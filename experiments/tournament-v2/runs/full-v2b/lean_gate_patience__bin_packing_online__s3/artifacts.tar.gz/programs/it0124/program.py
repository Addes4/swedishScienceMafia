# EVOLVE-BLOCK-START
"""Online bin packing: distribution-aware best fit.

Scoring rule
------------
For each candidate bin with remaining capacity c, placing the item leaves residual
r = c - item.  Best Fit prefers the smallest r (tightest fit).  We refine this using
a running (decaying) histogram of past item sizes: a residual r that exactly matches
a high-probability future item size is especially valuable, because a single future
item can then close the bin perfectly, avoiding wasted capacity.  Conversely, a
residual too small for any typical item is wasted and mildly penalized.

score = -r  +  beta * P(item == r)

where P is a normalized, decaying estimate of the empirical item-size distribution,
and beta controls how strongly we chase perfect complements.  Best-Fit is recovered
when beta = 0.
"""

import numpy as np

# Decaying running histogram of item sizes (buckets 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_ALPHA = 0.9995      # decay per observed item
_BETA = 12.0         # strength of complement-matching bonus
_COUNT = 0.0


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    global _HIST, _COUNT

    bins = np.asarray(bins, dtype=np.float64)
    residuals = bins - item  # residual capacity after placing the item here

    total = _HIST.sum()

    # Tightness term: prefer the smallest non-negative residual.
    tight = -residuals

    # Complement bonus: reward residuals equal to a likely future item size.
    if total > 0 and _BETA > 0.0:
        # Probability that the next item equals size s is estimated by hist[s]/total.
        # residual is a float; clamp to integer buckets.
        ri = np.clip(np.round(residuals).astype(np.int64), 0, 100)
        prob = _HIST[ri] / total              # estimated P(item == residual)
        # Only residuals that are valid sizes matter (>=1). Zero/negative residual
        # means the bin would be exactly full or overflow; harness only shows bins
        # the item fits in, so residual >= 0. Bonus for exact complements.
        bonus = _BETA * prob
        bonus = np.where(ri >= 1, bonus, 0.0)
    else:
        bonus = np.zeros_like(residuals)

    score = tight + bonus

    # Update the decaying histogram with this observed item.
    if 1 <= item <= 100:
        _HIST *= _ALPHA
        _HIST[item] += 1.0
        _COUNT += 1.0

    return score
# EVOLVE-BLOCK-END
