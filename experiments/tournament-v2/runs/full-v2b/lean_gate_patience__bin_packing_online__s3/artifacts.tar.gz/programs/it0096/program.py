# EVOLVE-BLOCK-START
"""Best-fit-dominant bin-choice rule.

For Weibull-shaped item sizes with mean ~40, classic best-fit (place the item in
the bin leaving the smallest non-negative residual) is a very strong online rule.
Earlier versions added a "fresh-bin penalty" that shifts the ordering and can
hurt. Here we anchor strictly on best-fit (minimize residual) and only use a
tie-breaker that lightly favors residuals close to the running mean item size,
which tends to be a refillable capacity, without ever overriding tightness.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.alpha = 0.02
        self.item_seen = 0


_state = _State()


def _observe(item):
    s = _state
    s.n += 1
    d = item - s.mean
    s.mean += s.alpha * d
    s.item_seen += 1


def priority(item, bins):
    _observe(item)

    s = _state
    mean = s.mean

    residual = bins - item  # >= 0 for all shown bins

    # Primary: best fit (smallest residual). Secondary: tiny bonus for residuals
    # near the running mean item size (a plausibly refillable capacity). The
    # secondary term is bounded well below 1 so it never overrides tightness.
    scale = mean if mean > 1.0 else 1.0
    closeness = 1.0 - np.abs(residual - mean) / (scale + residual + mean)
    # closeness in (0, 1]; weight small.
    bonus = 0.5 * closeness

    score = -residual.astype(np.float64) + bonus
    return score
# EVOLVE-BLOCK-END
