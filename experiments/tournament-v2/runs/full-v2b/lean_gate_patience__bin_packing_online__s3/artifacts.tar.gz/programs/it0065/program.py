# EVOLVE-BLOCK-START
"""Best-fit with a bias toward bins that become nearly full/closed."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.thresh = 20.0


_state = _State()


def priority(item, bins):
    """Best-fit, but favor bins whose post-placement residual is small."""
    s = _state
    s.n += 1
    # Running mean of item sizes (cheap, no variance needed).
    s.mean += (item - s.mean) / s.n
    # Threshold: half the mean item size, clamped to a small range.
    s.thresh = max(5.0, min(25.0, 0.5 * s.mean))

    residual = bins - item  # post-placement remaining capacity, >= 0

    # Base: best-fit => smaller residual is better (negative residual).
    score = -residual.astype(np.float64)

    # Bonus for bins that would become nearly-closed (residual below threshold).
    # Use a smooth bump so ties resolve consistently toward tighter bins.
    bonus = np.where(residual < s.thresh, (s.thresh - residual) * 0.5, 0.0)

    return score + bonus
# EVOLVE-BLOCK-END
