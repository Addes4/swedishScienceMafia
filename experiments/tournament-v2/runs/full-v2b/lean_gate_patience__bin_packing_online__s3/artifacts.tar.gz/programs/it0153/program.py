# EVOLVE-BLOCK-START
"""Best-fit bin choice with a closed-bin tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.min_item = 101  # smallest item seen so far

    def observe(self, item):
        if item < self.min_item:
            self.min_item = item


_state = _State()


def priority(item, bins):
    """Best-fit: smallest post-placement residual wins; closed bins get a bonus."""
    _state.observe(item)

    residual = bins - item  # int64 array, all >= 0 since bin fits item

    # Primary: smaller residual is better.
    score = -residual.astype(np.float64)

    # Tiny bonus for residuals that no future item (of observed min size) can use,
    # i.e. perfectly-closed bins -> prefer them to avoid wasting near-full bins.
    min_item = _state.min_item
    if min_item > 1:
        closed = residual < min_item
        score += closed * 1e-3

    return score
# EVOLVE-BLOCK-END
