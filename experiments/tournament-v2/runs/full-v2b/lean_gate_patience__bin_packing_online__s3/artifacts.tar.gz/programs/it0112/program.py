# EVOLVE-BLOCK-START
"""Best fit with histogram-aware residual desirability bonus."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.ones(101, dtype=np.float64)
        self.count = 1.0

    def observe(self, item):
        self.hist[item] += 1.0
        self.count += 1.0


_state = _State()


def priority(item, bins):
    st = _state
    st.observe(item)

    res = bins.astype(np.float64) - float(item)

    # Desirability of a leftover residual: how likely is it to be exactly
    # fillable by a common upcoming item size? Use histogram mass at that size.
    p = st.hist / st.count
    idx = np.clip(res.astype(np.int64), 0, 100)
    desirability = p[idx]

    # Base: best fit (prefer smallest leftover).
    score = -res + 8.0 * desirability
    return score
# EVOLVE-BLOCK-END
