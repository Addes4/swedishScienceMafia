# EVOLVE-BLOCK-START
"""Online bin packing: Best-Fit with a dead-space correction.

Primary rule is classic Best-Fit: smallest post-placement residual wins.
A tiny correction nudges ties/near-ties so that bins are not left with a
residual too small to accept a typical (mean ~40) future item, rewarding
perfect fills (residual 0) and slightly penalizing dead residuals.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Dead-space correction: residual below ~mean item size is wasteful.
    # Threshold near mean of distribution (about 40); small item-size guard.
    mean_item = 40.0
    # penalty grows as residual drops into the (0, mean_item) dead zone
    dead = np.where((residual > 0) & (residual < mean_item), 1.0, 0.0)
    # perfect fill bonus
    perfect = np.where(residual == 0, 1.0, 0.0)
    # Keep Primary tightest-fit dominant: scale residual by a large factor,
    # correction terms only affect bins with equal residuals.
    return -residual * 1000.0 - dead + perfect
# EVOLVE-BLOCK-END
