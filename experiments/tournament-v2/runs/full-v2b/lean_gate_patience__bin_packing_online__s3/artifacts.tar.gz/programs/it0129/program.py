# EVOLVE-BLOCK-START
"""Adaptive best-fit with consolidation bias for online bin packing."""
import numpy as np

_ewma_size = 40.0
_alpha = 0.02


def priority(item, bins):
    global _ewma_size
    _ewma_size = (1.0 - _alpha) * _ewma_size + _alpha * float(item)

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item  # remaining capacity if item placed here

    # Best-fit: prefer the smallest nonnegative residual (tightest fit).
    # Use large negative residual as primary score.
    score = -residual.astype(np.float64)

    # Consolidation bias: mildly reward bins that are already fuller
    # (i.e., bins with smaller remaining capacity relative to 100),
    # which packs into fewer bins by not spreading items thin.
    used = (bins < 100)
    fullness = (100.0 - bins.astype(np.float64)) / 100.0
    score += 0.5 * fullness * used

    # Tiny penalty for opening a brand-new bin, scaled by how many used bins exist,
    # so that fresh bins are only chosen when clearly best.
    fresh = (bins == 100)
    score -= 0.001 * fresh

    return score
# EVOLVE-BLOCK-END

