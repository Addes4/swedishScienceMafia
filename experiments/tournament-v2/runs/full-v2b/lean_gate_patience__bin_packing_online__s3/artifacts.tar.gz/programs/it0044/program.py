# EVOLVE-BLOCK-START
"""Best-fit with a probabilistic residual-usability bonus."""
import numpy as np


class _Model:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        self._dirty = True
        self._p = None

    def update(self, item):
        self.counts[item] += 1.0
        self.total += 1.0
        self._dirty = True

    def probs(self):
        if self._dirty or self._p is None:
            if self.total > 0:
                self._p = self.counts / self.total
            else:
                p = np.zeros(101, dtype=np.float64)
                p[1:101] = 1.0 / 100.0
                self._p = p
            self._dirty = False
        return self._p


_MODEL = _Model()


def priority(item, bins):
    m = _MODEL
    m.update(int(item))
    p = m.probs()

    tight = -(bins - item)              # best-fit dominant term
    leftover = bins - item              # >= 0 for shown bins

    # Residual-usability bonus: probability that the leftover equals an
    # integer size that future items actually take. Rewards packing that
    # leaves a *usable* residual (exactly consumable by a common size),
    # which is the main defect of pure best-fit.
    lo = np.clip(leftover, 0, 100).astype(np.int64)
    usable = p[lo]

    # Slight preference for keeping roomy bins flexible (avoid shredding).
    roomy = leftover * 0.0

    score = tight + 2.0 * usable
    return score
# EVOLVE-BLOCK-END
