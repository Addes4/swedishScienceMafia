# EVOLVE-BLOCK-START
"""Best-fit with a "multiple-of-mean" refinement.

Prefer the smallest post-placement residual (classic best fit). As a refinement,
penalize residuals whose value modulo the running mean item size is far from 0,
so that leftover gaps tend to be exactly refillable by future typical items.
"""
import numpy as np

_SIZE = 100


class _Model:
    def __init__(self):
        self.counts = np.zeros(_SIZE + 1, dtype=np.float64)
        self._n = 0

    def observe(self, item):
        self.counts[item] += 1.0
        self._n += 1

    def mean(self):
        total = self.counts[1:].sum()
        if total <= 0:
            return 40.0
        sizes = np.arange(1, _SIZE + 1, dtype=np.float64)
        return float(np.dot(self.counts[1:], sizes)) / total


_model = _Model()


def priority(item, bins):
    _model.observe(item)
    mean = _model.mean()
    if mean < 1.0:
        mean = 1.0

    res = bins.astype(np.float64) - float(item)

    # primary: best fit (smallest residual)
    score = -res

    # secondary: prefer residuals close to a multiple of the mean item size
    # (exactly refillable gaps), computed with a smooth periodic bonus.
    # Use fractional part relative to mean.
    frac = res % mean
    dist_to_mult = np.minimum(frac, mean - frac)  # in [0, mean/2]
    score -= 1e-3 * dist_to_mult

    return score
# EVOLVE-BLOCK-END
