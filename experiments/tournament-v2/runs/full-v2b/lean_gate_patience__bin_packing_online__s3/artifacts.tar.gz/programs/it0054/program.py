# EVOLVE-BLOCK-START
"""Adaptive fresh-bin penalty: best-fit tightness minus an adaptive reward for large residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0


_state = _State()


def priority(item, bins):
    """Score bins: tighter fit is better, but penalize leaving a large residual capacity.

    Penalty strength adapts to the running pressure (mean and variability of past items).
    """
    st = _state
    # Update running stats of item sizes (online mean/variance).
    st.n += 1
    delta = item - st.mean
    st.mean += delta / st.n
    st.m2 += delta * (item - st.mean)

    # Pressure proxy: size relative to mean, plus variability influence.
    if st.n > 1:
        std = (st.m2 / (st.n - 1)) ** 0.5
    else:
        std = 0.0

    # Normalize the current item against the running distribution.
    denom = st.mean if st.mean > 1e-9 else 1.0
    size_ratio = item / denom  # ~1 for typical items, >1 for large
    var_term = std / denom if denom > 1e-9 else 0.0

    # lambda in [0, ~1.2]: grows with item size pressure, shrinks with variability
    # (when variability is high, a strong fresh-bin penalty risks misplaced packing).
    lam = 0.9 * (size_ratio - 1.0) + 0.3 * var_term
    if lam < 0.0:
        lam = 0.0
    elif lam > 1.2:
        lam = 1.2

    # Best-fit term: -(bins - item) favors the tightest fit.
    tight = -(bins - item)
    # Penalize large residuals (fresh / high-remaining bins).
    return tight - lam * bins
# EVOLVE-BLOCK-END
