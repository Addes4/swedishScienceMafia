# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with exact-fill bonus.

Score each bin by (a) best-fit tightness (small post-placement residual) plus (b) a
bonus when the post-placement residual is likely to be fillable by upcoming items,
estimated from a running histogram of observed sizes. Bins whose leftover space
matches a probable item size, or a probable pair of item sizes, are preferred, so
bins tend to close out exactly rather than leaking small unusable gaps.
"""
import numpy as np

_SIZE = 100
_SIZES = np.arange(1, _SIZE + 1, dtype=np.float64)


class _Model:
    def __init__(self, decay=0.998):
        self.h = np.ones(_SIZE + 1, dtype=np.float64)
        self.h[0] = 0.0
        self._n = 0

    def observe(self, item):
        self.h *= self.decay
        self.h[item] += 1.0
        self._n += 1
        if self._n % 128 == 0:
            s = self.h[1:].sum()
            if s > 0:
                self.h[1:] *= 100.0 / s

    def probs(self):
        p = self.h[1:].copy()
        s = p.sum()
        if s <= 0:
            return np.full(_SIZE, 1.0 / _SIZE, dtype=np.float64)
        return p / s


_model = _Model()


def _fill_value(residuals, probs):
    """Estimate the value of a post-placement residual.

    For each residual r, compute the probability mass of single items that fit
    exactly (r-1..r region) and a smoothed measure of how completely r can be
    consumed by the most probable item sizes. Higher value -> more likely to be
    closed out cleanly later, so bins producing such residuals are preferred.
    """
    # cumulative distribution of single-item sizes
    cdf = np.concatenate(([0.0], np.cumsum(probs)))  # cdf[k] = P(size <= k)
    # probability an item fits in residual r: P(item <= r)
    fit_prob = cdf[np.clip(residuals.astype(np.int64), 0, _SIZE)]
    # expected "leftover usefulness": mass of items that leave a still-useful gap
    # prefer residuals that are small but still fit a typical item
    return fit_prob


def priority(item, bins):
    """Score bins: best-fit tightness plus exact-fill / refill-utility bonus."""
    _model.observe(item)
    probs = _model.probs()
    sizes = _SIZES
    mean = float(np.dot(probs, sizes))
    if mean <= 1e-9:
        mean = 1.0

    res = bins.astype(np.float64) - float(item)

    # best-fit: prefer smallest post-placement residual
    tightness = -res / mean

    # utility: residual that can hold a typical future item (prob-based)
    rc = np.clip(res.astype(np.int64), 0, _SIZE)
    cdf = np.concatenate(([0.0], np.cumsum(probs)))
    fit_prob = cdf[rc]
    # small residuals that still fit typical items aren't a strong loss
    utility = fit_prob * np.minimum(res, mean) / mean

    # exact-completion bonus: if residual equals a very probable size, big reward
    exact = probs[rc - 1] if np.ndim(rc) else probs[max(rc - 1, 0)]
    # handle index 0 safely
    exact = np.where(rc >= 1, probs[np.clip(rc - 1, 0, _SIZE - 1)], 0.0)

    return tightness + 0.25 * utility + 2.0 * exact
# EVOLVE-BLOCK-END
