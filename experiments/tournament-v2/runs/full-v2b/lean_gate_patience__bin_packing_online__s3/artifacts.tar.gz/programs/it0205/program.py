# EVOLVE-BLOCK-START
"""Best-Fit variant with a scaled tightness tie-breaker."""
import numpy as np


def priority(item, bins):
    """Score bins primarily by tightest fit, with a secondary proportional term.

    Classic Best-Fit picks the bin minimizing the post-placement residual.
    Here we use score = -(residual) + alpha * (bins - item) / 100.0 where the
    second term slightly favors placing the item in a bin that currently has
    more used capacity (larger original load), which preserves room in
    fresh bins. alpha is small so ordering remains essentially best-fit.
    """
    residual = bins - item
    # Primary: smaller residual is better (negative residual).
    # Secondary: proportional tightness tie-break.
    score = -residual.astype(np.float64) + 0.001 * ((bins - item) / 100.0)
    return score
# EVOLVE-BLOCK-END

