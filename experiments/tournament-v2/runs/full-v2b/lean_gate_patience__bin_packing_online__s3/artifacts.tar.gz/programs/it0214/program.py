# EVOLVE-BLOCK-START
"""Best-Fit with a running-histogram tie-breaker.

Primary rule: classic Best-Fit (smallest post-placement residual).
Secondary rule (tiny weight): among near-equal residuals, prefer a residual
that has frequently appeared as an item size, so the leftover is likely to be
consumed by a future item rather than wasted.
"""
import numpy as np

_FREQ = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    global _TOTAL
    res = bins - item  # post-placement residual (>= 0 for fitting bins)

    # update running histogram of item sizes (after scoring bin choice is fine too,
    # but do it here before use is fine since item is already fixed)
    _FREQ[item] += 1.0
    _TOTAL += 1.0

    # primary: minimize residual
    score = -res.astype(np.float64)

    # secondary: tiny bonus if the residual value is a commonly observed size
    freq = _FREQ[res]
    score += (freq / _TOTAL) * 1e-3

    return score
# EVOLVE-BLOCK-END
