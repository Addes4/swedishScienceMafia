# EVOLVE-BLOCK-START
"""Best-fit with randomized tie-breaking.

Primary rule: best-fit (smallest post-placement residual). For integer item
sizes, ties are frequent; breaking them in bin-index order tends to fill low
indices first, which can waste capacity. We break ties pseudo-randomly using a
running call counter so that items get spread more evenly, reducing the chance
of leaving many partially-full early bins.
"""
import numpy as np

_CAP = 100

_STATE = {
    "calls": 0,
}


def priority(item, bins):
    _STATE["calls"] += 1
    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    resid = bins - item
    np.clip(resid, 0.0, None, out=resid)

    # pseudo-random per-bin jitter, small enough to only break ties
    idx = np.arange(n, dtype=np.float64)
    jitter = (np.sin((idx + 1.0) * 12.9898 + _STATE["calls"] * 78.233) * 43758.5453)
    jitter = jitter - np.floor(jitter)  # in [0,1)
    jitter = jitter * 0.5  # keep strictly smaller than 1 (residual integer gap)

    score = -resid + jitter
    return score
# EVOLVE-BLOCK-END
