# EVOLVE-BLOCK-START
"""Best-fit with fresh-bin deferral: prefer tightest opened bin, use fresh only if needed."""
import numpy as np


def priority(item, bins):
    res = bins.astype(np.float64) - float(item)
    # Tightness: prefer smallest residual (classic best fit).
    score = -res
    # Strongly defer fresh (empty) bins: only chosen when no opened bin fits.
    fresh = res >= 100.0 - float(item)
    score -= 1e6 * fresh
    return score
# EVOLVE-BLOCK-END
