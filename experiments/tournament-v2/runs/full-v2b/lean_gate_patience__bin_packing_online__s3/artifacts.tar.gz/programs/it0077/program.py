# EVOLVE-BLOCK-START
"""Best-fit with large-item fill preference.

The key inefficiency in plain best fit is that a large item may be placed into
a bin leaving a large residual (which later gets wasted), while a slightly less
tight bin would have become nearly full.  We keep best fit as the primary rule
but, for items at or above the running mean size, add a bonus proportional to
how full the bin becomes after placement, gently favoring fuller bins.
"""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0
        self.count = 0.0

    def observe(self, item):
        self.count += 1.0
        a = 1.0 / min(self.count, 200.0)
        self.mean += a * (item - self.mean)


_state = _State()


def priority(item, bins):
    _state.observe(item)

    obj = np.asarray(bins, dtype=np.int64)
    rem = obj - item  # residual after placement (>= 0)

    # Primary: tightest fit (smallest residual).
    score = -rem.astype(np.float64) * 1e6

    # Secondary: for large items, reward bins that end up fuller
    # (smaller residual relative to capacity), breaking near-ties toward
    # deeper, more completely used bins.
    if item >= _state.mean:
        # higher = fuller after placement
        fullness = (100.0 - rem.astype(np.float64)) / 100.0
        score += fullness

    return score
# EVOLVE-BLOCK-END
