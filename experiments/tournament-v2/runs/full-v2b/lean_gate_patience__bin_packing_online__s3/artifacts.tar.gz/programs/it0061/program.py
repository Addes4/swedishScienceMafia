# EVOLVE-BLOCK-START
"""Plain Best-Fit: choose the bin with the smallest remaining capacity that fits."""
import numpy as np


def priority(item, bins):
    """Rank bins by smallest remaining capacity (best fit)."""
    return -bins
# EVOLVE-BLOCK-END
