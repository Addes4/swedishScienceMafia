# EVOLVE-BLOCK-START
"""Best-fit with residual-fit bonus from online item-size histogram.

Base rule: best-fit (minimize post-placement residual).
Extra: smooth bonus for residuals that are close to a size likely to appear,
approximated by a fixed set of common target residuals derived from the running
mean, giving slight preference to bins that can be exactly filled later.
"""
import numpy as np


def priority(item, bins):
    st = priority.__dict__
    if 'mean' not in st:
        st['mean'] = 40.0
        st['count'] = 0

    st['count'] += 1
    st['mean'] += 0.05 * (item - st['mean'])
    mean = st['mean']

    residual = bins.astype(np.float64) - item
    # base: best-fit
    score = -residual

    # bonus: encourage residuals near zero (exact fill) and near mean
    # small extra term, never dominating best-fit ordering
    tiny = np.exp(-((residual) / 2.0) ** 2)          # exact-fit bonus
    mid = np.exp(-((residual - mean) / 8.0) ** 2)     # usable chunk bonus
    score = score + 0.3 * tiny + 0.05 * mid
    return score
# EVOLVE-BLOCK-END
