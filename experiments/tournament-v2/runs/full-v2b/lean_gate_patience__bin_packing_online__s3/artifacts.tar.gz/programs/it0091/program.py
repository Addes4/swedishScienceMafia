"""Sum-of-squares (opportunity-cost) bin-choice rule with histogram-adaptive blending.

Classic best-fit minimizes the immediate residual. A stronger online rule is to
minimize the *increase in the sum of squares* of all residuals caused by placing
the item, which is equivalent to preferring bins whose residual stays as full as
possible. We blend this with a histogram-derived "fill value" term that rewards
residuals historically likely to be reused.
"""

import numpy as np

STATE = {
    "hist": np.zeros(101, dtype=np.float64),
    "n": 0.0,
    "ewma": 0.0,
    "var": 0.0,
    "init": False,
}


def priority(item, bins):
    st = STATE
    hist = st["hist"]

    # Update EWMA pressure from arriving item (past info only).
    if not st["init"]:
        st["ewma"] = float(item)
        st["var"] = 0.0
        st["init"] = True
    else:
        a = 0.05
        prev = st["ewma"]
        st["ewma"] = (1 - a) * prev + a * item
        d = item - prev
        st["var"] = (1 - a) * st["var"] + a * d * d

    bins = np.asarray(bins)
    k = bins.shape[0]
    if k == 0:
        return bins

    res = bins.astype(np.float64)          # residual BEFORE placing
    residual = res - item                  # residual AFTER placing

    # Sum-of-squares opportunity cost: placing into a bin changes its squared
    # residual from res^2 to residual^2; we want to MINIMIZE total sum of squares,
    # so the score is the negative change = res^2 - residual^2.
    score_ss = res * res - residual * residual

    # Histogram-based fill value of the resulting residual.
    total = hist.sum()
    if total > 0:
        cum = np.concatenate(([0.0], np.cumsum(hist)))
        idx = np.arange(101)
        cum_sz = np.concatenate(([0.0], np.cumsum(idx * hist)))
        r_clip = np.clip(residual.astype(np.int64), 0, 100)
        fit_mass = cum[r_clip + 1]
        sz_sum = cum_sz[r_clip + 1]
        with np.errstate(divide="ignore", invalid="ignore"):
            mean_fit = np.where(fit_mass > 0, sz_sum / np.maximum(fit_mass, 1e-9), 0.0)
        p_fit = fit_mass / total
        leftover = np.maximum(residual - mean_fit, 0.0)
        fill_val = -leftover * (0.5 + 0.5 * p_fit)
    else:
        fill_val = -residual

    # Prefer not to leave a negative residual (invalid placements get pushed down
    # via score_ss which would be huge negative if residual < 0).
    valid = residual >= 0

    # Weight: lean on sum-of-squares (strong theoretical basis); moderate fill term.
    scores = score_ss + 0.15 * fill_val
    scores = np.where(valid, scores, -1e9)

    # Update histogram after scoring.
    if 1 <= item <= 100:
        hist[item] += 1.0
        st["n"] += 1.0

    return scores
