# EVOLVE-BLOCK-START
"""Best-Fit with load-tie-break bin choice.

Items go to the fitting bin with the smallest post-placement residual
(classic Best-Fit). Ties are broken toward the bin that is currently
fullest, encoded via a tiny secondary term so it never overrides the
primary residual ordering for distinct residuals.
"""
import numpy as np


def priority(item, bins):
    # Primary: smallest post-placement residual (-(bins - item)).
    # Secondary: prefer fuller bins, i.e. smaller pre-placement remaining
    # capacity (bins). Use a tiny weight so ties in residual are resolved
    # without disturbing the main best-fit ordering.
    post = bins - item
    return -post.astype(np.float64) - 1e-6 * bins
# EVOLVE-BLOCK-END
