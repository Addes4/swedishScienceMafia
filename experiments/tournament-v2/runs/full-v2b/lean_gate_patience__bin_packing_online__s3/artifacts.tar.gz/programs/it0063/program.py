# EVOLVE-BLOCK-START
"""Best-fit with a small alignment bonus favoring residuals near multiples of
a common small-item quantum, to improve exact-fill opportunities."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.small_sum = 0.0
        self.small_cnt = 0
        self.q = 0.0


_state = _State()


def priority(item, bins):
    s = _state
    s.n += 1

    # Track mean of smallish items as candidate "fill quantum" q.
    if item <= 50:
        s.small_sum += item
        s.small_cnt += 1
    if s.small_cnt > 50:
        s.q = s.small_sum / s.small_cnt

    residual = bins - item  # post-placement residual, >= 0

    # Base best-fit: smaller residual is better.
    base = -residual.astype(np.float64)

    # Alignment bonus: reward residuals close to a multiple of q.
    if s.q > 1.0:
        r = np.mod(residual, s.q)
        d = np.minimum(r, s.q - r)
        align = np.maximum(0.0, 1.0 - d / (0.5 * s.q))
        bonus = 1.1 * align
    else:
        bonus = 0.0

    return base + bonus
# EVOLVE-BLOCK-END
