import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "sumsq": 0.0,
    "recent": [],
}


def priority(item, bins):
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["sumsq"] += item * item
    st["recent"].append(item)
    if len(st["recent"]) > 200:
        st["recent"].pop(0)

    n = st["n"]
    mean = st["sum"] / n
    var = max(0.0, st["sumsq"] / n - mean * mean)
    sd = var ** 0.5
    target = mean  # typical future item size

    rem = bins.astype(np.float64)
    slack_after = rem - item

    if item >= 50:
        # Large item: pure best fit (minimize leftover).
        score = -slack_after
    else:
        # Small item: prefer residual closest to the typical item size,
        # while still favoring tight fits. Blend tightness with target residual.
        score = -slack_after - 0.3 * np.abs(slack_after - target)

    return score
