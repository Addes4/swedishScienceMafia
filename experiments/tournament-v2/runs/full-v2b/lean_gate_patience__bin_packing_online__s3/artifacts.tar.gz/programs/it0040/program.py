# EVOLVE-BLOCK-START
"""Best-fit core with a bonus for residuals matching frequently seen item sizes."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes (1..100), with mild decay to track distribution
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0


_state = _State()


def priority(item, bins):
    st = _state
    st.count += 1

    # decayed histogram; slow adaptation, no future info
    decay = 0.001 if st.count > 20 else 0.05
    st.hist *= (1.0 - decay)
    st.hist[item] += 1.0

    # Residual after placing into each bin.
    residual = bins - item  # best-fit: smaller residual is better

    # Base best-fit score (higher is better): tighter fit => larger item-bins.
    score = -(residual).astype(np.float64)

    # Bonus for residual matching a frequently seen size: strong recent mass means
    # that leftover can likely be filled exactly later.
    # Look at the histogram positions 1..100 as candidate residual sizes.
    # We compute a per-bin weight from histogram frequency at that residual value.
    r = residual.astype(np.int64)
    valid = (r >= 0) & (r <= 100)
    h = np.zeros(bins.shape, dtype=np.float64)
    idx = np.clip(r, 0, 100)
    h[valid] = st.hist[idx[valid]]
    # normalize
    tot = st.hist.sum()
    if tot > 0:
        h = h / tot
    # Bonus magnitude small but meaningful; frequency-scaled.
    score += 200.0 * h

    # Tiny tie-break: prefer leaving larger remaining capacity among equal scores
    # (keeps a flexible bin) using a negligible epsilon.
    score += 1e-6 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
