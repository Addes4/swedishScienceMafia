# EVOLVE-BLOCK-START
"""Best-fit with a dead-zone penalty for residuals too small for future large items."""
import numpy as np

_state = {"sum": 0.0, "n": 0, "big": 40.0}


def priority(item, bins):
    """Best-fit dominant, penalize residuals in a dead zone below typical large items."""
    s = _state
    s["sum"] += item
    s["n"] += 1
    if s["n"] > 50:
        s["sum"] *= 0.995
        s["n"] *= 0.995
    recent = s["sum"] / s["n"]
    # Track the tail: roughly the top ~30% of items (Weibull mean ~40, tail bigger).
    if item > recent:
        s["big"] = 0.95 * s["big"] + 0.05 * item

    big = max(s["big"], 1.0)

    leftover = bins.astype(np.float64) - item
    # Dominant best-fit: prefer smallest nonnegative leftover.
    score = -leftover

    # Dead-zone penalty: a small positive leftover that can't hold a typical big item
    # wastes the bin for future large arrivals. Penalize it, more when the gap is
    # just below the big-item scale (hardest to reuse).
    dead = (leftover > 0) & (leftover < big)
    # Weight peaks near leftover ~ big/2 and fades toward 0 and toward big.
    w = 1.0 - np.abs(2.0 * leftover / big - 1.0)
    w = np.clip(w, 0.0, 1.0)
    score = score - 0.15 * big * dead * w

    return score
# EVOLVE-BLOCK-END
