# EVOLVE-BLOCK-START
"""Best-fit with an adaptive, size-aware tie-break.

Core: maximising (item - residual) is classic Best-Fit (tightest fit).
Add-ons:
  * lambda * residual term to slightly discourage opening fresh bins.
  * A small "fragment" correction: residuals that are positive but smaller than
    a running estimate of the smallest item seen recently are effectively
    wasted, so we nudge the score to avoid creating them when an alternative
    with a usable residual exists.
State kept out of the hot loop where possible.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0
        self.min_seen = 100.0   # running minimum item size (with mild decay)
        self.window = 500
        self.recent = []

    def update(self, item):
        self.n += 1
        delta = item - self.mean
        self.mean += delta / self.n
        self.m2 += delta * (item - self.mean)
        if item < self.min_seen:
            self.min_seen = float(item)
        self.recent.append(item)
        if len(self.recent) > self.window:
            self.recent.pop(0)

    def pressure(self):
        if self.n < 5:
            return 0.0
        var = self.m2 / max(1, self.n - 1)
        std = var ** 0.5
        m = self.mean
        return (m / 100.0) + 0.5 * (std / 100.0)

    def small_item_estimate(self):
        # Smallest item we expect to need room for. Use min seen but bounded
        # so it doesn't collapse to a huge value too quickly.
        ms = self.min_seen
        if len(self.recent) >= 50:
            rec_min = min(self.recent)
            ms = min(ms, float(rec_min))
        return max(1.0, min(ms, 40.0))


_state = _State()


def priority(item, bins):
    _state.update(item)

    p = _state.pressure()
    lam = 0.5 * (1.0 - min(1.0, p / 0.6))

    rem = bins.astype(np.float64)
    residual = rem - item          # leftover after placing
    tightness = -residual          # best-fit core

    slack_pen = -lam * rem         # discourage fresh bins

    # Fragment correction: residual in (0, small_est) is nearly wasted.
    small = _state.small_item_estimate()
    # reward residuals that are >= small (usable), penalize tiny positive residuals.
    frag = np.where((residual > 0) & (residual < small),
                    -(small - residual) * 0.15,
                    0.0)

    return tightness + slack_pen + frag
# EVOLVE-BLOCK-END
