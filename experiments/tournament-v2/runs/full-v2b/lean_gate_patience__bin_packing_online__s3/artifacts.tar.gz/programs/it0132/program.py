# EVOLVE-BLOCK-START
"""Best-fit with a fillability bonus based on a running size histogram."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_hist_count = 0.0

# Cache arrays
_r = np.arange(101, dtype=np.float64)
_fill_cache = None
_fill_tag = -1.0


def priority(item, bins):
    global _hist, _hist_count, _fill_cache, _fill_tag

    bins = np.asarray(bins, dtype=np.int64)
    n = bins.shape[0]

    if 1 <= item <= 100:
        _hist[item] += 1.0
        _hist_count += 1.0

    residual = (bins - item).astype(np.float64)  # residual after placement

    # Frequent-update fill probability cache: probability that a random future item
    # fits into a residual of size r. Approximated as P(size <= r) from the histogram.
    tag = _hist_count
    if _fill_cache is None or tag - _fill_tag >= 50.0:
        if _hist_count > 0:
            counts = _hist[1:101]
            total = _hist_count
            cum = np.cumsum(counts) / total  # cum[k-1] = P(size <= k)
        else:
            cum = np.full(100, 0.4)
        # prob[r] = P(future item size <= r)
        prob = np.empty(101, dtype=np.float64)
        prob[0] = 0.0
        prob[1:101] = cum
        _fill_cache = prob
        _fill_tag = tag

    # Best-fit: prefer small residual (minimize waste)
    score = -residual

    # Fillability bonus: reward bins whose residual is likely to fit at least one more item,
    # so we don't "waste" a bin on a residual that can hold nothing useful.
    fill_prob = _fill_cache[np.clip(residual, 0, 100).astype(np.int64)]
    score += 2.0 * fill_prob

    return score
# EVOLVE-BLOCK-END
