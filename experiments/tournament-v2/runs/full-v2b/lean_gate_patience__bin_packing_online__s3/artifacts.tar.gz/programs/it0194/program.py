import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "count": 0.0,
    "mean": 40.0,
    "fill": None,      # lookup table: expected future fill count for residual 0..100
    "last_built": -1,
}

SIZES = np.arange(1, 101, dtype=np.float64)


def _build_fill(hist, count):
    # Empirical distribution over sizes 1..100 with Laplace smoothing.
    total = count + 100.0
    p = (hist[1:101] + 1.0) / total  # length 100

    # Expected number of *items* that can be packed (greedy, one item at a time)
    # into residual r.  We approximate by the expected total size that fits
    # divided by the mean size, but cap at the raw count of items that fit.
    # Use E[min(r//j, ...)]-style: sum_j p_j * floor(r/j) but this can exceed
    # actual packing; instead use expected volume fill: the expected number of
    # items ~ r * E[1/j] when r is large relative to items.
    e_inv = float(p.dot(1.0 / SIZES))
    mean = float(p.dot(SIZES))

    fill = np.zeros(101, dtype=np.float64)
    for r in range(101):
        # expected items fit ~ min(r * E[1/j], r/mean-ish) blend
        val = r * e_inv
        # but never more than r / (small mean estimate) items
        val = min(val, r / max(mean, 1.0))
        fill[r] = val
    return fill


def priority(item, bins):
    st = _state
    st["hist"][item] += 1.0
    st["count"] += 1.0
    c = st["count"]
    st["mean"] = st["mean"] + (item - st["mean"]) / c

    # Rebuild fill table periodically (cheap enough, amortized).
    if st["fill"] is None or c - st["last_built"] >= 50:
        st["fill"] = _build_fill(st["hist"], c)
        st["last_built"] = c

    fill = st["fill"]

    resid = bins - item
    resid = np.clip(resid, 0, 100).astype(np.int64)

    # Score: prefer residuals with high expected future fill (use up space well),
    # tie-break toward tighter fit by adding a small preference for smaller resid.
    score = fill[resid] - resid * 0.001

    return score
