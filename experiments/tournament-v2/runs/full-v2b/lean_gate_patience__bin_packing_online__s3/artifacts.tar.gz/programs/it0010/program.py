# EVOLVE-BLOCK-START
"""
Adaptive best-fit: tightest fit wins, with a decaying penalty against
opening brand-new bins so that large items can still get fresh space early on
without wasting new bins on items that fit snugly into existing ones.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0

    def observe(self):
        self.n += 1


_state = _State()


def priority(item, bins):
    item = int(item)
    _state.observe()

    b = np.asarray(bins, dtype=np.float64)
    size = b.size
    if size == 0:
        return np.zeros(0, dtype=np.float64)

    residual = b - float(item)

    # Primary key: prefer the tightest fit (smallest residual after placement).
    base = -residual

    # Penalty against using a completely fresh bin. It decays with the number of
    # observed items: early on we want to preserve fresh bins for the occasional
    # large item; once the stream is well underway, pure best-fit is best.
    fresh = (b >= 100.0).astype(np.float64)
    decay = 1.0 / (1.0 + _state.n / 500.0)
    base = base - 1.5 * decay * fresh

    return base


# EVOLVE-BLOCK-END
