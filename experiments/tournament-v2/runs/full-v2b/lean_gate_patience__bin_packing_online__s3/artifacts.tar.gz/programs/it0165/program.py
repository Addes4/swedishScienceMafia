# EVOLVE-BLOCK-START
"""Best-fit with an explicit future-fillability bonus.

For each candidate bin we look at the residual capacity left after placing the
item and estimate how densely that residual could be filled by future items,
using the running histogram of observed sizes. The greedy densest-fill estimate
is the fraction of the residual that can be covered by repeatedly taking the
largest observed size that still fits. A residual that can be almost perfectly
covered is valuable (it "wants" to be closed); a residual that wastes space is
penalized. We combine this with a strong preference for the tightest fit.
"""
import numpy as np

_CAP = 100

_STATE = {
    "hist": None,
    "count": 0,
}


def _ensure_hist():
    if _STATE["hist"] is None:
        _STATE["hist"] = np.zeros(_CAP + 1, dtype=np.float64)


def priority(item, bins):
    _ensure_hist()
    _STATE["hist"][item] += 1.0
    _STATE["count"] += 1

    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    resid = bins - item
    np.clip(resid, 0.0, None, out=resid)

    hist = _STATE["hist"]
    total = _STATE["count"]

    # sorted observed sizes (descending) for greedy densest-fill estimate
    sizes = np.arange(1, _CAP + 1, dtype=np.float64)
    counts = hist[1:]
    if total > 0:
        present = sizes[counts > 0]
        order = np.argsort(-present)
        sorted_sizes = present[order]
    else:
        sorted_sizes = np.array([40.0])

    # --- fit tightness (dominant): prefer smallest residual ---
    tight = -resid

    # --- densest-fill estimate per unique residual value ---
    # residual values are integers 0..100; compute the greedy fill fraction.
    fill = np.zeros(n, dtype=np.float64)
    # small cache keyed by integer residual
    cache = {}

    def densest(r):
        rr = r
        if rr <= 0:
            return 1.0  # exact fill / already closed
        covered = 0.0
        # greedily take the largest size that fits
        for s in sorted_sizes:
            while s <= rr:
                rr -= s
                covered += s
        return covered / r

    uniq = np.unique(resid)
    for u in uniq:
        if u <= 0:
            cache[0.0] = 1.0
        else:
            cache[float(u)] = densest(float(u))

    for i in range(n):
        fill[i] = cache[float(resid[i])]

    # Fresh bins: residual == 100 - item.
    is_fresh = (bins >= _CAP - 1e-9)
    pressure = min(1.0, total / 500.0)
    fresh_pen = is_fresh.astype(np.float64) * (0.5 + 1.5 * pressure)

    # Combine: tightness dominates; fillability rewards reusable residuals;
    # exact fills get a strong bonus.
    score = tight + 4.0 * fill - fresh_pen
    score = score + 3.0 * (resid < 0.5).astype(np.float64)

    return score
# EVOLVE-BLOCK-END
