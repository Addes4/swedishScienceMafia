# EVOLVE-BLOCK-START
"""Online bin choice: best-fit with a closing bonus and exact-fit tie-break.

Primary rule: place the item into the bin with the smallest post-placement
residual (best fit) to keep bins tightly packed. A large bonus is given to
placements that "close" a bin (residual smaller than the smallest item size
seen so far). A running frequency array records how often each item size is
seen; placements whose residual exactly equals a frequently observed size are
favored, since such bins are likely to be filled exactly by a future item.
"""
import numpy as np

_SIZE_MAX = 100

# Smallest item size observed so far (init to a large value).
_min_item = _SIZE_MAX + 1

# Running frequency of observed item sizes (index 0..100).
_freq = np.zeros(_SIZE_MAX + 1, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _min_item, _freq, _total
    item = int(item)
    if item < _min_item:
        _min_item = item

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item
    fits = residual >= 0

    # Best-fit: prefer the smallest non-negative residual.
    score = -residual

    # Closing bonus: residual below smallest observed item => bin is closed.
    closed = fits & (residual < _min_item)
    score = score + closed * _SIZE_MAX

    # Tie-break: reward residuals that exactly match a frequently-seen size,
    # since a future item of that size can fill the bin exactly.
    ri = np.clip(residual, 0, _SIZE_MAX).astype(np.int64)
    exact = fits & (residual == ri)
    freq_bonus = np.where(exact, _freq[ri] / (_total + 1.0), 0.0)
    score = score + freq_bonus * 0.5

    # Ensure non-fitting bins are never chosen.
    score = np.where(fits, score, -1e9)

    # Update frequency stats for future calls.
    _freq[item] += 1.0
    _total += 1.0

    return score
# EVOLVE-BLOCK-END
