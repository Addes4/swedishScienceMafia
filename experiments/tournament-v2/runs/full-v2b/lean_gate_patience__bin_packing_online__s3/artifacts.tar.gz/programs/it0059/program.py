# EVOLVE-BLOCK-START
"""Best-fit tightened by an adaptive reward for residuals that match frequent item sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.counts = np.zeros(101, dtype=np.float64)  # histogram of past item sizes


_state = _State()


def priority(item, bins):
    """Score bins: primarily best-fit (smallest post-placement residual).

    Add a bonus when the resulting residual equals a size that past items frequently
    take, so leftover fragments are likely to be filled exactly by a future item.
    """
    st = _state
    st.n += 1
    counts = st.counts
    counts[item] += 1.0

    residual = bins - item  # post-placement remaining capacity per bin (>=0)

    # Frequency (probability) that a future item equals this residual value.
    freq = counts / st.n

    # Best-fit primary term (scaled so tie-breaks matter only among close residuals).
    score = -residual.astype(np.float64)

    # Bonus: residual matches a commonly-seen item size -> keep fragment valuable.
    # Weight grows mildly with sample size confidence but stays modest.
    bonus = freq[residual] * 40.0

    return score + bonus
# EVOLVE-BLOCK-END
