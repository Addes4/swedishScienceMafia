# EVOLVE-BLOCK-START
"""Online adaptive excess rule using a running item-size histogram."""
import numpy as np


class _State:
    def __init__(self):
        # histogram over item sizes 1..100
        self.hist = np.ones(101, dtype=np.float64) * 0.01
        self.count = 0.0
        # EWMA of item sizes
        self.mean = 40.0
        # alpha for histogram decay
        self.alpha = 0.02


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    st = _state

    # update running statistics with current item
    st.count += 1.0
    st.hist[item] += 1.0
    # decay histogram to keep it recent
    st.hist *= (1.0 - st.alpha)
    st.mean = 0.98 * st.mean + 0.02 * item

    residual = bins - item  # remaining capacities after placing item here

    # baseline: prefer tight fit (small residual)
    score = -residual.astype(np.float64)

    # downstream usefulness: probability that residual capacity can be well filled
    # estimate expected number of future items that fit into residual
    # using running mean
    m = max(st.mean, 1e-6)

    # small bonus if residual is near a multiple of mean (good packing potential)
    rem = residual.astype(np.float64)
    # measure closeness of residual to a multiple of mean (prefer near-multiples)
    k = np.round(rem / m)
    k = np.maximum(k, 1.0)
    # deviation of residual from k*mean
    dev = np.abs(rem - k * m)
    # smaller deviation is better
    score += 0.5 * (-dev)

    # bonus for bins with low residual variance potential (tight best fit strongly)
    # already captured by -residual term

    return score
# EVOLVE-BLOCK-END
