# EVOLVE-BLOCK-START
"""Best-fit with a residual-matching bonus based on a running item histogram."""
import numpy as np

_SIZE = 101
_HIST = np.ones(_SIZE, dtype=np.float64)
_COUNT = float(_SIZE)
_DECAY = 0.995


def priority(item, bins):
    global _HIST, _COUNT
    _HIST *= _DECAY
    _HIST[item] += 1.0
    _COUNT = _COUNT * _DECAY + 1.0
    hist = _HIST / _COUNT

    residual = bins - item  # post-placement residual capacity per candidate bin

    # Best-fit dominant term: smaller residual is better.
    score = -residual.astype(np.float64)

    # Residual-matching bonus: a residual r is "useful" if r is itself a
    # frequently occurring item size (so a future item can fill it exactly).
    freq = hist[np.clip(residual, 0, 100)]
    # scale the bonus so it only acts as a tie-breaker (max bonus < 1 unit).
    score += freq * 8.0

    return score
# EVOLVE-BLOCK-END
