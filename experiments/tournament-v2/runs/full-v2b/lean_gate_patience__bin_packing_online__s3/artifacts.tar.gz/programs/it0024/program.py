"""Adaptive best-fit with pressure-modulated fresh-bin penalty."""
import numpy as np

_state = {"sum": 0.0, "count": 0, "prev": None, "slack": 40.0}


def priority(item, bins):
    """Rank bins: tightest fit, penalized by an adaptive reluctance to use fresh bins.

    We keep a running estimate of the "pressure" of arriving items: smaller items
    leave more slack, so we relax toward pure best-fit; larger items make us
    more willing to open fresh bins (since they can't be packed tightly anyway).
    """
    s = _state
    # Running estimate of mean item size and recent slack (remaining capacity left
    # after a best-fit placement, approximated by mean capacity minus item).
    s["sum"] += item
    s["count"] += 1
    mean_item = s["sum"] / s["count"]

    b = bins.astype(np.float64)
    n = b.shape[0]

    # Tightness score: prefer bins where the fit is tightest (best fit).
    tight = -(b - item)

    # Pressure: large items -> we should not cling to tightness; small items -> hug
    # tightness harder. Adaptivity via mean item size relative to capacity.
    pressure = mean_item / 100.0  # ~0.4 typical

    # Fresh-bin penalty: penalize using bins with a lot of remaining capacity.
    # Lambda grows as items get smaller (more room to pack tightly).
    lam = 1.0 - pressure  # in (0,1)
    fresh = b / 100.0

    return tight - lam * fresh
