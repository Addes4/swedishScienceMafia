# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a graded closing bonus.

Primary rule: best fit (smallest post-placement residual among feasible bins).
A large bonus is added when the placement closes the bin (residual below the
smallest item size observed so far). Among open bins, a small graded bonus
rewards residuals that are close to the closing threshold, so we keep the fit
tight instead of leaving wide-open bins.
"""
import numpy as np

CAP = 100

# Smallest item size observed so far (used to detect effective bin closing).
_min_item = CAP + 1


def priority(item, bins):
    global _min_item

    if item < _min_item:
        _min_item = item

    b = np.asarray(bins, dtype=np.float64)
    residual = b - item
    residual = np.maximum(residual, 0.0)

    # Best fit: prefer the smallest residual.
    score = -residual

    if _min_item <= CAP:
        # Large bonus for closing the bin.
        close = residual < _min_item
        score += 1000.0 * close

        # Graded bonus: among open bins, prefer residuals nearer the closing
        # threshold (tighter fits fill up sooner).
        openness = np.log1p(residual - _min_item + 1.0)
        score -= 1e-2 * openness

    return score
# EVOLVE-BLOCK-END
