# EVOLVE-BLOCK-START
"""Adaptive best-fit: tightness minus a penalty for choosing slack/fresh bins.

The penalty strength lambda adapts to a running estimate of item-size pressure.
Large items (high mean, high variability) -> stronger best-fit (low penalty).
Small/loose items -> stronger reluctance to open fresh bins (high penalty on slack).
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 0.0   # running mean item size
        self.m2 = 0.0     # running variance accumulator
        self.recent_sum = 0.0
        self.recent_cnt = 0
        self.recent = []  # sliding window
        self.window = 200

    def update(self, item):
        self.n += 1
        delta = item - self.mean
        self.mean += delta / self.n
        self.m2 += delta * (item - self.mean)
        self.recent.append(item)
        if len(self.recent) > self.window:
            self.recent.pop(0)

    def pressure(self):
        # proxy for slack/pressure: mean size scaled, plus variability
        if self.n < 5:
            return 0.0
        var = self.m2 / max(1, self.n - 1)
        std = var ** 0.5
        m = self.mean
        # normalize: item mean ~40, std ~ ? scale pressure into roughly [0,1]
        p = (m / 100.0) + 0.5 * (std / 100.0)
        return p


_state = _State()


def priority(item, bins):
    """Score = -(remaining - item) - lam * remaining  (best-fit + slack penalty)."""
    # update state with this item (counts toward pressure estimate)
    _state.update(item)

    p = _state.pressure()
    # lam: stronger penalty (reluctance to open bins) when pressure is LOW.
    # at p=0 lam ~ 0.5; at p=0.6 lam ~ 0.0
    lam = 0.5 * (1.0 - min(1.0, p / 0.6))

    rem = bins.astype(np.float64)
    tightness = -(rem - item)          # smaller leftover -> higher score (best fit)
    slack_pen = -lam * rem             # penalize high-remaining (fresh) bins
    return tightness + slack_pen
# EVOLVE-BLOCK-END
