# EVOLVE-BLOCK-START
"""Distribution-aware residual-value bin rule.

Idea: a bin's leftover capacity is only useful if future items can fill it
exactly. We keep a running histogram of item sizes and, for each candidate bin,
estimate the "coverage value" of the post-placement residual r: the expected
number of future items that can be packed into r (a renewal-style estimate).
Unlike plain best-fit, this prefers bins whose leftover space is a good fit for
the empirical size distribution rather than merely the smallest residual.
"""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "count": 0.0,
    "mean": 40.0,
    "alpha": 0.03,
}

# Precomputed sizes vector (static).
_SIZES = np.arange(101, dtype=np.float64)


def priority(item, bins):
    st = _state
    hist = st["hist"]

    # Update running statistics with the arriving item.
    st["mean"] = (1.0 - st["alpha"]) * st["mean"] + st["alpha"] * float(item)
    hist[item] += 1.0
    st["count"] += 1.0

    bins_f = bins.astype(np.float64)
    residual = bins_f - float(item)

    total = hist.sum()
    mean = st["mean"]
    if mean < 1e-6:
        mean = 40.0

    # --- Coverage value of residual: expected future items packable. ---
    # Base: simple mean-based count.
    base = residual / mean

    # Distribution-aware correction: reward residuals that are "composable"
    # from common item sizes. We use the running distribution to compute, for
    # each residual r, the probability mass of sizes <= r (can fit one more
    # item) and a fine-grained reward when r is near a frequent size (clean fit).
    if total > 0.0:
        cum = np.cumsum(hist) / total
        P_fit = cum[np.clip(residual.astype(np.int64), 0, 100)]
    else:
        P_fit = np.zeros_like(residual)

    coverage = base * (0.7 + 0.6 * P_fit)

    # Best-fit core: prefer smaller residual.
    tight = -residual

    # Reward near-exact fits (residual close to a common item size) so the
    # leftover is likely to be consumed later rather than stranded as a sliver.
    # Slight positive weight; not dominant.
    score = tight + 0.35 * coverage

    # Strongly prefer residuals that are exactly zero (perfect fill).
    score += 10.0 * (residual < 1e-9)

    return score
# EVOLVE-BLOCK-END
