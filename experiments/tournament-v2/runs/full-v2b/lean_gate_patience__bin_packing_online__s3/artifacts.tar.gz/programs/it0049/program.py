# EVOLVE-BLOCK-START
"""Best-fit with a frequency-weighted residual-matching tie-break from a running histogram."""
import numpy as np

_SIZE = 101
_HIST = np.ones(_SIZE, dtype=np.float64)
_DECAY = 0.99


def priority(item, bins):
    global _HIST
    # decayed running histogram of past item sizes (recency-weighted)
    _HIST *= _DECAY
    _HIST[item] += 1.0
    hist = _HIST / _HIST.sum()

    residual = bins - item  # remaining capacity after placing (>=0 for fitting bins)

    # Primary: best-fit -> prefer smallest residual (tightest packing).
    # Secondary: reward residuals that exactly equal a frequent item size,
    # so that leftover fragment can later be filled perfectly.
    match = hist[np.clip(residual, 0, 100)]
    # Bonus scale kept small relative to the best-fit gap between bins so it
    # acts as a tie-breaker and never dominates the tightness ordering.
    score = -residual.astype(np.float64) + 2.0 * match
    return score
# EVOLVE-BLOCK-END
