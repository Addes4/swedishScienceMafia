# EVOLVE-BLOCK-START
"""Online bin selection via expected future fill (DP on residual capacity)."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.ones(101, dtype=np.float64)
        self.count = 101.0
        # precomputed fill value cache keyed by residual r
        self._cache = {}

    def update(self, item):
        self.hist[item] += 1.0
        self.count += 1.0

    def probs(self):
        p = self.hist / self.count
        p[0] = 0.0
        return p


_S = _State()

# residual capacities range 0..100; compute fill value lazily per distribution.
def _fill_values(p):
    # expected number of items that fit into capacity r, using greedy fill model:
    # V[r] = sum_s p[s] * (1 + V[r-s]) for s <= r, averaged.
    # This is a value-iteration of expected items packed in residual r.
    V = np.zeros(101, dtype=np.float64)
    items = np.arange(1, 101)
    for r in range(1, 101):
        s = items[items <= r]
        ps = p[s]
        tot = ps.sum()
        if tot <= 0:
            V[r] = 0.0
            continue
        ps = ps / tot
        # one item then residual r-s (approximate independence)
        V[r] = 1.0 + float(np.dot(ps, V[r - s]))
    return V


def priority(item, bins):
    s = _S
    s.update(item)

    p = s.probs()

    # recompute fill values periodically (cheap: 100x100) -> do every call
    V = _fill_values(p)

    resid = bins - item  # nonnegative

    # value of residual after placing: V[resid]
    val = V[resid]

    # reward: better future fill, with mild tie-break toward tighter fits
    score = val - 1e-3 * resid.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
