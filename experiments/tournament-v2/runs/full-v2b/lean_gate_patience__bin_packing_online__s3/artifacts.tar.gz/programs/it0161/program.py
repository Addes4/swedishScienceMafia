# EVOLVE-BLOCK-START
"""Best-fit with an adaptive "closing" bonus.

Rank bins by smallest post-placement residual (best-fit), but give a decisive
bonus to bins whose residual has become too small to hold any future item
(residual < smallest item size seen so far). Such bins are effectively "closed"
and represent zero wasted capacity, which is exactly what we want to maximize.
The bonus is scaled to dominate the residual term so that closing a bin always
beats leaving a usable residual.
"""
import numpy as np

_CAP = 100

_STATE = {
    "min_seen": _CAP,   # smallest item size observed so far
}


def priority(item, bins):
    # track smallest item seen so far
    if item < _STATE["min_seen"]:
        _STATE["min_seen"] = item
    min_seen = _STATE["min_seen"]

    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    resid = bins - item
    np.clip(resid, 0.0, None, out=resid)

    # best-fit: prefer smallest residual (scaled into [0, 1))
    # residual ranges 0..100; divide to keep it well below the closing bonus.
    fit = -resid / 1000.0

    # closing bonus: residual too small for any future item -> bin is full.
    # Use threshold = min_seen (any future item is >= min_seen).
    closed = (resid < min_seen).astype(np.float64)

    # exact fill gets an extra nudge (residual == 0)
    exact = (resid < 0.5).astype(np.float64)

    score = fit + 2.0 * closed + 0.5 * exact
    return score
# EVOLVE-BLOCK-END

