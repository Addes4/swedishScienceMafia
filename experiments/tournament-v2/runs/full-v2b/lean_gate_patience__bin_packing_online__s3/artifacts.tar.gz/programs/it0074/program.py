# EVOLVE-BLOCK-START
"""Best-fit with an online-estimated large-item reserve bonus.

The base ordering is tight best fit (smallest post-placement residual wins).
On top of it we add a strong bonus for bins whose post-placement residual is
close to a running estimate of the "large item" size (a high quantile of the
item distribution).  If a bin's residual lands near a size that a future large
item can exactly use, we prefer it, which reduces the number of bins wasted on
fragmentation that can never be filled by the big items.
"""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0.0
        self.hist = np.zeros(101, dtype=np.float64)

    def observe(self, item):
        self.count += 1.0
        self.hist[item] += 1.0

    def large_size(self):
        # ~92nd percentile of item sizes seen so far (cached-ish, cheap enough)
        n = self.hist.sum()
        if n < 50.0:
            return 40.0
        cdf = np.cumsum(self.hist) / n
        idx = int(np.searchsorted(cdf, 0.92))
        if idx < 1:
            idx = 1
        if idx > 100:
            idx = 100
        return float(idx)


_state = _State()


def priority(item, bins):
    _state.observe(item)

    obj = np.asarray(bins, dtype=np.int64)
    rem = obj - item  # residual capacity after placing item

    big = _state.large_size()

    remf = rem.astype(np.float64)
    # base: tight best fit -> smaller residual is better
    base = -remf

    # bonus: reward residuals close to the large-item size (room for a big item)
    bonus = 1.0 / (1.0 + np.abs(remf - big))

    score = base * 1e3 + bonus * 1.0
    return score
# EVOLVE-BLOCK-END
