# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a graded closing bonus.

Primary rule: best fit (smallest post-placement residual among feasible bins).
A strong bonus is added when the placement closes the bin, i.e. the residual
becomes smaller than the smallest item size observed so far times a small
safety factor (so bins that can only hold the very smallest items are treated
as effectively closed, reducing fragmentation).
"""
import numpy as np

CAP = 100

# Smallest item size observed so far (used to detect effective bin closing).
_min_item = CAP + 1
# Safety factor: treat residual below factor * min_item as effectively closed.
_FACTOR = 1.0


def priority(item, bins):
    global _min_item

    if item < _min_item:
        _min_item = item

    b = np.asarray(bins, dtype=np.float64)
    residual = b - item
    residual = np.maximum(residual, 0.0)

    # Best-fit: prefer the smallest residual.
    score = -residual

    # Closing bonus: if residual can no longer hold any item seen so far
    # (up to the safety factor), strongly reward closing this bin.
    if _min_item <= CAP:
        thr = _FACTOR * _min_item
        close = residual < thr
        score += 1000.0 * close

    return score
# EVOLVE-BLOCK-END
