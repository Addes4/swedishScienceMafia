# EVOLVE-BLOCK-START
"""Histogram-based future-fillability bin packing."""
import numpy as np

# Running histogram of past item sizes (1..100)
_hist = np.zeros(101, dtype=np.float64)
_hist_count = 0.0

# EWMA of item sizes for adaptive pressure estimation
_ewma_size = 40.0
_ewma_alpha = 0.02

# Cache: expected number of items fillable from a given residual capacity
# Recomputed lazily when histogram changes significantly.
_fill_cache = None
_fill_cache_tag = -1.0


def _compute_fill_expectation():
    """Expected count of future items that can be packed into residual capacity r,
    estimated greedily using the running size histogram. Returns array indexed by r (0..100)."""
    global _fill_cache, _fill_cache_tag

    if _hist_count < 20:
        # Not enough data: fall back to a simple heuristic
        return None

    # Normalized probabilities over sizes 1..100
    probs = _hist[1:101] / _hist_count
    sizes = np.arange(1, 101, dtype=np.float64)

    # Expected size (mean of distribution)
    mean_size = float(np.dot(sizes, probs))
    if mean_size < 1.0:
        mean_size = 1.0

    # Expected value estimate: for residual r, expected number of items ~ r / mean_size,
    # but better: greedily simulate expected fill using the histogram.
    # For a quick proxy, use expected number of items weighted by probability that
    # an item fits, integrated over the greedy process. We approximate by:
    #   E[fill(r)] = sum over items expected to fit = r / mean_size (linear approx),
    # but we want *usefulness* meaning how likely the residual exactly gets refilled well.
    # Use a sublinear measure: a residual that can host ~1 item is best (tightness),
    # a residual that is tiny is wasted; a large residual is useful for future large items.
    # Score usefulness as expected number of items packable, but decaying for very large residuals.
    expected_items = r_arr / mean_size
    return expected_items


_fill_r = np.arange(101, dtype=np.float64)


def priority(item, bins):
    global _hist, _hist_count, _ewma_size, _fill_cache, _fill_cache_tag

    bins = np.asarray(bins, dtype=np.int64)
    n = bins.shape[0]

    # Update histogram with the arriving item (before scoring, so we use history)
    if 1 <= item <= 100:
        _hist[item] += 1.0
        _hist_count += 1.0
        _ewma_size = (1.0 - _ewma_alpha) * _ewma_size + _ewma_alpha * float(item)

    residual = bins - item  # residual capacity after placing item here

    # Fit tightness: prefer small residual (tight fit). Use negative residual.
    tightness = -residual.astype(np.float64)

    # Future-fillability: estimate expected number of future items the residual can hold,
    # using running histogram mean. Cache based on histogram count.
    tag = _hist_count
    if _fill_cache is None or abs(tag - _fill_cache_tag) > 30.0:
        probs = _hist[1:101] / _hist_count if _hist_count > 0 else np.full(100, 0.01)
        sizes = np.arange(1, 101, dtype=np.float64)
        mean_size = float(np.dot(sizes, probs))
        if mean_size < 1.0:
            mean_size = 1.0
        # Expected number of items packable into residual r (linear approximation)
        _fill_cache = _fill_r / mean_size
        _fill_cache_tag = tag

    fill_expect = _fill_cache[residual]  # expected items fillable from this residual

    # Score: tightness plus usefulness of the residual.
    # A bin whose residual can hold several future items is valuable; a bin that
    # wastes capacity (residual too small to hold typical items) is penalized.
    # Use usefulness = fill_expect, but reward residuals that are "just enough" for ~1 item.
    usefulness = np.minimum(fill_expect, 2.0)

    score = tightness + 3.0 * usefulness

    # Adaptive fresh-bin penalty: under high pressure (small mean size), penalize large residuals
    # less; under low pressure, prefer tight fits more.
    fresh_mask = residual >= 100 - item  # roughly fresh bins (residual ~ 100-item)
    pressure = float(item) / max(_ewma_size, 1.0)  # how big this item is vs recent average
    if pressure > 1.0:
        # Large item: prefer putting it in bins with residual that can hold it tightly
        score = tightness * (1.0 + 0.2 * (pressure - 1.0)) + 2.0 * usefulness

    return score
# EVOLVE-BLOCK-END
