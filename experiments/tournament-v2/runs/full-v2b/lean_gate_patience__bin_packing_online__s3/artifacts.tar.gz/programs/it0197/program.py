"""Best-Fit: place item into the fullest bin that still fits it."""
import numpy as np


def priority(item, bins):
    # bins holds remaining capacities of bins the item fits in.
    # Best-Fit: choose the smallest remaining capacity (tightest fit).
    # Score = -remaining capacity; tie goes to first bin.
    return -bins
