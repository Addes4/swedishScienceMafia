# EVOLVE-BLOCK-START
"""Best-fit packing with a running histogram used only as a tie-breaker."""
import numpy as np

_SIZE = 101
_HIST = np.ones(_SIZE, dtype=np.float64)
_DECAY = 0.995


def priority(item, bins):
    global _HIST
    # update running distribution of past item sizes (decayed histogram)
    _HIST *= _DECAY
    _HIST[item] += 1.0
    total = _HIST.sum()
    freq = _HIST / total  # empirical PMF over item sizes 0..100

    residual = bins - item  # remaining capacity after placing (>=0 for fitting bins)

    # Primary: strong best-fit preference for the smallest residual.
    score = -residual.astype(np.float64)

    # Secondary: tiny bonus when the residual exactly matches a commonly
    # observed item size, so the fragment can be consumed exactly later.
    freq_at_res = freq[np.clip(residual, 0, 100)]
    score += freq_at_res * 0.5

    return score
# EVOLVE-BLOCK-END
