# EVOLVE-BLOCK-START
"""Distribution-aware completion scoring.

For each candidate bin we compute the resulting residual capacity r = rem - item.
We then estimate how "usable" that residual is: using a running histogram of past
item sizes, we greedily simulate how many future items the residual could absorb
(assuming we keep applying best-fit into this residual). The bin whose residual
absorbs the most simulated items per unit capacity -- i.e. packs "densely" -- is
preferred. This naturally prefers tight fits (small residuals can only accept
small items, so they score low when the item is large) and open, flexible bins.
"""

import numpy as np

# ---- running history of past item sizes -----------------------------------
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_SEEN = 0


def _update_hist(item):
    global _TOTAL, _SEEN
    _HIST[item] += 1.0
    _TOTAL += 1.0
    _SEEN += 1


def _simulate_absorb(residual, max_steps=24):
    """Greedy: how many representative items fit into `residual` on average?

    We estimate expected packing density by repeatedly picking the largest
    typical item that fits, weighted by how common such sizes are.
    Returns a score: items absorbed + filled fraction.
    """
    if _TOTAL <= 0.0:
        # No history: fall back to pure best fit.
        return -float(residual)
    r = residual
    if r <= 0:
        return -1e9
    # Weighted "largest that fits" heuristic using empirical distribution.
    # Precompute cumulative-ish: for a residual r, expected next accepted size
    # is roughly the average of sizes <= r, weighted by frequency.
    absorbed = 0
    filled = 0.0
    for _ in range(max_steps):
        if r <= 0:
            break
        # mean of available sizes <= r weighted by histogram
        idx = np.arange(1, min(int(r), 100) + 1)
        if idx.size == 0:
            break
        w = _HIST[idx]
        tot_w = w.sum()
        if tot_w <= 0.0:
            # fall back: try to take a small representative piece
            take = min(r, 10)
        else:
            take = float((idx * w).sum() / tot_w)
            take = max(1.0, take)
        take = min(take, r)
        if take <= 0:
            break
        r -= take
        absorbed += 1
        filled += take
    # Score: absorbed count dominates, plus fraction filled (denser residual better).
    return absorbed + (filled / (filled + 1.0))


def priority(item, bins):
    _update_hist(int(item))

    bins = np.asarray(bins)
    n = bins.shape[0]
    res = bins - item  # resulting residual capacity for each candidate bin

    scores = np.empty(n, dtype=np.float64)
    for i in range(n):
        r = int(res[i])
        if r < 0:
            scores[i] = -1e12
            continue
        # Usability of resulting residual (how many future items it can hold).
        util = _simulate_absorb(r)
        # Slight preference for tighter fits to counter over-fragmentation.
        tightness = -0.02 * r
        scores[i] = util + tightness
    return scores
# EVOLVE-BLOCK-END
