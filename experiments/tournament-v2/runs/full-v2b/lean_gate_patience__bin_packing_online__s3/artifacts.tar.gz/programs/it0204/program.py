# EVOLVE-BLOCK-START
"""Classic Best-Fit: choose the bin leaving the smallest non-negative residual."""
import numpy as np


def priority(item, bins):
    """Score each bin by the negative residual after placing the item.

    The item goes to the bin with the highest score, i.e. the smallest
    remaining capacity that still fits (classic Best-Fit). Ties fall to the
    first bin, which matches the harness tie-breaking rule.
    """
    residual = bins - item
    # Prefer the smallest residual (tightest fit).
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

