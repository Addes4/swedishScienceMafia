# EVOLVE-BLOCK-START
"""Adaptive fresh-bin-resistant best fit with large-item protection.

Score for a bin with remaining capacity r when placing item of size s:
    score = -(r - s) - lam * (r / 100) + eps * usable

The first term is plain best-fit tightness (prefer smallest residual).
The second term penalizes high remaining capacity ("fresh" bins).
The third term breaks near-ties toward bins whose residual is at least the
running mean item size, so that a bin able to host a future average item is
preserved over one that can only absorb small leftovers.
"""
import numpy as np


def priority(item, bins):
    st = priority.__dict__
    if 'mean' not in st:
        st['mean'] = 40.0
        st['var'] = 200.0
        st['count'] = 0
        st['lam'] = 0.5

    m = st['mean']
    v = st['var']
    d = item - m
    st['mean'] = m + 0.05 * d
    st['var'] = (1.0 - 0.05) * (v + 0.05 * d * d)
    st['count'] += 1

    mean = st['mean']
    var = st['var']
    sd = var ** 0.5
    pressure = mean / 50.0
    vol = sd / 25.0

    lam = 0.8 / (1.0 + 1.5 * pressure + 0.5 * vol)
    lam = float(min(max(lam, 0.0), 1.2))
    st['lam'] = lam

    residual = bins - item
    base = -(residual.astype(np.float64)) - lam * (bins.astype(np.float64) / 100.0)

    # tiny tie-break: keep bins that can still host an average-sized item
    usable = (residual >= mean).astype(np.float64)
    return base + 1e-6 * usable
# EVOLVE-BLOCK-END

