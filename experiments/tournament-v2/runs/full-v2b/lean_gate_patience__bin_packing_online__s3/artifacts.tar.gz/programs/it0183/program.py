# EVOLVE-BLOCK-START
"""Online bin choice: best-fit with a closing bonus.

Primary rule: place the item into the bin with the smallest post-placement
residual (best fit) to keep bins tightly packed. Additionally, give a large
bonus to placements that "close" a bin, i.e. leave a residual smaller than the
smallest item size seen so far, since that bin can no longer accept any future
item and is effectively used up efficiently.
"""
import numpy as np

_SIZE_MAX = 100

# Smallest item size observed so far (init to a large value).
_min_item = _SIZE_MAX + 1


def priority(item, bins):
    global _min_item
    item = int(item)
    if item < _min_item:
        _min_item = item

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item

    # Best-fit: prefer the smallest non-negative residual.
    # Residuals < 0 mean the item doesn't fit; push those far down.
    score = -residual

    # Closing bonus: residual below smallest observed item => bin is closed.
    closed = (residual >= 0) & (residual < _min_item)
    score = score + closed * _SIZE_MAX

    # Ensure non-fitting bins are never chosen.
    fits = residual >= 0
    score = np.where(fits, score, -1e9)

    return score
# EVOLVE-BLOCK-END
