# EVOLVE-BLOCK-START
"""Adaptive best-fit with a phase-modulated fresh-bin penalty."""
import numpy as np

_state = {"sum": 0.0, "n": 0, "last": 40.0}


def priority(item, bins):
    """Score bins by tightness minus an adaptive penalty for unused space / fresh bins."""
    # Update running estimate of recent item size.
    s = _state
    s["sum"] += item
    s["n"] += 1
    recent = s["sum"] / s["n"]
    # Bounded influence of item size so estimate tracks drift but stays stable.
    if s["n"] > 50:
        s["sum"] *= 0.995
        s["n"] *= 0.995
    s["last"] = 0.9 * s["last"] + 0.1 * item

    # Phase: ratio of current item to recent typical size.
    # Large items (relative) -> favor tight fits strongly, penalize fresh bins.
    # Small items -> allow more bin-opening slack.
    ratio = item / max(recent, 1.0)

    # Fresh bins have bins == 100. Penalize using them when items are large.
    # Tightness score: leftover after placing = bins - item (smaller is better),
    # so score = -(bins - item) = item - bins. Add penalty for fresh bins.
    leftover = bins - item
    score = -leftover.astype(np.float64)

    # Penalty grows when current item is large relative to recent average.
    fresh = (bins >= 100)
    penalty = 0.5 * (1.0 + ratio)
    score = score - fresh * penalty

    # Small additional preference for fuller bins (smaller remaining capacity)
    # proportional to how tight the situation is.
    score = score - (1.0 / (1.0 + ratio)) * (bins.astype(np.float64) / 100.0)

    return score
# EVOLVE-BLOCK-END
