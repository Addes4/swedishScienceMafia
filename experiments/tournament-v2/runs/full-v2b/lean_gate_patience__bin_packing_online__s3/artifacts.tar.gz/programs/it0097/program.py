# EVOLVE-BLOCK-START
"""Adaptive residual-aware bin-choice rule.

Score each bin primarily by the post-placement residual (best fit), with a small
adaptive penalty against placing items into nearly-empty ("fresh") bins when the
recent item-size pressure is low. The penalty is kept small so the rule stays
close to classic best fit, which is a strong online packing rule.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.var = 600.0
        self.alpha = 0.03


_state = _State()


def _observe(item):
    s = _state
    s.n += 1
    d = item - s.mean
    s.mean += s.alpha * d
    s.var += s.alpha * (d * d - s.var)


def priority(item, bins):
    _observe(item)

    s = _state
    mean = s.mean
    var = s.var

    pressure = mean / 100.0
    spread = (var ** 0.5) / 100.0

    # Small fresh-bin resistance: strongest under low pressure, weakest under high pressure.
    lam = 0.20 * (1.0 - pressure) ** 2 / (1.0 + spread)
    if lam < 0.0:
        lam = 0.0
    elif lam > 0.12:
        lam = 0.12

    residual = bins - item  # >= 0 for all shown bins

    rm = mean if mean > 1.0 else 1.0
    utility = residual / (rm + residual)

    score = -residual.astype(np.float64) + 100.0 * lam * utility
    return score
# EVOLVE-BLOCK-END
