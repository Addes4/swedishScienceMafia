# EVOLVE-BLOCK-START
"""Online bin packing: Best-Fit with a mild anti-fragmentation bias.

Classic Best-Fit (tightest post-placement residual) is very strong on
Weibull-shaped sizes.  We keep it as the dominant term but add a tiny
secondary term that prefers heavier bins (smaller pre-placement remaining
capacity) when post-placement residuals are nearly equal.  The weight is
small enough that it only affects genuine near-ties, preserving best-fit
behavior while slightly consolidating load.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item          # post-placement free space
    # primary: tightest fit (smallest residual -> highest score)
    # secondary: prefer fuller bins (smaller current remaining capacity)
    return -(residual + 0.01 * (bins - item))
# EVOLVE-BLOCK-END

