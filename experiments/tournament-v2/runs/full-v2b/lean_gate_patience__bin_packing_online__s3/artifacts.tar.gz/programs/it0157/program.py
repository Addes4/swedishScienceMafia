# EVOLVE-BLOCK-START
"""Best-fit with a fine-grained preference for near-perfect fills."""
import numpy as np


class _State:
    def __init__(self):
        self.min_item = 101  # smallest item seen so far

    def observe(self, item):
        if item < self.min_item:
            self.min_item = item


_state = _State()


def priority(item, bins):
    """Best-fit primary; strongly favor residuals too small to be reused."""
    _state.observe(item)

    residual = bins - item  # int64 array, all >= 0 since bin fits item

    # Primary: smaller residual is better (best-fit).
    score = -residual.astype(np.float64)

    # Bonus for residuals that cannot hold even the smallest future item,
    # scaled so it never overturns the primary ordering.
    min_item = _state.min_item
    if min_item > 1:
        dead = residual < min_item
        score += dead * 0.5

    return score
# EVOLVE-BLOCK-END
