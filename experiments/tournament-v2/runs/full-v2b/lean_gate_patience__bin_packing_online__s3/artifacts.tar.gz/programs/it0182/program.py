# EVOLVE-BLOCK-START
"""Online stochastic 'future fillability' bin-choice rule.

Idea: track a running histogram of observed item sizes. For each candidate bin,
estimate how many future items can be packed into the bin's residual capacity
after placing the arriving item. Bins whose residual can absorb many "typical"
future items are more valuable to keep fillable; bins whose residual is a poor
match to the size distribution should be used up instead. Combine this expected
fillability with a classic best-fit tightness term.
"""
import numpy as np

_SIZE_MAX = 100

# Running histogram of observed item sizes, index 1..100 (0 unused).
_hist = np.zeros(_SIZE_MAX + 1, dtype=np.float64)
_count = 0
# Sorted distinct sizes seen so far, for fast greedy fill estimation.
_sizes_sorted = None
_cache_ready = False

# Expected item size estimate; refreshed lazily.
_mean_size = 40.0
_total_size_seen = 0.0


def _update_stats(item):
    global _count, _total_size_seen, _mean_size, _cache_ready
    _hist[item] += 1.0
    _count += 1
    _total_size_seen += item
    if _count > 0:
        _mean_size = _total_size_seen / _count
    # Rebuild sorted distinct sizes occasionally.
    if _count <= 64 or (_count % 64 == 0):
        nz = np.nonzero(_hist)[0]
        if len(nz) > 0:
            # Ascending sizes with frequencies.
            _counts = _hist[nz]
            _sizes_sorted = nz.astype(np.float64)
            _freqs = _counts.astype(np.float64)
            # Store probs and sizes in module tuple.
            global _probs_sorted
            _probs_sorted = _freqs / _freqs.sum()
        _cache_ready = True


_probs_sorted = None


def _greedy_fill(residual):
    """Estimate expected number of future items packable into `residual`.

    Uses the empirical size distribution: repeatedly take the smallest
    available size that fits, but weight by expected size. We approximate
    with mean-size division plus a correction based on the smallest size.
    """
    if residual <= 0:
        return 0.0
    if _sizes_sorted is None or _probs_sorted is None or _count < 8:
        # Fall back to mean-based estimate.
        if _mean_size <= 0:
            return 0.0
        return residual / _mean_size

    smallest = _sizes_sorted[0]
    # Greedy: fill residual with the most efficient (smallest) items that fit.
    # Expected count: use empirical distribution truncated at residual.
    # Continuous-ish estimate: sum over sizes s <= residual of prob(s) * (count contribution).
    # Simple robust estimator: residual / mean_size, plus a bonus when residual
    # is a good multiple of the smallest typical size.
    est = residual / _mean_size
    if smallest > 0:
        fit_small = residual / smallest
        # Blend toward the small-item bound when residual is small.
        if residual < 2.0 * _mean_size:
            est = max(est, 0.5 * fit_small)
    return est


def priority(item, bins):
    """Return a score per bin; item goes to the highest (first on ties)."""
    _update_stats(int(item))
    bins = np.asarray(bins, dtype=np.float64)

    # Residuals after placing this item.
    residual = bins - float(item)

    # Expected future fillability of each residual.
    # Vectorized greedy estimate: residual / mean_size with small-item blend.
    if _mean_size <= 0:
        fill = np.zeros_like(residual)
    else:
        fill = residual / _mean_size

    if _sizes_sorted is not None and len(_sizes_sorted) > 0:
        smallest = _sizes_sorted[0]
        if smallest > 0:
            fit_small = residual / smallest
            small_mask = residual < 2.0 * _mean_size
            blend = np.where(small_mask, np.maximum(fill, 0.5 * fit_small), fill)
            fill = np.where(residual > 0, blend, fill)
    fill = np.where(residual > 0, fill, 0.0)

    # Fit tightness: prefer placing into tighter bins (smaller residual),
    # but this is balanced against keeping fillable residuals.
    tightness = -residual / _SIZE_MAX  # higher (less negative) for tight fit

    # Combine: weight fillability as the primary objective, tightness as tie-break.
    score = fill + 0.3 * tightness
    return score
# EVOLVE-BLOCK-END
