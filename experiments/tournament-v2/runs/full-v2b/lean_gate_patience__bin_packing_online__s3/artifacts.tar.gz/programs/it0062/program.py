# EVOLVE-BLOCK-START
"""Best-fit with a light reservation-aware tie-break.

Primary rule: classic Best-Fit (smallest post-placement residual).
Secondary rule (only for near-ties in residual): prefer leaving a residual that
matches a frequently-seen item size, so those residuals can be filled exactly
later. This is the classic "Best-Fit with reservation" refinement.
"""
import numpy as np


class _State:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)  # past item-size histogram
        self.total = 0.0


_state = _State()


def priority(item, bins):
    s = _state

    # Post-placement residual for every bin.
    resid = bins - item                      # >= 0 for all shown bins

    # Best-Fit primary term: smaller residual => higher score.
    base = -resid

    # Reservation bonus: reward residuals that equal a common past item size.
    freq = s.counts
    tot = s.total
    if tot > 0:
        # normalized frequency of each residual value (0..100)
        idx = np.clip(resid.astype(np.int64), 0, 100)
        pop = freq[idx] / tot                # in [0,1]
        # scale down so it only breaks ties among essentially equal residuals
        bonus = 1e-3 * pop
    else:
        bonus = 0.0

    score = base + bonus

    # Record the arriving item for future frequency estimates.
    s.counts[item] += 1.0
    s.total += 1.0

    return score
# EVOLVE-BLOCK-END
