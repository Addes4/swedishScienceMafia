import numpy as np

_state = {
    "count": 0.0,
    "mean": 40.0,
    "min_item": 101,
}


def priority(item, bins):
    st = _state
    st["count"] += 1.0
    c = st["count"]
    st["mean"] = st["mean"] + (item - st["mean"]) / c
    if item < st["min_item"]:
        st["min_item"] = item

    resid = bins.astype(np.float64) - item  # residual after placement
    # Clip negatives (shouldn't happen; harness only gives fitting bins)
    resid = np.clip(resid, 0.0, 100.0)

    # Best-fit: strongly prefer the smallest residual.
    # Give a bonus to perfectly-filled bins (residual 0) and to bins whose
    # residual is at least a small typical size (>= min_item), so we don't
    # waste near-closed bins that can't be refilled.
    score = -resid

    # Slight preference for exact fills.
    score = np.where(resid == 0.0, score + 1.0, score)

    # Penalize tiny residuals that are below the smallest item seen so far,
    # since those bins become effectively unusable waste: better to fully
    # close them (residual 0) than leave a small unusable sliver.
    sliver = (resid > 0.0) & (resid < st["min_item"])
    score = np.where(sliver, score - 0.5, score)

    return score
