# EVOLVE-BLOCK-START
"""Distribution-aware complement best-fit bin choice.

Prefer the bin that leaves the smallest usable residual (best fit), but add a bonus
when that residual equals a size that occurs frequently in the recent item stream
(a decaying histogram). This nudges bins toward residuals that a likely future item
can fill exactly, reducing dead space, while keeping the strong locality of best fit.
"""
import numpy as np

_SIZE = 100


class _Model:
    def __init__(self, decay=0.99):
        self.h = np.zeros(_SIZE + 1, dtype=np.float64)
        self.decay = decay
        self._n = 0

    def observe(self, item):
        self.h *= self.decay
        self.h[item] += 1.0
        self._n += 1

    def probs(self):
        p = self.h[1:].copy()
        s = p.sum()
        if s <= 0:
            return np.full(_SIZE, 1.0 / _SIZE, dtype=np.float64)
        return p / s


_model = _Model()


def priority(item, bins):
    _model.observe(item)
    probs = _model.probs()
    sizes = np.arange(1, _SIZE + 1, dtype=np.float64)
    mean = float(np.dot(probs, sizes))
    if mean <= 1e-9:
        mean = 1.0

    res = bins.astype(np.float64) - float(item)

    # core: best-fit tightness (prefer small residual), scaled by mean size
    score = -res / mean

    # complement bonus: residual matching a high-probability future item size
    idx = np.clip(res.astype(np.int64), 0, _SIZE)
    # probability of the exact residual size as a future item
    p_exact = probs[idx - 1]
    # only reward positive residuals (a fully used bin is already ideal)
    bonus = np.where(res > 0, p_exact, 0.0)
    score += 0.5 * bonus

    return score
# EVOLVE-BLOCK-END
