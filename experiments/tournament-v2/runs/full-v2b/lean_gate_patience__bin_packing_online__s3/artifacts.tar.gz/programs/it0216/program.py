# EVOLVE-BLOCK-START
"""Best-Fit with a refillable-bin tie bonus.

Primary order: smallest post-placement residual (classic Best-Fit).
Secondary nudge: when that residual is still comfortably refillable
(residual >= a typical item size), prefer the currently fuller bin,
so heavy bins tend to stay in play instead of being abandoned.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # classic best-fit ordering
    score = -residual.astype(np.float64)
    # when residual remains large enough to hold a typical item,
    # give a small bonus to bins that are currently more loaded.
    refillable = residual >= 40
    load = (100 - bins).astype(np.float64)
    score = score + np.where(refillable, load * 0.01, 0.0)
    return score
# EVOLVE-BLOCK-END
