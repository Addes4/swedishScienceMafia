# EVOLVE-BLOCK-START
"""Best-fit with residual-fillability bias.

Idea: plain best-fit minimizes leftover residual, but not all residuals are
equally useful.  A residual r is "good" if some incoming item size is likely to
equal r (so the bin can be closed exactly).  We keep an online histogram of
observed item sizes (a smoothed estimate of the distribution) and give a bonus
to bins whose post-placement residual has high estimated arrival probability.
Fresh bins (remaining 100) get a slight penalty so we only open them when the
fit quality is comparable.
"""
import numpy as np

NBINS = 101  # residual 0..100


def priority(item, bins):
    st = priority.__dict__
    if 'hist' not in st:
        # smoothed histogram over sizes 1..100, initialized uniform-ish
        st['hist'] = np.ones(NBINS, dtype=np.float64) * 0.5
        st['total'] = 0.0

    hist = st['hist']

    # score every bin
    bins_f = bins.astype(np.float64)
    residual = bins_f - item  # >= 0 for fitting bins

    # estimated probability of an item equal to each residual (normalized)
    counts = hist
    norm = counts.sum()
    probs = counts / norm if norm > 0 else counts

    ridx = residual.astype(np.int64)
    ridx = np.clip(ridx, 0, NBINS - 1)

    # bonus proportional to probability that residual gets exactly filled
    bonus = probs[ridx]

    # base: prefer small residual (best fit)
    score = -residual * 0.05

    # residual fillability bonus (scaled)
    score += bonus * 0.3

    # slight penalty for fresh bins (remaining 100) to discourage opening
    score -= (bins_f == 100.0) * 0.02

    # update histogram AFTER scoring (uses only past items)
    if item >= 1:
        hist[item] += 1.0
    st['total'] += 1.0

    return score
# EVOLVE-BLOCK-END
