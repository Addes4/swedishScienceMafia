# EVOLVE-BLOCK-START
"""
Adaptive best-fit with empirical residual matching.

We keep a running estimate of the item size distribution and prefer placements
whose resulting residual capacity is close to the size of a typical upcoming
item (so the leftover is likely to be reused).  This generalizes best-fit: the
tightest fit is best only when leftovers are likely to be filled by future items.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.hist = np.zeros(101, dtype=np.float64)  # smoothed size histogram
        self.fresh = np.zeros(101, dtype=np.float64)

    def observe_item(self, item):
        self.n += 1
        alpha = 0.02 if self.n > 200 else 0.15
        if self.n == 1:
            self.mean = float(item)
        else:
            self.mean = (1.0 - alpha) * self.mean + alpha * float(item)
        self.hist *= (1.0 - alpha)
        self.hist[item] += alpha


_state = _State()


def priority(item, bins):
    item = int(item)
    st = _state
    st.observe_item(item)

    b = np.asarray(bins, dtype=np.float64)
    size = b.size
    if size == 0:
        return np.zeros(0, dtype=np.float64)

    residual = b - float(item)

    # Base score: best fit (prefer small residual).
    base = -residual

    # Bonus if residual is likely to be fillable by a future item: weight by
    # empirical probability of a future item size being close to residual.
    w = np.zeros(101, dtype=np.float64)
    m = st.mean
    # Gaussian-ish kernel around residual to reward "matchable" leftovers,
    # peaked so that residual near typical item sizes scores higher.
    sd = max(5.0, 0.35 * m)
    idx = np.clip(np.round(residual).astype(np.int64), 0, 100)
    match_bonus = np.exp(-0.5 * ((idx - m) / sd) ** 2)
    # Exact-fill bonus (residual == 0 wastes nothing).
    exact = (residual <= 0.5).astype(np.float64)

    score = base + 2.0 * match_bonus + 1.5 * exact

    # Penalize opening brand-new bins slightly (they have residual 100).
    fresh_penalty = 0.5 + 0.7 * (m / 100.0)
    fresh_mask = (b >= 100).astype(np.float64)
    score -= fresh_penalty * fresh_mask

    # Small bonus for used bins to concentrate packing.
    used_mask = (b < 100).astype(np.float64)
    score += 0.05 * used_mask

    fit = b >= item
    if not np.all(fit):
        score = np.where(fit, score, -1e9)

    return score


# EVOLVE-BLOCK-END
