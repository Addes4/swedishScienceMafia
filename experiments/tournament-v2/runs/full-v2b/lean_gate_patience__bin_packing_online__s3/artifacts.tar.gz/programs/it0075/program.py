# EVOLVE-BLOCK-START
"""Fractional best-fit with online mean-adaptive tie-breaking.

The score combines two signals:
  1. Primary: minimize post-placement residual (classic best fit) so items
     pack tightly into already-opened bins.
  2. Secondary: among bins with similar residuals, prefer the one whose
     residual after placement is closest to a multiple of the running mean
     item size, so leftover space stays usable for typical items.
The tie-break is scaled small enough not to disturb the primary ordering.
"""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0
        self.count = 0.0

    def observe(self, item):
        self.count += 1.0
        a = 1.0 / min(self.count, 200.0)
        self.mean += a * (item - self.mean)


_state = _State()


def priority(item, bins):
    obj = np.asarray(bins, dtype=np.int64)
    _state.observe(item)

    rem = (obj - item).astype(np.float64)
    # primary: tighter (smaller) residual is better
    primary = -rem

    # secondary: reward residuals that are "clean" wrt the running mean size,
    # i.e. residual is close to an integer multiple of mean (usable space).
    m = max(_state.mean, 1.0)
    frac = rem / m
    dist_to_int = np.abs(frac - np.round(frac))
    secondary = -dist_to_int

    return primary * 1000.0 + secondary
# EVOLVE-BLOCK-END
