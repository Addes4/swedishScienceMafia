# EVOLVE-BLOCK-START
"""Adaptive fresh-bin-resistant best fit.

Score = -(residual) - lam * (residual / 100)

where residual = bins - item after placing the item, and lam grows with the
running EWMA estimate of recent item-size pressure.  Under high average item
size we add a penalty on large residual capacities (i.e. on fresh / nearly
empty bins), nudging the packer toward using existing open bins whose residual
is comparable to typical item sizes, reserving empty bins for future large
items.  Under low pressure lam -> 0 and the rule reduces to plain best fit.
"""
import numpy as np

# Running EWMA of item sizes (pressure estimate), updated every call.
_ewma = [40.0]
_count = [0]


def priority(item, bins):
    # Update running estimate of item-size pressure.
    a = 0.05  # EWMA smoothing factor
    _ewma[0] = (1.0 - a) * _ewma[0] + a * item
    _count[0] += 1

    # Pressure normalized to [0, 1] against capacity 100.
    pressure = _ewma[0] / 100.0

    # Resistance strength: small at low pressure, larger at high pressure.
    lam = 25.0 * pressure * pressure

    residual = bins - item  # remaining capacity if item is placed here
    # Best fit: prefer the smallest residual.  Penalize large residual
    # (fresh/near-empty bins) with strength lam so their space is saved.
    return -(residual + lam * (residual / 100.0))
# EVOLVE-BLOCK-END
