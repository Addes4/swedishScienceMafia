# EVOLVE-BLOCK-START
"""Adaptive best-fit with exact-fit reward.

Classic best-fit (minimize post-placement residual) is very strong for this
distribution. The remaining waste comes from leaving small "slivers" that no
future item can fill exactly and from opening fresh bins too readily. We keep
best-fit as the backbone and add two small corrections:

  * a reward when the post-placement residual equals a size that we have seen
    often enough to expect again (so the bin can be closed exactly),
  * a mild penalty on high residuals (fresh bins) proportional to the current
    estimate of mean item size.

Both corrections are scaled well below the residual term so they only act as
tie-breakers / near-tie nudges and never override tight-fit behaviour.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        # coarse histogram over residual values 0..100
        self.hist = np.zeros(101, dtype=np.float64)
        self.decay = 0.995
        self._init_hist()


def _init_hist():
    # prior shaped like the Weibull-ish item distribution (mean ~40)
    x = np.arange(101, dtype=np.float64)
    h = (x / 45.0) ** 1.2 * np.exp(-(x / 45.0) ** 1.5)
    h[0] = 0.0
    s = h.sum()
    if s > 0:
        h /= s
    _state.hist = h


_state = _State()


def _observe(item):
    s = _state
    s.n += 1
    s.mean += 0.03 * (item - s.mean)
    s.hist *= s.decay
    s.hist[item] += 1.0 - s.decay


def priority(item, bins):
    _observe(item)

    s = _state
    residual = bins - item  # >= 0

    # Exact-fit reward: probability mass of the residual value in the histogram
    prob = s.hist[np.clip(residual, 0, 100)]
    prob = prob / (s.hist.max() + 1e-12)

    # Fresh-bin resistance proportional to mean item size (so larger residuals
    # are slightly less attractive), tiny weight.
    fresh = residual / 100.0

    w_exact = 6.0
    w_fresh = 4.0

    score = -residual.astype(np.float64) + w_exact * prob - w_fresh * fresh
    return score
# EVOLVE-BLOCK-END
