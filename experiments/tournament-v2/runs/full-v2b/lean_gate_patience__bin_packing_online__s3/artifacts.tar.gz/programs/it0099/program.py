# EVOLVE-BLOCK-START
"""Online bin-choice rule: decrease in the sum of squared residuals.

Placing `item` into a bin with remaining capacity `b` changes the sum of
squared residuals by (b - item)^2 - b^2 = item^2 - 2*item*b. Since item is
fixed across bins, ranking by this quantity is equivalent to maximizing
b^2 - (b - item)^2, i.e. preferring bins whose current residual is small
relative to the item (tight fit) while still accounting for the squared
scale of the residual. This "sum of squares" (a.k.a. matching/opportunity
cost) criterion is a well-known strong online packing rule and is
parameter-free.
"""
import numpy as np


def priority(item, bins):
    b = bins.astype(np.float64)
    # Decrease in sum of squared residuals; item^2 is constant so omit it.
    score = -2.0 * item * b
    return score
# EVOLVE-BLOCK-END
