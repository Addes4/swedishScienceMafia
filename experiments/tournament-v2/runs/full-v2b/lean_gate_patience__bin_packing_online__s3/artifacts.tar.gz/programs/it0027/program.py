"""Best-fit with waste-consolidation tie-break."""
import numpy as np

_state = {"sum": 0.0, "count": 0, "min_item": 100}


def priority(item, bins):
    """Rank bins: Best-Fit core, with a tie-break that consolidates small waste.

    Best-Fit (maximize item - residual, i.e. minimize post-placement residual) is
    the dominant signal.  Bins whose post-placement residual is too small to ever
    accept another item (below the smallest item seen so far) are effectively
    dead zones; among near-tied such bins we favor the one leaving the *largest*
    dead residual, so unavoidable waste is concentrated instead of scattered.
    """
    s = _state
    if item < s["min_item"]:
        s["min_item"] = item
    min_item = s["min_item"]

    b = bins.astype(np.float64)
    residual = b - item  # remaining capacity if we place here

    # Dominant signal: tightest fit.
    tight = -residual

    # Dead-residual flag: residual < min_item is unusable space.
    dead = residual < min_item  # boolean

    # For dead placements we add a mild preference for larger (consolidated) waste.
    # Normalize by capacity so the term is small compared to the tightness signal.
    waste_pref = np.where(dead, residual, -1000.0) / 100.0

    return tight + 0.05 * waste_pref
