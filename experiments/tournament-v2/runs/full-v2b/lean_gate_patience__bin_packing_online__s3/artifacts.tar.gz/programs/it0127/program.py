import numpy as np


class _State:
    def __init__(self):
        # Running histogram of past item sizes (1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0
        # EWMA of recent item sizes (pressure proxy)
        self.ewma = 40.0
        self.alpha = 0.02
        # EWMA of item size squared-ish (variance proxy) for binomial-ish fill estimate
        self.ewma_sq = 1600.0

    def observe(self, item):
        self.hist[item] += 1.0
        self.count += 1.0
        self.ewma = (1.0 - self.alpha) * self.ewma + self.alpha * item
        self.ewma_sq = (1.0 - self.alpha) * self.ewma_sq + self.alpha * item * item


_state = _State()


def _fillability(residual, hist, count):
    """Estimate expected number of future items that could fit into a residual capacity.

    Uses the running histogram: sum over sizes s<=residual of
    (residual // s) * p(s), but weighted by probability and capped, to reward
    residuals that match frequent small/medium sizes well.
    """
    if residual <= 0:
        return -1000.0
    # Probability distribution over sizes 1..100
    if count > 0:
        p = hist / count
    else:
        p = None
    r = int(residual)
    if r > 100:
        r = 100
    # expected number of items of each size s that fit in residual, times how
    # "useful" that size is (weighted by 1/size so larger fills count more).
    if p is not None:
        sizes = np.arange(1, r + 1)
        fit_counts = (int(residual) // sizes).astype(np.float64)
        # Weight each potential item by its size (waste reduction value)
        value = np.sum(fit_counts * p[1:r + 1] * sizes) / (residual + 1.0)
    else:
        value = 0.0
    # Reward residuals close to multiples that can be packed densely; penalize
    # near-empty residuals slightly (they may stay wasted).
    return value


def priority(item, bins):
    if _state.count > 0:
        hist = _state.hist
        count = _state.count
    else:
        hist = _state.hist
        count = 0.0

    residual = bins - item  # remaining capacity after placing item (>=0 since bins are valid)
    residual = residual.astype(np.float64)

    # Tightness: prefer small residual (tight fit)
    tight = -residual

    # Fresh-bin penalty: penalize large residuals (bins that look empty/fresh),
    # with strength adapting to recent item pressure (larger items -> less penalty
    # so we reserve big bins for big items; smaller items -> more spread is fine).
    pressure = _state.ewma  # ~ mean item size
    std_proxy = np.sqrt(max(_state.ewma_sq - pressure * pressure, 1.0))
    # Penalize residual near a full fresh bin (100 - item) proportionally.
    fresh_pen = -0.08 * (residual / 100.0) * (40.0 / (pressure + 1.0))

    # Fillability: reward residuals that can be refilled well by future items.
    fill = np.array(
        [_fillability(r, hist, count) for r in residual],
        dtype=np.float64,
    )

    score = tight + fresh_pen + 1.5 * fill

    _state.observe(item)
    return score
