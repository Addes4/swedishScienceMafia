# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with closing bonus and residual-frequency term.

Primary rule: best fit (smallest post-placement residual) plus a strong bonus
when the placement closes the bin (residual below the smallest item observed).
A small extra bonus rewards residuals that exactly equal a frequently observed
item size, nudging the packer to leave gaps that a common item will fill.
"""
import numpy as np

CAP = 100
N = CAP + 1

# Smallest item size observed so far.
_min_item = CAP + 1
# Running histogram of observed item sizes (counts, index = size).
_hist = np.zeros(N, dtype=np.float64)


def priority(item, bins):
    global _min_item, _hist

    if item < _min_item:
        _min_item = item
    _hist[item] += 1.0

    b = np.asarray(bins, dtype=np.float64)
    residual = b - item
    residual = np.maximum(residual, 0.0)

    # Best-fit: prefer the smallest residual.
    score = -residual

    # Small bonus for residuals that exactly match a likely future item size.
    # Use the frequency of that size as a proxy for how fillable it is.
    idx = residual.astype(np.int64)
    idx[idx >= N] = 0
    freq = _hist[idx]
    # Normalize gently so it only breaks near-ties.
    total = _hist.sum()
    if total > 0:
        score += 0.01 * (freq / total) * 100.0

    # Closing bonus: if residual can no longer hold any item seen so far,
    # strongly reward closing this bin.
    if _min_item <= CAP:
        close = residual < _min_item
        score += 1000.0 * close

    return score
# EVOLVE-BLOCK-END

