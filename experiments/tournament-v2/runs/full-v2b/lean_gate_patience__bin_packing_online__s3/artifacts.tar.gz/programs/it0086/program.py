# EVOLVE-BLOCK-START
"""Online best-fit with a sliver-avoidance bonus."""
import numpy as np


class _State:
    def __init__(self):
        self.min_item = 1.0
        self.count = 0.0


_state = _State()


def priority(item, bins):
    """Best-fit (minimize residual), with a small bonus for residuals large
    enough to hold typical future small items (avoid unusable slivers)."""
    st = _state
    st.count += 1.0
    if item < st.min_item:
        # decay toward new minimum slowly to remain adaptive
        st.min_item = 0.9 * st.min_item + 0.1 * float(item)

    residual = bins.astype(np.float64) - float(item)

    score = -residual
    # bonus when residual can still hold a small item (not a dead sliver)
    score += 0.3 * (residual >= st.min_item)

    return score
# EVOLVE-BLOCK-END
