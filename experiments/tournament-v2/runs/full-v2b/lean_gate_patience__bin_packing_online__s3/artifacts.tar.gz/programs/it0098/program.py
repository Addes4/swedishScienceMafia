# EVOLVE-BLOCK-START
"""Tight best-fit bin-choice rule.

Score each candidate bin by the residual capacity left after placing the item
(`residual = remaining - item`), preferring the smallest non-negative residual
(tightest fit). A negligible tie-break slightly favors already-used bins over
fresh bins so that equal-residual choices consolidate bins instead of opening
new ones.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for all shown bins
    # Tightest fit dominates; tiny secondary term favors used (smaller remaining) bins.
    score = -residual.astype(np.float64) - 1e-4 * bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
