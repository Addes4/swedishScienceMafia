import numpy as np

# Weibull-shaped distribution, mean ~40. We approximate the fixed distribution
# with a discretized Weibull(k, lambda) over integers 1..100.
# Weibull shape ~ chosen so mean ~40. We solve for lambda given shape 2.0.
_alpha = 100.0 / 100.0  # placeholder unused

# Build a discrete pmf once at import time.
def _build_pmf():
    from math import exp
    shape = 2.0
    # Choose scale so that mean of truncated Weibull on 1..100 is ~40.
    # Weibull mean = scale * Gamma(1 + 1/shape). Set mean 40 -> scale.
    # Gamma(1.5) ~ 0.886226925452758
    scale = 40.0 / 0.886226925452758
    x = np.arange(1, 101, dtype=np.float64)
    cdf = 1.0 - np.exp(-((x / scale) ** shape))
    cdf_prev = 1.0 - np.exp(-(((x - 1.0) / scale) ** shape))
    p = cdf - cdf_prev
    p = np.clip(p, 0.0, None)
    p = p / p.sum()
    return p

_p = _build_pmf()
_sizes = np.arange(1, 101, dtype=np.float64)

# Expected number of items packable into residual r using a simple greedy
# "fill with expected sizes" model: value[r] = E_greedy count.
# We approximate by a renewal value function: V[r] = max(0, V[r - s]) averaged.
# Compute V via iterative DP over residuals 0..100.
def _build_value():
    V = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        best = 0.0
        acc = 0.0
        for j in range(1, 101):
            if j <= r:
                acc += _p[j - 1] * (1.0 + V[r - j])
        # Also consider leaving residual unused (weight of items that don't fit)
        acc += np.sum(_p[np.arange(1, 101) > r])
        V[r] = acc
    return V

_V = _build_value()
# Normalize V to a [0, ~] range; scale so differences are meaningful.
_value_scale = 1.0

_state = {"count": 0.0}

def priority(item, bins):
    resid = bins - item
    resid = np.clip(resid, 0, 100).astype(np.int64)
    # Fillability of residual.
    fill = _V[resid]
    # Tie-break toward tighter fit (smaller residual) via tiny linear term.
    tight = -resid.astype(np.float64)
    score = fill * 1.0 + tight * 0.001
    return score
