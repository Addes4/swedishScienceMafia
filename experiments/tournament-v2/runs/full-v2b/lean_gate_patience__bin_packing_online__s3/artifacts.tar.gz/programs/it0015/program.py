# EVOLVE-BLOCK-START
"""Adaptive best-fit with a running-size-model penalty.

The dominant term is classic Best-Fit tightness (minimize leftover).
A secondary term breaks near-ties toward bins whose residual space
matches the recent item-size distribution well, reducing fragmentation.
"""
import numpy as np

_state = {"sum": 0.0, "n": 0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    s = _state
    s["sum"] += item
    s["n"] += 1
    # Exponential-decay histogram of recent item sizes (weighted).
    if s["n"] > 200:
        s["hist"] *= 0.99
        s["sum"] *= 0.99
        s["n"] *= 0.99
    s["hist"][item] += 1.0

    b = bins.astype(np.float64)
    leftover = b - item  # remaining capacity after placing

    # Primary: best-fit tightness.
    score = -leftover

    # Secondary: prefer bins whose new leftover is a "common" size,
    # i.e. likely to be filled exactly by a future item of that size.
    # hist[leftover] is high when many recent items had that exact size.
    total = s["hist"].sum()
    if total > 0:
        idx = np.clip(leftover.astype(np.int64), 0, 100)
        match = s["hist"][idx] / total
        score = score + 0.3 * match

    return score
# EVOLVE-BLOCK-END
