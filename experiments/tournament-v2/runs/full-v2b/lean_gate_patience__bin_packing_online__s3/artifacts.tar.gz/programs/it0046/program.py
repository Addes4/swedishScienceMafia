# EVOLVE-BLOCK-START
"""Best fit plus frequency-weighted exact-residual bonus."""
import numpy as np


class _Model:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        self._probs = None

    def update(self, item):
        self.counts[item] += 1.0
        self.total += 1.0
        self._probs = None

    def probs(self):
        if self._probs is None:
            if self.total > 0:
                p = self.counts / self.total
            else:
                p = np.zeros(101, dtype=np.float64)
                p[1:101] = 1.0 / 100.0
            self._probs = p
        return self._probs


_MODEL = _Model()


def priority(item, bins):
    m = _MODEL
    m.update(int(item))
    p = m.probs()

    # Primary: best fit -> smaller residual (bins - item) is better.
    residual = bins - item
    tight = -residual.astype(np.float64)

    # Residual usefulness: a residual that can exactly fit a common item size
    # is valuable because a future item will consume it exactly.
    res = residual.astype(np.int64)
    validity = (res >= 1) & (res <= 100)
    freq = np.zeros(residual.shape, dtype=np.float64)
    freq[validity] = p[res[validity]]

    # Bonus proportional to the chance that this residual gets exactly used.
    bonus = 2.0 * freq

    return tight + bonus
# EVOLVE-BLOCK-END
