# EVOLVE-BLOCK-START
import numpy as np


def priority(item, bins):
    """Classic Best Fit: place into the fitting bin with the least remaining
    capacity after insertion (smallest leftover). Ties go to the first bin.

    Higher score is better, so we score by -leftover = -(b - item) = item - b,
    which is maximized by the tightest fitting bin.
    """
    b = np.asarray(bins, dtype=np.float64)
    if b.size == 0:
        return np.zeros(0, dtype=np.float64)
    return float(item) - b


# EVOLVE-BLOCK-END
