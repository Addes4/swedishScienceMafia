# EVOLVE-BLOCK-START
"""Histogram-based expected-fillability bin rule with adaptive fresh-bin penalty.

The rule ranks each candidate bin by a combination of:
  * tightness of the fit (small residual after placing the item is good),
  * an estimate of how much *useful* capacity remains, measured as the expected
    number of future items (drawn from a running histogram of past item sizes)
    that could be packed into the residual, and
  * an adaptive penalty on near-empty (fresh) bins, whose strength grows with a
    running EWMA of item-size pressure (mean recent item size relative to bin
    capacity).

All quantities are computed with cheap vectorised numpy operations so 5,000
arriving items stay within the time limit.
"""
import numpy as np

# Running statistics kept between calls.
_state = {
    "hist": np.zeros(101, dtype=np.float64),   # histogram of past item sizes
    "count": 0.0,                              # total items seen
    "ewma_size": 40.0,                         # EWMA of item size
    "alpha": 0.02,                             # EWMA smoothing
    "pressure": 0.4,                           # ewma_size / 100
}


def _expected_fills(residual, hist):
    """Vectorised estimate of expected number of future items packable in `residual`.

    We approximate by counting, for each residual value, how many average-sized
    items (mean of the histogram) fit, plus a small correction that rewards
    residuals which are close to common item sizes (so they can absorb a whole
    future item tightly rather than leave slivers).
    """
    total = hist.sum()
    if total <= 0.0:
        # No information yet: fall back to raw residual.
        return residual.astype(np.float64)

    # Mean item size from histogram.
    sizes = np.arange(hist.size, dtype=np.float64)
    mean_size = float((sizes * hist).sum() / total)
    if mean_size < 1e-6:
        mean_size = 40.0

    # Expected count of mean-sized items fitting in each residual.
    base = residual.astype(np.float64) / mean_size

    # Reward residuals that are close to frequently seen item sizes: a residual
    # that matches a common item size can absorb that item perfectly.
    # Compute, per residual r, the max histogram mass over sizes <= r.
    # Cumulative distribution of item sizes.
    cum = np.cumsum(hist) / total
    sizes_i = np.arange(hist.size)
    # For each residual, best "match quality" = probability mass at sizes <= r
    # weighted toward larger usable sizes.
    idx = np.clip(residual.astype(np.int64), 0, hist.size - 1)
    match = cum[idx]  # P(size <= residual)

    # Blend: expected fills, stretched slightly by match quality.
    return base * (0.85 + 0.3 * match)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    st = _state
    hist = st["hist"]

    # Update EWMA and histogram with the new item (this item is placed now).
    st["ewma_size"] = (1.0 - st["alpha"]) * st["ewma_size"] + st["alpha"] * float(item)
    st["pressure"] = st["ewma_size"] / 100.0
    hist[item] += 1.0
    st["count"] += 1.0

    bins_f = bins.astype(np.float64)
    residual = bins_f - float(item)          # capacity left after placing here

    # Expected future fillability of the residual.
    fill = _expected_fills(residual, hist)

    # Tightness: smaller residual is better.
    tight = -residual

    # Adaptive penalty on fresh / near-empty bins: penalise large residuals
    # proportional to current pressure, so under high pressure we stop scattering
    # items into fresh bins and instead save them for similarly large items.
    pressure = st["pressure"]
    fresh_penalty = pressure * bins_f          # large residual -> bigger penalty

    # Also reward moderately tight fits strongly (best-fit core).
    score = tight + 0.9 * fill - 1.4 * fresh_penalty

    # Strongly prefer exact / near-exact fits.
    score += 25.0 * (residual < 1e-9)

    return score
# EVOLVE-BLOCK-END
