# EVOLVE-BLOCK-START
"""Best-fit with histogram-aware tie-breaking.

Primary ordering is strict best-fit (smallest post-placement residual).
Ties are broken by preferring bins whose residual can still hold the most
common upcoming item size, so leftover slack stays reusable. A secondary
tie-break avoids leaving residuals that fit nothing common.
"""
import numpy as np

_STATE = {
    "hist": None,
    "count": 0.0,
}


def priority(item, bins):
    s = _STATE

    if s["hist"] is None:
        s["hist"] = np.zeros(101, dtype=np.float64)
    s["hist"][item] += 1.0
    s["count"] += 1.0

    bins_f = bins.astype(np.float64)
    resid = bins_f - item

    # primary: best-fit (smallest residual after placement)
    score = -resid

    if s["count"] > 30:
        hist = s["hist"]
        total = s["count"]
        # most common recent item size (mode with weight), avoid tiny sizes
        # find best-fit size: size whose count is largest and > 5
        probs = hist / total
        # expected "fit value": probability that a random next item fits resid
        resid_int = np.clip(resid.astype(np.int64), 0, 100)
        cum = np.cumsum(hist)
        p_fit = cum[resid_int] / total

        # We want residuals that fit a decent chance of an item (reusable),
        # but not so large they waste fresh bins. Add graded bonus for
        # residuals with high fit-probability, tiny weight so it only breaks
        # near-ties among similar residuals.
        score = score + 0.02 * p_fit
    return score
# EVOLVE-BLOCK-END
