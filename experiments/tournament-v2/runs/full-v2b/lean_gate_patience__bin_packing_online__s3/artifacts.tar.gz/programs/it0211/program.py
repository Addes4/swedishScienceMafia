# EVOLVE-BLOCK-START
"""Best-Fit bin choice.

Items go to the fitting bin with the smallest remaining capacity after
placement (the tightest fit), which is a strong online packing heuristic.
"""
import numpy as np


def priority(item, bins):
    # best fit: prefer the smallest post-placement residual
    return -(bins - item)
# EVOLVE-BLOCK-END
