# EVOLVE-BLOCK-START
"""Best-fit with a time-decaying penalty on opening fresh bins."""
import numpy as np

_state = {"n": 0.0}


def priority(item, bins):
    s = _state
    s["n"] += 1.0

    resid = bins.astype(np.float64)
    # Primary: best fit -> maximize score = item - residual (minimize leftover).
    score = float(item) - resid

    # Penalize opening fresh bins, but decay the penalty as the instance fills,
    # so late behavior is essentially pure best-fit.
    decay = 1.0 / (1.0 + s["n"] / 500.0)
    fresh = resid >= 100.0
    if fresh.any():
        # Penalty proportional to wasted capacity a fresh bin would have.
        penalty = 2.0 * decay * (1.0 - item / 100.0)
        score = score - fresh * penalty

    return score
# EVOLVE-BLOCK-END
