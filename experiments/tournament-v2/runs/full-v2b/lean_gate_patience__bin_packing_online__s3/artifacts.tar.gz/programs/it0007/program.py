# EVOLVE-BLOCK-START
"""
Adaptive best-fit with a dynamic phase-aware bias.

Places each item into the bin with the highest score. The core rule is best fit
(smallest resulting residual), with:
  * a dynamic penalty for opening brand-new bins that grows when a tight existing
    fit is available,
  * a mild bonus for bins that are already fuller (lower current capacity),
  * soft target matching against the observed mean item size.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0.0
        self.mean = 40.0
        self.last_items = []
        self.waste = 0.0
        self.bins_seen = 0

    def observe_item(self, item):
        self.n += 1
        self.total += item
        alpha = 0.02 if self.n > 100 else 0.2
        if self.n == 1:
            self.mean = float(item)
        else:
            self.mean = (1.0 - alpha) * self.mean + alpha * float(item)
        self.last_items.append(item)
        if len(self.last_items) > 64:
            self.last_items.pop(0)

    def observe_choice(self, residual_after):
        if residual_after is not None:
            self.waste = 0.99 * self.waste + 0.01 * float(residual_after)


_state = _State()


def priority(item, bins):
    item = int(item)
    _state.observe_item(item)

    b = np.asarray(bins, dtype=np.float64)
    size = b.size
    if size == 0:
        return np.zeros(0, dtype=np.float64)

    fit = b >= item
    residual = b - float(item)
    base = -residual

    mean_est = max(1.0, min(99.0, _state.mean))

    used_mask = (b < 100.0).astype(np.float64)
    fresh_mask = (b >= 100.0).astype(np.float64)

    # How tight is the best existing (used) fit? If a used bin offers a tight
    # residual, opening a fresh bin should be strongly discouraged.
    used_res = np.where(used_mask > 0, residual, np.inf)
    best_used_res = float(np.min(used_res)) if np.any(used_mask > 0) else np.inf

    # fresh penalty: larger when a good existing fit exists.
    tightness = 0.0
    if np.isfinite(best_used_res):
        # best_used_res small -> tightness near 1; large -> near 0.
        tightness = max(0.0, 1.0 - best_used_res / max(1.0, mean_est))
    fresh_penalty = 0.5 + 1.5 * tightness + 0.5 * (mean_est / 100.0)

    score = base - fresh_penalty * fresh_mask

    # Mild bonus for already-fuller bins (concentrate leftovers).
    score += 0.05 * used_mask

    # Soft target matching: reward residuals near one mean item.
    score += 0.06 * (-np.abs(residual - mean_est))

    if not np.all(fit):
        score = np.where(fit, score, -1e9)

    return score


# EVOLVE-BLOCK-END
