# EVOLVE-BLOCK-START
"""Online bin choice: best-fit with a histogram-based residual-usefulness bonus.

For each arriving item we compute residual = capacity - item for every fitting bin.
We prefer small residual (classic best-fit). To break ties usefully, we add a bonus
proportional to the probability that the residual capacity can still be filled by a
future item, estimated from a running histogram of past item sizes. The bonus is
computed as a cheap vectorized lookup of the residual against a histogram-derived
"fill value" table.
"""
import numpy as np

_MAX = 100


class _State:
    def __init__(self):
        # histogram over item sizes 1..100, with slight prior so no size is impossible
        self.hist = np.ones(_MAX + 1, dtype=np.float64)
        self.count = 0.0
        # decay factor to keep histogram recent (adapts if distribution shifts)
        self.alpha = 0.005
        # weight of the usefulness bonus
        self.bonus_w = 0.35
        # cached usefulness table indexed by residual capacity (0..100)
        self.useful = np.zeros(_MAX + 1, dtype=np.float64)


_state = _State()


def _rebuild_useful(st):
    """For each possible residual capacity r, estimate usefulness = P(future item fits)
    weighted so larger residuals that are 'fillable' get more credit. We use the
    expected best single future item size that fits r, normalized."""
    h = st.hist
    total = h.sum()
    if total <= 0:
        st.useful[:] = 0.0
        return
    p = h / total  # probability of each size 1..100
    sizes = np.arange(_MAX + 1, dtype=np.float64)
    useful = np.zeros(_MAX + 1, dtype=np.float64)
    # For each r, usefulness = sum over sizes s<=r of p[s] * s / r
    # This rewards residuals that can be substantially filled by one typical item.
    cum_ps = np.cumsum(p * sizes)  # cumulative expected size contribution
    # clamp: only sizes <= r count
    for r in range(_MAX + 1):
        if r <= 0:
            useful[r] = 0.0
        else:
            useful[r] = cum_ps[r] / r
    st.useful = useful


def priority(item, bins):
    st = _state

    # update running histogram
    st.hist *= (1.0 - st.alpha)
    st.hist[item] += 1.0
    st.count += 1.0

    # periodically rebuild the usefulness lookup (cheap: 101 entries)
    if int(st.count) % 25 == 1:
        _rebuild_useful(st)

    residual = bins - item
    rem = residual.astype(np.float64)

    # primary: best-fit -> prefer smallest residual
    score = -rem

    # secondary: reward residuals that can still be filled by a typical item
    idx = np.clip(residual, 0, _MAX).astype(np.int64)
    score += st.bonus_w * st.useful[idx]

    return score
# EVOLVE-BLOCK-END
