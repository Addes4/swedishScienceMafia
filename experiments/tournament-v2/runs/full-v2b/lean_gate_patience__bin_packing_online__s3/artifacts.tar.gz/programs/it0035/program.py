# EVOLVE-BLOCK-START
"""Pair-aware best-fit: exploit common residual capacities.

Many online packers waste bins because best-fit leaves a small residual that no
future item fits. A simple fix: when an existing bin's remaining capacity
matches a plausible next item size (estimated from a short sliding window of
recent items), placing the current item there leaves a residual that those
items can fill. So we add a bonus for bins whose post-placement residual lands
near a recently observed item size, while keeping best-fit as the core.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.recent = []
        self.window = 64

    def update(self, item):
        self.n += 1
        self.recent.append(int(item))
        if len(self.recent) > self.window:
            self.recent.pop(0)


_state = _State()


def priority(item, bins):
    _state.update(item)

    rem = bins.astype(np.float64)
    residual = rem - float(item)          # post-placement leftover per bin

    # Core: best-fit (smaller residual -> higher score).
    score = -residual

    # Pair bonus: reward bins whose residual is close to a recently seen item
    # size, so that residual is likely to be consumed soon.
    recent = _state.recent
    if recent:
        r = np.asarray(recent, dtype=np.float64)
        # distance from residual to nearest recent item size
        d = np.min(np.abs(residual[:, None] - r[None, :]), axis=1)
        # bonus shrinks with distance; ~1 unit if residual ~ some recent size
        score += 0.8 / (1.0 + d)

    return score
# EVOLVE-BLOCK-END
