# EVOLVE-BLOCK-START
"""Dead-residual-avoiding best fit.

Pure best-fit leaves many bins with tiny unusable leftovers.  This rule keeps
best-fit's tightness but adds a penalty when the post-placement residual falls
in the "dead zone" (a small residual that few future items can use), pushing the
item into bins that still leave a sizable, reusable remaining capacity, while
still strongly preferring the tightest fit overall.  A running estimate of the
typical item size sets the dead-zone threshold adaptively.
"""
import numpy as np


def priority(item, bins):
    st = priority.__dict__
    if 'mean' not in st:
        st['mean'] = 40.0
        st['count'] = 0

    m = st['mean']
    st['mean'] = m + 0.02 * (item - m)
    st['count'] += 1
    typ = st['mean']

    residual = bins.astype(np.float64) - item

    # Base: tightest residual first (best fit).
    score = -residual

    # Penalize dead residuals: after placing, if the remaining capacity is small
    # but nonzero, that space is likely wasted.  Penalize it so we prefer bins
    # that leave a reusable remainder.
    dead_thresh = 0.5 * typ
    small = residual > 0.0
    dead = small & (residual < dead_thresh)
    score = score - 3.0 * dead.astype(np.float64) * (1.0 - residual / dead_thresh)

    return score
# EVOLVE-BLOCK-END

