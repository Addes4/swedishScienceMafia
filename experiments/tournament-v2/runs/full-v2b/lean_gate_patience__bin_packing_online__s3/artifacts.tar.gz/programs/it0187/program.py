# EVOLVE-BLOCK-START
"""Online bin choice: best-fit with a graded closing preference.

Primary rule: place the item into the bin with the smallest post-placement
residual (best fit) to keep bins tightly packed. Give a large bonus to
placements that "close" a bin (residual below the smallest item size seen so
far), because such a bin can accept no future item and is efficiently used up.
Within the closing tier, prefer the bin with the largest residual (most slack
wasted is smallest), and overall use plain best-fit to break remaining ties.
"""
import numpy as np

_SIZE_MAX = 100

# Smallest item size observed so far (init to a large value).
_min_item = _SIZE_MAX + 1


def priority(item, bins):
    global _min_item
    item = int(item)
    if item < _min_item:
        _min_item = item

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item

    fits = residual >= 0

    # Best-fit: prefer the smallest non-negative residual.
    score = -residual

    # Closing tier: residual below smallest observed item => bin is closed.
    # Among these, prefer the LARGEST residual (least usable slack wasted).
    closed = fits & (residual < _min_item)
    score = np.where(closed, residual + _SIZE_MAX, score)

    # Non-fitting bins never chosen.
    score = np.where(fits, score, -1e9)

    return score
# EVOLVE-BLOCK-END
