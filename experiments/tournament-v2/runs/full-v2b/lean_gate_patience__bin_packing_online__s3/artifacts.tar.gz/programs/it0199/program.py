"""Best-Fit with dead-residual awareness: prefer tightest fit, rewarding
placements that leave a residual too small to fit any future item (free waste)."""
import numpy as np

_min_seen = 101


def priority(item, bins):
    global _min_seen
    if item < _min_seen:
        _min_seen = item

    # residual after placing item in each bin
    residual = bins - item

    # A residual is "dead" if it is smaller than the smallest item seen so far,
    # meaning no future item could ever fit there -> no useful capacity wasted.
    dead = residual < _min_seen

    # Build score: 
    #  - dead placements: high base score, prefer the smallest residual (tightest)
    #    among dead ones so we don't waste more than necessary.
    #  - non-dead placements: standard best-fit (prefer smallest residual),
    #    i.e. highest score = closest to zero but still >= min_seen.
    #
    # We want dead placements to always beat non-dead ones (since the leftover
    # capacity there is unusable anyway). Use an offset large enough to dominate.
    n = bins.shape[0]
    score = np.empty(n, dtype=np.float64)

    offset = 1000.0
    # non-dead: score in (-100, 0], higher = smaller residual = better fit
    score[:] = -residual

    # dead: dominate, and among dead prefer smallest residual (tightest).
    score[dead] = offset - residual[dead]

    return score
