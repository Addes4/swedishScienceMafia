"""Online bin packing: best-fit with a closing bonus and fillable-residual nudge.

Rank bins so that a placement which leaves a residual too small to ever hold
another item (below the smallest size seen so far) is strongly preferred
(closing the bin cleanly). Otherwise prefer the tightest fit, but add a small
bonus for residuals that match small observed item sizes (or simple multiples),
which tend to be fillable later.
"""
import numpy as np

_cnt_min = 101          # smallest item size observed so far
_total = 0.0
_sum = 0.0


def priority(item, bins):
    global _cnt_min, _total, _sum

    s = int(item)
    if s < _cnt_min:
        _cnt_min = s
    _total += 1.0
    _sum += s

    mean = _sum / _total if _total > 0 else 40.0
    if mean < 1e-9:
        mean = 40.0

    min_size = _cnt_min if _cnt_min <= 100 else 1

    residual = bins - s                       # post-placement residual, vectorized

    # Closing bonus: residuals too small to ever hold another item are best.
    close = residual < min_size

    # Small nudge: residuals that are "fillable" (an exact small item size or a
    # near multiple of the smallest size) are slightly more attractive than a
    # plain tight fit.  Keep this small so best-fit dominates.
    m = float(min_size)
    if m >= 1.0:
        ratio = residual / m
        frac = np.abs(ratio - np.round(ratio))
    else:
        frac = np.zeros_like(residual)

    # Primary term: -residual (tightest fit wins).  Bonus rewards fillable
    # residuals (frac near 0).  Scale bonus by a small constant.
    scores = -residual + 0.5 * (1.0 - frac)

    # Override with closing bonus where applicable (largest score first).
    scores = np.where(close, 1e6 - residual, scores)

    return scores
