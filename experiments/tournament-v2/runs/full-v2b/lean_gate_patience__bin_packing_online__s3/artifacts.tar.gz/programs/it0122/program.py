# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a mild fresh-bin penalty.

The dominant signal is best-fit tightness: prefer the bin whose remaining capacity
after placing the item is smallest (smallest residual).  On top of that we apply a
small fixed penalty to brand-new (unused) bins so that, when several bins give the
same residual, we prefer to keep opening no more bins than necessary; and a tiny
epsilon bias to bins that already hold items, breaking ties toward existing bins.

Fresh bins have remaining capacity exactly 100.
"""

import numpy as np


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    bins = np.asarray(bins, dtype=np.float64)

    residuals = bins - item  # residual capacity after placing the item here

    # Best-fit: prefer the smallest residual (tightest fit).
    score = -residuals

    # Mild penalty for opening a brand-new bin (remaining capacity exactly 100).
    fresh = (bins >= 100.0 - 1e-9)
    score = score - fresh * 0.5

    return score
# EVOLVE-BLOCK-END
