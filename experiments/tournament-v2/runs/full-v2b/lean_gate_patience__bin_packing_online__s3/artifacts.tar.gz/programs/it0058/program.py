# EVOLVE-BLOCK-START
"""Best-fit with convex (squared) residual penalty: strongly prefer near-perfect fits."""
import numpy as np


def priority(item, bins):
    """Score bins by the negative square of the post-placement residual.

    A convex penalty on the leftover capacity aggressively prefers bins that
    end up nearly full, which packs tightly and reduces bin count. Squaring
    breaks near-ties among small residuals in favor of the tightest bin while
    still distinguishing large residuals sharply (discouraging fresh bins).
    """
    residual = bins - item  # >= 0 for bins the item fits in
    # Negative squared residual: smallest residual gets highest score.
    # Use float64 to avoid int64 overflow on squares (max 100^2 = 10000, safe,
    # but the subtraction is fine; convert to float for the square anyway).
    r = residual.astype(np.float64)
    return -(r * r)
# EVOLVE-BLOCK-END
