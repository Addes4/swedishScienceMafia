# EVOLVE-BLOCK-START
"""Histogram-simulated completion best fit for online bin packing."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)  # counts of past items by size 1..100
_TOTAL = 0.0
_SIZES = np.arange(1, 101, dtype=np.float64)


def _completion_waste(cap, hist, mean_size):
    """Greedy simulate filling leftover capacity `cap` using past-size probabilities.

    Returns predicted fraction of capacity that will be filled (higher = better).
    We fill greedily with sizes weighted by frequency, approximating expected usage.
    """
    if cap <= 0:
        return 0.0
    remaining = cap
    filled = 0.0
    # Greedy: repeatedly pick the largest size <= remaining with reasonable probability,
    # otherwise the best-fitting probable size. Limited iterations for speed.
    for _ in range(12):
        if remaining <= 0.5:
            break
        # Look at candidate sizes we could still place, weighted by frequency.
        max_sz = int(remaining)
        if max_sz < 1:
            break
        # Sizes that fit
        lo = max(1, max_sz - 30)
        cand = hist[lo:max_sz + 1]
        tot = cand.sum()
        if tot <= 0:
            # fall back to mean size
            if mean_size <= remaining and mean_size >= 1:
                remaining -= mean_size
                filled += mean_size
                continue
            # use approximate expected fill of leftover
            filled += remaining * 0.5
            break
        sizes = np.arange(lo, max_sz + 1, dtype=np.float64)
        probs = cand / tot
        # To favor filling, choose the size bin whose expected leftover usage is best.
        lefts = remaining - sizes
        # approximate downstream usage of leftover via mean_size ratio (geometric-ish)
        if mean_size > 0:
            downstream = 1.0 - np.exp(-lefts / mean_size)
        else:
            downstream = lefts / 100.0
        gain = (sizes + lefts * downstream)  # total expected filled
        best = np.argmax(gain * probs)
        r = sizes[best]
        if r > remaining:
            break
        remaining -= r
        filled += r
        if r < 1:
            break
    return filled


def priority(item, bins):
    global _TOTAL
    # Update histogram with the arriving item (before deciding).
    mean_size = 0.0
    if _TOTAL > 0:
        mean_size = float(np.dot(_HIST, _SIZES) / _TOTAL)
    else:
        mean_size = 40.0

    n = len(bins)
    item = float(item)

    # Candidate residuals after placing item in each bin.
    residual = bins.astype(np.float64) - item

    scores = np.empty(n, dtype=np.float64)

    # Predict fill quality of residual for each distinct capacity.
    cache = {}

    # Detect if this is a fresh bin (cap 100) to mildly discourage opening new bins.
    for i in range(n):
        r = residual[i]
        if r < 0:
            # Should not happen since bins are only those that fit, but guard.
            scores[i] = -1e18
            continue
        key = int(r)
        if key in cache:
            wasted = cache[key]
        else:
            filled = _completion_waste(r, _HIST, mean_size)
            # waste = capacity not expected to be filled
            wasted = r - filled
            cache[key] = wasted
        # Lower predicted waste is better; slight preference to tighter fit.
        # Combine predicted waste with a small immediate tightness term.
        scores[i] = -(wasted + 0.02 * r)

    # Update histogram after scoring (arriving item counted for future).
    ii = int(item)
    if 1 <= ii <= 100:
        _HIST[ii] += 1.0
        _TOTAL += 1.0

    return scores
# EVOLVE-BLOCK-END
