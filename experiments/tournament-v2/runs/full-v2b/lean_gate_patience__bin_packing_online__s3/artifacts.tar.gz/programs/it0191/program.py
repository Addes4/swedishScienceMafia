import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "count": 0.0,
}

# Precompute the size grid once.
_SIZES = np.arange(1, 101, dtype=np.float64)


def priority(item, bins):
    st = _state
    st["hist"][item] += 1.0
    st["count"] += 1.0
    c = st["count"]

    n = bins.size

    # Empirical distribution over sizes seen so far with tiny smoothing.
    hist = st["hist"]
    p = (hist + 0.5) / (c + 50.0)
    pm = p[1:101]  # probability of sizes 1..100

    resid = bins - item
    resid = np.clip(resid, 0, 100)

    # Only the residual values matter; compute for each unique residual the
    # expected number of future items it can still greedily hold.
    # E[count into residual r] ~ sum_j p_j * floor(r/j) (continuous fill proxy).
    # We compute this exactly for all r in 0..100 once per call (cheap).
    floors = np.zeros(101, dtype=np.float64)
    # Sum over item sizes j weighted by probability pm[j-1], of floor(r/j).
    # Build matrix: for each j, floor(r/j) for r=0..100.
    r_grid = np.arange(0, 101, dtype=np.float64)
    # weight each size
    fill_table = np.zeros(101, dtype=np.float64)
    for j in range(1, 101):
        pj = pm[j - 1]
        if pj <= 0.0:
            continue
        fill_table += pj * np.floor(r_grid / j)

    # Score: expected fillability of the residual (higher is better).
    # Subtract a tiny tie-breaker favoring tighter fits (smaller residual),
    # scaled small so it only breaks near-ties.
    score = fill_table[resid.astype(np.int64)] - 0.0001 * resid.astype(np.float64)

    return score
