# EVOLVE-BLOCK-START
"""Best fit with a mild preference for already-fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Pure best fit would be -(bins - item).  Subtract a small multiple of the
    # remaining capacity so that among equally tight fits we favor bins that are
    # already closer to full, which reduces fragmentation.
    b = bins.astype(np.float64)
    return -(b - item) - 1e-3 * b
# EVOLVE-BLOCK-END
