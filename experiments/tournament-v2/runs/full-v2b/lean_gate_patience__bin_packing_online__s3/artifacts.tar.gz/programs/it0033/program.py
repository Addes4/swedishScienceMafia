# EVOLVE-BLOCK-START
"""Best-fit with a small constant fresh-bin (slack) penalty.

Core rule: prefer the bin whose post-placement residual is smallest (Best-Fit).
Add a small constant penalty proportional to the bin's remaining capacity so that,
all else being nearly equal, we slightly prefer reusing a bin that is already
partly full over opening/seeding a fresh one. A fixed small lambda avoids the
noise of an adaptive estimator.
"""
import numpy as np

# Small constant slack penalty. Enough to break near-ties toward fuller bins,
# small enough not to override genuine best-fit differences.
_LAMBDA = 0.01


def priority(item, bins):
    rem = bins.astype(np.float64)
    tightness = -(rem - item)   # best-fit: smaller leftover -> higher score
    slack_pen = -_LAMBDA * rem  # tiny push toward already-used (fuller) bins
    return tightness + slack_pen
# EVOLVE-BLOCK-END
