# EVOLVE-BLOCK-START
"""Best-fit with histogram-aware tie-break and adaptive fresh-bin reservation.

Primary rule: best-fit (smallest post-placement residual wins).  Near-ties are
broken by how well the residual matches the most common upcoming item sizes from
a running histogram, so leftover slack stays reusable.  A mild penalty discourages
opening fresh bins early, fading as the instance progresses.
"""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "count": 0.0,
}


def priority(item, bins):
    st = _state
    hist = st["hist"]
    hist[item] += 1.0
    st["count"] += 1.0

    bins_f = bins.astype(np.float64)
    residual = bins_f - float(item)

    total = hist.sum()
    if total > 4.0:
        sizes = np.arange(hist.size, dtype=np.float64)
        # Probability-weighted "reusability": expected number of future items
        # that fit into the residual using mean size, plus match bonus.
        mean_size = float((sizes * hist).sum() / total)
        if mean_size < 1.0:
            mean_size = 40.0
        idx = np.clip(residual.astype(np.int64), 0, hist.size - 1)
        match = np.cumsum(hist)[idx] / total  # P(size <= residual)
    else:
        mean_size = 40.0
        match = np.zeros_like(residual)

    # Core best-fit: smaller residual is better (dominant term).
    best_fit = -residual

    # Secondary: reward residuals that can still absorb a whole typical future item.
    fillable = (residual >= mean_size).astype(np.float64)
    usable = (residual / mean_size) + 0.5 * match

    # Fresh-bin penalty: penalise using sizeable leftover (unused) bins early,
    # fading with how many bins have been opened.
    opened = np.count_nonzero(bins_f < 99.5)
    frac_open = opened / max(bins_f.size, 1)
    fresh_pen = (0.2 + 0.6 * frac_open) * (bins_f >= 99.5)

    score = best_fit + 0.35 * usable + 0.5 * fillable - 3.0 * fresh_pen

    # Prefer exact fits strongly.
    score += 20.0 * (residual < 1e-9)

    return score
# EVOLVE-BLOCK-END
