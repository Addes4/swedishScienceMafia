"""Adaptive best-fit with reusable-residual bonus and fresh-bin penalty."""
import numpy as np

_state = {
    "sum": 0.0,
    "count": 0,
    "residual_hits": {},   # bucket -> count of times a residual was later filled by an item
    "prev_residual": None, # residual created by previous placement
}


def priority(item, bins):
    """Rank bins: tightest fit, plus a bonus for creating reusable residuals.

    We maintain a coarse histogram of residuals (post-placement leftover space)
    that have actually been *reused* by a later item: when a subsequent arriving
    item fits exactly into a residual we recorded, that residual size is deemed
    reusable and gets a bonus in future scoring.
    """
    s = _state

    # Detect reuse of the residual created by the previous placement.
    pr = s["prev_residual"]
    if pr is not None and abs(pr - item) <= 1:
        key = int(round(pr / 5.0)) * 5
        s["residual_hits"][key] = s["residual_hits"].get(key, 0) + 1

    s["sum"] += item
    s["count"] += 1
    mean_item = s["sum"] / s["count"]

    b = bins.astype(np.float64)
    item_f = float(item)

    # Best-fit core: prefer tightest fit (minimize residual = b - item).
    tight = -(b - item_f)

    # Reusable-residual bonus: reward residuals matching historically reused gaps.
    resid = b - item_f
    bonus = np.zeros_like(resid)
    if s["residual_hits"]:
        keys = np.round(resid / 5.0).astype(np.int64) * 5
        maxc = max(s["residual_hits"].values())
        for k, c in s["residual_hits"].items():
            m = keys == k
            if m.any():
                bonus[m] += (c / maxc)

    # Fresh-bin penalty, scaled down so it only breaks near-ties.
    pressure = mean_item / 100.0
    lam = 1.0 - pressure
    fresh = b / 100.0

    # Record residual that this placement would create for the chosen bin,
    # approximated by best choice; we update after return is impossible, so we
    # store the residual of the best-fit candidate (tightest) as proxy.
    # Best-fit candidate residual = min over residual >= 0.
    cand = resid[resid >= 0]
    if cand.size:
        s["prev_residual"] = float(cand.min())
    else:
        s["prev_residual"] = None

    return tight - lam * fresh + 0.5 * bonus
