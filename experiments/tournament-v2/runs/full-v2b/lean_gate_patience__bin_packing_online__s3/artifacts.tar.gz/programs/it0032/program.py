# EVOLVE-BLOCK-START
"""Best-fit core with a small adaptive fresh-bin penalty.

Score = (item - residual) - lam * max(0, residual - mean_item)

The item goes to the bin minimizing residual (classic Best-Fit), which is the
strongest known online rule for this capacity. A small penalty lam on residuals
larger than the running mean item size gently discourages opening / using very
slack bins, and lam adapts to observed item pressure.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0

    def update(self, item):
        self.n += 1
        delta = item - self.mean
        self.mean += delta / self.n
        self.m2 += delta * (item - self.mean)

    def pressure(self):
        if self.n < 5:
            return 0.5
        var = self.m2 / max(1, self.n - 1)
        std = var ** 0.5
        m = self.mean
        p = (m / 100.0) + 0.5 * (std / 100.0)
        return p


_state = _State()


def priority(item, bins):
    _state.update(item)
    p = _state.pressure()
    # lam small; at typical p~0.45 lam ~ 0.02
    lam = 0.05 * (1.0 - min(1.0, p / 0.7))

    rem = bins.astype(np.float64)
    residual = rem - item

    core = -residual                      # best fit: smaller residual -> higher
    excess = np.maximum(0.0, residual - _state.mean)
    return core - lam * excess
# EVOLVE-BLOCK-END
