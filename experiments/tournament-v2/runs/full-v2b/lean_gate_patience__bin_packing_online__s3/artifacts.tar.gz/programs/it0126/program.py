# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a small tie-break against fresh bins.

Rule
----
Best-fit: place the item in the bin whose remaining capacity is the smallest
value still >= item, i.e. minimize the post-placement residual r = c - item.
This tends to leave the least usable space and empirically performs very close
to the optimal lower bound for Weibull(mean~40) sizes on capacity 100.

Tie-breaking: when residuals are equal, prefer a bin that is already in use
over a completely empty bin, so we don't open a new bin while an equally good
used bin exists.  Implemented by adding a tiny bonus to non-fresh bins.
"""

import numpy as np


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    bins = np.asarray(bins, dtype=np.float64)

    residuals = bins - item  # residual capacity after placing the item here

    # Best-fit: prefer the smallest non-negative residual.
    score = -residuals

    # Tiny bonus for already-used bins (remaining capacity strictly below 100)
    # to avoid opening a new bin when a used bin is an equally tight fit.
    fresh = bins >= 100.0 - 1e-9
    score += (~fresh) * 1e-4

    return score
# EVOLVE-BLOCK-END

