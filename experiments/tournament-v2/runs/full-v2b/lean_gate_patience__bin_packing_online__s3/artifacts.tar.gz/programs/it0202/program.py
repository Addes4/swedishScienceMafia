"""Best-Fit enhanced with exact-fill and complement-fill preferences."""
import numpy as np


def priority(item, bins):
    # residual after placing item into a bin with remaining capacity c
    residual = bins - item  # all >= 0 since bins only contains fitting bins

    # Base: prefer tightest fit (smallest residual after placement)
    score = -residual.astype(np.float64)

    # Strongly prefer bins that become exactly full (zero waste)
    score[residual == 0] += 1000.0

    return score
