import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "count": 0,
    "recent": [],
}


def priority(item, bins):
    st = _state
    st["count"] += 1
    st["hist"][item] += 1.0
    st["recent"].append(item)
    if len(st["recent"]) > 200:
        st["recent"].pop(0)

    rem = bins.astype(np.float64)

    # Dominant term: classic Best-Fit (prefer smallest residual after placement).
    slack_after = rem - item
    score = -slack_after

    # Tiebreaker: reward residuals that match a likely next item size.
    # Use recent-item histogram to form a soft distribution over "fillable" residuals.
    if st["recent"]:
        recent = np.array(st["recent"], dtype=np.float64)
        # expected refill probability ~ how many recent items fit exactly in residual
        # build a small lookup of counts by residual value (rounded to integer)
        res_int = np.clip(np.round(slack_after).astype(np.int64), 0, 100)
        fillable = np.zeros_like(slack_after)
        # vectorized: count recent items equal to residual (exact-match refill signal)
        # cheap approximation: use a smoothed histogram via bincount on recent
        vals, cnts = np.unique(recent.astype(np.int64), return_counts=True)
        match = np.zeros(101, dtype=np.float64)
        match[vals] = cnts
        # smooth neighbors so near-matches also count a little
        sm = match.copy()
        sm[1:] += 0.5 * match[:-1]
        sm[:-1] += 0.5 * match[1:]
        fillable = sm[res_int] / max(1.0, len(st["recent"]))
        score = score + 0.35 * fillable

    # Slight penalty on opening a fresh bin, only when item is small.
    fresh = rem >= 100.0 - 1e-9
    score = score - (0.6 if item <= 30 else 0.05) * fresh.astype(np.float64)

    return score
