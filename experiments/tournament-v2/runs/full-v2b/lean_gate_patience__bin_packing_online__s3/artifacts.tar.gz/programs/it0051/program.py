# EVOLVE-BLOCK-START
"""Best-fit with a residual-value tiebreak estimated from a running histogram."""
import numpy as np

_SIZE = 101
_HIST = np.ones(_SIZE, dtype=np.float64)
_COUNT = float(_SIZE)
_DECAY = 0.999


def priority(item, bins):
    global _HIST, _COUNT
    _HIST *= _DECAY
    _HIST[item] += 1.0
    _COUNT = _COUNT * _DECAY + 1.0
    hist = _HIST / _COUNT

    residual = bins - item

    # value of a residual r: expected "reusability" of that leftover fragment.
    # higher when future items tend to exactly fit or nearly fill r.
    cum = np.cumsum(hist)               # P(size <= r)
    cum_w = np.cumsum(hist * np.arange(101, dtype=np.float64))
    with np.errstate(divide='ignore', invalid='ignore'):
        mean_fit = np.where(cum > 1e-12, cum_w / np.maximum(cum, 1e-12), 0.0)
    rc = np.clip(residual, 0, 100)
    use = cum[rc]                       # chance a future item fits
    near = 1.0 - np.abs(rc - mean_fit[rc]) / np.maximum(rc, 1.0)

    # primary: best-fit (least residual). secondary: residual value.
    return -residual * 1.0 + 0.001 * (use + near)
# EVOLVE-BLOCK-END
