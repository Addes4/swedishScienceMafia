# EVOLVE-BLOCK-START
"""Online bin packing via histogram-based expected future fillability.

Approach:
- Maintain a running histogram (empirical distribution) of item sizes seen so far.
- For each candidate bin, consider placing the item there, leaving residual r = cap - item.
- Estimate how many *future* items could still be packed into residual r, using a
  greedy continuous fill estimate derived from the observed size distribution.
- Score each bin by combining:
    (a) tight fit: placing into a bin whose residual after placement is small
    (b) expected fillability: residual r can still absorb many future items
  Bins are ranked; highest score wins (ties -> first).
"""
import numpy as np

# Histogram over integer sizes 1..100 (index 1..100 used).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0

# Cache the fillability curve for given residual values within a histogram snapshot.
_FILL_CACHE = {}
_FILL_CACHE_KEY = None
_FILL_CACHE_BUILT_FOR_COUNT = -1


def _build_fill_value(residuals):
    """For each residual capacity, estimate number of future items packable (greedy)."""
    global _FILL_CACHE, _FILL_CACHE_KEY, _FILL_CACHE_BUILT_FOR_COUNT
    # Rebuild alphabet distribution (normalized probabilities, sizes 1..100).
    total = _HIST[1:].sum()
    if total <= 0:
        # Uniform-ish fallback: mean ~40 items.
        probs = np.ones(101, dtype=np.float64)
        probs[0] = 0.0
        probs /= probs.sum()
    else:
        probs = _HIST / total
        probs[0] = 0.0

    out = np.empty(residuals.shape[0], dtype=np.float64)
    # Greedy fill: repeatedly take smallest available item that fits (best-fit-decreasing
    # actual fill is unknowable online; smallest-fits-first greedily maximizes count).
    # We approximate expected count via: repeatedly remove probability mass from the
    # smallest sizes that fit.
    # To keep it fast, precompute a cumulative size-decreasing sweep.
    sizes = np.arange(101, dtype=np.float64)
    # Sort sizes ascending by probability-weighted "fit priority" = size ascending.
    order = np.arange(1, 101)

    for k in range(residuals.shape[0]):
        r = residuals[k]
        if r <= 0:
            out[k] = 0.0
            continue
        rem = r
        count = 0.0
        remaining_mass = 1.0
        # smallest-fits-first greedy expectation
        for s in order:
            if s > rem:
                break
            p = probs[s]
            if p <= 0.0:
                continue
            # expected number of items of size s that would be taken until capacity exhausted
            expected = (rem / s) if s > 0 else 0.0
            expected = min(expected, remaining_mass / max(p, 1e-12))
            # number actually taken limited by residual and mass
            take = min(rem // s, remaining_mass / max(p, 1e-12))
            # expected count contribution weighted by probability mass fraction
            contrib = take * p
            # But that overcounts mass; simpler: scale by mass share
            contrib = min(rem / s, 1.0 / max(p, 1e-12)) * p
            take = min(rem / s, 1.0 / max(p, 1e-12))
            contrib = take * p
            count += contrib
            rem -= take * s * p
            remaining_mass -= p
            if rem <= 0 or remaining_mass <= 0:
                break
        out[k] = count
    _FILL_CACHE = out
    _FILL_CACHE_BUILT_FOR_COUNT = _COUNT
    return out


def _fillability(residuals):
    """Estimate expected number of future items packable in each residual."""
    global _FILL_CACHE_BUILT_FOR_COUNT
    # Rebuild if histogram changed meaningfully.
    if _FILL_CACHE_BUILT_FOR_COUNT != _COUNT:
        return _build_fill_value(residuals)
    if _FILL_CACHE.shape[0] != residuals.shape[0]:
        return _build_fill_value(residuals)
    return _FILL_CACHE


def priority(item, bins):
    """Rank bins by tight-fit plus expected future fillability of residual."""
    global _COUNT, _HIST

    # Update histogram with observed item (online, before scoring).
    _HIST[item] += 1.0
    _COUNT += 1.0

    residuals = bins - item  # residual after placing item (>=0 since bins are eligible)
    np.maximum(residuals, 0, out=residuals)

    # Expected number of future items that fit in residual.
    fill = _fillability(residuals)

    # Tight-fit component: prefer small residual relative to typical item.
    mean_size = (_HIST[1:] * np.arange(1, 101)).sum() / max(_COUNT, 1.0)
    tight = -residuals / max(mean_size, 1.0)

    # Combine: fillability is primary, tight-fit breaks near-ties.
    return fill + 0.5 * tight
# EVOLVE-BLOCK-END
