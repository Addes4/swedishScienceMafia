# EVOLVE-BLOCK-START
"""Harmonic-style Best-Fit: prefer tight fits, weighted by size class of the item."""
import numpy as np

_CLASSES = (0.5, 1.0 / 3.0, 0.25, 0.2, 1.0 / 6.0, 1.0 / 12.0, 1.0 / 24.0)


def priority(item, bins):
    """Best-fit ranking with a size-class weight.

    Classic best-fit (smallest residual) is already strong. Harmonic packing
    gains from treating large-relative items by their size class. We bias the
    tightness term by where the item falls among the harmonic classes: items
    that are a large fraction of the bin get a stronger tightness weight so
    they pack into nearly-full bins, while small items prefer leaving a
    residual matching their own class.
    """
    residual = bins - item
    fits = residual >= 0
    # Weight: tighter is better, scaled by how dominant the item is.
    frac = item / 100.0
    # Items that nearly fill a bin get the strongest tightness push.
    w = 1.0 + frac * frac * 4.0
    score = -residual.astype(np.float64) * w
    # Small bonus for exact fits (zero residual) to encourage closing bins.
    score = score + np.where(residual == 0, 0.5, 0.0)
    return score
# EVOLVE-BLOCK-END
