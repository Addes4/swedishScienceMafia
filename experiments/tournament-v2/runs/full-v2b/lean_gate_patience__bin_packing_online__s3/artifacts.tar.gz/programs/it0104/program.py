# EVOLVE-BLOCK-START
"""Sum-of-Squares (SS) matching rule.

Choose the bin minimizing the sum of squared residual capacities after
placement.  The terms for other bins are constant, so the per-bin score is
the squared post-placement residual (maximized negatively).  Equivalent to
pairing large items with large residuals and small items with small
residuals (a matching/greedy view), which outperforms plain best fit on
many distributions.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity if placed here (>=0)
    return -(residual.astype(np.float64) ** 2)
# EVOLVE-BLOCK-END
