# EVOLVE-BLOCK-START
"""Best-fit with sliver-avoidance.

Online bin packing with random item sizes: plain best-fit leaves slivers
(residuals too small ever to hold another item) which are pure waste.
This rule ranks bins by post-placement residual, but *collapses* any residual
smaller than the smallest item size seen so far to zero (i.e. treats it as a
perfectly closed bin), so the packed choice prefers bins that finish cleanly
rather than leaving unusable leftovers.
"""
import numpy as np

_state = {
    "min_seen": 100.0,   # smallest item size observed so far
    "count": 0.0,
}


def priority(item, bins):
    st = _state
    it = float(item)
    if it < st["min_seen"]:
        st["min_seen"] = it
    st["count"] += 1.0

    bins_f = bins.astype(np.float64)
    residual = bins_f - it

    # Smallest item we might still see (use 1 until we've seen something small).
    min_hold = st["min_seen"]
    if min_hold < 1.0:
        min_hold = 1.0

    # Sliver-avoidance: a residual that can never hold another item is as good
    # as a perfectly closed bin.  Map any residual < min_hold to 0.
    usable = np.where(residual < min_hold, 0.0, residual)

    # Lower usable residual is better; add a small bonus for genuinely closed
    # bins so cleanly-finishing placements win.
    score = -usable + 0.5 * (usable < 1e-9)

    return score
# EVOLVE-BLOCK-END
