# EVOLVE-BLOCK-START
"""Online bin selection via expected future coverage of residual capacity."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.ones(101, dtype=np.float64)  # item sizes 1..100
        self.count = 101.0

    def update(self, item):
        self.hist[item] += 1.0
        self.count += 1.0


_S = _State()


def priority(item, bins):
    s = _S
    s.update(item)

    p = s.hist / s.count
    p[0] = 0.0

    # residual capacity after placing item in each candidate bin
    resid = (bins - item).astype(np.float64)

    # Expected number of future items packable into a residual of capacity r,
    # via the renewal/coverage recursion: V(r) = sum_i p_i * (1 + V(r-i)) for i<=r.
    # Precompute V for capacities 0..100 (only needs up to 100).
    V = np.zeros(101, dtype=np.float64)
    # p_i for sizes 1..100; use a tapered tail to keep V bounded (V can grow)
    # We compute V exactly with the self-consistent approximation:
    # V(r) = (F(r) + sum_{i<=r} p_i * V(r-i)) where F(r)=P(item<=r).
    # Solve greedily since V(r) depends only on smaller capacities.
    csum = np.cumsum(p)  # csum[r] = P(size <= r)
    for r in range(1, 101):
        acc = csum[r]
        total = 0.0
        for i in range(1, r + 1):
            if p[i] > 0.0:
                total += p[i] * V[r - i]
        V[r] = acc + total

    fill_est = V[np.clip(resid, 0, 100).astype(np.int64)]

    # Primary: prefer bins whose residual after placement is well "covered"
    # by expected future items (rewards reusable slack), with a mild tightness
    # preference so we don't waste capacity.
    tight = -resid

    score = 2.0 * fill_est + 0.5 * tight

    return score
# EVOLVE-BLOCK-END
