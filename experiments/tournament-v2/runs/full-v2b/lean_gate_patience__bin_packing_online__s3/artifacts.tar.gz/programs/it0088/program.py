# EVOLVE-BLOCK-START
"""Online adaptive best-fit with mean-residual preference."""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0.0
        self.mean = 40.0
        self.hist = np.ones(101, dtype=np.float64)
        self.hist_sum = 101.0


_state = _State()


def priority(item, bins):
    st = _state

    st.count += 1.0
    st.hist[item] += 1.0
    st.hist_sum += 1.0
    st.mean = (st.mean * (st.count - 1.0) + item) / st.count

    residual = bins.astype(np.float64) - item  # remaining capacity after placing here

    # Primary: classic best-fit -> smallest non-negative residual (win = highest score)
    score = -residual

    # Secondary: prefer residuals close to the running mean item size, since that
    # residual is most likely to be exactly filled by a typical upcoming item.
    m = max(st.mean, 1e-6)
    score += 0.02 * (-np.abs(residual - m))

    return score
# EVOLVE-BLOCK-END
