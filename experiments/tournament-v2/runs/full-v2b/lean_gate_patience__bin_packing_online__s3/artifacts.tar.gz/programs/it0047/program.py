# EVOLVE-BLOCK-START
"""Best-fit with empirical modal-residual matching bonus."""
import numpy as np


class _Model:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def update(self, item):
        self.counts[item] += 1.0
        self.total += 1.0


_MODEL = _Model()


def priority(item, bins):
    global _MODEL
    m = _MODEL
    m.update(int(item))

    # Pure best-fit baseline: prefer smallest remaining bin that still fits.
    # tight = -(bins - item); larger (less negative) means tighter fit.
    tight = -(bins - item)

    residual = bins - item  # post-placement leftover

    # Empirical frequencies of item sizes (smoothed with uniform prior).
    counts = m.counts
    total = m.total
    if total > 0:
        freq = (counts + 1.0) / (total + 100.0)
    else:
        freq = np.full(101, 1.0 / 100.0)

    # Modal residual value: the frequently-occurring size whose exact residual
    # is most valuable to leave behind.
    modal = int(np.argmax(freq[1:101])) + 1
    modal_freq = float(freq[modal])

    # Strong bonus when residual exactly equals the modal size (that fragment
    # can be filled exactly later), scaled by how common that size is.
    bonus = np.where(residual == modal, modal_freq * 5.0, 0.0)

    score = tight + bonus
    return score
# EVOLVE-BLOCK-END
