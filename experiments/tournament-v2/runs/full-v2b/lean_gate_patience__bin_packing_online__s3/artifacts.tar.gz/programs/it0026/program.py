"""Best-fit with a least-full tie-break among equally tight fits."""
import numpy as np

BIG = 1000.0


def priority(item, bins):
    """Rank bins by best-fit tightness; break ties toward the least-full bin."""
    b = bins.astype(np.float64)
    # Primary: tightest fit (maximize item - residual).
    # Secondary: among equal residuals, prefer larger residual (less full bin).
    return (item - b) * BIG - b
