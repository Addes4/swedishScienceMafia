"""Best-Fit variant: prefer tightest fit, but penalize residuals too small to fit
the running mean item size (they are effectively wasted), so we favor placements
that keep a usable remainder."""
import numpy as np

_state = {"sum": 0, "n": 0}


def priority(item, bins):
    n = _state["n"]
    s = _state["sum"]
    mean = (s / n) if n > 0 else item
    _state["sum"] = s + item
    _state["n"] = n + 1

    # residual after placing item into each bin
    residual = bins - item
    np.maximum(residual, 0, out=residual)

    # Base: best-fit (prefer smallest residual) -> score = -residual
    score = -residual.astype(np.float64)

    # Penalize residuals that are small but nonzero and can't fit a typical item:
    # such a leftover is mostly wasted space, so slightly lower its score.
    thresh = mean
    dead = (residual > 0) & (residual < thresh)
    score[dead] -= 1.0

    return score
