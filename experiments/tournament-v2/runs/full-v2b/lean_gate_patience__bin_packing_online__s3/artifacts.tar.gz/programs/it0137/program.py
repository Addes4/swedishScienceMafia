# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware tie-breaking and fresh-bin reservation.

Primary criterion is still tightest fit (smallest post-placement residual),
which is near-optimal for this distribution. Ties are broken by preferring
bins whose residual is likely to be "usable" by future items from the
running histogram, and fresh bins are mildly de-prioritized unless the
arriving item is itself large (so we don't open fresh bins wastefully).
"""
import numpy as np

_STATE = {
    "hist": None,
    "count": 0.0,
    "ewma": 40.0,
}


def priority(item, bins):
    s = _STATE
    if s["hist"] is None:
        s["hist"] = np.zeros(101, dtype=np.float64)
    s["hist"][item] += 1.0
    s["count"] += 1.0
    s["ewma"] = 0.98 * s["ewma"] + 0.02 * item

    b = bins.astype(np.float64)
    resid = b - item

    # Primary: tightest fit -> larger score for smaller residual.
    score = -resid

    if s["count"] > 50:
        hist = s["hist"]
        cum = np.cumsum(hist)
        total = s["count"]

        ri = np.clip(resid.astype(np.int64), 0, 100)

        # Probability that a future item fits into this residual.
        p_fit = cum[ri] / total

        # Small tie-break bonus: prefer residuals that are likely usable.
        # Scaled tiny so it only breaks near-ties, never overrides tightness.
        eps = 1e-3
        score = score + eps * p_fit

        # Fresh-bin reservation: unused bins have residual 100 == bins==100.
        # De-prioritize opening a fresh bin unless item is large.
        is_fresh = (b >= 100.0)
        ewma = s["ewma"]
        # resistance grows when recent items are small (we expect more small
        # items that could fill leftovers rather than needing a fresh bin).
        smallness = max(0.0, min(1.0, (ewma - 25.0) / 25.0))  # 0 small .. 1 large
        fresh_penalty = 2e-3 * (1.0 - smallness)
        score = score - fresh_penalty * is_fresh

    return score
# EVOLVE-BLOCK-END
