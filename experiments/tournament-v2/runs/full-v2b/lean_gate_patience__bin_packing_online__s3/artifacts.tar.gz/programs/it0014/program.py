# EVOLVE-BLOCK-START
"""Best-fit tightness with a tiny fill-fraction tiebreaker."""
import numpy as np


def priority(item, bins):
    """Score bins by tightness (item - residual), plus a small fuller-bin bonus."""
    residual = bins.astype(np.float64)
    # Primary: best-fit -> prefer smallest residual that still fits.
    score = -residual
    # Tiebreaker: slight preference for fuller bins (small residual).
    score = score - 0.01 * (residual / 100.0)
    return score
# EVOLVE-BLOCK-END
