# EVOLVE-BLOCK-START
"""Online bin-selection: best-fit with mean-aligned slack tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.ones(101, dtype=np.float64)
        self.count = 101.0
        self.sum = 101.0 * 40.0

    def update(self, item):
        self.hist[item] += 1.0
        self.count += 1.0
        self.sum += item

    @property
    def mean(self):
        return self.sum / self.count


_S = _State()


def priority(item, bins):
    s = _S
    s.update(item)

    resid = bins - item  # nonnegative; only fitting bins are passed
    resid_f = resid.astype(np.float64)

    mean_item = s.mean
    if mean_item < 1e-6:
        mean_item = 1.0

    # Primary: best-fit -> smaller residual is better (tight packing).
    # Tie-break: reward residuals that are close to a whole number of mean-item
    # "slots", so the leftover slack can be cleanly refilled by typical items.
    # Compute distance from resid to nearest multiple of mean_item.
    k = np.round(resid_f / mean_item)
    slack_waste = np.abs(resid_f - k * mean_item)
    # Normalize into a small bonus in [-0.5, 0].
    tie = -0.5 * np.clip(slack_waste / mean_item, 0.0, 1.0)

    return -resid_f + tie
# EVOLVE-BLOCK-END
