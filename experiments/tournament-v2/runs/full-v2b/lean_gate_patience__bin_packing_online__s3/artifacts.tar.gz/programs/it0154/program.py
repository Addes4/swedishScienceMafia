# EVOLVE-BLOCK-START
"""Best-fit bin choice with a future-usability tie-break."""
import numpy as np


class _State:
    def __init__(self):
        self.min_item = 101

    def observe(self, item):
        if item < self.min_item:
            self.min_item = item


_state = _State()


def priority(item, bins):
    """Best-fit: smallest post-placement residual wins; tie-break by future fillability."""
    _state.observe(item)

    residual = bins - item  # int64, all >= 0

    # Primary: smaller residual is better (best-fit).
    score = -residual.astype(np.float64)

    # Secondary tiny term: prefer residuals that are hard to reuse further
    # (i.e., smaller than the smallest item yet seen), so perfectly-closed
    # bins sort ahead of barely-open ones with the same residual.
    min_item = _state.min_item
    if min_item > 1:
        closed = residual < min_item
        score += closed * 1e-3
        # Among closed bins, prefer the tightest (smallest residual).
        score += closed * (-residual.astype(np.float64)) * 1e-6

    return score
# EVOLVE-BLOCK-END
