# EVOLVE-BLOCK-START
"""Best-fit with a small tie-break bonus for residuals matching common item sizes."""
import numpy as np

_SIZE = 101
_HIST = np.ones(_SIZE, dtype=np.float64)
_COUNT = float(_SIZE)
_DECAY = 0.998


def priority(item, bins):
    global _HIST, _COUNT
    # update running distribution of past item sizes (decayed histogram)
    _HIST *= _DECAY
    _HIST[item] += 1.0
    _COUNT = _COUNT * _DECAY + 1.0
    hist = _HIST / _COUNT

    residual = bins - item  # remaining capacity after placing (>=0)

    # Primary term: best-fit -> minimize residual strongly.
    best_fit = -residual.astype(np.float64)

    # Secondary tie-break: reward residuals that equal a frequently occurring
    # past item size (so that fragment is likely consumed exactly later).
    frag_bonus = hist[np.clip(residual, 0, 100)]

    # Small weight so it only breaks ties among near-equal residuals.
    return best_fit + 0.01 * frag_bonus * 100.0
# EVOLVE-BLOCK-END

