"""Best-Fit with quantized tightness and fullest-bin tie-break."""
import numpy as np


def priority(item, bins):
    """Rank bins: classic Best-Fit, with near-ties broken toward the fullest bin.

    Score = -(residual) as primary tightness, but we quantize the residual into
    small buckets so that bins leaving almost the same space are treated as ties;
    within a bucket we prefer the bin with the least remaining capacity (fullest),
    which reduces fragmentation and discourages opening fresh bins.
    """
    b = bins.astype(np.int64)
    residual = b - item

    # Quantize tightness to ~4-unit buckets: distinct fits dominate, near-ties
    # collapse so the secondary key can act.
    tight_bucket = residual // 4

    # Primary: tighter fit (larger bucket). Secondary: fuller bin (smaller b).
    # Multiply primary by a large factor so it always dominates the secondary term,
    # whose magnitude is bounded by 100.
    return (1000 - tight_bucket.astype(np.float64)) * 200.0 - b.astype(np.float64)
