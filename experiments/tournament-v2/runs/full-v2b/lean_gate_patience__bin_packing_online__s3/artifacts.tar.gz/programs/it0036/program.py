# EVOLVE-BLOCK-START
"""Adaptive best-fit with a fresh-bin penalty modulated by recent item pressure."""
import numpy as np


class _State:
    def __init__(self):
        # exponential moving averages of recent item sizes
        self.mean = 40.0
        self.var = 100.0
        self.count = 0
        self.lam = 0.0 if False else 0.06


_state = _State()


def priority(item, bins):
    """Score bins by best-fit tightness minus an adaptive penalty for high remaining capacity.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state

    # Update running statistics with the arriving item (no future info used).
    x = float(item)
    st.count += 1
    alpha = 0.02 if st.count > 50 else 0.1
    delta = x - st.mean
    st.mean += alpha * delta
    st.var += alpha * (delta * delta - st.var)

    # Item-size pressure: high when items are large and/or variable.
    # Mean around 40, std around 20 for this distribution.
    pressure = st.mean / 100.0 + 0.5 * (st.var ** 0.5) / 100.0

    # Lambda: stronger fresh-bin penalty when pressure is high, weaker when low.
    # Baseline lambda ~0.06; vary within a modest range so behavior stays near best-fit.
    lam = 0.04 + 0.08 * min(max(pressure, 0.0), 1.0)
    st.lam = lam

    # Best-fit base score: tighter fit (smaller remaining after placement) is better.
    # Penalize large remaining capacity (fresh-ish bins) by lam * remaining.
    return -(bins - item) - lam * bins
# EVOLVE-BLOCK-END
