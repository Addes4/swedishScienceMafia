# EVOLVE-BLOCK-START
"""Adaptive best-fit with dynamic fresh-bin resistance.

Score = tightness minus an adaptive penalty that pushes items away from
large-residual bins when recent items have been large, reserving big empty
bins for future large items. The resistance adapts via a running EWMA of
item sizes and a histogram-based estimate of item-size pressure.
"""
import numpy as np

_STATE = {
    "ewma": 40.0,        # EWMA of observed item sizes
    "count": 0.0,        # number of items seen
    "hist": None,        # running histogram of item sizes (101 bins, index = size)
}


def priority(item, bins):
    s = _STATE

    # --- update running statistics with the arriving item ---
    if s["hist"] is None:
        s["hist"] = np.zeros(101, dtype=np.float64)
    s["hist"][item] += 1.0
    s["count"] += 1.0
    s["ewma"] = 0.98 * s["ewma"] + 0.02 * item

    ewma = s["ewma"]

    # Pressure: how large recent items are relative to half capacity.
    # Under high pressure we penalize fresh (large-residual) bins harder so
    # their space is saved for similarly-large future items.
    pressure = max(0.0, min(1.0, (ewma - 40.0) / 40.0))

    # Preferred residual after placing the item: tighter when pressure low,
    # larger slack tolerated when pressure high only for small items.
    # Base tightness term:
    tightness = -(bins.astype(np.float64) - item)

    # --- adaptive fresh-bin penalty ---
    # residual after placement
    resid = bins.astype(np.float64) - item
    # Count of past items that could still fit in this residual (histogram).
    hist = s["hist"]
    resid_int = np.clip(resid.astype(np.int64), 0, 100)
    # cumulative counts of items with size <= r
    cum = np.cumsum(hist)
    fit_count = cum[resid_int]

    # Expected smallness of refillable items: prefer bins whose residual is
    # near the size of typical recent items (so they can be topped off).
    # Penalize residuals much larger than typical item size (wasted space).
    penalty = 0.0
    if s["count"] > 20:
        # fraction of bins' residual usable given item distribution
        # we want residuals that are multiples close to ewma (pack well)
        mismatch = np.abs(resid - ewma) / (ewma + 1e-9)
        # fresh-bin resistance scales with pressure
        fresh_resist = (1.0 + 2.0 * pressure) * mismatch
        # additionally softly discourage leaving residual that can't hold any
        # moderately-sized upcoming item
        unusable = (fit_count < 1.0).astype(np.float64)
        penalty = 0.5 * fresh_resist + 0.3 * unusable * (1.0 + pressure)

    return tightness - penalty
# EVOLVE-BLOCK-END
