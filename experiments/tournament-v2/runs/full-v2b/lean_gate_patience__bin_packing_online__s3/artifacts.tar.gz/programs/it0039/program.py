# EVOLVE-BLOCK-START
"""Best-fit with a histogram-driven residual-usefulness bonus."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of observed item sizes (1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0
        self.decay = 0.999


_state = _State()


def priority(item, bins):
    st = _state

    # Update histogram of item sizes seen so far.
    st.count += 1
    st.hist[item] += 1.0

    # Probability that a future item of at most bin's residual will arrive,
    # approximated by the empirical histogram (smoothed, no future info).
    hist = st.hist
    total = hist.sum()
    if total < 20.0:
        # Not enough data: pure best-fit.
        return -(bins - item)

    # Build a "usefulness" curve of residual r: expected chance we can still
    # place a future item into a bin with residual exactly r (i.e., some item
    # size <= r exists). Since hist is density over sizes, usefulness(r) is
    # high when many common sizes fit within r but r is not wastefully large.
    # We approximate it with the cumulative mass of sizes <= r, mildly
    # weighted to prefer tighter but still usable residuals.
    cdf = np.cumsum(hist) / total  # cdf[s] = P(item <= s)

    # Residual after placing into each bin.
    resid = bins - item  # resid >= 0 by contract

    # Usability: probability that at least one of the next few items fits.
    # Use small-sample correction: p ~ 1 - (1-cdf)^k with k ~ 8.
    k = 8.0
    fit_prob = 1.0 - (1.0 - cdf[resid]) ** k

    # Base: best-fit (prefer small residual). Bonus: residual is usable.
    # Penalty proportional to residual to slightly resist opening fresh bins.
    base = -(resid)
    bonus = 2.0 * fit_prob
    penalty = 0.02 * resid

    return base + bonus - penalty
# EVOLVE-BLOCK-END
