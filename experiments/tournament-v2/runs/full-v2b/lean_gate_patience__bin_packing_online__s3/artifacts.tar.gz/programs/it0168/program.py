"""Online bin packing: two-regime best-fit with density-aware tie-breaking.

Rank bins so that a placement which leaves a residual too small to ever hold
another item is strongly preferred (closing the bin cleanly). Otherwise prefer
tight fits, but bias slightly toward residuals whose fill density relative to
the running mean item size is high, avoiding leaving huge gaps in bins we open.
"""
import numpy as np

_cnt_min = 101          # smallest item size observed so far
_total = 0.0
_sum = 0.0


def priority(item, bins):
    global _cnt_min, _total, _sum

    s = int(item)
    if s < _cnt_min:
        _cnt_min = s
    _total += 1.0
    _sum += s

    mean = _sum / _total if _total > 0 else 40.0
    if mean < 1e-9:
        mean = 40.0

    n = bins.shape[0]
    scores = np.empty(n, dtype=np.float64)

    min_size = _cnt_min if _cnt_min <= 100 else 1
    inv_mean = 1.0 / mean

    for i in range(n):
        b = int(bins[i])
        residual = b - s

        if residual < min_size:
            # Closing the bin: best possible outcome, rank by how full it ends.
            scores[i] = 1e6 - residual
        else:
            # Tightness in units of mean item size (smaller better), plus a mild
            # penalty for very large residuals (poor density if we leave a gap).
            r = residual * inv_mean
            scores[i] = -r - 0.02 * r * r

    return scores
