# EVOLVE-BLOCK-START
"""Size-class moderate-fit rule.

Large items (>= 50) consume most of a bin, so they use tight best-fit.
Smaller items use a "moderate fit": place them where the post-placement
residual is closest to a target of item + mean/2, which tends to leave
bins at a residual scale useful for the next large item.
"""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0
        self.count = 0.0

    def observe(self, item):
        self.count += 1.0
        a = 1.0 / min(self.count, 200.0)
        self.mean += a * (item - self.mean)


_state = _State()


def priority(item, bins):
    _state.observe(item)
    obj = np.asarray(bins, dtype=np.int64)
    rem = obj - item  # residual after placement

    if item >= 50:
        # tight best fit: smallest residual wins, tie-break to more-used bin
        score = -rem.astype(np.float64) * 1e6 - (100.0 - obj.astype(np.float64))
    else:
        # moderate fit: target residual = item + half the typical item size
        target = item + 0.5 * _state.mean
        diff = np.abs(rem.astype(np.float64) - target)
        # prefer diff closest to target, tie-break to more-used bin
        score = -diff * 1e6 - (100.0 - obj.astype(np.float64))
    return score
# EVOLVE-BLOCK-END
