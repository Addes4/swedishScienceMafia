# EVOLVE-BLOCK-START
"""Best fit with a gentle, item-scaled fresh-bin penalty.

Plain best fit (minimize residual after placement) is a very strong online
rule here.  The one systematic loss it suffers is opening a fresh bin while an
existing open bin could still accept the item, wasting the leftover space of
that open bin.  We add a small penalty proportional to the fresh-bin indicator
(residual after placement close to a full empty bin), scaled by item size so
that large items (which rarely fit leftovers anyway) are largely unaffected
and small items are gently discouraged from consuming a brand-new bin.
"""
import numpy as np

_FULL = 100.0


def priority(item, bins):
    residual = bins - item  # capacity left if item goes here

    # Fresh-bin indicator: residual very close to a full empty bin (>= 100-item
    # means this bin was empty before placement).  Penalize mildly.
    # Strength grows with item size up to a modest cap.
    lam = 0.03 * item
    if lam > 2.0:
        lam = 2.0

    fresh = residual >= (_FULL - item)  # empty before placement
    penalty = lam * fresh.astype(np.float64)

    return -(residual.astype(np.float64) + penalty)
# EVOLVE-BLOCK-END
