# EVOLVE-BLOCK-START
"""Adaptive best-fit with residual-fit penalty based on running size histogram."""
import numpy as np

# Running histogram of past item sizes (1..100)
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Score bins by best-fit tightness plus a penalty for leaving unusable residue."""
    global _hist, _total

    residual = bins - item  # remaining capacity after placing item

    # Best-fit tightness: prefer small residual (relative to item).
    # Use harmonic-like term: for residual r>=0, score decreases with r.
    # -(residual + 1) gives strong preference for smallest residual;
    # we scale by a smooth function.
    tightness = -1.0 / (residual + 1.0)

    # Estimate typical item size from histogram.
    if _total > 0:
        sizes = np.arange(101)
        mean_size = (sizes * _hist).sum() / _total
    else:
        mean_size = 40.0

    # Penalty: if residual is positive but smaller than a typical small item,
    # it becomes wasted/unusable. Reward residuals that can still fit mean-sized items,
    # penalize tiny non-zero residues.
    # Fit quality of residual r: how well does r align with multiples of mean_size?
    safe_mean = max(mean_size, 1.0)
    # Usable fraction estimate: r / mean_size, capped; tiny r -> near 0 usable.
    usable = residual / safe_mean
    # Saturating function so that larger residual is better (more room).
    usable_score = usable / (1.0 + usable)

    # Combine: primary is tightness, but penalize tiny residues.
    # Weight usable_score positively but small relative to tightness.
    w = 0.35
    score = tightness + w * usable_score

    # Update histogram after scoring (state for future calls).
    _hist[item] += 1.0
    _total += 1.0

    return score
# EVOLVE-BLOCK-END
