import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "sumsq": 0.0,
    "last_items": [],
    "recent": [],
}


def priority(item, bins):
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["sumsq"] += item * item
    st["recent"].append(item)
    if len(st["recent"]) > 50:
        st["recent"].pop(0)

    n = st["n"]
    mean = st["sum"] / n
    var = max(0.0, st["sumsq"] / n - mean * mean)
    sd = var ** 0.5

    # Pressure in [0,1]: larger items / higher variance => tighter packing preferred.
    pressure = min(1.0, max(0.0, (mean - 25.0) / 45.0 + (sd - 15.0) / 60.0))

    # lambda: reluctance to open fresh bins. Small when items are large (prefer tight fits),
    # larger when items are small (avoid opening fresh bins needlessly).
    lam = (1.0 - pressure) * 4.0

    rem = bins.astype(np.float64)
    fresh = (rem >= 100.0 - 1e-9)

    # Tightness score: prefer bins leaving little residual slack after placement.
    slack_after = rem - item
    tight = -slack_after

    # Penalize opening/using fresh bins.
    score = tight - lam * fresh.astype(np.float64)

    return score
