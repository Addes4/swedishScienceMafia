# EVOLVE-BLOCK-START
"""Clean Best-Fit: choose the bin minimizing the post-placement residual capacity."""
import numpy as np


def priority(item, bins):
    """Score each bin by its post-placement residual; smaller residual => higher score.

    The item fits in every bin shown, so residual = bins - item >= 0.
    Ties (equal residuals) go to the first bin, which matches classic best-fit.
    """
    return -(bins - item)
# EVOLVE-BLOCK-END
