# EVOLVE-BLOCK-START
"""Adaptive histogram-aware best fit with fresh-bin pressure penalty."""
import numpy as np


class _State:
    def __init__(self):
        # running histogram of item sizes (1..100)
        self.hist = np.ones(101, dtype=np.float64)
        self.count = 1.0
        # EWMA of recent item sizes (pressure)
        self.ewma = 40.0
        # EWMA of residual capacity produced after placements (used for tuning)
        self.resid_ewma = 40.0

    def observe(self, item):
        self.hist[item] += 1.0
        self.count += 1.0
        a = 0.05
        self.ewma = (1.0 - a) * self.ewma + a * item


_state = _State()


def priority(item, bins):
    st = _state
    st.observe(item)

    # normalize histogram to probability
    p = st.hist / st.count

    # For each bin, residual r = bins - item.
    # Score = tightness (prefer small residual) + fillability bonus - fresh penalty.
    res = bins.astype(np.float64) - float(item)

    # Tightness: negative residual (best-fit-like). Deep tightness under low pressure.
    tight = -res

    # Fillability: expected value of "useful fill" for a residual r.
    # Approximate expected number of items fitting in r times their size,
    # scaled to avoid dominating tightness. Use distribution mass of sizes <= r.
    sizes = np.arange(101, dtype=np.float64)
    pm = p * sizes  # weighted by size
    cum_p = np.cumsum(p)  # CDF
    # Expected coverage ~ sum over sizes s<=r of p[s]*s
    # Compute per-residual via searchsorted-based accumulation.
    idx = np.clip(res.astype(np.int64), 0, 100)
    # cumulative weighted mass up to idx
    weighted_cum = np.cumsum(pm)
    fillable = weighted_cum[idx]  # in units of expected item size mass

    # Fresh-bin penalty: bins with large residual (esp. empty bins at 100) are penalized
    # more strongly when recent items are large (high pressure).
    pressure = np.clip(st.ewma / 100.0, 0.0, 1.0)
    fresh = np.where(res >= 100 - item, 1.0, 0.0)  # untouched bins
    fresh_pen = (0.5 + 3.0 * pressure) * fresh * res

    # Spread of bin choices also mildly prefers avoiding medium residuals under pressure.
    medium_pen = pressure * np.maximum(res - 50.0, 0.0) * 0.05

    score = tight + 0.15 * fillable - fresh_pen - medium_pen
    return score
# EVOLVE-BLOCK-END
