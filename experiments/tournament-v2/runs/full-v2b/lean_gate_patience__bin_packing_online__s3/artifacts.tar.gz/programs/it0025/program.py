"""Best-fit with a leftover-reuse bonus keyed on recently seen item sizes."""
import numpy as np

_state = {"sum": 0.0, "count": 0, "recent": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Rank bins: best fit, with a bonus when the residual matches a recent item size.

    Best fit (minimize leftover) is the dominant term. On top of it, we reward
    placements whose post-placement residual equals an item size observed
    recently, since such a residual can later be filled exactly, reducing waste.
    The recent-size set decays so it reflects the local item distribution.
    """
    s = _state
    s["sum"] += item
    s["count"] += 1

    # Decay recent-size histogram, then record this item.
    s["recent"] *= 0.995
    s["recent"][item] += 1.0
    rec = s["recent"]

    b = bins.astype(np.float64)

    # Best-fit: smaller residual after placement is better.
    residual = b - item
    tight = -residual

    # Reuse bonus: residual is a valid bin size (>=1) that has been seen recently.
    resid_int = np.rint(residual).astype(np.int64)
    valid = (resid_int >= 1) & (resid_int <= 100) & (np.abs(residual - resid_int) < 1e-6)
    bonus = np.zeros(b.shape[0], dtype=np.float64)
    bonus[valid] = rec[resid_int[valid]]

    # Normalize the bonus to a modest weight so it only breaks near-ties.
    denom = rec.max() if rec.max() > 0 else 1.0

    return tight + 0.5 * (bonus / denom)
