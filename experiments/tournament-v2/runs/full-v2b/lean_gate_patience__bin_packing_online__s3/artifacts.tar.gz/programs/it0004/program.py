# EVOLVE-BLOCK-START
"""Best fit with perfect-fill bonus and fuller-bin tie-breaking."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Tightest fit: smaller leftover is better.
    score = -leftover.astype(np.float64)
    # Perfect fill bonus: strongly prefer exact fits.
    score += np.where(leftover == 0, 1e-3, 0.0)
    # Slight preference for fuller bins (smaller leftover) to concentrate load.
    score -= 1e-6 * leftover.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
