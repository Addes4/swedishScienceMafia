"""Best-fit anchored rule with an exact-fit probability bonus.

Score = -residual (classic best fit) plus a small bonus for residuals that
past items have exactly matched (estimated from a running histogram). This
keeps the strong best-fit behavior while slightly preferring residuals that
can later be filled perfectly.
"""

import numpy as np

STATE = {
    "hist": np.zeros(101, dtype=np.float64),
    "n": 0.0,
}


def priority(item, bins):
    st = STATE
    hist = st["hist"]

    bins = np.asarray(bins)
    k = bins.shape[0]
    if k == 0:
        return bins

    residuals = bins - item

    tight = -residuals.astype(np.float64)

    total = hist.sum()
    if total <= 0:
        scores = tight
    else:
        res_clipped = np.clip(residuals.astype(np.int64), 0, 100)
        # Historical mass of items equal to the residual (exact fill potential).
        exact = hist[res_clipped]
        # Normalize to a probability; give a modest bonus.
        bonus = 20.0 * (exact / total)
        scores = tight + bonus

    if 1 <= item <= 100:
        hist[item] += 1.0
        st["n"] += 1.0

    return scores
