# EVOLVE-BLOCK-START
"""Best-fit with adaptive hedge toward spreading, driven by running residual."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0.0
        # running mean of post-placement residual of the chosen bin
        self.avg_res = 50.0
        # running mean of item size
        self.avg_item = 40.0

    def observe(self, item, residual):
        self.n += 1.0
        a = 1.0 / min(self.n, 200.0)
        self.avg_item += a * (item - self.avg_item)
        self.avg_res += a * (residual - self.avg_res)


_S = _State()


def priority(item, bins):
    it = float(item)
    # residual if item goes into each bin
    residual = bins - it

    # Best-fit key: prefer smallest residual (most full bin that fits).
    # We add an adaptive penalty term that pushes toward leaving
    # "useful" residuals when recent packing has been leaving large slacks.
    # target_res is the residual we'd like to leave (roughly half the mean
    # item size) so a future item can still fit snugly.
    target = _S.avg_item * 0.5

    # hedge strength scales with how much leftover we've been generating
    slack_ratio = _S.avg_res / max(_S.avg_item, 1.0)
    lam = 0.15 * max(0.0, slack_ratio - 1.0)

    # best-fit (dominant) minus penalty for being far from the target residual
    score = -residual - lam * np.abs(residual - target)

    chosen = int(np.argmax(score))
    _S.observe(it, float(residual[chosen]))
    return score
# EVOLVE-BLOCK-END
