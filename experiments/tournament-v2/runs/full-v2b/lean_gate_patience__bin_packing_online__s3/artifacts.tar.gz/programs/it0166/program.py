"""Online bin packing via expected-fillability scoring.

We keep a running histogram of observed item sizes. For each candidate bin we
estimate how many future items could still be packed into the residual capacity
after placing the current item, using the empirical size distribution (an
efficient greedy knapsack-fill estimate). We combine that predicted "future
fill" with a fit-tightness term so that tight placements and well-utilizable
leftover capacity are both rewarded.
"""
import numpy as np

# Fixed histogram bins over sizes 1..100 (index 0 -> size 1).
_BINS = 100
_cnt = np.zeros(_BINS + 1, dtype=np.float64)   # empirical counts, size s -> index s
_total = 0.0

# running sums for the fill estimate
_sum = 0.0


def _expected_fill(cap):
    """Estimate #future items packable into `cap` using empirical distribution.

    Use expected item size to get a continuous estimate of the number of items
    that fit, with a mild cap so tiny residuals aren't overvalued.
    """
    if cap <= 0:
        return 0.0
    mean = _sum / _total if _total > 0 else 40.0
    if mean < 1e-9:
        mean = 40.0
    return cap / mean


def priority(item, bins):
    """Rank bins: reward tight fit and high expected future fillability."""
    global _total, _sum

    # Update running statistics with the arriving item (only past info used for scoring
    # choices below is fine; updating first is causal since current item is 'past' now).
    s = int(item)
    if 1 <= s <= _BINS:
        _cnt[s] += 1.0
    _total += 1.0
    _sum += s

    mean = _sum / _total if _total > 0 else 40.0
    if mean < 1e-9:
        mean = 40.0

    n = bins.shape[0]
    scores = np.empty(n, dtype=np.float64)

    # Fit tightness: reward small residual after placing the item.
    # Expected fillability: reward capacity that can still hold many future items.
    # We weight so that putting the item where leftover can be used well wins.
    for i in range(n):
        b = int(bins[i])
        residual = b - s
        # tightness: 1 when residual ~ 0, decreasing as residual grows
        tight = -residual
        # expected number of future items that fit in the residual
        fill = residual / mean
        # Combined: prefer tight placements, but value residual that still
        # can take a typical item (fill ~ 1 or more), penalize wasted big gaps.
        scores[i] = tight + 0.5 * fill * mean / (mean + residual + 1.0) * 100.0

    return scores
