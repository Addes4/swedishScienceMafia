# EVOLVE-BLOCK-START
"""Best fit with a small bonus for perfectly filling a bin."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    leftover = bins - item
    # Base: tightest fit (smallest leftover) gets highest score.
    score = -leftover.astype(np.float64)
    # Slight bonus when the bin is filled exactly (leftover 0).
    score += 0.5 * (leftover == 0)
    return score
# EVOLVE-BLOCK-END

