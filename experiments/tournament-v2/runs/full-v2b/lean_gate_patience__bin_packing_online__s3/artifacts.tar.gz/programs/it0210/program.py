# EVOLVE-BLOCK-START
"""Histogram-based future-fillability bin choice.

For each candidate bin, after hypothetically placing the item, we estimate the
expected amount of future item volume the residual capacity could absorb using
a greedy fill estimate against the running empirical distribution of observed
item sizes.  Bins whose residue can absorb more typical item volume are
preferred; a tiny best-fit term breaks ties toward tighter fits.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)   # counts of observed item sizes 1..100
_TOTAL = 0.0
# precomputed greedy "expected absorbed volume" lookup refreshed lazily
_CFG = None
_CFG_VERSION = -1
_VERSION = 0


def _expected_absorb(cap, probs, acc):
    """Greedy estimate of expected volume absorbable into capacity `cap`.

    acc[k] = expected number of items of size <= k needed (in expectation) to
    accumulate volume; we approximate by repeatedly using the best (largest)
    item that still fits with meaningful probability, weighted by its share.
    """
    if cap <= 0:
        return 0.0
    total = 0.0
    remaining = cap
    # Emulate greedy filling: at each step take the largest size that fits
    # with the observed distribution, consuming expected volume.
    sizes = np.nonzero(probs)[0]
    while remaining >= 1:
        fits = sizes[sizes <= remaining]
        if fits.size == 0:
            break
        k = fits[-1]
        p = probs[k]
        if p <= 0.0:
            break
        # expected number of this size before moving: geometric(p)
        expected_count = 1.0 / p
        usable = expected_count * k
        if usable >= remaining:
            total += remaining
            remaining = 0
        else:
            total += usable
            remaining -= usable
            # after taking all of this size, continue with smaller sizes
            sizes = fits[:-1]
    return total


def _rebuild():
    global _CFG, _CFG_VERSION
    if _TOTAL <= 0 or _CFG_VERSION == _VERSION:
        return
    probs = _HIST / _HIST.sum()
    top = 100
    cfg = np.zeros(top + 1, dtype=np.float64)
    for cap in range(1, top + 1):
        cfg[cap] = _expected_absorb(cap, probs, None)
    _CFG = cfg
    _CFG_VERSION = _VERSION


def priority(item, bins):
    global _TOTAL, _VERSION
    # update histogram with the current item's size
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _TOTAL += 1.0
        _VERSION += 1

    _rebuild()

    residual = bins - item          # hypothetical residue after placing item
    residual = np.maximum(residual, 0)

    if _CFG is None:
        # cold start: pure best fit
        return -(bins - item)

    # map residuals to expected absorbable volume
    idx = np.clip(residual, 0, 100)
    absorb = _CFG[idx]

    # prefer larger absorbable volume; tiebreak: tighter fit
    return absorb - 1e-3 * residual
# EVOLVE-BLOCK-END
