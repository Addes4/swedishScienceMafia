"""Online bin packing: best-fit with a "closing" bonus.

Rank bins so that a placement which leaves a residual too small to ever hold
another item (below the smallest size seen so far) is strongly preferred
(closing the bin cleanly). Otherwise prefer the tightest fit, scaled so that
residuals near a typical item size are treated as acceptable rather than
wasted.
"""
import numpy as np

_cnt_min = 101          # smallest item size observed so far
_total = 0.0
_sum = 0.0


def priority(item, bins):
    global _cnt_min, _total, _sum

    s = int(item)
    if s < _cnt_min:
        _cnt_min = s
    _total += 1.0
    _sum += s

    mean = _sum / _total if _total > 0 else 40.0
    if mean < 1e-9:
        mean = 40.0

    n = bins.shape[0]
    scores = np.empty(n, dtype=np.float64)

    # Smallest residual we consider "still usable": roughly one small item.
    min_size = _cnt_min if _cnt_min <= 100 else 1

    for i in range(n):
        b = int(bins[i])
        residual = b - s

        if residual < min_size:
            # Closing the bin: best possible outcome, rank by how full it ends.
            scores[i] = 1e6 - residual
        else:
            # Prefer tight fits, but treat residuals near a typical item size
            # as more valuable than tiny-but-unusable or huge gaps.
            # Rank primarily by residual (smaller better), as best-fit.
            scores[i] = -float(residual)

    return scores
