# EVOLVE-BLOCK-START
"""Simulated-completion bin choice using a running item-size histogram.

For each candidate bin we consider placing the arriving item, leaving residual
capacity r. We then simulate how well that residual space will be consumed by
typical future items, estimated from a running histogram of past item sizes.
A residual that matches a common item size (or a sum of common sizes) is
considered "useful"; a residual left as awkward slack is penalized. The bin
with the highest score (best expected utilization of its residual) wins.
"""
import numpy as np

# Running histogram of observed item sizes (1..100). Laplace-smoothed so that
# early calls still have a sensible distribution.
_HIST = np.ones(101, dtype=np.float64)
_HIST[0] = 1.0  # ignore index 0
_COUNT = 0.0

# Precompute a smoothing prior shape resembling a Weibull-ish distribution
# centered around ~40 so the first calls are reasonable.
def _make_prior():
    x = np.arange(101, dtype=np.float64)
    # crude Weibull-like density with mean ~40
    shape, scale = 1.5, 44.0
    pdf = (shape / scale) * (x / scale) ** (shape - 1.0) * np.exp(-(x / scale) ** shape)
    pdf[0] = 0.0
    pdf = np.nan_to_num(pdf)
    s = pdf.sum()
    if s <= 0:
        pdf = np.ones(101)
        pdf[0] = 0.0
        s = pdf.sum()
    return pdf / s

_PRIOR = _make_prior()


def _prob_vec():
    """Current smoothed probability vector over sizes 1..100 given the histogram."""
    p = _HIST / _HIST.sum()
    return p


def _fill_value(r, p, item_mean):
    """Estimate the value of residual capacity `r` given size distribution p.

    Use a cheap deterministic approximation: the expected packing efficiency of
    greedy filling capacity r with items drawn from p. We approximate by
    repeatedly subtracting the largest item size that still fits (from the
    distribution's cumulative structure) -- but to keep it fast we use a small
    analytical proxy:
      - if r equals or exceeds common item sizes, value is high (fully usable),
      - value penalized by the share of probability mass between r/2 and r
        (which would be wasted because a single item can't fill it).
    """
    if r <= 0:
        return -1e9
    # probability mass that can exactly-ish use the residual.
    # Full-utilization proxy: expected number of items needed weighted by fit.
    # Use the expected waste going from r to the next natural remainder.

    # Frequency of item sizes <= r (those that can still be placed in residual).
    usable = p[:r + 1].sum() if r < 100 else 1.0

    # Expected value: combine how close r is to typical item sizes and how much
    # usable mass remains. Reward residuals near multiples of mean, penalize
    # tiny awkward slacks far from any common item size.
    # Distance to nearest common item size (weighted by distribution).
    sizes = np.arange(101, dtype=np.float64)
    if r < 100:
        # item sizes in [1, r]
        sub = p[1:r + 1]
        ss = sizes[1:r + 1]
    else:
        sub = p[1:101]
        ss = sizes[1:101]
    tot = sub.sum()
    if tot <= 0:
        return -usable
    # Expected leftover after placing one item: r - E[size | size<=r]
    mean_fit = (ss * sub).sum() / tot

    # After placing one best-fitting item, residual r' = r - chosen size.
    # We value residual by its expected subsequent usability, approximated by
    # expected final fractional waste: penalty grows when mean_fit is far from r.
    leftover = r - mean_fit
    # Normalize leftover by mean item size: small leftover is "awkward".
    frac = leftover / item_mean if item_mean > 0 else 0.0

    # Reward low expected leftover (tight, well-aligned residual), reward high
    # usable mass.
    value = usable - 0.6 * frac
    return value


def priority(item, bins):
    global _COUNT
    n = len(bins)
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # Full residual for the simulated placement is bins (remaining capacity).
    # We place `item`, so residual becomes bins - item.
    resid = bins - item
    valid = resid >= 0
    if not valid.any():
        # Shouldn't happen (array only contains fitting bins), but be safe.
        return np.zeros(n, dtype=np.float64)

    # Build current distribution estimate (blend prior + observed, weighted by count).
    total = _COUNT + _HIST[1:].sum() - 100.0  # observed count-ish
    obs = _HIST.copy()
    # Smooth strongly to avoid noise dominating; weight prior by a prior strength.
    prior_strength = 40.0
    mixed = obs + prior_strength * _PRIOR * 100.0
    p = mixed / mixed.sum()
    item_mean = float((np.arange(101) * p).sum())

    scores = np.full(n, -1e9, dtype=np.float64)
    idx = np.nonzero(valid)[0]
    # Score each candidate residual.
    for i in idx:
        r = int(resid[i])
        scores[i] = _fill_value(r, p, item_mean)

    # Update running histogram with the current item (after scoring).
    _HIST[item] += 1.0
    _COUNT += 1.0

    # Ties: highest score; numpy argmax picks first on ties.
    return scores
# EVOLVE-BLOCK-END
