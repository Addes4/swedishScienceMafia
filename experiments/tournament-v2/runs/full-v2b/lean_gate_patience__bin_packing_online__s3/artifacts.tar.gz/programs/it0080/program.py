# EVOLVE-BLOCK-START
"""Greedy-lookahead bin choice: score bins by simulating future fills of the residual
using a running histogram of past item sizes."""
import numpy as np

# Running histogram of observed item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)
_count = 0


def priority(item, bins):
    global _hist, _count

    # Update running histogram with the arriving item.
    _hist[item] += 1.0
    _count += 1.0

    # Build a representative "typical item" profile from past sizes.
    # Use the empirical distribution's mean and spread to sample a small set
    # of representative items for lookahead.
    if _count < 8:
        # Not enough history: fall back to best fit.
        return -(bins - item)

    total = _hist.sum()
    sizes = np.nonzero(_hist)[0]
    probs = _hist[sizes] / total

    # Representative items: a handful of quantiles of the past distribution.
    # Weighted quantiles via cumulative probability.
    cum = np.cumsum(probs)
    qs = np.array([0.15, 0.35, 0.55, 0.75, 0.9])
    idx = np.searchsorted(cum, qs)
    idx = np.clip(idx, 0, len(sizes) - 1)
    reps = sizes[idx].astype(np.int64)

    n = bins.shape[0]
    scores = np.empty(n, dtype=np.float64)

    for i in range(n):
        rem = int(bins[i]) - item
        if rem < 0:
            # Should not happen (bins shown all fit), but guard.
            scores[i] = -1e18
            continue
        # Greedy fill simulation: repeatedly place the largest representative
        # item that fits, to estimate how many future items this residual absorbs.
        used = 0.0
        r = rem
        # small number of iterations to keep it cheap
        guard = 0
        while r > 0 and guard < 6:
            placed = False
            for s in reps[::-1]:
                s = int(s)
                if s <= r:
                    r -= s
                    used += 1.0
                    placed = True
                    break
            if not placed:
                break
            guard += 1
        # Also add a fractional term for leftover space to break ties smoothly.
        frac = r / 100.0
        # Score: prefer bins whose residual absorbs many future items,
        # tie-broken toward tighter packing (smaller residual).
        scores[i] = used - 0.5 * frac

    return scores
# EVOLVE-BLOCK-END
