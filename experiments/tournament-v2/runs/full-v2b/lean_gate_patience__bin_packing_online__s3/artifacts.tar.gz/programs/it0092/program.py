"""Best-fit with exact-fit-residual bonus.

Primary term: minimize residual (best fit). Secondary: reward residuals that
future items are likely to exactly fill, estimated from a running histogram of
past item sizes. Fresh bins (residual near capacity) are mildly preferred to be
kept open for large items via a small penalty gradient.
"""

import numpy as np

STATE = {
    "hist": np.zeros(101, dtype=np.float64),
    "n": 0.0,
}


def priority(item, bins):
    st = STATE
    hist = st["hist"]

    bins = np.asarray(bins)
    k = bins.shape[0]
    if k == 0:
        return bins

    residuals = bins - item
    res_f = residuals.astype(np.float64)
    res_i = residuals.astype(np.int64)

    # Primary: best fit (tightest residual).
    tight = -res_f

    total = hist.sum()
    if total > 0:
        # Probability that a future item exactly matches the residual.
        # Use a smoothed probability over residuals 0..100.
        p = hist / total
        # slight smoothing to avoid zero-probability dead ends
        p_smooth = (hist + 0.5) / (total + 50.5)
        res_clipped = np.clip(res_i, 0, 100)
        exact_bonus = p_smooth[res_clipped]
        # Scale into score units comparable to residual differences.
        exact_bonus = exact_bonus * 40.0
    else:
        exact_bonus = np.zeros(k, dtype=np.float64)

    scores = tight + exact_bonus

    if 1 <= item <= 100:
        hist[item] += 1.0
        st["n"] += 1.0

    return scores
