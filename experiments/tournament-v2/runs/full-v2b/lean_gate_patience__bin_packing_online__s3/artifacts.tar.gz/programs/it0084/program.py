# EVOLVE-BLOCK-START
"""Online best-fit with a histogram-based residual usefulness bonus."""
import numpy as np


class _State:
    def __init__(self):
        # histogram over item sizes 1..100 (laplace smoothed)
        self.hist = np.ones(101, dtype=np.float64)
        self.total = 100.0
        # precomputed usefulness table recomputed periodically
        self.useful = None
        self.since_rebuild = 0
        self.rebuild_every = 1


_state = _State()


def _build_useful(st):
    """For each residual capacity r in 0..100, estimate value gained by filling it.

    We compute, for each r, the best expected single-item fill using the histogram:
    max over item size s <= r of (s / r) weighted by probability, then approximate
    a greedy multi-item completion with a simple recursion over remaining capacity.
    """
    hist = st.hist
    total = st.total
    p = hist / total  # probability of each size 1..100

    # value[v] = expected fraction of capacity v that can be filled by greedy
    # best-fit completion using items drawn from p (approximation via one-step
    # lookahead: value[v] = max_s<=v p-scaled contribution).
    val = np.zeros(101, dtype=np.float64)
    # Precompute for each v the best single fill ratio times a mild continuation.
    for v in range(1, 101):
        # consider placing item of size s (s <= v), gain s/v plus continuation on v-s
        best = 0.0
        # iterate over plausible sizes using cumulative distribution weighting
        for s in range(1, v + 1):
            ps = p[s]
            if ps <= 0.0:
                continue
            gain = (s + val[v - s]) / v
            contrib = ps * gain
            if contrib > best:
                best = contrib
        val[v] = best
    return val


def priority(item, bins):
    st = _state

    # update histogram
    st.hist[item] += 1.0
    st.total += 1.0
    # mild decay to stay adaptive
    if st.total > 2000.0:
        st.hist *= 0.995
        st.total *= 0.995

    st.since_rebuild += 1
    if st.useful is None or st.since_rebuild >= st.rebuild_every:
        st.useful = _build_useful(st)
        st.since_rebuild = 0

    residual = bins - item  # 0..99 actually residual >= 0 since item fits
    # clip residual to [0,100] for table lookup
    r = residual.astype(np.int64)
    np.clip(r, 0, 100, out=r)

    # baseline: tight fit preference (small residual better)
    score = -residual.astype(np.float64)

    # usefulness bonus: bins whose residual is well-fillable get a bonus
    # weight so it perturbs ties but keeps best-fit dominant
    score += 3.0 * st.useful[r]

    return score
# EVOLVE-BLOCK-END
