import numpy as np

_state = {
    "min_item": 100.0,
    "count": 0.0,
}


def priority(item, bins):
    st = _state
    st["count"] += 1.0
    if item < st["min_item"]:
        st["min_item"] = float(item)
    min_seen = st["min_item"]

    n = bins.size
    resid = bins - item  # residual if placed here
    resid = np.clip(resid, 0, 100).astype(np.float64)

    # Best-fit basis: prefer the smallest residual.
    score = -resid

    # Bonus for placements that leave a residual too small to accept the
    # smallest item seen so far (a "dead" remainder wastes no usable space).
    dead = (resid >= 0) & (resid < min_seen)
    score = score + dead * 100.0

    return score
