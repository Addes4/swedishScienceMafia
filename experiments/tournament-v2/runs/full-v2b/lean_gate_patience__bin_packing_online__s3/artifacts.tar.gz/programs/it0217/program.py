# EVOLVE-BLOCK-START
"""Online stochastic future-fillability bin choice.

Idea: instead of best-fit (minimize the immediate residual), estimate how many
future items can be packed into the residual that remains *after* placing the
current item, assuming future items are drawn from the empirical distribution of
items seen so far.  A residual that can absorb many typical future items is a
"healthy" bin; a residual that fits almost nothing is waste.

We maintain a running histogram of observed item sizes.  For each candidate bin
we compute the post-placement residual r = bin_remaining - item and score it by
an estimate of the number of future items (and their total volume) greedily
packable into r.  Bins that fit the item but leave a well-utilizable residual
win.  Small self-preference tie-breaks keep early decisions sensible before the
histogram is meaningful.
"""
import numpy as np

# Number of items seen so far (module-level state, persists between calls).
_count = 0
# Empirical counts of observed item sizes 0..100.
_hist = np.zeros(101, dtype=np.float64)

# Precompute item sizes 1..100 for the greedy fill estimate.
_SIZES = np.arange(1, 101)


def _expected_fillable(residual):
    """Estimate future items packable into a bin of remaining capacity `residual`.

    Uses the empirical distribution of past items.  The greedy estimate places
    items from smallest to largest while they fit.  We approximate the two
    quantities we care about (number of items and volume absorbed) with a cheap
    deterministic fill: sort the observed sizes, and greedily consume capacity,
    weighting by the empirical probability of each size.

    To keep it O(1)-ish per bin we use precomputed expected-value tables keyed
    by residual.  Because residuals are integers 0..100, we can cache results.
    """
    return _fill_cache[residual]


# Caches computed lazily and refreshed when the histogram changes materially.
_fill_cache = np.zeros(101, dtype=np.float64)
_cache_version = -1.0


def _rebuild_cache():
    """Recompute the fillability estimate for every residual 0..100."""
    global _cache_version
    total = _hist.sum()
    if total <= 0:
        # No data yet: fall back to a flat prior (uniform sizes 1..100).
        prob = np.ones(101, dtype=np.float64)
        prob[0] = 0.0
        prob /= prob.sum()
    else:
        prob = _hist / total

    # Smallest-first greedy: for a given residual, walk sizes ascending and
    # count how many can be packed.  We compute an expected number of future
    # items and expected absorbed volume.
    # To do this efficiently for all residuals at once, use a simple DP that
    # mirrors "expected items if we could fill with the smallest available".
    # Approach: E[items] ~ sum over k of P(can place k-th item) is complex;
    # instead compute a deterministic fill using the mean size among fitting
    # items, which yields a smooth, monotone score.
    # Deterministic greedy: repeatedly take the smallest size that fits,
    # deterministically (mode weighted).  This gives a consistent, cheap value.
    for r in range(101):
        cap = r
        items = 0.0
        vol = 0.0
        # Greedy: consume using the order of increasing size.
        for s in range(1, 101):
            if s > cap:
                break
            p = prob[s]
            if p <= 0:
                continue
            # expected number of this size we can still place
            maxk = cap // s
            if maxk <= 0:
                continue
            # Expected count limited by probability mass and capacity.
            # Approximate: take expected count = p * total mapped to room.
            # Here we simply place as many as capacity allows, scaled by p.
            k = maxk
            use = min(k, cap // s)
            cap -= use * s
            items += use * p
            vol += use * s * p
        _fill_cache[r] = items + 0.02 * vol

    _cache_version = _hist.sum()


def priority(item, bins):
    global _count

    # Update empirical histogram with the arriving item.
    _hist[item] += 1.0
    total = _hist.sum()

    # Refresh the fillability cache periodically (not every call) for speed.
    if total != _cache_version:
        _rebuild_cache()

    # Post-placement residual for every candidate bin.
    residual = bins - item  # >= 0 by contract

    # Base score: future-fillability of the residual.
    scores = _fill_cache[residual]

    # Tie-break / early-decision guidance: prefer leaving a residual that is
    # neither too small (no room) nor a huge empty bin (waste).  A mild
    # best-fit flavour rewards tighter fits, but only weakly so the
    # fillability estimate dominates once data accumulates.
    # Weight grows with confidence (more observed items).
    conf = min(1.0, total / 200.0)
    # Tightness term: prefer smaller residual (classic best-fit), scaled down.
    scores = scores - (1.0 - conf) * 0.01 * residual

    # Avoid a perfectly empty bin when a reasonable fit exists: slight penalty
    # for putting the item into a completely unused bin far from full.
    scores = scores - 0.0005 * (bins == 100)

    return scores
# EVOLVE-BLOCK-END
