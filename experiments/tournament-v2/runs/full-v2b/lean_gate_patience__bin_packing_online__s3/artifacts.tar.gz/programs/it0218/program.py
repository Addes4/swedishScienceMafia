# EVOLVE-BLOCK-START
"""Online bin packing: classic Best-Fit.

Put the arriving item into the fitting bin whose remaining capacity after
placement is the smallest (tightest fit).  Ties go to the first bin, which the
harness handles.  This simple rule is extremely strong on Weibull-shaped sizes.
"""
import numpy as np


def priority(item, bins):
    # bins = remaining capacity of each bin the item fits in.
    # Post-placement residual: smaller is better (tightest fit).
    residual = bins - item
    return -residual
# EVOLVE-BLOCK-END
