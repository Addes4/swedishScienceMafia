"""Best-Fit with a light empirical-fillability tie-break."""
import numpy as np

# running histogram of item sizes seen so far
_hist = np.zeros(101, dtype=np.float64)
_count = 0


def priority(item, bins):
    global _hist, _count
    # update running histogram
    _hist[item] += 1.0
    _count += 1

    resid = bins.astype(np.int64)

    # Best-fit core: prefer smallest residual (tightest fit)
    best = -resid.astype(np.float64)

    # Light tie-break: bonus for residuals that are exact common sizes or
    # sums of two common sizes, so they can be liquidated later.
    # Build a cheap fillability score per residual using the running histogram.
    if _count >= 20:
        h = _hist
        # probability mass of sizes <= r (single item fits) and of two-item fills
        cdf = np.cumsum(h)
        # For each candidate residual r <= 100, estimate fraction of future items <= r
        # plus a small bonus for exact common sizes.
        idx = np.clip(resid, 0, 100)
        single = cdf[idx] / _count
        exact = h[idx] / _count
        # scale the tie-break small so best-fit stays dominant
        tie = 0.02 * single + 0.05 * exact
    else:
        tie = 0.0

    return best + tie
