# EVOLVE-BLOCK-START
"""Online bin packing: Best-Fit with a histogram-based "clean close" tiebreak.

The dominant rule is classic Best-Fit (put the item into the fitting bin whose
post-placement residual is smallest).  Among bins whose residuals are close to
the minimum, we break ties using a running histogram of observed item sizes:
a residual that is exactly reachable as a sum/size of typical future items is
slightly preferred, so bins tend to close cleanly instead of leaving awkward
gaps that later fragment the packing.
"""
import numpy as np

# Module-level state: histogram of observed item sizes (1..100).
_hist = np.zeros(101, dtype=np.float64)
_seen = 0
# Cache of "reachable" residual capacities given observed sizes (greedy).
_reachable = None


def _build_reachable():
    """Approximate set of residual capacities that can be exactly filled by
    greedy packing of observed-size items (a coarse 'can close cleanly' map)."""
    global _reachable
    sizes = np.nonzero(_hist)[0]
    if sizes.size == 0:
        _reachable = np.zeros(101, dtype=np.float64)
        return
    # Probability mass weighting: how desirable each capacity is as a target.
    reach = np.zeros(101, dtype=np.float64)
    weights = _hist[sizes] / _hist.sum()
    # For each capacity c, estimate how likely greedy packing can fill it well:
    # use a small DP over capacities up to 100 with expected item sizes.
    # Simple proxy: capacity is desirable if large enough to fit mean item,
    # weighted by proximity to actual observed sizes.
    order = np.argsort(sizes)
    sorted_sizes = sizes[order]
    sorted_w = weights[order]
    for c in range(1, 101):
        # best single observed size <= c (clean close), else fractional fill est.
        idx = np.searchsorted(sorted_sizes, c, side='right') - 1
        if idx >= 0:
            s = sorted_sizes[idx]
            reach[c] = 1.0 - (c - s) / 100.0
        else:
            reach[c] = c / 100.0
    _reachable = reach


def priority(item, bins):
    global _seen
    residual = bins - item

    # Update histogram lazily (only occasionally rebuild reachability cache).
    _hist[item] += 1.0
    _seen += 1
    if _reachable is None or _seen % 25 == 0:
        _build_reachable()

    # Dominant term: tightest fit (smaller residual better).
    tight = -residual.astype(np.float64)

    # Secondary term: prefer residuals that are "good targets" (clean close).
    reach = _reachable[residual.astype(np.int64).clip(0, 100)]

    # Small weight so tightness stays dominant.
    return tight + 0.5 * reach
# EVOLVE-BLOCK-END
