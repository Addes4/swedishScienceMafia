# EVOLVE-BLOCK-START
"""
Adaptive best-fit with a dynamic phase-aware bias.

The item is immediately placed into the bin with the highest score. We try to improve
on plain best fit by:
  * preferring bins whose residual capacity after insertion is small (best fit),
  * mildy penalizing unused bins to reduce needless bin openings,
  * adjusting the tradeoff over time using statistics of the item stream.
"""
import numpy as np


class _State:
    """Simple running state for the priority policy."""

    def __init__(self):
        self.n = 0
        self.total = 0.0
        self.mean = 40.0
        self.bins_opened = 0
        self.last_items = []
        self.waste = 0.0

    def observe_item(self, item):
        """Update item statistics using exponential smoothing."""
        self.n += 1
        self.total += item
        alpha = 0.02 if self.n > 100 else 0.2
        if self.n == 1:
            self.mean = float(item)
        else:
            self.mean = (1.0 - alpha) * self.mean + alpha * float(item)

        self.last_items.append(item)
        if len(self.last_items) > 64:
            self.last_items.pop(0)

    def observe_choice(self, residual_after):
        """Track how much waste the chosen placement produced."""
        if residual_after is not None:
            self.waste = 0.99 * self.waste + 0.01 * float(residual_after)


_state = _State()


def priority(item, bins):
    """Rank bins for an arriving item.

    Higher score is better; ties go to the first bin.  `bins` contains the residual
    capacity of every bin that can hold this item, in index order.
    """
    item = int(item)
    _state.observe_item(item)

    b = np.asarray(bins, dtype=np.float64)
    size = b.size
    if size == 0:
        return np.zeros(0, dtype=np.float64)

    # Apply capacity clipping for safety.
    fit = b >= item

    # Residual space that would remain if the item were placed here.
    residual = b - float(item)

    # Base score: prefer small residual (best fit).  Use a smooth monotone map so
    # very tight and moderately tight bins are distinguished without hard cutoffs.
    base = -residual

    # Bias: discourage opening brand-new bins (residual 100) slightly less when
    # recent items have been large, since a fresh bin may soon be needed anyway.
    # Warm up the bias from observed mean item size.
    mean_est = max(1.0, min(99.0, _state.mean))
    fresh_penalty = 0.6 + 0.8 * (mean_est / 100.0)
    fresh_mask = b >= 100
    score = base - fresh_penalty * fresh_mask.astype(np.float64)

    # Encourage using bins that will end up reasonably filled relative to the
    # empirical mean; this softly rewards a residual near one mean item or less.
    target = mean_est
    score += 0.08 * (-np.abs(residual - target))

    # Slight preference for bins already partially filled (i.e. not unused) to keep
    # the number of open bins low.
    used_mask = b < 100
    score += 0.05 * used_mask.astype(np.float64)

    # If the item fits nowhere among shown bins, all shown bins fit, by problem
    # statement, so `fit` should be all True; still guard.
    if not np.all(fit):
        score = np.where(fit, score, -1e9)

    return score


# EVOLVE-BLOCK-END
