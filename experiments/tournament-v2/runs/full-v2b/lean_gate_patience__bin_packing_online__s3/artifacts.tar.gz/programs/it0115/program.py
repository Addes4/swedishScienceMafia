# EVOLVE-BLOCK-START
"""Distribution-aware exact-refill bin choice.

Each candidate bin is scored by how tight the placement is (prefer small
post-placement residual) plus a bonus when the residual matches a likely
future item size, using a recency-weighted histogram of observed sizes.
"""
import numpy as np

_SIZE = 100
_ITEMS = np.arange(1, _SIZE + 1, dtype=np.float64)


class _Model:
    def __init__(self, decay=0.99):
        self.h = np.ones(_SIZE + 1, dtype=np.float64)  # Laplace smoothing
        self.h[0] = 0.0
        self.decay = decay
        self._n = 0

    def observe(self, item):
        self.h *= self.decay
        self.h[item] += 1.0
        self._n += 1
        if self._n % 512 == 0:
            s = self.h[1:].sum()
            if s > 0:
                self.h[1:] *= 100.0 / s

    def probs(self):
        p = self.h[1:].copy()
        s = p.sum()
        if s <= 0:
            return np.full(_SIZE, 1.0 / _SIZE, dtype=np.float64)
        return p / s


_model = _Model()


def priority(item, bins):
    _model.observe(item)
    p = _model.probs()

    res = bins.astype(np.float64) - float(item)

    # tightness: prefer small residual
    tightness = -res / 100.0

    # exact-refill bonus: probability mass near this residual size
    # smooth the pmf a little so nearby integer sizes share credit
    kernel = np.array([0.15, 0.7, 0.15])
    ps = np.convolve(p, kernel, mode="same")
    idx = np.clip(res.astype(np.int64), 0, _SIZE)
    # pmf evaluated at residual (size 0 has no mass -> fresh bins get 0 bonus)
    refill = ps[idx - 1] if False else np.where((res >= 1), ps[np.clip(idx - 1, 0, _SIZE - 1)], 0.0)

    score = tightness + 0.25 * refill
    return score
# EVOLVE-BLOCK-END
