# EVOLVE-BLOCK-START
"""Online stochastic reachability-fillability bin packing.

For each arriving item we score every feasible bin by estimating how well its
residual capacity (after placing the item) can be filled by future items, using a
running histogram of observed item sizes and a greedy continuous fill estimate.
We blend this expected fillability with fit tightness so that tightly-fitting bins
and easily-fillable residuals are both favored.
"""
import numpy as np

CAP = 100

# Running histogram of observed item sizes (1..100).
_hist = np.zeros(CAP + 1, dtype=np.float64)
_n = 0.0
# EWMA of item size for the fill estimate.
_mean = 40.0


def _greedy_fill(residual):
    """Estimate how many future items (size ~ _mean) fit into `residual`.

    Uses a continuous approximation: the number of items is roughly
    residual / mean, but we account for waste by a concave correction.
    Returns a nonneg float.
    """
    if residual <= 0:
        return 0.0
    m = _mean if _mean > 1e-9 else 40.0
    # Expected count if items were exactly mean-sized.
    q = residual / m
    # Penalize small residuals that can't hold even one typical item.
    if q < 1.0:
        return q * q  # smooth ramp to 0
    return q


def priority(item, bins):
    global _hist, _n, _mean

    # Update running histogram/mean with the current item (online estimate).
    _hist[item] += 1.0
    _n += 1.0
    _mean += (item - _mean) / _n if _n > 0 else 0.0
    if _n > 5000.0:
        # Keep mean responsive but bounded.
        pass

    b = np.asarray(bins, dtype=np.float64)
    residual = b - item  # residual after placing item; >= 0 for feasible bins
    residual = np.maximum(residual, 0.0)

    # Expected fillability of each residual.
    m = _mean if _mean > 1e-9 else 40.0
    q = residual / m
    fill = np.where(q < 1.0, q * q, q)

    # Fit tightness: reward small residuals (tight packing) mildly.
    # Normalize tightness into [0,1]-ish.
    tightness = 1.0 - residual / CAP

    # Combine: primary signal is fillability (how much future capacity we use),
    # secondary is tightness to break near-ties toward tightly packed bins.
    score = fill + 0.15 * tightness

    return score
# EVOLVE-BLOCK-END
