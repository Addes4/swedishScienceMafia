# EVOLVE-BLOCK-START
"""Tight best fit that defers fresh-bin usage.

Plain best fit occasionally opens a fresh bin when an existing open bin would
have been a better long-term choice (e.g. residual just above the item).  Here
we still prefer the tightest fit (smallest post-placement residual) but apply a
sizeable penalty to fresh bins (remaining capacity == 100) so they are used
only when no open bin is available.  This reserves empty bins for future large
items while keeping the strong tightness behaviour of best fit.
"""
import numpy as np

# Fixed penalty (in residual units) applied to fresh bins so that an open bin
# is essentially always preferred when its residual is even slightly larger.
_FRESH_PENALTY = 5.0


def priority(item, bins):
    residual = bins - item  # remaining capacity if item is placed here
    is_fresh = (bins >= 100)
    # Best fit: smallest residual wins.  Defer fresh bins with a penalty.
    score = -residual - _FRESH_PENALTY * is_fresh
    return score
# EVOLVE-BLOCK-END
