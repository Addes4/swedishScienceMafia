# EVOLVE-BLOCK-START
"""Online bin packing: Best-Fit with a perfect-fill tie-break.

Classic Best-Fit: choose the fitting bin with the smallest post-placement
residual (tightest fit).  We keep that as the dominant ordering, and add a
small correction that, for equal post-placement residuals, prefers the bin
that becomes exactly full (residual 0) and otherwise the heavier bin.  This
nudges the packer toward cleaning out bins without disturbing tightest-fit.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Dominant: tightest fit (smaller residual better).
    # Tiny correction for equal residuals: reward perfect fill (residual 0),
    # then prefer the fuller (pre-placement heavier) bin.
    perfect = (residual == 0)
    return -residual * 1000.0 + perfect * 1.0 + (bins * -1e-4)
# EVOLVE-BLOCK-END
