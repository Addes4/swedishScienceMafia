# EVOLVE-BLOCK-START
"""Histogram-aware best fit: prefer tight bins whose residual is refillable."""
import numpy as np


class _State:
    def __init__(self):
        # running histogram of item sizes (1..100), Laplace-smoothed
        self.hist = np.ones(101, dtype=np.float64)
        self.count = 1.0
        # slow EWMA of item sizes for pressure estimate
        self.ewma = 40.0

    def observe(self, item):
        self.hist[item] += 1.0
        self.count += 1.0
        a = 0.05
        self.ewma = (1.0 - a) * self.ewma + a * item


_state = _State()


def priority(item, bins):
    st = _state
    st.observe(item)

    p = st.hist / st.count           # probability of each size
    sizes = np.arange(101, dtype=np.float64)

    # Residual capacity after placing the item in each candidate bin.
    res = bins.astype(np.float64) - float(item)
    np.clip(res, 0.0, 100.0, out=res)

    # Approximate expected number of future items that fit into a residual r:
    # er = sum_{s=1..r} p[s]  (probability an item fits) times expected "packing"
    # factor. Use the mean item size to convert residual space into item slots.
    pm = p * sizes
    weighted_cum = np.cumsum(pm)            # sum_{s<=r} p[s]*s
    prob_cum = np.cumsum(p)                 # CDF
    mean_size = float(weighted_cum[-1]) if weighted_cum[-1] > 0 else 40.0

    idx = np.clip(res.astype(np.int64), 0, 100)
    # Expected fillable mass up to residual (weighted by item size == space used)
    fillable_mass = weighted_cum[idx]
    # Expected number of items that fit: prob_cum[r] * (r / mean_size)
    exp_items = prob_cum[idx] * (res / mean_size)

    # Score:
    #  - prefer small residual (tight / best fit) to pack densely
    #  - strongly reward residuals that are likely to be refilled
    #  - discourage bins whose residual is large and will likely be wasted
    pressure = np.clip(st.ewma / 100.0, 0.0, 1.0)

    tight = -res
    refill = exp_items + 0.5 * (fillable_mass / mean_size)

    # Penalize leaving large unusable-ish residuals, more under high pressure.
    waste = np.maximum(res - st.ewma, 0.0) * (0.3 + pressure)

    score = tight + 0.5 * refill - waste
    return score
# EVOLVE-BLOCK-END
