# EVOLVE-BLOCK-START
"""Best-Fit with an adaptive "keep-useful-residual" rule.

Core is classic Best-Fit (maximize item - residual, i.e. tightest fit).

Additional idea: an existing bin whose post-placement residual would be smaller
than a running estimate of typical future item size is likely to end up wasted.
So among bins that leave a "useful" residual (>= t), prefer the fullest of those;
only if no such bin exists, fall back to pure Best-Fit (tightest fit) to avoid
opening a fresh bin.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0
        self.window = 200
        self.recent_sum = 0.0

    def update(self, item):
        self.n += 1
        delta = item - self.mean
        self.mean += delta / self.n
        self.m2 += delta * (item - self.mean)
        self.recent_sum += item
        if self.n > self.window:
            pass

    def typical_size(self):
        # estimate of a typical upcoming item size (proxy for "useful residual")
        if self.n < 5:
            return 20.0
        var = self.m2 / max(1, self.n - 1)
        std = var ** 0.5
        # a bit below the mean, biased toward smaller items that appear often
        t = self.mean - 0.5 * std
        if t < 5.0:
            t = 5.0
        return t


_state = _State()


def priority(item, bins):
    _state.update(item)

    rem = bins.astype(np.float64)
    residual = rem - item          # post-placement residual (>=0 for fitting bins)

    # classic best fit: tightest residual (smallest residual) -> highest score
    tight = -residual

    # useful-residual mask: bins that keep at least a typical item of room
    t = _state.typical_size()
    useful = residual >= t

    # among useful bins, prefer the fullest (largest residual would be wasteful;
    # we want tightest fit among those that are still useful)
    tight_useful = np.where(useful, -residual, -1e9)

    # Combine: strongly prefer useful bins, tie-broken by tightness.
    score = np.where(useful, tight_useful + 1000.0, tight)
    return score
# EVOLVE-BLOCK-END
