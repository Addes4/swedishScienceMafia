# EVOLVE-BLOCK-START
"""Fragmentation-aware best fit with adaptive distribution model."""
import numpy as np


class _Model:
    def __init__(self):
        # histogram over sizes 1..100
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        # cache expected waste lookup keyed by integer remaining capacity
        self._waste_cache = np.zeros(101, dtype=np.float64)
        self._dirty = True

    def update(self, item):
        self.counts[item] += 1.0
        self.total += 1.0
        self._dirty = True

    def probs(self):
        p = self.counts.copy()
        if self.total > 0:
            p /= self.total
        else:
            # uniform prior fallback; Weibull-ish mean ~40
            p[1:101] = 1.0 / 100.0
        return p

    def expected_waste(self, remaining):
        # Expected leftover after placing one random future item into a bin
        # with the given integer remaining capacity, assuming best-fit-like
        # packing (place item if it fits, else waste stays). We approximate
        # by expected unmet remainder minimized over item choices.
        if remaining <= 0:
            return 0.0
        p = self.probs()
        # sizes that fit
        sizes = np.arange(1, remaining + 1)
        # leftover if we place the largest fitting item (best-fit analogue):
        # approximate expected leftover = sum p[s] * (remaining - s) over s<=remaining
        # plus penalty for items that don't fit (they contribute their own waste elsewhere)
        fitted = p[1:remaining + 1]
        mask = np.arange(1, remaining + 1)
        exp_fit = np.dot(fitted, remaining - mask)
        return exp_fit


_MODEL = _Model()


def priority(item, bins):
    global _MODEL
    m = _MODEL
    m.update(int(item))

    # Best-fit tightness baseline: prefer smaller (bins - item)
    tight = -(bins - item)

    # Adaptive fresh-bin resistance: penalize bins with high remaining capacity
    # more strongly when the model sees large items (mean size), because opening
    # a fresh bin for a big item wastes a lot of potential packing density.
    p = m.probs()
    mean_size = float(np.dot(np.arange(1, 101), p[1:101]))
    # scale factor: larger mean -> stronger resistance to opening fresh bins
    lam = 0.02 + 0.01 * (mean_size / 40.0)

    # Fragmentation-aware bonus: prefer the bin whose leftover after this item
    # is likely to be usable (hungry bins leave too much slack for future items).
    # Approximate by preferring bins where remaining - item is not too small,
    # balanced against tightness, weighted by mean size pressure.
    leftover = bins - item
    # penalize very small leftovers (they become nearly useless fragments) when
    # items are large; for small items small fragments are fine.
    fragment_penalty = np.where(leftover < mean_size * 0.5,
                                 (mean_size * 0.5 - leftover) * 0.05,
                                 0.0)

    score = tight - lam * bins - fragment_penalty
    return score
# EVOLVE-BLOCK-END
