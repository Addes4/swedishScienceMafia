# EVOLVE-BLOCK-START
"""Best fit with a small bias toward fuller bins to concentrate leftovers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Resulting remaining capacity after placing: smaller is better (tight fit).
    leftover = bins - item
    # Bias toward fuller bins: bins with smaller current capacity get a bonus.
    return -leftover - 1e-3 * bins
# EVOLVE-BLOCK-END

