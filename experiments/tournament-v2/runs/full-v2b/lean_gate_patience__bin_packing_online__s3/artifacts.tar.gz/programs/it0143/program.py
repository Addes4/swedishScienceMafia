# EVOLVE-BLOCK-START
"""Best-fit bin rule.

Rank candidate bins by the residual capacity left after placing the item:
the bin with the smallest sufficient residual wins (classic Best-Fit). Ties
go to the first such bin. This is computed with a single vectorised numpy
subtraction, so 5,000 arriving items run well within the time limit.

Best-Fit is known to be very strong (often within a small constant of the
optimal number of bins) and, crucially, is not noisy/tunable, which avoids
the overfitting that plagued earlier hybrid heuristics.
"""
import numpy as np


def priority(item, bins):
    """Score each bin: higher score = preferred. Smallest residual wins."""
    residual = bins.astype(np.float64) - float(item)
    # Negate so that the smallest residual gets the highest score.
    return -residual
# EVOLVE-BLOCK-END

