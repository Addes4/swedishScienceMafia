# EVOLVE-BLOCK-START
"""Best-fit with a lightweight histogram-based tie-breaker.

Primary score is simply the negative post-placement residual (strict best-fit),
which is a strong baseline for Weibull(mean~40) items on capacity-100 bins.
A tiny secondary term nudges ties toward residuals that historically tend to
be "toppable" by future items, using a decaying running histogram. The tiny
weight avoids disturbing the dominant best-fit behaviour observed to plateau
around 0.9616.
"""
import numpy as np

_STATE = {
    "hist": None,
    "count": 0.0,
}


def priority(item, bins):
    s = _STATE
    if s["hist"] is None:
        s["hist"] = np.zeros(101, dtype=np.float64)

    resid = bins.astype(np.float64) - item

    # Primary: strict best-fit (highest score = smallest non-negative residual).
    tightness = -resid

    # Secondary tiny tie-breaker using histogram (only meaningful once warmed).
    if s["count"] > 50:
        hist = s["hist"]
        cum = np.cumsum(hist)            # cum[r] = #past items with size <= r
        total = s["count"]
        resid_int = np.clip(resid.astype(np.int64), 0, 100)
        # fraction of past items that would fit into the residual
        frac = cum[resid_int] / total
        # small bonus for residuals that can still take a typical future item
        tie = 1e-3 * frac
    else:
        tie = 0.0

    # update histogram (after using it, so current item not counted for itself)
    s["hist"][item] += 1.0
    s["count"] += 1.0

    return tightness + tie
# EVOLVE-BLOCK-END
