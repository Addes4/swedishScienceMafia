# EVOLVE-BLOCK-START
"""Best-fit with an adaptive reward for leaving a usable residual (vs near-full bins)."""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0
        self.var = 100.0
        self.count = 0
        # running estimate of a "small" item size (lower decile-ish)
        self.small = 20.0


_state = _State()


def priority(item, bins):
    """Score bins: maximize (item - residual) [best-fit] plus reward for useful residuals.

    A bin whose post-placement residual is very small but nonzero is likely wasted
    (unusable). Reward residuals that are 0 (perfect) or >= a running small-item
    threshold so the bin remains reusable, and mildly penalize fresh bins.
    """
    st = _state
    x = float(item)

    # Update running statistics (only past/current info).
    st.count += 1
    alpha = 0.02 if st.count > 50 else 0.1
    delta = x - st.mean
    st.mean += alpha * delta
    st.var += alpha * (delta * delta - st.var)
    # Track a small-item level: move toward item when item is small.
    if x < st.small:
        st.small += 0.05 * (x - st.small)
    else:
        st.small += 0.002 * (x - st.small)

    resid = bins - item  # remaining capacity after placement (>= 0 guaranteed)

    # Core best-fit: prefer tightest fit (smaller residual).
    score = -resid.astype(np.float64)

    # Reward: residual exactly zero (perfect fill) OR residual large enough to
    # still accommodate a typical small item (bin stays useful).
    thr = max(st.small, 1.0)
    usable = (resid == 0) | (resid >= thr)
    score += 0.5 * usable

    # Mild fresh-bin penalty so we don't open new bins needlessly.
    score -= 0.03 * bins

    return score
# EVOLVE-BLOCK-END
