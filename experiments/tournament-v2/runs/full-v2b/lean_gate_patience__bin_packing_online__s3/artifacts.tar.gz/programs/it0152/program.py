# EVOLVE-BLOCK-START
"""Histogram-based future-fillability bin choice."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes (1..100), Laplace smoothed
        self.hist = np.ones(101, dtype=np.float64)
        self.count = 101.0
        # cache of value density info recomputed lazily
        self._dirty = True
        self._sizes = np.arange(1, 101, dtype=np.float64)
        # empirical mean item size for adaptive tuning
        self.sum = 0.0
        self.n = 0

    def observe(self, item):
        self.hist[item] += 1.0
        self.count += 1.0
        self.sum += item
        self.n += 1
        self._dirty = True


_state = _State()


def _fill_value(residual):
    """Estimate expected number of future items packable greedily into `residual`.

    Use smallest-first greedy packing weighted by the running size distribution:
    repeatedly take the smallest item that fits (highest frequency), so we estimate
    how many items of the residual's capacity can be consumed.
    """
    if residual <= 0:
        return 0.0
    h = _state.hist
    # cumulative remaining capacity
    rem = residual
    value = 0.0
    # keep a mutable copy of counts only for sizes <= rem
    # smallest-first greedy: choose smallest size with positive mass
    # Since sizes are integers, iterate small sizes.
    # Limit iterations to avoid excessive time; residual <= 100 and sizes >= 1.
    counts = h
    # We iterate sizes from 1 upward; each iteration consumes one item.
    for s in range(1, min(100, rem) + 1):
        if counts[s] <= 0:
            continue
        # number of items of size s we can fit
        if s > rem:
            break
        k = int(rem // s)
        # how many of size s the histogram suggests we'd actually see soon
        # Use the mass relative to total; expected count available ~ (count[s]/count)
        # Scale by a horizon estimate (average items per bin ~ 100/mean)
        # Just take as many as fit, capped.
        value += k
        rem -= k * s
        if rem <= 0:
            break
    return value


def priority(item, bins):
    """Score bins by tightness plus expected future fillability of residual."""
    h = _state.hist

    # adaptive horizon: typical number of items that a bin of cap 100 will hold
    if _state.n > 0:
        mean_item = _state.sum / _state.n
    else:
        mean_item = 40.0
    if mean_item < 1.0:
        mean_item = 40.0

    # candidate bins fit item; residual after placement
    residual = bins - item  # int64 array

    # Estimate future fillability of residual using the running histogram.
    # Vectorize a cheap surrogate: expected number of future items fitting in residual
    # ~ residual / mean_item, but discounted when residual is large (hard to fill fully).
    # Add exact small-residual accounting via a lookup for common residuals.
    mean_item = float(mean_item)
    expected_fill = residual / mean_item

    # Penalize large residuals (fresh/loose bins) slightly to encourage tight packing.
    # Tightness term: prefer bins where residual is small relative to item.
    tightness = -(residual.astype(np.float64)) * 0.01

    # Reward bins that, after placing, leave a residual close to a "good" size:
    # sizes near multiples that pack well. Use expected_fill strongly.
    score = expected_fill * 1.0 + tightness

    return score
# EVOLVE-BLOCK-END
