# EVOLVE-BLOCK-START
"""Histogram-based expected future fillability bin packing.

We maintain a running histogram of item sizes seen so far.  For each candidate
bin we consider the residual capacity r that would remain after placing the
current item, and estimate the expected number of *future* items that can be
packed into that residual using a greedy fill: repeatedly draw a size from the
observed distribution and accept it if it fits, until capacity is exhausted.
Because an exact stochastic simulation is too slow, we use a cheap continuous
approximation: E[#items] ~ r / mean_size, penalised when r is small relative
to typical item sizes (so tiny unusable residuals are discouraged).

Score = expected_count(residual)  (higher is better)
        and small preference for a tight residual (best-fit-like tie-break).
"""
import numpy as np

CAP = 100.0

# Running histogram state (module level so it persists across calls).
_hist = None           # counts per size 1..100
_total = 0.0
_sum = 0.0
_recent = None         # recent mean (short window)
_recent_n = 0.0


def _mean_size():
    if _total == 0:
        return 40.0
    return _sum / _total


def _record(item):
    global _hist, _total, _sum, _recent_n
    if _hist is None:
        _hist = np.ones(101, dtype=np.float64)  # Laplace-ish smoothing
        _total = 100.0
        _sum = 100.0 * 40.0
    _hist[item] += 1.0
    _total += 1.0
    _sum += item
    _recent_n += 1.0


def _fill_estimate(r, mean, p_dist):
    """Estimate expected number of future items packable into capacity r.

    Uses a light-weight renewal/greedy approximation:
      base   = r / mean               (continuous count)
      usable = fraction of residual >= a "typical" item size
    We blend these so that large-but-fragmented residuals are valued, while
    tiny slivers are not overvalued.
    """
    if r <= 0:
        return -1e9
    base = r / mean
    # Probability a fresh item fits in r, using the observed distribution.
    # p_dist is cumulative-free histogram (normalized) indexed 1..100.
    idx = int(min(r, 100))
    if idx >= 100:
        p_fit = 1.0
    else:
        p_fit = float(p_dist[1:idx + 1].sum())
    # Effective expected count: greedy acceptance term plus continuous term.
    return base * (0.5 + 0.5 * p_fit) + p_fit


def priority(item, bins):
    _record(item)
    mean = _mean_size()

    if _hist is None:
        hist = np.ones(101, dtype=np.float64)
    else:
        hist = _hist
    p_dist = hist / hist.sum()

    bins = np.asarray(bins, dtype=np.float64)

    # Residual if we place the item now.
    r = bins - float(item)
    r = np.where(r < 0, -1.0, r)  # bins shown all fit; guard anyway

    # Score each bin by expected future fillability of its residual.
    scores = np.empty_like(r)
    for i in range(r.shape[0]):
        scores[i] = _fill_estimate(r[i], mean, p_dist)

    # Tie-break: prefer tightest fitting residual (smaller r) -> subtract r*eps.
    scores = scores - 1e-3 * r
    return scores
# EVOLVE-BLOCK-END
