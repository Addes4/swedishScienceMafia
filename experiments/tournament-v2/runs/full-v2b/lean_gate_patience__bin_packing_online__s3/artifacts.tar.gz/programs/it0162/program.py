# EVOLVE-BLOCK-START
"""Scaled best-fit with bin-closing preference and fillability tie-break.

Idea: place the arriving item so that the post-placement residual is either
0 (perfect fill), or below a "closing threshold" (so the bin can effectively be
sealed as full), otherwise prefer residuals whose remaining capacity is still
usefully fillable by typical future items. A mild fresh-bin penalty discourages
opening new bins until existing ones are exhausted.
"""
import numpy as np

_STATE = {
    "hist": None,
    "count": 0,
    "min_seen": 101,
}

_CAP = 100


def _update_hist(item):
    if _STATE["hist"] is None:
        _STATE["hist"] = np.zeros(_CAP + 1, dtype=np.float64)
    _STATE["hist"][item] += 1.0
    _STATE["count"] += 1
    if item < _STATE["min_seen"]:
        _STATE["min_seen"] = item


def priority(item, bins):
    _update_hist(item)

    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    resid = bins - item
    np.clip(resid, 0.0, None, out=resid)

    total = _STATE["count"]
    hist = _STATE["hist"]
    if total > 0:
        sizes = np.arange(1, _CAP + 1, dtype=np.float64)
        counts = hist[1:]
        mean_size = float((sizes * counts).sum() / total)
    else:
        mean_size = 40.0
    if mean_size <= 0:
        mean_size = 40.0

    # Closing threshold: if residual can't fit a typical small item, seal the bin.
    close_thresh = min(mean_size * 0.5, 20.0)

    # Primary: strongly prefer perfect / near-closing fills (small residual).
    # Use an exponential decay so residual 0 dominates strongly.
    close_score = np.exp(-resid / max(close_thresh, 1e-6))

    # Fillability: residual usefully fillable by future items (in mean units).
    fill = np.clip(resid / mean_size, 0.0, 1.0)

    # Fresh-bin penalty, ramping up with observed count.
    pressure = min(1.0, total / 500.0)
    is_fresh = bins >= (_CAP - 1e-9)
    fresh_pen = is_fresh.astype(np.float64) * (0.5 + 1.5 * pressure)

    score = 4.0 * close_score + 0.3 * fill - fresh_pen
    return score
# EVOLVE-BLOCK-END

