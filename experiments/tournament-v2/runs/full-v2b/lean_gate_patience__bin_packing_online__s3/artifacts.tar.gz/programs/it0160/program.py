# EVOLVE-BLOCK-START
"""Histogram-based future fillability bin-choice rule.

Idea: when choosing a bin for the arriving item, we care not just about how tightly
the item fits (best-fit), but also about how "useful" the residual capacity left
behind is for future items. We maintain a running histogram of observed item sizes
and, for each candidate bin, estimate the expected number of future items that a
greedy first-fit-decreasing fill could pack into the post-placement residual
capacity. This estimate is combined with fit tightness to rank bins.

Additionally we apply a mild penalty to untouched/fresh bins (residual == 100) early
on, to encourage consolidating items, and prefer near-perfect fills.
"""
import numpy as np

# ---- small module-level state (persists across calls) ----
_STATE = {
    "hist": None,       # counts per integer size 1..100
    "count": 0,         # total observed items
    "fresh_allow": 1.0, # multiplier controlling fresh-bin penalty
}

_CAP = 100


def _ensure_hist():
    if _STATE["hist"] is None:
        _STATE["hist"] = np.zeros(_CAP + 1, dtype=np.float64)


def _update_hist(item):
    _ensure_hist()
    _STATE["hist"][item] += 1.0
    _STATE["count"] += 1


def _fill_estimate(residual):
    """Estimate expected number of future items packable into `residual`.

    Greedy first-fit-decreasing style estimate using the observed size
    distribution as a proxy for future items. We approximate by consuming the
    residual with the *average* item size weighted toward smaller-items, which
    gives a smooth and cheap proxy for fillability. Larger residual -> more
    future items can be packed, so bigger residual is more valuable to keep
    available in one bin only if we can fill it densely.
    """
    hist = _STATE["hist"]
    total = _STATE["count"]
    if total <= 0 or residual <= 0:
        return 0.0
    # mean size from histogram
    sizes = np.arange(1, _CAP + 1, dtype=np.float64)
    counts = hist[1:]
    mean_size = float((sizes * counts).sum() / total)
    if mean_size <= 0:
        mean_size = 40.0
    # expected number of items that fit
    return residual / mean_size


def priority(item, bins):
    """Return a priority per bin; highest wins (first on ties).

    Combines fit tightness with a future-fillability term and a fresh-bin
    penalty that adapts to recent item pressure.
    """
    _update_hist(item)

    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # post-placement residuals (must be >= 0; bins shown all fit the item)
    resid = bins - item
    np.clip(resid, 0.0, None, out=resid)

    # --- fit tightness: prefer small residual (best-fit flavor) ---
    # normalized so that filling a bin exactly is best.
    tight = -resid

    # --- future fillability: estimate how many future items fit ---
    # vectorized mean-size based estimate
    hist = _STATE["hist"]
    total = _STATE["count"]
    if total > 0:
        sizes = np.arange(1, _CAP + 1, dtype=np.float64)
        counts = hist[1:]
        mean_size = float((sizes * counts).sum() / total)
    else:
        mean_size = 40.0
    if mean_size <= 0:
        mean_size = 40.0

    # expected items that fit in the residual after placement
    fill = resid / mean_size

    # --- fresh-bin penalty: avoid opening new bins unless needed ---
    # fresh bins have residual (after placement) == 100 - item.
    is_fresh = (bins >= _CAP - 1e-9)
    # stronger penalty when we've already seen many items (packing pressure)
    pressure = min(1.0, total / 200.0)
    fresh_pen = is_fresh.astype(np.float64) * (3.0 + 5.0 * pressure)

    # --- combine ---
    # Fit tightness dominates; fillability gently rewards leaving room in
    # already-open bins that can still absorb future items.
    score = tight + 0.35 * fill - fresh_pen

    # Encourage exact/near-exact fills strongly (small residual leftover).
    exact_bonus = 2.0 * (resid < 0.5).astype(np.float64)
    score = score + exact_bonus

    return score
# EVOLVE-BLOCK-END
