# EVOLVE-BLOCK-START
"""Online bin packing via short-simulation lookahead scoring.

For each candidate bin we imagine placing the arriving item, then run a tiny
greedy "fill simulation" of the resulting residual using a running histogram of
past item sizes. Bins whose residual can be efficiently refilled by typical
future items are preferred.

Key ideas:
  * Maintain an online histogram of past item sizes (100 buckets, EWMA decay).
  * For a candidate residual R, estimate how many typical items fit (~ R / mean)
    and compute an expected "fill efficiency" using a deterministic pseudo-fill
    of the residual against the top item sizes in the histogram.
  * Combine tightness (small R after placement) with fillability so that we do
    not strand large gaps nor fragment space into unusable slivers.
"""
import numpy as np

# --- running state ---------------------------------------------------------
_HIST = np.zeros(101, dtype=np.float64)   # histogram of past item sizes
_HIST[1:] = 1.0                           # small smoothing prior
_COUNT = 100.0                            # effective number of prior samples
_DECAY = 0.995                            # EWMA-style decay of old mass


def _register(item):
    """Update the running histogram with a new observed item size."""
    global _HIST, _COUNT
    _HIST *= _DECAY
    _COUNT *= _DECAY
    _HIST[item] += 1.0
    _COUNT += 1.0


def _fillable_gain(residual, mean, hist):
    """Estimate how 'usably' a residual capacity can be refilled.

    We do a cheap deterministic greedy fill using likely item sizes drawn from
    the histogram (the most probable sizes), counting how many items fit and
    what fraction of the residual is consumed.
    """
    if residual <= 0:
        return 0.0
    # Take the most probable sizes from the histogram (top few) as candidates.
    # Avoid a full sort each call: use the strongest buckets via argpartition.
    top_idx = np.argpartition(hist, -8)[-8:]
    cand = top_idx[top_idx >= 1]
    if cand.size == 0:
        return residual / max(mean, 1.0)
    sizes = np.sort(cand)[::-1]
    space = residual
    used = 0
    items = 0
    # Alternate: fill with a mid-large size first, then fit small ones.
    for s in sizes:
        if s <= space:
            space -= s
            used += s
            items += 1
            # after placing one, try to pack remaining with small items
            for t in sizes[::-1]:
                while t <= space:
                    space -= t
                    used += t
                    items += 1
            break
    # fill remainder with the smallest typical item to model fragmentation
    small = sizes[-1]
    if small <= space:
        used += (space // small) * small
    frac = used / residual
    return frac * np.log1p(items)


def _scores(item, bins):
    """Compute per-bin scores."""
    # residual after placing `item`
    res = bins - item
    # running mean of past items (falls back to item if cold)
    mean = float(np.dot(np.arange(1, 101), _HIST[1:]) / max(_COUNT, 1.0))
    mean = max(mean, 1.0)

    n = bins.shape[0]
    fit = -res.astype(np.float64)          # tightness: small residual preferred

    # fillability of the residual after placement (prefer usable gaps)
    fill = np.empty(n, dtype=np.float64)
    for i in range(n):
        fill[i] = _fillable_gain(int(res[i]), mean, _HIST)

    # Small bonus for perfectly filling (residual 0).
    perfect = np.where(res == 0, 1.0, 0.0)

    # Weighting: tightness dominates but fillability breaks ties / avoids waste.
    return fit + 0.5 * fill + 0.25 * perfect


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    _register(item)
    return _scores(item, bins)
# EVOLVE-BLOCK-END
