# EVOLVE-BLOCK-START
"""Best-fit with a small fillability tie-break."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_hist_count = 0.0

_small_cache = None
_small_tag = -1.0


def priority(item, bins):
    global _hist, _hist_count, _small_cache, _small_tag

    bins = np.asarray(bins, dtype=np.int64)
    n = bins.shape[0]

    if 1 <= item <= 100:
        _hist[item] += 1.0
        _hist_count += 1.0

    residual = (bins - item).astype(np.float64)

    # Best-fit: prefer smallest post-placement residual (most negative fits first).
    score = -residual

    # Small bonus: favor residuals that are not so small that they become useless,
    # i.e. reward keeping room for at least a small future item.
    # Use a mild preference toward residuals with a tiny bit of leftover space.
    tiny_bonus = np.where((residual >= 1) & (residual <= 5), 1e-3, 0.0)
    score = score + tiny_bonus

    return score
# EVOLVE-BLOCK-END
