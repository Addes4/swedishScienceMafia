# EVOLVE-BLOCK-START
"""Histogram-aware best fit: reward tight fits but penalize residues that future items can't fill."""
import numpy as np

# Empirical histogram of observed item sizes (index 0..100, sizes 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0

# Precompute, for each residual capacity r, a greedy future-fill estimate using the
# currently assumed size distribution. We recompute lazily / periodically.
_LAST_TOTAL = -1.0
_VALUE_CACHE = np.zeros(101, dtype=np.float64)
_REBUILD_EVERY = 8  # rebuild the value table every this many items


def _rebuild_value():
    """Estimate expected number of items packable in capacity r using greedy fill with
    the empirical distribution."""
    global _LAST_TOTAL
    total = _TOTAL
    if total <= 0:
        # No data yet: assume uniform small-ish sizes to break symmetry mildly.
        sizes = np.arange(1, 101, dtype=np.float64)
        weights = np.ones(101, dtype=np.float64)
    else:
        sizes = np.arange(1, 101, dtype=np.float64)
        weights = _HIST[1:].copy()

    wsum = weights.sum()
    if wsum <= 0:
        weights = np.ones(101, dtype=np.float64)
        wsum = weights.sum()
    probs = weights / wsum
    # Item sizes for greedy: use the observed support (descending sizable chunks).
    # We approximate expected fillable count by a greedy first-fit-decreasing style
    # expectation: fill residue using the most probable sizes repeatedly.
    support = np.nonzero(probs > 1e-9)[0] + 1  # sizes with nonzero prob
    # value[r] = expected count of items packed greedily into r
    val = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        rem = r
        cnt = 0.0
        # Greedy: at each step pick the largest size <= rem with meaningful probability,
        # weighted by probability to get a soft estimate.
        while rem > 0:
            feasible = support[support <= rem]
            if feasible.size == 0:
                break
            idx = feasible - 1
            best = feasible[np.argmax(probs[idx])]
            p = probs[best - 1]
            cnt += p
            if p < 1e-6:
                break
            rem -= int(best)
            if cnt > 200:
                break
        val[r] = cnt
    _VALUE_CACHE[:] = val
    _LAST_TOTAL = total


def priority(item, bins):
    global _TOTAL
    n = bins.shape[0]
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # Update histogram lazily: record current item before scoring (it's already arriving).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _TOTAL += 1.0

    if _TOTAL - _LAST_TOTAL >= _REBUILD_EVERY or _TOTAL <= 1.0:
        _rebuild_value()

    # Post-placement residual for each bin.
    residual = bins - item  # all bins here fit item, so residual >= 0
    np.clip(residual, 0, 100, out=residual)

    # Tightness term: prefer small residual (best-fit) but smoothly.
    tightness = -(residual.astype(np.float64))

    # Future-fillability: expected items packable into residual.
    fill = _VALUE_CACHE[residual]

    # Combine: reward tightness strongly, but give credit when residual can still be
    # usefully refilled. Balance via a moderate weight on fill.
    return tightness + 6.0 * fill
# EVOLVE-BLOCK-END
