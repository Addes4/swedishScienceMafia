# EVOLVE-BLOCK-START
"""Best-Fit that prefers leaving a truly dead residual (smaller than any seen item)."""
import numpy as np


def priority(item, bins):
    """Rank bins by post-placement residual, boosting dead residuals.

    A residual is "dead" if it is smaller than the smallest item observed so
    far: no future item can ever fit there, so leaving such a residual wastes
    nothing useful. Among dead residuals we pick the tightest (largest dead),
    and otherwise standard Best-Fit (smallest residual) applies.
    """
    global _min_seen
    try:
        _min_seen
    except NameError:
        _min_seen = 101

    residual = bins - item  # >= 0 for fitting bins
    dead_cut = _min_seen - 1  # residual <= dead_cut means no future item fits

    # Base: prefer smallest residual (classic best-fit) via negative residual.
    score = -residual.astype(np.float64)

    # Boost dead residuals strongly, and pick the tightest among them.
    dead = residual <= dead_cut
    if dead.any():
        # Reward dead residuals; larger dead residual (closer to cut) gets
        # slightly higher score so it is filled to maximal useful extent.
        score[dead] += 1000.0 + residual[dead]

    if item < _min_seen:
        _min_seen = item

    return score
# EVOLVE-BLOCK-END
