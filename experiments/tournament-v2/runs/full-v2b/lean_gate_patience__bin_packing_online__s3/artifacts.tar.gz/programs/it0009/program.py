# EVOLVE-BLOCK-START
"""
Best-Fit bin choice.

Place the arriving item into the bin that leaves the smallest residual capacity
while still fitting.  This is the classic online Best-Fit heuristic: it keeps
bins tight and tends to pack well for continuous-like size distributions.
"""
import numpy as np


def priority(item, bins):
    """Rank bins by best fit: higher score = smaller resulting residual."""
    b = np.asarray(bins, dtype=np.float64)
    if b.size == 0:
        return np.zeros(0, dtype=np.float64)
    # Prefer the bin with the smallest residual capacity after insertion.
    return float(item) - b


# EVOLVE-BLOCK-END
