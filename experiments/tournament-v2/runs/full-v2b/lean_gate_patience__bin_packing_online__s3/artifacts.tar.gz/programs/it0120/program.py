# EVOLVE-BLOCK-START
"""Adaptive fresh-bin-resistant best fit.

Score each bin by tightness of fit (small residual after placement) but penalize
large residual (fresh) bins based on a running EWMA estimate of item-size pressure.
Under high recent pressure (large items), we avoid opening fresh bins and instead
pack tightly into existing ones; under low pressure we behave like standard best fit.
"""
import numpy as np


def priority(item, bins):
    # Running estimate of average item size (EWMA), stored on the function.
    state = priority.state
    if state is None:
        state = {"avg": 40.0, "alpha": 0.02, "count": 0}
        priority.state = state

    item = float(item)
    # Update EWMA of item sizes.
    state["avg"] = (1.0 - state["alpha"]) * state["avg"] + state["alpha"] * item
    state["count"] += 1

    residual = bins - item  # bins only contains bins where the item fits, so >= 0

    # Pressure: how large items are relative to a nominal mean (~40).
    pressure = state["avg"] / 40.0  # ~1 at the typical mean, higher for large items

    # Tightness: prefer small residual (best fit).
    # Fresh-bin penalty: subtract leftover space, scaled by pressure, but only
    # meaningfully for large residuals (i.e., bins far from full).
    # residual / 100 is in [0,1]. Fresh bins have residual ~ (100 - item).
    leftover = residual / 100.0

    # Penalize leftover space more when recent items are large (pressure high),
    # so we don't waste the last space on a bin we may not refill.
    penalty = 4.0 * pressure * leftover * leftover

    return -leftover - penalty
# EVOLVE-BLOCK-END
