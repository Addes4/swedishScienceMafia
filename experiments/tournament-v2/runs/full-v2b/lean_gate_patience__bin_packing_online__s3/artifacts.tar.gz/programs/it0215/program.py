# EVOLVE-BLOCK-START
"""Best-Fit bin choice with deterministic low-index tie-break.

Items go to the fitting bin with the smallest remaining capacity after
placement (the tightest fit). Pure Best-Fit is a strong online heuristic;
we keep it exactly and only add an infinitesimal, deterministic tie-break
favoring lower bin indices (which are the older, more-loaded bins), so
that genuinely equivalent choices consolidate into already-open bins
instead of spreading across the array.
"""
import numpy as np


def priority(item, bins):
    n = bins.shape[0]
    residual = bins - item
    # primary term: tightest fit (negated post-placement residual)
    # secondary term: infinitesimal preference for lower indices
    idx = np.arange(n, dtype=np.float64)
    return -(residual.astype(np.float64)) - 1e-6 * idx
# EVOLVE-BLOCK-END
