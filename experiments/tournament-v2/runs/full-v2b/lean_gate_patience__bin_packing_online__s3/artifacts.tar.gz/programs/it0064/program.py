# EVOLVE-BLOCK-START
"""Best-fit with a small residual-matching bias toward likely future items."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101)  # counts of item sizes seen
        self.total = 0


_state = _State()


def priority(item, bins):
    s = _state
    s.hist[item] += 1
    s.total += 1

    # Fit probability mass near a residual r, i.e. P(next item fits exactly-ish).
    # Use histogram smoothed over a small window.
    h = s.hist
    total = s.total

    residual = bins - item  # capacity left after placing item (>=0)

    # Base: pure best-fit (prefer small residual).
    score = -residual.astype(np.float64)

    # Small bonus when residual is a size that frequently appears (future exact fits).
    # Smooth histogram with a 3-wide window to be robust.
    r = residual.astype(np.int64)
    r = np.clip(r, 0, 100)
    lo = np.clip(r - 1, 0, 100)
    hi = np.clip(r + 1, 0, 100)
    mass = (h[lo] + h[r] + h[hi]) / max(1.0, total)
    score += 5.0 * mass

    return score
# EVOLVE-BLOCK-END
