# EVOLVE-BLOCK-START
"""Distribution-aware best-fit using a fractional tightness score.

Bins are ranked by how tightly the item fits after placement.  Instead of the
raw residual (standard best fit), we use a normalized "fill fraction" that
prefers the bin whose remaining capacity, relative to the bin's total used
space, best matches the item.  This is the reservoir/ratio rule which tends to
reduce the number of opened bins versus plain best fit.
"""
import numpy as np


class _State:
    def __init__(self):
        # running estimate of typical item size (EWMA), Laplace-free
        self.mean = 40.0
        self.count = 0.0

    def observe(self, item):
        self.count += 1.0
        a = 1.0 / min(self.count, 200.0)
        self.mean += a * (item - self.mean)


_state = _State()


def priority(item, bins):
    """Score bins by tightness of fit (fractional best fit)."""
    _state.observe(item)

    obj = np.asarray(bins, dtype=np.int64)
    rem = obj - item  # remaining capacity after placing item

    # Standard best fit: smallest residual is best.
    # Normalize the residual by a capacity scale so tight fits dominate but
    # among bins with the same residual, deeper (more-filled) bins win -- this
    # discourages opening fresh bins.
    scale = 100.0
    fit = 1.0 - rem.astype(np.float64) / scale  # higher = tighter

    # Convert to an integer-like strict ordering: primary term is exact residual
    # (best fit), secondary term rewards bins that are already more used.
    # more-used => smaller original capacity (100 - rem_orig); here obj = rem_orig
    used = (scale - obj.astype(np.float64)) / scale  # 0 for fresh, ->1 for full

    score = -rem.astype(np.float64) * 1e6 - (scale - obj.astype(np.float64))
    return score
# EVOLVE-BLOCK-END
