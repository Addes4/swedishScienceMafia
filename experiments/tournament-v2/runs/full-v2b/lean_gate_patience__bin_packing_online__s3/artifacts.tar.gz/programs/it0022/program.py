import numpy as np

_hist = {}
_recent = []


def priority(item, bins):
    global _hist, _recent
    _recent.append(item)
    if len(_recent) > 200:
        old = _recent.pop(0)
        c = _hist.get(old, 0) - 1
        if c <= 0:
            _hist.pop(old, None)
        else:
            _hist[old] = c
    _hist[item] = _hist.get(item, 0) + 1

    rem = bins.astype(np.int64)
    resid = rem - item

    # Best-fit core: prefer small residual after placement.
    score = (item - rem).astype(np.float64)

    # Near-tie bonus: if residual exactly equals a size seen recently, the bin
    # can be filled perfectly later, so promote it slightly.
    seen = np.zeros(101, dtype=np.float64)
    for s, c in _hist.items():
        seen[s] = 1.0
    # residual must be a plausible future item (present in recent history)
    bonus = seen[np.clip(resid, 0, 100)]
    score = score + 0.001 * bonus

    return score
