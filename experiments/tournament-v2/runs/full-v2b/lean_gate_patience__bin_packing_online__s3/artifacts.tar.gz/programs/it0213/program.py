# EVOLVE-BLOCK-START
"""Best-Fit with tie-break toward fuller bins.

Items go to the fitting bin with the smallest remaining capacity after
placement (tightest fit). Bins whose post-placement residual is within a
tiny tolerance of the minimum are considered equivalent, and among those
the fuller bin (smaller pre-placement remaining capacity) is preferred.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    mn = residual.min()
    # tolerance: residuals within 1 unit of the best are treated as ties
    tie = residual <= (mn + 1)
    # among ties, prefer the bin with the largest current load
    score = -residual.astype(np.float64)
    # tiny bonus to fuller bins, only enough to break near-ties
    score += tie * (-1e-3) * (bins.astype(np.float64))
    return score
# EVOLVE-BLOCK-END
