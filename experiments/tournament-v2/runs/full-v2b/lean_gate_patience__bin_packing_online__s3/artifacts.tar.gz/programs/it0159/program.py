"""Histogram-based future fillability bin packing.

Track a running histogram of observed item sizes. For every candidate bin,
place the item, then estimate how many future items could be packed into the
resulting residual capacity (a greedy/knapsack fill estimate using recent item
statistics). Combine that expected fillability with a fit-tightness term so the
item goes where the residual is least "wasted" and most likely to be reused.

Also keep a mild fresh-bin penalty driven by recent item pressure, to avoid
needlessly opening new bins when fit is good enough.
"""

import numpy as np

# Item sizes 1..100
MAX_SIZE = 100

# Histogram state (module-level so it persists; reset lazily per large gaps).
_hist = np.ones(MAX_SIZE + 1, dtype=np.float64)  # Laplace smoothing
_hist_count = float(MAX_SIZE)
_last_item = None

# For estimate of number of items that fit in residual capacity.
# Precompute for a range of residual capacities and a small set of "typical" sizes.
_CAP_CACHE = {}


def _update_hist(item):
    global _hist_count
    # Simple decay to make the histogram adaptive but stable.
    if _hist_count > 20000:
        _hist *= 0.5
        _hist_count *= 0.5
    _hist[item] += 1.0
    _hist_count += 1.0


def _fill_estimate(residual, mean_size):
    """Estimate how many future items (mean size mean_size) fit in `residual`.

    Approaches a knapsack-fill count. Use continuous estimate with mild
    correction; cheap and monotone.
    """
    if residual <= 0:
        return 0.0
    if mean_size <= 0.5:
        mean_size = 0.5
    return residual / mean_size


def priority(item, bins):
    global _last_item
    _update_hist(item)
    _last_item = item

    # Recent item pressure: expected item size from histogram.
    total = _hist_count
    sizes = np.arange(1, MAX_SIZE + 1, dtype=np.float64)
    probs = _hist[1:] / total
    mean_size = float(np.dot(sizes, probs))
    if mean_size < 1.0:
        mean_size = 1.0

    b = np.asarray(bins, dtype=np.float64)

    # Residual after placing item in each bin.
    resid = b - float(item)

    # Future fillability: expected count of future items fitting in residual.
    # Prefer bins whose residual is a near-multiple of mean size (less waste).
    fill = resid / mean_size

    # Waste relative to the "ideal" modular fill:
    # a residual that is just above k*mean_size for integer k is good.
    k = np.floor(resid / mean_size)
    ideal = k * mean_size
    waste = resid - ideal  # in [0, mean_size)

    # Fit tightness: smaller residual (for this item) means tighter pack.
    # Normalize by capacity scale.
    tightness = -resid / float(MAX_SIZE)

    # Fresh-bin penalty: discourage opening a new bin (residual 100) unless
    # we can't do well elsewhere. Penalty grows with how full bins typically
    # are relative to capacity.
    fresh_mask = (b >= MAX_SIZE)
    fill_ratio = 1.0 - mean_size / float(MAX_SIZE)  # typical fill level
    fresh_penalty = np.where(fresh_mask, fill_ratio, 0.0)

    # Combined score: expected reused capacity minus waste minus fresh penalty.
    score = (fill * (1.0 - waste / mean_size) * 0.6
             + tightness * 1.0
             - fresh_penalty * 1.5)

    return score
