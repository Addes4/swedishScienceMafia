# EVOLVE-BLOCK-START
"""Best-Fit: choose the bin leaving the smallest non-negative residual."""
import numpy as np


def priority(item, bins):
    """Score bins by best fit: maximize (item - residual) = tightest fit.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining 100), in bin order.
    """
    # Best-fit base score: tighter fit (smaller residual after placement) is better.
    score = -(bins - item)
    # Tiny tie-break: among equal residuals prefer the larger original residual bin
    # (i.e. the one that had more room), keeping roomy bins flexible for future items.
    # Since residual is identical, prefer bigger current capacity -> smaller penalty.
    return score.astype(np.float64) - 1e-6 * (100 - bins)
# EVOLVE-BLOCK-END
