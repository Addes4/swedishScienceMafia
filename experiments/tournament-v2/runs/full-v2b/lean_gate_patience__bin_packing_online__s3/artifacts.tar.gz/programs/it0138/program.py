# EVOLVE-BLOCK-START
"""Best-fit with harmonic residual alignment.

Primary term is tightest-fit (smallest post-placement residual). A secondary
term rewards bins whose residual is close to an integer multiple of the
running mean item size, so leftover slack stays reusable (reducing fragments
that no future item can fill). Statistics are updated online.
"""
import numpy as np

_STATE = {
    "ewma": 40.0,
    "count": 0.0,
}


def priority(item, bins):
    s = _STATE
    s["count"] += 1.0
    s["ewma"] = 0.98 * s["ewma"] + 0.02 * item
    mean = s["ewma"]

    resid = bins.astype(np.float64) - item
    resid = np.maximum(resid, 0.0)

    # dominant: tightest fit
    score = -resid

    # harmonic alignment: residual near a multiple of the mean item size
    if s["count"] > 50 and mean > 1.0:
        ratio = resid / mean
        # distance to nearest integer multiple
        frac = np.abs(ratio - np.round(ratio))
        # give a bonus for clean multiples (smaller frac better), scaled down
        # so it only breaks near-ties of the best-fit term
        score += 0.5 * (1.0 - frac) - 0.15 * np.minimum(ratio, 3.0)

    return score
# EVOLVE-BLOCK-END
