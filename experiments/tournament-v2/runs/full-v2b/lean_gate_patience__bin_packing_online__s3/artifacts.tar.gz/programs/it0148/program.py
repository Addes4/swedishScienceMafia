# EVOLVE-BLOCK-START
"""Online best-fit bin-selection with distribution-aware tie-break."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes 1..100 (index 0 unused), with forgetting
        self.hist = np.ones(101, dtype=np.float64)
        self.count = 101.0
        self.decay = 0.999
        self.calls = 0

    def update(self, item):
        self.hist *= self.decay
        self.count *= self.decay
        self.hist[item] += 1.0
        self.count += 1.0
        self.calls += 1


_S = _State()


def priority(item, bins):
    s = _S
    s.update(item)

    # probability distribution of future item sizes (smoothed)
    p = s.hist / s.count
    p[0] = 0.0

    # residual capacity after placing item in each bin
    resid = (bins - item).astype(np.float64)

    # Primary: best-fit -- smaller post-placement residual is better.
    # Use negative residual so higher score = smaller residual (tighter fit).
    score = -resid

    # Tiny tie-break: prefer residuals that are likely to be reusable,
    # i.e. residual equals or slightly exceeds a common small/medium item size.
    frac_fit = np.cumsum(p)[bins.clip(0, 100)]  # P(item <= bin capacity)
    # reward leaving a residual that fits many common items
    usable = np.cumsum(p)[resid.astype(np.int64).clip(0, 100)]
    score += 1e-3 * usable

    # Penalize leaving an untouched fresh bin (resid==100) slightly
    score -= 1e-3 * (resid == 100.0).astype(np.float64)

    return score
# EVOLVE-BLOCK-END

