# EVOLVE-BLOCK-START
"""Two-tier bin choice: tight best-fit for snug fits, fullest-bin-first otherwise.

For an arriving item we split candidate bins by the residual they would leave:
  - if residual <= threshold, we prefer the smallest residual (classic best fit)
  - otherwise we prefer the bin with the smallest remaining capacity (most full),
    which tends to conserve fresh bins better than plain best fit.
The threshold adapts from a running estimate of the mean item size.
"""
import numpy as np


def priority(item, bins):
    st = priority.__dict__
    if 'mean' not in st:
        st['mean'] = 40.0
        st['count'] = 0

    # EWMA of item sizes
    m = st['mean']
    st['mean'] = m + 0.05 * (item - m)
    st['count'] += 1
    mean = st['mean']

    b = bins.astype(np.float64)
    residual = b - item

    # threshold: roughly half a typical item
    thr = 0.5 * mean

    # Base: prefer smallest remaining capacity (fullest bin)
    score = -b

    # For snug fits (residual <= thr) strongly prefer smallest residual.
    snug = residual <= thr
    # make snug bins dominate over non-snug, then order by -residual within snug
    score = score + snug * 1000.0 - residual
    # For non-snug bins, also subtract residual scaled down so fullest-bin still leads
    score = score - 0.0 * residual

    return score
# EVOLVE-BLOCK-END
