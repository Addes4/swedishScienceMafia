# EVOLVE-BLOCK-START
"""Best-fit with randomized selection among near-tied tight fits.

Strict greedy best-fit is myopic: it always commits to the single tightest
residual, which can strand awkward remainders.  Instead we compute the best
fit residual, then choose uniformly at random among all bins whose residual is
within a small window of that minimum.  Randomizing among near-equal tight fits
spreads packing decisions and tends to reduce the number of opened bins.
"""
import numpy as np


class _State:
    def __init__(self):
        self.mean = 40.0
        self.count = 0.0
        # deterministic-ish RNG so behaviour is stable across instances
        self.rng = np.random.default_rng(123456789)

    def observe(self, item):
        self.count += 1.0
        a = 1.0 / min(self.count, 200.0)
        self.mean += a * (item - self.mean)


_state = _State()


def priority(item, bins):
    """Score bins by tightness of fit, with a randomized near-tie window."""
    _state.observe(item)

    obj = np.asarray(bins, dtype=np.int64)
    rem = obj - item  # remaining capacity after placing item (>=0 for shown bins)

    # Primary term: strict best fit (smallest residual). Scale by a large
    # constant so the ordering by residual dominates.
    score = -rem.astype(np.float64) * 1e6

    # Randomized near-tie break: bins within a small window of the minimum
    # residual get a random epsilon so ties resolve unpredictably rather than
    # always to the lowest index.
    min_rem = int(rem.min())
    window = 2
    near = rem <= (min_rem + window)
    if near.sum() > 1:
        rand = _state.rng.random(rem.shape[0]) * 1e5
        score = score + np.where(near, rand, 0.0)

    return score
# EVOLVE-BLOCK-END
