# EVOLVE-BLOCK-START
"""Harmonic-aware best fit.

The Harmonic family of online bin-packing algorithms is provably good: items of
size in (1/(k+1), 1/k] of capacity are packed into bins reserved for that class.
We can't reserve bins explicitly (the harness owns them), but we can bias the
greedy choice toward the harmonic class of the arriving item.

For an item of size s, let k = floor(100 / s) (so s is in class k, i.e.
100/(k+1) < s <= 100/k).  Within a class, packing class items together into a
bin is good.  We reward a bin by how close its post-placement residual is to an
integer multiple of typical needs, but crucially we scale the "best fit"
preference by the harmonic weight 1/k: larger items (small k) care more about
exact fits, small items (large k) can afford to leave more slack.

Concretely: score = -(residual) * (1 + 1/k) - tiny * residual, with the fresh-bin
resistance folded in through the harmonic class of the item itself.
"""
import numpy as np


def priority(item, bins):
    s = float(item)
    # Harmonic class index for this item: 1/k < s/100 <= 1/(k-1) style.
    k = int(100.0 // s) if s >= 1.0 else 100
    if k < 1:
        k = 1

    residual = bins - item  # remaining capacity if placed here

    # Tightness preference: smaller residual is better (best fit).  Weight the
    # preference by the harmonic class so that large items pack very tightly
    # and small items tolerate more slack, matching harmonic-class behavior.
    w = 1.0 + 1.0 / k
    # A small fresh-bin resistance proportional to the class weight, mildly
    # discouraging use of near-empty bins for small items.
    lam = 0.02 * (1.0 / k)

    return -(w * residual + lam * residual)
# EVOLVE-BLOCK-END
