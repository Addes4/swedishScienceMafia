# EVOLVE-BLOCK-START
"""Online bin packing: Best-Fit with a residual-utility correction.

Classic Best-Fit (tightest post-placement residual) is hard to beat here, so
keep it as the dominant ordering.  On top, apply a tiny correction that makes
bins more likely to stay useful for future items: reward exact fills, and give a
mild bonus to residuals close to the typical arriving item size (~40), since
such a bin can still absorb a whole future item.  The correction is scaled well
below 1 so it only breaks near-ties in the tightest-fit ordering.
"""
import numpy as np

_MEAN = 40.0


def priority(item, bins):
    residual = bins - item
    # Dominant term: tightest fit (smaller residual better -> more negative).
    score = -residual.astype(np.float64)

    r = residual.astype(np.float64)
    # Bonus for perfect fill (exactly closes the bin).
    score += 0.3 * (r == 0)
    # Mild bonus for residuals close to a typical item size (refillable bins),
    # tapering off as residual grows large (wasted capacity).
    score += 0.05 * np.exp(-((r - _MEAN) ** 2) / (2.0 * _MEAN ** 2))
    return score
# EVOLVE-BLOCK-END
