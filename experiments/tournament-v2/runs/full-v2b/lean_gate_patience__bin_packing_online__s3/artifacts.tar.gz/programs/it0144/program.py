# EVOLVE-BLOCK-START
"""Best-fit with size-aware fresh-bin reservation and match-quality tie-break.

Ranking components:
  * tightness = negative post-placement residual (best-fit core),
  * a strong bonus when the residual can exactly host a common observed item size
    (so leftover space stays reusable),
  * a fresh-bin penalty that scales with item size, so small items prefer to
    cram into existing bins while large items may open a new bin.
"""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "count": 0.0,
}


def priority(item, bins):
    st = _state
    hist = st["hist"]
    hist[item] += 1.0
    st["count"] += 1.0

    bins_f = bins.astype(np.float64)
    residual = bins_f - float(item)

    # Best-fit core: smaller residual is better.
    tight = -residual

    total = hist.sum()
    if total > 0.0:
        sizes = np.arange(hist.size, dtype=np.float64)
        # Match-quality: reward residuals that closely correspond to a common
        # item size (so the leftover can host a whole future item).
        idx = np.clip(residual.astype(np.int64), 0, hist.size - 1)
        # Distance from residual to nearest frequently observed size.
        mass = hist / total
        # For each residual, find largest size <= residual with decent mass.
        cum = np.cumsum(hist) / total
        match = cum[idx]
    else:
        match = np.zeros_like(residual)

    # Fresh-bin penalty grows with item size: small items should reuse bins.
    size_frac = float(item) / 100.0
    fresh_penalty = (0.6 + 0.9 * size_frac) * bins_f

    score = tight + 0.6 * match - 0.35 * fresh_penalty

    # Strongly prefer (near) exact fits.
    score += 20.0 * (residual < 1e-9)

    return score
# EVOLVE-BLOCK-END
