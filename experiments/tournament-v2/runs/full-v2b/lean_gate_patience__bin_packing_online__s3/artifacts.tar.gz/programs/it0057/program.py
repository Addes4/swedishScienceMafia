# EVOLVE-BLOCK-START
"""Best-fit with a running-histogram tie-break bonus for fillable residuals."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        # Histogram of past item sizes (1..100).
        self.hist = np.zeros(101, dtype=np.float64)


_state = _State()


def priority(item, bins):
    st = _state
    st.n += 1
    # Update histogram of past items (before current, fine either way).
    st.hist[int(item)] += 1.0

    # Sorted list of previously seen item sizes for residual matching.
    hist = st.hist
    total = hist.sum()
    if total > 0:
        # Probability of seeing a given size in the future (smooth estimate).
        probs = (hist + 0.5) / (total + 50.0)
    else:
        probs = np.full(101, 1.0 / 100.0)

    residual = bins - item  # post-placement residual, >= 0

    # Primary: best-fit -> smallest residual.
    score = -residual.astype(np.float64)

    # Tie-break bonus: reward residuals that a future item is likely to fill,
    # i.e. residuals whose value is a common (or at least plausible) item size.
    # Scale small so it can't override best-fit, only reorder near-ties.
    idx = residual
    bonus = np.where(residual <= 100, probs[idx], 0.0)
    score += 0.5 * bonus

    return score
# EVOLVE-BLOCK-END

