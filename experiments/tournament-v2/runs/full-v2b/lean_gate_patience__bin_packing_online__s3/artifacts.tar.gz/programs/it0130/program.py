# EVOLVE-BLOCK-START
"""Best-fit with histogram-driven exact-closure bonus."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_hist_count = 0.0

# reachability: reachable[s] = max probability-ish weight that some multiset of
# common item sizes sums exactly to s. Rebuilt lazily.
_reach = None
_reach_tag = -1.0

_fresh_penalty = 1e-3


def _most_probable_sizes(probs, k=6):
    idx = np.argsort(probs)[::-1]
    out = []
    for i in idx:
        s = i + 1
        if probs[i] > 0:
            out.append(s)
        if len(out) >= k:
            break
    return out


def _build_reach(probs, sizes):
    # 0/1 unbounded knapsack reachability weighted: for each achievable sum s (1..100),
    # store best (max) product of probabilities along a decomposition greedily.
    # We approximate with a simple DP: best[s] = max over size in sizes with size<=s of
    #   max(probs[size-1], best[s-size] * probs[size-1])
    best = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        b = 0.0
        for sz in sizes:
            if sz <= s:
                p = probs[sz - 1]
                cand = p if s - sz == 0 else best[s - sz] * p
                if cand > b:
                    b = cand
        best[s] = b
    return best


def priority(item, bins):
    global _hist, _hist_count, _reach, _reach_tag

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item

    if 1 <= item <= 100:
        _hist[item] += 1.0
        _hist_count += 1.0

    # rebuild reachability occasionally
    if _hist_count >= 20:
        tag = _hist_count
        if _reach is None or abs(tag - _reach_tag) > 50.0:
            probs = _hist[1:101] / _hist_count
            sizes = _most_probable_sizes(probs, 6)
            _reach = _build_reach(probs, sizes)
            _reach_tag = tag

    # base: best-fit (smaller residual better)
    score = -residual.astype(np.float64)

    # exact-closure bonus: if residual is exactly reachable by likely items, reward it
    if _reach is not None:
        valid = residual >= 0
        bonus = np.zeros(residual.shape[0], dtype=np.float64)
        safe = np.clip(residual, 0, 100)
        bonus[valid] = _reach[safe[valid]]
        score += 2.0 * bonus

    # tiny penalty for fresh bins to avoid opening new bins on ties
    fresh = bins == 100
    score[fresh] -= _fresh_penalty

    return score
# EVOLVE-BLOCK-END
