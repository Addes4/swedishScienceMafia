# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a closing bonus.

Primary rule: best fit (smallest post-placement residual among feasible bins).
A strong bonus is added when the placement closes the bin, i.e. the residual
becomes smaller than the smallest item size observed so far (no future item can
fit). This is the classic best-fit-decreasing-like greedy adapted online and
performed best in practice.
"""
import numpy as np

CAP = 100

# Smallest item size observed so far (used to detect effective bin closing).
_min_item = CAP + 1


def priority(item, bins):
    global _min_item

    if item < _min_item:
        _min_item = item

    b = np.asarray(bins, dtype=np.float64)
    residual = b - item
    residual = np.maximum(residual, 0.0)

    # Best-fit: prefer the smallest residual.
    score = -residual

    # Closing bonus: if residual can no longer hold any item seen so far,
    # strongly reward closing this bin.
    if _min_item <= CAP:
        close = residual < _min_item
        score += 1000.0 * close

    return score
# EVOLVE-BLOCK-END
