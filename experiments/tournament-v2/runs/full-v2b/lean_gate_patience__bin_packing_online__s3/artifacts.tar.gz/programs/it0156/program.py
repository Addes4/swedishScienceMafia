# EVOLVE-BLOCK-START
"""Best-fit with a residual-matching bonus for likely future item sizes."""
import numpy as np


class _State:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)  # histogram of item sizes
        self.total = 0.0
        self.decay = 0.999

    def observe(self, item):
        # Exponential forgetting keeps the histogram adaptive.
        self.counts *= self.decay
        self.total *= self.decay
        self.counts[item] += 1.0
        self.total += 1.0

    def prob(self, size):
        if size < 1 or size > 100 or self.total <= 0:
            return 0.0
        return self.counts[size] / self.total


_state = _State()


def priority(item, bins):
    _state.observe(item)

    residual = bins - item  # all >= 0

    # Primary: smaller residual is better (best-fit).
    score = -residual.astype(np.float64)

    # Small bonus for residuals that look like a plausible upcoming item size,
    # so those bins can be exactly filled later rather than wasted.
    max_res = int(residual.max()) if len(residual) else 0
    bonus = np.zeros(len(residual), dtype=np.float64)
    if _state.total > 0 and max_res >= 1:
        # window of relevant residual sizes (cap work)
        lo = 1
        hi = min(max_res, 100)
        # build probability table for sizes in [lo, hi], weight by how "exactly fillable"
        sizes = np.arange(0, 101, dtype=np.float64)
        probs = _state.counts / _state.total  # length 101
        # Bonus for residual r: probability mass near r (item sizes close to r).
        # Sum probabilities of sizes within +/- 2 of r.
        for d in range(-2, 3):
            idx = np.clip(residual + d, 0, 100).astype(np.int64)
            bonus += probs[idx]
        score += bonus * 1e-3

    return score
# EVOLVE-BLOCK-END
