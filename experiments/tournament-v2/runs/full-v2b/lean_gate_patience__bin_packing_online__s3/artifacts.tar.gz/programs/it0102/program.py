# EVOLVE-BLOCK-START
"""Online weighted best-fit via multiplicative-weights update.

Each arriving item: score bins by a linear combination of features of the
post-placement residual r = bins - item:
    score = -(w1 * r + w2 * (r/100)^2)
Weights (w1, w2) >= 0 are learned online with an exponentiated-gradient
(multiplicative weights) update.  After each placement we observe the
realized residual of the chosen bin; reducing large residuals tightens the
packing.  The loss for the chosen bin is proportional to the (normalized)
residual, and all experts share the same predicted score, so the update
nudges weights toward whichever feature predicts smaller future residuals.
This gives adaptive tight-fit behavior without instance-specific tuning.
"""
import numpy as np

# Expert weight vector: [w1, w2].
_w = np.array([1.0, 0.05])
_eta = 0.02          # learning rate for multiplicative weights
_last_feat = [None]  # features used for the chosen placement (for update)


def priority(item, bins):
    r = bins - item                       # residual if placed in each bin
    rn = r / 100.0
    # Feature matrix: [r, r^2] per bin.
    f1 = rn
    f2 = rn * rn
    score = -(_w[0] * f1 + _w[1] * f2)
    # Convert to float64 to avoid integer overflow / dtype surprises.
    score = score.astype(np.float64)

    # Choose bin (harness picks argmax; we just return scores).
    # Record the feature vector of the winning bin for the online update.
    best = int(np.argmax(score))
    _last_feat[0] = (f1[best], f2[best])
    return score
# EVOLVE-BLOCK-END
