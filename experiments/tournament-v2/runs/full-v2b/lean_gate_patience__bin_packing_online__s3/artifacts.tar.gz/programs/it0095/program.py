# EVOLVE-BLOCK-START
"""Adaptive residual-aware bin-choice rule.

The rule is an online scoring function over bins:

    score = -(residual) + lambda * utility(residual)

where `residual = bin_remaining - item` is the capacity left if the item is placed
there, and the fresh-bin penalty strength `lambda` adapts to a running estimate of
recent item-size pressure (EWMA mean and variance). When recent items are large,
lambda shrinks so the rule behaves like tight best-fit; when recent items are small,
lambda grows so the rule is reluctant to open high-remaining ("fresh") bins that
would not be usefully refilled.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.var = 600.0
        self.alpha = 0.03
        self.item_seen = 0
        self.lam = 0.0


_state = _State()


def _observe(item):
    s = _state
    s.n += 1
    d = item - s.mean
    s.mean += s.alpha * d
    s.var += s.alpha * (d * d - s.var)
    s.item_seen += 1


def priority(item, bins):
    _observe(item)

    s = _state
    mean = s.mean
    var = s.var

    # "Pressure": how large items tend to be relative to the 100 unit bin.
    pressure = mean / 100.0
    spread = (var ** 0.5) / 100.0

    # lambda: strong fresh-bin resistance under low pressure, weak under high pressure.
    # Also clamp for numerical safety.
    lam = 0.9 * (1.0 - pressure) ** 2 / (1.0 + spread)
    if lam < 0.0:
        lam = 0.0
    elif lam > 0.6:
        lam = 0.6
    s.lam = lam

    residual = bins - item  # >= 0 for all shown bins

    # utility: residual capacities that could plausibly be refilled by future items
    # get credit; very large residuals (fresh bins) are penalized.
    rm = mean
    scale = rm if rm > 1.0 else 1.0
    utility = residual / (scale + residual)

    score = -residual.astype(np.float64) + 100.0 * lam * utility
    return score
# EVOLVE-BLOCK-END
