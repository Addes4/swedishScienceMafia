# EVOLVE-BLOCK-START
"""Online bin selection: best-fit with unusable-slack bonus."""
import numpy as np


class _State:
    def __init__(self):
        self.min_item = 100

    def update(self, item):
        if item < self.min_item:
            self.min_item = item


_S = _State()


def priority(item, bins):
    s = _S
    s.update(item)

    resid = bins - item  # nonnegative; bins only contain fitting bins

    score = -resid.astype(np.float64)  # best-fit: smaller residual wins

    # Reward residuals that no future item could ever use (below min seen size):
    # treat those bins as if perfectly filled, so they drop out of consideration.
    m = s.min_item
    if m > 1:
        closed = (resid < m).astype(np.float64)
        score = score + closed * 1000.0

    return score
# EVOLVE-BLOCK-END
