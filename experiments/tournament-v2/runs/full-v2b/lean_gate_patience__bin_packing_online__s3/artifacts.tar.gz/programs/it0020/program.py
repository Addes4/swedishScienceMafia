import numpy as np

_state = {
    "min_item": 101.0,
}


def priority(item, bins):
    st = _state
    if item < st["min_item"]:
        st["min_item"] = float(item)
    gap = st["min_item"]

    rem = bins.astype(np.float64)
    after = rem - item

    # Dominant term: tightness (prefer small residual after placement).
    tight = -after

    # Penalize residuals in the unusable dead zone (0, gap): this space can no
    # longer accept even the smallest item seen, so it is effectively wasted.
    # A residual of exactly 0 is perfect; residual >= gap is usable.
    dead = (after > 1e-9) & (after < gap - 1e-9)
    penalty = dead.astype(np.float64) * gap

    score = tight - penalty

    return score
