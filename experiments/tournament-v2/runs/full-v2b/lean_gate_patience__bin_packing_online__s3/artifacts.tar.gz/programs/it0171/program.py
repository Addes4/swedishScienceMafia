"""Online bin packing: vectorized best-fit with a small fillability bonus.

Primarily rank bins by the post-placement residual (best-fit: smallest residual
first). To break ties and slightly favor residuals that future items can pack
densely, add a small bonus when the residual is close to a multiple of common
item sizes observed so far. All computation is vectorized with numpy.
"""
import numpy as np

# Running statistics of item sizes seen so far.
_min = 101
_sum = 0.0
_cnt = 0.0
# Coarse size-frequency buckets (per unit size 1..100).
_hist = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    global _min, _sum, _cnt, _hist

    s = int(item)
    if s < _min:
        _min = s
    _sum += s
    _cnt += 1.0
    _hist[s] += 1.0

    mean = _sum / _cnt if _cnt > 0 else 40.0
    if mean < 1e-9:
        mean = 40.0

    min_size = _min if _min <= 100 else 1

    # Most likely small item size (mode of the histogram), used as a fill unit.
    if _cnt >= 8.0:
        # Consider the highest-frequency size among the smallest 40 sizes.
        window = _hist[1:41]
        unit = int(np.argmax(window)) + 1
    else:
        unit = max(1, min_size)

    residual = bins.astype(np.float64) - s  # post-placement residual

    # Base: best-fit -> smaller residual is better.
    scores = -residual

    # Bonus: strongly prefer residuals too small to hold even a min item
    # (clean close), and mildly prefer residuals that tile well with `unit`.
    closed = residual < min_size
    scores = scores + closed * 1000.0

    # For open bins, add a small bonus for residuals near a multiple of `unit`.
    r = np.maximum(residual, 0.0)
    nearest_mult = np.round(r / unit) * unit
    mismatch = np.abs(r - nearest_mult)
    wastage = np.where(nearest_mult > 0, mismatch / unit, mismatch)
    scores = scores - 0.05 * wastage

    # Light preference for leaving larger usable residual among equivalent fits.
    scores = scores + 1e-4 * residual

    return scores
