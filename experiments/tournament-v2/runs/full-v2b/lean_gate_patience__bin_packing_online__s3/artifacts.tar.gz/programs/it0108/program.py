# EVOLVE-BLOCK-START
"""Residual-to-common-size matching with histogram-driven targets."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.ones(101, dtype=np.float64)
        self.count = 1.0

    def observe(self, item):
        self.hist[item] += 1.0
        self.count += 1.0


_state = _State()

# Precompute size grid once
_SIZES = np.arange(101, dtype=np.float64)


def priority(item, bins):
    st = _state
    st.observe(item)

    p = st.hist / st.count  # probability of each size

    res = bins.astype(np.float64) - float(item)  # residual after placement
    res_clip = np.clip(res, 0.0, 100.0)

    # Strength (mass) of sizes that exactly match a residual: how likely is
    # this residual to be exactly refilled by a future item?
    ri = np.clip(res, 0, 100).astype(np.int64)
    match_mass = p[ri]

    # Tightness: prefer small residuals (best-fit flavor).
    tight = -res_clip

    # Reward residuals that are exactly fillable by a frequent item size.
    fill_bonus = 40.0 * match_mass

    # Penalize large residuals (fresh/reserved space) more when item is large.
    fresh = np.where(res >= 100.0 - item, 1.0, 0.0)
    fresh_pen = 0.05 * fresh * res_clip

    score = tight + fill_bonus - fresh_pen
    return score
# EVOLVE-BLOCK-END
