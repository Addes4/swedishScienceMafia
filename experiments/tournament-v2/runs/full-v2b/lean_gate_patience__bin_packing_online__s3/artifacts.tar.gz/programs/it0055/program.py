# EVOLVE-BLOCK-START
"""Best-fit with adaptive residual-value shaping for online bin packing."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0


_state = _State()


def priority(item, bins):
    """Rank bins: prefer smallest post-placement residual (best fit).

    Add a mild adaptive correction that slightly favors residuals which are
    unlikely to be exactly fillable later, keeping such bins clean of small
    stranded fragments when the running distribution is concentrated.
    """
    st = _state
    st.n += 1
    delta = item - st.mean
    st.mean += delta / st.n
    st.m2 += delta * (item - st.mean)

    if st.n > 1:
        std = (st.m2 / (st.n - 1)) ** 0.5
    else:
        std = 0.0

    residual = bins - item  # >= 0 for bins the item fits in

    # Primary: best fit -> smallest residual wins.
    score = -residual.astype(np.float64)

    # Adaptive term: penalize very small nonzero residuals slightly, since
    # fragment bins are hard to reuse; magnitude shrinks with high dispersion.
    mean = st.mean if st.mean > 1e-9 else 1.0
    disp = std / mean
    w = 0.15 / (1.0 + disp) if disp >= 0.0 else 0.15

    frag = np.where((residual > 0) & (residual < 0.35 * mean), w, 0.0)
    score -= frag

    return score
# EVOLVE-BLOCK-END
