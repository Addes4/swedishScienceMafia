"""Online bin packing: histogram-guided best-fit.

We score each candidate placement (bin with remaining capacity b, item size s)
by the post-placement residual r = b - s:

  * If r < smallest item seen so far, the bin is effectively closed -> huge bonus,
    ranked by how full it ends up (smaller r slightly better).
  * Otherwise we prefer residuals that are "compatible" with the observed size
    distribution: residuals that are close to a frequent item size, or to a
    small sum of frequent sizes, tend to be fillable later. We reward such
    residuals, mildly penalize large open residuals, and break the remaining
    ties toward the tightest fit (classic best-fit).

This keeps the robustness of best-fit while discouraging leaving awkward
residuals that later items cannot fill efficiently.
"""
import numpy as np

# Running statistics of observed items
_cnt_min = 101                 # smallest item size seen so far
_total = 0.0
_sum = 0.0
_hist = np.zeros(101, dtype=np.float64)   # histogram of observed sizes 1..100
_hist_total = 0.0

# Size of the histogram window used to decide "frequent" sizes
_FREQ_FRAC = 0.02


def _good_residual(r, min_size, mean):
    """Heuristic score for an open residual r (>= min_size).

    Higher is better. Combines:
      - tightness (small r preferred),
      - fillability: reward residuals near a common item size or a small sum
        of two common sizes, so the bin can still be closed cleanly later.
    """
    # Tightness term: smaller residual is better in a smooth way.
    tight = -(r - min_size)

    return tight


def priority(item, bins):
    global _cnt_min, _total, _sum, _hist, _hist_total

    s = int(item)
    if s < _cnt_min:
        _cnt_min = s
    _total += 1.0
    _sum += s
    if 1 <= s <= 100:
        _hist[s] += 1.0
        _hist_total += 1.0

    mean = _sum / _total if _total > 0 else 40.0
    if mean < 1e-9:
        mean = 40.0

    min_size = _cnt_min if _cnt_min <= 100 else 1

    n = bins.shape[0]
    scores = np.empty(n, dtype=np.float64)

    # Build the set of "good" candidate residuals from the histogram:
    # frequent item sizes and sums of two frequent sizes (bounded by 100).
    if _hist_total > 0:
        freq_sizes = np.nonzero(_hist >= _FREQ_FRAC * _hist_total)[0]
    else:
        freq_sizes = np.array([], dtype=np.int64)

    # Good residuals: frequent sizes plus pairwise sums within capacity.
    good = np.zeros(101, dtype=bool)
    if freq_sizes.size:
        good[freq_sizes] = True
        sums = []
        for a in freq_sizes:
            for b in freq_sizes:
                t = a + b
                if t <= 100:
                    sums.append(t)
        if sums:
            good[np.array(sums, dtype=np.int64)] = True

    for i in range(n):
        b = int(bins[i])
        residual = b - s

        if residual < min_size:
            # Closing the bin: best possible outcome; rank by how full it ends.
            scores[i] = 1e6 - residual
        else:
            base = -float(residual)  # best-fit tie-break (smaller residual better)
            if residual <= 100 and good[residual]:
                base += 5.0          # reward fillable residuals
            scores[i] = base

    return scores
