# EVOLVE-BLOCK-START
"""Online stochastic reachability fillability bin-selection rule."""
import numpy as np


class _State:
    def __init__(self):
        # histogram of item sizes 1..100 (index 0 unused)
        self.hist = np.ones(101, dtype=np.float64)
        self.count = 101.0
        self.ewma_pressure = 40.0
        self.calls = 0

    def update(self, item):
        self.hist[item] += 1.0
        self.count += 1.0
        self.ewma_pressure = 0.99 * self.ewma_pressure + 0.01 * item
        self.calls += 1


_S = _State()


def priority(item, bins):
    s = _S
    s.update(item)

    n = len(bins)
    # probability distribution of future item sizes
    p = s.hist / s.count
    p[0] = 0.0

    # expected number of items packing into residual capacity r  (knapsack-ish fill)
    # E_fill(r) ~ sum_{k>=1} P(at least k items fit) approximated via greedy
    # Use a simple mean-item recursion: expected fill count ~ r / mean_item weighted
    # but cap by probability of fitting small items.
    mean_item = float(np.dot(p, np.arange(101)))
    if mean_item < 1e-6:
        mean_item = 1.0

    # residual after placing item in each bin
    resid = bins - item  # nonnegative since bins only contain fitting bins

    # Expected "value" (number of future items) fillable into residual capacity.
    # Approximate: count_est(r) = exp-ish saturating function of r/mean_item,
    # but weighted by the fraction of items that are <= r (they can start a fill).
    frac_fit = np.cumsum(p)[resid]  # P(item <= resid)
    # expected items fill ~ (resid / mean_item) capped, times ability to use them
    fill_est = (resid / mean_item) * frac_fit

    # Fit tightness: prefer smaller residual after placement (pack tightly),
    # but strongly prefer residuals that can be refilled.
    # Score higher = better.
    # Tightness term: smaller resid -> higher score.
    tight = -resid.astype(np.float64)

    # Fillability term rewards leaving a residual that future items can use,
    # especially when residual is well matched to distribution.
    # Combine: modest tightness + fillability.
    score = tight + 2.0 * fill_est

    # Slight penalty for leaving a full empty bin (resid==100) to avoid waste
    score = score - 0.5 * (resid == 100).astype(np.float64) * 100.0

    return score
# EVOLVE-BLOCK-END
