# EVOLVE-BLOCK-START
"""Additive-combinatorics hybrid: large Bose-Chowla / Ruzsa Sidon sets + sum compaction.

Theory: for a Sidon set A of size n, |A-A| = n(n-1)+1 and |A+A| = n(n+1)/2,
so log|A-A|/log|A+A| -> 2. Maximizing size n within the integer range
maximizes this ratio (plus the size bonus). We build the largest Sidon set
possible using the Ruzsa / Bose-Chowla construction, then apply deterministic
sum-set compaction that preserves differences.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _sieve_primes(limit):
    if limit < 2:
        return []
    sieve = bytearray([1]) * (limit + 1)
    sieve[0] = sieve[1] = 0
    i = 2
    while i * i <= limit:
        if sieve[i]:
            sieve[i * i::i] = bytearray(len(sieve[i * i::i]))
        i += 1
    return [i for i in range(limit + 1) if sieve[i]]


def _ruzsa_sidon(p):
    """Ruzsa construction: A = {2pk + (k^2 mod p) : k = 0..p-1}.
    This is a Sidon set of size p in the range [0, ~2p^2]."""
    return [2 * p * k + ((k * k) % p) for k in range(p)]


def _bose_chowla(p):
    """Bose-Chowla: A = {2p*k + (k^2 mod p) : k=0..p-1} (same as Ruzsa variant,
    but with the classical parameterization using a primitive root).
    We use the standard: A = {k + p*(k^2 mod p) : k=0..p-1}."""
    return [k + p * ((k * k) % p) for k in range(p)]


def _counts(a):
    a = list(a)
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for j in range(i, len(a)):
            y = a[j]
            sums.add(x + y)
            diffs.add(x - y)
            diffs.add(y - x)
    return len(diffs), len(sums)


def _compact_sums(A, time_budget):
    """Deterministic replacement scan minimizing |A+A| subject to |A-A| floor.
    Uses incremental sum/diff multisets for efficiency."""
    A = list(A)
    n = len(A)
    if n < 3:
        return A
    deadline = time.time() + time_budget

    # Build base sum/diff counts (with multiplicities) incrementally.
    sum_count = {}
    for i in range(n):
        for j in range(i, n):
            s = A[i] + A[j]
            sum_count[s] = sum_count.get(s, 0) + (1 if i == j else 2)

    def add_sums(x, sign):
        for y in A:
            s = x + y
            sum_count[s] = sum_count.get(s, 0) + sign
        sum_count[2 * x] = sum_count.get(2 * x, 0) + sign

    def distinct_sums():
        return sum(1 for v in sum_count.values() if v > 0)

    def diff_size():
        d = set()
        for i in range(n):
            for j in range(i, n):
                d.add(A[i] - A[j])
                d.add(A[j] - A[i])
        return len(d)

    base_s = distinct_sums()
    base_d = diff_size()
    diff_floor = max(2, int(0.85 * base_d))

    improved = True
    while improved and time.time() < deadline:
        improved = False
        centroid = sum(A) // n
        order = list(range(n))
        random.shuffle(order)
        for i in order:
            if time.time() > deadline:
                break
            old = A[i]
            # Remove old element's sum contributions.
            for y in A:
                s = old + y
                sum_count[s] -= 1
            sum_count[2 * old] -= 1
            # Candidate values near centroid and old value.
            candidates = set()
            for d in range(-30, 31):
                candidates.add(centroid + d)
            for d in range(-15, 16):
                candidates.add(old + d)
            candidates.discard(old)

            best_v = old
            best_s = base_s
            for v in candidates:
                if v in A:
                    continue
                # Add v's sum contributions.
                for y in A:
                    s = v + y
                    sum_count[s] = sum_count.get(s, 0) + 1
                sum_count[2 * v] = sum_count.get(2 * v, 0) + 1
                ns = distinct_sums()
                # Remove v's contributions.
                for y in A:
                    s = v + y
                    sum_count[s] -= 1
                sum_count[2 * v] -= 1
                if ns < best_s:
                    # Check difference floor cheaply: replace and count.
                    A[i] = v
                    nd = diff_size()
                    A[i] = old
                    if nd >= diff_floor:
                        best_s = ns
                        best_v = v
            # Re-add old (or best_v) contributions.
            if best_v != old:
                A[i] = best_v
                for y in A:
                    if y == best_v:
                        continue
                    s = best_v + y
                    sum_count[s] = sum_count.get(s, 0) + 1
                sum_count[2 * best_v] = sum_count.get(2 * best_v, 0) + 1
                base_s = best_s
                base_d = diff_size()
                diff_floor = max(2, int(0.85 * base_d))
                improved = True
            else:
                for y in A:
                    s = old + y
                    sum_count[s] = sum_count.get(s, 0) + 1
                sum_count[2 * old] = sum_count.get(2 * old, 0) + 1
    return A


def solve():
    """Return a list of distinct integers maximizing log|A-A|/log|A+A|."""
    best = None
    best_score = -1.0

    # Stage 1: build large Sidon sets via Bose-Chowla/Ruzsa for many primes.
    # Score scales with size, so we prefer the largest primes that fit in range.
    primes = _sieve_primes(700)
    # Try primes spanning a wide range of sizes.
    test_primes = primes
    for p in test_primes:
        cand = _ruzsa_sidon(p)
        if len(cand) < 2:
            continue
        # Center to reduce magnitude.
        c = (max(cand) + min(cand)) // 2
        cand = [x - c for x in cand]
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    # Also try the Bose-Chowla variant.
    for p in primes:
        cand = _bose_chowla(p)
        if len(cand) < 2:
            continue
        c = (max(cand) + min(cand)) // 2
        cand = [x - c for x in cand]
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    # Stage 2: sum-set compaction on the best Sidon set.
    deadline = time.time() + 115
    cur_best = best[:]
    cur_score = best_score
    # Only compact if the set is small enough for O(n^2) to be tractable.
    if len(cur_best) <= 400:
        for budget in (20, 40, 50):
            if time.time() > deadline:
                break
            cand = _compact_sums(cur_best, budget)
            if len(set(cand)) < 2:
                continue
            s = _score(cand)
            if s > cur_score:
                cur_best, cur_score = cand[:], s

    # Stage 3: light local search for final polish.
    remaining = max(1.0, deadline - time.time())
    if remaining > 1 and len(cur_best) <= 2000:
        cur = cur_best[:]
        span = max(1, (max(cur) - min(cur)) // 100) if len(cur) > 1 else 1
        end = time.time() + min(remaining, 30)
        while time.time() < end:
            cand = cur[:]
            i = random.randrange(len(cand))
            delta = random.randint(-span, span)
            if delta == 0:
                delta = 1
            cand[i] += delta
            if len(set(cand)) != len(cand):
                continue
            s = _score(cand)
            if s >= cur_score:
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s
            elif random.random() < 0.02:
                cur = cand

    return sorted(set(best))
# EVOLVE-BLOCK-END
