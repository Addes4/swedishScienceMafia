# EVOLVE-BLOCK-START
"""Hybrid Golomb + dense-core construction for maximizing log|A-A|/log|A+A|."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    """Compute score components quickly."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def _greedy_golomb(n, max_val, rng):
    """Greedily build a Golomb ruler with n marks."""
    marks = [0]
    candidates = list(range(1, max_val + 1))
    rng.shuffle(candidates)
    for _ in range(n - 1):
        best_c = None
        best_new = -1
        # Try a sample of candidates
        sample = candidates[:min(200, len(candidates))]
        for c in sample:
            if c in marks:
                continue
            new_diffs = set()
            ok = True
            for m in marks:
                d = abs(c - m)
                if d in new_diffs:
                    ok = False
                    break
                new_diffs.add(d)
            if not ok:
                continue
            # count total distinct diffs
            all_d = set()
            new_set = marks + [c]
            for i in range(len(new_set)):
                for j in range(i + 1, len(new_set)):
                    all_d.add(abs(new_set[i] - new_set[j]))
            if len(all_d) > best_new:
                best_new = len(all_d)
                best_c = c
        if best_c is None:
            # fallback: pick any unused
            for c in candidates:
                if c not in marks:
                    best_c = c
                    break
        if best_c is not None:
            marks.append(best_c)
    return marks


def _build_dense_golomb(m, golomb_size, gap, rng):
    """Dense core {0..m} plus Golomb-like values offset by gap."""
    core = list(range(m + 1))
    g = _greedy_golomb(golomb_size, max(50, golomb_size * 8), rng)
    offset = m + gap
    extra = [offset + x for x in g]
    return core + extra


def _local_search(a, deadline, rng):
    """Simulated annealing on the actual objective."""
    a = sorted(set(a))
    best = a[:]
    best_score = _score(a)
    cur = a[:]
    cur_score = best_score
    T = 0.05
    steps = 0
    while time.time() < deadline:
        steps += 1
        if steps % 200 == 0:
            T *= 0.999
        cand = cur[:]
        op = rng.random()
        if op < 0.5 and len(cand) > 2:
            # mutate one element
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-5, 5)
        elif op < 0.75:
            # add element
            if len(cand) < 4000:
                base = rng.choice(cand)
                cand.append(base + rng.randint(1, 30))
        elif op < 0.9 and len(cand) > 3:
            # remove element
            i = rng.randrange(len(cand))
            cand.pop(i)
        else:
            # large jump: rebuild from dense core
            m = rng.randint(2, 8)
            gs = rng.randint(3, 10)
            gap = rng.randint(1, 5)
            cand = _build_dense_golomb(m, gs, gap, rng)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > best_score or rng.random() < math.exp((s - cur_score) / max(T, 1e-6)):
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        if rng.random() < 0.02:
            cur = best[:]
            cur_score = best_score
    return best, best_score


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Phase 1: try many structured constructions
    constructions = []
    for m in range(0, 12):
        for gs in range(3, 15):
            for gap in [1, 2, 3, 5, 8, 13]:
                constructions.append((m, gs, gap))
    rng.shuffle(constructions)

    phase1_deadline = time.time() + 40
    for (m, gs, gap) in constructions:
        if time.time() > phase1_deadline:
            break
        cand = _build_dense_golomb(m, gs, gap, rng)
        cand = sorted(set(cand))
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    # Also try pure dense intervals and pure golomb rulers
    for n in range(3, 60):
        cand = list(range(n))
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]
    for n in range(3, 40):
        cand = _greedy_golomb(n, n * n, rng)
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    # Phase 2: local search from best
    if best is None:
        best = [0, 1, 3]
        best_score = _score(best)

    improved, imp_score = _local_search(best, deadline, rng)
    if imp_score > best_score:
        best = improved
        best_score = imp_score

    # Phase 3: restart local search from several seeds if time permits
    while time.time() < deadline:
        # random restart: dense core + greedy golomb
        m = rng.randint(1, 10)
        gs = rng.randint(3, 12)
        gap = rng.randint(1, 10)
        seed = _build_dense_golomb(m, gs, gap, rng)
        remaining = deadline - time.time()
        if remaining < 5:
            break
        sub_deadline = time.time() + min(remaining, 15)
        cand, s = _local_search(seed, sub_deadline, rng)
        if s > best_score:
            best = cand
            best_score = s

    return sorted(set(best))
# EVOLVE-BLOCK-END
