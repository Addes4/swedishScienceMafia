# EVOLVE-BLOCK-START
"""Improved: structured Sidon-like constructions + local search."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _ratio(a):
    """Pure log|A-A| / log|A+A| without the size bonus (used for seed ranking)."""
    a = set(a)
    if len(a) < 2:
        return float("-inf")
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) <= 1:
        return float("-inf")
    return math.log(len(diffs)) / math.log(len(sums))


def _quadratic_set(p):
    """Bose-Chowla-like Sidon set: A = {i + p*(i^2 mod p) : i in 0..p-1}."""
    return [i + p * ((i * i) % p) for i in range(p)]


def _greedy_sidon(n, seed=0):
    """Greedily build a Sidon set of size ~n within a bounded range."""
    rng = random.Random(seed)
    A = []
    used_sums = set()
    used_diffs = set()
    cand = list(range(1, 4 * n * n + 10))
    rng.shuffle(cand)
    for x in cand:
        ok = True
        new_sums = set()
        new_diffs = set()
        for a in A:
            s = x + a
            if s in used_sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
            d1 = x - a
            d2 = a - x
            if d1 in used_diffs or d2 in used_diffs or d1 in new_diffs or d2 in new_diffs:
                ok = False
                break
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            A.append(x)
            used_sums |= new_sums | {2 * x}
            used_diffs |= new_diffs
        if len(A) >= n:
            break
    return A


def _bounded_sidon(n, span, seed=0):
    """Build a Sidon-like set of size n inside [0, span] using randomized greedy,
    biased toward keeping elements near the middle (compacting the sum set)."""
    rng = random.Random(seed)
    A = []
    used_sums = set()
    used_diffs = set()
    center = span // 2
    cand = sorted(range(0, span + 1), key=lambda x: (abs(x - center), rng.random()))
    for x in cand:
        ok = True
        new_sums = set()
        new_diffs = set()
        for a in A:
            s = x + a
            if s in used_sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
            d1 = x - a
            d2 = a - x
            if d1 in used_diffs or d2 in used_diffs or d1 in new_diffs or d2 in new_diffs:
                ok = False
                break
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            A.append(x)
            used_sums |= new_sums | {2 * x}
            used_diffs |= new_diffs
        if len(A) >= n:
            break
    return A


def _reflect_half(A):
    """Reflect the upper half of A around its center to try to shrink |A+A|."""
    if len(A) < 4:
        return A
    B = sorted(A)
    c = (B[0] + B[-1]) // 2
    n = len(B)
    out = B[: n // 2] + [2 * c - x for x in B[n // 2:]]
    if len(set(out)) != len(B):
        return A
    return out


def _local_search(seed, deadline, best, best_score):
    """Run multi-scale local search from `seed` until `deadline`.
    Returns updated (best, best_score)."""
    cur = seed[:]
    cur_score = _score(cur)
    if cur_score > best_score:
        best, best_score = cur[:], cur_score
    span_cur = (max(cur) - min(cur)) if len(cur) > 1 else 1
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        if random.random() < 0.7:
            step = max(1, span_cur // 50)
        else:
            step = max(1, span_cur // 8)
        delta = random.randint(-step, step)
        if delta == 0:
            delta = 1
        cand[i] += delta
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            span_cur = (max(cur) - min(cur)) if len(cur) > 1 else 1
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.03:
            cur = cand
            span_cur = (max(cur) - min(cur)) if len(cur) > 1 else 1
    return best, best_score


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    # Collect a diverse pool of candidate seeds with their pure ratios.
    seeds = []  # list of (ratio, list)

    def _add(cand):
        r = _ratio(cand)
        if r > float("-inf"):
            seeds.append((r, list(cand)))

    # Try structured quadratic constructions for a range of primes.
    primes = [p for p in range(11, 200) if all(p % d for d in range(2, int(p ** 0.5) + 1))]
    for p in primes:
        cand = _quadratic_set(p)
        for shift in (0, -p // 2):
            _add([x + shift for x in cand])
        r = _reflect_half(cand)
        if len(set(r)) == len(cand):
            _add(r)

    # Bounded Sidon constructions inside a tight span.
    for n in [20, 40, 60, 90, 120, 160, 200]:
        for span_mult in (2, 3, 4, 6):
            span = n * n * span_mult
            if span > 10 ** 6:
                continue
            for seed in (n, n * 7 + 1, n * 13 + 5):
                cand = _bounded_sidon(n, span, seed=seed)
                if len(cand) >= 2:
                    _add(cand)

    # Greedy Sidon sets of various sizes.
    for n in [30, 50, 80, 120, 150]:
        cand = _greedy_sidon(n, seed=n)
        if len(cand) >= 2:
            _add(cand)

    if not seeds:
        seeds = [(_ratio([7, 15, 18, 22, -3, -2]), [7, 15, 18, 22, -3, -2])]

    # Deduplicate by frozenset, then rank by pure ratio (size bonus only as tiebreak).
    seen = set()
    uniq = []
    for r, a in sorted(seeds, key=lambda t: (-t[0], -len(set(t[1])))):
        key = frozenset(a)
        if key in seen:
            continue
        seen.add(key)
        uniq.append((r, a))

    # Keep top-K seeds by pure ratio for refinement.
    K = 20
    top = uniq[:K]

    # Initialize best from the highest-ratio seed by _score.
    best = None
    best_score = -1.0
    for r, a in top:
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a[:]

    # Allocate remaining time across top-K seeds, weighted toward higher ranks.
    start = time.time()
    total_budget = 100.0
    # Weight: rank 1 gets the largest share.
    weights = [K - i for i in range(len(top))]
    wsum = sum(weights)
    elapsed = 0.0
    for idx, (r, a) in enumerate(top):
        share = total_budget * weights[idx] / wsum
        sub_deadline = start + elapsed + share
        best, best_score = _local_search(a, sub_deadline, best, best_score)
        elapsed = time.time() - start
        if elapsed >= total_budget:
            break

    # Final polishing: try reflecting and small shifts on the best found.
    for shift in range(-3, 4):
        c2 = [x + shift for x in best]
        s = _score(c2)
        if s > best_score:
            best_score = s
            best = c2[:]
    r = _reflect_half(best)
    if len(set(r)) == len(best):
        s = _score(r)
        if s > best_score:
            best_score = s
            best = r[:]

    # Also try reflecting the top-K seeds directly as a final tiebreak.
    for r_ratio, a in top:
        rr = _reflect_half(a)
        if len(set(rr)) == len(a):
            s = _score(rr)
            if s > best_score:
                best_score = s
                best = rr[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END