# EVOLVE-BLOCK-START
"""Golomb + dense-core construction maximizing log|A-A|/log|A+A|."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _greedy_golomb(n, max_val, rng):
    """Greedily build a near-Golomb ruler with n marks up to max_val."""
    marks = [0]
    used_diffs = set()
    candidates = list(range(1, max_val + 1))
    rng.shuffle(candidates)
    for _ in range(n - 1):
        best_c = None
        best_new = -1
        for c in candidates[:min(400, len(candidates))]:
            if c in marks:
                continue
            new_d = set()
            ok = True
            for m in marks:
                d = abs(c - m)
                if d in new_d:
                    ok = False
                    break
                new_d.add(d)
            if not ok:
                continue
            new_unique = len(new_d - used_diffs)
            if new_unique > best_new:
                best_new = new_unique
                best_c = c
                if new_unique == len(marks):
                    break
        if best_c is None:
            for c in candidates:
                if c not in marks:
                    best_c = c
                    break
        if best_c is None:
            break
        marks.append(best_c)
        for m in marks[:-1]:
            used_diffs.add(abs(best_c - m))
    return marks


def _build_dense_golomb(m, golomb_size, gap, rng, golomb_max=None):
    """Dense core {0..m} plus a Golomb-like block offset by gap."""
    core = list(range(m + 1))
    if golomb_size <= 0:
        return core
    if golomb_max is None:
        golomb_max = max(60, golomb_size * golomb_size)
    g = _greedy_golomb(golomb_size, golomb_max, rng)
    offset = m + gap
    extra = [offset + x for x in g]
    return core + extra


def _incremental_score(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            diffs.add(ai - a[j])
            diffs.add(a[j] - ai)
            sums.add(ai + a[j])
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _refine(a, deadline, rng):
    """Targeted local search that tries to increase differences and decrease sums."""
    a = sorted(set(a))
    best = a[:]
    best_score = _score(a)
    cur = a[:]
    cur_score = best_score
    T = 0.08
    step = 0
    while time.time() < deadline:
        step += 1
        if step % 500 == 0:
            T = max(0.0005, T * 0.997)
        cand = cur[:]
        op = rng.random()
        if op < 0.35 and cand:
            i = rng.randrange(len(cand))
            # move a mark by a difference to another mark
            j = rng.randrange(len(cand))
            d = cand[i] - cand[j]
            if d == 0:
                d = rng.randint(1, 10)
            cand[i] = cand[j] + d + rng.randint(-2, 2)
        elif op < 0.6 and len(cand) < 4000:
            # add an element chosen to introduce new differences
            x = rng.choice(cand)
            y = rng.choice(cand)
            new = x + (x - y) + rng.randint(-1, 1)
            cand.append(new)
        elif op < 0.8 and len(cand) > 3:
            cand.pop(rng.randrange(len(cand)))
        else:
            # swap two elements
            if len(cand) >= 2:
                i, j = rng.randrange(len(cand)), rng.randrange(len(cand))
                cand[i], cand[j] = cand[j], cand[i]
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _incremental_score(cand)
        if s > cur_score or rng.random() < math.exp((s - cur_score) / max(T, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best = cand[:]
                best_score = s
        if rng.random() < 0.01:
            cur = best[:]
            cur_score = best_score
    return best, best_score


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 110

    best = [0, 1, 3]
    best_score = _score(best)

    # Phase 1: sweep structured dense+Golomb constructions
    phase1_deadline = time.time() + 45
    configs = []
    for m in range(0, 16):
        for gs in range(2, 18):
            for gap in [1, 2, 3, 5, 8, 13, 21, 34]:
                configs.append((m, gs, gap))
    rng.shuffle(configs)
    for (m, gs, gap) in configs:
        if time.time() > phase1_deadline:
            break
        cand = _build_dense_golomb(m, gs, gap, rng)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _incremental_score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    # Also test pure dense intervals for small n
    for n in range(2, 80):
        cand = list(range(n))
        s = _incremental_score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    # Phase 2: refine best
    if time.time() < deadline:
        cand, s = _refine(best, deadline, rng)
        if s > best_score:
            best, best_score = cand, s

    # Phase 3: restarts from diverse seeds until deadline
    while time.time() < deadline:
        m = rng.randint(0, 14)
        gs = rng.randint(2, 16)
        gap = rng.choice([1, 2, 3, 5, 8, 13, 21, 34])
        seed = _build_dense_golomb(m, gs, gap, rng)
        remaining = deadline - time.time()
        if remaining < 3:
            break
        sub_deadline = time.time() + min(remaining, 12)
        cand, s = _refine(seed, sub_deadline, rng)
        if s > best_score:
            best, best_score = cand, s

    return sorted(set(best))
# EVOLVE-BLOCK-END