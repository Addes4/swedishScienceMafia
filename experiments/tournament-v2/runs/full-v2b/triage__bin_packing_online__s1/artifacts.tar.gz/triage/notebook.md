# Research notebook: bin_packing_online

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.961642.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 5 | Precompute a score table for all 100 item sizes × 101 remaining capacities using an offline dynamic-programming heuristic that simulates future packing, then us | 0.40 | favourite | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra (swapped) | invalid | 0.000000 |
| 4 | Divide bins into two classes: those with remaining capacity >= 50 and those below, and apply best-fit only among the “below-half” bins if any exist, otherwise b | 0.35 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961642 |
| 1 | Maintain an exponential moving average of the arriving item sizes, and when an item is relatively large (e.g., >70th percentile of recent history), prefer bins  | 0.23 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 2 | Implement a harmonic-like scoring: return a score that heavily penalizes large residual gaps but becomes neutral for perfectly fitting items, e.g., `return -((b | 0.19 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 3 | Track counts of items placed in each bin so far (via state), and add a small bonus to bins that already contain more items, encouraging packing efficiency via g | 0.17 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 0 | Add a small randomized tie-break to the best-fit score, e.g., `return -(bins - item) + np.random.uniform(-0.001, 0.001, size=len(bins))`, to avoid systematic bi | 0.14 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.571166 |

Best after round 1: **0.961642** (spent $0.01)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Classify bins into "almost-full" (remaining < 20) and "open" (remaining >= 20). For items <= 20, target "almost-full" bins via best-fit; otherwise, target "open | 0.17 | favourite | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra (swapped) | not_better | 0.434084 |
| 2 | Implement a dual-priority system based on item size: if item > 50, use worst-fit (prefer largest gap) to keep small-bin options open; if item <= 50, use best-fi | 0.13 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961174 |
| 3 | Model the state as a game tree and use a one-step lookahead: for each candidate bin, simulate placing the item, then score the resulting bin configuration using | 0.12 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.396100 |
| 0 | Use a sum-of-squares heuristic: score = -((bins - item)^2). This strongly prefers either perfect fits or at least very tight fits, while moderately penalizing l | 0.03 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 1 | Treat the item size as a fraction of remaining capacity and target bins that leave a residual capacity close to common recently seen item sizes. Maintain a hist | 0.02 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 5 | Instead of a fixed scoring function, treat the problem as an online assignment task: apply the SNF (Sum of Normalized Fit) rule where score = -(bins - item) / i | -0.06 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 2: **0.961642** (spent $0.01)

## Round 3

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Use a learned linear model: maintain online sufficient statistics (mean, variance) of arriving items, and define a precomputed 101×101 score table `W[remaining] | 0.26 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 5 | Devise a "probabilistic best-fit" that, for each bin, computes `score = -(bins - item)` as a base, then adds an entropic bonus `+ λ * log(P(bins - item))`, wher | 0.01 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 2 | Treat each bin as a "bin-packing profile" string (e.g., the sequence of items placed into it so far, compressed by size ranges) and maintain a dictionary of suc | -0.00 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.960941 |
| 0 | Model the remaining-capacity distribution as a set of discrete "levels" (e.g., multiples of 10) and, for the incoming item, compute a score based on the Kolmogo | -0.03 | middle | Qwen/Qwen3.5-9B:together (swapped) | invalid | 0.000000 |
| 4 | Model the current bins as nodes in a graph and the incoming item as a connection. Use a spectral scoring: for each bin, compute the Fiedler vector of the residu | -0.04 | long_shot | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | invalid | 0.000000 |
| 3 | Apply a "first-fit decreasing" heuristic on the fly by reserving a subset of bins for large items: when `item > 70`, score bins proportionally to `(bins - item) | -0.12 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.961642 |

Best after round 3: **0.961642** (spent $0.03)

## Round 4

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 2 | Implement the `Harmonic` algorithm for online bin packing: classify items into intervals (0,1/3], (1/3,1/2], (1/2,1] of bin capacity, and assign each bin a “col | 0.09 | favourite | Qwen/Qwen3.5-9B:together (swapped) | invalid | 0.000000 |
| 1 | Maintain a running estimate of the distribution of future item sizes using an online kernel density estimator. Score each bin by the expected number of future i | 0.03 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.443810 |
| 4 | Treat the problem as a controlled fragmentation process: maintain a global histogram of all current residual capacities. Score a bin by the reduction in the L1- | 0.01 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.502922 |
| 5 | Simulate a simple offline lower-bound check: for each bin, compute the sum of items that would be needed to exactly fill its residual after placing the current  | -0.05 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 3 | Use a “load-balancing” score: `score = -(bins - item) + α * (count_of_items_in_bin)` where `count_of_items_in_bin` is tracked per bin in state. This rewards bin | -0.13 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 0 | For each bin, score by `-(bins - item) / max(1, bins)` so that relative waste is minimized—this amplifies the penalty for leaving a small sliver versus a large  | -0.19 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.961642 |

Best after round 4: **0.961642** (spent $0.05)

## Round 5

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Simulate future packing by drawing a small number of random items (e.g., 10) from a parametric model fitted online to recent item arrivals (e.g., Weibull). For  | 0.08 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 5 | Classify each item and bin into one of several “size ranks” (e.g., small ≤ 20, medium 21–70, large > 70). Maintain a penalty matrix updated online: each time a  | -0.04 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 0 | Introduce a “buffer zone” policy: when an item’s size is within the top 10% of historically observed sizes, restrict placement to bins whose remaining capacity  | -0.04 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 2 | Use a two-stage decision: if the item’s size exactly equals the remaining capacity of any bin (perfect fit), immediately rank that bin highest; otherwise, apply | -0.07 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.959550 |
| 1 | Maintain an online estimate of the cumulative distribution function of item sizes. For each bin, compute a score = -(bins - item) − λ * CDF(bins - item), where  | -0.12 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 3 | Track a running histogram of residual capacities across all bins after each placement. Score a candidate bin by the Jensen–Shannon divergence between the histog | -0.21 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 5: **0.961642** (spent $0.07)

## Round 6

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 2 | Learn a value function V(gap_vector) from previous instances using a small neural network trained to predict final number of bins used. At decision time, for ea | 0.27 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 3 | Track occurrences of “regret” events — when a placed item later blocks a perfect fit for a subsequent item. Maintain regret counts per (item_size, chosen_gap_le | 0.03 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961642 |
| 4 | Combine best-fit with a “future-proof” bonus: for each bin, score = -(bins - item) + γ * I(bins - item is exactly one of the K most frequent item sizes seen rec | 0.01 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961408 |
| 0 | Use an exponential smoothing model of the item-size sequence to forecast the next few items. For each candidate bin, simulate placing the current item plus thos | -0.01 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.960010 |
| 5 | Partition bins into chains: each time a bin receives an item, record the sequence of leftover gaps it produces. When a new item arrives, score bins higher if th | -0.05 | long_shot | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra (swapped) | not_better | 0.946702 |
| 1 | Define a state vector of all current remaining capacities. For each candidate bin, compute the resulting state vector, then score it by the L2 norm or entropy o | -0.10 | long_shot | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra (swapped) | not_better | 0.961642 |

Best after round 6: **0.961642** (spent $0.10)

## Round 7

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 5 | Use a "regret-minimization" approach with expert advice: run several classic bin-choice heuristics (best-fit, worst-fit, first-fit, etc.) in parallel on a virtu | 0.11 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961176 |
| 4 | Define a potential function over the multiset of remaining capacities: `Φ = sum_{bins} (remaining / 100)^p` with `p > 1` (e.g., p=2). For each candidate bin, co | 0.02 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.396100 |
| 3 | Implement a "dual threshold" policy with dynamic thresholds: if the item is below a lower threshold (e.g., 25th percentile of recent sizes), use best-fit among  | -0.09 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 2 | Treat the problem as an online bipartite matching: each bin's residual capacity is a resource, and the incoming item is a demand. Use the "balanced" criterion f | -0.17 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.956304 |
| 1 | Maintain an online reservoir sample of recent items and, for each candidate bin, compute the number of items from the sample that could exactly fit into the lef | -0.18 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.473545 |
| 0 | Score bins to minimize the expected Gini coefficient of the remaining capacities after placement, where a high Gini (few large gaps and many small ones) is pref | -0.23 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 7: **0.961642** (spent $0.12)

## Round 8

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Encode the multiset of all current remaining capacities into a permutation-invariant representation via a Deep Sets architecture (small, pre-trained offline on  | 0.14 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 0 | Treat the bin-choice as an online convex optimization problem using an exponentiated gradient algorithm. Maintain log-probability weights for each possible rema | 0.12 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.891319 |
| 2 | Use a “bin-age” and “gap-cohort” strategy: tag bins by the epoch (group of 50 arrivals) in which they were first opened, and track the empirical fill rate of bi | 0.00 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 5 | Track the sequence of per-bin “packing densities” (sum of items placed / (100 - residual)) across time to estimate the process’s drift. When a bin choice would  | -0.04 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.779130 |
| 3 | Apply an “online knapsack reservoir” score: for each bin, simulate solving a small online knapsack problem over the next N expected items (using an autoregressi | -0.14 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 1 | Implement a “virtual pairing” heuristic: maintain a pool of observed frequent item-size combinations that sum to common leftover gaps, updated online via a slid | -0.17 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 8: **0.961642** (spent $0.14)

