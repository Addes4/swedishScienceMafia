# EVOLVE-BLOCK-START
"""Classified bin choice: tight-fit into almost-full bins, worst-fit into open bins.

Bins are split into "almost-full" (remaining capacity < T) and "open" (>= T).
Small items (size <= T) go to the almost-full bin they fit most tightly, filling
the residual space of nearly-closed bins.  Larger items go to the open bin with
the most remaining space, keeping large pockets of free space available.  The
threshold T adapts to the running mean of the observed item sizes.
"""
import numpy as np

_state = {"sum": 0.0, "n": 0, "T": 20}


def priority(item, bins):
    st = _state
    st["sum"] += item
    st["n"] += 1
    mean = st["sum"] / st["n"]

    # Threshold tracks ~half the running mean item size.  Small items try to fill
    # the leftovers of almost-full bins; large items seek open bins.
    T = int(mean * 0.5)
    if T < 5:
        T = 5
    elif T > 40:
        T = 40

    remaining = bins  # numpy int64 array of remaining capacities

    if item <= T:
        # Target almost-full bins (remaining < T) via best fit; among open bins
        # fall back to a mild best-fit so large items keep the roomy bins.
        small_bins = remaining < T
        # best fit among almost-full bins: maximize (T - remaining) i.e. smallest remaining
        score_small = np.where(small_bins, 100 - remaining, -1.0)
        # fallback: best fit generally
        score_fallback = -(remaining - item)
        score = np.where(small_bins, score_small, score_fallback)
        # forbid any bin that doesn't actually fit
        score = np.where(remaining >= item, score, -1e9)
        return score
    else:
        # Target open bins (remaining >= T) via worst fit: most remaining capacity.
        open_bins = remaining >= T
        score_open = np.where(open_bins, remaining.astype(np.float64), -1e9)
        # if no open bin exists for this item, fall back to best fit everywhere
        score_best = -(remaining - item).astype(np.float64)
        score = np.where(open_bins.any(), score_open, score_best)
        score = np.where(remaining >= item, score, -1e9)
        return score
# EVOLVE-BLOCK-END
