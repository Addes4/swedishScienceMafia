# EVOLVE-BLOCK-START
"""Best-fit with randomized tie-breaking to avoid systematic bias toward early bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit base priority: higher (less negative) = fits tighter
    fitness = -(bins - item)
    
    # Small random perturbation to break ties randomly and avoid bias toward early bins
    rng = np.random.default_rng()
    rng.shuffle(fitness)
    
    return fitness + rng.uniform(-0.0001, 0.0001, size=bins.shape)
# EVOLVE-BLOCK-END
