import numpy as np
from typing import List, Optional

class OnlineKnapsackScorer:
    def __init__(self, ar_order: int = 1, forecast_horizon: int = 64):
        self.ar_order = ar_order
        self.forecast_horizon = forecast_horizon
        # AR(1) parameters: φ and σ²
        self.phi = 0.0
        self.sigma2 = 100.0  # variance; bin sizes are 1-100, so this is reasonable
        self._observed_history = []

    def update_ar_model(self, items: np.ndarray):
        """Update AR(1) model parameters using observed item sizes."""
        if len(items) >= self.ar_order + 1:
            # Compute lag-1 correlation for φ
            x = items[-len(items) - self.ar_order - 1:] if len(items) > self.ar_order + 1 else items
            errors = x[1:] - self.phi * x[:-1] if hasattr(self, 'phi') else x[1:]
            self.sigma2 = np.var(errors) if len(errors) > 0 else self.sigma2
            
            # Simple recursive least squares for φ
            if len(x) >= 2:
                y = x[1:]
                z = x[:-1]
                numer = np.sum(y * z)
                denom = np.sum(z ** 2)
                if denom > 0:
                    self.phi = numer / denom
            else:
                self.phi = 0.0
            if self.phi > 1.0: self.phi = 1.0
            if self.phi < -1.0: self.phi = -1.0

    def forecast_items(self) -> np.ndarray:
        """Generate N future items using AR(1)."""
        N = self.forecast_horizon
        if N <= 0: return np.zeros(0)
        rng = np.random.default_rng()
        items = np.zeros(N, dtype=float)
        # Warm-up from last observed item if available
        if hasattr(self, '_last_item') and self._last_item > 0:
            items[0] = self._last_item
        else:
            items[0] = 50  # initial guess (mean size)
        for i in range(1, N):
            x_t = self.phi * items[i - 1] + rng.normal(0, np.sqrt(self.sigma2))
            x_t = max(1, min(100, int(round(x_t))))
            items[i] = float(x_t)
        return items

    def pack_knapsack(self, capacity: float, items: np.ndarray) -> float:
        """Simple greedy knapsack solver using item value=size."""
        # All items have equal 'value' per se, but different 'weight' (size)
        # First-fit decreasing by value/weight = 1/unit
        # So we'd just take as many as fit.
        item_sizes = np.array([min(int(size), int(capacity)) for size in items if size < capacity and size > 0], dtype=float)
        if len(item_sizes) == 0: return 0.0
        total_value = 0.0
        for size in item_sizes:
            if capacity >= 0:
                total_value += size
                capacity -= size
            else:
                break
        return total_value

    def score_bins(self, bins_residuals: np.ndarray) -> np.ndarray:
        """Score each bin's residual capacity using AR(1) forecast and expected knapsack value."""
        if len(bins_residuals) == 0: return np.array([])
        bins_residuals = np.asarray(bins_residuals)
        forecasted_items = self.forecast_items()
        if len(forecasted_items) == 0:
            # Fallback: just use residuals
            return bins_residuals

        scores = np.zeros(len(bins_residuals), dtype=float)
        for i, res in enumerate(bins_residuals):
            score = self.pack_knapsack(res, forecasted_items)
            # Normalize by bin's residual max possible
            if res > 0:
                max_complement = np.maximum(0, np.sum(np.clip(forecasted_items, 0, res)))
                scores[i] = score / max_complement if max_complement > 0 else score
            else:
                scores[i] = 0.0
        return np.maximum(scores, 0.0)

    def __call__(self, bins_residuals: np.ndarray, item: Optional[int] = None, update_model: bool = True, history: Optional[np.ndarray] = None) -> np.ndarray:
        # Update model based on observed stream items if provided
        if update_model and history is not None:
            self.update_ar_model(history)
            if item is not None:
                self._last_item = item
        elif item is not None:
            self._last_item = item

        scores = self.score_bins(bins_residuals)
        return scores


def priority(item: int, bins_residuals: np.ndarray, history: Optional[np.ndarray] = None, history_len: Optional[int] = 100) -> np.ndarray:
    """
    Apply online knapsack reservoir scoring:
    Forecast future items using AR(1) auto-regression, then simulate knapsack packing
    in each bin. Use the expected packing value as the score.

    Args:
        item: Current item size (1–100)
        bins_residuals: Residual capacity for each bin (float or int), may be empty
        history: Lookback sliding window of prior items (np.ndarray if len(history) > 0)
        history_len: Use most recent items to train AR(1)

    Returns:
        np.ndarray of scores (higher = more promising bin)
    """
    scorer = OnlineKnapsackScorer()
    if history is not None:
        history = np.asarray(history)[-history_len:]
        scorer.update_ar_model(history)
    if item is not None:
        # Update last observed item inline
        if hasattr(scorer, '_last_item'):
            scorer._last_item = item
    return scorer.score_bins(bins_residuals)
