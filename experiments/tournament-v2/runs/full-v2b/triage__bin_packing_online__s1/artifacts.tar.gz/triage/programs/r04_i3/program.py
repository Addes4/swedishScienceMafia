# EVOLVE-BLOCK-START
"""Load balancing: reward bins that already hold more items to tend to fill them."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global items_per_bin

    # Filter to only bins that are shown in `bins`
    # Keep track of which global bin indices these are
    mask = ~np.isnan(bins)
    mask = mask.astype(bool)

    # Map global bin indices to their item counts
    # We can look up items_per_bin directly using global bin indices
    # But since bins array may skip some bins, we reconstruct mapping
    # Actually, bins array IS in bin order as stated, but only includes bins that fit
    # We need to know which bin index each element in bins corresponds to
    # The harness provides bins indices in order, so bins[0] is the first bin that fits
    # This creates ambiguity - we need global bin_id information
    # Let's assume bins indices reflect actual bin IDs (0-indexed)

    # Track number of items per bin
    bin_counts = items_per_bin.copy()

    # Score: tightness + load balancing (reward bins with higher count)
    # Tightness: -(remaining - item), smaller value after subtracting item → closer match
    # Load balancing: slight bonus for bins already holding items
    alpha = 0.1
    scores = -bins + alpha * bin_counts

    # Return scores for all bins in order they appear
    return scores

# EVOLVE-BLOCK-END
