import numpy as np
from collections import defaultdict

# Global state: regret counters
# regret_counts[(item_size, gap_left)] = number of times placing an item of `item_size`
# into a bin with remaining capacity `old_rem` (so gap = old_rem - item_size) was later
# followed by a "regret" — i.e., a future item arrived that could have fit perfectly
# into that gap but couldn't be placed there (because we don't track individual bins,
# we approximate by noting when an item sees a gap that exactly matches its size).
# We'll track "observed perfect fit opportunities" to estimate regret rate.

# Note: We cannot look into the future, so regret must be estimated from past data.
# Idea: When an item of size `s` arrives and there exists at least one bin with gap == s
# (i.e., remaining capacity == s), we consider that a "perfect fit opportunity".
# For any previous item placements that resulted in a gap of size `s`, we count a regret
# if a perfect fit opportunity for size `s` appears later and the item is NOT placed
# into that gap. But we don't know which bin it went into. Heuristic: for each previous
# placement that left a gap equal to the current item size, we increment a regret counter
# for that (item_size, gap) pair, because the current item could have fit perfectly into
# that gap, but we didn't have it available (it's already used or we didn't choose it).
# This is approximate but captures "gap sizes that cause missed perfect fits".

perfect_fit_opportunities_count = defaultdict(int)  # key: gap_size, value: count of times we've seen an item of exactly that size arrive

regret_counts = defaultdict(float)  # key: (item_size, gap_left), value: cumulative regret

def priority(item, bins):
    global perfect_fit_opportunities_count, regret_counts

    # --- Update regret estimates based on current item arrival ---
    # The current item of size `item` could have perfectly fit into any bin with remaining capacity == item.
    # If such bins exist, we increment the perfect fit opportunity count for gap size `item`.
    # For each historical placement that left a gap exactly equal to `item`, we might consider a regret
    # if the current item is not placed into such a bin. But we don't know which placements were "lost".
    # Instead, we simply increment a regret counter for every (past_item_size, gap=item) pair,
    # under the assumption that a gap of size `item` was created in the past and now an item of that exact size
    # appears. This captures the general notion: creating gaps of certain sizes leads to regrets later.

    # To avoid double counting every time an item arrives, we only increment regret for a (size, gap)
    # pair when we actually *observe* a perfect fit opportunity for that gap size.
    # However, we can't increment infinitely because the same past placement only regrets once per future item.
    # We'll approximate by tracking the "regret rate" as a fraction of opportunities.

    perfect_fit_opportunities_count[item] += 1

    # Increment regret for all (past_item_size, gap=item) pairs that we've ever recorded.
    # This is expensive if many pairs exist. We'll maintain a separate structure of "active gap generators"
    # to avoid O(N^2). Since we only track (item_size, gap_left) pairs that actually occurred, we can
    # iterate over keys of regret_counts where gap_left == item. But we need to be efficient.
    # Alternative: we maintain a mapping from gap_size -> list of item_sizes that created it.
    # But still could be large. Let's implement a simpler approach: in the scoring function, we look up
    # regret rate for the gap that would be created.

    # --- Compute base scores (best fit = smallest gap) ---
    gaps = bins - item  # all non-negative because bins only include those where item fits
    base_scores = -gaps  # higher (less negative) for tighter fit

    # --- Add regret penalty ---
    # For each bin, compute the gap that would be left if item placed there.
    # Penalize bins where the resulting gap has historically high regret rate.
    regret_penalty = np.zeros_like(bins, dtype=float)

    # For efficiency, we compute regret penalty for each unique gap value
    unique_gaps = np.unique(gaps)
    gap_to_penalty = {}
    for gap in unique_gaps:
        # regret_rate for gap: average regret over all (any_item_size, gap) pairs
        # Collect all item_sizes that have historically led to this gap
        # We maintain regret_counts[(isz, g)] and we want sum over isz of regret/(opportunities?).
        # Since we don't have per-placement tracking, we'll approximate:
        # regret_rate(gap) = total_regret_for_gap / total_placements_that_created_gap
        total_regret = 0.0
        total_creations = 0
        # This scan could be slow. We'll maintain aggregated structures: gap_regret_sum[gap] and gap_creation_count[gap].
        # Let's do that.
    # --- We need fast lookup. Let's keep aggregate dicts: gap_total_regret[gap] and gap_total_creations[gap].
    # We'll initialize these outside and update when we record a placement.

    # For now, assume we have gap_total_regret and gap_total_creations updated externally.
    # In this priority function, after deciding which bin, we will record the placement.
    # But we need the penalty during decision. We'll use current statistics.

    # To avoid slowness, we compute penalty using vectorized numpy if possible, but need per-gap lookup.
    # Use a simple loop over unique gaps.
    for gap in unique_gaps:
        creations = gap_creation_count.get(gap, 0)
        if creations > 0:
            regret_sum = gap_regret_sum.get(gap, 0.0)
            # regret rate clamped to avoid extreme penalties
            rate = min(regret_sum / creations, 1.0)
            # penalty proportional to regret rate (tunable weight)
            gap_to_penalty[gap] = rate * 10.0  # scale factor
        else:
            gap_to_penalty[gap] = 0.0

    regret_penalty = np.array([gap_to_penalty[g] for g in gaps], dtype=float)

    scores = base_scores - regret_penalty

    # --- Record the chosen placement after tie-breaking? We can't because we only return scores.
    # The harness will place item into the bin with highest score (first on ties).
    # We need to update our statistics knowing the eventual choice. However, we don't get feedback.
    # We'll approximate by assuming the item goes to the bin we gave highest score.
    # We'll store the intended gaps so we can update regret later, but this might cause drift if
    # ties are resolved differently. We'll accept the approximation.

    # We'll store the "intended gap" for later regret update.
    # Since we can't be sure, we'll simply update based on the first bin in order with max score.
    # That's what the harness does. We'll replicate that logic.
    best_idx = np.argmax(scores)  # first occurrence if multiple max
    chosen_gap = gaps[best_idx]

    # --- Update regret statistics based on this placement ---
    # We increment the creation count for this gap, and also associate the item size with it.
    gap_creation_count[chosen_gap] = gap_creation_count.get(chosen_gap, 0) + 1
    # Also track per (item, gap) if needed, but aggregated is enough for penalty.
    # For regret increments, we don't do it here; we do it when future items arrive (above).
    # That requires cross-referencing. We'll implement a simplified version:
    # We'll maintain a list of recent placements (item_size, gap) to update when a perfect fit opportunity occurs.
    # But that's too slow. We'll use the aggregated approach: when an item of size S arrives,
    # we increment gap_regret_sum[gap=S] by the number of times that gap S was created. That is,
    # every time a gap S is created, a future item of size S will cause regret.
    # So regret for gap S = number_of_times_gap_S_created * perfect_fit_opportunities_for_size_S.
    # We can maintain this product.

    # Let's refine: regret_gap[gap] should be the number of times a perfect fit opportunity for size `gap`
    # occurred AFTER the gap was created. We can maintain it as: whenever an item of size S arrives,
    # gap_regret_sum[S] += gap_creation_count[S]  (all previous creations of gap S now regret once).
    # This is exactly the product accumulation over time.

    # So in priority, when item arrives, we first update regret sums for gap = item:
    if item in gap_creation_count:
        gap_regret_sum[item] = gap_regret_sum.get(item, 0.0) + gap_creation_count[item]

    # Then we compute scores as before using updated gap_regret_sum and gap_creation_count.

    # Now compute penalty with updated statistics.
    # Recompute penalties because regret sums just changed.
    unique_gaps = np.unique(gaps)
    gap_to_penalty = {}
    for gap in unique_gaps:
        creations = gap_creation_count.get(gap, 0)
        if creations > 0:
            regret_sum = gap_regret_sum.get(gap, 0.0)
            rate = min(regret_sum / creations, 1.0)
            gap_to_penalty[gap] = rate * 10.0
        else:
            gap_to_penalty[gap] = 0.0

    regret_penalty = np.array([gap_to_penalty[g] for g in gaps], dtype=float)
    scores = base_scores - regret_penalty

    # After deciding, record the intended placement (for future regret updates)
    best_idx = np.argmax(scores)
    chosen_gap = gaps[best_idx]
    gap_creation_count[chosen_gap] = gap_creation_count.get(chosen_gap, 0) + 1

    return scores

# Global state must persist across calls.
gap_creation_count = defaultdict(int)  # gap -> number of times we've created (or intended to create) this gap
gap_regret_sum = defaultdict(float)    # gap -> cumulative regret (times a perfect fit for this gap was missed)
