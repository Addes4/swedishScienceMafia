import numpy as np

# State variables that persist across calls
_experts = [
    # name, priority_function
    ("best_fit", lambda item, bins: -(bins - item)),
    ("worst_fit", lambda item, bins: bins - item),
    ("first_fit", lambda item, bins: np.arange(len(bins))[::-1]),  # higher index = earlier, but we want first bin max
    ("last_fit", lambda item, bins: np.arange(len(bins))),
    ("almost_best_fit", lambda item, bins: -(bins - item) - 0.1 * (bins == item)),
    ("middle_fit", lambda item, bins: -np.abs(bins - 50 - item)),
]
_n_experts = len(_experts)
_weights = None  # will be initialized on first call
_virtual_bins = None  # list of numpy arrays, one per expert
_initialized = False

def _init(initial_bins_size):
    global _weights, _virtual_bins, _initialized
    _weights = np.ones(_n_experts) / _n_experts
    _virtual_bins = [np.full(initial_bins_size, 100, dtype=np.int64) for _ in range(_n_experts)]
    _initialized = True

def priority(item, bins):
    global _weights, _virtual_bins, _initialized
    if not _initialized:
        _init(len(bins))
    
    # 1. Get voting from each expert on the real bins shown
    n_experts = _n_experts
    expert_votes = []  # list of (expert_idx, preferred_real_bin_idx)
    for i, (name, func) in enumerate(_experts):
        priorities = func(item, bins)
        # Find the bin with highest priority (first on tie)
        best_bin = int(np.argmax(priorities))
        expert_votes.append((i, best_bin))
    
    # 2. Score real bins by weighted majority of expert votes
    scores = np.zeros(len(bins), dtype=np.float64)
    for expert_idx, vote_bin in expert_votes:
        scores[vote_bin] += _weights[expert_idx]
    
    # 3. Determine which real bin the item will go into
    chosen_bin_idx = int(np.argmax(scores))
    
    # 4. Update expert weights based on virtual outcomes
    # Run item on each expert's virtual bin state
    opened_new_bin = np.zeros(n_experts, dtype=bool)
    for i in range(n_experts):
        vbins = _virtual_bins[i]
        # The expert uses the same priority rule on its virtual bins
        # Virtual bins: all bins (including unused ones) are available
        # Must find bins where item fits
        valid_mask = vbins >= item
        if not np.any(valid_mask):
            # Should not happen in theory (capacity 100, item <= 100, unused bins present)
            # But just in case, expand
            new_size = len(vbins) + 10
            _virtual_bins[i] = np.concatenate([vbins, np.full(10, 100, dtype=np.int64)])
            vbins = _virtual_bins[i]
            valid_mask = vbins >= item
        
        valid_indices = np.where(valid_mask)[0]
        valid_bins = vbins[valid_mask]
        # Compute priorities for these valid bins
        priorities = func(item, valid_bins)
        best_local = valid_indices[np.argmax(priorities)]
        
        # Check if this bin was previously unused (capacity 100) -> opened new bin?
        if vbins[best_local] == 100:
            opened_new_bin[i] = True
        
        # Apply placement in virtual state
        vbins[best_local] -= item
    
    # Learning rate parameter
    eta = 0.1
    # Standard exponential hedge update
    # We want to decrease weight if expert opened a new bin
    # loss = 1 if new bin opened, 0 otherwise
    loss = opened_new_bin.astype(np.float64)
    _weights = _weights * np.exp(-eta * loss)
    _weights /= np.sum(_weights)
    
    # Handle expanding virtual bins if necessary (when virtual runs out of bins)
    # This is done inside the loop if needed.
    
    # The function must return scores for the provided bins.
    # The harness uses only the returned scores to select a bin.
    return scores
