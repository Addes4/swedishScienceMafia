# EVOLVE-BLOCK-START
"""Two-stage bin-choice rule.

Stage 1 (perfect fit): if any bin's remaining capacity exactly equals the item
size, put the item there (rank that bin highest). This is always optimal and
preserves the tight packing.

Stage 2 (fallback): otherwise split by item size relative to a running median
estimate of the item distribution:
  - small items (below median) use worst fit: go to the bin with the LARGEST
    remaining capacity. Small items can squeeze into the gaps large items
    create later, so keeping large open bins available is good.
  - large items (at or above median) use best fit: go to the smallest remaining
    capacity that still fits. Large items cannot fill small gaps, so consume
    the tightest suitable bin to avoid destroying roomy bins.
"""
import numpy as np

# Running median estimate of the item-size distribution, updated online.
# The target distribution is Weibull-shaped with mean ~40, so its median is
# somewhat below the mean (around 34-36). We seed with that and adapt.
_MEDIAN = 36.0
_N = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    global _MEDIAN, _N

    # --- Stage 1: perfect fit gets absolute top priority ---
    perfect = (bins == item)
    if perfect.any():
        scores = np.where(perfect, 1.0, 0.0)
        return scores

    # --- Stage 2: class-based rule ---
    if item < _MEDIAN:
        # Small item: worst fit (largest remaining capacity).
        # Bins are int64; scale to a positive score, higher = larger capacity.
        scores = bins.astype(np.float64)
    else:
        # Large item: best fit (smallest remaining capacity that fits).
        scores = -bins.astype(np.float64)

    # --- Online median adaptation (out-of-band, cheap) ---
    # Nudge the median estimate toward the empirical median of observed items.
    _N += 1
    # Simple stochastic-ish update: move a fraction toward the item, but only
    # enough to track a slowly varying distribution. Median of a fixed
    # distribution is constant, so keep this gentle to avoid drift/noise.
    lr = 1.0 / (1.0 + _N * 0.001)
    # Use a robust target: treat item as a sample; move toward it only slightly.
    _MEDIAN += lr * (item - _MEDIAN)
    # Keep it in a sensible range.
    if _MEDIAN < 25.0:
        _MEDIAN = 25.0
    elif _MEDIAN > 45.0:
        _MEDIAN = 45.0

    return scores
# EVOLVE-BLOCK-END
