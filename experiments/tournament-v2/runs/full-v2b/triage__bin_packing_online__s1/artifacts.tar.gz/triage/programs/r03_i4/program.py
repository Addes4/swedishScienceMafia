# EVOLVE-BLOCK-START
import numpy as np
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import eigsh

class GraphBinPacking:
    def __init__(self):
        self.n_items = 0
        self.items_history = []
        self.bin_history = []
        
    def _build_adjacency(self, capacities):
        """Build adjacency matrix from capacities (after potential placement).
        Nodes with similar residual capacity are connected."""
        n = len(capacities)
        if n <= 1:
            return csr_matrix((1, 1)) if n == 1 else csr_matrix((0, 0))
        
        # Normalize capacities
        cap_normalized = capacities / 100.0
        
        # Build adjacency based on similarity of residual capacities
        # Use Gaussian kernel similarity
        sigma = 0.15  # bandwidth parameter
        rows, cols, data = [], [], []
        
        for i in range(n):
            for j in range(i+1, n):
                diff = abs(cap_normalized[i] - cap_normalized[j])
                similarity = np.exp(-diff**2 / (2 * sigma**2))
                if similarity > 0.01:  # threshold for sparsity
                    rows.extend([i, j])
                    cols.extend([j, i])
                    data.extend([similarity, similarity])
        
        if not rows:
            return csr_matrix((n, n))
        
        return csr_matrix((data, (rows, cols)), shape=(n, n))
    
    def _algebraic_connectivity(self, adj_matrix):
        """Compute the algebraic connectivity (Fiedler eigenvalue) of a graph."""
        n = adj_matrix.shape[0]
        if n <= 1:
            return 0.0
        
        try:
            # Compute degree matrix and Laplacian
            degrees = np.array(adj_matrix.sum(axis=1)).flatten()
            D = csr_matrix((degrees, (range(n), range(n))), shape=(n, n))
            L = D - adj_matrix
            
            # Get Fiedler value (second smallest eigenvalue)
            if n == 2:
                # For 2 nodes, just compute eigenvalues directly
                L_dense = L.toarray()
                eigenvalues = np.linalg.eigvalsh(L_dense)
                return float(eigenvalues[1]) if len(eigenvalues) > 1 else 0.0
            
            eigenvalues, _ = eigsh(L, k=2, which='SM', maxiter=100, tol=1e-4)
            fiedler = float(eigenvalues[1]) if len(eigenvalues) > 1 else 0.0
            
            # Penalize very small graphs (less flexibility)
            if n < 5:
                fiedler *= (n / 10.0)
                
            return fiedler
        except Exception:
            return 0.0
    
    def priority(self, item, bins):
        """Spectral scoring: maximize algebraic connectivity after placement."""
        n_bins = len(bins)
        scores = np.full(n_bins, -np.inf)
        
        # If no bins (shouldn't happen with harness), return empty
        if n_bins == 0:
            return np.array([])
        
        # Try placing item in each bin and compute resulting algebraic connectivity
        for i in range(n_bins):
            # Create hypothetical capacities after placement
            hypothetical_caps = bins.copy()
            hypothetical_caps[i] -= item
            
            # Build adjacency and compute algebraic connectivity
            adj = self._build_adjacency(hypothetical_caps)
            connectivity = self._algebraic_connectivity(adj)
            
            # Score: higher connectivity is better
            scores[i] = connectivity
        
        # If all scores are -inf (shouldn't happen), fall back to best fit
        if np.all(scores == -np.inf):
            return -(bins - item)
        
        # For bins with residual 0 after placement, give very low priority
        scores[bins == item] = -np.inf
        
        return scores

# Global instance to maintain state
_graph_packer = GraphBinPacking()

def priority(item, bins):
    return _graph_packer.priority(item, bins)
# EVOLVE-BLOCK-END
