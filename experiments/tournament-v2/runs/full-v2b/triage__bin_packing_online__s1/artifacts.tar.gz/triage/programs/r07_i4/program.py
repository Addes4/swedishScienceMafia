import numpy as np

# Potential function exponent: p > 1 penalizes small remaining capacities more than proportional,
# encouraging concentration of capacity into fewer bins.
P_EXPONENT = 2.0
CAPACITY = 100.0

def priority(item, bins):
    """
    Score each bin by the *decrease* in the potential function Φ when the item is placed.
    Φ = Σ (rem_i / 100)^p.
    A larger drop means the bin's remaining capacity shrinks from a 'flat' or 'useful' state
    closer to full, which is preferred. The bin with the maximum drop gets the item (ties to first).
    """
    # Convert to float for power calculation
    rem_float = bins.astype(np.float64)
    
    # Potential before placing in each bin:
    # Each bin currently contributes (r_i / 100)^p
    phi_before = (rem_float / CAPACITY) ** P_EXPONENT  # shape (n_bins,)
    
    # Potential after placing the item in that bin:
    new_rem = rem_float - item
    phi_after = (new_rem / CAPACITY) ** P_EXPONENT
    
    # Drop in potential: before minus after (higher is better)
    drop = phi_before - phi_after
    
    # Return drop as score; higher drop wins.
    return drop
