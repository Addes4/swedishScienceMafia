import numpy as np

# We treat the 100 possible "gap sizes" (remaining capacity after placing an item)
# as experts, and maintain a probability distribution over how desirable each gap is.
# We use exponentiated gradient with a learning rate.

class GapDesirabilityModel:
    """Online exponentiated-gradient weights over gaps (1..100)."""
    def __init__(self, learning_rate=0.01):
        # log-weights; start uniform
        self.log_weights = np.zeros(101)  # index 0 unused, 1..100
        self.eta = learning_rate
        self._cache_prob = None  # cached probabilities
    
    def get_scores(self, bins, item):
        """Return an array of scores, one per bin, based on current gap weights."""
        gaps = bins - item  # shape (n_bins,)
        # Map gaps to indices, clipping to 1..100 safe range
        gaps_clipped = np.clip(gaps, 1, 100)
        # Retrieve log-weights for those gaps
        scores = self.log_weights[gaps_clipped]
        return scores

    def update(self, gap_filled):
        """Reinforce a particular gap size that led to a bin closure (exact fit or later fill).
        gap_filled: int in [1, 100] — the remaining capacity that was just filled.
        We use a simple gradient: reward that gap by adding eta * 1 to its log-weight,
        then renormalize via softmax by subtracting log-sum-exp from all log-weights.
        Equivalent to exponentiated gradient step: weights *= exp(eta * reward) then normalize."""
        if gap_filled < 1 or gap_filled > 100:
            return
        # Add reward to log-weight of the corresponding gap
        self.log_weights[gap_filled] += self.eta
        # Renormalize in log space: subtract log(sum(exp(log_weights)))
        max_log = np.max(self.log_weights[1:])
        stable_exp = np.exp(self.log_weights[1:] - max_log)
        log_sum = np.log(np.sum(stable_exp)) + max_log
        self.log_weights -= log_sum  # subtract from all (including index 0, unimportant)
        self._cache_prob = None

# Global state: one model instance per run
model = GapDesirabilityModel(learning_rate=0.05)
previous_item = None
previous_remaining = None  # remaining capacity in the chosen bin after placing previous_item

def priority(item, bins):
    """Return a score array for bins using exponentiated gradient gap-desirability weights."""
    global model, previous_item, previous_remaining
    
    # Update model based on outcome of previous placement
    # The harness just calls priority() sequentially. We know the outcome of the
    # previous placement because we recorded its remaining capacity. The harness
    # enforces capacity, so that remaining is guaranteed. If a bin is later filled,
    # its remaining capacity becomes 0 in the next call for that bin. But we don't
    # get explicit "filled" events. We detect bin closure as follows:
    # If a bin's remaining capacity after previous placement was > 0, and now that
    # bin is not in `bins` for the current item? Actually we can't directly see
    # removed bins. We can approximate: if the remaining capacity was small and
    # the bin likely got filled, we reinforce that gap. Another approach: reinforce
    # based on whether the *chosen* gap was subsequently completely filled.
    # Insight: When a bin is exactly filled, its remaining capacity becomes 0.
    # In the next call, that bin won't appear in `bins` for items > 0.
    # But we don't have visibility into the full set of bins; we only see bins
    # that fit the current item. So we cannot track bin removal directly.
    #
    # Better idea: use a global counter of how many times each gap was "used"
    # and whether it led to compactness. However, the problem asks to update
    # weights "whenever a subsequent item successfully fills a leftover gap".
    # We can approximate by recording the gap left after placing an item.
    # Later, if any item exactly matches that gap (i.e., the bin gets filled),
    # we can detect it because the remaining capacity before that fill was exactly
    # that gap. But we don't see which bin it goes into unless we model the whole state.
    #
    # Simplest approach: reinforce the gap that was left when an item is placed,
    # under the assumption that leaving a gap often leads to later filling.
    # But we need to reinforce *when* filling happens. The evaluator mentioned
    # "reinforcing gaps that lead to compact packing".
    #
    # Let's approximate with a delayed feedback: every time an item is placed,
    # if the chosen bin's remaining capacity after placement is exactly some gap,
    # we record that gap. If later an item perfectly fills a bin (i.e., item size
    # equals a bin's remaining capacity), we reinforce that gap. We can detect
    # perfect fill because the harness calls priority with `bins` that include that
    # bin (remaining capacity equals item size). After placement, that bin disappears
    # because remaining becomes 0. So we know a perfect fill occurred for that gap.
    #
    # Code: For the current call, for each bin in `bins`, if `bins[i] == item`,
    # that means placing current item would exactly fill that bin. The gap that will
    # be filled is exactly `bins[i] - item = 0`, not interesting. But we care about
    # the gap left by some previous item that set this bin's remaining capacity.
    # That previous item left a gap of `previous_remaining`? Not necessarily the same bin.
    #
    # To get proper feedback, we maintain a mapping from bin index to its current
    # remaining capacity as seen by us? But we don't see bin indices; `bins` is just
    # an array of capacities for bins that fit the item, in fixed order. We don't know
    # which bin is which across calls. So we can't link.
    #
    # Alternative interpretation: The "gap" here refers to the remaining capacity
    # after placing an item, not the difference `bins - item`. The idea "score bins
    # with `weights[bins - item]`, updating the weight vector multiplicatively whenever
    # a subsequent item successfully fills a leftover gap, reinforcing gaps that lead
    # to compact packing" suggests:
    #   - The weight vector tracks desirability of gaps (remaining capacities after placing).
    #   - When an item is placed, we record the gap it leaves (remaining).
    #   - Later, when some item fills a bin (making remaining=0), we look at the historical
    #     gap that had been left before filling, and reinforce that gap.
    #
    # We can approximate: every time an item exactly fills a bin (i.e., `item == remaining`),
    # we know the gap left by the previous item placed into that bin was exactly that `remaining`.
    # So we can reinforce `weight[remaining]`. But we only know `remaining` because it equals
    # `item`. So reinforcement happens on perfect fits.
    #
    # Implementation: In each `priority` call, check if any bin in `bins` has capacity == item.
    # If so, that perfect fit will happen. We can reinforce the gap equal to `item` because
    # that gap is being filled perfectly. This is the "gap that led to compact packing".
    # This is a simple online feedback: whenever a perfect fit occurs, increase weight for that gap.
    
    perfect_fill_gaps = bins[bins == item]  # remaining capacities exactly equal to item
    if len(perfect_fill_gaps) > 0:
        # The gap equal to `item` is being perfectly filled; reinforce that gap.
        model.update(item)
    
    # Also, we might want to reinforce the gap left by the *previous* placement
    # if that previous gap later led to a perfect fill. But we don't know causality.
    # The above reinforcement is for the gap size that is being eliminated.
    
    # Compute scores using current model
    scores = model.get_scores(bins, item)
    
    # Record the outcome for potential future use (optional: we could also reinforce
    # based on whether the chosen gap was "good"). We'll record the remaining after
    # placement only if we can choose a bin.
    # We must pick a bin: the highest score bin will be selected by harness.
    # To record the remaining capacity after our choice, we need to know which bin we
    # would pick. Since we return scores, the harness picks the argmax. We can simulate
    # that here.
    chosen_idx = np.argmax(scores)
    chosen_remaining = bins[chosen_idx] - item
    
    # Optionally, we could immediately reinforce the gap `chosen_remaining`? Not yet,
    # but we could record it for later perfect fill detection. But we can't track bins.
    # We'll rely only on perfect-fill reinforcement.
    
    # Store previous item and remaining for potential future logic (not used here but kept)
    previous_item = item
    previous_remaining = chosen_remaining
    
    return scores
