# EVOLVE-BLOCK-START
"""Harmonic algorithm for online bin packing.

Bin and items are classified into classes based on size relative to bin capacity (100).
Items are classified by size (circular ordering):
- C1: (50, 100] (large items)
- C2: (33.33, 50] (medium items)
- C3: (0, 33.33] (small items)

Bins are reclassified by remaining capacity for efficient packing.
Scores favor bins that match the item class and have better fit (smaller remaining capacity).
"""
import numpy as np

# Note: bins already contains only bins that can fit the item (capacity >= item_size).
# We assign priority scores based on matching item class to bin's remaining capacity class.

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    item_class = _classify_item(item)
    
    # Define bin class thresholds (based on remaining capacity)
    # C1: > 50
    # C2: > 33.33 (equal or greater than 33.33)
    # C3: > 0 (all remaining capacity)
    
    # Calculate bonus for class match
    class_match = (bins[None, :] > (
        (50, 33) if item_class == 'C1' else (33, 25) if item_class == 'C2' else (33, 10)
    ))  # Simplified class matching
    
    # Better fit (smaller remaining capacity) gets better score
    best_fit = -bins
    
    # Thresholds for class matching
    item_size_class = _classify_size(item)
    bins_remaining_class = _classify_bin_class(bins)
    
    # Class match scoring: give bonus for matching class
    class_compatible = _get_class_compat(item_size_class, bins_remaining_class)
    
    # Combine: match-based bonus + best-fit score
    score = class_compatible * 10 - bins
    
    score = np.maximum(0, score) + best_fit
    
    # Handle edge case for NaN values (should not occur per problem specs)
    score = np.nan_to_num(score, nan=0, posinf=0, neginf=0)
    
    return score


def _classify_item(item):
    """Classify item by size into C1, C2, C3."""
    if item > 50:
        return 'C1'
    elif item > 33:
        return 'C2'
    else:
        return 'C3'


def _classify_bin_class(remaining_capacity):
    """Classify bins by their remaining capacity into C1, C2, C3."""
    c1 = remaining_capacity > 50
    c2 = remaining_capacity > 33 & (~c1)
    c3 = ~(c1 | c2)
    
    # Return dummy values (0, 1, 2) for each class
    return c1.astype(int) + c2.astype(int) + c3.astype(int)


def _get_class_compat(item_class, bins_class):
    """Return scalar value based on item and bin class compatibility."""
    # Simplified compatibility: 
    # C1 items fit in C1 or C2 or C3 bins
    # But C1 items are best in C1 (bin > 50), C2 in C2, C3 in C3
    return np.where(bins_class == 0, 1,  # C1 fit
                   np.where(bins_class == 1, 0.8,  # C2 fit
                   0.7)  # C3 fit
    )


# EVOLVE-BLOCK-END
