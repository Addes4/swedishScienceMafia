# EVOLVE-BLOCK-START
"""Best fit with a size-history-aware term.

Idea:
- Keep a running approximation of the recent item-size distribution using an
  exponential moving average of the mean and of the squared size.
- Estimate a "typical large item" threshold from recent history.
- For items at/above that threshold, slightly prefer bins where the leftover
  gap after placement looks like a typical recent item size (so the residue can
  be filled later), while still mostly following best-fit.

The function only ranks the bins shown; the harness selects the highest score.
"""
import numpy as np


class _State:
    __slots__ = ("n", "mean", "m2", "threshold", "alpha")

    def __init__(self):
        self.n = 0
        self.mean = 40.0          # prior matching distribution mean
        self.m2 = 1600.0          # prior variance ~ (40)^2
        self.threshold = 55.0     # rough large-item cutoff
        self.alpha = 0.02         # EMA smoothing for running stats


_STATE = _State()


def priority(item, bins):
    st = _STATE
    n = st.n
    a = st.alpha

    # Update running mean/variance of arriving item sizes.
    old_mean = st.mean
    st.mean = old_mean + a * (item - old_mean)
    st.m2 = (1.0 - a) * st.m2 + a * (item - old_mean) * (item - st.mean)
    st.n = n + 1

    var = st.m2 if st.m2 > 1.0 else 1.0
    sd = var ** 0.5

    # Typical recent item size (used as the desired residual gap).
    typical = st.mean
    if typical < 5.0:
        typical = 5.0
    elif typical > 95.0:
        typical = 95.0

    # Threshold for "relatively large" items: upper part of recent history.
    # mean + ~0.5 sd corresponds roughly to the 70th percentile for a
    # right-skewed distribution.
    thresh = st.mean + 0.5 * sd
    st.threshold = thresh

    # Base: best fit (smallest remaining capacity that still fits).
    # score = -(bins - item)
    base = -(bins - item)

    # Only pollute the ranking for relatively large items; small items are
    # handled well by pure best fit.
    if item >= thresh and item >= 20:
        # leftover gap if placed here
        leftover = bins - item
        # Reward leftover gaps close to a typical recent item size.
        # Normalize by a soft scale so the term stays a tie-breaker.
        diff = leftover - typical
        match = -np.abs(diff)
        # Slight preference for slightly larger leftovers than typical
        # (avoids closing bins too early with unusable dust).
        score = base + 0.35 * match
    else:
        score = base

    return score
# EVOLVE-BLOCK-END
