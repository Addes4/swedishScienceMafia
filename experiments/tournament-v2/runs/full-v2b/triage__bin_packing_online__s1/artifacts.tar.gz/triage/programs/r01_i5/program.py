# EVOLVE-BLOCK-START
"""Score-table bin choice.

Precompute, at import time, a value table V[c] for every residual capacity c = 0..100.
V[c] estimates how much of a residual space of size c can be productively filled by a
random stream of future items (drawn from an approximation of the Weibull-shaped size
distribution, mean ~40).  A residual is "good" if future items are likely to use it well;
a residual that is awkward to fill (too large to combine, too small to be useful) gets a
low value.

When an item is placed in a bin the resulting residual is bins[i] - item.  The bin whose
residual has the highest V is preferred.  An exact fit (residual 0) gets the maximum value,
so the rule behaves like best-fit while also avoiding residuals that waste space later.
"""
import numpy as np


def _build_value_table():
    rng = np.random.default_rng(987654321)

    # Approximate the item size distribution: Weibull(k=2), scale chosen so mean = 40.
    # Gamma(1.5) = 0.8862269254527580
    k = 2.0
    lam = 40.0 / 0.8862269254527580
    big = rng.weibull(k, 400000) * lam
    sizes = np.clip(np.round(big).astype(np.int64), 1, 100)
    counts = np.bincount(sizes, minlength=101).astype(np.float64)
    probs = counts / counts.sum()
    support = np.arange(1, 101)

    T = 3000      # trials per capacity
    L = 70        # future item draws per trial
    draws = rng.choice(support, size=(L, T), p=probs)

    V = np.zeros(101, dtype=np.float64)
    V[0] = 1.0    # perfect fit: nothing wasted, best possible residual

    for c in range(1, 101):
        left = np.full(T, c, dtype=np.int64)
        total = np.zeros(T, dtype=np.float64)
        for t in range(L):
            s = draws[t]
            fit = s <= left
            add = np.where(fit, s, 0)
            left -= add
            total += add
        V[c] = (total / c).mean()

    return V


_V = _build_value_table()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # residual is guaranteed in 0..100 because the harness only shows bins the item fits in.
    return _V[residual]
# EVOLVE-BLOCK-END
