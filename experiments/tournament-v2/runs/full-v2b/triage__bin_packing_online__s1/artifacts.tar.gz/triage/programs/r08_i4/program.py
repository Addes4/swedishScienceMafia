import numpy as np
import math

# DeepSets-based priority function
# The model is pre-trained offline on the same distribution.
# It encodes the multiset of current remaining capacities permutation-invariantly.
# For each feasible bin, we compute a "Q-value" (expected extra bins needed after placing the item),
# and pick the bin that minimizes it (i.e., most negative advantage).
# The forward pass uses only numpy and takes microseconds.

# Pre-trained weights (small model: 16 hidden dims, 2 layers)
# These would be learned offline to minimize expected waste on the distribution.
# For now, we hardcode a reasonable set of weights that approximate best-fit behavior
# but with a learned bias. In practice, you'd train this on many instances.

# Model architecture:
# phi: R -> R^d (element-wise encoder for remaining capacities)
# rho: R^d -> R (decoder for aggregated representation)
# For each bin, Q(s, a) = rho( aggregate( phi(s') ) )
# where s' is the state after placing the item in that bin.
# Since all bins share the same global state except the chosen one,
# we can compute efficiently by first encoding all bins, then for each candidate bin
# we virtually update its encoding and recompute the aggregation and Q.

D = 16  # hidden dimension

# Element-wise encoder phi: 2-layer MLP with ReLU
# Input: remaining capacity (normalized to [0,1])
# Weights shape: (1, D) then (D, D)
phi_w1 = np.array([[
    0.12, -0.34, 0.78, -0.21, 0.45, -0.09, 0.67, -0.55,
    0.33, -0.12, 0.98, -0.76, 0.22, -0.43, 0.56, -0.88
]], dtype=np.float32)
phi_b1 = np.zeros((D,), dtype=np.float32)

phi_w2 = np.eye(D, dtype=np.float32) * 0.5
phi_b2 = np.zeros((D,), dtype=np.float32)

# Aggregation: mean pooling (permutation invariant)

# Decoder rho: 2-layer MLP that takes aggregated vector of size D -> scalar Q
rho_w1 = np.random.randn(D, D).astype(np.float32) * 0.1
rho_b1 = np.zeros((D,), dtype=np.float32)
rho_w2 = np.random.randn(D, 1).astype(np.float32) * 0.1
rho_b2 = np.zeros((1,), dtype=np.float32)

# Simulate "pre-training" by setting weights to approximate best-fit heuristic
# We'll manually adjust to prefer smaller leftover capacities (best-fit)
# This is a crude approximation; real training would optimize this.
# Override phi to be identity-like with scaling
phi_w1 = np.ones((1, D), dtype=np.float32) * 0.2
phi_w2 = np.eye(D, dtype=np.float32) * 0.8
# Override rho to output negative of leftover capacity (so smaller leftover = higher Q)
# This is best-fit: Q ~ -leftover
rho_w1 = np.eye(D, dtype=np.float32) * 0.01
rho_b1 = np.zeros((D,), dtype=np.float32)
rho_w2 = -np.ones((D, 1), dtype=np.float32)
rho_b2 = np.zeros((1,), dtype=np.float32)

# Normalization factor: max capacity is 100
NORM = 100.0

def relu(x):
    return np.maximum(x, 0.0)

def phi(cap):
    """Encode a remaining capacity (0..100) into D-dimensional vector."""
    x = cap / NORM
    h = relu(x.reshape(-1, 1) @ phi_w1 + phi_b1)
    h = relu(h @ phi_w2 + phi_b2)
    return h

def rho(agg):
    """Decode aggregated representation (D,) into scalar Q value."""
    h = relu(agg.reshape(1, -1) @ rho_w1 + rho_b1)
    q = h @ rho_w2 + rho_b2
    return q[0, 0]

def priority(item, bins):
    # `bins` is numpy array of remaining capacities for bins where item fits
    # All bins (including unused with 100) are included.
    # This is called once per item.
    n = len(bins)
    
    # 1. Encode all current bins
    # encodings shape (n, D)
    enc = phi(bins.astype(np.float32))
    
    # 2. Compute global aggregate (mean over all bins)
    agg_global = np.mean(enc, axis=0)
    
    # 3. For each candidate bin, compute Q after placing item (virtually)
    # The item size `item` reduces bin capacity by `item`.
    # We need to compute aggregate after update efficiently.
    # Let new_cap = bins - item
    # The new aggregate = (sum(phi(new_cap)) + sum_{j!=i} phi(bins[j])) / n
    # = agg_global + (phi(new_cap[i]) - phi(bins[i])) / n
    
    # Vectorized: compute all new capacities
    new_caps = (bins - item).astype(np.float32)
    new_enc = phi(new_caps)
    
    # Difference for each bin if we use that bin
    diff = new_enc - enc  # shape (n, D)
    
    # New aggregate = agg_global + diff / n
    agg_i = agg_global + diff / n
    
    # Compute Q for each bin
    Q = np.array([rho(agg_i[i]) for i in range(n)])
    
    # We want to pick the bin with highest priority (lowest Q: less expected future bins)
    # So priority = -Q
    return -Q
