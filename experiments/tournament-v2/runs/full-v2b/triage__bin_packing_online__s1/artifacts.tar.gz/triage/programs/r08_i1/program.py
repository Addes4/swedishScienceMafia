# EVOLVE-BLOCK-START
"""Virtual pairing: track recent item combinations that fill gaps."""
import numpy as np


class VirtualPairing:
    def __init__(self):
        self.window_size = 500  # sliding window of recent items
        self.item_history = []  # queue of item sizes in window
        # gap_counts[g] = how many times we saw a bin with remaining capacity g
        self.gap_counts = {}
        # combo_counts[g] = how many times we saw item combinations that sum to g (likely to fill gap)
        self.combo_counts = {}
        self.history_counts = {}

    def _update_window(self, item):
        self.item_history.append(item)
        if len(self.item_history) > self.window_size:
            old_item = self.item_history.pop(0)
        
    def _count_combos(self, window):
        """Update combo counts: for each pair of items in window, count their sum."""
        if len(window) < 2:
            return
        for i in range(len(window)):
            for j in range(i + 1, len(window)):
                s = window[i] + window[j]
                if s <= 100:
                    self.combo_counts[s] = self.combo_counts.get(s, 0) + 1
        for s in list(self.combo_counts.keys()):
            if self.combo_counts[s] > 2000:  # prevent unlimited growth
                self.combo_counts[s] = self.combo_counts[s] - 1000

    def _compute_gap_scores(self, bins, item):
        """Compute priority scores combining gap frequency and combo likelihood."""
        scores = np.zeros_like(bins, dtype=np.float64)
        base = bins  # use remaining capacity as base

        for g in bins:
            # Score based on: how common this gap is (stops it from looming)
            # and how likely a future combo can fill it (higher is better)
            freq = self.gap_counts.get(g, 0)
            combos = self.combo_counts.get(g, 0)
            window_size = len(self.item_history) if self.item_history else 1
            
            # Lower gap frequency = less experienced = give boost if often seen
            # More combos filling gap = prefer it if it will vanish
            if g > 0:
                freq_score = min(100, np.log10(freq + 1)) / 2
            else:
                freq_score = 0
            
            # Combo score: higher is better for filling this gap
            combo_score = min(100, combos / max(100, window_size))
            
            # Combine: prefer bins leaving common gaps that are fillable
            scores[g] = np.sqrt(freq_score) + combo_score
        return scores


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Get global module-level state
    VPS = VirtualPairing.__new__(VirtualPairing)
    with np.errstate(runtime='ignore'):  # silence overflow warnings
        VR = state = None

    # Call virtual pair scoring
    priority = VPS._compute_gap_scores(bins, item)
