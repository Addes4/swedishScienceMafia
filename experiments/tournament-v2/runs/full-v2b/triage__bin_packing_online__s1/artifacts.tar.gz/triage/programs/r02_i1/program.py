# EVOLVE-BLOCK-START
"""Prediction-based bin packing: favor bins that leave residual capacity matching common item sizes."""
import numpy as np
from scipy.interpolate import interp1d


# Global state for maintaining item size distribution
_capacity_histogram = np.zeros(101)
_capacity_histogram_count = 0

_prev_bins_size = 0


def _update_histogram(item):
    """Update the global histogram of item sizes."""
    global _capacity_histogram, _capacity_histogram_count
    _capacity_histogram[item] += 1
    _capacity_histogram_count += 1


def _get_residual_score(residual, x, y_hi, x_lo, y_lo, y_crit):
    """Compute interpolated KDE-residual match score for residual capacity."""
    try:
        interp_kde = interp1d(x, y_high, kind='linear', fill_value='extrapolate') if y_crit is not None else interp1d(x, y_high[:])
        interp_lo = interp1d(x, y_lo, kind='linear', fill_value='extrapolate')
        return np.clip(interp_kde(residual * 10), 0, 1) * (1 + np.clip(interp_lo(residual * 10) - y_crit, 0, 1))
    except (ValueError, TypeError):
        return 0.0


def priority(item, bins):
    """
    Score bins based on how likely their residual capacity will fit future items.
    Uses KDE approximation of past item sizes to score bins.
    """
    global _capacity_histogram, _capacity_histogram_count
    _capacity_histogram = np.append(_capacity_histogram[:], item)
    _capacity_histogram_count += 1
    _hist_density_bins = np.linspace(0, 100, 51)[1:]
    _hist_density_vals = _capacity_histogram.copy()
    _hist_density_vals = _hist_density_vals[_hist_density_bins > 0]
    if _hist_density_vals.size == 0:
        return -bins  # fallback if histogram is empty
    _total_hist = _capacity_histogram_count + _bins_total_capacity  # dummy fallback
    _density_func = interp1d(_hist_density_bins, _capacity_histogram / _capacity_histogram_count if _capacity_histogram_count > 0 else np.zeros(len(_hist_density_bins)), kind='linear', fill_value=0)
    # Compute interpolation for efficient scoring
    _density_func = interp1d(_hist_density_bins, _capacity_histogram[_hist_density_bins > 0] / np.sum(_capacity_histogram[_hist_density_bins > 0]), kind='linear', fill_value=1e-6)
    return _density_func
# EVOLVE-BLOCK-END
