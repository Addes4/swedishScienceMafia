# EVOLVE-BLOCK-START
"""Track histogram of residual capacities and score by Jensen-Shannon divergence to uniform."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Local state is preserved across calls via closure/module-level
    # Use thread-local-like via module attribute (allowed since harness doesn't reset calls mid-run)
    global _capacity_hist, _n_bins, _capacity_counts
    if not hasattr(_capacity_hist, 'initialized'):
        _capacity_hist = np.zeros(101, dtype=np.int64)
        _n_bins = 0
        _capacity_counts = np.zeros(101, dtype=np.int64)
        _capacity_hist['initialized'] = True
        _capacity_counts['initialized'] = True
    
    # bins is remaining capacity of all bins item fits in
    # For each canvasable bin, place item and project new histogram
    # To stay fast, we track our global histogram and compute impact per candidate

    # Compute proposed histogram for each fit bin:
    # new count = current count + change to the c states (bins updated by subtracting item)
    
    # First: compute change vector: we decrement the capacity (bin) by item
    # We'll compute for all current-residual values and item

    # To score efficiently, we compute how the histogram's distribution changes
    # Score = -JS_divergence_to_uniform (higher is better, so we negate)
    
    # Use numpy for vectorized histogram ops; track current histogram counts via estimator
    # We'll store cumulative histogram state in a module-level heritage-safe manner
    if not hasattr(_capacity_hist, 'initialized'):
        _capacity_hist = np.zeros(101, dtype=np.float64)
        _n_bins = 0
        _capacity_counts = np.zeros(101, dtype=np.int32)
        _capacity_hist['initialized'] = True
        _capacity_counts['initialized'] = True

    # Current state: _capacity_counts[i] = number of bins with residual capacity i
    # Need to compute, for each candidate bin (current capacity b), the new histogram
    # After placement: b - item_new_bin_count[i] increases, b decreases by 1 (one bin changes)
    # The capacity histogram is updated by decrementing count[b] and incrementing count[b - item]

    # Efficient approach:
    # - Compute histogram of current capacity content across all bins in global state
    # - For each candidate bin capacity b in bins, compute deviation in divergence
    # - Score based on improvement

    n = len(bins)
    
    # Get current histogram counts from module scope
    count_hist = _capacity_counts
    num_bins = _n_bins
    
    # Precompute uniform target for JS divergence logic (over range 0..100)
    # Target is roughly uniform: P_target[i] = 1/101 for i in 0..100
    
    # But to make JS divergence plausible, work with floating PTOT for rates
    # Our target over full cap range [0,100], discretized
    
    # For efficiency: compute JS divergence directly in a vectorized manner
    
    # For each candidate bin (with current capacity b):
    #   - remove one count from b, place one count in b-item
    #   - compute new histogram, then JS to uniform
    #   - store score (lower is better, so return neg for sorting arg)
    
    # We need to avoid recomputing histogram from absolute bins every time
    # Instead, we compute delta in JS efficiently
    
    # For speed and correctness:
    # - Compute contribution of delta: d_i = new_count_i - old_count_i
    # - Only two slots change: bin b (count decreases by 1), bin b-item (count increases by 1)
    # - Recompute JS divergence with updated counts efficiently
    
    # Define uniform target
    P_target = np.full(101, 1.0/101, dtype=np.float64)
    
    # Create output priority array
    scores = np.zeros(n, dtype=np.float64)
    
    # Extract values to float for operations
    bin_caps = bins.astype(np.float64)
    
    # To avoid re-decoding global state each call, use static closure
    # But state must be preserved across calls:
    
    # Recompute once per bin if needed for correctness:
    # This counts all bins up to 100; we'll compute histogram once from bins array
    # But wait: bins array is only for bins item fits in (subset)
    # Global state tracks ALL bins
    
    # For accurate histogram, we must maintain invariants:
    # - _n_bins = number of bins created
    # - _capacity_counts = cumulative histogram
    
    # But computing JS for each bin is accurate if we correctly model global state
    # However, this is heavy: O(n*100) per call = 5000*100=500k per item -> ~2.5s per instance
    # We need sub-linear per-item
    
    # Optimized: precompute JS baseline divergence once per instance
    # Actually, since bins change per call, we compute divergence deltas:
    
    # Compute JS(delta_contributions):
    # JS_div(P, Q) = 0.5 * sum_i KL(P_i || (P_i + Q_i)/2) + ... symmetric
    
    # Use def for clarity with numba-esque vectorization
    
    # Actually, simpler: compute per-basis delta score using contribution approximation
    # The diversity score: bins should have uniform residual distribution
    # JS to uniform approximates uniform-diversity metric
    
    # For speed, just compute each candidate's score on-the-fly with minimal overhead
    # Since we have numpy, vectorized loop is OK within time limit:
    
    for i in range(n):
        b = bin_caps[i]
        cap_after = b - item
        
        # Validate capacity after placement
        if cap_after < 0:
            continue
        
        # New histogram after placing in this bin:
        # count_hist[b] -= 1; count_hist[cap_after] += 1
        
        # Compute M = (P_current + P_new*)/2 = (2*P_current + delta)/2 = P_current + delta/2
        # But we'll compute exact JS
        
        # P_current: current histogram of all bins
        # P_new: same as current except b--1, cap_after+1
        
        # Compute KL(P_new || M) + 0.5 * KL(P_new || M) = divergence
        # But since symmetric, only need M, and two KL terms
        
        # M[i] = (P[i] + Q[i])/2 = (count_hist[i] + (count_hist[i] + d[i]))/2 where d = delta counts
        
        # delta = delta_counts: -1 at b, +1 at cap_after
        
        # We'll approximate the divergence efficiently:
        # 1. Compute the contribution of changed indices only
        
        # Full JS computation:
        # JS(P||Q) = 0.5 * sum_i P_i * log(2*P_i/(P_i+Q_i)) + 0.5 * sum_i Q_i * log(2*Q_i/(P_i+Q_i))
        # Here P = current histogram (normalized), Q = candidate histogram (normalized)
        
        # Current histogram (normalized to probability):
        total = count_hist.sum()
        P = count_hist / total
        total_val = count_hist.sum()
        
        # Candidate histogram = current + delta
        # delta = -1 at b, +1 at cap_after
        Q = P.copy()
        Q[b] -= 1 / total  # Wait: we need unscaled version

        # Proper calculation:
        # P[i] = count_hist[i] / total
        # Q_actual[i] = count_hist_actual[i] + delta[i]
        # Normalize Q_actual by total
        
        Q_actual = count_hist.copy()
        Q_actual[b] -= 1
        Q_actual[cap_after] += 1
        total_Q = count_hist.sum()  # Same total bin count
        
        Q = Q_actual / total_Q if total_Q > 0 else P
        
        # Compute midpoint M
        M = (P + Q) / 2
        
        # Compute KL divergences
        # Guard for small counts
        
        # A: KL(P || M)
        mask_A = (M > 1e-10) & (P > 0)
        KL_A = np.sum(P[mask_A] * np.log(P[mask_A] / M[mask_A])) if mask_A.sum() > 0 else 0.0
        
        # B: KL(Q || M)
        mask_B = (M > 1e-10) & (Q > 0)
        KL_B = np.sum(Q[mask_B] * np.log(Q[mask_B] / M[mask_B])) if mask_B.sum() > 0 else 0.0
        
        JS = 0.5 * KL_A + 0.5 * KL_B
        
        # Convert to priority: higher score better, so negative divergence
        scores[i] = -JS
    
    return scores
# EVOLVE-BLOCK-END
