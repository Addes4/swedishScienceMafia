# EVOLVE-BLOCK-START
"""Online bipartite matching heuristic: rank bins by how far the post-placement
fill ratio (bins - item) / bins is from 0.5.

Rationale: a placement either leaves a very small residual (tight fit, ratio near 0)
or consumes a very large fraction of a fresh bin (ratio near 1 on a nearly-empty bin
being filled by a big item). Keeping the residual-ratio distribution away from the
mushy middle 0.5 tends to preserve cleanly-sized bins for future items.

We combine the ratio signal with a small tie-break toward tight fits so that we
split ties (equal distance from 0.5) in favor of leaving less waste. Ranking uses
a lexicographic-style additive combination where the primary term dominates.
"""
import numpy as np


def priority(item, bins):
    # Post-placement residual ratio: 0 = perfectly full, 1 = untouched-empty.
    ratio = (bins - item) / bins

    # Distance from the mushy midpoint: larger = better (very tight or very loose).
    dist = np.abs(ratio - 0.5)

    # Convert dist into a large-integer primary key so the secondary tight-fit
    # tie-break only matters when distances are exactly equal.
    primary = dist * 1_000_000.0

    # Secondary: tighter fit (smaller residual) preferred on ties.
    secondary = -(bins - item).astype(np.float64)

    return primary + secondary
# EVOLVE-BLOCK-END
