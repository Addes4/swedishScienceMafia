import numpy as np

# Size ranks for items
def get_size_rank(size):
    if size <= 20:
        return 0  # small
    elif size <= 70:
        return 1  # medium
    else:
        return 2  # large

# Gap ranks for residual capacities after placing an item
def get_gap_rank(gap):
    if gap <= 10:
        return 0  # very tight
    elif gap <= 30:
        return 1  # tight
    elif gap <= 60:
        return 2  # medium
    else:
        return 3  # loose

# State: penalty matrix for (item_rank, gap_rank) pairs
# We maintain a reward matrix: higher is better
# We need to keep this across calls
_state = {
    'reward': np.ones((3, 4)) * 0.5,  # (item_rank, gap_rank) -> initial neutral reward
    'last_gap_rank': None,
    'last_bin_capacity': None,
    'history': []  # store (item_rank, gap_rank) for bins that were used
}

def priority(item, bins):
    """Return priority for each bin based on learned rewards for (item_rank, projected_gap_rank)."""
    # Update rewards based on previous placements
    if _state['last_gap_rank'] is not None and _state['last_bin_capacity'] is not None:
        # The previous item was placed, leaving some gap
        # Now a new item arrives (current "item") - we want to reward the (prev_item_rank, gap_left_rank)
        # Actually the idea says: "each time a bin's residual capacity later receives an item,
        # reward the (incoming-item-rank, leftover-gap-rank) combination that preceded it."
        # So when a bin with gap gets a new item, we reward the pair (incoming_item_rank, that_gap_rank)
        # We need to know the item that was just placed? Wait, "incoming-item-rank" is the new item.
        # We need to know the gap that was in the bin before this placement.
        # But we only have bins array here - it shows capacities before placement.
        # When we place an item, we know which bin it went to (the one we chose).
        # The harness tells us the item size, and we select a bin with certain remaining capacity.
        # After placement, that bin's new capacity = old_capacity - item.
        # The "leftover gap" from previous placements is the old_capacity after previous item?
        # Let's re-read: "each time a bin's residual capacity later receives an item,
        # reward the (incoming-item-rank, leftover-gap-rank) combination that preceded it."
        # I think: when an item arrives, we consider bins. Each bin has some residual capacity.
        # That residual capacity is the "leftover gap" from previous items packed in that bin.
        # If we later put an item into that bin, we should reward the pair:
        # (rank of that later item, rank of that residual capacity).
        # So we need to know after each placement: for the bin we used, what was its capacity before?
        # Here in priority(), we see bins (old capacities). If we choose a bin and place item,
        # we will know old_capacity and item size. We should store that to later reward.
        # But the reward should be applied when the NEXT item arrives?
        # Actually: "reward the combination that preceded it" means we can reward immediately after placing,
        # or when next item comes? We can do it at the start of next priority() call,
        # using stored (prev_item_rank, prev_gap_rank) and the fact that it just received an item? No.
        # Let's simplify: we maintain a reward matrix. For each candidate bin with capacity c,
        # we compute projected gap = c - item. We want to assign score = reward[item_rank, gap_rank].
        # And we update reward matrix based on actual outcomes: when we later see items, we don't know
        # which bins they go to? We can track the history of placements.
        # After a placement, we know (item_rank, old_gap_rank) of the bin used. We don't know if that gap
        # was "good" until later another item fills it? Actually "each time a bin's residual capacity
        # later receives an item". So if a bin has gap g, and later an item of size s is placed in that bin,
        # then the pair (rank(s), rank(g)) was successful. We could reward that.
        # But we only know placements as they happen. So when we place an item into a bin with old capacity c,
        # we can immediately reward the pair (current_item_rank, rank(c))? Because we are using that gap now.
        # That makes sense: the gap c was left previously, and now an item (current) fits into it.
        # So we reward that combination! Yes, that's exactly what it says: "the (incoming-item-rank, leftover-gap-rank) combination that preceded it."
        # So when we choose a bin and place item, we should give positive reward to (item_rank, gap_rank_of_old_capacity).
        # And we penalize other combinations? Or just increase reward for observed successful pairs.
        pass

    # Now compute priorities
    item_rank = get_size_rank(item)
    # Compute projected gaps
    gaps = bins - item  # all bins shown fit the item, so gaps >= 0
    # Classify gaps
    gap_ranks = np.array([get_gap_rank(g) for g in gaps])
    
    # Get rewards for each bin
    rewards = np.array([_state['reward'][item_rank, gr] for gr in gap_ranks])
    
    # We need to decide which bin to pick. The bin with highest score.
    # But we also need to update the reward matrix after we know which bin we'll use.
    # We cannot update here because we don't return the chosen bin index; the harness uses our scores
    # and will place the item in the highest-scored bin.
    # To update the reward matrix based on actual placement, we need to remember what we did.
    # We could store the chosen bin's parameters and update on the next call, assuming the placement happens.
    # But we need to know which bin was actually used. Since we return scores, the harness picks the first maximum.
    # We can determine that on the next call by seeing what changed in bins? Not possible because bins are just capacities.
    # We can't know without maintaining our own model.
    # Alternative: we can update reward matrix immediately after we decide which bin we would choose,
    # but we must ensure the same decision is made by harness. That's fine: we can find the maximum index.
    # But wait, priority() returns scores for all bins. The harness will use the one with highest score (first max).
    # We can internally determine which bin that is, and update our state accordingly for the next call?
    # The question says "It may keep state between calls". So we can remember what we think will be chosen,
    # and on the next call, we can apply the update assuming it was placed. But we need to be careful:
    # what if the item doesn't fit? The harness only shows bins where it fits, so it will be placed.
    # So we can predict the chosen bin in this call, and remember its parameters (item_rank, old_gap_rank).
    # On the next call, we update the reward matrix for that remembered pair.
    # That's exactly what I started coding above with _state['last_gap_rank'] etc.
    # However, the previous code attempted to use last_gap_rank and last_bin_capacity, but those would be from
    # the previous item's chosen bin. The idea is: "each time a bin's residual capacity later receives an item,
    # reward the (incoming-item-rank, leftover-gap-rank) combination that preceded it."
    # So if last call we placed an item, we left some new gap. That new gap is now the "leftover gap" for future items.
    # When a new item arrives and goes into that same bin, we should reward (new_item_rank, that_leftover_gap_rank).
    # So we need to track, for each bin, its current gap rank? That's complex.
    # Let's re-read carefully: "each time a bin’s residual capacity later receives an item, reward the
    # (incoming-item-rank, leftover-gap-rank) combination that preceded it."
    # I think it means: consider a bin. Before placing an item, it had some leftover gap from previous items.
    # When we place a new item into that bin, we reward the pair (rank of new item, rank of that leftover gap).
    # So we need to know the leftover gap rank for each bin at the moment we place an item into it.
    # We can maintain our own array of bin capacities (since we know all placements).
    # Yes! We can track the capacities ourselves by simulating placements.
    # We have access to bins array, but that's just the capacities of bins that fit the current item, in a fixed order.
    # We can maintain a global list of all bin capacities (initially empty, or filled with 100s?) Actually we need to know
    # the state of all bins ever created. Since we see bins array with actual capacities (including unused bins as 100),
    # we can simply copy that into our own state each call? But bins array is provided, and it's a copy. We could just
    # maintain our own array of bin capacities that we update based on placements. But we need to know which bin index
    # the item goes to. We can determine that from our scores.
    # So: maintain self.bin_capacities = [] (list). On each call, we first sync with reality by checking if bins array length
    # matches? No, bins array length equals number of items so far? It says "There are as many bins as items; unused bins
    # have remaining capacity 100 and are included." So length of bins == number of items that have arrived so far?
    # Actually "as many bins as items" probably means at any point there could be up to number of items bins. But it says
    # "There are as many bins as items" in the function description: it's a fixed length array with length equal to number
    # of items? No, "There are as many bins as items" might mean there are N bins at the moment item N arrives? Let's check:
    # item i arrives, bins array contains remaining capacity of every bin the item fits in, including all unused bins (capacity 100)
    # and their count equals number of items that have arrived? Probably length is the number of bins that currently exist.
    # But it's not clear. Simpler: we can just maintain an array of bins capacities ourselves, starting with an empty list,
    # and each time we place an item, we either open a new bin (if we choose a bin with capacity 100 that wasn't used before)
    # or add to existing. But we need to know which bin index we chose. We can compute chosen_index = first maximum of our scores.
    # But our self.bin_capacities must correspond to the real bin order. Since the harness provides bins in fixed bin order,
    # and we can track the number of bins seen, we can just use the bins array provided as ground truth for the current capacities?
    # But on the first call, bins array length? We can infer from length of bins array. But then we can update after placement.
    # We'll maintain self.capacities (a numpy array) that we update each time we place an item.
    # On each call to priority(), we will:
    # - Update our self.capacities based on placement from previous call (store item size and chosen index).
    # - Also, we can use the bins array to verify? Not needed.
    # We'll store last_item_size and last_chosen_idx.
    # Then, compute scores, determine chosen_idx for this call, store it for next update.
    # This way we know the old capacity of the bin we are about to use, which is self.capacities[chosen_idx] before placement.
    # Then we reward (current_item_rank, gap_rank_of_that_old_capacity).
    # That matches the description.
    
    # However, we can't modify self.capacities inside priority() before returning because the placement hasn't happened yet.
    # But we can update reward based on the decision we make, because it's deterministic.
    # We'll just apply the reward immediately for the bin we decide, using the current self.capacities.
    # This might be slightly ahead of actual placement, but it's equivalent.
    
    # Need to consider first call: no last_item_size, no self.capacities.
    # We'll initialize self.capacities as empty list, and on first call, we need to know current capacities.
    # Since we don't have them, we can't make informed decision on first item. But the bins argument contains the capacities.
    # We can just use bins array to initialize our self.capacities for the first call, assuming no previous placements.
    # The bins array on first call will probably have length 1 (capacity 100) because there are as many bins as items? 
    # "There are as many bins as items" could mean: for item i, there are i bins? Or always N bins? Let's read:
    # "There are as many bins as items; unused bins have remaining capacity 100 and are included."
    # I think it means the array size equals the number of items that have arrived so far (including current one?).
    # Example: first item arrives, array size 1 (capacity 100). Second item arrives, array size 2 (some used, some 100).
    # That would make sense. So we can use the bins array length to know how many bins exist, and we can maintain our own copy
    # by storing the bins array each time? But we need old capacity of the bin we choose. The bins array shows the state before
    # placing the current item. So we can simply set self.capacities = bins.copy() before we modify anything.
    # That way we have accurate old capacities for all bins. Then we decide which bin, and we know its old capacity.
    # Then after placing, we would update our copy by subtracting item from that bin. But we can just do that inside priority
    # after we determine the chosen index, so that our copy stays up-to-date for next call.
    # But wait, we are not allowed to modify bins array (it's a copy anyway). So we can keep our own copy and update it.
    # Then on the next call, we first sync our copy with reality by checking the provided bins? Not needed if we keep it correct.
    # However, the harness might create new bins that we didn't anticipate? "There are as many bins as items" suggests that the
    # array length grows with each item. If we only track bins we know, we might miss newly added empty bins.
    # But our priority function only sees bins that the item fits in; unused bins are included (capacity 100). So if we need
    # more bins, the array will include them. To keep our copy accurate, we should probably rely on the bins array each call
    # as the source of truth for capacities, because we might have inaccuracies? Actually, if we perfectly track placements,
    # our copy should match (since we only ever subtract from a bin). But new bins appear with capacity 100. We can start our
    # copy as an empty list and extend it as needed based on the bins array length.
    # Simplest: On each call, we set self.capacities = bins.copy() (since bins is a copy of current state before placement).
    # Then we decide, and we can update self.capacities for our own internal reward, but we don't need to keep it across calls
    # because next call we'll get a new bins array reflecting the placement. But we need the old capacity of the chosen bin
    # to compute the gap rank for rewarding. Since we have bins.copy(), we have old capacities. Then we can update reward
    # using that old capacity. Then we don't need to maintain our own array across calls (except for reward matrix).
    # That's much simpler!
    # But we also need to know the previous placement's gap to reward when the next item arrives? No, the reward is based on
    # the current placement: (incoming_item_rank, leftover_gap_before_placement). We have that info now.
    # So we can do it all in this call: reward based on the bin we select's old capacity.
    # That means we don't need any state except the reward matrix.
    # However, the idea mentions "penalty matrix updated online: each time a bin's residual capacity later receives an item,
    # reward the (incoming-item-rank, leftover-gap-rank) combination that preceded it." That's exactly what we'll do.
    # So algorithm:
    # - bins array shows capacities before placing item.
    # - Compute item_rank.
    # - For each bin, compute gap = bins[bin] - item, gap_rank.
    # - Score = reward[item_rank, gap_rank].
    # - Choose bin with highest score.
    # - Then update reward for that specific (item_rank, gap_rank_of_chosen_bin_old_capacity) by adding a small increment.
    # But wait: the "leftover gap" that preceded it is the old capacity, not the new gap after placement. "leftover-gap-rank"
    # refers to the residual capacity before placing the incoming item? "bin's residual capacity later receives an item" ->
    # the residual capacity is the state before the incoming item. So old capacity. Yes.
    # So we reward (incoming_item_rank, gap_rank_of_old_capacity).
    # That is straightforward.
    
    global _state
    reward_matrix = _state['reward']
    
    # Compute scores
    item_rank = get_size_rank(item)
    gaps = bins - item
    gap_ranks = np.array([get_gap_rank(g) for g in gaps])
    
    scores = np.array([reward_matrix[item_rank, gr] for gr in gap_ranks])
    
    # Choose bin (argmax, ties to first, which np.argmax does)
    best_idx = np.argmax(scores)
    
    # Update reward for the chosen combination (item_rank, rank of old capacity of that bin)
    old_capacity = bins[best_idx]
    old_gap_rank = get_gap_rank(old_capacity)  # gap before placing this item
    # Increment reward
    # Use learning rate
    lr = 0.1
    reward_matrix[item_rank, old_gap_rank] += lr * (1.0 - reward_matrix[item_rank, old_gap_rank])  # move toward 1
    
    # Possibly decay other rewards or keep as is. The idea is to encourage historically fillable gaps.
    # We'll just increase the reward for this combination.
    # Also maybe we should consider that if we don't choose a bin, we aren't using that gap, but that's fine.
    
    return scores
