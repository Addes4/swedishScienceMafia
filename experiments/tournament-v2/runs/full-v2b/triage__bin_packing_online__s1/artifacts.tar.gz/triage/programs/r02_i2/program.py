"""Dual-priority system: worst-fit for large items (>50), best-fit with small-bin preference for small items (<=50)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item > 50:
        # Worst-fit: prefer largest remaining capacity to keep small bins available
        return bins.astype(float)
    else:
        # Small item: prefer best-fit among bins with capacity <= 50
        # If such bins exist, prioritize them; otherwise fall back to best-fit overall
        small_bins_mask = bins <= 50
        
        if np.any(small_bins_mask):
            # Among small-capacity bins, use best-fit (tightest fit)
            scores = np.where(small_bins_mask, -(bins - item), -np.inf)
            return scores
        else:
            # No small-capacity bins available, use best-fit overall
            return -(bins - item)
