# EVOLVE-BLOCK-START
"""Tail-fit: Markov-chain gap prediction with a chain-completion prior.

Idea
----
We think of each bin as a "chain": a sequence of leftover gaps produced as items
are placed into it.  Every time we put an item of size s into a bin whose
current gap is g, the bin's new gap becomes g' = g - s (possibly 0, which is a
*full* bin).  So we can record a Markov chain over gap transitions
(g -> g') observed in the past.

When a new item arrives we consider, for every candidate bin with gap g,
the residual g' = g - item that would result.  We score the bin by how
promising the transition is:

  * transitions that historically ended in a full bin (g' == 0) are great;
  * gaps g' that are "good targets" (frequently used as fillers, i.e. gaps
    from which the chain tends to complete) are also good;
  * a small tie-breaker prefers tighter fits (best-fit flavour).

We keep everything in O(#gaps) per call by bucketing gaps into 101 integer
values (0..100); leftover is always an integer in [0,100].  State is a
101x101 transition counter matrix plus a 101-vector of "next gap" usage, which
together act as the chain model.
"""
import numpy as np

# ---- persistent state (module level) -------------------------------------------------
# T[a, b] = number of observed transitions from gap a to gap b (b = a - item_size).
_T = np.zeros((101, 101), dtype=np.float64)
# row totals for transition probabilities (kept lazily in sync).
_Trow = np.zeros(101, dtype=np.float64)
# Number of times a placement *ended* with residual gap b (i.e. b became the new gap).
# This doubles as the "target" popularity of a gap.
_use = np.zeros(101, dtype=np.float64)
_use_total = 0.0

# How strongly to weight the transition model vs. the plain tight-fit rule.
_ALPHA = 1.15          # weight of chain-completion (ending at gap 0)
_BETA = 1.10           # weight of reaching a popular ('useful') next gap
_GAMMA = 0.90          # tie-break: prefer tighter fits
_IDEAL = 38.0          # typical item size ~40; a gap near this is a good target


def _model():
    """Return (ready, P) where P[a,b] is a smoothed transition probability."""
    global _Trow
    # Recompute row sums (cheap: 101x101).
    rs = _T.sum(axis=1)
    # Laplace smoothing over 101 possible successors.
    denom = rs[:, None] + 1.0
    return _T, (_T + 0.35) / denom


def priority(item, bins):
    global _use_total

    bins = np.asarray(bins, dtype=np.int64)
    item = int(item)

    # Residual gap if this bin were chosen.
    resid = bins - item                      # >= 0 by contract

    # ---- gather the model -----------------------------------------------------------
    _, P = _model()

    # p0[g]  = probability that a placement from gap g completes the bin (residual 0)
    p0 = P[:, 0]
    # reach[g] = expected 'value' of landing on gap g = how often gap g is used
    #            plus a preference for gaps that themselves tend to complete.
    if _use_total > 0.0:
        reach = _use / max(1.0, _use_total)
    else:
        reach = np.zeros(101, dtype=np.float64)
    # being a popular successor is good; strongly favour residuals that finish the bin
    target = reach.copy()
    target[0] += 0.40                        # gap 0 == perfectly full bin

    # map residual -> scores via fancy indexing
    chain_goodness = p0[resid]               # historical chance of completing from here
    target_value = target[resid]             # popularity / promise of the resulting gap

    # ---- compose score -------------------------------------------------------------
    # Prefer: high chance the resulting gap later fills (chain_goodness),
    #         resulting gap is a popular/useful target,
    #         and the fit is tight (small residual).
    score = (_ALPHA * chain_goodness
             + _BETA * target_value
             - _GAMMA * (resid.astype(np.float64) / 100.0))

    # Small deterministic nudge toward the "ideal" residual, mirroring a good
    # packing cadence (items around the mean size leave complementary gaps).
    score += 0.02 * (1.0 - np.abs(resid.astype(np.float64) - _IDEAL) / 100.0)

    # ---- learn from the item we are about to place -------------------------------
    # We must learn the transition *before*/at placement.  We do not know which bin
    # the harness will pick, but the strongest learning signal is deterministic:
    # the chosen bin is the argmax of `score` (ties -> first).  We replicate that
    # decision here so the model reflects the actual chosen transition.
    idx = int(np.argmax(score))
    g_from = int(bins[idx])
    g_to = int(resid[idx])

    _T[g_from, g_to] += 1.0
    _use[g_to] += 1.0
    _use_total += 1.0

    return score
# EVOLVE-BLOCK-END
