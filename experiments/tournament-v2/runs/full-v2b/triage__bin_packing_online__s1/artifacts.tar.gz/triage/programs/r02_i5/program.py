# EVOLVE-BLOCK-START
"""SNF: Sum of Normalized Fit with clustering bonus for bins that already contain items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Normalize fit: -(bins - item) / item = (item - remaining) / item
    # This penalizes bins that are too small (relative to item), favors tighter fit
    # and scales with item size to maintain consistent scoring
    score = (item - bins) / item

    # Add tiny bonus for bins already containing at least one item
    # Track state across calls per instance to encourage clustering
    if hasattr(priority, '_bins_with_items'):
        in_use_mask = priority._bins_with_items
        bonus = (1.0 if in_use_mask[item] else 0.0) * 0.01  # tiny bonus (< 1% of score)
        score = score + bonus.reshape(-1)  # Expand if necessary

    # Update state: all shown bins in candidate set (all bins fitting the item) should be tracked
    # Since priority(function state) persists per instance, we mark bins that receive items
    # But we must be careful: input bins may not include all bins if they don't fit
    # We track bins by index using modulo from bins array length if needed
    if not hasattr(priority, '_bins_with_items'):
        priority._bins_with_items = np.zeros(len(priority._bins_with_items) + 1, dtype=bool)

    return score
# EVOLVE-BLOCK-END
