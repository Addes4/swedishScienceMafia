# EVOLVE-BLOCK-START
"""Reverse fragmentation control for online bin packing.

For each arriving item we rank candidate bins by how well the resulting set of
remaining capacities stays "uneven": a few large gaps (flexible for big items)
and many tiny gaps (harmless).  Placing into a bin lowers its gap by `item`;
we reward the resulting gap distribution for concentrating its mass, using a
local first-order form of the L2 norm and entropy of the sorted gaps, so the
computation stays O(n) per call and vectorized.
"""
import numpy as np


# Running statistics of the current gap multiset, updated between calls.
_STATE = {
    "sum": 0.0,       # sum of all used-bin gaps
    "sumsq": 0.0,     # sum of squares of gaps
    "count": 0.0,     # number of used bins (gap > 0, capacity < 100 counted distinctly)
    "ent": 0.0,       # sum of p*log(p) contributions of the current gaps
    "sizes": None,    # dict: gap value -> multiplicity, to update local changes
}


def _reset_if_needed():
    if _STATE["sizes"] is None:
        _STATE["sizes"] = {}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _reset_if_needed()
    if bins.size == 0:
        return np.zeros(0, dtype=np.float64)

    res = (bins - item).astype(np.float64)  # resulting gaps for each candidate bin
    cur = bins.astype(np.float64)

    # Recompute global statistics directly from the current state (cheap, vectorized).
    # Used bins: those that are not pristine empties (capacity 100).
    used_mask = cur < 100.0
    used = cur[used_mask]
    cnt = float(used.size)
    ssum = float(used.sum())
    ssq = float(np.dot(used, used))

    if cnt <= 1.0 or ssum <= 0.0:
        # Not enough structure yet: pure best fit (tightest) as a sane default.
        return -res

    # L2 norm of normalized gaps after placing in each candidate:
    #   new L2 = (ssq - g^2 + r^2) / (ssum - g + r)^2
    # where g is the current gap of that bin, r = g - item the resulting gap.
    g = cur
    r = res
    new_sum = ssum - g + r
    new_sq = ssq - g * g + r * r
    # guard against r == 0 (bin becomes exactly full -> gap leaves the used set)
    # handled naturally: r contributes 0 to sums.
    l2 = new_sq / np.maximum(new_sum, 1e-9) ** 2

    # Entropy effect: lower entropy is better (more uneven).  Approximate the
    # change by the local normalized-gap contribution; vectorized.
    p_new = r / np.maximum(new_sum, 1e-9)
    # entropy term (smaller better); avoid log(0)
    with np.errstate(divide="ignore", invalid="ignore"):
        ent_local = np.where(r > 0, -p_new * np.log(np.maximum(p_new, 1e-300)), 0.0)
    # global entropy shift: replacing -p*log p contribution of g by that of r
    p_old = g / np.maximum(ssum, 1e-9)
    with np.errstate(divide="ignore", invalid="ignore"):
        ent_old = np.where(g > 0, -p_old * np.log(np.maximum(p_old, 1e-9)), 0.0)
    ent = np.where(r > 0, ent_local, 0.0) - np.where(g < 100.0, ent_old, 0.0)

    # Combine: reward concentration (L2), penalize entropy.
    scores = l2 - 0.05 * ent

    # Small tie-break toward tighter fit for stability.
    scores = scores - 1e-6 * r

    # Unused empty bins (capacity 100) should be least preferred unless nothing else:
    # they are not part of `used`, but appear in the array.  Treat their placement as
    # producing a large new gap 100-item in the used set.
    empty = ~used_mask
    scores[empty] = -1.0 + (100.0 - item) * 1e-9

    return scores
# EVOLVE-BLOCK-END
