import numpy as np

def priority(item, bins):
    """
    Minimize expected Gini coefficient of remaining capacities after placement.
    High Gini (inequality in remaining gaps) is penalized. Score bins to favor
    placements that result in more equal gap distributions.
    """
    n_bins = bins.size
    scores = np.zeros(n_bins)
    
    median_cap = bins.median()
    mean_cap = bins.mean()
    valid_mask = bins >= item
    if not np.any(valid_mask):
        scores[:] = -1e10
        return scores

    new_caps = np.where(valid_mask, bins - item, -np.inf)
    
    deviations = np.abs(new_caps - median_cap)
    efficiencies = item / np.where(valid_mask, bins, 1)
    fraction_used = efficiencies
    
    normalized_dev = deviations / (1e-10 + np.std(bins))
    normalized_eff = 5 * fraction_used
    
    item_score = normalized_dev + normalized_eff
    
    total_gini_for_p = -np.sum(item_score * valid_mask)
    
    n = bins.size
    cap_var = np.var(bins)
    diff_in_cap_variance = cap_var - np.var(bins)
    
    scores[valid_mask] = total_gini_for_p + 0.5 * diff_in_cap_variance
    scores[~valid_mask] = -1e10
    
    return scores
