# EVOLVE-BLOCK-START
"""Buffer-zone policy on top of best fit.

Idea
----
Best fit (bin with the smallest remaining capacity that still fits) is a very
strong online rule for this distribution.  Its known weakness is that a rare
large item can be forced into a bin that is nearly full, "fragmenting" what
would otherwise have been a good small gap, and afterwards no item can use the
leftover sliver.  Conversely a large item placed into a nearly empty bin wastes
a lot of large open space.

We therefore add a *buffer zone* for large items:

  * Maintain an online estimate of the size distribution (we only need a rough
    upper quantile).  We use a simple streaming tracker of recently seen sizes
    (a bounded reservoir-like list) and take a high quantile as the threshold.
    The first few calls use a conservative fixed threshold.

  * If the arriving item is "large" (size >= threshold, roughly the top 10% of
    the historical sizes), we restrict its candidate bins to:
       - perfect fits (remaining capacity == item), or
       - roomy bins (remaining capacity >= 2 * item),
    i.e. we avoid dumping a big item into a medium gap and fragmenting it.
    Among the allowed bins we still use best fit.

  * Otherwise (normal sized item) we use ordinary best fit everywhere.

Scoring: we must return a score for *every* bin.  Forbidden bins get a very
low score so they are never chosen; allowed bins get the usual best-fit score
(-(remaining - item), i.e. larger when the remaining capacity is closer to the
item).  Ties break to the first bin, which the harness handles.
"""

import numpy as np

# ---------------------------------------------------------------------------
# Streaming statistics kept between calls.
# ---------------------------------------------------------------------------
_SIZES = []            # bounded window of recently observed item sizes
_CAP = 2000            # window length
_SEEN = 0              # total items observed so far
_THRESHOLD = 70        # fallback threshold before we trust the statistics
_BIG = 1e9             # sentinel used to push forbidden bins to the bottom
_FORBID = -1e6


def _update_threshold(item):
    """Update the rolling size window and recompute the 'large item' cut."""
    global _THRESHOLD, _SEEN
    _SEEN += 1

    # Keep a bounded window of recent sizes.  Using a simple append-and-trim
    # keeps the code branch-light and fast enough for 5000 calls.
    _SIZES.append(item)
    if len(_SIZES) > _CAP:
        # Trim in bulk occasionally to avoid O(n) work every call.
        del _SIZES[:1000]

    if _SEEN % 25 == 0 and len(_SIZES) >= 200:
        # High quantile ~ top 10%.  Sorting a few thousand ints every 25th
        # call is cheap compared to the rest of the framework.
        arr = np.asarray(_SIZES)
        _THRESHOLD = int(np.quantile(arr, 0.90))


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest score."""
    _update_threshold(item)

    n = bins.shape[0]
    # Best-fit score for every bin (works for all bins since bins are only the
    # ones the item fits in).  Closer remaining capacity -> higher score.
    best_fit = item - bins  # = -(bins - item)

    if item >= _THRESHOLD:
        # Large item: only allow perfect fits or very roomy bins.
        allowed = (bins == item) | (bins >= 2 * item)
        if allowed.any():
            scores = np.where(allowed, best_fit, _FORBID)
            return scores
        # If nothing qualifies (e.g. all bins are medium gaps), fall back to
        # plain best fit so we never fail to place the item.
        return best_fit

    # Normal item: plain best fit across all bins.
    return best_fit
# EVOLVE-BLOCK-END
