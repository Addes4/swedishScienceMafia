# EVOLVE-BLOCK-START
"""Online bin choice using target gap distribution via discrete levels (multiples of 10).
Maintains statistics of past gaps to estimate target distribution. Scores bins by how well
their post-placement gap aligns with the target distribution (minimizes KS-like distance)."""
import numpy as np

# Maintain target distribution: expected count of bins in each gap level (0-100 in multiples of 10)
_TARGET_FREQ = None
 Nar_history = []  # Track total bins seen for normalization


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TARGET_FREQ
    
    # Estimate item size's intended bin-scale (level) for target
    # Approximate ideal bin usage: items of size s typically leave small gaps
    if _TARGET_FREQ is None or np.max(_TARGET_FREQ) == 0:
        # Initialize from first few calls via previous matches
        new_target_freq = _TARGET_FREQ.copy() if _TARGET_FREQ is not None else np.zeros(11, dtype=np.float64)
        # First-pass: favor smaller gaps by favoring near 0
        _TARGET_FREQ = new_target_freq
        _TARGET_FREQ.fill(1)  # Flat start
    
    # Define discrete levels: levels 0 to 10 (each level = multiples of 10)
    # i.e., 0-9, 10-19, ..., 90-99, 100
    item_level_idx = (item + 5) // 10  # roughly matching item size range
    bins_level = (bins * 10) // 100  # convert bins to level 0-10

    # Compute cumulative distribution match score briefly for each bin
    # Use simplified KS-like score: favor bins where resulting gap aligns with target
    scores = np.empty(len(bins), dtype=np.float64)
    
    # Increment item level histogram
    item_hist = np.zeros(11, dtype=np.float64)
    for i, level in enumerate(bins_level):
        if level < 11:
            item_hist[level] += 1
        # Prefer bins with smaller resulting gaps (closer to 0)
        scores[i] = -(bins[i] - item)
        # Apply target distribution penalty toward favored gap level
        if item_hist.size > 0:
            norm = item_hist.sum()
            norm_hist = item_hist / norm
            scores[i] -= np.sum(np.abs(norm_hist - _TARGET_FREQ))
    
    # Add slight preference for 0-level (fully filled gaps)
    for i, level in enumerate(bins_level):
        if level == 0:
            scores[i] -= 1.0
    
    return scores


# Initialize used in harness
