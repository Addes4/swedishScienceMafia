# EVOLVE-BLOCK-START
"""Dual-threshold policy with streaming quantile estimate of recent item sizes.

Small items (below the lower quantile) go to the tightest bin among those with
remaining capacity <= 2*item (fine-grained packing).  Large items (above the
upper quantile) go to the bin with the most room among bins whose capacity is
at least 2*item (keep big bins open for big items).  Medium items use plain
best-fit.  The thresholds adapt from a streaming estimate of the item-size
distribution.
"""
import numpy as np

_Q_LO = 0.25
_Q_HI = 0.75
_ALPHA = 0.02       # quantile update step
_WARMUP = 200       # items before trusting the estimate


class _State:
    def __init__(self):
        self.q_lo = 25.0
        self.q_hi = 60.0
        self.n = 0

    def update(self, item):
        self.n += 1
        x = float(item)
        # Stochastic quantile approximation (Robbins-Monro style).
        # Lower quantile
        if x > self.q_lo:
            self.q_lo += _ALPHA * _Q_LO
        else:
            self.q_lo -= _ALPHA * (1.0 - _Q_LO)
        # Upper quantile
        if x > self.q_hi:
            self.q_hi += _ALPHA * _Q_HI
        else:
            self.q_hi -= _ALPHA * (1.0 - _Q_HI)
        # Keep in a sane range
        if self.q_lo < 1.0:
            self.q_lo = 1.0
        if self.q_hi > 100.0:
            self.q_hi = 100.0
        if self.q_hi < self.q_lo + 5.0:
            self.q_hi = self.q_lo + 5.0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties to first."""
    _state.update(item)

    item = float(item)
    cap = bins.astype(np.float64)

    if _state.n <= _WARMUP:
        # Not enough information yet: best-fit.
        return -(cap - item)

    q_lo = _state.q_lo
    q_hi = _state.q_hi

    if item < q_lo:
        # Small item: best-fit among bins with capacity <= 2*item.
        tight = cap <= 2.0 * item
        score = np.where(tight, -(cap - item), -1e18)
        return score
    if item > q_hi:
        # Large item: worst-fit among bins with capacity >= 2*item.
        roomy = cap >= 2.0 * item
        score = np.where(roomy, cap - item, -1e18)
        return score
    # Medium item: best-fit overall.
    return -(cap - item)
# EVOLVE-BLOCK-END
