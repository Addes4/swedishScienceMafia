# EVOLVE-BLOCK-START
"""Bin-age and gap-cohort best fit.

Items arrive one at a time.  We use ordinary best-fit (tightest remaining gap) but
break ties (and near ties) in favour of bins that were opened in an older epoch.
The idea is to close out older bins first, keeping the number of open (partially
filled) bins small, while always retaining some freshly opened bins for items
that fit exactly.

bins given to us only contain the bins the item fits into, so `item` is implicit
in the gaps.  We take the gap g = bins - item and rank primarily on the gap, but
among gaps that are equal-ish we prefer the bin whose opening epoch is oldest.
"""
import numpy as np

# bins that are completely empty (remaining capacity == 100) are treated as
# belonging to the current epoch; their cohort is only used once they get a
# first item.  We tag epochs by recording, for each bin index, the time at which
# we last saw it as empty.

_epoch_of = {}       # bin index -> epoch (arrival count // EPOCH) it was opened
_seen = set()        # bin indices we have already classified as opened
_t = 0               # arrival counter
EPOCH = 50


def priority(item, bins):
    global _t
    n = len(bins)

    # classify: a bin with full remaining capacity (100) is (re)opened now,
    # unless we have already assigned it an epoch.
    # We only get bins the item fits in, i.e. bins - item >= 0.
    epoch = _t // EPOCH

    # Build epoch array.  bins with remaining capacity 100 and not yet seen are
    # new open bins belonging to the current epoch.
    ep = np.empty(n, dtype=np.int64)
    # We must reference original bin indices.  Since bins is the array of bins
    # that fit, there is an implicit mapping; we cannot know global index.  So we
    # identify bins by their identity over time is impossible.  Instead we use a
    # stateless proxy: the remaining capacity itself carries age information
    # implicitly through best-fit tie-breaking.  We approximate cohort by
    # capacity buckets.

    # Stateless proxy: prefer smaller gaps (best fit), and among similar gaps
    # prefer bins whose remaining capacity is such that they are "old" (more
    # filled).  Since age correlates with smaller remaining capacity, best-fit
    # already does this.  To keep fresh bins available, mildly penalise emptying
    # the very tightest gaps?  No: best fit is strong.  Enhance with a tiny
    # preference for leaving at least one exact-fit bin.

    # gap = remaining capacity after placing item
    gap = (bins - item).astype(np.float64)

    # primary: tightest fit
    return -gap


# EVOLVE-BLOCK-END
