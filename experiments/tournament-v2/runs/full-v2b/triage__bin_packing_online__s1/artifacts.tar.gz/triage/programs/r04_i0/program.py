import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score (ties go to the first bin).

    score calculation: -(bins - item) / max(1, bins)
    this minimizes relative waste, preserving large bins for future big items.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in.
    """
    return -(bins - item) / np.maximum(1, bins)
