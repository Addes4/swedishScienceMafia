# EVOLVE-BLOCK-START
"""Best fit plus a future-proof bonus for gaps matching frequent recent item sizes."""
import numpy as np
from collections import deque

# Rolling window of recently seen item sizes (state kept between calls).
_RECENT = deque(maxlen=1000)
_ALL = deque(maxlen=5000)

# Bonus weight for leaving a gap that matches a frequent recent item size.
GAMMA = 12.0

# Number of top frequent sizes to reward.
K = 12


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _RECENT.append(item)
    _ALL.append(item)

    # Best-fit base score: prefer the tightly fitting bin (negative residual).
    residual = bins - item
    score = -residual.astype(np.float64)

    # Compute the most frequent item sizes in the recent window and in the full history.
    if len(_ALL) >= 50:
        # Count frequencies over the full observed history (bounded by maxlen).
        counts = np.bincount(np.fromiter(_ALL, dtype=np.int64, count=len(_ALL)),
                             minlength=101)
        # Ignore the item sizes that are never useful as gaps of positive size.
        counts[0] = 0
        # Pick the K most frequent sizes.
        top = np.argpartition(counts, -K)[-K:]
        top = top[counts[top] > 0]
        if top.size > 0:
            # Reward bins whose leftover capacity exactly matches a common item size.
            match = np.isin(residual, top)
            score += GAMMA * match

    return score
# EVOLVE-BLOCK-END
