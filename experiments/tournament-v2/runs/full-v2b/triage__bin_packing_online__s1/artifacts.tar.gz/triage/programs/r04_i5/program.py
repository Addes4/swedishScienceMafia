# EVOLVE-BLOCK-START
"""Best fit with a subset-sum safety bonus on the residual gap.

The idea: after tentatively placing the item in a bin, the residual is
rem = bin_remaining - item.  If we can partition that residual exactly using
sizes drawn from a small buffer of recent items, the gap is "safe": a future
item may close it nicely rather than leaving an awkward hole.  We score such
bins higher, breaking ties in favour of tighter fits.

We do not actually know future items, so the buffer holds recent past items,
which share the same (stationary) distribution.  A bounded subset-sum DP over
the buffer (capped size) tells us whether rem is reachable.

Fall back cleanly to pure best fit when the bonus cannot help.
"""
import numpy as np

# Fixed-size ring buffer of recent item sizes.
_BUF = [0] * 64
_POS = 0
_FILLED = 0

# Subset-sum reachability cache keyed by residual value.
_REACH = {}


def _reachable(target, cap):
    """True if `target` can be formed as a sum of a subset of the buffer items.

    `cap` limits how many buffer entries we consider (bounded work per call).
    Results are memoised by (target, tuple of used sizes) implicitly through a
    simple per-target cache; the buffer changes slowly so this is effective.
    """
    if target == 0:
        return True
    key = (target, cap)
    cached = _REACH.get(key)
    if cached is not None:
        return cached

    sizes = _BUF[:_FILLED][:cap]
    # Bitset subset-sum: bit j set => sum j reachable.
    bits = 1
    for s in sizes:
        if s <= target:
            bits |= bits << s
        # keep only bits up to target to bound the integer size
        mask = (1 << (target + 1)) - 1
        bits &= mask
        if (bits >> target) & 1:
            _REACH[key] = True
            return True
    res = bool((bits >> target) & 1)
    _REACH[key] = res
    return res


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties)."""
    global _POS, _FILLED

    # Record this item for future subset-sum checks.
    _BUF[_POS] = int(item)
    _POS = (_POS + 1) % len(_BUF)
    if _FILLED < len(_BUF):
        _FILLED += 1

    # Bound the DP: only look at a handful of recent, small-ish items.
    cap = min(_FILLED, 24)
    targets = bins - item  # residual after placing the item

    scores = np.empty(len(bins), dtype=np.float64)
    # Primary signal: preferred tighter fits (smaller residual), like best fit.
    # Secondary: bonus for residuals that are exactly reachable by recent sizes.
    for i in range(len(bins)):
        rem = int(targets[i])
        # Base: negative residual => tighter fit gets higher score.
        base = -float(rem)
        if rem <= 0 or _FILLED == 0:
            scores[i] = base
            continue
        # Only bother for reasonably small, exactly-fillable gaps.
        bonus = 0.0
        if rem <= 100:
            if _reachable(rem, cap):
                bonus = 0.5
        scores[i] = base + bonus

    return scores
# EVOLVE-BLOCK-END
