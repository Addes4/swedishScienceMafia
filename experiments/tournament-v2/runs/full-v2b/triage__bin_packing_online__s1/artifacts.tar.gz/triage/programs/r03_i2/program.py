# EVOLVE-BLOCK-START
"""Profile-based online bin packing.

Idea: treat each bin as a "profile" (a coarse summary of the items already placed
in it, e.g. binned sizes). Maintain a table mapping profile -> decayed statistics
about how well bins with that profile have historically accepted subsequent
items. When a new item arrives, score each candidate bin by the empirical
success rate of its profile plus a small term favoring tighter fits.

This is an online rule: statistics are updated after each placement using a
decayed count so recent history matters more.
"""
import numpy as np

# ---------------------------------------------------------------------------
# Tunable constants
# ---------------------------------------------------------------------------
DECAY = 0.995            # decay factor for historical counts
TIGHTNESS_W = 0.6        # weight on the tight-fit term
PROFILE_PRIOR = 1.0      # smoothing for the profile success rate

# Number of coarse size buckets used to build the profile string.
# We use the item's "fullness class" rather than exact sizes so profiles
# generalise across instances of the same distribution.
N_BUCKETS = 10

# Precompute bucket boundaries on the capacity scale (0 .. 100 remaining).
_BOUNDS = np.linspace(0.0, 101.0, N_BUCKETS + 1)

# ---------------------------------------------------------------------------
# Global state (persists across calls within one instance / process)
# ---------------------------------------------------------------------------
# The problem states the function may keep state between calls.
_profile_stats = {}      # profile_key -> [good, total] decayed counts
_last_item = None        # lingering item used to attribute a success
_last_key = None         # profile key of the bin chosen last time


def _bucket(remaining):
    """Map a remaining-capacity value into a small integer bucket index."""
    # _BOUNDS[-1] = 101, so values <= 100 always fit below the last bound.
    idx = int(np.searchsorted(_BOUNDS, remaining, side="right")) - 1
    if idx < 0:
        idx = 0
    elif idx >= N_BUCKETS:
        idx = N_BUCKETS - 1
    return idx


def _profile_key(bins_slice):
    """Build a compact hashable profile from a bin's current contents.

    bins_slice: remaining capacities of the bins contributing to this profile.
    Here we only have the chosen bin's remaining capacity, so the profile is
    the bucket of its remaining capacity. This yields a stable, small set of
    profiles that are shared across instances with the same distribution.
    """
    r = bins_slice
    if r >= 99.5:
        # An empty / unused bin.
        return 0
    # Two-level profile: fullness bucket crossed with a parity bit keeps the
    # dictionary tiny while still distinguishing near-full bins.
    b = _bucket(r)
    return 1 + b


def priority(item, bins):
    """Return a score for every bin; item goes to the highest-scoring bin."""
    global _last_item, _last_key

    bins = np.asarray(bins)
    n = bins.shape[0]
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # ------------------------------------------------------------------
    # 1) Credit the previously chosen bin for having accepted the last item.
    # ------------------------------------------------------------------
    if _last_key is not None:
        stats = _profile_stats.get(_last_key)
        if stats is None:
            stats = [PROFILE_PRIOR, 2.0 * PROFILE_PRIOR]
            _profile_stats[_last_key] = stats
        # decay
        stats[0] *= DECAY
        stats[1] *= DECAY
        # empirical success: a placement that was possible counts as "good"
        stats[0] += 1.0
        stats[1] += 1.0
    _last_key = None

    # ------------------------------------------------------------------
    # 2) Score candidate bins.
    # ------------------------------------------------------------------
    # Precompute profile success rate per candidate bin.
    scores = np.empty(n, dtype=np.float64)
    keys = []
    # Tightness term: prefer the bin with the least remaining capacity that
    # still fits (classic best-fit), expressed as -(remaining - item).
    tight = -(bins.astype(np.float64) - float(item))

    for i in range(n):
        key = _profile_key(int(bins[i]))
        keys.append(key)
        stats = _profile_stats.get(key)
        if stats is None:
            rate = PROFILE_PRIOR / (2.0 * PROFILE_PRIOR)  # = 0.5 smoothed
        else:
            rate = stats[0] / stats[1] if stats[1] > 0 else 0.5
        # Primary: how well this profile historically accepts future items.
        scores[i] = rate

    # Blend with tightness (best-fit) so behaviour is sensible even with no
    # history.  Normalise tightness to a comparable small scale.
    tmax = np.max(np.abs(tight))
    if tmax > 0:
        tight_n = tight / tmax
    else:
        tight_n = tight
    scores = scores + TIGHTNESS_W * tight_n

    # ------------------------------------------------------------------
    # 3) Pick the best bin (first on ties).
    # ------------------------------------------------------------------
    best = int(np.argmax(scores))
    _last_key = keys[best]
    _last_item = int(item)
    return scores
# EVOLVE-BLOCK-END
