# EVOLVE-BLOCK-START
"""Evolution: track bins with more items, add small bonus. Encourage packing efficiency via grouping."""
import numpy as np
from collections import defaultdict

# State: bin_id -> count of items placed in this bin
bin_counts = defaultdict(int)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    We track how many items each bin has held so far, and prefer bins with higher counts.
    Primary score guides best-fit (tight fit), secondary bonus encourages grouping.
    """
    # Compute how many items fit in each bin (i.e., bins[i] >= item)
    fits = bins >= item
    bins_index = np.where(fits)[0]

    if len(bins_index) == 0:
        # No bin can accept the item
        return np.full(len(bins), 0, dtype=int)

    # Compute current best-fit score: tighter remaining capacity = better
    remaining_cap = bins[fits]
    fit_scores = -remaining_cap
    fit_scores[~fit] = -np.inf  # Ensure bins that don't fit are not chosen (though they shouldn't be in bins)

    # Bonus: prefer bins with more items, scaled down to be small relative to fit_scores
    # Add small bonus reward for bins with more items
    # Convert to bonus using bin index map
    bonus_scores = np.zeros(len(fits), dtype=float)
    for i in bins_index:
        bonus_scores[i] = bin_counts[i] * 0.05

    # Combine scores: prioritize good fit (first dimension), push to efficient bins slightly
    total_scores = fit_scores + bonus_scores

    # Adjust full bins: they won't fit anyway, but to avoid numerical issues:
    total_scores[~fits] = -np.inf

    # Find max score, return priority per bin
    max_score = np.max(total_scores)
    # Create full-size array
    full_scores = np.full(len(bins), -1, dtype=float)
    full_scores[~fits] = -np.inf
    full_scores[fits] = total_scores

    # Find all bins with max score
    best_mask = (full_scores == max_score) & fits
    if np.any(best_mask):
        best_bins = np.where(best_mask)[0]
        # Return scores with ranking for top bins only
        return full_scores
    else:
        return full_scores
# EVOLVE-BLOCK-END
