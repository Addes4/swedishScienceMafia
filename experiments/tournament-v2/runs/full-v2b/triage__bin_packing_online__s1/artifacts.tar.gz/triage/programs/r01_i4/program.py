import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Determine which bins are "below half" (remaining capacity < 50)
    below_half = bins < 50

    if np.any(below_half):
        # Only consider below-half bins: set full/high bins to a very low score
        scores = np.where(below_half, -(bins - item), -np.inf)
    else:
        # All bins are >= 50, use best-fit among all
        scores = -(bins - item)

    return scores
