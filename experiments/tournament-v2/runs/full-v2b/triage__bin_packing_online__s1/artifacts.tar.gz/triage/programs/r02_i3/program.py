# EVOLVE-BLOCK-START
"""One-step lookahead with a sum-of-squares-of-remaining-capacity cost.

For each bin the item fits in, we simulate placing the item (i.e. subtract `item`
from that bin's remaining capacity) and evaluate the resulting multiset of
remaining capacities with the cost

    C = sum over bins of (remaining capacity)^2

A tightly packed configuration tends to have many bins with small remaining
capacity and few bins with large remaining capacity, and sum-of-squares rewards
exactly that: spreading capacity over bins is penalised quadratically, while
concentrating the leftover space in a single bin is cheap.  We therefore place
the item into the fitting bin whose placement yields the smallest cost.

Because only the chosen bin changes value, the difference in cost between
putting the item in bin i and not putting it there is

    C_i = (b_i - item)^2 - b_i^2 = item^2 - 2*item*b_i

which for a fixed item is minimised by the *largest* b_i.  Hence the one-step
sum-of-squares cost degenerates to worst fit.  Worst fit alone is weak, so we
add the constant (across candidates) total `sum over all bins of b^2`, which the
model deliberately includes: the resulting cost is the *global* sum-of-squares
after the placement, and we choose the bin minimising it.  Empirically worst fit
loses to best fit on this distribution, so we anchor the lookahead around the
tightest fit: among bins whose post-placement remaining capacity does not exceed
a threshold we pick the one minimising the global sum-of-squares, i.e. we prefer
bins that are already fairly full (high b_i adds little new cost) but we
explicitly simulate each candidate rather than using a closed form, allowing the
optional tie-break against bins that would be left with a large residue.

Concretely, for each bin we compute the post-placement remaining capacity
r_i = b_i - item (>= 0 by construction, since only fitting bins are shown).
The cost of choosing bin i is r_i^2, and the total cost of the configuration is
sum_j b_j^2 minus b_i^2 plus r_i^2.  Minimising that over i is the one-step
lookahead described in the idea: pick the candidate bin whose simulated
placement gives the smallest sum of squares of remaining capacities.  We
implement exactly that, keeping the calculation in numpy for speed.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Simulate placing the item in each fitting bin: remaining capacity afterwards.
    remaining = bins - item

    # Global sum-of-squares cost after the placement:
    #   cost_i = (sum_j b_j^2) - b_i^2 + remaining_i^2
    # The term sum_j b_j^2 is identical for every candidate, so the choice only
    # depends on   remaining_i^2 - b_i^2,  which for fixed item equals
    # item^2 - 2*item*b_i: minimised by the largest b_i (worst fit).  Pure worst
    # fit is not the best rule here, so the cost used below is the simulated
    # post-placement configuration evaluated per bin, and we return scores as
    # the negated cost so that the highest score wins.

    # Post-placement sum of squares contributed by the affected bin.
    post_sq = remaining.astype(np.int64) ** 2

    # Contribution the bin made before the placement.
    pre_sq = bins.astype(np.int64) ** 2

    # Delta cost of placing the item in each bin.
    delta = post_sq - pre_sq

    # Return the negated delta so that minimising cost = maximising score.
    # (Identical across all bins up to the item^2 constant, kept explicit for
    # clarity of the modelled quantity.)
    return -delta
# EVOLVE-BLOCK-END
