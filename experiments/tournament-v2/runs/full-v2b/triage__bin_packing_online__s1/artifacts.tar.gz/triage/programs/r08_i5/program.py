# EVOLVE-BLOCK-START
"""Best fit with a CUSUM-aware density guard.

Core ranking: best fit (tightest remaining capacity).

Added twist: maintain a running estimate of the packing density of the items
actually placed (total placed / total consumed capacity).  A CUSUM-style
detector watches the item sizes for an upward regime shift.  If a candidate
bin would end up with a density above a dynamic threshold, it is penalized
unless the placement is a perfect fit.  The idea is to avoid over-compacting
bins (leaving little slack) right before larger items arrive, since compact
bins cannot absorb the size shift and force extra bins.
"""
import numpy as np

# --- state kept across calls ------------------------------------------------
_STATE = {
    "n": 0,            # number of items seen
    "sum_items": 0.0,  # sum of item sizes
    "sum_used": 0.0,   # sum of capacity consumed by placements
    # per-bin records: capacities and placed sums are tracked lazily via dicts
    "bin_cap0": {},    # bin index -> original (initial) remaining capacity
    "bin_sum": {},     # bin index -> sum of items placed into that bin
    # CUSUM detector on item size about its long run mean
    "cusum": 0.0,
    "mean_size": 40.0,
}

_ALPHA = 0.02          # EWMA factor for the running mean of item sizes
_CUSUM_SLACK = 0.6     # slack (in item-size units) before CUSUM reacts
_CUSUM_THRESH = 6.0    # CUSUM threshold that triggers the guard
_DENSITY_BASE = 1.0    # nominal acceptable density (perfect compaction)


def _reset_if_new_instance(bins):
    """Detect a fresh instance by checking whether tracked bins still match.

    The harness hands us only bins the item *fits* in, but it is a copy of the
    live bookkeeping.  We refresh our per-bin capacity records from `bins`
    each call, creating entries for freshly encountered bin indices.
    """
    pass


def priority(item, bins):
    global _STATE
    st = _STATE

    # ---- refresh per-bin capacity bookkeeping from the live array ----------
    # We can't map array positions to stable bin ids directly, but bin order is
    # fixed and lengths grow monotonically; treat position as the bin id and
    # record the first capacity we ever see for a position (unused = 100).
    m = len(bins)
    cap0 = st["bin_cap0"]
    bsum = st["bin_sum"]
    for pos in range(m):
        if pos not in cap0:
            # First time we see this bin; its full capacity equals current
            # remaining only if it is untouched. We can't know past placements
            # reliably, so seed with current remaining to stay conservative.
            cap0[pos] = int(bins[pos])
            bsum[pos] = 0

    # ---- update CUSUM with this item --------------------------------------
    st["n"] += 1
    st["sum_items"] += item
    mu = st["mean_size"]
    dev = item - mu
    if st["n"] > 50:
        st["cusum"] = max(0.0, st["cusum"] + dev - _CUSUM_SLACK)
        if st["cusum"] > _CUSUM_THRESH:
            # regime shift upward: raise tolerance slightly, then let it decay
            st["cusum"] = _CUSUM_THRESH * 0.5
    st["mean_size"] = mu + _ALPHA * (item - mu)

    # Guard strength: 0 when calm, ramps up when CUSUM is high.
    guard = min(1.0, st["cusum"] / _CUSUM_THRESH) if st["n"] > 50 else 0.0

    # ---- best-fit base score ----------------------------------------------
    rem = bins.astype(np.float64)
    residual_after = rem - item          # remaining capacity if placed here

    # Base ranking: tighter fit (smaller residual_after) is better -> negate.
    base = residual_after

    # ---- density guard -----------------------------------------------------
    # For each candidate bin, estimate density after placing the item:
    # density = (previously placed sum + item) / (total consumed capacity)
    # Consumed capacity = cap0 - residual_after.
    scores = base.copy()
    if guard > 0.0:
        cap0 = st["bin_cap0"]
        bsum = st["bin_sum"]
        for pos in range(m):
            c0 = cap0.get(pos, 100)
            used_after = c0 - residual_after[pos]
            if used_after <= 0:
                continue
            placed_sum = bsum.get(pos, 0) + item
            dens = placed_sum / used_after
            perfect = 1.0 if residual_after[pos] == 0 else 0.0
            if perfect == 0.0 and dens > _DENSITY_BASE:
                # Penalize over-dense placements proportionally to excess & guard
                over = dens - _DENSITY_BASE
                scores[pos] += guard * over * 200.0

    # ---- record the choice we are about to make ---------------------------
    # Since the harness picks the argmax itself, we must anticipate it: the
    # best score here is where the item lands.  Update bookkeeping for the bin
    # with the best score (first on ties).
    best = int(np.argmax(scores))
    # Update records: this bin now has the item.
    cap0 = st["bin_cap0"]
    bsum = st["bin_sum"]
    if best not in cap0:
        cap0[best] = 100
        bsum[best] = 0
    # We only know the residual after; reconstruct consumed and placed sum.
    # stored placed sum for the bin, then add this item.
    bsum[best] = bsum.get(best, 0) + item
    st["sum_used"] += item

    return scores
# EVOLVE-BLOCK-END

