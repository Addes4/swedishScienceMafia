# EVOLVE-BLOCK-START
"""Best-fit variant using a fullness-ratio score.

Idea (harmonic-like scoring): prefer bins whose *relative* residual gap is small.
For a bin with remaining capacity r and incoming item s, the gap after placing is
r - s.  Instead of ranking purely on the absolute gap (best fit), rank on

    gap_ratio = (r - s) / r        (for r > 0)

which is the fraction of the *current* free space that would be left unused.
This penalizes large residual gaps relative to the bin's size, while a perfect
fit (r == s) always gives gap_ratio == 0 regardless of r, so perfect fits are
strongly preferred.  We return the negative ratio so that higher score wins.

To keep the item from being wasted on tiny leftover bins (where a small absolute
gap can look misleadingly good), we combine the ratio with a mild absolute-gap
term.  This keeps behavior close to best-fit for the common case but sharpens
preference for well-filled bins.
"""
import numpy as np


def priority(item, bins):
    """Rank bins by relative residual gap (primary), absolute gap (secondary)."""
    rem = bins.astype(np.float64)
    gap = rem - item  # >= 0 for all shown bins (harness only shows fitting bins)

    # Relative residual gap. Use rem as denominator; rem >= item >= 1 so safe.
    ratio = gap / rem

    # Primary: full bins (small ratio) best. Secondary: small absolute gap,
    # scaled down so it only breaks ties / near-ties among similar ratios.
    score = -(ratio + 1e-3 * gap)
    return score
# EVOLVE-BLOCK-END
