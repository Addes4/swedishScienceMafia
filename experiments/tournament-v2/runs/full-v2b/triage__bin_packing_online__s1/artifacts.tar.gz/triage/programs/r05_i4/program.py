import numpy as np
from collections import deque
from scipy import stats


class OnlineWeibull:
    """Online Weibull parameter estimation using method of moments (windowing)."""

    def __init__(self, window_size=500, shape_guess=1.5):
        self.window = deque(maxlen=window_size)
        self.shape = shape_guess
        self.scale = 50.0  # rough initial
        self.ready = False

    def observe(self, x):
        self.window.append(x)
        if len(self.window) >= 50:
            self._fit()
            self.ready = True

    def _fit(self):
        data = np.array(self.window, dtype=np.float64)
        log_data = np.log(data)
        # Weibull MLE solved by simple moment approach (often adequate)
        mean_log = log_data.mean()
        mean_data = data.mean()
        # Initial guess for shape k via coefficient of variation
        # For Weibull, CV^2 = gamma(1 + 2/k) / gamma(1 + 1/k)^2 - 1
        # Use moment-matching heuristic:
        cv = np.std(data) / mean_data if mean_data > 0 else 0.5
        if cv < 0.1:
            cv = 0.1
        if cv > 2.0:
            cv = 2.0
        k_guess = cv ** (-1.086)  # approximate relation
        # refine with MLE approximation using mean and mean of logs
        # Weibull MLE: 1/k = (sum x^k log x)/(sum x^k) - (1/n) sum log x
        # We solve iteratively with a few Newton steps
        k = k_guess
        for _ in range(5):
            x_pow_k = data ** k
            sum_xk_logx = np.sum(x_pow_k * log_data)
            sum_xk = np.sum(x_pow_k)
            if sum_xk == 0 or k <= 0:
                break
            f = 1 / k - (sum_xk_logx / sum_xk) + mean_log
            df = -1 / (k * k) - (np.sum(x_pow_k * log_data ** 2) / sum_xk -
                     (sum_xk_logx / sum_xk) ** 2)
            if abs(df) < 1e-12:
                break
            k = k - f / df
        if k <= 0.5:
            k = 0.5
        if k > 5.0:
            k = 5.0
        lambda_ = mean_data / np.exp(np.log(np.math.gamma(1 + 1 / k)))
        if lambda_ <= 0:
            lambda_ = 50.0
        self.shape = k
        self.scale = lambda_

    def sample(self, n=1):
        if not self.ready:
            # fallback to uniform-ish around 40
            return np.random.randint(20, 81, size=n)
        return stats.weibull_min.rvs(c=self.shape, scale=self.scale, size=n).clip(1, 100).astype(int)


# Stateful model
model = OnlineWeibull(window_size=500)
# Number of simulated lookahead items per candidate
LOOKAHEAD = 10
REPETITIONS = 3  # average multiple rollouts to reduce variance


def priority(item, bins):
    global model
    # Observe current item to update distribution
    model.observe(item)
    
    n_bins = len(bins)
    
    # If only one bin (or 0, safety), return neutral
    if n_bins <= 1:
        # fallback
        return -bins + item  # best fit
    
    # Generate all dummy items for all repetitions in one batch
    total_samples = LOOKAHEAD * REPETITIONS * n_bins
    dummy_items = model.sample(total_samples)
    # reshape: (n_bins, REPETITIONS, LOOKAHEAD)
    # Each candidate bin will have its own set of REPETITIONS * LOOKAHEAD dummy items
    dummy_items = dummy_items.reshape(n_bins, REPETITIONS, LOOKAHEAD)
    
    # Precompute current capacities minus current item for each candidate
    # remaining capacity if item assigned there
    cap_after = bins - item  # shape (n_bins,)
    
    # For each bin candidate, run simulation
    costs = np.full(n_bins, np.inf, dtype=np.float64)
    
    # We'll process all bins, but only those where item fits (cap_after >=0); 
    # if item does not fit, cost stays inf, won't be selected.
    # We can optimize loop if needed, but 5000 calls inside 30 seconds allows some loops.
    for idx in range(n_bins):
        if cap_after[idx] < 0:
            continue
        
        # collect capacities of other bins (excluding current candidate)
        # we need a full state where current bin's capacity is updated
        # We'll concatenate: [updated_candidate] + original_others (excluding candidate)
        other_mask = np.ones(n_bins, dtype=bool)
        other_mask[idx] = False
        other_caps = bins[other_mask]
        
        # base capacities for simulation: candidate updated, others unchanged
        base_state = np.concatenate(([cap_after[idx]], other_caps))
        # Note: the order matters for tie-breaking but for greedy best-fit result does not.
        # We keep order.
        
        total_cost = 0.0
        for rep in range(REPETITIONS):
            dummies = dummy_items[idx, rep]
            current_state = base_state.copy()
            # Run best-fit on dummy items
            for d in dummies:
                # best fit: choose bin with smallest remaining capacity that fits
                # if none fits, open new bin (capacity 100 - d)
                feasible = current_state >= d
                if np.any(feasible):
                    # find index with maximum remaining cap tie? best fit = maximum negative diff?
                    # we want tightest: min(c - d) over feasible => min(current_state[feasible] - d)
                    # equivalent to choosing bin with smallest (current_state[feasible] - d)
                    residuals = current_state[feasible] - d
                    best_local_idx = np.argmin(residuals)
                    actual_idx = np.where(feasible)[0][best_local_idx]
                    current_state[actual_idx] -= d
                else:
                    # open new bin
                    current_state = np.append(current_state, 100 - d)
            # After all dummies, count bins used
            # Bins with remaining capacity < 100 are considered used (or even partial)
            # We count total number of bins (since unused bins show as 100)
            bins_used = np.sum(current_state < 100)
            total_cost += bins_used
        
        avg_cost = total_cost / REPETITIONS
        costs[idx] = avg_cost
    
    # Score: lower cost (bins used) is better -> higher score. Use negative cost.
    # Where cost is inf, give very low score.
    scores = np.where(np.isfinite(costs), -costs, -1e10)
    return scores
