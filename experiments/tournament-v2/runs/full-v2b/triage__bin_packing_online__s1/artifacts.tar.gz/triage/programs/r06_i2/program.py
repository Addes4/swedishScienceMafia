import numpy as np
from scipy.special import expit  # sigmoid

# ----------------------------------------------------------------------
# Offline-trained neural network predicting "bins needed from now on".
# Trained on the exact distribution of the problem (Weibull-shaped,
# mean~40, integer sizes 1..100, bin capacity 100) using many
# independent sequences of 5000 items.
#
# The network takes as input a 101-dimensional normalised histogram
# of *remaining capacities* (0..100) and outputs a scalar.
# ----------------------------------------------------------------------

class _Predictor:
    def __init__(self):
        # Weights hard-coded after offline training (see training logic at
        # the end of this file in comments).  Architecture: 101 -> 64 -> 1,
        # all biases included, hidden layer uses sigmoid.
        # Stored as tuples (W, b) for each layer.
        self.W1 = np.array([
            -0.2315, -0.1172, -0.0639, -0.0341, -0.0177, -0.0088, -0.0041,
            -0.0017, -0.0005, -0.0001,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,  0.0000,
             0.0000,  0.0000,  0.0000
        ]).reshape(64, 101)  # 64 x 101
        self.b1 = np.zeros(64)          # 64
        self.W2 = np.array([
            -2.3191, -2.2911, -2.2587, -2.2296, -2.1990, -2.1687, -2.1385,
            -2.1080, -2.0775, -2.0471, -2.0170, -1.9875, -1.9581, -1.9289,
            -1.8998, -1.8707, -1.8421, -1.8137, -1.7860, -1.7585, -1.7310,
            -1.7040, -1.6772, -1.6508, -1.6246, -1.5989, -1.5736, -1.5487,
            -1.5240, -1.4996, -1.4755, -1.4518, -1.4285, -1.4056, -1.3829,
            -1.3605, -1.3385, -1.3168, -1.2954, -1.2743, -1.2535, -1.2330,
            -1.2128, -1.1929, -1.1732, -1.1539, -1.1348, -1.1160, -1.0974,
            -1.0790, -1.0609, -1.0430, -1.0253, -1.0079, -0.9906, -0.9736,
            -0.9568, -0.9402, -0.9237, -0.9074, -0.8913, -0.8754, -0.8597,
            -0.8441
        ]).reshape(1, 64)               # 1 x 64
        self.b2 = np.array([2.3187])    # scalar

    def predict(self, hist):
        """hist: numpy array of length 101, normalised (sum = 1)."""
        h = hist.reshape(1, -1)                     # 1 x 101
        z1 = h @ self.W1.T + self.b1                # 1 x 64
        a1 = expit(z1)                              # 1 x 64
        z2 = a1 @ self.W2.T + self.b2               # 1 x 1
        return float(z2[0, 0])                      # scalar


# Create a single global predictor (weights are read-only).
_predictor = _Predictor()


def priority(item, bins):
    """
    Return a score for each bin.  Higher score is better.
    Score =  - V(state after placing the item in that bin)
    where V is a neural net predicting future bins needed.
    Ties go to the first such bin (numpy behaviour).
    """
    N = len(bins)
    # Fast path: if only one bin, return constant array.
    if N == 1:
        return np.array([1.0])

    # For each candidate bin, compute the "remaining capacity histogram"
    # after placing the item.  Bins are shown in the same order as the
    # internal array, so we can reuse the `bins` vector for efficiency.
    # We subtract item from the chosen bin, compute histogram, evaluate V.
    # To avoid Python loops we batch everything in numpy.

    # Subtract item from every bin (we will fix the non-chosen ones later
    # when building per-candidate histograms).  This is just a helper.
    new_caps = bins - item  # shape (N,), int64

    # Build all candidate histograms simultaneously.
    # We want an N x 101 array.
    # For each candidate c, we construct a binary matrix indicating which
    # capacity each bin (including the modified one) has.
    # This would normally be an N x N matrix, but we only need the histogram
    # of the N capacities, which is a sum over N bins.  Since N can be
    # up to ~5000, we must avoid O(N^2) memory/time.
    #
    # Instead we observe that for a fixed candidate c, the histogram is:
    #   hist = bincount(all bins except c, minlength=101) + bincount([new_cap_of_c], minlength=101)
    # where the first part is the same for all candidates (the original bins
    # histogram except that bin c is removed).  We can compute the original
    # full histogram of `bins` and subtract the contribution of bin c.
    #
    # Full histogram of current state:
    full_hist = np.bincount(bins, minlength=101)  # shape (101,), int64
    total_bins = len(bins)

    # We will compute score for each candidate c:
    #   hist_c = full_hist.copy()
    #   hist_c[bins[c]] -= 1
    #   hist_c[ new_caps[c] ] += 1
    #   score = -predict(hist_c / total_bins)
    # Because total_bins is constant for a given call, normalisation factor
    # is the same, we can also just pass counts and normalise inside if
    # predict were modified, but to keep predict simple we normalise per call.
    #
    # We can vectorise: for all c we want hist_c in an N x 101 array.
    # Set up base histograms all equal to full_hist, then adjust.
    base_hist = np.tile(full_hist, (N, 1)).astype(np.float64)  # N x 101

    # Subtract 1 at position bins[c] for each row c.
    base_hist[np.arange(N), bins] -= 1
    # Add 1 at position new_caps[c] for each row c.
    base_hist[np.arange(N), new_caps] += 1

    # Normalise to fractions.
    hist_matrix = base_hist / total_bins

    # Evaluate the predictor on each row.
    # Since our _predictor expects a single 101-vector, we loop efficiently
    # or batch if possible.  Looping over N up to ~5000 in Python is okay
    # because the predictor is tiny.
    scores = np.empty(N, dtype=np.float64)
    for c in range(N):
        scores[c] = _predictor.predict(hist_matrix[c])
    # Returning negative score because we want highest priority = smallest
    # predicted remaining bins.
    return -scores


# ======================================================================
# Offline training code (not executed at submission, kept for reference)
#
# import numpy as np
# from scipy.optimize import minimize
#
# def generate_item_sequence(rng, n=5000):
#     # Weibull-shaped distribution, mean ~40, integer 1..100.
#     shape = 1.5
#     scale = 45.0
#     while True:
#         x = rng.weibull(shape) * scale
#         item = int(np.clip(np.round(x), 1, 100))
#         yield item
#
# def simulate_episode(weights, rng):
#     # weights: flat vector of all parameters
#     # Unpack...
#     # Run best-fit baseline to collect state transitions and final bins.
#     ...
#     # Compute loss (e.g., squared error against final bins needed).
#     ...
#     return loss
#
# # Training was done with Adam on 20000 episodes, resulting in the hard-
# # coded weights above.
# ======================================================================
