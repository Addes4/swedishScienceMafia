# EVOLVE-BLOCK-START
"""Forecast-aided best fit.

Maintain an exponentially-smoothed estimate of the item-size sequence and
forecast the next few items.  For the tightest-fit candidate bins, run a fast
best-fit mini-simulation of {current item + forecasted items} and count how many
*additional* bins must be opened.  Bins that keep the pack compact under the
forecast are preferred; everything else falls back to plain best-fit.
"""
import numpy as np

# --- forecasting state -------------------------------------------------------
_ALPHA = 0.15          # EWMA smoothing factor
_state = {"mean": 40.0}  # distribution mean ~40 is a good prior

# --- simulation parameters ---------------------------------------------------
_K = 4                 # number of forecasted future items
_M = 32                # number of candidate bins to fully simulate
_LAMBDA = 130.0        # penalty per extra bin (dominates any residual gap)


def _bestfit_extra(base_used, r_c, forecast):
    """Simulate placing the current item (already represented by r_c) plus the
    forecasted items, using best-fit, and return the number of new bins opened.

    base_used : remaining capacities of currently used bins (excluding candidate)
    r_c       : remaining capacity of the candidate bin after placing the item
    forecast  : array of forecasted future item sizes
    """
    R = base_used
    if r_c > 0:
        R = np.append(R, r_c)
    R = R[R > 0]
    extra = 0
    for f in forecast:
        if R.size:
            # best fit: smallest residual that still holds f
            fits = R[R >= f]
            if fits.size:
                bestv = fits.min()
                idxs = np.where(R == bestv)[0]
                k = idxs[0]
                R[k] -= f
                if R[k] <= 0:
                    R = np.delete(R, k)
                continue
        # nothing fits -> open a fresh bin
        extra += 1
        nv = int(100 - f)
        if nv > 0:
            R = np.append(R, nv)
    return extra


def priority(item, bins):
    # ---- update forecast ----------------------------------------------------
    m = _state["mean"]
    _state["mean"] = (1.0 - _ALPHA) * m + _ALPHA * item
    fmean = max(1.0, _state["mean"])
    forecast = np.full(_K, fmean)

    bins = np.asarray(bins)
    N = bins.shape[0]
    residual = bins - item            # remaining capacity if item placed here (>=0)
    if N == 0:
        return residual.astype(np.float64)

    # ---- base score: best fit (tightest residual wins) ----------------------
    scores = -residual.astype(np.float64)

    # ---- shortlist: the tightest-fit candidates -----------------------------
    M = _M if N > _M else N
    if N > M:
        cand = np.argpartition(residual, M - 1)[:M]
    else:
        cand = np.arange(N)

    # used bins have remaining capacity strictly below 100 (unused are exactly 100)
    used_mask = bins < 100
    base_used = bins[used_mask].astype(np.int64)

    for c in cand:
        r_c = int(residual[c])
        if used_mask[c]:
            cap_c = int(bins[c])
            # start from all used bins and replace this bin's old residual
            R = base_used.copy()
            pos = np.where(R == cap_c)[0]
            if pos.size:
                R[pos[0]] = r_c
            else:
                R = np.append(R, r_c)
        else:
            R = base_used.copy()

        extra = _bestfit_extra(R, r_c, forecast)
        scores[c] = -float(r_c) - _LAMBDA * extra

    return scores
# EVOLVE-BLOCK-END
