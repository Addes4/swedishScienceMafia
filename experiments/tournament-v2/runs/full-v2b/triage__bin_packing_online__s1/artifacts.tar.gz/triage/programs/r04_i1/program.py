import numpy as np
from collections import deque
import bisect

class OnlineKDE:
    """Online kernel density estimator for item sizes [1..100] using a fixed Gaussian kernel."""
    def __init__(self, bandwidth=3.0, history_size=500):
        self.bandwidth = bandwidth
        self.history_size = history_size
        self.data = deque(maxlen=history_size)
        self._cache_grid = np.arange(0, 101)
        self._norm = 1.0 / (np.sqrt(2 * np.pi) * bandwidth)
        self._denom = 2.0 * bandwidth * bandwidth
        # Precomputed kernel values for efficiency
        self._kernel_cache = {}
        self._update_kernel_cache()
    
    def _update_kernel_cache(self):
        """Precompute Gaussian kernel for integer centers 1..100 onto 0..100."""
        self._kernel_cache = {}
        for x in range(1, 101):
            diff = self._cache_grid - x
            self._kernel_cache[x] = self._norm * np.exp(-diff * diff / self._denom)
    
    def update(self, item):
        self.data.append(item)
    
    def pdf(self, x):
        """Evaluate KDE at point x (0 <= x <= 100)."""
        if not self.data:
            return 0.0
        total = 0.0
        for center in self.data:
            diff = x - center
            total += self._norm * np.exp(-diff * diff / self._denom)
        return total / len(self.data)
    
    def expected_fit_count(self, gap):
        """Compute integral of KDE from 0 to gap, approximating via sum over integer sizes."""
        if gap <= 0:
            return 0.0
        if not self.data:
            return gap / 100.0  # fallback when no history
        
        # We approximate the integral by summing PDF over integer points
        # We cache the CDF array over 0..100 for speed
        if not hasattr(self, '_cdf_cache') or self._cdf_cache is None:
            self._precompute_cdf()
        
        # gap is integer, index into precomputed CDF
        idx = min(gap, 100)
        return self._cdf_cache[idx]
    
    def _precompute_cdf(self):
        """Precompute cumulative sum of KDE over integer domain [0, 100]."""
        if not self.data:
            self._cdf_cache = np.zeros(101)
            return
        
        pdf_vals = np.zeros(101)
        factor = 1.0 / len(self.data)
        for center in self.data:
            pdf_vals += self._kernel_cache[center]
        pdf_vals *= factor
        self._cdf_cache = np.cumsum(pdf_vals)
        # Normalize to ensure CDF(100) = 1.0?
        # It's an approximation, we keep as is.


# Global state: one KDE per problem instance. Reset per instance is manual.
# We'll store it in a global variable and reinitialize.
# Since the harness calls priority sequentially for one instance, we track state via a class.
_state = {"kde": None}

def priority(item, bins):
    """Return priority based on expected future items fitting in remaining gap."""
    kde = _state["kde"]
    if kde is None:
        kde = OnlineKDE(bandwidth=3.0, history_size=500)
        _state["kde"] = kde
    
    # Update KDE with current item (before placing, we include it)
    kde.update(item)
    
    # Compute expected fit count for each bin after placing item
    gaps = bins - item
    # Vectorized approach: compute CDF for each gap
    # Since KDE has precomputed CDF, we can map gaps to scores
    # But we need to handle gaps > 100 as capped at 100 (since items max 100)
    capped_gaps = np.minimum(gaps, 100)
    
    # Precompute CDF if needed or ensure it's fresh
    if not hasattr(kde, '_cdf_cache') or kde._cdf_cache is None:
        kde._precompute_cdf()
    
    scores = kde._cdf_cache[capped_gaps.astype(int)]
    
    # For gaps > 100, CDF should be 1.0 but we approximate; we can set to max CDF
    # Since items only up to 100, probability mass beyond 100 is zero.
    # Actually, KDE only defined up to 100, so integral to gap >100 = integral to 100.
    scores[gaps > 100] = kde._cdf_cache[100]
    
    return scores

# Reset state for each instance (the harness may not do this, but we can detect if it's a new instance by resetting manually? Not allowed to see reset signal.)
# We'll rely on the fact that instances are sequential but independent; we need to detect a new instance.
# Since item sequence length is fixed 5000, we can reset after every 5000 items.
# We'll count items per instance.

if not hasattr(priority, "counter"):
    priority.counter = 0

original_priority = priority

def priority_with_reset(item, bins):
    original_priority.counter += 1
    if original_priority.counter > 5000:
        # Reset for new instance
        _state["kde"] = None
        original_priority.counter = 1
    return original_priority(item, bins)

# Ensure the function signature is correct
import types
priority_with_reset.__name__ = "priority"

# Override global reference
priority = priority_with_reset
