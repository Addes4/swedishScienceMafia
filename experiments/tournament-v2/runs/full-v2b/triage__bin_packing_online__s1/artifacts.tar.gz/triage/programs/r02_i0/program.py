# EVOLVE-BLOCK-START
"""Sum-of-squares best fit: prefer tight fits, penalize large gaps quadratically."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Score = -((bins - item)^2). This strongly prefers perfect fits (score 0) and
    near-perfect fits, while quadratically penalizing bins that would leave a large
    residual gap. The hope is that medium-capacity bins are preserved for future items.
    """
    gap = bins - item
    return -(gap * gap)
# EVOLVE-BLOCK-END
