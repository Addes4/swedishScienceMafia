# EVOLVE-BLOCK-START
"""
Maintain an online sample of recent items and score bins by how many sample
items would exactly fit into each bin's remaining capacity. This helps favor
gaps more likely to accommodate future items.
"""
import numpy as np


class OnlineBinPacker:
    def __init__(self):
        self.item_history = np.zeros(0, dtype=np.int64)
        self.max_history = 1000  # Keep a rolling sample of recent items
        # Preallocate for efficiency
        self.history_buffer = np.zeros(self.max_history, dtype=np.int64)
        self.hist_pos = 0
    
    def _get_history(self, stream_item):
        """Add new item and return current history array."""
        self.history_buffer[self.hist_pos] = stream_item
        self.hist_pos = (self.hist_pos + 1) % self.max_history
        
        # Update count and handle overfull buffer
        count = (self.hist_pos if self.hist_pos < self.max_history else self.max_history)
        
        if count >= self.max_history:
            count = self.max_history
        else:
            count += 1  # Increment for new entry
        
        if count <= self.max_history:
            self.item_history = self.history_buffer[:count]
        else:
            # Trigger circular history logic
            lookback = min(count - self.max_history, self.max_history - 1)
            self.item_history = self.history_buffer[lookback:]
        
        return self.item_history
    
    def priority(self, item, bins):
        """
        Score bins by number of historical items that fit exactly into remaining capacity.
        """
        # Get our item history (use None to trigger the add operation)
        self._get_history(item)
        history = self._get_history(None)
        
        if len(history) == 0:
            # No history yet, return uniform priority
            return np.ones_like(bins, dtype=np.float64)
        
        # Count how many history items would exactly fit into each bin's remaining capacity
        gaps = bins.copy()
        gaps = np.maximum(gaps - 1, 0)  # If any bin has remaining == 0, it's not usable
        
        # We need to handle each bin's capacity and match against history items
        # Using advanced numpy operations for efficiency
        
        # Compute which history items would exactly fit each bin
        # For each history item size, count bins where bin_capacity >= item
        n_bins = len(bins)
        n_history = len(history)
        
        if n_history == 0:
            return np.ones(n_bins, dtype=np.float64)
        
        # Create a mask for bins with valid space for history items
        valid_bins = gaps >= 1
        if not np.any(valid_bins):
            return np.zeros(n_bins, dtype=np.float64)
        
        # Vectorized counting of matching history items per bin
        # For efficiency, compute counts per bin
        item_counts = np.zeros(n_bins, dtype=np.int64)
        
        for h_item in history:
            if h_item <= 0:
                continue
            mask = bins >= h_item
            item_counts += mask.astype(np.int64)
        
        # Score bins - prefer those that can accommodate more sample items
        score = np.maximum(item_counts, 0.0)
        
        return score.astype(np.float64)


# Monkey-patch to bind to global state for function calls
_bin_packer = None

def _init_packer():
    """Initialize the global bin packer at first call."""
    global _bin_packer
    if _bin_packer is None:
        _bin_packer = OnlineBinPacker()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin,
          including unused bins (remaining capacity 100), in bin order.
    """
    _init_packer()
    if _bin_packer is None:
        return np.ones_like(bins, dtype=np.float64)
    
    count = 0
    # Add item to tracker and count for first call
    _bin_packer._get_history(item)
    
    history = _bin_packer.item_history.copy()
    n_bins = len(bins)
    n_history = len(history)
    
    if n_bins == 0:
        return np.array([], dtype=np.float64)
    
    if n_history == 0 or np.all(bins == 0):
        return np.full(n_bins, dtype=np.float64)
    
    score = np.zeros(n_bins, dtype=np.float64)
    
    # For efficiency with item sizes 1-100, use histogram-like counting
    # Count how many history items <= each bin capacity
    capacity_counts = np.zeros(n_bins, dtype=np.int64)
    
    for h_item in history:
        if h_item <= 0 or h_item > 100:
            continue
        # Find bins with capacity >= h_item
        mask = bins >= h_item
        capacity_counts += mask.astype(np.int64)
    
    # Higher score = more history items that would fit exactly (or partially)
    return capacity_counts.astype(np.float64)
    
# Register the global priority function
# The harness will call this directly
prior = priority
# EVOLVE-BLOCK-END
