# EVOLVE-BLOCK-START
"""Histogram-shaping rule.

Idea: treat online bin packing as a controlled fragmentation process.  We keep a
global histogram of the residual capacities of *all* currently open bins (the
function is only shown bins the item fits in, but the harness passes a copy of
the full bin array; unused bins appear with remaining capacity 100).  For every
candidate placement we compute the new residual capacity, update the histogram,
and measure how much this moves the histogram closer to a target distribution
over residual capacities.

A good target is one that leaves many large-ish gaps available so that small
items can always find tight fits and large items still fit.  We use a target
that is a mixture: heavy mass on "empty-ish" bins (so new bins are created
lazily) and a spread over mid-range gaps that matches the fragmentation we
expect.  Concretely we compare L1 distance to a fixed smooth target profile and
pick the placement minimising it; ties broken towards tighter fits.
"""
import numpy as np

# capacity and number of residual-capacity buckets (1 unit granularity)
_CAP = 100
_EDGES = np.arange(_CAP + 2)  # 0..101 boundaries for residual 0..100

# ---- target residual distribution -------------------------------------------
# A residual of 0 means a full bin -> not useful.  Residuals near the top mean an
# almost-empty bin, which is very flexible.  We want a target that keeps plenty
# of flexibility: mass concentrated towards high residuals plus a smooth tail so
# mid-size items also find homes.  This profile was chosen a priori (not tuned to
# a particular instance) as a geometric-ish shape with a small uniform floor.
_r = np.arange(_CAP + 1, dtype=np.float64)
_target = 0.6 * (0.985 ** (60.0 - np.minimum(_r, 60.0))) + 0.4 / (_CAP + 1.0)
_target = np.where(_r == 0, 0.0, _target)
_target = _target / _target.sum()


class _State:
    def __init__(self):
        self.hist = np.zeros(_CAP + 1, dtype=np.float64)
        self.n = 0
        self.initialised = False
        # running estimate of total items / bins seen, to scale lazily


_STATE = _State()


def _update_hist(item, chosen_old_cap, chosen_new_cap):
    h = _STATE.hist
    h[chosen_old_cap] -= 1.0
    if chosen_new_cap >= 0:
        h[chosen_new_cap] += 1.0
    _STATE.n += 1


def priority(item, bins):
    """Score bins by the L1 improvement of the global residual histogram."""
    bins = np.asarray(bins, dtype=np.int64)
    h = _STATE.hist

    # ---- lazily (re)initialise the histogram from the *current* bin array ----
    # The harness gives us the full set of bins (those the item fits in).  The
    # first call thus reveals the current population of bins.  We rebuild the
    # histogram from `bins` whenever our internal count drifts too far from it,
    # which keeps us robust across instances and to bookkeeping drift.
    m = bins.shape[0]
    if not _STATE.initialised or abs(int(h.sum()) - m) > 2 + m // 20:
        h[:] = 0.0
        np.add.at(h, np.clip(bins, 0, _CAP), 1.0)
        _STATE.initialised = True

    # residual capacities after placing the item in each candidate bin
    new_caps = bins - item
    # clamp into valid range (the harness guarantees bins are bins the item fits
    # in, so new_caps >= 0, but be safe)
    new_caps = np.clip(new_caps, 0, _CAP)

    # ---- L1 distance change --------------------------------------------------
    # For each candidate we move one count from bins[k] to new_caps[k].  The
    # change in L1 distance to the target for bucket b with count h[b] is
    # (g[b] - h[b]) where g is the target *scaled to the current total*.
    total = h.sum()
    if total <= 0:
        total = float(m if m > 0 else 1)
    target_counts = _target * total

    # delta for removing a unit from bucket c is -( |g_c-(h_c-1)| - |g_c-h_c| )
    # = -(1 - 2*sign(h_c>g_c)) approximately; exact per-bucket gradient:
    # d/dh [ |g - h| ] = sign(h - g).
    # Removing a unit from old bucket o: delta = |g_o-(h_o-1)| - |g_o-h_o|.
    # Adding a unit to new bucket nw:   delta = |g_nw-(h_nw+1)| - |g_nw-h_nw|.
    old = bins
    g = target_counts

    h_old = h[old]
    h_new = h[new_caps]

    # removal delta
    d_old = np.abs(g[old] - (h_old - 1.0)) - np.abs(g[old] - h_old)
    # addition delta (new bucket, after the removal from its own bucket if same)
    # handle potential overlap: if old == new_caps, removal and addition happen
    # on same bucket; use net change.
    d_new = np.abs(g[new_caps] - (h_new + 1.0)) - np.abs(g[new_caps] - h_new)

    delta = d_old + d_new

    # We want the placement that *reduces* L1 distance -> smallest delta.
    score = -delta

    # ---- tie-break towards tighter fits (best-fit flavour) -------------------
    # Larger raw residual (less tight) gets a tiny penalty; scale so it only
    # matters for exact ties in the histogram objective.
    score = score + (bins.astype(np.float64)) * 1e-9

    # record the (provisional) chosen placement for the histogram update.
    # The true chosen bin is argmax with first-tie preference; replicate it.
    idx = int(np.argmax(score))
    old_cap = int(old[idx])
    new_cap = int(new_caps[idx])
    _update_hist(item, old_cap, new_cap)

    return score
# EVOLVE-BLOCK-END
