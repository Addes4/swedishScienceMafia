# EVOLVE-BLOCK-START
"""First-fit decreasing heuristic with bin reservation for large and small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Module-level state for bin reservation strategy
    if not hasattr(priority, "_large_item_count"):
        priority._large_item_count = 0
    if not hasattr(priority, "_reserve_threshold"):
        priority._reserve_threshold = 40
    
    score = np.full(len(bins), -np.inf)
    fits = bins >= item

    if item > 70:
        # Large items: Use best-fit but penalize bins below dynamic reserve threshold
        priority._large_item_count += 1
        largeitem_count = priority._large_item_count
        
        # Scale reserve threshold based on large item frequency (0 to 70)
        threshold = int(max(10, 60 - largeitem_count / 100))

        if np.any(fits):
            # Base score: negative gap for best-fit
            base_score = -(bins[fits] - item)
            
            # Add penalty to bins below threshold to prefer truly large-gap bins
            penalty = np.where(fits & (bins < threshold), -10000.0, 0.0)
            combined_score = base_score - penalty
            
            score[fits] = combined_score
    else:
        # Small items: Best-fit with bonus for bins below 30% capacity
        below_30 = fits & (bins < 30.0)
        
        if np.any(fits):
            # Base score: negative gap for best-fit
            base_score = -(bins[fits] - item)
            
            # Add bonus to bins with low remaining capacity to encourage filling them gradually
            bonus = np.where(below_30, 50.0, 0.0)
            
            combined_score = base_score + bonus
            score[fits] = combined_score
    
    return score
# EVOLVE-BLOCK-END
