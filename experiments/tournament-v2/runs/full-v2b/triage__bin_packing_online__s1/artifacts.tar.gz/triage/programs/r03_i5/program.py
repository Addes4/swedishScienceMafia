import numpy as np
from scipy.stats import gaussian_kde

class Priority:
    def __init__(self):
        # Store successful gaps (the remaining capacity right before placing an item)
        self.successful_gaps = []
        # Number of items seen so far
        self.n_items = 0
        # Kernel density estimate for ln(P(gap))
        self.kde = None
        self.lambda_factor = 0.1  # weight for entropic bonus

    def _maybe_update_kde(self):
        # Update KDE every 200 successful placements
        if len(self.successful_gaps) > 10 and len(self.successful_gaps) % 200 == 0:
            try:
                self.kde = gaussian_kde(self.successful_gaps)
            except np.linalg.LinAlgError:
                self.kde = None

    def priority(self, item, bins):
        self.n_items += 1

        # Base score: best-fit (negative gap = -(capacity - item))
        gaps = bins - item  # int64 array
        base_scores = -gaps.astype(float)

        # If we have a KDE, add entropic bonus for gaps that historically were successful
        if self.kde is not None:
            # KDE can fail if gaps are outside the estimated range; use small fallback
            try:
                logp = self.kde.logpdf(gaps)
                # In case of -inf, replace with a minimal value
                logp = np.nan_to_num(logp, nan=-20.0, neginf=-20.0)
                entropic_bonus = self.lambda_factor * logp
                scores = base_scores + entropic_bonus
            except Exception:
                scores = base_scores
        else:
            scores = base_scores

        # After choosing the bin, we need to store the gap? No, we can't, because
        # we don't know which bin will be chosen. The harness will use the scores
        # and select the argmax. We need to track the actual choice.
        # Instead, we can record the gap of the chosen bin in a wrapper or using
        # a callback mechanism? The problem doesn't allow us to know the choice.
        # We must infer the choice from the fact that `priority` is called again?
        # Actually, we can just store the gap that corresponds to the highest score,
        # but ties go to first bin. We can do:
        best_idx = np.argmax(scores)
        chosen_gap = gaps[best_idx]
        self.successful_gaps.append(chosen_gap)
        self._maybe_update_kde()

        return scores


# Global instance to maintain state across calls in the same run
_priority_instance = Priority()

def priority(item, bins):
    return _priority_instance.priority(item, bins)
