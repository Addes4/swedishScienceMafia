# EVOLVE-BLOCK-START
"""Improved bin packing: Best Fit with CDF-based penalization of gaps."""
import numpy as np

# Global state: track item size frequencies for CDF estimation
_item_counts = np.zeros(101, dtype=np.int64)
_total_items = 0
_lambda = 0.10  # small penalty weight for gap inefficiency

def priority(item, bins):
    """
    Score bins to prefer tight fits while avoiding gaps larger than future typical items.

    item: size of arriving item (1..100)
    bins: remaining capacities of bins that item fits in, in order
    Returns: scores (same length as bins); highest score wins, ties go to first bin
    """
    global _item_counts, _total_items, _lambda
    
    # Update distribution estimate with current item
    item_idx = item
    if item_idx < 101:
        _item_counts[item_idx] += 1
    _total_items += 1
    
    # If no distribution estimate yet, fall back to pure best fit
    if _total_items < 2:
        return -(bins - item)
    
    # Compute the CDF of observed item sizes (cumulative proportion <= size)
    cdf = np.cumsum(_item_counts) / _total_items
    
    # Score bins: minimize gap (fit), then penalize larger-than-typical gaps
    # Prefer gaps where CDF(gap) is low (few small items fit there)
    scores = (-(bins - item)
              - _lambda * np.array([1.0 if gap >= 101 else
                            _item_counts[0:gap+1].sum() / _total_items if gap > 0 else 0.0
                            for gap in bins], dtype=np.float64))
    
    # Clip negative to -100 to avoid potential issues (though mathematically shouldn't occur)
    return np.clip(scores, -100, None)
# EVOLVE-BLOCK-END
