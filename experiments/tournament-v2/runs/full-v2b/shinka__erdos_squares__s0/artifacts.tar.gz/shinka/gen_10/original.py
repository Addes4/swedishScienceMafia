# EVOLVE-BLOCK-START
"""Hybrid: grid/greedy baseline + guillotine partitions + inflation/relaxation + simulated annealing."""
import math
import random


# ---------- geometry helpers ----------

def _corners(x, y, a, s):
    c, si = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
    h = s * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(x + px * c - py * si, y + px * si + py * c) for px, py in pts]


def _overlap(s1, s2):
    x1, y1, a1, w1 = s1
    x2, y2, a2, w2 = s2
    if w1 <= 0 or w2 <= 0:
        return False
    r1 = w1 * 0.7072
    r2 = w2 * 0.7072
    if abs(x1 - x2) > r1 + r2 or abs(y1 - y2) > r1 + r2:
        return False
    p1 = _corners(x1, y1, a1, w1)
    p2 = _corners(x2, y2, a2, w2)

    def axes(pts):
        out = []
        for i in range(4):
            ax, ay = pts[i]
            bx, by = pts[(i + 1) % 4]
            out.append((-(by - ay), bx - ax))
        return out

    for ax, ay in axes(p1) + axes(p2):
        n = math.hypot(ax, ay)
        if n == 0:
            continue
        ax, ay = ax / n, ay / n
        q1 = [p[0] * ax + p[1] * ay for p in p1]
        q2 = [p[0] * ax + p[1] * ay for p in p2]
        if max(q1) <= min(q2) + 1e-12 or max(q2) <= min(q1) + 1e-12:
            return False
    return True


def _inside(x, y, a, s):
    if s <= 0:
        return True
    for xx, yy in _corners(x, y, a, s):
        if xx < -1e-9 or xx > 1 + 1e-9 or yy < -1e-9 or yy > 1 + 1e-9:
            return False
    return True


def _inside_unit(sq):
    return _inside(sq[0], sq[1], sq[2], sq[3])


def _valid(sq):
    for i in range(len(sq)):
        if not _inside_unit(sq[i]):
            return False
        for j in range(i + 1, len(sq)):
            if _overlap(tuple(sq[i]), tuple(sq[j])):
                return False
    return True


def _score(sq):
    return sum(s[3] for s in sq)


# ---------- grid / greedy baseline ----------

def _grid_plan(n, rows, cols, angle=0.0):
    if rows * cols > n:
        return None
    side = min(1.0 / rows, 1.0 / cols)
    total_w = cols * side
    total_h = rows * side
    ox = (1.0 - total_w) / 2.0
    oy = (1.0 - total_h) / 2.0
    sq = []
    for i in range(rows):
        for j in range(cols):
            cx = ox + (j + 0.5) * side
            cy = oy + (i + 0.5) * side
            sq.append((cx, cy, angle, side))
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq


def _best_grid(n):
    best_sq = None
    best_score = -1.0
    for rows in range(1, int(math.sqrt(n)) + 3):
        for cols in range(1, n // max(rows, 1) + 2):
            if rows * cols > n:
                continue
            plan = _grid_plan(n, rows, cols)
            if plan is None:
                continue
            score = sum(s[3] for s in plan)
            if score > best_score:
                best_score = score
                best_sq = plan
    if best_sq is None:
        best_sq = _grid_plan(n, 1, 1)
    return best_sq, best_score


def _greedy_fill(base_squares, n, trials=30, seed=12345):
    best = [tuple(s) for s in base_squares]
    best_sum = sum(s[3] for s in best)
    rng = random.Random(seed)

    for _ in range(trials):
        cand = [list(s) for s in base_squares]
        order = list(range(n))
        rng.shuffle(order)
        for idx in order:
            if cand[idx][3] <= 0:
                for _try in range(25):
                    s = rng.uniform(0.05, 0.45)
                    a = rng.choice([0.0, 0.0, 0.0, 0.125, 0.25, 0.375])
                    x = rng.uniform(s * 0.6, 1 - s * 0.6)
                    y = rng.uniform(s * 0.6, 1 - s * 0.6)
                    trial = (x, y, a, s)
                    if not _inside_unit(trial):
                        continue
                    ok = True
                    for k in range(n):
                        if k == idx:
                            continue
                        if _overlap(trial, tuple(cand[k])):
                            ok = False
                            break
                    if ok:
                        cand[idx] = list(trial)
                        break
        for _pass in range(3):
            for idx in range(n):
                x, y, a, s = cand[idx]
                if s <= 0:
                    continue
                for delta in (0.02, 0.01, 0.005):
                    ns = s + delta
                    if ns > 1.0:
                        continue
                    trial = (x, y, a, ns)
                    if not _inside_unit(trial):
                        continue
                    ok = True
                    for k in range(n):
                        if k == idx:
                            continue
                        if _overlap(trial, tuple(cand[k])):
                            ok = False
                            break
                    if ok:
                        cand[idx] = list(trial)
                        s = ns
                        break
        cur_sum = sum(s[3] for s in cand)
        if cur_sum > best_sum and _valid(cand):
            best_sum = cur_sum
            best = [tuple(c) for c in cand]
    return best, best_sum


# ---------- guillotine partition generator ----------

def _gen_partition(n, rng):
    rects = [(0.0, 0.0, 1.0, 1.0)]
    while len(rects) < n:
        weights = [(x1 - x0) * (y1 - y0) for x0, y0, x1, y1 in rects]
        tot = sum(weights)
        r = rng.random() * tot
        acc = 0.0
        idx = 0
        for i, w in enumerate(weights):
            acc += w
            if acc >= r:
                idx = i
                break
        x0, y0, x1, y1 = rects[idx]
        w = x1 - x0
        h = y1 - y0
        if w >= h:
            vertical = rng.random() < 0.75
        else:
            vertical = rng.random() < 0.25
        t = rng.uniform(0.25, 0.75)
        if vertical:
            xm = x0 + w * t
            rects[idx] = (x0, y0, xm, y1)
            rects.append((xm, y0, x1, y1))
        else:
            ym = y0 + h * t
            rects[idx] = (x0, y0, x1, ym)
            rects.append((x0, ym, x1, y1))
    return rects


def _partition_to_squares(rects):
    out = []
    for x0, y0, x1, y1 in rects:
        w = x1 - x0
        h = y1 - y0
        s = min(w, h)
        cx = 0.5 * (x0 + x1)
        cy = 0.5 * (y0 + y1)
        out.append([cx, cy, 0.0, s])
    return out


# ---------- inflation / relaxation ----------

def _relax(squares, iters=60, grow=0.06):
    n = len(squares)
    sq = [list(s) for s in squares]
    for _ in range(iters):
        for i in range(n):
            if sq[i][3] > 0:
                sq[i][3] += grow * sq[i][3]
        for i in range(n):
            x, y, a, s = sq[i]
            if s <= 0:
                continue
            r = s * 0.5
            if x - r < 0:
                sq[i][0] = r
            if x + r > 1:
                sq[i][0] = 1 - r
            if y - r < 0:
                sq[i][1] = r
            if y + r > 1:
                sq[i][1] = 1 - r
        moved = False
        for i in range(n):
            if sq[i][3] <= 0:
                continue
            for j in range(i + 1, n):
                if sq[j][3] <= 0:
                    continue
                xi, yi, _, si = sq[i]
                xj, yj, _, sj = sq[j]
                ri = si * 0.5
                rj = sj * 0.5
                dx = xj - xi
                dy = yj - yi
                minx = ri + rj
                miny = ri + rj
                ox = minx - abs(dx)
                oy = miny - abs(dy)
                if ox > 0 and oy > 0:
                    if ox < oy:
                        push = ox * 0.5 + 1e-4
                        if dx >= 0:
                            sq[i][0] -= push
                            sq[j][0] += push
                        else:
                            sq[i][0] += push
                            sq[j][0] -= push
                    else:
                        push = oy * 0.5 + 1e-4
                        if dy >= 0:
                            sq[i][1] -= push
                            sq[j][1] += push
                        else:
                            sq[i][1] += push
                            sq[j][1] -= push
                    moved = True
        for i in range(n):
            x, y, a, s = sq[i]
            if s <= 0:
                continue
            r = s * 0.5
            sq[i][0] = min(max(x, r), 1 - r)
            sq[i][1] = min(max(y, r), 1 - r)
        if not moved:
            break
    for _ in range(40):
        bad = False
        for i in range(n):
            if sq[i][3] <= 0:
                continue
            if not _inside(sq[i][0], sq[i][1], sq[i][2], sq[i][3]):
                sq[i][3] *= 0.97
                bad = True
                continue
            for j in range(i + 1, n):
                if sq[j][3] <= 0:
                    continue
                if _overlap(tuple(sq[i]), tuple(sq[j])):
                    sq[i][3] *= 0.97
                    sq[j][3] *= 0.97
                    bad = True
        if not bad:
            break
    return sq


# ---------- main solver ----------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # 1) grid / greedy baseline
    grid_sq, grid_score = _best_grid(n)
    best = [tuple(s) for s in grid_sq]
    best_score = grid_score

    if sum(1 for s in best if s[3] <= 0) > 0:
        refined, ref_score = _greedy_fill(grid_sq, n, trials=30, seed=777 + n)
        if ref_score > best_score and _valid(refined):
            best = refined
            best_score = ref_score

    # 2) guillotine + relaxation exploration
    rng = random.Random(987654321 + n)
    pop_size = 80 if n <= 20 else 50
    for _ in range(pop_size):
        rects = _gen_partition(n, rng)
        sq = _partition_to_squares(rects)
        sq = _relax(sq, iters=55, grow=0.05)
        sc = _score(sq)
        if sc > best_score and _valid(sq):
            best_score = sc
            best = [tuple(s) for s in sq]

    # 3) simulated annealing
    cur = [list(s) for s in best]
    cur_score = best_score
    T0 = 0.05
    iters = 500 if n <= 20 else 300
    for it in range(iters):
        T = T0 * (1.0 - it / float(iters)) + 1e-4
        rects = _gen_partition(n, rng)
        cand = _partition_to_squares(rects)
        for k in range(n):
            cand[k][0] += rng.uniform(-0.02, 0.02)
            cand[k][1] += rng.uniform(-0.02, 0.02)
        cand = _relax(cand, iters=35, grow=0.05)
        sc = _score(cand)
        if sc > cur_score or rng.random() < math.exp((sc - cur_score) / max(T, 1e-6)):
            cur = cand
            cur_score = sc
            if sc > best_score and _valid(cand):
                best_score = sc
                best = [tuple(s) for s in cand]

    # 4) final individual grow polish
    final = [list(s) for s in best]
    for _ in range(4):
        for i in range(n):
            x, y, a, s = final[i]
            if s <= 0:
                continue
            for delta in (0.02, 0.01, 0.005, 0.002):
                ns = s + delta
                if ns > 1.0:
                    continue
                trial = (x, y, a, ns)
                if not _inside(*trial):
                    continue
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if _overlap(trial, tuple(final[j])):
                        ok = False
                        break
                if ok:
                    final[i][3] = ns
                    break

    result = [tuple(s) for s in final[:n]]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END