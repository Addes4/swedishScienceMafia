# EVOLVE-BLOCK-START
"""Region-partition square packer.

Architecture
------------
The unit square is treated as a tree of axis-aligned rectangular regions.
Each leaf region is filled with an optimal grid of equal-sized squares that
fit inside it. Different *partition shapes* (grid, nested, corner-L,
two-corner, three-strip, and their mirrors) are described declaratively as
lists of regions, and one generic filler turns a shape into a candidate
layout. `solve(n)` enumerates all shapes, scores them, and returns the best.

This keeps every constraint in one place (`_region_grid`), removes the
duplicated geometry logic of the previous version, and makes adding new
partition shapes a one-line change.
"""
import math


# ---------- generic rectangular-region filling ----------

def _region_grid(rx, ry, rw, rh, count):
    """Fill the rectangle [rx,rx+rw] x [ry,ry+rh] with `count` equal squares
    arranged in the best a x b grid (a*b >= count, using only `count` cells).

    Returns (list_of_squares, score) where each square is (cx, cy, 0.0, side).
    If count <= 0, returns ([], 0.0).
    """
    if count <= 0 or rw <= 0.0 or rh <= 0.0:
        return [], 0.0
    best = None
    best_side = -1.0
    best_ab = None
    # a columns, b rows; a*b >= count so we can place `count` squares of the
    # largest possible side.
    for a in range(1, count + 1):
        for b in range(1, count + 1):
            if a * b < count:
                continue
            side = min(rw / a, rh / b)
            if side > best_side:
                best_side = side
                best_ab = (a, b)
    if best_ab is None:
        return [], 0.0
    a, b = best_ab
    side = best_side
    # centre the used a x b grid inside the region
    used_w = a * side
    used_h = b * side
    ox = rx + (rw - used_w) * 0.5
    oy = ry + (rh - used_h) * 0.5
    squares = []
    placed = 0
    for i in range(a):
        for j in range(b):
            if placed >= count:
                break
            cx = ox + (i + 0.5) * side
            cy = oy + (j + 0.5) * side
            squares.append((cx, cy, 0.0, side))
            placed += 1
        if placed >= count:
            break
    return squares, placed * side


def _score_layout(layout):
    return sum(sq[3] for sq in layout)


# ---------- partition shapes ----------
#
# A shape is a function (n) -> list_of_regions, where each region is
# (rx, ry, rw, rh, count). The generic filler turns it into a layout.

def _shape_grid(n):
    """Single region covering the whole unit square."""
    return [(0.0, 0.0, 1.0, 1.0, n)]


def _shape_corner_L(n):
    """Big square of side 1/k in bottom-left + right strip + top strip."""
    best = None
    best_score = -1.0
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem <= 0:
            score = s
            if score > best_score:
                best_score = score
                best = [(0.0, 0.0, s, s, 1)]
            continue
        # right strip: width (1-s), height 1, m squares stacked
        # top strip:   width s, height (1-s), p squares in a row
        for m in range(0, rem + 1):
            for p in range(0, rem - m + 1):
                if m + p > rem:
                    continue
                r_s = min(1.0 - s, 1.0 / m) if m > 0 else 0.0
                t_s = min(s, (1.0 - s) / p) if p > 0 else 0.0
                if m > 0 and r_s <= 0:
                    continue
                if p > 0 and t_s <= 0:
                    continue
                score = s + m * r_s + p * t_s
                if score > best_score:
                    best_score = score
                    regs = [(0.0, 0.0, s, s, 1)]
                    # right strip: m squares of side r_s in a vertical column
                    if m > 0:
                        regs.append((s, 0.0, 1.0 - s, 1.0, m))
                    # top strip: p squares of side t_s in a horizontal row
                    if p > 0:
                        regs.append((0.0, s, s, 1.0 - s, p))
                    best = regs
    if best is None:
        return _shape_grid(n)
    return best


def _shape_two_corner(n):
    """Big square of side 1/k in bottom-left; right strip and top strip
    independently sized (this is the classic n=11..15 construction)."""
    best = None
    best_score = -1.0
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem <= 0:
            if s > best_score:
                best_score = s
                best = [(0.0, 0.0, s, s, 1)]
            continue
        for m in range(0, rem + 1):
            for p in range(0, rem - m + 1):
                if m + p > rem:
                    continue
                r_s = min(1.0 - s, 1.0 / m) if m > 0 else 0.0
                t_s = min(s, (1.0 - s) / p) if p > 0 else 0.0
                if m > 0 and r_s <= 0:
                    continue
                if p > 0 and t_s <= 0:
                    continue
                score = s + m * r_s + p * t_s
                if score > best_score:
                    best_score = score
                    regs = [(0.0, 0.0, s, s, 1)]
                    if m > 0:
                        regs.append((s, 0.0, 1.0 - s, 1.0, m))
                    if p > 0:
                        regs.append((0.0, s, s, 1.0 - s, p))
                    best = regs
    if best is None:
        return _shape_grid(n)
    return best


def _shape_three_strip(n):
    """Big square of side 1/k in bottom-left, plus THREE independently sized
    regions in the L-shaped remainder:
      - right strip  : [s,0] x [1-s, 1]  (width 1-s, height 1-s)   -> m squares
      - top strip    : [0,s] x [s,   1]  (width 1, height 1-s)     -> p squares
      - corner block : [s,s] x [1-s, 1-s] (width 1-s, height 1-s)  -> q squares
    Wait, geometry: place the big square in the bottom-left corner of side s.
    The L-shaped remainder = right strip R = [s,1] x [0,1] minus the top-right
    corner, plus top strip T = [0,s] x [s,1]. To add a third free region, we
    split R into:
      R1 = [s,1] x [0, 1-s]   (width 1-s, height 1-s)   -> m squares (grid)
      R2 = [s,1] x [1-s, 1]   (width 1-s, height s)     -> q squares (grid)
    and keep T = [0,s] x [s,1] (width s, height 1-s)    -> p squares.

    All three sub-regions can have independent square sizes, giving an extra
    degree of freedom vs. the two-corner layout. The corner block R2 sits in
    the bottom-right where the right strip and top strip meet, which is
    exactly where the classic optimal packings for larger n place a small
    extra square.
    """
    best = None
    best_score = -1.0
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem <= 0:
            if s > best_score:
                best_score = s
                best = [(0.0, 0.0, s, s, 1)]
            continue
        # m: squares in R1 (bottom-right, width 1-s, height 1-s)
        # p: squares in T  (top-left,    width s,   height 1-s)
        # q: squares in R2 (top-right,   width 1-s, height s)
        for m in range(0, rem + 1):
            for p in range(0, rem - m + 1):
                for q in range(0, rem - m - p + 1):
                    if m + p + q > rem:
                        continue
                    # optimal side for each region given its count
                    s1 = min(1.0 - s, 1.0 - s)  # placeholder, computed below
                    r1 = 0.0
                    if m > 0:
                        # region R1: width 1-s, height 1-s
                        r1 = min((1.0 - s) / max(1, int(math.ceil(math.sqrt(m)))),
                                 (1.0 - s) / max(1, int(math.ceil(m / max(1, int(math.ceil(math.sqrt(m))))))))
                    # Simpler: use the generic best-grid helper's logic inline
                    def best_side(rw, rh, cnt):
                        if cnt <= 0:
                            return 0.0
                        bs = 0.0
                        for a in range(1, cnt + 1):
                            for b in range(1, cnt + 1):
                                if a * b < cnt:
                                    continue
                                v = min(rw / a, rh / b)
                                if v > bs:
                                    bs = v
                        return bs
                    r1 = best_side(1.0 - s, 1.0 - s, m)
                    r2 = best_side(1.0 - s, s, q)
                    r3 = best_side(s, 1.0 - s, p)
                    score = s + m * r1 + q * r2 + p * r3
                    if score > best_score:
                        best_score = score
                        regs = [(0.0, 0.0, s, s, 1)]
                        if m > 0:
                            regs.append((s, 0.0, 1.0 - s, 1.0 - s, m))
                        if q > 0:
                            regs.append((s, 1.0 - s, 1.0 - s, s, q))
                        if p > 0:
                            regs.append((0.0, s, s, 1.0 - s, p))
                        best = regs
    if best is None:
        return _shape_grid(n)
    return best


def _shape_nested(n):
    """k x k grid of side 1/k, with an m_x x m_y bottom-left block subdivided
    into an a x b grid of smaller squares.

    Generalizes the original square-corner version (m_x = m_y = m). Allowing
    the subdivided corner block to be rectangular decouples the two axes,
    mirroring the "independent sizing" primitive that made the two-corner
    family beat the square one; it strictly adds candidate layouts.
    """
    best = None
    best_score = -1.0
    for k in range(2, n + 2):
        s_big = 1.0 / k
        for m_x in range(1, k):
            for m_y in range(1, k):
                base_cnt = k * k - m_x * m_y
                if base_cnt > n:
                    continue
                for a in range(1, n + 1):
                    for b in range(1, n + 1):
                        cnt = base_cnt + a * b
                        if cnt > n:
                            continue
                        s_small = min((m_x * s_big) / a,
                                      (m_y * s_big) / b)
                        if s_small <= 0.0:
                            continue
                        score = base_cnt * s_big + a * b * s_small
                        if score > best_score:
                            best_score = score
                            best = ('nested', k, m_x, m_y, a, b,
                                    s_big, s_small)
    if best is None:
        return _shape_grid(n)
    _, k, m_x, m_y, a, b, s_big, s_small = best
    regs = []
    # subdivided m_x x m_y block in bottom-left
    regs.append((0.0, 0.0, m_x * s_big, m_y * s_big, a * b))
    # remaining full k x k cells: top strip (full width, (k-m_y) rows) and
    # left strip (height m_y rows, width (k-m_x) columns).
    top_h = (k - m_y) * s_big
    if top_h > 0:
        regs.append((0.0, m_y * s_big, 1.0, top_h, k * (k - m_y)))
    left_w = (k - m_x) * s_big
    if left_w > 0:
        regs.append((m_x * s_big, 0.0, left_w, m_y * s_big, m_y * (k - m_x)))
    return regs


# ---------- candidate assembly ----------

def _build_from_shape(shape_regs, n):
    """Turn a list of (rx, ry, rw, rh, count) regions into a layout of n squares."""
    squares = []
    for rx, ry, rw, rh, cnt in shape_regs:
        if cnt <= 0:
            continue
        sub, _ = _region_grid(rx, ry, rw, rh, cnt)
        squares.extend(sub)
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _mirror(layout):
    return [(1.0 - cx, 1.0 - cy, ang, side) for cx, cy, ang, side in layout]


# ---------- public API ----------

def _score(layout):
    return sum(sq[3] for sq in layout)


def _sanitize(layout, n):
    out = []
    for sq in layout[:n]:
        cx, cy, ang, side = sq
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        side = max(side, 0.0)
        out.append((cx, cy, ang, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    shapes = [
        _shape_grid,
        _shape_nested,
        _shape_corner_L,
        _shape_two_corner,
        _shape_three_strip,
    ]
    candidates = []
    for sh in shapes:
        try:
            regs = sh(n)
        except Exception:
            continue
        layout = _build_from_shape(regs, n)
        candidates.append(layout)
        candidates.append(_mirror(layout))

    best = max(candidates, key=_score)
    return _sanitize(best, n)
# EVOLVE-BLOCK-END