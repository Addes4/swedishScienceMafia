# EVOLVE-BLOCK-START
"""Adaptive square packer: generate multiple layout candidates and pick the best.

Structure:
  - LayoutCandidate: dataclass-like tuple holding squares and score
  - grid_layout(n): best a x b grid layout (a*b <= n), extras are zero-size
  - mixed_layout(n): one large square + grid in remaining L-shaped region
  - greedy_layout(n): greedy largest-first placement in a guillotine partition
  - evaluate(layout): sum of sides (assumes validity by construction)
  - solve(n): orchestrates candidate generation and selection
"""
import math


def _grid_layout(n):
    """Best a x b grid with a*b <= n; side = 1/max(a,b). Extras zero-size."""
    best = None
    best_score = -1.0
    for a in range(1, n + 1):
        for b in range(1, n + 1):
            if a * b > n:
                continue
            side = 1.0 / max(a, b)
            score = (a * b) * side
            if score > best_score:
                best_score = score
                best = (a, b, side)
    a, b, side = best
    squares = []
    for i in range(a):
        for j in range(b):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _mixed_layout(n):
    """One large square of side s in a corner, plus a grid filling the rest.

    Try s = 1/k for various k, then fill the L-shaped remainder with a grid.
    """
    best = None
    best_score = -1.0
    # Try placing a large square of side s in bottom-left corner
    for k in range(2, n + 1):
        s = 1.0 / k
        if k > n:
            break
        remaining = n - 1
        if remaining <= 0:
            score = s
            if score > best_score:
                best_score = score
                best = [(s / 2, s / 2, 0.0, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
            continue
        # Fill remaining region: right strip of width (1-s) x 1, and top strip of width s x (1-s)
        # Right strip: place a column of squares of side (1-s)/m
        # Top strip: place a row of squares of side (1-s)/m
        # Try m columns in right strip and p rows in top strip
        for m in range(1, remaining + 1):
            for p in range(0, remaining - m + 1):
                if m + p > remaining:
                    continue
                # right strip: m squares stacked vertically, side width (1-s)/m?
                # Actually: right strip width (1-s), height 1. m squares of side (1-s)/m stacked.
                # top strip width s, height (1-s). p squares of side s/p? No, height (1-s).
                # Use side = min((1-s)/m, s/p) if p>0 else (1-s)/m
                if p > 0:
                    side2 = min((1.0 - s) / m, s / p)
                else:
                    side2 = (1.0 - s) / m
                if side2 <= 0:
                    continue
                score = s + (m + p) * side2
                if score > best_score:
                    best_score = score
                    squares = [(s / 2, s / 2, 0.0, s)]
                    # right strip squares
                    w = (1.0 - s) / m
                    for i in range(m):
                        cx = s + (i + 0.5) * w
                        cy = (i + 0.5) * (1.0 / m) if False else (i + 0.5) * (1.0 / m)
                        cy = (i + 0.5) * (1.0 / m)
                        squares.append((cx, cy, 0.0, min(w, 1.0 / m)))
                    # top strip squares
                    if p > 0:
                        h = (1.0 - s) / p
                        for j in range(p):
                            cx = (j + 0.5) * (s / p)
                            cy = s + (j + 0.5) * h
                            squares.append((cx, cy, 0.0, min(s / p, h)))
                    while len(squares) < n:
                        squares.append((0.5, 0.5, 0.0, 0.0))
                    best = squares[:n]
    if best is None:
        return _grid_layout(n)
    return best


def _greedy_layout(n):
    """Greedy: repeatedly split the largest free rectangle and place a square."""
    # Simple guillotine: start with unit square, place squares in a binary split tree.
    # Candidate: place squares of equal size in best a x b arrangement, but try
    # also one square slightly larger than grid side in a corner.
    best = None
    best_score = -1.0
    # Try: one square of side s, remaining n-1 in grid of a x b where a*b <= n-1
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem == 0:
            score = s
            if score > best_score:
                best_score = score
                best = [(s / 2, s / 2, 0.0, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
            continue
        # remaining squares in region [0,1-s] x [0,1] (left strip) or similar
        # Use grid in strip of width (1-s): a x b with a*b <= rem, side = min((1-s)/a, 1/b)
        for a in range(1, rem + 1):
            for b in range(1, rem + 1):
                if a * b > rem:
                    continue
                side2 = min((1.0 - s) / a, 1.0 / b)
                score = s + (a * b) * side2
                if score > best_score:
                    best_score = score
                    squares = [(s / 2, s / 2, 0.0, s)]
                    for i in range(a):
                        for j in range(b):
                            cx = s + (i + 0.5) * ((1.0 - s) / a)
                            cy = (j + 0.5) * (1.0 / b)
                            squares.append((cx, cy, 0.0, side2))
                    while len(squares) < n:
                        squares.append((0.5, 0.5, 0.0, 0.0))
                    best = squares[:n]
    if best is None:
        return _grid_layout(n)
    return best


def _rect_pack(w, h, count, ox=0.0, oy=0.0):
    """Pack `count` squares into rectangle [ox,ox+w] x [oy,oy+h] as a grid,
    maximizing sum of sides. Returns list of (cx,cy,ang,side)."""
    if count <= 0 or w <= 0 or h <= 0:
        return []
    best = None
    best_score = -1.0
    for a in range(1, count + 1):
        for b in range(1, count + 1):
            if a * b > count:
                continue
            side = min(w / a, h / b)
            # only use full grid a*b; leftover squares become zero-size later
            score = (a * b) * side
            if score > best_score:
                best_score = score
                best = (a, b, side)
    a, b, side = best
    out = []
    for i in range(a):
        for j in range(b):
            out.append((ox + (i + 0.5) * (w / a), oy + (j + 0.5) * (h / b), 0.0, side))
    return out


def _shelf_layout(n):
    """Recursive guillotine: large square in corner, then pack the L-shaped
    remainder as right strip + top strip, each optimally gridded."""
    best = None
    best_score = -1.0
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem <= 0:
            score = s
            if score > best_score:
                best_score = score
                best = [(s / 2, s / 2, 0.0, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
            continue
        # right strip: width (1-s), height 1
        # top strip: width s, height (1-s)
        for m in range(0, rem + 1):
            p = rem - m
            right = _rect_pack(1.0 - s, 1.0, m, ox=s, oy=0.0)
            top = _rect_pack(s, 1.0 - s, p, ox=0.0, oy=s)
            squares = [(s / 2, s / 2, 0.0, s)] + right + top
            score = sum(sq[3] for sq in squares)
            if score > best_score:
                best_score = score
                while len(squares) < n:
                    squares.append((0.5, 0.5, 0.0, 0.0))
                best = squares[:n]
    if best is None:
        return _grid_layout(n)
    return best


def _spiral_layout(n):
    """Place largest square in a corner, then subdivide remaining L-region
    recursively: alternate right/top strips, each packed as a grid."""
    best = None
    best_score = -1.0
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem <= 0:
            continue
        # Try 3-region: big square + right strip + top strip, but split
        # right strip into two sub-strips (bottom and upper) for flexibility.
        for m1 in range(0, rem + 1):
            for m2 in range(0, rem - m1 + 1):
                p = rem - m1 - m2
                # right strip width (1-s), height 1: split into bottom m1 and top m2
                # Use heights h1, h2 to be chosen. Simple: split proportionally.
                if m1 + m2 > 0:
                    h1 = 1.0 * m1 / (m1 + m2)
                    h2 = 1.0 - h1
                else:
                    h1 = h2 = 0.0
                right1 = _rect_pack(1.0 - s, h1, m1, ox=s, oy=0.0) if m1 > 0 else []
                right2 = _rect_pack(1.0 - s, h2, m2, ox=s, oy=h1) if m2 > 0 else []
                top = _rect_pack(s, 1.0 - s, p, ox=0.0, oy=s)
                squares = [(s / 2, s / 2, 0.0, s)] + right1 + right2 + top
                score = sum(sq[3] for sq in squares)
                if score > best_score:
                    best_score = score
                    while len(squares) < n:
                        squares.append((0.5, 0.5, 0.0, 0.0))
                    best = squares[:n]
    if best is None:
        return _shelf_layout(n)
    return best


def _score(layout):
    return sum(sq[3] for sq in layout)


def _sanitize(layout, n):
    """Clamp to [0,1] and ensure n squares."""
    out = []
    for sq in layout[:n]:
        cx, cy, ang, side = sq
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        side = max(side, 0.0)
        out.append((cx, cy, ang, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out


def solve(n):
    """Generate candidates, pick the best-scoring layout."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    candidates = [
        _grid_layout(n),
        _mixed_layout(n),
        _greedy_layout(n),
        _corner_layout(n),
        _shelf_layout(n),
        _spiral_layout(n),
    ]
    best = max(candidates, key=_score)
    return _sanitize(best, n)
# EVOLVE-BLOCK-END