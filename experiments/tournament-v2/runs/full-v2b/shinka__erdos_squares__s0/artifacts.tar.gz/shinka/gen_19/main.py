# EVOLVE-BLOCK-START
"""Hybrid: grid/greedy baseline + guillotine partitions + inflation/relaxation + simulated annealing."""
import math
import random


# ---------- geometry helpers ----------

def _corners(x, y, a, s):
    c, si = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
    h = s * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(x + px * c - py * si, y + px * si + py * c) for px, py in pts]


def _overlap(s1, s2):
    x1, y1, a1, w1 = s1
    x2, y2, a2, w2 = s2
    if w1 <= 0 or w2 <= 0:
        return False
    r1 = w1 * 0.7072
    r2 = w2 * 0.7072
    if abs(x1 - x2) > r1 + r2 or abs(y1 - y2) > r1 + r2:
        return False
    p1 = _corners(x1, y1, a1, w1)
    p2 = _corners(x2, y2, a2, w2)

    def axes(pts):
        out = []
        for i in range(4):
            ax, ay = pts[i]
            bx, by = pts[(i + 1) % 4]
            out.append((-(by - ay), bx - ax))
        return out

    for ax, ay in axes(p1) + axes(p2):
        n = math.hypot(ax, ay)
        if n == 0:
            continue
        ax, ay = ax / n, ay / n
        q1 = [p[0] * ax + p[1] * ay for p in p1]
        q2 = [p[0] * ax + p[1] * ay for p in p2]
        if max(q1) <= min(q2) + 1e-12 or max(q2) <= min(q1) + 1e-12:
            return False
    return True


def _inside(x, y, a, s):
    if s <= 0:
        return True
    for xx, yy in _corners(x, y, a, s):
        if xx < -1e-9 or xx > 1 + 1e-9 or yy < -1e-9 or yy > 1 + 1e-9:
            return False
    return True


def _inside_unit(sq):
    return _inside(sq[0], sq[1], sq[2], sq[3])


def _valid(sq):
    for i in range(len(sq)):
        if not _inside_unit(sq[i]):
            return False
        for j in range(i + 1, len(sq)):
            if _overlap(tuple(sq[i]), tuple(sq[j])):
                return False
    return True


def _score(sq):
    return sum(s[3] for s in sq)


# ---------- grid / greedy baseline ----------

def _grid_plan(n, rows, cols, angle=0.0):
    if rows * cols > n:
        return None
    side = min(1.0 / rows, 1.0 / cols)
    total_w = cols * side
    total_h = rows * side
    ox = (1.0 - total_w) / 2.0
    oy = (1.0 - total_h) / 2.0
    sq = []
    for i in range(rows):
        for j in range(cols):
            cx = ox + (j + 0.5) * side
            cy = oy + (i + 0.5) * side
            sq.append((cx, cy, angle, side))
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq


def _best_grid(n):
    best_sq = None
    best_score = -1.0
    for rows in range(1, int(math.sqrt(n)) + 3):
        for cols in range(1, n // max(rows, 1) + 2):
            if rows * cols > n:
                continue
            plan = _grid_plan(n, rows, cols)
            if plan is None:
                continue
            score = sum(s[3] for s in plan)
            if score > best_score:
                best_score = score
                best_sq = plan
    if best_sq is None:
        best_sq = _grid_plan(n, 1, 1)
    return best_sq, best_score


def _staircase_plan(n, cols, rng):
    """Non-uniform column widths and row heights -> varied square sizes."""
    if cols < 1 or cols > n:
        return None
    # random column widths summing to 1
    raw = [rng.uniform(0.5, 1.5) for _ in range(cols)]
    tot = sum(raw)
    widths = [r / tot for r in raw]
    # distribute n squares among columns
    counts = [1] * cols
    for _ in range(n - cols):
        counts[rng.randrange(cols)] += 1
    sq = []
    x0 = 0.0
    for ci in range(cols):
        w = widths[ci]
        k = counts[ci]
        # random row heights summing to 1
        raw_h = [rng.uniform(0.5, 1.5) for _ in range(k)]
        tot_h = sum(raw_h)
        heights = [r / tot_h for r in raw_h]
        y0 = 0.0
        for ri in range(k):
            h = heights[ri]
            s = min(w, h)
            cx = x0 + w * 0.5
            cy = y0 + h * 0.5
            sq.append([cx, cy, 0.0, s])
            y0 += h
        x0 += w
    while len(sq) < n:
        sq.append([0.5, 0.5, 0.0, 0.0])
    return sq[:n]


def _best_staircase(n, rng, tries):
    best = None
    best_score = -1.0
    for _ in range(tries):
        cols = rng.randint(1, min(n, 5))
        plan = _staircase_plan(n, cols, rng)
        if plan is None:
            continue
        sc = sum(s[3] for s in plan)
        if sc > best_score:
            best_score = sc
            best = plan
    return best, best_score


def _two_corner_layout(n, a, m, p, q, r):
    """One big square in the bottom-left corner; right strip is an m x p grid,
    top strip is a q x r grid. Over-provisioning cells are dropped."""
    if a <= 0 or a >= 1:
        return None
    s_r = min((1.0 - a) / m, 1.0 / p) if m > 0 and p > 0 else 0.0
    s_t = min(a / q, (1.0 - a) / r) if q > 0 and r > 0 else 0.0
    sq = [[a * 0.5, a * 0.5, 0.0, a]]
    # right strip cells: columns j=0..m-1 along x in [a,1], rows i=0..p-1 along y in [0,1]
    rw = (1.0 - a) / m
    rh = 1.0 / p
    n_right = min(m * p, n - 1)
    for idx in range(n_right):
        j = idx % m
        i = idx // m
        cx = a + (j + 0.5) * rw
        cy = (i + 0.5) * rh
        sq.append([cx, cy, 0.0, s_r])
    # top strip cells: columns j=0..q-1 along x in [0,a], rows i=0..r-1 along y in [a,1]
    tw = a / q
    th = (1.0 - a) / r
    rem = n - len(sq)
    n_top = min(q * r, rem)
    for idx in range(n_top):
        j = idx % q
        i = idx // q
        cx = (j + 0.5) * tw
        cy = a + (i + 0.5) * th
        sq.append([cx, cy, 0.0, s_t])
    while len(sq) < n:
        sq.append([0.5, 0.5, 0.0, 0.0])
    return sq[:n]


def _best_two_corner(n):
    """Sweep the two-corner family and return the best valid layout."""
    best = None
    best_score = -1.0
    # candidate values of a: reciprocals and a fine grid around 1/sqrt(n)
    a_vals = set()
    for k in range(2, n + 2):
        a_vals.add(1.0 / k)
        a_vals.add(1.0 - 1.0 / k)
    center = 1.0 / math.sqrt(max(n, 1))
    for t in range(0, 21):
        a_vals.add(max(0.05, min(0.95, center - 0.2 + 0.02 * t)))
    for a in a_vals:
        if a <= 0.02 or a >= 0.98:
            continue
        for m in range(1, min(n, 6) + 1):
            for p in range(1, min(n, 6) + 1):
                if m * p > n - 1 + 6:
                    continue
                for q in range(1, min(n, 6) + 1):
                    for r in range(1, min(n, 6) + 1):
                        sq = _two_corner_layout(n, a, m, p, q, r)
                        if sq is None:
                            continue
                        sc = sum(s[3] for s in sq)
                        if sc > best_score and _valid(sq):
                            best_score = sc
                            best = sq
    return best, best_score


def _greedy_fill(base_squares, n, trials=30, seed=12345):
    best = [tuple(s) for s in base_squares]
    best_sum = sum(s[3] for s in best)
    rng = random.Random(seed)

    for _ in range(trials):
        cand = [list(s) for s in base_squares]
        order = list(range(n))
        rng.shuffle(order)
        for idx in order:
            if cand[idx][3] <= 0:
                for _try in range(25):
                    s = rng.uniform(0.05, 0.45)
                    a = rng.choice([0.0, 0.0, 0.0, 0.125, 0.25, 0.375])
                    x = rng.uniform(s * 0.6, 1 - s * 0.6)
                    y = rng.uniform(s * 0.6, 1 - s * 0.6)
                    trial = (x, y, a, s)
                    if not _inside_unit(trial):
                        continue
                    ok = True
                    for k in range(n):
                        if k == idx:
                            continue
                        if _overlap(trial, tuple(cand[k])):
                            ok = False
                            break
                    if ok:
                        cand[idx] = list(trial)
                        break
        for _pass in range(3):
            for idx in range(n):
                x, y, a, s = cand[idx]
                if s <= 0:
                    continue
                for delta in (0.02, 0.01, 0.005):
                    ns = s + delta
                    if ns > 1.0:
                        continue
                    trial = (x, y, a, ns)
                    if not _inside_unit(trial):
                        continue
                    ok = True
                    for k in range(n):
                        if k == idx:
                            continue
                        if _overlap(trial, tuple(cand[k])):
                            ok = False
                            break
                    if ok:
                        cand[idx] = list(trial)
                        s = ns
                        break
        cur_sum = sum(s[3] for s in cand)
        if cur_sum > best_sum and _valid(cand):
            best_sum = cur_sum
            best = [tuple(c) for c in cand]
    return best, best_sum


# ---------- guillotine partition generator ----------

def _gen_partition(n, rng):
    rects = [(0.0, 0.0, 1.0, 1.0)]
    while len(rects) < n:
        weights = [(x1 - x0) * (y1 - y0) for x0, y0, x1, y1 in rects]
        tot = sum(weights)
        r = rng.random() * tot
        acc = 0.0
        idx = 0
        for i, w in enumerate(weights):
            acc += w
            if acc >= r:
                idx = i
                break
        x0, y0, x1, y1 = rects[idx]
        w = x1 - x0
        h = y1 - y0
        if w >= h:
            vertical = rng.random() < 0.75
        else:
            vertical = rng.random() < 0.25
        t = rng.uniform(0.25, 0.75)
        if vertical:
            xm = x0 + w * t
            rects[idx] = (x0, y0, xm, y1)
            rects.append((xm, y0, x1, y1))
        else:
            ym = y0 + h * t
            rects[idx] = (x0, y0, x1, ym)
            rects.append((x0, ym, x1, y1))
    return rects


def _partition_to_squares(rects):
    out = []
    for x0, y0, x1, y1 in rects:
        w = x1 - x0
        h = y1 - y0
        s = min(w, h)
        cx = 0.5 * (x0 + x1)
        cy = 0.5 * (y0 + y1)
        out.append([cx, cy, 0.0, s])
    return out


# ---------- inflation / relaxation ----------

def _relax(squares, iters=60, grow=0.06):
    n = len(squares)
    sq = [list(s) for s in squares]
    for _ in range(iters):
        for i in range(n):
            if sq[i][3] > 0:
                sq[i][3] += grow * sq[i][3]
        for i in range(n):
            x, y, a, s = sq[i]
            if s <= 0:
                continue
            r = s * 0.5
            if x - r < 0:
                sq[i][0] = r
            if x + r > 1:
                sq[i][0] = 1 - r
            if y - r < 0:
                sq[i][1] = r
            if y + r > 1:
                sq[i][1] = 1 - r
        moved = False
        for i in range(n):
            if sq[i][3] <= 0:
                continue
            for j in range(i + 1, n):
                if sq[j][3] <= 0:
                    continue
                xi, yi, _, si = sq[i]
                xj, yj, _, sj = sq[j]
                ri = si * 0.5
                rj = sj * 0.5
                dx = xj - xi
                dy = yj - yi
                minx = ri + rj
                miny = ri + rj
                ox = minx - abs(dx)
                oy = miny - abs(dy)
                if ox > 0 and oy > 0:
                    if ox < oy:
                        push = ox * 0.5 + 1e-4
                        if dx >= 0:
                            sq[i][0] -= push
                            sq[j][0] += push
                        else:
                            sq[i][0] += push
                            sq[j][0] -= push
                    else:
                        push = oy * 0.5 + 1e-4
                        if dy >= 0:
                            sq[i][1] -= push
                            sq[j][1] += push
                        else:
                            sq[i][1] += push
                            sq[j][1] -= push
                    moved = True
        for i in range(n):
            x, y, a, s = sq[i]
            if s <= 0:
                continue
            r = s * 0.5
            sq[i][0] = min(max(x, r), 1 - r)
            sq[i][1] = min(max(y, r), 1 - r)
        if not moved:
            break
    for _ in range(40):
        bad = False
        for i in range(n):
            if sq[i][3] <= 0:
                continue
            if not _inside(sq[i][0], sq[i][1], sq[i][2], sq[i][3]):
                sq[i][3] *= 0.97
                bad = True
                continue
            for j in range(i + 1, n):
                if sq[j][3] <= 0:
                    continue
                if _overlap(tuple(sq[i]), tuple(sq[j])):
                    sq[i][3] *= 0.97
                    sq[j][3] *= 0.97
                    bad = True
        if not bad:
            break
    return sq


# ---------- main solver ----------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # 1) grid / greedy baseline
    grid_sq, grid_score = _best_grid(n)
    best = [tuple(s) for s in grid_sq]
    best_score = grid_score

    if sum(1 for s in best if s[3] <= 0) > 0:
        refined, ref_score = _greedy_fill(grid_sq, n, trials=30, seed=777 + n)
        if ref_score > best_score and _valid(refined):
            best = refined
            best_score = ref_score

    # 1a) two-corner parametric layouts (big square + strip grids)
    tc_sq, tc_score = _best_two_corner(n)
    if tc_sq is not None and tc_score > best_score and _valid(tc_sq):
        best = [tuple(s) for s in tc_sq]
        best_score = tc_score
        # relax the two-corner seed
        relaxed_tc = _relax([list(s) for s in tc_sq], iters=80, grow=0.08)
        sc_tc = _score(relaxed_tc)
        if sc_tc > best_score and _valid(relaxed_tc):
            best_score = sc_tc
            best = [tuple(s) for s in relaxed_tc]

    # 1b) asymmetric staircase plans (varied sizes) + relaxation
    rng = random.Random(31415 + n)
    stair_best, stair_score = _best_staircase(n, rng, tries=60)
    if stair_best is not None and stair_score > best_score:
        best = [tuple(s) for s in stair_best]
        best_score = stair_score
    # relax the best staircase
    if stair_best is not None:
        relaxed_stair = _relax([list(s) for s in stair_best], iters=80, grow=0.08)
        sc = _score(relaxed_stair)
        if sc > best_score and _valid(relaxed_stair):
            best_score = sc
            best = [tuple(s) for s in relaxed_stair]

    # 2) guillotine + relaxation exploration
    rng = random.Random(987654321 + n)
    pop_size = 80 if n <= 20 else 50
    for _ in range(pop_size):
        rects = _gen_partition(n, rng)
        sq = _partition_to_squares(rects)
        sq = _relax(sq, iters=55, grow=0.06)
        sc = _score(sq)
        if sc > best_score and _valid(sq):
            best_score = sc
            best = [tuple(s) for s in sq]
        # also try a staircase-seeded candidate
        if rng.random() < 0.3:
            cols = rng.randint(1, min(n, 5))
            sp = _staircase_plan(n, cols, rng)
            if sp is not None:
                sp = _relax(sp, iters=55, grow=0.06)
                sc2 = _score(sp)
                if sc2 > best_score and _valid(sp):
                    best_score = sc2
                    best = [tuple(s) for s in sp]

    # 3) simulated annealing
    cur = [list(s) for s in best]
    cur_score = best_score
    T0 = 0.05
    iters = 500 if n <= 20 else 300
    for it in range(iters):
        T = T0 * (1.0 - it / float(iters)) + 1e-4
        rects = _gen_partition(n, rng)
        cand = _partition_to_squares(rects)
        for k in range(n):
            cand[k][0] += rng.uniform(-0.02, 0.02)
            cand[k][1] += rng.uniform(-0.02, 0.02)
        cand = _relax(cand, iters=35, grow=0.05)
        sc = _score(cand)
        if sc > cur_score or rng.random() < math.exp((sc - cur_score) / max(T, 1e-6)):
            cur = cand
            cur_score = sc
            if sc > best_score and _valid(cand):
                best_score = sc
                best = [tuple(s) for s in cand]

    # 4) final individual grow polish (with coordinate nudging)
    final = [list(s) for s in best]
    for _ in range(6):
        for i in range(n):
            x, y, a, s = final[i]
            if s <= 0:
                continue
            # try small coordinate nudges to allow more growth
            for dx, dy in ((0.0, 0.0), (0.01, 0.0), (-0.01, 0.0),
                           (0.0, 0.01), (0.0, -0.01)):
                nx, ny = x + dx, y + dy
                for delta in (0.03, 0.02, 0.01, 0.005, 0.002, 0.001):
                    ns = s + delta
                    if ns > 1.0:
                        continue
                    trial = (nx, ny, a, ns)
                    if not _inside(*trial):
                        continue
                    ok = True
                    for j in range(n):
                        if j == i:
                            continue
                        if _overlap(trial, tuple(final[j])):
                            ok = False
                            break
                    if ok:
                        final[i][0] = nx
                        final[i][1] = ny
                        final[i][3] = ns
                        x, y, s = nx, ny, ns
                        break
                else:
                    continue
                break

    result = [tuple(s) for s in final[:n]]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END