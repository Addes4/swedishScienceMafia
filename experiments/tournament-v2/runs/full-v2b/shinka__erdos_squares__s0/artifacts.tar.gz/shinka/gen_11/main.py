# EVOLVE-BLOCK-START
"""Slack-guided contact packing: deterministic tiling + monotone grow + contact-graph polish."""
import math
import random


# ---------- geometry ----------

def _corners(x, y, a, s):
    c, si = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
    h = s * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(x + px * c - py * si, y + px * si + py * c) for px, py in pts]


def _overlap(s1, s2):
    x1, y1, a1, w1 = s1
    x2, y2, a2, w2 = s2
    if w1 <= 1e-12 or w2 <= 1e-12:
        return False
    r1 = w1 * 0.7072
    r2 = w2 * 0.7072
    if abs(x1 - x2) > r1 + r2 or abs(y1 - y2) > r1 + r2:
        return False
    p1 = _corners(x1, y1, a1, w1)
    p2 = _corners(x2, y2, a2, w2)

    def axes(pts):
        out = []
        for i in range(4):
            ax, ay = pts[i]
            bx, by = pts[(i + 1) % 4]
            out.append((-(by - ay), bx - ax))
        return out

    for ax, ay in axes(p1) + axes(p2):
        n = math.hypot(ax, ay)
        if n == 0:
            continue
        ax, ay = ax / n, ay / n
        q1 = [p[0] * ax + p[1] * ay for p in p1]
        q2 = [p[0] * ax + p[1] * ay for p in p2]
        if max(q1) <= min(q2) + 1e-12 or max(q2) <= min(q1) + 1e-12:
            return False
    return True


def _inside(x, y, a, s):
    if s <= 1e-12:
        return True
    for xx, yy in _corners(x, y, a, s):
        if xx < -1e-9 or xx > 1 + 1e-9 or yy < -1e-9 or yy > 1 + 1e-9:
            return False
    return True


def _inside_unit(sq):
    return _inside(sq[0], sq[1], sq[2], sq[3])


def _valid(sq):
    n = len(sq)
    for i in range(n):
        if not _inside_unit(sq[i]):
            return False
        for j in range(i + 1, n):
            if _overlap(tuple(sq[i]), tuple(sq[j])):
                return False
    return True


def _score(sq):
    return sum(s[3] for s in sq)


# ---------- deterministic tilings ----------

def _tiling_plan(n, rows, cols):
    """Row-major tiling of unit square into rows*cols cells; each cell gets a square."""
    if rows * cols != n:
        return None
    # optimal side for a rows x cols grid is min(1/rows, 1/cols)
    side = min(1.0 / rows, 1.0 / cols)
    cell_w = 1.0 / cols
    cell_h = 1.0 / rows
    sq = []
    for i in range(rows):
        for j in range(cols):
            cx = (j + 0.5) * cell_w
            cy = (i + 0.5) * cell_h
            sq.append([cx, cy, 0.0, side])
    return sq


def _best_tiling(n):
    best = None
    best_score = -1.0
    for rows in range(1, n + 1):
        if n % rows != 0:
            continue
        cols = n // rows
        plan = _tiling_plan(n, rows, cols)
        if plan is None:
            continue
        sc = _score(plan)
        if sc > best_score:
            best_score = sc
            best = plan
    return best, best_score


def _mixed_tiling(n):
    """Try rows x cols tilings with a few zero-size fillers to get non-uniform sizes."""
    best = None
    best_score = -1.0
    for rows in range(1, n + 1):
        for cols in range(1, n + 1):
            if rows * cols > n:
                continue
            side = min(1.0 / rows, 1.0 / cols)
            cell_w = 1.0 / cols
            cell_h = 1.0 / rows
            sq = []
            for i in range(rows):
                for j in range(cols):
                    cx = (j + 0.5) * cell_w
                    cy = (i + 0.5) * cell_h
                    sq.append([cx, cy, 0.0, side])
            while len(sq) < n:
                sq.append([0.5, 0.5, 0.0, 0.0])
            sc = _score(sq)
            if sc > best_score:
                best_score = sc
                best = sq
    return best, best_score


# ---------- monotone grow with contact detection ----------

def _grow_exact(sq, n, max_iters=200):
    """Grow each square greedily as long as no overlap and inside unit. Deterministic."""
    sq = [list(s) for s in sq]
    for _ in range(max_iters):
        improved = False
        # sort indices by current side descending to grow big ones first
        order = sorted(range(n), key=lambda i: -sq[i][3])
        for i in order:
            x, y, a, s = sq[i]
            if s <= 0:
                continue
            # binary search maximum side
            lo, hi = s, 1.0
            # exponential search
            step = 0.01
            best_s = s
            # try growing
            cur = s
            for _ in range(30):
                trial_s = cur + step
                if trial_s > 1.0:
                    break
                trial = (x, y, a, trial_s)
                if not _inside(*trial):
                    break
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if _overlap(trial, tuple(sq[j])):
                        ok = False
                        break
                if ok:
                    cur = trial_s
                    best_s = cur
                else:
                    break
            # try finer steps
            for step2 in (0.005, 0.002, 0.001):
                for _ in range(20):
                    trial_s = cur + step2
                    if trial_s > 1.0:
                        break
                    trial = (x, y, a, trial_s)
                    if not _inside(*trial):
                        break
                    ok = True
                    for j in range(n):
                        if j == i:
                            continue
                        if _overlap(trial, tuple(sq[j])):
                            ok = False
                            break
                    if ok:
                        cur = trial_s
                        best_s = cur
                    else:
                        break
            if best_s > s + 1e-12:
                sq[i][3] = best_s
                improved = True
        if not improved:
            break
    return sq


def _translate_to_slack(sq, n, iters=80):
    """Push squares toward empty space to allow growth."""
    sq = [list(s) for s in sq]
    for _ in range(iters):
        moved = False
        # try to move each square slightly toward the center of the largest gap
        for i in range(n):
            x, y, a, s = sq[i]
            if s <= 0:
                continue
            best_dx, best_dy = 0.0, 0.0
            best_gain = 0.0
            for dx, dy in ((0.01, 0.0), (-0.01, 0.0), (0.0, 0.01), (0.0, -0.01),
                           (0.007, 0.007), (-0.007, 0.007), (0.007, -0.007), (-0.007, -0.007)):
                nx, ny = x + dx, y + dy
                if not _inside(nx, ny, a, s):
                    continue
                # check overlap
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if _overlap((nx, ny, a, s), tuple(sq[j])):
                        ok = False
                        break
                if not ok:
                    continue
                # estimate potential growth
                gain = 0.0
                for step in (0.02, 0.01, 0.005):
                    ts = s + step
                    if ts > 1.0:
                        continue
                    if not _inside(nx, ny, a, ts):
                        continue
                    kok = True
                    for j in range(n):
                        if j == i:
                            continue
                        if _overlap((nx, ny, a, ts), tuple(sq[j])):
                            kok = False
                            break
                    if kok:
                        gain = step
                        break
                if gain > best_gain:
                    best_gain = gain
                    best_dx, best_dy = dx, dy
            if best_gain > 0:
                sq[i][0] += best_dx
                sq[i][1] += best_dy
                moved = True
        if not moved:
            break
    return sq


def _rotate_polish(sq, n, tries=40, seed=999):
    """Try small rotations on largest squares to unlock growth."""
    rng = random.Random(seed + n)
    sq = [list(s) for s in sq]
    order = sorted(range(n), key=lambda i: -sq[i][3])
    for _ in range(tries):
        i = order[rng.randrange(min(len(order), max(1, n // 2)))]
        x, y, a, s = sq[i]
        if s <= 0:
            continue
        best_a = a
        best_s = s
        for da in (0.02, -0.02, 0.05, -0.05, 0.125, -0.125, 0.25, -0.25):
            na = (a + da) % 1.0
            # try growing at new angle
            cur = s
            for step in (0.02, 0.01, 0.005, 0.002):
                for _ in range(10):
                    ts = cur + step
                    if ts > 1.0:
                        break
                    if not _inside(x, y, na, ts):
                        break
                    ok = True
                    for j in range(n):
                        if j == i:
                            continue
                        if _overlap((x, y, na, ts), tuple(sq[j])):
                            ok = False
                            break
                    if ok:
                        cur = ts
                    else:
                        break
            if cur > best_s + 1e-9:
                best_s = cur
                best_a = na
        if best_s > s + 1e-9:
            sq[i][2] = best_a
            sq[i][3] = best_s
    return sq


# ---------- main solver ----------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # 1) deterministic best tiling
    tiling_sq, tiling_score = _best_tiling(n)
    mixed_sq, mixed_score = _mixed_tiling(n)
    if mixed_score > tiling_score:
        best = mixed_sq
        best_score = mixed_score
    else:
        best = tiling_sq
        best_score = tiling_score

    # 2) initial grow
    best = _grow_exact(best, n)
    sc = _score(best)
    if sc > best_score and _valid(best):
        best_score = sc

    # 3) translate to slack, grow again
    cand = _translate_to_slack(best, n, iters=60)
    cand = _grow_exact(cand, n)
    sc = _score(cand)
    if sc > best_score and _valid(cand):
        best_score = sc
        best = cand

    # 4) rotation polish
    cand = _rotate_polish(best, n, tries=30)
    cand = _grow_exact(cand, n)
    sc = _score(cand)
    if sc > best_score and _valid(cand):
        best_score = sc
        best = cand

    # 5) local coordinate nudges + grow
    for _ in range(8):
        improved = False
        for i in range(n):
            x, y, a, s = best[i]
            if s <= 0:
                continue
            for dx, dy in ((0.005, 0.0), (-0.005, 0.0), (0.0, 0.005), (0.0, -0.005),
                           (0.003, 0.003), (-0.003, 0.003), (0.003, -0.003), (-0.003, -0.003)):
                nx, ny = x + dx, y + dy
                if not _inside(nx, ny, a, s):
                    continue
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if _overlap((nx, ny, a, s), tuple(best[j])):
                        ok = False
                        break
                if ok:
                    # try to grow at new position
                    cur = s
                    for step in (0.01, 0.005, 0.002, 0.001):
                        for _ in range(5):
                            ts = cur + step
                            if ts > 1.0:
                                break
                            if not _inside(nx, ny, a, ts):
                                break
                            kok = True
                            for j in range(n):
                                if j == i:
                                    continue
                                if _overlap((nx, ny, a, ts), tuple(best[j])):
                                    kok = False
                                    break
                            if kok:
                                cur = ts
                            else:
                                break
                    if cur > s + 1e-9:
                        best[i] = [nx, ny, a, cur]
                        improved = True
                        break
        if not improved:
            break

    # final grow
    best = _grow_exact(best, n)
    best_score = max(best_score, _score(best))

    result = [tuple(s) for s in best[:n]]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END
