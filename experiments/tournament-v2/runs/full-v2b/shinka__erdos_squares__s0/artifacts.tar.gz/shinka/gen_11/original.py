# EVOLVE-BLOCK-START
"""Adaptive grid + free square packing with local refinement."""
import math
import random


def _overlap(s1, s2):
    """Check if two squares overlap in interior (approx via SAT)."""
    x1, y1, a1, s1_ = s1
    x2, y2, a2, s2_ = s2
    if s1_ <= 0 or s2_ <= 0:
        return False
    # quick bounding-box check
    r1 = s1_ * 0.7072
    r2 = s2_ * 0.7072
    if abs(x1 - x2) > r1 + r2 or abs(y1 - y2) > r1 + r2:
        return False
    # SAT for rotated squares
    def corners(x, y, a, s):
        c, si = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
        h = s / 2.0
        pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
        return [(x + px * c - py * si, y + px * si + py * c) for px, py in pts]

    def axes(pts):
        ax = []
        for i in range(4):
            x1_, y1_ = pts[i]
            x2_, y2_ = pts[(i + 1) % 4]
            dx, dy = x2_ - x1_, y2_ - y1_
            ax.append((-dy, dx))
        return ax

    p1 = corners(x1, y1, a1, s1_)
    p2 = corners(x2, y2, a2, s2_)
    for ax in axes(p1) + axes(p2):
        n = math.hypot(*ax)
        if n == 0:
            continue
        axn = (ax[0] / n, ax[1] / n)
        proj1 = [p[0] * axn[0] + p[1] * axn[1] for p in p1]
        proj2 = [p[0] * axn[0] + p[1] * axn[1] for p in p2]
        if max(proj1) <= min(proj2) + 1e-12 or max(proj2) <= min(proj1) + 1e-12:
            return False
    return True


def _inside_unit(sq):
    x, y, a, s = sq
    if s <= 0:
        return True
    c, si = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
    h = s / 2.0
    for px, py in [(-h, -h), (h, -h), (h, h), (-h, h)]:
        xx = x + px * c - py * si
        yy = y + px * si + py * c
        if xx < -1e-9 or xx > 1 + 1e-9 or yy < -1e-9 or yy > 1 + 1e-9:
            return False
    return True


def _valid(squares):
    for i in range(len(squares)):
        if not _inside_unit(squares[i]):
            return False
        for j in range(i + 1, len(squares)):
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _grid_plan(n, rows, cols, angle=0.0):
    """Return grid squares for rows x cols grid, plus zero-size fillers."""
    if rows * cols > n:
        return None
    side = min(1.0 / rows, 1.0 / cols)
    # center the grid
    total_w = cols * side
    total_h = rows * side
    ox = (1.0 - total_w) / 2.0
    oy = (1.0 - total_h) / 2.0
    sq = []
    for i in range(rows):
        for j in range(cols):
            cx = ox + (j + 0.5) * side
            cy = oy + (i + 0.5) * side
            sq.append((cx, cy, angle, side))
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq


def _greedy_fill(base_squares, n, trials=40):
    """Try to enlarge/fill leftover slots with free squares via random search."""
    best = list(base_squares)
    best_sum = sum(s[3] for s in best)
    rng = random.Random(12345)

    for _ in range(trials):
        cand = [list(s) for s in base_squares]
        # find non-zero squares and try to slightly shrink them, then add new ones
        order = list(range(n))
        rng.shuffle(order)
        for idx in order:
            if cand[idx][3] <= 0:
                # try to place a new square in a random free spot
                for _try in range(20):
                    s = rng.uniform(0.05, 0.45)
                    a = rng.choice([0.0, 0.0, 0.0, 0.125, 0.25, 0.375])
                    x = rng.uniform(s * 0.6, 1 - s * 0.6)
                    y = rng.uniform(s * 0.6, 1 - s * 0.6)
                    trial = (x, y, a, s)
                    if not _inside_unit(trial):
                        continue
                    ok = True
                    for k in range(n):
                        if k == idx:
                            continue
                        if _overlap(trial, cand[k]):
                            ok = False
                            break
                    if ok:
                        cand[idx] = list(trial)
                        break
        # local refine: try to grow each square
        for _pass in range(3):
            for idx in range(n):
                x, y, a, s = cand[idx]
                if s <= 0:
                    continue
                for delta in (0.02, 0.01, 0.005):
                    ns = s + delta
                    if ns > 1.0:
                        continue
                    trial = (x, y, a, ns)
                    if not _inside_unit(trial):
                        continue
                    ok = True
                    for k in range(n):
                        if k == idx:
                            continue
                        if _overlap(trial, cand[k]):
                            ok = False
                            break
                    if ok:
                        cand[idx] = list(trial)
                        s = ns
                        break
        cur_sum = sum(s[3] for s in cand)
        if cur_sum > best_sum and _valid([tuple(c) for c in cand]):
            best_sum = cur_sum
            best = [tuple(c) for c in cand]
    return best


def solve(n):
    if n <= 0:
        return []
    # 1) choose best grid configuration
    best_sq = None
    best_score = -1.0
    for rows in range(1, int(math.sqrt(n)) + 3):
        for cols in range(1, n // max(rows, 1) + 2):
            if rows * cols > n:
                continue
            plan = _grid_plan(n, rows, cols)
            if plan is None:
                continue
            score = sum(s[3] for s in plan)
            if score > best_score:
                best_score = score
                best_sq = plan
    if best_sq is None:
        best_sq = _grid_plan(n, 1, 1)

    # 2) if there are leftover zero squares, try to fill them
    if sum(1 for s in best_sq if s[3] <= 0) > 0:
        refined = _greedy_fill(best_sq, n, trials=25)
        if sum(s[3] for s in refined) > best_score:
            best_sq = refined

    # ensure exact length
    best_sq = list(best_sq)[:n]
    while len(best_sq) < n:
        best_sq.append((0.5, 0.5, 0.0, 0.0))
    return best_sq
# EVOLVE-BLOCK-END
