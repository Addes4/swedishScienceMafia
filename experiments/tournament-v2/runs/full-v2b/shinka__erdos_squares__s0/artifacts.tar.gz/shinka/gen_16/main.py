# EVOLVE-BLOCK-START
"""Recursive guillotine DP packer for maximizing the sum of square side lengths.

Approach (fundamentally different from template-based packers):
  We recursively partition the unit square via guillotine cuts. At every free
  rectangle we either:
    (a) fill it with a uniform grid of squares, or
    (b) place a single square in a corner, or
    (c) split it by a horizontal or vertical cut and pack both halves.
  A memoized DP over states (w, h, k) -- discretized rectangle dimensions and
  square count -- finds the best sum of sides. This generalises every classic
  construction (grid, nested grid, corner L, two-corner L, multi-level L)
  without hard-coding them, and discovers new ones.
"""
import math
from functools import lru_cache


# Discretization: candidate side lengths are 1/i, and candidate cut positions
# are multiples of 1/i for i up to MAXD.
MAXD = 40


def _cands(n):
    """Candidate 1/i values for i in 1..max(n, MAXD)."""
    m = max(n, MAXD)
    return [1.0 / i for i in range(1, m + 1)]


def _grid_fill(w, h, k):
    """Fill rectangle w x h with up to k equal squares. Return (score, squares).

    Squares are placed in an a x b grid; side = min(w/a, h/b). We use
    min(a*b, k) squares (extras zero-size).
    """
    best_score = 0.0
    best = None
    for a in range(1, k + 1):
        for b in range(1, k + 1):
            side = min(w / a, h / b)
            if side <= 0:
                continue
            cnt = min(a * b, k)
            score = cnt * side
            if score > best_score:
                best_score = score
                best = (a, b, side, cnt)
    if best is None:
        return 0.0, []
    a, b, side, cnt = best
    squares = []
    for i in range(a):
        for j in range(b):
            if len(squares) >= cnt:
                break
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        if len(squares) >= cnt:
            break
    return best_score, squares


def _cut_positions(w, h, n):
    """Candidate cut fractions along w and h."""
    cs = set()
    for i in range(1, max(n, MAXD) + 1):
        f = 1.0 / i
        if 0.0 < f < 1.0:
            cs.add(f)
    return sorted(cs)


def _pack(w, h, k, depth):
    """Recursively pack rectangle w x h with up to k squares.

    Returns (score, squares) where squares are in local coords
    [0,w] x [0,h]. Uses guillotine cuts and uniform grids.
    """
    if k <= 0 or w <= 1e-12 or h <= 1e-12:
        return 0.0, []

    # Base: uniform grid fill.
    best_score, best_sq = _grid_fill(w, h, k)

    # Limit recursion depth to keep runtime bounded.
    if depth <= 0 or k <= 1:
        return best_score, best_sq

    # Try guillotine splits.
    cuts = _cut_positions(w, h, k)
    for f in cuts:
        # Vertical cut: left = w*f, right = w*(1-f)
        wl = w * f
        wr = w * (1.0 - f)
        for kl in range(1, k):
            kr = k - kl
            sl, sql = _pack(wl, h, kl, depth - 1)
            if sl <= 0:
                continue
            sr, sqr = _pack(wr, h, kr, depth - 1)
            if sl + sr > best_score:
                best_score = sl + sr
                shifted = list(sql) + [(x + wl, y, a, s) for (x, y, a, s) in sqr]
                best_sq = shifted
        # Horizontal cut: bottom = h*f, top = h*(1-f)
        hb = h * f
        ht = h * (1.0 - f)
        for kb in range(1, k):
            kt = k - kb
            sb, sqb = _pack(w, hb, kb, depth - 1)
            if sb <= 0:
                continue
            st, sqt = _pack(w, ht, kt, depth - 1)
            if sb + st > best_score:
                best_score = sb + st
                shifted = list(sqb) + [(x, y + hb, a, s) for (x, y, a, s) in sqt]
                best_sq = shifted

    return best_score, best_sq


def _dp_solve(n, depth=3):
    """Top-level: pack unit square with n squares via recursive DP."""
    score, squares = _pack(1.0, 1.0, n, depth)
    return score, squares


# --- simple fallback (used when DP yields little) -------------------------

def _grid_layout(n):
    best = None
    best_score = -1.0
    for a in range(1, n + 1):
        for b in range(1, n + 1):
            side = 1.0 / max(a, b)
            cnt = min(a * b, n)
            score = cnt * side
            if score > best_score:
                best_score = score
                best = (a, b, side)
    a, b, side = best
    squares = []
    for i in range(a):
        for j in range(b):
            if len(squares) >= n:
                break
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        if len(squares) >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _score(layout):
    return sum(sq[3] for sq in layout)


def _sanitize(layout, n):
    out = []
    for sq in layout[:n]:
        cx, cy, ang, side = sq
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        side = max(side, 0.0)
        out.append((cx, cy, ang, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out


def solve(n):
    """Generate recursive DP layout and pick best against grid fallback."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    candidates = []

    # Fallback grid.
    candidates.append(_grid_layout(n))

    # Recursive guillotine DP at increasing depths (bounded for 60s).
    # Depth 2 is fast; depth 3 adds more constructions. We cap total work.
    for depth in (2, 3):
        try:
            sc, sqs = _dp_solve(n, depth=depth)
            if sqs:
                # Pad to n and clamp into unit square.
                padded = list(sqs)
                while len(padded) < n:
                    padded.append((0.5, 0.5, 0.0, 0.0))
                candidates.append(padded[:n])
        except RecursionError:
            pass

    if not candidates:
        return _grid_layout(n)

    best = max(candidates, key=_score)
    return _sanitize(best, n)
# EVOLVE-BLOCK-END