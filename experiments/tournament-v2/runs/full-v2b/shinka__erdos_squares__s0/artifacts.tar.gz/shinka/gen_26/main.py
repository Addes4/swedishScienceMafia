# EVOLVE-BLOCK-START
"""Adaptive square packer: generate multiple layout candidates and pick the best.

Structure:
  - LayoutCandidate: dataclass-like tuple holding squares and score
  - grid_layout(n): best a x b grid layout (a*b <= n), extras are zero-size
  - mixed_layout(n): one large square + grid in remaining L-shaped region
  - greedy_layout(n): greedy largest-first placement in a guillotine partition
  - evaluate(layout): sum of sides (assumes validity by construction)
  - solve(n): orchestrates candidate generation and selection
"""
import math


def _grid_layout(n):
    """Best a x b grid; side = 1/max(a,b). Use min(a*b, n) cells, extras zero-size.

    Allowing a*b >= n lets us fill only n cells of a larger grid, which is
    strictly better in many cases (e.g. n=8: use 8 of 9 cells of a 3x3 grid,
    side 1/3, total 8/3 instead of the 2x4 grid's total 2).
    """
    best = None
    best_score = -1.0
    for a in range(1, n + 1):
        for b in range(1, n + 1):
            side = 1.0 / max(a, b)
            cnt = min(a * b, n)
            score = cnt * side
            if score > best_score:
                best_score = score
                best = (a, b, side)
    a, b, side = best
    squares = []
    for i in range(a):
        for j in range(b):
            if len(squares) >= n:
                break
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        if len(squares) >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _nested_layout(n):
    """k x k grid of side 1/k, with an m x m corner block subdivided into an
    a x b grid of smaller squares.

    Total squares used: k*k - m*m + a*b (must be <= n; extras zero-size).
    Score = (k*k - m*m)/k + a*b * (m/k)/max(a,b).

    This captures classic optimal constructions:
      n=6:  k=3,m=2,a=1,b=1 -> 5 + 1 squares, score 7/3
      n=7:  k=2,m=1,a=2,b=2 -> 3 + 4 squares, score 5/2
      n=13: k=4,m=2,a=1,b=1 -> 12 + 1 squares, score 7/2
    """
    best = None
    best_score = -1.0
    for k in range(2, n + 2):
        for m in range(1, k):
            base_cnt = k * k - m * m
            if base_cnt > n:
                continue
            for a in range(1, n + 1):
                for b in range(1, n + 1):
                    cnt = base_cnt + a * b
                    if cnt > n:
                        continue
                    s_big = 1.0 / k
                    s_small = (m * s_big) / max(a, b)
                    score = base_cnt * s_big + a * b * s_small
                    if score > best_score:
                        best_score = score
                        squares = []
                        # The subdivided m x m block in the bottom-left corner.
                        for i in range(a):
                            for j in range(b):
                                squares.append(((i + 0.5) * s_small,
                                                (j + 0.5) * s_small,
                                                0.0, s_small))
                        # Remaining full k x k cells.
                        for i in range(k):
                            for j in range(k):
                                if i < m and j < m:
                                    continue
                                squares.append(((i + 0.5) * s_big,
                                                (j + 0.5) * s_big,
                                                0.0, s_big))
                        while len(squares) < n:
                            squares.append((0.5, 0.5, 0.0, 0.0))
                        best = squares[:n]
    if best is None:
        return _grid_layout(n)
    return best


def _mixed_layout(n):
    """One large square of side s in a corner, plus a grid filling the rest.

    Try s = 1/k for various k, then fill the L-shaped remainder with a grid.
    """
    best = None
    best_score = -1.0
    # Try placing a large square of side s in bottom-left corner
    for k in range(2, n + 1):
        s = 1.0 / k
        if k > n:
            break
        remaining = n - 1
        if remaining <= 0:
            score = s
            if score > best_score:
                best_score = score
                best = [(s / 2, s / 2, 0.0, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
            continue
        # Fill remaining region: right strip of width (1-s) x 1, and top strip of width s x (1-s)
        # Right strip: place a column of squares of side (1-s)/m
        # Top strip: place a row of squares of side (1-s)/m
        # Try m columns in right strip and p rows in top strip
        for m in range(1, remaining + 1):
            for p in range(0, remaining - m + 1):
                if m + p > remaining:
                    continue
                # right strip: m squares stacked vertically, side width (1-s)/m?
                # Actually: right strip width (1-s), height 1. m squares of side (1-s)/m stacked.
                # top strip width s, height (1-s). p squares of side s/p? No, height (1-s).
                # Use side = min((1-s)/m, s/p) if p>0 else (1-s)/m
                if p > 0:
                    side2 = min((1.0 - s) / m, s / p)
                else:
                    side2 = (1.0 - s) / m
                if side2 <= 0:
                    continue
                score = s + (m + p) * side2
                if score > best_score:
                    best_score = score
                    squares = [(s / 2, s / 2, 0.0, s)]
                    # right strip squares
                    w = (1.0 - s) / m
                    for i in range(m):
                        cx = s + (i + 0.5) * w
                        cy = (i + 0.5) * (1.0 / m) if False else (i + 0.5) * (1.0 / m)
                        cy = (i + 0.5) * (1.0 / m)
                        squares.append((cx, cy, 0.0, min(w, 1.0 / m)))
                    # top strip squares
                    if p > 0:
                        h = (1.0 - s) / p
                        for j in range(p):
                            cx = (j + 0.5) * (s / p)
                            cy = s + (j + 0.5) * h
                            squares.append((cx, cy, 0.0, min(s / p, h)))
                    while len(squares) < n:
                        squares.append((0.5, 0.5, 0.0, 0.0))
                    best = squares[:n]
    if best is None:
        return _grid_layout(n)
    return best


def _greedy_layout(n):
    """Greedy: repeatedly split the largest free rectangle and place a square."""
    # Simple guillotine: start with unit square, place squares in a binary split tree.
    # Candidate: place squares of equal size in best a x b arrangement, but try
    # also one square slightly larger than grid side in a corner.
    best = None
    best_score = -1.0
    # Try: one square of side s, remaining n-1 in grid of a x b where a*b <= n-1
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem == 0:
            score = s
            if score > best_score:
                best_score = score
                best = [(s / 2, s / 2, 0.0, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
            continue
        # remaining squares in region [0,1-s] x [0,1] (left strip) or similar
        # Use grid in strip of width (1-s): a x b with a*b <= rem, side = min((1-s)/a, 1/b)
        for a in range(1, rem + 1):
            for b in range(1, rem + 1):
                if a * b > rem:
                    continue
                side2 = min((1.0 - s) / a, 1.0 / b)
                score = s + (a * b) * side2
                if score > best_score:
                    best_score = score
                    squares = [(s / 2, s / 2, 0.0, s)]
                    for i in range(a):
                        for j in range(b):
                            cx = s + (i + 0.5) * ((1.0 - s) / a)
                            cy = (j + 0.5) * (1.0 / b)
                            squares.append((cx, cy, 0.0, side2))
                    while len(squares) < n:
                        squares.append((0.5, 0.5, 0.0, 0.0))
                    best = squares[:n]
    if best is None:
        return _grid_layout(n)
    return best


def _corner_layout(n):
    """Place a large square in one corner and pack the L-shaped remainder with
    two rectangular grids (right strip and top strip), independently sized."""
    best = None
    best_score = -1.0
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem <= 0:
            score = s
            if score > best_score:
                best_score = score
                best = [(s / 2, s / 2, 0.0, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
            continue
        # right strip: width (1-s), height 1 -> m squares of side (1-s)/m
        # top strip: width s, height (1-s) -> p squares of side (1-s)/p?
        # Actually top strip height is (1-s), so p squares in a row: side = (1-s)/p
        # But width s limits: side <= s
        for m in range(1, rem + 1):
            for p in range(0, rem - m + 1):
                if m + p > rem:
                    continue
                side_r = (1.0 - s) / m
                side_t = (1.0 - s) / p if p > 0 else 0.0
                side_t = min(side_t, s) if p > 0 else 0.0
                side_r = min(side_r, 1.0)
                if p > 0 and side_t <= 0:
                    continue
                score = s + m * side_r + p * side_t
                if score > best_score:
                    best_score = score
                    squares = [(s / 2, s / 2, 0.0, s)]
                    for i in range(m):
                        cx = s + (i + 0.5) * ((1.0 - s) / m)
                        cy = (i + 0.5) * (1.0 / m)
                        squares.append((cx, cy, 0.0, side_r))
                    if p > 0:
                        for j in range(p):
                            cx = (j + 0.5) * (s / p)
                            cy = s + (j + 0.5) * ((1.0 - s) / p)
                            squares.append((cx, cy, 0.0, side_t))
                    while len(squares) < n:
                        squares.append((0.5, 0.5, 0.0, 0.0))
                    best = squares[:n]
    if best is None:
        return _grid_layout(n)
    return best


def _two_corner_layout(n):
    """Place a big square of side 1/k in the bottom-left corner, then pack the
    right strip (width 1-1/k, height 1) with m squares of side r_s and the top
    strip (width 1/k, height 1-1/k) with p squares of side t_s, allowing the
    two strip grid sizes to differ.

    This is a strict generalisation of `_mixed_layout` and `_corner_layout`:
    it explores independent side lengths for the right and top strips, which
    is what the classic optimal constructions for n=11..15 exploit.

    Score = 1/k + m*r_s + p*t_s, with m + p + 1 <= n (extras zero-size).
    Constraints:
      right strip: width (1-1/k), height 1
         -> m squares stacked vertically: r_s <= min((1-1/k), 1/m)
      top strip:   width 1/k, height (1-1/k)
         -> p squares in a row: t_s <= min(1/k, (1-1/k)/p)
    """
    best = None
    best_score = -1.0
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem <= 0:
            if s > best_score:
                best_score = s
                best = [(s / 2, s / 2, 0.0, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
            continue
        for m in range(0, rem + 1):
            for p in range(0, rem - m + 1):
                if m + p > rem:
                    continue
                r_s = 0.0
                if m > 0:
                    r_s = min(1.0 - s, 1.0 / m)
                t_s = 0.0
                if p > 0:
                    t_s = min(s, (1.0 - s) / p)
                if m > 0 and r_s <= 0:
                    continue
                if p > 0 and t_s <= 0:
                    continue
                score = s + m * r_s + p * t_s
                if score > best_score:
                    best_score = score
                    squares = [(s / 2, s / 2, 0.0, s)]
                    # right strip: column of m squares of side r_s
                    for i in range(m):
                        cx = s + r_s / 2
                        cy = (i + 0.5) * (1.0 / m)
                        squares.append((cx, cy, 0.0, r_s))
                    # top strip: row of p squares of side t_s
                    for j in range(p):
                        cx = (j + 0.5) * (s / p) if p > 0 else 0.0
                        cx = (j + 0.5) * (s / p)
                        cy = s + t_s / 2
                        squares.append((cx, cy, 0.0, t_s))
                    while len(squares) < n:
                        squares.append((0.5, 0.5, 0.0, 0.0))
                    best = squares[:n]
    if best is None:
        return _grid_layout(n)
    return best


def _two_corner_layout_tr(n):
    """Chiral mirror of `_two_corner_layout`: reflect the packing through the
    centre of the unit square (x -> 1-x, y -> 1-y). This maps a valid packing
    to another valid packing with identical side lengths, but places the big
    square in the top-right corner and swaps the strip orientations. For
    asymmetric optimal layouts, one chirality may win over the other.
    """
    base = _two_corner_layout(n)
    mirrored = []
    for cx, cy, ang, side in base:
        mirrored.append((1.0 - cx, 1.0 - cy, ang, side))
    return mirrored


def _refine_big_side(n, s):
    """Analytically optimise the two-corner layout for a *fixed* big-square
    side `s` (not necessarily of the form 1/k).

    A big square of side s sits in the bottom-left corner. The right strip
    (width 1-s, height 1) is filled with m squares of side r_s <= min(1-s, 1/m);
    the top strip (width s, height 1-s) is filled with p squares of side
    t_s <= min(s, (1-s)/p). We enumerate m, p with m + p + 1 <= n and pick the
    best score s + m*r_s + p*t_s. Returns (score, layout) or (-1, None).
    """
    if s <= 0.0 or s >= 1.0:
        return -1.0, None
    rem = n - 1
    if rem <= 0:
        return s, [(s / 2, s / 2, 0.0, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
    best_score = -1.0
    best = None
    for m in range(0, rem + 1):
        if m > 0:
            r_s = min(1.0 - s, 1.0 / m)
        else:
            r_s = 0.0
        for p in range(0, rem - m + 1):
            if p > 0:
                t_s = min(s, (1.0 - s) / p)
            else:
                t_s = 0.0
            score = s + m * r_s + p * t_s
            if score > best_score:
                best_score = score
                squares = [(s / 2, s / 2, 0.0, s)]
                for i in range(m):
                    cx = s + r_s / 2
                    cy = (i + 0.5) * (1.0 / m)
                    squares.append((cx, cy, 0.0, r_s))
                for j in range(p):
                    cx = (j + 0.5) * (s / p) if p > 0 else 0.0
                    cy = s + t_s / 2
                    squares.append((cx, cy, 0.0, t_s))
                while len(squares) < n:
                    squares.append((0.5, 0.5, 0.0, 0.0))
                best = squares[:n]
    return best_score, best


def _portfolio_refine(n, candidates):
    """Refinement pass: for the top-2 scoring candidates, recover the big-square
    side s (the largest square in the layout) and analytically re-solve the
    two-corner strip packing for a small analytic grid of s-values around s and
    around 1/k. Returns the best refined layout, or None.
    """
    if n <= 1:
        return None
    scored = sorted(candidates, key=_score, reverse=True)
    seeds = []
    for cand in scored[:2]:
        if not cand:
            continue
        big = max(cand, key=lambda sq: sq[3])
        s0 = big[3]
        if s0 <= 0.0:
            continue
        # Recover integer k if s0 ~ 1/k.
        k0 = None
        if s0 > 0:
            k_est = round(1.0 / s0)
            if k_est >= 1 and abs(1.0 / k_est - s0) < 1e-6:
                k0 = k_est
        s_values = set()
        s_values.add(s0)
        if k0 is not None:
            for dk in (-1, 1):
                kk = k0 + dk
                if kk >= 1:
                    s_values.add(1.0 / kk)
            for kk in range(max(1, k0 - 3), k0 + 4):
                s_values.add(1.0 / kk)
        # Fine uniform scan around s0 and over (0, 1].
        for t in range(1, 31):
            s_values.add(t / 31.0)
        # Local refinement around s0.
        for d in range(-5, 6):
            v = s0 + d * 0.005
            if 0.0 < v < 1.0:
                s_values.add(v)
        best_score = -1.0
        best_layout = None
        for s in s_values:
            sc, lay = _refine_big_side(n, s)
            if lay is not None and sc > best_score:
                best_score = sc
                best_layout = lay
        if best_layout is not None:
            seeds.append(best_layout)
    if not seeds:
        return None
    return max(seeds, key=_score)


def _score(layout):
    return sum(sq[3] for sq in layout)
=======


def _sanitize(layout, n):
    """Clamp to [0,1] and ensure n squares."""
    out = []
    for sq in layout[:n]:
        cx, cy, ang, side = sq
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        side = max(side, 0.0)
        out.append((cx, cy, ang, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out


def solve(n):
    """Generate candidates, pick the best-scoring layout."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    candidates = [
        _grid_layout(n),
        _nested_layout(n),
        _asym_nested_layout(n),
        _mixed_layout(n),
        _greedy_layout(n),
        _corner_layout(n),
        _two_corner_layout(n),
        _two_corner_layout_tr(n),
    ]
    best = max(candidates, key=_score)
    # Cheap portfolio-level refinement: perturb the big-square side around the
    # best candidates and re-solve the strip counts analytically. The original
    # `best` stays in the pool, so the score can never regress.
    refined = _portfolio_refine(n, candidates)
    if refined is not None and _score(refined) > _score(best):
        best = refined
    return _sanitize(best, n)
# EVOLVE-BLOCK-END