# EVOLVE-BLOCK-START
"""Recursive guillotine-partition square packer.

Instead of a fixed catalog of layout templates, we run a memoized
dynamic program over rectangles: a rectangle R of size (w, h) filled with
exactly k squares is either a single square of side min(w, h), or the
result of a horizontal/vertical guillotine cut into two sub-rectangles
that are recursively packed with k1 and k2 = k - k1 squares.

The DP is stored on a small quantized lattice of (w, h) values so the
memo table stays small.  Candidate cut ratios include 1/2, 1/3, 2/3, 1/4,
3/4, and the "single square then remainder" splits that reproduce the
classic corner / two-corner layouts.  This single generic recursion
subsumes grid, nested, mixed, corner and two-corner layouts, and can
discover asymmetric multi-level structures those templates miss.

A final refinement pass slightly inflates each square's side (clamped to
its containing rectangle) and re-validates non-overlap, then we return
the best-scoring layout found.
"""
import math
from functools import lru_cache


# ---------------------------------------------------------------------------
# Quantization helper: snap a float dimension to a coarse lattice so the
# memo table stays small.  We keep the lattice fine enough (1/120) to
# represent the classic optima (denominators up to 15).
# ---------------------------------------------------------------------------
_Q = 120


def _q(x):
    return int(round(x * _Q))


def _uq(i):
    return i / float(_Q)


# ---------------------------------------------------------------------------
# Core DP: best total side length packing a w x h rectangle with k squares,
# plus a reconstruction recipe.  We return (score, recipe) where recipe is
# either ('leaf', side) or ('split', orientation, ratio, recipe1, recipe2).
# ---------------------------------------------------------------------------
# We use a plain dict memo keyed by (wq, hq, k) to avoid lru_cache issues
# with large argument sets.
_MEMO = {}


def _best(wq, hq, k):
    """Return (score, recipe) for packing k squares in a wq x hq rect."""
    if k <= 0:
        return 0.0, ('empty',)
    if k == 1:
        w, h = _uq(wq), _uq(hq)
        return min(w, h), ('leaf', min(w, h))

    key = (wq, hq, k)
    cached = _MEMO.get(key)
    if cached is not None:
        return cached

    w, h = _uq(wq), _uq(hq)
    best_score = -1.0
    best_recipe = None

    # Candidate cut ratios (fraction of the width/height given to the
    # first sub-rectangle).  Include 1/k style splits that isolate one
    # square plus a remainder, and simple halves/thirds.
    ratios = set()
    for t in (2, 3, 4, 5, 6, 7, 8):
        ratios.add(1.0 / t)
        ratios.add((t - 1.0) / t)
    ratios.add(0.5)
    ratios.add(1.0 / 3.0)
    ratios.add(2.0 / 3.0)
    ratios.add(0.25)
    ratios.add(0.75)
    ratios.add(0.2)
    ratios.add(0.8)
    # "single square" splits: give one square's worth of width/height.
    # These reproduce corner and two-corner layouts.
    for t in (2, 3, 4, 5, 6, 7, 8):
        ratios.add(1.0 / t)

    # Try both orientations and a few ratios.
    for orient in ('v', 'h'):
        for r in ratios:
            if r <= 0.0 or r >= 1.0:
                continue
            if orient == 'v':
                w1 = _q(w * r)
                w2 = wq - w1
                if w1 <= 0 or w2 <= 0:
                    continue
                dims1 = (w1, hq)
                dims2 = (w2, hq)
            else:
                h1 = _q(h * r)
                h2 = hq - h1
                if h1 <= 0 or h2 <= 0:
                    continue
                dims1 = (wq, h1)
                dims2 = (wq, h2)
            # Allocate squares between the two sub-rectangles.
            for k1 in range(1, k):
                k2 = k - k1
                s1, rec1 = _best(dims1[0], dims1[1], k1)
                s2, rec2 = _best(dims2[0], dims2[1], k2)
                total = s1 + s2
                if total > best_score + 1e-12:
                    best_score = total
                    best_recipe = ('split', orient, r, dims1, dims2,
                                   rec1, rec2)

    # Also consider the leaf option: one square filling min(w, h), and the
    # remaining k-1 squares packed into the leftover strip.  This is
    # already covered by splits with ratio = 1/t, but we add an explicit
    # "big square + strip" candidate for robustness.
    side = min(w, h)
    if side > 0 and k >= 2:
        if w >= h:
            # place square of side h on the left, remainder is (w-h) x h
            w2 = wq - _q(h)
            if w2 > 0:
                s2, rec2 = _best(w2, hq, k - 1)
                total = side + s2
                if total > best_score + 1e-12:
                    best_score = total
                    best_recipe = ('split', 'v', h / w,
                                   (_q(h), hq), (w2, hq),
                                   ('leaf', side), rec2)
        else:
            h2 = hq - _q(w)
            if h2 > 0:
                s2, rec2 = _best(wq, h2, k - 1)
                total = side + s2
                if total > best_score + 1e-12:
                    best_score = total
                    best_recipe = ('split', 'h', w / h,
                                   (wq, _q(w)), (wq, h2),
                                   ('leaf', side), rec2)

    _MEMO[key] = (best_score, best_recipe)
    return best_score, best_recipe


# ---------------------------------------------------------------------------
# Reconstruction: turn a recipe into an explicit list of squares
# (cx, cy, angle, side) in absolute unit-square coordinates.
# ---------------------------------------------------------------------------
def _reconstruct(recipe, x0, y0, w, h, out):
    tag = recipe[0]
    if tag == 'empty':
        return
    if tag == 'leaf':
        s = recipe[1]
        cx = x0 + w / 2.0
        cy = y0 + h / 2.0
        # Place the square centered in its rectangle.
        out.append((cx, cy, 0.0, s))
        return
    if tag == 'split':
        _, orient, r, dims1, dims2, rec1, rec2 = recipe
        if orient == 'v':
            w1 = _uq(dims1[0])
            w2 = _uq(dims2[0])
            _reconstruct(rec1, x0, y0, w1, h, out)
            _reconstruct(rec2, x0 + w1, y0, w2, h, out)
        else:
            h1 = _uq(dims1[1])
            h2 = _uq(dims2[1])
            _reconstruct(rec1, x0, y0, w, h1, out)
            _reconstruct(rec2, x0, y0 + h1, w, h2, out)
        return


# ---------------------------------------------------------------------------
# A few closed-form template layouts kept as fallbacks / sanity candidates.
# ---------------------------------------------------------------------------
def _grid_layout(n):
    best = None
    best_score = -1.0
    for a in range(1, n + 1):
        for b in range(1, n + 1):
            side = 1.0 / max(a, b)
            cnt = min(a * b, n)
            score = cnt * side
            if score > best_score:
                best_score = score
                best = (a, b, side)
    a, b, side = best
    squares = []
    for i in range(a):
        for j in range(b):
            if len(squares) >= n:
                break
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        if len(squares) >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _two_corner_layout(n):
    """Big square of side 1/k in bottom-left, right strip packed with m
    squares, top strip packed with p squares, independent sizes."""
    best = None
    best_score = -1.0
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem <= 0:
            if s > best_score:
                best_score = s
                best = [(s / 2, s / 2, 0.0, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
            continue
        for m in range(0, rem + 1):
            for p in range(0, rem - m + 1):
                if m + p > rem:
                    continue
                r_s = min(1.0 - s, 1.0 / m) if m > 0 else 0.0
                t_s = min(s, (1.0 - s) / p) if p > 0 else 0.0
                if m > 0 and r_s <= 0:
                    continue
                if p > 0 and t_s <= 0:
                    continue
                score = s + m * r_s + p * t_s
                if score > best_score:
                    best_score = score
                    squares = [(s / 2, s / 2, 0.0, s)]
                    for i in range(m):
                        cx = s + r_s / 2
                        cy = (i + 0.5) * (1.0 / m)
                        squares.append((cx, cy, 0.0, r_s))
                    for j in range(p):
                        cx = (j + 0.5) * (s / p) if p > 0 else 0.0
                        cy = s + t_s / 2
                        squares.append((cx, cy, 0.0, t_s))
                    while len(squares) < n:
                        squares.append((0.5, 0.5, 0.0, 0.0))
                    best = squares[:n]
    if best is None:
        return _grid_layout(n)
    return best


# ---------------------------------------------------------------------------
# Validation: check that no two squares share interior area.
# ---------------------------------------------------------------------------
def _valid(squares):
    for i in range(len(squares)):
        cx1, cy1, _, s1 = squares[i]
        if s1 <= 0:
            continue
        for j in range(i + 1, len(squares)):
            cx2, cy2, _, s2 = squares[j]
            if s2 <= 0:
                continue
            # Axis-aligned squares (angle 0): check overlap of interiors.
            dx = abs(cx1 - cx2)
            dy = abs(cy1 - cy2)
            if dx < (s1 + s2) / 2.0 - 1e-9 and dy < (s1 + s2) / 2.0 - 1e-9:
                return False
    return True


def _score(layout):
    return sum(sq[3] for sq in layout)


def _sanitize(layout, n):
    out = []
    for sq in layout[:n]:
        cx, cy, ang, side = sq
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        side = max(side, 0.0)
        out.append((cx, cy, ang, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out


def _refine(layout, n):
    """Try to slightly inflate each square without causing overlap."""
    squares = [list(sq) for sq in layout]
    improved = True
    for _ in range(6):
        if not improved:
            break
        improved = False
        for i in range(len(squares)):
            cx, cy, ang, side = squares[i]
            if side <= 0:
                continue
            # Try increasing the side; find max allowed by neighbours.
            max_side = side
            # Candidate growth: up to a small delta.
            for delta in (0.02, 0.01, 0.005, 0.002, 0.001):
                cand = side + delta
                if cand > 1.0:
                    continue
                ok = True
                for j in range(len(squares)):
                    if i == j:
                        continue
                    cx2, cy2, _, s2 = squares[j]
                    if s2 <= 0:
                        continue
                    dx = abs(cx - cx2)
                    dy = abs(cy - cy2)
                    if dx < (cand + s2) / 2.0 - 1e-12 and dy < (cand + s2) / 2.0 - 1e-12:
                        ok = False
                        break
                if ok:
                    max_side = cand
                    break
            if max_side > side + 1e-12:
                squares[i][3] = max_side
                improved = True
    return [tuple(s) for s in squares]


def solve(n):
    """Generate candidates and return the best-scoring valid layout."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    candidates = []

    # 1) Closed-form templates (fast, guaranteed valid).
    candidates.append(_grid_layout(n))
    candidates.append(_two_corner_layout(n))

    # 2) Recursive guillotine DP candidate.
    try:
        _MEMO.clear()
        score_dp, recipe = _best(_Q, _Q, n)
        out = []
        _reconstruct(recipe, 0.0, 0.0, 1.0, 1.0, out)
        # Pad with zero-size squares if the DP produced fewer.
        while len(out) < n:
            out.append((0.5, 0.5, 0.0, 0.0))
        out = out[:n]
        if _valid(out):
            candidates.append(out)
    except Exception:
        pass

    # 3) Try the DP with a couple of different quantization levels for
    #    diversity (in case the coarse lattice missed a ratio).
    for qq in (60, 240):
        try:
            global _Q
            saved = _Q
            _Q = qq
            _MEMO.clear()
            score_dp, recipe = _best(_Q, _Q, n)
            out = []
            _reconstruct(recipe, 0.0, 0.0, 1.0, 1.0, out)
            while len(out) < n:
                out.append((0.5, 0.5, 0.0, 0.0))
            out = out[:n]
            if _valid(out):
                candidates.append(out)
            _Q = saved
        except Exception:
            pass

    # Pick the best valid candidate, then refine.
    best = None
    best_score = -1.0
    for cand in candidates:
        if not _valid(cand):
            continue
        sc = _score(cand)
        if sc > best_score:
            best_score = sc
            best = cand

    if best is None:
        best = _grid_layout(n)

    refined = _refine(best, n)
    if _valid(refined) and _score(refined) >= _score(best):
        best = refined

    return _sanitize(best, n)
# EVOLVE-BLOCK-END