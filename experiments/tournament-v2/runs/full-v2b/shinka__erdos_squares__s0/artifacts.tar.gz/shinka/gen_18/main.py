# EVOLVE-BLOCK-START
"""Stochastic square packer: seed from structured layouts, then refine with
simulated annealing on (cx, cy, angle, side) tuples using an adaptive overlap
penalty. Returns the best valid packing found.

This is a fundamentally different strategy from enumerated layout families:
the search is continuous, the constraint is a soft penalty that tightens over
time, and the final step projects any residual overlap away by shrinking the
offending squares. It is fully generic in n.
"""
import math
import random


# ---------- basic geometry ----------

def _corners(cx, cy, ang, side):
    """Return the 4 corners of a square (fraction of turn for angle)."""
    h = side * 0.5
    c = math.cos(2.0 * math.pi * ang)
    s = math.sin(2.0 * math.pi * ang)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + c * dx - s * dy, cy + s * dx + c * dy))
    return pts


def _sat_overlap(a, b):
    """Overlap area (approximate via separating-axis on the AABB of the
    rotated squares). Cheap and monotone enough for annealing."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    # axis-aligned bounding half-extents of each rotated square
    ca = abs(math.cos(2.0 * math.pi * aa)) + abs(math.sin(2.0 * math.pi * aa))
    cb = abs(math.cos(2.0 * math.pi * ba)) + abs(math.sin(2.0 * math.pi * ba))
    ha = asz * 0.5 * ca
    hb = bsz * 0.5 * cb
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ox = ha + hb - dx
    oy = ha + hb - dy
    if ox <= 0.0 or oy <= 0.0:
        return 0.0
    return ox * oy


def _out_of_bounds(sq):
    """Penalty mass for a square sticking out of [0,1]^2."""
    cx, cy, ang, side = sq
    h = side * 0.5
    c = abs(math.cos(2.0 * math.pi * ang)) + abs(math.sin(2.0 * math.pi * ang))
    half = h * c
    p = 0.0
    if cx - half < 0.0:
        p += (half - cx)
    if cx + half > 1.0:
        p += (cx + half - 1.0)
    if cy - half < 0.0:
        p += (half - cy)
    if cy + half > 1.0:
        p += (cy + half - 1.0)
    return p


def _total_penalty(layout):
    pen = 0.0
    n = len(layout)
    for i in range(n):
        pen += _out_of_bounds(layout[i])
    for i in range(n):
        for j in range(i + 1, n):
            pen += _sat_overlap(layout[i], layout[j])
    return pen


def _objective(layout, lam):
    score = sum(sq[3] for sq in layout)
    return score - lam * _total_penalty(layout)


# ---------- seeds ----------

def _grid_seed(n):
    best = None
    best_score = -1.0
    for a in range(1, n + 1):
        for b in range(1, n + 1):
            side = 1.0 / max(a, b)
            cnt = min(a * b, n)
            sc = cnt * side
            if sc > best_score:
                best_score = sc
                best = (a, b, side)
    a, b, side = best
    out = []
    for i in range(a):
        for j in range(b):
            if len(out) >= n:
                break
            out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        if len(out) >= n:
            break
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _corner_seed(n):
    """One big square in a corner plus a column/row grid in the L."""
    best = None
    best_score = -1.0
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem <= 0:
            if s > best_score:
                best_score = s
                best = [(s / 2, s / 2, 0.0, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
            continue
        for m in range(0, rem + 1):
            for p in range(0, rem - m + 1):
                if m + p > rem:
                    continue
                r_s = min(1.0 - s, 1.0 / m) if m > 0 else 0.0
                t_s = min(s, (1.0 - s) / p) if p > 0 else 0.0
                sc = s + m * r_s + p * t_s
                if sc > best_score:
                    best_score = sc
                    sq = [(s / 2, s / 2, 0.0, s)]
                    for i in range(m):
                        sq.append((s + r_s / 2, (i + 0.5) / m, 0.0, r_s))
                    for j in range(p):
                        sq.append(((j + 0.5) * (s / p) if p > 0 else 0.0,
                                   s + t_s / 2, 0.0, t_s))
                    while len(sq) < n:
                        sq.append((0.5, 0.5, 0.0, 0.0))
                    best = sq[:n]
    if best is None:
        return _grid_seed(n)
    return best


def _nested_seed(n):
    best = None
    best_score = -1.0
    for k in range(2, n + 2):
        for m in range(1, k):
            base_cnt = k * k - m * m
            if base_cnt > n:
                continue
            for a in range(1, n + 1):
                for b in range(1, n + 1):
                    cnt = base_cnt + a * b
                    if cnt > n:
                        continue
                    s_big = 1.0 / k
                    s_small = (m * s_big) / max(a, b)
                    sc = base_cnt * s_big + a * b * s_small
                    if sc > best_score:
                        best_score = sc
                        sq = []
                        for i in range(a):
                            for j in range(b):
                                sq.append(((i + 0.5) * s_small,
                                           (j + 0.5) * s_small, 0.0, s_small))
                        for i in range(k):
                            for j in range(k):
                                if i < m and j < m:
                                    continue
                                sq.append(((i + 0.5) * s_big,
                                           (j + 0.5) * s_big, 0.0, s_big))
                        while len(sq) < n:
                            sq.append((0.5, 0.5, 0.0, 0.0))
                        best = sq[:n]
    if best is None:
        return _grid_seed(n)
    return best


# ---------- annealing ----------

def _anneal(seed, n, iters=4000, rng=None):
    if rng is None:
        rng = random.Random(12345 + n)
    layout = [list(sq) for sq in seed]
    lam = 2.0
    cur = _objective(layout, lam)
    best = [list(sq) for sq in layout]
    best_score = sum(sq[3] for sq in layout)
    best_pen = _total_penalty(layout)
    T0 = 0.05
    for it in range(iters):
        T = T0 * (1.0 - it / iters) + 1e-4
        # adaptive lambda: if penalty is high, raise it
        if it % 50 == 0:
            pen = _total_penalty(layout)
            lam *= 1.0 + 0.05 * (pen > 1e-6)
            lam = min(lam, 1e6)
        i = rng.randrange(n)
        old = layout[i][:]
        # choose a move type
        m = rng.random()
        cx, cy, ang, side = old
        if m < 0.45:
            # resize
            side = max(0.0, side + rng.gauss(0.0, 0.02))
        elif m < 0.75:
            # move
            cx += rng.gauss(0.0, 0.02)
            cy += rng.gauss(0.0, 0.02)
        elif m < 0.9:
            # rotate
            ang += rng.gauss(0.0, 0.02)
        else:
            # combined
            side = max(0.0, side + rng.gauss(0.0, 0.015))
            cx += rng.gauss(0.0, 0.01)
            cy += rng.gauss(0.0, 0.01)
        layout[i] = [cx, cy, ang, side]
        new = _objective(layout, lam)
        if new >= cur or rng.random() < math.exp((new - cur) / max(T, 1e-9)):
            cur = new
            pen = _total_penalty(layout)
            sc = sum(sq[3] for sq in layout)
            if pen < 1e-9 and sc > best_score:
                best_score = sc
                best = [list(sq) for sq in layout]
                best_pen = pen
        else:
            layout[i] = old
    return best


def _shrink_to_valid(layout):
    """Greedily shrink squares that overlap until the packing is valid."""
    layout = [list(sq) for sq in layout]
    n = len(layout)
    for _ in range(200):
        pen = _total_penalty(layout)
        if pen < 1e-9:
            break
        # find worst overlapping pair, shrink the smaller
        worst = None
        worst_ov = 0.0
        for i in range(n):
            for j in range(i + 1, n):
                ov = _sat_overlap(layout[i], layout[j])
                if ov > worst_ov:
                    worst_ov = ov
                    worst = (i, j)
        if worst is None:
            # out of bounds only
            for i in range(n):
                if _out_of_bounds(layout[i]) > 0:
                    layout[i][0] = min(max(layout[i][0], 0.0), 1.0)
                    layout[i][1] = min(max(layout[i][1], 0.0), 1.0)
            continue
        i, j = worst
        if layout[i][3] <= layout[j][3]:
            layout[i][3] *= 0.9
        else:
            layout[j][3] *= 0.9
    # final clamp
    for sq in layout:
        sq[0] = min(max(sq[0], 0.0), 1.0)
        sq[1] = min(max(sq[1], 0.0), 1.0)
        sq[3] = max(sq[3], 0.0)
    return layout


def _score(layout):
    return sum(sq[3] for sq in layout)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    seeds = [_grid_seed(n), _corner_seed(n), _nested_seed(n)]
    best = None
    best_score = -1.0
    for s_idx, seed in enumerate(seeds):
        rng = random.Random(1000 * s_idx + n)
        cand = _anneal(seed, n, iters=3000, rng=rng)
        cand = _shrink_to_valid(cand)
        sc = _score(cand)
        if sc > best_score:
            best_score = sc
            best = cand

    # also keep the raw best seed as a fallback
    for seed in seeds:
        sc = _score(seed)
        if sc > best_score:
            best_score = sc
            best = [list(sq) for sq in seed]

    out = []
    for sq in best[:n]:
        out.append((float(sq[0]), float(sq[1]), float(sq[2]), float(sq[3])))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
# EVOLVE-BLOCK-END