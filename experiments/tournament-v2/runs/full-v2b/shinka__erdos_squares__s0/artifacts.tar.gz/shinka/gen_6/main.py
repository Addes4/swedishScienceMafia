# EVOLVE-BLOCK-START
"""Adaptive square packer with rotation and recursive strip packing.

Structure:
  - _grid_layout(n): best a x b grid
  - _strip_pack(width, height, count): place count equal squares in a rectangle
  - _corner_layout(n): large square + two strips (right, top)
  - _rotated_layout(n): rotated large square + packed triangles/strips
  - _recursive_layout(n): recursive guillotine partition
  - _partition_search(n): brute-force integer partitions for small n
  - _score(layout): sum of sides
  - solve(n): orchestrate candidates, pick best, sanitize
"""
import math
from itertools import product


def _grid_layout(n):
    best = None
    best_score = -1.0
    for a in range(1, n + 1):
        for b in range(1, n + 1):
            if a * b > n:
                continue
            side = 1.0 / max(a, b)
            score = (a * b) * side
            if score > best_score:
                best_score = score
                best = (a, b, side)
    a, b, side = best
    squares = []
    for i in range(a):
        for j in range(b):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _strip_pack(width, height, count, x0=0.0, y0=0.0):
    """Place `count` equal squares inside rectangle [x0,x0+width] x [y0,y0+height].
    Returns list of (cx, cy, 0.0, side). Uses best a x b arrangement."""
    if count <= 0 or width <= 0 or height <= 0:
        return []
    best = None
    best_score = -1.0
    for a in range(1, count + 1):
        for b in range(1, count + 1):
            if a * b > count:
                continue
            side = min(width / a, height / b)
            score = (a * b) * side
            if score > best_score:
                best_score = score
                best = (a, b, side)
    a, b, side = best
    squares = []
    for i in range(a):
        for j in range(b):
            cx = x0 + (i + 0.5) * (width / a)
            cy = y0 + (j + 0.5) * (height / b)
            squares.append((cx, cy, 0.0, side))
    return squares


def _corner_layout(n):
    """Large square in bottom-left + right strip + top strip."""
    best = None
    best_score = -1.0
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem <= 0:
            score = s
            if score > best_score:
                best_score = score
                best = [(s / 2, s / 2, 0.0, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
            continue
        for m in range(1, rem + 1):
            for p in range(0, rem - m + 1):
                if m + p > rem:
                    continue
                side_r = (1.0 - s) / m
                side_t = (1.0 - s) / p if p > 0 else 0.0
                side_t = min(side_t, s) if p > 0 else 0.0
                if p > 0 and side_t <= 0:
                    continue
                score = s + m * side_r + p * side_t
                if score > best_score:
                    best_score = score
                    squares = [(s / 2, s / 2, 0.0, s)]
                    for i in range(m):
                        cx = s + (i + 0.5) * ((1.0 - s) / m)
                        cy = (i + 0.5) * (1.0 / m)
                        squares.append((cx, cy, 0.0, side_r))
                    if p > 0:
                        for j in range(p):
                            cx = (j + 0.5) * (s / p)
                            cy = s + (j + 0.5) * ((1.0 - s) / p)
                            squares.append((cx, cy, 0.0, side_t))
                    while len(squares) < n:
                        squares.append((0.5, 0.5, 0.0, 0.0))
                    best = squares[:n]
    if best is None:
        return _grid_layout(n)
    return best


def _rotated_layout(n):
    """Rotated large square (45 deg) in bottom-left; pack remaining region with
    axis-aligned strips. The rotated square of side s has bounding box s*sqrt(2).
    Remaining region is the unit square minus the rotated square (a set of
    triangles/strips approximated by axis-aligned rectangles)."""
    best = None
    best_score = -1.0
    sqrt2 = math.sqrt(2.0)
    for k in range(2, n + 1):
        s = 1.0 / k
        bbox = s * sqrt2
        if bbox > 1.0:
            continue
        rem = n - 1
        if rem <= 0:
            score = s
            if score > best_score:
                best_score = score
                best = [(0.5, 0.5, 0.125, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
            continue
        # Place rotated square centered at (0.5, 0.5) if it fits, else near corner.
        # Use center (0.5, 0.5) and pack the four corner triangles with small squares.
        # Approximate: fill four corner regions with axis-aligned squares of side
        # (1 - bbox)/2 in each corner, plus optional strips.
        corner_side = (1.0 - bbox) / 2.0
        if corner_side <= 0:
            continue
        # Four corner squares
        corners = [
            (corner_side / 2, corner_side / 2),
            (1.0 - corner_side / 2, corner_side / 2),
            (corner_side / 2, 1.0 - corner_side / 2),
            (1.0 - corner_side / 2, 1.0 - corner_side / 2),
        ]
        # Try to distribute remaining squares among the four corner regions and
        # side strips. Simplify: put up to 4 corner squares, then fill strips.
        for n_corners in range(0, min(4, rem) + 1):
            rem2 = rem - n_corners
            # side strips: top and bottom strips of width 1, height corner_side
            # and left/right strips of width corner_side, height 1 - 2*corner_side
            # Use two strips: bottom strip height corner_side, top strip height corner_side
            for m_bot in range(0, rem2 + 1):
                for m_top in range(0, rem2 - m_bot + 1):
                    m_left = rem2 - m_bot - m_top
                    # bottom strip: width 1, height corner_side
                    side_bot = min(1.0 / max(m_bot, 1), corner_side) if m_bot > 0 else 0.0
                    side_top = min(1.0 / max(m_top, 1), corner_side) if m_top > 0 else 0.0
                    # left strip: width corner_side, height 1 - 2*corner_side
                    side_left = min(corner_side, (1.0 - 2 * corner_side) / max(m_left, 1)) if m_left > 0 else 0.0
                    score = s + n_corners * corner_side + m_bot * side_bot + m_top * side_top + m_left * side_left
                    if score > best_score:
                        best_score = score
                        squares = [(0.5, 0.5, 0.125, s)]
                        for idx in range(n_corners):
                            cx, cy = corners[idx]
                            squares.append((cx, cy, 0.0, corner_side))
                        # bottom strip
                        if m_bot > 0:
                            for i in range(m_bot):
                                cx = (i + 0.5) * (1.0 / m_bot)
                                cy = corner_side / 2
                                squares.append((cx, cy, 0.0, side_bot))
                        # top strip
                        if m_top > 0:
                            for i in range(m_top):
                                cx = (i + 0.5) * (1.0 / m_top)
                                cy = 1.0 - corner_side / 2
                                squares.append((cx, cy, 0.0, side_top))
                        # left strip
                        if m_left > 0:
                            for i in range(m_left):
                                cx = corner_side / 2
                                cy = corner_side + (i + 0.5) * ((1.0 - 2 * corner_side) / m_left)
                                squares.append((cx, cy, 0.0, side_left))
                        while len(squares) < n:
                            squares.append((0.5, 0.5, 0.0, 0.0))
                        best = squares[:n]
    if best is None:
        return _grid_layout(n)
    return best


def _recursive_layout(n):
    """Recursive guillotine: split unit square into two rectangles, pack each
    with a grid of equal squares. Search all splits (vertical/horizontal) and
    integer allocations of n between the two sides."""
    best = None
    best_score = -1.0
    for split_ratio_num in range(1, 20):
        split_ratio = split_ratio_num / 20.0
        for alloc in range(1, n):
            # vertical split: left width split_ratio, right width 1-split_ratio
            left = _strip_pack(split_ratio, 1.0, alloc)
            right = _strip_pack(1.0 - split_ratio, 1.0, n - alloc)
            score = sum(sq[3] for sq in left) + sum(sq[3] for sq in right)
            if score > best_score:
                best_score = score
                best = left + right
            # horizontal split
            bottom = _strip_pack(1.0, split_ratio, alloc)
            top = _strip_pack(1.0, 1.0 - split_ratio, n - alloc)
            score = sum(sq[3] for sq in bottom) + sum(sq[3] for sq in top)
            if score > best_score:
                best_score = score
                best = bottom + top
    if best is None:
        return _grid_layout(n)
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]


def _partition_search(n):
    """For small n, brute-force integer partitions of n into up to 4 grid blocks
    arranged in a guillotine pattern, choosing best side lengths."""
    if n > 16:
        return None
    best = None
    best_score = -1.0
    # Try one large square + up to 3 grid blocks in remaining L-shape
    for k in range(1, n + 1):
        s = 1.0 / k
        rem = n - 1
        if rem <= 0:
            score = s
            if score > best_score:
                best_score = score
                best = [(s / 2, s / 2, 0.0, s)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
            continue
        # right strip: m squares, top strip: p squares, plus optional bottom-left corner
        for m in range(0, rem + 1):
            for p in range(0, rem - m + 1):
                q = rem - m - p
                # q squares in a small bottom-right square region of size (1-s) x (1-s)
                side_r = (1.0 - s) / m if m > 0 else 0.0
                side_t = min((1.0 - s) / p, s / p) if p > 0 else 0.0
                side_q = (1.0 - s) / max(1, int(math.ceil(math.sqrt(q)))) if q > 0 else 0.0
                if q > 0:
                    side_q = min(side_q, (1.0 - s) / max(1, int(math.ceil(math.sqrt(q)))))
                score = s + m * side_r + p * side_t + q * side_q
                if score > best_score:
                    best_score = score
                    squares = [(s / 2, s / 2, 0.0, s)]
                    for i in range(m):
                        cx = s + (i + 0.5) * ((1.0 - s) / m) if m > 0 else 0
                        cy = (i + 0.5) * (1.0 / m) if m > 0 else 0
                        squares.append((cx, cy, 0.0, side_r))
                    if p > 0:
                        for j in range(p):
                            cx = (j + 0.5) * (s / p)
                            cy = s + (j + 0.5) * ((1.0 - s) / p)
                            squares.append((cx, cy, 0.0, side_t))
                    if q > 0:
                        aq = max(1, int(math.ceil(math.sqrt(q))))
                        for idx in range(q):
                            ii = idx % aq
                            jj = idx // aq
                            cx = s + (ii + 0.5) * ((1.0 - s) / aq)
                            cy = s + (jj + 0.5) * ((1.0 - s) / aq)
                            # place in top-right region above right strip
                            cy = 1.0 - (jj + 0.5) * ((1.0 - s) / aq)
                            squares.append((cx, cy, 0.0, side_q))
                    while len(squares) < n:
                        squares.append((0.5, 0.5, 0.0, 0.0))
                    best = squares[:n]
    return best


def _score(layout):
    return sum(sq[3] for sq in layout)


def _sanitize(layout, n):
    out = []
    for sq in layout[:n]:
        cx, cy, ang, side = sq
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        side = max(side, 0.0)
        out.append((cx, cy, ang, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    candidates = [
        _grid_layout(n),
        _corner_layout(n),
        _rotated_layout(n),
        _recursive_layout(n),
    ]
    p = _partition_search(n)
    if p is not None:
        candidates.append(p)
    best = max(candidates, key=_score)
    return _sanitize(best, n)
# EVOLVE-BLOCK-END
