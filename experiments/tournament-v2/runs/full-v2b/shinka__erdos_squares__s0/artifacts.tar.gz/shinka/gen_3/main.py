# EVOLVE-BLOCK-START
"""General method: choose the best equal-size grid (a x b) that fits n squares,
falling back to the largest k x k grid when that is better."""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    best_sum = -1.0
    best = None

    # Candidate 1: baseline k x k grid of side 1/k (k = isqrt(n)).
    k = math.isqrt(n)
    if k > 0:
        s = 1.0 / k
        total = (k * k) * s
        if total > best_sum:
            best_sum = total
            best = (k, k, s)

    # Candidate 2: equal-size a x b grid with a*b >= n, side = min(1/a, 1/b).
    for a in range(1, n + 1):
        b = (n + a - 1) // a
        s = min(1.0 / a, 1.0 / b)
        total = n * s
        if total > best_sum:
            best_sum = total
            best = (a, b, s)

    a, b, s = best
    squares = []
    for i in range(a):
        for j in range(b):
            if len(squares) >= n:
                break
            squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        if len(squares) >= n:
            break
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
# EVOLVE-BLOCK-END