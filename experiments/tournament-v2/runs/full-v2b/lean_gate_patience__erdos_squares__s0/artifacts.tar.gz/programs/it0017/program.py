"""Multi-scale guillotine packing with rotated inner blocks.

Recursively split the unit square into rectangular cells, then place a grid of equal
squares in each cell.  For each cell we consider both an axis-aligned grid and a grid
rotated by 45 degrees, picking whichever packs the cell more efficiently.  This is a
purely constructive method that works for any n.
"""

import math


def _axis_block(n, w, h):
    """Place n equal squares in a w x h rectangle as an axis-aligned grid.
    Return (side, cols, rows)."""
    if n <= 0:
        return 0.0, 0, 0
    best = (0.0, 1, 1)
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        s = min(w / cols, h / rows)
        if s > best[0]:
            best = (s, cols, rows)
    return best


def _rot_block(n, w, h):
    """Place n equal squares whose grid is rotated 45 degrees inside w x h.
    Return (side, cols, rows).  A c x r grid of side-s squares rotated 45 deg has
    bounding box (c+r)*s/sqrt(2) wide and (c+r)*s/sqrt(2) tall... more precisely
    the rotated grid bounding box is (c*s*cos + r*s*sin, c*s*sin + r*s*cos) with
    45 deg => ( (c+r)*s/sqrt2, (c+r)*s/sqrt2 ) is wrong; use exact formula."""
    if n <= 0:
        return 0.0, 0, 0
    th = math.pi / 4.0
    ct, st = math.cos(th), math.sin(th)
    best = (0.0, 1, 1)
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        # bounding box of a cols x rows s-rotated square grid
        bw = (cols * ct + rows * st)
        bh = (cols * st + rows * ct)
        s = min(w / bw, h / bh)
        if s > best[0]:
            best = (s, cols, rows)
    return best


def _block(n, w, h):
    """Best (side, cols, rows, angle) for packing n equal squares in w x h,
    trying axis-aligned and 45-degree-rotated grids."""
    a = _axis_block(n, w, h)
    r = _rot_block(n, w, h)
    if r[0] > a[0] + 1e-12:
        return (r[0], r[1], r[2], 0.125)  # 45 degrees = 0.125 turn
    return (a[0], a[1], a[2], 0.0)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    leaves = [(0.0, 0.0, 1.0, 1.0, n)]

    for _ in range(400):
        best_gain = 0.0
        best_idx = -1
        best_partition = None

        for idx, (x, y, w, h, cnt) in enumerate(leaves):
            if cnt < 2:
                continue
            cur_side, _, _, _ = _block(cnt, w, h)
            cur_val = cnt * cur_side
            if w >= h:
                for a in range(1, cnt):
                    b = cnt - a
                    frac = math.sqrt(a) / (math.sqrt(a) + math.sqrt(b))
                    frac = min(max(frac, 1e-3), 1 - 1e-3)
                    w1 = w * frac
                    w2 = w - w1
                    s1 = _block(a, w1, h)[0]
                    s2 = _block(b, w2, h)[0]
                    val = a * s1 + b * s2
                    gain = val - cur_val
                    if gain > best_gain:
                        best_gain = gain
                        best_idx = idx
                        best_partition = (a, b, 'v', frac)
            else:
                for a in range(1, cnt):
                    b = cnt - a
                    frac = math.sqrt(a) / (math.sqrt(a) + math.sqrt(b))
                    frac = min(max(frac, 1e-3), 1 - 1e-3)
                    h1 = h * frac
                    h2 = h - h1
                    s1 = _block(a, w, h1)[0]
                    s2 = _block(b, w, h2)[0]
                    val = a * s1 + b * s2
                    gain = val - cur_val
                    if gain > best_gain:
                        best_gain = gain
                        best_idx = idx
                        best_partition = (a, b, 'h', frac)

        if best_idx < 0 or best_gain <= 1e-12:
            break

        x, y, w, h, cnt = leaves[best_idx]
        a, b, kind, frac = best_partition
        if kind == 'v':
            w1 = w * frac
            leaves[best_idx] = (x, y, w1, h, a)
            leaves.append((x + w1, y, w - w1, h, b))
        else:
            h1 = h * frac
            leaves[best_idx] = (x, y, w, h1, a)
            leaves.append((x, y + h1, w, h - h1, b))

    result = []
    for (x, y, w, h, cnt) in leaves:
        side, cols, rows, angle = _block(cnt, w, h)
        if side <= 0:
            result += [(x + w / 2, y + h / 2, 0.0, 0.0)] * cnt
            continue
        if angle == 0.0:
            gw = cols * side
            gh = rows * side
            ox = x + (w - gw) / 2
            oy = y + (h - gh) / 2
            placed = 0
            for i in range(cols):
                for j in range(rows):
                    placed += 1
                    cx = ox + (i + 0.5) * side
                    cy = oy + (j + 0.5) * side
                    result.append((cx, cy, 0.0, side))
            while placed < cnt:
                result.append((x + w / 2, y + h / 2, 0.0, 0.0))
                placed += 1
        else:
            # rotated 45-degree grid; centers of the rotated grid
            th = math.pi / 4.0
            ct, st = math.cos(th), math.sin(th)
            # local grid coords (i,j) -> rotate
            placed = 0
            # find extents to center the rotated block
            # corner offsets in rotated frame
            xs = []
            ys = []
            cells = []
            for i in range(cols):
                for j in range(rows):
                    lx = (i - (cols - 1) / 2.0) * side
                    ly = (j - (rows - 1) / 2.0) * side
                    rx = lx * ct - ly * st
                    ry = lx * st + ly * ct
                    cells.append((rx, ry))
                    xs.append(abs(rx) + side * (abs(ct) + abs(st)) / 2)
                    ys.append(abs(ry) + side * (abs(st) + abs(ct)) / 2)
            # bounding half-extent of the rotated squares (axis-aligned bbox of tilted square)
            half = side * (abs(ct) + abs(st)) / 2.0
            maxx = max((abs(cx) for cx, cy in cells), default=0.0) + half
            maxy = max((abs(cy) for cx, cy in cells), default=0.0) + half
            # scale down if exceeds cell
            sx = w / (2 * maxx) if maxx > 0 else 1.0
            sy = h / (2 * maxy) if maxy > 0 else 1.0
            sc = min(1.0, sx, sy)
            side *= sc
            half = side * (abs(ct) + abs(st)) / 2.0
            ccx = x + w / 2
            ccy = y + h / 2
            grid_cx = (cols - 1) / 2.0
            grid_cy = (rows - 1) / 2.0
            for i in range(cols):
                for j in range(rows):
                    placed += 1
                    lx = (i - grid_cx) * side
                    ly = (j - grid_cy) * side
                    rx = lx * ct - ly * st
                    ry = lx * st + ly * ct
                    result.append((ccx + rx, ccy + ry, angle, side))
            while placed < cnt:
                result.append((x + w / 2, y + h / 2, 0.0, 0.0))
                placed += 1

    result = result[:n]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))

    # clamp everything into [0,1]
    out = []
    for cx, cy, ang, s in result:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        s = min(1.0, max(0.0, s))
        out.append((cx, cy, ang % 1.0, s))
    return out
