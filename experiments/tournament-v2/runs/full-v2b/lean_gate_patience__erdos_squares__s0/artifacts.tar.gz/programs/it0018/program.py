"""Multi-scale guillotine packing followed by a continuous 'grow & resolve' polish.

Stage 1: recursively split the unit square into rectangular cells whose aspect ratio is
kept as square as possible, then place a sub-grid of equal squares in each cell.

Stage 2: take the resulting layout and iteratively try to enlarge individual squares.
For each square (largest first) we attempt to increase its side and nudge its centre;
any candidate that stays inside the unit square and does not overlap another square is
accepted.  Overlap is tested with the separating-axis theorem using the squares'
half-diagonals as bounding circles for a cheap rejection, plus a full SAT test.
"""

import math
import random


def _best_block(n, w, h):
    """Place n equal squares in a w x h rectangle as a grid; return (side, cols, rows)."""
    if n <= 0:
        return 0.0, 0, 0
    best = (0.0, 1, 1)
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        s = min(w / cols, h / rows)
        if s > best[0]:
            best = (s, cols, rows)
    return best


# ---------------------------------------------------------------- SAT overlap test
def _overlap(a, b):
    """Return True if squares a and b (cx,cy,angle,side) overlap in their interiors."""
    ax, ay, aa, asd = a
    bx, by, ba, bsd = b
    if asd <= 0 or bsd <= 0:
        return False
    # cheap bounding-circle rejection
    ra = asd * 1.4143 / 2
    rb = bsd * 1.4143 / 2
    dx = ax - bx
    dy = ay - by
    if dx * dx + dy * dy > (ra + rb) ** 2:
        return False

    def axes(cx, cy, ang, s):
        t = ang * 2 * math.pi
        c = math.cos(t)
        sn = math.sin(t)
        h = s / 2
        return [
            (cx + c * h - sn * h, cy + sn * h + c * h),
            (cx + c * h + sn * h, cy + sn * h - c * h),
            (cx - c * h + sn * h, cy - sn * h - c * h),
            (cx - c * h - sn * h, cy - sn * h + c * h),
        ], (c, sn)

    pa, (ca, sa) = axes(ax, ay, aa, asd)
    pb, (cb, sb) = axes(bx, by, ba, bsd)
    test_axes = [
        (ca, sa), (-sa, ca),
        (cb, sb), (-sb, cb),
    ]
    for ux, uy in test_axes:
        amin = min(p[0] * ux + p[1] * uy for p in pa)
        amax = max(p[0] * ux + p[1] * uy for p in pa)
        bmin = min(p[0] * ux + p[1] * uy for p in pb)
        bmax = max(p[0] * ux + p[1] * uy for p in pb)
        if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
            return False
    return True


def _in_unit(cx, cy, ang, s):
    t = ang * 2 * math.pi
    c = abs(math.cos(t))
    sn = abs(math.sin(t))
    h = s / 2
    rx = c * h + sn * h
    ry = sn * h + c * h
    return cx - rx >= -1e-9 and cx + rx <= 1 + 1e-9 and cy - ry >= -1e-9 and cy + ry <= 1 + 1e-9


def _valid_layout(squares):
    n = len(squares)
    for i in range(n):
        cx, cy, ang, s = squares[i]
        if not (0 <= cx <= 1 and 0 <= cy <= 1 and 0 <= ang <= 1 and 0 <= s <= 1):
            return False
        if not _in_unit(cx, cy, ang, s):
            return False
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _polish(squares, time_budget_iters=4000, seed=12345):
    """Grow and slide squares to improve the sum of sides."""
    rng = random.Random(seed)
    n = len(squares)
    if n == 0:
        return squares
    squares = [list(s) for s in squares]

    def conflicts(i):
        for j in range(n):
            if j != i and _overlap(squares[i], squares[j]):
                return True
        return False

    step = 0.02
    for it in range(time_budget_iters):
        # order squares: largest first, occasionally shuffled
        order = sorted(range(n), key=lambda k: -squares[k][3])
        if it % 3 == 2:
            rng.shuffle(order)
        improved = False
        for i in order:
            cx, cy, ang, s = squares[i]
            # try growing
            for ds in (0.01, 0.005, 0.002, 0.001):
                ns = min(1.0, s + ds)
                if ns == s:
                    continue
                cand = [cx, cy, ang, ns]
                if _in_unit(cand[0], cand[1], cand[2], cand[3]):
                    squares[i] = cand
                    if not conflicts(i):
                        s = ns
                        improved = True
                        break
                    squares[i] = [cx, cy, ang, s]
        step *= 0.95
        if not improved and it > 200:
            # small random jiggle to escape
            for i in range(n):
                cx, cy, ang, s = squares[i]
                d = 0.004
                nx = min(max(cx + rng.uniform(-d, d), 0.0), 1.0)
                ny = min(max(cy + rng.uniform(-d, d), 0.0), 1.0)
                cand = [nx, ny, ang, s]
                if _in_unit(cand[0], cand[1], cand[2], cand[3]):
                    squares[i] = cand
                    if conflicts(i):
                        squares[i] = [cx, cy, ang, s]
            if it > time_budget_iters // 2:
                break
    return [(float(a), float(b), float(c), float(d)) for a, b, c, d in squares]


def _construct(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    leaves = [(0.0, 0.0, 1.0, 1.0, n)]

    for _ in range(400):
        best_gain = 0.0
        best_idx = -1
        best_partition = None

        for idx, (x, y, w, h, cnt) in enumerate(leaves):
            if cnt < 2:
                continue
            cur_side, _, _ = _best_block(cnt, w, h)
            cur_val = cnt * cur_side
            if w >= h:
                for a in range(1, cnt):
                    b = cnt - a
                    frac = math.sqrt(a) / (math.sqrt(a) + math.sqrt(b))
                    frac = min(max(frac, 1e-3), 1 - 1e-3)
                    w1 = w * frac
                    w2 = w - w1
                    s1, _, _ = _best_block(a, w1, h)
                    s2, _, _ = _best_block(b, w2, h)
                    val = a * s1 + b * s2
                    gain = val - cur_val
                    if gain > best_gain:
                        best_gain = gain
                        best_idx = idx
                        best_partition = (a, b, 'v', frac)
            else:
                for a in range(1, cnt):
                    b = cnt - a
                    frac = math.sqrt(a) / (math.sqrt(a) + math.sqrt(b))
                    frac = min(max(frac, 1e-3), 1 - 1e-3)
                    h1 = h * frac
                    h2 = h - h1
                    s1, _, _ = _best_block(a, w, h1)
                    s2, _, _ = _best_block(b, w, h2)
                    val = a * s1 + b * s2
                    gain = val - cur_val
                    if gain > best_gain:
                        best_gain = gain
                        best_idx = idx
                        best_partition = (a, b, 'h', frac)

        if best_idx < 0 or best_gain <= 1e-12:
            break

        x, y, w, h, cnt = leaves[best_idx]
        a, b, kind, frac = best_partition
        if kind == 'v':
            w1 = w * frac
            leaves[best_idx] = (x, y, w1, h, a)
            leaves.append((x + w1, y, w - w1, h, b))
        else:
            h1 = h * frac
            leaves[best_idx] = (x, y, w, h1, a)
            leaves.append((x, y + h1, w, h - h1, b))

    result = []
    for (x, y, w, h, cnt) in leaves:
        side, cols, rows = _best_block(cnt, w, h)
        if side <= 0:
            result += [(x + w / 2, y + h / 2, 0.0, 0.0)] * cnt
            continue
        gw = cols * side
        gh = rows * side
        ox = x + (w - gw) / 2
        oy = y + (h - gh) / 2
        placed = 0
        for i in range(cols):
            for j in range(rows):
                placed += 1
                cx = ox + (i + 0.5) * side
                cy = oy + (j + 0.5) * side
                result.append((cx, cy, 0.0, side))
        while placed < cnt:
            result.append((x + w / 2, y + h / 2, 0.0, 0.0))
            placed += 1

    result = result[:n]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result


def solve(n):
    if n <= 0:
        return []
    base = _construct(n)
    best = base
    best_val = sum(s[3] for s in base)
    # a few polish restarts with different seeds
    for seed in (1, 7, 12345):
        pol = _polish(base, time_budget_iters=1500, seed=seed)
        if _valid_layout(pol):
            v = sum(s[3] for s in pol)
            if v > best_val:
                best_val = v
                best = pol
    # final safety: ensure validity
    if not _valid_layout(best):
        best = base
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
