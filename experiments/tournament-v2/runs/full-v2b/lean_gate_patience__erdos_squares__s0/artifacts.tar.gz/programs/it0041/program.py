# EVOLVE-BLOCK-START
"""Fast constructive packing: integer grids of axis-aligned squares, plus a
mixed layout where an axis-aligned block sits in a band and the remaining band
is filled by 45-degree tilted squares.  No exponential search -> no timeouts."""
import math


def _grid_value(w, h, n):
    """Best total side placing n equal axis-aligned squares in a w x h cell,
    using a p x q grid (p*q may exceed n, we use n of them)."""
    best = (0.0, 0.0, 1, n)
    for p in range(1, n + 1):
        q = (n + p - 1) // p
        s = min(w / p, h / q)
        v = s * n
        if v > best[0]:
            best = (v, s, p, q)
    for q in range(1, n + 1):
        p = (n + q - 1) // q
        s = min(w / p, h / q)
        v = s * n
        if v > best[0]:
            best = (v, s, p, q)
    return best


def _emit_grid(w, h, n, p, q, s, ox=0.0, oy=0.0):
    """Emit up to n axis-aligned squares of side s in a p x q grid centered in
    the w x h cell, offset by (ox, oy)."""
    out = []
    bw, bh = p * s, q * s
    base_x = ox + (w - bw) * 0.5
    base_y = oy + (h - bh) * 0.5
    count = 0
    for j in range(q):
        for i in range(p):
            if count >= n:
                break
            cx = base_x + (i + 0.5) * s
            cy = base_y + (j + 0.5) * s
            out.append((cx, cy, 0.0, s))
            count += 1
        if count >= n:
            break
    return out


def _plain_grid(n):
    v, s, p, q = _grid_value(1.0, 1.0, n)
    return v, _emit_grid(1.0, 1.0, n, p, q, s)


def _tilted_band_layout(n):
    """An axis-aligned block of k columns x m rows occupies the bottom band,
    the top band is filled with 45-degree tilted squares whose bounding boxes
    tile the band.  Return (value, placements)."""
    best = (0.0, None)
    # bottom block: k columns, m rows, side a; top band height T
    for k in range(1, n + 1):
        for m in range(0, n + 1):
            used = k * m
            if used > n:
                continue
            rem = n - used
            # block width k*a <= 1 ; block height m*a <= h_top_band? We instead
            # let block occupy its own horizontal band of height m*a at bottom.
            a = 1.0 / k
            if m * a > 1.0:
                a = 1.0 / m
            block_h = m * a
            block_w = k * a
            if block_w > 1.0 + 1e-12 or block_h > 1.0 + 1e-12:
                continue
            T = 1.0 - block_h
            if rem > 0:
                if T <= 0:
                    continue
                # tilted squares of side t have bounding box t*sqrt2; in the band
                # of height T we fit one tilted row; number across = floor(1/(t*sqrt2))
                # choose t so that n_cols * t is maximized with n_cols=rem
                # t = min(T/sqrt2, 1/(rem*sqrt2))
                t = min(T / math.sqrt(2.0), 1.0 / (rem * math.sqrt(2.0)))
                if t <= 0:
                    continue
                val = used * a + rem * t
                if val > best[0]:
                    best = (val, ('tilt', k, m, a, rem, t))
            else:
                val = used * a
                if val > best[0]:
                    best = (val, ('tilt', k, m, a, 0, 0.0))
    if best[1] is None:
        return 0.0, None
    _, k, m, a, rem, t = best[1]
    block_h = m * a
    placements = []
    # bottom block centered horizontally, at bottom band
    if m > 0:
        bw = k * a
        ox = (1.0 - bw) * 0.5
        for j in range(m):
            for i in range(k):
                cx = ox + (i + 0.5) * a
                cy = (j + 0.5) * a
                placements.append((cx, cy, 0.0, a))
    # top band tilted squares
    if rem > 0 and t > 0:
        bb = t * math.sqrt(2.0)
        y0 = block_h
        # place rem squares across the band, centered
        total_w = rem * bb
        if total_w > 1.0:
            total_w = 1.0
        start = (1.0 - total_w) * 0.5
        cy = y0 + (1.0 - y0) * 0.5
        for i in range(rem):
            cx = start + (i + 0.5) * bb
            placements.append((cx, cy, 0.125, t))
    while len(placements) < n:
        placements.append((0.5, 0.5, 0.0, 0.0))
    return best[0], placements[:n]


def _rotated_grid(n):
    """All squares tilted 45 degrees, bounding boxes tile the plane."""
    best = (0.0, None)
    # bounding box of side-s 45-degree square is s*sqrt2; square is valid if
    # the rotated square (diagonal s*sqrt2) fits inside unit square.
    for p in range(1, n + 1):
        q = (n + p - 1) // p
        # we want equal squares of side s with grid of bounding boxes tiling
        t_box = min(1.0 / p, 1.0 / q)
        s = t_box / math.sqrt(2.0)
        v = s * n
        if v > best[0]:
            best = (v, p, q, s)
    if best[1] is None:
        return 0.0, None
    _, p, q, s = best
    tbox = s * math.sqrt(2.0)
    out = []
    bw, bh = p * tbox, q * tbox
    ox, oy = (1.0 - bw) * 0.5, (1.0 - bh) * 0.5
    count = 0
    for j in range(q):
        for i in range(p):
            if count >= n:
                break
            cx = ox + (i + 0.5) * tbox
            cy = oy + (j + 0.5) * tbox
            out.append((cx, cy, 0.125, s))
            count += 1
        if count >= n:
            break
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return best[0], out[:n]


def _mixed_grid(n):
    """k columns x m rows block with a single leftover tilted band, plus a
    fallback that splits n into an axis-aligned block and a tilted block in a
    vertical band."""
    return _tilted_band_layout(n)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_val = -1.0
    best_pl = None

    candidates = [_plain_grid(n), _tilted_band_layout(n), _rotated_grid(n)]
    for v, pl in candidates:
        if pl is not None and v > best_val:
            best_val = v
            best_pl = pl

    if best_pl is None:
        s = 1.0 / math.isqrt(n)
        best_pl = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                   for i in range(math.isqrt(n))
                   for j in range(math.isqrt(n))]
        best_pl += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_pl))

    result = []
    for (cx, cy, a, s) in best_pl[:n]:
        s = max(0.0, min(1.0, s))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        result.append((cx, cy, a, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END
