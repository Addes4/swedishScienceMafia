# EVOLVE-BLOCK-START
"""Continuous optimiser: place n oriented squares in the unit square maximising
the sum of side lengths, using a separating-axis penalty plus a validity repair."""
import math
import numpy as np
from scipy.optimize import minimize

_TWO_PI = 2.0 * math.pi


def _verts(cx, cy, ang, s):
    """Four vertices of a square (centre, angle in turns, side)."""
    th = ang * _TWO_PI
    c = math.cos(th)
    sn = math.sin(th)
    h = 0.5 * s
    ex, ey = c * h, sn * h
    fx, fy = -sn * h, c * h
    return ((cx + ex + fx, cy + ey + fy),
            (cx + ex - fx, cy + ey - fy),
            (cx - ex + fx, cy - ey + fy),
            (cx - ex - fx, cy - ey - fy))


def _pen(pa, pb):
    """Interior-overlap penetration depth of two squares (0 if disjoint/touching)."""
    if pa[3] <= 0.0 or pb[3] <= 0.0:
        return 0.0
    va = _verts(*pa)
    vb = _verts(*pb)
    axes = []
    for ang in (pa[2], pb[2]):
        th = ang * _TWO_PI
        c = math.cos(th)
        s = math.sin(th)
        axes.append((c, s))
        axes.append((-s, c))
    pen = float('inf')
    for dx, dy in axes:
        al = [v[0] * dx + v[1] * dy for v in va]
        bl = [v[0] * dx + v[1] * dy for v in vb]
        amin, amax = min(al), max(al)
        bmin, bmax = min(bl), max(bl)
        ov = min(amax, bmax) - max(amin, bmin)
        if ov <= 0.0:
            return 0.0
        if ov < pen:
            pen = ov
    return pen


def _objective(x, n):
    P = [(x[4 * i], x[4 * i + 1], x[4 * i + 2], max(0.0, x[4 * i + 3]))
         for i in range(n)]
    total = 0.0
    pen = 0.0
    for i in range(n):
        cx, cy, ang, s = P[i]
        total += s
        for px, py in _verts(cx, cy, ang, s):
            if px < 0.0:
                pen += px * px
            elif px > 1.0:
                pen += (px - 1.0) ** 2
            if py < 0.0:
                pen += py * py
            elif py > 1.0:
                pen += (py - 1.0) ** 2
        for j in range(i + 1, n):
            p = _pen(P[i], P[j])
            if p > 0.0:
                pen += p * p
    return -total + 50.0 * pen


def _repair(P):
    """Shrink squares until every vertex is in [0,1] and no interiors overlap."""
    P = [list(p) for p in P]
    for _ in range(400):
        ok = True
        for p in P:
            if p[3] <= 0.0:
                continue
            v = _verts(*p)
            mnx = min(q[0] for q in v)
            mxx = max(q[0] for q in v)
            mny = min(q[1] for q in v)
            mxy = max(q[1] for q in v)
            over = max(0.0, -mnx, mxx - 1.0, -mny, mxy - 1.0)
            if over > 1e-12:
                p[3] = max(0.0, p[3] - over)
                ok = False
        for i in range(len(P)):
            for j in range(i + 1, len(P)):
                if P[i][3] <= 0.0 or P[j][3] <= 0.0:
                    continue
                pn = _pen(tuple(P[i]), tuple(P[j]))
                if pn > 1e-12:
                    P[i][3] = max(0.0, P[i][3] - 0.5 * pn)
                    P[j][3] = max(0.0, P[j][3] - 0.5 * pn)
                    ok = False
        if ok:
            break
    return [tuple(p) for p in P]


def _init(n, rng):
    k = math.isqrt(n)
    s = 1.0 / k if k > 0 else 1.0
    P = []
    for i in range(k):
        for j in range(k):
            if rng is None:
                dx = dy = 0.0
            else:
                dx = rng.uniform(-0.03, 0.03)
                dy = rng.uniform(-0.03, 0.03)
            P.append((min(1.0, max(0.0, (i + 0.5) * s + dx)),
                      min(1.0, max(0.0, (j + 0.5) * s + dy)),
                      0.0, s))
    m = n - len(P)
    for t in range(m):
        P.append((0.5, 0.5, 0.0, 0.4 / (k + 1)))
    return P[:n]


def solve(n):
    if n <= 0:
        return []
    best = None
    best_val = -1.0
    rng = np.random.default_rng(20240611)
    restarts = 3
    for r in range(restarts):
        P = _init(n, None if r == 0 else rng)
        x = np.array([v for p in P for v in p], dtype=float)
        bounds = [(0.0, 1.0), (0.0, 1.0), (0.0, 0.25), (0.0, 1.0)] * n
        try:
            res = minimize(lambda z: _objective(z, n), x, method='L-BFGS-B',
                           bounds=bounds, options={'maxiter': 300, 'maxfun': 100000})
            x = res.x
        except Exception:
            pass
        Q = [(float(x[4 * i]), float(x[4 * i + 1]),
              min(0.25, max(0.0, float(x[4 * i + 2]))),
              max(0.0, float(x[4 * i + 3]))) for i in range(n)]
        Q = _repair(Q)
        val = sum(p[3] for p in Q)
        if val > best_val:
            best_val = val
            best = Q
    out = []
    for cx, cy, ang, s in best:
        out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)),
                    min(1.0, max(0.0, ang)), min(1.0, max(0.0, s))))
    return out
# EVOLVE-BLOCK-END
