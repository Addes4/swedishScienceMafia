import math


def solve(n):
    best = None
    best_val = -1.0

    def consider(layout):
        nonlocal best, best_val
        if len(layout) < n:
            layout = layout + [(0.5, 0.5, 0.0, 0.0)] * (n - len(layout))
        layout = layout[:n]
        val = sum(s for _, _, _, s in layout)
        if val > best_val + 1e-12:
            best_val = val
            best = layout

    S2 = math.sqrt(2.0)

    # Precompute best pure uniform grid
    for k in range(1, n + 1):
        if k * k <= n:
            s = 1.0 / k
            g = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                 for i in range(k) for j in range(k)]
            consider(g)

    # ---- Mixed-row construction ----
    # A horizontal band of full height h in [0,1].
    # Option AXIS(a): a axis-aligned squares of side s=1/a filling width, height s.
    #    band height = 1/a, contributes a*(1/a)=1 to sum.
    # Option TILT(b): b 45-degree squares. Each tilted square of side t has bbox
    #    t*sqrt2. Fit b across width: b*t*sqrt2 = 1 -> t=1/(b*sqrt2). Band height
    #    = t*sqrt2 = 1/b. Contributes b*t = b/(b*sqrt2) = 1/sqrt2.
    #
    # So per band, normalized sum-per-full-width:
    #   AXIS(a): contributes 1 (with height 1/a)
    #   TILT(b): contributes 1/sqrt2 (with height 1/b)
    # We stack bands summing heights to <=1. AXIS bands are efficient per height.
    #
    # Generalize: allow bands that don't span full width? Keep full-width bands.
    def build_bands(bands):
        # bands: list of ('A', a) or ('T', b). Returns layout and total.
        layout = []
        y = 0.0
        total = 0.0
        for kind, cnt in bands:
            if kind == 'A':
                a = cnt
                s = 1.0 / a
                for i in range(a):
                    for j in range(a):  # a x a block filling width and height s? 
                        # Actually AXIS(a): a squares in one row, height s.
                        pass
                # one row of a squares
                for i in range(a):
                    layout.append(((i + 0.5) * s, y + 0.5 * s, 0.0, s))
                total += 1.0
                y += s
            else:
                b = cnt
                t = 1.0 / (b * S2)
                h = 1.0 / b
                for i in range(b):
                    cx = (i + 0.5) * (1.0 / b)
                    layout.append((cx, y + 0.5 * h, 0.125, t))
                total += 1.0 / S2
                y += h
        return layout, total, y

    # DP to maximize count-weighted value with exactly n squares, height <=1.
    # Each band uses k squares and consumes height. We want total squares = n.
    # maximize sum of band values, plus leftover squares of side 0.
    # value(A,a)=1 per a squares; value(T,b)=1/sqrt2 per b squares.
    # We choose multiset of bands.
    # heights: hA(a)=1/a (a>=1), hT(b)=1/b (b>=1)
    # Cap counts to n.
    maxc = n
    NEG = -1e18
    # dp[c] = best total value using exactly c squares, and store bands
    dp = [NEG] * (maxc + 1)
    dp[0] = 0.0
    choice = [None] * (maxc + 1)
    # iterate: allow any number of bands; do it as unbounded knapsack over total squares
    # also track height to ensure <=1
    # Use dp over (count, heightgrid) is heavy; instead enumerate band combos via DP
    # on count where height is derived. But height depends on choice. So do DP where
    # state = count, and we require sum heights <=1. Since sum of reciprocals <=1.
    # Use dict dp: count -> (value, bands, height)
    states = {0: (0.0, [], 0.0)}
    # options: (kind, cnt, value, height)
    options = []
    for a in range(1, n + 1):
        options.append(('A', a, 1.0, 1.0 / a))
    for b in range(1, n + 1):
        options.append(('T', b, 1.0 / S2, 1.0 / b))

    for _ in range(n + 1):
        new_states = dict(states)
        for c, (val, bands, h) in states.items():
            for kind, cnt, v, dh in options:
                nc = c + cnt
                if nc > n:
                    continue
                nh = h + dh
                if nh > 1.0 + 1e-12:
                    continue
                nv = val + v
                key = nc
                cur = new_states.get(key)
                if cur is None or nv > cur[0] + 1e-12:
                    new_states[key] = (nv, bands + [(kind, cnt)], nh)
        states = new_states

    # choose best among states with c<=n (rest are zero-size squares)
    for c, (val, bands, h) in states.items():
        if c <= n:
            layout, total, ytot = build_bands(bands)
            if ytot > 1.0 + 1e-9:
                continue
            consider(layout)

    # ---- Family: column version ----
    # Same but vertical bands (transpose). Equivalent by symmetry of square, skip.
    # But mixed (some columns tilted) may differ; build transpose version.
    def build_bands_col(bands):
        layout = []
        x = 0.0
        for kind, cnt in bands:
            if kind == 'A':
                a = cnt
                s = 1.0 / a
                for j in range(a):
                    layout.append((x + 0.5 * s, (j + 0.5) * s, 0.0, s))
                x += s
            else:
                b = cnt
                t = 1.0 / (b * S2)
                w = 1.0 / b
                for j in range(b):
                    cy = (j + 0.5) * (1.0 / b)
                    layout.append((x + 0.5 * w, cy, 0.125, t))
                x += w
        return layout, x

    for c, (val, bands, h) in states.items():
        if c <= n:
            layout, xtot = build_bands_col(bands)
            if xtot > 1.0 + 1e-9:
                continue
            consider(layout)

    # ---- Family D: multi-scale guillotine (kept from before) ----
    def pack_in_rect(x0, y0, x1, y1, remaining, out):
        w = x1 - x0
        h = y1 - y0
        if remaining <= 0 or w <= 1e-12 or h <= 1e-12:
            return 0
        best_block = None
        best_score = -1.0
        maxk = min(20, remaining)
        for k in range(1, maxk + 1):
            for m in range(1, min(20, remaining // k) + 1):
                if k * m > remaining:
                    continue
                s = min(w / k, h / m)
                score = k * m * s
                if score > best_score:
                    best_score = score
                    best_block = (k, m, s)
        if best_block is None:
            return 0
        k, m, s = best_block
        for i in range(k):
            for j in range(m):
                out.append((x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, 0.0, s))
        placed = k * m
        rem = remaining - placed
        if rem == 0:
            return placed
        used_w = k * s
        used_h = m * s
        rem_placed = 0
        if w - used_w > 1e-12:
            rem_placed += pack_in_rect(x0 + used_w, y0, x1, y0 + used_h,
                                       rem - rem_placed, out)
        if rem_placed < rem and h - used_h > 1e-12:
            rem_placed += pack_in_rect(x0, y0 + used_h, x1, y1,
                                       rem - rem_placed, out)
        return placed + rem_placed

    out = []
    pack_in_rect(0.0, 0.0, 1.0, 1.0, n, out)
    consider(out)

    if best is None:
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best = best[:n]
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))

    return best
