# EVOLVE-BLOCK-START
"""Sum of side lengths maximization via analytic layout families.

Key facts:
 - Placing n equal axis-aligned squares in the unit square: best is to choose
   p columns x q rows with p*q >= n, side = min(1/p, 1/q); use n of them.
 - Mixing sizes: put a big square in a corner and fill the remaining L-shape
   with a grid of smaller squares / tilted squares.
 - Rotated (45 deg) squares can fill a band of height h with side s = h/sqrt(2)
   and width occupation s*sqrt(2)=h.
We evaluate a curated set of such families and return the best.
"""
import math


def _grid_layout(n_cells, w, h):
    """Place n_cells equal axis-aligned squares in w x h region.
    Returns (value, side, p, q)."""
    if n_cells <= 0:
        return (0.0, 0.0, 0, 0)
    best = (0.0, 0.0, 0, 0)
    for p in range(1, n_cells + 1):
        q = (n_cells + p - 1) // p
        s = min(w / p, h / q)
        v = s * n_cells
        if v > best[0] + 1e-15:
            best = (v, s, p, q)
    return best


def _emit_grid(w, h, n_cells, p, q, s, n_total):
    out = []
    bw, bh = p * s, q * s
    ox, oy = (w - bw) * 0.5, (h - bh) * 0.5
    cnt = 0
    for j in range(q):
        for i in range(p):
            if cnt >= n_cells:
                break
            out.append((ox + (i + 0.5) * s, oy + (j + 0.5) * s, 0.0, s))
            cnt += 1
        if cnt >= n_cells:
            break
    while len(out) < n_total:
        out.append((w * 0.5, h * 0.5, 0.0, 0.0))
    return out[:n_total]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_val = -1.0
    best_pl = None

    def consider(v, pl):
        nonlocal best_val, best_pl
        if v > best_val + 1e-12:
            best_val = v
            best_pl = pl

    # --- Family A: uniform p x q grid over the whole unit square ---
    v, s, p, q = _grid_layout(n, 1.0, 1.0)
    consider(v, _emit_grid(1.0, 1.0, n, p, q, s, n))

    # --- Family B: split into two rectangles (vertical or horizontal),
    # each filled with an equal grid; search split fraction and counts. ---
    for axis in (0, 1):
        for t in range(1, n):
            r = n - t
            fr = set()
            for den in (2, 3, 4, 5, 6, 7, 8, 10):
                for num in range(1, den):
                    fr.add(num / den)
            for m in (t, r):
                vm, sm, pm, qm = _grid_layout(m, 1.0, 1.0)
                if sm > 0:
                    need = (pm * sm) if axis == 0 else (qm * sm)
                    if 0 < need < 1.0:
                        fr.add(need)
                        fr.add(1.0 - need)
            for frac in fr:
                if frac <= 1e-9 or frac >= 1 - 1e-9:
                    continue
                if axis == 0:
                    w1, h1 = frac, 1.0
                    w2, h2 = 1.0 - frac, 1.0
                else:
                    w1, h1 = 1.0, frac
                    w2, h2 = 1.0, 1.0 - frac
                v1, s1, p1, q1 = _grid_layout(t, w1, h1)
                v2, s2, p2, q2 = _grid_layout(r, w2, h2)
                tv = v1 + v2
                if tv > best_val + 1e-12:
                    pl1 = _emit_grid(w1, h1, t, p1, q1, s1, t)
                    pl2 = _emit_grid(w2, h2, r, p2, q2, s2, r)
                    if axis == 0:
                        off2 = (frac, 0.0)
                    else:
                        off2 = (0.0, frac)
                    merged = list(pl1)
                    for (cx, cy, a, ss) in pl2:
                        merged.append((cx + off2[0], cy + off2[1], a, ss))
                    consider(tv, merged)

    # --- Family C: big corner square + remainder L-shape grid ---
    def corner_eval(a, rem):
        if a <= 1e-9 or a >= 1 - 1e-9:
            return None
        best_local = None
        for k in range(0, rem + 1):
            r2 = rem - k
            v1, s1, p1, q1 = _grid_layout(k, 1.0 - a, a) if k > 0 else (0.0, 0.0, 0, 0)
            v2, s2, p2, q2 = _grid_layout(r2, 1.0, 1.0 - a) if r2 > 0 else (0.0, 0.0, 0, 0)
            tot = a + v1 + v2
            if best_local is None or tot > best_local[0] + 1e-12:
                best_local = (tot, a, k, p1, q1, s1, p2, q2, s2, r2)
        return best_local

    cand_a = set()
    for den in (2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 16, 20):
        for num in range(1, den):
            cand_a.add(num / den)
    for m in range(1, n):
        vm, sm, pm, qm = _grid_layout(m, 1.0, 1.0)
        if 0 < sm < 1:
            cand_a.add(sm)
            cand_a.add(sm * 2)
    cand_a = sorted(x for x in cand_a if 1e-6 < x < 1 - 1e-6)

    def _place_corner(a, k, p1, q1, s1, p2, q2, s2, r2, n):
        pl = [(a * 0.5, a * 0.5, 0.0, a)]
        if k > 0:
            sub = _emit_grid(1.0 - a, a, k, p1, q1, s1, k)
            for (cx, cy, ang, ss) in sub:
                pl.append((cx + a, cy, ang, ss))
        if r2 > 0:
            sub = _emit_grid(1.0, 1.0 - a, r2, p2, q2, s2, r2)
            for (cx, cy, ang, ss) in sub:
                pl.append((cx, cy + a, ang, ss))
        while len(pl) < n:
            pl.append((0.5, 0.5, 0.0, 0.0))
        return pl[:n]

    best_corner = None
    for a in cand_a:
        res = corner_eval(a, n - 1)
        if res is None:
            continue
        if best_corner is None or res[0] > best_corner[0] + 1e-12:
            best_corner = res

    # continuous refinement of a via local scan
    if best_corner is not None:
        a0 = best_corner[1]
        for step in (0.02, 0.005, 0.001):
            a = a0 - 0.1
            while a <= a0 + 0.1 and 1e-6 < a < 1 - 1e-6:
                res = corner_eval(a, n - 1)
                if res is not None and res[0] > best_corner[0] + 1e-12:
                    best_corner = res
                    a0 = res[1]
                a += step

    if best_corner is not None:
        tot, a, k, p1, q1, s1, p2, q2, s2, r2 = best_corner
        if tot > best_val + 1e-12:
            consider(tot, _place_corner(a, k, p1, q1, s1, p2, q2, s2, r2, n))

    # --- Family D: 45-degree tilted band(s) ---
    sq2 = math.sqrt(2.0)
    for h in cand_a:
        side = h / sq2
        cnt_fit = int(1.0 / h + 1e-9)
        if cnt_fit <= 0:
            continue
        for band_cnt in (cnt_fit,):
            if band_cnt > n:
                continue
            rem = n - band_cnt
            v_rem, sr, pr, qr = _grid_layout(rem, 1.0, 1.0 - h) if rem > 0 else (0.0, 0.0, 0, 0)
            tot = band_cnt * side + v_rem
            if tot > best_val + 1e-12:
                pl = []
                for i in range(band_cnt):
                    cx = (i + 0.5) * h
                    cy = h * 0.5
                    pl.append((cx, cy, 0.125, side))
                if rem > 0:
                    sub = _emit_grid(1.0, 1.0 - h, rem, pr, qr, sr, rem)
                    for (cx, cy, ang, ss) in sub:
                        pl.append((cx, cy + h, ang, ss))
                while len(pl) < n:
                    pl.append((0.5, 0.5, 0.0, 0.0))
                consider(tot, pl[:n])

    # --- Family E: big corner square + tilted band on top + grid in right strip ---
    # a x a square bottom-left; top region [0,1]x[a,1] height (1-a) filled with a
    # tilted band (occupying bottom of that region) + axis-aligned grid above it;
    # right strip [a,1]x[0,a] filled with grid. Optimize a and band height b.
    for a in cand_a:
        rem0 = n - 1
        if rem0 < 0:
            continue
        # right strip grid
        # distribute rem0 among right strip (k), top band tilted (cnt), top grid (rest)
        for k in range(0, rem0 + 1):
            rem1 = rem0 - k
            v1, s1, p1, q1 = _grid_layout(k, 1.0 - a, a) if k > 0 else (0.0, 0.0, 0, 0)
            # scan band height b for tilted band in top region
            for bi in range(0, 13):
                b = (1.0 - a) * bi / 13.0 if bi < 13 else 0.0
                if bi == 0:
                    cnt = 0
                    b = 0.0
                else:
                    if b <= 1e-9:
                        continue
                    cnt = int(1.0 / b + 1e-9)
                    if cnt < 0:
                        cnt = 0
                if cnt > rem1:
                    cnt = rem1
                    b = 1.0 / cnt if cnt > 0 else 0.0
                if cnt > 0 and b > 1e-9:
                    sside = b / sq2
                else:
                    sside = 0.0
                rem2 = rem1 - cnt
                top_h = (1.0 - a) - b
                if top_h < 1e-9:
                    if rem2 > 0:
                        continue
                    v2, s2, p2, q2 = (0.0, 0.0, 0, 0)
                else:
                    v2, s2, p2, q2 = _grid_layout(rem2, 1.0, top_h) if rem2 > 0 else (0.0, 0.0, 0, 0)
                tot = a + v1 + sside * cnt + v2
                if tot > best_val + 1e-12:
                    pl = [(a * 0.5, a * 0.5, 0.0, a)]
                    if k > 0:
                        sub = _emit_grid(1.0 - a, a, k, p1, q1, s1, k)
                        for (cx, cy, ang, ss) in sub:
                            pl.append((cx + a, cy, ang, ss))
                    ybase = a
                    if cnt > 0 and sside > 0:
                        for i in range(cnt):
                            cx = (i + 0.5) * b
                            cy = ybase + b * 0.5
                            pl.append((cx, cy, 0.125, sside))
                        ybase += b
                    if rem2 > 0:
                        sub = _emit_grid(1.0, top_h, rem2, p2, q2, s2, rem2)
                        for (cx, cy, ang, ss) in sub:
                            pl.append((cx, cy + ybase, ang, ss))
                    while len(pl) < n:
                        pl.append((0.5, 0.5, 0.0, 0.0))
                    consider(tot, pl[:n])

    if best_pl is None:
        v, s, p, q = _grid_layout(n, 1.0, 1.0)
        best_pl = _emit_grid(1.0, 1.0, n, p, q, s, n)

    result = []
    for (cx, cy, a, s) in best_pl[:n]:
        s = max(0.0, min(1.0, float(s)))
        cx = max(0.0, min(1.0, float(cx)))
        cy = max(0.0, min(1.0, float(cy)))
        result.append((cx, cy, 0.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END
