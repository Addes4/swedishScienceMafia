import math
import random


def solve(n):
    random.seed(12345)

    def corners(cx, cy, a, s):
        ang = a * 2 * math.pi
        ca, sa = math.cos(ang), math.sin(ang)
        h = s / 2.0
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
        return pts

    def overlap(sq1, sq2):
        cx1, cy1, a1, s1 = sq1
        cx2, cy2, a2, s2 = sq2
        if s1 <= 0 or s2 <= 0:
            return False
        P = corners(cx1, cy1, a1, s1)
        Q = corners(cx2, cy2, a2, s2)
        for poly, other in ((P, Q), (Q, P)):
            for i in range(4):
                x1, y1 = poly[i]
                x2, y2 = poly[(i + 1) % 4]
                ex, ey = x2 - x1, y2 - y1
                nx, ny = -ey, ex
                norm = math.hypot(nx, ny)
                if norm < 1e-15:
                    continue
                nx, ny = nx / norm, ny / norm
                pmin = pminv = min(pt[0] * nx + pt[1] * ny for pt in poly)
                pmax = max(pt[0] * nx + pt[1] * ny for pt in poly)
                qmin = min(pt[0] * nx + pt[1] * ny for pt in other)
                qmax = max(pt[0] * nx + pt[1] * ny for pt in other)
                if pmax <= qmin + 1e-12 or qmax <= pmin + 1e-12:
                    return False
        return True

    def total(layout):
        return sum(s for _, _, _, s in layout)

    def in_bounds(sq):
        cx, cy, a, s = sq
        for px, py in corners(cx, cy, a, s):
            if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                return False
        return True

    def valid_layout(layout):
        for i in range(len(layout)):
            if not in_bounds(layout[i]):
                return False
            for j in range(i + 1, len(layout)):
                if overlap(layout[i], layout[j]):
                    return False
        return True

    best = None
    best_val = -1.0

    def consider(layout):
        nonlocal best, best_val
        if len(layout) < n:
            layout = layout + [(0.5, 0.5, 0.0, 0.0)] * (n - len(layout))
        layout = layout[:n]
        val = sum(s for _, _, _, s in layout)
        if val > best_val:
            best_val = val
            best = list(layout)

    # ---- Family A: pure uniform grid k x k ----
    for k in range(1, n + 1):
        if k * k <= n:
            s = 1.0 / k
            g = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                 for i in range(k) for j in range(k)]
            consider(g)

    # ---- Family B: rows of axis-aligned + band of 45deg tilted ----
    for r in range(1, n + 1):
        for a in range(1, n + 1):
            na = r * a
            if na > n:
                continue
            h_axis = r * (1.0 / a)
            if h_axis >= 1.0:
                continue
            h_left = 1.0 - h_axis
            for b in range(1, n - na + 1):
                t = min(1.0 / (b * math.sqrt(2)), h_left / math.sqrt(2))
                if t <= 0:
                    continue
                layout = []
                s = 1.0 / a
                for j in range(r):
                    for i in range(a):
                        layout.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                y0 = h_axis
                for i in range(b):
                    cx = (i + 0.5) * t * math.sqrt(2)
                    cy = y0 + t * math.sqrt(2) / 2.0
                    if cx - t * math.sqrt(2) / 2 < -1e-9 or cx + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    if cy + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    layout.append((cx, cy, 0.125, t))
                if len(layout) >= n:
                    consider(layout)

    # ---- Family C: columns version ----
    for c in range(1, n + 1):
        for a in range(1, n + 1):
            na = c * a
            if na > n:
                continue
            w_axis = c * (1.0 / a)
            if w_axis >= 1.0:
                continue
            w_left = 1.0 - w_axis
            for b in range(1, n - na + 1):
                t = min(1.0 / (b * math.sqrt(2)), w_left / math.sqrt(2))
                if t <= 0:
                    continue
                layout = []
                s = 1.0 / a
                for i in range(c):
                    for j in range(a):
                        layout.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                x0 = w_axis
                for j in range(b):
                    cy = (j + 0.5) * t * math.sqrt(2)
                    cx = x0 + t * math.sqrt(2) / 2.0
                    if cx + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    if cy + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    layout.append((cx, cy, 0.125, t))
                if len(layout) >= n:
                    consider(layout)

    # ---- Family D: full grid of 45deg tilted squares ----
    for k in range(1, n + 1):
        if k * k <= n:
            t = 1.0 / (k * math.sqrt(2))
            g = [((i + 0.5) * t * math.sqrt(2), (j + 0.5) * t * math.sqrt(2),
                  0.125, t) for i in range(k) for j in range(k)]
            consider(g)

    # ---- Family E: guillotine blocks ----
    def pack_in_rect(x0, y0, x1, y1, remaining, out):
        w = x1 - x0
        h = y1 - y0
        if remaining <= 0 or w <= 1e-12 or h <= 1e-12:
            return 0
        best_block = None
        best_score = -1.0
        for k in range(1, min(20, remaining) + 1):
            for m in range(1, min(20, remaining // k) + 1):
                if k * m > remaining:
                    continue
                s = min(w / k, h / m)
                score = k * m * s
                if score > best_score:
                    best_score = score
                    best_block = (k, m, s)
        if best_block is None:
            return 0
        k, m, s = best_block
        for i in range(k):
            for j in range(m):
                out.append((x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, 0.0, s))
        placed = k * m
        rem = remaining - placed
        if rem == 0:
            return placed
        used_w = k * s
        used_h = m * s
        rem_placed = 0
        if w - used_w > 1e-12:
            rem_placed += pack_in_rect(x0 + used_w, y0, x1, y0 + used_h,
                                       rem - rem_placed, out)
        if rem_placed < rem and h - used_h > 1e-12:
            rem_placed += pack_in_rect(x0, y0 + used_h, x1, y1,
                                       rem - rem_placed, out)
        return placed + rem_placed

    out = []
    pack_in_rect(0.0, 0.0, 1.0, 1.0, n, out)
    consider(out)

    if best is None:
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best = best[:n]
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))

    # ---- Coordinate-descent growth refinement ----
    layout = [list(sq) for sq in best]

    def try_layout(cand):
        # verify validity quickly
        for i in range(n):
            cx, cy, a, s = cand[i]
            if s <= 0:
                continue
            if not in_bounds(cand[i]):
                return False
        for i in range(n):
            if cand[i][3] <= 0:
                continue
            for j in range(i + 1, n):
                if cand[j][3] <= 0:
                    continue
                if overlap(cand[i], cand[j]):
                    return False
        return True

    improved = True
    iters = 0
    while improved and iters < 60:
        improved = False
        iters += 1
        order = list(range(n))
        random.shuffle(order)
        for idx in order:
            base = layout[idx][:]
            bestlocal = base[:]
            bestv = base[3]
            # try growing this square, trying several centers/angles
            s0 = base[3]
            probes = []
            growth = max(0.02, s0 * 0.5)
            for ds in (growth, growth * 0.5, growth * 0.25, 0.01):
                ns = s0 + ds
                for dcx in (-0.02, -0.01, 0.0, 0.01, 0.02):
                    for dcy in (-0.02, -0.01, 0.0, 0.01, 0.02):
                        probes.append((base[0] + dcx, base[1] + dcy,
                                       base[2], ns))
                # also try tiny angle tweaks
                for da in (-0.02, -0.01, 0.01, 0.02):
                    probes.append((base[0], base[1], base[2] + da, ns))
            for cx, cy, a, ns in probes:
                if cx < 0 or cx > 1 or cy < 0 or cy > 1:
                    continue
                cand = [row[:] for row in layout]
                cand[idx] = [cx, cy, a, ns]
                if try_layout(cand):
                    if ns > bestv:
                        bestv = ns
                        bestlocal = [cx, cy, a, ns]
            if bestv > base[3] + 1e-12:
                layout[idx] = bestlocal
                improved = True
        # also try shrink-and-reposition of small squares to make room: skip (costly)

    final = [(cx, cy, a, s) for cx, cy, a, s in layout]
    if valid_layout(final) and total(final) >= best_val - 1e-9:
        if total(final) > best_val:
            best_val = total(final)
            best = final
    elif total(final) > best_val:
        # only accept if valid
        pass

    return best
