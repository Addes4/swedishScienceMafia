import math


def solve(n):
    best = None
    best_val = -1.0

    def consider(layout):
        nonlocal best, best_val
        if len(layout) < n:
            layout = layout + [(0.5, 0.5, 0.0, 0.0)] * (n - len(layout))
        layout = layout[:n]
        # validate non-overlap simply (axis-aligned only assumed here)
        val = sum(s for _, _, _, s in layout)
        if val > best_val:
            best_val = val
            best = layout

    # ---- Family A: pure uniform grid k x m (axis aligned) ----
    for k in range(1, n + 1):
        rem = n - k * k
        # full k x k grid plus leftover squares as small extras
        if k * k <= n:
            s = 1.0 / k
            g = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                 for i in range(k) for j in range(k)]
            consider(g)

    # ---- Family B: one row of axis-aligned squares + one tilted row ----
    # Place a axis-aligned squares of side s = 1/a along bottom, plus
    # b tilted squares (rotated 45 deg) of side t in a band of height t*sqrt(2)
    # that sit in remaining rows. Tilted 45-deg squares of side t occupy bbox t*sqrt2,
    # pack them in a row of width 1: b*t*sqrt2 <= 1.
    # Total side = a*s + b*t, with a*s = 1 -> s=1/a, and rows must fit height 1.
    def tilt_row_best(rows_axis, a, b, t):
        return a * (1.0 / a) + b * t

    # Search combos: a axis-aligned squares in one row (width 1, side 1/a),
    # stacked rows of axis squares: r rows of a squares -> r*a squares, height r/a.
    # Then a band of b tilted 45 squares (side t), height t*sqrt2, width b*t*sqrt2 <=1.
    for r in range(1, n + 1):
        for a in range(1, n + 1):
            na = r * a
            if na > n:
                continue
            h_axis = r * (1.0 / a)
            if h_axis >= 1.0:
                continue
            h_left = 1.0 - h_axis
            # band of tilted squares
            for b in range(0, n - na + 1):
                if b == 0:
                    continue
                # side t limited by width: b*t*sqrt2 <= 1 -> t <= 1/(b*sqrt2)
                # and height: t*sqrt2 <= h_left -> t <= h_left/sqrt2
                t = min(1.0 / (b * math.sqrt(2)), h_left / math.sqrt(2))
                if t <= 0:
                    continue
                total = na * (1.0 / a) + b * t
                # build layout
                layout = []
                s = 1.0 / a
                for j in range(r):
                    for i in range(a):
                        layout.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                # tilted band placed above
                y0 = h_axis
                for i in range(b):
                    cx = (i + 0.5) * t * math.sqrt(2)
                    cy = y0 + t * math.sqrt(2) / 2.0
                    if cx - t * math.sqrt(2) / 2 < -1e-9 or cx + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    if cy + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    layout.append((cx, cy, 0.125, t))
                if len(layout) >= n:
                    consider(layout)

    # ---- Family C: column version of B ----
    for c in range(1, n + 1):
        for a in range(1, n + 1):
            na = c * a
            if na > n:
                continue
            w_axis = c * (1.0 / a)
            if w_axis >= 1.0:
                continue
            w_left = 1.0 - w_axis
            for b in range(1, n - na + 1):
                t = min(1.0 / (b * math.sqrt(2)), w_left / math.sqrt(2))
                if t <= 0:
                    continue
                layout = []
                s = 1.0 / a
                for i in range(c):
                    for j in range(a):
                        layout.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                x0 = w_axis
                for j in range(b):
                    cy = (j + 0.5) * t * math.sqrt(2)
                    cx = x0 + t * math.sqrt(2) / 2.0
                    if cx + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    if cy + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    layout.append((cx, cy, 0.125, t))
                if len(layout) >= n:
                    consider(layout)

    # ---- Family D: multi-scale guillotine with uniform blocks (original) ----
    def pack_in_rect(x0, y0, x1, y1, remaining, out):
        w = x1 - x0
        h = y1 - y0
        if remaining <= 0 or w <= 1e-12 or h <= 1e-12:
            return 0
        best_block = None
        best_score = -1.0
        maxk = min(20, remaining)
        for k in range(1, maxk + 1):
            for m in range(1, min(20, remaining // k) + 1):
                if k * m > remaining:
                    continue
                s = min(w / k, h / m)
                score = k * m * s
                if score > best_score:
                    best_score = score
                    best_block = (k, m, s)
        if best_block is None:
            return 0
        k, m, s = best_block
        for i in range(k):
            for j in range(m):
                out.append((x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, 0.0, s))
        placed = k * m
        rem = remaining - placed
        if rem == 0:
            return placed
        used_w = k * s
        used_h = m * s
        rem_placed = 0
        if w - used_w > 1e-12:
            rem_placed += pack_in_rect(x0 + used_w, y0, x1, y0 + used_h,
                                       rem - rem_placed, out)
        if rem_placed < rem and h - used_h > 1e-12:
            rem_placed += pack_in_rect(x0, y0 + used_h, x1, y1,
                                       rem - rem_placed, out)
        return placed + rem_placed

    out = []
    pack_in_rect(0.0, 0.0, 1.0, 1.0, n, out)
    consider(out)

    if best is None:
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best = best[:n]
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))

    return best
