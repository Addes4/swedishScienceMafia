# EVOLVE-BLOCK-START
"""Heuristic packing: build a good initial layout, then locally grow each square
while keeping interiors disjoint (separating-axis test)."""
import math
import random


def _overlap(a, b):
    """Return True if two squares (cx,cy,angle,side) overlap in interiors."""
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0.0 or bsz <= 0.0:
        return False
    ta = aa * 2.0 * math.pi
    tb = ba * 2.0 * math.pi
    ca, sa = math.cos(ta), math.sin(ta)
    cb, sb = math.cos(tb), math.sin(tb)
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    # half-extents projected on each axis
    ra = asz * 0.5 * (abs(ca * ca + sa * sa))
    for ux, uy in axes:
        pa = abs((ax - bx) * ux + (ay - by) * uy)
        # projection radius of square a on axis
        eax = asz * 0.5 * (abs(ca * ux + sa * uy) + abs(-sa * ux + ca * uy))
        ebx = bsz * 0.5 * (abs(cb * ux + sb * uy) + abs(-sb * ux + cb * uy))
        if pa >= eax + ebx - 1e-12:
            return False
    return True


def _inside(sq, eps=1e-9):
    cx, cy, ang, s = sq
    if s <= 0.0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    t = ang * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    for dx, dy in ((h, h), (h, -h), (-h, h), (-h, -h)):
        x = cx + dx * c - dy * sn
        y = cy + dx * sn + dy * c
        if not (eps <= x <= 1.0 - eps and eps <= y <= 1.0 - eps):
            return False
    return True


def _valid(sq, others):
    if not _inside(sq):
        return False
    for o in others:
        if _overlap(sq, o):
            return False
    return True


def _initial(n):
    """Start from an (m) x (m) grid where m*n close to n, plus extra squares."""
    best = None
    best_val = -1.0
    for k in range(1, n + 1):
        if k * k > n:
            break
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        squares = squares[:n]
        val = sum(s[3] for s in squares)
        if val > best_val:
            best_val = val
            best = squares
    return best


def _grow(squares, n, iters=4000):
    """Coordinate-descent: try to enlarge each square."""
    rng = random.Random(12345 + n)
    # Order squares; try to grow small ones first
    idxs = list(range(n))
    for _ in range(iters):
        i = idxs[rng.randrange(n)]
        cx, cy, ang, s = squares[i]
        others = squares[:i] + squares[i + 1:]
        # try increasing side
        step = 0.5
        improved = False
        while step > 1e-4:
            ns = s + step
            cand = (cx, cy, ang, ns)
            if _valid(cand, others):
                s = ns
                improved = True
            else:
                step *= 0.5
        # try small random perturbation of position/angle then regrow
        if not improved and rng.random() < 0.5:
            d = 0.02
            dx = (rng.random() - 0.5) * d
            dy = (rng.random() - 0.5) * d
            da = (rng.random() - 0.5) * 0.1
            cand = (cx + dx, cy + dy, ang + da, s)
            if _valid(cand, others):
                cx, cy, ang = cand[0], cand[1], cand[2]
        squares[i] = (cx, cy, ang, s)
    return squares


def solve(n):
    squares = _initial(n)
    squares = _grow(squares, n)
    # clamp / sanitize
    out = []
    for cx, cy, ang, s in squares:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        s = max(0.0, s)
        out.append((cx, cy, ang, s))
    return out[:n]
# EVOLVE-BLOCK-END

