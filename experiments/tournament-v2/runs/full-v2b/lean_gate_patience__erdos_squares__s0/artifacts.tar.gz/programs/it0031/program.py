import math


def solve(n):
    """Multi-scale guillotine packing with greedy block sizes."""
    best = None
    best_val = -1.0

    def make_block(cx, cy, side, cnt):
        # cnt squares of equal side in a near-square grid inside a cell of size side*cnt
        # For a cell of area enough to hold cnt unit-scaled squares.
        pass

    # Represent layout choices by recursive partition (splits) and block fillings.
    # We search over simple guillotine cuts producing cells; fill each cell with
    # a grid of equal squares of a size adapted to the cell dimensions.

    def pack_in_rect(x0, y0, x1, y1, remaining, out):
        """Greedily fill rectangle with count remaining squares, append to out.
        Returns number placed."""
        w = x1 - x0
        h = y1 - y0
        if remaining <= 0 or w <= 1e-12 or h <= 1e-12:
            return 0
        # choose block grid k x m maximizing total side = (k*m)*s where s=min(w/k,h/m)
        best_block = None
        best_score = -1.0
        maxk = min(30, remaining)
        for k in range(1, maxk + 1):
            for m in range(1, min(30, remaining // k) + 1):
                if k * m > remaining:
                    continue
                s = min(w / k, h / m)
                score = k * m * s
                if score > best_score:
                    best_score = score
                    best_block = (k, m, s)
        if best_block is None:
            return 0
        k, m, s = best_block
        # place k by m grid
        for i in range(k):
            for j in range(m):
                cx = x0 + (i + 0.5) * s
                cy = y0 + (j + 0.5) * s
                out.append((cx, cy, 0.0, s))
        placed = k * m
        rem = remaining - placed
        if rem == 0:
            return placed
        # split leftover region by guillotine: split along longer dimension
        used_w = k * s
        used_h = m * s
        # leftover strips
        rem_placed = 0
        if w - used_w > 1e-12:
            rem_placed += pack_in_rect(x0 + used_w, y0, x1, y0 + used_h, rem - rem_placed, out)
        if h - used_h > 1e-12:
            rem_placed += pack_in_rect(x0, y0 + used_h, x1, y1, rem - rem_placed, out)
        return placed + rem_placed

    # Try several guillotine partitions of the unit square
    def try_layout(split_mode):
        out = []
        # initial subdivision choices
        # mode 0: single rect
        # mode 1: split vertically then fill both halves
        # mode 2: split into k vertical strips
        # mode 3: recursive binary split
        if split_mode == 0:
            pack_in_rect(0.0, 0.0, 1.0, 1.0, n, out)
        elif split_mode == 1:
            # split into 2x2
            pack_in_rect(0.0, 0.0, 0.5, 0.5, n, out)
        elif split_mode == 2:
            pack_in_rect(0.0, 0.0, 1.0, 1.0, n, out)
        else:
            pack_in_rect(0.0, 0.0, 1.0, 1.0, n, out)
        # pad
        while len(out) < n:
            out.append((0.5, 0.5, 0.0, 0.0))
        return out[:n]

    candidates = []
    for mode in range(4):
        cand = try_layout(mode)
        val = sum(s for _, _, _, s in cand)
        if val > best_val:
            best_val = val
            best = cand

    # Also try simple grid baseline as fallback
    k = math.isqrt(n)
    side = 1.0 / k
    grid = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    grid += [(0.5, 0.5, 0.0, 0.0)] * (n - len(grid))
    val = sum(s for _, _, _, s in grid)
    if val > best_val:
        best = grid[:n]

    return best
