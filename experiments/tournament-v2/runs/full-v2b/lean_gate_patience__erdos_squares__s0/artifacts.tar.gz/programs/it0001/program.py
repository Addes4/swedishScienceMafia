# EVOLVE-BLOCK-START
"""Greedy guillotine packing of squares into the unit square.

We keep a list of free axis-aligned rectangles that partition (a subset of) the
unit square.  To place a square we take the free rectangle with the largest area,
cut out the largest square that fits inside it, and split the remaining L-shaped
region into two rectangles.  This adapts to every n and gives the biggest squares
where there is the most room.
"""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n == 0:
        return []

    # Free rectangles stored as (x0, y0, x1, y1).
    free = [(0.0, 0.0, 1.0, 1.0)]
    squares = []

    for _ in range(n):
        if not free:
            squares.append((0.5, 0.5, 0.0, 0.0))
            continue
        # Pick the free rectangle with the largest area.
        best = max(range(len(free)), key=lambda i: (free[i][2] - free[i][0]) * (free[i][3] - free[i][1]))
        x0, y0, x1, y1 = free.pop(best)
        w = x1 - x0
        h = y1 - y0
        s = min(w, h)
        # Place the square in a corner of the rectangle (bottom-left).
        cx = x0 + s / 2.0
        cy = y0 + s / 2.0
        squares.append((cx, cy, 0.0, s))
        # Split the leftover region into two rectangles.
        if w > h:
            # strip on the right
            free.append((x0 + s, y0, x1, y1))
            if h > 0:
                free.append((x0, y0 + s, x0 + s, y1))  # empty when h==s
        else:
            free.append((x0, y0 + s, x1, y1))
            if w > 0:
                free.append((x0 + s, y0, x1, y0 + s))
        # Drop degenerate rectangles.
        free = [r for r in free if r[2] - r[0] > 1e-12 and r[3] - r[1] > 1e-12]

    # Pad with zero-size squares if we somehow produced fewer than n.
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
# EVOLVE-BLOCK-END
