"""Multi-scale guillotine packing plus a fast numpy-vectorized polish."""

import math

import numpy as np
from scipy.optimize import minimize


def _best_block(n, w, h):
    if n <= 0:
        return 0.0, 0, 0
    best = (0.0, 1, 1)
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        s = min(w / cols, h / rows)
        if s > best[0]:
            best = (s, cols, rows)
    return best


def _corners(cx, cy, ang, s):
    t = ang * 2 * math.pi
    c = math.cos(t)
    sn = math.sin(t)
    h = s / 2
    return [
        (cx + c * h - sn * h, cy + sn * h + c * h),
        (cx + c * h + sn * h, cy + sn * h - c * h),
        (cx - c * h + sn * h, cy - sn * h - c * h),
        (cx - c * h - sn * h, cy - sn * h + c * h),
    ]


def _overlap(a, b):
    ax, ay, aa, asd = a
    bx, by, ba, bsd = b
    if asd <= 0 or bsd <= 0:
        return False
    ra = asd * 1.4143 / 2
    rb = bsd * 1.4143 / 2
    dx = ax - bx
    dy = ay - by
    if dx * dx + dy * dy > (ra + rb) ** 2:
        return False

    pa = _corners(ax, ay, aa, asd)
    pb = _corners(bx, by, ba, bsd)
    ta = aa * 2 * math.pi
    tb = ba * 2 * math.pi
    ca, sa = math.cos(ta), math.sin(ta)
    cb, sb = math.cos(tb), math.sin(tb)
    for ux, uy in [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]:
        amin = min(p[0] * ux + p[1] * uy for p in pa)
        amax = max(p[0] * ux + p[1] * uy for p in pa)
        bmin = min(p[0] * ux + p[1] * uy for p in pb)
        bmax = max(p[0] * ux + p[1] * uy for p in pb)
        if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
            return False
    return True


def _in_unit(cx, cy, ang, s):
    t = ang * 2 * math.pi
    c = abs(math.cos(t))
    sn = abs(math.sin(t))
    h = s / 2
    rx = c * h + sn * h
    ry = sn * h + c * h
    return cx - rx >= -1e-9 and cx + rx <= 1 + 1e-9 and cy - ry >= -1e-9 and cy + ry <= 1 + 1e-9


def _valid_layout(squares):
    n = len(squares)
    for i in range(n):
        cx, cy, ang, s = squares[i]
        if not (0 <= cx <= 1 and 0 <= cy <= 1 and 0 <= ang <= 1 and 0 <= s <= 1):
            return False
        if not _in_unit(cx, cy, ang, s):
            return False
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j]):
                return False
    return True


# ---------------------------------------------------------------------------
# Fast numpy helpers
# ---------------------------------------------------------------------------

def _np_corners(arr):
    """arr: (n,4) columns cx,cy,ang,s  ->  (n,4,2) corner coordinates."""
    cx = arr[:, 0]
    cy = arr[:, 1]
    ang = arr[:, 2]
    s = arr[:, 3]
    t = ang * 2.0 * np.pi
    c = np.cos(t)
    sn = np.sin(t)
    h = s / 2.0
    # local corner offsets (unit square corners scaled by h then rotated)
    ux = np.array([1.0, 1.0, -1.0, -1.0])
    uy = np.array([1.0, -1.0, -1.0, 1.0])
    ox = c[:, None] * ux[None, :] * h[:, None] - sn[:, None] * uy[None, :] * h[:, None]
    oy = sn[:, None] * ux[None, :] * h[:, None] + c[:, None] * uy[None, :] * h[:, None]
    return np.stack([cx[:, None] + ox, cy[:, None] + oy], axis=2)


def _np_in_unit_bool(arr):
    cx = arr[:, 0]
    cy = arr[:, 1]
    ang = arr[:, 2]
    s = arr[:, 3]
    t = ang * 2.0 * np.pi
    c = np.abs(np.cos(t))
    sn = np.abs(np.sin(t))
    h = s / 2.0
    rx = (c + sn) * h
    ry = (c + sn) * h
    return (s >= 0) & (cx - rx >= -1e-9) & (cx + rx <= 1 + 1e-9) & \
           (cy - ry >= -1e-9) & (cy + ry <= 1 + 1e-9)


def _np_no_overlap_bool(arr):
    """True if no pair of squares overlaps (SAT on all 4 corners axes each)."""
    n = arr.shape[0]
    if n < 2:
        return True
    corners = _np_corners(arr)              # (n,4,2)
    t = arr[:, 2] * 2.0 * np.pi
    c = np.cos(t)
    sn = np.sin(t)
    # axes per square: two edge normals (the square's own axes)
    axes = np.stack([np.stack([c, sn], axis=1),
                     np.stack([-sn, c], axis=1)], axis=1)  # (n,2,2)

    for i in range(n):
        ci = corners[i]                      # (4,2)
        ai = axes[i]                         # (2,2)
        for j in range(i + 1, n):
            cj = corners[j]
            aj = axes[j]
            # bounding radius quick reject
            if ((arr[i, 0] - arr[j, 0]) ** 2 + (arr[i, 1] - arr[j, 1]) ** 2) > \
                    ((arr[i, 3] + arr[j, 3]) * 1.4143 / 2.0) ** 2:
                continue
            sep = False
            for u in (ai[0], ai[1], aj[0], aj[1]):
                pi = ci @ u
                pj = cj @ u
                if pi.max() <= pj.min() + 1e-12 or pj.max() <= pi.min() + 1e-12:
                    sep = True
                    break
            if not sep:
                return False
    return True


def _np_valid(arr):
    if arr.shape[0] == 0:
        return True
    if not np.all(np.isfinite(arr)):
        return False
    if np.any(arr[:, 0] < -1e-9) or np.any(arr[:, 0] > 1 + 1e-9):
        return False
    if np.any(arr[:, 1] < -1e-9) or np.any(arr[:, 1] > 1 + 1e-9):
        return False
    if np.any(arr[:, 3] < -1e-9) or np.any(arr[:, 3] > 1 + 1e-9):
        return False
    if not np.all(_np_in_unit_bool(arr)):
        return False
    return _np_no_overlap_bool(arr)


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

def _construct(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    leaves = [(0.0, 0.0, 1.0, 1.0, n)]

    for _ in range(400):
        best_gain = 0.0
        best_idx = -1
        best_partition = None

        for idx, (x, y, w, h, cnt) in enumerate(leaves):
            if cnt < 2:
                continue
            cur_side, _, _ = _best_block(cnt, w, h)
            cur_val = cnt * cur_side
            horizontal_split = w >= h
            for a in range(1, cnt):
                b = cnt - a
                frac = math.sqrt(a) / (math.sqrt(a) + math.sqrt(b))
                frac = min(max(frac, 1e-3), 1 - 1e-3)
                if horizontal_split:
                    w1 = w * frac
                    w2 = w - w1
                    s1, _, _ = _best_block(a, w1, h)
                    s2, _, _ = _best_block(b, w2, h)
                    kind = 'v'
                else:
                    h1 = h * frac
                    h2 = h - h1
                    s1, _, _ = _best_block(a, w, h1)
                    s2, _, _ = _best_block(b, w, h2)
                    kind = 'h'
                val = a * s1 + b * s2
                gain = val - cur_val
                if gain > best_gain:
                    best_gain = gain
                    best_idx = idx
                    best_partition = (a, b, kind, frac)

        if best_idx < 0 or best_gain <= 1e-12:
            break

        x, y, w, h, cnt = leaves[best_idx]
        a, b, kind, frac = best_partition
        if kind == 'v':
            w1 = w * frac
            leaves[best_idx] = (x, y, w1, h, a)
            leaves.append((x + w1, y, w - w1, h, b))
        else:
            h1 = h * frac
            leaves[best_idx] = (x, y, w, h1, a)
            leaves.append((x, y + h1, w, h - h1, b))

    result = []
    for (x, y, w, h, cnt) in leaves:
        side, cols, rows = _best_block(cnt, w, h)
        if side <= 0:
            result += [(x + w / 2, y + h / 2, 0.0, 0.0)] * cnt
            continue
        gw = cols * side
        gh = rows * side
        ox = x + (w - gw) / 2
        oy = y + (h - gh) / 2
        placed = 0
        for i in range(cols):
            for j in range(rows):
                placed += 1
                cx = ox + (i + 0.5) * side
                cy = oy + (j + 0.5) * side
                result.append((cx, cy, 0.0, side))
        while placed < cnt:
            result.append((x + w / 2, y + h / 2, 0.0, 0.0))
            placed += 1

    result = result[:n]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result


def _to_arr(squares):
    return np.array(squares, dtype=float).reshape(-1, 4)


def _from_arr(arr):
    out = []
    for cx, cy, ang, s in arr:
        out.append((float(min(max(cx, 0.0), 1.0)),
                    float(min(max(cy, 0.0), 1.0)),
                    float(ang % 1.0),
                    float(min(max(s, 0.0), 1.0))))
    return out


# ---------------------------------------------------------------------------
# SLSQP polish
# ---------------------------------------------------------------------------

def _slsqp_polish(squares, maxiter=400, free_angle=False, angle_perturb=0.0):
    n = len(squares)
    if n == 0:
        return squares
    k = 4 if free_angle else 3
    x0 = []
    for idx, (cx, cy, ang, s) in enumerate(squares):
        x0.append(cx)
        x0.append(cy)
        x0.append(s)
        if free_angle:
            a = (ang + angle_perturb) % 1.0
            x0.append(a)
    x0 = [min(max(v, 0.0), 1.0) for v in x0]

    def neg_sum(x):
        return -sum(x[k * i + 2] for i in range(n))

    def neg_grad(x):
        g = [0.0] * (k * n)
        for i in range(n):
            g[k * i + 2] = -1.0
        return g

    def constraints_bounds(x):
        c = []
        for i in range(n):
            cx = x[k * i]
            cy = x[k * i + 1]
            s = x[k * i + 2]
            if free_angle:
                t = x[k * i + 3] * 2 * math.pi
                ca = abs(math.cos(t))
                sa = abs(math.sin(t))
                rx = (ca + sa) * s / 2
                ry = (ca + sa) * s / 2
            else:
                rx = s / 2
                ry = s / 2
            c.append(cx - rx)
            c.append(1 - cx - rx)
            c.append(cy - ry)
            c.append(1 - cy - ry)
        return c

    cons = [{'type': 'ineq', 'fun': constraints_bounds}]

    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]

    def pair_constraints(x):
        c = []
        for (i, j) in pairs:
            cxi, cyi, si = x[k * i], x[k * i + 1], x[k * i + 2]
            cxj, cyj, sj = x[k * j], x[k * j + 1], x[k * j + 2]
            if free_angle:
                ti = x[k * i + 3] * 2 * math.pi
                tj = x[k * j + 3] * 2 * math.pi
                norms = [(math.cos(ti), math.sin(ti)), (-math.sin(ti), math.cos(ti)),
                         (math.cos(tj), math.sin(tj)), (-math.sin(tj), math.cos(tj))]
                best = -1e18
                for ux, uy in norms:
                    ri = (abs(math.cos(ti) * ux + math.sin(ti) * uy) +
                          abs(-math.sin(ti) * ux + math.cos(ti) * uy)) * si / 2
                    rj = (abs(math.cos(tj) * ux + math.sin(tj) * uy) +
                          abs(-math.sin(tj) * ux + math.cos(tj) * uy)) * sj / 2
                    proj = abs((cxi - cxj) * ux + (cyi - cyj) * uy)
                    best = max(best, proj - ri - rj)
            else:
                dx_sep = abs(cxi - cxj) - (si + sj) / 2
                dy_sep = abs(cyi - cyj) - (si + sj) / 2
                best = max(dx_sep, dy_sep)
            c.append(best)
        return c

    cons.append({'type': 'ineq', 'fun': pair_constraints})

    try:
        res = minimize(neg_sum, x0, jac=neg_grad, constraints=cons,
                       method='SLSQP', options={'maxiter': maxiter, 'ftol': 1e-11})
        x = res.x
    except Exception:
        return squares

    out = []
    for i in range(n):
        ang = (float(x[k * i + 3]) % 1.0) if free_angle else squares[i][2]
        out.append((float(x[k * i]), float(x[k * i + 1]), ang,
                    float(x[k * i + 2])))
    out = [(min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0),
            ang % 1.0, min(max(s, 0.0), 1.0)) for (cx, cy, ang, s) in out]
    return out


# ---------------------------------------------------------------------------
# Fast grow-and-nudge local search using numpy validity
# ---------------------------------------------------------------------------

def _fast_valid(arr):
    return _np_valid(arr)


def _cd_polish_fast(arr, iters=40, step=0.03, grow=True):
    """arr: (n,4) numpy array of a valid layout.  Deterministic growth search."""
    arr = arr.copy()
    n = arr.shape[0]
    if n == 0:
        return arr

    def ok(test):
        return _np_valid(test)

    # first: greedily grow every square (respecting all constraints)
    if grow:
        improved = True
        rounds = 0
        while improved and rounds < iters:
            improved = False
            rounds += 1
            for i in range(n):
                for ds in (step, step / 2, step / 4, step / 8):
                    trial = arr.copy()
                    trial[i, 3] += ds
                    if trial[i, 3] > 1.0:
                        continue
                    if ok(trial):
                        arr = trial
                        improved = True
                        break

    # nudge step: small translation / rotation attempts to open room
    rng = np.random.RandomState(12345)
    for _ in range(iters):
        improved = False
        # sort indices by side ascending so small squares get room to move
        order = np.argsort(arr[:, 3])
        for i in order:
            i = int(i)
            best_trial = None
            # try translating
            for ddx, ddy in ((0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01),
                             (0.005, 0.005), (-0.005, 0.005),
                             (0.005, -0.005), (-0.005, -0.005)):
                trial = arr.copy()
                trial[i, 0] = min(max(trial[i, 0] + ddx, 0.0), 1.0)
                trial[i, 1] = min(max(trial[i, 1] + ddy, 0.0), 1.0)
                if ok(trial):
                    best_trial = trial
                    break
            # try rotating slightly
            if best_trial is None:
                for da in (0.01, -0.01, 0.02, -0.02, 0.005, -0.005):
                    trial = arr.copy()
                    trial[i, 2] = (trial[i, 2] + da) % 1.0
                    if ok(trial):
                        best_trial = trial
                        break
            if best_trial is not None:
                arr = best_trial
                improved = True
        # after nudging, try growing again
        for i in range(n):
            for ds in (step, step / 2, step / 4):
                trial = arr.copy()
                trial[i, 3] += ds
                if trial[i, 3] > 1.0:
                    continue
                if ok(trial):
                    arr = trial
                    improved = True
                    break
        if not improved:
            break
    return arr


# ---------------------------------------------------------------------------
# Seeds
# ---------------------------------------------------------------------------

def _seeds(n):
    seeds = []
    base = _construct(n)
    seeds.append(_to_arr(base))
    # uniform grids
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        s = min(1.0 / cols, 1.0 / rows)
        if s <= 0:
            continue
        gw = cols * s
        gh = rows * s
        ox = (1 - gw) / 2
        oy = (1 - gh) / 2
        placed = 0
        sq = []
        for i in range(cols):
            for j in range(rows):
                if placed >= n:
                    break
                sq.append((ox + (i + 0.5) * s, oy + (j + 0.5) * s, 0.0, s))
                placed += 1
            if placed >= n:
                break
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        seeds.append(_to_arr(sq[:n]))
    # a few angle-perturbed versions of base
    b = _to_arr(base)
    for off in (0.125, 0.0625, 0.25):
        v = b.copy()
        v[:, 2] = (v[:, 2] + off) % 1.0
        seeds.append(v)
    return seeds


def _score_arr(arr):
    return float(np.sum(arr[:, 3]))


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_arr = None
    best_val = -1.0

    def consider(arr):
        nonlocal best_arr, best_val
        a = np.clip(arr.copy(), 0.0, 1.0)
        a[:, 2] = a[:, 2] % 1.0
        if not _np_valid(a):
            return
        v = _score_arr(a)
        if v > best_val:
            best_val = v
            best_arr = a.copy()

    seeds = _seeds(n)

    # SLSQP-polished candidates (free-angle takes longer but is strong)
    for seed in seeds[:6]:
        sq = _from_arr(seed)
        consider(_to_arr(_slsqp_polish(sq, maxiter=250, free_angle=False)))

    for seed in seeds[:4]:
        sq = _from_arr(seed)
        for off in (0.0, 0.0625):
            consider(_to_arr(_slsqp_polish(sq, maxiter=300, free_angle=True,
                                           angle_perturb=off)))

    # fast coordinate-descent on seeds and on SLSQP outputs
    sources = []
    for seed in seeds:
        sources.append(seed)
    if best_arr is not None:
        sources.append(best_arr)
        sources.append(_to_arr(_slsqp_polish(_from_arr(best_arr), maxiter=200,
                                             free_angle=False)))

    for src in sources:
        a = _cd_polish_fast(src, iters=30, step=0.03)
        consider(a)
        # shrink-repair escape
        shrunk = a.copy()
        shrunk[:, 3] *= 0.92
        a2 = _cd_polish_fast(shrunk, iters=40, step=0.03)
        consider(a2)

    if best_arr is None:
        best_arr = _to_arr(_construct(n))
        best_arr = np.clip(best_arr, 0.0, 1.0)
        best_arr[:, 2] = best_arr[:, 2] % 1.0

    out = _from_arr(best_arr)
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
