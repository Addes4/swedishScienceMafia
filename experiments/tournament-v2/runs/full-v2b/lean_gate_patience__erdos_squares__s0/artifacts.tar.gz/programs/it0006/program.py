# EVOLVE-BLOCK-START
"""Structured layout search plus a robust simulated-annealing packer."""
import math
import random


def _vertices(cx, cy, ang, s):
    c, sn = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _overlap(A, B):
    for poly in (A, B):
        n = len(poly)
        for k in range(n):
            x1, y1 = poly[k]
            x2, y2 = poly[(k + 1) % n]
            ax, ay = -(y2 - y1), (x2 - x1)
            projA = [ax * p[0] + ay * p[1] for p in A]
            projB = [ax * p[0] + ay * p[1] for p in B]
            if max(projA) < min(projB) + 1e-9 or max(projB) < min(projA) + 1e-9:
                return False
    return True


def _feasible(sqs):
    boxes = []
    for (cx, cy, ang, s) in sqs:
        if s <= 1e-12:
            continue
        if cx < -1e-9 or cx > 1 + 1e-9 or cy < -1e-9 or cy > 1 + 1e-9:
            return False
        v = _vertices(cx, cy, ang, s)
        xs = [p[0] for p in v]
        ys = [p[1] for p in v]
        if min(xs) < -1e-9 or max(xs) > 1 + 1e-9 or min(ys) < -1e-9 or max(ys) > 1 + 1e-9:
            return False
        boxes.append(v)
    m = len(boxes)
    for i in range(m):
        for j in range(i + 1, m):
            if _overlap(boxes[i], boxes[j]):
                return False
    return True


def _grid(k):
    res = []
    if k <= 0:
        return res
    s = 1.0 / k
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    return res


def _greedy_split(cx0, cy0, w, h, remaining):
    rects = [(cx0, cy0, w, h)]
    out = []
    for _ in range(remaining):
        best_i = -1
        best_s = 0.0
        for i, (x, y, rw, rh) in enumerate(rects):
            s = min(rw, rh)
            if s > best_s + 1e-12:
                best_s = s
                best_i = i
        if best_i < 0 or best_s <= 1e-12:
            break
        x, y, rw, rh = rects.pop(best_i)
        s = best_s
        out.append((x + s * 0.5, y + s * 0.5, 0.0, s))
        if rw - s > rh - s:
            if rw - s > 1e-12:
                rects.append((x + s, y, rw - s, rh))
            if rh - s > 1e-12:
                rects.append((x, y + s, s, rh - s))
        else:
            if rh - s > 1e-12:
                rects.append((x, y + s, rw, rh - s))
            if rw - s > 1e-12:
                rects.append((x + s, y, rw - s, s))
    return out


def _make_layout(n, k):
    base = _grid(k)
    used = len(base)
    if used > n:
        return base[:n]
    rem = n - used
    if rem <= 0:
        return base[:n]
    best = None
    best_sum = -1
    for frac in (0.4, 0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 0.98, 1.0):
        s = frac / k
        strip_h = 1.0 - k * s
        if strip_h <= 1e-9:
            continue
        cand = []
        for i in range(k):
            for j in range(k):
                cand.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        extra = _greedy_split(0.0, k * s, 1.0, strip_h, rem)
        cand += extra
        if len(cand) < n:
            continue
        tot = sum(c[3] for c in cand)
        if tot > best_sum:
            best_sum = tot
            best = cand
    if best is None:
        best = base
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]


def _anneal(init, n, time_budget_iters=60000):
    """Simulated-annealing style packer greedy on total size."""
    sqs = [list(s) for s in init]
    while len(sqs) < n:
        sqs.append([0.5, 0.5, 0.0, 0.0])
    sqs = sqs[:n]

    m = len(sqs)

    def total():
        return sum(s[3] for s in sqs)

    def ok(idx, cand):
        old = sqs[idx]
        sqs[idx] = cand
        res = _feasible(sqs)
        if not res:
            sqs[idx] = old
        return res

    # First: aggressive growth phase
    for phase in range(3):
        for _ in range(3000):
            improved = False
            order = list(range(m))
            random.shuffle(order)
            for i in order:
                s = sqs[i][3]
                # try grow
                for ds in (0.05, 0.02, 0.01, 0.005, 0.002, 0.001):
                    cand = [sqs[i][0], sqs[i][1], sqs[i][2], s + ds]
                    if ok(i, cand):
                        improved = True
                        break
                # try move+rotate to make room
                for _t in range(6):
                    dx = random.uniform(-0.03, 0.03)
                    dy = random.uniform(-0.03, 0.03)
                    da = random.uniform(-0.05, 0.05)
                    cand = [sqs[i][0] + dx, sqs[i][1] + dy, sqs[i][2] + da, sqs[i][3]]
                    if ok(i, cand):
                        improved = True
                        break
            if not improved:
                break

    # Second: global perturbation-restart hill climb
    best = [s[:] for s in sqs]
    best_tot = total()
    T0 = 0.02
    for it in range(20000):
        T = T0 * (1.0 - it / 20000.0) + 0.0005
        i = random.randrange(m)
        old = sqs[i][:]
        scale = 0.04 * (1.0 - it / 20000.0) + 0.005
        if random.random() < 0.5:
            # perturb + grow
            cand = [old[0] + random.uniform(-scale, scale),
                    old[1] + random.uniform(-scale, scale),
                    old[2] + random.uniform(-0.05, 0.05),
                    max(0.0, old[3] + random.uniform(-scale, scale))]
        else:
            cand = [old[0], old[1], old[2], max(0.0, old[3] + random.uniform(0, scale))]
        if cand[0] < 0 or cand[0] > 1 or cand[1] < 0 or cand[1] > 1:
            continue
        if ok(i, cand):
            t = total()
            if t > best_tot:
                best_tot = t
                best = [s[:] for s in sqs]
        else:
            # accept slightly worse occasionally (very rarely here, feasibility-driven)
            pass

    return [(s[0], s[1], s[2], s[3]) for s in best]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    k0 = max(1, math.isqrt(n))
    candidates = []
    for k in range(max(1, k0 - 2), k0 + 3):
        g = _grid(k)
        if len(g) >= n:
            candidates.append(g[:n])
        lay = _make_layout(n, k)
        if len(lay) == n:
            candidates.append(lay)

    best = None
    best_score = -1
    for cand in candidates:
        if len(cand) < n:
            cand = cand + [(0.5, 0.5, 0.0, 0.0)] * (n - len(cand))
        cand = cand[:n]
        if not _feasible(cand):
            continue
        sc = sum(c[3] for c in cand)
        if sc > best_score:
            best_score = sc
            best = cand

    if best is None:
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    # Run the annealer from the best structured layout (and a couple of variants).
    try:
        seeds = [best]
        for k in range(max(1, k0 - 2), k0 + 3):
            g = _grid(k)
            if len(g) >= n:
                seeds.append(g[:n])
        results = []
        for sd in seeds:
            random.seed(12345 + n + len(sd))
            r = _anneal(sd, n)
            if _feasible(r):
                results.append(r)
        if results:
            results.sort(key=lambda r: sum(c[3] for c in r), reverse=True)
            if sum(c[3] for c in results[0]) >= best_score - 1e-9:
                best = results[0]
    except Exception:
        pass

    return best[:n]
# EVOLVE-BLOCK-END

