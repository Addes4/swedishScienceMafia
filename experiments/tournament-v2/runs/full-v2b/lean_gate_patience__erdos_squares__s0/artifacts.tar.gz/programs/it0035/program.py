import math

try:
    import numpy as np
    from scipy.optimize import minimize
    _HAVE_SCIPY = True
except Exception:
    _HAVE_SCIPY = False


def _to_params(layout, n):
    p = np.zeros(4 * n)
    for i, (cx, cy, a, s) in enumerate(layout):
        p[4 * i] = cx
        p[4 * i + 1] = cy
        p[4 * i + 2] = a
        p[4 * i + 3] = s
    return p


def _from_params(p, n):
    out = []
    for i in range(n):
        out.append((float(p[4 * i]), float(p[4 * i + 1]),
                    float(p[4 * i + 2]) % 1.0, float(max(0.0, p[4 * i + 3]))))
    return out


def _axes(ang):
    # two orthogonal unit edge directions of a square rotated by fraction ang
    th = 2.0 * math.pi * ang
    c = math.cos(th)
    s = math.sin(th)
    return (c, s), (-s, c)


def _corners(cx, cy, ang, side):
    (ax, ay), (bx, by) = _axes(ang)
    h = side / 2.0
    pts = []
    for sx, sy in ((1, 1), (1, -1), (-1, -1), (-1, 1)):
        pts.append((cx + sx * h * ax + sy * h * bx,
                    cy + sx * h * ay + sy * h * by))
    return pts


def _max_violation(layout):
    n = len(layout)
    worst = 0.0
    boxes = []
    for (cx, cy, ang, side) in layout:
        cs = _corners(cx, cy, ang, side)
        (ax, ay), (bx, by) = _axes(ang)
        boxes.append((cs, (ax, ay), (bx, by), side))
    for i in range(n):
        ci, ai, bi, si = boxes[i]
        for k in range(i + 1, n):
            cj, aj, bj, sj = boxes[k]
            # separating axes: ai, bi, aj, bj
            for (ux, uy) in (ai, bi, aj, bj):
                mini = min(px * ux + py * uy for px, py in ci)
                maxi = max(px * ux + py * uy for px, py in ci)
                minj = min(px * ux + py * uy for px, py in cj)
                maxj = max(px * ux + py * uy for px, py in cj)
                gap = max(mini - maxj, minj - maxi)
                if gap > 1e-9:
                    break
            else:
                # overlapping: compute penetration as the min overlap over axes
                pen = None
                for (ux, uy) in (ai, bi, aj, bj):
                    mini = min(px * ux + py * uy for px, py in ci)
                    maxi = max(px * ux + py * uy for px, py in ci)
                    minj = min(px * ux + py * uy for px, py in cj)
                    maxj = max(px * ux + py * uy for px, py in cj)
                    ov = min(maxi - minj, maxj - mini)
                    if ov < 0:
                        ov = 0.0
                    pen = ov if pen is None else min(pen, ov)
                if pen is None:
                    pen = 0.0
                if pen > worst:
                    worst = pen
    return worst


def _penalty(layout, w):
    n = len(layout)
    total = 0.0
    boxes = []
    for (cx, cy, ang, side) in layout:
        cs = _corners(cx, cy, ang, side)
        (ax, ay), (bx, by) = _axes(ang)
        boxes.append((cs, (ax, ay), (bx, by)))
    for i in range(n):
        ci, ai, bi = boxes[i]
        for k in range(i + 1, n):
            cj, aj, bj = boxes[k]
            # SAT: min overlap over the 4 axes; if any gap>0 they are separated
            min_overlap = None
            separated = False
            for (ux, uy) in (ai, bi, aj, bj):
                mini = min(px * ux + py * uy for px, py in ci)
                maxi = max(px * ux + py * uy for px, py in ci)
                minj = min(px * ux + py * uy for px, py in cj)
                maxj = max(px * ux + py * uy for px, py in cj)
                gap = max(mini - maxj, minj - maxi)
                if gap > 0:
                    separated = True
                    break
                ov = min(maxi - minj, maxj - mini)
                min_overlap = ov if min_overlap is None else min(min_overlap, ov)
            if not separated:
                total += (min_overlap if min_overlap else 0.0) ** 2
    for i in range(n):
        cx, cy, ang, side = layout[i]
        for px, py in boxes[i][0]:
            if px < 0:
                total += w * px * px
            elif px > 1:
                total += w * (px - 1) ** 2
            if py < 0:
                total += w * py * py
            elif py > 1:
                total += w * (py - 1) ** 2
    return total


def solve(n):
    best = None
    best_val = -1.0

    def consider(layout):
        nonlocal best, best_val
        if len(layout) < n:
            layout = layout + [(0.5, 0.5, 0.0, 0.0)] * (n - len(layout))
        layout = layout[:n]
        val = sum(s for _, _, _, s in layout)
        if val > best_val:
            best_val = val
            best = layout

    # ---- Family A: uniform grid ----
    for k in range(1, n + 1):
        if k * k <= n:
            s = 1.0 / k
            g = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                 for i in range(k) for j in range(k)]
            consider(g)

    # ---- Family B: axis rows + tilted band above ----
    for r in range(1, n + 1):
        for a in range(1, n + 1):
            na = r * a
            if na > n:
                continue
            h_axis = r * (1.0 / a)
            if h_axis >= 1.0:
                continue
            h_left = 1.0 - h_axis
            for b in range(1, n - na + 1):
                t = min(1.0 / (b * math.sqrt(2)), h_left / math.sqrt(2))
                if t <= 0:
                    continue
                layout = []
                s = 1.0 / a
                for j in range(r):
                    for i in range(a):
                        layout.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                y0 = h_axis
                for i in range(b):
                    cx = (i + 0.5) * t * math.sqrt(2)
                    cy = y0 + t * math.sqrt(2) / 2.0
                    if cx - t * math.sqrt(2) / 2 < -1e-9 or cx + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    if cy + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    layout.append((cx, cy, 0.125, t))
                if len(layout) >= n:
                    consider(layout)

    # ---- Family C: axis cols + tilted band right ----
    for c in range(1, n + 1):
        for a in range(1, n + 1):
            na = c * a
            if na > n:
                continue
            w_axis = c * (1.0 / a)
            if w_axis >= 1.0:
                continue
            w_left = 1.0 - w_axis
            for b in range(1, n - na + 1):
                t = min(1.0 / (b * math.sqrt(2)), w_left / math.sqrt(2))
                if t <= 0:
                    continue
                layout = []
                s = 1.0 / a
                for i in range(c):
                    for j in range(a):
                        layout.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                x0 = w_axis
                for j in range(b):
                    cy = (j + 0.5) * t * math.sqrt(2)
                    cx = x0 + t * math.sqrt(2) / 2.0
                    if cx + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    if cy + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    layout.append((cx, cy, 0.125, t))
                if len(layout) >= n:
                    consider(layout)

    # ---- Family D: guillotine multi-scale ----
    def pack_in_rect(x0, y0, x1, y1, remaining, out):
        w = x1 - x0
        h = y1 - y0
        if remaining <= 0 or w <= 1e-12 or h <= 1e-12:
            return 0
        best_block = None
        best_score = -1.0
        maxk = min(20, remaining)
        for k in range(1, maxk + 1):
            for m in range(1, min(20, remaining // k) + 1):
                if k * m > remaining:
                    continue
                s = min(w / k, h / m)
                score = k * m * s
                if score > best_score:
                    best_score = score
                    best_block = (k, m, s)
        if best_block is None:
            return 0
        k, m, s = best_block
        for i in range(k):
            for j in range(m):
                out.append((x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, 0.0, s))
        placed = k * m
        rem = remaining - placed
        if rem == 0:
            return placed
        used_w = k * s
        used_h = m * s
        rem_placed = 0
        if w - used_w > 1e-12:
            rem_placed += pack_in_rect(x0 + used_w, y0, x1, y0 + used_h,
                                       rem - rem_placed, out)
        if rem_placed < rem and h - used_h > 1e-12:
            rem_placed += pack_in_rect(x0, y0 + used_h, x1, y1,
                                       rem - rem_placed, out)
        return placed + rem_placed

    out = []
    pack_in_rect(0.0, 0.0, 1.0, 1.0, n, out)
    consider(out)

    if best is None:
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best = best[:n]
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))
        best_val = sum(s for _, _, _, s in best)

    # ---- Polish with scipy SLSQP ----
    if _HAVE_SCIPY:
        # candidate starting sets: keep the best layout and a couple of variants
        starts = [best]
        # also try the pure-"all tilted grid" when n is a perfect square-ish
        k = max(1, int(math.isqrt(n)))
        if k * k >= n:
            t = 1.0 / (k * math.sqrt(2))
            g = []
            for i in range(k):
                for j in range(k):
                    g.append((0.5 + (i + 0.5 - k / 2.0) * t * math.sqrt(2),
                              0.5 + (j + 0.5 - k / 2.0) * t * math.sqrt(2),
                              0.125, t))
            starts.append(g[:n])
        for start in starts:
            p0 = _to_params(start, n)
            try:
                res = minimize(
                    lambda p: _penalty(_from_params(p, n), 1000.0),
                    p0, method='SLSQP',
                    options={'maxiter': 300, 'ftol': 1e-12})
                cand = _from_params(res.x, n)
            except Exception:
                continue
            if _max_violation(cand) < 1e-6:
                # clamp inside unit square
                fixed = []
                ok = True
                for (cx, cy, ang, side) in cand:
                    cs = _corners(cx, cy, ang, side)
                    if any(px < -1e-7 or px > 1 + 1e-7 or py < -1e-7 or py > 1 + 1e-7
                           for px, py in cs):
                        ok = False
                        break
                    fixed.append((cx, cy, ang, side))
                if ok:
                    consider(fixed)

    return best
