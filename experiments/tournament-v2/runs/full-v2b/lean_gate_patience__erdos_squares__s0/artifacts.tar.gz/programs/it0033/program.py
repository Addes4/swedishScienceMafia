import math
import numpy as np


def _overlap_ok(layout, tol=1e-9):
    n = len(layout)
    if n < 2:
        return True
    cs = np.cos(2 * math.pi * np.array([a for _, _, a, _ in layout]))
    sn = np.sin(2 * math.pi * np.array([a for _, _, a, _ in layout]))
    cx = np.array([c[0] for c in layout])
    cy = np.array([c[1] for c in layout])
    s = np.array([c[3] for c in layout])
    ux = np.stack([cs, sn], axis=1)   # local x axis
    uy = np.stack([-sn, cs], axis=1)  # local y axis
    for i in range(n):
        for j in range(i + 1, n):
            axes = (ux[i], uy[i], ux[j], uy[j])
            d = np.array([cx[j] - cx[i], cy[j] - cy[i]])
            sep = False
            for ax in axes:
                ri = (s[i] / 2) * (abs(ax[0] * ux[i][0] + ax[1] * ux[i][1]) +
                                   abs(ax[0] * uy[i][0] + ax[1] * uy[i][1]))
                rj = (s[j] / 2) * (abs(ax[0] * ux[j][0] + ax[1] * ux[j][1]) +
                                   abs(ax[0] * uy[j][0] + ax[1] * uy[j][1]))
                proj = abs(d[0] * ax[0] + d[1] * ax[1])
                if proj > ri + rj - tol * 0.0 and proj >= ri + rj - 1e-7:
                    sep = True
                    break
            if not sep:
                return False
    return True


def _inside(layout, tol=1e-7):
    for x, y, a, s in layout:
        c = math.cos(2 * math.pi * a)
        sn = math.sin(2 * math.pi * a)
        h = s / 2.0
        for dx, dy in ((h, 0), (-h, 0), (0, h), (0, -h)):
            px = x + dx * c - dy * sn
            py = y + dx * sn + dy * c
            if px < -tol or px > 1 + tol or py < -tol or py > 1 + tol:
                return False
        # also corner check via half-diagonal
        d = abs(c) + abs(sn)
        r = h * d
        if x - r < -tol or x + r > 1 + tol or y - r < -tol or y + r > 1 + tol:
            return False
    return True


def _value(layout):
    return sum(s for _, _, _, s in layout)


def _feasible(layout):
    return _inside(layout) and _overlap_ok(layout)


def _cd_polish(layout, iters=60):
    n = len(layout)
    lay = [list(c) for c in layout]
    for _ in range(iters):
        improved = False
        for i in range(n):
            for var in range(4):
                for delta in (0.02, 0.008, 0.003, 0.001):
                    for sgn in (1, -1):
                        old = lay[i][var]
                        lay[i][var] = old + sgn * delta * (1.0 if var < 3 else 1.0)
                        if var == 3:
                            if lay[i][3] < 0:
                                lay[i][3] = 0.0
                        cand = [tuple(c) for c in lay]
                        if _feasible(cand) and _value(cand) > _value(layout) + 1e-9:
                            layout = cand
                            improved = True
                            break
                    else:
                        lay[i][var] = old
                        continue
                    break
        if not improved:
            break
    return layout


def _grow(layout, rounds=3):
    n = len(layout)
    lay = [list(c) for c in layout]
    for _ in range(rounds):
        for i in range(n):
            cur = lay[i][3]
            trial = cur
            while trial < 1.0:
                trial += 0.01
                lay[i][3] = trial
                cand = [tuple(c) for c in lay]
                if _feasible(cand):
                    continue
                else:
                    lay[i][3] = trial - 0.01
                    break
            # try shrink-free move of center to open room
    return [tuple(c) for c in lay]


def solve(n):
    seeds = []

    # Family A: uniform k x k grid plus zeros
    for k in range(1, n + 1):
        if k * k <= n:
            s = 1.0 / k
            g = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                 for i in range(k) for j in range(k)]
            seeds.append(g)

    # Family B: r rows of a axis squares + band of b tilted 45 squares
    for r in range(1, n + 1):
        for a in range(1, n + 1):
            na = r * a
            if na > n:
                continue
            h_axis = r * (1.0 / a)
            if h_axis >= 1.0:
                continue
            h_left = 1.0 - h_axis
            for b in range(1, n - na + 1):
                t = min(1.0 / (b * math.sqrt(2)), h_left / math.sqrt(2))
                if t <= 0:
                    continue
                layout = []
                s = 1.0 / a
                for j in range(r):
                    for i in range(a):
                        layout.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                y0 = h_axis
                for i in range(b):
                    cx = (i + 0.5) * t * math.sqrt(2)
                    cy = y0 + t * math.sqrt(2) / 2.0
                    if cx + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    if cy + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    layout.append((cx, cy, 0.125, t))
                if len(layout) >= n:
                    seeds.append(layout[:n])

    # Family C: c columns of a axis squares + band of b tilted
    for c in range(1, n + 1):
        for a in range(1, n + 1):
            na = c * a
            if na > n:
                continue
            w_axis = c * (1.0 / a)
            if w_axis >= 1.0:
                continue
            w_left = 1.0 - w_axis
            for b in range(1, n - na + 1):
                t = min(1.0 / (b * math.sqrt(2)), w_left / math.sqrt(2))
                if t <= 0:
                    continue
                layout = []
                s = 1.0 / a
                for i in range(c):
                    for j in range(a):
                        layout.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                x0 = w_axis
                for j in range(b):
                    cy = (j + 0.5) * t * math.sqrt(2)
                    cx = x0 + t * math.sqrt(2) / 2.0
                    if cx + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    if cy + t * math.sqrt(2) / 2 > 1 + 1e-9:
                        break
                    layout.append((cx, cy, 0.125, t))
                if len(layout) >= n:
                    seeds.append(layout[:n])

    # Family D: guillotine packer
    def pack_in_rect(x0, y0, x1, y1, remaining, out):
        w = x1 - x0
        h = y1 - y0
        if remaining <= 0 or w <= 1e-12 or h <= 1e-12:
            return 0
        best_block = None
        best_score = -1.0
        for k in range(1, min(20, remaining) + 1):
            for m in range(1, min(20, remaining // k) + 1):
                if k * m > remaining:
                    continue
                s = min(w / k, h / m)
                score = k * m * s
                if score > best_score:
                    best_score = score
                    best_block = (k, m, s)
        if best_block is None:
            return 0
        k, m, s = best_block
        for i in range(k):
            for j in range(m):
                out.append((x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, 0.0, s))
        placed = k * m
        rem = remaining - placed
        if rem == 0:
            return placed
        used_w = k * s
        used_h = m * s
        rem_placed = 0
        if w - used_w > 1e-12:
            rem_placed += pack_in_rect(x0 + used_w, y0, x1, y0 + used_h,
                                       rem - rem_placed, out)
        if rem_placed < rem and h - used_h > 1e-12:
            rem_placed += pack_in_rect(x0, y0 + used_h, x1, y1,
                                       rem - rem_placed, out)
        return placed + rem_placed

    out = []
    pack_in_rect(0.0, 0.0, 1.0, 1.0, n, out)
    seeds.append(out)

    # normalise seeds to length n, pad with zero-size squares at a corner
    norm = []
    for sd in seeds:
        sd = [(x, y, a, s) for (x, y, a, s) in sd]
        if len(sd) > n:
            sd = sd[:n]
        while len(sd) < n:
            sd.append((0.0, 0.0, 0.0, 0.0))
        norm.append(sd)

    best = None
    best_val = -1.0
    for sd in norm:
        val = _value(sd)
        if val > best_val:
            best_val = val
            best = sd

    # polish top candidate seeds (bounded)
    norm.sort(key=_value, reverse=True)
    polished_best = best
    polished_val = best_val
    limit = min(len(norm), 6 if n <= 20 else 3)
    for sd in norm[:limit]:
        p = _grow(sd)
        p2 = _cd_polish(p, iters=40 if n <= 16 else 20)
        v = _value(p2)
        if v > polished_val and _feasible(p2):
            polished_val = v
            polished_best = p2

    if polished_best is None:
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        polished_best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                         for i in range(k) for j in range(k)]
        polished_best = polished_best[:n]
        while len(polished_best) < n:
            polished_best.append((0.0, 0.0, 0.0, 0.0))

    return polished_best
