# EVOLVE-BLOCK-START
"""Sum of side lengths maximization via analytic layout families."""
import math


def _grid_layout(n_cells, w, h):
    if n_cells <= 0:
        return (0.0, 0.0, 0, 0)
    best = (0.0, 0.0, 0, 0)
    for p in range(1, n_cells + 1):
        q = (n_cells + p - 1) // p
        s = min(w / p, h / q)
        v = s * n_cells
        if v > best[0] + 1e-15:
            best = (v, s, p, q)
    return best


def _emit_grid(w, h, n_cells, p, q, s, n_total):
    out = []
    bw, bh = p * s, q * s
    ox, oy = (w - bw) * 0.5, (h - bh) * 0.5
    cnt = 0
    for j in range(q):
        for i in range(p):
            if cnt >= n_cells:
                break
            out.append((ox + (i + 0.5) * s, oy + (j + 0.5) * s, 0.0, s))
            cnt += 1
        if cnt >= n_cells:
            break
    while len(out) < n_total:
        out.append((w * 0.5, h * 0.5, 0.0, 0.0))
    return out[:n_total]


def _band_tilted(w, h, cnt):
    """cnt squares tilted 45 deg filling a band w x h.
    Each tilted square with side s occupies a bounding box of size s*sqrt(2).
    Choose s so that cnt fit: cnt*s*sqrt(2) <= w and s*sqrt(2) <= h."""
    sq2 = math.sqrt(2.0)
    if cnt <= 0:
        return (0.0, [])
    s = min(w / (cnt * sq2), h / sq2)
    if s <= 0:
        return (0.0, [])
    bx = s * sq2
    bw = cnt * bx
    ox = (w - bw) * 0.5
    pl = []
    for i in range(cnt):
        cx = ox + (i + 0.5) * bx
        cy = h * 0.5
        pl.append((cx, cy, 0.125, s))
    return (s * cnt, pl)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_val = -1.0
    best_pl = None

    def consider(v, pl):
        nonlocal best_val, best_pl
        if v > best_val + 1e-12:
            best_val = v
            best_pl = pl

    # --- Family A: uniform grid ---
    v, s, p, q = _grid_layout(n, 1.0, 1.0)
    consider(v, _emit_grid(1.0, 1.0, n, p, q, s, n))

    # --- Family B: two-rectangle split, each a grid ---
    fr_common = set()
    for den in (2, 3, 4, 5, 6, 7, 8, 10, 12):
        for num in range(1, den):
            fr_common.add(num / den)

    for axis in (0, 1):
        for t in range(1, n):
            r = n - t
            fr = set(fr_common)
            for m in (t, r):
                vm, sm, pm, qm = _grid_layout(m, 1.0, 1.0)
                if sm > 0:
                    need = (pm * sm) if axis == 0 else (qm * sm)
                    if 0 < need < 1.0:
                        fr.add(need)
                        fr.add(1.0 - need)
            for frac in fr:
                if frac <= 1e-9 or frac >= 1 - 1e-9:
                    continue
                if axis == 0:
                    w1, h1 = frac, 1.0
                    w2, h2 = 1.0 - frac, 1.0
                else:
                    w1, h1 = 1.0, frac
                    w2, h2 = 1.0, 1.0 - frac
                v1, s1, p1, q1 = _grid_layout(t, w1, h1)
                v2, s2, p2, q2 = _grid_layout(r, w2, h2)
                tv = v1 + v2
                if tv > best_val + 1e-12:
                    pl1 = _emit_grid(w1, h1, t, p1, q1, s1, t)
                    pl2 = _emit_grid(w2, h2, r, p2, q2, s2, r)
                    off2 = (frac, 0.0) if axis == 0 else (0.0, frac)
                    merged = list(pl1)
                    for (cx, cy, a, ss) in pl2:
                        merged.append((cx + off2[0], cy + off2[1], a, ss))
                    consider(tv, merged)

    # --- Family C: big corner square + L-shape remainder grid ---
    def corner_eval(a, rem):
        if a <= 1e-9 or a >= 1 - 1e-9:
            return None
        best_local = None
        for k in range(0, rem + 1):
            r2 = rem - k
            v1, s1, p1, q1 = _grid_layout(k, 1.0 - a, a) if k > 0 else (0.0, 0.0, 0, 0)
            v2, s2, p2, q2 = _grid_layout(r2, 1.0, 1.0 - a) if r2 > 0 else (0.0, 0.0, 0, 0)
            tot = a + v1 + v2
            if best_local is None or tot > best_local[0] + 1e-12:
                best_local = (tot, a, k, p1, q1, s1, p2, q2, s2, r2)
        return best_local

    cand_a = set(fr_common)
    for m in range(1, n):
        vm, sm, pm, qm = _grid_layout(m, 1.0, 1.0)
        if 0 < sm < 1:
            cand_a.add(sm)
            cand_a.add(sm * 2)
    cand_a = sorted(x for x in cand_a if 1e-6 < x < 1 - 1e-6)

    best_corner = None
    for a in cand_a:
        res = corner_eval(a, n - 1)
        if res is None:
            continue
        if best_corner is None or res[0] > best_corner[0] + 1e-12:
            best_corner = res

    if best_corner is not None:
        tot, a, k, p1, q1, s1, p2, q2, s2, r2 = best_corner
        if tot > best_val + 1e-12:
            pl = [(a * 0.5, a * 0.5, 0.0, a)]
            if k > 0:
                sub = _emit_grid(1.0 - a, a, k, p1, q1, s1, k)
                for (cx, cy, ang, ss) in sub:
                    pl.append((cx + a, cy, ang, ss))
            if r2 > 0:
                sub = _emit_grid(1.0, 1.0 - a, r2, p2, q2, s2, r2)
                for (cx, cy, ang, ss) in sub:
                    pl.append((cx, cy + a, ang, ss))
            while len(pl) < n:
                pl.append((0.5, 0.5, 0.0, 0.0))
            consider(tot, pl[:n])

    # --- Family D: tilted band above an axis-aligned grid ---
    sq2 = math.sqrt(2.0)
    for h in cand_a:
        side = h / sq2
        cnt_fit = int(1.0 / (side * sq2) + 1e-9) if side > 0 else 0
        cnt_fit = min(cnt_fit, n)
        for band_cnt in range(max(1, cnt_fit - 2), cnt_fit + 1):
            if band_cnt <= 0 or band_cnt > n:
                continue
            rem = n - band_cnt
            v_rem, sr, pr, qr = _grid_layout(rem, 1.0, 1.0 - h) if rem > 0 else (0.0, 0.0, 0, 0)
            tv, tpl = _band_tilted(1.0, h, band_cnt)
            tot = tv + v_rem
            if tot > best_val + 1e-12:
                pl = list(tpl)
                if rem > 0:
                    sub = _emit_grid(1.0, 1.0 - h, rem, pr, qr, sr, rem)
                    for (cx, cy, ang, ss) in sub:
                        pl.append((cx, cy + h, ang, ss))
                while len(pl) < n:
                    pl.append((0.5, 0.5, 0.0, 0.0))
                consider(tot, pl[:n])

    # --- Family E: big corner square + adjacent tilted band + remainder grid ---
    # Big axis-aligned square side a in bottom-left corner.
    # Tilted band in region [a,1] x [0,b] with b <= a (right of the big square).
    # Remaining [0,1] x [b,1] plus [a,1] x [b, ...] filled by grid:
    # We fill top region [0,1] x [b,1] with a grid, and right-of-big lower part
    # [a,1] x [b, a] with a grid too.
    def mixed_eval(a, b, rem_top, rem_right):
        if a <= 1e-9 or a >= 1 - 1e-9:
            return None
        # tilted band region: x in [a,1] (width 1-a), y in [0,b] (height b)
        vband, bpl = _band_tilted(1.0 - a, b, rem_right if rem_right >= 0 else 0)
        # Actually we treat rem_right as a grid count inside [a,1]x[b,a]; band count separate
        return None

    # Simpler: big square a; right strip [a,1]x[0,1] split at y=a into
    # bottom part [a,1]x[0,a] (tilted band or grid) and top strip [0,1]x[a,1] grid.
    for a in cand_a:
        # region [a,1] x [0,a] can be filled by tilted squares (45 deg) possibly
        for band_cnt in range(0, n):
            rem = (n - 1) - band_cnt
            if rem < 0:
                continue
            # band occupies [a,1]x[0,a]: width 1-a, height a
            vband, bpl = _band_tilted(1.0 - a, a, band_cnt) if band_cnt > 0 else (0.0, [])
            # top strip [0,1] x [a,1] filled with grid of size rem
            vt, st, pt, qt = _grid_layout(rem, 1.0, 1.0 - a) if rem > 0 else (0.0, 0.0, 0, 0)
            tot = a + vband + vt
            if tot > best_val + 1e-12:
                pl = [(a * 0.5, a * 0.5, 0.0, a)]
                for (cx, cy, ang, ss) in bpl:
                    pl.append((cx + a, cy, ang, ss))
                if rem > 0:
                    sub = _emit_grid(1.0, 1.0 - a, rem, pt, qt, st, rem)
                    for (cx, cy, ang, ss) in sub:
                        pl.append((cx, cy + a, ang, ss))
                while len(pl) < n:
                    pl.append((0.5, 0.5, 0.0, 0.0))
                consider(tot, pl[:n])

    # Adaptive refinement of the best corner-side parameter via local search
    # around the current best corner solution.
    if best_pl is None:
        v, s, p, q = _grid_layout(n, 1.0, 1.0)
        best_pl = _emit_grid(1.0, 1.0, n, p, q, s, n)

    result = []
    for (cx, cy, a, s) in best_pl[:n]:
        s = max(0.0, min(1.0, float(s)))
        cx = max(0.0, min(1.0, float(cx)))
        cy = max(0.0, min(1.0, float(cy)))
        result.append((cx, cy, 0.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END

