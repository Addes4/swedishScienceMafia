# EVOLVE-BLOCK-START
"""Grid start plus randomized coordinate-descent growth for a better packing."""
import math
import random


def _overlap(a, b):
    """Return True if two axis-aligned squares (cx, cy, ang, s) have overlapping interiors.
    We only use angle 0 for the search, so this is simple."""
    ax, ay, aa, as_ = a
    bx, by, ba, bs = b
    if as_ <= 0.0 or bs <= 0.0:
        return False
    return (abs(ax - bx) < (as_ + bs) * 0.5 - 1e-12 and
            abs(ay - by) < (as_ + bs) * 0.5 - 1e-12)


def _feasible(sqs):
    m = len(sqs)
    for i in range(m):
        cx, cy, _, s = sqs[i]
        if s <= 0.0:
            continue
        h = s * 0.5
        if cx - h < -1e-9 or cx + h > 1.0 + 1e-9:
            return False
        if cy - h < -1e-9 or cy + h > 1.0 + 1e-9:
            return False
        for j in range(i + 1, m):
            if _overlap(sqs[i], sqs[j]):
                return False
    return True


def _clamp(sqs):
    """Push squares back inside the unit square."""
    for i, (cx, cy, ang, s) in enumerate(sqs):
        h = s * 0.5
        if s > 1.0:
            s = 1.0
            h = 0.5
        cx = min(max(cx, h), 1.0 - h)
        cy = min(max(cy, h), 1.0 - h)
        sqs[i] = (cx, cy, ang, s)
    return sqs


def _grid_start(n):
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def solve(n):
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0)] if n == 1 else []

    # Try a few candidate grid arrangements and improve each.
    best = None
    best_sum = -1.0

    k = math.isqrt(n)
    candidates = []
    # base: k x k grid with extras as zero-size in centre
    candidates.append(_grid_start(n))
    # variant: distribute the extra squares as an extra partial row in a k-wide grid
    if k >= 1 and n > k * k:
        side = 1.0 / (k + 1.0)
        # place (k+1) rows worth partially; simpler: use (k) x (k) but shrink to leave room
        # Try a packing with k columns and ceil(n/k) rows
        rows = (n + k - 1) // k
        side2 = 1.0 / max(k, rows)
        sq = []
        for i in range(n):
            r = i // k
            c = i % k
            cx = (c + 0.5) * side2
            cy = (r + 0.5) * side2
            sq.append((cx, cy, 0.0, side2))
        candidates.append(sq)

    random.seed(12345 + n)

    for start in candidates:
        sqs = _clamp([list(s) for s in start])
        sqs = [tuple(s) for s in sqs]
        if not _feasible(sqs):
            continue

        # coordinate descent: try to grow and re-center each square
        improved = True
        while improved:
            improved = False
            for i in range(n):
                cx, cy, ang, s = sqs[i]
                if s <= 0.0:
                    # place a tiny square somewhere free
                    placed = False
                    for _ in range(40):
                        tx = random.uniform(0.01, 0.99)
                        ty = random.uniform(0.01, 0.99)
                        trial = list(sqs)
                        trial[i] = (tx, ty, 0.0, 0.02)
                        trial = _clamp(trial)
                        if _feasible(trial):
                            sqs = [tuple(x) for x in trial]
                            improved = True
                            placed = True
                            break
                    if placed:
                        continue
                    else:
                        continue

                # try to grow this square, and shift it toward the nearest boundary
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1),
                               (1, 1), (1, -1), (-1, 1), (-1, -1), (0, 0)):
                    step = 0.01
                    trial = list(sqs)
                    ns = min(1.0, s + step)
                    ncx = cx + dx * step * 0.5
                    ncy = cy + dy * step * 0.5
                    if ns <= s:
                        continue
                    trial[i] = (ncx, ncy, 0.0, ns)
                    trial = _clamp(trial)
                    if _feasible(trial):
                        sqs = [tuple(x) for x in trial]
                        improved = True
                        break

        total = sum(s for (_, _, _, s) in sqs)
        if total > best_sum:
            best_sum = total
            best = sqs

    if best is None:
        best = _grid_start(n)
        best = [tuple(s) for s in best]

    # ensure length n
    best = list(best[:n])
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best
# EVOLVE-BLOCK-END
