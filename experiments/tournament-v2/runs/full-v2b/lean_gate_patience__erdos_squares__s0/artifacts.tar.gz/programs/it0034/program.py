import math


def solve(n):
    best = None
    best_val = -1.0

    def consider(layout):
        nonlocal best, best_val
        if len(layout) < n:
            layout = layout + [(0.5, 0.5, 0.0, 0.0)] * (n - len(layout))
        layout = layout[:n]
        val = sum(s for _, _, _, s in layout)
        if val > best_val + 1e-12:
            best_val = val
            best = layout

    def axis_block(x0, y0, k, m, s):
        return [((x0 + (i + 0.5) * s), (y0 + (j + 0.5) * s), 0.0, s)
                for i in range(k) for j in range(m)]

    def tilt_band_horizontal(y0, y1, b):
        # b squares rotated 45 deg, side t, packed in a row of height (y1-y0)
        h = y1 - y0
        if h <= 1e-12 or b <= 0:
            return []
        t = min(1.0 / (b * math.sqrt(2.0)), h / math.sqrt(2.0))
        if t <= 1e-12:
            return []
        out = []
        w = t * math.sqrt(2.0)
        for i in range(b):
            cx = (i + 0.5) * w
            cy = y0 + h / 2.0
            out.append((cx, cy, 0.125, t))
        return out

    def tilt_band_vertical(x0, x1, b):
        w = x1 - x0
        if w <= 1e-12 or b <= 0:
            return []
        t = min(1.0 / (b * math.sqrt(2.0)), w / math.sqrt(2.0))
        if t <= 1e-12:
            return []
        out = []
        hh = t * math.sqrt(2.0)
        for j in range(b):
            cy = (j + 0.5) * hh
            cx = x0 + w / 2.0
            out.append((cx, cy, 0.125, t))
        return out

    # ---- Family A: pure uniform k x m grid (axis aligned) ----
    for k in range(1, n + 1):
        for m in range(1, n + 1):
            if k * m <= n:
                s = min(1.0 / k, 1.0 / m)
                consider(axis_block(0.0, 0.0, k, m, s))

    # ---- Family B: axis-aligned block occupying full width-guillotine,
    #      with a horizontal tilted band above (or vertical to the side) ----
    for k in range(1, n + 1):
        for m in range(1, n + 1):
            na = k * m
            if na > n:
                continue
            s = 1.0 / k
            h_axis = m * s
            if h_axis > 1.0 + 1e-12:
                continue
            h_axis = min(h_axis, 1.0)
            rem = n - na
            # leftover band above, fill with tilted squares (and possibly
            # some extra tiny axis squares)
            layout = axis_block(0.0, 0.0, k, m, s)
            if rem > 0:
                band = tilt_band_horizontal(h_axis, 1.0, rem)
                layout = layout + band
            consider(layout)
            # vertical variant
            layout = axis_block(0.0, 0.0, k, m, s)
            if rem > 0:
                band = tilt_band_vertical(s * k, 1.0, rem)
                layout = layout + band
            consider(layout)

    # ---- Family C: full grid of tilted (45 deg) squares + leftover axis squares ----
    # A grid of p columns x q rows of 45-deg squares: each bbox has width
    # t*sqrt2, so p*t*sqrt2<=1 and q*t*sqrt2<=1.
    for p in range(1, n + 1):
        for q in range(1, n + 1):
            if p * q > n:
                continue
            t = min(1.0 / (p * math.sqrt(2.0)), 1.0 / (q * math.sqrt(2.0)))
            if t <= 1e-12:
                continue
            w = t * math.sqrt(2.0)
            layout = []
            for i in range(p):
                for j in range(q):
                    layout.append(((i + 0.5) * w, (j + 0.5) * w, 0.125, t))
            rem = n - p * q
            if rem > 0:
                # fill remaining space (right strip and top strip) with
                # small axis squares
                strip_w = 1.0 - p * w
                strip_h = 1.0 - q * w
                if strip_w > 1e-9:
                    sm = min(strip_w, 1.0 / max(1, int(math.ceil(rem ** 0.5))))
                    cnt = 0
                    rows = max(1, int(1.0 / sm))
                    for rr in range(rows):
                        for cc in range(max(1, int(strip_w / sm))):
                            if cnt >= rem:
                                break
                            layout.append((p * w + (cc + 0.5) * sm,
                                           (rr + 0.5) * sm, 0.0, sm))
                            cnt += 1
                        if cnt >= rem:
                            break
                for _ in range(rem):
                    if len(layout) >= n:
                        break
                    layout.append((0.5, 0.5, 0.0, 0.0))
            consider(layout)

    # ---- Family D: multi-scale guillotine with uniform blocks (original) ----
    def pack_in_rect(x0, y0, x1, y1, remaining, out):
        w = x1 - x0
        h = y1 - y0
        if remaining <= 0 or w <= 1e-12 or h <= 1e-12:
            return 0
        best_block = None
        best_score = -1.0
        maxk = min(20, remaining)
        for k in range(1, maxk + 1):
            for m in range(1, min(20, remaining // k) + 1):
                if k * m > remaining:
                    continue
                s = min(w / k, h / m)
                score = k * m * s
                if score > best_score:
                    best_score = score
                    best_block = (k, m, s)
        if best_block is None:
            return 0
        k, m, s = best_block
        for i in range(k):
            for j in range(m):
                out.append((x0 + (i + 0.5) * s, y0 + (j + 0.5) * s, 0.0, s))
        placed = k * m
        rem = remaining - placed
        if rem == 0:
            return placed
        used_w = k * s
        used_h = m * s
        rem_placed = 0
        if w - used_w > 1e-12:
            rem_placed += pack_in_rect(x0 + used_w, y0, x1, y0 + used_h,
                                       rem - rem_placed, out)
        if rem_placed < rem and h - used_h > 1e-12:
            rem_placed += pack_in_rect(x0, y0 + used_h, x1, y1,
                                       rem - rem_placed, out)
        return placed + rem_placed

    out = []
    pack_in_rect(0.0, 0.0, 1.0, 1.0, n, out)
    consider(out)

    # ---- Family E: two-block horizontal: axis grid + tilted-45 grid side by side,
    #      with independent widths ----
    for k in range(1, n + 1):
        for m in range(1, n + 1):
            na = k * m
            if na > n:
                continue
            rem = n - na
            if rem <= 0:
                continue
            # axis block uses width fraction, leaving rest for tilted band column
            for p in range(1, rem + 1):
                # p is count of tilted squares in the side column
                # axis block width = k*s, tilted bbox height = p*t*sqrt2 <= 1,
                # tilted bbox width = t*sqrt2, and k*s + t*sqrt2 <= 1.
                # t = min(1/(1*sqrt2) ... ) -> maximize t s.t. k*s + t*sqrt2<=1
                # Also axis height m*s <= 1. Choose s to maximize total.
                # total = k*m*s + p*t, t = (1 - k*s)/sqrt2, s <= 1/m
                s_max = min(1.0 / k, 1.0 / m)
                # maximize over s in [0, s_max]
                # d/ds [km s + p(1-k s)/sqrt2] = km - p k/sqrt2
                # monotone; pick boundary
                cands = [0.0, s_max]
                c0 = k * m - p * k / math.sqrt(2.0)
                if abs(c0) < 1e-15 and s_max > 0:
                    cands.append(s_max / 2.0)
                if c0 > 0:
                    cands.append(s_max)
                if c0 < 0:
                    cands.append(0.0)
                # also height constraint for tilted column: p*t*sqrt2<=1
                # t=(1-k s)/sqrt2 => p(1-ks)<=1 => s >= (1-1/p)/k
                for s in cands:
                    s = max(0.0, min(s, s_max))
                    if k * s > 1.0 + 1e-12:
                        continue
                    t = (1.0 - k * s) / math.sqrt(2.0)
                    if t <= 1e-12:
                        continue
                    if p * t * math.sqrt(2.0) > 1.0 + 1e-9:
                        continue
                    if m * s > 1.0 + 1e-9:
                        continue
                    layout = axis_block(0.0, 0.0, k, m, s)
                    hh = t * math.sqrt(2.0)
                    for j in range(p):
                        cy = (j + 0.5) * hh if p * hh <= 1.0 + 1e-9 else None
                        if cy is None:
                            break
                        cx = k * s + hh / 2.0
                        layout.append((cx, cy, 0.125, t))
                    if len(layout) >= n:
                        consider(layout)

    if best is None:
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best = best[:n]
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))

    return best

