# EVOLVE-BLOCK-START
"""Structured layout search plus a light coordinate-descent expansion."""
import math
import random


def _vertices(cx, cy, ang, s):
    c, sn = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _overlap(A, B):
    for poly in (A, B):
        n = len(poly)
        for k in range(n):
            x1, y1 = poly[k]
            x2, y2 = poly[(k + 1) % n]
            ax, ay = -(y2 - y1), (x2 - x1)
            projA = [ax * p[0] + ay * p[1] for p in A]
            projB = [ax * p[0] + ay * p[1] for p in B]
            if max(projA) < min(projB) + 1e-9 or max(projB) < min(projA) + 1e-9:
                return False
    return True


def _feasible(sqs):
    boxes = []
    for (cx, cy, ang, s) in sqs:
        if s <= 0:
            continue
        if cx < -1e-9 or cx > 1 + 1e-9 or cy < -1e-9 or cy > 1 + 1e-9:
            return False
        v = _vertices(cx, cy, ang, s)
        xs = [p[0] for p in v]
        ys = [p[1] for p in v]
        if min(xs) < -1e-9 or max(xs) > 1 + 1e-9 or min(ys) < -1e-9 or max(ys) > 1 + 1e-9:
            return False
        boxes.append(v)
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            if _overlap(boxes[i], boxes[j]):
                return False
    return True


def _grid(k):
    res = []
    if k <= 0:
        return res
    s = 1.0 / k
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    return res


def _best_sum(cand, n):
    if len(cand) < n:
        cand = cand + [(0.5, 0.5, 0.0, 0.0)] * (n - len(cand))
    cand = cand[:n]
    if not _feasible(cand):
        return None
    return sum(c[3] for c in cand), cand


# ---------- row-partition family ----------
def _row_layout(n, heights, cols_per_row):
    """Divide unit square into horizontal strips with given heights (summing to 1),
    each filled with a uniform grid of cols_per_row[i] columns. Trim to n largest."""
    cells = []
    y = 0.0
    for hi, (h, c) in enumerate(zip(heights, cols_per_row)):
        if h <= 1e-12 or c <= 0:
            y += h
            continue
        w = 1.0 / c
        sq = min(w, h)
        offx = (w - sq) * 0.5
        offy = (h - sq) * 0.5
        for i in range(c):
            for _ in range(1):
                cx = i * w + w * 0.5
                cy = y + h * 0.5
                cells.append((cx, cy, 0.0, sq))
        y += h
    if len(cells) < n:
        return None
    cells.sort(key=lambda t: -t[3])
    return cells[:n]


def _row_family(n):
    out = []
    # enumerate simple partitions: rows with equal-ish counts
    k0 = max(1, math.isqrt(n))
    for rows in range(1, k0 + 3):
        for cols in range(1, k0 + 3):
            if rows * cols < n:
                continue
            heights = [1.0 / rows] * rows
            cpr = [cols] * rows
            lay = _row_layout(n, heights, cpr)
            if lay is not None:
                out.append(lay)
    # two-band splits: top band with 'a' rows of 'ca' cols, bottom with 'b' rows 'cb' cols
    for H in (0.5, 0.4, 0.6, 1.0 / 3, 2.0 / 3, 0.25, 0.75, 0.375, 0.625, 0.2, 0.8):
        for ra in range(1, 4):
            for ca in range(1, 6):
                for rb in range(1, 4):
                    for cb in range(1, 6):
                        if ra * ca + rb * cb < n:
                            continue
                        heights = [H / ra] * ra + [(1 - H) / rb] * rb
                        cpr = [ca] * ra + [cb] * rb
                        lay = _row_layout(n, heights, cpr)
                        if lay is not None:
                            out.append(lay)
    return out


def _big_square_layout(n, side, corner):
    """One big axis-aligned square in a corner, remainder filled with a grid."""
    if n < 1:
        return []
    s = side
    if s <= 0 or s > 1:
        return []
    big_cx = big_cy = s * 0.5
    if corner == 'tl':
        big_cx = 1 - s * 0.5
    elif corner == 'br':
        big_cy = 1 - s * 0.5
    elif corner == 'tr':
        big_cx = 1 - s * 0.5
        big_cy = 1 - s * 0.5
    out = [(big_cx, big_cy, 0.0, s)]
    rem = n - 1
    if rem <= 0:
        return out
    # remainder strips
    if corner in ('bl', 'br'):
        strips = [(s, 0.0, 1.0 - s, 1.0), (0.0, s, s, 1.0 - s)]
    else:
        strips = [(0.0, 0.0, 1.0 - s, 1.0), (1.0 - s, 0.0, s, 1.0 - s)]
    best = None
    best_sum = -1
    areas = [w * h for (_, _, w, h) in strips]
    tot = sum(areas)
    if tot <= 1e-12:
        return out
    counts = [int(round(rem * a / tot)) for a in areas]
    counts[0] += rem - sum(counts)
    cand = list(out)
    for (sx, sy, sw, sh), c in zip(strips, counts):
        if c <= 0:
            continue
        # fill strip with uniform grid
        cols = max(1, int(round(math.sqrt(c * sw / max(sh, 1e-9)))))
        rows = max(1, c // cols)
        while rows * cols < c:
            if sw / (cols + 1) >= sh / rows:
                cols += 1
            else:
                rows += 1
        cw = sw / cols
        ch = sh / rows
        sq = min(cw, ch)
        offx = (cw - sq) * 0.5
        offy = (ch - sq) * 0.5
        cnt = 0
        for i in range(cols):
            for j in range(rows):
                if cnt >= c:
                    break
                cand.append((sx + i * cw + cw * 0.5, sy + j * ch + ch * 0.5, 0.0, sq))
                cnt += 1
    if len(cand) < n:
        return None
    cand.sort(key=lambda t: -t[3])
    return cand[:n]


def _expand(sqs, iters=400):
    sqs = [list(s) for s in sqs]
    n = len(sqs)
    order = list(range(n))

    def ok_full(idx, cand):
        old = sqs[idx]
        sqs[idx] = cand
        res = _feasible(sqs)
        if not res:
            sqs[idx] = old
        return res

    for _ in range(iters):
        improved = False
        random.shuffle(order)
        for i in order:
            cx, cy, a, s = sqs[i]
            for ds in (0.02, 0.01, 0.005, 0.002, 0.001):
                cand = [cx, cy, a, s + ds]
                if ok_full(i, cand):
                    s += ds
                    cx, cy, a, s = sqs[i]
                    improved = True
            for dx, dy in ((0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01),
                           (0.005, 0.005), (-0.005, 0.005),
                           (0.005, -0.005), (-0.005, -0.005)):
                cand = [cx + dx, cy + dy, a, s]
                if ok_full(i, cand):
                    improved = True
        if not improved:
            break

    return [(c[0], c[1], c[2], c[3]) for c in sqs]


def _coord_descent(sqs, n, budget=8):
    """Stronger structured descent: repeat grow/shrink-balance a few times."""
    best = _expand(sqs, iters=120)
    r = _best_sum(best, n)
    if r is None:
        return sqs
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(999 + n)
    candidates = []

    # simple grids
    k0 = max(1, math.isqrt(n))
    for k in range(max(1, k0 - 2), k0 + 3):
        g = _grid(k)
        if len(g) >= n:
            candidates.append(g[:n])

    # row-partition family (key new family)
    candidates.extend(_row_family(n))

    # big square + L
    for xi in range(4, 21):
        side = xi * 0.05
        for corner in ('bl', 'br', 'tl', 'tr'):
            cand = _big_square_layout(n, side, corner)
            if cand is not None and len(cand) == n:
                candidates.append(cand)

    # dedupe + score
    pool = []
    seen = set()
    for cand in candidates:
        r = _best_sum(cand, n)
        if r is None:
            continue
        sc, c2 = r
        key = tuple(round(x, 5) for sq in c2 for x in sq)
        if key in seen:
            continue
        seen.add(key)
        pool.append((sc, c2))

    if not pool:
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        return best[:n]

    pool.sort(key=lambda t: -t[0])
    pool = pool[:10]

    results = list(pool)
    for sc, c2 in pool:
        try:
            polished = _expand(c2, iters=200)
            r = _best_sum(polished, n)
            if r is not None:
                results.append(r)
        except Exception:
            pass

    results.sort(key=lambda t: -t[0])
    best = results[0][1]
    if not _feasible(best):
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]
# EVOLVE-BLOCK-END
