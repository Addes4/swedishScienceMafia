# EVOLVE-BLOCK-START
"""Multi-scale guillotine packing of squares into the unit square.

Recursively split a rectangle into two sub-rectangles (guillotine cuts).
At each leaf place a uniform block of equal squares.  A *bounded* search
over cut positions (curated candidate set) and block layouts maximises the
total sum of side lengths, with memoization and pruning so every n finishes
well inside the time limit.
"""
import math


def _block_value(rw, rh, k):
    """Best value and grid (p,q) for a uniform block of k squares
    packed axis-aligned inside a (rw, rh) rectangle."""
    best = (0.0, 1, 1)
    # Only p up to k; q = ceil(k/p).  side = min(rw/p, rh/q).
    for p in range(1, k + 1):
        q = (k + p - 1) // p
        side = min(rw / p, rh / q)
        if side > best[0] + 1e-15:
            best = (side, p, q)
    return best  # (side, p, q), value = k * side


def _fill_rect(x0, y0, rw, rh, k, side, p, q):
    """Place k axis-aligned squares of equal side as a centred p x q grid."""
    if k <= 0 or side <= 1e-12:
        return [(0.5, 0.5, 0.0, 0.0)] * max(k, 0)
    gx = p * side
    gy = q * side
    ox = x0 + (rw - gx) / 2.0
    oy = y0 + (rh - gy) / 2.0
    out = []
    count = 0
    for i in range(p):
        for j in range(q):
            if count >= k:
                break
            out.append((ox + (i + 0.5) * side, oy + (j + 0.5) * side, 0.0, side))
            count += 1
    return out


def _candidates(rw, rh, k):
    """Curated candidate cut fractions for a rectangle."""
    cands = set()
    for t in (1, 2, 3, 4, 5, 6, 7):
        cands.add(t / 8.0)
    # fractions based on grid dimensions that give the best block
    s, p, q = _block_value(rw, rh, k)
    cands.add(min(1.0, p / float(max(p, q))))
    cands.add(min(1.0, q / float(max(p, q))))
    # fractions based on integer splits of k
    for p in range(1, k + 1):
        cands.add(p / float(k))
    out = []
    for f in cands:
        if 1e-9 < f < 1.0 - 1e-9:
            out.append(f)
    return out


def _search(x0, y0, rw, rh, k, depth, memo):
    """Return (value, squares) for packing k squares into rectangle."""
    if k <= 0:
        return 0.0, []
    key = (round(rw, 8), round(rh, 8), k, depth)
    if key in memo:
        return memo[key]

    # Option A: uniform block filling the whole rectangle
    side, p, q = _block_value(rw, rh, k)
    best_val = k * side
    best_sq = _fill_rect(x0, y0, rw, rh, k, side, p, q)

    if depth <= 0 or k == 1:
        memo[key] = (best_val, best_sq)
        return best_val, best_sq

    # Upper bound: k equal squares of side min(rw,rh)/sqrt(k) is loose, use block value.
    cands = _candidates(rw, rh, k)
    for axis in (0, 1):
        length = rw if axis == 0 else rh
        if length <= 1e-9:
            continue
        for frac in cands:
            # skip cuts that just reproduce the uniform block (already tried)
            if axis == 0:
                r1 = (x0, y0, rw * frac, rh)
                r2 = (x0 + rw * frac, y0, rw * (1 - frac), rh)
            else:
                r1 = (x0, y0, rw, rh * frac)
                r2 = (x0, y0 + rh * frac, rw, rh * (1 - frac))
            # integer split of k along this axis
            for k1 in range(0, k + 1):
                k2 = k - k1
                if k1 == 0 and k2 == 0:
                    continue
                # quick upper bound to prune
                ub1 = (k1 * min(r1[2], r1[3]) if k1 else 0.0)
                ub2 = (k2 * min(r2[2], r2[3]) if k2 else 0.0)
                # tighter bound: block value is <= k*min(rw,rh); use max dim too
                ub1 = k1 * min(r1[2], r1[3]) if k1 else 0.0
                ub2 = k2 * min(r2[2], r2[3]) if k2 else 0.0
                if ub1 + ub2 <= best_val + 1e-12:
                    continue
                v1, s1 = _search(r1[0], r1[1], r1[2], r1[3], k1, depth - 1, memo)
                v2, s2 = _search(r2[0], r2[1], r2[2], r2[3], k2, depth - 1, memo)
                if v1 + v2 > best_val + 1e-12:
                    best_val = v1 + v2
                    best_sq = s1 + s2
    memo[key] = (best_val, best_sq)
    return best_val, best_sq


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    best_total = -1.0
    best_sq = None
    # depth-limited guillotine search, keep the best across depths
    for depth in (1, 2):
        memo = {}
        val, sq = _search(0.0, 0.0, 1.0, 1.0, n, depth, memo)
        if val > best_total:
            best_total = val
            best_sq = sq
    if best_sq is None:
        k = max(1, math.isqrt(n))
        side = 1.0 / k
        best_sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        best_sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))

    # Sanitise output: clamp to [0,1], pad/truncate to n.
    out = []
    for (cx, cy, ang, sd) in best_sq:
        sd = max(0.0, min(1.0, sd))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = max(0.0, min(1.0, ang))
        out.append((cx, cy, ang, sd))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
