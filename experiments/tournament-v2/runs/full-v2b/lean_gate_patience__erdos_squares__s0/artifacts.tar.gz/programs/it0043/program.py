# EVOLVE-BLOCK-START
"""Multi-scale guillotine packing with a bounded memoized search.

We recursively split a rectangular cell into two sub-cells, and in each leaf
place a uniform block of m equal axis-aligned squares (p columns x q rows).
The split fractions are derived from the analytic block sizes (so cuts occur at
natural boundaries) plus a few simple fractions. A memo keyed on the rounded
cell dimensions and remaining count keeps the search polynomial and fast.
"""
import math
from functools import lru_cache


def _block_value(w, h, m):
    """Best total side sum placing exactly m equal axis-aligned squares in a w x h cell."""
    if m <= 0:
        return (0.0, 1.0, 1, 1)
    best = (0.0, 0.0, 1, 1)
    for p in range(1, m + 1):
        q = (m + p - 1) // p
        s = min(w / p, h / q)
        v = s * m
        if v > best[0]:
            best = (v, s, p, q)
    for q in range(1, m + 1):
        p = (m + q - 1) // q
        s = min(w / p, h / q)
        v = s * m
        if v > best[0]:
            best = (v, s, p, q)
    return best


# cache block values for (rounded w, rounded h, m)
_bv_cache = {}


def _block_value_cached(w, h, m):
    key = (round(w, 8), round(h, 8), m)
    r = _bv_cache.get(key)
    if r is None:
        r = _block_value(w, h, m)
        _bv_cache[key] = r
    return r


def _emit_block(w, h, m, p, q, s, n):
    """Place m squares of side s in p columns x q rows inside w x h cell, centered."""
    out = []
    bw = p * s
    bh = q * s
    ox = (w - bw) * 0.5
    oy = (h - bh) * 0.5
    count = 0
    for j in range(q):
        for i in range(p):
            if count >= m:
                break
            cx = ox + (i + 0.5) * s
            cy = oy + (j + 0.5) * s
            out.append((cx, cy, 0.0, s))
            count += 1
        if count >= m:
            break
    while len(out) < n:
        out.append((w * 0.5, h * 0.5, 0.0, 0.0))
    return (s * m, out[:n])


_memo = {}


def _search(w, h, n, depth):
    """Return (value, placement_list) for packing n squares in w x h cell."""
    if n <= 0:
        return (0.0, [])
    if depth <= 0 or n == 1:
        m = n
        v, s, p, q = _block_value_cached(w, h, m)
        return _emit_block(w, h, m, p, q, s, n)

    key = (round(w, 8), round(h, 8), n, depth)
    hit = _memo.get(key)
    if hit is not None:
        return hit

    # leaf candidate: single block
    vb, sb, pb, qb = _block_value_cached(w, h, n)
    best_val = vb
    best_pl = _emit_block(w, h, n, pb, qb, sb, n)

    # try splits
    for axis in (0, 1):
        span = w if axis == 0 else h
        for t in range(1, n):
            r = n - t
            fracs = _split_fractions(w, h, t, r, axis)
            for frac in fracs:
                if axis == 0:
                    w1, w2 = frac * w, (1 - frac) * w
                    h1, h2 = h, h
                    off2 = (frac * w, 0.0)
                else:
                    w1, w2 = w, w
                    h1, h2 = frac * h, (1 - frac) * h
                    off2 = (0.0, frac * h)
                if w1 <= 1e-9 or h1 <= 1e-9 or w2 <= 1e-9 or h2 <= 1e-9:
                    continue
                v1, pl1 = _search(w1, h1, t, depth - 1)
                if v1 <= best_val:
                    # even if v1 alone can't beat, still need combined potential
                    pass
                v2, pl2 = _search(w2, h2, r, depth - 1)
                tv = v1 + v2
                if tv > best_val + 1e-12:
                    best_val = tv
                    merged = list(pl1)
                    for (cx, cy, a, s) in pl2:
                        merged.append((cx + off2[0], cy + off2[1], a, s))
                    while len(merged) < n:
                        merged.append((w * 0.5, h * 0.5, 0.0, 0.0))
                    best_pl = merged[:n]

    _memo[key] = (best_val, best_pl)
    return (best_val, best_pl)


def _split_fractions(w, h, t, r, axis):
    """Candidate split fractions along an axis, derived from block sizes."""
    span = w if axis == 0 else h
    fracs = set()
    for m in (t, r):
        if m <= 0:
            continue
        v, s, p, q = _block_value_cached(w, h, m)
        if s > 0:
            need = (p * s) if axis == 0 else (q * s)
            if 0 < need < span:
                fracs.add(need / span)
            # also allow the complementary block size
            need2 = (q * s) if axis == 0 else (p * s)
            if 0 < need2 < span:
                fracs.add(need2 / span)
    for den in (2, 3, 4, 5, 6, 8, 10):
        for num in range(1, den):
            f = num / den
            if 0 < f < 1:
                fracs.add(f)
    return sorted(f for f in fracs if 0 < f < 1)


def solve(n):
    """Return n squares inside the unit square maximizing sum of sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    _memo.clear()
    best_val = -1.0
    best_pl = None

    for depth in (2, 3):
        v, pl = _search(1.0, 1.0, n, depth)
        if v > best_val:
            best_val = v
            best_pl = pl

    # simple uniform block candidate
    v, s, p, q = _block_value(1.0, 1.0, n)
    if v > best_val:
        val, pl = _emit_block(1.0, 1.0, n, p, q, s, n)
        best_val = val
        best_pl = pl

    if best_pl is None:
        k = math.isqrt(n)
        s = 1.0 / k
        pl = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
              for i in range(k) for j in range(k)]
        pl += [(0.5, 0.5, 0.0, 0.0)] * (n - len(pl))
        best_pl = pl[:n]

    result = []
    for (cx, cy, a, s) in best_pl[:n]:
        s = max(0.0, min(1.0, s))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        result.append((cx, cy, 0.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END
