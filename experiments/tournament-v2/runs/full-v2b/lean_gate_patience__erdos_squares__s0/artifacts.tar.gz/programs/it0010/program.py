# EVOLVE-BLOCK-START
"""Structured layout search with row-based packings plus coordinate-descent expansion."""
import math
import random


def _vertices(cx, cy, ang, s):
    c, sn = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _feasible(sqs):
    boxes = []
    for (cx, cy, ang, s) in sqs:
        if s <= 0:
            continue
        if cx < 0 or cx > 1 or cy < 0 or cy > 1:
            return False
        v = _vertices(cx, cy, ang, s)
        xs = [p[0] for p in v]
        ys = [p[1] for p in v]
        if min(xs) < -1e-9 or max(xs) > 1 + 1e-9 or min(ys) < -1e-9 or max(ys) > 1 + 1e-9:
            return False
        boxes.append(v)
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            if _overlap(boxes[i], boxes[j]):
                return False
    return True


def _overlap(A, B):
    for poly in (A, B):
        n = len(poly)
        for k in range(n):
            x1, y1 = poly[k]
            x2, y2 = poly[(k + 1) % n]
            ax, ay = -(y2 - y1), (x2 - x1)
            projA = [ax * p[0] + ay * p[1] for p in A]
            projB = [ax * p[0] + ay * p[1] for p in B]
            if max(projA) < min(projB) + 1e-9 or max(projB) < min(projA) + 1e-9:
                return False
    return True


def _grid(k):
    res = []
    if k <= 0:
        return res
    s = 1.0 / k
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    return res


def _grid_rect(nx, ny):
    """nx by ny grid filling the unit square."""
    res = []
    if nx <= 0 or ny <= 0:
        return res
    sx = 1.0 / nx
    sy = 1.0 / ny
    s = min(sx, sy)
    for i in range(nx):
        for j in range(ny):
            res.append(((i + 0.5) * sx, (j + 0.5) * sy, 0.0, s))
    return res


def _greedy_split(x, y, w, h, remaining):
    rects = [(x, y, w, h)]
    out = []
    for _ in range(remaining):
        best_i = -1
        best_s = 0.0
        for i, (rx, ry, rw, rh) in enumerate(rects):
            s = min(rw, rh)
            if s > best_s + 1e-12:
                best_s = s
                best_i = i
        if best_i < 0 or best_s <= 1e-12:
            break
        rx, ry, rw, rh = rects.pop(best_i)
        s = best_s
        out.append((rx + s * 0.5, ry + s * 0.5, 0.0, s))
        if rw - s > rh - s:
            if rw - s > 1e-12:
                rects.append((rx + s, ry, rw - s, rh))
            if rh - s > 1e-12:
                rects.append((rx, ry + s, s, rh - s))
        else:
            if rh - s > 1e-12:
                rects.append((rx, ry + s, rw, rh - s))
            if rw - s > 1e-12:
                rects.append((rx + s, ry, rw - s, s))
    return out


def _row_layout(counts, heights):
    """Place squares in horizontal rows. Row i has `counts[i]` squares all of
    side heights[i]; rows stack from bottom up. If the total width of a row
    exceeds 1, squares in that row are shrunk so they fit. Heights are clamped
    so the stack fits in [0,1]. Returns list of squares."""
    out = []
    total_h = sum(heights)
    y = 0.0
    for cnt, h in zip(counts, heights):
        if cnt <= 0 or h <= 0:
            continue
        # side capped by available height and by fitting `cnt` across
        s = min(h, 1.0 / cnt)
        if s <= 0:
            continue
        w = cnt * s
        # center the row horizontally
        x0 = (1.0 - w) * 0.5
        for i in range(cnt):
            cx = x0 + (i + 0.5) * s
            cy = y + s * 0.5
            out.append((cx, cy, 0.0, s))
        # consume the row's allotted height (up to total available)
        y += s
    return out


def _row_family(n):
    """Enumerate structured row packings."""
    cands = []
    # Partition n into rows, try a range of row count and height schemes.
    for r in range(1, n + 1):
        if r > n:
            continue
        # counts: distribute n squares over r rows as evenly as possible
        base = n // r
        rem = n % r
        counts = [base + (1 if i < rem else 0) for i in range(r)]
        counts = [c for c in counts if c > 0]
        if not counts:
            continue
        r2 = len(counts)
        # scheme A: equal heights
        for h in (1.0 / r2,):
            heights = [h] * r2
            cands.append(_row_layout(counts, heights))
        # scheme B: heights proportional to 1/counts (equal-area rows)
        inv = [1.0 / c for c in counts]
        tot = sum(inv)
        heights = [v / tot for v in inv]
        cands.append(_row_layout(counts, heights))
        # scheme C: a few hand-varied schemes: one tall row + rest equal
        for tall_idx in range(r2):
            inv2 = [1.0 for _ in range(r2)]
            inv2[tall_idx] = 1.5
            tot2 = sum(inv2)
            heights = [v / tot2 for v in inv2]
            cands.append(_row_layout(counts, heights))
    return cands


def _big_square_layout(n, side, corner):
    if n < 1:
        return []
    s = side
    if s <= 0 or s > 1:
        return []
    big_cx = big_cy = s * 0.5
    if corner == 'tl':
        big_cx = 1 - s * 0.5
    elif corner == 'br':
        big_cy = 1 - s * 0.5
    elif corner == 'tr':
        big_cx = 1 - s * 0.5
        big_cy = 1 - s * 0.5
    out = [(big_cx, big_cy, 0.0, s)]
    rem = n - 1
    if rem <= 0:
        return out
    best = None
    best_sum = -1
    for split_right_first in (True, False):
        if split_right_first:
            strips = [(s, 0.0, 1.0 - s, 1.0), (0.0, s, s, 1.0 - s)]
        else:
            strips = [(0.0, s, 1.0, 1.0 - s), (s, 0.0, 1.0 - s, s)]
        areas = [w * h for (_, _, w, h) in strips]
        tot_area = sum(areas)
        if tot_area <= 1e-12:
            continue
        counts = [int(round(rem * a / tot_area)) for a in areas]
        counts[0] += rem - sum(counts)
        cand = list(out)
        for (sx, sy, sw, sh), c in zip(strips, counts):
            cand += _greedy_split(sx, sy, sw, sh, c)
        if len(cand) >= n:
            cand = cand[:n]
            tot = sum(cc[3] for cc in cand)
            if tot > best_sum:
                best_sum = tot
                best = cand
    return best if best is not None else out


def _make_layout(n, k):
    base = _grid(k)
    used = len(base)
    if used >= n:
        return base[:n]
    rem = n - used
    best = None
    best_sum = -1
    for frac in (0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 0.98, 1.0):
        s = frac / k
        strip_h = 1.0 - k * s
        if strip_h <= 1e-9:
            continue
        cand = []
        for i in range(k):
            for j in range(k):
                cand.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        extra = _greedy_split(0.0, k * s, 1.0, strip_h, rem)
        cand += extra
        if len(cand) < n:
            continue
        tot = sum(c[3] for c in cand)
        if tot > best_sum:
            best_sum = tot
            best = cand
    if best is None:
        best = base
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]


def _rect_split_layout(n, rng, depth=0):
    def rec(x, y, w, h, pieces):
        if pieces <= 1:
            s = min(w, h)
            return [(x + s * 0.5, y + s * 0.5, 0.0, s)]
        if w <= 0 or h <= 0:
            return [(x + w * 0.5, y + h * 0.5, 0.0, 0.0)] * pieces
        pieces_a = rng.randint(1, pieces - 1)
        pieces_b = pieces - pieces_a
        r = pieces_a / pieces
        r = min(max(r, 0.15), 0.85)
        if w >= h:
            wa = w * r
            return rec(x, y, wa, h, pieces_a) + rec(x + wa, y, w - wa, h, pieces_b)
        else:
            ha = h * r
            return rec(x, y, w, ha, pieces_a) + rec(x, y + ha, w, h - ha, pieces_b)
    return rec(0.0, 0.0, 1.0, 1.0, n)


def _expand(sqs, iters=400):
    sqs = [list(s) for s in sqs]
    n = len(sqs)
    order = list(range(n))

    def ok_full(idx, cand):
        old = sqs[idx]
        sqs[idx] = cand
        res = _feasible(sqs)
        if not res:
            sqs[idx] = old
        return res

    for _ in range(iters):
        improved = False
        random.shuffle(order)
        for i in order:
            cx, cy, a, s = sqs[i]
            for ds in (0.02, 0.01, 0.005, 0.002, 0.001):
                cand = [cx, cy, a, s + ds]
                if ok_full(i, cand):
                    s += ds
                    cx, cy, a, s = sqs[i]
                    improved = True
            for dx, dy in ((0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01),
                           (0.005, 0.005), (-0.005, 0.005),
                           (0.005, -0.005), (-0.005, -0.005)):
                cand = [cx + dx, cy + dy, a, s]
                if ok_full(i, cand):
                    improved = True
        if not improved:
            break

    return [(c[0], c[1], c[2], c[3]) for c in sqs]


def _best_sum(cand, n):
    if len(cand) < n:
        cand = cand + [(0.5, 0.5, 0.0, 0.0)] * (n - len(cand))
    cand = cand[:n]
    if not _feasible(cand):
        return None
    return sum(c[3] for c in cand), cand


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    k0 = max(1, math.isqrt(n))
    candidates = []

    # uniform grids and grid + leftover
    for k in range(max(1, k0 - 3), k0 + 4):
        if k <= 0:
            continue
        g = _grid(k)
        if len(g) >= n:
            candidates.append(g[:n])
        lay = _make_layout(n, k)
        if len(lay) == n:
            candidates.append(lay)

    # rectangular grids
    for nx in range(1, n + 1):
        for ny in range(1, n + 1):
            if nx * ny >= n and nx * ny <= n + 3:
                g = _grid_rect(nx, ny)
                if len(g) >= n:
                    candidates.append(g[:n])

    # row-based structured family
    for c in _row_family(n):
        if len(c) >= n:
            candidates.append(c[:n])

    # big-square + L-shape family
    for xi in range(4, 20):
        side = xi * 0.05
        for corner in ('bl', 'br', 'tl', 'tr'):
            cand = _big_square_layout(n, side, corner)
            if len(cand) >= n:
                candidates.append(cand[:n])

    # random guillotine subdivisions
    for _ in range(120):
        cand = _rect_split_layout(n, rng)
        if len(cand) == n:
            candidates.append(cand)

    best = None
    best_score = -1
    pool = []
    seen = set()
    for cand in candidates:
        r = _best_sum(cand, n)
        if r is None:
            continue
        sc, c2 = r
        key = tuple(round(x, 4) for sq in c2 for x in sq)
        if key in seen:
            continue
        seen.add(key)
        pool.append((sc, c2))
        if sc > best_score:
            best_score = sc
            best = c2

    if best is None:
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    pool.sort(key=lambda t: -t[0])
    pool = pool[:16]

    results = list(pool)
    for sc, c2 in pool:
        try:
            polished = _expand(c2, iters=300)
            r = _best_sum(polished, n)
            if r is not None:
                results.append(r)
        except Exception:
            pass

    results.sort(key=lambda t: -t[0])
    best = results[0][1]
    if not _feasible(best):
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    return best[:n]
# EVOLVE-BLOCK-END
