# EVOLVE-BLOCK-START
"""Greedy best-fit packing of squares into the unit square.

Two complementary constructions are built and the better one is kept:

1. "Corner + L-remainder": place a big axis-aligned square of side a in a
   corner; the remaining L-shape is split into two rectangles, each filled
   by a uniform grid of equal squares.  a is optimised by scanning.

2. "Greedy best fit": repeatedly add the next square by scanning a set of
   candidate centres and angles and choosing the placement that admits the
   largest side while not overlapping anything already placed.

A final SAT-based repair pass guarantees the output is overlap-free.
"""
import math


# ---------------------------------------------------------------------------
# Geometry helpers (rotated square overlap via SAT)
# ---------------------------------------------------------------------------

def _corners(cx, cy, ang, side):
    if side <= 0:
        return [(cx, cy)] * 4
    th = ang * 2.0 * math.pi
    c = math.cos(th)
    s = math.sin(th)
    h = side / 2.0
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * s, cy + dx * s + dy * c))
    return pts


def _separated(a, b, eps=0.0):
    """True if squares a and b have disjoint interiors (SAT)."""
    ca = _corners(*a)
    cb = _corners(*b)
    for poly in (ca, cb):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex = x2 - x1
            ey = y2 - y1
            ln = math.hypot(ex, ey)
            if ln <= 1e-15:
                continue
            ax = -ey / ln
            ay = ex / ln
            pa = [ax * x + ay * y for (x, y) in ca]
            pb = [ax * x + ay * y for (x, y) in cb]
            if max(pa) <= min(pb) + eps or max(pb) <= min(pa) + eps:
                return True
    return False


def _overlap_depth(a, b):
    """SAT minimum translation depth; <0 means separated."""
    ca = _corners(*a)
    cb = _corners(*b)
    axes = []
    for poly in (ca, cb):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex = x2 - x1
            ey = y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 1e-15:
                axes.append((-ey / ln, ex / ln))
    min_overlap = float('inf')
    for (ax, ay) in axes:
        pa = [ax * x + ay * y for (x, y) in ca]
        pb = [ax * x + ay * y for (x, y) in cb]
        if max(pa) <= min(pb) + 1e-12 or max(pb) <= min(pa) + 1e-12:
            return -1.0
        o = min(max(pa), max(pb)) - max(min(pa), min(pb))
        if o < min_overlap:
            min_overlap = o
    return min_overlap


def _inside_ok(cx, cy, ang, side):
    return (side / 2.0 <= cx <= 1.0 - side / 2.0 and
            side / 2.0 <= cy <= 1.0 - side / 2.0)


# ---------------------------------------------------------------------------
# Construction 1: corner square + L-shaped remainder of two grids
# ---------------------------------------------------------------------------

def _grid_in_rect(x0, y0, w, h, k, out):
    """Fill the (w x h) rectangle at (x0,y0) with k equal axis-aligned squares."""
    if k <= 0 or w <= 1e-12 or h <= 1e-12:
        return
    best = (0.0, 1, 1)
    for p in range(1, k + 1):
        q = (k + p - 1) // p
        side = min(w / p, h / q)
        if side > best[0] + 1e-15:
            best = (side, p, q)
    side, p, q = best
    if side <= 1e-12:
        return
    ox = x0 + (w - p * side) / 2.0
    oy = y0 + (h - q * side) / 2.0
    cnt = 0
    for i in range(p):
        for j in range(q):
            if cnt >= k:
                break
            out.append((ox + (i + 0.5) * side, oy + (j + 0.5) * side, 0.0, side))
            cnt += 1


def _corner_family(n, a_grid):
    best_val = -1.0
    best = None
    for a in a_grid:
        if a <= 0 or a >= 1:
            continue
        # big square in bottom-left corner
        rem_w = 1.0 - a
        # right strip: width rem_w, height 1.0 ; top strip: width a, height rem_w
        for k_big in (0, 1):
            n_rest = n - 1  # big square takes 1
            if n_rest < 0:
                continue
            for k1 in range(0, n_rest + 1):
                k2 = n_rest - k1
                out = []
                if k_big == 0:
                    out.append((a / 2.0, a / 2.0, 0.0, a))
                _grid_in_rect(a, 0.0, rem_w, 1.0, k1, out)      # right strip
                _grid_in_rect(0.0, a, a, rem_w, k2, out)        # top strip
                if len(out) < n:
                    # pad remaining with points in the top-right corner
                    while len(out) < n:
                        out.append((1.0 - 1e-9, 1.0 - 1e-9, 0.0, 0.0))
                val = sum(s[3] for s in out)
                if val > best_val:
                    best_val = val
                    best = out
    return best_val, best


# ---------------------------------------------------------------------------
# Construction 2: greedy largest-first best-fit
# ---------------------------------------------------------------------------

def _candidate_sites():
    sites = []
    m = 9
    for i in range(1, m):
        for j in range(1, m):
            sites.append((i / m, j / m))
    # also corners-biased grid
    for i in range(1, m):
        for j in range(1, m):
            sites.append((1.0 - i / m, j / m))
            sites.append((i / m, 1.0 - j / m))
    return sites


def _greedy(n, sites, angles=(0.0, 0.125, 0.25)):
    placed = []

    def max_side_at(cx, cy, ang, cap):
        """Largest side <= cap placeable at (cx,cy,ang) avoiding placed."""
        s = cap
        for (px, py, pa, ps) in placed:
            if _separated((cx, cy, ang, 1e-9), (px, py, pa, ps), eps=0.0):
                continue
            # estimate allowed side by shrinking
            lo, hi = 0.0, s
            for _ in range(20):
                mid = (lo + hi) / 2.0
                if _separated((cx, cy, ang, mid), (px, py, pa, ps)):
                    lo = mid
                else:
                    hi = mid
            s = min(s, lo)
            if s <= 1e-9:
                return 0.0
        # inside unit square
        return s

    for _ in range(n):
        best_side = -1.0
        best_pl = None
        for (cx, cy) in sites:
            for ang in angles:
                avail = 2.0 * min(cx, cy, 1.0 - cx, 1.0 - cy)
                cap = min(avail, 1.0)
                if cap <= best_side:
                    continue
                s = max_side_at(cx, cy, ang, cap)
                if s > best_side + 1e-12:
                    best_side = s
                    best_pl = (cx, cy, ang, s)
        if best_pl is None or best_side <= 1e-9:
            placed.append((0.5, 0.5, 0.0, 0.0))
        else:
            placed.append(best_pl)
    return placed


# ---------------------------------------------------------------------------
# Repair
# ---------------------------------------------------------------------------

def _repair(squares):
    sq = [list(s) for s in squares]
    n = len(sq)
    for _ in range(6000):
        worst = None
        wi = wj = -1
        for i in range(n):
            if sq[i][3] <= 1e-9:
                continue
            for j in range(i + 1, n):
                if sq[j][3] <= 1e-9:
                    continue
                ov = _overlap_depth(sq[i], sq[j])
                if ov > 1e-9:
                    if worst is None or ov > worst:
                        worst = ov
                        wi, wj = i, j
        if worst is None:
            break
        k = wi if sq[wi][3] >= sq[wj][3] else wj
        new_side = sq[k][3] - worst
        if new_side < 0:
            new_side = sq[k][3] * 0.5
        if new_side < 1e-9:
            new_side = 0.0
        sq[k][3] = new_side
    return [tuple(s) for s in sq]


def solve(n):
    if n <= 0:
        return []

    # corner family: scan a
    a_grid = [i / 64.0 for i in range(1, 64)]
    v1, s1 = _corner_family(n, a_grid)

    # greedy best fit
    sites = _candidate_sites()
    s2 = _greedy(n, sites, angles=(0.0, 0.125, 0.25, 0.375))
    v2 = sum(s[3] for s in s2)

    if v1 >= v2 and s1 is not None:
        best = s1
    else:
        best = s2

    out = []
    for (cx, cy, ang, sd) in best:
        sd = max(0.0, min(1.0, sd))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = ang % 1.0
        out.append((cx, cy, ang, sd))
    out = _repair(out)
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
