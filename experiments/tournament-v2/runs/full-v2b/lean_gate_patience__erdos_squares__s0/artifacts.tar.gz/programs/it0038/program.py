import math


def solve(n):
    """Constructive multi-scale guillotine packing.

    We repeatedly fill the available area with uniform square blocks.  Each step
    chooses a block layout: a row/column cut of the current rectangle that fits
    some number of equal squares of maximal side, then recurses on the two
    remaining sub-rectangles with the remaining square budget.
    """
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None

    # Candidate first-level guillotine cuts.  For a cut at fraction f along x
    # we get two rectangles: (f, 1) and (1-f, 1); similarly for y.
    # For each rectangle we compute the best uniform blocking of q squares,
    # recursively splitting the budget between the two rectangles.

    import functools

    @functools.lru_cache(maxsize=None)
    def block_value(w, h, q):
        """Maximum total side sum when packing q equal squares in a w x h rectangle."""
        if q <= 0:
            return 0.0, None
        # Largest side s such that some arrangement of q squares of side s fits.
        # Allow a grid a x b with a*b >= q.  s = min(w/a, h/b) maximised over a,b.
        best_v = 0.0
        best_s = 0.0
        best_grid = (0, 0)
        # upper bound on a
        amax = int(w / 1e-12) + 1 if w > 0 else 1
        bmax = int(h / 1e-12) + 1 if h > 0 else 1
        # We only need a,b up to q since more cells than squares is useless.
        for a in range(1, q + 1):
            # need b >= ceil(q/a)
            bmin = (q + a - 1) // a
            # optimal b: as small as possible gives largest s
            b = bmin
            s = min(w / a, h / b)
            if s > best_s:
                # check fit
                if a * b <= q * 1 and w >= a * s - 1e-15 and h >= b * s - 1e-15:
                    pass
            # maximise min(w/a, h/b): for each a choose b to balance
            # b such that w/a == h/b => b = h*a/w; try floor and ceil
            if w > 0 and h > 0:
                bbal = h * a / w
                for bb in (max(bmin, int(math.floor(bbal))), max(bmin, int(math.ceil(bbal))), bmin):
                    if bb < 1:
                        bb = 1
                    if a * bb >= q:
                        ss = min(w / a, h / bb)
                        if ss > best_s:
                            best_s = ss
                            best_grid = (a, bb)
        best_v = best_s * q
        return best_v, best_grid

    def split_budget(w, h, q):
        """Best guillotine packing of q equal squares in rectangle w x h."""
        if q <= 0:
            return 0.0, []
        v, grid = block_value(w, h, q)
        if v <= 0:
            return 0.0, []
        a, b = grid
        s = min(w / a, h / b)
        placements = []
        used = 0
        for i in range(a):
            for j in range(b):
                if used >= q:
                    break
                cx = (i + 0.5) * s
                cy = (j + 0.5) * s
                placements.append((cx, cy, s))
                used += 1
            if used >= q:
                break
        return s * q, placements

    # Try guillotine splits recursively across the unit square.
    # State: list of (x, y, w, h, q).  Start with one rectangle.
    # We use a simple recursive guillotine over the whole unit square choosing
    # either to fill as a uniform block or to cut into two.

    memo = {}

    def rec(x, y, w, h, q):
        if q <= 0:
            return 0.0, []
        key = (round(x, 9), round(y, 9), round(w, 9), round(h, 9), q)
        if key in memo:
            return memo[key]

        # Option 1: fill uniformly
        v1, pl1 = split_budget(w, h, q)
        best_v = v1
        best_p = [(x + cx, y + cy, 0.0, s) for (cx, cy, s) in pl1]

        # Option 2: vertical or horizontal guillotine cut splitting q
        if q >= 2:
            # candidate cut positions: balance on a few fractions
            for frac in (0.5, 0.25, 0.75, 1.0 / 3.0, 2.0 / 3.0):
                # vertical cut
                w1 = w * frac
                w2 = w * (1 - frac)
                if w1 > 1e-12 and w2 > 1e-12:
                    for q1 in range(1, q):
                        q2 = q - q1
                        # only try a few q1 near balanced by area
                        va, pa = rec(x, y, w1, h, q1)
                        vb, pb = rec(x + w1, y, w2, h, q2)
                        tot = va + vb
                        if tot > best_v:
                            best_v = tot
                            best_p = pa + pb
                # horizontal cut
                h1 = h * frac
                h2 = h * (1 - frac)
                if h1 > 1e-12 and h2 > 1e-12:
                    for q1 in range(1, q):
                        q2 = q - q1
                        va, pa = rec(x, y, w, h1, q1)
                        vb, pb = rec(x, y + h1, w, h2, q2)
                        tot = va + vb
                        if tot > best_v:
                            best_v = tot
                            best_p = pa + pb

        memo[key] = (best_v, best_p)
        return best_v, best_p

    # Limit recursion effort: try a coarse search first.
    def search(x, y, w, h, q, depth):
        if q <= 0:
            return 0.0, []
        if depth >= 2 or q <= 1:
            v, pl = split_budget(w, h, q)
            return v, [(x + cx, y + cy, 0.0, s) for (cx, cy, s) in pl]

        v1, pl1 = split_budget(w, h, q)
        best_v = v1
        best_p = [(x + cx, y + cy, 0.0, s) for (cx, cy, s) in pl1]

        # try balanced two-way splits
        for frac in (0.5, 1.0 / 3.0, 2.0 / 3.0, 0.25, 0.75):
            # vertical
            w1 = w * frac
            w2 = w - w1
            if w1 > 1e-9 and w2 > 1e-9:
                # split q proportional to area
                q1 = max(1, min(q - 1, int(round(q * w1 / w))))
                for dq in (-1, 0, 1):
                    qq1 = q1 + dq
                    if 1 <= qq1 <= q - 1:
                        va, pa = search(x, y, w1, h, qq1, depth + 1)
                        vb, pb = search(x + w1, y, w2, h, q - qq1, depth + 1)
                        if va + vb > best_v:
                            best_v = va + vb
                            best_p = pa + pb
            # horizontal
            h1 = h * frac
            h2 = h - h1
            if h1 > 1e-9 and h2 > 1e-9:
                q1 = max(1, min(q - 1, int(round(q * h1 / h))))
                for dq in (-1, 0, 1):
                    qq1 = q1 + dq
                    if 1 <= qq1 <= q - 1:
                        va, pa = search(x, y, w, h1, qq1, depth + 1)
                        vb, pb = search(x, y + h1, w, h2, q - qq1, depth + 1)
                        if va + vb > best_v:
                            best_v = va + vb
                            best_p = pa + pb

        return best_v, best_p

    v, pl = search(0.0, 0.0, 1.0, 1.0, n, 0)
    squares = []
    for (cx, cy, s) in pl:
        squares.append((cx, cy, 0.0, s))
    if len(squares) < n:
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return [tuple(x) for x in squares[:n]]
