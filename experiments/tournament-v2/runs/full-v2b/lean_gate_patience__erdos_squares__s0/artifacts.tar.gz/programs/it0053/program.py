# EVOLVE-BLOCK-START
"""Multi-scale guillotine packing of squares into the unit square.

Recursively split a rectangle into two sub-rectangles (guillotine cuts).
At each leaf place a uniform block of equal squares.  A bounded search
over cut positions and block layouts maximises the total sum of side
lengths, with memoization and pruning.  A final repair pass removes any
residual overlaps so the output is always valid.
"""
import math


def _block_value(rw, rh, k):
    """Best value and grid (p,q) for a uniform block of k squares
    packed axis-aligned inside a (rw, rh) rectangle."""
    best = (0.0, 1, 1)
    for p in range(1, k + 1):
        q = (k + p - 1) // p
        side = min(rw / p, rh / q)
        if side > best[0] + 1e-15:
            best = (side, p, q)
    return best


def _fill_rect(x0, y0, rw, rh, k, side, p, q):
    """Place k axis-aligned squares of equal side as a centred p x q grid."""
    if k <= 0 or side <= 1e-12:
        return [(0.5, 0.5, 0.0, 0.0)] * max(k, 0)
    gx = p * side
    gy = q * side
    ox = x0 + (rw - gx) / 2.0
    oy = y0 + (rh - gy) / 2.0
    out = []
    count = 0
    for i in range(p):
        for j in range(q):
            if count >= k:
                break
            out.append((ox + (i + 0.5) * side, oy + (j + 0.5) * side, 0.0, side))
            count += 1
    return out


def _candidates(rw, rh, k):
    cands = set()
    # coarser fixed grid, plus block-aspect-derived fractions
    for t in (1, 2, 3, 4, 5):
        cands.add(t / 6.0)
    s, p, q = _block_value(rw, rh, k)
    cands.add(min(1.0, p / float(max(p, q))))
    cands.add(min(1.0, q / float(max(p, q))))
    for p in range(1, k + 1):
        cands.add(p / float(k))
    out = []
    for f in cands:
        if 1e-9 < f < 1.0 - 1e-9:
            out.append(f)
    return out


def _search(x0, y0, rw, rh, k, depth, memo):
    if k <= 0:
        return 0.0, []
    key = (round(rw, 8), round(rh, 8), k, depth)
    if key in memo:
        return memo[key]

    side, p, q = _block_value(rw, rh, k)
    best_val = k * side
    best_sq = _fill_rect(x0, y0, rw, rh, k, side, p, q)

    if depth <= 0 or k == 1:
        memo[key] = (best_val, best_sq)
        return best_val, best_sq

    cands = _candidates(rw, rh, k)
    for axis in (0, 1):
        length = rw if axis == 0 else rh
        if length <= 1e-9:
            continue
        for frac in cands:
            if axis == 0:
                r1 = (x0, y0, rw * frac, rh)
                r2 = (x0 + rw * frac, y0, rw * (1 - frac), rh)
            else:
                r1 = (x0, y0, rw, rh * frac)
                r2 = (x0, y0 + rh * frac, rw, rh * (1 - frac))
            for k1 in range(0, k + 1):
                k2 = k - k1
                if k1 == 0 and k2 == 0:
                    continue
                ub1 = k1 * min(r1[2], r1[3]) if k1 else 0.0
                ub2 = k2 * min(r2[2], r2[3]) if k2 else 0.0
                if ub1 + ub2 <= best_val + 1e-12:
                    continue
                v1, s1 = _search(r1[0], r1[1], r1[2], r1[3], k1, depth - 1, memo)
                v2, s2 = _search(r2[0], r2[1], r2[2], r2[3], k2, depth - 1, memo)
                if v1 + v2 > best_val + 1e-12:
                    best_val = v1 + v2
                    best_sq = s1 + s2
    memo[key] = (best_val, best_sq)
    return best_val, best_sq


# ---------------------------------------------------------------------------
# Geometry helpers for overlap detection / repair.
# ---------------------------------------------------------------------------

def _corners(cx, cy, ang, side):
    """Return the 4 corners of a (possibly rotated) square."""
    if side <= 0:
        return [(cx, cy)] * 4
    th = ang * 2.0 * math.pi
    c = math.cos(th)
    s = math.sin(th)
    h = side / 2.0
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * s, cy + dx * s + dy * c))
    return pts


def _overlap_area(a, b):
    """Approximate interior overlap measure between two squares via SAT.

    Returns min separation depth (<0 means no real overlap).
    """
    ca = _corners(*a)
    cb = _corners(*b)
    axes = []
    for poly in (ca, cb):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex = x2 - x1
            ey = y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 1e-15:
                axes.append((-ey / ln, ex / ln))
    min_overlap = float('inf')
    for (ax, ay) in axes:
        pa = [ax * x + ay * y for (x, y) in ca]
        pb = [ax * x + ay * y for (x, y) in cb]
        if max(pa) <= min(pb) + 1e-12 or max(pb) <= min(pa) + 1e-12:
            return -1.0
        o = min(max(pa), max(pb)) - max(min(pa), min(pb))
        min_overlap = min(min_overlap, o)
    return min_overlap


def _repair(squares):
    """Iteratively shrink squares to remove any interior overlaps."""
    sq = [list(s) for s in squares]
    n = len(sq)
    for _ in range(4000):
        worst = None
        wi = wj = -1
        for i in range(n):
            if sq[i][3] <= 1e-9:
                continue
            for j in range(i + 1, n):
                if sq[j][3] <= 1e-9:
                    continue
                ov = _overlap_area(sq[i], sq[j])
                if ov > 1e-9:
                    if worst is None or ov > worst:
                        worst = ov
                        wi, wj = i, j
        if worst is None:
            break
        if sq[wi][3] >= sq[wj][3]:
            k = wi
        else:
            k = wj
        new_side = sq[k][3] - worst
        if new_side < 0:
            new_side = sq[k][3] * 0.5
        if new_side < 1e-9:
            new_side = 0.0
        sq[k][3] = new_side
    return [tuple(s) for s in sq]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    best_total = -1.0
    best_sq = None
    for depth in (1, 2, 3):
        memo = {}
        val, sq = _search(0.0, 0.0, 1.0, 1.0, n, depth, memo)
        if val > best_total:
            best_total = val
            best_sq = sq
    if best_sq is None:
        k = max(1, math.isqrt(n))
        side = 1.0 / k
        best_sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        best_sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))

    out = []
    for (cx, cy, ang, sd) in best_sq:
        sd = max(0.0, min(1.0, sd))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = max(0.0, min(1.0, ang))
        out.append((cx, cy, ang, sd))
    out = _repair(out)
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
