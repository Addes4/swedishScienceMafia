# EVOLVE-BLOCK-START
"""Sum of side lengths maximization via analytic layout families.

Key facts:
 - Placing n equal axis-aligned squares in the unit square: best is to choose
   p columns x q rows with p*q >= n, side = min(1/p, 1/q); use n of them.
 - Mixing sizes: put a big square in a corner and fill the remaining L-shape
   with a grid of smaller squares.
 - Rotated (45 deg) squares can fill a band of height h with side s = h/sqrt(2)
   and width occupation s*sqrt(2)=h.
We evaluate a curated set of such families and return the best.
"""
import math


def _grid_layout(n_cells, w, h):
    """Place n_cells equal axis-aligned squares in w x h region.
    Returns (value, side, p, q)."""
    if n_cells <= 0:
        return (0.0, 0.0, 0, 0)
    best = (0.0, 0.0, 0, 0)
    for p in range(1, n_cells + 1):
        q = (n_cells + p - 1) // p
        s = min(w / p, h / q)
        v = s * n_cells
        if v > best[0] + 1e-15:
            best = (v, s, p, q)
    return best


def _emit_grid(w, h, n_cells, p, q, s, n_total):
    out = []
    bw, bh = p * s, q * s
    ox, oy = (w - bw) * 0.5, (h - bh) * 0.5
    cnt = 0
    for j in range(q):
        for i in range(p):
            if cnt >= n_cells:
                break
            out.append((ox + (i + 0.5) * s, oy + (j + 0.5) * s, 0.0, s))
            cnt += 1
        if cnt >= n_cells:
            break
    while len(out) < n_total:
        out.append((w * 0.5, h * 0.5, 0.0, 0.0))
    return out[:n_total]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_val = -1.0
    best_pl = None

    def consider(v, pl):
        nonlocal best_val, best_pl
        if v > best_val + 1e-12:
            best_val = v
            best_pl = pl

    # --- Family A: uniform p x q grid over the whole unit square ---
    v, s, p, q = _grid_layout(n, 1.0, 1.0)
    consider(v, _emit_grid(1.0, 1.0, n, p, q, s, n))

    # --- Family B: split into two rectangles (vertical or horizontal),
    # each filled with an equal grid; search split fraction and counts. ---
    for axis in (0, 1):
        for t in range(1, n):
            r = n - t
            fr = set()
            for den in (2, 3, 4, 5, 6, 7, 8, 10):
                for num in range(1, den):
                    fr.add(num / den)
            for m in (t, r):
                vm, sm, pm, qm = _grid_layout(m, 1.0, 1.0)
                if sm > 0:
                    need = (pm * sm) if axis == 0 else (qm * sm)
                    if 0 < need < 1.0:
                        fr.add(need)
                        fr.add(1.0 - need)
            for frac in fr:
                if frac <= 1e-9 or frac >= 1 - 1e-9:
                    continue
                if axis == 0:
                    w1, h1 = frac, 1.0
                    w2, h2 = 1.0 - frac, 1.0
                else:
                    w1, h1 = 1.0, frac
                    w2, h2 = 1.0, 1.0 - frac
                v1, s1, p1, q1 = _grid_layout(t, w1, h1)
                v2, s2, p2, q2 = _grid_layout(r, w2, h2)
                tv = v1 + v2
                if tv > best_val + 1e-12:
                    pl1 = _emit_grid(w1, h1, t, p1, q1, s1, t)
                    pl2 = _emit_grid(w2, h2, r, p2, q2, s2, r)
                    if axis == 0:
                        off2 = (frac, 0.0)
                    else:
                        off2 = (0.0, frac)
                    merged = list(pl1)
                    for (cx, cy, a, ss) in pl2:
                        merged.append((cx + off2[0], cy + off2[1], a, ss))
                    consider(tv, merged)

    # --- Family C: big corner square + remainder L-shape grid ---
    def corner_eval(a, rem):
        if a <= 1e-9 or a >= 1 - 1e-9:
            return None
        best_local = None
        for k in range(0, rem + 1):
            r2 = rem - k
            v1, s1, p1, q1 = _grid_layout(k, 1.0 - a, a) if k > 0 else (0.0, 0.0, 0, 0)
            v2, s2, p2, q2 = _grid_layout(r2, 1.0, 1.0 - a) if r2 > 0 else (0.0, 0.0, 0, 0)
            tot = a + v1 + v2
            if best_local is None or tot > best_local[0] + 1e-12:
                best_local = (tot, a, k, p1, q1, s1, p2, q2, s2, r2)
        return best_local

    def corner_build(res):
        tot, a, k, p1, q1, s1, p2, q2, s2, r2 = res
        pl = [(a * 0.5, a * 0.5, 0.0, a)]
        if k > 0:
            sub = _emit_grid(1.0 - a, a, k, p1, q1, s1, k)
            for (cx, cy, ang, ss) in sub:
                pl.append((cx + a, cy, ang, ss))
        if r2 > 0:
            sub = _emit_grid(1.0, 1.0 - a, r2, p2, q2, s2, r2)
            for (cx, cy, ang, ss) in sub:
                pl.append((cx, cy + a, ang, ss))
        while len(pl) < n:
            pl.append((0.5, 0.5, 0.0, 0.0))
        return pl[:n]

    # scan candidate a values (fixed fractions + grid-driven)
    cand_a = set()
    for den in (2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20):
        for num in range(1, den):
            cand_a.add(num / den)
    for m in range(1, n):
        vm, sm, pm, qm = _grid_layout(m, 1.0, 1.0)
        if 0 < sm < 1:
            cand_a.add(sm)
            cand_a.add(sm * 2)
    cand_a = sorted(x for x in cand_a if 1e-6 < x < 1 - 1e-6)

    best_corner = None
    for a in cand_a:
        res = corner_eval(a, n - 1)
        if res is None:
            continue
        if best_corner is None or res[0] > best_corner[0] + 1e-12:
            best_corner = res

    # Continuous refinement of the corner side via golden-section search.
    # The objective is piecewise-smooth (min of linear functions), so refine.
    def obj_a(a):
        res = corner_eval(a, n - 1)
        return -res[0] if res is not None else 0.0

    def golden_min(f, lo, hi, iters=60):
        gr = (math.sqrt(5.0) - 1.0) / 2.0
        c = hi - gr * (hi - lo)
        d = lo + gr * (hi - lo)
        fc, fd = f(c), f(d)
        for _ in range(iters):
            if fc < fd:
                hi, d, fd = d, c, fc
                c = hi - gr * (hi - lo)
                fc = f(c)
            else:
                lo, c, fc = c, d, fd
                d = lo + gr * (hi - lo)
                fd = f(d)
        xm = 0.5 * (lo + hi)
        return xm, f(xm)

    if best_corner is not None:
        # try refining a in a window around the best candidate
        a0 = best_corner[1]
        lo = max(1e-4, a0 - 0.15)
        hi = min(1 - 1e-4, a0 + 0.15)
        if hi > lo:
            xm, fm = golden_min(obj_a, lo, hi, iters=80)
            res = corner_eval(xm, n - 1)
            if res is not None and -fm > best_corner[0] + 1e-12:
                best_corner = res

    if best_corner is not None and best_corner[0] > best_val + 1e-12:
        consider(best_corner[0], corner_build(best_corner))

    # --- Family E: big corner square + remainder split into two strips,
    # scanning both a and the split point continuously. ---
    def two_strip_eval(a, t):
        # right strip region: width (1-a), height 1 (full height minus?) Use:
        # corner square [0,a]x[0,a]; right strip width (1-a) full height 1;
        # top-left strip width a, height (1-a).
        if a <= 1e-9 or a >= 1 - 1e-9:
            return None
        best_local = None
        for k in range(0, t + 1):
            r2 = t - k
            v1, s1, p1, q1 = _grid_layout(k, 1.0 - a, 1.0) if k > 0 else (0.0, 0.0, 0, 0)
            v2, s2, p2, q2 = _grid_layout(r2, a, 1.0 - a) if r2 > 0 else (0.0, 0.0, 0, 0)
            tot = a + v1 + v2
            if best_local is None or tot > best_local[0] + 1e-12:
                best_local = (tot, a, k, p1, q1, s1, p2, q2, s2, r2)
        return best_local

    best_two = None
    for a in cand_a:
        res = two_strip_eval(a, n - 1)
        if res is None:
            continue
        if best_two is None or res[0] > best_two[0] + 1e-12:
            best_two = res

    if best_two is not None:
        a0 = best_two[1]
        lo = max(1e-4, a0 - 0.15)
        hi = min(1 - 1e-4, a0 + 0.15)

        def obj_two(a):
            res = two_strip_eval(a, n - 1)
            return -res[0] if res is not None else 0.0

        if hi > lo:
            xm, fm = golden_min(obj_two, lo, hi, iters=80)
            res = two_strip_eval(xm, n - 1)
            if res is not None and -fm > best_two[0] + 1e-12:
                best_two = res

        if best_two[0] > best_val + 1e-12:
            tot, a, k, p1, q1, s1, p2, q2, s2, r2 = best_two
            pl = [(a * 0.5, a * 0.5, 0.0, a)]
            if k > 0:
                sub = _emit_grid(1.0 - a, 1.0, k, p1, q1, s1, k)
                for (cx, cy, ang, ss) in sub:
                    pl.append((cx + a, cy, ang, ss))
            if r2 > 0:
                sub = _emit_grid(a, 1.0 - a, r2, p2, q2, s2, r2)
                for (cx, cy, ang, ss) in sub:
                    pl.append((cx, cy + a, ang, ss))
            while len(pl) < n:
                pl.append((0.5, 0.5, 0.0, 0.0))
            consider(tot, pl[:n])

    # --- Family D: 45-degree tilted band(s) ---
    sq2 = math.sqrt(2.0)
    for h in cand_a:
        side = h / sq2
        cnt_fit = int(1.0 / h + 1e-9)
        if cnt_fit <= 0:
            continue
        if cnt_fit > n:
            continue
        rem = n - cnt_fit
        v_rem, sr, pr, qr = _grid_layout(rem, 1.0, 1.0 - h) if rem > 0 else (0.0, 0.0, 0, 0)
        tot = cnt_fit * side + v_rem
        if tot > best_val + 1e-12:
            pl = []
            for i in range(cnt_fit):
                cx = (i + 0.5) * h
                cy = h * 0.5
                pl.append((cx, cy, 0.125, side))
            if rem > 0:
                sub = _emit_grid(1.0, 1.0 - h, rem, pr, qr, sr, rem)
                for (cx, cy, ang, ss) in sub:
                    pl.append((cx, cy + h, ang, ss))
            while len(pl) < n:
                pl.append((0.5, 0.5, 0.0, 0.0))
            consider(tot, pl[:n])

    if best_pl is None:
        v, s, p, q = _grid_layout(n, 1.0, 1.0)
        best_pl = _emit_grid(1.0, 1.0, n, p, q, s, n)

    result = []
    for (cx, cy, a, s) in best_pl[:n]:
        s = max(0.0, min(1.0, float(s)))
        cx = max(0.0, min(1.0, float(cx)))
        cy = max(0.0, min(1.0, float(cy)))
        result.append((cx, cy, 0.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END
