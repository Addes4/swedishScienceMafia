"""Multi-scale guillotine packing plus a rotation/scale polish.

First build a constructive guillotine layout (recursive subdivision into cells with
equal-square grids).  Then attempt to improve it by applying a global rotation and
inflating all squares about the centre until they no longer fit inside the unit square
(feasibility checked by a separating-axis-style test against the box boundary).  We also
try the axis-aligned variant, and keep the best feasible result.
"""

import math
from itertools import product


def _best_block(n, w, h):
    """Place n equal squares in a w x h rectangle as a grid; return (side, cols, rows)
    maximising the side, with cols*rows >= n."""
    if n <= 0:
        return 0.0, 0, 0
    best = (0.0, 1, 1)
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        s = min(w / cols, h / rows)
        if s > best[0]:
            best = (s, cols, rows)
    return best


def _guillotine(n):
    """Return list of (cx, cy, side) axis-aligned equal-square placements."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 1.0)]

    leaves = [(0.0, 0.0, 1.0, 1.0, n)]

    for _ in range(400):
        best_gain = 0.0
        best_idx = -1
        best_partition = None

        for idx, (x, y, w, h, cnt) in enumerate(leaves):
            if cnt < 2:
                continue
            cur_side, _, _ = _best_block(cnt, w, h)
            cur_val = cnt * cur_side
            if w >= h:
                for a in range(1, cnt):
                    b = cnt - a
                    frac = math.sqrt(a) / (math.sqrt(a) + math.sqrt(b))
                    frac = min(max(frac, 1e-3), 1 - 1e-3)
                    w1 = w * frac
                    w2 = w - w1
                    s1, _, _ = _best_block(a, w1, h)
                    s2, _, _ = _best_block(b, w2, h)
                    val = a * s1 + b * s2
                    gain = val - cur_val
                    if gain > best_gain:
                        best_gain = gain
                        best_idx = idx
                        best_partition = (a, b, 'v', frac)
            else:
                for a in range(1, cnt):
                    b = cnt - a
                    frac = math.sqrt(a) / (math.sqrt(a) + math.sqrt(b))
                    frac = min(max(frac, 1e-3), 1 - 1e-3)
                    h1 = h * frac
                    h2 = h - h1
                    s1, _, _ = _best_block(a, w, h1)
                    s2, _, _ = _best_block(b, w, h2)
                    val = a * s1 + b * s2
                    gain = val - cur_val
                    if gain > best_gain:
                        best_gain = gain
                        best_idx = idx
                        best_partition = (a, b, 'h', frac)

        if best_idx < 0 or best_gain <= 1e-12:
            break

        x, y, w, h, cnt = leaves[best_idx]
        a, b, kind, frac = best_partition
        if kind == 'v':
            w1 = w * frac
            leaves[best_idx] = (x, y, w1, h, a)
            leaves.append((x + w1, y, w - w1, h, b))
        else:
            h1 = h * frac
            leaves[best_idx] = (x, y, w, h1, a)
            leaves.append((x, y + h1, w, h - h1, b))

    out = []
    for (x, y, w, h, cnt) in leaves:
        side, cols, rows = _best_block(cnt, w, h)
        if side <= 0:
            out += [(x + w / 2, y + h / 2, 0.0)] * cnt
            continue
        gw = cols * side
        gh = rows * side
        ox = x + (w - gw) / 2
        oy = y + (h - gh) / 2
        placed = 0
        for i in range(cols):
            for j in range(rows):
                placed += 1
                cx = ox + (i + 0.5) * side
                cy = oy + (j + 0.5) * side
                out.append((cx, cy, side))
        while placed < cnt:
            out.append((x + w / 2, y + h / 2, 0.0))
            placed += 1
    return out[:n]


def _corner_extent(cx, cy, side, ang, ux, uy):
    """Max projection of a square's corners of half-size side/2 on unit vector (ux,uy),
    assuming centre (cx,cy)."""
    c = math.cos(2 * math.pi * ang)
    s = math.sin(2 * math.pi * ang)
    h = side / 2.0
    ex = h * (abs(ux * c - uy * s) + abs(ux * s + uy * c))
    ey = h * (abs(ux * s + uy * c) + abs(ux * c - uy * s))
    # simpler: project onto (ux,uy) of the two rotated axes
    e = h * (abs(ux * c + uy * s) + abs(ux * (-s) + uy * c))
    return e


def _fits(cx, cy, side, ang, tol=1e-9):
    c = math.cos(2 * math.pi * ang)
    s = math.sin(2 * math.pi * ang)
    h = side / 2.0
    # square aligned with rotated axes: corners at centre +- h*u +- h*v
    # u = (c, s), v = (-s, c)
    for sx in (-1, 1):
        for sy in (-1, 1):
            px = cx + sx * h * c - sy * h * s
            py = cy + sx * h * s + sy * h * c
            if px < -tol or px > 1 + tol or py < -tol or py > 1 + tol:
                return False
    return True


def _max_scale_for_angle(sqs, ang):
    """Given axis-aligned squares as (cx0,cy0,side) about centre 0.5, rotate by ang about
    (0.5,0.5) and find max common scale factor <=1 keeping all inside [0,1]^2."""
    c = math.cos(2 * math.pi * ang)
    s = math.sin(2 * math.pi * ang)
    scale = 1.0
    for (cx0, cy0, side) in sqs:
        if side <= 0:
            continue
        # relative coord about centre
        rx = cx0 - 0.5
        ry = cy0 - 0.5
        cxr = rx * c - ry * s
        cyr = rx * s + ry * c
        h = side / 2.0
        # corners extents in x and y after rotating this square by ang too
        # we rotate squares as a rigid body with the whole configuration
        # corner offsets in x: h*(|c|+|s|) ; same in y
        ex = h * (abs(c) + abs(s))
        ey = ex
        # constraint: |cxr| + scale*ex <= 0.5  => scale <= (0.5 - |cxr|)/ex
        if ex < 1e-15:
            continue
        lim = (0.5 - abs(cxr)) / ex
        if abs(cyr) + ex * scale > 0.5:
            limy = (0.5 - abs(cyr)) / ey
            lim = min(lim, limy)
        scale = min(scale, lim)
    return scale


def _apply(sqs, ang, scale):
    c = math.cos(2 * math.pi * ang)
    s = math.sin(2 * math.pi * ang)
    res = []
    for (cx0, cy0, side) in sqs:
        rx = cx0 - 0.5
        ry = cy0 - 0.5
        cxr = rx * c - ry * s
        cyr = rx * s + ry * c
        res.append((0.5 + cxr * scale, 0.5 + cyr * scale, ang, side * scale))
    return res


def solve(n):
    if n <= 0:
        return []
    base = _guillotine(n)
    if not base:
        return [(0.5, 0.5, 0.0, 0.0)] * n

    # axis-aligned baseline
    best = [(cx, cy, 0.0, side) for (cx, cy, side) in base]
    best_val = sum(s for (_, _, s) in base)

    # try rotations; for each, compute max uniform scale keeping everything inside
    for k in range(1, 24):
        ang = k / 96.0  # up to ~0.24 turn
        if ang >= 0.25:
            break
        sc = _max_scale_for_angle(base, ang)
        if sc <= 1.0:
            # shrinking reduces value, so skip unless we can gain
            continue
        val = best_val * sc
        if val <= best_val + 1e-12:
            continue
        cand = [(cx, cy, 0.0, side) for (cx, cy, side) in base]
        # rotate whole config about centre
        c = math.cos(2 * math.pi * ang)
        s = math.sin(2 * math.pi * ang)
        new = []
        ok = True
        for (cx0, cy0, side) in base:
            rx = cx0 - 0.5
            ry = cy0 - 0.5
            cxr = rx * c - ry * s
            cyr = rx * s + ry * c
            ncx = 0.5 + cxr * sc
            ncy = 0.5 + cyr * sc
            nside = side * sc
            if not _fits(ncx, ncy, nside, ang):
                ok = False
                break
            new.append((ncx, ncy, ang, nside))
        if ok:
            v = sum(s for (_, _, _, s) in new)
            if v > best_val + 1e-12:
                best_val = v
                best = new

    # pad/truncate
    result = list(best)
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
