# EVOLVE-BLOCK-START
"""Structured layout search plus a light coordinate-descent expansion."""
import math
import random


def _vertices(cx, cy, ang, s):
    c, sn = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _feasible(sqs):
    """Basic check: inside unit square and roughly non-overlapping via SAT."""
    boxes = []
    for (cx, cy, ang, s) in sqs:
        if s <= 0:
            continue
        if cx < 0 or cx > 1 or cy < 0 or cy > 1:
            return False
        v = _vertices(cx, cy, ang, s)
        xs = [p[0] for p in v]
        ys = [p[1] for p in v]
        if min(xs) < -1e-9 or max(xs) > 1 + 1e-9 or min(ys) < -1e-9 or max(ys) > 1 + 1e-9:
            return False
        boxes.append(v)
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            if _overlap(boxes[i], boxes[j]):
                return False
    return True


def _overlap(A, B):
    for poly in (A, B):
        n = len(poly)
        for k in range(n):
            x1, y1 = poly[k]
            x2, y2 = poly[(k + 1) % n]
            ax, ay = -(y2 - y1), (x2 - x1)
            projA = [ax * p[0] + ay * p[1] for p in A]
            projB = [ax * p[0] + ay * p[1] for p in B]
            if max(projA) < min(projB) + 1e-9 or max(projB) < min(projA) + 1e-9:
                return False
    return True


def _grid(k, extra_row):
    """Return list of (cx, cy, ang, s) for a k x k grid, optionally with extra row."""
    res = []
    if not extra_row:
        if k == 0:
            return res
        s = 1.0 / k
        for i in range(k):
            for j in range(k):
                res.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        return res
    # layout: (k) full rows of k squares, plus a partial last row using smaller squares
    # grid of k rows: total squares = k*k + r, with r = extra_row.
    r = extra_row
    total = k * k + r
    if total <= 0:
        return res
    # Try: top part is a grid of k columns and (k) rows with side s1, bottom is r squares
    # side s1 placed in a row of r of them.
    # We solve: width used: k*s1 <= 1 ; bottom row: r*s2 <= 1 ; height: k*s1 + s2 <= 1
    # choose s1 = s2 = h for simplicity: h = 1/(k+1) when r <= k (fits) -> k*s = ... hmm
    # Simpler: uniform grid of (k+ ... ) Actually use the "fill" approach below.
    return res


def _greedy_split(cx0, cy0, w, h, remaining):
    """Guillotine pack: largest free rect, fill with largest square, split."""
    rects = [(cx0, cy0, w, h)]
    out = []
    for _ in range(remaining):
        best_i = -1
        best_s = 0.0
        for i, (x, y, rw, rh) in enumerate(rects):
            s = min(rw, rh)
            if s > best_s + 1e-12:
                best_s = s
                best_i = i
        if best_i < 0 or best_s <= 1e-12:
            break
        x, y, rw, rh = rects.pop(best_i)
        s = best_s
        out.append((x + s * 0.5, y + s * 0.5, 0.0, s))
        # split remaining
        if rw - s > rh - s:
            # horizontal split
            if rw - s > 1e-12:
                rects.append((x + s, y, rw - s, rh))
            if rh - s > 1e-12:
                rects.append((x, y + s, s, rh - s))
        else:
            if rh - s > 1e-12:
                rects.append((x, y + s, rw, rh - s))
            if rw - s > 1e-12:
                rects.append((x + s, y, rw - s, s))
    return out


def _make_layout(n, k):
    """One structured layout for given k: k*k grid plus greedy fill of remaining space."""
    base = _grid(k, 0)
    used = len(base)
    if used > n:
        return base[:n]
    # fit remaining in the gaps? Instead: use top square(s) region approach:
    # simplest: reserve a strip at top for leftovers and greedy-split it
    # Try: shrink the k-grid to occupy [0,1] x [0, h] then leftover strip [0,1] x [h,1].
    rem = n - used
    if rem <= 0:
        return base[:n]
    # Build: k-grid at bottom with side s, leftover strip height 1 - k*s
    # s can be up to 1/k but leave room: choose s so leftover strip can fit rem squares greedily
    best = None
    best_sum = -1
    for frac in (0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 0.98, 1.0):
        s = frac / k
        strip_h = 1.0 - k * s
        if strip_h <= 1e-9:
            continue
        cand = []
        for i in range(k):
            for j in range(k):
                cand.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        extra = _greedy_split(0.0, k * s, 1.0, strip_h, rem)
        cand += extra
        if len(cand) < n:
            continue
        tot = sum(c[3] for c in cand)
        if tot > best_sum:
            best_sum = tot
            best = cand
    if best is None:
        best = base
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]


def _expand(sqs, iters=400):
    """Light coordinate descent: try to grow each square in place."""
    sqs = [list(s) for s in sqs]
    n = len(sqs)
    order = list(range(n))

    def ok_full(idx, cand):
        old = sqs[idx]
        sqs[idx] = cand
        res = _feasible(sqs)
        if not res:
            sqs[idx] = old
        return res

    for _ in range(iters):
        improved = False
        random.shuffle(order)
        for i in order:
            cx, cy, a, s = sqs[i]
            # try growing
            for ds in (0.02, 0.01, 0.005, 0.002):
                cand = [cx, cy, a, s + ds]
                if ok_full(i, cand):
                    s += ds
                    cx, cy, a, s = sqs[i]
                    improved = True
            # try moving into free space to grow further
            for dx, dy in ((0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01), (0.005, 0.005),
                           (-0.005, 0.005), (0.005, -0.005), (-0.005, -0.005)):
                cand = [cx + dx, cy + dy, a, s]
                if ok_full(i, cand):
                    improved = True
        if not improved:
            break

    return [(c[0], c[1], c[2], c[3]) for c in sqs]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    k0 = max(1, math.isqrt(n))
    candidates = []
    for k in range(max(1, k0 - 2), k0 + 3):
        if k <= 0:
            continue
        # exact grid
        g = _grid(k, 0)
        if len(g) >= n:
            candidates.append(g[:n])
        # grid with greedy top strip
        lay = _make_layout(n, k)
        if len(lay) == n:
            candidates.append(lay)

    best = None
    best_score = -1
    for cand in candidates:
        if len(cand) < n:
            cand = cand + [(0.5, 0.5, 0.0, 0.0)] * (n - len(cand))
        cand = cand[:n]
        if not _feasible(cand):
            continue
        sc = sum(c[3] for c in cand)
        if sc > best_score:
            best_score = sc
            best = cand

    if best is None:
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    # light polish
    try:
        polished = _expand(best)
        if _feasible(polished) and sum(c[3] for c in polished) >= sum(c[3] for c in best) - 1e-9:
            best = polished
    except Exception:
        pass

    return best[:n]
# EVOLVE-BLOCK-END
