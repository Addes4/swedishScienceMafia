# EVOLVE-BLOCK-START
"""Sum of side lengths maximization via analytic layout families.

Families evaluated:
 - uniform p x q grid over the whole unit square
 - two rectangles (vertical/horizontal split), each filled with an equal grid
 - a big axis-aligned square in a corner, remainder L-shape filled by
   splitting into up to three sub-rectangles each filled with a uniform grid
 - a big axis-aligned square with the right strip further divided into
   stacked sub-blocks, giving more size flexibility
 - 45-degree tilted band plus an axis-aligned region
The best family is returned.
"""
import math


def _grid_layout(n_cells, w, h):
    """Place n_cells equal axis-aligned squares in w x h region.
    Returns (value, side, p, q)."""
    if n_cells <= 0:
        return (0.0, 0.0, 0, 0)
    best = (0.0, 0.0, 0, 0)
    for p in range(1, n_cells + 1):
        q = (n_cells + p - 1) // p
        s = min(w / p, h / q)
        v = s * n_cells
        if v > best[0] + 1e-15:
            best = (v, s, p, q)
    return best


def _emit_grid(w, h, n_cells, p, q, s, n_total):
    out = []
    bw, bh = p * s, q * s
    ox, oy = (w - bw) * 0.5, (h - bh) * 0.5
    cnt = 0
    for j in range(q):
        for i in range(p):
            if cnt >= n_cells:
                break
            out.append((ox + (i + 0.5) * s, oy + (j + 0.5) * s, 0.0, s))
            cnt += 1
        if cnt >= n_cells:
            break
    while len(out) < n_total:
        out.append((w * 0.5, h * 0.5, 0.0, 0.0))
    return out[:n_total]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_val = -1.0
    best_pl = None

    def consider(v, pl):
        nonlocal best_val, best_pl
        if v > best_val + 1e-12:
            best_val = v
            best_pl = pl

    # --- Family A: uniform p x q grid over the whole unit square ---
    v, s, p, q = _grid_layout(n, 1.0, 1.0)
    consider(v, _emit_grid(1.0, 1.0, n, p, q, s, n))

    # --- Family B: split into two rectangles, each filled with an equal grid ---
    for axis in (0, 1):
        for t in range(1, n):
            r = n - t
            fr = set()
            for den in (2, 3, 4, 5, 6, 7, 8, 10):
                for num in range(1, den):
                    fr.add(num / den)
            for m in (t, r):
                vm, sm, pm, qm = _grid_layout(m, 1.0, 1.0)
                if sm > 0:
                    need = (pm * sm) if axis == 0 else (qm * sm)
                    if 0 < need < 1.0:
                        fr.add(need)
                        fr.add(1.0 - need)
            for frac in fr:
                if frac <= 1e-9 or frac >= 1 - 1e-9:
                    continue
                if axis == 0:
                    w1, h1 = frac, 1.0
                    w2, h2 = 1.0 - frac, 1.0
                else:
                    w1, h1 = 1.0, frac
                    w2, h2 = 1.0, 1.0 - frac
                v1, s1, p1, q1 = _grid_layout(t, w1, h1)
                v2, s2, p2, q2 = _grid_layout(r, w2, h2)
                tv = v1 + v2
                if tv > best_val + 1e-12:
                    pl1 = _emit_grid(w1, h1, t, p1, q1, s1, t)
                    pl2 = _emit_grid(w2, h2, r, p2, q2, s2, r)
                    if axis == 0:
                        off2 = (frac, 0.0)
                    else:
                        off2 = (0.0, frac)
                    merged = list(pl1)
                    for (cx, cy, a, ss) in pl2:
                        merged.append((cx + off2[0], cy + off2[1], a, ss))
                    consider(tv, merged)

    # --- Family C: big corner square + remainder L-shape split into
    # up to three rectangles (right strip possibly stacked) each grid-filled. ---
    def corner3_eval(a, rem):
        """Big square in [0,a]x[0,a]. Remainder = right strip (1-a) x a
        plus top strip 1 x (1-a). Optionally split the right strip into two
        stacked sub-blocks and the top strip into two side-by-side sub-blocks.
        Returns best (total, layout-descriptor) or None."""
        if a <= 1e-9 or a >= 1 - 1e-9:
            return None
        best = None
        aw = 1.0 - a   # width of right strip
        ah = a         # height of right strip
        bh = 1.0 - a   # height of top strip
        # distribute rem among up to 4 blocks:
        #   k1,k2 : two stacked blocks in right strip (heights f*ah, (1-f)*ah)
        #   m1,m2 : two side-by-side blocks in top strip (widths g, 1-g)
        # Simplify: try a few f and g, and split rem counts.
        for f in (0.0, 0.5):  # 0.0 means single block for right strip
            if f == 0.0:
                rparts = [(aw, ah)]
            else:
                rparts = [(aw, ah * f), (aw, ah * (1.0 - f))]
            for g in (0.0, 0.5):
                if g == 0.0:
                    tparts = [(1.0, bh)]
                else:
                    tparts = [(1.0 * g, bh), (1.0 * (1.0 - g), bh)]
                nblk = len(rparts) + len(tparts)
                if nblk > rem + 4:
                    continue
                # distribute rem among nblk blocks
                # brute force small: use recursion over integer partitions
                parts = rparts + tparts
                # cap search: only try balanced distributions when rem large
                def rec(idx, left, acc):
                    nonlocal best
                    if idx == len(parts):
                        if left == 0:
                            tot = a
                            desc = []
                            for (w, h), cnt in zip(parts, acc):
                                vv, ss, pp, qq = _grid_layout(cnt, w, h) if cnt > 0 else (0.0, 0.0, 0, 0)
                                tot += vv
                                desc.append((w, h, cnt, pp, qq, ss))
                            if best is None or tot > best[0] + 1e-12:
                                best = (tot, a, desc)
                        return
                    # how many for this block
                    for cnt in range(0, left + 1):
                        acc.append(cnt)
                        rec(idx + 1, left - cnt, acc)
                        acc.pop()
                # for large rem, restrict the brute force to avoid blowup
                if rem <= 18:
                    rec(0, rem, [])
                else:
                    # greedy balanced distribution
                    acc = []
                    left = rem
                    for i in range(len(parts)):
                        cnt = left // (len(parts) - i)
                        # tune by area
                        acc.append(cnt)
                        left -= cnt
                    desc = []
                    tot = a
                    for (w, h), cnt in zip(parts, acc):
                        vv, ss, pp, qq = _grid_layout(cnt, w, h) if cnt > 0 else (0.0, 0.0, 0, 0)
                        tot += vv
                        desc.append((w, h, cnt, pp, qq, ss))
                    if best is None or tot > best[0] + 1e-12:
                        best = (tot, a, desc)
        return best

    cand_a = set()
    for den in (2, 3, 4, 5, 6, 7, 8, 10, 12, 16):
        for num in range(1, den):
            cand_a.add(num / den)
    for m in range(1, n):
        vm, sm, pm, qm = _grid_layout(m, 1.0, 1.0)
        if 0 < sm < 1:
            cand_a.add(sm)
            cand_a.add(sm * 2)
    cand_a = sorted(x for x in cand_a if 1e-6 < x < 1 - 1e-6)

    # local refinement of a around best candidate: golden-ish sampling
    def eval_corner_at(a):
        return corner3_eval(a, n - 1)

    best_corner = None
    for a in cand_a:
        res = eval_corner_at(a)
        if res is None:
            continue
        if best_corner is None or res[0] > best_corner[0] + 1e-12:
            best_corner = res
    # refine around best_corner's a
    if best_corner is not None:
        a0 = best_corner[1]
        for _ in range(3):
            lo = max(1e-6, a0 - 0.05)
            hi = min(1 - 1e-6, a0 + 0.05)
            for k in range(-10, 11):
                a = a0 + k * 0.005
                if not (1e-6 < a < 1 - 1e-6):
                    continue
                res = eval_corner_at(a)
                if res is not None and res[0] > best_corner[0] + 1e-12:
                    best_corner = res
            a0 = best_corner[1]

    if best_corner is not None:
        tot, a, desc = best_corner
        if tot > best_val + 1e-12:
            pl = [(a * 0.5, a * 0.5, 0.0, a)]
            # reconstruct blocks; right strip parts come first (offset x=a),
            # top strip parts next (offset y=a). We stored parts in order
            # rparts then tparts, so first len(rparts) are right strip.
            nright = 1 if len(desc) == 2 else 2
            idx = 0
            ycur = 0.0
            for bi in range(nright):
                w, h, cnt, pp, qq, ss = desc[idx]
                if cnt > 0:
                    sub = _emit_grid(w, h, cnt, pp, qq, ss, cnt)
                    for (cx, cy, ang, sss) in sub:
                        pl.append((cx + a, cy + ycur, ang, sss))
                ycur += h
                idx += 1
            # top strip
            xcur = 0.0
            for bi in range(idx, len(desc)):
                w, h, cnt, pp, qq, ss = desc[bi]
                if cnt > 0:
                    sub = _emit_grid(w, h, cnt, pp, qq, ss, cnt)
                    for (cx, cy, ang, sss) in sub:
                        pl.append((cx + xcur, cy + a, ang, sss))
                xcur += w
            while len(pl) < n:
                pl.append((0.5, 0.5, 0.0, 0.0))
            consider(tot, pl[:n])

    # --- Family D: 45-degree tilted band(s) ---
    sq2 = math.sqrt(2.0)
    for h in cand_a:
        side = h / sq2
        cnt_fit = int(1.0 / h + 1e-9)
        if cnt_fit <= 0:
            continue
        for band_cnt in (cnt_fit,):
            if band_cnt > n:
                continue
            rem = n - band_cnt
            v_rem, sr, pr, qr = _grid_layout(rem, 1.0, 1.0 - h) if rem > 0 else (0.0, 0.0, 0, 0)
            tot = band_cnt * side + v_rem
            if tot > best_val + 1e-12:
                pl = []
                for i in range(band_cnt):
                    cx = (i + 0.5) * h
                    cy = h * 0.5
                    pl.append((cx, cy, 0.125, side))
                if rem > 0:
                    sub = _emit_grid(1.0, 1.0 - h, rem, pr, qr, sr, rem)
                    for (cx, cy, ang, ss) in sub:
                        pl.append((cx, cy + h, ang, ss))
                while len(pl) < n:
                    pl.append((0.5, 0.5, 0.0, 0.0))
                consider(tot, pl[:n])

    if best_pl is None:
        v, s, p, q = _grid_layout(n, 1.0, 1.0)
        best_pl = _emit_grid(1.0, 1.0, n, p, q, s, n)

    result = []
    for (cx, cy, a, s) in best_pl[:n]:
        s = max(0.0, min(1.0, float(s)))
        cx = max(0.0, min(1.0, float(cx)))
        cy = max(0.0, min(1.0, float(cy)))
        result.append((cx, cy, 0.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END
