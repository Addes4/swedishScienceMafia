# EVOLVE-BLOCK-START
"""Multi-scale guillotine packing of squares into the unit square.

The construction recursively splits a rectangle into two sub-rectangles
(guillotine cuts) and, at each leaf, may instead place a uniform block of
equal squares.  A depth-limited search over the choice of cut, cut position
and block layout maximises the total sum of side lengths.
"""
import math


def _block_layout(rw, rh, k, angle):
    """Return (count, side, extra_data) for a uniform block of k squares
    packed axis-aligned inside a (rw, rh) rectangle, maximising side.

    The squares are placed in a p x q grid with p*q >= k and p,q the
    grid dimensions that give the largest side = min(rw/p, rh/q).
    """
    best = (0, 0.0, (1, 1))
    for p in range(1, k + 1):
        q = (k + p - 1) // p
        if p * q < k:
            continue
        side = min(rw / p, rh / q)
        if side > best[1] + 1e-15:
            best = (k, side, (p, q))
    return best


def _fill_rect(x0, y0, rw, rh, k, angle):
    """Place k axis-aligned squares of equal side in the rectangle,
    as a p x q grid.  Returns list of (cx, cy, angle, side)."""
    if k <= 0 or rw <= 1e-12 or rh <= 1e-12:
        return []
    _, side, (p, q) = _block_layout(rw, rh, k, angle)
    if side <= 1e-12:
        return [(0.5, 0.5, 0.0, 0.0)] * k
    out = []
    # centre the whole grid in the rectangle
    gx = p * side
    gy = q * side
    ox = x0 + (rw - gx) / 2.0
    oy = y0 + (rh - gy) / 2.0
    ca = math.cos(angle)
    sa = math.sin(angle)
    count = 0
    for i in range(p):
        for j in range(q):
            if count >= k:
                break
            lx = ox + (i + 0.5) * side
            ly = oy + (j + 0.5) * side
            # rotate about rectangle centre (kept small; here angle is 0)
            cx = lx
            cy = ly
            out.append((cx, cy, 0.0, side))
            count += 1
    return out


def _search(x0, y0, rw, rh, k, depth, memo):
    """Return (value, squares) for packing k squares into rectangle."""
    if k <= 0:
        return 0.0, []
    key = (round(x0, 9), round(y0, 9), round(rw, 9), round(rh, 9), k, depth)
    if key in memo:
        return memo[key]

    # Option A: uniform block filling the whole rectangle
    _, side, _g = _block_layout(rw, rh, k, 0.0)
    best_val = k * side
    best_sq = _fill_rect(x0, y0, rw, rh, k, 0.0)

    if depth <= 0 or k == 1:
        memo[key] = (best_val, best_sq)
        return best_val, best_sq

    # Option B: guillotine split (vertical or horizontal)
    # Try a set of candidate cut positions.
    for axis in (0, 1):
        length = rw if axis == 0 else rh
        if length <= 1e-9:
            continue
        # candidate fractions
        cands = set()
        for t in range(1, 8):
            cands.add(t / 8.0)
        # also add positions that make nice grid fractions
        for p in range(1, min(k, 6) + 1):
            cands.add(p / float(max(k, 1)))
        for frac in cands:
            if frac <= 1e-9 or frac >= 1.0 - 1e-9:
                continue
            for k1 in range(0, k + 1):
                k2 = k - k1
                if k1 == 0 and k2 == 0:
                    continue
                if axis == 0:
                    r1 = (x0, y0, rw * frac, rh)
                    r2 = (x0 + rw * frac, y0, rw * (1 - frac), rh)
                else:
                    r1 = (x0, y0, rw, rh * frac)
                    r2 = (x0, y0 + rh * frac, rw, rh * (1 - frac))
                v1, s1 = _search(r1[0], r1[1], r1[2], r1[3], k1, depth - 1, memo)
                v2, s2 = _search(r2[0], r2[1], r2[2], r2[3], k2, depth - 1, memo)
                if v1 + v2 > best_val + 1e-12:
                    best_val = v1 + v2
                    best_sq = s1 + s2
    memo[key] = (best_val, best_sq)
    return best_val, best_sq


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    # A good initial guess: try several depth levels, keep best.
    best_total = -1.0
    best_sq = None
    for depth in (2, 3):
        memo = {}
        val, sq = _search(0.0, 0.0, 1.0, 1.0, n, depth, memo)
        if val > best_total:
            best_total = val
            best_sq = sq
    if best_sq is None:
        # fallback simple grid
        k = math.isqrt(n)
        side = 1.0 / k
        best_sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        best_sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))

    # Sanitise output: clamp to [0,1], pad/truncate to n.
    out = []
    for (cx, cy, ang, sd) in best_sq:
        sd = max(0.0, min(1.0, sd))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = max(0.0, min(1.0, ang))
        out.append((cx, cy, ang, sd))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
