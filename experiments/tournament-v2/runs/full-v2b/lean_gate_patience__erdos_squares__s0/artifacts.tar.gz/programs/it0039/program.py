# EVOLVE-BLOCK-START
"""Multi-scale guillotine packing: recursively split the unit square into cells and
fill each cell with the largest uniform block of squares that fits, maximizing the
total sum of side lengths."""
import math


def _block_value(w, h, m):
    """Best total side sum placing exactly m equal axis-aligned squares in a w x h cell.

    If we use a p x q grid (p*q >= m, using m of them), side = min(w/p, h/q).
    We search p, q candidates. Returns (value, side, p, q).
    """
    if m <= 0:
        return (0.0, 1.0, 0, 0)
    best = (0.0, 0.0, 0, 0)
    # candidate p from 1..m; q = ceil(m/p)
    for p in range(1, m + 1):
        q = (m + p - 1) // p
        s = min(w / p, h / q)
        v = s * m
        if v > best[0]:
            best = (v, s, p, q)
    # also try q outer loop for symmetry (helps when h/w differs)
    for q in range(1, m + 1):
        p = (m + q - 1) // q
        s = min(w / p, h / q)
        v = s * m
        if v > best[0]:
            best = (v, s, p, q)
    return best


def _search(w, h, n, depth):
    """Return (value, placement_list) for packing n squares in w x h cell.
    placement_list entries are (cx, cy, angle, side) in cell-local coords [0,w]x[0,h].
    """
    if n <= 0:
        return (0.0, [])
    if depth <= 0 or n == 1:
        best = (0.0, None)
        for m in range(1, n + 1):
            v1, s1, p1, q1 = _block_value(w, h, m)
            rem = n - m
            # remaining squares get size 0 (points) -> value 0
            if v1 > best[0]:
                best = (v1, (m, p1, q1, s1))
        if best[1] is None:
            return (0.0, [])
        m, p, q, s = best[1]
        return _emit_block(w, h, m, p, q, s, n)

    # Try all guillotine splits: horizontal (along h) or vertical (along w)
    best_val = -1.0
    best_pl = None
    best_blocks = None
    for m in range(1, n + 1):
        v1, s1, p1, q1 = _block_value(w, h, m)
        rem = n - m
        cand = v1
        if cand > best_val:
            best_val = cand
            best_blocks = (m, p1, q1, s1, rem)

    # recursion: split cell into two and distribute
    for axis in (0, 1):
        span = w if axis == 0 else h
        for t in range(1, n):
            # fraction split candidate from block heuristics
            for frac in _split_fractions(w, h, t, n - t, axis):
                if axis == 0:
                    w1, w2 = frac * w, (1 - frac) * w
                    h1, h2 = h, h
                else:
                    w1, w2 = w, w
                    h1, h2 = frac * h, (1 - frac) * h
                if w1 <= 1e-12 or h1 <= 1e-12 or w2 <= 1e-12 or h2 <= 1e-12:
                    continue
                v1, pl1 = _search(w1, h1, t, depth - 1)
                v2, pl2 = _search(w2, h2, n - t, depth - 1)
                tv = v1 + v2
                if tv > best_val:
                    best_val = tv
                    if axis == 0:
                        off2 = (frac * w, 0.0)
                    else:
                        off2 = (0.0, frac * h)
                    best_pl = (pl1, pl2, off2)
    if best_pl is not None:
        pl1, pl2, off2 = best_pl
        merged = list(pl1)
        for (cx, cy, a, s) in pl2:
            merged.append((cx + off2[0], cy + off2[1], a, s))
        # pad with zeros if needed
        while len(merged) < n:
            merged.append((w * 0.5, h * 0.5, 0.0, 0.0))
        return (best_val, merged[:n])

    # fallback: single block
    if best_blocks is None:
        return (0.0, [(w * 0.5, h * 0.5, 0.0, 0.0)] * n)
    m, p, q, s, rem = best_blocks
    return _emit_block(w, h, m, p, q, s, n)


def _split_fractions(w, h, t, r, axis):
    """Generate candidate split fractions along an axis."""
    span = w if axis == 0 else h
    fracs = set()
    for m in (t, r):
        if m <= 0:
            continue
        v, s, p, q = _block_value(w if axis == 0 else w, h if axis == 0 else h, m)
        if s > 0:
            if axis == 0:
                # need width for p columns
                need = p * s
            else:
                need = q * s
            if 0 < need < span:
                fracs.add(need / span)
    # include useful simple fractions
    for den in (2, 3, 4, 5, 6, 7, 8):
        for num in range(1, den):
            fracs.add(num / den)
    return sorted(f for f in fracs if 0 < f < 1)


def _emit_block(w, h, m, p, q, s, n):
    """Place m squares of side s in p columns x q rows inside w x h cell,
    centered. Pad to n with zero-size squares."""
    out = []
    # center the p*s x q*s block region
    bw = p * s
    bh = q * s
    ox = (w - bw) * 0.5
    oy = (h - bh) * 0.5
    count = 0
    for j in range(q):
        for i in range(p):
            if count >= m:
                break
            cx = ox + (i + 0.5) * s
            cy = oy + (j + 0.5) * s
            out.append((cx, cy, 0.0, s))
            count += 1
        if count >= m:
            break
    while len(out) < n:
        out.append((w * 0.5, h * 0.5, 0.0, 0.0))
    return (s * m, out[:n])


def solve(n):
    """Return n squares inside the unit square maximizing sum of sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_val = -1.0
    best_pl = None

    # Try several recursion depths and rectangle aspect handling.
    # We search the full square with a guillotine recursion.
    for depth in (2, 3):
        v, pl = _search(1.0, 1.0, n, depth)
        if v > best_val:
            best_val = v
            best_pl = pl

    # Also consider a simple uniform p x q block directly as a candidate.
    v, s, p, q = _block_value(1.0, 1.0, n)
    if v > best_val:
        val, pl = _emit_block(1.0, 1.0, n, p, q, s, n)
        best_val = val
        best_pl = pl

    if best_pl is None:
        k = math.isqrt(n)
        s = 1.0 / k
        pl = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
              for i in range(k) for j in range(k)]
        pl += [(0.5, 0.5, 0.0, 0.0)] * (n - len(pl))
        best_pl = pl[:n]

    # Clamp and sanitize
    result = []
    for (cx, cy, a, s) in best_pl[:n]:
        s = max(0.0, min(1.0, s))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        result.append((cx, cy, 0.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END
