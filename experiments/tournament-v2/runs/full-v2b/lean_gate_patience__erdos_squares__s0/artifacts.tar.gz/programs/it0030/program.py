"""Band-partition constructor (axis-aligned + 45-degree rows) with numpy SAT polish."""

import math

import numpy as np


def _best_block(n, w, h):
    if n <= 0:
        return 0.0, 0, 0
    best = (0.0, 1, 1)
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        s = min(w / cols, h / rows)
        if s > best[0]:
            best = (s, cols, rows)
    return best


# -------- fast numpy SAT validator --------

def _corners_np(c, a, s):
    """c: (n,2) centres, a: (n,) angles (turns), s: (n,) sides -> (n,4,2)."""
    t = a * 2.0 * math.pi
    co = np.cos(t)[:, None]
    si = np.sin(t)[:, None]
    h = (s / 2.0)[:, None]
    # local corners (+-h,+-h) rotated
    lx = np.array([[-1.0, -1.0], [1.0, -1.0], [1.0, 1.0], [-1.0, 1.0]])  # (4,2)
    px = lx[None, :, 0] * h
    py = lx[None, :, 1] * h
    x = c[:, 0:1] + co * px - si * py
    y = c[:, 1:2] + si * px + co * py
    return np.stack([x, y], axis=2)


def _ok_np(c, a, s):
    n = len(s)
    if n == 0:
        return True
    if np.any(s < -1e-9):
        return False
    t = a * 2.0 * math.pi
    ca = np.abs(np.cos(t))
    sa = np.abs(np.sin(t))
    rx = (ca + sa) * s / 2.0
    ry = (sa + ca) * s / 2.0
    if np.any(c[:, 0] - rx < -1e-7) or np.any(c[:, 0] + rx > 1 + 1e-7):
        return False
    if np.any(c[:, 1] - ry < -1e-7) or np.any(c[:, 1] + ry > 1 + 1e-7):
        return False
    P = _corners_np(c, a, s)
    for i in range(n):
        if s[i] <= 1e-12:
            continue
        for j in range(i + 1, n):
            if s[j] <= 1e-12:
                continue
            ax = P[i, :, 0]
            ay = P[i, :, 1]
            bx = P[j, :, 0]
            by = P[j, :, 1]
            d1 = P[i, 1] - P[i, 0]
            d2 = P[i, 2] - P[i, 1]
            d3 = P[j, 1] - P[j, 0]
            d4 = P[j, 2] - P[j, 1]
            sep = False
            for dx, dy in ((d1[0], d1[1]), (d2[0], d2[1]),
                           (d3[0], d3[1]), (d4[0], d4[1])):
                aa = ax * dx + ay * dy
                bb = bx * dx + by * dy
                if aa.max() <= bb.min() + 1e-9 or bb.max() <= aa.min() + 1e-9:
                    sep = True
                    break
            if not sep:
                return False
    return True


def _score(layout):
    return sum(s[3] for s in layout)


def _to_arrays(squares):
    n = len(squares)
    c = np.array([[squares[i][0], squares[i][1]] for i in range(n)], dtype=float)
    a = np.array([squares[i][2] for i in range(n)], dtype=float)
    s = np.array([squares[i][3] for i in range(n)], dtype=float)
    return c, a, s


# -------- band construction --------

def _grid_in_rect(x, y, w, h, cnt):
    side, cols, rows = _best_block(cnt, w, h)
    out = []
    if side <= 0:
        for _ in range(cnt):
            out.append((x + w / 2, y + h / 2, 0.0, 0.0))
        return out
    gw = cols * side
    gh = rows * side
    ox = x + (w - gw) / 2
    oy = y + (h - gh) / 2
    placed = 0
    for i in range(cols):
        for j in range(rows):
            placed += 1
            out.append((ox + (i + 0.5) * side, oy + (j + 0.5) * side, 0.0, side))
    while placed < cnt:
        out.append((x + w / 2, y + h / 2, 0.0, 0.0))
        placed += 1
    return out


def _band_layout(n, top_count, top_angle):
    """Top band has top_count squares of angle top_angle; bottom band axis-aligned."""
    if top_count <= 0 or top_count >= n:
        return None
    bottom_count = n - top_count
    # top row: squares of side s in a band of height?  We solve two-band split.
    # Try each band height h in fine steps and compute feasibility.
    best = None
    best_val = -1.0
    for steps in range(1, 60):
        h = steps / 60.0
        # top band: fit top_count tilted squares in [0,1] x [1-h,1]
        # width available per square = 1/top_count; tilt causes extent
        ca = abs(math.cos(top_angle * 2 * math.pi))
        sa = abs(math.sin(top_angle * 2 * math.pi))
        # horizontal extent of a turned square of side s = (ca+sa)*s
        s_top = min((1.0 / top_count) / (ca + sa), h / (ca + sa))
        if s_top <= 0:
            continue
        # bottom band: fit bottom_count in [0,1] x [0,1-h]
        s_bot, cols, rows = _best_block(bottom_count, 1.0, 1.0 - h)
        if s_bot <= 0:
            continue
        val = top_count * s_top + bottom_count * s_bot
        if val > best_val:
            best_val = val
            best = (h, s_top, s_bot, cols, rows, bottom_count)
    if best is None:
        return None
    h, s_top, s_bot, cols, rows, bottom_count = best
    out = []
    for i in range(top_count):
        cx = (i + 0.5) / top_count
        cy = 1.0 - h / 2.0
        out.append((cx, cy, top_angle, s_top))
    # bottom grid
    gw = cols * s_bot
    gh = rows * s_bot
    ox = (1.0 - gw) / 2.0
    oy = (1.0 - h - gh) / 2.0 if (1.0 - h) > gh else 0.0
    placed = 0
    for i in range(cols):
        for j in range(rows):
            if placed >= bottom_count:
                break
            placed += 1
            out.append((ox + (i + 0.5) * s_bot, oy + (j + 0.5) * s_bot, 0.0, s_bot))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _col_layout(n, left_count, left_angle):
    """Left column tilted, right column axis-aligned."""
    if left_count <= 0 or left_count >= n:
        return None
    right_count = n - left_count
    best = None
    best_val = -1.0
    for steps in range(1, 60):
        w = steps / 60.0
        ca = abs(math.cos(left_angle * 2 * math.pi))
        sa = abs(math.sin(left_angle * 2 * math.pi))
        s_left = min((1.0 / left_count) / (ca + sa), w / (ca + sa))
        if s_left <= 0:
            continue
        s_right, cols, rows = _best_block(right_count, 1.0 - w, 1.0)
        if s_right <= 0:
            continue
        val = left_count * s_left + right_count * s_right
        if val > best_val:
            best_val = val
            best = (w, s_left, s_right, cols, rows, right_count)
    if best is None:
        return None
    w, s_left, s_right, cols, rows, right_count = best
    out = []
    for i in range(left_count):
        cy = (i + 0.5) / left_count
        cx = w / 2.0
        out.append((cx, cy, left_angle, s_left))
    gw = cols * s_right
    gh = rows * s_right
    ox = w + (1.0 - w - gw) / 2.0
    oy = (1.0 - gh) / 2.0
    placed = 0
    for i in range(cols):
        for j in range(rows):
            if placed >= right_count:
                break
            placed += 1
            out.append((ox + (i + 0.5) * s_right, oy + (j + 0.5) * s_right, 0.0, s_right))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _simple_grid(n):
    side, cols, rows = _best_block(n, 1.0, 1.0)
    out = []
    gw = cols * side
    gh = rows * side
    ox = (1.0 - gw) / 2.0
    oy = (1.0 - gh) / 2.0
    placed = 0
    for i in range(cols):
        for j in range(rows):
            if placed >= n:
                break
            placed += 1
            out.append((ox + (i + 0.5) * side, oy + (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


# -------- numpy CD polish --------

def _polish(squares, rounds=60):
    c, a, s = _to_arrays(squares)
    n = len(s)
    if not _ok_np(c, a, s):
        return squares
    for _ in range(rounds):
        improved = False
        for i in range(n):
            # try grow
            for ds in (0.01, 0.004, 0.001):
                ns = s.copy()
                ns[i] += ds
                if ns[i] > 1:
                    continue
                if _ok_np(c, a, ns):
                    s = ns
                    improved = True
                    break
            # try move centre
            cx, cy = c[i]
            best_move = None
            for ddx, ddy in ((0.008, 0), (-0.008, 0), (0, 0.008), (0, -0.008),
                             (0.008, 0.008), (-0.008, 0.008),
                             (0.008, -0.008), (-0.008, -0.008)):
                nc = c.copy()
                nc[i, 0] = min(max(cx + ddx, 0.0), 1.0)
                nc[i, 1] = min(max(cy + ddy, 0.0), 1.0)
                if _ok_np(nc, a, s):
                    best_move = nc
                    break
            if best_move is not None:
                c = best_move
                improved = True
            # try nudge angle
            old = a[i]
            for da in (0.01, -0.01, 0.005, -0.005):
                na = a.copy()
                na[i] = (old + da) % 1.0
                if _ok_np(c, na, s):
                    a = na
                    improved = True
                    break
        if not improved:
            break
    return [(float(c[i, 0]), float(c[i, 1]), float(a[i] % 1.0), float(s[i]))
            for i in range(n)]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    candidates = [_simple_grid(n)]
    # 2-band partitions: tilted top/left band
    for angle in (0.125, 0.0):
        for k in range(1, n):
            L = _band_layout(n, k, angle)
            if L:
                candidates.append(L)
            L = _col_layout(n, k, angle)
            if L:
                candidates.append(L)

    best = None
    best_val = -1.0
    for cand in candidates:
        c, a, s = _to_arrays(cand)
        if not _ok_np(c, a, s):
            # try tiny shrink
            cand2 = [(cx, cy, ang, sd * 0.98) for (cx, cy, ang, sd) in cand]
            c, a, s = _to_arrays(cand2)
        if not _ok_np(c, a, s):
            continue
        pol = _polish(cand, rounds=50)
        v = _score(pol)
        if v > best_val:
            best_val = v
            best = pol

    if best is None:
        best = _simple_grid(n)
        best = [(cx, cy, ang, sd) for (cx, cy, ang, sd) in best]

    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
