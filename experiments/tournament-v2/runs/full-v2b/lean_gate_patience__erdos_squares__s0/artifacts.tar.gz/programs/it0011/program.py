# EVOLVE-BLOCK-START
"""Structured layout search plus a separating-axis local expansion."""
import math
import random


def _vertices(cx, cy, ang, s):
    c, sn = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _overlap(A, B):
    for poly in (A, B):
        n = len(poly)
        for k in range(n):
            x1, y1 = poly[k]
            x2, y2 = poly[(k + 1) % n]
            ax, ay = -(y2 - y1), (x2 - x1)
            projA = [ax * p[0] + ay * p[1] for p in A]
            projB = [ax * p[0] + ay * p[1] for p in B]
            if max(projA) < min(projB) + 1e-9 or max(projB) < min(projA) + 1e-9:
                return False
    return True


def _feasible(sqs):
    boxes = []
    for (cx, cy, ang, s) in sqs:
        if s <= 0:
            continue
        if cx < -1e-9 or cx > 1 + 1e-9 or cy < -1e-9 or cy > 1 + 1e-9:
            return False
        v = _vertices(cx, cy, ang, s)
        xs = [p[0] for p in v]
        ys = [p[1] for p in v]
        if min(xs) < -1e-9 or max(xs) > 1 + 1e-9 or min(ys) < -1e-9 or max(ys) > 1 + 1e-9:
            return False
        boxes.append(v)
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            if _overlap(boxes[i], boxes[j]):
                return False
    return True


def _grid(k):
    res = []
    if k <= 0:
        return res
    s = 1.0 / k
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    return res


def _greedy_split(x, y, w, h, remaining):
    rects = [(x, y, w, h)]
    out = []
    for _ in range(remaining):
        best_i = -1
        best_s = 0.0
        for i, (rx, ry, rw, rh) in enumerate(rects):
            s = min(rw, rh)
            if s > best_s + 1e-12:
                best_s = s
                best_i = i
        if best_i < 0 or best_s <= 1e-12:
            break
        rx, ry, rw, rh = rects.pop(best_i)
        s = best_s
        out.append((rx + s * 0.5, ry + s * 0.5, 0.0, s))
        if rw - s > rh - s:
            if rw - s > 1e-12:
                rects.append((rx + s, ry, rw - s, rh))
            if rh - s > 1e-12:
                rects.append((rx, ry + s, s, rh - s))
        else:
            if rh - s > 1e-12:
                rects.append((rx, ry + s, rw, rh - s))
            if rw - s > 1e-12:
                rects.append((rx + s, ry, rw - s, s))
    return out


def _big_square_layout(n, side, corner):
    if n < 1:
        return []
    s = side
    if s <= 0 or s > 1:
        return []
    big_cx = big_cy = s * 0.5
    if corner == 'tl':
        big_cx = 1 - s * 0.5
    elif corner == 'br':
        big_cy = 1 - s * 0.5
    elif corner == 'tr':
        big_cx = 1 - s * 0.5
        big_cy = 1 - s * 0.5
    out = [(big_cx, big_cy, 0.0, s)]
    rem = n - 1
    if rem <= 0:
        return out
    best = None
    best_sum = -1
    for split_right_first in (True, False):
        if split_right_first:
            strips = [(s, 0.0, 1.0 - s, 1.0), (0.0, s, s, 1.0 - s)]
        else:
            strips = [(0.0, s, 1.0, 1.0 - s), (s, 0.0, 1.0 - s, s)]
        areas = [w * h for (_, _, w, h) in strips]
        tot_area = sum(areas)
        if tot_area <= 1e-12:
            continue
        counts = [int(round(rem * a / tot_area)) for a in areas]
        counts[0] += rem - sum(counts)
        cand = list(out)
        for (sx, sy, sw, sh), c in zip(strips, counts):
            cand += _greedy_split(sx, sy, sw, sh, c)
        if len(cand) >= n:
            cand = cand[:n]
            tot = sum(cc[3] for cc in cand)
            if tot > best_sum:
                best_sum = tot
                best = cand
    return best if best is not None else out


def _make_layout(n, k):
    base = _grid(k)
    used = len(base)
    if used >= n:
        return base[:n]
    rem = n - used
    best = None
    best_sum = -1
    for frac in (0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 0.98, 1.0):
        s = frac / k
        strip_h = 1.0 - k * s
        if strip_h <= 1e-9:
            continue
        cand = []
        for i in range(k):
            for j in range(k):
                cand.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        extra = _greedy_split(0.0, k * s, 1.0, strip_h, rem)
        cand += extra
        if len(cand) < n:
            continue
        tot = sum(c[3] for c in cand)
        if tot > best_sum:
            best_sum = tot
            best = cand
    if best is None:
        best = base
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]


def _rect_split_layout(n, rng, depth=0):
    def rec(x, y, w, h, pieces):
        if pieces <= 1:
            s = min(w, h)
            return [(x + s * 0.5, y + s * 0.5, 0.0, s)]
        if w <= 0 or h <= 0:
            return [(x + w * 0.5, y + h * 0.5, 0.0, 0.0)] * pieces
        pieces_a = rng.randint(1, pieces - 1)
        pieces_b = pieces - pieces_a
        r = pieces_a / pieces
        r = min(max(r, 0.15), 0.85)
        if w >= h:
            wa = w * r
            return rec(x, y, wa, h, pieces_a) + rec(x + wa, y, w - wa, h, pieces_b)
        else:
            ha = h * r
            return rec(x, y, w, ha, pieces_a) + rec(x, y + ha, w, h - ha, pieces_b)
    return rec(0.0, 0.0, 1.0, 1.0, n)


def _push_apart(sqs, passes=30):
    """Slide overlapping squares apart and clamp inside the unit square."""
    n = len(sqs)
    for _ in range(passes):
        moved = False
        for i in range(n):
            ci = sqs[i]
            if ci[3] <= 0:
                continue
            vi = _vertices(ci[0], ci[1], ci[2], ci[3])
            for j in range(i + 1, n):
                cj = sqs[j]
                if cj[3] <= 0:
                    continue
                vj = _vertices(cj[0], cj[1], cj[2], cj[3])
                if _overlap(vi, vj):
                    # push centers apart along center difference
                    dx = ci[0] - cj[0]
                    dy = ci[1] - cj[1]
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        dx, dy, d = 1.0, 0.0, 1.0
                    step = 0.02
                    nx, ny = dx / d, dy / d
                    sqs[i] = [ci[0] + nx * step, ci[1] + ny * step, ci[2], ci[3]]
                    sqs[j] = [cj[0] - nx * step, cj[1] - ny * step, cj[2], cj[3]]
                    ci = sqs[i]
                    cj = sqs[j]
                    vi = _vertices(ci[0], ci[1], ci[2], ci[3])
                    moved = True
        # clamp
        for i in range(n):
            cx, cy, a, s = sqs[i]
            if s <= 0:
                continue
            v = _vertices(cx, cy, a, s)
            xs = [p[0] for p in v]
            ys = [p[1] for p in v]
            mx = 0.0
            my = 0.0
            if min(xs) < 0:
                mx = -min(xs)
            if max(xs) > 1:
                mx = min(mx, 1 - max(xs))
            if min(ys) < 0:
                my = -min(ys)
            if max(ys) > 1:
                my = min(my, 1 - max(ys))
            sqs[i] = [cx + mx, cy + my, a, s]
        if not moved:
            break
    return sqs


def _try_grow(sqs, i, ds):
    cx, cy, a, s = sqs[i]
    cand = [cx, cy, a, s + ds]
    v = _vertices(cand[0], cand[1], cand[2], cand[3])
    xs = [p[0] for p in v]
    ys = [p[1] for p in v]
    if min(xs) < -1e-9 or max(xs) > 1 + 1e-9 or min(ys) < -1e-9 or max(ys) > 1 + 1e-9:
        return False
    vi = v
    for j in range(len(sqs)):
        if j == i:
            continue
        cj = sqs[j]
        if cj[3] <= 0:
            continue
        vj = _vertices(cj[0], cj[1], cj[2], cj[3])
        if _overlap(vi, vj):
            return False
    sqs[i] = cand
    return True


def _expand(sqs, iters=200):
    sqs = [list(s) for s in sqs]
    n = len(sqs)
    order = list(range(n))
    for _ in range(iters):
        improved = False
        random.shuffle(order)
        for i in order:
            cx, cy, a, s = sqs[i]
            for ds in (0.02, 0.01, 0.005, 0.002, 0.001, 0.0005):
                if _try_grow(sqs, i, ds):
                    improved = True
            # try small translations to make room
            for dx, dy in ((0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01),
                           (0.005, 0.005), (-0.005, 0.005),
                           (0.005, -0.005), (-0.005, -0.005)):
                cx, cy, a, s = sqs[i]
                cand = [cx + dx, cy + dy, a, s]
                v = _vertices(cand[0], cand[1], cand[2], cand[3])
                xs = [p[0] for p in v]
                ys = [p[1] for p in v]
                if min(xs) < -1e-9 or max(xs) > 1 + 1e-9 or min(ys) < -1e-9 or max(ys) > 1 + 1e-9:
                    continue
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    cj = sqs[j]
                    if cj[3] <= 0:
                        continue
                    vj = _vertices(cj[0], cj[1], cj[2], cj[3])
                    if _overlap(v, vj):
                        ok = False
                        break
                if ok:
                    sqs[i] = cand
                    improved = True
        if not improved:
            break
    return [(c[0], c[1], c[2], c[3]) for c in sqs]


def _polish(cand, n):
    """Push-apart then expand then push-apart again."""
    sqs = [list(s) for s in cand]
    sqs = _push_apart(sqs, passes=40)
    sqs = _expand(sqs, iters=150)
    sqs = _push_apart(sqs, passes=20)
    sqs = _expand(sqs, iters=150)
    r = _best_sum(sqs, n)
    if r is not None:
        return r
    return None


def _best_sum(cand, n):
    if len(cand) < n:
        cand = cand + [(0.5, 0.5, 0.0, 0.0)] * (n - len(cand))
    cand = cand[:n]
    if not _feasible(cand):
        return None
    return sum(c[3] for c in cand), cand


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    k0 = max(1, math.isqrt(n))
    candidates = []

    for k in range(max(1, k0 - 2), k0 + 3):
        if k <= 0:
            continue
        g = _grid(k)
        if len(g) >= n:
            candidates.append(g[:n])
        lay = _make_layout(n, k)
        if len(lay) == n:
            candidates.append(lay)

    for xi in range(4, 20):
        side = xi * 0.05
        for corner in ('bl', 'br', 'tl', 'tr'):
            cand = _big_square_layout(n, side, corner)
            if len(cand) >= n:
                candidates.append(cand[:n])

    for _ in range(120):
        cand = _rect_split_layout(n, rng)
        if len(cand) == n:
            candidates.append(cand)

    best = None
    best_score = -1
    pool = []
    seen = set()
    for cand in candidates:
        r = _best_sum(cand, n)
        if r is None:
            continue
        sc, c2 = r
        key = tuple(round(x, 5) for sq in c2 for x in sq)
        if key in seen:
            continue
        seen.add(key)
        pool.append((sc, c2))
        if sc > best_score:
            best_score = sc
            best = c2

    if best is None:
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    pool.sort(key=lambda t: -t[0])
    pool = pool[:12]

    results = list(pool)
    for sc, c2 in pool:
        try:
            r = _polish(c2, n)
            if r is not None:
                results.append(r)
        except Exception:
            pass

    results.sort(key=lambda t: -t[0])
    best = results[0][1]
    if not _feasible(best):
        k = max(1, math.isqrt(n))
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    return best[:n]
# EVOLVE-BLOCK-END
