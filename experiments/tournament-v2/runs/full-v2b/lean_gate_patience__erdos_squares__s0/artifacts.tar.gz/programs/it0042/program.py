# EVOLVE-BLOCK-START
"""Fast bounded constructor: try several analytic layout families and pick the
one with the largest valid total side sum.  Runs in O(n^2) time so it is safe
for all n within the time limit."""
import math


def _grid_block(w, h, m):
    """Best sum of sides placing exactly m equal axis-aligned squares in a w x h cell.
    Returns (value, side, cols, rows)."""
    if m <= 0:
        return (0.0, 0.0, 0, 0)
    best = (0.0, 0.0, 0, 0)
    for p in range(1, m + 1):
        q = (m + p - 1) // p
        s = min(w / p, h / q)
        v = s * m
        if v > best[0]:
            best = (v, s, p, q)
    return best


def _emit_grid(w, h, m, p, q, s, n):
    """Place m squares of side s in a p x q grid centered, pad with zeros."""
    out = []
    bw, bh = p * s, q * s
    ox, oy = (w - bw) * 0.5, (h - bh) * 0.5
    cnt = 0
    for j in range(q):
        for i in range(p):
            if cnt >= m:
                break
            out.append((ox + (i + 0.5) * s, oy + (j + 0.5) * s, 0.0, s))
            cnt += 1
        if cnt >= m:
            break
    while len(out) < n:
        out.append((w * 0.5, h * 0.5, 0.0, 0.0))
    return (s * m, out[:n])


def _uniform(n):
    """Plain p x q uniform grid of all n squares."""
    v, s, p, q = _grid_block(1.0, 1.0, n)
    return _emit_grid(1.0, 1.0, n, p, q, s, n)


def _corner_plus_grid(n):
    """A big axis-aligned square in one corner; the L-shaped remainder filled
    by a uniform grid of the other squares sized to fit the leftover region."""
    best = (-1.0, None)
    for m in range(1, n + 1):
        # big square side a takes corner; remaining squares go into the
        # L-shape: top strip (1 x (1-a)) and right strip (a x (1-a)).
        # Try a range of a values.
        for a in [i / 40.0 for i in range(1, 40)]:
            r = n - m
            rem = 1.0 - a
            # top strip: (1 x rem), right strip: (a x rem)
            v1, s1, p1, q1 = _grid_block(1.0, rem, r)
            # value using top strip alone
            cand = a * m + v1
            if cand > best[0]:
                pl = _layout_corner(a, m, 1.0, rem, r, p1, q1, s1)
                best = (cand, pl)
            v2, s2, p2, q2 = _grid_block(a, rem, r)
            cand = a * m + v2
            if cand > best[0]:
                pl = _layout_corner(a, m, a, rem, r, p2, q2, s2)
                best = (cand, pl)
    if best[1] is None:
        return _uniform(n)
    return best


def _layout_corner(a, m, rw, rh, r, p, q, s):
    """Big square side a at bottom-left; other r squares in rw x rh region."""
    out = [(a * 0.5, a * 0.5, 0.0, a)]
    # region for the rest: place at bottom-right if region width a else top
    if abs(rw - a) < 1e-9:
        ox, oy = 1.0 - rw, 0.0
    else:
        ox, oy = 0.0, 1.0 - rh
    bw, bh = p * s, q * s
    gx = ox + (rw - bw) * 0.5
    gy = oy + (rh - bh) * 0.5
    cnt = 0
    for j in range(q):
        for i in range(p):
            if cnt >= r:
                break
            out.append((gx + (i + 0.5) * s, gy + (j + 0.5) * s, 0.0, s))
            cnt += 1
        if cnt >= r:
            break
    while len(out) < m + r:
        out.append((0.5, 0.5, 0.0, 0.0))
    return (a * m + s * r, out)


def _split_two_blocks(n):
    """Split unit square by a vertical (or horizontal) guillotine cut into two
    rectangles, each filled by a uniform equal-square grid."""
    best = (-1.0, None)
    for axis in (0, 1):
        for t in range(1, n):
            r = n - t
            for k in range(1, 21):
                frac = k / 21.0
                if axis == 0:
                    w1, h1 = frac, 1.0
                    w2, h2 = 1.0 - frac, 1.0
                else:
                    w1, h1 = 1.0, frac
                    w2, h2 = 1.0, 1.0 - frac
                v1, s1, p1, q1 = _grid_block(w1, h1, t)
                v2, s2, p2, q2 = _grid_block(w2, h2, r)
                tv = v1 + v2
                if tv > best[0]:
                    pl = []
                    ox1, oy1 = 0.0, 0.0
                    bw, bh = p1 * s1, q1 * s1
                    gx = ox1 + (w1 - bw) * 0.5
                    gy = oy1 + (h1 - bh) * 0.5
                    c = 0
                    for j in range(q1):
                        for i in range(p1):
                            if c >= t:
                                break
                            pl.append((gx + (i + 0.5) * s1, gy + (j + 0.5) * s1, 0.0, s1))
                            c += 1
                        if c >= t:
                            break
                    if axis == 0:
                        ox2, oy2 = frac, 0.0
                    else:
                        ox2, oy2 = 0.0, frac
                    bw, bh = p2 * s2, q2 * s2
                    gx = ox2 + (w2 - bw) * 0.5
                    gy = oy2 + (h2 - bh) * 0.5
                    c = 0
                    for j in range(q2):
                        for i in range(p2):
                            if c >= r:
                                break
                            pl.append((gx + (i + 0.5) * s2, gy + (j + 0.5) * s2, 0.0, s2))
                            c += 1
                        if c >= r:
                            break
                    while len(pl) < n:
                        pl.append((0.5, 0.5, 0.0, 0.0))
                    best = (tv, pl)
    if best[1] is None:
        return _uniform(n)
    return best


def _tilted_band(n):
    """A grid of 45-degree tilted squares in one band plus an axis grid elsewhere.
    Tilted squares with side s have bounding box s*sqrt(2); tk x tl such squares
    tile a rectangle of size tk*s*sqrt2 x tl*s*sqrt2."""
    best = (-1.0, None)
    sq2 = math.sqrt(2.0)
    for tk in range(1, n + 1):
        for tl in range(1, n + 1):
            m = tk * tl
            if m > n:
                continue
            r = n - m
            # tilted band along the bottom with height hb = tl*s*sq2, width = tk*s*sq2
            # choose s so band width fills the unit square: tk*s*sq2 = 1 -> s = 1/(tk*sq2)
            s = 1.0 / (tk * sq2)
            hb = tl * s * sq2
            if hb > 1.0:
                continue
            if r > 0:
                v2, s2, p2, q2 = _grid_block(1.0, 1.0 - hb, r)
            else:
                v2 = 0.0
            tv = m * s + v2
            if tv > best[0]:
                pl = []
                # tilted band at top
                oy = 1.0 - hb
                for j in range(tl):
                    for i in range(tk):
                        cx = (i + 0.5) * s * sq2
                        cy = oy + (j + 0.5) * s * sq2
                        pl.append((cx, cy, 0.125, s))
                if r > 0:
                    bw, bh = p2 * s2, q2 * s2
                    gx = (1.0 - bw) * 0.5
                    gy = ((1.0 - hb) - bh) * 0.5
                    c = 0
                    for j in range(q2):
                        for i in range(p2):
                            if c >= r:
                                break
                            pl.append((gx + (i + 0.5) * s2, gy + (j + 0.5) * s2, 0.0, s2))
                            c += 1
                        if c >= r:
                            break
                while len(pl) < n:
                    pl.append((0.5, 0.5, 0.0, 0.0))
                best = (tv, pl)
    if best[1] is None:
        return _uniform(n)
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    candidates = [_uniform(n), _split_two_blocks(n), _corner_plus_grid(n)]
    if n <= 60:
        candidates.append(_tilted_band(n))

    best = max(candidates, key=lambda c: c[0])
    pl = best[1]
    result = []
    for (cx, cy, a, s) in pl[:n]:
        result.append((max(0.0, min(1.0, cx)),
                       max(0.0, min(1.0, cy)),
                       0.0,
                       max(0.0, min(1.0, s))))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END
