# EVOLVE-BLOCK-START
"""Sum of side lengths maximization via analytic layout families.

Key facts:
 - Placing n equal axis-aligned squares in the unit square: best is to choose
   p columns x q rows with p*q >= n, side = min(1/p, 1/q); use n of them.
 - Mixing sizes: put a big square in a corner and fill the remaining L-shape
   with a grid of smaller squares.
 - Rotated (45 deg) squares can fill a band of height h with side s = h/sqrt(2)
   and width occupation s*sqrt(2)=h.
We evaluate a curated set of such families and return the best.
"""
import math


def _grid_layout(n_cells, w, h):
    """Place n_cells equal axis-aligned squares in w x h region.
    Returns (value, side, p, q)."""
    if n_cells <= 0:
        return (0.0, 0.0, 0, 0)
    best = (0.0, 0.0, 0, 0)
    for p in range(1, n_cells + 1):
        q = (n_cells + p - 1) // p
        s = min(w / p, h / q)
        v = s * n_cells
        if v > best[0] + 1e-15:
            best = (v, s, p, q)
    return best


def _emit_grid(w, h, n_cells, p, q, s, n_total):
    out = []
    bw, bh = p * s, q * s
    ox, oy = (w - bw) * 0.5, (h - bh) * 0.5
    cnt = 0
    for j in range(q):
        for i in range(p):
            if cnt >= n_cells:
                break
            out.append((ox + (i + 0.5) * s, oy + (j + 0.5) * s, 0.0, s))
            cnt += 1
        if cnt >= n_cells:
            break
    while len(out) < n_total:
        out.append((w * 0.5, h * 0.5, 0.0, 0.0))
    return out[:n_total]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_val = -1.0
    best_pl = None

    def consider(v, pl):
        nonlocal best_val, best_pl
        if v > best_val + 1e-12:
            best_val = v
            best_pl = pl

    # --- Family A: uniform p x q grid over the whole unit square ---
    v, s, p, q = _grid_layout(n, 1.0, 1.0)
    consider(v, _emit_grid(1.0, 1.0, n, p, q, s, n))

    # --- Family B: split into two rectangles (vertical or horizontal),
    # each filled with an equal grid; search split fraction and counts. ---
    for axis in (0, 1):
        for t in range(1, n):
            r = n - t
            # Candidate split fractions from natural needs plus simple fractions
            fr = set()
            for den in (2, 3, 4, 5, 6, 7, 8, 10):
                for num in range(1, den):
                    fr.add(num / den)
            # also fractions from grid aspect
            for m in (t, r):
                vm, sm, pm, qm = _grid_layout(m, 1.0, 1.0)
                if sm > 0:
                    need = (pm * sm) if axis == 0 else (qm * sm)
                    if 0 < need < 1.0:
                        fr.add(need)
                        fr.add(1.0 - need)
            for frac in fr:
                if frac <= 1e-9 or frac >= 1 - 1e-9:
                    continue
                if axis == 0:
                    w1, h1 = frac, 1.0
                    w2, h2 = 1.0 - frac, 1.0
                else:
                    w1, h1 = 1.0, frac
                    w2, h2 = 1.0, 1.0 - frac
                v1, s1, p1, q1 = _grid_layout(t, w1, h1)
                v2, s2, p2, q2 = _grid_layout(r, w2, h2)
                tv = v1 + v2
                if tv > best_val + 1e-12:
                    pl1 = _emit_grid(w1, h1, t, p1, q1, s1, t)
                    pl2 = _emit_grid(w2, h2, r, p2, q2, s2, r)
                    if axis == 0:
                        off2 = (frac, 0.0)
                    else:
                        off2 = (0.0, frac)
                    merged = list(pl1)
                    for (cx, cy, a, ss) in pl2:
                        merged.append((cx + off2[0], cy + off2[1], a, ss))
                    consider(tv, merged)

    # --- Family C: big corner square + remainder L-shape grid ---
    # Place one axis-aligned square of side a in corner [0,a]x[0,a];
    # remaining region is union of right strip (1-a) x a and top strip 1 x (1-a).
    # Distribute remaining n-1 squares between the two strips.
    try:
        from scipy.optimize import minimize_scalar
        have_scipy = True
    except Exception:
        have_scipy = False

    def corner_eval(a, rem):
        if a <= 1e-9 or a >= 1 - 1e-9:
            return None
        # right strip: width (1-a), height a ; top strip: width 1, height (1-a)
        # try all splits of rem into (k, rem-k)
        best_local = None
        # candidate a choices: grid-driven; here we just distribute
        for k in range(0, rem + 1):
            r2 = rem - k
            v1, s1, p1, q1 = _grid_layout(k, 1.0 - a, a) if k > 0 else (0.0, 0.0, 0, 0)
            v2, s2, p2, q2 = _grid_layout(r2, 1.0, 1.0 - a) if r2 > 0 else (0.0, 0.0, 0, 0)
            tot = a + v1 + v2
            if best_local is None or tot > best_local[0] + 1e-12:
                best_local = (tot, a, k, p1, q1, s1, p2, q2, s2, r2)
        return best_local

    # scan candidate a values and refine
    cand_a = set()
    for den in (2, 3, 4, 5, 6, 7, 8, 10, 12):
        for num in range(1, den):
            cand_a.add(num / den)
    # grid-driven sizes
    for m in range(1, n):
        vm, sm, pm, qm = _grid_layout(m, 1.0, 1.0)
        if 0 < sm < 1:
            cand_a.add(sm)
            cand_a.add(sm * 2)
    cand_a = sorted(x for x in cand_a if 1e-6 < x < 1 - 1e-6)

    best_corner = None
    for a in cand_a:
        res = corner_eval(a, n - 1)
        if res is None:
            continue
        if best_corner is None or res[0] > best_corner[0] + 1e-12:
            best_corner = res

    if best_corner is not None:
        tot, a, k, p1, q1, s1, p2, q2, s2, r2 = best_corner
        if tot > best_val + 1e-12:
            pl = [(a * 0.5, a * 0.5, 0.0, a)]
            # right strip placement
            if k > 0:
                sub = _emit_grid(1.0 - a, a, k, p1, q1, s1, k)
                for (cx, cy, ang, ss) in sub:
                    pl.append((cx + a, cy, ang, ss))
            if r2 > 0:
                sub = _emit_grid(1.0, 1.0 - a, r2, p2, q2, s2, r2)
                for (cx, cy, ang, ss) in sub:
                    pl.append((cx, cy + a, ang, ss))
            while len(pl) < n:
                pl.append((0.5, 0.5, 0.0, 0.0))
            consider(tot, pl[:n])

    # --- Family D: 45-degree tilted band(s) ---
    # A band of height h filled with tilted squares: side = h/sqrt(2),
    # each occupies width h. Number that fit across width 1: floor(1/h).
    # Use such bands plus an axis-aligned region for the rest.
    sq2 = math.sqrt(2.0)
    for h in cand_a:
        side = h / sq2
        cnt_fit = int(1.0 / h + 1e-9)
        if cnt_fit <= 0:
            continue
        for band_cnt in (cnt_fit,):
            if band_cnt > n:
                continue
            rem = n - band_cnt
            # remaining region height 1-h, width 1
            v_rem, sr, pr, qr = _grid_layout(rem, 1.0, 1.0 - h) if rem > 0 else (0.0, 0.0, 0, 0)
            tot = band_cnt * side + v_rem
            if tot > best_val + 1e-12:
                pl = []
                # fill band with tilted squares
                # each tilted square centered, occupy width h; place them evenly
                for i in range(band_cnt):
                    cx = (i + 0.5) * h
                    cy = h * 0.5
                    pl.append((cx, cy, 0.125, side))
                if rem > 0:
                    sub = _emit_grid(1.0, 1.0 - h, rem, pr, qr, sr, rem)
                    for (cx, cy, ang, ss) in sub:
                        pl.append((cx, cy + h, ang, ss))
                while len(pl) < n:
                    pl.append((0.5, 0.5, 0.0, 0.0))
                consider(tot, pl[:n])

    if best_pl is None:
        v, s, p, q = _grid_layout(n, 1.0, 1.0)
        best_pl = _emit_grid(1.0, 1.0, n, p, q, s, n)

    # sanitize
    result = []
    for (cx, cy, a, s) in best_pl[:n]:
        s = max(0.0, min(1.0, float(s)))
        cx = max(0.0, min(1.0, float(cx)))
        cy = max(0.0, min(1.0, float(cy)))
        result.append((cx, cy, 0.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
# EVOLVE-BLOCK-END
