"""Multi-scale guillotine packing plus a continuous SLSQP polish.

Stage 1: recursively split the unit square into rectangular cells whose aspect ratio
is kept as square as possible, then place a sub-grid of equal squares in each cell.

Stage 2: reformulate as a smooth optimisation.  We parameterise each square by its
centre (cx, cy) and its side s (angles fixed), and maximise sum(s) subject to
    - every square lies inside the unit square (four linear inequalities), and
    - no two squares overlap.
Overlap of two axis-aligned squares is avoided by requiring that their x-intervals
or y-intervals are separated; we encode this with a big-M / slack formulation using
scipy's SLSQP with inequality constraints.  A short fallback keeps the best valid
layout found.
"""

import math
import random

from scipy.optimize import minimize


def _best_block(n, w, h):
    """Place n equal squares in a w x h rectangle as a grid; return (side, cols, rows)."""
    if n <= 0:
        return 0.0, 0, 0
    best = (0.0, 1, 1)
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        s = min(w / cols, h / rows)
        if s > best[0]:
            best = (s, cols, rows)
    return best


def _overlap(a, b):
    """Return True if squares a and b (cx,cy,angle,side) overlap in their interiors."""
    ax, ay, aa, asd = a
    bx, by, ba, bsd = b
    if asd <= 0 or bsd <= 0:
        return False
    ra = asd * 1.4143 / 2
    rb = bsd * 1.4143 / 2
    dx = ax - bx
    dy = ay - by
    if dx * dx + dy * dy > (ra + rb) ** 2:
        return False

    def axes(cx, cy, ang, s):
        t = ang * 2 * math.pi
        c = math.cos(t)
        sn = math.sin(t)
        h = s / 2
        return [
            (cx + c * h - sn * h, cy + sn * h + c * h),
            (cx + c * h + sn * h, cy + sn * h - c * h),
            (cx - c * h + sn * h, cy - sn * h - c * h),
            (cx - c * h - sn * h, cy - sn * h + c * h),
        ], (c, sn)

    pa, (ca, sa) = axes(ax, ay, aa, asd)
    pb, (cb, sb) = axes(bx, by, ba, bsd)
    for ux, uy in [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]:
        amin = min(p[0] * ux + p[1] * uy for p in pa)
        amax = max(p[0] * ux + p[1] * uy for p in pa)
        bmin = min(p[0] * ux + p[1] * uy for p in pb)
        bmax = max(p[0] * ux + p[1] * uy for p in pb)
        if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
            return False
    return True


def _in_unit(cx, cy, ang, s):
    t = ang * 2 * math.pi
    c = abs(math.cos(t))
    sn = abs(math.sin(t))
    h = s / 2
    rx = c * h + sn * h
    ry = sn * h + c * h
    return cx - rx >= -1e-9 and cx + rx <= 1 + 1e-9 and cy - ry >= -1e-9 and cy + ry <= 1 + 1e-9


def _valid_layout(squares):
    n = len(squares)
    for i in range(n):
        cx, cy, ang, s = squares[i]
        if not (0 <= cx <= 1 and 0 <= cy <= 1 and 0 <= ang <= 1 and 0 <= s <= 1):
            return False
        if not _in_unit(cx, cy, ang, s):
            return False
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _construct(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    leaves = [(0.0, 0.0, 1.0, 1.0, n)]

    for _ in range(400):
        best_gain = 0.0
        best_idx = -1
        best_partition = None

        for idx, (x, y, w, h, cnt) in enumerate(leaves):
            if cnt < 2:
                continue
            cur_side, _, _ = _best_block(cnt, w, h)
            cur_val = cnt * cur_side
            horizontal_split = w >= h
            for a in range(1, cnt):
                b = cnt - a
                frac = math.sqrt(a) / (math.sqrt(a) + math.sqrt(b))
                frac = min(max(frac, 1e-3), 1 - 1e-3)
                if horizontal_split:
                    w1 = w * frac
                    w2 = w - w1
                    s1, _, _ = _best_block(a, w1, h)
                    s2, _, _ = _best_block(b, w2, h)
                    kind = 'v'
                else:
                    h1 = h * frac
                    h2 = h - h1
                    s1, _, _ = _best_block(a, w, h1)
                    s2, _, _ = _best_block(b, w, h2)
                    kind = 'h'
                val = a * s1 + b * s2
                gain = val - cur_val
                if gain > best_gain:
                    best_gain = gain
                    best_idx = idx
                    best_partition = (a, b, kind, frac)

        if best_idx < 0 or best_gain <= 1e-12:
            break

        x, y, w, h, cnt = leaves[best_idx]
        a, b, kind, frac = best_partition
        if kind == 'v':
            w1 = w * frac
            leaves[best_idx] = (x, y, w1, h, a)
            leaves.append((x + w1, y, w - w1, h, b))
        else:
            h1 = h * frac
            leaves[best_idx] = (x, y, w, h1, a)
            leaves.append((x, y + h1, w, h - h1, b))

    result = []
    for (x, y, w, h, cnt) in leaves:
        side, cols, rows = _best_block(cnt, w, h)
        if side <= 0:
            result += [(x + w / 2, y + h / 2, 0.0, 0.0)] * cnt
            continue
        gw = cols * side
        gh = rows * side
        ox = x + (w - gw) / 2
        oy = y + (h - gh) / 2
        placed = 0
        for i in range(cols):
            for j in range(rows):
                placed += 1
                cx = ox + (i + 0.5) * side
                cy = oy + (j + 0.5) * side
                result.append((cx, cy, 0.0, side))
        while placed < cnt:
            result.append((x + w / 2, y + h / 2, 0.0, 0.0))
            placed += 1

    result = result[:n]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result


def _slsqp_polish(squares, maxiter=400):
    """Maximise sum(s) with SLSQP: variables are (cx, cy, s) per square; angles fixed.

    Non-overlap is encoded by requiring either the x-projections or the y-projections
    to be separated:  cx_i - cx_j >= (s_i+s_j)/2 with a slack, OR the same in y.
    We use the product slack formulation: at least one of the two separations holds.
    SLSQP here uses the smooth surrogate g_ij = max over the two separations >= 0.
    """
    n = len(squares)
    if n == 0:
        return squares
    # variables: 3 per square (cx, cy, s)
    x0 = []
    for cx, cy, ang, s in squares:
        x0.append(cx)
        x0.append(cy)
        x0.append(s)
    x0 = [min(max(v, 0.0), 1.0) for v in x0]

    def unpack(x):
        return [(x[3 * i], x[3 * i + 1], x[3 * i + 2]) for i in range(n)]

    def neg_sum(x):
        return -sum(x[3 * i + 2] for i in range(n))

    def neg_grad(x):
        g = [0.0] * (3 * n)
        for i in range(n):
            g[3 * i + 2] = -1.0
        return g

    def constraints_bounds(x):
        # containment: cx - s/2 >= 0, cx + s/2 <= 1, same for y
        c = []
        for i in range(n):
            cx = x[3 * i]
            cy = x[3 * i + 1]
            s = x[3 * i + 2]
            h = s / 2
            c.append(cx - h)          # >= 0
            c.append(1 - cx - h)      # >= 0
            c.append(cy - h)          # >= 0
            c.append(1 - cy - h)      # >= 0
        return c

    cons = [{'type': 'ineq', 'fun': constraints_bounds}]

    # non-overlap: for each pair, dx_sep OR dy_sep >= 0
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]

    def pair_constraints(x):
        c = []
        for (i, j) in pairs:
            cxi, cyi, si = x[3 * i], x[3 * i + 1], x[3 * i + 2]
            cxj, cyj, sj = x[3 * j], x[3 * j + 1], x[3 * j + 2]
            dx_sep = abs(cxi - cxj) - (si + sj) / 2
            dy_sep = abs(cyi - cyj) - (si + sj) / 2
            # require dx_sep >= 0 OR dy_sep >= 0; approximate with max
            c.append(max(dx_sep, dy_sep))
        return c

    cons.append({'type': 'ineq', 'fun': pair_constraints})

    try:
        res = minimize(neg_sum, x0, jac=neg_grad, constraints=cons,
                       method='SLSQP', options={'maxiter': maxiter, 'ftol': 1e-10})
        x = res.x
    except Exception:
        return squares

    out = []
    for i in range(n):
        out.append((float(x[3 * i]), float(x[3 * i + 1]), squares[i][2], float(x[3 * i + 2])))
    # clamp into valid box
    out = [(min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), ang,
            min(max(s, 0.0), 1.0)) for (cx, cy, ang, s) in out]
    return out


def _greedy_fix(squares):
    """Starting from a possibly-slightly-invalid layout, shrink squares until valid."""
    n = len(squares)
    out = [list(s) for s in squares]

    def bad(i):
        cx, cy, ang, s = out[i]
        if s < 0:
            return True
        if not _in_unit(cx, cy, ang, s):
            return True
        for j in range(n):
            if j != i and _overlap(out[i], out[j]):
                return True
        return False

    for _ in range(60):
        changed = False
        for i in range(n):
            while bad(i) and out[i][3] > 1e-6:
                out[i][3] *= 0.98
                changed = True
            if bad(i):
                out[i][3] = 0.0
                changed = True
        if not changed:
            break
    return [(float(a), float(b), float(c), float(d)) for a, b, c, d in out]


def solve(n):
    if n <= 0:
        return []
    base = _construct(n)
    best = base
    best_val = sum(s[3] for s in base)

    candidates = [base]
    # axis-aligned SLSQP polish from the constructive baseline
    candidates.append(_slsqp_polish(base, maxiter=300))

    for cand in candidates:
        if not _valid_layout(cand):
            cand = _greedy_fix(cand)
        if _valid_layout(cand):
            v = sum(s[3] for s in cand)
            if v > best_val:
                best_val = v
                best = cand

    if not _valid_layout(best):
        best = base
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
