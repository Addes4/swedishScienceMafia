"""Multi-scale guillotine packing: recursively split the unit square into rectangular
cells whose aspect ratio is kept as square as possible, then place a sub-grid of equal
squares in each cell.  We greedily choose how many squares to put in each cell so that
the resulting sum of side lengths is large.  This is a purely constructive method that
works for any n without solving a global optimisation problem."""

import math


def _best_block(n, w, h):
    """Place n equal squares in a w x h rectangle as a grid; return (side, cols, rows)
    maximising the side, with cols*rows >= n (unused cells become size-zero squares)."""
    if n <= 0:
        return 0.0, 0, 0
    best = (0.0, 1, 1)
    # try numbers of columns; rows = ceil(n/cols)
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        s = min(w / cols, h / rows)
        if s > best[0]:
            best = (s, cols, rows)
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Greedy recursive subdivision into a binary tree of rectangles (guillotine cuts).
    # Each leaf holds a grid of equal squares.
    # State: list of (x, y, w, h, count)
    leaves = [(0.0, 0.0, 1.0, 1.0, n)]

    # Number of refinement rounds: split the leaf with the worst "efficiency" gain.
    for _ in range(400):
        # evaluate best split for every leaf with count >= 2
        best_gain = 0.0
        best_idx = -1
        best_partition = None  # (count_a, split along longer side)

        for idx, (x, y, w, h, cnt) in enumerate(leaves):
            if cnt < 2:
                continue
            cur_side, _, _ = _best_block(cnt, w, h)
            cur_val = cnt * cur_side
            # try splitting into two parts a and cnt-a, along the longer side
            if w >= h:
                # vertical cut: widths r and w-r; keep aspect reasonable
                for a in range(1, cnt):
                    b = cnt - a
                    # choose split fraction proportional to sqrt of counts to keep aspect
                    frac = math.sqrt(a) / (math.sqrt(a) + math.sqrt(b))
                    frac = min(max(frac, 1e-3), 1 - 1e-3)
                    w1 = w * frac
                    w2 = w - w1
                    s1, _, _ = _best_block(a, w1, h)
                    s2, _, _ = _best_block(b, w2, h)
                    val = a * s1 + b * s2
                    gain = val - cur_val
                    if gain > best_gain:
                        best_gain = gain
                        best_idx = idx
                        best_partition = (a, b, 'v', frac)
            else:
                for a in range(1, cnt):
                    b = cnt - a
                    frac = math.sqrt(a) / (math.sqrt(a) + math.sqrt(b))
                    frac = min(max(frac, 1e-3), 1 - 1e-3)
                    h1 = h * frac
                    h2 = h - h1
                    s1, _, _ = _best_block(a, w, h1)
                    s2, _, _ = _best_block(b, w, h2)
                    val = a * s1 + b * s2
                    gain = val - cur_val
                    if gain > best_gain:
                        best_gain = gain
                        best_idx = idx
                        best_partition = (a, b, 'h', frac)

        if best_idx < 0 or best_gain <= 1e-12:
            break

        x, y, w, h, cnt = leaves[best_idx]
        a, b, kind, frac = best_partition
        if kind == 'v':
            w1 = w * frac
            leaves[best_idx] = (x, y, w1, h, a)
            leaves.append((x + w1, y, w - w1, h, b))
        else:
            h1 = h * frac
            leaves[best_idx] = (x, y, w, h1, a)
            leaves.append((x, y + h1, w, h - h1, b))

    # Build the actual squares
    result = []
    for (x, y, w, h, cnt) in leaves:
        side, cols, rows = _best_block(cnt, w, h)
        if side <= 0:
            result += [(x + w / 2, y + h / 2, 0.0, 0.0)] * cnt
            continue
        # centre the grid of cols x rows in the cell
        gw = cols * side
        gh = rows * side
        ox = x + (w - gw) / 2
        oy = y + (h - gh) / 2
        placed = 0
        for i in range(cols):
            for j in range(rows):
                placed += 1
                cx = ox + (i + 0.5) * side
                cy = oy + (j + 0.5) * side
                result.append((cx, cy, 0.0, side))
        # any extra (shouldn't happen since cols*rows>=cnt) -> size zero
        while placed < cnt:
            result.append((x + w / 2, y + h / 2, 0.0, 0.0))
            placed += 1

    result = result[:n]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result
