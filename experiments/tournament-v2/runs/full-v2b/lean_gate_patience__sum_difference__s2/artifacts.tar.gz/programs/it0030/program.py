# EVOLVE-BLOCK-START
"""Direct iterated local search maximizing log|A-A|/log|A+A|, seeded with
translated Sidon-block unions that create heavy sum collisions."""
import math
import random
import time


def _stats(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return -1.0, 0, 0
    diffs = set()
    sums = set()
    for x in s:
        for y in s:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if ns <= 1 or nd <= 1:
        return -1.0, nd, ns
    score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return score, nd, ns


def _score(a):
    return _stats(a)[0]


def _rand_set(n, span):
    vals = random.sample(range(span), n) if span >= n else [random.randrange(span) for _ in range(n)]
    return sorted(set(vals))


def _sidon_base(n, span):
    """Greedy Sidon-ish base: keep pair sums mostly distinct => few sum collisions."""
    vals = random.sample(range(span), min(span, n * 3))
    random.shuffle(vals)
    base = []
    sums = set()
    for v in vals:
        ok = True
        new_sums = set()
        for b in base:
            s = v + b
            if s in sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        # also 2v
        if 2 * v in sums:
            ok = False
        if ok:
            base.append(v)
            sums |= new_sums
            sums.add(2 * v)
            if len(base) >= n:
                break
    return sorted(base)


def _translated_union_seed():
    """A = union over t in T of (lam*B + t), T additively rich (many sum collisions)."""
    nb = random.randint(6, 14)
    base = _sidon_base(nb, 2000)
    if len(base) < 4:
        return None
    lam = random.choice([1000, 5000, 20000, 100000])
    # translations that collide a lot: short AP gives many duplicate t_i+t_j
    nt = random.randint(4, 12)
    step = random.choice([1, 2, 3, 5])
    T = [random.randint(-100, 100) + step * i for i in range(nt)]
    # spread translations far apart so differences (lam*b1+t1)-(lam*b2+t2) distinct
    gap = lam * (max(base) - min(base) + 2)
    T = [t + i * gap for i, t in enumerate(T)]
    A = []
    for t in T:
        for b in base:
            A.append(lam * b + t)
    A = sorted(set(A))
    if len(A) < 6:
        return None
    return A


def _ilp(seed, deadline, span):
    cur = sorted(set(seed))
    if len(cur) < 4:
        return cur, -1.0
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    n = len(cur)

    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.55:
            i = random.randrange(len(cand))
            lo = min(cand) - 2 * span
            hi = max(cand) + 2 * span
            newv = random.randint(lo, hi)
            if newv in cand:
                continue
            cand[i] = newv
        elif r < 0.85:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-span, span)
        else:
            if random.random() < 0.5 and len(cand) < 300:
                cand.append(random.randint(min(cand) - span, max(cand) + span))
            elif len(cand) > 6:
                del cand[random.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 4:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.01:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    random.seed(987654321)
    start = time.time()
    deadline = start + 110

    best = None
    best_score = -1.0

    # Structured seeds: translated Sidon-block unions.
    for _ in range(120):
        if time.time() > deadline - 8:
            break
        seed = _translated_union_seed()
        if not seed:
            continue
        span = max(2, (max(seed) - min(seed)) // 6)
        sub = time.time() + 0.4
        c, sc = _ilp(seed, sub, span)
        if sc > best_score:
            best, best_score = c[:], sc

    # Random seeds.
    for trial in range(200):
        if time.time() > deadline - 8:
            break
        n = random.randint(30, 150)
        span = random.choice([n, int(n * 1.2), int(n * 1.5), int(n * 2), int(n * 3)])
        seed = _rand_set(n, span)
        sub = time.time() + 0.4
        c, sc = _ilp(seed, sub, max(2, span // 4))
        if sc > best_score:
            best, best_score = c[:], sc

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
        best_score = _score(best)

    c, sc = _ilp(best, deadline - 1.0, max(2, (max(best) - min(best)) // 4))
    if sc > best_score:
        best, best_score = c, sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
