import math
import random
import time


def _metrics(a):
    a = list(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2 or len(diffs) < 2:
        return 0.0, len(diffs), len(sums)
    sc = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / n) / 100
    return sc, len(diffs), len(sums)


def _ap_union(lengths, steps, offsets):
    A = []
    for L, s, o in zip(lengths, steps, offsets):
        A.extend(o + s * i for i in range(L))
    return A


def solve():
    deadline = time.time() + 110
    best_A = []
    best_sc = -1.0

    # Union of a few APs with distinct (large, coprime-ish) steps.
    # Within each AP sums collide strongly; cross terms spread differences.
    step_pool = [1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]

    configs = []
    # number of APs, base length per AP
    for num_aps in (2, 3, 4):
        for per in (8, 16, 32, 64):
            for mult in (1, 7, 30, 200, 1500):
                lengths = [per] * num_aps
                steps = [mult * step_pool[i] for i in range(num_aps)]
                offsets = [i * 10**6 for i in range(num_aps)]
                configs.append((lengths, steps, offsets))

    for lengths, steps, offsets in configs:
        if time.time() > deadline - 10:
            break
        A = _ap_union(lengths, steps, offsets)
        A = sorted(set(A))
        if len(A) > 4000 or max(abs(v) for v in A) > 10**15:
            continue
        sc, nd, ns = _metrics(A)
        if sc > best_sc:
            best_sc, best_A = sc, A[:]

    # Random search over offsets for the best config found (structured).
    if best_A:
        A = best_A[:]
        cur_sc = best_sc
        base_steps = sorted({abs(A[i+1]-A[i]) for i in range(len(A)-1) if A[i+1]-A[i] > 0})
        iters = 0
        while time.time() < deadline and iters < 60000:
            iters += 1
            mode = random.random()
            cand = A[:]
            if mode < 0.5:
                # add an element consistent with some AP
                step = random.choice(base_steps) if base_steps else 1
                x = random.choice(A)
                cand.append(x + step)
            elif mode < 0.8:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-3, 3)
            else:
                if len(cand) > 4:
                    cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2 or len(cand) > 4000:
                continue
            if max(abs(v) for v in cand) > 10**15:
                continue
            sc, nd, ns = _metrics(cand)
            if sc > cur_sc:
                A, cur_sc = cand, sc
                if sc > best_sc:
                    best_sc, best_A = sc, cand[:]

    if not best_A:
        best_A = [0, 1, 3, 7, 12, 20]
    return sorted(set(best_A))
