# EVOLVE-BLOCK-START
"""Sidon-base construction: build a B_2 set B (distinct pairwise sums), then embed it
into the integers so that |A - A| stays very large while |A + A| resembles |B + B|.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _greedy_sidon(n, pool, rng):
    """Greedy B_2 set: all pairwise sums a+b (with a<=b) distinct."""
    B = []
    sumset = set()
    cand = list(pool)
    rng.shuffle(cand)
    for x in cand:
        if len(B) >= n:
            break
        ok = True
        new_sums = []
        for y in B:
            for s in (x + y,):
                if s in sumset:
                    ok = False
                    break
            if not ok:
                break
        if ok:
            s0 = x + x
            if s0 in sumset:
                ok = False
        if ok:
            for y in B:
                new_sums.append(x + y)
            new_sums.append(x + x)
            for s in new_sums:
                sumset.add(s)
            B.append(x)
    return B


def _embed_sidon(B, base_shift):
    """Embed B into integers with a superincreasing-with-signed drift map so that
    differences of A are mostly distinct but sums collapse onto B+B structure."""
    B = sorted(B)
    n = len(B)
    # spread the values strongly: A_i = B_i * K + i * D, with D chosen so that
    # A is 'convex'; keep sums controlled via the Sidon property of B.
    K = base_shift
    A = []
    for i, b in enumerate(B):
        A.append(b * K + i * i * 3 + i)
    return A


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 100

    best = None
    best_score = -1.0

    # try several sizes / pools
    for n in [30, 60, 100, 160, 240, 340, 480, 650, 850, 1100, 1400, 1800]:
        if time.time() > deadline:
            break
        pool = list(range(1, n * 6 + 10))
        B = _greedy_sidon(n, pool, rng)
        if len(B) < 3:
            continue
        for shift in [1, 7, 1000, 10 ** 6]:
            A = _embed_sidon(B, shift)
            A = sorted(set(A))
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A
        if time.time() > deadline:
            break

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
