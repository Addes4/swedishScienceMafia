# EVOLVE-BLOCK-START
"""Iterated local search maximizing log|A-A|/log|A+A|, with a fast numpy scorer,
translated-Sidon-block seeds, and a reheat phase."""
import math
import random
import time
import numpy as np


def _stats_np(arr):
    """arr: 1-D int64 numpy array of distinct values."""
    n = arr.size
    if n < 2:
        return -1.0, 0, 0
    d = arr[:, None] - arr[None, :]
    s = arr[:, None] + arr[None, :]
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns <= 1 or nd <= 1:
        return -1.0, nd, ns
    score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return score, nd, ns


def _score_np(arr):
    return _stats_np(arr)[0]


def _stats(a):
    return _stats_np(np.array(sorted(set(a)), dtype=np.int64))


def _score(a):
    return _stats(a)[0]


def _rand_set(n, span):
    vals = random.sample(range(span), n) if span >= n else [random.randrange(span) for _ in range(n)]
    return sorted(set(vals))


def _sidon_base(n, span):
    vals = random.sample(range(span), min(span, n * 3))
    random.shuffle(vals)
    base = []
    sums = set()
    for v in vals:
        ok = True
        new_sums = set()
        for b in base:
            s = v + b
            if s in sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if 2 * v in sums:
            ok = False
        if ok:
            base.append(v)
            sums |= new_sums
            sums.add(2 * v)
            if len(base) >= n:
                break
    return sorted(base)


def _translated_union_seed():
    nb = random.randint(6, 14)
    base = _sidon_base(nb, 2000)
    if len(base) < 4:
        return None
    lam = random.choice([1000, 5000, 20000, 100000, 1000000])
    nt = random.randint(4, 12)
    step = random.choice([1, 2, 3, 5])
    T = [random.randint(-100, 100) + step * i for i in range(nt)]
    gap = lam * (max(base) - min(base) + 2)
    T = [t + i * gap for i, t in enumerate(T)]
    A = []
    for t in T:
        for b in base:
            A.append(lam * b + t)
    A = sorted(set(A))
    if len(A) < 6:
        return None
    return A


def _ilp(seed, deadline, span):
    cur = np.array(sorted(set(seed)), dtype=np.int64)
    if cur.size < 4:
        return cur.tolist(), -1.0
    cur_score = _score_np(cur)
    best = cur.copy()
    best_score = cur_score

    while time.time() < deadline:
        cand = cur.copy()
        r = random.random()
        if r < 0.55:
            i = random.randrange(cand.size)
            lo = int(cand.min()) - 2 * span
            hi = int(cand.max()) + 2 * span
            newv = random.randint(lo, hi)
            if newv in set(cand.tolist()):
                continue
            cand[i] = newv
        elif r < 0.85:
            i = random.randrange(cand.size)
            cand[i] += random.randint(-span, span)
        else:
            if random.random() < 0.5 and cand.size < 300:
                lo = int(cand.min()) - span
                hi = int(cand.max()) + span
                cand = np.append(cand, random.randint(lo, hi))
            elif cand.size > 6:
                cand = np.delete(cand, random.randrange(cand.size))
        cand = np.unique(cand)
        if cand.size < 4:
            continue
        s = _score_np(cand)
        if s > cur_score or random.random() < 0.01:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand.copy(), s
    return best.tolist(), best_score


def _reheat(arr, deadline, span):
    cur = np.array(sorted(set(arr)), dtype=np.int64)
    if cur.size < 4:
        return cur.tolist(), -1.0
    cur_score = _score_np(cur)
    best = cur.copy()
    best_score = cur_score
    T0 = 0.01
    while time.time() < deadline:
        cand = cur.copy()
        i = random.randrange(cand.size)
        cand[i] += random.randint(-span, span)
        cand = np.unique(cand)
        if cand.size < 4:
            continue
        s = _score_np(cand)
        if s > cur_score or random.random() < math.exp(-(cur_score - s) / max(T0, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand.copy(), s
        T0 *= 0.99995
    return best.tolist(), best_score


def solve():
    random.seed(987654321)
    start = time.time()
    deadline = start + 110

    best = None
    best_score = -1.0

    for _ in range(120):
        if time.time() > deadline - 10:
            break
        seed = _translated_union_seed()
        if not seed:
            continue
        span = max(2, (max(seed) - min(seed)) // 6)
        sub = time.time() + 0.5
        c, sc = _ilp(seed, sub, span)
        if sc > best_score:
            best, best_score = c[:], sc

    for trial in range(200):
        if time.time() > deadline - 10:
            break
        n = random.randint(30, 150)
        span = random.choice([n, int(n * 1.2), int(n * 1.5), int(n * 2), int(n * 3)])
        seed = _rand_set(n, span)
        sub = time.time() + 0.5
        c, sc = _ilp(seed, sub, max(2, span // 4))
        if sc > best_score:
            best, best_score = c[:], sc

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
        best_score = _score(best)

    span = max(2, (max(best) - min(best)) // 4) if len(best) > 1 else 2
    c, sc = _ilp(best, deadline - 5.0, span)
    if sc > best_score:
        best, best_score = c, sc

    c, sc = _reheat(best, deadline - 0.5, max(2, span))
    if sc > best_score:
        best, best_score = c, sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
