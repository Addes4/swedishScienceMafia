# EVOLVE-BLOCK-START
"""Bose-Chowla Sidon core + multi-level base-M dilation.

Build a genuine Bose-Chowla Sidon set B in Z_{q^2-1} of size ~q:
for the finite field F_{q^2} with primitive element theta, the set
    { a in Z_{q^2-1} : theta^a = theta + X }   (roots of the BC map)
is Sidon in Z_{q^2-1}, i.e. all pairwise sums c+c' are distinct mod N.
Then embed B into Z via
    A = { sum_t c_t * M^t : c_t in B, t = 0..L-1 }
with M > 2*max(B) so that differences cannot cancel across digits.
We get |A-A| ~ |B-B|^L and |A+A| ~ |B+B|^L, so the exponent equals
log|B-B|/log|B+B| ~ log(|B|^2)/log(|B|^2/2) -> close to 1 but the
base ratio for a true Sidon set is 2 in the "sums counted" sense:
|B+B| = |B|(|B|+1)/2 and |B-B| = |B|(|B|-1)+1, giving exponent
log(|B|^2)/log(|B|^2/2) which is what we want.  Size bonus is near 1.
"""
import math
import time

MAX_A = 4000
LIMIT = 10 ** 15


def _is_prime(m):
    if m < 2:
        return False
    if m % 2 == 0:
        return m == 2
    i = 3
    while i * i <= m:
        if m % i == 0:
            return False
        i += 2
    return True


def _bsgs_log(mod, base, target):
    """Solve base^x = target in Z_mod for x in [0, mod) via baby-step giant-step."""
    if mod <= 1:
        return 0
    m = int(math.isqrt(mod)) + 1
    table = {}
    cur = 1
    for j in range(m):
        table.setdefault(cur, j)
        cur = (cur * base) % mod
    factor = pow(base, mod - m, mod)  # base^{-m}
    gamma = target % mod
    for i in range(m + 1):
        if gamma in table:
            return i * m + table[gamma]
        gamma = (gamma * factor) % mod
    return -1


def _bose_chowla_set(q):
    """Bose-Chowla Sidon set in Z_{q^2-1} for prime q, size q.

    Represent F_{q^2} = F_q[X]/(X^2 - X - d) with a non-residue d, primitive
    element theta, and take the exponents a with theta^a = theta + X.
    We instead use the simple known parametrization: pick a primitive
    element g of F_{q^2}; B = { log_g(g + X0) } for a suitable X0.
    For practicality we enumerate exponents of the form found by searching
    for an element whose square is a non-residue / using the standard
    'Samuelson' trick is complex; here we use the direct known BC set in
    Z_{q^2-1} constructed as follows.
    """
    # Standard Bose-Chowla construction:
    #   Let p = q prime, and let e = q^2 - 1.
    #   Fix a primitive element x of F_{q^2} (found by search over a
    #   quadratic extension built as pairs (a,b) with multiplication
    #   (a,b)*(c,d) = (ac + bd*d0, ad + bc)  where X^2 = d0 (non-residue)).
    #   Then B = { i : x^i = x + (0,1) }  (i.e. exponent of x + X).
    # This gives |B| = q and B Sidon in Z_e.
    e = q * q - 1
    if e <= 0:
        return [0]
    # find non-residue d0 in F_q
    def is_qr(a):
        if a == 0:
            return True
        return pow(a, (q - 1) // 2, q) == 1
    d0 = None
    for a in range(2, q):
        if not is_qr(a):
            d0 = a
            break
    if d0 is None:
        d0 = 2  # q small fallback

    def mul(u, v):
        a, b = u
        c, d = v
        return ((a * c + b * d * d0) % q, (a * d + b * c) % q)

    def pw(u, k):
        r = (1, 0)
        base = u
        while k:
            if k & 1:
                r = mul(r, base)
            base = mul(base, base)
            k >>= 1
        return r

    # find primitive element of F_{q^2}: order e
    def order(u):
        # factor e
        n = e
        fac = []
        d = 2
        while d * d <= n:
            if n % d == 0:
                fac.append(d)
                while n % d == 0:
                    n //= d
            d += 1
        if n > 1:
            fac.append(n)
        o = e
        for f in fac:
            while o % f == 0 and pw(u, o // f) == (1, 0):
                o //= f
        return o

    prim = None
    for a in range(q):
        for b in range(q):
            if (a, b) == (0, 0):
                continue
            if order((a, b)) == e:
                prim = (a, b)
                break
        if prim is not None:
            break
    if prim is None:
        return [0]

    target = (1, 1)  # theta + X ... using X with X^2 = d0 => (1,1) means 1 + X
    # solve prim^i = target
    idx = _bsgs_log(e, _pair_to_int(prim, q), _pair_to_int(target, q))
    # BSGS over Z_e directly using pair multiplication is cleaner:
    B = []
    # full cycle search (e up to ~ q^2, q small enough)
    cur = (1, 0)
    for i in range(e):
        if cur == target:
            B.append(i)
        cur = mul(cur, prim)
    return sorted(set(B))


def _pair_to_int(u, q):
    return u[0] * q + u[1]


def _greedy_sidon(target, maxval):
    B = [0]
    sums = {0}
    cand = 1
    while len(B) < target and cand <= maxval:
        ok = True
        for b in B:
            if cand + b in sums:
                ok = False
                break
        if ok:
            for b in B:
                sums.add(cand + b)
            sums.add(2 * cand)
            B.append(cand)
        cand += 1
    return B


def _score_quick(A):
    A = list(set(A))
    n = len(A)
    if n < 2:
        return -1.0
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    if len(sums) < 2:
        return -1.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0


def _build(A0, M, L):
    cur = [0]
    for _ in range(L):
        cur = [x * M + c for x in cur for c in A0]
        if len(cur) > MAX_A:
            return None
    return sorted(set(cur))


def solve():
    deadline = time.time() + 110

    best = None
    best_score = -1.0
    best_A = None

    # Candidate cores: Bose-Chowla sets for small primes q, plus greedy sets.
    cores = []
    for q in (3, 5, 7, 11, 13):
        if time.time() > deadline:
            break
        B = _bose_chowla_set(q)
        if len(B) >= 3:
            # normalize to non-negative with small spread
            B = sorted(set(B))
            cores.append(B)
    for target in (3, 4, 5, 6, 7, 8, 9, 10):
        C = _greedy_sidon(target, 400)
        if len(C) >= 3:
            cores.append(C)

    for C in cores:
        if time.time() > deadline:
            break
        span = max(C) - min(C)
        M = 2 * span + 1 if span > 0 else 3
        for L in range(1, 10):
            if time.time() > deadline:
                break
            if len(C) ** L > MAX_A:
                break
            A = _build(C, M, L)
            if A is None:
                continue
            if A[-1] > LIMIT or A[0] < -LIMIT:
                continue
            if len(A) < 2:
                continue
            sc = _score_quick(A)
            if sc > best_score:
                best_score = sc
                best = A

    if best is None:
        best = _greedy_sidon(6, 100)
    return sorted(set(best))
# EVOLVE-BLOCK-END
