# EVOLVE-BLOCK-START
"""Direct ratio-driven greedy: grow A choosing candidates that maximize the
difference/sum tradeoff exactly, then local-search refine the exact score.

The score log|A-A|/log|A+A| rewards: many distinct differences, few distinct sums.
A greedy that adds an element x only if it creates many NEW differences (x-a, a-x)
while creating few new sums (x+a) directly pushes the ratio up. Scaling a good
finite set into a large range makes differences from distinct base differences
distinct too, but risks adding sum collisions less than difference collisions.
"""
import math
import random
import time


def _score(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return 0.0
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _grow_ratio(seed, pool, target_n, deadline):
    """Greedily add the pool element maximizing new-diff / new-sum gain."""
    A = list(seed)
    A_set = set(A)
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    pool = [p for p in pool if p not in A_set]
    random.shuffle(pool)
    pi = 0
    while len(A) < target_n and time.time() < deadline:
        best_x = None
        best_val = -1e18
        # scan a random subset of pool each round for speed
        scanned = 0
        limit = min(len(pool), 800)
        start = pi % max(1, len(pool))
        for k in range(limit):
            x = pool[(start + k) % len(pool)]
            if x in A_set:
                continue
            nd = 0
            ns = 0
            for a in A:
                if (x - a) not in diffs:
                    nd += 1
                if (x + a) not in sums:
                    ns += 1
            # 2x for 2*x diff/sum
            if (x - x) not in diffs:  # always 0 in diffs for |A|>=1
                pass
            if (2 * x) not in diffs:
                nd += 1
            if (2 * x) not in sums:
                ns += 1
            # value: reward new diffs, penalize new sums
            val = nd - 2.0 * ns
            if val > best_val:
                best_val = val
                best_x = x
            scanned += 1
        if best_x is None:
            break
        # actually compute exact new counts for acceptance
        x = best_x
        add = True
        for a in A:
            pass
        if add and len(A) < target_n:
            nd = 0
            ns = 0
            for a in A:
                if (x - a) not in diffs:
                    nd += 1
                if (a - x) not in diffs:
                    nd += 1
                if (x + a) not in sums:
                    ns += 1
            if (2 * x) not in diffs:
                nd += 1
            if (2 * x) not in sums:
                ns += 1
            A.append(x)
            A_set.add(x)
            for a in A:
                diffs.add(x - a)
                diffs.add(a - x)
                sums.add(x + a)
        pi += 1
    return A


def _refine(A, deadline):
    best = sorted(set(A))
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score
    sset = set(cur)
    maxv = max(abs(v) for v in cur) if cur else 1
    span = max(1, maxv // max(1, len(cur)))
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.55 and len(cand) >= 2:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, max(1, span))
        elif op < 0.75:
            cand.append(random.randint(-maxv, maxv))
        elif op < 0.9 and len(cand) > 3:
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            # swap: move an element to a nearby unused value
            if len(cand) >= 2:
                i = random.randrange(len(cand))
                cand[i] += random.choice([-1, 1]) * max(1, span // 2)
        cand = sorted(set(cand))
        if not cand or len(cand) > 4000:
            continue
        if max(abs(x) for x in cand) > 10 ** 15:
            continue
        s = _score(cand)
        if s > cur_score or (s == cur_score and len(cand) > len(cur)):
            cur, cur_score = cand, s
            if s > best_score or (s == best_score and len(cand) > len(best)):
                best, best_score = cand[:], s
        elif random.random() < 0.015:
            cur = best[:]
            cur_score = best_score
    return best


def solve():
    deadline = time.time() + 110

    # Pool: small dense range so differences stay distinct via scaling later.
    random.seed(12345)
    target_n = 400
    # Seed with a couple of small values spread out.
    seed = [0, 1]
    # Pool: values in a moderate range (small => many distinct diffs possible).
    pool = list(range(2, 40000))
    A0 = _grow_ratio(seed, pool, target_n, time.time() + 60)

    # Scale into a large range so differences become distinct.
    A0 = sorted(set(A0))
    if A0:
        mx = max(A0) - min(A0)
        scale = 1
        if mx > 0:
            scale = min(10 ** 9, max(1, (10 ** 15 // (2 * (mx + 1)))))
        A0 = [v * scale for v in A0]

    best = A0
    best_score = _score(best)

    # Also try a larger greedy set (more elements => larger bonus & ratio floor).
    if time.time() < deadline:
        seed2 = [0, 1]
        pool2 = list(range(2, 120000))
        A1 = _grow_ratio(seed2, pool2, 1200, time.time() + 20)
        A1 = sorted(set(A1))
        if A1:
            mx = max(A1) - min(A1)
            scale = min(10 ** 9, max(1, (10 ** 15 // (2 * (mx + 1))))) if mx > 0 else 1
            A1 = [v * scale for v in A1]
            s1 = _score(A1)
            if s1 > best_score:
                best, best_score = A1, s1

    best = _refine(best, deadline)
    return sorted(set(best))
# EVOLVE-BLOCK-END
