"""Approach: construct A via a Sidon-like greedy/randomized sum-avoiding construction
(few distinct sums), then refine with exact-score local search."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _local(a, deadline):
    a = list(set(a))
    best = a[:]
    best_s = _score(best)
    cur = a[:]
    cur_s = best_s
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2, random.randint(-100, 100)])
        elif op < 0.8:
            cand.append(random.randint(-1000, 1000))
        elif len(cand) > 3:
            del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        s = _score(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s >= best_s:
                best, best_s = cand[:], s
        elif random.random() < 0.05:
            cur, cur_s = best[:], best_s
    return best, best_s


def _sidon_greedy(pool_hi, n_target, rng):
    """Build a set where sums are as concentrated as possible: greedily pick elements
    keeping the number of distinct sums small relative to size."""
    A = [0]
    sums = {0}
    used = {0}
    for _ in range(n_target):
        best_c = None
        best_pen = None
        for _t in range(30):
            c = rng.randint(-pool_hi, pool_hi)
            if c in used:
                continue
            new_sums = {c + x for x in A}
            add = len(new_sums - sums)
            # prefer small growth of sums, large spread (|c| big helps diffs)
            pen = add - 0.02 * abs(c)
            if best_pen is None or pen < best_pen:
                best_pen = pen
                best_c = c
        if best_c is None:
            break
        A.append(best_c)
        used.add(best_c)
        sums |= {best_c + x for x in A}
    return A


def solve():
    deadline = time.time() + 110
    rng = random.Random(12345)
    best = None
    best_s = -1.0

    # several starts: greedy Sidon-ish, plus arithmetic-like seeds
    seeds = []
    for hi in (50, 200, 800, 3000):
        seeds.append(_sidon_greedy(hi, 25, rng))
    seeds.append([i for i in range(1, 30)])
    seeds.append([0, 1, 3, 7, 12, 20, 30, 44, 65, 80])

    for s in seeds:
        if time.time() > deadline:
            break
        b, bs = _local(s, min(deadline, time.time() + 12))
        if bs > best_s:
            best, best_s = b, bs

    while time.time() < deadline:
        b, bs = _local(best[:], min(deadline, time.time() + 8))
        if bs > best_s:
            best, best_s = b, bs

    return sorted(set(best))
