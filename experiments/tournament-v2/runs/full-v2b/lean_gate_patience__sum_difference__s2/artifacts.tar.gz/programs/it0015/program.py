"""Approach. Look for the best ratio empirically by combining (a) digit-sum
sets with exactly k ones in m bits (small sum sets, dense difference sets) and
(b) 'box' / mixed-radix digit constructions A = {sum_i d_i * t_i : 0<=t_i<T}
which have |A+A| and |A-A| both equal to the box, giving ratio ~2*(dim-1)/dim
when the digit ranges make sums/differences collapse. Since the ratio is a
ratio of logarithms, the *right* structure to win is one where the number of
distinct differences is much larger than the number of distinct sums. For a
'box' all sums/diffs are distinct, rating ~ (2d*logT)/(d*logT)=2, but offsets
collapse. The digit-sum (Sidon-ish) families used here get ~1.17-1.28. We scan
broadly and keep the exact max using a fast numpy bitset scorer."""
import math
import time
from itertools import combinations
import numpy as np


def _bitset_pair(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    n = a.shape[0]
    dmin = int(a[0] - a[-1]); dmax = int(a[-1] - a[0])
    smin = int(a[0] + a[0]); smax = int(a[-1] + a[-1])

    def make_bits(vals, lo, hi):
        width = hi - lo + 1
        words = (width + 63) // 64
        bits = np.zeros(words, dtype=np.int64)
        idx = vals - lo
        w = idx >> 6
        b = idx & 63
        np.bitwise_or.at(bits, w, (np.int64(1) << b).astype(np.int64))
        return bits

    diff = (a[:, None] - a[None, :]).ravel()
    dbits = make_bits(diff.astype(np.int64), dmin, dmax)
    ndistinct_d = int(np.unpackbits(dbits.view(np.uint8)).sum())

    ssum = (a[:, None] + a[None, :]).ravel()
    sbits = make_bits(ssum.astype(np.int64), smin, smax)
    ndistinct_s = int(np.unpackbits(sbits.view(np.uint8)).sum())

    return ndistinct_d, ndistinct_s


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _bitset_pair(a)
    if ns <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _digit_set(m, k):
    out = []
    for comb in combinations(range(m), k):
        v = 0
        for b in comb:
            v |= (1 << b)
        out.append(v)
    return out


def _mixed_radix(dims, base):
    """A = { sum_i base^i * t_i : 0 <= t_i < dims[i] }."""
    A = [0]
    p = 1
    for d in dims:
        new = []
        for v in A:
            for t in range(d):
                new.append(v + p * t)
        A = new
        p *= base
    return A


def solve():
    deadline = time.time() + 100
    best = None
    best_s = -1.0
    NMAX = 4000

    def consider(A):
        nonlocal best, best_s
        A = sorted(set(A))
        n = len(A)
        if n < 2 or n > NMAX:
            return
        if max(abs(v) for v in A) > 10**15:
            return
        try:
            s = _score(A)
        except Exception:
            return
        if s > best_s:
            best_s = s
            best = A

    # (a) digit-sum sets: numbers with exactly k ones in m bits.
    for m in range(6, 30):
        for k in range(1, m):
            size = math.comb(m, k)
            if size < 2 or size > NMAX:
                continue
            consider(_digit_set(m, k))
        if time.time() > deadline:
            break

    # (b) mixed-radix boxes near the element limit.
    if time.time() < deadline:
        for base in (2, 3, 4, 5, 6, 7, 8, 10, 13):
            dims = []
            size = 1
            # grow dimension count until near NMAX
            for _ in range(10):
                if size * base > NMAX:
                    break
                dims.append(base)
                size *= base
            if len(dims) >= 2:
                consider(_mixed_radix(dims, base))
            if time.time() > deadline:
                break

    # (c) small dilations / offsets of the best
    if best is not None and time.time() < deadline:
        for off in (0, 1, -1, 2, -2):
            consider([v + off for v in best])

    return best if best else [0, 1]
