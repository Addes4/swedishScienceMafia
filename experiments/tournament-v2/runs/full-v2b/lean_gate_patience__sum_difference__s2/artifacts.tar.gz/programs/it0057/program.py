# EVOLVE-BLOCK-START
"""Direct greedy optimization of the target ratio.

We maintain difference-set D and sum-set S incrementally.  At each step
we scan a candidate pool and pick the integer x maximizing the resulting
objective log|D'| / log|S'| (+ tiny size bonus).  Because the objective
saturates for large n (the size bonus is at most 0.01) it is enough to
work with modest n, where exact incremental bookkeeping is cheap.  We run
several stochastic restarts with different candidate pools / starting
points and keep the best set found within the time budget.
"""
import math
import time

MAX_A = 4000
LIMIT = 10 ** 15


def _objective(nd, ns, n):
    if ns < 2 or nd < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _greedy(seed, pool, max_n):
    A = list(seed)
    D = {x - y for x in A for y in A}
    S = {x + y for x in A for y in A}
    used = set(A)
    for _ in range(max_n - len(A)):
        best_x = None
        best_ratio = -1.0
        n_new = len(A) + 1
        for x in pool:
            if x in used:
                continue
            newD = {x - a for a in A}
            newD |= {-d for d in newD}
            newS = {x + a for a in A}
            nd = len(D | newD)
            ns = len(S | newS)
            if ns < 2:
                continue
            r = math.log(nd) / math.log(ns)
            if r > best_ratio:
                best_ratio = r
                best_x = x
                best_nd, best_ns = nd, ns
        if best_x is None:
            break
        x = best_x
        for a in A:
            D.add(x - a)
            D.add(a - x)
            S.add(x + a)
        S.add(2 * x)
        D.add(0)
        A.append(x)
        used.add(x)
        if len(pool) < 4:
            break
    return A


def solve():
    deadline = time.time() + 108

    best = None
    best_score = -1.0

    # Candidate pools of varying ranges / shapes.
    pools = []
    pools.append(list(range(0, 60)))
    pools.append([i * i for i in range(0, 12)])
    pools.append([2 ** i for i in range(0, 14)])
    # mixed geometric + linear
    mixed = []
    for i in range(0, 40):
        mixed.append(i)
    for i in range(0, 10):
        mixed.append(2 ** i)
    pools.append(mixed)
    # large sparse pool
    pools.append([i * 7 for i in range(0, 80)])

    seeds = [[0], [0, 1], [0, 1, 3], []]

    max_n = 300

    for seed in seeds:
        for pool in pools:
            if time.time() > deadline:
                break
            A = _greedy(seed, pool, max_n)
            if len(A) < 2:
                continue
            D = {x - y for x in A for y in A}
            S = {x + y for x in A for y in A}
            sc = _objective(len(D), len(S), len(A))
            if sc > best_score:
                best_score = sc
                best = A

    if best is None:
        best = [0, 1]
    return sorted(set(best))
# EVOLVE-BLOCK-END
