# EVOLVE-BLOCK-START
"""Construction: A = interval [0,m) UNION scaled Bose-Chowla Sidon set(s).

Bose-Chowla in Z_{q^2-1}: B = { i*q + (i^2 mod q) : i in [0,q) }.
This gives |B-B| approx q^2 = |B|^2 while |B+B| is much smaller because
i^2+j^2 mod q collisions collapse many sums.

We embed B with a large multiplier M so cross-differences with the interval
stay distinct, and add the interval to collapse sums. We search exactly.
"""
import math
import time


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def bose_chowla(q):
    """Return Bose-Chowla Sidon set of size q in Z_{q^2-1}."""
    base = [0]
    s = []
    # standard BC: for primitive element g of F_{q^2}, take exponents.
    # Simpler explicit variant: B = { i*q + (i*i) % q : 0<=i<q }.
    return [i * q + (i * i) % q for i in range(q)]


def score(a):
    a = list(set(a))
    if len(a) < 2:
        return -1.0, 0, 0
    diffs = len({x - y for x in a for y in a})
    sums = len({x + y for x in a for y in a})
    if sums < 1:
        return -1.0, diffs, sums
    return math.log(diffs) / math.log(sums) + (1 - 1 / len(a)) / 100, diffs, sums


def make_combined(m, Y, M):
    A = list(range(m))
    for y in Y:
        A.append(M * y)
    return A


def solve():
    deadline = time.time() + 105
    best_A = None
    best_sc = -1.0

    # Combine interval + a scaled Bose-Chowla set; drop the interval into
    # a single coordinate offset to also collapse sums.
    primes = [p for p in range(2, 60) if is_prime(p)]

    m_candidates = [1, 2, 4, 8, 16, 32, 64, 96, 128]

    for q in primes:
        if time.time() > deadline:
            break
        Y = bose_chowla(q)
        yspan = max(Y) - min(Y)
        for m in m_candidates:
            if time.time() > deadline:
                break
            # M large enough to separate cross-differences from intervals:
            # M*(nonzero y-diff) must exceed m.
            yd = sorted({abs(Y[i] - Y[j]) for i in range(len(Y)) for j in range(i + 1, len(Y))})
            ymin = yd[0] if yd else 1
            Mmin = (m + 2) // max(1, ymin) + 1
            for M in {Mmin, Mmin + 1, Mmin * 2, Mmin + m + 1}:
                if M < 1:
                    continue
                A = make_combined(m, Y, M)
                if max(abs(x) for x in A) > 10 ** 15:
                    continue
                s, _, _ = score(A)
                if s > best_sc:
                    best_sc = s
                    best_A = A[:]

    # Pure Bose-Chowla (no interval), since BC alone could yield high ratio.
    for q in primes:
        if time.time() > deadline:
            break
        A = bose_chowla(q)
        s, _, _ = score(A)
        if s > best_sc:
            best_sc = s
            best_A = A[:]

    if best_A is None:
        best_A = [0, 1, 3, 7]
    return list(set(best_A))
# EVOLVE-BLOCK-END
