# EVOLVE-BLOCK-START
"""Incremental iterated local search for max log|A-A|/log|A+A|.

Maintains sum/difference multisets in dicts so a single-element swap costs O(n)
instead of O(n^2). Includes a targeted "sum-collision" move that inserts
z = x + y - w (creating x + y = w + z) to actively shrink |A+A| while keeping
the difference set large.
"""
import math
import random
import time


def _sc(ad, sd, n):
    ns = len(sd)
    nd = len(ad)
    if ns <= 1 or nd <= 1:
        return -1.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _add(ad, sd, A, As, e):
    for o in A:
        s = e + o
        sd[s] = sd.get(s, 0) + 2
        d1 = e - o
        ad[d1] = ad.get(d1, 0) + 1
        d2 = o - e
        ad[d2] = ad.get(d2, 0) + 1
    sd[2 * e] = sd.get(2 * e, 0) + 1
    ad[0] = ad.get(0, 0) + 1
    A.append(e)
    As.add(e)


def _remove(ad, sd, A, As, e):
    A.remove(e)
    As.discard(e)
    for o in A:
        s = e + o
        c = sd[s] - 2
        if c:
            sd[s] = c
        else:
            del sd[s]
        d1 = e - o
        c = ad[d1] - 1
        if c:
            ad[d1] = c
        else:
            del ad[d1]
        d2 = o - e
        c = ad[d2] - 1
        if c:
            ad[d2] = c
        else:
            del ad[d2]
    c = sd[2 * e] - 1
    if c:
        sd[2 * e] = c
    else:
        del sd[2 * e]
    c = ad[0] - 1
    if c:
        ad[0] = c
    else:
        del ad[0]


def _build(A0):
    A = []
    As = set()
    ad = {}
    sd = {}
    for e in A0:
        if e not in As:
            _add(ad, sd, A, As, e)
    return A, As, ad, sd


def _search(A0, deadline, bg, maxn=400):
    A, As, ad, sd = _build(A0)
    if len(A) < 3:
        return
    n = len(A)
    cur = _sc(ad, sd, n)
    bestA = list(A)
    bestS = cur
    if bestS > bg[0]:
        bg[0] = bestS
        bg[1] = list(A)

    T = 0.004
    stall = 0
    while True:
        if time.time() > deadline:
            break
        r = random.random()
        if r < 0.28 and len(A) >= 6:
            # targeted sum-collision: replace some element by z = x + y - w
            x = random.choice(A)
            y = random.choice(A)
            w = random.choice(A)
            z = x + y - w
            old = random.choice(A)
            if z == old or z in As:
                continue
            _remove(ad, sd, A, As, old)
            _add(ad, sd, A, As, z)
            s2 = _sc(ad, sd, len(A))
            if s2 >= cur or random.random() < math.exp((s2 - cur) / T):
                cur = s2
                if s2 > bestS:
                    bestS = s2
                    bestA = list(A)
                    stall = 0
                    if s2 > bg[0]:
                        bg[0] = s2
                        bg[1] = list(A)
            else:
                _remove(ad, sd, A, As, z)
                _add(ad, sd, A, As, old)
        elif r < 0.72 and len(A) >= 6:
            # plain replacement
            mn = min(A)
            mx = max(A)
            span = max(2, mx - mn)
            old = random.choice(A)
            if random.random() < 0.5:
                newv = old + random.randint(-span // 4 - 1, span // 4 + 1)
            else:
                newv = random.randint(mn - span // 2, mx + span // 2)
            if newv == old or newv in As:
                continue
            _remove(ad, sd, A, As, old)
            _add(ad, sd, A, As, newv)
            s2 = _sc(ad, sd, len(A))
            if s2 >= cur or random.random() < math.exp((s2 - cur) / T):
                cur = s2
                if s2 > bestS:
                    bestS = s2
                    bestA = list(A)
                    stall = 0
                    if s2 > bg[0]:
                        bg[0] = s2
                        bg[1] = list(A)
            else:
                _remove(ad, sd, A, As, newv)
                _add(ad, sd, A, As, old)
        elif r < 0.88:
            # add element
            if len(A) >= maxn:
                continue
            mn = min(A)
            mx = max(A)
            span = max(2, mx - mn)
            newv = random.randint(mn - span // 2, mx + span // 2)
            if newv in As:
                continue
            _add(ad, sd, A, As, newv)
            s2 = _sc(ad, sd, len(A))
            if s2 >= cur or random.random() < math.exp((s2 - cur) / T):
                cur = s2
                if s2 > bestS:
                    bestS = s2
                    bestA = list(A)
                    stall = 0
                    if s2 > bg[0]:
                        bg[0] = s2
                        bg[1] = list(A)
            else:
                _remove(ad, sd, A, As, newv)
        else:
            # remove element
            if len(A) <= 6:
                continue
            old = random.choice(A)
            _remove(ad, sd, A, As, old)
            s2 = _sc(ad, sd, len(A))
            if s2 >= cur or random.random() < math.exp((s2 - cur) / T):
                cur = s2
                if s2 > bestS:
                    bestS = s2
                    bestA = list(A)
                    stall = 0
                    if s2 > bg[0]:
                        bg[0] = s2
                        bg[1] = list(A)
            else:
                _add(ad, sd, A, As, old)

        stall += 1
        if stall > 4000:
            # perturb from best found locally
            A, As, ad, sd = _build(bestA)
            cur = bestS
            stall = 0
            for _ in range(random.randint(1, 3)):
                if len(A) < 6:
                    break
                mn = min(A)
                mx = max(A)
                span = max(2, mx - mn)
                old = random.choice(A)
                _remove(ad, sd, A, As, old)
                newv = old + random.randint(-span, span)
                if newv not in As:
                    _add(ad, sd, A, As, newv)
            cur = _sc(ad, sd, len(A))


def _sidon_base(n, span, tries=1):
    best = []
    for _ in range(tries):
        pool = list(range(span))
        random.shuffle(pool)
        base = []
        sums = set()
        ok_all = True
        for v in pool:
            ok = True
            new_sums = set()
            for b in base:
                s = v + b
                if s in sums or s in new_sums:
                    ok = False
                    break
                new_sums.add(s)
            if ok and 2 * v in sums:
                ok = False
            if ok:
                base.append(v)
                sums |= new_sums
                sums.add(2 * v)
                if len(base) >= n:
                    break
        if len(base) > len(best):
            best = base
    return sorted(best)


def _translated_union_seed():
    nb = random.randint(6, 14)
    base = _sidon_base(nb, 2000)
    if len(base) < 4:
        return None
    lam = random.choice([1000, 5000, 20000, 100000])
    nt = random.randint(4, 12)
    step = random.choice([1, 2, 3, 5])
    T = [random.randint(-100, 100) + step * i for i in range(nt)]
    gap = lam * (max(base) - min(base) + 2)
    T = [t + i * gap for i, t in enumerate(T)]
    A = []
    for t in T:
        for b in base:
            A.append(lam * b + t)
    A = sorted(set(A))
    if len(A) < 6:
        return None
    return A


def _random_seed():
    n = random.randint(30, 160)
    span = random.choice([n, int(n * 1.2), int(n * 1.5), int(n * 2), int(n * 3)])
    if span >= n:
        vals = random.sample(range(span), n)
    else:
        vals = [random.randrange(span) for _ in range(n)]
    return sorted(set(vals))


def solve():
    random.seed(20240517)
    start = time.time()
    deadline = start + 115.0

    bg = [-1.0, None]

    # Phase 1: many short searches from diverse seeds.
    for _ in range(30):
        if time.time() > deadline - 25:
            break
        if random.random() < 0.35:
            seed = _translated_union_seed()
            if not seed:
                seed = _random_seed()
        else:
            seed = _random_seed()
        _search(seed, time.time() + 2.0, bg)

    if bg[1] is None:
        bg[1] = list(range(12))
        bg[0] = _sc(*(None,), 0) if False else bg[0]

    # Phase 2: long refinement from the global best.
    if bg[1] is not None:
        _search(bg[1], deadline - 0.5, bg)

    if bg[1] is None:
        return [0, 1, 3, 7, 12, 20]
    return sorted(set(bg[1]))
# EVOLVE-BLOCK-END
