# EVOLVE-BLOCK-START
"""Erdos-Turan Sidon construction in Z_{p^2-1}: A = {2p*x + (x^2 mod p)}.

This is an exact Sidon set (all pairwise sums distinct, so |A+A| = n(n+1)/2)
and simultaneously has near-maximal difference set, giving ratio close to 2.
"""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _prime_leq(n):
    while n >= 2 and not _is_prime(n):
        n -= 1
    return n


def _erdos_turan(p):
    """Sidon set in Z_{p^2-1}: A = {2p*x + (x^2 mod p) : x in [0,p)}."""
    mod = p * p - 1
    A = [2 * p * x + (x * x) % p for x in range(p)]
    # Reduce mod (p^2-1) where applicable to keep values small and distinct.
    seen = set()
    out = []
    for v in A:
        w = v % mod
        if w not in seen:
            seen.add(w)
            out.append(w)
    return out


def solve():
    deadline = time.time() + 110
    # Candidate primes; large p means large n. Cap n <= 4000.
    best = None
    best_score = -1.0
    # Sample a range of primes from moderate to ~1200 (n up to ~1200).
    primes = []
    p = 2
    while p <= 1400:
        # collect primes
        pass
        p += 1
    # Build candidate primes list efficiently
    cand = [x for x in range(2, 1401) if _is_prime(x)]
    for p in cand:
        if time.time() > deadline:
            break
        A = _erdos_turan(p)
        if len(A) < 2 or len(A) > 4000:
            continue
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A
    if best is None:
        best = _erdos_turan(_prime_leq(200))
    return best
# EVOLVE-BLOCK-END
