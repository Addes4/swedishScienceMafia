# EVOLVE-BLOCK-START
"""A = C + [0,k) with C a Bose-Chowla Sidon set.

Sums:   A+A = (C+C) + [0,2k),  |A+A| ~ |C+C| + 2k
Diffs:  A-A = (C-C) + [-k,k),  |A-A| ~ |C-C| + 2k
With C Sidon of size c: |C+C| ~ c^2/2 (plus c),  |C-C| ~ c^2.
Then n = c*k and ratio log(|C-C|+2k)/log(|C+C|+2k).
We sweep c and k using these cheap analytic formulas and only run exact
verification for the top candidates.
"""
import math
import time


def _is_prime_power(q):
    if q < 2:
        return None
    p = 2
    while p * p <= q:
        if q % p == 0:
            e = 0
            while q % p == 0:
                q //= p
                e += 1
            return (p, e) if q == 1 else None
        p += 1
    return (q, 1)


def _prime_power_ge(n):
    q = n
    while True:
        r = _is_prime_power(q)
        if r is not None:
            return q, r[0], r[1]
        q += 1


def _bose_chowla(c):
    """Bose-Chowla Sidon set of size q in Z_{q^2-1} (needs prime power q)."""
    q, p, e = _prime_power_ge(c)
    m = q * q - 1
    # build multiplicative generator of F_{q^2}^* mapped through theta -> Z_m
    # Use the standard construction with theta = (x -> x^{q} + x) trick.
    # We work with F_q elem and represent F_{q^2} = F_q[t]/(t^2 - t - g) with g
    # a generator of F_q^* (only valid when q odd gives irreducible + trace).
    # Simpler robust approach: index field element as (a,b)=a+b*t, multiplication
    # in the polynomial basis t^2 = t + g where g primitive in F_q.
    if q == 2:
        # trivial
        return [0]
    # find primitive element g of F_q
    # factor q-1
    fac = []
    x = q - 1
    d = 2
    while d * d <= x:
        if x % d == 0:
            fac.append(d)
            while x % d == 0:
                x //= d
        d += 1
    if x > 1:
        fac.append(x)
    g = None
    for cand in range(2, q):
        if all(pow(cand, (q - 1) // f, q) != 1 for f in fac):
            g = cand
            break
    # check t^2 = t + g is irreducible over F_q: need t^2-t-g no root
    # discriminant 1+4g must be non-residue
    disc = (1 + 4 * g) % q
    if q > 2 and pow(disc, (q - 1) // 2, q) == 1:
        # g wrong parity; bump
        for cand in range(2, q):
            if all(pow(cand, (q - 1) // f, q) != 1 for f in fac):
                g = cand
                disc = (1 + 4 * g) % q
                if pow(disc, (q - 1) // 2, q) != 1:
                    break

    def mul(a, b):
        # (a0 + a1 t)(b0 + b1 t) = a0 b0 + (a0 b1 + a1 b0) t + a1 b1 t^2
        # t^2 = t + g
        r0 = (a[0] * b[0] + a[1] * b[1] * g) % q
        r1 = (a[0] * b[1] + a[1] * b[0] + a[1] * b[1]) % q
        return (r0, r1)

    def trace(a):
        # theta(a) = a + a^q ; a^q = (a0 + a1 t)^q = a0 + a1 t^q (Frobenius),
        # t^q = t + Tr?  Simpler: theta = a + a^q, but here use log via primitive
        return None

    # Standard Bose construction uses theta(x) = x + x^q which lands in F_q.
    # x^q for x=a0+a1 t: since Frobenius fixes F_q and sends t -> t^q.
    # t^q = t + T where T = Tr(t) = 1 (from t^2=t+g, trace of t = 1).
    tq = (1, 1)  # t^q = t + 1 for this normal-ish basis

    def frob(a):
        # a^q = a0 + a1 * t^q
        return (a[0] + a[1] * tq[0], a[1] * tq[1])

    def add(a, b):
        return ((a[0] + b[0]) % q, (a[1] + b[1]) % q)

    # primitive element of F_{q^2}^*
    # find generator alpha
    order = m
    # factor order
    ofac = []
    x = order
    d = 2
    while d * d <= x:
        if x % d == 0:
            ofac.append(d)
            while x % d == 0:
                x //= d
        d += 1
    if x > 1:
        ofac.append(x)

    alpha = None
    for cand in range(1, q * q):
        a = (cand % q, cand // q)
        if a == (0, 0):
            continue
        ok = True
        for f in ofac:
            # a^(order/f)
            pw = (1, 0)
            e2 = order // f
            base = a
            while e2 > 0:
                if e2 & 1:
                    pw = mul(pw, base)
                base = mul(base, base)
                e2 >>= 1
            if pw == (1, 0):
                ok = False
                break
        if ok:
            alpha = a
            break

    # now build powers and take theta -> gives Sidon set in Z_m (via discrete log)
    # We need mapping from element to exponent index; use direct: B = { i : theta(alpha^i) has some value }
    # Standard Bose-Chowla: B = { i : theta(alpha^i) = a for a fixed? } -- instead
    # classic: for i in Z_m, let beta_i with log_alpha of (theta^{-1}?) ...
    # Use well-known equivalent: B = { i in [0,m) : theta(alpha^i) = 1 } is too small.
    # Correct classical: B = { i : theta(alpha^i) = 0 }?  Let's use the concrete
    # construction: B = { log_alpha(alpha^i) }... 
    # Classical Bose set: B = { i : alpha^i - alpha^{i+q?} } ...
    # Fall back to known simple variant: B = { i : theta(alpha^i) is a fixed nonzero }
    # Actually standard: index set { i : theta(alpha^i) = 1 }? no.
    #
    # Use the standard construction directly:
    # B = { i in [0,m) : alpha^i + alpha^{i+q} = 1 } is not size q either.
    #
    # Robust fallback: greedy Sidon is reliable. Build greedy if construction
    # uncertain.
    return None


def _sidon_greedy(n):
    B = []
    sums = set()
    val = 0
    limit = 80 * n * n + 1000
    while len(B) < n and val < limit:
        new = [val + b for b in B] + [2 * val]
        if all(s not in sums for s in new):
            B.append(val)
            sums.update(new)
        val += 1
    return B


def _bose_chowla_set(c):
    """Bose-Chowla Sidon set of size q in Z_{q^2-1} via sqrt-based trick,
    valid for prime q. Implemented through F_{q^2} discrete log."""
    q, p, e = _prime_power_ge(c)
    if e != 1:
        return None
    m = q * q - 1
    # field F_q^2 as pairs (a,b) with t^2 = t + g, g primitive in F_q
    fac = []
    x = q - 1
    d = 2
    while d * d <= x:
        if x % d == 0:
            fac.append(d)
            while x % d == 0:
                x //= d
        d += 1
    if x > 1:
        fac.append(x)
    g = None
    for cand in range(2, q):
        if all(pow(cand, (q - 1) // f, q) != 1 for f in fac):
            g = cand
            break
    if g is None:
        return None

    def mul(a, b):
        r0 = (a[0] * b[0] + a[1] * b[1] * g) % q
        r1 = (a[0] * b[1] + a[1] * b[0] + a[1] * b[1]) % q
        return (r0, r1)

    # primitive generator alpha
    ofac = []
    x = m
    d = 2
    while d * d <= x:
        if x % d == 0:
            ofac.append(d)
            while x % d == 0:
                x //= d
        d += 1
    if x > 1:
        ofac.append(x)

    def order_of(a):
        o = m
        for f in ofac:
            while o % f == 0:
                pw = (1, 0)
                e2 = o // f
                base = a
                while e2 > 0:
                    if e2 & 1:
                        pw = mul(pw, base)
                    base = mul(base, base)
                    e2 >>= 1
                if pw == (1, 0):
                    o //= f
                else:
                    break
        return o

    alpha = None
    for cand in range(1, q * q):
        a = (cand % q, cand // q)
        if a == (0, 0):
            continue
        if order_of(a) == m:
            alpha = a
            break
    if alpha is None:
        return None

    # t^q: Frobenius sends t -> t^q.  t^q = t + Tr(t) = t + 1.
    tq = (1, 1)

    def frob(a):
        return ((a[0] + a[1] * tq[0]) % q, (a[1] * tq[1]) % q)

    def add(a, b):
        return ((a[0] + b[0]) % q, (a[1] + b[1]) % q)

    # Bose-Chowla: B = { i in [0,m) : theta(alpha^i) = 1 }?  Instead use the
    # equivalent formulation: B = { i : alpha^i + alpha^{i*q} = const }.
    # Build set of exponents i such that theta(x) = alpha^i + alpha^{iq} = 1
    # (theta : multiplicative group -> additive F_q). The set {i : theta(alpha^i)=1}
    # is a Sidon set of size q in Z_m.
    # We compute for each exponent i the value theta(alpha^i) and pick those =1.
    result = []
    pw = (1, 0)  # alpha^0
    # precompute alpha^q
    aq = alpha
    for _ in range(q - 1):
        aq = mul(aq, alpha)
    # aq = alpha^q
    for i in range(m):
        # theta = pw + pw^q where pw^q = alpha^{qi}
        pwq = pw
        # compute pw^q via frob
        pwq = frob(pw)
        th = add(pw, pwq)
        if th == (1, 0):
            result.append(i)
        pw = mul(pw, alpha)
    if len(result) == q:
        return result
    return None


def _diffsum_size(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def solve():
    t0 = time.time()
    budget = 110.0

    best = None
    best_score = -1.0

    # Build cores of many sizes.
    cores = {}
    for cn in (3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 18, 20, 24, 28,
               32, 36, 40, 48, 56, 64, 72, 80):
        C = None
        if cn >= 4:
            C = _bose_chowla_set(cn)
        if C is None or len(C) < 3:
            C = _sidon_greedy(cn)
        cores[cn] = C

    # analytic + exact candidate evaluation
    def eval_A(A):
        d, s = _diffsum_size(A)
        if s < 2 or d < 2:
            return -1.0
        return math.log(d) / math.log(s) + (1 - 1 / len(A)) / 100

    candidates = []
    for cn, C in cores.items():
        if len(C) < 3:
            continue
        c = len(C)
        cc_sum = len(set(x + y for x in C for y in C))
        cc_diff = len(set(x - y for x in C for y in C))
        # sweep k; use analytic guess for sizes (sum set size = cc_sum+2k-1,
        # diff = cc_diff+2k-1), pick k maximizing analytic ratio.
        best_k = None
        best_ak = -1.0
        for k in range(1, 4000):
            n = c * k
            if n > 4000 or n < 3:
                continue
            s = cc_sum + 2 * k - 1
            d = cc_diff + 2 * k - 1
            if s < 2 or d < 2:
                continue
            ak = math.log(d) / math.log(s) + (1 - 1 / n) / 100
            if ak > best_ak:
                best_ak = ak
                best_k = k
        if best_k is None:
            continue
        # try a window around best_k
        for k in range(max(1, best_k - 2), best_k + 3):
            n = c * k
            if n > 4000 or n < 3:
                continue
            candidates.append((best_ak, cn, k))

    candidates.sort(reverse=True)
    seen = set()
    for ak, cn, k in candidates:
        if time.time() - t0 > budget:
            break
        if (cn, k) in seen:
            continue
        seen.add((cn, k))
        C = cores[cn]
        A = []
        for x in C:
            for t in range(k):
                A.append(x + t)
        sc = eval_A(A)
        if sc > best_score:
            best_score = sc
            best = A

    if best is None:
        best = [0, 1, 2, 3]

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    return best


# EVOLVE-BLOCK-END
