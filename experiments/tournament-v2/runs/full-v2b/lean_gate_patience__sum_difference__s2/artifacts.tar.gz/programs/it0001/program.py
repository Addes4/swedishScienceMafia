# EVOLVE-BLOCK-START
"""Ruzsa-style construction: A = B + C, with B difference-rich and C sum-poor."""
import math


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(B, C):
    return sorted({b + c for b in B for c in C})


def solve():
    """Maximise log|A-A|/log|A+A| using A = B + C (Ruzsa construction)."""
    best = None
    best_score = -1.0

    # Candidate "sum-poor" small bases C: arithmetic progressions are ideal
    # (|C+C| = 2|C|-1), so A+A is much smaller than A-A when B is spread out.
    Cs = []
    for m in (2, 3, 4, 5, 6, 7, 8):
        Cs.append(list(range(m)))                # 0..m-1
    Cs.append([0, 1, 3])                         # near-AP
    Cs.append([0, 2, 5])                         # sparse but still few sums
    Cs.append([0, 1])

    # Candidate "difference-rich" parts B.
    Bs = []
    # 1) powers of 2 -> all subset sums distinct: huge difference set
    for k in (12, 16, 20, 24, 28, 32):
        Bs.append([1 << i for i in range(k)])
    # 2) dense interval of integers (large difference set, but sums grow)
    for k in (20, 40, 80, 120, 160):
        Bs.append(list(range(k)))
    # 3) product of intervals (scaled) -> many distinct differences
    for a, b in ((8, 12), (10, 16), (12, 20), (14, 24), (16, 28)):
        Bs.append([i * 1000 + j for i in range(a) for j in range(b)])

    seen = set()
    for B in Bs:
        for C in Cs:
            A = _build(B, C)
            if len(A) < 2 or len(A) > 4000:
                continue
            key = (len(A), A[0], A[-1])
            if key in seen:
                continue
            seen.add(key)
            s = _score(A)
            if s > best_score:
                best, best_score = A, s

    if best is None:
        best = [0, 1]
    return best
# EVOLVE-BLOCK-END
