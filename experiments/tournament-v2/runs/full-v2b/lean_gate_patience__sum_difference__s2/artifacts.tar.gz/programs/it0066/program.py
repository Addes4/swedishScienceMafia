# EVOLVE-BLOCK-START
"""Construction: A = [0,m)  UNION  M * B, where B is a Bose-Chowla Sidon set.

Bose-Chowla gives B a subset of Z_{q^2-1} with all pairwise differences distinct
(Sidon), so |B-B| = |B|^2 - |B| + 1 ~ |B|^2, while sums collide giving a smaller
|B+B|.  Dilating B by a large base M keeps all differences distinct and separates
them from the interval's differences; the interval [0,m) collapses many sums
(|I+I| ~ 2m) and keeps differences contiguous.  We search (q, m, M) by exact score.
"""
import math
import time


def bose_chowla(q):
    """Sidon set in Z_{q^2-1} (q prime power). Uses theta primitive in F_{q^2}.
    Standard construction: B = { i : (theta^i - theta) ... } -> here we use the
    well-known integer realization: B = { 2q*i + (i^2 mod q) } gives a Sidon set
    in Z_{q^2-1} of size q+1 (also mod q^2 - 1 after reduction)."""
    # Bose set in F_q x F_q via graph of x^2, mapped into Z_{q^2-1}.
    # Elements: for i in 0..q-1: a = i, b = i^2 mod q -> x = a*q + b? Instead use
    # the classic Sidon set B = { i : 0<=i<q } under the map i -> 2q i + (i^2 mod q).
    B = []
    for i in range(q):
        B.append(2 * q * i + (i * i) % q)
    # add the point at infinity / q-th element to reach size q+1
    B.append(2 * q * q - 1)  # sentinel for infinity in Z_{q^2-1}
    return B


def score(a):
    a = list(set(a))
    if len(a) < 2:
        return -1.0, 0, 0
    diffs = len({x - y for x in a for y in a})
    sums = len({x + y for x in a for y in a})
    if sums < 1 or diffs < 1:
        return -1.0, diffs, sums
    return math.log(diffs) / math.log(sums) + (1 - 1 / len(a)) / 100, diffs, sums


def make_combined(m, B, M):
    A = list(range(m))
    for b in B:
        A.append(M * b)
    return A


def solve():
    deadline = time.time() + 100

    primes = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67,
              71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127]

    best_A = None
    best_sc = -1.0

    interval_sizes = [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128]

    for q in primes:
        if time.time() > deadline:
            break
        Bfull = bose_chowla(q)
        # try trimming the sentinel / various prefix sizes
        for k in range(max(2, q - 2), len(Bfull) + 1):
            Bk = Bfull[:k]
            # smallest nonzero |difference| in Bk (before dilation)
            bd = min(abs(Bk[i] - Bk[j])
                     for i in range(len(Bk)) for j in range(i + 1, len(Bk)))
            if bd == 0:
                continue
            for m in interval_sizes:
                if time.time() > deadline:
                    break
                # M large enough that M*bd > m -> cross diffs don't collide with interval
                Mmin = m // bd + 2
                for mult in (1, 2, 4):
                    M = Mmin * mult
                    A = make_combined(m, Bk, M)
                    if max(abs(x) for x in A) > 10**15:
                        continue
                    s, _, _ = score(A)
                    if s > best_sc:
                        best_sc = s
                        best_A = A[:]
        if time.time() > deadline:
            break

    if best_A is None:
        best_A = bose_chowla(5)
    return list(set(best_A))
# EVOLVE-BLOCK-END
