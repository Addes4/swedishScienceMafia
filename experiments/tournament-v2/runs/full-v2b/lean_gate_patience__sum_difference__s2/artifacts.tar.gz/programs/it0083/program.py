# EVOLVE-BLOCK-START
"""Bose-Chowla Sidon base: for q a prime power, B = {2(q-1)k + ((k^2 mod (q-1))) : k in [0,q-1)}
is a Sidon (B_2) set. Different Sidon families give slightly different additive
concentration; scanning several families/primes and picking the best by exact score
optimizes log|A-A| / log|A+A|."""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _primes_upto(n):
    sieve = bytearray([1]) * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for i in range(2, int(n ** 0.5) + 1):
        if sieve[i]:
            sieve[i*i::i] = bytearray(len(sieve[i*i::i]))
    return [i for i in range(n + 1) if sieve[i]]


def _erdos_turan(p):
    return [2 * p * k + (k * k) % p for k in range(p)]


def _bose_chowla(q):
    # q = prime power; work in GF(q), use modulus m = q - 1 as the "space"
    m = q - 1
    return [2 * m * k + (k * k) % m for k in range(m)]


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    primes = _primes_upto(2000)

    def consider(A):
        nonlocal best, best_score
        if len(A) < 2:
            return
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A

    for p in primes:
        if time.time() > deadline:
            break
        # Bose-Chowla with q = p (prime power), modulus p-1
        if p >= 3:
            B = _bose_chowla(p)
            for shift in [0, 1, 3, 7, 13, 31, 127]:
                consider(sorted(set(x + shift for x in B)))
        # Erdős-Turán
        B = _erdos_turan(p)
        for shift in [0, 1, 3, 7, 13, 31, 127]:
            consider(sorted(set(x + shift for x in B)))

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
