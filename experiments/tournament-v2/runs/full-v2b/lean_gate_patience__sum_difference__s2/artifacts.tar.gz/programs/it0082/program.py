# EVOLVE-BLOCK-START
"""Maximize log|A-A|/log|A+A|.

Approach:
 - Build Sidon-type bases (Erdos-Turan / Bose-Chowla) giving near-max difference.
 - Try structured embeddings (shifted copies, geometric strides) that cause many
   sum collisions while keeping differences spread.
 - Additionally run a randomized greedy local search that directly optimizes the
   exact objective for moderate sizes, keeping the best found.
"""
import math
import time
import random


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _primes_upto(n):
    sieve = bytearray([1]) * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for i in range(2, int(n ** 0.5) + 1):
        if sieve[i]:
            sieve[i*i::i] = bytearray(len(sieve[i*i::i]))
    return [i for i in range(n + 1) if sieve[i]]


def _erdos_turan(p):
    return [2 * p * k + (k * k) % p for k in range(p)]


def _bose_chowla(q):
    # q prime power; use q = p (prime). Sidon mod q^2-1.
    mod = q * q - 1
    return [((k * (q + 1) if False else 0)) for k in range(q)]  # placeholder


def _greedy_sidon(n, rng, limit=20000):
    """Randomized greedy B_2 (Sidon) set of size n."""
    B = []
    sums = set()
    diffs = set()
    while len(B) < n and limit > 0:
        limit -= 1
        x = rng.randrange(1, 4 * n * n)
        ok = True
        new_sums = {x + b for b in B} | {2 * x}
        if new_sums & sums:
            continue
        B.append(x)
        sums |= new_sums
    return B


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    primes = _primes_upto(1200)

    # 1) Erdos-Turan base with shifts (the reliable baseline)
    for p in primes:
        if time.time() > deadline:
            break
        B = _erdos_turan(p)
        for shift in (0, 1, 3, 7, 13, 31, 127):
            A = sorted(set(x + shift for x in B))
            if len(A) < 2:
                continue
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A

    # 2) Union of two copies of a Sidon base with a geometric stride:
    #    A = B union (B*g + c)  -- cross sums may collide more than differences.
    rng = random.Random(12345)
    for p in primes[:40]:
        if time.time() > deadline:
            break
        B = _erdos_turan(p)
        base = list(B)
        for g in (3, 5, 7, 11, 13, 17, 19, 23):
            for c in (1, p, 2 * p, 7, 31):
                A = sorted(set(base) | set(x * g + c for x in base))
                if len(A) < 2:
                    continue
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A

    # 3) Randomized greedy Sidon + folding to reduce sum set
    random.seed(999)
    trials = 0
    while time.time() < deadline and trials < 400:
        trials += 1
        n = rng.randrange(20, 120)
        B = _greedy_sidon(n, rng)
        if len(B) < 5:
            continue
        for shift in (0, 1, 7, 31):
            A = sorted(set(x + shift for x in B))
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A
        # try union with reflected copy
        M = max(B) * 2 + rng.randrange(1, 1000)
        A = sorted(set(B) | set(M - x for x in B))
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
