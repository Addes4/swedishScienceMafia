# EVOLVE-BLOCK-START
"""Construction: A = interval I of length m  UNION scaled Sidon-like set M*Y.

The interval gives many in-range sums (collapsing |A+A|) and contiguous differences.
Scaling Y by large M keeps cross-differences distinct from interval differences and
from each other, boosting |A-A|. We search over (m, |Y|, M) with exact scoring for
moderate sizes where set computation is cheap, and pick the best by real score.
"""
import math
import random
import time


def build_sidon_base(target, seed=12345, time_budget=4.0):
    rng = random.Random(seed)
    deadline = time.time() + time_budget
    best = []
    while time.time() < deadline:
        b = []
        pool = list(range(0, max(64, target * target * 3)))
        rng.shuffle(pool)
        sums = set()
        for v in pool:
            ok = True
            new_sums = []
            for x in b:
                s = x + v
                if s in sums:
                    ok = False
                    break
                new_sums.append(s)
            if ok:
                s = v + v
                if s in sums:
                    ok = False
                else:
                    new_sums.append(s)
            if ok:
                b.append(v)
                sums.update(new_sums)
            if len(b) >= target:
                break
        if len(b) > len(best):
            best = b[:]
    return best


def score(a):
    a = list(set(a))
    if len(a) < 2:
        return -1.0, 0, 0
    diffs = len({x - y for x in a for y in a})
    sums = len({x + y for x in a for y in a})
    if sums < 1:
        return -1.0, diffs, sums
    return math.log(diffs) / math.log(sums) + (1 - 1 / len(a)) / 100, diffs, sums


def make_combined(m, Y, M):
    """A = {0..m-1} U {M*y : y in Y}.
    Shift by -(m//2) later not needed for set cardinalities."""
    A = list(range(m))
    for y in Y:
        A.append(M * y)
    return A


def solve():
    deadline = time.time() + 100

    # Build a reasonably large Sidon-like set once.
    Y = build_sidon_base(60, seed=2024, time_budget=8.0)
    if len(Y) < 2:
        Y = [0, 1, 3]

    best_A = None
    best_sc = -1.0

    # Search interval sizes and multipliers.
    m_candidates = [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64]
    # The scaled set contributes |Y| elements. Try trimming Y to various sizes.
    y_max = len(Y)

    for m in m_candidates:
        if time.time() > deadline:
            break
        for k in range(1, y_max + 1):
            if time.time() > deadline:
                break
            Yk = Y[:k]
            # M must be large enough to separate cross differences from intervals.
            # cross diff M*(y_i - y_j) + (i - j): need |M*(min nonzero y-diff)| > m
            yd = sorted({abs(Yk[i] - Yk[j]) for i in range(len(Yk)) for j in range(i + 1, len(Yk))})
            if yd:
                Mmin = (m + 2) // max(1, yd[0]) + 1
            else:
                Mmin = 2
            for M in {Mmin, Mmin + 1, Mmin * 2, Mmin + m + 1}:
                if M < 1:
                    continue
                A = make_combined(m, Yk, M)
                if max(abs(x) for x in A) > 10**15:
                    continue
                s, _, _ = score(A)
                if s > best_sc:
                    best_sc = s
                    best_A = A[:]

    # Also try pure scaled Sidon (interval length 0 cases covered by m=1).
    # Try a two-layer dilation for larger |A-A|: Y embedded as base-M powers.
    for k in range(2, y_max + 1):
        if time.time() > deadline:
            break
        Yk = Y[:k]
        yd = sorted({abs(Yk[i] - Yk[j]) for i in range(len(Yk)) for j in range(i + 1, len(Yk))})
        if not yd:
            continue
        M = yd[-1] + 1
        A = [Yk[i] * (M ** i) for i in range(k)]
        if max(abs(x) for x in A) > 10**15:
            continue
        s, _, _ = score(A)
        if s > best_sc:
            best_sc = s
            best_A = A[:]

    if best_A is None:
        best_A = [0, 1, 3, 7]
    return list(set(best_A))
# EVOLVE-BLOCK-END
