"""Approach: structured 'digit-sum' sets (numbers with exactly k ones in binary)
have small sum sets and large difference sets. To evaluate many/large candidates
fast, score with numpy bitset shifts instead of O(n^2) Python sets. Scan a wide
range of (m, k), including larger sets up to the 4000 limit, plus multi-scale
Kronecker constructions A = B + t*C and small dilations, and pick the best."""
import math
import time
from itertools import combinations
import numpy as np


def _bitset_pair(a):
    """Given list of ints, return counts of distinct differences and sums using
    numpy bit packing."""
    a = np.array(sorted(set(a)), dtype=np.int64)
    n = a.shape[0]
    dmin = int(a[0] - a[-1])
    dmax = int(a[-1] - a[0])
    smin = int(a[0] + a[0])
    smax = int(a[-1] + a[-1])

    def make_bits(vals, lo, hi):
        width = hi - lo + 1
        words = (width + 63) // 64
        bits = np.zeros(words, dtype=np.int64)
        idx = vals - lo
        w = idx >> 6
        b = idx & 63
        np.bitwise_or.at(bits, w, (np.int64(1) << b).astype(np.int64))
        return bits

    diff = (a[:, None] - a[None, :]).ravel()
    dbits = make_bits(diff.astype(np.int64), dmin, dmax)
    ndistinct_d = int(np.unpackbits(dbits.view(np.uint8)).sum())

    ssum = (a[:, None] + a[None, :]).ravel()
    sbits = make_bits(ssum.astype(np.int64), smin, smax)
    ndistinct_s = int(np.unpackbits(sbits.view(np.uint8)).sum())

    return ndistinct_d, ndistinct_s


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _bitset_pair(a)
    if ns <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _digit_set(m, k):
    out = []
    for comb in combinations(range(m), k):
        v = 0
        for b in comb:
            v |= (1 << b)
        out.append(v)
    return out


def _digit_set_complement(m, k):
    """Numbers with exactly m-k ones among m bits = bitwise complement within m bits."""
    full = (1 << m) - 1
    return [full ^ v for v in _digit_set(m, m - k)]


def solve():
    deadline = time.time() + 100
    best = None
    best_s = -1.0
    NMAX = 4000
    LIMIT = 10**15

    def okay(A):
        return len(A) >= 2 and max(abs(v) for v in A) <= LIMIT

    def consider(A):
        nonlocal best, best_s
        A = sorted(set(A))
        n = len(A)
        if n < 2 or n > NMAX or not okay(A):
            return
        s = _score(A)
        if s > best_s:
            best_s = s
            best = A

    base_sets = []
    # Digit-sum sets: numbers with exactly k ones in m bits.
    for m in range(6, 30):
        for k in range(1, m):
            size = math.comb(m, k)
            if size < 2 or size > NMAX:
                continue
            base_sets.append(_digit_set(m, k))
        if time.time() > deadline:
            break

    # Rank base sets by individual score (cheap-ish), keep a few good ones.
    scored_bases = []
    for A in base_sets:
        A = sorted(set(A))
        if len(A) < 2 or len(A) > NMAX or not okay(A):
            continue
        s = _score(A)
        if s > best_s:
            best_s = s
            best = A
        scored_bases.append((s, A))
        if time.time() > deadline:
            break

    scored_bases.sort(key=lambda x: -x[0])

    # Multi-scale Kronecker constructions: A = B + t*C for good small base sets.
    # Focus on small B, C so product stays within NMAX.
    small_sets = [(s, A) for (s, A) in scored_bases if 2 <= len(A) <= 60]
    tries = 0
    for si, B in small_sets:
        if time.time() > deadline:
            break
        for sj, C in small_sets:
            if time.time() > deadline:
                break
            nb, nc = len(B), len(C)
            if nb * nc > NMAX or nb * nc < 2:
                continue
            for t in (4, 8, 16, 32, 64):
                A = [b + t * c for b in B for c in C]
                if len(A) > NMAX:
                    continue
                consider(A)
                tries += 1
                if tries % 200 == 0 and time.time() > deadline:
                    break

    # Dilations of the best set: |A+A| and |A-A| unchanged, keeps bonus same,
    # but combining with an offset can paddle the size bonus on ties.
    if best is not None:
        base_best = list(best)
        for mult in (1, 2, 3, 5, 7, 11):
            for off in (0, 1, -1):
                cand = [mult * v + off for v in base_best]
                if max(abs(v) for v in cand) > LIMIT:
                    continue
                consider(cand)
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break

    return best if best else [0, 1]
