# EVOLVE-BLOCK-START
"""Erdos-Turan style Sidon set with a tunable scaling factor.

A = {k*x + (x^2 mod p) : x in [0,p)} for prime p and small integer k.
Varying k changes how differences and sums collide, letting exact scoring
pick the best ratio rather than relying on a fixed k=2p.
"""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _build(p, k, cap=4000):
    """A = {k*x + (x*x mod p)} reduced to distinct integers."""
    seen = set()
    out = []
    for x in range(p):
        v = k * x + (x * x) % p
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # primes from moderate to ~800 (n up to ~800 keeps scoring fast enough)
    cand = [x for x in range(2, 801) if _is_prime(x)]

    for p in cand:
        if time.time() > deadline:
            break
        # try scaling factors: k must be large enough to separate cross terms
        ks = [p, 2 * p - 1, 2 * p, 2 * p + 1, p * p // 2, p * p - 1]
        for k in ks:
            if k <= 0:
                continue
            A = _build(p, k)
            n = len(A)
            if n < 2 or n > 4000:
                continue
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A
    if best is None:
        best = _build(200, 400, 4000)
    return best
# EVOLVE-BLOCK-END
