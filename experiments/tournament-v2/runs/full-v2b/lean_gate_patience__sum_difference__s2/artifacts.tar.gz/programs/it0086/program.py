# EVOLVE-BLOCK-START
"""Directly optimize the objective log|A-A|/log|A+A| (+ size bonus) with a greedy
bitset-based local search. We track exact sum/difference sets as Python ints used as
bitsets, and add or swap elements to maximize the score."""
import time


def _score(A):
    n = len(A)
    if n < 2:
        return -1.0
    s = set()
    d = set()
    for i in range(n):
        ai = A[i]
        for j in range(i, n):
            s.add(ai + A[j])
        for j in range(n):
            d.add(ai - A[j])
    ls = len(s)
    ld = len(d)
    if ls < 2:
        return -1.0
    import math
    val = math.log(ld) / math.log(ls)
    val += (1.0 - 1.0 / n) / 100.0
    return val


def _sums_diffs_count(A, lo, hi):
    """Return (len(A+A), len(A-A)) using bytearray bitsets over the given offset range."""
    n = len(A)
    span = hi - lo + 1
    sb = bytearray(span)
    db = bytearray(2 * span)
    off = span  # index shift for differences
    for i in range(n):
        ai = A[i]
        for j in range(i, n):
            sb[ai + A[j] - lo] = 1
        for j in range(n):
            db[ai - A[j] + off] = 1
    return sum(sb), sum(db)


def solve():
    import random
    import math
    deadline = time.time() + 100.0
    rng = random.Random(987654321)

    # Seed set: a bounded interval gives dense sums; adding spread elements boosts differences.
    n0 = 60
    A = list(range(0, n0))
    step = 4000
    for k in range(1, 40):
        A.append(n0 - 1 + k * step)
    A = sorted(set(A))

    # Candidate pool for additions: spread-out integers.
    pool_lo, pool_hi = 0, 200000
    pool = [rng.randint(pool_lo, pool_hi) for _ in range(600)]

    def full_eval(S):
        S = sorted(set(S))
        if len(S) < 2:
            return -1.0, S, 0, 0
        lo = min(S)
        hi = max(S)
        return _score(S), S, lo, hi

    best_val, A, lo, hi = full_eval(A)

    # Greedy addition phase: add elements from the pool that improve the score.
    improved = True
    while improved and time.time() < deadline:
        improved = False
        cur_val = best_val
        cur_S = set(A)
        best_add = None
        best_add_val = cur_val
        for c in pool:
            if c in cur_S:
                continue
            cand = A + [c]
            v = _score(cand)
            if v > best_add_val:
                best_add_val = v
                best_add = c
        if best_add is not None:
            A = sorted(set(A + [best_add]))
            best_val = best_add_val
            improved = True

    # Swap / local-search: try replacing an element to improve.
    while time.time() < deadline:
        cur_val = best_val
        cur_set = set(A)
        best_swap = None
        best_swap_val = cur_val
        for i in range(len(A)):
            base = A[:i] + A[i + 1:]
            for c in rng.sample(pool, 40):
                if c in cur_set:
                    continue
                v = _score(base + [c])
                if v > best_swap_val:
                    best_swap_val = v
                    best_swap = (i, c)
        if best_swap is not None:
            i, c = best_swap
            A = A[:i] + A[i + 1:] + [c]
            A = sorted(set(A))
            best_val = best_swap_val
        else:
            break

    return sorted(set(A))
# EVOLVE-BLOCK-END

