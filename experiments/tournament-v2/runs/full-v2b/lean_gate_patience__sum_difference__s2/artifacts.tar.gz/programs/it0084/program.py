# EVOLVE-BLOCK-START
"""Sidon-base geometric construction: build a B_2 set, embed it into integers via a huge base
multiplier so that sums stay as small as possible (from B_2) and differences stay maximally large."""
import math
import random
import time


def _is_sidon(B):
    """Check that all pairwise sums b_i + b_j (i <= j) are distinct."""
    seen = set()
    n = len(B)
    for i in range(n):
        bi = B[i]
        for j in range(i, n):
            s = bi + B[j]
            if s in seen:
                return False
            seen.add(s)
    return True


def _greedy_sidon(limit, rng):
    """Randomized greedy Sidon set: a B_2 set where all pairwise sums are distinct.
    This minimizes |B+B| ~ n^2/2."""
    B = []
    used_sums = set()
    candidates = list(range(0, limit))
    rng.shuffle(candidates)
    for c in candidates:
        ok = True
        add = []
        for b in B:
            s = b + c
            if s in used_sums:
                ok = False
                break
            add.append(s)
        s2 = c + c
        if s2 in used_sums:
            ok = False
        if ok:
            add.append(s2)
            for s in add:
                used_sums.add(s)
            B.append(c)
        if len(B) >= 900:
            break
    return B


def solve():
    """Return distinct integers A with |A-A| large and |A+A| small; maximize
    log|A-A|/log|A+A| plus a small size bonus."""
    rng = random.Random(12345)

    # Build a base Sidon set B (all pairwise sums distinct -> |B+B| = n(n+1)/2).
    # Use a moderate limit: a denser B_2 set keeps sums compact while still Sidon.
    best_B = []
    deadline = time.time() + 30.0
    attempts = 0
    while time.time() < deadline and attempts < 40:
        attempts += 1
        limit = 4000
        B = _greedy_sidon(limit, rng)
        if len(B) > len(best_B):
            best_B = B

    B = best_B
    n = len(B)
    if n < 2:
        return [0, 1]

    # Embed B into integers via positional (geometric) expansion in a large base M.
    # A choice b_i -> sum over coordinates b_i * M^i makes all A-A differences distinct
    # (maximally large difference set) while the sum set structure inherits the Sidon
    # property of B: |A+A| stays near the minimal n(n+1)/2 value.
    # M must exceed 2*max(B) so digit carries cannot collapse distinct sums.
    maxB = max(B)
    M = 2 * maxB + 1

    # To keep integers within |a| <= 1e15, cap the number of coordinates.
    # With values of size maxB (< limit) and base M ~ 8001, choose exponent count so
    # M^(k-1) * maxB <= 1e15.  M ~ 8001 -> M^5 ~ 3.3e19 too big; M^4 ~ 4.1e15.
    # So limit coordinates to k=5, which bounds magnitudes ~ 8001^4 * 4000 ~ 1.6e19... trim.
    # Recompute a safe k by magnitude.
    k = 0
    mag = 1
    while k < n:
        if mag > 1e15 // max(1, maxB):
            break
        mag *= M
        k += 1
    k = max(2, min(k, n))

    # Randomly select which k base elements to use as coordinate weights, trying a few subsets
    # to maximize the resulting ratio. Actually use all if k==n; else take a spread subset.
    idx = list(range(n))
    rng.shuffle(idx)
    chosen = idx[:k]
    chosen.sort()
    weights = [B[i] for i in chosen]

    # Ensure distinctness of weights contributions; build A.
    A = []
    for i in range(k):
        A.append(weights[i] * (M ** i))
    A = sorted(set(A))
    return A
# EVOLVE-BLOCK-END
