import math
import random
import time


def _score(nd, ns, n):
    if ns < 2 or nd < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100


def solve():
    deadline = time.time() + 110
    best_A = []
    best_sc = -1.0

    # ---- Greedy incremental construction, directly maximizing the ratio ----
    # For each candidate, we compute the new diff/sum counts incrementally.
    rng = random.Random(12345)

    # A pool of candidate values to consider. We explore a spread of magnitudes.
    def build_greedy(seed_vals, pool):
        A = list(seed_vals)
        A = sorted(set(A))
        # current diff and sum multisets-counters via sets
        dset = {x - y for x in A for y in A}
        sset = {x + y for x in A for y in A}
        nd = len(dset)
        ns = len(sset)
        cur = _score(nd, ns, len(A))
        improved = True
        while improved and time.time() < deadline:
            improved = False
            best_local = None
            best_local_sc = cur
            cands = pool[:]
            rng.shuffle(cands)
            # sample to stay in budget
            limit = 400
            for c in cands[:limit]:
                if time.time() > deadline:
                    break
                if c in A:
                    continue
                nd_new = nd
                ns_new = ns
                d_add = 0
                # new differences: c - x and x - c
                seen_d = set()
                for x in A:
                    v1 = c - x
                    v2 = x - c
                    if v1 not in dset and v1 not in seen_d:
                        seen_d.add(v1)
                    if v2 not in dset and v2 not in seen_d:
                        seen_d.add(v2)
                # c - c = 0 always in dset (since x-x=0)
                d_add = len(seen_d)
                s_seen = set()
                for x in A:
                    v = c + x
                    if v not in sset and v not in s_seen:
                        s_seen.add(v)
                cc = c + c
                if cc not in sset and cc not in s_seen:
                    s_seen.add(cc)
                s_add = len(s_seen)
                nd_new = nd + d_add
                ns_new = ns + s_add
                sc = _score(nd_new, ns_new, len(A) + 1)
                if sc > best_local_sc + 1e-12:
                    best_local_sc = sc
                    best_local = (c, nd_new, ns_new, d_add, s_add)
            if best_local is not None:
                c, nd, ns, _, _ = best_local
                A.append(c)
                A.sort()
                # recompute exact sets to avoid drift
                dset = {x - y for x in A for y in A}
                sset = {x + y for x in A for y in A}
                nd = len(dset)
                ns = len(sset)
                cur = _score(nd, ns, len(A))
                improved = True
        return A, cur

    # Build pools of different magnitudes.
    pools = [
        list(range(-40, 41)),
        list(range(-200, 201, 2)),
        list(range(-1000, 1001, 7)),
    ]

    seeds = [
        [0],
        [0, 1],
        [0, 1, 3],
        [0, 1, 3, 7],
    ]

    for seed in seeds:
        if time.time() > deadline - 10:
            break
        for pool in pools:
            if time.time() > deadline - 10:
                break
            A, sc = build_greedy(seed, pool)
            if sc > best_sc:
                best_sc = sc
                best_A = A[:]

    if not best_A:
        best_A = [0, 1, 3, 7, 12, 20]
    return sorted(set(best_A))
