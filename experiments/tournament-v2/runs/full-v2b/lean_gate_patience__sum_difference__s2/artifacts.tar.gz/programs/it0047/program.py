# EVOLVE-BLOCK-START
"""Construction: A = C + [0,k), C a small Sidon-like core.
  A + A = (C+C) + [0,2k)  -> size ~ |C+C| + 2k  (sums collide heavily)
  A - A = (C-C) + [-k,k)  -> size ~ |C-C| + 2k
With C Sidon, |C+C| ~ |C|^2/2 and |C-C| ~ |C|^2, so ratios are far apart.
Pick k near-balancing to maximize log(d)/log(s) with the size bonus, sweeping
fine k granularity analytically rather than blindly."""
import math
import time


def _sidon_greedy(n):
    """Greedy Sidon set: all pairwise sums (incl. doubles) distinct."""
    B = []
    sums = set()
    val = 0
    limit = 60 * n * n + 500
    while len(B) < n and val < limit:
        new = [val + b for b in B] + [2 * val]
        if all(s not in sums for s in new):
            B.append(val)
            sums.update(new)
        val += 1
    return B


def _diffsum_size(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def solve():
    t0 = time.time()
    budget = 110.0

    best = None
    best_score = -1.0

    # Build a range of Sidon cores.
    cores = {}
    for cn in (3, 4, 5, 6, 7, 8, 10, 12, 14, 16, 20, 24, 28, 32, 40, 50, 60):
        cores[cn] = _sidon_greedy(cn)

    for cn, C in cores.items():
        if len(C) < 3:
            continue
        scale = max(1, 4 * cn)
        Cscaled = [c * scale for c in C]
        # analytic sizes
        cc_sum = len(set(x + y for x in C for y in C))
        cc_diff = len(set(x - y for x in C for y in C))
        # k sweep: fine near the balanced point, coarse wide
        ks = set()
        # balance guess: 2k ~ (cc_diff - cc_sum) keeps exponents tuned
        for base in (cc_sum // 2, cc_sum, cc_diff // 2, cc_diff,
                     (cc_diff - cc_sum) // 2 + 1):
            if base < 1:
                base = 1
            for m in (1, 2, 4, 8, 16, 32, 64):
                ks.add(max(1, base * m // 4))
        ks.update([1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048])
        for k in sorted(ks):
            if k < 1:
                continue
            size = len(Cscaled) * k
            if size > 4000 or size < 3:
                continue
            A = []
            for c in Cscaled:
                for t in range(k):
                    A.append(c + t)
            if time.time() - t0 > budget:
                break
            d, s = _diffsum_size(A)
            if s < 2 or d < 2:
                continue
            sc = math.log(d) / math.log(s) + (1 - 1 / len(A)) / 100
            if sc > best_score:
                best_score, best = sc, A

    if best is None:
        best = [0, 1, 2, 3]

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    return best


# EVOLVE-BLOCK-END
