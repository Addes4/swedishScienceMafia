"""Approach: seed from digit-sum sets then run a time-bounded local search
(greedy hill-climbing with perturbations) using an exact numpy bitset scorer
to squeeze extra ratio out of the structured construction."""
import math
import time
import random
from itertools import combinations
import numpy as np


def _bitset_pair(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    n = a.shape[0]
    dmin = int(a[0] - a[-1]); dmax = int(a[-1] - a[0])
    smin = int(a[0] + a[0]); smax = int(a[-1] + a[-1])

    def make_bits(vals, lo, hi):
        width = hi - lo + 1
        words = (width + 63) // 64
        bits = np.zeros(words, dtype=np.int64)
        idx = vals - lo
        w = idx >> 6
        b = idx & 63
        np.bitwise_or.at(bits, w, (np.int64(1) << b).astype(np.int64))
        return bits

    diff = (a[:, None] - a[None, :]).ravel()
    dbits = make_bits(diff.astype(np.int64), dmin, dmax)
    nd = int(np.unpackbits(dbits.view(np.uint8)).sum())

    ssum = (a[:, None] + a[None, :]).ravel()
    sbits = make_bits(ssum.astype(np.int64), smin, smax)
    ns = int(np.unpackbits(sbits.view(np.uint8)).sum())
    return nd, ns


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _bitset_pair(a)
    if ns <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _digit_set(m, k):
    out = []
    for comb in combinations(range(m), k):
        v = 0
        for b in comb:
            v |= (1 << b)
        out.append(v)
    return out


def solve():
    random.seed(12345)
    deadline = time.time() + 100
    best = None
    best_s = -1.0
    NMAX = 4000

    def consider(A):
        nonlocal best, best_s
        A = sorted(set(A))
        n = len(A)
        if n < 2 or n > NMAX:
            return -1.0
        s = _score(A)
        if s > best_s:
            best_s = s
            best = A
        return s

    # Seed: digit-sum sets.
    for m in range(6, 30):
        for k in range(1, m):
            size = math.comb(m, k)
            if size < 2 or size > NMAX:
                continue
            consider(_digit_set(m, k))
        if time.time() > deadline - 40:
            break

    if best is None:
        return [0, 1]

    # Local search: perturb the best set.
    cur = list(best)
    cur_s = best_s
    span = max(cur) - min(cur)
    step = max(1, span // (len(cur) + 1))
    while time.time() < deadline:
        cand = list(cur)
        # perturb one or a few elements
        t = random.randint(1, 3)
        used = set(cand)
        for _ in range(t):
            i = random.randrange(len(cand))
            old = cand[i]
            delta = random.choice([-step, step, -1, 1,
                                   random.randint(-3 * step, 3 * step)])
            nv = old + delta
            if nv in used:
                continue
            used.discard(old)
            used.add(nv)
            cand[i] = nv
        # candidate size may be off the 4000 limit only if grew; keep same size
        s = _score(cand)
        if s > cur_s:
            cur_s = s
            cur = cand
            if s > best_s:
                best_s = s
                best = sorted(cand)

    return best
