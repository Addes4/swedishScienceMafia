import time
import math
import random
import numpy as np


def _final_score(A):
    n = len(A)
    if n < 2:
        return -1.0, 0, 0
    a = np.array(sorted(A), dtype=np.int64)
    nd = int(np.unique(np.subtract.outer(a, a)).size)
    ns = int(np.unique(np.add.outer(a, a)).size)
    if ns < 2 or nd < 2:
        return -1.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100, nd, ns


def _mode_val(nd, ns, mode):
    if ns <= 1:
        return -1e18
    if mode == 'log':
        return math.log(nd) / math.log(ns)
    if mode == 'ratio':
        return nd / float(ns)
    # penalize sums more strongly to push ns down
    return math.log(nd) / (math.log(ns) ** 1.3)


def _greedy(pool, n_target, mode, deadline, per_step=250):
    A = [0]
    Aset = {0}
    D = {0}
    S = {0}
    while len(A) < n_target and time.time() < deadline:
        if len(pool) > per_step:
            cand = random.sample(pool, per_step)
        else:
            cand = pool
        best = None
        bestval = -1e18
        bD = bS = None
        for c in cand:
            if c in Aset:
                continue
            addD = set()
            for x in A:
                d = c - x
                if d not in D:
                    addD.add(d)
                d2 = x - c
                if d2 not in D:
                    addD.add(d2)
            nd = len(D) + len(addD)
            addS = set()
            for x in A:
                s = c + x
                if s not in S:
                    addS.add(s)
            if c + c not in S:
                addS.add(c + c)
            ns = len(S) + len(addS)
            v = _mode_val(nd, ns, mode)
            if v > bestval:
                bestval = v
                best = c
                bD = addD
                bS = addS
        if best is None:
            break
        A.append(best)
        Aset.add(best)
        D |= bD
        S |= bS
    return A


def _polish(A, pool, deadline, best_sc):
    # Fast numpy-scored local moves: add one element, or swap one element.
    A = list(A)
    sc, nd, ns = _final_score(A)
    if sc > best_sc:
        best_sc = sc
    pool_arr = pool
    while time.time() < deadline:
        improved = False
        # try adding the single best element from a sample
        cand = random.sample(pool_arr, min(len(pool_arr), 60))
        for c in cand:
            if c in A:
                continue
            B = A + [c]
            s2, _, _ = _final_score(B)
            if s2 > sc:
                A = B
                sc = s2
                improved = True
                break
        if improved:
            continue
        # try swapping an element
        if len(A) >= 3:
            i = random.randrange(len(A))
            c = random.choice(cand)
            if c in A:
                continue
            B = A[:]
            B[i] = c
            if len(set(B)) != len(B):
                continue
            s2, _, _ = _final_score(B)
            if s2 > sc:
                A = B
                sc = s2
                improved = True
        # occasional removal move (an element may add more sums than diffs)
        if len(A) >= 4:
            i = random.randrange(len(A))
            B = A[:i] + A[i + 1:]
            s2, _, _ = _final_score(B)
            if s2 > sc:
                A = B
                sc = s2
                improved = True
        if not improved:
            # small random jump to escape
            if len(A) < 4000:
                c = random.choice(cand)
                if c not in A:
                    B = A + [c]
                    if max(abs(x) for x in B) <= 10 ** 15:
                        A = B
                        sc, _, _ = _final_score(A)
        if sc > best_sc:
            best_sc = sc
    return A, best_sc


def solve():
    deadline = time.time() + 115
    best_A = []
    best_sc = -1.0

    # fallback structured seed (union of translated Sidon-like blocks)
    seed = [0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 96, 122, 147, 181, 203, 251, 289,
            360, 372, 448, 469, 560, 595, 680, 720, 890, 963]
    sc0, _, _ = _final_score(seed)
    if sc0 > best_sc:
        best_sc, best_A = sc0, seed[:]

    configs = [
        (2000, 120, 'log', 260),
        (4000, 200, 'log', 240),
        (4000, 180, 'ratio', 240),
        (1500, 90, 'pen', 300),
        (6000, 300, 'log', 200),
        (1000, 70, 'pen', 320),
        (8000, 350, 'log', 180),
    ]

    for R, nt, mode, per in configs:
        if time.time() > deadline - 5:
            break
        pool = list(range(0, R))
        A = _greedy(pool, nt, mode, min(time.time() + 12, deadline - 5), per_step=per)
        if len(A) < 3:
            continue
        sc, _, _ = _final_score(A)
        if sc > best_sc:
            best_sc, best_A = sc, A[:]

    # Polish the best set(s) with remaining time
    if best_A:
        pool = list(range(0, max(3000, max(best_A) + 2000)))
        while time.time() < deadline - 2:
            A2, sc2 = _polish(best_A, pool, time.time() + 4, best_sc)
            if sc2 > best_sc:
                best_sc, best_A = sc2, A2[:]

    if not best_A:
        best_A = [0, 1, 3, 7, 12, 20]

    # safety: clamp bounds and deduplicate
    out = [int(x) for x in sorted(set(best_A))]
    lim = 10 ** 15
    out = [x for x in out if abs(x) <= lim][:4000]
    return out
