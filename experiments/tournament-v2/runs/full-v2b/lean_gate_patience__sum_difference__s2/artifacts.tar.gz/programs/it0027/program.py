# EVOLVE-BLOCK-START
"""Construct A with many additive collisions mod p but spread-out differences."""
import math
import random
import time

try:
    import numpy as np
except Exception:
    np = None


def _stats(a):
    s = list(set(a))
    n = len(s)
    if n < 2:
        return -1.0, 0, 0
    if np is not None:
        arr = np.array(s, dtype=np.int64)
        diffs = np.subtract.outer(arr, arr).ravel()
        sums = np.add.outer(arr, arr).ravel()
        nd = int(np.unique(diffs).size)
        ns = int(np.unique(sums).size)
    else:
        diffs = set()
        sums = set()
        for x in s:
            for y in s:
                diffs.add(x - y)
                sums.add(x + y)
        nd = len(diffs)
        ns = len(sums)
    if ns <= 1 or nd <= 1:
        return -1.0, nd, ns
    score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return score, nd, ns


def _score(a):
    return _stats(a)[0]


def _is_prime(x):
    if x < 2:
        return False
    if x % 2 == 0:
        return x == 2
    i = 3
    while i * i <= x:
        if x % i == 0:
            return False
        i += 2
    return True


def _primes_below(n):
    res = []
    for x in range(n, 2, -1):
        if _is_prime(x):
            res.append(x)
    return res


def _construction(p, M, c=1, d=1, shift=0):
    # A = { shift + c*i + M * ((i*i) % p) : i in 0..p-1 }
    A = []
    for i in range(p):
        A.append(shift + c * i + M * ((i * i) % p) % (M * (p + 1)))
    return A


def _construction2(p, M, a=1, b=0):
    # A = { a*i*i + b*i + M*(i % p) ... alternate: use quadratic mod p in exponent
    A = []
    for i in range(p):
        A.append(a * i * i + b * i + M * ((i * i * i) % p))
    return A


def _greedy_refine(a, deadline):
    """Simple replace-based hill climb on exact score."""
    cur = sorted(set(a))
    if len(cur) < 4:
        return cur, -1.0
    cur_score = _score(cur)
    best, best_score = cur[:], cur_score
    lo = min(cur)
    hi = max(cur)
    span = max(1, (hi - lo) // 2)

    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-span, span)
        cand = sorted(set(cand))
        if len(cand) < 4:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.02:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    random.seed(1234567)
    start = time.time()
    deadline = start + 110

    best = None
    best_score = -1.0

    primes = _primes_below(400)
    candidates = []

    # Family 1: i*c + M*(i^2 mod p)
    for p in primes:
        if p < 5:
            continue
        for Mc in (1, 2, 3, 5, 8):
            M = max(p, 1) * Mc
            for c in (1,):
                cand = _construction(p, M, c=c, shift=0)
                candidates.append(cand)

    # Family 2: cubic residue construction
    for p in primes:
        if p < 5:
            continue
        for Mc in (1, 2, 3):
            M = p * Mc
            cand = _construction2(p, M, a=1 if random.random() < 0.5 else 2, b=1)
            candidates.append(cand)

    for cand in candidates:
        if time.time() > deadline - 6:
            break
        cand = sorted(set(cand))
        if len(cand) < 4:
            continue
        s = _score(cand)
        if s > best_score:
            best, best_score = cand[:], s

    if best is None:
        best = list(range(1, 60))
        best_score = _score(best)

    # A few short refinements on the best-so-far.
    for _ in range(8):
        if time.time() > deadline - 1.0:
            break
        sub = min(deadline - 0.5, time.time() + 3.0)
        c, sc = _greedy_refine(best, sub)
        if sc > best_score:
            best, best_score = c, sc

    # Final long refine
    if time.time() < deadline - 1.0:
        sub = deadline - 0.5
        c, sc = _greedy_refine(best, sub)
        if sc > best_score:
            best, best_score = c, sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
