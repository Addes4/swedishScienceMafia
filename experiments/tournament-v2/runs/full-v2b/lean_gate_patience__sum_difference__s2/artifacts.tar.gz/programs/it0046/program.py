# EVOLVE-BLOCK-START
"""Construction: A = C + [0,k) where C is a Sidon-like core (pairwise sums distinct).
Then A+A = (C+C) + [0,2k) (size ~ |C+C| + 2k) and A-A = (C-C) + [-k,k) (size ~ |C-C| + 2k).
With C Sidon, |C+C| ~ |C|^2/2 and |C-C| ~ |C|^2, so differences dominate sums.
We choose k analytically around the balanced point 2k ~ |C+C| to maximize the log ratio,
then do a bounded local refinement directly on the objective."""
import math
import random


def _sidon_greedy(n, rng):
    """Greedy Sidon set: all pairwise sums (incl. doubles) distinct."""
    B = []
    sums = set()
    val = 0
    # generous limit so we can reach n elements
    limit = 4 * n * n + 200
    while len(B) < n and val < limit:
        new = [val + b for b in B] + [2 * val]
        ok = True
        for s in new:
            if s in sums:
                ok = False
                break
        if ok:
            B.append(val)
            sums.update(new)
        val += 1
    return B


def _diffsum_size(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score_from_sizes(d, s, n):
    if s < 2 or d < 2:
        return -1.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _build_Cs(rng):
    cores = {}
    for cn in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 30, 40, 50):
        C = _sidon_greedy(cn, rng)
        if len(C) >= 2:
            cores[len(C)] = C
    return cores


def solve():
    rng = random.Random(20240607)
    cores = _build_Cs(rng)

    best = None
    best_score = -1.0

    for cn, C in cores.items():
        if cn < 2:
            continue
        # scale core so that the interval sits below inter-core gaps
        scale = max(1, 4 * cn)
        Cscaled = [c * scale for c in C]
        ccsize = len(set(x + y for x in Cscaled for y in Cscaled))
        # balanced point: 2k ~ |C+C|
        kmax = max(1, min(3999 // cn, (ccsize // 2) + 40))
        candidates = set()
        for base in (ccsize // 2, ccsize // 3, ccsize, cn, kmax):
            for delta in (-40, -20, -8, -3, -1, 0, 1, 3, 8, 20, 40):
                kk = base + delta
                if 1 <= kk <= kmax:
                    candidates.add(kk)
        for k in candidates:
            size = cn * k
            if size < 2 or size > 4000:
                continue
            A = []
            for c in Cscaled:
                for t in range(k):
                    A.append(c + t)
            A = sorted(set(A))
            d, s = _diffsum_size(A)
            sc = _score_from_sizes(d, s, len(A))
            if sc > best_score:
                best_score, best = sc, A

    if best is None:
        best = [0, 1, 2, 3]

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]

    # Bounded local refinement: try shifting the whole set (doesn't change score)
    # and try trimming endpoints to slightly reduce sums while keeping differences.
    improved = True
    rounds = 0
    while improved and rounds < 6:
        improved = False
        rounds += 1
        cur_d, cur_s = _diffsum_size(best)
        cur_sc = _score_from_sizes(cur_d, cur_s, len(best))
        # try removing one element from each end
        for cut in (1,):
            cand = best[cut:]
            if len(cand) >= 2:
                d, s = _diffsum_size(cand)
                sc = _score_from_sizes(d, s, len(cand))
                if sc > cur_sc:
                    best = cand
                    cur_sc = sc
                    improved = True
                    break
            cand = best[:-cut]
            if len(cand) >= 2:
                d, s = _diffsum_size(cand)
                sc = _score_from_sizes(d, s, len(cand))
                if sc > cur_sc:
                    best = cand
                    cur_sc = sc
                    improved = True
                    break

    return best


# EVOLVE-BLOCK-END
