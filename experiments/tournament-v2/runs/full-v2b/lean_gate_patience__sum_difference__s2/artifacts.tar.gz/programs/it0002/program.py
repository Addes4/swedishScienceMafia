# EVOLVE-BLOCK-START
"""Search for sets A with large A-A and small A+A via structured constructions + local search."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _eval(listlike):
    return _score(listlike)


def _candidates():
    """Yield structured starting sets."""
    cands = []

    # Geometric-like / digit constructions with a large base -> small sums.
    for base in (2, 3, 4, 5, 6, 7, 8, 10, 12, 16):
        for k in (4, 5, 6, 7, 8, 9, 10):
            A = [base ** i for i in range(k)]
            cands.append(A)
        # two-digit construction: base^i * {0,1}
        for k in (3, 4, 5, 6):
            A = []
            for i in range(k):
                A.append(base ** i)
                A.append(base ** i + base ** (k - 1))
            cands.append(A)

    # Ruzsa-style: A = B + C with C small base set, B a dense interval Sidon-ish.
    for c in ([0, 1], [0, 1, 2], [0, 1, 2, 3], [0, 1, 3], [0, 1, 4], [0, 1, 2, 5]):
        for m in (10, 20, 30, 50, 80, 120):
            B = list(range(m))
            A = sorted({b + cc * (m + 1) for b in B for cc in c})
            cands.append(A)

    # Corridor / few-sum exponent-style small sets
    cands.append([0, 1, 2, 4, 8, 16, 32, 64])
    cands.append([1, 2, 4, 8, 16, 32, 64, 128, 256])
    return cands


def solve():
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _eval(best)

    for cand in _candidates():
        if time.time() > deadline - 20:
            break
        s = _eval(cand)
        if s > best_score:
            best, best_score = cand[:], s

    # Local search seeded from the best structured candidate.
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6 and cand:
            i = random.randrange(len(cand))
            scale = max(1, abs(cand[i]) // 4 + 1)
            cand[i] += random.randint(-max(1, scale // 8), max(1, scale // 8))
        elif op < 0.8:
            cand.append(random.randint(-1000, 1000))
        elif cand and len(cand) > 3:
            del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 3:
            cur = best[:]
            continue
        s = _eval(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.15:
            cur = best[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
