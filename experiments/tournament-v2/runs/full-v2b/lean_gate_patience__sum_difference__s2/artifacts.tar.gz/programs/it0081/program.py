# EVOLVE-BLOCK-START
"""Stack k shifted copies of an Erdos-Turan Sidon base B along a large stride M.
Sums a+b within/across blocks collide heavily (block index i+j is bounded, and
values re-mix via M), while differences across blocks are spread over k*M ranges
with distinct residues.  Scan (p, k, M) by exact score.
"""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _primes_upto(n):
    sieve = bytearray([1]) * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for i in range(2, int(n ** 0.5) + 1):
        if sieve[i]:
            sieve[i*i::i] = bytearray(len(sieve[i*i::i]))
    return [i for i in range(n + 1) if sieve[i]]


def _erdos_turan(p):
    return [2 * p * k + (k * k) % p for k in range(p)]


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    primes = _primes_upto(400)

    for p in primes:
        if time.time() > deadline:
            break
        B = _erdos_turan(p)
        n = len(B)
        bmin, bmax = min(B), max(B)
        span = bmax - bmin
        # candidate strides: just above span (small overlap), and smaller ones
        for k in (2, 3, 4, 5):
            if n * k > 3800:
                break
            for mult in (1, 1.5, 2, 3):
                M = int(span * mult) + 1
                if M <= 0:
                    continue
                A = sorted(set(i * M + b for i in range(k) for b in B))
                if len(A) < 2:
                    continue
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
