# EVOLVE-BLOCK-START
"""Multi-copy shifted Bose-Chowla construction.

B is a Bose-Chowla Sidon base of size q with all pairwise sums distinct.
A = union_{t=0}^{k-1} (B + t*M).

Goal: SMALL |A+A| and LARGE |A-A|.
- Differences: A-A contains all differences of B, plus shifts tM + (b-b').
  With k copies and stride M we get a large, mostly distinct difference set.
- Sums: a sum has value (b+b') + (t+u)M. If M is chosen so that sums from the
  same (t+u) band overlap across different (t,u) pairs, |A+A| collapses. Since
  b+b' ranges over B+B (size q(q+1)/2, roughly [0, 4q)), choosing M slightly
  larger than the spread of B+B lets adjacent bands touch/overlap, so we get
  about (2k-1) bands of size ~|B+B| instead of k^2 * |B+B| pairs.

We scan q, k, M and keep the exact best score, using numpy for fast counting.
"""
import time
import math
import numpy as np


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _bose_chowla(q):
    B = [2 * q * k + (k * k) % q for k in range(q)]
    return B


def _score_np(A):
    n = len(A)
    if n < 2:
        return -1.0
    a = np.array(A, dtype=np.int64)
    # differences a[i]-a[j]
    D = a[:, None] - a[None, :]
    ud = np.unique(D)
    ld = ud.size
    # sums a[i]+a[j]
    S = a[:, None] + a[None, :]
    us = np.unique(S)
    ls = us.size
    if ls < 2:
        return -1.0
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def solve():
    deadline = time.time() + 100.0
    best_val = -1.0
    best_A = [0, 1]

    qs = [q for q in range(20, 260) if _is_prime(q)]

    for q in qs:
        if time.time() > deadline:
            break
        B = _bose_chowla(q)
        spreadB = max(B) - min(B)
        sumB_max = 2 * max(B)
        sumB_min = 0
        # band of sums B+B spans [sumB_min, sumB_max], size 2*max(B)+1
        sumspan = 2 * spreadB  # rough width of B+B
        # Choose M near sumspan/k so bands of different (t+u) merge.
        m0 = max(spreadB + 1, 1)
        m_cands = set()
        for k in range(2, 9):
            # to make sum bands collide: M ~ sumspan/k keeps many overlaps
            m_cands.add((sumspan // k) if k else sumspan)
            m_cands.add(sumspan // (2 * k))
        m_cands.add(spreadB + 1)
        m_cands.add(sumspan)
        m_cands.add(2 * spreadB + 1)

        for M in m_cands:
            if M <= 0:
                continue
            for k in range(2, 9):
                if time.time() > deadline:
                    break
                n = k * q
                if n > 4000:
                    continue
                vals = set()
                for t in range(k):
                    off = t * M
                    for b in B:
                        vals.add(b + off)
                if len(vals) != n:
                    continue
                A = sorted(vals)
                val = _score_np(A)
                if val > best_val:
                    best_val = val
                    best_A = A

    return best_A
# EVOLVE-BLOCK-END
