# EVOLVE-BLOCK-START
"""Directly optimize log|A-A|/log|A+A| with a fast exact scorer + smart moves.

Seed: a Sidon set scaled into widely separated values (all differences ~distinct,
sums ~k^2/2). Then greedily add/relocate elements choosing the move that best
improves the exact ratio, using sets for O(k) incremental scoring.
"""
import math
import random
import time


def _counts(a):
    s = list(set(a))
    n = len(s)
    if n < 2:
        return 0, 0
    sums = set()
    for i in range(n):
        si = s[i]
        for j in range(i, n):
            sums.add(si + s[j])
    diffs = set()
    for i in range(n):
        si = s[i]
        for j in range(n):
            if i != j:
                diffs.add(si - s[j])
    return len(diffs), len(sums)


def _score(a):
    s = list(set(a))
    n = len(s)
    if n < 2:
        return 0.0
    nd, ns = _counts(s)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _greedy_sidon(limit_n, deadline):
    B = [0]
    used = {0}
    x = 1
    while x <= limit_n and time.time() < deadline:
        ok = True
        local = []
        for b in B:
            v = x + b
            if v in used:
                ok = False
                break
            local.append(v)
        if ok:
            local.append(2 * x)
            if len(set(local)) != len(local):
                ok = False
        if ok:
            if any(v in used for v in local):
                ok = False
        if ok:
            B.append(x)
            used.update(local)
        x += 1
    return B


def _inc_score(s, x_new):
    """Exact ratio of set s + x_new, computed via incremental set ops."""
    ss = set(s)
    nd0 = set()
    ns0 = set()
    for a in ss:
        for b in ss:
            ns0.add(a + b)
            if a != b:
                nd0.add(a - b)
    ns = set(ns0)
    nd = set(nd0)
    for a in ss:
        ns.add(a + x_new)
        ns.add(a + a)
        nd.add(a - x_new)
        nd.add(x_new - a)
    ns.add(2 * x_new)
    n = len(ss) + 1
    if len(ns) < 2:
        return 0.0, nd, ns
    return math.log(len(nd)) / math.log(len(ns)) + (1 - 1 / n) / 100, nd, ns


def solve():
    deadline = time.time() + 108

    base = _greedy_sidon(6000, time.time() + 20)
    if len(base) < 30:
        base = _greedy_sidon(20000, time.time() + 20)
    base = sorted(set(base))
    if not base:
        base = [0, 1]

    hi = max(base)
    scale = max(1, (10 ** 15 // (hi + 1)) if hi > 0 else 1)
    A = sorted(set(b * scale for b in base))
    # cap size to keep scoring tractable
    while len(A) > 220:
        A = A[::2]

    best = A
    best_score = _score(A)
    cur = A
    cur_score = best_score

    while time.time() < deadline:
        # try inserting best candidate from a random sample of positions
        cand_val = random.randint(-10 ** 15, 10 ** 15)
        if cand_val in set(cur):
            continue
        sc, _, _ = _inc_score(cur, cand_val)
        if sc > cur_score:
            cur = sorted(set(cur + [cand_val]))
            cur_score = sc
            if sc > best_score:
                best, best_score = cur[:], sc
        else:
            # occasional relocation: drop a random element then re-add best
            if len(cur) > 4 and random.random() < 0.3:
                c2 = cur[:]
                c2.pop(random.randrange(len(c2)))
                if time.time() > deadline:
                    break
                # re-try a few inserts on reduced set
                base2 = sorted(set(c2))
                try:
                    vals = sorted(set(base2))
                    lo, hi2 = vals[0], vals[-1]
                except Exception:
                    continue
                for _ in range(6):
                    v = random.randint(lo - 10 * scale, hi2 + 10 * scale)
                    v = max(-10 ** 15, min(10 ** 15, v))
                    if v in set(base2):
                        continue
                    sc2, _, _ = _inc_score(base2, v)
                    n2 = len(base2) + 1
                    cur_sc2 = math.log(len(set([p + q for p in base2 for q in base2]))) / \
                              math.log(len(set([p + q for p in base2 for q in base2]))) if False else None
                    if sc2 > cur_score:
                        base2 = sorted(set(base2 + [v]))
                        cur = base2
                        cur_score = sc2
                        if sc2 > best_score:
                            best, best_score = cur[:], sc2
                        break

    return sorted(set(best))
# EVOLVE-BLOCK-END
