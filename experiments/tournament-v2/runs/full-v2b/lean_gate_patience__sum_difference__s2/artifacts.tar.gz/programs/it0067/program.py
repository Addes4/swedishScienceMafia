# EVOLVE-BLOCK-START
"""Fresh approach: construct a Sidon-style set with few sums (all pairwise sums distinct),
then embed it so differences are maximized."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build_sidon(n, deadline):
    """Greedily build a B_2 set (all pairwise sums distinct) of size ~n."""
    # Start with a few values; extend while keeping Sidon property.
    # Use integer values; check all pair sums for collisions.
    random.seed(12345)
    limit = 10 ** 15
    B = [0, 1]
    sums = {0: {0}, 1: {1}, 2: {0}}
    # Maintain set of all pair sums (i<=j) and pair differences.
    # We'll just recompute incrementally.
    pairsums = set()
    for i in range(len(B)):
        for j in range(i, len(B)):
            pairsums.add(B[i] + B[j])
    pairdiffs = set()
    for i in range(len(B)):
        for j in range(len(B)):
            pairdiffs.add(B[i] - B[j])

    # candidate pool: exponential-like spread
    cand_num = 2
    tried = 0
    max_val = 10 ** 6
    while len(B) < n and time.time() < deadline:
        # generate candidate
        c = random.randint(2, max_val)
        tried += 1
        if tried > 20000 * n:
            max_val *= 2
            tried = 0
        # check Sidon: for each existing x, y: c + x != a + b where a,b in B (a<=b)
        ok = True
        for x in B:
            s = c + x
            if s in pairsums:
                ok = False
                break
        if ok:
            # also c+c must be new
            if 2 * c in pairsums:
                ok = False
        if ok:
            # add c: update pairsums and pairdiffs
            new_sums = set()
            for x in B:
                new_sums.add(c + x)
            new_sums.add(2 * c)
            if new_sums & pairsums:
                ok = False
            if ok:
                pairsums |= new_sums
                for x in B:
                    pairdiffs.add(c - x)
                    pairdiffs.add(x - c)
                pairdiffs.add(0)
                B.append(c)
    return B


def solve():
    n_target = 150
    deadline = time.time() + 100
    B = _build_sidon(n_target, deadline)
    n = len(B)
    # B is a Sidon set in integers: all pairwise sums are distinct -> |B+B| = n(n+1)/2.
    # Pairwise differences: at most n*(n-1)+1 distinct, typically near maximum for Sidon sets.
    # Embed: shift so values are positive and distinct, no need to scale.
    mn = min(B)
    A = sorted(set(x - mn for x in B))
    # Verify/score improvements: if score poor, try a mild optimization on top.
    best = A
    best_score = _score(best)

    # Quick refinement: try scaling to boost difference/sum ratio is unnecessary;
    # differences and sums behave the same under affine transform. Just return.
    return best
# EVOLVE-BLOCK-END
