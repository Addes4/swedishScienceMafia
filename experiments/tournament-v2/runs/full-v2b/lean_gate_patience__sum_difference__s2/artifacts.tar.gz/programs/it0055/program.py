# EVOLVE-BLOCK-START
"""Multi-level dilation with Bose-Chowla Sidon core.

A = { sum_t c_t * M^t : c_t in C }, C a Sidon set, M > 2*max(C).

For any difference x-y, the highest digit t where the digit tuples
differ cannot be cancelled by lower digits (since |c-c'| < M), so the
difference determines the highest digit pair.  This gives
|A-A| = |C-C|^L and |A+A| = |C+C|^L, hence ratio
    L*log|C-C| / (L*log|C+C|) = log|C-C|/log|C+C|,
strictly better than a single core, with A large so the size bonus
approaches 1.  We maximise log|C-C|/log|C+C| over Sidon cores.
"""
import math
import time

MAX_A = 4000
LIMIT = 10 ** 15


def _greedy_sidon(target, maxval):
    """Greedy Sidon set in [0, maxval] with all pairwise sums distinct."""
    B = [0]
    sums = {0}
    cand = 1
    while len(B) < target and cand <= maxval:
        ok = True
        for b in B:
            if cand + b in sums:
                ok = False
                break
        if ok:
            for b in B:
                sums.add(cand + b)
            sums.add(2 * cand)
            B.append(cand)
        cand += 1
    return B


def _score_quick(A):
    A = list(set(A))
    n = len(A)
    if n < 2:
        return -1.0
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    if len(sums) < 2:
        return -1.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0


def _ratio(C):
    """log|C-C|/log|C+C| for the core."""
    diffs = {x - y for x in C for y in C}
    sums = {x + y for x in C for y in C}
    if len(sums) < 2:
        return -1.0
    return math.log(len(diffs)) / math.log(len(sums))


def _build(C, M, L):
    cur = [0]
    for _ in range(L):
        nxt = []
        for x in cur:
            for c in C:
                nxt.append(x * M + c)
        cur = nxt
        if len(cur) > MAX_A:
            return None
    return sorted(set(cur))


def solve():
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Build a range of Sidon cores with different densities/sizes.
    cores = []
    for target in (2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12):
        C = _greedy_sidon(target, 2000)
        if len(C) >= 2:
            cores.append(C)

    # Also try a "dense-ish" core: {0} u powers-ish via greedy with tighter spread.
    for target in (3, 4, 5, 6, 7):
        C = _greedy_sidon(target, 60)
        if len(C) >= 2:
            cores.append(C)

    for C in cores:
        if time.time() > deadline:
            break
        maxC = max(C)
        M = 2 * maxC + 1
        if M < 1:
            M = 1
        L = 0
        while True:
            L += 1
            if time.time() > deadline:
                break
            if len(C) ** L > MAX_A:
                break
            A = _build(C, M, L)
            if A is None:
                continue
            if A[-1] > LIMIT or A[0] < -LIMIT:
                break
            if len(A) < 2:
                continue
            sc = _score_quick(A)
            if sc > best_score:
                best_score = sc
                best = A

    if best is None:
        # Fallback: simple Sidon dilation that we know fits.
        C = _greedy_sidon(6, 2000)
        best = _build(C, 2 * max(C) + 1, 4)
    return sorted(set(best))
# EVOLVE-BLOCK-END

