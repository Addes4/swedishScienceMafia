# EVOLVE-BLOCK-START
"""Try a union-of-arithmetic-progressions construction.

A = union_i { s_i + d_i * t : 0 <= t < L_i }.

Within one AP the sum set is itself an AP (dense), and across APs sums live on a
coarser lattice. Differences within an AP are also an AP, but differences between
APs with distinct step sizes spread out and are mostly distinct. The hope is that
sums collide more than differences, giving a large log|A-A|/log|A+A|.

We sweep several families of (starts, steps, lengths) and keep the best exact score.
"""
import math
from itertools import combinations


def _sizes(a):
    d = set()
    s = set()
    for x in a:
        for y in a:
            d.add(x - y)
            s.add(x + y)
    return len(d), len(s)


def _score(a):
    if len(a) < 2:
        return -1.0, 0, 0
    d, s = _sizes(a)
    if d < 2 or s < 2:
        return -1.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100, d, s


def _build(apars):
    """apars: list of (start, step, length)."""
    A = set()
    for s, d, L in apars:
        for t in range(L):
            A.add(s + d * t)
    return sorted(A)


def _make_candidates():
    cands = []

    # Family 1: m APs sharing the same start region, steps = distinct primes/powers.
    for m in (2, 3, 4, 5):
        for L in (8, 16, 32, 64, 128, 256):
            for base in (1, 2, 3):
                steps = []
                s = 1
                for i in range(m):
                    s *= base + 2
                    steps.append(s)
                # distinct-ish steps
                steps = sorted(set(steps))
                if len(steps) < m:
                    continue
                starts = [0] * m
                apars = [(starts[i], steps[i], L) for i in range(m)]
                if sum(L for _ in range(m)) <= 4000:
                    cands.append(apars)

    # Family 2: APs with a common step q but distinct residues => they interleave
    # inside one big AP, so sums collapse strongly; differences between residues
    # spread out.
    for m in (2, 3, 4, 5, 6, 8):
        for q in (m, 2 * m, m * m, 10, 20, 50, 100):
            total = 4000
            L = total // m
            if L < 4:
                continue
            # shifts chosen small and irregular to break symmetry in differences
            shifts = []
            v = 0
            for i in range(m):
                shifts.append(v)
                v += 1 + (i * i) % 3 + (i % 4)
            apars = [(shifts[i], q, L) for i in range(m)]
            cands.append(apars)

    # Family 3: nested APs: a big AP plus a few sparse APs with large coprime steps.
    for q in (2, 3, 5, 7, 11):
        for m in (1, 2, 3, 4):
            L = 4000 // (m + 1)
            apars = [(0, 1, L)]
            for i in range(m):
                step = q * (i + 2)
                apars.append((1 + i * 3, step, L))
            cands.append(apars)

    # Family 4: scaled copies of a small Sidon-ish core: shifts = c_i, step = big
    for m in (2, 3, 4, 5):
        core = []
        v = 0
        for i in range(m):
            core.append(v)
            v += (i + 1) * 2 + 1
        for step in (30, 100, 300, 1000, 3000):
            L = max(2, 4000 // m)
            apars = [(core[i], step, L) for i in range(m)]
            cands.append(apars)

    return cands


def solve():
    best = None
    best_score = -1.0

    for apars in _make_candidates():
        total = sum(L for _, _, L in apars)
        if total > 4000:
            continue
        A = _build(apars)
        if len(A) > 4000:
            continue
        sc, d, s = _score(A)
        if sc > best_score:
            best_score, best = sc, A

    if best is None:
        best = [0, 1, 2, 3]

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    return best


# EVOLVE-BLOCK-END
