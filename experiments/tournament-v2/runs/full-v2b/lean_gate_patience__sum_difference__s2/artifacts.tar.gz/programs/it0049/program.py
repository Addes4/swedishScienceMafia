# EVOLVE-BLOCK-START
"""Construction: A = C + [0,k), C a Sidon-like core in a cyclic group.
  A + A = (C+C) + [0,2k)  -> size ~ |C+C| + 2k  (sums collide heavily)
  A - A = (C-C) + [-k,k)  -> size ~ |C-C| + 2k
With C Sidon (mod q), |C-C| ~ |C|^2 and |C+C| is close to |C|^2/2, so the
ratio is far apart. We pick the best k analytically rather than sweeping, and
use a Bose-Chowla-style Sidon set (size q-1, no equal differences) so |C-C|
is maximal."""
import math
import time


def _sidon_mod_prime(q):
    """Bose-Chowla-like Sidon set in Z_q: {i : x^2 = i} won't work; use the
    standard construction {2*i*q + (i^2 mod q)} giving distinct differences,
    then map to a Sidon set mod q*q via CRT-free packing. Simpler: use the
    quadratic Sidon set {i + q*(i^2 mod q)} for i in [0,q)."""
    # {a_i = i + q*(i^2 mod q)} has all differences distinct because
    # a_i - a_j = (i-j) + q*((i^2-j^2) mod q) determines i-j and i+j.
    return [i + q * ((i * i) % q) for i in range(q - 1)]


def _diffsum_size(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def solve():
    t0 = time.time()
    budget = 110.0

    best = None
    best_score = -1.0

    # Candidate Sidon cores: quadratic sets for various primes q.
    primes = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59,
              67, 71, 79, 83, 89, 97, 101, 113, 127]
    core_specs = {}
    for q in primes:
        if time.time() - t0 > budget * 0.3:
            break
        C = _sidon_mod_prime(q)
        if len(C) >= 3:
            core_specs[q] = C

    for q, C in core_specs.items():
        cn = len(C)
        span = max(C) - min(C)
        # exact |C+C|, |C-C| (cheap for small cores)
        cc_sum = len(set(x + y for x in C for y in C))
        cc_diff = len(set(x - y for x in C for y in C))

        # analytic k: maximize log(cc_diff + 2k)/log(cc_sum + 2k),
        # with constraint cn*k <= 4000. include size bonus term mildly.
        # scan k at a coarse-to-fine schedule but O(few hundred) only.
        ks = set()
        lo, hi = 1, max(1, 4000 // cn)
        # candidate k around where the log-ratio is maximized: derivative
        # zeros are near 2k ~ sqrt(cc_sum * cc_diff); use multiples.
        root = int(math.sqrt(max(1, cc_sum * cc_diff))) // 2 + 1
        for base in (1, root // 4, root // 2, root, 2 * root, hi // 2, hi):
            base = max(1, base)
            for m in (1, 2, 3, 4, 6, 8, 12, 16, 24, 32):
                ks.add(base * m)
        ks.update([1, 2, 4, 8, 16, 32, 64, 128, 256, 512])
        for k in sorted(ks):
            if k < 1 or k > hi:
                continue
            n = cn * k
            if n > 4000 or n < 3:
                continue
            if time.time() - t0 > budget:
                break
            # exact construction
            A = []
            for c in C:
                base_v = c
                for t in range(k):
                    A.append(base_v + t)
            d, s = _diffsum_size(A)
            if s < 2 or d < 2:
                continue
            sc = math.log(d) / math.log(s) + (1 - 1 / len(A)) / 100
            if sc > best_score:
                best_score, best = sc, A

    if best is None:
        best = [0, 1, 2, 3]

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    return best


# EVOLVE-BLOCK-END
