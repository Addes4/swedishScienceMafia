# EVOLVE-BLOCK-START
"""Structural construction: Bose-Chowla Sidon base B, then A = B union (B + M).

A Sidon base keeps distinct pairwise sums. Shifting by M makes cross sums b+b'+M.
The sum set A+A = (B+B) ∪ (B+B+M) ∪ (B+B+2M) which, because differences in B are
bounded, can be made to overlap when M is small relative to the spread of B - but
here we want SMALL sums and LARGE differences, so we instead exploit that B is a
Sidon set (|B+B| = q(q+1)/2) while A = B ∪ (B+M) yields many distinct differences.
We scan q and M and keep the best exact score."""
import time
import math


def _counts(A):
    n = len(A)
    s = set()
    d = set()
    for i in range(n):
        ai = A[i]
        for j in range(i, n):
            s.add(ai + A[j])
        for j in range(n):
            d.add(ai - A[j])
    return len(s), len(d)


def _score(A):
    n = len(A)
    if n < 2:
        return -1.0
    ls, ld = _counts(A)
    if ls < 2:
        return -1.0
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def _bose_chowla(q):
    """Sidon set of size q in [0, 2q) for prime q (or prime power, use prime q)."""
    B = []
    for k in range(q):
        B.append(2 * q * k + (k * k) % q)
    return B


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def solve():
    deadline = time.time() + 100.0
    best_val = -1.0
    best_A = [0, 1]

    # Candidate q values for the Sidon base.
    qs = []
    v = 30
    while v <= 300:
        if _is_prime(v):
            qs.append(v)
        v += 1
    # also some larger primes
    for v in (317, 349, 383, 401, 449, 499, 557, 601, 659, 701):
        if _is_prime(v):
            qs.append(v)

    for q in qs:
        if time.time() > deadline:
            break
        B = _bose_chowla(q)
        spread = max(B) - min(B)
        # M must exceed the spread of B so that B and B+M are separated but
        # cross-sum ranges overlap with intra-sum ranges to shrink |A+A|.
        base = spread + 1
        M_candidates = set()
        for factor in (1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144):
            M_candidates.add(base * factor)
        # also try making the two copies overlap in sums
        M_candidates.add(spread)
        M_candidates.add(2 * spread)
        for M in sorted(M_candidates):
            if M <= 0:
                continue
            if M < spread + 1:
                continue
            A = sorted(set(B) | set(b + M for b in B))
            if time.time() > deadline:
                break
            n = len(A)
            if n > 4000:
                continue
            val = _score(A)
            if val > best_val:
                best_val = val
                best_A = A

    return best_A
# EVOLVE-BLOCK-END
