import math
import random
import time


def _metrics(a):
    a = list(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2 or len(diffs) < 2:
        return 0.0, len(diffs), len(sums)
    sc = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / n) / 100
    return sc, len(diffs), len(sums)


def _find_sidon_seed(target, deadline):
    """Greedy/randomized search for a Sidon set (all pairwise sums distinct)."""
    best = []
    # seed with powers of two-ish small Sidon
    while time.time() < deadline:
        B = []
        used_sums = set()
        vals = list(range(0, target * 6 + 10))
        # start from a random small anchor
        B.append(random.choice([0, 1, 2, 3]))
        for _ in range(target * 40):
            if len(B) >= target:
                break
            cand = random.choice(vals)
            if cand in B:
                continue
            ok = True
            new_sums = set()
            for x in B:
                for y in [cand]:
                    s = x + y
                    if s in used_sums or s in new_sums:
                        ok = False
                        break
                    new_sums.add(s)
                if not ok:
                    break
            if ok:
                # also need cand+cand distinct
                if cand + cand in used_sums or cand + cand in new_sums:
                    ok = False
            if ok:
                B.append(cand)
                used_sums |= new_sums
                used_sums.add(cand + cand)
        if len(B) > len(best):
            best = B[:]
        if len(best) >= target:
            break
    return best


def _embed(B, base, power):
    """Spread base values into widely separated integers to decorrelate differences."""
    return [v * base + (v + 1) ** power for v in B]


def solve():
    deadline = time.time() + 110
    best_A = []
    best_sc = -1.0

    # Try several base/shape parameterizations and pick the best.
    configs = [
        (14, 1000, 2),
        (16, 3000, 2),
        (18, 5000, 2),
        (20, 10000, 2),
        (16, 20000, 3),
        (20, 100000, 2),
        (24, 1000000, 2),
    ]

    t0 = time.time()
    sidon_budget = max(20.0, (deadline - t0) * 0.5)

    for target, base, power in configs:
        if time.time() > deadline - 5:
            break
        seed_deadline = min(time.time() + sidon_budget / max(1, len(configs)), deadline - 5)
        B = _find_sidon_seed(target, seed_deadline)
        if len(B) < 3:
            continue
        A = _embed(B, base, power)
        A = sorted(set(A))
        sc, nd, ns = _metrics(A)
        if sc > best_sc:
            best_sc, best_A = sc, A[:]

    # Local enhancement: try adding elements that increase |A-A| while
    # keeping |A+A| from growing too much. Also try small perturbations.
    if best_A:
        A = best_A[:]
        cur_sc = best_sc
        iters = 0
        maxv = max(abs(x) for x in A)
        while time.time() < deadline and iters < 200000:
            iters += 1
            mode = random.random()
            cand = A[:]
            if mode < 0.6:
                # add a new value near the existing spread but offset
                x = random.choice(A)
                y = random.choice(A)
                nv = x + y + random.randint(-3, 3)
                if nv not in cand:
                    cand.append(nv)
            elif mode < 0.85:
                # shift one element slightly
                i = random.randrange(len(cand))
                cand[i] += random.randint(-5, 5)
                if len(set(cand)) != len(cand):
                    continue
            else:
                # try to drop a redundant element if that helps ratio
                if len(cand) > 6:
                    cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2 or len(cand) > 4000:
                continue
            if max(abs(v) for v in cand) > 10**15:
                continue
            sc, nd, ns = _metrics(cand)
            if sc > cur_sc:
                A, cur_sc = cand, sc
                if sc > best_sc:
                    best_sc, best_A = sc, cand[:]

    if not best_A:
        best_A = [0, 1, 3, 7, 12, 20]
    return sorted(set(best_A))
