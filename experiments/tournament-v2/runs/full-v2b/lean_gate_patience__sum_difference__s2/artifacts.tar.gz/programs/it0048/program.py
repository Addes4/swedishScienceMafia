# EVOLVE-BLOCK-START
"""Construction: A = [0,m) + M*Y, Y a Sidon-like set of size r.

  A + A = [0,2m) + M*(Y+Y)     -> |A+A| ~ (|Y+Y|)*2m  (interval collapses sums)
  A - A = (-m,m) + M*(Y-Y)     -> |A-A| ~ (|Y-Y|)*2m  (differences distinct)

With Y Sidon, |Y+Y| ~ r^2/2 and |Y-Y| ~ r^2, so choosing m ~ M keeps the
interval contributions from washing out the exponent gap while maximizing |A|.
We sweep m, M, r over a modest grid using exact set sizes for small configs,
and pick the best scored configuration.
"""
import math
import time


def _sidon_greedy(n):
    """Greedy Sidon set: all pairwise sums (incl. doubles) distinct."""
    B = []
    sums = set()
    val = 0
    limit = 200 * n * n + 2000
    while len(B) < n and val < limit:
        new = [val + b for b in B] + [2 * val]
        if all(s not in sums for s in new):
            B.append(val)
            sums.update(new)
        val += 1
    return B


def _diffsum_size(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def solve():
    t0 = time.time()
    budget = 100.0

    # Precompute Sidon cores once.
    max_r = 60
    cores = {}
    for r in range(3, max_r + 1):
        C = _sidon_greedy(r)
        if len(C) == r:
            cores[r] = C

    best = None
    best_score = -1.0

    def build(m, M, Y):
        # A = union over y in Y of { M*y + t : 0 <= t < m }
        A = []
        for y in Y:
            base = M * y
            for t in range(m):
                A.append(base + t)
        return A

    # Configs: r = |Y|, m = interval length, M = scale between interval and Y.
    # Want total size r*m <= 4000. Try a grid of (r, m, M).
    r_values = [r for r in cores if 3 <= r <= 40]
    for r in r_values:
        Y = cores[r]
        spanY = Y[-1] - Y[0] if len(Y) >= 2 else 1
        for m in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64):
            if r * m > 4000 or r * m < 3:
                continue
            # M must be large enough that M*(Y-Y) gaps exceed interval width,
            # so differences across different y don't merge: M >= 2m is safe,
            # but too large M wastes nothing in sizes; use M = 2m and a few sizes.
            for mult in (1, 2, 4):
                M = 2 * m * mult
                if M > 10**9:
                    continue
                A = build(m, M, Y)
                if len(A) > 4000:
                    continue
                if time.time() - t0 > budget:
                    break
                d, s = _diffsum_size(A)
                if s < 2 or d < 2:
                    continue
                sc = math.log(d) / math.log(s) + (1 - 1 / len(A)) / 100
                if sc > best_score:
                    best_score, best = sc, A
            if time.time() - t0 > budget:
                break
        if time.time() - t0 > budget:
            break

    if best is None:
        best = [0, 1, 2, 3]

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    return best


# EVOLVE-BLOCK-END

