# EVOLVE-BLOCK-START
"""Multi-copy interval (AP) construction with merging sum bands.

A = union_{t=0}^{k-1} (t*M + [0, R))   (a "comb" of intervals).

Sums of two elements lie in bands indexed by (t+u): value in [ (t+u)M, (t+u)M + 2R-2 ].
With M ~ 2R the bands for different (t+u) overlap/touch, so the number of distinct
sums is about (2k-1)*(2R-1) instead of k^2 * (2R-1) pairs.

Differences a - b = (t-u)M + (x - y) with x,y in [0,R).  For distinct t,u the
bands are separated (|t-u|M >= M > 2R) so differences stay largely distinct:
about (2k-1)*R... time, giving a large |A - A|.

We scan R, k and M near 2R and keep the exact best score.
"""
import time
import math
import numpy as np


def _score_np(A):
    n = len(A)
    if n < 2:
        return -1.0
    a = np.array(A, dtype=np.int64)
    D = a[:, None] - a[None, :]
    ld = np.unique(D).size
    S = a[:, None] + a[None, :]
    ls = np.unique(S).size
    if ls < 2:
        return -1.0
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def solve():
    deadline = time.time() + 100.0
    best_val = -1.0
    best_A = [0, 1]

    # We want n = k*R <= 4000.  Try many (k, R) with k,R >= 2.
    candidates = []
    for k in range(2, 40):
        for R in range(2, 4001 // k + 1):
            n = k * R
            if 2 <= n <= 4000:
                candidates.append((k, R))
    # Prefer larger n and moderately sized k
    candidates.sort(key=lambda kr: -kr[0] * kr[1])

    for k, R in candidates:
        if time.time() > deadline:
            break
        n = k * R
        if n < 2:
            continue
        # M near 2R-1 merges adjacent sum bands maximally.
        baseMs = set()
        for d in range(-2, 4):
            m = 2 * R - 1 + d
            if m > 0:
                baseMs.add(m)
        # also try M values that make gap smaller -> more band merging
        for div in range(1, 4):
            m = (2 * R - 1) // div
            if m > 0:
                baseMs.add(m)
        for M in baseMs:
            if time.time() > deadline:
                break
            A = []
            for t in range(k):
                off = t * M
                for x in range(R):
                    A.append(off + x)
            if len(set(A)) != n:
                continue
            A = sorted(set(A))
            val = _score_np(A)
            if val > best_val:
                best_val = val
                best_A = A

    return best_A
# EVOLVE-BLOCK-END
