# EVOLVE-BLOCK-START
"""Construction based on the Bose-Chowla Sidon set.

Pick a prime power q. The Bose-Chowla set B = { (a, a^2) -> 2q*i + (i^2 mod q) : i=0..q-1 }
is a Sidon set in Z_{q^2-1} of size q: all sums b_i+b_j (i<=j) are distinct as residues
mod q^2-1, giving |B-B| ~ q^2 and |B+B| ~ q^2/2 over the finite group.

We instead exploit a different regime: we want MANY differences and FEW sums. We use
embeddings that keep differences distinct (Sidon property for differences) while making
sums collide. We search several constructions with exact scoring and pick the best.
"""
import math
import time


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1.0, 0, 0
    diffs = len({x - y for x in a for y in a})
    sums = len({x + y for x in a for y in a})
    if sums < 1:
        return -1.0, diffs, sums
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100, diffs, sums


def bose_chowla(q):
    """Bose-Chowla Sidon set in Z_{q^2-1} via the field F_{q^2}.
    Represent elements of F_{q^2} as a + b*x with x^2 = g (a primitive element generator).
    A standard explicit construction: B = { i : i in primitive elements } mapped nicely.
    Here use the classic: pick primitive element theta of F_{q^2}; B = {a : theta + a is ... }.
    Simpler valid Sidon set mod (q^2-1): B = { 2q*i + (i*i mod q) : i = 0..q-1 }.
    This is the standard Bose-Chowla Sidon set of size q in Z_{q^2-1}.
    """
    B = []
    for i in range(q):
        B.append(2 * q * i + (i * i) % q)
    return B


def build_sidon_base(target, seed=12345, time_budget=4.0):
    import random
    rng = random.Random(seed)
    deadline = time.time() + time_budget
    best = []
    while time.time() < deadline:
        b = []
        pool = list(range(0, max(64, target * target * 3)))
        rng.shuffle(pool)
        sums = set()
        for v in pool:
            ok = True
            new_sums = []
            for x in b:
                s = x + v
                if s in sums:
                    ok = False
                    break
                new_sums.append(s)
            if ok:
                s = v + v
                if s in sums:
                    ok = False
                else:
                    new_sums.append(s)
            if ok:
                b.append(v)
                sums.update(new_sums)
            if len(b) >= target:
                break
        if len(b) > len(best):
            best = b[:]
    return best


def make_combined(m, Y, M):
    A = list(range(m))
    for y in Y:
        A.append(M * y)
    return A


def solve():
    deadline = time.time() + 100
    best_A = None
    best_sc = -1.0

    # ---- Construction 1: Bose-Chowla Sidon set scaled by base to keep differences distinct ----
    for q in range(3, 70):
        if time.time() > deadline:
            break
        if not is_prime(q):
            continue
        B = bose_chowla(q)
        n = len(B)
        # Try embeddings: single layer with multiplier, and multi-layer base dilation.
        # Single-layer: A = [M*b for b in B] . Differences distinct iff B is Sidon; sums
        # <= 2*max so |A+A| can be up to ~n^2/2 but often less due to collisions.
        for M in (1, 2, 3, 5):
            A = [M * b for b in B]
            s, _, _ = score(A)
            if s > best_sc:
                best_sc = s
                best_A = A[:]
        # Multi-layer dilation: A = { sum b_i M^i } would blow up; instead use the
        # "dilate differences, collapse sums" trick: take B in two blocks sharing sums.
        # Build A = B  U  (2*max+1 - B reversed)? Keep it simple: also try the set
        # A = B (raw). Already covered by M=1.

    # ---- Construction 2: interval + scaled greedy Sidon (previous best family) ----
    Y = build_sidon_base(60, seed=2024, time_budget=6.0)
    if len(Y) < 2:
        Y = [0, 1, 3]
    y_max = len(Y)
    for m in [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128]:
        if time.time() > deadline:
            break
        for k in range(1, y_max + 1):
            if time.time() > deadline:
                break
            Yk = Y[:k]
            yd = sorted({abs(Yk[i] - Yk[j]) for i in range(len(Yk)) for j in range(i + 1, len(Yk))})
            Mmin = (m + 2) // max(1, yd[0]) + 1 if yd else 2
            for M in {Mmin, Mmin + 1, Mmin * 2, Mmin + m + 1}:
                if M < 1:
                    continue
                A = make_combined(m, Yk, M)
                if max(abs(x) for x in A) > 10**15:
                    continue
                s, _, _ = score(A)
                if s > best_sc:
                    best_sc = s
                    best_A = A[:]

    # ---- Construction 3: Bose-Chowla B combined with interval, scaled ----
    for q in range(3, 40):
        if time.time() > deadline:
            break
        if not is_prime(q):
            continue
        B = bose_chowla(q)
        for M in (1, q, q + 1, 2 * q):
            for m in (1, 2, 4, 8):
                A = make_combined(m, B, M)
                if max(abs(x) for x in A) > 10**15:
                    continue
                s, _, _ = score(A)
                if s > best_sc:
                    best_sc = s
                    best_A = A[:]

    if best_A is None:
        best_A = [0, 1, 3, 7]
    return list(set(best_A))
# EVOLVE-BLOCK-END
