# EVOLVE-BLOCK-START
"""Construction: take a Sidon base B (Bose-Chowla), then form A = B ∪ (B + T).
Cross sums b + (b' + T) = T + (b + b') lie in an affine copy of B+B, and
intra sums lie in B+B, so |A+A| ~ |B+B| + |B+B shifted| is kept modest, while
A-A contains differences within B, within B+T (copy of B-B), plus cross terms
b - (b' + T) = (b - b') - T spanning a wide interval -> large. We scan T and p
by exact bitset score."""
import time
import math


def _sums_diffs_count(A, lo, hi):
    n = len(A)
    span = hi - lo + 1
    sb = bytearray(span)
    db = bytearray(2 * span)
    off = span
    for i in range(n):
        ai = A[i]
        for j in range(i, n):
            sb[ai + A[j] - lo] = 1
        for j in range(n):
            db[ai - A[j] + off] = 1
    return sum(sb), sum(db)


def _score(A):
    n = len(A)
    if n < 2:
        return -1.0
    S = sorted(set(A))
    if len(S) < 2:
        return -1.0
    lo, hi = S[0], S[-1]
    ls, ld = _sums_diffs_count(S, lo, hi)
    if ls < 2:
        return -1.0
    val = math.log(ld) / math.log(ls)
    val += (1.0 - 1.0 / len(S)) / 100.0
    return val


def _bose_chowla(p, q):
    """Bose-Chowla Sidon set of size q over modulus q^2 - 1, for prime power q."""
    B = []
    for a in range(1, q):
        B.append((2 * a * q + (a * a) % q) % (q * q - 1))
    return sorted(set(B))


def solve():
    deadline = time.time() + 100.0
    best_val = -1.0
    best_A = [0, 1]

    qs = [7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103]
    for q in qs:
        if time.time() > deadline:
            break
        B = _bose_chowla(1, q)
        if len(B) < 2:
            continue
        # Try several shifts T (including a couple near typical values).
        R = max(B) - min(B)
        for Tfac in (1, 2, 3, 4, 6, 8, 12, 16, 24, 32):
            if time.time() > deadline:
                break
            T = R * Tfac + (Tfac * 7 + 3)
            A = sorted(set(B + [b + T for b in B]))
            v = _score(A)
            if v > best_val:
                best_val = v
                best_A = A

    # Greedy refinement: try adding elements from a spread pool to improve.
    lo0 = min(best_A)
    hi0 = max(best_A)
    span = hi0 - lo0
    pool = []
    for k in range(1, 60):
        pool.append(lo0 - span * k)
        pool.append(hi0 + span * k)
    improved = True
    while improved and time.time() < deadline:
        improved = False
        cur_set = set(best_A)
        for c in pool:
            if c in cur_set:
                continue
            cand = sorted(set(best_A + [c]))
            v = _score(cand)
            if v > best_val:
                best_val = v
                best_A = cand
                improved = True
                break

    return sorted(set(best_A))
# EVOLVE-BLOCK-END
