# EVOLVE-BLOCK-START
"""Direct greedy ratio optimization with incremental local search."""
import math
import random
import time


def _counts(a):
    """Return (|A-A|, |A+A|) for sorted list a."""
    s = a
    n = len(s)
    diffs = set()
    sums = set()
    for i in range(n):
        si = s[i]
        for j in range(n):
            diffs.add(si - s[j])
            sums.add(si + s[j])
    return len(diffs), len(sums)


def _score_parts(nd, ns, n):
    if ns <= 1 or nd <= 1:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    nd, ns = _counts(a)
    return _score_parts(nd, ns, n)


def _greedy_sidon(limit, target, rng):
    """Build a set with as many distinct pairwise sums as possible (Sidon-like),
    via randomized greedy over [0, limit)."""
    used_sums = {0}
    A = [0]
    cands = list(range(1, limit))
    rng.shuffle(cands)
    for c in cands:
        if len(A) >= target:
            break
        new_sums = []
        ok = True
        for x in A:
            s = x + c
            if s in used_sums:
                ok = False
                break
            new_sums.append(s)
        if ok:
            ns2 = set(new_sums)
            if len(ns2) != len(new_sums):
                continue
            # c + c distinct from everything?
            if c + c in used_sums or c + c in ns2:
                continue
            used_sums |= ns2
            used_sums.add(c + c)
            A.append(c)
    return sorted(A)


def _dilate(A, m, shift):
    return sorted(x * m + shift for x in A)


def _local_polish(A, deadline, rng, iters_cap=10_000_000):
    """Local search: perturb elements, accept if score improves (hill climb with restarts)."""
    A = sorted(set(A))
    best = A[:]
    nd, ns = _counts(best)
    best_score = _score_parts(nd, ns, len(best))
    cur = A[:]
    span = (max(A) - min(A)) or 1
    step = max(1, span // (8 * max(1, len(A))))
    it = 0
    while time.time() < deadline and it < iters_cap:
        it += 1
        cand = cur[:]
        i = rng.randrange(len(cand))
        if rng.random() < 0.5:
            delta = rng.randint(-step, step)
            if delta == 0:
                delta = 1
            newv = cand[i] + delta
        else:
            newv = rng.randint(-span, 2 * span)
        if newv in cand:
            continue
        cand[i] = newv
        cand = sorted(cand)
        if len(cand) < 4:
            continue
        ndc, nsc = _counts(cand)
        s = _score_parts(ndc, nsc, len(cand))
        if s > best_score:
            best, best_score, cur = cand[:], s, cand
            nd, ns = ndc, nsc
        elif s == best_score:
            cur = cand
        else:
            # occasional restart from best
            if rng.random() < 0.005:
                cur = best[:]
        if it % 2000 == 0:
            step = max(1, (max(cur) - min(cur)) // (8 * max(1, len(cur))))
    return best


def solve():
    rng = random.Random(98765)
    start = time.time()
    deadline = start + 112

    best = None
    best_score = -1.0

    # Build Sidon bases of various sizes, dilate heavily, then polish.
    for k in (20, 30, 40, 50, 60, 80):
        if time.time() > deadline - 30:
            break
        limit = 2 * k * k + 20
        base = _greedy_sidon(limit, k, rng)
        if len(base) < 4:
            continue
        span = (max(base) - min(base)) or 1
        for m in (1, span + 1, span * span + 1):
            if time.time() > deadline - 20:
                break
            cand = _dilate(base, m, 0)
            nd, ns = _counts(cand)
            s = _score_parts(nd, ns, len(cand))
            if s > best_score:
                best_score, best = s, cand[:]

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
        best_score = _score(best)

    # Long polish on the best candidate.
    remaining = deadline - time.time()
    if remaining > 3:
        pol = _local_polish(best, deadline - 1, rng)
        ps = _score(pol)
        if ps > best_score:
            best, best_score = pol, ps

    return sorted(set(best))
# EVOLVE-BLOCK-END
