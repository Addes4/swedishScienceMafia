# EVOLVE-BLOCK-START
"""Erdos-Turan Sidon set, symmetrized under reflection to collapse sums.

Base B = {2p*x + (x*x mod p) : x in [0,p)} is an Erdos-Turan Sidon set
(|B-B| ~ p^2).  Adding its reflection M - B makes each sum s and its
mirror 2M - s coincide, roughly halving |A+A| while (since B is Sidon)
keeping most differences distinct.  We scan p and M by exact score.
"""
import math
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _base(p):
    """Erdos-Turan Sidon base of size p."""
    return [2 * p * x + (x * x) % p for x in range(p)]


def _symmetrize(B, M):
    """A = B u (M - B), deduplicated, sorted."""
    S = set(B)
    for b in B:
        S.add(M - b)
    return sorted(S)


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    cand = [x for x in range(2, 1401) if _is_prime(x)]

    for p in cand:
        if time.time() > deadline:
            break
        B = _base(p)
        bmin, bmax = min(B), max(B)
        # reflection centers: choose M so reflected block sits just above /
        # overlapping the base block for good sum collisions.
        span = bmax - bmin
        centers = [
            bmin + bmax,
            bmin + bmax + 1,
            bmin + bmax - 1,
            2 * bmin + span,
            2 * bmax - span,
            2 * bmin,
            2 * bmax,
        ]
        for M in centers:
            A = _symmetrize(B, M)
            n = len(A)
            if n < 2 or n > 4000:
                continue
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A

    if best is None:
        best = _symmetrize(_base(200), 2 * 200 * 199)
    return best
# EVOLVE-BLOCK-END
