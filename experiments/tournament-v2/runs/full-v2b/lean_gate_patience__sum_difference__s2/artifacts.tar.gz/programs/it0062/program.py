# EVOLVE-BLOCK-START
"""Construction: A = interval [0,m) UNION M*Y with Y a greedy Sidon set.

The interval collapses |A+A| (all sums 0..2m-2 are present) and gives
contiguous differences, while the large-multiplier scaled Sidon part keeps
|A-A| near |A|^2. We search (m, |Y|, M) with exact score for moderate sizes
and choose the best by the real scoring formula.
"""
import math
import random
import time


def build_sidon_base(target, seed=12345, time_budget=6.0):
    rng = random.Random(seed)
    deadline = time.time() + time_budget
    best = []
    while time.time() < deadline:
        b = []
        pool = list(range(0, max(64, target * target * 4)))
        rng.shuffle(pool)
        sums = set()
        for v in pool:
            ok = True
            new_sums = []
            for x in b:
                s = x + v
                if s in sums:
                    ok = False
                    break
                new_sums.append(s)
            if ok:
                s = v + v
                if s in sums:
                    ok = False
                else:
                    new_sums.append(s)
            if ok:
                b.append(v)
                sums.update(new_sums)
            if len(b) >= target:
                break
        if len(b) > len(best):
            best = b[:]
    return best


def score(a):
    a = list(set(a))
    if len(a) < 2:
        return -1.0, 0, 0
    diffs = len({x - y for x in a for y in a})
    sums = len({x + y for x in a for y in a})
    if sums < 1:
        return -1.0, diffs, sums
    return math.log(diffs) / math.log(sums) + (1 - 1 / len(a)) / 100, diffs, sums


def make_combined(m, Y, M):
    A = list(range(m))
    for y in Y:
        A.append(M * y)
    return A


def solve():
    deadline = time.time() + 105

    Y = build_sidon_base(80, seed=2024, time_budget=10.0)
    if len(Y) < 2:
        Y = [0, 1, 3]

    best_A = None
    best_sc = -1.0

    y_max = len(Y)

    # Broad interval sweep; keep total |A| bounded so exact scoring is fast.
    m_candidates = list(range(1, 260))
    m_candidates += [300, 350, 400, 500, 600, 700, 800, 1000]

    for k in range(2, y_max + 1):
        if time.time() > deadline:
            break
        Yk = Y[:k]
        yd = sorted({abs(Yk[i] - Yk[j]) for i in range(len(Yk)) for j in range(i + 1, len(Yk))})
        if not yd:
            continue
        ymin = yd[0]
        ymax = yd[-1]
        for m in m_candidates:
            if time.time() > deadline:
                break
            if m + k > 900:
                continue
            Mmin = (m + 2) // max(1, ymin) + 1
            for M in {Mmin, Mmin + 1, Mmin * 2, Mmin + m + 1, ymax + m + 2}:
                if M < 1:
                    continue
                A = make_combined(m, Yk, M)
                if max(abs(x) for x in A) > 10**15:
                    continue
                if M * ymax > 10**14 and m > 50:
                    # keep numbers modest to avoid overflow in sums
                    pass
                s, _, _ = score(A)
                if s > best_sc:
                    best_sc = s
                    best_A = A[:]

    if best_A is None:
        best_A = [0, 1, 3, 7]
    return list(set(best_A))
# EVOLVE-BLOCK-END

