# EVOLVE-BLOCK-START
"""Erdos-Turan Sidon base: build B = {2pk + (k^2 mod p) : k in [0,p)} which is a
B_2 (Sidon) set, giving |B+B| ~ n^2/2 and |B-B| ~ n^2 (maximal). Then optionally
fold/shift by a small modulus to reduce |A+A| slightly while preserving spread.
"""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _primes_upto(n):
    sieve = bytearray([1]) * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for i in range(2, int(n ** 0.5) + 1):
        if sieve[i]:
            sieve[i*i::i] = bytearray(len(sieve[i*i::i]))
    return [i for i in range(n + 1) if sieve[i]]


def _erdos_turan(p):
    return [2 * p * k + (k * k) % p for k in range(p)]


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    primes = _primes_upto(2000)

    for p in primes:
        if time.time() > deadline:
            break
        B = _erdos_turan(p)
        n = len(B)
        # try a few folding shifts
        for shift in [0, 1, 3, 7, 13, 31, 127]:
            A = sorted(set(x + shift for x in B))
            if len(A) < 2:
                continue
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
