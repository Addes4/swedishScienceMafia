# EVOLVE-BLOCK-START
"""Minkowski-sum seed A = C + [0,k) with C a small Sidon set (few sum collisions),
then a bounded local search that greedily adds nearby integers, always keeping
the exact incremental difference/sum sets, to maximize log|A-A|/log|A+A|."""
import math
import random
import time


def _sidon_greedy(n, limit_step=True):
    """Greedy Sidon set: all pairwise sums (incl. doubles) distinct."""
    B = []
    sums = set()
    val = 0
    limit = 60 * n * n + 500
    while len(B) < n and val < limit:
        new = [val + b for b in B] + [2 * val]
        if all(s not in sums for s in new):
            B.append(val)
            sums.update(new)
        val += 1
    return B


def _metric(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    d = len(diffs)
    s = len(sums)
    if d < 2 or s < 2:
        return -1e18, d, s
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100, d, s


def _seed_best(rng):
    best = None
    best_score = -1.0
    cores = {}
    for cn in (3, 4, 5, 6, 8, 10, 14, 20, 30):
        cores[cn] = _sidon_greedy(cn)

    for cn, C in cores.items():
        if len(C) < 3:
            continue
        scale = max(1, 4 * cn)
        Cscaled = [c * scale for c in C]
        for k in (1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 3900):
            size = len(Cscaled) * k
            if size > 4000:
                continue
            A = []
            for c in Cscaled:
                for t in range(k):
                    A.append(c + t)
            if len(A) > 4000:
                continue
            sc, d, s = _metric(A)
            if sc > best_score:
                best_score, best = sc, A
    return best, best_score


def _local_search(A, deadline, rng):
    A = list(sorted(set(A)))
    cur = set(A)
    sums = set()
    diffs = set()
    for x in A:
        for y in A:
            sums.add(x + y)
            diffs.add(x - y)

    def score(nA, d, s):
        if d < 2 or s < 2:
            return -1e18
        return math.log(d) / math.log(s) + (1 - 1 / nA) / 100

    cur_score = score(len(A), len(diffs), len(sums))

    lo = min(A)
    hi = max(A)

    while time.time() < deadline:
        improved = False
        # try adding a random nearby integer
        for _ in range(40):
            if time.time() >= deadline:
                break
            if len(cur) >= 4000:
                break
            if rng.random() < 0.6:
                cand = rng.randint(lo - 4, hi + 4)
            else:
                cand = rng.randint(lo - 200, hi + 200)
            if cand in cur:
                continue
            new_sums = [cand + x for x in cur] + [2 * cand]
            new_diffs = [cand - x for x in cur] + [x - cand for x in cur] + [0]
            added_s = sum(1 for v in new_sums if v not in sums)
            added_d = sum(1 for v in new_diffs if v not in diffs)
            nA = len(cur) + 1
            ns = len(sums) + added_s
            nd = len(diffs) + added_d
            sc = score(nA, nd, ns)
            if sc > cur_score:
                cur.add(cand)
                sums.update(new_sums)
                diffs.update(new_diffs)
                cur_score = sc
                lo = min(lo, cand)
                hi = max(hi, cand)
                improved = True
                break
        if not improved:
            break
    return sorted(cur)


def solve():
    rng = random.Random(20240607)
    t0 = time.time()
    deadline = t0 + 110.0

    best, best_score = _seed_best(rng)

    if best is None:
        best = [0, 1, 2, 3]

    search_deadline = min(deadline, time.time() + 90.0)
    cand = _local_search(best, search_deadline, rng)
    sc, d, s = _metric(cand)
    if sc > best_score:
        best = cand

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    return best


# EVOLVE-BLOCK-END
