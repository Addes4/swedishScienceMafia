# EVOLVE-BLOCK-START
"""Directly optimize log|A-A|/log|A+A| using big-int bitsets for fast evaluation.

Key idea: represent A+A and A-A as Python ints used as bitsets, so counting is a
single .bit_count() call.  This makes each evaluation ~O(n) big-int ops instead of
O(n^2) Python loops, letting us run many more local-search moves within budget.

Construction: start from a dense interval [0,k) (which yields a very compact sum
set) and greedily add/swap spread elements that grow |A-A| faster than |A+A|.
"""
import time
import math


def _bitsets(A):
    """Return (Sbits, Dbits, lo, hi) as big ints for A+A and A-A."""
    lo = min(A)
    hi = max(A)
    span = hi - lo + 1
    # sum bit i corresponds to value lo + i (i in [0, 2*span-1])
    S = 0
    D = 0
    n = len(A)
    for i in range(n):
        ai = A[i]
        for j in range(i, n):
            S |= 1 << (ai + A[j] - 2 * lo)
        for j in range(n):
            # store differences shifted by span so index >= 0 ; center at span
            D |= 1 << (ai - A[j] + span)
    return S, D, span


def _score_from_bits(S, D, n):
    ls = S.bit_count()
    ld = D.bit_count()
    if ls < 2 or ld < 2 or n < 2:
        return -1.0
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def solve():
    import random
    deadline = time.time() + 108.0
    rng = random.Random(1234567)

    # Seed: a dense block gives a tiny sum set; spread elements enlarge differences.
    k = 90
    A = list(range(0, k))
    base = k - 1
    step = 3000
    for t in range(1, 30):
        A.append(base + t * step)
    A = sorted(set(A))

    S, D, span = _bitsets(A)
    best_val = _score_from_bits(S, D, len(A))
    best_A = A[:]

    # Candidate pool: spread integers across a wide range.
    pool = [rng.randint(0, 400000) for _ in range(500)]

    def rebuild(S):
        return _bitsets(S)

    # Greedy additions.
    improved = True
    while improved and time.time() < deadline:
        improved = False
        cur_set = set(A)
        best_add = None
        best_add_val = best_val
        for c in pool:
            if c in cur_set:
                continue
            cand = sorted(A + [c])
            S2, D2, sp2 = _bitsets(cand)
            v = _score_from_bits(S2, D2, len(cand))
            if v > best_add_val + 1e-12:
                best_add_val = v
                best_add = c
        if best_add is not None:
            A = sorted(A + [best_add])
            S, D, span = _bitsets(A)
            best_val = best_add_val
            improved = True

    # Local swaps.
    while time.time() < deadline:
        cur_val = best_val
        cur_set = set(A)
        best_swap = None
        best_swap_val = cur_val
        for i in range(len(A)):
            base_list = A[:i] + A[i + 1:]
            for c in rng.sample(pool, 30):
                if c in cur_set:
                    continue
                cand = base_list + [c]
                S2, D2, sp2 = _bitsets(cand)
                v = _score_from_bits(S2, D2, len(cand))
                if v > best_swap_val + 1e-12:
                    best_swap_val = v
                    best_swap = (i, c)
        if best_swap is not None:
            i, c = best_swap
            A = sorted(set(A[:i] + A[i + 1:] + [c]))
            S, D, span = _bitsets(A)
            best_val = best_swap_val
        else:
            break

    # Random restarts with variations of the block size.
    while time.time() < deadline:
        kk = rng.randint(60, 140)
        st = rng.randint(1500, 5000)
        B = list(range(0, kk))
        b0 = kk - 1
        for t in range(1, rng.randint(15, 40)):
            B.append(b0 + t * st)
        B = sorted(set(B))
        S3, D3, _ = _bitsets(B)
        v = _score_from_bits(S3, D3, len(B))
        if v > best_val + 1e-12:
            best_val = v
            best_A = B[:]

    return sorted(set(best_A))
# EVOLVE-BLOCK-END
