# EVOLVE-BLOCK-START
"""Bose-Chowla Sidon set construction: minimize |A+A| while maximizing |A-A|.

A Bose set B = { i*p + (i^2 mod p) : i in [0,p) } with p prime is a Sidon set modulo p*q
for suitable q, so all pairwise sums are distinct.  We rescale by a large factor to keep
differences distinct as integers and push |A-A| toward its maximum, while |A+A| stays near
the minimum k(k+1)/2.
"""
import math
import time


def _score(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return 0.0
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _bose_set(p):
    """Bose-Chowla Sidon set mod p*(p-1): { i*p + (i^2 mod p) } over F_p^2 representation.
    Use the simpler Welch variant: a_i = i + p*(i^2 mod p)."""
    return [i + p * ((i * i) % p) for i in range(p)]


def solve():
    deadline = time.time() + 115
    LIMIT = 10 ** 15
    MAXN = 4000

    best = None
    best_score = -1.0

    # Try various primes p; Bose/Welch Sidon sets of size p.
    p = MAXN
    while p >= 2 and time.time() < deadline:
        if _is_prime(p):
            B = _bose_set(p)
            mx = max(B)
            if mx > 0:
                scale = LIMIT // mx
                if scale >= 1:
                    A = sorted(set(b * scale for b in B))
                else:
                    A = B[:]
            else:
                A = B[:]
            A = [x for x in A if abs(x) <= LIMIT]
            if len(A) >= 2:
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A[:]
            # Only need the largest few primes for the size bonus, but sample a range.
        p -= 1

    if best is None:
        best = [0, 1]

    # Local search: try scaling variants and small perturbations.
    cur = best[:]
    best = cur[:]
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        mx = max(abs(x) for x in cand) if cand else 1
        # random small shift of one element
        i = (it * 2654435761) % len(cand)
        step = max(1, mx // 1000)
        delta = ((it % 7) - 3) * step
        cand[i] += delta
        cand = sorted(set(cand))
        if not cand or max(abs(x) for x in cand) > LIMIT or len(cand) > MAXN:
            continue
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]
            cur = cand[:]
        elif s == best_score and len(cand) > len(best):
            best = cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END

