# EVOLVE-BLOCK-START
"""Erdos-Turan / Bose-Chowla Sidon constructions tuned by exact score."""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _et(p, k):
    seen = set()
    out = []
    for x in range(p):
        v = k * x + (x * x) % p
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


def _bc(q, k):
    # Bose-Chowla: primitive root g mod q, A = {x : g^x style} -> use
    # {k*x + (x*x mod (q*q-1))} variant; reduce modulo q^2-1
    m = q * q - 1
    seen = set()
    out = []
    for x in range(q):
        v = k * x + (x * x) % m
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    primes = [x for x in range(2, 1201) if _is_prime(x)]

    for p in primes:
        if time.time() > deadline:
            break
        ks = [p, 2 * p - 1, 2 * p, 2 * p + 1, p * p // 2, p * p - 1,
              p * p + 1, 3 * p]
        for k in ks:
            if k <= 0:
                continue
            A = _et(p, k)
            n = len(A)
            if 2 <= n <= 4000:
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A
        # Bose-Chowla style modulo q^2-1
        for k in [q for q in ks]:
            if k <= 0:
                continue
            A = _bc(p, k)
            n = len(A)
            if 2 <= n <= 4000:
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A

    if best is None:
        best = _et(200, 400)
    return best
# EVOLVE-BLOCK-END

