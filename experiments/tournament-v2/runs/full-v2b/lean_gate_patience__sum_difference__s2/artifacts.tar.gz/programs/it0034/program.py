# EVOLVE-BLOCK-START
"""Iterated local search maximizing log|A-A|/log|A+A| with structured
multi-scale lattice seeds (rich low block + Sidon high block)."""
import math
import random
import time


def _stats(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return -1.0, 0, 0
    diffs = set()
    sums = set()
    for x in s:
        for y in s:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if ns <= 1 or nd <= 1:
        return -1.0, nd, ns
    score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return score, nd, ns


def _score(a):
    return _stats(a)[0]


def _rand_set(n, span):
    vals = random.sample(range(span), n) if span >= n else [random.randrange(span) for _ in range(n)]
    return sorted(set(vals))


def _sidon_base(n, span):
    """Greedy Sidon-ish base: keep pair sums mostly distinct."""
    vals = random.sample(range(span), min(span, n * 3))
    random.shuffle(vals)
    base = []
    sums = set()
    for v in vals:
        ok = True
        new_sums = set()
        for b in base:
            s = v + b
            if s in sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if 2 * v in sums:
            ok = False
        if ok:
            base.append(v)
            sums |= new_sums
            sums.add(2 * v)
            if len(base) >= n:
                break
    return sorted(base)


def _dense_block(n, span):
    """Small additively rich set: short union of APs, many sum collisions."""
    out = set()
    while len(out) < n:
        step = random.choice([1, 2, 3, 5, 7])
        start = random.randint(-span, span)
        ln = random.randint(2, max(2, n // 2))
        for i in range(ln):
            out.add(start + step * i)
    return sorted(out)[:n]


def _multiscale_seed():
    """A = a + M*b with a additively rich (few sum values) and M large so that
    differences a1-a2 + M*(b1-b2) mostly distinct at the high scale."""
    na = random.randint(6, 16)
    span_a = random.choice([10, 20, 40])
    low = _dense_block(na, span_a)
    if len(low) < 4:
        return None
    nb = random.randint(5, 14)
    sid = _sidon_base(nb, 3000)
    if len(sid) < 4:
        return None
    M = random.choice([1000, 3000, 10000, 30000, 100000])
    A = []
    for b in sid:
        for a in low:
            A.append(a + M * b)
    A = sorted(set(A))
    if len(A) < 8:
        return None
    return A


def _ilp(seed, deadline, span):
    cur = sorted(set(seed))
    if len(cur) < 4:
        return cur, -1.0
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score

    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.55:
            i = random.randrange(len(cand))
            lo = min(cand) - 2 * span
            hi = max(cand) + 2 * span
            newv = random.randint(lo, hi)
            if newv in cand:
                continue
            cand[i] = newv
        elif r < 0.85:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-span, span)
        else:
            if random.random() < 0.5 and len(cand) < 300:
                cand.append(random.randint(min(cand) - span, max(cand) + span))
            elif len(cand) > 6:
                del cand[random.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 4:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.01:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    random.seed(20240617)
    start = time.time()
    deadline = start + 112

    best = None
    best_score = -1.0

    # Structured multi-scale seeds.
    for _ in range(160):
        if time.time() > deadline - 8:
            break
        seed = _multiscale_seed()
        if not seed:
            continue
        span = max(2, (max(seed) - min(seed)) // 8)
        sub = time.time() + 0.35
        c, sc = _ilp(seed, sub, span)
        if sc > best_score:
            best, best_score = c[:], sc

    # Random seeds.
    for trial in range(150):
        if time.time() > deadline - 8:
            break
        n = random.randint(30, 150)
        span = random.choice([n, int(n * 1.2), int(n * 1.5), int(n * 2), int(n * 3)])
        seed = _rand_set(n, span)
        sub = time.time() + 0.35
        c, sc = _ilp(seed, sub, max(2, span // 4))
        if sc > best_score:
            best, best_score = c[:], sc

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
        best_score = _score(best)

    c, sc = _ilp(best, deadline - 1.0, max(2, (max(best) - min(best)) // 4))
    if sc > best_score:
        best, best_score = c, sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
