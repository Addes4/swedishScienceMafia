# EVOLVE-BLOCK-START
"""Block-Sidon construction: A = B + M*C with B, C Sidon bases embedded so that intra-block
and cross-block sum structures stay near-minimal while differences spread widely."""
import math
import time


def _bose_chowla(q):
    """Bose-Chowla Sidon set on prime power q-1: B = {2q k + (k^2 mod q)} for k=0..q-1."""
    B = []
    for k in range(q):
        B.append(2 * q * k + (k * k) % q)
    return B


def _is_prime_power(n):
    if n < 2:
        return False
    m = n
    for p in range(2, int(n ** 0.5) + 1):
        if m % p == 0:
            while m % p == 0:
                m //= p
            return m == 1
    return True


def _best_base(target_n, limit_mag):
    """Pick a Bose-Chowla base with size around target_n fitting under limit_mag."""
    best = []
    q = 2
    while q < 4000:
        if _is_prime_power(q - 1):
            B = _bose_chowla(q)
            if len(B) <= target_n + 5 and max(B) <= limit_mag:
                if len(B) > len(best):
                    best = B
        q += 1
    return best


def solve():
    rng_seed = 12345
    deadline = time.time() + 60.0

    # Two Sidon blocks B and C. A = B + M*C where M > 2*max(B) so digits separate.
    # |A+A| sizes: B+B (n_B^2/2), B+C (n_B n_C), C+C (n_C^2/2) -> near-minimal total.
    # |A-A| = |B-B| + |B-C| + |C-B| + |C-C|, each near n^2 -> large.
    best_score = -1.0
    best_A = [0, 1]

    limit_mag = 10 ** 15

    for nB in (60, 90, 120, 160, 200):
        B = _best_base(nB, limit_mag)
        if len(B) < 3:
            continue
        maxB = max(B)
        # M must exceed 2*maxB to keep digit separation between B and M*C blocks.
        M = 2 * maxB + 1
        maxC = limit_mag // M
        for nC in (60, 90, 120, 160, 200):
            C = _best_base(nC, maxC)
            if len(C) < 3:
                continue
            if time.time() > deadline:
                break
            A = set()
            for b in B:
                A.add(b)
                A.add(-b)
            for c in C:
                v = M * c
                A.add(v)
                A.add(-v)
            A = sorted(A)
            # exact score
            diffs = set()
            sums = set()
            for x in A:
                for y in A:
                    diffs.add(x - y)
                    sums.add(x + y)
            if len(sums) == 0:
                continue
            score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / len(A)) / 100.0
            if score > best_score:
                best_score = score
                best_A = A
    return best_A
# EVOLVE-BLOCK-END
