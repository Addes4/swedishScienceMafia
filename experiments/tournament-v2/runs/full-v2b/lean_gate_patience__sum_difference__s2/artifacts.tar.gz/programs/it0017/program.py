# EVOLVE-BLOCK-START
"""Sidon-set construction: minimize |A+A| (near-distinct sums) while maximizing |A-A|.

Idea: A Sidon set B in [1,N] has all pairwise sums distinct, so |B+B| ~ k(k+1)/2 ~ k^2/2,
which is the theoretical minimum for |A+A|. Meanwhile differences can be made large and
distinct by scaling B and adding a bit of local-search refinement on the literal score.
"""
import math
import random
import time


def _score(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return 0.0
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _greedy_sidon(limit_n, time_budget):
    """Greedily build a Sidon set (all pairwise sums distinct) inside [0, limit_n]."""
    # Ruzsa / classic greedy Sidon construction.
    B = [0]
    used_sums = {0}
    # candidate pool
    deadline = time.time() + time_budget
    x = 1
    while x <= limit_n and time.time() < deadline:
        ok = True
        new_sums = []
        for b in B:
            v = x + b
            if v in used_sums:
                ok = False
                break
            new_sums.append(v)
        if ok:
            new_sums.append(2 * x)
            # also must not collide among themselves / duplicates handled by set add
            ns_set = set(new_sums)
            if len(ns_set) != len(new_sums):
                ok = False
            if ok:
                for v in new_sums:
                    if v in used_sums:
                        ok = False
                        break
        if ok:
            B.append(x)
            used_sums.update(new_sums)
        x += 1
    return B


def _random_sidon(k, n, tries, deadline):
    """Randomized Sidon set search in [0,n] of size ~k, keeping best found."""
    best = None
    best_sz = 0
    while time.time() < deadline:
        for _ in range(tries):
            cand = [0]
            sums = {0}
            attempts = 0
            target = random.randint(max(2, k - 4), k)
            while len(cand) < target and attempts < 60 * target:
                attempts += 1
                x = random.randint(1, n)
                local = []
                bad = False
                for b in cand:
                    v = x + b
                    if v in sums:
                        bad = True
                        break
                    local.append(v)
                if bad:
                    continue
                local.append(2 * x)
                seen = set()
                for v in local:
                    if v in sums or v in seen:
                        bad = True
                        break
                    seen.add(v)
                if bad:
                    continue
                cand.append(x)
                sums.update(local)
            if len(cand) > best_sz:
                best_sz = len(cand)
                best = cand[:]
    return best if best else [0]


def solve():
    """Return A with large |A-A| and small |A+A|."""
    deadline = time.time() + 110

    # Build a Sidon base set. Larger base => smaller ratio gap; aim for a few hundred.
    base = _greedy_sidon(200000, time_budget=15)
    if len(base) < 20:
        base = _random_sidon(300, 300000, 20, time.time() + 60)
    else:
        # try to enlarge / diversify with randomized Sidon search
        extra = _random_sidon(min(2000, max(len(base) + 200, 400)),
                              3_000_000, 10, time.time() + 50)
        if extra and len(extra) > len(base):
            base = extra

    base = sorted(set(base))
    n_base = len(base)

    # Scale so differences are distinct and large (avoid diff collisions from small values).
    scale = max(1, 10 ** 15 // (max(base) + 1) if max(base) > 0 else 1)
    scale = min(scale, 10 ** 9)
    A = [b * scale for b in base]
    A = sorted(set(A))

    best = A
    best_score = _score(best)

    # Local search: perturb a few elements, keep improvements.
    cur = best[:]
    cur_score = best_score
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        op = random.random()
        if op < 0.6 and len(cand) >= 2:
            i = random.randrange(len(cand))
            step = scale if random.random() < 0.7 else random.randint(1, scale)
            cand[i] += random.choice([-1, 1]) * step
        elif op < 0.8:
            cand.append(random.randint(0, 10 ** 15))
        elif len(cand) > 3:
            i = random.randrange(len(cand))
            cand.pop(i)
        cand = sorted(set(cand))
        if not cand:
            continue
        if max(abs(x) for x in cand) > 10 ** 15:
            continue
        if len(cand) > 4000:
            continue
        s = _score(cand)
        if s > cur_score or (s == cur_score and len(cand) > len(cur)):
            cur, cur_score = cand, s
            if s > best_score or (s == best_score and len(cand) > len(best)):
                best, best_score = cand[:], s
        elif random.random() < 0.02:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
