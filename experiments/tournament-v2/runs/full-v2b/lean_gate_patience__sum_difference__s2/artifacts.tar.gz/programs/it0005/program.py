# EVOLVE-BLOCK-START
"""Structured search: base-b digit sets (small sums, large differences) + local refinement."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1.0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) < 2:
        return -1.0, n
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, n


def _digits_set(b, maxdigit, ndigits):
    A = [0]
    for _ in range(ndigits):
        nxt = []
        for x in A:
            for d in range(1, maxdigit + 1):
                nxt.append(x * b + d)
        A = nxt
        if len(A) > 800:
            break
    return A


def solve():
    random.seed(12345)
    best = None
    best_score = -2.0
    deadline = time.time() + 100

    # Candidate structured families: base-b "digit" sets.
    candidates = []
    for b in (2, 3, 4, 5, 6, 7, 8, 10):
        for md in (b - 1, b, b + 1):
            for nd in (2, 3, 4, 5):
                A = _digits_set(b, md, nd)
                if 2 <= len(A) <= 4000:
                    candidates.append(A)

    for A in candidates:
        s, _ = _score(A)
        if s > best_score:
            best_score = s
            best = A[:]

    # Local refinement: perturb individual elements to improve score.
    if best is None:
        best = [1, 2, 3, 5, 8]
        best_score, _ = _score(best)

    cur = best[:]
    cur_score = best_score
    step = 1
    while time.time() < deadline:
        cand = cur[:]
        # mutate a few elements
        k = random.randint(1, 3)
        for _ in range(k):
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        # occasionally add/remove an element
        r = random.random()
        if r < 0.10 and len(cand) < 4000:
            cand.append(random.randint(-100, 100))
        elif r < 0.15 and len(cand) > 3:
            cand.pop(random.randrange(len(cand)))
        if len(set(cand)) < 2:
            continue
        s, _ = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
                step = 1
        elif random.random() < 0.05:
            cur, cur_score = best[:], best_score
        else:
            step = min(step + 1, 5)
    return sorted(set(best))
# EVOLVE-BLOCK-END
