# EVOLVE-BLOCK-START
"""Realize the classic construction: A = C + [0,k) where C is a small Sidon-like core
(all pairwise sums distinct) and [0,k) is an interval. Then
  A + A = (C+C) + [0,2k)   -> size ~ |C+C| + 2k
  A - A = (C-C) + [-k,k)   -> size ~ |C-C| + 2k
With C a Sidon set |C+C| ~ |C|^2/2 and |C-C| ~ |C|^2, so differences far outnumber sums.
|A| = |C|*k is large, which helps the size bonus. We sweep (|C|, k) to maximize the score."""
import math
import random
import time


def _sidon_greedy(n, rng):
    """Greedy Sidon set: pairwise sums (incl. doubles) distinct."""
    B = []
    sums = set()
    val = 0
    limit = 60 * n * n + 500
    while len(B) < n and val < limit:
        new = [val + b for b in B] + [2 * val]
        if all(s not in sums for s in new):
            B.append(val)
            sums.update(new)
        val += 1
    return B


def _diffsum_size(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def solve():
    rng = random.Random(20240607)
    best = None
    best_score = -1.0

    # Core Sidon sets of several sizes (cached).
    cores = {}
    for cn in (3, 4, 5, 6, 8, 10, 14, 20, 30):
        cores[cn] = _sidon_greedy(cn, rng)

    for cn, C in cores.items():
        if len(C) < 3:
            continue
        # scale core so it sits well above the interval
        scale = max(1, 4 * cn)
        Cscaled = [c * scale for c in C]
        for k in (1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 3900):
            size = len(Cscaled) * k
            if size > 4000:
                continue
            A = []
            for c in Cscaled:
                for t in range(k):
                    A.append(c + t)
            if len(A) > 4000:
                continue
            d, s = _diffsum_size(A)
            if s < 2 or d < 2:
                continue
            sc = math.log(d) / math.log(s) + (1 - 1 / len(A)) / 100
            if sc > best_score:
                best_score, best = sc, A

    if best is None:
        best = [0, 1, 2, 3]

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]

    # light polish: try shifting / trimming to refine ratio quickly
    return best


# EVOLVE-BLOCK-END
