"""Approach: structured 'digit-sum' sets (numbers with exactly k ones in binary)
have small sum sets and large difference sets. Broaden the search with:
 (a) full scan of (m,k) digit-sum sets and complements,
 (b) product/concatenation constructions combining two digit-sum sets,
 (c) a bounded hill-climbing refinement that adds/removes/swaps elements.
Score with numpy bitset shifts for speed."""
import math
import time
from itertools import combinations
import numpy as np


def _bitset_pair(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    n = a.shape[0]
    dmin = int(a[0] - a[-1])
    dmax = int(a[-1] - a[0])
    smin = int(a[0] + a[0])
    smax = int(a[-1] + a[-1])

    def make_bits(vals, lo, hi):
        width = hi - lo + 1
        words = (width + 63) // 64
        bits = np.zeros(words, dtype=np.int64)
        idx = vals - lo
        w = idx >> 6
        b = idx & 63
        np.bitwise_or.at(bits, w, (np.int64(1) << b).astype(np.int64))
        return bits

    diff = (a[:, None] - a[None, :]).ravel()
    dbits = make_bits(diff.astype(np.int64), dmin, dmax)
    ndistinct_d = int(np.unpackbits(dbits.view(np.uint8)).sum())

    ssum = (a[:, None] + a[None, :]).ravel()
    sbits = make_bits(ssum.astype(np.int64), smin, smax)
    ndistinct_s = int(np.unpackbits(sbits.view(np.uint8)).sum())

    return ndistinct_d, ndistinct_s


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _bitset_pair(a)
    if ns <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _digit_set(m, k):
    out = []
    for comb in combinations(range(m), k):
        v = 0
        for b in comb:
            v |= (1 << b)
        out.append(v)
    return out


def solve():
    deadline = time.time() + 100
    best = None
    best_s = -1.0
    NMAX = 4000

    def consider(A):
        nonlocal best, best_s
        A = sorted(set(A))
        n = len(A)
        if n < 2 or n > NMAX:
            return
        if max(abs(v) for v in A) > 10**15:
            return
        s = _score(A)
        if s > best_s:
            best_s = s
            best = A

    # (a) Digit-sum sets and complements.
    for m in range(6, 32):
        for k in range(1, m):
            size = math.comb(m, k)
            if size < 2 or size > NMAX:
                continue
            base = _digit_set(m, k)
            consider(base)
            full = (1 << m) - 1
            consider([full ^ v for v in base])
        if time.time() > deadline:
            break

    # (b) Product/concatenation constructions: A = {v + P*u} for a small digit
    # set and a large multiplier P, combining two digit-sum sets in different
    # bit ranges. This tends to keep sums overlapping in the high part while
    # differences spread in the low part.
    products = []
    for m1 in range(4, 16):
        for k1 in range(1, m1):
            s1 = math.comb(m1, k1)
            if s1 < 2 or s1 > 60:
                continue
            products.append(_digit_set(m1, k1))
    for m2 in range(4, 20):
        for k2 in range(1, m2):
            s2 = math.comb(m2, k2)
            if s2 < 2 or s2 > NMAX:
                continue
            high = _digit_set(m2, k2)
            for lo in products:
                if len(lo) * len(high) > NMAX:
                    continue
                P = 1 << (m2 + 2)
                A = [h * P + l for h in high for l in lo]
                consider(A)
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # (c) Bounded hill-climbing refinement of the best candidate: try adding
    # elements near the existing ones and removing elements.
    if best is not None:
        cur = list(best)
        cur_s = best_s
        steps = 0
        while time.time() < deadline and steps < 400:
            steps += 1
            improved = False
            # try removals
            for i in range(len(cur)):
                cand = cur[:i] + cur[i + 1:]
                s = _score(cand)
                if s > cur_s:
                    cur_s = s
                    cur = cand
                    improved = True
                    break
            if improved:
                continue
            # try additions near median of gaps
            gaps = [cur[i + 1] - cur[i] for i in range(len(cur) - 1)]
            med = sorted(gaps)[len(gaps) // 2] if gaps else 1
            mn, mx = min(cur), max(cur)
            trials = set()
            for x in cur:
                for d in (med, med // 2, med * 2, 1):
                    trials.add(x + d)
                    trials.add(x - d)
            for trial in trials:
                if trial in cur:
                    continue
                if len(cur) + 1 > NMAX:
                    break
                cand = sorted(cur + [trial])
                s = _score(cand)
                if s > cur_s:
                    cur_s = s
                    cur = cand
                    improved = True
                    break
            if not improved:
                break
        if cur_s > best_s:
            best = cur
            best_s = cur_s

    return best if best else [0, 1]
