# EVOLVE-BLOCK-START
"""Scalable construction:
1) Build a small Sidon-like base set B (distinct pairwise sums) via randomized greedy.
2) Embed B into integers using a geometric progression A = { sum_i b_i * M^i } with M
   chosen so large that differences stay distinct too. This pushes |A-A| toward |A|^2/2
   while |A+A| stays around |B+B| (small), maximizing the ratio and the size bonus.
"""
import math
import random
import time


def _check_sidon(b):
    sums = {}
    n = len(b)
    for i in range(n):
        for j in range(i, n):
            s = b[i] + b[j]
            if s in sums:
                return False
            sums[s] = (i, j)
    return True


def build_sidon_base(target, seed=12345, time_budget=6.0):
    """Greedy/randomized search for a Sidon-like set B of size ~target."""
    rng = random.Random(seed)
    deadline = time.time() + time_budget
    best = []
    while time.time() < deadline:
        b = []
        pool = list(range(0, max(50, target * target * 2)))
        rng.shuffle(pool)
        sums = set()
        for v in pool:
            ok = True
            new_sums = []
            for x in b:
                s = x + v
                if s in sums:
                    ok = False
                    break
                new_sums.append(s)
            if ok:
                s = v + v
                if s in sums:
                    ok = False
                else:
                    new_sums.append(s)
            if ok:
                b.append(v)
                sums.update(new_sums)
            if len(b) >= target:
                break
        if len(b) > len(best):
            best = b[:]
    return best


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    deadline = time.time() + 110

    best_A = None
    best_score = -1.0

    # Try a range of target sizes, pick the best-scoring one.
    # If B is a Sidon set: |A+A| ~ |B|^2/2, |A-A| ~ |B|^2 (via geometric embedding).
    # Larger |B| -> larger |A-A| -> better ratio; the bonus also grows with |A|.
    for trial, target in enumerate([40, 80, 120, 160, 200, 240, 280, 300]):
        if time.time() > deadline:
            break
        tb = min(8.0, deadline - time.time())
        if tb < 0.5:
            break
        base = build_sidon_base(target, seed=999 + trial, time_budget=tb)
        if len(base) < 2:
            continue
        n = len(base)
        # Embed into integers with a huge multiplier so differences stay distinct.
        # M must exceed max possible difference of two embedded values:
        # max_diff < n * (max(base)+1) * M^(n-1), choose M = (n * (max(base)+1)) + 2
        M = n * (max(base) + 1) + 2
        A = []
        for i, b in enumerate(base):
            A.append(b * (M ** i))
        # Ensure values fit in 1e15 constraint.
        if max(abs(x) for x in A) > 10**15:
            # Reduce M and n by trimming to fit.
            trim = len(A)
            while trim > 2:
                M2 = trim * (max(base[:trim]) + 1) + 2
                A2 = [base[i] * (M2 ** i) for i in range(trim)]
                if max(abs(x) for x in A2) <= 10**15:
                    A = A2
                    break
                trim -= 1
            else:
                continue
        s = _score(A)
        if s > best_score:
            best_score = s
            best_A = A

    if best_A is None:
        best_A = [7, 15, 18, 22, -3, -2]

    return list(set(best_A))
# EVOLVE-BLOCK-END
