# EVOLVE-BLOCK-START
"""Erdos-Turan / Sidon-style sets with a tunable scaling factor, searched
over a wide prime range using a fast numpy scorer.

A = {k*x + (x*x mod p) : x in [0,p)} for prime p and integer k ~ 2p.
Larger p gives |A-A| closer to p^2 while the modular perturbation keeps
sums colliding; a finer grid of k lets exact scoring find the best ratio.
"""
import math
import time
import numpy as np


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _score_np(v):
    """v: 1-D int64 numpy array of distinct integers."""
    n = v.size
    if n < 2:
        return 0.0
    d = np.unique(v[:, None] - v[None, :]).size
    s = np.unique(v[:, None] + v[None, :]).size
    if s == 0:
        return 0.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _build(p, k):
    x = np.arange(p, dtype=np.int64)
    v = k * x + (x * x) % p
    return np.unique(v)


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # wider prime range (larger n -> ratio closer to 2), capped so n <= 4000
    cand = [x for x in range(2, 2001) if _is_prime(x)]

    for p in cand:
        if time.time() > deadline:
            break
        # k must exceed p so cross terms separate; classic ET uses k = 2p.
        if p > 4000:
            break
        base = 2 * p
        ks = set()
        for delta in range(-6, 7):
            ks.add(base + delta)
        for extra in (p, p * p // 2, p * p - 1, p * p + 1, base * 2, base // 2):
            if extra > 0:
                ks.add(extra)
        for k in ks:
            if k <= 0:
                continue
            v = _build(p, k)
            n = v.size
            if n < 2 or n > 4000:
                continue
            s = _score_np(v)
            if s > best_score:
                best_score = s
                best = v.tolist()
    if best is None:
        best = _build(200, 400).tolist()
    return best
# EVOLVE-BLOCK-END
