# EVOLVE-BLOCK-START
"""Direct iterated local search maximizing log|A-A|/log|A+A|,
seeded with structured unions of translated Sidon blocks."""
import math
import random
import time


def _stats(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return -1.0, 0, 0
    diffs = set()
    sums = set()
    for x in s:
        for y in s:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if ns <= 1 or nd <= 1:
        return -1.0, nd, ns
    score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return score, nd, ns


def _score(a):
    return _stats(a)[0]


def _rand_set(n, span):
    vals = random.sample(range(span), n) if span >= n else [random.randrange(span) for _ in range(n)]
    return sorted(set(vals))


def _sidon(k, lim):
    """Randomized greedy Sidon set of size ~k with all pair sums distinct."""
    B = []
    used = set()
    tries = 0
    while len(B) < k and tries < 4000:
        tries += 1
        v = random.randrange(lim)
        ok = True
        for b in B:
            for c in B:
                if v + b == c + v:  # trivial
                    continue
            # check no collision with existing sums involving v
        new_sums = set()
        bad = False
        for b in B:
            s = v + b
            if s in used:
                bad = True
                break
            new_sums.add(s)
            d = v - b
        if not bad:
            # also ensure doubles don't collide
            for b in B:
                if 2 * v == v + b or 2 * b == v + v:
                    pass
            if (v + v) in used:
                continue
            used |= new_sums
            used.add(v + v)
            B.append(v)
    return B


def _block_union_candidate():
    """Union of translated copies of a Sidon block -> many sum collisions."""
    k = random.randint(10, 25)
    lim = random.choice([k * 40, k * 60, k * 80])
    B = _sidon(k, lim)
    if len(B) < 6:
        B = list(range(1, k + 1))
    lam = random.choice([1, 2, 3, 5, 11, 23])
    nb = random.randint(2, 5)
    step = random.choice([1, 2, 3, k, k * 2])
    A = []
    for j in range(nb):
        off = j * step * random.choice([1, 1, 2])
        for b in B:
            A.append(lam * b + off)
    return sorted(set(A))


def _ilp(seed, deadline, span):
    cur = sorted(set(seed))
    if len(cur) < 4:
        return cur, -1.0
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score

    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.55:
            i = random.randrange(len(cand))
            lo = min(cand) - 2 * span
            hi = max(cand) + 2 * span
            newv = random.randint(lo, hi)
            if newv in cand:
                continue
            cand[i] = newv
        elif r < 0.85:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-span, span)
        else:
            if random.random() < 0.5 and len(cand) < 300:
                cand.append(random.randint(min(cand) - span, max(cand) + span))
            elif len(cand) > 6:
                del cand[random.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 4:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.01:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    random.seed(987654321)
    start = time.time()
    deadline = start + 110

    best = None
    best_score = -1.0

    # Structured seeds first (Sidon block unions).
    for trial in range(400):
        if time.time() > deadline - 8:
            break
        seed = _block_union_candidate()
        if len(seed) < 4:
            continue
        span = max(2, (max(seed) - min(seed)) // 4)
        sub = time.time() + 0.25
        c, sc = _ilp(seed, sub, span)
        if sc > best_score:
            best, best_score = c[:], sc

    # Random seeds too.
    for trial in range(150):
        if time.time() > deadline - 8:
            break
        n = random.randint(30, 150)
        span = random.choice([n, int(n * 1.2), int(n * 1.5), int(n * 2), int(n * 3)])
        seed = _rand_set(n, span)
        sub = time.time() + 0.4
        c, sc = _ilp(seed, sub, max(2, span // 4))
        if sc > best_score:
            best, best_score = c[:], sc

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
        best_score = _score(best)

    c, sc = _ilp(best, deadline - 1.0, max(2, (max(best) - min(best)) // 4))
    if sc > best_score:
        best, best_score = c, sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
