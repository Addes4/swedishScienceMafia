# EVOLVE-BLOCK-START
"""Sidon-base geometric embedding: small sum set, large difference set."""
import math
import random
import time


def _greedy_sidon(n, limit, rng):
    """Greedily build a Sidon (B_2) set: all pairwise sums a+b (a<=b) distinct."""
    B = []
    sums = set()
    candidates = list(range(0, limit))
    rng.shuffle(candidates)
    for c in candidates:
        if len(B) >= n:
            break
        ok = True
        new_sums = [c + c]
        for b in B:
            s = c + b
            if s in sums or s in new_sums:
                ok = False
                break
            new_sums.append(s)
        if ok:
            for s in new_sums:
                sums.add(s)
            B.append(c)
    return B


def _embed(B, M):
    """Embed base set B into integers as sum b_i * M^i (positions -> huge gaps)."""
    A = []
    for i, b in enumerate(B):
        A.append(b * (M ** i))
    return A


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 100

    best = None
    best_score = -1.0

    # Try several base sizes and embeddings, keep the best scored.
    configs = []
    for n in (30, 60, 120, 250, 500, 1000, 1500, 2000, 3000, 3500):
        configs.append((n, 4 * n * n + 10))
    rng.shuffle(configs)

    for n, limit in configs:
        if time.time() > deadline:
            break
        B = _greedy_sidon(n, limit, rng)
        if len(B) < 2:
            continue
        # Embed: choose M large enough to keep differences distinct.
        # Differences b_i*M^i - b_j*M^j with distinct exponents are controlled
        # by M >> max|b|, so pick M based on base values.
        maxb = max(abs(b) for b in B) if B else 1
        M = maxb + 1
        A = _embed(B, M)
        # Bound absolute values to 1e15.
        if A and abs(A[-1]) > 10 ** 15:
            # Reduce: fall back to a smaller/linear spread using powers capped.
            continue
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A

    if best is None:
        # Fallback simple construction.
        best = [7, 15, 18, 22, -3, -2]

    # Deduplicate and clip to constraints.
    out = sorted(set(best))
    clipped = [x for x in out if abs(x) <= 10 ** 15]
    if len(clipped) < 2:
        clipped = [7, 15, 18, 22, -3, -2]
    return clipped[:4000]
# EVOLVE-BLOCK-END
