# EVOLVE-BLOCK-START
"""Construct A with distinct sums (Sidon-like) so |A+A| ~ |A|^2/2, then embed so differences
are spread out — maximizing log|A-A|/log|A+A| while keeping |A| large."""
import math
import random
import time


def _sidon_greedy(n, rng):
    """Greedily build a Sidon set B (all pairwise sums distinct) of size ~n."""
    B = []
    sums = set()
    limit = 10 * n * n + 100
    val = 1
    tries = 0
    while len(B) < n and val < limit and tries < 200000:
        tries += 1
        # check if adding val keeps sums distinct
        new_sums = [val + b for b in B] + [2 * val]
        if all(s not in sums for s in new_sums):
            B.append(val)
            sums.update(new_sums)
            # occasionally bump val more to spread
            val += 1 + rng.randint(0, 3)
        else:
            val += 1
    return B


def _embed(B, base):
    """Map Sidon set B into integers via powers of base so differences are distinct."""
    A = []
    for b in B:
        A.append(b * base)
    return A


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    rng = random.Random(12345)
    best = None
    best_score = -1.0
    deadline = time.time() + 110

    target_n = 300
    for attempt in range(40):
        if time.time() > deadline - 5:
            break
        n = target_n
        B = _sidon_greedy(n, rng)
        if len(B) < 3:
            continue
        # stretch with base multiplier to separate differences
        base = 1
        cand = B[:]
        sc = _score(cand)
        if sc > best_score:
            best_score, best = sc, cand

    # try bigger/near-limit sets too
    for n in (400, 500, 700, 900, 1200, 1500, 2000):
        if time.time() > deadline - 5:
            break
        B = _sidon_greedy(n, rng)
        if len(B) < 3:
            continue
        sc = _score(B)
        if sc > best_score:
            best_score, best = sc, B

    return sorted(set(best))


# EVOLVE-BLOCK-END
