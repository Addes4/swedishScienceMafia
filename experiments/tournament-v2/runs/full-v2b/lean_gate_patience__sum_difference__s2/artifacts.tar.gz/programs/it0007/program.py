"""Approach: Ruzsa-type construction.  A = { sum_{i} e_i b^i } style set chosen so that
A+A is small because many sums collide through carries, while A-A is large.  We test several
parameter families and pick the best exact score, plus a light local-search polish.
"""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _fast_score_size(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            sums.add(ai + aj)
        for j in range(n):
            diffs.add(ai - a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _ruzsa_like(m, k, base):
    """A = differences/sums collapse: take digits in base 'base' with m positions,
    each digit in {0..k}.  Many sums collide via carries => small sum set.
    The set is spread geometrically => large difference set."""
    A = [0]
    p = 1
    for _ in range(m):
        new = []
        for x in A:
            for d in range(k + 1):
                new.append(x + d * p)
        A = new
        p *= base
    return A


def _gt_construction(m, base):
    """A = { sum e_i b^i : e_i in {0,1} } (geometric digit cube)."""
    A = [0]
    p = 1
    for _ in range(m):
        A = [x for x in A] + [x + p for x in A]
        p *= base
    return A


def _local(a, deadline, seed=0):
    rng = random.Random(seed)
    a = list(set(a))
    best = a[:]
    best_s = _fast_score_size(best)
    cur = a[:]
    cur_s = best_s
    span = max(abs(x) for x in a) if a else 1
    step = max(1, span // 20)
    while time.time() < deadline:
        cand = cur[:]
        op = rng.random()
        if op < 0.7 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-step, -1, 1, 2, step])
        elif op < 0.85:
            cand.append(rng.randint(-span, span))
        elif len(cand) > 4:
            del cand[rng.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) > 60:
            continue
        s = _fast_score_size(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s >= best_s:
                best, best_s = cand[:], s
        elif rng.random() < 0.05:
            cur, cur_s = best[:], best_s
    return best, best_s


def _candidate_sets():
    cands = []
    # digit-cube constructions: sums collapse via carries
    for m in (4, 5, 6, 7, 8):
        for base in (2, 3, 4):
            A = _gt_construction(m, base)
            cands.append(A)
    # Ruzsa-like: digits 0..k
    for m in (3, 4, 5):
        for k in (1, 2, 3):
            for base in (2, 3, 4, 5):
                A = _ruzsa_like(m, k, base)
                cands.append(A)
    return cands


def solve():
    deadline = time.time() + 110
    best = None
    best_s = -1.0

    cands = _candidate_sets()
    for A in cands:
        if time.time() > deadline:
            break
        A = list(set(A))
        if len(A) > 4000:
            continue
        s = _fast_score_size(A)
        if s > best_s:
            best, best_s = A, s

    # polish the best candidates
    order = sorted(cands, key=lambda A: -_fast_score_size(list(set(A))))[:6]
    for idx, A in enumerate(order):
        if time.time() > deadline:
            break
        b, bs = _local(list(set(A)), min(deadline, time.time() + 12), seed=idx)
        if bs > best_s:
            best, best_s = b, bs

    while time.time() < deadline:
        b, bs = _local(best[:], min(deadline, time.time() + 8), seed=random.randrange(10 ** 6))
        if bs > best_s:
            best, best_s = b, bs

    return sorted(set(best))
