# EVOLVE-BLOCK-START
"""Bose-Chowla / Erdos-Turan Sidon sets in Z_{p^2-1}, best-of search."""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _prime_leq(n):
    while n >= 2 and not _is_prime(n):
        n -= 1
    return n


def _erdos_turan(p):
    """Sidon set in Z_{p^2-1}: A = {2p*x + (x^2 mod p) : x in [0,p)}."""
    mod = p * p - 1
    seen = set()
    out = []
    for x in range(p):
        v = (2 * p * x + (x * x) % p) % mod
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0
    cand = [x for x in range(2, 4001) if _is_prime(x)]
    for p in cand:
        if p > 4000:
            break
        if time.time() > deadline:
            break
        A = _erdos_turan(p)
        n = len(A)
        if n < 2 or n > 4000:
            continue
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A
    if best is None:
        best = _erdos_turan(_prime_leq(200))
    return best
# EVOLVE-BLOCK-END
