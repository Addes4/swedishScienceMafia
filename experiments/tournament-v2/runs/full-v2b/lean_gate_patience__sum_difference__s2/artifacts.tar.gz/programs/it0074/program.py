# EVOLVE-BLOCK-START
"""Two-copy (doubled) Erdos-Turan Sidon construction.

Base B = {k*x + (x*x mod p)} is a Sidon set: |B+B| ~ |B|^2/2, |B-B| ~ |B|^2.
Take A = B union (B + M) for a large stride M.  Differences across the two
copies spread out (keeping |A-A| near 4|B|^2) while the relation
(b+M)+(b'+M) = 2M + (b+b') and b+b' collide after centering, trimming the
sum set relative to the difference set.  We scan (p, k, M) by exact score.
"""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _base(p, k):
    """Erdos-Turan Sidon base B = {k*x + (x*x mod p)}."""
    seen = set()
    out = []
    for x in range(p):
        v = k * x + (x * x) % p
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


def _two_copy(B, M):
    return B + [v + M for v in B]


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # keep n = 2*p <= 4000
    cand = [x for x in range(2, 2001) if _is_prime(x)]

    for p in cand:
        if time.time() > deadline:
            break
        ks = [p, 2 * p - 1, 2 * p, 2 * p + 1]
        for k in ks:
            if k <= 0:
                continue
            B = _base(p, k)
            if len(B) < 2:
                continue
            span = max(B) - min(B)
            # stride M well beyond the base span so copies don't overlap
            for mult in (1, 2, 4, 8):
                M = (span + 1) * mult
                A = _two_copy(B, M)
                n = len(set(A))
                if n < 2 or n > 4000:
                    continue
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A
    if best is None:
        B = _base(200, 400)
        best = _two_copy(B, (max(B) - min(B) + 1))
    return best
# EVOLVE-BLOCK-END
