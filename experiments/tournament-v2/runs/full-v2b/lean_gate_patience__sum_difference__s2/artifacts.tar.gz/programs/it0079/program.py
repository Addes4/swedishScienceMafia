# EVOLVE-BLOCK-START
"""Erdos-Turan Sidon base randomized restarts + modulus folding scan.

Base B = {2pk + (k^2 mod p)} is a Sidon set. We then apply a folding map
x -> (x mod M) + c * (x // M) for a scan of (M, c), which wraps the
maximal-spread base so that many sums collide while differences stay
large.  Scored exactly, several hundred candidates.
"""
import math
import time
import random


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _primes_upto(n):
    sieve = bytearray([1]) * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for i in range(2, int(n ** 0.5) + 1):
        if sieve[i]:
            sieve[i*i::i] = bytearray(len(sieve[i*i::i]))
    return [i for i in range(n + 1) if sieve[i]]


def _erdos_turan(p):
    return [2 * p * k + (k * k) % p for k in range(p)]


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    primes = [p for p in _primes_upto(220) if p >= 11]

    for p in primes:
        if time.time() > deadline:
            break
        B = _erdos_turan(p)
        n = len(B)
        if n < 4:
            continue
        maxb = B[-1]
        # candidate moduli around base range and folds
        for M in [maxb // 2, maxb // 3, maxb // 4, p * p // 2, p * p,
                  p * p + 1, p * p - 1, 2 * p, 3 * p, 5 * p]:
            if M < n:
                continue
            for c in [1, 2, 3, 5, 7, 11]:
                A = [(b % M) + c * (b // M) for b in B]
                if len(set(A)) < n * 3 // 4:
                    continue
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = list(set(A))
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
