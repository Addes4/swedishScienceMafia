"""Approach: structured 'digit-sum' sets (numbers with exactly k ones in binary)
have small sum sets and large difference sets. Additionally try 'digit-cube'
sets A = {sum d_i * c_i} where c_i are small digit choices at geometric
positions -- these make sums collapse heavily (many multi-representations)
while differences stay comparatively distinct. Score with numpy bitset shifts
instead of O(n^2) Python sets."""
import math
import time
from itertools import combinations, product
import numpy as np


def _bitset_pair(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    n = a.shape[0]
    dmin = int(a[0] - a[-1])
    dmax = int(a[-1] - a[0])
    smin = int(a[0] + a[0])
    smax = int(a[-1] + a[-1])

    def make_bits(vals, lo, hi):
        width = hi - lo + 1
        words = (width + 63) // 64
        bits = np.zeros(words, dtype=np.int64)
        idx = vals - lo
        w = idx >> 6
        b = idx & 63
        np.bitwise_or.at(bits, w, (np.int64(1) << b).astype(np.int64))
        return bits

    diff = (a[:, None] - a[None, :]).ravel()
    dbits = make_bits(diff.astype(np.int64), dmin, dmax)
    ndistinct_d = int(np.unpackbits(dbits.view(np.uint8)).sum())

    ssum = (a[:, None] + a[None, :]).ravel()
    sbits = make_bits(ssum.astype(np.int64), smin, smax)
    ndistinct_s = int(np.unpackbits(sbits.view(np.uint8)).sum())

    return ndistinct_d, ndistinct_s


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _bitset_pair(a)
    if ns <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _digit_set(m, k):
    out = []
    for comb in combinations(range(m), k):
        v = 0
        for b in comb:
            v |= (1 << b)
        out.append(v)
    return out


def _digit_set_complement(m, k):
    full = (1 << m) - 1
    return [full ^ v for v in _digit_set(m, m - k)]


def _digit_cube(base, digits, m):
    """A = { sum_{i=0}^{m-1} digit_i * base^i : digit_i in digits }."""
    out = []
    for tup in product(digits, repeat=m):
        v = 0
        p = 1
        for d in tup:
            v += d * p
            p *= base
        out.append(v)
    return out


def solve():
    deadline = time.time() + 100
    best = None
    best_s = -1.0
    NMAX = 4000

    def consider(A):
        nonlocal best, best_s
        A = sorted(set(A))
        n = len(A)
        if n < 2 or n > NMAX:
            return
        if max(abs(v) for v in A) > 10**15:
            return
        s = _score(A)
        if s > best_s:
            best_s = s
            best = A

    # Digit-sum sets: numbers with exactly k ones in m bits.
    for m in range(6, 30):
        for k in range(1, m):
            size = math.comb(m, k)
            if size < 2 or size > NMAX:
                continue
            consider(_digit_set(m, k))
        if time.time() > deadline:
            break

    # Digit-cube sets: small sum sets via many multi-representations.
    # base b, alphabet of d digits, m positions; size = d^m <= NMAX.
    for base in range(3, 8):
        for d in range(2, 5):
            digits = tuple(range(d))
            for m in range(1, 40):
                size = d ** m
                if size < 2 or size > NMAX:
                    if size > NMAX:
                        break
                    continue
                A = _digit_cube(base, digits, m)
                consider(A)
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # Shifted/dilated variants of the best.
    if best is not None:
        for off in (0, 1, -1, 2, -2):
            candidate = [v + off for v in best]
            if max(abs(v) for v in candidate) <= 10**15:
                consider(candidate)
            if time.time() > deadline:
                break

    return best if best else [0, 1]
