# EVOLVE-BLOCK-START
"""Iterated local search maximizing log|A-A|/log|A+A|, seeded with
translated Sidon-block unions that create heavy sum collisions.
Scoring uses numpy for speed so many more moves fit in the time budget."""
import math
import random
import time
import numpy as np


def _stats_np(arr):
    """arr: 1-D numpy int64 array of distinct values."""
    n = arr.size
    if n < 2:
        return -1.0, 0, 0
    d = arr[:, None] - arr[None, :]
    s = arr[:, None] + arr[None, :]
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns <= 1 or nd <= 1:
        return -1.0, nd, ns
    score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return score, nd, ns


def _score_arr(arr):
    return _stats_np(arr)[0]


def _to_arr(a):
    return np.array(sorted(set(a)), dtype=np.int64)


def _stats(a):
    return _stats_np(_to_arr(a))


def _score(a):
    return _stats_np(_to_arr(a))[0]


def _rand_set(n, span):
    vals = random.sample(range(span), n) if span >= n else [random.randrange(span) for _ in range(n)]
    return sorted(set(vals))


def _sidon_base(n, span):
    """Greedy Sidon-ish base: keep pair sums mostly distinct."""
    vals = random.sample(range(span), min(span, n * 3))
    random.shuffle(vals)
    base = []
    sums = set()
    for v in vals:
        ok = True
        new_sums = set()
        for b in base:
            s = v + b
            if s in sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if 2 * v in sums:
            ok = False
        if ok:
            base.append(v)
            sums |= new_sums
            sums.add(2 * v)
            if len(base) >= n:
                break
    return sorted(base)


def _translated_union_seed():
    """A = union over t in T of (lam*B + t), T additively rich (many sum collisions)."""
    nb = random.randint(6, 16)
    base = _sidon_base(nb, 2000)
    if len(base) < 4:
        return None
    lam = random.choice([1000, 5000, 20000, 100000])
    nt = random.randint(4, 16)
    step = random.choice([1, 2, 3, 5])
    T = [random.randint(-100, 100) + step * i for i in range(nt)]
    gap = lam * (max(base) - min(base) + 2)
    T = [t + i * gap for i, t in enumerate(T)]
    A = []
    for t in T:
        for b in base:
            A.append(lam * b + t)
    A = sorted(set(A))
    if len(A) < 6:
        return None
    return A


def _ap_union_seed():
    """Union of translated copies of a flat AP block: translations form a long AP,
    maximizing sum collisions while differences stay mostly distinct."""
    block_len = random.randint(4, 12)
    nblocks = random.randint(4, 20)
    block_step = random.choice([1, 2, 3, 5, 10])
    # translations forming a long AP, far apart so cross-block differences distinct
    t_step = random.choice([1, 2, 3])
    sep = random.choice([10, 50, 200, 1000, 100000])
    A = []
    for j in range(nblocks):
        t = t_step * j + sep * j
        for i in range(block_len):
            A.append(t + block_step * i)
    A = sorted(set(A))
    if len(A) < 6:
        return None
    return A


def _ilp(seed, deadline, span):
    cur = sorted(set(seed))
    if len(cur) < 4:
        return cur, -1.0
    cur_arr = _to_arr(cur)
    cur_score = _score_arr(cur_arr)
    best = cur[:]
    best_score = cur_score

    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.55:
            i = random.randrange(len(cand))
            lo = min(cand) - 2 * span
            hi = max(cand) + 2 * span
            newv = random.randint(lo, hi)
            if newv in cand:
                continue
            cand[i] = newv
        elif r < 0.85:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-span, span)
        else:
            if random.random() < 0.5 and len(cand) < 400:
                cand.append(random.randint(min(cand) - span, max(cand) + span))
            elif len(cand) > 6:
                del cand[random.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 4:
            continue
        arr = _to_arr(cand)
        s = _score_arr(arr)
        if s > cur_score or random.random() < 0.01:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    random.seed(987654321)
    start = time.time()
    deadline = start + 110

    best = None
    best_score = -1.0

    # Structured seeds: translated Sidon-block unions.
    for _ in range(150):
        if time.time() > deadline - 10:
            break
        seed = _translated_union_seed()
        if not seed:
            continue
        span = max(2, (max(seed) - min(seed)) // 6)
        sub = time.time() + 0.35
        c, sc = _ilp(seed, sub, span)
        if sc > best_score:
            best, best_score = c[:], sc

    # Structured seeds: AP-block unions.
    for _ in range(150):
        if time.time() > deadline - 10:
            break
        seed = _ap_union_seed()
        if not seed:
            continue
        span = max(2, (max(seed) - min(seed)) // 6)
        sub = time.time() + 0.35
        c, sc = _ilp(seed, sub, span)
        if sc > best_score:
            best, best_score = c[:], sc

    # Random seeds.
    for trial in range(200):
        if time.time() > deadline - 10:
            break
        n = random.randint(30, 200)
        span = random.choice([n, int(n * 1.2), int(n * 1.5), int(n * 2), int(n * 3)])
        seed = _rand_set(n, span)
        sub = time.time() + 0.3
        c, sc = _ilp(seed, sub, max(2, span // 4))
        if sc > best_score:
            best, best_score = c[:], sc

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
        best_score = _score(best)

    c, sc = _ilp(best, deadline - 1.0, max(2, (max(best) - min(best)) // 4))
    if sc > best_score:
        best, best_score = c, sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
