# EVOLVE-BLOCK-START
"""Construction: use a Bose-Chowla / Singer difference set in Z_q (a "perfect
difference family"-like core with |C-C| ~ |C|^2 and only one sum per value),
then lift it by an interval:  A = C + [0,k) as a Minkowski sum in the integers.

For a scaled core C (distinct, all >0), we get
    A + A = (C+C) + [0, 2k)   size ~ |C+C| + 2k
    A - A = (C-C) + [-k, k)   size ~ |C-C| + 2k
Because a Singer/Bose-Chowla set has |C-C| ~ |C|^2 and |C+C| ~ |C|^2/2,
the log-ratio log|A-A|/log|A+A| is maximized by tuning k near |C+C|.

We compute optimal k analytically per core and only measure sizes exactly."""
import math
import time


def _bose_chowla(q):
    """Bose-Chowla Sidon set in Z_{q^2-1}: {i : theta^i - theta in GF(q^2)}
    mapped to integer representatives.  We use the standard element set of the
    Singer difference set, realized via powers of a primitive element of
    GF(q^2) written as x with x^2 = x + a (a primitive)."""
    # Work in GF(q^2) = GF(q)[x]/(x^2 - x - a) for a primitive element a of GF(q).
    # Find a primitive root of GF(q).
    def is_prime(n):
        if n < 2:
            return False
        i = 2
        while i * i <= n:
            if n % i == 0:
                return False
            i += 1
        return True

    def primitive_root_of_field(p):
        if p == 2:
            return 1
        # factor p-1
        m = p - 1
        fac = []
        d = 2
        while d * d <= m:
            if m % d == 0:
                fac.append(d)
                while m % d == 0:
                    m //= d
            d += 1
        if m > 1:
            fac.append(m)
        for g in range(2, p):
            if all(pow(g, (p - 1) // f, p) != 1 for f in fac):
                return g
        return 1

    a = primitive_root_of_field(q)

    def mul(u, v):
        # (u0 + u1 x)(v0 + v1 x) = u0v0 + u1v1*a + (u0v1 + u1v0 + u1v1) x
        return ((u[0] * v[0] + u[1] * v[1] * a) % q,
                (u[0] * v[1] + u[1] * v[0] + u[1] * v[1]) % q)

    def pw(e):
        r = (1, 0)
        b = (0, 1)  # x
        while e:
            if e & 1:
                r = mul(r, b)
            b = mul(b, b)
            e >>= 1
        return r

    n = q * q - 1
    elems = set()
    for i in range(n):
        u = pw(i)
        # map (u0,u1) -> u0 + u1*q  in [0, q^2)
        v = u[0] + u[1] * q
        elems.add(v)
    return sorted(elems)


def _diffsum_size(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _core_diffsum(C):
    d = set()
    s = set()
    for x in C:
        for y in C:
            d.add(x - y)
            s.add(x + y)
    return len(d), len(s)


def solve():
    t0 = time.time()
    budget = 110.0
    best = None
    best_score = -1.0

    # Candidate cores: small Bose-Chowla Singer sets (dense differences).
    cores = []
    for q in (7, 8, 9, 11, 13, 16, 17, 19, 23, 25, 27, 29, 31, 32):
        if q < 3:
            continue
        try:
            C = _bose_chowla(q)
        except Exception:
            continue
        if len(C) < 3:
            continue
        C = [c for c in C]
        cores.append(C)

    # Also include a few plain greedy Sidon sets scaled, as fallback diversity.
    def _sidon_greedy(n):
        B = []
        sums = set()
        val = 0
        limit = 60 * n * n + 500
        while len(B) < n and val < limit:
            new = [val + b for b in B] + [2 * val]
            if all(s not in sums for s in new):
                B.append(val)
                sums.update(new)
            val += 1
        return B

    for cn in (6, 8, 10, 12, 16, 20):
        cores.append(_sidon_greedy(cn))

    for C in cores:
        if len(C) < 3:
            continue
        # scale core so it's spread out and interval contributions are small
        scale = max(1, 4 * len(C))
        Cscaled = sorted(set(c * scale for c in C))
        cc_sum, cc_diff = _core_diffsum(Cscaled)
        if cc_sum < 2:
            continue
        # analytic: maximize log(cc_diff + 2k)/log(cc_sum + 2k)
        # try ks around balanced point 2k ~ cc_sum
        ks = set()
        for base in (cc_sum, cc_diff // 2, (cc_diff - cc_sum) // 2):
            for m in (1, 2, 3, 4, 6, 8, 12, 16):
                ks.add(max(1, (base * m) // 4))
        ks.update([1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096])

        for k in sorted(ks):
            if k < 1:
                continue
            size = len(Cscaled) * k
            if size > 4000 or size < 3:
                continue
            A = []
            for c in Cscaled:
                for t in range(k):
                    A.append(c + t)
            if time.time() - t0 > budget:
                break
            if len(A) < 3:
                continue
            d, s = _diffsum_size(A)
            if s < 2 or d < 2:
                continue
            sc = math.log(d) / math.log(s) + (1 - 1 / len(A)) / 100
            if sc > best_score:
                best_score, best = sc, A

    if best is None:
        best = [0, 1, 2, 3]

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    return best


# EVOLVE-BLOCK-END
