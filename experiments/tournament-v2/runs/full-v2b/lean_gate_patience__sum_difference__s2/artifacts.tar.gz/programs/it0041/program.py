import math
import random
import time


def _metrics(a):
    a = list(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2 or len(diffs) < 2:
        return 0.0, len(diffs), len(sums)
    sc = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / n) / 100
    return sc, len(diffs), len(sums)


def _greedy_add(A, pool, deadline, budget_time):
    """Add elements from pool one at a time choosing the one maximizing score."""
    A = list(A)
    nd, ns = _metrics(A)[1], _metrics(A)[2]
    cur = _metrics(A)[0]
    end = time.time() + budget_time
    while time.time() < end:
        best_gain = 0.0
        best_cand = None
        for c in pool:
            if c in A:
                continue
            cand = A + [c]
            sc, d2, s2 = _metrics(cand)
            if sc > cur + 1e-12:
                if sc - cur > best_gain:
                    best_gain = sc - cur
                    best_cand = c
        if best_cand is None:
            break
        A.append(best_cand)
        cur = _metrics(A)[0]
        if time.time() > deadline:
            break
    return A


def _sidon(target, deadline):
    best = []
    while time.time() < deadline:
        B = []
        used = set()
        while len(B) < target and time.time() < deadline:
            placed = False
            for _ in range(400):
                cand = random.randint(0, target * target * 4)
                if cand in B:
                    continue
                ok = True
                new_s = set()
                for x in B:
                    s = x + cand
                    if s in used or s in new_s:
                        ok = False
                        break
                    new_s.add(s)
                if ok and (cand + cand) not in used and (cand + cand) not in new_s:
                    B.append(cand)
                    used.add(cand + cand)
                    used |= new_s
                    placed = True
                    break
            if not placed:
                break
        if len(B) > len(best):
            best = B[:]
    return best


def solve():
    deadline = time.time() + 115
    best_A = [0, 1, 3, 7]
    best_sc = _metrics(best_A)[0]

    # Minkowski construction: A = B + [0,k)
    # small Sidon B, dense interval [0,k) -> small sum set, big difference set
    configs = []
    for kb in range(3, 10):
        for k in [10, 20, 40, 80, 160]:
            for scale in [1, 4, 16, 64]:
                configs.append((kb, k, scale))

    random.shuffle(configs)
    for kb, k, scale in configs:
        if time.time() > deadline - 10:
            break
        B = _sidon(kb, min(time.time() + 1.5, deadline - 10))
        if len(B) < 2:
            continue
        A = []
        for b in B:
            for j in range(k):
                A.append(b * scale * k + j)
        A = sorted(set(A))
        # greedy polish: try candidates that are sums/differences of existing
        sc = _metrics(A)[0]
        if sc > best_sc:
            best_sc, best_A = sc, A[:]

    # Greedy polish on the best found set
    if best_A:
        A = best_A[:]
        # candidate pool: sums of pairs (likely to keep sums small dense)
        pool = set()
        base = A[:]
        for i in range(len(base)):
            for j in range(i, len(base)):
                pool.add(base[i] + base[j])
                pool.add(base[i] - base[j])
        pool = [v for v in pool if v not in set(A)]
        random.shuffle(pool)
        pool = pool[:2000]
        A2 = _greedy_add(A, pool, deadline, max(1.0, deadline - time.time() - 2))
        sc = _metrics(A2)[0]
        if sc > best_sc:
            best_sc, best_A = sc, A2[:]

    return sorted(set(best_A))

