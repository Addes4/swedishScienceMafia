# EVOLVE-BLOCK-START
"""Direct optimization: search for finite sets A of moderate size that
maximize log|A-A| / log|A+A| (+ tiny size bonus), via simulated annealing
over element values. The asymptotic Sidon/interval families both cap the
log-ratio near 1, so we instead exploit the small/medium-n regime with an
exact-score local search that can genuinely balance a large difference set
against a small sum set."""
import math
import random
import time


def score(A):
    n = len(A)
    if n < 2:
        return -1.0
    diffs = len({x - y for x in A for y in A})
    sums = len({x + y for x in A for y in A})
    if sums < 1 or diffs < 1:
        return -1.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 110
    rng = random.Random(987654321)

    best_A = None
    best_sc = -1.0

    # Sizes to explore. Bonus (1-1/n)/100 is tiny, so the log-ratio dominates;
    # moderate n gives the search room to find skewed configurations.
    sizes = [12, 16, 20, 24, 28, 32, 40, 48, 56, 64, 80, 100]

    # Element value range: mixing small (dense) and slightly larger values lets
    # the optimizer create sum collisions while spreading differences.
    SPAN = 20000

    while time.time() < deadline:
        for n in sizes:
            if time.time() > deadline:
                break

            # --- initialization variants ---
            r = rng.random()
            if r < 0.35:
                # arithmetic progression start (few sums)
                A = list(range(n))
            elif r < 0.6:
                # AP plus a couple of far outliers
                A = list(range(n - 2)) + [rng.randint(3 * n, SPAN),
                                          rng.randint(3 * n, SPAN)]
                A = list(dict.fromkeys(A))
                while len(A) < n:
                    A.append(rng.randint(0, SPAN))
            else:
                A = rng.sample(range(0, SPAN), n)

            A = list(dict.fromkeys(A))
            if len(A) < n:
                A = list(range(n))

            cur = score(A)
            local_best = A[:]
            local_best_sc = cur
            T = 0.8
            steps = 0
            # bounded inner loop so we rotate over sizes/restarts within budget
            while time.time() < deadline and steps < 3000:
                steps += 1
                B = A[:]
                i = rng.randrange(n)
                if rng.random() < 0.75:
                    # small/large perturbations of a single element
                    delta = rng.choice([-3, -2, -1, 1, 2, 3, 5, 7, 11,
                                        20, 40, 100, 300, 1000])
                    B[i] = B[i] + delta
                elif rng.random() < 0.5:
                    B[i] = rng.randint(-2 * n, 2 * n)
                else:
                    B[i] = rng.randint(-SPAN, SPAN)
                if len(set(B)) < n:
                    continue
                ns = score(B)
                if ns >= cur or rng.random() < math.exp((ns - cur) / max(T, 1e-9)):
                    A = B
                    cur = ns
                    if ns > local_best_sc:
                        local_best_sc = ns
                        local_best = B[:]
                T *= 0.9993

            if local_best_sc > best_sc:
                best_sc = local_best_sc
                best_A = local_best[:]

    if best_A is None:
        best_A = list(range(12))

    # safety: keep distinct, within bound
    out = []
    seen = set()
    for x in best_A:
        x = int(x)
        if abs(x) > 10 ** 15:
            continue
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out if len(out) >= 2 else [0, 1]
# EVOLVE-BLOCK-END
