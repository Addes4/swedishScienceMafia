# EVOLVE-BLOCK-START
"""Build A greedily to maximize log|A-A|/log|A+A| using numpy bitset cardinalities.

Strategy: seed with a Sidon base (small sums), then greedily grow the set choosing the
candidate element that most improves the exact ratio, using fast bitset union sizes.
"""
import math
import random
import time

import numpy as np


def _card(diffs, sums):
    """Cardinality of difference and sum sets via numpy bit-array truth tables."""
    return int(diffs.sum()), int(sums.sum())


class BitsetScorer:
    """Incrementally tracks distinct sums/diffs as boolean bit arrays over a shifted range."""
    def __init__(self, maxabs):
        self.shift = maxabs
        self.size = 2 * maxabs + 2
        self.sums = np.zeros(self.size, dtype=bool)
        self.diffs = np.zeros(self.size, dtype=bool)
        self.nsum = 0
        self.ndiff = 0

    def add(self, a, existing):
        # compute new sum/diff positions and count newly-set bits
        s_vals = np.array([a + b for b in existing], dtype=np.int64) + self.shift
        d_vals = [a - b for b in existing]
        d_vals = np.array([d + self.shift for d in d_vals] + [-d + self.shift for d in d_vals], dtype=np.int64)
        d_vals = np.append(d_vals, 2 * self.shift)  # a - a = 0
        s_vals = np.append(s_vals, 2 * a + self.shift)
        # clip
        s_vals = s_vals[(s_vals >= 0) & (s_vals < self.size)]
        d_vals = d_vals[(d_vals >= 0) & (d_vals < self.size)]
        new_s = ~self.sums[s_vals]
        newsum = int(new_s.sum())
        self.sums[s_vals] = True
        self.nsum += newsum
        new_d = ~self.diffs[d_vals]
        newdiff = int(new_d.sum())
        self.diffs[d_vals] = True
        self.ndiff += newdiff
        return newsum, newdiff


def _greedy_sidon(limit_n, deadline):
    B = [0]
    used_sums = {0}
    x = 1
    while x <= limit_n and time.time() < deadline:
        ok = True
        new_sums = [0]
        for b in B:
            v = x + b
            if v in used_sums:
                ok = False
                break
            new_sums.append(v)
        if ok:
            new_sums.append(2 * x)
            if len(set(new_sums)) != len(new_sums):
                ok = False
            if ok:
                for v in new_sums:
                    if v in used_sums:
                        ok = False
                        break
        if ok:
            B.append(x)
            used_sums.update(new_sums)
        x += 1
    return B


def solve():
    deadline = time.time() + 110

    # Seed: greedy Sidon set in moderate range -> small sum set.
    base = _greedy_sidon(30000, time_budget=20)
    if len(base) < 20:
        base = list(range(30))

    # Scale to spread values out so differences stay distinct in the huge range.
    mx = max(base) if base else 1
    scale = max(1, (10 ** 15) // (2 * (mx + 1)))
    A = [b * scale for b in base]
    A = sorted(set(A))

    maxabs = max(abs(x) for x in A)
    scorer = BitsetScorer(maxabs + 1)
    for i, a in enumerate(A):
        scorer.add(a, A[:i])

    best = A
    best_ratio = -1.0
    if scorer.nsum > 1:
        best_ratio = math.log(scorer.ndiff) / math.log(scorer.nsum) + (1 - 1 / len(A)) / 100

    cur = A[:]
    cur_score = best_ratio

    # Local search: perturb single elements and accept improvements.
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.7 and len(cand) >= 2:
            i = random.randrange(len(cand))
            step = scale if random.random() < 0.7 else random.randint(1, max(1, scale))
            cand[i] += random.choice([-1, 1]) * step
        elif op < 0.85:
            cand.append(random.randint(0, 10 ** 15))
        elif len(cand) > 3:
            i = random.randrange(len(cand))
            cand.pop(i)
        cand = sorted(set(cand))
        if not cand:
            continue
        if max(abs(x) for x in cand) > 10 ** 15:
            continue
        if len(cand) > 4000:
            continue
        diffs = {x - y for x in cand for y in cand}
        sums = {x + y for x in cand for y in cand}
        if len(sums) < 2:
            continue
        s = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(cand)) / 100
        if s > cur_score or (s == cur_score and len(cand) > len(cur)):
            cur, cur_score = cand, s
            if s > best_ratio or (s == best_ratio and len(cand) > len(best)):
                best, best_ratio = cand[:], s
        elif random.random() < 0.03:
            cur = best[:]
            cur_score = best_ratio

    return sorted(set(best))
# EVOLVE-BLOCK-END
