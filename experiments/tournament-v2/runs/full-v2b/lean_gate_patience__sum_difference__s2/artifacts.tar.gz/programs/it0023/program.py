# EVOLVE-BLOCK-START
"""Sidon-style construction with modular dilation and local polish."""
import math
import random
import time


def _stats(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in s:
        for y in s:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return score, nd, ns


def _score(a):
    return _stats(a)[0]


def _greedy_sidon(limit, target):
    """Greedily build a set of small integers with all sums (x+y, x<=y) distinct,
    i.e. a Sidon set (B_2 set) in [0, limit)."""
    A = [0]
    used_sums = {0}
    cands = list(range(1, limit))
    random.shuffle(cands)
    for c in cands:
        if len(A) >= target:
            break
        new_sums = set()
        ok = True
        for x in A:
            s = x + c
            if s in used_sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if ok:
            new_sums.add(c + c)
            used_sums |= new_sums
            used_sums.add(c + c)
            A.append(c)
    return sorted(A)


def _dilate(A, m, shift):
    return sorted(x * m + shift for x in A)


def _local_polish(A, deadline, iters_cap=200000):
    """Local search over individual element perturbations, maximizing score."""
    A = sorted(set(A))
    best = A[:]
    best_score = _score(A)
    cur = A[:]
    step = max(1, (max(A) - min(A)) // (4 * max(1, len(A))))
    it = 0
    while time.time() < deadline and it < iters_cap:
        it += 1
        cand = cur[:]
        i = random.randrange(len(cand))
        delta = random.randint(-step, step)
        if delta == 0:
            delta = 1
        newv = cand[i] + delta
        if newv in cand and newv != cand[i]:
            continue
        cand[i] = newv
        cand = sorted(set(cand))
        if len(cand) < 4:
            continue
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
            step = max(1, (max(best) - min(best)) // (4 * len(best)))
        elif random.random() < 0.02:
            cur = best[:]


    return best


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    random.seed(12345)
    start = time.time()
    deadline = start + 110

    best = None
    best_score = -1.0

    # Try several sizes of the base Sidon set over a growing range.
    configs = []
    # For a Sidon set of size k in [0, N), roughly N ~ k^2 is needed.
    for k in (15, 20, 25, 30, 35, 40, 50, 60):
        limit = k * k + 10
        configs.append((k, limit))

    for (k, limit) in configs:
        if time.time() > deadline - 20:
            break
        base = _greedy_sidon(limit, k)
        if len(base) < 4:
            continue
        span = max(base) - min(base) or 1
        # Dilate so that differences stay distinct: choose modulus ~ span^2 and a large multiplier.
        n = len(base)
        # Rough bound: (#diffs) ~ n^2 if we spread well. Use multiplier > span^2.
        for m in (1, span + 1, span * span + 1, (span * span + 1) * 3):
            if time.time() > deadline - 15:
                break
            for shift in (0, m // 2):
                cand = _dilate(base, m, shift)
                # Try adding a few extra random integers to enlarge the difference set.
                s, nd, ns = _stats(cand)
                if s > best_score:
                    best_score, best = s, cand[:]
                # Random perturbations on this dilated base.
                polish_budget = 8.0
                sub_deadline = time.time() + polish_budget
                if sub_deadline > deadline - 5:
                    sub_deadline = deadline - 5
                if sub_deadline <= time.time():
                    continue
                pol = _local_polish(cand, sub_deadline, iters_cap=20000)
                s2, nd2, ns2 = _stats(pol)
                if s2 > best_score:
                    best_score, best = s2, pol[:]

    # Final polish on the current best.
    if best is None:
        best = [0, 1, 3, 7, 12, 20]
        best_score = _score(best)

    if time.time() < deadline - 20:
        pol = _local_polish(best, deadline - 2, iters_cap=500000)
        s = _score(pol)
        if s > best_score:
            best, best_score = pol, s

    return sorted(set(best))
# EVOLVE-BLOCK-END
