# EVOLVE-BLOCK-START
"""Sidon-style base with geometric (base-M) embedding.

Strategy:
  1. Build a Sidon-like set B via randomized greedy so that all pairwise sums
     b_i + b_j (i <= j) are distinct.  Such a B has |B+B| = |B|(|B|+1)/2,
     the theoretical minimum, so |A+A| will be ~|A|^2/2.
  2. Embed B into Z via a base-M representation: A = { sum b_i * M^i }.
     Choosing M large enough (M > 2*max spread of B) makes every pairwise
     difference a_i - a_j have a unique signed digit pattern (no carries in
     the leading nonzero coordinate deciding order), so A - A is essentially
     all of A x A: |A-A| ~ |A|^2.

This gives |A-A| ~ n^2 and |A+A| ~ n^2/2, i.e. ratio log(n^2)/log(n^2/2) -> 1
but with the set as large as possible, which maximizes the size bonus.
"""
import math
import random
import time

MAX_A = 4000
LIMIT = 10 ** 15


def _sidon_base(target_n, rng):
    """Build a Sidon set (all pairwise sums distinct) of size ~target_n.

    Uses a Singer-like/randomized greedy: repeatedly try to add the smallest
    candidate that keeps all pairwise sums distinct.
    """
    B = [0]
    sum_set = {0}
    cand = 1
    fails = 0
    while len(B) < target_n and fails < 200000:
        ok = True
        new_sums = []
        for b in B:
            s = cand + b
            if s in sum_set:
                ok = False
                break
            new_sums.append(s)
        if ok:
            for s in new_sums:
                sum_set.add(s)
            B.append(cand)
            fails = 0
        else:
            fails += 1
        cand += 1
    return B


def _embed(B, M):
    """Map B -> A via base-M digits: a_k = sum_i b_i * M^i (only nonzero digits)."""
    # Put digit i at position i, skip zero digits to keep values small.
    A = []
    for i, b in enumerate(B):
        if b == 0:
            continue
        A.append(b * (M ** i))
    return A


def _reflect_limits(A):
    """Shift/scale check: return A if within limits, else None."""
    for a in A:
        if abs(a) > LIMIT:
            return None
    return A


def _score_quick(A):
    A = list(set(A))
    n = len(A)
    if n < 2:
        return -1.0
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    if len(sums) < 2:
        return -1.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Candidate base sizes; bigger B => bigger |A| => bigger size bonus, and
    # ratio stays roughly the same as long as embedding is exact.
    base_sizes = [64, 96, 120, 150, 180, 200]

    for target_n in base_sizes:
        if time.time() > deadline:
            break
        B = _sidon_base(target_n, rng)
        n = len(B)
        if n < 4:
            continue
        # Base M must exceed the range of possible digit sums so the
        # digit representation of differences is unique (no carries).
        # Since each digit b_i in [0, max(B)] and we compare sums of
        # signed digits with coefficients in {-1,0,1}, we need
        # M > 2 * max(B) roughly.  Take a comfortable margin.
        maxB = max(B)
        M = 2 * maxB + 1
        # Also ensure magnitude stays <= 1e15.
        # Largest position is n-1, value ~ maxB * M^(n-1).
        # If too big, shrink n.
        while n >= 4 and maxB * (M ** (n - 1)) > LIMIT:
            n -= 1
            B = B[:n]
            if n >= 4:
                maxB = max(B)
                M = 2 * maxB + 1
        if n < 4:
            continue
        A = _embed(B, M)
        A = [a for a in A if a != 0]
        if not _reflect_limits(A):
            continue
        A = sorted(set(A))
        if len(A) < 2:
            continue
        sc = _score_quick(A)
        if sc > best_score:
            best_score = sc
            best = A

    if best is None:
        # Fallback small Sidon example.
        best = [0, 1, 4, 10, 18, 23]
    return sorted(set(best))
# EVOLVE-BLOCK-END
