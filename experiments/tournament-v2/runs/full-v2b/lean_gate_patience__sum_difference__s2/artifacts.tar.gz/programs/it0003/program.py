# EVOLVE-BLOCK-START
"""Ruzsa-style construction: A = B + C with B a dense interval (rich differences),
C a small base set chosen so that A + A collapses (small sum set)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _construction(B, C):
    """A = B + C."""
    return sorted({b + c for b in B for c in C})


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # B is a dense interval giving a near-complete difference set
    # C is a small base set; scale C far apart so differences stay distinct
    for blen in [20, 40, 60, 80, 120, 160, 200, 260, 320, 400]:
        B = list(range(blen))
        # candidate base sets: small sets; spread them to keep |A-A| large
        base_candidates = [
            [0],
            [0, 1],
            [0, 1, 3],
            [0, 1, 4],
            [0, 1, 5],
            [0, 1, 3, 7],
            [0, 1, 4, 10],
            [0, 1, 3, 9],
            [0, 1, 2, 5, 11],
        ]
        for C0 in base_candidates:
            # scale C so that translated copies of B don't overlap too much,
            # keeping A-A large; pick spacing around blen
            for spacing in [blen, blen + 1, 2 * blen, 3 * blen, 5 * blen]:
                C = [c * spacing for c in C0]
                A = _construction(B, C)
                if len(A) > 4000:
                    continue
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # Local refinement: perturb best set slightly
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-2, 2)
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s

    return sorted(set(best))
# EVOLVE-BLOCK-END
