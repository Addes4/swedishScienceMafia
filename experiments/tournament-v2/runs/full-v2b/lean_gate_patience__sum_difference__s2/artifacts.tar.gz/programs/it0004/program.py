# EVOLVE-BLOCK-START
"""Ruzsa-type construction: A = B + C with B a long interval and C a small base set,
chosen to maximize log|A-A|/log|A+A|. Searches over structured C candidates."""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return n, len(diffs), len(sums)


def _ratio(a):
    n = len(set(a))
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(B, C):
    return [b + c for b in B for c in C]


def _candidates():
    # Structured base sets C to try.
    cands = []
    cands.append([0, 1])
    cands.append([0, 1, 2])
    cands.append([0, 1, 3])
    cands.append([0, 1, 2, 4])
    cands.append([0, 1, 2, 3])
    cands.append([0, 1, 2, 4, 7])
    cands.append([0, 1, 2, 3, 5])
    cands.append([0, 1, 3, 4, 9])
    cands.append([0, 1, 2, 4, 8])
    cands.append([0, 1, 2, 4, 8, 16])
    cands.append([0, 1, 2, 3, 4])
    cands.append([0, 1, 2, 3, 4, 5])
    cands.append([0, 1, 2, 5, 7])
    cands.append([0, 1, 3, 7, 12])
    return cands


def solve():
    """Return A = B + C maximizing log|A-A|/log|A+A|."""
    best_a = [0, 1, 2, 4, 8]
    best_score = _ratio(best_a)
    deadline = time.time() + 100

    # Try interval B of various lengths with structured C.
    lengths = list(range(2, 40)) + [50, 60, 80, 100, 150, 200, 300]
    for C in _candidates():
        for L in lengths:
            B = list(range(L))
            a = _build(B, C)
            if len(set(a)) > 4000:
                continue
            s = _ratio(a)
            if s > best_score:
                best_score = s
                best_a = a
        if time.time() > deadline:
            break

    # Local refinement: adjust C by random perturbations (fast scoring).
    C = [0, 1, 2, 4, 8]
    L = 60
    while time.time() < deadline:
        cand_C = C[:]
        i = random.randrange(len(cand_C))
        cand_C[i] += random.choice([-2, -1, 1, 2])
        cand_C = sorted(set(cand_C))
        if len(cand_C) < 2 or len(cand_C) > 12:
            continue
        for Lc in (30, 45, 60, 80):
            a = _build(list(range(Lc)), cand_C)
            if len(set(a)) > 4000:
                continue
            s = _ratio(a)
            if s > best_score:
                best_score = s
                best_a = a
                C = cand_C
                L = Lc
                break

    return sorted(set(best_a))
# EVOLVE-BLOCK-END
