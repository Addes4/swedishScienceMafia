# EVOLVE-BLOCK-START
"""Mixed sum-collapsing / difference-spreading construction.

We build A as a union of a small interval [0,m) (whose internal sums
collapse into a short range) and a large scaled Sidon set M*Y (whose
internal sums are near-maximal but whose scaled spacing keeps the
difference set large).  We also retain the multi-level base-M dilation
of a Sidon core.  A small exact sweep over parameters picks the best.
"""
import math
import time

MAX_A = 4000
LIMIT = 10 ** 15


def _greedy_sidon(target, maxval):
    """Greedy Sidon set in [0, maxval] with all pairwise sums distinct."""
    B = [0]
    sums = {0}
    cand = 1
    while len(B) < target and cand <= maxval:
        ok = True
        for b in B:
            if cand + b in sums:
                ok = False
                break
        if ok:
            for b in B:
                sums.add(cand + b)
            sums.add(2 * cand)
            B.append(cand)
        cand += 1
    return B


def _score_quick(A):
    A = list(set(A))
    n = len(A)
    if n < 2:
        return -1.0
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    if len(sums) < 2:
        return -1.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0


def _build_multilevel(A0, M, L):
    cur = [0]
    for _ in range(L):
        cur = [x * M + c for x in cur for c in A0]
        if len(cur) > MAX_A:
            return None
    return sorted(set(cur))


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    def consider(A):
        nonlocal best, best_score
        if A is None:
            return
        A = sorted(set(A))
        n = len(A)
        if n < 2 or n > MAX_A:
            return
        if A[-1] > LIMIT or A[0] < -LIMIT:
            return
        sc = _score_quick(A)
        if sc > best_score:
            best_score = sc
            best = A

    # Precompute a large Sidon set we can slice.
    Ybig = _greedy_sidon(64, 20000)

    # --- Construction 1: [0,m) union M*(prefix of Sidon Y) ---
    for my in (4, 6, 8, 12, 16, 24, 32, 48):
        if time.time() > deadline:
            break
        Y = Ybig[:my]
        maxY = Y[-1] if Y else 0
        for m in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32):
            for M in (2 * maxY + 1, 4 * maxY + 1, 8 * maxY + 1, 16 * maxY + 1, 64, 256, 1024):
                if time.time() > deadline:
                    break
                A = list(range(m)) + [M * y for y in Y]
                if len(set(A)) != len(A):
                    continue
                if len(A) > MAX_A:
                    continue
                consider(A)

    # --- Construction 2: multi-level dilation of a Sidon core ---
    for C in (Ybig[:3], Ybig[:4], Ybig[:5], Ybig[:6], Ybig[:7], Ybig[:8]):
        maxC = max(C)
        base = 2 * maxC + 1
        for L in range(1, 7):
            if time.time() > deadline:
                break
            if len(C) ** L > MAX_A:
                break
            A = _build_multilevel(C, base, L)
            consider(A)

    # --- Construction 3: multi-level dilation, interval core ---
    for L in range(1, 7):
        if time.time() > deadline:
            break
        for m in (2, 3, 4, 5, 6, 8):
            if m ** L > MAX_A:
                continue
            A = _build_multilevel(list(range(m)), 2 * m + 1, L)
            consider(A)

    if best is None:
        best = Ybig[:6]
    return best
# EVOLVE-BLOCK-END
