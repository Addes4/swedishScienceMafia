# EVOLVE-BLOCK-START
"""Difference-set dilation construction.

Key idea: We want |A-A| ~ |A|^2 and |A+A| ~ |A|^2/2 simultaneously.
A single Sidon set gives both; a difference set gives big |A-A| but also
big |A+A|.  We combine them via a *multi-level* base-M embedding of a
Bose-Chowla core C in Z_p:

    A = { sum_t c_t * M^t : c_t in C (t=0..L-1) }

Because the base-M digit representation is unique for differences
(M chosen larger than twice the core spread), two differences that can
cancel in one digit position cannot cancel in the highest differing
position.  Hence |A-A| grows like |C-C|^L and |A+A| like |C+C|^L,
giving ratio  L*log|C-C| / (L*log|C+C|) = log|C-C|/log|C+C| which is
strictly better than a single Sidon core yields, while the set is huge
(so the size bonus is near 1).  We pick the (p, L) that maximises the
quick score subject to magnitude limits.
"""
import math
import time

MAX_A = 4000
LIMIT = 10 ** 15


def _bose_chowla(p):
    """Bose-Chowla Sidon set in Z_p: { i : theta^i = theta+1-ish }.

    Concretely for prime p, take the primitive root representation:
    B = { x in Z_p : x = g^i + g^{2i} for i }... but simplest known
    practical BC construction over Z_{p^2-1}: we instead build a
    Sidon set directly in Z_p via greedy, then use it as the core.
    """
    # Greedy Sidon set in Z_p for small p (all sums c+c' distinct mod p).
    B = [0]
    sums = {0}
    for cand in range(1, p):
        ok = True
        for b in B:
            s = (cand + b) % p
            if s in sums:
                ok = False
                break
        if ok:
            for b in B:
                sums.add((cand + b) % p)
            sums.add((cand * 2) % p) if False else None
            # add cand+cand too
            sums.add((2 * cand) % p)
            B.append(cand)
    return B


def _greedy_sidon(target, maxval):
    """Greedy Sidon set in [0, maxval] with all pairwise sums distinct."""
    B = [0]
    sums = {0}
    cand = 1
    while len(B) < target and cand <= maxval:
        ok = True
        new = []
        for b in B:
            s = cand + b
            if s in sums:
                ok = False
                break
        if ok:
            for b in B:
                sums.add(cand + b)
            sums.add(2 * cand)
            B.append(cand)
        cand += 1
    return B


def _score_quick(A):
    A = list(set(A))
    n = len(A)
    if n < 2:
        return -1.0
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    if len(sums) < 2:
        return -1.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0


def _build(A0, M, L):
    """A = { sum_t c_t * M^t }, c_t in A0, for t=0..L-1."""
    cur = [0]
    for _ in range(L):
        cur = [x * M + c for x in cur for c in A0]
        if len(cur) > MAX_A:
            return None
    return sorted(set(cur))


def solve():
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Core candidates: greedy Sidon sets of various sizes.
    cores = []
    for target in (3, 4, 5, 6, 7, 8):
        C = _greedy_sidon(target, 400)
        if len(C) >= 3:
            cores.append(C)

    for C in cores:
        if time.time() > deadline:
            break
        maxC = max(C)
        M = 2 * maxC + 1
        # Try dilation levels L; A size = |C|^L.
        for L in range(1, 9):
            if time.time() > deadline:
                break
            if len(C) ** L > MAX_A:
                break
            # magnitude check: max value ~ maxC * (M^(L-1)) ... precise build
            A = _build(C, M, L)
            if A is None:
                continue
            if A[-1] > LIMIT or A[0] < -LIMIT:
                continue
            if len(A) < 2:
                continue
            sc = _score_quick(A)
            if sc > best_score:
                best_score = sc
                best = A

    # Fallback evaluation of best if construction failed.
    if best is None:
        best = _greedy_sidon(6, 100)
    return sorted(set(best))
# EVOLVE-BLOCK-END
