"""Approach: structured 'digit-sum' sets (numbers with exactly k ones in binary)
have small sum sets and large difference sets. To evaluate many/large candidates
fast, score with numpy bitset shifts instead of O(n^2) Python sets. Scan a wide
range of (m, k) and pick the best."""
import math
import time
from itertools import combinations
import numpy as np


def _bitset_pair(a):
    """Given list of ints, return bitsets (as big ints) for the difference set
    and sum set using numpy bit packing. Values are shifted to be nonnegative."""
    a = np.array(sorted(set(a)), dtype=np.int64)
    n = a.shape[0]
    # difference set: values in [min-min? actually a_i - a_j] range
    dmin = int(a[0] - a[-1])
    dmax = int(a[-1] - a[0])
    smin = int(a[0] + a[0])
    smax = int(a[-1] + a[-1])

    def make_bits(vals, lo, hi):
        width = hi - lo + 1
        words = (width + 63) // 64
        bits = np.zeros(words, dtype=np.int64)
        idx = vals - lo
        w = idx >> 6
        b = idx & 63
        np.bitwise_or.at(bits, w, (np.int64(1) << b).astype(np.int64))
        return bits

    # differences
    diff = (a[:, None] - a[None, :]).ravel()
    dbits = make_bits(diff.astype(np.int64), dmin, dmax)
    ndistinct_d = int(np.unpackbits(dbits.view(np.uint8)).sum())

    # sums
    ssum = (a[:, None] + a[None, :]).ravel()
    sbits = make_bits(ssum.astype(np.int64), smin, smax)
    ndistinct_s = int(np.unpackbits(sbits.view(np.uint8)).sum())

    return ndistinct_d, ndistinct_s


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _bitset_pair(a)
    if ns <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _digit_set(m, k):
    out = []
    for comb in combinations(range(m), k):
        v = 0
        for b in comb:
            v |= (1 << b)
        out.append(v)
    return out


def solve():
    deadline = time.time() + 100
    best = None
    best_s = -1.0

    for m in range(6, 26):
        for k in range(1, m):
            size = math.comb(m, k)
            if size < 2 or size > 1500:
                continue
            A = _digit_set(m, k)
            s = _score(A)
            if s > best_s:
                best_s = s
                best = A
        if time.time() > deadline:
            break

    return sorted(set(best)) if best else [0, 1]
