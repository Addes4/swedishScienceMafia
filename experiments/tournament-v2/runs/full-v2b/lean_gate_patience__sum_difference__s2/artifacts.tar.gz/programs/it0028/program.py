# EVOLVE-BLOCK-START
"""Direct iterated local search maximizing log|A-A|/log|A+A|.

Seeds include random sets AND unions of short arithmetic progressions,
which create many additive collisions (small A+A) while differences stay
varied (large A-A).  Candidates are canonicalized by translation.
"""
import math
import random
import time


def _stats(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return -1.0, 0, 0
    diffs = set()
    sums = set()
    for x in s:
        for y in s:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if ns <= 1 or nd <= 1:
        return -1.0, nd, ns
    score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return score, nd, ns


def _score(a):
    return _stats(a)[0]


def _canon(a):
    a = sorted(set(a))
    if not a:
        return a
    m = a[0]
    return [x - m for x in a]


def _rand_set(n, span):
    vals = random.sample(range(span), n) if span >= n else [random.randrange(span) for _ in range(n)]
    return sorted(set(vals))


def _ap_union_set(nblocks, block_len, step, base_step, jitter):
    """Union of short arithmetic progressions with large random offsets."""
    vals = set()
    for _ in range(nblocks):
        start = random.randint(0, base_step)
        s = random.choice([step, step + random.randint(-jitter, jitter) if jitter else step])
        if s <= 0:
            s = 1
        for k in range(block_len):
            vals.add(start + k * s)
    return sorted(vals)


def _ilp(seed, deadline, span):
    """Iterated local search: perturb by swapping/replacing elements, exact scoring."""
    cur = _canon(seed)
    if len(cur) < 4:
        return cur, -1.0
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score

    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.55:
            i = random.randrange(len(cand))
            lo = min(cand) - 2 * span
            hi = max(cand) + 2 * span
            newv = random.randint(lo, hi)
            if newv in cand:
                continue
            cand[i] = newv
        elif r < 0.85:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-span, span)
        else:
            if random.random() < 0.5 and len(cand) < 300:
                cand.append(random.randint(min(cand) - span, max(cand) + span))
            elif len(cand) > 6:
                del cand[random.randrange(len(cand))]
        cand = _canon(cand)
        if len(cand) < 4:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.01:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    random.seed(987654321)
    start = time.time()
    deadline = start + 110

    best = None
    best_score = -1.0

    for trial in range(300):
        if time.time() > deadline - 8:
            break
        mode = random.random()
        if mode < 0.5:
            n = random.randint(20, 200)
            span = random.choice([n, int(n * 1.2), int(n * 1.5), int(n * 2), int(n * 3)])
            seed = _rand_set(n, span)
        else:
            # structured union of short APs -> many sum collisions
            nblocks = random.randint(2, 12)
            block_len = random.randint(3, 25)
            step = random.choice([1, 2, 3, 5, 7, 11, 13])
            base_step = random.randint(block_len, max(block_len + 1, block_len * 40))
            jitter = random.choice([0, 0, 1, 2])
            seed = _ap_union_set(nblocks, block_len, step, base_step, jitter)
        span_seed = max(2, (max(seed) - min(seed)) // 4) if len(seed) >= 2 else 8
        sub = time.time() + 0.4
        c, sc = _ilp(seed, sub, span_seed)
        if sc > best_score:
            best, best_score = c[:], sc

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
        best_score = _score(best)

    c, sc = _ilp(best, deadline - 1.0, max(2, (max(best) - min(best)) // 4))
    if sc > best_score:
        best, best_score = c, sc

    return _canon(best)
# EVOLVE-BLOCK-END
