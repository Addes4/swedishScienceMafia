# EVOLVE-BLOCK-START
"""Direct iterated local search maximizing log|A-A|/log|A+A|."""
import math
import random
import time


def _stats(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return -1.0, 0, 0
    diffs = set()
    sums = set()
    for x in s:
        for y in s:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if ns <= 1 or nd <= 1:
        return -1.0, nd, ns
    score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return score, nd, ns


def _score(a):
    return _stats(a)[0]


def _rand_set(n, span):
    vals = random.sample(range(span), n) if span >= n else [random.randrange(span) for _ in range(n)]
    return sorted(set(vals))


def _ilp(seed, deadline, span):
    """Iterated local search: perturb by swapping/replacing elements, exact scoring."""
    cur = sorted(set(seed))
    if len(cur) < 4:
        return cur, -1.0
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    n = len(cur)

    while time.time() < deadline:
        # random move type
        cand = cur[:]
        r = random.random()
        if r < 0.55:
            # replace a random element with a new value
            i = random.randrange(len(cand))
            lo = min(cand) - 2 * span
            hi = max(cand) + 2 * span
            newv = random.randint(lo, hi)
            if newv in cand:
                continue
            cand[i] = newv
        elif r < 0.85:
            # shift one element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-span, span)
        else:
            # add or remove an element
            if random.random() < 0.5 and len(cand) < 300:
                cand.append(random.randint(min(cand) - span, max(cand) + span))
            elif len(cand) > 6:
                del cand[random.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 4:
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.01:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def solve():
    random.seed(987654321)
    start = time.time()
    deadline = start + 110

    best = None
    best_score = -1.0

    # Seed with several sizes and spans. Small spans encourage sum collisions.
    for trial in range(200):
        if time.time() > deadline - 8:
            break
        n = random.randint(30, 150)
        span = random.choice([n, int(n * 1.2), int(n * 1.5), int(n * 2), int(n * 3)])
        seed = _rand_set(n, span)
        sub = time.time() + 0.4
        c, sc = _ilp(seed, sub, max(2, span // 4))
        if sc > best_score:
            best, best_score = c[:], sc

    if best is None:
        best = [0, 1, 3, 7, 12, 20]
        best_score = _score(best)

    # Long final polish.
    c, sc = _ilp(best, deadline - 1.0, max(2, (max(best) - min(best)) // 4))
    if sc > best_score:
        best, best_score = c, sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
