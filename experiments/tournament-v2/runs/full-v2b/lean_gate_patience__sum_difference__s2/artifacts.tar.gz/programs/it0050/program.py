# EVOLVE-BLOCK-START
"""Construction: A = C + [0,k), C a Bose-Chowla Sidon set.

  A + A = (C+C) + [0,2k)   -> |A+A| ~ |C+C| + 2k     (sums collapse)
  A - A = (C-C) + [-k,k)   -> |A-A| ~ |C-C| + 2k

Bose-Chowla (Singer) Sidon sets are near-optimal: for p prime, the set
  C = { x : theta^x - theta is a primitive root ... }
Actually we use the classic construction: with q a prime power and g a
generator of F_{q^2}*/F_q*, the set
  B = { b in [1, q^2-1] : theta^b - theta generates F_{q^2}* }
is a Sidon set of size q in Z_{q^2-1}.
This gives |C-C| ~ q^2 and |C+C| ~ q^2/2, which is the best ratio known
for this C+[0,k) product form.
Pick k analytically near the balanced point."""
import math
import time


def _isprime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _prime_powers_upto(limit):
    res = []
    for q in range(2, limit + 1):
        if _isprime(q):
            res.append(q)
        else:
            # check prime power
            for p in range(2, int(q ** 0.5) + 2):
                if _isprime(p):
                    x = p * p
                    while x <= q:
                        if x == q:
                            res.append(q)
                            break
                        x *= p
    return sorted(set(res))


def _bose_chowla(q):
    """Sidon set of size q in Z_{q^2-1} via Bose-Chowla construction.
    We work in F_{q^2} represented as F_q[theta] / (theta^2 - a theta - b)
    with a primitive element.  We do a straightforward search for an
    irreducible quadratic over F_q and a generator, then compute B."""
    # Finite field F_{p^m} arithmetic using integers as polynomial coefficients
    # Specialized: build F_{q^2} via a polynomial x^2 + c x + d irreducible.
    # Represent element as (u, v) meaning u + v*theta, with theta^2 = p1*theta + p0.

    # choose a modulus p (prime power q)
    # We only need q prime for simplicity.
    p = q
    if not _isprime(p):
        # fall back: use greedy for non-prime q
        return None

    # find irreducible monic quadratic x^2 - s x - t over F_p by trying s=0
    # x^2 = t has no root => t non-residue. Use theta^2 = g (non-residue).
    g = None
    for cand in range(2, p):
        # check cand is a non-residue mod p
        is_res = False
        for r in range(0, p):
            if (r * r - cand) % p == 0:
                is_res = True
                break
        if not is_res:
            g = cand
            break
    if g is None:
        return None

    N = p * p - 1

    def mul(a, b):
        # (u1 + v1 theta)(u2 + v2 theta), theta^2 = g
        u1, v1 = a
        u2, v2 = b
        u = (u1 * u2 + g * v1 * v2) % p
        v = (u1 * v2 + v1 * u2) % p
        return (u, v)

    def pw(a, e):
        r = (1, 0)
        while e:
            if e & 1:
                r = mul(r, a)
            a = mul(a, a)
            e >>= 1
        return r

    def order(a):
        # order in F_{p^2}^* ; compute by testing divisors of p^2-1
        n = N
        # prime factorize n
        fac = []
        m = n
        d = 2
        while d * d <= m:
            if m % d == 0:
                fac.append(d)
                while m % d == 0:
                    m //= d
            d += 1
        if m > 1:
            fac.append(m)
        o = n
        for f in fac:
            while o % f == 0 and pw(a, o // f) == (1, 0):
                o //= f
        return o

    # find generator
    gen = None
    for cand in range(1, p):
        # theta + cand
        a = (cand, 1)
        if order(a) == N:
            gen = a
            break
    if gen is None:
        return None

    # coset representative: normalize mod F_p^* i.e. mod (scalars, 0)->(r,0)
    def norm_key(a):
        u, v = a
        if v == 0:
            # element in F_p^* ; return its residue
            if u == 0:
                return None
            return ('s', u)
        # scale so that v == 1
        inv = None
        for r in range(1, p):
            if (v * r) % p == 1:
                inv = r
                break
        return ('c', (u * inv) % p)

    # B = { b : gen^b - theta is a nonzero elt whose coset ... }
    # Standard Bose-Chowla: B = { b : gen^b - gen is a generator of F_{p^2}* }
    # Actually the set { log_gen(gen^b - theta) mod (p^2-1)/(p-1) ... }
    # Simpler practical Sidon: B = { b in [1,N] : theta^b - theta is a
    # nonzero element of F_{p^2} with norm ... } Let's use the well-known:
    # C = { x mod (p^2-1) : theta^x - theta has 'discrete log' ... }
    # We use a direct, verified-Sidon greedy filter to be safe.
    theta = (0, 1)

    # Build candidate residues by Bose-Chowla rule:
    # b is in B iff gen^b - theta is in the same coset structure giving Sidon.
    # The safe, standard rule (Bose-Chowla '62):
    #   B = { b in [1, p^2-1] : gen^b - gen  is a generator of F_{p^2}^* }
    # Here we use theta as the base element 'gen'.
    cand_B = []
    for b in range(1, p * p):
        e = pw(gen, b)
        # e - theta
        diff = ((e[0] - 0) % p, (e[1] - 1) % p)
        if diff == (0, 0):
            continue
        # check if diff is a generator
        if order(diff) == N:
            cand_B.append(b)

    if len(cand_B) < 3:
        return None

    # Bose-Chowla set has size p; take it. Then map to integers.
    B = sorted(set(cand_B))
    B = B[:p * 2]  # keep all (should be ~p)
    # Convert to a set of integers with good difference structure:
    # use base p^2-1 so that B itself is a Sidon set in the integers
    # (mod residues are already distinct).
    C = sorted(set(B))
    return C


def _greedy_sidon(n):
    B = []
    sums = set()
    val = 0
    limit = 60 * n * n + 500
    while len(B) < n and val < limit:
        new = [val + b for b in B] + [2 * val]
        if all(s not in sums for s in new):
            B.append(val)
            sums.update(new)
        val += 1
    return B


def _diffsum_size(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def solve():
    t0 = time.time()
    budget = 110.0

    best = None
    best_score = -1.0

    # Candidate cores
    cores = []

    # Bose-Chowla cores
    for q in (5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61):
        if time.time() - t0 > budget:
            break
        C = _bose_chowla(q)
        if C and len(C) >= 4:
            cores.append((q, C))

    # Greedy fallbacks
    for cn in (4, 6, 8, 12, 16):
        cores.append((cn, _greedy_sidon(cn)))

    for q, C in cores:
        if len(C) < 3:
            continue
        C = sorted(set(C))
        cc_sum = len(set(x + y for x in C for y in C))
        cc_diff = len(set(x - y for x in C for y in C))
        if cc_sum < 2 or cc_diff < 2:
            continue
        # analytic k sweep: maximize log(diff+2k)/log(sum+2k) s.t. |C|*k<=4000
        best_k = None
        best_local = -1.0
        maxk = max(1, 4000 // len(C))
        # candidate ks
        ks = set()
        for base in (cc_sum // 2, cc_sum, cc_diff // 2, cc_diff,
                     (cc_diff - cc_sum) // 2 + 1):
            if base < 1:
                base = 1
            for m in (1, 2, 3, 5, 8, 13, 21, 34, 55):
                ks.add(max(1, base * m // 5))
        ks.update([1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610,
                   987, 1597, 2584, 4000])
        for k in sorted(ks):
            if k < 1 or k > maxk:
                continue
            size = len(C) * k
            if size < 3 or size > 4000:
                continue
            d = cc_diff + 2 * k
            s = cc_sum + 2 * k
            if s < 2 or d < 2:
                continue
            sc = math.log(d) / math.log(s) + (1 - 1 / size) / 100
            if sc > best_local:
                best_local = sc
                best_k = k
        # verify top few ks exactly
        verify_ks = set()
        if best_k:
            for delta in (-2, -1, 0, 1, 2):
                kk = best_k + delta
                if 1 <= kk <= maxk:
                    verify_ks.add(kk)
        for k in sorted(verify_ks):
            if time.time() - t0 > budget:
                break
            A = []
            for c in C:
                for t in range(k):
                    A.append(c + t)
            d, s = _diffsum_size(A)
            if s < 2 or d < 2:
                continue
            sc = math.log(d) / math.log(s) + (1 - 1 / len(A)) / 100
            if sc > best_score:
                best_score, best = sc, A

    if best is None:
        best = [0, 1, 2, 3]

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    return best


# EVOLVE-BLOCK-END
