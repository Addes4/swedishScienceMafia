# EVOLVE-BLOCK-START
"""Bose-Chowla style Sidon construction with exact numpy scoring."""
import math
import random
import time
import numpy as np


def _stats(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    nd = len(diffs)
    ns = len(sums)
    score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return score, nd, ns


def _score(a):
    return _stats(a)[0]


def _is_prime(x):
    if x < 2:
        return False
    if x % 2 == 0:
        return x == 2
    i = 3
    while i * i <= x:
        if x % i == 0:
            return False
        i += 2
    return True


def _primes_near(target):
    res = []
    p = int(target)
    while len(res) < 6 and p > 2:
        if _is_prime(p):
            res.append(p)
        p -= 1
    p = int(target) + 1
    cnt = 0
    while len(res) < 12 and cnt < 400:
        if _is_prime(p):
            res.append(p)
            cnt += 1
        p += 1
    return sorted(set(res))


def _bose_chowla(p):
    """A = {i + p*(i^2 mod p) : i=0..p-1}. Sidon mod p^2 (Bose-Chowla-ish).

    Sums i+j and i^2+j^2 determined -> sums x+y distinct when using
    the map i -> i + p*(i*i mod p). Differences also spread because
    the quadratic residue part varies."""
    A = []
    for i in range(p):
        A.append(i + p * ((i * i) % p))
    return sorted(set(A))


def _vary(p, a, b):
    """A = {a*i^2 mod p lifted + b*i} generalized embedding."""
    A = []
    for i in range(p):
        A.append(b * i + p * ((a * i * i) % p))
    return sorted(set(A))


def _local_polish(A, deadline, iters_cap=200000):
    A = sorted(set(A))
    best = A[:]
    best_score = _score(A)
    cur = A[:]
    span = (max(A) - min(A)) if len(A) > 1 else 1
    step = max(1, span // (4 * max(1, len(A))))
    it = 0
    while time.time() < deadline and it < iters_cap:
        it += 1
        cand = cur[:]
        i = random.randrange(len(cand))
        delta = random.randint(-step, step)
        if delta == 0:
            delta = 1
        newv = cand[i] + delta
        if newv in cand and newv != cand[i]:
            continue
        cand[i] = newv
        cand = sorted(set(cand))
        if len(cand) < 4:
            continue
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
            span = (max(best) - min(best)) if len(best) > 1 else 1
            step = max(1, span // (4 * len(best)))
        elif random.random() < 0.02:
            cur = best[:]
    return best


def solve():
    random.seed(20240517)
    start = time.time()
    deadline = start + 105

    best = None
    best_score = -1.0

    # Try various primes for the Bose-Chowla construction.
    targets = [55, 60, 63, 65, 70, 75, 80]
    seen = set()
    for t in targets:
        for p in _primes_near(t):
            if p in seen:
                continue
            seen.add(p)
            if time.time() > deadline - 30:
                break
            for (a, b) in ((1, 1), (1, 2), (2, 1), (1, 3)):
                cand = _vary(p, a, b)
                if len(cand) < 4:
                    continue
                s, nd, ns = _stats(cand)
                if s > best_score:
                    best_score, best = s, cand[:]

    if best is None:
        best = _bose_chowla(7)
        best_score = _score(best)

    # Local polish on the current best.
    if time.time() < deadline - 20:
        pol = _local_polish(best, deadline - 2, iters_cap=300000)
        s = _score(pol)
        if s > best_score:
            best, best_score = pol, s

    return sorted(set(best))
# EVOLVE-BLOCK-END
