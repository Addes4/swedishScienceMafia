# EVOLVE-BLOCK-START
"""Multi-copy shifted Bose-Chowla construction, with fast bitset counting.

B is a Bose-Chowla Sidon base of size q with distinct pairwise sums.
A = union_{t=0}^{k-1} (B + t*M).

Small |A+A|: choose M ~ spread(B+B) so adjacent sum-bands overlap, giving
about (2k-1) bands instead of k^2 bands of pairs.
Large |A-A|: distinct shifts make the difference set nearly fully spread.

Counting |A+A| and |A-A| exactly is the bottleneck.  We use Python big-int
bitsets: numerator/denominator popcounts of OR of shifted bitsets, so a
candidate can be scored in O(n * words) big-int operations rather than
materialising all n^2 pairs with numpy.  This lets us scan many more
(q, k, M) candidates within the time budget.
"""
import time
import math


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _bose_chowla(q):
    return [2 * q * k + (k * k) % q for k in range(q)]


def _bitset_size(A):
    lo = min(A)
    return lo


def _count_bits(A):
    """Exact |A+A| and |A-A| via big-int bitsets.  A a sorted list."""
    lo = min(A)
    hi = max(A)
    # shift everything to non-negative
    a = [x - lo for x in A]
    # sums: range [0, 2*hi_shift]
    hiS = max(a) * 2
    # build bitset for sums
    # For each value, OR a shifted bitset representing its row a[i]+a[j]
    sums = 0
    # use a representation of the set as a bitset over offsets
    # setbits[k] = 1 if k in a
    setbits = 0
    for x in a:
        setbits |= (1 << x)
    # for each x, row bitset = setbits << x
    for x in a:
        sums |= (setbits << x)
    ns = bin(sums).count("1")
    # differences: values a[i]-a[j], range [-max(a), max(a)]
    # shift by max(a) to make non-negative
    m = max(a)
    diffs = 0
    for x in a:
        # x - a[j] in [-m, m], shift by m -> [0, 2m]
        diffs |= (setbits << (m - x))
    nd = bin(diffs).count("1")
    return ns, nd


def solve():
    deadline = time.time() + 100.0
    best_val = -1.0
    best_A = [0, 1]

    qs = [q for q in range(20, 320) if _is_prime(q)]

    for q in qs:
        if time.time() > deadline:
            break
        B = _bose_chowla(q)
        spreadB = max(B) - min(B)
        sumspan = 2 * spreadB

        m_cands = set()
        m_cands.add(spreadB + 1)
        m_cands.add(sumspan)
        m_cands.add(2 * spreadB + 1)
        for k in range(2, 10):
            if k:
                m_cands.add(sumspan // k)
                m_cands.add(sumspan // (2 * k))
                m_cands.add(sumspan // (3 * k))
            m_cands.add(spreadB + 1)
        # also try finely spaced M around sumspan/k
        for k in range(2, 10):
            base = sumspan // k
            for delta in (-3, -2, -1, 0, 1, 2, 3):
                v = base + delta
                if v > 0:
                    m_cands.add(v)

        for M in m_cands:
            if M <= 0:
                continue
            for k in range(2, 10):
                if time.time() > deadline:
                    break
                n = k * q
                if n > 4000:
                    continue
                vals = set()
                for t in range(k):
                    off = t * M
                    for b in B:
                        vals.add(b + off)
                if len(vals) != n:
                    continue
                A = sorted(vals)
                ns, nd = _count_bits(A)
                if ns < 2:
                    continue
                val = math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0
                if val > best_val:
                    best_val = val
                    best_A = A

    return best_A
# EVOLVE-BLOCK-END
