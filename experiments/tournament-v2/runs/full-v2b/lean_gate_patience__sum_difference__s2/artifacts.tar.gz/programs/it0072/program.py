# EVOLVE-BLOCK-START
"""Multi-copy Sidon construction.

Base B is an Erdos-Turan Sidon set B = {2p*x + (x^2 mod p) : x in [0,p)}.
We build A as several translated copies of B placed on a large arithmetic
progression with stride S.  Differences between different copies stay large
(distinct offsets), while sums across copies collapse because copy sums land
on a common progression, keeping |A+A| well below n^2.
"""
import math
import time


def _score(a):
    a = list(a)
    if len(a) < 2:
        return 0.0
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _base(p):
    """Erdos-Turan Sidon base."""
    return [2 * p * x + (x * x) % p for x in range(p)]


def _build_multi(p, T, S, cap=4000):
    B = _base(p)
    seen = set()
    out = []
    for t in range(T):
        off = t * S
        for v in B:
            w = v + off
            if w not in seen:
                seen.add(w)
                out.append(w)
    if len(out) > cap:
        out = out[:cap]
    return out


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # base primes: keep base size moderate so total set fits in 4000
    primes = [x for x in range(5, 300) if _is_prime(x)]

    for p in primes:
        if time.time() > deadline:
            break
        base = _base(p)
        span = max(base) - min(base)
        # stride options: place copies far apart so differences stay distinct
        strides = [span + 1, span + p, 2 * span + 1, 3 * span + 1,
                   (span + 1) * 2, (span + 1) * 3]
        for S in strides:
            for T in range(2, max(3, 4000 // p) + 1):
                if time.time() > deadline:
                    break
                A = _build_multi(p, T, S)
                n = len(A)
                if n < 2 or n > 4000:
                    continue
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A
            if time.time() > deadline:
                break
    if best is None:
        best = _base(50)
    return best
# EVOLVE-BLOCK-END
