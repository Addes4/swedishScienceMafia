# EVOLVE-BLOCK-START
"""Bose-Chowla style Sidon set: many differences, few sums.

For a prime p, the set A = { i + p*(i^2 mod p) : i = 0..p-1 } lifted mod M = p^2 - 1
is a Sidon set modulo M: all pairwise sums i+j + p*(i^2+j^2) are distinct, and the
sums modulo M realize ~ k(k+1)/2 distinct values while differences realize ~ k(k-1)+1.
Choosing p ~ sqrt(target size) gives an optimal ratio; we lift to large integers.
"""
import math
import time


def _score(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return 0.0
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _bose_chowla(p):
    """Sidon set of size p from the finite field GF(p^2)."""
    M = p * p - 1
    A = []
    for i in range(p):
        A.append((i + p * (i * i % p)) % M)
    return A


def solve():
    deadline = time.time() + 60

    best = None
    best_score = -1.0

    # Try many primes; larger p gives larger sets with optimal ratio.
    primes = []
    p = 4000
    while p >= 2 and len(primes) < 200:
        if _is_prime(p):
            primes.append(p)
        p -= 1
    # also some smaller primes spread out
    for q in range(3, 4000, 197):
        if _is_prime(q) and q not in primes:
            primes.append(q)

    maxabs = 10 ** 15

    for p in primes:
        if time.time() > deadline:
            break
        base = _bose_chowla(p)
        base = sorted(set(base))
        k = len(base)
        if k < 2:
            continue
        mx = max(base)
        if mx <= 0:
            continue
        scale = max(1, maxabs // mx)
        A = sorted({b * scale for b in base})
        if len(A) != k:
            continue
        sc = _score(A)
        if sc > best_score or (sc == best_score and (best is None or len(A) > len(best))):
            best_score = sc
            best = A[:]

    # Also try a direct large Sidon set: use p large (near 4000) if it fits.
    # p up to ~3999 gives size up to ~3999; verify feasibility against maxabs.
    for p in (2000, 2500, 3000, 3500, 3999):
        if not _is_prime(p) or time.time() > deadline:
            continue
        base = sorted(set(_bose_chowla(p)))
        mx = max(base)
        if mx <= 0:
            continue
        scale = max(1, maxabs // mx)
        A = sorted({b * scale for b in base})
        if len(A) > 4000:
            continue
        sc = _score(A)
        if sc > best_score or (sc == best_score and (best is None or len(A) > len(best))):
            best_score = sc
            best = A[:]

    if best is None:
        best = [0, 1]
    return sorted(set(best))
# EVOLVE-BLOCK-END

