"""Structured 'digit-sum' sets: numbers < m^k-like with fixed digit sum, which
have small sum sets and large difference sets. We scan many such configs using a
fast exact scorer and pick the best ratio."""
import math
import time
from itertools import combinations


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _digit_set(m, k):
    """Numbers < 2^m with exactly k ones in binary."""
    out = []
    for comb in combinations(range(m), k):
        v = 0
        for b in comb:
            v |= (1 << b)
        out.append(v)
    return out


def solve():
    deadline = time.time() + 100
    best = None
    best_s = -1.0

    # scan digit-sum sets; keep n under a size we can score quickly
    for m in range(6, 23):
        for k in range(1, m):
            A = _digit_set(m, k)
            if len(A) < 2 or len(A) > 800:
                continue
            s = _score(A)
            if s > best_s:
                best_s = s
                best = A
        if time.time() > deadline:
            break

    return sorted(set(best)) if best else [0, 1]
