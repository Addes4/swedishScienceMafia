import math
import random
import time


def _metrics(a):
    a = list(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2 or len(diffs) < 2:
        return 0.0, len(diffs), len(sums)
    sc = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / n) / 100
    return sc, len(diffs), len(sums)


def _build(P, Q, C, bias=0):
    A = set()
    for q in Q:
        off = q * C + bias
        for p in P:
            A.add(p + off)
    return sorted(A)


def _make_sidon(t, deadline, lo=0):
    """Greedy randomized Sidon set (all pairwise sums distinct)."""
    best = []
    hi = lo + t * t * 4 + 10
    while time.time() < deadline:
        B = [lo]
        used = {2 * lo}
        tries = 0
        while len(B) < t and tries < t * 400:
            tries += 1
            cand = random.randint(lo + 1, hi)
            if cand in B:
                continue
            ok = True
            new = set()
            for x in B:
                s = x + cand
                if s in used or s in new:
                    ok = False
                    break
                new.add(s)
            if ok and (cand + cand) not in used and (cand + cand) not in new:
                B.append(cand)
                used |= new
                used.add(cand + cand)
        if len(B) > len(best):
            best = B[:]
        if len(best) >= t:
            break
    return best


def solve():
    deadline = time.time() + 110
    best_A = []
    best_sc = -1.0

    # Additively rich small base P: many sums collide -> small |P+P|.
    rich_P_sets = [
        [0, 1, 2, 3, 4],                 # arithmetic progression
        [0, 1, 2, 4, 5, 6],              # union of two APs
        [0, 1, 2, 3, 4, 5, 6],           # longer AP
        [0, 1, 3, 4, 6, 7],              # near-AP
        [0, 1, 2, 4, 5, 6, 8, 9, 10],    # 3 APs
        [0, 1, 2, 3, 8, 9, 10, 11],      # 2 APs away
    ]

    t0 = time.time()
    sidon_budget = max(15.0, (deadline - t0) * 0.4)

    # Sweep Sidon sizes for Q and scale C, and P options.
    sidon_sizes = [8, 10, 12, 14, 16, 18, 20]
    scales = [1000, 4000, 16000, 64000, 256000, 10**6]

    cache = {}
    for t in sidon_sizes:
        if time.time() > deadline - 20:
            break
        sd = min(time.time() + sidon_budget / max(1, len(sidon_sizes)), deadline - 20)
        Q = _make_sidon(t, sd)
        if len(Q) < 3:
            continue
        cache[t] = Q
        # shift Q to start at 0
        mn = min(Q)
        Q0 = [q - mn for q in Q]
        for P in rich_P_sets:
            for C in scales:
                if time.time() > deadline - 15:
                    break
                A = _build(P, Q0, C)
                if max(abs(x) for x in A) > 10**15:
                    continue
                sc, nd, ns = _metrics(A)
                if sc > best_sc:
                    best_sc, best_A = sc, A[:]

    # Direct greedy refinement: try extending the best set with a coarse
    # translation (new Sidon element scaled), keeping the metric.
    if best_A:
        A = best_A[:]
        cur_sc = best_sc
        # infer C from spacing
        As = sorted(A)
        if len(As) > 1:
            gaps = [As[i + 1] - As[i] for i in range(len(As) - 1) if As[i + 1] > As[i]]
            Capprox = min(gaps) if gaps else 1
        else:
            Capprox = 1
        Capprox = max(1, Capprox // max(1, len(rich_P_sets[0])) + 1)

        iters = 0
        while time.time() < deadline and iters < 60000:
            iters += 1
            mode = random.random()
            cand = A[:]
            if mode < 0.5:
                # add a full new block
                P = random.choice(rich_P_sets)
                q = random.randint(-5, max(A) // max(1, Capprox) + 5)
                off = q * Capprox
                for p in P:
                    cand.append(p + off)
            elif mode < 0.8:
                # perturb a whole block by shifting scale C
                C2 = Capprox * (1 + random.choice([-1, 1]) * random.random() * 0.5)
                C2 = int(max(1, C2))
                # rebuild using stored Q of one size if available
                if cache:
                    t = max(cache)
                    Q = cache[t]
                    mn = min(Q)
                    Q0 = [q - mn for q in Q]
                    P = random.choice(rich_P_sets)
                    cand = _build(P, Q0, C2)
            else:
                if len(cand) > 8:
                    for _ in range(random.randint(1, 3)):
                        if cand:
                            cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2 or len(cand) > 4000:
                continue
            if max(abs(v) for v in cand) > 10**15:
                continue
            sc, nd, ns = _metrics(cand)
            if sc > cur_sc:
                A, cur_sc = cand, sc
                if sc > best_sc:
                    best_sc, best_A = sc, cand[:]

    if not best_A:
        best_A = [0, 1, 3, 7, 12, 20]
    return sorted(set(best_A))
