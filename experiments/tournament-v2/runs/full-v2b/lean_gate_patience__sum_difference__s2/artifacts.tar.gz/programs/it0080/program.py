# EVOLVE-BLOCK-START
"""Reflection construction: A = B ∪ (M - B) where B is an Erdos-Turan Sidon set.

For a Sidon B: |B-B| ~ n^2, |B+B| ~ n^2/2.
Cross-sums b + (M - b') = M + (b - b') range over an affine image of B-B (~n^2 values),
but crucially cross-differences b - (M - b') = (b+b') - M range over an affine image of
B+B (~n^2/2 values), which is SMALLER. So the reflection swaps which set is large:
differences grow relative to sums. Combined with within-copy contributions, we scan
p and M by exact score to find the best log|A-A|/log|A+A|.
"""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _primes_upto(n):
    sieve = bytearray([1]) * (n + 1)
    sieve[0:2] = b"\x00\x00"
    for i in range(2, int(n ** 0.5) + 1):
        if sieve[i]:
            sieve[i*i::i] = bytearray(len(sieve[i*i::i]))
    return [i for i in range(n + 1) if sieve[i]]


def _erdos_turan(p):
    return [2 * p * k + (k * k) % p for k in range(p)]


def _make_reflection(B, M):
    # A = B union (M - B), deduplicated, sorted
    A = set(B)
    for b in B:
        A.add(M - b)
    return sorted(A)


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    primes = _primes_upto(700)

    for p in primes:
        if time.time() > deadline:
            break
        B = _erdos_turan(p)
        span = B[-1] - B[0]
        # M controls the separation between the two copies; scan a range
        for M in [span + 1, span + p, 2 * span + 1, 3 * span + p]:
            A = _make_reflection(B, M)
            if len(A) < 2 or len(A) > 4000:
                continue
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A
        if time.time() > deadline:
            break

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
