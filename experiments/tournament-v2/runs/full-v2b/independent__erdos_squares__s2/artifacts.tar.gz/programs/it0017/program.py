import math
import random

def _corners(cx, cy, a, s):
    c = math.cos(2.0 * math.pi * a)
    sn = math.sin(2.0 * math.pi * a)
    h = 0.5 * s
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * c - dy * sn
        y = cy + dx * sn + dy * c
        pts.append((x, y))
    return pts

def _inside(cx, cy, a, s):
    if s <= 0.0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    c = abs(math.cos(2.0 * math.pi * a))
    sn = abs(math.sin(2.0 * math.pi * a))
    r = 0.5 * s * (c + sn)
    return cx - r >= -1e-12 and cx + r <= 1.0 + 1e-12 and cy - r >= -1e-12 and cy + r <= 1.0 + 1e-12

def _overlap_area(p, q):
    # separating axis theorem for convex polygons
    cx1, cy1, a1, s1 = p
    cx2, cy2, a2, s2 = q
    if s1 <= 0.0 or s2 <= 0.0:
        # point or zero square: tiny overlap if point strictly inside other square
        if s1 <= 0.0 and s2 <= 0.0:
            return 0.0
        if s1 <= 0.0:
            cx1, cy1, s1, cx2, cy2, a2, s2 = cx1, cy1, 0.0, cx2, cy2, a2, s2
        if s2 <= 0.0:
            return 0.0
    A = _corners(cx1, cy1, a1, s1)
    B = _corners(cx2, cy2, a2, s2)
    axes = []
    for poly in (A, B):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            axes.append((-(y2 - y1), x2 - x1))
    best = 1e18
    for ax, ay in axes:
        nrm = math.hypot(ax, ay)
        if nrm < 1e-15:
            continue
        ax /= nrm
        ay /= nrm
        pmin = pmax = A[0][0] * ax + A[0][1] * ay
        for x, y in A[1:]:
            v = x * ax + y * ay
            if v < pmin:
                pmin = v
            if v > pmax:
                pmax = v
        qmin = qmax = B[0][0] * ax + B[0][1] * ay
        for x, y in B[1:]:
            v = x * ax + y * ay
            if v < qmin:
                qmin = v
            if v > qmax:
                qmax = v
        gap = min(pmax, qmax) - max(pmin, qmin)
        if gap <= 0.0:
            return 0.0
        if gap < best:
            best = gap
    return best * best

def _score(squares):
    total = 0.0
    for _, _, _, s in squares:
        total += s
    return total

def _feasible(squares):
    m = len(squares)
    for i in range(m):
        pi = squares[i]
        if not _inside(pi[0], pi[1], pi[2], pi[3]):
            return False
        for j in range(i + 1, m):
            if _overlap_area(pi, squares[j]) > 1e-9:
                return False
    return True

def _place_one(squares, s, rng, tries=40):
    best = None
    best_pen = 1e18
    for _ in range(tries):
        a = rng.random()
        c = abs(math.cos(2.0 * math.pi * a))
        sn = abs(math.sin(2.0 * math.pi * a))
        r = 0.5 * s * (c + sn)
        if r > 0.5:
            continue
        cx = rng.uniform(r, 1.0 - r)
        cy = rng.uniform(r, 1.0 - r)
        cand = (cx, cy, a, s)
        pen = 0.0
        for q in squares:
            ov = _overlap_area(cand, q)
            if ov > 0.0:
                pen += ov
        if pen < best_pen - 1e-15:
            best_pen = pen
            best = cand
            if pen <= 1e-12:
                break
    return best, best_pen

def _local_search(squares, idx, rng, iters=30):
    cur = squares[idx]
    best = cur
    best_pen = 0.0
    for j, q in enumerate(squares):
        if j != idx:
            best_pen += _overlap_area(cur, q)
    step = 0.08
    for _ in range(iters):
        improved = False
        for _ in range(6):
            nx = best[0] + rng.uniform(-step, step)
            ny = best[1] + rng.uniform(-step, step)
            na = best[2] + rng.uniform(-step, step)
            ns = best[3]
            if not _inside(nx, ny, na, ns):
                continue
            cand = (nx, ny, na, ns)
            pen = 0.0
            for j, q in enumerate(squares):
                if j != idx:
                    pen += _overlap_area(cand, q)
            if pen < best_pen - 1e-15:
                best_pen = pen
                best = cand
                improved = True
        if not improved:
            step *= 0.5
            if step < 1e-6:
                break
    squares[idx] = best
    return best_pen

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    best_squares = None
    best_total = -1.0
    rng = random.Random(12345 + n)
    restarts = 12 if n <= 20 else 6
    for _ in range(restarts):
        squares = []
        # Try descending sizes from a reasonable upper envelope.
        for i in range(n):
            # Initial size guess: fit one square at best possibly with rotation
            guess = 1.0 / math.sqrt(n + 1)
            # For early squares, try larger starting guesses
            if i < max(1, n // 3):
                guess *= 1.6
            elif i < 2 * max(1, n // 3):
                guess *= 1.15
            s = min(guess, 1.0)
            tries = 30
            for attempt in range(12):
                placed, pen = _place_one(squares, s, rng, tries=tries)
                if placed is not None and pen <= 1e-9:
                    squares.append(placed)
                    _local_search(squares, len(squares) - 1, rng, iters=15)
                    if _overlap_area(squares[-1], squares[-1]) > 1e-9:
                        pass
                    break
                s *= 0.82
                tries = max(12, tries // 2)
            else:
                # give up: add point
                squares.append((0.5, 0.5, 0.0, 0.0))
        # improve each square iteratively by adjusting size locally
        for _ in range(2):
            for i in range(n):
                base = squares[i]
                if base[3] <= 1e-12:
                    # try to give it some size
                    for s in (0.03, 0.02, 0.01, 0.005):
                        placed, pen = _place_one(squares[:i] + squares[i+1:], s, rng, tries=40)
                        if placed is not None and pen <= 1e-9:
                            squares[i] = placed
                            break
                    continue
                # try slight growth
                for grow in (1.08, 1.04, 1.02, 1.01):
                    ns = base[3] * grow
                    if ns > 1.0:
                        continue
                    cand = (base[0], base[1], base[2], ns)
                    if not _inside(*cand):
                        # recenter as far as possible
                        a = base[2]
                        c = abs(math.cos(2.0 * math.pi * a))
                        sn = abs(math.sin(2.0 * math.pi * a))
                        r = 0.5 * ns * (c + sn)
                        if r > 0.5:
                            continue
                        cand = (min(max(base[0], r), 1.0 - r), min(max(base[1], r), 1.0 - r), a, ns)
                    pen = 0.0
                    for j, q in enumerate(squares):
                        if j != i:
                            pen += _overlap_area(cand, q)
                    if pen <= 1e-9:
                        squares[i] = cand
                        break
        # remove overlap by shrinking randomly if any remains
        for _ in range(100):
            any_ov = False
            for i in range(n):
                for j in range(i + 1, n):
                    ov = _overlap_area(squares[i], squares[j])
                    if ov > 1e-9:
                        any_ov = True
                        # shrink the smaller one
                        si = squares[i][3]
                        sj = squares[j][3]
                        k = i if si <= sj else j
                        x, y, a, s = squares[k]
                        if s <= 1e-9:
                            squares[k] = (0.5, 0.5, 0.0, 0.0)
                        else:
                            ns = s * 0.9
                            c = abs(math.cos(2.0 * math.pi * a))
                            sn = abs(math.sin(2.0 * math.pi * a))
                            r = 0.5 * ns * (c + sn)
                            if r > 0.5:
                                squares[k] = (0.5, 0.5, 0.0, 0.0)
                            else:
                                nx = min(max(x, r), 1.0 - r)
                                ny = min(max(y, r), 1.0 - r)
                                squares[k] = (nx, ny, a, ns)
            if not any_ov:
                break
        total = _score(squares)
        if total > best_total + 1e-12 and _feasible(squares):
            best_total = total
            best_squares = list(squares)
    if best_squares is None:
        # fallback: grid
        k = math.isqrt(n)
        side = 1.0 / k
        best_squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        best_squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_squares))
    best_squares = best_squares[:n]
    while len(best_squares) < n:
        best_squares.append((0.5, 0.5, 0.0, 0.0))
    # final cleanup
    for i in range(len(best_squares)):
        cx, cy, a, s = best_squares[i]
        if not _inside(cx, cy, a, s):
            if s > 0:
                c = abs(math.cos(2.0 * math.pi * a))
                sn = abs(math.sin(2.0 * math.pi * a))
                r = 0.5 * s * (c + sn)
                if r <= 0.5:
                    cx = min(max(cx, r), 1.0 - r)
                    cy = min(max(cy, r), 1.0 - r)
                else:
                    s = 0.0
                    cx = cy = 0.5
            else:
                cx = min(max(cx, 0.0), 1.0)
                cy = min(max(cy, 0.0), 1.0)
            best_squares[i] = (cx, cy, a, s)
    return best_squares
