import math
import random

def _overlap_ok(sq, placed, eps=1e-9):
    # conservative: check if axis-aligned bounding circles overlap
    cx, cy, a, s = sq
    r = s * 0.7071067811865476
    for (px, py, pa, ps) in placed:
        pr = ps * 0.7071067811865476
        if (cx - px) ** 2 + (cy - py) ** 2 >= (r + pr) ** 2:
            continue
        # detailed polygon overlap test (SAT for convex polygons)
        if _poly_overlap(cx, cy, a, s, px, py, pa, ps, eps):
            return False
    return True

def _corners(cx, cy, a, s):
    ang = a * 2 * math.pi
    c, si = math.cos(ang), math.sin(ang)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * si, cy + dx * si + dy * c))
    return pts

def _sep_axis(pts, axis):
    mn = mx = pts[0][0] * axis[0] + pts[0][1] * axis[1]
    for p in pts[1:]:
        v = p[0] * axis[0] + p[1] * axis[1]
        if v < mn: mn = v
        if v > mx: mx = v
    return mn, mx

def _poly_overlap(cx, cy, a, s, px, py, pa, ps, eps):
    A = _corners(cx, cy, a, s)
    B = _corners(px, py, pa, ps)
    for poly in (A, B):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            ax = -(y2 - y1)
            ay = (x2 - x1)
            L = math.hypot(ax, ay)
            if L < 1e-15:
                continue
            ax /= L; ay /= L
            mn1, mx1 = _sep_axis(A, (ax, ay))
            mn2, mx2 = _sep_axis(B, (ax, ay))
            if mx1 <= mn2 + eps or mx2 <= mn1 + eps:
                return False
    return True

def _in_unit(sq, eps=1e-9):
    cx, cy, a, s = sq
    if s <= 0:
        return 0 <= cx <= 1 and 0 <= cy <= 1
    if s > 1 + 1e-9:
        return False
    for (x, y) in _corners(cx, cy, a, s):
        if x < -eps or x > 1 + eps or y < -eps or y > 1 + eps:
            return False
    return True

def _fits(sq, placed, eps=1e-9):
    return _in_unit(sq, eps) and _overlap_ok(sq, placed, eps)

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    random.seed(12345)

    # start with best grid
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) >= n:
                break
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        if len(squares) >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]

    # greedy insertion for remaining zero-size
    placed = [s for s in squares if s[3] > 0]
    remaining = [(s[0], s[1], s[2], s[3]) for s in squares if s[3] == 0]

    # try to place as large a square as possible in remaining gaps
    for idx in range(len(remaining)):
        best = None
        best_size = -1.0
        # sample random candidates
        for _ in range(800):
            cx = random.random()
            cy = random.random()
            a = random.random()
            # binary search max size
            lo, hi = 0.0, 1.0
            for _bs in range(30):
                mid = (lo + hi) * 0.5
                cand = (cx, cy, a, mid)
                if _fits(cand, placed, eps=1e-6):
                    lo = mid
                else:
                    hi = mid
            if lo > best_size:
                # refine
                cand = (cx, cy, a, lo)
                if _fits(cand, placed, eps=1e-7):
                    best = cand
                    best_size = lo
        if best is not None and best_size > 1e-6:
            placed.append(best)
            remaining[idx] = best

    squares = placed[:]
    # fill the rest with zero near centers if we couldn't place
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]

    # local optimization: simulated annealing on (cx, cy, a, s)
    S = [list(s) for s in squares]
    # ensure at least n entries
    total = sum(s[3] for s in S)

    def evaluate(state):
        s = sum(x[3] for x in state)
        return s

    def feasible_state(state):
        for i in range(len(state)):
            sq = tuple(state[i])
            if not _in_unit(sq, eps=1e-7):
                return False
        for i in range(len(state)):
            for j in range(i + 1, len(state)):
                a = tuple(state[i]); b = tuple(state[j])
                if a[3] <= 0 or b[3] <= 0:
                    continue
                if _poly_overlap(a[0], a[1], a[2], a[3], b[0], b[1], b[2], b[3], 1e-7):
                    return False
        return True

    # Phase 1: try to grow each square
    improved = True
    while improved:
        improved = False
        for i in range(n):
            if S[i][3] <= 0:
                continue
            # try grow
            step = 0.02
            for _ in range(8):
                old = S[i][3]
                new_s = old + step
                cand = [S[i][0], S[i][1], S[i][2], new_s]
                if _in_unit(tuple(cand), eps=1e-7):
                    others = [tuple(S[j]) for j in range(n) if j != i]
                    if _overlap_ok(tuple(cand), others, eps=1e-7):
                        S[i][3] = new_s
                        improved = True
                        break
                step *= 0.5
            # try move
            for _ in range(4):
                dx = (random.random() - 0.5) * 0.05
                dy = (random.random() - 0.5) * 0.05
                da = (random.random() - 0.5) * 0.1
                cand = [S[i][0] + dx, S[i][1] + dy, S[i][2] + da, S[i][3]]
                cand[0] = min(1, max(0, cand[0]))
                cand[1] = min(1, max(0, cand[1]))
                cand[2] = cand[2] % 1.0
                cand = tuple(cand)
                if _in_unit(cand, eps=1e-7):
                    others = [tuple(S[j]) for j in range(n) if j != i]
                    if _overlap_ok(cand, others, eps=1e-7):
                        S[i] = list(cand)
                        improved = True

    # Phase 2: annealing
    best_state = [list(s) for s in S]
    best_val = sum(x[3] for x in S)
    T = 0.05
    for it in range(4000):
        i = random.randrange(n)
        if S[i][3] <= 0 and random.random() < 0.5:
            # try to give it size
            cand = [S[i][0], S[i][1], S[i][2], random.random() * 0.3]
        else:
            dx = (random.random() - 0.5) * 0.04
            dy = (random.random() - 0.5) * 0.04
            da = (random.random() - 0.5) * 0.2
            ds = (random.random() - 0.5) * 0.04
            cand = [S[i][0] + dx, S[i][1] + dy, S[i][2] + da, max(0.0, S[i][3] + ds)]
        cand[0] = min(1, max(0, cand[0]))
        cand[1] = min(1, max(0, cand[1]))
        cand[2] = cand[2] % 1.0
        cand = tuple(cand)
        if not _in_unit(cand, eps=1e-7):
            continue
        others = [tuple(S[j]) for j in range(n) if j != i]
        if not _overlap_ok(cand, others, eps=1e-7):
            continue
        old_val = sum(x[3] for x in S)
        old_i = list(S[i])
        S[i] = list(cand)
        new_val = sum(x[3] for x in S)
        delta = new_val - old_val
        if delta >= 0 or random.random() < math.exp(delta / max(T, 1e-9)):
            if new_val > best_val:
                best_val = new_val
                best_state = [list(s) for s in S]
        else:
            S[i] = old_i
        T *= 0.9997

    # final: try to grow everything again
    S = best_state
    improved = True
    while improved:
        improved = False
        for i in range(n):
            if S[i][3] <= 0:
                # try create from zero
                for _ in range(50):
                    cx = random.random()
                    cy = random.random()
                    a = random.random()
                    lo, hi = 0.0, 0.5
                    for _bs in range(25):
                        mid = (lo + hi) * 0.5
                        cand = (cx, cy, a, mid)
                        others = [tuple(S[j]) for j in range(n) if j != i]
                        if _in_unit(cand, eps=1e-7) and _overlap_ok(cand, others, eps=1e-7):
                            lo = mid
                        else:
                            hi = mid
                    if lo > 0:
                        S[i] = [cx, cy, a, lo]
                        improved = True
                        break
                continue
            step = 0.01
            for _ in range(10):
                old = S[i][3]
                new_s = old + step
                cand = [S[i][0], S[i][1], S[i][2], new_s]
                if _in_unit(tuple(cand), eps=1e-7):
                    others = [tuple(S[j]) for j in range(n) if j != i]
                    if _overlap_ok(tuple(cand), others, eps=1e-7):
                        S[i][3] = new_s
                        improved = True
                        break
                step *= 0.5

    result = [tuple(x) for x in S]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
