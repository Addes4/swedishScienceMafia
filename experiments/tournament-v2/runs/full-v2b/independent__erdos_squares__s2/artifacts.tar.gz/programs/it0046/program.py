import math
import random
import numpy as np
from scipy.optimize import minimize

# -------------------------------------------------------------
# Geometry helpers
# -------------------------------------------------------------

def corners(x, y, ang, s):
    """Return 4 corners of a square."""
    c = math.cos(ang * 2 * math.pi)
    sn = math.sin(ang * 2 * math.pi)
    h = s * 0.5
    # local corners (+-h, +-h)
    return [
        (x + ( c * a - sn * b), y + ( sn * a + c * b))
        for a, b in ((h, h), (-h, h), (-h, -h), (h, -h))
    ]

def project(corners, ax, ay):
    vals = [cx * ax + cy * ay for cx, cy in corners]
    return min(vals), max(vals)

def overlap_area(sq1, sq2):
    """
    Approximate area of intersection of two convex polygons
    (squares are convex) using Sutherland-Hodgman clipping.
    sq is (x, y, ang, s).
    """
    poly1 = corners(*sq1)
    poly2 = corners(*sq2)
    # clip poly1 by each edge of poly2
    def clip(subject, ax, ay):
        """clip polygon by half-plane ax*x+ay*y <= c (c implicit via edge)."""
        if not subject:
            return []
        out = []
        n = len(subject)
        for i in range(n):
            p = subject[i]
            q = subject[(i + 1) % n]
            dp = p[0] * ax + p[1] * ay
            dq = q[0] * ax + q[1] * ay
            if dp <= 0:
                out.append(p)
            if dp * dq < 0:
                # intersection point
                t = dp / (dp - dq)
                out.append((p[0] + t * (q[0] - p[0]),
                            p[1] + t * (q[1] - p[1])))
        return out

    # Build edges of poly2, each edge gives inward normal
    n = len(poly2)
    # determine orientation
    area = 0.0
    for i in range(n):
        x1, y1 = poly2[i]
        x2, y2 = poly2[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    ccw = area > 0
    subject = poly1
    for i in range(n):
        x1, y1 = poly2[i]
        x2, y2 = poly2[(i + 1) % n]
        ex, ey = x2 - x1, y2 - y1
        # inward normal (left for ccw, right for cw)
        if ccw:
            nx, ny = -ey, ex
        else:
            nx, ny = ey, -ex
        length = math.hypot(nx, ny)
        if length < 1e-15:
            continue
        nx /= length
        ny /= length
        # translate so that half plane is ax*x+ay*y <= 0
        c = x1 * nx + y1 * ny
        subject = clip(subject, nx, ny)  # careful c
        # actually I divided, need c
        # redo properly below
        subject = clip_hline(subject, nx, ny, c)
        if not subject:
            return 0.0
    # area
    if len(subject) < 3:
        return 0.0
    a = 0.0
    for i in range(len(subject)):
        x1, y1 = subject[i]
        x2, y2 = subject[(i + 1) % len(subject)]
        a += x1 * y2 - x2 * y1
    return abs(a) * 0.5

def clip_hline(poly, nx, ny, c):
    """clip poly by nx*x+ny*y <= c"""
    if not poly:
        return []
    out = []
    n = len(poly)
    for i in range(n):
        p = poly[i]
        q = poly[(i + 1) % n]
        dp = p[0] * nx + p[1] * ny - c
        dq = q[0] * nx + q[1] * ny - c
        if dp <= 0:
            out.append(p)
        if dp * dq < 0:
            t = dp / (dp - dq)
            out.append((p[0] + t * (q[0] - p[0]),
                        p[1] + t * (q[1] - p[1])))
    return out

# -------------------------------------------------------------
# Constructive initial packing
# -------------------------------------------------------------

def initial_packing(n):
    """Return list of (x, y, ang, s) and corresponding vector."""
    # Try several grid arrangements and pick best.
    best = None
    best_val = -1

    # candidate (cols, rows) pairs close to sqrt-ish
    candidates = []
    for a in range(1, n + 1):
        b = math.ceil(n / a)
        if a * b >= n:
            candidates.append((a, b))
    # unique
    candidates = list(set(candidates))

    for a, b in candidates:
        # number of full squares we can place: put largest square possible
        # if we allow varying sizes: greedy fill rows
        # simple: make a x b grid each cell sized to fit
        cellw = 1.0 / a
        cellh = 1.0 / b
        m = min(cellw, cellh)
        # try to give each of the n squares equal size m
        total = n * m
        if best is None or total > best_val:
            best_val = total
            # build arrangement with n squares in first n cells of a*b grid
            arr = []
            cnt = 0
            for i in range(a):
                for j in range(b):
                    if cnt >= n:
                        break
                    cx = (i + 0.5) * cellw
                    cy = (j + 0.5) * cellh
                    arr.append((cx, cy, 0.0, m))
                    cnt += 1
                if cnt >= n:
                    break
            best = arr
    return best

# -------------------------------------------------------------
# Objective / constraints for optimizer
# -------------------------------------------------------------

def unpack(v, n):
    """v has length 4n: x, y, ang, s per square (interleaved)."""
    sq = []
    for i in range(n):
        x, y, a, s = v[4*i:4*i+4]
        sq.append((x, y, a, s))
    return sq

def total_side(v):
    n = len(v) // 4
    return -sum(v[4*i+3] for i in range(n))  # negative for minimization

def penalty(v):
    n = len(v) // 4
    sq = unpack(v, n)
    pen = 0.0
    # bound constraints
    for (x, y, a, s) in sq:
        if s < 0:
            pen += 1e4 * s * s
        # square inside unit square: approximate by checking corners
        cs = corners(x, y, a, s)
        for cx, cy in cs:
            if cx < -1e-9:
                pen += 1e4 * (cx) ** 2
            if cx > 1 + 1e-9:
                pen += 1e4 * (cx - 1) ** 2
            if cy < -1e-9:
                pen += 1e4 * (cy) ** 2
            if cy > 1 + 1e-9:
                pen += 1e4 * (cy - 1) ** 2
    # overlap penalties (SAT)
    for i in range(n):
        for j in range(i + 1, n):
            s1, s2 = sq[i], sq[j]
            if s1[3] < 1e-12 and s2[3] < 1e-12:
                continue
            cs1 = corners(*s1)
            cs2 = corners(*s2)
            # quick reject via bounding circles
            r1 = s1[3] * math.sqrt(2) * 0.5
            r2 = s2[3] * math.sqrt(2) * 0.5
            d = math.hypot(s1[0] - s2[0], s1[1] - s2[1])
            if d > r1 + r2 + 1e-12:
                continue
            # SAT
            ov = False
            # axes from square 1
            for k in range(4):
                p = cs1[k]
                q = cs1[(k + 1) % 4]
                ax, ay = -(q[1] - p[1]), (q[0] - p[0])
                l = math.hypot(ax, ay)
                if l < 1e-15:
                    continue
                ax /= l
                ay /= l
                min1, max1 = project(cs1, ax, ay)
                min2, max2 = project(cs2, ax, ay)
                if max1 <= min2 + 1e-9 or max2 <= min1 + 1e-9:
                    break
            else:
                # no separating axis found -> overlap
                ov = True
            if not ov:
                continue
            # compute overlap area approximately (penalty proportional)
            ar = overlap_area(s1, s2)
            if ar > 1e-14:
                pen += 1e3 * ar
    return pen

def combined(v):
    return total_side(v) + penalty(v)

# -------------------------------------------------------------
# Main solve
# -------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        # a single square: unit square, side 1 (rotated 45 deg gives side sqrt2)
        # Actually a square rotated 45 degrees inside unit square:
        # diagonal length 1 => side = 1/sqrt(2) ~ 0.7071, which is worse.
        # Best is side 1 axis-aligned.
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(42)
    np.random.seed(42)

    best_sol = None
    best_obj = -1e18

    # Multiple starts
    starts = []
    # 1. axis-aligned grid (baseline)
    k = math.isqrt(n)
    side = 1.0 / k
    grid = []
    for i in range(k):
        for j in range(k):
            grid.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # remaining
    m = k
    for idx in range(len(grid), n):
        # place on top row
        i = idx - len(grid)
        px = (i + 0.5) / m if m > 0 else 0.5
        grid.append((px, 1.0 - side / 2, 0.0, side * 0.999))
    starts.append(grid)

    # 2. initial_packing variants
    for _ in range(3):
        arr = initial_packing(n)
        starts.append(arr)

    # 3. random perturbations
    for _ in range(3):
        arr = initial_packing(n)
        arr2 = []
        for (x, y, a, s) in arr:
            arr2.append((
                min(0.999, max(0.001, x + random.gauss(0, 0.03))),
                min(0.999, max(0.001, y + random.gauss(0, 0.03))),
                random.random(),
                max(0.001, s * random.uniform(0.8, 1.0)),
            ))
        starts.append(arr2)

    # Build vector from arrangement
    def to_vec(arr):
        v = []
        for (x, y, a, s) in arr:
            v.extend([x, y, a, s])
        return np.array(v, dtype=float)

    # Run optimization
    time_limit = 50.0
    import time
    t0 = time.time()

    for arr in starts:
        if time.time() - t0 > time_limit:
            break
        v0 = to_vec(arr)
        try:
            res = minimize(combined, v0, method="Powell",
                           options={"maxiter": 5000, "xtol": 1e-7, "ftol": 1e-9})
        except Exception:
            continue
        # Clean up: project
        v = res.x
        sq = unpack(v, n)
        # clamp sizes >= 0
        cleaned = []
        for (x, y, a, s) in sq:
            if s < 0:
                s = 0.0
            # clamp center
            x = min(1.0, max(0.0, x))
            y = min(1.0, max(0.0, y))
            # angle normalize
            a = a % 1.0
            cleaned.append((x, y, a, s))
        # Resolve overlaps by shrinking the smaller (greedy)
        cleaned = resolve_overlaps(cleaned)
        total = sum(s for (_, _, _, s) in cleaned)
        if total > best_obj:
            best_obj = total
            best_sol = cleaned

    # also check simple grid
    if best_sol is None:
        best_sol = initial_packing(n)

    # Ensure length n
    while len(best_sol) < n:
        best_sol.append((0.5, 0.5, 0.0, 0.0))
    return best_sol[:n]

def resolve_overlaps(sq):
    """Greedy shrink to remove interior overlaps."""
    n = len(sq)
    polys = [corners(*s) for s in sq]
    # iterative relaxation
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                if sq[i][3] < 1e-12 or sq[j][3] < 1e-12:
                    continue
                ar = overlap_area(sq[i], sq[j])
                if ar > 1e-10:
                    # shrink the smaller square
                    if sq[i][3] < sq[j][3]:
                        factor = max(0.5, 1.0 - (ar ** 0.5) * 2)
                        x, y, a, s = sq[i]
                        sq[i] = (x, y, a, s * factor)
                    else:
                        factor = max(0.5, 1.0 - (ar ** 0.5) * 2)
                        x, y, a, s = sq[j]
                        sq[j] = (x, y, a, s * factor)
                    changed = True
        if not changed:
            break
    return sq
