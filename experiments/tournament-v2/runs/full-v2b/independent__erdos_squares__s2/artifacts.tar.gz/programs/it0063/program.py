import math
import random
from typing import List, Tuple

# ------------------------------------------------------------
# Geometry helpers
# ------------------------------------------------------------

def _rot_square(cx, cy, a, s):
    """Return the 4 corners of a square (centre, angle fraction, side)."""
    t = 2.0 * math.pi * a
    c, sn = math.cos(t), math.sin(t)
    h = 0.5 * s
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        xr = x * c - y * sn
        yr = x * sn + y * c
        out.append((cx + xr, cy + yr))
    return out


def _overlap_value(sq1, sq2):
    """Return an approximate overlap area / penetration metric between two squares."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 0.0 or s2 <= 0.0:
        return 0.0
    p1 = _rot_square(cx1, cy1, a1, s1)
    p2 = _rot_square(cx2, cy2, a2, s2)
    # quick circle bound
    r1 = 0.5 * s1 * math.sqrt(2.0)
    r2 = 0.5 * s2 * math.sqrt(2.0)
    d2 = (cx1 - cx2) ** 2 + (cy1 - cy2) ** 2
    if d2 > (r1 + r2) ** 2:
        return 0.0
    # separating axis test with area estimate:
    # For convex polygons, SAT gives non-overlap; if overlapping,
    # use clipping / approximate via sampling if necessary.
    # Here we use a simple approximate penetration based on corner-in-poly.
    def point_in_poly(px, py, poly):
        inside = False
        n = len(poly)
        j = n - 1
        for i in range(n):
            xi, yi = poly[i]
            xj, yj = poly[j]
            if ((yi > py) != (yj > py)) and (px < (xj - xi) * (py - yi) / (yj - yi + 1e-300) + xi):
                inside = not inside
            j = i
        return inside

    # count corners inside the other polygon; if none and no edge crossing,
    # likely separated, but SAT is more reliable. Use SAT for exact non-overlap:
    def sat_overlap(p1, p2):
        polys = [p1, p2]
        for poly in polys:
            for i in range(len(poly)):
                x1, y1 = poly[i]
                x2, y2 = poly[(i + 1) % len(poly)]
                nx, ny = -(y2 - y1), (x2 - x1)
                # project both
                min1 = max1 = None
                for px, py in p1:
                    v = px * nx + py * ny
                    if min1 is None or v < min1:
                        min1 = v
                    if max1 is None or v > max1:
                        max1 = v
                min2 = max2 = None
                for px, py in p2:
                    v = px * nx + py * ny
                    if min2 is None or v < min2:
                        min2 = v
                    if max2 is None or v > max2:
                        max2 = v
                if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                    return False, 0.0
        # overlapping by SAT; estimate area via Monte Carlo-ish / corner count
        cnt = 0
        for px, py in p1:
            if point_in_poly(px, py, p2):
                cnt += 1
        for px, py in p2:
            if point_in_poly(px, py, p1):
                cnt += 1
        return True, max(1, cnt) * 0.25 * min(s1, s2) ** 2

    ov, val = sat_overlap(p1, p2)
    return val if ov else 0.0


# ------------------------------------------------------------
# Overlap repair / local optimization
# ------------------------------------------------------------

def _repair_overlaps(squares, iters=200, rng=None):
    """Push apart and shrink overlapping squares; grow all a bit when feasible."""
    if rng is None:
        rng = random.Random(12345)
    n = len(squares)
    sq = [list(s) for s in squares]

    for _ in range(iters):
        # compute overlap pairs
        any_ov = False
        for i in range(n):
            for j in range(i + 1, n):
                ov = _overlap_value(tuple(sq[i]), tuple(sq[j]))
                if ov > 1e-12:
                    any_ov = True
                    # push apart along centre difference
                    dx = sq[i][0] - sq[j][0]
                    dy = sq[i][1] - sq[j][1]
                    dist = math.hypot(dx, dy) + 1e-12
                    push = min(0.01, 0.05 * math.sqrt(ov))
                    ux, uy = dx / dist, dy / dist
                    si, sj = sq[i][3], sq[j][3]
                    # move proportional to size
                    wi = si / (si + sj + 1e-12)
                    wj = sj / (si + sj + 1e-12)
                    sq[i][0] += ux * push * wj
                    sq[i][1] += uy * push * wj
                    sq[j][0] -= ux * push * wi
                    sq[j][1] -= uy * push * wi
                    # slight shrink of both if very overlapped
                    if ov > 0.001 * min(si, sj) ** 2:
                        sq[i][3] *= 0.999
                        sq[j][3] *= 0.999

        # keep in bounds
        for s in sq:
            cx, cy, a, side = s
            # conservative bound: half diagonal
            hd = 0.5 * side * math.sqrt(2.0)
            cx = min(max(cx, hd), 1.0 - hd)
            cy = min(max(cy, hd), 1.0 - hd)
            s[0], s[1] = cx, cy

        if not any_ov:
            # try growing
            best_grow = 1.002
            for s in sq:
                if s[3] == 0.0:
                    continue
                old = s[3]
                s[3] *= best_grow
                hd = 0.5 * s[3] * math.sqrt(2.0)
                if s[0] - hd < -1e-9 or s[0] + hd > 1.0 + 1e-9 or s[1] - hd < -1e-9 or s[1] + hd > 1.0 + 1e-9:
                    s[3] = old
                    continue
                # check overlap after growth
                ok = True
                for j in range(n):
                    if j == sq.index(s):
                        continue
                    if _overlap_value(tuple(s), tuple(sq[j])) > 1e-12:
                        ok = False
                        break
                if not ok:
                    s[3] = old
            # small random jiggle
            idx = rng.randrange(n)
            if sq[idx][3] > 0:
                old = list(sq[idx])
                sq[idx][0] += rng.uniform(-0.005, 0.005)
                sq[idx][1] += rng.uniform(-0.005, 0.005)
                sq[idx][2] += rng.uniform(-0.01, 0.01)
                hd = 0.5 * sq[idx][3] * math.sqrt(2.0)
                sq[idx][0] = min(max(sq[idx][0], hd), 1.0 - hd)
                sq[idx][1] = min(max(sq[idx][1], hd), 1.0 - hd)
                # revert if overlap
                bad = False
                for j in range(n):
                    if j == idx:
                        continue
                    if _overlap_value(tuple(sq[idx]), tuple(sq[j])) > 1e-12:
                        bad = True
                        break
                if bad:
                    sq[idx] = old

    return [tuple(s) for s in sq]


# ------------------------------------------------------------
# Constructive layouts
# ------------------------------------------------------------

def _uniform_grid(k):
    s = 1.0 / k
    return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]


def _grid_with_big(n):
    """k x k grid plus one extra large square replacing some cells where possible."""
    k = math.isqrt(n)
    base = _uniform_grid(k)
    rem = n - k * k
    if rem == 0:
        return base
    # Add zero-size squares at random places
    return base + [(0.5, 0.5, 0.0, 0.0)] * rem


def _best_row_col(n):
    """Try near-square grids and rows/columns packings."""
    best = None
    best_sum = -1.0
    for k in range(1, n + 1):
        # k x m grid; choose m = ceil(n/k), last row partial
        m = (n + k - 1) // k
        if k * m < n:
            continue
        sx = 1.0 / k
        sy = 1.0 / m
        s = min(sx, sy)
        cnt = 0
        squares = []
        for i in range(k):
            for j in range(m):
                if cnt >= n:
                    break
                cx = (i + 0.5) * sx
                cy = (j + 0.5) * sy
                squares.append((cx, cy, 0.0, s))
                cnt += 1
            if cnt >= n:
                break
        total = s * n
        if total > best_sum:
            best_sum = total
            best = squares
    return best


def _recursive_strips(n):
    """Guillotine-like: split unit square into strips, recursively pack."""
    if n == 0:
        return []
    if n == 1:
        # one square centered, side 1
        return [(0.5, 0.5, 0.0, 1.0)]
    # try splitting horizontally/vertically into two groups
    best = None
    best_val = -1.0
    for n1 in range(1, n):
        n2 = n - n1
        # vertical split: widths w1, w2, squares full height
        # If we use 1 square in left strip, side = w1; etc.
        # Better: solve recursively for each strip scaled.
        # Approx: allocate area proportional to n1,n2
        a1 = n1 / n
        w1 = math.sqrt(a1)
        w2 = 1.0 - w1
        if w1 <= 0 or w2 <= 0:
            continue
        # left strip solution scaled to w1 x 1
        left = _recursive_strips(n1)
        right = _recursive_strips(n2)
        # scale left into [0,w1]x[0,1], right into [w1,1]x[0,1]
        sq = []
        for cx, cy, a, s in left:
            sq.append((cx * w1, cy, a, s * w1))
        for cx, cy, a, s in right:
            sq.append((w1 + cx * w2, cy, a, s * w2))
        val = sum(x[3] for x in sq)
        if val > best_val:
            best_val = val
            best = sq
    return best if best is not None else _best_row_col(n)


# ------------------------------------------------------------
# Known good special cases
# ------------------------------------------------------------

def _special(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side 0.5 each
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # 2x2 grid with one missing: sides 0.5,0.5,0.5
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5)]
    if n == 4:
        return _uniform_grid(2)
    if n == 5:
        # 2x2 grid + one small square in corner? Actually best known: side lengths sum ~2.207
        # Try: 4 corner squares of side ~0.5 minus, plus one center? Simpler: 2x3 grid missing one
        # Use 0.5, 0.5, 0.5, 0.5, and a small square in remaining L-shape
        # Approx: side 0.5 for 4, plus 0.5? No.
        # Known: for n=5, sum ~ 2.0? Actually 5 squares of side 0.5 would sum 2.5 but cannot fit.
        # Try: 0.5,0.5,0.5,0.5, 0.0 (sum 2.0). But can do better?
        # Use 3 squares side 0.5 on bottom, 2 squares side 0.5 on top -> 5*0.5=2.5? But 6 cells of 0.5 grid.
        # 0.5 grid has 4 squares. 5th can be small in corner: side ~0.5? no.
        # Let's use 2x3 grid with cells 0.5 x 1/3, side min=1/3? sum ~ 5/3=1.67 worse.
        # Actually best for n=5 is 0.5,0.5,0.5,0.5 and one of 0.5? no.
        # Use 2x2 grid of 0.5, then split one 0.5 cell into two 0.25 squares. sum = 3*0.5+2*0.25=2.0
        # Or make one square 0.5 and rest? Let's just use 0.5,0.5,0.5,0.5,0.25 (sum 2.25) by splitting a cell.
        # Can we fit 0.5,0.5,0.5,0.5,0.25? Place four 0.5 in corners? They touch. Use 3x3 grid? 
        # Use 0.5 squares in 2x2, then split one into two 0.25: sum=2.0. 
        # Better: 0.5,0.5,0.5,0.5,0.5? total 2.5 but 5 squares of 0.5 may fit in 0.5 grid? 4 only.
        # Try 0.6,0.6,0.4,0.4,0.4? sum 2.4.
        # We'll just return 0.5,0.5,0.5,0.5,0.25 placement.
        s = 0.5
        return [
            (0.25, 0.25, 0.0, s),
            (0.75, 0.25, 0.0, s),
            (0.25, 0.75, 0.0, s),
            (0.75, 0.75, 0.0, s),
            (0.5, 0.5, 0.0, 0.0)  # placeholder zero
        ]
    return None


# ------------------------------------------------------------
# Main solver
# ------------------------------------------------------------

def solve(n: int) -> List[Tuple[float, float, float, float]]:
    if n <= 0:
        return []
    # exact specials
    sp = _special(n)
    if sp is not None:
        return sp

    # candidate constructions
    candidates = []

    # 1. best row/col grid
    c1 = _best_row_col(n)
    if c1:
        candidates.append(c1)

    # 2. uniform grid (k x k + zeros)
    c2 = _grid_with_big(n)
    candidates.append(c2)

    # 3. recursive strips
    c3 = _recursive_strips(n)
    if c3:
        candidates.append(c3)

    # 4. random grid permutations / mixed sizes: k x k plus small squares in gaps
    k = math.isqrt(n)
    base = _uniform_grid(k)
    rem = n - k * k
    c4 = list(base)
    # place remaining squares in free space: shrink some grid squares and fill
    if rem > 0:
        # simple: place remaining as small squares at random non-overlapping spots
        for _ in range(rem):
            c4.append((random.random(), random.random(), random.random(), 0.01))
    candidates.append(c4)

    # Evaluate by sum of sides, then repair to remove overlaps
    best_sq = None
    best_sum = -1.0
    for cand in candidates:
        if len(cand) != n:
            cand = (cand + [(0.5, 0.5, 0.0, 0.0)] * n)[:n]
        cand = [tuple(x) for x in cand]
        # clamp
        cand = [
            (min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), a % 1.0, max(0.0, s))
            for (cx, cy, a, s) in cand
        ]
        total = sum(s for _, _, _, s in cand)
        if total > best_sum:
            best_sum = total
            best_sq = cand

    # final repair and small optimization
    if best_sq is None:
        best_sq = [(0.5, 0.5, 0.0, 0.0)] * n

    # Try multiple random restarts for better local optimum
    rng = random.Random(1234 + n)
    best_final = best_sq
    best_final_sum = sum(s for _, _, _, s in best_sq)
    for trial in range(3):
        # perturb current best
        pert = []
        for cx, cy, a, s in best_sq:
            pert.append((
                cx + rng.uniform(-0.02, 0.02),
                cy + rng.uniform(-0.02, 0.02),
                (a + rng.uniform(-0.02, 0.02)) % 1.0,
                max(0.0, s * rng.uniform(0.9, 1.1))
            ))
        repaired = _repair_overlaps(pert, iters=100, rng=rng)
        total = sum(s for _, _, _, s in repaired)
        if total > best_final_sum:
            best_final_sum = total
            best_final = repaired

    # ensure exactly n, all in [0,1]
    result = []
    for i in range(n):
        if i < len(best_final):
            cx, cy, a, s = best_final[i]
        else:
            cx, cy, a, s = 0.5, 0.5, 0.0, 0.0
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        s = max(0.0, s)
        # conservatively ensure fit: shrink if needed
        hd = 0.5 * s * math.sqrt(2.0)
        if cx - hd < -1e-9:
            cx = hd
        if cx + hd > 1.0 + 1e-9:
            cx = 1.0 - hd
        if cy - hd < -1e-9:
            cy = hd
        if cy + hd > 1.0 + 1e-9:
            cy = 1.0 - hd
        if cx < 0 or cx > 1 or cy < 0 or cy > 1:
            s = 0.0
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
        result.append((cx, cy, a, s))

    return result
