import math
import random
import numpy as np
from scipy.optimize import minimize

# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------

def _grid_solution(n):
    """A row-by-row grid where each row can have its own height and count."""
    if n <= 0:
        return []

    # choose number of rows r; within row i choose c_i squares.
    # Want c_i ~ n/r and heights ~ 1/r, but optimise.
    best = None

    for r in range(1, min(n, 40) + 1):
        # distribute counts among rows: mostly floor(n/r) plus remainder
        base = n // r
        rem = n % r
        counts = [base + (1 if i < rem else 0) for i in range(r) if base + (1 if i < rem else 0) > 0]
        if not counts:
            continue

        # solve for heights h_i > 0 with sum h_i = 1 and h_i * counts[i] maximised
        # but actually side_i = min(h_i, 1/counts[i]) roughly;
        # allocate more height to rows with fewer columns? standard: water-filling
        m = len(counts)
        # optimal: h_i = t / counts_i clipped to 1/counts_i? We want max sum min(h_i, 1/c_i)
        # with sum h = 1. If we set h_i = 1/c_i for all i, sum = sum 1/c_i.
        # If sum < 1, extra height wasted -> instead reduce some c_i.
        # Simple approach: give each row height 1/m, side = min(1/m, 1/c_i)
        # Better: binary search on s = side, h_i = min(s, 1/c_i)? Then sum h_i <=1.
        # Let's do: for a target side s, each row needs height s, width c_i * s <= 1 => c_i <= 1/s.
        # We choose c_i as large as possible with c_i <= 1/s and sum over rows of s <= 1 => r*s <=1.
        # Actually heights are independent; side limited by min(height, 1/c_i).
        # For a target s: need height >= s and c_i * s <= 1 => c_i <= floor(1/s).
        # Number of squares = sum c_i, with r rows, each c_i <= floor(1/s), r <= 1/s.
        # So max n for side s: floor(1/s) * floor(1/s). That's just grid.

        # Instead: optimise freely: choose heights h_i, counts c_i; side_i = min(h_i, 1/c_i)
        # sum side_i maximised.
        # For fixed counts, optimal heights: set h_i = 1/c_i for all i needing (those with largest gain)?
        # Actually we want h_i as large as possible up to 1/c_i, all equal priority.
        # So fill shortest c_i first.
        order = sorted(range(m), key=lambda i: counts[i], reverse=True)
        # fill rows with smallest count first? Each row i gives side min(h_i, 1/c_i).
        # To maximise sum, allocate first to rows where 1/c_i is largest (small count).
        # Water-filling: s = target, h_i = min(s, 1/c_i)? No, we want h_i = s if 1/c_i >= s else h_i = 1/c_i (full).
        # Sum h_i <= 1, maximise sum min(h_i, 1/c_i).
        # This is like: give each row min(1/c_i, s), total = sum min(1/c_i, s) <= 1, then sum of side = sum min(1/c_i,s).
        # So s chosen so sum min(1/c_i, s) = 1.
        inv = [1.0 / c for c in counts]
        lo, hi = 0.0, 1.0
        for _ in range(60):
            mid = (lo + hi) / 2
            tot = sum(min(x, mid) for x in inv)
            if tot > 1.0:
                hi = mid
            else:
                lo = mid
        s = lo
        heights = [min(x, s) for x in inv]
        # normalise
        total_h = sum(heights)
        if total_h > 0:
            heights = [h / total_h for h in heights]

        # build squares
        squares = []
        y = 0.0
        for i in range(m):
            c = counts[i]
            h = heights[i]
            side = min(h, 1.0 / c)
            # place c squares in row
            w = side * c
            if w > 1.0 + 1e-9:
                # shouldn't happen, but clamp
                side = 1.0 / c
                w = 1.0
            x = 0.0
            for j in range(c):
                cx = x + side / 2
                cy = y + h / 2
                squares.append((cx, cy, 0.0, side))
                x += side
            y += h

        if len(squares) < n:
            squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        elif len(squares) > n:
            squares = squares[:n]

        score = sum(sq[3] for sq in squares)
        if best is None or score > best[0]:
            best = (score, squares)

    if best is None:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    return best[1]


# ---------------------------------------------------------------------
# Small-n continuous improvement
# ---------------------------------------------------------------------

def _overlap_area(sq1, sq2):
    """Approximate overlap area of two squares (rotated rectangles)."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 1e-12 or s2 <= 1e-12:
        return 0.0
    # use separating axis theorem for OBB
    ang1 = a1 * 2 * math.pi
    ang2 = a2 * 2 * math.pi
    axes = []
    for ang in (ang1, ang2):
        for d in (0.0, math.pi / 2):
            axes.append((math.cos(ang + d), math.sin(ang + d)))

    corners1 = _corners(cx1, cy1, ang1, s1)
    corners2 = _corners(cx2, cy2, ang2, s2)

    min_overlap = float('inf')
    for ax, ay in axes:
        proj1 = [x * ax + y * ay for x, y in corners1]
        proj2 = [x * ax + y * ay for x, y in corners2]
        d1 = max(proj1) - min(proj1)
        d2 = max(proj2) - min(proj2)
        # projected interval overlap
        ov = min(max(proj1), max(proj2)) - max(min(proj1), min(proj2))
        if ov <= 0:
            return 0.0
        min_overlap = min(min_overlap, ov)
    # rough area estimate
    return min_overlap ** 2


def _corners(cx, cy, ang, side):
    h = side / 2
    c, s = math.cos(ang), math.sin(ang)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * c - dy * s
        y = cy + dx * s + dy * c
        pts.append((x, y))
    return pts


def _penalty(squares):
    """Total overlap area + out-of-bounds penalty."""
    pen = 0.0
    n = len(squares)
    for i in range(n):
        cx, cy, a, s = squares[i]
        if s <= 1e-12:
            continue
        # bounds
        for x, y in _corners(cx, cy, a * 2 * math.pi if a <= 1 else a, s):
            if x < -1e-9:
                pen += (-x) ** 2 * 1e4
            if x > 1 + 1e-9:
                pen += (x - 1) ** 2 * 1e4
            if y < -1e-9:
                pen += (-y) ** 2 * 1e4
            if y > 1 + 1e-9:
                pen += (y - 1) ** 2 * 1e4
        # overlap with later
        for j in range(i + 1, n):
            if squares[j][3] <= 1e-12:
                continue
            # fast circle test
            dx = cx - squares[j][0]
            dy = cy - squares[j][1]
            rsum = (s + squares[j][3]) / 2
            if dx * dx + dy * dy > rsum * rsum * 2.0:
                continue
            pen += _overlap_area(squares[i], squares[j]) * 1e3
    return pen


def _objective(x, n):
    """x: flat array [cx, cy, angle, side] * n. Return -(sum side) + penalty."""
    squares = []
    for i in range(n):
        cx, cy, a, s = x[4 * i:4 * i + 4]
        # clamp angle to [0,1)
        a = a % 1.0
        squares.append((cx, cy, a, max(0.0, s)))
    total_side = sum(sq[3] for sq in squares)
    pen = _penalty(squares)
    return -total_side + pen


def _improve_small(n, init_squares, time_budget=5.0):
    """Try to improve a packing for small n via Nelder-Mead / Powell."""
    if n == 0:
        return init_squares

    x0 = []
    for cx, cy, a, s in init_squares:
        x0.extend([cx, cy, a, s])
    x0 = np.array(x0, dtype=float)

    # bounds
    bounds = []
    for _ in range(n):
        bounds.append((0.0, 1.0))  # cx
        bounds.append((0.0, 1.0))  # cy
        bounds.append((0.0, 1.0))  # angle
        bounds.append((0.0, 1.0))  # side

    best_x = x0.copy()
    best_val = _objective(best_x, n)

    # Nelder-Mead with restarts
    import time
    t0 = time.time()
    attempts = 0
    while time.time() - t0 < time_budget:
        attempts += 1
        try:
            res = minimize(lambda x: _objective(x, n), best_x,
                           method='Nelder-Mead',
                           options={'maxiter': 2000, 'xatol': 1e-4, 'fatol': 1e-6,
                                    'adaptive': True})
            if res.fun < best_val - 1e-9:
                best_val = res.fun
                best_x = res.x.copy()
        except Exception:
            break
        # small random perturbation
        perturb = best_x + np.random.normal(0, 0.02, size=best_x.shape)
        perturb = np.clip(perturb, 0.0, 1.0)
        val = _objective(perturb, n)
        if val < best_val:
            best_val = val
            best_x = perturb

    # reconstruct
    out = []
    for i in range(n):
        cx, cy, a, s = best_x[4 * i:4 * i + 4]
        a = a % 1.0
        out.append((float(np.clip(cx, 0, 1)), float(np.clip(cy, 0, 1)), float(a), max(0.0, float(s))))
    return out


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # get grid-based initial solution
    squares = _grid_solution(n)

    # verify and repair small overlaps/bounds
    # quick sanity: ensure all inside
    fixed = []
    for cx, cy, a, s in squares:
        # shrink if outside
        if s <= 0:
            fixed.append((cx, cy, a, s))
            continue
        a_rad = a * 2 * math.pi
        c, si = math.cos(a_rad), math.sin(a_rad)
        half = s / 2
        ext_x = abs(c * half) + abs(si * half)
        ext_y = abs(si * half) + abs(c * half)
        cx = min(max(cx, ext_x), 1 - ext_x)
        cy = min(max(cy, ext_y), 1 - ext_y)
        fixed.append((cx, cy, a, s))
    squares = fixed

    # for small n try continuous improvement
    if n <= 16:
        try:
            improved = _improve_small(n, squares, time_budget=4.0)
            if sum(x[3] for x in improved) >= sum(x[3] for x in squares) - 1e-9:
                squares = improved
        except Exception:
            pass

    # final safety: scale down if any out-of-bounds
    # (already handled)

    # pad if needed
    if len(squares) < n:
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
