import math


def solve(n):
    if n <= 0:
        return []
    # Special small cases with known good configurations
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two rectangles -> two squares of side 0.5
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # 3 squares: 0.5, 0.5, and a smaller one in the remaining 0.5x0.5 area? Actually two 0.5 squares leave 0.5x1 strip; put one square 0.5 in it -> total 1.5
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5), (0.5, 0.75, 0.0, 0.25)]
    if n == 4:
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s),
                (0.25, 0.75, 0.0, s), (0.75, 0.75, 0.0, s)]

    # General: try several layouts and pick the best sum
    best = _grid_layout(n)
    best_sum = sum(sq[3] for sq in best)

    alt = _shelf_layout(n)
    alt_sum = sum(sq[3] for sq in alt)
    if alt_sum > best_sum:
        best, best_sum = alt, alt_sum

    alt2 = _mixed_layout(n)
    alt2_sum = sum(sq[3] for sq in alt2)
    if alt2_sum > best_sum:
        best, best_sum = alt2, alt2_sum

    return best


def _grid_layout(n):
    """Largest k x k grid, plus leftover squares of decreasing size in remaining strip."""
    k = math.isqrt(n)
    s = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    rem = n - k * k
    if rem == 0:
        return squares
    # Fill leftover space: after k x k grid of side 1/k, there's no space left.
    # Instead reduce one column/row to make room. Use a strip approach:
    # Use k columns of width 1/k, but make one column narrow (w) and put rem squares there.
    # Recompute: place k rows fully, but last column only (k) squares? Simpler:
    # Use (k) x (k) grid but shrink to allow rem extra squares in a leftover strip.
    # Fallback: just add tiny squares at center.
    for _ in range(rem):
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _shelf_layout(n):
    """Shelf packing: arrange squares in horizontal shelves, sizes chosen greedily."""
    squares = []
    remaining = n
    y = 0.0
    # Number of shelves: try a few, pick best
    best = None
    best_sum = -1.0
    for shelves in range(1, min(n, 8) + 1):
        rows = shelves
        # distribute n squares into rows as evenly as possible
        counts = [n // rows] * rows
        for i in range(n % rows):
            counts[i] += 1
        # each row has equal height h = 1/rows
        h = 1.0 / rows
        total = 0.0
        sq_list = []
        ok = True
        for r, cnt in enumerate(counts):
            if cnt == 0:
                continue
            # squares in this row have side <= h (to fit in height) and sum of widths <= 1
            # maximize sum of sides: if cnt * h <= 1, all can have side h
            if cnt * h <= 1.0:
                side = h
            else:
                side = 1.0 / cnt
            # side is limited by min(h, 1/cnt)
            side = min(h, 1.0 / cnt)
            x = 0.0
            for _ in range(cnt):
                cx = x + side / 2.0
                cy = r * h + side / 2.0
                sq_list.append((cx, cy, 0.0, side))
                x += side
            total += cnt * side
        if total > best_sum:
            best_sum = total
            best = sq_list
    return best if best is not None else [(0.5, 0.5, 0.0, 0.0)] * n


def _mixed_layout(n):
    """Mix: k x k grid minus some squares, plus a strip of smaller squares."""
    best = None
    best_sum = -1.0
    for k in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 2):
        if k * k > n:
            continue
        rem = n - k * k
        # base grid k x k of side 1/k, but shrink grid to width 1 to allow a strip
        # Place k x k grid of side s, leaving strip of width (1 - k*s) if we compress
        # Try s slightly less than 1/k to fit rem extra squares in a strip.
        for s in [1.0 / k, 1.0 / (k + 0.5), 1.0 / (k + 1)]:
            if s <= 0 or k * s > 1.0 + 1e-12:
                continue
            grid_w = k * s
            grid_h = k * s
            if grid_w > 1.0 or grid_h > 1.0:
                continue
            strip_w = 1.0 - grid_w
            strip_h = 1.0 - grid_h
            # place rem squares in strip along right edge of width strip_w, height grid_h
            if rem > 0 and strip_w > 1e-9:
                # try to fit rem squares of side t: rem * t <= grid_h and t <= strip_w
                t = min(strip_w, grid_h / rem) if rem > 0 else 0
                if t > 0:
                    sq_list = []
                    for i in range(k):
                        for j in range(k):
                            sq_list.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                    for m in range(rem):
                        cy = (m + 0.5) * (grid_h / rem)
                        cx = grid_w + t / 2.0
                        sq_list.append((cx, cy, 0.0, t))
                    tot = k * k * s + rem * t
                    if tot > best_sum:
                        best_sum = tot
                        best = sq_list
            elif rem == 0:
                sq_list = []
                for i in range(k):
                    for j in range(k):
                        sq_list.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                tot = k * k * s
                if tot > best_sum:
                    best_sum = tot
                    best = sq_list
    if best is None:
        return _grid_layout(n)
    # Ensure exactly n squares
    if len(best) < n:
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]
