"""Adaptive square packing into the unit square.

Strategy:
1. For many n, an efficient and robust solution comes from a deterministic set of
   candidate layouts (grids, strips, recursive guillotine splits, rotated patterns).
2. We refine any candidate using a penalty-based local optimiser (scipy.optimize.minimize
   with SLSQP) over centre coordinates, angle and side, with many random restarts.
3. The best result is returned.
"""

import math
import random
import numpy as np
from scipy.optimize import minimize

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _clip01(x):
    return min(1.0, max(0.0, x))


def _rect_pack(rects, n):
    """Greedily fit up to n axis-aligned squares into given axis-aligned rectangles.
    rects is list of (x0,y0,x1,y1).  Returns list of (cx, cy, 0, side)."""
    out = []
    # sort rectangles by area descending
    rects = sorted(rects, key=lambda r: (r[2]-r[0])*(r[3]-r[1]), reverse=True)
    remaining = list(rects)
    while len(out) < n and remaining:
        # best fit: largest square that fits into some rectangle
        best = None
        for i, (x0, y0, x1, y1) in enumerate(remaining):
            w, h = x1 - x0, y1 - y0
            s = min(w, h)
            if s <= 0:
                continue
            if best is None or s > best[0]:
                # place square in a corner, leave rest as rectangles
                best = (s, i, x0, y0, x1, y1)
        if best is None:
            break
        s, idx, x0, y0, x1, y1 = best
        remaining.pop(idx)
        cx, cy = (x0 + s / 2, y0 + s / 2)
        out.append((cx, cy, 0.0, s))
        # split leftover into up to two rectangles
        if x1 - (x0 + s) > 1e-12:
            remaining.append((x0 + s, y0, x1, y1))
        if y1 - (y0 + s) > 1e-12:
            remaining.append((x0, y0 + s, x0 + s, y1))
    return out


def _guillotine(n):
    """Try many recursive guillotine split layouts."""
    best = None
    for seed in range(30):
        rng = random.Random(seed)
        # generate a random slicing tree depth
        rects = [(0.0, 0.0, 1.0, 1.0)]
        target = n
        # We only need enough rectangles: split until we have >= n rectangles
        while len(rects) < target:
            # pick largest rectangle
            rects.sort(key=lambda r: (r[2]-r[0])*(r[3]-r[1]), reverse=True)
            x0, y0, x1, y1 = rects.pop(0)
            w, h = x1 - x0, y1 - y0
            if w < 1e-9 or h < 1e-9:
                rects.append((x0, y0, x1, y1))
                break
            # random split direction
            if rng.random() < 0.5 and w > h:
                f = rng.uniform(0.2, 0.8)
                rects.append((x0, y0, x0 + w * f, y1))
                rects.append((x0 + w * f, y0, x1, y1))
            elif rng.random() < 0.5:
                f = rng.uniform(0.2, 0.8)
                rects.append((x0, y0, x1, y0 + h * f))
                rects.append((x0, y0 + h * f, x1, y1))
            else:
                f = rng.uniform(0.2, 0.8)
                rects.append((x0, y0, x0 + w * f, y1))
                rects.append((x0 + w * f, y0, x1, y1))
        squares = _rect_pack(rects, n)
        if len(squares) < n:
            squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        val = sum(s[3] for s in squares)
        if best is None or val > best[0]:
            best = (val, squares)
    return best[1]


def _grid_layout(n, k, angle=0.0):
    """k x k grid of axis-aligned squares, rotated by angle if it fits."""
    if k * k > n:
        return None
    side = 1.0 / k
    squares = []
    # bounding box of one rotated square
    ca, sa = abs(math.cos(angle * 2 * math.pi)), abs(math.sin(angle * 2 * math.pi))
    ext = side * (ca + sa)
    if ext > 1.0 + 1e-12:
        return None
    per = math.floor(1.0 / ext)
    if per < k:
        return None
    # place k x k rotated squares spaced by ext
    off = (1.0 - k * ext) / 2.0
    for i in range(k):
        for j in range(k):
            cx = off + (i + 0.5) * ext
            cy = off + (j + 0.5) * ext
            squares.append((cx, cy, angle, side))
    return squares


# ---------------------------------------------------------------------------
# penalty-based local solver
# ---------------------------------------------------------------------------

def _overlap_penalty(sq):
    """Total pairwise interior overlap area (approx) + boundary violations."""
    n = len(sq)
    pen = 0.0
    # boundary: centre +/- rotated half-extent must be inside [0,1]^2
    for (cx, cy, ang, s) in sq:
        if s <= 1e-14:
            continue
        th = ang * 2 * math.pi
        ca, sa = abs(math.cos(th)), abs(math.sin(th))
        hx = 0.5 * s * (ca + sa)
        hy = hx
        left = cx - hx
        right = cx + hx
        bottom = cy - hy
        top = cy + hy
        if left < -1e-12:
            pen += (left) ** 2 * 1000
        if right > 1 + 1e-12:
            pen += (right - 1) ** 2 * 1000
        if bottom < -1e-12:
            pen += (bottom) ** 2 * 1000
        if top > 1 + 1e-12:
            pen += (top - 1) ** 2 * 1000
    # pairwise overlap via separating axis (approx using penetration)
    for i in range(n):
        ci_x, ci_y, ai, si = sq[i]
        if si <= 1e-14:
            continue
        for j in range(i + 1, n):
            cj_x, cj_y, aj, sj = sq[j]
            if sj <= 1e-14:
                continue
            # approximate using AABB overlap of rotated bounding boxes
            ci = math.cos(ai * 2 * math.pi)
            si_ = math.sin(ai * 2 * math.pi)
            hxi = 0.5 * si * (abs(ci) + abs(si_))
            hyi = hxi
            cj = math.cos(aj * 2 * math.pi)
            sj_ = math.sin(aj * 2 * math.pi)
            hxj = 0.5 * sj * (abs(cj) + abs(sj_))
            hyj = hxj
            dx = abs(ci_x - cj_x) - (hxi + hxj)
            dy = abs(ci_y - cj_y) - (hyi + hyj)
            if dx < 0 and dy < 0:
                pen += min(-dx, -dy) ** 2 * 1000
    return pen


def _neg_sum(sq):
    return -sum(s[3] for s in sq)


def _objective(params, n):
    sq = []
    for i in range(n):
        cx = params[4 * i]
        cy = params[4 * i + 1]
        ang = params[4 * i + 2]
        s = params[4 * i + 3]
        sq.append((cx, cy, ang, s))
    return _neg_sum(sq) + _overlap_penalty(sq)


def _refine(init, n, maxiter=80):
    """SLSQP refinement of a layout."""
    x0 = []
    bounds = []
    for (cx, cy, ang, s) in init:
        x0.extend([cx, cy, ang, s])
        bounds.extend([(0, 1), (0, 1), (0, 0.5), (0, 1)])
    x0 = np.array(x0, dtype=float)

    def fun(x):
        return _objective(x, n)

    try:
        res = minimize(fun, x0, method='SLSQP', bounds=bounds,
                       options={'maxiter': maxiter, 'ftol': 1e-12, 'disp': False})
        if res.success or res.fun < fun(x0):
            x = res.x
            out = []
            for i in range(n):
                cx = _clip01(x[4 * i])
                cy = _clip01(x[4 * i + 1])
                ang = _clip01(x[4 * i + 2] % 0.5)
                s = max(0.0, x[4 * i + 3])
                out.append((cx, cy, ang, s))
            return out
    except Exception:
        pass
    return init


# ---------------------------------------------------------------------------
# candidate generators
# ---------------------------------------------------------------------------

def _candidates(n):
    cands = []
    # 1. best guillotine
    cands.append(_guillotine(n))
    # 2. grids for various k
    for k in range(1, n + 1):
        kk = k * k
        if kk <= n:
            side = 1.0 / k
            sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                  for i in range(k) for j in range(k)]
            sq += [(0.5, 0.5, 0.0, 0.0)] * (n - kk)
            cands.append(sq)
    # 3. rotated grids
    for k in range(1, min(n, 20) + 1):
        for ang in [0.0, 0.05, 0.1, 0.125, 0.15, 0.2, 0.25]:
            g = _grid_layout(n, k, ang)
            if g:
                g += [(0.5, 0.5, 0.0, 0.0)] * (n - len(g))
                cands.append(g[:n])
    # 4. strip layouts: divide into horizontal strips
    for m in range(1, n + 1):
        h = 1.0 / m
        row = int(round(1.0 / h)) if h > 0 else 0
        # actually: m strips, each can hold floor(1/h) squares of side h
        cols = int(math.floor(1.0 / h + 1e-12))
        if cols <= 0:
            continue
        sq = []
        for r in range(m):
            for c in range(cols):
                if len(sq) >= n:
                    break
                sq.append(((c + 0.5) * h, (r + 0.5) * h, 0.0, h))
            if len(sq) >= n:
                break
        if len(sq) < n:
            sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        cands.append(sq[:n])
    # 5. random jitter of best grid
    rng = random.Random(12345)
    base_k = int(math.isqrt(n))
    if base_k > 0:
        side = 1.0 / base_k
        for trial in range(10):
            sq = []
            for i in range(base_k):
                for j in range(base_k):
                    if len(sq) >= n:
                        break
                    cx = (i + 0.5) * side + rng.uniform(-0.02, 0.02)
                    cy = (j + 0.5) * side + rng.uniform(-0.02, 0.02)
                    ang = rng.uniform(-0.05, 0.05)
                    s = side * rng.uniform(0.9, 1.05)
                    sq.append((_clip01(cx), _clip01(cy), ang, s))
                if len(sq) >= n:
                    break
            if len(sq) < n:
                sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
            cands.append(sq[:n])
    return cands


# ---------------------------------------------------------------------------
# main entry
# ---------------------------------------------------------------------------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    # degenerate / trivial
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidates(n)

    # refine top candidates
    cands.sort(key=lambda sq: sum(s[3] for s in sq), reverse=True)
    best = cands[0]
    best_val = sum(s[3] for s in best)

    # refine best few
    for cand in cands[:6]:
        refined = _refine(cand, n, maxiter=60)
        v = sum(s[3] for s in refined)
        if v > best_val:
            best_val = v
            best = refined

    # additional random restarts
    rng = random.Random(987654)
    for _ in range(4):
        sq = [(_clip01(rng.random()), _clip01(rng.random()), rng.uniform(0, 0.5),
               rng.uniform(0.02, 0.2)) for _ in range(n)]
        refined = _refine(sq, n, maxiter=40)
        v = sum(s[3] for s in refined)
        if v > best_val:
            best_val = v
            best = refined

    # ensure valid output shape
    out = []
    for i in range(n):
        if i < len(best):
            cx, cy, ang, s = best[i]
        else:
            cx, cy, ang, s = 0.5, 0.5, 0.0, 0.0
        out.append((_clip01(cx), _clip01(cy), _clip01(ang % 0.5), max(0.0, s)))
    return out
