import math
import random
import numpy as np
from scipy.optimize import minimize

# ----------------------------------------------------------------------
# Basic geometry helpers
# ----------------------------------------------------------------------

def corners(cx, cy, ang, s):
    """Return the 4 corners of a square (counter-clockwise)."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    dx, dy = h * ca, h * sa
    ex, ey = -h * sa, h * ca
    return [(cx + dx + ex, cy + dy + ey),
            (cx + dx - ex, cy + dy - ey),
            (cx - dx - ex, cy - dy - ey),
            (cx - dx + ex, cy - dy + ey)]

def _proj_range(pts, ax, ay):
    vals = [p[0]*ax + p[1]*ay for p in pts]
    return min(vals), max(vals)

def sat_overlap(sq1, sq2):
    """Return penetration depth (positive if overlapping) using SAT. 0 if apart."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 0 or s2 <= 0:
        return 0.0
    a1r = a1 * 2.0 * math.pi
    a2r = a2 * 2.0 * math.pi
    c1, s_1 = math.cos(a1r), math.sin(a1r)
    c2, s_2 = math.cos(a2r), math.sin(a2r)
    # axes for squares
    axes = [(c1, s_1), (-s_1, c1), (c2, s_2), (-s_2, c2)]
    p1 = corners(cx1, cy1, a1, s1)
    p2 = corners(cx2, cy2, a2, s2)
    min_pen = float('inf')
    for ax, ay in axes:
        mn1, mx1 = _proj_range(p1, ax, ay)
        mn2, mx2 = _proj_range(p2, ax, ay)
        # overlap along this axis
        pen = min(mx1, mx2) - max(mn1, mn2)
        if pen <= 0:
            return 0.0
        if pen < min_pen:
            min_pen = pen
    return min_pen

def boundary_pen(sq):
    """How far (positive) the square crosses the unit-square boundary."""
    cx, cy, a, s = sq
    if s <= 0:
        return 0.0
    pts = corners(cx, cy, a, s)
    mnx = min(p[0] for p in pts)
    mxx = max(p[0] for p in pts)
    mny = min(p[1] for p in pts)
    mxy = max(p[1] for p in pts)
    pen = 0.0
    if mnx < 0.0: pen = max(pen, -mnx)
    if mxx > 1.0: pen = max(pen, mxx - 1.0)
    if mny < 0.0: pen = max(pen, -mny)
    if mxy > 1.0: pen = max(pen, mxy - 1.0)
    return pen

# ----------------------------------------------------------------------
# Objective for scipy (soft penalties)
# ----------------------------------------------------------------------

def make_obj(n, target_s):
    """Objective: negative total side length plus penalty for overlaps/boundary."""
    def obj(x):
        sqs = [(x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]) for i in range(n)]
        total = sum(s[-1] for s in sqs)
        pen = 0.0
        W = 50.0
        for i in range(n):
            s_i = sqs[i][-1]
            if s_i > 0:
                bp = boundary_pen(sqs[i])
                if bp > 0:
                    pen += W * bp * bp
        for i in range(n):
            for j in range(i+1, n):
                ov = sat_overlap(sqs[i], sqs[j])
                if ov > 0:
                    pen += W * ov * ov
        return -total + pen
    return obj

# ----------------------------------------------------------------------
# Heuristic initial layouts
# ----------------------------------------------------------------------

def grid_layout(n):
    k = int(math.floor(math.sqrt(n)))
    if k == 0: k = 1
    side = 1.0 / k
    sqs = []
    for i in range(k):
        for j in range(k):
            sqs.append(((i+0.5)*side, (j+0.5)*side, 0.0, side))
    # extras as tiny squares
    while len(sqs) < n:
        sqs.append((0.5, 0.5, 0.0, 0.0))
    return sqs[:n]

def row_layout(n):
    """Place squares in rows, each row packed side by side."""
    if n == 0: return []
    # choose number of rows r, each row gets roughly n/r squares
    best = None
    best_sum = -1
    for r in range(1, n+1):
        c = (n + r - 1) // r
        # each square side s, row height s (axis-aligned)
        s = min(1.0 / c, 1.0 / r)
        # But we can put rows with different counts; for simplicity equal
        total = n * s
        if total > best_sum:
            best_sum = total
            best = (r, c, s)
    r, c, s = best
    sqs = []
    idx = 0
    for i in range(r):
        for j in range(c):
            if idx >= n: break
            sqs.append(((j+0.5)*s, (i+0.5)*s, 0.0, s))
            idx += 1
        if idx >= n: break
    while len(sqs) < n:
        sqs.append((0.5, 0.5, 0.0, 0.0))
    return sqs[:n]

def random_layout(n):
    sqs = []
    for _ in range(n):
        s = random.uniform(0.0, 0.3)
        cx = random.uniform(s*0.7, 1-s*0.7)
        cy = random.uniform(s*0.7, 1-s*0.7)
        a = random.uniform(0.0, 1.0)
        sqs.append((cx, cy, a, s))
    return sqs

# ----------------------------------------------------------------------
# Greedy size assignment
# ----------------------------------------------------------------------

def greedy_sizes(n, positions):
    """Given positions and angles, choose sizes greedily (binary search per square
    while avoiding overlaps and boundary)."""
    sqs = [list(p) for p in positions]
    # order by potential area (position far from boundary)
    for idx in range(n):
        lo, hi = 0.0, 1.0
        for _ in range(25):
            mid = (lo + hi) * 0.5
            sqs[idx][3] = mid
            ok = True
            if boundary_pen(tuple(sqs[idx])) > 1e-9:
                ok = False
            if ok:
                for j in range(n):
                    if j == idx: continue
                    if sat_overlap(tuple(sqs[idx]), tuple(sqs[j])) > 1e-9:
                        ok = False
                        break
            if ok:
                lo = mid
            else:
                hi = mid
        sqs[idx][3] = lo
    return [tuple(s) for s in sqs]

# ----------------------------------------------------------------------
# Local improvement (random perturbation + re-greedy)
# ----------------------------------------------------------------------

def improve(n, sqs, iters=200):
    best = [list(s) for s in sqs]
    best_sum = sum(s[3] for s in best)
    for it in range(iters):
        cand = [list(s) for s in best]
        # perturb one or a few squares
        k = random.randint(1, max(1, n//4))
        for _ in range(k):
            i = random.randrange(n)
            cand[i][0] = min(1.0, max(0.0, cand[i][0] + random.gauss(0, 0.06)))
            cand[i][1] = min(1.0, max(0.0, cand[i][1] + random.gauss(0, 0.06)))
            if random.random() < 0.3:
                cand[i][2] = random.random()
        # shrink all sizes to zero then re-assign greedily? Too slow.
        # Instead: reduce sizes slightly, then grow
        for s in cand:
            s[3] *= 0.9
        cand = greedy_sizes(n, cand)
        new_sum = sum(s[3] for s in cand)
        if new_sum > best_sum + 1e-9:
            best = cand
            best_sum = new_sum
    return [tuple(s) for s in best]

# ----------------------------------------------------------------------
# Main solver
# ----------------------------------------------------------------------

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # seed
    random.seed(12345 + n)
    np.random.seed(12345 + n)
    candidates = []
    candidates.append(grid_layout(n))
    candidates.append(row_layout(n))
    for _ in range(3):
        candidates.append(random_layout(n))
    # refine each with scipy
    best_overall = None
    best_score = -1e18
    for init in candidates:
        x0 = []
        for sq in init:
            x0.extend(sq)
        x0 = np.array(x0, dtype=float)
        # bounds: cx, cy in [0,1], angle [0,1), side [0,1]
        bounds = [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)] * n
        obj = make_obj(n, 1.0)
        res = minimize(obj, x0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': 300, 'ftol': 1e-12})
        sqs = [(res.x[4*i], res.x[4*i+1], res.x[4*i+2], res.x[4*i+3]) for i in range(n)]
        # fix overlaps: greedy re-assign sizes
        sqs = greedy_sizes(n, sqs)
        score = sum(s[3] for s in sqs)
        if score > best_score:
            best_score = score
            best_overall = sqs
    # local improvement
    best_overall = improve(n, best_overall, iters=150)
    # final cleanup: if any overlap remains, shrink offending squares
    sqs = [list(s) for s in best_overall]
    changed = True
    while changed:
        changed = False
        # boundary
        for i in range(n):
            if sqs[i][3] > 0 and boundary_pen(tuple(sqs[i])) > 1e-9:
                # shrink
                s = sqs[i][3]
                # compute max shrink to fit
                lo, hi = 0.0, s
                for _ in range(30):
                    mid = (lo+hi)*0.5
                    sqs[i][3] = mid
                    if boundary_pen(tuple(sqs[i])) <= 1e-9:
                        lo = mid
                    else:
                        hi = mid
                sqs[i][3] = lo
                changed = True
        # overlaps
        for i in range(n):
            for j in range(i+1, n):
                ov = sat_overlap(tuple(sqs[i]), tuple(sqs[j]))
                if ov > 1e-9:
                    # shrink the larger one
                    if sqs[i][3] >= sqs[j][3]:
                        k = i
                    else:
                        k = j
                    s = sqs[k][3]
                    lo, hi = 0.0, s
                    for _ in range(30):
                        mid = (lo+hi)*0.5
                        sqs[k][3] = mid
                        ok = boundary_pen(tuple(sqs[k])) <= 1e-9
                        if ok:
                            for jj in range(n):
                                if jj == k: continue
                                if sat_overlap(tuple(sqs[k]), tuple(sqs[jj])) > 1e-9:
                                    ok = False
                                    break
                        if ok:
                            lo = mid
                        else:
                            hi = mid
                    sqs[k][3] = lo
                    changed = True
    # ensure everything in [0,1]
    out = []
    for cx, cy, a, s in sqs:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        a = a % 1.0
        s = max(0.0, min(1.0, s))
        # re-verify: if still out of bounds, clip
        if boundary_pen((cx, cy, a, s)) > 0:
            # shrink to fit
            lo, hi = 0.0, s
            for _ in range(30):
                mid = (lo+hi)*0.5
                if boundary_pen((cx, cy, a, mid)) <= 1e-12:
                    lo = mid
                else:
                    hi = mid
            s = lo
        out.append((cx, cy, a, s))
    return out
# EVOLVE-BLOCK-END
