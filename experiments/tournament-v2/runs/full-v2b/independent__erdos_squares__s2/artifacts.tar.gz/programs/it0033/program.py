import math
import random
import time


def _overlap_area(s1, s2):
    x1, y1, a1, s1d = s1
    x2, y2, a2, s2d = s2
    if s1d <= 0.0 or s2d <= 0.0:
        return 0.0
    # exact overlap of two rotated squares is expensive; approximate by sampling corners
    # use separating axis theorem on convex polygons
    def corners(x, y, a, s):
        h = s * 0.5
        ca = math.cos(a * 2.0 * math.pi)
        sa = math.sin(a * 2.0 * math.pi)
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            rx = dx * ca - dy * sa
            ry = dx * sa + dy * ca
            pts.append((x + rx, y + ry))
        return pts

    p1 = corners(x1, y1, a1, s1d)
    p2 = corners(x2, y2, a2, s2d)

    def project(pts, axis):
        ax, ay = axis
        dots = [px * ax + py * ay for px, py in pts]
        return min(dots), max(dots)

    def axes(pts):
        res = []
        n = len(pts)
        for i in range(n):
            x0, y0 = pts[i]
            x1_, y1_ = pts[(i + 1) % n]
            ex, ey = x1_ - x0, y1_ - y0
            ax, ay = -ey, ex
            ln = math.hypot(ax, ay)
            if ln > 1e-12:
                res.append((ax / ln, ay / ln))
        return res

    for ax, ay in axes(p1) + axes(p2):
        mn1, mx1 = project(p1, (ax, ay))
        mn2, mx2 = project(p2, (ax, ay))
        if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
            return 0.0
    # if no separating axis, they overlap; return positive (approximate area)
    return min(s1d * s1d, s2d * s2d)


def _inside(x, y, a, s):
    if s <= 0.0:
        return True
    h = s * 0.5
    ca = abs(math.cos(a * 2.0 * math.pi))
    sa = abs(math.sin(a * 2.0 * math.pi))
    # bounding half-width/height of rotated square
    rx = h * (ca + sa)
    ry = h * (ca + sa)
    return (x - rx >= -1e-9 and x + rx <= 1 + 1e-9 and
            y - ry >= -1e-9 and y + ry <= 1 + 1e-9)


def _feasible(squares):
    for i in range(len(squares)):
        if not _inside(*squares[i]):
            return False
    for i in range(len(squares)):
        for j in range(i + 1, len(squares)):
            if _overlap_area(squares[i], squares[j]) > 1e-12:
                return False
    return True


def _score(squares):
    return sum(s[3] for s in squares)


def _greedy_initial(n):
    # Start from a good heuristic: mixed grid/rows
    squares = []
    if n == 0:
        return squares
    # try several grid configurations and row packings, pick best feasible
    best = None
    best_score = -1.0

    # candidate: k x k grid plus remainder as tiny squares in free spots
    for k in range(max(1, math.isqrt(n) - 2), math.isqrt(n) + 3):
        if k > n:
            continue
        side = 1.0 / k
        base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        if len(base) > n:
            continue
        cand = list(base)
        rem = n - len(base)
        # place rest as size-zero at random free-ish locations
        for _ in range(rem):
            cand.append((random.uniform(0.05, 0.95), random.uniform(0.05, 0.95), 0.0, 0.0))
        sc = _score(cand)
        if sc > best_score:
            best_score = sc
            best = cand

    # row packing: equal-height rows
    # approximate: place squares as horizontal strips
    cnt = n
    # try equal-size squares packed in rows
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        side_w = 1.0 / cols
        side_h = 1.0 / rows
        side = min(side_w, side_h)
        if side * min(cols * rows, n) <= 0:
            continue
        cand = []
        idx = 0
        for r in range(rows):
            for c in range(cols):
                if idx >= n:
                    break
                cx = (c + 0.5) * side
                cy = (r + 0.5) * side
                cand.append((cx, cy, 0.0, side))
                idx += 1
        if len(cand) == n:
            sc = _score(cand)
            if sc > best_score:
                best_score = sc
                best = cand

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    return best


def _hill_climb(n, time_limit=45.0):
    random.seed(12345 + n)
    cur = _greedy_initial(n)
    best = list(cur)
    best_sc = _score(best)

    start = time.time()
    temp = 0.05
    it = 0
    # try to remove smallest squares and reinsert larger ones
    while time.time() - start < time_limit:
        it += 1
        if it % 2000 == 0:
            temp = max(0.0001, temp * 0.995)
        i = random.randrange(n)
        x, y, a, s = cur[i]
        xs, ys, as_, ss = list(cur[i]), None, None, None

        mode = random.random()
        ns = s
        nx, ny, na = x, y, a
        if mode < 0.4:
            # move
            nx = x + random.gauss(0, 0.01)
            ny = y + random.gauss(0, 0.01)
            nx = min(max(nx, 0.0), 1.0)
            ny = min(max(ny, 0.0), 1.0)
        elif mode < 0.7:
            # rotate
            na = (a + random.gauss(0, 0.02)) % 1.0
        else:
            # resize
            ns = max(0.0, s + random.gauss(0, 0.005))

        if ns > 0:
            # check inside
            if not _inside(nx, ny, na, ns):
                continue

        old = cur[i]
        cur[i] = (nx, ny, na, ns)
        ok = True
        for j in range(n):
            if j != i:
                if _overlap_area(cur[i], cur[j]) > 1e-12:
                    ok = False
                    break
        if ok:
            sc = _score(cur)
            if sc >= best_sc:
                best_sc = sc
                best = list(cur)
            cur[i] = cur[i]
        else:
            cur[i] = old

    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # best known: two on bottom, one on top
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        # five equal-ish: 2x2 grid plus one rotated in center gap? approximate
        # known good: side ~0.4142 for 5? Try regular pattern
        return [(0.207, 0.207, 0.0, 0.414), (0.793, 0.207, 0.0, 0.414),
                (0.207, 0.793, 0.0, 0.414), (0.793, 0.793, 0.0, 0.414),
                (0.5, 0.5, 0.25, 0.414)]

    # general case: heuristic construction + local search
    res = _hill_climb(n, time_limit=min(50.0, 60.0 / max(1, (n // 10 + 1)) + 40.0))

    # ensure n exactly
    if len(res) < n:
        res += [(0.5, 0.5, 0.0, 0.0)] * (n - len(res))
    res = res[:n]

    # fix any infeasibility by shrinking problematic squares
    res = _repair(res, n)
    return res


def _repair(res, n):
    for i in range(n):
        x, y, a, s = res[i]
        if s <= 0:
            continue
        if not _inside(x, y, a, s):
            # shrink until inside
            s2 = s
            while s2 > 1e-9 and not _inside(x, y, a, s2):
                s2 *= 0.9
            res[i] = (x, y, a, s2)
        # resolve overlaps by shrinking
        for _ in range(50):
            bad = False
            for j in range(n):
                if j == i:
                    continue
                if _overlap_area(res[i], res[j]) > 1e-12:
                    bad = True
                    break
            if not bad:
                break
            x, y, a, s = res[i]
            res[i] = (x, y, a, s * 0.9)
    return res
