import math
import random
import time
import numpy as np
from scipy.optimize import minimize

# ----------------------------------------------------------------------
# Geometry helpers
# ----------------------------------------------------------------------

def corners(cx, cy, ang, s):
    """Return 4 corners of square (cx,cy,ang,s). ang in turns."""
    a = ang * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        rx = c * x - sn * y
        ry = sn * x + c * y
        out.append((cx + rx, cy + ry))
    return out

def poly_overlap_area(p1, p2):
    """Approximate overlap area of two convex polygons via SAT + clip
    (for our thin objects; returns 0 if separated)."""
    # quick SAT test
    def axes(poly):
        for i in range(len(poly)):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % len(poly)]
            dx, dy = x2 - x1, y2 - y1
            L = math.hypot(dx, dy)
            if L > 1e-15:
                yield (-dy / L, dx / L)
    for (ax, ay) in axes(p1):
        mn1 = min(x * ax + y * ay for x, y in p1)
        mx1 = max(x * ax + y * ay for x, y in p1)
        mn2 = min(x * ax + y * ay for x, y in p2)
        mx2 = max(x * ax + y * ay for x, y in p2)
        if mx1 - mn2 < 1e-12 or mx2 - mn1 < 1e-12:
            return 0.0
    # overlap in SAT sense; compute approx area via clipped centroid approach
    # use shoelace on intersection polygon computed by halfplane clipping of p1 by p2 edges
    poly = list(p1)
    for i in range(len(p2)):
        if len(poly) < 3:
            return 0.0
        x1, y1 = p2[i]
        x2, y2 = p2[(i + 1) % len(p2)]
        dx, dy = x2 - x1, y2 - y1
        # keep points on left side of edge (inside p2); p2 assumed CCW
        # determine orientation of p2
        area2 = 0.0
        for j in range(len(p2)):
            ax, ay = p2[j]
            bx, by = p2[(j + 1) % len(p2)]
            area2 += ax * by - bx * ay
        sgn = 1.0 if area2 > 0 else -1.0
        newpoly = []
        for j in range(len(poly)):
            px, py = poly[j]
            qx, qy = poly[(j + 1) % len(poly)]
            dp = sgn * (dx * (py - y1) - dy * (px - x1))
            dq = sgn * (dx * (qy - y1) - dy * (qx - x1))
            if dp >= -1e-15:
                newpoly.append((px, py))
            if (dp > 1e-15 and dq < -1e-15) or (dp < -1e-15 and dq > 1e-15):
                t = dp / (dp - dq)
                newpoly.append((px + t * (qx - px), py + t * (qy - py)))
        poly = newpoly
    if len(poly) < 3:
        return 0.0
    A = 0.0
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        A += x1 * y2 - x2 * y1
    return abs(A) * 0.5

def in_unit(cx, cy, ang, s, eps=1e-9):
    for (x, y) in corners(cx, cy, ang, s):
        if x < -eps or x > 1 + eps or y < -eps or y > 1 + eps:
            return False
    return True

# ----------------------------------------------------------------------
# Objective: sum of sides, with penalties for overlaps and out-of-bounds
# ----------------------------------------------------------------------

def penalty_and_score(squares):
    n = len(squares)
    S = sum(sq[3] for sq in squares)
    pen = 0.0
    # bounds
    for (cx, cy, ang, s) in squares:
        if s <= 0:
            continue
        for (x, y) in corners(cx, cy, ang, s):
            if x < 0:
                pen += (0 - x) ** 2
            if x > 1:
                pen += (x - 1) ** 2
            if y < 0:
                pen += (0 - y) ** 2
            if y > 1:
                pen += (y - 1) ** 2
    # overlaps
    polys = [corners(cx, cy, ang, s) for (cx, cy, ang, s) in squares]
    for i in range(n):
        for j in range(i + 1, n):
            if squares[i][3] <= 0 and squares[j][3] <= 0:
                continue
            ov = poly_overlap_area(polys[i], polys[j])
            if ov > 0:
                pen += ov
    return S, pen

# ----------------------------------------------------------------------
# Repair: shrink squares / move to reduce overlap
# ----------------------------------------------------------------------

def try_layout(cxs, cys, angs, sides, iters=200, seed=0):
    n = len(sides)
    rng = random.Random(seed)
    cur = [(cxs[i], cys[i], angs[i], sides[i]) for i in range(n)]

    def obj(v):
        sq = [(v[4*i], v[4*i+1], v[4*i+2], v[4*i+3]) for i in range(n)]
        S, pen = penalty_and_score(sq)
        return -S + 1e5 * pen

    x = np.array([c for sq in cur for c in sq])
    # bounds: cx,cy in [0,1], ang in [-1,1], side in [0,1]
    lb = [0.0, 0.0, -1.0, 0.0] * n
    ub = [1.0, 1.0, 1.0, 1.0] * n
    res = minimize(obj, x, method='L-BFGS-B', bounds=list(zip(lb, ub)),
                   options={'maxiter': iters, 'ftol': 1e-12, 'gtol': 1e-10})
    x = res.x
    cur = [(x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]) for i in range(n)]
    S, pen = penalty_and_score(cur)
    # final aggressive shrink until valid
    cur2 = [list(sq) for sq in cur]
    for it in range(300):
        S, pen = penalty_and_score([tuple(sq) for sq in cur2])
        if pen < 1e-9:
            break
        # shrink smallest affected squares and nudge
        for i in range(n):
            cx, cy, ang, s = cur2[i]
            if s <= 1e-12:
                continue
            cur2[i][3] = s * 0.999
            cur2[i][0] = min(1.0, max(0.0, cx + rng.uniform(-0.001, 0.001)))
            cur2[i][1] = min(1.0, max(0.0, cy + rng.uniform(-0.001, 0.001)))
    return [(c, y, a % 1.0, min(1.0, max(0.0, s))) for (c, y, a, s) in cur2]

# ----------------------------------------------------------------------
# Initial layouts
# ----------------------------------------------------------------------

def grid_layout(n, seed=0):
    k = math.isqrt(n)
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n]

def random_layout(n, seed=0):
    rng = random.Random(seed)
    sq = []
    for i in range(n):
        s = rng.uniform(0.0, 0.3) / math.sqrt(n)
        cx = rng.uniform(0.05, 0.95)
        cy = rng.uniform(0.05, 0.95)
        a = rng.uniform(0.0, 1.0)
        sq.append((cx, cy, a, s))
    return sq

def strip_layout(n, seed=0):
    """Random guillotine-ish vertical strips."""
    rng = random.Random(seed)
    sizes = [rng.random() + 0.1 for _ in range(n)]
    tot = sum(sizes)
    sq = []
    x = 0.0
    for i in range(n):
        w = sizes[i] / tot
        s = min(w, 1.0)
        # make it a square of side s, centered in strip
        cx = x + w / 2.0
        cy = 0.5
        angle = 0.0
        sq.append((cx, cy, angle, s))
        x += w
    return sq

def column_layout(n, seed=0):
    rng = random.Random(seed)
    k = max(1, int(math.sqrt(n)))
    rows = (n + k - 1) // k
    sq = []
    idx = 0
    for r in range(rows):
        cols_here = min(k, n - idx)
        w = 1.0 / cols_here
        h = 1.0 / rows
        s = min(w, h)
        for c in range(cols_here):
            cx = (c + 0.5) * w
            cy = (r + 0.5) * h
            sq.append((cx, cy, 0.0, s))
            idx += 1
    return sq[:n]

# ----------------------------------------------------------------------
# Main solver
# ----------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    random.seed(12345)
    t_end = time.time() + 55.0

    starts = []
    starts.append(grid_layout(n))
    starts.append(random_layout(n, 1))
    starts.append(random_layout(n, 2))
    starts.append(strip_layout(n, 3))
    starts.append(column_layout(n, 4))
    for k in range(5, 12):
        starts.append(random_layout(n, k))

    best = None
    best_score = -1.0

    for si, init in enumerate(starts):
        if time.time() > t_end:
            break
        cxs = [sq[0] for sq in init]
        cys = [sq[1] for sq in init]
        angs = [sq[2] for sq in init]
        sides = [sq[3] for sq in init]

        # scale sides up a bit (infeasible start) but keep <=1
        maxs = max(max(sides), 1e-9)
        if maxs > 0:
            factor = min(1.0 / maxs, 1.0)
            sides = [min(1.0, s * factor) for s in sides]

        iters = 300 if n <= 10 else 200
        try:
            res = try_layout(cxs, cys, angs, sides, iters=iters, seed=si)
            S, pen = penalty_and_score(res)
            if pen < 1e-7 and S > best_score:
                best_score = S
                best = res
        except Exception:
            continue

    if best is None:
        best = grid_layout(n)

    # final validity clamp
    out = []
    for (cx, cy, ang, s) in best[:n]:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = min(1.0, max(0.0, s))
        out.append((cx, cy, ang, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
