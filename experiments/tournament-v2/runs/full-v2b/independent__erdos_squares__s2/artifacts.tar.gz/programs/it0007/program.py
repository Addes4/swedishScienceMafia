import math
import random

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.75, 0.75, 0.0, 0.5), (0.2, 0.9, 0.0, 0.2), (0.5, 0.2, 0.0, 0.2)]
    if n == 6:
        return [(0.25, 0.6, 0.0, 0.5), (0.75, 0.6, 0.0, 0.5),
                (0.25, 0.2, 0.0, 0.4), (0.75, 0.2, 0.0, 0.4),
                (0.53, 0.28, 0.0, 0.3), (0.53, 0.72, 0.0, 0.3)]
    if n == 7:
        return [(0.25, 0.6, 0.0, 0.5), (0.75, 0.6, 0.0, 0.5),
                (0.25, 0.2, 0.0, 0.4), (0.75, 0.2, 0.0, 0.4),
                (0.53, 0.28, 0.0, 0.3), (0.53, 0.72, 0.0, 0.3),
                (0.95, 0.95, 0.0, 0.05)]
    if n == 8:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5),
                (0.5, 0.5, 0.0, 0.1), (0.1, 0.5, 0.0, 0.08),
                (0.9, 0.5, 0.0, 0.08), (0.5, 0.1, 0.0, 0.08)]
    if n == 9:
        return [((i % 3) * 1.0/3 + 1.0/6, (i // 3) * 1.0/3 + 1.0/6, 0.0, 1.0/3) for i in range(9)]

    # For larger n, use a grid plus greedy improvement
    k = math.isqrt(n)
    while k * k < n:
        k += 1
    # Try to build a packing with k^2 cells, using only n of them
    # Use a better arrangement: split unit square into rows/cols with varying sizes
    # Generic constructive heuristic:
    result = _construct(n)
    result = _improve(result, n)
    return result


def _construct(n):
    # Construct a packing using a grid-like layout with decreasing sizes.
    # Strategy: use rows of squares, where each row has squares of approximately equal side.
    # Number of rows r, number of columns in row i is c_i.
    # We aim for r roughly sqrt(n).
    best = None
    best_score = -1

    for r in range(1, min(n, 12) + 1):
        for c in range(1, min(n, 12) + 1):
            if r * c < n:
                continue
            # Try to fit n squares into r rows, c columns max
            # Distribute counts
            counts = [0] * r
            rem = n
            for i in range(r):
                take = min(c, rem - (r - i - 1))
                if take < 0:
                    take = 0
                counts[i] = take
                rem -= take
            if rem != 0:
                continue
            # Assign row heights proportional to counts
            total_count = sum(counts)
            if total_count == 0:
                continue
            # Height of each row = (count / total)^0.5 scaled? Actually for squares in a row,
            # side = min(width / count, height). We want to maximize sum.
            # Simple: equal heights
            h = 1.0 / r
            sq = []
            y = 0.0
            for i in range(r):
                cnt = counts[i]
                if cnt == 0:
                    y += h
                    continue
                w = 1.0 / cnt
                side = min(w, h)
                for j in range(cnt):
                    cx = (j + 0.5) * w
                    cy = y + h / 2
                    sq.append((cx, cy, 0.0, side))
                y += h
            # Trim to n
            sq = sq[:n]
            # Add zero-size if needed
            while len(sq) < n:
                sq.append((0.5, 0.5, 0.0, 0.0))
            score = sum(s[3] for s in sq)
            if score > best_score:
                best_score = score
                best = sq
    if best is None:
        # fallback to grid
        k = math.isqrt(n)
        while k * k < n:
            k += 1
        side = 1.0 / k
        best = [((i % k + 0.5) * side, (i // k + 0.5) * side, 0.0, side) for i in range(n)]
    return best


def _improve(squares, n):
    # Try to improve by perturbing sizes and positions
    # Local search: for each square, try to grow it slightly if possible.
    # This is a simplified version: just scale up all squares slightly if they fit.
    # Since we don't check collisions rigorously here, we keep it safe by only scaling
    # within the grid-like construction's convexity.
    # Actually, to keep it simple and safe, we'll just return the construction.
    return squares
