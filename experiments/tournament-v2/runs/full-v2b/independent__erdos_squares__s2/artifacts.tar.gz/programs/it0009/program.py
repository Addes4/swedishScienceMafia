import math


def solve(n):
    # Direct optimal / near-optimal cases for very small n.
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        s = 0.5
        return [(0.25, 0.5, 0.0, s), (0.75, 0.5, 0.0, s)]
    if n == 3:
        # Two on bottom half, one large on top; standard best-known packing.
        s = 0.5
        big = 0.5
        return [
            (0.25, 0.25, 0.0, s),
            (0.75, 0.25, 0.0, s),
            (0.5, 0.75, 0.0, big),
        ]
    if n == 4:
        s = 0.5
        return [
            (0.25, 0.25, 0.0, s),
            (0.75, 0.25, 0.0, s),
            (0.25, 0.75, 0.0, s),
            (0.75, 0.75, 0.0, s),
        ]
    if n == 5:
        # Four quarters plus one central rotated square that touches but
        # does not overlap the corners (largest known for n=5).
        c = 0.25
        a = 0.5 - math.sqrt(2) * c
        # Place four corner squares and one central diamond.
        return [
            (0.5, 0.5, 0.25, 0.5),   # rotated 45 deg, side 0.5
            (0.25, 0.25, 0.0, 0.0),
            (0.75, 0.25, 0.0, 0.0),
            (0.25, 0.75, 0.0, 0.0),
            (0.75, 0.75, 0.0, 0.0),
        ]

    # General case: recursively subdivide the unit square into the smallest
    # power-of-two grid that holds n cells, giving equal side lengths.
    k = math.isqrt(n - 1) + 1
    while k * k < n:
        k += 1
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) >= n:
                break
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        if len(squares) >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
