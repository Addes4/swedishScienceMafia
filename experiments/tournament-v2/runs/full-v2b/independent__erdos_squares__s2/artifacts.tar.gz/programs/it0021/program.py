import math
import random
import numpy as np
from scipy.optimize import minimize

# ----------------------------------------------------------------------
# Geometry helpers
# ----------------------------------------------------------------------

def corners(cx, cy, ang, side):
    """Return the 4 corners of a square (as numpy array)."""
    c, s = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
    h = side / 2.0
    pts = np.array([[h, h], [-h, h], [-h, -h], [h, -h]], dtype=float)
    R = np.array([[c, -s], [s, c]])
    return pts @ R.T + np.array([cx, cy])


def sep_axes(cx, cy, ang):
    """Unit vectors of the two edge directions of a square."""
    c, s = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
    return np.array([[c, s], [-s, c]])


def overlap_penalty(squares):
    """Sum of squared overlap amounts (SAT based) for all pairs."""
    n = len(squares)
    pen = 0.0
    for i in range(n):
        cx1, cy1, a1, s1 = squares[i]
        if s1 <= 0:
            continue
        ax1 = sep_axes(cx1, cy1, a1)
        c1 = corners(cx1, cy1, a1, s1)
        for j in range(i + 1, n):
            cx2, cy2, a2, s2 = squares[j]
            if s2 <= 0:
                continue
            ax2 = sep_axes(cx2, cy2, a2)
            c2 = corners(cx2, cy2, a2, s2)
            min_ov = 1e18
            for ax in (ax1[0], ax1[1], ax2[0], ax2[1]):
                p1 = c1 @ ax
                p2 = c2 @ ax
                ov = min(p1.max(), p2.max()) - max(p1.min(), p2.min())
                if ov < min_ov:
                    min_ov = ov
                if min_ov <= 0:
                    break
            if min_ov > 0:
                pen += min_ov * min_ov
    return pen


def boundary_penalty(squares):
    """Penalty for going outside [0,1]^2."""
    pen = 0.0
    for cx, cy, ang, s in squares:
        if s <= 0:
            continue
        pts = corners(cx, cy, ang, s)
        xs, ys = pts[:, 0], pts[:, 1]
        pen += max(0.0, -xs.min()) ** 2 + max(0.0, xs.max() - 1.0) ** 2
        pen += max(0.0, -ys.min()) ** 2 + max(0.0, ys.max() - 1.0) ** 2
    return pen


def total_objective(params, n):
    """Negate sum of sides + penalties (for minimisation)."""
    squares = params_to_squares(params, n)
    total = sum(s for (_, _, _, s) in squares)
    pen = 1000.0 * (overlap_penalty(squares) + boundary_penalty(squares))
    return -total + pen


def params_to_squares(params, n):
    """params length 4n: cx, cy, ang, side."""
    out = []
    for i in range(n):
        cx = min(max(params[4 * i], 0.0), 1.0)
        cy = min(max(params[4 * i + 1], 0.0), 1.0)
        ang = params[4 * i + 2] % 1.0
        side = max(0.0, params[4 * i + 3])
        out.append((cx, cy, ang, side))
    return out


def squares_to_params(squares):
    p = []
    for (cx, cy, ang, s) in squares:
        p += [cx, cy, ang, s]
    return np.array(p, dtype=float)


def feasible(squares, eps=1e-7):
    """Check feasibility exactly."""
    if boundary_penalty(squares) > 1e-6:
        return False
    if overlap_penalty(squares) > eps:
        return False
    return True


# ----------------------------------------------------------------------
# Initial tilings
# ----------------------------------------------------------------------

def grid_init(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
          for i in range(k) for j in range(k)]
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq[:n]


def smart_init(n):
    """A few good hand-crafted starts for small n, otherwise grid."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # two bottom halves + one top, adjust so top fits? use grid-2 and a zero
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        # four corner squares + rotated centre; scale corner a bit smaller
        a = 1.0 / (2.0 + math.sqrt(2.0))
        if a * 2 > 1.0:
            a = 0.4
        d = 1.0 - a
        side_c = math.sqrt(2.0) * (0.5 - a) * 2 if False else 0.0
        return [(a / 2, a / 2, 0.0, a), (1 - a / 2, a / 2, 0.0, a),
                (a / 2, 1 - a / 2, 0.0, a), (1 - a / 2, 1 - a / 2, 0.0, a),
                (0.5, 0.5, 0.25, 0.0)]
    if n == 6:
        return [(0.25, 1 / 6, 0.0, 1 / 3), (0.75, 1 / 6, 0.0, 1 / 3),
                (0.25, 0.5, 0.0, 1 / 3), (0.75, 0.5, 0.0, 1 / 3),
                (0.25, 5 / 6, 0.0, 1 / 3), (0.75, 5 / 6, 0.0, 1 / 3)]
    return grid_init(n)


# ----------------------------------------------------------------------
# Local optimisation
# ----------------------------------------------------------------------

def optimise(squares, n, maxiter=200, refine_iters=6):
    params = squares_to_params(squares)

    bounds = []
    for _ in range(n):
        bounds += [(0.0, 1.0), (0.0, 1.0), (None, None), (0.0, 1.0)]

    def obj(p):
        return total_objective(p, n)

    best_params = params.copy()
    best_val = obj(best_params)

    cur = params.copy()
    for it in range(refine_iters):
        res = minimize(obj, cur, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': maxiter, 'ftol': 1e-14, 'gtol': 1e-12})
        if res.fun < best_val:
            best_val = res.fun
            best_params = res.x.copy()
        # random perturbation to escape
        cur = best_params + np.array([random.uniform(-0.05, 0.05) for _ in range(4 * n)])
        cur[3::4] = np.clip(cur[3::4], 0.0, 1.0)
        cur[0::4] = np.clip(cur[0::4], 0.0, 1.0)
        cur[1::4] = np.clip(cur[1::4], 0.0, 1.0)

    return params_to_squares(best_params, n), best_val


def polish_sides(squares):
    """Greedily shrink sides until strictly feasible."""
    sq = [list(s) for s in squares]
    for _ in range(200):
        if feasible([tuple(s) for s in sq]):
            break
        # shrink all positive sides slightly
        changed = False
        for s in sq:
            if s[3] > 1e-12:
                s[3] *= 0.999
                changed = True
        if not changed:
            break
    return [tuple(s) for s in sq]


def scale_to_fit(squares):
    """Uniformly scale all positive squares to fit inside unit box, then shrink for overlap."""
    pos = [s for s in squares if s[3] > 1e-12]
    if not pos:
        return squares
    cx = sum(s[0] for s in pos) / len(pos)
    cy = sum(s[1] for s in pos) / len(pos)
    # bounding radius
    maxr = 0.0
    for (x, y, a, sd) in pos:
        pts = corners(x, y, a, sd)
        r = np.max(np.sqrt((pts[:, 0] - cx) ** 2 + (pts[:, 1] - cy) ** 2))
        maxr = max(maxr, r)
    if maxr <= 0:
        return squares
    # fit inside box centred at .5,.5 if possible
    return squares


# ----------------------------------------------------------------------
# Main solver
# ----------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345 + n)
    np.random.seed(12345 + n)

    best = None
    best_score = -1.0

    starts = []
    starts.append(smart_init(n))
    starts.append(grid_init(n))

    # simple hierarchical: split into equal rows/cols variants
    for cols in range(1, n + 1):
        if n % cols == 0:
            rows = n // cols
            s = min(1.0 / cols, 1.0 / rows)
            sq = []
            for i in range(cols):
                for j in range(rows):
                    sq.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
            starts.append(sq)

    time_budget = 55.0
    import time
    t0 = time.time()

    for start in starts:
        if time.time() - t0 > time_budget:
            break
        sq = start
        # shrink tiny overlaps first
        for _ in range(30):
            if feasible(sq):
                break
            sq = [(x, y, a, s * 0.995) for (x, y, a, s) in sq]
        sq, val = optimise(sq, n, maxiter=150, refine_iters=4)
        sq = polish_sides(sq)
        score = sum(s[3] for s in sq)
        if score > best_score:
            best_score = score
            best = sq

    # Additional focused search from best
    while time.time() - t0 < time_budget:
        sq = [(x, y, a, s) for (x, y, a, s) in best]
        # random tweak
        for i in range(n):
            if random.random() < 0.5:
                x, y, a, s = sq[i]
                x = min(1.0, max(0.0, x + random.uniform(-0.03, 0.03)))
                y = min(1.0, max(0.0, y + random.uniform(-0.03, 0.03)))
                a = (a + random.uniform(-0.03, 0.03)) % 1.0
                s = min(1.0, max(0.0, s * random.uniform(0.97, 1.03)))
                sq[i] = (x, y, a, s)
        sq = [(x, y, a, s * 0.995) for (x, y, a, s) in sq]
        sq, val = optimise(sq, n, maxiter=60, refine_iters=2)
        sq = polish_sides(sq)
        score = sum(s[3] for s in sq)
        if score > best_score:
            best_score = score
            best = sq

    # final cleanup: ensure feasibility
    if not feasible(best):
        for _ in range(200):
            best = [(x, y, a, s * 0.999) for (x, y, a, s) in best]
            if feasible(best):
                break

    # snap to [0,1]
    out = []
    for (x, y, a, s) in best:
        x = min(1.0, max(0.0, x))
        y = min(1.0, max(0.0, y))
        a = a % 1.0
        s = max(0.0, min(1.0, s))
        out.append((x, y, a, s))
    return out
