import math
import numpy as np
from scipy.optimize import minimize


def _inside_and_disjoint(params, n):
    """Return penalty for containment outside unit square and pairwise overlap."""
    p = params.reshape(n, 4)
    cx, cy, ang, s = p[:, 0], p[:, 1], p[:, 2], p[:, 3]
    s = np.maximum(s, 0.0)
    # half-diagonal extent of a rotated square: half side * (|cos|+|sin|)
    c = np.abs(np.cos(2 * np.pi * ang))
    sn = np.abs(np.sin(2 * np.pi * ang))
    ext = 0.5 * s * (c + sn)
    pen = 0.0
    # containment: centre must be at least ext away from all sides
    pen += np.sum(np.maximum(0.0, ext - cx) ** 2)
    pen += np.sum(np.maximum(0.0, ext - (1.0 - cx)) ** 2)
    pen += np.sum(np.maximum(0.0, ext - cy) ** 2)
    pen += np.sum(np.maximum(0.0, ext - (1.0 - cy)) ** 2)
    # separation between every pair of squares (SAT for rotated rectangles)
    for i in range(n):
        for j in range(i + 1, n):
            dx = cx[i] - cx[j]
            dy = cy[i] - cy[j]
            # axes of square i
            ai = 2 * np.pi * ang[i]
            uix, uiy = np.cos(ai), np.sin(ai)
            vix, viy = -uiy, uix
            # axes of square j
            aj = 2 * np.pi * ang[j]
            ujx, ujy = np.cos(aj), np.sin(aj)
            vjx, vjy = -ujy, ujx
            axes = ((uix, uiy), (vix, viy), (ujx, ujy), (vjx, vjy))
            min_gap = 1e9
            for ax, ay in axes:
                pi = 0.5 * s[i] * (np.abs(ax * uix + ay * uiy) + np.abs(ax * vix + ay * viy))
                pj = 0.5 * s[j] * (np.abs(ax * ujx + ay * ujy) + np.abs(ax * vjx + ay * vjy))
                d = abs(dx * ax + dy * ay)
                gap = d - (pi + pj)
                if gap < min_gap:
                    min_gap = gap
            pen += max(0.0, min_gap) ** 2
    return pen


def _objective(params, n):
    p = params.reshape(n, 4)
    s = np.maximum(p[:, 3], 0.0)
    return -np.sum(s) + 500.0 * _inside_and_disjoint(params, n)


def _repair_feasible(params, n, iters=60):
    """Greedy shrink to enforce feasibility before optimization."""
    p = params.reshape(n, 4).copy()
    for _ in range(iters):
        pen = _inside_and_disjoint(p.reshape(-1), n)
        if pen < 1e-14:
            break
        p[:, 3] *= 0.97
    return p.reshape(-1)


def _initial_grid(n):
    """Start from a near-square grid, then random perturb slightly."""
    k = max(1, int(round(math.sqrt(n))))
    rows = k
    cols = (n + rows - 1) // rows
    side = min(1.0 / rows, 1.0 / cols) * 0.95
    p = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            cx = (c + 0.5) / cols
            cy = (r + 0.5) / rows
            p.append((cx, cy, 0.0, side))
            idx += 1
    while len(p) < n:
        p.append((0.5, 0.5, 0.0, 0.0))
    p = np.array(p[:n], dtype=float)
    return p


def _initial_random(n, rng):
    p = np.zeros((n, 4))
    p[:, 0] = rng.uniform(0.1, 0.9, n)
    p[:, 1] = rng.uniform(0.1, 0.9, n)
    p[:, 2] = rng.uniform(0.0, 1.0, n)
    p[:, 3] = rng.uniform(0.0, 0.25, n)
    return p


def _optimize(n, p0, maxiter=400):
    p0 = _repair_feasible(p0.reshape(-1), n)
    # bounds: centre [0,1], angle [0,1), side [0,1]
    bounds = [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)] * n
    res = minimize(
        _objective,
        p0,
        args=(n,),
        method="L-BFGS-B",
        bounds=bounds,
        options={"maxiter": maxiter, "ftol": 1e-12, "gtol": 1e-10},
    )
    p = res.x.reshape(n, 4)
    p[:, 3] = np.maximum(p[:, 3], 0.0)
    return -_objective(res.x, n) + 500.0 * _inside_and_disjoint(res.x, n), p


def solve(n):
    """Return n non-overlapping squares in unit square maximising sum of sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    rng = np.random.default_rng(12345)
    best_sum = -1.0
    best_p = None

    starts = []
    starts.append(_initial_grid(n))
    # several random starts
    for _ in range(8):
        starts.append(_initial_random(n, rng))

    # special structured starts for small n
    if n <= 8:
        # try equal-ish grid and row arrangement
        for rows in range(1, n + 1):
            cols = (n + rows - 1) // rows
            side = min(1.0 / rows, 1.0 / cols) * 0.99
            p = []
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= n:
                        break
                    p.append(((c + 0.5) / cols, (r + 0.5) / rows, 0.0, side))
                    idx += 1
            while len(p) < n:
                p.append((0.5, 0.5, 0.0, 0.0))
            starts.append(np.array(p[:n], dtype=float))

    for p0 in starts:
        try:
            val, p = _optimize(n, p0)
            if val > best_sum:
                best_sum = val
                best_p = p.copy()
        except Exception:
            continue

    if best_p is None:
        best_p = _initial_grid(n)

    # final safety: if still overlapping, shrink
    for _ in range(100):
        if _inside_and_disjoint(best_p.reshape(-1), n) < 1e-9:
            break
        best_p[:, 3] *= 0.98

    result = []
    for i in range(n):
        cx, cy, ang, s = best_p[i]
        cx = float(np.clip(cx, 0.0, 1.0))
        cy = float(np.clip(cy, 0.0, 1.0))
        ang = float(ang % 1.0)
        s = float(max(0.0, s))
        # final clamp for containment with rotation
        c = abs(math.cos(2 * math.pi * ang))
        sn = abs(math.sin(2 * math.pi * ang))
        ext = 0.5 * s * (c + sn)
        if ext > 0.5 + 1e-12:
            s = 1.0 / (c + sn + 1e-12)
            ext = 0.5 * s * (c + sn)
        cx = min(max(cx, ext), 1.0 - ext)
        cy = min(max(cy, ext), 1.0 - ext)
        result.append((cx, cy, ang, s))
    return result
