import math
import random
import numpy as np
from scipy.optimize import minimize

EPS = 1e-12


def _overlap_amount(sq1, sq2):
    """Return >0 if interiors overlap, 0 or negative for separation (SAT for squares)."""
    x1, y1, a1, s1 = sq1
    x2, y2, a2, s2 = sq2
    if s1 <= 0 or s2 <= 0:
        return -1.0
    h1 = s1 * 0.5
    h2 = s2 * 0.5
    t1 = a1 * 2.0 * math.pi
    t2 = a2 * 2.0 * math.pi
    c1, sn1 = math.cos(t1), math.sin(t1)
    c2, sn2 = math.cos(t2), math.sin(t2)
    axes = [(c1, sn1), (-sn1, c1), (c2, sn2), (-sn2, c2)]
    dx = x2 - x1
    dy = y2 - y1
    min_sep = 1e9
    for ax, ay in axes:
        dist = dx * ax + dy * ay
        r1 = h1 * (abs(c1 * ax + sn1 * ay) + abs(-sn1 * ax + c1 * ay))
        r2 = h2 * (abs(c2 * ax + sn2 * ay) + abs(-sn2 * ax + c2 * ay))
        sep = abs(dist) - (r1 + r2)
        if sep > min_sep:
            min_sep = sep
        if sep > 1e-9:
            return -1.0
    return -min_sep


def _overlap_penalty(sq1, sq2):
    ov = _overlap_amount(sq1, sq2)
    if ov <= 0:
        return 0.0
    return ov * ov


def _wall_penalty(x, y, a, s):
    if s <= 0:
        return 0.0
    t = a * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    ex = h * (abs(c) + abs(sn))
    ey = h * (abs(sn) + abs(c))
    p = 0.0
    if x - ex < 0:
        p += (ex - x) ** 2
    if x + ex > 1:
        p += (x + ex - 1.0) ** 2
    if y - ey < 0:
        p += (ey - y) ** 2
    if y + ey > 1:
        p += (y + ey - 1.0) ** 2
    return p


def _pack_objective(vars, n, w_overlap=1.0, w_wall=1.0):
    total = 0.0
    sq = []
    idx = 0
    for i in range(n):
        x = vars[idx]
        y = vars[idx + 1]
        a = vars[idx + 2]
        s = vars[idx + 3]
        idx += 4
        sq.append((x, y, a, s))
        total -= s
        total += w_wall * _wall_penalty(x, y, a, s)
    for i in range(n):
        for j in range(i + 1, n):
            total += w_overlap * _overlap_penalty(sq[i], sq[j])
    return total


def _to_vars(squares):
    v = []
    for x, y, a, s in squares:
        v.extend([x, y, a, s])
    return np.array(v, dtype=float)


def _from_vars(vars, n):
    sq = []
    for i in range(n):
        x = float(np.clip(vars[4 * i], 0.0, 1.0))
        y = float(np.clip(vars[4 * i + 1], 0.0, 1.0))
        a = float(vars[4 * i + 2]) % 1.0
        s = float(np.clip(vars[4 * i + 3], 0.0, 1.0))
        sq.append((x, y, a, s))
    return sq


def _feasible(squares):
    n = len(squares)
    for i in range(n):
        x, y, a, s = squares[i]
        if s < 0:
            return False
        t = a * 2.0 * math.pi
        c, sn = math.cos(t), math.sin(t)
        h = s * 0.5
        ex = h * (abs(c) + abs(sn))
        ey = h * (abs(sn) + abs(c))
        if x - ex < -1e-7 or x + ex > 1 + 1e-7:
            return False
        if y - ey < -1e-7 or y + ey > 1 + 1e-7:
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap_amount(squares[i], squares[j]) > 1e-7:
                return False
    return True


def _score(squares):
    return sum(s for _, _, _, s in squares)


def _repair(squares):
    sq = list(squares)
    n = len(sq)
    for _ in range(50):
        changed = False
        for i in range(n):
            x, y, a, s = sq[i]
            if s <= 0:
                continue
            t = a * 2.0 * math.pi
            c, sn = math.cos(t), math.sin(t)
            h = s * 0.5
            ex = h * (abs(c) + abs(sn))
            ey = h * (abs(sn) + abs(c))
            nx, ny = x, y
            if nx - ex < 0:
                nx = ex
            if nx + ex > 1:
                nx = 1 - ex
            if ny - ey < 0:
                ny = ey
            if ny + ey > 1:
                ny = 1 - ey
            if nx != x or ny != y:
                sq[i] = (nx, ny, a, s)
                changed = True
        for i in range(n):
            for j in range(i + 1, n):
                if _overlap_amount(sq[i], sq[j]) > 1e-7:
                    xi, yi, ai, si = sq[i]
                    xj, yj, aj, sj = sq[j]
                    dx = xj - xi
                    dy = yj - yi
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        dx = 1.0
                        dy = 0.0
                        d = 1.0
                    dx /= d
                    dy /= d
                    shift = 0.0005
                    sq[i] = (xi - dx * shift, yi - dy * shift, ai, si)
                    sq[j] = (xj + dx * shift, yj + dy * shift, aj, sj)
                    changed = True
        if not changed:
            break
    # small shrink of violated squares
    for i in range(n):
        x, y, a, s = sq[i]
        if s <= 0:
            continue
        shrunk = False
        for j in range(n):
            if i == j:
                continue
            ov = _overlap_amount(sq[i], sq[j])
            if ov > 0:
                sq[i] = (x, y, a, max(0.0, s - ov * 1.05))
                shrunk = True
                break
        if shrunk:
            continue
    return [tuple(map(float, t)) for t in sq]


def _initial_grid(n, mode=0):
    squares = []
    remaining = n
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    k = math.isqrt(n)
    while k > 0 and k * k > n:
        k -= 1
    base = 1.0 / max(k, 1)
    placed = 0
    if mode == 0:
        for i in range(k):
            for j in range(k):
                if placed >= remaining:
                    break
                squares.append(((i + 0.5) * base, (j + 0.5) * base, 0.0, base))
                placed += 1
        while placed < remaining:
            squares.append((0.5, 0.5, 0.0, 0.0))
            placed += 1
        return squares
    elif mode == 1:
        for i in range(k):
            for j in range(k):
                if placed >= remaining:
                    break
                squares.append(((i + 0.5) * base, (j + 0.5) * base, 0.0, base))
                placed += 1
        if placed < remaining:
            squares.append((0.5, 0.5, 0.0, 0.0))
            placed += 1
        while placed < remaining:
            squares.append((0.5, 0.5, 0.0, 0.0))
            placed += 1
        return squares
    elif mode == 2:
        for i in range(k):
            for j in range(k):
                if placed >= remaining:
                    break
                squares.append(((i + 0.5) * base, (j + 0.5) * base, 0.0, base))
                placed += 1
        while placed < remaining:
            squares.append((0.5, 0.5, 0.0, 0.0))
            placed += 1
        return squares
    return squares


def _initial_random(n, rng):
    sq = []
    for _ in range(n):
        s = rng.random() * (1.0 / math.sqrt(max(n, 1)))
        s = min(s, 1.0)
        x = rng.random() * (1.0 - s) + s * 0.5
        y = rng.random() * (1.0 - s) + s * 0.5
        a = rng.random() if rng.random() < 0.3 else 0.0
        sq.append((x, y, a, s))
    return sq


def _initial_scaled(n, factor, mode):
    sq = _initial_grid(n, mode)
    out = []
    for x, y, a, s in sq:
        out.append((x, y, a, s * factor))
    return out


def _initial_near_opt(n):
    """A heuristic pattern: one large square in a corner plus grid of rest."""
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    k = int(math.floor(math.sqrt(n - 1)))
    if k <= 0:
        return [(0.5, 0.5, 0.0, 1.0 / n)] * n
    small = 1.0 / (k + 1)
    large = 1.0 - small
    sq = [(small + large * 0.5, small + large * 0.5, 0.0, large)]
    # place k*k small squares in the remaining L-shaped strip
    cells = []
    for i in range(k + 1):
        for j in range(k + 1):
            if i == k and j == k:
                continue
            cells.append((i, j))
    rng = random.Random(12345)
    rng.shuffle(cells)
    for idx, (i, j) in enumerate(cells):
        if len(sq) >= n:
            break
        x = i * small + small * 0.5
        y = j * small + small * 0.5
        sq.append((x, y, 0.0, small))
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq[:n]


def _optimize_from(init_squares, n, time_budget_iters=60):
    v = _to_vars(init_squares)
    best = list(init_squares)
    best_score = _score(init_squares) if _feasible(init_squares) else -1e9
    w_overlap = 20.0
    w_wall = 20.0
    bounds = []
    for _ in range(n):
        bounds.append((0.001, 0.999))
        bounds.append((0.001, 0.999))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
    for it in range(time_budget_iters):
        def fun(vv):
            return _pack_objective(vv, n, w_overlap, w_wall)
        try:
            res = minimize(fun, v, method='L-BFGS-B', bounds=bounds,
                           options={'maxiter': 300, 'ftol': 1e-14, 'gtol': 1e-12})
            v = res.x
        except Exception:
            break
        sq = _from_vars(v, n)
        if _feasible(sq):
            sc = _score(sq)
            if sc > best_score + 1e-10:
                best_score = sc
                best = [tuple(map(float, t)) for t in sq]
        else:
            sq2 = _repair(sq)
            if _feasible(sq2):
                sc = _score(sq2)
                if sc > best_score + 1e-10:
                    best_score = sc
                    best = [tuple(map(float, t)) for t in sq2]
        w_overlap *= 1.15
        w_wall *= 1.15
        if it % 10 == 9:
            # if still infeasible, try to shrink
            sq = _from_vars(v, n)
            if not _feasible(sq):
                for i in range(n):
                    x, y, a, s = sq[i]
                    sq[i] = (x, y, a, s * 0.995)
                v = _to_vars(sq)
    return best, best_score


def _try_explicit_constructions(n):
    """Try several known good layouts."""
    candidates = []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side 0.5 in grid
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        s = 1.0 / 3.0
        sq = [(s * 0.5, s * 0.5, 0.0, s), (s * 1.5, s * 0.5, 0.0, s),
              (s * 2.5, s * 0.5, 0.0, s), (s * 0.5, s * 1.5, 0.0, s),
              (s * 0.5, s * 2.5, 0.0, s)]
        return sq
    if n == 6:
        s = 0.5
        return [(s*0.5, s*0.5, 0, s), (s*1.5, s*0.5, 0, s),
                (s*0.5, s*1.5, 0, s), (s*1.5, s*1.5, 0, s),
                (0.25, 0.25, 0, 0.0), (0.75, 0.75, 0, 0.0)]
    return None


def solve(n):
    if n <= 0:
        return []
    n = int(n)
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    explicit = _try_explicit_constructions(n)
    if explicit is not None:
        # still may optimize for better
        pass
    best_sq = None
    best_sc = -1.0

    rng = random.Random(987654321 + n)

    candidates = []
    # structured starts
    for mode in range(4):
        candidates.append(_initial_grid(n, mode))
    candidates.append(_initial_near_opt(n))
    if explicit is not None:
        candidates.append(explicit)
    # scaled grid variants
    base = _initial_grid(n, 0)
    for factor in [1.0, 1.05, 0.98, 1.02, 1.1]:
        candidates.append([(x, y, a, s * factor) for x, y, a, s in base])
    # random
    for _ in range(8):
        candidates.append(_initial_random(n, rng))
    # a few with all rotated 45 deg
    rot = []
    for x, y, a, s in base:
        rot.append((x, y, 0.125, s))
    candidates.append(rot)

    # explicit check for n=2..5
    if explicit is not None:
        candidates.insert(0, explicit)

    # Limit total candidates based on n for time
    max_cands = 14 if n <= 15 else (10 if n <= 30 else (7 if n <= 60 else 5))
    candidates = candidates[:max(1, max_cands)]

    for cs in candidates:
        if _feasible(cs):
            sc = _score(cs)
            if sc > best_sc:
                best_sc = sc
                best_sq = [tuple(map(float, t)) for t in cs]

    # choose best feasible as starting point
    if best_sq is None:
        # fallback: baseline grid
        k = math.isqrt(n)
        side = 1.0 / max(k, 1)
        best_sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        best_sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))
        best_sq = best_sq[:n]
        best_sc = _score(best_sq)

    # local optimization loop around best
    iters = 30 if n <= 20 else (22 if n <= 50 else (16 if n <= 100 else 12))
    try:
        opt_sq, opt_sc = _optimize_from(best_sq, n, time_budget_iters=iters)
        if opt_sc > best_sc:
            best_sq = opt_sq
            best_sc = opt_sc
    except Exception:
        pass

    # try direct coordinate descent on side lengths while keeping feasibility
    # (small random perturbations + repair)
    for trial in range(12):
        pert = []
        for x, y, a, s in best_sq:
            ns = s * (1.0 + rng.uniform(-0.02, 0.04))
            nx = x + rng.uniform(-0.02, 0.02)
            ny = y + rng.uniform(-0.02, 0.02)
            na = a + (rng.uniform(-0.05, 0.05) if rng.random() < 0.2 else 0.0)
            pert.append((min(max(nx, 0.0), 1.0), min(max(ny, 0.0), 1.0), na % 1.0, max(ns, 0.0)))
        if _feasible(pert):
            sc = _score(pert)
            if sc > best_sc:
                best_sq = pert
                best_sc = sc
        else:
            rep = _repair(pert)
            if _feasible(rep):
                sc = _score(rep)
                if sc > best_sc:
                    best_sq = rep
                    best_sc = sc

    # final safety repair
    if not _feasible(best_sq):
        best_sq = _repair(best_sq)
    if not _feasible(best_sq):
        k = math.isqrt(n)
        side = 1.0 / max(k, 1)
        best_sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        best_sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))
        best_sq = best_sq[:n]

    # ensure exactly n
    if len(best_sq) < n:
        best_sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))
    best_sq = best_sq[:n]

    out = []
    for x, y, a, s in best_sq:
        x = min(max(float(x), 0.0), 1.0)
        y = min(max(float(y), 0.0), 1.0)
        a = float(a) % 1.0
        s = min(max(float(s), 0.0), 1.0)
        # final wall clamp
        t = a * 2.0 * math.pi
        c, sn = math.cos(t), math.sin(t)
        h = s * 0.5
        ex = h * (abs(c) + abs(sn))
        ey = h * (abs(sn) + abs(c))
        if ex > 0.5:
            s = 0.0
            h = 0.0
            ex = ey = 0.0
        x = min(max(x, ex), 1.0 - ex) if ex <= 0.5 else 0.5
        y = min(max(y, ey), 1.0 - ey) if ey <= 0.5 else 0.5
        out.append((x, y, a, s))

    # final overlap clamp by shrinking
    for _ in range(10):
        changed = False
        for i in range(n):
            xi, yi, ai, si = out[i]
            if si <= 0:
                continue
            for j in range(n):
                if i == j:
                    continue
                ov = _overlap_amount(out[i], out[j])
                if ov > 1e-9:
                    si = max(0.0, si - ov * 1.001)
                    out[i] = (xi, yi, ai, si)
                    changed = True
                    break
        if not changed:
            break

    return out
