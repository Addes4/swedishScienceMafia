import math
import random
import numpy as np

# ----------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------

def rotated_square_corners(cx, cy, ang, s):
    """Return 4 corners of a square (cx,cy) angle fraction of turn, side s."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * ca - dy * sa
        y = cy + dx * sa + dy * ca
        pts.append((x, y))
    return pts


def point_in_rotated_square(px, py, cx, cy, ang, s):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    dx, dy = px - cx, py - cy
    lx = dx * ca + dy * sa
    ly = -dx * sa + dy * ca
    h = s * 0.5
    return -h < lx < h and -h < ly < h


def squares_intersect(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """True if interiors overlap (any positive area intersection)."""
    if s1 <= 0 or s2 <= 0:
        return False
    # quick bounding circle test
    r1 = s1 * 0.7071067811865476
    r2 = s2 * 0.7071067811865476
    if (cx1 - cx2) ** 2 + (cy1 - cy2) ** 2 >= (r1 + r2) ** 2 - 1e-12:
        return False
    # separating axis theorem on 4 axes (2 per square)
    axes = []
    a1r = a1 * 2.0 * math.pi
    a2r = a2 * 2.0 * math.pi
    for a in (a1r, a2r):
        axes.append((math.cos(a), math.sin(a)))
        axes.append((-math.sin(a), math.cos(a)))
    corners1 = rotated_square_corners(cx1, cy1, a1, s1)
    corners2 = rotated_square_corners(cx2, cy2, a2, s2)
    for ax, ay in axes:
        p1 = [x * ax + y * ay for x, y in corners1]
        p2 = [x * ax + y * ay for x, y in corners2]
        if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
            return False
    return True


def in_unit_square(cx, cy, ang, s, tol=1e-10):
    """Check all corners inside [0,1]^2."""
    for x, y in rotated_square_corners(cx, cy, ang, s):
        if x < -tol or x > 1.0 + tol or y < -tol or y > 1.0 + tol:
            return False
    return True


# ----------------------------------------------------------------------
# evaluation / penalty
# ----------------------------------------------------------------------

def total_side(sqs):
    return sum(max(0.0, s) for (_, _, _, s) in sqs)


def penalty(sqs):
    """Return 0 if feasible, else a positive violation measure."""
    n = len(sqs)
    pen = 0.0
    # boundary
    for cx, cy, ang, s in sqs:
        if s <= 0:
            continue
        for x, y in rotated_square_corners(cx, cy, ang, s):
            if x < 0:
                pen += -x
            if x > 1:
                pen += x - 1
            if y < 0:
                pen += -y
            if y > 1:
                pen += y - 1
    # overlap
    for i in range(n):
        cx1, cy1, a1, s1 = sqs[i]
        if s1 <= 0:
            continue
        for j in range(i + 1, n):
            cx2, cy2, a2, s2 = sqs[j]
            if s2 <= 0:
                continue
            if squares_intersect(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
                # approximate overlap area via small sampling near centroids:
                # cheaper: use bounding-circle distance deficit
                d = math.hypot(cx1 - cx2, cy1 - cy2)
                r1 = s1 * 0.7071067811865476
                r2 = s2 * 0.7071067811865476
                pen += max(0.0, r1 + r2 - d) * 0.5 + 1e-7
    return pen


def objective(sqs, w=50.0):
    return total_side(sqs) - w * penalty(sqs)


# ----------------------------------------------------------------------
# structured packings
# ----------------------------------------------------------------------

def grid_packing(n):
    k = math.isqrt(n)
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n]


def refined_grid(n):
    """Try all (rows, cols) factorisations close to sqrt(n), use leftover for extra strip."""
    best = None
    best_score = -1.0
    for r in range(1, n + 1):
        c = (n + r - 1) // r
        if r * c < n:
            continue
        if r > 20 or c > 20:
            continue
        side = min(1.0 / r, 1.0 / c)
        sq = []
        for i in range(r):
            for j in range(c):
                if len(sq) >= n:
                    break
                sq.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
            if len(sq) >= n:
                break
        if len(sq) < n:
            sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        sq = sq[:n]
        score = total_side(sq)
        if score > best_score:
            best_score = score
            best = sq
    return best


def guillotine_greedy(n):
    """Recursive binary split packing: split largest region, place square in one part."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # choose split: try to make pieces whose best grids are balanced
    best = None
    best_score = -1.0
    k = math.isqrt(n)
    for k1 in range(1, k + 1):
        k2 = n - k1
        if k2 <= 0:
            continue
        # estimate best achievable sum: sqrt(k1) + sqrt(k2)
        est = math.sqrt(k1) + math.sqrt(k2)
        if est > best_score:
            best_score = est
            best = (k1, k2)
    k1, k2 = best

    # split unit square into two rectangles: each holds ~ k1, k2 squares.
    # use proportions proportional to sqrt area requirement ~ proportion of sides
    # choose side split t such that t * (1/t) grids work
    # simple: split vertically with width t = 1/sqrt(k1) guess
    # better: try several splits and pick best by recursive scores
    best_split = None
    best_val = -1.0
    trials = []
    for t in [0.3 * i / 10 + 0.05 for i in range(1, 15)] + [0.5]:
        trials.append(t)
    for t in trials:
        # left rect width t, right width 1-t
        left = pack_rect(t, 1.0, k1)
        right = pack_rect(1.0 - t, 1.0, k2)
        if left is None or right is None:
            continue
        val = sum(s for _, _, _, s in left) + sum(s for _, _, _, s in right)
        if val > best_val:
            best_val = val
            best_split = (t, left, right)
    if best_split is None:
        return grid_packing(n)
    t, left, right = best_split
    offx = t
    out = list(left)
    for cx, cy, a, s in right:
        out.append((cx + offx, cy, a, s))
    return out


def pack_rect(w, h, n):
    """Pack n squares in a w x h rectangle at origin. Return list or None."""
    if n <= 0:
        return []
    if n == 1:
        s = min(w, h)
        return [(w * 0.5, h * 0.5, 0.0, s)]
    # choose near-square grid
    best = None
    best_score = -1.0
    for r in range(1, n + 1):
        c = (n + r - 1) // r
        if r * c < n:
            continue
        if r > 12 or c > 12:
            continue
        sh = h / r
        sw = w / c
        s = min(sh, sw)
        score = s * n
        if score > best_score:
            best_score = score
            best = (r, c, s)
    if best is None:
        return None
    r, c, s = best
    out = []
    for i in range(r):
        for j in range(c):
            if len(out) >= n:
                break
            out.append(((j + 0.5) * (w / c), (i + 0.5) * (h / r), 0.0, s))
        if len(out) >= n:
            break
    while len(out) < n:
        out.append((w * 0.5, h * 0.5, 0.0, 0.0))
    return out


# ----------------------------------------------------------------------
# local search
# ----------------------------------------------------------------------

def local_search(sqs, n, steps=3000, seed=0):
    rng = random.Random(seed)
    cur = [list(s) for s in sqs]
    cur_obj = objective(cur)
    best = [list(s) for s in cur]
    best_obj = cur_obj

    for step in range(steps):
        i = rng.randrange(n)
        sq = cur[i][:]
        if rng.random() < 0.35:
            # move
            sq[0] += rng.gauss(0, 0.03)
            sq[1] += rng.gauss(0, 0.03)
        elif rng.random() < 0.7:
            # resize (many tiny squares might grow)
            sq[3] = max(0.0, sq[3] + rng.gauss(0, 0.02))
        else:
            # rotate
            sq[2] = (sq[2] + rng.gauss(0, 0.05)) % 1.0
        # clip centre
        sq[0] = min(1.0, max(0.0, sq[0]))
        sq[1] = min(1.0, max(0.0, sq[1]))
        # clamp side so centre + rotated half stays inside approximately
        h = sq[3] * 0.7071067811865476
        cx = sq[0]
        cy = sq[1]
        max_allowed = min(cx, 1 - cx, cy, 1 - cy) / 0.7071067811865476
        if sq[3] > max_allowed:
            sq[3] = max(0.0, max_allowed)

        old = cur[i]
        cur[i] = sq
        new_obj = objective(cur)
        delta = new_obj - cur_obj
        if delta >= 0 or rng.random() < math.exp(delta * 10.0 / max(0.01, 1.0 + step * 0.001)):
            cur_obj = new_obj
        else:
            cur[i] = old
        if cur_obj > best_obj:
            best_obj = cur_obj
            best = [list(s) for s in cur]
    return [tuple(s) for s in best]


# ----------------------------------------------------------------------
# main
# ----------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # candidate: refined grid
    g = refined_grid(n)
    # candidate: guillotine
    try:
        h = guillotine_greedy(n)
    except Exception:
        h = None
    # candidate: simple grid
    base = grid_packing(n)

    candidates = [g, base]
    if h is not None:
        candidates.append(h)

    # pick candidate with highest total side after light local search for small n
    if n <= 30:
        best_sq = None
        best_val = -1.0
        for cand in candidates:
            if cand is None:
                continue
            refined = local_search(cand, n, steps=2000 if n <= 12 else 1200, seed=n)
            val = total_side(refined) - 100.0 * penalty(refined)
            if val > best_val:
                best_val = val
                best_sq = refined
        if best_sq is None:
            best_sq = g
    else:
        # just choose best structured candidate, then short local search on smallest squares
        best_sq = max([c for c in candidates if c is not None], key=lambda s: total_side(s))
        if n <= 60:
            best_sq = local_search(best_sq, n, steps=800, seed=n)

    # final cleanup: ensure no overlap/boundary violation by zeroing offending squares
    out = [list(s) for s in best_sq]
    # boundary fix: move inside
    for i, (cx, cy, ang, s) in enumerate(out):
        if s <= 0:
            out[i] = [0.5, 0.5, 0.0, 0.0]
            continue
        # move centre to feasible if not
        ok = True
        for x, y in rotated_square_corners(cx, cy, ang, s):
            if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                ok = False
                break
        if not ok:
            cx = min(max(0.5, cx), 0.5)
            cy = min(max(0.5, cy), 0.5)
            out[i] = [cx, cy, ang, s]
    # iterative overlap removal: shrink smaller of overlapping pair
    for _ in range(200):
        changed = False
        for i in range(n):
            if out[i][3] <= 0:
                continue
            for j in range(i + 1, n):
                if out[j][3] <= 0:
                    continue
                if squares_intersect(out[i][0], out[i][1], out[i][2], out[i][3],
                                     out[j][0], out[j][1], out[j][2], out[j][3]):
                    # shrink smaller one drastically
                    if out[i][3] <= out[j][3]:
                        out[i][3] *= 0.7
                    else:
                        out[j][3] *= 0.7
                    changed = True
        if not changed:
            break
    # final boundary clamp
    for i in range(n):
        s = out[i][3]
        if s <= 0:
            out[i] = [0.5, 0.5, 0.0, 0.0]
            continue
        cx, cy, ang = out[i][0], out[i][1], out[i][2]
        # shrink to guarantee inside
        h = s * 0.7071067811865476
        margin = min(cx, 1 - cx, cy, 1 - cy)
        if margin < h:
            s = margin / 0.7071067811865476
        out[i][3] = max(0.0, min(1.0, s))
        out[i][0] = min(1.0, max(0.0, out[i][0]))
        out[i][1] = min(1.0, max(0.0, out[i][1]))
        out[i][2] = out[i][2] % 1.0

    return [tuple(s) for s in out]
