import math
import random
import time

# EVOLVE-BLOCK-START

def _overlap_area(s1, s2):
    """Return True if two squares' interiors overlap."""
    x1, y1, a1, s1v = s1
    x2, y2, a2, s2v = s2
    if s1v <= 0.0 or s2v <= 0.0:
        return False
    # quick axis-aligned bound check using rotated bounding boxes
    def bbox(x, y, a, s):
        c = abs(math.cos(2 * math.pi * a))
        si = abs(math.sin(2 * math.pi * a))
        r = 0.5 * s * (c + si)
        return x - r, y - r, x + r, y + r
    b1 = bbox(x1, y1, a1, s1v)
    b2 = bbox(x2, y2, a2, s2v)
    if b1[2] <= b2[0] or b2[2] <= b1[0] or b1[3] <= b2[1] or b2[3] <= b1[1]:
        return False
    # Separating axis theorem for two convex polygons (squares)
    def corners(x, y, a, s):
        h = 0.5 * s
        ang = 2 * math.pi * a
        ca, sa = math.cos(ang), math.sin(ang)
        pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
        return [(x + px * ca - py * sa, y + px * sa + py * ca) for px, py in pts]
    p1 = corners(x1, y1, a1, s1v)
    p2 = corners(x2, y2, a2, s2v)
    # test normals of both squares (4 axes)
    for poly in (p1, p2):
        for i in range(4):
            ax, ay = poly[i]
            bx, by = poly[(i + 1) % 4]
            nx, ny = -(by - ay), (bx - ax)
            len2 = nx * nx + ny * ny
            if len2 == 0:
                continue
            min1 = min(p[0] * nx + p[1] * ny for p in p1)
            max1 = max(p[0] * nx + p[1] * ny for p in p1)
            min2 = min(p[0] * nx + p[1] * ny for p in p2)
            max2 = max(p[0] * nx + p[1] * ny for p in p2)
            if max1 <= min2 or max2 <= min1:
                return False
    return True

def _inside(x, y, a, s):
    if s <= 0:
        return True
    ang = 2 * math.pi * a
    ca, sa = math.cos(ang), math.sin(ang)
    h = 0.5 * s
    for px, py in ((-h, -h), (h, -h), (h, h), (-h, h)):
        X = x + px * ca - py * sa
        Y = y + px * sa + py * ca
        if X < -1e-12 or X > 1 + 1e-12 or Y < -1e-12 or Y > 1 + 1e-12:
            return False
    return True

def _feasible(squares):
    n = len(squares)
    for i in range(n):
        if not _inside(*squares[i]):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if squares[i][3] > 0 and squares[j][3] > 0:
                if _overlap_area(squares[i], squares[j]):
                    return False
    return True

def _score(squares):
    return sum(s[3] for s in squares)

def _initial_grid(n):
    """Row-based packing: choose rows, each row has a number of equal squares."""
    best = None
    best_score = -1.0
    # Try number of rows r and cols c with r*c >= n, place grid, extra as zero
    for r in range(1, n + 1):
        c = (n + r - 1) // r
        # cell size limited by both dimensions
        s = min(1.0 / r, 1.0 / c)
        total = n * s
        # rows of size s, last row may have fewer
        if total > best_score:
            cnt = 0
            sq = []
            for i in range(r):
                for j in range(c):
                    if cnt < n:
                        cx = (j + 0.5) * s
                        cy = (i + 0.5) * s
                        sq.append((cx, cy, 0.0, s))
                        cnt += 1
            while len(sq) < n:
                sq.append((0.5, 0.5, 0.0, 0.0))
            best_score = total
            best = sq
    return best

def _refine(squares, budget):
    """Local optimization: perturb one square at a time, accept improvements."""
    n = len(squares)
    cur = list(squares)
    cur_score = _score(cur)
    best = list(cur)
    best_score = cur_score
    t0 = time.time()
    # Determine active squares (nonzero size)
    # Try to grow each square and shift.
    step = 0.02
    while time.time() - t0 < budget * 0.95:
        improved = False
        for _ in range(max(1, n)):
            i = random.randrange(n)
            if cur[i][3] <= 0 and random.random() < 0.3:
                # try to give size to zero square
                pass
            old = cur[i]
            # candidate moves: change size, or shift
            kind = random.random()
            if kind < 0.5:
                # change size
                d = random.uniform(-1, 1) * step
                newsize = old[3] + d
                if newsize < 0:
                    newsize = 0.0
                cand = (old[0], old[1], old[2], newsize)
            elif kind < 0.8:
                # shift
                d = random.uniform(-1, 1) * step
                ang = random.random() * 2 * math.pi
                cand = (min(1, max(0, old[0] + d * math.cos(ang))),
                        min(1, max(0, old[1] + d * math.sin(ang))),
                        old[2], old[3])
            else:
                # rotate
                cand = (old[0], old[1], old[2] + random.uniform(-0.1, 0.1), old[3])
            cur[i] = cand
            if _inside(*cand):
                # check overlaps involving i
                ok = True
                for j in range(n):
                    if j != i and cur[j][3] > 0 and cand[3] > 0:
                        if _overlap_area(cand, cur[j]):
                            ok = False
                            break
                if ok:
                    new_score = cur_score - old[3] + cand[3]
                    if new_score >= cur_score - 1e-12:
                        cur_score = new_score
                        improved = True
                        if cur_score > best_score:
                            best_score = cur_score
                            best = list(cur)
                        continue
            cur[i] = old
        if not improved:
            step *= 0.97
            if step < 1e-5:
                break
    return best

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # Build initial packed square
    cur = _initial_grid(n)
    # Try to improve: for perfect squares, grid is optimal already
    k = math.isqrt(n)
    if n == k * k:
        return cur
    # Optimization budget
    budget = 8.0
    # Also try to make a tighter packing by allowing varied sizes
    best = _refine(cur, budget)
    return best

# EVOLVE-BLOCK-END
