import math
import random
from typing import List, Tuple

import numpy as np
from scipy.optimize import minimize


# ---------------------------------------------------------------------------
# geometry utilities
# ---------------------------------------------------------------------------

def _corners(cx: float, cy: float, ang: float, s: float) -> np.ndarray:
    """Return the 4 corners of a square as a (4,2) array.
    angle is a fraction of a full turn.
    """
    t = 2.0 * math.pi * ang
    c, sn = math.cos(t), math.sin(t)
    h = 0.5 * s
    # local corners (x,y) in [-h,h]^2
    local = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    rot = np.array([[c, -sn], [sn, c]], dtype=float)
    return local @ rot.T + np.array([cx, cy])


def _poly_overlap_area(p1: np.ndarray, p2: np.ndarray) -> float:
    """Return the area of overlap of two convex quadrilaterals using
    the Sutherland-Hodgman clipping algorithm.
    """
    out = p1
    # clip p1 by each edge of p2
    for i in range(4):
        a = p2[i]
        b = p2[(i + 1) % 4]
        # inside test: cross(b-a, p-a) >= 0 for CCW polygons
        edge = b - a
        inside_mask = (out[:,0] - a[0]) * edge[1] - (out[:,1] - a[1]) * edge[0] >= -1e-14
        if inside_mask.all():
            continue
        if not inside_mask.any():
            return 0.0
        new_pts = []
        m = len(out)
        for j in range(m):
            cur = out[j]
            nxt = out[(j + 1) % m]
            cur_in = inside_mask[j]
            nxt_in = inside_mask[(j + 1) % m]
            if cur_in:
                new_pts.append(cur)
            if cur_in != nxt_in:
                # intersection of segment cur->nxt with line a->b
                d = nxt - cur
                denom = d[0] * edge[1] - d[1] * edge[0]
                if abs(denom) < 1e-18:
                    continue
                t_param = ((a[0] - cur[0]) * edge[1] - (a[1] - cur[1]) * edge[0]) / denom
                new_pts.append(cur + t_param * d)
        if not new_pts:
            return 0.0
        out = np.array(new_pts, dtype=float)
    # area of resulting polygon via shoelace
    if len(out) < 3:
        return 0.0
    x = out[:,0]
    y = out[:,1]
    return 0.5 * abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))


def _inside_unit(poly: np.ndarray, tol: float = 0.0) -> float:
    """Return how far the polygon sticks outside [0,1]^2 (max violation)."""
    v = 0.0
    v = max(v, -poly[:,0].min() - tol)
    v = max(v, poly[:,0].max() - 1.0 - tol)
    v = max(v, -poly[:,1].min() - tol)
    v = max(v, poly[:,1].max() - 1.0 - tol)
    return v


# ---------------------------------------------------------------------------
# objective for the optimizer
# ---------------------------------------------------------------------------

def _build_params(squares):
    """Flatten list of squares into parameter vector [cx,cy,ang,s] * n."""
    p = []
    for cx, cy, a, s in squares:
        p.extend([cx, cy, a, s])
    return np.array(p, dtype=float)


def _params_to_squares(p):
    n = len(p) // 4
    out = []
    for i in range(n):
        out.append((p[4*i], p[4*i+1], p[4*i+2], max(0.0, p[4*i+3])))
    return out


def _penalty(p, n_required, weight_outside=1000.0, weight_overlap=1000.0):
    """Return (objective_to_minimise, sum_of_sides, violations)."""
    sq = _params_to_squares(p)
    total_side = sum(s for _, _, _, s in sq)

    # inside violations
    v_out = 0.0
    polys = []
    for cx, cy, a, s in sq:
        poly = _corners(cx, cy, a, s)
        polys.append(poly)
        v_out += _inside_unit(poly)
        # also penalise if centre is far outside (safety)
        v_out += max(0.0, abs(cx - 0.5) - 0.5)
        v_out += max(0.0, abs(cy - 0.5) - 0.5)

    # overlap violations (approximate via pairwise polygon clipping)
    v_ov = 0.0
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            # quick bounding-box reject
            pi, pj = polys[i], polys[j]
            if (pi[:,0].max() <= pj[:,0].min() + 1e-12 or
                pj[:,0].max() <= pi[:,0].min() + 1e-12 or
                pi[:,1].max() <= pj[:,1].min() + 1e-12 or
                pj[:,1].max() <= pi[:,1].min() + 1e-12):
                continue
            a_ov = _poly_overlap_area(pi, pj)
            if a_ov > 1e-12:
                v_ov += a_ov

    # objective: minimise negative sum + penalties
    obj = -total_side + weight_outside * v_out + weight_overlap * v_ov
    return obj, total_side, v_out + v_ov


# ---------------------------------------------------------------------------
# candidate constructions
# ---------------------------------------------------------------------------

def _grid_layout(n: int):
    """Best of several simple grid-like layouts."""
    best = None
    best_val = -1.0
    for k in range(1, min(n, 20) + 1):
        # k x k grid, then leftover in a row or column
        base = k * k
        if base > n:
            continue
        size = 1.0 / k
        if base == n:
            sq = [((i + 0.5) * size, (j + 0.5) * size, 0.0, size)
                  for i in range(k) for j in range(k)]
            val = n * size
            if val > best_val:
                best_val = val
                best = sq
        else:
            # try adding a row of (k) squares at top or right, scaled down
            # put leftover m in a strip on top with height h, squares of side h
            m = n - base
            # strip on top: k+? Actually we can place squares in the strip of height h
            # width 1, can fit floor(1/h) squares of side h. We need m.
            # Solve: h * floor(1/h) >= m, minimise loss.
            # Try h = 1/(k+1), 1/(k+2), ... and also h = m/(? )
            for h_den in range(k + 1, k + 5 * k + 10):
                h = 1.0 / h_den
                cols = int(1.0 / h + 1e-12)
                if cols >= m:
                    # remaining k*k squares scaled to fit in [0,1-h]^2
                    size2 = min((1.0 - h) / k, 1.0 / k)  # keep within
                    # centre grid in remaining area
                    sq = []
                    # existing kxk squares shrunk a bit to fit below strip
                    for i in range(k):
                        for j in range(k):
                            cx = (1.0 - size2) * 0.5 + i * size2 if k > 1 else 0.5
                            cy = (1.0 - h - size2) * 0.5 + j * size2 if k > 1 else (1.0 - h) * 0.5
                            sq.append((cx, cy, 0.0, size2))
                    # strip squares
                    for idx in range(m):
                        cx = (idx + 0.5) * h
                        cy = 1.0 - h * 0.5
                        sq.append((cx, cy, 0.0, h))
                    val = k * k * size2 + m * h
                    if val > best_val:
                        best_val = val
                        best = sq
                    break
    if best is None:
        # fallback: all zero
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    return best, best_val


def _single_row(n: int):
    """n squares in a single row, side 1/n each (cannot do better)."""
    s = 1.0 / n
    return [((i + 0.5) * s, 0.5, 0.0, s) for i in range(n)], 1.0


def _diamond_pack(n: int):
    """Place n identical rotated squares (45 deg) in a grid pattern."""
    # Rotated squares create diamond tiling; try a few simple arrangements.
    best = None
    best_val = -1.0
    for k in range(1, min(n, 20) + 1):
        if k * k > n:
            continue
        m = n - k * k
        # try full grid of diamonds plus leftover
        # diamond side s, bounding box s*sqrt(2). In unit square can fit k per row if k*s*sqrt2<=1
        s = 1.0 / (k * math.sqrt(2))
        sq = []
        for i in range(k):
            for j in range(k):
                cx = (i + 0.5) / k
                cy = (j + 0.5) / k
                sq.append((cx, cy, 0.125, s))  # 45 deg
        # leftover as small squares in gaps? just zero-size
        sq += [(0.5, 0.5, 0.0, 0.0)] * m
        val = k * k * s
        if val > best_val:
            best_val = val
            best = sq
    return best, best_val


# ---------------------------------------------------------------------------
# local refinement
# ---------------------------------------------------------------------------

def _refine(init_sq, n, time_budget_steps=60):
    """Run a few rounds of scipy minimize on the parameters."""
    p0 = _build_params(init_sq)
    # ensure p0 length is 4*n
    if len(p0) < 4 * n:
        p0 = np.concatenate([p0, np.zeros(4 * n - len(p0))])
    p0 = p0[:4 * n]

    def obj_fn(p):
        o, _, _ = _penalty(p, n)
        return o

    # bounds: cx,cy in [0,1], angle in [0,0.5), side in [0,1]
    bounds = []
    for _ in range(n):
        bounds.extend([(-0.1, 1.1), (-0.1, 1.1), (-0.5, 1.0), (0.0, 1.0)])

    result = minimize(obj_fn, p0, method='L-BFGS-B', bounds=bounds,
                      options={'maxiter': 200, 'ftol': 1e-12, 'gtol': 1e-12})
    p = result.x
    # repair: ensure centres inside, sides non-negative
    sq = _params_to_squares(p)
    # clamp centres to [0,1]
    sq = [(min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), a % 1.0, max(0.0, s))
          for cx, cy, a, s in sq]
    return sq


def _project_valid(sq, n):
    """Make squares valid: clamp inside, remove overlaps by shrinking."""
    # clamp centres and sides
    out = []
    for cx, cy, a, s in sq:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        s = max(0.0, s)
        out.append([cx, cy, a, s])
    # iteratively reduce side of overlapping squares
    for _ in range(50):
        changed = False
        polys = [_corners(cx, cy, a, s) for cx, cy, a, s in out]
        for i in range(n):
            if out[i][3] <= 1e-14:
                continue
            vi = _inside_unit(polys[i])
            if vi > 1e-12:
                # shrink to fit
                out[i][3] = max(0.0, out[i][3] - vi * 2.0)
                changed = True
                polys[i] = _corners(*out[i])
                continue
            for j in range(i + 1, n):
                if out[j][3] <= 1e-14:
                    continue
                a_ov = _poly_overlap_area(polys[i], polys[j])
                if a_ov > 1e-12:
                    # shrink both proportionally
                    scale = 1.0 - min(0.5, a_ov * 4.0)
                    out[i][3] *= scale
                    out[j][3] *= scale
                    polys[i] = _corners(*out[i])
                    polys[j] = _corners(*out[j])
                    changed = True
        if not changed:
            break
    # final strict clamp
    for i in range(n):
        out[i][3] = max(0.0, out[i][3])
        out[i][0] = min(max(out[i][0], 0.0), 1.0)
        out[i][1] = min(max(out[i][1], 0.0), 1.0)
    return [tuple(x) for x in out]


# ---------------------------------------------------------------------------
# main solver
# ---------------------------------------------------------------------------

def solve(n: int) -> List[Tuple[float, float, float, float]]:
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides.
    """
    if n <= 0:
        return []

    # For very small n, use exact-ish/best-effort constructions.
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two halves
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three squares: two in top row, one in bottom?
        # Actually 3 equal squares side 0.5 fit: two on bottom, one on top centred.
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s), (0.5, 0.75, 0.0, s)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # Collect candidate initial layouts.
    candidates = []

    # 1) grid-based
    sq, val = _grid_layout(n)
    candidates.append((sq, val))

    # 2) single row (good for small n)
    sq, val = _single_row(n)
    candidates.append((sq, val))

    # 3) diamond pack
    sq, val = _diamond_pack(n)
    candidates.append((sq, val))

    # 4) k x k grid with leftover as a column/row of smaller squares
    k = math.isqrt(n)
    if k * k < n:
        m = n - k * k
        # try k+1 columns in a row? Or k+1 by k grid (last row partial)
        # Use k+1 squares across
        cols = k + 1
        rows = (n + cols - 1) // cols
        sx = 1.0 / cols
        sy = 1.0 / rows
        sq = []
        idx = 0
        for r in range(rows):
            for c in range(cols):
                if idx >= n:
                    break
                sq.append(((c + 0.5) * sx, 1.0 - (r + 0.5) * sy, 0.0, min(sx, sy)))
                idx += 1
        val = sum(s for *_, s in sq)
        candidates.append((sq, val))

    # Pick best candidate.
    best_sq = None
    best_val = -1.0
    for sq, val in candidates:
        if len(sq) < n:
            sq = sq + [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        sq = sq[:n]
        if val > best_val:
            best_val = val
            best_sq = sq

    # Refine.
    try:
        refined = _refine(best_sq, n)
        refined = _project_valid(refined, n)
        # only accept if better or equal
        val_r = sum(s for *_, s in refined)
        val_b = sum(s for *_, s in best_sq)
        # compute violation of refined
        viol = 0.0
        polys = [_corners(cx, cy, a, s) for cx, cy, a, s in refined]
        for i in range(n):
            viol += _inside_unit(polys[i])
            for j in range(i + 1, n):
                viol += _poly_overlap_area(polys[i], polys[j])
        if viol < 1e-6 and val_r >= val_b - 1e-9:
            best_sq = refined
    except Exception:
        pass

    # Final safety projection.
    best_sq = _project_valid(best_sq, n)

    # Ensure exactly n entries.
    best_sq = best_sq[:n]
    while len(best_sq) < n:
        best_sq.append((0.5, 0.5, 0.0, 0.0))

    # Clamp all values to [0,1].
    final = []
    for cx, cy, a, s in best_sq:
        final.append((min(max(float(cx), 0.0), 1.0),
                      min(max(float(cy), 0.0), 1.0),
                      float(a) % 1.0,
                      min(max(float(s), 0.0), 1.0)))
    return final
