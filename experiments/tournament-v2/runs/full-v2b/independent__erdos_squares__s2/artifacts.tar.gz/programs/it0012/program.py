import math
import numpy as np
from scipy.optimize import minimize

def solve(n):
    if n == 0:
        return []
    # Initial guess: grid plus small squares
    k = math.isqrt(n)
    side = 1.0 / k if k > 0 else 0.0
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) < n:
                squares.append([ (i + 0.5) * side, (j + 0.5) * side, 0.0, side ])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    squares = squares[:n]
    # Convert to 1D array for optimisation
    x0 = np.array(squares).flatten()
    # Bounds: centres and angle in [0,1], side in [0,1]
    bounds = []
    for i in range(n):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])
    # Objective: minimise negative sum of sides + penalty
    def obj(x):
        squares = x.reshape(-1, 4)
        sides = squares[:, 3]
        total_side = np.sum(sides)
        penalty = 0.0
        # Boundary penalty
        for cx, cy, angle, s in squares:
            if s == 0:
                continue
            theta = angle * 2 * math.pi
            cos_t = math.cos(theta)
            sin_t = math.sin(theta)
            # Half diagonal length
            h = s / 2.0
            # Corners relative to center
            corners = [
                (h, h),
                (h, -h),
                (-h, -h),
                (-h, h)
            ]
            for dx, dy in corners:
                x = cx + dx * cos_t - dy * sin_t
                y = cy + dx * sin_t + dy * cos_t
                if x < 0:
                    penalty += 1000 * (-x)**2
                elif x > 1:
                    penalty += 1000 * (x - 1)**2
                if y < 0:
                    penalty += 1000 * (-y)**2
                elif y > 1:
                    penalty += 1000 * (y - 1)**2
        # Overlap penalty (only for non-zero squares)
        for i in range(n):
            for j in range(i + 1, n):
                s1 = squares[i, 3]
                s2 = squares[j, 3]
                if s1 == 0 or s2 == 0:
                    continue
                # Simple overlap approximation using bounding circles
                r1 = s1 * 0.7071
                r2 = s2 * 0.7071
                dist = math.hypot(squares[i, 0] - squares[j, 0], squares[i, 1] - squares[j, 1])
                if dist < r1 + r2:
                    penalty += 500 * (r1 + r2 - dist)**2
        return -total_side + penalty

    # Optimise
    res = minimize(obj, x0, method='L-BFGS-B', bounds=bounds, options={'maxiter': 100, 'ftol': 1e-8})
    x_opt = res.x
    squares_opt = x_opt.reshape(-1, 4)
    # Project to feasible (ensure boundaries)
    for i in range(n):
        cx, cy, angle, s = squares_opt[i]
        # Clamp angle
        angle = angle % 1.0
        # Adjust side if needed? Leave as is, but clamp centre
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        # Ensure square fits (simple scaling)
        if s > 0:
            theta = angle * 2 * math.pi
            cos_t = math.cos(theta)
            sin_t = math.sin(theta)
            h = s / 2.0
            corners = [(h, h), (h, -h), (-h, -h), (-h, h)]
            min_x = min(cx + dx * cos_t - dy * sin_t for dx, dy in corners)
            max_x = max(cx + dx * cos_t - dy * sin_t for dx, dy in corners)
            min_y = min(cy + dx * sin_t + dy * cos_t for dx, dy in corners)
            max_y = max(cy + dx * sin_t + dy * cos_t for dx, dy in corners)
            # If outside, shift and scale
            if min_x < 0 or max_x > 1 or min_y < 0 or max_y > 1:
                # Scale down to fit
                w = max_x - min_x
                h_box = max_y - min_y
                scale = min(1.0 / w, 1.0 / h_box, 1.0)
                s *= scale
                h = s / 2.0
                # Recompute corners
                corners = [(h, h), (h, -h), (-h, -h), (-h, h)]
                min_x = min(cx + dx * cos_t - dy * sin_t for dx, dy in corners)
                max_x = max(cx + dx * cos_t - dy * sin_t for dx, dy in corners)
                min_y = min(cy + dx * sin_t - dy * cos_t for dx, dy in corners)
                max_y = max(cy + dx * sin_t - dy * cos_t for dx, dy in corners)
                # Shift centre
                if min_x < 0:
                    cx -= min_x
                if max_x > 1:
                    cx -= (max_x - 1)
                if min_y < 0:
                    cy -= min_y
                if max_y > 1:
                    cy -= (max_y - 1)
                cx = min(max(cx, 0.0), 1.0)
                cy = min(max(cy, 0.0), 1.0)
        squares_opt[i] = [cx, cy, angle, s]
    # Return as tuples
    return [tuple(row) for row in squares_opt]
