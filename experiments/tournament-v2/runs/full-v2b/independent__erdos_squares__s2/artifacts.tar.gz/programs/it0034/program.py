import math
import random
import numpy as np

# We represent each square as (cx, cy, angle, side, vx, vy, omega, dside)
# and do a penalty-based relaxation. To make it fast and robust, we use
# an event-driven overlap resolution: iteratively push apart overlapping
# squares and clamp to the unit box, while occasionally resizing.

def _corners(cx, cy, ang, s):
    """Return the 4 corners of a square."""
    c = math.cos(2 * math.pi * ang)
    sn = math.sin(2 * math.pi * ang)
    h = s * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        rx = c * x - sn * y + cx
        ry = sn * x + c * y + cy
        out.append((rx, ry))
    return out


def _overlap_area(c1, c2):
    """Approximate overlap area between two convex polygons using SAT + clipping.
    Returns a positive number if they overlap, else 0."""
    # Use Separating Axis Theorem to get penetration depth; approximate area
    # as product of min penetrations on two axes.
    axes = []
    for poly in (c1, c2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            length = math.hypot(ex, ey)
            if length < 1e-15:
                continue
            axes.append((-ey / length, ex / length))
    min_pen = 1e18
    for ax, ay in axes:
        p1 = [x * ax + y * ay for x, y in c1]
        p2 = [x * ax + y * ay for x, y in c2]
        if max(p1) < min(p2) or max(p2) < min(p1):
            return 0.0
        pen = min(max(p1), max(p2)) - max(min(p1), min(p2))
        if pen < min_pen:
            min_pen = pen
    return min_pen * min_pen if min_pen < 1e18 else 0.0


def _inside_box(corners, eps=1e-12):
    """Return overlap-outside penalty."""
    pen = 0.0
    for x, y in corners:
        if x < -eps:
            pen += -x
        if x > 1 + eps:
            pen += x - 1
        if y < -eps:
            pen += -y
        if y > 1 + eps:
            pen += y - 1
    return pen


def _penetration_vector(c1, c2):
    """Return (dx, dy, depth) minimum translation vector for c2 out of c1.
    Uses SAT."""
    axes = []
    for poly in (c1, c2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            length = math.hypot(ex, ey)
            if length < 1e-15:
                continue
            axes.append((-ey / length, ex / length))
    min_pen = 1e18
    best_axis = None
    best_sign = 1
    for ax, ay in axes:
        p1 = [x * ax + y * ay for x, y in c1]
        p2 = [x * ax + y * ay for x, y in c2]
        if max(p1) < min(p2) or max(p2) < min(p1):
            return (0.0, 0.0, 0.0)
        pen = min(max(p1), max(p2)) - max(min(p1), min(p2))
        if pen < min_pen:
            min_pen = pen
            best_axis = (ax, ay)
            # sign: push c2 along +axis if its center projection is greater
            c1c = sum(x * ax + y * ay for x, y in c1) / len(c1)
            c2c = sum(x * ax + y * ay for x, y in c2) / len(c2)
            best_sign = 1 if c2c >= c1c else -1
    if best_axis is None:
        return (0.0, 0.0, 0.0)
    return (best_axis[0] * best_sign, best_axis[1] * best_sign, min_pen)


def _resolve_overlaps(squares, iters=200, allow_rotation=True):
    """squares: list of [cx, cy, ang, s]. Mutates in place to reduce overlaps."""
    n = len(squares)
    if n <= 1:
        return
    # precompute for speed
    for it in range(iters):
        # find worst overlaps
        max_ov = 0.0
        worst = []
        for i in range(n):
            if squares[i][3] < 1e-12:
                continue
            ci = _corners(*squares[i])
            for j in range(i + 1, n):
                if squares[j][3] < 1e-12:
                    continue
                # quick center distance check
                dx = squares[i][0] - squares[j][0]
                dy = squares[i][1] - squares[j][1]
                maxr = (squares[i][3] + squares[j][3]) * 0.75
                if dx * dx + dy * dy > maxr * maxr * 4:
                    continue
                cj = _corners(*squares[j])
                mv = _penetration_vector(ci, cj)
                depth = mv[2]
                if depth > 1e-10:
                    worst.append((depth, i, j, mv))
                    if depth > max_ov:
                        max_ov = depth
        if max_ov < 1e-8:
            break
        # resolve a batch of overlaps
        worst.sort(reverse=True)
        done = set()
        strength = 0.9
        for depth, i, j, mv in worst[:max(1, n)]:
            if (i, j) in done:
                continue
            done.add((i, j))
            # move both apart by half depth along mv (c2 out of c1 -> push j +, i -)
            dx, dy = mv[0], mv[1]
            push = depth * 0.5 * strength + 0.01
            si = squares[i][3]
            sj = squares[j][3]
            wi = 1.0 / (si + 1e-9)
            wj = 1.0 / (sj + 1e-9)
            tot = wi + wj
            # i moves -mv * (wi/tot), j moves +mv * (wj/tot)
            squares[i][0] -= dx * push * (wi / tot)
            squares[i][1] -= dy * push * (wi / tot)
            squares[j][0] += dx * push * (wj / tot)
            squares[j][1] += dy * push * (wj / tot)
            # random small rotation jitter
            if allow_rotation and random.random() < 0.3:
                squares[i][2] += random.uniform(-0.02, 0.02)
                squares[j][2] += random.uniform(-0.02, 0.02)
        # clamp inside box
        for k in range(n):
            if squares[k][3] < 1e-12:
                continue
            c = _corners(*squares[k])
            minx = min(p[0] for p in c)
            maxx = max(p[0] for p in c)
            miny = min(p[1] for p in c)
            maxy = max(p[1] for p in c)
            # move to fit
            if minx < 0:
                squares[k][0] += -minx
            if maxx > 1:
                squares[k][0] -= (maxx - 1)
            if miny < 0:
                squares[k][1] += -miny
            if maxy > 1:
                squares[k][1] -= (maxy - 1)


def _score(squares):
    """Total side length, but heavily penalize overlaps/outside."""
    n = len(squares)
    total = sum(s[3] for s in squares)
    pen = 0.0
    # outside penalty
    for s in squares:
        if s[3] < 1e-12:
            continue
        c = _corners(*s)
        pen += _inside_box(c)
    # overlap penalty
    for i in range(n):
        if squares[i][3] < 1e-12:
            continue
        ci = _corners(*squares[i])
        for j in range(i + 1, n):
            if squares[j][3] < 1e-12:
                continue
            dx = squares[i][0] - squares[j][0]
            dy = squares[i][1] - squares[j][1]
            maxr = (squares[i][3] + squares[j][3]) * 0.75
            if dx * dx + dy * dy > maxr * maxr * 4:
                continue
            cj = _corners(*squares[j])
            ov = _overlap_area(ci, cj)
            pen += ov * 10.0
    return total - pen * 100.0


def _initial_grid(n):
    """Generate n squares with a grid-ish layout, axis-aligned."""
    # find good k x m layout
    best = None
    for k in range(1, n + 1):
        m = (n + k - 1) // k
        # square side fitting k x m
        sw = 1.0 / k
        sh = 1.0 / m
        s = min(sw, sh)
        total = s * min(k * m, n)
        if best is None or total > best[0]:
            best = (total, k, m, s)
    _, k, m, s = best
    squares = []
    idx = 0
    for i in range(k):
        for j in range(m):
            if idx >= n:
                break
            cx = (i + 0.5) * s
            cy = (j + 0.5) * s
            squares.append([cx, cy, 0.0, s, 0.0, 0.0, 0.0, 0.0])
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
    return squares


def _try_growth(squares, rounds=50):
    """Try to grow each square if possible without causing overlap."""
    n = len(squares)
    order = list(range(n))
    for r in range(rounds):
        random.shuffle(order)
        improved = False
        for i in order:
            old_s = squares[i][3]
            # try growing
            for factor in [1.05, 1.02, 1.01, 1.005]:
                ns = old_s * factor
                if ns > 1.0:
                    continue
                # tentatively set size
                squares[i][3] = ns
                # check overlaps
                ci = _corners(*squares[i])
                ok = _inside_box(ci) < 1e-9
                if ok:
                    for j in range(n):
                        if j == i or squares[j][3] < 1e-12:
                            continue
                        cj = _corners(*squares[j])
                        if _overlap_area(ci, cj) > 1e-9:
                            ok = False
                            break
                if ok:
                    improved = True
                    break
                else:
                    squares[i][3] = old_s
        if not improved:
            break
    return squares


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345 + n)

    best_squares = None
    best_score = -1e18

    # multiple restarts
    for restart in range(8):
        squares = _initial_grid(n)
        # randomize slightly
        for s in squares:
            s[0] += random.uniform(-0.01, 0.01)
            s[1] += random.uniform(-0.01, 0.01)
            s[2] += random.uniform(-0.05, 0.05)
            s[0] = max(0.0, min(1.0, s[0]))
            s[1] = max(0.0, min(1.0, s[1]))

        for stage in range(6):
            _resolve_overlaps(squares, iters=100, allow_rotation=True)
            _try_growth(squares, rounds=30)
            _resolve_overlaps(squares, iters=80, allow_rotation=True)

        # final cleanup: shrink overlapping squares slightly
        for _ in range(30):
            changed = False
            for i in range(n):
                if squares[i][3] < 1e-12:
                    continue
                ci = _corners(*squares[i])
                for j in range(i + 1, n):
                    if squares[j][3] < 1e-12:
                        continue
                    cj = _corners(*squares[j])
                    if _overlap_area(ci, cj) > 1e-10:
                        # shrink the larger one
                        if squares[i][3] > squares[j][3]:
                            squares[i][3] *= 0.995
                        else:
                            squares[j][3] *= 0.995
                        changed = True
                if changed:
                    break
            if not changed:
                break

        sc = _score(squares)
        if sc > best_score:
            best_score = sc
            best_squares = [list(s) for s in squares]

    # ensure all side lengths are non-negative and all in range
    result = []
    for s in best_squares:
        cx = max(0.0, min(1.0, s[0]))
        cy = max(0.0, min(1.0, s[1]))
        ang = s[2] % 1.0
        side = max(0.0, min(1.0, s[3]))
        result.append((cx, cy, ang, side))
    return result
