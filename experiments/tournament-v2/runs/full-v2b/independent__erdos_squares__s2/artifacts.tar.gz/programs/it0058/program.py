import math
import random

# ---------- geometry helpers ----------

def _rot(x, y, c, s):
    return (x * c - y * s, x * s + y * c)


def _corners(cx, cy, ang, side):
    """Return 4 corners of a square (fraction of full turn for angle)."""
    a = ang * 2.0 * math.pi
    c, s = math.cos(a), math.sin(a)
    h = side * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + x * c - y * s, cy + x * s + y * c) for (x, y) in pts]


def _inside(pts, eps=1e-12):
    for (x, y) in pts:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def _sat_disjoint(p, q, eps=1e-12):
    """True if two convex polygons have disjoint interiors (touching ok).
    Uses separating axis theorem over edge normals of both polygons."""
    for poly in (p, q):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ax, ay = -(y2 - y1), (x2 - x1)
            # project both polygons
            pmin = pmax = p[0][0] * ax + p[0][1] * ay
            for (x, y) in p[1:]:
                v = x * ax + y * ay
                if v < pmin: pmin = v
                if v > pmax: pmax = v
            qmin = qmax = q[0][0] * ax + q[0][1] * ay
            for (x, y) in q[1:]:
                v = x * ax + y * ay
                if v < qmin: qmin = v
                if v > qmax: qmax = v
            # gap check
            if pmax <= qmin + eps or qmax <= pmin + eps:
                return True
    return False


def _valid(cand, others, eps=1e-12):
    """cand is list of corner-lists; check all pairs disjoint and all inside."""
    n = len(cand)
    for i in range(n):
        if not _inside(cand[i], eps):
            return False
        for j in range(i + 1, n):
            if not _sat_disjoint(cand[i], cand[j], eps):
                return False
    return True


# ---------- initial layouts ----------

def _grid_layout(n):
    """Best axis-aligned grid using integer-ish splits."""
    # choose rows r, cols c with r*c >= n and r,c small => side = max(1/r,1/c)
    best = None
    best_score = -1
    for r in range(1, n + 1):
        c = (n + r - 1) // r
        if r * c < n:
            continue
        side = min(1.0 / r, 1.0 / c)
        # actually use full row height/col width individually
        rows = [1.0 / r] * r
        cols = [1.0 / c] * c
        score = 0.0
        cells = []
        for i in range(r):
            for j in range(c):
                if len(cells) < n:
                    s = min(rows[i], cols[j])
                    cells.append((j, i, s))
                    score += s
        if score > best_score:
            best_score = score
            best = cells
    return best


def _greedy_fill(n):
    """Fill unit square by repeatedly placing largest square in remaining gap
    using axis-aligned scan; simple but robust."""
    # We'll just use grid; improvement comes from local search
    return _grid_layout(n)


# ---------- local search ----------

def _angles():
    a = [0.0, 0.25]
    for k in range(1, 40):
        a.append(k / 80.0)
    return a


def _solve_local(n, time_budget=50.0):
    import time
    t0 = time.time()
    cells = _greedy_fill(n)
    # ensure exactly n
    if len(cells) < n:
        cells += [(0, 0, 0.0)] * (n - len(cells))
    cells = cells[:n]

    # build state
    state = []
    for (gx, gy, s) in cells:
        # place roughly centered, will be adjusted
        cx = (gx + 0.5) / max(1, math.isqrt(n))
        cy = (gy + 0.5) / max(1, math.isqrt(n))
        state.append([cx, cy, 0.0, s])

    angles = _angles()
    rng = random.Random(12345)

    def corner_list(st):
        return [_corners(cx, cy, ang, side) for (cx, cy, ang, side) in st]

    def total_score(st):
        return sum(s for (_, _, _, s) in st)

    def try_all(st):
        """Try to improve every square by moving/resizing/rotating."""
        improved_any = False
        improved = True
        while improved:
            improved = False
            if time.time() - t0 > time_budget:
                break
            for i in range(n):
                best_gain = 0.0
                best_move = None
                # current
                others_corners = corner_list([st[j] for j in range(n) if j != i])
                others = [st[j] for j in range(n) if j != i]
                cx0, cy0, ang0, s0 = st[i]
                # candidate placements: keep center, try angles & grow
                candidates = []
                for ang in angles:
                    candidates.append((cx0, cy0, ang))
                # small center shifts
                for dx in (-0.05, -0.02, 0.0, 0.02, 0.05):
                    for dy in (-0.05, -0.02, 0.0, 0.02, 0.05):
                        for ang in (0.0, 0.25):
                            candidates.append((cx0 + dx, cy0 + dy, ang))
                for (cx, cy, ang) in candidates:
                    if cx < 0 or cx > 1 or cy < 0 or cy > 1:
                        continue
                    # binary search max side
                    lo, hi = 0.0, 1.0
                    # quick upper bound from inside constraints
                    # find best hi that stays inside at least
                    def fits(s):
                        pts = _corners(cx, cy, ang, s)
                        if not _inside(pts):
                            return False
                        for j in range(n):
                            if j == i:
                                continue
                            if not _sat_disjoint(pts, corner_list([st[j]])[0]):
                                return False
                        return True
                    if not fits(1e-9):
                        continue
                    for _ in range(40):
                        mid = (lo + hi) * 0.5
                        if fits(mid):
                            lo = mid
                        else:
                            hi = mid
                    gain = lo - s0
                    if gain > best_gain + 1e-12:
                        best_gain = gain
                        best_move = (cx, cy, ang, lo)
                if best_move is not None:
                    st[i] = list(best_move)
                    improved = True
                    improved_any = True
        return improved_any

    try_all(state)

    # try random perturbations for a few restarts
    best_state = [row[:] for row in state]
    best_score = total_score(best_state)

    while time.time() - t0 < time_budget:
        # perturb
        trial = [row[:] for row in best_state]
        i = rng.randrange(n)
        trial[i][0] += rng.uniform(-0.1, 0.1)
        trial[i][1] += rng.uniform(-0.1, 0.1)
        trial[i][0] = min(1.0, max(0.0, trial[i][0]))
        trial[i][1] = min(1.0, max(0.0, trial[i][1]))
        # shrink to be safe
        trial[i][3] *= 0.95
        for j in range(n):
            trial[j][0] = min(1.0, max(0.0, trial[j][0]))
            trial[j][1] = min(1.0, max(0.0, trial[j][1]))
            trial[j][2] %= 1.0
        if not _valid(corner_list(trial)):
            continue
        try_all(trial)
        sc = total_score(trial)
        if sc > best_score + 1e-9:
            best_score = sc
            best_state = [row[:] for row in trial]
        else:
            # occasionally accept
            if rng.random() < 0.1:
                best_state = [row[:] for row in trial]

    return best_state


# ---------- fast path for tiny n ----------

def _solve_tiny(n):
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    return None


# ---------- main ----------

def solve(n):
    if n <= 0:
        return []
    tiny = _solve_tiny(n)
    if tiny is not None:
        return tiny
    try:
        st = _solve_local(n, time_budget=50.0)
    except Exception:
        # fallback grid
        k = math.isqrt(n)
        s = 1.0 / k
        st = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
        st += [(0.5, 0.5, 0.0, 0.0)] * (n - len(st))
        st = st[:n]
    out = []
    for (cx, cy, ang, side) in st:
        # sanitise
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        side = max(0.0, min(1.0, side))
        out.append((cx, cy, ang, side))
    return out
