import math
import random

def solve(n):
    """
    Return n squares (cx, cy, angle, side) inside the unit square [0,1]^2,
    with disjoint interiors, aiming to maximise the sum of side lengths.

    Strategy:
      - Start from a k x k grid of equal squares (k = floor(sqrt(n))), plus zero-size
        squares for the remainder.
      - Then run a stochastic local search that perturbs positions, angles and sizes,
        accepting changes that increase total side length, while using a separating-axis
        test to reject interior overlaps.
      - A few restarts / incremental growth steps are used to scale sizes beyond the
        equal-grid baseline.
    """

    if n <= 0:
        return []

    # ---------- collision helpers ----------
    def corners(cx, cy, ang, s):
        """Return the 4 corners of a square (centre, angle fraction of turn, side)."""
        h = s * 0.5
        c = math.cos(2.0 * math.pi * ang)
        sn = math.sin(2.0 * math.pi * ang)
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x = cx + dx * c - dy * sn
            y = cy + dx * sn + dy * c
            pts.append((x, y))
        return pts

    def axes(pts):
        """Separating axes for a convex polygon: normals to its edges."""
        out = []
        for i in range(len(pts)):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % len(pts)]
            ex, ey = x2 - x1, y2 - y1
            ax, ay = -ey, ex
            ln = math.hypot(ax, ay)
            if ln > 1e-15:
                out.append((ax / ln, ay / ln))
        return out

    def overlap(s1, s2):
        """True iff the two squares have overlapping interiors (SAT on polygons)."""
        cx1, cy1, a1, t1 = s1
        cx2, cy2, a2, t2 = s2
        if t1 <= 0.0 or t2 <= 0.0:
            return False
        p1 = corners(cx1, cy1, a1, t1)
        p2 = corners(cx2, cy2, a2, t2)

        # Quick AABB reject (cheap)
        min1x = min(p[0] for p in p1); max1x = max(p[0] for p in p1)
        min2x = min(p[0] for p in p2); max2x = max(p[0] for p in p2)
        if max1x <= min2x + 1e-12 or max2x <= min1x + 1e-12:
            return False
        min1y = min(p[1] for p in p1); max1y = max(p[1] for p in p1)
        min2y = min(p[1] for p in p2); max2y = max(p[1] for p in p2)
        if max1y <= min2y + 1e-12 or max2y <= min1y + 1e-12:
            return False

        for ax, ay in axes(p1) + axes(p2):
            proj1 = [x * ax + y * ay for x, y in p1]
            proj2 = [x * ax + y * ay for x, y in p2]
            if max(proj1) <= min(proj2) + 1e-12 or max(proj2) <= min(proj1) + 1e-12:
                return False
        return True

    # ---------- feasibility of one square wrt container and others ----------
    def inside_container(s):
        cx, cy, ang, side = s
        if side <= 0.0:
            # zero squares count as points; must be inside [0,1]^2
            return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
        p = corners(cx, cy, ang, side)
        for x, y in p:
            if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
                return False
        return True

    def feasible(s, others):
        if not inside_container(s):
            return False
        for o in others:
            if overlap(s, o):
                return False
        return True

    def total(sqs):
        return sum(s[3] for s in sqs)

    # ---------- initial solutions ----------
    def grid_init(n):
        """k x k grid, k = isqrt(n), plus zero-size fillers."""
        k = math.isqrt(n)
        if k == 0:
            return [(0.5, 0.5, 0.0, 0.0) for _ in range(n)]
        side = 1.0 / k
        out = []
        for i in range(k):
            for j in range(k):
                out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        while len(out) < n:
            out.append((0.5, 0.5, 0.0, 0.0))
        return out[:n]

    def strip_init(n):
        """Try to place squares in rows with varied sizes."""
        sqs = []
        y = 0.0
        remaining = n
        while remaining > 0:
            # decide row height
            k = min(remaining, max(1, int(math.sqrt(remaining))))
            h = 1.0 / max(1, k)
            if y + h > 1.0 + 1e-12:
                break
            for i in range(k):
                sqs.append(((i + 0.5) * h, y + h * 0.5, 0.0, h))
            y += h
            remaining -= k
        while len(sqs) < n:
            sqs.append((0.5, 0.5, 0.0, 0.0))
        return sqs[:n]

    def random_init(n, seed=0):
        rng = random.Random(seed)
        sqs = [(0.5, 0.5, 0.0, 0.0) for _ in range(n)]
        # place random small squares, growing until collision
        for i in range(n):
            best = (0.0, 0.0, 0.0, 0.0)
            for _ in range(30):
                cx = rng.random()
                cy = rng.random()
                ang = rng.random()
                # estimate max side
                lim = min(cx, 1 - cx, cy, 1 - cy) * 1.5
                if lim <= 0:
                    continue
                side = lim * rng.random()
                cand = (cx, cy, ang, side)
                if feasible(cand, sqs[:i] + sqs[i + 1:]):
                    if side > best[3]:
                        best = cand
            sqs[i] = best
        return sqs

    # ---------- local search ----------
    def improve(sqs, steps, rng, t0=0.05):
        sqs = [list(s) for s in sqs]
        best = [list(s) for s in sqs]
        best_val = total(sqs)
        cur_val = best_val

        for it in range(steps):
            i = rng.randrange(n)
            old = tuple(sqs[i])
            cand = list(old)
            move = rng.random()
            if move < 0.45:
                cand[0] += (rng.random() - 0.5) * 0.02
                cand[1] += (rng.random() - 0.5) * 0.02
            elif move < 0.70:
                cand[2] += (rng.random() - 0.5) * 0.08
            else:
                cand[3] += (rng.random() - 0.5) * 0.02

            # clamp
            cand[0] = min(1.0, max(0.0, cand[0]))
            cand[1] = min(1.0, max(0.0, cand[1]))
            if cand[3] < 0.0:
                cand[3] = 0.0

            # enforce container bounds by shrinking if necessary
            # (simple: if outside, reduce side until inside)
            if cand[3] > 0.0:
                for _ in range(12):
                    if inside_container(tuple(cand)):
                        break
                    cand[3] *= 0.85
                    if cand[3] < 1e-12:
                        cand[3] = 0.0
                        break

            others = [tuple(sqs[j]) for j in range(n) if j != i]
            if feasible(tuple(cand), others):
                old_len = old[3]
                new_len = cand[3]
                delta = new_len - old_len
                # simulated annealing-ish acceptance
                if delta >= 0 or rng.random() < math.exp(delta / max(1e-9, t0)):
                    sqs[i] = cand
                    cur_val += delta
                    if cur_val > best_val:
                        best_val = cur_val
                        best = [list(s) for s in sqs]
            else:
                pass

            # occasionally try to grow a square directly
            if rng.random() < 0.04:
                j = rng.randrange(n)
                oldj = tuple(sqs[j])
                candj = list(oldj)
                candj[3] += 0.005
                if candj[3] > 0.0:
                    for _ in range(20):
                        if inside_container(tuple(candj)):
                            break
                        candj[3] *= 0.9
                        if candj[3] < 1e-12:
                            candj[3] = 0.0
                            break
                others = [tuple(sqs[k]) for k in range(n) if k != j]
                if feasible(tuple(candj), others):
                    delta = candj[3] - oldj[3]
                    sqs[j] = candj
                    cur_val += delta
                    if cur_val > best_val:
                        best_val = cur_val
                        best = [list(s) for s in sqs]

        return [tuple(s) for s in best]

    # ---------- run multiple restarts and keep the best ----------
    best_sol = None
    best_score = -1.0
    rng = random.Random(12345)

    inits = [grid_init(n), strip_init(n), random_init(n, seed=1), random_init(n, seed=2)]

    for init in inits:
        # repair feasibility: drop overlapping squares to zero, shrink others
        sqs = []
        for s in init:
            cand = list(s)
            cand[0] = min(1.0, max(0.0, cand[0]))
            cand[1] = min(1.0, max(0.0, cand[1]))
            cand[3] = max(0.0, cand[3])
            while cand[3] > 0.0 and not inside_container(tuple(cand)):
                cand[3] *= 0.9
                if cand[3] < 1e-12:
                    cand[3] = 0.0
                    break
            if cand[3] > 0.0 and any(overlap(tuple(cand), tuple(o)) for o in sqs):
                cand[3] = 0.0
            sqs.append(tuple(cand))

        # try to increase sizes greedily
        improved = True
        while improved:
            improved = False
            order = list(range(n))
            rng.shuffle(order)
            for i in order:
                s = list(sqs[i])
                if s[3] <= 0.0:
                    # try to grow from zero
                    for _ in range(20):
                        cx = min(1.0, max(0.0, s[0] + (rng.random() - 0.5) * 0.1))
                        cy = min(1.0, max(0.0, s[1] + (rng.random() - 0.5) * 0.1))
                        ang = rng.random()
                        side = 0.005 + rng.random() * 0.02
                        cand = (cx, cy, ang, side)
                        if inside_container(cand) and all(
                            not overlap(cand, sqs[j]) for j in range(n) if j != i
                        ):
                            sqs[i] = cand
                            improved = True
                            break
                else:
                    # grow
                    for factor in (1.02, 1.01, 1.005, 1.001):
                        cand = (s[0], s[1], s[2], s[3] * factor)
                        if inside_container(cand) and all(
                            not overlap(cand, sqs[j]) for j in range(n) if j != i
                        ):
                            sqs[i] = cand
                            improved = True
                            break

        # local search
        steps = max(2000, 250 * n)
        cand_sol = improve(sqs, steps, rng)

        val = total(cand_sol)
        if val > best_score:
            best_score = val
            best_sol = cand_sol

    # final safety: ensure no overlaps and inside [0,1]
    final = []
    for s in best_sol:
        cx, cy, ang, side = s
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        side = max(0.0, side)
        cand = (cx, cy, ang, side)
        if side > 0.0:
            while side > 0.0 and not inside_container(cand):
                side *= 0.9
                cand = (cx, cy, ang, side)
        if side > 0.0 and any(overlap(cand, o) for o in final):
            cand = (cx, cy, ang, 0.0)
        final.append(cand)

    return final
