import math
import random


def _sq_poly(cx, cy, ang, s):
    """Return the 4 corners of a square with centre (cx,cy), side s, angle ang turns."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        xr = cx + ca * x - sa * y
        yr = cy + sa * x + ca * y
        out.append((xr, yr))
    return out


def _seg_intersect(p1, p2, p3, p4):
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    d1 = cross(p3, p4, p1)
    d2 = cross(p3, p4, p2)
    d3 = cross(p1, p2, p3)
    d4 = cross(p1, p2, p4)
    if ((d1 > 0 and d2 < 0) or (d1 < 0 and d2 > 0)) and (
        (d3 > 0 and d4 < 0) or (d3 < 0 and d4 > 0)
    ):
        return True
    # collinear touching counts as intersect only if overlapping interiors; skip
    return False


def _inside(poly, pt):
    # convex polygon, check same side
    n = len(poly)
    for i in range(n):
        a = poly[i]
        b = poly[(i + 1) % n]
        d = (b[0] - a[0]) * (pt[1] - a[1]) - (b[1] - a[1]) * (pt[0] - a[0])
        if d < 0:
            return False
    return True


def _poly_intersect(p1, p2):
    # if any edge intersects -> intersect interiors likely
    n1 = len(p1)
    n2 = len(p2)
    for i in range(n1):
        a1 = p1[i]
        b1 = p1[(i + 1) % n1]
        for j in range(n2):
            a2 = p2[j]
            b2 = p2[(j + 1) % n2]
            if _seg_intersect(a1, b1, a2, b2):
                return True
    # containment check
    if _inside(p1, p2[0]):
        return True
    if _inside(p2, p1[0]):
        return True
    return False


def _in_unit(poly):
    for x, y in poly:
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _score(placed):
    return sum(s for _, _, _, s in placed)


def _try_pack(n, seed, time_budget_iters=4000):
    rng = random.Random(seed)
    # candidate list of (cx, cy, ang, s)
    best = None
    best_score = -1.0

    # multi-start
    attempts = 3 if n <= 8 else 2
    for att in range(attempts):
        placed = []  # list of (cx,cy,ang,s,poly)
        polys = []
        total = 0.0

        for step in range(n):
            # choose scale decreasing
            remaining = n - step
            # target side: heuristic
            if remaining == 1:
                maxs_hint = 1.0
            else:
                maxs_hint = 1.0 / math.sqrt(remaining) * 1.15
            best_cand = None
            best_cand_s = -1.0

            # sample attempts for this square
            num_try = 800 if n <= 25 else 400
            for _ in range(num_try):
                if rng.random() < 0.5 and placed:
                    # anchor near existing
                    px, py, pa, ps = rng.choice(placed)
                    cx = px + rng.uniform(-ps, ps)
                    cy = py + rng.uniform(-ps, ps)
                else:
                    cx = rng.uniform(0.0, 1.0)
                    cy = rng.uniform(0.0, 1.0)
                ang = rng.choice([0.0, 0.25, rng.uniform(0.0, 0.5)])
                # binary search largest s that fits
                lo, hi = 0.0, min(cx, cy, 1 - cx, 1 - cy) * 2.0 * math.sqrt(2)
                hi = min(hi, maxs_hint)
                # quick check with hi
                poly = _sq_poly(cx, cy, ang, hi)
                if not _in_unit(poly):
                    # shrink until fits
                    hi *= 0.7
                    poly = _sq_poly(cx, cy, ang, hi)
                    if not _in_unit(poly):
                        continue
                ok = True
                for q in polys:
                    if _poly_intersect(poly, q):
                        ok = False
                        break
                if not ok:
                    continue
                # grow
                for _ in range(20):
                    mid = (lo + hi) * 0.5
                    if mid < 1e-6:
                        break
                    ptest = _sq_poly(cx, cy, ang, mid)
                    if not _in_unit(ptest):
                        hi = mid
                        continue
                    okk = True
                    for q in polys:
                        if _poly_intersect(ptest, q):
                            okk = False
                            break
                    if okk:
                        lo = mid
                        poly = ptest
                    else:
                        hi = mid
                s = lo
                if s > best_cand_s:
                    best_cand_s = s
                    best_cand = (cx, cy, ang, s, _sq_poly(cx, cy, ang, s))

            if best_cand is None:
                # place zero
                placed.append((0.5, 0.5, 0.0, 0.0))
                polys.append([])
                continue
            cx, cy, ang, s, poly = best_cand
            placed.append((cx, cy, ang, s))
            polys.append(poly)
            total += s

        if total > best_score:
            best_score = total
            best = placed

    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Perfect square: use grid
    k = math.isqrt(n)
    if k * k == n:
        s = 1.0 / k
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]

    # Try to find best packing
    random.seed(12345)
    best = None
    best_score = -1.0
    seeds = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 42, 99, 123]
    for sd in seeds:
        res = _try_pack(n, sd)
        sc = _score(res)
        if sc > best_score:
            best_score = sc
            best = res

    # baseline grid + remainder
    k = math.isqrt(n)
    s = 1.0 / k
    grid = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    rem = n - len(grid)
    grid += [(0.5, 0.5, 0.0, 0.0)] * rem
    gsc = _score([(cx, cy, a, ss) for (cx, cy, a, ss) in grid])
    if gsc > best_score:
        best = grid

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    return best[:n]
