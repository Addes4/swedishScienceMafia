import math
import random
import numpy as np
from scipy.optimize import minimize


def _area_bound(n):
    # trivial upper bound is n, but useful sanity only
    return float(n)


def _grid_layout(n):
    k = int(math.isqrt(n))
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _row_layout(n):
    # try m rows with equal height, squares packed in rows
    best = None
    best_s = -1
    for rows in range(1, n + 1):
        cols = int(math.ceil(n / rows))
        h = 1.0 / rows
        w = 1.0 / cols
        s = min(h, w)
        # total sum if each square size s
        total = n * s
        if total > best_s:
            best_s = total
            best = (rows, cols, s)
    rows, cols, s = best
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            x = (c + 0.5) * (1.0 / cols)
            y = (r + 0.5) * (1.0 / rows)
            squares.append((x, y, 0.0, s))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _strips_layout(n):
    # Partition into vertical strips of varying widths, each filled with squares.
    # Simple heuristic: try all partitions of n into parts, use square in each strip.
    # Approximate: use k strips of equal-ish counts.
    best = None
    best_s = -1
    for k in range(1, n + 1):
        # distribute n among k strips
        base = n // k
        rem = n % k
        counts = [base + (1 if i < rem else 0) for i in range(k)]
        counts = [c for c in counts if c > 0]
        k2 = len(counts)
        if k2 == 0:
            continue
        # width per strip: choose strip widths proportional to sqrt(count)
        weights = [math.sqrt(c) for c in counts]
        ssum = sum(weights)
        widths = [w / ssum for w in weights]
        # in each strip, place count squares stacked vertically, side = min(width, 1/count)
        squares = []
        x0 = 0.0
        total = 0.0
        ok = True
        for c, w in zip(counts, widths):
            sh = 1.0 / c
            s = min(w, sh)
            total += c * s
            for i in range(c):
                x = x0 + w / 2.0
                y = (i + 0.5) * sh
                squares.append((x, y, 0.0, s))
            x0 += w
        if total > best_s:
            best_s = total
            best = squares
    return best


def _recursive_layout(n):
    # recursively split rectangle into two parts, distribute n
    from functools import lru_cache

    # we work with rectangles (x0,y0,x1,y1) and n squares.
    # value function: estimate total side length.
    memo = {}

    def rec(w, h, n):
        if n == 0:
            return 0.0, []
        key = (round(w, 6), round(h, 6), n)
        if key in memo:
            return memo[key]
        # base: single square
        if n == 1:
            s = min(w, h)
            res = (s, [(w / 2.0, h / 2.0, 0.0, s)])
            memo[key] = res
            return res
        # option 1: grid-like
        best_val = -1.0
        best_sq = None

        # try vertical split
        for i in range(1, n):
            # split proportionally to sqrt(i) and sqrt(n-i) by area
            w1 = w * math.sqrt(i) / (math.sqrt(i) + math.sqrt(n - i))
            w2 = w - w1
            if w1 <= 0 or w2 <= 0:
                continue
            v1, s1 = rec(w1, h, i)
            v2, s2 = rec(w2, h, n - i)
            val = v1 + v2
            if val > best_val:
                best_val = val
                best_sq = [(x, y, a, s) for (x, y, a, s) in s1] + \
                          [(x + w1, y, a, s) for (x, y, a, s) in s2]

        # try horizontal split
        for i in range(1, n):
            h1 = h * math.sqrt(i) / (math.sqrt(i) + math.sqrt(n - i))
            h2 = h - h1
            if h1 <= 0 or h2 <= 0:
                continue
            v1, s1 = rec(w, h1, i)
            v2, s2 = rec(w, h2, n - i)
            val = v1 + v2
            if val > best_val:
                best_val = val
                best_sq = [(x, y, a, s) for (x, y, a, s) in s1] + \
                          [(x, y + h1, a, s) for (x, y, a, s) in s2]

        # option: all in one row/col
        # vertical stack
        s = min(w, h / n)
        val = n * s
        if val > best_val:
            best_val = val
            best_sq = [(w / 2, (i + 0.5) * (h / n), 0.0, s) for i in range(n)]
        # horizontal stack
        s = min(h, w / n)
        val = n * s
        if val > best_val:
            best_val = val
            best_sq = [((i + 0.5) * (w / n), h / 2, 0.0, s) for i in range(n)]

        memo[key] = (best_val, best_sq)
        return best_val, best_sq

    val, sqs = rec(1.0, 1.0, n)
    return [(x, y, a, s) for (x, y, a, s) in sqs]


def _overlap_penalty(squares):
    # squares as (cx, cy, angle, side), angle in fraction of full turn
    # compute pairwise overlap penalty for axis-aligned squares (angles ignored for speed)
    n = len(squares)
    pen = 0.0
    for i in range(n):
        xi, yi, ai, si = squares[i]
        hi = si / 2.0
        if hi <= 0:
            continue
        for j in range(i + 1, n):
            xj, yj, aj, sj = squares[j]
            hj = sj / 2.0
            if hj <= 0:
                continue
            dx = abs(xi - xj)
            dy = abs(yi - yj)
            ox = hi + hj - dx
            oy = hi + hj - dy
            if ox > 0 and oy > 0:
                pen += ox * oy
    return pen


def _containment_penalty(squares):
    pen = 0.0
    for (x, y, a, s) in squares:
        h = s / 2.0
        if h <= 0:
            continue
        pen += max(0.0, h - x) ** 2
        pen += max(0.0, x + h - 1.0) ** 2
        pen += max(0.0, h - y) ** 2
        pen += max(0.0, y + h - 1.0) ** 2
    return pen


def _objective_and_grad(params, n, base_squares, w_pen, w_cont):
    # params: for each square, cx, cy, side (keep angles fixed for gradient)
    squares = []
    for i in range(n):
        cx = params[3 * i]
        cy = params[3 * i + 1]
        s = params[3 * i + 2]
        ang = base_squares[i][2]
        squares.append((cx, cy, ang, s))

    # sum of sides (maximize -> minimize negative)
    val = -sum(sq[3] for sq in squares)

    # gradient
    grad = np.zeros(3 * n)
    for i in range(n):
        grad[3 * i + 2] = -1.0

    # containment penalties (soft)
    for i, (x, y, a, s) in enumerate(squares):
        h = s / 2.0
        # left
        if x - h < 0:
            d = x - h
            val += w_cont * d * d
            grad[3 * i] += w_cont * 2 * d
            grad[3 * i + 2] += w_cont * 2 * d * (-1.0 / 2.0)
        # right
        if x + h > 1:
            d = x + h - 1
            val += w_cont * d * d
            grad[3 * i] += w_cont * 2 * d
            grad[3 * i + 2] += w_cont * 2 * d * (1.0 / 2.0)
        # bottom
        if y - h < 0:
            d = y - h
            val += w_cont * d * d
            grad[3 * i + 1] += w_cont * 2 * d
            grad[3 * i + 2] += w_cont * 2 * d * (-1.0 / 2.0)
        # top
        if y + h > 1:
            d = y + h - 1
            val += w_cont * d * d
            grad[3 * i + 1] += w_cont * 2 * d
            grad[3 * i + 2] += w_cont * 2 * d * (1.0 / 2.0)

    # pairwise overlap penalties (soft, axis-aligned approximation)
    for i in range(n):
        xi, yi, ai, si = squares[i]
        hi = si / 2.0
        if hi <= 0:
            continue
        for j in range(i + 1, n):
            xj, yj, aj, sj = squares[j]
            hj = sj / 2.0
            if hj <= 0:
                continue
            dx = xi - xj
            dy = yi - yj
            ox = hi + hj - abs(dx)
            oy = hi + hj - abs(dy)
            if ox > 0 and oy > 0:
                val += w_pen * ox * oy
                sx = 1.0 if dx > 0 else -1.0
                sy = 1.0 if dy > 0 else -1.0
                # d(ox)/dxi = -sx, etc.
                grad[3 * i] += w_pen * (-sx) * oy
                grad[3 * j] += w_pen * (sx) * oy
                grad[3 * i + 1] += w_pen * (-sy) * ox
                grad[3 * j + 1] += w_pen * (sy) * ox
                # derivatives wrt side
                grad[3 * i + 2] += w_pen * 0.5 * oy
                grad[3 * j + 2] += w_pen * 0.5 * ox

    return val, grad


def _polish(n, squares, iters=200):
    # optimize sizes and positions with L-BFGS-B, keeping angles fixed
    if n == 0:
        return squares
    x0 = np.zeros(3 * n)
    bounds = []
    for i in range(n):
        x0[3 * i] = squares[i][0]
        x0[3 * i + 1] = squares[i][1]
        x0[3 * i + 2] = squares[i][3]
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))

    def fun(p):
        return _objective_and_grad(p, n, squares, 100.0, 100.0)

    try:
        res = minimize(fun, x0, jac=True, method='L-BFGS-B',
                       bounds=bounds, options={'maxiter': iters, 'ftol': 1e-12})
        p = res.x
    except Exception:
        p = x0

    out = []
    for i in range(n):
        cx = min(max(p[3 * i], 0.0), 1.0)
        cy = min(max(p[3 * i + 1], 0.0), 1.0)
        s = min(max(p[3 * i + 2], 0.0), 1.0)
        out.append((cx, cy, squares[i][2], s))
    return out


def _resolve_overlaps(squares, passes=50):
    # simple iterative push-out to remove overlaps, keep inside unit square
    n = len(squares)
    sq = [list(x) for x in squares]
    for _ in range(passes):
        moved = False
        for i in range(n):
            xi, yi, ai, si = sq[i]
            hi = si / 2.0
            if hi <= 0:
                continue
            # containment
            if xi - hi < 0:
                xi = hi
                moved = True
            if xi + hi > 1:
                xi = 1 - hi
                moved = True
            if yi - hi < 0:
                yi = hi
                moved = True
            if yi + hi > 1:
                yi = 1 - hi
                moved = True
            for j in range(n):
                if i == j:
                    continue
                xj, yj, aj, sj = sq[j]
                hj = sj / 2.0
                if hj <= 0:
                    continue
                dx = xi - xj
                dy = yi - yj
                ox = hi + hj - abs(dx)
                oy = hi + hj - abs(dy)
                if ox > 0 and oy > 0:
                    # push along smaller overlap axis
                    if ox < oy:
                        if dx >= 0:
                            xi += ox / 2.0
                        else:
                            xi -= ox / 2.0
                    else:
                        if dy >= 0:
                            yi += oy / 2.0
                        else:
                            yi -= oy / 2.0
                    moved = True
            # clamp again
            if xi - hi < 0:
                xi = hi
            if xi + hi > 1:
                xi = 1 - hi
            if yi - hi < 0:
                yi = hi
            if yi + hi > 1:
                yi = 1 - hi
            sq[i][0] = xi
            sq[i][1] = yi
        if not moved:
            break
    return [tuple(x) for x in sq]


def _shrink_to_fit(squares):
    # scale down all sizes until no overlaps and inside bounds, if needed
    sq = [list(x) for x in squares]
    n = len(sq)
    for _ in range(100):
        ok = True
        # check containment
        for i in range(n):
            xi, yi, ai, si = sq[i]
            hi = si / 2.0
            if xi - hi < -1e-9 or xi + hi > 1 + 1e-9 or yi - hi < -1e-9 or yi + hi > 1 + 1e-9:
                ok = False
                break
            for j in range(i + 1, n):
                xj, yj, aj, sj = sq[j]
                hj = sj / 2.0
                dx = abs(xi - xj)
                dy = abs(yi - yj)
                if dx < hi + hj - 1e-9 and dy < hi + hj - 1e-9:
                    ok = False
                    break
            if not ok:
                break
        if ok:
            return [tuple(x) for x in sq]
        # shrink all sizes by 0.99
        for k in range(n):
            sq[k][3] *= 0.995
    return [tuple(x) for x in sq]


def _improve(squares, n, seed=0):
    rnd = random.Random(seed)
    best = _shrink_to_fit(_resolve_overlaps(squares))
    best_val = sum(s[3] for s in best)

    # try several random perturbations and polish
    for it in range(8):
        cand = [list(s) for s in best]
        # perturb positions slightly
        for i in range(n):
            if cand[i][3] > 0:
                cand[i][0] += rnd.uniform(-0.02, 0.02)
                cand[i][1] += rnd.uniform(-0.02, 0.02)
                cand[i][0] = min(max(cand[i][0], 0.0), 1.0)
                cand[i][1] = min(max(cand[i][1], 0.0), 1.0)
        cand = _resolve_overlaps([tuple(x) for x in cand])
        cand = _polish(n, cand, iters=100)
        cand = _resolve_overlaps(cand)
        cand = _shrink_to_fit(cand)
        val = sum(s[3] for s in cand)
        if val > best_val:
            best_val = val
            best = cand

    # try optimizing sizes with positions fixed
    return best


def solve(n):
    if n <= 0:
        return []
    candidates = []
    candidates.append(_grid_layout(n))
    candidates.append(_row_layout(n))
    try:
        candidates.append(_strips_layout(n))
    except Exception:
        pass
    try:
        candidates.append(_recursive_layout(n))
    except Exception:
        pass

    # add a rotated variant of the grid for small n
    if n <= 25:
        k = math.isqrt(n)
        if k * k == n:
            s = 1.0 / k
            rot = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
            # try small rotations
            for ang in [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45]:
                c = math.cos(2 * math.pi * ang)
                sn = math.sin(2 * math.pi * ang)
                rotated = []
                ok = True
                for (x, y, a, sz) in rot:
                    h = sz / 2.0
                    # bounding box half-extent after rotation
                    ex = abs(c) * h + abs(sn) * h
                    ey = abs(sn) * h + abs(c) * h
                    if ex > 0.5 or ey > 0.5:
                        ok = False
                        break
                if ok:
                    # place rotated squares with same centers (they fit)
                    rotated = [(x, y, ang, sz) for (x, y, a, sz) in rot]
                    candidates.append(rotated)

    best = None
    best_val = -1.0
    for cand in candidates:
        if len(cand) != n:
            continue
        c2 = _shrink_to_fit(_resolve_overlaps(cand))
        v = sum(s[3] for s in c2)
        if v > best_val:
            best_val = v
            best = c2

    if best is None:
        best = _grid_layout(n)

    best = _improve(best, n, seed=42)

    # final guarantee: shrink if still overlapping
    best = _shrink_to_fit(_resolve_overlaps(best))

    # pad if needed
    out = list(best[:n])
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
