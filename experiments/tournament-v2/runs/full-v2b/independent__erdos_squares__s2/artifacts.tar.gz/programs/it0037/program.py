import math


def _overlap(a, b, eps=1e-12):
    """Return True if two axis-aligned or rotated squares overlap in interior."""
    cx1, cy1, a1, s1 = a
    cx2, cy2, a2, s2 = b
    if s1 <= 0.0 or s2 <= 0.0:
        return False
    h1 = 0.5 * s1
    h2 = 0.5 * s2
    # bounding circle check
    r1 = h1 * math.sqrt(2.0)
    r2 = h2 * math.sqrt(2.0)
    dx = cx1 - cx2
    dy = cy1 - cy2
    if dx * dx + dy * dy > (r1 + r2) ** 2:
        return False

    # Separating axis theorem for two convex polygons (squares)
    def axes(cx, cy, ang, h):
        t = ang * 2.0 * math.pi
        c = math.cos(t)
        s = math.sin(t)
        return ((c, s), (-s, c))

    def corners(cx, cy, ang, h):
        t = ang * 2.0 * math.pi
        c = math.cos(t)
        s = math.sin(t)
        px = h * c
        py = h * s
        qx = -h * s
        qy = h * c
        return (
            (cx + px + qx, cy + py + qy),
            (cx + px - qx, cy + py - qy),
            (cx - px - qx, cy - py - qy),
            (cx - px + qx, cy - py + qy),
        )

    p1 = corners(cx1, cy1, a1, h1)
    p2 = corners(cx2, cy2, a2, h2)

    def project(poly, ax):
        d = [x * ax[0] + y * ax[1] for x, y in poly]
        return min(d), max(d)

    for ax in axes(cx1, cy1, a1, h1):
        lo1, hi1 = project(p1, ax)
        lo2, hi2 = project(p2, ax)
        if hi1 < lo2 - eps or hi2 < lo1 - eps:
            return False
    for ax in axes(cx2, cy2, a2, h2):
        lo1, hi1 = project(p1, ax)
        lo2, hi2 = project(p2, ax)
        if hi1 < lo2 - eps or hi2 < lo1 - eps:
            return False
    return True


def _inside_unit(cx, cy, ang, side):
    if side <= 0.0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    h = 0.5 * side
    t = ang * 2.0 * math.pi
    c = math.cos(t)
    s = math.sin(t)
    # half extent along x and y
    ex = h * (abs(c) + abs(s))
    ey = h * (abs(c) + abs(s))
    return (cx - ex >= -1e-12 and cx + ex <= 1.0 + 1e-12 and
            cy - ey >= -1e-12 and cy + ey <= 1.0 + 1e-12)


def _feasible(squares):
    n = len(squares)
    for i in range(n):
        if not _inside_unit(*squares[i]):
            return False
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _sum_sides(squares):
    return sum(s[3] for s in squares)


def _try_place(squares, side, nc=18):
    """Try to place a square of given side in a free spot, return new square or None."""
    best = None
    best_slack = -1.0
    h = 0.5 * side
    # sample centre positions
    for ix in range(nc):
        for iy in range(nc):
            # jittered grid
            cx = (ix + 0.5 + 0.37 * ((ix * 7 + iy * 13) % 5 - 2) / 5.0) / nc
            cy = (iy + 0.5 + 0.37 * ((ix * 11 + iy * 3) % 5 - 2) / 5.0) / nc
            for ang in (0.0, 0.25, 0.125, 0.375):
                cand = (cx, cy, ang, side)
                if not _inside_unit(cx, cy, ang, side):
                    continue
                ok = True
                for sq in squares:
                    if _overlap(cand, sq):
                        ok = False
                        break
                if ok:
                    # compute slack: distance to nearest obstacle & boundary
                    ex = h * (abs(math.cos(ang * 2 * math.pi)) + abs(math.sin(ang * 2 * math.pi)))
                    slack = min(cx - ex, 1.0 - cx - ex, cy - ex, 1.0 - cy - ex)
                    if slack > best_slack:
                        best_slack = slack
                        best = (cx, cy, ang, side)
    return best


def _grow_squares(squares, iters=4):
    """Try to increase side lengths of existing squares slightly."""
    n = len(squares)
    improved = True
    for _ in range(iters):
        improved = False
        for i in range(n):
            cx, cy, ang, side = squares[i]
            if side <= 0.0:
                continue
            # try to grow side by small amount
            for factor in (1.02, 1.01, 1.005, 1.002, 1.001):
                ns = side * factor
                if ns > 1.0:
                    continue
                cand = (cx, cy, ang, ns)
                if not _inside_unit(*cand):
                    continue
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if _overlap(cand, squares[j]):
                        ok = False
                        break
                if ok:
                    squares[i] = cand
                    improved = True
                    break
        if not improved:
            break
    return squares


def _local_optimize(squares, iters=30):
    """Perturb centres slightly to improve sum."""
    n = len(squares)
    step = 0.01
    cur = _sum_sides(squares)
    for _ in range(iters):
        improved = False
        for i in range(n):
            cx, cy, ang, side = squares[i]
            for dx, dy in ((step, 0), (-step, 0), (0, step), (0, -step)):
                ncx = cx + dx
                ncy = cy + dy
                if not _inside_unit(ncx, ncy, ang, side):
                    continue
                cand = (ncx, ncy, ang, side)
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if _overlap(cand, squares[j]):
                        ok = False
                        break
                if ok:
                    squares[i] = cand
                    cx, cy = ncx, ncy
                    improved = True
        if not improved:
            step *= 0.5
            if step < 1e-7:
                break
    return squares


def _initial_grid(n):
    """Best grid arrangement plus extra squares."""
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # extra squares placed in the remaining space
    while len(squares) < n:
        # try decreasing side
        placed = False
        for frac in (0.5, 0.4, 0.33, 0.25, 0.2, 0.15, 0.1, 0.07, 0.05, 0.03, 0.02, 0.01):
            cand_side = frac * side
            pos = _try_place(squares, cand_side)
            if pos is not None:
                squares.append(pos)
                placed = True
                break
        if not placed:
            squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side 0.5
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three squares, best known: 0.5 + 0.5 + small or rotated arrangement
        s = 0.5
        squares = [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
        # third square can be bigger if rotated? Just use 0.5 for now
        return squares
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        # 4 squares of side 0.5, plus small in middle? Actually 4*0.5 = 2.0
        # Try 0.5,0.5,0.5,0.5 + something
        squares = [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                   (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
        pos = _try_place(squares, 0.01)
        if pos:
            squares.append(pos)
        else:
            squares.append((0.5, 0.5, 0.0, 0.0))
        return squares

    squares = _initial_grid(n)
    # Try to improve with growth and local search
    squares = _grow_squares(squares, iters=5)
    squares = _local_optimize(squares, iters=20)
    squares = _grow_squares(squares, iters=3)
    squares = _local_optimize(squares, iters=15)
    # Trim to n
    squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares
