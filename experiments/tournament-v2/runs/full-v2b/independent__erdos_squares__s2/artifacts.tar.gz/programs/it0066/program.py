import math


def solve(n):
    """Place n squares inside the unit square, no two sharing an interior.

    Strategy: recursively decompose the unit square into empty rectangular
    regions.  At each step, pick the largest free rectangle, place the largest
    axis-aligned square that fits in it, and split the rectangle into the two
    remaining L-shaped strips.  This greedy packing gives the k x k grid for
    perfect squares and improves on it for other n by squeezing extra squares
    into the leftover strips.
    """
    if n <= 0:
        return []

    rects = [(0.0, 0.0, 1.0, 1.0)]  # (x0, y0, x1, y1)
    squares = []

    while len(squares) < n:
        # pick rectangle with the largest possible inscribed square
        best_i = -1
        best_s = -1.0
        for i, (x0, y0, x1, y1) in enumerate(rects):
            w = x1 - x0
            h = y1 - y0
            s = w if w < h else h
            if s > best_s:
                best_s = s
                best_i = i

        if best_s <= 0.0:
            break

        x0, y0, x1, y1 = rects.pop(best_i)
        w = x1 - x0
        h = y1 - y0
        s = w if w < h else h

        # place square in the lower-left corner of the rectangle
        cx = x0 + s / 2.0
        cy = y0 + s / 2.0
        squares.append((cx, cy, 0.0, s))

        if w > h:
            # vertical square column removed; remainder is right strip
            rects.append((x0 + s, y0, x1, y1))
        else:
            # horizontal square row removed; remainder is top strip
            rects.append((x0, y0 + s, x1, y1))

    # fill remaining slots with size-zero squares
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))

    return squares
