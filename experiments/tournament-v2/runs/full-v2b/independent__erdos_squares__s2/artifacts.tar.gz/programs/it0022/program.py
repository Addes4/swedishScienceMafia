import math, random, time

def solve(n):
    random.seed(12345)
    start = time.time()
    LIMIT = 58.0

    def inside_poly(px, py, poly):
        inside = False
        m = len(poly)
        j = m - 1
        for i in range(m):
            xi, yi = poly[i]
            xj, yj = poly[j]
            if ((yi > py) != (yj > py)) and (px < (xj - xi) * (py - yi) / (yj - yi + 1e-30) + xi):
                inside = not inside
            j = i
        return inside

    def square_corners(cx, cy, ang, s):
        # angle in fraction of full turn; convert to radians
        a = (ang % 1.0) * 2 * math.pi
        ca, sa = math.cos(a), math.sin(a)
        h = s * 0.5
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x = cx + dx * ca - dy * sa
            y = cy + dx * sa + dy * ca
            pts.append((x, y))
        return pts

    def poly_overlap(A, B):
        # exact-ish separating axis for convex polygons
        for poly in (A, B):
            m = len(poly)
            for i in range(m):
                x1, y1 = poly[i]
                x2, y2 = poly[(i + 1) % m]
                nx, ny = -(y2 - y1), (x2 - x1)
                mina = mina_b = 1e30
                maxa = maxb = -1e30
                for x, y in A:
                    d = x * nx + y * ny
                    if d < mina: mina = d
                    if d > maxa: maxa = d
                for x, y in B:
                    d = x * nx + y * ny
                    if d < mina_b: mina_b = d
                    if d > maxb: maxb = d
                if maxa <= mina_b + 1e-12 or maxb <= mina + 1e-12:
                    return False
        return True

    def valid(cx, cy, ang, s, placed):
        if s <= 0:
            # point must be inside unit square
            if cx < -1e-9 or cx > 1 + 1e-9 or cy < -1e-9 or cy > 1 + 1e-9:
                return False
            return True
        pts = square_corners(cx, cy, ang, s)
        for x, y in pts:
            if x < -1e-8 or x > 1 + 1e-8 or y < -1e-8 or y > 1 + 1e-8:
                return False
        for p in placed:
            if p[3] <= 0:
                continue
            if poly_overlap(pts, square_corners(*p)):
                return False
        return True

    def score(sqs):
        return sum(s[3] for s in sqs)

    # initial: grid packing
    k = math.isqrt(n)
    best = []
    if k > 0:
        side = 1.0 / k
        for i in range(k):
            for j in range(k):
                best.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))

    # local search: try to improve by slightly perturbing / re-packing subsets
    def try_improve(sqs, deadline):
        cur = list(sqs)
        improved = True
        while improved and time.time() < deadline:
            improved = False
            # pick a subset of nonzero squares and attempt to grow/repack
            idxs = [i for i in range(n) if cur[i][3] > 1e-9]
            if not idxs:
                break
            # try growing each square in place
            for i in idxs:
                if time.time() > deadline:
                    break
                cx, cy, ang, s = cur[i]
                others = [cur[j] for j in range(n) if j != i]
                # binary search max size
                lo, hi = s, min(cx, 1 - cx, cy, 1 - cy) * 2.3 + 0.05
                hi = min(hi, 1.5)
                best_s = s
                for _ in range(24):
                    mid = (lo + hi) * 0.5
                    if mid <= s:
                        lo = mid
                        continue
                    if valid(cx, cy, ang, mid, others):
                        best_s = mid
                        lo = mid
                    else:
                        hi = mid
                if best_s > s + 1e-10:
                    cur[i] = (cx, cy, ang, best_s)
                    improved = True
            # try rotation for each square
            for i in idxs:
                if time.time() > deadline:
                    break
                cx, cy, ang, s = cur[i]
                others = [cur[j] for j in range(n) if j != i]
                best_ang = ang
                best_s = s
                for _ in range(20):
                    na = random.random()
                    if not valid(cx, cy, na, s, others):
                        continue
                    lo, hi = s, min(cx, 1 - cx, cy, 1 - cy) * 2.3 + 0.05
                    hi = min(hi, 1.5)
                    bs = s
                    for _ in range(18):
                        mid = (lo + hi) * 0.5
                        if valid(cx, cy, na, mid, others):
                            bs = mid
                            lo = mid
                        else:
                            hi = mid
                    if bs > best_s + 1e-10:
                        best_s = bs
                        best_ang = na
                if best_s > s + 1e-10:
                    cur[i] = (cx, cy, best_ang, best_s)
                    improved = True
            # try moving small squares into gaps, then growing
            for i in idxs:
                if time.time() > deadline:
                    break
                cx, cy, ang, s = cur[i]
                if s > 0.35:
                    continue
                others = [cur[j] for j in range(n) if j != i]
                best_pos = None
                best_val = s
                for _ in range(40):
                    nx = random.random()
                    ny = random.random()
                    na = random.random()
                    if not valid(nx, ny, na, s, others):
                        continue
                    lo, hi = s, min(nx, 1 - nx, ny, 1 - ny) * 2.3 + 0.05
                    hi = min(hi, 1.0)
                    bs = s
                    for _ in range(16):
                        mid = (lo + hi) * 0.5
                        if valid(nx, ny, na, mid, others):
                            bs = mid
                            lo = mid
                        else:
                            hi = mid
                    if bs > best_val + 1e-10:
                        best_val = bs
                        best_pos = (nx, ny, na, bs)
                if best_pos is not None:
                    cur[i] = best_pos
                    improved = True
        return cur

    best = try_improve(best, start + LIMIT * 0.6)

    # final anneal-like random restarts of subsets
    cur = list(best)
    deadline = start + LIMIT
    it = 0
    while time.time() < deadline:
        it += 1
        # pick random subset and shrink then regrow
        idxs = random.sample(range(n), min(n, max(1, n // 4 + 1)))
        trial = list(cur)
        for i in idxs:
            trial[i] = (trial[i][0], trial[i][1], random.random(), 0.0)
        # rebuild greedily: for each zero square, try to insert max size at random spots
        for i in idxs:
            others = [trial[j] for j in range(n) if j != i]
            best_val = 0.0
            best_sq = trial[i]
            for _ in range(30):
                nx = random.random()
                ny = random.random()
                na = random.random()
                lo, hi = 0.0, min(nx, 1 - nx, ny, 1 - ny) * 2.5 + 0.05
                hi = min(hi, 1.2)
                ok = False
                for _ in range(20):
                    mid = (lo + hi) * 0.5
                    if valid(nx, ny, na, mid, others):
                        lo = mid
                        ok = True
                    else:
                        hi = mid
                if ok and lo > best_val + 1e-10:
                    best_val = lo
                    best_sq = (nx, ny, na, lo)
            trial[i] = best_sq
        trial = try_improve(trial, min(deadline, time.time() + 3.0))
        if score(trial) > score(cur) + 1e-12:
            cur = trial
            if score(cur) > score(best):
                best = list(cur)
        if time.time() > deadline:
            break

    # ensure n squares
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    best = best[:n]

    # final clamp
    out = []
    for cx, cy, ang, s in best:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = max(0.0, min(1.0, s))
        out.append((cx, cy, ang, s))
    return out
