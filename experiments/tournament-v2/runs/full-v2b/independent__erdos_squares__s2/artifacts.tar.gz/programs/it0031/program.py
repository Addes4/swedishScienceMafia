import math
import random
import time

TIME_LIMIT = 60.0

# ---------- geometry helpers ----------

def _corners(cx, cy, ang, s):
    """Return 4 corners of a square as (x, y) tuples."""
    h = s * 0.5
    c = math.cos(2.0 * math.pi * ang)
    si = math.sin(2.0 * math.pi * ang)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + c * dx - si * dy
        y = cy + si * dx + c * dy
        pts.append((x, y))
    return pts

def _overlap(pts1, pts2):
    """True if two convex polygons have overlapping interiors."""
    # separating-axis theorem on edges of both polygons
    for poly in (pts1, pts2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ax = -(y2 - y1)
            ay = x2 - x1
            # project both polygons
            min1 = max1 = pts1[0][0] * ax + pts1[0][1] * ay
            for x, y in pts1[1:]:
                v = x * ax + y * ay
                if v < min1:
                    min1 = v
                elif v > max1:
                    max1 = v
            min2 = max2 = pts2[0][0] * ax + pts2[0][1] * ay
            for x, y in pts2[1:]:
                v = x * ax + y * ay
                if v < min2:
                    min2 = v
                elif v > max2:
                    max2 = v
            if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                return False
    return True

def _all_valid(squares):
    """Check all squares inside unit square and pairwise disjoint interiors."""
    boxes = []
    for cx, cy, ang, s in squares:
        if s <= 0.0:
            continue
        if cx < -1e-12 or cx > 1.0 + 1e-12 or cy < -1e-12 or cy > 1.0 + 1e-12:
            return False
        pts = _corners(cx, cy, ang, s)
        for x, y in pts:
            if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
                return False
        boxes.append((pts, s))
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            if _overlap(boxes[i][0], boxes[j][0]):
                return False
    return True

def _score(squares):
    return sum(s[3] for s in squares)

# ---------- constructive starts ----------

def _grid_rows(n, rows):
    """Split unit square into 'rows' horizontal strips, fill each with equal squares."""
    squares = []
    remaining = n
    y = 0.0
    for r in range(rows):
        rows_left = rows - r
        count = remaining // rows_left if rows_left > 0 else 0
        if r == rows - 1:
            count = remaining
        if count <= 0:
            y += 0.0
            remaining -= count
            continue
        height = 1.0 / rows
        # fill row with 'count' squares
        if count == 0:
            continue
        side = min(height, 1.0 / count)
        # adjust side so count squares fit
        side = min(side, 1.0 / count)
        cols = max(1, int(1.0 / side))
        side = min(side, 1.0 / cols)
        side = min(side, height)
        # place them centered
        total_w = count * side
        x0 = (1.0 - total_w) / 2.0
        cy = y + height * 0.5
        for i in range(count):
            cx = x0 + (i + 0.5) * side
            squares.append((cx, cy, 0.0, side))
        y += height
        remaining -= count
    # pad
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]

def _corner_rotate(n):
    """Try one big square and smaller rotated squares in corners or edges."""
    if n <= 0:
        return []
    # baseline grid
    k = math.isqrt(n)
    best = _grid_rows(n, k)
    best_s = _score(best)
    # try a center square of various sizes and rotations
    for big_s in [0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9]:
        # remaining area around it
        trial = [(0.5, 0.5, 0.0, big_s)]
        rem = n - 1
        # place small squares in 4 strips around big square
        gap = (1.0 - big_s) * 0.5
        if gap > 1e-6 and rem > 0:
            # top and bottom strips
            strips = []
            # compute how many can fit in top strip
            for _ in range(rem):
                # approximate: fill side strips
                pass
        # simple fill: remaining squares in 4 corner-ish positions
        for i in range(rem):
            r = i % 4
            if r == 0:
                cx, cy = gap * 0.5, gap * 0.5
            elif r == 1:
                cx, cy = 1.0 - gap * 0.5, gap * 0.5
            elif r == 2:
                cx, cy = gap * 0.5, 1.0 - gap * 0.5
            else:
                cx, cy = 1.0 - gap * 0.5, 1.0 - gap * 0.5
            s = min(gap * 0.95, 0.5)
            trial.append((cx, cy, 0.0, s))
        if len(trial) < n:
            trial += [(0.5, 0.5, 0.0, 0.0)] * (n - len(trial))
        trial = trial[:n]
        if _all_valid(trial):
            sc = _score(trial)
            if sc > best_s:
                best_s = sc
                best = trial
    return best

def _random_start(n):
    """Random non-overlapping placement."""
    squares = []
    if n == 0:
        return squares
    # start with grid rows random
    rows = random.randint(1, max(1, min(n, 5)))
    return _grid_rows(n, rows)

# ---------- local optimization ----------

def _perturb_and_improve(squares, deadline):
    """Try to improve by adjusting sizes/positions/angles."""
    n = len(squares)
    if n == 0:
        return squares
    best = [tuple(s) for s in squares]
    best_score = _score(best)
    cur = [list(s) for s in best]

    step_size = 0.05
    iter_count = 0
    while time.time() < deadline:
        iter_count += 1
        # pick a random square and a random parameter to tweak
        if n == 0:
            break
        idx = random.randrange(n)
        param = random.randrange(4)  # 0=cx, 1=cy, 2=ang, 3=side
        old_val = cur[idx][param]
        # propose
        if param == 3:
            delta = random.gauss(0, step_size * 0.5)
            new_val = max(0.0, old_val + delta)
        elif param == 2:
            delta = random.gauss(0, step_size)
            new_val = (old_val + delta) % 1.0
        else:
            delta = random.gauss(0, step_size)
            new_val = old_val + delta
        cur[idx][param] = new_val
        # clamp center inside [0,1]
        if param in (0, 1):
            cur[idx][param] = min(1.0, max(0.0, cur[idx][param]))

        # check validity
        valid = True
        # check center in range
        for s in cur:
            if s[0] < -1e-9 or s[0] > 1.0 + 1e-9 or s[1] < -1e-9 or s[1] > 1.0 + 1e-9:
                valid = False
                break
            if s[3] < 0:
                valid = False
                break
        if valid:
            # build polygons
            polys = []
            for s in cur:
                if s[3] <= 1e-15:
                    continue
                polys.append(_corners(s[0], s[1], s[2], s[3]))
            # check inside unit square
            for p in polys:
                for x, y in p:
                    if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
                        valid = False
                        break
                if not valid:
                    break
        if valid:
            m = len(polys)
            for i in range(m):
                if not valid:
                    break
                for j in range(i + 1, m):
                    if _overlap(polys[i], polys[j]):
                        valid = False
                        break

        if valid:
            new_score = _score(cur)
            if new_score >= best_score - 1e-12:
                best_score = new_score
                best = [tuple(s) for s in cur]
            else:
                # revert
                cur[idx][param] = old_val
        else:
            # revert
            cur[idx][param] = old_val

        # occasionally reset toward best
        if iter_count % 500 == 0:
            cur = [list(s) for s in best]
            step_size = max(0.001, step_size * 0.999)
            if step_size < 0.002:
                step_size = 0.02

    return best

# ---------- main ----------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    deadline = time.time() + TIME_LIMIT * 0.9
    best = None
    best_score = -1.0

    # Candidate starts
    starts = []

    # 1. grid with sqrt(n) rows
    k = math.isqrt(n)
    starts.append(_grid_rows(n, k))

    # 2. grid with various row counts
    for rows in range(1, min(n, 8) + 1):
        starts.append(_grid_rows(n, rows))

    # 3. corner rotation attempt
    starts.append(_corner_rotate(n))

    # 4. simple 45-degree rotated grid for small n
    if n <= 8:
        s = 1.0 / math.sqrt(2.0 * n) if n > 0 else 0.0
        trial = []
        for i in range(n):
            cx = 0.5
            cy = 0.5
            trial.append((cx, cy, 0.25, s))
        # not valid generally; skip

    # 5. random starts with time remaining
    random.seed(12345 + n)

    # Evaluate starts
    for st in starts:
        st = [tuple(s) for s in st]
        if len(st) < n:
            st = st + [(0.5, 0.5, 0.0, 0.0)] * (n - len(st))
        st = st[:n]
        if _all_valid(st):
            sc = _score(st)
            if sc > best_score:
                best_score = sc
                best = st

    if best is None:
        # fallback baseline
        k = math.isqrt(n)
        side = 1.0 / k
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]
        best_score = _score(best)

    # local search from best
    improved = _perturb_and_improve(best, deadline)
    if improved is not None:
        improved = [tuple(s) for s in improved]
        if len(improved) < n:
            improved += [(0.5, 0.5, 0.0, 0.0)] * (n - len(improved))
        improved = improved[:n]
        if _all_valid(improved):
            sc = _score(improved)
            if sc > best_score:
                best_score = sc
                best = improved

    # multi-start local search if time remains
    attempt = 0
    while time.time() < deadline:
        attempt += 1
        # generate random start
        rows = random.randint(1, max(1, min(n, 6)))
        st = _grid_rows(n, rows)
        # random perturb
        if random.random() < 0.5:
            st = [list(s) for s in st]
            for i in range(n):
                st[i][0] = min(1.0, max(0.0, st[i][0] + random.gauss(0, 0.05)))
                st[i][1] = min(1.0, max(0.0, st[i][1] + random.gauss(0, 0.05)))
                if random.random() < 0.3:
                    st[i][3] = max(0.0, st[i][3] + random.gauss(0, 0.03))
            st = [tuple(s) for s in st]
        if len(st) < n:
            st += [(0.5, 0.5, 0.0, 0.0)] * (n - len(st))
        st = st[:n]
        if _all_valid(st):
            local_deadline = min(deadline, time.time() + 2.0)
            loc = _perturb_and_improve(st, local_deadline)
            if loc is not None:
                loc = [tuple(s) for s in loc]
                if len(loc) < n:
                    loc += [(0.5, 0.5, 0.0, 0.0)] * (n - len(loc))
                loc = loc[:n]
                if _all_valid(loc):
                    sc = _score(loc)
                    if sc > best_score:
                        best_score = sc
                        best = loc

    # final validation and cleanup
    result = []
    for s in best[:n]:
        cx, cy, ang, side = s
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        side = max(0.0, side)
        result.append((cx, cy, ang, side))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
