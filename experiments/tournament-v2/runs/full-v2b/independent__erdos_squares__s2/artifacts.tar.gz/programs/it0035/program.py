import math
import numpy as np
from scipy.optimize import minimize

# ---------- overlap helpers ----------

def _corners(cx, cy, ang, s):
    # ang in fraction of full turn
    th = 2.0 * math.pi * ang
    c = math.cos(th) * (s * 0.5)
    si = math.sin(th) * (s * 0.5)
    return np.array([
        [cx - c + si, cy - si - c],
        [cx + c + si, cy - si + c],
        [cx + c - si, cy + si + c],
        [cx - c - si, cy + si - c],
    ])

def _sat_overlap(sq1, sq2):
    """Return True if interiors overlap (strictly positive area intersection).
    Uses separating axis theorem on the two squares."""
    c1 = _corners(*sq1)
    c2 = _corners(*sq2)
    axes = []
    for poly in (c1, c2):
        for i in range(4):
            e = poly[(i + 1) % 4] - poly[i]
            n = np.array([-e[1], e[0]])
            ln = np.hypot(n[0], n[1])
            if ln > 1e-15:
                axes.append(n / ln)
    for ax in axes:
        p1 = c1 @ ax
        p2 = c2 @ ax
        if p1.max() <= p2.min() + 1e-12 or p2.max() <= p1.min() + 1e-12:
            return False
    return True

def _penalty(x, n):
    """x = [cx, cy, ang, s] * n flattened -> total overlap penalty (sum of penetration depths)."""
    sides = x[3::4]
    if np.any(sides < -1e-9):
        return 1e6
    pen = 0.0
    for i in range(n):
        si = x[4*i:4*i+4]
        for j in range(i+1, n):
            sj = x[4*j:4*j+4]
            if si[3] <= 1e-12 or sj[3] <= 1e-12:
                continue
            if _sat_overlap(tuple(si), tuple(sj)):
                # approximate penetration using minimal corner distance
                ci = _corners(*si); cj = _corners(*sj)
                # min distance between any corners (cheap proxy)
                d = min(np.hypot(a[0]-b[0], a[1]-b[1]) for a in ci for b in cj)
                pen += (min(si[3], sj[3]) - max(d, 0.0)) ** 2 + 1e-6
    return pen

def _bounds(n, pad=0.0):
    b = []
    for _ in range(n):
        b += [(pad, 1.0 - pad), (pad, 1.0 - pad), (0.0, 1.0), (0.0, 1.0)]
    return b

def _to_vec(sqr):
    return np.array([c for s in sqr for c in s], dtype=float)

def _from_vec(x, n):
    return [tuple(x[4*i:4*i+4]) for i in range(n)]

def _in_unit(sq, eps=1e-7):
    cx, cy, ang, s = sq
    if s < -eps:
        return False
    if s <= eps:
        return True
    c = _corners(cx, cy, ang, s)
    return np.all(c >= -eps) and np.all(c <= 1.0 + eps)

def _objective(x, n):
    return -np.sum(x[3::4])

def _inside_violation(x, n):
    pen = 0.0
    for i in range(n):
        if not _in_unit(x[4*i:4*i+4]):
            c = _corners(*x[4*i:4*i+4])
            below = max(0.0, -c.min())
            above = max(0.0, c.max() - 1.0)
            pen += (below + above) ** 2 * 1e3
    return pen

# ---------- initial layouts ----------

def grid_layout(n, kx=None, ky=None):
    if kx is None:
        kx = math.isqrt(n)
        ky = kx
    kx = max(1, min(kx, n))
    ky = max(1, min(ky, (n + kx - 1) // kx))
    cols = kx; rows = ky
    sx = 1.0 / cols; sy = 1.0 / rows
    out = []
    for r in range(rows):
        for c in range(cols):
            if len(out) >= n: break
            out.append(((c + 0.5) * sx, (r + 0.5) * sy, 0.0, min(sx, sy)))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]

def mixed_grid(n):
    """Try square-ish grids and pick one with max total side (all same size)."""
    best = None; bs = -1
    for kx in range(1, int(math.sqrt(n)) + 1):
        ky = (n + kx - 1) // kx
        s = min(1.0/kx, 1.0/ky)
        tot = s * min(kx*ky, n)
        if tot > bs:
            bs = tot; best = (kx, ky)
    kx, ky = best
    return grid_layout(n, kx, ky)

def rotated_strip(n):
    """Alternative: split into strips, rotate squares 45 deg in alternating strips."""
    out = []
    # approximate: use grid but rotate squares alternately by 45 deg
    kx = math.isqrt(n)
    ky = (n + kx - 1) // kx
    sx = 1.0/kx; sy = 1.0/ky
    s = min(sx, sy) * (1.0 / math.sqrt(2)) * 0.98
    for r in range(ky):
        for c in range(kx):
            if len(out) >= n: break
            ang = 0.125 if (r + c) % 2 == 0 else 0.375
            out.append(((c + 0.5) * sx, (r + 0.5) * sy, ang, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]

def random_layout(n, seed=0):
    rng = np.random.default_rng(seed)
    out = []
    for _ in range(n):
        cx = float(rng.uniform(0.0, 1.0))
        cy = float(rng.uniform(0.0, 1.0))
        ang = float(rng.uniform(0.0, 1.0))
        s = float(rng.uniform(0.0, 0.1))
        out.append((cx, cy, ang, s))
    return out

# ---------- local solver ----------

def refine(sqr, n, maxiter=400, allow_rotation=True):
    x0 = _to_vec(sqr)
    def f(x):
        p = _objective(x, n)
        p += _inside_violation(x, n) * 1.0
        p += _penalty(x, n) * 50.0
        return p
    bnds = _bounds(n)
    try:
        res = minimize(f, x0, method='SLSQP', bounds=bnds,
                       options={'maxiter': maxiter, 'ftol': 1e-12, 'disp': False})
        x = res.x
    except Exception:
        x = x0
    # clean up: clamp to bounds, remove tiny
    x = np.clip(x, 0.0, 1.0)
    x[3::4] = np.maximum(x[3::4], 0.0)
    return _from_vec(x, n)

# ---------- main ----------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    candidates = []
    candidates.append(mixed_grid(n))
    candidates.append(grid_layout(n, math.isqrt(n), math.isqrt(n)))
    if n >= 4:
        candidates.append(rotated_strip(n))
    for s in range(3):
        candidates.append(random_layout(n, seed=s * 123 + n))

    best = None
    best_score = -1.0
    for cand in candidates:
        # quick feasibility check first
        feasible = all(_in_unit(sq) for sq in cand if sq[3] > 1e-9)
        # refine
        try:
            ref = refine(cand, n)
        except Exception:
            ref = cand
        score = sum(max(0.0, sq[3]) for sq in ref)
        # ensure feasibility: if not, reduce sizes
        if not all(_in_unit(sq) for sq in ref if sq[3] > 1e-9):
            ref2 = [list(sq) for sq in ref]
            for sq in ref2:
                sq[3] *= 0.95
            ref = [tuple(sq) for sq in ref2]
            score = sum(sq[3] for sq in ref)
        if score > best_score:
            best_score = score
            best = ref

    # final polish: try again on best with more iterations
    if best is not None:
        try:
            ref = refine(best, n, maxiter=600)
            sc = sum(sq[3] for sq in ref)
            if sc > best_score:
                best = ref
                best_score = sc
        except Exception:
            pass

    # guarantee feasibility
    out = []
    for sq in best:
        cx, cy, ang, s = sq
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = max(0.0, min(s, 1.0))
        out.append((cx, cy, ang, s))
    # if any overlaps remain, shrink offending later squares
    for iter_ in range(20):
        ok = True
        for i in range(n):
            if out[i][3] <= 1e-12: continue
            if not _in_unit(out[i]):
                ok = False
                out[i] = (0.5, 0.5, 0.0, 0.0)
                continue
            for j in range(i+1, n):
                if out[j][3] <= 1e-12: continue
                if _sat_overlap(out[i], out[j]):
                    ok = False
                    # shrink larger
                    i_s = out[i][3]; j_s = out[j][3]
                    if i_s >= j_s:
                        out[i] = (out[i][0], out[i][1], out[i][2], i_s * 0.95)
                    else:
                        out[j] = (out[j][0], out[j][1], out[j][2], j_s * 0.95)
        if ok:
            break

    return out[:n]
