import math
import random

RNGSEED = 12345
EPS = 1e-12


def _overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Return True if two squares (centres, angle in turns, side) have overlapping interiors."""
    if s1 <= 0.0 or s2 <= 0.0:
        return False
    h1 = 0.5 * s1
    h2 = 0.5 * s2
    t1 = a1 * (2.0 * math.pi)
    t2 = a2 * (2.0 * math.pi)
    c1, s1r = math.cos(t1), math.sin(t1)
    c2, s2r = math.cos(t2), math.sin(t2)

    # axes: x, y, axis1, axis2
    axes = [(1.0, 0.0), (0.0, 1.0), (c1, s1r), (c2, s2r)]
    dx = cx2 - cx1
    dy = cy2 - cy1
    for ax, ay in axes:
        r1 = h1 * (abs((c1 * ax + s1r * ay)) + abs((-s1r * ax + c1 * ay)))
        r2 = h2 * (abs((c2 * ax + s2r * ay)) + abs((-s2r * ax + c2 * ay)))
        proj = abs(dx * ax + dy * ay)
        if proj >= r1 + r2 - 1e-12:
            return False
    return True


def _inside(cx, cy, angle, side):
    """Check square fully inside unit square."""
    if side <= 0.0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    h = 0.5 * side
    t = angle * 2.0 * math.pi
    c, s = math.cos(t), math.sin(t)
    # corners
    ex = h * (abs(c) + abs(s))
    ey = h * (abs(s) + abs(c))
    return (cx - ex >= -1e-9 and cx + ex <= 1.0 + 1e-9 and
            cy - ey >= -1e-9 and cy + ey <= 1.0 + 1e-9)


def _feasible(sqs):
    m = len(sqs)
    for i in range(m):
        cx, cy, a, s = sqs[i]
        if not _inside(cx, cy, a, s):
            return False
    for i in range(m):
        for j in range(i + 1, m):
            if _overlap(sqs[i][0], sqs[i][1], sqs[i][2], sqs[i][3],
                        sqs[j][0], sqs[j][1], sqs[j][2], sqs[j][3]):
                return False
    return True


def _total(sqs):
    return sum(s[3] for s in sqs)


def _greedy_pack(n, rng):
    """Construct packing by inserting squares one at a time."""
    sqs = []
    # try largest side first; start from a grid-ish guess
    # candidate side values
    if n <= 1:
        cands = [1.0]
    else:
        cands = []
        base = 1.0 / math.sqrt(n) if n > 0 else 1.0
        for k in range(60):
            f = 1.0 - k * 0.015
            if f <= 0.05:
                break
            cands.append(base * f / 0.6)
        cands = sorted(set(round(c, 6) for c in cands if 0.0 < c <= 1.0), reverse=True)

    for i in range(n):
        placed = False
        # try decreasing sizes with random positions/angles
        for trial in range(4000):
            if trial < len(cands):
                side = cands[trial]
            else:
                side = cands[-1] if cands else 0.01
            side *= (0.97 ** max(0, trial - len(cands)))
            if side <= 1e-6:
                side = 1e-6
            a = rng.random()
            # sample feasible centre region
            h = 0.5 * side
            t = a * 2.0 * math.pi
            ex = h * (abs(math.cos(t)) + abs(math.sin(t)))
            ey = h * (abs(math.sin(t)) + abs(math.cos(t)))
            if ex > 0.5 or ey > 0.5:
                continue
            cx = ex + rng.random() * (1.0 - 2.0 * ex)
            cy = ey + rng.random() * (1.0 - 2.0 * ey)
            ok = True
            for (qx, qy, qa, qs) in sqs:
                if _overlap(cx, cy, a, side, qx, qy, qa, qs):
                    ok = False
                    break
            if ok:
                sqs.append((cx, cy, a, side))
                placed = True
                break
        if not placed:
            sqs.append((0.5, 0.5, 0.0, 0.0))
    return sqs


def _improve(sqs, time_budget, rng):
    """Local search: perturb a square's position/angle/size, accept if improvement."""
    best = list(sqs)
    best_val = _total(best)
    m = len(best)
    if m == 0:
        return best
    steps = 0
    while steps < time_budget:
        steps += 1
        idx = rng.randrange(m)
        cx, cy, a, s = best[idx]
        old = best[idx]
        # perturb
        scale = 0.05
        new_s = s
        r = rng.random()
        if r < 0.4:
            new_s = min(1.0, max(0.0, s + rng.uniform(-scale, scale) * (0.2 + s)))
        elif r < 0.7:
            new_s = min(1.0, max(0.0, s * rng.uniform(0.9, 1.15)))
        new_cx = min(1.0, max(0.0, cx + rng.uniform(-scale, scale)))
        new_cy = min(1.0, max(0.0, cy + rng.uniform(-scale, scale)))
        new_a = (a + rng.uniform(-scale, scale)) % 1.0

        cand = (new_cx, new_cy, new_a, new_s)
        best[idx] = cand
        if _feasible(best):
            newv = _total(best)
            if newv >= best_val - 1e-12:
                best_val = newv
                continue
        best[idx] = old
    return best


def solve(n):
    if n <= 0:
        return []
    rng = random.Random(RNGSEED + n * 100003)
    best_sqs = None
    best_val = -1.0

    # multiple random restarts
    restarts = 3 if n <= 20 else 2
    for _ in range(restarts):
        sqs = _greedy_pack(n, rng)
        sqs = _improve(sqs, 1200 if n <= 30 else 800, rng)
        v = _total(sqs)
        if v > best_val:
            best_val = v
            best_sqs = sqs

    # fallback grid
    if best_sqs is None or not _feasible(best_sqs):
        k = math.isqrt(n)
        side = 1.0 / k
        best_sqs = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                    for i in range(k) for j in range(k)]
        best_sqs += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sqs))
        best_sqs = best_sqs[:n]

    out = []
    for cx, cy, a, s in best_sqs[:n]:
        out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)),
                    min(1.0, max(0.0, a)), max(0.0, min(1.0, s))))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
