# EVOLVE-BLOCK-START
"""Squares in a square: maximise sum of side lengths.

Approach:
  * build a strong initial packing using exact/structured layouts
    (grids, side strips, corner/centre patterns, rotated variants);
  * improve it by local search: repeatedly try moving/resizing each square
    while preserving interior-disjointness.
"""
import math
import random


# ----------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------
def _overlap(sq1, sq2, eps=1e-10):
    """Return True if two squares overlap in their interiors.

    Squares are represented as (cx, cy, angle, side).  Angle is a fraction
    of a full turn.  Fast enough for the sizes used here.
    """
    x1, y1, a1, s1 = sq1
    x2, y2, a2, s2 = sq2
    if s1 <= 0.0 or s2 <= 0.0:
        return False
    if s1 > 1.0 or s2 > 1.0:
        return True

    # separating axis test for two squares
    t1 = a1 * 2.0 * math.pi
    t2 = a2 * 2.0 * math.pi
    c1, s_1 = math.cos(t1), math.sin(t1)
    c2, s_2 = math.cos(t2), math.sin(t2)

    # axes:  x, y, and the two normals of square 1 and square 2
    axes = [(1.0, 0.0), (0.0, 1.0),
            (c1, s_1), (-s_1, c1),
            (c2, s_2), (-s_2, c2)]

    # half-extents of centre projection for each square along each axis
    h1 = s1 * 0.5
    h2 = s2 * 0.5

    dx = x2 - x1
    dy = y2 - y1

    for ax, ay in axes:
        d = abs(dx * ax + dy * ay)
        r1 = h1 * (abs(c1 * ax + s_1 * ay) + abs(-s_1 * ax + c1 * ay))
        r2 = h2 * (abs(c2 * ax + s_2 * ay) + abs(-s_2 * ax + c2 * ay))
        if d > r1 + r2 + eps:
            return False
    return True


def _inside(sq, eps=1e-10):
    """Check square is inside [0,1]^2."""
    x, y, a, s = sq
    if s <= 0.0:
        return True
    if s > 1.0 + eps:
        return False
    t = a * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    # four corners
    corners = [
        (x + h * (c - sn), y + h * (sn + c)),
        (x + h * (c + sn), y + h * (sn - c)),
        (x - h * (c + sn), y - h * (sn - c)),
        (x - h * (c - sn), y - h * (sn + c)),
    ]
    for px, py in corners:
        if px < -eps or px > 1.0 + eps or py < -eps or py > 1.0 + eps:
            return False
    return True


def _total(squares):
    return sum(max(0.0, sq[3]) for sq in squares)


def _is_valid(squares):
    """Check all squares inside and pairwise disjoint."""
    for sq in squares:
        if not _inside(sq):
            return False
    for i in range(len(squares)):
        for j in range(i + 1, len(squares)):
            if _overlap(squares[i], squares[j]):
                return False
    return True


# ----------------------------------------------------------------------
# structural initial layouts
# ----------------------------------------------------------------------
def _grid_layout(n):
    """Largest k x k grid, then fill remaining as tiny squares in gaps."""
    k = math.isqrt(n)
    s = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    rem = n - k * k
    if rem > 0 and k > 0:
        # put remaining in top strip in a row
        strip_h = 1.0 - k * s
        if strip_h < 1e-12:
            strip_h = 1e-6
        w = 1.0 / rem
        h = min(strip_h, 1.0)
        for i in range(rem):
            cx = (i + 0.5) * w
            cy = k * s + h * 0.5
            # ensure inside
            cy = max(h * 0.5, min(1.0 - h * 0.5, cy))
            res.append((cx, cy, 0.0, h))
        # shrink if needed
        res = _fix_inside(res)
    return _pad(res, n)


def _strip_layout(n):
    """Place squares in horizontal rows that fill the width."""
    # choose number of rows r, distribute n squares evenly
    best = None
    for r in range(1, n + 1):
        if r > 50:
            break
        # try to pack n squares into r rows roughly equally
        counts = [n // r] * r
        for i in range(n % r):
            counts[i] += 1
        sizes = []
        for c in counts:
            if c == 0:
                sizes.append([0.0])
                continue
            # row width = 1, each square side <= 1/c
            s = min(1.0 / c, 1.0 / r)
            sizes.append(s)
        total = sum(s for s in sizes)
        if best is None or total > best[0]:
            best = (total, r, counts, sizes)
    if best is None:
        return _grid_layout(n)
    _, r, counts, sizes = best
    res = []
    y0 = 0.0
    row_h = 1.0 / r
    for i in range(r):
        c = counts[i]
        if c == 0:
            continue
        sh = min(row_h, sizes[i])
        # place c squares centered in row
        y = y0 + sh * 0.5
        if c == 1:
            xs = [0.5]
        else:
            xs = [(j + 0.5) / c for j in range(c)]
        for x in xs:
            res.append((x, y, 0.0, sh))
        y0 += row_h
    res = _fix_inside(res)
    return _pad(res, n)


def _grid_plus_rotated(n):
    """Grid plus some rotated squares in the top gap."""
    k = math.isqrt(n)
    if k * k == n:
        return _grid_layout(n)
    s = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    rem = n - k * k
    strip_h = 1.0 - k * s
    if strip_h <= 1e-9:
        return _pad(res, n)
    w = 1.0 / rem
    h = min(strip_h, w * 0.7071067811865476)
    for i in range(rem):
        cx = (i + 0.5) * w
        cy = k * s + h * 0.5
        cy = max(h * 0.5, min(1.0 - h * 0.5, cy))
        res.append((cx, cy, 0.125, h))
    res = _fix_inside(res)
    return _pad(res, n)


def _pad(res, n):
    """Pad to exactly n squares with zero-size squares."""
    res = list(res[:n])
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res


def _fix_inside(res):
    """Make every square inside [0,1]^2, shrinking as needed."""
    out = []
    for x, y, a, s in res:
        if s <= 0.0:
            out.append((x, y, a, 0.0))
            continue
        s = min(s, 1.0)
        t = a * 2.0 * math.pi
        c, sn = math.cos(t), math.sin(t)
        # half extent in x and y
        ex = s * 0.5 * (abs(c) + abs(sn))
        ey = s * 0.5 * (abs(sn) + abs(c))
        x = max(ex, min(1.0 - ex, x))
        y = max(ey, min(1.0 - ey, y))
        # if ex > 0.5 shrink
        if ex > 0.5 or ey > 0.5:
            scale = min(0.5 / ex if ex > 0 else 1.0, 0.5 / ey if ey > 0 else 1.0)
            s *= scale * 0.999999
            out.append((0.5, 0.5, a, s))
        else:
            out.append((x, y, a, s))
    return out


# ----------------------------------------------------------------------
# local improvement
# ----------------------------------------------------------------------
def _local_search(squares, time_budget=8.0):
    """Coordinate descent with random moves, keeping disjointness."""
    import time
    random.seed(12345)
    best = [list(sq) for sq in squares]
    best_score = _total(best)
    start = time.time()
    n = len(best)

    def try_accept(candidate):
        nonlocal best, best_score
        if not _is_valid(candidate):
            return False
        sc = _total(candidate)
        if sc > best_score + 1e-12:
            best = [list(sq) for sq in candidate]
            best_score = sc
            return True
        return False

    # order of indices, with shrinking radii
    radii = [0.25, 0.12, 0.06, 0.03, 0.015, 0.008, 0.004, 0.002]
    for rad in radii:
        if time.time() - start > time_budget:
            break
        improved = True
        while improved and time.time() - start < time_budget:
            improved = False
            order = list(range(n))
            random.shuffle(order)
            for idx in order:
                if time.time() - start > time_budget:
                    break
                sq = best[idx]
                old = list(sq)
                # try several random perturbations
                for _ in range(6):
                    cand = [list(s) for s in best]
                    dx = random.uniform(-rad, rad)
                    dy = random.uniform(-rad, rad)
                    ds = random.uniform(-rad * 0.5, rad * 0.5)
                    da = random.uniform(-0.25, 0.25)
                    nx = old[0] + dx
                    ny = old[1] + dy
                    ns = max(0.0, old[3] + ds)
                    na = (old[2] + da) % 1.0
                    if ns > 1.0:
                        ns = 1.0
                    cand[idx] = [nx, ny, na, ns]
                    # fix inside
                    cand = _fix_inside(cand)
                    if try_accept(cand):
                        improved = True
                        break
    return best


# ----------------------------------------------------------------------
# public solve
# ----------------------------------------------------------------------
_CACHE = {}


def solve(n):
    """Return a list of n squares (cx, cy, angle, side) inside the unit
    square with disjoint interiors, maximising the sum of side lengths."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n in _CACHE:
        return [tuple(s) for s in _CACHE[n]]

    candidates = []
    candidates.append(_grid_layout(n))
    candidates.append(_strip_layout(n))
    candidates.append(_grid_plus_rotated(n))

    # a few deterministic variations
    random.seed(9876 + n)
    base = _grid_layout(n)
    for _ in range(3):
        cand = [list(s) for s in base]
        for k in range(n):
            if random.random() < 0.3:
                cand[k][0] += random.uniform(-0.02, 0.02)
                cand[k][1] += random.uniform(-0.02, 0.02)
                cand[k][2] = random.choice([0.0, 0.125, 0.25, 0.375, 0.5])
        cand = _fix_inside(cand)
        candidates.append(cand)

    best = None
    best_score = -1.0
    for cand in candidates:
        if not _is_valid(cand):
            cand = _fix_inside(cand)
            if not _is_valid(cand):
                # fall back to tiny zero-size
                cand = [(0.5, 0.5, 0.0, 0.0)] * n
        sc = _total(cand)
        if sc > best_score:
            best_score = sc
            best = cand

    # local search from the best few candidates
    scored = sorted([( _total(c), c) for c in candidates], key=lambda t: -t[0])
    time_per = 45.0 / max(1, len(scored))
    for _, cand in scored[:3]:
        improved = _local_search(cand, time_budget=min(20.0, time_per))
        sc = _total(improved)
        if sc > best_score:
            best_score = sc
            best = improved

    result = [tuple(s) for s in best]
    _CACHE[n] = result
    return result
# EVOLVE-BLOCK-END
