import math
import random
import numpy as np


# ---------- geometry helpers ----------

def _corners(cx, cy, ang, s):
    """Return 4 corners of square with center (cx,cy), angle fraction (0..1), side s."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _overlap_area(sq1, sq2, eps=1e-12):
    """Return True if interiors of two squares overlap (approx via separating axis).
    Squares are (cx,cy,ang,side)."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= eps or s2 <= eps:
        return False
    # SAT for two convex polygons
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)
    for poly, other in ((p1, p2), (p2, p1)):
        for i in range(4):
            ax = poly[(i + 1) % 4][0] - poly[i][0]
            ay = poly[(i + 1) % 4][1] - poly[i][1]
            # normal
            nx, ny = -ay, ax
            # project other
            o_vals = [nx * p[0] + ny * p[1] for p in other]
            p_vals = [nx * p[0] + ny * p[1] for p in poly]
            if max(p_vals) <= min(o_vals) + 1e-9 or max(o_vals) <= min(p_vals) + 1e-9:
                return False  # separated
    return True


def _inside_unit(sq, eps=1e-9):
    cx, cy, ang, s = sq
    if s <= 0:
        return True
    for x, y in _corners(cx, cy, ang, s):
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


# ---------- constructive heuristic ----------

def _construct(n):
    if n == 0:
        return []
    if n == 1:
        # a single square of side 1 centered, angle 0
        return [(0.5, 0.5, 0.0, 1.0)]

    # Try a grid with some rotated edge squares to fill gaps.
    # Strategy: choose grid k x k (plus remaining squares placed in leftover
    # strips at the borders as large as possible, possibly rotated 45 deg).
    best = None
    best_score = -1.0
    max_k = int(math.isqrt(n))
    candidates = []
    for k in range(max(1, max_k - 3), max_k + 1):
        if k * k > n:
            continue
        candidates.append(k)
    # also try k such that k*k + a few
    for k in candidates:
        base = k * k
        rem = n - base
        # Try filling remaining into side strips: put some squares along bottom/top
        # Simple approach: place k*k grid of size 1/k. Remaining squares go into
        # the last row/col as extra cells? Instead, use a (k+1) x k scheme partially.
        # Better: use k columns, distribute rows unevenly. We'll just do grid and
        # then add small squares in leftover gaps (there are none in exact grid).
        # Alternative: use a k x k grid but shrink to allow a border, then fill
        # border with squares.
        sqs = []
        s = 1.0 / k
        for i in range(k):
            for j in range(k):
                sqs.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        sqs = sqs[:n]
        # measure
        sc = sum(q[3] for q in sqs)
        if sc > best_score:
            best_score = sc
            best = sqs

    # Try: leave a border of width w, grid inside of size 1-2w, and place
    # remaining squares in the border strips as large as possible.
    # For rem squares, we can put them along one strip.
    for k in range(1, min(8, n) + 1):
        if k * k > n:
            continue
        rem = n - k * k
        # Need to fit rem squares in strips while grid occupies kxk.
        # Use grid of side g in center, leaving border w = (1-g)/2.
        # In vertical strip of width w and height 1, we can fit floor(rem/2) ... 
        # Simplest: distribute rem among 4 strips of width w.
        # Each strip can host squares of side up to w. If rem squares placed in
        # one strip of width w and height 1, side = min(w, 1/rem_side_count).
        # Let's try placing all rem squares in a single strip (bottom), each side = min(w, 1/rem).
        # We'll optimize w by trying a few values.
        for w in [0.0, 0.02, 0.05, 0.08, 0.1, 0.12, 0.15, 0.2]:
            g = 1.0 - 2 * w
            if g <= 0:
                continue
            s = g / k
            if s <= 0:
                continue
            sqs = []
            for i in range(k):
                for j in range(k):
                    sqs.append((w + (i + 0.5) * s, w + (j + 0.5) * s, 0.0, s))
            # place rem squares in bottom strip (below grid)
            if rem > 0 and w > 1e-6:
                # bottom strip: y in [0, w], x in [0,1]
                # place rem squares side = min(w, 1.0/rem) along x
                ss = min(w, 1.0 / rem)
                for r in range(rem):
                    sqs.append(((r + 0.5) * ss, w * 0.5, 0.0, ss))
            # maybe not enough space; check
            ok = True
            for sq in sqs:
                if not _inside_unit(sq):
                    ok = False
                    break
            if not ok:
                continue
            # check overlaps
            bad = False
            m = len(sqs)
            for i in range(m):
                for j in range(i + 1, m):
                    if _overlap_area(sqs[i], sqs[j]):
                        bad = True
                        break
                if bad:
                    break
            if bad:
                continue
            sc = sum(q[3] for q in sqs)
            if sc > best_score:
                best_score = sc
                best = sqs[:]

    # Try known good patterns for small n:
    if n == 2:
        # two squares side by side, each side 0.5 -> sum 1.0
        best = [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    elif n == 3:
        # three squares: one big 0.5x0.5 and two 0.25? Actually best known is
        # 0.5 + 0.25 + 0.25? Let's just do 1 big and 2 small.
        # Known optimum for n=3 is sqrt(2)/2 + ...? Not sure; use 0.5,0.5,0.5? Not possible.
        # Use: one square side 0.5, two squares side 0.25? Total 1.0
        # Actually better: 0.5 + 0.25 + 0.25 = 1.0
        best = [(0.25, 0.75, 0.0, 0.5), (0.75, 0.125, 0.0, 0.25), (0.75, 0.375, 0.0, 0.25)]
        # Hmm, this may overlap. Let's use a safer config: 1 square 0.5, 2 squares 0.25 placed
        # in the right strip.
        best = [(0.25, 0.5, 0.0, 0.5),
                (0.75, 0.125, 0.0, 0.25),
                (0.75, 0.375, 0.0, 0.25)]
        # check right strip: x in [0.5,1], width 0.5, two squares of 0.25 stacked -> fine.
    elif n == 5:
        # Known good: four squares of 0.5? that's n=4 sum 2. For n=5, maybe
        # 0.5+0.5+0.5+0.5+? Can't fit 4 of 0.5 plus another. Use 3x3 grid with
        # extra? Just use heuristic.
        pass

    # If nothing good, default grid
    if best is None or len(best) != n:
        k = math.isqrt(n)
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]
    return best


# ---------- local refinement ----------

def _refine(sqs, iterations=200, time_budget=None):
    """Try to increase each side length while keeping disjoint/inside."""
    import time
    start = time.time()
    n = len(sqs)
    sqs = [list(q) for q in sqs]
    # random order passes
    order = list(range(n))
    best_score = sum(q[3] for q in sqs)
    improved = True
    it = 0
    while improved and it < iterations:
        improved = False
        it += 1
        random.shuffle(order)
        for idx in order:
            if time_budget and time.time() - start > time_budget:
                break
            cx, cy, ang, s = sqs[idx]
            # try increasing s
            # maximum possible: limited by neighbors and boundary
            # binary search or incremental
            lo, hi = s, 2.0
            # quick upper bound: max half distance to boundary
            # find max s that keeps inside and no overlap
            best_s = s
            # try a few step sizes
            for trial in range(30):
                mid = (lo + hi) * 0.5
                cand = (cx, cy, ang, mid)
                if not _inside_unit(cand):
                    hi = mid
                    continue
                ok = True
                for j in range(n):
                    if j == idx:
                        continue
                    if _overlap_area(cand, sqs[j]):
                        ok = False
                        break
                if ok:
                    lo = mid
                    best_s = mid
                else:
                    hi = mid
            if best_s > s + 1e-9:
                sqs[idx][3] = best_s
                improved = True
        # also try small center/angle perturbations occasionally
        if it % 5 == 0:
            for idx in range(n):
                if time_budget and time.time() - start > time_budget:
                    break
                cx, cy, ang, s = sqs[idx]
                # try moving slightly
                for _ in range(3):
                    ncx = cx + random.uniform(-0.01, 0.01)
                    ncy = cy + random.uniform(-0.01, 0.01)
                    nang = ang + random.uniform(-0.02, 0.02)
                    cand = (ncx, ncy, nang, s)
                    if not _inside_unit(cand):
                        continue
                    ok = True
                    for j in range(n):
                        if j == idx:
                            continue
                        if _overlap_area(cand, sqs[j]):
                            ok = False
                            break
                    if ok:
                        # check if can increase size
                        lo2, hi2 = s, 2.0
                        bs = s
                        for _t in range(20):
                            mid = (lo2 + hi2) * 0.5
                            cand2 = (ncx, ncy, nang, mid)
                            if not _inside_unit(cand2):
                                hi2 = mid
                                continue
                            ok2 = True
                            for j in range(n):
                                if j == idx:
                                    continue
                                if _overlap_area(cand2, sqs[j]):
                                    ok2 = False
                                    break
                            if ok2:
                                lo2 = mid
                                bs = mid
                            else:
                                hi2 = mid
                        if bs > s + 1e-9:
                            sqs[idx] = [ncx, ncy, nang, bs]
                            improved = True
                            break
    return [tuple(q) for q in sqs]


# ---------- main solve ----------

def solve(n):
    if n <= 0:
        return []
    sqs = _construct(n)
    # refine for small n where it helps and time allows
    if n <= 30:
        try:
            sqs = _refine(sqs, iterations=300, time_budget=8.0)
        except Exception:
            pass
    # ensure exactly n
    sqs = list(sqs)
    while len(sqs) < n:
        sqs.append((0.5, 0.5, 0.0, 0.0))
    sqs = sqs[:n]
    # clamp all values to [0,1] as required
    out = []
    for cx, cy, ang, s in sqs:
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = max(0.0, min(1.0, ang))
        s = max(0.0, min(1.0, s))
        out.append((cx, cy, ang, s))
    return out
