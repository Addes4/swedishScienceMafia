import math
import numpy as np
from scipy.optimize import minimize


def _sat_constraints(sq, i, j):
    """Return minimum separation distance between squares i and j (positive = disjoint)."""
    ci, si = sq[i][:2], sq[i][3]
    cj, sj = sq[j][:2], sq[j][3]
    ai, aj = sq[i][2] * 2 * math.pi, sq[j][2] * 2 * math.pi
    # half extents along local axes
    hi = si / 2.0
    hj = sj / 2.0
    # separating axes: the 4 local axes
    axes = []
    for a in (ai, aj):
        axes.append((math.cos(a), math.sin(a)))
        axes.append((-math.sin(a), math.cos(a)))
    d = (cj[0] - ci[0], cj[1] - ci[1])
    best = -1e18
    for ax in axes:
        proj_i = hi * (abs(ax[0] * math.cos(ai) + ax[1] * math.sin(ai)) +
                       abs(ax[0] * (-math.sin(ai)) + ax[1] * math.cos(ai)))
        proj_j = hj * (abs(ax[0] * math.cos(aj) + ax[1] * math.sin(aj)) +
                       abs(ax[0] * (-math.sin(aj)) + ax[1] * math.cos(aj)))
        dist = abs(ax[0] * d[0] + ax[1] * d[1])
        gap = dist - (proj_i + proj_j)
        if gap > best:
            best = gap
    return best


def _build_layout(n, m, layout='v'):
    """Build initial layout with m x m grid plus n-m^2 extra in a strip."""
    squares = []
    extra = n - m * m
    if m == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    if extra == 0:
        s = 1.0 / m
        for i in range(m):
            for j in range(m):
                squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        return squares

    # grid size reduced to make room for strip
    # try to fit grid in fraction f, strip in 1-f
    best = None
    best_sum = -1

    for f in np.linspace(0.3, 0.95, 14):
        gs = f / m  # grid side
        if gs <= 0:
            continue
        rem = 1.0 - f  # strip width/height
        # try to fit extra squares in strip of dimension (rem, 1)
        if layout == 'v':
            # vertical strip on right of width rem
            strip_w, strip_h = rem, 1.0
        elif layout == 'h':
            strip_w, strip_h = 1.0, rem
        else:
            strip_w, strip_h = rem, rem

        # packing extra unit squares (rotated or axis-aligned) in strip
        # simple: arrange in rows/cols
        if extra > 0 and strip_w > 0 and strip_h > 0:
            # try to pack axis-aligned squares of side ss
            # find best ss such that ceil(extra / floor(strip_h/ss)) boxes fit
            ss = min(strip_w, strip_h)
            # binary search on ss
            lo, hi = 0.0, min(strip_w, strip_h)
            for _ in range(40):
                mid = (lo + hi) / 2
                ncols = int(strip_w / mid) if mid > 0 else 0
                nrows = int(strip_h / mid) if mid > 0 else 0
                if ncols * nrows >= extra and mid > 0:
                    lo = mid
                else:
                    hi = mid
            ss = lo
            if ss <= 1e-12:
                ss = 0.0

            cur = []
            s = gs
            if layout == 'v':
                for i in range(m):
                    for j in range(m):
                        cur.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                ox = f
                nrows = max(1, int(strip_h / ss)) if ss > 0 else 1
                ncols = max(1, int(strip_w / ss)) if ss > 0 else 1
                cnt = 0
                for jj in range(nrows):
                    for ii in range(ncols):
                        if cnt >= extra:
                            break
                        cx = ox + (ii + 0.5) * ss
                        cy = (jj + 0.5) * ss
                        cur.append((cx, cy, 0.0, ss))
                        cnt += 1
                    if cnt >= extra:
                        break
                while len(cur) < n:
                    cur.append((0.5, 0.5, 0.0, 0.0))
            elif layout == 'h':
                for i in range(m):
                    for j in range(m):
                        cur.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                oy = f
                nrows = max(1, int(strip_h / ss)) if ss > 0 else 1
                ncols = max(1, int(strip_w / ss)) if ss > 0 else 1
                cnt = 0
                for jj in range(nrows):
                    for ii in range(ncols):
                        if cnt >= extra:
                            break
                        cx = (ii + 0.5) * ss
                        cy = oy + (jj + 0.5) * ss
                        cur.append((cx, cy, 0.0, ss))
                        cnt += 1
                    if cnt >= extra:
                        break
                while len(cur) < n:
                    cur.append((0.5, 0.5, 0.0, 0.0))
            else:
                # corner block
                for i in range(m):
                    for j in range(m):
                        cur.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                cnt = 0
                for jj in range(nrows):
                    for ii in range(ncols):
                        if cnt >= extra:
                            break
                        cx = f + (ii + 0.5) * ss
                        cy = f + (jj + 0.5) * ss
                        cur.append((cx, cy, 0.0, ss))
                        cnt += 1
                    if cnt >= extra:
                        break
                while len(cur) < n:
                    cur.append((0.5, 0.5, 0.0, 0.0))

            total = sum(sq[3] for sq in cur[:n])
            if total > best_sum:
                best_sum = total
                best = cur[:n]

    if best is None:
        s = 1.0 / m
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(m) for j in range(m)]
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))
        best = best[:n]
    return best


def _refine(squares, time_budget=8.0):
    """Local optimization on positions, angles, sides."""
    n = len(squares)
    if n == 0:
        return squares
    # variables: for each square: cx, cy, angle, side
    # but keep side nonneg. Use unconstrained side, clamp.
    x0 = []
    for (cx, cy, ang, s) in squares:
        x0.append(cx)
        x0.append(cy)
        x0.append(ang)
        x0.append(s)
    x0 = np.array(x0)

    def unpack(x):
        sq = []
        for i in range(n):
            cx, cy, ang, s = x[4*i:4*i+4]
            samp = max(0.0, s)
            sq.append((cx, cy, ang, samp))
        return sq

    def objective(x):
        sq = unpack(x)
        return -sum(sq[i][3] for i in range(n))

    cons = []
    # boundary constraints: square inside [0,1]^2
    # Use half-extent along x/y
    for i in range(n):
        def make_bound(i, sign):
            def f(x):
                cx, cy, ang, s = x[4*i:4*i+4]
                s = max(0.0, s)
                h = s / 2.0
                a = ang * 2 * math.pi
                # extent in x: h*|cos a| + h*|sin a|
                ex = h * (abs(math.cos(a)) + abs(math.sin(a)))
                ey = h * (abs(math.cos(a)) + abs(math.sin(a)))
                if sign == 0:
                    return cx - ex  # >= 0
                elif sign == 1:
                    return 1.0 - cx - ex  # >= 0
                elif sign == 2:
                    return cy - ey  # >= 0
                else:
                    return 1.0 - cy - ey  # >= 0
            return f
        for sign in range(4):
            cons.append({'type': 'ineq', 'fun': make_bound(i, sign)})

    # non-overlap constraints
    for i in range(n):
        for j in range(i+1, n):
            def make_sep(i, j):
                def f(x):
                    sq = unpack(x)
                    return _sat_constraints(sq, i, j)
                return f
            cons.append({'type': 'ineq', 'fun': make_sep(i, j)})

    # bounds
    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))  # cx
        bounds.append((0.0, 1.0))  # cy
        bounds.append((-10.0, 10.0))  # angle
        bounds.append((0.0, 1.0))  # side

    # initial feasible-ish?
    try:
        res = minimize(objective, x0, method='SLSQP', bounds=bounds,
                       constraints=cons, options={'maxiter': 400, 'ftol': 1e-12})
        sq = unpack(res.x)
    except Exception:
        sq = squares

    # post-process: try to scale all up if feasible
    # compute min gap among all pairs and boundary
    def feasibility_scale(sq, scale):
        newsq = [(cx, cy, ang, s*scale) for (cx, cy, ang, s) in sq]
        for i in range(n):
            cx, cy, ang, s = newsq[i]
            h = s/2.0
            a = ang * 2 * math.pi
            ex = h*(abs(math.cos(a))+abs(math.sin(a)))
            ey = h*(abs(math.cos(a))+abs(math.sin(a)))
            if cx - ex < -1e-9 or 1-cx-ex < -1e-9 or cy-ey < -1e-9 or 1-cy-ey < -1e-9:
                return False
        for i in range(n):
            for j in range(i+1, n):
                if _sat_constraints(newsq, i, j) < -1e-9:
                    return False
        return True

    lo, hi = 1.0, 3.0
    for _ in range(30):
        mid = (lo + hi) / 2
        if feasibility_scale(sq, mid):
            lo = mid
        else:
            hi = mid
    sq = [(cx, cy, ang, s*lo) for (cx, cy, ang, s) in sq]

    # clamp
    out = []
    for (cx, cy, ang, s) in sq:
        out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)),
                    ang % 1.0, min(1.0, max(0.0, s))))
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # exact square
    m = math.isqrt(n)
    if m * m == n:
        s = 1.0 / m
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(m) for j in range(m)]

    best = None
    best_score = -1

    for m in range(max(1, math.isqrt(n) - 1), math.isqrt(n) + 1):
        if m * m > n:
            continue
        for layout in ('v', 'h', 'c'):
            try:
                sq = _build_layout(n, m, layout)
            except Exception:
                continue
            if len(sq) != n:
                if len(sq) < n:
                    sq = sq + [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
                sq = sq[:n]
            total = sum(s[3] for s in sq)
            if total > best_score:
                best_score = total
                best = sq

    if best is None:
        m = math.isqrt(n)
        s = 1.0 / m
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(m) for j in range(m)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    # refinement for small to medium n
    if n <= 120:
        try:
            refined = _refine(best, 8.0)
            if sum(s[3] for s in refined) >= sum(s[3] for s in best):
                best = refined
        except Exception:
            pass

    return best
