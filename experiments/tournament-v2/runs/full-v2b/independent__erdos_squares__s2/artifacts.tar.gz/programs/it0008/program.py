import math
import random
import numpy as np
from scipy.optimize import minimize

# ------------------------------------------------------------
# Geometry helpers for axis-aligned or rotated squares.
# A square is represented as (cx, cy, angle, side) where angle
# is in turns (0..1). Interior points are disjoint.
# ------------------------------------------------------------
def square_corners(cx, cy, angle, side):
    """Return corners of a square centred at (cx,cy), angle in turns."""
    a = 2.0 * math.pi * angle
    c, s = math.cos(a), math.sin(a)
    h = side * 0.5
    # local corners: (-h,-h), (h,-h), (h,h), (-h,h)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + c * dx - s * dy
        y = cy + s * dx + c * dy
        pts.append((x, y))
    return pts

def sat_overlap(sq1, sq2, eps=1e-12):
    """Return penetration depth if squares overlap, else 0.
       Uses separating axis theorem for convex polygons."""
    p1 = square_corners(*sq1)
    p2 = square_corners(*sq2)
    # Quick bounding-box reject
    if (max(p[0] for p in p1) <= min(p[0] for p in p2) - eps or
        max(p[0] for p in p2) <= min(p[0] for p in p1) - eps or
        max(p[1] for p in p1) <= min(p[1] for p in p2) - eps or
        max(p[1] for p in p2) <= min(p[1] for p in p1) - eps):
        return 0.0

    # SAT axes: normals to edges of both squares
    axes = []
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i+1) % 4]
            ex, ey = x2 - x1, y2 - y1
            # perpendicular
            n = (-ey, ex)
            ln = math.hypot(n[0], n[1])
            if ln > eps:
                axes.append((n[0]/ln, n[1]/ln))
    min_pen = float('inf')
    for ax, ay in axes:
        # project both polygons
        d1 = [ax * x + ay * y for x, y in p1]
        d2 = [ax * x + ay * y for x, y in p2]
        min1, max1 = min(d1), max(d1)
        min2, max2 = min(d2), max(d2)
        # overlap on this axis
        ov = min(max1, max2) - max(min1, min2)
        if ov <= eps:
            return 0.0
        min_pen = min(min_pen, ov)
    return min_pen

def containment_penalty(sq):
    """Penalty if square not fully inside [0,1]^2. Returns total violation."""
    pts = square_corners(*sq)
    pen = 0.0
    for x, y in pts:
        if x < 0:
            pen += -x
        if x > 1:
            pen += x - 1
        if y < 0:
            pen += -y
        if y > 1:
            pen += y - 1
    return pen

# ------------------------------------------------------------
# Objective for local optimization: maximize sum side - lambda * violations
# We minimize negative sum side + lambda * penalty.
# Variables: for each square [cx, cy, angle, side].
# Bounds: cx,cy in [0,1]; angle in [0,1); side in [0,1].
# ------------------------------------------------------------
def make_objective(n, squares0):
    m = n

    def unpack(x):
        return [(x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]) for i in range(m)]

    def obj(x):
        sqs = unpack(x)
        total_side = sum(s[3] for s in sqs)
        pen = 0.0
        # containment
        for s in sqs:
            pen += containment_penalty(s)
        # overlaps
        for i in range(m):
            for j in range(i+1, m):
                d = sat_overlap(sqs[i], sqs[j])
                if d > 0:
                    pen += d
        # weight: large enough to enforce feasibility, but smooth
        LAMBDA = 1000.0
        return -total_side + LAMBDA * pen

    return obj, unpack

# ------------------------------------------------------------
# Initialization strategies
# ------------------------------------------------------------
def init_grid(n):
    """Largest k x k grid that fits, plus zeros."""
    k = max(1, int(math.isqrt(n)))
    # try to improve by using non-equal grid? start with equal.
    side = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    res += [(0.5, 0.5, 0.0, 0.0)] * (n - len(res))
    return res[:n]

def init_random(n, rng):
    """Random feasible-ish placement: random positions, small sides."""
    res = []
    # choose sides from a distribution
    for _ in range(n):
        side = rng.random() * 0.5
        cx = rng.uniform(side/2, 1 - side/2)
        cy = rng.uniform(side/2, 1 - side/2)
        ang = rng.random()
        res.append((cx, cy, ang, side))
    return res

def init_sorted_random(n, rng):
    """Random sizes sorted descending, placed greedily."""
    sides = sorted([rng.random() for _ in range(n)], reverse=True)
    # scale so sum roughly fits?
    scale = 1.0 / (sum(sides) ** 0.5 + 1e-9) if sum(sides) > 0 else 1.0
    side_scale = min(1.0, 1.0 / math.sqrt(n) * 1.5)
    sides = [min(1.0, s * side_scale) for s in sides]
    res = []
    for s in sides:
        # random position attempts
        placed = False
        for _ in range(20):
            cx = rng.uniform(s/2, 1 - s/2)
            cy = rng.uniform(s/2, 1 - s/2)
            ang = 0.0
            candidate = (cx, cy, ang, s)
            # check overlap with existing
            ok = True
            for other in res:
                if sat_overlap(candidate, other) > 1e-9:
                    ok = False
                    break
            if ok:
                res.append(candidate)
                placed = True
                break
        if not placed:
            res.append((0.5, 0.5, 0.0, 0.0))
    return res

# ------------------------------------------------------------
# Local optimization using scipy L-BFGS-B with numerical gradient
# ------------------------------------------------------------
def optimize_squares(squares0, maxiter=200):
    n = len(squares0)
    x0 = []
    bounds = []
    for (cx, cy, ang, s) in squares0:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        s = min(max(s, 0.0), 1.0)
        x0.extend([cx, cy, ang, s])
        bounds.extend([(0,1), (0,1), (0,1), (0,1)])
    obj, _ = make_objective(n, squares0)
    try:
        res = minimize(obj, x0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': maxiter, 'ftol': 1e-12, 'gtol': 1e-8})
        x = res.x
    except Exception:
        x = x0
    # reconstruct
    return [(x[4*i], x[4*i+1], x[4*i+2] % 1.0, max(0.0, min(1.0, x[4*i+3]))) for i in range(n)]

# ------------------------------------------------------------
# Post-processing: enforce feasibility by removing tiny overlaps
# and scaling down or moving squares slightly.
# ------------------------------------------------------------
def repair(squares):
    """Iteratively resolve overlaps by shrinking the smaller square,
       and push inside bounds."""
    n = len(squares)
    sqs = [list(s) for s in squares]
    for _ in range(50):
        changed = False
        # containment: move center so all corners inside
        for i in range(n):
            cx, cy, ang, s = sqs[i]
            if s <= 1e-12:
                continue
            pts = square_corners(cx, cy, ang, s)
            minx = min(p[0] for p in pts)
            maxx = max(p[0] for p in pts)
            miny = min(p[1] for p in pts)
            maxy = max(p[1] for p in pts)
            dx = 0.0
            dy = 0.0
            if minx < 0:
                dx = -minx
            elif maxx > 1:
                dx = 1 - maxx
            if miny < 0:
                dy = -miny
            elif maxy > 1:
                dy = 1 - maxy
            if abs(dx) > 1e-15 or abs(dy) > 1e-15:
                cx += dx
                cy += dy
                # clamp
                cx = min(max(cx, 0), 1)
                cy = min(max(cy, 0), 1)
                sqs[i] = [cx, cy, ang, s]
                changed = True
        # overlaps
        for i in range(n):
            for j in range(i+1, n):
                si, sj = sqs[i], sqs[j]
                if si[3] <= 1e-12 or sj[3] <= 1e-12:
                    continue
                ov = sat_overlap(si, sj)
                if ov > 1e-9:
                    # shrink the smaller
                    if si[3] < sj[3]:
                        idx = i
                    else:
                        idx = j
                    s = sqs[idx][3]
                    new_s = max(0.0, s - ov * 0.5)
                    sqs[idx][3] = new_s
                    changed = True
        if not changed:
            break
    return [tuple(s) for s in sqs]

def total_side(squares):
    return sum(s[3] for s in squares)

# ------------------------------------------------------------
# Main solve
# ------------------------------------------------------------
def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side by side, each 0.5
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three squares: one large + two small? optimal likely: 0.5,0.5 then split one?
        # simple: three columns? better: one 0.5x0.5 and two 0.25? sum 1.0
        # Actually can do: big square 0.5, two squares 0.5x0.5? can't fit 3 of 0.5.
        # Try: 0.5, 0.5, 0.5? area 0.75 > 1, no.
        # Known: best is 1.5? No, for n=3 might be 1.0? Let's start with grid 1x1 + two small.
        return [(0.5, 0.5, 0.0, 1.0)] + [(0.0,0.0,0.0,0.0)]*2
    # Other n: search
    rng = random.Random(12345 + n)
    best = None
    best_val = -1.0

    # Deterministic grid starter
    starts = [init_grid(n)]

    # Randomized restarts
    for _ in range(4):
        starts.append(init_random(n, rng))
        starts.append(init_sorted_random(n, rng))

    # For small n, try more restarts
    n_restarts = 8 if n <= 20 else 4
    for _ in range(n_restarts):
        starts.append(init_random(n, rng))

    # Evaluate each start with local optimization
    for s0 in starts:
        try:
            s_opt = optimize_squares(s0, maxiter=300 if n <= 25 else 150)
            s_rep = repair(s_opt)
            val = total_side(s_rep)
            if val > best_val:
                best_val = val
                best = s_rep
        except Exception:
            s_rep = repair(s0)
            val = total_side(s_rep)
            if val > best_val:
                best_val = val
                best = s_rep

    # Additional polishing: try to increase each square side if no overlap
    if best is not None:
        sqs = [list(s) for s in best]
        # Greedy expansion: for each square, try to increase side while feasible
        for _ in range(20):
            improved = False
            for i in range(n):
                old_s = sqs[i][3]
                if old_s <= 1e-12:
                    continue
                # try scaling up
                for scale in (1.1, 1.05, 1.02, 1.01):
                    new_s = min(1.0, old_s * scale)
                    # check containment and overlaps
                    test = [list(sqs[j]) for j in range(n)]
                    test[i][3] = new_s
                    # adjust center to maintain inside
                    cx, cy, ang, s = test[i]
                    pts = square_corners(cx, cy, ang, s)
                    minx = min(p[0] for p in pts)
                    maxx = max(p[0] for p in pts)
                    miny = min(p[1] for p in pts)
                    maxy = max(p[1] for p in pts)
                    if minx < -1e-12 or maxx > 1+1e-12 or miny < -1e-12 or maxy > 1+1e-12:
                        continue
                    ok = True
                    for j in range(n):
                        if j == i:
                            continue
                        if sat_overlap(test[i], test[j]) > 1e-9:
                            ok = False
                            break
                    if ok:
                        sqs[i][3] = new_s
                        improved = True
                        break
            if not improved:
                break
        best = [tuple(s) for s in sqs]

    # Ensure exactly n squares
    if best is None or len(best) < n:
        best = init_grid(n)
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
