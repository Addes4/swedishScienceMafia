import math
import random
import numpy as np


def _overlap(s1, s2):
    """Return True if two rotated squares overlap in interior."""
    x1, y1, a1, s1s = s1
    x2, y2, a2, s2s = s2
    if s1s <= 0 or s2s <= 0:
        return False
    h1 = s1s * 0.5
    h2 = s2s * 0.5
    # corners of each square
    def corners(x, y, a, s):
        h = s * 0.5
        t = a * 2 * math.pi
        c, si = math.cos(t), math.sin(t)
        pts = []
        for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
            pts.append((x + dx * c - dy * si, y + dx * si + dy * c))
        return pts
    p1 = corners(x1, y1, a1, s1s)
    p2 = corners(x2, y2, a2, s2s)
    # SAT axes
    axes = []
    for i in range(2):
        dx = p1[(i + 1) % 4][0] - p1[i][0]
        dy = p1[(i + 1) % 4][1] - p1[i][1]
        axes.append((-dy, dx))
    for i in range(2):
        dx = p2[(i + 1) % 4][0] - p2[i][0]
        dy = p2[(i + 1) % 4][1] - p2[i][1]
        axes.append((-dy, dx))
    for ax, ay in axes:
        n = math.hypot(ax, ay)
        if n < 1e-15:
            continue
        ax, ay = ax / n, ay / n
        min1 = max1 = p1[0][0] * ax + p1[0][1] * ay
        for px, py in p1[1:]:
            v = px * ax + py * ay
            if v < min1: min1 = v
            if v > max1: max1 = v
        min2 = max2 = p2[0][0] * ax + p2[0][1] * ay
        for px, py in p2[1:]:
            v = px * ax + py * ay
            if v < min2: min2 = v
            if v > max2: max2 = v
        if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
            return False
    return True


def _point_inside_square(px, py, sq):
    x, y, a, s = sq
    if s <= 0:
        return False
    h = s * 0.5
    t = a * 2 * math.pi
    c, si = math.cos(t), math.sin(t)
    dx = px - x
    dy = py - y
    # inverse rotation
    lx = dx * c + dy * si
    ly = -dx * si + dy * c
    return -h < lx < h and -h < ly < h


def _valid(squares):
    n = len(squares)
    for i in range(n):
        x, y, a, s = squares[i]
        if s < 0:
            return False
        if s == 0:
            continue
        h = s * 0.5
        # inside unit square: all four corners inside [0,1]x[0,1]
        t = a * 2 * math.pi
        c, si = math.cos(t), math.sin(t)
        for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
            cx = x + dx * c - dy * si
            cy = y + dx * si + dy * c
            if cx < -1e-9 or cx > 1 + 1e-9 or cy < -1e-9 or cy > 1 + 1e-9:
                return False
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _clamp(sq):
    x, y, a, s = sq
    a = a % 1.0
    if s <= 0:
        return (0.5, 0.5, 0.0, 0.0)
    h = s * 0.5
    t = a * 2 * math.pi
    c, si = math.cos(t), math.sin(t)
    # compute bounding box of rotated square centred at (0,0)
    xs = []
    ys = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        xs.append(dx * c - dy * si)
        ys.append(dx * si + dy * c)
    minx, maxx = min(xs), max(xs)
    miny, maxy = min(ys), max(ys)
    # clamp centre so square fits
    x = min(max(x, -minx), 1 - maxx)
    y = min(max(y, -miny), 1 - maxy)
    return (x, y, a, s)


def _sum_side(squares):
    return sum(s for _, _, _, s in squares)


def _greedy_initial(n):
    """Start with squares in a grid, possibly with random perturbations."""
    k = max(1, math.isqrt(n))
    if k * k < n:
        k += 1
    # try several grids: k x k grid may be too many, but we'll use all n
    base = 1.0 / k
    squares = []
    for i in range(n):
        r = i // k
        c = i % k
        x = (c + 0.5) * base
        y = (r + 0.5) * base
        squares.append((x, y, 0.0, base))
    return squares


def _random_initial(n):
    sq = []
    for _ in range(n):
        s = random.uniform(0.0, 0.2)
        a = random.random()
        x = random.uniform(0.5 * s, 1 - 0.5 * s)
        y = random.uniform(0.5 * s, 1 - 0.5 * s)
        sq.append((x, y, a, s))
    return sq


def _improve(squares, time_limit=55):
    import time
    start = time.time()
    n = len(squares)
    best = list(squares)
    best_score = _sum_side(best)
    # ensure valid
    if not _valid(best):
        # fix invalid by shrinking
        for i in range(n):
            x, y, a, s = best[i]
            while not _valid(best) and s > 0:
                s *= 0.5
                best[i] = (x, y, a, s)
        best_score = _sum_side(best)

    cur = list(best)
    cur_score = best_score
    T = 0.05
    step = 0.0
    while time.time() - start < time_limit:
        step += 1
        if step % 5000 == 0:
            T *= 0.97
        # pick random move
        idx = random.randrange(n)
        x, y, a, s = cur[idx]
        move = random.random()
        if move < 0.35:
            # translate
            nx = x + random.gauss(0, T * 0.3)
            ny = y + random.gauss(0, T * 0.3)
            na = a
            ns = s
        elif move < 0.55:
            # rotate
            nx = x
            ny = y
            na = (a + random.gauss(0, T * 0.2)) % 1.0
            ns = s
        elif move < 0.85:
            # rescale
            nx = x
            ny = y
            na = a
            ns = max(0.0, s + random.gauss(0, T * 0.1))
        else:
            # all
            nx = x + random.gauss(0, T * 0.2)
            ny = y + random.gauss(0, T * 0.2)
            na = (a + random.gauss(0, T * 0.15)) % 1.0
            ns = max(0.0, s + random.gauss(0, T * 0.08))

        cand = _clamp((nx, ny, na, ns))
        old = cur[idx]
        cur[idx] = cand
        if _valid(cur):
            new_score = _sum_side(cur)
            if new_score > cur_score or random.random() < math.exp((new_score - cur_score) / max(T, 1e-9)):
                cur_score = new_score
                if cur_score > best_score:
                    best_score = cur_score
                    best = list(cur)
            else:
                cur[idx] = old
        else:
            cur[idx] = old

        # Occasionally try to increase a random square to fill gaps
        if step % 100 == 0:
            idx = random.randrange(n)
            x, y, a, s = cur[idx]
            ns = min(s * 1.05 + 0.005, 1.0)
            cand = _clamp((x, y, a, ns))
            old = cur[idx]
            cur[idx] = cand
            if _valid(cur):
                ns2 = _sum_side(cur)
                if ns2 > cur_score:
                    cur_score = ns2
                    if cur_score > best_score:
                        best_score = cur_score
                        best = list(cur)
                else:
                    cur[idx] = old
            else:
                cur[idx] = old

    return best


def solve(n):
    if n <= 0:
        return []
    random.seed(12345 + n)
    np.random.seed(12345 + n)

    # initial guess
    if n <= 16:
        # try random starts and greedy
        candidates = [_greedy_initial(n)]
        for _ in range(3):
            candidates.append(_random_initial(n))
        best = None
        best_score = -1
        for c in candidates:
            if _valid(c):
                sc = _sum_side(c)
                if sc > best_score:
                    best_score = sc
                    best = list(c)
        if best is None:
            best = _greedy_initial(n)
            # shrink to valid
            for i in range(n):
                x, y, a, s = best[i]
                while not _valid(best) and s > 0:
                    s *= 0.5
                    best[i] = (x, y, a, s)
            best_score = _sum_side(best)
    else:
        # start with grid, but make squares slightly different sizes
        k = int(math.ceil(math.sqrt(n)))
        base = 1.0 / k
        best = []
        for i in range(n):
            r = i // k
            c = i % k
            # initial size proportional to cell
            s = base * 0.98
            x = (c + 0.5) * base
            y = (r + 0.5) * base
            a = 0.0
            best.append((x, y, a, s))
        # shrink if invalid
        for i in range(n):
            x, y, a, s = best[i]
            while not _valid(best) and s > 0:
                s *= 0.5
                best[i] = (x, y, a, s)
        best_score = _sum_side(best)

    # local improvement
    time_limit = 55
    improved = _improve(best, time_limit)
    # final validation
    if not _valid(improved):
        # fallback
        k = max(1, math.isqrt(n))
        side = 1.0 / k
        improved = [((i % k + 0.5) * side, (i // k + 0.5) * side, 0.0, side) for i in range(n)]
        if len(improved) < n:
            improved += [(0.5, 0.5, 0.0, 0.0)] * (n - len(improved))
        improved = improved[:n]
    return improved
