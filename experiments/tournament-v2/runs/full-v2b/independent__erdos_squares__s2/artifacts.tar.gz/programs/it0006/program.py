import math
import random
from scipy.optimize import minimize

def rect_overlap(p, q):
    # Separating Axis Theorem for oriented rectangles (squares)
    # p, q: (cx, cy, angle_frac, side)
    cx1, cy1, a1, s1 = p
    cx2, cy2, a2, s2 = q
    if s1 <= 1e-12 or s2 <= 1e-12:
        return False
    th1 = a1 * 2 * math.pi
    th2 = a2 * 2 * math.pi
    c1, s_1 = math.cos(th1), math.sin(th1)
    c2, s_2 = math.cos(th2), math.sin(th2)
    # axes: two per rectangle (unit normals)
    axes = [(c1, s_1), (-s_1, c1), (c2, s_2), (-s_2, c2)]
    # rectangle vertices relative to center
    h1 = s1 / 2
    h2 = s2 / 2
    verts1 = []
    for dx, dy in [(h1, h1), (-h1, h1), (-h1, -h1), (h1, -h1)]:
        verts1.append((dx * c1 - dy * s_1, dx * s_1 + dy * c1))
    verts2 = []
    for dx, dy in [(h2, h2), (-h2, h2), (-h2, -h2), (h2, -h2)]:
        verts2.append((dx * c2 - dy * s_2, dx * s_2 + dy * c2))
    for ax, ay in axes:
        min1 = min(vx * ax + vy * ay for vx, vy in verts1)
        max1 = max(vx * ax + vy * ay for vx, vy in verts1)
        min2 = min(vx * ax + vy * ay for vx, vy in verts2)
        max2 = max(vx * ax + vy * ay for vx, vy in verts2)
        if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
            return False
    return True

def in_unit_square(p):
    cx, cy, a, s = p
    if s <= 1e-12:
        return True
    th = a * 2 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s / 2
    for dx, dy in [(h, h), (-h, h), (-h, -h), (h, -h)]:
        x = cx + dx * c - dy * sn
        y = cy + dx * sn + dy * c
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True

def all_ok(sqs):
    n = len(sqs)
    for i in range(n):
        if not in_unit_square(sqs[i]):
            return False
        for j in range(i + 1, n):
            if rect_overlap(sqs[i], sqs[j]):
                return False
    return True

def total(sqs):
    return sum(s for _, _, _, s in sqs)

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    random.seed(12345 + n)
    best_sqs = None
    best_val = -1.0
    
    # Try several grid layouts and orientations
    for k in range(1, int(math.sqrt(n)) + 1):
        for orient in [0.0, 0.25, 0.125, 0.375, 0.0625, 0.1875]:
            # place k^2 squares in a grid, then add zero-size for the rest
            if k * k > n:
                continue
            base = 1.0 / k
            sqs = []
            for i in range(k):
                for j in range(k):
                    sqs.append(( (i + 0.5) * base, (j + 0.5) * base, orient, base * 0.98 ))
            # Try to grow the grid squares slightly if possible via optimization
            sqs += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sqs))
            sqs = sqs[:n]
            
            # Optimize: try to increase sizes of all non-zero squares
            # Use simple coordinate descent: for each square, try increasing its size
            for _ in range(50):
                improved = False
                order = list(range(len(sqs)))
                random.shuffle(order)
                for idx in order:
                    cx, cy, a, s = sqs[idx]
                    # try to increase s
                    for delta in [0.02, 0.01, 0.005, 0.002, 0.001]:
                        ns = s + delta
                        if ns > 1.0:
                            continue
                        cand = (cx, cy, a, ns)
                        # check against all others and bounds
                        ok = True
                        for j, other in enumerate(sqs):
                            if j == idx:
                                continue
                            if rect_overlap(cand, other):
                                ok = False
                                break
                        if ok and in_unit_square(cand):
                            sqs[idx] = cand
                            improved = True
                            break
                if not improved:
                    break
            
            # try to place some of the zero-size squares into gaps
            for _ in range(200):
                placed = False
                for idx in range(len(sqs)):
                    if sqs[idx][3] > 1e-9:
                        continue
                    # try to find a spot for this square
                    best_size = 0.0
                    best_pos = None
                    # random sampling
                    for _ in range(300):
                        cx = random.random()
                        cy = random.random()
                        a = random.choice([0.0, 0.25, 0.125, 0.375, random.random()])
                        # binary search max size
                        lo, hi = 0.0, 1.0
                        for _ in range(25):
                            mid = (lo + hi) / 2
                            cand = (cx, cy, a, mid)
                            ok = True
                            for j, other in enumerate(sqs):
                                if j == idx:
                                    continue
                                if rect_overlap(cand, other):
                                    ok = False
                                    break
                            if ok and in_unit_square(cand):
                                lo = mid
                            else:
                                hi = mid
                        if lo > best_size:
                            best_size = lo
                            best_pos = (cx, cy, a, lo)
                    if best_pos is not None and best_pos[3] > 1e-6:
                        sqs[idx] = best_pos
                        placed = True
                        break
                if not placed:
                    break
            
            val = total(sqs)
            if val > best_val:
                best_val = val
                best_sqs = [list(s) for s in sqs]
    
    # Fine local optimization on best solution
    if best_sqs is None:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    
    sqs = [list(s) for s in best_sqs]
    # Try to improve each square: adjust position and angle slightly
    for _ in range(200):
        improved = False
        order = list(range(n))
        random.shuffle(order)
        for idx in order:
            cx, cy, a, s = sqs[idx]
            best_local = (cx, cy, a, s)
            best_local_val = s
            # random perturbations
            for _ in range(50):
                ncx = cx + random.uniform(-0.02, 0.02)
                ncy = cy + random.uniform(-0.02, 0.02)
                na = (a + random.uniform(-0.02, 0.02)) % 1.0
                # try to increase size
                for ds in [0.0, 0.002, 0.005, 0.01]:
                    ns = min(1.0, s + ds)
                    cand = (ncx, ncy, na, ns)
                    ok = True
                    for j in range(n):
                        if j == idx:
                            continue
                        if rect_overlap(cand, sqs[j]):
                            ok = False
                            break
                    if ok and in_unit_square(cand):
                        if ns > best_local_val:
                            best_local_val = ns
                            best_local = (ncx, ncy, na, ns)
            if best_local_val > s + 1e-9:
                sqs[idx] = list(best_local)
                improved = True
        if not improved:
            break
    
    # Normalize and return
    result = []
    for cx, cy, a, s in sqs:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        a = a % 1.0
        s = min(1.0, max(0.0, s))
        result.append((cx, cy, a, s))
    return result
