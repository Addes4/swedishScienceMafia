# EVOLVE-BLOCK-START
"""Packing squares in the unit square by heuristic cell assignment and local search.

The approach:
  1. Build an initial axis-aligned grid of k x k cells (k=floor(sqrt(n))), filling
     any remaining slots with small squares placed at cell centres.
  2. Refine with coordinate descent: for each square in random order, try several
     candidate (centre_x, centre_y, angle, side) perturbations and keep any move
     that increases the total side while preserving disjoint interiors.
  3. Periodically try to grow the smallest squares by pushing others away
     (repulsion step) and by re-centring squares within available free space.
  4. Repeat from multiple random restarts within a time limit and keep the best.

All squares stay inside [0,1]^2 by construction of candidate centres and clamped
sizes; disjointness is checked by separating-axis between rotated squares.
"""

import math
import random
import time


def _corners(cx, cy, angle, side):
    """Return the four corners of a square (rotated by angle turns)."""
    h = side * 0.5
    c = math.cos(2.0 * math.pi * angle)
    s = math.sin(2.0 * math.pi * angle)
    # local corners (-h,-h),(h,-h),(h,h),(-h,h)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * s, cy + dx * s + dy * c))
    return pts


def _inside(cx, cy, angle, side, eps=1e-12):
    """Check the whole square lies inside the unit square."""
    for x, y in _corners(cx, cy, angle, side):
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def _project(pts, axis):
    """Project points onto an axis and return (min, max)."""
    ax, ay = axis
    vals = [x * ax + y * ay for x, y in pts]
    return min(vals), max(vals)


def _overlap(pts1, pts2):
    """Separating-axis test for two convex polygons (squares)."""
    for pts in (pts1, pts2):
        n = len(pts)
        for i in range(n):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            # normal to edge
            ax, ay = -ey, ex
            ln = math.hypot(ax, ay)
            if ln < 1e-15:
                continue
            ax /= ln
            ay /= ln
            mn1, mx1 = _project(pts1, (ax, ay))
            mn2, mx2 = _project(pts2, (ax, ay))
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return False
    return True


def _feasible(squares):
    """Check all squares are inside the unit square and pairwise non-overlapping."""
    polys = []
    for cx, cy, a, s in squares:
        if s < 0:
            return False
        if s == 0:
            if cx < 0 or cx > 1 or cy < 0 or cy > 1:
                return False
            polys.append([(cx, cy)])
        else:
            if not _inside(cx, cy, a, s):
                return False
            polys.append(_corners(cx, cy, a, s))
    m = len(polys)
    for i in range(m):
        for j in range(i + 1, m):
            if _overlap(polys[i], polys[j]):
                return False
    return True


def _total(squares):
    return sum(s for _, _, _, s in squares)


def _grid(n):
    """Initial axis-aligned grid packing with some zero squares if needed."""
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    grid = []
    for i in range(k):
        for j in range(k):
            grid.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # We have k^2 squares; if n > k^2 add tiny squares at random free-ish spots
    while len(grid) < n:
        grid.append((0.5, 0.5, 0.0, 0.0))
    return grid[:n]


def _score(squares):
    return sum(s for _, _, _, s in squares)


def _try_move(squares, idx, cand, best_total):
    """Try replacing squares[idx] with cand; return new list if feasible and better."""
    old = squares[idx]
    squares[idx] = cand
    if _feasible(squares):
        t = _score(squares)
        if t > best_total:
            return squares, t
    squares[idx] = old
    return squares, best_total


def _local_search(squares, rng, deadline):
    """Coordinate descent on centres, angles, sizes to increase total side."""
    best = [list(s) for s in squares]
    best_total = _score(best)
    n = len(best)
    improved = True
    it = 0
    while improved and time.time() < deadline:
        improved = False
        it += 1
        order = list(range(n))
        rng.shuffle(order)
        for idx in order:
            if time.time() >= deadline:
                break
            cx, cy, a, s = best[idx]
            old_total = best_total
            # candidate perturbations, from coarse to fine
            attempts = []
            step = 0.05
            for _ in range(8):
                attempts.append((cx + rng.uniform(-step, step),
                                 cy + rng.uniform(-step, step),
                                 a + rng.uniform(-0.05, 0.05),
                                 s * rng.uniform(0.9, 1.15)))
                step *= 0.85
            # also try small axis-aligned nudges and pure growth
            attempts.append((cx, cy, 0.0, s * 1.05))
            attempts.append((cx, cy, a, s * 1.02))
            attempts.append((cx + rng.uniform(-0.01, 0.01),
                             cy + rng.uniform(-0.01, 0.01),
                             a, s * 1.01))
            # clamp centre to [0,1]
            for (ncx, ncy, na, ns) in attempts:
                ncx = min(1.0, max(0.0, ncx))
                ncy = min(1.0, max(0.0, ncy))
                if ns < 0:
                    ns = 0.0
                if ns > 1.0:
                    ns = 1.0
                if not _inside(ncx, ncy, na, ns):
                    # shrink until inside (crude)
                    lo, hi = 0.0, ns
                    for _ in range(20):
                        mid = (lo + hi) * 0.5
                        if _inside(ncx, ncy, na, mid):
                            lo = mid
                        else:
                            hi = mid
                    ns = lo
                if ns <= 0:
                    continue
                cand = (ncx, ncy, na, ns)
                best[idx] = cand
                if _feasible(best):
                    t = _score(best)
                    if t > best_total + 1e-14:
                        best_total = t
                        improved = True
                        cx, cy, a, s = cand
                    else:
                        best[idx] = (cx, cy, a, s)
                else:
                    best[idx] = (cx, cy, a, s)
    return best, best_total


def _repel(squares, rng, deadline, rounds=3):
    """Try to grow each square by moving neighbours slightly away."""
    n = len(squares)
    cur = [list(s) for s in squares]
    cur_total = _score(cur)
    for _ in range(rounds):
        if time.time() >= deadline:
            break
        any_grow = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            if time.time() >= deadline:
                break
            cx, cy, a, s = cur[i]
            if s <= 1e-12:
                # place near largest empty spot
                cand = (0.5, 0.5, 0.0, 0.0)
                cur[i] = list(cand)
                continue
            # Try to grow s by 5% and resolve overlaps by nudging others
            grow = s * 1.03
            cand = (cx, cy, a, grow)
            if _inside(*cand):
                trial = [list(q) for q in cur]
                trial[i] = list(cand)
                if _feasible(trial):
                    cur = trial
                    cur_total = _score(cur)
                    any_grow = True
                    continue
                # nudge conflicting squares
                jitter = 0.03
                for _ in range(5):
                    t2 = [list(q) for q in trial]
                    for j in range(n):
                        if j == i:
                            continue
                        t2[j][0] += rng.uniform(-jitter, jitter)
                        t2[j][1] += rng.uniform(-jitter, jitter)
                        t2[j][0] = min(1.0, max(0.0, t2[j][0]))
                        t2[j][1] = min(1.0, max(0.0, t2[j][1]))
                    if _feasible(t2):
                        cur = t2
                        cur_total = _score(cur)
                        any_grow = True
                        break
                    jitter *= 0.7
        if not any_grow:
            break
    return cur, cur_total


def solve(n):
    """Return n squares in the unit square maximising sum of side lengths."""
    if n <= 0:
        return []
    rng = random.Random(12345 + n)
    best = None
    best_total = -1.0
    start = time.time()
    limit = start + 55.0

    # deterministic base grid
    base = _grid(n)
    if _feasible(base):
        best = [list(s) for s in base]
        best_total = _score(best)
    else:
        best = [list(s) for s in base]
        best_total = _score(best)

    # Main loop: alternate local search and repulsion, with restarts
    attempt = 0
    while time.time() < limit:
        attempt += 1
        if best is None or best_total <= 0:
            cur = _grid(n)
            # randomise a bit
            for i in range(len(cur)):
                cur[i] = (min(1.0, max(0.0, cur[i][0] + rng.uniform(-0.02, 0.02))),
                          min(1.0, max(0.0, cur[i][1] + rng.uniform(-0.02, 0.02))),
                          rng.choice([0.0, 0.25, 0.5, 0.75]),
                          cur[i][3])
        else:
            # perturb best slightly
            cur = [list(s) for s in best]
            for i in range(len(cur)):
                if rng.random() < 0.5:
                    cur[i][0] = min(1.0, max(0.0, cur[i][0] + rng.uniform(-0.03, 0.03)))
                    cur[i][1] = min(1.0, max(0.0, cur[i][1] + rng.uniform(-0.03, 0.03)))
                if rng.random() < 0.3:
                    cur[i][2] = (cur[i][2] + rng.uniform(-0.1, 0.1)) % 1.0
                if rng.random() < 0.2:
                    cur[i][3] = max(0.0, cur[i][3] * rng.uniform(0.95, 1.05))

        cur, cur_total = _local_search(cur, rng, min(limit, time.time() + 3.0))
        cur, cur_total = _repel(cur, rng, min(limit, time.time() + 2.0), rounds=2)
        cur, cur_total = _local_search(cur, rng, min(limit, time.time() + 3.0))

        if cur_total > best_total + 1e-12 and _feasible(cur):
            best = [list(s) for s in cur]
            best_total = cur_total

        # small chance to aggressively reset from grid with different orientation
        if attempt % 5 == 0:
            k = max(1, math.isqrt(n))
            side = 1.0 / k
            cand = []
            for i in range(k):
                for j in range(k):
                    ang = rng.choice([0.0, 0.25, 0.5, 0.75])
                    cand.append(((i + 0.5) * side, (j + 0.5) * side, ang, side))
            while len(cand) < n:
                cand.append((rng.random(), rng.random(), 0.0, 0.0))
            cand = cand[:n]
            if _feasible(cand):
                t = _score(cand)
                cand, t = _local_search(cand, rng, min(limit, time.time() + 2.0))
                if t > best_total:
                    best = [list(s) for s in cand]
                    best_total = t

    # Final cleanup: ensure feasible, shrink any violations, keep zeros compact
    if best is None:
        best = [list(s) for s in _grid(n)]
    # Clamp and fix
    for i in range(len(best)):
        cx, cy, a, s = best[i]
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        s = max(0.0, s)
        if s > 0:
            if not _inside(cx, cy, a, s):
                lo, hi = 0.0, s
                for _ in range(30):
                    mid = (lo + hi) * 0.5
                    if _inside(cx, cy, a, mid):
                        lo = mid
                    else:
                        hi = mid
                s = lo
        best[i] = [cx, cy, a, s]
    # If still infeasible, fall back to grid
    if not _feasible(best):
        best = [list(s) for s in _grid(n)]

    return [(float(cx), float(cy), float(a % 1.0), float(s)) for cx, cy, a, s in best]


# EVOLVE-BLOCK-END
