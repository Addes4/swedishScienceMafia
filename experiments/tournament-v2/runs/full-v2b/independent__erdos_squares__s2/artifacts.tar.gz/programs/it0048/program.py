import math
import random

import numpy as np
from scipy.optimize import minimize


def _overlap_area(sq1, sq2):
    (x1, y1, t1, s1) = sq1
    (x2, y2, t2, s2) = sq2

    if s1 <= 0.0 or s2 <= 0.0:
        return 0.0

    def corners(x, y, t, s):
        a = 2.0 * math.pi * t
        c = math.cos(a)
        sn = math.sin(a)
        h = 0.5 * s
        pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
        out = []
        for px, py in pts:
            out.append((x + c * px - sn * py, y + sn * px + c * py))
        return out

    p1 = corners(x1, y1, t1, s1)
    p2 = corners(x2, y2, t2, s2)

    def proj(poly, axis):
        vals = [p[0] * axis[0] + p[1] * axis[1] for p in poly]
        return min(vals), max(vals)

    def axes(poly):
        res = []
        for i in range(4):
            x0, y0 = poly[i]
            x1, y1 = poly[(i + 1) % 4]
            vx, vy = x1 - x0, y1 - y0
            ln = math.hypot(vx, vy)
            if ln > 0:
                res.append((vx / ln, vy / ln))
        return res

    a1 = axes(p1)
    a2 = axes(p2)
    best = None

    for axis in a1 + a2:
        mn1, mx1 = proj(p1, axis)
        mn2, mx2 = proj(p2, axis)
        ov = min(mx1, mx2) - max(mn1, mn2)
        if ov <= 0:
            return 0.0
        if best is None or ov < best:
            best = ov

    if best is None:
        return 0.0

    # approximate polygon intersection area
    def inside(pt, poly):
        x, y = pt
        c = False
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            if ((y1 > y) != (y2 > y)):
                xin = x1 + (y - y1) * (x2 - x1) / (y2 - y1)
                if x < xin:
                    c = not c
        return c

    pts = []
    for p in p1:
        if inside(p, p2):
            pts.append(p)
    for p in p2:
        if inside(p, p1):
            pts.append(p)

    for i in range(4):
        a = p1[i]
        b = p1[(i + 1) % 4]
        for j in range(4):
            c = p2[j]
            d = p2[(j + 1) % 4]

            r = (b[0] - a[0], b[1] - a[1])
            s = (d[0] - c[0], d[1] - c[1])
            den = r[0] * s[1] - r[1] * s[0]
            if abs(den) < 1e-15:
                continue
            qp = (c[0] - a[0], c[1] - a[1])
            t = (qp[0] * s[1] - qp[1] * s[0]) / den
            u = (qp[0] * r[1] - qp[1] * r[0]) / den
            if 0 <= t <= 1 and 0 <= u <= 1:
                pts.append((a[0] + t * r[0], a[1] + t * r[1]))

    if len(pts) < 3:
        return 0.0

    pts = list(set((round(x, 12), round(y, 12)) for x, y in pts))
    cx = sum(p[0] for p in pts) / len(pts)
    cy = sum(p[1] for p in pts) / len(pts)
    pts.sort(key=lambda p: math.atan2(p[1] - cy, p[0] - cx))

    area = 0.0
    for i in range(len(pts)):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % len(pts)]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def _penalty(squares):
    n = len(squares)
    pen = 0.0

    for x, y, t, s in squares:
        if s <= 0:
            continue
        a = 2.0 * math.pi * t
        c = abs(math.cos(a))
        sn = abs(math.sin(a))
        r = 0.5 * s * (c + sn)

        # outside penalty
        pen += 1000.0 * max(0.0, r - x) ** 2
        pen += 1000.0 * max(0.0, x + r - 1.0) ** 2
        pen += 1000.0 * max(0.0, r - y) ** 2
        pen += 1000.0 * max(0.0, y + r - 1.0) ** 2

        pen += 1000.0 * max(0.0, s - 1.0) ** 2

    for i in range(n):
        for j in range(i + 1, n):
            a = _overlap_area(squares[i], squares[j])
            if a > 1e-14:
                pen += 5000.0 * a

    return pen


def _total_side(squares):
    return sum(max(0.0, s) for _, _, _, s in squares)


def _make_grid(n):
    k = int(math.sqrt(n))
    while k * k < n:
        k += 1

    res = []
    for i in range(k):
        for j in range(k):
            if len(res) >= n:
                break
            res.append([(i + 0.5) / k, (j + 0.5) / k, 0.0, 1.0 / k])
        if len(res) >= n:
            break

    while len(res) < n:
        res.append([0.5, 0.5, 0.0, 0.0])

    return res


def _make_staggered(n):
    if n == 1:
        return [[0.5, 0.5, 0.0, 1.0]]

    k = int(math.sqrt(n))
    if k < 1:
        k = 1

    res = []

    # Row-based staggered layout
    rows = int(round(math.sqrt(n)))
    if rows < 1:
        rows = 1

    idx = 0
    for r in range(rows):
        cols = (n + rows - 1) // rows
        if r % 2 == 1 and cols > 1:
            shift = 0.5 / cols
        else:
            shift = 0.0
        for c in range(cols):
            if idx >= n:
                break
            x = (c + 0.5 + shift) / cols
            y = (r + 0.5) / rows
            if x <= 0.0 or x >= 1.0:
                x = min(0.999, max(0.001, x))
            s = min(1.0 / cols, 1.0 / rows)
            res.append([x, y, 0.0, s])
            idx += 1

    while len(res) < n:
        res.append([0.5, 0.5, 0.0, 0.0])

    return res[:n]


def _make_random(n, rng):
    res = []
    for _ in range(n):
        s = rng.random() * 0.3 + 0.01
        x = rng.random() * (1.0 - s) + 0.5 * s
        y = rng.random() * (1.0 - s) + 0.5 * s
        t = rng.random()
        res.append([x, y, t, s])
    return res


def _repair(squares, rng):
    n = len(squares)
    sq = [list(x) for x in squares]

    for _ in range(120):
        changed = False

        for i in range(n):
            x, y, t, s = sq[i]
            if s <= 0:
                sq[i][0] = min(1.0, max(0.0, x))
                sq[i][1] = min(1.0, max(0.0, y))
                sq[i][2] = t % 1.0
                continue

            a = 2.0 * math.pi * t
            c = abs(math.cos(a))
            sn = abs(math.sin(a))
            r = 0.5 * s * (c + sn)

            nx = min(1.0 - r, max(r, x))
            ny = min(1.0 - r, max(r, y))
            if abs(nx - x) > 1e-12 or abs(ny - y) > 1e-12:
                changed = True
            sq[i][0] = nx
            sq[i][1] = ny

        for i in range(n):
            for j in range(i + 1, n):
                if sq[i][3] <= 0 or sq[j][3] <= 0:
                    continue
                a = _overlap_area(sq[i], sq[j])
                if a > 1e-13:
                    changed = True
                    # move apart
                    xi, yi, ti, si = sq[i]
                    xj, yj, tj, sj = sq[j]
                    dx = xj - xi
                    dy = yj - yi
                    d = math.hypot(dx, dy)
                    if d < 1e-12:
                        dx, dy = rng.random() - 0.5, rng.random() - 0.5
                        d = math.hypot(dx, dy)
                    if d < 1e-12:
                        dx, dy = 1.0, 0.0
                        d = 1.0
                    step = 0.02 * (si + sj)
                    xi -= dx / d * step
                    yi -= dy / d * step
                    xj += dx / d * step
                    yj += dy / d * step
                    sq[i][0] = xi
                    sq[i][1] = yi
                    sq[j][0] = xj
                    sq[j][1] = yj

        if not changed:
            break

    for i in range(n):
        sq[i][2] %= 1.0
        if sq[i][3] < 0:
            sq[i][3] = 0.0

    return sq


def _greedy_fill(n, base):
    sq = [list(x) for x in base]
    for _ in range(200):
        improved = False
        for i in range(n):
            x, y, t, s = sq[i]
            best = s
            best_state = None
            for ds in [0.001, 0.002, 0.005, 0.01]:
                ns = min(1.0, s + ds)
                cand = [x, y, t, ns]
                old = sq[i]
                sq[i] = cand
                sq[i] = old
                if _penalty(sq) < 1e-12:
                    best = ns
                    best_state = cand
            if best_state is not None:
                sq[i] = best_state
                improved = True
        if not improved:
            break
    return sq


def _local_opt(sq, rng, iters=3000):
    n = len(sq)
    cur = [list(x) for x in sq]
    cur_score = _total_side(cur) - 0.001 * _penalty(cur)

    for _ in range(iters):
        i = rng.randrange(n)
        old = cur[i][:]
        mode = rng.random()

        if mode < 0.4:
            cur[i][3] = max(0.0, min(1.0, cur[i][3] + rng.gauss(0, 0.01)))
        elif mode < 0.7:
            cur[i][0] = max(0.0, min(1.0, cur[i][0] + rng.gauss(0, 0.01)))
            cur[i][1] = max(0.0, min(1.0, cur[i][1] + rng.gauss(0, 0.01)))
        elif mode < 0.85:
            cur[i][2] = (cur[i][2] + rng.gauss(0, 0.02)) % 1.0
        else:
            cur[i][3] = max(0.0, min(1.0, cur[i][3] + rng.gauss(0, 0.03)))
            cur[i][0] = max(0.0, min(1.0, cur[i][0] + rng.gauss(0, 0.01)))
            cur[i][1] = max(0.0, min(1.0, cur[i][1] + rng.gauss(0, 0.01)))

        new_score = _total_side(cur) - 0.001 * _penalty(cur)
        if new_score < cur_score and rng.random() > 0.02:
            cur[i] = old
        else:
            cur_score = new_score

    return cur


def _sa(sq, rng, steps=2000):
    n = len(sq)
    cur = [list(x) for x in sq]
    cur_pen = _penalty(cur)
    cur_side = _total_side(cur)

    T = 0.05
    for step in range(steps):
        T = 0.05 * (1.0 - step / steps) + 0.0001
        i = rng.randrange(n)
        old = cur[i][:]
        cur[i][3] = max(0.0, min(1.0, cur[i][3] + rng.gauss(0, 0.02)))
        cur[i][0] = max(0.0, min(1.0, cur[i][0] + rng.gauss(0, 0.01)))
        cur[i][1] = max(0.0, min(1.0, cur[i][1] + rng.gauss(0, 0.01)))
        cur[i][2] = (cur[i][2] + rng.gauss(0, 0.03)) % 1.0

        new_pen = _penalty(cur)
        new_side = _total_side(cur)
        d = (new_side - cur_side) - 0.5 * (new_pen - cur_pen)

        if d >= 0 or rng.random() < math.exp(d / T):
            cur_pen = new_pen
            cur_side = new_side
        else:
            cur[i] = old

    return cur


def solve(n):
    if n <= 0:
        return []

    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n * 1000)

    candidates = []
    candidates.append(_make_grid(n))
    candidates.append(_make_staggered(n))

    for _ in range(8):
        candidates.append(_make_random(n, rng))

    best = None
    best_val = -1e18

    for cand in candidates:
        sq = _repair(cand, rng)
        sq = _greedy_fill(n, sq)
        sq = _local_opt(sq, rng, iters=1500)
        sq = _sa(sq, rng, steps=1200)
        sq = _repair(sq, rng)

        val = _total_side(sq) - 0.01 * _penalty(sq)
        if val > best_val:
            best_val = val
            best = sq

    # final polish
    if best is not None:
        for _ in range(5):
            best = _local_opt(best, rng, iters=1000)
            best = _sa(best, rng, steps=1000)
            best = _repair(best, rng)

    result = []
    for x, y, t, s in best:
        x = min(1.0, max(0.0, x))
        y = min(1.0, max(0.0, y))
        t = t % 1.0
        s = min(1.0, max(0.0, s))
        result.append((x, y, t, s))

    return result
