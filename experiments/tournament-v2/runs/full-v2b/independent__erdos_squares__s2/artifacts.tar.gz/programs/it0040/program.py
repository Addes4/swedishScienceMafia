import math
import random
import time


def _overlap_1d(a0, a1, b0, b1):
    return not (a1 <= b0 or b1 <= a0)


def _axis_aligned_bbox(cx, cy, ang, s):
    if s <= 0:
        return cx, cy, cx, cy
    c = abs(math.cos(math.pi * ang))
    si = abs(math.sin(math.pi * ang))
    hx = 0.5 * s * (c + si)
    hy = 0.5 * s * (c + si)
    return cx - hx, cy - hy, cx + hx, cy + hy


def _sat_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    if s1 <= 0 or s2 <= 0:
        return False
    axes = []
    for ang in (a1, a2):
        th = math.pi * ang
        ux, uy = math.cos(th), math.sin(th)
        vx, vy = -uy, ux
        axes.append((ux, uy))
        axes.append((vx, vy))
    for ax, ay in axes:
        r1 = 0.5 * s1 * (abs(math.cos(math.pi * a1)) + abs(math.sin(math.pi * a1)))
        r2 = 0.5 * s2 * (abs(math.cos(math.pi * a2)) + abs(math.sin(math.pi * a2)))
        c1 = cx1 * ax + cy1 * ay
        c2 = cx2 * ax + cy2 * ay
        r1 = 0.5 * s1 * (abs(math.cos(math.pi * a1) * ax + math.sin(math.pi * a1) * ay) +
                         abs(-math.sin(math.pi * a1) * ax + math.cos(math.pi * a1) * ay))
        r2 = 0.5 * s2 * (abs(math.cos(math.pi * a2) * ax + math.sin(math.pi * a2) * ay) +
                         abs(-math.sin(math.pi * a2) * ax + math.cos(math.pi * a2) * ay))
        if abs(c1 - c2) >= r1 + r2 - 1e-12:
            return False
    return True


def _fits(cx, cy, ang, s, others):
    if s <= 0:
        return 0 <= cx <= 1 and 0 <= cy <= 1
    x0, y0, x1, y1 = _axis_aligned_bbox(cx, cy, ang, s)
    if x0 < -1e-12 or y0 < -1e-12 or x1 > 1 + 1e-12 or y1 > 1 + 1e-12:
        return False
    for (ox, oy, oa, os) in others:
        if os <= 0:
            continue
        if _sat_overlap(cx, cy, ang, s, ox, oy, oa, os):
            return False
    return True


def _try_place(cx, cy, ang, s, placed):
    return _fits(cx, cy, ang, s, placed)


def _greedy(n, seed, angles):
    rng = random.Random(seed)
    placed = []
    target = 1.0
    for i in range(n):
        best = None
        best_s = -1.0
        attempts = 220 + 8 * n
        for _ in range(attempts):
            s = target * (0.35 + 0.65 * rng.random())
            ang = angles[rng.randrange(len(angles))]
            cx = rng.random()
            cy = rng.random()
            # shrink to fit
            if _fits(cx, cy, ang, s, placed):
                if s > best_s:
                    best_s = s
                    best = (cx, cy, ang, s)
                    target = max(target, min(1.0, s * 1.25))
        if best is None:
            for _ in range(attempts):
                s = target * 0.2
                ang = angles[rng.randrange(len(angles))]
                cx = rng.random()
                cy = rng.random()
                if _fits(cx, cy, ang, s, placed):
                    best = (cx, cy, ang, s)
                    best_s = s
                    break
        if best is None:
            best = (0.5, 0.5, 0.0, 0.0)
        placed.append(best)
    return placed


def _score(sqs):
    return sum(s for (_, _, _, s) in sqs)


def _repair(sqs, idx, others):
    cx, cy, ang, s = sqs[idx]
    lo, hi = 0.0, 1.0
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        if _fits(cx, cy, ang, mid, others):
            lo = mid
        else:
            hi = mid
    return (cx, cy, ang, lo)


def _improve(sqs, n, deadline, angles):
    rng = random.Random(12345 + n)
    best = [list(x) for x in sqs]
    best_score = _score(best)
    cur = [list(x) for x in best]
    cur_score = best_score
    it = 0
    while time.time() < deadline:
        it += 1
        i = rng.randrange(n)
        others = [tuple(cur[j]) for j in range(n) if j != i]
        cx, cy, ang, s = cur[i]
        # random move
        mode = rng.random()
        if mode < 0.5:
            ang = angles[rng.randrange(len(angles))]
            cx = min(1.0, max(0.0, cx + (rng.random() - 0.5) * 0.25))
            cy = min(1.0, max(0.0, cy + (rng.random() - 0.5) * 0.25))
        elif mode < 0.8:
            cx = min(1.0, max(0.0, cx + (rng.random() - 0.5) * 0.1))
            cy = min(1.0, max(0.0, cy + (rng.random() - 0.5) * 0.1))
        else:
            ang = angles[rng.randrange(len(angles))]
        news = _repair([(cx, cy, ang, s)], 0, others)
        old_s = cur[i][3]
        cur[i] = list(news)
        cur_score += news[3] - old_s
        if cur_score > best_score + 1e-12:
            best_score = cur_score
            best = [list(x) for x in cur]
        elif cur_score < best_score - 1e-9:
            cur = [list(x) for x in best]
            cur_score = best_score
    return [tuple(x) for x in best]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    start = time.time()
    budget = 55.0 if n <= 40 else 50.0
    deadline = start + budget * 0.92
    angles = [0.0, 0.25, 0.125, 0.375]
    best = None
    best_score = -1.0
    seeds = [1, 2, 3, 7, 11, 19, 23, 31, 41, 53]
    si = 0
    while time.time() < deadline:
        seed = seeds[si % len(seeds)] + 1000 * (si // len(seeds))
        si += 1
        sqs = _greedy(n, seed, angles)
        sqs = _improve(sqs, n, min(deadline, time.time() + 3.5), angles)
        sc = _score(sqs)
        if sc > best_score:
            best_score = sc
            best = sqs
        if si > 300:
            break
    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    # final normalization
    out = []
    for (cx, cy, ang, s) in best:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = min(1.0, max(0.0, ang))
        s = min(1.0, max(0.0, s))
        out.append((cx, cy, ang, s))
    return out[:n]
