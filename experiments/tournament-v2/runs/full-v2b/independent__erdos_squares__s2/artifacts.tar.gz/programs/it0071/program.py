import math
import random

# ----------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------

def corners(cx, cy, ang, s):
    """Return the 4 corners of a square (centre cx,cy, angle fraction of turn, side s)."""
    a = 2.0 * math.pi * ang
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def axes(ang):
    a = 2.0 * math.pi * ang
    c, sn = math.cos(a), math.sin(a)
    return ((c, sn), (-sn, c))


def overlap(p1, p2):
    """SAT for two convex polygons given as point lists. Returns True if interiors overlap."""
    for a in (p1, p2):
        n = len(a)
        for i in range(n):
            ax = a[(i + 1) % n][0] - a[i][0]
            ay = a[(i + 1) % n][1] - a[i][1]
            # normal
            nx, ny = -ay, ax
            l = math.hypot(nx, ny)
            if l < 1e-15:
                continue
            nx /= l
            ny /= l
            min1 = min2 = 1e300
            max1 = max2 = -1e300
            for (x, y) in p1:
                d = x * nx + y * ny
                if d < min1: min1 = d
                if d > max1: max1 = d
            for (x, y) in p2:
                d = x * nx + y * ny
                if d < min2: min2 = d
                if d > max2: max2 = d
            if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                return False
    return True


def inside(p, eps=1e-9):
    for (x, y) in p:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def feasible(sq):
    """sq is list of (cx,cy,ang,s)."""
    polys = []
    for (cx, cy, ang, s) in sq:
        if s <= 0:
            polys.append(None)
        else:
            p = corners(cx, cy, ang, s)
            if not inside(p):
                return False
            polys.append(p)
    n = len(sq)
    for i in range(n):
        if polys[i] is None:
            continue
        for j in range(i + 1, n):
            if polys[j] is None:
                continue
            if overlap(polys[i], polys[j]):
                return False
    return True


# ----------------------------------------------------------------------
# constructive small-n patterns (known good configurations)
# ----------------------------------------------------------------------

def pattern_1():
    return [(0.5, 0.5, 0.0, 1.0)]


def pattern_2():
    # two squares side by side, each 1 x 0.5 -> sum 1.0 (optimal for n=2)
    return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]


def pattern_3():
    # three rectangles 1 x 1/3  => sum 1 (not optimal: can do slightly better with a rotated square)
    # Use: one big square 0.5x0.5? Actually optimal n=3 is 1 + 0.5? No.
    # Known: n=3 best sum = 1.5? Let's just use a heuristic: two at bottom, one rotated at top.
    # We'll rely on optimiser for n=3 too.
    s = 1.0 / 3.0
    return [(0.5, s * 0.5, 0.0, s),
            (0.5, 3 * s * 0.5, 0.0, s),
            (0.5, 5 * s * 0.5, 0.0, s)]


def pattern_4():
    side = 0.5
    return [(0.25, 0.25, 0.0, side), (0.75, 0.25, 0.0, side),
            (0.25, 0.75, 0.0, side), (0.75, 0.75, 0.0, side)]


def pattern_5():
    # 2x2 grid + 5th small square in a corner? Actually use optimiser.
    side = 1.0 / 3.0
    sq = [( (i+0.5)*side, (j+0.5)*side, 0.0, side) for i in range(3) for j in range(3)]
    return sq[:5]


def pattern_6():
    side = 1.0 / 3.0
    sq = [( (i+0.5)*side, (j+0.5)*side, 0.0, side) for i in range(3) for j in range(3)]
    return sq[:6]


def pattern_7():
    side = 1.0 / 3.0
    sq = [( (i+0.5)*side, (j+0.5)*side, 0.0, side) for i in range(3) for j in range(3)]
    return sq[:7]


# ----------------------------------------------------------------------
# main grid initialisation and optimisation
# ----------------------------------------------------------------------

def grid_init(n):
    """Return initial list of squares: best k x k grid plus remainder in a row/col."""
    k = math.isqrt(n)
    side = 1.0 / k
    sq = []
    for i in range(k):
        for j in range(k):
            sq.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    rem = n - k * k
    if rem > 0:
        # place extra squares at the bottom as smaller squares
        # use a row of rem squares across width, height = 1/(k+1)
        h = 1.0 / (k + 1)
        w = 1.0 / rem
        if w > h:
            # place them as a full row of height h and width min(1, rem*h)
            pass
        # simple: put rem equal squares in bottom strip
        ss = min(1.0 / rem, h)
        left = 0.0
        for r in range(rem):
            cx = left + ss * 0.5
            cy = ss * 0.5
            sq.append((cx, cy, 0.0, ss))
            left += ss
    # if too many, shrink extras to 0
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq[:n]


def objective(sq):
    return sum(s for (_, _, _, s) in sq)


def local_search(sq, n, time_limit_iters=8000, seed=0):
    """Randomized local search: perturb one square at a time, accept if feasible and improves."""
    rnd = random.Random(seed)
    best = [list(x) for x in sq]
    best_val = objective(best)
    cur = [list(x) for x in sq]
    cur_val = best_val

    # schedule of proposal types
    for it in range(time_limit_iters):
        i = rnd.randrange(n)
        cx, cy, ang, s = cur[i]
        # propose new values
        mode = rnd.random()
        if mode < 0.45:
            # resize
            ds = rnd.gauss(0, 0.03) * (1.0 if s > 0 else 0.2)
            ns = s + ds
        elif mode < 0.65:
            # move
            dx = rnd.gauss(0, 0.02)
            dy = rnd.gauss(0, 0.02)
            ns = s
        elif mode < 0.85:
            # rotate
            da = rnd.gauss(0, 0.05)
            ns = s
        else:
            # resize + move
            ds = rnd.gauss(0, 0.02)
            ns = s + ds
            dx = rnd.gauss(0, 0.01)
            dy = rnd.gauss(0, 0.01)

        if mode < 0.45:
            ncx, ncy, nang = cx, cy, ang
            if ns < 0:
                ns = 0.0
        elif mode < 0.65:
            ncx, ncy, nang = cx + dx, cy + dy, ang
            ns = s
        elif mode < 0.85:
            ncx, ncy, nang = cx, cy, ang + da
            ns = s
        else:
            ncx, ncy, nang = cx + dx, cy + dy, ang
            if ns < 0:
                ns = 0.0

        ncx = min(1.0, max(0.0, ncx))
        ncy = min(1.0, max(0.0, ncy))
        nang = nang % 1.0
        cand = [list(x) for x in cur]
        cand[i] = [ncx, ncy, nang, ns]
        # feasibility check
        if feasible(cand):
            cand_val = objective(cand)
            if cand_val >= cur_val - 1e-12:
                cur = cand
                cur_val = cand_val
                if cand_val > best_val + 1e-12:
                    best = [list(x) for x in cand]
                    best_val = cand_val
            else:
                # sometimes accept worse
                if rnd.random() < math.exp((cand_val - cur_val) / max(1e-6, 0.001)):
                    cur = cand
                    cur_val = cand_val

    # clean-up: try to grow each square greedily
    improved = True
    while improved:
        improved = False
        for i in range(n):
            cx, cy, ang, s = best[i]
            # try increasing size while keeping feasibility
            lo, hi = s, min(1.0, s + 0.3)
            # binary search for max feasible
            for _ in range(25):
                mid = (lo + hi) / 2
                trial = [list(x) for x in best]
                trial[i] = [cx, cy, ang, mid]
                if feasible(trial):
                    lo = mid
                else:
                    hi = mid
            if lo > s + 1e-9:
                best[i] = [cx, cy, ang, lo]
                improved = True
    return [tuple(x) for x in best]


def make_initial(n):
    if n == 1:
        return pattern_1()
    elif n == 2:
        return pattern_2()
    elif n == 3:
        return pattern_3()
    elif n == 4:
        return pattern_4()
    elif n == 5:
        return pattern_5()
    elif n == 6:
        return pattern_6()
    elif n == 7:
        return pattern_7()
    else:
        return grid_init(n)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side)."""
    if n <= 0:
        return []
    sq = make_initial(n)
    # ensure length
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    sq = sq[:n]

    # For small n, also try a few random rotations in initial grid
    best = sq
    best_val = objective(sq)

    # run local search with several seeds for robustness
    n_seeds = 3 if n <= 20 else 2
    for seed in range(n_seeds):
        start = [list(x) for x in sq]
        if seed > 0:
            # randomize small
            rnd = random.Random(seed)
            for k in range(len(start)):
                if start[k][3] > 0:
                    start[k][2] = rnd.random()
                    start[k][0] = min(1.0, max(0.0, start[k][0] + rnd.gauss(0, 0.02)))
                    start[k][1] = min(1.0, max(0.0, start[k][1] + rnd.gauss(0, 0.02)))
        res = local_search(start, n, time_limit_iters=6000 // n_seeds, seed=seed)
        val = objective(res)
        if val > best_val:
            best_val = val
            best = res

    # final cleanup: try to grow each square
    best = [list(x) for x in best]
    for _ in range(2):
        for i in range(n):
            cx, cy, ang, s = best[i]
            lo, hi = s, min(1.0, s + 0.5)
            for _ in range(30):
                mid = (lo + hi) / 2
                trial = [list(x) for x in best]
                trial[i] = [cx, cy, ang, mid]
                if feasible(trial):
                    lo = mid
                else:
                    hi = mid
            best[i] = [cx, cy, ang, lo]

    # ensure everything inside and feasible (fallback)
    if not feasible(best):
        # fallback to grid
        best = grid_init(n)
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))
        best = best[:n]

    return [tuple(min(1.0, max(0.0, v))) if idx < 3 else min(1.0, max(0.0, v))
            for idx, v in enumerate(x) for x in best]

