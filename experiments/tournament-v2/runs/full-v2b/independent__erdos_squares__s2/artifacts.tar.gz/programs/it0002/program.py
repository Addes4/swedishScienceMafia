import math
import random
import time

# ---------- geometry helpers for rotated squares ----------
def square_corners(cx, cy, ang, s):
    """Return the 4 corners (counter-clockwise) of a rotated square.
    ang: fraction of full turn, so actual angle = ang * 2*pi."""
    t = ang * 2.0 * math.pi
    c = math.cos(t)
    si = math.sin(t)
    h = s * 0.5
    # local corners: (-h,-h), (h,-h), (h,h), (-h,h)
    pts = []
    for lx, ly in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + lx * c - ly * si
        y = cy + lx * si + ly * c
        pts.append((x, y))
    return pts


def project_polygon(pts, axis):
    """Project polygon points onto axis, return (min, max)."""
    ax, ay = axis
    dots = [px * ax + py * ay for px, py in pts]
    return min(dots), max(dots)


def overlap_on_axis(p1, p2, axis):
    """Return True if projections overlap (positive overlap) on axis."""
    a1, b1 = project_polygon(p1, axis)
    a2, b2 = project_polygon(p2, axis)
    return not (b1 <= a2 or b2 <= a1)


def separating_axis_test(p1, p2):
    """Return True if the two convex polygons intersect (positive area overlap or touching edge).
    For our purpose, we want to detect *interior* overlap. We'll treat touching as OK.
    We'll use strict inequality: if projections are disjoint -> no overlap.
    If all projections overlap with positive amount -> interior overlap.
    """
    # axes: normals of edges of both squares. Since both are squares, 2 unique axes each.
    # For square 1: edges directions are rotation by ang. Normal is perpendicular.
    # But easier: use the 4 edge vectors as axes after perpendicular.
    # We'll compute axes from each polygon.
    def axes_from(pts):
        axs = []
        n = len(pts)
        for i in range(n):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % n]
            dx = x2 - x1
            dy = y2 - y1
            # normal
            axs.append((-dy, dx))
        return axs

    axes = axes_from(p1) + axes_from(p2)
    for ax in axes:
        a1, b1 = project_polygon(p1, ax)
        a2, b2 = project_polygon(p2, ax)
        # if disjoint (strictly separated, allowing touching at a point/edge)
        if b1 <= a2 or b2 <= a1:
            return False
    # if no separating axis -> they overlap with positive area
    return True


def squares_overlap(s1, s2):
    """Check if two squares (cx,cy,ang,s) overlap in interior.
    Return True if they share interior area (or edge? problem says no two share an interior point,
    so touching edges is allowed)."""
    if s1[3] <= 0 or s2[3] <= 0:
        return False
    p1 = square_corners(*s1)
    p2 = square_corners(*s2)
    # Use SAT but with strict separation to allow touching
    # We'll check if they overlap with positive area.
    # Quick bounding circle check first:
    r1 = s1[3] * 0.5 * math.sqrt(2)
    r2 = s2[3] * 0.5 * math.sqrt(2)
    dx = s1[0] - s2[0]
    dy = s1[1] - s2[1]
    if dx * dx + dy * dy > (r1 + r2) ** 2:
        return False
    # SAT with strict separation
    def axes_from(pts):
        axs = []
        n = len(pts)
        for i in range(n):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % n]
            dx_ = x2 - x1
            dy_ = y2 - y1
            axs.append((-dy_, dx_))
        return axs

    for ax in axes_from(p1) + axes_from(p2):
        a1, b1 = project_polygon(p1, ax)
        a2, b2 = project_polygon(p2, ax)
        # separated (allow touching): if max of one <= min of other
        if b1 <= a2 or b2 <= a1:
            return False
    return True


def inside_unit_square(cx, cy, ang, s):
    """Check if square is fully inside [0,1]x[0,1]."""
    if s <= 0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    pts = square_corners(cx, cy, ang, s)
    for x, y in pts:
        if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
            return False
    return True


def feasible(squares):
    """Check all squares inside unit square and pairwise non-overlapping interiors."""
    n = len(squares)
    for i in range(n):
        if not inside_unit_square(*squares[i]):
            return False
    for i in range(n):
        if squares[i][3] <= 0:
            continue
        for j in range(i + 1, n):
            if squares[j][3] <= 0:
                continue
            if squares_overlap(squares[i], squares[j]):
                return False
    return True


# ---------- initial layouts ----------
def grid_layout(n):
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def known_good_layout(n):
    """Some known good packings for specific n (approximate, from literature).
    This is not exhaustive but helps for some n."""
    if n == 2:
        # Two squares side 0.5 side by side gives sum 1.0, but can we do better?
        # Max for n=2 is 1.0 (two 0.5 squares), can't beat.
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # Known: three squares max sum ~ 1.5? Actually can have one 0.5 and two 0.5? No.
        # Best known: 0.5 + 0.5 + 0.5 = 1.5? Must fit: three 0.5 squares can't fit in unit square.
        # Actually max for n=3 is around 1.4142? Two diagonal? Let's just use grid.
        pass
    if n == 5:
        # known: side 1/3 for 4 + one more? grid gives 4/3.
        # Alternative: one big 0.5, four small around? might be better.
        # We'll let optimizer handle it.
        pass
    return None


def initial_layout(n):
    """Return a starting layout."""
    kl = known_good_layout(n)
    if kl is not None:
        return kl
    return grid_layout(n)


# ---------- local optimization ----------
def try_perturb(squares, idx, rng, temperature, best_sum):
    """Try to modify square idx, return new squares if improvement, else None."""
    s = list(squares)
    cx, cy, ang, side = s[idx]

    # random perturbation
    # Sometimes change size, sometimes position/angle
    r = rng.random()
    if r < 0.6:
        # adjust size
        delta = rng.uniform(-0.1, 0.1) * temperature
        new_side = max(0.0, side + delta)
        s[idx] = (cx, cy, ang, new_side)
    elif r < 0.9:
        # adjust position
        dx = rng.uniform(-0.05, 0.05) * temperature
        dy = rng.uniform(-0.05, 0.05) * temperature
        s[idx] = (cx + dx, cy + dy, ang, side)
    else:
        # adjust angle
        dang = rng.uniform(-0.1, 0.1) * temperature
        s[idx] = (cx, cy, ang + dang, side)

    # clamp position to stay inside (rough)
    cx, cy, ang, side = s[idx]
    # clamp center so that corners might be inside
    cx = min(max(cx, 0.0), 1.0)
    cy = min(max(cy, 0.0), 1.0)
    s[idx] = (cx, cy, ang, side)

    # check feasibility
    if not inside_unit_square(*s[idx]):
        return None
    # check overlap with others
    for j in range(len(s)):
        if j == idx:
            continue
        if squares_overlap(s[idx], s[j]):
            return None
    return s


def local_improve(squares, rng, time_limit, initial_sum):
    """Run simulated annealing-like local search."""
    n = len(squares)
    best = list(squares)
    best_sum = initial_sum
    cur = list(squares)
    cur_sum = initial_sum

    t0 = time.time()
    temperature = 1.0
    steps = 0
    while time.time() - t0 < time_limit:
        steps += 1
        # pick random square
        idx = rng.randrange(n)
        new_squares = try_perturb(cur, idx, rng, temperature, best_sum)
        if new_squares is None:
            temperature *= 0.9999
            if temperature < 1e-6:
                temperature = 0.1
            continue
        new_sum = sum(sq[3] for sq in new_squares)
        # accept if better or with probability
        if new_sum >= cur_sum or rng.random() < math.exp((new_sum - cur_sum) / max(temperature, 1e-9) * 0.1):
            cur = new_squares
            cur_sum = new_sum
            if new_sum > best_sum:
                best = list(new_squares)
                best_sum = new_sum
        temperature *= 0.9999
        if temperature < 1e-6:
            temperature = 0.5
            # restart from best
            cur = list(best)
            cur_sum = best_sum
    return best, best_sum


def greedy_fill(squares, n, rng, time_limit):
    """Given some squares, try to add more by placing axis-aligned squares in gaps."""
    # This is a fallback: we'll just use grid if nothing better.
    return squares


def solve(n):
    """Main solver."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    best_solution = None
    best_sum = -1.0

    # Try several initializations and local searches
    num_restarts = 5
    time_per_restart = 8.0  # seconds, total < 60

    for restart in range(num_restarts):
        if restart == 0:
            squares = initial_layout(n)
        else:
            # random initial: random centers and small sides
            squares = []
            for _ in range(n):
                cx = rng.uniform(0.1, 0.9)
                cy = rng.uniform(0.1, 0.9)
                ang = rng.uniform(0.0, 1.0)
                side = rng.uniform(0.0, 0.2)
                squares.append((cx, cy, ang, side))
            # make feasible: shrink until feasible
            if not feasible(squares):
                # fallback to grid if random fails
                squares = grid_layout(n)

        init_sum = sum(sq[3] for sq in squares)
        improved, imp_sum = local_improve(squares, rng, time_per_restart, init_sum)
        if imp_sum > best_sum:
            best_sum = imp_sum
            best_solution = improved

    # final check and pad if needed
    if best_solution is None:
        best_solution = grid_layout(n)
    if len(best_solution) < n:
        best_solution += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_solution))
    return best_solution[:n]

# The above code uses a simple local search. To make it faster and more effective,
# we inline the collision checks and use a smarter perturbation strategy.

# Let's refine: We'll implement a more efficient version.
# Actually, let's rewrite the solver with a focus on speed and quality.

import math
import random
import time

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # best known is likely 1.5? Actually can't. Let's use 0.5, 0.5, and a small one.
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5), (0.5, 0.5, 0.0, 0.0)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    # For general n, use a heuristic: try to fit k squares in a kxk grid, then optimize.
    return _general_solve(n)

def _general_solve(n):
    rng = random.Random(987654321 + n)
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i+0.5)*side, (j+0.5)*side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))

    # quick local search for remaining items: try to grow each square
    # We'll do a simple coordinate descent: for each square, try to increase side until blocked.
    # We'll do many iterations.
    t0 = time.time()
    while time.time() - t0 < 10.0:
        improved = False
        for i in range(n):
            cx, cy, ang, sd = squares[i]
            # try to increase side
            # binary search for max side
            lo, hi = sd, 1.0
            for _ in range(20):
                mid = (lo + hi) * 0.5
                test = list(squares)
                test[i] = (cx, cy, ang, mid)
                # check feasibility
                ok = True
                # inside
                if not _inside(cx, cy, ang, mid):
                    ok = False
                else:
                    for j in range(n):
                        if j == i: continue
                        if _overlap(test[i], test[j]):
                            ok = False
                            break
                if ok:
                    lo = mid
                else:
                    hi = mid
            if lo > sd:
                squares[i] = (cx, cy, ang, lo)
                improved = True
        # try to reposition each square
        for i in range(n):
            cx, cy, ang, sd = squares[i]
            best_pos = (cx, cy)
            best_sd = sd
            # try small grid around
            for dx in [-0.02, -0.01, 0, 0.01, 0.02]:
                for dy in [-0.02, -0.01, 0, 0.01, 0.02]:
                    ncx = cx + dx
                    ncy = cy + dy
                    if not _inside(ncx, ncy, ang, sd):
                        continue
                    test = list(squares)
                    test[i] = (ncx, ncy, ang, sd)
                    ok = True
                    for j in range(n):
                        if j == i: continue
                        if _overlap(test[i], test[j]):
                            ok = False
                            break
                    if ok:
                        # try to grow
                        lo, hi = sd, 1.0
                        for _ in range(15):
                            mid = (lo+hi)*0.5
                            test2 = list(squares)
                            test2[i] = (ncx, ncy, ang, mid)
                            if _inside(ncx, ncy, ang, mid) and all(not _overlap(test2[i], test2[j]) for j in range(n) if j != i):
                                lo = mid
                            else:
                                hi = mid
                        if lo > best_sd:
                            best_sd = lo
                            best_pos = (ncx, ncy)
            if best_sd > sd:
                squares[i] = (best_pos[0], best_pos[1], ang, best_sd)
                improved = True
        if not improved:
            break

    # try some random restarts for the zero-size squares
    # Actually, let's use a simple simulated annealing for all squares
    # but only if time permits.
    return squares

def _inside(cx, cy, ang, s):
    if s <= 0:
        return 0 <= cx <= 1 and 0 <= cy <= 1
    t = ang * 2 * math.pi
    c = math.cos(t)
    si = math.sin(t)
    h = s * 0.5
    for lx, ly in ((-h,-h),(h,-h),(h,h),(-h,h)):
        x = cx + lx*c - ly*si
        y = cy + lx*si + ly*c
        if x < -1e-9 or x > 1+1e-9 or y < -1e-9 or y > 1+1e-9:
            return False
    return True

def _overlap(s1, s2):
    if s1[3] <= 0 or s2[3] <= 0:
        return False
    # quick bounding circle
    r1 = s1[3] * 0.5 * math.sqrt(2)
    r2 = s2[3] * 0.5 * math.sqrt(2)
    dx = s1[0] - s2[0]
    dy = s1[1] - s2[1]
    if dx*dx + dy*dy > (r1+r2)**2:
        return False
    # SAT
    def corners(cx, cy, ang, s):
        t = ang * 2 * math.pi
        c = math.cos(t)
        si = math.sin(t)
        h = s * 0.5
        return [(cx + lx*c - ly*si, cy + lx*si + ly*c) for lx, ly in ((-h,-h),(h,-h),(h,h),(-h,h))]
    p1 = corners(*s1)
    p2 = corners(*s2)
    def axes(pts):
        axs = []
        for i in range(4):
            x1,y1 = pts[i]
            x2,y2 = pts[(i+1)%4]
            dx_ = x2-x1
            dy_ = y2-y1
            axs.append((-dy_, dx_))
        return axs
    for ax in axes(p1) + axes(p2):
        dots1 = [px*ax[0]+py*ax[1] for px,py in p1]
        dots2 = [px*ax[0]+py*ax[1] for px,py in p2]
        if max(dots1) <= min(dots2) or max(dots2) <= min(dots1):
            return False
    return True

# Final version: use the above _general_solve but with longer time and better restarts.
# Also handle n=3 optimally: three squares can be packed as 0.5, 0.5, and a small one in corner?
# Actually, for n=3, best is two 0.5 squares and one more? No, can't fit third.
# Known result: max sum for n=3 is about 1.4142 (two 0.5 and one 0.4142 diagonal?).
# Let's just let the solver handle it, but for n=3 we can use a known good: three squares in a row? No.
# We'll trust the general solver.

# Let's make the general solver stronger by trying multiple initial configurations.

def solve(n):
    if n <= 0: return []
    if n == 1: return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2: return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    rng = random.Random(42)
    best = None
    best_sum = -1

    # try several initial layouts and optimize each
    time_budget = 50.0
    t_start = time.time()

    # start with grid
    k = math.isqrt(n)
    side = 1.0/k
    init = []
    for i in range(k):
        for j in range(k):
            init.append(((i+0.5)*side, (j+0.5)*side, 0.0, side))
    while len(init) < n:
        init.append((0.5, 0.5, 0.0, 0.0))

    # optimize from grid
    result = _optimize(init, n, rng, time_budget * 0.8)
    s = sum(sq[3] for sq in result)
    if s > best_sum:
        best_sum = s
        best = result

    # try random initial
    for _ in range(3):
        if time.time() - t_start > time_budget:
            break
        init2 = []
        for _ in range(n):
            init2.append((rng.uniform(0.1,0.9), rng.uniform(0.1,0.9), rng.uniform(0,1), rng.uniform(0,0.15)))
        # make feasible
        if not _feasible(init2):
            init2 = [ (sq[0], sq[1], sq[2], 0.0) for sq in init2 ]
        result2 = _optimize(init2, n, rng, 10.0)
        s2 = sum(sq[3] for sq in result2)
        if s2 > best_sum:
            best_sum = s2
            best = result2

    return best

def _feasible(squares):
    n = len(squares)
    for i in range(n):
        if not _inside(*squares[i]):
            return False
    for i in range(n):
        if squares[i][3] <= 0: continue
        for j in range(i+1, n):
            if squares[j][3] <= 0: continue
            if _overlap(squares[i], squares[j]):
                return False
    return True

def _optimize(squares, n, rng, time_limit):
    """Improved local search with coordinate descent and random perturbations."""
    t0 = time.time()
    cur = list(squares)
    cur_sum = sum(sq[3] for sq in cur)
    best = list(cur)
    best_sum = cur_sum

    # phase 1: deterministic coordinate descent (try to grow each square)
    improved = True
    while improved and time.time() - t0 < time_limit * 0.5:
        improved = False
        for i in range(n):
            cx, cy, ang, sd = cur[i]
            # try growing
            lo, hi = sd, 1.0
            for _ in range(25):
                mid = (lo+hi)*0.5
                test = list(cur)
                test[i] = (cx, cy, ang, mid)
                ok = _inside(cx, cy, ang, mid)
                if ok:
                    for j in range(n):
                        if j == i: continue
                        if _overlap(test[i], test[j]):
                            ok = False; break
                if ok:
                    lo = mid
                else:
                    hi = mid
            if lo > sd + 1e-9:
                cur[i] = (cx, cy, ang, lo)
                improved = True
        # try moving each square to a better position
        for i in range(n):
            cx, cy, ang, sd = cur[i]
            best_local = (cx, cy, sd)
            for dx in [-0.05, -0.02, -0.01, 0, 0.01, 0.02, 0.05]:
                for dy in [-0.05, -0.02, -0.01, 0, 0.01, 0.02, 0.05]:
                    ncx = cx + dx
                    ncy = cy + dy
                    if not _inside(ncx, ncy, ang, sd):
                        continue
                    test = list(cur)
                    test[i] = (ncx, ncy, ang, sd)
                    ok = True
                    for j in range(n):
                        if j == i: continue
                        if _overlap(test[i], test[j]):
                            ok = False; break
                    if ok:
                        # try to grow at new position
                        lo, hi = sd, 1.0
                        for _ in range(20):
                            mid = (lo+hi)*0.5
                            test2 = list(cur)
                            test2[i] = (ncx, ncy, ang, mid)
                            if _inside(ncx, ncy, ang, mid) and all(not _overlap(test2[i], test2[j]) for j in range(n) if j != i):
                                lo = mid
                            else:
                                hi = mid
                        if lo > best_local[2] + 1e-9:
                            best_local = (ncx, ncy, lo)
            if best_local[2] > sd + 1e-9:
                cur[i] = (best_local[0], best_local[1], ang, best_local[2])
                improved = True
        cur_sum = sum(sq[3] for sq in cur)
        if cur_sum > best_sum:
            best = list(cur)
            best_sum = cur_sum

    # phase 2: random search (simulated annealing)
    while time.time() - t0 < time_limit:
        i = rng.randrange(n)
        cx, cy, ang, sd = cur[i]
        # random perturbation
        r = rng.random()
        if r < 0.5:
            nsd = max(0.0, sd + rng.uniform(-0.05, 0.05))
            ncx, ncy, nang = cx, cy, ang
        elif r < 0.8:
            ncx = cx + rng.uniform(-0.05, 0.05)
            ncy = cy + rng.uniform(-0.05, 0.05)
            nsd = sd
            nang = ang
        else:
            nang = ang + rng.uniform(-0.1, 0.1)
            ncx, ncy, nsd = cx, cy, sd
        ncx = min(max(ncx, 0.0), 1.0)
        ncy = min(max(ncy, 0.0), 1.0)
        test = list(cur)
        test[i] = (ncx, ncy, nang, nsd)
        ok = _inside(ncx, ncy, nang, nsd)
        if ok:
            for j in range(n):
                if j == i: continue
                if _overlap(test[i], test[j]):
                    ok = False; break
        if ok:
            new_sum = sum(sq[3] for sq in test)
            if new_sum >= cur_sum:
                cur = test
                cur_sum = new_sum
                if new_sum > best_sum:
                    best = list(test)
                    best_sum = new_sum
            else:
                # accept with small probability
                T = 0.01
                if rng.random() < math.exp((new_sum - cur_sum)/T):
                    cur = test
                    cur_sum = new_sum

    return best

# Note: The above is a bit slow due to Python loops. We'll optimize by reducing n for large n.
# For large n, we can use a simpler approach: grid + local search on a few squares.

# Final solve function:
def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # best known: two 0.5 and one small in corner? Let's try: 0.5, 0.5, and 0.0
        # Actually, three squares can be packed as 0.5, 0.5, and a 0.0? Not great.
        # Let's use solver.
        pass

    rng = random.Random(12345 + n)
    # For large n, just use grid and optimize a bit.
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))

    # If n is large, don't spend too much time.
    if n > 30:
        # just return grid (fast)
        return squares

    # For small n, use optimization.
    return _optimize(squares, n, rng, 20.0)

# The code above is not the final answer; I'll provide a cleaner version below.

<change>
I will use a global optimization strategy: for each n, build an initial layout using the best known packings for small n (grid for perfect squares, optimal known patterns for key n values where possible), then run a simulated-annealing / coordinate-descent refinement that perturbs centers, angles, and sizes with collision checking (using separating axis theorem for rotated squares) to maximize the sum of side lengths. Where direct search is too slow, a fast greedy strip-packing heuristic with local corrections will fill remaining slots, and since zero-size squares are allowed, I can always pad to exactly n entries. For maximum robustness across all n, I will run multiple restarts within a time budget and keep the best feasible solution.
</change>

