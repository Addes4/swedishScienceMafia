import math
import random

EPS = 1e-12


def _corners(cx, cy, angle, side):
    """Return the four corners of a square."""
    a = angle * 2.0 * math.pi
    c = math.cos(a)
    s = math.sin(a)
    h = side * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for lx, ly in pts:
        x = cx + c * lx - s * ly
        y = cy + s * lx + c * ly
        out.append((x, y))
    return out


def _inside_unit(cx, cy, angle, side):
    h = side * 0.5
    if h <= 0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    for x, y in _corners(cx, cy, angle, side):
        if x < -EPS or x > 1.0 + EPS or y < -EPS or y > 1.0 + EPS:
            return False
    return True


def _project(poly, axis):
    ax, ay = axis
    vals = [px * ax + py * ay for px, py in poly]
    return min(vals), max(vals)


def _overlap(poly1, poly2):
    """Separating axis test. Return True if interiors overlap."""
    for poly in (poly1, poly2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            edge = (x2 - x1, y2 - y1)
            axis = (-edge[1], edge[0])
            n = math.hypot(axis[0], axis[1])
            if n < 1e-15:
                continue
            axis = (axis[0] / n, axis[1] / n)
            lo1, hi1 = _project(poly1, axis)
            lo2, hi2 = _project(poly2, axis)
            if hi1 <= lo2 + 1e-11 or hi2 <= lo1 + 1e-11:
                return False
    return True


def _valid(squares, cx, cy, angle, side):
    if not _inside_unit(cx, cy, angle, side):
        return False
    if side <= 0:
        return True
    newp = _corners(cx, cy, angle, side)
    for (sx, sy, sa, ss) in squares:
        if ss <= 0:
            continue
        other = _corners(sx, sy, sa, ss)
        if _overlap(newp, other):
            return False
    return True


def _sum(squares):
    return sum(s[3] for s in squares)


def _grid_solution(n):
    """Largest k x k grid plus zero-size squares."""
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _improve(n, squares, deadline_iters=250, rng=None):
    """Try to enlarge existing squares or add larger ones by local search."""
    if rng is None:
        rng = random.Random(12345)
    best = [list(s) for s in squares]

    # For each zero or small square, try to insert a positive square
    for it in range(deadline_iters):
        # Try replace zeros
        zeros = [i for i, s in enumerate(best) if s[3] <= 1e-15]
        if not zeros:
            break
        idx = zeros[it % len(zeros)]
        # try a size that may fit
        improved = False
        for size_guess in (0.4, 0.3, 0.25, 0.2, 0.15, 0.1, 0.07, 0.05):
            for _ in range(20):
                cx = rng.uniform(size_guess / 2, 1 - size_guess / 2)
                cy = rng.uniform(size_guess / 2, 1 - size_guess / 2)
                ang = rng.choice([0.0, 0.25, 0.5, 0.75])
                others = [best[j] for j in range(n) if j != idx]
                if _valid(others, cx, cy, ang, size_guess):
                    best[idx] = [cx, cy, ang, size_guess]
                    improved = True
                    break
            if improved:
                break
        if not improved:
            # this zero cannot be improved in this round
            pass

    # Try enlarging all squares
    max_side = 1.0
    for _ in range(300):
        changed = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, side = best[i]
            others = [best[j] for j in range(n) if j != i]
            # binary search for max side keeping same center/angle
            lo = side
            hi = max(side, 1.0)
            # expand upper bound until invalid
            if _valid(others, cx, cy, ang, hi):
                best[i] = [cx, cy, ang, hi]
                changed = True
                continue
            for _ in range(30):
                mid = (lo + hi) / 2
                if _valid(others, cx, cy, ang, mid):
                    lo = mid
                else:
                    hi = mid
            if lo > side + 1e-10:
                best[i] = [cx, cy, ang, lo]
                changed = True
        if not changed:
            break

    return [tuple(s) for s in best]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # empirically good: two halves on bottom, one square on top
        return [
            (0.25, 0.25, 0.0, 0.5),
            (0.75, 0.25, 0.0, 0.5),
            (0.5, 0.75, 0.0, 0.5),
        ]
    if n == 4:
        return [
            (0.25, 0.25, 0.0, 0.5),
            (0.75, 0.25, 0.0, 0.5),
            (0.25, 0.75, 0.0, 0.5),
            (0.75, 0.75, 0.0, 0.5),
        ]
    if n == 5:
        return [
            (0.25, 0.25, 0.0, 0.5),
            (0.75, 0.25, 0.0, 0.5),
            (0.25, 0.75, 0.0, 0.5),
            (0.75, 0.75, 0.0, 0.5),
            (0.5, 0.5, 0.0, 0.0),
        ]

    # General case
    base = _grid_solution(n)
    rng = random.Random(987654321 + n)

    # Try multiple random restarts, keep best
    best = base
    best_score = _sum(base)

    restarts = 6
    for r in range(restarts):
        cand = [list(s) for s in base]
        # random jitter of centers for nonzero squares
        for i in range(n):
            if cand[i][3] > 0:
                side = cand[i][3]
                # shrink slightly to allow jitter
                cand[i][3] = side * 0.98
                # jitter center
                cx, cy, ang, _ = cand[i]
                cand[i][0] = min(max(cx + rng.uniform(-0.01, 0.01), side / 2), 1 - side / 2)
                cand[i][1] = min(max(cy + rng.uniform(-0.01, 0.01), side / 2), 1 - side / 2)
        # remove overlaps by shrinking offending squares (simple pass)
        for _ in range(5):
            for i in range(n):
                for j in range(i + 1, n):
                    si = cand[i]
                    sj = cand[j]
                    if si[3] <= 0 or sj[3] <= 0:
                        continue
                    pi = _corners(*si)
                    pj = _corners(*sj)
                    if _overlap(pi, pj):
                        # shrink smaller one
                        if si[3] < sj[3]:
                            cand[i][3] *= 0.9
                        else:
                            cand[j][3] *= 0.9

        improved = _improve(n, cand, deadline_iters=150, rng=rng)
        score = _sum(improved)
        if score > best_score + 1e-9:
            best_score = score
            best = improved

    # Validate and fix invalid solutions
    out = []
    for (cx, cy, ang, side) in best:
        if side < 0:
            side = 0.0
        # clamp center inside bounding circle
        h = side * 0.5
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        # shrink if invalid
        while side > 0 and not _inside_unit(cx, cy, ang, side):
            side *= 0.99
            if side < 1e-12:
                side = 0.0
                break
        out.append((cx, cy, ang, side))

    # Final overlap removal by shrinking
    for _ in range(10):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                si = out[i]
                sj = out[j]
                if si[3] <= 0 or sj[3] <= 0:
                    continue
                pi = _corners(*si)
                pj = _corners(*sj)
                if _overlap(pi, pj):
                    if si[3] < sj[3]:
                        ns = si[3] * 0.9
                        out[i] = (si[0], si[1], si[2], ns)
                    else:
                        ns = sj[3] * 0.9
                        out[j] = (sj[0], sj[1], sj[2], ns)
                    changed = True
        if not changed:
            break

    # Clamp to [0,1]
    final = []
    for (cx, cy, ang, side) in out:
        if side <= 0:
            final.append((min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), 0.0, 0.0))
        else:
            h = side * 0.5
            # ensure inside by shrinking
            while side > 0 and not _inside_unit(cx, cy, ang, side):
                side *= 0.99
            if side < 1e-12:
                final.append((min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), 0.0, 0.0))
            else:
                final.append((cx, cy, ang, side))

    # ensure exactly n
    while len(final) < n:
        final.append((0.5, 0.5, 0.0, 0.0))
    return final[:n]
