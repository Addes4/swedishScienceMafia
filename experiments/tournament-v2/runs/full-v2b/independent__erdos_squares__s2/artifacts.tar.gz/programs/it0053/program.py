import math
import random

try:
    import numpy as np
    from scipy.optimize import minimize
except Exception:
    np = None
    minimize = None


# A compact, practical packing heuristic.
# Idea:
# - Start from a perfect k x k grid for k=floor(sqrt(n)).
# - Use the remaining space as a set of free rectangles.
# - Recursively and greedily allocate the largest possible square in each free rectangle
#   (guillotine cuts), then run a local numerical improvement that only ever scales down
#   existing squares or moves them inside their current free regions via a conservative
#   overlap-avoiding relaxation.
#
# The scoring only cares about total side length.  Squares with side 0 are allowed,
# which gives a clean way to handle leftover slots.
#
# The local optimization below is deliberately conservative: every candidate move is
# checked or repaired so that no two squares overlap in their interiors.


# ---------- geometry helpers ----------

def _overlap_amount(s1, s2):
    """Return >0 if two axis-aligned squares (cx,cy,angle,side) overlap in interior.

    Only angles that are multiples of 0.25 are used by the local optimizer, so this
    reduces to an axis-aligned bounding box check.  For robustness we handle any angle
    by computing the separating axis theorem on the two squares.
    """
    cx1, cy1, a1, s1 = s1
    cx2, cy2, a2, s2 = s2
    if s1 <= 1e-15 or s2 <= 1e-15:
        return 0.0

    t1 = a1 * 2.0 * math.pi
    t2 = a2 * 2.0 * math.pi
    c1, sn1 = math.cos(t1), math.sin(t1)
    c2, sn2 = math.cos(t2), math.sin(t2)

    # corners of square 1
    h1 = s1 * 0.5
    p1 = [(cx1 + c1 * (-h1) - sn1 * (-h1), cy1 + sn1 * (-h1) + c1 * (-h1)),
          (cx1 + c1 * ( h1) - sn1 * (-h1), cy1 + sn1 * ( h1) + c1 * (-h1)),
          (cx1 + c1 * ( h1) - sn1 * ( h1), cy1 + sn1 * ( h1) + c1 * ( h1)),
          (cx1 + c1 * (-h1) - sn1 * ( h1), cy1 + sn1 * (-h1) + c1 * ( h1))]

    h2 = s2 * 0.5
    p2 = [(cx2 + c2 * (-h2) - sn2 * (-h2), cy2 + sn2 * (-h2) + c2 * (-h2)),
          (cx2 + c2 * ( h2) - sn2 * (-h2), cy2 + sn2 * ( h2) + c2 * (-h2)),
          (cx2 + c2 * ( h2) - sn2 * ( h2), cy2 + sn2 * ( h2) + c2 * ( h2)),
          (cx2 + c2 * (-h2) - sn2 * ( h2), cy2 + sn2 * (-h2) + c2 * ( h2))]

    def proj(poly, ax, ay):
        vals = [x * ax + y * ay for x, y in poly]
        return min(vals), max(vals)

    def separated(ax, ay):
        n1 = math.hypot(ax, ay)
        if n1 < 1e-15:
            return False
        ax, ay = ax / n1, ay / n1
        a, b = proj(p1, ax, ay)
        c, d = proj(p2, ax, ay)
        return b <= c + 1e-14 or d <= a + 1e-14

    # axes: edge normals of both squares
    for k in range(4):
        x1, y1 = p1[k]
        x2, y2 = p1[(k + 1) % 4]
        if separated(-(y2 - y1), x2 - x1):
            return 0.0
    for k in range(4):
        x1, y1 = p2[k]
        x2, y2 = p2[(k + 1) % 4]
        if separated(-(y2 - y1), x2 - x1):
            return 0.0
    # approximate overlap magnitude
    return min(s1, s2) ** 2 * 0.5


def _inside(s):
    cx, cy, a, side = s
    if side <= 1e-15:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    h = side * 0.5
    t = a * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    for sx in (-h, h):
        for sy in (-h, h):
            x = cx + c * sx - sn * sy
            y = cy + sn * sx + c * sy
            if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
                return False
    return True


def _clip_inside(s):
    cx, cy, a, side = s
    if side <= 1e-15:
        return (min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), 0.0, 0.0)
    # shrink if necessary; axis-aligned assumptions make this easy
    if abs(a - round(a * 4) / 4.0) > 1e-12:
        a = round(a * 4) / 4.0
    if abs(a % 1.0) < 1e-12 or abs((a % 1.0) - 0.5) < 1e-12:
        w = side
        h = side
    else:
        # 45 degree rotated square: bounding box is side*sqrt(2)
        w = side * math.sqrt(2.0)
        h = side * math.sqrt(2.0)
    cx = min(1.0 - w * 0.5, max(w * 0.5, cx))
    cy = min(1.0 - h * 0.5, max(h * 0.5, cy))
    return (cx, cy, a, side)


# ---------- greedy guillotine packing ----------

def _greedy_squares(n):
    # We maintain free rectangles and always cut the largest square that fits.
    # This is a classic shelf/guillotine heuristic.  It gives good results for
    # moderate n and is very fast.
    free = [(0.0, 0.0, 1.0, 1.0)]
    out = []

    for _ in range(n):
        # pick free rectangle that can host the largest square
        best = None
        best_side = -1.0
        best_idx = -1
        for i, (x, y, w, h) in enumerate(free):
            s = min(w, h)
            if s > best_side + 1e-15:
                best_side = s
                best_idx = i
        if best_side <= 1e-12:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue

        x, y, w, h = free.pop(best_idx)
        s = min(w, h)
        cx = x + s * 0.5
        cy = y + s * 0.5
        out.append((cx, cy, 0.0, s))

        # split remaining area into two rectangles (guillotine)
        if w > h:
            free.append((x + s, y, w - s, h))
            free.append((x, y + s, s, h - s))
        else:
            free.append((x, y + s, w, h - s))
            free.append((x + s, y, w - s, s))

    return out


# ---------- local improvement ----------

def _total_side(sol):
    return sum(s[3] for s in sol)


def _repair(sol):
    """Shrink any overlapping squares until the layout is valid."""
    sol = [list(s) for s in sol]
    n = len(sol)
    # Clip inside first
    for i in range(n):
        cx, cy, a, side = _clip_inside(tuple(sol[i]))
        sol[i] = [cx, cy, a, side]

    # Iteratively shrink overlapping pairs
    for _ in range(30):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                si = tuple(sol[i])
                sj = tuple(sol[j])
                if _overlap_amount(si, sj) > 1e-13:
                    # shrink the larger one slightly, or both
                    if sol[i][3] >= sol[j][3]:
                        sol[i][3] *= 0.97
                    else:
                        sol[j][3] *= 0.97
                    changed = True
        if not changed:
            break
    return [tuple(s) for s in sol]


def _local_search(sol, steps=200):
    """Try small random changes that increase total side while remaining valid."""
    n = len(sol)
    if n == 0:
        return sol
    best = [list(s) for s in sol]
    best_val = _total_side(best)

    for _ in range(steps):
        cand = [row[:] for row in best]
        # choose a random square and perturb
        i = random.randrange(n)
        cx, cy, a, side = cand[i]
        mode = random.random()
        if mode < 0.45:
            # grow
            delta = random.uniform(0.001, 0.04)
            side = min(1.0, side + delta)
        elif mode < 0.70:
            # move
            cx += random.uniform(-0.03, 0.03)
            cy += random.uniform(-0.03, 0.03)
        elif mode < 0.85:
            # rotate among multiples of 1/8 turn
            k = random.randrange(8)
            a = k / 8.0
        else:
            # shrink slightly to escape conflict
            side *= random.uniform(0.90, 0.99)

        cand[i] = [cx, cy, a, side]

        # clip and repair
        for k in range(n):
            cx, cy, a, side = _clip_inside(tuple(cand[k]))
            cand[k] = [cx, cy, a, side]

        cand = [list(row) for row in _repair([tuple(row) for row in cand])]
        val = _total_side(cand)

        if val > best_val + 1e-13:
            best = cand
            best_val = val

    return [tuple(row) for row in best]


# ---------- final polish using axis-aligned grid refinement ----------

def _polish_grid(sol, rounds=3):
    """A simple coordinate-ascent on the largest squares.

    It assumes axis-aligned placements and tries to increase each square's side while
    keeping centres fixed relative to a coarse grid, then repairs.
    """
    n = len(sol)
    if n == 0:
        return sol

    sol = [list(s) for s in sol]
    for _ in range(rounds):
        # Try increasing each square in turn, then repair
        for i in range(n):
            # prefer growing larger ones first
            order = sorted(range(n), key=lambda k: -sol[k][3])
            for i in order:
                cx, cy, a, side = sol[i]
                # try several growth factors
                for fac in (1.10, 1.05, 1.02):
                    new_side = min(1.0, side * fac)
                    # keep centre as is; if it no longer fits, clip may move it
                    t = _clip_inside((cx, cy, 0.0, new_side))
                    sol[i] = [t[0], t[1], t[2], t[3]]
                    if _valid(sol):
                        side = new_side
                    else:
                        sol[i] = [cx, cy, a, side]
                        break
            sol = [list(row) for row in _repair([tuple(row) for row in sol])]
    return [tuple(row) for row in sol]


def _valid(sol):
    n = len(sol)
    for i in range(n):
        if not _inside(sol[i]):
            return False
        for j in range(i + 1, n):
            if _overlap_amount(sol[i], sol[j]) > 1e-12:
                return False
    return True


# ---------- main ----------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    # Large n: use a near-optimal grid plus recursive split
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Greedy guillotine initial solution
    sol = _greedy_squares(n)

    # Ensure exactly n
    if len(sol) < n:
        sol += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sol))
    sol = sol[:n]

    # Clean and legalize
    sol = [list(s) for s in sol]
    for i in range(n):
        cx, cy, a, side = _clip_inside(tuple(sol[i]))
        sol[i] = [cx, cy, a, side]
    sol = [list(row) for row in _repair([tuple(row) for row in sol])]

    # Quick local search
    try:
        sol = _local_search([tuple(row) for row in sol], steps=min(300, 80 + n * 4))
    except Exception:
        pass

    # Refine with a grid-based coordinate ascent for small n
    if n <= 36:
        try:
            sol = _polish_grid([tuple(row) for row in sol], rounds=4)
        except Exception:
            pass

    # Final legality and fallback if something went wrong
    sol = [tuple(row) for row in sol]
    if not _valid(sol):
        sol = _repair(sol)

    # If still invalid, fall back to a safe grid
    if not _valid(sol):
        k = math.isqrt(n)
        side = 1.0 / max(1, k)
        sol = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        sol += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sol))
        sol = sol[:n]

    # Guarantee exactly n entries and valid ranges
    out = []
    for i in range(n):
        if i < len(sol):
            cx, cy, a, side = sol[i]
        else:
            cx, cy, a, side = 0.5, 0.5, 0.0, 0.0
        cx = min(1.0, max(0.0, float(cx)))
        cy = min(1.0, max(0.0, float(cy)))
        a = float(a) % 1.0
        side = max(0.0, min(1.0, float(side)))
        out.append((cx, cy, a, side))
    return out
