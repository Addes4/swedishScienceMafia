import math
import numpy as np
from scipy.optimize import minimize

# ---------- geometry helpers ----------

def corners(cx, cy, a, s):
    """Return 4x2 array of corner coordinates of rotated square."""
    t = 2.0 * math.pi * a
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    # local axes
    ax = np.array([c, sn])
    ay = np.array([-sn, c])
    pts = []
    for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append([cx + sx * ax[0] + sy * ay[0],
                    cy + sx * ax[1] + sy * ay[1]])
    return np.array(pts)

def sat_overlap(A, B):
    """Separating axis check for convex polygons. Returns True if interiors overlap."""
    for poly in (A, B):
        n = len(poly)
        for i in range(n):
            p1 = poly[i]
            p2 = poly[(i + 1) % n]
            edge = p2 - p1
            axis = np.array([-edge[1], edge[0]])
            L = np.hypot(axis[0], axis[1])
            if L < 1e-15:
                continue
            axis = axis / L
            amin = np.min(A @ axis)
            amax = np.max(A @ axis)
            bmin = np.min(B @ axis)
            bmax = np.max(B @ axis)
            if amax <= bmin + 1e-9 or bmax <= amin + 1e-9:
                return False
    return True

def penalty(params, n):
    """Negative sum of sides + large overlap/boundary penalty."""
    # params: [cx, cy, a, s] repeated
    total = 0.0
    pen = 0.0
    polys = []
    for i in range(n):
        cx, cy, a, s = params[4*i:4*i+4]
        if s < 0:
            s = 0.0
        a = a % 1.0
        total += s
        P = corners(cx, cy, a, s)
        polys.append(P)
        # boundary: ensure all corners inside [0,1]^2
        for x, y in P:
            if x < -1e-9:
                pen += 1e4 * (-x + 1e-3)
            if x > 1 + 1e-9:
                pen += 1e4 * (x - 1 + 1e-3)
            if y < -1e-9:
                pen += 1e4 * (-y + 1e-3)
            if y > 1 + 1e-9:
                pen += 1e4 * (y - 1 + 1e-3)
    # overlaps
    for i in range(n):
        for j in range(i+1, n):
            if sat_overlap(polys[i], polys[j]):
                pen += 1e5
    return -total + pen

# ---------- initial configurations ----------

def grid_init(n, k=None):
    """k x (k+1) or similar grid for n."""
    best = None
    # try rectangular grids
    for a in range(1, n+1):
        b = (n + a - 1) // a
        if a*b < n:
            continue
        s = min(1.0/a, 1.0/b)
        sq = []
        cnt = 0
        for i in range(a):
            for j in range(b):
                if cnt >= n:
                    break
                sq.append(((i+0.5)*s, (j+0.5)*s, 0.0, s))
                cnt += 1
            if cnt >= n:
                break
        val = sum(x[3] for x in sq)
        if best is None or val > best[0]:
            best = (val, sq)
    return best[1]

def hex_init(n):
    """Approximate hexagonal arrangement."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # choose rows
    best = None
    for rows in range(1, n+1):
        cols = (n + rows - 1)//rows
        # side fit in cell
        w = 1.0 / cols
        h = 1.0 / rows
        s = min(w, h)
        sq = []
        for r in range(rows):
            for c in range(cols):
                if len(sq) >= n:
                    break
                x = (c + 0.5) * w + (0.5*w if (r%2) else 0.0)
                y = (r + 0.5) * h
                if x + s*0.5 > 1.0:
                    x = 1.0 - s*0.5
                sq.append((x, y, 0.0, s))
            if len(sq) >= n:
                break
        val = sum(t[3] for t in sq)
        if best is None or val > best[0]:
            best = (val, sq)
    return best[1]

def known_small(n):
    """Some known good configurations for small n."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25,0.25,0,0.5),(0.75,0.25,0,0.5),(0.25,0.75,0,0.5),(0.75,0.75,0,0.5)]
    if n == 5:
        # central square and four corners
        s = 0.5
        return [(0.25,0.25,0,s),(0.75,0.25,0,s),(0.25,0.75,0,s),(0.75,0.75,0,s),(0.5,0.5,0,0.5)]
    if n == 6:
        s = 1.0/3.0
        return [(0.5,0.5,0,s),(0.5,0.5+ s,0,s),(0.5,0.5-s,0,s),(0.5-s,0.5,0,s),(0.5+s,0.5,0,s),
                (0.5-s/2,0.5-s/2,0,s)]
    # general fallback
    return None

def initial_params(squares):
    p = []
    for cx, cy, a, s in squares:
        p.extend([cx, cy, a, s])
    return np.array(p)

def params_to_squares(params):
    sq = []
    for i in range(len(params)//4):
        cx, cy, a, s = params[4*i:4*i+4]
        s = max(0.0, s)
        a = a % 1.0
        sq.append((float(cx), float(cy), float(a), float(s)))
    return sq

# ---------- main solve ----------

def solve(n):
    if n <= 0:
        return []
    # try known seeds
    best_sq = None
    best_val = -1.0

    seeds = []
    k = known_small(n)
    if k is not None:
        seeds.append(k)
    seeds.append(grid_init(n))
    seeds.append(hex_init(n))
    # also random-ish seeds based on grids with random angles
    for _ in range(5):
        kk = math.isqrt(n)
        if kk == 0:
            kk = 1
        s = 1.0 / kk
        sq = []
        for i in range(kk):
            for j in range(kk):
                if len(sq) >= n:
                    break
                sq.append(((i+0.5)*s, (j+0.5)*s, np.random.uniform(0,0.25), s))
            if len(sq) >= n:
                break
        while len(sq) < n:
            sq.append((0.5,0.5,0,0.0))
        seeds.append(sq)

    # bounds: cx,cy,a,s
    bounds = []
    for _ in range(n):
        bounds.extend([(0.0,1.0),(0.0,1.0),(0.0,1.0),(0.0,1.0)])

    for seed in seeds:
        if len(seed) != n:
            continue
        x0 = initial_params(seed)
        try:
            res = minimize(lambda p: penalty(p, n), x0, method='SLSQP',
                           bounds=bounds, options={'maxiter': 200, 'ftol': 1e-9})
            sq = params_to_squares(res.x)
            # repair: set tiny negatives to 0
            sq = [(cx,cy,a,max(0.0,s)) for cx,cy,a,s in sq]
            # check feasibility, if not, keep as is (penalty already large)
            val = sum(s for _,_,_,s in sq)
            if val > best_val:
                best_val = val
                best_sq = sq
        except Exception:
            pass

    if best_sq is None:
        best_sq = grid_init(n)

    # ensure exactly n
    while len(best_sq) < n:
        best_sq.append((0.5,0.5,0.0,0.0))
    return best_sq[:n]
