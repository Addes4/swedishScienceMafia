import math
import random
import numpy as np


def _rot_square(cx, cy, a, s):
    ca, sa = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * ca - dy * sa
        y = cy + dx * sa + dy * ca
        pts.append((x, y))
    return pts


def _inside(pts):
    for x, y in pts:
        if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
            return False
    return True


def _axis(cx, cy, a, s):
    ca, sa = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
    ux, uy = ca, sa
    vx, vy = -sa, ca
    h = s * 0.5
    return (cx - h * ux - h * vx, cy - h * uy - h * vy,
            cx + h * ux - h * vx, cy + h * uy - h * vy,
            cx - h * ux + h * vx, cy - h * uy + h * vy,
            cx + h * ux + h * vx, cy + h * uy + h * vy)


def _sat_overlap(sq1, sq2):
    ax1, ay1, ax2, ay2, ax3, ay3, ax4, ay4 = sq1
    bx = [sq2[0], sq2[2], sq2[4], sq2[6]]
    by = [sq2[1], sq2[3], sq2[5], sq2[7]]
    axes = []
    for pts in ((ax1, ay1, ax2, ay2), (ax2, ay2, ax3, ay3),
                (bx[0], by[0], bx[1], by[1]), (bx[1], by[1], bx[2], by[2])):
        ex = pts[2] - pts[0]
        ey = pts[3] - pts[1]
        ln = math.hypot(ex, ey)
        if ln > 1e-15:
            axes.append((-ey / ln, ex / ln))
    best = 1e9
    a_pts = ((ax1, ay1), (ax2, ay2), (ax3, ay3), (ax4, ay4))
    b_pts = ((bx[0], by[0]), (bx[1], by[1]), (bx[2], by[2]), (bx[3], by[3]))
    for nx, ny in axes:
        amin, amax = 1e9, -1e9
        for x, y in a_pts:
            p = x * nx + y * ny
            if p < amin: amin = p
            if p > amax: amax = p
        bmin, bmax = 1e9, -1e9
        for x, y in b_pts:
            p = x * nx + y * ny
            if p < bmin: bmin = p
            if p > bmax: bmax = p
        ov = min(amax, bmax) - max(amin, bmin)
        if ov < best: best = ov
    return max(0.0, best)


def _sep_dist(ax, ay, a, s1, bx, by, b, s2):
    q1 = _axis(ax, ay, a, s1)
    q2 = _axis(bx, by, b, s2)
    return _sat_overlap(q1, q2)


def _total_overlap(sqs):
    n = len(sqs)
    tot = 0.0
    for i in range(n):
        if sqs[i][3] <= 0: continue
        for j in range(i + 1, n):
            if sqs[j][3] <= 0: continue
            tot += _sep_dist(*sqs[i], *sqs[j])
    return tot


def _out_penalty(sqs):
    p = 0.0
    for cx, cy, a, s in sqs:
        if s <= 0: continue
        ca, sa = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
        h = s * 0.5
        ex = abs(ca) * h + abs(sa) * h
        ey = abs(sa) * h + abs(ca) * h
        if cx - ex < 0: p += (ex - cx) ** 2
        if cx + ex > 1: p += (cx + ex - 1) ** 2
        if cy - ey < 0: p += (ey - cy) ** 2
        if cy + ey > 1: p += (cy + ey - 1) ** 2
    return p


def _obj(sqs):
    return sum(s for _, _, _, s in sqs) - 500.0 * _out_penalty(sqs) - 200.0 * _total_overlap(sqs)


def _feasible(sqs):
    if _out_penalty(sqs) > 1e-9:
        return False
    if _total_overlap(sqs) > 1e-9:
        return False
    return True


def _grid(n, k):
    side = 1.0 / k
    sqs = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    return sqs[:n]


def _pack_rows(n):
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    best = None
    best_score = -1
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if cols * rows < n: continue
        s = min(1.0 / rows, 1.0 / cols)
        count = 0
        sqs = []
        for r in range(rows):
            for c in range(cols):
                if count < n:
                    sqs.append(((c + 0.5) * s, (r + 0.5) * s, 0.0, s))
                    count += 1
        sc = sum(x[3] for x in sqs)
        if sc > best_score:
            best_score = sc
            best = sqs
    return best


def _greedy_spiral(n):
    sqs = []
    rng = random.Random(12345 + n)
    for i in range(n):
        best_c = None
        best_s = -1
        for _ in range(40):
            cx = rng.random()
            cy = rng.random()
            a = rng.choice([0.0, 0.25, 0.125, 0.375, 0.5])
            lim = min(cx, cy, 1 - cx, 1 - cy) * 2
            if i == 0: lim = 1.0
            s = lim * (0.4 + 0.6 * rng.random())
            if s <= 0: continue
            ok = True
            for bx, by, ba, bs in sqs:
                if _sep_dist(cx, cy, a, s, bx, by, ba, bs) > 1e-10:
                    ok = False
                    break
            if ok and _inside(_rot_square(cx, cy, a, s)):
                if s > best_s:
                    best_s = s
                    best_c = (cx, cy, a, s)
        if best_c is None:
            best_c = (0.5, 0.5, 0.0, 0.0)
        sqs.append(best_c)
    return sqs


def _local_improve(sqs, iters=3000, rng=None):
    if rng is None:
        rng = random.Random(999)
    n = len(sqs)
    sqs = [list(x) for x in sqs]
    cur = _obj(sqs)
    T = 0.05
    for it in range(iters):
        i = rng.randrange(n)
        old = list(sqs[i])
        which = rng.randrange(4)
        if which == 0:
            sqs[i][0] = min(1.0, max(0.0, sqs[i][0] + rng.gauss(0, 0.03)))
        elif which == 1:
            sqs[i][1] = min(1.0, max(0.0, sqs[i][1] + rng.gauss(0, 0.03)))
        elif which == 2:
            sqs[i][2] = (sqs[i][2] + rng.gauss(0, 0.02)) % 1.0
        else:
            sqs[i][3] = max(0.0, sqs[i][3] + rng.gauss(0, 0.02))
        new = _obj(sqs)
        if new > cur or rng.random() < math.exp((new - cur) / max(1e-9, T)):
            cur = new
        else:
            sqs[i] = old
        T *= 0.9995
        T = max(T, 1e-4)
    return [tuple(x) for x in sqs]


def _best_solution(n):
    cands = []
    k = math.isqrt(n)
    if k >= 1:
        cands.append(_grid(n, k))
        if k + 1 <= n:
            g = _grid((k + 1) * (k + 1), k + 1)
            cands.append(g[:n])
    cands.append(_pack_rows(n))
    cands.append(_greedy_spiral(n))
    best = None
    best_sum = -1
    for c in cands:
        if c is None: continue
        s = sum(x[3] for x in c)
        if s > best_sum:
            best_sum = s
            best = c
    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    best = _best_solution(n)
    rng = random.Random(2024)
    cur_best = best
    cur_sum = sum(x[3] for x in best)
    iters = 2000 if n < 50 else (1500 if n < 200 else 800)
    for t in range(3):
        improved = _local_improve(cur_best, iters=iters, rng=rng)
        if _feasible(improved):
            s = sum(x[3] for x in improved)
            if s > cur_sum:
                cur_sum = s
                cur_best = improved
    return cur_best


if __name__ == "__main__":
    for nn in [1, 2, 3, 4, 5, 9, 10, 16, 17]:
        r = solve(nn)
        print(nn, sum(x[3] for x in r), len(r))
