import math
import random
from scipy.optimize import minimize


def _corners(cx, cy, ang, s):
    h = s * 0.5
    c = math.cos(2 * math.pi * ang)
    sn = math.sin(2 * math.pi * ang)
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + x * c - y * sn, cy + x * sn + y * c) for x, y in pts]


def _overlap_area(p1, p2):
    # Sutherland-Hodgman clip of convex p1 by convex p2
    def inside(p, a, b):
        return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= -1e-12
    def inter(a, b, c, d):
        # line ab with line cd
        r = (b[0] - a[0], b[1] - a[1])
        s = (d[0] - c[0], d[1] - c[1])
        den = r[0] * s[1] - r[1] * s[0]
        if abs(den) < 1e-15:
            return b
        t = ((c[0] - a[0]) * s[1] - (c[1] - a[1]) * s[0]) / den
        return (a[0] + t * r[0], a[1] + t * r[1])

    poly = p1[:]
    if not poly:
        return 0.0
    c0, c1, c2 = p2[0], p2[1], p2[2]
    for i in range(len(p2)):
        a = p2[i]
        b = p2[(i + 1) % len(p2)]
        # ensure CCW-ish; p2 is convex
        new = []
        if not poly:
            return 0.0
        prev = poly[-1]
        for cur in poly:
            cur_in = inside(cur, a, b)
            prev_in = inside(prev, a, b)
            if cur_in:
                if not prev_in:
                    new.append(inter(prev, cur, a, b))
                new.append(cur)
            elif prev_in:
                new.append(inter(prev, cur, a, b))
            prev = cur
        poly = new
        if not poly:
            return 0.0
    # area
    area = 0.0
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def _pack_side(sqs):
    return sum(s for (_, _, _, s) in sqs)


def _penalty(sqs):
    n = len(sqs)
    cps = [_corners(*q) for q in sqs]
    pen = 0.0
    for i in range(n):
        cx, cy, ang, s = sqs[i]
        if s <= 0:
            continue
        h = s * 0.5
        # outside unit square
        for x, y in cps[i]:
            if x < -1e-9:
                pen += (-x) * (-x) * 500
            if x > 1 + 1e-9:
                pen += (x - 1) * (x - 1) * 500
            if y < -1e-9:
                pen += (-y) * (-y) * 500
            if y > 1 + 1e-9:
                pen += (y - 1) * (y - 1) * 500
        for j in range(i + 1, n):
            ov = _overlap_area(cps[i], cps[j])
            if ov > 1e-10:
                pen += ov * 2000
    return pen


def _score(params, n, fixed):
    sqs = []
    for i in range(n):
        cx, cy, ang = params[3 * i:3 * i + 3]
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        sqs.append((cx, cy, ang, fixed[i]))
    pen = _penalty(sqs)
    # sum of sides is fixed; want to minimize penalty
    return pen


def _resolve_sizes(params, n, sides):
    sqs = []
    for i in range(n):
        cx, cy, ang = params[3 * i:3 * i + 3]
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        sqs.append((cx, cy, ang, sides[i]))
    return sqs


def _trim_ok(sqs):
    return _penalty(sqs) < 1e-8


def _improve_sizes(params, n, sides, iters=200):
    # try to increase sides greedily while keeping feasibility
    sides = list(sides)
    order = sorted(range(n), key=lambda i: -sides[i])
    for _ in range(iters):
        improved = False
        for i in order:
            if sides[i] <= 0:
                continue
            step = 0.02 * sides[i] + 1e-4
            trial = sides[:]
            trial[i] += step
            sqs = _resolve_sizes(params, n, trial)
            if _trim_ok(sqs):
                sides = trial
                improved = True
        if not improved:
            break
    return sides


def _optimize_from(x0, n, sides, maxiter=40):
    sides = list(sides)
    best_sides = sides[:]
    best_pen = _score(x0, n, sides)
    for it in range(maxiter):
        res = minimize(_score, x0, args=(n, sides), method='Nelder-Mead',
                       options={'maxiter': 800, 'xatol': 1e-6, 'fatol': 1e-8})
        x0 = res.x
        pen = res.fun
        if pen < best_pen:
            best_pen = pen
            best_sides = sides[:]
        sides = _improve_sizes(x0, n, sides, iters=60)
        pen2 = _score(x0, n, sides)
        if pen2 < best_pen:
            best_pen = pen2
            best_sides = sides[:]
        if best_pen < 1e-9:
            break
    return x0, best_sides, best_pen


def _best_grid(n):
    rack = []
    # grid patterns k x m inside unit square, plus filler squares in leftover strips
    best = None
    best_val = -1
    for k in range(1, int(math.sqrt(n)) + 3):
        for m in range(1, n + 1):
            if k * m > n:
                continue
            # k columns, m rows as equal squares? then leftover
            base = min(1.0 / k, 1.0 / m)
            cnt = k * m
            val = cnt * base
            if val > best_val:
                best_val = val
                best = (k, m, base)
    return best


def _greedy_rack(n, W, H, x0, y0):
    res = []
    # columns of squares filling W,H with given count n roughly equal
    if n <= 0:
        return res
    cols = max(1, min(n, int(round(math.sqrt(n * W / max(H, 1e-9))))))
    cols = max(1, min(cols, n))
    rows = int(math.ceil(n / cols))
    w = W / cols
    h = H / rows
    s = min(w, h)
    for i in range(n):
        r = i // cols
        c = i % cols
        res.append((x0 + (c + 0.5) * w, y0 + (r + 0.5) * h, 0.0, s))
    return res


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # candidate packings
    candidates = []

    # 1) simple grid
    k = math.isqrt(n)
    s1 = 1.0 / k
    g1 = [((i + 0.5) * s1, (j + 0.5) * s1, 0.0, s1) for i in range(k) for j in range(k)]
    g1 += [(0.5, 0.5, 0.0, 0.0)] * (n - len(g1))
    candidates.append(g1[:n])

    # 2) split horizontal: floor(n/2) columns each side etc.
    for split in range(1, n):
        # left block gets split squares, right gets n-split
        left = _greedy_rack(split, 0.5, 1.0, 0.0, 0.0)
        right = _greedy_rack(n - split, 0.5, 1.0, 0.5, 0.0)
        cand = left + right
        candidates.append(cand)

    # 3) split vertical
    for split in range(1, n):
        top = _greedy_rack(split, 1.0, 0.5, 0.0, 0.5)
        bot = _greedy_rack(n - split, 1.0, 0.5, 0.0, 0.0)
        cand = top + bot
        candidates.append(cand)

    # 4) 3-strip
    a = max(1, n // 3)
    b = max(1, (n - a) // 2)
    c = n - a - b
    if c <= 0:
        c = 1
        b = max(1, (n - 1) // 2)
        a = n - 1 - b
    if a > 0 and b > 0 and c > 0 and a + b + c == n:
        s_a = 1.0 / a
        s_b = 1.0 / b
        s_c = 1.0 / c
        sq = []
        for i in range(a):
            sq.append(((i + 0.5) * s_a, 0.5 * s_a + 0.0, 0.0, min(s_a, 0.5)))
        for j in range(b):
            sq.append((0.5, 1.0 / 3 + (j + 0.5) * (1.0 / 3), 0.0, min(s_b, 1.0 / 3)))
        for l in range(c):
            sq.append((0.5, 2.0 / 3 + (l + 0.5) * (1.0 / 3), 0.0, min(s_c, 1.0 / 3)))
        candidates.append(sq)

    best = None
    best_val = -1
    for cand in candidates:
        val = _pack_side(cand)
        if val > best_val:
            best_val = val
            best = cand

    # polish with local search for small n
    if n <= 10:
        sides = [q[3] for q in best]
        x0 = []
        for q in best:
            x0 += [q[0], q[1], q[2]]
        x0 = [min(1.0, max(0.0, v)) if i % 3 != 2 else v for i, v in enumerate(x0)]
        x0, sides, pen = _optimize_from(x0, n, sides, maxiter=30)
        cand = _resolve_sizes(x0, n, sides)
        if _penalty(cand) < 1e-6:
            val = _pack_side(cand)
            if val > best_val:
                best_val = val
                best = cand

    # ensure exactly n entries
    out = best[:n]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
