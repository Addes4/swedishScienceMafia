import math
import random
from scipy.optimize import minimize

def solve(n):
    if n == 0:
        return []
    # Try several strategies and keep the best
    best = None
    best_score = -1.0
    for strategy in range(4):
        squares = initialize(n, strategy)
        squares = optimize(n, squares)
        score = sum(s[3] for s in squares)
        if score > best_score:
            best_score = score
            best = squares
    return best

def initialize(n, strategy):
    """Create initial placement of n squares."""
    if strategy == 0:
        return grid_init(n, rotated=False)
    elif strategy == 1:
        return grid_init(n, rotated=True)
    elif strategy == 2:
        return hex_init(n)
    else:
        return random_init(n)

def grid_init(n, rotated):
    """k x k grid plus small squares."""
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) < n:
                ang = 0.0
                if rotated and (i + j) % 2 == 0:
                    ang = 0.0
                squares.append([(i + 0.5) * side, (j + 0.5) * side, ang, side])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 1e-6])
    return squares[:n]

def hex_init(n):
    """Hexagonal-like packing of small squares as starting point."""
    k = math.isqrt(n)
    side = 1.0 / (k + 1)
    squares = []
    for i in range(k + 1):
        for j in range(k + 1):
            if len(squares) < n:
                offset = 0.5 * side if (j % 2 == 1) else 0.0
                x = (i + 0.5) * side + offset
                y = (j + 0.5) * side * (math.sqrt(3) / 2) if False else (j + 0.5) * side
                if x + side / 2 <= 1.0 and y + side / 2 <= 1.0:
                    squares.append([x, y, 0.0, side])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 1e-6])
    return squares[:n]

def random_init(n):
    squares = []
    for _ in range(n):
        squares.append([random.uniform(0.1, 0.9), random.uniform(0.1, 0.9), 0.0, 1e-6])
    return squares

def square_corners(cx, cy, ang, side):
    """Return 4 corners of square."""
    theta = ang * 2 * math.pi
    c = math.cos(theta) * side / 2
    s = math.sin(theta) * side / 2
    return [
        (cx - c - s, cy - s + c),
        (cx + c - s, cy + s + c),
        (cx + c + s, cy + s - c),
        (cx - c + s, cy - s - c),
    ]

def overlap_area(sq1, sq2):
    """Check if two squares overlap; return True if interiors intersect."""
    # Use separating axis theorem for convex polygons
    c1 = square_corners(*sq1)
    c2 = square_corners(*sq2)
    for poly in [c1, c2]:
        for i in range(4):
            edge = (poly[(i + 1) % 4][0] - poly[i][0], poly[(i + 1) % 4][1] - poly[i][1])
            axis = (-edge[1], edge[0])
            proj1 = [c1[j][0] * axis[0] + c1[j][1] * axis[1] for j in range(4)]
            proj2 = [c2[j][0] * axis[0] + c2[j][1] * axis[1] for j in range(4)]
            if max(proj1) <= min(proj2) + 1e-12 or max(proj2) <= min(proj1) + 1e-12:
                return False
    return True

def compute_penalty(squares):
    """Penalty for overlap and out-of-bounds."""
    pen = 0.0
    # Out of bounds
    for sq in squares:
        cx, cy, ang, side = sq
        if side <= 0:
            continue
        corners = square_corners(cx, cy, ang, side)
        for x, y in corners:
            if x < -1e-9:
                pen += (0 - x) ** 2 * 100
            if x > 1.0 + 1e-9:
                pen += (x - 1.0) ** 2 * 100
            if y < -1e-9:
                pen += (0 - y) ** 2 * 100
            if y > 1.0 + 1e-9:
                pen += (y - 1.0) ** 2 * 100
    # Overlaps
    for i in range(len(squares)):
        if squares[i][3] <= 0:
            continue
        for j in range(i + 1, len(squares)):
            if squares[j][3] <= 0:
                continue
            if overlap_area(squares[i], squares[j]):
                pen += 50.0
    return pen

def objective(params, n, squares_orig):
    """Objective: maximize sum of sides - penalty."""
    squares = []
    for i in range(n):
        cx = params[i * 4]
        cy = params[i * 4 + 1]
        ang = params[i * 4 + 2]
        side = params[i * 4 + 3]
        squares.append([cx, cy, ang, side])
    total_side = sum(s[3] for s in squares)
    pen = compute_penalty(squares)
    return -(total_side - pen)

def optimize(n, squares):
    """Run optimization to improve placement."""
    # First, remove zero-size squares temporarily
    active = [s for s in squares if s[3] > 1e-10]
    zeros = [s for s in squares if s[3] <= 1e-10]
    m = len(active)
    if m == 0:
        return squares
    x0 = []
    for s in active:
        x0.extend([s[0], s[1], s[2], s[3]])
    x0 = list(x0)
    bounds = []
    for i in range(m):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (-10.0, 10.0), (0.0, 1.0)])
    
    def obj(p):
        sqs = []
        for i in range(m):
            cx, cy, ang, side = p[i * 4], p[i * 4 + 1], p[i * 4 + 2], p[i * 4 + 3]
            sqs.append([cx, cy, ang, side])
        total = sum(s[3] for s in sqs)
        pen = compute_penalty(sqs)
        return -(total - pen * 1000)
    
    try:
        res = minimize(obj, x0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': 200, 'ftol': 1e-10, 'gtol': 1e-10})
        if res.success or res.fun < obj(x0):
            x0 = res.x
    except Exception:
        pass
    
    # Try a simple growth phase: try to increase each square's size greedily
    improved = True
    iters = 0
    while improved and iters < 50:
        improved = False
        iters += 1
        for i in range(m):
            cx, cy, ang, side = x0[i * 4], x0[i * 4 + 1], x0[i * 4 + 2], x0[i * 4 + 3]
            # Try increasing size
            best_side = side
            for delta in [0.01, 0.005, 0.002, 0.001]:
                test = side + delta
                test_sq = [cx, cy, ang, test]
                others = []
                for j in range(m):
                    if j != i:
                        others.append([x0[j * 4], x0[j * 4 + 1], x0[j * 4 + 2], x0[j * 4 + 3]])
                # Check if test square fits
                ok = True
                corners = square_corners(cx, cy, ang, test)
                for x, y in corners:
                    if x < 0 or x > 1.0 or y < 0 or y > 1.0:
                        ok = False
                        break
                if ok:
                    for o in others:
                        if o[3] > 1e-10 and overlap_area(test_sq, o):
                            ok = False
                            break
                if ok:
                    best_side = side + delta
                    break
            if best_side > side:
                x0[i * 4 + 3] = best_side
                improved = True
    
    # Reconstruct squares
    result = []
    for i in range(m):
        result.append([x0[i * 4], x0[i * 4 + 1], x0[i * 4 + 2], x0[i * 4 + 3]])
    # Add back zeros, but try to make them tiny positive if possible
    for _ in range(n - m):
        result.append([0.5, 0.5, 0.0, 0.0])
    return result
