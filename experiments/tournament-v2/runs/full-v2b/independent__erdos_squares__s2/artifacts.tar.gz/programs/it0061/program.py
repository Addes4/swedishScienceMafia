import math
import random
import numpy as np
from scipy.optimize import minimize_scalar


def _inside_unit(cx, cy, a, s):
    c = math.cos(a * 2 * math.pi)
    sn = math.sin(a * 2 * math.pi)
    r = s * 0.5
    ex = abs(c) * r + abs(sn) * r
    ey = abs(sn) * r + abs(c) * r
    return (cx - ex >= -1e-12 and cx + ex <= 1 + 1e-12 and
            cy - ey >= -1e-12 and cy + ey <= 1 + 1e-12)


def _overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    if s1 <= 1e-15 or s2 <= 1e-15:
        return False
    a = a1 * 2 * math.pi
    b = a2 * 2 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    cb, sb = math.cos(b), math.sin(b)
    d = (cx1 - cx2, cy1 - cy2)
    r1 = s1 * 0.5
    r2 = s2 * 0.5
    # SAT with 4 axes: two from each square
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    for ax, ay in axes:
        proj = abs(d[0] * ax + d[1] * ay)
        e1 = r1 * (abs(ca * ax + sa * ay) + abs(-sa * ax + ca * ay))
        e2 = r2 * (abs(cb * ax + sb * ay) + abs(-sb * ax + cb * ay))
        if proj >= e1 + e2 - 1e-12:
            return False
    return True


def _max_side(cx, cy, a, squares):
    if not _inside_unit(cx, cy, a, 1e-12):
        return 0.0
    lo, hi = 0.0, 1.0
    for _ in range(45):
        mid = (lo + hi) * 0.5
        ok = True
        if not _inside_unit(cx, cy, a, mid):
            ok = False
        else:
            for (ox, oy, oa, os_) in squares:
                if _overlap(cx, cy, a, mid, ox, oy, oa, os_):
                    ok = False
                    break
        if ok:
            lo = mid
        else:
            hi = mid
    return lo


def _place_best(squares, rng, angle_samples=16, center_samples=50):
    # Try random candidate placements, then refine best with local search.
    best = (0.0, 0.5, 0.5, 0.0)
    best_s = -1.0
    for _ in range(center_samples):
        cx = rng.random()
        cy = rng.random()
        a = rng.random()
        s = _max_side(cx, cy, a, squares)
        if s > best_s:
            best_s = s
            best = (a, cx, cy, s)
    # local refinement using scipy
    if best_s > 0:
        a0, x0, y0, s0 = best
        def obj(v):
            a, x, y = v
            return -_max_side(x, y, a % 1.0, squares)
        res = minimize_scalar(lambda t: obj([(a0 + t) % 1.0, x0, y0]),
                              bounds=(-0.25, 0.25), method='bounded')
        da = res.x
        res2 = minimize_scalar(lambda t: obj([(a0 + da) % 1.0, min(1, max(0, x0 + t)), y0]),
                               bounds=(-0.2, 0.2), method='bounded')
        dx = res2.x
        res3 = minimize_scalar(lambda t: obj([(a0 + da) % 1.0, min(1, max(0, x0 + dx)), min(1, max(0, y0 + t))]),
                               bounds=(-0.2, 0.2), method='bounded')
        dy = res3.x
        a1 = (a0 + da) % 1.0
        x1 = min(1, max(0, x0 + dx))
        y1 = min(1, max(0, y0 + dy))
        s1 = _max_side(x1, y1, a1, squares)
        if s1 > best_s:
            best = (a1, x1, y1, s1)
            best_s = s1
    return best


def _greedy(n, seed=0):
    rng = random.Random(seed)
    squares = []
    for _ in range(n):
        a, cx, cy, s = _place_best(squares, rng)
        # ensure inside
        if s > 0.5 or not _inside_unit(cx, cy, a, s):
            s = 0.0
        squares.append((cx, cy, a, s))
    return squares


def _refine(squares, iters=300, seed=0):
    rng = random.Random(seed)
    sq = [list(x) for x in squares]
    n = len(sq)
    if n == 0:
        return []
    def total():
        return sum(x[3] for x in sq)
    def valid(idx=None):
        for i in range(n):
            if not _inside_unit(sq[i][0], sq[i][1], sq[i][2], sq[i][3]):
                return False
            for j in range(i + 1, n):
                if _overlap(sq[i][0], sq[i][1], sq[i][2], sq[i][3],
                            sq[j][0], sq[j][1], sq[j][2], sq[j][3]):
                    return False
        return True
    for _ in range(iters):
        # pick a small square to perturb
        idxs = sorted(range(n), key=lambda i: sq[i][3])
        i = idxs[rng.randrange(min(n, max(1, n // 2)))]
        old = sq[i][:]
        # perturb
        cx, cy, a, s = sq[i]
        if rng.random() < 0.5:
            cx = min(1, max(0, cx + rng.uniform(-0.15, 0.15)))
            cy = min(1, max(0, cy + rng.uniform(-0.15, 0.15)))
        else:
            a = (a + rng.uniform(-0.1, 0.1)) % 1.0
        # grow to max
        others = [tuple(sq[j]) for j in range(n) if j != i]
        news = _max_side(cx, cy, a, others)
        sq[i] = [cx, cy, a, news]
        ok = True
        for j in range(n):
            if j == i:
                continue
            if _overlap(sq[i][0], sq[i][1], sq[i][2], sq[i][3],
                        sq[j][0], sq[j][1], sq[j][2], sq[j][3]):
                ok = False
                break
        if not ok or not _inside_unit(sq[i][0], sq[i][1], sq[i][2], sq[i][3]):
            sq[i] = old
    return [tuple(x) for x in sq]


def solve(n):
    if n <= 0:
        return []
    # For small n, try several seeds / greedy orders.
    best = None
    best_score = -1.0
    trials = 1 if n > 20 else 3
    for t in range(trials):
        sq = _greedy(n, seed=t)
        sq = _refine(sq, iters=min(400, 60 + n * 8), seed=t)
        score = sum(x[3] for x in sq)
        if score > best_score:
            best_score = score
            best = sq
    # Ensure exactly n
    out = []
    for i in range(n):
        if i < len(best):
            cx, cy, a, s = best[i]
            if not (0 <= cx <= 1 and 0 <= cy <= 1 and 0 <= a <= 1 and 0 <= s <= 1):
                cx = min(1, max(0, cx))
                cy = min(1, max(0, cy))
                a = min(1, max(0, a))
                s = min(1, max(0, s))
            out.append((cx, cy, a, s))
        else:
            out.append((0.5, 0.5, 0.0, 0.0))
    return out
