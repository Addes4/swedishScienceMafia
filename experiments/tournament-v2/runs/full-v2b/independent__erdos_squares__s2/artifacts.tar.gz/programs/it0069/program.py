import math
import random

def solve(n):
    """Pack n squares into the unit square maximizing sum of side lengths.
    
    Uses recursive guillotine partitioning: repeatedly split a rectangle into
    two sub-rectangles, fill each leaf with the largest square fitting.
    A local search over split patterns finds good packings for any n.
    """
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    # Cache for cell fitting
    def max_square_in_rect(w, h):
        """Largest axis-aligned square fitting in w x h rectangle."""
        return min(w, h)
    
    def pack_rect(w, h, count, x0=0.0, y0=0.0):
        """Pack `count` squares into rectangle (x0,y0,w,h). Returns list of tuples."""
        if count == 0:
            return []
        if count == 1:
            s = min(w, h)
            cx = x0 + w/2
            cy = y0 + h/2
            return [(cx, cy, 0.0, s)]
        
        # Choose split: vertical or horizontal, with fractional position
        # Heuristic: try to balance so each side gets roughly equal "square potential"
        best = None
        best_score = -1
        
        # Try several split ratios
        ratios = [i/10.0 for i in range(1, 10)]
        for ratio in ratios:
            for vertical in (True, False):
                # Split into a and b parts
                if vertical:
                    w1, w2 = w * ratio, w * (1 - ratio)
                    h1, h2 = h, h
                else:
                    w1, w2 = w, w
                    h1, h2 = h * ratio, h * (1 - ratio)
                
                # Allocate counts proportional to max square area potential
                # For each count k in [1, count-1], estimate score
                for k in range(1, count):
                    # Estimate max square size possible in each part
                    s1 = min(w1, h1)
                    s2 = min(w2, h2)
                    # Rough score: sum of squares if each part fills with equal squares
                    # (upper bound actually, but useful for comparison)
                    sc = s1 * min(k, max(1, int(w1*h1/(s1*s1)))) + s2 * min(count-k, max(1, int(w2*h2/(s2*s2))))
                    # Better: use sqrt of area for equal squares
                    a1 = w1 * h1
                    a2 = w2 * h2
                    if k > 0 and a1 > 0:
                        sc = math.sqrt(a1) * k**0.5  # if k equal squares fill area a1
                    else:
                        sc = 0
                    if count - k > 0 and a2 > 0:
                        sc += math.sqrt(a2) * (count-k)**0.5
                    
                    if sc > best_score:
                        best_score = sc
                        best = (vertical, ratio, k)
        
        if best is None:
            # Fallback: all in one line
            s = min(w, h) / count
            result = []
            for i in range(count):
                if w >= h:
                    cx = x0 + (i + 0.5) * w / count
                    cy = y0 + h / 2
                    result.append((cx, cy, 0.0, min(w/count, h)))
                else:
                    cx = x0 + w / 2
                    cy = y0 + (i + 0.5) * h / count
                    result.append((cx, cy, 0.0, min(h/count, w)))
            return result
        
        vertical, ratio, k = best
        
        if vertical:
            w1 = w * ratio
            w2 = w - w1
            r1 = pack_rect(w1, h, k, x0, y0)
            r2 = pack_rect(w2, h, count - k, x0 + w1, y0)
        else:
            h1 = h * ratio
            h2 = h - h1
            r1 = pack_rect(w, h1, k, x0, y0)
            r2 = pack_rect(w, h2, count - k, x0, y0 + h1)
        
        return r1 + r2
    
    # Improve by trying multiple top-level configurations
    best_result = None
    best_sum = -1
    
    # Try different global strategies
    configs = []
    
    # Strategy 1: guillotine from top
    result = pack_rect(1.0, 1.0, n)
    s = sum(t[3] for t in result)
    if s > best_sum:
        best_sum = s
        best_result = result
    
    # Strategy 2: Perfect grid plus remainder using best fit
    k = math.isqrt(n)
    if k >= 1 and k*k <= n:
        base_side = 1.0 / k
        squares = []
        for i in range(k):
            for j in range(k):
                squares.append(((i + 0.5) * base_side, (j + 0.5) * base_side, 0.0, base_side))
        rem = n - k*k
        if rem > 0:
            # Add remnant squares in a strip - use a finer grid approach
            # Try to improve by rebalancing: use different grid dimensions
            pass
        s = sum(t[3] for t in squares)
        # Only use if no remainder or if remainder handled
        if rem == 0 and s > best_sum:
            best_sum = s
            best_result = squares
    
    # Strategy 3: Try all grid dimensions a x b where a*b close to n
    for a in range(1, n+1):
        b = (n + a - 1) // a  # ceiling
        if a * b < n:
            continue
        if a > 25 or b > 25:
            continue
        # Fill with a x b grid but only n squares: largest ones
        cell_w = 1.0 / a
        cell_h = 1.0 / b
        side = min(cell_w, cell_h)
        # Number of squares in grid = a*b
        # If exactly n, use all. Otherwise remove smallest cells or shrink
        if a * b == n:
            sq = []
            for i in range(a):
                for j in range(b):
                    sq.append(((i + 0.5) * cell_w, (j + 0.5) * cell_h, 0.0, side))
            s = sum(t[3] for t in sq)
            if s > best_sum:
                best_sum = s
                best_result = sq
        else:
            # Use a x b grid but with n squares: make some cells empty or adjust
            # Simplest: use n squares in first n cells of the grid
            sq = []
            count = 0
            for i in range(a):
                for j in range(b):
                    if count >= n:
                        break
                    sq.append(((i + 0.5) * cell_w, (j + 0.5) * cell_h, 0.0, side))
                    count += 1
                if count >= n:
                    break
            s = sum(t[3] for t in sq)
            if s > best_sum:
                best_sum = s
                best_result = sq
    
    # Strategy 4: Mixed grid - one dimension a, another varies
    for a in range(1, min(n, 15) + 1):
        for b in range(1, min(n, 15) + 1):
            if a * b < n:
                continue
            if a * b - n > a + b:
                continue  # too many empty cells
            # Use a x b grid, fill n squares with varying sizes
            # Optimal: make first row/col larger
            if a * b == n:
                continue  # already done
            # Try: (a-1) rows full, last row has (n - (a-1)*b) squares
            # Make grid with (a-1) rows of b squares, then remainder
            rem = n - (a-1)*b
            if rem <= 0:
                continue
            if rem > b:
                continue
            # Heights: first (a-1) rows have height h1, remaining row h2
            # total height = (a-1)*h1 + h2 = 1
            # Square sizes: min(1/b, h1) for full rows, min(1/rem, h2) for last
            # Optimize h1, h2
            best_local = None
            best_local_sum = -1
            for t in range(0, 101):
                h1 = t / 100.0
                h2 = 1.0 - (a-1) * h1
                if h2 <= 0:
                    continue
                s1 = min(1.0/b, h1)
                s2 = min(1.0/rem, h2)
                total = (a-1) * b * s1 + rem * s2
                if total > best_local_sum:
                    best_local_sum = total
                    best_local = (h1, h2, s1, s2)
            if best_local is not None and best_local_sum > best_sum:
                h1, h2, s1, s2 = best_local
                sq = []
                y = 0.0
                for row in range(a-1):
                    for col in range(b):
                        cx = (col + 0.5) / b
                        cy = y + h1 / 2
                        sq.append((cx, cy, 0.0, s1))
                    y += h1
                for col in range(rem):
                    cx = (col + 0.5) / rem
                    cy = y + h2 / 2
                    sq.append((cx, cy, 0.0, s2))
                if len(sq) == n:
                    s = sum(t[3] for t in sq)
                    if s > best_sum:
                        best_sum = s
                        best_result = sq
    
    if best_result is None:
        # Fallback baseline
        k = math.isqrt(n)
        side = 1.0 / k if k > 0 else 1.0
        best_result = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        best_result += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_result))
    
    return best_result[:n]
