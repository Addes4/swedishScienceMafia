import math
import random

def solve(n):
    """Place n squares in unit square maximizing sum of side lengths."""
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    # Start with grid-based packing
    k = math.isqrt(n)
    if k * k == n:
        # Perfect square: use full grid
        s = 1.0 / k
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) 
                for i in range(k) for j in range(k)]
    
    # Use grid for k*k squares, then add remaining in gaps
    squares = []
    
    # Determine optimal grid configuration
    # Try k x k grid plus extras, or k x (k+1) etc.
    best_config = None
    best_score = -1
    
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if cols * rows >= n:
            # Try to fit rows x cols grid
            # For non-square grids, squares can be rectangular arranged
            w = 1.0 / cols
            h = 1.0 / rows
            if w == h:
                score = n * w
            else:
                # Some squares can be larger
                score = n * min(w, h) + (max(w, h) - min(w, h)) * min(n, rows * cols)
            if score > best_score:
                best_score = score
                best_config = (rows, cols)
    
    # Place squares in grid
    k = math.isqrt(n)
    s = 1.0 / k
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
    
    remaining = n - k * k
    
    if remaining > 0:
        # Find gaps and try to fit squares
        # Use a simple greedy approach: split some squares
        # Place extra squares in corners or edges
        
        if remaining <= k:
            # Add a row of squares
            # Shrink existing squares slightly
            new_s = 1.0 / (k + 1)
            # Reposition: use (k+1) x k grid partially
            squares = []
            for i in range(k + 1):
                for j in range(k):
                    if len(squares) < n:
                        squares.append([(i + 0.5) * new_s, (j + 0.5) * new_s, 0.0, new_s])
            # Fill remaining
            while len(squares) < n:
                squares.append([0.5, 0.5, 0.0, 0.0])
        else:
            # Need multiple extra rows
            rows_needed = (n + k - 1) // k
            new_s = 1.0 / max(k, rows_needed)
            squares = []
            for i in range(k + 1):
                for j in range(rows_needed):
                    if len(squares) < n:
                        squares.append([(i + 0.5) * new_s, (j + 0.5) * new_s, 0.0, new_s])
            while len(squares) < n:
                squares.append([0.5, 0.5, 0.0, 0.0])
    
    return squares[:n]
