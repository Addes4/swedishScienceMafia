import math
import random
import numpy as np
from scipy.optimize import minimize


def _pack_grid(n):
    """Recursive greedy packing of n squares into unit square using guillotine cuts.

    Strategy: maintain a list of free rectangles. Repeatedly place the largest
    feasible square in the largest free rectangle (or split rectangles) to
    approximately maximize sum of side lengths.
    """
    # free rectangles stored as (x, y, w, h)
    free = [(0.0, 0.0, 1.0, 1.0)]
    squares = []

    # We use a simple approach: place squares by repeatedly taking the biggest
    # free rectangle, placing a square of size min(w,h) in its corner, then
    # splitting the remainder into two rectangles.
    for _ in range(n):
        # find largest free rect by area
        best_i = -1
        best_area = -1.0
        for i, (x, y, w, h) in enumerate(free):
            a = w * h
            if a > best_area:
                best_area = a
                best_i = i
        if best_i < 0:
            squares.append((0.5, 0.5, 0.0, 0.0))
            continue
        x, y, w, h = free.pop(best_i)
        s = min(w, h)
        squares.append((x + s / 2.0, y + s / 2.0, 0.0, s))
        # split remaining space into two rectangles
        if w > s and h > s:
            free.append((x + s, y, w - s, h))
            free.append((x, y + s, w, h - s))
        elif w > s:
            free.append((x + s, y, w - s, h))
        elif h > s:
            free.append((x, y + s, w, h - s))

    return squares


def _merge_and_optimize(n, squares, iterations=3):
    """Try to improve the sum of side lengths by adjusting sizes (shrink) and
    optimizing positions to allow larger squares."""
    # This is a heuristic improvement: after the greedy packing, some squares
    # may be smaller than needed. We attempt local adjustments of positions.
    # For simplicity we optimize positions with small perturbations to allow
    # larger sizes on the largest squares.
    result = list(squares)
    # sort by size ascending so we can try to grow larger ones
    result.sort(key=lambda sq: sq[3])

    # simple coordinate descent: for the smallest squares, try to adjust
    # position/size to fit better around larger squares.  Limited budget.
    rng = random.Random(12345)
    for _ in range(iterations * n):
        i = rng.randrange(n)
        x, y, a, s = result[i]
        # try small perturbation
        dx = rng.uniform(-0.02, 0.02)
        dy = rng.uniform(-0.02, 0.02)
        nx = min(max(x + dx, s / 2.0), 1.0 - s / 2.0)
        ny = min(max(y + dy, s / 2.0), 1.0 - s / 2.0)
        # check overlap with axis-aligned bounding boxes
        ok = True
        for j, (xj, yj, aj, sj) in enumerate(result):
            if j == i:
                continue
            if abs(nx - xj) < (s + sj) / 2.0 and abs(ny - yj) < (s + sj) / 2.0:
                ok = False
                break
        if ok:
            result[i] = (nx, ny, a, s)
    return result


def _overlap_penalty(params, n, targets):
    """Penalty function for SLSQP: params = [cx, cy, s] per square.
    Penalizes overlaps and out-of-bounds."""
    pen = 0.0
    cx = params[0::3]
    cy = params[1::3]
    ss = params[2::3]
    # bounds penalty: keep squares inside unit square (account for rotation ~ axis aligned here)
    for i in range(n):
        s = ss[i]
        if s < 0:
            pen += 1e6 * (-s) ** 2
            s = 0.0
        if cx[i] - s / 2.0 < -1e-9:
            pen += 1e6 * (s / 2.0 - cx[i]) ** 2
        if cx[i] + s / 2.0 > 1.0 + 1e-9:
            pen += 1e6 * (cx[i] + s / 2.0 - 1.0) ** 2
        if cy[i] - s / 2.0 < -1e-9:
            pen += 1e6 * (s / 2.0 - cy[i]) ** 2
        if cy[i] + s / 2.0 > 1.0 + 1e-9:
            pen += 1e6 * (cy[i] + s / 2.0 - 1.0) ** 2
    # overlap penalty (axis-aligned bounding box approximation, sufficient for angles=0)
    for i in range(n):
        for j in range(i + 1, n):
            ox = (ss[i] + ss[j]) / 2.0 - abs(cx[i] - cx[j])
            oy = (ss[i] + ss[j]) / 2.0 - abs(cy[i] - cy[j])
            if ox > 0 and oy > 0:
                pen += ox * oy * 1e4
    return pen


def _slsqp_improve(n, squares, maxiter=50):
    """Use SLSQP to minimize overlap penalty and grow squares."""
    if n > 60:
        return squares  # too expensive
    x0 = np.zeros(3 * n)
    for i, (cx, cy, a, s) in enumerate(squares):
        x0[3 * i] = cx
        x0[3 * i + 1] = cy
        x0[3 * i + 2] = s

    def neg_sum(p):
        return -np.sum(p[2::3]) + _overlap_penalty(p, n, None) * 1e-6

    try:
        res = minimize(neg_sum, x0, method='SLSQP',
                       options={'maxiter': maxiter, 'ftol': 1e-6})
        p = res.x
    except Exception:
        return squares

    new_squares = []
    for i in range(n):
        cx = float(np.clip(p[3 * i], 0.0, 1.0))
        cy = float(np.clip(p[3 * i + 1], 0.0, 1.0))
        s = float(max(0.0, p[3 * i + 2]))
        # ensure inside
        s = min(s, 2 * min(cx, 1 - cx), 2 * min(cy, 1 - cy))
        new_squares.append((cx, cy, 0.0, s))

    # verify no overlaps; if overlap, revert
    for i in range(n):
        for j in range(i + 1, n):
            xi, yi, ai, si = new_squares[i]
            xj, yj, aj, sj = new_squares[j]
            if abs(xi - xj) < (si + sj) / 2.0 - 1e-9 and abs(yi - yj) < (si + sj) / 2.0 - 1e-9:
                return squares
    return new_squares


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # Build initial packing
    squares = _pack_grid(n)
    # Improve positions slightly
    squares = _merge_and_optimize(n, squares, iterations=2)
    # Try SLSQP for small n
    improved = _slsqp_improve(n, squares, maxiter=80)
    # choose better by sum of sides
    if sum(sq[3] for sq in improved) > sum(sq[3] for sq in squares):
        squares = improved
    # Ensure correct count
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
