def get_digit_at(n):
    s = ''.join(str(i) for i in range(1, n + 1))
    return int(s[n - 1])
