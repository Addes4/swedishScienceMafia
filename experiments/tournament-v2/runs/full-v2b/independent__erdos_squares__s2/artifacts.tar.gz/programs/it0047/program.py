import math
import random
import numpy as np
from scipy.optimize import minimize

# Try to keep runtime bounded and deterministic across environments
RNG = random.Random(1234567)
np.random.seed(1234567)

EPS = 1e-12
CONSTRAINT_TOL = 1e-9


def _rotate(angle):
    a = 2.0 * math.pi * angle
    c = math.cos(a)
    s = math.sin(a)
    return c, s


def _square_vertices(cx, cy, angle, side):
    c, s = _rotate(angle)
    h = 0.5 * side
    # corners relative to centre
    rel = ((-h, -h), (h, -h), (h, h), (-h, h))
    out = []
    for x, y in rel:
        out.append((cx + c * x - s * y, cy + s * x + c * y))
    return out


def _in_unit(cx, cy, angle, side):
    # cheap bounding box check based on all vertices
    pts = _square_vertices(cx, cy, angle, side)
    for x, y in pts:
        if x < -CONSTRAINT_TOL or x > 1.0 + CONSTRAINT_TOL:
            return False
        if y < -CONSTRAINT_TOL or y > 1.0 + CONSTRAINT_TOL:
            return False
    return True


def _project_params(params, n):
    # params: n * [cx, cy, angle, side]
    p = np.asarray(params, dtype=float).reshape((n, 4))
    p[:, 0] = np.clip(p[:, 0], 0.0, 1.0)
    p[:, 1] = np.clip(p[:, 1], 0.0, 1.0)
    p[:, 2] = np.mod(p[:, 2], 1.0)
    p[:, 3] = np.clip(p[:, 3], 0.0, 1.0)
    return p


def _sat_square_intersect(a, b):
    """Positive-area intersection test for two convex polygons using SAT."""
    pa = _square_vertices(*a)
    pb = _square_vertices(*b)
    for poly in (pa, pb):
        for i in range(len(poly)):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % len(poly)]
            ex, ey = x2 - x1, y2 - y1
            nx, ny = -ey, ex
            ln = math.hypot(nx, ny)
            if ln < 1e-15:
                continue
            nx /= ln
            ny /= ln

            mina = min(x * nx + y * ny for x, y in pa)
            maxa = max(x * nx + y * ny for x, y in pa)
            minb = min(x * nx + y * ny for x, y in pb)
            maxb = max(x * nx + y * ny for x, y in pb)

            # separated if projections do not overlap at all
            if maxa <= minb or maxb <= mina:
                return False
    return True


def _pair_violation(a, b):
    """Return a measure of overlap. 0 means no positive-area intersection."""
    if a[3] <= 0.0 or b[3] <= 0.0:
        return 0.0

    pa = _square_vertices(*a)
    pb = _square_vertices(*b)

    # SAT axes
    axes = []
    for poly in (pa, pb):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln < 1e-15:
                continue
            axes.append((-ey / ln, ex / ln))

    min_overlap = float("inf")
    for nx, ny in axes:
        mina = min(x * nx + y * ny for x, y in pa)
        maxa = max(x * nx + y * ny for x, y in pa)
        minb = min(x * nx + y * ny for x, y in pb)
        maxb = max(x * nx + y * ny for x, y in pb)

        o = min(maxa, maxb) - max(mina, minb)
        if o <= 0.0:
            return 0.0
        if o < min_overlap:
            min_overlap = o

    return min_overlap if min_overlap != float("inf") else 0.0


def _penalty(params, n):
    p = _project_params(params, n)
    pen = 0.0

    # boundary penalties
    for cx, cy, angle, side in p:
        if side <= 0.0:
            continue
        c, s = _rotate(angle)
        h = 0.5 * side
        # axis-aligned bounds after rotation:
        # x-extent = side * (|c| + |s|) * 0.5
        ext_x = side * (abs(c) + abs(s)) * 0.5
        ext_y = side * (abs(c) + abs(s)) * 0.5

        lo = cx - ext_x
        hi = cx + ext_x
        if lo < 0.0:
            pen += lo * lo
        if hi > 1.0:
            pen += (hi - 1.0) ** 2

        lo = cy - ext_y
        hi = cy + ext_y
        if lo < 0.0:
            pen += lo * lo
        if hi > 1.0:
            pen += (hi - 1.0) ** 2

    # overlap penalties
    for i in range(n):
        for j in range(i + 1, n):
            v = _pair_violation(p[i], p[j])
            if v > 0.0:
                pen += 10.0 * v * v

    return pen


def _objective(params, n):
    p = _project_params(params, n)
    # maximise sum sides => minimise negative sum + penalty
    return -float(np.sum(p[:, 3])) + _penalty(params, n)


def _objective_with_penalty_weight(params, n, weight):
    p = _project_params(params, n)
    pen = _penalty(params, n)
    return -float(np.sum(p[:, 3])) + weight * pen


def _random_feasible_start(n, k_grid):
    """Build starts from grids and random perturbations."""
    p = np.zeros((n, 4), dtype=float)

    if k_grid >= 1:
        side0 = 1.0 / k_grid
        idx = 0
        for i in range(k_grid):
            for j in range(k_grid):
                if idx >= n:
                    break
                p[idx, 0] = (i + 0.5) * side0
                p[idx, 1] = (j + 0.5) * side0
                p[idx, 2] = 0.0
                p[idx, 3] = side0
                idx += 1
        while idx < n:
            p[idx, 0] = RNG.random()
            p[idx, 1] = RNG.random()
            p[idx, 2] = RNG.random()
            p[idx, 3] = 0.0
            idx += 1

    # small random perturbation
    for i in range(n):
        if p[i, 3] > 0.0 and RNG.random() < 0.7:
            p[i, 0] += (RNG.random() - 0.5) * 0.02 * p[i, 3]
            p[i, 1] += (RNG.random() - 0.5) * 0.02 * p[i, 3]
            p[i, 2] += (RNG.random() - 0.5) * 0.02
            p[i, 3] *= (0.98 + 0.04 * RNG.random())

    # try to make it feasible
    for _ in range(200):
        p[:, 0] = np.clip(p[:, 0], 0.0, 1.0)
        p[:, 1] = np.clip(p[:, 1], 0.0, 1.0)
        p[:, 2] = np.mod(p[:, 2], 1.0)
        p[:, 3] = np.clip(p[:, 3], 0.0, 1.0)

        changed = False
        for i in range(n):
            if p[i, 3] <= 0.0:
                continue
            ok = True
            for j in range(n):
                if i == j or p[j, 3] <= 0.0:
                    continue
                if _pair_violation(p[i], p[j]) > 0.0:
                    ok = False
                    break
            if not ok:
                p[i, 3] *= 0.98
                changed = True
                continue

            # check boundary
            c, s = _rotate(p[i, 2])
            ext = p[i, 3] * (abs(c) + abs(s)) * 0.5
            if (p[i, 0] - ext < -1e-9 or p[i, 0] + ext > 1.0 + 1e-9 or
                p[i, 1] - ext < -1e-9 or p[i, 1] + ext > 1.0 + 1e-9):
                p[i, 3] *= 0.98
                changed = True
                continue

        if not changed:
            break

    return p.ravel()


def _repair(p, n, steps=80):
    p = _project_params(p, n).copy()
    for _ in range(steps):
        p[:, 0] = np.clip(p[:, 0], 0.0, 1.0)
        p[:, 1] = np.clip(p[:, 1], 0.0, 1.0)
        p[:, 2] = np.mod(p[:, 2], 1.0)
        p[:, 3] = np.clip(p[:, 3], 0.0, 1.0)

        changed = False
        for i in range(n):
            if p[i, 3] <= 0.0:
                continue
            c, s = _rotate(p[i, 2])
            ext = p[i, 3] * (abs(c) + abs(s)) * 0.5
            pen = 0.0
            if p[i, 0] - ext < 0.0:
                pen += (p[i, 0] - ext) ** 2
            if p[i, 0] + ext > 1.0:
                pen += (p[i, 0] + ext - 1.0) ** 2
            if p[i, 1] - ext < 0.0:
                pen += (p[i, 1] - ext) ** 2
            if p[i, 1] + ext > 1.0:
                pen += (p[i, 1] + ext - 1.0) ** 2

            for j in range(n):
                if i == j or p[j, 3] <= 0.0:
                    continue
                pen += _pair_violation(p[i], p[j]) ** 2

            if pen > 1e-14:
                p[i, 3] *= 0.985
                changed = True

        if not changed:
            break

    # push tiny squares to zero
    p[p[:, 3] < 1e-12, 3] = 0.0
    return p.ravel()


def _local_optimize(p0, n, maxiter=400):
    p0 = _repair(p0, n).copy()
    best = p0.copy()
    best_val = -float(np.sum(_project_params(best, n)[:, 3]))

    weights = [0.3, 1.0, 3.0, 10.0, 30.0]
    for w in weights:
        try:
            res = minimize(
                lambda x: _objective_with_penalty_weight(x, n, w),
                best,
                method="L-BFGS-B",
                options={
                    "maxiter": maxiter,
                    "ftol": 1e-13,
                    "gtol": 1e-9,
                    "maxfun": 50000,
                },
                bounds=None,
            )
            cand = _repair(res.x, n)
            cand_val = -float(np.sum(_project_params(cand, n)[:, 3]))
            if cand_val > best_val - 1e-8:
                best = cand
                best_val = cand_val
        except Exception:
            pass

    # final polishing
    for _ in range(3):
        try:
            res = minimize(
                lambda x: _objective(x, n),
                best,
                method="L-BFGS-B",
                options={
                    "maxiter": maxiter,
                    "ftol": 1e-14,
                    "gtol": 1e-10,
                    "maxfun": 100000,
                },
                bounds=None,
            )
            cand = _repair(res.x, n)
            cand_val = -float(np.sum(_project_params(cand, n)[:, 3]))
            if cand_val > best_val - 1e-9:
                best = cand
                best_val = cand_val
        except Exception:
            pass

    return best, best_val


def _canonical_output(p, n):
    p = _project_params(p, n)
    out = []
    for i in range(n):
        cx, cy, ang, side = p[i]
        if side < 1e-11:
            side = 0.0
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
            ang = 0.0
        else:
            # final safety clipping
            c, s = _rotate(ang)
            ext = side * (abs(c) + abs(s)) * 0.5
            cx = min(max(cx, ext), 1.0 - ext)
            cy = min(max(cy, ext), 1.0 - ext)
        out.append((float(cx), float(cy), float(ang), float(side)))
    return out


def _score_output(squares, n):
    p = np.array(squares, dtype=float).reshape((n, 4))
    val = float(np.sum(p[:, 3]))
    # subtract a large penalty if invalid
    pen = _penalty(p.ravel(), n)
    return val - 1e6 * pen


def _try_simple_grids(n):
    """Generate good regular grid candidates."""
    cands = []
    for k in range(1, int(math.sqrt(n)) + 3):
        if k * k > n:
            # mixed rectangular grids: a columns x b rows
            pass

    # rectangular grids a * b with a*b <= n and use remaining as zero
    for a in range(1, n + 1):
        for b in range(1, n + 1):
            if a * b > n or a * b < n - 4:
                continue
            s = min(1.0 / a, 1.0 / b)
            w = a * s
            h = b * s
            # centre the block
            ox = (1.0 - w) * 0.5
            oy = (1.0 - h) * 0.5
            p = np.zeros((n, 4), dtype=float)
            idx = 0
            for i in range(a):
                for j in range(b):
                    if idx >= n:
                        break
                    p[idx] = (ox + (i + 0.5) * s, oy + (j + 0.5) * s, 0.0, s)
                    idx += 1
            while idx < n:
                p[idx] = (0.5, 0.5, 0.0, 0.0)
                idx += 1
            cands.append(p.ravel())

    # rotated square patterns: sometimes 1 large + small ones
    return cands


def _greedy_largest_first(n, side):
    """Place n-1 small squares and one large square, return start."""
    p = np.zeros((n, 4), dtype=float)
    p[0] = (0.5, 0.5, 0.0, side)
    if n > 1:
        # try to place tiny squares in corners
        small = (1.0 - side) * 0.5
        positions = []
        for x in (small * 0.5, 1.0 - small * 0.5):
            for y in (small * 0.5, 1.0 - small * 0.5):
                positions.append((x, y))
        # avoid overlaps: just shrink small if needed
        for i in range(1, n):
            if positions:
                x, y = positions.pop(0)
                p[i] = (x, y, 0.0, 0.0)
            else:
                p[i] = (0.5, 0.5, 0.0, 0.0)
    return p.ravel()


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    # n = 1: largest possible square is the unit square itself
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    candidates = []

    k = math.isqrt(n)
    # main starting points
    candidates.append(_random_feasible_start(n, k))
    if k > 1:
        candidates.append(_random_feasible_start(n, k - 1))
    candidates.append(_random_feasible_start(n, max(1, int(round(math.sqrt(n))))))

    for p in _try_simple_grids(n):
        candidates.append(p)

    # a few structured starts
    for frac in (0.6, 0.7, 0.8, 0.9):
        p = np.zeros((n, 4), dtype=float)
        p[0] = (0.5, 0.5, 0.0, frac)
        # distribute remaining tiny squares
        for i in range(1, n):
            p[i] = (RNG.random(), RNG.random(), 0.0, 0.05 * (1.0 - frac))
        candidates.append(_repair(p.ravel(), n))

    best = None
    best_val = -float("inf")

    # Evaluate candidates and optimize the most promising ones.
    scored = []
    for p0 in candidates:
        pr = _repair(p0, n)
        val = -float(np.sum(_project_params(pr, n)[:, 3]))
        # prefer feasible first
        pen = _penalty(pr, n)
        scored.append((val + 100.0 * pen, val, pr))

    scored.sort(key=lambda t: t[0])

    # optimize top candidates
    to_opt = scored[:8]
    for _, _, p0 in to_opt:
        try:
            p_opt, val_opt = _local_optimize(p0, n, maxiter=350)
            # recompute exact score with penalty to avoid invalid
            pen = _penalty(p_opt, n)
            if pen > 1e-7:
                continue
            if val_opt < best_val:
                # still accept if it's the first feasible
                if best is None:
                    best = p_opt
                    best_val = val_opt
                continue
            if best is None or val_opt > best_val + 1e-12:
                best = p_opt
                best_val = val_opt
        except Exception:
            continue

    # a few random restarts if time permits
    for _ in range(6):
        p0 = _random_feasible_start(n, max(1, k))
        try:
            p_opt, val_opt = _local_optimize(p0, n, maxiter=220)
            pen = _penalty(p_opt, n)
            if pen > 1e-7:
                continue
            if best is None or val_opt > best_val + 1e-12:
                best = p_opt
                best_val = val_opt
        except Exception:
            continue

    if best is None:
        # fallback: regular grid
        return solve(math.isqrt(n) * math.isqrt(n))[:n] if n > 0 else []

    out = _canonical_output(best, n)

    # Ensure exact count and validity with a last repair if needed.
    p = np.array(out, dtype=float).reshape((n, 4))
    if _penalty(p.ravel(), n) > 1e-8:
        p = _project_params(_repair(p.ravel(), n), n)
        out = _canonical_output(p.ravel(), n)

    return out
