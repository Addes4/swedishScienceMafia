import math
import numpy as np
from scipy.optimize import minimize

def _corners(cx, cy, a, s):
    # angle as fraction of full turn
    th = a * 2 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    # four corners in local frame
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for px, py in pts:
        x = cx + px * c - py * sn
        y = cy + px * sn + py * c
        out.append((x, y))
    return out

def _overlap_area_sq(c1, c2):
    # convex polygon intersection area (Sutherland–Hodgman)
    def clip(poly, a, b):
        # keep points on left of directed edge a->b
        out = []
        if not poly:
            return out
        def side(p):
            return (b[0]-a[0])*(p[1]-a[1]) - (b[1]-a[1])*(p[0]-a[0])
        S = len(poly)
        for i in range(S):
            p = poly[i]
            q = poly[(i+1)%S]
            sp = side(p)
            sq = side(q)
            if sp >= 0:
                out.append(p)
            if (sp > 0 and sq < 0) or (sp < 0 and sq > 0):
                t = sp / (sp - sq)
                ix = p[0] + t*(q[0]-p[0])
                iy = p[1] + t*(q[1]-p[1])
                out.append((ix, iy))
        return out
    A = _corners(*c1)
    B = _corners(*c2)
    poly = list(A)
    for i in range(4):
        a = B[i]
        b = B[(i+1)%4]
        poly = clip(poly, a, b)
        if not poly:
            return 0.0
    area = 0.0
    for i in range(len(poly)):
        x1,y1 = poly[i]
        x2,y2 = poly[(i+1)%len(poly)]
        area += x1*y2 - x2*y1
    return abs(area) * 0.5

def _penalty_and_grad(params, n):
    # params: for each square [cx, cy, a, s]
    P = params.reshape(n, 4)
    pen = 0.0
    grad = np.zeros_like(P)
    # boundary penalty
    for i in range(n):
        cx, cy, a, s = P[i]
        if s <= 1e-12:
            continue
        cs = _corners(cx, cy, a, s)
        for (x,y) in cs:
            if x < 0:
                d = -x
                pen += d*d
                grad[i,0] -= 2*d
            elif x > 1:
                d = x-1
                pen += d*d
                grad[i,0] += 2*d
            if y < 0:
                d = -y
                pen += d*d
                grad[i,1] -= 2*d
            elif y > 1:
                d = y-1
                pen += d*d
                grad[i,1] += 2*d
    # overlap penalty + approximate gradient
    eps = 1e-6
    for i in range(n):
        si = P[i,3]
        if si <= 1e-12:
            continue
        for j in range(i+1, n):
            sj = P[j,3]
            if sj <= 1e-12:
                continue
            # quick reject by centre distance
            dx = P[i,0]-P[j,0]
            dy = P[i,1]-P[j,1]
            maxr = (si+sj)*0.7072
            if dx*dx+dy*dy > maxr*maxr:
                continue
            ov = _overlap_area_sq(P[i], P[j])
            if ov <= 1e-12:
                continue
            pen += 50.0 * ov * ov
            # numeric gradient for the 8 parameters involved
            h = 1e-5
            for kk, col in ((i,0),(i,1),(i,2),(i,3),(j,0),(j,1),(j,2),(j,3)):
                pp = P[kk, col]
                P[kk, col] = pp + h
                ovp = _overlap_area_sq(P[i], P[j])
                P[kk, col] = pp - h
                ovm = _overlap_area_sq(P[i], P[j])
                P[kk, col] = pp
                d = (ovp - ovm)/(2*h)
                grad[kk, col] += 50.0 * 2 * ov * d
    return pen, grad.flatten()

def _neg_sum(params, n):
    P = params.reshape(n,4)
    return -np.sum(np.maximum(P[:,3], 0.0))

def _neg_sum_grad(params, n):
    g = np.zeros_like(params)
    P = params.reshape(n,4)
    for i in range(n):
        if P[i,3] > 0:
            g[i*4+3] = -1.0
    return g

def _objective(x, n):
    pen, gpen = _penalty_and_grad(x, n)
    return -np.sum(np.maximum(x.reshape(n,4)[:,3],0.0)) + pen

def _objective_grad(x, n):
    P = x.reshape(n,4)
    g = np.zeros_like(x)
    for i in range(n):
        if P[i,3] > 0:
            g[i*4+3] = -1.0
    pen, gpen = _penalty_and_grad(x, n)
    return g + gpen

def _initial(n):
    # try perfect square grid first
    k = math.isqrt(n)
    if k*k == n:
        s = 1.0/k
        P = []
        for i in range(k):
            for j in range(k):
                P.append([(i+0.5)*s, (j+0.5)*s, 0.0, s])
        return np.array(P).flatten(), k, s
    # otherwise: use k x k grid of size 1/k plus extra squares in a row/col
    # Try a few candidate layouts and pick best after relaxation start.
    best = None
    best_score = -1
    # layout A: all equal small squares in a near-square grid
    cols = math.ceil(math.sqrt(n))
    rows = math.ceil(n/cols)
    sA = min(1.0/cols, 1.0/rows)
    PA = []
    for i in range(rows):
        for j in range(cols):
            if len(PA) >= n:
                break
            PA.append([(j+0.5)*sA, (i+0.5)*sA, 0.0, sA])
        if len(PA) >= n:
            break
    return np.array(PA).flatten(), rows, cols

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # Heuristic starts
    starts = []
    # Start 1: square grid if perfect square
    k = math.isqrt(n)
    if k*k == n:
        s = 1.0/k
        P = []
        for i in range(k):
            for j in range(k):
                P.append([(i+0.5)*s, (j+0.5)*s, 0.0, s])
        starts.append(np.array(P).flatten())
    # Start 2: general grid with equal squares
    cols = math.ceil(math.sqrt(n))
    rows = math.ceil(n/cols)
    s2 = min(1.0/cols, 1.0/rows)
    P2 = []
    for i in range(rows):
        for j in range(cols):
            if len(P2) >= n:
                break
            P2.append([(j+0.5)*s2, (i+0.5)*s2, 0.0, s2])
        if len(P2) >= n:
            break
    # pad if needed
    while len(P2) < n:
        P2.append([0.5, 0.5, 0.0, 0.0])
    starts.append(np.array(P2).flatten())
    # Start 3: slightly larger first k^2 squares, rest zero
    if k*k < n:
        P3 = []
        s3 = 1.0/k
        for i in range(k):
            for j in range(k):
                P3.append([(i+0.5)*s3, (j+0.5)*s3, 0.0, s3])
        while len(P3) < n:
            P3.append([0.5, 0.5, 0.0, 0.0])
        starts.append(np.array(P3).flatten())
    # Start 4: strip layout
    P4 = []
    s4 = 1.0/n
    for i in range(n):
        P4.append([(i+0.5)*s4, 0.5, 0.0, s4])
    starts.append(np.array(P4).flatten())

    best_x = None
    best_val = -1e18

    # Bounds: cx, cy in [-0.5, 1.5] (allow some freedom), angle in [-0.25,0.25], side in [0,1]
    bounds = []
    for _ in range(n):
        bounds.append((-0.5, 1.5))
        bounds.append((-0.5, 1.5))
        bounds.append((-0.25, 0.25))
        bounds.append((0.0, 1.0))

    for x0 in starts:
        x0 = np.clip(x0, [b[0] for b in bounds], [b[1] for b in bounds])
        try:
            res = minimize(_objective_grad, x0, args=(n,), method='L-BFGS-B', jac=True,
                           bounds=bounds, options={'maxiter': 200, 'ftol':1e-12, 'gtol':1e-8})
            val = res.fun
            if val < best_val:
                best_val = val
                best_x = res.x
        except Exception:
            pass
    if best_x is None:
        best_x = starts[1]

    # Post-process: enforce feasibility, zero out tiny/negative squares
    P = best_x.reshape(n,4)
    # Slightly shrink any overlapping squares (few iterations)
    for _ in range(50):
        changed = False
        for i in range(n):
            si = P[i,3]
            if si <= 1e-12:
                continue
            for j in range(i+1,n):
                sj = P[j,3]
                if sj <= 1e-12:
                    continue
                ov = _overlap_area_sq(P[i], P[j])
                if ov > 1e-10:
                    # shrink the smaller one slightly
                    if si <= sj:
                        P[i,3] *= 0.98
                        si = P[i,3]
                    else:
                        P[j,3] *= 0.98
                        sj = P[j,3]
                    changed = True
        if not changed:
            break
    # boundary clamp: move/shrink inside
    for i in range(n):
        s = P[i,3]
        if s <= 1e-12:
            P[i,:3] = [0.5,0.5,0.0]
            continue
        cs = _corners(P[i,0], P[i,1], P[i,2], s)
        xs = [p[0] for p in cs]
        ys = [p[1] for p in cs]
        minx, maxx = min(xs), max(xs)
        miny, maxy = min(ys), max(ys)
        if minx < 0:
            P[i,0] -= minx
        if maxx > 1:
            P[i,0] -= (maxx-1)
        if miny < 0:
            P[i,1] -= miny
        if maxy > 1:
            P[i,1] -= (maxy-1)
        # after moving, re-check, shrink if needed
        cs = _corners(P[i,0], P[i,1], P[i,2], s)
        xs = [p[0] for p in cs]
        ys = [p[1] for p in cs]
        if min(xs) < 0 or max(xs) > 1 or min(ys) < 0 or max(ys) > 1:
            P[i,3] = 0.0
            P[i,:3] = [0.5,0.5,0.0]

    # final overlap fix: shrink until no overlap
    for _ in range(200):
        bad = False
        for i in range(n):
            if P[i,3] <= 1e-12:
                continue
            for j in range(i+1,n):
                if P[j,3] <= 1e-12:
                    continue
                if _overlap_area_sq(P[i], P[j]) > 1e-9:
                    P[j,3] *= 0.9
                    bad = True
        if not bad:
            break

    # build result
    result = []
    for i in range(n):
        cx, cy, a, s = P[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = ((a + 0.25) % 0.5) - 0.25
        s = min(max(s, 0.0), 1.0)
        result.append((float(cx), float(cy), float(a), float(s)))
    return result
