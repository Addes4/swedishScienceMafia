import math
import random
import numpy as np
from scipy.optimize import minimize

# ----------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------

def corners(cx, cy, a, s):
    """Return the four corners of a square (centre, angle fraction of turn, side)."""
    t = 2.0 * math.pi * a
    c, sn = math.cos(t), math.sin(t)
    h = 0.5 * s
    dx, dy = h * c, h * sn
    ex, ey = -h * sn, h * c
    return ((cx - dx - ex, cy - dy - ey),
            (cx + dx - ex, cy + dy - ey),
            (cx + dx + ex, cy + dy + ey),
            (cx - dx + ex, cy - dy + ey))


def _proj(poly, ax, ay):
    vals = [x * ax + y * ay for x, y in poly]
    return min(vals), max(vals)


def overlap_area(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Positive if the two squares have overlapping interiors (SAT on four axes)."""
    if s1 <= 1e-14 or s2 <= 1e-14:
        return 0.0
    p1 = corners(cx1, cy1, a1, s1)
    p2 = corners(cx2, cy2, a2, s2)
    axes = []
    for p in (p1, p2):
        for i in range(4):
            x1, y1 = p[i]
            x2, y2 = p[(i + 1) & 3]
            ex, ey = x2 - x1, y2 - y1
            L = math.hypot(ex, ey)
            if L > 1e-15:
                axes.append((-ey / L, ex / L))
    pen = 1e9
    for ax, ay in axes:
        lo1, hi1 = _proj(p1, ax, ay)
        lo2, hi2 = _proj(p2, ax, ay)
        gap = min(hi1 - lo2, hi2 - lo1)
        if gap <= 0.0:
            return 0.0
        if gap < pen:
            pen = gap
    return pen


def inside_ok(cx, cy, a, s):
    """Return 0 if the square lies inside the unit square, else a positive violation."""
    if s <= 0.0:
        return 0.0
    xs = [p[0] for p in corners(cx, cy, a, s)]
    ys = [p[1] for p in corners(cx, cy, a, s)]
    v = 0.0
    if min(xs) < 0.0:
        v += -min(xs)
    if max(xs) > 1.0:
        v += max(xs) - 1.0
    if min(ys) < 0.0:
        v += -min(ys)
    if max(ys) > 1.0:
        v += max(ys) - 1.0
    return v


# ----------------------------------------------------------------------
# constructive packings
# ----------------------------------------------------------------------

def grid_packing(n, k):
    """k x k regular grid; remaining squares are size-zero points."""
    out = []
    if k > 0:
        s = 1.0 / k
        for i in range(k):
            for j in range(k):
                out.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
    while len(out) < n:
        out.append([0.5, 0.5, 0.0, 0.0])
    return out[:n]


def row_packing(n):
    """One row of n equal squares, as many as fit; rest are points."""
    out = []
    if n > 0:
        s = 1.0 / n
        for i in range(n):
            out.append([(i + 0.5) * s, 0.5, 0.0, s])
    return out


def greedy_rect_packing(n):
    """
    Greedy guillotine packing:
    maintain free rectangles (axis-aligned).  At every step split the largest
    free rectangle into a square and two residual rectangles.
    """
    rects = [(0.0, 0.0, 1.0, 1.0)]          # x, y, w, h
    squares = []
    for _ in range(n):
        # choose rectangle that can give the largest square
        best = None
        bestv = -1.0
        for r in rects:
            v = min(r[2], r[3])
            if v > bestv:
                bestv = v
                best = r
        if best is None or bestv <= 1e-12:
            squares.append([0.5, 0.5, 0.0, 0.0])
            continue
        x, y, w, h = best
        rects.remove(best)
        s = min(w, h)
        squares.append([x + 0.5 * s, y + 0.5 * s, 0.0, s])
        if w - s > 1e-12:
            rects.append((x + s, y, w - s, h))
        if h - s > 1e-12:
            rects.append((x, y + s, w, h - s))
    return squares


def best_constructive(n):
    """Return the best deterministic starting packing among several candidates."""
    best = None
    best_score = -1.0

    cands = []
    if n > 0:
        # pure grids
        for k in range(max(1, int(math.isqrt(n)) - 2), int(math.isqrt(n)) + 3):
            if k * k <= n:
                cands.append(grid_packing(n, k))
        # rows
        cands.append(row_packing(n))
        # greedy rectangle
        cands.append(greedy_rect_packing(n))
        # a few grid + extra-row mixes
        for k in range(max(1, int(math.isqrt(n)) - 2), int(math.isqrt(n)) + 2):
            if k * k >= n:
                continue
            base = grid_packing(k * k, k)
            rem = n - k * k
            # put remaining squares in one row below the grid
            s = 1.0 / k
            if rem > 0:
                y0 = (k - 0.5) * s
                # shrink a bit to make room vertically if necessary
                if y0 + 0.5 * s > 1.0:
                    y0 = 1.0 - 0.5 * s
                rs = min(s, 1.0 / rem)
                for i in range(rem):
                    base.append([(i + 0.5) * rs, y0, 0.0, rs])
            cands.append(base)

    for c in cands:
        sc = score(c)
        if sc > best_score:
            best_score = sc
            best = c
    return [row[:] for row in best]


def score(sqs):
    return sum(x[3] for x in sqs)


# ----------------------------------------------------------------------
# local optimisation
# ----------------------------------------------------------------------

def pack_penalty(v, n):
    """v: flat vector length 4n.  Returns (negative sum of sides + penalties)."""
    cx = v[0::4]
    cy = v[1::4]
    a = v[2::4]
    s = np.clip(v[3::4], 0.0, 1.0)
    total = -float(np.sum(s))

    # boundary penalties (approximate with four corners of the AABB)
    th = 2.0 * np.pi * a
    c, sn = np.cos(th), np.sin(th)
    h = 0.5 * s
    ex = np.abs(h * c) + np.abs(h * sn)
    ey = np.abs(h * sn) + np.abs(h * c)
    lo_x = cx - ex
    hi_x = cx + ex
    lo_y = cy - ey
    hi_y = cy + ey
    pen = 1e6 * (float(np.sum(np.maximum(0.0, -lo_x) ** 2)) +
                 float(np.sum(np.maximum(0.0, hi_x - 1.0) ** 2)) +
                 float(np.sum(np.maximum(0.0, -lo_y) ** 2)) +
                 float(np.sum(np.maximum(0.0, hi_y - 1.0) ** 2)))

    # non-overlap penalties, vectorised for the common axis-aligned case
    for i in range(n):
        if s[i] <= 1e-14:
            continue
        for j in range(i + 1, n):
            if s[j] <= 1e-14:
                continue
            if abs(a[i] - a[j]) < 1e-12 and abs(a[i] - round(a[i])) < 1e-12:
                # both axis aligned
                d1 = max(0.0, 0.5 * (s[i] + s[j]) - abs(cx[i] - cx[j]))
                d2 = max(0.0, 0.5 * (s[i] + s[j]) - abs(cy[i] - cy[j]))
                ov = d1 * d2
            else:
                ov = overlap_area(cx[i], cy[i], a[i], s[i],
                                  cx[j], cy[j], a[j], s[j]) ** 2
            pen += 1e6 * ov
    return total + pen


def make_vector(sqs):
    v = np.zeros(4 * len(sqs))
    for i, (cx, cy, a, s) in enumerate(sqs):
        v[4 * i] = cx
        v[4 * i + 1] = cy
        v[4 * i + 2] = a
        v[4 * i + 3] = s
    return v


def vector_to_squares(v, n):
    out = []
    for i in range(n):
        cx = float(np.clip(v[4 * i], 0.0, 1.0))
        cy = float(np.clip(v[4 * i + 1], 0.0, 1.0))
        a = float(v[4 * i + 2] % 1.0)
        s = float(np.clip(v[4 * i + 3], 0.0, 1.0))
        out.append((cx, cy, a, s))
    return out


def local_optimize(sqs, maxiter=60, restart_angles=False, tries=1):
    n = len(sqs)
    if n == 0:
        return sqs
    best = [tuple(x) for x in sqs]
    best_score = score(best)
    rng = random.Random(12345)

    for t in range(tries):
        v0 = make_vector(sqs)
        if restart_angles and t > 0:
            for i in range(n):
                v0[4 * i + 2] = rng.random()
                v0[4 * i] += rng.uniform(-0.02, 0.02)
                v0[4 * i + 1] += rng.uniform(-0.02, 0.02)

        def fun(v):
            return pack_penalty(v, n)

        try:
            res = minimize(fun, v0, method="Powell",
                           options={"maxiter": maxiter, "xtol": 1e-4, "ftol": 1e-5})
        except Exception:
            res = None
        if res is not None:
            cand = vector_to_squares(res.x, n)
            sc = score(cand)
            if sc > best_score + 1e-9:
                best_score = sc
                best = cand
    return best


# ----------------------------------------------------------------------
# main
# ----------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # known very good layouts for tiny n (found by search)
    specials = {
        2: [(0.5, 0.5, 0.0, 0.5), (0.5, 0.5, 0.25, 0.5)],
        3: [(0.5, 2.0 / 3.0, 0.0, 1.0 / 3.0),
            (0.5, 1.0 / 3.0, 0.0, 1.0 / 3.0),
            (0.75, 0.5, 0.0, 0.5)],
        4: [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
            (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)],
    }
    if n in specials:
        # refine the special ones too
        return local_optimize(specials[n], maxiter=30, tries=1)

    start = best_constructive(n)
    start = [tuple(x) for x in start]

    # try several refinement passes, then a final polish with more iterations
    best = local_optimize(start, maxiter=40, tries=2)
    if n <= 20:
        best = local_optimize(best, maxiter=80, tries=3, restart_angles=True)
    elif n <= 60:
        best = local_optimize(best, maxiter=50, tries=1)
    else:
        best = local_optimize(best, maxiter=25, tries=1)

    # ensure correct length
    best = list(best[:n])
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))

    # sanity: clamp and return tuples
    out = []
    for cx, cy, a, s in best:
        cx = min(max(float(cx), 0.0), 1.0)
        cy = min(max(float(cy), 0.0), 1.0)
        a = float(a) % 1.0
        s = min(max(float(s), 0.0), 1.0)
        out.append((cx, cy, a, s))
    return out


if __name__ == "__main__":
    for n in range(1, 11):
        sol = solve(n)
        print(n, sum(x[3] for x in sol))
