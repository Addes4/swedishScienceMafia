import math
import random


def _overlap(s1, s2):
    """Return True if two squares (cx, cy, ang, side) overlap interiors."""
    cx1, cy1, a1, s1v = s1
    cx2, cy2, a2, s2v = s2
    if s1v <= 1e-12 or s2v <= 1e-12:
        return False

    # Half side lengths
    h1 = s1v * 0.5
    h2 = s2v * 0.5

    # Square corners relative to center
    def corners(cx, cy, ang, h):
        th = ang * 2 * math.pi
        c, sn = math.cos(th), math.sin(th)
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
        return pts

    p1 = corners(cx1, cy1, a1, h1)
    p2 = corners(cx2, cy2, a2, h2)

    # SAT for convex polygons
    def project(poly, axis):
        vals = [p[0] * axis[0] + p[1] * axis[1] for p in poly]
        return min(vals), max(vals)

    def axes(poly):
        res = []
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            res.append((-ey, ex))
        return res

    for poly, other in ((p1, p2), (p2, p1)):
        for ax in axes(poly):
            ln = math.hypot(ax[0], ax[1])
            if ln < 1e-15:
                continue
            ax = (ax[0] / ln, ax[1] / ln)
            mn1, mx1 = project(p1, ax)
            mn2, mx2 = project(p2, ax)
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return False
    return True


def _feasible(squares, tol=1e-9):
    n = len(squares)
    for i in range(n):
        cx, cy, a, s = squares[i]
        if s < -tol:
            return False
        if s > 0:
            # inside unit square check via corners
            th = a * 2 * math.pi
            c, sn = math.cos(th), math.sin(th)
            h = s * 0.5
            for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
                x = cx + dx * c - dy * sn
                y = cy + dx * sn + dy * c
                if x < -tol or x > 1 + tol or y < -tol or y > 1 + tol:
                    return False
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _clamp_square(sq):
    cx, cy, a, s = sq
    a = a % 1.0
    if s < 0:
        s = 0.0
    if s > 1.0:
        s = 1.0
    # clamp center so square stays inside if possible for axis-aligned; for rotated, shrink if needed
    th = a * 2 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    minx = min(cx + dx * c - dy * sn for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)))
    maxx = max(cx + dx * c - dy * sn for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)))
    miny = min(cy + dx * sn + dy * c for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)))
    maxy = max(cy + dx * sn + dy * c for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)))
    if minx < 0:
        cx -= minx
    if maxx > 1:
        cx -= (maxx - 1)
    if miny < 0:
        cy -= miny
    if maxy > 1:
        cy -= (maxy - 1)
    # after clamping, if still outside, shrink
    minx = min(cx + dx * c - dy * sn for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)))
    maxx = max(cx + dx * c - dy * sn for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)))
    miny = min(cy + dx * sn + dy * c for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)))
    maxy = max(cy + dx * sn + dy * c for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)))
    if minx < -1e-12 or maxx > 1 + 1e-12 or miny < -1e-12 or maxy > 1 + 1e-12:
        # reduce size aggressively
        scale = 1.0
        if maxx - minx > 1:
            scale = min(scale, 1.0 / (maxx - minx))
        if maxy - miny > 1:
            scale = min(scale, 1.0 / (maxy - miny))
        s *= scale * 0.999
        h = s * 0.5
        cx = min(max(cx, h), 1 - h)
        cy = min(max(cy, h), 1 - h)
    return (cx, cy, a, s)


def _grid_construct(n):
    """Basic grid plus optimized leftover."""
    if n == 0:
        return []
    k = max(1, int(math.isqrt(n)))
    # try divisors / near-square grid with n squares exactly? We only need n squares.
    # Use k x k grid for as many as possible, then refine leftovers.
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    return squares


def _refine(squares, iterations=2000):
    """Local search: try moving / resizing random square, accept if improves sum and feasible."""
    n = len(squares)
    best = [list(s) for s in squares]
    best_score = sum(s[3] for s in best)
    cur = [list(s) for s in best]
    cur_score = best_score

    for it in range(iterations):
        i = random.randrange(n)
        sq = list(cur[i])
        old = list(sq)

        mode = random.random()
        if mode < 0.4:
            # perturb center
            sq[0] += random.uniform(-0.08, 0.08)
            sq[1] += random.uniform(-0.08, 0.08)
        elif mode < 0.7:
            # perturb angle
            sq[2] += random.uniform(-0.15, 0.15)
        else:
            # perturb size
            sq[3] += random.uniform(-0.05, 0.05)

        sq = _clamp_square(sq)
        # boundary clamp
        sq[0] = min(max(sq[0], 0.0), 1.0)
        sq[1] = min(max(sq[1], 0.0), 1.0)
        sq[2] = sq[2] % 1.0
        if sq[3] < 0:
            sq[3] = 0.0
        if sq[3] > 1:
            sq[3] = 1.0

        cur[i] = sq
        if _feasible(cur):
            new_score = sum(s[3] for s in cur)
            if new_score > cur_score - 1e-14:
                cur_score = new_score
                if cur_score > best_score:
                    best_score = cur_score
                    best = [list(s) for s in cur]
            else:
                cur[i] = old
        else:
            cur[i] = old

    return [tuple(s) for s in best]


def _fancy_patterns(n):
    """Try known good configurations for small n."""
    # For very small n, optimizations known:
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        s = 0.5
        return [(0.25, 0.5, 0.0, s), (0.75, 0.5, 0.0, s)]
    if n == 3:
        # two on bottom, one on top
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s), (0.5, 0.75, 0.0, s)]
    if n == 4:
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s), (0.25, 0.75, 0.0, s), (0.75, 0.75, 0.0, s)]
    if n == 5:
        # 4 small corners + 1 center, sizes ~0.5 and ~0.5? Actually four 0.5 squares side by side leaves center diamond
        # Better: 5 squares: four of side 0.5? No overlap. Use 5 equal squares in a 2x3 grid missing one.
        s = 1.0 / 3.0
        res = []
        for i in range(2):
            for j in range(3):
                res.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        # remove one and optimize? Just return 6 and truncate? We need exactly 5. Try 5 with one large.
        # Known: 5 squares can have sum > 1. Use four 0.5 squares in 2x2 plus one in middle? No, overlap.
        # Use grid 2x3 with 6 squares, remove center one? That's 5.
        res = []
        for i in range(2):
            for j in range(3):
                res.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        res = res[:5]
        return res
    return None


def solve(n):
    if n <= 0:
        return []
    # special patterns
    pat = _fancy_patterns(n)
    if pat is not None:
        return pat

    # general approach: k x k grid plus extra squares squeezed in
    k = int(math.isqrt(n))
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))

    # Use a finer grid for remaining squares
    remaining = n - k * k
    if remaining > 0:
        # Try to refine using randomized search
        for _ in range(remaining):
            squares.append((0.5, 0.5, 0.0, 0.0))

    # Refine with local search
    squares = _refine(squares, iterations=min(5000, 200 + 20 * n))
    return squares
