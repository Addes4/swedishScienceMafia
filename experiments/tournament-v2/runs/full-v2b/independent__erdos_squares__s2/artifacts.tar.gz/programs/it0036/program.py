import math

# Global cache of best results for rectangles of size (w, h) with k squares.
# Keyed by (w, h, k) rounded to avoid float issues.
_CACHE = {}


def _norm(x):
    return round(x, 9)


def _rect_best(w, h, k):
    """Return (best_sum, list_of_squares_in_local_coords) for placing k squares
    in a w by h rectangle (0..w, 0..h). Squares are (cx, cy, angle, side)."""
    if k == 0:
        return 0.0, []
    if w <= 0 or h <= 0:
        return 0.0, [(0.0, 0.0, 0.0, 0.0)] * k

    key = (_norm(w), _norm(h), k)
    if key in _CACHE:
        return _CACHE[key]

    # If w and h are nearly equal, use square grid approximation as base.
    # Try guillotine splits.
    best_sum = -1.0
    best_list = None

    # Try splitting with a vertical cut: left width x, right width w-x
    for i in range(1, k):
        # We need to choose x. Optimize by trying a few candidate x values.
        # Candidate x proportional to sqrt(i/k) * w (area-balanced).
        # Also try equal squares arrangement boundaries.
        candidates = set()
        # area-balanced
        candidates.add(w * math.sqrt(i / k))
        candidates.add(w * i / k)
        candidates.add(w * 0.5)
        # Add grid-based: if we put a square of side s in each part.
        for frac in [0.25, 0.5, 0.75]:
            candidates.add(w * frac)
        for x in candidates:
            x = max(0.0, min(w, x))
            if x <= 0 or x >= w:
                continue
            s1, l1 = _rect_best(x, h, i)
            s2, l2 = _rect_best(w - x, h, k - i)
            total = s1 + s2
            if total > best_sum:
                best_sum = total
                best_list = l1 + [(cx + x, cy, a, s) for (cx, cy, a, s) in l2]

    # Try horizontal split
    for i in range(1, k):
        candidates = set()
        candidates.add(h * math.sqrt(i / k))
        candidates.add(h * i / k)
        candidates.add(h * 0.5)
        for frac in [0.25, 0.5, 0.75]:
            candidates.add(h * frac)
        for y in candidates:
            y = max(0.0, min(h, y))
            if y <= 0 or y >= h:
                continue
            s1, l1 = _rect_best(w, y, i)
            s2, l2 = _rect_best(w, h - y, k - i)
            total = s1 + s2
            if total > best_sum:
                best_sum = total
                best_list = l1 + [(cx, cy + y, a, s) for (cx, cy, a, s) in l2]

    # Base case: try to place one square (rotated to touch all sides) in the rect,
    # and if k==1 that is the only option. For k>1, also try filling with grid.
    if k == 1:
        # Largest axis-aligned square
        s_axis = min(w, h)
        # Largest rotated square that fits in w x h rectangle.
        # A square of side s rotated by angle theta has bounding box:
        # width = s*(cos+sin), height = s*(cos+sin) if theta in [0,pi/2] where cos=|cos|, sin=|sin|
        # For angle 0..0.25 (0..90deg), bounding box both = s*(c+s).
        # But a square tilted can also fit differently if w != h.
        # General: for angle t in [0, pi/4], bounding box is s*(cos t + sin t) in both dims.
        # So max axis-aligned bounding square side = min(w,h), giving same s.
        # But rotated square can be larger if placed diagonally? No: bounding box must fit.
        # Actually for a square rotated by 45deg, bounding box side = s*sqrt(2). So s = min(w,h)/sqrt(2) < min(w,h).
        # So axis-aligned is best for k==1.
        s = min(w, h)
        best_sum = s
        best_list = [(w / 2, h / 2, 0.0, s)]
    else:
        # Try grid arrangement: find best a x b grid with a*b >= k, a<=b or whatever.
        # Or just use all k squares of equal size in a grid.
        # This is a fallback for when splits don't help.
        # Find a,b such that a*b >= k and we can fit squares of size s in w x h.
        best_grid_sum = 0.0
        best_grid_list = None
        for a in range(1, k + 1):
            b = (k + a - 1) // a
            if a * b < k:
                continue
            # We place k squares in a grid of a columns and b rows, but only k of them.
            # Actually place exactly a*b squares? No, we only need k.
            # Use a columns, b rows, fill first k cells.
            s = min(w / a, h / b)
            if s <= 0:
                continue
            total = s * k
            if total > best_grid_sum:
                best_grid_sum = total
                lst = []
                count = 0
                for j in range(b):
                    for i in range(a):
                        if count >= k:
                            break
                        cx = (i + 0.5) * s
                        cy = (j + 0.5) * s
                        lst.append((cx, cy, 0.0, s))
                        count += 1
                    if count >= k:
                        break
                best_grid_list = lst
        if best_grid_sum > best_sum:
            best_sum = best_grid_sum
            best_list = best_grid_list

    _CACHE[key] = (best_sum, best_list)
    return best_sum, best_list


def solve(n):
    """Return n squares inside the unit square maximising sum of side lengths."""
    global _CACHE
    _CACHE = {}
    w, h = 1.0, 1.0
    total, squares = _rect_best(w, h, n)
    # Ensure all squares are within [0,1] and have nonnegative side.
    res = []
    for cx, cy, angle, side in squares:
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        side = max(0.0, min(1.0, side))
        angle = angle % 1.0
        res.append((cx, cy, angle, side))
    # Pad if fewer than n (shouldn't happen)
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
