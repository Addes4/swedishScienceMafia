import math
import random
import numpy as np
from scipy.optimize import minimize

# ---------- geometry helpers ----------

def corners(cx, cy, ang, s):
    """Return the 4 corner points (as np arrays) of a square."""
    half = 0.5 * s
    ca, sa = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
    pts = []
    for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        dx, dy = sx * half, sy * half
        pts.append((cx + ca * dx - sa * dy, cy + sa * dx + ca * dy))
    return pts

def _seg_intersect(p1, p2, p3, p4):
    d1 = (p2[0] - p1[0], p2[1] - p1[1])
    d2 = (p4[0] - p3[0], p4[1] - p3[1])
    denom = d1[0] * d2[1] - d1[1] * d2[0]
    if abs(denom) < 1e-12:
        return False
    t = ((p3[0] - p1[0]) * d2[1] - (p3[1] - p1[1]) * d2[0]) / denom
    u = ((p3[0] - p1[0]) * d1[1] - (p3[1] - p1[1]) * d1[0]) / denom
    return 1e-9 < t < 1 - 1e-9 and 1e-9 < u < 1 - 1e-9

def overlap_area(c1, c2):
    """Return True if two oriented square boundaries cross; approximation of overlap."""
    p = corners(*c1)
    q = corners(*c2)
    for i in range(4):
        for j in range(4):
            if _seg_intersect(p[i], p[(i + 1) % 4], q[j], q[(j + 1) % 4]):
                return True
    # check containment via centroid-in-square
    def inside(cx, cy, ang, s, px, py):
        ca, sa = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
        dx, dy = px - cx, py - cy
        lx = ca * dx + sa * dy
        ly = -sa * dx + ca * dy
        return abs(lx) <= 0.5 * s + 1e-12 and abs(ly) <= 0.5 * s + 1e-12
    if inside(*c2, c1[0], c1[1]) or inside(*c1, c2[0], c2[1]):
        # need actual area overlap check -> use SAT for oriented squares
        return sat_overlap(c1, c2)
    return False

def sat_overlap(c1, c2):
    """Separating axis theorem for two oriented squares."""
    def axes(cx, cy, ang):
        ca, sa = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
        return [(ca, sa), (-sa, ca)]
    def proj(cx, cy, ang, s, ax):
        ca, sa = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
        half = 0.5 * s
        pts = []
        for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            dx, dy = sx * half, sy * half
            pts.append((cx + ca * dx - sa * dy, cy + sa * dx + ca * dy))
        vals = [px * ax[0] + py * ax[1] for px, py in pts]
        return min(vals), max(vals)
    for ax in axes(*c1[:3]) + axes(*c2[:3]):
        lo1, hi1 = proj(*c1, ax)
        lo2, hi2 = proj(*c2, ax)
        if hi1 - 1e-12 <= lo2 or hi2 - 1e-12 <= lo1:
            return False
    return True

def feasible(cands):
    n = len(cands)
    for i in range(n):
        cx, cy, ang, s = cands[i]
        if s <= 0:
            continue
        # containment (approximate: all corners inside)
        for px, py in corners(cx, cy, ang, s):
            if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                return False
        for j in range(i + 1, n):
            if cands[j][3] <= 0:
                continue
            if sat_overlap(cands[i], cands[j]):
                return False
    return True

# ---------- constructive initial layouts ----------

def grid_layout(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            if len(res) < n:
                res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]

def greedy_layout(n, rng, base_side=None):
    """Place squares one by one, maximizing each side greedily."""
    placed = []
    for idx in range(n):
        best = None
        best_s = 0.0
        # try a number of candidate placements
        trials = 40 if idx > 0 else 1
        for _ in range(trials):
            ang = 0.0 if rng.random() < 0.7 else rng.random()
            # sample center
            cx = rng.random()
            cy = rng.random()
            # find max side that fits
            if idx == 0:
                # largest inscribed square in unit square
                lo, hi = 0.0, 1.0
                for _ in range(30):
                    mid = 0.5 * (lo + hi)
                    cand = (cx, cy, ang, mid)
                    ok = True
                    for px, py in corners(*cand):
                        if px < -1e-12 or px > 1 + 1e-12 or py < -1e-12 or py > 1 + 1e-12:
                            ok = False
                            break
                    if ok:
                        lo = mid
                    else:
                        hi = mid
                s = lo
            else:
                cap = base_side if base_side else 1.0
                lo, hi = 0.0, cap
                for _ in range(30):
                    mid = 0.5 * (lo + hi)
                    cand = (cx, cy, ang, mid)
                    ok = True
                    for px, py in corners(*cand):
                        if px < -1e-12 or px > 1 + 1e-12 or py < -1e-12 or py > 1 + 1e-12:
                            ok = False
                            break
                    if ok:
                        for p in placed:
                            if sat_overlap(cand, p):
                                ok = False
                                break
                    if ok:
                        lo = mid
                    else:
                        hi = mid
                s = lo
            if s > best_s:
                best_s = s
                best = (cx, cy, ang, s)
        # local refine of this square against placed ones
        if best is not None and best[3] > 0:
            best = refine_single(best, placed, n, idx)
        placed.append(best if best else (0.5, 0.5, 0.0, 0.0))
    return placed

def refine_single(sq, placed, n, idx):
    """Coordinate ascent on one square to maximize its side while avoiding overlaps."""
    cx, cy, ang, s = sq
    best = (cx, cy, ang, s)
    for _ in range(20):
        improved = False
        for dcx in (-0.02, -0.01, 0.01, 0.02):
            for dcy in (-0.02, -0.01, 0.01, 0.02):
                for da in (-0.02, -0.01, 0.01, 0.02):
                    ncx = min(1, max(0, cx + dcx))
                    ncy = min(1, max(0, cy + dcy))
                    nang = (ang + da) % 1.0
                    # max side at this pose
                    lo, hi = 0.0, 1.0
                    for _ in range(25):
                        mid = 0.5 * (lo + hi)
                        cand = (ncx, ncy, nang, mid)
                        ok = True
                        for px, py in corners(*cand):
                            if px < -1e-12 or px > 1 + 1e-12 or py < -1e-12 or py > 1 + 1e-12:
                                ok = False
                                break
                        if ok:
                            for p in placed:
                                if sat_overlap(cand, p):
                                    ok = False
                                    break
                        if ok:
                            lo = mid
                        else:
                            hi = mid
                    if lo > best[3] + 1e-9:
                        best = (ncx, ncy, nang, lo)
                        improved = True
        if not improved:
            break
        cx, cy, ang, s = best
    return best

# ---------- global refinement ----------

def objective(params, n):
    return -sum(max(0.0, params[4 * i + 3]) for i in range(n))

def pack_constraints(params, n):
    cons = []
    cands = [(params[4 * i], params[4 * i + 1], params[4 * i + 2] % 1.0, max(0.0, params[4 * i + 3]))
             for i in range(n)]
    return cands, cons

def refine_global(cands, n, rng, maxiter=30):
    x0 = []
    for cx, cy, ang, s in cands:
        x0.extend([cx, cy, ang, s])
    x0 = np.array(x0)

    def obj(x):
        return -sum(max(0.0, x[4 * i + 3]) for i in range(n))

    def con_containment(x):
        out = []
        for i in range(n):
            cx, cy, ang, s = x[4 * i], x[4 * i + 1], x[4 * i + 2] % 1.0, max(0.0, x[4 * i + 3])
            if s <= 0:
                continue
            ca, sa = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
            half = 0.5 * s
            for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                dx, dy = sx * half, sy * half
                px = cx + ca * dx - sa * dy
                py = cy + sa * dx + ca * dy
                out.append(px)        # >= 0
                out.append(1 - px)    # >= 0
                out.append(py)
                out.append(1 - py)
        return np.array(out)

    def con_nonoverlap(x):
        out = []
        cs = []
        for i in range(n):
            cs.append((x[4 * i], x[4 * i + 1], x[4 * i + 2] % 1.0, max(0.0, x[4 * i + 3])))
        for i in range(n):
            if cs[i][3] <= 0:
                continue
            for j in range(i + 1, n):
                if cs[j][3] <= 0:
                    continue
                # approximate non-overlap via SAT distance
                d = sep_dist(cs[i], cs[j])
                out.append(d)
        return np.array(out) if out else np.array([1.0])

    def sep_dist(c1, c2):
        # minimum separation over SAT axes, positive = separated
        def axes(cx, cy, ang):
            ca, sa = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
            return [(ca, sa), (-sa, ca)]
        def proj(cx, cy, ang, s, ax):
            ca, sa = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
            half = 0.5 * s
            vals = []
            for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                dx, dy = sx * half, sy * half
                px = cx + ca * dx - sa * dy
                py = cy + sa * dx + ca * dy
                vals.append(px * ax[0] + py * ax[1])
            return min(vals), max(vals)
        mind = 1e9
        for ax in axes(*c1[:3]) + axes(*c2[:3]):
            lo1, hi1 = proj(*c1, ax)
            lo2, hi2 = proj(*c2, ax)
            d = max(lo2 - hi1, lo1 - hi2)
            mind = min(mind, d)
        return mind

    cons = [
        {'type': 'ineq', 'fun': con_containment},
        {'type': 'ineq', 'fun': con_nonoverlap},
    ]
    bounds = [(0, 1)] * (4 * n)
    for i in range(n):
        bounds[4 * i + 2] = (0, 1)
        bounds[4 * i + 3] = (0, 1)

    try:
        res = minimize(obj, x0, method='SLSQP', bounds=bounds, constraints=cons,
                       options={'maxiter': maxiter, 'ftol': 1e-10, 'disp': False})
        if res.success or res.fun < obj(x0):
            x = res.x
        else:
            x = x0
    except Exception:
        x = x0
    out = []
    for i in range(n):
        out.append((x[4 * i], x[4 * i + 1], x[4 * i + 2] % 1.0, max(0.0, x[4 * i + 3])))
    return out

# ---------- main driver ----------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    best = None
    best_score = -1.0

    # candidate starts
    candidates = []
    candidates.append(grid_layout(n))
    k = math.isqrt(n)
    if k > 0:
        candidates.append(greedy_layout(n, rng, base_side=1.0 / k))

    for _ in range(3):
        candidates.append(greedy_layout(n, random.Random(rng.randint(0, 10**9))))

    for cand in candidates:
        if not feasible(cand):
            # fix tiny infeasibilities by shrinking overlaps
            cand = repair(cand, n)
        try:
            refined = refine_global(cand, n, rng, maxiter=40)
        except Exception:
            refined = cand
        if feasible(refined):
            sc = sum(c[3] for c in refined)
            if sc > best_score:
                best_score = sc
                best = refined

    if best is None:
        best = grid_layout(n)
    # final tiny repair
    best = repair(best, n)
    # ensure exactly n squares
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return [tuple(map(float, b)) for b in best[:n]]

def repair(cands, n):
    """Shrink any square that overlaps or escapes, and clamp positions."""
    cs = [list(c) for c in cands]
    for _ in range(10):
        changed = False
        for i in range(n):
            cx, cy, ang, s = cs[i]
            if s <= 0:
                continue
            # clamp
            ncx = min(1.0, max(0.0, cx))
            ncy = min(1.0, max(0.0, cy))
            if ncx != cx or ncy != cy:
                cs[i][0], cs[i][1] = ncx, ncy
                changed = True
            # containment shrink
            for px, py in corners(ncx, ncy, ang, s):
                if px < 0 or px > 1 or py < 0 or py > 1:
                    cs[i][3] *= 0.98
                    changed = True
                    break
            for j in range(n):
                if i == j:
                    continue
                if cs[j][3] <= 0:
                    continue
                if sat_overlap(tuple(cs[i]), tuple(cs[j])):
                    cs[i][3] *= 0.95
                    cs[j][3] *= 0.95
                    changed = True
        if not changed:
            break
    return [tuple(c) for c in cs]
