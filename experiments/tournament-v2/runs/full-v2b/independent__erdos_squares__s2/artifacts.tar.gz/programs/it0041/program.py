import math
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, ang, s):
    """Return the 4 corners of a square as an array (4,2)."""
    half = 0.5 * s
    ca, sa = math.cos(2.0 * math.pi * ang), math.sin(2.0 * math.pi * ang)
    # local corners
    loc = np.array([[-half, -half], [half, -half], [half, half], [-half, half]])
    rot = np.array([[ca, -sa], [sa, ca]])
    return loc @ rot.T + np.array([cx, cy])


def _overlap_area(sq1, sq2):
    """Approximate overlap area between two squares using separating axis + clipping.
    Returns a nonnegative penalty. Uses polygon intersection via SAT-like sampling of
    overlap along axes; for speed we use a robust approximation: if separated return 0,
    else return product of overlaps along the two edge normals of sq1 (conservative)."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 0 or s2 <= 0:
        return 0.0
    # quick distance bound
    r1 = s1 * math.sqrt(2.0) * 0.5
    r2 = s2 * math.sqrt(2.0) * 0.5
    if (cx1 - cx2) ** 2 + (cy1 - cy2) ** 2 > (r1 + r2) ** 2:
        return 0.0
    c1 = _corners(cx1, cy1, a1, s1)
    c2 = _corners(cx2, cy2, a2, s2)
    # SAT for convex polygons: check all edge normals
    axes = []
    for poly in (c1, c2):
        for i in range(4):
            e = poly[(i + 1) % 4] - poly[i]
            axes.append(np.array([-e[1], e[0]]))
    min_overlap = float('inf')
    for ax in axes:
        # skip tiny axes
        ln = math.hypot(ax[0], ax[1])
        if ln < 1e-12:
            continue
        ax = ax / ln
        p1 = c1 @ ax
        p2 = c2 @ ax
        o = min(p1.max(), p2.max()) - max(p1.min(), p2.min())
        if o <= 0:
            return 0.0
        if o < min_overlap:
            min_overlap = o
    # conservative: overlap penalty proportional to min_overlap^2
    return min_overlap * min_overlap


def _containment_penalty(sq):
    cx, cy, ang, s = sq
    if s <= 0:
        if cx < 0 or cx > 1 or cy < 0 or cy > 1:
            return (max(0.0, -cx) + max(0.0, cx - 1) +
                    max(0.0, -cy) + max(0.0, cy - 1)) ** 2
        return 0.0
    c = _corners(cx, cy, ang, s)
    pen = 0.0
    for x, y in c:
        if x < 0:
            pen += (-x) ** 2
        elif x > 1:
            pen += (x - 1) ** 2
        if y < 0:
            pen += (-y) ** 2
        elif y > 1:
            pen += (y - 1) ** 2
    return pen


def _objective(params, n, weight_overlap, weight_contain):
    sqs = []
    for i in range(n):
        cx, cy, ang, s = params[4 * i:4 * i + 4]
        sqs.append((float(cx), float(cy), float(ang), max(0.0, float(s))))
    total_side = sum(sq[3] for sq in sqs)
    pen = 0.0
    for i in range(n):
        pen += weight_contain * _containment_penalty(sqs[i])
        for j in range(i + 1, n):
            pen += weight_overlap * _overlap_area(sqs[i], sqs[j])
    return -total_side + pen


def _make_feasible(squares):
    """Adjust each square's centre minimally so corners lie inside [0,1]^2,
    then shrink sides if needed."""
    out = []
    for cx, cy, ang, s in squares:
        if s <= 0:
            out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), ang, 0.0))
            continue
        # binary search scale factor
        lo, hi = 0.0, s
        for _ in range(40):
            mid = 0.5 * (lo + hi)
            c = _corners(cx, cy, ang, mid)
            if c.min() >= -1e-12 and c.max() <= 1 + 1e-12:
                lo = mid
            else:
                hi = mid
        s2 = lo
        c = _corners(cx, cy, ang, s2)
        # shift to fit
        dx = max(-c[:, 0].min(), 0.0) - max(c[:, 0].max() - 1.0, 0.0)
        dy = max(-c[:, 1].min(), 0.0) - max(c[:, 1].max() - 1.0, 0.0)
        # if still not fit (too large), recompute s
        ncx, ncy = cx + dx, cy + dy
        c2 = _corners(ncx, ncy, ang, s2)
        while (c2.min() < -1e-9 or c2.max() > 1 + 1e-9) and s2 > 1e-12:
            s2 *= 0.99
            c2 = _corners(ncx, ncy, ang, s2)
        out.append((min(1.0, max(0.0, ncx)), min(1.0, max(0.0, ncy)), ang, s2))
    return out


def _repair_overlaps(squares, n, iterations=200):
    """Greedily resolve overlaps by shrinking smaller square in each overlapping pair."""
    sqs = [list(x) for x in squares]
    for _ in range(iterations):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                s1 = sqs[i][3]
                s2 = sqs[j][3]
                if s1 <= 0 or s2 <= 0:
                    continue
                ov = _overlap_area(tuple(sqs[i]), tuple(sqs[j]))
                if ov > 1e-10:
                    # shrink the smaller one
                    if s1 <= s2:
                        target = sqs[i][3]
                        lo, hi = 0.0, target
                        for _ in range(30):
                            mid = 0.5 * (lo + hi)
                            sqs[i][3] = mid
                            if _overlap_area(tuple(sqs[i]), tuple(sqs[j])) <= 1e-11:
                                lo = mid
                            else:
                                hi = mid
                        sqs[i][3] = lo
                    else:
                        target = sqs[j][3]
                        lo, hi = 0.0, target
                        for _ in range(30):
                            mid = 0.5 * (lo + hi)
                            sqs[j][3] = mid
                            if _overlap_area(tuple(sqs[i]), tuple(sqs[j])) <= 1e-11:
                                lo = mid
                            else:
                                hi = mid
                        sqs[j][3] = lo
                    changed = True
        if not changed:
            break
    return [tuple(x) for x in sqs]


def _greedy_pack(n, angle_grid=(0.0, 0.25, 0.5, 0.75, 0.125, 0.375, 0.625, 0.875)):
    """Greedy packing: place squares one by one at random-ish candidates maximizing side."""
    rng = np.random.RandomState(12345 + n)
    squares = []
    total = 0.0
    # start with a decent uniform guess
    for i in range(n):
        best = None
        for _ in range(60):
            cx = rng.uniform(0.0, 1.0)
            cy = rng.uniform(0.0, 1.0)
            ang = angle_grid[rng.randint(len(angle_grid))]
            # max size at this position
            lo, hi = 0.0, 1.0
            for _ in range(25):
                mid = 0.5 * (lo + hi)
                c = _corners(cx, cy, ang, mid)
                if c.min() >= -1e-12 and c.max() <= 1 + 1e-12:
                    lo = mid
                else:
                    hi = mid
            s = lo
            if best is None or s > best[3]:
                best = (cx, cy, ang, s)
        squares.append(list(best))
        total += best[3]
    return [tuple(x) for x in squares]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    best = None
    best_val = -1.0

    # candidate starts
    starts = []
    # grid start
    k = math.isqrt(n)
    side = 1.0 / k
    grid = []
    for i in range(k):
        for j in range(k):
            grid.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    while len(grid) < n:
        grid.append([0.5, 0.5, 0.0, 0.0])
    starts.append([tuple(x) for x in grid[:n]])

    # greedy
    starts.append(_greedy_pack(n))

    # half-size first two rows style
    for trial in range(3):
        s = 0.5
        g = []
        for i in range(n):
            g.append((0.5, 0.5, 0.0, 0.0))
        starts.append(g)

    for si, start in enumerate(starts):
        # initial params
        params = []
        for cx, cy, ang, s in start:
            params.extend([cx, cy, ang, s])
        params = np.array(params, dtype=float)

        # multi-stage optimization
        for stage, (wo, wc, maxiter) in enumerate(
                [(50.0, 50.0, 60), (200.0, 200.0, 60), (1000.0, 1000.0, 80)]):
            try:
                res = minimize(_objective, params, args=(n, wo, wc),
                               method='Nelder-Mead',
                               options={'maxiter': maxiter, 'xatol': 1e-6, 'fatol': 1e-8})
                params = res.x
            except Exception:
                pass

        # extract, repair, make feasible
        squares = []
        for i in range(n):
            cx, cy, ang, s = params[4 * i:4 * i + 4]
            squares.append((float(cx), float(cy), float(ang), max(0.0, float(s))))
        squares = _make_feasible(squares)
        squares = _repair_overlaps(squares, n)
        squares = _make_feasible(squares)
        squares = _repair_overlaps(squares, n)

        val = sum(sq[3] for sq in squares)
        if val > best_val:
            best_val = val
            best = squares

    # final check: ensure length n
    out = []
    for cx, cy, ang, s in best:
        out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)),
                    ang % 1.0, max(0.0, s)))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
