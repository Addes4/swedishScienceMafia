import math
import random
import time

# ---------- geometry helpers ----------

def _corners(cx, cy, ang, side):
    """Return the four corners of a square, angle as fraction of full turn."""
    if side <= 0.0:
        return [(cx, cy)] * 4
    h = side * 0.5
    th = ang * 2.0 * math.pi
    ca = math.cos(th)
    sa = math.sin(th)
    # local corners at (+-h, +-h)
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _project(poly, axis):
    ax, ay = axis
    vals = [px * ax + py * ay for px, py in poly]
    return min(vals), max(vals)


def _overlap_area(a, b):
    """Return True if polygons a,b have positive-area intersection (SAT)."""
    # quick bounding box reject
    aminx = min(p[0] for p in a); amaxx = max(p[0] for p in a)
    aminy = min(p[1] for p in a); amaxy = max(p[1] for p in a)
    bminx = min(p[0] for p in b); bmaxx = max(p[0] for p in b)
    bminy = min(p[1] for p in b); bmaxy = max(p[1] for p in b)
    if amaxx <= bminx or bmaxx <= aminx or amaxy <= bminy or bmaxy <= aminy:
        return False

    def axes(poly):
        out = []
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            # normal
            out.append((-ey, ex))
        return out

    for ax in axes(a) + axes(b):
        nrm = math.hypot(ax[0], ax[1])
        if nrm == 0:
            continue
        axis = (ax[0] / nrm, ax[1] / nrm)
        amin, amax = _project(a, axis)
        bmin, bmax = _project(b, axis)
        if amax <= bmin + 1e-13 or bmax <= amin + 1e-13:
            return False
    return True


def _inside_unit(poly):
    for x, y in poly:
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


def _clip_unit(poly):
    """Sutherland-Hodgman clip polygon against unit square."""
    def clip_edge(pts, inside, inter):
        out = []
        if not pts:
            return out
        prev = pts[-1]
        prev_in = inside(prev)
        for cur in pts:
            cur_in = inside(cur)
            if cur_in:
                if not prev_in:
                    out.append(inter(prev, cur))
                out.append(cur)
            elif prev_in:
                out.append(inter(prev, cur))
            prev = cur
            prev_in = cur_in
        return out

    def inter_vert(a, b, x):
        t = (x - a[0]) / (b[0] - a[0])
        return (x, a[1] + t * (b[1] - a[1]))

    def inter_horiz(a, b, y):
        t = (y - a[1]) / (b[1] - a[1])
        return (a[0] + t * (b[0] - a[0]), y)

    eps = 1e-12
    pts = poly
    pts = clip_edge(pts, lambda p: p[0] >= -eps, lambda a, b: inter_vert(a, b, 0.0))
    pts = clip_edge(pts, lambda p: p[0] <= 1.0 + eps, lambda a, b: inter_vert(a, b, 1.0))
    pts = clip_edge(pts, lambda p: p[1] >= -eps, lambda a, b: inter_horiz(a, b, 0.0))
    pts = clip_edge(pts, lambda p: p[1] <= 1.0 + eps, lambda a, b: inter_horiz(a, b, 1.0))
    return pts


def _poly_area(poly):
    if len(poly) < 3:
        return 0.0
    s = 0.0
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        s += x1 * y2 - x2 * y1
    return abs(s) * 0.5


def _overlap_threshold(a, b, thr=1e-10):
    """True if intersection area exceeds thr."""
    if not _overlap_area(a, b):
        return False
    # simplify: if SAT says overlap, approximate by checking clipped area of a vs b
    # use small threshold on bounding-box-overlap area
    return True


# ---------- construction ----------

def _grid_layout(n, k):
    out = []
    side = 1.0 / k
    for i in range(k):
        for j in range(k):
            if len(out) >= n:
                break
            out.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
        if len(out) >= n:
            break
    while len(out) < n:
        out.append([0.5, 0.5, 0.0, 0.0])
    return out


def _random_layout(n, rng):
    out = []
    for _ in range(n):
        side = rng.uniform(0.0, 0.35)
        cx = rng.uniform(side * 0.5, 1.0 - side * 0.5)
        cy = rng.uniform(side * 0.5, 1.0 - side * 0.5)
        ang = rng.random()
        out.append([cx, cy, ang, side])
    return out


def _score(squares):
    return sum(max(0.0, s[3]) for s in squares)


def _is_feasible(squares, tol=1e-9):
    n = len(squares)
    polys = []
    for cx, cy, ang, side in squares:
        if side <= 0.0:
            continue
        poly = _corners(cx, cy, ang, side)
        if not _inside_unit(poly):
            return False
        polys.append(poly)
    m = len(polys)
    for i in range(m):
        for j in range(i + 1, m):
            if _overlap_area(polys[i], polys[j]):
                return False
    return True


def _repair(squares, rng, max_iter=300):
    """If overlapping, try to shrink/move offending squares."""
    sq = [list(s) for s in squares]
    for _ in range(max_iter):
        if _is_feasible(sq):
            return sq
        # find first conflict
        polys = []
        for cx, cy, ang, side in sq:
            if side <= 0.0:
                polys.append(None)
            else:
                polys.append(_corners(cx, cy, ang, side))
        fixed = False
        for i in range(len(sq)):
            if polys[i] is None:
                continue
            # boundary fix
            if not _inside_unit(polys[i]):
                sq[i][3] *= 0.7
                sq[i][0] = min(max(sq[i][0], sq[i][3] * 0.5), 1.0 - sq[i][3] * 0.5)
                sq[i][1] = min(max(sq[i][1], sq[i][3] * 0.5), 1.0 - sq[i][3] * 0.5)
                polys[i] = _corners(*sq[i])
                fixed = True
                break
        if fixed:
            continue
        conflict = None
        for i in range(len(sq)):
            if polys[i] is None:
                continue
            for j in range(i + 1, len(sq)):
                if polys[j] is None:
                    continue
                if _overlap_area(polys[i], polys[j]):
                    conflict = (i, j)
                    break
            if conflict:
                break
        if conflict is None:
            return sq
        i, j = conflict
        # shrink smaller one
        if sq[i][3] < sq[j][3]:
            sq[i][3] *= 0.85
        else:
            sq[j][3] *= 0.85
        # random tiny move of one
        t = rng.randrange(2)
        if t == 0:
            sq[i][0] += rng.uniform(-0.01, 0.01)
            sq[i][1] += rng.uniform(-0.01, 0.01)
            sq[i][0] = min(max(sq[i][0], 0.0), 1.0)
            sq[i][1] = min(max(sq[i][1], 0.0), 1.0)
        else:
            sq[j][0] += rng.uniform(-0.01, 0.01)
            sq[j][1] += rng.uniform(-0.01, 0.01)
            sq[j][0] = min(max(sq[j][0], 0.0), 1.0)
            sq[j][1] = min(max(sq[j][1], 0.0), 1.0)
    return sq


# ---------- optimization ----------

def _neighbors_feasible(squares, i, old_poly, new_poly, all_polys):
    """Check only collisions involving square i (new_poly) against others."""
    if not _inside_unit(new_poly):
        return False
    for j, pj in enumerate(all_polys):
        if j == i or pj is None:
            continue
        if _overlap_area(new_poly, pj):
            return False
    return True


def _local_search(n, seed, time_budget):
    rng = random.Random(seed)
    start = time.time()

    # initial: best of grid candidates
    k = max(1, int(math.sqrt(n)))
    best = _grid_layout(n, k)
    best_score = _score(best)

    # try several initial configurations
    for _ in range(30):
        if time.time() - start > time_budget * 0.25:
            break
        cand = _random_layout(n, rng)
        cand = _repair(cand, rng, 200)
        if _is_feasible(cand):
            sc = _score(cand)
            if sc > best_score:
                best, best_score = cand, sc

    if not _is_feasible(best):
        best = _repair(best, rng, 500)
        best_score = _score(best)

    cur = [list(s) for s in best]
    cur_score = best_score

    # Simulated annealing with adaptive moves
    T = 0.05
    alpha = 0.9995
    it = 0
    best_overall = [list(s) for s in cur]
    best_overall_score = cur_score

    while time.time() - start < time_budget:
        it += 1
        if it % 500 == 0:
            T *= alpha
            if T < 1e-4:
                T = 1e-4

        # build polygons once per iteration (could be optimized)
        polys = []
        for cx, cy, ang, side in cur:
            if side <= 0.0:
                polys.append(None)
            else:
                polys.append(_corners(cx, cy, ang, side))

        # pick random square
        idx = rng.randrange(n)
        old = list(cur[idx])
        old_poly = polys[idx]

        # propose move
        move_type = rng.random()
        if move_type < 0.35:
            # resize
            news = old[3] + rng.gauss(0, 0.03)
            news = max(0.0, min(0.5, news))
            new = [old[0], old[1], old[2], news]
        elif move_type < 0.6:
            # translate
            nx = old[0] + rng.gauss(0, 0.025)
            ny = old[1] + rng.gauss(0, 0.025)
            new = [nx, ny, old[2], old[3]]
        elif move_type < 0.85:
            # rotate
            na = old[2] + rng.gauss(0, 0.08)
            new = [old[0], old[1], na, old[3]]
        else:
            # combined
            na = old[2] + rng.gauss(0, 0.05)
            ns = old[3] + rng.gauss(0, 0.02)
            nx = old[0] + rng.gauss(0, 0.015)
            ny = old[1] + rng.gauss(0, 0.015)
            new = [nx, ny, na, max(0.0, ns)]

        # clamp center so square fits (for quick reject)
        hs = new[3] * 0.5
        # conservative: keep center in [hs, 1-hs]
        new[0] = min(max(new[0], 0.0), 1.0)
        new[1] = min(max(new[1], 0.0), 1.0)

        if new[3] <= 0.0:
            new[3] = 0.0
            new_poly = None
        else:
            new_poly = _corners(*new)

        # feasibility check
        ok = True
        if new_poly is not None:
            if not _inside_unit(new_poly):
                ok = False
            else:
                for j, pj in enumerate(polys):
                    if j == idx or pj is None:
                        continue
                    if _overlap_area(new_poly, pj):
                        ok = False
                        break

        if not ok:
            continue

        old_contrib = old[3]
        new_contrib = new[3]
        delta = new_contrib - old_contrib

        if delta >= 0 or rng.random() < math.exp(delta / max(T, 1e-6)):
            cur[idx] = new
            cur_score += delta
            if cur_score > best_overall_score:
                # verify feasibility
                if _is_feasible(cur):
                    best_overall = [list(s) for s in cur]
                    best_overall_score = cur_score

    return best_overall, best_overall_score


def solve(n):
    if n <= 0:
        return []

    t0 = time.time()
    total_budget = 55.0
    # allocate time, more for larger n
    per_round = max(0.5, min(15.0, total_budget / max(1, min(8, n // 5 + 1))))

    best = None
    best_score = -1.0
    seed = 12345

    rounds = 0
    while time.time() - t0 < total_budget - 1.0:
        remaining = total_budget - (time.time() - t0)
        budget = min(per_round, remaining - 0.5)
        if budget <= 0.1:
            break
        cand, sc = _local_search(n, seed, budget)
        seed += 1
        rounds += 1
        if sc > best_score:
            best_score = sc
            best = cand
        # occasional bigger initial restarts handled inside local_search

    if best is None:
        k = max(1, int(math.sqrt(n)))
        best = _grid_layout(n, k)

    # final feasibility repair / validation
    if not _is_feasible(best):
        rng = random.Random(999)
        best = _repair(best, rng, 2000)
        best_score = _score(best)

    # ensure exactly n squares and values in [0,1]
    result = []
    for cx, cy, ang, side in best:
        sx = min(max(cx, 0.0), 1.0)
        sy = min(max(cy, 0.0), 1.0)
        a = ang % 1.0
        s = max(0.0, min(1.0, side))
        result.append((sx, sy, a, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
