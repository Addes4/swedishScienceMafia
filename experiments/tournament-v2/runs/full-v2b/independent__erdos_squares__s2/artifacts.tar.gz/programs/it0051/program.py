import math
import random
import time

# ---------- basic geometry ops ----------

def _corners(cx, cy, ang, s):
    h = 0.5 * s
    ca = math.cos(2.0 * math.pi * ang)
    sa = math.sin(2.0 * math.pi * ang)
    # local square ±h,±h
    pts = []
    for x, y in ((h, h), (h, -h), (-h, -h), (-h, h)):
        pts.append((cx + ca * x - sa * y, cy + sa * x + ca * y))
    return pts


def _sat_overlap(a, b):
    """True if convex polygons a and b overlap with positive area (strict)."""
    # Separating axis theorem
    for poly in (a, b):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ax, ay = x2 - x1, y2 - y1
            # normal
            nx, ny = -ay, ax
            if nx == 0.0 and ny == 0.0:
                continue
            mn1 = mx1 = a[0][0] * nx + a[0][1] * ny
            for px, py in a[1:]:
                v = px * nx + py * ny
                if v < mn1: mn1 = v
                if v > mx1: mx1 = v
            mn2 = mx2 = b[0][0] * nx + b[0][1] * ny
            for px, py in b[1:]:
                v = px * nx + py * ny
                if v < mn2: mn2 = v
                if v > mx2: mx2 = v
            # strict separation (allow touching)
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return False
    return True


def _inside_unit(pts):
    for x, y in pts:
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


def _valid_all(sqs):
    polys = []
    for cx, cy, ang, s in sqs:
        if s <= 0.0:
            polys.append(None)
            continue
        p = _corners(cx, cy, ang, s)
        if not _inside_unit(p):
            return False
        polys.append(p)
    m = len(sqs)
    for i in range(m):
        if polys[i] is None:
            continue
        for j in range(i + 1, m):
            if polys[j] is None:
                continue
            if _sat_overlap(polys[i], polys[j]):
                return False
    return True


# ---------- initial constructive packings ----------

def _grid_pack(n):
    k = math.isqrt(n)
    s = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            out.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    return out


def _row_pack(n):
    """Try several row-height layouts and keep the best valid one."""
    best = None
    best_score = -1.0

    # candidate numbers of rows
    cand_rows = set()
    for r in range(1, n + 1):
        cand_rows.add(r)
        if r <= 60:
            cand_rows.add(r)
    # fewer candidates for large n
    if n > 120:
        cand_rows = set(range(1, min(n, 40) + 1))
        for r in range(1, 20):
            cand_rows.add(max(1, n // r))
    for r in list(cand_rows):
        if r > n:
            continue
        # distribute n across r rows as evenly as possible
        base = n // r
        rem = n % r
        rows = [base + (1 if i < rem else 0) for i in range(r)]
        h = 1.0 / r
        placed = []
        y = 0.0
        ok = True
        for cnt in rows:
            if cnt == 0:
                y += h
                continue
            w = 1.0 / cnt
            s = min(w, h)
            # if row is wider than needed, center horizontally
            totw = cnt * s
            x0 = (1.0 - totw) * 0.5
            for i in range(cnt):
                cx = x0 + (i + 0.5) * s
                cy = y + 0.5 * h
                placed.append((cx, cy, 0.0, s))
            y += h
        # fill remainder with zero squares
        while len(placed) < n:
            placed.append((0.5, 0.5, 0.0, 0.0))
        sc = sum(p[3] for p in placed)
        if sc > best_score and _valid_all(placed):
            best_score = sc
            best = placed
    return best


def _mixed_pack(n):
    """Mixture: a block of k*k squares plus a row strip of remaining ones, several splits."""
    best = None
    best_score = -1.0
    for k in range(1, int(math.sqrt(n)) + 1):
        rem = n - k * k
        if rem < 0:
            continue
        s0 = 1.0 / k
        placed = [((i + 0.5) * s0, (j + 0.5) * s0, 0.0, s0)
                  for i in range(k) for j in range(k)]
        if rem > 0:
            # put remaining in a strip of height h at top or bottom
            # try a few row counts inside the strip
            for remrows in range(1, min(rem, 6) + 1):
                pass
            h = min(1.0 - k * s0 if k * s0 < 1.0 else 0.0, 0.25)
            if h <= 1e-9:
                h = 0.0
            if h > 1e-9:
                # horizontal rows in the strip
                rr = min(rem, max(1, int(rem)))
                # simple: single row if possible, else multiple
                for rows_count in range(1, min(rem, 4) + 1):
                    base = rem // rows_count
                    extra = rem % rows_count
                    hh = h / rows_count
                    y = 1.0 - h
                    tmp = list(placed)
                    ok = True
                    for ri in range(rows_count):
                        cnt = base + (1 if ri < extra else 0)
                        if cnt <= 0:
                            continue
                        w = 1.0 / cnt
                        ss = min(w, hh)
                        totw = cnt * ss
                        x0 = (1.0 - totw) * 0.5
                        for i in range(cnt):
                            tmp.append((x0 + (i + 0.5) * ss, y + (ri + 0.5) * hh, 0.0, ss))
                        y += hh
                    while len(tmp) < n:
                        tmp.append((0.5, 0.5, 0.0, 0.0))
                    sc = sum(p[3] for p in tmp)
                    if sc > best_score and _valid_all(tmp):
                        best_score = sc
                        best = tmp
    return best


def _initial(n):
    cands = [_grid_pack(n), _mixed_pack(n), _row_pack(n)]
    best = None
    bs = -1.0
    for c in cands:
        if c is None:
            continue
        c = list(c)
        while len(c) < n:
            c.append((0.5, 0.5, 0.0, 0.0))
        c = c[:n]
        sc = sum(p[3] for p in c)
        if sc > bs:
            bs = sc
            best = c
    return best if best is not None else [(0.5, 0.5, 0.0, 0.0)] * n


# ---------- local search ----------

def _score(sqs):
    return sum(s[3] for s in sqs)


def _perturb_all(sqs, rng, temp):
    """Randomly jiggle every square slightly; return new list (may be invalid)."""
    out = []
    for cx, cy, ang, s in sqs:
        if s <= 0.0:
            out.append((cx, cy, ang, s))
            continue
        # small translation and resizing
        scale = 0.04 * (0.5 + temp)
        nx = cx + rng.uniform(-scale, scale)
        ny = cy + rng.uniform(-scale, scale)
        ns = s + rng.uniform(-scale, scale)
        if ns < 0.0:
            ns = 0.0
        # clamp roughly inside
        if ns > 0:
            h = 0.5 * ns
            nx = min(max(nx, h), 1.0 - h)
            ny = min(max(ny, h), 1.0 - h)
        out.append((nx, ny, ang, ns))
    return out


def _polish(n, sqs, deadline):
    """Coordinate descent + SA over (cx, cy, s) for a while."""
    rng = random.Random(12345 + n)
    best = [t for t in sqs]
    best_sc = _score(best)

    # Try to grow each square individually as far as possible
    improved = True
    rounds = 0
    while improved and time.time() < deadline and rounds < 6:
        improved = False
        rounds += 1
        for idx in range(n):
            cur = best[idx]
            cx, cy, ang, s = cur
            if s <= 0.0:
                # try to give it positive size if room
                trial_s = 0.02
                for t in range(12):
                    tcx, tcy = 0.5, 0.5
                    cand = list(best)
                    cand[idx] = (tcx, tcy, ang, trial_s)
                    if _valid_all(cand):
                        best = cand
                        best_sc += trial_s
                        improved = True
                        break
                    trial_s *= 0.7
                continue
            # binary-search maximal growth keeping validity
            lo, hi = s, min(1.0, s * 1.8 + 0.05)
            # first ensure hi is feasible direction
            ok_hi = False
            for _ in range(10):
                cand = list(best)
                cand[idx] = (cx, cy, ang, hi)
                if _valid_all(cand):
                    ok_hi = True
                    break
                hi = (lo + hi) * 0.5
            if not ok_hi:
                continue
            if hi <= s + 1e-9:
                continue
            if abs(hi - s) > 1e-6:
                cand = list(best)
                cand[idx] = (cx, cy, ang, hi)
                best = cand
                best_sc += hi - s
                improved = True

    # SA-ish small perturbations
    cur = [t for t in best]
    cur_sc = _score(cur)
    it = 0
    while time.time() < deadline:
        it += 1
        temp = max(0.0, 1.0 - it / 3000.0)
        cand = _perturb_all(cur, rng, temp)
        # snap tiny squares to zero
        for i, t in enumerate(cand):
            if t[3] < 0.005:
                cand[i] = (t[0], t[1], t[2], 0.0)
        if _valid_all(cand):
            sc = _score(cand)
            if sc > cur_sc or rng.random() < 0.02 * temp:
                cur = cand
                cur_sc = sc
                if sc > best_sc:
                    best = [t for t in cand]
                    best_sc = sc
        if it > 8000 and temp <= 0.0:
            break

    # final greedy growth pass
    for idx in range(n):
        cx, cy, ang, s = best[idx]
        if s <= 0.0:
            continue
        lo, hi = s, min(1.0, s * 1.5 + 0.1)
        for _ in range(25):
            mid = (lo + hi) * 0.5
            cand = list(best)
            cand[idx] = (cx, cy, ang, mid)
            if _valid_all(cand):
                lo = mid
            else:
                hi = mid
        if lo > s + 1e-9:
            cand = list(best)
            cand[idx] = (cx, cy, ang, lo)
            best = cand
    return best


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two half-size squares
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    deadline = t0 + 55.0

    init = _initial(n)
    # quick valid check; fall back
    if not _valid_all(init):
        init = _grid_pack(n)
        while len(init) < n:
            init.append((0.5, 0.5, 0.0, 0.0))
        init = init[:n]

    # trim time for small n so we don't waste
    budget = 55.0
    if n <= 10:
        budget = 20.0
    elif n <= 30:
        budget = 35.0
    deadline = time.time() + budget

    res = _polish(n, init, deadline)

    # ensure output format/length
    res = list(res)
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    res = res[:n]
    # final clamp
    out = []
    for cx, cy, ang, s in res:
        if s < 0.0:
            s = 0.0
        if s == 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
        else:
            h = 0.5 * s
            cx = min(max(cx, h), 1.0 - h)
            cy = min(max(cy, h), 1.0 - h)
            out.append((cx, cy, ang % 1.0, s))
    return out
