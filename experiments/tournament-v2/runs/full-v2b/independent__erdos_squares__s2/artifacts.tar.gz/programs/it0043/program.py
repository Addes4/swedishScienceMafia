import math
import random
import numpy as np
from scipy.optimize import minimize


# ---------------------------------------------------------------- geometry ---
def square_corners(cx, cy, ang, s):
    """Corners of a square (centre, angle in turns, side) as 4x2 array."""
    t = 2.0 * math.pi * ang
    c, si = math.cos(t), math.sin(t)
    h = 0.5 * s
    # local corners (+-h, +-h), rotated
    return np.array([
        [cx + (c * h - si * h), cy + (si * h + c * h)],
        [cx + (-c * h - si * h), cy + (-si * h + c * h)],
        [cx + (-c * h + si * h), cy + (-si * h - c * h)],
        [cx + (c * h + si * h), cy + (si * h - c * h)],
    ])


def ov(ax, ay, bx, by):
    """1D overlap length of intervals [ax,ay], [bx,by]."""
    return max(0.0, min(ax, bx) - max(ay, by), min(ay, by) - max(ax, bx))


def sep_penalty(c1, c2):
    """A smooth-ish separation measure between two convex quads.
    Returns 0 if interiors are disjoint, else positive penetration depth estimate."""
    # use projections onto edge normals of both squares (separating-axis style),
    # but converted to a continuous penalty.
    best = 0.0
    for poly, other in ((c1, c2), (c2, c1)):
        for i in range(4):
            p, q = poly[i], poly[(i + 1) % 4]
            nx, ny = (q[1] - p[1]), -(q[0] - p[0])
            L = math.hypot(nx, ny)
            if L < 1e-15:
                continue
            nx, ny = nx / L, ny / L
            a = [nx * v[0] + ny * v[1] for v in poly]
            b = [nx * v[0] + ny * v[1] for v in other]
            gap = min(b) - max(a)          # if >0 separated by this axis
            if gap > 0:
                return 0.0
            best = max(best, -gap)
    return best


def overlap_area(c1, c2):
    """Approximate overlap area via clipping both quads against each other (Sutherland-Hodgman)."""
    def clip(subject, clipper):
        out = subject
        for i in range(4):
            a = clipper[i]
            b = clipper[(i + 1) % 4]
            inp = out
            out = []
            if not inp:
                break
            # inside test: left of edge ab
            def inside(p):
                return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= -1e-12
            for j in range(len(inp)):
                cur = inp[j]
                prev = inp[j - 1]
                ic, ip = inside(cur), inside(prev)
                if ic:
                    if not ip:
                        out.append(inter(prev, cur, a, b))
                    out.append(cur)
                elif ip:
                    out.append(inter(prev, cur, a, b))
        return out

    def inter(p, q, a, b):
        d1x, d1y = q[0] - p[0], q[1] - p[1]
        d2x, d2y = b[0] - a[0], b[1] - a[1]
        den = d1x * d2y - d1y * d2x
        if abs(den) < 1e-15:
            return q
        t = ((a[0] - p[0]) * d2y - (a[1] - p[1]) * d2x) / den
        return [p[0] + t * d1x, p[1] + t * d1y]

    poly = clip([list(v) for v in c1], [list(v) for v in c2])
    if len(poly) < 3:
        return 0.0
    A = 0.0
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        A += x1 * y2 - x2 * y1
    return abs(A) * 0.5


# --------------------------------------------------------------- objective ---
def total_penalty(params, n, big=1e6):
    p = params.reshape(n, 4)
    pen = 0.0
    corners = []
    for i in range(n):
        cx, cy, ang, s = p[i]
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        s = max(s, 0.0)
        corners.append(square_corners(cx, cy, ang, s))
        # containment: each corner inside unit square
        for v in corners[-1]:
            if v[0] < -1e-12:
                pen += big * (-v[0]) ** 2
            if v[0] > 1.0 + 1e-12:
                pen += big * (v[0] - 1.0) ** 2
            if v[1] < -1e-12:
                pen += big * (-v[1]) ** 2
            if v[1] > 1.0 + 1e-12:
                pen += big * (v[1] - 1.0) ** 2
    # pairwise
    for i in range(n):
        if p[i, 3] <= 1e-14:
            continue
        for j in range(i + 1, n):
            if p[j, 3] <= 1e-14:
                continue
            # fast distance reject
            dx = p[i, 0] - p[j, 0]
            dy = p[i, 1] - p[j, 1]
            rr = 0.5 * (p[i, 3] * 1.4143 + p[j, 3] * 1.4143)
            if dx * dx + dy * dy > rr * rr:
                continue
            a = overlap_area(corners[i], corners[j])
            if a > 0:
                pen += big * a ** 1.5 + a
    return pen


def neg_sum(params, n):
    p = params.reshape(n, 4)
    # feasible-ish: sum of sides
    f = total_penalty(params, n, big=1e7)
    return -float(np.sum(np.maximum(p[:, 3], 0.0))) + f


# ----------------------------------------------------------- initial guesses
def spiral_init(n, rng):
    """A spiral of squares with varying sizes."""
    res = []
    if n == 0:
        return res
    for i in range(n):
        t = i
        r = 0.48 * ((t * 0.61803398875) % 1.0) ** 0.5
        th = 2 * math.pi * ((t * 0.38196601125) % 1.0)
        cx = 0.5 + r * math.cos(th)
        cy = 0.5 + r * math.sin(th)
        cx = min(max(cx, 0.05), 0.95)
        cy = min(max(cy, 0.05), 0.95)
        s = 1.0 / math.sqrt(max(n, 1)) * rng.uniform(0.4, 1.0)
        res.append([cx, cy, rng.uniform(0, 1), s])
    return res


def grid_init(n):
    k = math.isqrt(n)
    s = 1.0 / k if k > 0 else 1.0
    res = []
    for i in range(k):
        for j in range(k):
            res.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
    while len(res) < n:
        res.append([0.5, 0.5, 0.0, 0.0])
    return res


def greedy_init(n, rng, tries=40):
    """Greedy: insert squares one by one with random size, angle; shrink if overlapping."""
    best = None
    best_score = -1
    for _ in range(tries):
        squares = []
        for i in range(n):
            placed = False
            for _attempt in range(30):
                s = rng.uniform(0.2, 0.6) / math.sqrt(max(n, 1)) * rng.uniform(0.5, 2.0)
                s = min(max(s, 1e-4), 0.5)
                cx = rng.uniform(s * 0.71, 1 - s * 0.71)
                cy = rng.uniform(s * 0.71, 1 - s * 0.71)
                ang = rng.uniform(0, 1)
                if ok_place(squares, cx, cy, ang, s):
                    squares.append([cx, cy, ang, s])
                    placed = True
                    break
            if not placed:
                squares.append([0.5, 0.5, 0.0, 0.0])
        # grow: scale up all sides by common factor, preserving positions relative
        sc = fit_scale(squares)
        for sq in squares:
            sq[3] *= sc
        score = sum(sq[3] for sq in squares)
        if score > best_score:
            best_score = score
            best = [sq[:] for sq in squares]
    return best


def ok_place(squares, cx, cy, ang, s):
    """Check a square fits without overlap."""
    c = square_corners(cx, cy, ang, s)
    for v in c:
        if v[0] < -1e-9 or v[0] > 1 + 1e-9 or v[1] < -1e-9 or v[1] > 1 + 1e-9:
            return False
    for sq in squares:
        if sq[3] <= 1e-12:
            continue
        if sep_penalty(c, square_corners(*sq)) > 1e-9:
            return False
    return True


def fit_scale(squares):
    """Find max common multiplier m for sides so all fit, by bisection."""
    if not squares:
        return 1.0
    lo, hi = 0.0, 1.0
    # find upper bound
    for _ in range(20):
        if feasible_scaled(squares, hi):
            hi *= 2
        else:
            break
    for _ in range(60):
        mid = (lo + hi) / 2
        if feasible_scaled(squares, mid):
            lo = mid
        else:
            hi = mid
    return lo


def feasible_scaled(squares, m):
    n = len(squares)
    cs = []
    for i in range(n):
        cx, cy, ang, s = squares[i]
        cs.append(square_corners(cx, cy, ang % 1.0, max(s * m, 0.0)))
        for v in cs[-1]:
            if v[0] < -1e-8 or v[0] > 1 + 1e-8 or v[1] < -1e-8 or v[1] > 1 + 1e-8:
                return False
    for i in range(n):
        if squares[i][3] * m <= 1e-12:
            continue
        for j in range(i + 1, n):
            if squares[j][3] * m <= 1e-12:
                continue
            if sep_penalty(cs[i], cs[j]) > 1e-8:
                return False
    return True


# --------------------------------------------------------------- refinement --
def refine(init, n, rng, maxiter=200):
    """Use scipy to locally optimise."""
    x0 = np.array(init, dtype=float).reshape(-1)
    x0[0::4] = np.clip(x0[0::4], 1e-6, 1 - 1e-6)
    x0[1::4] = np.clip(x0[1::4], 1e-6, 1 - 1e-6)
    x0[2::4] = x0[2::4] % 1.0
    x0[3::4] = np.maximum(x0[3::4], 0.0)

    bounds = []
    for _ in range(n):
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 0.71))

    method = "L-BFGS-B"
    try:
        res = minimize(neg_sum, x0, args=(n,), method=method,
                       bounds=bounds, options={"maxiter": maxiter, "maxfun": maxiter * 20,
                                               "ftol": 1e-12, "gtol": 1e-10})
        return res.x, res.fun
    except Exception:
        return x0, neg_sum(x0, n)


def repair(squares, n):
    """Ensure feasibility strictly: shrink overlapping squares."""
    bad = True
    for _ in range(200):
        bad = False
        corners = []
        for sq in squares:
            cx, cy, ang, s = sq
            ang = ang % 1.0
            corners.append(square_corners(cx, cy, ang, max(s, 0.0)))
        # clamp inside
        for i in range(n):
            for v in corners[i]:
                if v[0] < 0 or v[0] > 1 or v[1] < 0 or v[1] > 1:
                    bad = True
        if bad:
            for sq in squares:
                sq[3] *= 0.98
            continue
        over = False
        for i in range(n):
            if squares[i][3] <= 1e-13:
                continue
            for j in range(i + 1, n):
                if squares[j][3] <= 1e-13:
                    continue
                if sep_penalty(corners[i], corners[j]) > 1e-9:
                    over = True
        if not over:
            return squares
        for sq in squares:
            sq[3] *= 0.995
    return squares


# ---------------------------------------------------------------- main solve
def solve(n):
    if n == 0:
        return []
    if n == 1:
        # one square; best is a single axis-aligned unit square
        return [(0.5, 0.5, 0.0, 1.0)]
    rng = random.Random(12345 + n)

    candidates = []
    # various inits
    candidates.append(grid_init(n))
    for _ in range(6):
        candidates.append(spiral_init(n, rng))
    for _ in range(8):
        candidates.append(greedy_init(n, rng, tries=6))

    best_squares = None
    best_score = -1.0
    time_budget_iters = 2 if n <= 12 else (2 if n <= 40 else 1)

    for init in candidates:
        squares = [list(map(float, sq)) for sq in init]
        # scale to fit
        sc = fit_scale(squares)
        for sq in squares:
            sq[3] *= sc
        # optional refinement
        for _ in range(time_budget_iters):
            try:
                x, f = refine(squares, n, rng, maxiter=120)
            except Exception:
                break
            cand_squares = [list(x[4 * i:4 * i + 4]) for i in range(n)]
            # accept if feasible and better
            rep = repair([list(s) for s in cand_squares], n)
            sc2 = fit_scale(rep)
            for sq in rep:
                sq[3] *= sc2
            rep = repair(rep, n)
            sc2 = fit_scale(rep)
            for sq in rep:
                sq[3] *= sc2
            score = sum(sq[3] for sq in rep)
            if score > best_score:
                best_score = score
                best_squares = [sq[:] for sq in rep]
            # restart from repaired
            squares = [sq[:] for sq in rep]
            if n <= 5:
                pass

        # direct candidate
        rep = repair([list(s) for s in squares], n)
        sc2 = fit_scale(rep)
        for sq in rep:
            sq[3] *= sc2
        rep = repair(rep, n)
        sc2 = fit_scale(rep)
        for sq in rep:
            sq[3] *= sc2
        score = sum(sq[3] for sq in rep)
        if score > best_score:
            best_score = score
            best_squares = [sq[:] for sq in rep]

    if best_squares is None:
        best_squares = grid_init(n)

    out = []
    for cx, cy, ang, s in best_squares:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        s = max(s, 0.0)
        out.append((cx, cy, ang, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
