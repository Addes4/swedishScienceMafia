import math
import random
import numpy as np
from scipy.optimize import minimize

# ---------------------------------------------------------------------------
# Geometry: rotated square as convex polygon, SAT overlap area / depth penalty
# ---------------------------------------------------------------------------


def square_corners(cx, cy, angle, side):
    """Return the 4 corners of a square as an (4,2) array."""
    a = angle * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side * 0.5
    pts = np.array([
        [h, h], [-h, h], [-h, -h], [h, -h]
    ], dtype=float)
    R = np.array([[ca, -sa], [sa, ca]])
    return pts @ R.T + np.array([cx, cy])


def sat_overlap(poly_a, poly_b):
    """Return the minimum translation distance needed to separate two convex
    polygons (0 if already disjoint).  Uses SAT on the polygon edge normals."""
    best = float('inf')
    for poly in (poly_a, poly_b):
        n = len(poly)
        for i in range(n):
            edge = poly[(i + 1) % n] - poly[i]
            # outward normal (doesn't matter sign for interval overlap test)
            axis = np.array([-edge[1], edge[0]])
            norm = np.hypot(axis[0], axis[1])
            if norm < 1e-15:
                continue
            axis = axis / norm

            # project both polygons
            pa = poly_a @ axis
            pb = poly_b @ axis
            # overlap depth along this axis
            depth = min(pa.max(), pb.max()) - max(pa.min(), pb.min())
            if depth <= 0.0:
                return 0.0  # separating axis found -> disjoint
            if depth < best:
                best = depth
    return best


def boundary_penalty(poly, margin=0.0):
    """Penalty if polygon extends outside [0,1]^2."""
    pen = 0.0
    lo = poly.min(axis=0)
    hi = poly.max(axis=0)
    for v in (lo[0], lo[1]):
        if v < margin:
            pen += (margin - v)
    for v in (hi[0], hi[1]):
        if v > 1.0 - margin:
            pen += (v - (1.0 - margin))
    return pen


# ---------------------------------------------------------------------------
# Objective / constraints for optimisation
# ---------------------------------------------------------------------------

def decode(x, n):
    """x = [cx0,cy0,a0,s0, cx1,...].  Return list of tuples."""
    sq = []
    for i in range(n):
        cx, cy, a, s = x[4 * i:4 * i + 4]
        sq.append((cx, cy, a, s))
    return sq


def objective(x, n):
    s = 0.0
    for i in range(n):
        s += x[4 * i + 3]
    return -s  # minimize negative sum of sides


def penalties(x, n, w_overlap=1e4, w_boundary=1e4):
    """Return total penalty from overlaps and boundary violations."""
    sq = decode(x, n)
    polys = [square_corners(*t) for t in sq]
    pen = 0.0
    # boundary
    for p in polys:
        pen += boundary_penalty(p)
    # overlaps
    for i in range(n):
        for j in range(i + 1, n):
            d = sat_overlap(polys[i], polys[j])
            if d > 0:
                pen += d * d
    return pen * w_overlap + pen * w_boundary


def total_obj(x, n, w=1e5):
    return objective(x, n) + w * penalties(x, n, 1.0, 1.0)


# ---------------------------------------------------------------------------
# Initial packings
# ---------------------------------------------------------------------------

def grid_packing(n):
    """Largest k x k grid plus the rest as tiny squares in leftover space."""
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # extra squares: place them in the top-left of already-used cells (overlap
    # penalty will be resolved by optimizer).  To help, put them tiny at free
    # random positions.
    extra = n - k * k
    for t in range(extra):
        # place them above the k*k grid if possible, otherwise near a corner
        cx = 0.5 + 0.01 * (t + 1)
        cy = 0.5 - 0.01 * (t + 1)
        squares.append((0.02 + 0.001 * t, 0.02 + 0.001 * t, 0.0, 0.01))
    return squares


def random_packing(n, rng):
    """Random feasible-ish packing: many small squares."""
    squares = []
    for _ in range(n):
        s = rng.uniform(0.01, 0.25)
        cx = rng.uniform(s / 2, 1 - s / 2)
        cy = rng.uniform(s / 2, 1 - s / 2)
        a = rng.uniform(0, 1)
        squares.append((cx, cy, a, s))
    return squares


# ---------------------------------------------------------------------------
# Optimisation
# ---------------------------------------------------------------------------

def clean_bounds(n):
    lbs, ubs = [], []
    for i in range(n):
        lbs += [0.0, 0.0, 0.0, 0.0]
        ubs += [1.0, 1.0, 1.0, 1.0]
    return lbs, ubs


def refine(squares, n, maxiter=200):
    x0 = np.array([v for t in squares for v in t], dtype=float)
    # ensure feasible start for optimizer (clamp)
    x0 = np.clip(x0, 0.0, 1.0)
    lb, ub = clean_bounds(n)
    bounds = list(zip(lb, ub))
    try:
        res = minimize(total_obj, x0, args=(n,), method='L-BFGS-B',
                       bounds=bounds, options={'maxiter': maxiter,
                                               'ftol': 1e-12, 'gtol': 1e-10})
        x = res.x
    except Exception:
        x = x0
    # project out overlaps greedily (shrink squares if necessary)
    return decode(x, n)


def make_feasible(squares):
    """Greedily shrink any square that overlaps another or the boundary."""
    sq = list(squares)
    n = len(sq)
    changed = True
    it = 0
    while changed and it < 200:
        changed = False
        it += 1
        polys = [square_corners(*t) for t in sq]
        for i in range(n):
            cx, cy, a, s = sq[i]
            # boundary: shrink if outside
            p = polys[i]
            lo = p.min(axis=0)
            hi = p.max(axis=0)
            shrink = 0.0
            if lo[0] < 0:
                shrink = max(shrink, -lo[0] / 1.0)
            if lo[1] < 0:
                shrink = max(shrink, -lo[1] / 1.0)
            if hi[0] > 1:
                shrink = max(shrink, (hi[0] - 1))
            if hi[1] > 1:
                shrink = max(shrink, (hi[1] - 1))
            if shrink > 1e-12 and s > 1e-12:
                # reduce side
                factor = max(0.0, 1.0 - shrink / max(s, 1e-12))
                ns = s * factor
                # recentre to stay inside
                cx = min(max(cx, ns / 2), 1 - ns / 2)
                cy = min(max(cy, ns / 2), 1 - ns / 2)
                sq[i] = (cx, cy, a, ns)
                changed = True
                polys[i] = square_corners(*sq[i])
        # overlaps
        for i in range(n):
            for j in range(i + 1, n):
                d = sat_overlap(polys[i], polys[j])
                if d > 1e-9:
                    # shrink both a bit
                    for k in (i, j):
                        cx, cy, a, s = sq[k]
                        ns = max(0.0, s - d * 0.5)
                        cx = min(max(cx, ns / 2), 1 - ns / 2)
                        cy = min(max(cy, ns / 2), 1 - ns / 2)
                        sq[k] = (cx, cy, a, ns)
                        polys[k] = square_corners(*sq[k])
                    changed = True
    return sq


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side by side, each width 0.5
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # optimal-ish: one big square covering half and two small
        # big square 0.5 x 0.5 bottom-left, two others top / right
        # sum ~ 0.5 + 0.5 + 0.5 = 1.5 (possible? no, use 0.5, 0.5, 0.5 stacked)
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        # 2x2 grid -> sum = 2
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    rng = random.Random(12345 + n)
    best_sq = None
    best_score = -1.0

    # candidate starts
    starts = []
    starts.append(grid_packing(n))
    # perturbed grid starts
    for _ in range(4):
        g = grid_packing(n)
        perturbed = []
        for (cx, cy, a, s) in g:
            perturbed.append((
                min(max(cx + rng.uniform(-0.05, 0.05), 0.0), 1.0),
                min(max(cy + rng.uniform(-0.05, 0.05), 0.0), 1.0),
                (a + rng.uniform(-0.05, 0.05)) % 1.0,
                max(0.0, s + rng.uniform(-0.02, 0.02))
            ))
        starts.append(perturbed)
    # random starts
    for _ in range(3):
        starts.append(random_packing(n, rng))

    for st in starts:
        # attempt local refinement
        try:
            cand = refine(st, n, maxiter=300)
        except Exception:
            cand = st
        cand = make_feasible(cand)
        # verify and score
        total = sum(t[3] for t in cand)
        # feasibility check: slight overlap allowed? reject if any meaningful overlap
        ok = True
        polys = [square_corners(*t) for t in cand]
        for i in range(n):
            for j in range(i + 1, n):
                if sat_overlap(polys[i], polys[j]) > 1e-6:
                    ok = False
                    break
            if not ok:
                break
        if ok:
            for p in polys:
                lo = p.min(axis=0)
                hi = p.max(axis=0)
                if lo[0] < -1e-6 or lo[1] < -1e-6 or hi[0] > 1 + 1e-6 or hi[1] > 1 + 1e-6:
                    ok = False
                    break
        if ok and total > best_score:
            best_score = total
            best_sq = cand

    if best_sq is None:
        # fallback: plain grid
        best_sq = make_feasible(grid_packing(n))

    # ensure exactly n entries
    best_sq = list(best_sq)[:n]
    while len(best_sq) < n:
        best_sq.append((0.5, 0.5, 0.0, 0.0))

    # final safety clamp
    result = []
    for (cx, cy, a, s) in best_sq:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        s = min(max(s, 0.0), 1.0)
        result.append((cx, cy, a, s))
    return result
