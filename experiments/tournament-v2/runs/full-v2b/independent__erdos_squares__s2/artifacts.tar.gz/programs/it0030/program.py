import math
import random
import time

def solve(n):
    if n <= 0:
        return []
    random.seed(12345 + n)
    start = time.time()
    limit = 55.0  # seconds, leave some margin

    def inside(cx, cy, side, ang):
        # angle is fraction of full turn; 0.25 = 90 degrees
        # Check if square with center (cx,cy), side, rotation ang fits in unit square
        th = ang * 2.0 * math.pi
        ca, sa = math.cos(th), math.sin(th)
        half = side * 0.5
        # corners relative to center
        pts = [(half, half), (-half, half), (-half, -half), (half, -half)]
        minx = 10.0
        maxx = -10.0
        miny = 10.0
        maxy = -10.0
        for x, y in pts:
            rx = x * ca - y * sa
            ry = x * sa + y * ca
            if rx < minx: minx = rx
            if rx > maxx: maxx = rx
            if ry < miny: miny = ry
            if ry > maxy: maxy = ry
        return (cx + minx >= -1e-9 and cx + maxx <= 1.0 + 1e-9 and
                cy + miny >= -1e-9 and cy + maxy <= 1.0 + 1e-9)

    def overlap(sq1, sq2):
        # SAT for two squares (with small tolerance)
        cx1, cy1, a1, s1 = sq1
        cx2, cy2, a2, s2 = sq2
        if s1 <= 0.0 or s2 <= 0.0:
            return False
        # If centers far apart, no overlap
        dx = cx1 - cx2
        dy = cy1 - cy2
        dist = math.hypot(dx, dy)
        if dist > (s1 + s2) * 0.72 + 1e-9:
            return False

        # Build axes for both squares
        th1 = a1 * 2.0 * math.pi
        th2 = a2 * 2.0 * math.pi
        axes1 = [(math.cos(th1), math.sin(th1)), (-math.sin(th1), math.cos(th1))]
        axes2 = [(math.cos(th2), math.sin(th2)), (-math.sin(th2), math.cos(th2))]
        
        # Use overlap with strict interior test by shrinking slightly.
        # Two convex polygons disjoint if there's an axis separating them.
        # For squares A and B with centers c1,c2 and half extents h1,h2:
        # Projection radius of square i onto axis ax is h_i*(|ax·u_i1|+|ax·u_i2|) 
        # where u_i1,u_i2 are unit axes of square i.
        h1 = s1 * 0.5
        h2 = s2 * 0.5
        for ax in axes1 + axes2:
            axx, axy = ax
            proj1 = abs(axx * axes1[0][0] + axy * axes1[0][1]) + abs(axx * axes1[1][0] + axy * axes1[1][1])
            proj2 = abs(axx * axes2[0][0] + axy * axes2[0][1]) + abs(axx * axes2[1][0] + axy * axes2[1][1])
            r1 = h1 * proj1
            r2 = h2 * proj2
            c = abs(dx * axx + dy * axy)
            # Strictly disjoint if c >= r1 + r2 (allow tiny epsilon)
            if c < r1 + r2 - 1e-9:
                return True  # overlaps interior
        return False

    def total(squares):
        return sum(s for (_, _, _, s) in squares)

    def is_feasible(squares):
        # Check all inside and no overlaps
        for s in squares:
            if not inside(s[0], s[1], s[3], s[2]):
                return False
        m = len(squares)
        for i in range(m):
            if squares[i][3] <= 0:
                continue
            for j in range(i+1, m):
                if squares[j][3] <= 0:
                    continue
                if overlap(squares[i], squares[j]):
                    return False
        return True

    # Initial configuration strategies
    def init_grid(k, remaining):
        # k x k grid, then place remaining as small squares in gaps or zero
        side = 1.0 / k
        sqs = []
        for i in range(k):
            for j in range(k):
                sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        # If remaining > 0, try to fit smaller squares by splitting cells
        # Simplest: give them zero size first
        while len(sqs) < n:
            sqs.append((0.5, 0.5, 0.0, 0.0))
        return sqs[:n]

    def init_rows_cols(n):
        # Try to arrange squares in rows of varying widths
        # Use a greedy approach: start with all zero, then greedily expand one by one
        sqs = [(0.5, 0.5, 0.0, 0.0)] * n
        # Try to create k full squares and rest smaller
        k = max(1, int(math.sqrt(n)))
        # Alternative: place squares in a row/grid with varying sizes
        # Greedy: divide into columns with different counts
        best_init = None
        best_val = -1.0
        # Try a few grid-like patterns with different splits
        for kx in range(1, min(n, 20) + 1):
            for ky in range(1, min(n, 20) + 1):
                if kx * ky > n:
                    continue
                # kx * ky squares in grid, then remaining get split
                side = min(1.0 / kx, 1.0 / ky)
                sqs = []
                for i in range(kx):
                    for j in range(ky):
                        sqs.append(((i + 0.5) * (1.0 / kx), (j + 0.5) * (1.0 / ky), 0.0, side))
                # Remaining squares: try to subdivide some cells
                rem = n - kx * ky
                # Just fill with zero for now
                while len(sqs) < n:
                    sqs.append((0.5, 0.5, 0.0, 0.0))
                val = total(sqs[:n])
                if val > best_val:
                    best_val = val
                    best_init = sqs[:n]
        return best_init

    # Start with several initial configurations, pick best feasible
    candidates = []
    for k in range(1, min(n, 30) + 1):
        if k * k <= n:
            candidates.append(init_grid(k, n - k * k))
    ic = init_rows_cols(n)
    if ic:
        candidates.append(ic)

    best = None
    best_score = -1.0

    for cand in candidates:
        if is_feasible(cand):
            sc = total(cand)
            if sc > best_score:
                best_score = sc
                best = [list(x) for x in cand]

    if best is None:
        # Fallback: zeros
        best = [[0.5, 0.5, 0.0, 0.0] for _ in range(n)]
        best_score = 0.0

    # Local search / simulated annealing
    # Moves: 
    # 1. Change angle of a square (0 to 0.25, symmetry)
    # 2. Change position
    # 3. Change size (grow/shrink)
    # 4. Swap sizes? 
    # We'll do coordinate-wise hill climbing with random restarts within time

    # Ensure all squares are valid initially
    # If not feasible, shrink offending squares
    def repair(sqs):
        sqs = [list(x) for x in sqs]
        for _ in range(100):
            bad = False
            for i in range(len(sqs)):
                if not inside(sqs[i][0], sqs[i][1], sqs[i][3], sqs[i][2]):
                    bad = True
                    # shrink and center
                    sqs[i][0] = 0.5
                    sqs[i][1] = 0.5
                    sqs[i][3] *= 0.5
            for i in range(len(sqs)):
                if sqs[i][3] <= 0:
                    continue
                for j in range(i+1, len(sqs)):
                    if sqs[j][3] <= 0:
                        continue
                    if overlap(sqs[i], sqs[j]):
                        bad = True
                        # shrink both slightly
                        sqs[i][3] *= 0.95
                        sqs[j][3] *= 0.95
            if not bad:
                break
        return [tuple(x) for x in sqs]

    best = repair(best)
    best_score = total(best)

    # Iterative improvement
    temp = 0.05
    it = 0
    last_improve = time.time()
    while time.time() - start < limit:
        it += 1
        # pick a random square to modify
        idx = random.randrange(n)
        sq = list(best[idx])
        move = random.random()
        
        new_sq = sq[:]
        if move < 0.35:
            # change position
            new_sq[0] += random.uniform(-0.05, 0.05)
            new_sq[1] += random.uniform(-0.05, 0.05)
            new_sq[0] = max(0.0, min(1.0, new_sq[0]))
            new_sq[1] = max(0.0, min(1.0, new_sq[1]))
        elif move < 0.55:
            # change angle
            new_sq[2] = random.uniform(0.0, 0.25)
        elif move < 0.85:
            # change size (usually increase)
            factor = random.uniform(0.95, 1.3) if random.random() < 0.7 else random.uniform(0.7, 1.05)
            new_sq[3] = max(0.0, new_sq[3] * factor)
        else:
            # random restart of this square
            new_sq = [random.uniform(0.05, 0.95), random.uniform(0.05, 0.95),
                      random.uniform(0.0, 0.25), random.uniform(0.0, 0.4)]
        
        # Enforce inside
        if not inside(new_sq[0], new_sq[1], new_sq[3], new_sq[2]):
            # try to shrink until fits
            for _ in range(10):
                new_sq[3] *= 0.9
                if inside(new_sq[0], new_sq[1], new_sq[3], new_sq[2]):
                    break
            else:
                continue
        
        # Check overlap with others
        ok = True
        for j in range(n):
            if j == idx:
                continue
            if overlap(new_sq, best[j]):
                ok = False
                break
        if not ok:
            continue
        
        # Compute delta
        old_score = best_score
        new_score = old_score - best[idx][3] + new_sq[3]
        delta = new_score - old_score
        T = max(1e-6, temp * (1.0 - (time.time() - start) / limit))
        if delta > 0 or random.random() < math.exp(delta / (T + 1e-12)):
            best[idx] = tuple(new_sq)
            best_score = new_score
            if delta > 0:
                last_improve = time.time()
        # Occasionally try to grow all squares greedily
        if it % 500 == 0:
            # Try to grow each square a bit
            improved = False
            for i in range(n):
                for _ in range(5):
                    factor = random.uniform(1.001, 1.02)
                    ns = list(best[i])
                    ns[3] *= factor
                    if inside(ns[0], ns[1], ns[3], ns[2]):
                        ok2 = True
                        for j in range(n):
                            if j == i: continue
                            if overlap(ns, best[j]):
                                ok2 = False
                                break
                        if ok2:
                            best[i] = tuple(ns)
                            best_score += (ns[3] - best[i][3] if False else 0)
                            improved = True
            if improved:
                best_score = total(best)

    return best
