import math
import random
import numpy as np
from scipy.optimize import minimize

def _overlap_area(c1, c2, a1, a2, s1, s2):
    """Approximate check if two rotated squares overlap. Returns True if interiors intersect."""
    # Use separating axis theorem (SAT) for rotated squares
    # A square centered at (cx, cy) with rotation angle (radians) and side s
    # Half-extents along local axes
    h1, h2 = s1/2, s2/2
    # Local axes for each square
    ca1, sa1 = math.cos(a1), math.sin(a1)
    ca2, sa2 = math.cos(a2), math.sin(a2)
    axes1 = [(ca1, sa1), (-sa1, ca1)]
    axes2 = [(ca2, sa2), (-sa2, ca2)]
    axes = axes1 + axes2
    # Vector between centers
    dx, dy = c2[0]-c1[0], c2[1]-c1[1]
    for ax, ay in axes:
        # Projection of half-extents onto axis
        # For square 1: project using its axes
        proj1 = abs((ca1*ax + sa1*ay))*h1 + abs((-sa1*ax + ca1*ay))*h1
        proj2 = abs((ca2*ax + sa2*ay))*h2 + abs((-sa2*ax + ca2*ay))*h2
        dist = abs(dx*ax + dy*ay)
        if dist >= proj1 + proj2 - 1e-12:
            return False
    return True

def _feasible(squares):
    """Check if all squares are inside unit square and disjoint interiors."""
    for (cx, cy, ang, side) in squares:
        if side <= 0: continue
        # check bounding box inside [0,1]^2
        ca, sa = math.cos(ang), math.sin(ang)
        h = side/2
        # corners
        corners = [(cx + h*(ca - sa), cy + h*(sa + ca)),
                   (cx + h*(ca + sa), cy + h*(sa - ca)),
                   (cx + h*(-ca + sa), cy + h*(-sa - ca)),
                   (cx + h*(-ca - sa), cy + h*(-sa + ca))]
        for x, y in corners:
            if x < -1e-9 or x > 1+1e-9 or y < -1e-9 or y > 1+1e-9:
                return False
    n = len(squares)
    for i in range(n):
        if squares[i][3] <= 0: continue
        for j in range(i+1, n):
            if squares[j][3] <= 0: continue
            if _overlap_area((squares[i][0], squares[i][1]), (squares[j][0], squares[j][1]),
                             squares[i][2], squares[j][2], squares[i][3], squares[j][3]):
                return False
    return True

def _objective(params, n, active):
    """Negative sum of sides for active squares; params: (cx, cy, ang, side) for each active."""
    s = 0.0
    for i in range(n):
        if active[i]:
            s += params[4*i+3]
    return -s

def _pack_anneal(n, time_limit=2.0):
    """Simulated annealing / random search for n squares."""
    if n == 0:
        return []
    # start with grid
    k = math.isqrt(n)
    side = 1.0/k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i+0.5)*side, (j+0.5)*side, 0.0, side])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    squares = squares[:n]
    
    best = [s[:] for s in squares]
    best_sum = sum(s[3] for s in squares)
    
    import time
    start = time.time()
    T = 0.05
    step = 0.02
    cur = [s[:] for s in squares]
    cur_sum = best_sum
    
    while time.time() - start < time_limit:
        # pick random square
        idx = random.randrange(n)
        if cur[idx][3] <= 1e-9:
            # try to grow from zero
            new = cur[idx][:]
            new[3] = random.uniform(0.001, 0.05)
            new[0] = random.uniform(0.05, 0.95)
            new[1] = random.uniform(0.05, 0.95)
            new[2] = random.uniform(0, math.pi/2)
        else:
            new = cur[idx][:]
            move = random.choice(['cx','cy','ang','side'])
            if move == 'cx':
                new[0] += random.gauss(0, step)
            elif move == 'cy':
                new[1] += random.gauss(0, step)
            elif move == 'ang':
                new[2] += random.gauss(0, step)
            else:
                new[3] += random.gauss(0, step*2)
            # clamp
            new[0] = min(1.0, max(0.0, new[0]))
            new[1] = min(1.0, max(0.0, new[1]))
            new[2] = new[2] % (math.pi/2)
            new[3] = max(0.0, min(1.0, new[3]))
        
        # check feasibility
        trial = [s[:] for s in cur]
        trial[idx] = new
        if _feasible(trial):
            delta = new[3] - cur[idx][3]
            if delta >= 0 or random.random() < math.exp(delta/T):
                cur = trial
                cur_sum += delta
                if cur_sum > best_sum:
                    best_sum = cur_sum
                    best = [s[:] for s in cur]
        # cooling
        T *= 0.9999
        if T < 1e-5: T = 1e-5
    return best

def _random_restart(n, num_restarts=5, time_per=0.5):
    best = None
    best_sum = -1
    for _ in range(num_restarts):
        sq = _pack_anneal(n, time_per)
        s = sum(x[3] for x in sq)
        if s > best_sum:
            best_sum = s
            best = sq
    return best

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) in [0,1]^2, disjoint interiors."""
    if n <= 4:
        # For small n, try to find good patterns
        # n=1: side=1 center (0.5,0.5) angle=0
        if n == 1:
            return [(0.5, 0.5, 0.0, 1.0)]
        # n=2: two squares side 0.5 each, or rotated
        if n == 2:
            # two squares side 0.5 side by side
            return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
        if n == 3:
            # one big 0.5, two 0.5? Actually 3 squares: 2 in top row, 1 bottom? Not optimal.
            # Use 3 squares each 1/3? Or one 0.5, two 0.5?
            # Best for 3: two 0.5 side by side top, one 0.5 bottom? That's 0.5+0.5+0.5=1.5 but does it fit?
            # 3 squares of side 0.5 in a row: total width 1.5 > 1. So only 2 fit in a row.
            # Try: one 0.5, two 0.5? 
            # Actually known: for n=3, can do 0.5, 0.5, 0.5? No.
            # Let's just use the annealing for n>=2
            pass
    # Use simulated annealing with random restarts
    time_limit = min(10.0, 55.0 / max(1, n))  # scale with n
    # For small n give more time
    if n <= 10:
        time_limit = 5.0
    elif n <= 30:
        time_limit = 3.0
    else:
        time_limit = 1.5
    
    best = None
    best_sum = -1
    import time
    start = time.time()
    restarts = 0
    while time.time() - start < time_limit - 0.1 and restarts < 20:
        sq = _pack_anneal(n, time_limit - (time.time() - start))
        s = sum(x[3] for x in sq)
        if s > best_sum:
            best_sum = s
            best = sq
        restarts += 1
    
    if best is None:
        # fallback
        k = math.isqrt(n)
        side = 1.0/k
        best = [((i+0.5)*side, (j+0.5)*side, 0.0, side) for i in range(k) for j in range(k)]
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))
        best = best[:n]
    
    # Convert angles to fraction of full turn
    result = []
    for (cx, cy, ang, side) in best:
        result.append((cx, cy, ang/(2*math.pi), side))
    return result[:n]
