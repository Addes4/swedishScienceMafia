# EVOLVE-BLOCK-START
"""Packing many squares in the unit square, maximising total side length.

The approach is a fast randomised constructive heuristic followed by a
penalty-based local search.  It works for every n without a lookup table and
respects the 60 second per-n budget by capping the number of iterations.
"""

import math
import random
import time


def _corners(cx, cy, a, s):
    """Return the four corners of a square."""
    ca = math.cos(2.0 * math.pi * a)
    sa = math.sin(2.0 * math.pi * a)
    h = 0.5 * s
    return (
        (cx + h * (ca - sa), cy + h * (sa + ca)),
        (cx + h * (ca + sa), cy + h * (sa - ca)),
        (cx + h * (-ca + sa), cy + h * (-sa - ca)),
        (cx + h * (-ca - sa), cy + h * (-sa + ca)),
    )


def _bbox(cx, cy, a, s):
    pts = _corners(cx, cy, a, s)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    return min(xs), min(ys), max(xs), max(ys)


def _valid(sq):
    """Quick bounding-box validity check (necessary, not sufficient)."""
    for cx, cy, a, s in sq:
        x0, y0, x1, y1 = _bbox(cx, cy, a, s)
        if x0 < -1e-12 or y0 < -1e-12 or x1 > 1.0 + 1e-12 or y1 > 1.0 + 1e-12:
            return False
    return True


def _overlap_pair(p, q):
    """Return the overlap area of two convex quads (0 if disjoint)."""
    # Separating axis theorem for convex polygons using sampled directions
    # from the edge normals; then polygon clipping via Sutherland-Hodgman.
    def axes(poly):
        ax = []
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 1e-15:
                ax.append((-ey / ln, ex / ln))
        return ax

    poly1 = list(_corners(*p))
    poly2 = list(_corners(*q))

    for ax in axes(poly1) + axes(poly2):
        p1 = [x * ax[0] + y * ax[1] for x, y in poly1]
        p2 = [x * ax[0] + y * ax[1] for x, y in poly2]
        if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
            return 0.0

    # clip poly2 against poly1
    def inside(p, a, b):
        return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= -1e-15

    def intersect(p, q, a, b):
        d1x, d1y = q[0] - p[0], q[1] - p[1]
        d2x, d2y = b[0] - a[0], b[1] - a[1]
        den = d1x * d2y - d1y * d2x
        if abs(den) < 1e-15:
            return p
        t = ((a[0] - p[0]) * d2y - (a[1] - p[1]) * d2x) / den
        return (p[0] + t * d1x, p[1] + t * d1y)

    output = poly2
    clip = poly1
    m = len(clip)
    for i in range(m):
        inp = output
        output = []
        if not inp:
            break
        a = clip[i]
        b = clip[(i + 1) % m]
        for j in range(len(inp)):
            cur = inp[j]
            prev = inp[j - 1]
            ci = inside(cur, a, b)
            pi = inside(prev, a, b)
            if ci:
                if not pi:
                    output.append(intersect(prev, cur, a, b))
                output.append(cur)
            elif pi:
                output.append(intersect(prev, cur, a, b))
    if len(output) < 3:
        return 0.0
    area = 0.0
    for i in range(len(output)):
        x1, y1 = output[i]
        x2, y2 = output[(i + 1) % len(output)]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def _score(sq, penalize=True):
    total = sum(s for _, _, _, s in sq)
    if not penalize:
        return total
    pen = 0.0
    m = len(sq)
    for i in range(m):
        cx, cy, a, s = sq[i]
        x0, y0, x1, y1 = _bbox(cx, cy, a, s)
        if x0 < 0.0:
            pen += -x0
        if y0 < 0.0:
            pen += -y0
        if x1 > 1.0:
            pen += x1 - 1.0
        if y1 > 1.0:
            pen += y1 - 1.0
        for j in range(i + 1, m):
            pen += _overlap_pair(sq[i], sq[j])
            if pen > 0.5:
                return total - 10.0 * pen
    return total - 10.0 * pen


def _greedy_construct(n, rng):
    """Construct a starting configuration with descending square sizes."""
    sq = []
    used = []
    # sizes decreasing: use shelf-like placement first
    # For the first squares use a diagonal / grid-like initial guess.
    for k in range(n):
        best_s = 0.0
        best_pos = (0.5, 0.5, 0.0)
        # sample random candidates, keep largest that fits without overlap
        trials = 40 if k < 80 else 20
        for _ in range(trials):
            s = rng.uniform(0.02, 0.7)
            a = rng.choice([0.0, 0.0, 0.0, 0.25, rng.random()])
            cx = rng.uniform(0.5 * s, 1.0 - 0.5 * s)
            cy = rng.uniform(0.5 * s, 1.0 - 0.5 * s)
            cand = (cx, cy, a, s)
            if not _valid([cand]):
                continue
            ok = True
            for other in sq:
                if _overlap_pair(cand, other) > 1e-12:
                    ok = False
                    break
            if ok and s > best_s:
                best_s = s
                best_pos = (cx, cy, a)
        sq.append((best_pos[0], best_pos[1], best_pos[2], best_s))
    return sq


def _improve(sq, time_limit, rng):
    """Penalty-based stochastic local search."""
    start = time.time()
    best = [list(x) for x in sq]
    best_val = _score([tuple(x) for x in best], penalize=False)
    if not _valid([tuple(x) for x in best]):
        best_val = _score([tuple(x) for x in best], penalize=True)

    cur = [list(x) for x in sq]
    cur_val = _score([tuple(x) for x in cur], penalize=True)
    n = len(cur)
    steps = 0
    while time.time() - start < time_limit:
        steps += 1
        i = rng.randrange(n)
        old = cur[i][:]
        # perturbation
        mode = rng.random()
        if mode < 0.45:
            # change side
            cur[i][3] = max(0.0, old[3] + rng.gauss(0.0, 0.03))
        elif mode < 0.7:
            # move
            cur[i][0] = min(1.0, max(0.0, old[0] + rng.gauss(0.0, 0.02)))
            cur[i][1] = min(1.0, max(0.0, old[1] + rng.gauss(0.0, 0.02)))
        elif mode < 0.9:
            # rotate
            cur[i][2] = (old[2] + rng.gauss(0.0, 0.02)) % 1.0
        else:
            # swap / random restart of one square
            s = rng.uniform(0.0, 0.6)
            a = rng.choice([0.0, 0.25, rng.random()])
            cx = rng.uniform(0.5 * s, 1.0 - 0.5 * s)
            cy = rng.uniform(0.5 * s, 1.0 - 0.5 * s)
            cur[i] = [cx, cy, a, s]

        # clamp
        s = cur[i][3]
        ca = abs(math.cos(2 * math.pi * cur[i][2]))
        sa = abs(math.sin(2 * math.pi * cur[i][2]))
        hx = 0.5 * s * (ca + sa)
        cur[i][0] = min(1.0 - hx, max(hx, cur[i][0]))
        cur[i][1] = min(1.0 - hx, max(hx, cur[i][1]))

        new_val = _score([tuple(x) for x in cur], penalize=True)
        temp = 0.02 * (1.0 - min(1.0, (time.time() - start) / max(1e-9, time_limit)))
        if new_val > cur_val or rng.random() < math.exp((new_val - cur_val) / max(1e-6, temp)):
            cur_val = new_val
            real = _score([tuple(x) for x in cur], penalize=False)
            if _valid([tuple(x) for x in cur]) and real > best_val:
                best_val = real
                best = [x[:] for x in cur]
        else:
            cur[i] = old

        # local greedy polish of largest square occasionally
        if steps % 500 == 0:
            if _valid([tuple(x) for x in cur]):
                real = _score([tuple(x) for x in cur], penalize=False)
                if real > best_val:
                    best_val = real
                    best = [x[:] for x in cur]

    return [tuple(x) for x in best]


def solve(n):
    """Return n non-overlapping squares maximising the sum of side lengths."""
    if n <= 0:
        return []

    rng = random.Random(1234567 + n)
    best_sq = None
    best_sum = -1.0

    # Number of independent starts; adapt to n and time budget.
    if n <= 20:
        starts = 8
        tl = 5.0
    elif n <= 100:
        starts = 4
        tl = 8.0
    elif n <= 400:
        starts = 2
        tl = 12.0
    else:
        starts = 1
        tl = 25.0

    total_deadline = time.time() + 55.0

    for st in range(starts):
        if time.time() > total_deadline:
            break
        sq = _greedy_construct(n, rng)
        # try to make a valid initial config
        if not _valid(sq):
            # shrink until valid
            for _ in range(200):
                sq2 = []
                for cx, cy, a, s in sq:
                    s2 = s * 0.99
                    ca = abs(math.cos(2 * math.pi * a))
                    sa = abs(math.sin(2 * math.pi * a))
                    h = 0.5 * s2 * (ca + sa)
                    cx2 = min(1.0 - h, max(h, cx))
                    cy2 = min(1.0 - h, max(h, cy))
                    sq2.append((cx2, cy2, a, s2))
                sq = sq2
                if _valid(sq):
                    break
        if not _valid(sq):
            continue
        imp = _improve(sq, tl / starts, rng)
        s = _score(imp, penalize=False)
        if _valid(imp) and s > best_sum:
            best_sum = s
            best_sq = imp

    if best_sq is None:
        # fallback: grid of equal axis-aligned squares
        k = max(1, math.isqrt(n))
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                   for i in range(k) for j in range(k)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        return squares[:n]

    # fill missing squares (if any)
    if len(best_sq) < n:
        best_sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sq))
    return [tuple(x) for x in best_sq[:n]]


# EVOLVE-BLOCK-END
