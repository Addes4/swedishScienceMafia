import math
import random
import numpy as np

TWO_PI = 2.0 * math.pi


def _corners(cx, cy, ang, side):
    """Return the four corners of a rotated square."""
    if side <= 0.0:
        return [(cx, cy)] * 4
    a = ang * TWO_PI
    ca, sa = math.cos(a), math.sin(a)
    h = side * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + x * ca - y * sa, cy + x * sa + y * ca) for x, y in pts]


def _inside(poly):
    """Check that all corners are inside the unit square (with tolerance)."""
    for x, y in poly:
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


def _overlap(p1, p2):
    """Separating axis test for two convex polygons. Returns True if interiors overlap."""
    for poly in (p1, p2):
        n = len(poly)
        if n == 1:
            continue
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            ax, ay = -ey, ex  # normal
            # skip zero normal
            if ax * ax + ay * ay < 1e-30:
                continue
            min1 = min2 = 1e30
            max1 = max2 = -1e30
            for px, py in p1:
                d = px * ax + py * ay
                if d < min1: min1 = d
                if d > max1: max1 = d
            for px, py in p2:
                d = px * ax + py * ay
                if d < min2: min2 = d
                if d > max2: max2 = d
            if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                return False
    return True


def _valid(squares):
    """Check all squares are inside and non-overlapping. squares: list of (cx,cy,ang,side)."""
    polys = []
    for cx, cy, ang, side in squares:
        poly = _corners(cx, cy, ang, side)
        if not _inside(poly):
            return False
        polys.append(poly)
    m = len(polys)
    for i in range(m):
        if len(polys[i]) == 1:
            continue
        for j in range(i + 1, m):
            if len(polys[j]) == 1:
                continue
            if _overlap(polys[i], polys[j]):
                return False
    return True


def _initial_grid(n):
    """Start with the largest grid of equal axis-aligned squares, extra at centre size 0."""
    k = max(1, math.isqrt(n))
    # try to use a near-square grid: k x k may leave up to 2k-1 unused; we can do k*(k+1)
    if k * (k + 1) <= n:
        rows, cols = k, k + 1
    else:
        rows, cols = k, k
    side = min(1.0 / rows, 1.0 / cols)
    squares = []
    for i in range(rows):
        for j in range(cols):
            if len(squares) >= n:
                break
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
        if len(squares) >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _score(squares):
    return sum(s[3] for s in squares)


def _perturb_candidate(idx, squares, rng, scale_c, scale_a, scale_s):
    """Try to improve a single square by local search."""
    cx, cy, ang, side = squares[idx]
    best = (cx, cy, ang, side)
    best_s = side
    # candidate perturbations
    for _ in range(40):
        ncx = cx + rng.uniform(-scale_c, scale_c)
        ncy = cy + rng.uniform(-scale_c, scale_c)
        nang = ang + rng.uniform(-scale_a, scale_a)
        nside = max(0.0, side + rng.uniform(-scale_s, scale_s))
        # clamp position
        ncx = min(max(ncx, 0.0), 1.0)
        ncy = min(max(ncy, 0.0), 1.0)
        if nside <= 1e-14:
            nside = 0.0
        trial = list(squares)
        trial[idx] = (ncx, ncy, nang, nside)
        if _valid(trial):
            if nside > best_s + 1e-15:
                best_s = nside
                best = (ncx, ncy, nang, nside)
    return best


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    rng = random.Random(12345 + n)
    squares = _initial_grid(n)
    # ensure validity (it should be)
    if not _valid(squares):
        # fallback: all zero
        squares = [(0.5, 0.5, 0.0, 0.0)] * n

    total = _score(squares)
    # phase 1: greedily grow individual squares / add area
    for it in range(6):
        improved = False
        for idx in range(n):
            before = squares[idx][3]
            new = _perturb_candidate(idx, squares, rng, 0.03, 0.15, 0.04)
            if new[3] > before + 1e-15:
                squares[idx] = new
                improved = True
        total_new = _score(squares)
        if total_new <= total + 1e-15 and not improved:
            break
        total = total_new

    # phase 2: try to relocate the smallest squares to gain more
    # Sort indices by side descending; try to redistribute
    for _ in range(3):
        order = sorted(range(n), key=lambda i: squares[i][3])
        changed = False
        for i in order:
            # remove this square temporarily by setting to zero, then try to find good spot
            old = squares[i]
            squares[i] = (old[0], old[1], old[2], 0.0)
            # try many random placements for this square
            best_side = 0.0
            best_pos = squares[i]
            for _ in range(80):
                cx = rng.uniform(0.0, 1.0)
                cy = rng.uniform(0.0, 1.0)
                ang = rng.uniform(0.0, 1.0)
                side = old[3]
                trial = list(squares)
                trial[i] = (cx, cy, ang, side)
                if _valid(trial):
                    # try to grow it
                    lo, hi = side, min(1.0, math.hypot(min(cx, 1 - cx), min(cy, 1 - cy)) * 2.0)
                    # binary search up to reasonable size
                    for _ in range(12):
                        mid = (lo + hi) * 0.5
                        trial[i] = (cx, cy, ang, mid)
                        if _valid(trial):
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_side + 1e-15:
                        best_side = lo
                        best_pos = (cx, cy, ang, lo)
            if best_side > old[3] + 1e-15:
                squares[i] = best_pos
                changed = True
            else:
                squares[i] = old
        if not changed:
            break

    # final cleanup / ensure valid
    if not _valid(squares):
        squares = [(0.5, 0.5, 0.0, 0.0)] * n

    # clamp all numbers to [0,1] as required (angles may exceed but fraction is fine; ensure in [0,1])
    out = []
    for cx, cy, ang, side in squares:
        ang = ang % 1.0
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        side = min(max(side, 0.0), 1.0)
        out.append((cx, cy, ang, side))
    return out
