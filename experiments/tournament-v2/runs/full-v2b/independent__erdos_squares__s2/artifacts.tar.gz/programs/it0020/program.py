import math
import random
import numpy as np
from scipy.optimize import minimize


def _rot(a, x, y):
    c = math.cos(2 * math.pi * a)
    s = math.sin(2 * math.pi * a)
    return c * x - s * y, s * x + c * y


def _corners(cx, cy, a, side):
    h = side * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x, y = _rot(a, dx, dy)
        pts.append((cx + x, cy + y))
    return pts


def _axes(a):
    c = math.cos(2 * math.pi * a)
    s = math.sin(2 * math.pi * a)
    return (c, s), (-s, c)


def _overlap(p1, a1, s1, p2, a2, s2):
    axes = [_axes(a1)[0], _axes(a1)[1], _axes(a2)[0], _axes(a2)[1]]
    c1 = _corners(p1[0], p1[1], a1, s1)
    c2 = _corners(p2[0], p2[1], a2, s2)
    for ax in axes:
        ux, uy = ax
        mn1 = mx1 = c1[0][0] * ux + c1[0][1] * uy
        for x, y in c1[1:]:
            v = x * ux + y * uy
            if v < mn1: mn1 = v
            if v > mx1: mx1 = v
        mn2 = mx2 = c2[0][0] * ux + c2[0][1] * uy
        for x, y in c2[1:]:
            v = x * ux + y * uy
            if v < mn2: mn2 = v
            if v > mx2: mx2 = v
        if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
            return 0.0
    # minimum translation overlap area estimate: use axis-aligned approximation
    # approximate penetration depth = min overlap over axes
    best = 1e9
    for ax in axes:
        ux, uy = ax
        mn1 = mx1 = c1[0][0] * ux + c1[0][1] * uy
        for x, y in c1[1:]:
            v = x * ux + y * uy
            if v < mn1: mn1 = v
            if v > mx1: mx1 = v
        mn2 = mx2 = c2[0][0] * ux + c2[0][1] * uy
        for x, y in c2[1:]:
            v = x * ux + y * uy
            if v < mn2: mn2 = v
            if v > mx2: mx2 = v
        ov = min(mx1, mx2) - max(mn1, mn2)
        if ov < best: best = ov
    return max(0.0, best)


def _penalty(sqs, w=2000.0):
    n = len(sqs)
    pen = 0.0
    for i in range(n):
        cx, cy, a, s = sqs[i]
        if s <= 0: continue
        h = 0.5 * s
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x, y = _rot(a, dx, dy)
            x += cx; y += cy
            if x < 0: pen += w * (-x) ** 2
            if x > 1: pen += w * (x - 1) ** 2
            if y < 0: pen += w * (-y) ** 2
            if y > 1: pen += w * (y - 1) ** 2
    for i in range(n):
        cxi, cyi, ai, si = sqs[i]
        if si <= 0: continue
        for j in range(i + 1, n):
            cxj, cyj, aj, sj = sqs[j]
            if sj <= 0: continue
            ov = _overlap((cxi, cyi), ai, si, (cxj, cyj), aj, sj)
            if ov > 1e-12:
                pen += w * ov ** 2
    return pen


def _objective(x, n):
    sqs = []
    for i in range(n):
        b = 4 * i
        sqs.append((x[b], x[b + 1], x[b + 2], x[b + 3]))
    return _penalty(sqs)


def _fit(sqs, maxiter=120):
    n = len(sqs)
    x0 = []
    for cx, cy, a, s in sqs:
        x0.extend([min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), min(max(a, 0.0), 1.0), s])
    x0 = np.array(x0, dtype=float)
    bounds = [(0, 1), (0, 1), (0, 1), (0, 1)] * n
    try:
        res = minimize(_objective, x0, args=(n,), method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': maxiter, 'ftol': 1e-12, 'gtol': 1e-10})
        x = res.x
    except Exception:
        x = x0
    out = []
    for i in range(n):
        b = 4 * i
        out.append((float(x[b]), float(x[b + 1]), float(x[b + 2]), float(x[b + 3])))
    return out


def _score(sqs):
    return sum(s for _, _, _, s in sqs)


def _grid(n):
    k = int(math.isqrt(n))
    res = []
    side = 1.0 / k
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    rem = n - k * k
    if rem > 0:
        # add a strip of rem squares along the top/bottom within remaining space
        # remaining height = 1 - k*side = 1 - 1 = 0 if k divides 1. Instead use smaller k.
        pass
    return res


def _grid_rem(n):
    best = None
    for k in range(1, int(math.isqrt(n)) + 1):
        if k * k > n: break
        rows = n // k
        if rows == 0: continue
        # k columns, rows rows, fill remaining with a partial row
        # choose sizes: grid of k columns and rows rows
        # handle leftover
        rem = n - k * rows
        # We'll use a top strip of height t with some squares
        # Simple: uniform k columns across, with rows squares, then extra squares in top strip
        best_local = None
        for t in np.linspace(0.0, 1.0, 21):
            if rem == 0:
                t = 0.0
            if t <= 0 and rem > 0:
                continue
            h = (1.0 - t) / rows if rows > 0 else 1.0
            if h <= 0: continue
            w = 1.0 / k
            s = min(w, h)
            res = []
            ok = True
            for i in range(k):
                for j in range(rows):
                    cx = (i + 0.5) * w
                    cy = (j + 0.5) * h
                    res.append((cx, cy, 0.0, s))
            if rem > 0 and t > 0:
                # place rem squares in top strip of height t
                if rem <= 2:
                    sw = 1.0 / rem
                    st = min(sw, t)
                    for i in range(rem):
                        res.append(((i + 0.5) * sw, 1.0 - t + st * 0.5, 0.0, st))
                else:
                    kk = math.isqrt(rem)
                    if kk * kk < rem:
                        kk += 1
                    if kk > 0:
                        sw = 1.0 / kk
                        st = min(sw, t)
                        cnt = 0
                        for i in range(kk):
                            for j in range(kk):
                                if cnt >= rem: break
                                res.append(((i + 0.5) * sw, 1.0 - t + (j + 0.5) * st, 0.0, st))
                                cnt += 1
            if len(res) != n:
                # pad with zeros
                while len(res) < n:
                    res.append((0.5, 0.5, 0.0, 0.0))
                res = res[:n]
            val = _score(res)
            if best_local is None or val > best_local[0]:
                best_local = (val, res)
        if best_local and (best is None or best_local[0] > best[0]):
            best = best_local
    return best[1] if best else _grid(n) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(_grid(n)))


def _squaring_sizes(total, count, rng, tries=50):
    # recursively split a square into `count` squares; returns list of sides
    # Represent as list of areas in a unit square
    if count <= 0:
        return []
    if count == 1:
        return [total]
    # random split into two groups
    best = None
    for _ in range(tries):
        c1 = rng.randint(1, count - 1)
        c2 = count - c1
        # fill sizes greedily
        szs = []
        # horizontal split: widths proportional to something
        # Use simple recursive square packing: choose split fraction f
        f = rng.uniform(0.2, 0.8)
        left = _squaring_sizes(total * f, c1, rng, tries=10)
        right = _squaring_sizes(total * (1 - f), c2, rng, tries=10)
        szs = left + right
        if len(szs) == count:
            if best is None or sum(szs) > sum(best):
                best = szs
    return best if best else [total / count] * count


def _guillotine(n, seed=0):
    rng = random.Random(seed)
    sizes = _squaring_sizes(0.5, n, rng, tries=30)
    if not sizes:
        return None
    # place them greedily on a grid
    # sort descending
    sizes = sorted(sizes, reverse=True)
    # generate candidate
    # use a shelf packing
    res = []
    x = 0.0
    y = 0.0
    row_h = 0.0
    for s in sizes:
        if x + s > 1.0 + 1e-9:
            x = 0.0
            y += row_h
            row_h = 0.0
        if y + s > 1.0 + 1e-9:
            s = min(s, 1.0 - y)
        if s <= 0: continue
        res.append((x + s * 0.5, y + s * 0.5, 0.0, s))
        x += s
        row_h = max(row_h, s)
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]


def _try_rotated_grid(n, k, rows, angle):
    # k columns * rows rows with rotation
    if k * rows > n: return None
    rem = n - k * rows
    h = 1.0 / rows
    w = 1.0 / k
    s = min(w, h) * (1.0 / (abs(math.cos(2 * math.pi * angle)) + abs(math.sin(2 * math.pi * angle))))
    if s <= 0: return None
    res = []
    for i in range(k):
        for j in range(rows):
            res.append(((i + 0.5) * w, (j + 0.5) * h, angle, s))
    # leftover
    if rem > 0:
        # add along a strip
        pass
    return res


def _greedy_rot(n, seed=0):
    rng = random.Random(seed)
    res = []
    # try random angles
    sizes = []
    # place n squares with decreasing sizes using a simple strip strategy
    for _ in range(30):
        ang = rng.choice([0.0, 0.05, 0.1, 0.15, 0.2, 0.25])
        # estimate largest feasible size for all equal
        c = abs(math.cos(2 * math.pi * ang)) + abs(math.sin(2 * math.pi * ang))
        k = int(math.isqrt(n))
        s = 1.0 / k / c
        if s > 0:
            sizes.append(s)
    return None


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 0.5)]
    candidates = []

    # 1. k x k grid plus leftover via simple strip
    k = int(math.isqrt(n))
    side = 1.0 / k
    g = []
    for i in range(k):
        for j in range(k):
            g.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    rem = n - k * k
    if rem > 0:
        # shrink to make room for strip of height t
        t_best = 0.0
        best_g = None
        for t in np.linspace(0.0, 0.5, 51):
            if t <= 0 and rem > 0:
                continue
            h = (1.0 - t) / k if k > 0 else 1.0
            s = min(side, h) if k > 0 else 1.0
            if s <= 0: continue
            cand = []
            for i in range(k):
                for j in range(k):
                    cand.append(((i + 0.5) * side, (j + 0.5) * h, 0.0, s))
            # leftover
            if rem <= 3:
                sw = 1.0 / rem
                st = min(sw, t)
                for i in range(rem):
                    cand.append(((i + 0.5) * sw, 1.0 - t + st * 0.5, 0.0, st))
            else:
                kk = int(math.ceil(math.sqrt(rem)))
                sw = 1.0 / kk
                st = min(sw, t)
                cnt = 0
                for i in range(kk):
                    for j in range(kk):
                        if cnt >= rem: break
                        cand.append(((i + 0.5) * sw, 1.0 - t + (j + 0.5) * st, 0.0, st))
                        cnt += 1
            while len(cand) < n:
                cand.append((0.5, 0.5, 0.0, 0.0))
            cand = cand[:n]
            val = _score(cand)
            if best_g is None or val > best_g[0]:
                best_g = (val, cand)
        if best_g:
            g = best_g[1]
    candidates.append(g)

    # 2. grid variants with different column counts
    for kk in range(max(1, k - 2), k + 3):
        rows = n // kk
        if rows <= 0: continue
        rem2 = n - kk * rows
        t_best = 0.0
        best_local = None
        for t in np.linspace(0.0, 0.5, 41):
            if rem2 > 0 and t <= 0: continue
            if rows == 0: break
            h = (1.0 - t) / rows
            w = 1.0 / kk
            s = min(w, h)
            cand = []
            for i in range(kk):
                for j in range(rows):
                    cand.append(((i + 0.5) * w, (j + 0.5) * h, 0.0, s))
            if rem2 > 0 and t > 0:
                if rem2 <= 3:
                    sw = 1.0 / rem2
                    st = min(sw, t)
                    for i in range(rem2):
                        cand.append(((i + 0.5) * sw, 1.0 - t + st * 0.5, 0.0, st))
                else:
                    kk2 = int(math.ceil(math.sqrt(rem2)))
                    sw = 1.0 / kk2
                    st = min(sw, t)
                    cnt = 0
                    for i in range(kk2):
                        for j in range(kk2):
                            if cnt >= rem2: break
                            cand.append(((i + 0.5) * sw, 1.0 - t + (j + 0.5) * st, 0.0, st))
                            cnt += 1
            while len(cand) < n:
                cand.append((0.5, 0.5, 0.0, 0.0))
            cand = cand[:n]
            val = _score(cand)
            if best_local is None or val > best_local[0]:
                best_local = (val, cand)
        if best_local:
            candidates.append(best_local[1])

    # 3. guillotine-ish random packings
    for seed in range(12):
        gc = _guillotine(n, seed)
        if gc and len(gc) == n:
            candidates.append(gc)

    # 4. rotated grid candidate
    for ang in [0.0, 0.02, 0.05, 0.08, 0.1, 0.15, 0.2, 0.25]:
        c = abs(math.cos(2 * math.pi * ang)) + abs(math.sin(2 * math.pi * ang))
        for kk in range(max(1, k - 1), k + 3):
            rows = n // kk
            if rows <= 0: continue
            rem2 = n - kk * rows
            w = 1.0 / kk
            h = 1.0 / rows
            s = min(w, h) / c
            if s <= 0: continue
            cand = []
            for i in range(kk):
                for j in range(rows):
                    cand.append(((i + 0.5) * w, (j + 0.5) * h, ang, s))
            if rem2 > 0:
                # just make leftover zero-size
                pass
            while len(cand) < n:
                cand.append((0.5, 0.5, 0.0, 0.0))
            cand = cand[:n]
            candidates.append(cand)

    # evaluate and pick best
    best_val = -1.0
    best_cand = None
    for cand in candidates:
        if len(cand) != n: continue
        v = _score(cand)
        if v > best_val:
            best_val = v
            best_cand = cand

    if best_cand is None:
        return [(0.5, 0.5, 0.0, 0.0)] * n

    # refine with numerical optimization (short)
    refined = _fit(best_cand, maxiter=200)
    if _score(refined) > 0:
        # clip to valid and check feasibility
        refined = [(min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), min(max(a, 0.0), 1.0),
                    max(0.0, min(s, 1.0)))
                   for cx, cy, a, s in refined]
        # slightly shrink to guarantee feasibility
        for _ in range(8):
            pen = _penalty(refined, w=1.0)
            if pen < 1e-8:
                break
            refined = [(cx, cy, a, s * 0.995) for cx, cy, a, s in refined]
        if _score(refined) > best_val * 0.999:
            best_cand = refined

    # final safety: ensure all squares within [0,1]^2 and n entries
    out = []
    for cx, cy, a, s in best_cand[:n]:
        s = max(0.0, s)
        h = 0.5 * s
        # ensure corners inside
        pts = _corners(cx, cy, a, s)
        minx = min(p[0] for p in pts); maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts); maxy = max(p[1] for p in pts)
        dx = 0.0; dy = 0.0
        if minx < 0: dx = -minx
        if maxx > 1: dx = 1 - maxx
        if miny < 0: dy = -miny
        if maxy > 1: dy = 1 - maxy
        out.append((min(max(cx + dx, 0.0), 1.0), min(max(cy + dy, 0.0), 1.0), min(max(a, 0.0), 1.0), s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
