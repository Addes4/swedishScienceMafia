import math
import random


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345 + n)

    # initial layout: nearly uniform grid, split into rows/cols close to sqrt(n)
    cols = max(1, int(round(math.sqrt(n))))
    rows = (n + cols - 1) // cols
    cells = []
    for r in range(rows):
        for c in range(cols):
            if len(cells) >= n:
                break
            w = 1.0 / cols
            h = 1.0 / rows
            cx = (c + 0.5) * w
            cy = (r + 0.5) * h
            cells.append([cx, cy, 0.0, min(w, h)])
        if len(cells) >= n:
            break

    sq = cells[:]

    def bounds(s):
        # axis-aligned bounding box half-extent, conservative for rotated square
        a = s[2] * 2 * math.pi
        ca = abs(math.cos(a))
        sa = abs(math.sin(a))
        h = 0.5 * s[3] * (ca + sa)
        return h

    # pairwise overlap amount (positive = overlap)
    def overlap(s1, s2):
        h1 = bounds(s1)
        h2 = bounds(s2)
        dx = abs(s1[0] - s2[0])
        dy = abs(s1[1] - s2[1])
        ox = (h1 + h2) - dx
        oy = (h1 + h2) - dy
        if ox <= 0 or oy <= 0:
            return 0.0
        return min(ox, oy)

    # iterative growth + separation
    for it in range(180):
        # try to grow each square
        for i in range(n):
            s = sq[i]
            grow = 1.0 + 0.02 * (1.0 + 0.5 * random.random())
            old = s[3]
            s[3] = min(s[3] * grow, 2.0)
            h = bounds(s)
            # keep inside unit square
            if s[0] - h < 0.0 or s[0] + h > 1.0 or s[1] - h < 0.0 or s[1] + h > 1.0:
                s[3] = old

        # resolve overlaps by pushing apart and shrinking
        moves = [[0.0, 0.0] for _ in range(n)]
        for i in range(n):
            for j in range(i + 1, n):
                a = sq[i]
                b = sq[j]
                ov = overlap(a, b)
                if ov > 1e-12:
                    dx = b[0] - a[0]
                    dy = b[1] - a[1]
                    dist = math.hypot(dx, dy)
                    if dist < 1e-9:
                        ang = random.random() * 2 * math.pi
                        dx, dy = math.cos(ang), math.sin(ang)
                        dist = 1.0
                    ux, uy = dx / dist, dy / dist
                    push = 0.5 * ov + 0.001
                    moves[i][0] -= ux * push
                    moves[i][1] -= uy * push
                    moves[j][0] += ux * push
                    moves[j][1] += uy * push
                    # shrink both slightly
                    a[3] *= 0.995
                    b[3] *= 0.995

        for i in range(n):
            s = sq[i]
            s[0] += moves[i][0]
            s[1] += moves[i][1]
            h = bounds(s)
            if s[0] - h < 0.0:
                s[0] = h
            if s[0] + h > 1.0:
                s[0] = 1.0 - h
            if s[1] - h < 0.0:
                s[1] = h
            if s[1] + h > 1.0:
                s[1] = 1.0 - h

    # final cleanup: enforce validity and pack any remaining overlap
    for _ in range(80):
        bad = False
        for i in range(n):
            for j in range(i + 1, n):
                if overlap(sq[i], sq[j]) > 1e-9:
                    bad = True
                    a = sq[i]
                    b = sq[j]
                    a[3] *= 0.98
                    b[3] *= 0.98
        if not bad:
            break

    # convert, clamp, and return
    res = []
    for s in sq:
        cx = min(1.0, max(0.0, s[0]))
        cy = min(1.0, max(0.0, s[1]))
        ang = s[2] % 1.0
        side = max(0.0, min(1.0, s[3]))
        res.append((cx, cy, ang, side))
    return res
