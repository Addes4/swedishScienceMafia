import math
import random
import time

import numpy as np
from scipy.optimize import minimize

# ---------- geometry helpers ----------

def corners(cx, cy, ang, s):
    a = math.pi * ang
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + c * x - sn * y, cy + sn * x + c * y) for (x, y) in pts]


def axes_of(ang):
    a = math.pi * ang
    c, sn = math.cos(a), math.sin(a)
    return (c, sn), (-sn, c)


def overlap_area_sq(sq1, sq2):
    x1, y1, a1, s1 = sq1
    x2, y2, a2, s2 = sq2
    if s1 <= 1e-18 or s2 <= 1e-18:
        return 0.0
    p1 = corners(x1, y1, a1, s1)
    p2 = corners(x2, y2, a2, s2)
    axes = list(axes_of(a1)) + list(axes_of(a2))
    min_overlap = 1e18
    for ax, ay in axes:
        p1v = [x * ax + y * ay for x, y in p1]
        p2v = [x * ax + y * ay for x, y in p2]
        h1 = (max(p1v) - min(p1v)) * 0.5
        h2 = (max(p2v) - min(p2v)) * 0.5
        d = abs((sum(p1v) / 4.0) - (sum(p2v) / 4.0))
        gap = d - (h1 + h2)
        if gap >= -1e-12:
            return 0.0
        min_overlap = min(min_overlap, -gap)
    return min_overlap


def inside_square(sq, tol=1e-9):
    x, y, a, s = sq
    if s <= 1e-18:
        return True
    for px, py in corners(x, y, a, s):
        if px < -tol or px > 1 + tol or py < -tol or py > 1 + tol:
            return False
    return True


def clip_to_unit(cx, cy, a, s, iters=20):
    """Shrink and move a square to fit inside unit square, minimally."""
    if s <= 1e-18:
        return 0.5, 0.5, 0.0, 0.0
    for _ in range(iters):
        if inside_square((cx, cy, a, s)):
            return cx, cy, a, s
        s *= 0.98
    return 0.5, 0.5, 0.0, 0.0


def total(sol):
    return sum(s for (_, _, _, s) in sol)


# ---------- initial packings ----------

def grid_init(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0) for _ in range(n)]
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def rows_init(n, cols):
    """Fill rows of equal squares."""
    if cols <= 0:
        return grid_init(n)
    side = 1.0 / cols
    rows = math.ceil(n / cols)
    rh = side
    if rows * rh > 1:
        rh = 1.0 / rows
        side = min(side, rh)
    out = []
    for r in range(rows):
        y = (r + 0.5) * rh
        used = 0
        for c in range(cols):
            if len(out) >= n:
                break
            x = (c + 0.5) * side
            out.append((x, y, 0.0, side))
            used += 1
        if used == 0:
            break
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def random_init(n, rng):
    """Random small squares inside unit square."""
    out = []
    for _ in range(n):
        s = rng.uniform(0.0, 0.25)
        cx = rng.uniform(s / 2, 1 - s / 2) if s > 0 else 0.5
        cy = rng.uniform(s / 2, 1 - s / 2) if s > 0 else 0.5
        out.append((cx, cy, rng.random(), s))
    return out


def greedy_strip(n):
    """Greedy: place largest possible squares side by side."""
    out = []
    # place in a grid of cells, each cell gets one square, sizes chosen to fill
    k = int(math.sqrt(n))
    if k == 0:
        return grid_init(n)
    side = 1.0 / k
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, side))
    # simple rows
    out = []
    rows = k
    cols = k
    # rotate alternate rows for better density
    h = 1.0 / rows
    w = 1.0 / cols
    s = min(h, w)
    for r in range(rows):
        for c in range(cols):
            if len(out) >= n:
                break
            x = (c + 0.5) * w
            y = (r + 0.5) * h
            ang = 0.0
            out.append((x, y, ang, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


# ---------- optimization ----------

def build_params(sol):
    """Flatten solution to x = [cx, cy, angle, side] * n."""
    x = []
    for cx, cy, a, s in sol:
        x.extend([cx, cy, a, s])
    return np.array(x, dtype=float)


def unpack(x, n):
    sol = []
    for i in range(n):
        cx, cy, a, s = x[4 * i:4 * i + 4]
        sol.append((cx, cy, a, s))
    return sol


def repar(sol, n):
    """Project solution to satisfy constraints approximately."""
    out = []
    for cx, cy, a, s in sol:
        s = max(0.0, min(s, 1.0))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        # rotate angle into [0,1)
        a = a % 1.0
        # try to fit
        cx, cy, a, s = clip_to_unit(cx, cy, a, s)
        out.append((cx, cy, a, s))
    # resolve overlaps by shrinking smaller square
    for _ in range(3):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                if overlap_area_sq(out[i], out[j]) > 1e-9:
                    si = out[i][3]
                    sj = out[j][3]
                    if si > 0 or sj > 0:
                        # shrink the bigger one
                        if si >= sj:
                            s = si * 0.9
                            out[i] = (out[i][0], out[i][1], out[i][2], s)
                        else:
                            s = sj * 0.9
                            out[j] = (out[j][0], out[j][1], out[j][2], s)
                        changed = True
        if not changed:
            break
    return out


# ---------- objective ----------

class Objective:
    def __init__(self, n, pen_w=10.0):
        self.n = n
        self.pen_w = pen_w

    def __call__(self, x):
        sol = unpack(x, self.n)
        # bounds / sanity
        total_s = 0.0
        pen = 0.0
        for i, (cx, cy, a, s) in enumerate(sol):
            if s < 0:
                s = 0.0
            s = max(0.0, s)
            total_s += s
            # inside penalty
            if s > 1e-15:
                c = corners(cx, cy, a, s)
                for px, py in c:
                    if px < 0:
                        pen += self.pen_w * (0 - px) ** 2
                    if px > 1:
                        pen += self.pen_w * (px - 1) ** 2
                    if py < 0:
                        pen += self.pen_w * (0 - py) ** 2
                    if py > 1:
                        pen += self.pen_w * (py - 1) ** 2
            else:
                if cx < 0 or cx > 1 or cy < 0 or cy > 1:
                    pen += 1.0
        # overlap penalty
        for i in range(self.n):
            for j in range(i + 1, self.n):
                o = overlap_area_sq(sol[i], sol[j])
                if o > 0:
                    pen += self.pen_w * o
        return -total_s + pen


def refine(sol, n, time_limit, rng):
    """Local optimization using scipy."""
    t0 = time.time()
    x = build_params(sol)
    best_x = x.copy()
    best_f = Objective(n)(x)

    # try a few random perturbations and pick the best
    trials = 0
    while time.time() - t0 < time_limit * 0.5:
        trials += 1
        xt = x.copy()
        # perturb
        for i in range(n):
            if rng.random() < 0.3:
                xt[4 * i] += rng.gauss(0, 0.05)
                xt[4 * i + 1] += rng.gauss(0, 0.05)
            if rng.random() < 0.3:
                xt[4 * i + 2] += rng.gauss(0, 0.05)
            if rng.random() < 0.3:
                xt[4 * i + 3] += rng.gauss(0, 0.05)
        xt = np.clip(xt, -0.5, 1.5)
        # project
        solt = repar(unpack(xt, n), n)
        xt = build_params(solt)
        ft = Objective(n)(xt)
        if ft < best_f:
            best_f = ft
            best_x = xt.copy()

    # scipy optimize on best
    obj = Objective(n)
    try:
        res = minimize(obj, best_x, method='Nelder-Mead',
                       options={'maxiter': 2000, 'xatol': 1e-5, 'fatol': 1e-6,
                                'disp': False})
        if res.fun < best_f:
            best_f = res.fun
            best_x = res.x
    except Exception:
        pass

    # L-BFGS-B
    try:
        res = minimize(obj, best_x, method='L-BFGS-B',
                       options={'maxiter': 500, 'ftol': 1e-9})
        if res.fun < best_f:
            best_f = res.fun
            best_x = res.x
    except Exception:
        pass

    # final projection
    sol = repar(unpack(best_x, n), n)
    return sol


def solve(n):
    if n <= 0:
        return []
    rng = random.Random(12345 + n)
    t0 = time.time()
    TIME = 55.0

    # candidates
    candidates = []
    candidates.append(grid_init(n))
    # rows with various column counts
    for c in range(1, n + 1):
        candidates.append(rows_init(n, c))
    candidates.append(greedy_strip(n))
    for _ in range(2):
        candidates.append(random_init(n, rng))

    # evaluate
    best = None
    best_val = -1e18
    for cand in candidates:
        cand = repar(cand, n)
        v = total(cand)
        # apply objective penalty to compare
        f = Objective(n)(build_params(cand))
        if -f > best_val:
            best_val = -f
            best = cand

    # refine best
    try:
        refined = refine(best, n, TIME - (time.time() - t0), rng)
        if total(refined) > total(best):
            best = refined
    except Exception:
        pass

    # final safety: satisfy constraints strictly
    best = repar(best, n)
    # ensure inside, shrink if necessary
    final = []
    for cx, cy, a, s in best:
        s = max(0.0, s)
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        cx, cy, a, s = clip_to_unit(cx, cy, a, s)
        final.append((cx, cy, a, s))
    # shrink overlaps
    for _ in range(5):
        any_over = False
        for i in range(n):
            for j in range(i + 1, n):
                o = overlap_area_sq(final[i], final[j])
                if o > 1e-10:
                    any_over = True
                    si = final[i][3]
                    sj = final[j][3]
                    if si >= sj and si > 0:
                        s = si * 0.95
                        final[i] = (final[i][0], final[i][1], final[i][2], s)
                    elif sj > 0:
                        s = sj * 0.95
                        final[j] = (final[j][0], final[j][1], final[j][2], s)
        if not any_over:
            break

    out = []
    for cx, cy, a, s in final:
        out.append((float(cx), float(cy), float(a), float(s)))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


if __name__ == "__main__":
    for n in [1, 2, 3, 4, 5, 9, 16, 25, 36, 49, 64, 100]:
        t0 = time.time()
        sol = solve(n)
        print(n, sum(s for _, _, _, s in sol), "time", time.time() - t0)
