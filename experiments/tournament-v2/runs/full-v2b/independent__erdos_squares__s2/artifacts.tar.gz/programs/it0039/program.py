import math
import random
import numpy as np
from scipy.optimize import minimize


# ---------- geometry / constraint helpers ----------

def corners(cx, cy, ang, s):
    """Return 4 corners of a square (center, angle in turns, side)."""
    a = ang * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    p = [( h, h), (-h, h), (-h,-h), ( h,-h)]
    out = []
    for x, y in p:
        out.append((cx + x * c - y * sn, cy + x * sn + y * c))
    return out


def _seg_intersect(p1, p2, p3, p4):
    d1x = p2[0]-p1[0]; d1y = p2[1]-p1[1]
    d2x = p4[0]-p3[0]; d2y = p4[1]-p3[1]
    den = d1x*d2y - d1y*d2x
    if abs(den) < 1e-15:
        return False
    t = ((p3[0]-p1[0])*d2y - (p3[1]-p1[1])*d2x)/den
    u = ((p3[0]-p1[0])*d1y - (p3[1]-p1[1])*d1x)/den
    return 1e-12 < t < 1-1e-12 and 1e-12 < u < 1-1e-12


def interiors_overlap(c1, c2, strict=True):
    if c1[3] <= 1e-13 or c2[3] <= 1e-13:
        return False
    # quick AABB reject
    def bbox(c):
        pts = corners(*c)
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        return min(xs), max(xs), min(ys), max(ys)
    x0,x1,y0,y1 = bbox(c1)
    u0,u1,v0,v1 = bbox(c2)
    eps = 1e-12
    if x1 <= u0+eps or u1 <= x0+eps or y1 <= v0+eps or v1 <= y0+eps:
        return False
    # SAT: 4 axes from each square
    def axes(c):
        pts = corners(*c)
        ax = []
        for i in range(4):
            ex = pts[(i+1)%4][0]-pts[i][0]
            ey = pts[(i+1)%4][1]-pts[i][1]
            L = math.hypot(ex, ey)
            ax.append((ex/L, ey/L))
        return ax
    def proj(c, ax):
        pts = corners(*c)
        d = [p[0]*ax[0]+p[1]*ax[1] for p in pts]
        return min(d), max(d)
    for ax in axes(c1)+axes(c2):
        a0,a1 = proj(c1, ax)
        b0,b1 = proj(c2, ax)
        if a1 <= b0 + 1e-11 or b1 <= a0 + 1e-11:
            return False
    return True


def contains(c, eps=1e-9):
    pts = corners(*c)
    for x, y in pts:
        if x < -eps or x > 1+eps or y < -eps or y > 1+eps:
            return False
    return True


def feasible(sols, eps=1e-9):
    n = len(sols)
    for i in range(n):
        if not contains(sols[i], eps):
            return False
    for i in range(n):
        if sols[i][3] <= 1e-12:
            continue
        for j in range(i+1, n):
            if interiors_overlap(sols[i], sols[j]):
                return False
    return True


# ---------- constructive initial layouts ----------

def grid_layout(n):
    k = max(1, math.isqrt(n))
    side = 1.0/k
    sq = [((i+0.5)*side, (j+0.5)*side, 0.0, side)
          for i in range(k) for j in range(k)]
    sq += [(0.5, 0.5, 0.0, 0.0)]*(n-len(sq))
    return sq[:n]


def row_layout(n):
    """Build rows of equal-height squares.  Distribute n among k rows and
    within each row maximize square count that fits.  Rows can have slightly
    different heights to try to fill vertical space."""
    best = None
    best_val = -1
    # choose number of rows r (each row has same height h = 1/r)
    for r in range(1, n+1):
        h = 1.0/r
        # distribute n squares among r rows as evenly as possible
        base = n//r
        rem = n % r
        counts = [base + (1 if i < rem else 0) for i in range(r)]
        if any(c == 0 for c in counts):
            # still allowed: 0-size squares, but a row with 0 squares wastes space;
            # skip when possible
            pass
        # within a row of height h, how many squares of side h fit side by side?
        # floor(1/h) = r of them (equal squares).  If count c <= r, place them.
        sq = []
        ok = True
        y = 0.0
        for i in range(r):
            c = counts[i]
            hy = y + h/2.0
            if c <= r:
                s = h
                # spread evenly
                xs = [(j+0.5)*(1.0/c) for j in range(c)]
                for x in xs:
                    sq.append((x, hy, 0.0, s))
            else:
                # more squares than r: shrink squares so that c of them fit in width 1
                s = min(h, 1.0/c)
                xs = [(j+0.5)/c for j in range(c)]
                for x in xs:
                    sq.append((x, hy, 0.0, s))
            y += h
        if len(sq) < n:
            sq += [(0.5, 0.5, 0.0, 0.0)]*(n-len(sq))
        sq = sq[:n]
        val = sum(s[3] for s in sq)
        if val > best_val and feasible(sq):
            best_val = val
            best = sq
    return best


def improved_row_layout(n):
    """Stack rows where each row height is optimised so a given number of
    squares fills the row completely (side = min(h, 1/c)).  Search over
    partitions of n into row counts."""
    best = None
    best_val = -1

    def eval_counts(counts):
        # counts list = number of squares per row
        # solve for row heights h_i: sum h_i = 1, h_i <= 1/c_i (else width shrinks
        # and height may not be fully used).  Actually side s_i = min(h_i, 1/c_i).
        # To maximize sum c_i * s_i we want s_i as large as possible.
        # Try equal allocation first, then small variations.
        r = len(counts)
        # start: h_i proportional to 1/c_i?  Instead give each row h_i = 1/r.
        for _ in range(1):
            h = [1.0/r]*r
            # shrink rows that can't use that much height? Increase others.
            # simple: s_i = min(h_i, 1/c_i)
            s = [min(h[i], 1.0/counts[i]) for i in range(r)]
            total = sum(counts[i]*s[i] for i in range(r))
            return total, s

    # try base equal splits; also try all rows of roughly equal squares
    # Search over r rows and ways to split n
    candidates = []
    for r in range(1, n+1):
        base = n//r
        if base == 0:
            continue
        rem = n % r
        counts = [base+(1 if i < rem else 0) for i in range(r)]
        candidates.append(counts)
        # some alternative distributions
        if base > 1:
            counts2 = [base]*r
            counts2[0] += n - base*r
            if all(c > 0 for c in counts2):
                candidates.append(counts2)

    for counts in candidates:
        total, s = eval_counts(counts)
        if total <= best_val:
            continue
        # build layout with these heights
        r = len(counts)
        # height allocation: give each row h_i = s_i where s_i = min.. => use uniform first
        # then refine by solving small LP-ish
        h = [1.0/r]*r
        # fix heights for rows limited by 1/c
        lim = [1.0/counts[i] for i in range(r)]
        # rows with lim < 1/r must be clamped; redistribute leftover
        for _ in range(50):
            over = sum(max(0.0, h[i]-lim[i]) for i in range(r))
            if over < 1e-12:
                break
            h = [min(h[i], lim[i]) for i in range(r)]
            free = [i for i in range(r) if h[i] < lim[i]-1e-15]
            if not free:
                break
            for i in free:
                h[i] += over/len(free)
        # normalize
        tot = sum(h)
        h = [x/tot for x in h]
        sq = []
        y = 0.0
        for i in range(r):
            c = counts[i]
            hi = h[i]
            side = min(hi, 1.0/c)
            hy = y + hi/2.0
            for j in range(c):
                x = (j+0.5)/c
                sq.append((x, hy, 0.0, side))
            y += hi
        if len(sq) < n:
            sq += [(0.5, 0.5, 0.0, 0.0)]*(n-len(sq))
        sq = sq[:n]
        if feasible(sq):
            val = sum(s[3] for s in sq)
            if val > best_val:
                best_val = val
                best = sq
    return best


def best_constructive(n):
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0)]*n if n == 1 else []
    layouts = [grid_layout(n), row_layout(n), improved_row_layout(n)]
    best = None
    bv = -1
    for L in layouts:
        if L and len(L) == n and feasible(L):
            v = sum(s[3] for s in L)
            if v > bv:
                bv = v
                best = L
    return best


# ---------- local optimization ----------

def pack_var(sols, iters=200):
    """Random hill climbing: perturb one square at a time."""
    n = len(sols)
    cur = [list(s) for s in sols]
    cur_val = sum(s[3] for s in cur)
    best = [list(s) for s in cur]
    best_val = cur_val

    def try_update(idx, newc):
        old = cur[idx]
        if not contains(newc):
            return False
        for j in range(n):
            if j == idx:
                continue
            if interiors_overlap(newc, cur[j]):
                return False
        cur[idx] = newc
        return True

    temp = [0.05]*n
    for it in range(iters):
        idx = random.randrange(n)
        old = cur[idx]
        scale = 0.03 * (1.0 - it/iters*0.7)
        # propose: shift, rotate, or resize
        mode = random.random()
        cx, cy, ang, s = old
        if mode < 0.4:
            # resize up
            ns = min(s + scale*random.random(), 1.0)
            nc = (cx, cy, ang, ns)
        elif mode < 0.7:
            nc = (cx + (random.random()-0.5)*scale*2,
                  cy + (random.random()-0.5)*scale*2, ang, s)
        elif mode < 0.85:
            nc = (cx, cy, ang + (random.random()-0.5)*scale*2, s)
        else:
            nc = (cx + (random.random()-0.5)*scale,
                  cy + (random.random()-0.5)*scale,
                  ang + (random.random()-0.5)*scale, s)
        if try_update(idx, nc):
            v = sum(x[3] for x in cur)
            if v > best_val - 1e-12:
                pass
            if not feasible(cur):
                cur[idx] = old
            else:
                if v > best_val + 1e-12:
                    best_val = v
                    best = [list(x) for x in cur]
    return best, best_val


def continuous_opt(sols, maxiter=150):
    """Use scipy minimize (SLSQP) on the side lengths with fixed centers/angles
    maybe.  Instead use a simple coordinate ascent on sizes."""
    n = len(sols)
    cur = [list(s) for s in sols]

    for _ in range(3):
        improved = False
        for i in range(n):
            old = cur[i][:]
            # try to increase size of square i
            lo, hi = old[3], 1.0
            # binary search
            for _ in range(40):
                mid = (lo+hi)/2
                cand = [old[0], old[1], old[2], mid]
                if contains(cand) and all(
                        not interiors_overlap(cand, cur[j]) for j in range(n) if j != i):
                    lo = mid
                else:
                    hi = mid
            if lo > old[3] + 1e-7:
                cur[i] = [old[0], old[1], old[2], lo]
                improved = True
        if not improved:
            break
    return cur, sum(s[3] for s in cur)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = best_constructive(n)
    if best is None:
        best = grid_layout(n)
    best_val = sum(s[3] for s in best)

    # For small/medium n, try local optimization from a few starts.
    budget = 1 if n > 60 else (3 if n > 20 else 6)
    random.seed(12345 + n)
    for attempt in range(budget):
        if attempt == 0:
            start = [list(s) for s in best]
        else:
            start = [list(s) for s in best]
            # random perturbation of angles and positions
            for k in range(n):
                if start[k][3] > 1e-6:
                    start[k][0] += (random.random()-0.5)*0.05
                    start[k][1] += (random.random()-0.5)*0.05
                    start[k][2] += (random.random()-0.5)*0.2
                    start[k][0] = min(max(start[k][0], 0.0), 1.0)
                    start[k][1] = min(max(start[k][1], 0.0), 1.0)
            if not feasible(start):
                continue

        # local coordinate-ascent on sides
        cur, val = continuous_opt(start)
        # hill climb perturb
        cur2, val2 = pack_var(cur, iters=300 if n <= 40 else 120)
        if val2 > best_val:
            best_val = val2
            best = cur2

    # final size cleanup: snap tiny sizes to 0, ensure valid
    out = []
    for s in best:
        cx, cy, ang, side = s
        if side < 1e-9:
            out.append((0.5, 0.5, 0.0, 0.0))
        else:
            # clamp inside
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
            ang = ang % 1.0
            out.append((cx, cy, ang, side))
    # ensure feasible; if not, fall back to constructive
    if not feasible(out, eps=1e-7):
        out = best_constructive(n) or grid_layout(n)
        if not feasible(out, eps=1e-7):
            out = grid_layout(n)
    return out[:n]
