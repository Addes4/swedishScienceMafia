# EVOLVE-BLOCK-START
"""Hybrid square packing: recursive guillotine initialisation plus local optimisation."""
import math
import random
import numpy as np
from scipy.optimize import minimize


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _rotated_corners(cx, cy, angle, side):
    """Return the four corners of a possibly rotated square."""
    h = side * 0.5
    ca = math.cos(2.0 * math.pi * angle)
    sa = math.sin(2.0 * math.pi * angle)
    base = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + ca * x - sa * y, cy + sa * x + ca * y) for x, y in base]


def _overlap(a, b):
    """True if two squares overlap with positive area (separating-axis theorem)."""
    ca = _rotated_corners(*a)
    cb = _rotated_corners(*b)
    for poly in (ca, cb):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            nx, ny = -(y2 - y1), (x2 - x1)
            len_n = math.hypot(nx, ny)
            if len_n < 1e-15:
                continue
            nx /= len_n
            ny /= len_n
            pa = [nx * x + ny * y for x, y in ca]
            pb = [nx * x + ny * y for x, y in cb]
            if max(pa) <= min(pb) + 1e-12 or max(pb) <= min(pa) + 1e-12:
                return False
    return True


def _inside(cx, cy, angle, side):
    """True if the square lies inside the unit square."""
    if side < 0:
        return False
    for x, y in _rotated_corners(cx, cy, angle, side):
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


def _valid(sqs):
    """Check all squares: inside unit square and pairwise interior-disjoint."""
    m = len(sqs)
    for i in range(m):
        if not _inside(*sqs[i]):
            return False
    for i in range(m):
        for j in range(i + 1, m):
            if sqs[i][3] > 0 and sqs[j][3] > 0 and _overlap(sqs[i], sqs[j]):
                return False
    return True


# ---------------------------------------------------------------------------
# Initial packing: recursive guillotine subdivision
# ---------------------------------------------------------------------------

def _greedy_split(x, y, w, h, angle, out, target):
    """Recursively fill the axis-aligned rectangle [x,x+w]x[y,y+h] with up to
    `target` squares, allowing the whole rectangle to be covered by one rotated
    square when beneficial."""
    if target <= 0:
        return
    # area available
    area = w * h
    # Try one square covering the fraction of the rectangle
    if target == 1:
        side = min(w, h)
        out.append((x + w * 0.5, y + h * 0.5, 0.0, side))
        return

    # Split the rectangle
    if w >= h:
        # vertical split
        frac = 0.5
        best_frac = 0.5
        best_score = -1.0
        for k in range(1, 20):
            f = k / 20.0
            left_n = max(1, int(round(target * f)))
            if left_n >= target:
                left_n = target - 1
            right_n = target - left_n
            if right_n < 1:
                continue
            s = f * (1 - f)
            if s > best_score:
                best_score = s
                best_frac = f
        left_n = max(1, int(round(target * best_frac)))
        if left_n >= target:
            left_n = target - 1
        right_n = target - left_n
        _greedy_split(x, y, w * best_frac, h, angle, out, left_n)
        _greedy_split(x + w * best_frac, y, w * (1 - best_frac), h, angle, out, right_n)
    else:
        frac = 0.5
        best_frac = 0.5
        best_score = -1.0
        for k in range(1, 20):
            f = k / 20.0
            bot_n = max(1, int(round(target * f)))
            if bot_n >= target:
                bot_n = target - 1
            top_n = target - bot_n
            if top_n < 1:
                continue
            s = f * (1 - f)
            if s > best_score:
                best_score = s
                best_frac = f
        bot_n = max(1, int(round(target * best_frac)))
        if bot_n >= target:
            bot_n = target - 1
        top_n = target - bot_n
        _greedy_split(x, y, w, h * best_frac, angle, out, bot_n)
        _greedy_split(x, y + h * best_frac, w, h * (1 - best_frac), angle, out, top_n)


def _grid_initial(n, k):
    side = 1.0 / k
    return [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(k) for j in range(k)]


def _initial_packing(n):
    """Return an initial valid configuration of n squares."""
    if n == 0:
        return []
    # perfect / near-perfect square grid
    k = math.isqrt(n)
    if k * k == n:
        return _grid_initial(n, k)

    best = None
    best_sum = -1.0

    # try grid with m rows/cols and remainder, and also recursive subdivision
    for m in range(1, n + 1):
        for rows in range(1, n // m + 2):
            cols = m
            total = rows * cols
            if total > n:
                break
            # place total grid squares with side = min(1/rows, 1/cols)
            side = min(1.0 / rows, 1.0 / cols)
            sqs = []
            for i in range(cols):
                for j in range(rows):
                    sqs.append(((i + 0.5) * (1.0 / cols),
                                (j + 0.5) * (1.0 / rows),
                                0.0, side))
            rem = n - total
            sqs += [(0.5, 0.5, 0.0, 0.0)] * rem
            s = sum(q[3] for q in sqs)
            if s > best_sum and _valid(sqs):
                best_sum = s
                best = sqs

    # recursive quadtree/guillotine
    for _ in range(30):
        out = []
        _greedy_split(0.0, 0.0, 1.0, 1.0, 0.0, out, n)
        if len(out) > n:
            out = out[:n]
            while len(out) < n:
                out.append((0.5, 0.5, 0.0, 0.0))
        if len(out) == n and _valid(out):
            s = sum(q[3] for q in sqs)
            if s > best_sum:
                best_sum = s
                best = out

    if best is None:
        # fallback grid
        k = math.isqrt(n)
        best = _grid_initial(n, k) + [(0.5, 0.5, 0.0, 0.0)] * (n - k * k)
    return best


# ---------------------------------------------------------------------------
# Local optimisation
# ---------------------------------------------------------------------------

def _penalty(sqs, n):
    """Penalty for overlaps and boundary violations."""
    pen = 0.0
    for i in range(n):
        cx, cy, ang, sd = sqs[i]
        if sd <= 0:
            continue
        for x, y in _rotated_corners(cx, cy, ang, sd):
            if x < 0:
                pen += -x * 10.0
            elif x > 1.0:
                pen += (x - 1.0) * 10.0
            if y < 0:
                pen += -y * 10.0
            elif y > 1.0:
                pen += (y - 1.0) * 10.0
    for i in range(n):
        if sqs[i][3] <= 0:
            continue
        for j in range(i + 1, n):
            if sqs[j][3] <= 0:
                continue
            if _overlap(sqs[i], sqs[j]):
                # approximate overlap amount by corner penetration
                ca = _rotated_corners(*sqs[i])
                cb = _rotated_corners(*sqs[j])
                for px, py in ca:
                    if _point_in_poly(px, py, cb):
                        pen += 20.0
                for px, py in cb:
                    if _point_in_poly(px, py, ca):
                        pen += 20.0
    return pen


def _point_in_poly(px, py, poly):
    inside = False
    j = 3
    for i in range(4):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if ((yi > py) != (yj > py)) and \
           (px < (xj - xi) * (py - yi) / (yj - yi + 1e-30) + xi):
            inside = not inside
        j = i
    return inside


def _objective(params, n, base):
    """Objective: negative sum of sides + penalty."""
    sqs = []
    for i in range(n):
        cx = params[3 * i]
        cy = params[3 * i + 1]
        sd = params[3 * i + 2]
        ang = base[i][2]
        sqs.append((cx, cy, ang, sd))
    total = sum(q[3] for q in sqs)
    return -total + _penalty(sqs, n)


def _repair(sqs, n):
    """Repair an invalid configuration by shrinking overlapping squares."""
    sqs = [list(q) for q in sqs]
    for _ in range(200):
        changed = False
        for i in range(n):
            if sqs[i][3] <= 0:
                continue
            for x, y in _rotated_corners(*sqs[i]):
                if x < 1e-9 or x > 1.0 - 1e-9 or y < 1e-9 or y > 1.0 - 1e-9:
                    sqs[i][3] *= 0.98
                    changed = True
                    break
        for i in range(n):
            if sqs[i][3] <= 0:
                continue
            for j in range(i + 1, n):
                if sqs[j][3] <= 0:
                    continue
                if _overlap(sqs[i], sqs[j]):
                    sqs[i][3] *= 0.97
                    sqs[j][3] *= 0.97
                    changed = True
        if not changed:
            break
    return [tuple(q) for q in sqs]


def _optimise(sqs, n, iterations=80):
    """Coordinate-descent / pattern search on (cx, cy, side) for each square."""
    sqs = [list(q) for q in sqs]
    step_pos = 0.02
    step_side = 0.015
    best_score = sum(q[3] for q in sqs)
    for it in range(iterations):
        improved = False
        for i in range(n):
            if sqs[i][3] <= 0:
                continue
            for dim in range(3):
                old = sqs[i][dim]
                for delta in (step_pos if dim < 2 else step_side,
                              -step_pos if dim < 2 else step_side):
                    trial = [list(q) for q in sqs]
                    trial[i][dim] = old + delta
                    trial = _repair(trial, n)
                    if _valid(trial):
                        sc = sum(q[3] for q in trial)
                        if sc > best_score + 1e-12:
                            best_score = sc
                            sqs = trial
                            improved = True
        if improved:
            step_pos = min(step_pos * 1.05, 0.05)
            step_side = min(step_side * 1.05, 0.04)
        else:
            step_pos *= 0.7
            step_side *= 0.7
            if step_pos < 1e-5 and step_side < 1e-5:
                break
    return [tuple(q) for q in sqs]


# ---------------------------------------------------------------------------
# Main solve
# ---------------------------------------------------------------------------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = _initial_packing(n)
    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    best = [tuple(q) for q in best]
    best_sum = sum(q[3] for q in best)

    # multi-start local search
    random.seed(12345)
    for trial in range(6):
        cand = [list(q) for q in best]
        # random perturbation
        for i in range(n):
            cand[i][0] += random.uniform(-0.03, 0.03)
            cand[i][1] += random.uniform(-0.03, 0.03)
            cand[i][3] *= random.uniform(0.9, 1.1)
            cand[i][0] = min(max(cand[i][0], 0.0), 1.0)
            cand[i][1] = min(max(cand[i][1], 0.0), 1.0)
            cand[i][3] = max(cand[i][3], 0.0)
        cand = _repair(cand, n)
        cand = _optimise(cand, n, iterations=60)
        s = sum(q[3] for q in cand)
        if _valid(cand) and s > best_sum:
            best_sum = s
            best = cand

    # final polish
    best = _optimise(best, n, iterations=120)
    if not _valid(best):
        best = _repair(best, n)
    # ensure size-zero squares for safety
    best = list(best[:n])
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    # clamp
    out = []
    for q in best:
        cx, cy, ang, sd = q
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = min(max(ang, 0.0), 1.0)
        sd = max(0.0, min(sd, 1.0))
        out.append((cx, cy, ang, sd))
    return out
# EVOLVE-BLOCK-END
