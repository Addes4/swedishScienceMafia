import math
import random
import numpy as np


def _corners(cx, cy, ang, s):
    c = math.cos(2 * math.pi * ang)
    sn = math.sin(2 * math.pi * ang)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _obb_overlap(a, b, eps=1e-12):
    ax, ay, aa, as_ = a
    bx, by, ba, bs = b
    if as_ <= eps or bs <= eps:
        return 0.0
    ca = math.cos(2 * math.pi * aa); sa = math.sin(2 * math.pi * aa)
    cb = math.cos(2 * math.pi * ba); sb = math.sin(2 * math.pi * ba)
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    pa = _corners(ax, ay, aa, as_)
    pb = _corners(bx, by, ba, bs)
    min_ov = 1e9
    for nx, ny in axes:
        axs = [p[0] * nx + p[1] * ny for p in pa]
        bxs = [p[0] * nx + p[1] * ny for p in pb]
        ov = min(max(axs), max(bxs)) - max(min(axs), min(bxs))
        if ov <= 0:
            return 0.0
        min_ov = min(min_ov, ov)
    return min_ov


def _outside_penalty(cx, cy, ang, s):
    if s <= 0:
        return 0.0
    pts = _corners(cx, cy, ang, s)
    pen = 0.0
    for x, y in pts:
        if x < 0:
            pen += -x
        elif x > 1:
            pen += x - 1
        if y < 0:
            pen += -y
        elif y > 1:
            pen += y - 1
    return pen


def _energy(sqs, target):
    e = 0.0
    total = 0.0
    for q in sqs:
        total += q[3]
        e += _outside_penalty(q[0], q[1], q[2], q[3]) * 50.0
    for i in range(len(sqs)):
        for j in range(i + 1, len(sqs)):
            ov = _obb_overlap(sqs[i], sqs[j])
            if ov > 0:
                e += ov * ov * 200.0
    e += -total
    return e


def _grid_init(n):
    if n <= 0:
        return []
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    sqs = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    while len(sqs) < n:
        sqs.append((0.5, 0.5, 0.0, 0.0))
    return sqs[:n]


def _make_init(n):
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    return _grid_init(n)


def _repair(sqs, rng, steps=600):
    rng = random
    sqs = [list(q) for q in sqs]
    n = len(sqs)
    for _ in range(steps):
        i = rng.randrange(n)
        cx, cy, ang, s = sqs[i]
        best = (cx, cy, ang, s)
        best_e = _energy(sqs, 0)
        for _ in range(10):
            scale = 1.0
            ncx = min(0.999, max(0.001, cx + rng.uniform(-0.12, 0.12) * scale))
            ncy = min(0.999, max(0.001, cy + rng.uniform(-0.12, 0.12) * scale))
            nang = (ang + rng.uniform(-0.08, 0.08)) % 1.0
            ns = max(0.0, s + rng.uniform(-0.08, 0.08))
            old = sqs[i]
            sqs[i] = [ncx, ncy, nang, ns]
            e = _energy(sqs, 0)
            if e < best_e:
                best_e = e
                best = (ncx, ncy, nang, ns)
            sqs[i] = old
        sqs[i] = list(best)
    return [tuple(q) for q in sqs]


def _grow(sqs, rng, iters=250):
    sqs = [list(q) for q in sqs]
    n = len(sqs)
    for _ in range(iters):
        i = rng.randrange(n)
        cx, cy, ang, s = sqs[i]
        cands = []
        for dst in (0.05, 0.02, 0.01):
            cands.append([cx, cy, ang, s + dst])
        for dcx, dcy in ((0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01)):
            cands.append([cx + dcx, cy + dcy, ang, s])
        best = None
        best_e = _energy(sqs, 0)
        for c in cands:
            c[0] = min(0.999, max(0.001, c[0]))
            c[1] = min(0.999, max(0.001, c[1]))
            c[3] = max(0.0, c[3])
            if c[3] > 1.0:
                continue
            old = sqs[i]
            sqs[i] = c
            e = _energy(sqs, 0)
            if e < best_e:
                best_e = e
                best = c
            sqs[i] = old
        if best is not None:
            sqs[i] = list(best)
    return [tuple(q) for q in sqs]


def _polish(sqs, rng, iters=150):
    sqs = [list(q) for q in sqs]
    n = len(sqs)
    for _ in range(iters):
        for i in range(n):
            cx, cy, ang, s = sqs[i]
            best = [cx, cy, ang, s]
            best_e = _energy(sqs, 0)
            for _ in range(6):
                ncx = min(0.999, max(0.001, cx + rng.uniform(-0.02, 0.02)))
                ncy = min(0.999, max(0.001, cy + rng.uniform(-0.02, 0.02)))
                nang = (ang + rng.uniform(-0.02, 0.02)) % 1.0
                ns = max(0.0, s + rng.uniform(-0.005, 0.005))
                old = sqs[i]
                sqs[i] = [ncx, ncy, nang, ns]
                e = _energy(sqs, 0)
                if e < best_e:
                    best_e = e
                    best = [ncx, ncy, nang, ns]
                sqs[i] = old
            sqs[i] = best
    return [tuple(q) for q in sqs]


def _clip(sqs):
    out = []
    for cx, cy, ang, s in sqs:
        s = max(0.0, min(1.0, s))
        ang = ang % 1.0
        pts = _corners(cx, cy, ang, s)
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        minx, maxx = min(xs), max(xs)
        miny, maxy = min(ys), max(ys)
        if minx < 0:
            cx -= minx
        if maxx > 1:
            cx -= (maxx - 1)
        if miny < 0:
            cy -= miny
        if maxy > 1:
            cy -= (maxy - 1)
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        # shrink if still outside
        for _ in range(20):
            pts = _corners(cx, cy, ang, s)
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            mnx, mxx = min(xs), max(xs)
            mny, mxy = min(ys), max(ys)
            if mnx >= -1e-9 and mxx <= 1 + 1e-9 and mny >= -1e-9 and mxy <= 1 + 1e-9:
                break
            s *= 0.98
            if s <= 0:
                s = 0.0
                break
        out.append((cx, cy, ang % 1.0, max(0.0, s)))
    return out


def solve(n):
    if n <= 0:
        return []
    if n > 40:
        return _grid_init(n)
    rng = random.Random(12345 + n)

    candidates = []
    candidates.append(_make_init(n))
    # add a couple randomized starts
    for _ in range(2):
        base = _make_init(n)
        base = [list(q) for q in base]
        for q in base:
            q[0] = min(0.999, max(0.001, q[0] + rng.uniform(-0.05, 0.05)))
            q[1] = min(0.999, max(0.001, q[1] + rng.uniform(-0.05, 0.05)))
            q[2] = (q[2] + rng.uniform(-0.1, 0.1)) % 1.0
        candidates.append([tuple(q) for q in base])

    best = None
    best_score = -1.0
    for cand in candidates:
        sqs = [tuple(q) for q in cand]
        for _ in range(3):
            sqs = _repair(sqs, rng, 250)
            sqs = _grow(sqs, rng, 150)
            sqs = _polish(sqs, rng, 60)
        sqs = _clip(sqs)
        # final repair without clipping drift
        sqs = _polish(sqs, rng, 80)
        sqs = _clip(sqs)
        score = sum(q[3] for q in sqs)
        # verify no gross overlaps; shrink if needed
        changed = True
        guard = 0
        while changed and guard < 50:
            changed = False
            guard += 1
            for i in range(len(sqs)):
                for j in range(i + 1, len(sqs)):
                    ov = _obb_overlap(sqs[i], sqs[j])
                    if ov > 1e-7:
                        a = list(sqs[i]); b = list(sqs[j])
                        a[3] *= 0.97
                        b[3] *= 0.97
                        sqs[i] = tuple(a); sqs[j] = tuple(b)
                        changed = True
        sqs = _clip(sqs)
        score = sum(q[3] for q in sqs)
        if score > best_score:
            best_score = score
            best = sqs
    return best
