import math
import random
import numpy as np


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(1234567 + n)

    # Represent each square as [cx, cy, angle, side].
    # angle is a fraction of a full turn.

    def sq_vertices(s):
        cx, cy, a, side = s
        if side <= 0.0:
            return [(cx, cy), (cx, cy), (cx, cy), (cx, cy)]
        th = 2.0 * math.pi * a
        c = math.cos(th)
        si = math.sin(th)
        h = side * 0.5
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x = cx + dx * c - dy * si
            y = cy + dx * si + dy * c
            pts.append((x, y))
        return pts

    def inside_unit(s, eps=1e-12):
        cx, cy, a, side = s
        if side <= 0.0:
            return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
        pts = sq_vertices(s)
        for x, y in pts:
            if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
                return False
        return True

    def proj_inside(s):
        cx, cy, a, side = s
        if side <= 0.0:
            return [min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a, 0.0]
        # Binary search scale/translation is too expensive; instead clamp center after checking.
        # Simple safe fallback: shrink uniformly until inside.
        res = [cx, cy, a, side]
        for _ in range(60):
            if inside_unit(res):
                return res
            res[3] *= 0.995
        # also clamp center
        res[0] = min(1.0, max(0.0, res[0]))
        res[1] = min(1.0, max(0.0, res[1]))
        return res

    def axes(s):
        a = s[2]
        th = 2.0 * math.pi * a
        c = math.cos(th)
        si = math.sin(th)
        return (c, si), (-si, c)

    def interval_on_axis(s, axis):
        cx, cy, a, side = s
        if side <= 0.0:
            return (0.0, -1.0)  # empty
        ux, uy = axis
        ax, ay = axes(s)
        (u1x, u1y), (u2x, u2y) = ax
        h = side * 0.5
        vals = []
        for sg1 in (-1.0, 1.0):
            for sg2 in (-1.0, 1.0):
                x = cx + sg1 * h * u1x + sg2 * h * u2x
                y = cy + sg1 * h * u1y + sg2 * h * u2y
                vals.append(x * ux + y * uy)
        return (min(vals), max(vals))

    def overlap_interior(s1, s2, eps=1e-12):
        # Separating axis theorem for convex polygons.
        if s1[3] <= 1e-15 or s2[3] <= 1e-15:
            return False
        p1 = sq_vertices(s1)
        p2 = sq_vertices(s2)
        axes_list = []
        for pts in (p1, p2):
            for i in range(4):
                x1, y1 = pts[i]
                x2, y2 = pts[(i + 1) % 4]
                ex, ey = x2 - x1, y2 - y1
                ln = math.hypot(ex, ey)
                if ln > 1e-15:
                    axes_list.append((-ey / ln, ex / ln))
        for ux, uy in axes_list:
            min1 = min(x * ux + y * uy for x, y in p1)
            max1 = max(x * ux + y * uy for x, y in p1)
            min2 = min(x * ux + y * uy for x, y in p2)
            max2 = max(x * ux + y * uy for x, y in p2)
            if max1 <= min2 + eps or max2 <= min1 + eps:
                return False
        return True

    def valid(squares):
        for s in squares:
            if not inside_unit(s):
                return False
        m = len(squares)
        for i in range(m):
            for j in range(i + 1, m):
                if overlap_interior(squares[i], squares[j]):
                    return False
        return True

    # ---------- initialization ----------

    def grid_init(n):
        k = int(math.floor(math.sqrt(n)))
        while k * k > n:
            k -= 1
        side = 1.0 / k
        squares = []
        for i in range(k):
            for j in range(k):
                squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
        return squares

    def guillotine_init(n):
        # recursively split rectangles with square-ish pieces.
        # We produce n squares via a simple slicing scheme.
        rects = [(0.0, 0.0, 1.0, 1.0, n)]
        squares = []
        # Use a priority queue by area to split.
        import heapq
        # We'll just do a deterministic recursive split that tries to equalize side sums.
        def split_rect(x, y, w, h, cnt):
            if cnt <= 0:
                return
            if cnt == 1:
                s = min(w, h)
                if s <= 0:
                    squares.append([x + w * 0.5, y + h * 0.5, 0.0, 0.0])
                else:
                    squares.append([x + w * 0.5, y + h * 0.5, 0.0, s])
                return
            # try split along longer dimension to create room for squares.
            # Split cnt into left/right proportional to sqrt or area.
            if w >= h:
                # vertical cut
                # choose cnt1 such that widths proportional maybe
                best = None
                for cnt1 in range(1, cnt):
                    cnt2 = cnt - cnt1
                    # estimated max square sides
                    w1 = w * (cnt1 / cnt)
                    w2 = w * (cnt2 / cnt)
                    val = min(w1, h) * cnt1 + min(w2, h) * cnt2
                    if best is None or val > best[0]:
                        best = (val, cnt1)
                cnt1 = best[1]
                cnt2 = cnt - cnt1
                w1 = w * (cnt1 / cnt)
                w2 = w - w1
                split_rect(x, y, w1, h, cnt1)
                split_rect(x + w1, y, w2, h, cnt2)
            else:
                best = None
                for cnt1 in range(1, cnt):
                    cnt2 = cnt - cnt1
                    h1 = h * (cnt1 / cnt)
                    h2 = h * (cnt2 / cnt)
                    val = min(w, h1) * cnt1 + min(w, h2) * cnt2
                    if best is None or val > best[0]:
                        best = (val, cnt1)
                cnt1 = best[1]
                cnt2 = cnt - cnt1
                h1 = h * (cnt1 / cnt)
                h2 = h - h1
                split_rect(x, y, w, h1, cnt1)
                split_rect(x, y + h1, w, h2, cnt2)
        split_rect(0.0, 0.0, 1.0, 1.0, n)
        return squares

    # Choose initialization. For small n, guillotine is often better.
    candidates = []
    if n <= 200:
        candidates.append(grid_init(n))
    candidates.append(guillotine_init(n))
    # Also randomized guillotine-ish variants
    for _ in range(10 if n <= 100 else 3):
        # use grid then random local improvements later
        candidates.append(grid_init(n))

    best = None
    best_sum = -1.0
    for cand in candidates:
        cand = [proj_inside(s) for s in cand]
        if valid(cand):
            sm = sum(s[3] for s in cand)
            if sm > best_sum:
                best_sum = sm
                best = [s[:] for s in cand]

    if best is None:
        # fallback: points only
        best = [[0.5, 0.5, 0.0, 0.0] for _ in range(n)]
        best_sum = 0.0

    # ---------- local search ----------
    # Try to improve by moving/resizing/rotating individual squares, and pairwise adjustments.
    squares = [s[:] for s in best]
    total_sum = best_sum

    def recompute_sum(sq):
        return sum(s[3] for s in sq)

    def make_move(sq, i, rng, stage):
        s = sq[i][:]
        old = s[:]
        # pick a move type
        if stage < 0.5:
            # position move
            if rng.random() < 0.5:
                s[0] += rng.gauss(0, 0.05)
            else:
                s[1] += rng.gauss(0, 0.05)
            s[0] = min(1.0, max(0.0, s[0]))
            s[1] = min(1.0, max(0.0, s[1]))
        else:
            r = rng.random()
            if r < 0.4:
                # side change
                s[3] *= math.exp(rng.gauss(0, 0.15))
                s[3] = max(0.0, min(1.0, s[3]))
            elif r < 0.7:
                # angle change
                s[2] = (s[2] + rng.gauss(0, 0.05)) % 1.0
            else:
                # position + side
                s[0] += rng.gauss(0, 0.03)
                s[1] += rng.gauss(0, 0.03)
                s[3] *= math.exp(rng.gauss(0, 0.1))
                s[0] = min(1.0, max(0.0, s[0]))
                s[1] = min(1.0, max(0.0, s[1]))
                s[3] = max(0.0, min(1.0, s[3]))
        return s

    # We do many random trials with validity checks.
    # To reduce cost, use spatial reasoning? Keep simple for now.
    import time
    t0 = time.time()
    time_limit = 45.0

    def local_optimize(squares, rng, time_limit):
        sq = [s[:] for s in squares]
        cur_sum = sum(s[3] for s in sq)
        improved = True
        it = 0
        while time.time() - t0 < time_limit:
            it += 1
            if it % 2000 == 0:
                # restart from current best with perturbation if stuck
                pass
            i = rng.randrange(len(sq))
            old_s = sq[i][:]
            old_val = old_s[3]
            new_s = make_move(sq, i, rng, rng.random())
            new_s = proj_inside(new_s)
            sq[i] = new_s
            # check validity for this square only against others
            ok = inside_unit(new_s)
            if ok:
                for j in range(len(sq)):
                    if j == i:
                        continue
                    if overlap_interior(new_s, sq[j]):
                        ok = False
                        break
            if ok:
                delta = new_s[3] - old_val
                if delta >= -1e-12:
                    cur_sum += delta
                else:
                    # accept sometimes
                    if rng.random() < math.exp(delta * 10.0):
                        cur_sum += delta
                    else:
                        sq[i] = old_s
            else:
                sq[i] = old_s
        return sq, cur_sum

    squares, total_sum = local_optimize(squares, rng, time_limit)

    # Try a global improvement: for each square, try to enlarge until blocked.
    # This can be done via binary search on side length while keeping center/angle.
    def enlarge_square(sq, i):
        # Try to grow square i as much as possible by moving it slightly and growing.
        s = sq[i]
        if s[3] <= 0:
            # place somewhere
            best_s = None
            best_val = -1
            for _ in range(30):
                cx = rng.random()
                cy = rng.random()
                a = rng.random()
                side = 0.01
                cand = [cx, cy, a, side]
                cand = proj_inside(cand)
                if inside_unit(cand) and all(not overlap_interior(cand, sq[j]) for j in range(len(sq)) if j != i):
                    if cand[3] > best_val:
                        best_val = cand[3]
                        best_s = cand
            if best_s is not None:
                sq[i] = best_s
            return
        # try to grow
        lo, hi = s[3], 1.0
        best = s[:]
        # binary search on side with small random perturbations
        for _ in range(20):
            mid = (lo + hi) * 0.5
            # try several random positions/angles
            for _ in range(5):
                cand = s[:]
                cand[3] = mid
                if rng.random() < 0.5:
                    cand[0] += rng.gauss(0, 0.01)
                if rng.random() < 0.5:
                    cand[1] += rng.gauss(0, 0.01)
                if rng.random() < 0.3:
                    cand[2] = (cand[2] + rng.gauss(0, 0.02)) % 1.0
                cand = proj_inside(cand)
                if inside_unit(cand) and all(not overlap_interior(cand, sq[j]) for j in range(len(sq)) if j != i):
                    if cand[3] > best[3]:
                        best = cand[:]
                        lo = cand[3]
                    break
            else:
                hi = mid
        sq[i] = best

    # Run enlarge a few times
    for _ in range(3):
        for i in range(n):
            enlarge_square(squares, i)

    # Final validity check and output
    for i in range(n):
        squares[i] = proj_inside(squares[i])
        if not inside_unit(squares[i]):
            # shrink
            s = squares[i]
            for _ in range(100):
                if inside_unit(s):
                    break
                s[3] *= 0.99
            squares[i] = s

    # Remove any overlaps by shrinking problematic squares
    changed = True
    while changed:
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                if overlap_interior(squares[i], squares[j]):
                    # shrink both slightly
                    squares[i][3] *= 0.95
                    squares[j][3] *= 0.95
                    changed = True

    # Ensure inside
    for i in range(n):
        squares[i] = proj_inside(squares[i])

    # Final check: if invalid, fallback to grid
    if not valid(squares):
        k = int(math.floor(math.sqrt(n)))
        while k * k > n:
            k -= 1
        side = 1.0 / k
        squares = []
        for i in range(k):
            for j in range(k):
                squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
        while len(squares) < n:
            squares.append([0.5, 0.5, 0.0, 0.0])

    # clip all values
    res = []
    for s in squares[:n]:
        cx = min(1.0, max(0.0, s[0]))
        cy = min(1.0, max(0.0, s[1]))
        a = s[2] % 1.0
        side = min(1.0, max(0.0, s[3]))
        res.append((cx, cy, a, side))
    return res
