"""Static size-frequency residual-value bin packing rule."""
import numpy as np

# Precompute a static model of typical future item sizes on the 1..100 range.
# The distribution is Weibull-shaped with mean about 40.
_rng = np.random.default_rng(0)
_sample = _rng.weibull(shape=2.0, size=200000) * 55.0
_sample = np.clip(np.round(_sample).astype(int), 1, 100)

# Frequency of each item size, and a smoothed "chance an item of exactly size s appears".
_freq = np.bincount(_sample, minlength=101).astype(float)
_freq /= _freq.sum()

# Convex residual-value curve: residual r is more valuable if it matches common item sizes.
# value(r) = sum_s freq[s] * (1 if s == r else small) ~ reward exact matches heavily.
SIZE = np.arange(101)

def _build_value():
    # For each possible residual r (1..100), value = probability that a future item fits
    # exactly into r plus a small bonus for larger residuals (more room to maneuver).
    v = np.zeros(101)
    # exact-match reward
    v[1:101] = _freq[1:101] * 100.0
    # slightly convex bonus scaled by fill probability: bigger residual can hold bigger items
    for r in range(1, 101):
        fits = _freq[1:r + 1].sum()          # prob. a random item fits in residual r
        big = _freq[r:101].sum()             # prob. item at least as big as residual
        v[r] += 2.0 * fits + 1.0 * big
    return v

_VALUE = _build_value()

# Precompute for every item size and every possible bin residual (0..100) the score.
# Placing item in a bin with residual b leaves residual b - item; score that residual.
_SCORE = np.zeros((101, 101))  # [item, residual]
for it in range(1, 101):
    for b in range(it, 101):
        _SCORE[it, b] = _VALUE[b - it]
    for b in range(0, it):
        _SCORE[it, b] = -1e9  # item doesn't fit (harness never shows these)


def priority(item, bins):
    """Score each bin by the value of the residual it would leave."""
    item = int(item)
    if item < 1:
        item = 1
    if item > 100:
        item = 100
    return _SCORE[item][bins]
