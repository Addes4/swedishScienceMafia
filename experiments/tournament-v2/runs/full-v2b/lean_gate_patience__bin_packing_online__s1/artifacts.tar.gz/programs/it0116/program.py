# EVOLVE-BLOCK-START
"""Best-fit bin choice with exact-fit reinforcement.

Place the arriving item into the fitting bin with the smallest remaining
capacity (tightest fit).  Additionally, when some fitting bin would be filled
exactly (residual 0), strongly prefer it, since closing a bin at zero
residual can never hurt and often lets the packer finish a bin early.
"""
import numpy as np


def priority(item, bins):
    """Score each bin by the negative residual it would leave.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every fitting bin (numpy int64, bin order).
    """
    residual = bins - item
    # Best-fit: prefer the smallest residual (tightest fit).
    # Extra bonus (negative residual) for an exact fill (residual == 0).
    score = -residual.astype(np.float64)
    score[residual == 0] -= 1e6
    return score
# EVOLVE-BLOCK-END
