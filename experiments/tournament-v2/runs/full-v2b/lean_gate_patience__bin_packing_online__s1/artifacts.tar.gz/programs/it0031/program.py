# EVOLVE-BLOCK-START
"""Best-fit packing rule with an online learned residual-value bonus.

The dominant term is classic best-fit: place the item into the bin with the
smallest non-negative residual (score ~ 1/(residual+1)).  A light secondary
term uses an online histogram of the item sizes seen so far to mildly reward
placements whose leftover residual matches a typical future item size, which
reduces fragmentation.  The secondary weight is small so best-fit dominates
and the rule stays robust.
"""
import numpy as np

# Running histogram of item sizes seen so far (index 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0

# Weight of the learned residual-value term relative to the best-fit term.
_W = 0.35


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    global _COUNT
    r = bins - item  # residual capacity if placed in each bin (>= 0 by contract)

    # Classic best-fit term: tightest residual wins.
    scores = 1.0 / (r + 1.0)

    # Learned expected-value term: reward residuals that match a common future
    # item size (so the leftover space is likely to be useful again).
    if _COUNT > 0.0:
        weights = _HIST / _COUNT
        # Value of a residual: probability that some typical future item fits
        # snugly, aggregated over sizes.
        vals = np.zeros_like(r, dtype=np.float64)
        for s in range(1, 101):
            w = weights[s]
            if w > 0.0:
                # reward residuals near s (snug future fit)
                vals += w * np.exp(-((r - s) ** 2) / (2.0 * 20.0 * 20.0))
        # Normalize to a comparable scale then apply small weight.
        maxv = vals.max()
        if maxv > 0.0:
            vals = vals / maxv
        scores = scores + _W * vals

    # Mild preference for already-open (less empty) bins.
    scores = scores - 0.0001 * bins

    # Update statistics with the current item.
    _HIST[item] += 1.0
    _COUNT += 1.0

    return scores
# EVOLVE-BLOCK-END
