# EVOLVE-BLOCK-START
"""Best-fit with an adaptive residual-value tie-break.

Pure best-fit (smallest positive post-placement residual) scores ~0.9616 and is
hard to beat.  Here we keep best-fit as the PRIMARY key but break near-ties
using a data-driven value of the leftover residual: we maintain an online
histogram of item sizes and estimate, for each candidate residual, the expected
number of future items it can still absorb.  Bins whose leftover is more likely
to be exactly/ tightly refilled are preferred, which slightly reduces
fragmentation without ever overriding a clearly-better fit.
"""
import numpy as np

_CAP = 100
# Online item-size histogram (index 0..100).
_counts = np.zeros(_CAP + 1, dtype=np.float64)
_total = 0.0

# Lagged probability estimate used to value a residual.
def _pmf():
    if _total <= 0:
        # fall back to a flat/uniform prior over 1..100
        p = np.ones(_CAP + 1, dtype=np.float64)
        p[0] = 0.0
        return p / p.sum()
    p = _counts.copy()
    p[0] = 0.0
    s = p.sum()
    if s <= 0:
        p = np.ones(_CAP + 1, dtype=np.float64)
        p[0] = 0.0
        return p / p.sum()
    return p / s

# Precompute a static value function G(r): expected number of future items that a
# fresh residual r can absorb under a greedy expected model.  Rebuilt lazily.
_G = np.zeros(_CAP + 1, dtype=np.float64)
_G_built_total = -1.0

def _build_G():
    p = _pmf()
    g = np.zeros(_CAP + 1, dtype=np.float64)
    for r in range(1, _CAP + 1):
        if r == 0:
            continue
        # expected continuation: pick best expected value over item size <= r
        sizes = np.arange(1, r + 1)
        ps = p[1 : r + 1]
        mass = ps.sum()
        if mass <= 1e-12:
            g[r] = 0.0
            continue
        cont = float((ps * g[r - sizes]).sum()) / mass
        g[r] = (1.0 + cont) * mass
    return g


def priority(item, bins):
    global _total, _G, _G_built_total
    # Update statistics AFTER reading current item (allowed; no future info).
    _counts[item] += 1.0
    _total += 1.0

    residual = (bins - item).astype(np.int64)
    np.clip(residual, 0, _CAP, out=residual)

    # Rebuild the value function occasionally as the histogram learns.
    if _total - _G_built_total >= 50.0 or _G_built_total < 0.0:
        _G = _build_G()
        _G_built_total = _total

    # Primary key: smallest residual (best fit).  Secondary key: higher expected
    # absorbable future items (value of the leftover).  Scale the secondary term
    # small so it only breaks near-ties.
    best = int(residual.min())

    # Among bins within a tiny window of the best fit, prefer the more "valuable"
    # leftover; otherwise pure best-fit dominates.
    window = 2
    mask = residual <= best + window
    idx = np.nonzero(mask)[0]

    # Compute scores: strongly penalize larger residual, then reward value.
    # Larger residual => lower score (best-fit bias).  Value term is bounded so
    # it never flips a gap of more than ~0.5 residual units of preference.
    res_sel = residual[idx]
    val_sel = _G[res_sel]
    # best-fit dominant term
    score_sel = -res_sel.astype(np.float64) + 0.15 * val_sel

    # Everything outside the window gets a very low score.
    out = np.full(len(residual), -1e9, dtype=np.float64)
    out[idx] = score_sel
    return out
# EVOLVE-BLOCK-END
