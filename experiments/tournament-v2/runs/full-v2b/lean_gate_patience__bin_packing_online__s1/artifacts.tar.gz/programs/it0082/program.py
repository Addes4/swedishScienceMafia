# EVOLVE-BLOCK-START
"""Best-fit bin choice with a size-aware tie-break.

Primary rule: minimize post-placement residual (classical Best-Fit).
This dominates pure residual-value variants on this distribution.
Tie-break: among bins achieving the same minimal post-placement residual
(common because empty bins and many equal residuals collide), use a small,
strictly-subordinate epsilon term.  For most items we keep ties resolved by
bin index (harness default).  For large items we slightly prefer the bin with
the larger pre-placement capacity so that small residual gaps left by big
items are not packed into nearly-full bins, preserving tight bins for future
small fillers.

score = -(post residual) + eps * f(item) * (pre residual - post residual)
where f(item) is 0 for small items (leave pure best-fit) and grows for larger
items so the tie-break only matters when residual ties occur.
"""
import numpy as np


def priority(item, bins):
    """Highest score wins; primary = tightest fit, small large-item tie-break."""
    bins = np.asarray(bins)
    residual = bins - item                      # >= 0 guaranteed by harness
    score = -residual.astype(np.float64)

    # eps is tiny enough that it never overrides a 1-unit difference in
    # post-placement residual, only breaks exact ties.
    if item >= 50:
        eps = 1e-4
        # pre-placement capacity is 'bins'; larger means emptier/bin more room.
        score = score + eps * bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

