# EVOLVE-BLOCK-START
"""Best-fit bin packing with an exact-fill tie-break.

The strongest rule for this online problem is best-fit: place the item into the
bin leaving the smallest post-placement residual.  We keep that as the primary
criterion (weight 1), and add a tiny secondary term that rewards an *exact fill*
(bin whose pre-placement residual equals the item, i.e. leftover 0), which
strictly improves packing when several bins achieve the same minimal residual.
"""
import numpy as np


def priority(item, bins):
    bins = np.asarray(bins)
    residual = bins - item                       # post-placement residual (>=0)
    # Primary criterion: minimize residual (tightest fit).  Smaller residual ->
    # larger score.
    score = -residual.astype(np.float64)
    # Secondary: an exact fill (residual == 0) is a strictly good outcome; give it
    # a small extra nudge so exact fits win their ties.  Magnitude is tiny so it
    # never overrides the primary best-fit ordering.
    score += 1e-6 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
