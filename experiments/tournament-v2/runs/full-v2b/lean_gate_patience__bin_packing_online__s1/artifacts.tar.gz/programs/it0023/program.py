# EVOLVE-BLOCK-START
"""Best-fit bin packing: place each item into the fitting bin that leaves the
smallest non-negative residual capacity, with a mild tie-break preferring
already-open bins over fresh (empty) ones to avoid opening new bins early."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (all >= item), bin order.
    """
    residual = bins - item
    # Best-fit: prefer smaller residual after placement.
    scores = 1.0 / (residual + 1.0)
    # Mild bonus for reusing already-open bins (lower remaining capacity means
    # the bin is not empty), so fresh bins are chosen only when the fit is
    # comparable. Empty bins have capacity 100.
    scores = scores - 1e-6 * bins
    return scores
# EVOLVE-BLOCK-END
