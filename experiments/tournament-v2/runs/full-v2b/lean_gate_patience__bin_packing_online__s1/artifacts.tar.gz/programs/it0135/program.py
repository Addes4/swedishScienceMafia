# EVOLVE-BLOCK-START
"""Adaptive residual-value bin choice.

Idea: maintain an online estimate of the item-size distribution as a smoothed
histogram.  From that distribution derive a value function V(r) that measures
how much useful future packing capacity a residual of size r represents.
Rank each bin by the value of the residual it would leave after placement,
blended with a tightest-fit term.  The value function adapts as items arrive.
"""
import numpy as np

# ---------------------------------------------------------------------------
# Module-level online state
# ---------------------------------------------------------------------------
_CAP = 100

# smoothed histogram of item sizes, index 1..100 (0 unused)
_hist = np.ones(_CAP + 1, dtype=np.float64)
_hist[0] = 0.0
_hist_sum = float(_hist.sum())

# cached value table V[r] for residual capacity r = 0..100
_V = None
_V_dirty = True

_alpha = 0.02        # smoothing factor for the online histogram
_refresh_every = 25  # recompute value table every this many calls
_calls = 0


def _build_value_table():
    """Build V[r]: expected future fillability of a residual capacity r.

    Approach: dynamic-programming style recursion.  For residual r, the
    expected "useful fill" contributed by a future item that fits is the
    average item size weighted by probability, plus the value of the residual
    left afterwards, discounted so larger residuals are not over-credited.
    """
    p = _hist.copy()
    s = p.sum()
    if s <= 0:
        p = np.ones(_CAP + 1, dtype=np.float64)
        p[0] = 0.0
        s = p.sum()
    p = p / s  # probability mass over sizes 1..100

    V = np.zeros(_CAP + 1, dtype=np.float64)

    # expected item size conditional on it fitting, per residual r, computed
    # incrementally.  We iterate residuals upward; a convex-ish reward grows
    # with r but saturates, and leftover value is discounted.
    sizes = np.arange(1, _CAP + 1, dtype=np.float64)
    for r in range(1, _CAP + 1):
        # items that fit in residual r
        upper = min(r, _CAP)
        probs = p[1:upper + 1]
        pfit = probs.sum()
        if pfit <= 1e-12:
            V[r] = V[r - 1]
            continue
        w = sizes[:upper]
        # expected size of a fitting item
        avg_size = float(np.dot(w, probs)) / pfit
        # probability that at least one future item fits (uses pfit as proxy)
        # future residual after placing a typical fitting item
        r_next = max(0.0, r - avg_size)
        # value of leftover, discounted to reflect consumption of capacity
        discount = 0.60
        V[r] = pfit * (avg_size + discount * V[int(round(r_next))]) \
               + (1.0 - pfit) * V[r - 1]
    return V


def _ensure_table():
    global _V, _V_dirty, _calls
    _calls += 1
    if _V is None or (_V_dirty and (_calls % _refresh_every == 0)):
        _V = _build_value_table()
        _V_dirty = False


def priority(item, bins):
    """Score bins by adaptive residual value plus tightest-fit tie-break."""
    global _hist, _hist_sum, _V_dirty

    # --- update online size histogram with the observed item -----------------
    # exponential smoothing towards this observation
    _hist *= (1.0 - _alpha)
    _hist[item] += _alpha * _CAP
    _hist_sum = float(_hist.sum())
    _V_dirty = True

    _ensure_table()
    V = _V

    residual_after = bins - item
    # clip to valid range
    np.clip(residual_after, 0, _CAP, out=residual_after)

    # value of residual left after placing the item here
    val = V[residual_after]

    # tightest-fit tie-break: prefer smaller resulting residual
    tight = -residual_after.astype(np.float64) * 1e-3

    # slight preference for larger remaining capacity (spread load) is avoided;
    # we want tight packing so we favour small residuals through `tight`.
    return val + tight
# EVOLVE-BLOCK-END
