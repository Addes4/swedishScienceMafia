# EVOLVE-BLOCK-START
"""Near-best-fit with a reusable-residual tie-break.

Primary rule: restrict to bins whose post-placement residual is within a small
window of the minimum residual (near-best-fit), so we still pack tightly but gain
freedom to pick a bin whose leftover capacity is likely reusable.
Within that band: prefer the residual that equals a common upcoming item size
(from a static Weibull-shaped histogram, mean ~40), so the leftover bin can be
filled exactly by a likely future item. Then prefer the least-full bin.
"""
import numpy as np
from math import gamma

_SIZE = 101
_WINDOW = 2  # allow residual up to min+2

def _build_probs():
    k = 2.0
    mean = 40.0
    scale = mean / gamma(1.0 + 1.0 / k)
    sizes = np.arange(1, _SIZE)
    pdf = (k / scale) * (sizes / scale) ** (k - 1.0) * np.exp(-(sizes / scale) ** k)
    pdf = np.clip(pdf, 0.0, None)
    s = pdf.sum()
    if s <= 0:
        pdf = np.ones_like(pdf)
        s = pdf.sum()
    return pdf / s

_PROB = _build_probs()

# Weight for residuals 0..100: how likely that residual exactly matches an item size.
_MATCH = np.zeros(_SIZE, dtype=np.float64)
_MATCH[1:100] = _PROB[0:99]
_MATCH[0] = _MATCH.max() if _MATCH.max() > 0 else 1.0

def priority(item, bins):
    b = np.asarray(bins, dtype=np.int64)
    residual = b - item
    resid_f = residual.astype(np.float64)
    min_res = resid_f.min()
    # Near-best-fit band: only bins within _WINDOW of the minimum residual are eligible.
    in_band = resid_f <= min_res + _WINDOW
    # Within the band, prefer reusable residuals; outside band gets strong penalty.
    match = _MATCH[np.clip(residual, 0, _SIZE - 1)]
    score = np.where(in_band, match, -1e9)
    # Tie-break within band: least-full bins first (larger pre-placement capacity).
    score = score + 1e-6 * b
    return score
# EVOLVE-BLOCK-END


