# EVOLVE-BLOCK-START
"""Best-fit bin choice.

Place the arriving item into the fitting bin with the smallest remaining
capacity (tightest fit), i.e. leave the smallest possible residual.  This
classic online rule is near-optimal for this Weibull-shaped size
distribution and dominates the residual-value heuristics empirically.
"""
import numpy as np


def priority(item, bins):
    """Score each bin by the negative residual it would leave.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every fitting bin (numpy int64, bin order).
    """
    # Best-fit: prefer the smallest residual (tightest fit).  Ties fall to
    # the first bin because we never add a tie-breaking perturbation.
    return -(bins - item)
# EVOLVE-BLOCK-END

