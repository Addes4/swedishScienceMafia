"""Adaptive priced-fill bin packing rule.

We maintain a learned "value" of each possible residual capacity, represented as a
piecewise-linear convex function V(r) whose slopes are adaptive prices p_k on 10-unit
capacity buckets.  Each arriving item is ducked into the bin maximizing the gain
V(residual_after) - V(residual_before) plus a small tightest-fit tie-break.  After
placing the item we nudge the prices so that the chosen bucket's leftover space is
discounted (it was partially consumed) and near-full space is rewarded, which mirrors
subgradient ascent on an amortized fill objective.
"""
import numpy as np

# --- piecewise-linear value function over residual capacity 0..100 ------------
# slopes per 10-unit bucket [90..100], [80..90], ..., [0..10]
_STEP = 10
_NB = 101  # residual values 0..100
_V = np.zeros(_NB, dtype=np.float64)

# adaptive prices: slope of V on bucket b (b = r // 10, 0..10)
# start from a mild concave (diminishing) value so tight fits win slightly.
_prices = np.array([0.02 * b + 0.10 for b in range(11)], dtype=np.float64)

# smoothed empirical size histogram (1..100)
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0

_alpha = 0.02  # learning rate for prices
_decay = 0.9995


def _build_V():
    """Rebuild V from prices: V(0)=0, integrate slopes bucket by bucket."""
    # slope on (r-1, r] equals price of bucket containing r
    global _V
    r = np.arange(_NB)
    b = r // _STEP
    b = np.minimum(b, 10)
    # value by cumulative sum of per-unit slopes from 0 up to r
    inc = _prices[b]
    inc[0] = 0.0
    _V = np.cumsum(inc)
    # keep V(0)=0
    _V -= _V[0]


def _rebuild():
    _build_V()


_rebuild()


def priority(item, bins):
    """Rank bins by adaptive priced-fill gain from placing `item`."""
    global _total

    b = np.asarray(bins, dtype=np.int64)
    n = b.shape[0]

    after = b - item

    # gain in fill value from consuming the item's space
    # (V(b) - V(after)): larger when the leftover residual is "cheap"
    va = _V[b]
    vb = _V[after]
    gain = va - vb

    # tightest fit tie-break: prefer smaller residual after placement
    tie = -after.astype(np.float64) * 1e-3

    scores = gain + tie

    # --- pick best bin (for the state update we mirror the harness choice) ---
    choice = int(np.argmax(scores))
    chosen_before = int(b[choice])
    chosen_after = int(after[choice])

    # --- online price update ---------------------------------------------------
    # smooth histogram
    _total = _total * _decay + 1.0
    _counts[item] = _counts[item] * _decay + 1.0

    # Subgradient idea: the bucket we just landed in (chosen_after) is now scarcer,
    # so raise its price (discourage re-filling exactly there and encourage packing
    # items whose sizes better line up); low buckets get relatively cheaper.
    bucket_after = min(chosen_after // _STEP, 10)
    # reward fill near the top (small residual => high value density)
    target = 1.0 - chosen_after / 100.0  # in [0,1], higher when tighter
    _prices[bucket_after] += _alpha * target

    # gently renormalize so prices stay bounded
    _prices *= 0.9999
    _prices[:] = np.clip(_prices, 0.0, 5.0)

    _rebuild()

    return scores
