# EVOLVE-BLOCK-START
"""Best-fit bin choice.

Items are placed into the bin that leaves the smallest post-placement residual
(tightest fit), i.e. minimize (remaining_capacity - item).  Ties go to the
first such bin, which the harness handles for us by picking the highest score
with first-index tie-breaking.  This online rule tracks (and often beats) the
classical Best-Fit heuristic and empirically achieves ~0.96 on this
distribution.
"""
import numpy as np


def priority(item, bins):
    """Highest score wins; score = -(post-placement residual)."""
    bins = np.asarray(bins)
    residual = bins - item                      # >= 0 guaranteed by harness
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
