# EVOLVE-BLOCK-START
"""Best-fit with unfillable-residual (waste) avoidance.

Primary rule: best fit (smallest non-negative post-placement residual),
which is the strongest known rule for this distribution.  When the best
post-placement residual is nonzero we additionally break near-ties by
preferring the placement that does not strand an unfillable residual:
any residual smaller than the smallest item size observed so far can
essentially never be filled again, so it is wasted capacity.  Among bins
whose residual is within a small tolerance of the minimum we therefore
prefer the one minimizing that permanent waste.
"""
import numpy as np

# smallest item size seen so far (used as a fillability threshold)
_MIN_SEEN = [100]


def priority(item, bins):
    it = int(item)
    if it < _MIN_SEEN[0]:
        _MIN_SEEN[0] = it
    mn = _MIN_SEEN[0]

    residual = bins.astype(np.int64) - it  # >= 0 for bins the item fits

    # Permanent waste of a placement: residual leftover that can never be
    # used again because it is smaller than any possible future item.
    waste = np.where(residual < mn, residual, 0)

    # Dominant key: best fit (smallest residual).
    # Tie-break (scaled small): least permanent waste, then largest capacity.
    score = (-residual.astype(np.float64)) * 1e6 - waste.astype(np.float64) * 1e3 \
        + bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
