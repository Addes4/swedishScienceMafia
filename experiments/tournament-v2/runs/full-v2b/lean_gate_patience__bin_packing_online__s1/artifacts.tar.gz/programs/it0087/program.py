# EVOLVE-BLOCK-START
"""Best-fit with an adaptive, empirically-learned residual-quality tie-break.

Pure best-fit (minimize the post-placement residual) is the dominant rule for
this online bin-packing problem.  Ties for the minimal residual are frequent
(especially the many empty bins, all leaving residual 100).  We break those ties
using an online estimate of the item-size distribution: a residual is "good" if
it is small and, more importantly, if it is a size that newly arriving items can
fill exactly or nearly exactly.

Concretely we keep a small histogram of observed item sizes updated online and
add a tiny tie-break bonus equal to the empirical CDF mass of residuals at or
below the candidate residual (a proxy for "fillable").  The bonus is scaled far
below 1 so it can only ever affect exact ties in the best-fit residual.
"""
import numpy as np

# 101 slots for sizes 1..100 (index = size).
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0

# Precomputed smoothed "fillability" weight: reward leaving a residual that is a
# common item size (so a future item can plug it exactly), penalize odd gaps.
_SIZES = np.arange(101, dtype=np.float64)


def _fillability(residual):
    """Empirical probability that a future item is <= residual (rough credit)."""
    if _TOTAL <= 0.0:
        return 0.0
    r = int(residual)
    if r < 1:
        return 1.0            # zero leftover: perfectly packed, best case
    if r > 100:
        return 0.0
    return float(_HIST[1:r + 1].sum()) / _TOTAL


def priority(item, bins):
    global _TOTAL
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)   # post-placement residual, >=0

    # Primary: strict best-fit (minimize residual).
    score = -residual

    # Tiny secondary tie-break: among equal residuals, prefer the residual that
    # is most likely to be filled by future items (small, common sizes).
    hist_before = _HIST
    total_before = _TOTAL
    # Vectorized fillability using current (pre-update) histogram.
    if total_before > 0.0:
        cdf = np.concatenate(([0.0], np.cumsum(hist_before)))[:101]  # cdf[r]=mass<=r
        r_idx = np.clip(residual.astype(np.int64), 0, 100)
        fill = cdf[r_idx]
        fill = np.where(residual == 0, 1.0, fill)
        fill = np.where(residual > 100, 0.0, fill)
        score = score + 1e-3 * fill

    # Update the online histogram with the current item.
    _HIST[item] += 1.0
    _TOTAL += 1.0

    return score
# EVOLVE-BLOCK-END
