# EVOLVE-BLOCK-START
"""Best-fit bin choice rule with tightest-bin tie-break.

Plain best-fit minimizes the post-placement residual. Among bins leaving the
same residual, prefer the one with the smallest pre-placement capacity (the
"most full" bin), which keeps fragmented bins from lingering and tends to use
fewer bins overall.
"""
import numpy as np


def priority(item, bins):
    """Score each bin: best-fit, ties to the most-full bin.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (bins the item fits in).

    Returns a numpy array of scores (higher is better), same length, no NaN.
    """
    resid = bins - item  # residual after placing item (>= 0 for shown bins)

    # Primary: best fit -> smaller residual scores higher.
    # Secondary: among equal residuals, smaller pre-placement capacity wins.
    scores = -resid.astype(np.float64) - bins.astype(np.float64) / 1000.0

    return scores
# EVOLVE-BLOCK-END
