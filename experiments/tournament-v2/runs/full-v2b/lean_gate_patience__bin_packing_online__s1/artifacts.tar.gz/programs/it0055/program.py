# EVOLVE-BLOCK-START
"""Best-fit with a learned reusable-residual tie-break.

Primary rule: pure best-fit (smallest residual capacity that still fits),
which is the strongest online rule for this distribution.

Tie-break: among bins with the same post-placement residual, prefer the bin
whose new residual equals a size that has actually been observed (from a
running histogram of past item sizes), since such a hole can be filled
exactly later. Falls back to least-full bin.
"""
import numpy as np


def priority(item, bins):
    b = np.asarray(bins, dtype=np.float64)
    residual = b - item

    # Primary: best-fit -> smaller residual scores higher.
    primary = -residual * 1000.0

    # Secondary: prefer leaving a reusable residual (observed item size).
    # Counts of past item sizes, stored on the function object.
    freq = getattr(priority, "freq", None)
    if freq is None:
        freq = np.zeros(101, dtype=np.float64)
        priority.freq = freq
        priority.total = 1.0

    # Count how many bins leave an exactly-usable residual.
    r_int = residual.astype(np.int64)
    valid = (r_int >= 1) & (r_int <= 100)
    reusable = np.zeros(residual.shape, dtype=np.float64)
    reusable[valid] = freq[r_int[valid]]

    # Small weight so best-fit dominates; leave-zero (closing a bin) is best.
    secondary = reusable
    secondary = np.where(r_int == 0, 1e6, secondary)

    # Tertiary: least-full bin (prefer larger pre-placement capacity).
    tertiary = b

    # Update histogram with the current item.
    freq[item] += 1.0
    priority.total += 1.0

    return primary + secondary + tertiary * 1e-3
# EVOLVE-BLOCK-END
