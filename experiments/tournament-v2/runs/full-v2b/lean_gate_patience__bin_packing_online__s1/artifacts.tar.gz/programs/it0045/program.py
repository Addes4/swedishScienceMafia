# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a reusable-residual tie-breaker.

The dominant signal is best-fit: place the item where the residual capacity
after placement is smallest (tightest fit).  This is the strongest online rule
for minimizing the number of bins.

As a small tie-breaker we keep an online histogram of observed item sizes and
give a tiny bonus to bins whose residual-after-placement equals a frequently
observed item size.  Such a residual leftover is more likely to be exactly
filled by a future item, so the space stays reusable.  The bonus is kept small
so it only resolves near-ties and never overrides best-fit.
"""
import numpy as np

# Online histogram of observed item sizes (1..100), smoothed.
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Score bins by best-fit, with a small reusable-residual tie-breaker."""
    global _TOTAL
    bins = np.asarray(bins, dtype=np.float64)
    residual_after = bins - float(item)

    # Best-fit: strictly decreasing in the residual after placement.
    score = 1.0 / (residual_after + 1.0)

    # Update the online histogram of item sizes (Laplace-smoothed).
    _HIST[item] += 1.0
    _TOTAL += 1.0
    freq = _HIST / (_TOTAL + 100.0)

    # Small tie-breaker: reward residuals matching a common future item size.
    res_int = np.rint(residual_after).astype(np.int64)
    res_valid = (res_int >= 0) & (res_int <= 100)
    bonus = np.zeros_like(score)
    bonus[res_valid] = freq[res_int[res_valid]]

    # Tiny weight so best-fit remains dominant.
    score = score + 1e-4 * bonus

    score = np.nan_to_num(score, nan=-1e18, posinf=1e18, neginf=-1e18)
    return score
# EVOLVE-BLOCK-END
