# EVOLVE-BLOCK-START
"""Best-fit with a value-function tie-breaker.

The empirical evidence: pure best-fit (smallest post-placement residual) is a very strong
online rule for this Weibull-shaped, mean-~40 distribution. A full value function alone
scored slightly worse. So we make best-fit the dominant signal, and use a precomputed
value function only to break *near-ties* among residuals that are almost as tight, steering
those choices toward residuals that are especially reusable for future typical items.
"""
import numpy as np

# Weibull-shaped item pmf over sizes 1..100, mean ~40.
_sizes = np.arange(1, 101)
_k = 1.6
_lam = 45.0
_p = (_k / _lam) * (_sizes / _lam) ** (_k - 1.0) * np.exp(-(_sizes / _lam) ** _k)
_p = np.clip(_p, 1e-9, None)
_p /= _p.sum()

# Value iteration on residuals: V(r) approximates how packable residual r is.
_gamma = 0.98
_V = np.zeros(101, dtype=np.float64)
for _ in range(300):
    newV = np.empty(101, dtype=np.float64)
    for r in range(101):
        acc = 0.0
        for s in range(1, 101):
            rem = r - s
            if rem >= 0:
                acc += _p[s - 1] * _V[rem]
            else:
                acc -= _p[s - 1] * 0.5
        newV[r] = _gamma * acc
    if np.max(np.abs(newV - _V)) < 1e-10:
        _V = newV
        break
    _V = newV
_V = _V - _V.min()


def priority(item, bins):
    """Best-fit dominant, value function as a near-tie breaker."""
    residual = bins - item
    res_clipped = np.clip(residual, 0, 100)
    # Dominant: prefer small residual. Normalize into [0,1) so it dominates tie-breaks.
    best_fit = -res_clipped.astype(np.float64)
    # Small, bounded bonus from the value function to break near-ties.
    tie = _V[res_clipped]
    tie = tie / (tie.max() + 1e-12)
    return best_fit + 0.5 * tie
# EVOLVE-BLOCK-END
