# EVOLVE-BLOCK-START
"""Bounded best-fit: prefer tight residuals, but within a tolerance prefer larger residuals."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    r = int(residual.min())
    # tolerance window: allow slightly larger residuals to avoid stranding tiny gaps
    tol = 1 if r <= 1 else (2 if r <= 5 else 3)
    near = residual <= (r + tol)
    # Among near-best bins, prefer the largest residual (largest remaining capacity),
    # which keeps room open and avoids creating unfillable slivers.
    score = np.where(near, residual.astype(np.float64), -1e9)
    return score
# EVOLVE-BLOCK-END
