# EVOLVE-BLOCK-START
"""Best-fit packing with an online empirical "residual fillability" bonus.

The dominant term is classic best-fit (tightest residual wins).  The secondary
term estimates how *useful* a leftover residual is: given the empirical size
distribution of items seen so far, a residual r can fit roughly
    E[#fittable items] = sum_{s<=r} p(s)
of a future item on average.  Rewarding residuals by this fillability score
prefers leftovers that are likely to be reused, which reduces fragmentation.
"""
import numpy as np

# Running histogram of item sizes seen so far (index 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0
_CUM = np.zeros(101, dtype=np.float64)  # cumulative probabilities by size

# Weight of the learned residual-value term relative to the best-fit term.
_W = 0.30


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    global _COUNT, _CUM
    r = bins - item  # residual capacity if placed in each bin (>= 0 by contract)

    # Classic best-fit term: tightest residual wins.
    scores = 1.0 / (r + 1.0)

    # Learned fillability term: reward residuals that a typical future item
    # can still fit into, using the empirical CDF of past item sizes.
    if _COUNT > 0.0:
        probs = _HIST / _COUNT  # p(s) for s = 1..100
        # Cumulative probability that a future item has size <= r.
        cum = np.concatenate(([0.0], np.cumsum(probs[1:])))  # cum[k] = P(size <= k)
        # For each residual r, expected fraction of future items fittable.
        rr = np.clip(r.astype(np.int64), 0, 100)
        vals = cum[rr]
        scores = scores + _W * vals
        # Small extra reward when the residual exactly equals the current size,
        # encouraging leftover space to be reused by the same item size.
        scores = scores + 0.02 * (r == item)

    # Mild preference for already-open (less empty) bins.
    scores = scores - 0.0001 * bins

    # Update statistics with the current item.
    _HIST[item] += 1.0
    _COUNT += 1.0

    return scores
# EVOLVE-BLOCK-END

