# EVOLVE-BLOCK-START
"""Best-fit with perfect-closure preference.

Primary: pure best-fit (smallest residual that fits) is the strongest simple
online rule for this Weibull distribution. Among equal residuals, prefer the
bin that closes exactly (residual 0), then the least-full bin (largest b),
which avoids stranding many near-full bins with small unusable holes.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of bins the item fits in (numpy int64).
    """
    b = np.asarray(bins, dtype=np.float64)
    residual = b - item
    # Primary: best-fit -> smaller residual scores higher (dominant weight).
    # Secondary: reward exact closure (residual 0) slightly.
    # Tertiary: among equals, prefer least-full bin (larger b).
    closure_bonus = (residual == 0).astype(np.float64)
    return -residual * 1000.0 + closure_bonus * 10.0 + b
# EVOLVE-BLOCK-END
