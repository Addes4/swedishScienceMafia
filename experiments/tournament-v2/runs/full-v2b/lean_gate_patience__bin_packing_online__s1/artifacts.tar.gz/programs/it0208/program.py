# EVOLVE-BLOCK-START
"""Static value-function packing: precompute the Weibull item-size pmf (mean ~40),
build a value function G(r) approximating how much of a residual of size r can be
usefully filled, and score each bin by G(residual after placement) blended with a
tightest-fit term."""
import numpy as np

# ---- Build the item-size pmf (Weibull-shaped, mean ~40) once. ----
def _build_pmf():
    # Discretized Weibull(k, lambda) over integer sizes 1..100 with mean ~40.
    # Mean = lambda * Gamma(1 + 1/k). Try a few shapes to land mean near 40.
    from math import gamma
    best = None
    best_err = 1e9
    for k in np.linspace(1.0, 3.0, 41):
        lam = 40.0 / gamma(1.0 + 1.0 / k)
        xs = np.arange(1, 101, dtype=float)
        # discrete pmf via differences of the continuous CDF
        cdf = 1.0 - np.exp(-((xs / lam) ** k))
        cdf0 = 1.0 - np.exp(-(((xs - 1) / lam) ** k))
        p = cdf - cdf0
        p = np.clip(p, 0.0, None)
        s = p.sum()
        if s <= 0:
            continue
        p = p / s
        m = float((p * xs).sum())
        err = abs(m - 40.0)
        if err < best_err:
            best_err = err
            best = p
    return best

_PMF = _build_pmf()
_SIZES = np.arange(1, 101, dtype=float)

# ---- Value function G(r): expected fraction of residual r that can be filled. ----
# We compute, for each residual r (0..100), the expected "closed amount": given the
# pmf restricted to items <= r, a simple greedy estimate of how much can still be
# packed. Use expected best single-item fill plus recursive expectation.
def _build_value():
    G = np.zeros(101, dtype=float)
    # G[r] = expected amount filled starting from residual r with random items.
    # Approximate with one-step recursion using expected item <= r plus continuation.
    for r in range(1, 101):
        mask = _SIZES <= r
        p = _PMF * mask
        tot = p.sum()
        if tot <= 0:
            G[r] = 0.0
            continue
        p = p / tot
        # expected size of next placed item, weighted by how likely it is <= r
        exp_item = float((p * _SIZES).sum())
        # probability that no item fits (all items > r) -> residual becomes waste
        qfit = tot
        G[r] = qfit * (exp_item + G[np.maximum(r - np.round(exp_item).astype(int), 0)])
    return G

_G = _build_value()


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0


_s = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _s.n += 1
    _s.mean += (item - _s.mean) / _s.n

    residual = bins - item
    residual = np.clip(residual, 0, 100).astype(int)
    val = _G[residual]
    # Blend the fillability value with a tightest-fit tie-breaker so that among
    # equally valuable residuals we prefer the smallest (leaves clean room).
    return val - 1e-3 * residual
# EVOLVE-BLOCK-END

