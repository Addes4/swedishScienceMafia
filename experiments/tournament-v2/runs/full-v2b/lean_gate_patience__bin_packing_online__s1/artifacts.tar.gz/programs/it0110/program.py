import numpy as np


def priority(item, bins):
    """Best-fit with a small complement-pairing tie-break.

    Primary score: negative post-placement residual (tightest fit wins).
    Secondary: a tiny bonus when the residual is a good complement for the
    item (encourages pairing without overriding the dominant best-fit order).
    """
    residual = bins - item
    # Complement bonus: residual near (100 - item) means a similarly-sized
    # partner can later fill the bin exactly. Keep it small so best-fit
    # ordering is preserved for the vast majority of decisions.
    comp = np.abs(residual - (100 - item))
    bonus = 1.0 / (1.0 + comp)
    return -residual.astype(np.float64) + 1e-3 * bonus
