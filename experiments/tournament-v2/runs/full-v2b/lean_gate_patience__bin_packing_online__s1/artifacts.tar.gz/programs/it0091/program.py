# EVOLVE-BLOCK-START
"""Adaptive online pricing rule.

Idea (Lagrangian view of online bin packing):
  * Each bin presents a residual capacity r after the item would be placed.
  * Assign a *price* p[r] to each possible residual level, learned online.
  * Placing an item into a bin changes the stored "potential" of that bin:
        old residual b  ->  new residual b - item
    and we prefer the placement that minimizes the *marginal loss*
        L(b -> b-item) = w(b - item) - w(b),
    where w is a value function over residuals equal to the integral of prices.
  * Prices are updated by an online subgradient/exponential-style rule using the
    observed item sizes: residuals that turn out hard to reuse get a lower price,
    well-usable residuals get a higher price. This self-tunes to the distribution
    (Weibull-shaped, mean ~40) without hard-coding a curve.

Scoring: return (marginal value of the resulting residual) i.e. the benefit of
leaving residual b-item, plus a small tightest-fit tie-break so that near-equal
choices prefer the more exactly fitting bin.

The harness owns the bins; we only rank them. All state is module-level so it
persists between the 5,000 calls of an instance.
"""
import numpy as np

_CAP = 100

# ---------------------------------------------------------------------------
# Learned state
# ---------------------------------------------------------------------------
# We learn a value function V[r] (r = 0..100) : the "worth" of a bin with
# residual capacity r. Score of placing the item in a bin with residual b is
#     V[b - item] + small * (-(b - item))
# V is updated online to reflect how useful residuals proved to be.
_V = None

# Running statistics of observed item sizes (EMA of counts -> histogram).
_hist = np.zeros(_CAP + 1, dtype=np.float64)
_n_obs = 0

# Learning rate / smoothing for the price updates.
_LR = 0.15          # how fast V adapts
_DECAY = 0.999      # decay of value toward 0 (encourages packing tight)

# Blend weight for the pure best-fit tie-break term.
_BF_W = 1e-3


def _init_value():
    """Initial value function: worth of residual r.

    A residual of 0 is worthless (bin is full but usable); a residual of CAP is
    also relatively worthless (completely empty bin kept in reserve); residuals
    in the 'sweet spot' where a typical item (~40) can fill them tightly are
    most valuable. Start from a simple convex-ish prior built from a fixed
    Weibull-like shape so the rule is reasonable even before learning.
    """
    r = np.arange(_CAP + 1, dtype=np.float64)
    # Prior usable-residual curve: high near typical item sizes, low at extremes.
    # Use a smooth Gaussian-ish bump around 40 plus a mild convex base.
    prior = np.exp(-0.5 * ((r - 40.0) / 25.0) ** 2)
    return prior


def _update(observed_item):
    """Online update of the value function from the observed item size.

    Intuition: a residual r is *useful* if it can be exactly completed by an item
    of a size that appears in the stream, and *useless* if it is too small to
    accept typical items. We nudge V toward a target that rewards residuals which
    the just-seen item could fill tightly (r ~ observed_item) and mildly penalizes
    residuals that are too small to fit a typical item.
    """
    global _V, _hist, _n_obs

    _hist[observed_item] += 1.0
    _n_obs += 1

    if _V is None:
        _V = _init_value()

    # Build an empirical "fillability" target from the running histogram:
    # target[r] = probability mass of observed items that fit r, weighted by how
    # tightly they fit (favor near-exact completion).
    h = _hist
    total = h.sum()
    if total <= 0:
        return
    freq = h / total

    r = np.arange(_CAP + 1, dtype=np.float64)
    # Sum over item sizes s <= r of freq[s] * tightness(r, s)
    # tightness = fraction filled = s / r  (1 when exact), plus a bonus for exact.
    # Vectorized via convolution-like accumulation (sizes are 1..100, cheap loop).
    target = np.zeros(_CAP + 1, dtype=np.float64)
    # Only consider sizes with non-negligible mass to keep it fast.
    idx = np.nonzero(freq)[0]
    if idx.size > 0:
        s = idx.astype(np.float64)
        fs = freq[idx]
        # For each residual r >= s: contribution fs * (s/r) and exact bonus.
        for k in range(idx.size):
            sk = idx[k]
            fk = freq[sk]
            # r from sk..CAP
            rr = r[sk:]
            contrib = fk * (float(sk) / np.maximum(rr, 1.0))
            target[sk:] += contrib
            # exact-completion bonus
            target[sk] += 0.25 * fk

    # Normalize target to a comparable scale with V.
    tmax = target.max()
    if tmax > 0:
        target = target / tmax

    # Blend prior/current V toward the empirical target, plus mild decay toward
    # the "convex base" so the rule keeps preferring tight fits over time.
    base = r / _CAP  # mild linear base; leaving large residual slightly ok, but we
                     # weight low residuals up via decay toward tight-fit preference
    _V = (1.0 - _LR) * _V * _DECAY + _LR * target
    # Add a small convex component so V decreases super-linearly toward full.
    _V = _V + 0.02 * (1.0 - base)


def priority(item, bins):
    """Score each candidate bin; the item goes to the highest score (first on ties)."""
    global _V
    if _V is None:
        _V = _init_value()

    # Learn from this arrival (online, no future info used).
    _update(int(item))

    b = bins.astype(np.float64)
    residual_after = b - float(item)          # capacity left if we drop it here
    residual_after = np.clip(residual_after, 0.0, float(_CAP))

    # Marginal value: worth of the resulting residual, plus best-fit tie-break.
    score = _V[residual_after.astype(np.int64)] + _BF_W * (-(b - float(item)))
    return score
# EVOLVE-BLOCK-END
