# EVOLVE-BLOCK-START
"""Best-fit with a learned "fillable gap" tie-break.

Pure best-fit (smallest non-negative residual) is the strongest simple online
rule here.  We keep it strictly dominant, but break ties (and near-ties) using
a running, decayed histogram of item sizes seen so far.  The intuition: after
placing an item, the residual is a "gap" left in that bin; a gap that matches a
size that actually tends to arrive is more likely to be filled later, so we
nudge the ranking toward residuals that are common item sizes.

The histogram is a fixed-size array over integer sizes 1..100, updated with
exponential decay so it adapts to the (fixed) distribution without storing
history.  The bonus is scaled tiny (max ~1) versus the primary residual term
(scaled by 101) so best-fit still dominates whenever residuals differ by >= 1.
"""
import numpy as np

# Size-indexed decayed histogram of item sizes (1..100).  Index 0 unused.
_HIST = np.zeros(101, dtype=np.float64)
_DECAY = 0.9995  # slow decay -> long-memory estimate of the size distribution


def priority(item, bins):
    """Score bins: best-fit primary, fillable-gap tie-break.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    global _HIST
    # Update histogram with the current item before scoring.
    _HIST *= _DECAY
    _HIST[item] += 1.0

    residual = bins - item  # >= 0 for all shown bins

    # Primary key: smaller residual strictly better (dominant weight 101).
    primary = -residual.astype(np.float64) * 101.0

    # Secondary: prefer residuals that are historically common item sizes.
    # residual can be up to 99; clamp into the histogram index range.
    idx = np.clip(residual, 0, 100)
    gap_value = _HIST[idx]

    # Normalize gap_value to ~[0,1] using total mass to keep the scale tiny.
    total = _HIST.sum()
    if total > 0.0:
        gap_value = gap_value / total
    else:
        gap_value = np.zeros_like(gap_value)

    return primary + gap_value
# EVOLVE-BLOCK-END
