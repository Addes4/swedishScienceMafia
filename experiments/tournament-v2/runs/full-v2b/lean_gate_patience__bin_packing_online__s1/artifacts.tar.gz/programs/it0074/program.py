# EVOLVE-BLOCK-START
"""Best-fit bin choice with an adaptive residual-reuse tie-break.

Primary rule: minimize the post-placement residual (classic best-fit), which is the
strongest known rule for this distribution. Ties are common when many empty bins
(residual 100) are present. To break ties, keep a running histogram of the residuals
that have actually been *left behind* by placements, and among tied bins prefer the
one whose post-placement residual class is (a) exactly zero (perfect fill) or (b) the
most frequently reused residual class seen so far. This adapts to the real instance
rather than a guessed Weibull shape.
"""
import numpy as np

_SIZE = 101

# Running counts of residuals produced by prior placements (excluding empty bins).
_RES_COUNT = np.zeros(_SIZE, dtype=np.float64)
_TOTAL = 0.0
# Uniform prior so early ties still resolve sensibly.
_PRIOR = 1.0

def priority(item, bins):
    global _TOTAL
    b = np.asarray(bins, dtype=np.int64)
    residual = b - item
    # Primary: minimize post-placement residual (best / tightest fit).
    primary = -residual.astype(np.float64)

    # Tie-break value for each residual class: how "reusable" it has proven to be.
    reuse = _RES_COUNT / (_TOTAL + _PRIOR * _SIZE)
    reuse = reuse + _PRIOR / (_TOTAL + _PRIOR * _SIZE)
    # Perfect fill always maximally desirable.
    reuse[0] = reuse.max() + 1.0 if reuse.max() > 0 else 1.0

    r = np.clip(residual, 0, _SIZE - 1)
    reuse_term = reuse[r]

    score = primary + 1e-3 * reuse_term + 1e-6 * b
    best = int(np.argmax(score))
    chosen = residual[best]
    if chosen < _SIZE:
        _RES_COUNT[chosen] += 1.0
        _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
