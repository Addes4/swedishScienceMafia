# EVOLVE-BLOCK-START
"""Best-fit with a mild anti-fragmentation preference.

Best-fit (smallest post-placement residual) is the dominant rule, but
strict best-fit can leave many tiny unusable residuals. We add a small
reward proportional to the post-placement residual for already-open bins
so that, when residuals are close, we prefer bins that retain a bit more
room for future items, reducing fragmentation.
"""
import numpy as np


def priority(item, bins):
    """Score each bin by tightness of the post-placement residual."""
    r = bins.astype(np.int64) - item
    score = 1.0 / (r + 1.0)
    # Mild anti-fragmentation bonus for already-open bins with more free space.
    score = score + 0.0005 * np.where(bins >= 100, 0.0, r)
    # Slight penalty for opening fresh (empty) bins.
    score = np.where(bins >= 100, score - 0.001, score)
    return score
# EVOLVE-BLOCK-END

