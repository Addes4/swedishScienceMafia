# EVOLVE-BLOCK-START
"""Residual-value bin ranking.

Idea: instead of choosing the bin that fits the item most tightly, score each
candidate bin by how "valuable" its residual capacity is after the placement.
A residual capacity r is valuable if it is likely to be exactly fillable by
future items. We estimate, from the known item distribution (Weibull-shaped,
mean ~40), a per-residual utility table: the probability that some future item
or small combination of items hits r closely. Tight-fitting is a special case,
but we also strongly reward leaving residuals that match common item sizes.

The table is built once, lazily, from a fixed analytic approximation of the
distribution, so no per-instance tuning is needed. Ranking is O(number of bins)
per call with pure numpy.
"""
import numpy as np

# ---------------------------------------------------------------------------
# Lazily-built residual-utility table.
# ---------------------------------------------------------------------------
_UTIL = None


def _build_util():
    """Build a table util[r] for r in 0..100: value of leaving residual r."""
    # Approximate the item size distribution: Weibull with mean ~40.
    # For a Weibull(k, lam) mean = lam * Gamma(1 + 1/k).  Choose shape k=1.6,
    # then lam = 40 / Gamma(1 + 1/1.6).
    from math import gamma, exp
    k = 1.6
    lam = 40.0 / gamma(1.0 + 1.0 / k)

    sizes = np.arange(1, 101, dtype=np.float64)
    # Weibull pdf, discretized to integer sizes, then normalized.
    pdf = (k / lam) * (sizes / lam) ** (k - 1.0) * np.exp(-(sizes / lam) ** k)
    pdf = np.maximum(pdf, 0.0)
    # Add a small floor so no size is impossible.
    pdf += 1e-6
    prob = pdf / pdf.sum()

    # Utility of residual r: probability mass of items that fit "usefully" plus
    # a bonus for residuals that can be exactly matched, plus ability to host
    # two smaller items.
    util = np.zeros(101, dtype=np.float64)

    # Exact-match / near-match bonus: sum of probabilities of sizes shrinking r
    # to a small leftover, weighted so leaving near-zero waste is good.
    for r in range(101):
        if r == 0:
            util[r] = 0.0
            continue
        # Probability that a single item leaves little waste.
        fit = prob[:r]  # sizes 1..r
        waste = r - np.arange(1, r + 1)
        # Reward small waste strongly (exact fit best).
        single = np.sum(fit * np.exp(-waste / 6.0))
        # Reward residuals that can take a pair of typical items well.
        # Approximate: expected number of typical items that can fit.
        typical = np.sum(np.arange(1, r + 1) * prob[:r])
        pair = 1.0 - np.exp(-(r / 45.0) ** 1.0)
        # Combining: prefer residuals that are neither tiny nor trivially 100.
        util[r] = single + 0.35 * pair * (1.0 if r < 100 else 0.0)
    # A completely full bin (residual 0) is ideal; give it a high constant.
    util[0] = 1.0
    # Unused-bin residual 100 should be gently discouraged vs. good fills.
    util[100] = util[100] * 0.9
    return util


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties)."""
    global _UTIL
    if _UTIL is None:
        _UTIL = _build_util()

    # Residual capacity after placing the item, clipped to [0, 100].
    residual = bins - item
    np.clip(residual, 0, 100, out=residual)

    # Score = utility of the residual we would leave.
    return _UTIL[residual]
# EVOLVE-BLOCK-END
