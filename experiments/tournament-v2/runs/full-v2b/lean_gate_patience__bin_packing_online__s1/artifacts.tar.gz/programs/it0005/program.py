# EVOLVE-BLOCK-START
"""Scaled best fit: prioritize by post-placement residual with a mild nonlinearity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Slightly favor tighter fits but compress the scale so near-ties are treated alike.
    return -np.sqrt(residual.astype(np.float64))
# EVOLVE-BLOCK-END

