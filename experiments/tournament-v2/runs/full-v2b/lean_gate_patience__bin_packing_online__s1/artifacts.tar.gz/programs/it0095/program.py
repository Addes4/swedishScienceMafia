# EVOLVE-BLOCK-START
"""Best-fit online bin packing with an adaptive refill-score tie-break.

Best-fit (choose the bin leaving the smallest non-negative residual) is
near-optimal on this Weibull-shaped size distribution. The remaining gap to the
lower bound comes from bins whose residual can never be refilled exactly, so a
little capacity is wasted. We keep best-fit dominant, but among bins whose
resulting residual is within a small window of the best, we break the tie by
preferring residuals that match a "common future item size", estimated online
from the observed item-size histogram (smoothed). This nudges the packing toward
residuals a later item is likely to fill exactly.
"""
import numpy as np

# Online histogram of item sizes 1..100 (smoothed), used to score residuals.
_hist = np.zeros(101, dtype=np.float64)
_count = 0


def priority(item, bins):
    """Score each candidate bin; highest score wins, ties to the first bin."""
    global _count
    b = np.asarray(bins, dtype=np.float64)
    residual = b - float(item)

    # Base: best-fit => smallest residual gets highest score.
    score = -residual

    # Adaptive refill bonus: prefer residuals likely to be refilled exactly.
    # Update the empirical histogram with the current item first.
    if 1 <= item <= 100:
        _hist[item] += 1.0
    _count += 1

    # Smoothed probability that a future item equals a given residual size.
    total = _hist.sum()
    if total > 0:
        prob = _hist / total
        # Kernel-smooth the histogram a little so nearby residual sizes share
        # credit; residual sizes are integers 0..100.
        kern = np.array([0.25, 0.5, 0.25])
        smooth = np.convolve(prob, kern, mode="same")
        # Weight the bonus small so best-fit ordering stays dominant.
        weight = 0.02
        r = residual.astype(np.int64)
        r = np.clip(r, 0, 100)
        score = score + weight * smooth[r]

    return score
# EVOLVE-BLOCK-END
