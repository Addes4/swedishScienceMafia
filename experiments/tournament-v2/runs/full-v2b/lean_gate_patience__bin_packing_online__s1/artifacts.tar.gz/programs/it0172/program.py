# EVOLVE-BLOCK-START
"""Classic best-fit with an emptiest-bin tie-break.

Among all bins the item fits in, place it in the one with the smallest residual
capacity after placement (best fit), which preserves large free spaces and packs
densely.  Exact ties on the post-placement residual are broken by choosing the bin
with the largest pre-placement remaining capacity (the emptiest fitting bin), which
delays the opening of new bins.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item                          # residual if item placed here
    # best fit: smallest post-placement residual first;
    # tie-break: largest pre-placement capacity (emptiest bin) first.
    score = -residual.astype(np.float64) * 1e6 - bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

