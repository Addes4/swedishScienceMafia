# EVOLVE-BLOCK-START
"""Residual-value bin ranking with multiple-of-mean bonus.

Idea: score each candidate bin by how "valuable" its residual capacity is after
the placement. We combine three signals:
  1. exact/near-exact single item fit (avoid waste),
  2. whether the residual aligns with typical item sizes or their multiples
     (so future items can fill it efficiently),
  3. mild preference against leaving a barely-used fresh bin.

Ranking is O(number of bins) with pure numpy, using a precomputed table.
"""
import numpy as np

_UTIL = None


def _build_util():
    """Build util[r] for r in 0..100: value of leaving residual r."""
    from math import gamma
    k = 1.6
    lam = 40.0 / gamma(1.0 + 1.0 / k)

    sizes = np.arange(1, 101, dtype=np.float64)
    pdf = (k / lam) * (sizes / lam) ** (k - 1.0) * np.exp(-(sizes / lam) ** k)
    pdf = np.maximum(pdf, 0.0) + 1e-6
    prob = pdf / pdf.sum()

    util = np.zeros(101, dtype=np.float64)
    for r in range(101):
        if r == 0:
            util[r] = 1.0
            continue
        fit = prob[:r]
        waste = r - np.arange(1, r + 1)
        # Signal 1: reward small waste on a single-item fill.
        single = np.sum(fit * np.exp(-waste / 6.0))
        # Signal 2: reward residuals close to typical item sizes and their
        # multiples (mean ~40), likely fillable by future items.
        if r < 100:
            m = r / 40.0
            mult = np.exp(-(m - round(m)) ** 2 / 0.15)
            pair = 1.0 - np.exp(-(r / 45.0))
        else:
            mult = 0.9
            pair = 1.0
        util[r] = single + 0.35 * pair * mult
    util[100] = util[100] * 0.9
    return util


def priority(item, bins):
    global _UTIL
    if _UTIL is None:
        _UTIL = _build_util()
    residual = bins - item
    np.clip(residual, 0, 100, out=residual)
    return _UTIL[residual]
# EVOLVE-BLOCK-END
