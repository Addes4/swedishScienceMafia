# EVOLVE-BLOCK-START
"""Static size-frequency residual-value bin choice.

We build, once at import time, a Weibull-shaped discrete item-size histogram
(matching the stated distribution: Weibull-shaped, mean about 40).  From it we
derive a convex "usable residual" value function G(r) = expected future
fillability of a leftover capacity r.  Arriving items are placed in the bin whose
post-placement residual has the highest marginal value, with a tightest-fit
(best-fit) tie-break.
"""
import numpy as np

# ---- Build the size histogram once -----------------------------------------
# Weibull with shape k and scale lambda chosen so mean ~= 40.
_MEAN = 40.0
_SHAPE = 2.0  # gives a moderately skewed Weibull shape
# For Weibull, mean = lambda * Gamma(1 + 1/k)
try:
    from math import gamma as _gamma
except Exception:  # pragma: no cover
    _gamma = None

if _gamma is not None:
    _SCALE = _MEAN / _gamma(1.0 + 1.0 / _SHAPE)
else:  # pragma: no cover
    _SCALE = _MEAN / 0.886226925452758  # Gamma(1.5)

# Discrete integer sizes 1..100 with Weibull pdf weights.
_sizes = np.arange(1, 101, dtype=np.float64)
_z = (_sizes - 0.5) / _SCALE
if _SHAPE == 2.0:
    _pdf = _z * np.exp(-0.5 * _z * _z) * 2.0 / _SCALE  # 2D Weibull pdf
else:  # pragma: no cover
    _pdf = (_SHAPE / _SCALE) * (_z ** (_SHAPE - 1.0)) * np.exp(-(_z ** _SHAPE))
_pdf = np.clip(_pdf, 0.0, None)
_w = _pdf / _pdf.sum()

# Cumulative distribution: P(item <= s)
_cdf = np.cumsum(_w)
# Probability mass of item size exactly s
_p = _w

# ---- Convex "usable residual" value function G(r) --------------------------
# G(r) = expected fraction of the residual r that a single future item could
# usefully absorb, i.e. E[min(r, X)] / r weighted by how likely X <= r.
# This is increasing and concave/convex in a way that rewards residuals that are
# neither too small (unfillable) nor too large (wasteful over-full bins).
def _build_G():
    G = np.zeros(101, dtype=np.float64)
    # expected min(r, X)
    expmin = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        xs = _sizes[_sizes <= r]
        if xs.size == 0:
            expmin[r] = 0.0
            continue
        probs = _p[:xs.size]
        # conditional contribution: min(r, X) = X for all X<=r
        expmin[r] = float(np.sum(xs * probs))
    # probability that at least one future item fits in r (approx 1-exp(-lam*t))
    # use cumulative probability of a single draw plus a geometric-ish boost
    fitprob = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        pr = _cdf[r - 1]  # P(X <= r)
        # expected number of fitting items over remaining horizon ~ scaled
        fitprob[r] = 1.0 - np.exp(-3.0 * pr)
    G[1:] = (expmin[1:] / np.maximum(_sizes[1:], 1.0)) * fitprob[1:]
    # memoryless wastes reward: make G increasing and convex-ish
    return G


_G = _build_G()


def priority(item, bins):
    """Score bins by the usable-residual value of the post-placement leftover."""
    bins = np.asarray(bins)
    residual = bins - item  # remaining capacity if the item is placed here
    residual_clipped = np.clip(residual, 0, 100)
    # value of the residual the bin would leave
    val = _G[residual_clipped.astype(np.int64)]
    # tightest-fit tie-break: smaller residual slightly preferred
    tie = -residual_clipped * 1e-6
    # item goes to highest score; ties -> first bin. prefer smaller residual.
    return val + tie
# EVOLVE-BLOCK-END
