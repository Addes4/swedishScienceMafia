# EVOLVE-BLOCK-START
"""Best-fit bin choice with a size-aware preference for already-open bins.

The dominant rule is best-fit: place the item in the fitting bin whose
remaining capacity after placement is smallest. This keeps bins tightly
packed and avoids leaving useful gaps. Fresh (empty) bins are penalized
proportionally to the item size, so we prefer to fill already-open bins
before opening a new one, especially for small items.
"""
import numpy as np


def priority(item, bins):
    """Score each bin by tightness of the post-placement residual."""
    r = bins.astype(np.int64) - item
    # Best-fit: 1/(residual+1) is large when residual is small/near-zero.
    score = 1.0 / (r + 1.0)
    # Size-aware reuse bonus: penalize empty bins more for small items,
    # so a fresh bin is opened only when truly necessary.
    penalty = 0.002 * (100.0 - item) / 100.0 + 0.001
    score = np.where(bins >= 100, score - penalty, score)
    return score
# EVOLVE-BLOCK-END
