# EVOLVE-BLOCK-START
"""Best-fit guided by a distribution-aware residual usefulness score.

We precompute a Weibull-shaped item pmf and, for each residual r, a usefulness measure:
how likely a future item is to nearly fill r (leaving small unusable waste), i.e. the
density mass of item sizes near r. Bins whose post-placement residual lands near a
typical item size are favored, plus a best-fit tie-breaker.
"""
import numpy as np

_sizes = np.arange(1, 101)
_k = 1.6
_lam = 45.0
_p = (_k / _lam) * (_sizes / _lam) ** (_k - 1.0) * np.exp(-(_sizes / _lam) ** _k)
_p = np.clip(_p, 1e-12, None)
_p /= _p.sum()

# Usefulness of residual r: probability mass of items that fit in r and leave a
# small remainder (so the bin's slack stays reusable), roughly full-fill likelihood.
_useful = np.zeros(101, dtype=np.float64)
for r in range(101):
    acc = 0.0
    for s in range(1, r + 1):
        rem = r - s
        # weight by how tightly s fills r (small leftover is good)
        acc += _p[s - 1] * (1.0 - rem / 100.0)
    _useful[r] = acc

# normalize
_useful = _useful / (_useful.max() + 1e-12)


def priority(item, bins):
    residual = bins - item
    residual = np.clip(residual, 0, 100)
    score = _useful[residual]
    # best-fit tie-breaker: prefer tighter fits slightly
    score = score - 1e-4 * residual
    return score
# EVOLVE-BLOCK-END

