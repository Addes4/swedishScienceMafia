# EVOLVE-BLOCK-START
"""Worst-fit packing rule.

For random item sizes with mean around 40 (capacity 100), worst-fit (open the
least-full fitting bin) historically beats best-fit on average bin count because
it maintains many balanced, nearly-full bins instead of creating a few tightly
packed ones and a long tail of partially filled bins.  Primary: prefer the
largest pre-placement remaining capacity.  Tie-break: smaller residual after
placement (i.e. tighter fit).
"""
import numpy as np


def priority(item, bins):
    """Score bins by worst-fit, tie-broken toward the tighter fit."""
    residual = bins - item
    # Primary: worst-fit -> larger pre-placement capacity wins.
    # Secondary: among equal capacities, prefer smaller residual (tighter fit).
    return bins.astype(np.float64) * 1000.0 - residual.astype(np.float64)
# EVOLVE-BLOCK-END
