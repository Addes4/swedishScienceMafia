# EVOLVE-BLOCK-START
"""Online bin packing: best-fit rule.

Items arrive one at a time and must be placed immediately.  The classic
best-fit heuristic places the item into the bin with the smallest residual
capacity that still fits the item.  This packs tightly and is a strong
online rule for reducing the number of bins used.

We score each bin by 1/(residual + 1): this is monotonically decreasing in
the residual, so the smallest fitting residual gets the highest score, and
ties go to the first such bin (matching the harness tie rule).
"""
import numpy as np


def priority(item, bins):
    """Score bins by best-fit: smaller residual after placement is better."""
    bins = np.asarray(bins, dtype=np.float64)
    residual_after = bins - float(item)

    # Best-fit: reward the tightest fit. 1/(r+1) is strictly decreasing in r.
    score = 1.0 / (residual_after + 1.0)

    score = np.nan_to_num(score, nan=-1e18, posinf=1e18, neginf=-1e18)
    return score
# EVOLVE-BLOCK-END
