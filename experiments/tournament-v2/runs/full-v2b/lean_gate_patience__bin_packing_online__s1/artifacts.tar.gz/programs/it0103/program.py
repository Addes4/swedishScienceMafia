import numpy as np

# --- static model of the item-size distribution (Weibull-shaped, mean ~40) ---
# Build a value function V(r) approximating the expected number of "useful" future
# items that a residual capacity r can accommodate / match. We then prefer the
# placement with the smallest residual among bins, breaking ties toward residuals
# that are likely to be exactly or near-exactly refilled by a future item.

_SIZE_MIN = 1
_SIZE_MAX = 100
_CACHE = {}

def _build_model():
    # Approximate Weibull(shape k=1.8, scale to get mean ~40) pmf over sizes
    k = 1.8
    # mean of Weibull = scale * Gamma(1+1/k)
    from math import gamma
    scale = 40.0 / gamma(1.0 + 1.0 / k)
    sizes = np.arange(_SIZE_MIN, _SIZE_MAX + 1, dtype=np.float64)
    # Weibull pdf ~ (k/scale)(x/scale)^(k-1) exp(-(x/scale)^k)
    pdf = (k / scale) * (sizes / scale) ** (k - 1.0) * np.exp(-(sizes / scale) ** k)
    pdf = pdf / pdf.sum()
    # For a residual r, value = probability that some future item can exactly finish
    # a bin of residual r, weighted by closeness. Use a smoothed histogram lookup:
    # V(r) = sum_s pdf(s) * exp(-((r - s)/5)^2)  + small bonus for near-fit.
    R = np.arange(0, _SIZE_MAX + 1, dtype=np.float64)
    V = np.zeros_like(R)
    for i, r in enumerate(R):
        if r <= 0:
            V[i] = 1.0  # a full bin is perfect (no waste)
        else:
            V[i] = np.sum(pdf * np.exp(-((r - sizes) / 4.0) ** 2)) + 0.15 * np.sum(
                pdf[sizes <= r] * (1.0 - r / (2.0 * _SIZE_MAX))
            )
    return V

def priority(item, bins):
    V = _CACHE.get('V')
    if V is None:
        V = _build_model()
        _CACHE['V'] = V
    after = bins - item
    # clip to [0,100]; anything negative shouldn't occur (bins shown all fit)
    idx = np.clip(after, 0, _SIZE_MAX).astype(np.int64)
    val = V[idx]
    # Primary: best-fit (minimize residual). Secondary: maximize V(residual).
    # Combine: smaller residual dominates, V breaks ties and near-ties.
    score = -after.astype(np.float64) * 1000.0 + val
    return score
