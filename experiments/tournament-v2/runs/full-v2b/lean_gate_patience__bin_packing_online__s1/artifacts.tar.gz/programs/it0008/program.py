# EVOLVE-BLOCK-START
"""Best-fit ranking with a mild anti-fragmentation bias.

Standard best fit (place into the bin that becomes fullest) is a strong online
rule for Weibull-ish sizes. To reduce fragmentation we add a small bonus to
already-used bins so that open bins get packed tightly before a fresh bin is
opened. Fresh bins (residual 100) receive no bonus. All computation is O(nbins)
with pure numpy.
"""
import numpy as np


def priority(item, bins):
    residual = bins.astype(np.float64) - item
    np.clip(residual, 0.0, 100.0, out=residual)

    # Fill fraction after placing the item: higher is better (best fit).
    fill = (100.0 - residual) / 100.0

    # Small bonus for reusing an already-open bin rather than a fresh one.
    open_bonus = np.where(bins < 100, 0.02, 0.0)

    return fill + open_bonus
# EVOLVE-BLOCK-END
