# EVOLVE-BLOCK-START
"""Best fit with a small anti-fragmentation bias toward earlier bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    idx = np.arange(bins.shape[0])
    return -residual - 1e-6 * idx
# EVOLVE-BLOCK-END
