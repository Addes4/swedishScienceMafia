import numpy as np

def priority(item, bins):
    after = bins - item
    # Best-fit baseline: minimize residual capacity after placing the item.
    best = after.min()

    if item > 50:
        # For large items, avoid leaving a "stranded" large residual (which
        # cannot accept another large item but is too big to be usefully
        # refilled). Among bins with residual >= (100 - item) consider
        # filling as tightly as possible, but if the tightest residual is
        # large (> 50 - item implies leftover can't pair with another large
        # item), prefer leaving the bin with a residual that is at least
        # large enough to still allow a future medium item; we approximate
        # by picking the tightest residual, unless it strands > a threshold.
        # Threshold: a leftover residual that is itself large (>50) is
        # reusable by another large item, so it is NOT waste. The true waste
        # is a leftover residual in (0, 50) that is too small for a large
        # item. So among bins with residual in [0,50) pick the largest
        # capacity that still fits (i.e. smallest residual = best-fit), and
        # among bins with residual >= 50 pick the one closest to 100-item.
        mask_small = (after >= 0) & (after < 50)
        if mask_small.any():
            # best-fit among stranded-residual bins: smallest residual
            score = np.where(mask_small, -after, -1e9)
            return score
        # otherwise just best-fit
        return -after

    # Small/medium items: pure best-fit.
    return -after
