# EVOLVE-BLOCK-START
"""Best-fit bin packing with an 'avoid fresh empty bins' tie-break.

Best-fit (minimize the post-placement residual) is the strongest known online
rule for this distribution.  Its main ambiguity is ties: many bins share the
same minimal residual, and empty bins (pre-placement residual 100) tie with
partially-used bins.  Since item sizes average ~40, wasting an empty bin early
on a mediocre fit is costly.  So as a *tiny* secondary term (strictly smaller
than one residual unit) we reward bins whose pre-placement residual is smaller,
i.e. bins that are already partly full, keeping empty bins in reserve.
"""
import numpy as np


def priority(item, bins):
    bins = np.asarray(bins)
    residual = bins - item                       # post-placement residual (>=0)
    # Primary criterion: minimize residual (tightest fit).
    score = -residual.astype(np.float64)
    # Secondary (bounded by <1 unit of residual): prefer already-used bins,
    # i.e. those with a smaller pre-placement residual / capacity.
    used_frac = (100.0 - bins.astype(np.float64)) / 100.0   # 0 for empty, ->1 as full
    score += 0.5 * used_frac
    return score
# EVOLVE-BLOCK-END
