# EVOLVE-BLOCK-START
"""Best-fit with a perfect-fill bonus.

Primary rule: minimize post-placement residual (classic Best-Fit), which the
recent trials show dominates residual-value variants on this distribution.
Secondary: give a strong extra reward when the placement leaves residual 0
(perfect fill), since such a bin is strictly "used up" and cannot hurt future
packing; this mildly biases selection toward exact fills when they are
available without ever sacrificing tightness elsewhere.
"""
import numpy as np


def priority(item, bins):
    """Highest score wins; score = -(post-placement residual) + perfect-fill bonus."""
    bins = np.asarray(bins)
    residual = bins - item                      # >= 0 guaranteed by harness
    score = -residual.astype(np.float64)
    # Strongly prefer exact fills: reward residual == 0.
    score += (residual == 0) * 1.0
    return score
# EVOLVE-BLOCK-END
