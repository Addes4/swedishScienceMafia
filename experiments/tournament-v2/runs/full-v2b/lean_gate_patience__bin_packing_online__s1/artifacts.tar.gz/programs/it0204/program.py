# EVOLVE-BLOCK-START
"""Stateful least-waste rule using empirical item-size statistics."""
import numpy as np

# empirical histogram of observed item sizes (1..100), initialized to a Weibull-ish prior
_HIST = np.ones(101, dtype=np.float64)
_COUNT = 0.0

# Weibull(k=1.5, lam) prior to smooth early behavior
_K = 1.5
_LAM = 40.0 / 0.902745
_sizes = np.arange(1, 101, dtype=np.float64)
_prior = (_K / _LAM) * (_sizes / _LAM) ** (_K - 1.0) * np.exp(-(_sizes / _LAM) ** _K)
_prior = np.maximum(_prior, 0.0)
_prior /= _prior.sum()
_HIST[1:] = _prior * 50.0
_WEIGHT = 50.0


def priority(item, bins):
    """Best-fit style but reject residuals that are too small to ever be useful:
    prefer the smallest residual that still leaves room for a typical small item,
    using an empirical histogram of past items as the desirability of residuals."""
    global _COUNT, _WEIGHT
    bins = np.asarray(bins)
    residual = bins - item

    # update empirical histogram
    _HIST[item] += 1.0
    _COUNT += 1.0

    # probability mass of items strictly larger than residual (unfillable by one item)
    # Desirability of residual r: expected number of items that could fill it well.
    # Use cumulative: prefer residuals where a sizeable mass of items fits.
    cdf = np.cumsum(_HIST) / _HIST.sum()
    # for each residual, look at mass of items <= residual (fillable in one shot)
    rr = np.clip(residual.astype(np.int64), 0, 100)
    fill_mass = cdf[np.clip(rr - 1, 0, 99)]  # P(size <= residual-1) approx

    # Value: tight residuals good (small leftover), plus reward fillability.
    tight = -(residual.astype(np.float64)) / 100.0
    score = tight + 0.4 * fill_mass
    return score
# EVOLVE-BLOCK-END
