# EVOLVE-BLOCK-START
"""Best-fit packing rule with an online learned residual-utility bonus.

The dominant term is classic best-fit: place the item into the bin with the
smallest non-negative residual (score ~ 1/(residual+1)).  A secondary term uses
an online histogram of the item sizes seen so far to estimate the expected
usefulness of a leftover residual: the average fraction of a typical future
item that could still be packed into that residual.  This mildly steers items
into bins whose leftover space will remain absorbable by common future items,
reducing fragmentation without overriding best-fit.
"""
import numpy as np

# Running histogram of item sizes seen so far (index 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0

# Weight of the learned residual-utility term relative to the best-fit term.
_W = 0.5


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    global _COUNT
    r = bins - item  # residual capacity if placed in each bin (>= 0 by contract)

    # Classic best-fit term: tightest residual wins.
    scores = 1.0 / (r + 1.0)

    # Learned residual-utility term: value of a residual is the expected
    # fraction of a future item that can be absorbed by it.
    if _COUNT > 0.0:
        weights = _HIST / _COUNT
        sizes = np.arange(101, dtype=np.float64)
        # For each bin residual r, average over past sizes s of min(s, r)/s,
        # i.e. the fraction of a typical item of size s that fits in r.
        frac = np.minimum(sizes[None, :], r[:, None]) / np.maximum(sizes[None, :], 1.0)
        vals = frac @ weights
        maxv = vals.max()
        if maxv > 0.0:
            vals = vals / maxv
        scores = scores + _W * vals

    # Mild preference for already-open (less empty) bins.
    scores = scores - 0.0001 * bins

    # Update statistics with the current item.
    _HIST[item] += 1.0
    _COUNT += 1.0

    return scores
# EVOLVE-BLOCK-END

