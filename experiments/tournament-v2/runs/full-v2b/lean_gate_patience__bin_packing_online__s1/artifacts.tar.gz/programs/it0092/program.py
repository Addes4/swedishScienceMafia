# EVOLVE-BLOCK-START
"""Pure best-fit online bin packing.

The harness shows us every bin the item fits in, along with its remaining
capacity. Best-fit places the item into the bin that leaves the smallest
non-negative residual, i.e. the tightest bin that still fits. This simple greedy
rule is near-optimal on this Weibull-shaped size distribution (mean ~40), where
items must be placed immediately. Ties go to the first bin (lowest index),
matching the harness's tie-breaking.
"""
import numpy as np


def priority(item, bins):
    """Score each candidate bin; highest score wins, ties to the first bin.

    We score by the *negative* residual that would remain after placing the
    item, so the bin with the smallest resulting residual (tightest fit) gets
    the highest score.
    """
    b = np.asarray(bins, dtype=np.float64)
    residual_after = b - float(item)
    return -residual_after
# EVOLVE-BLOCK-END

