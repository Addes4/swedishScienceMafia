# EVOLVE-BLOCK-START
"""Adaptive fillability rule with singleton-avoidance: score bins by best-fit plus a
learned reuse value of the residual, and add a penalty for leaving residual capacity
that is likely to be dead space (too small to fit future items).
"""
import numpy as np

# ---- online-learned size distribution (module state, persists across calls) ----
_hist = np.zeros(101, dtype=np.float64)     # counts of observed sizes 1..100
_seen = 0.0                                 # total (smoothed) observations
_hist[1:101] += 0.5
_seen += 50.0

_G = None
_G_age = 0
_REBUILD_EVERY = 25


def _value_table():
    """G[r] = expected consumption of a residual capacity r by a single future item."""
    p = _hist[1:101] / max(_seen, 1e-9)
    sizes = np.arange(1, 101, dtype=np.float64)
    r = np.arange(0, 101, dtype=np.float64)
    cap = np.minimum(sizes[None, :], r[:, None])          # (101, 100)
    exp_consume = cap @ p                                  # (101,)
    return exp_consume


def _rebuild_value():
    global _G, _G_age
    _G = _value_table()
    _G_age = 0


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties)."""
    global _seen, _G_age

    _hist[item] += 1.0
    _seen += 1.0

    if _G is None or _G_age >= _REBUILD_EVERY:
        _rebuild_value()
    _G_age += 1

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item
    np.clip(residual, 0, 100, out=residual)

    # best-fit dominant: prefer small residual
    score = -residual.astype(np.float64)

    # reward residuals that future items are likely to consume (fillability)
    score += 1e-3 * _G[residual]

    # penalize residuals that are likely dead space: too small to fit most items
    # _G[r] small relative to r means low fill probability; add a tiny factor
    dead = (residual > 0).astype(np.float64) * (1.0 - _G[residual] / (residual + 1e-9))
    score -= 5e-4 * dead

    return score
# EVOLVE-BLOCK-END
