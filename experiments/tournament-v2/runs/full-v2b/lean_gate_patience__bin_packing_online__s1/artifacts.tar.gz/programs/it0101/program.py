import numpy as np

def priority(item, bins):
    after = bins - item
    # Best-fit primary: minimize remaining capacity after placement.
    # numpy.argmax picks the first maximal score, breaking ties to the lowest index.
    score = -after.astype(np.float64)
    # Harmonic-hole adjustment: a residual r fits a next item only if r >= that item.
    # Penalize residuals that are "just below" common item sizes so we prefer bins
    # whose leftover can still accept a typical future item. Small, so best-fit dominates.
    r = after.astype(np.float64)
    # bonus for residual that is exactly 0 (bin fills) or large enough to fit a ~40 item
    bonus = np.zeros_like(r)
    bonus[r == 0] += 1e-6
    bonus[r >= 40] += 1e-7
    return score + bonus
