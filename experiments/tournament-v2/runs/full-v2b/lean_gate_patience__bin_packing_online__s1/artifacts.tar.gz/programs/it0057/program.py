# EVOLVE-BLOCK-START
"""Best-fit with least-full tie-break.

Rank candidate bins by the residual capacity left after placing the item
(smaller residual = better fit).  Because the item fits in every bin shown,
residuals are non-negative.  Ties on residual are broken by preferring the
bin with the larger pre-placement remaining capacity (the least-full bin),
which keeps a few bins open and flexible rather than fragmenting capacity
across many nearly-full bins.
"""
import numpy as np


def priority(item, bins):
    """Score bins by best-fit, tie-broken toward the least-full bin."""
    residual = bins - item
    # Primary: best fit -> smaller residual is better (negate).
    # Secondary: among equal residuals, larger pre-placement capacity wins.
    return -residual.astype(np.float64) * 1000.0 + bins.astype(np.float64)
# EVOLVE-BLOCK-END

