"""Static Weibull residual-fillability value rule blended with tightest-fit."""
import numpy as np

# ---- static precomputation of the Weibull item-size pmf (mean ~40) ----
def _build_value():
    # Weibull with shape k tuned so that mean ~= 40 for the harness distribution.
    # We use k=1.5 (moderate skew) and pick scale so mean = scale*Gamma(1+1/k) ~= 40.
    from math import gamma
    k = 1.5
    scale = 40.0 / gamma(1.0 + 1.0 / k)
    # fine pmf over integer sizes 1..100
    sizes = np.arange(1, 101, dtype=np.float64)
    cdf = 1.0 - np.exp(-((sizes / scale) ** k))
    cdf_prev = 1.0 - np.exp(-(((sizes - 1.0) / scale) ** k))
    pmf = cdf - cdf_prev
    pmf = np.clip(pmf, 0.0, None)
    s = pmf.sum()
    if s > 0:
        pmf /= s
    # fillability value G(r): expected number (weighted) of items that can still fit in r.
    # G(r) = sum_{a <= r} pmf[a] * (a + r - a fill bonus)?
    # Better: reward residuals that can absorb whole items and leave usable slack.
    # Define G(r) = sum_{a<=r} pmf[a] * (1 + G(r-a)) is expensive; use a simpler convex proxy:
    # expected fraction of capacity recyclable, weighted by probability and item size.
    # We'll build G via a "fill efficiency" recursion approximation:
    R = 101
    # expected number of items that fit: cumulative pmf mass
    cum = np.cumsum(pmf)  # cum[r] = P(item <= r)
    G = np.zeros(R + 1, dtype=np.float64)
    for r in range(R + 1):
        G[r] = cum[r] if r <= 100 else cum[100]
    # reward residuals just above an item size boundary less; we want leftovers to be
    # easily fillable: penalize residual that is small-but-nonzero using a convex tilt.
    # Convex tilt: combine mass with size-weighted usability.
    tilt = np.zeros(R + 1, dtype=np.float64)
    for r in range(R + 1):
        if r <= 0:
            tilt[r] = 0.0
        else:
            # expected usable mass: sum_{a<=r} pmf[a]*a / r  (how densely we can fill)
            a = np.arange(1, min(r, 100) + 1, dtype=np.float64)
            p = pmf[: len(a)]
            tilt[r] = float((p * a).sum()) / r
    # Blend: value emphasizes that placing the item leaves a residual usable for future items,
    # and that the residual itself is dense (high expected utilization of the leftover).
    value = G + 0.5 * tilt
    return value


_G = _build_value()


def priority(item, bins):
    """Highest score to bin whose post-placement residual has best fillability."""
    residual = bins - item  # >= 0 since only fitting bins are shown
    residual = np.clip(residual, 0, 100)
    # value of leftover capacity for future packing
    vals = _G[residual]
    # tightest-fit term: small residual after placement is good (less wasted space)
    tight = -residual.astype(np.float64) / 100.0
    return vals + 1.0 * tight
# EVOLVE-BLOCK-END
