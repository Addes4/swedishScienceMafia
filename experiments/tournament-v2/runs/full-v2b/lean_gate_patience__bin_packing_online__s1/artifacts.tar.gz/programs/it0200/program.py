# EVOLVE-BLOCK-START
"""Static Weibull residual-fillability value rule blended with tightest fit."""
import numpy as np

# ---- Precompute Weibull item-size pmf (mean ~40) ----
# Weibull with shape k and scale lam; mean = lam * Gamma(1+1/k).
# Choose k ~ 1.5 -> Gamma(1+1/1.5)=Gamma(1.6667)~0.9027 -> lam ~ 44.3 gives mean ~40.
_K = 1.5
_LAM = 40.0 / 0.902745  # ~44.31

_SIZES = np.arange(1, 101, dtype=np.float64)
_PMF = (_K / _LAM) * (_SIZES / _LAM) ** (_K - 1.0) * np.exp(-(_SIZES / _LAM) ** _K)
_PMF = np.maximum(_PMF, 0.0)
_PMF /= _PMF.sum()

# ---- Value function G(r): expected "fillability" of a residual capacity r ----
# G(r) estimates how valuable it is to have residual r. A residual is valuable if it is
# close to a likely item size (can be filled by one item) but small enough to be "tight".
# Build it as a convex, decreasing-with-optimal structure over r in [0,100].
_CAP = 100

def _g_value(r):
    """Value of residual r: low residuals (tight) are good, but a residual that matches
    a common upcoming item size is also good (can absorb a whole item)."""
    # Base: prefer tight residuals (smaller leftover is better) -- convex penalty.
    tight = -(r.astype(np.float64))

    # Bonus for residuals that are near a high-probability item size (fillable exactly-ish).
    rr = r.astype(np.float64)
    # pmf indexed by size; add pmf at floor(r) and nearby, weighted.
    idx = np.clip(np.round(rr).astype(np.int64), 1, 100)
    fill_bonus = _PMF[idx - 1] * 60.0

    return tight + fill_bonus


def priority(item, bins):
    """Score bins by static residual fillability of the post-placement residual,
    blended with a tightest-fit term."""
    bins = np.asarray(bins)
    residual = bins - item  # >= 0 for all shown bins (item fits)

    g = _g_value(residual)

    # Tightest-fit component: strongly prefers the smallest residual that still fits.
    tf = -(residual.astype(np.float64))

    score = g + 0.5 * tf
    return score
# EVOLVE-BLOCK-END
