# EVOLVE-BLOCK-START
"""Best-fit with a learned fillability bonus.

Pure best-fit (minimize residual) is strong but leaves many barely-usable slivers.
We learn the item-size distribution online and add a bonus proportional to the expected
amount of a leftover residual that can still be consumed by a single future item, so bins
that leave *usable* space are preferred when residuals are close.  Best-fit stays dominant.
"""
import numpy as np

# ---- online-learned size distribution (module state, persists across calls) ----
_hist = np.zeros(101, dtype=np.float64)     # counts of observed sizes 1..100
_seen = 0.0                                 # total (smoothed) observations
_hist[1:101] += 0.5
_seen += 50.0

# cached expected-consumption lookup
_EC = None
_EC_age = 0
_REBUILD_EVERY = 25
# weight of the fillability bonus relative to the best-fit term
_BONUS = 0.35


def _rebuild_value():
    """Build EC[r] = expected consumption of residual r by one future item, r = 0..100."""
    global _EC, _EC_age
    p = _hist[1:101] / max(_seen, 1e-9)
    sizes = np.arange(1, 101, dtype=np.float64)
    r = np.arange(0, 101, dtype=np.float64)
    cap = np.minimum(sizes[None, :], r[:, None])          # shape (101, 100)
    _EC = cap @ p                                          # expected consumption per residual
    _EC_age = 0


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties)."""
    global _seen, _EC_age

    # update learned distribution with the incoming item
    _hist[item] += 1.0
    _seen += 1.0

    if _EC is None or _EC_age >= _REBUILD_EVERY:
        _rebuild_value()
    _EC_age += 1

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item                                # residual after placement, >= 0
    np.clip(residual, 0, 100, out=residual)

    # dominant: minimize residual (best-fit); secondary: reward usable leftovers
    score = -residual.astype(np.float64) + _BONUS * _EC[residual]

    # tiny deterministic tie-break toward tighter fits
    score = score - 1e-6 * residual
    return score
# EVOLVE-BLOCK-END
