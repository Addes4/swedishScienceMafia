# EVOLVE-BLOCK-START
"""Best-fit packing rule with a small exact-fit (residual 0) bonus.

The dominant term is classic best-fit: place the item into the bin with the
smallest non-negative residual (score ~ 1/(residual+1)).  A tiny extra bonus
pushes perfect fits (residual exactly 0) ahead of merely tight fits, which
avoids wasting a bin's last slot on a slightly-too-small item.  No learned
statistics are needed, keeping the rule stable across instances.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    r = bins - item  # residual capacity if placed in each bin (>= 0 by contract)

    # Classic best-fit term: tightest residual wins.
    scores = 1.0 / (r + 1.0)

    # Small bonus for a perfect fit (residual 0): keep the last slot usable
    # rather than filling it with a near-fit.
    scores = scores + 0.02 * (r == 0)

    # Mild preference for already-open (less empty) bins.
    scores = scores - 0.0001 * bins

    return scores
# EVOLVE-BLOCK-END

