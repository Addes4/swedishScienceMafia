# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with perfect-fill priority.

Items arrive one at a time and must be placed immediately.  The bin choice
rule ranks bins by the residual capacity that placing the item there would
leave, preferring the smallest such residual (tightest fit).  Bins that would
be filled exactly are given an extra bonus so an available perfect fit is
never passed over.
"""
import numpy as np


def priority(item, bins):
    """Score bins by best-fit, with an extra bonus for exact fills."""
    residual_after = bins - item
    score = -residual_after.astype(np.float64)
    # Strictly prefer an exact fill (residual 0) over any other option.
    score[residual_after == 0] += 1e6
    return score
# EVOLVE-BLOCK-END

