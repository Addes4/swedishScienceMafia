# EVOLVE-BLOCK-START
"""Static size-frequency residual-value bin choice.

A Weibull-shaped histogram of typical future item sizes (mean ~40) is precomputed
once. It is turned into a convex "useful residual" value function V(r): the expected
fraction of an arriving item that a residual capacity r can still absorb. Each bin is
scored by V(leftover capacity) after hypothetically placing the item, plus a tiny
tightest-fit tie-break so nearly-equal residuals prefer the tighter bin.
"""
import numpy as np

# --- Precompute a Weibull-shaped size histogram (mean ~40), once at import time. ---
_SIZE = 101  # capacities 0..100

def _build_hist():
    shape_k = 2.0
    mean = 40.0
    # Weibull mean = scale * Gamma(1 + 1/k)
    from math import gamma
    scale = mean / gamma(1.0 + 1.0 / shape_k)
    sizes = np.arange(1, _SIZE)  # item sizes 1..100
    # Weibull pdf
    pdf = (shape_k / scale) * (sizes / scale) ** (shape_k - 1.0) * np.exp(-(sizes / scale) ** shape_k)
    pdf = np.clip(pdf, 0.0, None)
    if pdf.sum() <= 0:
        pdf = np.ones_like(pdf)
    p = pdf / pdf.sum()
    return p  # p[i-1] = prob of item size i

_PROB = _build_hist()
_SIZES = np.arange(1, _SIZE)

# --- Useful-residual value function V[r] for r in 0..100. ---
# V[r] = expected amount of a single future item size s (<=r) that fits into residual r,
# weighted by probability; larger residual is monotonically more useful, but matching
# common sizes gives extra "fit" credit via a convex combination.
def _build_value():
    V = np.zeros(_SIZE, dtype=np.float64)
    # expected fillable amount for each residual
    for r in range(_SIZE):
        if r <= 0:
            V[r] = 0.0
            continue
        # probability/expected value of fitting an item into residual r
        mask = _SIZES <= r
        p_fit = _PROB[mask]
        s_fit = _SIZES[mask]
        # expected absorbed item size ~ how much of the residual an item would use
        val = float(np.sum(p_fit * s_fit))
        # reward tight packing: also weight by average size to residual ratio (convex)
        ratio = float(np.sum(p_fit * (s_fit / r) ** 2)) if r > 0 else 0.0
        V[r] = val + 0.35 * ratio * 100.0
    return V

_VALUE = _build_value()

# Precompute post-placement residual value for each (bin_capacity, item) pair is done
# on the fly with numpy indexing.

def priority(item, bins):
    """Score each bin by expected future fillability of leftover capacity after placement."""
    b = np.asarray(bins, dtype=np.int64)
    residual = b - item
    # V of leftover residual (clip to valid range)
    idx = np.clip(residual, 0, _SIZE - 1)
    score = _VALUE[idx]
    # Tiny tie-break: among equal residuals, prefer the tighter (smaller) residual,
    # and among that, prefer larger residuals slightly? Use tightest-fit tie-break.
    score = score - 1e-3 * residual
    return score
# EVOLVE-BLOCK-END
