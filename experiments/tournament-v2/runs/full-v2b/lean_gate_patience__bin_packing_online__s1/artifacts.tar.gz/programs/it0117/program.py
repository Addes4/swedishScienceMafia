# EVOLVE-BLOCK-START
"""Worst-fit bin choice.

Place the arriving item into the fitting bin with the largest remaining
capacity (emptiest fit).  For Weibull-shaped item sizes this spreads items
across bins, reducing fragmentation and often matching or beating best-fit.
"""
import numpy as np


def priority(item, bins):
    """Score each bin by its remaining capacity (larger = better)."""
    # Worst-fit: prefer the emptiest bin that still fits.
    return bins
# EVOLVE-BLOCK-END

