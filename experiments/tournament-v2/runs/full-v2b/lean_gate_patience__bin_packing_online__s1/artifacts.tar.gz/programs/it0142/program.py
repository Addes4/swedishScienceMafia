# EVOLVE-BLOCK-START
"""Residual-match rule: score bins by how likely their leftover capacity is usable
by future items, using an online-updated empirical size histogram."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)   # counts of seen item sizes
_TOTAL = 0.0
_FITTED = False


def _build_value():
    """Build a static-ish value table V[r] = expected fillability of residual r.

    We use a smoothed empirical size histogram to estimate the probability that a
    future item has size s. A residual r is valuable if small items can still fill it,
    so define V[r] as the expected 'usable fraction' of r under the empirical size law:
        V[r] = sum_s p_s * min(s, r) * (1 + 1{s <= r})
    which rewards residuals that can still accept common item sizes. Scaled to [0,1].
    """
    global _FITTED
    p = _HIST.copy()
    # Laplace smoothing over sizes 1..100 so unseen sizes retain a little mass.
    p[1:101] += 0.5
    p[0] = 0.0
    s = p.sum()
    if s <= 0:
        p = np.ones(101, dtype=np.float64)
        p[0] = 0.0
        s = p.sum()
    p /= s

    sizes = np.arange(101, dtype=np.float64)
    V = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        # probability mass of items that fit in r
        fit_mass = p[1:r + 1].sum()
        # expected size of fitting items
        exp_fit = (p[1:r + 1] * sizes[1:r + 1]).sum()
        # value: mixture of coverage (exp_fit) and count of fitting sizes (fit_mass)
        V[r] = exp_fit * (1.0 + fit_mass) + r * fit_mass * 0.1
    mx = V.max()
    if mx > 0:
        V /= mx
    _FITTED = True
    return V


_V = _build_value()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    global _TOTAL

    # Online update of the empirical size histogram.
    _HIST[item] += 1.0
    _TOTAL += 1.0

    # Rebuild the value table periodically (cheap amortized) to reflect observed items.
    global _V
    if int(_TOTAL) % 50 == 0:
        _V = _build_value()

    residual = bins - item  # remaining capacity after placing the item

    # Tightest-fit component: prefer small leftover (best-fit).
    # Normalized tightly so it doesn't dominate on huge leftovers.
    tight = -residual.astype(np.float64)

    # Residual-value component: value of the leftover capacity it would create.
    # Use the fillability table; scale down to blend with tightness.
    rclip = np.clip(residual, 0, 100).astype(np.int64)
    val = _V[rclip]

    # Blend: primary signal is tightest fit, secondary is residual fillability.
    return tight + 60.0 * val
# EVOLVE-BLOCK-END
