# EVOLVE-BLOCK-START
"""Static value-function packing.

We model the leftover capacity of a bin as an asset whose worth is how easily it can be
refilled with future items drawn from the (Weibull-shaped, mean ~40) item distribution.
A residual r is "good" if it can host a typical item leaving another good residual.
We precompute, by value iteration, a scalar value V(r) for integer residuals 0..100 and
score each bin by V(residual after placing the item), breaking ties toward tighter fits.
"""
import numpy as np

# Weibull-shaped item pmf over sizes 1..100 with mean ~40.
_sizes = np.arange(1, 101)
_k = 1.6          # shape
_lam = 45.0       # scale
_p = (_k / _lam) * (_sizes / _lam) ** (_k - 1.0) * np.exp(-(_sizes / _lam) ** _k)
_p = np.clip(_p, 1e-9, None)
_p /= _p.sum()

# Expected "reward" for leaving residual r: value of r minus a small waste penalty.
# Value iteration: V(r) = gamma * sum_s p(s) * V'(r - s)  with V'(neg) heavily penalized.
_gamma = 0.98
_V = np.zeros(101, dtype=np.float64)
for _ in range(200):
    newV = np.empty(101, dtype=np.float64)
    for r in range(101):
        acc = 0.0
        for s in range(1, 101):
            rem = r - s
            if rem >= 0:
                acc += _p[s - 1] * _V[rem]
            else:
                # overflow: penalize by scaled leftover that cannot be reused
                acc -= _p[s - 1] * 0.5
        newV[r] = _gamma * acc
    if np.max(np.abs(newV - _V)) < 1e-9:
        _V = newV
        break
    _V = newV

# Make the value function favor larger usable residuals monotonically.
_V = _V - _V.min()
# small bonus for exact fit (residual 0 fully closes bin)
_exact = 0.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties go to first bin."""
    residual = bins - item
    # Base: value of the resulting residual.
    score = _V[np.clip(residual, 0, 100)]
    # Tie-breaker: prefer smaller residual (best-fit-like) to keep big bins open.
    score = score - 1e-3 * residual
    return score
# EVOLVE-BLOCK-END

