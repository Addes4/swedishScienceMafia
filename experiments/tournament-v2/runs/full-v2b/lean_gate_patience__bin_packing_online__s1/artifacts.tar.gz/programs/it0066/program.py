# EVOLVE-BLOCK-START
"""Best-fit with histogram-guided tie-break on the leftover residual.

Plain best-fit (minimize post-placement residual) is near-optimal here.
The remaining margin comes from tie-breaking: when two bins leave similar
residuals, prefer the one whose leftover capacity is itself a frequently
arriving item size, so that leftover space stays reusable later. A running
histogram of past item sizes provides this preference without seeing the
future.
"""
import numpy as np


def priority(item, bins):
    """Score bins so best-fit wins, ties broken by reusable leftover space.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (bins the item fits in).

    Returns a numpy array of scores (higher is better), same length, no NaN.
    """
    # Running histogram of observed item sizes (1..100), stored on function.
    hist = priority.hist
    resid = bins - item  # residual after placing item (>= 0 here)

    # Best-fit primary: smaller residual scores higher (strict, factor 1e6).
    scores = -resid.astype(np.float64) * 1e6

    # Reusability preference: leftover capacity likely to match a future item.
    # resid in [0, 99]; look up how often that size has arrived.
    r = resid.astype(np.int64)
    r = np.clip(r, 0, 100)
    freq = hist[r].astype(np.float64)

    # Secondary term stays far below the 1e6 primary spacing, so it can only
    # decide among (near-)ties, never override best-fit.
    scores += freq

    # Update histogram with this item for future calls.
    hist[item] += 1.0

    return scores


priority.hist = np.zeros(101, dtype=np.float64)
# EVOLVE-BLOCK-END
