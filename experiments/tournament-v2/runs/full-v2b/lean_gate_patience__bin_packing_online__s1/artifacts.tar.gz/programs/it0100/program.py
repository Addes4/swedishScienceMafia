import numpy as np

def priority(item, bins):
    after = bins - item
    # Best-fit: minimize the residual capacity left after placing the item.
    # numpy.argmax picks the first maximal score, which naturally breaks ties
    # toward the lowest bin index among equally tight fits.
    return -after
