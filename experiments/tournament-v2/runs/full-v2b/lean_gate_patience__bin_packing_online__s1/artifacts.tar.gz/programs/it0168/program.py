# EVOLVE-BLOCK-START
"""Deterministic best-fit with fullest-bin tie-break.

Classic best-fit: place the item in the bin that leaves the smallest positive
residual.  When several bins give the same residual, prefer the fullest one
(smallest pre-placement remaining capacity).  This is a pure, stable rule with
no learned state, which was empirically the strongest and most reproducible
choice for this Weibull-shaped workload.
"""
import numpy as np


def priority(item, bins):
    residual = (bins - item).astype(np.float64)
    np.clip(residual, 0.0, 100.0, out=residual)

    # Primary key: smallest residual (best fit) -> negate for "higher is better".
    # Secondary key: smallest pre-placement capacity (fullest bin) among ties.
    # Combine into a single lexicographic-style score using tiny epsilon on the
    # secondary term so it only ever breaks exact ties.
    score = -residual - 1e-6 * bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
