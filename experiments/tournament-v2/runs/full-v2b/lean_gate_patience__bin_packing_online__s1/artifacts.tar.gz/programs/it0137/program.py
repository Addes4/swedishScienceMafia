# EVOLVE-BLOCK-START
"""Online bin packing: best-fit bin choice with a small residual-fit bonus.

Items arrive one at a time and must be placed immediately.  The bin choice
rule ranks the bins the item fits in by the residual capacity that placing the
item there would leave, preferring the smallest such residual (tightest fit).
A tiny secondary bonus encourages leaving a residual that matches a commonly
seen item size, which makes exact future fills more likely.  The bonus is kept
small so that the dominant best-fit ordering is preserved.
"""
import numpy as np


def priority(item, bins):
    """Score bins by best-fit, plus a small bonus for common residuals."""
    residual_after = bins - item
    # Dominant best-fit term: smaller residual -> higher score.
    score = -residual_after.astype(np.float64)
    # Small bonus for residuals equal to the current item size, a frequent
    # leftover that tends to be filled exactly by a later item of the same size.
    bonus = (residual_after == item).astype(np.float64)
    return score + 0.01 * bonus
# EVOLVE-BLOCK-END
