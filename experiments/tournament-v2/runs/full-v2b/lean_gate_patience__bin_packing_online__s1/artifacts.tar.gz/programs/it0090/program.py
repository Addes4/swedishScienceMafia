# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware tie-break.

Primary rule remains best-fit: minimize the post-placement residual.  The only
freedom left is among bins that produce the *same* residual, which happens often
(notably the pool of empty bins all leave residual 100 - item).  Rather than
break these ties arbitrarily, we look at the empirical item-size distribution:
a leftover capacity is more useful if it matches a common future item size, so
among equal residuals we prefer the residual whose value is a high-density point
of the size distribution.  The density term is scaled small enough that it never
overrides the best-fit ordering, only breaks exact ties.
"""
import numpy as np

# Fixed Weibull-shaped item-size pmf (mean ~40, support 1..100).  This is a
# property of the problem distribution, identical across instances, so we bake
# it in once.  Shape k=1.5, scale ~44 gives a Weibull with mean about 40.
_K = 1.5
_LAM = 44.0


def _build_pmf():
    x = np.arange(1, 101, dtype=np.float64)
    # Weibull pdf up to a normalizing constant on 1..100.
    pdf = (_K / _LAM) * (x / _LAM) ** (_K - 1.0) * np.exp(-(x / _LAM) ** _K)
    pdf = np.maximum(pdf, 1e-12)
    pmf = pdf / pdf.sum()
    return pmf


_PMF = _build_pmf()


def priority(item, bins):
    bins = np.asarray(bins)
    residual = bins - item                       # post-placement residual (>=0)
    # Primary criterion: minimize residual (tightest fit).
    score = -residual.astype(np.float64)
    # Secondary: reward residuals that are high-density points of the size
    # distribution (more likely to be exactly matched by a future item), and
    # specifically bonus an exact fill (residual 0).  Magnitudes are tiny so the
    # best-fit ordering is never overridden, only ties are resolved.
    density = _PMF[residual]                     # residual in [0,100]; index 0 unused region
    score += 1e-6 * density
    score += 1e-3 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
