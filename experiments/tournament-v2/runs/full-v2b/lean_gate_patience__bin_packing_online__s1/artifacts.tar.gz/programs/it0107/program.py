import numpy as np


def priority(item, bins):
    """Best-fit: place into the fullest bin that still fits the item.

    Score each bin by the negative residual capacity after placement, so the
    smallest residual (tightest fit) gets the highest score. Ties go to the
    first bin index, which is fine here.
    """
    residual = bins - item
    return -residual.astype(np.float64)
