# EVOLVE-BLOCK-START
"""Best-fit bin-choice rule with a distribution-aware tie-break.

Pure best-fit (place into the bin leaving the smallest non-negative residual)
is the strongest simple online rule here. Its weakness is the many exact ties:
when several bins yield the same residual, the original rule used pre-placement
capacity (emptiest wins), which is only a crude proxy.

Instead we break residual ties using a static "residual utility" table T[r]:
how well a residual capacity r can still be filled by future items drawn from
the known size distribution (Weibull-shaped, mean ~40). T is built once at
import time via a small DP over a discretized item-size histogram, so it costs
nothing per call. Residuals that are exactly representable as sums of common
item sizes get higher utility, so ties favor bins whose leftover is reusable.

Best-fit remains the dominant key (weight 101 on residual dominates the
bounded utility), so the rule is unchanged whenever residuals differ.
"""
import numpy as np

# Build a static utility table for residuals 0..100.
def _build_utility():
    rng = np.random.default_rng(12345)
    # Sample the Weibull-shaped size distribution (mean ~40, shapes in [1,100]).
    shape = 2.2  # chosen so mean ~ 40
    scale = 40.0 / 0.8862  # gamma(1+1/shape) ~ 0.8862 for shape 2.2
    samples = rng.weibull(shape, 200000) * scale
    sizes = np.clip(np.round(samples).astype(np.int64), 1, 100)
    hist = np.bincount(sizes, minlength=101).astype(np.float64)
    hist /= hist.sum()
    # Probability mass by value.
    p = hist[1:101]  # index 0 -> size 1
    # Utility: expected number of items from the distribution that fit into a
    # residual r, weighted to favor residuals that are near-exactly fillable.
    # Approximate representability via a self-convolution of the histogram.
    # conv[k] = probability that a sum of two items equals k.
    conv = np.zeros(201)
    conv[2:201] = np.convolve(p, p)[1:200]
    T = np.zeros(101, dtype=np.float64)
    for r in range(0, 101):
        # value of residual r: prefer it can be exactly used.
        exact = 0.0
        if r >= 1:
            exact = p[r - 1]  # a single item exactly of size r
        if 2 <= r <= 200:
            exact += conv[r]  # two items summing to r
        # baseline: slightly prefer larger residuals (more usable room), but
        # this is tiny compared to the best-fit key.
        T[r] = exact + 1e-4 * r
    return T

_T = _build_utility()


def priority(item, bins):
    """Score each bin: best-fit primary, utility-based tie-break.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    residual = (bins - item).astype(np.int64)
    # Clip residual into valid table range (always fits, so >= 0).
    util = _T[np.clip(residual, 0, 100)]
    # Primary: smaller residual better (weight 101 dominates util, |util| < ~1).
    return -residual.astype(np.float64) * 101.0 + util
# EVOLVE-BLOCK-END

