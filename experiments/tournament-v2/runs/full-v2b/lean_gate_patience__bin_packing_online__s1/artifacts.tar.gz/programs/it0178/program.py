# EVOLVE-BLOCK-START
"""Static Weibull-size-frequency residual-value rule.

The item sizes follow a Weibull-shaped distribution with mean ~40. We precompute
that distribution once, then build a value function G(r) = expected total fraction
of a residual capacity r that will be usable by future items (a concave fillability
value). For each candidate bin we score it by the value of the post-placement
residual G(r - item), blended with a tightest-fit term, so that:

  * bins whose leftover after placing the item is "well shaped" (near a size that
    future items can fill without wasting much) get priority;
  * among equally good residuals, the tightest fit (smallest residual) wins, which
    is what classic heuristics like best-fit approximate.

G is computed from the Weibull distribution by a discrete dynamic program over
residual capacities 0..100: a residual capacity r has value equal to the expected
usable fraction, where the next item of size s (if s <= r) consumes s and leaves
r - s, and if s > r the bin is closed with the leftover wasted. This gives a
concave, monotone fillability value.
"""
import numpy as np

_CAP = 100
_MEAN = 40.0

# Weibull shape parameter. A shape < 1 gives a heavy tail of small items and a
# decaying density, which matches a mean-40 left-skewed packing distribution.
_SHAPE = 1.5


def _weibull_pmf(shape, mean, n=_CAP):
    """Discretized Weibull pmf on sizes 1..n, scaled parameter so mean ~= `mean`.

    Weibull(shape, scale) has mean scale * Gamma(1 + 1/shape). We pick scale so the
    mean matches, then bin the continuous density onto integer sizes 1..n and add an
    atom for the overflow (sizes > n) folded into the last bucket so the pmf sums to 1
    over a support that reaches the capacity.
    """
    from math import gamma
    scale = mean / gamma(1.0 + 1.0 / shape)

    # CDF at integer boundaries.
    edges = np.arange(0, n + 1, dtype=np.float64)
    cdf = 1.0 - np.exp(-np.power(edges / scale, shape))
    cdf = np.clip(cdf, 0.0, 1.0)

    pmf = np.empty(n, dtype=np.float64)
    pmf[0] = cdf[1] - cdf[0]
    for s in range(2, n + 1):
        pmf[s - 1] = cdf[s] - cdf[s - 1]
    # Fold any remaining mass (sizes > n) into the largest bucket.
    tail = 1.0 - cdf[n]
    pmf[n - 1] += tail

    total = pmf.sum()
    if total > 0:
        pmf /= total
    return pmf


def _build_value_function(pmf):
    """Discrete dynamic program for the fillability value G(r), r = 0..100.

    G(r) = expected number of items' worth of capacity used before this residual
    can no longer accept the next item, normalized, i.e. the expected usable
    fraction of residual r. Larger r is always weakly better and the value is
    concave, giving a smooth preference for residuals that combine well.
    """
    n = pmf.shape[0]
    G = np.zeros(_CAP + 1, dtype=np.float64)

    # Value of a residual r = expected fraction of r that will be consumed by a
    # greedy sequence of future items (using the same value function recursively).
    for r in range(1, _CAP + 1):
        # Distribution of the next item conditioned on it fitting (s <= r).
        s = np.arange(1, min(r, n) + 1)
        p = pmf[s - 1]
        fit_mass = p.sum()
        if fit_mass <= 0.0:
            # No item can fit: residual wasted.
            G[r] = 0.0
            continue
        p_norm = p / fit_mass
        # If an item fits we use it: consumed value = s/r plus the future value
        # of what remains, scaled to the residual fraction it represents.
        consumed = s / r
        future = G[r - s] * ((r - s) / r)
        expected = np.dot(p_norm, consumed + future)
        # Probability that some future item fits at all (fit_mass); if no item ever
        # fits the residual is wasted. Multiply by fit_mass to account for the
        # possibility that this residual is unreachable/small.
        G[r] = fit_mass * expected

    # Normalize so G(max capacity) ~ 1 (fraction of capacity usable).
    if G[_CAP] > 0:
        G = G / G[_CAP]
    return G


_PMF = _weibull_pmf(_SHAPE, _MEAN)
_G = _build_value_function(_PMF)

# Blend weight between the residual-value term and the tightest-fit term.
_TIGHT_W = 0.25


def priority(item, bins):
    """Score each bin by post-placement residual fillability plus tightest-fit.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    residual = bins - item
    # Value of the leftover space after placing the item here.
    rv = _G[np.clip(residual, 0, _CAP)]
    # Tightest fit: prefer smaller residuals (less wasted space now).
    tight = -(residual.astype(np.float64)) / float(_CAP)
    return rv + _TIGHT_W * tight
# EVOLVE-BLOCK-END
