# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with an empirical-fit tie-breaker.

The dominant term is the classic best-fit score 1/(r+1), which is strictly
decreasing in the residual r, so the bin with the smallest fitting residual
gets the highest score (ties to the first bin).  Best-fit is a very strong
online rule.

To exploit the fact that ties/close calls are resolved poorly by bin index
alone, we add a *tiny* secondary reward: we keep an online histogram of the
item sizes seen so far, and reward a bin whose residual after placement
exactly matches a frequently observed item size.  The weight is small enough
to never overturn a strict best-fit preference but breaks effective ties
toward residuals that are actually reusable.
"""
import numpy as np

# Online histogram of observed integer item sizes (1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    global _COUNT
    bins = np.asarray(bins, dtype=np.float64)
    residual_after = bins - float(item)

    # Best-fit: strictly decreasing in residual.
    score = 1.0 / (residual_after + 1.0)

    # Empirical frequency of item sizes seen so far (with a small prior).
    # reward residual r that equals a commonly seen item size.
    r_int = np.clip(np.round(residual_after), 0, 100).astype(np.int64)
    freq = _HIST[r_int]
    if _COUNT > 0:
        freq = freq / _COUNT
    # tiny tie-breaker, never overturning best-fit differences
    score = score + 1e-3 * freq

    # update online histogram with the current item
    if 1 <= item <= 100:
        _HIST[int(item)] += 1.0
    _COUNT += 1.0

    score = np.nan_to_num(score, nan=-1e18, posinf=1e18, neginf=-1e18)
    return score
# EVOLVE-BLOCK-END
