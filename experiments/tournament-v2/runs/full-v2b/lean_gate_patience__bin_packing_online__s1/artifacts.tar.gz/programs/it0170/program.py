import numpy as np


class _State:
    def __init__(self, cap=100):
        self.cap = cap
        # decayed histogram over item sizes 1..cap
        self.hist = np.zeros(cap + 1, dtype=np.float64)
        self.total = 0.0
        self.decay = 0.995
        # value function cache
        self.value = None
        self.value_dirty = True

    def observe(self, item):
        self.hist *= self.decay
        self.hist[item] += 1.0
        self.total = self.total * self.decay + 1.0
        self.value_dirty = True

    def _build_value(self):
        cap = self.cap
        h = self.hist.copy()
        if self.total <= 0:
            # uniform fallback
            p = np.ones(cap + 1, dtype=np.float64)
            p[0] = 0.0
            p /= p.sum()
        else:
            # light smoothing with a small uniform prior
            h += 0.1
            h[0] = 0.0
            s = h.sum()
            if s <= 0:
                h = np.ones(cap + 1, dtype=np.float64)
                h[0] = 0.0
                s = h.sum()
            p = h / s
        # DP: G[r] = expected future coverage of residual space r
        # G[r] = sum_s p[s] * (s + G[r-s]) for s <= r, else G[r-1]... 
        # Actually whenever no item fits, residual is wasted; model as
        # value of best possible achievable fill fraction.
        # Use recursion: G[r] = sum_{s<=r} p[s]*(s + G[r-s]) + sum_{s>r} p[s]*G_waste
        # where if nothing fits, the bin is closed (value 0 for further fill).
        # To keep it simple and convex-ish, do iterative fixed point.
        G = np.zeros(cap + 1, dtype=np.float64)
        # iterate
        for _ in range(30):
            newG = np.zeros(cap + 1, dtype=np.float64)
            for r in range(1, cap + 1):
                acc = 0.0
                # items that fit
                for s in range(1, r + 1):
                    acc += p[s] * (s + G[r - s])
                # items that don't fit: bin essentially closed for that item,
                # but future smaller items may still fit; approximate by keeping G[r]
                # weighted by probability that some item fits.
                fit_prob = p[1:r + 1].sum() if r >= 1 else 0.0
                nofit_prob = 1.0 - fit_prob
                acc += nofit_prob * G[r]
                newG[r] = acc
            G = newG
        self.value = G
        self.value_dirty = False

    def get_value(self):
        if self.value_dirty or self.value is None:
            self._build_value()
        return self.value


_state = _State()


def priority(item, bins):
    st = _state
    st.observe(int(item))
    G = st.get_value()
    cap = st.cap

    residual = bins - item  # remaining capacity after placement
    residual = np.clip(residual, 0, cap)

    # convex coverage value of residual
    gvals = G[residual]

    # tightest-fit probability: chance the next item almost exactly fills residual
    # use histogram as proxy distribution
    h = st.hist
    if st.total > 0:
        p = h / max(st.total, 1e-9)
        # probability mass concentrated near residual (within small window)
        # approximate with p at residual and its neighbors
        idx = residual
        tight = np.zeros_like(residual, dtype=np.float64)
        for d in range(0, 4):
            lo = np.clip(idx - d, 0, cap)
            hi = np.clip(idx + d, 0, cap)
            tight += p[lo] + p[hi]
    else:
        tight = 1.0 / (residual + 1.0)

    # blend: value of remaining space + encouragement to leave tight residuals
    score = gvals + 0.5 * tight
    return score
