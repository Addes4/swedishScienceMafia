import numpy as np

def priority(item, bins):
    after = bins - item
    # Base: best-fit (smallest residual that still fits).
    score = -after.astype(np.float64)
    # Exact-fill bonus: strongly reward consuming the bin completely.
    score += (after == 0) * 1e6
    # For large items, pure best-fit often dumps them into an empty bin
    # leaving a ~40 residual that can only take small items, wasting the
    # chance to pair two large items. Slightly prefer residuals that are
    # in a "mid" band that large items (say >50) could neatly finish,
    # while still ranking dominantly by tightness.
    if item > 50:
        # favored residual after placement: moderately large so a big
        # future item (>50) can still fit and fill well. Push away from
        # very small residuals and from very large ones.
        # Give a gentle bonus when residual >= 50-... i.e., <=50 region.
        bonus = np.where((after >= 30) & (after <= 50), 0.5, 0.0)
        score += bonus
    return score
