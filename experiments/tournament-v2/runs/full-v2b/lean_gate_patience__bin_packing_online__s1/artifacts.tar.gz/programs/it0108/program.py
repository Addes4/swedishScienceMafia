import numpy as np


def priority(item, bins):
    """Size-class-aware fit.

    Small/medium items (<= 50): strict best-fit (smallest post-placement
    residual) packs tightly and is near-optimal.

    Large items (> 50): a bin can hold at most one more item of comparable
    size, so placing a large item into the fullest bin risks stranding the
    remaining space. Instead prefer the bin with the largest remaining
    capacity that still fits (worst-fit), leaving maximum room for a future
    partner item. Ties go to the tightest fit.
    """
    residual = bins - item
    r = residual.astype(np.float64)
    if item > 50:
        # worst-fit on the residual that remains *after* placement
        return r
    # best-fit: smallest residual after placement ranks highest
    return -r
