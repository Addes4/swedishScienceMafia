"""Best-fit with residual-value tie-break using a light item histogram."""

import numpy as np

# Decaying histogram of recent item sizes (1..100), kept across calls.
_hist = np.zeros(101, dtype=np.float64)
_decay = 0.98


def priority(item, bins):
    """Best-fit primary; tie-break toward residuals that match frequent sizes."""
    global _hist
    _hist *= _decay
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for bins shown

    # Primary: prefer smallest residual (tightest fit) -> negative residual.
    # Secondary tie-break within near-minimal residual:
    #   reward leaving a residual that matches a frequently seen item size.
    # Use a small relative weight so it only affects near-ties.
    resid_int = np.clip(residual, 0, 100).astype(np.int64)
    freq = _hist[resid_int]
    max_freq = _hist.max() + 1e-12

    # Small tie-break term in (-1, 0] so it cannot override residual ordering
    # when residuals differ by >= 1.
    tie = -0.5 * (freq / max_freq)

    # Emptier-bin nudge for remaining capacity, very small.
    nudge = -1e-6 * bins.astype(np.float64)

    return -residual.astype(np.float64) + tie + nudge
