# EVOLVE-BLOCK-START
"""Best-fit packing rule.

For each candidate bin we compute the residual r = remaining_capacity - item
that would result from placing the arriving item there. We score the bin by
1/(r+1), so the item goes into the bin with the smallest non-negative residual
(the tightest fit). A tiny penalty per unit of remaining capacity mildly favours
already-open bins over fresh ones, which keeps large empty bins available.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    r = bins - item  # residual capacity if placed in each bin (>= 0 by contract)
    scores = 1.0 / (r + 1.0)
    # Mild preference for already-open (less empty) bins.
    scores = scores - 0.0001 * bins
    return scores
# EVOLVE-BLOCK-END

