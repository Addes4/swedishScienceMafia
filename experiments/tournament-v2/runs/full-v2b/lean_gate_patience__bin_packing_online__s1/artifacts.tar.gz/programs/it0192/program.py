# EVOLVE-BLOCK-START
"""Best-fit rule for online bin packing.

Put the item into the bin that leaves the smallest non-negative residual
(best fit).  Among bins with the same residual, prefer the one that was
fuller before placement (smallest pre-placement capacity), which packs
more tightly and matches classic best-fit behavior.
"""
import numpy as np


def priority(item, bins):
    """Rank bins: best fit (smallest residual), then fullest bin first."""
    residual = bins.astype(np.int64) - int(item)
    score = -residual.astype(np.float64) * 101.0 - bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

