# EVOLVE-BLOCK-START
"""Best-fit with a small residual-utility bonus for open bins.

Best fit (place into the bin that becomes fullest) is a strong online rule.
We add a tiny bonus for already-used bins whose post-placement residual is
still large enough to be useful for future items, and no bonus for fresh bins.
This nudges the packing to reuse open bins before opening new ones, while
still strongly preferring tight fits. All computation is pure numpy, O(nbins).
"""
import numpy as np


def priority(item, bins):
    residual = bins.astype(np.float64) - item
    np.clip(residual, 0.0, 100.0, out=residual)

    # Fill fraction after placing the item: higher is better (best fit).
    fill = (100.0 - residual) / 100.0

    # Small bonus for reusing an already-open bin that still leaves a useful
    # residual (avoids opening fresh bins prematurely). Fresh bins get none.
    open_bonus = np.where((bins < 100) & (residual > 0.0), 0.02, 0.0)

    return fill + open_bonus
# EVOLVE-BLOCK-END
