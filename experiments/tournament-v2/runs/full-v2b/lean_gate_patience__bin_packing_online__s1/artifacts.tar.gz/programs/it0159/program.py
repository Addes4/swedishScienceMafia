# EVOLVE-BLOCK-START
"""Best-fit with a tiny tie-break among near-equal residuals."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Primary: smallest residual (best fit). Tiny secondary nudge:
    # among residuals within 1 unit of the minimum, prefer larger bins.
    rmin = residual.min()
    near = residual <= (rmin + 1)
    # For near-tie bins, subtract a small amount proportional to the bin's
    # current remaining capacity so larger bins win those ties.
    nudge = np.where(near, bins, 0).astype(np.float64) * 1e-6
    return -residual.astype(np.float64) + nudge
# EVOLVE-BLOCK-END

