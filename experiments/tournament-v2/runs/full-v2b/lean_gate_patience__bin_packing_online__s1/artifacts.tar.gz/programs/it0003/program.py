# EVOLVE-BLOCK-START
"""Best fit with a tiny deterministic tie-breaking perturbation.

The item goes to the bin where it fits most tightly (smallest residual after placement).
Exact ties are common (many bins share the same remaining capacity), and the fixed
first-bin tie rule can build up a suboptimal pattern. We add a very small perturbation
derived from a running counter so that ties are broken in a varied but deterministic way.
"""
import numpy as np

_state = {"n": 0}


def priority(item, bins):
    # Best fit: prefer the smallest residual after placement.
    score = -(bins - item)

    # Tiny tie-break perturbation keyed on (bin capacity, item, step).  The magnitude is
    # well below 1 so it only affects exact/near-exact ties in the primary key.
    _state["n"] += 1
    n = _state["n"]
    # deterministic pseudo-random jitter in (-0.5, 0.5) per bin
    jitter = ((bins * 2654435761 + item * 40503 + n * 2246822519) % 1024) / 1024.0 - 0.5
    return score + 1e-3 * jitter
# EVOLVE-BLOCK-END
