# EVOLVE-BLOCK-START
"""Best-fit with a learned "matchable residual" tie-break.

Ranking is dominated by best-fit (smallest residual after placement), which is a strong
baseline.  A small secondary term rewards leaving a residual that coincides with a
frequently observed item size, because such leftovers are likely to be filled exactly by a
future item.  The secondary term only breaks near-ties, so it cannot hurt the core rule.
"""
import numpy as np

# ---- online-learned size distribution (module state, persists across calls) ----
_hist = np.zeros(101, dtype=np.float64)     # counts of observed sizes 1..100
_seen = 0.0
# pseudo-count prior: gentle uniform smoothing so early calls behave sensibly
_hist[1:101] += 0.5
_seen += 50.0

# cached "matchability" weights over residuals 0..100
_M = None
_M_age = 0
_REBUILD_EVERY = 25


def _rebuild_match():
    """Weights: probability that a future item exactly matches a residual size."""
    global _M, _M_age
    p = _hist[1:101] / max(_seen, 1e-9)
    m = np.zeros(101, dtype=np.float64)
    # residual r (1..100) can be exactly completed by an item of size r
    m[1:] = p
    _M = m
    _M_age = 0


def priority(item, bins):
    global _seen, _M_age

    # update learned distribution with the incoming item
    _hist[item] += 1.0
    _seen += 1.0

    if _M is None or _M_age >= _REBUILD_EVERY:
        _rebuild_match()
    _M_age += 1

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item
    np.clip(residual, 0, 100, out=residual)

    # dominant term: best-fit (prefer smallest residual)
    score = -residual.astype(np.float64)
    # secondary: reward residuals that a future item can exactly complete
    score += 0.5 * _M[residual]

    return score
# EVOLVE-BLOCK-END

