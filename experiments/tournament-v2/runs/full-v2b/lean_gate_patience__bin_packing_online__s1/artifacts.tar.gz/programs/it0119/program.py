# EVOLVE-BLOCK-START
"""Best-fit with an online minimum-item-size tie-break.

The dominant rule is classic best-fit (place into the fitting bin with the
smallest remaining capacity, i.e. leave the smallest residual).  A residual
that is smaller than every item size seen so far can never be filled again,
so it is pure waste.  Among bins whose post-placement residual ties for the
minimum, we therefore prefer residuals that are still "fillable"
(residual >= smallest observed item size).  The smallest size is estimated
online from past items only, so no future information is used.
"""
import numpy as np


def priority(item, bins):
    """Score bins: best-fit dominant, with a small fillability tie-break.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every fitting bin (numpy int64, bin order).
    """
    # Track the smallest item size observed so far (state across calls).
    smallest = getattr(priority, "_smallest", 100)
    if item < smallest:
        smallest = item
        priority._smallest = smallest

    residual = bins - item  # remaining capacity after placing the item

    # Best-fit: prefer the smallest residual.
    score = -residual.astype(np.float64)

    # Small tie-break: penalize residuals that are too small to ever fit
    # another item (below the smallest size seen so far), but only among
    # bins that already achieve the minimum residual.
    min_res = residual.min()
    tie = residual == min_res
    if min_res < smallest:
        score = score + tie * (-0.5)

    return score
# EVOLVE-BLOCK-END
