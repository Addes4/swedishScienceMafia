# EVOLVE-BLOCK-START
"""Best-fit rule with a small tie-break bonus for residuals that match
frequent item sizes (so the residual can be cleanly closed by a future item).

Items arrive one at a time; we pick the bin whose remaining capacity after
placing the item (the residual) is smallest, i.e. classic best fit.  A tiny
bonus is added for residuals that equal a likely single future item size, which
makes the tie-breaking robust on the Weibull-shaped distribution.
"""
import numpy as np

_sizes = np.arange(1, 101, dtype=np.float64)

def _weibull_pmf(shape, scale):
    cdf_hi = 1.0 - np.exp(-((_sizes + 0.5) / scale) ** shape)
    cdf_lo = 1.0 - np.exp(-((_sizes - 0.5) / scale) ** shape)
    pmf = np.clip(cdf_hi - cdf_lo, 0.0, None)
    pmf[0] = 1.0 - np.exp(-(0.5 / scale) ** shape)
    pmf = pmf / pmf.sum()
    return pmf

_SHAPE = 1.6
scale = 40.0
pmf = _weibull_pmf(_SHAPE, scale)
for _ in range(80):
    pmf = _weibull_pmf(_SHAPE, scale)
    mean = float(np.dot(_sizes, pmf))
    if abs(mean - 40.0) < 0.02:
        break
    if mean < 40.0:
        scale *= 1.005
    else:
        scale *= 0.995
_ITEM_PMF = pmf

# Bonus table: probability that some future item exactly fills residual r.
# Only residuals 1..100 are meaningful.
_BONUS = np.zeros(101, dtype=np.float64)
_BONUS[1:101] = _ITEM_PMF[0:100]

# Weight of the tie-break bonus relative to the best-fit term.
_W = 0.05

def priority(item, bins):
    """Choose the tightest-fit bin, breaking ties toward closable residuals."""
    residual = bins - item  # >= 0 for all bins shown
    r = np.clip(residual, 0, 100).astype(np.int64)
    bonus = _BONUS[r]
    # Dominant term: prefer smallest residual (best fit).
    return -residual.astype(np.float64) + _W * bonus
# EVOLVE-BLOCK-END

