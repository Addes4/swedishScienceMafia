# EVOLVE-BLOCK-START
"""Best-fit with an online-learned exact-match reward on the residual left behind.

Pure best-fit (score = -residual) is a strong baseline here. We add a small secondary
term: the online histogram gives P(next item size == r) for the residual r a bin would
leave. Leaving a residual equal to a very frequent item size means a future item is likely
to fill it exactly (closing a bin), so we mildly reward it.
"""
import numpy as np

# ---- online-learned size distribution (module state, persists across calls) ----
_hist = np.zeros(101, dtype=np.float64)     # counts of observed sizes 1..100
_seen = 0.0
_hist[1:101] += 0.5
_seen += 50.0

_prob = None          # normalized P(item == r), index 0..100
_prob_age = 0
_REBUILD_EVERY = 25
_LAMBDA = 4.0         # weight of the exact-match reward relative to best-fit term


def _rebuild_prob():
    global _prob, _prob_age
    _prob = _hist[1:101] / max(_seen, 1e-9)
    _prob_age = 0


def priority(item, bins):
    global _seen, _prob_age, _prob

    _hist[item] += 1.0
    _seen += 1.0

    if _prob is None or _prob_age >= _REBUILD_EVERY:
        _rebuild_prob()
    _prob_age += 1

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item
    np.clip(residual, 0, 100, out=residual)

    # residual index 0..99 -> probability lookup (index 0 -> 0 probability)
    exact = np.zeros(residual.shape, dtype=np.float64)
    mask = residual > 0
    if np.any(mask):
        exact[mask] = _prob[residual[mask] - 1]

    # dominant best-fit (-residual); small reward for leaving a frequent item size
    score = -residual.astype(np.float64) + _LAMBDA * exact
    return score
# EVOLVE-BLOCK-END
