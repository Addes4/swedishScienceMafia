# EVOLVE-BLOCK-START
"""Online bin packing via a stateful residual-value rule.

We learn the running mean and variance of arriving items, and score each bin by how
attractive its post-placement residual is: we want residuals that are (a) small (tight
packing, so we don't leave large holes) but (b) still >= roughly one mean item, so the
bin can likely be closed by a future item rather than becoming dead waste.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.m2 = 0.0  # for variance


_s = _State()


def priority(item, bins):
    n = _s.n + 1
    delta = item - _s.mean
    _s.mean += delta / n
    _s.m2 += delta * (item - _s.mean)
    _s.n = n

    mean = _s.mean
    var = _s.m2 / n if n > 1 else 0.0
    std = var ** 0.5

    residual = (bins - item).astype(np.float64)

    # Dead waste: residual that is too small to ever hold a likely item is bad.
    # A bin whose residual is < ~mean - std is hard to close -> penalize.
    close_margin = max(1.0, mean - 0.5 * std)
    dead = np.maximum(0.0, close_margin - residual)

    # Empty-ish bins (large residual) should be preserved until needed: mild penalty
    # for placing into a bin that is still very empty when a tighter bin exists.
    # Tight-fit preference: smaller residual better.
    score = -0.30 * residual - 3.0 * dead
    return score
# EVOLVE-BLOCK-END

