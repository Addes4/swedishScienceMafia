# EVOLVE-BLOCK-START
"""Size-frequency residual-value packing rule.

Score each candidate bin by the expected future usefulness of the residual
capacity left after placing the item, using a fixed Weibull-shaped size
histogram (mean ~40) to define a convex "useful residual" function.
"""
import numpy as np

C = 100


def _build_hist():
    # Weibull-shaped size distribution on 1..100 with mean ~40.
    # Weibull(k=2, lambda) shifted/truncated; pick scale to get mean ~40.
    sizes = np.arange(1, C + 1, dtype=float)
    k = 2.0
    # Weibull on (0, inf) with scale lam, conditioned on <=100, mean ~40.
    lam = 56.0
    pdf = (k / lam) * (sizes / lam) ** (k - 1.0) * np.exp(-(sizes / lam) ** k)
    pdf /= pdf.sum()
    return sizes, pdf


_SIZES, _PDF = _build_hist()

# Convex "useful residual" value function over residual capacity r = 0..100.
# Reward residuals that match common future sizes and full bins; convex shape
# so that mid residuals are super-additively valuable.
def _build_value():
    r = np.arange(C + 1, dtype=float)
    # Expected number of typical items that can fit / composability measure:
    # v(r) = E_s[ 1 + v(r - s) ] approximated by a smooth convex proxy:
    #   reward small residuals (near full) and residuals that are multiples
    #   of common sizes.  Use convex increasing-then-saturating curve.
    base = (r / C)
    # convex emphasis: superlinear near the top (fully packed is great)
    conv = base ** 1.6
    # peak reward for residuals close to common item size (likely fillable)
    fillable = np.zeros(C + 1)
    for s, p in zip(_SIZES.astype(int), _PDF):
        lo = max(0, s - 4)
        hi = min(C, s + 4)
        fillable[lo:hi + 1] += p * 0.15
    val = conv + fillable
    return val


_VALUE = _build_value()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of bins the item fits in (numpy int64).
    """
    b = np.asarray(bins, dtype=np.int64)
    residual = b - item
    residual = np.clip(residual, 0, C)
    # Value of leftover capacity for future items.
    future = _VALUE[residual]
    # Prefer tight fit as a secondary signal (best-fit tie-break).
    tight = -(b.astype(np.float64))
    # Weight: mostly residual value, small best-fit nudge.
    return future * 1000.0 + tight
# EVOLVE-BLOCK-END
