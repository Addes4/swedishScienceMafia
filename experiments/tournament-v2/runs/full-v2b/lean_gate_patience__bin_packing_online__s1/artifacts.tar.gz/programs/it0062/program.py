# EVOLVE-BLOCK-START
"""Best-fit with a small tolerance band and a reusable-residual tie-break.

Primary rule remains best-fit: we strongly prefer the bin that leaves the
smallest residual capacity after placing the item.  However, residuals that
differ only by a small tolerance are treated as nearly equivalent, and within
that band we prefer the bin whose leftover residual equals (or is close to) a
frequently observed item size, using a running histogram of past item sizes.
This keeps leftover space exactly reusable by future items, reducing waste.
"""
import numpy as np


class _State:
    def __init__(self):
        # Histogram of observed item sizes (1..100); smoothed by +1.
        self.hist = np.ones(101, dtype=np.float64)


_state = _State()


def priority(item, bins):
    """Best-fit primary with reusable-residual tie-break inside a tolerance band."""
    residual = bins - item

    hist = _state.hist
    # Value of a leftover residual r: high if r is a common item size.
    # r ranges over 0..100 (0 means perfectly filled = best).
    r = residual.astype(np.int64)
    r = np.clip(r, 0, 100)
    reusable = hist[r]  # frequency weight of the leftover as a future item size

    # Update histogram with the current item for future calls.
    _state.hist[item] += 1.0

    # Primary: best fit -> smaller residual better.  Scale large so it
    # dominates.  Tolerance band: add a small bonus for reusable residuals
    # so that near-equal residuals are resolved toward reusable leftovers.
    return -residual.astype(np.float64) * 1000.0 + reusable
# EVOLVE-BLOCK-END
