# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a reusable-residual tie-breaker.

The dominant signal is best-fit (place into the tightest fitting bin).  Ties
in residual capacity are broken by preferring residuals that are more useful
for future packing: an exactly-closed bin (residual 0) is ideal, and otherwise
we reward residuals that match frequently seen item sizes, using a running
histogram of past items.  The tie-breaker is scaled small so it never
overrides the best-fit ordering.
"""
import numpy as np

# Running histogram of observed item sizes (shared across calls).
_HIST = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    item = int(item)

    # Update running histogram of past item sizes.
    _HIST[item] += 1.0
    total = _HIST.sum()
    freq = _HIST / total  # normalized frequency of each size

    bins = np.asarray(bins, dtype=np.float64)
    residual_after = bins - float(item)

    # Best-fit dominant term: strictly decreasing in residual.
    score = 1.0 / (residual_after + 1.0)

    # Reusable-residual tie-breaker:
    #  - residual 0 (bin exactly closed) gets a small positive bonus,
    #  - otherwise reward residuals equal to common future item sizes.
    r = residual_after.astype(np.int64)
    valid = (r >= 0) & (r <= 100)
    bonus = np.zeros_like(residual_after)
    bonus[valid] = freq[r[valid]]
    bonus[r == 0] = 0.05  # closed bin is very reusable

    score = score + 1e-6 * bonus

    score = np.nan_to_num(score, nan=-1e18, posinf=1e18, neginf=-1e18)
    return score
# EVOLVE-BLOCK-END
