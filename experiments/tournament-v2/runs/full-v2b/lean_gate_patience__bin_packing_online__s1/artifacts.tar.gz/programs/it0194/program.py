"""Best-fit bin-choice rule."""

import numpy as np


def priority(item, bins):
    """Prefer the smallest residual capacity after placing the item.

    Bins are shown only if the item fits, so residual = bins - item >= 0.
    Ties (equal residual) are broken by preferring the larger bin (more
    remaining capacity before placement), which keeps fuller bins for later
    tight fits in a stable, deterministic way.
    """
    residual = bins - item
    # Primary: smaller residual is better -> use negative residual.
    # Secondary: larger pre-placement capacity is slightly better as a tie-break.
    return -residual.astype(np.float64) * 1000.0 - bins.astype(np.float64)
