# EVOLVE-BLOCK-START
"""Best-fit packing rule with a sharp, deterministic residual-value bonus.

The dominant term is classic best-fit: place the item into the bin with the
smallest non-negative residual (score ~ 1/(residual+1)).  A secondary term
rewards residuals that match the typical item size of the fixed distribution
(mean about 40), so the leftover space is likely to be reusable by a future
item, reducing fragmentation.  Unlike a learned online histogram, this target
is fixed and noise-free.
"""
import numpy as np

# Weight of the residual-value term relative to the best-fit term.
_W = 0.35

# Bandwidth of the sharp Gaussian kernel used for residual value.
_BW = 5.0

# Typical item size of the distribution (mean about 40).
_TARGET = 40.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    r = bins - item  # residual capacity if placed in each bin (>= 0 by contract)

    # Classic best-fit term: tightest residual wins.
    scores = 1.0 / (r + 1.0)

    # Deterministic residual-value term: reward residuals that match the
    # typical item size, so the leftover can host a future typical item.
    vals = np.exp(-((r - _TARGET) ** 2) / (2.0 * _BW * _BW))
    scores = scores + _W * vals

    # Reward residuals that could still hold the current item's size again.
    scores = scores + 0.05 * (r >= item)
    # Reward an exact match of the current item size, encouraging reuse.
    scores = scores + 0.03 * (r == item)

    # Mild preference for already-open (less empty) bins.
    scores = scores - 0.0001 * bins

    return scores
# EVOLVE-BLOCK-END
