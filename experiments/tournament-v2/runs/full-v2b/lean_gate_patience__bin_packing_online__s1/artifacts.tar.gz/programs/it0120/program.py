# EVOLVE-BLOCK-START
"""Adaptive residual-value bin-choice rule.

The rule keeps an online histogram of past item sizes and builds an estimate of
how "fillable" a leftover capacity is.  A bin is scored by the estimated future
value of the residual it would leave after receiving the current item, blended
with a tightest-fit term.  This adapts to the running item-size distribution
instead of assuming a fixed parametric shape.
"""
import numpy as np

_CAP = 100
_NBINS_HIST = 101
# Laplace-style smoothing so empty/small bins do not dominate early on.
_ALPHA = 0.5

# Module-level state (persists between calls within an instance).
_hist = np.full(_NBINS_HIST, _ALPHA, dtype=np.float64)
_total = float(_NBINS_HIST * _ALPHA)


def _fill_value(r):
    """Estimate expected number of future items that can still fit in residual r.

    Uses the current smoothed empirical item-size distribution.  A residual r
    can accept any future item of size <= r; scaled by how often such items occur.
    """
    r = int(r)
    if r <= 0:
        return 0.0
    # Probability mass of future items that fit in residual r.
    fit_mass = float(_hist[1:r + 1].sum()) / _total
    # Expected usable volume: mass * capacity, with a mild concavity via sqrt-like
    # scaling to reward balanced rather than all-or-nothing residuals.
    return fit_mass * (r ** 0.5)


def priority(item, bins):
    """Return a score per bin; item goes to the highest (first on ties)."""
    global _total

    # Update online size histogram with the observed item.
    if 1 <= item <= _CAP:
        _hist[item] += 1.0
        _total += 1.0

    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    for i in range(n):
        b = int(bins[i])
        residual = b - item
        if residual < 0:
            # Should not happen (harness only shows fitting bins), but be safe.
            scores[i] = -1e18
            continue
        # Value of the leftover capacity for future packing.
        v = _fill_value(residual)
        # Tightest-fit tie-break: smaller residual preferred.
        tight = -float(residual)
        scores[i] = v + 0.15 * tight

    return scores
# EVOLVE-BLOCK-END
