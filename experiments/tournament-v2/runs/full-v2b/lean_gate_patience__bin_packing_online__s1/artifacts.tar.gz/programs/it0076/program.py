# EVOLVE-BLOCK-START
"""Best-fit bin choice with a strong perfect-fill preference.

Primary rule: minimize the post-placement residual (classic best-fit / tightest fit).
To sharpen it, exact/near-exact fills (residual 0, then small residuals) are boosted
so that whenever an item can complete a bin (or come very close), it does so; this is
what most reduces the final bin count. Ties among otherwise equal residuals prefer the
bin with the largest pre-placement capacity (least full), keeping emptier bins free.
"""
import numpy as np

def priority(item, bins):
    b = np.asarray(bins, dtype=np.int64)
    residual = b - item
    # Strongly prefer perfect fills, then near-perfect fills, then best-fit.
    # Encode as a tiered bonus on top of the best-fit primary key.
    perfect = (residual == 0).astype(np.float64)
    near = (residual <= 3).astype(np.float64) * (1.0 - perfect)
    primary = -residual.astype(np.float64)
    score = primary + 1000.0 * perfect + 5.0 * near + 1e-6 * b
    return score
# EVOLVE-BLOCK-END
