# EVOLVE-BLOCK-START
"""Weibull residual-fillability bin choice rule.

Idea: items are i.i.d. from a fixed Weibull-shaped distribution with mean 40.
For a bin with remaining capacity r (after the item is placed), define a value
G(r) = expected number of future items that can be packed starting from residual
capacity r, using the item-size distribution.  G is increasing and convex-ish;
we score each bin by G(r - item).  A tightest-fit tie-break term (smaller
residual preferred) is blended in.

G(r) is computed once on a grid of integer residual capacities 0..100 by a
dynamic program over the (discretized) item-size distribution:

    G(r) = max( G(r-1),  sum_s P(s) * (1 + G(r - s)) )   for s <= r

Actually we use a simple greedy fill expectation: for residual r, the expected
number of items ~ r / mean, but accounting for the fact that small residuals
can only hold small items, we integrate the distribution.  We approximate the
expected number of items packable from residual r by a "fractional" continuous
relaxation:

    G(r) = E[ number of iid items whose cumulative sum <= r ].

That is a renewal-type quantity.  We compute it via DP on integer sizes with
the discrete pmf, which is exact for the "sum of items <= r" count with a
greedy (best-fit-decreasing-on-the-fly) fill of a single bin.
"""
import numpy as np

_CAP = 100
_N = 5000

# ---------------------------------------------------------------------------
# Build the item-size pmf (Weibull-shaped, mean ~ 40) once at import time.
# ---------------------------------------------------------------------------
def _build_pmf():
    # Weibull with shape k and scale lam such that mean = 40.
    # Try a few shapes; typical bin-packing benchmark uses mean ~40 with
    # a right tail.  We use scipy if available, else a hand-rolled sampler.
    try:
        from scipy.stats import weibull_min
        for k in (1.5, 1.6, 1.7, 1.8, 2.0):
            c = weibull_min(k)
            m = c.mean()
            lam = 40.0 / m
            # sample on integer grid 1..100
            xs = np.arange(1, _CAP + 1)
            cdf = c.cdf((xs + 0.5) / lam) - c.cdf((xs - 0.5) / lam)
            cdf = np.clip(cdf, 1e-12, None)
            cdf /= cdf.sum()
            # only accept if this looks reasonable (no huge mass at 100)
            if cdf[-1] < 0.05:
                return cdf.astype(np.float64), k, lam
        return cdf.astype(np.float64), k, lam
    except Exception:
        pass

    # Fallback: discretized approximation without scipy.
    # Weibull(k=1.8) with mean 40: lambda = 40 / Gamma(1+1/k).
    # Approximate Gamma(1+1/k) ~ 0.89 for k=1.8.
    k = 1.8
    lam = 40.0 / 0.8887
    xs = np.arange(1, _CAP + 1)
    pdf = (k / lam) * (xs / lam) ** (k - 1) * np.exp(-(xs / lam) ** k)
    pdf = np.clip(pdf, 1e-12, None)
    pdf /= pdf.sum()
    return pdf.astype(np.float64), k, lam


_PMF, _K, _LAM = _build_pmf()
_SIZES = np.arange(1, _CAP + 1)

# ---------------------------------------------------------------------------
# Expected number of items packable from a residual capacity r.
# G[r] = expected count of iid items, packed greedily, whose total <= r.
# Use DP: treat the single-bin process.  A continuous renewal approximation:
#   G(r) = sum_{s<=r} P(s) * (1 + G(r - s))   scaled --- but that overcounts
# because the "expected count" isn't a simple recursion (choice of which item).
# We instead simulate the *greedy expected fill*: pack items in increasing size
# order (best case for maximizing count), which is a good proxy for value.
#
# Simpler & robust: for residual r, define f(r) = E[#items with cumulative sum
# <= r] under the true distribution, using the fact that for a renewal process
# the expected count satisfies  G(r) = sum_s P(s) * (1 + G(r-s))  where we take
# the max over "use this item as the next one" --- this is the standard renewal
# recursion and is correct for the expected number of renewals <= r.
# ---------------------------------------------------------------------------
def _build_value():
    G = np.zeros(_CAP + 1, dtype=np.float64)
    # G[r] = sum_{s=1..r} P(s) * (1 + G[r - s])
    # This is the renewal function (expected number of items whose cumulative
    # sum is <= r).  Compute by increasing r.
    for r in range(1, _CAP + 1):
        ss = _SIZES[:_]  # sizes 1..100
        mask = ss <= r
        s = ss[mask]
        p = _PMF[mask]
        vals = G[r - s]
        G[r] = float(np.dot(p, 1.0 + vals))
    # Normalize by nothing; it's already an expected count.
    return G


_G = _build_value().astype(np.float64)

# Tightest-fit strength.
_TF_WEIGHT = 0.35


def priority(item, bins):
    """Score each bin by residual fillability G(r - item) minus tightest-fit.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    bins = np.asarray(bins, dtype=np.int64)
    resid = bins - item
    # clamp for safety
    resid = np.clip(resid, 0, _CAP)
    g = _G[resid]
    # Tightest-fit: prefer smaller residual, expressed on the same scale.
    # G is roughly linear with slope ~1/mean ~ 0.025 per unit residual,
    # so convert the tightest-fit preference to comparable magnitude.
    tf = -(resid.astype(np.float64)) * 0.025 * _TF_WEIGHT
    return g + tf
# EVOLVE-BLOCK-END
