# EVOLVE-BLOCK-START
"""Best-fit with an empirical two-step (pairing) reuse tie-breaker.

Best-fit (minimize leftover capacity) stays the dominant signal.  Among bins
with equal or near-equal residual we break ties using an online empirical size
distribution: prefer a residual that is a frequent item size (so it can be
paired tightly later) and that has high probability of being fillable by a
future item.  All statistics come only from items already seen.
"""
import numpy as np

_CAP = 100
_NBINS_HIST = 101
_ALPHA = 0.5
_BESTFIT_W = 8.0
_REUSE_W = 1.0
_PAIR_W = 0.6
_DEAD_W = 0.5

_hist = np.full(_NBINS_HIST, _ALPHA, dtype=np.float64)
_total = float(_NBINS_HIST * _ALPHA)
_min_item = None
_cdf = None
_pmf = None


def _refresh():
    global _cdf, _pmf
    _pmf = _hist / _total
    _cdf = np.cumsum(_hist) / _total


def priority(item, bins):
    """Return a score per bin; item goes to the highest (first on ties)."""
    global _total, _min_item

    if 1 <= item <= _CAP:
        _hist[item] += 1.0
        _total += 1.0
        if _min_item is None or item < _min_item:
            _min_item = item
        _refresh()

    if _cdf is None:
        _refresh()

    b = bins.astype(np.float64)
    residual = b - float(item)  # capacity left after placing the item

    # Dominant: best-fit, smaller residual preferred.
    scores = -_BESTFIT_W * residual

    idx = np.clip(residual.astype(np.int64), 0, _CAP)
    fits = residual > 0

    # Survival: probability a future item fits into this residual.
    reuse = _cdf[idx]
    # Pairing: residual itself is a frequent size -> good tight combination.
    pair = _pmf[idx]

    scores += np.where(fits, _REUSE_W * reuse + _PAIR_W * pair, 0.0)

    # Perfect fill: strongly reward.
    scores = np.where(residual == 0, scores + 3.0, scores)

    # Mild dead-space penalty for residuals too small to ever be filled.
    if _min_item is not None:
        dead = (residual > 0) & (residual < _min_item)
        scores -= np.where(dead, _DEAD_W, 0.0)

    # Infeasible bins (item doesn't fit) must never be chosen.
    scores = np.where(residual >= 0, scores, -1e18)

    return scores
# EVOLVE-BLOCK-END
