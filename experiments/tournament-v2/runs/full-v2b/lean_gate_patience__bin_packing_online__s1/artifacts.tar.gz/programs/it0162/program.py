# EVOLVE-BLOCK-START
"""Best-fit with a learned fillability tie-break on the residual."""
import numpy as np

# Approximate Weibull-shaped item distribution, mean ~40, over sizes 1..100.
# Build a discrete frequency table once at import time.
_rng = np.random.default_rng(12345)
# Weibull with shape ~1.5 scaled to give mean ~40.
_shape = 1.5
_scale = 40.0 / 0.9027452929  # Gamma(1+1/shape) for shape=1.5
_samples = _rng.weibull(_shape, 200000) * _scale
_ints = np.clip(np.round(_samples).astype(np.int64), 1, 100)
_freq = np.bincount(_ints, minlength=101).astype(np.float64)
_freq /= _freq.sum()
_cum = np.cumsum(_freq)  # _cum[s] = P(size <= s)

# Value of a residual r: probability that some single future item exactly fills it,
# plus bonus for residuals that are within reach of common sizes.
# Exact-fill probability is _freq[r]; we add a smooth term based on proximity of
# common item sizes to r so that near-fillable residuals are preferred.
_sizes = np.arange(1, 101)
def _make_g():
    g = np.zeros(101, dtype=np.float64)
    for r in range(101):
        exact = _freq[r] if 1 <= r <= 100 else 0.0
        # proximity: sum over common sizes s of freq[s] * exp(-((r-s)/2)^2)
        diff = (_sizes - r) / 2.0
        prox = np.dot(_freq[1:101], np.exp(-diff * diff))
        g[r] = exact + 0.5 * prox
    return g

_G = _make_g()
# Scale factor converts fillability into a tie-break magnitude (sub-unit).
_SCALE = 0.9


def priority(item, bins):
    residual = bins - item  # always >= 0 for the bins we are shown
    residual = np.where(residual < 0, 0, residual)
    fill = _G[residual]
    # Primary: smallest residual (best-fit). Secondary: largest fillability.
    return -residual + _SCALE * fill
# EVOLVE-BLOCK-END

