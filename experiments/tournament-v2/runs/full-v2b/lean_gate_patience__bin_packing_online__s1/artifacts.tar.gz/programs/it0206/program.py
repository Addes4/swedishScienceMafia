# EVOLVE-BLOCK-START
"""Adaptive residual-target packing: aim each bin's post-placement residual at a running
estimate of the mean item size, learned online from the arriving items."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0


_s = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Update running mean of observed items.
    _s.n += 1
    _s.mean += (item - _s.mean) / _s.n

    residual = bins - item
    # Target residual: roughly half the mean item size, so a bin is left with room
    # for about one more average item rather than overflowing into waste.
    target = 0.5 * _s.mean
    # Prefer residual close to target (both too tight and too loose are penalized),
    # with a small best-fit tie-breaker.
    return -np.abs(residual - target) - 1e-3 * residual
# EVOLVE-BLOCK-END
