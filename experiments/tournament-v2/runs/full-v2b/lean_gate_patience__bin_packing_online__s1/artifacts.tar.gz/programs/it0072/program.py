# EVOLVE-BLOCK-START
"""Best-fit bin choice with an adaptive reusable-residual tie-break.

Primary rule: minimize the post-placement residual (classic best-fit / tightest fit),
which is the strongest known rule here. Ties are common when many empty bins
(residual 100) are present, so the tie-break matters: among bins achieving the
minimal residual, prefer the bin whose leftover residual is likely reusable for a
future item. Instead of guessing a Weibull shape, we maintain an online histogram
of the item sizes seen so far (with a small uniform prior so early items still get
sensible scores), and reward residuals that match a common item size.
If the tie-break is inconclusive, fall back to the least-full bin.
"""
import numpy as np

_SIZE = 101

# Online item-size histogram with a small uniform prior.
_COUNT = np.ones(_SIZE, dtype=np.float64)
_TOTAL = _SIZE - 1.0

def priority(item, bins):
    global _TOTAL
    # Update the running distribution with the new item.
    _COUNT[item] += 1.0
    _TOTAL += 1.0

    b = np.asarray(bins, dtype=np.int64)
    residual = b - item

    # Primary: minimize post-placement residual (best / tightest fit).
    primary = -residual.astype(np.float64)

    # Reusability of the leftover capacity: probability that some item size equals
    # the residual (or fills it exactly, i.e. residual 0).
    prob = _COUNT / _TOTAL
    match = prob[np.clip(residual, 0, _SIZE - 1)]
    match = match + 0.5 * prob[np.clip(residual + item, 1, _SIZE - 1)]

    # Least-full tie-break: larger pre-placement capacity is preferred.
    score = primary + 1e-2 * match + 1e-6 * b
    return score
# EVOLVE-BLOCK-END
