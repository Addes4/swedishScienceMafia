# EVOLVE-BLOCK-START
"""Best-fit with an online empirical-distribution reusable-residual bonus.

The dominant signal is classic best-fit (minimize leftover capacity).  A small
secondary term rewards residuals that the running empirical size distribution
says are likely to be reused by a future item, using a cumulative (survival)
estimate rather than a single-bin point mass, and mildly penalizes residuals
below the smallest item size observed so far (dead space).
"""
import numpy as np

_CAP = 100
_NBINS_HIST = 101
_ALPHA = 0.5
_BESTFIT_W = 4.0
_REUSE_W = 1.0
_DEAD_W = 1.0

_hist = np.full(_NBINS_HIST, _ALPHA, dtype=np.float64)
_total = float(_NBINS_HIST * _ALPHA)
_min_item = None


def priority(item, bins):
    """Return a score per bin; item goes to the highest (first on ties)."""
    global _total, _min_item

    if 1 <= item <= _CAP:
        _hist[item] += 1.0
        _total += 1.0
        if _min_item is None or item < _min_item:
            _min_item = item

    b = bins.astype(np.float64)
    residual = b - float(item)  # capacity left after placing the item

    # Dominant: best-fit, smaller residual preferred.
    scores = -_BESTFIT_W * residual

    # Cumulative fraction of past items with size <= residual: probability
    # that some future item fits into this residual.
    cdf = np.cumsum(_hist) / _total
    idx = np.clip(residual.astype(np.int64), 0, _CAP)
    reuse = cdf[idx]

    fits = residual > 0
    scores += np.where(fits, _REUSE_W * reuse, 0.0)

    # Perfect fill: strongly reward.
    scores = np.where(residual == 0, scores + 3.0, scores)

    # Mild dead-space penalty for residuals too small to ever be filled.
    if _min_item is not None:
        dead = (residual > 0) & (residual < _min_item)
        scores -= np.where(dead, _DEAD_W, 0.0)

    # Infeasible bins (item doesn't fit) must never be chosen.
    scores = np.where(residual >= 0, scores, -1e18)

    return scores
# EVOLVE-BLOCK-END

