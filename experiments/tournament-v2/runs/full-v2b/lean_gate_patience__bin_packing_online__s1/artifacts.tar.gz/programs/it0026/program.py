# EVOLVE-BLOCK-START
"""Best-fit bin packing with an online-adaptive residual-usefulness bonus.

Core rule is best-fit: prefer the fitting bin that leaves the smallest
non-negative residual.  A secondary, learned term rewards residuals that are
still large enough to fit a typical future item (tracked online via a running
histogram of observed sizes), so placements that lock a bin into an unusably
small gap are slightly discouraged.
"""
import numpy as np

# Running counts of past item sizes (index = size).  Bins of the size axis.
_SIZE = 101
_counts = np.zeros(_SIZE, dtype=np.float64)
_total = 0.0
_typical = 40.0  # running estimate of a high-ish quantile of item sizes


def _update(item):
    global _total, _typical
    _counts[item] += 1.0
    _total += 1.0
    # Cheap exponential update of a "typical large item" threshold: track an
    # upper-middle quantile of observed sizes.  Use a smooth max-style tracker.
    if _total <= 1.0:
        _typical = float(item)
    else:
        # Nudge toward item when item is above the current estimate, less so when
        # below (this approximates a ~75th percentile of the distribution).
        if item > _typical:
            _typical += 0.20 * (item - _typical)
        else:
            _typical += 0.02 * (item - _typical)


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest score."""
    _update(item)

    residual = bins - item  # >= 0 for all shown bins

    # Dominant best-fit term: smaller residual -> larger score.
    scores = 1.0 / (residual + 1.0)

    # Secondary usefulness term: a residual that can still hold a typical future
    # item is more valuable than one that cannot.  Reward residuals >= typical.
    # Smooth, bounded, and strictly smaller in magnitude than the best-fit gaps.
    useful = np.minimum(residual, _typical) / (_typical + 1.0)  # in [0,1)
    scores = scores + 0.02 * useful

    # Very mild preference to reuse already-open bins over fresh (empty) ones.
    scores = scores - 1e-6 * bins
    return scores
# EVOLVE-BLOCK-END
