# EVOLVE-BLOCK-START
"""Best-fit with a small structural bonus for leaving a "consumable" residual.

Weibull-ish sizes have mean about 40.  Pure best fit leaves many arbitrary
residuals that no future item can exactly fill, wasting space.  Here we score
each candidate bin by its fill fraction after placing the item (best fit), plus
a small bonus when the resulting residual is a value that a typical future item
could plausibly close exactly, encouraging bins to be sealed off rather than
left dangling.  Bonus magnitude is kept small so it does not perturb the
dominant best-fit behaviour.
"""
import numpy as np

# Residuals that a single typical future item could exactly fill (cheap cover
# of the bulk of the Weibull mass around the mean of ~40).
_GOOD_RESIDUALS = np.zeros(101, dtype=np.float64)
for _r in range(1, 101):
    # Favour residuals in the "one typical item" band, tapering at the edges.
    if 35 <= _r <= 55:
        _GOOD_RESIDUALS[_r] = 1.0
    elif 20 <= _r < 35 or 55 < _r <= 75:
        _GOOD_RESIDUALS[_r] = 0.5


def priority(item, bins):
    residual = bins.astype(np.float64) - item
    np.clip(residual, 0.0, 100.0, out=residual)

    # Fill fraction after placing the item: higher is better (best fit).
    fill = (100.0 - residual) / 100.0

    # Tiny bonus for leaving a residual a typical future item can close.
    good = _GOOD_RESIDUALS[residual.astype(np.int64)]

    # Slight bonus for reusing an open bin rather than a fresh one.
    open_bonus = np.where(bins < 100, 0.02, 0.0)

    return fill + 0.005 * good + open_bonus
# EVOLVE-BLOCK-END
