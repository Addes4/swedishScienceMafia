# EVOLVE-BLOCK-START
"""Best-fit with adaptive reusable-residual tie-break.

Primary rule stays best-fit: the bin with the smallest residual after placing
the item wins.  On exact residual ties we prefer the bin whose leftover
capacity matches a commonly seen item size (so the gap can be filled exactly
later), and, failing that, the least-full bin.  A cheap running size histogram
adapts to the (unknown) instance distribution without seeing the future.
"""
import numpy as np

# Static component of the value function: a coarse "reusable residual" table.
_SIZE_BINS = 101


def priority(item, bins):
    global _hist
    try:
        _hist
    except NameError:
        _hist = np.zeros(_SIZE_BINS, dtype=np.float64)

    r = (bins - item).astype(np.int64)
    r = np.where(r < 0, 0, r)

    # Reuse value of each distinct post-placement residual: how often that
    # exact size has been observed as an item recently.
    reuse = _hist[r]

    # Score: best-fit dominant (smaller residual better), then reusable
    # residual, then least-full bin.
    score = -r.astype(np.float64) * 1e6 + reuse * 1e3 + bins.astype(np.float64)

    # Update histogram with the current item for future calls.
    _hist[item] += 1.0

    return score
# EVOLVE-BLOCK-END
