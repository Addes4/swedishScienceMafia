# EVOLVE-BLOCK-START
"""Learned-style bin choice: pick the bin whose residual capacity after placing the
item is most "frequently fillable" by typical future items, using a static
size-frequency model and a convex residual-value heuristic.
"""
import numpy as np

# ---- Static size-frequency model of the item distribution ----
# Weibull-shaped, mean about 40, integer sizes 1..100.
# Precompute a cheap proxy of the item size distribution: a discretized Weibull.
_WEIGHTS = None


def _build_model():
    """Discretize a Weibull(k=2, lambda=45) pmf over integer sizes 1..100."""
    global _WEIGHTS
    if _WEIGHTS is not None:
        return
    lam = 45.0
    k = 2.0
    sizes = np.arange(1, 101, dtype=np.float64)
    pdf = (k / lam) * (sizes / lam) ** (k - 1.0) * np.exp(-(sizes / lam) ** k)
    pdf = np.maximum(pdf, 0.0)
    # Normalize (truncated distribution)
    if pdf.sum() <= 0:
        pdf = np.ones_like(pdf)
    _WEIGHTS = pdf / pdf.sum()


def _residual_value(r):
    """Convex value of a residual capacity r (0..100).

    We reward residual capacity that is around common item sizes (so that a
    future typical item can slot in). Small useless leftovers are penalized,
    full bins (r=0) are assigned a very low value, and a fresh bin (r=100) is
    mildly penalized to discourage opening new bins unnecessarily.
    """
    _build_model()
    # probability mass of item sizes <= r (a future item fits with this prob.)
    fit_mass = float(_WEIGHTS[:r].sum()) if r > 0 else 0.0
    # Convex term: quadratic utility in "fillability" of the residual, scaled
    # by how tight the leftover is. A residual that exactly matches common
    # item sizes gets a big boost.
    # Peaked bonus around typical sizes (~40).
    common = 40.0
    peak = np.exp(-((r - common) ** 2) / (2.0 * 25.0 ** 2))
    # Slight preference for larger reusable residuals, but convex to avoid
    # leaving many tiny useless slivers.
    usable = fit_mass * (0.5 + peak)
    # value drops for near-empty residuals
    return usable + 0.02 * r


def priority(item, bins):
    """Score each bin by expected usefulness of its residual after this item."""
    r = bins.astype(np.int64) - item
    # Vectorize the residual value over all candidate residuals.
    r_clip = np.clip(r, 0, 100)
    _build_model()
    cum = np.concatenate(([0.0], np.cumsum(_WEIGHTS)))  # cum[r] = mass of sizes <= r
    fit_mass = cum[r_clip]
    common = 40.0
    peak = np.exp(-((r_clip - common) ** 2) / (2.0 * 25.0 ** 2))
    usable = fit_mass * (0.5 + peak)
    val = usable + 0.02 * r_clip
    # Very low value for exactly full bins.
    val = np.where(r_clip == 0, -1.0, val)
    return val
# EVOLVE-BLOCK-END

