"""Best-fit blended with a fillability reward on the residual."""

import numpy as np


# Precompute a concave "fillability" reward over residual capacities.
_RES = np.arange(0, 101, dtype=np.float64)
# Reward small residuals (near-exact fits) but don't punish moderate ones too hard.
_REWARD = np.log1p(_RES)


def priority(item, bins):
    residual = bins - item
    # Primary: tightest fit (smallest residual). Secondary: prefer residuals
    # that can still usefully absorb future items (concave reward).
    r = residual.astype(np.float64)
    reward = np.log1p(r)
    return -r + 0.05 * reward
