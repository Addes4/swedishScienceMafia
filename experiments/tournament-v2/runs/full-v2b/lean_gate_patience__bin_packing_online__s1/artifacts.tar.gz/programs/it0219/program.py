# EVOLVE-BLOCK-START
"""Best-fit rule with tie-break bonuses for residuals that can be cleanly
closed by one or two future items.

Items arrive one at a time; we pick the bin whose remaining capacity after
placing the item (the residual) is smallest, i.e. classic best fit.  A tiny
bonus is added for residuals that equal a likely single future item size or a
likely sum of two future item sizes, which makes the tie-breaking robust on the
Weibull-shaped distribution (mean about 40).
"""
import numpy as np

_sizes = np.arange(1, 101, dtype=np.float64)

def _weibull_pmf(shape, scale):
    cdf_hi = 1.0 - np.exp(-((_sizes + 0.5) / scale) ** shape)
    cdf_lo = 1.0 - np.exp(-((_sizes - 0.5) / scale) ** shape)
    pmf = np.clip(cdf_hi - cdf_lo, 0.0, None)
    pmf[0] = 1.0 - np.exp(-(0.5 / scale) ** shape)
    pmf = pmf / pmf.sum()
    return pmf

_SHAPE = 1.6
scale = 40.0
pmf = _weibull_pmf(_SHAPE, scale)
for _ in range(80):
    pmf = _weibull_pmf(_SHAPE, scale)
    mean = float(np.dot(_sizes, pmf))
    if abs(mean - 40.0) < 0.02:
        break
    if mean < 40.0:
        scale *= 1.005
    else:
        scale *= 0.995
_ITEM_PMF = pmf

# Bonus table for residuals 1..100: probability that a future item exactly
# fills the residual (single-item closure).
_BONUS1 = np.zeros(101, dtype=np.float64)
_BONUS1[1:101] = _ITEM_PMF[0:100]

# Probability that the residual equals the sum of exactly two future item
# sizes (two-item closure).  Convolve the pmf with itself.
_two = np.convolve(_ITEM_PMF, _ITEM_PMF)
# Cap at residual 100; entries correspond to sums 2..200.
_BONUS2 = np.zeros(101, dtype=np.float64)
_hi = min(100, _two.shape[0] - 1)
_BONUS2[2:_hi + 1] = _two[1:_hi]  # sum s -> index s, _two index (s-2)... careful below

# Recompute cleanly: _two[k] corresponds to sum (k+2) since sizes >=1.
_BONUS2 = np.zeros(101, dtype=np.float64)
for k in range(_two.shape[0]):
    s = k + 2
    if 2 <= s <= 100:
        _BONUS2[s] = _two[k]

# Weight of the tie-break bonuses relative to the best-fit term.
_W1 = 0.05
_W2 = 0.02

def priority(item, bins):
    """Choose the tightest-fit bin, breaking ties toward closable residuals."""
    residual = bins - item  # >= 0 for all bins shown
    r = np.clip(residual, 0, 100).astype(np.int64)
    bonus = _W1 * _BONUS1[r] + _W2 * _BONUS2[r]
    # Dominant term: prefer smallest residual (best fit).
    return -residual.astype(np.float64) + bonus
# EVOLVE-BLOCK-END
