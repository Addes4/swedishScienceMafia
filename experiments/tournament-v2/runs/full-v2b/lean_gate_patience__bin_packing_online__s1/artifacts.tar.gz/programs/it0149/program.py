# EVOLVE-BLOCK-START
"""Static Weibull size-frequency residual-value rule for online bin packing.

Idea: items are drawn from a fixed Weibull-shaped distribution (mean ~40). We precompute
that distribution once, then define a convex "fillability" value G(r) = expected amount of
useful capacity realizable from a residual capacity of r, under the item distribution. A bin
is scored by the value of the residual it leaves after placing the arriving item, blended
with a tightest-fit term. The convexity of G rewards leaving residuals that future items can
pack efficiently, reducing the number of bins used.
"""
import numpy as np

# ---------------------------------------------------------------------------
# Precompute the item-size distribution and the value function G(r).
# ---------------------------------------------------------------------------

def _build_distribution():
    """Discretized pmf over item sizes 1..100 from a Weibull-shaped distribution."""
    sizes = np.arange(1, 101, dtype=float)

    # We chose a Weibull-like shape whose mean is ~40. With loc=0, scale=lam,
    # shape=k, mean = lam * Gamma(1 + 1/k). Try a family and pick the one whose
    # discretized mean is closest to 40.
    best = None
    for k in np.linspace(1.4, 4.0, 131):
        g = np.exp(_gammaln_scalar(1.0 + 1.0 / k))
        lam = 40.0 / g
        # pdf of Weibull(k, lam)
        pdf = (k / lam) * (sizes / lam) ** (k - 1.0) * np.exp(-(sizes / lam) ** k)
        p = pdf / pdf.sum()  # normalize over integer support 1..100
        mean = float((p * sizes).sum())
        err = abs(mean - 40.0)
        if best is None or err < best[0]:
            best = (err, p)
    return best[1]


def _gammaln_scalar(x):
    """Lanczos approximation to log(Gamma(x)) for x > 0; standard library only."""
    import math
    return math.lgamma(x)


_P = _build_distribution()          # pmf over sizes 1..100 (indices 0..99 for size 1..100)
_CDF = np.cumsum(_P)                # CDF over size <= s
_TAIL = 1.0 - _CDF                  # P(size > s)

# expected size of an item, conditioned on being > s (for the fillability recursion)
_E_TAIL = np.zeros(101, dtype=float)   # _E_TAIL[s] = E[size | size > s] for s = 0..99
for s in range(0, 100):
    tail_prob = _TAIL[s]
    if tail_prob > 1e-12:
        weights = _P[s:]  # sizes s+1 .. 100 correspond to indices s..99
        sizes_tail = np.arange(s + 1, 101, dtype=float)
        _E_TAIL[s] = float((weights * sizes_tail).sum() / tail_prob)
    else:
        _E_TAIL[s] = 0.0
# for s = 100 there are no larger items
_E_TAIL_100 = 0.0


def _build_value():
    """G[r] = expected realizable capacity from a residual capacity r (convex in r).

    Recursion intuition: with residual r, the next item size s ~ P restricted to s <= r.
    If no item fits, the residual is wasted (value 0). Otherwise we gain s and continue
    with residual r - s, whose value is G[r - s]. This yields the expected total packed
    into a single bin starting from residual r, which is convex-ish in r and rewards
    leaving residuals that future items can fill.
    """
    G = np.zeros(101, dtype=float)
    # G[0] = 0. Build up for r = 1..100.
    # Use a softmax-like expectation but sharpen so it stays stable & fast.
    for r in range(1, 101):
        # probability mass of sizes <= r
        p_fit = _P[:r]                      # sizes 1..r
        total = p_fit.sum()
        if total <= 1e-12:
            G[r] = 0.0
            continue
        sizes_fit = np.arange(1, r + 1, dtype=float)
        # expected gain if some item fits (weighted by conditional pmf)
        cond = p_fit / total
        val = 0.0
        for i in range(r):
            s = i + 1
            val += cond[i] * (s + G[r - s])
        G[r] = val
    return G


_G = _build_value()


def priority(item, bins):
    """Score bins by the fillability of the residual left after placing `item`.

    Highest score wins (first bin on ties). Blends the residual value G with a
    tightest-fit term to break ties toward snug placements.
    """
    residual = bins - item                       # remaining capacity after placement
    residual = np.clip(residual, 0, 100)
    g = _G[residual.astype(np.int64)]            # value of leftover space

    # Tightest-fit term: prefer smaller residual (snug fit). Normalized to similar
    # scale as g so it acts as a tie-break / small bias rather than dominating.
    tight = -(residual.astype(np.float64)) / 100.0

    return g + 0.35 * tight
# EVOLVE-BLOCK-END
