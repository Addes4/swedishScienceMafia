# EVOLVE-BLOCK-START
"""Best-fit with a size-frequency bonus for reusable residuals.

Primary signal: best-fit (smallest residual that still fits). This is the
strongest known online rule for the Weibull-shaped mean-40 distribution.

Improvement over pure best-fit: ties and near-ties are broken/skewed by how
likely the resulting residual is to be filled exactly by a future item.
We maintain a running histogram of observed item sizes (available online, no
future peeking). A residual r is "valuable" if many past items had size r,
meaning a future item of that size can close the bin cleanly. We add a small
bonus proportional to log(1 + count[r]) so that, among comparable fits, the
bin leaving a commonly-useful hole wins. The bonus is scaled small enough to
never override a genuine best-fit advantage of more than a few units.
"""
import numpy as np

# Running histogram of observed item sizes (1..100). Initialized flat so the
# rule is well-defined before enough items have been seen.
_COUNT = np.zeros(101, dtype=np.float64)
_SEEN = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of bins the item fits in (numpy int64).
    """
    global _SEEN

    b = np.asarray(bins, dtype=np.float64)
    residual = b - item  # post-placement leftover capacity, >= 0

    # Value of leaving residual r: how often items of size r have appeared.
    # log1p keeps it bounded and monotone in frequency.
    freq = np.log1p(_COUNT[residual.astype(np.int64)])
    # Normalize to a modest range so it only skews near-ties.
    freq = freq / (np.log1p(_SEEN + 1.0) + 1e-9)

    # Primary: best-fit -> smaller residual scores much higher.
    # Secondary: prefer residuals matching common item sizes.
    score = -residual * 1000.0 + 50.0 * freq - 1e-3 * b

    # Update histogram with the item we just placed (online, no future info).
    _COUNT[item] += 1.0
    _SEEN += 1

    return score
# EVOLVE-BLOCK-END
