"""Static Weibull residual-fillability rule with a tightest-fit blend."""

import numpy as np

# ---------------------------------------------------------------------------
# Precompute the Weibull item-size distribution with mean ~40 (integer 1..100).
# Weibull shape k, scale lam. mean = lam * Gamma(1 + 1/k). We solve for lam so
# that the mean (with mass truncated/rounded onto 1..100) equals ~40.
# ---------------------------------------------------------------------------
_SHAPE = 2.0  # Weibull shape parameter (k > 1 gives a mid-heavy single mode)


def _gamma_fn(x):
    # Lanczos approximation for the gamma function (avoids scipy dependency).
    g = 7
    coef = [
        0.99999999999980993,
        676.5203681218851,
        -1259.1392167224028,
        771.32342877765313,
        -176.61502916214059,
        12.507343278686905,
        -0.13857109526572012,
        9.9843695780195716e-6,
        1.5056327351493116e-7,
    ]
    x = x - 1
    a = coef[0]
    t = x + g + 0.5
    for i in range(1, g + 2):
        a += coef[i] / (x + i)
    return np.sqrt(2 * np.pi) * t ** (x + 0.5) * np.exp(-t) * a


# Build the item-size pmf on integer sizes 1..100.
_SIZES = np.arange(1, 101, dtype=np.float64)
_K = _SHAPE

# Choose scale so that the discrete mean equals ~40.
_lam = 44.0
for _ in range(60):
    cdf = 1.0 - np.exp(-(_SIZES / _lam) ** _K)
    pdf = np.diff(np.concatenate(([0.0], cdf)))
    pdf = np.clip(pdf, 0.0, None)
    tot = pdf.sum()
    if tot <= 0:
        break
    pdf = pdf / tot
    mean = np.dot(pdf, _SIZES)
    # d(mean)/d(lam) is roughly mean/lam; Newton-ish update toward 40.
    if abs(mean - 40.0) < 1e-6:
        break
    _lam *= (40.0 / mean) ** 0.999
    _lam = float(np.clip(_lam, 1.0, 1000.0))

cdf = 1.0 - np.exp(-(_SIZES / _lam) ** _K)
_pmf = np.diff(np.concatenate(([0.0], cdf)))
_pmf = np.clip(_pmf, 0.0, None)
_pmf = _pmf / _pmf.sum()

# ---------------------------------------------------------------------------
# Value function G(r): expected "fillability" of a bin with residual capacity r.
# A residual r is valuable if it can still absorb typical items well. We define
# G(r) as the expected size of a random item conditioned on it fitting in r,
# scaled up by the probability that some item fits. Convex-ish and monotone in
# r, this rewards placing an item such that the leftover residual is "useful".
# ---------------------------------------------------------------------------
_CAP = 100.0
_R = np.arange(0, 101, dtype=np.float64)

# Probability that a random item fits into residual r.
_fit_prob = np.array([float(np.dot(_pmf, (_SIZES <= r).astype(np.float64))) for r in _R])
# Expected fitted item size given it fits; 0 if nothing fits.
_exp_fit = np.array([
    float(np.dot(_pmf * _SIZES, (_SIZES <= r).astype(np.float64)))
    for r in _R
])
# G(r) = expected usable size actually consumable from residual r.
_G = np.where(_fit_prob > 0, _exp_fit, 0.0)
# Add a mild convex term rewarding residuals that are near "just enough" for
# another typical item: bonus for residual in the typical item range.
_G = _G + 0.15 * _fit_prob * _exp_fit
# Enforce monotone non-decreasing.
_G = np.maximum.accumulate(_G)

_G_arr = _G.astype(np.float64)


def priority(item, bins):
    """Score bins by residual fillability after placing the item, plus tightest fit."""
    residual = bins - item  # residual capacity after placing (>= 0 for shown bins)
    residual_clipped = np.clip(residual, 0, 100).astype(np.int64)
    val = _G_arr[residual_clipped]
    # Blend with a tightest-fit term: prefer smaller post-placement residual.
    tight = -residual.astype(np.float64)
    return val + 0.35 * tight
