# EVOLVE-BLOCK-START
"""Best-fit augmented with a residual-value correction.

Primary rule: best fit (place in the bin whose post-placement residual is
smallest), which packs densely.  To mitigate the main weakness of greedy
best-fit -- stranding a medium residual that can no longer accept a typically
sized item -- we add a small correction that slightly penalizes residuals
lying in a "dead zone" near the running mean item size, biasing the choice
toward residuals that remain fillable.  The correction is tiny so the rule
stays essentially best-fit; it only resolves close decisions.
"""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    # Update running mean of observed items (cheap scalar state).
    st = _state
    st["sum"] += item
    st["n"] += 1
    mean = st["sum"] / st["n"]

    residual = bins - item  # post-placement residual per bin

    # Base: best fit -> smaller residual is better.
    score = -(residual.astype(np.float64))

    # Smooth "dead zone" penalty: residuals that are positive but smaller
    # than the typical item size are wasteful and block future large items,
    # so we push slightly against them relative to larger residuals.
    # penalty(r) is largest near r ~ mean/2 and fades for large r.
    r = residual.astype(np.float64)
    # Only consider residuals >= 0 (all shown bins fit, so r >= 0).
    # Gaussian bump centred at mean*0.5 with width mean*0.4.
    width = 0.4 * mean if mean > 0 else 1.0
    bump = np.exp(-((r - 0.5 * mean) ** 2) / (2.0 * width * width))
    # Penalize being in the dead zone (subtract from score).
    lam = 0.5
    score -= lam * bump

    return score
# EVOLVE-BLOCK-END
