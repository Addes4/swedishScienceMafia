# EVOLVE-BLOCK-START
"""Best-fit with a fullest-bin tie-break.

Pure best-fit (smallest positive post-placement residual) scores ~0.9616.
Ties in the post-placement residual are common (many bins can leave the same
leftover).  When ties occur we prefer the bin with the smallest pre-placement
remaining capacity, i.e. the fullest bin that still fits the item.  This keeps
the packing dense and reduces fragmentation without ever overriding a strictly
better fit.
"""
import numpy as np

_CAP = 100


def priority(item, bins):
    residual = (bins - item).astype(np.int64)
    # Bins that cannot fit the item get residual < 0; the harness only shows
    # fitting bins, but clamp defensively.
    np.clip(residual, -1, _CAP, out=residual)

    # Primary key: smallest post-placement residual (best fit).
    # Secondary key: smallest pre-placement remaining capacity (fullest bin).
    # We encode both into one score: larger residual strongly penalized, and
    # for equal residual a smaller 'bins' value is preferred.
    best = int(residual.min())
    score = -(residual.astype(np.float64)) - (bins.astype(np.float64)) * 1e-4
    # Push non-minimal residuals far down so best-fit strictly dominates.
    out = np.where(residual == best, score, -1e9)
    return out
# EVOLVE-BLOCK-END
