import numpy as np


def priority(item, bins):
    residual = bins - item
    # Primary: smallest post-placement residual (best-fit).
    # Tie-break: among near-equal residuals, prefer the bin that was
    # more full before placement (smaller bins[]), i.e. consolidate.
    # Use residual as primary and a small negative bonus for larger bins[]
    # so that within a residual window of 2 the fuller bin wins.
    pre = bins.astype(np.float64)
    r = residual.astype(np.float64)
    return -(r * 10.0) - pre
