import numpy as np

# ---- Precompute a Weibull-shaped item-size distribution (once) ----
# Parameters chosen to match mean ~40, shape from the problem statement.
_K = 1.3          # Weibull shape
_LAM = 44.0       # Weibull scale (mean ~ 40 for k=1.3)
_HIST = np.zeros(101, dtype=np.float64)
for _s in range(1, 101):
    _HIST[_s] = (_K / _LAM) * ((_s / _LAM) ** (_K - 1.0)) * np.exp(-((_s / _LAM) ** _K))
_HIST[0] = 0.0
_tot = _HIST.sum()
if _tot > 0:
    _HIST /= _tot

# Working histogram extended over capacity range [0, 100]
_H = _HIST[1:101].copy()  # index 0 -> size 1
_MAXS = 100

# ---- Build convex value function G(r): expected fillability of residual r ----
# G(r) = sum_{s=1..r} p(s) * (1 + G(r - s)) roughly measures future packed mass,
# but we instead want a smooth convex proxy: the expected number (or mass) of
# items the residual can still absorb. A convex increasing curve is desirable so
# that many small residuals and very large residuals are both attractive relative
# to "half-full awkward" residuals.
#
# We compute V[r] = expected weight of items still placeable in capacity r, using
# the size distribution, with a recursion on the optimal-ish continuation. This is
# expensive to do exactly; instead use a convex surrogate: 
#   G(r) = r - small_penalty_for_fragmentation(r)
# where fragmentation penalty grows where r is "hard to fill".

# Fragmentation penalty: probability that r cannot be exactly/approximately filled.
# Approximate with the CDF of a sum distribution is heavy; use a simple, monotone
# convex proxy based on the mean size: the worst residuals are those just below the
# common sizes.
mean_s = float(np.dot(np.arange(1, 101), _HIST[1:101]))
if mean_s <= 0:
    mean_s = 40.0

# Convex fillability curve: G(r) increases with slope that is small in the middle
# (hard-to-fill region) and larger at the extremes (easy large fills / tiny waste).
# Build it by accumulating per-residual expected absorbed mass with a smoothing.
_V = np.zeros(101, dtype=np.float64)
_V[0] = 0.0
for r in range(1, 101):
    # expected mass absorbed if we keep filling optimally ~ r minus expected leftover
    # expected leftover after repeatedly packing random items into capacity r
    # Approximate leftover via a geometric-ish model around mean_s.
    leftover = 0.0
    # probability mass of items larger than r that must be left as-is effectively
    # contributes to "unusable" residual; smaller items can chip away.
    # Model: usable(r) = r * (1 - exp(-r / mean_s))  is concave; we want convex.
    usable = r - mean_s * (1.0 - np.exp(-r / mean_s))
    if usable < 0:
        usable = 0.0
    _V[r] = usable

# Make it strictly convex and monotone with a small quadratic to favor tight fits
_V = _V + 1e-3 * (np.arange(101, dtype=np.float64) ** 2)

# Normalize for numerical stability
_vmax = _V[100] if _V[100] != 0 else 1.0
_V = _V / _vmax


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    residual = bins - item                      # capacity left after placing here
    np.clip(residual, 0, 100, out=residual)

    # Gain in value function from consuming part of the residual.
    before = _V[np.clip(bins, 0, 100)]
    after = _V[residual]
    gain = before - after                       # value lost by placing (cost)

    # Prefer placements that leave highly valuable residual and lose little value.
    # Score = after (fillability of leftover) minus a tightest-fit tie-break.
    score = after.astype(np.float64)

    # Tightest fit tie-break: prefer smaller residual (denser packing), scaled small.
    score -= 1e-4 * residual.astype(np.float64)

    return score
