# EVOLVE-BLOCK-START
"""Best-fit bin-choice rule with a full-bin-preserving tie-break.

Classic best-fit (place into the bin leaving the smallest non-negative residual)
is the strongest simple online rule for this distribution. We keep it exactly,
and only change behavior when several bins yield the same minimal residual.

When the minimal residual is 0 (a perfect fill), any of those zero-residual bins
is equally "tight", so we prefer the one with the *smallest* pre-placement
capacity: it is the bin that was fullest already, so consuming it costs us the
least remaining flexibility, keeping emptier bins free for large future items.
When residuals tie at a nonzero value we prefer the largest pre-placement
capacity (the emptiest such bin), reserving fuller bins for items that only just
fit there.

We implement this as a single lexicographic integer score so the primary key
(smallest residual) strictly dominates.
"""
import numpy as np


def priority(item, bins):
    """Score each bin: best-fit primary, residual-dependent tie-break.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    residual = bins - item
    pre = bins
    # Primary: smaller residual is better.
    # Secondary: if residual == 0, prefer smaller pre-placement capacity (fullest bin).
    #            otherwise, prefer larger pre-placement capacity (emptiest bin).
    # Encode with weight 101 > max capacity span (100), so primary always dominates.
    tie_pref = np.where(residual == 0, -pre, pre)
    return -(residual.astype(np.float64)) * 101.0 + tie_pref.astype(np.float64)
# EVOLVE-BLOCK-END
