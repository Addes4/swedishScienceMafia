# EVOLVE-BLOCK-START
"""Hybrid First-Fit / Best-Fit bin choice.

Empirically, classic Best-Fit scores ~0.9616 here.  Pure First-Fit tends to do
better with the large items of this Weibull distribution (it preserves big
contiguous residuals for later big items), while Best-Fit does better with the
many small items (it packs them tightly into the smallest usable gaps).  So we
combine them: large items use First-Fit (prefer the earliest bin that fits),
small items use Best-Fit (prefer the tightest fit).

The harness picks the highest score with first-index tie-breaking, so we can
encode First-Fit directly as score = -index, and Best-Fit as
score = -(residual), using bin index as the secondary criterion.
"""
import numpy as np


def priority(item, bins):
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)

    if item >= 40:
        # First-Fit: prefer the earliest bin that fits the item.
        # Score only depends on bin index (smaller index -> higher score).
        return -idx
    else:
        # Best-Fit: minimize post-placement residual; break ties by index.
        residual = bins.astype(np.float64) - float(item)
        return -residual - 1e-6 * idx
# EVOLVE-BLOCK-END
