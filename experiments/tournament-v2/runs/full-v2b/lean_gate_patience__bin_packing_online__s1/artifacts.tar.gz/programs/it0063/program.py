# EVOLVE-BLOCK-START
"""Size-frequency residual-value bin choice rule.

Instead of tightly fitting (best fit), we precompute a Weibull-shaped histogram of
typical future item sizes (mean ~40). From it we build a convex value function V(r)
that estimates how "fillable" a leftover residual of r is by the stream of common
item sizes. Each candidate bin is scored by the value of the residual it would leave
(plus a small exact-fit bonus), and the item goes to the bin maximizing that value.
"""
import numpy as np

# ---- One-time precomputation of a Weibull-shaped size histogram (mean ~40) ----
_CAP = 100
_W_SHAPE = 2.0
_W_SCALE = 45.0  # Weibull scale; with shape 2.0 gives mean ~ 45*0.886 = ~40


def _build_value_function():
    # Density over integer sizes 1..100 from a discretized Weibull.
    sizes = np.arange(1, _CAP + 1, dtype=np.float64)
    k, lam = _W_SHAPE, _W_SCALE
    # Weibull pdf
    pdf = (k / lam) * (sizes / lam) ** (k - 1.0) * np.exp(-(sizes / lam) ** k)
    pdf = np.clip(pdf, 0.0, None)
    if pdf.sum() <= 0:
        pdf = np.ones_like(sizes)
    freq = pdf / pdf.sum()

    # Convex "usable residual" value: expected best single-future-item fillability.
    # V(r) = sum_s freq[s] * f(r, s) where f rewards residuals close to a common
    # size (leaving a residual that a typical future item can nearly fill).
    V = np.zeros(_CAP + 1, dtype=np.float64)
    for r in range(1, _CAP + 1):
        s = sizes
        # How well future size s fits into residual r: min(s, r)/max(s, r) shaped
        # to be convex in r (penalize residuals that match no common size, reward
        # residuals equal to common sizes so the next item can fill them).
        ratio = np.minimum(s, r) / np.maximum(s, r)
        # Convexity: emphasize near-exact matches.
        val = ratio * ratio
        # Bonus for being able to hold a common item at all (s <= r): these bins
        # are usable; too-small residuals are much worse.
        hold = (s <= r).astype(np.float64)
        V[r] = np.sum(freq * val * (1.0 + hold))
    # Make value convex-ish increasing with residual usefulness; normalize.
    V = V / (V.max() if V.max() > 0 else 1.0)
    return V


_V = _build_value_function()


def priority(item, bins):
    """Score each bin by the fillability value of the residual it would leave.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (bins the item fits in).
    Returns a numpy array of scores, same length, no NaN.
    """
    resid = bins - item  # residual after placing item
    np.clip(resid, 0, _CAP, out=resid)
    # Value of the residual (expected future fillability).
    scores = _V[resid]
    # Small exact-fit bonus: bins that become exactly empty are already optimally
    # packed, so slightly prefer them to avoid wasting full bins.
    scores = scores + 0.02 * (resid == 0)
    return scores
# EVOLVE-BLOCK-END
