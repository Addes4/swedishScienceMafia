# EVOLVE-BLOCK-START
"""Best-fit packing rule with a sharp online learned modal-residual bonus.

The dominant term is classic best-fit: place the item into the bin with the
smallest non-negative residual (score ~ 1/(residual+1)).  A secondary term
uses an online histogram of the item sizes seen so far to reward placements
whose leftover residual exactly matches the most common future item size.
Because the size distribution is concentrated around ~40, rewarding residuals
equal to the modal size reduces fragmentation more effectively and with far
less variance than a broad kernel.
"""
import numpy as np

# Running histogram of item sizes seen so far (index 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0

# Weight of the learned modal-residual term relative to the best-fit term.
_W = 0.6


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    global _COUNT
    r = bins - item  # residual capacity if placed in each bin (>= 0 by contract)

    # Classic best-fit term: tightest residual wins.
    scores = 1.0 / (r + 1.0)

    # Learned modal-residual term: reward residuals that exactly match the most
    # common future item size (so the leftover space is likely to be useful).
    if _COUNT > 0.0:
        mode_size = int(np.argmax(_HIST))
        scores = scores + _W * (r == mode_size)

    # Mild preference for already-open (less empty) bins.
    scores = scores - 0.0001 * bins

    # Update statistics with the current item.
    _HIST[item] += 1.0
    _COUNT += 1.0

    return scores
# EVOLVE-BLOCK-END
