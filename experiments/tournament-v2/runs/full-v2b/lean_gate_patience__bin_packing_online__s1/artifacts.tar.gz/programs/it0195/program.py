"""Best-fit bin-choice rule with a light histogram-based tie-break."""

import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0


def priority(item, bins):
    global _count
    _count += 1
    decay = 0.999
    # decay the running histogram of past item sizes
    _hist *= decay
    if 0 <= item <= 100:
        _hist[item] += 1.0

    residual = bins - item

    # Primary key: best-fit (smallest residual). Scale large so it dominates.
    score = -residual.astype(np.float64) * 10000.0

    # Secondary: among equal residual, prefer residuals that are likely to be
    # exactly filled by a future item (higher histogram mass near that residual).
    resid_i = residual.astype(np.int64)
    resid_i = np.clip(resid_i, 0, 100)
    mass = _hist[resid_i]
    score += mass * 1.0

    # Tertiary: stable tie-break favoring larger pre-placement capacity.
    score -= bins.astype(np.float64) * 1e-3

    return score
