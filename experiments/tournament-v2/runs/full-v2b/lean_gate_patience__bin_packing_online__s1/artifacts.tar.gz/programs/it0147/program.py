# EVOLVE-BLOCK-START
"""Best-fit with a tolerance band: find the minimal post-placement residual, then
among bins close to that residual prefer the loosest (largest residual) bin so
that leftover space stays large and reusable; exact fills still win outright."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    residual = bins.astype(np.float64) - item
    r_min = residual.min()

    # Bins that leave essentially the tightest fit (within tolerance) are the
    # candidates; among them the loosest leftover is preferred to avoid slivers.
    tol = 4.0
    in_band = residual <= r_min + tol

    # Primary: prefer being in the tight-fit band.
    score = np.where(in_band, 0.0, -residual)

    # Secondary: within the band, larger residual (looser bin) is better, but
    # exact fills (residual 0) get an extra push so they aren't lost.
    secondary = np.where(in_band, residual, 0.0)
    exact = np.where(residual == 0.0, 1.0, 0.0)

    return score + 0.01 * secondary + 2.0 * exact
# EVOLVE-BLOCK-END
