# EVOLVE-BLOCK-START
"""Residual-value bin choice based on a static Weibull item-size model.

Items are ~Weibull distributed with mean 40.  For a bin left with residual capacity r
after placing the current item, we ask how "useful" that residual is likely to be for
future items.  A residual that is a very common item size is valuable (it will be filled
exactly); a residual just below a common size is wasteful.  We encode this by precomputing
a value function over residuals from the size density and its cumulative structure, then
scoring each candidate bin by the value of the residual it would leave, plus a small
tightest-fit nudge to break ties efficiently.
"""
import numpy as np

# ---- Precompute the Weibull item-size model once (module import time) --------------
# Weibull(k, lam) with mean ~40.  Shape 2, scale 40/Gamma(1+1/2) ~= 45.13 gives mean ~40.
_K = 2.0
_SCALE = 40.0 / 0.8862269254527580  # Gamma(1.5) = sqrt(pi)/2

# Discretized size distribution over 1..100 (mass function of item sizes).
_SIZES = np.arange(1, 101, dtype=np.float64)
_cdf = 1.0 - np.exp(-((_SIZES / _SCALE) ** _K))
_pmf = np.diff(np.concatenate(([0.0], _cdf)))
_pmf = np.clip(_pmf, 0.0, None)
_pmf /= _pmf.sum()

# Expected number of items that "fit" a residual of size r, weighting larger items more
# (they use up the residual more efficiently).  This yields a convex-ish value in r:
# larger residuals can host more / bigger future items, but exact-fit residuals are
# especially valuable.
def _build_value():
    r = np.arange(0, 101, dtype=np.float64)
    # Survival probability: chance a future item is <= r.
    surv = np.cumsum(_pmf)              # surv[i] = P(size <= i+1)
    surv_full = np.concatenate(([0.0], surv))  # index by r (0..100)
    # Mean fraction of residual consumed by a future item that fits.
    # For each r, integrate E[size | size<=r] weighted by P(size<=r).
    weighted = _SIZES * _pmf
    cum_w = np.concatenate(([0.0], np.cumsum(weighted)))  # sum size*pmf up to r
    # value ~ expected usable capacity: how much of r gets consumed by the next fitting item,
    # plus a term rewarding residuals that equal a likely item size (exact fills are good).
    exact = np.zeros_like(r)
    for i, rr in enumerate(r):
        idx = int(rr)
        if 1 <= idx <= 100:
            exact[i] = _pmf[idx - 1]
    frac = np.zeros_like(r)
    for i, rr in enumerate(r):
        if rr <= 0:
            frac[i] = 0.0
        else:
            idx = int(min(rr, 100))
            # probability an arriving item fits, and expected consumption when it does
            p_fit = surv_full[idx]
            if p_fit > 0:
                mean_fit = cum_w[idx] / p_fit
            else:
                mean_fit = 0.0
            frac[i] = p_fit * (mean_fit / max(rr, 1.0))
    # Combine: reward high probability of being usable and efficient consumption.
    G = 1.0 * frac + 0.5 * exact
    return G

_G = _build_value()


def priority(item, bins):
    """Score bins by the value of the residual they would leave, plus tight-fit nudge."""
    residual = bins - item          # residual capacity if item placed here (>=0 for fit bins)
    residual = np.clip(residual, 0, 100)
    value = _G[residual.astype(np.int64)]
    # Small tightest-fit term: prefer leaving a residual close to a common small size.
    tie = -residual * 1e-3
    return value + tie
# EVOLVE-BLOCK-END
