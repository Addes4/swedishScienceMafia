# EVOLVE-BLOCK-START
"""Best-fit with an adaptive residual-reusability tie-break.

The harness shows us every bin the item fits in, along with its remaining
capacity. Pure best-fit (place into the bin leaving the smallest
non-negative residual) is near-optimal on this Weibull-shaped size distribution
(mean ~40). The only remaining lever is how we resolve near-ties among
candidate residuals of similar magnitude, since leaving a residual that no
future item can use wastes space.

We keep best-fit dominant by using a large weight on the (negative) residual.
A small secondary term rewards bins whose resulting residual matches a
frequently observed recent item size, estimated online from past items.
"""
import numpy as np


# Module-level state: a small histogram over residuals/items seen so far.
_HIST = np.zeros(101, dtype=np.float64)
_SEEN = 0.0


def priority(item, bins):
    """Score each candidate bin; highest score wins, ties to the first bin."""
    global _HIST, _SEEN

    b = np.asarray(bins, dtype=np.float64)
    residual_after = b - float(item)

    # Update the empirical histogram with this item's size (past items only
    # matter for scoring; current item is already known).
    it = int(item)
    if 0 <= it <= 100:
        _HIST[it] += 1.0
        _SEEN += 1.0

    # Empirical probability that a future item equals a given integer size.
    if _SEEN > 0:
        prob = _HIST / _SEEN
    else:
        prob = _HIST

    # Reusability of the leftover residual: how likely some future item can
    # exactly fill it (residual - future_item == 0), which "closes" the bin.
    r = np.clip(np.round(residual_after), 0, 100).astype(np.int64)
    reuse = prob[r]

    # Best-fit dominant; small bonus for reusable residuals.
    return -residual_after + 1e-3 * reuse
# EVOLVE-BLOCK-END

