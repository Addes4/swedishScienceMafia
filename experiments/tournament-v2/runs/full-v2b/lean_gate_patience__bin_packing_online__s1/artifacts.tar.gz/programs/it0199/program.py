"""Best-fit with a mild residual-usefulness tie-break."""

import numpy as np

# Fixed, distribution-informed "usefulness" of a post-placement residual.
# Small residuals that equal common item sizes are slightly favored, while
# exact fits (residual 0) get a small extra bonus. Magnitude is kept tiny
# so it only affects genuine near-ties and never overrides best-fit.
_WEIGHT = 1e-3


def priority(item, bins):
    residual = bins - item  # >= 0 for all shown bins
    # Primary: smallest residual (best fit).
    primary = -residual.astype(np.float64) * 1000.0
    # Secondary: prefer larger pre-placement capacity as a stable tie-break.
    secondary = -bins.astype(np.float64)
    # Tertiary: tiny usefulness nudge. Exact fits are best, then residuals
    # around typical item sizes are mildly preferred over stranded leftovers.
    r = residual.astype(np.float64)
    usefulness = np.where(r == 0.0, 1.0, 1.0 / (1.0 + np.abs(r - 40.0)))
    return primary + secondary + _WEIGHT * usefulness
