# EVOLVE-BLOCK-START
"""Best-fit rule: place the item in the fitting bin with the smallest remaining
capacity after placement (tightest fit). This keeps bins full and minimizes waste."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    # Post-placement residual: smaller is better (best fit), so negate.
    residual = bins.astype(np.float64) - item

    # Pure best-fit ordering. Exact fills (residual == 0) are already the most
    # preferred under this ordering, so no tie-breaker is needed.
    return -residual
# EVOLVE-BLOCK-END
