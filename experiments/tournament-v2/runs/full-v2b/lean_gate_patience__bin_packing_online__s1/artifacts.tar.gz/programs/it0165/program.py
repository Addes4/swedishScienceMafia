# EVOLVE-BLOCK-START
"""Best-fit with a "fuller bin first" tie-break.

Primary rule: best fit (smallest post-placement residual, i.e. tightest
remaining space left over).  Ties in the residual are broken by preferring the
bin with the LARGER current remaining capacity (the bin that was more full
before placement).  This marginally reduces leftover fragmentation and delays
opening new bins, without ever overriding a strictly better fit.
"""
import numpy as np

_CAP = 100


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing the item
    # Primary key: smallest residual (best fit).  Note: bins with residual < 0
    # are not shown to us (array already filtered to fitting bins), but guard.
    np.clip(residual, 0, _CAP, out=residual)

    # We score with two keys combined so a single argmax works:
    #   primary  = -residual      (smaller residual -> higher score)
    #   secondary = +bins (pre-placement remaining capacity, fuller bin larger)
    # Scale primary so it dominates any secondary difference: residual gap of 1
    # must outweigh the max secondary gap (100).  Use factor 1000.
    score = (-residual.astype(np.float64)) * 1000.0 + bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
