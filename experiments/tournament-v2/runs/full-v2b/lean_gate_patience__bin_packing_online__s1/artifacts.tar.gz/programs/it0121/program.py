# EVOLVE-BLOCK-START
"""Best-fit with adaptive reusable-residual tie-breaking.

The dominant signal is classic best-fit (minimize leftover capacity).  A small
secondary term rewards residuals that the running empirical size distribution
says are likely to be reused by a future item, and mildly penalizes residuals
below the smallest item size observed so far (dead space).
"""
import numpy as np

_CAP = 100
_NBINS_HIST = 101
_ALPHA = 0.5

_hist = np.full(_NBINS_HIST, _ALPHA, dtype=np.float64)
_total = float(_NBINS_HIST * _ALPHA)
_min_item = None


def priority(item, bins):
    """Return a score per bin; item goes to the highest (first on ties)."""
    global _total, _min_item

    if 1 <= item <= _CAP:
        _hist[item] += 1.0
        _total += 1.0
        if _min_item is None or item < _min_item:
            _min_item = item

    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    for i in range(n):
        b = int(bins[i])
        residual = b - item
        if residual < 0:
            scores[i] = -1e18
            continue
        # Dominant: best-fit, smaller residual preferred.
        s = -float(residual)
        if residual > 0:
            # Reusable-residual bonus: how often have we seen items of this size?
            reuse = float(_hist[residual]) / _total
            s += 2.0 * reuse
            # Mild dead-space penalty for residuals too small to ever be filled.
            if _min_item is not None and residual < _min_item:
                s -= 1.0
        else:
            # residual 0 is a perfect fill; strongly reward.
            s += 3.0
        scores[i] = s

    return scores
# EVOLVE-BLOCK-END
