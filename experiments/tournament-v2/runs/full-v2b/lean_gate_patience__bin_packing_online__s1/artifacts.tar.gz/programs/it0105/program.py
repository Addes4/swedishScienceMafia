import numpy as np

def priority(item, bins):
    after = bins - item
    # Best-fit: minimize residual after placement.
    # Among near-tight fits, prefer leaving the largest residual so that
    # small residuals aren't fragmented and can still absorb future items.
    m = after.min()
    # tolerate residuals up to m + 1 as "equally tight"
    tight = after <= (m + 1)
    score = np.where(tight, after, -10**9)
    return score
