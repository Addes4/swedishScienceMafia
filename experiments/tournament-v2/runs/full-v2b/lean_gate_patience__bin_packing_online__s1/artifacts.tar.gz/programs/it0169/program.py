# EVOLVE-BLOCK-START
"""Best-fit with exact-fill bonus tie-break using online item histogram.

Pure best-fit is very strong here (~0.9616).  The main loss comes from creating
leftovers that no future item can fill tightly.  We keep best-fit as the primary
key (score ~ -residual), but add a small bonus to a bin when its post-placement
residual r is a size that has been observed frequently (so a future item can
fill it exactly).  The bonus is tiny relative to 1 unit of residual, so it only
breaks near-ties and never overrides a clearly better fit.
"""
import numpy as np

_CAP = 100
_counts = np.zeros(_CAP + 1, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _total
    _counts[item] += 1.0
    _total += 1.0

    residual = (bins - item).astype(np.float64)
    np.clip(residual, 0.0, float(_CAP), out=residual)

    # Frequency-based bonus for residual r: how likely a future item has size r.
    # Use counts of exactly r normalized by total; small so it only breaks ties.
    if _total > 1.0:
        freq = _counts / _total
    else:
        freq = np.zeros(_CAP + 1, dtype=np.float64)
    # Bonus for residuals that are themselves common item sizes, plus a tiny
    # preference for smaller residuals on top of best-fit.
    bonus = freq[np.clip(residual.astype(np.int64), 0, _CAP)]

    # Primary: -residual (best fit).  Secondary: bonus in [0,1], scaled to <0.5
    # so it can only flip ties or near-ties of a single residual unit.
    return -residual + 0.4 * bonus
# EVOLVE-BLOCK-END
