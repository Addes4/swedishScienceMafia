# EVOLVE-BLOCK-START
"""Best-fit with a reusable-residual tie-break.

Primary rule is best-fit: smaller residual after placement is better.
Among bins with equal residual, prefer those whose leftover residual matches a
frequently observed past item size (so the gap can be exactly reused), then
prefer the least-full bin as a final fallback.
"""
import numpy as np


def priority(item, bins):
    """Score bins by best-fit, tie-broken toward reusable/moldeable residuals."""
    if priority.counts is None:
        priority.counts = np.zeros(101, dtype=np.float64)
    counts = priority.counts

    residual = bins - item  # non-negative for all bins shown
    # Running histogram of past item sizes (of items already placed).
    # Frequency signal for a residual r is counts[r] (how often size r appears).
    freq = counts[np.clip(residual, 0, 100)]

    # Primary: best fit -> smaller residual better (large weight).
    # Secondary: prefer residual matching a frequent item size.
    # Tertiary: prefer least-full bin (larger pre-placement capacity).
    score = (-residual.astype(np.float64) * 100000.0
             + freq * 1000.0
             + bins.astype(np.float64))
    return score


priority.counts = None


def _update(item):
    if priority.counts is not None:
        priority.counts[item] += 1.0


# Hook: the harness calls priority(item, bins); we update state after each call.
_orig_priority = priority


def priority(item, bins):  # noqa: F811
    if priority.counts is None:
        priority.counts = np.zeros(101, dtype=np.float64)
    residual = bins - item
    freq = priority.counts[np.clip(residual, 0, 100)]
    score = (-residual.astype(np.float64) * 100000.0
             + freq * 1000.0
             + bins.astype(np.float64))
    priority.counts[item] += 1.0
    return score


priority.counts = None
# EVOLVE-BLOCK-END

