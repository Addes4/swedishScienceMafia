# EVOLVE-BLOCK-START
"""Static Weibull-based residual-fillability value rule with a tightest-fit blend.

We precompute the item-size pmf (Weibull with mean ~40, matching the problem's
stated distribution) and estimate the distribution of sums of L future items via
Poisson/Gaussian approximation to build a value G(r): the expected fraction of
future items that will still fit into a residual capacity r.  Scoring each bin by
G(residual after placing the item) favors residuals that remain "packable" rather
than merely tight, while a small best-fit term keeps bins from being wasted.
"""
import numpy as np

# ---- Build a static Weibull item-size pmf with mean ~40 -------------------
# Construct a Weibull pmf on 1..100, then tune the scale so the mean is ~40.
_sizes = np.arange(1, 101, dtype=np.float64)

def _weibull_pmf(shape, scale):
    cdf_hi = 1.0 - np.exp(-((_sizes + 0.5) / scale) ** shape)
    cdf_lo = 1.0 - np.exp(-((_sizes - 0.5) / scale) ** shape)
    pmf = np.clip(cdf_hi - cdf_lo, 0.0, None)
    pmf[0] = 1.0 - np.exp(-(0.5 / scale) ** shape)
    pmf = pmf / pmf.sum()
    return pmf

_SHAPE = 1.6
# Search scale so that mean is ~40.
scale = 40.0
for _ in range(60):
    pmf = _weibull_pmf(_SHAPE, scale)
    mean = float(np.dot(_sizes, pmf))
    if mean < 40.0:
        scale *= 1.01
    else:
        scale *= 0.99
    if abs(mean - 40.0) < 0.05:
        break
_ITEM_PMF = pmf  # pmf over sizes 1..100

# Expected number of items per bin ~ 100 / mean ~ 2.5.  Take L = round.
_MEAN = float(np.dot(_sizes, _ITEM_PMF))
_L_FLOAT = 100.0 / _MEAN

# ---- Build G(r): expected count of future items fitting in residual r -----
# Approximate the number of future items that fit as a Poisson process with
# rate proportional to r / mean, capped at L_FLOAT.  A residual of r can accept
# a number of items whose sum <= r; the expected fillable count is a smooth
# increasing, roughly concave function of r, saturating around L_FLOAT.
def _build_value():
    r = np.arange(0, 101, dtype=np.float64)
    # Expected number of items placeable in residual r, roughly r/mean but with
    # diminishing returns due to fragmentation.
    k = r / _MEAN
    # Saturation: as r approaches 100 the attainable count approaches L_FLOAT.
    k = np.minimum(k, _L_FLOAT)
    # Fragmentation penalty: small residuals near item size are "good".
    # Use expected efficiency: probability a random item exactly nearly fits.
    eff = np.zeros_like(r)
    cum = np.cumsum(_ITEM_PMF)  # cum[i-1] = P(size <= i)
    for i, rr in enumerate(r):
        ri = int(rr)
        if ri <= 0:
            eff[i] = 0.0
            continue
        # Probability an arriving item fits
        pfit = cum[min(ri, 100) - 1]
        # Weight by expected count of fitting items = L_FLOAT * pfit, but
        # cap growth using log to avoid over-rewarding huge residuals.
        eff[i] = k[i] * (1.0 - 0.35 * (1.0 - pfit))
    return r, eff

_R, _G = _build_value()

# Precompute interpolation-friendly arrays.
def _value(r_after):
    # r_after is an integer array in [0, 100]; clamp and use direct index.
    idx = np.clip(r_after, 0, 100).astype(np.int64)
    return _G[idx]


def priority(item, bins):
    """Score each bin by residual fillability value plus a tightest-fit bonus."""
    residual = bins - item  # >= 0 for bins shown (all bins fit the item)
    g = _value(residual)
    # Tightest-fit term: prefer smaller residual (classic best fit).
    tight = -(residual.astype(np.float64))
    # Blend: value dominates the choice, tightness breaks near-ties.
    return g * 1.0 + tight * 0.02
# EVOLVE-BLOCK-END
