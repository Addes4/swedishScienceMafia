# EVOLVE-BLOCK-START
"""Expected-items-left rule: score a bin by how many future items its residual can still absorb.

We learn the item-size distribution online (a smoothed histogram of past items) and use it
to estimate, for a residual capacity r, the expected number of future items that can fit
into r before it becomes unusable. Bins that leave residuals likely to accept multiple
further items are promoted; this rewards long-run packing efficiency rather than only the
immediate best fit.
"""
import numpy as np

# ---- online-learned size distribution (module state, persists across calls) ----
_hist = np.zeros(101, dtype=np.float64)     # counts of observed sizes 1..100
_seen = 0.0                                 # total (smoothed) observations
_hist[1:101] += 0.5
_seen += 50.0

# cached value function, rebuilt occasionally
_G = None
_G_age = 0
_REBUILD_EVERY = 25


def _rebuild_value():
    """Build value function G[r] = expected number of remaining items that fit in r."""
    global _G, _G_age
    p = _hist[1:101] / max(_seen, 1e-9)
    sizes = np.arange(1, 101, dtype=np.float64)

    # E[number of items of size s >= threshold needed to exhaust capacity r]
    # Use a renewal-style approximation: expected items that fit is roughly
    # sum over one future item of the mean usable amount, converted to a count.
    # Concretely: value(r) = 1 + sum_s p_s * value(r - s) for s <= r (recursion).
    r = np.arange(0, 101, dtype=np.float64)
    G = np.zeros(101, dtype=np.float64)
    for cap in range(1, 101):
        acc = 0.0
        for s in range(1, cap + 1):
            acc += p[s - 1] * (1.0 + G[cap - s])
        # probability that some item fits into this residual
        pfit = p[:cap].sum()
        G[cap] = acc if pfit > 1e-12 else 0.0
    _G = G
    _G_age = 0


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties)."""
    global _seen, _G_age

    _hist[item] += 1.0
    _seen += 1.0

    if _G is None or _G_age >= _REBUILD_EVERY:
        _rebuild_value()
    _G_age += 1

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item
    np.clip(residual, 0, 100, out=residual)

    # primary: expected number of future items this residual can still absorb
    score = _G[residual].astype(np.float64)
    # tie-break: prefer tighter fit (smaller residual) among equal values
    score = score - 1e-6 * residual

    return score
# EVOLVE-BLOCK-END
