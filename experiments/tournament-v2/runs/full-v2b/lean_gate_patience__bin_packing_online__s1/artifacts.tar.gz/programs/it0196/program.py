"""Best-fit bin-choice rule with exact-fit emphasis."""

import numpy as np


def priority(item, bins):
    """Rank bins: prefer smallest post-placement residual, exact fit first.

    Bins shown all fit the item, so residual = bins - item >= 0.
    Primary key: smaller residual is better.
    Secondary: prefer larger pre-placement capacity (keeps fuller bins
    available) but exact fits (residual 0) are strictly best.
    """
    residual = (bins - item).astype(np.float64)
    exact = (residual == 0.0).astype(np.float64)
    return -residual * 1000.0 - bins.astype(np.float64) + exact * 1e9

