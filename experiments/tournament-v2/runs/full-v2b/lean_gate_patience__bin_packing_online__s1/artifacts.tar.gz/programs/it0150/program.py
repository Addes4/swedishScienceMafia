import numpy as np


def priority(item, bins):
    """Pure best-fit: prefer the bin leaving the smallest residual capacity.

    Among bins where the item fits, the one with the smallest remaining capacity
    after placement is chosen (tightest fit), which historically performs best.
    Exact fits (residual 0) naturally rank highest. Ties go to the first bin.
    """
    residual = bins - item
    # We must not place into bins where the item does not fit; but the harness
    # only passes bins the item fits in, so residual >= 0 for all entries.
    return -(residual.astype(np.float64))
