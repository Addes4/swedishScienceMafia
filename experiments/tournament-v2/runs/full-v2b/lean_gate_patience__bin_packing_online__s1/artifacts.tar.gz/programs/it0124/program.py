# EVOLVE-BLOCK-START
"""Best-fit with a learned harmonic-class matching secondary term.

Classic best-fit (minimize leftover) is dominant, but on Weibull-shaped item
sizes pure best-fit tends to fragment bins into awkward residuals.  We add a
small secondary term that prefers residuals r such that the item plus r lands
in a "harmonic class" (dyadic band) that has historically been filled well.
Tracking is online, using only past items.
"""
import numpy as np

_CAP = 100
_NBINS_HIST = 101
_ALPHA = 0.5
_BESTFIT_W = 4.0
_CLASS_W = 0.6
_REUSE_W = 0.4
_DEAD_W = 1.0

_hist = np.full(_NBINS_HIST, _ALPHA, dtype=np.float64)
_total = float(_NBINS_HIST * _ALPHA)
_min_item = None

# Harmonic class boundaries for scoring residuals.
_BOUNDS = np.array([1, 2, 3, 4, 6, 8, 12, 16, 25, 33, 50, 60, 80, 100], dtype=np.int64)


def _class_of(x):
    """Index of the harmonic band containing x (vectorized)."""
    return np.searchsorted(_BOUNDS, x, side='right')


def priority(item, bins):
    """Return a score per bin; item goes to the highest (first on ties)."""
    global _total, _min_item

    if 1 <= item <= _CAP:
        _hist[item] += 1.0
        _total += 1.0
        if _min_item is None or item < _min_item:
            _min_item = item

    b = bins.astype(np.float64)
    residual = b - float(item)  # capacity left after placing the item

    # Dominant: best-fit, smaller residual preferred.
    scores = -_BESTFIT_W * residual

    # Secondary: prefer residuals whose dyadic class is small (tighter bands
    # correspond to safer residuals that are more likely to be re-filled).
    r_int = np.clip(residual.astype(np.int64), 0, _CAP)
    cls = _class_of(r_int)
    # Small class index => small residual => better; only a mild nudge.
    scores -= _CLASS_W * cls

    # Cumulative fraction of past items with size <= residual: probability
    # that some future item fits into this residual.
    cdf = np.cumsum(_hist) / _total
    reuse = cdf[r_int]

    fits = residual > 0
    scores += np.where(fits, _REUSE_W * reuse, 0.0)

    # Perfect fill: strongly reward.
    scores = np.where(residual == 0, scores + 3.0, scores)

    # Mild dead-space penalty for residuals too small to ever be filled.
    if _min_item is not None:
        dead = (residual > 0) & (residual < _min_item)
        scores -= np.where(dead, _DEAD_W, 0.0)

    # Infeasible bins (item doesn't fit) must never be chosen.
    scores = np.where(residual >= 0, scores, -1e18)

    return scores
# EVOLVE-BLOCK-END
