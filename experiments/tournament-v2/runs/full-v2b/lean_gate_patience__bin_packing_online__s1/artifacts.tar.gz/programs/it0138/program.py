# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a learned residual-usefulness tie-breaker.

The primary rule is best-fit: rank bins by the negative residual capacity they
would leave, so the tightest fitting bin wins.  On top of this dominant
ordering, a mild secondary term rewards leaving a residual that is close to a
frequently observed item size, since such leftover space is likely to be
usable by a future item.  The histogram is updated online from arriving items.
"""
import numpy as np

# Online histogram of item sizes (1..100), smoothed counts.
_SIZE_MAX = 100
_counts = np.ones(_SIZE_MAX + 1, dtype=np.float64)  # Laplace smoothing
_total = float(_SIZE_MAX + 1)


def priority(item, bins):
    """Best-fit dominant score plus a small residual-usefulness bonus."""
    global _counts, _total

    # Update the online size histogram with the current item.
    _counts[item] += 1.0
    _total += 1.0

    residual_after = bins - item  # >= 0 for bins the item fits in

    # Best-fit: prefer smallest residual (dominant term).
    score = -residual_after.astype(np.float64)

    # Secondary: reward residuals close to a common item size.
    # Clamp residuals to the histogram support for lookup.
    idx = residual_after.astype(np.int64)
    idx = np.clip(idx, 0, _SIZE_MAX)
    usefulness = _counts[idx] / _total
    score += 1e-6 * usefulness

    return score
# EVOLVE-BLOCK-END
