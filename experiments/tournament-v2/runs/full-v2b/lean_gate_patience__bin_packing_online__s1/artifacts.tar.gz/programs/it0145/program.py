# EVOLVE-BLOCK-START
"""Best-fit rule with a tiny anti-sliver tie-breaker.

Primary ordering: best-fit (smallest post-placement residual).
Secondary (epsilon only, to break exact residual ties): among bins leaving the
same residual, prefer the one whose residual is at least the running mean item
size, so the bin stays "useful" for a typical future item rather than becoming
an unusable sliver.
"""
import numpy as np


def priority(item, bins):
    residual = bins.astype(np.float64) - item

    # Dominant term: best-fit (smaller residual -> higher score).
    score = -residual

    # Tiny epsilon tie-breaker: among equal residuals, mildly prefer bins whose
    # residual can still accommodate a typical future item (reduces slivers).
    # This only matters when residuals are exactly equal.
    eps = 1e-6
    score += eps * np.minimum(residual, 40.0)

    return score
# EVOLVE-BLOCK-END
