# EVOLVE-BLOCK-START
"""Best-fit with a mild adaptive "small-residual" penalty on tie-breaks.

Pure best-fit (place into the bin leaving the smallest non-negative residual,
tie-broken toward the emptiest bin) is the strongest known simple online rule
for this distribution.  We keep it as the strictly dominant key and only add a
very small secondary nudge: an arriving item creates a post-placement residual
``r``.  If ``r`` is positive but small, the bin is likely to end up underfilled
because the next items tend to be near the running mean item size and will not
fit into a sliver.  We therefore mildly penalize tiny positive residuals.

The penalty is scaled far below the primary key weight so it can never override
best-fit's ordering; it only reshuffles candidates whose residuals are close.
A short decayed estimate of recent item sizes provides the scale for "too small
to be useful".
"""
import numpy as np


_state = {"avg": 40.0}


def priority(item, bins):
    """Score bins: best-fit primary, tiny penalty for useless small residuals."""
    global _state

    # Decayed running average of recent item sizes (memoryless, safe even if the
    # harness calls us out of any particular order within an instance).
    _state["avg"] = 0.98 * _state["avg"] + 0.02 * float(item)

    residual = bins - item
    cap = bins.astype(np.float64)
    res = residual.astype(np.float64)

    # Primary: smaller (non-negative) residual is strongly better.
    # Weight 101 exceeds the max capacity span so it strictly dominates.
    score = -res * 101.0 + cap

    # Secondary: penalize positive residuals that are too small for a typical
    # upcoming item to exploit.  The penalty is tiny (<< 1) and only applies to
    # residuals in [1, avg/2), tapering to zero at avg/2 so exact or useful fits
    # are untouched.
    small = _state["avg"] * 0.5
    # Only penalize residuals strictly between 0 and small.
    active = (res > 0.0) & (res < small)
    if np.any(active):
        frac = np.where(active, 1.0 - (res / small), 0.0)
        score = score - 1e-3 * frac

    return score
# EVOLVE-BLOCK-END
