# EVOLVE-BLOCK-START
"""Best-fit with complementary-residual tie-break.

Dominant rule: best-fit (prefer smallest residual after placement).
Secondary (tiny) term: prefer leaving a residual close to 100 - item, so that
a bin freshly filled by a large item tends to have room for a similar large
item later, and bins are packed into complementary pairs.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Dominant: best-fit. Secondary: closeness of residual to complement.
    target = 100 - item
    secondary = -np.abs(residual - target)
    return -residual.astype(np.float64) + 1e-3 * secondary
# EVOLVE-BLOCK-END
