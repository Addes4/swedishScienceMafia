# EVOLVE-BLOCK-START
"""Best-fit with a tie-break preferring the fullest fitting bin.

The item goes into the bin that leaves the smallest positive post-placement
residual (best-fit).  Ties are broken by choosing the bin with the smallest
current remaining capacity (i.e. the fullest bin that still fits the item),
which concentrates filling and delays opening new bins.  A small learned
value-function term is deliberately dropped because it hurt performance.
"""
import numpy as np


def priority(item, bins):
    # Post-placement residual (remaining capacity that would be left).
    residual = bins - item  # bins shown all have remaining >= item, so >= 0

    # Primary key: smallest residual => best-fit.  For equal residual, the
    # pre-placement capacity bins (before subtracting) is bins itself; smaller
    # bins means a fuller bin, preferred.  Encode as a single lexicographic
    # score: minimize (residual, bins).
    # Use float scores; larger is better, so negate both keys with weights such
    # that the residual term strictly dominates the capacity tie-break.
    res = residual.astype(np.float64)
    cap = bins.astype(np.float64)
    # Smallest residual dominates; among equal residuals, smallest cap dominates.
    # Weight chosen so cap never overrides a strictly smaller residual.
    score = -(res * 1e6) - cap
    return score
# EVOLVE-BLOCK-END
