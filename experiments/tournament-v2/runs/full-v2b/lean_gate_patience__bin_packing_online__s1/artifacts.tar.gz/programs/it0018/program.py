# EVOLVE-BLOCK-START
"""Best-fit bin choice with a strong reuse incentive for open bins.

The dominant rule is best-fit: place the item in the fitting bin whose
remaining capacity after placement is smallest. This keeps bins tightly
packed and avoids leaving useful gaps. Fresh (empty) bins are penalized
by a fixed fraction of the best-fit score so that already-open bins are
strongly preferred before opening a new one.
"""
import numpy as np


def priority(item, bins):
    """Score each bin by tightness of the post-placement residual."""
    r = bins.astype(np.int64) - item
    # Best-fit: 1/(residual+1) is large when residual is small/near-zero.
    score = 1.0 / (r + 1.0)
    # Reuse bonus: empty bins (residual 100) get a fixed fraction penalty,
    # so we prefer filling already-open bins before opening a new one.
    score = np.where(bins >= 100, score * 0.98, score)
    return score
# EVOLVE-BLOCK-END

