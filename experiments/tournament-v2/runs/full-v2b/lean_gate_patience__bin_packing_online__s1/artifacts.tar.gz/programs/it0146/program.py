# EVOLVE-BLOCK-START
"""Leveled best-fit: group candidate placements into coarse residual buckets so
that "equally tight" fits are treated as ties, and within a bucket prefer the
tightest residual. Exact fills get the best (lowest) bucket. This keeps the
dominant tightest-fit ordering while deterministically reducing the creation of
many nearly-equal partial bins that pure best-fit would split apart."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    residual = bins.astype(np.int64) - item

    # Coarse bucket: residual // 8. Level 0 = exact fill. Within a bucket the
    # exact residual breaks ties (tighter first).
    level = residual // 8

    # Higher score wins: prefer smaller level (coarser tightness), then smaller residual.
    score = (-level).astype(np.float64) * 1000.0 - residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
