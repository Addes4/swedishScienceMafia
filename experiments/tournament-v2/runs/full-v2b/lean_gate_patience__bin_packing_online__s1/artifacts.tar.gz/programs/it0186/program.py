# EVOLVE-BLOCK-START
"""Weibull-residual fillability rule for online bin packing.

The item sizes follow a fixed Weibull-shaped distribution with mean about 40.
Precompute that distribution once.  For a bin with remaining capacity r after
placing the arriving item, define a value G(r) = expected total size that can
still be packed into a bin of capacity r under a "perfect" packing of the
distribution (i.e. E[min(r, S)] for a single future item plus a recursion-free
proxy).  A convex increasing function of r captures the idea that larger
residuals are weakly better but small residuals that still fit an item well are
valuable: we blend the value of the *post-placement* residual with a
tightest-fit bonus.
"""
import numpy as np

# ---- Precompute Weibull(size) distribution with mean ~40 -------------------
# Weibull with shape k, scale lam: mean = lam * Gamma(1 + 1/k) = 40.
_K = 1.5
_LAM = 40.0 / 0.9027452929509336  # Gamma(1+1/1.5) ~ 0.90274529


def _weibull_pmf():
    """Discretized Weibull pmf over integer sizes 1..100 (unnormalized then
    renormalized on the support)."""
    x = np.arange(1, 101, dtype=float)
    # CDF difference of continuous Weibull evaluated at half-integer boundaries.
    b = (x + 0.5) / _LAM
    a = (x - 0.5) / _LAM
    cdf = 1.0 - np.exp(-(b ** _K))
    cdf_lo = 1.0 - np.exp(-(a ** _K))
    p = cdf - cdf_lo
    p = np.clip(p, 0.0, None)
    s = p.sum()
    if s > 0:
        p = p / s
    return p


_PMF = _weibull_pmf()               # p[i] = Pr(size == i+1)
_SIZES = np.arange(1, 101)         # size = i+1


# ---- Convex cumulative "fillability" value G(r) ----------------------------
def _build_value():
    """G(r) larger means a bin with residual r can still absorb more item mass.

    We define G(r) as the expected amount packed into a residual of r by an
    ideal (clarvoyant) best-fit process against the item distribution:
        V(r) = E_S[ 1{S<=r} * (S + V(r - S)) ]  ... expensive, so we approximate
    with the mean-field single-item term plus a mild convex correction.
    """
    r = np.arange(0, 101, dtype=float)
    # Expected size that still fits: E[S * 1{S <= r}].
    es = np.zeros(101)
    cs = np.cumsum(_PMF)          # Pr(size <= t) for t = 1..100 -> index t-1
    esz = np.cumsum(_PMF * _SIZES)
    for rr in range(101):
        if rr <= 0:
            es[rr] = 0.0
        else:
            es[rr] = esz[min(rr, 100) - 1]
    # Convex-ish correction: reward residuals that leave little "waste".
    # waste fraction ~ (rr - expected filled)/rr
    with np.errstate(divide="ignore", invalid="ignore"):
        fill_frac = np.where(r > 0, es / np.maximum(r, 1.0), 0.0)
    # G increasing in r but with a concavity penalty so that we don't force
    # large residuals; combine.
    G = r * fill_frac + 0.15 * r
    G[0] = -1e6
    return G


_G = _build_value()


def priority(item, bins):
    """Score bins by post-placement residual fillability plus tight fit."""
    residual = bins.astype(np.int64) - int(item)
    residual = np.clip(residual, 0, 100)
    # Value of residual after placement.
    score = _G[residual].astype(float)
    # Blend a tightest-fit term so that bins whose residual nearly matches a
    # typical item are favored (reduces fragmentation).
    tight = -(bins.astype(np.float64) - float(item))
    return score * 1.0 + tight * 0.35
# EVOLVE-BLOCK-END
