# EVOLVE-BLOCK-START
"""Best-fit packing rule with an online learned exact-fit bonus.

The dominant term is classic best-fit: place the item into the bin with the
smallest non-negative residual (score ~ 1/(residual+1)).  A secondary term uses
an online histogram of the item sizes seen so far to reward placements whose
leftover residual exactly equals a common future item size, so the leftover
space is likely to be reused snugly.  The secondary weight is kept moderate so
best-fit dominates and the rule stays robust.
"""
import numpy as np

# Running histogram of item sizes seen so far (index 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0

# Weight of the learned residual-value term relative to the best-fit term.
_W = 0.5


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    global _COUNT
    r = bins - item  # residual capacity if placed in each bin (>= 0 by contract)

    # Classic best-fit term: tightest residual wins.
    scores = 1.0 / (r + 1.0)

    # Learned term: reward residuals that exactly match a commonly seen size.
    if _COUNT > 0.0:
        weights = _HIST / _COUNT
        # vals[b] = weighted count of past items whose size equals residual r[b].
        # r is integer-valued, so index directly (clip to valid range).
        ri = np.clip(r.astype(np.int64), 0, 100)
        vals = weights[ri]
        maxv = vals.max()
        if maxv > 0.0:
            vals = vals / maxv
        scores = scores + _W * vals

    # Mild preference for already-open (less empty) bins.
    scores = scores - 0.00005 * bins

    # Update statistics with the current item.
    _HIST[item] += 1.0
    _COUNT += 1.0

    return scores
# EVOLVE-BLOCK-END

