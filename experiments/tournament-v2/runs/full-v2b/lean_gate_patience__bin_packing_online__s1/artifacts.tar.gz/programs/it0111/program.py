import numpy as np


def priority(item, bins):
    """Best-fit with a consolidation tie-break.

    Dominant term: negative residual after placement (tightest fit wins).
    Secondary term: prefer bins that are already fuller (smaller current
    remaining capacity), which consolidates load and helps when residuals tie.
    """
    residual = bins - item
    # Dominant: tightest fit. Secondary: fuller bin (smaller bins value).
    return -residual.astype(np.float64) - 1e-6 * bins.astype(np.float64)
