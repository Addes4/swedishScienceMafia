# EVOLVE-BLOCK-START
"""Greedy packing scored by expected absorbable item mass.

Each bin's post-placement residual r is valued by the expected size of a future item
that can still fit into it, E[s | s <= r] weighted by the probability mass that fits:
    A(r) = sum_{s<=r} p(s) * s + lambda * (mass fitting)
This rewards residuals that can still take large (high-value) items rather than merely
being large, which discourages splitting future large items across many bins.
A tiny best-fit tie-breaker keeps loose bins open for the big items that need them.
"""
import numpy as np

# Weibull-shaped item pmf over sizes 1..100 with mean ~40.
_sizes = np.arange(1, 101)
_k = 1.6
_lam = 45.0
_p = (_k / _lam) * (_sizes / _lam) ** (_k - 1.0) * np.exp(-(_sizes / _lam) ** _k)
_p = np.clip(_p, 1e-9, None)
_p /= _p.sum()

# Cumulative "absorbable value" table: A(r) = sum_{s<=r} p(s) * s
_cum_p = np.concatenate(([0.0], np.cumsum(_p)))          # _cum_p[r] = P(s <= r)
_val = np.concatenate(([0.0], np.cumsum(_p * _sizes)))    # _val[r] = E[s 1{s<=r}]
_val_full = _cum_p * np.arange(0, 101)                    # mass * r upper bound ref
_absorb = _val.copy()                                     # expected absorbed size

# Blend: expected absorbable size plus a fraction of the fitting mass times residual,
# favouring residuals with both useful size and usable room.
_TABLE = _absorb + 0.5 * (_cum_p * np.arange(0, 101))


def priority(item, bins):
    """Score bins by expected absorbable mass of the resulting residual."""
    residual = bins - item
    r = np.clip(residual, 0, 100)
    score = _TABLE[r]
    # Tie-breaker: mild preference for tighter fits (smaller residual).
    score = score - 1e-3 * residual
    return score
# EVOLVE-BLOCK-END
