# EVOLVE-BLOCK-START
"""Best-fit with a learned-residual bonus.

Primary rule: best fit (smallest post-placement residual).  Additionally, among
bins whose residual differs only slightly, prefer the one whose post-placement
residual is a commonly observed item size, since such a bin is likely to be
tightly filled by a future item.  The learned distribution uses a decayed
histogram over integer sizes, updated online with no future information.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0
_DECAY = 0.999


def priority(item, bins):
    global _TOTAL
    residual = bins - item  # post-placement residual

    # decayed histogram of observed item sizes
    _HIST *= _DECAY
    _TOTAL *= _DECAY
    _HIST[item] += 1.0
    _TOTAL += 1.0

    # frequency estimate (probability that a future item size equals r)
    freq = _HIST / max(_TOTAL, 1.0)

    # bonus from learned frequency of the resulting residual
    idx = np.clip(residual, 0, 100).astype(np.int64)
    bonus = freq[idx]

    # primary: best fit (smallest residual); tiny bonus for fillable residuals
    score = -residual.astype(np.float64) * 1e6 + bonus * 1e3 - bins.astype(np.float64) * 1e-3
    return score
# EVOLVE-BLOCK-END
