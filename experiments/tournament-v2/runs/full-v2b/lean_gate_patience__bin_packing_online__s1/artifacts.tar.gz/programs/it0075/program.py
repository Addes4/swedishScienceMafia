# EVOLVE-BLOCK-START
"""Best-fit bin choice with a tight-bin tie-break.

Primary rule: minimize the post-placement residual (classic best-fit / tightest fit),
the strongest known rule for this problem. Ties are frequent (many empty bins with
residual 100), so among bins achieving the minimal residual we prefer the bin that
was already the fullest before placement (smallest pre-placement capacity). This keeps
partially-filled bins getting filled up rather than starting new bins, reducing
fragmentation. A small reusability bonus breaks any remaining ties.
"""
import numpy as np
from math import gamma

_SIZE = 101

def _build_probs():
    k = 2.0
    mean = 40.0
    scale = mean / gamma(1.0 + 1.0 / k)
    sizes = np.arange(1, _SIZE)
    pdf = (k / scale) * (sizes / scale) ** (k - 1.0) * np.exp(-(sizes / scale) ** k)
    pdf = np.clip(pdf, 0.0, None)
    s = pdf.sum()
    if s <= 0:
        pdf = np.ones_like(pdf)
        s = pdf.sum()
    return pdf / s

_PROB = _build_probs()

# Weight for residuals 0..100: how likely that residual exactly matches an item size.
_MATCH = np.zeros(_SIZE, dtype=np.float64)
_MATCH[1:100] = _PROB[0:99]
# Perfect fill (residual 0) is always highly desirable.
_MATCH[0] = _MATCH.max() if _MATCH.max() > 0 else 1.0

def priority(item, bins):
    b = np.asarray(bins, dtype=np.int64)
    residual = b - item
    # Primary: minimize post-placement residual (best / tightest fit).
    primary = -residual.astype(np.float64)
    # Secondary: prefer the bin that was fullest before placement (smallest capacity),
    # i.e. keep filling already-used bins.
    secondary = -b.astype(np.float64)
    # Tertiary: reusability of the leftover residual.
    match = _MATCH[np.clip(residual, 0, _SIZE - 1)]
    score = primary + 1e-3 * secondary + 1e-6 * match
    return score
# EVOLVE-BLOCK-END
