# EVOLVE-BLOCK-START
"""Residual-value bin packing: choose the bin whose leftover capacity is most
usable by future items drawn from a fixed Weibull-shaped size distribution."""
import numpy as np

# Precompute a static size-frequency model of future items.
# Weibull-shaped, mean about 40, support 1..100.
_sizes = np.arange(1, 101, dtype=np.float64)


def _weibull_pmf():
    # Match mean ~40 with a Weibull-ish shape; tune c and scale so mean is ~40.
    # Weibull(k, lambda): mean = lambda * Gamma(1 + 1/k).
    # Pick k so the distribution is right-skewed like the problem statement.
    k = 2.0
    # Gamma(1.5) ~= 0.8862269
    scale = 40.0 / 0.886226925452758
    # Weibull pdf on (0, inf):
    pdf = (k / scale) * (_sizes / scale) ** (k - 1.0) * np.exp(-(_sizes / scale) ** k)
    pdf = np.maximum(pdf, 0.0)
    s = pdf.sum()
    if s <= 0:
        pdf = np.ones_like(_sizes)
        s = pdf.sum()
    return pdf / s


_PMF = _weibull_pmf()
_CDF = np.cumsum(_PMF)
_PMF = np.maximum(_PMF, 1e-9)
_CDF = np.concatenate(([0.0], _CDF))


def _useful_residual(r):
    # r: integer residual capacity remaining after placing the item (0..100).
    # Reward residuals that can be well-filled by common future item sizes.
    # Convex-ish "value" of a residual: probability mass of items that fit
    # times a factor that penalizes leaving tiny scraps.
    if r <= 0:
        return 0.0
    r = int(r)
    if r > 100:
        r = 100
    # Distribution of a single future item truncated to what fits in r.
    fit_mass = float(_CDF[r])  # P(item <= r), capped by array length
    if fit_mass <= 0.0:
        return -1000.0
    # Expected fraction of residual consumed by the next fitting item,
    # normalized so bigger residuals are not trivially better.
    idx = np.arange(1, r + 1, dtype=np.float64)
    pm = _PMF[:r]
    mean_fit = float(np.dot(idx, pm))
    if mean_fit <= 0.0:
        mean_fit = 1.0
    # "Packing efficiency": how much of r a typical fitting item uses.
    efficiency = mean_fit / r
    # Reward high fit probability and good efficiency, scaled by residual size
    # so that leaving more usable room is preferred, but small unusable scraps
    # are strongly penalized.
    return fit_mass * efficiency * (r ** 0.5)


# Precompute the score for every possible residual to make calls fast.
_RESIDUAL_SCORE = np.empty(101, dtype=np.float64)
for _r in range(101):
    _RESIDUAL_SCORE[_r] = _useful_residual(_r)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (all >= item), in bin order.
    """
    residual = bins - item
    # Clamp to valid range; bins should all fit the item but be defensive.
    residual = np.clip(residual, 0, 100).astype(np.int64)
    scores = _RESIDUAL_SCORE[residual]
    # Prefer bins that already have contents (lower remaining) as a mild
    # tie-breaker, matching best-fit behavior when residuals look equal.
    scores = scores - 1e-6 * bins
    return scores
# EVOLVE-BLOCK-END
