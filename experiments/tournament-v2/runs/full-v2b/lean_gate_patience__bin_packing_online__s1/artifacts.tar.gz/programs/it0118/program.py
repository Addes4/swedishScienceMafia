# EVOLVE-BLOCK-START
"""Best-fit bin choice with tie-break that avoids tiny unfillable residuals.

Place the arriving item into the fitting bin with the smallest remaining
capacity (tightest fit), i.e. leave the smallest possible residual.  This
classic online rule is near-optimal for this Weibull-shaped size
distribution and dominates the residual-value heuristics empirically.

Among bins whose post-placement residual is (numerically) identical, pure
best-fit falls back to the lowest bin index.  That default can leave many
bins with small "dead" residuals (1..SMALL-1) that no future item can ever
fill, wasting capacity across the run.  We add a strictly sub-dominant
secondary term that, only for ties, prefers leaving either 0 or a residual
large enough to still be usable later.  The epsilon is small enough that it
can never override a real best-fit difference.
"""
import numpy as np

# Residuals strictly below this cannot fit many small items and are likely
# wasted; prefer either a full bin (0) or a more reusable residual.
_SMALL = 8
_EPS = 1e-6


def priority(item, bins):
    """Score each bin by the negative residual it would leave.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every fitting bin (numpy int64, bin order).
    """
    residual = bins - item
    # Dominant best-fit term: prefer the smallest residual.
    score = -residual.astype(np.float64)
    # Sub-dominant tie-break: penalize small unusable residuals (1.._SMALL-1),
    # but not a perfectly full bin (0).
    small_penalty = ((residual > 0) & (residual < _SMALL)).astype(np.float64)
    score -= _EPS * small_penalty
    return score
# EVOLVE-BLOCK-END
