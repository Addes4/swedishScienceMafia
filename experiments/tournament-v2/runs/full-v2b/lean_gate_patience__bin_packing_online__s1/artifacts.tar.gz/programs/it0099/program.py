import numpy as np

# ---------------------------------------------------------------------------
# Static size-frequency -> convex residual-value function, built once.
# ---------------------------------------------------------------------------
# Item sizes are Weibull-shaped with mean ~40. We approximate the *density* of
# item sizes with a Weibull(k=2, lambda) whose mean is 40.
#   mean = lambda * Gamma(1 + 1/k) = 40  ->  lambda = 40 / Gamma(1.5)
# We compute a histogram f[s] for s = 1..100 and then define the value of a
# residual capacity r as the expected "matching rate" of that residual, i.e.
# the probability that some future item can be seated into a set of bins whose
# aggregate leftover is r.  A simple, convex, monotone proxy is the fraction of
# the residual that can, on average, be consumed by a maximally-packed subset
# of future items.  We approximate this with a greedy "fillability" measure.
# ---------------------------------------------------------------------------

_CAP = 100

# --- Build Weibull size distribution ---
# shape k = 2 gives a right-skewed bump around 30-50 for mean 40.
_K = 2.0
# Gamma(1 + 1/k) via math.gamma
import math
_SCALE = 40.0 / math.gamma(1.0 + 1.0 / _K)

def _build_freq():
    s = np.arange(1, _CAP + 1, dtype=np.float64)
    # Weibull pdf on [0, 100]; discrete histogram proportional to pdf
    pdf = (_K / _SCALE) * (s / _SCALE) ** (_K - 1.0) * np.exp(-(s / _SCALE) ** _K)
    freq = pdf * 100.0  # roughly counts per 100 items
    freq = np.clip(freq, 1e-6, None)
    return freq

_FREQ = _build_freq()          # expected number of items of each size (per 100 items)
_TOTAL = _FREQ.sum()
_P = _FREQ / _TOTAL            # probability mass per integer size s (index s-1)

def _build_value():
    """G[r] = expected usable fraction of a residual capacity r.

    We define G via a greedy fillability estimate: given residual capacity r,
    the expected amount of that residual that a stream of future items can fill
    is modeled by repeatedly drawing the *typical largest item that fits* and
    subtracting, accumulating filled mass.  We approximate this with a smooth
    recursive relation using the survival function of the size distribution.

    value(r) = r * fillable_fraction(r), where fillable_fraction increases
    (concavely) with r, so value is convex and monotone in r.
    """
    G = np.zeros(_CAP + 1, dtype=np.float64)
    # Survival: probability that a random item has size >= s
    surv = np.zeros(_CAP + 2, dtype=np.float64)
    tail = np.cumsum(_P[::-1])[::-1]
    surv[1:_CAP + 1] = tail
    surv[_CAP + 1] = 0.0

    # Expected size of the largest item that fits in r, weighted by mass.
    # E[max fit size | r] = sum_{s<=r} s * P(s) / P(s <= r)  (conditional mean)
    cum = np.cumsum(_P)  # cum[s-1] = P(size <= s)
    wsum = np.cumsum(_P * np.arange(1, _CAP + 1, dtype=np.float64))
    for r in range(1, _CAP + 1):
        p_le = cum[r - 1]
        if p_le <= 0.0:
            G[r] = 0.0
            continue
        mean_fit = wsum[r - 1] / p_le     # conditional mean of item that fits
        # Expected fillable mass: geometric-style accumulation, capped at r.
        # If the mean fit is m, each placement consumes m on average; the number
        # of items that can still be packed is roughly r/m, but capacity
        # granularity means we estimate fillable mass as r * (1 - exp(-p_le)).
        fillable = r * (1.0 - np.exp(-p_le)) if mean_fit < r else r
        # blend with the raw conditional mean so very small residuals stay usable
        fillable = 0.5 * fillable + 0.5 * min(r, mean_fit)
        G[r] = fillable
    return G

_G = _build_value()

# Precompute marginal gain G[r - item] - this is just looked up.
def priority(item, bins):
    """Residual-value rule: prefer bins whose post-placement residual is most
    fillable, with a tightest-fit tie-break."""
    after = bins - item
    after = np.clip(after, 0, _CAP)
    vals = _G[after.astype(np.int64)]
    # convex gain favors residual shapes that future items can still pack well;
    # tiny best-fit tie-break pushes toward the tightest remaining fit.
    return vals - 1e-4 * after
