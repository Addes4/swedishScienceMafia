# EVOLVE-BLOCK-START
"""Best-fit with a least-loaded tie-break.

Primary: choose the bin with the smallest residual capacity that still fits
(pure best-fit), which is the strongest online rule for this distribution.
Tie-break: among bins with identical residual, prefer the one that is least
full (largest pre-placement capacity), which avoids stranding many
nearly-full bins with unusable small holes.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of bins the item fits in (numpy int64).
    """
    b = np.asarray(bins, dtype=np.float64)
    residual = b - item
    # Primary: best-fit -> smaller residual scores higher.
    # Weight large so best-fit dominates; secondary breaks ties.
    return -residual * 1000.0 + b
# EVOLVE-BLOCK-END

