# EVOLVE-BLOCK-START
"""Best-fit rule for online bin packing.

Put the item into the bin that leaves the smallest non-negative residual
(best fit).  Ties are broken by preferring the bin with the largest
pre-placement capacity, which is the canonical tie-break used by the
best-known solution for this problem.
"""
import numpy as np


def priority(item, bins):
    """Rank bins: best fit (smallest residual), then largest capacity."""
    residual = bins.astype(np.int64) - int(item)
    # Primary key: smallest residual. Secondary key: largest pre-placement
    # capacity. Return a score that encodes both with correct ordering.
    # Since scores are maximized, negate for residual and use capacity as a
    # secondary tie-break scaled small enough not to override the primary key.
    max_cap = 100
    score = -residual.astype(np.float64) * (max_cap + 1) + bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
