# EVOLVE-BLOCK-START
"""Best-fit packing with a learned exact-residual-value bonus.

Base term is classic best-fit: place the item into the bin with the smallest
non-negative residual (score ~ 1/(residual+1)).  A secondary term uses an
online histogram of item sizes seen so far to reward residuals that exactly
match a common future item size (especially a perfect fit, residual 0), which
tends to keep leftover space reusable by the next typical item.  A tiny penalty
on larger residuals discourages needlessly opening fresh bins.
"""
import numpy as np

# Running histogram of item sizes seen so far (index 1..100).
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0

# Weight of the learned exact-residual match term relative to best-fit.
_W = 0.6
# Bonus weight for a perfect fit (residual 0).
_PERFECT = 0.5


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    global _COUNT
    r = bins - item  # residual capacity if placed in each bin (>= 0 by contract)

    # Classic best-fit term: tightest residual wins.
    scores = 1.0 / (r + 1.0)

    # Learned exact-residual match term: reward residuals that equal a common
    # observed item size, so the leftover space is likely to be reused.
    if _COUNT > 0.0:
        weights = _HIST / _COUNT  # empirical probabilities, index 1..100
        # Prob-mass that each residual matches the size of a future item.
        r_clipped = np.clip(r, 0, 100).astype(np.int64)
        match = weights[r_clipped]  # P(future item size == residual)
        scores = scores + _W * match

    # Extra bonus for leaving a perfect fit (residual 0).
    scores = scores + _PERFECT * (r == 0)

    # Mild preference for already-open (less empty) bins.
    scores = scores - 0.0001 * bins

    # Update statistics with the current item.
    _HIST[item] += 1.0
    _COUNT += 1.0

    return scores
# EVOLVE-BLOCK-END

