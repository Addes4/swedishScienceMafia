import numpy as np

# Precompute the set of item sizes 1..100 and a static "fillability" weight:
# a residual r is more valuable if it can still accept many future items,
# but best-fit remains the primary ordering.  We use a tiny additive bonus
# for residuals that are exact item sizes (very likely to be consumed later),
# which nudges ties/near-ties without disturbing the strong best-fit rule.
_SIZES = np.arange(1, 101, dtype=np.float64)


def priority(item, bins):
    residual = (bins - item).astype(np.float64)
    # Primary: best-fit (smaller residual better).  Secondary bonus: strongly
    # prefer an exact fill (residual 0), which best-fit already does, and give a
    # very small preference to residuals that equal a possible item size so that
    # such a bin is more likely to be exactly filled by a future item.
    exact = (residual == 0.0).astype(np.float64)
    matchable = ((residual >= 1.0) & (residual <= 100.0)).astype(np.float64)
    return -(residual) + 0.001 * exact + 0.0005 * matchable
