# EVOLVE-BLOCK-START
"""Thresholded best-fit ranking.

Best fit (place into the bin that becomes fullest) is a strong online rule for
Weibull-ish sizes. Its weakness is that it sometimes fills a bin down to a tiny
sliver, wasting the residual, before an already-open bin with a more useful
remaining capacity is chosen. We keep best-fit as the base score but give a
bump to already-open bins whose post-placement residual is still large enough to
hold typical future items, and no bump to fresh bins. Pure numpy, O(nbins).
"""
import numpy as np


def priority(item, bins):
    residual = bins.astype(np.float64) - item
    np.clip(residual, 0.0, 100.0, out=residual)

    # Fill fraction after placing the item: higher is better (best fit).
    fill = (100.0 - residual) / 100.0

    # Bonus for reusing an already-open bin whose residual is still usable,
    # scaled so it cannot override a large best-fit advantage.
    open_mask = bins < 100
    usable = residual >= 20.0
    open_bonus = np.where(open_mask & usable, 0.02, 0.0)

    return fill + open_bonus
# EVOLVE-BLOCK-END
