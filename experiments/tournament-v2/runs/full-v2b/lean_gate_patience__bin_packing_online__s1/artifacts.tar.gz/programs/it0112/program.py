import numpy as np


def priority(item, bins):
    """Best-fit with a tie-break toward later-index bins.

    The dominant term is the negative residual after placement (tightest fit
    wins).  A tiny, index-proportional term breaks exact ties in favour of the
    highest bin index, which avoids always deepening the same low-index bins.
    """
    residual = bins - item
    n = residual.shape[0]
    idx = np.arange(n, dtype=np.float64)
    # scale so the index term (< 1) never overrides a residual difference (>= 1)
    return -residual.astype(np.float64) + (idx / (n + 1.0))
