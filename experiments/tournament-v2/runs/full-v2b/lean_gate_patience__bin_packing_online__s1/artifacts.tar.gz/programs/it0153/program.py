import numpy as np

# Fixed item-size distribution: Weibull-shaped, sizes 1..100, mean ~40.
# Precompute a static "fillability" curve once at import time.
_SIZES = np.arange(1, 101, dtype=np.float64)

# Weibull(k=2, lambda) with mean 40 -> scale = 40 / Gamma(1.5)
from math import gamma
_SHAPE = 2.0
_SCALE = 40.0 / gamma(1.0 + 1.0 / _SHAPE)

# Probability mass per integer size (unnormalized fine: we normalize later).
_cdf = 1.0 - np.exp(-((_SIZES / _SCALE) ** _SHAPE))
_prev_cdf = 1.0 - np.exp(-((( _SIZES - 1.0) / _SCALE) ** _SHAPE))
_pmf = np.clip(_cdf - _prev_cdf, 1e-12, None)
_pmf = _pmf / _pmf.sum()

# survival probability: probability a random item has size >= s
_surv = np.zeros(101)
for s in range(1, 101):
    _surv[s] = _pmf[s - 1:].sum()

# fillability of residual r: probability that some future item exactly fits r
# (approx: prob an item of exactly size r exists among next few items)
_fit_small = _surv.copy()  # prob item size >= r (can be placed to reduce residual)


def priority(item, bins):
    residual = bins - item
    r = residual.astype(np.float64)

    # Primary: best-fit, smallest residual wins (more negative => higher score).
    score = -r

    # Secondary small penalty for residuals that are hard to fill later:
    # a leftover r that is smaller than the smallest likely item wastes space.
    # Reward exact fills and residuals that are multiples/achievable; penalize
    # residual values whose probability of being consumed is low.
    idx = np.clip(r.astype(np.int64), 0, 100)
    fillable = _surv[idx]  # higher = can still accept many item sizes
    # Encourage leaving residual room that items can still use, and strong bonus
    # for exact fills (residual 0) to keep best-fit's tight behavior.
    score += 1e-3 * fillable - 1e-3 * (idx == 0)

    return score
