# EVOLVE-BLOCK-START
"""Residual-value rule via a proper expected-fill value function.

We build a Weibull item-size pmf (mean ~40) and compute V(r), a value function
over residual capacity r in 0..100.  V(r) estimates how much of the residual r
can on average be "usefully consumed" by future items, computed with a
one-step look-ahead recursion using the pmf.  Bins are scored by V(residual
after placing the item) plus a small best-fit term.
"""
import numpy as np

_sizes = np.arange(1, 101, dtype=np.float64)

def _weibull_pmf(shape, scale):
    cdf_hi = 1.0 - np.exp(-((_sizes + 0.5) / scale) ** shape)
    cdf_lo = 1.0 - np.exp(-((_sizes - 0.5) / scale) ** shape)
    pmf = np.clip(cdf_hi - cdf_lo, 0.0, None)
    pmf = pmf / pmf.sum()
    return pmf

_SHAPE = 1.6
scale = 40.0
for _ in range(80):
    pmf = _weibull_pmf(_SHAPE, scale)
    mean = float(np.dot(_sizes, pmf))
    if mean < 40.0:
        scale *= 1.01
    else:
        scale *= 0.99
    if abs(mean - 40.0) < 0.05:
        break
_ITEM_PMF = pmf  # pmf over sizes 1..100
_MEAN = float(np.dot(_sizes, _ITEM_PMF))

# ---- Build V(r): expected value of residual capacity r -------------------
# V(r) = expected maximum usable fill of r by the *next* item plus the value
# of what remains.  Concretely, with each item size s <= r chosen with prob
# p_s (renormalized over s <= r), the immediate gain is s and the future value
# is V(r - s).  Weight by the probability that the next item fits at all, and
# add a small term accounting for the chance no item fits (wasted residual).
_P = _ITEM_PMF
_PSIZE = _sizes

def _build_value():
    V = np.zeros(101, dtype=np.float64)
    # Cumulative pmf for fit probability, using the raw pmf (not renormalized)
    # so that the fit-probability term is meaningful.
    cum = np.cumsum(_P)  # cum[i-1] = P(size <= i)
    for r in range(1, 101):
        pfit = cum[r - 1]
        if pfit <= 1e-12:
            V[r] = 0.0
            continue
        # Distribution over fitting sizes, conditional on fitting.
        probs = _P[:r] / pfit
        # One-step Bellman step: expected immediate gain s plus discounted
        # continuation.  Contraction factor < 1 keeps the recursion stable.
        gain = 0.0
        for i in range(r):
            s = int(_PSIZE[i])
            gain += probs[i] * (s + 0.6 * V[r - s])
        # Weight by fit probability: large residuals that are rarely refillable
        # (i.e., pfit tiny) get little value.
        V[r] = pfit * gain + (1.0 - pfit) * 0.0
    return V

_V = _build_value()


def priority(item, bins):
    """Score each bin by residual fill-value plus a tightest-fit bonus."""
    residual = bins - item
    idx = np.clip(residual, 0, 100).astype(np.int64)
    v = _V[idx]
    # Convert fill-value to a "per residual unit" measure so that wasting a
    # small residual is penalized less than wasting a large one.
    v = v - 0.02 * residual.astype(np.float64)
    return v
# EVOLVE-BLOCK-END
