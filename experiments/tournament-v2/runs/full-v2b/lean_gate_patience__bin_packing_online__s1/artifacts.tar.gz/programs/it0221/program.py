# EVOLVE-BLOCK-START
"""Best-fit rule with a size-aware tie-break.

Items arrive one at a time and must be placed immediately.  The dominant
signal is classic best fit: choose the bin whose residual after placing the
item is smallest.  Ties (and near-ties) are broken by preferring residuals
that are "closeable": a residual r is good if it is just slightly larger than
a likely future item size, so that the leftover can be cleaned up by a single
subsequent item rather than stranded.  This asymmetry helps avoid leaving tiny
useless slivers.

Concretely we score each bin by -(residual) plus a small bonus that is high
when the residual after placement is large enough to be usefully refilled by
one common item size, i.e. the residual is near a typical item size.
"""
import numpy as np

_sizes = np.arange(1, 101, dtype=np.float64)

def _weibull_pmf(shape, scale):
    cdf_hi = 1.0 - np.exp(-((_sizes + 0.5) / scale) ** shape)
    cdf_lo = 1.0 - np.exp(-((_sizes - 0.5) / scale) ** shape)
    pmf = np.clip(cdf_hi - cdf_lo, 0.0, None)
    pmf[0] = 1.0 - np.exp(-(0.5 / scale) ** shape)
    pmf = pmf / pmf.sum()
    return pmf

_SHAPE = 1.6
scale = 40.0
pmf = _weibull_pmf(_SHAPE, scale)
for _ in range(80):
    pmf = _weibull_pmf(_SHAPE, scale)
    mean = float(np.dot(_sizes, pmf))
    if abs(mean - 40.0) < 0.02:
        break
    if mean < 40.0:
        scale *= 1.005
    else:
        scale *= 0.995
_ITEM_PMF = pmf

# For each residual r (0..100), a "closeability" value: how useful the
# leftover capacity r is.  We measure the probability that a single future
# item lands in the window (r - slack, r], i.e. that the residual can be
# (nearly) cleaned up by one more item, plus a reward for exactly filling.
_BONUS = np.zeros(101, dtype=np.float64)
_cum = np.concatenate(([0.0], np.cumsum(_ITEM_PMF)))  # _cum[k] = P(size<=k)
for r in range(0, 101):
    if r == 0:
        _BONUS[r] = 1.0  # perfectly filled bin
    else:
        lo = max(0, r - 5)  # tolerate a few units of leftover slack
        # probability that a future item falls in (r-5, r]
        p = _cum[r] - _cum[lo]
        # also lightly reward residuals that equal a common item size
        p += 0.1 * _ITEM_PMF[r - 1]
        _BONUS[r] = p

_W = 0.2

def priority(item, bins):
    """Choose the tightest-fit bin, breaking ties toward closable residuals."""
    residual = bins - item  # >= 0 for all bins shown
    r = np.clip(residual, 0, 100).astype(np.int64)
    bonus = _BONUS[r]
    # Dominant term: prefer smallest residual (best fit).
    return -residual.astype(np.float64) + _W * bonus
# EVOLVE-BLOCK-END
