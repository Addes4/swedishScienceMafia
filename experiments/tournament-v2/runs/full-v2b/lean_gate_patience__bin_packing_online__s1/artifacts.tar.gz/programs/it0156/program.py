# EVOLVE-BLOCK-START
"""Best-fit blended with a convex residual fillability value derived from the Weibull size law."""
import numpy as np

# Weibull with shape k and scale λ, mean = λ*Γ(1+1/k) ≈ 40.
_K = 1.5
_LAMBDA = 40.0 / 0.9027452929509336  # gamma(1+1/1.5)


def _weibull_pmf():
    # discretize onto integer sizes 1..100
    s = np.arange(1, 101)
    cdf = 1.0 - np.exp(-((s / _LAMBDA) ** _K))
    pmf = np.diff(np.concatenate(([0.0], cdf)))
    pmf = np.clip(pmf, 0.0, None)
    pmf /= pmf.sum()
    return pmf


_PMF = _weibull_pmf()
_SIZES = np.arange(1, 101)


def _build_value():
    # G[r] = expected number of future items optimally fillable from residual capacity r.
    # Use a simple DP: value(r) = sum_{i} p(i) * (1 + value(r-i)) for i<=r, else value(r).
    # Convexity/concavity emerges naturally. Precompute for r=0..100.
    maxr = 100
    G = np.zeros(maxr + 1)
    # iterate to convergence (value iteration for a renewal reward process)
    for _ in range(200):
        newG = G.copy()
        for r in range(maxr + 1):
            acc = 0.0
            for i in range(1, r + 1):
                acc += _PMF[i - 1] * (1.0 + G[r - i])
            newG[r] = acc
        if np.max(np.abs(newG - G)) < 1e-10:
            G = newG
            break
        G = newG
    return G


_G = _build_value()


def priority(item, bins):
    residual = bins - item
    residual = np.clip(residual, 0, 100)
    value = _G[residual]
    # blend with tightest fit so we prefer smaller residuals (better packing)
    return value - 0.01 * residual
# EVOLVE-BLOCK-END
