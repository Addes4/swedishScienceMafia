# EVOLVE-BLOCK-START
"""Best-fit rule with a strong preference for exact fills.

Items arrive one at a time; pick the bin whose remaining capacity after placing
the item (the residual) is smallest, i.e. classic best fit.  Ties (equal
residual) are broken in favor of bins that are already full (residual 0), which
avoids leaving many near-full bins that can never be closed.  The primary term
is a monotone decreasing function of the residual (negated residual), with a
slight nonlinear compression so that very small residuals are strongly
preferred over merely small ones.
"""
import numpy as np

# Weight of the exact-fill bonus relative to the best-fit term.
_W_EXACT = 0.25

def priority(item, bins):
    """Choose the tightest-fit bin, preferring exact fills on ties."""
    residual = bins - item  # >= 0 for all bins shown
    r = np.clip(residual, 0, 100).astype(np.float64)
    # Dominant term: prefer smallest residual (best fit), slightly compressed
    # so small residuals are strongly favored.
    score = -(r + 0.02 * r * r)
    # Strong bonus for exact fills (r == 0) to close bins cleanly.
    score += _W_EXACT * (r == 0.0)
    return score
# EVOLVE-BLOCK-END
