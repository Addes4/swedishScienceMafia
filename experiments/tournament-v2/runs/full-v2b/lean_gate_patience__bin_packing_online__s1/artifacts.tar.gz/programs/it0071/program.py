# EVOLVE-BLOCK-START
"""Best-fit bin choice with a reusable-residual tie-break.

Primary rule: minimize the post-placement residual (classic best-fit / tightest fit),
which is the strongest known rule here. Ties are extremely common when many empty
bins (residual 100) are present, so the tie-break matters: among bins achieving the
minimal residual, prefer the bin whose leftover residual exactly matches a common
future item size (from a static Weibull-shaped histogram, mean ~40), so the leftover
capacity is likely reusable. If no such bin exists, fall back to the bin with the
largest pre-placement capacity (least full), which keeps emptier bins free.
"""
import numpy as np
from math import gamma

_SIZE = 101

def _build_probs():
    k = 2.0
    mean = 40.0
    scale = mean / gamma(1.0 + 1.0 / k)
    sizes = np.arange(1, _SIZE)
    pdf = (k / scale) * (sizes / scale) ** (k - 1.0) * np.exp(-(sizes / scale) ** k)
    pdf = np.clip(pdf, 0.0, None)
    s = pdf.sum()
    if s <= 0:
        pdf = np.ones_like(pdf)
        s = pdf.sum()
    return pdf / s

_PROB = _build_probs()

# Weight for residuals 0..100: how likely that residual exactly matches an item size.
_MATCH = np.zeros(_SIZE, dtype=np.float64)
_MATCH[1:100] = _PROB[0:99]
# Perfect fill (residual 0) is always highly desirable.
_MATCH[0] = _MATCH.max() if _MATCH.max() > 0 else 1.0

def priority(item, bins):
    b = np.asarray(bins, dtype=np.int64)
    residual = b - item
    # Primary: minimize post-placement residual (best / tightest fit).
    primary = -residual.astype(np.float64)
    # Reachability-based tie-break: reward residuals that match a common item size
    # or are zero (perfect fill).
    match = _MATCH[np.clip(residual, 0, _SIZE - 1)]
    # Least-full tie-break: larger pre-placement capacity is preferred.
    score = primary + 1e-3 * match + 1e-6 * b
    return score
# EVOLVE-BLOCK-END

