# EVOLVE-BLOCK-START
"""Best-fit blended with a half-bin target residual.

For a Weibull-ish distribution with mean ~40, leaving residuals near the typical
item size lets future items fill bins tightly, which beats naive best-fit.  We
score each bin by a weighted combination of (negative) residual distance to a
target and (negative) raw residual, keeping best-fit as a moderate term, and
track the running mean item size to set the target online.
"""
import numpy as np

_CAP = 100
_NBINS_HIST = 101
_ALPHA = 0.5

_hist = np.full(_NBINS_HIST, _ALPHA, dtype=np.float64)
_total = float(_NBINS_HIST * _ALPHA)
_item_sum = 0.0
_item_count = 0.0


def priority(item, bins):
    """Return a score per bin; item goes to the highest (first on ties)."""
    global _total, _item_sum, _item_count

    if 1 <= item <= _CAP:
        _hist[item] += 1.0
        _total += 1.0
        _item_sum += item
        _item_count += 1.0

    b = bins.astype(np.float64)
    residual = b - float(item)

    # Online target: a bit above the mean item size so leftovers stay reusable.
    mean_item = (_item_sum / _item_count) if _item_count > 0 else 40.0
    target = mean_item

    # Best-fit nudge (small but dominant among close residuals).
    scores = -0.15 * residual

    # Blend toward the target residual (prefer residuals near the target).
    scores -= 0.02 * np.abs(residual - target)

    # Reward residuals that the empirical distribution can fill.
    cdf = np.cumsum(_hist) / _total
    idx = np.clip(residual.astype(np.int64), 0, _CAP)
    scores += 1.5 * cdf[idx]

    # Perfect fill: strongly reward.
    scores = np.where(residual == 0, scores + 3.0, scores)

    # Infeasible bins must never be chosen.
    scores = np.where(residual >= 0, scores, -1e18)

    return scores
# EVOLVE-BLOCK-END
