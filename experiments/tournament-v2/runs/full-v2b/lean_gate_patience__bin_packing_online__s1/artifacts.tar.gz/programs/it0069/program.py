# EVOLVE-BLOCK-START
"""Near-best-fit with tightest-bin preference inside a small residual band.

Plain best-fit (minimize post-placement residual) is near-optimal here, but
strict ties are rare, so tie-breaks barely matter. Instead we allow a small
band of residuals near the minimum and, within that band, prefer the bin whose
pre-placement remaining capacity is smallest (the fullest bin that still fits),
which reduces fragmentation across bins.
"""
import numpy as np


def priority(item, bins):
    """Score bins: smallest residual wins, but banded so tightness can break.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 remaining capacities (item fits, so bins >= item).

    Returns a numpy array of scores (higher is better), same length, no NaN.
    """
    resid = bins - item  # post-placement residual, integer in [0, 99]

    best = resid.min()
    # Band: residuals within BAND of the best are treated as "primary tier".
    BAND = 3
    in_band = resid <= best + BAND

    # Primary score: within band, prefer *fullest* bin (smallest bins).
    # Outside band, penalize by residual distance so they never beat band bins.
    # Scale so outside-band scores stay strictly below any in-band score.
    tightness = bins.astype(np.float64)  # smaller = fuller = preferred in band
    band_bonus = 200.0  # makes in-band strictly dominate

    # In-band score: high base minus pre-placement capacity (tighter wins).
    # Outside-band score: below the in-band range, ordered by residual.
    scores = np.where(
        in_band,
        band_bonus - tightness,
        -resid.astype(np.float64) - 200.0,
    )
    return scores
# EVOLVE-BLOCK-END

