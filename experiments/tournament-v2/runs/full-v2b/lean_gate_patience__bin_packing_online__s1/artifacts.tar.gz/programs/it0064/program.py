# EVOLVE-BLOCK-START
"""Best-fit bin choice rule with least-full tie-break.

Place the item into the bin that leaves the smallest non-negative residual
(plain best-fit, which is near-optimal for this random-size stream). When
several bins leave the same residual, prefer the one with the largest
pre-placement remaining capacity, i.e. the least-full bin, which tends to
keep more partially-filled bins open and reusable.
"""
import numpy as np


def priority(item, bins):
    """Score each bin so that best-fit wins, ties broken by least-full bin.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (bins the item fits in).

    Returns a numpy array of scores (higher is better), same length, no NaN.
    """
    resid = bins - item  # residual after placing item (>= 0 for shown bins)

    # Primary: best fit -> smaller residual should score higher.
    # Secondary: among equal residuals, larger pre-placement capacity wins.
    # Encode lexicographically as (small resid, large bins) via a single score.
    # Since residuals are integers in [0, 99] and capacities in [item, 100],
    # scaling keeps the primary term strictly dominant.
    scores = -resid.astype(np.float64) + bins.astype(np.float64) / 1000.0

    return scores
# EVOLVE-BLOCK-END

