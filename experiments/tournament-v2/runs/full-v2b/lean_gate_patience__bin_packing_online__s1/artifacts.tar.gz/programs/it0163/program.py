# EVOLVE-BLOCK-START
"""Static Weibull-size-frequency residual-value bin-choice rule.

Items are drawn from a fixed Weibull-shaped distribution (mean ~40) with sizes
1..100.  We precompute the pmf of that distribution once, and derive a value
function G(r) that estimates how "usefully fillable" a residual capacity r is
by future items: G(r) = sum_s p(s) * G(r - s) capped, i.e. the expected number
of future items absorbed, in a worst/typical packing sense.

Concretely we define G via a convex increasing function of r built from the
expected amount that can still be packed: since placing an item should leave a
residual whose expected fillable volume is high, we score each bin by
    score = alpha * G(bins - item) + beta * (tightest-fit term)
"""
import numpy as np

# ---- Build the Weibull pmf once (shape chosen to match mean ~40 on 1..100) ----
_CAP = 100
_SIZES = np.arange(1, _CAP + 1, dtype=np.float64)

def _build_pmf():
    # Weibull with k=1.5, scale tuned so the truncated mean over 1..100 is ~40.
    best = None
    for scale in np.linspace(20.0, 60.0, 401):
        k = 1.5
        # Weibull pdf on sizes 1..100
        pdf = (k / scale) * (np.maximum(_SIZES, 1e-9) / scale) ** (k - 1.0) * np.exp(
            -(np.maximum(_SIZES, 1e-9) / scale) ** k
        )
        pdf = np.where(_SIZES >= 1, pdf, 0.0)
        tot = pdf.sum()
        if tot <= 0:
            continue
        pmf = pdf / tot
        mean = float((pmf * _SIZES).sum())
        err = abs(mean - 40.0)
        if best is None or err < best[0]:
            best = (err, pmf)
    return best[1]

_PMF = _build_pmf()

# Cumulative value function G(r): expected fillable "coverage" of residual r.
# G(r) grows concave then saturates near the mean item size scale.  We build it
# by iterating an expected-future-value recursion on a discrete residual grid.
_G = np.zeros(_CAP + 1, dtype=np.float64)

def _build_G():
    # G(r): expected number (fractional) of future items that can be packed into
    # residual r under a greedy expectation.  Start from G(0)=0 and do value
    # iteration: placing a best-fit item of size s <= r yields 1 + G(r - s)
    # weighted by the pmf, choosing the placement that maximizes the value.
    g = np.zeros(_CAP + 1, dtype=np.float64)
    for r in range(1, _CAP + 1):
        # For residual r, consider the next item's size s distributed by _PMF
        # restricted to s <= r; the value is 1 + g(r - s), we take the expected
        # over that distribution, but also allow the option of "stop".
        mass = _PMF[: r].sum()
        if mass <= 1e-12:
            g[r] = 0.0
            continue
        # expected continuation value
        cont = float((_PMF[:r] * g[r - np.arange(1, r + 1)]).sum()) / mass
        # value of having residual r ~ expected items packable, plus a smooth
        # convex "room" term that rewards larger residuals that can hold a big
        # item (proxy for future large-item compatibility).
        g[r] = (1.0 + cont) * mass + 0.0
    return g

_G = _build_G()

# Precompute a compatibility term: how much probability mass of future items the
# residual can still hold (a concave reward), used to shape the ranking.
def _fill_prob(r):
    if r <= 0:
        return 0.0
    return float(_PMF[: r].sum())

_FILL = np.array([_fill_prob(r) for r in range(_CAP + 1)], dtype=np.float64)


def priority(item, bins):
    """Score bins by residual value after placing the item.

    score = G(residual) + tightest-fit (larger bonus for smaller residual) that
    still leaves room.  Highest score wins; ties go to the first bin.
    """
    residual = bins - item  # guaranteed >= 0 for the bins shown
    residual_clip = np.clip(residual, 0, _CAP).astype(np.int64)

    g_val = _G[residual_clip]
    fill_val = _FILL[residual_clip]

    # Tightest-fit penalty: strongly prefer the residual closest to 0, but scale
    # it so that a nearly-full bin is preferred only when the value is similar.
    # We combine the coverage value with a small tightest-fit term.
    return g_val + 0.01 * fill_val - 0.001 * residual
# EVOLVE-BLOCK-END
