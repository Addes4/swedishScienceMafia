# EVOLVE-BLOCK-START
"""Best-fit with a light adaptive residual-frequency tie-break.

Primary rule: best fit (smallest non-negative residual). Secondary: largest
pre-placement capacity. A small adaptive bonus is added for residuals that
match frequent historical item sizes, encouraging gaps that future items
can fill exactly.
"""
import numpy as np


def priority(item, bins):
    n = bins.shape[0]
    caps = bins.astype(np.int64)
    residual = caps - int(item)

    # Dominant key: smallest residual (best fit).
    # Secondary key: largest pre-placement capacity.
    score = -residual.astype(np.float64) * (100.0 + 1.0) + caps.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
