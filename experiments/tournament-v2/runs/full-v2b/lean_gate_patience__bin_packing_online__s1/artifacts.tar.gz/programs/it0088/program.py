# EVOLVE-BLOCK-START
"""Best-fit with an adaptive reuse-aware tie-break.

Primary rule: strict best-fit (minimize post-placement residual).  Secondary,
tiny term: among bins that would leave the same minimal residual we prefer
residuals that are "reusable", i.e. that match a size seen in the empirical item
histogram.  The magnitude is small enough never to override best-fit ordering.
"""
import numpy as np

_state = {"hist": np.zeros(101, dtype=np.int64)}


def priority(item, bins):
    bins = np.asarray(bins)
    h = _state["hist"]
    # record the arriving item (online, only past information)
    h[item] += 1

    residual = (bins - item).astype(np.float64)        # >= 0 by contract
    score = -residual                                   # primary: best-fit

    # Secondary tie-break: reward residual values that have been seen as items
    # (so the leftover capacity is likely still usable later).
    intres = np.round(residual).astype(np.int64)
    intres = np.clip(intres, 0, 100)
    reusable = (h[intres] > 0).astype(np.float64)
    score += 1e-6 * reusable
    # Exact fill is strictly best.
    score += 1e-6 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
