# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with learned-residual tie-breaking.

The dominant term ranks bins by best-fit (smallest residual after placement).
A small learned-histogram term mildly prefers residuals close to common item
sizes, which can turn leftovers into exact fits on a later item without
disturbing the strong best-fit ordering.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_N = 0.0
_ALPHA = 0.05


def priority(item, bins):
    global _HIST, _N
    bins64 = bins.astype(np.int64)
    residual_after = bins64 - item

    # Online smoothed item-size histogram.
    _HIST *= (1.0 - _ALPHA)
    _HIST[item] += _ALPHA
    _N += 1.0

    # Probability mass near each possible residual (window of +/-2).
    p = _HIST / max(_HIST.sum(), 1e-12)
    # bonus for residual r = closeness to common item sizes
    r = residual_after
    idx = np.clip(r, 0, 100)
    bonus = p[idx]
    # also give a touch of mass from nearby sizes
    for d in (1, 2):
        lo = np.clip(r - d, 0, 100)
        hi = np.clip(r + d, 0, 100)
        bonus += 0.5 * p[lo] + 0.5 * p[hi]

    # Primary best-fit dominates; tie-break by residual usefulness.
    return -residual_after.astype(np.float64) + 0.001 * bonus
# EVOLVE-BLOCK-END
