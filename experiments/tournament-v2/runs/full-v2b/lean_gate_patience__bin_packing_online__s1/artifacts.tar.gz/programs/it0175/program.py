# EVOLVE-BLOCK-START
"""Best-fit with a small adaptive tie-break.

Primary key: smallest post-placement residual (classic best fit), which is hard
to beat online. The only remaining lever is how to break exact ties on the
residual. We keep a cheap exponentially-weighted estimate of the current item
scale and, among bins whose post-placement residual matches the best value, we
prefer the residual that is most likely to be filled by a future item, i.e. the
one closest to the estimated typical item size. This is exact and O(n) per call.
"""
import numpy as np

_state = {"mean": 40.0, "count": 0}


def priority(item, bins):
    # Update a cheap EW estimate of the (non-zero) item scale.
    m = _state["mean"]
    _state["mean"] = m + (item - m) * 0.005
    _state["count"] += 1
    target = _state["mean"]

    residual = bins - item
    # Primary: best fit => minimize residual (maximize -residual).
    # Secondary: among equal residuals, prefer residual closest to the typical
    # future item size (more likely to be consumable later).
    # Encode lexicographically with exact integer primary and small secondary.
    primary = -residual.astype(np.int64)
    secondary = -np.abs(residual.astype(np.float64) - target)
    # Sort by primary first, secondary second, bin index last (ties -> first bin).
    # Multiply primary by a large factor so it strictly dominates secondary.
    score = primary.astype(np.float64) * 1e6 + secondary
    return score
# EVOLVE-BLOCK-END
