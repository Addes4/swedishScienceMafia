# EVOLVE-BLOCK-START
"""Residual-value bin choice.

Precompute, once, a discretized model of the item-size distribution (a
Weibull-shaped histogram, mean ~40) and derive a convex "value" function
G(r) over integer residual capacities r in [0, 100].  G(r) estimates the
expected long-run future fillability of leaving a bin with r free capacity,
i.e. a measure of how much useful matching potential residual capacity r
retains.  The rule scores a bin by the value of the residual it would
leave, G(r - item), plus a small tightest-fit tie-break.
"""
import numpy as np

# --------------------------------------------------------------------------
# Build the item-size model once (module import time).
# Weibull-shaped distribution on [1, 100], mean about 40.
# --------------------------------------------------------------------------

_CAP = 100


def _build_weibull_hist():
    """Return a length-(_CAP+1) array of probabilities for sizes 1..100."""
    # Weibull with shape k and scale lam chosen so the mean over integers
    # 1..100 is approximately 40.  A shape around 1.4-1.6 with a suitable
    # scale gives a right-skewed histogram concentrated in the 20-60 range.
    sizes = np.arange(1, _CAP + 1, dtype=float)
    # Parameters chosen so mean ~ 40 (Weibull mean = lam * Gamma(1 + 1/k)).
    k = 1.6
    lam = 44.0
    # Continuous Weibull pdf (shape k, scale lam).
    pdf = (k / lam) * (sizes / lam) ** (k - 1.0) * np.exp(-(sizes / lam) ** k)
    pdf = pdf * (sizes >= 1)
    total = pdf.sum()
    if total <= 0:
        pdf = np.ones_like(sizes)
        total = pdf.sum()
    hist = pdf / total
    # hist[i] corresponds to item size (i+1).  Store indexed 0.._CAP with
    # index = size.
    full = np.zeros(_CAP + 1, dtype=float)
    full[1:] = hist
    return full


_HIST = _build_weibull_hist()


def _build_value_function():
    """G(r): expected future fillability of a residual capacity r.

    Rationale: a residual of r is more valuable when it is likely to be
    exactly usable by a future item (matching potential), and less valuable
    when it is too small to hold anything or so large that it is better
    treated as a fresh bin.  We model, for each residual r, the probability
    that at least one future item fits, weighted by the "waste" avoided by
    being able to fill it.  This yields a concave-then-flat profile which
    encourages leaving residuals near common item sizes.
    """
    sizes = np.arange(0, _CAP + 1, dtype=float)
    # Probability that a single future item fits in residual r.
    # cumulative over sizes <= r.
    cum = np.cumsum(_HIST)  # cum[r] = P(size <= r) for r in 0.._CAP
    # Expected number / mass of items that could fit residual r, but only
    # useful if the residual is actually consumed.  Use the "matchable
    # mass" = sum_{s<=r} p(s) * s / r  (fraction of r that a random
    # fitting item would consume), weighted by the fit probability.
    fit_prob = cum.copy()
    # expected fraction of r filled by a random fitting item:
    # E[s | s<=r] / r
    weighted = np.cumsum(_HIST * np.arange(0, _CAP + 1))
    # expected size given fit
    with np.errstate(divide="ignore", invalid="ignore"):
        cond_mean = np.where(cum > 1e-12, weighted / np.maximum(cum, 1e-12), 0.0)
        frac_filled = np.where(sizes > 0, cond_mean / np.maximum(sizes, 1.0), 0.0)
    frac_filled = np.clip(frac_filled, 0.0, 1.0)
    # fillability = probability a future item fits * how well it would fill.
    value = fit_prob * frac_filled
    # Add a mild term rewarding absolute usable capacity so large residuals
    # are not over-favored relative to small ones in a way that breaks bin
    # economy.
    value = value + 1e-4 * sizes / float(_CAP)
    return value


_G = _build_value_function()


def priority(item, bins):
    """Score each bin by the value of the residual it would leave.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every fitting bin (numpy int64, bin order).
    """
    residual = bins - item  # all >= 0 since bins is pre-filtered to fit
    residual = np.clip(residual, 0, _CAP)
    # Value of the residual after placing the item here.
    gain = _G[residual]
    # Tightest-fit tie-break: prefer the bin that ends up most tightly
    # packed (largest value density), scaled small so it only breaks ties
    # in the residual-value function.
    tie = -residual
    return gain + 1e-6 * tie
# EVOLVE-BLOCK-END
