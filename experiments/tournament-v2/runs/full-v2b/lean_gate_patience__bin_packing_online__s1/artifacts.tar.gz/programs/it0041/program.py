# EVOLVE-BLOCK-START
"""Static size-frequency residual-value packing rule.

Idea: instead of greedily minimizing the residual (best-fit), score each bin by how
"usefully fillable" its residual would be by typical future items. We model the item
size distribution with a fixed Weibull-shaped histogram whose mean is about 40 (the
distribution stated in the problem). For a residual capacity r we compute a convex
usefulness value: residuals equal to a common future item size are valuable because
the next such item can be packed there exactly, while residuals that are too small or
wasteful are penalized.

The score for a bin is the usefulness of the residual it would leave after placing
the arriving item. Placing an item into a bin may, however, also be motivated by
filling a residual that is "almost" a good fit, so we add a small term rewarding
placing the item where it comes close to consuming the whole residual without
leaving a large unusable remainder.
"""
import numpy as np

# ---- Fixed size-frequency model -------------------------------------------------
# We build a Weibull-shaped histogram with mean about 40 over sizes 1..100.
# Shape parameter chosen so the density is skewed right with mode below the mean,
# matching the "Weibull-shaped, mean about 40" description.
_k = 1.5
_lambda = 40.0 / float(np.math.gamma(1.0 + 1.0 / _k))  # so that mean = 40

_sizes = np.arange(1, 101, dtype=np.float64)
# Weibull pdf (scipy not needed; closed form).
_pdf = (_k / _lambda) * (_sizes / _lambda) ** (_k - 1.0) * np.exp(
    -(_sizes / _lambda) ** _k
)
_pdf = _pdf / _pdf.sum()
_HIST = _pdf  # probability of each size 1..100

# ---- Convex "useful residual" value function -----------------------------------
# For a residual capacity r, value(r) rewards the ability to fill r with upcoming
# items. We approximate the expected number of items that can be packed into r,
# weighted by the probability of common sizes, but we penalize unused leftover.
#
# A simple, monotone-in-fillability convex surrogate:
#   value(r) = sqrt(r / mean_size)  -- concave in r actually, so instead use a
#   convex-ish shape: encourage residuals that match highly probable sizes.
#
# We compute a per-residual score:
#   util[r] = sum_s HIST[s] * fit_bonus(r, s)
# where fit_bonus encourages residuals r that are near a multiple of s (can pack
# several items) and especially that leave little waste.
_rvals = np.arange(0, 101, dtype=np.float64)

# Pairwise fit matrix: for each residual r and each item size s, a bonus that is
# high when r can be exactly consumed or leaves small waste relative to s.
_util = np.zeros(101, dtype=np.float64)
for r in range(1, 101):
    acc = 0.0
    for s in range(1, 101):
        p = _HIST[s - 1]
        if p <= 0.0 or s > r:
            # item larger than residual: cannot help fill it
            continue
        # number of items of size s that fit
        q = r // s
        waste = r - q * s
        # reward exact divisibility (waste 0) and penalize waste; also reward
        # more items packed => better use of space
        fit_score = q * (1.0 - waste / float(s + 1))
        acc += p * fit_score
    _util[r] = acc

# Normalise util to a reasonable range.
_util = _util / (np.max(_util) + 1e-12)

# Precompute a fast lookup: _util is indexed by integer residual 0..100.
# Place item: residual = bins - item. score = util[residual] plus a small
# best-fit-like tiebreak (prefer tighter fits), scaled down so that it only
# breaks ties between equally useful residuals.
_util_arr = _util.astype(np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    Score = static size-frequency "useful residual" value of the residual the item
    would leave, plus a tiny best-fit tiebreak.
    """
    residual = bins - item  # numpy int64, >= 0 for all shown bins
    # Clip to valid range for lookup (bins shown all have enough capacity).
    r = np.clip(residual, 0, 100)
    useful = _util_arr[r]
    # Tiny tiebreak: prefer tighter fit (smaller residual), scaled small.
    tie = -residual.astype(np.float64) * 1e-6
    return useful + tie
# EVOLVE-BLOCK-END
