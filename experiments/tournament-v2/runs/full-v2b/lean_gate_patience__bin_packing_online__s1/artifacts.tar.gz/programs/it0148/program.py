# EVOLVE-BLOCK-START
"""Best-fit with a tiny tie-breaker that favors residuals that are more likely
to be exactly matched by a future item. Since exact fills (residual 0) are the
ideal, we bias (only among near-equal residuals) toward residuals divisible by
common small item sizes, keeping the dominant tightest-fit ordering."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    residual = bins.astype(np.float64) - item

    # Dominant term: tighter fit is better (smaller residual -> larger score).
    # Tiny secondary term (magnitude < 0.5, smaller than the 1.0 residual gap)
    # rewards residuals that are more "reusable": divisible by 2, 3, or 5.
    divisible = (
        (residual % 2 == 0).astype(np.float64)
        + (residual % 3 == 0).astype(np.float64)
        + (residual % 5 == 0).astype(np.float64)
    )
    return -residual + 0.001 * divisible
# EVOLVE-BLOCK-END
