# EVOLVE-BLOCK-START
"""Harmonic-matching bin choice.

Instead of only minimizing the residual, score each fitting bin by how many
"typical" future items its post-placement residual could still host. Items are
drawn from a fixed Weibull-shaped distribution with mean ~40, so we approximate
the value of a residual r as the expected number of future items it can hold,
summing over a set of representative sizes s the harmonic term 1/s when r >= s.
This favors residuals that are useful for the common small/medium items while
keeping tightness, reducing wasted slack.
"""
import numpy as np

# Representative sizes covering the item distribution (1..100, mean ~40).
_SIZES = np.arange(1, 101, dtype=np.float64)
# Approximate probability weights: heavier near the mode (~30-45), light tails.
_W = np.exp(-((_SIZES - 36.0) ** 2) / (2.0 * 30.0 ** 2))
_W /= _W.sum()
# Precompute per-size value weight 1/s for harmonic-style matching.
_VAL = _W / _SIZES


def priority(item, bins):
    """Score each bin by the expected number of future items its residual hosts."""
    r = bins.astype(np.int64) - item
    # Fit mask: only bins that can physically take the item get the value bonus.
    fits = r >= 0
    r_clipped = np.where(fits, r, 0)
    # Matrix of residuals (rows) vs representative sizes (cols): count matches.
    # For each bin, value = sum over sizes s <= r of weight_s / s.
    matched = (r_clipped[:, None] >= _SIZES[None, :])
    score = matched @ _VAL
    # Strong best-fit tiebreak: slightly prefer the tightest fit among equal value.
    score = score + 1e-3 / (r + 1.0)
    # Fresh (empty) bins get a tiny penalty to encourage reuse before opening.
    score = np.where(bins >= 100, score - 1e-6, score)
    return score
# EVOLVE-BLOCK-END
