# EVOLVE-BLOCK-START
"""Best-fit with a harmonic residual-class refinement.

For the Weibull-shaped size distribution (mean ~40), pure best-fit fragments
capacity into awkward small residuals.  We keep the strong best-fit ordering
but add a small, item-independent bonus for placing an item so that the
resulting residual lands in a "useful" size class: a residual that can still
hold a typical future item (~40) or stack evenly.  This nudges choices away
from dead-end residuals without disturbing near-exact fits.
"""
import numpy as np


def priority(item, bins):
    """Return a priority score for every bin; item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (all >= item), bin order.
    """
    residual = bins - item
    # Best-fit: strongly prefer the smallest non-negative residual.
    scores = 1.0 / (residual + 1.0)

    # Harmonic residual-class bonus: reward residuals that are multiples of the
    # typical item size (~40) or can still hold one more typical item, since
    # these leave capacity that is easy to fill later.
    r = residual.astype(np.float64)
    typical = 40.0
    # Fraction of a typical item that the residual can hold, capped at 2.
    frac = np.minimum(r / typical, 2.0)
    # Reward residuals that are integral multiples of ~40 (0 and 1 and 2 ideal).
    near_int = np.abs(frac - np.round(frac))
    class_bonus = (1.0 - near_int)
    scores = scores + 1e-4 * class_bonus

    # Mild bonus for reusing already-open bins over fresh (capacity-100) ones.
    scores = scores - 1e-6 * bins
    return scores
# EVOLVE-BLOCK-END
