# EVOLVE-BLOCK-START
"""Online bin packing: sharpened best-fit rule.

Items arrive one at a time and must be placed immediately.  The classic
best-fit heuristic places the item into the bin with the smallest residual
capacity that still fits.  Sharpening the preference (raising the score
contrast between residuals) tends to reduce fragmentation on Weibull-shaped
item sizes and lowers the number of bins used.

We score each bin by 1/(residual_after + 1)**p: this is monotonically
decreasing in the residual, so the smallest fitting residual gets the highest
score, and ties go to the first such bin (matching the harness tie rule).
The exponent p>1 increases the contrast near tight fits.
"""
import numpy as np

_P = 4.0


def priority(item, bins):
    """Score bins by sharpened best-fit: tighter residual after placement is better."""
    bins = np.asarray(bins, dtype=np.float64)
    residual_after = bins - float(item)

    # Sharpened best-fit: reward the tightest fit with increased contrast.
    score = 1.0 / (residual_after + 1.0) ** _P

    score = np.nan_to_num(score, nan=-1e18, posinf=1e18, neginf=-1e18)
    return score
# EVOLVE-BLOCK-END

