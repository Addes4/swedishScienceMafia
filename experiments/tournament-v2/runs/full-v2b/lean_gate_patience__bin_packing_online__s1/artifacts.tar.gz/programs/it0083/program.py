# EVOLVE-BLOCK-START
"""Best-fit with a pre-placement-capacity tie-break.

Primary criterion: minimize post-placement residual (classic best-fit).
Ties (the frequent exact-residual collisions) are broken by preferring the bin
with the larger pre-placement capacity, which preserves small "dust" bins for
small items and keeps empty bins usable for large items.
"""
import numpy as np


def priority(item, bins):
    """Highest score wins; best-fit, tie-broken by larger pre-placement capacity."""
    bins = np.asarray(bins)
    residual = bins - item                       # post-placement residual (>= 0)
    # Primary: smaller residual is better -> larger -residual.
    # Secondary (tiny weight): larger pre-placement capacity (bins) is better.
    # Scale so that a 1-unit residual gap always dominates any capacity tie-break.
    return -residual.astype(np.float64) + bins.astype(np.float64) / (bins.size + 2.0)
# EVOLVE-BLOCK-END
