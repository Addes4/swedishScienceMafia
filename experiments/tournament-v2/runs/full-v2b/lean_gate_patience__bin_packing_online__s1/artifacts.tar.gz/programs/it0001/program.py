# EVOLVE-BLOCK-START
"""Best fit with a small fragmentation-aware tie-break on the resulting residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smallest resulting residual (best fit).
    # Secondary: avoid residuals that are awkward to fill later (very small residue).
    score = -residual.astype(np.float64)
    # Mild penalty for tiny leftovers, which are hard to reuse.
    score -= 0.01 * np.exp(-residual.astype(np.float64) / 2.0)
    return score
# EVOLVE-BLOCK-END
