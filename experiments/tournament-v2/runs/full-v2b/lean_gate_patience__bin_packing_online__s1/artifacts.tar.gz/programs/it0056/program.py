# EVOLVE-BLOCK-START
"""Static size-frequency residual-value rule.

Idea: precompute a histogram of typical future item sizes (Weibull-shaped,
mean ~40).  Turn it into a value function V(r) = expected "usefulness" of
leaving residual capacity r in a bin, where usefulness rewards residuals that
can be well used by common future item sizes.  V is built to be convex-ish
(marginal value of residual decreasing) so that we don't leave huge residuals
unfilled and don't create tiny useless residuals.

For the arriving item we score each candidate bin by V(bin_remaining - item),
with a slight bonus for tight fits to break ties sensibly.
"""
import numpy as np

# --- Build the static size-frequency model once at import time ---------------
_CAP = 100

# Approximate a Weibull-shaped size distribution with mean ~40 (integer 1..100).
# We use a discretized Weibull with scale ~45, shape ~1.6, truncated to [1,100].
def _weibull_pmf():
    k = 1.6
    lam = 44.0
    sizes = np.arange(1, _CAP + 1, dtype=float)
    # Weibull pdf on (0, inf)
    pdf = (k / lam) * (sizes / lam) ** (k - 1.0) * np.exp(-(sizes / lam) ** k)
    pdf[0] = 0.0
    pdf = pdf / pdf.sum()
    return pdf

_PMF = _weibull_pmf()

# Expected number of future items of each size class, capped for tractability.
# We treat this as a normalized distribution over sizes 1..100.
_HIST = _PMF

def _build_value():
    """V[r] = expected usefulness of residual capacity r for r = 0..100.

     usefulness(r) = E_{future item s} [ 1 if s <= r else 0 ] * something
    We want convex-ish marginal value: early capacity is worth a lot (lets us
    place a common item), later capacity worth less.  A simple and effective
    construction: V[r] = sum_{s <= r} p(s) * s  -- the expected "mass" of
    future items that this residual can still host, weighted by item size.
    This is concave in r actually; we instead want marginal decreasing value
    of the residual, which this gives.  We also add a small bonus for being
    able to host a whole extra item.

    We blend two components:
      (a) probability mass of futures that fit  -> rewards larger residuals
      (b) expected packed size given fits       -> rewards usable residuals
    """
    r = np.arange(_CAP + 1, dtype=float)
    # cumulative probability that a future item fits in residual r
    cum = np.concatenate([[0.0], np.cumsum(_HIST)])  # cum[i] = P(s <= i)
    fit_prob = cum[r.astype(int)]
    # expected size of a future item conditional on it fitting (else 0)
    exp_size_given_fit = np.zeros(_CAP + 1)
    tail = np.cumsum(_HIST[::-1])[::-1]  # tail[i] = P(s >= i+1) with 0-index
    for rr in range(_CAP + 1):
        if rr == 0:
            exp_size_given_fit[rr] = 0.0
        else:
            sizes = np.arange(1, rr + 1)
            mass = _HIST[:rr].sum()
            if mass > 0:
                exp_size_given_fit[rr] = (sizes * _HIST[:rr]).sum() / mass
            else:
                exp_size_given_fit[rr] = 0.0
    # useful residual value: reward the ability to pack typical items
    V = fit_prob * exp_size_given_fit
    # Smooth slightly so it behaves well and is not too spiky
    V = 0.5 * V + 0.5 * np.convolve(V, np.ones(3) / 3.0, mode="same")
    return V

_VALUE = _build_value()


def priority(item, bins):
    """Score bins by the expected fillability of the leftover capacity."""
    residual = bins - item
    # clip to valid range (bins shown all fit the item, so residual >= 0)
    idx = np.clip(residual, 0, _CAP).astype(np.int64)
    base = _VALUE[idx]
    # small best-fit tie-break: prefer tighter fits (smaller residual)
    base = base - 1e-3 * residual
    return base
# EVOLVE-BLOCK-END
