# EVOLVE-BLOCK-START
"""Best-fit with a tiny near-full preference tie-break.

The harness shows us every bin the item fits in, along with its remaining
capacity. Best-fit places the item into the bin that leaves the smallest
non-negative residual, i.e. the tightest bin that still fits. This rule is
near-optimal on this Weibull-shaped size distribution (mean ~40), where items
must be placed immediately.

To squeeze out a bit more we add a tiny monotone tie-break that only matters
when two bins would leave exactly the same residual (e.g. two empty bins).
Among equal residuals we prefer the bin where the placed item covers a larger
*absolute* amount, i.e. a bin that was already more filled (smaller pre-residual).
This nudges the packer toward filling tight bins rather than scattering items
into fresh empty bins, without disturbing the dominant best-fit ordering.
"""
import numpy as np


def priority(item, bins):
    """Score each candidate bin; highest score wins, ties to the first bin.

    Primary term: negative residual left after placement (best-fit).
    Secondary term (tiny): prefer bins with smaller pre-placement residual,
    i.e. bins that were already tighter, among equal post-placement residuals.
    """
    b = np.asarray(bins, dtype=np.float64)
    residual_after = b - float(item)
    # Tiny tie-break: smaller pre-residual (tighter bin) is slightly preferred.
    return -residual_after - 1e-6 * b
# EVOLVE-BLOCK-END
