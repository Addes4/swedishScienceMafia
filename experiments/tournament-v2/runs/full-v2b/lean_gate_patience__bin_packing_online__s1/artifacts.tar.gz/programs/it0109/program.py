import numpy as np


def priority(item, bins):
    residual = bins - item  # remaining capacity after placing item in each bin

    if item <= 50:
        # Small item: strict best-fit (fullest bin that still fits).
        return -residual.astype(np.float64)

    # Large item: prefer the bin whose post-placement residual is closest to
    # the complementary large size (100 - item), so two large items can pair up.
    target = 100 - item  # residual we'd like to leave for a partner large item
    # Score: negative distance to target residual, then tie-break tightest fit.
    dist = np.abs(residual.astype(np.float64) - target)
    # Prefer residuals >= 0; all shown bins already fit (residual >= 0).
    # Add tiny best-fit preference for ties.
    return -dist - 1e-6 * residual.astype(np.float64)
