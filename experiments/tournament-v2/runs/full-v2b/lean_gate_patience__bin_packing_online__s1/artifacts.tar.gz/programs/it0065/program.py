# EVOLVE-BLOCK-START
"""Best-fit with residual-tie refinement and least-full tie-break.

Place each item into the bin leaving the smallest non-negative residual
(plain best-fit, near-optimal for this random-size stream). A tiny, strictly
bounded bonus is applied only to bins whose residual is within 1 of the best
fit, and which themselves have a residual equal to the most recently observed
item size; this keeps best-fit dominant while nudging reuse of exact leftovers.
Remaining ties favor the least-full bin.
"""
import numpy as np


def priority(item, bins):
    """Score each bin: best-fit dominant, with a tiny reusable-residual nudge.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (bins the item fits in).

    Returns a numpy array of scores (higher is better), same length, no NaN.
    """
    caps = bins.astype(np.float64)
    resid = caps - float(item)  # residual after placing item (>= 0)

    # Primary: best fit -> smaller residual scores higher.
    scores = -resid

    # Secondary: among near-equal residuals (within 1), prefer the bin whose
    # post-placement residual equals the current item size (exact reuse of a
    # just-seen size). Bounded by <1 so it never overrides a real fit gap.
    if item >= 1:
        near = np.abs(resid - float(item)) < 1e-9
        scores = scores + 0.5 * near.astype(np.float64)

    # Tertiary: least-full bin (larger pre-placement capacity) wins ties.
    scores = scores + caps / 1000.0

    return scores
# EVOLVE-BLOCK-END
