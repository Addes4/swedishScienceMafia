# EVOLVE-BLOCK-START
"""Best-fit with a mild consolidation tie-break.

Primary rule is pure best-fit: put the item in the bin with the smallest
residual capacity that still fits it.  This is the strongest known online
heuristic for this distribution.

Tie-break: when two bins would leave the same residual, prefer the one that
was already more full (smaller pre-placement remaining capacity), i.e.
consolidate into fuller bins rather than spreading items.  This leaves more
pristine bins with large free space for big future items.
"""
import numpy as np


def priority(item, bins):
    b = np.asarray(bins, dtype=np.float64)
    residual = b - item
    # Primary: exact best-fit -> smaller residual scores higher.
    # Weight large enough to dominate; tie-break uses -b so that a fuller
    # bin (smaller b) gets the higher score.
    return -residual * 1000.0 - b
# EVOLVE-BLOCK-END
