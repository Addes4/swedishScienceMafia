# EVOLVE-BLOCK-START
"""Hybrid best-fit bin packing.

For each arriving item we rank fitting bins by a score that is primarily
best-fit (small residual after placement) but augmented with a small
size-class bonus that rewards residuals which are "efficient" to refill
given the mean ~40 item distribution. Very large residuals are slightly
penalized so that already partially-filled bins are reused when the fit is
comparable, reducing fragmentation.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for all bins shown

    # Dominant term: best-fit -> smaller residual is better.
    scores = 1.0 / (residual + 1.0)

    # Mild preference for already-open bins (lower remaining capacity before
    # placement) over fresh bins whose remaining capacity is 100.
    scores -= 1e-6 * bins

    # Small size-class bonus: residuals close to the mean item size (~40) are
    # efficient to refill; very small residuals are also fine (tight fit).
    # Reward residuals in a mid band, penalize near-full fresh bins.
    band = np.exp(-((residual - 40.0) ** 2) / (2.0 * 30.0 * 30.0))
    scores += 1e-4 * band

    return scores
# EVOLVE-BLOCK-END
