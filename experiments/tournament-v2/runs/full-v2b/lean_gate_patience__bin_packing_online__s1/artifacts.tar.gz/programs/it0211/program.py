# EVOLVE-BLOCK-START
"""Best-fit backbone with a distribution-aware packability bonus.

Best-fit (prefer the smallest positive post-placement residual) is a very strong online
heuristic for this workload. We keep it dominant and only break near-ties using a value
function that measures how well a residual can be refilled by future Weibull-shaped items:
V(r) = expected future reward when starting from residual r, computed by value iteration
on the item-size pmf. This nudges the choice toward residuals that are easy to refill.
"""
import numpy as np

# Weibull-shaped item pmf over sizes 1..100 with mean ~40.
_sizes = np.arange(1, 101)
_k = 1.6
_lam = 45.0
_p = (_k / _lam) * (_sizes / _lam) ** (_k - 1.0) * np.exp(-(_sizes / _lam) ** _k)
_p = np.clip(_p, 1e-12, None)
_p /= _p.sum()

# Reward for a placement starting from residual r: 1 if some item fits, plus discounted
# continuation; overflow (item larger than r) yields zero reward for that draw.
_gamma = 0.95
_V = np.zeros(101, dtype=np.float64)
for _ in range(300):
    newV = np.empty(101, dtype=np.float64)
    # For each residual, expected immediate reward (prob any single drawn item fits and
    # we then continue from r - s) plus continuity term.
    # Compute cdf-based term for items that fit.
    for r in range(101):
        acc = 0.0
        for s in range(1, r + 1):
            acc += _p[s - 1] * (1.0 + _gamma * _V[r - s])
        newV[r] = acc
    if np.max(np.abs(newV - _V)) < 1e-9:
        _V = newV
        break
    _V = newV

# Normalize to a comparable scale.
_V = _V / (1.0 + _V.max())
# Prefer exact closes slightly: residual 0 fully retires the bin.
_V[0] += 0.02


def priority(item, bins):
    """Highest score wins; ties go to first bin. Best-fit dominant."""
    residual = bins - item
    # Dominant: best-fit. Big negative slope on residual so smallest residual wins.
    score = -residual.astype(np.float64)
    # Distribution-aware packability bonus to break near-ties among fitting residuals.
    score = score + 1e-2 * _V[np.clip(residual, 0, 100)]
    return score
# EVOLVE-BLOCK-END
