import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _total
    # online histogram of observed item sizes
    _counts[item] += 1.0
    _total += 1.0

    residual = bins - item  # all >= 0 (harness only passes fitting bins)
    res_f = residual.astype(np.float64)

    # smallest residual dominates
    score = -res_f

    # Among near-ties (within 2 of the minimum residual), break toward a
    # "reusable" leftover: exact fills first, then residuals that match
    # frequently seen item sizes.
    min_res = res_f.min()
    window = res_f <= (min_res + 2.0)

    # frequency-weighted reusability of the resulting residual
    freq = _counts / _total
    reuse = freq[residual.astype(np.int64)]  # prob that residual == some item size

    # exact fill bonus
    exact = (residual == 0).astype(np.float64)

    # tie-break term only applies within the window
    tie = 1e-3 * reuse + 1e-2 * exact
    score = np.where(window, score + tie, score)

    return score
