# EVOLVE-BLOCK-START
"""Best-fit bin-choice rule with an emptiest-bin tie-break, plus a
dead-zone-aware tie-break.

Classic best-fit (place into the bin leaving the smallest non-negative
residual) is the strongest simple online rule for this distribution. Among bins
that give the same residual we prefer the one with the largest pre-placement
remaining capacity (the emptiest such bin).

On top of that, exact ties in residual are further broken by preferring a
residual that is *not* in the tiny dead zone (0..ZONE) unless it is exactly 0:
a residual of exactly 0 is a perfect fill and is always best; small non-zero
residuals are likely to be unusable by future items, so among equal residual
values we slightly prefer the bin with a larger pre-placement capacity.
"""
import numpy as np

_ZONE = 6  # residuals 1..6 are treated as low-value dead-zone slots


def priority(item, bins):
    """Score each bin: best-fit primary, then dead-zone/emptiest tie-break.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    residual = bins - item
    r = residual.astype(np.float64)
    b = bins.astype(np.float64)
    # Primary: smaller residual is better -> large negative weight.
    # Weight 101 exceeds the max capacity span so the primary key dominates.
    score = -r * 101.0
    # Secondary: dead-zone penalty for tiny non-zero residuals. Magnitude is
    # small enough not to override the primary best-fit ordering.
    dz = ((residual > 0) & (residual <= _ZONE)).astype(np.float64)
    score -= dz * 0.5
    # Tertiary: larger pre-placement capacity is better (emptiest bin).
    score += b
    return score
# EVOLVE-BLOCK-END
