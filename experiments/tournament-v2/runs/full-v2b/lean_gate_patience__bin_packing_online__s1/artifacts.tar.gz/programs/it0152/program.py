import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": None}


def priority(item, bins):
    st = _state
    if st["hist"] is None:
        st["hist"] = np.zeros(101, dtype=np.float64)

    # Primary order: best-fit (smallest post-placement residual).
    residual = (bins - item).astype(np.float64)

    # Adaptive secondary bias: prefer residuals that match observed item sizes
    # (more likely to be exactly consumed later).
    if st["n"] == 0:
        bias = np.zeros_like(residual)
    else:
        # Normalize histogram to probabilities.
        p = st["hist"] / st["n"]
        # Value of a residual r: probability mass at r and nearby (exact-fill chance).
        idx = np.clip(residual.astype(np.int64), 0, 100)
        val = p[idx]
        # Spread to neighbors to smooth.
        val = val + 0.5 * p[np.clip(idx - 1, 0, 100)] + 0.5 * p[np.clip(idx + 1, 0, 100)]
        # Tiny weight so best-fit dominates; resolve only near-ties.
        bias = val * 1e-3

    score = -residual + bias

    # Update running histogram with current item (after scoring).
    st["hist"][item] += 1.0
    st["n"] += 1
    st["sum"] += item

    return score
