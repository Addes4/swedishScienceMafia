# EVOLVE-BLOCK-START
"""Best-fit with a learned soft fillability penalty on dead-zone residuals.

Pure best-fit squeezes residuals to tiny values, but tiny residuals often cannot
absorb a future item and thus waste space.  We keep best-fit as the dominant key
but add a small penalty for post-placement residuals that fall in a "dead zone"
(too small for a typical upcoming item) relative to the learned mean item size.
"""
import numpy as np

_state = {"mean": 40.0, "n": 0.0}


def priority(item, bins):
    # update a decayed running mean of item sizes
    _state["mean"] = 0.999 * _state["mean"] + 0.001 * float(item)
    _state["n"] += 1.0
    mean = _state["mean"]

    residual = bins - item  # residual if placed here

    # dead-zone penalty: residuals that are small but >= a fraction of the mean
    # are wasteful because a typical next item (size ~ mean) cannot fit snugly.
    r = residual.astype(np.float64)
    # smooth penalty peaking where r is around mean/2 (a typical item barely won't fit)
    penalty = np.exp(-((r - mean * 0.5) ** 2) / (2.0 * (mean * 0.35) ** 2))
    penalty *= (r > 0.0)  # only penalize residuals that still can't be filled

    score = -r * 1e6 - penalty * 1000.0
    return score
# EVOLVE-BLOCK-END
