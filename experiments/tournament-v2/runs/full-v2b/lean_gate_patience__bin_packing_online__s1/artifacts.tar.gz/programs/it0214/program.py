# EVOLVE-BLOCK-START
"""Best-fit with an exact-fill bonus.

Online bin packing rewards closing bins tightly. The dominant signal is therefore a
best-fit (smallest post-placement residual) rule, which keeps large bins open and produces
fewer bins. On top of that we add a small bonus for residuals r that can be exactly filled
by a single future item drawn from the Weibull-shaped size distribution, since such
residuals can be closed cleanly rather than left half-full.
"""
import numpy as np

# Weibull-shaped item pmf over sizes 1..100 with mean ~40.
_sizes = np.arange(1, 101)
_k = 1.6          # shape
_lam = 45.0       # scale
_p = (_k / _lam) * (_sizes / _lam) ** (_k - 1.0) * np.exp(-(_sizes / _lam) ** _k)
_p = np.clip(_p, 1e-9, None)
_p /= _p.sum()

# Single-fill probability: how likely a fresh item exactly equals residual r.
_fill_prob = np.zeros(101, dtype=np.float64)
_fill_prob[1:] = _p  # index r holds p(item == r)


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties go to first bin."""
    residual = bins - item
    r = np.clip(residual, 0, 100)
    # Dominant: best-fit, prefer smaller residual (keeps large bins open).
    score = -residual.astype(np.float64)
    # Small bonus: residuals that can be closed exactly by a future item.
    score = score + 5.0 * _fill_prob[r]
    # Prefer exact fits slightly over tiny positive remainders.
    score = score + 2.0 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
