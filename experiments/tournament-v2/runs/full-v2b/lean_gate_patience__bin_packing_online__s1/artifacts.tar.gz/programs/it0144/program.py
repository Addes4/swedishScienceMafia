# EVOLVE-BLOCK-START
"""Best-fit with a reusable-leftover tie-breaker.

Primary ordering: tightest fit (smallest post-placement residual), negated so the
largest score wins. As a secondary tie-breaker within a narrow band of residuals,
mildly prefer residuals that match common observed item sizes, since a leftover
equal to a frequent item size is likely to be exactly filled later.
"""
import numpy as np

# Online histogram of item sizes (1..100). Kept as module-level state.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    global _COUNT
    # Update online histogram with the current item (prior observations only).
    _HIST[item] += 1.0
    _COUNT += 1.0

    residual = bins.astype(np.float64) - item  # >= 0 for fitting bins

    # Primary: best-fit (smaller residual better).
    score = -residual

    # Secondary: prefer residuals equal to common item sizes. Use a bounded
    # bonus so it only breaks near-ties, not the dominant tight-fit order.
    if _COUNT > 0.0:
        res_idx = residual.astype(np.int64)
        res_idx = np.clip(res_idx, 0, 100)
        # Frequency of item sizes close to this residual (0..100).
        freq = _HIST[res_idx] / _COUNT
        # Small bounded bonus in [0, 0.5): cannot override a full unit of residual.
        score = score + 0.5 * (freq / (freq + 1.0))

    return score
# EVOLVE-BLOCK-END
