# EVOLVE-BLOCK-START
"""Best-fit with a smooth dead-zone penalty on post-placement residuals.

Classic best fit minimizes the post-placement residual.  A residual sitting just
below the typical item size (~40) is nearly worthless: too small to take a normal
item and too large to count as a nearly-full bin.  So we add a small penalty for
residuals in that dead zone, modelled as a Gaussian bump centred slightly below
the mean item size, which nudges packing to either nearly fill bins or leave
generous space for future items.
"""
import numpy as np



def priority(item, bins):
    residual = bins - item                       # residual if item goes here
    r = residual.astype(np.float64)
    # dead zone: residuals just below the typical item size are hard to reuse
    dead = np.exp(-((r - 30.0) ** 2) / (2.0 * 12.0 ** 2))
    score = -r - 6.0 * dead
    # tie-break toward the emptiest fitting bin to delay opening new bins
    score = score * 1e6 - bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
