# EVOLVE-BLOCK-START
"""Best fit with a small bias toward opening unused bins when the fit is loose."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit: prefer smallest residual after placement.
    # Slight bias: discourage leaving tiny residual fragments by rewarding
    # placements that fill a bin exactly or leave a large chunk usable later.
    # Exact fill (residual == 0) is strongly preferred; otherwise, among
    # residuals, prefer the smallest but avoid fragmenting (residual < item
    # and residual small relative to typical remaining need).
    score = -residual.astype(np.float64)
    # Reward exact fits
    score += (residual == 0) * 1e6
    return score
# EVOLVE-BLOCK-END
