# EVOLVE-BLOCK-START
"""Online bin packing: best-fit bin choice.

Items arrive one at a time and must be placed immediately.  The bin choice
rule ranks the bins the item fits in by the residual capacity that placing the
item there would leave, preferring the smallest such residual (tightest fit).
Empirically this monotone best-fit ordering is a strong online rule for the
target Weibull-shaped item distribution.
"""
import numpy as np


def priority(item, bins):
    """Score bins by best-fit: prefer the smallest residual after placement."""
    residual_after = bins - item
    return -residual_after.astype(np.float64)
# EVOLVE-BLOCK-END

