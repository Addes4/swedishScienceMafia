# EVOLVE-BLOCK-START
"""Best-fit with a stateful tie-break that favors residual capacities matching
frequently-seen past item sizes (i.e. leftovers that are likely to be closed)."""
import numpy as np

# Running histogram of item sizes seen so far (1..100), used to value leftovers.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0
# Tolerant band: residuals within this of the best residual are treated as ties.
_TOL = 1.0


def priority(item, bins):
    global _COUNT
    bins = np.asarray(bins)
    residual = bins - item  # >= 0 for all shown bins

    # Update running size histogram.
    _HIST[item] += 1.0
    _COUNT += 1.0

    # Normalized frequency of each possible residual (probability that a future item
    # exactly closes this leftover).
    freq = _HIST / _COUNT  # freq[s] = P(size == s) so far

    # Best-fit primary: smallest residual.
    r = residual.astype(np.float64)
    best = r.min()

    # Among bins whose residual is within tolerance of best, prefer a residual that
    # matches a frequent past item size, and give a small extra bonus for exact fits (0).
    within = (r <= best + _TOL)
    # Value of the leftover for the future: probability it can be exactly closed.
    scores = freq[np.clip(residual, 0, 100).astype(np.int64)]
    scores = scores + 0.001 * (residual == 0)

    # Primary key dominates: minimize residual; secondary only breaks near-ties.
    # Encode as: large negative for smaller residual, plus the tie-break value.
    return (-r * 1000.0) + np.where(within, scores, 0.0)
# EVOLVE-BLOCK-END
