# EVOLVE-BLOCK-START
"""Best-fit: place the item into the bin leaving the smallest non-negative residual."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Bins the harness offers always fit the item, so residual >= 0.
    # Prefer the smallest residual (tightest fit). Ties go to the first bin.
    return -residual
# EVOLVE-BLOCK-END

