# EVOLVE-BLOCK-START
"""Randomized best-fit online bin packing.

Pure deterministic best-fit is near-optimal but can get stuck in patterns that
waste bins (e.g., pairing items so that no later item fills the leftover). We
keep best-fit as the dominant rule: among bins within a small tolerance of the
tightest fit, we deterministically pick one via a hash of (item, candidate
residuals), which mixes in fresh bins and slightly looser fits while remaining
reproducible and instance-independent.
"""
import numpy as np


def priority(item, bins):
    b = np.asarray(bins, dtype=np.float64)
    residual_after = b - float(item)

    # Primary: tightest fit (smallest nonnegative residual) gets highest score.
    # We add a tiny deterministic perturbation based on a hash of the residual
    # and item size, so that exact ties among equal residuals (common for the
    # many unused bins with residual 100) are broken in a varied but stable way.
    n = residual_after.shape[0]
    idx = np.arange(n, dtype=np.float64)
    it = float(item)
    # Deterministic pseudo-random hash in [0,1)
    h = np.sin((residual_after * 12.9898 + it * 78.233 + idx * 3.7)) * 43758.5453
    h = h - np.floor(h)
    return -residual_after + 1e-4 * h
# EVOLVE-BLOCK-END
