# EVOLVE-BLOCK-START
"""Best-fit bin packing with a deepest-fit tie-break.

The dominant rule for this problem is best-fit: place the item into the bin
leaving the smallest post-placement residual.  We keep that as the primary
criterion, and add an infinitesimal secondary term that only matters when two
bins yield the *same* post-placement residual.  In that tie we prefer the bin
that was tighter *before* placement (smaller pre-placement residual), i.e. the
deepest fit, which gently reduces fragmentation without ever overriding the
primary best-fit ordering.
"""
import numpy as np


def priority(item, bins):
    bins = np.asarray(bins)
    residual = bins - item                       # post-placement residual (>=0)
    # Primary criterion: minimize post-placement residual (tightest fit).
    score = -residual.astype(np.float64)
    # Secondary tie-break, only active for equal residuals (magnitude tiny):
    # prefer the bin that was tightest before placement.
    score -= 1e-6 * bins.astype(np.float64)
    return score
# EVOLVE-BLOCK-END

