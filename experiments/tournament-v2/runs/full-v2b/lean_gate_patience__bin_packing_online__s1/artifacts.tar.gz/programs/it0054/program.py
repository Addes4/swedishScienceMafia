# EVOLVE-BLOCK-START
"""Best-fit via a smooth exponential-decay score.

Primary: among fitting bins, prefer the smallest post-placement residual
(pure best-fit). Using exp(-r) makes the ranking exactly best-fit while
giving a steep, strictly decreasing signal so numeric ties are essentially
impossible except for identical residuals.
Tie-break: among identical residuals, prefer the least-full bin (largest b),
which keeps large-open bins available for future large items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of bins the item fits in (numpy int64).
    """
    b = np.asarray(bins, dtype=np.float64)
    residual = b - item
    # Primary: best-fit -> smaller residual scores higher (exp is strictly decreasing).
    # Secondary: prefer larger pre-placement capacity to break residual ties.
    return -np.exp(-residual) + 1e-6 * b
# EVOLVE-BLOCK-END


