# EVOLVE-BLOCK-START
"""Static size-frequency residual-value bin packing rule.

Items arrive online.  For each arriving item we score every bin by how
"useful" the residual capacity left behind is likely to be, given a fixed
model of future item sizes (a Weibull-shaped histogram with mean ~40).

The idea: leaving a residual equal to a common future item size is valuable
(that bin can be nearly perfectly filled soon), whereas residuals that are
too small to hold typical items or that are slightly off from common sizes
are less valuable.  We express this as an expected fillability of the
residual using a convex useful-residual function evaluated against the
size-frequency histogram.
"""
import numpy as np

# ---------------------------------------------------------------------------
# Static size-frequency model of future items.
# Weibull distribution, shape k ~ 2, scale chosen so mean ~ 40.
# mean = scale * Gamma(1 + 1/k)
# ---------------------------------------------------------------------------
_K = 2.0
# Gamma(1.5) = 0.88622692545
_SCALE = 40.0 / 0.8862269254527580

_SIZES = np.arange(1, 101, dtype=np.float64)

# Weibull pdf on integer sizes 1..100 (shifted so size s -> s-0.5 for continuity)
def _weibull_pdf(x):
    x = np.clip(x, 1e-6, None)
    return (_K / _SCALE) * (x / _SCALE) ** (_K - 1.0) * np.exp(-(x / _SCALE) ** _K)


# Probability mass for each integer item size (with mass for size 100 including tail).
def _build_hist():
    xs = _SIZES - 0.5
    pdf = _weibull_pdf(xs)
    mass = pdf.copy()
    # Weight for the top bucket adds the tail beyond 99.5 as well, and renormalize.
    mass /= mass.sum()
    return mass


_HIST = _build_hist()                 # length 100, index i -> P(item = i+1)

# Cumulative availability: for a residual r, the chance that a future item of
# size <= r arrives.  We also build a convex "useful residual" value.
#
# Convex useful-residual idea:
#   value(r) = sum_s P(s) * min(s, r)          -> expected amount of capacity
#               that the *next* item can consume from this residual.
# This is concave in r in general (it's a capped sum), but the key property
# for choosing bins is that residuals matching common sizes are rewarded.
#
# To make placement decisions sharper, we additionally use a fill-efficiency
# score: expected fraction of residual fillable, weighted by the probability
# of being able to place *some* common item, emphasizing exact-fit residuals.

_PREFIX = np.cumsum(_HIST)            # _PREFIX[r-1] = P(item <= r)

# Expected fill of a residual of size r: E[min(s, r)] for s drawn from _HIST.
# E[min(s,r)] = sum_{s<=r} P(s)*s + r * P(s > r)
_SXP = _HIST * _SIZES                 # expected contribution of exact items
_CUM_SXP = np.cumsum(_SXP)            # sum_{s<=r} P(s)*s  at index r-1


def _expected_fill(r):
    """Vectorized E[min(s, r)] for r >= 0 (float arrays)."""
    r = np.asarray(r, dtype=np.float64)
    ri = np.clip(np.floor(r).astype(np.int64), 0, 100)
    # value from items fitting fully in r
    fit_sxp = np.where(ri >= 1, _CUM_SXP[np.clip(ri - 1, 0, 99)], 0.0)
    fit_p = np.where(ri >= 1, _PREFIX[np.clip(ri - 1, 0, 99)], 0.0)
    # items larger than r fill exactly r
    over_p = 1.0 - fit_p
    frac = r - ri  # fractional part handled approximately via interpolation
    # handle sub-integer residuals by linear blend toward next prefix
    nxt = np.clip(ri, 0, 99)
    nxt_p = _PREFIX[nxt]
    nxt_sxp = _CUM_SXP[nxt]
    fit_p = fit_p + frac * (nxt_p - fit_p)
    fit_sxp = fit_sxp + frac * (nxt_sxp - fit_sxp)
    over_p = 1.0 - fit_p
    return fit_sxp + r * over_p


# Fractional fill score of a residual: expected fill / residual.
# Rewards residuals that common items can almost completely consume.
def _fillability(r):
    r = np.asarray(r, dtype=np.float64)
    er = _expected_fill(r)
    safe = np.maximum(r, 1.0)
    return er / safe


# Precompute useful-residual values for every possible residual 0..100.
_RESID = np.arange(0, 101, dtype=np.float64)
_FILL = _fillability(_RESID)              # expected fraction filled by next item

# Blend expected-fill and fraction-filled to rank residuals.
# A convex combination emphasizing absolute useful capacity but rewarding high
# fill efficiency (so tightly-fitting residuals preferred).
_USEFUL = 0.5 * _expected_fill(_RESID) + 0.5 * _FILL * _RESID


def priority(item, bins):
    """Score bins by expected usefulness of the residual left after placement."""
    bins = np.asarray(bins, dtype=np.float64)
    residual_after = bins - float(item)
    idx = np.clip(residual_after, 0.0, 100.0).astype(np.int64)

    # Base useful-residual of what we leave behind.
    score = _USEFUL[idx].astype(np.float64)

    # Small tie-break toward tighter fit (best-fit flavour) so near-identical
    # useful residuals resolve in favour of fuller bins.
    score = score - 1e-3 * residual_after

    # Ensure no NaN/inf.
    score = np.nan_to_num(score, nan=-1e18, posinf=1e18, neginf=-1e18)
    return score
# EVOLVE-BLOCK-END
