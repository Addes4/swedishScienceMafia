# EVOLVE-BLOCK-START
"""Best-fit rule for online bin packing with a burn-in-free adaptive nudge.

Primary rule: best fit (smallest non-negative residual). Ties (and near
ties within a narrow window) are broken by which post-placement residual
matches the most common recent item size, so leftover gaps are likely to
be filled by upcoming items.
"""
import numpy as np

# State: recently observed item sizes (all-time histogram kept cheaply).
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_DECAY = 0.999


def _reset():
    global _hist, _count
    _hist = np.zeros(101, dtype=np.float64)
    _count = 0.0


def priority(item, bins):
    """Rank bins: best fit (smallest residual), tie-break by fillability."""
    global _count
    it = int(item)

    # Update running histogram (decayed) of past items for fillability estimates.
    _hist *= _DECAY
    _hist[it] += 1.0
    _count = _count * _DECAY + 1.0
    if _count < 1e-9:
        _count = 1e-9
    pmf = _hist / _count

    caps = bins.astype(np.int64)
    residual = caps - it

    # Fillability of a residual r: probability a future item can exactly fill it,
    # approximated as the recent frequency of size r (capped at 100).
    r_idx = np.clip(residual, 0, 100)
    fill = pmf[r_idx]

    # Primary key: best fit. Use a large scale so fill never overrides a
    # strictly smaller residual, but helps among similar residuals.
    # Allow fill to act as tie-break by making its weight small relative to 1.
    score = -residual.astype(np.float64) * 1000.0 + fill * 500.0 + caps.astype(np.float64) * 1e-3
    return score
# EVOLVE-BLOCK-END

