# EVOLVE-BLOCK-START
"""Best-fit bin packing with an online size-awareness bonus.

Place each arriving item into the bin that is the best fit (smallest residual),
but add a secondary score based on a running histogram of observed item sizes:
residuals that can snugly hold the most frequent past sizes are preferred,
which reduces the fragmentation left behind for the Weibull-shaped sizes.
"""
import numpy as np

# Running (smoothed) counts of item sizes 1..100.
_size_counts = np.ones(101, dtype=np.float64)
_n_seen = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (all >= item), bin order.
    """
    global _n_seen

    # Update the size histogram with the new item (Laplace-smoothed).
    _size_counts[item] += 1.0
    _n_seen += 1.0

    residual = bins - item  # non-negative

    # Base: best-fit -> smaller residual after placement is better.
    scores = 1.0 / (residual + 1.0)

    # Secondary: reward residuals that can still tightly hold a common size.
    # For each bin's residual r, value it by max over sizes s <= r of
    # freq(s) * s / (r + 1); this prefers leaving gaps that match a frequent
    # future item closely (small waste relative to room).
    freq = _size_counts / _size_counts.sum()  # probability over sizes 1..100
    r = residual.astype(np.float64)

    # Precompute, for each possible residual value 0..100, the best "fit value".
    # fitval(R) = max_{1<=s<=R} freq[s] * (s / (R + 1))
    max_res = 100
    # matrix of s/(R+1)*freq[s] for s <= R
    Rvals = np.arange(max_res + 1, dtype=np.float64)  # 0..100
    Svals = np.arange(max_res + 1, dtype=np.float64)  # sizes 0..100
    # weight for size s and residual R: freq[s]*s/(R+1) when 1<=s<=R else -inf
    W = (freq[None, :] * Svals[None, :]) / (Rvals[:, None] + 1.0)
    # mask out s==0 and s>R
    mask = (Svals[None, :] >= 1.0) & (Svals[None, :] <= Rvals[:, None])
    W = np.where(mask, W, -1.0)
    fitval = W.max(axis=1)  # length 101

    r_clip = np.clip(residual, 0, max_res).astype(int)
    scores = scores + 0.01 * fitval[r_clip]

    return scores
# EVOLVE-BLOCK-END
