# EVOLVE-BLOCK-START
"""Best-fit with reusable-residual tie-break.

Plain best-fit (place the item so the leftover is minimal) is near-optimal
for this random stream. The remaining loss comes from what the leftover
space looks like: a residual that exactly equals a common future item size
can be reused with zero waste, while a "dead" residual (one that no arriving
item can fill exactly) is effectively wasted.

We keep best-fit strictly dominant, but among bins whose residual is close
to the minimum, we add a bounded bonus for residuals that are either 0
(perfect fill) or match a frequently observed item size, using a running
histogram of past items. The bonus is kept small enough never to override a
strictly better best-fit choice.
"""
import numpy as np


_CAP = 100
# State kept between calls: a normalized running histogram of item sizes.
_size_counts = np.zeros(_CAP + 1, dtype=np.float64)
_total_items = 0.0


def priority(item, bins):
    """Score bins: minimize residual, with a small reusable-residual bonus.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (item fits in all of them).
    """
    global _total_items

    resid = bins - item  # residual after placement, >= 0 for shown bins

    # --- update running histogram of observed item sizes (incremental) ---
    _total_items += 1.0
    _size_counts[item] += 1.0
    # Laplace-smoothed normalized frequency of each size.
    freq = (_size_counts + 1.0) / (_total_items + _CAP)

    # Primary term: best fit (smaller residual => higher score).
    scores = -resid.astype(np.float64)

    # Reusable-residual bonus, bounded to < 1 so it only breaks near-ties.
    # A residual of 0 is maximally reusable; otherwise reward residuals that
    # match a common item size.
    reusable = freq[resid]  # in roughly [0, ~0.05]
    # Give exact fills (residual 0) a modest extra, still well below 1.
    perfect = (resid == 0).astype(np.float64)
    scores += 0.9 * perfect + 0.9 * reusable

    return scores
# EVOLVE-BLOCK-END
