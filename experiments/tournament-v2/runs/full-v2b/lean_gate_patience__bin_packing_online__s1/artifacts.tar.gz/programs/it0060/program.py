# EVOLVE-BLOCK-START
"""Best-fit with a reusable-residual (exact-fill) bonus.

Primary signal remains best-fit: the item prefers the bin leaving the smallest
non-negative residual.  On top of that we add a bonus when the post-placement
residual equals a size that recurs in the input stream, because such a leftover
can later be filled exactly.  A running histogram of observed item sizes (built
only from past items) estimates how likely a given residual is to be reusable.
Ties on the primary fit are broken toward the least-full bin, keeping some bins
open and flexible.
"""
import numpy as np


def priority(item, bins):
    """Score bins by best-fit plus a reusable-residual bonus."""
    residual = (bins - item).astype(np.int64)

    # Build a running value estimate for each possible residual.  We keep a
    # histogram of past item sizes; a residual r is valuable if r is a size
    # that shows up often (so the leftover can likely be filled exactly).
    hist = priority.hist
    if hist is not None:
        bonus = hist[residual]
    else:
        bonus = 0.0

    # Primary: best fit (smaller residual better).  Secondary: least-full bin
    # (larger pre-placement capacity).  Tertiary: reusable-residual bonus.
    score = -residual.astype(np.float64) * 1e6
    score += bins.astype(np.float64)
    score += bonus.astype(np.float64) * 1e4

    # Update histogram with the current item for future calls.
    priority.hist[item] += 1.0

    return score


priority.hist = np.zeros(101, dtype=np.float64)
# EVOLVE-BLOCK-END
