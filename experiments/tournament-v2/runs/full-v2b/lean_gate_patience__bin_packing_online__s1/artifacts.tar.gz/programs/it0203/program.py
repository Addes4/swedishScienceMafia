# EVOLVE-BLOCK-START
"""Best-fit with a stateful exact-fit / historical-residual bonus."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)  # counts of past item sizes 1..100
_TOTAL = 0.0


def priority(item, bins):
    global _TOTAL
    bins = np.asarray(bins)
    residual = (bins - item).astype(np.float64)  # >= 0 for shown bins

    # Best-fit primary component (smaller residual strongly preferred).
    score = -residual

    # Bonus if the post-placement residual is exactly zero (perfect closure).
    score += 1.0 * (residual == 0.0)

    # Light bonus if the residual matches a frequently-seen past item size,
    # making the leftover easily closable by a future item.
    idx = np.clip(residual.astype(np.int64), 0, 100)
    if _TOTAL > 0:
        freq = _HIST[idx] / _TOTAL
        score += 2.0 * freq

    # Update running histogram with the current item.
    _HIST[int(item)] += 1.0
    _TOTAL += 1.0
    return score
# EVOLVE-BLOCK-END
