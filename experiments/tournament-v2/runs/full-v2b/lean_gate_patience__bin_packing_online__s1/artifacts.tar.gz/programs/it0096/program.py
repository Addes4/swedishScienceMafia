# EVOLVE-BLOCK-START
"""Best-fit with a small-hole penalty for online bin packing.

The harness shows us every bin the item fits in, along with its remaining
capacity. Best-fit places the item into the bin that leaves the smallest
non-negative residual, i.e. the tightest bin that still fits. This is
near-optimal on this Weibull-shaped size distribution (mean ~40), but it tends
to create tiny "holes" (residuals too small to ever be filled again), which can
waste a bin for the whole run.

We keep best-fit dominant, but subtract a small penalty for residuals that fall
in an unusable small-hole range, so among near-tight fits we slightly prefer
leaving a residual that still has a chance of being reused.
"""
import numpy as np

# A residual below this is effectively unusable for the ~40-mean distribution,
# so creating one risks wasting the bin entirely.
SMALL_HOLE = 10.0


def priority(item, bins):
    """Score each candidate bin; highest score wins, ties to the first bin.

    Primary term is the usual best-fit score (negative post-placement residual).
    A small penalty discourages leaving an unusable tiny residual.
    """
    b = np.asarray(bins, dtype=np.float64)
    residual_after = b - float(item)

    # Best-fit: prefer the smallest non-negative residual.
    score = -residual_after

    # Penalize residuals in the unusable small-hole range.
    small = (residual_after >= 0.0) & (residual_after < SMALL_HOLE)
    score = score - np.where(small, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
