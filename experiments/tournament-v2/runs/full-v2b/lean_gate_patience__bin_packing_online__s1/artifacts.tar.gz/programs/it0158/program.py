# EVOLVE-BLOCK-START
"""Best-fit with a capacity-preferring tie-break.

Primary key: smallest post-placement residual (best-fit).
Tie-break: among bins whose residual is within 1 unit of the minimum,
prefer the bin with the largest current remaining capacity, which tends
to keep later large items placeable and avoids stranding.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    min_res = residual.min()
    # Prefer tightest fit; break near-ties toward larger remaining capacity.
    near = residual <= (min_res + 1)
    tie_bonus = np.where(near, bins, 0).astype(np.float64)
    return -residual.astype(np.float64) * 1000.0 + tie_bonus
# EVOLVE-BLOCK-END

