# EVOLVE-BLOCK-START
"""Best-fit bin-choice rule with an emptiest-bin tie-break.

Classic best-fit (place into the bin leaving the smallest non-negative residual)
is the strongest simple online rule for this distribution. Among bins that give
the same residual we prefer the one with the largest pre-placement remaining
capacity, i.e. the emptiest such bin, because a fuller bin (smaller pre-placement
capacity) is better reserved for items that only just fit there.

We implement this as a single lexicographic score: the primary key is the
post-placement residual (smaller is better), scaled by a large constant so it
dominates, plus the pre-placement capacity as a fine tie-break (larger is
better). This exactly reproduces best-fit when residuals differ, and uses the
emptiest-bin preference only when residuals tie.
"""
import numpy as np


def priority(item, bins):
    """Score each bin: best-fit primary, emptiest-fitting-bin tie-break.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    residual = bins - item
    # Primary: smaller residual is better -> large negative weight.
    # Secondary: larger pre-placement capacity is better -> small positive weight.
    # The weight on residual (CAP+1 = 101) exceeds the max possible capacity span,
    # so the primary key strictly dominates.
    return -(residual.astype(np.float64)) * 101.0 + bins.astype(np.float64)
# EVOLVE-BLOCK-END

