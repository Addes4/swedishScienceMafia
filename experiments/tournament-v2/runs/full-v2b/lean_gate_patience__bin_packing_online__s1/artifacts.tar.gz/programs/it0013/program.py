# EVOLVE-BLOCK-START
"""Harmonically-weighted best fit.

Best fit (minimize post-placement residual) is a strong online rule. A linear
fill score under-weights near-exact fits, so we instead rank by 1/(residual+1),
which sharply favors bins that end up nearly full while still ordering all other
bins sensibly. A tiny bonus for reusing already-open bins reduces fragmentation.
All computation is O(nbins) with pure numpy.
"""
import numpy as np


def priority(item, bins):
    residual = bins.astype(np.float64) - item
    np.clip(residual, 0.0, 100.0, out=residual)

    # Sharply prefer bins that end up nearly full.
    score = 1.0 / (residual + 1.0)

    # Tiny bonus for reusing an already-open bin rather than opening a fresh one.
    score += np.where(bins < 100, 0.0005, 0.0)

    return score
# EVOLVE-BLOCK-END
