# EVOLVE-BLOCK-START
"""Best-fit bin packing with an adaptive empty-bin penalty.

Place each item into the fitting bin that leaves the smallest non-negative
residual capacity.  A mild penalty discourages opening a fresh (empty) bin;
the penalty grows with the item size, because large items should preferentially
reuse partial bins (they are hard to place later), whereas small items may seed
new bins cheaply.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (all >= item), bin order.
    """
    residual = bins - item
    # Best-fit: prefer smaller residual after placement.
    scores = 1.0 / (residual + 1.0)
    # Penalize fresh bins; scale grows with item size so large items avoid new bins.
    empty = bins == 100
    penalty = 1e-5 * (item / 100.0)
    scores = scores - penalty * empty
    return scores
# EVOLVE-BLOCK-END
