# EVOLVE-BLOCK-START
"""Static size-frequency residual-value packing rule.

For each candidate bin we compute the residual r = remaining_capacity - item that
would result from placing the arriving item there. We then score the bin by how
"usefully fillable" that residual is: we estimate, using a fixed model of the
arriving-item size distribution (Weibull-shaped, mean ~40), the value of the
residual capacity, where the value function is convex and peaks when the
residual equals a common future item size. Bins whose residual is likely to be
matched by a typical future item are preferred.
"""
import numpy as np

# ---- Build a static model of the item-size distribution -------------------
# Weibull-shaped distribution with mean ~40 on the integer range 1..100.
# Shape k and scale lam chosen so that mean ~ 40 (k ~ 1.6, lam ~ 44.7).
_K = 1.6
_LAM = 44.7

_SIZES = np.arange(1, 101, dtype=np.float64)
# Weibull pdf (unnormalized), evaluated on integer sizes
_PDF = (_K / _LAM) * (_SIZES / _LAM) ** (_K - 1.0) * np.exp(-(_SIZES / _LAM) ** _K)
# Probability mass per integer size (truncated to 1..100, renormalized)
_MASS = _PDF / _PDF.sum()

# Expected item size under the model (used in the value function)
_MEAN = float((_SIZES * _MASS).sum())

# ---- Precompute the "useful residual" value for every possible residual ----
# Residuals range from 0 up to 99 (we never leave residual < 0 here since bins
# shown all fit the item; residual up to 100 - 1 = 99, but include 0..100).
_RES_CAP = np.arange(0, 101, dtype=np.float64)

# A convex value function v(r):
#   * v(0) is 0 (wasted bin potential, but actually r=0 means perfect fit -> good)
#   * larger residuals are generally better (more free space) but we reward
#     residuals that match common future item sizes (so they can be reused).
#
# Build the fillability component: for a residual r, how much expected item mass
# falls in the interval [0, r] weighted toward exact common sizes. We use the
# probability mass of items with size <= r, but weight heavily the mass exactly
# equal to common sizes by adding a term p(r) at the residual value itself.
_fill_mass = np.cumsum(_MASS)  # _fill_mass[i] = P(size <= i+1), for size index
# Probability that a future item can be placed in a residual of size r.
_fit_prob = np.zeros_like(_RES_CAP)
for i, r in enumerate(_RES_CAP):
    ri = int(r)
    if ri <= 0:
        _fit_prob[i] = 0.0
    elif ri >= 100:
        _fit_prob[i] = 1.0
    else:
        _fit_prob[i] = _fill_mass[ri - 1]

# Exact-match bonus: high probability that residual equals a frequently
# occurring item size, so it can be filled exactly.
_exact = np.zeros_like(_RES_CAP)
for i, r in enumerate(_RES_CAP):
    ri = int(r)
    if 1 <= ri <= 100:
        _exact[i] = _MASS[ri - 1]

# Convex value: reward usable capacity, plus a bonus for matching common sizes,
# with a slight penalty for leaving a very large empty residual (wasting a bin).
_VALUE = (1.0 * _fit_prob
          + 3.0 * _exact
          - 0.002 * (_RES_CAP ** 2) / 100.0
          - 0.5 * (1.0 - _fit_prob))
# Ensure convex-ish growth toward moderate residuals; store as lookup table.
_VALUE_TABLE = _VALUE


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    r = bins - item  # residual capacity if placed in each bin
    r = np.clip(r, 0, 100)
    # Look up the static value of each residual, then interpolate.
    scores = np.interp(r, _RES_CAP, _VALUE_TABLE)
    # Prefer bins that are already more occupied (lower residual) as a mild
    # tie-breaker, since keeping large empty bins available is valuable.
    scores = scores - 0.001 * bins
    return scores
# EVOLVE-BLOCK-END
