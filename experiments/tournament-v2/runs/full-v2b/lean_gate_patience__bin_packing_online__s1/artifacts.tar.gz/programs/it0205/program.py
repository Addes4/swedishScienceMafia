# EVOLVE-BLOCK-START
"""Residual-preference rule: score by (residual)^alpha, tuned for the Weibull item mix."""
import numpy as np

# alpha > 1 favors LARGER residuals (more room for future items, worst-fit-like),
# alpha < 1 favors smaller residuals (tightest-fit). Pure best-fit ~ alpha very negative.
_ALPHA = 1.0
_SCALE = -1.0


def priority(item, bins):
    """Score bins by a power of the post-placement residual."""
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # >= 0 for all shown bins

    # Prefer larger residuals so the bin stays flexible for future arrivals.
    score = _SCALE * np.power(residual, _ALPHA)
    return score
# EVOLVE-BLOCK-END
