# EVOLVE-BLOCK-START
"""Size-frequency residual-value rule.

Idea: the item sizes come from a fixed Weibull-shaped distribution (mean ~40).
If we know the size histogram, a leftover capacity r is "useful" if it exactly
matches some common future item size, and less useful otherwise.  We build a
convex value function V(r) = expected fillability of residual r, i.e. how many
future items (in the sense of a greedy best-fit simulation over the histogram)
can be expected to close the bin tightly.

Concretely we build the histogram h[s] for s = 1..100 once (Weibull, mean ~40),
then compute:

    P(r) = sum_s h[s] * 1[s == r]              (chance an item exactly fills r)
    W(r) = sum_s h[s] * s * 1[s <= r]          (expected amount usable later)

and define the residual value

    V(r) = P(r) + W(r)/100

so that residuals matching common item sizes are strongly rewarded, and larger
usable residual mass is mildly rewarded.  Larger r has more usable mass but
less likely exact fit; the P term dominates for "nice" residuals.

For an arriving item in a bin with remaining capacity b (b >= item), the
post-placement residual is r = b - item.  We score:

    score = V(r) + eps * (-(b - item))

The eps term is a tiny tightest-fit tie-break so that among equally valuable
residuals we prefer the tightest placement, which empirically helps.
"""
import numpy as np

# ---- build the size histogram once ---------------------------------------
# Weibull(shape=2, scale=45) has mean = 45*Gamma(1.5) ~ 39.9, matching the
# stated "mean about 40".  We discretize onto integers 1..100 and renormalize.
_k = 2.0
_lam = 45.0
_sizes = np.arange(1, 101, dtype=np.float64)
_cdf = 1.0 - np.exp(-((_sizes / _lam) ** _k))
_pdf = np.diff(np.concatenate(([0.0], _cdf)))
_pdf = np.clip(_pdf, 1e-9, None)
_h = _pdf / _pdf.sum()                       # histogram over sizes 1..100

# ---- residual value function --------------------------------------------
# V_index[r-1] = value of leaving residual r (r in 1..100).
# We also need r == 0 (bin exactly filled): that is the best outcome.
_exact = np.zeros(101, dtype=np.float64)     # _exact[r] = h[r] (exact fit prob)
for s in range(1, 101):
    _exact[s] = _h[s - 1]

# usable mass: expected size of a future item that fits in residual r
_usable = np.zeros(101, dtype=np.float64)
_running = 0.0
for r in range(1, 101):
    _running += _h[r - 1] * r
    _usable[r] = _running

# V(r): exact-fit reward + mild usable-mass reward.
# r = 0 means perfectly closed: give it the max value.
_V = np.zeros(101, dtype=np.float64)
_V[1:] = _exact[1:] + _usable[1:] / 100.0
_V[0] = _exact.max() + _usable.max() / 100.0 + 1.0   # bonus for exact closure

_EPS = 1e-4


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins."""
    bins = np.asarray(bins)
    residual = bins - item                      # >= 0 guaranteed by harness
    residual_clipped = np.clip(residual, 0, 100)
    # gather V(r) for each bin's post-placement residual
    val = _V[residual_clipped]
    return val - _EPS * residual
# EVOLVE-BLOCK-END
