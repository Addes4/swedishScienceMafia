# EVOLVE-BLOCK-START
"""Adaptive fillability rule: score a bin by how fillable the residual it leaves will be.

We learn the item-size distribution online (a smoothed histogram of past items), then use
it to build a convex "coverage" value function over residual capacities. The value of a
residual r is the expected amount of r that future items can consume, which rewards leaving
residuals that future items are likely to match tightly.
"""
import numpy as np

# ---- online-learned size distribution (module state, persists across calls) ----
_hist = np.zeros(101, dtype=np.float64)     # counts of observed sizes 1..100
_seen = 0.0                                 # total (smoothed) observations
# pseudo-count prior: gentle uniform smoothing so early calls behave sensibly
_hist[1:101] += 0.5
_seen += 50.0

# cached value function, rebuilt occasionally
_G = None
_G_age = 0
_REBUILD_EVERY = 25


def _rebuild_value():
    """Build convex value function G[r] = expected useful fill of residual capacity r.

    G[r] = E_over future item sizes s of [ s if s <= r else (some fallback) ].
    We use G[r] = sum_s p_s * min(s, r)  which is concave in r? No: min(s, r) is concave
    in r, so we instead value *reduction* of residual, i.e. a convex fillability curve:
    use H[r] = r - sum_s p_s * min(s, r) = expected wasted residual if one more item comes,
    and score bins by -H[residual].  H is convex; good.
    """
    global _G, _G_age
    p = _hist[1:101] / max(_seen, 1e-9)
    sizes = np.arange(1, 101, dtype=np.float64)
    r = np.arange(0, 101, dtype=np.float64)
    # expected consumption by a single future item, clipped to capacity
    # min(s, r) for each r
    cap = np.minimum(sizes[None, :], r[:, None])          # shape (101, 100)
    exp_consume = cap @ p                                  # shape (101,)
    # convex wasted-residual function: how much capacity is likely to go unused
    H = r - exp_consume
    _G = H
    _G_age = 0


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties)."""
    global _seen, _G_age

    # update learned distribution with the incoming item
    _hist[item] += 1.0
    _seen += 1.0

    if _G is None or _G_age >= _REBUILD_EVERY:
        _rebuild_value()
    _G_age += 1

    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item                                # residual after placement, >= 0
    np.clip(residual, 0, 100, out=residual)

    # lower "wasted residual" is better -> negate H.  Tightest fit is the r=0 case.
    score = -_G[residual]

    # tie-break/blend: prefer tighter fits, which is the strong baseline
    score = score.astype(np.float64) - 1e-6 * residual

    return score
# EVOLVE-BLOCK-END
