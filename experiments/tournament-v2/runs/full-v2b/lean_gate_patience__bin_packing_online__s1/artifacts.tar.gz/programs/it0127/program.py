# EVOLVE-BLOCK-START
"""Best-fit with a dominant empirical-residual-match term.

The key idea: for i.i.d. items, a leftover residual r is most valuable when
r is a size that frequently shows up later, since then it can be filled by a
single future item.  We therefore rank bins primarily by the empirical
probability that some future item will exactly equal the residual (a smoothed
PMF evaluated at r), which rewards packing residuals onto common item sizes,
with strict best-fit (small residual) as a strong secondary signal.
"""
import numpy as np

_CAP = 100
_NBINS_HIST = 101
_ALPHA = 0.5
_MATCH_W = 10.0
_BESTFIT_W = 1.0

_hist = np.full(_NBINS_HIST, _ALPHA, dtype=np.float64)
_total = float(_NBINS_HIST * _ALPHA)


def priority(item, bins):
    """Return a score per bin; item goes to the highest (first on ties)."""
    global _total

    if 1 <= item <= _CAP:
        _hist[item] += 1.0
        _total += 1.0

    b = bins.astype(np.float64)
    residual = b - float(item)  # capacity left after placing the item

    idx = np.clip(residual.astype(np.int64), 0, _CAP)

    # Empirical probability mass at this residual: chance a future item
    # exactly fills the leftover space in one shot.
    pmf = _hist / _total
    match = pmf[idx]

    # Dominant: reward residuals that are common upcoming item sizes.
    scores = _MATCH_W * match

    # Secondary: strict best-fit, smaller residual preferred.
    scores -= _BESTFIT_W * residual

    # Perfect fill: extra reward.
    scores = np.where(residual == 0, scores + 5.0, scores)

    # Infeasible bins must never be chosen.
    scores = np.where(residual >= 0, scores, -1e18)

    return scores
# EVOLVE-BLOCK-END
