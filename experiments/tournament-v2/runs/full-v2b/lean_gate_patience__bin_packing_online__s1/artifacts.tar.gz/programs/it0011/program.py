# EVOLVE-BLOCK-START
"""Best-fit with a recent-size residual reward.

Place into the bin that becomes fullest (best fit), but boost bins whose
post-placement residual matches a recently seen item size, since such bins are
likely to be finished off by a similar item soon. Uses a small exponential
histogram of past items for state.
"""
import numpy as np

_SIZES = 100
_hist = np.zeros(_SIZES + 1, dtype=np.float64)
_recent = 0


def priority(item, bins):
    global _recent

    residual = bins.astype(np.float64) - item
    np.clip(residual, 0.0, 100.0, out=residual)

    fill = (100.0 - residual) / 100.0

    # reward small residuals that match a recent item size (likely to be filled)
    res_idx = residual.astype(np.int64)
    match = _hist[np.clip(res_idx, 0, _SIZES)]

    open_bonus = np.where(bins < 100, 0.02, 0.0)

    score = fill + 0.05 * match * np.where(residual > 0, 1.0, 0.0) + open_bonus

    # update running histogram with decay
    _hist *= 0.995
    _hist[item] += 1.0
    _recent += 1

    return score
# EVOLVE-BLOCK-END
