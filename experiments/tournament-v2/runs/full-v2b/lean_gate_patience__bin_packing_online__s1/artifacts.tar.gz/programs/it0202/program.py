# EVOLVE-BLOCK-START
"""Best-fit with online-learned residual coverage tie-breaking."""
import numpy as np

# Online histogram of recent item sizes (Laplace-smoothed), used only as a tie-break.
_HIST = np.ones(101, dtype=np.float64)
_HIST[0] = 0.0  # size 0 never occurs
_TOTAL = float(_HIST.sum())
_DECAY = 0.995


def _record(item):
    global _HIST, _TOTAL
    _HIST *= _DECAY
    _HIST[item] += 1.0
    _TOTAL = _HIST.sum()


def priority(item, bins):
    bins = np.asarray(bins)
    residual = bins - item  # >= 0 for all shown bins

    # Primary: best-fit -> smallest post-placement residual.
    # Secondary: among residuals close to the best, prefer ones whose residual value
    # is a likely future item size (better chance to be exactly closed later).
    best = residual.min()
    # Coverage bonus: probability mass that residual could be filled by one item soon.
    rr = residual
    idx = np.clip(rr.astype(np.int64), 0, 100)
    cover = _HIST[idx] / _TOTAL  # higher if residual is a common size

    # Combine: dominant best-fit, small coverage tie-break, tiny final tightness key.
    score = -(residual.astype(np.float64)) * 1000.0 + cover * 0.5 - rr * 1e-3
    # Preserve strict best-fit for clearly better residuals via the large multiplier.
    score = np.where(residual <= best + 1, cover * 0.5 - rr * 1e-3, score)

    _record(item)
    return score
# EVOLVE-BLOCK-END
