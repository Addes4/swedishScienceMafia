# EVOLVE-BLOCK-START
"""Static residual-value rule.

Precompute (once) a Weibull-shaped item-size histogram matching the problem's
stated distribution (mean ~40).  Convert it into a convex "fillability" value
function V(r): a measure of how likely / how usefully a leftover capacity r can
still be consumed by future items.  Each arriving item is placed in the bin
whose post-placement residual has the highest fillability value, with a small
best-fit tie-break so ties and near-ties resolve toward tighter packing.
"""
import numpy as np

# ---- one-time precomputation of the Weibull size histogram ----------------
_SIZES = np.arange(1, 101, dtype=np.float64)          # integer item sizes 1..100
_WEIB_SHAPE = 2.0                                      # Weibull shape k
_WEIB_SCALE = 45.0                                     # scale lambda (mean ~40)

def _build_value_table():
    # Weibull pdf on 1..100, truncated and normalized to a pmf over integer sizes.
    x = _SIZES / _WEIB_SCALE
    pdf = (_WEIB_SHAPE / _WEIB_SCALE) * (x ** (_WEIB_SHAPE - 1.0)) * np.exp(-(x ** _WEIB_SHAPE))
    pdf = np.maximum(pdf, 0.0)
    pmf = pdf / pdf.sum()

    # CDF and survival for "can a future item fit exactly-ish into residual r".
    # V(r) = expected number/utility of future items that a residual r can host.
    # Convex-ish: grows with r, saturates, with a mild peak reward for "good leftovers".
    cum = np.cumsum(pmf)
    surv = 1.0 - cum               # surv[i] = P(size > i+1)

    r = np.arange(0, 101, dtype=np.float64)
    # Probability that at least one future item fits in residual r.
    fit_prob = np.zeros(101, dtype=np.float64)
    fit_prob[0] = 0.0
    for ri in range(1, 101):
        # P(size <= ri)
        fit_prob[ri] = cum[ri - 1]

    # Value: convex in the sense of rewarding residual that can host a *typical*
    # item, penalizing residuals too large (wasteful) or too small to be useful.
    # We weight by the expected size of the largest item that fits, promoting
    # residuals that are genuinely usable rather than merely empty.
    usable = np.zeros(101, dtype=np.float64)
    for ri in range(1, 101):
        idx = np.arange(1, ri + 1)
        w = pmf[idx - 1]
        if w.sum() > 0:
            # expected consumed size if we try to place a fitting item
            usable[ri] = np.dot(idx, w) / w.sum() * fit_prob[ri]
    # Normalize to a comparable scale.
    m = usable.max() if usable.max() > 0 else 1.0
    value = usable / m
    return value.astype(np.float64)


_VALUE = _build_value_table()


def priority(item, bins):
    """Score each bin by the fillability value of its post-placement residual."""
    bins = np.asarray(bins)
    residual = bins - item                      # >= 0 for all shown bins
    np.clip(residual, 0, 100, out=residual)
    val = _VALUE[residual]                      # convex residual-value curve
    # Small best-fit tie-break: prefer tighter packing among equal-value residuals.
    return val - 1e-6 * residual
# EVOLVE-BLOCK-END
