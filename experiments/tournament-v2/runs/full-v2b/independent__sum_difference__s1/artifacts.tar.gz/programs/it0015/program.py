import math
import random
import time

def _score_parts(a):
    a = set(a)
    if len(a) < 2:
        return 0, 1, 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    ratio = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100
    return len(diffs), len(sums), ratio


def _score(a):
    return _score_parts(a)[2]


def _greedy_refine(base, deadline, best_score):
    """Try removing elements / shifting to reduce sum set while keeping diff set."""
    a = base[:]
    best = a[:]
    random.shuffle(a)
    cur = a[:]
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.45 and len(cand) > 3:
            # remove a random element
            i = random.randrange(len(cand))
            cand.pop(i)
        elif op < 0.85:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2])
        else:
            cand.append(random.randint(-50, 50))
        # dedupe and shrink magnitude by translating (translation invariant)
        cand = sorted(set(cand))
        if not cand:
            continue
        # keep values in range
        if max(abs(x) for x in cand) > 10**15:
            continue
        s = _score(cand)
        if s >= best_score:
            best_score = s
            best = cand[:]
            cur = cand
        elif random.random() < 0.15:
            cur = best[:]
    return best, best_score


def _seed_sidon(n, scale, rng):
    """Build a Sidon-like set: B = {2*i*k + i*i mod p} style, or greedy Sidon."""
    # Greedy Sidon: keep sums distinct
    B = [0]
    used_sums = {0}
    x = 1
    while len(B) < n:
        ok = True
        new_sums = []
        for b in B:
            s = x + b
            if s in used_sums:
                ok = False
                break
            new_sums.append(s)
        if ok:
            if rng.random() < 0.3:
                # also check differences distinct-ish not required; Sidon => diffs distinct
                pass
            B.append(x)
            for s in new_sums:
                used_sums.add(s)
        x += 1
        if x > 10 * n * n + 100:
            break
    return [b * scale for b in B]


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Seed candidates: known good small sets and structured constructions
    seeds = [
        [0, 1, 3, 7, 12, 20],
        [0, 2, 5, 10, 16, 23, 31],
        [7, 15, 18, 22, -3, -2],
        [0, 1, 3, 8, 12, 18, 23, 29],
        [0, 1, 4, 9, 15, 22, 26, 31, 37, 42],
    ]
    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score = sc
            best = s[:]

    # Try Sidon-like sets of several sizes
    for n in [5, 6, 8, 10, 12, 16, 20, 25, 30, 40, 50, 70, 100, 150, 200]:
        for trial in range(2):
            if time.time() > deadline - 40:
                break
            B = _seed_sidon(n, 1, rng)
            sc = _score(B)
            if sc > best_score:
                best_score = sc
                best = B[:]

    # Random / arithmetic-based constructions
    # A = {0,1,...,n-1} union {large multiples}? Try difference-heavy sets.
    # Use "B_h" style: A = {i : i in [0,m)} gives ratio ~ log(2m)/log(2m) = 1. Bad.
    # Use Sidon: sums ~ n^2, diffs ~ n^2 but coefficient may differ.
    # Known trick: A = {2^k} gives diffs ~ 2^k^2, sums ~ 2^k^2 also. Bad.

    # Focused local search from current best
    if best is not None:
        best, best_score = _greedy_refine(best, min(deadline, time.time() + 60), best_score)

    # Large neighborhood: perturb and refine
    while time.time() < deadline - 15:
        base = best[:]
        # random perturbation
        for _ in range(rng.randint(1, 3)):
            if base and rng.random() < 0.7:
                i = rng.randrange(len(base))
                if rng.random() < 0.5:
                    base.pop(i)
                else:
                    base[i] += rng.choice([-3, -2, -1, 1, 2, 3])
            else:
                base.append(rng.randint(-100, 100))
        base = sorted(set(base))
        if not base:
            continue
        sc = _score(base)
        if sc > best_score:
            best_score = sc
            best = base[:]
        base, sc = _greedy_refine(base, min(deadline, time.time() + 10), sc)
        if sc > best_score:
            best_score = sc
            best = base[:]

    return sorted(set(best))
