import math
import random
import time
from itertools import combinations


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _structure_score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e18
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 2:
        return -1e18
    return (math.log(len(diffs)) / math.log(len(sums)), len(diffs), -len(sums), n)


def _make_seeds():
    seeds = []
    # Geometric / Sidon-ish on sparse powers
    for k in range(2, 13):
        base = [1 << i for i in range(k)]
        seeds.append(base)
        seeds.append([x + i for i, x in enumerate(base)])
    # Perfect difference-like Golomb ruler-ish: use i*(i+1)/2 style then stretch
    for n in range(3, 20):
        seeds.append([i * i for i in range(n)])
        seeds.append([i * (i + 1) // 2 for i in range(n)])
    # Sparse near-arithmetic with geometric tail: a = small dense block plus powers
    for dense in range(1, 6):
        for pw in range(3, 12):
            s = list(range(dense))
            s += [dense * (1 << i) for i in range(pw)]
            seeds.append(s)
    # Random sparse large-gap sets (Golomb-ish random construction)
    rnd = random.Random(12345)
    for _ in range(400):
        n = rnd.randint(4, 14)
        M = rnd.randint(5, 40)
        s = set()
        while len(s) < n:
            s.add(rnd.randint(0, M) * rnd.choice([1, 1, 1, 3, 7, 17]))
        seeds.append(sorted(s))
    return seeds


def _local_search(start, deadline, seeds_pool):
    cur = list(dict.fromkeys(start))
    if len(cur) < 2:
        return cur
    best = cur[:]
    best_sc = _structure_score(best)
    cur_sc = best_sc
    step = max(1, max(abs(x) for x in cur) // 20 + 1)
    stall = 0
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.55 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif op < 0.80:
            # add element: near existing gaps or in stretched region
            if len(cand) < 4000:
                if random.random() < 0.5 and len(cand) >= 2:
                    cand.sort()
                    k = random.randrange(len(cand) - 1)
                    newv = (cand[k] + cand[k + 1]) // 2 + random.randint(-3, 3)
                    cand.append(newv)
                else:
                    mx = max(cand) if cand else 0
                    cand.append(mx + random.randint(1, max(2, mx // 4 + 2)))
        else:
            if len(cand) > 2:
                i = random.randrange(len(cand))
                del cand[i]
        cand = list(dict.fromkeys(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 120:
            cand = cand[:120]
        sc = _structure_score(cand)
        if sc >= cur_sc:
            if sc > best_sc:
                best, best_sc = cand[:], sc
                stall = 0
            cur, cur_sc = cand[:], sc
        else:
            stall += 1
            if stall > 250:
                # restart from a random seed
                cur = list(dict.fromkeys(random.choice(seeds_pool)))
                random.shuffle(cur)
                cur = list(dict.fromkeys(cur))
                cur_sc = _structure_score(cur)
                stall = 0
                if cur_sc > best_sc:
                    best, best_sc = cur[:], cur_sc
    return best


def solve():
    deadline = time.time() + 110
    seeds = _make_seeds()
    random.shuffle(seeds)
    best = None
    best_rec = None

    # Evaluate seeds, keep good ones
    scored = []
    t0 = time.time()
    for s in seeds:
        if time.time() > t0 + 8:
            break
        s = list(dict.fromkeys(s))
        if len(s) < 2:
            continue
        scored.append((_structure_score(s), s))
    scored.sort(key=lambda x: x[0], reverse=True)
    keep = [s for _, s in scored[:60]]

    # Local search from the best seeds within budget
    idx = 0
    while time.time() < deadline and keep:
        start = keep[idx % len(keep)]
        idx += 1
        sub_deadline = min(deadline, time.time() + 6)
        cand = _local_search(start, sub_deadline, keep)
        rec = _structure_score(cand)
        if best_rec is None or rec > best_rec:
            best, best_rec = cand[:], rec

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    # Final trim: try removing/replacing to improve ratio (favor larger with bonus)
    best = list(dict.fromkeys(best))
    final_deadline = time.time() + 2
    improved = True
    while improved and time.time() < final_deadline:
        improved = False
        cur_rec = _structure_score(best)
        n = len(best)
        for i in range(n):
            trial = best[:i] + best[i + 1:]
            if len(trial) < 2:
                continue
            if _structure_score(trial) > cur_rec:
                best, cur_rec, improved = trial, _structure_score(trial), True
                break

    best = sorted(set(best))
    # safety: cap size and magnitude
    while len(best) > 4000:
        best = best[::2]
    best = [x for x in best if abs(x) <= 10 ** 15]
    if len(best) < 2:
        return [7, 15, 18, 22, -3, -2]
    return best


if __name__ == "__main__":
    res = solve()
    print(len(res), _score(res))
