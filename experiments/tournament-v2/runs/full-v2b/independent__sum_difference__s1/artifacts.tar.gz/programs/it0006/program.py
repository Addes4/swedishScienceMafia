import math
import random
import time

def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _fast_eval(a):
    """Estimate score quickly using exact sets for moderate n."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
            if i != j:
                diffs.add(ai - a[j])
                diffs.add(a[j] - ai)
        for j in range(i):
            diffs.add(ai - a[j])
            diffs.add(a[j] - ai)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)

def _greedy_sidon(n, bound, rng):
    """Greedily build a Sidon-like set: avoid duplicate sums/differences."""
    A = []
    sums = set()
    diffs = set()
    candidates = list(range(-bound, bound + 1))
    rng.shuffle(candidates)
    for c in candidates:
        ok = True
        new_sums = set()
        new_diffs = set()
        for a in A:
            s1 = c + a
            d1 = c - a
            d2 = a - c
            if s1 in sums or s1 in new_sums:
                ok = False
                break
            if d1 in diffs or d1 in new_diffs or d2 in diffs or d2 in new_diffs:
                ok = False
                break
            new_sums.add(s1)
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            ns = c + c
            if ns not in sums and ns not in new_sums:
                A.append(c)
                sums.update(new_sums)
                sums.add(ns)
                diffs.update(new_diffs)
                if len(A) >= n:
                    break
    return A

def _local_search(A, time_limit, rng):
    A = list(set(A))
    if len(A) < 2:
        return A, 0.0
    best = A[:]
    best_score, _, _ = _fast_eval(best)
    deadline = time.time() + time_limit
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        op = rng.random()
        if op < 0.6 and cand:
            i = rng.randrange(len(cand))
            shift = rng.randint(-5, 5)
            if shift == 0:
                shift = 1
            cand[i] += shift
        elif op < 0.8:
            cand.append(rng.randint(-200, 200))
        elif len(cand) > 10:
            del cand[rng.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s, _, _ = _fast_eval(cand)
        if s > best_score:
            best, best_score, cur = cand[:], s, cand
        elif s > best_score - 0.001:
            cur = cand[:]
        elif rng.random() < 0.05:
            cur = best[:]
    return best, best_score

def solve():
    rng = random.Random(12345)
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Try several greedy Sidon-like constructions with different sizes/bounds.
    deadline = time.time() + 110
    configs = []
    for n in [30, 50, 80, 120, 160, 200, 250, 300]:
        bounds = [n * 2, n * 3, n * 5, n * 10, n * 20]
        for b in bounds:
            if b <= 100000:
                configs.append((n, b))
    rng.shuffle(configs)

    for n, bound in configs:
        if time.time() > deadline - 5:
            break
        A = _greedy_sidon(n, bound, rng)
        if len(A) < 2:
            continue
        s, _, _ = _fast_eval(A)
        if s > best_score:
            best, best_score = A[:], s
        # local search a bit on each
        A2, s2 = _local_search(A, 1.0, rng)
        if s2 > best_score:
            best, best_score = A2[:], s2

    # Main local search on best found.
    if time.time() < deadline:
        A3, s3 = _local_search(best, max(0.0, deadline - time.time()), rng)
        if s3 > best_score:
            best, best_score = A3[:], s3

    return sorted(set(best))
