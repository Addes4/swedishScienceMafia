import math
import random
import time


def _score_parts(a):
    a = set(a)
    if len(a) < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    lst = list(a)
    for x in lst:
        for y in lst:
            diffs.add(x - y)
            sums.add(x + y)
    n = len(a)
    s = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return s, len(diffs), len(sums)


def _score(a):
    return _score_parts(a)[0]


def _greedy_construct(n_target, max_val, rng):
    # Start with a small Sidon-ish set, then greedily add elements
    # that keep sums relatively small while adding many differences.
    A = [0]
    # seed with a few elements spread out
    for v in [1, 2, 5, 9, 15, 24, 38]:
        if len(A) < n_target:
            A.append(v)
    used = set(A)
    candidates = list(range(1, max_val + 1))
    rng.shuffle(candidates)
    ci = 0
    while len(A) < n_target and ci < len(candidates):
        c = candidates[ci]
        ci += 1
        if c in used:
            continue
        # approximate cost: extra sums vs extra diffs
        base_sums = {x + y for x in A for y in A}
        base_diffs = {x - y for x in A for y in A}
        new_sums = {c + x for x in A} | {2 * c}
        new_diffs = {abs(c - x) for x in A} | {0}
        add_s = len(new_sums - base_sums)
        add_d = len(new_diffs - base_diffs)
        if add_d <= 0:
            continue
        # prefer high ratio of new diffs to new sums, but allow growth
        ratio = add_d / (add_s + 0.5)
        if ratio > 0.8 or add_s == 0:
            A.append(c)
            used.add(c)
    return A


def _local_search(A, deadline, rng):
    best = sorted(set(A))
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score
    vals = list(range(-200, 201))

    while time.time() < deadline:
        cand = cur[:]
        op = rng.random()
        if op < 0.6:
            i = rng.randrange(len(cand))
            delta = rng.choice([-1, 1, -2, 2, -3, 3, -5, 5, -7, 7, -11, 11])
            cand[i] += delta
        elif op < 0.8:
            i = rng.randrange(len(cand))
            j = rng.randrange(len(cand))
            if i != j:
                cand[i], cand[j] = cand[j], cand[i]
        elif op < 0.92:
            if len(cand) > 3:
                i = rng.randrange(len(cand))
                del cand[i]
        else:
            cand.append(rng.randint(-150, 150))
        cand = sorted(set(cand))
        if len(cand) < 3:
            continue
        if max(abs(x) for x in cand) > 10**12:
            continue
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif rng.random() < 0.02:
            cur, cur_score = cand, s
        if rng.random() < 0.05:
            cur, cur_score = best[:], best_score
    return best, best_score


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110.0
    best = None
    best_score = -1.0

    # Try several structural constructions
    configs = [
        (40, 200),
        (60, 400),
        (80, 800),
        (120, 2000),
        (160, 5000),
        (200, 12000),
        (250, 30000),
        (300, 80000),
    ]

    for (n_target, max_val) in configs:
        if time.time() > deadline:
            break
        A = _greedy_construct(n_target, max_val, rng)
        s = _score(A)
        if s > best_score:
            best, best_score = A[:], s
        # local search from this point
        cand, cs = _local_search(A, min(deadline, time.time() + 12.0), rng)
        if cs > best_score:
            best, best_score = cand[:], cs

    # Final polish
    if best is not None and time.time() < deadline:
        cand, cs = _local_search(best, deadline, rng)
        if cs > best_score:
            best, best_score = cand[:], cs

    if best is None:
        best = [0, 1, 3, 7, 12]

    # Ensure distinct ints and constraints
    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    return best
