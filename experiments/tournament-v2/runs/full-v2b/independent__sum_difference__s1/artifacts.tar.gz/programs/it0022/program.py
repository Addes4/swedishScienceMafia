import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _build_golomb(n):
    # Greedy/backtracking Golomb ruler with marks as large as needed
    # Use known prefix of optimal Golomb rulers where possible.
    known = {
        1:[0],2:[0,1],3:[0,1,3],4:[0,1,4,6],5:[0,1,4,9,11],
        6:[0,1,4,10,12,17],7:[0,1,4,10,18,23,25],
        8:[0,1,4,9,15,22,32,34],9:[0,1,5,12,25,27,35,41,44],
        10:[0,1,6,10,23,26,34,41,53,55],
        11:[0,1,4,13,28,33,47,54,64,70,72],
        12:[0,2,6,24,29,40,43,55,68,75,76,85],
        13:[0,2,5,25,37,43,59,70,85,89,98,99,106],
        14:[0,4,6,20,35,52,59,77,78,86,89,99,122,127],
    }
    if n in known:
        return known[n][:]
    # Greedy construction beyond known
    marks = [0, 1]
    diffs = {1}
    while len(marks) < n:
        cand = marks[-1] + 1
        while True:
            ok = True
            for m in marks:
                if cand - m in diffs:
                    ok = False
                    break
            if ok:
                break
            cand += 1
        for m in marks:
            diffs.add(cand - m)
        marks.append(cand)
    return marks

def solve():
    random.seed(12345)
    deadline = time.time() + 115
    best = None
    best_score = -1.0

    # Try various Golomb rulers, then apply affine transforms to compress sums.
    candidates = []
    for n in [8,9,10,11,12,13,14]:
        try:
            g = _build_golomb(n)
        except Exception:
            continue
        # Squeeze range: map to smaller integers by keeping distinctness of diffs.
        # Apply scaling to shrink sums while preserving difference distinctness.
        candidates.append(g[:])

    # Also try a Sidon-like base with negative spread to concentrate sums.
    for n in [6,7,8,9,10]:
        g = _build_golomb(n)
        g2 = [x - g[-1]//2 for x in g]
        candidates.append(g2)

    def local_search(base, tlimit):
        cur = base[:]
        cur_score = _score(cur)
        nonlocal_best = cur[:]
        nonlocal_score = cur_score
        t0 = time.time()
        it = 0
        while time.time() < t0 + tlimit:
            it += 1
            cand = cur[:]
            # Random perturbation
            r = random.random()
            if r < 0.6 and len(cand) > 1:
                i = random.randrange(len(cand))
                cand[i] += random.choice([-2,-1,1,2])
                # keep distinct
                s = set(cand)
                if len(s) != len(cand):
                    continue
            elif r < 0.8 and len(cand) < 60:
                cand.append(random.randint(-50, 50))
                if len(set(cand)) != len(cand):
                    continue
            elif len(cand) > 4:
                i = random.randrange(len(cand))
                cand.pop(i)
            s = _score(cand)
            if s > cur_score or random.random() < 0.05:
                cur = cand
                cur_score = s
                if s > nonlocal_score:
                    nonlocal_best = cand[:]
                    nonlocal_score = s
        return nonlocal_best, nonlocal_score

    # Score candidates
    for c in candidates:
        s = _score(c)
        if s > best_score:
            best, best_score = c[:], s

    # Local search on best candidate, and explore scaling factors.
    results = []
    per = max(1.0, (deadline - time.time()) / max(1, len(candidates)))
    for c in candidates:
        if time.time() > deadline - 1:
            break
        b, s = local_search(c, min(per, deadline - time.time()))
        results.append((s, b))
        if s > best_score:
            best, best_score = b, s

    # Scaling search: scale a Golomb ruler and shift; scaling affects sums range.
    base_g = _build_golomb(12)
    t_end = time.time() + max(0, deadline - time.time() - 0.5)
    scale = 1
    while time.time() < t_end:
        scaled = [x * scale for x in base_g]
        s = _score(scaled)
        if s > best_score:
            best, best_score = scaled[:], s
        # random scale/shift attempts
        for _ in range(50):
            sc = random.randint(1, 5)
            sh = random.randint(-3, 3) * sc
            cand = [x * sc + sh for x in base_g]
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s
            if time.time() > t_end:
                break
        scale += 1
        if scale > 6:
            scale = 1

    # Final refinement with hill climbing on best
    if best is not None:
        b, s = local_search(best, max(0, deadline - time.time() - 1))
        if s > best_score:
            best, best_score = b, s

    if best is None:
        best = [0, 1, 3]
    return sorted(set(int(x) for x in best))
