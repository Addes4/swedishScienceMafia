import math
import random
import time


def _score_stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return -1e9, len(diffs), len(sums)
    score = math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0
    return score, len(diffs), len(sums)


def _score(a):
    return _score_stats(a)[0]


def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 115.0
    best = None
    best_score = -1e18
    best_d = 0
    best_s = 0

    # Deterministic structured candidates.
    # A set with many differences but few sums can be built by making A+A
    # lie in a small interval while A-A spans much farther.
    candidates = []

    # Powers of two plus shifts tend to have rich difference structure.
    for k in range(7, 13):
        base = [1 << i for i in range(k)]
        candidates.append(base[:])
        candidates.append([x + 1 for x in base])
        candidates.append([x - (1 << (k - 1)) for x in base])

    # Near arithmetic progressions with multiplicative/sparse perturbations.
    for n in [30, 60, 100, 160, 240, 360, 520, 750, 1000, 1400, 1900, 2600, 3500, 4000]:
        step = max(1, int(1e12 // max(1, n)))
        arr = [i * step for i in range(n)]
        candidates.append(arr)

        # Shifted/scaled powers of two embedded in a progression.
        for k in range(8, min(16, n.bit_length() + 8)):
            b = [i * step for i in range(max(1, n - (1 << k)))]
            for i in range(k):
                b.append((n - (1 << k) + i) * step + (1 << i) * step // max(1, 1 << k))
            if len(set(b)) == n:
                candidates.append(b)

    # Random structured sets around a small sum range.
    rng = random.Random(123456789)
    for n in [50, 80, 120, 180, 260, 380, 550, 800, 1200, 1700, 2400, 3200, 4000]:
        for _ in range(8):
            vals = set()
            while len(vals) < n:
                # Mix thin arithmetic structure with random offsets.
                if rng.random() < 0.75:
                    v = rng.randrange(0, max(2, n // 2)) * 2 + rng.randrange(0, 2)
                else:
                    v = rng.randrange(0, max(2, n * 3))
                vals.add(v)
            candidates.append(list(vals))

    seen = set()
    for cand in candidates:
        cand = list(dict.fromkeys(cand))
        if len(cand) < 2:
            continue
        key = tuple(sorted(cand))
        if key in seen:
            continue
        seen.add(key)
        sc, d, s = _score_stats(cand)
        if sc > best_score:
            best_score, best, best_d, best_s = sc, list(cand), d, s

    # Local search / evolutionary search.
    if best is None:
        best = list(range(64))
        best_score, best_d, best_s = _score_stats(best)

    cur = list(best)
    cur_score = best_score

    while time.time() < deadline:
        # Occasionally restart from the best.
        if random.random() < 0.01:
            cur = list(best)
            cur_score = best_score

        cand = list(cur)
        n = len(cand)
        op = random.random()

        if op < 0.42:
            # Perturb one element.
            i = random.randrange(n)
            scale = 1
            if random.random() < 0.25:
                scale = max(1, abs(cand[i]) // 1000 + 1)
            cand[i] += random.randint(-3 * scale, 3 * scale)
        elif op < 0.70:
            # Perturb a small block.
            k = min(n, random.randint(1, 8))
            start = random.randrange(max(1, n - k + 1))
            for j in range(start, min(n, start + k)):
                cand[j] += random.randint(-5, 5)
        elif op < 0.84:
            # Add an element.
            if n < 4000:
                if random.random() < 0.5:
                    v = random.choice(cand) + random.randint(-50, 50)
                else:
                    v = random.randint(-2000, 2000)
                cand.append(v)
        elif op < 0.96:
            # Remove an element, usually the most redundant-looking one.
            if n > 3:
                if random.random() < 0.5:
                    idx = random.randrange(n)
                else:
                    # Try to remove a random of the middle few.
                    idx = n // 2 + random.randint(-3, 3)
                    idx = max(0, min(n - 1, idx))
                cand.pop(idx)
        else:
            # Swap scale / translate whole set.
            if random.random() < 0.5:
                sh = random.randint(-20, 20)
                cand = [x + sh for x in cand]
            else:
                mul = random.choice([1, 2, 3, 5])
                if mul != 1:
                    cand = [x * mul for x in cand]

        cand = list(dict.fromkeys(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 4000:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue

        sc, d, s = _score_stats(cand)
        if sc >= cur_score or random.random() < 0.02:
            cur, cur_score = cand, sc

        if sc > best_score:
            best_score, best, best_d, best_s = sc, list(cand), d, s

    # Final cleanup: try to remove elements that do not help much.
    improved = True
    while improved and time.time() < deadline:
        improved = False
        arr = list(dict.fromkeys(best))
        base_score = _score(arr)
        order = list(range(len(arr)))
        random.shuffle(order)
        for idx in order:
            if time.time() >= deadline:
                break
            if len(arr) <= 2:
                break
            cand = arr[:idx] + arr[idx + 1:]
            if not cand:
                continue
            sc = _score(cand)
            if sc > base_score:
                arr = cand
                base_score = sc
                improved = True

        if improved:
            best = arr
            best_score = base_score

    best = sorted(set(int(x) for x in best))
    while len(best) > 4000:
        best.pop()
    return best
