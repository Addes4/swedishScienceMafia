import math
import random
import time


def _sets(a):
    s = set(a)
    su = {x + y for x in s for y in s}
    di = {x - y for x in s for y in s}
    return di, su


def _score(a):
    s = set(a)
    if len(s) < 2:
        return -1e9
    su = {x + y for x in s for y in s}
    di = {x - y for x in s for y in s}
    if len(su) < 2:
        return -1e9
    return math.log(len(di)) / math.log(len(su)) + (1 - 1 / len(s)) / 100


def solve():
    random.seed(123456789)
    deadline = time.time() + 115

    # Candidate start: powers of 2 (small sum set), shifted to reduce structure.
    best = []
    best_score = -1e18

    def consider(a):
        nonlocal best, best_score
        a = sorted(set(a))
        if len(a) < 2:
            return
        sc = _score(a)
        if sc > best_score:
            best_score = sc
            best = a[:]

    # Seeds
    for k in range(3, 18):
        consider([(1 << i) + i for i in range(k)])
        consider([(1 << i) - i for i in range(k)])
        consider([(1 << i) + (i * i) for i in range(k)])

    # Add a "Golomb-ish" base set with many differences
    gol = [0]
    used_d = {0}
    while len(gol) < 60:
        c = gol[-1] + 1
        while True:
            ok = True
            for g in gol:
                d = c - g
                if d in used_d:
                    ok = False
                    break
            if ok:
                break
            c += 1
        for g in gol:
            used_d.add(c - g)
        gol.append(c)
    consider(gol)
    consider([x + 1 for x in gol])

    # Main local search
    cur = best[:]
    cur_score = best_score

    def perturb(a):
        b = a[:]
        r = random.random()
        if r < 0.5:
            i = random.randrange(len(b))
            delta = random.choice([-3, -2, -1, 1, 2, 3, random.randint(-20, 20)])
            b[i] += delta
        elif r < 0.8:
            b.append(random.randint(-1000, 1000))
        elif r < 0.9 and len(b) > 3:
            b.pop(random.randrange(len(b)))
        else:
            i = random.randrange(len(b))
            j = random.randrange(len(b))
            b[i], b[j] = b[j], b[i]
        return b

    it = 0
    while time.time() < deadline:
        it += 1
        cand = perturb(cur)
        if len(set(cand)) != len(cand):
            continue
        sc = _score(cand)
        if sc >= cur_score or random.random() < 0.02:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = sorted(set(cand))
                best_score = sc
        if it % 300 == 0 and random.random() < 0.4:
            cur = best[:]
            cur_score = best_score
        if time.time() > deadline:
            break

    return best
