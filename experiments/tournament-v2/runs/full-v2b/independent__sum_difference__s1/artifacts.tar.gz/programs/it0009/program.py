import math
import random
import time
from array import array


def _bitset_count(vals):
    if not vals:
        return 0
    lo = min(vals)
    hi = max(vals)
    off = -lo
    n = hi - lo + 1
    bits = bytearray((n + 7) // 8)
    for v in vals:
        x = v + off
        bits[x >> 3] |= 1 << (x & 7)
    return sum(b.bit_count() for b in bits)


def _score(vals):
    n = len(vals)
    if n < 2:
        return 0.0
    diffs = [a - b for a in vals for b in vals]
    sums = [a + b for a in vals for b in vals]
    d = _bitset_count(diffs)
    s = _bitset_count(sums)
    if s <= 1:
        return 100.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _fast_stats(vals):
    n = len(vals)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = vals[i]
        for j in range(i, n):
            aj = vals[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score_fast(vals):
    n = len(vals)
    if n < 2:
        return 0.0
    d, s = _fast_stats(vals)
    if s <= 1:
        return 100.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _initial_sets():
    res = []

    # Small known-good seed
    res.append([7, 15, 18, 22, -3, -2])

    # Geometric-like construction: {0..k} plus scaled copies
    # Keeps sums clustered around 2*max while differences spread over shifts.
    for k in [4, 6, 8, 10]:
        base = list(range(k + 1))
        A = set(base)
        step = 2 * (k + 1) + 1
        for m in range(2, 10):
            for x in base:
                A.add(x * (step ** (m - 1)))
        a = sorted(A)
        if len(a) <= 4000:
            res.append(a)

    # Golomb-like greedy with many differences but bounded growth
    g = [0, 1]
    used = {0, 1, -1}
    while len(g) < 40:
        best_c = None
        best_new = -1
        last = g[-1]
        for c in range(last + 1, last + 80):
            cnt = 0
            ok = True
            for x in g:
                if c - x in used:
                    ok = False
                    break
                cnt += 1
            if ok and cnt > best_new:
                best_new = cnt
                best_c = c
        if best_c is None:
            break
        for x in g:
            used.add(best_c - x)
            used.add(x - best_c)
        g.append(best_c)
    res.append(g)

    # Powers of 2 scaled
    p = [2 ** i for i in range(14)]
    res.append(p)

    # Mixed alternating large gaps
    a = []
    cur = 0
    for i in range(30):
        a.append(cur)
        cur += (i * i) + 1
    res.append(a)

    return res


def _hill_climb(start, deadline):
    vals = sorted(set(start))
    if len(vals) < 2:
        return vals
    cur_score = _score_fast(vals)
    best = vals[:]
    best_score = cur_score
    n = len(vals)
    vals_set = set(vals)

    temperature = 1.0
    while time.time() < deadline:
        cand = best[:]
        op = random.random()
        if op < 0.55:
            i = random.randrange(len(cand))
            span = max(1, abs(cand[i]) // 3 + 5)
            if random.random() < 0.3:
                span = 3
            delta = random.randint(-span, span)
            if delta == 0:
                continue
            cand[i] += delta
        elif op < 0.75:
            if len(cand) < 4000:
                cand.append(random.randint(-1000, 1000))
        elif op < 0.90:
            if len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
        else:
            if len(cand) >= 2:
                i = random.randrange(len(cand))
                cand[i] = -cand[i]
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        sc = _score_fast(cand)
        if sc >= best_score or random.random() < math.exp((sc - best_score) / max(1e-9, temperature)):
            if sc > best_score:
                best_score = sc
                best = cand[:]
                temperature = max(0.02, temperature * 0.999)
        temperature *= 0.99999
    return best


def _polish(vals, deadline):
    vals = sorted(set(vals))
    if len(vals) < 2:
        return vals
    best = vals[:]
    best_score = _score_fast(best)
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for i in range(len(best)):
            base = best[:]
            # try local +/- moves
            for delta in list(range(-20, 21)) + [random.randint(-1000, 1000) for _ in range(10)]:
                if delta == 0:
                    continue
                cand = base[:]
                cand[i] += delta
                cand = sorted(set(cand))
                if len(cand) < 2 or len(cand) > 4000:
                    continue
                sc = _score_fast(cand)
                if sc > best_score:
                    best_score = sc
                    best = cand
                    improved = True
                    break
            if improved:
                break
    return best


def solve():
    deadline = time.time() + 115
    best = None
    best_score = -1.0

    # Evaluate initial constructions
    seeds = _initial_sets()
    for s in seeds:
        s = sorted(set(s))
        if 2 <= len(s) <= 4000:
            sc = _score_fast(s)
            if sc > best_score:
                best_score = sc
                best = s[:]

    # Hill-climb from best seeds
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score_fast(best)

    # Iterated local search
    while time.time() < deadline - 2:
        start = best[:]
        if random.random() < 0.5 and len(seeds) > 0:
            start = random.choice(seeds)[:]
        cand = _hill_climb(start, min(deadline - 1, time.time() + 12))
        sc = _score_fast(cand)
        if sc > best_score:
            best_score = sc
            best = cand[:]
            best = _polish(best, min(deadline, time.time() + 8))
            best_score = _score_fast(best)

    return sorted(set(best))


# For local testing
if __name__ == "__main__":
    a = solve()
    d, s = _fast_stats(a)
    print(len(a), d, s, math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100)
