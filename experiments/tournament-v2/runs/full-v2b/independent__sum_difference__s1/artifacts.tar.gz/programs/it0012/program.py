import math
import random
import time
from itertools import combinations


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _greedy_union(nblocks=8, blocksize=28, gap=10000, shift=1):
    # Build a union of nblocks translated copies of a Sidon-ish block.
    # Small sums are forced into a grid because each coordinate is a small
    # base value plus a block offset, while differences are spread by the gaps.
    block = [0]
    # Build a B_2-ish base block by greedy search over small integers.
    used_sums = {0}
    while len(block) < blocksize:
        best_c = None
        best_new = -1
        # Try candidates, prioritizing ones that create few new sums.
        base = max(block)
        for c in range(base + 1, base + 200):
            new_s = {c + x for x in block} | {2 * c}
            new_cnt = len(new_s - used_sums)
            if new_cnt > best_new:
                best_new = new_cnt
                best_c = c
                if new_cnt >= 2 * (len(block) + 1):
                    break
        block.append(best_c)
        used_sums |= {best_c + x for x in block} | {2 * best_c}

    A = []
    for i in range(nblocks):
        off = i * gap + shift * i * i
        for x in block:
            A.append(off + x)
    return A


def _refine(A, deadline):
    A = sorted(set(A))
    best = A[:]
    best_score = _score(best)
    cur = best[:]

    while time.time() < deadline:
        cand = cur[:]
        if random.random() < 0.6:
            # small perturbation
            i = random.randrange(len(cand))
            delta = random.choice([-3, -2, -1, 1, 2, 3]) * random.randint(1, 10)
            cand[i] += delta
        elif random.random() < 0.5:
            # shift a whole block-like subset
            i = random.randrange(max(1, len(cand) - 10))
            delta = random.randint(-20, 20)
            for j in range(i, min(len(cand), i + random.randint(2, 10))):
                cand[j] += delta
        else:
            # translate everything slightly
            delta = random.randint(-50, 50)
            cand = [x + delta for x in cand]

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.08:
            cur = best[:]
    return best


def solve():
    deadline = time.time() + 115.0

    best = None
    best_score = -1.0

    # Try several structured constructions.
    configs = [
        (6, 26, 8000, 1),
        (7, 28, 9000, 1),
        (8, 28, 10000, 1),
        (6, 30, 12000, 1),
        (5, 31, 15000, 1),
        (10, 25, 7000, 1),
        (12, 22, 6000, 1),
        (8, 28, 50000, 3),
        (6, 32, 100000, 5),
        (4, 36, 200000, 7),
    ]

    for (nb, bs, gap, sh) in configs:
        if time.time() > deadline - 5:
            break
        A = _greedy_union(nb, bs, gap, sh)
        s = _score(A)
        if s > best_score:
            best_score, best = s, A[:]

    if best is None:
        best = _greedy_union(6, 26, 8000, 1)

    # Refine within remaining time.
    refined = _refine(best, deadline)
    s = _score(refined)
    if s > best_score:
        best_score, best = s, refined

    return sorted(set(int(x) for x in best))
