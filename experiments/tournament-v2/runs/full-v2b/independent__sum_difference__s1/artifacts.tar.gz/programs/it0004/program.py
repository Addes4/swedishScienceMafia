import math
import random
import time

def _stats(a):
    a = list(dict.fromkeys(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)

def _score_cached(a):
    s, _, _ = _stats(a)
    return s

def _greedy_base(n):
    rnd = random.Random(12345)
    a = [0]
    used_sum = {0}
    used_diff = {0}
    for _ in range(n - 1):
        best_c = None
        best_val = -10**18
        for _ in range(40):
            c = rnd.randint(-10**9, 10**9)
            if c in a:
                continue
            new_diffs = 0
            new_sums = 0
            for x in a:
                if c - x not in used_diff:
                    new_diffs += 1
                if x - c not in used_diff:
                    new_diffs += 1
                if c + x not in used_sum:
                    new_sums += 1
                if x + c not in used_sum:
                    new_sums += 1
            if c not in used_diff:
                new_diffs += 1
            if c + c not in used_sum:
                new_sums += 1
            val = new_diffs - 3 * new_sums
            if val > best_val:
                best_val = val
                best_c = c
        if best_c is None:
            best_c = rnd.randint(-10**9, 10**9)
        a.append(best_c)
        for x in a[:-1]:
            used_diff.add(best_c - x)
            used_diff.add(x - best_c)
            used_sum.add(best_c + x)
            used_sum.add(x + best_c)
        used_diff.add(0)
        used_sum.add(best_c + best_c)
    return a

def _hill_climb(a, deadline):
    a = list(dict.fromkeys(a))
    score, nd, ns = _stats(a)
    n = len(a)
    step = 10**6
    while time.time() < deadline:
        improved = False
        order = list(range(n))
        random.shuffle(order)
        for i in order:
            if time.time() >= deadline:
                break
            old = a[i]
            for delta in (step, -step, step // 3 + 1, -(step // 3 + 1),
                          step // 10 + 1, -(step // 10 + 1), 1, -1):
                cand = a[:]
                cand[i] = old + delta
                if cand[i] == old:
                    continue
                s2, d2, m2 = _stats(cand)
                if s2 > score or (s2 == score and d2 > nd):
                    a = cand
                    score, nd, ns = s2, d2, m2
                    improved = True
                    break
            if improved and time.time() >= deadline:
                break
        if not improved:
            step //= 2
            if step == 0:
                break
    return a, score

def solve():
    random.seed(2024)
    deadline = time.time() + 110
    best = None
    best_score = -1e18
    # Try a few sizes to find good ratio (larger n gives bonus and typically larger ratio)
    for n in [30, 60, 120, 200, 300, 400]:
        if time.time() >= deadline - 5:
            break
        base = _greedy_base(n)
        a, sc = _hill_climb(base, min(deadline, time.time() + 15))
        if sc > best_score:
            best_score = sc
            best = a[:]
    # spend remaining time on largest best set
    if best is not None:
        while time.time() < deadline:
            a, sc = _hill_climb(best, min(deadline, time.time() + 10))
            if sc > best_score:
                best_score = sc
                best = a[:]
    if best is None:
        best = [0, 1]
    return sorted(set(int(x) for x in best))
