import math
import random
import time


def _score(a):
    a = list(a)
    if len(a) < 2:
        return 0.0
    s = list(a)
    diffs = set()
    sums = set()
    n = len(s)
    for i in range(n):
        si = s[i]
        for j in range(n):
            diffs.add(si - s[j])
            sums.add(si + s[j])
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    # faster via sorted and range reasoning
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 110

    candidates = []

    # Powers of 2: superincreasing, Sidon-ish for sums
    p2 = [1 << i for i in range(25)]
    candidates.append(p2)

    # Powers of 2 minus 1
    candidates.append([(1 << i) - 1 for i in range(1, 25)])

    # Powers of 3
    p3 = [1]
    for _ in range(18):
        p3.append(p3[-1] * 3)
    candidates.append(p3)

    # Geometric with ratio 2 but including 0
    candidates.append([0] + [1 << i for i in range(24)])

    # Fibonacci-like
    fib = [1, 2]
    while len(fib) < 30:
        fib.append(fib[-1] + fib[-2])
    candidates.append(fib)

    # Powers of 2 split into blocks around range
    # Union of two power-of-2 like sets
    u = [1 << i for i in range(18)] + [(1 << i) * 1000003 for i in range(16)]
    candidates.append(u)

    # Very large powers: length limits
    big = [1 << i for i in range(1, 46)]
    candidates.append(big)

    best = None
    best_score = -1.0
    for c in candidates:
        c = list(set(c))
        if len(c) < 2:
            continue
        try:
            sc = _score_fast(c)
        except Exception:
            continue
        if sc > best_score:
            best_score = sc
            best = c[:]

    # Local search on top of best candidate
    cur = best[:]
    cur_score = best_score

    step = 0
    while time.time() < deadline:
        step += 1
        cand = cur[:]
        # mutation types
        r = random.random()
        if r < 0.5 and cand:
            i = random.randrange(len(cand))
            mag = random.choice([1, 2, 3, 5, 10, 100, 1000])
            cand[i] += random.randint(-mag, mag)
        elif r < 0.7 and len(cand) < 4000:
            # add a new element based on existing ones
            if len(cand) >= 2:
                x = random.choice(cand)
                y = random.choice(cand)
                newv = abs(x - y)
                if newv == 0:
                    newv = x + 1
                cand.append(newv)
        elif r < 0.85 and len(cand) > 2:
            i = random.randrange(len(cand))
            del cand[i]
        else:
            # shift all
            d = random.choice([-1, 1])
            cand = [x + d for x in cand]

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 4000:
            continue
        # magnitude constraint
        if any(abs(x) > 10**15 for x in cand):
            continue

        sc = _score_fast(cand)
        if sc > cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
        elif random.random() < 0.05:
            cur = cand
            cur_score = sc

    return sorted(set(best))
