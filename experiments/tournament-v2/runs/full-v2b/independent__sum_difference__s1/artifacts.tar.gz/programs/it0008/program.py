import math
import random
import time
from itertools import combinations

LIMIT = 4000
MAG = 10**15


def _stats(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            if j >= i:
                sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(max(len(sums), 2)), len(diffs), len(sums)


def _score(a):
    s, _, _ = _stats(a)
    n = len(a)
    if n < 2:
        return 0.0
    return s + (1 - 1.0 / n) / 100


def eps(n):
    return (1 - 1.0 / n) / 100


def _stats_from(a):
    """Full diff and sum sets (unordered sums)."""
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
        for j in range(i, n):
            sums.add(ai + a[j])
    return diffs, sums


def score_from_sets(diffs, sums, n):
    if len(sums) < 2 or n < 2:
        return 0.0, 0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / n) / 100, len(diffs), len(sums)


def greedy_sidon(n):
    """Build a Sidon set greedily (small differences, few sum collisions)."""
    a = [0]
    used_diffs = {0}
    used_sums = {0}
    cand = 1
    while len(a) < n and cand < 10**7:
        ok = True
        nd = set()
        ns = set()
        for x in a:
            d1 = cand - x
            d2 = x - cand
            if d1 in used_diffs or d2 in used_diffs:
                ok = False
                break
            nd.add(d1)
            nd.add(d2)
        if ok:
            for x in a:
                s = cand + x
                if s in used_sums:
                    ok = False
                    break
                ns.add(s)
        if ok:
            ns.add(cand + cand)
            used_diffs |= nd
            used_diffs.add(0)
            used_sums |= ns
            a.append(cand)
        cand += 1
    return a


def try_shift_construction(n, shifts, seed):
    """A = union of B shifted by multiples of M, B a Sidon set."""
    random.seed(seed)
    base = greedy_sidon(max(4, n // len(shifts)))
    if len(base) < 2:
        base = [0, 1]
    M = max(base[-1] * 3, 10)
    a = []
    for k in shifts:
        for b in base:
            a.append(b + k * M)
    a = sorted(set(a))
    return a


def local_search(a, deadline, best_score_holder):
    a = sorted(set(a))
    cur = a[:]
    ds, ss = _stats_from(cur)
    cur_sc, nd, ns = score_from_sets(ds, ss, len(cur))
    best = cur[:]
    best_sc = cur_sc
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        op = random.random()
        if op < 0.6 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-3, 3)
        elif op < 0.75 and len(cand) < LIMIT:
            cand.append(random.randint(-50, 50))
        elif op < 0.85 and len(cand) > 2:
            i = random.randrange(len(cand))
            del cand[i]
        elif op < 0.95 and len(cand) > 2:
            i = random.randrange(len(cand))
            j = random.randrange(len(cand))
            cand[i] = -cand[i] if cand[i] else 0
        else:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, 20)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        n = len(cand)
        cds, css = _stats_from(cand)
        csc, _, _ = score_from_sets(cds, css, n)
        if csc >= cur_sc:
            cur = cand
            cur_sc = csc
            if csc > best_sc:
                best = cand[:]
                best_sc = csc
                best_score_holder[0] = best_sc
                best_score_holder[1] = best[:]
        elif random.random() < 0.05:
            cur = best[:]
            cur_sc = best_sc
    return best, best_sc


def solve():
    deadline = time.time() + 115
    best_holder = [0.0, None]

    # Candidate constructions
    candidates = []

    # 1. small hand-crafted Sidon-ish
    candidates.append([7, 15, 18, 22, -3, -2])

    # 2. pure Sidon set
    sid = greedy_sidon(30)
    candidates.append(sid)

    # 3. shifted union constructions
    for nsh in (2, 3, 4):
        for seed in range(6):
            cand = try_shift_construction(48, list(range(nsh)), seed)
            candidates.append(cand)

    # 4. random dense small sets (sums collide a lot when values are close)
    random.seed(12345)
    for _ in range(40):
        k = random.randint(6, 25)
        cand = random.sample(range(-40, 41), k)
        candidates.append(cand)

    best = None
    best_sc = -1.0
    for cand in candidates:
        if len(cand) < 2:
            continue
        ds, ss = _stats_from(cand)
        sc, _, _ = score_from_sets(ds, ss, len(cand))
        if sc > best_sc:
            best_sc = sc
            best = cand[:]
            best_holder[0] = best_sc
            best_holder[1] = best[:]

    # Local search from the best few candidates
    candidates.sort(key=lambda c: -_score_from(c))
    # helper inline
    def _local_score(a):
        ds, ss = _stats_from(a)
        return score_from_sets(ds, ss, len(a))[0]

    work = candidates[:3]
    while time.time() < deadline:
        improved = False
        for start in work:
            rem = deadline - time.time()
            if rem <= 0:
                break
            cand_best, cand_sc = local_search(start, min(deadline, time.time() + rem / len(work) + 0.5), best_holder)
            if cand_sc > best_sc:
                best = cand_best[:]
                best_sc = cand_sc
                improved = True
        if not improved and time.time() < deadline:
            # restart from best with perturbation
            if best is not None and time.time() < deadline:
                pert = best[:]
                for _ in range(random.randint(1, 3)):
                    if pert and len(pert) > 2:
                        i = random.randrange(len(pert))
                        pert[i] += random.randint(-10, 10)
                work = [sorted(set(pert))]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    # enforce constraints
    best = sorted(set(int(x) for x in best))
    best = [x for x in best if abs(x) <= MAG][:LIMIT]
    if len(best) < 2:
        best = [0, 1]
    return best


def _score_from(a):
    ds, ss = _stats_from(a)
    return score_from_sets(ds, ss, len(a))[0]


if __name__ == "__main__":
    res = solve()
    s = _score(res)
    print(len(res), s, res[:20])
