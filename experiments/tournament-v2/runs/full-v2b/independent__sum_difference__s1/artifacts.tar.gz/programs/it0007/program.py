import math
import random
import time


def _score_parts(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0, n
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    ld = len(diffs)
    ls = len(sums)
    if ls < 2:
        return 0.0, ld, ls, n
    sc = math.log(ld) / math.log(ls) + (1 - 1.0 / n) / 100
    return sc, ld, ls, n


def _score(a):
    return _score_parts(a)[0]


def _golomb_bounded(n, span):
    """Greedy Golomb-ruler-ish construction within [0, span]."""
    marks = [0]
    used = {0}
    cand = 1
    while len(marks) < n and cand <= span:
        ok = True
        for m in marks:
            d = cand - m
            if d in used:
                ok = False
                break
        if ok:
            for m in marks:
                used.add(cand - m)
            marks.append(cand)
        cand += 1
    return marks


def _sidon_mod(n):
    """Sidon set in integers via Bose-Chowla-like construction mod p using log table."""
    # find prime p with p-1 >= n
    def is_prime(x):
        if x < 2:
            return False
        i = 2
        while i * i <= x:
            if x % i == 0:
                return False
            i += 1
        return True

    p = n + 2
    while not (is_prime(p) and (p - 1) >= n):
        p += 1
    # primitive root of p
    def primitive_root(p):
        if p == 2:
            return 1
        factors = []
        m = p - 1
        d = 2
        while d * d <= m:
            if m % d == 0:
                factors.append(d)
                while m % d == 0:
                    m //= d
            d += 1
        if m > 1:
            factors.append(m)
        g = 2
        while g < p:
            if all(pow(g, (p - 1) // f, p) != 1 for f in factors):
                return g
            g += 1
        return 2

    g = primitive_root(p)
    # discrete log table
    log = [0] * p
    x = 1
    for i in range(p - 1):
        log[x] = i
        x = (x * g) % p
    # Bose-Chowla: {i : 2^i in F_p} gives Sidon in Z_{p^2-1} approx
    # simpler: use set {log table values scale} -- fallback simple greedy
    return None


def _build_sidon(n):
    """Build an n-element Sidon set with small max element via randomized greedy."""
    # try several random orders to get compact set
    best = None
    for trial in range(6):
        marks = [0]
        used = {0}
        limit = max(200, 6 * n * n)
        cand = 1
        random.seed(trial * 12345 + 7)
        while len(marks) < n and cand <= limit:
            ok = True
            for m in marks:
                if (cand - m) in used:
                    ok = False
                    break
            if ok:
                used.add(cand - 0)
                for m in marks:
                    used.add(cand - m)
                marks.append(cand)
            cand += 1
        if len(marks) == n:
            if best is None or marks[-1] < best[-1]:
                best = marks[:]
    return best


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Try several candidate constructions
    candidates = []

    # 1. random dense small sets (few elements, very high ratio possible)
    for n in (4, 5, 6, 7, 8):
        for t in range(200):
            if time.time() > deadline * 0.3:
                break
            random.seed(hash((n, t)) & 0xffffffff)
            a = set()
            while len(a) < n:
                a.add(random.randint(-3 * n, 3 * n))
            candidates.append(list(a))

    # 2. Sidon sets
    for n in (5, 6, 7, 8, 9, 10, 12, 14, 16, 20, 24, 30, 40, 50, 70, 100, 150, 200, 300, 500, 800, 1200):
        if time.time() > deadline * 0.6:
            break
        s = _build_sidon(n)
        if s is not None:
            candidates.append(s)
            # translate/scatter variant
            candidates.append([x * (1 + random.randint(0, 2)) + random.randint(-2, 2) for x in s])

    for c in candidates:
        sc, ld, ls, nn = _score_parts(c)
        if sc > best_score:
            best_score = sc
            best = list(set(c))

    # Local search from best
    cur = best[:] if best else [7, 15, 18, 22, -3, -2]
    cur_score = _score(cur)

    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.5:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif r < 0.7:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 0, 1]) * random.randint(1, 200)
        elif r < 0.85:
            cand.append(random.randint(-int(cur_score * 1000) - 10, int(cur_score * 1000) + 10))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if max(abs(x) for x in cand) > 10**15:
            continue
        sc = _score(cand)
        if sc > cur_score or random.random() < 0.02:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = cand[:]

    return sorted(set(best))
