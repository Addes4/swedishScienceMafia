import math
import random
import time


def _score(a):
    a = list(dict.fromkeys(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _fast_stats(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums)


def _local_optimize(base, deadline):
    a = list(dict.fromkeys(base))
    best = a[:]
    bd, bs = _fast_stats(best)
    best_score = math.log(bd) / math.log(bs) + (1.0 - 1.0 / len(best)) / 100.0
    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        cand = cur[:]
        mode = random.random()
        if mode < 0.72 and cand:
            i = random.randrange(len(cand))
            scale = random.choice([1, 1, 1, 2, 3, 5, 8])
            cand[i] += random.randint(-scale, scale)
        elif mode < 0.88:
            cand.append(random.randint(-200, 200))
        else:
            if len(cand) > 3:
                j = random.randrange(len(cand))
                cand.pop(j)
                cand.append(random.randint(-200, 200))

        cand = list(dict.fromkeys(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 900:
            continue

        d, s = _fast_stats(cand)
        if s <= 1:
            continue
        sc = math.log(d) / math.log(s) + (1.0 - 1.0 / len(cand)) / 100.0

        if sc >= cur_score:
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
        elif random.random() < 0.015:
            cur = best[:]
            cur_score = best_score

    return best, best_score


def _build_core(nbase, spread):
    # Dense short AP plus a few strategic asymmetric shifts.
    a = list(range(-nbase, nbase + 1))
    extra = [
        spread,
        -spread,
        2 * spread + 1,
        -2 * spread - 1,
        3 * spread + 7,
        -3 * spread - 7,
        spread * 5 + 3,
        -spread * 5 - 3,
    ]
    for x in extra:
        if x not in a:
            a.append(x)
    return a


def _score_structure(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ds = len(diffs)
    ss = len(sums)
    if ss <= 1:
        return -1.0, ds, ss
    return math.log(ds) / math.log(ss) + (1.0 - 1.0 / n) / 100.0, ds, ss


def solve():
    random.seed(12345)
    deadline = time.time() + 112.0

    best = None
    best_score = -1.0

    # Try several structural starting points.
    starts = []
    for nb in [4, 5, 6, 7, 8, 10, 12, 14, 16, 20, 24, 28]:
        for sp in [10, 20, 40, 80]:
            starts.append(_build_core(nb, sp))

    # Random sparse/Sidon-like starts.
    for _ in range(20):
        k = random.randint(8, 40)
        s = set()
        while len(s) < k:
            s.add(random.randint(-300, 300))
        starts.append(list(s))

    # Multiplicative-like starts.
    for _ in range(10):
        s = set()
        x = random.randint(2, 5)
        v = 1
        for _ in range(random.randint(10, 30)):
            s.add(v)
            s.add(-v)
            v *= x
            if abs(v) > 10**12:
                break
        if s:
            starts.append(list(s))

    for st in starts:
        if time.time() > deadline:
            break
        cand, sc = _local_optimize(st, min(deadline, time.time() + 8.0))
        if sc > best_score:
            best_score = sc
            best = cand[:]

    # Focused search around the best result.
    if best is None:
        best = [0, 1]
        best_score = _score(best)

    while time.time() < deadline:
        cand = best[:]
        for _ in range(random.randint(1, 6)):
            if not cand:
                cand = [0]
            r = random.random()
            if r < 0.55:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-50, 50)
            elif r < 0.8:
                cand.append(random.randint(-2000, 2000))
            else:
                if len(cand) > 3:
                    j = random.randrange(len(cand))
                    cand.pop(j)
                cand.append(random.randint(-2000, 2000))
        cand = list(dict.fromkeys(cand))
        if len(cand) < 2:
            continue
        d, s = _fast_stats(cand)
        if s <= 1:
            continue
        sc = math.log(d) / math.log(s) + (1.0 - 1.0 / len(cand)) / 100.0
        if sc > best_score:
            best_score = sc
            best = cand[:]

    # Final polish.
    remaining = deadline - time.time()
    if remaining > 0.5:
        polished, psc = _local_optimize(best, deadline)
        if psc > best_score:
            best = polished
            best_score = psc

    return sorted(set(int(x) for x in best if abs(x) <= 10**15))[:4000]
