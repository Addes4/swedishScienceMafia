import math
import random
import time
from scipy.optimize import minimize
import numpy as np

def _diff_sum_counts(a):
    s = set(a)
    n = len(s)
    diffs = set()
    sums = set()
    # compute sets
    for x in s:
        for y in s:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)

def score(a):
    n = len(a)
    if n < 2:
        return 0.0
    d, s = _diff_sum_counts(a)
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0

def solve():
    best = None
    best_score = -1.0
    
    # Try multiple random restarts with different constructions
    
    # Construction 1: Sidon set from quadratic residues
    # For a prime p, the set {(x, x^2 mod p)} has the property that all differences are unique
    # We can map to integers: a_i = i * M + (i^2 mod p) for suitable M
    # This gives a Sidon set (all sums distinct) but differences may collide
    
    # Let's use a simpler approach: random search with local optimization
    
    for restart in range(20):
        # Initial set: random distinct integers in a range
        # Try different sizes
        n = random.randint(20, 100)
        max_val = n * n * 2
        
        # Start with a random set
        A = random.sample(range(-max_val, max_val + 1), n)
        
        # Local search: try to improve by modifying one element at a time
        current_score = score(A)
        
        # Time limit per restart
        start_time = time.time()
        restart_time = 5.0  # seconds per restart
        
        while time.time() - start_time < restart_time:
            # Try modifying a random element
            idx = random.randrange(len(A))
            old_val = A[idx]
            
            # Try a few random new values
            best_new_val = old_val
            best_local_score = current_score
            
            for _ in range(5):
                # Generate candidate new value
                if random.random() < 0.5:
                    # Random value nearby
                    new_val = old_val + random.randint(-100, 100)
                else:
                    # Random value in the range
                    new_val = random.randint(-max_val, max_val)
                
                if new_val == old_val or new_val in A:
                    continue
                
                # Temporarily replace
                A[idx] = new_val
                new_score = score(A)
                if new_score > best_local_score:
                    best_local_score = new_score
                    best_new_val = new_val
                
                # Restore
                A[idx] = old_val
            
            if best_new_val != old_val:
                A[idx] = best_new_val
                current_score = best_local_score
            else:
                # Try adding or removing an element occasionally
                if random.random() < 0.1:
                    if len(A) > 10 and random.random() < 0.5:
                        # Remove an element
                        idx_remove = random.randrange(len(A))
                        removed = A.pop(idx_remove)
                        new_score = score(A)
                        if new_score > current_score:
                            current_score = new_score
                        else:
                            A.insert(idx_remove, removed)
                    else:
                        # Add an element
                        new_val = random.randint(-max_val, max_val)
                        if new_val not in A:
                            A.append(new_val)
                            new_score = score(A)
                            if new_score > current_score:
                                current_score = new_score
                            else:
                                A.pop()
        
        if current_score > best_score:
            best_score = current_score
            best = A[:]
            print(f"Restart {restart}: score={current_score:.4f}, size={len(A)}")
    
    # Final refinement: try to improve the best set
    if best is not None:
        A = best[:]
        current_score = best_score
        
        # Extended local search
        start_time = time.time()
        while time.time() - start_time < 60.0:
            improved = False
            
            # Try all pairs of swaps
            for i in range(len(A)):
                for j in range(i+1, len(A)):
                    # Try swapping values
                    if random.random() > 0.1:
                        continue
                    
                    A[i], A[j] = A[j], A[i]
                    new_score = score(A)
                    if new_score > current_score:
                        current_score = new_score
                        improved = True
                    else:
                        A[i], A[j] = A[j], A[i]
            
            # Try changing individual elements
            for i in range(len(A)):
                old_val = A[i]
                best_new_val = old_val
                best_local_score = current_score
                
                for _ in range(10):
                    # Try values that might increase the difference set size
                    # Use values from a grid
                    new_val = random.randint(-len(A)*len(A)*2, len(A)*len(A)*2)
                    if new_val == old_val or new_val in A:
                        continue
                    
                    A[i] = new_val
                    new_score = score(A)
                    if new_score > best_local_score:
                        best_local_score = new_score
                        best_new_val = new_val
                    A[i] = old_val
                
                if best_new_val != old_val:
                    A[i] = best_new_val
                    current_score = best_local_score
                    improved = True
            
            # Try adding an element
            if len(A) < 4000:
                for _ in range(10):
                    new_val = random.randint(-len(A)*len(A)*2, len(A)*len(A)*2)
                    if new_val not in A:
                        A.append(new_val)
                        new_score = score(A)
                        if new_score > current_score:
                            current_score = new_score
                            improved = True
                            break
                        else:
                            A.pop()
            
            # Try removing an element
            if len(A) > 10:
                for _ in range(5):
                    idx = random.randrange(len(A))
                    removed = A.pop(idx)
                    new_score = score(A)
                    if new_score > current_score:
                        current_score = new_score
                        improved = True
                        break
                    else:
                        A.insert(idx, removed)
            
            if not improved:
                # Restart from best
                A = best[:]
                current_score = best_score
                # Try random perturbation
                for _ in range(random.randint(1, 5)):
                    idx = random.randrange(len(A))
                    A[idx] = random.randint(-len(A)*len(A)*2, len(A)*len(A)*2)
                current_score = score(A)
        
        best = A
        best_score = current_score
    
    return sorted(set(best))
