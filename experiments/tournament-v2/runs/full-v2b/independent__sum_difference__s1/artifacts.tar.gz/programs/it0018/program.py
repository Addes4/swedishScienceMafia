import math
import random
import time

def _sets(a):
    a = list(set(a))
    if len(a) < 2:
        return None, None
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for j, y in enumerate(a):
            diffs.add(x - y)
            sums.add(x + y)
    return diffs, sums

def _score(a):
    diffs, sums = _sets(a)
    if diffs is None:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def _singer(n, p):
    # Build a Sidon-like set: choose k elements from Z_p with distinct pairwise
    # differences as much as possible.  Use a greedy construction.
    taken = set()
    used_diff = set()
    base = []
    for x in range(p):
        ok = True
        for y in base:
            d = (x - y) % p
            if d in used_diff or (p - d) % p in used_diff:
                if (p - d) % p != d:
                    ok = False
                    break
                ok = False
                break
        if ok:
            for y in base:
                used_diff.add((x - y) % p)
                used_diff.add((y - x) % p)
            base.append(x)
            if len(base) >= n:
                break
    return base

def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    deadline = time.time() + 100

    # Try greedy / random constructions at a few scales.
    p_candidates = [1009, 2003, 4001, 5003, 7001, 10007, 13001, 15013, 19997, 30011]
    n_fracs = [0.55, 0.4, 0.3, 0.25, 0.2, 0.15]

    for p in p_candidates:
        if time.time() > deadline:
            break
        for nf in n_fracs:
            n = max(3, int(p * nf))
            b = _singer(n, p)
            # translate so it is centered-ish; use as integers
            s = _score(b)
            if s > best_score:
                best_score = s
                best = b[:]

    # Local search to polish: try shifting / small perturbations.
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.5 and len(cand) > 3:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2])
        elif op < 0.8:
            cand.append(random.choice([-1, 1]) * random.randint(1, 30))
        elif len(cand) > 4:
            i = random.randrange(len(cand))
            cand.pop(i)
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = best[:]

    return sorted(set(best))
