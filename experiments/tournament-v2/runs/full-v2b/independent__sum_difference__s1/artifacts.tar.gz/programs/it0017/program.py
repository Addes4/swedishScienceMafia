import math
import random
import time


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _fast_counts(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            sums.add(ai + aj)
            diffs.add(ai - aj)
            diffs.add(aj - ai)
    return len(diffs), len(sums)


def _greedy(n, seed):
    rng = random.Random(seed)
    used = {0}
    a = [0]
    while len(a) < n:
        best_x = None
        best_key = None
        # sample candidate shifts; include small structured values
        cands = set()
        for _ in range(160):
            if rng.random() < 0.5:
                v = rng.randint(-4 * n, 4 * n)
            else:
                v = rng.randint(-2 * n * n, 2 * n * n)
            cands.add(v)
        for v in cands:
            if v in used:
                continue
            trial = a + [v]
            d, s = _fast_counts(trial)
            # maximize differences, then minimize sums
            key = (d, -s, rng.random())
            if best_key is None or key > best_key:
                best_key = key
                best_x = v
        if best_x is None:
            break
        a.append(best_x)
        used.add(best_x)
    return a


def _improve(a, deadline):
    n = len(a)
    if n < 2:
        return a
    cur = a[:]
    best = a[:]
    best_score = _score(best)
    used = set(cur)
    steps = 0
    while time.time() < deadline and steps < 20000:
        steps += 1
        cand = cur[:]
        i = random.randrange(n)
        delta = random.randint(-6, 6)
        if delta == 0:
            delta = random.choice([-1, 1])
        old = cand[i]
        new = old + delta
        if new in used and new != old:
            continue
        cand[i] = new
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]
            cur = cand[:]
            used.discard(old)
            used.add(new)
        elif random.random() < 0.15:
            cur = cand[:]
            used.discard(old)
            used.add(new)
    return best


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0
    n_vals = [16, 20, 24, 28, 32, 36, 40, 48, 56]
    seed = 0
    while time.time() < deadline:
        n = random.choice(n_vals)
        seed += 1
        a = _greedy(n, seed)
        a = sorted(set(a))
        a = _improve(a, min(deadline, time.time() + 8))
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a[:]
        # occasional larger continuation from the current best
        if best is not None and random.random() < 0.3:
            a2 = best[:]
            rng = random.Random(seed + 1000003)
            while len(a2) < min(80, len(best) + 8) and time.time() < deadline:
                base = a2[:]
                cand = set()
                for _ in range(200):
                    cand.add(rng.randint(-1000, 1000))
                bx = None
                bk = None
                for v in cand:
                    if v in base:
                        continue
                    t = base + [v]
                    d, sm = _fast_counts(t)
                    key = (d, -sm, rng.random())
                    if bk is None or key > bk:
                        bk = key
                        bx = v
                if bx is None:
                    break
                a2.append(bx)
            a2 = sorted(set(a2))
            a2 = _improve(a2, min(deadline, time.time() + 8))
            s2 = _score(a2)
            if s2 > best_score:
                best_score = s2
                best = a2[:]
    if best is None:
        best = [0, 1]
    return sorted(set(best))
