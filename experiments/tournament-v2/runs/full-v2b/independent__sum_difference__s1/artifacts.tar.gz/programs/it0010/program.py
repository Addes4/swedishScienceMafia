import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _fast_stats(a):
    a.sort()
    n = len(a)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    return len(sums)


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    deadline = time.time() + 100

    # Try structured seeds
    seeds = []
    # Geometric-ish set: powers plus offsets to create many differences, few sums
    for k in range(2, 8):
        s = []
        v = 1
        for i in range(k):
            s.append(v)
            v = v * 2 + random.randint(0, 3)
        seeds.append(s)
    # Union of two intervals with gap (difference-rich)
    for lo, hi, gap in [(0, 40, 100), (-50, 50, 500), (0, 60, 300)]:
        s = list(range(lo, hi)) + list(range(lo + gap, hi + gap))
        seeds.append(s)

    for seed in seeds:
        seed = list(set(seed))
        score = _score(seed)
        if score > best_score:
            best, best_score = seed[:], score

    cur = best[:]
    cur_score = best_score

    # Local search with adaptive moves
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        i = random.randrange(len(cand))
        if op < 0.5:
            cand[i] += random.randint(-5, 5)
        elif op < 0.8:
            cand[i] += random.choice([-1, 1]) * random.randint(1, 50)
        elif op < 0.9:
            cand.append(random.randint(-100, 200))
        else:
            if len(cand) > 4:
                cand.pop(random.randrange(len(cand)))

        cand = list(set(cand))
        if len(cand) > 4000:
            continue
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
