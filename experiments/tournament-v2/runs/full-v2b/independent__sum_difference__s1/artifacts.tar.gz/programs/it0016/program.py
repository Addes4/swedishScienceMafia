import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if ns < 2 or nd < 2:
        return -1e18, nd, ns
    score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return score, nd, ns


def _base_set(n):
    """Geometric progression base doubling -> few sums, many diffs."""
    return [1 << i for i in range(n)]


def _perturb(a, max_shift):
    a = a[:]
    i = random.randrange(len(a))
    a[i] += random.randint(-max_shift, max_shift)
    return a


def solve():
    deadline = time.time() + 115

    # Candidate pool: GPs of various sizes
    candidates = []
    for n in range(5, 60):
        candidates.append(_base_set(n))

    best = None
    best_score = -1e18

    for base in candidates:
        s, _, _ = _stats(base)
        if s > best_score:
            best_score = s
            best = base[:]

    # Local search around GP bases
    random.seed(12345)
    n_best = len(best)
    cur = best[:]
    cur_score = best_score

    step = 1
    it = 0
    while time.time() < deadline:
        it += 1
        # occasionally grow / shrink
        r = random.random()
        if r < 0.02 and len(cur) < 4000:
            cand = cur[:]
            cand.append(random.choice(cand) * 2 + random.randint(-1, 1))
        elif r < 0.03 and len(cur) > 4:
            cand = cur[:]
            cand.pop(random.randrange(len(cand)))
        else:
            cand = _perturb(cur, step)

        s, _, _ = _stats(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
                step = max(1, abs(step))
        else:
            if random.random() < 0.001:
                cur, cur_score = best[:], best_score
            step = max(1, step)
            if random.random() < 0.002:
                step = min(1 << 20, step * 2)

    result = sorted(set(int(x) for x in best))
    # clamp to allowed range
    result = [x for x in result if abs(x) <= 10**15]
    if len(result) > 4000:
        result = result[:4000]
    if len(result) < 2:
        result = [0, 1]
    return result
