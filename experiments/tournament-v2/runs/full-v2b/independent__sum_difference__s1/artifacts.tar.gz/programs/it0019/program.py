import math, random, time
import numpy as np

def _score(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    n = len(a)
    if n < 2: return 0.0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return math.log(d) / math.log(s) + (1 - 1/n) / 100.0

def _score_py(a):
    a = set(a)
    if len(a) < 2: return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/len(a)) / 100.0

def base_digit_set(base, n):
    # A = { sum_{i<n} c_i * base^i : c_i in {0,1} } would be too big (2^n).
    # Instead use a Golomb/Cantor-like: choose for each index i a coefficient
    # from a small set, but only a sparse selection.
    return None

def construct(base, n):
    # A = { i + base * something } pattern: use A = {base^i * k ...}
    # Better: Sidon-like set from base-b representation with digits 0..b-1
    # Take A = { sum d_i * base^i : d_i in {0,1}, i=0..n-1 } limited to n picks.
    # That's 2^n so restrict.
    return None

def greedy_cantor(max_n, base):
    # Build set with digits {0,1} in base `base`, greedy by adding smallest next number
    # that keeps sum set small. For base=3 this is Cantor set, sum set is 2*size.
    arr = [0]
    cand = 1
    pool = []
    # generate candidates of form sum of distinct powers of base
    from itertools import combinations
    powers = [base**i for i in range(20)]
    # generate small numbers with digit 0/1
    def gen(limit):
        res = []
        # BFS enumerate
        def rec(idx, val):
            if val > limit: return
            res.append(val)
            for j in range(idx+1, len(powers)):
                nv = val + powers[j]
                if nv <= limit:
                    rec(j, nv)
        for j in range(len(powers)):
            if powers[j] <= limit:
                rec(j, powers[j])
        res.sort()
        return res
    return None

def solve():
    best_a = [7, 15, 18, 22, -3, -2]
    best_s = _score(best_a)
    deadline = time.time() + 110

    # Candidate constructions to try
    candidates = []

    # Cantor-like sets in base 3,4,5 with near-real base growth
    for base in [3,4,5,6,7,8,10,16,32]:
        for top in [3,4,5,6,7,8,10,12,15,20]:
            powers = [base**i for i in range(top+1)]
            # pick a contiguous range such that size reasonable
            A = []
            # use set of sums of distinct powers limited by count
            # generate via BFS keeping smallest numbers
            vals = [0]
            for p in powers:
                new = vals + [v+p for v in vals]
                vals = new
                if len(vals) > 60000:
                    vals = sorted(vals)[:60000]
            vals = sorted(set(vals))[:4000]
            if len(vals) >= 2:
                candidates.append(vals)

    # random Sidon-ish: A = {i*B + f(i)}
    for _ in range(40):
        B = random.randint(2, 50)
        n = random.randint(10, 60)
        A = [random.randint(0, B-1) + i*B for i in range(n)]
        candidates.append(A)
    for _ in range(40):
        B = random.randint(3, 100)
        n = random.randint(20, 200)
        # A = subset from digits in base B avoiding equal sums
        A = []
        cur = 0
        step = B
        for i in range(n):
            A.append(random.randint(0, step-1) + i*step)
        candidates.append(A)

    # Cantor-set based: powers of 3 with digits 0,1
    for top in [6,7,8,9,10,11,12,13]:
        vals = [0]
        for i in range(top):
            p = 3**i
            new = vals + [v+p for v in vals]
            vals = sorted(set(new))
        if len(vals) >= 2:
            candidates.append(vals)

    # Moser-de Bruijn: numbers that are sums of distinct powers of 4
    for top in [5,6,7,8,9,10]:
        vals = [0]
        for i in range(top):
            p = 4**i
            vals = sorted(set(vals + [v+p for v in vals]))
        if len(vals) >= 2:
            candidates.append(vals)

    # extend small candidates greedily with random local search
    for c in candidates:
        if time.time() > deadline: break
        c = sorted(set(c))
        if len(c) < 2: continue
        s = _score_py(c)
        if s > best_s:
            best_s = s; best_a = c[:]

    # local search on best
    cur = best_a[:]
    cs = best_s
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        r = random.random()
        if r < 0.5 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif r < 0.75:
            # shift all
            d = random.randint(-3,3)
            cand = [x+d for x in cand]
        elif r < 0.9:
            cand.append(random.randint(-100, 100))
        else:
            if len(cand) > 3:
                i = random.randrange(len(cand))
                del cand[i]
        cand = sorted(set(cand))
        if len(cand) < 2: continue
        s = _score_py(cand)
        if s >= cs:
            cur, cs = cand, s
            if s > best_s:
                best_s = s; best_a = cand[:]
        elif random.random() < 0.02:
            cur = best_a[:]

    # try greedy additions from base-3 Cantor times something to boost ratio
    for base in [3,4]:
        for top in [9,10,11,12]:
            if time.time() > deadline: break
            vals = [0]
            for i in range(top):
                p = base**i
                vals = sorted(set(vals + [v+p for v in vals]))
            if not vals: continue
            v = vals[:4000]
            s = _score_py(v)
            if s > best_s:
                best_s = s; best_a = v[:]

    return sorted(set(best_a))
