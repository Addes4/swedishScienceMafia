import math
import random
import time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100

def _build_geometric(base, n, offset=0):
    # A = {base^i} scaled so differences are rich, sums are sparse-ish
    A = []
    x = 1
    for i in range(n):
        A.append(x + offset)
        x *= base
        if x > 10**14:
            break
    return A

def _build_powers_of_2_with_perturbations(n, seed=0):
    rng = random.Random(seed)
    A = []
    for i in range(n):
        A.append(2**i + rng.randint(-1, 1) * (2**(max(0, i-1)) // 2 + 1))
    return A

def _local_search(start, deadline):
    best = list(set(start))
    best_score = _score(best)
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        delta = random.choice([-2, -1, 1, 2, -3, 3])
        cand[i] += delta
        # avoid duplicates
        if len(set(cand)) < len(cand):
            continue
        s = _score(cand)
        if s >= best_score:
            best = list(set(cand))
            best_score = s
            cur = cand
        elif random.random() < 0.05:
            cur = best[:]
    return best, best_score

def solve():
    deadline = time.time() + 110
    candidates = []
    # Candidate 1: powers of 2 with controlled sum set
    n_try = 60
    for seed in range(5):
        candidates.append(_build_powers_of_2_with_perturbations(n_try, seed))
    # Candidate 2: base-2 geometric
    candidates.append(_build_geometric(2, n_try, offset=1))
    # Candidate 3: base-3 geometric
    candidates.append(_build_geometric(3, n_try, offset=2))
    # Candidate 4: mixed base representation
    A = []
    for i in range(40):
        A.append(2**i + 3**i)
    candidates.append(A)

    best = None
    best_score = -1.0
    for c in candidates:
        c = list(set(c))
        s = _score(c)
        if s > best_score:
            best_score = s
            best = c

    # Refine with local search on the best candidate
    time_left = deadline - time.time()
    if time_left > 0:
        b, bs = _local_search(best, deadline)
        if bs > best_score:
            best, best_score = b, bs

    return sorted(set(best))
