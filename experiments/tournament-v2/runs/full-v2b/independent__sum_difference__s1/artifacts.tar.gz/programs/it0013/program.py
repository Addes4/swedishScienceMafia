import math, random, time

def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    d = len(diffs)
    s = len(sums)
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s

def _score_fast(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    aa = a
    for i in range(n):
        xi = aa[i]
        for j in range(n):
            diffs.add(xi - aa[j])
            sums.add(xi + aa[j])
    d = len(diffs)
    s = len(sums)
    if s < 2:
        return 0.0, d, s
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100, d, s

def _greedy_sidonish(n, span, seed):
    rng = random.Random(seed)
    A = [0]
    used_sums = {0}
    used_diffs = {0}
    # keep track of counts via sets of existing pair sums/diffs
    existing_diffs = {0}
    existing_sums = {0}
    for _ in range(n - 1):
        best = None
        best_new = -1
        for _try in range(40):
            c = rng.randint(-span, span)
            if c in A:
                continue
            # count new sums and diffs
            new_s = 0
            new_d = 0
            ok = True
            for x in A:
                if (x + c) not in existing_sums:
                    new_s += 1
                if (c - x) not in existing_diffs:
                    new_d += 1
                if (x - c) not in existing_diffs:
                    new_d += 1
                if new_d > 4 and new_s == 0:
                    pass
            score = new_d - 3 * new_s
            if score > best_new:
                best_new = score
                best = c
        if best is None:
            break
        c = best
        for x in A:
            existing_sums.add(x + c)
            existing_diffs.add(c - x)
            existing_diffs.add(x - c)
        A.append(c)
    return A

def solve():
    deadline = time.time() + 110
    bestA = [0]
    bestScore = 0.0

    # Candidate 1: arithmetic progression block (small sums, small diffs)
    for n in [100, 300, 800, 1500, 3000]:
        A = list(range(n))
        s, d, ss = _score_fast(A)
        if s > bestScore:
            bestScore = s
            bestA = A

    # Candidate 2: two APs with different common differences -> large difference set
    # A = {i} union {i*M + offset}
    for n1 in [50, 200, 700, 1500]:
        for M in [3, 5, 7, 11, 13, 17]:
            A = list(range(n1)) + [i * M + 1000000 for i in range(n1)]
            A = list(set(A))
            s, d, ss = _score_fast(A)
            if s > bestScore:
                bestScore = s
                bestA = A

    # Candidate 3: AP plus one far element to boost differences
    for n in [200, 800, 2000, 3500]:
        for off in [10**6, 10**7, 10**9, 10**12]:
            A = list(range(n))
            A.append(off)
            s, d, ss = _score_fast(A)
            if s > bestScore:
                bestScore = s
                bestA = A

    # Candidate 4: random greedy sets that maximize new diffs - 3*new sums
    for seed in range(30):
        if time.time() > deadline - 30:
            break
        n = random.Random(seed).choice([50, 100, 200, 400])
        span = random.Random(seed + 1000).choice([n * 2, n * 5, n * 20, 10**6])
        A = _greedy_sidonish(n, span, seed)
        s, d, ss = _score_fast(A)
        if s > bestScore:
            bestScore = s
            bestA = A

    # Candidate 5: arithmetic progression with sparse large perturbations
    rng = random.Random(12345)
    for n in [500, 1000, 2000, 3000]:
        for k in [1, 2, 3]:
            A = list(range(n))
            for _ in range(k):
                idx = rng.randrange(len(A))
                A[idx] += rng.randint(10**6, 10**12)
            A = list(set(A))
            s, d, ss = _score_fast(A)
            if s > bestScore:
                bestScore = s
                bestA = A

    # Local search refinement around best
    cur = bestA[:]
    curScore, _, _ = _score(cur)
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.5 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-10, 10)
            if cand[i] in [cand[j] for j in range(len(cand)) if j != i]:
                continue
        elif op < 0.8 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-10**6, 10**6, -10**9, 10**9, -10**12, 10**12])
            if cand[i] in [cand[j] for j in range(len(cand)) if j != i]:
                continue
        else:
            continue
        if len(set(cand)) < 2:
            continue
        s, _, _ = _score(cand)
        if s >= curScore:
            cur = cand
            curScore = s
            if s > bestScore:
                bestScore = s
                bestA = cand[:]

    if not bestA or len(set(bestA)) < 2:
        bestA = [0, 1]
    return sorted(set(bestA))
