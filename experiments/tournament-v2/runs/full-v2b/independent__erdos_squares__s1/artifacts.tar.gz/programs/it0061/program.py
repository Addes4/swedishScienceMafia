import math

def solve(n):
    if n <= 0:
        return []
    # Best simple method: perfect square grid when possible.
    k = math.isqrt(n)
    if k * k == n:
        s = 1.0 / k
        return [((i+0.5)*s, (j+0.5)*s, 0.0, s) for i in range(k) for j in range(k)]

    # For non-squares, use a grid plus one extra row/column arrangement.
    # Try all ways to write n = a*b + r, using a grid of a by b and extra squares.
    best = None
    best_sum = -1.0

    # Candidate: full k x k grid + leftover small squares along edge.
    # Put leftover squares of size s_extra in remaining space.
    if k >= 1:
        s = 1.0 / k
        squares = [((i+0.5)*s, (j+0.5)*s, 0.0, s) for i in range(k) for j in range(k)]
        rem = n - k*k
        # Place remainder as tiny squares in a row in the top strip if possible.
        # Use strip of height 1 - k*s = 0 (no space). Instead shrink slightly.
        # Better: make grid of k rows but k+1 columns? Try rectangular grids.
        pass

    # Try rectangular grids a x b with a*b <= n, placing leftovers as small squares.
    # Maximize sum: a*b*(1/max(a,b)) + leftover * small_side
    # Rectangles can be non-square grid cells if a != b? Actually squares must fit in cells.
    # If grid a by b, cell width=1/a, height=1/b; square side = min(1/a,1/b).
    for a in range(1, n+1):
        for b in range(1, n//a + 1):
            cnt = a*b
            if cnt > n:
                break
            s = min(1.0/a, 1.0/b)
            # leftover squares can be placed in a thin strip if a*s < 1 or b*s < 1.
            rem = n - cnt
            left_sum = s * cnt
            # Add leftover squares in remaining area as small squares.
            # Area left = 1 - cnt*s*s? No, squares don't tile perfectly unless a==b.
            # Actually if a<=b, s=1/b, width used = a/b <= 1.
            # Remaining strip width = 1 - a/b, can fit squares of side <= strip_width.
            # Similarly height strip.
            if a <= b:
                strip_w = 1.0 - a * s
                strip_h = 1.0 - b * s
            else:
                strip_w = 1.0 - a * s
                strip_h = 1.0 - b * s
            # leftover squares: try to pack into strip with side up to max(strip_w, strip_h)
            extra_side = 0.0
            if rem > 0:
                # simple: put them in one strip
                if strip_w > 1e-12 or strip_h > 1e-12:
                    # pack rem squares in the larger strip
                    if strip_h >= strip_w:
                        # horizontal strip at top of height strip_h, width 1
                        # can fit floor(1/extra) squares
                        # maximize total = rem * extra s.t. extra * ceil(sqrt(rem)) <= 1
                        m = math.isqrt(rem)
                        if m*m < rem:
                            m += 1
                        # Actually place rem squares in grid within strip
                        # simpler: just use small squares of side 0 (allowed)
                        extra_side = 0.0
                        # better: try to fit rem squares in strip with side = strip_h, grid
                        cols = int(1.0 / strip_h)
                        if cols > 0:
                            rows_needed = (rem + cols - 1) // cols
                            if rows_needed * strip_h <= 1.0 + 1e-12:
                                extra_side = strip_h
                    else:
                        m = math.isqrt(rem)
                        if m*m < rem:
                            m += 1
                        extra_side = 0.0
                        cols = int(1.0 / strip_w)
                        if cols > 0:
                            rows_needed = (rem + cols - 1) // cols
                            if rows_needed * strip_w <= 1.0 + 1e-12:
                                extra_side = strip_w
            total = left_sum + rem * extra_side
            if total > best_sum + 1e-15:
                best_sum = total
                best = (a, b, s, extra_side, rem)

    if best is None:
        # Fallback: all zero except one tiny
        return [(0.5, 0.5, 0.0, 0.0)] * n

    a, b, s, extra_side, rem = best
    squares = []
    # Place a x b grid of squares of side s.
    # If a <= b: use a columns, b rows, cell width = 1/a, height=1/b, square side = 1/b.
    # Actually square side = min(1/a,1/b)=s.
    if a <= b:
        # width of each cell = 1/a, but we use square side s = 1/b <= 1/a
        # center them horizontally in each column? Or left-align.
        # Place in a subrectangle of width a*s, height b*s = 1.
        # So grid occupies width a*s, full height.
        left = 0.0
        for i in range(a):
            for j in range(b):
                cx = left + (i + 0.5) * s
                cy = (j + 0.5) * s
                squares.append((cx, cy, 0.0, s))
    else:
        # a > b: height used = b*s < 1, width full.
        bottom = 0.0
        for i in range(a):
            for j in range(b):
                cx = (i + 0.5) * s
                cy = bottom + (j + 0.5) * s
                squares.append((cx, cy, 0.0, s))

    # Place remaining squares as points (side 0) - allowed.
    # Better: try to place them in remaining strip if extra_side > 0.
    placed = a*b
    if rem > 0:
        if a <= b:
            strip_w = 1.0 - a * s
            # vertical strip on right of width strip_w, height 1
            if strip_w > 1e-12:
                cols = int(1.0 / strip_w)
                if cols > 0:
                    # place rem squares of side strip_w in grid
                    rows_needed = (rem + cols - 1) // cols
                    if rows_needed * strip_w <= 1.0 + 1e-9:
                        for idx in range(min(rem, cols * rows_needed)):
                            r = idx // cols
                            c = idx % cols
                            cx = a * s + (c + 0.5) * strip_w
                            cy = (r + 0.5) * strip_w
                            squares.append((cx, cy, 0.0, strip_w))
                            placed += 1
        else:
            strip_h = 1.0 - b * s
            # horizontal strip on top of height strip_h, width 1
            if strip_h > 1e-12:
                cols = int(1.0 / strip_h)
                if cols > 0:
                    rows_needed = (rem + cols - 1) // cols
                    if rows_needed * strip_h <= 1.0 + 1e-9:
                        for idx in range(min(rem, cols * rows_needed)):
                            r = idx // cols
                            c = idx % cols
                            cx = (c + 0.5) * strip_h
                            cy = b * s + (r + 0.5) * strip_h
                            squares.append((cx, cy, 0.0, strip_h))
                            placed += 1

    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))

    # Clamp to [0,1]
    out = []
    for (cx, cy, ang, side) in squares[:n]:
        if side < 1e-15:
            out.append((0.5, 0.5, 0.0, 0.0))
        else:
            # ensure inside
            cx = max(side/2, min(1 - side/2, cx))
            cy = max(side/2, min(1 - side/2, cy))
            out.append((cx, cy, ang, side))
    return out
