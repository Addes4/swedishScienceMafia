import math
import random
import time


def _overlap(a, b, eps=1e-9):
    """Return True if two squares (cx, cy, angle, side) overlap with positive area."""
    if a[3] <= eps or b[3] <= eps:
        return False
    # Separating axis theorem for two oriented squares
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    ca = math.cos(2 * math.pi * aa)
    sa = math.sin(2 * math.pi * aa)
    cb = math.cos(2 * math.pi * ba)
    sb = math.sin(2 * math.pi * ba)

    # half-extents along each local axis
    ha = asz * 0.5
    hb = bsz * 0.5

    # corner offsets for A
    ax1, ay1 = ca * ha, sa * ha
    ax2, ay2 = -sa * ha, ca * ha

    # corner offsets for B
    bx1, by1 = cb * hb, sb * hb
    bx2, by2 = -sb * hb, cb * hb

    # centers difference
    dx, dy = bx - ax, by - ay

    # axes from A
    for ux, uy in ((ax1, ay1), (ax2, ay2)):
        # project both boxes
        rA = abs(ux * ax1 + uy * ay1) + abs(ux * ax2 + uy * ay2)
        rB = abs(ux * bx1 + uy * by1) + abs(ux * bx2 + uy * by2)
        dist = abs(ux * dx + uy * dy)
        if dist >= rA + rB - eps:
            return False

    # axes from B
    for ux, uy in ((bx1, by1), (bx2, by2)):
        rA = abs(ux * ax1 + uy * ay1) + abs(ux * ax2 + uy * ay2)
        rB = abs(ux * bx1 + uy * by1) + abs(ux * bx2 + uy * by2)
        dist = abs(ux * dx + uy * dy)
        if dist >= rA + rB - eps:
            return False

    return True


def _inside(cx, cy, angle, side, eps=1e-9):
    """Check the square fits in [0,1]^2."""
    if side <= eps:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    ca = math.cos(2 * math.pi * angle)
    sa = math.sin(2 * math.pi * angle)
    h = side * 0.5
    # four corners
    pts = []
    for sx, sy in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
        px = cx + ca * h * sx - sa * h * sy
        py = cy + sa * h * sx + ca * h * sy
        pts.append((px, py))
    minx = min(p[0] for p in pts)
    maxx = max(p[0] for p in pts)
    miny = min(p[1] for p in pts)
    maxy = max(p[1] for p in pts)
    return minx >= -eps and maxx <= 1 + eps and miny >= -eps and maxy <= 1 + eps


def _feasible(squares, eps=1e-9):
    for i in range(len(squares)):
        if not _inside(*squares[i], eps=eps):
            return False
        for j in range(i + 1, len(squares)):
            if _overlap(squares[i], squares[j], eps=eps):
                return False
    return True


def _score(squares):
    return sum(s[3] for s in squares)


def _clamp_square(sq):
    cx, cy, ang, side = sq
    if side <= 0:
        return (min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), ang, 0.0)
    ca = math.cos(2 * math.pi * ang)
    sa = math.sin(2 * math.pi * ang)
    h = side * 0.5
    dx = abs(ca) * h + abs(sa) * h
    dy = abs(sa) * h + abs(ca) * h
    if dx > 0.5 or dy > 0.5:
        side = min(1.0 / (abs(ca) + abs(sa)), 1.0 / (abs(sa) + abs(ca)))
        h = side * 0.5
        dx = abs(ca) * h + abs(sa) * h
        dy = abs(sa) * h + abs(ca) * h
    cx = min(max(cx, dx), 1.0 - dx)
    cy = min(max(cy, dy), 1.0 - dy)
    return (cx, cy, ang, side)


def _repair(squares):
    """Greedy repair: try to keep as large sides as possible while removing overlaps."""
    squares = [_clamp_square(s) for s in squares]
    changed = True
    while changed:
        changed = False
        for i in range(len(squares)):
            for j in range(i + 1, len(squares)):
                if _overlap(squares[i], squares[j]):
                    # shrink the larger one slightly; if equal shrink both
                    si = squares[i][3]
                    sj = squares[j][3]
                    if si <= 0 and sj <= 0:
                        continue
                    if si >= sj:
                        new_side = max(0.0, si * 0.92 - 1e-6)
                        squares[i] = (squares[i][0], squares[i][1], squares[i][2], new_side)
                    else:
                        new_side = max(0.0, sj * 0.92 - 1e-6)
                        squares[j] = (squares[j][0], squares[j][1], squares[j][2], new_side)
                    changed = True
        if changed:
            squares = [_clamp_square(s) for s in squares]
    return squares


def _perturb(squares, strength, rng):
    out = []
    for cx, cy, ang, side in squares:
        if side <= 0:
            out.append((cx, cy, ang, side))
            continue
        ncx = cx + rng.gauss(0, strength * side)
        ncy = cy + rng.gauss(0, strength * side)
        nang = ang + rng.gauss(0, strength)
        nside = side * (1.0 + rng.gauss(0, strength * 0.5))
        if nside < 0:
            nside = 0.0
        out.append((ncx, ncy, nang, nside))
    return out


def _initial_grid(n):
    """Start with a grid of equal squares plus zeros."""
    k = max(1, math.isqrt(n))
    # if n has remainder, still use k x k grid and zeros
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _try_random_fill(base, n, time_limit, rng):
    """Given a base feasible packing of some size, try to add more squares and improve."""
    best = list(base)
    best_score = _score(best)
    # first, attempt to add squares to fill up to n
    while len(best) < n:
        add_side = 0.0
        add = (0.5, 0.5, 0.0, 0.0)
        # try a few random candidates for new small squares
        for _ in range(20):
            side = rng.uniform(0.001, 0.1)
            ang = rng.random()
            cx = rng.uniform(side * 0.5, 1 - side * 0.5)
            cy = rng.uniform(side * 0.5, 1 - side * 0.5)
            cand = (cx, cy, ang, side)
            if _inside(*cand) and all(not _overlap(cand, s) for s in best):
                if side > add_side:
                    add_side = side
                    add = cand
        if add_side > 0:
            best.append(add)
        else:
            best.append((0.5, 0.5, 0.0, 0.0))
    best_score = _score(best)

    start = time.time()
    it = 0
    while time.time() - start < time_limit:
        it += 1
        strength = 0.05 / (1 + it * 0.001)
        cand = _perturb(best, strength, rng)
        cand = _repair(cand)
        # try to grow some squares greedily
        cand_score = _score(cand)
        if cand_score > best_score:
            best = cand
            best_score = cand_score
        # occasionally try to grow small squares
        if it % 50 == 0:
            cand2 = list(best)
            for idx in range(len(cand2)):
                if cand2[idx][3] <= 0:
                    continue
                cx, cy, ang, side = cand2[idx]
                # try larger side
                for factor in (1.05, 1.1, 1.2):
                    ns = side * factor
                    if ns > 1.0:
                        continue
                    sq = (cx, cy, ang, ns)
                    if _inside(*sq) and all(not _overlap(sq, cand2[j]) for j in range(len(cand2)) if j != idx):
                        cand2[idx] = sq
                        break
            cand2_score = _score(_repair(cand2))
            if cand2_score > best_score:
                best = _repair(cand2)
                best_score = cand2_score

    return best


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    rng = random.Random(12345)

    # Time budget per n, but we use overall small budget since called many times.
    # We will use at most 2 seconds for small n, 10 seconds for larger n.
    time_limit = 2.0 if n <= 50 else 8.0

    # Start with a grid packing
    best = _initial_grid(n)
    best = _repair(best)
    best_score = _score(best)

    # Multi-start local search
    num_restarts = 3 if n <= 50 else 2
    for r in range(num_restarts):
        base = _initial_grid(n)
        # randomize slightly
        base = [(cx + rng.gauss(0, 0.02), cy + rng.gauss(0, 0.02), ang + rng.gauss(0, 0.1), s)
                for cx, cy, ang, s in base]
        base = _repair(base)
        candidate = _try_random_fill(base, n, time_limit / num_restarts, rng)
        if _score(candidate) > best_score:
            best = candidate
            best_score = _score(candidate)

    # Final sanity: ensure feasibility
    if not _feasible(best):
        best = _repair(best)
    return best
