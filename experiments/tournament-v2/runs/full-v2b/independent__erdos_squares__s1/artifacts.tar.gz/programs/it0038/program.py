import math
import random
import numpy as np
from scipy.optimize import minimize

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _rot(angle):
    c = math.cos(2.0 * math.pi * angle)
    s = math.sin(2.0 * math.pi * angle)
    return c, s


def _corners(cx, cy, angle, side):
    h = 0.5 * side
    c, s = _rot(angle)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        px = cx + c * dx - s * dy
        py = cy + s * dx + c * dy
        pts.append((px, py))
    return pts


def _overlap_penalty_for_pair(sq1, sq2):
    """Return a positive number if interiors overlap, else 0."""
    x1, y1, a1, s1 = sq1
    x2, y2, a2, s2 = sq2
    if s1 <= 1e-15 or s2 <= 1e-15:
        return 0.0
    p1 = _corners(x1, y1, a1, s1)
    p2 = _corners(x2, y2, a2, s2)
    # separating axis theorem for convex polygons
    for poly in (p1, p2):
        n = len(poly)
        for i in range(n):
            ax = poly[i][0] - poly[(i + 1) % n][0]
            ay = poly[i][1] - poly[(i + 1) % n][1]
            # normal
            nx, ny = -ay, ax
            # projection of both polygons
            min1 = min(px * nx + py * ny for px, py in p1)
            max1 = max(px * nx + py * ny for px, py in p1)
            min2 = min(px * nx + py * ny for px, py in p2)
            max2 = max(px * nx + py * ny for px, py in p2)
            if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                return 0.0
    # if no separating axis found -> overlap; estimate penetration depth loosely
    # use minimum translation distance in the axes
    best = 1e9
    polys = [p1, p2]
    for poly in polys:
        n = len(poly)
        for i in range(n):
            ax = poly[i][0] - poly[(i + 1) % n][0]
            ay = poly[i][1] - poly[(i + 1) % n][1]
            nx, ny = -ay, ax
            L = math.hypot(nx, ny)
            if L < 1e-15:
                continue
            nx, ny = nx / L, ny / L
            min1 = min(px * nx + py * ny for px, py in p1)
            max1 = max(px * nx + py * ny for px, py in p1)
            min2 = min(px * nx + py * ny for px, py in p2)
            max2 = max(px * nx + py * ny for px, py in p2)

            def interval_inside(a1, b1, a2, b2):
                # intersection length of [a1,b1] and [a2,b2]
                return max(0.0, min(b1, b2) - max(a1, a2))

            overlap = interval_inside(min1, max1, min2, max2)
            if overlap > 0:
                best = min(best, overlap)
    return best if best < 1e9 else 0.0


def _violations(squares):
    """Total wasted area / overlap measure and containment measure."""
    v = 0.0
    for (cx, cy, a, s) in squares:
        if s <= 0:
            continue
        for px, py in _corners(cx, cy, a, s):
            if px < -1e-12:
                v += -px
            if px > 1 + 1e-12:
                v += px - 1
            if py < -1e-12:
                v += -py
            if py > 1 + 1e-12:
                v += py - 1
    n = len(squares)
    for i in range(n):
        for j in range(i + 1, n):
            v += _overlap_penalty_for_pair(squares[i], squares[j])
    return v


# ---------------------------------------------------------------------------
# initial layouts
# ---------------------------------------------------------------------------

def _initial_grid(n):
    k = max(1, int(round(math.sqrt(n))))
    while k * k > n:
        k -= 1
        if k < 1:
            k = 1
            break
    if k < 1:
        k = 1
    side = 1.0 / k
    sq = []
    for i in range(k):
        for j in range(k):
            sq.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
            if len(sq) == n:
                break
        if len(sq) == n:
            break
    while len(sq) < n:
        sq.append([0.5, 0.5, 0.0, 0.0])
    return sq[:n]


def _initial_mixed(n):
    """Try several structured starts and return the best after quick local search."""
    candidates = []
    candidates.append(_initial_grid(n))
    for k in range(max(1, int(math.sqrt(n)) - 1), int(math.sqrt(n)) + 3):
        if k * k <= n:
            side = 1.0 / k
            sq = []
            for i in range(k):
                for j in range(k):
                    sq.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
                    if len(sq) == n:
                        break
                if len(sq) == n:
                    break
            while len(sq) < n:
                sq.append([0.5, 0.5, 0.0, 0.0])
            candidates.append(sq[:n])
    return min(candidates, key=lambda s: _violations(s))


# ---------------------------------------------------------------------------
# continuous optimisation on top of a configuration
# ---------------------------------------------------------------------------

def _pack_optimize(squares, maxiter=120):
    n = len(squares)
    # initial parameter vector
    x0 = []
    for (cx, cy, a, s) in squares:
        x0.extend([cx, cy, a, s])
    x0 = np.array(x0, dtype=float)

    bounds = []
    for _ in range(n):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])

    def objective(x):
        val = 0.0
        for i in range(n):
            val -= x[4 * i + 3]
        return val

    # constraint: for each pair, non-overlap (SAT-based)
    cons = []

    def make_pair_fun(i, j):
        def fun(x):
            xi, yi, ai, si = x[4 * i:4 * i + 4]
            xj, yj, aj, sj = x[4 * j:4 * j + 4]
            if si <= 1e-14 or sj <= 1e-14:
                return 1.0
            p1 = _corners(xi, yi, ai, si)
            p2 = _corners(xj, yj, aj, sj)
            # SAT: for each axis, require separation
            best_overlap = 1e9
            for poly in (p1, p2):
                m = len(poly)
                for t in range(m):
                    ax = poly[t][0] - poly[(t + 1) % m][0]
                    ay = poly[t][1] - poly[(t + 1) % m][1]
                    nx, ny = -ay, ax
                    L = math.hypot(nx, ny)
                    if L < 1e-15:
                        continue
                    nx, ny = nx / L, ny / L
                    min1 = min(px * nx + py * ny for px, py in p1)
                    max1 = max(px * nx + py * ny for px, py in p1)
                    min2 = min(px * nx + py * ny for px, py in p2)
                    max2 = max(px * nx + py * ny for px, py in p2)
                    if max1 <= min2 + 1e-9 or max2 <= min1 + 1e-9:
                        return 1.0  # separated on this axis
                    ov = min(max1, max2) - max(min1, min2)
                    if ov < best_overlap:
                        best_overlap = ov
            return -best_overlap  # negative -> constraint >= 0 means ok if ~0
        return fun

    for i in range(n):
        for j in range(i + 1, n):
            f = make_pair_fun(i, j)
            cons.append({'type': 'ineq', 'fun': f})

    # boundary constraints: corners inside [0,1]
    for i in range(n):
        def make_bound(i):
            def fun(x):
                ci = x[4 * i:4 * i + 4]
                cx, cy, a, s = ci
                if s <= 1e-14:
                    return 1.0
                vals = []
                for px, py in _corners(cx, cy, a, s):
                    vals.append(px)
                    vals.append(1 - px)
                    vals.append(py)
                    vals.append(1 - py)
                return min(vals)
            return fun
        cons.append({'type': 'ineq', 'fun': make_bound(i)})

    try:
        res = minimize(objective, x0, method='SLSQP', bounds=bounds, constraints=cons,
                       options={'maxiter': maxiter, 'ftol': 1e-10, 'disp': False})
        x = res.x
    except Exception:
        x = x0

    out = []
    for i in range(n):
        cx, cy, a, s = x[4 * i:4 * i + 4]
        # repair tiny violations by shrinking slightly?
        out.append((cx, cy, a, max(0.0, s)))
    return out


# ---------------------------------------------------------------------------
# random perturbation / restart
# ---------------------------------------------------------------------------

def _repaired(squares):
    """Shrink any square that violates constraints until satisfiable (greedy)."""
    out = [list(s) for s in squares]
    # first clamp centers
    for i in range(len(out)):
        out[i][0] = min(1.0, max(0.0, out[i][0]))
        out[i][1] = min(1.0, max(0.0, out[i][1]))
        out[i][2] = out[i][2] % 1.0
        out[i][3] = max(0.0, min(1.0, out[i][3]))
    # iteratively reduce violating squares
    for _ in range(200):
        changed = False
        n = len(out)
        for i in range(n):
            if out[i][3] <= 1e-15:
                continue
            # boundary
            ok = True
            for px, py in _corners(out[i][0], out[i][1], out[i][2], out[i][3]):
                if px < -1e-12 or px > 1 + 1e-12 or py < -1e-12 or py > 1 + 1e-12:
                    ok = False
                    break
            if not ok:
                out[i][3] *= 0.95
                changed = True
                if out[i][3] < 1e-14:
                    out[i][3] = 0.0
                continue
            for j in range(n):
                if i == j:
                    continue
                if out[j][3] <= 1e-15:
                    continue
                if _overlap_penalty_for_pair(out[i], out[j]) > 1e-11:
                    out[i][3] *= 0.97
                    changed = True
                    if out[i][3] < 1e-14:
                        out[i][3] = 0.0
                    break
        if not changed:
            break
    return [tuple(s) for s in out]


def _random_perturb(squares, scale=0.03):
    out = []
    for (cx, cy, a, s) in squares:
        out.append([cx + random.uniform(-scale, scale),
                    cy + random.uniform(-scale, scale),
                    a + random.uniform(-scale, scale),
                    s])
    return out


# ---------------------------------------------------------------------------
# main solver
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345 + n)

    best_squares = None
    best_score = -1.0

    # candidate initialisations
    starts = []
    # grid-ish
    starts.append(_initial_mixed(n))

    # a few random feasible starts
    for _ in range(3):
        k = max(1, int(math.sqrt(n)))
        s = 0.9 / k
        sq = []
        for i in range(n):
            sq.append([random.uniform(0.1, 0.9),
                       random.uniform(0.1, 0.9),
                       random.uniform(0, 1),
                       s * random.uniform(0.3, 1.0)])
        starts.append(_repaired(sq))

    # initial quick evaluation
    for st in starts:
        st = _repaired(st)
        sc = sum(s for (_, _, _, s) in st)
        if sc > best_score:
            best_score = sc
            best_squares = st

    # optimisation loop
    time_budget_iters = 4
    for it in range(time_budget_iters):
        if it == 0:
            cur = [list(s) for s in best_squares]
        else:
            cur = _random_perturb(best_squares, scale=0.02 + 0.02 * it)
            cur = _repaired(cur)

        # optimize
        optimized = _pack_optimize(cur, maxiter=150 + 50 * it)
        optimized = _repaired(optimized)
        sc = sum(s for (_, _, _, s) in optimized)
        if sc > best_score:
            best_score = sc
            best_squares = optimized

    # final repair and output
    res = _repaired(best_squares)
    # ensure length exactly n
    res = list(res[:n])
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    # clamp everything to [0,1] just in case
    out = []
    for (cx, cy, a, s) in res:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        a = a % 1.0
        s = min(1.0, max(0.0, s))
        out.append((cx, cy, a, s))
    return out
