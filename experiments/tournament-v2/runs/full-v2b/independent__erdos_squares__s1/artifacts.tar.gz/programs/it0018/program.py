import math
import numpy as np
from scipy.optimize import minimize

# ----------------------------- geometry helpers -----------------------------

def square_corners(cx, cy, ang, s):
    """Return 4 corners (x,y) of a square with center (cx,cy), angle fraction of turn,
    and side length s. Corners in CCW order."""
    theta = 2.0 * math.pi * ang
    c, sn = math.cos(theta), math.sin(theta)
    h = 0.5 * s
    # local corners
    local = [(-h, -h), (h, -h), (h, h), (-h, h)]
    pts = []
    for lx, ly in local:
        x = cx + c * lx - sn * ly
        y = cy + sn * lx + c * ly
        pts.append((x, y))
    return pts


def sep_axes(corners):
    """Axes for SAT: normals to the edges of the polygon."""
    axes = []
    m = len(corners)
    for i in range(m):
        x1, y1 = corners[i]
        x2, y2 = corners[(i + 1) % m]
        ex, ey = x2 - x1, y2 - y1
        # normal
        axes.append((-ey, ex))
    return axes


def sat_overlap_interior(c1, c2, eps=1e-9):
    """Return True if interiors of convex polygons overlap (SAT).
    c1, c2 are lists of corner points. Uses strict separation with small tolerance."""
    for poly in (c1, c2):
        for ax in sep_axes(poly):
            axx, axy = ax
            n1 = [axx * p[0] + axy * p[1] for p in c1]
            n2 = [axx * p[0] + axy * p[1] for p in c2]
            if max(n1) <= min(n2) + eps or max(n2) <= min(n1) + eps:
                return False
    return True

# ----------------------------- objective & constraints -----------------------------

def make_problem(n, k):
    """
    Optimize k squares (each has cx, cy, angle, side). Variables: 4k.
    Objective: maximize sum of sides -> minimize negative sum.
    Constraints:
      - box bounds via bounds
      - containment in unit square: all corners in [0,1]^2
      - pairwise non-overlap: SAT
    """
    def unpack(x):
        sq = []
        for i in range(k):
            cx = x[4*i]
            cy = x[4*i+1]
            ang = x[4*i+2] % 1.0
            s = x[4*i+3]
            sq.append((cx, cy, ang, s))
        return sq

    def obj(x):
        return -np.sum(x[3::4])

    def containment_con(x):
        sq = unpack(x)
        cons = []
        for (cx, cy, ang, s) in sq:
            pts = square_corners(cx, cy, ang, s)
            for (px, py) in pts:
                cons.append(px)          # >=0
                cons.append(1.0 - px)    # >=0
                cons.append(py)
                cons.append(1.0 - py)
        return np.array(cons)

    def overlap_con(x):
        sq = unpack(x)
        cs = [square_corners(*sq[i]) for i in range(k)]
        cons = []
        for i in range(k):
            for j in range(i+1, k):
                # SAT margin: for overlap, all separating axes fail. We want at least one axis separating.
                # Compute minimal "gap" needed.
                # For each axis of both polys, compute interval separation.
                best_gap = -1e9
                for poly in (cs[i], cs[j]):
                    for ax in sep_axes(poly):
                        axx, axy = ax
                        n1 = [axx*p[0] + axy*p[1] for p in cs[i]]
                        n2 = [axx*p[0] + axy*p[1] for p in cs[j]]
                        # gap if separated: max(min1) - min(max2) etc.
                        gap = max(0.0, max(min(n1) - max(n2), min(n2) - max(n1)))
                        best_gap = max(best_gap, gap)
                # best_gap <= 0 means overlap -> constraint best_gap >= 0
                cons.append(best_gap)
        return np.array(cons)

    return unpack, obj, containment_con, overlap_con

# ----------------------------- initial guesses -----------------------------

def grid_init(n):
    """Grid layout covering unit square, plus tiny/zero extras."""
    k = math.isqrt(n)
    side = 1.0 / k if k > 0 else 1.0
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i+0.5)*side, (j+0.5)*side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]

def grid_init_k(k):
    side = 1.0 / k
    return [((i+0.5)*side, (j+0.5)*side, 0.0, side) for i in range(k) for j in range(k)]

def random_init_k(k, rng):
    side = 1.0 / k
    squares = []
    for _ in range(k):
        cx = rng.uniform(side/2, 1 - side/2)
        cy = rng.uniform(side/2, 1 - side/2)
        ang = rng.uniform(0, 1)
        s = side
        squares.append((cx, cy, ang, s))
    return squares

# ----------------------------- single optimization -----------------------------

def optimize_k(k, x0, maxiter=200):
    unpack, obj, containment_con, overlap_con = make_problem(k, k)
    # variable bounds: cx,cy in [0,1], angle in [0,1), side in [0,1]
    bounds = []
    for _ in range(k):
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
    cons = [
        {'type': 'ineq', 'fun': containment_con},
        {'type': 'ineq', 'fun': overlap_con},
    ]
    res = minimize(obj, x0, method='SLSQP', bounds=bounds, constraints=cons,
                   options={'maxiter': maxiter, 'ftol': 1e-9})
    # sanitize
    x = res.x
    sq = []
    for i in range(k):
        cx = min(1.0, max(0.0, x[4*i]))
        cy = min(1.0, max(0.0, x[4*i+1]))
        ang = x[4*i+2] % 1.0
        s = min(1.0, max(0.0, x[4*i+3]))
        sq.append((cx, cy, ang, s))
    return -res.fun if np.isfinite(res.fun) else sum(s[3] for s in sq), sq

# ----------------------------- main solver -----------------------------

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n <= 4:
        # best for small n: one big square plus tiny ones in corners? Actually 2x2 grid gives 2
        # For n=2: two 0.5-side squares give 1.0; can do better with rotated? maybe ~1.06?
        # Use optimization with k=n
        pass

    import random
    rng = random.Random(12345)
    best_total = -1.0
    best_sq = None

    # Try k = n down to 1: maximize sum of k squares, rest are zero-size.
    # For speed, focus on k values near useful bounds.
    # heuristic: total ~ sqrt(n) * something, so k close to n is wasteful unless many small squares.
    # We'll try a range of k: from n down to max(1, int(0.3*n)), but that's many optimizations.
    # Better: start from k_max = n and go down, stop when improvement stalls.

    # For very large n, grid is near-optimal; refinement on many squares is expensive.
    # Strategy:
    # 1. If n large (>60), start grid and do a few local refinement passes.
    # 2. Else, try multiple k and initializations.

    if n > 80:
        # Use grid with k = isqrt(n), then fill remaining with small squares in gaps.
        sq = grid_init(n)
        # simple improvement: try to enlarge squares via iterative scaling/repair? skip; just return grid
        return sq

    # Candidate k values: prioritize near isqrt(n) up to n, but limited count.
    k_candidates = set()
    # heuristic: k from 1..n, but sample intelligently
    # include n, n-1, ..., max(1, n-10), and around isqrt(n)
    k0 = math.isqrt(n)
    for k in range(max(1, k0-2), min(n, k0+15)+1):
        k_candidates.add(k)
    for k in range(max(1, n-5), n+1):
        k_candidates.add(k)
    # also some intermediate
    for k in [int(n**0.5), int(n*0.7), int(n*0.85)]:
        if 1 <= k <= n:
            k_candidates.add(k)

    k_list = sorted(k_candidates, reverse=True)

    for k in k_list:
        # initial guesses
        inits = []
        if k == k0:
            inits.append(grid_init_k(k))
        # random restarts
        n_rand = 3 if k <= 30 else 1
        for _ in range(n_rand):
            inits.append(random_init_k(k, rng))
        # also seed from best previous solution if sizes match? skip

        for x0sq in inits:
            x0 = []
            for (cx, cy, ang, s) in x0sq:
                x0.extend([cx, cy, ang, s])
            x0 = np.array(x0)
            if len(x0) != 4*k:
                continue
            try:
                total, sq = optimize_k(k, x0, maxiter=150 if k <= 30 else 50)
            except Exception:
                continue
            # build full solution: k optimized + (n-k) zero squares
            full = sq + [(0.5, 0.5, 0.0, 0.0)] * (n - k)
            full = full[:n]
            if total > best_total + 1e-9:
                best_total = total
                best_sq = full

    if best_sq is None:
        best_sq = grid_init(n)

    # final polish: if we have non-degenerate squares, try re-optimizing all n with
    # tiny sides allowed, using best as start. Only for moderate n.
    if n <= 40:
        x0 = []
        for (cx, cy, ang, s) in best_sq:
            x0.extend([cx, cy, ang, s])
        x0 = np.array(x0)
        try:
            total, sq = optimize_k(n, x0, maxiter=100)
            full = sq
            if total > best_total + 1e-9:
                best_total = total
                best_sq = full
        except Exception:
            pass

    return best_sq
