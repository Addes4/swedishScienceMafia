import math
import random
import time

def solve(n):
    random.seed(12345 + n)
    end_time = time.time() + 55.0

    # ---- initial guesses ----
    def grid(k, n):
        side = 1.0 / k
        sqs = []
        for i in range(k):
            for j in range(k):
                sqs.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
        while len(sqs) < n:
            sqs.append([0.5, 0.5, 0.0, 0.0])
        return sqs[:n]

    # simple rows/cols arrangement allowing leftover as zero-size
    def grid_best(n):
        best = None
        best_score = -1.0
        for k in range(1, int(math.sqrt(n)) + 2):
            if k * k > n:
                # allow partial last row
                rows = (n + k - 1) // k
                if rows == 0:
                    continue
                # squares of size 1/k, placed in k-column grid, last row may be fewer
                side = 1.0 / k
                sqs = []
                for idx in range(n):
                    i = idx % k
                    j = idx // k
                    if j >= rows:
                        break
                    sqs.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
                if len(sqs) < n:
                    # fill with tiny squares in gaps? just zeros
                    while len(sqs) < n:
                        sqs.append([0.5, 0.5, 0.0, 0.0])
                score = sum(s[3] for s in sqs)
                if score > best_score:
                    best_score = score
                    best = sqs
            else:
                score = k * (1.0 / k)  # =1
                if score > best_score:
                    best_score = score
                    best = grid(k, n)
        if best is None:
            best = grid(1, n)
        return best

    def initial_greedy(n):
        # Try a greedy square placement: largest possible squares
        # Simple heuristic: put one large square, then pack others in remaining L-shape
        if n == 1:
            return [[0.5, 0.5, 0.0, 1.0]]
        # If n is perfect square, grid is optimal
        k = int(round(math.sqrt(n)))
        if k * k == n:
            return grid(k, n)
        best = grid_best(n)
        # Try one big square + rest in the L-shaped region
        # big square side b
        for b in [0.5, 0.45, 0.4, 0.55, 0.6, 0.7, 0.8, 0.9]:
            if b >= 1.0:
                continue
            m = n - 1
            if m <= 0:
                continue
            # pack m squares in the L-shape: right strip width (1-b) height 1, top strip width b height (1-b)
            # approximate by packing in right strip with grid
            best_local = None
            best_score = -1
            # Try placing m squares in right strip using grid
            w = 1.0 - b
            h = 1.0
            if w > 1e-9 and m > 0:
                # grid in right strip
                # find k x k grid with k^2 <= m and k*w fits? Actually side s = min(w/k1, h/k2) etc.
                # simpler: use a grid of size 1/k in right strip
                for k1 in range(1, m + 1):
                    if k1 * k1 > m:
                        break
                    s = min(w / k1, h / k1)
                    if s <= 0:
                        continue
                    cnt = 0
                    sqs = [[b / 2, 0.5, 0.0, b]]
                    for i in range(k1):
                        for j in range(k1):
                            if cnt >= m:
                                break
                            cx = b + (i + 0.5) * s
                            cy = (j + 0.5) * s
                            if cx + s / 2 <= 1.0 + 1e-9 and cy + s / 2 <= 1.0 + 1e-9:
                                sqs.append([cx, cy, 0.0, s])
                                cnt += 1
                        if cnt >= m:
                            break
                    while len(sqs) < n:
                        sqs.append([0.5, 0.5, 0.0, 0.0])
                    score = sum(x[3] for x in sqs)
                    if score > best_score:
                        best_score = score
                        best_local = sqs
            if best_local and best_score > sum(s[3] for s in best):
                best = best_local
        return best

    squares = initial_greedy(n)

    # ---- local optimization ----
    # We'll use a simple stochastic hill climbing with feasibility repair
    def is_feasible(sqs, eps=1e-7):
        # Check centers in [0,1] and squares fit inside
        # We'll check pairwise separation using SAT (separating axis theorem)
        for x, y, ang, s in sqs:
            if s <= 0:
                continue
            if x < 0 or x > 1 or y < 0 or y > 1:
                return False
            # half-diagonal
            h = s * math.sqrt(2) / 2
            if x - h < -eps or x + h > 1 + eps or y - h < -eps or y + h > 1 + eps:
                return False
        m = len(sqs)
        for i in range(m):
            xi, yi, ai, si = sqs[i]
            if si <= 0:
                continue
            for j in range(i + 1, m):
                xj, yj, aj, sj = sqs[j]
                if sj <= 0:
                    continue
                if not disjoint_squares(xi, yi, ai, si, xj, yj, aj, sj, eps):
                    return False
        return True

    def disjoint_squares(x1, y1, a1, s1, x2, y2, a2, s2, eps=1e-7):
        # returns True if interiors don't overlap (allow touching)
        # Use SAT with 4 axes (2 per square)
        axes = []
        for ang in (a1, a2):
            theta = ang * 2 * math.pi
            axes.append((math.cos(theta), math.sin(theta)))
            axes.append((-math.sin(theta), math.cos(theta)))
        # also axes along difference vector? Not needed for OBBs, axes are enough
        for ax, ay in axes:
            # project both squares
            proj1 = project_square(x1, y1, a1, s1, ax, ay)
            proj2 = project_square(x2, y2, a2, s2, ax, ay)
            if proj1[1] <= proj2[0] + eps or proj2[1] <= proj1[0] + eps:
                return True  # separated on this axis
        return False  # overlap on all axes

    def project_square(x, y, ang, s, ax, ay):
        theta = ang * 2 * math.pi
        c, sn = math.cos(theta), math.sin(theta)
        hs = s / 2
        corners = [(hs, hs), (-hs, hs), (-hs, -hs), (hs, -hs)]
        minp = float('inf')
        maxp = -float('inf')
        for cx, cy in corners:
            # rotate corner by theta
            rx = cx * c - cy * sn
            ry = cx * sn + cy * c
            px = (x + rx) * ax + (y + ry) * ay
            if px < minp: minp = px
            if px > maxp: maxp = px
        return minp, maxp

    def score(sqs):
        return sum(s[3] for s in sqs)

    def repair_centers(sqs):
        # clamp to valid bounding
        for i in range(len(sqs)):
            x, y, ang, s = sqs[i]
            if s <= 0:
                sqs[i] = [0.5, 0.5, 0.0, 0.0]
                continue
            h = s * math.sqrt(2) / 2
            x = min(max(x, h), 1 - h)
            y = min(max(y, h), 1 - h)
            sqs[i] = [x, y, ang, s]

    best_sqs = [list(s) for s in squares]
    best_score = score(best_sqs)

    # Try to improve by random moves: adjust centers, sizes, angles
    scale = 0.02
    cur = [list(s) for s in best_sqs]
    cur_score = best_score

    if n <= 4:
        # small n, we can do finer search
        scale = 0.005

    it = 0
    while time.time() < end_time:
        it += 1
        # random move: pick a square, perturb center, angle, size
        cand = [list(s) for s in cur]
        idx = random.randrange(n)
        x, y, ang, s = cand[idx]
        # perturb
        dx = random.gauss(0, scale)
        dy = random.gauss(0, scale)
        dang = random.gauss(0, scale)
        ds = random.gauss(0, scale * 0.5)
        x += dx
        y += dy
        ang = (ang + dang) % 1.0
        s = max(0.0, s + ds)
        # clamp size to fit in unit square
        if s > 1.0:
            s = 1.0
        # ensure center valid
        h = s * math.sqrt(2) / 2
        x = min(max(x, h), 1 - h)
        y = min(max(y, h), 1 - h)
        cand[idx] = [x, y, ang, s]

        # maybe perturb another square size
        if random.random() < 0.3 and n > 1:
            jdx = random.randrange(n)
            if jdx != idx:
                xj, yj, aj, sj = cand[jdx]
                sj = max(0.0, sj + random.gauss(0, scale * 0.5))
                if sj > 1.0:
                    sj = 1.0
                hj = sj * math.sqrt(2) / 2
                xj = min(max(xj, hj), 1 - hj)
                yj = min(max(yj, hj), 1 - hj)
                cand[jdx] = [xj, yj, aj, sj]

        # repair centers
        repair_centers(cand)

        # check feasibility
        if is_feasible(cand):
            new_score = score(cand)
            if new_score > cur_score or random.random() < 0.01:
                cur = cand
                cur_score = new_score
                if new_score > best_score:
                    best_score = new_score
                    best_sqs = [list(s) for s in cand]
        else:
            # try shrinking to resolve overlap
            # simple: reduce sizes of overlapping squares slightly
            for _ in range(10):
                # find overlap
                ok = True
                for i in range(n):
                    xi, yi, ai, si = cand[i]
                    if si <= 0:
                        continue
                    for j in range(i + 1, n):
                        xj, yj, aj, sj = cand[j]
                        if sj <= 0:
                            continue
                        if not disjoint_squares(xi, yi, ai, si, xj, yj, aj, sj, 1e-7):
                            # reduce both slightly
                            si2 = si * 0.99
                            sj2 = sj * 0.99
                            # adjust centers to fit
                            h = si2 * math.sqrt(2) / 2
                            xi = min(max(xi, h), 1 - h)
                            yi = min(max(yi, h), 1 - h)
                            h = sj2 * math.sqrt(2) / 2
                            xj = min(max(xj, h), 1 - h)
                            yj = min(max(yj, h), 1 - h)
                            cand[i] = [xi, yi, ai, si2]
                            cand[j] = [xj, yj, aj, sj2]
                            ok = False
                if ok:
                    break
            repair_centers(cand)
            if is_feasible(cand):
                new_score = score(cand)
                if new_score > cur_score or random.random() < 0.01:
                    cur = cand
                    cur_score = new_score
                    if new_score > best_score:
                        best_score = new_score
                        best_sqs = [list(s) for s in cand]

        # adaptive scale
        if it % 1000 == 0:
            if best_score > cur_score * 0.999:
                scale = min(0.05, scale * 1.05)
            else:
                scale = max(0.001, scale * 0.95)

    # final: return best
    return [(s[0], s[1], s[2], s[3]) for s in best_sqs]
