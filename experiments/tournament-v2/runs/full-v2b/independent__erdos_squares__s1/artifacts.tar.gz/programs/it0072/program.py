import math

EPS = 1e-12


def _corners(cx, cy, ang, s):
    """Return the 4 corners (ccw) of a square centre (cx,cy), angle in turns, side s."""
    h = 0.5 * s
    t = 2.0 * math.pi * ang
    c, si = math.cos(t), math.sin(t)
    return (
        (cx + c * h - si * h, cy + si * h + c * h),
        (cx - c * h - si * h, cy - si * h + c * h),
        (cx - c * h + si * h, cy - si * h - c * h),
        (cx + c * h + si * h, cy + si * h - c * h),
    )


def _axes(poly):
    """Normal axes of the polygon edges (unit normals), for SAT."""
    n = len(poly)
    ax = []
    for i in range(n):
        x0, y0 = poly[i]
        x1, y1 = poly[(i + 1) % n]
        ex, ey = x1 - x0, y1 - y0
        L = math.hypot(ex, ey)
        if L < 1e-15:
            continue
        ax.append((-ey / L, ex / L))
    return ax


def _overlap(polyA, polyB):
    """True if the interiors of the two convex polygons overlap (SAT)."""
    for poly, other in ((polyA, polyB), (polyB, polyA)):
        for nx, ny in _axes(poly):
            pa = [nx * x + ny * y for x, y in poly]
            pb = [nx * x + ny * y for x, y in other]
            if min(pa) >= max(pb) - EPS or min(pb) >= max(pa) - EPS:
                # separating axis; touching along it means no interior overlap
                return False
    return True


def _inside(corners, s):
    for x, y in corners:
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


def _max_scale(placements):
    """placements: list of (cx,cy,ang,s). Return max factor f so all squares
    scaled about their own centres stay inside the unit square and disjoint."""
    # radius of each square from its centre (half diagonal) is s*sqrt(2)/2.
    # To stay inside [0,1]^2 after scaling by f, need for each square:
    #   cx - f * R <= 0  and cx + f*R <= 1  etc, where R depends on angle.
    # Easier: binary search on f and test geometry exactly.
    def ok(f):
        polys = []
        for cx, cy, ang, s in placements:
            if s * f <= 0:
                continue
            poly = _corners(cx, cy, ang, s * f)
            if not _inside(poly, s * f):
                return False
            polys.append(poly)
        m = len(polys)
        for i in range(m):
            for j in range(i + 1, m):
                if _overlap(polys[i], polys[j]):
                    return False
        return True

    lo, hi = 0.0, 1.0
    # find a feasible upper bracket quickly
    while ok(hi) and hi < 1e6:
        lo = hi
        hi *= 2.0
    if hi >= 1e6:
        return lo
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if ok(mid):
            lo = mid
        else:
            hi = mid
    return lo


def _spiral_candidates(count):
    """Generate candidate (cx, cy, ang) tuples covering the unit square,
    sorted roughly by desirability (larger squares first go central)."""
    cands = []
    angles = [0.0, 0.25]
    # golden-angle spiral over the unit square, multiple offsets
    ga = math.pi * (3.0 - math.sqrt(5.0))
    for i in range(count):
        r = math.sqrt((i + 0.5) / count)
        theta = i * ga
        cx = 0.5 + 0.5 * r * math.cos(theta)
        cy = 0.5 + 0.5 * r * math.sin(theta)
        for ang in angles:
            cands.append((cx, cy, ang))
    # add grid-based candidates too
    g = max(2, int(math.sqrt(count)))
    for i in range(g):
        for j in range(g):
            cx = (i + 0.5) / g
            cy = (j + 0.5) / g
            for ang in angles:
                cands.append((cx, cy, ang))
    # dedupe
    seen = set()
    out = []
    for c in cands:
        key = (round(c[0], 9), round(c[1], 9), round(c[2], 9))
        if key not in seen:
            seen.add(key)
            out.append(c)
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Candidate positions in priority order.
    cands = _spiral_candidates(max(4 * n, 64))

    # Greedy: place squares one at a time at the candidate that allows the
    # largest side, given fixed side = 1 reference, then rescale globally.
    placements = []  # (cx,cy,ang,s) with s as fraction (start from 1.0 attempts)

    # We greedily choose positions; the side of each new square is decided so it
    # just fits against existing squares in a scaled-down search. Simpler robust
    # approach: pick each square at the candidate maximising its "room" measured
    # by a shrink test.  We'll assign tentative s=1 then shrink via global scale.
    taken = []
    polys = []

    for k in range(n):
        best = None
        best_score = -1.0
        for (cx, cy, ang) in cands:
            poly = _corners(cx, cy, ang, 1.0)
            if not _inside(poly, 1.0):
                continue
            # score: smallest distance to any existing polygon / boundary,
            # approximated by testing shrink: find max s fit at this spot.
            pos = (cx, cy, ang, 1.0)
            score = _local_fit(cx, cy, ang, polys)
            if score > best_score:
                best_score = score
                best = pos
            if best_score >= 0.999999:
                break
        if best is None:
            # fallback: place tiny square at a free-ish spot
            best = (0.5, 0.5, 0.0, 0.0)
            placements.append(best)
            continue
        placements.append(best)
        polys.append(_corners(best[0], best[1], best[2], 1.0))

    # Global rescale to make all disjoint and inside.
    f = _max_scale(placements)
    # also consider scaling further if there is slack: try slightly larger.
    res = []
    for cx, cy, ang, s in placements:
        # re-optimise centre a touch: pull toward free space is complex; keep.
        res.append([cx, cy, ang, s * f])

    # After global scaling, many squares may have different absolute sizes if we
    # want them all equal?  Requirement only needs disjointness; equal scale is
    # sum-optimal for a given packing pattern when all sides equal.
    # Improve: binary-search a uniform side length for the whole pattern:
    # treat each square's *relative* size as 1 (they're all 1 now), so the uniform
    # side is exactly f.  Done.

    # Local refinement: for each square, try to grow it individually without
    # breaking disjointness (increases sum).
    _refine(res, polys)

    out = []
    for cx, cy, ang, s in res:
        # clamp into [0,1]
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = min(1.0, max(0.0, ang)) % 1.0
        s = min(1.0, max(0.0, s))
        out.append((cx, cy, ang, s))
    # zero-size for the remainder if greedy failed to place n
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _local_fit(cx, cy, ang, polys):
    """Maximum uniform side s such that square at (cx,cy,ang) fits inside unit
    square and doesn't overlap existing polygons (each polygon is side-1 square)."""
    def ok(s):
        if s <= 0:
            return True
        poly = _corners(cx, cy, ang, s)
        if not _inside(poly, s):
            return False
        for p in polys:
            if _overlap(poly, p):
                return False
        return True

    lo, hi = 0.0, 1.0
    if not ok(hi):
        for _ in range(40):
            mid = 0.5 * (lo + hi)
            if ok(mid):
                lo = mid
            else:
                hi = mid
        return lo
    # can go bigger than 1? bound by unit square
    return hi


def _refine(res, polys):
    """Try to increase each square's side greedily."""
    n = len(res)
    for _ in range(3):
        improved = False
        for i in range(n):
            cx, cy, ang, s = res[i]
            others = [_corners(res[j][0], res[j][1], res[j][2], res[j][3])
                      for j in range(n) if j != i]

            def ok(ss):
                poly = _corners(cx, cy, ang, ss)
                if not _inside(poly, ss):
                    return False
                for p in others:
                    if _overlap(poly, p):
                        return False
                return True

            lo, hi = s, min(1.0, s + 1.0)
            if ok(hi):
                res[i][3] = hi
                improved = True
                continue
            for _ in range(40):
                mid = 0.5 * (lo + hi)
                if ok(mid):
                    lo = mid
                else:
                    hi = mid
            if lo > s + 1e-12:
                res[i][3] = lo
                improved = True
        if not improved:
            break
