import math
import random
import time

TIME_LIMIT = 55.0

class Square:
    __slots__ = ('x', 'y', 'a', 's', 'c', 'sn')
    def __init__(self, x, y, a, s):
        self.x = x
        self.y = y
        self.a = a
        self.s = s
        self.c = math.cos(a * 2 * math.pi)
        self.sn = math.sin(a * 2 * math.pi)

def corners(sq):
    h = sq.s * 0.5
    c = sq.c * h
    sn = sq.sn * h
    # corners (x,y) rotated by angle plus center
    x, y = sq.x, sq.y
    return ((x - c + sn, y - sn - c), (x + c + sn, y + sn - c),
            (x + c - sn, y + sn + c), (x - c - sn, y - sn + c))

def sep_axis(poly1, poly2, axis):
    # axis is (nx, ny) not normalized; project
    ax, ay = axis
    min1 = min(p[0]*ax + p[1]*ay for p in poly1)
    max1 = max(p[0]*ax + p[1]*ay for p in poly1)
    min2 = min(p[0]*ax + p[1]*ay for p in poly2)
    max2 = max(p[0]*ax + p[1]*ay for p in poly2)
    return max1 - min2, max2 - min1

def overlap_amount(sq1, sq2):
    """Return penetration depth (positive if overlapping), or 0 if separated."""
    p1 = corners(sq1)
    p2 = corners(sq2)
    axes = []
    for i in range(4):
        x1, y1 = p1[i]
        x2, y2 = p1[(i+1)%4]
        axes.append((y2 - y1, x1 - x2))
    for i in range(4):
        x1, y1 = p2[i]
        x2, y2 = p2[(i+1)%4]
        axes.append((y2 - y1, x1 - x2))
    min_overlap = float('inf')
    best_axis = None
    for ax, ay in axes:
        if ax == 0 and ay == 0:
            continue
        d1, d2 = sep_axis(p1, p2, (ax, ay))
        if d1 <= 0 or d2 <= 0:
            return 0.0, None
        ov = min(d1, d2)
        if ov < min_overlap:
            min_overlap = ov
            best_axis = (ax, ay)
    return min_overlap, best_axis

def overlaps_wall(sq):
    c = corners(sq)
    minx = min(p[0] for p in c)
    maxx = max(p[0] for p in c)
    miny = min(p[1] for p in c)
    maxy = max(p[1] for p in c)
    return minx, maxx, miny, maxy

def score(squares):
    return sum(sq.s for sq in squares)

def resolve(squares, iters=80, allow_shrink=True):
    n = len(squares)
    for it in range(iters):
        moved = False
        for i in range(n):
            si = squares[i]
            if si.s <= 0:
                continue
            ci = corners(si)
            minx = min(p[0] for p in ci)
            maxx = max(p[0] for p in ci)
            miny = min(p[1] for p in ci)
            maxy = max(p[1] for p in ci)
            fx = fy = 0.0
            # wall constraints
            if minx < 0:
                fx += -minx * 1.5
            if maxx > 1:
                fx -= (maxx - 1) * 1.5
            if miny < 0:
                fy += -miny * 1.5
            if maxy > 1:
                fy -= (maxy - 1) * 1.5
            # overlaps
            for j in range(i+1, n):
                sj = squares[j]
                if sj.s <= 0:
                    continue
                ov, axis = overlap_amount(si, sj)
                if ov > 0:
                    # move both apart
                    ax, ay = axis
                    ax2 = ax * (si.x - sj.x) + ay * (si.y - sj.y)
                    if ax2 < 0:
                        ax = -ax
                        ay = -ay
                    norm = math.hypot(ax, ay)
                    if norm > 0:
                        ax /= norm
                        ay /= norm
                    push = ov * 0.5 + 0.001
                    fx += ax * push
                    fy += ay * push
                    sj.x -= ax * push * 0.5
                    sj.y -= ay * push * 0.5
                    moved = True
            if fx != 0 or fy != 0:
                si.x += fx * 0.3
                si.y += fy * 0.3
                moved = True
        if not moved:
            break
    # clamp
    for sq in squares:
        if sq.s <= 0:
            continue
        c = corners(sq)
        minx = min(p[0] for p in c)
        maxx = max(p[0] for p in c)
        miny = min(p[1] for p in c)
        maxy = max(p[1] for p in c)
        if minx < 0:
            sq.x += -minx
        if maxx > 1:
            sq.x -= maxx - 1
        if miny < 0:
            sq.y += -miny
        if maxy > 1:
            sq.y -= maxy - 1

def try_expand(squares, factor=1.01):
    # try to expand each square uniformly
    for sq in squares:
        if sq.s <= 0:
            continue
        old = sq.s
        sq.s *= factor
        c = corners(sq)
        minx = min(p[0] for p in c)
        maxx = max(p[0] for p in c)
        miny = min(p[1] for p in c)
        maxy = max(p[1] for p in c)
        if minx < -1e-9 or maxx > 1 + 1e-9 or miny < -1e-9 or maxy > 1 + 1e-9:
            sq.s = old
            continue
        ok = True
        for other in squares:
            if other is sq or other.s <= 0:
                continue
            ov, _ = overlap_amount(sq, other)
            if ov > 1e-10:
                ok = False
                break
        if not ok:
            sq.s = old

def initial_grid(n):
    k = int(math.ceil(math.sqrt(n)))
    s = 1.0 / k
    squares = []
    cnt = 0
    for i in range(k):
        for j in range(k):
            if cnt >= n:
                break
            squares.append(Square((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
            cnt += 1
        if cnt >= n:
            break
    while len(squares) < n:
        squares.append(Square(0.5, 0.5, 0.0, 0.0))
    return squares

def optimize(n, time_limit):
    start_time = time.time()
    best_squares = None
    best_score = -1

    # try several starting configurations
    starts = []
    if n <= 25:
        starts.append(initial_grid(n))
    # random starts
    num_random = 8
    for _ in range(num_random):
        sqs = []
        for _ in range(n):
            x = random.uniform(0.05, 0.95)
            y = random.uniform(0.05, 0.95)
            a = random.choice([0.0, 0.25, 0.125, 0.375, 0.5])
            s = random.uniform(0.01, 0.15)
            sqs.append(Square(x, y, a, s))
        starts.append(sqs)

    for start_idx, squares in enumerate(starts):
        if time.time() - start_time > time_limit * 0.9:
            break
        # resolve first
        for _ in range(3):
            resolve(squares, iters=60)
            try_expand(squares, 1.05)
        resolve(squares, iters=60)
        # clamp
        for sq in squares:
            if sq.s > 0:
                c = corners(sq)
                minx = min(p[0] for p in c)
                maxx = max(p[0] for p in c)
                miny = min(p[1] for p in c)
                maxy = max(p[1] for p in c)
                if minx < 0: sq.x -= minx
                if maxx > 1: sq.x -= maxx - 1
                if miny < 0: sq.y -= miny
                if maxy > 1: sq.y -= maxy - 1

        cur_score = score(squares)
        # local search
        temp = 0.02
        for step in range(4000):
            if time.time() - start_time > time_limit * 0.95:
                break
            improvement = False
            # perturb one or two squares
            for _ in range(2):
                idx = random.randrange(n)
                sq = squares[idx]
                old_x, old_y, old_a, old_s = sq.x, sq.y, sq.a, sq.s
                # random move
                sq.x += random.gauss(0, temp)
                sq.y += random.gauss(0, temp)
                if random.random() < 0.3:
                    sq.a += random.gauss(0, 0.05)
                if random.random() < 0.2:
                    sq.s += random.gauss(0, temp * 0.3)
                    if sq.s < 0: sq.s = 0
                # clamp position
                c = corners(sq)
                minx = min(p[0] for p in c)
                maxx = max(p[0] for p in c)
                miny = min(p[1] for p in c)
                maxy = max(p[1] for p in c)
                if minx < 0: sq.x -= minx
                if maxx > 1: sq.x -= maxx - 1
                if miny < 0: sq.y -= miny
                if maxy > 1: sq.y -= maxy - 1
                # check overlaps
                ok = True
                for j in range(n):
                    if j == idx or squares[j].s <= 0:
                        continue
                    ov, _ = overlap_amount(sq, squares[j])
                    if ov > 1e-8:
                        ok = False
                        break
                if not ok:
                    sq.x, sq.y, sq.a, sq.s = old_x, old_y, old_a, old_s
                else:
                    improvement = True
            # try to expand all squares slightly
            try_expand(squares, 1.008)
            new_score = score(squares)
            if new_score > cur_score + 1e-9:
                cur_score = new_score
                temp *= 0.999
            else:
                temp *= 0.997
            temp = max(temp, 0.002)

        # final resolve and expand
        for _ in range(5):
            resolve(squares, iters=40)
            try_expand(squares, 1.02)
        resolve(squares, iters=40)
        # clamp
        for sq in squares:
            if sq.s <= 0: continue
            c = corners(sq)
            minx = min(p[0] for p in c)
            maxx = max(p[0] for p in c)
            miny = min(p[1] for p in c)
            maxy = max(p[1] for p in c)
            if minx < 0: sq.x -= minx
            if maxx > 1: sq.x -= maxx - 1
            if miny < 0: sq.y -= miny
            if maxy > 1: sq.y -= maxy - 1

        sc = score(squares)
        if sc > best_score:
            best_score = sc
            best_squares = [Square(sq.x, sq.y, sq.a, sq.s) for sq in squares]

    if best_squares is None:
        best_squares = initial_grid(n)

    result = []
    for sq in best_squares:
        result.append((sq.x, sq.y, sq.a % 1.0, max(0.0, sq.s)))
    return result[:n]


def solve(n):
    if n <= 0:
        return []
    # special cases
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # best known: three squares can sum to 1.5? Actually two halves and one? 
        # We'll use optimization
        pass
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    try:
        return optimize(n, TIME_LIMIT)
    except Exception:
        # fallback baseline
        k = math.isqrt(n)
        side = 1.0 / k
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        return squares[:n]
