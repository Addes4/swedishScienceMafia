import math
import random
from functools import lru_cache

try:
    import numpy as np
    from scipy.optimize import minimize
    HAVE_SCIPY = True
except Exception:
    HAVE_SCIPY = False


EPS = 1e-12


def _isqrt(n):
    return int(math.isqrt(max(0, int(n))))


def _overlap_ok(a, b):
    x1, y1, t1, s1 = a
    x2, y2, t2, s2 = b
    if s1 <= 1e-14 or s2 <= 1e-14:
        return True
    # SAT for two rotated rectangles (squares)
    def pts(x, y, ang, s):
        c = math.cos(2 * math.pi * ang)
        sn = math.sin(2 * math.pi * ang)
        h = s * 0.5
        return [
            (x + c * h - sn * h, y + sn * h + c * h),
            (x + c * h + sn * h, y + sn * h - c * h),
            (x - c * h + sn * h, y - sn * h - c * h),
            (x - c * h - sn * h, y - sn * h + c * h),
        ]

    def axes(p):
        res = []
        for i in range(4):
            x1, y1 = p[i]
            x2, y2 = p[(i + 1) % 4]
            dx, dy = x2 - x1, y2 - y1
            l = math.hypot(dx, dy)
            if l > 1e-14:
                res.append((-dy / l, dx / l))
        return res

    p1 = pts(x1, y1, t1, s1)
    p2 = pts(x2, y2, t2, s2)
    for ax in axes(p1) + axes(p2):
        axx, axy = ax
        mn1 = min(axx * px + axy * py for px, py in p1)
        mx1 = max(axx * px + axy * py for px, py in p1)
        mn2 = min(axx * px + axy * py for px, py in p2)
        mx2 = max(axx * px + axy * py for px, py in p2)
        if mx1 <= mn2 + 1e-10 or mx2 <= mn1 + 1e-10:
            return True
    return False


def _valid(squares, tol=1e-9):
    n = len(squares)
    for i in range(n):
        x, y, t, s = squares[i]
        if s < -tol:
            return False
        if x < -tol or x > 1 + tol or y < -tol or y > 1 + tol:
            return False
        if s > 0:
            h = s * 0.5
            cs = abs(math.cos(2 * math.pi * t))
            sn = abs(math.sin(2 * math.pi * t))
            # bounding box half-extent
            ex = h * (cs + sn)
            ey = h * (cs + sn)
            if x - ex < -tol or x + ex > 1 + tol or y - ey < -tol or y + ey > 1 + tol:
                return False
    for i in range(n):
        for j in range(i + 1, n):
            if not _overlap_ok(squares[i], squares[j]):
                return False
    return True


def _score(squares):
    return sum(max(0.0, s[3]) for s in squares)


def _clip_square(x, y, t, s):
    # clamp centre and side to fit unit square bounding box
    s = max(0.0, min(1.0, s))
    c = abs(math.cos(2 * math.pi * t))
    sn = abs(math.sin(2 * math.pi * t))
    k = c + sn
    if k > 1e-14:
        s = min(s, 1.0 / k)
    hx = s * 0.5 * k
    hy = hx
    x = min(1.0 - hx, max(hx, x))
    y = min(1.0 - hy, max(hy, y))
    return (x, y, t, s)


def _grid(n):
    k = _isqrt(n)
    if k <= 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


# ---------- exact/simple small layouts ----------

def _layout_1():
    return [(0.5, 0.5, 0.0, 1.0)]


def _layout_2():
    s = 0.5
    return [(0.25, 0.5, 0.0, s), (0.75, 0.5, 0.0, s)]


def _layout_3():
    # two stacked left, one large right
    # column widths a and b, heights: left squares side a, right square side 1-a
    # b determined by remaining width: b = 1 - a
    # right square side min(1-a, 1) = 1-a, but must fit height too
    # choose a = 0.5 gives two 0.5 left and one 0.5 right? actually 4 equal
    # better: 3 squares: one large, two small. approximate optimum by 0.5,0.5? use known good
    a = 0.5
    b = 0.5
    # left top and bottom squares side a=0.5, right one side 0.5
    return [
        (0.25, 0.25, 0.0, 0.5),
        (0.25, 0.75, 0.0, 0.5),
        (0.75, 0.5, 0.0, 0.5),
    ]


def _layout_4():
    s = 0.5
    return [
        (0.25, 0.25, 0.0, s),
        (0.75, 0.25, 0.0, s),
        (0.25, 0.75, 0.0, s),
        (0.75, 0.75, 0.0, s),
    ]


def _layout_5():
    # 2x2 grid plus one in remaining? use 5 by one big and four small?
    # A common efficient: one large square in a corner + row of small
    # Use numerical-ish: large 0.6, four 0.2 around? let's do recursive split
    return _recursive_split(5)


def _layout_6():
    return _recursive_split(6)


def _layout_7():
    return _recursive_split(7)


def _layout_8():
    return _recursive_split(8)


def _layout_9():
    return _recursive_split(9)


def _layout_10():
    return _recursive_split(10)


# ---------- recursive splitting heuristic ----------

def _split_rect(x, y, w, h, parts):
    """Return list of squares packing 'parts' squares into rectangle at x,y,w,h.
    Approximate by splitting rectangle recursively."""
    if parts <= 0:
        return []
    if parts == 1:
        s = min(w, h)
        return [(x + w * 0.5, y + h * 0.5, 0.0, s)]
    # choose split direction to keep near-square pieces
    if w >= h:
        # vertical split
        # target pieces proportional to width
        left_parts = max(1, min(parts - 1, int(round(parts * w / (w + h)))))
        if left_parts == 0:
            left_parts = 1
        if left_parts >= parts:
            left_parts = parts - 1
        # solve widths so resulting square sides equal-ish
        # use simple ratio
        f = left_parts / parts
        # iterate to balance side lengths
        for _ in range(20):
            wl = w * f
            wr = w - wl
            sl = min(wl, h)
            sr = min(wr, h)
            # want pieces count proportional? adjust f
            # heuristic: equal side lengths
            if sl > sr + 1e-12:
                f *= 0.99
            else:
                f *= 1.01
            f = max(1e-6, min(1 - 1e-6, f))
        wl = w * f
        wr = w - wl
        return _split_rect(x, y, wl, h, left_parts) + _split_rect(x + wl, y, wr, h, parts - left_parts)
    else:
        bottom_parts = max(1, min(parts - 1, int(round(parts * h / (w + h)))))
        if bottom_parts == 0:
            bottom_parts = 1
        if bottom_parts >= parts:
            bottom_parts = parts - 1
        f = bottom_parts / parts
        for _ in range(20):
            hb = h * f
            ht = h - hb
            sb = min(w, hb)
            st = min(w, ht)
            if sb > st + 1e-12:
                f *= 0.99
            else:
                f *= 1.01
            f = max(1e-6, min(1 - 1e-6, f))
        hb = h * f
        ht = h - hb
        return _split_rect(x, y, w, hb, bottom_parts) + _split_rect(x, y + hb, w, ht, parts - bottom_parts)


def _recursive_split(n):
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0 if n == 1 else 0.0)] * n
    res = _split_rect(0.0, 0.0, 1.0, 1.0, n)
    out = []
    for x, y, _t, s in res:
        # center already at x + thing? no, _split_rect returns center
        out.append((x, y, 0.0, s))
    return out[:n]


# ---------- local refinement ----------

def _refine(squares, tries=40, steps=200):
    n = len(squares)
    if n == 0:
        return squares
    sq = [list(s) for s in squares]
    best = _score(sq)
    rng = random.Random(12345)

    # coordinate descent-like random mutations with shrinking step
    for it in range(tries):
        cand = [list(s) for s in sq]
        temp = 0.08 * (0.98 ** it) + 1e-4
        for _ in range(max(1, n)):
            i = rng.randrange(n)
            if rng.random() < 0.45:
                cand[i][3] = max(0.0, cand[i][3] + rng.uniform(-temp, temp))
            if rng.random() < 0.35:
                cand[i][0] = min(1.0, max(0.0, cand[i][0] + rng.uniform(-temp, temp)))
            if rng.random() < 0.35:
                cand[i][1] = min(1.0, max(0.0, cand[i][1] + rng.uniform(-temp, temp)))
            if rng.random() < 0.20:
                cand[i][2] = (cand[i][2] + rng.uniform(-0.1, 0.1)) % 1.0
        fixed = [_clip_square(*c) for c in cand]
        if _valid(fixed):
            sc = _score(fixed)
            if sc > best + 1e-12:
                best = sc
                sq = fixed
    return sq


def _greedy_add(squares, n):
    """Try to add useful squares in empty space by sampling."""
    out = [tuple(s) for s in squares if s[3] > 1e-12]
    # simple grid candidate centers
    if len(out) >= n:
        return out[:n]
    # try place in largest empty spots via random sampling
    rng = random.Random(999)
    for _ in range(max(0, n - len(out))):
        best_cand = None
        best_s = -1.0
        for _ in range(300):
            x = rng.random()
            y = rng.random()
            t = rng.random()
            # binary search largest side that fits
            lo, hi = 0.0, 1.0
            for _ in range(24):
                mid = (lo + hi) * 0.5
                cand = (x, y, t, mid)
                ok = True
                for s in out:
                    if not _overlap_ok(cand, s):
                        ok = False
                        break
                if ok:
                    lo = mid
                else:
                    hi = mid
            if lo > best_s:
                best_s = lo
                best_cand = (x, y, t, lo)
        if best_cand is not None and best_cand[3] > 1e-10:
            out.append(best_cand)
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


# ---------- main solve ----------

def solve(n):
    n = int(n)
    if n <= 0:
        return []
    if n == 1:
        return _layout_1()
    if n == 2:
        return _layout_2()
    if n == 3:
        return _layout_3()
    if n == 4:
        return _layout_4()

    # start from recursive split, then refine
    base = _recursive_split(n)
    # ensure valid
    base = [_clip_square(*s) for s in base]
    if not _valid(base):
        base = _grid(n)
    best = _refine(base, tries=30, steps=150)

    # try grid as alternative
    g = _grid(n)
    g = [_clip_square(*s) for s in g]
    if _valid(g):
        bg = _refine(g, tries=10, steps=80)
        if _score(bg) > _score(best):
            best = bg

    # if some zero squares, try to grow them greedily
    zero_cnt = sum(1 for s in best if s[3] <= 1e-12)
    if zero_cnt > 0:
        best = _greedy_add(best, n)
        best = [_clip_square(*s) for s in best]
        if not _valid(best):
            # fall back: just return valid subset
            best = [s for s in best if _valid([s])]
            while len(best) < n:
                best.append((0.5, 0.5, 0.0, 0.0))

    # final validity/repair
    fixed = []
    for s in best:
        s = _clip_square(*s)
        if all(_overlap_ok(s, t) for t in fixed):
            fixed.append(s)
        else:
            fixed.append((0.5, 0.5, 0.0, 0.0))
    while len(fixed) < n:
        fixed.append((0.5, 0.5, 0.0, 0.0))
    fixed = fixed[:n]

    # guarantee validity for return
    if not _valid(fixed):
        fixed = _grid(n)

    # final local polish
    polished = _refine(fixed, tries=12, steps=100)
    if _valid(polished) and _score(polished) >= _score(fixed):
        fixed = polished

    return [(float(x), float(y), float(t % 1.0), float(max(0.0, s))) for x, y, t, s in fixed]
