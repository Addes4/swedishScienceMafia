import math


def _brick_wall(n):
    """Sheared brick-wall packing of axis-aligned squares: k squares across each
    row, each of width w=1/k, rows overlap vertically (height 2w) and are offset
    horizontally by w/2 so neighbours in adjacent rows interlock; total height h.
    Returns list or None."""
    k = max(1, round(math.sqrt(n)))
    best = None
    for k in range(1, n + 2):
        w = 1.0 / k
        # rows every (1+w... ) -- offset rows by w/2
        # try to fit as many rows as possible with vertical step v; each square
        # spans [x, x+w] x [y, y+w], rows offset alternately.
        v = w  # vertical step; adjacent rows offset by w/2 horizontally
        # possible number of rows
        rows = int((1.0 - w) / v) + 1 if v > 0 else 0
        if rows <= 0:
            continue
        # number of squares we can place
        cnt = rows * k
        # remaining squares have zero size; but maybe we can shrink w slightly to
        # get more rows with the same cnt? cnt only matters; take those with cnt>=?
        # We simply want max sum = cnt*w but must place exactly n; extra squares
        # get size 0, that's fine (sum is cnt*w). We want to maximize cnt*w over
        # cnt<=n and cnt achievable.
        if cnt > n:
            cnt = n
        total = cnt * w
        if best is None or total > best[0]:
            best = (total, k, w, rows)
    if best is None:
        return None
    _, k, w, rows = best
    squares = []
    y = w / 2.0
    placed = 0
    for r in range(rows):
        xoff = (w / 2.0) if (r % 2) else 0.0
        yy = y + r * w
        if yy + w / 2.0 > 1.0 + 1e-15:
            break
        for i in range(k):
            xx = xoff + i * w
            if xx + w > 1.0 + 1e-15:
                xx = 1.0 - w - 1e-12
                if xx < -1e-12:
                    continue
            if placed >= n:
                break
            squares.append((xx + w / 2.0, yy, 0.0, w))
            placed += 1
        if placed >= n:
            break
    if placed < n:
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - placed)
    return squares


def _shelf(n, k, rows_extra):
    """Simple rows packing: k squares per row, rows as many as fit.  allow
    overlapping between rows by choosing height w but step v<w to interlock
    with offset columns (staggered).  Here just a helper variant."""
    if k < 1:
        return None
    w = 1.0 / k
    # rows with vertical step w (no overlap), plus optionally stagger
    rows = int(1.0 / w + 1e-9)
    if rows < 1:
        return None
    cnt = rows * k
    if cnt > n:
        cnt = n
    total = cnt * w
    squares = []
    placed = 0
    y = w / 2.0
    for r in range(rows):
        yy = y + r * w
        if yy + w / 2.0 > 1.0 + 1e-15:
            break
        for i in range(k):
            xx = (i + 0.5) * w
            if xx + w / 2.0 > 1.0 + 1e-15:
                continue
            if placed >= n:
                break
            squares.append((xx, yy, 0.0, w))
            placed += 1
        if placed >= n:
            break
    if placed < n:
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - placed)
    return (total, squares)


def _rotated_strip(n):
    """Pack squares in rotated rows (45 deg tilt of the row direction) to fit
    more squares: rotate the whole brick arrangement by pi/4 and scale so it
    fits inside the unit square.  Returns (score, squares) or None."""
    # place squares in a rotated grid of side s; the grid rotates about center.
    # We try several tilt angles and pick best valid (all corners inside unit sq).
    best = None
    for k in range(1, n + 2):
        s = 1.0 / k
        cols = k
        rows = int(1.0 / s) if s > 0 else 0
        rows = max(1, rows)
        cnt = min(n, cols * rows)
        total = cnt * s
        if best is not None and total <= best[0]:
            continue
        # build grid, then try angles
        base = []
        placed = 0
        for r in range(rows):
            for c in range(cols):
                if placed >= n:
                    break
                base.append(((c + 0.5) * s - 0.5, (r + 0.5) * s - 0.5))
                placed += 1
            if placed >= n:
                break
        if not base:
            continue
        for deg in (0.0, 15.0, 30.0, 45.0, 60.0, 75.0):
            th = math.radians(deg)
            ct, st = math.cos(th), math.sin(th)
            ok = True
            sq = []
            for bx, by in base:
                cx = 0.5 + bx * ct - by * st
                cy = 0.5 + bx * st + by * ct
                # bounding radius of square
                R = s * math.sqrt(2.0) / 2.0
                if cx - R < -1e-9 or cx + R > 1 + 1e-9 or cy - R < -1e-9 or cy + R > 1 + 1e-9:
                    ok = False
                    break
                sq.append((cx, cy, deg / 360.0, s))
            if ok:
                # shrink to fit exactly if close
                if best is None or total > best[0]:
                    best = (total, sq)
                break
    return best


def _diagonal_pair(n):
    """Nested-family: place squares along the main diagonal and anti-diagonal so
    bigger squares can coexist (rotated by 45 deg).  Greedy: place squares of a
    fixed size s at lattice points rotated 45 deg, keep those inside."""
    best = None
    for k in range(1, n + 2):
        s = 1.0 / k
        cnt = 0
        pts = []
        # grid rotated 45 deg: coordinates p=(a,b), a,b in {-k..k}
        for a in range(-k, k + 1):
            for b in range(-k, k + 1):
                # center
                cx = 0.5 + (a + b) * s / 2.0
                cy = 0.5 + (a - b) * s / 2.0
                R = s * math.sqrt(2.0) / 2.0
                if cx - R < -1e-9 or cx + R > 1 + 1e-9:
                    continue
                if cy - R < -1e-9 or cy + R > 1 + 1e-9:
                    continue
                pts.append((cx, cy))
                cnt += 1
                if cnt >= n:
                    break
            if cnt >= n:
                break
        if cnt == 0:
            continue
        total = cnt * s
        if best is None or total > best[0]:
            sq = [(cx, cy, 0.125, s) for (cx, cy) in pts[:n]]
            while len(sq) < n:
                sq.append((0.5, 0.5, 0.0, 0.0))
            best = (total, sq)
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    candidates = []
    bw = _brick_wall(n)
    if bw is not None:
        candidates.append(bw)
    rs = _rotated_strip(n)
    if rs is not None:
        candidates.append(rs[1])
    dp = _diagonal_pair(n)
    if dp is not None:
        candidates.append(dp[1])
    # Simple full grid (non-staggered) as fallback
    k = math.isqrt(n)
    s = 1.0 / k
    cnt = k * k
    grid = []
    for i in range(k):
        for j in range(k):
            grid.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    grid += [(0.5, 0.5, 0.0, 0.0)] * (n - len(grid))
    candidates.append(grid[:n])

    best = None
    best_score = -1.0
    for cand in candidates:
        if cand is None or len(cand) < n:
            continue
        cand = list(cand[:n])
        while len(cand) < n:
            cand.append((0.5, 0.5, 0.0, 0.0))
        total = sum(x[3] for x in cand)
        if total > best_score:
            # validate quickly
            valid = True
            for (cx, cy, ang, side) in cand:
                if side < -1e-12:
                    valid = False
                    break
                if not (-1e-9 <= cx <= 1 + 1e-9 and -1e-9 <= cy <= 1 + 1e-9):
                    # clamp
                    pass
                if ang < -1e-9 or ang > 1 + 1e-9:
                    valid = False
                    break
            if valid:
                best_score = total
                best = cand
    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    # clamp all numbers to [0,1]
    out = []
    for (cx, cy, ang, side) in best:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        side = min(1.0, max(0.0, side))
        out.append((cx, cy, ang, side))
    return out[:n]
