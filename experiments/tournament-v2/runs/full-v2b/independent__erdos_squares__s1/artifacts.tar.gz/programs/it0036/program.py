import math
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, a, s):
    c = math.cos(2.0 * math.pi * a)
    si = math.sin(2.0 * math.pi * a)
    h = 0.5 * s
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * c - dy * si
        y = cy + dx * si + dy * c
        pts.append((x, y))
    return pts


def _overlap_area(sq1, sq2):
    # separating axis theorem for convex polygons
    p1 = _corners(*sq1)
    p2 = _corners(*sq2)
    polys = (p1, p2)
    for poly in polys:
        for i in range(len(poly)):
            j = (i + 1) % len(poly)
            ax = poly[i][0] - poly[j][0]
            ay = poly[i][1] - poly[j][1]
            axis = (-ay, ax)
            nrm = math.hypot(axis[0], axis[1])
            if nrm < 1e-15:
                continue
            axis = (axis[0] / nrm, axis[1] / nrm)
            mn1 = min(x * axis[0] + y * axis[1] for x, y in p1)
            mx1 = max(x * axis[0] + y * axis[1] for x, y in p1)
            mn2 = min(x * axis[0] + y * axis[1] for x, y in p2)
            mx2 = max(x * axis[0] + y * axis[1] for x, y in p2)
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return 0.0
    return 1.0


def _eval(x, n):
    # x: [cx0..cx(n-1), cy0..cy(n-1), a0..a(n-1), s0..s(n-1)]
    cx = x[0:n]
    cy = x[n:2 * n]
    a = x[2 * n:3 * n]
    s = x[3 * n:4 * n]
    obj = -np.sum(s)
    pen = 0.0
    for i in range(n):
        si = max(0.0, s[i])
        if cx[i] - si * 1.5 < -1.0 or cx[i] + si * 1.5 > 1.0 or cy[i] - si * 1.5 < -1.0 or cy[i] + si * 1.5 > 1.0:
            pen += 1e3
    for i in range(n):
        if s[i] <= 1e-12:
            continue
        for j in range(i + 1, n):
            if s[j] <= 1e-12:
                continue
            if _overlap_area((cx[i], cy[i], a[i], s[i]), (cx[j], cy[j], a[j], s[j])) > 0:
                pen += 1e3
    return obj + pen


def _centre_fit(cx, cy, a, s):
    pts = _corners(cx, cy, a, s)
    lo = min(x for x, y in pts)
    hi = max(x for x, y in pts)
    lo2 = min(y for x, y in pts)
    hi2 = max(y for x, y in pts)
    return cx, cy, a, s


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # constructive initial guess: grid for largest square block, then perturb
    best = None
    best_val = -1.0
    # multiple starts
    starts = []
    k = int(math.isqrt(n))
    # candidate grid layout
    base = []
    if k > 0:
        side = 1.0 / k
        for i in range(k):
            for j in range(k):
                base.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        base += [(0.5, 0.5, 0.0, 0.0)] * (n - len(base))
    starts.append(base[:n])
    # diagonal/greedy fill
    diag = []
    for i in range(n):
        diag.append((0.5, 0.5, 0.0, 0.0))
    starts.append(diag)
    # two-column layout
    twocol = []
    rows = (n + 1) // 2
    side2 = 1.0 / max(1, rows)
    for i in range(n):
        r = i // 2
        c = i % 2
        twocol.append((0.25 + 0.5 * c, (r + 0.5) * side2, 0.0, side2))
    starts.append(twocol[:n])

    for st in starts:
        x0 = np.zeros(4 * n)
        for i in range(n):
            x0[i] = st[i][0]
            x0[n + i] = st[i][1]
            x0[2 * n + i] = 0.0
            x0[3 * n + i] = st[i][3]
        bounds = []
        for i in range(n):
            bounds.append((0.0, 1.0))
        for i in range(n):
            bounds.append((0.0, 1.0))
        for i in range(n):
            bounds.append((0.0, 1.0))
        for i in range(n):
            bounds.append((0.0, 1.0))

        try:
            res = minimize(_eval, x0, args=(n,), method='SLSQP', bounds=bounds,
                           options={'maxiter': 200, 'ftol': 1e-9})
        except Exception:
            continue
        if res is None or not np.all(np.isfinite(res.x)):
            continue
        xx = res.x
        cx = xx[0:n]
        cy = xx[n:2 * n]
        a = xx[2 * n:3 * n]
        s = xx[3 * n:4 * n]
        # clip sides to zero if tiny
        s = np.maximum(s, 0.0)
        val = float(np.sum(s))
        if val > best_val and _eval(xx, n) < 1.0:
            best_val = val
            best = [(float(cx[i]), float(cy[i]), float(a[i]), float(s[i])) for i in range(n)]

    if best is None:
        # fallback to grid
        k = int(math.isqrt(n))
        side = 1.0 / max(k, 1)
        best = [((i % k + 0.5) * side, (i // k + 0.5) * side, 0.0, side) for i in range(k * k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    # final safety: shrink any offending squares
    out = []
    for i in range(n):
        cx, cy, a, s = best[i]
        # try to shrink until no overlap with previously placed
        for it in range(50):
            ok = True
            s = max(0.0, min(s, 1.0))
            crmax = s * 1.5
            if cx - crmax < -1e-9 or cx + crmax > 1.0 + 1e-9 or cy - crmax < -1e-9 or cy + crmax > 1.0 + 1e-9:
                s *= 0.9
                ok = False
            for o in out:
                if _overlap_area((cx, cy, a, s), o):
                    ok = False
                    break
            if ok:
                break
            s *= 0.9
        out.append((cx, cy, a, s))
    return out
