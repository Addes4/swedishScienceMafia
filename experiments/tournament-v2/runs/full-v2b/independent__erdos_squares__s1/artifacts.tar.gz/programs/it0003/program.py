import math
import random
import numpy as np
from scipy.optimize import minimize


def _poly(cx, cy, ang, s):
    """Return the 4 vertices of a square."""
    c = math.cos(2.0 * math.pi * ang)
    si = math.sin(2.0 * math.pi * ang)
    h = 0.5 * s
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + x * c - y * si, cy + x * si + y * c) for x, y in pts]


def _axes(ang):
    a = 2.0 * math.pi * ang
    c = math.cos(a)
    s = math.sin(a)
    return (c, s), (-s, c)


def _overlap_area(x1, y1, a1, s1, x2, y2, a2, s2):
    """Approximate overlap area via separating axis check and SAT clipping.
    Return positive area if overlapping."""
    if s1 <= 1e-12 or s2 <= 1e-12:
        return 0.0
    u1, v1 = _axes(a1)
    u2, v2 = _axes(a2)
    axes = [u1, v1, u2, v2]
    # quick separation check
    p1 = _poly(x1, y1, a1, s1)
    p2 = _poly(x2, y2, a2, s2)
    for ax, ay in axes:
        p1p = [p[0] * ax + p[1] * ay for p in p1]
        p2p = [p[0] * ax + p[1] * ay for p in p2]
        if max(p1p) < min(p2p) or max(p2p) < min(p1p):
            return 0.0
    # approximate overlap via clipping: sample? use SAT with clipping polygon
    # Use polygon intersection area via Sutherland-Hodgman
    def clip(subject, cx, cy, nx, ny):
        out = []
        if not subject:
            return out
        S = subject[-1]
        Sd = S[0] * nx + S[1] * ny - cx * nx - cy * ny
        for E in subject:
            Ed = E[0] * nx + E[1] * ny - cx * nx - cy * ny
            if Ed >= -1e-15:
                if Sd < -1e-15:
                    t = Sd / (Sd - Ed)
                    out.append((S[0] + t * (E[0] - S[0]), S[1] + t * (E[1] - S[1])))
                out.append(E)
            elif Sd >= -1e-15:
                t = Sd / (Sd - Ed)
                out.append((S[0] + t * (E[0] - S[0]), S[1] + t * (E[1] - S[1])))
            S = E
            Sd = Ed
        return out

    poly = p1
    # For p2, clip against each edge
    for i in range(4):
        A = p2[i]
        B = p2[(i + 1) % 4]
        ex = B[0] - A[0]
        ey = B[1] - A[1]
        # inside if cross(edge, point-A) >= 0 => left side
        poly = clip(poly, A[0], A[1], -ey, ex)
        if not poly:
            return 0.0
    if len(poly) < 3:
        return 0.0
    area = 0.0
    for i in range(len(poly)):
        xa, ya = poly[i]
        xb, yb = poly[(i + 1) % len(poly)]
        area += xa * yb - xb * ya
    return abs(area) * 0.5


def _constraints_and_cost(n, fixed_zero=True):
    def cost(params):
        s = params[3::4]
        return -float(np.sum(s))

    def cons_fun(params):
        cons = []
        xs = params[0::4]
        ys = params[1::4]
        angs = params[2::4]
        ss = params[3::4]

        # in unit box constraints (bounding box of rotated square)
        for i in range(n):
            s = ss[i]
            if s <= 0:
                continue
            c = abs(math.cos(2 * math.pi * angs[i])) * 0.5 * s
            si = abs(math.sin(2 * math.pi * angs[i])) * 0.5 * s
            hx = c + si
            hy = c + si
            cons.append(xs[i] - hx)
            cons.append(1.0 - xs[i] - hx)
            cons.append(ys[i] - hy)
            cons.append(1.0 - ys[i] - hy)

        # pairwise non-overlap: use approximate overlap area <= 0
        # To keep it efficient, only consider pairs that could overlap by bounding circles.
        for i in range(n):
            for j in range(i + 1, n):
                if ss[i] <= 1e-12 or ss[j] <= 1e-12:
                    continue
                dx = xs[i] - xs[j]
                dy = ys[i] - ys[j]
                ri = 0.5 * ss[i] * 1.4143
                rj = 0.5 * ss[j] * 1.4143
                if dx * dx + dy * dy >= (ri + rj) ** 2:
                    continue
                # Use overlap area as constraint. For non-overlap area must be 0.
                a = _overlap_area(xs[i], ys[i], angs[i], ss[i],
                                  xs[j], ys[j], angs[j], ss[j])
                cons.append(-a + 1e-9)
        return np.array(cons)

    return cost, cons_fun


def _initial_pack(n):
    """Build initial packing."""
    # try a few structured candidates and pick best
    candidates = []

    # k x k grid
    k = math.isqrt(n)
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]

    # recursive quadtree splitting: start with 1 square then split largest repeatedly
    # but we want many squares. Do a simple greedy random pack.
    best = None
    best_sum = -1

    for trial in range(20):
        random.seed(trial * 12345 + n)
        squares = []
        # Start from grid
        if trial < 5:
            base = list(sq)
        elif trial < 10:
            # grid with slightly different sizes
            base = []
            for i in range(k):
                for j in range(k):
                    base.append(((i + 0.5) * side + random.uniform(-0.01, 0.01),
                                 (j + 0.5) * side + random.uniform(-0.01, 0.01),
                                 random.uniform(0, 0.25),
                                 side * 0.999))
        else:
            base = []

        # Add remaining squares greedily
        used = len(base)
        squares = list(base)
        remaining = n - used
        for _ in range(remaining):
            placed = False
            # try random placements
            for attempt in range(200):
                s = random.uniform(0.001, 0.3)
                x = random.uniform(s / 2, 1 - s / 2)
                y = random.uniform(s / 2, 1 - s / 2)
                ang = random.uniform(0, 0.25)
                ok = True
                for (px, py, pa, ps) in squares:
                    if _overlap_area(x, y, ang, s, px, py, pa, ps) > 1e-10:
                        ok = False
                        break
                if ok:
                    squares.append((x, y, ang, s))
                    placed = True
                    break
            if not placed:
                squares.append((0.5, 0.5, 0.0, 0.0))
        ssum = sum(s[3] for s in squares)
        if ssum > best_sum:
            best_sum = ssum
            best = squares

    return best


def _refine(squares):
    n = len(squares)
    params = []
    for x, y, a, s in squares:
        params.extend([x, y, a, s])
    params = np.array(params, dtype=float)

    # bounds: x,y in [0,1], angle in [0,0.25] (quarter turn due symmetry), side in [0, 1]
    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 0.25))
        bounds.append((0.0, 1.0))

    cost, cons = _constraints_and_cost(n)

    # Use a simpler penalty-based refinement since analytic constraints are numerous
    def objective(p):
        s = p[3::4]
        total = -np.sum(s)
        # penalty for overlaps
        xs = p[0::4]
        ys = p[1::4]
        angs = p[2::4]
        ss = p[3::4]
        pen = 0.0
        # box penalty
        for i in range(n):
            if ss[i] <= 1e-12:
                continue
            c = abs(math.cos(2 * math.pi * angs[i])) * 0.5 * ss[i]
            si = abs(math.sin(2 * math.pi * angs[i])) * 0.5 * ss[i]
            hx = c + si
            hy = c + si
            for val in (xs[i] - hx, 1.0 - xs[i] - hx, ys[i] - hy, 1.0 - ys[i] - hy):
                if val < 0:
                    pen += 1000.0 * val * val
        # overlap penalty
        for i in range(n):
            for j in range(i + 1, n):
                if ss[i] <= 1e-12 or ss[j] <= 1e-12:
                    continue
                dx = xs[i] - xs[j]
                dy = ys[i] - ys[j]
                ri = 0.5 * ss[i] * 1.4143
                rj = 0.5 * ss[j] * 1.4143
                if dx * dx + dy * dy >= (ri + rj) ** 2:
                    continue
                a = _overlap_area(xs[i], ys[i], angs[i], ss[i],
                                  xs[j], ys[j], angs[j], ss[j])
                if a > 1e-10:
                    pen += 1000.0 * a * a
        return total + pen

    res = minimize(objective, params, method='L-BFGS-B', bounds=bounds,
                   options={'maxiter': 2000, 'ftol': 1e-12, 'gtol': 1e-10})
    p = res.x
    out = []
    for i in range(n):
        x = min(max(p[4 * i], 0.0), 1.0)
        y = min(max(p[4 * i + 1], 0.0), 1.0)
        a = min(max(p[4 * i + 2], 0.0), 0.25)
        s = max(p[4 * i + 3], 0.0)
        out.append((x, y, a, s))
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # For small n, use specific good configurations
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # two small at bottom, one large top
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.5, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        # 1 big square on top, 4 small on bottom
        return [(0.5, 2/3, 0.0, 2/3), (0.25, 1/6, 0.0, 1/3),
                (0.75, 1/6, 0.0, 1/3), (0.125, 1/6, 0.0, 0.0), (0.875, 1/6, 0.0, 0.0)]

    best = _initial_pack(n)
    refined = _refine(best)

    # Ensure zero side invalid placements are kept inside
    result = []
    for x, y, a, s in refined:
        # clamp
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        a = min(max(a, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        # Fix box: adjust side if necessary
        c = abs(math.cos(2 * math.pi * a)) * 0.5 * s
        si = abs(math.sin(2 * math.pi * a)) * 0.5 * s
        hx = c + si
        hy = c + si
        if hx > 1.0 or hy > 1.0:
            s = min(s, 1.0 / (abs(math.cos(2*math.pi*a)) + abs(math.sin(2*math.pi*a))))
            s = max(0.0, s)
        if x - hx < -1e-12 or x + hx > 1.0 + 1e-12 or y - hy < -1e-12 or y + hy > 1.0 + 1e-12:
            # center it and reduce if needed
            x = min(max(x, hx), 1.0 - hx) if hx <= 1.0 else 0.5
            y = min(max(y, hy), 1.0 - hy) if hy <= 1.0 else 0.5
        result.append((x, y, a, s))

    return result
