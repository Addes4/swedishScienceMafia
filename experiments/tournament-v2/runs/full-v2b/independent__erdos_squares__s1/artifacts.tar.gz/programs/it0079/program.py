import math
import random
import numpy as np
from scipy.spatial import ConvexHull


def _rotated_square_corners(cx, cy, angle, side):
    """Return four corners of a square with given center, angle (fraction of full turn), side length."""
    theta = angle * 2 * math.pi
    c, s = math.cos(theta), math.sin(theta)
    half = side / 2.0
    # corners relative to center
    pts = [(-half, -half), (half, -half), (half, half), (-half, half)]
    return [(cx + c * x - s * y, cy + s * x + c * y) for (x, y) in pts]


def _overlap_area(sq1, sq2):
    """Approximate overlap area via polygon intersection (Sutherland-Hodgman)."""
    p1 = _rotated_square_corners(*sq1)
    p2 = _rotated_square_corners(*sq2)
    # quick bounding circle check
    r1 = sq1[3] / math.sqrt(2.0)
    r2 = sq2[3] / math.sqrt(2.0)
    d2 = (sq1[0] - sq2[0]) ** 2 + (sq1[1] - sq2[1]) ** 2
    if d2 > (r1 + r2) ** 2:
        return 0.0
    if d2 < 1e-18:
        return min(sq1[3], sq2[3]) ** 2
    # polygon clipping
    def clip(subject, clipper):
        out = subject
        n = len(clipper)
        for i in range(n):
            if not out:
                break
            a = clipper[i]
            b = clipper[(i + 1) % n]
            # inside half-plane: cross(b-a, p-a) >= 0 (CCW)
            ax, ay = a
            bx, by = b
            dx, dy = bx - ax, by - ay
            inside = []
            m = len(out)
            for j in range(m):
                p = out[j]
                q = out[(j + 1) % m]
                px, py = p
                qx, qy = q
                cp = dx * (py - ay) - dy * (px - ax)
                cq = dx * (qy - ay) - dy * (qx - ax)
                if cp >= -1e-12:
                    inside.append(p)
                if (cp > 1e-12 and cq < -1e-12) or (cp < -1e-12 and cq > 1e-12):
                    t = cp / (cp - cq)
                    inside.append((px + t * (qx - px), py + t * (qy - py)))
            out = inside
        return out

    # ensure CCW
    def ensure_ccw(poly):
        area = 0.0
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            area += x1 * y2 - x2 * y1
        if area < 0:
            return list(reversed(poly))
        return poly

    p1 = ensure_ccw(p1)
    p2 = ensure_ccw(p2)
    inter = clip(p1, p2)
    if len(inter) < 3:
        return 0.0
    area = 0.0
    n = len(inter)
    for i in range(n):
        x1, y1 = inter[i]
        x2, y2 = inter[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def _inside_unit(cx, cy, angle, side):
    """Check if the rotated square is fully inside the unit square."""
    pts = _rotated_square_corners(cx, cy, angle, side)
    for x, y in pts:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _total_side(squares):
    return sum(sq[3] for sq in squares)


def _valid(squares, tol=1e-7):
    """Check all constraints: inside unit square and no interior overlap."""
    n = len(squares)
    for i in range(n):
        if squares[i][3] <= 0:
            continue
        if not _inside_unit(*squares[i]):
            return False
        for j in range(i + 1, n):
            if squares[j][3] <= 0:
                continue
            a = _overlap_area(squares[i], squares[j])
            if a > tol:
                return False
    return True


def _initial_grid(n):
    """Best grid-based layout."""
    best = None
    best_sum = -1
    # try various row/col configurations
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        k = max(rows, cols)
        if k > 10:
            continue
        # uniform grid of size k x k
        side = 1.0 / k
        sqs = []
        for i in range(k):
            for j in range(k):
                sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        # choose n largest (all equal here)
        sqs = sqs[:n] + [(0.5, 0.5, 0.0, 0.0)] * (n - len(sqs))
        sqs = sqs[:n]
        s = _total_side(sqs)
        if s > best_sum:
            best_sum = s
            best = sqs
    # also try non-uniform: one large square plus grid
    for big_side in [0.5, 0.6, 0.7, 0.8, 1.0]:
        rem = n - 1
        if rem <= 0:
            continue
        k = math.isqrt(rem)
        if k == 0:
            k = 1
        side = min(1.0 - big_side, big_side) / k if k > 0 else 0
        if side <= 0:
            continue
        sqs = [(big_side / 2, big_side / 2, 0.0, big_side)]
        for i in range(k):
            for j in range(k):
                if len(sqs) >= n:
                    break
                sqs.append((big_side + (i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        sqs += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sqs))
        sqs = sqs[:n]
        s = _total_side(sqs)
        if s > best_sum:
            best_sum = s
            best = sqs
    return best


def _perturb(squares, rng, temp):
    """Return a perturbed copy of squares."""
    new = [list(sq) for sq in squares]
    n = len(new)
    # pick a random square to modify
    idx = rng.randrange(n)
    if new[idx][3] <= 0:
        # activate a zero square
        new[idx][3] = rng.uniform(0.01, 0.1)
        new[idx][0] = rng.uniform(0.1, 0.9)
        new[idx][1] = rng.uniform(0.1, 0.9)
        new[idx][2] = rng.uniform(0.0, 0.25)
    else:
        # perturb size or position or angle
        r = rng.random()
        if r < 0.4:
            new[idx][3] *= rng.uniform(0.8, 1.2)
        elif r < 0.7:
            new[idx][0] += rng.gauss(0, 0.05 * temp)
            new[idx][1] += rng.gauss(0, 0.05 * temp)
        else:
            new[idx][2] += rng.gauss(0, 0.05 * temp)
            new[idx][2] %= 1.0
        new[idx][3] = max(0.0, new[idx][3])
        new[idx][0] = max(0.0, min(1.0, new[idx][0]))
        new[idx][1] = max(0.0, min(1.0, new[idx][1]))
    return [tuple(sq) for sq in new]


def _repair(squares, rng, iterations=100):
    """Try to fix overlaps by shrinking/moving squares."""
    sqs = [list(sq) for sq in squares]
    n = len(sqs)
    for _ in range(iterations):
        fixed = True
        for i in range(n):
            if sqs[i][3] <= 0:
                continue
            if not _inside_unit(*sqs[i]):
                # move inside
                sqs[i][0] = max(sqs[i][3] / 2, min(1 - sqs[i][3] / 2, sqs[i][0]))
                sqs[i][1] = max(sqs[i][3] / 2, min(1 - sqs[i][3] / 2, sqs[i][1]))
                if not _inside_unit(*sqs[i]):
                    sqs[i][3] *= 0.9
                fixed = False
            for j in range(i + 1, n):
                if sqs[j][3] <= 0:
                    continue
                a = _overlap_area(tuple(sqs[i]), tuple(sqs[j]))
                if a > 1e-7:
                    # shrink the smaller one
                    if sqs[i][3] < sqs[j][3]:
                        sqs[i][3] *= 0.95
                    else:
                        sqs[j][3] *= 0.95
                    fixed = False
        if fixed:
            break
    return [tuple(sq) for sq in sqs]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares: each 0.5 side, side by side
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # L-shaped: one 0.5 and two 0.5
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    rng = random.Random(12345 + n)
    best = _initial_grid(n)
    best_sum = _total_side(best)

    # Try a few random restarts with simulated annealing
    time_limit = 50.0
    import time
    start = time.time()

    # For small n, try more iterations
    max_iters = 5000 if n <= 10 else 2000

    current = best
    current_sum = best_sum

    for restart in range(5):
        if time.time() - start > time_limit:
            break
        # random restart: grid with random perturbations
        k = math.isqrt(n)
        if k < 1:
            k = 1
        side = 1.0 / k
        sqs = []
        for i in range(k):
            for j in range(k):
                sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        while len(sqs) < n:
            sqs.append((rng.uniform(0.1, 0.9), rng.uniform(0.1, 0.9), rng.uniform(0, 0.25),
                        rng.uniform(0.0, 0.1)))
        sqs = sqs[:n]
        # shuffle to distribute zero-size squares
        rng.shuffle(sqs)
        # repair
        sqs = _repair(sqs, rng, 50)
        s = _total_side(sqs)
        if s > current_sum:
            current = sqs
            current_sum = s

        temp = 0.1
        for it in range(max_iters):
            if time.time() - start > time_limit:
                break
            temp = 0.1 * (1.0 - it / max_iters) + 0.001
            new = _perturb(current, rng, temp)
            new = _repair(new, rng, 20)
            new_sum = _total_side(new)
            if new_sum > current_sum:
                current = new
                current_sum = new_sum
            elif rng.random() < math.exp((new_sum - current_sum) / (temp + 1e-9)):
                current = new
                current_sum = new_sum
            if current_sum > best_sum:
                # verify
                if _valid(current, tol=1e-5):
                    best = current
                    best_sum = current_sum

        if time.time() - start > time_limit:
            break

    # final validation and minor cleanup
    if not _valid(best, tol=1e-5):
        # fall back to grid
        best = _initial_grid(n)
    return best
