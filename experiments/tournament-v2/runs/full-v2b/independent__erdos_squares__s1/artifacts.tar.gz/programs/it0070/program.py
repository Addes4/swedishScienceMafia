import math
import random

def _overlap(sq1, sq2):
    # sq: (cx, cy, angle, side)
    ax1, ay1, a1, s1 = sq1
    ax2, ay2, a2, s2 = sq2
    if s1 <= 0 or s2 <= 0:
        return False
    # SAT for two rotated squares
    def corners(cx, cy, ang, s):
        h = s * 0.5
        co = math.cos(2*math.pi*ang)
        si = math.sin(2*math.pi*ang)
        pts = []
        for dx, dy in [(-h,-h),(h,-h),(h,h),(-h,h)]:
            pts.append((cx + dx*co - dy*si, cy + dx*si + dy*co))
        return pts
    p1 = corners(*sq1)
    p2 = corners(*sq2)
    axes = []
    for pts in (p1, p2):
        for i in range(4):
            x1,y1 = pts[i]
            x2,y2 = pts[(i+1)%4]
            axes.append((-(y2-y1), x2-x1))
    for ax, ay in axes:
        # project both
        def proj(p):
            return [x*ax + y*ay for x,y in p]
        pr1 = proj(p1)
        pr2 = proj(p2)
        if max(pr1) < min(pr2) or max(pr2) < min(pr1):
            return False
    return True

def _valid(squares):
    n = len(squares)
    for i in range(n):
        cx, cy, a, s = squares[i]
        if s < 0:
            return False
        h = s * 0.5
        co = abs(math.cos(2*math.pi*a))
        si = abs(math.sin(2*math.pi*a))
        # bounding box half extents
        ex = h * (co + si)
        ey = h * (co + si)
        if cx - ex < -1e-9 or cx + ex > 1+1e-9 or cy - ey < -1e-9 or cy + ey > 1+1e-9:
            return False
        for j in range(i+1, n):
            if _overlap(squares[i], squares[j]):
                return False
    return True

def _clamp_in(sq):
    cx, cy, a, s = sq
    if s <= 0:
        return (max(0.0,min(1.0,cx)), max(0.0,min(1.0,cy)), a, 0.0)
    h = s * 0.5
    co = abs(math.cos(2*math.pi*a))
    si = abs(math.sin(2*math.pi*a))
    ex = h * (co + si)
    ey = h * (co + si)
    cx = max(ex, min(1-ex, cx))
    cy = max(ey, min(1-ey, cy))
    if ex*2 > 1 or ey*2 > 1:
        # shrink to fit
        maxs = 1.0/(co+si)
        s = min(s, maxs)
        h = s*0.5
        ex = h*(co+si)
        ey = h*(co+si)
        cx = max(ex, min(1-ex, cx))
        cy = max(ey, min(1-ey, cy))
    return (cx, cy, a, s)

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        # best single square: rotate 45 deg to fit larger? Actually axis aligned gives 1.0
        return [(0.5,0.5,0.0,1.0)]
    # initial: grid
    k = math.isqrt(n)
    if k < 1:
        k = 1
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i+0.5)*side, (j+0.5)*side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    if not _valid(squares):
        # fallback
        s = 1.0/n
        return [(0.5,0.5,0.0,0.0) for _ in range(n)]

    best = [(-sum(s[3] for s in squares), squares[:])]
    random.seed(12345 + n)
    time_limit = 0.0
    import time
    t0 = time.time()
    limit = 55.0

    cur = squares[:]
    cur_score = sum(s[3] for s in cur)

    def try_move(idx, dcx, dcy, da, ds):
        nonlocal cur_score
        old = cur[idx]
        new = (old[0]+dcx, old[1]+dcy, old[2]+da, old[3]+ds)
        new = _clamp_in(new)
        # check all overlaps and bounds
        cur[idx] = new
        cx, cy, a, s = new
        if s < 0:
            cur[idx] = old
            return False
        h = s*0.5
        co = abs(math.cos(2*math.pi*a))
        si = abs(math.sin(2*math.pi*a))
        ex = h*(co+si); ey = h*(co+si)
        if cx-ex < -1e-9 or cx+ex > 1+1e-9 or cy-ey < -1e-9 or cy+ey > 1+1e-9:
            cur[idx] = old
            return False
        for j in range(len(cur)):
            if j==idx: continue
            if _overlap(new, cur[j]):
                cur[idx] = old
                return False
        cur_score += (s - old[3])
        return True

    # coordinate descent
    it = 0
    while time.time()-t0 < limit:
        it += 1
        improved = False
        order = list(range(n))
        random.shuffle(order)
        # try growing each square
        for idx in order:
            old = cur[idx]
            # try increase size
            for dscale in [1.05, 1.02, 1.01]:
                ds = old[3]*dscale - old[3]
                if ds <= 0: continue
                # try at same center
                if try_move(idx, 0,0,0, ds):
                    improved = True
                    break
                # try small shifts
                for _ in range(3):
                    dcx = (random.random()-0.5)*old[3]*0.3
                    dcy = (random.random()-0.5)*old[3]*0.3
                    da = (random.random()-0.5)*0.05
                    if try_move(idx, dcx, dcy, da, ds):
                        improved = True
                        break
                if improved:
                    break
            # try rotate to allow more size
            if old[3] > 1e-6:
                for da in [0.02, -0.02, 0.005, -0.005]:
                    if try_move(idx, 0,0,da, 0):
                        improved = True
                        break
        # random perturbations accepted if valid (simulated annealing-ish)
        if not improved:
            # random jump
            idx = random.randrange(n)
            old = cur[idx]
            dcx = (random.random()-0.5)*0.05
            dcy = (random.random()-0.5)*0.05
            da = (random.random()-0.5)*0.1
            ds = (random.random()-0.2)*0.05
            try_move(idx, dcx, dcy, da, ds)
            # also try shrink some to allow others
            if random.random() < 0.3:
                idx2 = random.randrange(n)
                if cur[idx2][3] > 0.001:
                    try_move(idx2, 0,0,0, -cur[idx2][3]*0.1)
        # re-optimize zero squares into gaps
        if it % 5 == 0:
            for idx in range(n):
                if cur[idx][3] < 1e-6:
                    # try to place small square somewhere
                    for _ in range(20):
                        x = random.random()
                        y = random.random()
                        a = random.random()
                        s = 0.01
                        trial = _clamp_in((x,y,a,s))
                        if trial[3] < 1e-9: continue
                        cur[idx] = trial
                        ok = True
                        for j in range(n):
                            if j==idx: continue
                            if _overlap(trial, cur[j]):
                                ok = False
                                break
                        if ok:
                            cur_score += trial[3]
                            improved = True
                            break
                        else:
                            cur[idx] = (old[0],old[1],old[2],0.0)
        if improved:
            score = sum(s[3] for s in cur)
            if score > best[0][0]*(-1) + 1e-12:  # > current best
                if -score < best[0][0]:
                    best[0] = (-score, cur[:])

    result = best[0][1]
    # final cleanup: ensure zero-size are at valid points
    out = []
    for cx, cy, a, s in result:
        if s <= 0:
            out.append((0.5,0.5,0.0,0.0))
        else:
            out.append(_clamp_in((cx,cy,a,s)))
    # validate
    if not _valid(out):
        # fallback to best valid grid
        k = math.isqrt(n)
        side = 1.0/k
        out = [((i+0.5)*side, (j+0.5)*side, 0.0, side) for i in range(k) for j in range(k)]
        out += [(0.5,0.5,0.0,0.0)]*(n-len(out))
        out = out[:n]
    return out
