import math

def solve(n):
    # Start with the best simple grid packing.
    # For perfect squares, a k x k grid is optimal in the axis-aligned case.
    k = math.isqrt(n)
    best = None
    best_sum = -1.0

    # Try all k with k*k <= n and a final row for n - k*k.
    # For non-perfect squares, use one full grid plus a partial row.
    for kk in range(max(1, k - 1), k + 1):
        m = kk * kk
        if m > n:
            continue
        rem = n - m
        s = 1.0 / kk
        total = m * s
        if rem == 0:
            cand = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                    for i in range(kk) for j in range(kk)]
            if total > best_sum:
                best_sum = total
                best = cand
            continue

        # Put remaining squares in a row at the bottom, sharing the same area.
        # Height available for the row is 1 - kk*s = 0 if kk is maximal, so shrink
        # the grid slightly to make room.
        # We use kk columns in the extra row when possible.
        cols = min(rem, kk)
        rows = (rem + cols - 1) // cols

        # Shrink main grid side to leave a strip of height t at the bottom.
        # Extra squares have side t, and they fit in cols columns with rows rows.
        # Need cols * t <= 1 and rows * t <= t, impossible unless rows=1.
        # So place all leftovers in a single row of height t, using rem columns.
        t = 1.0 / (rem + 1.0) if rem > 0 else 0.0
        main = 1.0 - t
        ss = main / kk
        total2 = m * ss + rem * t

        if total2 > best_sum:
            cand = []
            for i in range(kk):
                for j in range(kk):
                    cand.append(((i + 0.5) * ss, t + (j + 0.5) * ss, 0.0, ss))
            if rem > 0:
                cell = 1.0 / rem
                for i in range(rem):
                    cand.append(((i + 0.5) * cell, 0.5 * t, 0.0, t))
            best_sum = total2
            best = cand

    # Try an alternative: one square as large as possible, rest zero.
    # This helps for small n where a single large square can beat a grid.
    cand2 = [(0.5, 0.5, 0.0, 1.0)] + [(0.5, 0.5, 0.0, 0.0)] * (n - 1)
    if n * 1.0 > best_sum:
        # Only if the single square sum (1.0) beats grid sum.
        if 1.0 > best_sum:
            best_sum = 1.0
            best = cand2

    # For n <= 4, exact small cases:
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # Two squares side by side: each 0.5 x 0.5 -> sum 1.0
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # 2x2 grid minus one: side 0.5 each -> sum 1.5
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # For n = 5..8, 3x3 minus some is good.
    if n == 5:
        s = 1.0 / 3.0
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(3) for j in range(3)][:5]
    if n == 6:
        s = 1.0 / 3.0
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(3) for j in range(3)][:6]
    if n == 7:
        s = 1.0 / 3.0
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(3) for j in range(3)][:7]
    if n == 8:
        s = 1.0 / 3.0
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(3) for j in range(3)][:8]

    # General fallback: best of the candidates found.
    if best is None:
        # Axis-aligned grid
        k = math.isqrt(n)
        s = 1.0 / k
        best = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    return best[:n]
