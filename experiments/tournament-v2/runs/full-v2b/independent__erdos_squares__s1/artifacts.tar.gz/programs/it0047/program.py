import math
import random

# ----------------------------------------------------------------------
# basic overlap test for two axis-aligned or rotated squares
# ----------------------------------------------------------------------
def _corners(cx, cy, a, s):
    """Return 4 corners of a square with centre (cx,cy), angle a (fraction of turn),
    side s.  a is measured anticlockwise; corner order is clockwise."""
    th = a * 2.0 * math.pi
    c = math.cos(th) * (s * 0.5)
    si = math.sin(th) * (s * 0.5)
    h = s * 0.5
    # local axes: u = (c, si), v = (-si, c)
    pts = [
        (cx + c - (-si), cy + si - c),
        (cx + c + (-si), cy + si + c),
        (cx - c + (-si), cy - si + c),
        (cx - c - (-si), cy - si - c),
    ]
    return pts


def _overlap(sq1, sq2):
    """True if interiors of two squares overlap (SAT)."""
    c1x, c1y, a1, s1 = sq1
    c2x, c2y, a2, s2 = sq2
    if s1 <= 1e-15 or s2 <= 1e-15:
        return False
    p1 = _corners(c1x, c1y, a1, s1)
    p2 = _corners(c2x, c2y, a2, s2)

    def axes(poly):
        n = len(poly)
        result = []
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            result.append((-(y2 - y1), x2 - x1))
        return result

    for ax in axes(p1) + axes(p2):
        axx, axy = ax
        len2 = axx * axx + axy * axy
        if len2 < 1e-30:
            continue
        min1 = min(p[0] * axx + p[1] * axy for p in p1)
        max1 = max(p[0] * axx + p[1] * axy for p in p1)
        min2 = min(p[0] * axx + p[1] * axy for p in p2)
        max2 = max(p[0] * axx + p[1] * axy for p in p2)
        if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
            return False
    return True


def _inside(cx, cy, a, s):
    pts = _corners(cx, cy, a, s)
    for (x, y) in pts:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


# ----------------------------------------------------------------------
# rectangular grid packing
# ----------------------------------------------------------------------
def grid_pack(n, nx, ny):
    """Fill unit square with nx*ny equal squares in a regular grid.
    Returns list of squares."""
    s = min(1.0 / nx, 1.0 / ny)
    out = []
    for i in range(nx):
        for j in range(ny):
            out.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    return out


def best_grid(n):
    """Try all grids nx*ny <= n, choose max sum of sides."""
    best = []
    best_score = -1.0
    # limit search for large n
    maxdim = min(n, 200)
    for nx in range(1, maxdim + 1):
        for ny in range(1, maxdim + 1):
            if nx * ny > n:
                # can still use fewer squares if we want? no: grid gives exactly nx*ny
                break
            # need nx*ny <= n
            s = min(1.0 / nx, 1.0 / ny)
            score = (nx * ny) * s
            # bonus: remaining squares can be zero
            if score > best_score:
                best_score = score
                best = (nx, ny, s)
    if not best:
        return [], -1
    nx, ny, s = best
    out = []
    for i in range(nx):
        for j in range(ny):
            out.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    # fill extra with zero
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out, best_score


# ----------------------------------------------------------------------
# place remaining squares greedily in a strip (rectangle)
# ----------------------------------------------------------------------
def fill_strip(rect, count, existing):
    """rect = (x0, y0, x1, y1).  Try to place 'count' squares into this rectangle
    (already partly occupied by existing squares).  Greedy: place one square at a
    time, largest possible, at grid/search positions, avoiding overlaps.
    Returns (new_squares, total_side)."""
    x0, y0, x1, y1 = rect
    w = x1 - x0
    h = y1 - y0
    placed = []
    total = 0.0
    allsq = list(existing)
    for k in range(count):
        # binary-search largest side that fits somewhere
        lo, hi = 0.0, min(w, h) * 2.0
        best_place = None
        for _ in range(28):
            mid = 0.5 * (lo + hi)
            found = None
            # candidate centres and angles
            ncen = 7 if k < 8 else 3
            nang = 9 if k < 8 else 3
            for ia in range(nang):
                ang = ia / (2.0 * nang)
                for ix in range(ncen):
                    for iy in range(ncen):
                        cx = x0 + mid * 0.5 + (w - mid) * (ix / max(1, ncen - 1))
                        cy = y0 + mid * 0.5 + (h - mid) * (iy / max(1, ncen - 1))
                        if cx < x0 or cx > x1 or cy < y0 or cy > y1:
                            continue
                        cand = (cx, cy, ang, mid)
                        if not _inside(cx, cy, ang, mid):
                            continue
                        ok = True
                        for e in allsq:
                            if _overlap(cand, e):
                                ok = False
                                break
                        if ok:
                            found = cand
                            break
                    if found:
                        break
                if found:
                    break
            if found:
                lo = mid
                best_place = found
            else:
                hi = mid
        if best_place is None:
            best_place = (x0 + 0.001, y0 + 0.001, 0.0, 0.0)
            best_place = (min(x1, x0 + 0.001), min(y1, y0 + 0.001), 0.0, 0.0)
        placed.append(best_place)
        allsq.append(best_place)
        total += best_place[3]
    return placed, total


# ----------------------------------------------------------------------
# two-block packing
# ----------------------------------------------------------------------
def two_block(n):
    """Split unit square into two rectangles and fill each with grid / greedy."""
    best = None
    best_score = -1.0
    # try horizontal cut at fraction f with k squares in bottom block
    for k in range(1, n):
        # block A: k squares in a grid/free, block B: n-k squares
        # try to allocate heights
        for f in [0.25, 1.0/3, 0.4, 0.5, 0.6, 2.0/3, 0.75]:
            h1 = f
            h2 = 1.0 - f
            if h1 <= 0 or h2 <= 0:
                continue
            # subdivide widths: bottom [0,1]x[0,h1], top [0,1]x[h1,1]
            # For each block try a grid
            for nx1 in range(1, k + 1):
                # ny1 = ceil(k/nx1)
                for ny1 in range(1, k + 1):
                    if nx1 * ny1 > k:
                        break
                    for nx2 in range(1, n - k + 1):
                        for ny2 in range(1, n - k + 1):
                            if nx2 * ny2 > n - k:
                                break
                            s1 = min(1.0 / nx1, h1 / ny1)
                            s2 = min(1.0 / nx2, h2 / ny2)
                            if s1 <= 0 or s2 <= 0:
                                continue
                            sc = nx1 * ny1 * s1 + nx2 * ny2 * s2
                            if sc > best_score:
                                best_score = sc
                                best = (nx1, ny1, s1, nx2, ny2, s2, h1)
    # optimize f numerically  for the best (nx1,ny1,nx2,ny2)
    if best:
        nx1, ny1, s1, nx2, ny2, s2, h1 = best
        lo, hi = 0.0, 1.0
        for _ in range(40):
            m1 = lo + (hi - lo) * 0.33
            m2 = lo + (hi - lo) * 0.66
            v1 = nx1 * ny1 * min(1.0 / nx1, m1 / ny1) + nx2 * ny2 * min(1.0 / nx2, (1 - m1) / ny2)
            v2 = nx1 * ny1 * min(1.0 / nx1, m2 / ny1) + nx2 * ny2 * min(1.0 / nx2, (1 - m2) / ny2)
            if v1 > v2:
                hi = m2
            else:
                lo = m1
        h1 = 0.5 * (lo + hi)
        s1 = min(1.0 / nx1, h1 / ny1)
        s2 = min(1.0 / nx2, (1.0 - h1) / ny2)
        # build squares
        out = []
        for i in range(nx1):
            for j in range(ny1):
                cx = (i + 0.5) * s1
                cy = h1 - (j + 0.5) * s1  # bottom block
                # fix: bottom block y in [0,h1]
                cy = (j + 0.5) * s1
                out.append((cx, cy, 0.0, s1))
        for i in range(nx2):
            for j in range(ny2):
                cx = (i + 0.5) * s2
                cy = h1 + (j + 0.5) * s2
                out.append((cx, cy, 0.0, s2))
        while len(out) < n:
            out.append((0.5, 0.5, 0.0, 0.0))
        return out[:n], best_score
    return None, -1


# ----------------------------------------------------------------------
# main solver
# ----------------------------------------------------------------------
def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_sol = None
    best_score = -1.0

    # 1) rectangular grid
    sol_grid, score_grid = best_grid(n)
    if score_grid > best_score:
        best_score = score_grid
        best_sol = sol_grid

    # 2) two rectangular blocks (good for large n)
    sol_two, score_two = two_block(n)
    if sol_two is not None and score_two > best_score:
        best_score = score_two
        best_sol = sol_two

    # 3) grid + greedy fill for leftover in a strip
    #    try best few grids, then fill the remaining space (a horizontal strip)
    #    with the leftover squares using greedy placement.
    if n <= 60:
        maxdim = min(n, 40)
        for nx in range(1, maxdim + 1):
            for ny in range(1, maxdim + 1):
                if nx * ny > n:
                    break
                used = nx * ny
                s = min(1.0 / nx, 1.0 / ny)
                base_score = used * s
                if used == n:
                    continue
                # place grid in lower part, leftover above
                hgrid = ny * s
                # area above the grid
                extra = n - used
                if extra == 0:
                    continue
                # try to place extra squares in [0,1] x [hgrid, 1]
                existing = []
                for i in range(nx):
                    for j in range(ny):
                        cx = (i + 0.5) * s
                        cy = (j + 0.5) * s
                        existing.append((cx, cy, 0.0, s))
                if hgrid < 1.0 - 1e-9:
                    new_sq, add_score = fill_strip((0.0, hgrid, 1.0, 1.0), extra, existing)
                else:
                    # no space: try squeezing
                    continue
                total_score = base_score + add_score
                if total_score > best_score:
                    best_score = total_score
                    allsq = existing + new_sq
                    while len(allsq) < n:
                        allsq.append((0.5, 0.5, 0.0, 0.0))
                    best_sol = allsq[:n]

    # 4) for small n try a full greedy / random search
    if n <= 25:
        for trial in range(5):
            cand = _random_greedy(n)
            if cand is not None:
                sc = sum(sq[3] for sq in cand)
                if sc > best_score:
                    best_score = sc
                    best_sol = cand

    if best_sol is None:
        k = math.isqrt(n)
        s = 1.0 / k
        best_sol = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
        while len(best_sol) < n:
            best_sol.append((0.5, 0.5, 0.0, 0.0))

    # clean: ensure all in [0,1], clamp tiny negatives
    cleaned = []
    for (cx, cy, a, s) in best_sol[:n]:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        a = a % 1.0
        s = min(1.0, max(0.0, s))
        cleaned.append((cx, cy, a, s))
    while len(cleaned) < n:
        cleaned.append((0.5, 0.5, 0.0, 0.0))
    return cleaned[:n]


def _random_greedy(n):
    """Greedy random placement: start with biggest squares, place one by one."""
    squares = []
    total = 0.0
    for k in range(n):
        best = None
        bests = 0.0
        # binary search max side
        lo, hi = 0.0, 1.0
        for _ in range(20):
            mid = 0.5 * (lo + hi)
            found = None
            for _ in range(30):
                ang = random.random()
                cx = random.random()
                cy = random.random()
                # shrink toward inside
                if not _inside(cx, cy, ang, mid):
                    continue
                cand = (cx, cy, ang, mid)
                ok = True
                for e in squares:
                    if _overlap(cand, e):
                        ok = False
                        break
                if ok:
                    found = cand
                    break
            if found:
                lo = mid
                best = found
            else:
                hi = mid
        if best is None:
            # try a tiny one
            placed = False
            for _ in range(100):
                cx = random.random()
                cy = random.random()
                ang = random.random()
                cand = (cx, cy, ang, 1e-6)
                if _inside(cx, cy, ang, 1e-6):
                    ok = True
                    for e in squares:
                        if _overlap(cand, e):
                            ok = False
                            break
                    if ok:
                        best = cand
                        placed = True
                        break
            if not placed:
                best = (0.5, 0.5, 0.0, 0.0)
        squares.append(best)
        total += best[3]
    return squares
