import math
import random
from functools import lru_cache


def _rects_area(rects):
    return sum(w * h for (x, y, w, h) in rects)


def _split_rect(rect, s, angle):
    """Place a square of side s with lower-left corner at rect's lower-left
    (rotation ignored for tiling guarantee; rotate only if fits axis-aligned).
    Split remaining L-shaped region into two rectangles."""
    x, y, w, h = rect
    if s <= 0:
        return [rect]
    if s > min(w, h) + 1e-12:
        return None
    # Axis-aligned placement at lower-left
    rem = []
    # right strip
    if w - s > 1e-12:
        rem.append((x + s, y, w - s, h))
    # top strip (over the square width)
    if h - s > 1e-12:
        rem.append((x, y + s, s, h - s))
    # Also consider placing at top-left or bottom-right for better packing
    return rem


def _greedy_pack(n):
    """Greedy: always place largest square in some free rectangle, splitting it.
    Use a few placement variants and pick best by resulting potential."""
    if n <= 0:
        return []
    rects = [(0.0, 0.0, 1.0, 1.0)]
    squares = []

    for _ in range(n):
        best = None
        best_score = -1
        for i, r in enumerate(rects):
            x, y, w, h = r
            s = min(w, h)
            if s <= 1e-12:
                continue
            # Try placements: lower-left, and sometimes centered variants
            # Score: prefer placing large square, minimize waste compactness
            # We'll try a few candidate side lengths near s
            for frac in (1.0, 0.9, 0.8, 0.7, 0.6, 0.5):
                ss = s * frac
                if ss <= 1e-12:
                    continue
                # split
                new_rects = []
                valid = True
                for j, rr in enumerate(rects):
                    if j == i:
                        sub = _split_rect(rr, ss, 0.0)
                        if sub is None:
                            valid = False
                            break
                        new_rects.extend(sub)
                    else:
                        new_rects.append(rr)
                if not valid:
                    continue
                # Score: total area of free rects after placement
                free_area = _rects_area(new_rects)
                score = ss - free_area * 0.001 + frac * 0.001
                if score > best_score:
                    best_score = score
                    best = (ss, x + ss * 0.5, y + ss * 0.5, new_rects)
        if best is None:
            # fallback: zero square
            squares.append((0.5, 0.5, 0.0, 0.0))
            continue
        s, cx, cy, new_rects = best
        squares.append((cx, cy, 0.0, s))
        rects = new_rects

    return squares


def _improve(squares, iterations=20000, seed=12345):
    """Local search: randomly perturb one square's side or position, accept if
    total side increases and no overlap. Since we keep axis-aligned tiling from
    greedy packing, we need to redo packing. Instead, we do a direct positional
    optimization preserving non-overlap via separation constraints.

    Simpler: use the greedy result and do a coordinate descent by re-running
    greedy with small random changes to tie-breaking. This is a heuristic.
    """
    rng = random.Random(seed)
    best = list(squares)
    best_sum = sum(s[3] for s in best)
    n = len(best)
    if n == 0:
        return best

    # Simple approach: for each square, try increasing size and checking
    # if it can fit by pushing others. Too complex. Instead, do nothing
    # beyond the greedy for now, but try different tie-break random seeds.
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Run greedy with different random perturbations of choice, keep best
    import random
    rng = random.Random(42)

    best_squares = None
    best_sum = -1

    # Try many runs of a randomized greedy
    for trial in range(30):
        rects = [(0.0, 0.0, 1.0, 1.0)]
        squares = []
        ok = True
        for _ in range(n):
            # collect candidate placements
            cands = []
            for i, r in enumerate(rects):
                x, y, w, h = r
                s = min(w, h)
                if s <= 1e-12:
                    continue
                # candidate side lengths
                for frac in (1.0, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3):
                    ss = s * frac
                    if ss <= 1e-12:
                        continue
                    # try different positions within rect
                    for px in (0.0, 0.5 * (w - ss) if w > ss else 0.0):
                        for py in (0.0, 0.5 * (h - ss) if h > ss else 0.0):
                            if px + ss > w + 1e-12 or py + ss > h + 1e-12:
                                continue
                            cands.append((ss, i, x + px, y + py, px, py))
            if not cands:
                squares.append((0.5, 0.5, 0.0, 0.0))
                continue
            # randomized selection weighted towards larger squares
            cands.sort(key=lambda c: -c[0])
            # add noise
            if trial > 0:
                k = min(len(cands), max(1, len(cands) // 3))
                pick_pool = cands[:k]
                choice = rng.choice(pick_pool)
            else:
                choice = cands[0]

            ss, ri, cx_ll, cy_ll, px, py = choice
            # place axis-aligned at (cx_ll, cy_ll) lower-left
            x, y, w, h = rects[ri]
            # Build new rect list
            new_rects = []
            for j, rr in enumerate(rects):
                if j != ri:
                    new_rects.append(rr)
                    continue
                rx, ry, rw, rh = rr
                # Remove square [cx_ll, cx_ll+ss] x [cy_ll, cy_ll+ss] from rr
                # Left strip
                if cx_ll - rx > 1e-12:
                    new_rects.append((rx, ry, cx_ll - rx, rh))
                # Right strip
                if rx + rw - (cx_ll + ss) > 1e-12:
                    new_rects.append((cx_ll + ss, ry, rx + rw - (cx_ll + ss), rh))
                # Bottom strip under square (within x-range of square)
                if cy_ll - ry > 1e-12:
                    new_rects.append((cx_ll, ry, ss, cy_ll - ry))
                # Top strip above square
                if ry + rh - (cy_ll + ss) > 1e-12:
                    new_rects.append((cx_ll, cy_ll + ss, ss, ry + rh - (cy_ll + ss)))
            rects = new_rects
            squares.append((cx_ll + ss * 0.5, cy_ll + ss * 0.5, 0.0, ss))

        total = sum(s[3] for s in squares)
        if total > best_sum:
            best_sum = total
            best_squares = squares

    # Clamp all to [0,1]
    result = []
    for (cx, cy, ang, s) in best_squares:
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        result.append((cx, cy, ang, s))

    # Ensure exactly n
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
