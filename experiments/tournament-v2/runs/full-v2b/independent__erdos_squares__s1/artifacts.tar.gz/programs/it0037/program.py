import math
import random
import numpy as np
from scipy.optimize import minimize


def _square_corners(cx, cy, angle, side):
    a = 2.0 * math.pi * angle
    c, s = math.cos(a), math.sin(a)
    h = 0.5 * side
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + c * dx - s * dy
        y = cy + s * dx + c * dy
        pts.append((x, y))
    return pts


def _poly_area(poly):
    if len(poly) < 3:
        return 0.0
    s = 0.0
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        s += x1 * y2 - x2 * y1
    return 0.5 * abs(s)


def _inside_unit(poly, tol=1e-9):
    for x, y in poly:
        if x < -tol or x > 1.0 + tol or y < -tol or y > 1.0 + tol:
            return False
    return True


def _clip_convex(subject, clip):
    if not subject:
        return []
    out = subject[:]
    n = len(clip)
    for i in range(n):
        a = clip[i]
        b = clip[(i + 1) % n]
        ex = b[0] - a[0]
        ey = b[1] - a[1]
        inside_prev = None
        new_out = []
        m = len(out)
        for j in range(m):
            p = out[j]
            q = out[(j + 1) % m]
            px = p[0] - a[0]
            py = p[1] - a[1]
            qx = q[0] - a[0]
            qy = q[1] - a[1]
            pin = ex * py - ey * px >= -1e-12
            qin = ex * qy - ey * qx >= -1e-12
            if pin:
                new_out.append(p)
            if pin != qin:
                dx = q[0] - p[0]
                dy = q[1] - p[1]
                den = ex * dy - ey * dx
                if abs(den) > 1e-18:
                    t = (ex * py - ey * px) / den
                    ix = p[0] + t * dx
                    iy = p[1] + t * dy
                    new_out.append((ix, iy))
        out = new_out
        if not out:
            return []
    return out


def _overlap_pair(p1, p2):
    inter = _clip_convex(p1, p2)
    if len(inter) < 3:
        return 0.0
    return _poly_area(inter)


def _is_valid_one(sq, others, idx):
    cx, cy, ang, side = sq
    if side <= 1e-12:
        return True
    poly = _square_corners(cx, cy, ang, side)
    if not _inside_unit(poly):
        return False
    for j, o in enumerate(others):
        if j == idx:
            continue
        if o[3] <= 1e-12:
            continue
        po = _square_corners(o[0], o[1], o[2], o[3])
        if _overlap_pair(poly, po) > 1e-9:
            return False
    return True


def _greedy_valid(squares):
    squares = [list(s) for s in squares]
    n = len(squares)
    for i in range(n):
        if squares[i][3] <= 1e-12:
            continue
        if not _is_valid_one(squares[i], squares, i):
            lo, hi = 0.0, squares[i][3]
            ok = 0.0
            for _ in range(35):
                mid = 0.5 * (lo + hi)
                test = squares[i][:]
                test[3] = mid
                if _is_valid_one(test, squares, i):
                    ok = mid
                    lo = mid
                else:
                    hi = mid
            squares[i][3] = ok
    for i in range(n):
        if squares[i][3] > 1e-12:
            cx, cy, ang, side = squares[i]
            lo, hi = side, min(side * 3.0 + 1e-6, 2.0)
            if _is_valid_one([cx, cy, ang, hi], squares, i):
                squares[i][3] = hi
            else:
                for _ in range(35):
                    mid = 0.5 * (lo + hi)
                    test = [cx, cy, ang, mid]
                    if _is_valid_one(test, squares, i):
                        lo = mid
                    else:
                        hi = mid
                squares[i][3] = lo
    return squares


def _pack_energy(params, n):
    vals = params.reshape(n, 4)
    total = 0.0
    for i in range(n):
        cx, cy, ang, side = vals[i]
        if side < 0:
            side = 0.0
        total -= side
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang %= 1.0
        poly = _square_corners(cx, cy, ang, side)
        for x, y in poly:
            if x < 0:
                total += 300.0 * x * x
            elif x > 1:
                total += 300.0 * (x - 1) * (x - 1)
            if y < 0:
                total += 300.0 * y * y
            elif y > 1:
                total += 300.0 * (y - 1) * (y - 1)
    for i in range(n):
        cxi, cyi, angi, si = vals[i]
        if si <= 0:
            continue
        if not (0 <= cxi <= 1 and 0 <= cyi <= 1):
            continue
        if cxi < 0 or cxi > 1 or cyi < 0 or cyi > 1:
            continue
        pi = _square_corners(cxi, cyi, angi, si)
        if not _inside_unit(pi, 0.5):
            continue
        for j in range(i + 1, n):
            s_j = vals[j][3]
            if s_j <= 0:
                continue
            cxj, cyj = vals[j][0], vals[j][1]
            if cxj < 0 or cxj > 1 or cyj < 0 or cyj > 1:
                continue
            pj = _square_corners(cxj, cyj, vals[j][2], s_j)
            if not _inside_unit(pj, 0.5):
                continue
            dx = cxi - cxj
            dy = cyi - cyj
            r = 0.5 * (si + s_j) * 1.75
            if dx * dx + dy * dy > r * r:
                continue
            ov = _overlap_pair(pi, pj)
            if ov > 0:
                total += 200.0 * ov
    return total


def _coordinate_descent(squares, n, rounds=80):
    cur = [s[:] for s in squares]
    cur_sum = sum(s[3] for s in cur)
    best_sum = cur_sum
    best = [s[:] for s in cur]
    step = 0.08
    for rnd in range(rounds):
        improved = False
        for i in range(n):
            base = cur[i][:]
            for _ in range(6):
                trial = [s[:] for s in cur]
                dcx = random.uniform(-1, 1) * step
                dcy = random.uniform(-1, 1) * step
                da = random.uniform(-1, 1) * step * 0.5
                ds = random.uniform(-0.7, 1.0) * step * 0.5
                tx = base[0] + dcx
                ty = base[1] + dcy
                ta = (base[2] + da) % 1.0
                ts = max(0.0, base[3] + ds)
                if tx < 0 or tx > 1 or ty < 0 or ty > 1:
                    continue
                if ts <= 0:
                    continue
                trial[i] = [tx, ty, ta, ts]
                tv = _greedy_valid(trial)
                tsum = sum(s[3] for s in tv)
                if tsum > cur_sum + 1e-12:
                    cur = tv
                    cur_sum = tsum
                    improved = True
                    if tsum > best_sum:
                        best_sum = tsum
                        best = [s[:] for s in tv]
        if not improved:
            step *= 0.5
            if step < 1e-4:
                break
    return best


def _initial_grid(n):
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    rem = n - len(squares)
    for _ in range(rem):
        squares.append([0.5, 0.5, 0.0, 0.0])
    return squares


def _initial_random(n, seed):
    rng = random.Random(seed)
    squares = []
    for _ in range(n):
        cx = rng.uniform(0.15, 0.85)
        cy = rng.uniform(0.15, 0.85)
        ang = rng.random()
        side = rng.uniform(0.02, 0.18)
        squares.append([cx, cy, ang, side])
    return squares


def solve(n):
    if n <= 0:
        return []
    candidates = []
    candidates.append(_initial_grid(n))
    for seed in (1, 2, 3, 4):
        candidates.append(_initial_random(n, seed))
    best = None
    best_sum = -1.0
    import time
    t0 = time.time()
    for sq in candidates:
        v = _greedy_valid(sq)
        s = sum(x[3] for x in v)
        if s > best_sum:
            best_sum = s
            best = v
        if time.time() - t0 > 20:
            break
    if best is None:
        best = _greedy_valid(_initial_grid(n))
    try:
        improved = _coordinate_descent(best, n, rounds=60)
        s = sum(x[3] for x in improved)
        if s > best_sum:
            best_sum = s
            best = improved
    except Exception:
        pass
    out = []
    for cx, cy, ang, side in best:
        if side <= 1e-12:
            out.append((0.5, 0.5, 0.0, 0.0))
        else:
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
            out.append((cx, cy, ang % 1.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
