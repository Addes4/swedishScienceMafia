import math
import random

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    def key(x):
        return x

    def pack_from_sizes(sizes):
        # Greedy packing into unit square by sorting descending and placing on a grid-like shelf
        # but with rotation allowed we use simple non-overlap heuristic: split into rows
        sizes = list(sizes)
        # use strip packing by rows: choose row heights
        total = sum(sizes)
        if total <= 0:
            return [(0.5, 0.5, 0.0, 0.0)] * n
        # attempt several layouts and keep best
        best = None
        best_sum = -1
        for trial in range(40):
            order = list(range(n))
            random.shuffle(order)
            # sort by size descending mostly
            if trial < 20:
                order.sort(key=lambda i: -sizes[i])
            # shelf packing
            x = 0.0
            y = 0.0
            row_h = 0.0
            placed = [None] * n
            ok = True
            for idx in order:
                s = sizes[idx]
                if s <= 0:
                    placed[idx] = (0.5, 0.5, 0.0, 0.0)
                    continue
                if x + s > 1.0 + 1e-12:
                    y += row_h
                    x = 0.0
                    row_h = 0.0
                if y + s > 1.0 + 1e-12:
                    ok = False
                    break
                placed[idx] = (x + s/2, y + s/2, 0.0, s)
                x += s
                if s > row_h:
                    row_h = s
            if ok:
                tot = sum(p[3] for p in placed if p is not None)
                if tot > best_sum:
                    best_sum = tot
                    best = placed
        if best is None:
            # fallback grid
            k = math.isqrt(n)
            side = 1.0 / k if k > 0 else 0.0
            best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
            best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
            best = best[:n]
        return best

    # initial: grid
    k = math.isqrt(n)
    sizes = []
    side = 1.0 / k if k > 0 else 0.0
    for _ in range(k * k):
        sizes.append(side)
    while len(sizes) < n:
        sizes.append(0.0)

    best_sizes = list(sizes)
    best_val = sum(best_sizes)
    current = list(sizes)

    # local search: try moving mass from smaller squares to larger ones
    for it in range(3000):
        i = random.randrange(n)
        j = random.randrange(n)
        if i == j:
            continue
        if current[i] <= 1e-9:
            continue
        delta = current[i] * random.random() * 0.3
        if delta <= 0:
            continue
        cand = list(current)
        cand[i] -= delta
        cand[j] += delta
        # quick feasibility: sum of squares of sides <= 1? necessary not sufficient
        # use pack test
        if sum(cand) > best_val + 1e-9 or random.random() < 0.05:
            packed = pack_from_sizes(cand)
            val = sum(p[3] for p in packed)
            if val > best_val - 1e-9:
                current = cand
                if val > best_val:
                    best_val = val
                    best_sizes = list(cand)
    # final pack
    res = pack_from_sizes(best_sizes)
    # ensure length
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
