import math
import numpy as np
from scipy.optimize import minimize

def _overlap_penalty(squares):
    """Penalty for overlapping interiors and out-of-bounds squares."""
    n = len(squares)
    pen = 0.0
    # Precompute corners
    corners = []
    for (cx, cy, ang, s) in squares:
        if s <= 0:
            corners.append(np.zeros((4, 2)))
            continue
        a = ang * 2 * math.pi
        c, sn = math.cos(a), math.sin(a)
        hs = s / 2.0
        # local corners relative to center
        local = np.array([[-hs, -hs], [hs, -hs], [hs, hs], [-hs, hs]])
        rot = np.array([[c, -sn], [sn, c]])
        corners.append(local @ rot.T + np.array([cx, cy]))
    # Boundary penalty (exact for square: all corners inside [0,1])
    for i in range(n):
        if squares[i][3] <= 0:
            continue
        c = corners[i]
        for j in range(4):
            x, y = c[j]
            if x < 0:
                pen += 1e4 * x * x
            if x > 1:
                pen += 1e4 * (x - 1) ** 2
            if y < 0:
                pen += 1e4 * y * y
            if y > 1:
                pen += 1e4 * (y - 1) ** 2

    # Overlap penalty via separating axis theorem (SAT)
    # For two convex polygons, if they don't overlap, some axis separates them.
    # We use a soft penalty based on maximum penetration depth.
    for i in range(n):
        if squares[i][3] <= 0:
            continue
        ci = corners[i]
        for j in range(i + 1, n):
            if squares[j][3] <= 0:
                continue
            cj = corners[j]
            # SAT for two rotated squares
            # Axes: normals of edges of both squares (8 axes total)
            axes = []
            for poly in (ci, cj):
                for k in range(4):
                    edge = poly[(k + 1) % 4] - poly[k]
                    axis = np.array([-edge[1], edge[0]])
                    norm = np.linalg.norm(axis)
                    if norm > 1e-12:
                        axes.append(axis / norm)

            min_overlap = 1e10
            separated = False
            for ax in axes:
                pi = ci @ ax
                pj = cj @ ax
                overlap = min(pi.max(), pj.max()) - max(pi.min(), pj.min())
                if overlap <= 0:
                    separated = True
                    break
                if overlap < min_overlap:
                    min_overlap = overlap
            if not separated:
                pen += 1e5 * min_overlap * min_overlap
    return pen

def _neg_sum(squares):
    return -sum(s[3] for s in squares)

def _objective(params, n, base_squares):
    squares = []
    for i in range(n):
        cx, cy, ang, s = params[4*i:4*i+4]
        # clamp angle to [0,1) and side >=0
        ang = ang % 1.0
        s = max(0.0, s)
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        squares.append((cx, cy, ang, s))
    pen = _overlap_penalty(squares)
    return -sum(sq[3] for sq in squares) + pen

def _initial_guess(n):
    """Generate an initial configuration: grid plus possibly rotated squares."""
    squares = []
    if n == 0:
        return squares
    if n == 1:
        # one square can be side 1
        return [(0.5, 0.5, 0.0, 1.0)]
    # Try a grid that fits all n in a k x k arrangement
    k = math.isqrt(n)
    if k * k == n:
        side = 1.0 / k
        for i in range(k):
            for j in range(k):
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        return squares[:n]
    # otherwise, use a combination: some larger squares plus smaller ones
    # Simple heuristic: place k*k squares in grid, then remaining squares
    # as small squares in the leftover space. But we can do better:
    # Use a base tiling: find the largest square side s such that we can pack
    # m squares of side s, then fill rest with smaller.
    best = None
    best_sum = -1

    # Try different numbers of rows/cols for the large squares
    for rows in range(1, n + 1):
        for cols in range(1, n + 1):
            if rows * cols > n:
                continue
            m = rows * cols
            remaining = n - m
            # large squares fill the unit square: side = min(1/rows, 1/cols)
            side_large = min(1.0 / rows, 1.0 / cols)
            if side_large <= 0:
                continue
            total_sum = m * side_large
            # remaining squares: give them very small sides initially
            # but we'll let optimizer improve. However, we can estimate a better
            # initial allocation: distribute remaining area among remaining squares.
            # The leftover area after placing large squares:
            # (1 - rows*side_large) * (1 - cols*side_large) approx? Not exactly.
            # We'll just give each remaining square side = side_large / (remaining+1)
            if remaining > 0:
                side_rem = side_large / (remaining + 1)
                total_sum += remaining * side_rem
            if total_sum > best_sum:
                best_sum = total_sum
                best = (rows, cols, side_large, remaining, side_rem if remaining > 0 else 0)

    if best is None:
        # fallback: all squares tiny
        s = 1.0 / math.sqrt(n)
        return [(0.5, 0.5, 0.0, s) for _ in range(n)]

    rows, cols, side_large, remaining, side_rem = best
    # Place large squares in a grid, centered
    # We can center the grid: left offset = (1 - cols*side_large)/2
    # top offset = (1 - rows*side_large)/2
    off_x = (1.0 - cols * side_large) / 2.0
    off_y = (1.0 - rows * side_large) / 2.0
    for i in range(rows):
        for j in range(cols):
            cx = off_x + (j + 0.5) * side_large
            cy = off_y + (i + 0.5) * side_large
            squares.append((cx, cy, 0.0, side_large))
    # Place remaining squares in the leftover area at the right/bottom or wherever
    # Just scatter them in the unit square with small size
    if remaining > 0:
        # try to place them in a row below the grid
        # or in the leftover strip
        # simplest: place along the bottom edge
        for idx in range(remaining):
            # position them in the strip at bottom
            # distribute evenly
            if remaining == 1:
                cx = 0.5
                cy = 1.0 - side_rem / 2.0
            else:
                cx = (idx + 0.5) / remaining
                cy = 1.0 - side_rem / 2.0
            squares.append((cx, cy, 0.0, side_rem))

    return squares[:n]

def _optimize(n, initial):
    """Run L-BFGS-B optimization on the configuration."""
    if n == 0:
        return []
    # Build parameter vector: [cx, cy, angle, side] * n
    x0 = []
    for (cx, cy, ang, s) in initial:
        x0.extend([cx, cy, ang, s])
    x0 = np.array(x0)

    # Bounds: cx, cy in [0,1], angle free (we'll wrap), side in [0, 1]
    bounds = []
    for _ in range(n):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (None, None), (0.0, 1.0)])

    # Use a few restarts with perturbation
    best_result = None
    best_val = float('inf')
    for restart in range(3):
        if restart == 0:
            x_init = x0.copy()
        else:
            # perturb
            x_init = x0 + np.random.randn(len(x0)) * 0.01
            # clamp cx, cy, side
            for i in range(n):
                x_init[4*i] = max(0.0, min(1.0, x_init[4*i]))
                x_init[4*i+1] = max(0.0, min(1.0, x_init[4*i+1]))
                x_init[4*i+3] = max(0.0, x_init[4*i+3])

        try:
            res = minimize(
                _objective, x_init, args=(n, initial),
                method='L-BFGS-B', bounds=bounds,
                options={'maxiter': 200, 'ftol': 1e-8, 'gtol': 1e-6}
            )
            if res.fun < best_val:
                best_val = res.fun
                best_result = res.x
        except Exception:
            continue

    if best_result is None:
        return initial

    # Decode
    squares = []
    for i in range(n):
        cx, cy, ang, s = best_result[4*i:4*i+4]
        s = max(0.0, s)
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = ang % 1.0
        squares.append((cx, cy, ang, s))

    # Verify no overlaps and fix if necessary
    # (simple check: if any overlap, reduce sizes slightly)
    squares = _fix_overlaps(squares)
    return squares

def _fix_overlaps(squares):
    """Check for overlaps and shrink squares if needed to ensure validity."""
    n = len(squares)
    if n == 0:
        return squares
    # Compute corners
    def get_corners(cx, cy, ang, s):
        if s <= 0:
            return np.zeros((4, 2))
        a = ang * 2 * math.pi
        c, sn = math.cos(a), math.sin(a)
        hs = s / 2.0
        local = np.array([[-hs, -hs], [hs, -hs], [hs, hs], [-hs, hs]])
        rot = np.array([[c, -sn], [sn, c]])
        return local @ rot.T + np.array([cx, cy])

    # Check boundary
    result = []
    for sq in squares:
        cx, cy, ang, s = sq
        corners = get_corners(cx, cy, ang, s)
        # shrink until all corners inside
        max_scale = 1.0
        for (x, y) in corners:
            if s > 0:
                # scaling by factor f moves corners towards center
                # find f such that corner stays inside
                # corner = center + f * (corner - center)
                dx = x - cx
                dy = y - cy
                # need cx + f*dx in [0,1], cy + f*dy in [0,1]
                if dx > 1e-12:
                    f = (1.0 - cx) / dx
                    if f < max_scale:
                        max_scale = f
                elif dx < -1e-12:
                    f = (0.0 - cx) / dx
                    if f < max_scale:
                        max_scale = f
                if dy > 1e-12:
                    f = (1.0 - cy) / dy
                    if f < max_scale:
                        max_scale = f
                elif dy < -1e-12:
                    f = (0.0 - cy) / dy
                    if f < max_scale:
                        max_scale = f
        s = s * max(0.0, min(1.0, max_scale))
        result.append((cx, cy, ang, s))

    # Now iterate pairwise overlap resolution
    for _ in range(20):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                si = result[i]
                sj = result[j]
                if si[3] <= 0 or sj[3] <= 0:
                    continue
                # check overlap using SAT
                ci = get_corners(*si)
                cj = get_corners(*sj)
                axes = []
                for poly in (ci, cj):
                    for k in range(4):
                        edge = poly[(k + 1) % 4] - poly[k]
                        axis = np.array([-edge[1], edge[0]])
                        norm = np.linalg.norm(axis)
                        if norm > 1e-12:
                            axes.append(axis / norm)
                overlap = 1e10
                separated = False
                for ax in axes:
                    pi = ci @ ax
                    pj = cj @ ax
                    ov = min(pi.max(), pj.max()) - max(pi.min(), pj.min())
                    if ov <= 1e-9:
                        separated = True
                        break
                    overlap = min(overlap, ov)
                if not separated:
                    # shrink both slightly
                    shrink = 0.95
                    result[i] = (si[0], si[1], si[2], si[3] * shrink)
                    result[j] = (sj[0], sj[1], sj[2], sj[3] * shrink)
                    changed = True
        if not changed:
            break

    return result

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Try several initial configurations and pick the best after optimization
    best_squares = None
    best_sum = -1.0

    # Candidate 1: grid-based initial
    init1 = _initial_guess(n)
    opt1 = _optimize(n, init1)
    sum1 = sum(sq[3] for sq in opt1)
    if sum1 > best_sum:
        best_sum = sum1
        best_squares = opt1

    # Candidate 2: all squares in a row (for small n)
    if n <= 5:
        side = 1.0 / n
        init2 = [((i + 0.5) * side, 0.5, 0.0, side) for i in range(n)]
        opt2 = _optimize(n, init2)
        sum2 = sum(sq[3] for sq in opt2)
        if sum2 > best_sum:
            best_sum = sum2
            best_squares = opt2

    # Candidate 3: one big square plus rest small
    if n >= 2:
        init3 = [(0.5, 0.5, 0.0, 1.0)] + [(0.5, 0.5, 0.0, 1e-6)] * (n - 1)
        opt3 = _optimize(n, init3)
        sum3 = sum(sq[3] for sq in opt3)
        if sum3 > best_sum:
            best_sum = sum3
            best_squares = opt3

    # Candidate 4: for n that is perfect square, grid
    k = math.isqrt(n)
    if k * k == n and n > 1:
        side = 1.0 / k
        init4 = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        opt4 = _optimize(n, init4)
        sum4 = sum(sq[3] for sq in opt4)
        if sum4 > best_sum:
            best_sum = sum4
            best_squares = opt4

    # Candidate 5: quadtree-like subdivision
    if n >= 4:
        init5 = _quadtree_init(n)
        if init5:
            opt5 = _optimize(n, init5)
            sum5 = sum(sq[3] for sq in opt5)
            if sum5 > best_sum:
                best_sum = sum5
                best_squares = opt5

    if best_squares is None:
        best_squares = _initial_guess(n)

    # Ensure exactly n squares
    best_squares = best_squares[:n]
    while len(best_squares) < n:
        best_squares.append((0.5, 0.5, 0.0, 0.0))

    return best_squares

def _quadtree_init(n):
    """Generate initial configuration by recursively subdividing the unit square."""
    squares = []
    def subdivide(x, y, w, h, count):
        if count <= 0:
            return
        if count == 1:
            side = min(w, h)
            squares.append((x + w/2, y + h/2, 0.0, side))
            return
        # split into 4 quadrants
        w2, h2 = w/2, h/2
        # distribute count among quadrants proportionally to area
        total_area = w * h
        areas = [w2*h2]*4
        # distribute remaining count
        rem = count
        for i in range(4):
            if rem <= 0:
                break
            qx = x + (i % 2) * w2
            qy = y + (i // 2) * h2
            # allocate at least 1
            alloc = max(1, int(round(count * areas[i] / total_area)))
            alloc = min(alloc, rem)
            if i == 3:
                alloc = rem
            subdivide(qx, qy, w2, h2, alloc)
            rem -= alloc
    subdivide(0.0, 0.0, 1.0, 1.0, n)
    return squares[:n]
