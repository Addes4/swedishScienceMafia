import math
import random

def solve(n):
    # Greedy: place squares one by one, each as large as possible with a rotation search.
    # Then improve with local search moves (shrink/move/rotate) to grow smaller ones.
    random.seed(12345 + n)
    
    def overlaps(a, b):
        # a, b = (cx, cy, angle, side); check interior overlap of two rotated squares.
        # Use separating axis theorem.
        if a[3] <= 0 or b[3] <= 0:
            return False
        axes = []
        for s in (a, b):
            th = s[2] * 2 * math.pi
            c, si = math.cos(th), math.sin(th)
            axes.append((c, si))
            axes.append((-si, c))
        for (ax, ay) in axes:
            pa = proj(a, ax, ay)
            pb = proj(b, ax, ay)
            if pa[1] <= pb[0] + 1e-12 or pb[1] <= pa[0] + 1e-12:
                return False
        return True

    def proj(s, ax, ay):
        cx, cy, ang, side = s
        th = ang * 2 * math.pi
        c, si = math.cos(th), math.sin(th)
        h = side / 2
        # 4 corners
        pts = []
        for dx, dy in ((h, h), (h, -h), (-h, h), (-h, -h)):
            x = cx + dx * c - dy * si
            y = cy + dx * si + dy * c
            pts.append(x * ax + y * ay)
        return (min(pts), max(pts))

    def fits_inside(s):
        cx, cy, ang, side = s
        th = ang * 2 * math.pi
        c, si = math.cos(th), math.sin(th)
        h = side / 2
        for dx, dy in ((h, h), (h, -h), (-h, h), (-h, -h)):
            x = cx + dx * c - dy * si
            y = cy + dx * si + dy * c
            if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                return False
        return True

    def find_largest(placed):
        # Search candidates: try many rotations and centers; return best (s) that fits.
        best = (0.5, 0.5, 0.0, 0.0)
        best_s = 0.0
        # candidate rotations
        angles = [0.0, 0.25, 0.125, 0.375]
        if n >= 20:
            angles = [i / 64.0 for i in range(64)]
        # For given angle, largest square fits where? Use binary search on side and grid search on center.
        for ang in angles:
            th = ang * 2 * math.pi
            c, si = math.cos(th), math.sin(th)
            # bounding box half-extent for side s: (|c|+|si|)*s/2 in x and y
            k = (abs(c) + abs(si)) / 2.0
            # max side inside unit square for this angle
            max_side = 1.0 / (2 * k) if k > 0 else 1.0
            if max_side <= best_s:
                continue
            # try grid of centers
            G = 6
            bs = 0.0
            bc = (0.5, 0.5)
            for gi in range(G):
                for gj in range(G):
                    cx = (gi + 0.5) / G
                    cy = (gj + 0.5) / G
                    # binary search largest side centered at (cx,cy) with angle ang
                    lo, hi = 0.0, max_side
                    # check feasibility via sampling
                    for _ in range(36):
                        mid = (lo + hi) / 2
                        s = (cx, cy, ang, mid)
                        if mid <= 0 or (fits_inside(s) and not any(overlaps(s, p) for p in placed)):
                            lo = mid
                        else:
                            hi = mid
                    if lo > bs:
                        bs = lo
                        bc = (cx, cy)
            if bs > best_s:
                best_s = bs
                best = (bc[0], bc[1], ang, bs)
        return best

    squares = []
    remaining = n
    # Place in "rounds": interleave sizes so smaller squares can fill gaps later.
    for _ in range(n):
        s = find_largest(squares)
        squares.append(s)
    # If any zero, fine. Now local improvement: try to grow each square.
    for _ in range(3):
        improved = False
        for i in range(len(squares)):
            others = [squares[j] for j in range(len(squares)) if j != i]
            # try to grow square i: search slightly perturbed center/angle and larger side
            cur = squares[i]
            best = cur
            for dax in (-0.03, 0, 0.03):
                for day in (-0.03, 0, 0.03):
                    for dang in (-0.02, 0, 0.02):
                        cx = cur[0] + dax
                        cy = cur[1] + day
                        ang = (cur[2] + dang) % 1.0
                        # binary search max side
                        lo, hi = cur[3], min(1.0, cur[3] + 0.2)
                        for _ in range(30):
                            mid = (lo + hi) / 2
                            s = (cx, cy, ang, mid)
                            if fits_inside(s) and not any(overlaps(s, p) for p in others):
                                lo = mid
                            else:
                                hi = mid
                        if lo > best[3] + 1e-12:
                            best = (cx, cy, ang, lo)
            if best[3] > cur[3] + 1e-12:
                squares[i] = best
                improved = True
        if not improved:
            break

    # clamp all to [0,1] and ensure validity
    out = []
    for s in squares:
        cx = min(max(s[0], 0.0), 1.0)
        cy = min(max(s[1], 0.0), 1.0)
        ang = s[2] % 1.0
        side = max(0.0, min(s[3], 1.0))
        out.append((cx, cy, ang, side))
    # final cleanup: zero out any square that now overlaps earlier ones
    final = []
    for s in out:
        if all(not overlaps(s, t) for t in final) and fits_inside(s):
            final.append(s)
        else:
            final.append((0.5, 0.5, 0.0, 0.0))
    return final[:n]
