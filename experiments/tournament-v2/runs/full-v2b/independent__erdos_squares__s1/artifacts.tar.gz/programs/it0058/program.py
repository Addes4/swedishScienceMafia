import math
import numpy as np
from scipy.optimize import minimize


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # ---------- initial layout ----------
    # Best equal-square grid fit
    k = math.isqrt(n)
    side = 1.0 / k
    init = []
    for i in range(k):
        for j in range(k):
            init.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    # leftover squares: tiny size placed near centre
    while len(init) < n:
        # find a spot near an edge/corner to reduce interference
        idx = len(init) - k * k
        init.append([0.5, 0.5, 0.0, 0.0])

    init = np.array(init, dtype=float)  # each row: cx, cy, angle (fraction of full turn), side

    # ---------- helper: corners of a rotated square ----------
    def corners(cx, cy, ang, s):
        # ang is fraction of full turn; multiply by 2*pi to get radians
        a = ang * 2.0 * math.pi
        ca, sa = math.cos(a), math.sin(a)
        h = s * 0.5
        pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
        res = []
        for px, py in pts:
            rx = px * ca - py * sa + cx
            ry = px * sa + py * ca + cy
            res.append((rx, ry))
        return res

    # ---------- objective ----------
    # minimise negative sum of sides
    def objective(x):
        s = 0.0
        for i in range(n):
            s += x[4 * i + 3]
        return -s

    # ---------- constraints ----------
    constraints = []

    # --- bounds (box) ---
    bounds = []
    for i in range(n):
        # cx, cy in [0,1]; angle in [0,1); side in [0,1]
        bounds.append((0.0, 1.0))  # cx
        bounds.append((0.0, 1.0))  # cy
        bounds.append((0.0, 1.0))  # angle (can be any, but [0,1) is fine)
        bounds.append((0.0, 1.0))  # side

    # --- non-overlap constraints (separating axes) ---
    # For each pair, at least one separating axis must exist.
    # We formulate: for each pair, the minimum over the 4 candidate axes
    # of (projection gap) >= 0.  But that's non-smooth.
    # Instead use 4 inequalities per pair: for at least one axis, gap >= 0.
    # For SLSQP we need smooth inequalities.  We can use the standard
    # SAT formulation: compute the projection overlap along the 4 axes
    # (two from each square) and require min overlap <= 0.
    # This is non-smooth, so we approximate with soft-max/min.

    # Use a smooth approximation: softmin(v) = -log(sum(exp(-alpha*v)))/alpha
    # We'll require softmin(overlaps) <= 0.
    alpha = 50.0

    def overlap_along_axis(poly1, poly2, axis):
        # axis: (ax, ay) unit vector
        ax, ay = axis
        p1 = [ax * x + ay * y for x, y in poly1]
        p2 = [ax * x + ay * y for x, y in poly2]
        return min(max(p1) - min(p2), max(p2) - min(p1))

    def pair_constraint(x, i, j):
        # extract params
        xi = x[4 * i:4 * i + 4]
        xj = x[4 * j:4 * j + 4]
        c1 = corners(*xi)
        c2 = corners(*xj)
        # candidate axes: normals of each edge of each square
        axes = []
        for c in (c1, c2):
            for t in range(4):
                x1, y1 = c[t]
                x2, y2 = c[(t + 1) % 4]
                dx, dy = x2 - x1, y2 - y1
                L = math.hypot(dx, dy)
                if L > 1e-15:
                    axes.append((-dy / L, dx / L))
        # avoid duplicate axes
        uniq = []
        for a in axes:
            if not any(abs(a[0] - b[0]) + abs(a[1] - b[1]) < 1e-6 for b in uniq):
                uniq.append(a)
        if not uniq:
            return 0.0
        ovs = [overlap_along_axis(c1, c2, a) for a in uniq]
        # softmin
        m = min(ovs)
        s = sum(math.exp(-alpha * (v - m)) for v in ovs)
        softmin = m - math.log(s) / alpha
        return softmin

    for i in range(n):
        for j in range(i + 1, n):
            def make_con(i, j):
                def con(x):
                    return -pair_constraint(x, i, j)  # >= 0
                return con
            constraints.append({'type': 'ineq', 'fun': make_con(i, j)})

    # --- containment constraints ---
    for i in range(n):
        def make_contain(i):
            def con(x):
                xi = x[4 * i:4 * i + 4]
                c = corners(*xi)
                res = []
                for (px, py) in c:
                    res.append(px)
                    res.append(1.0 - px)
                    res.append(py)
                    res.append(1.0 - py)
                return np.array(res)
            return con
        constraints.append({'type': 'ineq', 'fun': make_contain(i)})

    # --- zero-size squares: they still need to be inside, which is automatic
    # but for safety we ensure side >= 0 by bounds. ---

    # ---------- optimise ----------
    x0 = init.flatten()
    # make sure sizes are feasible initially: shrink leftover zero-size squares
    # and scale down if overlap exists.  We'll just clamp side to be at most
    # a safe value based on grid.
    max_side = 1.0 / max(1, k)
    for i in range(n):
        if x0[4 * i + 3] > max_side:
            x0[4 * i + 3] = max_side * 0.99
    # For leftover squares, set a small non-zero size
    grid_count = k * k
    for i in range(grid_count, n):
        x0[4 * i + 3] = 0.01

    # slightly randomize to break symmetry?  No, keep deterministic.
    # run optimisation
    try:
        res = minimize(objective, x0, method='SLSQP', bounds=bounds,
                       constraints=constraints, options={'maxiter': 200, 'ftol': 1e-9})
        xf = res.x
    except Exception:
        xf = x0

    # ensure sum is not worse than initial
    if -objective(xf) < -objective(x0):
        xf = x0

    # extract result, clamp parameters to [0,1]
    out = []
    for i in range(n):
        cx = float(np.clip(xf[4 * i], 0.0, 1.0))
        cy = float(np.clip(xf[4 * i + 1], 0.0, 1.0))
        ang = float(np.clip(xf[4 * i + 2], 0.0, 1.0))
        side = float(np.clip(xf[4 * i + 3], 0.0, 1.0))
        out.append((cx, cy, ang, side))
    return out
