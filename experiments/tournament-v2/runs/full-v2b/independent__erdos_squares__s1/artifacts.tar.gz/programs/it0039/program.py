import math
import random

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Initial configuration: largest k x k grid plus zero-size squares.
    k = math.isqrt(n)
    base = 1.0 / k
    squares = [((i + 0.5) * base, (j + 0.5) * base, 0.0, base)
               for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    squares = squares[:n]

    def corners(cx, cy, ang, s):
        # Convert angle in turns to radians.
        a = ang * 2.0 * math.pi
        ca, sa = math.cos(a), math.sin(a)
        h = s * 0.5
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x = cx + dx * ca - dy * sa
            y = cy + dx * sa + dy * ca
            pts.append((x, y))
        return pts

    def overlap(sq1, sq2):
        # Separating axis theorem for convex polygons.
        cx1, cy1, a1, s1 = sq1
        cx2, cy2, a2, s2 = sq2
        if s1 <= 1e-12 or s2 <= 1e-12:
            return False
        p1 = corners(cx1, cy1, a1, s1)
        p2 = corners(cx2, cy2, a2, s2)
        for poly, other in ((p1, p2), (p2, p1)):
            for i in range(4):
                j = (i + 1) % 4
                ex = poly[j][0] - poly[i][0]
                ey = poly[j][1] - poly[i][1]
                axis = (-ey, ex)
                # Project both polygons.
                min1 = max1 = None
                for x, y in p1:
                    d = x * axis[0] + y * axis[1]
                    if min1 is None or d < min1: min1 = d
                    if max1 is None or d > max1: max1 = d
                min2 = max2 = None
                for x, y in p2:
                    d = x * axis[0] + y * axis[1]
                    if min2 is None or d < min2: min2 = d
                    if max2 is None or d > max2: max2 = d
                if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                    return False
        return True

    def inside(sq):
        cx, cy, ang, s = sq
        if s <= 1e-12:
            return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
        pts = corners(cx, cy, ang, s)
        for x, y in pts:
            if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
                return False
        return True

    def valid_config(sqs):
        for i in range(n):
            if not inside(sqs[i]):
                return False
        for i in range(n):
            if sqs[i][3] <= 1e-12:
                continue
            for j in range(i + 1, n):
                if sqs[j][3] <= 1e-12:
                    continue
                if overlap(sqs[i], sqs[j]):
                    return False
        return True

    def total(sqs):
        return sum(sq[3] for sq in sqs)

    # Local optimization: try to increase sizes and adjust positions/angles.
    def optimize(sqs, iterations=4000):
        cur = [list(sq) for sq in sqs]
        best = [list(sq) for sq in cur]
        best_val = total(cur)

        # Precompute which squares are non-zero.
        order = list(range(n))
        random.shuffle(order)

        for it in range(iterations):
            i = random.choice(order)
            old = cur[i][:]
            # Propose a change.
            kind = random.random()
            if kind < 0.55:
                # Try to enlarge or shrink slightly.
                delta = random.uniform(-0.03, 0.06)
                cur[i][3] = max(0.0, min(1.0, cur[i][3] + delta))
            elif kind < 0.8:
                # Translate.
                cur[i][0] += random.uniform(-0.03, 0.03)
                cur[i][1] += random.uniform(-0.03, 0.03)
                cur[i][0] = min(1.0, max(0.0, cur[i][0]))
                cur[i][1] = min(1.0, max(0.0, cur[i][1]))
            else:
                # Rotate.
                cur[i][2] = (cur[i][2] + random.uniform(-0.08, 0.08)) % 1.0

            # Accept if valid and improves or with small probability.
            if valid_config(cur):
                val = total(cur)
                if val > best_val - 1e-12 or random.random() < 0.002:
                    if val > best_val:
                        best_val = val
                        best = [x[:] for x in cur]
                else:
                    cur[i] = old
            else:
                cur[i] = old

            # Occasionally shrink a random square to allow growth elsewhere.
            if it % 500 == 499:
                j = random.choice(order)
                if cur[j][3] > 0.001:
                    cur[j][3] *= 0.98 if cur[j][3] < 0.5 else 0.995

        return best

    # Multiple restarts from perturbed grids.
    best_squares = [list(sq) for sq in squares]
    best_value = total(best_squares)

    trials = 8 if n <= 50 else (15 if n <= 200 else 25)
    local_iters = 3000 if n <= 50 else (5000 if n <= 200 else 8000)

    # Also try a spiral / concentric-like initialization for better starters.
    def initial_variant(variant):
        if variant == 0:
            return [list(sq) for sq in squares]
        sqs = [list(sq) for sq in squares]
        # Random perturbations of positions and sizes.
        for i in range(n):
            if sqs[i][3] > 1e-12:
                sqs[i][0] += random.uniform(-0.02, 0.02)
                sqs[i][1] += random.uniform(-0.02, 0.02)
                sqs[i][0] = min(1.0, max(0.0, sqs[i][0]))
                sqs[i][1] = min(1.0, max(0.0, sqs[i][1]))
                sqs[i][2] = random.uniform(0, 1)
                sqs[i][3] *= random.uniform(0.7, 1.05)
                sqs[i][3] = min(sqs[i][3], 1.0)
        # Ensure validity; if not, fall back.
        if not valid_config(sqs):
            return [list(sq) for sq in squares]
        return sqs

    for t in range(trials):
        if t == 0:
            init = [list(sq) for sq in squares]
        else:
            init = initial_variant(t)
        optimized = optimize(init, iterations=local_iters)
        val = total(optimized)
        if val > best_value:
            best_value = val
            best_squares = [x[:] for x in optimized]

    # Final cleanup: clamp and return.
    result = []
    for cx, cy, ang, s in best_squares:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = min(1.0, max(0.0, s))
        result.append((cx, cy, ang, s))
    return result
