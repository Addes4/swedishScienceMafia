import math
import random
import numpy as np
from scipy.optimize import minimize


# ---------------------------------------------------------------------------
# Basic geometry helpers
# ---------------------------------------------------------------------------

def _corners(cx, cy, ang, s):
    """Corners of a square with centre (cx, cy), angle = fraction of full turn, side s."""
    a = ang * 2.0 * math.pi
    c, t = math.cos(a), math.sin(a)
    h = 0.5 * s
    # local corners (axis aligned), then rotate
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * c - dy * t
        y = cy + dx * t + dy * c
        pts.append((x, y))
    return pts


def _inside(p):
    return -1e-12 <= p[0] <= 1.0 + 1e-12 and -1e-12 <= p[1] <= 1.0 + 1e-12


def _squares_overlap(sq1, sq2):
    """Return True if interiors of two squares overlap (robust SAT for convex quads)."""
    p1 = _corners(*sq1)
    p2 = _corners(*sq2)
    # separating axis test on both polygons' edge normals
    for poly in (p1, p2):
        m = len(poly)
        for i in range(m):
            a = poly[i]
            b = poly[(i + 1) % m]
            # outward normal
            nx = b[1] - a[1]
            ny = a[0] - b[0]
            # project both polygons
            min1 = min(x * nx + y * ny for x, y in p1)
            max1 = max(x * nx + y * ny for x, y in p1)
            min2 = min(x * nx + y * ny for x, y in p2)
            max2 = max(x * nx + y * ny for x, y in p2)
            if max1 < min2 - 1e-12 or max2 < min1 - 1e-12:
                return False
    return True


def _valid_layout(squares, tol=1e-9):
    for i in range(len(squares)):
        cx, cy, ang, s = squares[i]
        if s < -tol:
            return False
        if s <= tol:
            continue
        for p in _corners(cx, cy, ang, s):
            if p[0] < -tol or p[0] > 1 + tol or p[1] < -tol or p[1] > 1 + tol:
                return False
        for j in range(i + 1, len(squares)):
            if squares[j][3] <= tol:
                continue
            if _squares_overlap(squares[i], squares[j]):
                return False
    return True


# ---------------------------------------------------------------------------
# Penalty function for optimisation
# ---------------------------------------------------------------------------

# We optimise variables: for each square, (cx, cy, angle, side).
# Objective:  -sum(side) + PENALTY * violations

OUT_W = 1.0       # weight for out-of-bounds
OV_W = 1.0        # weight for overlap


def _unpack(v, n):
    v = np.asarray(v, dtype=float)
    sq = []
    for i in range(n):
        cx, cy, ang, s = v[4 * i:4 * i + 4]
        sq.append((cx, cy, ang, s))
    return sq


def _dist_out_of_bounds(cx, cy, ang, s):
    """Approximate penetration outside unit square (sum over corners)."""
    if s <= 0:
        pen = 0.0
        # point must be inside
        pen += max(0.0, -cx) ** 2 + max(0.0, cx - 1.0) ** 2
        pen += max(0.0, -cy) ** 2 + max(0.0, cy - 1.0) ** 2
        return pen
    pen = 0.0
    for x, y in _corners(cx, cy, ang, s):
        pen += max(0.0, -x) ** 2 + max(0.0, x - 1.0) ** 2
        pen += max(0.0, -y) ** 2 + max(0.0, y - 1.0) ** 2
    return pen


def _overlap_area(sq1, sq2):
    """Approximate overlap 'area' penalty via SAT overlap along axes (soft)."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 1e-12 or s2 <= 1e-12:
        return 0.0
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)
    # compute min overlap over all separating axes; if all positive -> overlapping
    best_min = float('inf')
    for poly in (p1, p2):
        m = len(poly)
        for i in range(m):
            ax = poly[i]
            bx = poly[(i + 1) % m]
            nx = bx[1] - ax[1]
            ny = ax[0] - bx[0]
            ln = math.hypot(nx, ny)
            if ln < 1e-15:
                continue
            nx /= ln
            ny /= ln
            vals1 = [x * nx + y * ny for x, y in p1]
            vals2 = [x * nx + y * ny for x, y in p2]
            min1, max1 = min(vals1), max(vals1)
            min2, max2 = min(vals2), max(vals2)
            ov = min(max1, max2) - max(min1, min2)
            if ov < best_min:
                best_min = ov
    if best_min <= 0.0:
        return 0.0
    # approximate overlap area as best_min^2 (capped)
    return best_min * best_min


def _objective(v, n):
    sq = _unpack(v, n)
    total_side = 0.0
    pen = 0.0
    for i in range(n):
        cx, cy, ang, s = sq[i]
        if s < 0:
            pen += 100.0 * s * s
            s = 0.0
        total_side += s
        pen += OUT_W * _dist_out_of_bounds(cx, cy, ang, s)
        for j in range(i + 1, n):
            cx2, cy2, ang2, s2 = sq[j]
            if s <= 1e-12 or s2 <= 1e-12:
                continue
            pen += OV_W * _overlap_area((cx, cy, ang, s), (cx2, cy2, ang2, s2))
    return -total_side + 100.0 * pen


# ---------------------------------------------------------------------------
# Initial layout generators
# ---------------------------------------------------------------------------

def _grid_layout(n, k):
    """k x k grid of squares: if n <= k*k, use k*k grid with some zero-size."""
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) < n:
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _guillotine_layout(n):
    """Recursively slice the unit square into rectangles, fill each with one axis-aligned square.
    Produce n rectangles (locale) and return centres+side as square. Some squares may be zero if rect too thin.
    """
    rects = [(0.0, 0.0, 1.0, 1.0)]
    while len(rects) < n:
        # pick the largest-area rectangle
        idx = max(range(len(rects)), key=lambda i: rects[i][2] * rects[i][3])
        x, y, w, h = rects.pop(idx)
        # split along longer dimension
        if w >= h:
            frac = 0.5 + random.uniform(-0.15, 0.15)
            frac = min(max(frac, 0.05), 0.95)
            w1 = w * frac
            w2 = w - w1
            rects.append((x, y, w1, h))
            rects.append((x + w1, y, w2, h))
        else:
            frac = 0.5 + random.uniform(-0.15, 0.15)
            frac = min(max(frac, 0.05), 0.95)
            h1 = h * frac
            h2 = h - h1
            rects.append((x, y, w, h1))
            rects.append((x, y + h1, w, h2))
    # each rectangle -> largest inscribed axis-aligned square
    squares = []
    for (x, y, w, h) in rects:
        s = min(w, h)
        cx = x + w / 2.0
        cy = y + h / 2.0
        squares.append((cx, cy, 0.0, s))
    return squares


def _best_grid_layout(n):
    best = None
    best_val = -1
    kmax = int(math.isqrt(n)) + 3
    for k in range(1, kmax + 1):
        if k * k < n:
            continue
        sq = _grid_layout(n, k)
        val = sum(x[3] for x in sq)
        if val > best_val:
            best_val = val
            best = sq
    return best


def _initial_layout(n, trials=8):
    candidates = []
    candidates.append(_best_grid_layout(n))
    for _ in range(trials):
        candidates.append(_guillotine_layout(n))
    # also, try grid with slightly smaller side (gap) to allow rotation
    for k in range(max(1, int(math.isqrt(n))), int(math.isqrt(n)) + 3):
        if k * k < n:
            continue
        side = 1.0 / k
        # shrink slightly
        for shrink in (0.95, 0.9):
            sq = []
            s = side * shrink
            for i in range(k):
                for j in range(k):
                    if len(sq) < n:
                        sq.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, s))
            while len(sq) < n:
                sq.append((0.5, 0.5, 0.0, 0.0))
            candidates.append(sq)
    best = None
    best_val = -1e18
    for c in candidates:
        v = _objective(np.array([x for sq in c for x in sq], dtype=float), n)
        if -v > best_val:
            best_val = -v
            best = c
    return best


# ---------------------------------------------------------------------------
# Optimisation wrapper
# ---------------------------------------------------------------------------

def _pack(squares):
    return np.array([x for sq in squares for x in sq], dtype=float)


def _repair(v, n):
    """Ensure boundaries and tiny overlaps are resolved by shrinking zeros / clamping."""
    sq = _unpack(v, n)
    out = []
    for cx, cy, ang, s in sq:
        s = max(0.0, s)
        # clamp centre
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        # if the square doesn't fit, shrink it
        if s > 0:
            # find max scale such that square inside
            # binary search scale
            lo, hi = 0.0, s
            for _ in range(40):
                mid = 0.5 * (lo + hi)
                ok = True
                for x, y in _corners(cx, cy, ang, mid):
                    if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
                        ok = False
                        break
                if ok:
                    lo = mid
                else:
                    hi = mid
            s = lo
        out.append((cx, cy, ang, s))
    return out


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side)."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345 + n)

    best_squares = _initial_layout(n, trials=6)
    best_val = sum(sq[3] for sq in best_squares)

    # Try several restarts with local optimisation
    n_restarts = 3
    for r in range(n_restarts):
        if r == 0:
            init = [list(x) for x in best_squares]
        else:
            init = [list(x) for x in _initial_layout(n, trials=4)]
            # add random perturbation
            for sq in init:
                sq[0] += random.uniform(-0.01, 0.01)
                sq[1] += random.uniform(-0.01, 0.01)
                sq[2] += random.uniform(-0.02, 0.02)
                sq[3] *= random.uniform(0.95, 1.0)
                sq[0] = min(max(sq[0], 0.0), 1.0)
                sq[1] = min(max(sq[1], 0.0), 1.0)
        v0 = _pack(init)

        try:
            res = minimize(
                _objective, v0, args=(n,),
                method='L-BFGS-B',
                options={'maxiter': 600, 'ftol': 1e-14, 'gtol': 1e-10},
            )
            v = res.x
        except Exception:
            v = v0

        sq = _repair(v, n)
        # greedy repair: remove tiny overlaps by shrinking smaller square
        sq = _remove_overlaps(sq)

        val = sum(x[3] for x in sq)
        if val > best_val:
            best_val = val
            best_squares = [list(x) for x in sq]

    # final validity fix
    best_squares = _remove_overlaps([list(x) for x in best_squares])

    # ensure exact n
    while len(best_squares) < n:
        best_squares.append((0.5, 0.5, 0.0, 0.0))
    best_squares = best_squares[:n]

    # final safety: if invalid, fall back to grid
    if not _valid_layout(best_squares):
        k = math.isqrt(n)
        kk = k
        while kk * kk < n:
            kk += 1
        return _grid_layout(n, kk)

    return [(float(x[0]), float(x[1]), float(x[2]), float(x[3])) for x in best_squares]


def _remove_overlaps(squares):
    """Greedy: while overlaps exist, shrink the smaller of the two overlapping squares."""
    sq = [list(x) for x in squares]
    for _ in range(200):
        changed = False
        for i in range(len(sq)):
            if sq[i][3] <= 0:
                continue
            # boundary fix
            cx, cy, ang, s = sq[i]
            for x, y in _corners(cx, cy, ang, s):
                if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                    # shrink
                    lo, hi = 0.0, s
                    for _ in range(30):
                        mid = 0.5 * (lo + hi)
                        ok = all(-1e-9 <= px <= 1 + 1e-9 and -1e-9 <= py <= 1 + 1e-9
                                 for px, py in _corners(cx, cy, ang, mid))
                        if ok:
                            lo = mid
                        else:
                            hi = mid
                    sq[i][3] = lo
                    changed = True
                    break
        for i in range(len(sq)):
            if sq[i][3] <= 0:
                continue
            for j in range(i + 1, len(sq)):
                if sq[j][3] <= 0:
                    continue
                sqi = tuple(sq[i])
                sqj = tuple(sq[j])
                if _squares_overlap(sqi, sqj):
                    # shrink smaller one
                    if sq[i][3] <= sq[j][3]:
                        idx = i
                    else:
                        idx = j
                    cx, cy, ang, s = sq[idx]
                    lo, hi = 0.0, s
                    for _ in range(32):
                        mid = 0.5 * (lo + hi)
                        other = sq[j] if idx == i else sq[i]
                        ok = True
                        for x, y in _corners(cx, cy, ang, mid):
                            if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                                ok = False
                                break
                        if ok and not _squares_overlap((cx, cy, ang, mid), tuple(other)):
                            lo = mid
                        else:
                            hi = mid
                    sq[idx][3] = lo
                    changed = True
        if not changed:
            break
    return sq
