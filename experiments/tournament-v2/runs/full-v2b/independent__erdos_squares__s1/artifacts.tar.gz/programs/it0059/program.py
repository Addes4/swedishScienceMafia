import math
import random
from typing import List, Tuple

# We'll implement a generic packing optimizer for squares inside the unit square.
# ------------------------------------------------------------
# Geometry helpers
# ------------------------------------------------------------

def square_corners(cx: float, cy: float, ang: float, s: float):
    """Return the 4 corners of a square with centre (cx,cy), angle in turns, side s."""
    # angle is fraction of full turn -> radians
    th = ang * 2.0 * math.pi
    c = math.cos(th)
    sn = math.sin(th)
    h = s * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        X = cx + x * c - y * sn
        Y = cy + x * sn + y * c
        out.append((X, Y))
    return out


def project_poly(pts, axis):
    """Project polygon points onto axis (unit vector), return (min,max)."""
    ax, ay = axis
    mn = float('inf')
    mx = float('-inf')
    for x, y in pts:
        v = x * ax + y * ay
        if v < mn: mn = v
        if v > mx: mx = v
    return mn, mx


def sat_overlap(poly1, poly2, eps=1e-9):
    """Return True if polygons overlap (positive area intersection). Using SAT for convex polys.
       For touching only (zero area) returns False."""
    # Check separating axes from both polygons
    for poly in (poly1, poly2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            # normal
            ax, ay = -ey, ex
            # normalize
            ln = math.hypot(ax, ay)
            if ln < 1e-15:
                continue
            ax /= ln; ay /= ln
            min1, max1 = project_poly(poly1, (ax, ay))
            min2, max2 = project_poly(poly2, (ax, ay))
            if max1 <= min2 + eps or max2 <= min1 + eps:
                return False  # separating axis found -> no overlap
    return True


def inside_unit_square(poly, eps=1e-9):
    """Check if polygon is inside [0,1]^2."""
    for x, y in poly:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


# ------------------------------------------------------------
# Objective: maximize sum of sides, penalize overlaps and out-of-bounds
# ------------------------------------------------------------

def evaluate(params, n):
    """params: list of (cx, cy, ang, s).
       Returns (score, penalty). score = sum of s (to maximize)."""
    # sum sides
    score = 0.0
    for _, _, _, s in params:
        score += s

    penalty = 0.0
    polys = []
    for cx, cy, ang, s in params:
        if s <= 1e-12:
            # zero square, treat as point, no overlap penalty
            polys.append(None)
            continue
        poly = square_corners(cx, cy, ang, s)
        polys.append(poly)
        # out-of-bounds penalty
        for x, y in poly:
            if x < 0.0:
                penalty += (0.0 - x) * (0.0 - x)
            elif x > 1.0:
                penalty += (x - 1.0) * (x - 1.0)
            if y < 0.0:
                penalty += (0.0 - y) * (0.0 - y)
            elif y > 1.0:
                penalty += (y - 1.0) * (y - 1.0)

    # overlap penalty (only for positive-size squares)
    for i in range(n):
        if polys[i] is None:
            continue
        for j in range(i + 1, n):
            if polys[j] is None:
                continue
            if sat_overlap(polys[i], polys[j], eps=0.0):
                # compute approximate overlap area via polygon clipping? expensive.
                # Instead, use a penalty based on penetration depth of SAT.
                # Simple: add constant penalty per overlapping pair plus small amount.
                penalty += 1.0 + 0.1 * (params[i][3] + params[j][3])
                # plus push them apart? We'll rely on local search.

    return score, penalty


def total_objective(params, n, penalty_weight=1000.0):
    score, pen = evaluate(params, n)
    return score - penalty_weight * pen


# ------------------------------------------------------------
# Constructive initial layouts
# ------------------------------------------------------------

def grid_layout(n, k, s):
    """k x k grid of squares of side s, centred in unit square."""
    # positions: (i+0.5)*s for i in 0..k-1
    res = []
    for i in range(k):
        for j in range(k):
            if len(res) >= n:
                return res
            cx = (i + 0.5) * s
            cy = (j + 0.5) * s
            res.append((cx, cy, 0.0, s))
    # fill remaining with zero squares
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res


def strip_layout(n, cols, side):
    """cols columns of squares of given side, full height? Actually place cols columns,
       each column filled with squares of side `side` stacked vertically."""
    # side given, rows = floor(1/side)
    res = []
    rows = int(math.floor(1.0 / side + 1e-12))
    if rows < 1:
        rows = 1
    # centre them
    total_w = cols * side
    total_h = rows * side
    x0 = (1.0 - total_w) * 0.5
    y0 = (1.0 - total_h) * 0.5
    for i in range(cols):
        for j in range(rows):
            if len(res) >= n:
                return res
            cx = x0 + (i + 0.5) * side
            cy = y0 + (j + 0.5) * side
            res.append((cx, cy, 0.0, side))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res


def one_big_plus_grid(n):
    """One large square occupying most of unit square, plus small squares in remaining corner/space.
       Try several configurations: big square at corner, remaining L-shaped region filled with small grid."""
    best = None
    best_score = -1.0
    # Try big square at corners, and remaining strip filled with small squares
    for (bx, by, bAng) in [(0.25, 0.25, 0.0), (0.75, 0.25, 0.0), (0.25, 0.75, 0.0), (0.75, 0.75, 0.0)]:
        # big square size S, centre at (bx,by)
        # Try different S values
        for frac in [0.8, 0.7, 0.6, 0.5, 0.4]:
            S = frac
            # remaining region: complement in unit square. We'll place small squares in the
            # region not covered by big square. For simplicity, try a grid in the remaining
            # area (approximate).
            # We'll just place big square then attempt to fill remaining with small squares
            # via a simple greedy / recursive method.
            # For now, try: big square at corner and fill the opposite L-shape with small squares.
            # We can use a simple grid on the two strips.
            # Let's just try to fill using a grid of small squares of size (1-S)/m for some m.
            # For each m, place small squares in the two rectangular strips not covered.
            for m in range(1, 8):
                small = (1.0 - S) / m if m > 0 else 0.0
                if small <= 0:
                    continue
                res = [(bx, by, bAng, S)]
                # For corner at (0.25,0.25) with S, big square covers [0.25-S/2, 0.25+S/2] x ...
                # We'll fill the rest with small squares via a simple grid on the whole unit square
                # but skip those overlapping big square. This is crude but ok for init.
                for i in range(m):
                    for j in range(m):
                        cx = (i + 0.5) * small
                        cy = (j + 0.5) * small
                        # check if this small square overlaps big square
                        # simple bounding box check
                        if abs(cx - bx) < (S + small) * 0.5 and abs(cy - by) < (S + small) * 0.5:
                            continue
                        if len(res) >= n:
                            break
                        res.append((cx, cy, 0.0, small))
                    if len(res) >= n:
                        break
                # extend with zero squares if needed
                while len(res) < n:
                    res.append((0.5, 0.5, 0.0, 0.0))
                # quick feasibility & score (allow overlaps? we'll rely on optimizer)
                sc = sum(r[3] for r in res)
                if sc > best_score:
                    # check rough feasibility (no overlaps, inside)
                    # we'll just accept
                    best_score = sc
                    best = res
    return best if best is not None else grid_layout(n, math.isqrt(n), 1.0/math.isqrt(n))


# ------------------------------------------------------------
# Local search
# ------------------------------------------------------------

def random_perturb(params, n, scale=0.02):
    """Return a perturbed copy of params."""
    new = []
    for cx, cy, ang, s in params:
        # perturb centre, angle, size
        ncx = cx + random.uniform(-scale, scale)
        ncy = cy + random.uniform(-scale, scale)
        nang = (ang + random.uniform(-scale, scale)) % 1.0
        ns = max(0.0, s + random.uniform(-scale, scale))
        # clamp
        ncx = min(max(ncx, 0.0), 1.0)
        ncy = min(max(ncy, 0.0), 1.0)
        new.append((ncx, ncy, nang, ns))
    return new


def local_search(params, n, iters=2000, temp0=0.05, temp1=1e-4):
    """Simulated annealing-like local search on total_objective."""
    cur = [tuple(p) for p in params]
    cur_obj = total_objective(cur, n)
    best = [tuple(p) for p in cur]
    best_obj = cur_obj
    T = temp0
    for it in range(iters):
        T = temp0 * (temp1 / temp0) ** (it / max(1, iters - 1))
        cand = random_perturb(cur, n, scale=0.02 * (1 - it / iters) + 0.002)
        cand_obj = total_objective(cand, n)
        if cand_obj > cur_obj or random.random() < math.exp((cand_obj - cur_obj) / max(T, 1e-12)):
            cur = cand
            cur_obj = cand_obj
            if cur_obj > best_obj:
                best_obj = cur_obj
                best = [tuple(p) for p in cur]
    return best


# ------------------------------------------------------------
# Main solver
# ------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        # one square: use full unit square
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares: split into two equal rectangles? Squares can't fill rectangle perfectly
        # Best: two squares of side 0.5 side by side
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three squares: possible: one 0.5x0.5 and two 0.5x0.5? no.
        # Best known: two 0.5 in bottom, one 0.5 in top? Actually 3 squares of side 0.5 fit?
        # 0.5*3 = 1.5 > 1 in one dimension, but can arrange in L-shape: two side by side, one above.
        # Yes: two 0.5x0.5 at bottom (0.25,0.25) and (0.75,0.25), one at top (0.5,0.75).
        # Side sum = 1.5.
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        # four squares of side 0.5: sum = 2.0
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # For general n, try a few constructive heuristics and pick best.
    candidates = []

    # 1) k x k grid
    k = math.isqrt(n)
    s = 1.0 / k
    candidates.append(grid_layout(n, k, s))

    # 2) Try grids with different k (smaller k, larger squares, more zero squares? no, we want sum)
    # Actually for n not perfect square, we can use k x k grid plus some extra squares in remaining strip.
    # We'll construct: k x k grid of side 1/k, then place remaining n - k^2 squares in the leftover strip.
    # simplest: add zero-size squares (doesn't help sum). Better: use slightly smaller squares to fit more.
    # e.g., use k columns and k+1 rows? side = 1/(k+1) maybe? We'll try various.

    # 3) Try k x (k+1) grid with side = 1/(k+1)
    k2 = math.isqrt(n)
    if k2 * (k2 + 1) >= n:
        cols = k2 + 1
        rows = k2
        side2 = 1.0 / cols
        # but rows*side2 <= 1? rows*k2+1? rows = k2, side2 = 1/(k2+1) => rows*side2 = k2/(k2+1) < 1
        # We'll place cols columns and rows rows, centred.
        total_w = cols * side2
        total_h = rows * side2
        x0 = (1.0 - total_w) * 0.5
        y0 = (1.0 - total_h) * 0.5
        res = []
        for i in range(cols):
            for j in range(rows):
                if len(res) >= n:
                    break
                cx = x0 + (i + 0.5) * side2
                cy = y0 + (j + 0.5) * side2
                res.append((cx, cy, 0.0, side2))
            if len(res) >= n:
                break
        while len(res) < n:
            res.append((0.5, 0.5, 0.0, 0.0))
        candidates.append(res)

    # 4) Try (k+1) x k grid similarly
    if k2 * (k2 + 1) >= n:
        cols = k2
        rows = k2 + 1
        side2 = 1.0 / rows
        total_w = cols * side2
        total_h = rows * side2
        x0 = (1.0 - total_w) * 0.5
        y0 = (1.0 - total_h) * 0.5
        res = []
        for i in range(cols):
            for j in range(rows):
                if len(res) >= n:
                    break
                cx = x0 + (i + 0.5) * side2
                cy = y0 + (j + 0.5) * side2
                res.append((cx, cy, 0.0, side2))
            if len(res) >= n:
                break
        while len(res) < n:
            res.append((0.5, 0.5, 0.0, 0.0))
        candidates.append(res)

    # 5) Try one big square + grid
    candidates.append(one_big_plus_grid(n))

    # 6) Random layouts? maybe not needed.

    # Evaluate candidates and pick best (by total_objective)
    best_params = None
    best_obj = -float('inf')
    for cand in candidates:
        obj = total_objective(cand, n, penalty_weight=1000.0)
        if obj > best_obj:
            best_obj = obj
            best_params = cand

    # Local search improvement
    # Run a few restarts with short local search
    num_restarts = 3
    iters_per = 1500
    for r in range(num_restarts):
        start = best_params if r == 0 else random_perturb(best_params, n, scale=0.05)
        improved = local_search(start, n, iters=iters_per, temp0=0.02, temp1=1e-5)
        obj = total_objective(improved, n, penalty_weight=1000.0)
        if obj > best_obj:
            best_obj = obj
            best_params = improved

    # Final cleanup: ensure feasibility. If not feasible, fall back to grid.
    # Check feasibility
    def is_feasible(params):
        polys = []
        for cx, cy, ang, s in params:
            if s <= 1e-12:
                polys.append(None)
                continue
            poly = square_corners(cx, cy, ang, s)
            if not inside_unit_square(poly, eps=1e-7):
                return False
            polys.append(poly)
        for i in range(len(polys)):
            if polys[i] is None:
                continue
            for j in range(i + 1, len(polys)):
                if polys[j] is None:
                    continue
                if sat_overlap(polys[i], polys[j], eps=1e-7):
                    return False
        return True

    if not is_feasible(best_params):
        # fallback: simple grid
        k = math.isqrt(n)
        s = 1.0 / k
        return grid_layout(n, k, s)

    # Clamp all values to [0,1]
    out = []
    for cx, cy, ang, s in best_params:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        s = max(0.0, s)
        out.append((cx, cy, ang, s))
    return out[:n]
