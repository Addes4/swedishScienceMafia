import math
import random

# ---------- geometry helpers ----------
def corners(cx, cy, ang, s):
    a = ang * 2.0 * math.pi
    c = math.cos(a) * (s * 0.5)
    si = math.sin(a) * (s * 0.5)
    # local half-extent vectors
    return [
        (cx - c + si, cy - si - c),
        (cx + c + si, cy + si - c),
        (cx + c - si, cy + si + c),
        (cx - c - si, cy - si + c),
    ]

def poly_axes(pts):
    axes = []
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        ex, ey = x2 - x1, y2 - y1
        L = math.hypot(ex, ey)
        if L > 1e-12:
            axes.append((-ey / L, ex / L))
    return axes

def project(pts, ax):
    d = [p[0] * ax[0] + p[1] * ax[1] for p in pts]
    return min(d), max(d)

def overlap_sat(p1, p2):
    # quick reject via bounding circles
    a1 = poly_axes(p1)
    a2 = poly_axes(p2)
    for ax in a1 + a2:
        m1, M1 = project(p1, ax)
        m2, M2 = project(p2, ax)
        if M1 <= m2 + 1e-12 or M2 <= m1 + 1e-12:
            return False
    return True

def inside_unit(pts):
    for x, y in pts:
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True

# ---------- objective ----------
def total_side(sqs):
    return sum(q[3] for q in sqs)

def valid_config(sqs, check_overlaps=True):
    polys = []
    for (cx, cy, ang, s) in sqs:
        if s <= 1e-12:
            polys.append(None)
            continue
        pts = corners(cx, cy, ang, s)
        if not inside_unit(pts):
            return False
        polys.append(pts)
    if check_overlaps:
        m = len(polys)
        for i in range(m):
            if polys[i] is None:
                continue
            for j in range(i + 1, m):
                if polys[j] is None:
                    continue
                if overlap_sat(polys[i], polys[j]):
                    return False
    return True

# ---------- initial construction ----------
def initial_grid(n):
    k = max(1, int(math.floor(math.sqrt(n))))
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
            if len(out) >= n:
                return out
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out

# Try to grow the smallest squares greedily.
def greedy_fill(sqs, iterations=4000):
    sqs = [list(q) for q in sqs]
    n = len(sqs)
    rng = random.Random(12345)
    best = sum(q[3] for q in sqs)
    for it in range(iterations):
        # pick a random zero or small square and try to inflate
        idx = rng.randrange(n)
        cx, cy, ang, s = sqs[idx]
        # perturb
        new_s = min(1.0, s + rng.uniform(0.001, 0.05))
        new_ang = ang + rng.uniform(-0.1, 0.1)
        new_cx = min(1.0, max(0.0, cx + rng.uniform(-0.05, 0.05)))
        new_cy = min(1.0, max(0.0, cy + rng.uniform(-0.05, 0.05)))
        old = sqs[idx]
        sqs[idx] = [new_cx, new_cy, new_ang, new_s]
        if valid_config(sqs):
            cur = sum(q[3] for q in sqs)
            if cur >= best:
                best = cur
            else:
                sqs[idx] = old
        else:
            # try smaller growth
            sqs[idx] = [new_cx, new_cy, new_ang, min(1.0, s + 0.005)]
            if valid_config(sqs):
                best = max(best, sum(q[3] for q in sqs))
            else:
                sqs[idx] = old
    return [tuple(q) for q in sqs]

# A local optimizer: simulated annealing, replacing the worst square.
def refine(sqs, time_budget_ops=60000):
    sqs = [list(q) for q in sqs]
    n = len(sqs)
    rng = random.Random(98765)
    cur = sum(q[3] for q in sqs)
    best = cur
    best_sqs = [tuple(q) for q in sqs]
    T = 0.05
    for it in range(time_budget_ops):
        idx = rng.randrange(n)
        cx, cy, ang, s = sqs[idx]
        old = (cx, cy, ang, s)
        # perturb size and position
        if rng.random() < 0.6:
            s2 = max(0.0, s + rng.gauss(0, 0.02))
        else:
            s2 = max(0.0, s)
        ang2 = ang + rng.gauss(0, 0.05)
        # shift center within allowed range roughly
        cx2 = min(1.0, max(0.0, cx + rng.gauss(0, 0.02)))
        cy2 = min(1.0, max(0.0, cy + rng.gauss(0, 0.02)))
        sqs[idx] = [cx2, cy2, ang2, s2]
        if valid_config(sqs):
            new = sum(q[3] for q in sqs)
            if new >= cur or rng.random() < math.exp((new - cur) / max(T, 1e-9)):
                cur = new
                if new > best:
                    best = new
                    best_sqs = [tuple(q) for q in sqs]
            else:
                sqs[idx] = list(old)
        else:
            sqs[idx] = list(old)
        T *= 0.99995
        if T < 1e-6:
            T = 0.01
    return best_sqs

def solve(n):
    if n == 0:
        return []
    base = initial_grid(n)
    # Try to improve zeros first
    improved = greedy_fill(base, iterations=3000 if n <= 20 else 8000)
    # Refine
    improved = refine(improved, time_budget_ops=25000 if n <= 9 else (45000 if n <= 25 else 60000))
    # Ensure all zero squares get at least a tiny size if possible
    improved = [list(q) for q in improved]
    # one more greedy pass focusing on zeros
    for _ in range(2):
        improved = greedy_fill(improved, iterations=2000)
        improved = refine(improved, time_budget_ops=15000)
    # Fix format and clamp
    out = []
    for (cx, cy, ang, s) in improved:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = min(1.0, max(0.0, s))
        out.append((cx, cy, ang, s))
    # final validity check; if invalid, fall back safely
    if not valid_config(out):
        return initial_grid(n)
    return out
