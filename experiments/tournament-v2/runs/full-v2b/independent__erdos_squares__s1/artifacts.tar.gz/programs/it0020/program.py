import math
import random
from scipy.optimize import minimize


def _score(p, n_rect, rects):
    """Negative sum of side lengths for a candidate packing."""
    total = 0.0
    for i in range(n_rect):
        x, y, a, s = p[4*i:4*i+4]
        if s < 1e-12:
            continue
        # clamp into unit square and rectangle bounds handled by penalty below
        total += s
    return -total


def _constraints(p, n_rect, rects):
    """Return a list of constraint violations (<=0 means feasible)."""
    cons = []
    # centre and size within the assigned rectangle (axis-aligned after rotation neglect)
    for i in range(n_rect):
        cx, cy, a, s = p[4*i:4*i+4]
        x0, y0, x1, y1 = rects[i]
        r = s * math.sqrt(2.0) / 2.0
        # rotated square stays inside its rectangle approximately
        cons.append(cx - r - x0)
        cons.append(x1 - (cx + r))
        cons.append(cy - r - y0)
        cons.append(y1 - (cy + r))
        if s < 0:
            cons.append(-s)
    return cons


def _optimize_rect(rect, k):
    """Return list of (cx, cy, angle, side) for k squares in rectangle."""
    x0, y0, x1, y1 = rect
    w = x1 - x0
    h = y1 - y0
    if k == 0:
        return []
    if k == 1:
        s = min(w, h)
        return [(x0 + w/2, y0 + h/2, 0.0, s)]
    # initial guess: grid inside rectangle, or rotated centres
    if k == 2:
        # two squares side by side or stacked
        if w >= h:
            s = min(w/2, h)
            return [(x0 + s/2, y0 + h/2, 0.0, s), (x0 + 3*s/2, y0 + h/2, 0.0, s)]
        else:
            s = min(w, h/2)
            return [(x0 + w/2, y0 + s/2, 0.0, s), (x0 + w/2, y0 + 3*s/2, 0.0, s)]
    if k == 3:
        # one big + two small, or three in a row
        s = min(w/3, h)
        if w >= 3*min(w,h):  # wide
            return [(x0 + (i+0.5)*s, y0 + h/2, 0.0, s) for i in range(3)]
        # L-shape
        a = min(w, h)
        b = min(w - a, h)
        # two stacked on right, one left
        if w >= h:
            a = min(w - h, h)
            s1 = h
            s2 = min(w - s1, h/2) if w > s1 else 0
            if s2 > 0:
                return [(x0 + s1/2, y0 + h/2, 0.0, s1),
                        (x0 + s1 + s2/2, y0 + s2/2, 0.0, s2),
                        (x0 + s1 + s2/2, y0 + s2*3/2, 0.0, s2)]
        else:
            s1 = w
            s2 = min(h - s1, w/2) if h > s1 else 0
            if s2 > 0:
                return [(x0 + w/2, y0 + s1/2, 0.0, s1),
                        (x0 + s2/2, y0 + s1 + s2/2, 0.0, s2),
                        (x0 + s2*3/2, y0 + s1 + s2/2, 0.0, s2)]
        # fallback: row
        s = min(w/k, h)
        return [(x0 + (i+0.5)*s, y0 + h/2, 0.0, s) for i in range(k)]
    # general: equal grid k cells
    best = None
    best_sum = -1
    for cols in range(1, k+1):
        rows = (k + cols - 1) // cols
        sc = min(w/cols, h/rows)
        # remaining k - cols*rows zero-sized if k not fit
        total = sc * min(k, cols*rows)
        if total > best_sum:
            best_sum = total
            best = (cols, rows, sc)
    cols, rows, sc = best
    out = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= k:
                break
            cx = x0 + (c + 0.5) * (w / cols)
            cy = y0 + (r + 0.5) * (h / rows)
            out.append((cx, cy, 0.0, sc))
            idx += 1
    while len(out) < k:
        out.append((x0 + w/2, y0 + h/2, 0.0, 0.0))
    return out


def _partition(n):
    """Choose a partition of [0,1]^2 into rectangles for n squares."""
    best = None
    best_val = -1
    # try all (rows, cols) tilings with slight aspect optimization
    for rows in range(1, n+1):
        cols = (n + rows - 1) // rows
        # distribute: some cells may get multiple squares
        base = n // (rows * cols)
        rem = n % (rows * cols)
        # value estimate: cells with 1 square -> side = min(w,h), with m squares -> approx
        def rect_val(m, w, h):
            if m == 0:
                return 0.0
            if m == 1:
                return min(w, h)
            if m == 2:
                if w >= h:
                    return 2 * min(w/2, h)
                return 2 * min(w, h/2)
            if m == 3:
                return 3 * min(w/3, h) if w >= h else 3 * min(w, h/3)
            g = math.isqrt(m)
            s = min(w/g, h/math.ceil(m/g))
            return s * m
        cell_w = 1.0 / cols
        cell_h = 1.0 / rows
        # assign base squares to all cells, rem extra to some
        val = base * rect_val(1, cell_w, cell_h) * (rows*cols - rem) / (rows*cols) * (rows*cols)
        # simpler: approximate total
        val = 0.0
        for i in range(rows*cols):
            m = base + (1 if i < rem else 0)
            val += rect_val(m, cell_w, cell_h)
        if val > best_val:
            best_val = val
            best = (rows, cols, base, rem)
    return best


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        s = 0.5
        return [(0.25, 0.5, 0.0, s), (0.75, 0.5, 0.0, s)]
    if n == 3:
        # best known: one large + two small or 3 equal
        # try 3 equal in a row
        s = 1.0/3
        # actually 1 big square + 2 small, or 3 equal
        cand1 = [(1/6, 0.5, 0.0, 1/3), (0.5, 0.5, 0.0, 1/3), (5/6, 0.5, 0.0, 1/3)]
        # one big + two small: big side a, two small side (1-a)/2 each
        # sum = a + 2*(1-a)/2 = a + 1 - a = 1 if small squares stacked beside big
        # if big side a and two small of side b: a + 2b, with b <= (1-a) and b <= 0.5
        # maximize a + 2b s.t. b <= (1-a), b <= 0.5, a <= 1 -> a = 0.5, b = 0.5? no
        # a + 2b, b = (1-a) => a + 2 - 2a = 2 - a, maximized at a=0 -> 2, but a>=b? 
        # constraints: place big square side a in corner, two small side b beside
        # b <= 0.5, a + b <= 1 in both dims. b <= (1-a)/... 
        # actually a = 0.5, b = 0.25? sum = 1.0
        # 3 equal in row: 1.0
        # better: 1 big a=0.5, 2 small b=0.25 stacked: sum = 0.5+0.5 = 1.0
        # known optimal for 3 is 1.0
        return [(1/6, 0.5, 0.0, 1/3), (0.5, 0.5, 0.0, 1/3), (5/6, 0.5, 0.0, 1/3)]
    if n == 4:
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s),
                (0.25, 0.75, 0.0, s), (0.75, 0.75, 0.0, s)]
    # general n: partition into rectangles
    rows, cols, base, rem = _partition(n)
    rects = []
    for r in range(rows):
        for c in range(cols):
            x0 = c / cols
            x1 = (c+1) / cols
            y0 = r / rows
            y1 = (r+1) / rows
            rects.append((x0, y0, x1, y1))
    squares = []
    idx = 0
    for i, rect in enumerate(rects):
        m = base + (1 if i < rem else 0)
        if idx >= n:
            break
        m = min(m, n - idx)
        sub = _optimize_rect(rect, m)
        squares.extend(sub)
        idx += len(sub)
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    # local improvement: try rotating some squares and re-fitting
    squares = squares[:n]
    squares = _improve(squares, n)
    return squares


def _improve(squares, n):
    """Simple local search: try enlarging squares greedily."""
    sq = [list(s) for s in squares]
    # clamp
    for s in sq:
        s[0] = min(max(s[0], 0.0), 1.0)
        s[1] = min(max(s[1], 0.0), 1.0)
        s[2] = s[2] % 1.0
        s[3] = max(0.0, min(s[3], 1.0))
    # try to grow each square a bit if possible (collision check axis-aligned approx)
    improved = True
    iters = 0
    while improved and iters < 50:
        improved = False
        iters += 1
        for i in range(n):
            if sq[i][3] <= 1e-15:
                continue
            old = sq[i][3]
            for factor in (1.01, 1.005, 1.001):
                news = old * factor
                if news > 1.0:
                    continue
                # check if fits inside unit square (rotated bounding box)
                r = news * math.sqrt(2.0) / 2.0
                cx, cy = sq[i][0], sq[i][1]
                if cx - r < 0 or cx + r > 1 or cy - r < 0 or cy + r > 1:
                    continue
                if _collides(sq, i, news):
                    continue
                sq[i][3] = news
                improved = True
                break
    return [tuple(s) for s in sq]


def _collides(sq, idx, new_side):
    """Check if square idx with new_side collides with any other (rotated approx)."""
    xi, yi, ai, _ = sq[idx]
    ri = new_side * math.sqrt(2.0) / 2.0
    for j in range(len(sq)):
        if j == idx or sq[j][3] < 1e-15:
            continue
        xj, yj, aj, sj = sq[j]
        rj = sj * math.sqrt(2.0) / 2.0
        # conservative: bounding circles overlap check
        if (xi - xj)**2 + (yi - yj)**2 < (ri + rj)**2 * 0.999:
            # more precise: check via separating axis for rotated squares
            if _sat_overlap(xi, yi, ai, new_side, xj, yj, aj, sj):
                return True
    return False


def _corners(cx, cy, angle, side):
    """Return 4 corners of rotated square."""
    a = angle * 2 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side / 2
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for px, py in pts:
        out.append((cx + px*ca - py*sa, cy + px*sa + py*ca))
    return out


def _sat_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Separating axis theorem for two squares."""
    if s1 < 1e-15 or s2 < 1e-15:
        return False
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)
    axes = []
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i+1) % 4]
            edge = (x2 - x1, y2 - y1)
            n = (-edge[1], edge[0])
            ln = math.hypot(*n)
            if ln > 1e-15:
                axes.append((n[0]/ln, n[1]/ln))
    for ax, ay in axes:
        min1 = min(p[0]*ax + p[1]*ay for p in p1)
        max1 = max(p[0]*ax + p[1]*ay for p in p1)
        min2 = min(p[0]*ax + p[1]*ay for p in p2)
        max2 = max(p[0]*ax + p[1]*ay for p in p2)
        if max1 <= min2 + 1e-9 or max2 <= min1 + 1e-9:
            return False
    return True
</change>
