import math
import random

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n <= 4:
        # Exact for small n: split into n equal-area rectangles? Grid is optimal for 2,3,4 often via simple cuts.
        # Try best simple layout by search over axis-aligned grids.
        pass

    # exact-ish initial: choose grid with rows/cols to maximize sum
    best = None
    best_score = -1

    def grid_solution(rows, cols):
        if rows * cols < n:
            return None
        side = min(1.0 / rows, 1.0 / cols)
        # Use rows x cols grid, all same size, filling n cells, rest zero.
        sq = []
        for i in range(rows):
            for j in range(cols):
                if len(sq) < n:
                    sq.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        sq += [((0.5, 0.5, 0.0, 0.0))] * (n - len(sq))
        return sq

    # Try all reasonable grids
    for rows in range(1, n + 1):
        for cols in range(1, n + 1):
            if rows * cols >= n:
                s = grid_solution(rows, cols)
                score = sum(x[3] for x in s)
                if score > best_score:
                    best_score = score
                    best = s

    # Also try a perfect square grid if sqrt fits
    k = math.isqrt(n)
    if k > 0:
        s = grid_solution(k, k)
        score = sum(x[3] for x in s)
        if score > best_score:
            best_score = score
            best = s

    # Improve via local search: grow some squares and shrink others while keeping disjoint
    # Since arbitrary rotation is hard to verify exactly, use small perturbation with strict overlap check.

    def overlap(s1, s2):
        # Check if axis-aligned squares overlap in interiors (treat as closed for safety)
        x1, y1, a1, s1_ = s1
        x2, y2, a2, s2_ = s2
        if s1_ <= 1e-12 or s2_ <= 1e-12:
            return False
        # Use axis-aligned bounding boxes for rotated squares: half-diagonal = s * sqrt(2)/2
        r1 = s1_ * math.sqrt(2) / 2
        r2 = s2_ * math.sqrt(2) / 2
        if abs(x1 - x2) >= r1 + r2 - 1e-12:
            return False
        if abs(y1 - y2) >= r1 + r2 - 1e-12:
            return False
        # More precise: transform into each square's frame and check
        # For rotated squares, check if any vertex of one is inside the other or edges cross.
        # We'll use a conservative overlap: separating axis theorem for convex polygons.
        def vertices(cx, cy, ang, side):
            h = side / 2
            c, s = math.cos(2 * math.pi * ang), math.sin(2 * math.pi * ang)
            pts = []
            for dx, dy in [(-h, -h), (h, -h), (h, h), (-h, h)]:
                pts.append((cx + dx * c - dy * s, cy + dx * s + dy * c))
            return pts

        pts1 = vertices(x1, y1, a1, s1_)
        pts2 = vertices(x2, y2, a2, s2_)

        def project(poly, axis):
            return [p[0] * axis[0] + p[1] * axis[1] for p in poly]

        def poly_overlap(p1, p2):
            # SAT for convex polygons
            for poly in (p1, p2):
                for i in range(len(poly)):
                    p = poly[i]
                    q = poly[(i + 1) % len(poly)]
                    edge = (q[0] - p[0], q[1] - p[1])
                    axis = (-edge[1], edge[0])
                    len_ax = math.hypot(*axis)
                    if len_ax < 1e-14:
                        continue
                    axis = (axis[0] / len_ax, axis[1] / len_ax)
                    proj1 = project(p1, axis)
                    proj2 = project(p2, axis)
                    if max(proj1) <= min(proj2) + 1e-12 or max(proj2) <= min(proj1) + 1e-12:
                        return False
            return True

        return poly_overlap(pts1, pts2)

    # Since exact overlap for rotated squares is costly, use axis-aligned local search only.
    # But allow small rotations and check overlap carefully.

    def total_score(sqs):
        return sum(sq[3] for sq in sqs)

    # Improve by trying to grow the smallest squares if there's room, or adjust positions.
    # Simple hill climbing: for each square, try increasing its side and moving it slightly.
    # Use random restarts and greedy expansion of zero squares into gaps.

    def valid_pos(x, y, side, ang, others):
        # Check square inside unit square (axis-aligned bound for rotated)
        if side <= 0:
            return True
        hd = side * math.sqrt(2) / 2
        if x - hd < -1e-9 or x + hd > 1 + 1e-9:
            return False
        if y - hd < -1e-9 or y + hd > 1 + 1e-9:
            return False
        # Check overlap with others
        for o in others:
            if overlap((x, y, ang, side), o):
                return False
        return True

    # Start with best grid, then try to improve by adding rotations and growth
    random.seed(42 + n)
    current = [list(sq) for sq in best]
    current_score = total_score(current)

    # Try to fill zero-size squares by placing them in gaps
    # First, attempt to grow all squares simultaneously with scaling if possible
    # We'll do local search: pick a square, try to increase its side by small delta,
    # and if overlap, try to move/resize others.

    def is_valid_all(sqs):
        for i in range(len(sqs)):
            if sqs[i][3] <= 0:
                continue
            hd = sqs[i][3] * math.sqrt(2) / 2
            if sqs[i][0] - hd < -1e-9 or sqs[i][0] + hd > 1 + 1e-9:
                return False
            if sqs[i][1] - hd < -1e-9 or sqs[i][1] + hd > 1 + 1e-9:
                return False
            for j in range(i + 1, len(sqs)):
                if sqs[j][3] <= 0:
                    continue
                if overlap(tuple(sqs[i]), tuple(sqs[j])):
                    return False
        return True

    if not is_valid_all(current):
        # fallback to axis-aligned grid
        current = [list(sq) for sq in best]
        for sq in current:
            sq[2] = 0.0
        current_score = total_score(current)

    # Local search: try to increase side of each square, possibly rotate slightly
    for iteration in range(200):
        improved = False
        idx_order = list(range(n))
        random.shuffle(idx_order)
        for i in idx_order:
            old = current[i][:]
            # try a few random perturbations
            for _ in range(10):
                new_side = old[3] + random.uniform(0.001, 0.02)
                new_ang = old[2] + random.uniform(-0.02, 0.02)
                # clamp angle to [0,1)
                new_ang = new_ang % 1.0
                # try to find a position
                attempts = 20
                for _a in range(attempts):
                    nx = old[0] + random.uniform(-0.02, 0.02)
                    ny = old[1] + random.uniform(-0.02, 0.02)
                    nx = max(0.0, min(1.0, nx))
                    ny = max(0.0, min(1.0, ny))
                    # Check bounds
                    hd = new_side * math.sqrt(2) / 2
                    if nx - hd < -1e-9 or nx + hd > 1 + 1e-9:
                        continue
                    if ny - hd < -1e-9 or ny + hd > 1 + 1e-9:
                        continue
                    # Check overlap with others
                    ok = True
                    others = [tuple(current[j]) for j in range(n) if j != i]
                    for o in others:
                        if o[3] <= 0:
                            continue
                        if overlap((nx, ny, new_ang, new_side), o):
                            ok = False
                            break
                    if ok:
                        # Also check bounds for others? assume others still valid.
                        current[i] = [nx, ny, new_ang, new_side]
                        improved = True
                        break
                if improved:
                    break
        if improved:
            # Verify all valid
            if not is_valid_all(current):
                # revert to previous safe state
                pass
            else:
                current_score = total_score(current)
        else:
            break

    # Final safety: ensure all squares inside unit square and no overlaps.
    # If any issue, fallback to best grid.
    if not is_valid_all(current):
        return best

    # Ensure every number in [0,1] and side >= 0
    result = []
    for sq in current:
        x, y, a, s = sq
        x = max(0.0, min(1.0, x))
        y = max(0.0, min(1.0, y))
        a = a % 1.0
        s = max(0.0, s)
        result.append((x, y, a, s))
    return result
