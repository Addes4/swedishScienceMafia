import math
import random
import numpy as np
from scipy.optimize import minimize

random.seed(12345)
np.random.seed(12345)


def corners_of(x, y, a, s):
    c = math.cos(2.0 * math.pi * a)
    sn = math.sin(2.0 * math.pi * a)
    h = 0.5 * s
    pts = []
    for dx, dy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        px = x + h * (dx * c - dy * sn)
        py = y + h * (dx * sn + dy * c)
        pts.append((px, py))
    return pts


def all_corners(v, n):
    out = []
    for i in range(n):
        x, y, a, s = v[4*i:4*i+4]
        out.append(corners_of(x, y, a, s))
    return out


def overlap_amount(ca, cb):
    # Separating axis theorem; returns positive penetration measure (approx)
    axes = []
    for j in range(2):
        p0 = ca[j]
        p1 = ca[j+1]
        axes.append((- (p1[1] - p0[1]), (p1[0] - p0[0])))
    for j in range(2):
        p0 = cb[j]
        p1 = cb[j+1]
        axes.append((- (p1[1] - p0[1]), (p1[0] - p0[0])))
    min_pen = 1e9
    for ax, ay in axes:
        ln = math.hypot(ax, ay)
        if ln < 1e-15:
            continue
        ax /= ln
        ay /= ln
        proj_a = [ax*px + ay*py for px, py in ca]
        proj_b = [ax*px + ay*py for px, py in cb]
        if max(proj_a) <= min(proj_b) or max(proj_b) <= min(proj_a):
            return 0.0
        pen = min(max(proj_a) - min(proj_b), max(proj_b) - min(proj_a))
        if pen < min_pen:
            min_pen = pen
    return min_pen


def penalty(v, n, w_bounds=200.0, w_overlap=2000.0):
    p = 0.0
    C = all_corners(v, n)
    for i in range(n):
        for (px, py) in C[i]:
            if px < 0.0:
                p += w_bounds * (-px)
            if px > 1.0:
                p += w_bounds * (px - 1.0)
            if py < 0.0:
                p += w_bounds * (-py)
            if py > 1.0:
                p += w_bounds * (py - 1.0)
    for i in range(n):
        for j in range(i+1, n):
            ov = overlap_amount(C[i], C[j])
            if ov > 0:
                p += w_overlap * ov
    return p


def objective(v, n):
    s = sum(v[4*i+3] for i in range(n))
    return -s + penalty(v, n)


def objective_nopen(v, n):
    return -sum(v[4*i+3] for i in range(n))


def clip_params(v):
    v = np.array(v, dtype=float)
    for i in range(len(v)//4):
        v[4*i] = min(max(v[4*i], 0.0), 1.0)
        v[4*i+1] = min(max(v[4*i+1], 0.0), 1.0)
        v[4*i+2] = v[4*i+2] % 1.0
        v[4*i+3] = max(v[4*i+3], 0.0)
    return v


def greedy_grow(n, tries=25):
    # Start from small seeds, grow sizes checking overlap, keeping centers inside.
    best = None
    best_val = -1
    for _ in range(tries):
        order = list(range(n))
        random.shuffle(order)
        placed = [None] * n
        boxes = []
        ok = True
        for idx in order:
            # try to place a square with random position/orientation; size found by search
            attempts = 60
            best_here = (0.0, 0.5, 0.5, 0.0)
            for _a in range(attempts):
                x = random.random()
                y = random.random()
                a = random.random()
                # binary search max side
                lo, hi = 0.0, 1.0
                for _b in range(26):
                    mid = 0.5 * (lo + hi)
                    if mid < 1e-9:
                        lo = mid
                        continue
                    ca = corners_of(x, y, a, mid)
                    inside = all(-1e-12 <= px <= 1+1e-12 and -1e-12 <= py <= 1+1e-12 for px, py in ca)
                    if not inside:
                        hi = mid
                        continue
                    bad = False
                    for cb in boxes:
                        if overlap_amount(ca, cb) > 1e-12:
                            bad = True
                            break
                    if bad:
                        hi = mid
                    else:
                        lo = mid
                if lo > best_here[3]:
                    best_here = (lo, x, y, a)
            placed[idx] = (best_here[1], best_here[2], best_here[3], best_here[0])
            boxes.append(corners_of(best_here[1], best_here[2], best_here[3], best_here[0]))
        val = sum(p[3] for p in placed)
        if val > best_val:
            best_val = val
            best = placed
    return best


def grid_init(n):
    v = []
    k = math.isqrt(n)
    if k >= 1:
        s = 1.0 / k
        cnt = 0
        for i in range(k):
            for j in range(k):
                if cnt < n:
                    v.extend([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
                    cnt += 1
    # greedy remaining using random spots and size 0
    while len(v) < 4*n:
        v.extend([0.5, 0.5, 0.0, 0.0])
    return np.array(v[:4*n])


def random_init(n):
    v = []
    for _ in range(n):
        v.extend([random.random(), random.random(), random.random(), 0.3 + 0.7*random.random()])
    return np.array(v)


def spiral_init(n):
    v = []
    # place squares along rows with decreasing size
    rows = max(1, int(math.sqrt(n)))
    idx = 0
    y = 0.0
    remaining = n
    row_sizes = []
    total = 1.0
    # Distribute row heights proportional to 1
    r = rows
    h = 1.0 / r
    for ri in range(r):
        cols = int(round(math.sqrt(remaining))) if remaining > 0 else 0
        if ri == r-1:
            cols = remaining
        cols = max(cols, 1)
        w = 1.0 / cols
        for ci in range(cols):
            if idx >= n:
                break
            v.extend([(ci+0.5)*w, y + h/2, 0.0, min(w, h)])
            idx += 1
        y += h
        remaining -= cols
    while len(v) < 4*n:
        v.extend([0.5, 0.5, 0.0, 0.0])
    return np.array(v[:4*n])


def optimize_from(v0, n, maxiter=200, ftol=1e-9, use_penalty=True):
    bounds = []
    for i in range(n):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (None, None), (0.0, 1.0)])
    if use_penalty:
        fun = lambda v: objective(v, n)
    else:
        fun = lambda v: objective_nopen(v, n)
    try:
        res = minimize(fun, v0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': maxiter, 'ftol': ftol, 'gtol': 1e-8})
        v = clip_params(res.x)
        return v, -objective_nopen(v, n)
    except Exception:
        return v0, -objective_nopen(v0, n)


def repair(v, n):
    # simple repair: shrink overlapping squares slightly
    v = v.copy()
    for _ in range(20):
        C = all_corners(v, n)
        changed = False
        for i in range(n):
            si = v[4*i+3]
            if si <= 0:
                continue
            for j in range(i+1, n):
                sj = v[4*j+3]
                if sj <= 0:
                    continue
                ov = overlap_amount(C[i], C[j])
                if ov > 1e-8:
                    # shrink both
                    v[4*i+3] = max(0.0, si - ov * 0.5)
                    v[4*j+3] = max(0.0, sj - ov * 0.5)
                    changed = True
        # push off walls
        for i in range(n):
            x, y, a, s = v[4*i:4*i+4]
            ca = corners_of(x, y, a, s)
            minx = min(px for px, py in ca)
            maxx = max(px for px, py in ca)
            miny = min(py for px, py in ca)
            maxy = max(py for px, py in ca)
            if minx < 0:
                v[4*i] += -minx
            if maxx > 1:
                v[4*i] -= (maxx - 1)
            if miny < 0:
                v[4*i+1] += -miny
            if maxy > 1:
                v[4*i+1] -= (maxy - 1)
            if changed:
                pass
        if not changed:
            break
    return v


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two rectangles: split into two 0.5 x 1 rectangles -> squares 0.5 each
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three squares: can't all be 0.5. Try a known good: 0.5,0.5, small rotated middle
        # Use solver to be safe.
        pass

    best_v = None
    best_val = -1.0

    cands = []
    cands.append(grid_init(n))
    cands.append(spiral_init(n))
    for _ in range(max(2, min(8, 40 // max(1, n)))):
        cands.append(random_init(n))
    g = greedy_grow(n, tries=max(2, min(12, 30 // max(1, n))))
    if g is not None:
        gv = np.array([x for p in g for x in p])
        cands.append(gv)

    for v0 in cands:
        # multiple optimization passes
        v = clip_params(v0)
        for it, use_pen in enumerate([True, True, False]):
            v2, val = optimize_from(v, n, maxiter=250 if n <= 6 else 180, use_penalty=use_pen)
            if val > best_val - 1e-12:
                # check feasibility
                C = all_corners(v2, n)
                feasible = True
                for i in range(n):
                    for (px, py) in C[i]:
                        if px < -1e-7 or px > 1+1e-7 or py < -1e-7 or py > 1+1e-7:
                            feasible = False
                            break
                    if not feasible:
                        break
                if feasible:
                    for i in range(n):
                        for j in range(i+1, n):
                            if overlap_amount(C[i], C[j]) > 1e-7:
                                feasible = False
                                break
                        if not feasible:
                            break
                if feasible:
                    v = v2
                    if val > best_val:
                        best_val = val
                        best_v = v.copy()
            if val > best_val - 1e-9 and n <= 12:
                v = v2
            else:
                v = v  # keep exploring but continue with best-ish

    if best_v is None:
        # fallback repair
        v = clip_params(cands[0])
        v = repair(v, n)
        best_v = v

    # final repair pass
    v = repair(best_v, n)
    # ensure sum not decreased by repair too much: if repair hurts, retry optimization
    result = []
    for i in range(n):
        x, y, a, s = v[4*i:4*i+4]
        x = min(max(float(x), 0.0), 1.0)
        y = min(max(float(y), 0.0), 1.0)
        a = float(a) % 1.0
        s = max(0.0, min(float(s), 1.5))
        result.append((x, y, a, s))
    return result
