import math
import random
import time


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # Two equal squares side 0.5 fit perfectly; side 0.5 each.
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # 2 on bottom, 1 on top rotated? Equal side 0.5 gives sum 1.5 possible but top gap.
        # Actually best simple known: three squares in an L, sum approx 1.5.
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        # 2x2 grid plus small in corner; approximate good packing sum ~2.2
        S = [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
             (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5),
             (0.5, 0.98, 0.0, 0.04)]
        return S
    # General method: start from a grid, then use simulated annealing / local search
    # to improve the sum under non-overlap constraints.

    # We'll search over configurations. Because n can be large, use a reasonably fast check.
    # Represent each square as [cx, cy, ang, side].
    # Bound: side <= 1, centers in [0,1], angles in [0,1).

    # Fast overlap test using separating axes for convex polygons.
    def corners(cx, cy, ang, s):
        # square centered at (cx,cy), angle fraction of turn, side s
        a = ang * 2.0 * math.pi
        ca = math.cos(a)
        sa = math.sin(a)
        h = s * 0.5
        # corners relative
        rel = [(-h, -h), (h, -h), (h, h), (-h, h)]
        pts = []
        for x, y in rel:
            pts.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
        return pts

    def overlap(A, B):
        # A, B are [cx,cy,ang,side]
        if A[3] <= 0 or B[3] <= 0:
            return False
        pa = corners(A[0], A[1], A[2], A[3])
        pb = corners(B[0], B[1], B[2], B[3])
        # SAT for convex polygons
        def project(poly, axis):
            ax, ay = axis
            dots = [x * ax + y * ay for x, y in poly]
            return min(dots), max(dots)
        def axes(poly):
            res = []
            for i in range(4):
                x1, y1 = poly[i]
                x2, y2 = poly[(i + 1) % 4]
                ex, ey = x2 - x1, y2 - y1
                # normal
                res.append((-ey, ex))
            return res
        for axis in axes(pa) + axes(pb):
            amin, amax = project(pa, axis)
            bmin, bmax = project(pb, axis)
            if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
                return False
        # Also need to ensure they actually overlap interior, not just touch.
        # If all projections overlap with positive length, then interiors overlap.
        return True

    def inside_unit(A):
        cx, cy, ang, s = A
        if s <= 0:
            return True
        pa = corners(cx, cy, ang, s)
        for x, y in pa:
            if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
                return False
        return True

    def total_side(config):
        return sum(a[3] for a in config)

    # Initial configuration: grid with k x k, plus remaining as zero.
    k = math.isqrt(n)
    grid = []
    if k > 0:
        s = 1.0 / k
        for i in range(k):
            for j in range(k):
                grid.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
    while len(grid) < n:
        grid.append([0.5, 0.5, 0.0, 0.0])
    grid = grid[:n]
    best = [row[:] for row in grid]
    best_score = total_side(best)

    # Try several heuristic patterns depending on n.
    # Also try a greedy insertion of squares into gaps.
    # For robustness, run local optimization with random restarts.

    def random_config():
        cfg = []
        # place points randomly with small sizes
        for _ in range(n):
            cfg.append([random.random(), random.random(), random.random(), 0.0])
        return cfg

    def repair(cfg):
        # scale down squares until they fit; if still overlapping, shrink.
        # First clamp positions and angles
        for a in cfg:
            a[0] = min(1.0, max(0.0, a[0]))
            a[1] = min(1.0, max(0.0, a[1]))
            a[2] = a[2] % 1.0
            a[3] = max(0.0, min(1.0, a[3]))
        # remove overlaps by shrinking the larger one
        changed = True
        it = 0
        while changed and it < 100:
            changed = False
            it += 1
            for i in range(n):
                for j in range(i + 1, n):
                    if overlap(cfg[i], cfg[j]):
                        # shrink the one with larger side, or both slightly
                        if cfg[i][3] >= cfg[j][3]:
                            cfg[i][3] *= 0.9
                        else:
                            cfg[j][3] *= 0.9
                        changed = True
            # push inside
            for a in cfg:
                if not inside_unit(a):
                    # shrink until inside or zero
                    for _ in range(20):
                        a[3] *= 0.9
                        if inside_unit(a):
                            break
                    else:
                        a[3] = 0.0
        return cfg

    # Score function
    def score(cfg):
        return sum(a[3] for a in cfg)

    # Local improvement: try to increase each square's side, adjust positions, maybe angles.
    def local_opt(cfg, time_limit):
        cfg = [row[:] for row in cfg]
        cur_score = score(cfg)
        improved = True
        while improved and time.time() < time_limit:
            improved = False
            # Try enlarging each square
            for i in range(n):
                if time.time() >= time_limit:
                    break
                orig = cfg[i][:]
                # Try increasing side
                max_add = 0.05
                for add in [0.02, 0.01, 0.005, 0.002, 0.001]:
                    if orig[3] + add <= 1.0:
                        test = orig[:]
                        test[3] += add
                        # check validity
                        if inside_unit(test):
                            ok = True
                            for j in range(n):
                                if j != i and overlap(test, cfg[j]):
                                    ok = False
                                    break
                            if ok:
                                cfg[i] = test
                                cur_score += add
                                improved = True
                                break
                # Try small translations
                for dx, dy in [(0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01),
                               (0.005, 0.005), (-0.005, 0.005),
                               (0.005, -0.005), (-0.005, -0.005)]:
                    if time.time() >= time_limit:
                        break
                    test = cfg[i][:]
                    test[0] += dx
                    test[1] += dy
                    if test[0] < 0 or test[0] > 1 or test[1] < 0 or test[1] > 1:
                        continue
                    if inside_unit(test):
                        ok = True
                        for j in range(n):
                            if j != i and overlap(test, cfg[j]):
                                ok = False
                                break
                        if ok:
                            # try to enlarge after translation
                            old_side = test[3]
                            for add in [0.01, 0.005, 0.002]:
                                if test[3] + add <= 1.0:
                                    test2 = test[:]
                                    test2[3] += add
                                    if inside_unit(test2):
                                        ok2 = True
                                        for j in range(n):
                                            if j != i and overlap(test2, cfg[j]):
                                                ok2 = False
                                                break
                                        if ok2:
                                            test = test2
                                            break
                            if test[3] > old_side or (test[0] != cfg[i][0] or test[1] != cfg[i][1]):
                                cfg[i] = test
                                improved = True
                                break
                # Try small angle changes
                for da in [0.01, -0.01, 0.005, -0.005]:
                    if time.time() >= time_limit:
                        break
                    test = cfg[i][:]
                    test[2] = (test[2] + da) % 1.0
                    if inside_unit(test):
                        ok = True
                        for j in range(n):
                            if j != i and overlap(test, cfg[j]):
                                ok = False
                                break
                        if ok:
                            old_side = test[3]
                            for add in [0.01, 0.005, 0.002]:
                                if test[3] + add <= 1.0:
                                    test2 = test[:]
                                    test2[3] += add
                                    if inside_unit(test2):
                                        ok2 = True
                                        for j in range(n):
                                            if j != i and overlap(test2, cfg[j]):
                                                ok2 = False
                                                break
                                        if ok2:
                                            test = test2
                                            break
                            if test[3] > old_side or test[2] != cfg[i][2]:
                                cfg[i] = test
                                improved = True
                                break
        return cfg

    # Try initial patterns
    candidates = []

    # Pattern 1: grid as above
    candidates.append([row[:] for row in grid])

    # Pattern 2: shifted rows (hexagonal-like)
    if k >= 2:
        cfg = []
        s = 1.0 / k
        offset = True
        for i in range(k):
            y = (i + 0.5) * s
            for j in range(k):
                x = (j + 0.5) * s
                if offset and i % 2 == 1:
                    x += s * 0.5
                if x > 1 - s * 0.5:
                    x -= s
                cfg.append([x, y, 0.0, s * 0.9])
        while len(cfg) < n:
            cfg.append([0.5, 0.5, 0.0, 0.0])
        candidates.append(repair(cfg[:n]))

    # Pattern 3: random
    for _ in range(5):
        cfg = random_config()
        cfg = repair(cfg)
        candidates.append(cfg)

    # Pattern 4: greedy insertion
    # Start with empty, insert squares one by one maximizing side.
    def greedy_insert(n):
        cfg = []
        for i in range(n):
            best_side = 0.0
            best_place = (0.5, 0.5, 0.0, 0.0)
            # try random points
            for _ in range(200):
                cx = random.random()
                cy = random.random()
                ang = random.random() if i > 0 else 0.0
                # binary search max side
                lo, hi = 0.0, 1.0
                for _ in range(12):
                    mid = (lo + hi) * 0.5
                    test = [cx, cy, ang, mid]
                    if not inside_unit(test):
                        hi = mid
                        continue
                    ok = True
                    for other in cfg:
                        if overlap(test, other):
                            ok = False
                            break
                    if ok:
                        lo = mid
                    else:
                        hi = mid
                if lo > best_side:
                    best_side = lo
                    best_place = (cx, cy, ang, lo)
            cfg.append(list(best_place))
        return cfg

    for _ in range(3):
        cfg = greedy_insert(n)
        candidates.append(cfg)

    # Evaluate and improve candidates
    time_per_candidate = max(0.5, (50.0 - (time.time() - t0)) / max(1, len(candidates) + 2))
    for cfg in candidates:
        if time.time() - t0 > 50:
            break
        cfg = local_opt(cfg, min(time.time() + time_per_candidate, t0 + 50))
        sc = score(cfg)
        if sc > best_score:
            best_score = sc
            best = [row[:] for row in cfg]

    # Final repair if needed (safety)
    best = repair(best)

    # Convert to required output format
    return [(a[0], a[1], a[2], a[3]) for a in best]
