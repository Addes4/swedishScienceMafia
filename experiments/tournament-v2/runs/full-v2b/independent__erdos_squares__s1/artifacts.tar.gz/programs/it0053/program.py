import math
import random

# ---------- geometry helpers ----------

def _corners(cx, cy, ang_turns, s):
    """Return 4 corners of a square (cx,cy), angle in turns, side s."""
    a = ang_turns * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
    return out


def _axes(ang_turns):
    a = ang_turns * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    # local x-axis and y-axis
    return (ca, sa), (-sa, ca)


def _overlap_sq(A, B, eps=1e-12):
    """A,B: (cx,cy,angle,side). Return True if interiors overlap."""
    if A[3] <= eps or B[3] <= eps:
        return False
    ca = _corners(*A)
    cb = _corners(*B)
    axes = []
    axA, ayA = _axes(A[2])
    axB, ayB = _axes(B[2])
    axes.extend([axA, ayA, axB, ayB])
    # SAT
    for ax in axes:
        pa = [p[0] * ax[0] + p[1] * ax[1] for p in ca]
        pb = [p[0] * ax[0] + p[1] * ax[1] for p in cb]
        if max(pa) <= min(pb) + eps or max(pb) <= min(pa) + eps:
            return False
    return True


def _inside(cx, cy, ang_turns, s, eps=1e-9):
    if s <= eps:
        return 0 <= cx <= 1 and 0 <= cy <= 1
    for x, y in _corners(cx, cy, ang_turns, s):
        if x < -eps or x > 1 + eps or y < -eps or y > 1 + eps:
            return False
    return True


def _ok_single(sq, eps=1e-12):
    return _inside(*sq, eps=eps)


def _all_ok(sqs, changed=None):
    n = len(sqs)
    for i in range(n):
        if not _ok_single(sqs[i]):
            return False
    if changed is None:
        for i in range(n):
            for j in range(i + 1, n):
                if _overlap_sq(sqs[i], sqs[j]):
                    return False
    else:
        for j in range(n):
            if j == changed:
                continue
            if _overlap_sq(sqs[changed], sqs[j]):
                return False
    return True


# ---------- heuristics ----------

def _greedy_fill(n):
    """Build an initial feasible set: greedy largest squares on a fine candidate lattice."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    sqs = []
    # candidate centers and angles
    # Fine near-axis aligned grid plus some rotations for diversity
    angles = [0.0, 0.25, 0.125, 0.375, 0.0625, 0.1875, 0.3125, 0.4375]
    # candidate positions: dense grid, plus jitter attempts later
    m = 41
    cands = []
    for i in range(m):
        for j in range(m):
            cands.append((i / (m - 1.0), j / (m - 1.0)))

    random.seed(12345)
    # random permutation of candidates for diversity across restarts
    rng = random.Random(987654321)

    def try_add(sqs, cx, cy, ang, smax):
        # binary search largest feasible side at this (cx,cy,ang)
        lo, hi = 0.0, smax
        # quick reject
        if not _inside(cx, cy, ang, hi):
            # bisect for max inside
            for _ in range(28):
                mid = (lo + hi) * 0.5
                if _inside(cx, cy, ang, mid):
                    lo = mid
                else:
                    hi = mid
            hi = lo
            lo = 0.0
        best = 0.0
        for _ in range(26):
            mid = (lo + hi) * 0.5
            sq = (cx, cy, ang, mid)
            ok = True
            for s2 in sqs:
                if _overlap_sq(sq, s2, eps=1e-10):
                    ok = False
                    break
            if ok:
                best = mid
                lo = mid
            else:
                hi = mid
        return best

    # build
    for _ in range(n):
        best = None
        order = cands[:]
        # sample a subset for speed
        if len(order) > 900:
            rng.shuffle(order)
            order = order[:900]
        for cx, cy in order:
            for ang in angles:
                s = try_add(sqs, cx, cy, ang, 1.0)
                if s > 1e-12:
                    if best is None or s > best[3]:
                        best = (cx, cy, ang, s)
        if best is None:
            # fallback tiny random feasible point
            for _ in range(500):
                cx = rng.random()
                cy = rng.random()
                ang = rng.random()
                s = 0.0
                if _inside(cx, cy, ang, 1e-6):
                    # grow
                    lo, hi = 0.0, 1e-3
                    while hi < 1.0 and _inside(cx, cy, ang, hi):
                        hi *= 2
                    hi = min(hi, 1.0)
                    for _ in range(20):
                        mid = (lo + hi) * 0.5
                        if _inside(cx, cy, ang, mid):
                            lo = mid
                        else:
                            hi = mid
                    s = lo
                if s > 0:
                    sq = (cx, cy, ang, s)
                    if all(not _overlap_sq(sq, t) for t in sqs):
                        best = sq
                        break
            if best is None:
                best = (0.5, 0.5, 0.0, 0.0)
        sqs.append(best)
    return sqs


def _perturb(sqs, rng, temp):
    """One local move: perturb a random square, return new list or None."""
    n = len(sqs)
    if n == 0:
        return None
    new = list(sqs)
    i = rng.randrange(n)
    cx, cy, ang, s = new[i]
    mode = rng.random()
    # choose move type
    if mode < 0.55:
        # move
        dx = rng.gauss(0, 0.03 * temp)
        dy = rng.gauss(0, 0.03 * temp)
        ncx = min(1.0, max(0.0, cx + dx))
        ncy = min(1.0, max(0.0, cy + dy))
        nang = (ang + rng.gauss(0, 0.05 * temp)) % 1.0
        ns = s
    elif mode < 0.75:
        # rotate
        ncx, ncy = cx, cy
        nang = (ang + rng.gauss(0, 0.15 * temp)) % 1.0
        ns = s
    elif mode < 0.95:
        # resize
        ncx, ncy = cx, cy
        nang = ang
        ns = max(0.0, s * (1.0 + rng.gauss(0, 0.12 * temp)))
        ns = min(ns, 1.0)
    else:
        # big jump
        ncx = rng.random()
        ncy = rng.random()
        nang = rng.random()
        ns = s
    cand = (ncx, ncy, nang, ns)
    # feasibility
    if not _ok_single(cand):
        # try to shrink to fit
        lo, hi = 0.0, cand[3]
        if _inside(ncx, ncy, nang, hi):
            lo = hi
        else:
            for _ in range(20):
                mid = (lo + hi) * 0.5
                if _inside(ncx, ncy, nang, mid):
                    lo = mid
                else:
                    hi = mid
        cand = (ncx, ncy, nang, lo)
        if cand[3] <= 1e-12 and s <= 1e-12:
            return None
    # check against others
    for j in range(n):
        if j == i:
            continue
        if _overlap_sq(cand, new[j]):
            return None
    new[i] = cand
    return new


def _score(sqs):
    return sum(s[3] for s in sqs)


def _optimize(sqs, time_budget=0.0):
    """Simulated-annealing-ish local improvement."""
    rng = random.Random(20240607)
    best = list(sqs)
    best_s = _score(best)
    cur = list(best)
    cur_s = best_s
    temp = 1.0
    it = 0
    # iterations budget derived loosely; time is wall clock limited outside if needed
    max_it = max(4000, 2500 * len(sqs))
    for it in range(max_it):
        cand = _perturb(cur, rng, temp)
        if cand is None:
            temp *= 0.9995
            continue
        cs = _score(cand)
        if cs >= cur_s or rng.random() < math.exp((cs - cur_s) / max(1e-9, 0.002 * temp)):
            cur = cand
            cur_s = cs
            if cs > best_s:
                best = cand
                best_s = cs
        temp *= 0.9995
        if temp < 1e-4:
            temp = 0.02
    return best


def _rebalance(sqs):
    """Try to grow some squares by temporarily removing and re-placing the smallest."""
    best = list(sqs)
    best_s = _score(best)
    rng = random.Random(555)
    n = len(best)
    if n <= 1:
        return best

    # attempt: remove smallest k, re-add greedily
    for trial in range(6):
        order = sorted(range(n), key=lambda i: best[i][3])
        k = min(n, max(1, n // 8 + 1))
        removed_idx = set(order[:k])
        keep = [best[i] for i in range(n) if i not in removed_idx]
        new_sqs = list(keep)
        success = True
        for _ in range(k):
            # place largest possible new square greedily
            best_place = None
            angles = [0.0, 0.25, 0.125, 0.375, 0.0625, 0.1875]
            m = 25
            positions = [(i / (m - 1.0), j / (m - 1.0)) for i in range(m) for j in range(m)]
            rng.shuffle(positions)
            for cx, cy in positions[:250]:
                for ang in angles:
                    # max side feasible
                    lo, hi = 0.0, 1.0
                    if not _inside(cx, cy, ang, hi):
                        h = 0.0
                        l = 0.0
                        r = 1.0
                        for _ in range(24):
                            mid = (l + r) * 0.5
                            if _inside(cx, cy, ang, mid):
                                l = mid
                            else:
                                r = mid
                        hi = l
                        lo = 0.0
                    for _ in range(22):
                        mid = (lo + hi) * 0.5
                        sq = (cx, cy, ang, mid)
                        if all(not _overlap_sq(sq, t) for t in new_sqs):
                            lo = mid
                        else:
                            hi = mid
                    if lo > 1e-12:
                        if best_place is None or lo > best_place[3]:
                            best_place = (cx, cy, ang, lo)
            if best_place is None:
                success = False
                break
            new_sqs.append(best_place)
        if success and len(new_sqs) == n:
            s = _score(new_sqs)
            if s > best_s:
                best = new_sqs
                best_s = s
                best = _optimize(best)
                best_s = _score(best)
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # start
    sqs = _greedy_fill(n)
    sqs = _optimize(sqs)
    sqs = _rebalance(sqs)
    sqs = _optimize(sqs)

    # ensure feasibility and correct length
    out = []
    for s in sqs[:n]:
        cx = min(1.0, max(0.0, s[0]))
        cy = min(1.0, max(0.0, s[1]))
        ang = s[2] % 1.0
        side = max(0.0, s[3])
        if not _ok_single((cx, cy, ang, side)):
            side = 0.0
        out.append((cx, cy, ang, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))

    # final repair pass: remove overlaps if any
    changed = True
    guard = 0
    while changed and guard < 200:
        changed = False
        guard += 1
        for i in range(n):
            for j in range(i + 1, n):
                if _overlap_sq(out[i], out[j]):
                    # shrink the smaller one
                    if out[i][3] <= out[j][3]:
                        out[i] = (out[i][0], out[i][1], out[i][2], 0.0)
                    else:
                        out[j] = (out[j][0], out[j][1], out[j][2], 0.0)
                    changed = True
    return out
