import math
import random

# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _rot_bbox(cx, cy, ang, s):
    """Axis-aligned bounding box of a square with centre (cx,cy), rotation ang
    (fraction of full turn), side s.  Returns (xmin, ymin, xmax, ymax)."""
    t = ang * 2.0 * math.pi
    ca, sa = math.cos(t), math.sin(t)
    h = s * 0.5
    # half-extent along world axes
    ex = abs(ca) * h + abs(sa) * h
    ey = abs(sa) * h + abs(ca) * h
    return (cx - ex, cy - ey, cx + ex, cy + ey)


def _overlap_area(a, b):
    """Exact overlap area of two rotated squares.  Returns 0 if disjoint."""
    # Use separating-axis theorem on the 4 axes of each square.
    ax, ay, aa, as_ = a
    bx, by, ba, bs = b
    if as_ <= 0.0 or bs <= 0.0:
        return 0.0

    ta = aa * 2.0 * math.pi
    ca, sa = math.cos(ta), math.sin(ta)
    ux, uy = ca, sa          # local x axis of A
    vx, vy = -sa, ca         # local y axis of A

    tb = ba * 2.0 * math.pi
    cb, sb = math.cos(tb), math.sin(tb)
    px, py = cb, sb
    qx, qy = -sb, cb

    axes = [(ux, uy), (vx, vy), (px, py), (qx, qy)]

    for nx, ny in axes:
        # project both squares onto axis n
        # centre projection
        c1 = ax * nx + ay * ny
        c2 = bx * nx + by * ny
        # half width of projection of a rotated square with side s:
        # s/2 * (|n . e1| + |n . e2|)
        ha = as_ * 0.5 * (abs(nx * ux + ny * uy) + abs(nx * vx + ny * vy))
        hb = bs * 0.5 * (abs(nx * px + ny * py) + abs(nx * qx + ny * qy))
        if abs(c1 - c2) >= ha + hb - 1e-15:
            return 0.0
    # overlap: use polygon clipping (Sutherland-Hodgman)
    A = _square_poly(ax, ay, aa, as_)
    B = _square_poly(bx, by, ba, bs)
    clipped = _clip_poly(A, B)
    return abs(_poly_area(clipped))


def _square_poly(cx, cy, ang, s):
    t = ang * 2.0 * math.pi
    ca, sa = math.cos(t), math.sin(t)
    h = s * 0.5
    return [
        (cx + ca * h - sa * h, cy + sa * h + ca * h),
        (cx + ca * h + sa * h, cy + sa * h - ca * h),
        (cx - ca * h + sa * h, cy - sa * h - ca * h),
        (cx - ca * h - sa * h, cy - sa * h + ca * h),
    ]


def _clip_poly(subject, clip):
    def inside(p, a, b):
        return (b[0]-a[0])*(p[1]-a[1]) - (b[1]-a[1])*(p[0]-a[0]) >= -1e-12
    def inter(p, a, b):
        d1x, d1y = b[0]-a[0], b[1]-a[1]
        d2x, d2y = p[1]-a[1], p[0]-a[0]
        den = d1x*d2y - d1y*d2x
        if abs(den) < 1e-18:
            return p
        d3x, d3y = p[0]-a[0], p[1]-a[1]
        t = (d3x*d1y - d3y*d1x)/den
        return (p[0] + t*(p[1]-p[0]), p[1] + t*(p[0]-p[1]))
    # normalise to clockwise
    def signed_area(poly):
        s = 0.0
        for i in range(len(poly)):
            x1,y1 = poly[i]; x2,y2 = poly[(i+1)%len(poly)]
            s += x1*y2 - x2*y1
        return s*0.5
    # robust generic clipper
    def clip_edge(poly, a, b):
        out = []
        n = len(poly)
        for i in range(n):
            cur = poly[i]
            prv = poly[i-1]
            cur_in = inside(cur, a, b)
            prv_in = inside(prv, a, b)
            if cur_in:
                if not prv_in:
                    out.append(_seg_inter(prv, cur, a, b))
                out.append(cur)
            elif prv_in:
                out.append(_seg_inter(prv, cur, a, b))
        return out
    out = subject
    m = len(clip)
    for i in range(m):
        if len(out) < 3:
            return []
        a = clip[i]
        b = clip[(i+1)%m]
        out = clip_edge(out, a, b)
    return out


def _seg_inter(p, q, a, b):
    # line p-q with line a-b
    r = (q[0]-p[0], q[1]-p[1])
    s = (b[0]-a[0], b[1]-a[1])
    den = r[0]*s[1] - r[1]*s[0]
    if abs(den) < 1e-18:
        return p
    qp = (a[0]-p[0], a[1]-p[1])
    t = (qp[0]*s[1] - qp[1]*s[0])/den
    return (p[0]+t*r[0], p[1]+t*r[1])


def _poly_area(poly):
    if len(poly) < 3:
        return 0.0
    s = 0.0
    n = len(poly)
    for i in range(n):
        x1,y1 = poly[i]; x2,y2 = poly[(i+1)%n]
        s += x1*y2 - x2*y1
    return s*0.5


def _outside(cx, cy, ang, s, margin=1e-9):
    x0, y0, x1, y1 = _rot_bbox(cx, cy, ang, s)
    return x0 < -margin or y0 < -margin or x1 > 1.0+margin or y1 > 1.0+margin


def _penalty(squares):
    """Total overlap + out-of-bounds amount."""
    pen = 0.0
    n = len(squares)
    for i in range(n):
        x, y, a, s = squares[i]
        if s <= 0:
            continue
        x0, y0, x1, y1 = _rot_bbox(x, y, a, s)
        if x0 < 0: pen += -x0
        if y0 < 0: pen += -y0
        if x1 > 1.0: pen += x1-1.0
        if y1 > 1.0: pen += y1-1.0
    for i in range(n):
        xi, yi, ai, si = squares[i]
        if si <= 0: continue
        for j in range(i+1, n):
            xj, yj, aj, sj = squares[j]
            if sj <= 0: continue
            # quick reject
            bx1 = _rot_bbox(xi, yi, ai, si)
            bx2 = _rot_bbox(xj, yj, aj, sj)
            if bx1[2] <= bx2[0] or bx2[2] <= bx1[0] or bx1[3] <= bx2[1] or bx2[3] <= bx1[1]:
                continue
            ov = _overlap_area(squares[i], squares[j])
            pen += ov * 10.0
    return pen


# ---------------------------------------------------------------------------
# Structured packings
# ---------------------------------------------------------------------------

def _grid_pack(n):
    """k x k full squares, rest zero.  k = floor(sqrt(n))."""
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)]*n
    s = 1.0/k
    res = [((i+0.5)*s, (j+0.5)*s, 0.0, s) for i in range(k) for j in range(k)]
    res += [(0.5, 0.5, 0.0, 0.0)]*(n-len(res))
    return res[:n]


def _rows_pack(n):
    """Put squares in rows; each row same height, choose row count/widths."""
    if n == 0:
        return []
    best = None
    for rows in range(1, n+1):
        cols = (n + rows - 1)//rows
        # count squares per row
        counts = []
        rem = n
        for r in range(rows):
            c = min(cols, rem)
            counts.append(c)
            rem -= c
        h = 1.0/rows
        # each row: c squares of side h
        total = 0.0
        cand = []
        y = 0.0
        for r, c in enumerate(counts):
            if c == 0: break
            # can we fit c squares of side h in width 1?
            w = min(h, 1.0/c)
            actual = min(h, 1.0/c)
            # use square side = min(h, 1/c)
            for i in range(c):
                x = (i+0.5)*actual
                cand.append((x, y+0.5*actual, 0.0, actual))
            y += actual
            total += c*actual
        # fill remainder
        while len(cand) < n:
            cand.append((0.5, 0.5, 0.0, 0.0))
        if best is None or total > best[0]:
            best = (total, cand[:n])
    return best[1]


def _uniform_pack(n):
    """n equal squares in a ceil(sqrt(n)) grid, trimmed."""
    k = math.ceil(math.sqrt(n))
    s = 1.0/k
    res = []
    for i in range(k):
        for j in range(k):
            if len(res) < n:
                res.append(((i+0.5)*s, (j+0.5)*s, 0.0, s))
    return res


# ---------------------------------------------------------------------------
# Improvement: coordinate descent
# ---------------------------------------------------------------------------

def _optimize(squares, iters=300, rng=None):
    squares = [list(sq) for sq in squares]
    n = len(squares)
    if rng is None:
        rng = random.Random(12345)

    def score(sqs):
        return _penalty(sqs)

    cur_pen = score(squares)

    step = 0.05
    for it in range(iters):
        improved = False
        # try scaling all
        for i in range(n):
            if squares[i][3] <= 0 and cur_pen < 1e-12:
                # small square may grow here
                pass
            for dim in range(4):
                old = squares[i][dim]
                if dim == 3:
                    delta = step * rng.uniform(0.2, 1.0)
                else:
                    delta = step * rng.uniform(-1.0, 1.0)
                for sign in (1, -1):
                    squares[i][dim] = old + sign*delta
                    if squares[i][3] < 0:
                        squares[i][3] = 0.0
                    # clamp centre
                    if dim == 0:
                        squares[i][0] = min(1.0, max(0.0, squares[i][0]))
                    if dim == 1:
                        squares[i][1] = min(1.0, max(0.0, squares[i][1]))
                    if dim == 2:
                        squares[i][2] = squares[i][2] % 1.0
                    if dim == 3 and squares[i][3] > 1.0:
                        squares[i][3] = 1.0
                    p = score(squares)
                    if p < cur_pen - 1e-15:
                        cur_pen = p
                        improved = True
                        break
                    else:
                        squares[i][dim] = old
                else:
                    continue
                break
        if not improved:
            step *= 0.5
            if step < 1e-4:
                break
    return [tuple(sq) for sq in squares]


# ---------------------------------------------------------------------------
# Objective
# ---------------------------------------------------------------------------

def _sum_sides(squares):
    return sum(sq[3] for sq in squares)


def _valid(squares, eps=1e-9):
    for i in range(len(squares)):
        if _outside(*squares[i], margin=1e-7):
            return False
    for i in range(len(squares)):
        xi,yi,ai,si = squares[i]
        if si <= 0: continue
        for j in range(i+1,len(squares)):
            xj,yj,aj,sj = squares[j]
            if sj <= 0: continue
            if _overlap_area(squares[i], squares[j]) > 1e-9:
                return False
    return True


def _repair(squares):
    """Push squares apart / shrink until valid."""
    sq = [list(s) for s in squares]
    n = len(sq)
    # shrink slightly if overlaps
    for _ in range(200):
        bad = False
        for i in range(n):
            if sq[i][3] <= 0: continue
            x0,y0,x1,y1 = _rot_bbox(*sq[i])
            if x0 < -1e-12 or y0 < -1e-12 or x1 > 1+1e-12 or y1 > 1+1e-12:
                # shrink
                sq[i][3] *= 0.999
                bad = True
        for i in range(n):
            xi,yi,ai,si = sq[i]
            if si <= 0: continue
            for j in range(i+1,n):
                xj,yj,aj,sj = sq[j]
                if sj <= 0: continue
                if _overlap_area(tuple(sq[i]), tuple(sq[j])) > 1e-12:
                    sq[i][3] *= 0.98
                    sq[j][3] *= 0.98
                    bad = True
            # keep inside
            if sq[i][3] > 0:
                x0,y0,x1,y1 = _rot_bbox(*sq[i])
                if x0 < 0:
                    sq[i][0] += -x0
                if y0 < 0:
                    sq[i][1] += -y0
                if x1 > 1:
                    sq[i][0] -= (x1-1)
                if y1 > 1:
                    sq[i][1] -= (y1-1)
        if not bad:
            break
    return [tuple(s) for s in sq]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side by side, each 0.5
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    candidates = []
    candidates.append(_grid_pack(n))
    candidates.append(_rows_pack(n))
    candidates.append(_uniform_pack(n))

    # refine best few
    best = None
    best_val = -1.0
    for cand in candidates:
        val = _sum_sides(cand)
        if val > best_val:
            best_val = val
            best = cand

    # try local optimisation on the best candidate
    rng = random.Random(98765 + n)
    for attempt in range(6 if n <= 30 else 3):
        start = [list(s) for s in best]
        if attempt > 0:
            # perturb
            for k in range(n):
                start[k][0] = min(1.0, max(0.0, start[k][0] + rng.uniform(-0.05, 0.05)))
                start[k][1] = min(1.0, max(0.0, start[k][1] + rng.uniform(-0.05, 0.05)))
                start[k][3] = max(0.0, min(1.0, start[k][3] * rng.uniform(0.9, 1.1)))
        opt = _optimize(start, iters=200, rng=rng)
        opt = _repair(opt)
        val = _sum_sides(opt)
        if val > best_val and _valid(opt, 1e-7):
            best_val = val
            best = opt

    best = _repair(best)
    # final validity guarantee
    if not _valid(best, 1e-6):
        best = _repair(best)
    best = best[:n]
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    # clamp all
    out = []
    for x,y,a,s in best:
        x = min(1.0, max(0.0, x))
        y = min(1.0, max(0.0, y))
        a = a % 1.0
        s = min(1.0, max(0.0, s))
        out.append((x,y,a,s))
    return out
