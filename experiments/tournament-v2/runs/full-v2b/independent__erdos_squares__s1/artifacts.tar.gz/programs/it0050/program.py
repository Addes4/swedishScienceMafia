import math
import random
import numpy as np
from scipy.optimize import minimize


def _square_vertices(cx, cy, angle, side):
    """Return the 4 vertices of a square as an (4,2) array."""
    a = 2.0 * math.pi * angle
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * side
    # corners in local coordinates
    local = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    R = np.array([[ca, -sa], [sa, ca]], dtype=float)
    return local @ R.T + np.array([cx, cy])


def _overlap_area_sat(poly1, poly2):
    """Approximate overlap area via separating axis theorem (returns 0 if disjoint)."""
    # Convex polygon clipping would be more precise; SAT gives a quick check.
    # Compute overlap of projections on all edge normals.
    overlap_min = 1e9
    for poly_a, poly_b in ((poly1, poly2), (poly2, poly1)):
        n = len(poly_a)
        for i in range(n):
            p1 = poly_a[i]
            p2 = poly_a[(i + 1) % n]
            edge = p2 - p1
            axis = np.array([-edge[1], edge[0]])
            norm = np.linalg.norm(axis)
            if norm < 1e-12:
                continue
            axis /= norm
            a_min = np.min(poly_a @ axis)
            a_max = np.max(poly_a @ axis)
            b_min = np.min(poly_b @ axis)
            b_max = np.max(poly_b @ axis)
            overlap = min(a_max, b_max) - max(a_min, b_min)
            if overlap <= 0:
                return 0.0
            if overlap < overlap_min:
                overlap_min = overlap
    return overlap_min


def _penalty(params, n, bounds_weight=1000.0):
    """Penalty for overlap and out-of-bounds, plus small bonus for larger sides."""
    total = 0.0
    polys = []
    sides = []
    for i in range(n):
        cx, cy, angle, side = params[4 * i:4 * i + 4]
        side = abs(side)
        sides.append(side)
        # clamp centre so square stays inside (soft constraint)
        v = _square_vertices(cx, cy, angle, side)
        polys.append(v)
        # out of bounds penalty
        xmin, ymin = np.min(v, axis=0)
        xmax, ymax = np.max(v, axis=0)
        if xmin < 0:
            total += bounds_weight * (0 - xmin) ** 2
        if ymin < 0:
            total += bounds_weight * (0 - ymin) ** 2
        if xmax > 1:
            total += bounds_weight * (xmax - 1) ** 2
        if ymax > 1:
            total += bounds_weight * (ymax - 1) ** 2

    # overlap penalty (pairwise)
    for i in range(n):
        for j in range(i + 1, n):
            ov = _overlap_area_sat(polys[i], polys[j])
            if ov > 0:
                total += 2000.0 * ov ** 2

    # objective: maximize sum of sides -> minimize negative sum
    total -= sum(sides)
    return total


def _repair(params, n):
    """Project parameters into valid ranges (centre, angle, side)."""
    p = np.array(params, dtype=float).copy()
    for i in range(n):
        cx, cy, angle, side = p[4 * i:4 * i + 4]
        side = max(0.0, min(1.0, side))
        angle = angle % 1.0
        # centre must keep square inside: conservative bound
        half_diag = 0.5 * side * math.sqrt(2.0)
        cx = max(half_diag, min(1.0 - half_diag, cx))
        cy = max(half_diag, min(1.0 - half_diag, cy))
        p[4 * i:4 * i + 4] = [cx, cy, angle, side]
    return p


def _initial_grid(n):
    """Initial placement: greedy grid with variable sizes."""
    k = math.isqrt(n)
    side = 1.0 / k
    result = []
    for i in range(k):
        for j in range(k):
            result.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # fill remaining with tiny squares
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Start from a good grid
    init = _initial_grid(n)

    # Build parameter vector
    p0 = np.zeros(4 * n, dtype=float)
    for i, (cx, cy, ang, side) in enumerate(init):
        p0[4 * i:4 * i + 4] = [cx, cy, ang, side]

    # Add small random perturbation
    rng = np.random.default_rng(12345)
    p0 += rng.normal(0, 0.01, size=p0.shape)
    p0 = _repair(p0, n)

    # Optimize with L-BFGS-B
    best_params = p0.copy()
    best_val = _penalty(p0, n)

    # Try a few random restarts
    for trial in range(3):
        if trial > 0:
            p = p0 + rng.normal(0, 0.05 if trial == 1 else 0.15, size=p0.shape)
            p = _repair(p, n)
        else:
            p = p0.copy()
        try:
            res = minimize(_penalty, p, args=(n,), method='L-BFGS-B',
                           options={'maxiter': 200, 'ftol': 1e-10, 'gtol': 1e-8})
            if res.fun < best_val:
                best_val = res.fun
                best_params = _repair(res.x, n)
        except Exception:
            pass

    # Final repair and pack into required format
    best_params = _repair(best_params, n)
    result = []
    for i in range(n):
        cx, cy, ang, side = best_params[4 * i:4 * i + 4]
        side = max(0.0, min(1.0, side))
        ang = ang % 1.0
        # final clamp
        half_diag = 0.5 * side * math.sqrt(2.0)
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        result.append((float(cx), float(cy), float(ang), float(side)))
    return result
