import math
import random
import time


def _corners(cx, cy, ang, s):
    """Return the 4 corners of a square in CCW order."""
    h = s * 0.5
    co, si = math.cos(ang * 2.0 * math.pi), math.sin(ang * 2.0 * math.pi)
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for (x, y) in pts:
        out.append((cx + x * co - y * si, cy + x * si + y * co))
    return out


def _overlap(a, b):
    """Separating axis test for two convex polygons."""
    ax, ay, aa, as_ = a
    bx, by, ba, bs = b
    ca = _corners(ax, ay, aa, as_)
    cb = _corners(bx, by, ba, bs)
    for poly, other in ((ca, cb), (cb, ca)):
        for i in range(4):
            p1 = poly[i]
            p2 = poly[(i + 1) % 4]
            ex = p2[0] - p1[0]
            ey = p2[1] - p1[1]
            nx, ny = -ey, ex
            mn1 = mn2 = float('inf')
            mx1 = mx2 = float('-inf')
            for (x, y) in poly:
                d = x * nx + y * ny
                if d < mn1:
                    mn1 = d
                if d > mx1:
                    mx1 = d
            for (x, y) in other:
                d = x * nx + y * ny
                if d < mn2:
                    mn2 = d
                if d > mx2:
                    mx2 = d
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return False
    return True


def _check_all(sqs):
    n = len(sqs)
    for i in range(n):
        a = sqs[i]
        if a[3] <= 0:
            continue
        for j in range(i + 1, n):
            b = sqs[j]
            if b[3] <= 0:
                continue
            if _overlap(a, b):
                return False
    return True


def _in_unit(cx, cy, ang, s):
    h = s * 0.5
    co, si = math.cos(ang * 2.0 * math.pi), math.sin(ang * 2.0 * math.pi)
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    for (x, y) in pts:
        px = cx + x * co - y * si
        py = cy + x * si + y * co
        if px < -1e-12 or px > 1 + 1e-12 or py < -1e-12 or py > 1 + 1e-12:
            return False
    return True


def _initial(n):
    # Try several grid layouts and pick the best valid one by total side.
    best = None
    best_score = -1.0
    for k in range(1, int(math.sqrt(n)) + 2):
        if k * k > n:
            continue
        side = 1.0 / k
        sqs = []
        for i in range(k):
            for j in range(k):
                sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        while len(sqs) < n:
            sqs.append((0.5, 0.5, 0.0, 0.0))
        sqs = sqs[:n]
        sc = sum(s[3] for s in sqs)
        if sc > best_score:
            best_score = sc
            best = sqs
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345 + n)
    start = _initial(n)
    best = [list(s) for s in start]
    best_score = sum(s[3] for s in best)

    # Local search
    cur = [list(s) for s in best]
    cur_score = best_score

    t_end = time.time() + 55.0
    it = 0
    while time.time() < t_end:
        it += 1
        # pick a random square to perturb
        i = random.randrange(n)
        old = cur[i][:]
        sq = cur[i][:]
        # choose action
        r = random.random()
        if r < 0.35:
            # perturb center
            sq[0] += random.gauss(0, 0.02)
            sq[1] += random.gauss(0, 0.02)
        elif r < 0.55:
            # perturb angle
            sq[2] += random.gauss(0, 0.02)
        elif r < 0.9:
            # perturb size
            sq[3] += random.gauss(0, 0.02)
        else:
            # move toward free space: random jump
            sq[0] = random.random()
            sq[1] = random.random()
            sq[2] = random.random()
            sq[3] = min(1.0, max(0.0, random.random() * 0.3))

        # clamp
        if sq[3] < 0:
            sq[3] = 0.0
        if sq[3] > 1.0:
            sq[3] = 1.0
        sq[2] = sq[2] % 1.0

        if not _in_unit(sq[0], sq[1], sq[2], sq[3]):
            # try to shrink back into unit square
            # scale size down until it fits or zero
            if sq[3] > 0:
                lo = 0.0
                hi = sq[3]
                for _ in range(20):
                    mid = 0.5 * (lo + hi)
                    if _in_unit(sq[0], sq[1], sq[2], mid):
                        lo = mid
                    else:
                        hi = mid
                sq[3] = lo
            if sq[3] <= 0:
                continue

        # check overlap with others
        ok = True
        for j in range(n):
            if j == i:
                continue
            b = cur[j]
            if b[3] <= 0:
                continue
            if _overlap(sq, b):
                ok = False
                break
        if not ok:
            # try to shrink size to resolve overlap
            # simple: reduce size gradually
            if sq[3] > 0:
                lo = 0.0
                hi = sq[3]
                for _ in range(25):
                    mid = 0.5 * (lo + hi)
                    sq[3] = mid
                    if not _in_unit(sq[0], sq[1], sq[2], sq[3]):
                        hi = mid
                        continue
                    ov = False
                    for j in range(n):
                        if j == i:
                            continue
                        b = cur[j]
                        if b[3] <= 0:
                            continue
                        if _overlap(sq, b):
                            ov = True
                            break
                    if ov:
                        hi = mid
                    else:
                        lo = mid
                sq[3] = lo
            if sq[3] <= 0:
                sq[3] = 0.0
                # accept as zero-size point
                # evaluate
                new_score = cur_score - old[3] + sq[3]
                # always accept zero (doesn't help but try)
                cur[i] = sq
                cur_score = new_score
                continue

        sq[3] = max(0.0, sq[3])
        new_score = cur_score - old[3] + sq[3]
        delta = new_score - cur_score
        temp = 0.02 * (1.0 - it / 100000.0)
        if temp < 1e-6:
            temp = 1e-6
        if delta >= 0 or random.random() < math.exp(delta / temp):
            cur[i] = sq
            cur_score = new_score
            if cur_score > best_score:
                # verify
                if _check_all(cur):
                    best_score = cur_score
                    best = [s[:] for s in cur]

    result = [(s[0], s[1], s[2] % 1.0, s[3]) for s in best]
    # Final verification and repair: ensure validity
    if not _check_all(result):
        result = _initial(n)
        result = [(s[0], s[1], s[2], s[3]) for s in result]
    return result
