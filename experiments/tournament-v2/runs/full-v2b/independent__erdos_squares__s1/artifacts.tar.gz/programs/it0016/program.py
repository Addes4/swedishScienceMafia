import math
import random
import time
from typing import List, Tuple

import numpy as np

try:
    from scipy.optimize import minimize
except Exception:
    minimize = None


# ------------------------------------------------------------
# Basic geometry / feasibility
# ------------------------------------------------------------

def _corners(cx, cy, ang, s):
    """Return 4 corners of a square as a 4x2 array."""
    a = ang * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = 0.5 * s
    # local corners in clockwise order
    local = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    rot = np.array([[c, -sn], [sn, c]], dtype=float)
    pts = local @ rot.T
    pts[:, 0] += cx
    pts[:, 1] += cy
    return pts


def _inside_unit(pts, tol=1e-12):
    return np.all(pts[:, 0] >= -tol) and np.all(pts[:, 0] <= 1.0 + tol) and \
           np.all(pts[:, 1] >= -tol) and np.all(pts[:, 1] <= 1.0 + tol)


def _sat_overlap(p1, p2, tol=1e-14):
    """Separating axis theorem for convex polygons. Returns True if interiors overlap."""
    # gather axes
    axes = []
    for poly in (p1, p2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            axes.append((-ey, ex))
    for ax, ay in axes:
        L = math.hypot(ax, ay)
        if L < 1e-15:
            continue
        ax /= L
        ay /= L
        min1 = min(p[0] * ax + p[1] * ay for p in p1)
        max1 = max(p[0] * ax + p[1] * ay for p in p1)
        min2 = min(p[0] * ax + p[1] * ay for p in p2)
        max2 = max(p[0] * ax + p[1] * ay for p in p2)
        if max1 <= min2 + tol or max2 <= min1 + tol:
            return False
    return True


def _feasible(sq, tol=1e-12):
    """sq: list of (cx, cy, ang, side). Check inside [0,1]^2 and pairwise disjoint interiors."""
    n = len(sq)
    if n == 0:
        return True
    params = np.asarray(sq, dtype=float)
    if np.any(params[:, 3] < -tol):
        return False
    corners = [_corners(cx, cy, ang, s) for cx, cy, ang, s in sq]
    for i in range(n):
        if not _inside_unit(corners[i], tol):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _sat_overlap(corners[i], corners[j]):
                return False
    return True


def _sum_sides(sq) -> float:
    return float(sum(max(0.0, s) for _, _, _, s in sq))


# ------------------------------------------------------------
# Constructions
# ------------------------------------------------------------

def _grid_construction(n):
    """Largest k x k axis-aligned grid plus zero-size leftovers."""
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _uniform_construction(n):
    """One square if n == 1, otherwise place n equal or nearly equal squares in rows."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n <= 0:
        return []
    # Try several row counts and take the best equal-size grid-like layout.
    best = None
    best_val = -1.0
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if rows * cols < n:
            continue
        side = min(1.0 / cols, 1.0 / rows)
        # layout rows*cols grid, but shrink side slightly if needed
        sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for j in range(rows) for i in range(cols)]
        # Fill with zeros if not enough
        sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        sq = sq[:n]
        if _feasible(sq):
            val = _sum_sides(sq)
            if val > best_val:
                best_val = val
                best = sq
    if best is None:
        best = _grid_construction(n)
    return best


# ------------------------------------------------------------
# Local search
# ------------------------------------------------------------

def _perturb_params(sq, rng, scale_pos=0.03, scale_ang=0.05, scale_s=0.03):
    """Return a perturbed copy, clipped/corrected to remain plausible."""
    out = []
    for cx, cy, ang, s in sq:
        if s <= 1e-15:
            out.append((cx, cy, ang, 0.0))
            continue
        cx2 = min(1.0, max(0.0, cx + rng.gauss(0.0, scale_pos)))
        cy2 = min(1.0, max(0.0, cy + rng.gauss(0.0, scale_pos)))
        ang2 = (ang + rng.gauss(0.0, scale_ang)) % 1.0
        s2 = max(0.0, min(1.0, s + rng.gauss(0.0, scale_s)))
        out.append((cx2, cy2, ang2, s2))
    return out


def _repair(sq, max_iter=30):
    """Shrink and re-center squares to fix infeasibility. Returns repaired list."""
    sq = [list(x) for x in sq]
    n = len(sq)
    if n == 0:
        return []
    # Iteratively shrink overlapping/large squares
    for _ in range(max_iter):
        changed = False
        # inside unit: shrink if needed; check axis-aligned bounding half-extent
        for i in range(n):
            cx, cy, ang, s = sq[i]
            # bounding half-extent of rotated square
            a = ang * 2.0 * math.pi
            hx = 0.5 * s * (abs(math.cos(a)) + abs(math.sin(a)))
            hy = hx
            if cx - hx < -1e-12 or cx + hx > 1 + 1e-12 or cy - hy < -1e-12 or cy + hy > 1 + 1e-12:
                # shrink to fit
                mx = min(cx, 1.0 - cx)
                my = min(cy, 1.0 - cy)
                max_h = min(mx, my)
                if hx > 1e-15:
                    factor = max_h / hx
                    if factor < 1.0:
                        s *= max(0.0, factor)
                        sq[i][3] = s
                        changed = True
                # recenter if still outside
                cx, cy, ang, s = sq[i]
                a = ang * 2.0 * math.pi
                hx = 0.5 * s * (abs(math.cos(a)) + abs(math.sin(a)))
                hy = hx
                cx = min(max(cx, hx), 1.0 - hx)
                cy = min(max(cy, hy), 1.0 - hy)
                sq[i][0] = cx
                sq[i][1] = cy
        # pairs
        for i in range(n):
            for j in range(i + 1, n):
                si = sq[i]
                sj = sq[j]
                if si[3] <= 1e-15 or sj[3] <= 1e-15:
                    continue
                pi = _corners(si[0], si[1], si[2], si[3])
                pj = _corners(sj[0], sj[1], sj[2], sj[3])
                if _sat_overlap(pi, pj, tol=0.0):
                    # shrink both a bit
                    f = 0.98
                    sq[i][3] = si[3] * f
                    sq[j][3] = sj[3] * f
                    changed = True
                    # move centres apart slightly
                    dx = sj[0] - si[0]
                    dy = sj[1] - si[1]
                    d = math.hypot(dx, dy) + 1e-12
                    push = 0.005 * (si[3] + sj[3])
                    sq[i][0] -= push * dx / d
                    sq[i][1] -= push * dy / d
                    sq[j][0] += push * dx / d
                    sq[j][1] += push * dy / d
                    # clip centres
                    for idx in (i, j):
                        cx, cy, ang, s = sq[idx]
                        a = ang * 2.0 * math.pi
                        h = 0.5 * s * (abs(math.cos(a)) + abs(math.sin(a)))
                        sq[idx][0] = min(max(cx, h), 1.0 - h)
                        sq[idx][1] = min(max(cy, h), 1.0 - h)
        if not changed:
            break
    # final validity check
    tuples = [(x[0], x[1], x[2], max(0.0, x[3])) for x in sq]
    if not _feasible(tuples):
        # fallback shrink all
        for x in sq:
            x[3] *= 0.9
        tuples = [(x[0], x[1], x[2], max(0.0, x[3])) for x in sq]
        if not _feasible(tuples):
            return _grid_construction(n)
    return [(x[0], x[1], x[2], max(0.0, x[3])) for x in sq]


def _greedy_increase_sizes(sq, rounds=4):
    """Try increasing each square's side while keeping feasibility."""
    sq = [list(x) for x in sq]
    n = len(sq)
    for _ in range(rounds):
        improved = False
        order = list(range(n))
        # larger squares first
        order.sort(key=lambda i: -sq[i][3])
        for i in order:
            cx, cy, ang, s = sq[i]
            if s >= 1.0 - 1e-15:
                continue
            lo, hi = s, 1.0000001
            # binary search max feasible size
            best_s = s
            for _ in range(24):
                mid = 0.5 * (lo + hi)
                test = [list(x) for x in sq]
                test[i][3] = mid
                # recentre if needed
                a = test[i][2] * 2.0 * math.pi
                h = 0.5 * mid * (abs(math.cos(a)) + abs(math.sin(a)))
                test[i][0] = min(max(test[i][0], h), 1.0 - h)
                test[i][1] = min(max(test[i][1], h), 1.0 - h)
                tt = [(x[0], x[1], x[2], x[3]) for x in test]
                if _feasible(tt, tol=1e-12):
                    best_s = mid
                    lo = mid
                else:
                    hi = mid
            if best_s > s + 1e-12:
                sq[i][3] = best_s
                a = sq[i][2] * 2.0 * math.pi
                h = 0.5 * best_s * (abs(math.cos(a)) + abs(math.sin(a)))
                sq[i][0] = min(max(sq[i][0], h), 1.0 - h)
                sq[i][1] = min(max(sq[i][1], h), 1.0 - h)
                improved = True
        if not improved:
            break
    return [(x[0], x[1], x[2], max(0.0, x[3])) for x in sq]


def _local_search(n, start, time_limit=2.5, seed=12345):
    """Simulated annealing / basin-hopping-ish search from a feasible start."""
    rng = random.Random(seed)
    cur = _repair(start)
    cur_val = _sum_sides(cur)
    best = cur
    best_val = cur_val

    t0 = time.time()
    it = 0
    temp0 = 0.08
    while time.time() - t0 < time_limit:
        it += 1
        T = temp0 * max(0.01, 1.0 - (time.time() - t0) / max(1e-9, time_limit))
        cand = _perturb_params(cur, rng)
        cand = _repair(cand)
        cand_val = _sum_sides(cand)
        if cand_val >= cur_val - 1e-15 or rng.random() < math.exp((cand_val - cur_val) / max(1e-9, T)):
            cur = cand
            cur_val = cand_val
            if cand_val > best_val + 1e-12:
                best = cand
                best_val = cand_val
        if it % 50 == 0:
            # greedy size increase occasionally
            cand = _greedy_increase_sizes(cur, rounds=1)
            cand_val = _sum_sides(cand)
            if cand_val > cur_val + 1e-12:
                cur = cand
                cur_val = cand_val
                if cand_val > best_val + 1e-12:
                    best = cand
                    best_val = cand_val
    return best, best_val


# ------------------------------------------------------------
# Main solver
# ------------------------------------------------------------

def solve(n: int) -> List[Tuple[float, float, float, float]]:
    """Return n squares inside the unit square with disjoint interiors,
    maximising the sum of side lengths."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # known optimum: two axis-aligned squares of side 0.5 side by side
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # 1x3 strip
        return [(1.0 / 6.0, 0.5, 0.0, 1.0 / 3.0),
                (0.5, 0.5, 0.0, 1.0 / 3.0),
                (5.0 / 6.0, 0.5, 0.0, 1.0 / 3.0)]

    # base feasible construction
    starts = []
    starts.append(_uniform_construction(n))
    starts.append(_grid_construction(n))

    # For small n, add some randomization to escape grid
    rng0 = random.Random(9876 + n)
    for _ in range(2):
        s = _perturb_params(_uniform_construction(n), rng0, 0.012, 0.02, 0.012)
        s = _repair(s)
        starts.append(s)

    # quick greedy improvement on each start
    improved_starts = []
    for s in starts:
        s2 = _greedy_increase_sizes(s, rounds=2)
        s2 = _repair(s2)
        improved_starts.append(s2)

    # choose best initial
    best = max(improved_starts, key=_sum_sides)
    best_val = _sum_sides(best)

    # time budget: keep total under ~25s to be safe
    global_deadline = time.time() + 22.0
    seed = 1234567
    attempts = 0
    while time.time() < global_deadline:
        attempts += 1
        rem = global_deadline - time.time()
        if rem <= 0.2:
            break
        budget = min(2.0, max(0.3, rem / 3.0))
        seed += 1
        start = max(improved_starts, key=_sum_sides) if attempts % 2 == 0 else improved_starts[attempts % len(improved_starts)]
        cand, cand_val = _local_search(n, start, time_limit=budget, seed=seed)
        if cand_val > best_val + 1e-12:
            best = cand
            best_val = cand_val
        # also try a greedy pass
        cand2 = _greedy_increase_sizes(best, rounds=2)
        cand2 = _repair(cand2)
        v2 = _sum_sides(cand2)
        if v2 > best_val + 1e-12:
            best = cand2
            best_val = v2
        if attempts >= 200:
            break

    # final validity and cleanup
    best = _repair(best)
    if not _feasible(best):
        best = _grid_construction(n)

    # ensure exactly n entries
    if len(best) < n:
        best = list(best) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    best = best[:n]

    # final micro greedy
    best = _greedy_increase_sizes(best, rounds=1)
    best = _repair(best)
    if not _feasible(best):
        best = _grid_construction(n)
    if len(best) < n:
        best = list(best) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    best = best[:n]

    # normalise/clean output
    out = []
    for cx, cy, ang, s in best:
        s = min(1.0, max(0.0, float(s)))
        cx = min(1.0, max(0.0, float(cx)))
        cy = min(1.0, max(0.0, float(cy)))
        ang = float(ang) % 1.0
        out.append((cx, cy, ang, s))
    return out


if __name__ == "__main__":
    # quick self-test
    for n in range(1, 10):
        sol = solve(n)
        print(n, len(sol), sum(s for *_, s in sol), _feasible(sol))
