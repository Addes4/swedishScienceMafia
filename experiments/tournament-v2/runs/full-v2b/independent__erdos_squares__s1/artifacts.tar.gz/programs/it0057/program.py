import math
import random
import numpy as np
from scipy.optimize import minimize

# ---------- helpers for collision / validity ----------

def square_corners(cx, cy, ang, s):
    """Return 4 corners of a square (center cx,cy, angle fraction of full turn, side s)."""
    if s <= 0:
        return [(cx, cy)] * 4
    theta = 2.0 * math.pi * ang
    c, sn = math.cos(theta), math.sin(theta)
    h = s * 0.5
    # local corners
    loc = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + c * x - sn * y, cy + sn * x + c * y) for (x, y) in loc]

def poly_axes(pts):
    """Return edge normals (axes) of convex polygon given by ordered points."""
    axes = []
    m = len(pts)
    for i in range(m):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % m]
        ex, ey = x2 - x1, y2 - y1
        n = math.hypot(ex, ey)
        if n > 1e-12:
            axes.append((-ey / n, ex / n))
    return axes

def project(pts, ax):
    dots = [p[0] * ax[0] + p[1] * ax[1] for p in pts]
    return min(dots), max(dots)

def polys_overlap(p1, p2, tol=1e-9):
    """SAT overlap test for convex polygons, allowing tiny touch."""
    axes = poly_axes(p1) + poly_axes(p2)
    for ax in axes:
        a1, b1 = project(p1, ax)
        a2, b2 = project(p2, ax)
        if b1 <= a2 + tol or b2 <= a1 + tol:
            return False
    return True

def overlap_area(p1, p2):
    """Approximate intersection area via Sutherland-Hodgman clipping."""
    def clip(poly, a, b):
        # clip poly by line a->b keeping left side
        res = []
        m = len(poly)
        dx, dy = b[0] - a[0], b[1] - a[1]
        for i in range(m):
            p = poly[i]
            q = poly[(i + 1) % m]
            sp = dx * (p[1] - a[1]) - dy * (p[0] - a[0])
            sq = dx * (q[1] - a[1]) - dy * (q[0] - a[0])
            if sp >= -1e-14:
                res.append(p)
            if (sp > 1e-14 and sq < -1e-14) or (sp < -1e-14 and sq > 1e-14):
                t = sp / (sp - sq)
                res.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])))
        return res

    out = p1[:]
    m = len(p2)
    for i in range(m):
        if not out:
            break
        a, b = p2[i], p2[(i + 1) % m]
        out = clip(out, a, b)
    if len(out) < 3:
        return 0.0
    area = 0.0
    for i in range(len(out)):
        x1, y1 = out[i]
        x2, y2 = out[(i + 1) % len(out)]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5

def compute_penalty_and_total(squares):
    """squares: list of (cx,cy,ang,s). Return (penalty, total_side)."""
    polys = [square_corners(cx, cy, ang, s) for (cx, cy, ang, s) in squares]
    total = sum(s for (_, _, _, s) in squares)
    pen = 0.0
    n = len(squares)
    # boundary penalty
    for i, (cx, cy, ang, s) in enumerate(squares):
        if s <= 0:
            continue
        pts = polys[i]
        for (x, y) in pts:
            if x < -1e-12:
                pen += (-x) * 100.0
            if x > 1 + 1e-12:
                pen += (x - 1) * 100.0
            if y < -1e-12:
                pen += (-y) * 100.0
            if y > 1 + 1e-12:
                pen += (y - 1) * 100.0
    # overlap penalty
    for i in range(n):
        if squares[i][3] <= 0:
            continue
        for j in range(i + 1, n):
            if squares[j][3] <= 0:
                continue
            if polys_overlap(polys[i], polys[j]):
                ov = overlap_area(polys[i], polys[j])
                pen += ov * 1000.0
    return pen, total

# ---------- initial packings ----------

def grid_packing(n):
    """k x k grid + tiny/zero squares."""
    if n == 0:
        return []
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]

def shelf_packing(n):
    """A guillotine shelf packing: rows of equal height squares."""
    if n == 0:
        return []
    best = None
    best_val = -1.0
    # try several row counts
    for rows in range(1, min(n, 20) + 1):
        # distribute n squares into 'rows' rows
        cols = [n // rows + (1 if i < n % rows else 0) for i in range(rows)]
        cols = [c for c in cols if c > 0]
        R = len(cols)
        if R == 0:
            continue
        # each row height must sum to <= 1; each row width: cols[i] * h_i <= 1
        # use h_i = min(1/R, 1/cols[i]) heuristic
        hs = [min(1.0 / R, 1.0 / cols[i]) for i in range(R)]
        ratio = sum(hs)
        if ratio > 1:
            # scale heights down
            scale = 1.0 / ratio
            hs = [h * scale for h in hs]
        y = 0.0
        res = []
        for i in range(R):
            h = hs[i]
            c = cols[i]
            w = 1.0 / c if c > 0 else 0.0
            s = min(h, w)
            # center each row
            for j in range(c):
                cx = (j + 0.5) * w
                cy = y + h * 0.5
                res.append((cx, cy, 0.0, s))
            y += h
        while len(res) < n:
            res.append((0.5, 0.5, 0.0, 0.0))
        val = sum(r[3] for r in res)
        if val > best_val:
            best_val = val
            best = res[:n]
    return best if best else grid_packing(n)

def mixed_packing(n):
    """Try a few patterns and return the best by simple estimate."""
    candidates = [grid_packing(n), shelf_packing(n)]
    best = None
    best_val = -1.0
    for c in candidates:
        # penalize by approximate overlap via SAT
        pen, tot = compute_penalty_and_total(c)
        val = tot - pen
        if val > best_val:
            best_val = val
            best = c
    return best

# ---------- local optimization ----------

def optimize(squares, n, time_budget=10.0):
    """Simulated annealing / random coordinate perturbation."""
    squares = [list(s) for s in squares]
    random.seed(12345)
    best = [s[:] for s in squares]
    _, best_total = compute_penalty_and_total(best)
    pen, tot = compute_penalty_and_total(squares)
    best_score = tot - pen
    best_total_score = tot if pen < 1e-6 else -1e9
    cur_score = tot - pen
    T = 0.05
    it = 0
    max_it = 20000
    while it < max_it:
        it += 1
        T = max(0.0001, 0.05 * (1 - it / max_it))
        # pick random square
        idx = random.randrange(n)
        old = squares[idx][:]
        s = old[3]
        # perturb center, angle, side
        new = old[:]
        if s > 0:
            new[0] += random.gauss(0, 0.01 * (0.1 + s))
            new[1] += random.gauss(0, 0.01 * (0.1 + s))
            new[2] += random.gauss(0, 0.02)
            new[3] += random.gauss(0, 0.02 * (0.1 + s))
            new[3] = max(0.0, new[3])
        else:
            new[0] += random.gauss(0, 0.01)
            new[1] += random.gauss(0, 0.01)
        # clamp
        new[0] = min(1.0, max(0.0, new[0]))
        new[1] = min(1.0, max(0.0, new[1]))
        new[2] = new[2] % 1.0
        squares[idx] = new
        pen2, tot2 = compute_penalty_and_total(squares)
        new_score = tot2 - pen2
        delta = new_score - cur_score
        if delta > 0 or random.random() < math.exp(delta / max(T, 1e-9)):
            cur_score = new_score
            if pen2 < 1e-7 and tot2 > best_total:
                best_total = tot2
                best = [s[:] for s in squares]
        else:
            squares[idx] = old
    return best

# ---------- main ----------

def solve(n):
    """
    Return list of n tuples (cx, cy, angle, side) inside unit square,
    interiors disjoint, maximizing sum of side lengths.
    """
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # get initial
    init = mixed_packing(n)
    # refine
    try:
        result = optimize(init, n, time_budget=8.0)
    except Exception:
        result = init
    # ensure exactly n, valid
    result = [(float(cx), float(cy), float(a % 1.0), max(0.0, float(s))) for (cx, cy, a, s) in result]
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    result = result[:n]
    # final check: repair overlaps by shrinking
    result = repair(result)
    return result

def repair(squares, max_iter=50):
    """Ensure no interior overlaps by shrinking offending squares."""
    squares = [list(s) for s in squares]
    for _ in range(max_iter):
        polys = [square_corners(*s) for s in squares]
        changed = False
        for i in range(len(squares)):
            if squares[i][3] <= 0:
                continue
            for j in range(i + 1, len(squares)):
                if squares[j][3] <= 0:
                    continue
                if polys_overlap(polys[i], polys[j]):
                    ov = overlap_area(polys[i], polys[j])
                    if ov > 1e-10:
                        # shrink both
                        for k in (i, j):
                            squares[k][3] *= 0.98
                            if squares[k][3] < 1e-4:
                                squares[k][3] = 0.0
                        changed = True
                        polys = [square_corners(*s) for s in squares]
        if not changed:
            break
    # clamp to unit square
    for s in squares:
        if s[3] > 0:
            pts = square_corners(*s)
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            if min(xs) < 0:
                s[0] -= min(xs)
            if max(xs) > 1:
                s[0] -= (max(xs) - 1)
            if min(ys) < 0:
                s[1] -= min(ys)
            if max(ys) > 1:
                s[1] -= (max(ys) - 1)
            s[0] = min(1.0, max(0.0, s[0]))
            s[1] = min(1.0, max(0.0, s[1]))
    return [tuple(s) for s in squares]
