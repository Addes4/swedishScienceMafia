# EVOLVE-BLOCK-START
"""Adaptive square packing inside the unit square for arbitrary n.

Strategy:
1. Build several initial layouts:
   - k x k grid plus a strip of equal squares in a leftover row/column.
   - geometric split: k rows where the last row may have fewer squares.
   - rotated patterns for specific hard small n.
2. Refine continuously with a fast simulated-annealing/local search:
   - perturb one square's size/position/angle
   - accept only if all interiors remain disjoint
   - maximize total side length.
"""

import math
import random

import numpy as np

try:
    from scipy.spatial import ConvexHull  # noqa: F401
except Exception:
    ConvexHull = None


# ---------- geometry helpers ----------

def _corners(cx, cy, ang, s):
    """Return 4 corner points (x,y) of square centered (cx,cy), angle fraction of turn, side s."""
    if s <= 0.0:
        return np.array([[cx, cy]] * 4, dtype=float)
    th = ang * 2.0 * math.pi
    ca = math.cos(th)
    sa = math.sin(th)
    h = s * 0.5
    # local corners before rotation
    pts = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    R = np.array([[ca, -sa], [sa, ca]], dtype=float)
    return pts @ R.T + np.array([cx, cy], dtype=float)


def _inside_unit(pts, eps=1e-12):
    return (pts[:, 0] >= -eps).all() and (pts[:, 0] <= 1.0 + eps).all() and \
           (pts[:, 1] >= -eps).all() and (pts[:, 1] <= 1.0 + eps).all()


def _polygons_overlap(ptsA, ptsB, eps=1e-12):
    """True if interiors of convex polygons intersect (separating axis theorem)."""
    if len(ptsA) < 3 or len(ptsB) < 3:
        return False
    polys = (ptsA, ptsB)
    for poly in polys:
        m = len(poly)
        for i in range(m):
            p1 = poly[i]
            p2 = poly[(i + 1) % m]
            edge = p2 - p1
            n = np.array([-edge[1], edge[0]], dtype=float)
            n2 = np.dot(n, n)
            if n2 < 1e-24:
                continue
            minA = maxA = None
            for q in ptsA:
                v = np.dot(n, q)
                if minA is None or v < minA:
                    minA = v
                if maxA is None or v > maxA:
                    maxA = v
            minB = maxB = None
            for q in ptsB:
                v = np.dot(n, q)
                if minB is None or v < minB:
                    minB = v
                if maxB is None or v > maxB:
                    maxB = v
            if maxA <= minB + eps or maxB <= minA + eps:
                return False
    return True


def _valid_layout(squares, eps=1e-10):
    n = len(squares)
    polys = []
    for (cx, cy, ang, s) in squares:
        if s < -eps:
            return False
        if s <= eps:
            polys.append(np.array([[cx, cy]] * 0))
            continue
        pts = _corners(cx, cy, ang, s)
        if not _inside_unit(pts, eps):
            return False
        polys.append(pts)
    for i in range(n):
        if len(polys[i]) == 0:
            continue
        for j in range(i + 1, n):
            if len(polys[j]) == 0:
                continue
            if _polygons_overlap(polys[i], polys[j], eps):
                return False
    return True


def _score(squares):
    return sum(max(0.0, s) for (_, _, _, s) in squares)


def _shuffle_tight(squares, rng):
    """Randomize order of equal small squares to diversify local search."""
    out = list(squares)
    rng.shuffle(out)
    return out


# ---------- initial constructions ----------

def _grid_plus_strip(n):
    """k x k equal squares plus remainder in a strip, side chosen to maximize sum."""
    k = int(math.isqrt(n))
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    best = None
    best_val = -1.0
    # Try every k such that k*k <= n. Put m extra squares in a row/column.
    for k in range(1, int(math.sqrt(n)) + 2):
        if k * k > n:
            continue
        m = n - k * k
        # Case 1: k full columns of height 1/k, plus m squares in a leftover column.
        # leftover width is 1 - k*s; total width fits: k*s + s2 <= 1, and s2 >= s.
        # For a strip of m squares stacked in leftover width w:
        # if m == 0: w=0, side = 1/k.
        if m == 0:
            s = 1.0 / k
            val = n * s
            if val > best_val:
                best_val = val
                squares = []
                for i in range(k):
                    for j in range(k):
                        squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                best = squares
            continue
        # strip of m squares in a vertical column of width w, height 1.
        # Let main squares side s, strip squares side t.
        # k*s + t <= 1 (if strip in remaining horizontal space)
        # m*t <= 1 (stacked)
        # Also t can equal s if m*t <= 1 and k*s + t <= 1.
        # optimize over s in (0, 1/k].
        # For given s, t = min(s, 1/m, 1 - k*s). Need 1 - k*s > 0.
        # maximize k^2*s + m*t.
        s_hi = 1.0 / k
        # t is min(s, 1/m, 1-k*s), and we need 1-k*s >= t and 1/m >= t.
        # Consider breakpoints.
        candidates = {s_hi}
        # s = 1 - k*s -> s = 1/(k+1), t = s
        candidates.add(1.0 / (k + 1))
        # 1/m = 1 - k*s -> s = (1 - 1/m)/k
        v = (1.0 - 1.0 / m) / k
        if 0 < v <= s_hi:
            candidates.add(v)
        # 1/m = s -> s = 1/m
        if 1.0 / m <= s_hi:
            candidates.add(1.0 / m)
        for s in candidates:
            if s <= 1e-12:
                continue
            t = min(s, 1.0 / m, 1.0 - k * s)
            if t < -1e-12:
                continue
            t = max(0.0, t)
            val = k * k * s + m * t
            if val > best_val:
                best_val = val
                squares = []
                for i in range(k):
                    for j in range(k):
                        squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                # place strip in leftover column at right
                x0 = k * s + t * 0.5
                for j in range(m):
                    y = (j + 0.5) * t
                    if y <= 1.0 + 1e-12:
                        squares.append((x0, y, 0.0, t))
                # if more needed, put at center size 0
                while len(squares) < n:
                    squares.append((0.5, 0.5, 0.0, 0.0))
                best = squares[:n]
    return best if best is not None else [(0.5, 0.5, 0.0, 0.0)] * n


def _strip_layout(n):
    """m squares in one row, n-m in another, optimize two sizes."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    best = None
    best_val = -1.0
    # Try split into two horizontal rows: top row has a squares, bottom has b = n-a.
    for a in range(1, n):
        b = n - a
        # top row: a squares side s, bottom row: b squares side t, stacked vertically.
        # a*s <= 1, b*t <= 1, s+t <= 1.
        # maximize a*s + b*t.
        # LP: vertices.
        cands = []
        # s=1/a, t=1/b
        s1, t1 = 1.0 / a, 1.0 / b
        if s1 + t1 <= 1.0 + 1e-12:
            cands.append((s1, t1))
        # s=1/a, s+t=1 -> t=1-1/a, need b*t<=1
        s2 = 1.0 / a
        t2 = 1.0 - s2
        if t2 > 0 and b * t2 <= 1.0 + 1e-12:
            cands.append((s2, t2))
        # t=1/b, s+t=1
        t3 = 1.0 / b
        s3 = 1.0 - t3
        if s3 > 0 and a * s3 <= 1.0 + 1e-12:
            cands.append((s3, t3))
        for s, t in cands:
            if s < -1e-12 or t < -1e-12:
                continue
            s = max(0.0, s)
            t = max(0.0, t)
            if a * s > 1.0 + 1e-9 or b * t > 1.0 + 1e-9 or s + t > 1.0 + 1e-9:
                continue
            val = a * s + b * t
            if val > best_val:
                best_val = val
                squares = []
                # bottom row
                for i in range(a):
                    squares.append(((i + 0.5) * s, t * 0.5, 0.0, s))
                # top row
                for i in range(b):
                    squares.append(((i + 0.5) * t, 1.0 - t * 0.5, 0.0, t))
                while len(squares) < n:
                    squares.append((0.5, 0.5, 0.0, 0.0))
                best = squares[:n]
    return best if best is not None else [(0.5, 0.5, 0.0, 0.0)] * n


def _rotated_small_cases(n):
    """Some better constructions for small n."""
    if n == 5:
        # Known optimal: 4 squares in corners + one rotated diamond in center.
        # We use a robust symmetric construction: 4 equal corner squares and center square.
        # Side of corner squares s, center square side t rotated 45 deg.
        # Maximize 4s + t.
        # Hard to derive exactly, use numerical construction.
        # Place 4 axis-aligned squares at corners, side s. Center diamond side t at 45 deg.
        # Constraints from geometry:
        # For center diamond (rotated 45 deg), its bounding box half-width = t*sqrt(2)/2.
        # Must fit between corner squares: horizontal gap between left squares and right squares
        # is 1 - 2s. Similarly vertical gap 1 - 2s.
        # Diamond fits in center square region of side 1-2s rotated.
        # Half-diagonal of diamond = t*sqrt(2)/2.
        # The diamond must stay within central cross: need t*sqrt(2) <= 1 - 2s? Actually
        # diamond points reach into gaps; exact condition: t*sqrt(2)/2 <= (1-2s) maybe too strict.
        # Safer: use optimizer below.
        return None
    return None


def _initial_candidates(n):
    cands = []
    g = _grid_plus_strip(n)
    if g is not None:
        cands.append(g)
    s = _strip_layout(n)
    if s is not None:
        cands.append(s)
    r = _rotated_small_cases(n)
    if r is not None:
        cands.append(r)
    # Also try row-count variations directly
    for rows in range(1, min(n, 20) + 1):
        cols = (n + rows - 1) // rows
        if rows * cols < n:
            continue
        # fill rows*cols grid then zero extra
        base = _grid_from_dims(rows, cols, n)
        if base is not None:
            cands.append(base)
    # deduplicate by score
    cands.sort(key=_score, reverse=True)
    return cands


def _grid_from_dims(rows, cols, n):
    """Packing with given rows/cols; optimize common side via simple two-size split."""
    if rows * cols < n:
        return None
    if rows == 0 or cols == 0:
        return None
    # fill n squares in rows x cols grid: first n cells, side = min(1/rows, 1/cols)
    s = min(1.0 / rows, 1.0 / cols)
    squares = []
    count = 0
    for i in range(rows):
        for j in range(cols):
            if count >= n:
                break
            squares.append(((j + 0.5) * s + (1.0 - cols * s) * 0.5,
                            (i + 0.5) * s + (1.0 - rows * s) * 0.5,
                            0.0, s))
            count += 1
        if count >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


# ---------- local search ----------

def _make_snapshot(sq):
    return [(cx, cy, ang, s) for (cx, cy, ang, s) in sq]


def _apply(sq, idx, new):
    old = sq[idx]
    sq[idx] = new
    return old


def _local_search(n, init, rng, time_budget_steps=2500):
    sq = _make_snapshot(init)
    if not _valid_layout(sq, eps=1e-9):
        # repair or fallback
        sq = [(min(max(cx, 0.5), 0.5), min(max(cy, 0.5), 0.5), 0.0, 0.0) for (cx, cy, _, _) in sq]
        # best effort
    cur = _score(sq)
    best = _make_snapshot(sq)
    best_val = cur

    # Temperature schedule
    T0 = 0.08
    T1 = 0.0005
    steps = time_budget_steps
    for step in range(steps):
        t = step / max(1, steps - 1)
        T = T0 * (T1 / T0) ** t
        idx = rng.randrange(n)
        cx, cy, ang, s = sq[idx]
        # choose move type
        r = rng.random()
        if r < 0.25:
            ns = s + rng.gauss(0, 0.04)
            if ns < 0.0:
                ns = 0.0
            if ns > 1.0:
                ns = 1.0
            new = (cx, cy, ang, ns)
        elif r < 0.5:
            ncx = cx + rng.gauss(0, 0.05)
            ncy = cy + rng.gauss(0, 0.05)
            ncx = min(max(ncx, 0.0), 1.0)
            ncy = min(max(ncy, 0.0), 1.0)
            new = (ncx, ncy, ang, s)
        elif r < 0.7:
            nang = ang + rng.gauss(0, 0.03)
            # wrap
            nang = nang % 1.0
            new = (cx, cy, nang, s)
        else:
            # composite
            ncx = cx + rng.gauss(0, 0.03)
            ncy = cy + rng.gauss(0, 0.03)
            nang = (ang + rng.gauss(0, 0.02)) % 1.0
            ns = s + rng.gauss(0, 0.02)
            ns = min(max(ns, 0.0), 1.0)
            ncx = min(max(ncx, 0.0), 1.0)
            ncy = min(max(ncy, 0.0), 1.0)
            new = (ncx, ncy, nang, ns)
        old = sq[idx]
        sq[idx] = new
        if _valid_layout(sq, eps=1e-10):
            new_score = _score(sq)
            delta = new_score - cur
            if delta >= -1e-12 or rng.random() < math.exp(delta / max(1e-12, T)):
                cur = new_score
                if cur > best_val + 1e-12:
                    best_val = cur
                    best = _make_snapshot(sq)
                    # occasional greedy reorder
                    if rng.random() < 0.01:
                        rng.shuffle(sq)
            else:
                sq[idx] = old
        else:
            sq[idx] = old
    return best, best_val


# ---------- main solver ----------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.5, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 3:
        # three equal squares side 1/2 in an L shape? Actually max is 1/2+1/2+1/2? No.
        # Three squares side 0.5 vertically stacked fit? 3*0.5=1.5 > 1, so no.
        # Best: two side 1/2 side by side, one 0.5 in remaining? width issue.
        # Two squares 0.5 side by side occupy full width; third square side 0.5 below.
        # That's 3 squares side 0.5? height 0.5+0.5=1.0 fits. Sum=1.5.
        return [(0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5), (0.5, 0.25, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    rng = random.Random(12345 + n * 9973)

    candidates = _initial_candidates(n)
    if not candidates:
        candidates = [_grid_plus_strip(n)]

    # Evaluate candidates quickly
    best_overall = None
    best_val = -1.0
    for cand in candidates:
        v = _score(cand)
        if v > best_val and _valid_layout(cand, eps=1e-9):
            best_val = v
            best_overall = _make_snapshot(cand)

    if best_overall is None:
        # fallback to a trivial valid layout
        k = int(math.isqrt(n))
        s = 1.0 / max(1, k)
        sq = []
        for i in range(k):
            for j in range(k):
                if len(sq) < n:
                    sq.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        return sq[:n]

    # Run local search from the best few candidates
    top = sorted(candidates, key=_score, reverse=True)[:3]
    # time limiting: use step counts scaled by n
    steps = max(800, min(4000, 250000 // max(1, n)))
    for cand in top:
        refined, val = _local_search(n, cand, rng, time_budget_steps=steps)
        if val > best_val + 1e-12:
            best_val = val
            best_overall = refined

    # Final safety check: ensure valid
    if not _valid_layout(best_overall, eps=1e-8):
        # fallback to best valid candidate
        for cand in top:
            if _valid_layout(cand, eps=1e-8):
                return cand[:n]
        # last resort trivial
        k = int(math.isqrt(n))
        s = 1.0 / max(1, k)
        sq = []
        for i in range(k):
            for j in range(k):
                if len(sq) < n:
                    sq.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        return sq[:n]

    # clamp all numbers to [0,1]
    out = []
    for (cx, cy, ang, s) in best_overall[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, ang, s))
    return out
# EVOLVE-BLOCK-END
