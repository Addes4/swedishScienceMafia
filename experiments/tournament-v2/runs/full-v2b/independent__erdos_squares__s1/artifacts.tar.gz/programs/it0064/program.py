import math
import random
import time
import numpy as np


def _overlap(s1, s2):
    """Return True if the interiors of two squares overlap."""
    cx1, cy1, a1, r1 = s1
    cx2, cy2, a2, r2 = s2
    if r1 <= 0.0 or r2 <= 0.0:
        return False
    # half-diagonal vector axes for each square
    t1 = a1 * 2.0 * math.pi
    t2 = a2 * 2.0 * math.pi
    # square 1 axes (unit directions)
    ux1, uy1 = math.cos(t1), math.sin(t1)
    vx1, vy1 = -uy1, ux1
    ux2, uy2 = math.cos(t2), math.sin(t2)
    vx2, vy2 = -uy2, ux2
    # projection radius of each square on each axis
    h1 = r1 * 0.5
    h2 = r2 * 0.5
    # axes to test: two from each square
    axes = ((ux1, uy1), (vx1, vy1), (ux2, uy2), (vx2, vy2))
    dx = cx2 - cx1
    dy = cy2 - cy1
    for ax, ay in axes:
        d = abs(dx * ax + dy * ay)
        # radius of square i on axis (ax,ay): h * (|axis . u_i| + |axis . v_i|)
        pr1 = h1 * (abs(ax * ux1 + ay * uy1) + abs(ax * vx1 + ay * vy1))
        pr2 = h2 * (abs(ax * ux2 + ay * uy2) + abs(ax * vx2 + ay * vy2))
        if d >= pr1 + pr2 - 1e-12:
            return False
    return True


def _feasible(squares):
    n = len(squares)
    for i in range(n):
        cx, cy, a, r = squares[i]
        if r <= 0.0:
            continue
        h = r * 0.5
        t = a * 2.0 * math.pi
        ux, uy = math.cos(t), math.sin(t)
        vx, vy = -uy, ux
        # extent of the square along x and y
        ex = h * (abs(ux) + abs(vx))
        ey = h * (abs(uy) + abs(vy))
        if cx - ex < -1e-9 or cx + ex > 1.0 + 1e-9:
            return False
        if cy - ey < -1e-9 or cy + ey > 1.0 + 1e-9:
            return False
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _total(squares):
    return sum(s[3] for s in squares)


def _project_out(sq, others, iterations=40):
    """Try to push sq inside bounds and away from others by shrinking/moving."""
    cx, cy, a, r = sq
    if r <= 0.0:
        return sq
    for _ in range(iterations):
        moved = False
        h = r * 0.5
        t = a * 2.0 * math.pi
        ux, uy = math.cos(t), math.sin(t)
        vx, vy = -uy, ux
        ex = h * (abs(ux) + abs(vx))
        ey = h * (abs(uy) + abs(vy))
        # bounds correction
        if cx - ex < 0.0:
            cx = ex
            moved = True
        if cx + ex > 1.0:
            cx = 1.0 - ex
            moved = True
        if cy - ey < 0.0:
            cy = ey
            moved = True
        if cy + ey > 1.0:
            cy = 1.0 - ey
            moved = True
        # overlap correction
        for o in others:
            if o is sq:
                continue
            if _overlap((cx, cy, a, r), o):
                ox = o[0]
                oy = o[1]
                dx = cx - ox
                dy = cy - oy
                dist = math.hypot(dx, dy)
                if dist < 1e-9:
                    dx = random.uniform(-1, 1)
                    dy = random.uniform(-1, 1)
                    dist = math.hypot(dx, dy)
                # push away
                push = 0.01
                cx += dx / dist * push
                cy += dy / dist * push
                moved = True
        sq = (cx, cy, a, r)
        if not moved:
            break
    return sq


def _greedy_place(n, rng, base_side, tries=200):
    """Try to pack n squares by greedy shrinking."""
    squares = []
    # initial guess: all same side
    side = base_side
    for i in range(n):
        best = None
        best_r = -1.0
        for _ in range(tries):
            a = rng.choice([0.0, 0.25, 0.125, 0.375, rng.random()])
            # try random positions
            cx = rng.uniform(0.0, 1.0)
            cy = rng.uniform(0.0, 1.0)
            r = side
            cand = (cx, cy, a, r)
            # clamp to bounds
            h = r * 0.5
            t = a * 2.0 * math.pi
            ux, uy = math.cos(t), math.sin(t)
            vx, vy = -uy, ux
            ex = h * (abs(ux) + abs(vx))
            ey = h * (abs(uy) + abs(vy))
            if ex > 0.5 or ey > 0.5:
                continue
            cx = min(max(cx, ex), 1.0 - ex)
            cy = min(max(cy, ey), 1.0 - ey)
            cand = (cx, cy, a, r)
            ok = True
            for s in squares:
                if _overlap(cand, s):
                    ok = False
                    break
            if ok:
                best = cand
                best_r = r
                break
            # estimate how much room via shrinking
        if best is None:
            # shrink side and retry with more attempts
            side *= 0.99
            if side < 0.001:
                side = 0.001
            # try again with a smaller side
            for _ in range(tries):
                a = rng.choice([0.0, 0.25, rng.random()])
                r = side
                h = r * 0.5
                t = a * 2.0 * math.pi
                ux, uy = math.cos(t), math.sin(t)
                vx, vy = -uy, ux
                ex = h * (abs(ux) + abs(vx))
                ey = h * (abs(uy) + abs(vy))
                if ex > 0.5 or ey > 0.5:
                    continue
                cx = rng.uniform(ex, 1.0 - ex)
                cy = rng.uniform(ey, 1.0 - ey)
                cand = (cx, cy, a, r)
                ok = True
                for s in squares:
                    if _overlap(cand, s):
                        ok = False
                        break
                if ok:
                    best = cand
                    break
        if best is None:
            best = (0.5, 0.5, 0.0, 0.0)
        squares.append(best)
    return squares


def _improve(squares, rng, time_limit):
    """Local search: try increasing sizes and adjusting positions."""
    n = len(squares)
    best = [list(s) for s in squares]
    best_score = sum(s[3] for s in best)
    start = time.time()
    stall = 0
    while time.time() - start < time_limit and stall < 2000:
        stall += 1
        i = rng.randrange(n)
        # try to increase square i
        cx, cy, a, r = best[i]
        delta = rng.choice([0.001, 0.005, 0.01, 0.02, 0.05])
        new_r = r + delta
        if new_r > 1.0:
            continue
        # try several angles
        new_a = a
        if rng.random() < 0.3:
            new_a = rng.choice([0.0, 0.25, 0.125, 0.375])
        h = new_r * 0.5
        t = new_a * 2.0 * math.pi
        ux, uy = math.cos(t), math.sin(t)
        vx, vy = -uy, ux
        ex = h * (abs(ux) + abs(vx))
        ey = h * (abs(uy) + abs(vy))
        if ex > 0.5 or ey > 0.5:
            continue
        new_cx = min(max(cx, ex), 1.0 - ex)
        new_cy = min(max(cy, ey), 1.0 - ey)
        cand = (new_cx, new_cy, new_a, new_r)
        # check overlap with all others
        ok = True
        for j in range(n):
            if j == i:
                continue
            if _overlap(cand, best[j]):
                ok = False
                break
        if ok:
            best[i] = list(cand)
            best_score += delta
        else:
            # try moving/shaking
            for _ in range(3):
                angle = rng.uniform(0, 2 * math.pi)
                dist = rng.choice([0.005, 0.01, 0.02])
                ncx = min(max(cx + dist * math.cos(angle), ex), 1.0 - ex)
                ncy = min(max(cy + dist * math.sin(angle), ey), 1.0 - ey)
                cand = (ncx, ncy, new_a, new_r)
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if _overlap(cand, best[j]):
                        ok = False
                        break
                if ok:
                    best[i] = list(cand)
                    best_score += delta
                    break
    return [tuple(s) for s in best], best_score


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    # Baseline grid for k x k
    k = math.isqrt(n)
    side = 1.0 / k if k > 0 else 1.0

    # Start with a grid arrangement
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) < n:
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))

    # Fill remaining with small squares placed greedily
    remaining = n - len(squares)
    if remaining > 0:
        # Reduce main side to make room for extra small ones
        # Try shrinking to fit
        extra = 1.0 / (k + 1)
        for _ in range(remaining):
            placed = False
            for attempt in range(50):
                r = extra * (1.0 - attempt * 0.02)
                a = rng.choice([0.0, 0.25])
                h = r * 0.5
                t = a * 2.0 * math.pi
                ux, uy = math.cos(t), math.sin(t)
                vx, vy = -uy, ux
                ex = h * (abs(ux) + abs(vx))
                ey = h * (abs(uy) + abs(vy))
                if ex > 0.5 or ey > 0.5:
                    continue
                found = False
                for _ in range(100):
                    cx = rng.uniform(ex, 1.0 - ex)
                    cy = rng.uniform(ey, 1.0 - ey)
                    cand = (cx, cy, a, r)
                    ok = True
                    for s in squares:
                        if _overlap(cand, s):
                            ok = False
                            break
                    if ok:
                        squares.append(cand)
                        placed = True
                        found = True
                        break
                if found:
                    break
            if not placed:
                # place a tiny square (may overlap-free due to smallness)
                for _ in range(100):
                    r = 0.001
                    cx = rng.uniform(0, 1)
                    cy = rng.uniform(0, 1)
                    cand = (cx, cy, 0.0, r)
                    ok = True
                    for s in squares:
                        if _overlap(cand, s):
                            ok = False
                            break
                    if ok:
                        squares.append(cand)
                        placed = True
                        break
                if not placed:
                    squares.append((0.5, 0.5, 0.0, 0.0))

    squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))

    # Ensure feasibility
    for _ in range(20):
        if _feasible(squares):
            break
        for i in range(n):
            squares[i] = _project_out(squares[i], squares, 20)

    score = _total(squares)
    best = [tuple(s) for s in squares]

    # Run some improvement passes
    time_budget = 5.0  # seconds for local search
    start_t = time.time()
    while time.time() - start_t < time_budget:
        improved, new_score = _improve(best, rng, 1.0)
        if _feasible(improved) and new_score > score:
            best = improved
            score = new_score
        # random restart with perturbation
        perturbed = []
        for s in best:
            cx, cy, a, r = s
            cx += rng.uniform(-0.005, 0.005)
            cy += rng.uniform(-0.005, 0.005)
            if rng.random() < 0.2:
                a = rng.choice([0.0, 0.25, 0.125, 0.375])
            perturbed.append((cx, cy, a, r))
        for _ in range(10):
            if _feasible(perturbed):
                break
            for i in range(n):
                perturbed[i] = _project_out(perturbed[i], perturbed, 20)
        imp2, sc2 = _improve(perturbed, rng, 0.5)
        if _feasible(imp2) and sc2 > score:
            best = imp2
            score = sc2

    # Final feasibility guarantee
    if not _feasible(best):
        # fall back to grid
        grid = []
        kk = max(1, math.isqrt(n))
        ss = 1.0 / kk
        for i in range(kk):
            for j in range(kk):
                if len(grid) < n:
                    grid.append(((i + 0.5) * ss, (j + 0.5) * ss, 0.0, ss))
        while len(grid) < n:
            grid.append((0.5, 0.5, 0.0, 0.0))
        best = grid[:n]

    # Sanity: clamp all values
    out = []
    for cx, cy, a, r in best:
        a = a % 1.0
        r = max(0.0, min(1.0, r))
        out.append((min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), a, r))
    return out
