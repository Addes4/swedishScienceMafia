import math
import random

def _overlap(s1, s2):
    cx1, cy1, a1, r1 = s1
    cx2, cy2, a2, r2 = s2
    if r1 <= 0 or r2 <= 0:
        return False
    t1 = a1 * 2 * math.pi
    t2 = a2 * 2 * math.pi
    c1, s1_ = math.cos(t1), math.sin(t1)
    c2, s2_ = math.cos(t2), math.sin(t2)
    R1 = r1 * 0.5
    R2 = r2 * 0.5
    # For rotated squares, use separating axis theorem on their edge normals
    axes = [(c1, s1_), (-s1_, c1), (c2, s2_), (-s2_, c2)]
    # projections of each square onto each axis
    proj1 = []
    proj2 = []
    for ax, ay in axes:
        # Square 1 corners relative to center
        corners1 = [
            (R1*(ax*c1 - ay*s1_) - (-R1*(ax*(-s1_) - ay*c1)) if False else 0, 0)
        ]
        # Do it directly: corners
        p1 = []
        for dx, dy in [(-R1,-R1),(R1,-R1),(R1,R1),(-R1,R1)]:
            x = dx*c1 - dy*s1_
            y = dx*s1_ + dy*c1
            p1.append((x,y))
        p2 = []
        for dx, dy in [(-R2,-R2),(R2,-R2),(R2,R2),(-R2,R2)]:
            x = dx*c2 - dy*s2_
            y = dx*s2_ + dy*c2
            p2.append((x,y))
        # check axis
        min1 = min(px*ax + py*ay for px,py in p1)
        max1 = max(px*ax + py*ay for px,py in p1)
        min2 = min(px*ax + py*ay for px,py in p2)
        max2 = max(px*ax + py*ay for px,py in p2)
        if max1 <= min2 or max2 <= min1:
            return False
    return True

def _inside(cx, cy, a, r):
    if r <= 0:
        return 0 <= cx <= 1 and 0 <= cy <= 1
    t = a * 2 * math.pi
    c, s = math.cos(t), math.sin(t)
    R = r * 0.5
    for dx, dy in [(-R,-R),(R,-R),(R,R),(-R,R)]:
        x = cx + dx*c - dy*s
        y = cy + dx*s + dy*c
        if x < -1e-9 or x > 1+1e-9 or y < -1e-9 or y > 1+1e-9:
            return False
    return True

def _valid(s, squares):
    if not _inside(s[0], s[1], s[2], s[3]):
        return False
    for o in squares:
        if _overlap(s, o):
            return False
    return True

def _greedy(n, tries=8):
    best = None
    best_val = -1
    import random as rnd
    for trial in range(tries):
        squares = []
        remaining = n
        # start with a few random small ones then fill with big
        # estimate: try to put down squares greedily
        for _ in range(n):
            # find best square greedily
            found = None
            found_r = -1
            # if first few, start with random offsets
            if len(squares) < 2:
                candidates = [(0.5, 0.5, 0.0)]
                for _ in range(6):
                    cx = 0.1 + 0.8*rnd.random()
                    cy = 0.1 + 0.8*rnd.random()
                    a = rnd.random()
                    candidates.append((cx, cy, a))
            else:
                candidates = None
            # sample positions
            if candidates is None:
                candidates = []
                for _ in range(120):
                    cx = 0.02 + 0.96*rnd.random()
                    cy = 0.02 + 0.96*rnd.random()
                    a = rnd.random()
                    candidates.append((cx, cy, a))
            # try angles too for each candidate
            for (cx0, cy0, a0) in candidates:
                # binary/direct search for max side
                lo, hi = 0.0, 1.0
                # upper bound
                for _ in range(3):
                    mid = (lo+hi)/2
                    s = (cx0, cy0, a0, mid)
                    if _valid(s, squares):
                        lo = mid
                    else:
                        hi = mid
                # refine
                for _ in range(12):
                    mid = (lo+hi)/2
                    s = (cx0, cy0, a0, mid)
                    if _valid(s, squares):
                        lo = mid
                    else:
                        hi = mid
                if lo > found_r:
                    # optimize orientation briefly
                    best_a = a0
                    best_cx, best_cy = cx0, cy0
                    found_r = lo
                    found = (cx0, cy0, a0, lo)
            if found is not None and found[3] > 1e-6:
                squares.append(found)
            else:
                squares.append((0.5, 0.5, 0.0, 0.0))
        val = sum(s[3] for s in squares)
        if val > best_val:
            best_val = val
            best = squares
    return best

def _grid_solution(n):
    k = int(math.isqrt(n))
    while k > 0:
        if k*k <= n:
            break
        k -= 1
    if k == 0:
        k = 1
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]

def _repair(squares):
    # remove overlaps iteratively
    for _ in range(50):
        changed = False
        for i in range(len(squares)):
            for j in range(i+1, len(squares)):
                if _overlap(squares[i], squares[j]):
                    # shrink smaller one
                    si = squares[i]
                    sj = squares[j]
                    if si[3] <= sj[3]:
                        smaller = i
                    else:
                        smaller = j
                    s = squares[smaller]
                    # shrink
                    newr = s[3] * 0.95
                    # find largest size that avoids overlap with all others and stays inside
                    others = [squares[k] for k in range(len(squares)) if k != smaller]
                    lo, hi = 0.0, s[3]
                    for _ in range(20):
                        mid = (lo+hi)/2
                        test = (s[0], s[1], s[2], mid)
                        if _inside(*test) and all(not _overlap(test, o) for o in others):
                            lo = mid
                        else:
                            hi = mid
                    squares[smaller] = (s[0], s[1], s[2], lo)
                    changed = True
        if not changed:
            break
    return squares

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # For larger n, grid is often nearly optimal and safe.
    grid = _grid_solution(n)
    grid_val = sum(s[3] for s in grid)
    # Try greedy approach for small/medium n
    if n <= 30:
        try:
            g = _greedy(n, tries=6 if n <= 12 else 3)
            gv = sum(s[3] for s in g)
            if gv > grid_val:
                return g
        except Exception:
            pass
    # local search: try to improve grid by replacing pairs with better
    best = grid
    best_val = grid_val
    if n <= 60:
        try:
            g = _greedy(n, tries=2)
            gv = sum(s[3] for s in g)
            if gv > best_val:
                best = g
                best_val = gv
        except Exception:
            pass
    return best
