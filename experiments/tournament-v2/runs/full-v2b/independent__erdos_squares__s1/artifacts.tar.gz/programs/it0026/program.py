import math
import random
import time


def _overlap_area(a, b):
    # approximate via separating axis on 4 axes each; exact for axis-aligned only,
    # but good enough as a penalty metric for local search.
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    ha = asz * 0.5
    hb = bsz * 0.5
    ca, sa = math.cos(aa * 2 * math.pi), math.sin(aa * 2 * math.pi)
    cb, sb = math.cos(ba * 2 * math.pi), math.sin(ba * 2 * math.pi)
    axes = [(ca, sa), (-sa, ca), (cb, sb), (-sb, cb)]
    minov = 1e18
    for ux, uy in axes:
        # project centers
        pa = ax * ux + ay * uy
        pb = bx * ux + by * uy
        ra = (abs(ca * ux + sa * uy) + abs(-sa * ux + ca * uy)) * ha
        rb = (abs(cb * ux + sb * uy) + abs(-sb * ux + sb * uy)) * hb
        ov = ra + rb - abs(pa - pb)
        if ov <= 1e-12:
            return 0.0
        if ov < minov:
            minov = ov
    return minov


def _inside(sq, eps=0.0):
    x, y, a, s = sq
    h = s * 0.5
    ca = math.cos(a * 2 * math.pi)
    sa = math.sin(a * 2 * math.pi)
    for dx, dy in ((h, h), (h, -h), (-h, h), (-h, -h)):
        px = x + ca * dx - sa * dy
        py = y + sa * dx + ca * dy
        if px < -eps or px > 1 + eps or py < -eps or py > 1 + eps:
            return False
    return True


def _penalty(sqs):
    p = 0.0
    for i in range(len(sqs)):
        if not _inside(sqs[i]):
            x, y, a, s = sqs[i]
            h = s * 0.5
            ca = math.cos(a * 2 * math.pi)
            sa = math.sin(a * 2 * math.pi)
            worst = 0.0
            for dx, dy in ((h, h), (h, -h), (-h, h), (-h, -h)):
                px = x + ca * dx - sa * dy
                py = y + sa * dx + ca * dy
                ex = max(0.0, -px, px - 1.0)
                ey = max(0.0, -py, py - 1.0)
                worst = max(worst, ex + ey)
            p += worst * worst * 10.0
        for j in range(i + 1, len(sqs)):
            ov = _overlap_area(sqs[i], sqs[j])
            if ov > 0:
                p += ov * ov * 10.0
    return p


def _score(sqs):
    return sum(s[3] for s in sqs) - _penalty(sqs)


def _greedy_bsp(n, rng, jitter=0.0):
    # recursive split of a rectangle into n cells
    cells = [(0.0, 0.0, 1.0, 1.0)]
    while len(cells) < n:
        # pick largest by area (or random among large)
        cells.sort(key=lambda c: c[2] * c[3], reverse=True)
        idx = 0
        if jitter > 0 and len(cells) > 1 and rng.random() < jitter:
            idx = rng.randrange(min(len(cells), max(1, len(cells) // 2)))
        x, y, w, h = cells.pop(idx)
        # split along longer dimension, at a random-ish ratio
        ratio = 0.5
        if jitter > 0:
            ratio = 0.5 + (rng.random() - 0.5) * 0.6
        ratio = min(0.9, max(0.1, ratio))
        if w >= h:
            w1 = w * ratio
            cells.append((x, y, w1, h))
            cells.append((x + w1, y, w - w1, h))
        else:
            h1 = h * ratio
            cells.append((x, y, w, h1))
            cells.append((x, y + h1, w, h - h1))
    sqs = []
    for x, y, w, h in cells:
        s = min(w, h)
        cx = x + w * 0.5
        cy = y + h * 0.5
        sqs.append((cx, cy, 0.0, s))
    return sqs


def _grid_seed(n, k):
    side = 1.0 / k
    sqs = []
    for i in range(k):
        for j in range(k):
            if len(sqs) >= n:
                break
            sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        if len(sqs) >= n:
            break
    while len(sqs) < n:
        sqs.append((0.5, 0.5, 0.0, 0.0))
    return sqs[:n]


def _local_opt(sqs, deadline, iters=4000):
    n = len(sqs)
    sqs = [list(s) for s in sqs]
    best = [list(s) for s in sqs]
    best_sc = _score(sqs)
    cur_sc = best_sc
    steps = [0.05, 0.02, 0.01, 0.005, 0.002, 0.001]
    it = 0
    while time.time() < deadline and it < iters:
        it += 1
        i = random.randrange(n)
        s = sqs[i]
        step = steps[min(len(steps) - 1, random.randrange(len(steps)))]
        op = random.randrange(4)
        old = list(s)
        if op == 0:
            s[0] = min(1.0, max(0.0, s[0] + (random.random() - 0.5) * step * 2))
        elif op == 1:
            s[1] = min(1.0, max(0.0, s[1] + (random.random() - 0.5) * step * 2))
        elif op == 2:
            s[2] = s[2] + (random.random() - 0.5) * step
        else:
            s[3] = min(1.0, max(0.0, s[3] + (random.random() - 0.5) * step * 2))
        new_sc = _score(sqs)
        if new_sc >= cur_sc - 1e-9:
            cur_sc = new_sc
            if new_sc > best_sc:
                best_sc = new_sc
                best = [list(t) for t in sqs]
        else:
            sqs[i] = old

    # growth phase: try to expand each square
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for i in range(n):
            s = sqs[i]
            best_grow = s[3]
            for delta in (0.05, 0.02, 0.01, 0.005, 0.002):
                s[3] = best_grow + delta
                sc = _score(sqs)
                if sc > best_sc + 1e-9:
                    best_sc = sc
                    best_grow = s[3]
                    best = [list(t) for t in sqs]
                    improved = True
                    break
                else:
                    s[3] = best_grow
    return best, best_sc


def solve(n):
    random.seed(12345)
    start = time.time()
    limit = start + 55.0
    if n <= 0:
        return []

    best = None
    best_sc = -1e18

    # seeds
    k = int(math.sqrt(n))
    while k * k < n:
        k += 1
    while k > 1 and (k - 1) ** 2 >= n:
        k -= 1
    seeds = []
    seeds.append(_grid_seed(n, k))
    if k > 1:
        seeds.append(_grid_seed(n, k - 1) if (k - 1) ** 2 <= n else _grid_seed(n, k))
    for j in range(8):
        seeds.append(_greedy_bsp(n, random, jitter=0.5))

    for seed in seeds:
        if time.time() > limit:
            break
        sub_deadline = min(limit, time.time() + max(1.0, 55.0 / max(1, len(seeds))))
        res, sc = _local_opt(seed, sub_deadline, iters=6000)
        if sc > best_sc:
            best_sc = sc
            best = res

    # final polish
    if best is not None and time.time() < limit:
        res, sc = _local_opt(best, limit, iters=20000)
        if sc > best_sc:
            best = res

    if best is None:
        best = _grid_seed(n, k)

    out = []
    for x, y, a, s in best[:n]:
        x = min(1.0, max(0.0, x))
        y = min(1.0, max(0.0, y))
        s = min(1.0, max(0.0, s))
        a = a % 1.0
        out.append((x, y, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
