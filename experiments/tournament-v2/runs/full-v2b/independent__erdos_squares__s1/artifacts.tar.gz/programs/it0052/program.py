import math
import random
import time
from typing import List, Tuple

# ---------- geometry helpers ----------

def corners(cx, cy, a, s):
    """Return the four corners of a square with center (cx,cy), angle fraction a, side s."""
    t = a * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    # local coordinates: (+-, +-)
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        # rotate (dx,dy)
        x = cx + dx * c - dy * sn
        y = cy + dx * sn + dy * c
        pts.append((x, y))
    return pts

def inside_unit(cx, cy, a, s, eps=1e-12):
    for x, y in corners(cx, cy, a, s):
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True

def proj_interval(cx, cy, a, s, ax, ay):
    """Project square onto axis (ax,ay) unit vector; return (min,max)."""
    pts = corners(cx, cy, a, s)
    vals = [x * ax + y * ay for x, y in pts]
    return min(vals), max(vals)

def overlap_sat(cx1, cy1, a1, s1, cx2, cy2, a2, s2, eps=1e-12):
    """Separating axis test for two convex polygons (squares). True if interiors overlap."""
    if s1 <= eps or s2 <= eps:
        return False
    # axes: 4 edge normals of both squares
    for a in (a1, a2):
        t = a * 2.0 * math.pi
        c, sn = math.cos(t), math.sin(t)
        # normals of square edges
        for nx, ny in ((c, sn), (-sn, c)):
            lo1, hi1 = proj_interval(cx1, cy1, a1, s1, nx, ny)
            lo2, hi2 = proj_interval(cx2, cy2, a2, s2, nx, ny)
            if hi1 <= lo2 + eps or hi2 <= lo1 + eps:
                return False
    return True

def any_overlap(squares, i, j, eps=1e-12):
    cx1, cy1, a1, s1 = squares[i]
    cx2, cy2, a2, s2 = squares[j]
    if s1 <= eps or s2 <= eps:
        return False
    return overlap_sat(cx1, cy1, a1, s1, cx2, cy2, a2, s2, eps)

def valid_single(cx, cy, a, s, eps=1e-12):
    if s <= eps:
        return True
    return inside_unit(cx, cy, a, s, eps)

# ---------- objective ----------
def total_side(squares):
    return sum(q[3] for q in squares)

def is_feasible(squares, eps=1e-12):
    n = len(squares)
    for i in range(n):
        if not valid_single(*squares[i], eps=eps):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if any_overlap(squares, i, j, eps):
                return False
    return True

# ---------- constructions ----------

def grid_solution(n):
    k = math.isqrt(n)
    side = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]

def spiral_solution(n):
    """Place squares along a spiral pattern approximating optimal nested configs."""
    out = []
    side = 1.0
    # first square: full unit square
    out.append((0.5, 0.5, 0.0, 1.0))
    if n == 1:
        return out
    # Place decreasing squares in a spiral, each rotated, inscribed in remaining region
    # simple heuristic: corners
    for idx in range(1, n):
        # use progressively smaller squares at corners
        s = 1.0 / (idx + 1)
        # alternate corners
        corners4 = [(0.0, 0.0), (1.0, 1.0), (0.0, 1.0), (1.0, 0.0)]
        cx, cy = corners4[(idx - 1) % 4]
        # move inward by s/2
        if cx < 0.5:
            cx += s * 0.5
        else:
            cx -= s * 0.5
        if cy < 0.5:
            cy += s * 0.5
        else:
            cy -= s * 0.5
        out.append((cx, cy, 0.0, s))
    return out

def random_solution(n, seed=0):
    rng = random.Random(seed)
    out = []
    for _ in range(n):
        s = rng.uniform(0.01, 0.5 / max(1, math.sqrt(n)))
        cx = rng.uniform(s * 0.71, 1.0 - s * 0.71)
        cy = rng.uniform(s * 0.71, 1.0 - s * 0.71)
        a = rng.uniform(0.0, 1.0)
        out.append((cx, cy, a, s))
    return out

# ---------- local search ----------

def repair(squares, rng, max_iter=2000):
    """Try to fix infeasible squares by shrinking/moving."""
    n = len(squares)
    squares = [list(q) for q in squares]
    for it in range(max_iter):
        changed = False
        # check all
        bad = []
        for i in range(n):
            if not valid_single(*squares[i]):
                bad.append(i)
        for i in range(n):
            for j in range(i + 1, n):
                if overlap_sat(*squares[i], *squares[j]):
                    if i not in bad:
                        bad.append(i)
                    if j not in bad:
                        bad.append(j)
        if not bad:
            break
        i = rng.choice(bad)
        # shrink
        squares[i][3] *= rng.uniform(0.5, 0.99)
        if squares[i][3] < 1e-6:
            squares[i][3] = 0.0
        # maybe move
        if rng.random() < 0.5:
            s = squares[i][3]
            squares[i][0] = rng.uniform(s * 0.71, 1.0 - s * 0.71) if s > 0 else 0.5
            squares[i][1] = rng.uniform(s * 0.71, 1.0 - s * 0.71) if s > 0 else 0.5
        changed = True
        if not changed and it > 50:
            break
    return [tuple(q) for q in squares]

def optimize(n, time_budget=55.0):
    start = time.time()
    best = None
    best_score = -1.0

    candidates = []
    # grid
    candidates.append(grid_solution(n))
    # spiral
    candidates.append(spiral_solution(n))
    # greedy: largest squares first
    candidates.append(greedy_solution(n))
    # random starts
    for seed in range(3):
        candidates.append(random_solution(n, seed))

    for sol in candidates:
        sol = [list(q) for q in sol]
        # repair if needed
        if not is_feasible(sol):
            sol = repair(sol, random.Random(0))
        sol = [tuple(q) for q in sol]
        score = total_side(sol)
        if is_feasible(sol) and score > best_score:
            best_score = score
            best = sol

    if best is None:
        return grid_solution(n)

    rng = random.Random(12345)
    # Simulated annealing / hill climbing
    current = [list(q) for q in best]
    current_score = total_side(current)
    T0 = 0.02
    steps = 0
    while time.time() - start < time_budget:
        steps += 1
        T = T0 * (1.0 - (time.time() - start) / time_budget) + 1e-6
        i = rng.randrange(n)
        old = current[i][:]
        # propose move
        choice = rng.random()
        s = current[i][3]
        if choice < 0.4:
            # change size
            delta = rng.gauss(0.0, 0.01)
            ns = max(0.0, min(1.0, s + delta))
            current[i][3] = ns
        elif choice < 0.7:
            # move center
            if s > 0:
                dx = rng.gauss(0.0, 0.02)
                dy = rng.gauss(0.0, 0.02)
                current[i][0] = max(s * 0.71, min(1.0 - s * 0.71, current[i][0] + dx))
                current[i][1] = max(s * 0.71, min(1.0 - s * 0.71, current[i][1] + dy))
            else:
                current[i][0] = rng.random()
                current[i][1] = rng.random()
        else:
            # rotate
            current[i][2] = (current[i][2] + rng.gauss(0.0, 0.02)) % 1.0
        # make sure inside unit box (with small margin)
        if not valid_single(*current[i]):
            # revert
            current[i] = old
            continue
        # check overlaps
        ok = True
        for j in range(n):
            if j == i:
                continue
            if overlap_sat(*current[i], *current[j]):
                ok = False
                break
        if ok:
            ns = current_score - old[3] + current[i][3]
            if ns >= current_score or rng.random() < math.exp((ns - current_score) / max(T, 1e-9)):
                current_score = ns
                if current_score > best_score:
                    # verify full feasibility
                    if is_feasible(current):
                        best_score = current_score
                        best = [tuple(q) for q in current]
            else:
                current[i] = old
        else:
            current[i] = old
    return best

def greedy_solution(n):
    """Place largest possible squares greedily in grid positions, then shrink."""
    # Start with regular grid
    sol = grid_solution(n)
    sol = [list(q) for q in sol]
    # try to grow each square one by one
    rng = random.Random(999)
    for i in range(n):
        s = sol[i][3]
        if s <= 0:
            continue
        # grow
        lo, hi = s, 1.0
        for _ in range(30):
            mid = (lo + hi) / 2
            old = sol[i][3]
            sol[i][3] = mid
            if valid_single(*sol[i]):
                ok = True
                for j in range(n):
                    if j != i and overlap_sat(*sol[i], *sol[j]):
                        ok = False
                        break
                if ok:
                    lo = mid
                else:
                    hi = mid
            else:
                hi = mid
            sol[i][3] = old
        sol[i][3] = lo
    return [tuple(q) for q in sol]

# ---------- main ----------

def solve(n: int) -> List[Tuple[float, float, float, float]]:
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    best = optimize(n, time_budget=55.0)
    # safety check
    if best is None or not is_feasible(best):
        best = grid_solution(n)
    # ensure all numbers in [0,1] (angle can be any real, take mod 1)
    out = []
    for cx, cy, a, s in best:
        a = a % 1.0
        s = max(0.0, min(1.0, s))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        out.append((cx, cy, a, s))
    return out
