import math
import random
import numpy as np

try:
    from scipy.optimize import minimize
    HAS_SCIPY = True
except Exception:
    HAS_SCIPY = False


def _squares_overlap(s1, s2, eps=1e-12):
    cx1, cy1, a1, s1_ = s1
    cx2, cy2, a2, s2_ = s2
    if s1_ <= eps or s2_ <= eps:
        return False
    hs1 = s1_ * 0.5
    hs2 = s2_ * 0.5
    t1 = a1 * 2.0 * math.pi
    t2 = a2 * 2.0 * math.pi
    c1, si1 = math.cos(t1), math.sin(t1)
    c2, si2 = math.cos(t2), math.sin(t2)
    ax1 = (c1, si1)
    ay1 = (-si1, c1)
    ax2 = (c2, si2)
    ay2 = (-si2, c2)
    ux = ax1
    uy = ay1
    vx = ax2
    vy = ay2
    # SAT for two squares
    for (ux_, uy_) in (ux, uy, vx, vy):
        # project both
        r1 = abs(hs1 * (ux_[0] * ax1[0] + ux_[1] * ax1[1])) + abs(hs1 * (ux_[0] * ay1[0] + ux_[1] * ay1[1]))
        r2 = abs(hs2 * (ux_[0] * ax2[0] + ux_[1] * ax2[1])) + abs(hs2 * (ux_[0] * ay2[0] + ux_[1] * ay2[1]))
        d = abs((cx1 - cx2) * ux_[0] + (cy1 - cy2) * ux_[1])
        if d >= r1 + r2 - eps:
            return False
    return True


def _inside_unit(s):
    cx, cy, a, side = s
    if side <= 0:
        return True
    hs = side * 0.5
    t = a * 2.0 * math.pi
    c, si = math.cos(t), math.sin(t)
    # half extent in x,y
    ex = hs * (abs(c) + abs(si))
    ey = hs * (abs(si) + abs(c))
    return cx - ex >= -1e-12 and cx + ex <= 1.0 + 1e-12 and cy - ey >= -1e-12 and cy + ey <= 1.0 + 1e-12


def _feasible(squares):
    n = len(squares)
    for i in range(n):
        if not _inside_unit(squares[i]):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _squares_overlap(squares[i], squares[j]):
                return False
    return True


def _clamp_square(s):
    cx, cy, a, side = s
    a = a % 1.0
    side = max(0.0, min(1.0, side))
    if side == 0:
        return (0.5, 0.5, 0.0, 0.0)
    t = a * 2.0 * math.pi
    c, si = math.cos(t), math.sin(t)
    ex = side * 0.5 * (abs(c) + abs(si))
    ey = side * 0.5 * (abs(si) + abs(c))
    nside = min(side, 1.0 / (abs(c) + abs(si)) if (abs(c) + abs(si)) > 1e-12 else 1.0,
                1.0 / (abs(si) + abs(c)) if (abs(si) + abs(c)) > 1e-12 else 1.0)
    side = max(0.0, nside)
    if side == 0:
        return (0.5, 0.5, 0.0, 0.0)
    t = a * 2.0 * math.pi
    c, si = math.cos(t), math.sin(t)
    ex = side * 0.5 * (abs(c) + abs(si))
    ey = side * 0.5 * (abs(si) + abs(c))
    cx = min(max(cx, ex), 1.0 - ex)
    cy = min(max(cy, ey), 1.0 - ey)
    return (cx, cy, a, side)


def _score(squares):
    return sum(s[3] for s in squares)


def _greedy_place(squares, side, angle, trials=400):
    best = None
    best_score = -1
    for _ in range(trials):
        cx = random.random()
        cy = random.random()
        cand = (cx, cy, angle, side)
        cand = _clamp_square(cand)
        if cand[3] <= 1e-9:
            continue
        ok = True
        for s in squares:
            if _squares_overlap(cand, s):
                ok = False
                break
        if ok:
            sc = cand[3]
            if sc > best_score:
                best_score = sc
                best = cand
    return best


def _construct_grid(n):
    best = None
    best_sum = -1
    for k in range(1, int(math.sqrt(n)) + 2):
        if k * k > n:
            break
        side = 1.0 / k
        sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
              for i in range(k) for j in range(k)]
        remaining = n - len(sq)
        # fill remainder with size 0
        sq += [(0.5, 0.5, 0.0, 0.0)] * remaining
        s = sum(x[3] for x in sq)
        if s > best_sum:
            best_sum = s
            best = sq[:n]
    return best


def _construct_varied(n):
    """Mixed grid with some rotated squares."""
    random.seed(12345)
    # base grid: try k x k plus extra
    best = None
    best_sum = -1
    for k in range(1, int(math.sqrt(n)) + 2):
        for kk in range(1, k + 1):
            if k * kk > n or kk == 0:
                continue
            if k * kk + (n - k * kk) == n:
                pass
            w = 1.0 / k
            h = 1.0 / kk if kk > 0 else 1.0
            side = min(w, h)
            if side <= 0:
                continue
            # place k x kk squares in rows/cols
            sq = []
            for i in range(k):
                for j in range(kk):
                    sq.append(((i + 0.5) * (1.0 / k), (j + 0.5) * (1.0 / kk), 0.0, min(1.0 / k, 1.0 / kk)))
            if len(sq) > n:
                sq = sq[:n]
            else:
                sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
            s = sum(x[3] for x in sq)
            if _feasible(sq) and s > best_sum:
                best_sum = s
                best = sq[:n]
    return best if best is not None else _construct_grid(n)


def _local_search(squares, iterations=20000, time_budget=0.0):
    n = len(squares)
    if n == 0:
        return squares
    cur = [list(s) for s in squares]
    cur_score = _score(cur)
    best = [list(s) for s in cur]
    best_score = cur_score
    import time
    t0 = time.time()
    temp0 = 0.05
    for it in range(iterations):
        if time_budget > 0 and time.time() - t0 > time_budget:
            break
        temp = temp0 * (1.0 - it / max(1, iterations))
        i = random.randrange(n)
        old = cur[i][:]
        # propose move
        r = random.random()
        if r < 0.45:
            # resize
            ds = random.gauss(0, 0.02)
            new = [old[0], old[1], old[2], max(0.0, old[3] + ds)]
        elif r < 0.8:
            # translate
            new = [old[0] + random.gauss(0, 0.02), old[1] + random.gauss(0, 0.02), old[2], old[3]]
        elif r < 0.95:
            # rotate
            new = [old[0], old[1], old[2] + random.gauss(0, 0.02), old[3]]
        else:
            # combined
            new = [old[0] + random.gauss(0, 0.02), old[1] + random.gauss(0, 0.02),
                   old[2] + random.gauss(0, 0.02), max(0.0, old[3] + random.gauss(0, 0.02))]
        new = list(_clamp_square(new))
        if new[3] <= 1e-9:
            new = [0.5, 0.5, 0.0, 0.0]
        # check feasibility against others
        ok = _inside_unit(new)
        if ok:
            for j in range(n):
                if j == i:
                    continue
                if _squares_overlap(new, cur[j]):
                    ok = False
                    break
        if ok:
            delta = new[3] - old[3]
            if delta > 0 or random.random() < math.exp(delta / max(temp, 1e-9)):
                cur[i] = new
                cur_score += delta
                if cur_score > best_score:
                    best_score = cur_score
                    best = [list(s) for s in cur]
        else:
            # try clamping harder: shrink
            if new[3] > 1e-9:
                shrunk = [new[0], new[1], new[2], new[3] * 0.5]
                shrunk = list(_clamp_square(shrunk))
                ok2 = _inside_unit(shrunk)
                if ok2:
                    for j in range(n):
                        if j == i:
                            continue
                        if _squares_overlap(shrunk, cur[j]):
                            ok2 = False
                            break
                if ok2:
                    delta = shrunk[3] - old[3]
                    if delta > 0 or random.random() < math.exp(delta / max(temp, 1e-9)):
                        cur[i] = shrunk
                        cur_score += delta
                        if cur_score > best_score:
                            best_score = cur_score
                            best = [list(s) for s in cur]
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        # largest single square is axis-aligned side 1
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # 2x1 grid top half + 1 bottom
        return [(0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5), (0.5, 0.25, 0.0, 0.5)]
    if n == 4:
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s),
                (0.25, 0.75, 0.0, s), (0.75, 0.75, 0.0, s)]

    random.seed(987654321 + n)
    np.random.seed(123456 + n)

    candidates = []
    g = _construct_grid(n)
    if g is not None and _feasible(g):
        candidates.append(g)
    v = _construct_varied(n)
    if v is not None and _feasible(v):
        candidates.append(v)

    # Try a few random restarts with greedy descending sizes (may not fill all n)
    for trial in range(3):
        sq = []
        side0 = 1.0 / math.sqrt(n) * 1.1
        placed = 0
        # try placing squares of decreasing size, then split remaining
        sizes = []
        # heuristic sizes
        k = int(math.sqrt(n))
        for i in range(n):
            sizes.append(1.0 / k)
        for i in range(n):
            a = 0.0 if (i % 5 != 0) else random.random()
            c = _greedy_place(sq, sizes[i], a, trials=30)
            if c is not None:
                sq.append(c)
                placed += 1
            else:
                sq.append((0.5, 0.5, 0.0, 0.0))
        if len(sq) >= n:
            sq = sq[:n]
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        if _feasible(sq):
            candidates.append(sq)

    if not candidates:
        candidates.append(_construct_grid(n))

    # pick best candidate
    candidates.sort(key=lambda s: -_score(s))
    best = candidates[0]

    # local search on top few
    import time
    t_start = time.time()
    total_budget = 45.0 / max(1, min(n, 4))
    for idx, cand in enumerate(candidates[:3]):
        remaining = total_budget - (time.time() - t_start)
        if remaining <= 0:
            break
        iters = max(2000, 15000 // max(1, n // 3))
        improved = _local_search([list(s) for s in cand], iterations=iters, time_budget=remaining * 0.8)
        if _feasible(improved) and _score(improved) > _score(best):
            best = improved

    # final polishing
    remaining = total_budget - (time.time() - t_start)
    if remaining > 0:
        improved = _local_search([list(s) for s in best], iterations=30000, time_budget=remaining)
        if _feasible(improved) and _score(improved) > _score(best):
            best = improved

    # ensure feasibility; if not, fall back
    if not _feasible(best):
        best = _construct_grid(n)

    result = []
    for s in best:
        cx, cy, a, side = float(s[0]), float(s[1]), float(s[2]) % 1.0, float(s[3])
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        side = max(0.0, min(1.0, side))
        result.append((cx, cy, a, side))
    return result[:n]
