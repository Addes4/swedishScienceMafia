import math
import random
import sys


def _overlap_area(a, b):
    """Return the intersection area of two oriented-unit-square placements.

    Placement is (cx, cy, angle_turns, side).  The test is exact for
    axis-aligned squares and conservative for rotated ones by using the
    separating-axis theorem on the four corner directions of each square.
    """
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0.0 or bsz <= 0.0:
        return 0.0

    def corners(cx, cy, ang, sz):
        t = ang * 2.0 * math.pi
        c, s = math.cos(t), math.sin(t)
        h = sz * 0.5
        return [
            (cx + (-h) * c - (-h) * s, cy + (-h) * s + (-h) * c),
            (cx + (h) * c - (-h) * s, cy + (h) * s + (-h) * c),
            (cx + (h) * c - (h) * s, cy + (h) * s + (h) * c),
            (cx + (-h) * c - (h) * s, cy + (-h) * s + (h) * c),
        ]

    ca = corners(ax, ay, aa, asz)
    cb = corners(bx, by, ba, bsz)

    axes = []
    for i in range(4):
        x1, y1 = ca[i]
        x2, y2 = ca[(i + 1) % 4]
        axes.append((-(y2 - y1), x2 - x1))
        x1, y1 = cb[i]
        x2, y2 = cb[(i + 1) % 4]
        axes.append((-(y2 - y1), x2 - x1))

    for nx, ny in axes:
        nlen = math.hypot(nx, ny)
        if nlen < 1e-15:
            continue
        nx /= nlen
        ny /= nlen
        pa = [nx * p[0] + ny * p[1] for p in ca]
        pb = [nx * p[0] + ny * p[1] for p in cb]
        if max(pa) <= min(pb) + 1e-12 or max(pb) <= min(pa) + 1e-12:
            return 0.0
    return 1.0


def _validate(squares):
    for i in range(len(squares)):
        xi, yi, ai, si = squares[i]
        if si < 0.0:
            return False
        t = ai * 2.0 * math.pi
        c, s = math.cos(t), math.sin(t)
        h = si * 0.5
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            px = xi + dx * c - dy * s
            py = yi + dx * s + dy * c
            if px < -1e-9 or px > 1.0 + 1e-9 or py < -1e-9 or py > 1.0 + 1e-9:
                return False
    for i in range(len(squares)):
        for j in range(i + 1, len(squares)):
            if _overlap_area(squares[i], squares[j]) > 1e-12:
                return False
    return True


def _grid(n, k):
    side = 1.0 / k
    sq = []
    for i in range(k):
        for j in range(k):
            sq.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    sq = sq[:n]
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq


def _greedy(n, seed, tries, angles):
    rng = random.Random(seed)
    best = None
    best_sum = -1.0

    for _ in range(tries):
        order = list(range(n))
        rng.shuffle(order)

        placed = []
        for idx in order:
            cand_size = None
            cand = None
            for _ in range(48):
                ang = rng.choice(angles)
                size = rng.uniform(0.02, 0.45)
                t = ang * 2.0 * math.pi
                c, s = math.cos(t), math.sin(t)
                h = size * 0.5
                ex = h * (abs(c) + abs(s))
                if ex * 2.0 > 1.0:
                    continue
                cx = rng.uniform(ex, 1.0 - ex)
                cy = rng.uniform(ex, 1.0 - ex)
                ok = True
                for p in placed:
                    if _overlap_area((cx, cy, ang, size), p) > 1e-12:
                        ok = False
                        break
                if ok:
                    cand = (cx, cy, ang, size)
                    cand_size = size
                    break
            if cand is None:
                cand = (0.5, 0.5, 0.0, 0.0)
            placed.append(cand)

        ssum = sum(p[3] for p in placed)
        if ssum > best_sum:
            best_sum = ssum
            best = placed
    return best, best_sum


def _relax(squares, rng, steps):
    cur = [list(s) for s in squares]
    cur_sum = sum(s[3] for s in cur)

    for _ in range(steps):
        i = rng.randrange(len(cur))
        sq = cur[i]
        nc = sq[:]
        op = rng.random()
        if op < 0.55:
            nc[3] = max(0.0, sq[3] + rng.uniform(-0.02, 0.02))
        elif op < 0.85:
            nc[0] = min(1.0, max(0.0, sq[0] + rng.uniform(-0.02, 0.02)))
            nc[1] = min(1.0, max(0.0, sq[1] + rng.uniform(-0.02, 0.02)))
        else:
            nc[2] = (sq[2] + rng.uniform(-0.08, 0.08)) % 1.0

        if not _fits(nc):
            continue

        old = cur[i]
        cur[i] = nc
        ok = True
        for j in range(len(cur)):
            if j == i:
                continue
            if _overlap_area(cur[i], cur[j]) > 1e-12:
                ok = False
                break
        if ok:
            cur_sum += cur[i][3] - old[3]
        else:
            cur[i] = old

    return [tuple(s) for s in cur], cur_sum


def _fits(sq):
    cx, cy, ang, size = sq
    if size < 0.0:
        return False
    t = ang * 2.0 * math.pi
    c, s = math.cos(t), math.sin(t)
    h = size * 0.5
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        px = cx + dx * c - dy * s
        py = cy + dx * s + dy * c
        if px < -1e-9 or px > 1.0 + 1e-9 or py < -1e-9 or py > 1.0 + 1e-9:
            return False
    return True


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    k = max(1, math.isqrt(n))
    baseline = _grid(n, k)

    angles_small = [0.0, 0.25, 0.5, 0.75]
    angles_wide = [0.0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875]

    best = baseline
    best_sum = sum(s[3] for s in baseline)

    if n <= 12:
        tries = 140
        steps = 6000
    elif n <= 40:
        tries = 90
        steps = 9000
    else:
        tries = 50
        steps = 14000

    candidates = []
    rng = random.Random(12345 + n)
    for t in range(tries):
        sq, sm = _greedy(n, rng.randrange(1 << 30), 1, angles_wide if t % 2 == 0 else angles_small)
        candidates.append((sq, sm))
    candidates.sort(key=lambda x: -x[1])

    for sq, sm in candidates[:4]:
        if sm > best_sum:
            best = sq
            best_sum = sm

    rng2 = random.Random(999 + n)
    for _ in range(3):
        relaxed, rsum = _relax(best, rng2, steps)
        if rsum > best_sum:
            best = relaxed
            best_sum = rsum

    if not _validate(best):
        # safe fallback
        best = baseline

    out = []
    for s in best:
        out.append(tuple(s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
