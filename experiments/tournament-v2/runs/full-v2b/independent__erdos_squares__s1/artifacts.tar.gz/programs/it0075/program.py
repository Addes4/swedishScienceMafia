import math
import random
import numpy as np

# Global cache for polygon overlap tests
_eps = 1e-12

def _rotate(px, py, cx, cy, a):
    c = math.cos(a)
    s = math.sin(a)
    dx = px - cx
    dy = py - cy
    return cx + dx * c - dy * s, cy + dx * s + dy * c

def _square_corners(cx, cy, angle, side):
    h = 0.5 * side
    ang = 2 * math.pi * angle
    c = math.cos(ang)
    s = math.sin(ang)
    pts = []
    for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + sx * c - sy * s, cy + sx * s + sy * c))
    return pts

def _seg_intersect(p1, p2, p3, p4):
    x1, y1 = p1
    x2, y2 = p2
    x3, y3 = p3
    x4, y4 = p4
    denom = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(denom) < 1e-30:
        return False
    t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / denom
    u = -((x1 - x2) * (y1 - y3) - (y1 - y2) * (x1 - x3)) / denom
    return 1e-11 < t < 1 - 1e-11 and 1e-11 < u < 1 - 1e-11

def _point_in_poly(pt, poly):
    x, y = pt
    inside = False
    n = len(poly)
    j = n - 1
    for i in range(n):
        xi, yi = poly[i]
        xj, yj = poly[j]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi + 1e-30) + xi):
            inside = not inside
        j = i
    return inside

def _squares_overlap(s1, s2):
    # s = (cx, cy, angle, side)
    if s1[3] < _eps or s2[3] < _eps:
        return False
    p1 = _square_corners(*s1)
    p2 = _square_corners(*s2)
    # check bounding boxes first
    b1 = (min(p[0] for p in p1), min(p[1] for p in p1), max(p[0] for p in p1), max(p[1] for p in p1))
    b2 = (min(p[0] for p in p2), min(p[1] for p in p2), max(p[0] for p in p2), max(p[1] for p in p2))
    if b1[2] <= b2[0] + 1e-12 or b2[2] <= b1[0] + 1e-12 or b1[3] <= b2[1] + 1e-12 or b2[3] <= b1[1] + 1e-12:
        return False
    # separating axis theorem for convex polygons
    for poly in (p1, p2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            axis = (-(y2 - y1), x2 - x1)
            # project
            min1 = min2 = float('inf')
            max1 = max2 = float('-inf')
            for px, py in p1:
                d = px * axis[0] + py * axis[1]
                min1 = min(min1, d)
                max1 = max(max1, d)
            for px, py in p2:
                d = px * axis[0] + py * axis[1]
                min2 = min(min2, d)
                max2 = max(max2, d)
            if max1 <= min2 + 1e-11 or max2 <= min1 + 1e-11:
                return False
    return True

def _inside_unit(s):
    if s[3] < _eps:
        return True
    pts = _square_corners(*s)
    for x, y in pts:
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True

def _can_place(s, placed):
    if not _inside_unit(s):
        return False
    for p in placed:
        if _squares_overlap(s, p):
            return False
    return True

def _local_opt(sol, idx, placed_list):
    # try to improve side of square idx by local search in position and angle
    best = sol[idx]
    bs = best[3]
    # check if extra side can be added without moving
    cx, cy, ang, side = best
    # binary search max side at current pos/angle
    lo, hi = side, side + 0.5
    for _ in range(25):
        mid = (lo + hi) / 2
        cand = (cx, cy, ang, mid)
        ok = _inside_unit(cand)
        if ok:
            for j, p in enumerate(sol):
                if j == idx:
                    continue
                if _squares_overlap(cand, p):
                    ok = False
                    break
        if ok:
            lo = mid
        else:
            hi = mid
    if lo > bs + 1e-9:
        bs = lo
        best = (cx, cy, ang, lo)
    # random local adjustments
    for _ in range(30):
        dcx = random.gauss(0, 0.01)
        dcy = random.gauss(0, 0.01)
        dang = random.gauss(0, 0.02)
        ncx = min(1, max(0, best[0] + dcx))
        ncy = min(1, max(0, best[1] + dcy))
        nang = best[2] + dang
        # binary search side
        lo, hi = 0, best[3] + 0.2
        for _ in range(22):
            mid = (lo + hi) / 2
            cand = (ncx, ncy, nang, mid)
            ok = _inside_unit(cand)
            if ok:
                for j, p in enumerate(sol):
                    if j == idx:
                        continue
                    if _squares_overlap(cand, p):
                        ok = False
                        break
            if ok:
                lo = mid
            else:
                hi = mid
        if lo > best[3] + 1e-9:
            best = (ncx, ncy, nang, lo)
    return best

def _solve_grid(n):
    k = int(math.isqrt(n))
    while k * k > n:
        k -= 1
    side = 1.0 / k if k > 0 else 0
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]

def _greedy_pack(n, trials=150):
    best_sol = None
    best_sum = -1
    # generate candidate placements: grid positions and angles
    angles = [0.0, 0.125, 0.25, 0.375, 0.0625, 0.1875, 0.3125, 0.4375,
              0.03, 0.09, 0.21, 0.29, 0.41, 0.47]
    for trial in range(trials):
        random.seed(trial * 7919 + n * 131)
        sol = []
        placed_sum = 0.0
        # insert n squares greedily
        for idx in range(n):
            best_cand = None
            best_side = -1
            # try candidate positions
            gsize = 12 if trial < 40 else 9
            for gi in range(gsize + 1):
                for gj in range(gsize + 1):
                    px = gi / gsize if gsize > 0 else 0.5
                    py = gj / gsize if gsize > 0 else 0.5
                    for ang in angles:
                        # binary search max side at this position/angle
                        lo, hi = 0.0, 1.2
                        for _ in range(26):
                            mid = (lo + hi) / 2
                            cand = (px, py, ang, mid)
                            ok = _inside_unit(cand)
                            if ok:
                                for p in sol:
                                    if _squares_overlap(cand, p):
                                        ok = False
                                        break
                            if ok:
                                lo = mid
                            else:
                                hi = mid
                        # try to center better: the square at (px,py) might not be centered
                        # binary search gives max side for that center; try a few local tweaks
                        if lo > best_side:
                            best_side = lo
                            best_cand = (px, py, ang, lo)
            # local optimization of best candidate
            if best_cand is not None and best_side > 0:
                # refine position
                bc = best_cand
                for _ in range(20):
                    dx = random.gauss(0, 0.02)
                    dy = random.gauss(0, 0.02)
                    da = random.gauss(0, 0.03)
                    npx = min(1, max(0, bc[0] + dx))
                    npy = min(1, max(0, bc[1] + dy))
                    nang = bc[2] + da
                    lo, hi = 0.0, bc[3] + 0.15
                    for _ in range(22):
                        mid = (lo + hi) / 2
                        cand = (npx, npy, nang, mid)
                        ok = _inside_unit(cand)
                        if ok:
                            for p in sol:
                                if _squares_overlap(cand, p):
                                    ok = False
                                    break
                        if ok:
                            lo = mid
                        else:
                            hi = mid
                    if lo > bc[3]:
                        bc = (npx, npy, nang, lo)
                best_cand = bc
                best_side = bc[3]
            if best_cand is None:
                best_cand = (0.5, 0.5, 0.0, 0.0)
            sol.append(best_cand)
            placed_sum += best_side
        if placed_sum > best_sum:
            best_sum = placed_sum
            best_sol = sol
    return best_sol

def _optimize_solution(sol, iterations=200):
    sol = [list(s) for s in sol]
    for it in range(iterations):
        improved = False
        for i in range(len(sol)):
            # try to grow square i
            old = sol[i][3]
            best = _local_opt(sol, i, None)
            sol[i] = list(best)
            if best[3] > old + 1e-9:
                improved = True
        # pairwise: try moving square i to make room for j
        if not improved and it > 50:
            break
    return [tuple(s) for s in sol]

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # Start with grid solution
    best = _solve_grid(n)
    best_sum = sum(s[3] for s in best)
    
    # Try greedy packing with several restarts
    trials = 60 if n <= 20 else (30 if n <= 60 else 15)
    greedy = _greedy_pack(n, trials=trials)
    if greedy:
        gsum = sum(s[3] for s in greedy)
        if gsum > best_sum:
            best = greedy
            best_sum = gsum
    
    # local optimization
    opt = _optimize_solution(best, iterations=100)
    osum = sum(s[3] for s in opt)
    if osum > best_sum:
        best = opt
        best_sum = osum
    
    # ensure correct count and all in [0,1]
    result = []
    for s in best:
        cx = min(1, max(0, s[0]))
        cy = min(1, max(0, s[1]))
        ang = s[2] % 1.0
        side = min(1.0, max(0.0, s[3]))
        result.append((cx, cy, ang, side))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
