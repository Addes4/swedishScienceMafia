import math
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, ang, s):
    a = ang * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    # local corners
    lx = np.array([-h, h, h, -h])
    ly = np.array([-h, -h, h, h])
    x = c * lx - sn * ly + cx
    y = sn * lx + c * ly + cy
    return np.stack([x, y], axis=1)


def _axes_of(cx, cy, ang, s):
    a = ang * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    ex = np.array([c, sn]) * h
    ey = np.array([-sn, c]) * h
    return ex, ey


def _project(poly, axis):
    d = poly @ axis
    return d.min(), d.max()


def _overlap_sat(p1, ax1, p2, ax2, eps=1e-9):
    """Return approximate overlap area (0 if disjoint)."""
    overlap = True
    for ax in (ax1[0], ax1[1], ax2[0], ax2[1]):
        n = np.linalg.norm(ax)
        if n < 1e-15:
            continue
        u = ax / n
        a0, a1 = _project(p1, u)
        b0, b1 = _project(p2, u)
        if a1 <= b0 + eps or b1 <= a0 + eps:
            return 0.0
    # estimate overlap area via bounding-box on a rough shape
    # use minimal penetration axis length product
    best = float('inf')
    for ax in (ax1[0], ax1[1], ax2[0], ax2[1]):
        n = np.linalg.norm(ax)
        if n < 1e-15:
            continue
        u = ax / n
        a0, a1 = _project(p1, u)
        b0, b1 = _project(p2, u)
        pen = min(a1 - b0, b1 - a0)
        if pen < best:
            best = pen
    if best == float('inf'):
        return 0.0
    return max(0.0, best) ** 2


def _packing(n, k, mode='grid'):
    """Produce initial squares."""
    if mode == 'grid':
        if k * k > n:
            k = int(math.isqrt(n))
        side = 1.0 / k if k > 0 else 1.0
        res = []
        for i in range(k):
            for j in range(k):
                if len(res) >= n:
                    break
                res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        while len(res) < n:
            res.append((0.5, 0.5, 0.0, 0.0))
        return res[:n]


def _guillotine(n):
    """Recursive guillotine split into n nearly-equal square areas."""
    # Build a binary tree of rectangles, each split into square approximations
    rects = [(0.0, 0.0, 1.0, 1.0)]
    while len(rects) < n:
        # split the largest rectangle
        rects.sort(key=lambda r: -r[2] * r[3])
        w, h, _, _ = rects[0]
        x, y, w, h = rects[0]
        if w >= h:
            # split vertically
            nw1 = w * (n - len(rects) + 1) / (n - len(rects) + 2)
            nw1 = max(nw1, 1e-6)
            nw1 = min(nw1, w - 1e-6)
            r1 = (x, y, nw1, h)
            r2 = (x + nw1, y, w - nw1, h)
        else:
            nh1 = h * (n - len(rects) + 1) / (n - len(rects) + 2)
            nh1 = max(nh1, 1e-6)
            nh1 = min(nh1, h - 1e-6)
            r1 = (x, y, w, nh1)
            r2 = (x, y + nh1, w, h - nh1)
        rects.pop(0)
        rects.append(r1)
        rects.append(r2)
    res = []
    for (x, y, w, h) in rects:
        s = min(w, h)
        cx = x + w / 2.0
        cy = y + h / 2.0
        res.append((cx, cy, 0.0, s))
    return res


def _value_and_grad(params, n, penalty=1e4):
    """params: array of 4*n: cx, cy, angle, side (all in [0,1]).
    Objective: maximise sum side - penalty * overlap_area.
    Returns (negative objective + penalty*overlap)."""
    cx = params[0::4]
    cy = params[1::4]
    ang = params[2::4]
    s = params[3::4]

    # clamp angles not needed for angle fraction, but wrap to [0, 1)
    ang = ang % 1.0

    polys = []
    axes = []
    for i in range(n):
        polys.append(_corners(cx[i], cy[i], ang[i], s[i]))
        axes.append(_axes_of(cx[i], cy[i], ang[i], s[i]))

    total_overlap = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            if s[i] <= 1e-12 or s[j] <= 1e-12:
                continue
            ov = _overlap_sat(polys[i], axes[i], polys[j], axes[j])
            total_overlap += ov

    obj = -np.sum(s) + penalty * total_overlap
    return obj


def _polish(n, init, maxiter=200):
    x0 = np.zeros(4 * n)
    for i, (cx, cy, ang, s) in enumerate(init):
        x0[4 * i] = min(max(cx, 1e-9), 1.0 - 1e-9)
        x0[4 * i + 1] = min(max(cy, 1e-9), 1.0 - 1e-9)
        x0[4 * i + 2] = ang % 1.0
        x0[4 * i + 3] = min(max(s, 0.0), 1.0)

    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))  # cx
        bounds.append((0.0, 1.0))  # cy
        bounds.append((0.0, 1.0))  # angle
        bounds.append((0.0, 1.0))  # side

    try:
        res = minimize(
            _value_and_grad,
            x0,
            args=(n, 1e5),
            method='L-BFGS-B',
            bounds=bounds,
            options={'maxiter': maxiter, 'ftol': 1e-12, 'gtol': 1e-10},
        )
        x = res.x
    except Exception:
        x = x0

    # clean result: enforce inside unit square by clamping centres, check for overlaps
    out = []
    for i in range(n):
        cx = min(max(x[4 * i], 0.0), 1.0)
        cy = min(max(x[4 * i + 1], 0.0), 1.0)
        ang = x[4 * i + 2] % 1.0
        s = min(max(x[4 * i + 3], 0.0), 1.0)
        out.append((cx, cy, ang, s))
    return out


def _score(sqs):
    return sum(s for (_, _, _, s) in sqs)


def _valid(sqs, eps=1e-7):
    """Check interiors disjoint and all inside unit square."""
    n = len(sqs)
    polys = []
    axes = []
    for (cx, cy, ang, s) in sqs:
        if s <= 0:
            continue
        # inside square check
        p = _corners(cx, cy, ang, s)
        if p[:, 0].min() < -eps or p[:, 0].max() > 1.0 + eps:
            return False
        if p[:, 1].min() < -eps or p[:, 1].max() > 1.0 + eps:
            return False
        polys.append(p)
        axes.append(_axes_of(cx, cy, ang, s))
    m = len(polys)
    for i in range(m):
        for j in range(i + 1, m):
            # check sat overlap
            ov = True
            for ax in (axes[i][0], axes[i][1], axes[j][0], axes[j][1]):
                nn = np.linalg.norm(ax)
                if nn < 1e-15:
                    continue
                u = ax / nn
                a0, a1 = _project(polys[i], u)
                b0, b1 = _project(polys[j], u)
                if a1 <= b0 + eps or b1 <= a0 + eps:
                    ov = False
                    break
            if ov:
                return False
    return True


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    candidates = []
    k = int(math.isqrt(n))
    for kk in range(max(1, k - 1), k + 2):
        if kk * kk <= n:
            candidates.append(_packing(n, kk, 'grid'))
    candidates.append(_guillotine(n))

    # also try a couple of random-ish perturbations of the grid for small n
    best = None
    best_score = -1.0

    for init in candidates:
        # initial must have n entries
        while len(init) < n:
            init.append((0.5, 0.5, 0.0, 0.0))
        init = init[:n]

        # quick check on unpolished initial
        if _valid(init):
            sc = _score(init)
            if sc > best_score:
                best_score = sc
                best = list(init)

        # polish
        polished = _polish(n, init)
        # fix tiny overlaps by shrinking
        polished = _repair(polished)
        if _valid(polished):
            sc = _score(polished)
            if sc > best_score:
                best_score = sc
                best = list(polished)

    if best is None:
        # fallback: grid
        k = int(math.isqrt(n))
        side = 1.0 / k if k > 0 else 0.0
        best = [((i % k + 0.5) * side, (i // k + 0.5) * side, 0.0, side) for i in range(n)]
        # if n not a square, last ones zero
        if k * k < n:
            k2 = k
            side2 = 1.0 / k2 if k2 > 0 else 0.0
            best = []
            for i in range(n):
                if i < k2 * k2:
                    best.append(((i % k2 + 0.5) * side2, (i // k2 + 0.5) * side2, 0.0, side2))
                else:
                    best.append((0.5, 0.5, 0.0, 0.0))

    # final safety shrink to ensure validity
    best = _repair(best)
    return best[:n]


def _repair(sqs, max_iter=60):
    """Iteratively shrink squares that overlap and move inside."""
    sqs = list(sqs)
    n = len(sqs)
    for _ in range(max_iter):
        polys = []
        axes = []
        for (cx, cy, ang, s) in sqs:
            polys.append(_corners(cx, cy, ang, s) if s > 0 else np.array([[cx, cy]]))
            axes.append(_axes_of(cx, cy, ang, s) if s > 0 else (np.array([0, 0]), np.array([0, 0])))

        changed = False
        # clamp inside square
        for i in range(n):
            cx, cy, ang, s = sqs[i]
            if s <= 0:
                continue
            a = ang * 2.0 * math.pi
            c, sn = math.cos(a), math.sin(a)
            h = s * 0.5
            # support in x and y
            sx = abs(c) * h + abs(sn) * h
            sy = abs(sn) * h + abs(c) * h
            ncx = min(max(cx, sx), 1.0 - sx)
            ncy = min(max(cy, sy), 1.0 - sy)
            if ncx != cx or ncy != cy:
                # check if can move exactly: if sx > 0.5 or sy > 0.5 impossible
                if sx <= 0.5 + 1e-9 and sy <= 0.5 + 1e-9:
                    sqs[i] = (ncx, ncy, ang, s)
                    changed = True
                else:
                    # shrink
                    smax = 1.0 / (abs(c) + abs(sn) + 1e-12)
                    sqs[i] = (0.5, 0.5, ang, min(s, smax))
                    changed = True

        # shrink overlaps
        for i in range(n):
            for j in range(i + 1, n):
                si = sqs[i][3]
                sj = sqs[j][3]
                if si <= 0 or sj <= 0:
                    continue
                ov = _overlap_sat(polys[i], axes[i], polys[j], axes[j])
                if ov > 1e-12:
                    # shrink both a bit
                    fx = 0.9
                    sqs[i] = (sqs[i][0], sqs[i][1], sqs[i][2], max(0.0, si * fx))
                    sqs[j] = (sqs[j][0], sqs[j][1], sqs[j][2], max(0.0, sj * fx))
                    changed = True
                polys[i] = _corners(*sqs[i]) if sqs[i][3] > 0 else np.array([[sqs[i][0], sqs[i][1]]])
                polys[j] = _corners(*sqs[j]) if sqs[j][3] > 0 else np.array([[sqs[j][0], sqs[j][1]]])
                axes[i] = _axes_of(sqs[i][0], sqs[i][1], sqs[i][2], sqs[i][3]) if sqs[i][3] > 0 else (np.array([0, 0]), np.array([0, 0]))
                axes[j] = _axes_of(sqs[j][0], sqs[j][1], sqs[j][2], sqs[j][3]) if sqs[j][3] > 0 else (np.array([0, 0]), np.array([0, 0]))

        if not changed:
            break
    return sqs
