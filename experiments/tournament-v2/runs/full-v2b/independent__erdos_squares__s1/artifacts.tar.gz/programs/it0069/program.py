import math
import random

# Geometry helpers for axis-aligned and rotated squares

def corners(cx, cy, ang, s):
    """Return 4 corners of square centered at (cx,cy), side s, angle fraction of turn."""
    th = ang * 2 * math.pi  # angle in radians
    c, si = math.cos(th), math.sin(th)
    h = s / 2.0
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        xr = x * c - y * si
        yr = x * si + y * c
        out.append((cx + xr, cy + yr))
    return out

def sat_overlap(a, b):
    """Check whether two convex polygons overlap via separating axis theorem."""
    # a and b are lists of points; return True if overlapping interiors
    # get axes from both polygons
    for poly in (a, b):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            # normal axis
            ax, ay = -ey, ex
            # project both polygons
            def proj(poly):
                vals = [p[0] * ax + p[1] * ay for p in poly]
                return min(vals), max(vals)
            mina, maxa = proj(a)
            minb, maxb = proj(b)
            if maxa < minb or maxb < mina:
                return False
    return True

def inside_unit(cx, cy, ang, s):
    if s == 0:
        return 0 <= cx <= 1 and 0 <= cy <= 1
    pts = corners(cx, cy, ang, s)
    for x, y in pts:
        if x < 0 or x > 1 or y < 0 or y > 1:
            return False
    return True

def clamp_center(cx, cy, ang, s):
    """Move center minimally so square fits in [0,1]^2."""
    if s == 0:
        return min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0)
    # iterative clamp: adjust center until inside
    for _ in range(10):
        pts = corners(cx, cy, ang, s)
        minx = min(p[0] for p in pts)
        maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts)
        maxy = max(p[1] for p in pts)
        dx = 0.0
        dy = 0.0
        if minx < 0:
            dx += -minx
        if maxx > 1:
            dx -= maxx - 1
        if miny < 0:
            dy += -miny
        if maxy > 1:
            dy -= maxy - 1
        if dx == 0 and dy == 0:
            break
        cx += dx
        cy += dy
    return min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0)

def resolve_overlaps(squares, iterations=200):
    """Push overlapping squares apart to reduce overlaps."""
    n = len(squares)
    for _ in range(iterations):
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                ci = corners(*squares[i])
                cj = corners(*squares[j])
                if sat_overlap(ci, cj):
                    moved = True
                    # push apart along center difference
                    xi, yi = squares[i][0], squares[i][1]
                    xj, yj = squares[j][0], squares[j][1]
                    dx = xj - xi
                    dy = yj - yi
                    dist = math.hypot(dx, dy)
                    if dist < 1e-9:
                        # random direction
                        ang = random.random() * 2 * math.pi
                        dx, dy = math.cos(ang), math.sin(ang)
                        dist = 1.0
                    # move a little
                    step = 0.5 * (squares[i][3] + squares[j][3] + 0.001)
                    step = min(step, 0.05)
                    ux, uy = dx / dist, dy / dist
                    # move both
                    squares[i] = (
                        xi - ux * step,
                        yi - uy * step,
                        squares[i][2],
                        squares[i][3],
                    )
                    squares[j] = (
                        xj + ux * step,
                        yj + uy * step,
                        squares[j][2],
                        squares[j][3],
                    )
        # clamp all
        for k in range(n):
            cx, cy, a, s = squares[k]
            cx, cy = clamp_center(cx, cy, a, s)
            squares[k] = (cx, cy, a, s)
        if not moved:
            break
    return squares

def greedy_placement(n):
    """Start with grid, then try to add larger squares greedily."""
    k = math.isqrt(n)
    side = 1.0 / k if k > 0 else 1.0
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # fill remaining with tiny squares
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]

def optimize(squares, n, time_budget=100):
    """Try to grow squares and fix overlaps."""
    # First, give every square some size if it is zero
    total = sum(s[3] for s in squares)
    for _ in range(time_budget):
        improved = False
        # try growing the smallest square
        idxs = sorted(range(n), key=lambda i: squares[i][3])
        for idx in idxs:
            cx, cy, a, s = squares[idx]
            if s >= 0.999:
                continue
            # try increase s
            for ds in [0.02, 0.01, 0.005, 0.002, 0.001]:
                ns = min(s + ds, 0.999)
                if ns <= s:
                    continue
                # check inside
                if not inside_unit(cx, cy, a, ns):
                    # try to clamp
                    ncx, ncy = clamp_center(cx, cy, a, ns)
                    if not inside_unit(ncx, ncy, a, ns):
                        continue
                    cx, cy = ncx, ncy
                # check overlap
                ok = True
                for j in range(n):
                    if j == idx:
                        continue
                    if sat_overlap(corners(cx, cy, a, ns), corners(*squares[j])):
                        ok = False
                        break
                if ok:
                    squares[idx] = (cx, cy, a, ns)
                    improved = True
                    break
        # try small position adjustments
        for idx in range(n):
            cx, cy, a, s = squares[idx]
            if s == 0:
                continue
            best = (cx, cy, a, s)
            best_sum = 0
            for _ in range(5):
                ncx = cx + (random.random() - 0.5) * 0.01
                ncy = cy + (random.random() - 0.5) * 0.01
                ncx, ncy = clamp_center(ncx, ncy, a, s)
                if not inside_unit(ncx, ncy, a, s):
                    continue
                # check overlap
                ok = True
                for j in range(n):
                    if j == idx:
                        continue
                    if sat_overlap(corners(ncx, ncy, a, s), corners(*squares[j])):
                        ok = False
                        break
                if ok:
                    # score based on remaining space? just accept
                    best = (ncx, ncy, a, s)
                    break
            squares[idx] = best
        if not improved:
            break
    return squares

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # For small n, try to use special known optimal packings
    # But general approach: multiple restarts with grid + optimization
    best_squares = None
    best_sum = -1.0
    
    # Determine initial grid size
    k = math.isqrt(n)
    side0 = 1.0 / k if k > 0 else 1.0
    
    # Try several random initial configurations
    num_restarts = 20
    for restart in range(num_restarts):
        if restart == 0:
            base = greedy_placement(n)
        else:
            base = []
            # random placements
            for i in range(n):
                if i < k * k:
                    # grid jittered
                    row = i // k
                    col = i % k
                    cx = (col + 0.5) * side0 + (random.random() - 0.5) * 0.05
                    cy = (row + 0.5) * side0 + (random.random() - 0.5) * 0.05
                    cx, cy = clamp_center(cx, cy, 0.0, side0)
                    base.append((cx, cy, 0.0, side0))
                else:
                    base.append((random.random(), random.random(), random.random(), 0.0))
        # resolve overlaps
        base = resolve_overlaps(base, iterations=50)
        # optimize
        base = optimize(base, n, time_budget=80)
        # final score
        total = sum(s[3] for s in base)
        if total > best_sum:
            best_sum = total
            best_squares = base[:]
    
    # ensure all centers in [0,1] and sides non-negative
    result = []
    for cx, cy, a, s in best_squares:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        s = max(0.0, s)
        result.append((cx, cy, a, s))
    # pad if needed
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
