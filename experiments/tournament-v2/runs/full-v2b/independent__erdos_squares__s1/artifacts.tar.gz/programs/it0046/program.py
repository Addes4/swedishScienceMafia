import math
import random
import time

# ---------- geometry: disjoint interiors for rotated squares ----------

def _corners(cx, cy, ang, s):
    """Corners of a square, angle as fraction of full turn."""
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa,
                    cy + dx * sa + dy * ca))
    return pts

def _proj(pts, ax, ay):
    return [x * ax + y * ay for x, y in pts]

def _overlap(poly1, poly2):
    """True if the interiors of two convex polygons intersect."""
    for pts in (poly1, poly2):
        n = len(pts)
        for i in range(n):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            ax, ay = -ey, ex
            L = math.hypot(ax, ay)
            if L == 0:
                continue
            ax, ay = ax / L, ay / L
            a = _proj(poly1, ax, ay)
            b = _proj(poly2, ax, ay)
            if min(a) >= max(b) - 1e-12 or min(b) >= max(a) - 1e-12:
                return False
    return True

def _inside_unit(poly):
    for x, y in poly:
        if x < -1e-10 or x > 1.0 + 1e-10 or y < -1e-10 or y > 1.0 + 1e-10:
            return False
    return True

def _valid(sq):
    """Check all squares are inside unit square and pairwise disjoint."""
    polys = [_corners(*s) for s in sq]
    for p in polys:
        if not _inside_unit(p):
            return False
    m = len(polys)
    for i in range(m):
        if sq[i][3] <= 0.0:
            continue
        for j in range(i + 1, m):
            if sq[j][3] <= 0.0:
                continue
            if _overlap(polys[i], polys[j]):
                return False
    return True

def _total(sq):
    return sum(s[3] for s in sq)

# ---------- initial construction ----------

def _initial(n):
    """Largest regular k x k grid, remainder zero-size at centre."""
    k = math.isqrt(n)
    side = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res

# ---------- local optimisation ----------

def _can_place(sq, idx, cx, cy, ang, s):
    """Would square idx with given params not overlap others and stay inside?"""
    poly = _corners(cx, cy, ang, s)
    if s > 0 and not _inside_unit(poly):
        return False
    for j, other in enumerate(sq):
        if j == idx or other[3] <= 0.0 or s <= 0.0:
            continue
        if _overlap(poly, _corners(*other)):
            return False
    return True

def _try_grow(sq, idx, delta, angles):
    """Try to grow square idx by delta trying several angles/positions."""
    cx, cy, ang, s = sq[idx]
    best = sq[idx]
    # try current centre with several angles
    for a in angles:
        ns = s + delta
        if _can_place(sq, idx, cx, cy, a, ns):
            if ns > best[3]:
                best = (cx, cy, a, ns)
    # try small positional jitters around centre
    if best[3] <= s:
        for _ in range(24):
            dx = random.uniform(-delta, delta)
            dy = random.uniform(-delta, delta)
            nx = min(1.0, max(0.0, cx + dx))
            ny = min(1.0, max(0.0, cy + dy))
            a = random.choice(angles)
            ns = s + delta
            if _can_place(sq, idx, nx, ny, a, ns):
                best = (nx, ny, a, ns)
                break
    return best

def _improve(sq, deadline):
    """Iteratively try to increase sum of sides."""
    n = len(sq)
    best = sq[:]
    best_score = _total(best)
    angles = [0.0, 0.25, 0.125, 0.375, 0.0625, 0.1875, 0.3125, 0.4375]
    step = 0.02
    stall = 0
    while time.time() < deadline:
        improved = False
        order = list(range(n))
        random.shuffle(order)
        for idx in order:
            if time.time() >= deadline:
                break
            cur = best[idx][3]
            delta = step * max(cur, 0.01)
            cand = _try_grow(best, idx, delta, angles)
            if cand[3] > cur + 1e-12:
                best[idx] = cand
                improved = True
                ns = _total(best)
                if ns > best_score:
                    best_score = ns
        if not improved:
            stall += 1
            if stall > 2:
                step *= 0.7
                stall = 0
                if step < 1e-4:
                    break
        else:
            stall = 0
    return best

def _compact(sq, rounds=3):
    """Shrink biggest squares slightly to allow rebalancing, then re-grow."""
    n = len(sq)
    res = sq[:]
    for _ in range(rounds):
        # sort indices by size
        idxs = sorted(range(n), key=lambda i: res[i][3], reverse=True)
        if not idxs:
            break
        # shrink the largest a bit
        i = idxs[0]
        cx, cy, a, s = res[i]
        res[i] = (cx, cy, a, s * 0.98)
    return res

# ---------- public ----------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        # best: single square side 1
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345 + n)
    t0 = time.time()
    deadline = t0 + 55.0

    sq = _initial(n)
    # quick validity check
    if not _valid(sq):
        # fallback: tiny squares
        sq = [(0.5, 0.5, 0.0, 0.0) for _ in range(n)]

    # multiple restarts with different local optima
    best = sq[:]
    best_score = _total(best)

    attempts = 0
    while time.time() < deadline and attempts < 8:
        attempts += 1
        cand = _improve(best[:], min(deadline, time.time() + 6.0))
        sc = _total(cand)
        if sc > best_score + 1e-12 and _valid(cand):
            best = cand
            best_score = sc
        # compact and retry
        if time.time() < deadline:
            comp = _compact(best, 1)
            cand2 = _improve(comp, min(deadline, time.time() + 5.0))
            sc2 = _total(cand2)
            if sc2 > best_score + 1e-12 and _valid(cand2):
                best = cand2
                best_score = sc2

    # final safety: if invalid, fall back to grid
    if not _valid(best):
        best = _initial(n)

    # clamp outputs
    out = []
    for cx, cy, a, s in best:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        a = a % 1.0
        s = max(0.0, min(1.0, s))
        out.append((cx, cy, a, s))
    return out
