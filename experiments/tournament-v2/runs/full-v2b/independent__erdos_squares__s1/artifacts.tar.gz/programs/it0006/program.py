import math
import random
import time


def overlap_ok(x1, y1, a1, s1, x2, y2, a2, s2):
    """Return True if interiors of two squares do not overlap."""
    if s1 <= 0 or s2 <= 0:
        return True
    c1, s1_ = math.cos(2 * math.pi * a1), math.sin(2 * math.pi * a1)
    c2, s2_ = math.cos(2 * math.pi * a2), math.sin(2 * math.pi * a2)
    # axes for each square
    u1 = [(c1, s1_), (-s1_, c1)]
    u2 = [(c2, s2_), (-s2_, c2)]
    dx = x1 - x2
    dy = y1 - y2
    h1 = s1 / 2.0
    h2 = s2 / 2.0
    # project onto 4 candidate separating axes
    for ax, ay in u1 + u2:
        r1 = h1 * (abs(ax * u1[0][0] + ay * u1[0][1]) + abs(ax * u1[1][0] + ay * u1[1][1]))
        r2 = h2 * (abs(ax * u2[0][0] + ay * u2[0][1]) + abs(ax * u2[1][0] + ay * u2[1][1]))
        d = abs(dx * ax + dy * ay)
        if d >= r1 + r2 - 1e-12:
            return True
    return False


def inside(x, y, a, s):
    """Check square inside unit square."""
    if s <= 0:
        return 0.0 <= x <= 1.0 and 0.0 <= y <= 1.0
    c, sn = math.cos(2 * math.pi * a), math.sin(2 * math.pi * a)
    h = s / 2.0
    # extent in x and y
    ex = h * (abs(c) + abs(sn))
    ey = h * (abs(sn) + abs(c))
    return x - ex >= -1e-12 and x + ex <= 1.0 + 1e-12 and y - ey >= -1e-12 and y + ey <= 1.0 + 1e-12


def valid_all(sqs):
    """Check all pairs and boundaries."""
    m = len(sqs)
    for i in range(m):
        if not inside(*sqs[i]):
            return False
    for i in range(m):
        for j in range(i + 1, m):
            x1, y1, a1, s1 = sqs[i]
            x2, y2, a2, s2 = sqs[j]
            if not overlap_ok(x1, y1, a1, s1, x2, y2, a2, s2):
                return False
    return True


def best_axis_square(sqs, candidates=4000, rng=None):
    """Find a good axis-aligned square to insert by sampling positions and sizing."""
    if rng is None:
        rng = random.Random(12345)
    best_s = 0.0
    best_x = 0.0
    best_y = 0.0
    # sample centers
    for _ in range(candidates):
        x = rng.random()
        y = rng.random()
        # find max half size that fits around (x,y)
        max_h = min(x, 1.0 - x, y, 1.0 - y)
        # shrink against existing
        for (sx, sy, sa, ss) in sqs:
            if ss <= 0:
                continue
            # axis aligned square centered at x,y; test overlap with rotated
            # use conservative: distance projected
            c, sn = math.cos(2 * math.pi * sa), math.sin(2 * math.pi * sa)
            h = ss / 2.0
            ex = h * (abs(c) + abs(sn))
            ey = h * (abs(sn) + abs(c))
            dx = abs(x - sx)
            dy = abs(y - sy)
            # half-extent sum for axis-aligned overlap on x or y
            rx = ex + max_h  # we will shrink max_h
            # max_h allowed considering x-overlap
            mx = ex - dx
            if mx > 0:
                max_h = min(max_h, mx)  # if centers closer than sum, need d >= ex + h
            my = ey - dy
            if my > 0:
                max_h = min(max_h, my)
            if max_h <= 0:
                break
        if max_h > best_s / 2.0:
            best_s = 2.0 * max_h
            best_x = x
            best_y = y
    return best_x, best_y, best_s


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(0)
    start = time.time()
    time_limit = 55.0

    # start with greedy: repeatedly insert best axis-aligned square
    squares = []
    for idx in range(n):
        if time.time() - start > time_limit * 0.5:
            # fill remainder with zeros
            while len(squares) < n:
                squares.append((0.5, 0.5, 0.0, 0.0))
            break
        bx, by, bs = best_axis_square(squares, candidates=max(80, 2000 // (idx + 1)), rng=rng)
        if bs <= 1e-15:
            squares.append((0.5, 0.5, 0.0, 0.0))
        else:
            squares.append((bx, by, 0.0, bs))
    # if we ended early
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]

    # local hill climb: perturb positions/sizes/angles slightly, accept if valid and sum grows
    def total(S):
        return sum(s for (_, _, _, s) in S)

    best = [list(t) for t in squares]
    best_sum = total(best)
    cur = [list(t) for t in best]
    cur_sum = best_sum

    iterations = 0
    max_iter = 20000
    while time.time() - start < time_limit and iterations < max_iter:
        iterations += 1
        # pick a random square
        i = rng.randrange(n)
        # if it's zero, try to grow it a bit
        cand = [row[:] for row in cur]
        x, y, a, s = cand[i]
        mode = rng.random()
        if mode < 0.5:
            # perturb position
            nx = x + rng.uniform(-0.02, 0.02)
            ny = y + rng.uniform(-0.02, 0.02)
            nx = min(1.0, max(0.0, nx))
            ny = min(1.0, max(0.0, ny))
            cand[i] = [nx, ny, a, s]
        elif mode < 0.8:
            # perturb size
            ns = s + rng.uniform(-0.02, 0.02)
            ns = max(0.0, ns)
            cand[i] = [x, y, a, ns]
        else:
            # perturb angle
            na = a + rng.uniform(-0.1, 0.1)
            na = na % 1.0
            cand[i] = [x, y, na, s]

        # validate only affected pairs
        ok = inside(*cand[i])
        if ok:
            for j in range(n):
                if j == i:
                    continue
                if not overlap_ok(cand[i][0], cand[i][1], cand[i][2], cand[i][3],
                                  cand[j][0], cand[j][1], cand[j][2], cand[j][3]):
                    ok = False
                    break
        if ok:
            nsum = sum(row[3] for row in cand)
            if nsum > cur_sum - 1e-15:
                cur = cand
                cur_sum = nsum
                if nsum > best_sum:
                    best = [row[:] for row in cand]
                    best_sum = nsum

    return [(float(x), float(y), float(a % 1.0), float(max(0.0, s))) for (x, y, a, s) in best]
