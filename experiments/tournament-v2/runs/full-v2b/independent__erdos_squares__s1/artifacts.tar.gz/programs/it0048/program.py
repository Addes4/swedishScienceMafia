import math
import numpy as np
from scipy.optimize import minimize


def _overlap_penalty_and_constraints(vars, n):
    # vars: [cx0, cy0, a0, side0, ...]
    c = vars.reshape(n, 4)
    cxs = c[:, 0]
    cys = c[:, 1]
    angs = c[:, 2]
    sides = c[:, 3]
    pen = 0.0
    cons = []

    # boundary / containment constraints: square inside [0,1]^2
    # use local rotated half-extents
    ca = np.cos(2 * np.pi * angs)
    sa = np.sin(2 * np.pi * angs)
    half = sides * 0.5
    hx = np.abs(ca) * half + np.abs(sa) * half
    hy = np.abs(sa) * half + np.abs(ca) * half

    lbx = (-1.0) - (cxs - hx)
    ubx = (1.0) - (cxs + hx)
    lby = (-1.0) - (cys - hy)
    uby = (1.0) - (cys + hy)

    for i in range(n):
        pen += max(0.0, -lbx[i]) ** 2 * 1e6
        pen += max(0.0, -ubx[i]) ** 2 * 1e6
        pen += max(0.0, -lby[i]) ** 2 * 1e6
        pen += max(0.0, -uby[i]) ** 2 * 1e6
        pen += max(0.0, -sides[i]) ** 2 * 1e6
        pen += max(0.0, sides[i] - 1.0) ** 2 * 1e6

    # pairwise non-overlap penalty (approx using projecting half-extents)
    if n > 1:
        # distance between centers
        dx = cxs[:, None] - cxs[None, :]
        dy = cys[:, None] - cys[None, :]
        dist = np.sqrt(dx * dx + dy * dy + 1e-30)
        rsum = (hx[:, None] + hx[None, :] + hy[:, None] + hy[None, :]) * 0.35
        viol = np.maximum(0.0, rsum - dist)
        pen += np.sum(viol ** 2) * 5e5

    return pen


def _pack_initial(n):
    # Begin with equal squares in a grid, then greedily add more if grid leaves room
    k = max(1, int(math.isqrt(n)))
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) < n:
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _greedy_add(squares, slots_to_fill):
    # Very rough greedy improvement: redistribute side lengths slightly
    return squares


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # initial arrangement
    squares = _pack_initial(n)

    # convert to flat variables
    x0 = []
    for cx, cy, a, s in squares:
        x0.extend([cx, cy, a, s])
    x0 = np.array(x0, dtype=float)

    bounds = []
    for _ in range(n):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])

    best_x = x0.copy()
    best_score = -np.sum(x0.reshape(n, 4)[:, 3])
    best_pen = _overlap_penalty_and_constraints(x0, n)

    # try a few restarts with randomized perturbations
    for it in range(3):
        if it == 0:
            xi = x0.copy()
        else:
            xi = best_x.copy()
            c = xi.reshape(n, 4)
            for i in range(n):
                # keep small squares small, big ones can move a bit
                scale = max(0.01, c[i, 3])
                c[i, 0] = np.clip(c[i, 0] + np.random.uniform(-0.05 * scale, 0.05 * scale), 0.0, 1.0)
                c[i, 1] = np.clip(c[i, 1] + np.random.uniform(-0.05 * scale, 0.05 * scale), 0.0, 1.0)
                c[i, 2] = np.clip((c[i, 2] + np.random.uniform(-0.02, 0.02)) % 1.0, 0.0, 1.0)
                c[i, 3] = np.clip(c[i, 3] * np.random.uniform(0.95, 1.05), 0.0, 1.0)
            xi = c.reshape(-1)

        try:
            res = minimize(
                _overlap_penalty_and_constraints,
                xi,
                args=(n,),
                method='L-BFGS-B',
                bounds=bounds,
                options={'maxiter': 300, 'ftol': 1e-9, 'gtol': 1e-6}
            )
            xi = res.x
            pen = _overlap_penalty_and_constraints(xi, n)
            score = np.sum(xi.reshape(n, 4)[:, 3])
            if pen < best_pen - 1e-6 or (pen < 1e-5 and score > best_score):
                best_x = xi
                best_pen = pen
                best_score = score
        except Exception:
            pass

    # final cleanup: force all into valid bounds and extract
    c = best_x.reshape(n, 4)
    result = []
    for i in range(n):
        cx = float(np.clip(c[i, 0], 0.0, 1.0))
        cy = float(np.clip(c[i, 1], 0.0, 1.0))
        a = float(c[i, 2]) % 1.0
        s = float(np.clip(c[i, 3], 0.0, 1.0))
        result.append((cx, cy, a, s))
    return result[:n]
