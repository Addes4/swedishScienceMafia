import math
import random
import time

# ---------- geometry helpers ----------

def corners(cx, cy, a, s):
    """Return the 4 corners of a square with centre (cx,cy), angle a turns, side s."""
    t = 2.0 * math.pi * a
    c = math.cos(t)
    sn = math.sin(t)
    h = 0.5 * s
    # local axes u=(c,s), v=(-s,c)
    ux, uy = c, sn
    vx, vy = -sn, c
    return [
        (cx + h * ux + h * vx, cy + h * uy + h * vy),
        (cx + h * ux - h * vx, cy + h * uy - h * vy),
        (cx - h * ux - h * vx, cy - h * uy - h * vy),
        (cx - h * ux + h * vx, cy - h * uy + h * vy),
    ]


def clamp01(x):
    if x < 0.0:
        return 0.0
    if x > 1.0:
        return 1.0
    return x


def poly_overlap_area(p1, p2, eps=1e-12):
    """Approximate/general convex polygon intersection area via clipping."""
    # Sutherland-Hodgman clipping; p1 clipped by each edge of p2.
    def inside(pt, a, b):
        # left side of directed edge a->b
        return (b[0] - a[0]) * (pt[1] - a[1]) - (b[1] - a[1]) * (pt[0] - a[0]) >= -eps

    def intersect(p, q, a, b):
        # line p-q with line a-b
        x1, y1 = p
        x2, y2 = q
        x3, y3 = a
        x4, y4 = b
        den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
        if abs(den) < 1e-18:
            return q
        px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / den
        py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / den
        return (px, py)

    output = p1[:]
    n2 = len(p2)
    for i in range(n2):
        a = p2[i]
        b = p2[(i + 1) % n2]
        inp = output
        output = []
        if not inp:
            break
        s = inp[-1]
        for e in inp:
            if inside(e, a, b):
                if not inside(s, a, b):
                    output.append(intersect(s, e, a, b))
                output.append(e)
            elif inside(s, a, b):
                output.append(intersect(s, e, a, b))
            s = e

    if len(output) < 3:
        return 0.0
    area = 0.0
    n = len(output)
    for i in range(n):
        x1, y1 = output[i]
        x2, y2 = output[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def outside_penalty(c, s):
    """Penalty for corners outside [0,1]^2."""
    if s <= 0:
        return 0.0
    p = 0.0
    for x, y in c:
        if x < 0:
            p += -x
        elif x > 1:
            p += x - 1
        if y < 0:
            p += -y
        elif y > 1:
            p += y - 1
    return p


# ---------- constructive starts ----------

def grid_layout(n):
    """Baseline grid construction."""
    k = int(math.isqrt(n))
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    res = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    res += [(0.5, 0.5, 0.0, 0.0)] * (n - len(res))
    return res[:n]


def strips_layout(n):
    """Vertical strips: k full-height strips plus small squares if remainder."""
    # choose k so k + remainder <= n and remainder handled as small squares in the last strip
    best = None
    for k in range(1, n + 1):
        rem = n - k
        # k strips of width 1/k and height up to 1, each one square side min(1/k,1)=1/k
        # remainder: place rem small squares in last strip, max side limited by strip
        w = 1.0 / k
        # if no remainder, sum = k*w = 1 (same as grid 1xk, bad for many n)
        # use remainder as one extra strip? simpler: try k full strips and rem zero-squares
        res = []
        for i in range(k):
            res.append(((i + 0.5) * w, 0.5, 0.25, w if w < 1.0 else 1.0))
        res += [(0.5, 0.5, 0.0, 0.0)] * rem
        val = k * w
        if best is None or val > best[0]:
            best = (val, res)
    return best[1]


def adaptive_grid(n):
    """Try a few grid/strip/heuristic starts and keep the best legal one."""
    cands = []
    cands.append(grid_layout(n))
    cands.append(strips_layout(n))

    # mixed: floor(sqrt(n)) major grid plus remainder placed in empty cells with adjusted sizes
    k = int(math.isqrt(n))
    if k >= 1:
        base = grid_layout(n)
        cands.append(base)

    # try rows/cols decomposition
    for r in range(1, n + 1):
        c = n // r
        if c * r > n or c == 0:
            continue
        w = 1.0 / c
        h = 1.0 / r
        s = min(w, h)
        res = []
        cnt = 0
        for i in range(c):
            for j in range(r):
                if cnt < n:
                    res.append(((i + 0.5) * w, (j + 0.5) * h, 0.0, s))
                    cnt += 1
        while len(res) < n:
            res.append((0.5, 0.5, 0.0, 0.0))
        cands.append(res[:n])

    best = None
    bestv = -1.0
    for c in cands:
        c = repair(c)
        v = total_side(c)
        if v > bestv:
            bestv = v
            best = c
    return best


def total_side(sqs):
    return sum(s for _, _, _, s in sqs if s > 0)


def repair(sqs):
    """Clamp centres and shrink overlapping squares."""
    sqs = [list(x) for x in sqs]
    changed = True
    for _ in range(20):
        changed = False
        for i in range(len(sqs)):
            cx, cy, a, s = sqs[i]
            if s <= 0:
                continue
            cx = clamp01(cx)
            cy = clamp01(cy)
            sqs[i][0] = cx
            sqs[i][1] = cy
            c = corners(cx, cy, a, s)
            pen = outside_penalty(c, s)
            if pen > 1e-12:
                # shrink to fit: binary search max scale
                lo, hi = 0.0, s
                for _ in range(40):
                    mid = (lo + hi) * 0.5
                    cm = corners(cx, cy, a, mid)
                    if outside_penalty(cm, mid) <= 1e-12:
                        lo = mid
                    else:
                        hi = mid
                sqs[i][3] = lo
                changed = True
        for i in range(len(sqs)):
            if sqs[i][3] <= 0:
                continue
            for j in range(i + 1, len(sqs)):
                if sqs[j][3] <= 0:
                    continue
                ci = corners(sqs[i][0], sqs[i][1], sqs[i][2], sqs[i][3])
                cj = corners(sqs[j][0], sqs[j][1], sqs[j][2], sqs[j][3])
                # quick AABB reject
                xi0 = min(p[0] for p in ci); xi1 = max(p[0] for p in ci)
                yi0 = min(p[1] for p in ci); yi1 = max(p[1] for p in ci)
                xj0 = min(p[0] for p in cj); xj1 = max(p[0] for p in cj)
                yj0 = min(p[1] for p in cj); yj1 = max(p[1] for p in cj)
                if xi1 <= xj0 + 1e-12 or xj1 <= xi0 + 1e-12 or yi1 <= yj0 + 1e-12 or yj1 <= yi0 + 1e-12:
                    continue
                ar = poly_overlap_area(ci, cj)
                if ar > 1e-12:
                    # shrink both proportionally
                    f = max(0.0, 1.0 - min(0.5, ar * 20.0))
                    sqs[i][3] *= (f ** 0.5)
                    sqs[j][3] *= (f ** 0.5)
                    changed = True
        if not changed:
            break
    return [tuple(x) for x in sqs]


def overlap_penalty(sqs):
    """Sum of pairwise overlap areas plus outside penalties."""
    pen = 0.0
    n = len(sqs)
    polys = []
    for i in range(n):
        cx, cy, a, s = sqs[i]
        if s <= 0:
            polys.append(None)
            continue
        c = corners(cx, cy, a, s)
        polys.append(c)
        pen += outside_penalty(c, s)
    for i in range(n):
        if polys[i] is None:
            continue
        for j in range(i + 1, n):
            if polys[j] is None:
                continue
            ci = polys[i]
            cj = polys[j]
            xi0 = min(p[0] for p in ci); xi1 = max(p[0] for p in ci)
            yi0 = min(p[1] for p in ci); yi1 = max(p[1] for p in ci)
            xj0 = min(p[0] for p in cj); xj1 = max(p[0] for p in cj)
            yj0 = min(p[1] for p in cj); yj1 = max(p[1] for p in cj)
            if xi1 <= xj0 + 1e-12 or xj1 <= xi0 + 1e-12 or yi1 <= yj0 + 1e-12 or yj1 <= yi0 + 1e-12:
                continue
            pen += poly_overlap_area(ci, cj) * 100.0
    return pen


# ---------- local search ----------

def anneal(n, start, tlimit=48.0):
    t0 = time.time()
    cur = [list(x) for x in start]
    cur = repair([tuple(x) for x in cur])
    cur = [list(x) for x in cur]
    curv = total_side(cur)
    best = [list(x) for x in cur]
    bestv = curv

    T = 0.03
    alpha = 0.9995
    step_count = 0
    while time.time() - t0 < tlimit:
        step_count += 1
        T *= alpha
        if T < 1e-6:
            T = 1e-6
        i = random.randrange(n)
        old = cur[i][:]
        # mutate one square
        new = old[:]
        r = random.random()
        if r < 0.35:
            # perturb position
            new[0] = clamp01(old[0] + random.gauss(0, 0.02))
            new[1] = clamp01(old[1] + random.gauss(0, 0.02))
        elif r < 0.7:
            # perturb size
            new[3] = max(0.0, old[3] + random.gauss(0, 0.01))
        elif r < 0.95:
            new[2] = (old[2] + random.gauss(0, 0.02)) % 1.0
        else:
            # random reset
            new[0] = random.random()
            new[1] = random.random()
            new[2] = random.random()
            new[3] = random.uniform(0.0, 0.15)

        cur[i] = new
        # evaluate only affected pairs approximately + repair
        c = repair([tuple(x) for x in cur])
        c = [list(x) for x in c]
        v = total_side(c)
        pen = overlap_penalty(c)
        score = v - pen
        oldpen = overlap_penalty([[x for x in cur[i]]])  # dummy
        # accept based on score change from old
        # restore old for fair comparison
        cur[i] = c[i]
        curv_new = v
        pen_new = pen
        # compute old score approximately by restoring old in repaired local
        # simpler: compare values and accept; re-evaluate old score occasionally
        accept = False
        if pen_new < 1e-9:
            if curv_new > bestv:
                bestv = curv_new
                best = [x[:] for x in c]
            if curv_new >= curv or random.random() < math.exp((curv_new - curv) / max(T, 1e-9)):
                accept = True
        else:
            # penalized
            if random.random() < math.exp((-(pen_new)) / max(T, 1e-9)):
                accept = True
        if not accept:
            cur[i] = old
        else:
            cur = c
            curv = curv_new

    return [tuple(x) for x in best]


def greedy_improve(n, sqs, tlimit=8.0):
    """Greedily enlarge squares while keeping legality."""
    t0 = time.time()
    sqs = [list(x) for x in sqs]
    order = list(range(n))
    random.shuffle(order)
    improved = True
    while improved and time.time() - t0 < tlimit:
        improved = False
        for i in order:
            if time.time() - t0 >= tlimit:
                break
            old = sqs[i][3]
            # try double until invalid, then binary search
            lo = old
            hi = old * 1.5 + 0.05
            # check hi
            while hi < 2.0:
                test = [x[:] for x in sqs]
                test[i][3] = hi
                cand = repair([tuple(x) for x in test])
                if cand[i][3] >= hi - 1e-9 and overlap_penalty(cand) < 1e-9:
                    lo = hi
                    hi *= 1.5
                else:
                    break
            # binary search
            l, r = old, hi
            for _ in range(30):
                mid = (l + r) * 0.5
                test = [x[:] for x in sqs]
                test[i][3] = mid
                cand = repair([tuple(x) for x in test])
                if cand[i][3] >= mid - 1e-9 and overlap_penalty(cand) < 1e-9:
                    l = mid
                else:
                    r = mid
            if l > old + 1e-9:
                test = [x[:] for x in sqs]
                test[i][3] = l
                cand = repair([tuple(x) for x in test])
                if overlap_penalty(cand) < 1e-9:
                    sqs = [list(x) for x in cand]
                    improved = True
    return [tuple(x) for x in sqs]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    start = adaptive_grid(n)
    start = repair(start)

    # multi-start short annealing, keep best legal
    best = start
    bestv = total_side(best)
    t0 = time.time()

    # deterministic quick improvement first
    g = greedy_improve(n, best, tlimit=5.0)
    if total_side(g) > bestv:
        best = g
        bestv = total_side(best)

    # randomized restarts
    attempts = 0
    while time.time() - t0 < 52.0:
        attempts += 1
        if attempts == 1:
            s0 = best
        else:
            # perturb best
            s0 = []
            for cx, cy, a, s in best:
                if random.random() < 0.3:
                    cx = clamp01(cx + random.gauss(0, 0.03))
                    cy = clamp01(cy + random.gauss(0, 0.03))
                s0.append((cx, cy, a, s))
        r = anneal(n, s0, tlimit=min(12.0, max(2.0, (52.0 - (time.time() - t0)) / 3.0)))
        r = repair(r)
        vr = total_side(r)
        if vr > bestv:
            bestv = vr
            best = r

    # final greedy polish
    best = greedy_improve(n, best, tlimit=max(1.0, 59.0 - (time.time() - t0)))
    best = repair(best)
    return best[:n]
