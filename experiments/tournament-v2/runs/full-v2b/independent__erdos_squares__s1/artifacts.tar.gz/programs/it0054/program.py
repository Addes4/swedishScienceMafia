import math
import random
import time

# ---------------------------------------------------------------
# Geometry helpers: squares may be rotated, we do SAT-based
# separation tests for convex polygons (axis-aligned OBBs).
# ---------------------------------------------------------------

def corners(cx, cy, ang, s):
    """Return 4 corner points of square, angle in fraction of full turn."""
    theta = ang * 2.0 * math.pi
    c = math.cos(theta) * (s * 0.5)
    si = math.sin(theta) * (s * 0.5)
    # half-diagonal direction vectors
    dx1, dy1 = c, si
    dx2, dy2 = -si, c
    return [
        (cx + dx1 + dx2, cy + dy1 + dy2),
        (cx + dx1 - dx2, cy + dy1 - dy2),
        (cx - dx1 - dx2, cy - dy1 - dy2),
        (cx - dx1 + dx2, cy - dy1 + dy2),
    ]


def poly_axes(pts):
    axes = []
    m = len(pts)
    for i in range(m):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % m]
        ax, ay = -(y2 - y1), (x2 - x1)
        ln = math.hypot(ax, ay)
        if ln > 1e-15:
            axes.append((ax / ln, ay / ln))
    return axes


def project(pts, ax, ay):
    mn = mx = pts[0][0] * ax + pts[0][1] * ay
    for x, y in pts[1:]:
        v = x * ax + y * ay
        if v < mn:
            mn = v
        if v > mx:
            mx = v
    return mn, mx


def overlap(p1, p2):
    """True if interiors of two convex polygons overlap (allow touching)."""
    eps = 1e-12
    for ax, ay in poly_axes(p1) + poly_axes(p2):
        a1, b1 = project(p1, ax, ay)
        a2, b2 = project(p2, ax, ay)
        if b1 <= a2 + eps or b2 <= a1 + eps:
            return False
    return True


def inside_unit(pts):
    eps = 1e-9
    for x, y in pts:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


# ---------------------------------------------------------------
# Build candidate polyomino-style tilings based on exact geometry
# ---------------------------------------------------------------

def best_grid(n):
    k = math.isqrt(n)
    s = 1.0 / k
    sq = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq[:n], k * s


def best_guillotine(n):
    """Try many guillotine partitions of unit square into n rectangles, then
    convert to squares: place as large a square as possible in each rect
    (or multiple sub-squares if rectangle is wide)."""
    best = None
    best_score = -1.0

    def rec(rects, count):
        nonlocal best, best_score
        if count == 0:
            return
        if len(rects) == 0:
            return
        # evaluate
        if count == len(rects):
            sq = []
            for (x0, y0, w, h) in rects:
                s = min(w, h)
                sq.append((x0 + w * 0.5, y0 + h * 0.5, 0.0, s))
            score = sum(t[3] for t in sq)
            if score > best_score:
                best_score = score
                best = sq
            return
        # split the biggest rect
        ri = max(range(len(rects)), key=lambda i: rects[i][2] * rects[i][3])
        x0, y0, w, h = rects[ri]
        rest = rects[:ri] + rects[ri + 1:]
        # vertical split
        for frac in (0.5, 0.4, 0.6, 0.3, 0.7):
            r1 = (x0, y0, w * frac, h)
            r2 = (x0 + w * frac, y0, w * (1 - frac), h)
            rec(rest + [r1, r2], count)
        # horizontal split
        for frac in (0.5, 0.4, 0.6, 0.3, 0.7):
            r1 = (x0, y0, w, h * frac)
            r2 = (x0, y0 + h * frac, w, h * (1 - frac))
            rec(rest + [r1, r2], count)

    # Try starting with different splits
    rec([(0.0, 0.0, 1.0, 1.0)], n)
    if best is None:
        return best_grid(n)
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_score


# ---------------------------------------------------------------
# Greedy + simulated annealing packer
# ---------------------------------------------------------------

def initial_random(n, rng):
    # Start from grid pattern as baseline, perturb it
    k = math.isqrt(n)
    s = 1.0 / k if k > 0 else 0.0
    sq = []
    for i in range(k):
        for j in range(k):
            sq.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
    while len(sq) < n:
        sq.append([0.5, 0.5, 0.0, 0.0])
    sq = sq[:n]
    for t in sq:
        t[0] += rng.uniform(-s * 0.1, s * 0.1)
        t[1] += rng.uniform(-s * 0.1, s * 0.1)
        t[2] = 0.0
        t[3] *= rng.uniform(0.85, 1.05)
    return sq


def evaluate(sq):
    total = 0.0
    for t in sq:
        total += t[3]
    return total


def feasible(sq, cache=None):
    xs = []
    for t in sq:
        if t[3] < 1e-12:
            xs.append(None)
            continue
        c = corners(t[0], t[1], t[2], t[3])
        if not inside_unit(c):
            return False
        xs.append(c)
    n = len(sq)
    for i in range(n):
        if xs[i] is None:
            continue
        for j in range(i + 1, n):
            if xs[j] is None:
                continue
            if overlap(xs[i], xs[j]):
                return False
    return True


def clamp_inside(t):
    """Shrink side until fitted inside and centred correctly."""
    # binary search shrink
    lo, hi = 0.0, t[3]
    for _ in range(40):
        mid = (lo + hi) * 0.5
        c = corners(t[0], t[1], t[2], mid)
        if inside_unit(c):
            lo = mid
        else:
            hi = mid
    t[3] = lo
    # re-centre
    c = corners(t[0], t[1], t[2], t[3])
    minx = min(p[0] for p in c)
    maxx = max(p[0] for p in c)
    miny = min(p[1] for p in c)
    maxy = max(p[1] for p in c)
    if maxx - minx > 1.0:
        t[3] = 0.0
        return t
    if minx < 0:
        t[0] -= minx
    if maxx > 1.0:
        t[0] -= (maxx - 1.0)
    if miny < 0:
        t[1] -= miny
    if maxy > 1.0:
        t[1] -= (maxy - 1.0)
    return t


def try_insert(sq, rng):
    """Try to grow some square or add a new one into a free region."""
    # pick the smallest nonzero square and try to grow it
    order = sorted(range(len(sq)), key=lambda i: sq[i][3])
    for idx in order[:max(1, len(sq) // 4)]:
        t = sq[idx]
        old = t[3]
        # try growing
        for _ in range(5):
            grow = old * rng.uniform(0.02, 0.15) + 1e-4
            t[3] = old + grow
            clamp_inside(t)
            if feasible(sq):
                break
            t[3] = old
        else:
            t[3] = old
    return sq


def optimize(n, time_budget):
    rng = random.Random(12345)
    t0 = time.time()

    # gather best initialization
    cands = []
    try:
        g, gs = best_grid(n)
        cands.append(g)
    except Exception:
        pass
    try:
        gu, gus = best_guillotine(n)
        cands.append(gu)
    except Exception:
        pass
    cands.append(initial_random(n, rng))

    best = None
    best_score = -1.0
    for c in cands:
        c = [list(t) for t in c]
        # clean
        for t in c:
            clamp_inside(t)
        if feasible(c):
            sc = evaluate(c)
            if sc > best_score:
                best_score = sc
                best = c

    if best is None:
        # fallback to grid
        k = math.isqrt(n)
        s = 1.0 / k
        best = [list(t) for t in best_grid(n)[0]]

    # Simulated annealing style improvement
    current = [list(t) for t in best]
    cur_score = evaluate(current)

    T0 = 0.02
    T_end = 1e-4
    iter_count = 0
    max_iter = 200000

    while True:
        if time.time() - t0 > time_budget:
            break
        if iter_count > max_iter:
            break
        iter_count += 1
        frac = min(1.0, (time.time() - t0) / time_budget)
        T = T0 * (T_end / T0) ** frac

        mode = rng.random()
        cand = [t[:] for t in current]

        if mode < 0.5:
            # grow / shrink a random square
            i = rng.randrange(len(cand))
            old = cand[i][3]
            if rng.random() < 0.7:
                cand[i][3] = old + rng.uniform(0.0, 0.05)
            else:
                cand[i][3] = max(0.0, old - rng.uniform(0.0, 0.05))
            clamp_inside(cand[i])
        elif mode < 0.8:
            # shift
            i = rng.randrange(len(cand))
            cand[i][0] += rng.uniform(-0.03, 0.03)
            cand[i][1] += rng.uniform(-0.03, 0.03)
            clamp_inside(cand[i])
        else:
            # rotate
            i = rng.randrange(len(cand))
            cand[i][2] = (cand[i][2] + rng.uniform(-0.05, 0.05)) % 1.0
            clamp_inside(cand[i])

        if not feasible(cand):
            continue
        cscore = evaluate(cand)
        delta = cscore - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(T, 1e-9)):
            current = cand
            cur_score = cscore
            if cur_score > best_score:
                best_score = cur_score
                best = [t[:] for t in cand]

    # final cleanup
    result = []
    for t in best[:n]:
        x, y, a, s = t
        x = min(1.0, max(0.0, x))
        y = min(1.0, max(0.0, y))
        a = a % 1.0
        s = max(0.0, s)
        result.append((x, y, a, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]


def solve(n):
    if n <= 0:
        return []
    # time budget: aim well under 60 s
    budget = 8.0
    if n >= 400:
        budget = 15.0
    if n >= 2000:
        budget = 20.0
    try:
        return optimize(n, budget)
    except Exception:
        k = math.isqrt(n) if n > 0 else 1
        if k == 0:
            return [(0.5, 0.5, 0.0, 0.0)] * n
        s = 1.0 / k
        sq = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        return sq[:n]
