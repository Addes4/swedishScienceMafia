import math
import random

def solve(n):
    """Approximate maximisation of sum of side lengths of n non-overlapping squares in unit square."""
    if n <= 0:
        return []
    # Fast special cases for perfect square grids and small n.
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side by side, each 0.5
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # L-shape three squares side 0.5? Actually 0.5*3=1.5 possible? Try 0.5,0.5,0.5 with one above two.
        # 2 bottom side 0.5, one top side 0.5 centered? Actually max likely ~1.5.
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # Heuristic initial configuration: largest k x k grid plus remainder.
    k = math.isqrt(n)
    rem = n - k * k
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    # place remainder as tiny squares in an extra row/col if possible
    if rem > 0:
        # shrink main grid slightly to fit an extra row of small squares
        small = side * 0.45
        for t in range(rem):
            x = (t + 0.5) * (1.0 / rem)
            squares.append([x, 1.0 - small * 0.5 - 1e-6, 0.0, small])
        # adjust main grid down slightly
        for s in squares[:k*k]:
            s[1] *= (1.0 - small)
            s[3] *= (1.0 - small)

    # Now local optimisation: random restarts and coordinate descent.
    best = [list(s) for s in squares]
    best_score = sum(s[3] for s in best)

    def score(sqs):
        return sum(s[3] for s in sqs)

    def overlaps(a, b):
        # conservative overlap test using bounding circles
        ax, ay, aa, asz = a
        bx, by, ba, bsz = b
        # convert angle fraction to radians
        ar = aa * 2 * math.pi
        br = ba * 2 * math.pi
        # half diagonals
        ra = asz * math.sqrt(2) / 2
        rb = bsz * math.sqrt(2) / 2
        d = math.hypot(ax - bx, ay - by)
        # circle overlap is insufficient; use SAT-like approximate for axis-aligned bounding boxes
        # compute AABB half extents
        ca, sa = math.cos(ar), math.sin(ar)
        cb, sb = math.cos(br), math.sin(br)
        hax = asz * 0.5 * (abs(ca) + abs(sa))
        hay = asz * 0.5 * (abs(ca) + abs(sa))
        hbx = bsz * 0.5 * (abs(cb) + abs(sb))
        hby = bsz * 0.5 * (abs(cb) + abs(sb))
        if abs(ax - bx) > hax + hbx - 1e-12: return False
        if abs(ay - by) > hay + hby - 1e-12: return False
        # further check: exact polygon intersection using separating axis theorem
        # corners of A
        cornersA = []
        for sx, sy in [(-1,-1), (1,-1), (1,1), (-1,1)]:
            px = ax + asz * 0.5 * (sx * ca - sy * sa)
            py = ay + asz * 0.5 * (sx * sa + sy * ca)
            cornersA.append((px, py))
        cornersB = []
        for sx, sy in [(-1,-1), (1,-1), (1,1), (-1,1)]:
            px = bx + bsz * 0.5 * (sx * cb - sy * sb)
            py = by + bsz * 0.5 * (sx * sb + sy * cb)
            cornersB.append((px, py))
        # SAT
        def get_axes(corners):
            axes = []
            for i in range(4):
                p1 = corners[i]
                p2 = corners[(i+1)%4]
                edge = (p2[0]-p1[0], p2[1]-p1[1])
                normal = (-edge[1], edge[0])
                length = math.hypot(*normal)
                if length > 1e-15:
                    axes.append((normal[0]/length, normal[1]/length))
            return axes
        axes = get_axes(cornersA) + get_axes(cornersB)
        for axis in axes:
            ax_ = axis[0]; ay_ = axis[1]
            minA = min(p[0]*ax_ + p[1]*ay_ for p in cornersA)
            maxA = max(p[0]*ax_ + p[1]*ay_ for p in cornersA)
            minB = min(p[0]*ax_ + p[1]*ay_ for p in cornersB)
            maxB = max(p[0]*ax_ + p[1]*ay_ for p in cornersB)
            if maxA < minB + 1e-12 or maxB < minA + 1e-12:
                return False
        return True

    def inside(s):
        x, y, a, sz = s
        r = sz * math.sqrt(2) / 2
        if x - r < -1e-9 or x + r > 1 + 1e-9: return False
        if y - r < -1e-9 or y + r > 1 + 1e-9: return False
        # more precise: check corners
        ar = a * 2 * math.pi
        c, sn = math.cos(ar), math.sin(ar)
        half = sz * 0.5
        for sx, sy in [(-1,-1),(1,-1),(1,1),(-1,1)]:
            px = x + half * (sx * c - sy * sn)
            py = y + half * (sx * sn + sy * c)
            if px < -1e-9 or px > 1+1e-9 or py < -1e-9 or py > 1+1e-9:
                return False
        return True

    def local_optimize(sqs, iterations=800):
        sqs = [list(s) for s in sqs]
        cur_score = score(sqs)
        for it in range(iterations):
            i = random.randrange(len(sqs))
            s = sqs[i]
            # try to increase size
            delta = random.uniform(-0.03, 0.06)
            new_sz = max(0.0, min(1.0, s[3] + delta))
            new_x = s[0] + random.uniform(-0.03, 0.03)
            new_y = s[1] + random.uniform(-0.03, 0.03)
            new_a = s[2] + random.uniform(-0.05, 0.05)
            cand = [new_x, new_y, new_a, new_sz]
            if not inside(cand):
                continue
            ok = True
            for j in range(len(sqs)):
                if i != j and overlaps(cand, sqs[j]):
                    ok = False
                    break
            if ok:
                old = sqs[i]
                sqs[i] = cand
                ns = score(sqs)
                if ns >= cur_score - 1e-9:
                    cur_score = ns
                else:
                    sqs[i] = old
        return sqs, cur_score

    # Try multiple restarts
    random.seed(12345)
    best_score = score(best)
    best_sqs = best
    for trial in range(8 if n <= 30 else 4):
        if trial == 0:
            cur = [list(s) for s in best]
        else:
            cur = []
            for _ in range(n):
                sz = random.uniform(0.02, 0.2)
                cur.append([random.uniform(sz/2, 1-sz/2), random.uniform(sz/2, 1-sz/2), random.uniform(0,1), sz])
        # quick repair: remove overlaps by shrinking
        for _ in range(30):
            for i in range(len(cur)):
                for j in range(i+1, len(cur)):
                    if overlaps(cur[i], cur[j]):
                        # shrink both a bit
                        for idx in (i, j):
                            cur[idx][3] *= 0.9
        cur, sc = local_optimize(cur, iterations=1000 if n <= 30 else 600)
        if sc > best_score:
            best_score = sc
            best_sqs = cur

    # final check: ensure all inside
    final = []
    for s in best_sqs:
        x, y, a, sz = s
        # clamp to be safe
        sz = max(0.0, min(1.0, sz))
        a = a % 1.0
        # ensure inside
        ar = a * 2 * math.pi
        c, sn = math.cos(ar), math.sin(ar)
        half = sz * 0.5
        maxr = half * (abs(c)+abs(sn))  # half-width in x or y at most
        x = max(maxr, min(1-maxr, x))
        y = max(maxr, min(1-maxr, y))
        final.append((x, y, a, sz))
    # pad with zeros if needed
    while len(final) < n:
        final.append((0.5, 0.5, 0.0, 0.0))
    return final[:n]
