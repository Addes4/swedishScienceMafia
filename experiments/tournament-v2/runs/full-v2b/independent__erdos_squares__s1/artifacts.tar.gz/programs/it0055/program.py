import math

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # Two squares can both be nearly full size if rotated 45 degrees? Let's just split horizontally.
        s = 0.5
        return [(0.25, 0.5, 0.0, s), (0.75, 0.5, 0.0, s)]
    # k x k grid for the main part
    k = math.isqrt(n)
    if k * k == n:
        s = 1.0 / k
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    # n not a perfect square: use k x (k+1) or similar? Let's try a row-based packing.
    # Try to find best a,b such that a*b <= n and use rotated squares in leftover.
    # First, try axis-aligned grid a x b with a*b <= n maximizing total side.
    best = None
    best_score = -1
    for a in range(1, n+1):
        for b in range(1, n+1):
            if a * b <= n:
                # axis-aligned squares of side min(1/a, 1/b) to fit in unit square?
                # Actually we can fit a x b grid with side s = min(1/a, 1/b) if we use the whole square.
                # Better: let s = min(1/a, 1/b). Place a along x, b along y.
                s = min(1.0/a, 1.0/b)
                total = a * b * s
                if total > best_score:
                    best_score = total
                    best = (a, b, s)
    a, b, s = best
    # Fill the a x b grid centered, leaving strips.
    squares = []
    for i in range(a):
        for j in range(b):
            x = (i + 0.5) * s + (1 - a*s)/2
            y = (j + 0.5) * s + (1 - b*s)/2
            squares.append((x, y, 0.0, s))
    # If we still lack squares, we can try to add rotated squares in leftover strips.
    # For simplicity, add zero-size for the rest.
    # But maybe we can do better: use 45-degree rotated squares in the leftover region.
    # Let's attempt adding some rotated squares in the leftover strips.
    rem = n - a * b
    if rem > 0:
        # Try to fill leftover area with rotated squares of side t where t is maximized.
        # If strip width w = 1 - a*s (if a*s < 1) or height h = 1 - b*s.
        # We'll just add zero-sized for now, but let's try to improve with a simple heuristic:
        # Place rotated squares along the longer leftover strip.
        # Compute leftover widths:
        w = 1.0 - a * s
        h = 1.0 - b * s
        # If w > h, leftover is vertical strip on right? Actually we centered, so gaps on both sides.
        # Let's not overcomplicate; use zero-size.
        for _ in range(rem):
            squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
