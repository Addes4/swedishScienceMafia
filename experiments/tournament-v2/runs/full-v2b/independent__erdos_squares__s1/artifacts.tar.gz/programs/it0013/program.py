import math
import random
import numpy as np


def solve(n):
    """Place n non-overlapping squares in the unit square maximising total side length."""
    rng = random.Random(12345 + n)
    np.random.seed(1000 + n)

    # Start with the best regular grid: k x k squares of side 1/k, plus tiny leftovers.
    k = int(math.isqrt(n))
    base = []
    s = 1.0 / k
    for i in range(k):
        for j in range(k):
            base.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
    # Remaining squares: put them as zero-size at centre (valid).
    while len(base) < n:
        base.append([0.5, 0.5, 0.0, 0.0])
    base = base[:n]

    # If n is a perfect square, grid is optimal-ish; still try to improve by splitting.
    # For general n we try to replace some grid squares with a slightly larger set
    # using local optimisation of squares in the free region.

    def is_valid(sqs):
        # Quick overlap check using separating axis theorem for rotated squares.
        polys = []
        for (cx, cy, a, side) in sqs:
            if side <= 1e-12:
                polys.append(None)
                continue
            ang = 2.0 * math.pi * a
            c, sn = math.cos(ang), math.sin(ang)
            hs = side * 0.5
            # corners
            pts = []
            for (sx, sy) in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                x = cx + (c * sx - sn * sy) * hs
                y = cy + (sn * sx + c * sy) * hs
                pts.append((x, y))
            # bounds
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            if min(xs) < -1e-9 or max(xs) > 1 + 1e-9 or min(ys) < -1e-9 or max(ys) > 1 + 1e-9:
                return False
            polys.append(pts)
        for i in range(len(polys)):
            if polys[i] is None:
                continue
            for j in range(i + 1, len(polys)):
                if polys[j] is None:
                    continue
                if polys_overlap(polys[i], polys[j]):
                    return False
        return True

    def polys_overlap(A, B):
        # SAT for convex polygons
        for poly in (A, B):
            m = len(poly)
            for i in range(m):
                x1, y1 = poly[i]
                x2, y2 = poly[(i + 1) % m]
                nx, ny = -(y2 - y1), (x2 - x1)
                # project both
                amin = min(px * nx + py * ny for px, py in A)
                amax = max(px * nx + py * ny for px, py in A)
                bmin = min(px * nx + py * ny for px, py in B)
                bmax = max(px * nx + py * ny for px, py in B)
                if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
                    return False
        return True

    best = [list(x) for x in base]
    best_score = sum(x[3] for x in best)

    # Local search: perturb positions/angles/sizes of all squares, keep improvements.
    cur = [list(x) for x in base]
    cur_score = best_score

    iters = 3000 if n <= 64 else 800
    for it in range(iters):
        idx = rng.randrange(n)
        trial = [list(x) for x in cur]
        sz = trial[idx][3]
        # Decide move type
        r = rng.random()
        if r < 0.45:
            # adjust size
            delta = rng.uniform(-0.06, 0.06) * (1.0 / k)
            new_sz = max(0.0, sz + delta)
            trial[idx][3] = new_sz
        elif r < 0.7:
            # move centre
            trial[idx][0] += rng.uniform(-0.05, 0.05) * (1.0 / k)
            trial[idx][1] += rng.uniform(-0.05, 0.05) * (1.0 / k)
            trial[idx][0] = min(1.0, max(0.0, trial[idx][0]))
            trial[idx][1] = min(1.0, max(0.0, trial[idx][1]))
        else:
            # rotate
            trial[idx][2] = (trial[idx][2] + rng.uniform(-0.1, 0.1)) % 1.0

        if is_valid(trial):
            ns = sum(x[3] for x in trial)
            if ns > cur_score - 1e-12:
                cur = trial
                cur_score = ns
                if ns > best_score:
                    best = [list(x) for x in trial]
                    best_score = ns

    # Final polish: try to grow each square individually
    improved = True
    passes = 0
    while improved and passes < 30:
        improved = False
        passes += 1
        for idx in range(n):
            trial = [list(x) for x in best]
            sz = trial[idx][3]
            new_sz = sz + 1e-3
            trial[idx][3] = new_sz
            if is_valid(trial):
                ns = sum(x[3] for x in trial)
                if ns > best_score:
                    best = trial
                    best_score = ns
                    improved = True

    return [tuple(x) for x in best]


# Helper used by is_valid inside solve; define at module level too
def polys_overlap(A, B):
    for poly in (A, B):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            nx, ny = -(y2 - y1), (x2 - x1)
            amin = min(px * nx + py * ny for px, py in A)
            amax = max(px * nx + py * ny for px, py in A)
            bmin = min(px * nx + py * ny for px, py in B)
            bmax = max(px * nx + py * ny for px, py in B)
            if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
                return False
    return True
