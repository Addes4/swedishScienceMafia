import math
import random

# Use a deterministic seed for reproducibility (not required, but helps).
random.seed(12345)

def solve(n):
    """
    Returns n squares (centre_x, centre_y, angle, side) inside the unit square [0,1]x[0,1],
    with disjoint interiors. Maximises sum of side lengths.
    """

    # For small n, known optimal or near-optimal arrangements.
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # Two squares: best is 1x1? Actually two squares can be side 0.5 each side by side => sum=1.
        # But can we do better? Two squares of side 1 cannot fit because they'd overlap.
        # Max sum for 2 squares: each side 0.5 => 1.0. But could rotate? No, 2 squares total area <= 1, sum is maximized when equal? Actually sum of sides <= 2*sqrt(total area)? Let's just use 0.5 each.
        # But there is a better: two squares of side 0.5 placed side by side, sum=1.
        # Actually can we fit two squares of side 2/3? area 4/9 each total 8/9 < 1. Sum 4/3 ~1.333? Wait: side 2/3 each, two of them area = 2*(4/9)=8/9 <1. Can they fit? side 2/3, two squares side by side would need width 4/3 >1. So no.
        # The best for 2: we can fit one square of side 1, and the other side 0? No.
        # Actually two squares can be arbitrarily close to side 0.5 each, sum 1. But maybe two squares of side 0.5 + epsilon? Two squares of side s: need 2s <= 1 in at least one dimension, so s<=0.5. So max sum = 1.0.
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # Arrange one square of side 0.5 on left, two of side 0.25 stacked on right? Sum = 1.0? Actually 0.5 + 0.25 + 0.25 = 1.0.
        # But maybe better: three squares of side 1/3 each in a row? sum = 1.0.
        # Can we do better? Three squares: one large, two small? 
        # The maximum sum for 3 squares is 1.0? Actually known result: max sum for n squares is sqrt(n)? No, for n=2 it's 1.0=sqrt(1)? Not exactly.
        # But we can try to find better via packing. Let's just use grid for now.
        pass

    # General approach: use a stochastic packing algorithm.

    # For performance, we use a constructive heuristic: 
    # Start with a k x k grid where k = floor(sqrt(n)), leaving leftover squares of size 0.
    # Then we try to improve by moving/growing squares.

    # But for many n, we can do better than grid: use "circle packing" style? 
    # Actually squares can be rotated, so we can pack them more efficiently.

    # We'll use a simple local search: 
    # 1. Initialize with grid (or random if n is small).
    # 2. Repeatedly pick a square, try to increase its size (or move it to a better spot)
    #    while maintaining feasibility (no overlaps, inside unit square).
    # 3. Use simulated annealing-like acceptance.

    # Since time limit is 60s, we can do many iterations.

    # We'll implement a fast overlap check using axis-aligned bounding boxes for rotated squares?
    # Actually for squares with arbitrary rotation, overlap check is SAT (separating axis theorem).
    # But we can simplify: for small angles, bounding boxes are close. 
    # We'll use SAT for correctness.

    def corners(cx, cy, angle, side):
        # returns 4 corners of square
        # angle is fraction of full turn (0.25=90 deg)
        rad = angle * 2 * math.pi
        c = math.cos(rad)
        s = math.sin(rad)
        h = side / 2.0
        # corners in local coords: (-h,-h), (h,-h), (h,h), (-h,h)
        pts = []
        for dx, dy in [(-h,-h), (h,-h), (h,h), (-h,h)]:
            x = cx + dx * c - dy * s
            y = cy + dx * s + dy * c
            pts.append((x,y))
        return pts

    def inside_unit_square(cx, cy, angle, side):
        pts = corners(cx, cy, angle, side)
        for x,y in pts:
            if x < -1e-9 or x > 1+1e-9 or y < -1e-9 or y > 1+1e-9:
                return False
        return True

    def overlap(sq1, sq2):
        # sq = (cx, cy, angle, side)
        # Use SAT for two convex polygons.
        # If one has side 0, no overlap.
        if sq1[3] < 1e-12 or sq2[3] < 1e-12:
            return False
        pts1 = corners(*sq1)
        pts2 = corners(*sq2)
        # Check all axes from both squares
        for pts in (pts1, pts2):
            for i in range(4):
                p1 = pts[i]
                p2 = pts[(i+1)%4]
                # edge vector
                ex = p2[0] - p1[0]
                ey = p2[1] - p1[1]
                # normal
                nx = -ey
                ny = ex
                # project both polygons onto normal
                def project(poly, nx, ny):
                    return [x*nx + y*ny for x,y in poly]
                proj1 = project(pts1, nx, ny)
                proj2 = project(pts2, nx, ny)
                if max(proj1) < min(proj2) - 1e-9 or max(proj2) < min(proj1) - 1e-9:
                    return False
        return True

    def all_overlaps(sqs, idx=None):
        # Check if any pair overlaps. If idx given, only check pairs involving idx.
        n = len(sqs)
        if idx is not None:
            for j in range(n):
                if j == idx:
                    continue
                if overlap(sqs[idx], sqs[j]):
                    return True
            return False
        else:
            for i in range(n):
                for j in range(i+1, n):
                    if overlap(sqs[i], sqs[j]):
                        return True
            return False

    def total_sum(sqs):
        return sum(sq[3] for sq in sqs)

    # Initial configuration: grid
    best_sqs = None
    best_score = -1.0

    # Try multiple random initializations
    for trial in range(5):
        # Grid initialization
        k = int(math.sqrt(n))
        if k < 1:
            k = 1
        side = 1.0 / k
        sqs = []
        for i in range(k):
            for j in range(k):
                if len(sqs) < n:
                    cx = (i + 0.5) * side
                    cy = (j + 0.5) * side
                    sqs.append([cx, cy, 0.0, side])
        # leftover squares
        while len(sqs) < n:
            sqs.append([0.5, 0.5, 0.0, 0.0])
        # If grid is too large? Actually we only take first n squares, but we might have more than n from grid? We break when len(sqs)==n.
        # But we might not fill all grid cells if n is not perfect square. That's fine.

        # Ensure all squares are inside unit square (they are by construction).
        # Now local search: we will try to increase sizes and adjust positions.
        # Use a simple greedy improvement: for each square, try to increase its side by a small amount,
        # then resolve overlaps by moving smaller squares.
        # This is complex; instead, we'll use a randomized approach: perturb positions and sizes, accept if feasible and improves sum.

        # We'll do a fixed number of iterations.
        curr_sqs = [list(sq) for sq in sqs]
        curr_score = total_sum(curr_sqs)

        # If n is large, many squares, local search may be slow. We limit iterations based on n.
        iters = max(1000, 50000 // max(1, n))

        for it in range(iters):
            # Pick a random square to modify
            i = random.randrange(n)
            sq = curr_sqs[i]
            # Try to increase size
            delta = random.uniform(0.0, 0.1) * (1.0 - sq[3])  # proportional to remaining space
            if delta < 1e-6:
                continue
            new_side = sq[3] + delta
            if new_side > 1.0:
                new_side = 1.0
            # Try new position too
            new_cx = sq[0] + random.uniform(-0.05, 0.05)
            new_cy = sq[1] + random.uniform(-0.05, 0.05)
            new_angle = sq[2] + random.uniform(-0.01, 0.01)
            # Keep inside unit square
            if not inside_unit_square(new_cx, new_cy, new_angle, new_side):
                continue
            # Check overlap with others (excluding itself)
            new_sq = [new_cx, new_cy, new_angle, new_side]
            # Temporarily replace
            old_sq = curr_sqs[i]
            curr_sqs[i] = new_sq
            # Check overlaps
            if not all_overlaps(curr_sqs, i):
                # Feasible, accept if score improves or with some probability (simulated annealing)
                new_score = total_sum(curr_sqs)
                if new_score > curr_score or random.random() < 0.01:
                    curr_score = new_score
                else:
                    # revert
                    curr_sqs[i] = old_sq
            else:
                # revert
                curr_sqs[i] = old_sq

        # After local search, try to shrink squares that are too large? Not needed.
        # Update best
        if curr_score > best_score:
            best_score = curr_score
            best_sqs = [list(sq) for sq in curr_sqs]

    # Ensure all angles are in [0,1] and sides >=0
    result = []
    for sq in best_sqs:
        cx, cy, angle, side = sq
        # clamp
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        angle = angle % 1.0
        side = max(0.0, min(1.0, side))
        result.append((cx, cy, angle, side))
    return result
