import math
import random

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_score = -1.0
    random.seed(12345 + n)

    def inside_square(cx, cy, ang, s):
        # bounding box check for rotated square
        half = s * 0.5
        c = math.cos(2 * math.pi * ang)
        ssin = math.sin(2 * math.pi * ang)
        # extent in x and y
        ex = abs(c) * half + abs(ssin) * half
        ey = abs(ssin) * half + abs(c) * half
        return cx - ex >= -1e-12 and cx + ex <= 1 + 1e-12 and cy - ey >= -1e-12 and cy + ey <= 1 + 1e-12

    def overlap(a, b):
        # strict interior overlap test using separating axis theorem for two squares
        (x1, y1, t1, s1) = a
        (x2, y2, t2, s2) = b
        if s1 <= 0 or s2 <= 0:
            return False
        ang1 = 2 * math.pi * t1
        ang2 = 2 * math.pi * t2
        c1, s1_ = math.cos(ang1), math.sin(ang1)
        c2, s2_ = math.cos(ang2), math.sin(ang2)
        # centers difference
        dx = x2 - x1
        dy = y2 - y1
        # axes: normals of both squares (2 each)
        eps = 1e-12
        axes = [(c1, s1_), (-s1_, c1), (c2, s2_), (-s2_, c2)]
        for ax, ay in axes:
            # projection radius on axis for square1
            r1 = 0.5 * s1 * (abs(c1 * ax + s1_ * ay) + abs(-s1_ * ax + c1 * ay))
            # for square2 need axes of square2 relative to its own orientation
            r2 = 0.5 * s2 * (abs(c2 * ax + s2_ * ay) + abs(-s2_ * ax + c2 * ay))
            dist = abs(dx * ax + dy * ay)
            if dist >= r1 + r2 - eps:
                return False
        return True

    def total_score(sqs):
        return sum(q[3] for q in sqs)

    def normalize(sqs):
        # keep only valid and clamp
        res = []
        for q in sqs:
            cx, cy, ang, s = q
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
            ang = ang % 1.0
            s = max(0.0, min(s, 1.0))
            if not inside_square(cx, cy, ang, s):
                s = 0.0
            res.append((cx, cy, ang, s))
        # enforce disjointness by shrinking overlapping ones
        changed = True
        while changed:
            changed = False
            for i in range(len(res)):
                for j in range(i + 1, len(res)):
                    if overlap(res[i], res[j]):
                        # shrink larger one
                        si = res[i][3]
                        sj = res[j][3]
                        if si >= sj:
                            cx, cy, ang, s = res[i]
                            s *= 0.9
                            res[i] = (cx, cy, ang, s)
                        else:
                            cx, cy, ang, s = res[j]
                            s *= 0.9
                            res[j] = (cx, cy, ang, s)
                        changed = True
                        break
                if changed:
                    break
        return res

    def initial_grid(n):
        k = int(math.sqrt(n))
        if k < 1:
            k = 1
        side = 1.0 / k
        squares = []
        for i in range(k):
            for j in range(k):
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        # remaining as zero
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        return squares[:n]

    def initial_random(n):
        sqs = []
        for _ in range(n):
            cx = random.random()
            cy = random.random()
            ang = random.random()
            s = random.random() * 0.2
            sqs.append((cx, cy, ang, s))
        return normalize(sqs)

    def try_improve(sqs, iterations=2000):
        sqs = [list(q) for q in sqs]
        score = total_score(sqs)
        for it in range(iterations):
            improved = False
            idxs = list(range(n))
            random.shuffle(idxs)
            for i in idxs:
                cx, cy, ang, s = sqs[i]
                # try grow
                step = min(0.02, 0.5 * (1.0 - s) + 0.001)
                for _ in range(5):
                    ns = s + step * random.random()
                    # random small shift/rotate
                    ncx = cx + (random.random() - 0.5) * step
                    ncy = cy + (random.random() - 0.5) * step
                    nang = (ang + (random.random() - 0.5) * 0.1) % 1.0
                    if not inside_square(ncx, ncy, nang, ns):
                        continue
                    cand = (ncx, ncy, nang, ns)
                    ok = True
                    for j in range(n):
                        if j == i:
                            continue
                        if overlap(cand, sqs[j]):
                            ok = False
                            break
                    if ok:
                        sqs[i] = [ncx, ncy, nang, ns]
                        improved = True
                        break
            if not improved:
                break
        return [tuple(q) for q in sqs]

    # multi-start
    starts = []
    starts.append(initial_grid(n))
    for _ in range(2):
        starts.append(initial_random(n))

    for st in starts:
        cand = try_improve(st, iterations=1500)
        sc = total_score(cand)
        if sc > best_score:
            best_score = sc
            best = cand

    # final normalize
    best = normalize(best)
    # pad if needed
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
