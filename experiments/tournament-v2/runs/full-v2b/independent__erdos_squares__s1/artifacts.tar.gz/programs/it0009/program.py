import math
import random
import numpy as np
from scipy.optimize import minimize


def _rect_pack_layout(n, k, beta):
    """
    Place n axis-aligned squares.
    Use k full rows of k squares, plus one extra row of m = n - k*k squares.
    All squares in full rows have side beta, extra row maybe same or different.
    Heights chosen so total height = 1.
    """
    m = n - k * k
    if m < 0:
        return None
    if m == 0:
        # k x k grid with side 1/k
        s = 1.0 / k
        return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    # k full rows + 1 partial row
    # full row height hf, partial row height hp, squares widths must fit.
    # full squares side beta <= hf and k*beta <= 1 => beta <= 1/k
    # partial squares side gamma <= hp and m*gamma <= 1
    # maximize sum = k*k*beta + m*gamma
    # Height: k*hf + hp = 1. Put beta = hf (full squares fill row height),
    # gamma = hp (partial squares fill extra row height). Then beta constrained <= 1/k.
    # Maximize f = k*k*beta + m*(1 - k*beta), with beta in [max(0,(1-1/m)/k)?...]
    # gamma <= 1/m and beta <= 1/k, beta >= 0, gamma = 1 - k*beta >= 0 => beta <= 1/k.
    # f = k*k*beta + m - m*k*beta = m + k*(k-m)*beta.
    # If k > m: increase beta => best beta = min(1/k, ...). gamma constraint:
    #   gamma <= 1/m => 1 - k beta <= 1/m => beta >= (1 - 1/m)/k.
    #   also beta <= 1/k.
    # We want gamma as large as possible? f increasing in beta if k>m.
    # So best beta = 1/k, gamma = 1 - 1 = 0, no good.
    # Reconsider: maybe partial row uses width fully: m*gamma <= 1 miss.
    # Actually we should not require square full row height exactly beta. Let full
    # row have height hf >= beta and partial row height hp >= gamma.
    # Tight: hf=beta, hp=gamma. Constraint k*beta + gamma = 1. Then:
    # f = k^2 beta + m gamma. With gamma = 1 - k beta:
    # f = k^2 beta + m(1 - k beta) = m + k(k - m) beta.
    # beta constraints: 0<=beta<=1/k, k*beta<=1, gamma<=1/m => 1-k beta <= 1/m.
    # if m<k: coefficient positive, maximize beta. Max beta = min(1/k, (1-1/m)/k if m>1 else 1/k)
    #   For m>1: (1-1/m)/k < 1/k. Need beta >= that lower bound. Max at 1/k => coeff positive so beta=1/k gives f=m too? wait max beta = 1/k gives gamma=0, f = k^2/k = k.
    # Hmm f = m + k(k-m)*beta at beta=1/k = m + (k-m) = k. And at beta=0 f=m.
    # For k>m, k>m: f increasing in beta, best beta = 1/k -> gamma=0 -> sum k (grid), that's k^2*(1/k)=k.
    # If m>k, coefficient negative, minimize beta. min beta = (1-1/m)/k. f = m + k(k-m)(1-1/m)/k = m + (k-m)(1-1/m).
    #   = m + (k-m) - (k-m)/m = k - (k-m)/m.
    # gamma = 1/m. sum = k*k*beta + m*(1/m) = k^2*(1-1/m)/k + 1 = k(1-1/m)+1 = k - k/m + 1.
    #   = k + 1 - k/m. Compare my formula k - (k-m)/m = k - k/m + 1. same.
    # So best when m>k: beta=(1-1/m)/k, gamma=1/m.
    # when m<k: best is grid plus zero squares? Actually f max = k, at beta=1/k, gamma=0.
    # But there may be better with partial row height 0 and squares side 0... plus slack.
    # Let's also allow full rows not full height to allow bigger squares? no, beta<=hf.
    # For m<k, alternative: make beta smaller so gamma bigger with negative coeff? For m<k coeff positive, so shrink beta reduces f. best beta=1/k.
    # Wait for m<k, coeff k(k-m)>0 so larger beta better; max beta=1/k, gamma=0.
    # But then we can use width: m squares of side 0 fill; maybe instead put m squares in partial row with side 1/m and rows above side (1-1/m)/k? That means beta=(1-1/m)/k, gamma=1/m. f = k^2*(1-1/m)/k + m*(1/m) = k(1-1/m)+1 = k+1-k/m. For m<k this is < k, worse than k. ok.
    # So only improvement when m>k, i.e. need more squares than grid. Good.
    # Actually can also consider k+1 grid with n < (k+1)^2: n = (k+1)^2 - t squares.
    # Let K=k+1, fill K rows: K^2 squares, remove t. Use K-1 full rows + partial? Complicated.
    # We'll also try: use K = ceil(sqrt(n)). Fill K rows but last row has fewer squares.
    return None


def _layout_rows_counts(n):
    """Try several row decompositions: choose number of columns r, rows fill with r squares,
    one partial row with m squares. Return best list or None."""
    best = None
    best_score = -1.0
    for r in range(1, n + 1):
        rows_full = n // r
        m = n - rows_full * r
        if rows_full == 0:
            # one partial row only: m=n squares, side 1/n (width) and height 1/n? or side 1
            # n squares in a row: side 1/n each, height 1/n. sum = 1.
            # But could be one square side 1 with n-1 zeros: sum 1.
            s = 1.0 / r if r <= n else 1.0
            if best is None or 1.0 > best_score:
                best_score = 1.0
        # full rows side beta in [0,1/r], partial row gamma in [0,1/m] if m>0
        # Height: rows_full*beta + (gamma if m>0 else 0) = 1
        if m == 0:
            beta = 1.0 / rows_full
            beta = min(beta, 1.0 / r)
            # sum = n*beta
            score = n * beta
            if score > best_score:
                best_score = score
                best = ('uniform', r, rows_full, beta)
        else:
            # choose beta maximizing f = rows_full*r*beta + m*gamma, gamma=1-rows_full*beta
            # constraints 0<=beta<=1/r, 0<=gamma<=1/m, beta<=1.0/rows_full
            A = rows_full * r
            B = m
            C = rows_full
            # f = A*beta + B*(1 - C*beta) = B + (A - B*C)*beta
            coef = A - B * C
            lo = max(0.0, (1.0 - 1.0 / m) / C) if m > 1 else 0.0
            hi = min(1.0 / r, 1.0 / C)
            if lo > hi:
                continue
            if coef > 0:
                beta = hi
            elif coef < 0:
                beta = lo
            else:
                beta = hi
            gamma = 1.0 - C * beta
            if gamma < -1e-12:
                continue
            gamma = max(0.0, gamma)
            beta = min(beta, 1.0 / r)
            gamma = min(gamma, 1.0 / m)
            score = A * beta + B * gamma
            if score > best_score + 1e-12:
                best_score = score
                best = ('rows', r, rows_full, m, beta, gamma)
    return best, best_score


def _build_from_rows(best, n):
    kind = best[0]
    squares = []
    if kind == 'uniform':
        _, r, rows_full, beta = best
        # rows_full rows of r squares
        y = 0.0
        for j in range(rows_full):
            for i in range(r):
                if len(squares) >= n:
                    break
                squares.append(((i + 0.5) * beta * (1.0 if False else 1),
                                y + beta / 2, 0.0, beta))
            # x positions: centers at (i+0.5)*(width of row) but width = r*beta
            # Actually we placed with centers (i+0.5)*beta; row width r*beta <=1.
            # Center the row horizontally.
            y += beta
        # recenter each row: fix x
        # Let's rebuild properly.
        squares = []
        y = 0.0
        for j in range(rows_full):
            row_width = r * beta
            x0 = (1.0 - row_width) / 2
            for i in range(r):
                if len(squares) >= n:
                    break
                squares.append((x0 + (i + 0.5) * beta, y + beta / 2, 0.0, beta))
            y += beta
    else:
        _, r, rows_full, m, beta, gamma = best
        squares = []
        y = 0.0
        for j in range(rows_full):
            row_width = r * beta
            x0 = (1.0 - row_width) / 2
            for i in range(r):
                if len(squares) >= n:
                    break
                squares.append((x0 + (i + 0.5) * beta, y + beta / 2, 0.0, beta))
            y += beta
        if m > 0:
            row_width = m * gamma
            x0 = (1.0 - row_width) / 2
            for i in range(m):
                if len(squares) >= n:
                    break
                squares.append((x0 + (i + 0.5) * gamma, y + gamma / 2, 0.0, gamma))
        y += gamma
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _greedy_improve(squares, n, iters=200):
    """
    Greedy: try to expand each square by diminishing, pushing into gaps.
    Simple approach: repeatedly try to increase side of each zero/interior square.
    """
    sq = [list(s) for s in squares]
    # bounds check helper for axis aligned (angle 0)
    def fits(ax, ay, side, exclude):
        if ax - side / 2 < -1e-9 or ax + side / 2 > 1 + 1e-9:
            return False
        if ay - side / 2 < -1e-9 or ay + side / 2 > 1 + 1e-9:
            return False
        for i2, (bx, by, b, bs) in enumerate(sq):
            if i2 == exclude or bs <= 1e-12:
                continue
            if abs(b) > 1e-9:
                continue
            # axis aligned
            if (abs(ax - bx) < (side + bs) / 2 - 1e-12 and
                    abs(ay - by) < (side + bs) / 2 - 1e-12):
                return False
        return True

    for _ in range(iters):
        changed = False
        for i in range(n):
            x, y, ang, s = sq[i]
            if abs(ang) > 1e-9:
                continue
            # try to grow around center
            best_s = s
            best_pos = (x, y)
            # check current position with larger sizes
            step = 0.02
            for delta in [0.001, 0.002, 0.005, 0.01, 0.02, 0.05]:
                ns = s + delta
                if fits(x, y, ns, i):
                    best_s = ns
                    best_pos = (x, y)
                else:
                    break
            # try shifting in 8 directions to grow
            for dx in [-0.02, -0.01, -0.005, 0.0, 0.005, 0.01, 0.02]:
                for dy in [-0.02, -0.01, -0.005, 0.0, 0.005, 0.01, 0.02]:
                    if dx == 0 and dy == 0:
                        continue
                    nx, ny = x + dx, y + dy
                    if nx - s / 2 < 0 or nx + s / 2 > 1 or ny - s / 2 < 0 or ny + s / 2 > 1:
                        continue
                    if fits(nx, ny, s + 0.005, i):
                        if s + 0.005 > best_s:
                            best_s = s + 0.005
                            best_pos = (nx, ny)
                            changed = True
            if best_s > s + 1e-12:
                sq[i] = [best_pos[0], best_pos[1], ang, best_s]
        if not changed:
            break
    return [tuple(s) for s in sq]


def _try_rotate_fill(squares, n):
    """For zero-size slots, try placing a rotated square in leftover corner gaps."""
    sq = [list(s) for s in squares]
    for i in range(n):
        if sq[i][3] > 1e-9:
            continue
        # try angles
        best = None
        for ang in [0.0, 0.25, 0.125, 0.375, 0.0625, 0.1875, 0.3125, 0.4375]:
            # approximate fit: compute collision by sampling boundary
            # Use simple axis-aligned check for angle 0 only; for rotation,
            # use bounding approximations
            pass
        # try scanning positions
        best_s = 0.0
        best_pos = (0.5, 0.5)
        best_ang = 0.0
        for ang in [0.0, 0.25, 0.125, 0.375]:
            ca = math.cos(2 * math.pi * ang)
            sa = math.sin(2 * math.pi * ang)
            # bounding box half-extent for side s: s/2*(|ca|+|sa|)
            for gx in range(1, 20):
                for gy in range(1, 20):
                    px = gx / 20.0
                    py = gy / 20.0
                    # find max s that fits
                    lo, hi = 0.0, 0.5
                    for _ in range(15):
                        mid = (lo + hi) / 2
                        # check bounding box inside unit square
                        ex = mid / 2 * (abs(ca) + abs(sa))
                        if px - ex < -1e-9 or px + ex > 1 + 1e-9 or py - ex < -1e-9 or py + ex > 1 + 1e-9:
                            hi = mid
                            continue
                        # check against other squares roughly using bounding circles
                        ok = True
                        for j2, (bx, by, b, bs) in enumerate(sq):
                            if j2 == i or bs <= 1e-12:
                                continue
                            if abs(b - ang) < 1e-9:
                                # same orientation: use SAT-ish approximate axis-aligned in rotated frame
                                # project centers
                                dx = px - bx
                                dy = py - by
                                # distance along square axes
                                d1 = dx * ca + dy * sa
                                d2 = -dx * sa + dy * ca
                                if abs(d1) < (mid + bs) / 2 - 1e-9 and abs(d2) < (mid + bs) / 2 - 1e-9:
                                    ok = False
                                    break
                            else:
                                # bounding circle conservative
                                r1 = mid * 0.7071067811865476
                                r2 = bs * 0.7071067811865476
                                if (px - bx) ** 2 + (py - by) ** 2 < (r1 + r2) ** 2 - 1e-9:
                                    # might overlap, conservative reject
                                    ok = False
                                    break
                        if ok:
                            lo = mid
                        else:
                            hi = mid
                    s = lo
                    if s > best_s + 1e-9:
                        best_s = s
                        best_pos = (px, py)
                        best_ang = ang
        if best_s > 1e-6:
            sq[i] = [best_pos[0], best_pos[1], best_ang, best_s]
    return [tuple(s) for s in sq]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    # Try row layouts
    best_layout, best_score = _layout_rows_counts(n)
    squares = _build_from_rows(best_layout, n)
    squares = _greedy_improve(squares, n, iters=100)
    squares = _try_rotate_fill(squares, n)
    squares = _greedy_improve(squares, n, iters=50)

    # Normalize: clamp to valid range
    out = []
    for (x, y, a, s) in squares:
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        a = min(max(a, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        out.append((x, y, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
