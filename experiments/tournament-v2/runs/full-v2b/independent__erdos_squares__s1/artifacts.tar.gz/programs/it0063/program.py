import math


def _grid(n):
    k = math.isqrt(n)
    s = 1.0 / k
    return [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]


def _row(n, m, y, h, x0=0.0, w=1.0):
    # m equal squares in a horizontal strip of height h
    s = min(w / m, h)
    return [(x0 + (i + 0.5) * s, y + h / 2, 0.0, s) for i in range(m)]


def _col(n, m, x, w, y0=0.0, h=1.0):
    # m equal squares in a vertical strip of width w
    s = min(h / m, w)
    return [(x + w / 2, y0 + (i + 0.5) * s, 0.0, s) for i in range(m)]


def _pack_best(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.5, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 5:
        return [(0.2, 0.2, 0.0, 0.4), (0.6, 0.2, 0.0, 0.4),
                (0.4, 0.6, 0.0, 0.4), (0.2, 0.9, 0.0, 0.2), (0.8, 0.9, 0.0, 0.2)]

    best = None
    bestv = -1.0

    # Family A: k x k grid plus residual strip solutions.
    k = math.isqrt(n)
    base = _grid(k * k)
    r = n - k * k
    if r:
        s = 1.0 / k
        cand = base[:]
        if r <= k:
            cand += _row(r, r, 0.0, 1.0 - k * s, 0.0, 1.0)
        else:
            cand += _row(k, k, 0.0, 1.0 - k * s, 0.0, 1.0)
            cand += _row(r - k, r - k, 0.0, 1.0 - k * s, 0.0, 1.0)
        val = sum(q[3] for q in cand)
        if val > bestv:
            bestv, best = val, cand

    # Family B: (k+1) grid cells with one occupied by several small squares.
    for k in range(1, min(n, 12) + 1):
        if (k + 1) ** 2 < n:
            continue
        # Try to fit n by taking a (k+1) grid and subdividing one cell.
        cell = 1.0 / (k + 1)
        rooms = (k + 1) ** 2
        extra = n - rooms
        if extra < 0:
            # remove some grid cells and replace by a strip of remaining cells
            continue
        if extra == 0:
            cand = _grid(rooms)
        else:
            # put one dense block in top-left cell, using j x j subdivisions
            sub = extra + 1
            j = math.isqrt(sub)
            if j * j < sub:
                j += 1
            cs = cell / j
            cand = []
            for i in range(1, k + 1):
                for jj in range(1, k + 1):
                    cand.append(((i + 0.5) * cell, (jj + 0.5) * cell, 0.0, cell))
            for a in range(j):
                for b in range(j):
                    if len(cand) - (k * k) < extra:
                        cand.append(((a + 0.5) * cs, (b + 0.5) * cs, 0.0, cs))
            cand = cand[:n]
        val = sum(q[3] for q in cand)
        if val > bestv:
            bestv, best = val, cand

    # Family C: one large square in a corner, remaining in strips.
    for big in [0.5, 0.45, 0.4, 0.35, 0.3]:
        rem = n - 1
        if rem <= 0:
            continue
        cand = [(big / 2, 1 - big / 2, 0.0, big)]
        # right vertical strip
        w = 1.0 - big
        cand += _col(rem, rem, big, w, 0.0, 1.0)[:rem]
        val = sum(q[3] for q in cand)
        if val > bestv:
            bestv, best = val, cand

    if best is None:
        best = base[:n] if len(base) >= n else base + [(0.5, 0.5, 0.0, 0.0)] * (n - len(base))
    if len(best) < n:
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side)."""
    if n <= 0:
        return []
    return _pack_best(n)
