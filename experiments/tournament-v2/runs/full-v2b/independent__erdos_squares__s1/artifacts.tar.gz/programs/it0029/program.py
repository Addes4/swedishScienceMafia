import math
import numpy as np
from scipy.optimize import minimize


def _grid_layout(n):
    """Start from the best square-ish grid, then greedily pack extras."""
    k = int(math.floor(math.sqrt(n)))
    squares = []
    side = 1.0 / k
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    extra = n - k * k
    if extra == 0:
        return squares

    # Number of grid cells we keep; use k x k grid then insert extras by
    # shrinking all grid squares slightly and placing extras in the gaps.
    # Simpler robust approach: use k x k grid for max(k*k, n) cells but with k+1
    # cells in one dimension if possible. Try both and pick best sum.
    candidates = []

    # Option A: (k+1) columns x k rows grid for all n using same side
    for cols in (k + 1, k, k + 2):
        rows = int(math.ceil(n / cols))
        if rows == 0:
            continue
        s = min(1.0 / cols, 1.0 / rows)
        cnt = cols * rows
        if cnt < n:
            continue
        arr = []
        idx = 0
        for j in range(rows):
            for i in range(cols):
                if idx >= n:
                    break
                arr.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
                idx += 1
            if idx >= n:
                break
        candidates.append(arr)

    # Option B: keep k x k grid of side s, and put extras as tiny squares in
    # remaining margins.
    for cols in (k + 1, k, k + 2):
        rows = int(math.ceil(n / cols))
        if rows == 0:
            continue
        s = min(1.0 / cols, 1.0 / rows)
        cnt = cols * rows
        if cnt < n:
            continue
        arr = []
        idx = 0
        for j in range(rows):
            for i in range(cols):
                if idx >= n:
                    break
                arr.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
                idx += 1
            if idx >= n:
                break
        candidates.append(arr)

    # Ensure lengths match n
    cleaned = []
    for arr in candidates:
        if len(arr) == n:
            cleaned.append(arr)
        elif len(arr) > n:
            cleaned.append(arr[:n])
    if not cleaned:
        cleaned = [squares + [[0.5, 0.5, 0.0, 0.0]] * extra]
    return cleaned


def _signed_distance_squares(p1, p2):
    """Approximate separation between two rotated squares given parameter vectors.

    Each square param: cx, cy, angle_fraction, side.
    Returns positive if separated by margin, negative if overlapping.
    Uses polygon SAT distance for the 2D case in a differentiable-ish manner
    only via the final geometry evaluation.
    """
    cx1, cy1, a1, s1 = p1
    cx2, cy2, a2, s2 = p2
    if s1 <= 0 or s2 <= 0:
        return 1.0
    ang1 = a1 * 2.0 * math.pi
    ang2 = a2 * 2.0 * math.pi
    c1, sn1 = math.cos(ang1), math.sin(ang1)
    c2, sn2 = math.cos(ang2), math.sin(ang2)

    # Half-extents
    h1 = s1 * 0.5
    h2 = s2 * 0.5

    # Vertices of square 1
    verts1 = []
    for dx, dy in ((-h1, -h1), (h1, -h1), (h1, h1), (-h1, h1)):
        x = cx1 + dx * c1 - dy * sn1
        y = cy1 + dx * sn1 + dy * c1
        verts1.append((x, y))
    verts2 = []
    for dx, dy in ((-h2, -h2), (h2, -h2), (h2, h2), (-h2, h2)):
        x = cx2 + dx * c2 - dy * sn2
        y = cy2 + dx * sn2 + dy * c2
        verts2.append((x, y))

    # SAT separation distance: max over axes of separation along that axis
    axes = []
    for v in (verts1, verts2):
        for i in range(4):
            x1, y1 = v[i]
            x2, y2 = v[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 1e-12:
                axes.append((-ey / ln, ex / ln))

    best_gap = -1e18
    # We want the minimal translation to separate: equivalently maximum over
    # axes of overlap (negative => gap)
    min_overlap = 1e18
    for ax, ay in axes:
        p1_vals = [vx * ax + vy * ay for vx, vy in verts1]
        p2_vals = [vx * ax + vy * ay for vx, vy in verts2]
        lo1, hi1 = min(p1_vals), max(p1_vals)
        lo2, hi2 = min(p2_vals), max(p2_vals)
        # overlap along this axis (positive means overlapping intervals)
        overlap = min(hi1, hi2) - max(lo1, lo2)
        if overlap < min_overlap:
            min_overlap = overlap
    return -min_overlap  # positive means separated (gap), negative means overlap


def _pack(n, seed_squares, time_budget=25.0):
    """Local continuous optimization with scipy."""
    m = len(seed_squares)
    # parameter vector: cx, cy, angle, side for each square
    x0 = np.array(seed_squares, dtype=float).ravel()

    def unpack(x):
        return x.reshape(m, 4)

    def objective(x):
        p = unpack(x)
        return -np.sum(p[:, 3])

    def constraint_bounds(x):
        p = unpack(x)
        pen = []
        # within unit square: vertices inside means centre within [0,1] offset
        # approximate: keep centre in [0.5*side*1.42, 1-...] but easier:
        # enforce a soft bound via constraints on centre and size.
        return p

    cons = []

    # Keep centres in [0,1]
    for i in range(m):
        def make_lo(i):
            return lambda x: unpack(x)[i, 0] - 0.0
        def make_hi(i):
            return lambda x: 1.0 - unpack(x)[i, 0]
        cons.append({'type': 'ineq', 'fun': make_lo(i)})
        cons.append({'type': 'ineq', 'fun': make_hi(i)})
        def make_ylo(i):
            return lambda x: unpack(x)[i, 1] - 0.0
        def make_yhi(i):
            return lambda x: 1.0 - unpack(x)[i, 1]
        cons.append({'type': 'ineq', 'fun': make_ylo(i)})
        cons.append({'type': 'ineq', 'fun': make_yhi(i)})
        # side >= 0
        cons.append({'type': 'ineq', 'fun': (lambda i: (lambda x: unpack(x)[i, 3]))(i)})

    # Containment: every vertex of every square inside [0,1]^2
    for i in range(m):
        def make_vertex_cons(i, sign_dx, sign_dy):
            def f(x):
                p = unpack(x)[i]
                cx, cy, a, s = p
                h = s * 0.5
                ang = a * 2.0 * math.pi
                c, sn = math.cos(ang), math.sin(ang)
                dx, dy = sign_dx * h, sign_dy * h
                vx = cx + dx * c - dy * sn
                vy = cy + dx * sn + dy * c
                # want 0 <= vx <= 1 and 0 <= vy <= 1
                return min(vx, 1.0 - vx, vy, 1.0 - vy)
            return f
        for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            cons.append({'type': 'ineq', 'fun': make_vertex_cons(i, sx, sy)})

    # Non-overlap for all pairs (skip zero-size)
    for i in range(m):
        for j in range(i + 1, m):
            def make_pair(i, j):
                def f(x):
                    p = unpack(x)
                    si, sj = p[i, 3], p[j, 3]
                    if si <= 1e-9 or sj <= 1e-9:
                        return 1.0
                    return _signed_distance_squares(p[i], p[j])
                return f
            cons.append({'type': 'ineq', 'fun': make_pair(i, j)})

    # Bounds for variables
    lb = np.zeros(m * 4)
    ub = np.ones(m * 4)
    # side upper bounded by 1
    for i in range(m):
        ub[i * 4 + 3] = 1.0
        lb[i * 4 + 3] = 0.0

    # Initial feasibility check (allow tiny violations)
    try:
        res = minimize(objective, x0, method='SLSQP', bounds=list(zip(lb, ub)),
                       constraints=cons, options={'maxiter': 500, 'ftol': 1e-9})
    except Exception:
        res = None

    if res is None or not np.all(np.isfinite(res.x)):
        return seed_squares

    p = unpack(res.x)
    out = []
    for row in p:
        cx, cy, a, s = row
        s = max(0.0, float(s))
        a = float(a) % 1.0
        cx = min(1.0, max(0.0, float(cx)))
        cy = min(1.0, max(0.0, float(cy)))
        out.append((cx, cy, a, s))
    return out


def _clean_result(squares):
    """Final sanitization: ensure disjoint, inside, and adjust to maximize sum."""
    n = len(squares)
    out = []
    for (cx, cy, a, s) in squares:
        s = max(0.0, min(1.0, float(s)))
        cx = min(1.0, max(0.0, float(cx)))
        cy = min(1.0, max(0.0, float(cy)))
        a = float(a) % 1.0
        if s <= 1e-12:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        # shrink until it fits inside bounds
        h = s * 0.5
        ang = a * 2.0 * math.pi
        c, sn = math.cos(ang), math.sin(ang)
        maxext = max(abs(c) * h + abs(sn) * h, abs(sn) * h + abs(c) * h)
        if cx - maxext < -1e-12 or cx + maxext > 1 + 1e-12 or cy - maxext < -1e-12 or cy + maxext > 1 + 1e-12:
            # shrink to fit
            max_half = min(cx, 1 - cx, cy, 1 - cy)
            s = min(s, 2 * max_half / max(abs(c) + abs(sn), 1e-12))
        out.append((cx, cy, a, max(0.0, s)))

    # Resolve any residual overlaps by shrinking offenders
    for _ in range(6):
        changed = False
        for i in range(n):
            if out[i][3] <= 0:
                continue
            for j in range(i + 1, n):
                if out[j][3] <= 0:
                    continue
                gap = _signed_distance_squares(out[i], out[j])
                if gap < -1e-9:
                    # shrink both slightly
                    si = out[i][3]
                    sj = out[j][3]
                    shrink = max(0.5, 1.0 - 0.1 * (-gap) / max(si + sj, 1e-9))
                    ci = out[i]
                    cj = out[j]
                    out[i] = (ci[0], ci[1], ci[2], si * 0.98)
                    out[j] = (cj[0], cj[1], cj[2], sj * 0.98)
                    changed = True
        if not changed:
            break

    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_score = -1.0

    seeds = _grid_layout(n)
    # Also include straightforward grid with zero extras
    k = int(math.floor(math.sqrt(n)))
    side = 1.0 / k
    base = [[(i + 0.5) * side, (j + 0.5) * side, 0.0, side] for i in range(k) for j in range(k)]
    while len(base) < n:
        base.append([0.5, 0.5, 0.0, 0.0])
    seeds = [base] + seeds

    seen = set()
    unique_seeds = []
    for s in seeds:
        if len(s) != n:
            continue
        key = tuple(tuple(round(x, 4) for x in row) for row in s)
        if key in seen:
            continue
        seen.add(key)
        unique_seeds.append(s)

    for seed in unique_seeds[:4]:
        try:
            res = _pack(n, seed)
            res = _clean_result(res)
            score = sum(r[3] for r in res)
            if score > best_score:
                best_score = score
                best = res
        except Exception:
            continue

    if best is None:
        best = _clean_result(base)
        if sum(r[3] for r in best) == 0 and n > 1:
            # fallback simple grid
            k = max(1, int(math.floor(math.sqrt(n))))
            s = 1.0 / k
            arr = []
            idx = 0
            for j in range(k):
                for i in range(k):
                    if idx >= n:
                        break
                    arr.append((i * s + s / 2, j * s + s / 2, 0.0, s))
                    idx += 1
                if idx >= n:
                    break
            while len(arr) < n:
                arr.append((0.5, 0.5, 0.0, 0.0))
            best = arr[:n]

    return best[:n]
