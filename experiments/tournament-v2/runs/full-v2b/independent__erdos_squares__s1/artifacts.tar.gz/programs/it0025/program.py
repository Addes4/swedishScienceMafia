import math
import random
import time

# We use a fast approximate non-overlap check based on SAT for rotated squares.
# For scoring (sum of sides), the arrangement just needs disjoint interiors;
# tiny overlaps hurt correctness, so we keep a small margin.

_TIME_LIMIT = 55.0

def _corners(x, y, a, s):
    """Return the 4 corners of a square with centre (x,y), angle a (fraction of full turn), side s."""
    th = 2.0 * math.pi * a
    c = math.cos(th) * (s * 0.5)
    sn = math.sin(th) * (s * 0.5)
    # local axes
    ax = (c, sn)
    ay = (-sn, c)
    return (
        (x + ax[0] + ay[0], y + ax[1] + ay[1]),
        (x + ax[0] - ay[0], y + ax[1] - ay[1]),
        (x - ax[0] - ay[0], y - ax[1] - ay[1]),
        (x - ax[0] + ay[0], y - ax[1] + ay[1]),
    )

def _axes(a):
    th = 2.0 * math.pi * a
    c = math.cos(th)
    sn = math.sin(th)
    return (c, sn), (-sn, c)

def _sat_overlap(x1, y1, a1, s1, x2, y2, a2, s2):
    """Return True if interiors of two squares overlap (strictly), using SAT.
    Touching is allowed."""
    axes1 = _axes(a1)
    axes2 = _axes(a2)
    axes = (axes1[0], axes1[1], axes2[0], axes2[1])
    dx = x2 - x1
    dy = y2 - y1
    half1 = s1 * 0.5
    half2 = s2 * 0.5
    for ax in axes:
        # projection radius of each square on axis ax
        r1 = half1 * (abs(ax[0]*axes1[0][0] + ax[1]*axes1[0][1]) +
                      abs(ax[0]*axes1[1][0] + ax[1]*axes1[1][1]))
        r2 = half2 * (abs(ax[0]*axes2[0][0] + ax[1]*axes2[0][1]) +
                      abs(ax[0]*axes2[1][0] + ax[1]*axes2[1][1]))
        d = abs(dx*ax[0] + dy*ax[1])
        if d >= r1 + r2 - 1e-12:
            return False
    return True

def _inside(x, y, a, s, eps=1e-9):
    """Check square fully inside unit square with small tolerance."""
    if s <= 0:
        return -eps <= x <= 1+eps and -eps <= y <= 1+eps
    cs = _corners(x, y, a, s)
    for px, py in cs:
        if px < -eps or px > 1+eps or py < -eps or py > 1+eps:
            return False
    return True

def _total_side(sq):
    return sum(s for (_,_,_,s) in sq)

def _ok(sq, margin=1e-9):
    n = len(sq)
    for i in range(n):
        x, y, a, s = sq[i]
        if s < 0:
            return False
        if not _inside(x, y, a, s, eps=margin):
            return False
    for i in range(n):
        xi, yi, ai, si = sq[i]
        if si <= 0:
            continue
        for j in range(i+1, n):
            xj, yj, aj, sj = sq[j]
            if sj <= 0:
                continue
            if _sat_overlap(xi, yi, ai, si, xj, yj, aj, sj):
                # allow tiny overlap due to tolerance? no: reject
                return False
    return True

def _greedy_grid(n):
    k = int(math.isqrt(n))
    while k > 1 and (1.0 / k) > 1.0 / (k-1):
        break
    side = 1.0 / k
    cells = [(i, j) for i in range(k) for j in range(k)]
    out = []
    for (i, j) in cells[:n]:
        out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # fill remaining with zero-size at centre
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]

def _perturb(sq, scale, rng):
    out = []
    for x, y, a, s in sq:
        nx = x + rng.gauss(0, scale) * 0.1
        ny = y + rng.gauss(0, scale) * 0.1
        na = a + rng.gauss(0, scale) * 0.1
        ns = s + rng.gauss(0, scale) * 0.1
        nx = min(1.0, max(0.0, nx))
        ny = min(1.0, max(0.0, ny))
        na = na % 1.0
        ns = max(0.0, min(1.0, ns))
        out.append((nx, ny, na, ns))
    return out

def _repair(sq, rng, iters=60):
    """Shrink overlapping squares to make configuration valid."""
    sq = [list(t) for t in sq]
    n = len(sq)
    for _ in range(iters):
        changed = False
        # boundary repair
        for i in range(n):
            x, y, a, s = sq[i]
            if s <= 0:
                sq[i][3] = 0.0
                continue
            cs = _corners(x, y, a, s)
            mnx = min(p[0] for p in cs); mxx = max(p[0] for p in cs)
            mny = min(p[1] for p in cs); mxy = max(p[1] for p in cs)
            # shift inside
            dx = 0.0
            if mnx < 0: dx += -mnx
            if mxx > 1: dx -= (mxx - 1)
            dy = 0.0
            if mny < 0: dy += -mny
            if mxy > 1: dy -= (mxy - 1)
            if dx != 0 or dy != 0:
                sq[i][0] = min(1.0, max(0.0, x + dx))
                sq[i][1] = min(1.0, max(0.0, y + dy))
                changed = True
            # shrink if still outside
            x, y, a, s = sq[i]
            if not _inside(x, y, a, s, eps=1e-12):
                sq[i][3] = max(0.0, s * 0.95)
                changed = True
        # overlap repair
        for i in range(n):
            for j in range(i+1, n):
                xi, yi, ai, si = sq[i]
                xj, yj, aj, sj = sq[j]
                if si <= 1e-12 or sj <= 1e-12:
                    continue
                if _sat_overlap(xi, yi, ai, si, xj, yj, aj, sj):
                    # shrink smaller one
                    if si <= sj:
                        sq[i][3] = max(0.0, si * 0.9)
                    else:
                        sq[j][3] = max(0.0, sj * 0.9)
                    changed = True
        if not changed:
            break
    return [tuple(t) for t in sq]

def _local_search(sq, time_limit, rng):
    """Simple stochastic hill climbing with shrinking/expanding moves."""
    best = [tuple(t) for t in sq]
    best_val = _total_side(best)
    cur = [list(t) for t in best]
    start = time.time()
    step = 0
    # adaptive scales
    scales = [0.03, 0.01, 0.003, 0.001]
    while time.time() - start < time_limit:
        step += 1
        sc = scales[min(len(scales)-1, step // 400)]
        i = rng.randrange(len(cur))
        old = list(cur[i])
        op = rng.random()
        x, y, a, s = cur[i]
        if op < 0.35:
            # try expand
            ns = min(1.0, s + rng.random() * sc)
            cur[i] = [x, y, a, ns]
        elif op < 0.6:
            # move
            cur[i] = [min(1.0, max(0.0, x + rng.gauss(0, sc))),
                      min(1.0, max(0.0, y + rng.gauss(0, sc))),
                      a, s]
        elif op < 0.8:
            # rotate
            cur[i] = [x, y, (a + rng.gauss(0, sc)) % 1.0, s]
        else:
            # shrink (to escape)
            cur[i] = [x, y, a, max(0.0, s - rng.random() * sc)]
        if not _inside(cur[i][0], cur[i][1], cur[i][2], cur[i][3], eps=1e-9):
            cur[i] = old
            continue
        # check overlaps with others
        bad = False
        for j in range(len(cur)):
            if j == i:
                continue
            xj, yj, aj, sj = cur[j]
            if sj <= 1e-12:
                continue
            if _sat_overlap(cur[i][0], cur[i][1], cur[i][2], cur[i][3], xj, yj, aj, sj):
                bad = True
                break
        if bad:
            cur[i] = old
            continue
        val = _total_side(cur)
        if val > best_val + 1e-15:
            best_val = val
            best = [tuple(t) for t in cur]
        elif rng.random() < 0.02:
            # accept sideways occasionally
            pass
        else:
            # revert if not better
            if val <= best_val:
                cur[i] = old
    return best

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        # single square: axis-aligned, side 1
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    best = _greedy_grid(n)
    best_val = _total_side(best)

    # Improve with repair + local search from several starts
    deadline = time.time() + _TIME_LIMIT
    attempts = 0
    # Start from greedy and some perturbed variants
    starts = [_greedy_grid(n)]
    for _ in range(4):
        starts.append(_perturb(_greedy_grid(n), 0.05, rng))
    # Also try a couple of random starts for small n
    if n <= 12:
        for _ in range(3):
            sq = []
            for _ in range(n):
                sq.append((rng.random(), rng.random(), rng.random(), rng.random()*0.5))
            starts.append(sq)

    for sq0 in starts:
        if time.time() > deadline:
            break
        sq1 = _repair(sq0, rng, iters=80)
        if _ok(sq1, margin=1e-9):
            val = _total_side(sq1)
            if val > best_val:
                best_val = val
                best = sq1
        # local search with remaining time
        remaining = max(0.0, deadline - time.time())
        if remaining <= 0:
            break
        per_start = remaining / max(1, (len(starts) - attempts))
        improved = _local_search(best, per_start, rng)
        if _ok(improved, margin=1e-9):
            val = _total_side(improved)
            if val > best_val:
                best_val = val
                best = improved
        attempts += 1

    # Final safety: ensure validity
    if not _ok(best, margin=1e-9):
        best = _repair(best, rng, iters=120)
        if not _ok(best, margin=1e-9):
            best = _greedy_grid(n)

    # Sort squares by size descending (not required, but clean)
    best = sorted(best, key=lambda t: -t[3])
    # Ensure exactly n
    if len(best) < n:
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]
