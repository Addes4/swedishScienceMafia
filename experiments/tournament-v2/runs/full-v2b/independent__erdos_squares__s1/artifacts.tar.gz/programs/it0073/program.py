import math
import random


def _overlap_area(a, b):
    # approximate via separating axis on rotated squares (SAT)
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 1e-15 or bsz <= 1e-15:
        return 0.0

    def corners(cx, cy, ang, s):
        t = ang * 2.0 * math.pi
        co, si = math.cos(t), math.sin(t)
        h = s * 0.5
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            pts.append((cx + dx * co - dy * si, cy + dx * si + dy * co))
        return pts

    ca = corners(ax, ay, aa, asz)
    cb = corners(bx, by, ba, bsz)

    def axes(pts):
        out = []
        for i in range(4):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 1e-15:
                out.append((-ey / ln, ex / ln))
        return out

    for nx, ny in axes(ca) + axes(cb):
        pa = [x * nx + y * ny for x, y in ca]
        pb = [x * nx + y * ny for x, y in cb]
        if max(pa) <= min(pb) + 1e-12 or max(pb) <= min(pa) + 1e-12:
            return 0.0
    return min(asz, bsz) ** 2 * 0.5


def _valid(sq):
    for idx, (x, y, a, s) in enumerate(sq):
        if s < 0:
            return False
        t = a * 2 * math.pi
        co, si = math.cos(t), math.sin(t)
        h = s * 0.5
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            px = x + dx * co - dy * si
            py = y + dx * si + dy * co
            if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                return False
        for j in range(idx + 1, len(sq)):
            if _overlap_area(sq[idx], sq[j]) > 1e-10:
                return False
    return True


def _score(sq):
    return sum(s for _, _, _, s in sq)


def _clamp_square(x, y, a, s):
    # shrink if needed to fit axis-aligned bounding box inside unit square
    t = a * 2 * math.pi
    co, si = math.cos(t), math.sin(t)
    ext_x = 0.5 * s * (abs(co) + abs(si))
    ext_y = 0.5 * s * (abs(co) + abs(si))
    # exact rotated square half extents
    co2 = abs(co)
    si2 = abs(si)
    ext_x = 0.5 * s * (co2 + si2)
    ext_y = 0.5 * s * (co2 + si2)
    maxs_x = 1.0 / (co2 + si2 + 1e-15) if (co2 + si2) > 0 else s
    maxs_y = 1.0 / (co2 + si2 + 1e-15) if (co2 + si2) > 0 else s
    maxs = min(maxs_x, maxs_y, s)
    if maxs < s:
        s = maxs
        ext_x = 0.5 * s * (co2 + si2)
        ext_y = 0.5 * s * (co2 + si2)
    x = min(max(x, ext_x), 1.0 - ext_x)
    y = min(max(y, ext_y), 1.0 - ext_y)
    return x, y, a, s


def _greedy_layout(n):
    # recursive guillotine packing into rectangles
    rects = [(0.0, 0.0, 1.0, 1.0)]
    squares = []
    while len(squares) + len(rects) < n:
        # choose largest rect
        best_i = max(range(len(rects)), key=lambda i: rects[i][2] * rects[i][3])
        x, y, w, h = rects.pop(best_i)
        # split along longer side roughly proportionally
        if w >= h:
            # split into two vertical strips
            frac = 0.5
            w1, w2 = w * frac, w * (1 - frac)
            rects.append((x, y, w1, h))
            rects.append((x + w1, y, w2, h))
        else:
            frac = 0.5
            h1, h2 = h * frac, h * (1 - frac)
            rects.append((x, y, w, h1))
            rects.append((x, y + h1, w, h2))
    # place square in each rect
    for x, y, w, h in rects:
        s = min(w, h)
        cx = x + w / 2
        cy = y + h / 2
        # if rect not square, try to center square: shrink to min(w,h)
        squares.append((cx, cy, 0.0, s))
    # add trivial squares if needed
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # start with greedy guillotine layout
    sq = _greedy_layout(n)
    sq = [_clamp_square(x, y, a, s) for x, y, a, s in sq]
    best = [tuple(s) for s in sq]
    best_score = _score(best)

    # local search: perturb random square coordinate/size/angle
    random.seed(12345 + n)
    cur = [tuple(s) for s in best]
    T = 0.5
    for it in range(3000 if n <= 6 else 1500 if n <= 20 else 600):
        i = random.randrange(n)
        x, y, a, s = cur[i]
        # propose
        step = 0.15 * (1.0 - it / (3000 if n <= 6 else 1500 if n <= 20 else 600)) + 0.01
        nx = x + random.uniform(-step, step)
        ny = y + random.uniform(-step, step)
        na = a + random.uniform(-step, step)
        ns = s + random.uniform(-step * 0.5, step * 0.5)
        nx, ny, na, ns = _clamp_square(nx, ny, na, ns)
        old = cur[i]
        cur[i] = (nx, ny, na, ns)
        # check collisions with all
        ok = True
        for j in range(n):
            if j == i:
                continue
            if _overlap_area(cur[i], cur[j]) > 1e-9:
                ok = False
                break
        if ok and _score(cur) >= best_score - 1e-12:
            sc = _score(cur)
            if sc > best_score:
                best_score = sc
                best = [tuple(s) for s in cur]
        else:
            cur[i] = old

    # final greedy increase pass: try expanding each square slowly
    for _ in range(3):
        for i in range(n):
            x, y, a, s = cur[i]
            improved = True
            tries = 0
            while improved and tries < 20:
                improved = False
                tries += 1
                delta = 0.01 * (0.7 ** tries)
                ns = s + delta
                nx, ny, na, ns2 = _clamp_square(x, y, a, ns)
                old = cur[i]
                cur[i] = (nx, ny, na, ns2)
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if _overlap_area(cur[i], cur[j]) > 1e-9:
                        ok = False
                        break
                if ok:
                    s = ns2
                    improved = True
                else:
                    cur[i] = old

    if _score(cur) > best_score:
        best = [tuple(s) for s in cur]
        best_score = _score(best)

    # ensure all values in [0,1] and valid
    out = []
    for x, y, a, s in best:
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        a = min(max(a, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        out.append((float(x), float(y), float(a), float(s)))
    return out[:n]
