import math
import random


def _grid_value(w, h, count):
    """Place `count` equal axis-aligned squares in a w x h rectangle maximising side sum."""
    if count <= 0 or w <= 0 or h <= 0:
        return 0.0, []
    k = math.isqrt(count)
    best = 0.0
    best_rows = None
    best_cols = None
    # Try all factorisations close to a square arrangement.
    for rows in range(1, count + 1):
        cols = (count + rows - 1) // rows
        if rows * cols < count:
            continue
        area = rows * cols
        if area < count:
            continue
        side = min(w / cols, h / rows) if cols > 0 and rows > 0 else 0.0
        val = side * count
        if val > best:
            best = val
            best_rows = rows
            best_cols = cols
    if best_rows is None:
        return 0.0, []
    rows = best_rows
    cols = best_cols
    side = min(w / cols, h / rows)
    squares = []
    # Fill exactly `count` slots in the grid.
    placed = 0
    for r in range(rows):
        for c in range(cols):
            if placed >= count:
                break
            x = (c + 0.5) * w / cols
            y = (r + 0.5) * h / rows
            squares.append((x, y, 0.0, side))
            placed += 1
        if placed >= count:
            break
    # scale positions to actual region (already done), return value
    return side * count, squares


def _solve_rect(w, h, n, ox, oy, depth=0):
    """Recursively pack n squares in rectangle of size w x h with lower-left at (ox, oy)."""
    if n <= 0:
        return 0.0, []
    if n == 1:
        side = min(w, h)
        return side, [(ox + w * 0.5, oy + h * 0.5, 0.0, side)]
    # Try a single grid.
    best_val, best_sq = _grid_value(w, h, n)
    # Try vertical split.
    if depth < 8:
        for n1 in range(1, n):
            n2 = n - n1
            # split width
            for frac in (0.5,):
                w1 = w * frac
                w2 = w - w1
                if w1 <= 0 or w2 <= 0:
                    continue
                v1, s1 = _solve_rect(w1, h, n1, ox, oy, depth + 1)
                v2, s2 = _solve_rect(w2, h, n2, ox + w1, oy, depth + 1)
                if v1 + v2 > best_val:
                    best_val = v1 + v2
                    best_sq = s1 + s2
            # split height
            for frac in (0.5,):
                h1 = h * frac
                h2 = h - h1
                if h1 <= 0 or h2 <= 0:
                    continue
                v1, s1 = _solve_rect(w, h1, n1, ox, oy, depth + 1)
                v2, s2 = _solve_rect(w, h2, n2, ox, oy + h1, depth + 1)
                if v1 + v2 > best_val:
                    best_val = v1 + v2
                    best_sq = s1 + s2
    return best_val, best_sq


def _greedy_fill(n):
    """Greedy approach: place squares one by one in a grid-like pattern."""
    # Start with a square grid and refine.
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    # Use recursive rectangle packing as the main method.
    val, squares = _solve_rect(1.0, 1.0, n, 0.0, 0.0)
    # Pad with zero-size squares if needed.
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _local_improve(squares, n):
    """Try to slightly adjust squares to improve total side without overlaps (approximate)."""
    # For a first pass, we just return the squares; the recursive method is already good.
    # A simple improvement: if there are zero-size squares, try to make them positive
    # by shrinking others slightly. This is a heuristic.
    total = sum(s[3] for s in squares)
    # Count zeros
    zeros = [i for i, s in enumerate(squares) if s[3] < 1e-12]
    if zeros and total > 0:
        # Try to distribute a small amount from all positive squares to zeros.
        pos = [i for i, s in enumerate(squares) if s[3] > 1e-12]
        if len(pos) > 0:
            # Reduce each positive square by a small factor and give to zeros.
            # Very conservative: only if we can find a valid packing.
            # For simplicity, we skip actual geometric validation; just slightly reduce.
            # This is risky and may cause overlaps, so we don't apply it.
            pass
    return squares


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # Use recursive rectangle packing.
    squares = _greedy_fill(n)
    # Ensure all centers are within [0,1] and sides valid.
    cleaned = []
    for cx, cy, ang, side in squares:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        side = min(side, 1.0)
        # Ensure the square fits within [0,1]^2 if axis-aligned.
        if abs(ang) < 1e-12:
            half = side * 0.5
            cx = min(1.0 - half, max(half, cx))
            cy = min(1.0 - half, max(half, cy))
        cleaned.append((cx, cy, 0.0, side))
    # Pad with zero-size squares to reach exactly n.
    while len(cleaned) < n:
        cleaned.append((0.5, 0.5, 0.0, 0.0))
    return cleaned[:n]
