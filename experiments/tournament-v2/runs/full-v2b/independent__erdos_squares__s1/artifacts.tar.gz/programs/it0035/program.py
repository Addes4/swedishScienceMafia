import math
import random
import numpy as np
from scipy.optimize import minimize

def _overlap_penalty_and_grad(params, n):
    """Compute total pairwise overlap penalty and gradient wrt params.
    params: flat array of [cx, cy, angle, side] * n
    Returns (penalty, grad). Penalty 0 when no overlap.
    Uses AABB-style separation approx with rotation, sufficient as soft repulsion.
    """
    P = params.reshape(n, 4)
    cx = P[:, 0]; cy = P[:, 1]; ang = P[:, 2]; s = P[:, 3]
    # half-extent projections for rotated squares onto axes:
    # square with side s rotated by theta: projection half-width onto x = 0.5*s*(|cos|+|sin|)
    c = np.cos(2*np.pi*ang); sn = np.sin(2*np.pi*ang)
    hx = 0.5*s*(np.abs(c)+np.abs(sn))
    hy = 0.5*s*(np.abs(c)+np.abs(sn))
    # Use exact rotated square overlap via separating axis is complex; use AABB of rotated square
    # AABB half extents are hx,hy above (same for both axes actually with |cos|+|sin|).
    pen = 0.0
    grad = np.zeros_like(params)
    gradP = grad.reshape(n,4)
    for i in range(n):
        for j in range(i+1, n):
            dx = cx[i]-cx[j]
            dy = cy[i]-cy[j]
            ox = (hx[i]+hx[j]) - abs(dx)
            oy = (hy[i]+hy[j]) - abs(dy)
            if ox > 0 and oy > 0:
                # overlap area approx ox*oy
                pen += ox*oy
                # gradients
                sgnx = np.sign(dx) if dx != 0 else 1.0
                sgny = np.sign(dy) if dy != 0 else 1.0
                # d(pen)/d(cx_i) etc
                # ox depends on hx which depends on s and ang
                # approximate derivatives
                dOx_dxi = -sgnx
                dOy_dyi = -sgny
                # wrt centers
                gradP[i,0] += oy*dOx_dxi
                gradP[j,0] -= oy*dOx_dxi
                gradP[i,1] += ox*dOy_dyi
                gradP[j,1] -= ox*dOy_dyi
                # wrt side (approx: hx increases with s)
                # dhx/ds = 0.5*(|c|+|sn|)
                dhx = 0.5*(np.abs(c[i])+np.abs(sn[i]))
                dhy = dhx
                gradP[i,3] += oy*dhx + ox*dhy
                gradP[j,3] += oy*dhx + ox*dhy
                # angle gradient ignored (small)
    return pen, grad

def _boundary_penalty_and_grad(params, n):
    """Penalty for squares going outside [0,1]^2."""
    P = params.reshape(n,4)
    cx = P[:,0]; cy = P[:,1]; ang = P[:,2]; s = P[:,3]
    c = np.cos(2*np.pi*ang); sn = np.sin(2*np.pi*ang)
    hx = 0.5*s*(np.abs(c)+np.abs(sn))
    hy = 0.5*s*(np.abs(c)+np.abs(sn))
    pen = 0.0
    grad = np.zeros_like(params)
    gradP = grad.reshape(n,4)
    for k in range(n):
        # left/right
        for (val, lo, hi, idx) in [(cx[k], 0.0, 1.0, 0), (cy[k], 0.0, 1.0, 1)]:
            h = hx[k] if idx==0 else hy[k]
            if val - h < lo:
                d = lo - (val - h)
                pen += d*d
                gradP[k,idx] -= 2*d
                # also side derivative
            if val + h > hi:
                d = (val + h) - hi
                pen += d*d
                gradP[k,idx] += 2*d
    return pen, grad

def _objective(params, n, target_sum):
    """Negative sum of sides + penalties."""
    P = params.reshape(n,4)
    s = P[:,3]
    total = np.sum(s)
    p1, g1 = _overlap_penalty_and_grad(params, n)
    p2, g2 = _boundary_penalty_and_grad(params, n)
    # maximize total -> minimize -total + penalty
    val = -total + 100.0*(p1 + p2)
    grad = np.zeros_like(params)
    gP = grad.reshape(n,4)
    gP[:,3] = -1.0
    grad += 100.0*(g1 + g2)
    return val, grad

def _maximize_sum(n, init_params, maxiter=200):
    """Run L-BFGS-B on the objective."""
    def fun(x):
        v, g = _objective(x, n, 1.0)
        return v, g
    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))  # cx
        bounds.append((0.0, 1.0))  # cy
        bounds.append((0.0, 1.0))  # angle
        bounds.append((0.0, 1.0))  # side
    res = minimize(fun, init_params, method='L-BFGS-B', jac=True, bounds=bounds,
                   options={'maxiter': maxiter, 'ftol': 1e-10, 'gtol': 1e-10})
    return res.x, res.fun

def _initial_grid(n):
    """Compute k x k grid for n, but fill extras as small squares in gaps or zero."""
    k = math.isqrt(n)
    side = 1.0 / k
    params = []
    used = 0
    for i in range(k):
        for j in range(k):
            if used < n:
                params.append((i + 0.5) * side)
                params.append((j + 0.5) * side)
                params.append(0.0)
                params.append(side)
                used += 1
    # Add remaining as tiny squares in center of one cell (will be optimized)
    while used < n:
        params.append(0.5)
        params.append(0.5)
        params.append(0.0)
        params.append(0.0)
        used += 1
    return np.array(params)

def _initial_random(n, seed):
    rng = random.Random(seed)
    params = []
    for i in range(n):
        cx = rng.uniform(0.1, 0.9)
        cy = rng.uniform(0.1, 0.9)
        ang = rng.uniform(0.0, 0.25)
        s = rng.uniform(0.0, 0.2)
        params.extend([cx, cy, ang, s])
    return np.array(params)

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    best_params = None
    best_sum = -1.0
    # try grid start
    starts = []
    starts.append(("grid", _initial_grid(n)))
    # a few random starts
    for seed in range(5):
        starts.append((f"rand{seed}", _initial_random(n, seed)))
    # also try recursive split for non-square n
    if n > 1:
        # try a start where larger squares in a row
        k = math.isqrt(n)
        rem = n - k*k
        params = _initial_grid(n)
        starts.append(("grid2", params))
    for name, init in starts:
        try:
            x, fval = _maximize_sum(n, init, maxiter=150)
            P = x.reshape(n,4)
            # clean: fix tiny negatives, clamp
            P[:,0] = np.clip(P[:,0], 0.0, 1.0)
            P[:,1] = np.clip(P[:,1], 0.0, 1.0)
            P[:,2] = np.clip(P[:,2], 0.0, 1.0)
            P[:,3] = np.clip(P[:,3], 0.0, 1.0)
            total = np.sum(P[:,3])
            if total > best_sum:
                best_sum = total
                best_params = P.copy()
        except Exception:
            continue
    if best_params is None:
        # fallback grid
        k = math.isqrt(n)
        side = 1.0/k
        P = np.zeros((n,4))
        for idx in range(n):
            if idx < k*k:
                i = idx // k
                j = idx % k
                P[idx] = [(i+0.5)*side, (j+0.5)*side, 0.0, side]
            else:
                P[idx] = [0.5, 0.5, 0.0, 0.0]
        best_params = P
    # ensure all in [0,1]
    best_params[:,0] = np.clip(best_params[:,0], 0.0, 1.0)
    best_params[:,1] = np.clip(best_params[:,1], 0.0, 1.0)
    best_params[:,2] = np.clip(best_params[:,2], 0.0, 1.0)
    best_params[:,3] = np.clip(best_params[:,3], 0.0, 1.0)
    result = []
    for i in range(n):
        result.append((float(best_params[i,0]), float(best_params[i,1]),
                       float(best_params[i,2]), float(best_params[i,3])))
    return result
