import math
import random
import numpy as np
from scipy.optimize import minimize


# ----------------------------------------------------------------------------
# Geometry helpers
# ----------------------------------------------------------------------------

def corners(cx, cy, ang, s):
    """Return the 4 corners of a square (center, angle in turns, side length)."""
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def sat_overlap(ptsA, ptsB, margin=1e-9):
    """Return True if convex polygons A and B overlap by more than margin."""
    for pts in (ptsA, ptsB):
        n = len(pts)
        for i in range(n):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % n]
            ax, ay = x2 - x1, y2 - y1
            # normal
            nx, ny = -ay, ax
            # project A
            a_vals = [nx * px + ny * py for px, py in ptsA]
            b_vals = [nx * px + ny * py for px, py in ptsB]
            if max(a_vals) - min(b_vals) <= margin or max(b_vals) - min(a_vals) <= margin:
                return False
    return True


def inside_unit(pts, margin=1e-9):
    for x, y in pts:
        if x < -margin or x > 1.0 + margin or y < -margin or y > 1.0 + margin:
            return False
    return True


def valid_layout(sqs, margin=1e-9):
    n = len(sqs)
    polys = []
    for cx, cy, ang, s in sqs:
        if s < 0:
            return False
        p = corners(cx, cy, ang, s)
        if not inside_unit(p, margin):
            return False
        polys.append(p)
    for i in range(n):
        for j in range(i + 1, n):
            if sqs[i][3] <= 0 or sqs[j][3] <= 0:
                continue
            if sat_overlap(polys[i], polys[j], margin):
                return False
    return True


def total(sqs):
    return sum(s[3] for s in sqs)


# ----------------------------------------------------------------------------
# Construction heuristics
# ----------------------------------------------------------------------------

def grid_layout(k, offset=0.0):
    """k x k grid, each square side 1/k."""
    s = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            out.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    return out


def perturb(sqs, rng, scale=0.01):
    new = []
    for cx, cy, ang, s in sqs:
        if s <= 0:
            new.append((cx, cy, ang, s))
            continue
        nx = cx + rng.uniform(-scale, scale)
        ny = cy + rng.uniform(-scale, scale)
        na = ang + rng.uniform(-scale * 0.5, scale * 0.5)
        new.append((nx, ny, na, s))
    return new


def try_add_square(sqs, rng, trials=200):
    """Try to insert an extra square into remaining space."""
    n = len(sqs)
    # bounding obstacles
    best = None
    for _ in range(trials):
        cx = rng.random()
        cy = rng.random()
        ang = rng.random()
        # binary search largest side
        lo, hi = 0.0, 0.5
        for _ in range(22):
            mid = 0.5 * (lo + hi)
            cand = sqs + [(cx, cy, ang, mid)]
            if valid_layout(cand):
                lo = mid
            else:
                hi = mid
        if lo > 1e-6:
            if best is None or lo > best[3]:
                best = (cx, cy, ang, lo)
    if best is None:
        return sqs
    return sqs + [best]


def shake_and_improve(sqs, rng, iters=200):
    """Randomly perturb and accept if total improves; also try growing a square."""
    cur = list(sqs)
    cur_val = total(cur)
    for _ in range(iters):
        cand = perturb(cur, rng, scale=0.01)
        if valid_layout(cand) and total(cand) > cur_val:
            cur, cur_val = cand, total(cand)
            continue
        # random grow
        idx = rng.randrange(len(cur)) if cur else 0
        if cur:
            cx, cy, ang, s = cur[idx]
            grow = s * 0.01 + 1e-4
            new = list(cur)
            new[idx] = (cx, cy, ang, s + grow)
            if valid_layout(new):
                cur, cur_val = new, total(new)
    return cur


# ----------------------------------------------------------------------------
# Main solver
# ----------------------------------------------------------------------------

def solve(n):
    rng = random.Random(12345)
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side 0.5 side by side
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    # Base grid
    k = math.isqrt(n)
    sqs = grid_layout(k)
    # Try to add extra squares in leftover space by placing them in a strip
    extra_needed = n - len(sqs)

    best = list(sqs)
    best_val = total(best)

    # Try multiple random insertions for extras
    for attempt in range(30):
        cur = list(sqs)
        r = random.Random(1000 + attempt)
        while len(cur) < n:
            cur = try_add_square(cur, r, trials=120)
            if len(cur) < n and len(cur) == len(sqs):  # failed to add
                # fall back: waste square
                cur.append((0.5, 0.5, 0.0, 0.0))
                break
            if len(cur) > n:
                cur = cur[:n]
        while len(cur) < n:
            cur.append((0.5, 0.5, 0.0, 0.0))
        if valid_layout(cur):
            v = total(cur)
            if v > best_val:
                best, best_val = list(cur), v

    # Improve with local search for square counts where rotation could help
    if n not in (1, 2, 3, 4):
        cur = best
        for _ in range(200):
            cur = shake_and_improve(cur, rng, iters=150)
            v = total(cur)
            if v > best_val and valid_layout(cur):
                best, best_val = list(cur), v

    # final cleanup: ensure no overlaps and exact count
    if not valid_layout(best):
        best = list(sqs) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(sqs))
        best = best[:n]
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
