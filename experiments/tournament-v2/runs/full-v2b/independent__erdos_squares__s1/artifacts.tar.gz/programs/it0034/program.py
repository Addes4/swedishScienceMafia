import math
import random
import numpy as np
from scipy.optimize import minimize

def _grid_in_rect(w, h, n):
    """Return n squares inside a w x h rectangle maximizing sum of sides.
    Strategy: try all k x m grids with k*m <= n, fill leftover with zero-size squares.
    Also try 'equal side' packing where all side = min(w/h ratio) etc."""
    if n == 0:
        return []
    best = None
    best_sum = -1
    # Try all ways to arrange as close to square grid as possible
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if cols > n:
            continue
        # grid of rows x cols
        s = min(w / cols, h / rows)
        used = min(rows * cols, n)
        total = s * used
        if total > best_sum:
            best_sum = total
            best = (rows, cols, s, used)
    # Also try packing 'k' squares all same size with s = min(w/k?, but that's same)
    # Also try uneven rows
    rows, cols, s, used = best
    result = []
    for i in range(rows):
        for j in range(cols):
            if len(result) >= n:
                break
            cx = (j + 0.5) * s
            cy = (i + 0.5) * s
            result.append((cx, cy, 0.0, s))
    # fill remaining
    while len(result) < n:
        result.append((0.5 * w, 0.5 * h, 0.0, 0.0))
    return result[:n]

def _split_square(total_w, total_h, n, depth=0):
    """Recursively split into rectangles, assign squares."""
    if n == 0:
        return []
    if n == 1:
        s = min(total_w, total_h)
        return [(total_w/2, total_h/2, 0.0, s)]
    # Try guillotine split: vertical or horizontal
    best = None
    best_sum = -1
    # Try all splits
    for i in range(1, n):
        for ratio in np.linspace(0.1, 0.9, 9):
            # vertical split
            w1 = total_w * ratio
            w2 = total_w * (1 - ratio)
            r1 = _split_square(w1, total_h, i, depth+1)
            r2 = _split_square(w2, total_h, n - i, depth+1)
            total = sum(r[3] for r in r1) + sum(r[3] for r in r2)
            if total > best_sum:
                best_sum = total
                best = (r1, r2, 'v', w1)
            # horizontal
            h1 = total_h * ratio
            h2 = total_h * (1 - ratio)
            r1 = _split_square(total_w, h1, i, depth+1)
            r2 = _split_square(total_w, h2, n - i, depth+1)
            total = sum(r[3] for r in r1) + sum(r[3] for r in r2)
            if total > best_sum:
                best_sum = total
                best = (r1, r2, 'h', h1)
    r1, r2, typ, sz = best
    result = []
    if typ == 'v':
        for (cx, cy, a, s) in r1:
            result.append((cx, cy, a, s))
        for (cx, cy, a, s) in r2:
            result.append((cx + sz, cy, a, s))
    else:
        for (cx, cy, a, s) in r1:
            result.append((cx, cy, a, s))
        for (cx, cy, a, s) in r2:
            result.append((cx, cy + sz, a, s))
    return result

def _normalize(squares, W=1.0, H=1.0):
    """Ensure all centers/sides valid, clip."""
    out = []
    for (cx, cy, a, s) in squares:
        s = max(0.0, min(s, 1.0))
        cx = max(0.01, min(W - 0.01, cx))
        cy = max(0.01, min(H - 0.01, cy))
        # check fits
        # half diagonal for rotated square
        half = s * (abs(math.cos(a*2*math.pi)) + abs(math.sin(a*2*math.pi))) / 2
        half = s * (abs(math.cos(a*2*math.pi)) + abs(math.sin(a*2*math.pi))) / 2
        # Actually simpler: rotated square bounding box: s*(|cos|+|sin|)/2
        ca = abs(math.cos(a*2*math.pi))
        sa = abs(math.sin(a*2*math.pi))
        bb = s * (ca + sa) / 2
        if cx - bb < 0: cx = bb
        if cy - bb < 0: cy = bb
        if cx + bb > W: cx = W - bb
        if cy + bb > H: cy = H - bb
        # shrink if needed
        if bb * 2 > W or bb * 2 > H:
            max_s = min(W, H) / (ca + sa) if (ca+sa) > 0 else min(W,H)
            s = min(s, max_s)
        out.append((cx, cy, a % 1.0, s))
    return out

def _overlap(c1, s1, a1, c2, s2, a2):
    """Check if two squares overlap (interiors)."""
    # Use SAT for rotated squares
    # approximate: use axis-aligned bounding boxes + SAT
    def corners(cx, cy, s, a):
        a = a * 2 * math.pi
        ca, sa = math.cos(a), math.sin(a)
        h = s / 2
        return [
            (cx + h*(ca - sa), cy + h*(sa + ca)),
            (cx + h*(ca + sa), cy + h*(-sa + ca)),
            (cx - h*(ca - sa), cy - h*(sa + ca)),
            (cx - h*(ca + sa), cy - h*(-sa + ca)),
        ]
    p1 = corners(c1[0], c1[1], s1, a1)
    p2 = corners(c2[0], c2[1], s2, a2)
    # SAT
    def axes(poly):
        axes = []
        n = len(poly)
        for i in range(n):
            x1,y1 = poly[i]
            x2,y2 = poly[(i+1)%n]
            edge = (x2-x1, y2-y1)
            normal = (-edge[1], edge[0])
            length = math.hypot(*normal)
            if length > 1e-12:
                axes.append((normal[0]/length, normal[1]/length))
        return axes
    for axis in axes(p1) + axes(p2):
        proj1 = [x*axis[0]+y*axis[1] for x,y in p1]
        proj2 = [x*axis[0]+y*axis[1] for x,y in p2]
        if max(proj1) < min(proj2) - 1e-9 or max(proj2) < min(proj1) - 1e-9:
            return False
    return True

def _total_side(squares):
    return sum(s for (cx,cy,a,s) in squares)

def _optimize(squares, n, iters=200):
    """Local search: move, rotate, resize one square at a time."""
    squares = [list(s) for s in squares]
    best = [s[:] for s in squares]
    best_val = _total_side(best)
    for it in range(iters):
        # pick random square
        idx = random.randrange(n)
        cur = squares[idx]
        # try random perturbation
        new_s = cur[3]
        new_cx = cur[0] + random.gauss(0, 0.02)
        new_cy = cur[1] + random.gauss(0, 0.02)
        new_a = (cur[2] + random.gauss(0, 0.05)) % 1.0
        # grow or shrink
        new_s = max(0.0, cur[3] + random.gauss(0, 0.02))
        # clip
        new_cx = max(0.0, min(1.0, new_cx))
        new_cy = max(0.0, min(1.0, new_cy))
        if new_s > 1.0: new_s = 1.0
        # normalize
        ca = abs(math.cos(new_a*2*math.pi))
        sa = abs(math.sin(new_a*2*math.pi))
        bb = new_s * (ca + sa) / 2
        if new_cx - bb < 0: new_cx = bb
        if new_cy - bb < 0: new_cy = bb
        if new_cx + bb > 1: new_cx = 1 - bb
        if new_cy + bb > 1: new_cy = 1 - bb
        # check overlap with all others
        ok = True
        for j in range(n):
            if j == idx: continue
            if _overlap((new_cx,new_cy), new_s, new_a, (squares[j][0],squares[j][1]), squares[j][3], squares[j][2]):
                ok = False
                break
        if ok:
            old = squares[idx][:]
            squares[idx] = [new_cx, new_cy, new_a, new_s]
            val = _total_side(squares)
            if val >= best_val:
                best_val = val
                best = [s[:] for s in squares]
            else:
                squares[idx] = old  # revert
    return best

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # initial: recursive split
    random.seed(42)
    best_squares = None
    best_val = -1
    # Try several strategies
    strategies = []
    # 1. simple grid
    k = math.isqrt(n)
    side = 1.0 / k
    grid = [((i+0.5)*side, (j+0.5)*side, 0.0, side) for i in range(k) for j in range(k)]
    while len(grid) < n:
        grid.append((0.5, 0.5, 0.0, 0.0))
    strategies.append(grid[:n])
    # 2. recursive split
    rec = _split_square(1.0, 1.0, n)
    if len(rec) < n:
        while len(rec) < n:
            rec.append((0.5, 0.5, 0.0, 0.0))
    strategies.append(rec[:n])
    # 3. equal size squares
    s = 1.0 / math.ceil(math.sqrt(n))
    eq = []
    idx = 0
    for i in range(math.ceil(1.0/s)):
        for j in range(math.ceil(1.0/s)):
            if idx >= n: break
            eq.append(((j+0.5)*s, (i+0.5)*s, 0.0, s))
            idx += 1
        if idx >= n: break
    while len(eq) < n:
        eq.append((0.5, 0.5, 0.0, 0.0))
    strategies.append(eq[:n])
    # 4. rotated squares attempt: place one large rotated square in center, fill rest
    for trial in range(3):
        sq = _split_square(1.0, 1.0, n)
        while len(sq) < n:
            sq.append((0.5, 0.5, 0.0, 0.0))
        sq = sq[:n]
        # randomize angles
        for i in range(min(n, len(sq))):
            if sq[i][3] > 0.01:
                sq[i] = (sq[i][0], sq[i][1], random.random(), sq[i][3])
        sq = _normalize(sq)
        strategies.append(sq)
    # Evaluate and optimize
    for strat in strategies:
        strat = _normalize(strat)
        # check overlaps, fix
        for i in range(len(strat)):
            for j in range(i+1, len(strat)):
                if _overlap((strat[i][0],strat[i][1]), strat[i][3], strat[i][2],
                           (strat[j][0],strat[j][1]), strat[j][3], strat[j][2]):
                    # shrink smaller
                    if strat[i][3] <= strat[j][3]:
                        strat[i] = (strat[i][0], strat[i][1], strat[i][2], strat[i][3]*0.5)
                    else:
                        strat[j] = (strat[j][0], strat[j][1], strat[j][2], strat[j][3]*0.5)
        strat = _normalize(strat)
        val = _total_side(strat)
        if val > best_val:
            best_val = val
            best_squares = strat
    # Optimize best
    if best_squares is not None:
        best_squares = _optimize(best_squares, n, iters=min(500, n*20))
    if best_squares is None:
        best_squares = strategies[0]
    # final normalization
    best_squares = _normalize(best_squares)
    # fill to n
    out = []
    for (cx,cy,a,s) in best_squares:
        out.append((float(cx), float(cy), float(a), float(s)))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
