import math
import random
import numpy as np
from scipy.optimize import minimize


def _overlap_penalty(sq1, sq2, margin=1e-9):
    x1, y1, a1, s1 = sq1
    x2, y2, a2, s2 = sq2
    if s1 <= 0 or s2 <= 0:
        return 0.0
    # Use separating axis theorem for two squares
    # Each square has two axes (normal to edges)
    axes = []
    for a, s in ((a1, s1), (a2, s2)):
        theta = a * 2 * math.pi
        c, sn = math.cos(theta), math.sin(theta)
        axes.append((c, sn))
        axes.append((-sn, c))
    # Compute projections
    def project(sq):
        x, y, a, s = sq
        if s <= 0:
            return (x, x), (y, y)
        theta = a * 2 * math.pi
        c, sn = math.cos(theta), math.sin(theta)
        # corners relative to center
        h = s / 2.0
        corners = [
            (x + c * h - sn * h, y + sn * h + c * h),
            (x + c * h + sn * h, y + sn * h - c * h),
            (x - c * h + sn * h, y - sn * h - c * h),
            (x - c * h - sn * h, y - sn * h + c * h),
        ]
        return [p[0] for p in corners], [p[1] for p in corners]
    p1x, p1y = project(sq1)
    p2x, p2y = project(sq2)
    # quick AABB check
    if max(p1x) + margin < min(p2x) or max(p2x) + margin < min(p1x):
        return 0.0
    if max(p1y) + margin < min(p2y) or max(p2y) + margin < min(p1y):
        return 0.0
    # SAT
    for ax, ay in axes:
        # project both
        proj1 = [x * ax + y * ay for x, y in zip(p1x, p1y)]
        proj2 = [x * ax + y * ay for x, y in zip(p2x, p2y)]
        if max(proj1) + margin < min(proj2) or max(proj2) + margin < min(proj1):
            return 0.0
    # If no separating axis, compute overlap area approximately
    # Use polygon clipping? For small angles, approximate as axis-aligned overlap
    # Simple approximation: compute min distance between centers vs sum of half-diagonals
    dx = x1 - x2
    dy = y1 - y2
    dist = math.hypot(dx, dy)
    r1 = s1 * 0.7071067811865476  # half diagonal
    r2 = s2 * 0.7071067811865476
    if dist < r1 + r2:
        return (r1 + r2 - dist) ** 2
    return 0.0


def _objective(params, n, ref_sizes):
    # params: x,y,angle,size for each square
    squares = []
    for i in range(n):
        base = i * 4
        x = params[base]
        y = params[base + 1]
        a = params[base + 2]
        s = params[base + 3]
        squares.append((x, y, a, s))
    # penalty for out of bounds
    pen = 0.0
    for x, y, a, s in squares:
        if s <= 0:
            continue
        theta = a * 2 * math.pi
        c, sn = math.cos(theta), math.sin(theta)
        h = s / 2.0
        corners = [
            (x + c * h - sn * h, y + sn * h + c * h),
            (x + c * h + sn * h, y + sn * h - c * h),
            (x - c * h + sn * h, y - sn * h - c * h),
            (x - c * h - sn * h, y - sn * h + c * h),
        ]
        for cx, cy in corners:
            if cx < -1e-6:
                pen += (cx + 1e-6) ** 2 * 1000
            if cx > 1 + 1e-6:
                pen += (cx - 1 - 1e-6) ** 2 * 1000
            if cy < -1e-6:
                pen += (cy + 1e-6) ** 2 * 1000
            if cy > 1 + 1e-6:
                pen += (cy - 1 - 1e-6) ** 2 * 1000
    # penalty for overlaps
    for i in range(n):
        for j in range(i + 1, n):
            pen += _overlap_penalty(squares[i], squares[j]) * 100
    # maximize sum of sizes -> minimize negative
    total = sum(s[3] for s in squares)
    return -total + pen


def _initial_grid(n):
    # Try several grid configurations
    best = None
    best_sum = -1
    for k in range(1, int(math.sqrt(n)) + 3):
        if k * k > n:
            continue
        # Use k x k grid
        side = 1.0 / k
        squares = []
        for i in range(k):
            for j in range(k):
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        # Fill remaining with zero-size or small squares in gaps
        remaining = n - len(squares)
        # Try to place extra squares in the grid gaps or as tiny squares
        # Distribute extra squares: use smaller grid inside one cell?
        # Simple: add zero-size squares at random positions
        for _ in range(remaining):
            squares.append((0.5, 0.5, 0.0, 0.0))
        total = sum(s[3] for s in squares)
        if total > best_sum:
            best_sum = total
            best = squares[:]
    return best


def _initial_perturbed(n):
    # Start from grid with small perturbations
    k = int(math.sqrt(n))
    if k * k > n:
        k -= 1
    side = 1.0 / max(k, 1)
    squares = []
    for i in range(k):
        for j in range(k):
            x = (i + 0.5) * side + random.uniform(-0.01, 0.01)
            y = (j + 0.5) * side + random.uniform(-0.01, 0.01)
            a = random.uniform(-0.02, 0.02)
            s = side * random.uniform(0.95, 1.0)
            squares.append((x, y, a, s))
    while len(squares) < n:
        squares.append((random.uniform(0.1, 0.9), random.uniform(0.1, 0.9), 0.0, random.uniform(0.0, 0.05)))
    return squares[:n]


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three equal squares side 1/2? No, 3 squares of side 0.5: total 1.5
        # Better: three squares: two of side 0.5 and one of side 0.5? Can't fit 3 of side 0.5.
        # Actually three squares of side 0.5 cannot fit in unit square (area 0.75 vs 1.0)
        # Try: two large on bottom, one on top
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # Start with best grid
    best_squares = _initial_grid(n)
    best_total = sum(s[3] for s in best_squares)

    # Try multiple random starts and optimize
    num_restarts = 3
    for restart in range(num_restarts):
        if restart == 0:
            init_sq = best_squares[:]
        else:
            init_sq = _initial_perturbed(n)

        # Flatten parameters
        x0 = []
        for x, y, a, s in init_sq:
            x0.extend([x, y, a, s])
        x0 = np.array(x0)

        # Bounds
        bounds = []
        for i in range(n):
            bounds.append((0.0, 1.0))  # x
            bounds.append((0.0, 1.0))  # y
            bounds.append((-0.125, 0.125))  # angle (small rotation)
            bounds.append((0.0, 1.0))  # size

        # Optimize with L-BFGS-B
        try:
            res = minimize(_objective, x0, args=(n, None), method='L-BFGS-B',
                          bounds=bounds, options={'maxiter': 200, 'ftol': 1e-10})
            opt_params = res.x
        except Exception:
            opt_params = x0

        # Extract squares
        squares = []
        for i in range(n):
            base = i * 4
            x = np.clip(opt_params[base], 0.0, 1.0)
            y = np.clip(opt_params[base + 1], 0.0, 1.0)
            a = opt_params[base + 2]
            s = max(0.0, opt_params[base + 3])
            squares.append((float(x), float(y), float(a), float(s)))

        # Fix any remaining overlaps by shrinking
        for i in range(n):
            for j in range(i + 1, n):
                pen = _overlap_penalty(squares[i], squares[j])
                if pen > 1e-9:
                    # shrink both slightly
                    xi, yi, ai, si = squares[i]
                    xj, yj, aj, sj = squares[j]
                    squares[i] = (xi, yi, ai, si * 0.95)
                    squares[j] = (xj, yj, aj, sj * 0.95)

        total = sum(s[3] for s in squares)
        if total > best_total:
            best_total = total
            best_squares = squares[:]

    # Final validation and clamping
    result = []
    for x, y, a, s in best_squares:
        x = max(0.0, min(1.0, x))
        y = max(0.0, min(1.0, y))
        a = max(-0.25, min(0.25, a))
        s = max(0.0, min(1.0, s))
        # Check corners
        theta = a * 2 * math.pi
        c, sn = math.cos(theta), math.sin(theta)
        h = s / 2.0
        corners = [
            (x + c * h - sn * h, y + sn * h + c * h),
            (x + c * h + sn * h, y + sn * h - c * h),
            (x - c * h + sn * h, y - sn * h - c * h),
            (x - c * h - sn * h, y - sn * h + c * h),
        ]
        # If any corner outside, shrink
        min_x = min(cx for cx, cy in corners)
        max_x = max(cx for cx, cy in corners)
        min_y = min(cy for cx, cy in corners)
        max_y = max(cy for cx, cy in corners)
        if min_x < 0 or max_x > 1 or min_y < 0 or max_y > 1:
            # shrink to fit
            scale = 1.0
            if min_x < 0:
                scale = min(scale, (x - 0.0) / (x - min_x) if x > min_x else 1.0)
            if max_x > 1:
                scale = min(scale, (1.0 - x) / (max_x - x) if max_x > x else 1.0)
            if min_y < 0:
                scale = min(scale, (y - 0.0) / (y - min_y) if y > min_y else 1.0)
            if max_y > 1:
                scale = min(scale, (1.0 - y) / (max_y - y) if max_y > y else 1.0)
            s *= scale
            h = s / 2.0
            # recenter if needed
            x = max(x, h)
            x = min(x, 1 - h)
            y = max(y, h)
            y = min(y, 1 - h)
        result.append((x, y, a, s))

    # Ensure exactly n squares
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
