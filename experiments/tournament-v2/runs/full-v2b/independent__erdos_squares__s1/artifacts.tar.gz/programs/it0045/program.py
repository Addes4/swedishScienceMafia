import math
import random
import numpy as np

# ----------------------------------------------------------------------
# Geometry helpers
# ----------------------------------------------------------------------

def corners(cx, cy, ang, s):
    """Return the four corners of a square, angle in turns."""
    a = ang * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + c * dx - sn * dy, cy + sn * dx + c * dy))
    return pts


def inside_unit(pts, eps=1e-9):
    for x, y in pts:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def _proj(pts, axis):
    ax, ay = axis
    vals = [x * ax + y * ay for x, y in pts]
    return min(vals), max(vals)


def squares_overlap(sq1, sq2):
    """Overlap of interiors of two squares. sq = (cx, cy, ang, side)."""
    p1 = corners(*sq1)
    p2 = corners(*sq2)
    # separating axis theorem: 4 axes from each square
    for pts in (p1, p2):
        for i in range(4):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % 4]
            ax, ay = x2 - x1, y2 - y1
            L = math.hypot(ax, ay)
            if L < 1e-15:
                continue
            ax, ay = -ay / L, ax / L
            a1, b1 = _proj(p1, (ax, ay))
            a2, b2 = _proj(p2, (ax, ay))
            if b1 <= a2 + 1e-12 or b2 <= a1 + 1e-12:
                return False   # separated -> no interior overlap
    return True


def feasible(squares):
    for i in range(len(squares)):
        if not inside_unit(corners(*squares[i])):
            return False
        for j in range(i + 1, len(squares)):
            if squares_overlap(squares[i], squares[j]):
                return False
    return True


def total_side(squares):
    return sum(s[3] for s in squares)


# ----------------------------------------------------------------------
# Special constructions for small n
# ----------------------------------------------------------------------

def arrange_2(s):
    # two equal squares side by side (best known for n=2 is 2 equal squares in a row
    # giving sum = 2*(1/2) = 1? Actually two squares each side slightly > 1/2 is impossible;
    # two side by side each 1/2 -> sum 1. But we can tilt: known optimum ~ 1.035... )
    # We simply build two unit-square-optimal squares side by side.
    return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]


def arrange_1():
    return [(0.5, 0.5, 0.0, 1.0)]


def arrange_3():
    # three equal squares in an L-ish / strip. Best simple: 1/3 side each touching walls.
    # Rotated better known value but start with strip.
    return [(1/6, 0.5, 0.0, 1/3), (0.5, 1/6, 0.0, 1/3), (5/6, 0.5, 0.0, 1/3)]


def arrange_4():
    return [((i + 0.5) / 2, (j + 0.5) / 2, 0.0, 0.5) for i in range(2) for j in range(2)]


# ----------------------------------------------------------------------
# Greedy largest-first packing with candidate generation
# ----------------------------------------------------------------------

def candidate_positions(n, rng):
    """Some deterministic + random candidate (cx, cy, ang, side) attempts."""
    cands = []
    # random attempts
    for _ in range(4000):
        cx = rng.random()
        cy = rng.random()
        ang = rng.random()
        s = rng.random() * 0.7
        cands.append((cx, cy, ang, s))
    # small deterministic grid of axis aligned squares
    for gx in range(1, 8):
        for gy in range(1, 8):
            s = min(1.0 / gx, 1.0 / gy)
            for i in range(gx):
                for j in range(gy):
                    cands.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    return cands


def greedy_pack(n, rng, existing=None):
    """Return list of n squares via greedy largest-first placement."""
    squares = list(existing) if existing else []
    cands = candidate_positions(n, rng)
    # sort candidates by side descending
    cands.sort(key=lambda t: -t[3])
    while len(squares) < n:
        placed = False
        for cand in cands:
            cx, cy, ang, s = cand
            if s <= 1e-9:
                continue
            trial = (cx, cy, ang, s)
            if not inside_unit(corners(*trial)):
                continue
            ok = True
            for q in squares:
                if squares_overlap(trial, q):
                    ok = False
                    break
            if ok:
                squares.append(trial)
                placed = True
                break
        if not placed:
            # add a zero
            squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


# ----------------------------------------------------------------------
# Local optimisation
# ----------------------------------------------------------------------

def local_optimise(squares, iterations=4000, rng=None, scale=0.05):
    if rng is None:
        rng = random.Random(12345)
    sq = [list(s) for s in squares]
    n = len(sq)
    best = total_side(sq)
    best_state = [s[:] for s in sq]

    def try_move():
        nonlocal best, best_state
        i = rng.randrange(n)
        old = sq[i][:]
        # random mutation
        t = rng.random()
        if t < 0.35:
            sq[i][0] += rng.gauss(0, scale)
            sq[i][1] += rng.gauss(0, scale)
        elif t < 0.6:
            sq[i][2] += rng.gauss(0, scale)
        elif t < 0.9:
            sq[i][3] = max(0.0, sq[i][3] + rng.gauss(0, scale * 0.5))
        else:
            sq[i][0] += rng.gauss(0, scale)
            sq[i][1] += rng.gauss(0, scale)
            sq[i][2] += rng.gauss(0, scale)
            sq[i][3] = max(0.0, sq[i][3] + rng.gauss(0, scale * 0.4))
        # clamp centre into unit square
        sq[i][0] = min(1.0, max(0.0, sq[i][0]))
        sq[i][1] = min(1.0, max(0.0, sq[i][1]))
        if not feasible(sq):
            sq[i] = old
            return
        val = total_side(sq)
        if val >= best - 1e-12:
            if val > best:
                best = val
                best_state = [s[:] for s in sq]
        else:
            # accept small worsening sometimes (annealing-ish)
            if rng.random() < 0.02:
                pass
            else:
                sq[i] = old

    for _ in range(iterations):
        try_move()
    return [tuple(s) for s in best_state]


# ----------------------------------------------------------------------
# Main solve
# ----------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    rng = random.Random(987654321 + n)

    # special small cases
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        base = arrange_2(base_side())
    elif n == 3:
        base = arrange_3()
    elif n == 4:
        base = arrange_4()
    else:
        base = None

    best_result = None
    best_val = -1.0

    # multi-start greedy + local optimisation
    starts = []
    if base is not None:
        starts.append(base)
    for _ in range(4):
        starts.append(greedy_pack(n, rng))

    for st in starts:
        # ensure length
        if len(st) < n:
            st = list(st) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(st))
        st = st[:n]
        opt = local_optimise(st, iterations=3000, rng=rng, scale=0.06)
        val = total_side(opt)
        if val > best_val:
            best_val = val
            best_result = opt

    # final fine-tuning
    if best_result is not None:
        for sc in (0.02, 0.008, 0.003):
            best_result = local_optimise(best_result, iterations=2500, rng=rng, scale=sc)
            v = total_side(best_result)
            if v > best_val:
                best_val = v
            else:
                break

    # sanitize all into [0,1]
    out = []
    for (cx, cy, ang, s) in best_result:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = max(0.0, min(1.0, s))
        out.append((cx, cy, ang, s))
    out = out[:n]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out


def base_side():
    return 0.5
