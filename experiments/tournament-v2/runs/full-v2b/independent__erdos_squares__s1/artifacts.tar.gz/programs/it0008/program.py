import math
import random
from itertools import combinations

# ---------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------

def _rot(angle):
    """Return cosine and sine of angle in turns."""
    a = angle * 2.0 * math.pi
    return math.cos(a), math.sin(a)


def _corners(cx, cy, angle, side):
    """Return the four corners of a square (cx, cy, angle, side)."""
    c, s = _rot(angle)
    h = side * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + c * dx - s * dy, cy + s * dx + c * dy))
    return pts


def _overlap_sat(p1, p2):
    """SAT overlap test for two convex polygons given as point lists.
    Returns a positive penetration measure if they overlap, 0 if separated."""
    polys = (p1, p2)
    min_overlap = float('inf')
    for poly in polys:
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            # normal
            nx, ny = -ey, ex
            ln = math.hypot(nx, ny)
            if ln < 1e-15:
                continue
            nx /= ln
            ny /= ln
            # project both polys
            minA = min(x * nx + y * ny for x, y in p1)
            maxA = max(x * nx + y * ny for x, y in p1)
            minB = min(x * nx + y * ny for x, y in p2)
            maxB = max(x * nx + y * ny for x, y in p2)
            if maxA <= minB or maxB <= minA:
                return 0.0
            ov = min(maxA - minB, maxB - minA)
            if ov < min_overlap:
                min_overlap = ov
    return min_overlap if min_overlap != float('inf') else 0.0


def _inside_unit(poly, eps=1e-9):
    """Check if all corners are inside the unit square."""
    for x, y in poly:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def _total_penalty(squares):
    """Compute total overlap + out-of-bounds penalty."""
    n = len(squares)
    if n == 0:
        return 0.0
    polys = []
    for entry in squares:
        cx, cy, angle, side = entry
        if side <= 0.0:
            polys.append(None)
        else:
            polys.append(_corners(cx, cy, angle, side))
    pen = 0.0
    for i in range(n):
        pi = polys[i]
        if pi is None:
            continue
        # out of bounds
        for x, y in pi:
            if x < 0.0:
                pen += (-x) * (-x)
            elif x > 1.0:
                pen += (x - 1.0) * (x - 1.0)
            if y < 0.0:
                pen += (-y) * (-y)
            elif y > 1.0:
                pen += (y - 1.0) * (y - 1.0)
        for j in range(i + 1, n):
            pj = polys[j]
            if pj is None:
                continue
            ov = _overlap_sat(pi, pj)
            if ov > 0.0:
                pen += ov * ov
    return pen


def _is_feasible(squares, tol=1e-7):
    """Check feasibility: no significant overlap and all inside unit square."""
    n = len(squares)
    polys = []
    for entry in squares:
        cx, cy, angle, side = entry
        if side <= 0.0:
            polys.append(None)
        else:
            polys.append(_corners(cx, cy, angle, side))
    for i in range(n):
        pi = polys[i]
        if pi is None:
            continue
        for x, y in pi:
            if x < -tol or x > 1.0 + tol or y < -tol or y > 1.0 + tol:
                return False
        for j in range(i + 1, n):
            pj = polys[j]
            if pj is None:
                continue
            if _overlap_sat(pi, pj) > tol:
                return False
    return True


# ---------------------------------------------------------------
# Constructive heuristics
# ---------------------------------------------------------------

def _greedy_place(sides_order):
    """Place squares in order of sides_order (list of side lengths),
    choosing the best position via candidates based on already-placed squares
    and the unit square boundaries."""
    placed = []  # list of (cx, cy, angle, side)
    # Precompute a coarse grid of sample angles
    for side in sides_order:
        if side <= 1e-12:
            placed.append((0.5, 0.5, 0.0, 0.0))
            continue
        # Candidate centres
        candidates = []
        # Centers of existing squares' centers and corners
        for (cx, cy, ang, s) in placed:
            if s <= 0:
                continue
            candidates.append((cx, cy))
            for (px, py) in _corners(cx, cy, ang, s):
                candidates.append((px, py))
        # Grid
        m = 6
        for i in range(m + 1):
            for j in range(m + 1):
                candidates.append((i / m, j / m))
        # Try angles
        best = None
        best_pen = float('inf')
        # Coarse: try few angles
        angles = [0.0, 0.25, 0.125, 0.375]
        for ang in angles:
            c, s = _rot(ang)
            h = side * 0.5
            # For each candidate, compute exact centre so square inside
            for (px, py) in candidates:
                # Try a few offsets
                for ox in (-h, 0.0, h):
                    for oy in (-h, 0.0, h):
                        cx = px + ox
                        cy = py + oy
                        # clamp so inside
                        # compute half-extent in each axis
                        hx = abs(c) * h + abs(s) * h
                        hy = abs(s) * h + abs(c) * h
                        if cx - hx < -1e-9:
                            cx = hx
                        if cx + hx > 1.0 + 1e-9:
                            cx = 1.0 - hx
                        if cy - hy < -1e-9:
                            cy = hy
                        if cy + hy > 1.0 + 1e-9:
                            cy = 1.0 - hy
                        if cx - hx < -1e-9 or cx + hx > 1.0 + 1e-9:
                            continue
                        if cy - hy < -1e-9 or cy + hy > 1.0 + 1e-9:
                            continue
                        pen = 0.0
                        poly_new = _corners(cx, cy, ang, side)
                        for (ocx, ocy, oang, os) in placed:
                            if os <= 0:
                                continue
                            poly_old = _corners(ocx, ocy, oang, os)
                            ov = _overlap_sat(poly_new, poly_old)
                            if ov > 0:
                                pen += ov * ov
                                if pen > best_pen:
                                    break
                        if pen < best_pen - 1e-12:
                            best_pen = pen
                            best = (cx, cy, ang, side)
                            if pen < 1e-12:
                                break
                    if best_pen < 1e-12:
                        break
                if best_pen < 1e-12:
                    break
            if best_pen < 1e-12:
                break
        if best is None:
            best = (0.5, 0.5, 0.0, 0.0)
        placed.append(best)
    return placed


# ---------------------------------------------------------------
# Local optimization
# ---------------------------------------------------------------

def _optimize(squares, iterations=400, time_budget=None):
    """Simulated-annealing-like / random perturbation + feasibility projection
    to increase sum of sides while maintaining feasibility."""
    import time
    t0 = time.time()
    n = len(squares)
    current = [list(s) for s in squares]
    cur_pen = _total_penalty(current)

    best = [list(s) for s in current]
    best_pen = cur_pen

    # If infeasible initially, try to push into feasible via penalty gradient descent
    step = 0.02
    rng = random.Random(12345)

    # Improved penalty-based relaxation
    for it in range(iterations):
        if time_budget and time.time() - t0 > time_budget:
            break
        # Alternate: try increasing one square's side, then repair
        idx = rng.randrange(n)
        old = list(current[idx])
        # perturb: try increasing side slightly
        delta = rng.uniform(-0.01, 0.015)
        new_side = max(0.0, old[3] + delta)
        current[idx][3] = new_side
        # also small jitter
        if rng.random() < 0.3:
            current[idx][0] += rng.uniform(-0.005, 0.005)
            current[idx][1] += rng.uniform(-0.005, 0.005)
            current[idx][0] = min(1.0, max(0.0, current[idx][0]))
            current[idx][1] = min(1.0, max(0.0, current[idx][1]))
        if rng.random() < 0.2:
            current[idx][2] += rng.uniform(-0.02, 0.02)
            current[idx][2] = current[idx][2] % 1.0

        new_pen = _total_penalty(current)
        if new_pen <= cur_pen or rng.random() < math.exp(-(new_pen - cur_pen) / max(1e-6, 0.001)):
            cur_pen = new_pen
            if new_pen == 0.0:
                total = sum(s[3] for s in current)
                if total > sum(s[3] for s in best):
                    best = [list(s) for s in current]
                    best_pen = 0.0
        else:
            current[idx] = old

    # If best is still infeasible, try to scale down sides to make feasible
    if _total_penalty(best) > 1e-9:
        # push each square toward centre and shrink
        for _ in range(200):
            for i in range(n):
                if best[i][3] > 0:
                    best[i][3] *= 0.98
                    best[i][0] = 0.5 + (best[i][0] - 0.5) * 0.98
                    best[i][1] = 0.5 + (best[i][1] - 0.5) * 0.98
            if _total_penalty(best) < 1e-9:
                break

    return [tuple(s) for s in best]


# ---------------------------------------------------------------
# Main solver
# ---------------------------------------------------------------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n == 0:
        return []
    if n == 1:
        # One square: side 1, centred
        return [(0.5, 0.5, 0.0, 1.0)]

    # Limit n for performance
    # We'll handle large n with grid and small n with optimization
    import time
    t_start = time.time()

    # Candidate strategies
    best_result = None
    best_sum = -1.0

    # Strategy A: grid (fallback, always feasible)
    k = math.isqrt(n)
    if k > 0:
        side = 1.0 / k
        grid_squares = []
        cnt = 0
        for i in range(k):
            for j in range(k):
                if cnt >= n:
                    break
                grid_squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
                cnt += 1
            if cnt >= n:
                break
        # pad with zeros
        while len(grid_squares) < n:
            grid_squares.append((0.5, 0.5, 0.0, 0.0))
        # Extra space: try to add one more row/col partially by shrinking
        # Simple improvement: if n > k*k, fill remaining with smaller squares
        # But grid is fallback; we'll do better below.

    # Strategy B: greedy + optimize
    # Order sides descending for greedy
    # For small n, use simple equal sides; for larger, use varied
    if n <= 6:
        # Try a few constructions
        # Heuristic: all equal sides equal to sqrt(n) pack
        # For n=2: two squares side 1/2? Actually best: two squares of side sqrt(2)/2 ≈0.707 each? 
        # Two unit squares of side 1/2 rotated 45 deg? Let's just use optimizer.
        pass

    # Build several initial packings and optimize

    # Determine number of active squares (many will be zero)
    # Try to pack as many non-zero as possible.

    # Heuristic initial sides:
    # Use square root packing: side ~ 1/sqrt(n_active)
    # We'll try a few active counts.
    results = []

    # Attempt 1: all n with equal sides roughly 1/sqrt(n), arranged in grid, then optimize
    # Attempt 2: greedy with decreasing sides
    # Attempt 3: random restart

    # Limit optimization for large n
    if n > 80:
        # Use grid directly with slight optimization off
        k = math.isqrt(n)
        side = 1.0 / k
        squares = []
        for i in range(k):
            for j in range(k):
                if len(squares) >= n:
                    break
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
            if len(squares) >= n:
                break
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
        # Fill extra cells with smaller squares by subdividing? Too complex.
        return squares[:n]

    # Small/medium n: optimize
    # Initial: grid
    k = math.isqrt(n)
    side0 = 1.0 / k if k > 0 else 1.0

    # Try multiple initializations
    init_list = []

    # Init 1: grid
    sq1 = []
    for i in range(k):
        for j in range(k):
            if len(sq1) >= n:
                break
            sq1.append(((i + 0.5) * side0, (j + 0.5) * side0, 0.0, side0))
        if len(sq1) >= n:
            break
    while len(sq1) < n:
        sq1.append((0.5, 0.5, 0.0, 0.0))
    init_list.append(sq1)

    # Init 2: greedy decreasing sides
    # Sides geometric decreasing
    sides = []
    for i in range(n):
        sides.append(1.0 / math.sqrt(n) * (1.0 - 0.1 * i / n))
    # Try descending order
    sides_desc = sorted(sides, reverse=True)
    sq2 = _greedy_place(sides_desc)
    init_list.append(sq2)

    # Init 3: all equal, random rotations
    sq3 = []
    for i in range(n):
        r = 1.0 / math.sqrt(n) * 0.9
        sq3.append((0.5, 0.5, random.random(), r))
    init_list.append(sq3)

    # Init 4: n=2 special: two squares side 1/sqrt(2) each rotated 45deg? 
    if n == 2:
        s = 1.0 / math.sqrt(2)
        # place side by side along diagonal
        sq4 = [(0.25, 0.5, 0.25, s), (0.75, 0.5, 0.25, s)]
        init_list.append(sq4)

    # Init 5: mix grid and rotations
    sq5 = [list(s) for s in sq1]
    for i in range(n):
        if sq5[i][3] > 0:
            sq5[i][2] = 0.125 * (i % 4)
    init_list.append([tuple(s) for s in sq5])

    # Optimize each initialization with moderate budget
    time_limit = 50.0
    per_init_budget = (time_limit - (time.time() - t_start)) / max(1, len(init_list))
    per_init_budget = max(1.0, min(per_init_budget, 12.0))

    for init in init_list:
        if time.time() - t_start > time_limit - 1.0:
            break
        # First make feasible if needed
        work = [list(s) for s in init]
        if _total_penalty(work) > 1e-9:
            # try to shrink to feasibility
            scale = 0.9
            for _ in range(300):
                pen = _total_penalty(work)
                if pen < 1e-12:
                    break
                for i in range(len(work)):
                    if work[i][3] > 0:
                        work[i][3] *= scale
                scale = 0.95 + 0.04 * scale
                if scale < 0.01:
                    break
            # if still infeasible, reduce all to near zero except first
            if _total_penalty(work) > 1e-9:
                for i in range(1, len(work)):
                    work[i][3] = 0.0
                work[0][3] = min(work[0][3], 1.0)
                work[0][0] = 0.5
                work[0][1] = 0.5

        opt = _optimize(work, iterations=500, time_budget=per_init_budget)
        if _total_penalty(opt) > 1e-7:
            # last resort: shrink
            s = 0.95
            for _ in range(200):
                for i in range(len(opt)):
                    opt[i] = (opt[i][0] * 0.5 + 0.25, opt[i][1] * 0.5 + 0.25,
                              opt[i][2], opt[i][3] * s)
                if _total_penalty([list(x) for x in opt]) < 1e-9:
                    break
                s *= 0.97
        if _is_feasible(opt):
            total = sum(s[3] for s in opt)
            if total > best_sum:
                best_sum = total
                best_result = opt

    # Also run a longer optimization from the best found so far
    if best_result is not None and time.time() - t_start < time_limit - 3.0:
        remaining = time_limit - (time.time() - t_start)
        best_result = _optimize([list(s) for s in best_result],
                                iterations=1000,
                                time_budget=max(1.0, remaining - 1.0))
        if _total_penalty([list(s) for s in best_result]) > 1e-9:
            # repair by shrinking all
            for _ in range(300):
                for i in range(len(best_result)):
                    best_result[i] = (0.5 + (best_result[i][0] - 0.5) * 0.98,
                                      0.5 + (best_result[i][1] - 0.5) * 0.98,
                                      best_result[i][2], best_result[i][3] * 0.98)
                if _total_penalty([list(s) for s in best_result]) < 1e-9:
                    break

    if best_result is None or not _is_feasible(best_result):
        # fallback grid
        k = math.isqrt(n)
        side = 1.0 / k if k > 0 else 0.0
        squares = []
        for i in range(k):
            for j in range(k):
                if len(squares) >= n:
                    break
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
            if len(squares) >= n:
                break
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
        return squares[:n]

    # Ensure all values are in [0,1]
    result = []
    for (cx, cy, ang, side) in best_result:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        side = min(1.0, max(0.0, side))
        result.append((cx, cy, ang, side))
    # Final feasibility check: if fails, shrink slightly
    if not _is_feasible(result):
        s = 0.98
        for _ in range(200):
            result = [(min(1.0, max(0.0, x * 0.5 + 0.25)),
                       min(1.0, max(0.0, y * 0.5 + 0.25)),
                       a, z * s) for (x, y, a, z) in result]
            if _is_feasible(result):
                break
            s *= 0.98

    # If still infeasible, fallback
    if not _is_feasible(result):
        k = math.isqrt(n)
        side = 1.0 / k if k > 0 else 0.0
        squares = []
        for i in range(k):
            for j in range(k):
                if len(squares) >= n:
                    break
                squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
            if len(squares) >= n:
                break
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
        return squares[:n]

    return result[:n]
