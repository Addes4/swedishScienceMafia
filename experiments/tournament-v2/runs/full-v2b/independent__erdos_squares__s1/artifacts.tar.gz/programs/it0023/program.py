"""Packing squares in the unit square to maximise total side length.

Strategy
--------
For a given n we try a family of candidate *size multisets*: a base near-grid
of equal squares (k = floor(sqrt(n)) of them) plus a small number of extra
squares whose sides form a short decreasing geometric tail.  For each candidate
multiset we pack the squares with a randomized greedy "lowest-left corner"
placement where a square may use any of a small set of orientations.  We keep
the best feasible packing found within a time budget.

The placement routine works with the candidate list sorted by decreasing side
(the big squares first), then tries to insert each square by scanning a large
number of candidate corner points generated from the already placed squares.
Because all coordinates are in the unit square and the squares need only have
pairwise-disjoint interiors, feasibility is checked by an exact SAT-style
overlap test that accounts for rotations.
"""

import math
import random
import time

# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

# A square with centre (cx, cy), angle t (fraction of a full turn), side s.
# Its four corners are obtained by rotating (+-s/2, +-s/2) by 2*pi*t.

def corners(cx, cy, t, s):
    """Return the 4 corners of the square."""
    a = 2.0 * math.pi * t
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _proj_range(pts, ax, ay):
    vals = [x * ax + y * ay for (x, y) in pts]
    return min(vals), max(vals)


def overlap(c1, c2):
    """True if the interiors of two convex polygons overlap (SAT)."""
    # Use separating-axis theorem on the 4 edges of each square (only the
    # unique axes; for squares two axes per square suffice, but 4 is cheap).
    for poly in (c1, c2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ax, ay = -(y2 - y1), (x2 - x1)
            ln = math.hypot(ax, ay)
            if ln < 1e-15:
                continue
            ax /= ln
            ay /= ln
            lo1, hi1 = _proj_range(c1, ax, ay)
            lo2, hi2 = _proj_range(c2, ax, ay)
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return False
    return True


def inside_unit(pts, eps=1e-9):
    for x, y in pts:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def square_corners(cx, cy, t, s):
    return corners(cx, cy, t, s)


def feasible(cx, cy, t, s, placed):
    """Check a candidate square against placed squares (list of (cx,cy,t,s))."""
    if s <= 1e-12:
        return (0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0)
    c = corners(cx, cy, t, s)
    if not inside_unit(c):
        return False
    for (px, py, pt, ps) in placed:
        if ps <= 1e-12:
            continue
        pc = corners(px, py, pt, ps)
        if overlap(c, pc):
            return False
    return True


# ---------------------------------------------------------------------------
# Candidate corner generation for greedy placement
# ---------------------------------------------------------------------------

def candidate_positions(placed, eps=1e-9):
    """Generate candidate centres where the next square might be tucked in."""
    pts = [(0.0, 0.0)]
    for (px, py, pt, ps) in placed:
        if ps <= 1e-12:
            continue
        c = corners(px, py, pt, ps)
        pts.extend(c)
    # Also midpoints along the boundary and interior grid, plus points just
    # outside each placed corner (the classic "corner" placement).
    res = set()
    for (x, y) in pts:
        res.add((min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0)))
    # Dense boundary samples
    steps = 40
    for i in range(steps + 1):
        u = i / steps
        res.add((u, 0.0))
        res.add((u, 1.0))
        res.add((0.0, u))
        res.add((1.0, u))
    # Some interior points for small squares
    g = 12
    for i in range(1, g):
        for j in range(1, g):
            res.add((i / g, j / g))
    return list(res)


def try_place(s, placed, angles, rng, tries=1):
    """Try to place a square of side s; return (cx,cy,t,s) or None."""
    if s <= 1e-12:
        return (0.5, 0.5, 0.0, 0.0)
    cands = candidate_positions(placed)
    rng.shuffle(cands)
    # Sort by a heuristic: prefer low y, then low x (bottom-left packing).
    cands.sort(key=lambda p: (p[1], p[0]))
    for ang in angles:
        for (cx, cy) in cands:
            if feasible(cx, cy, ang, s, placed):
                return (cx, cy, ang, s)
    return None


# ---------------------------------------------------------------------------
# Size multisets
# ---------------------------------------------------------------------------

def size_candidates(n):
    """Yield plausible side-length lists (decreasing) for n squares."""
    out = []

    # 1. Pure equal grid (k = floor(sqrt(n)) big squares, remaining tiny)
    k = max(1, int(math.isqrt(n)))
    base = 1.0 / k
    if k * k >= n:
        out.append([base] * n)
    else:
        extra = n - k * k
        # shrink the big ones slightly to make room for extras
        tail = [base * (0.5 ** (i + 1)) for i in range(extra)]
        big = base * (1.0 - 0.02 * extra / max(1, k))
        if big <= 0:
            big = base * 0.5
        out.append([big] * (k * k) + tail)

    # 2. Slightly perturbed equal sizes
    for scale in (1.0, 0.98, 0.95, 1.02):
        sizes = [base * scale] * n
        out.append(sizes)

    # 3. Geometric tail variants: k^2 equal squares + geometric extras
    for taildecay in (0.3, 0.4, 0.5, 0.6, 0.7):
        extra = n - k * k
        if extra <= 0:
            continue
        tail = [base * (taildecay ** (i + 1)) for i in range(extra)]
        # make big squares a bit smaller so tail fits
        shrink = 1.0
        for t in tail:
            shrink -= t / (base * 1.0)
        if shrink < 0.3:
            shrink = 0.3
        big = base * shrink
        sizes = [big] * (k * k) + tail
        out.append(sizes)

    # 4. One extra row/column style: k*(k) grid then split one big square
    if n > k * k:
        extra = n - k * k
        # replace one big square by several smaller ones
        sizes = [base] * (k * k - 1)
        # subdivide a square of side base into (m+1) pieces roughly
        m = extra + 1
        sub = base / math.sqrt(m)
        sizes += [sub] * m
        out.append(sizes)

    # 5. Random perturbations of the best-looking candidates
    return out


# ---------------------------------------------------------------------------
# Packing
# ---------------------------------------------------------------------------

def pack(sizes, time_limit, rng, angles):
    """Greedily pack squares (sorted decreasing) within time_limit."""
    order = sorted(range(len(sizes)), key=lambda i: -sizes[i])
    placed = []
    result = [None] * len(sizes)

    for idx in order:
        s = sizes[idx]
        if s <= 1e-12:
            result[idx] = (0.5, 0.5, 0.0, 0.0)
            continue
        if time.time() > time_limit:
            # fall back: place at centre with zero size
            result[idx] = (0.5, 0.5, 0.0, 0.0)
            continue
        spot = try_place(s, placed, angles, rng)
        if spot is None:
            # try smaller
            shrink = 0.98
            placed_ok = False
            for _ in range(60):
                s2 = s * shrink
                spot = try_place(s2, placed, angles, rng)
                if spot is not None:
                    result[idx] = spot
                    placed.append(spot)
                    placed_ok = True
                    break
                shrink *= 0.98
            if not placed_ok:
                result[idx] = (0.5, 0.5, 0.0, 0.0)
        else:
            result[idx] = spot
            placed.append(spot)

    for i in range(len(result)):
        if result[i] is None:
            result[i] = (0.5, 0.5, 0.0, 0.0)
    return result


def score(result):
    return sum(max(0.0, r[3]) for r in result)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    start = time.time()
    budget = 55.0
    rng = random.Random(12345 + n)

    angles_sets = [
        [0.0],
        [0.0, 0.25],
        [0.0, 0.125, 0.25, 0.375],
        [0.0, 0.0625, 0.125, 0.1875, 0.25, 0.3125, 0.375, 0.4375],
    ]

    best = None
    best_score = -1.0

    cands = size_candidates(n)
    # Always include a pure "k grid" fallback
    k = max(1, int(math.isqrt(n)))
    fallback_side = 1.0 / k
    fallback = [((i + 0.5) * fallback_side, (j + 0.5) * fallback_side, 0.0, fallback_side)
                for i in range(k) for j in range(k)]
    fallback += [(0.5, 0.5, 0.0, 0.0)] * (n - len(fallback))
    best = fallback[:n]
    best_score = score(best)

    for sizes in cands:
        if time.time() - start > budget * 0.4:
            break
        # normalise sizes so that total area <= 1
        total_area = sum(s * s for s in sizes)
        if total_area > 1.0:
            f = math.sqrt(1.0 / total_area) * 0.999
            sizes = [s * f for s in sizes]
        sizes = sorted(sizes, reverse=True)
        for angles in angles_sets:
            if time.time() - start > budget * 0.8:
                break
            r = pack(sizes, start + budget, rng, angles)
            sc = score(r)
            if sc > best_score:
                best_score = sc
                best = r

    # Small local refinement: try shrinking/rotating the smallest squares
    # to fit better.  (Kept simple to stay in budget.)
    if time.time() - start < budget * 0.9:
        improved = True
        b = [list(x) for x in best]
        for _ in range(200):
            if time.time() - start > budget * 0.95:
                break
            if not improved:
                break
            improved = False
            order = sorted(range(n), key=lambda i: b[i][3])
            for i in order:
                if b[i][3] <= 1e-9:
                    continue
                cx, cy, t, s = b[i]
                for ds in (0.005, -0.005, 0.02, -0.02):
                    s2 = s + ds
                    if s2 <= 0:
                        continue
                    placed = [tuple(b[j]) for j in range(n) if j != i and b[j][3] > 1e-12]
                    for dt in (0.0, 0.01, -0.01, 0.03, -0.03):
                        t2 = (t + dt) % 1.0
                        for dcx, dcy in ((0, 0), (0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01)):
                            ncx, ncy = cx + dcx, cy + dcy
                            if feasible(ncx, ncy, t2, s2, placed):
                                b[i] = [ncx, ncy, t2, s2]
                                improved = True
                                break
                        if improved:
                            break
                    if improved:
                        break
        sc = score([tuple(x) for x in b])
        if sc > best_score:
            best_score = sc
            best = [tuple(x) for x in b]

    # Clip to [0,1]
    out = []
    for (cx, cy, t, s) in best:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        t = t % 1.0
        s = min(1.0, max(0.0, s))
        out.append((cx, cy, t, s))
    return out[:n]
