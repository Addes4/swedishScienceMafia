import math
import random
from scipy.optimize import minimize

# ---------- helpers ----------

def _corners(cx, cy, ang, s):
    """Return the 4 corners of a square with centre (cx,cy), angle fraction, side s."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * ca - dy * sa
        y = cy + dx * sa + dy * ca
        pts.append((x, y))
    return pts


def _sat_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Return True if interiors of the two squares overlap (SAT on both axes)."""
    if s1 <= 1e-12 or s2 <= 1e-12:
        return False
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)
    # axes of square 1
    for i in range(2):
        ax = p1[i + 1][0] - p1[i][0]
        ay = p1[i + 1][1] - p1[i][1]
        # project p1
        min1 = max1 = p1[0][0] * ax + p1[0][1] * ay
        for p in p1[1:]:
            v = p[0] * ax + p[1] * ay
            if v < min1: min1 = v
            if v > max1: max1 = v
        min2 = max2 = p2[0][0] * ax + p2[0][1] * ay
        for p in p2[1:]:
            v = p[0] * ax + p[1] * ay
            if v < min2: min2 = v
            if v > max2: max2 = v
        if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
            return False
    # axes of square 2
    for i in range(2):
        ax = p2[i + 1][0] - p2[i][0]
        ay = p2[i + 1][1] - p2[i][1]
        min1 = max1 = p1[0][0] * ax + p1[0][1] * ay
        for p in p1[1:]:
            v = p[0] * ax + p[1] * ay
            if v < min1: min1 = v
            if v > max1: max1 = v
        min2 = max2 = p2[0][0] * ax + p2[0][1] * ay
        for p in p2[1:]:
            v = p[0] * ax + p[1] * ay
            if v < min2: min2 = v
            if v > max2: max2 = v
        if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
            return False
    return True


# ---------- initial layouts ----------

def _grid_layout(n):
    """Largest k x k grid plus tiny squares in leftover cells."""
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    squares = squares[:n]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _random_layout(n, rng):
    """Random non-overlapping axis-aligned greedy fill, then leftover zeros."""
    squares = []
    # simple random sequential addition
    attempts = 0
    while len(squares) < n and attempts < 20000:
        attempts += 1
        s = rng.uniform(0.02, 0.3)
        x = rng.uniform(s / 2, 1 - s / 2)
        y = rng.uniform(s / 2, 1 - s / 2)
        a = rng.choice([0.0, 0.25])
        ok = True
        for (cx, cy, ang, side) in squares:
            if _sat_overlap(x, y, a, s, cx, cy, ang, side):
                ok = False
                break
        if ok:
            squares.append((x, y, a, s))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


# ---------- optimization ----------

def _unpack(z, n):
    out = []
    for i in range(n):
        out.append((z[4 * i], z[4 * i + 1], z[4 * i + 2], z[4 * i + 3]))
    return out


def _objective(z, n, w_bound=20.0, w_overlap=50.0):
    """Negative sum of sides plus penalties for out-of-bounds and overlap."""
    sq = _unpack(z, n)
    total = 0.0
    pen = 0.0
    # inside penalty: each corner must be within [0,1]^2
    for (cx, cy, a, s) in sq:
        total += s
        if s > 0:
            for (x, y) in _corners(cx, cy, a, s):
                if x < 0:
                    pen += w_bound * (0 - x) ** 2
                elif x > 1:
                    pen += w_bound * (x - 1) ** 2
                if y < 0:
                    pen += w_bound * (0 - y) ** 2
                elif y > 1:
                    pen += w_bound * (y - 1) ** 2
    # overlap penalty: approximate by overlapping AABB of the rotated square
    # (kept cheap: use bounding box halves)
    boxes = []
    for (cx, cy, a, s) in sq:
        if s <= 1e-12:
            boxes.append((cx, cy, 0.0, 0.0))
            continue
        ar = a * 2 * math.pi
        c, sn = abs(math.cos(ar)), abs(math.sin(ar))
        hx = 0.5 * s * (c + sn)
        hy = 0.5 * s * (c + sn)
        boxes.append((cx, cy, hx, hy))
    for i in range(n):
        xi, yi, hxi, hyi = boxes[i]
        for j in range(i + 1, n):
            xj, yj, hxj, hyj = boxes[j]
            ox = (hxi + hxj) - abs(xi - xj)
            oy = (hyi + hyj) - abs(yi - yj)
            if ox > 0 and oy > 0:
                pen += w_overlap * ox * oy
    return -total + pen


def _optimize(squares, n, rng, maxiter=400):
    """Run SLSQP-ish L-BFGS-B on the packed representation."""
    z0 = []
    bounds = []
    for (cx, cy, a, s) in squares:
        z0 += [cx, cy, a % 1.0, max(0.0, s)]
        bounds += [(0.0, 1.0), (0.0, 1.0), (-2.0, 2.0), (0.0, 1.0)]
    z0 = [max(b[0], min(b[1], v)) for v, b in zip(z0, bounds)]

    def fun(z):
        return _objective(z, n)

    try:
        res = minimize(fun, z0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': maxiter, 'maxfun': maxiter * 10,
                                'ftol': 1e-10, 'gtol': 1e-10})
        z = res.x
    except Exception:
        z = z0
    sq = _unpack(z, n)
    # normalize angles
    out = []
    for (cx, cy, a, s) in sq:
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        a = a % 1.0
        s = max(0.0, min(1.0, s))
        out.append((cx, cy, a, s))
    return out


def _repair(squares, n):
    """Remove overlaps using SAT, shrinking smaller squares first, clamp inside."""
    sq = [list(t) for t in squares]
    # clamp inside by moving/shrinking
    for it in range(200):
        changed = False
        for i in range(n):
            cx, cy, a, s = sq[i]
            if s <= 0:
                continue
            # ensure inside: find worst violation
            pts = _corners(cx, cy, a, s)
            minx = min(p[0] for p in pts)
            maxx = max(p[0] for p in pts)
            miny = min(p[1] for p in pts)
            maxy = max(p[1] for p in pts)
            dx = 0.0
            dy = 0.0
            if minx < 0: dx = -minx
            if maxx > 1: dx = 1 - maxx
            if miny < 0: dy = -miny
            if maxy > 1: dy = 1 - maxy
            if dx != 0 or dy != 0:
                cx += dx
                cy += dy
                sq[i] = [cx, cy, a, s]
                changed = True
                pts = _corners(cx, cy, a, s)
                minx = min(p[0] for p in pts)
                maxx = max(p[0] for p in pts)
                miny = min(p[1] for p in pts)
                maxy = max(p[1] for p in pts)
                if minx < -1e-9 or maxx > 1 + 1e-9 or miny < -1e-9 or maxy > 1 + 1e-9:
                    # shrink
                    scale = s * 0.98
                    sq[i][3] = max(0.0, scale)
                    changed = True
        # resolve overlaps
        for i in range(n):
            for j in range(i + 1, n):
                xi, yi, ai, si = sq[i]
                xj, yj, aj, sj = sq[j]
                if si <= 0 or sj <= 0:
                    continue
                if _sat_overlap(xi, yi, ai, si, xj, yj, aj, sj):
                    # shrink smaller one
                    if si <= sj:
                        sq[i][3] = max(0.0, si * 0.97)
                    else:
                        sq[j][3] = max(0.0, sj * 0.97)
                    changed = True
        if not changed:
            break
    return [tuple(t) for t in sq]


def _score(squares):
    return sum(s for (_, _, _, s) in squares)


def _feasible(squares, n):
    # check inside and no overlap
    for (cx, cy, a, s) in squares:
        if s < 0:
            return False
        if s > 0:
            for (x, y) in _corners(cx, cy, a, s):
                if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                    return False
    for i in range(n):
        for j in range(i + 1, n):
            xi, yi, ai, si = squares[i]
            xj, yj, aj, sj = squares[j]
            if _sat_overlap(xi, yi, ai, si, xj, yj, aj, sj):
                return False
    return True


# ---------- main ----------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    candidates = []

    # candidate 1: grid
    candidates.append(_grid_layout(n))

    # candidate 2: grid with 45-degree rotation for k*k <= n
    k = max(1, math.isqrt(n))
    if k * k >= n:
        g = _grid_layout(n)
        rot = []
        for (cx, cy, a, s) in g:
            rot.append((cx, cy, 0.25, s))
        candidates.append(rot)

    # candidate 3..: random layouts
    for _ in range(3):
        candidates.append(_random_layout(n, rng))

    best = None
    best_score = -1.0

    for cand in candidates:
        # optimize
        opt = _optimize(cand, n, rng)
        rep = _repair(opt, n)
        # final polish on repaired
        opt2 = _optimize(rep, n, rng, maxiter=300)
        rep2 = _repair(opt2, n)
        score = _score(rep2)
        if _feasible(rep2, n) and score > best_score:
            best_score = score
            best = rep2

    # local search: random perturbation + optimize
    if best is not None:
        for trial in range(6):
            cand = []
            for (cx, cy, a, s) in best:
                cand.append((
                    max(0.0, min(1.0, cx + rng.uniform(-0.01, 0.01))),
                    max(0.0, min(1.0, cy + rng.uniform(-0.01, 0.01))),
                    (a + rng.uniform(-0.02, 0.02)) % 1.0,
                    max(0.0, s * rng.uniform(0.98, 1.02)),
                ))
            opt = _optimize(cand, n, rng, maxiter=250)
            rep = _repair(opt, n)
            score = _score(rep)
            if _feasible(rep, n) and score > best_score:
                best_score = score
                best = rep

    if best is None or not _feasible(best, n):
        best = _grid_layout(n)

    # guarantee length n
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
