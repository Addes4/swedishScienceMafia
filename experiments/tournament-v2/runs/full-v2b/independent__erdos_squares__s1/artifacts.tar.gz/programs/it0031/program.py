import math
import random
from functools import lru_cache

import numpy as np
from scipy.optimize import minimize, differential_evolution

# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _corners(cx, cy, ang, s):
    """Return 4 corners of square with centre (cx,cy), angle ang fraction of turn, side s."""
    if s <= 0:
        return np.array([[cx, cy]] * 4)
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    # local corners: (-h,-h), (h,-h), (h,h), (-h,h)
    loc = np.array([[-h, -h], [h, -h], [h, h], [-h, h]])
    rot = np.array([[c, -sn], [sn, c]])
    return loc @ rot.T + np.array([cx, cy])


def _overlap_area_sat(ax, ay, aa, asz, bx, by, ba, bsz):
    """Approximate overlap check for two squares using SAT on their corners.
    Returns True if interiors overlap (positive area overlap)."""
    if asz <= 0 or bsz <= 0:
        return False
    A = _corners(ax, ay, aa, asz)
    B = _corners(bx, by, ba, bsz)
    # Separating axis theorem: axes are normals to edges of both squares
    axes = []
    for poly in (A, B):
        for i in range(4):
            p1 = poly[i]
            p2 = poly[(i + 1) % 4]
            edge = p2 - p1
            # normal
            axes.append(np.array([-edge[1], edge[0]]))
    for axis in axes:
        nrm = np.linalg.norm(axis)
        if nrm < 1e-15:
            continue
        axis = axis / nrm
        projA = A @ axis
        projB = B @ axis
        if projA.max() <= projB.min() + 1e-12 or projB.max() <= projA.min() + 1e-12:
            return False
    return True


def _inside_unit(cx, cy, ang, s):
    if s <= 0:
        return True
    C = _corners(cx, cy, ang, s)
    if np.any(C < -1e-9) or np.any(C > 1.0 + 1e-9):
        return False
    return True


def _valid_solution(sol):
    n = len(sol)
    for i in range(n):
        cx, cy, ang, s = sol[i]
        if not _inside_unit(cx, cy, ang, s):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap_area_sat(*sol[i], *sol[j]):
                return False
    return True


def _score(sol):
    return sum(s[3] for s in sol)

# ---------------------------------------------------------------------------
# Heuristic: guillotine / recursive subdivision
# ---------------------------------------------------------------------------

def _guillotine_pack(rect, n):
    """Pack n squares (axis aligned) into rectangle (x,y,w,h).
    Returns list of (cx, cy, 0.0, s) relative to rect origin + offset.
    Uses a simple greedy recursive split."""
    x, y, w, h = rect
    if n <= 0:
        return []
    if n == 1:
        s = min(w, h)
        return [(x + w * 0.5, y + h * 0.5, 0.0, s)]
    # choose split: vertically or horizontally
    # aim for roughly equal areas
    # try vertical split
    best = None
    best_val = -1
    # candidate splits
    for frac in [i / 10.0 for i in range(1, 10)]:
        w1 = w * frac
        w2 = w - w1
        # allocate n1 to first
        for n1 in range(1, n):
            n2 = n - n1
            # estimate: if equal area per square, ability
            # just compute recursively small
            if n1 <= 6 and n2 <= 6:
                r1 = _guillotine_pack((x, y, w1, h), n1)
                r2 = _guillotine_pack((x + w1, y, w2, h), n2)
                val = sum(q[3] for q in r1) + sum(q[3] for q in r2)
                if val > best_val:
                    best_val = val
                    best = (r1, r2, 'v', frac, n1)
    # horizontal
    for frac in [i / 10.0 for i in range(1, 10)]:
        h1 = h * frac
        h2 = h - h1
        for n1 in range(1, n):
            n2 = n - n1
            if n1 <= 6 and n2 <= 6:
                r1 = _guillotine_pack((x, y, w, h1), n1)
                r2 = _guillotine_pack((x, y + h1, w, h2), n2)
                val = sum(q[3] for q in r1) + sum(q[3] for q in r2)
                if val > best_val:
                    best_val = val
                    best = (r1, r2, 'h', frac, n1)
    if best is None:
        # fallback: equal squares grid
        k = math.isqrt(n)
        if k * k == n:
            s = min(w, h) / k
            res = []
            for i in range(k):
                for j in range(k):
                    res.append((x + (i + 0.5) * s, y + (j + 0.5) * s, 0.0, s))
            return res
        # simple equal
        s = min(w, h) * 0.5
        if s > 0:
            return [(x + w * 0.5, y + h * 0.5, 0.0, s)] + [(x, y, 0.0, 0.0)] * (n - 1)
        else:
            return [(x + w * 0.5, y + h * 0.5, 0.0, 0.0)] * n
    r1, r2, _, _, _ = best
    return r1 + r2


def _greedy_large(n):
    """For larger n use greedy row packing (axis-aligned) with decreasing sizes."""
    # start with squares roughly equal, then adjust
    k = math.isqrt(n)
    s = 1.0 / k
    sol = []
    for i in range(k):
        for j in range(k):
            if len(sol) >= n:
                break
            sol.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        if len(sol) >= n:
            break
    # fill remaining with zero
    while len(sol) < n:
        sol.append((0.5, 0.5, 0.0, 0.0))
    return sol[:n]

# ---------------------------------------------------------------------------
# Gradient-based refinement for small n
# ---------------------------------------------------------------------------

def _refine(sol, maxiter=200):
    """Local coordinate descent: try moving / resizing each square."""
    n = len(sol)
    sol = [list(s) for s in sol]
    best_score = _score(sol)
    improved = True
    rng = random.Random(42)
    for it in range(maxiter):
        improved = False
        for i in range(n):
            cx, cy, ang, s = sol[i]
            # try increasing size
            for ds in [0.02, 0.01, 0.005, 0.002, 0.001]:
                ns = s + ds
                if ns > 1.0:
                    continue
                # try small shifts
                for dcx in [0.0, 0.005, -0.005, 0.01, -0.01]:
                    for dcy in [0.0, 0.005, -0.005, 0.01, -0.01]:
                        ncx = cx + dcx
                        ncy = cy + dcy
                        if not (0 <= ncx <= 1 and 0 <= ncy <= 1):
                            continue
                        if not _inside_unit(ncx, ncy, ang, ns):
                            continue
                        # check against all others
                        ok = True
                        for j in range(n):
                            if j == i:
                                continue
                            if _overlap_area_sat(ncx, ncy, ang, ns, *sol[j]):
                                ok = False
                                break
                        if ok:
                            sol[i] = [ncx, ncy, ang, ns]
                            cx, cy, ang, s = sol[i]
                            improved = True
                            break
                    if improved:
                        break
                if improved:
                    break
            if improved:
                # also try rotation for this square
                for dang in [0.01, -0.01, 0.02, -0.02, 0.05, -0.05]:
                    nang = (ang + dang) % 1.0
                    if not _inside_unit(cx, cy, nang, s):
                        continue
                    ok = True
                    for j in range(n):
                        if j == i:
                            continue
                        if _overlap_area_sat(cx, cy, nang, s, *sol[j]):
                            ok = False
                            break
                    if ok:
                        sol[i] = [cx, cy, nang, s]
                        ang = nang
                        improved = True
                        break
        best_score = _score(sol)
        if not improved:
            break
    return [tuple(s) for s in sol]


def _init_grid(n):
    """Initial solution: k x k grid plus small squares."""
    k = math.isqrt(n)
    s = 1.0 / k
    sol = []
    for i in range(k):
        for j in range(k):
            sol.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    # remaining: distribute along edges or make slightly smaller to fit more
    rem = n - k * k
    if rem > 0:
        # try to fit rem squares by shrinking grid
        # use recursive guillotine for total n
        sol2 = _guillotine_pack((0, 0, 1, 1), n)
        if len(sol2) == n and _valid_solution(sol2):
            if _score(sol2) > _score(sol):
                sol = sol2
        # otherwise place remaining as zero-size
        while len(sol) < n:
            sol.append((0.5, 0.5, 0.0, 0.0))
        sol = sol[:n]
    return sol


# ---------------------------------------------------------------------------
# Main solve
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s), (0.5, 0.75, 0.0, s)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # Get initial guess
    if n <= 25:
        init = _init_grid(n)
    else:
        init = _greedy_large(n)

    # Try guillotine for medium
    if n <= 20:
        g = _guillotine_pack((0, 0, 1, 1), n)
        if len(g) == n and _valid_solution(g) and _score(g) > _score(init):
            init = g

    # Refine
    sol = _refine(init, maxiter=100 if n <= 30 else 40)

    # Ensure valid
    if not _valid_solution(sol) or len(sol) != n:
        # fallback to grid
        sol = _init_grid(n)

    # final check
    if not _valid_solution(sol):
        # brute fallback: shrink all sizes until valid
        sol = [list(s) for s in sol]
        for _ in range(200):
            ok = True
            for i in range(n):
                if not _inside_unit(*sol[i]):
                    sol[i][3] *= 0.95
                    ok = False
            for i in range(n):
                for j in range(i + 1, n):
                    if _overlap_area_sat(*sol[i], *sol[j]):
                        sol[i][3] *= 0.95
                        sol[j][3] *= 0.95
                        ok = False
            if ok:
                break
        sol = [tuple(s) for s in sol]

    while len(sol) < n:
        sol.append((0.5, 0.5, 0.0, 0.0))
    return sol[:n]
