import math
import numpy as np
from scipy.optimize import minimize

def solve(n):
    """
    Returns a list of n tuples (cx, cy, angle, side) for squares inside [0,1]^2,
    maximizing the sum of side lengths.
    Squares are non-overlapping (interiors may not share points).
    angle is fraction of full turn (0.25 = 90 degrees).
    """
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side by side: each 0.5 x 0.5, sum = 1.0
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    # ------------------------------------------------------------------
    # Objective: maximize sum of sides = minimize negative sum
    # ------------------------------------------------------------------
    def neg_obj(v):
        # v is flattened array: [cx0, cy0, a0, s0, cx1, cy1, a1, s1, ...]
        return -np.sum(v[3::4])

    # ------------------------------------------------------------------
    # Constraints
    # ------------------------------------------------------------------
    def make_constraints(n_local):
        cons = []

        # Box constraints: for each square, all four corners inside [0,1]^2.
        # Corner offsets: half side-vector rotated by angle.
        # For square i: s = side, a = angle, half = s/2
        # u = half * (cos(2πa), sin(2πa))
        # v = half * (-sin(2πa), cos(2πa))
        # corners: c ± u ± v
        # We enforce each corner coordinate >= 0 and <= 1.
        # That's 8 inequalities per square.
        for i in range(n_local):
            def corner_constraint(v, i=i, comp=0, sign1=0, sign2=0, lower=1.0):
                # helper: evaluate corner coordinate and return margin
                # comp: 0 for x, 1 for y
                # sign1: +1 for +u, -1 for -u
                # sign2: +1 for +v, -1 for -v
                # lower: 1.0 for upper bound (1 - coord >= 0), -1.0 for lower bound (coord >= 0)
                idx = i * 4
                cx, cy, a, s = v[idx], v[idx+1], v[idx+2], v[idx+3]
                half = s * 0.5
                th = 2.0 * math.pi * a
                c, sn = math.cos(th), math.sin(th)
                # u = half * (c, sn), v = half * (-sn, c)
                if comp == 0:
                    coord = cx + sign1 * half * c + sign2 * half * (-sn)
                else:
                    coord = cy + sign1 * half * sn + sign2 * half * c
                if lower == 1.0:
                    return 1.0 - coord
                else:
                    return coord

            # lower bounds: coord >= 0
            for comp in (0, 1):
                for sign1 in (-1, 1):
                    for sign2 in (-1, 1):
                        cons.append({'type': 'ineq',
                                     'fun': (lambda v, i=i, comp=comp, sign1=sign1, sign2=sign2:
                                             corner_constraint(v, i, comp, sign1, sign2, -1.0))})
            # upper bounds: 1 - coord >= 0
            for comp in (0, 1):
                for sign1 in (-1, 1):
                    for sign2 in (-1, 1):
                        cons.append({'type': 'ineq',
                                     'fun': (lambda v, i=i, comp=comp, sign1=sign1, sign2=sign2:
                                             corner_constraint(v, i, comp, sign1, sign2, 1.0))})

        # Non-overlap constraints via separating axis theorem for all pairs.
        # For two convex polygons (squares), it is sufficient to check axes:
        # the edge normals of both polygons.  For each axis, project centres
        # and radii; require |proj_c1 - proj_c2| >= r1 + r2.
        # For a square with half-side h = s/2, the projection radius on an
        # axis making angle φ with the square's edge normal is:
        # h * (|cos φ| + |sin φ|) where φ is relative angle.
        # Actually for a square with side s, the support function radius
        # in direction n is h*(|cos(θ)| + |sin(θ)|) where θ is angle between
        # n and the square's orientation.
        # Here we use the edge normals as candidate axes.
        for i in range(n_local):
            for j in range(i+1, n_local):
                def overlap_constraint(v, i=i, j=j, k=k):
                    # k indexes the candidate axis (0..3): two from square i, two from j
                    idx_i = i * 4
                    idx_j = j * 4
                    cx1, cy1, a1, s1 = v[idx_i], v[idx_i+1], v[idx_i+2], v[idx_i+3]
                    cx2, cy2, a2, s2 = v[idx_j], v[idx_j+1], v[idx_j+2], v[idx_j+3]
                    # candidate axis angles (normal directions)
                    # square i normals: angle = a1 (x-axis of square) and a1+0.25 (y-axis)
                    # similarly for j.
                    if k < 2:
                        axis_angle = (a1 + k * 0.25) * 2.0 * math.pi
                    else:
                        axis_angle = (a2 + (k-2) * 0.25) * 2.0 * math.pi
                    ux, uy = math.cos(axis_angle), math.sin(axis_angle)
                    # projection of centres
                    p1 = cx1 * ux + cy1 * uy
                    p2 = cx2 * ux + cy2 * uy
                    # support radius for square i in direction u:
                    # half side times (|cos(θ)| + |sin(θ)|) where θ = axis_angle - square_angle
                    def support_radius(s, a):
                        h = s * 0.5
                        th = axis_angle - (a * 2.0 * math.pi)
                        return h * (abs(math.cos(th)) + abs(math.sin(th)))
                    r1 = support_radius(s1, a1)
                    r2 = support_radius(s2, a2)
                    # separation: |p1 - p2| >= r1 + r2
                    return abs(p1 - p2) - (r1 + r2)
                for k in range(4):
                    cons.append({'type': 'ineq',
                                 'fun': (lambda v, i=i, j=j, k=k: overlap_constraint(v, i, j, k))})
        return cons

    # ------------------------------------------------------------------
    # Initial guesses
    # ------------------------------------------------------------------
    def grid_initial(n_local):
        # Place k x k squares in a grid; distribute leftovers intelligently.
        k = math.isqrt(n_local)
        if k < 1:
            k = 1
        side = 1.0 / k
        squares = []
        # place k*k grid squares
        for ix in range(k):
            for iy in range(k):
                squares.append([(ix + 0.5) * side, (iy + 0.5) * side, 0.0, side])
        # remaining squares: place them in the largest gap, or at boundary with tiny size
        rem = n_local - len(squares)
        if rem > 0:
            # Try to fit extra squares along the edges, sharing boundaries.
            # Simple strategy: reduce size of existing grid and pack more.
            # We'll put remaining squares at random positions with small size.
            # But better: use a sub-grid approach.
            # For now: put them at corners with size 0 (which is valid) but
            # the optimizer will grow them.
            for r in range(rem):
                # Place at random location near an edge with small side
                # To avoid issues, use a small positive side.
                # We'll place them in a row along the bottom.
                # This is just an initial guess; the optimizer will adjust.
                # Use zero-size to start (valid but not helpful). Instead,
                # let's use tiny size at random positions.
                # We'll use a deterministic quasi-random sequence.
                # Simple: place at corners and mid-edges alternating.
                pos = [
                    (0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (1.0, 1.0),
                    (0.5, 0.0), (0.0, 0.5), (1.0, 0.5), (0.5, 1.0),
                ][r % 8]
                squares.append([pos[0], pos[1], 0.0, 0.0])
        return squares[:n_local]

    # ------------------------------------------------------------------
    # Main optimisation loop: multiple restarts
    # ------------------------------------------------------------------
    best_v = None
    best_val = -np.inf

    # Number of restarts based on n (smaller n easier, more restarts)
    restarts = 15 if n <= 12 else (10 if n <= 30 else 5)
    # Increase restarts if time allows? We'll use a schedule.
    # But we need to finish within 60 seconds. Let's use moderate restarts.
    # We'll adapt based on n: smaller n can afford more restarts.
    if n <= 6:
        restarts = 25
    elif n <= 10:
        restarts = 18
    elif n <= 20:
        restarts = 12
    elif n <= 40:
        restarts = 8
    else:
        restarts = 5

    # Base initial guess from grid
    init_base = grid_initial(n)

    # If n is small, try also a single big square + small ones pattern
    for attempt in range(restarts):
        if attempt == 0:
            init_squares = init_base
        else:
            # Perturb the base or randomize
            init_squares = []
            # Random valid-ish configuration
            for i in range(n):
                # random centre, angle, and small side
                cx = np.random.uniform(0.0, 1.0)
                cy = np.random.uniform(0.0, 1.0)
                a = np.random.uniform(0.0, 1.0)
                # choose small side to be likely feasible
                s = np.random.uniform(0.0, 0.3)
                init_squares.append([cx, cy, a, s])
            # also mix in the grid guess for some restarts
            if attempt % 2 == 0:
                mix = grid_initial(n)
                for i in range(n):
                    if i < len(mix):
                        # blend
                        alpha = np.random.uniform(0.0, 1.0)
                        init_squares[i][0] = alpha * mix[i][0] + (1-alpha) * init_squares[i][0]
                        init_squares[i][1] = alpha * mix[i][1] + (1-alpha) * init_squares[i][1]
                        init_squares[i][2] = alpha * mix[i][2] + (1-alpha) * init_squares[i][2]
                        init_squares[i][3] = alpha * mix[i][3] + (1-alpha) * init_squares[i][3]

        # Flatten initial
        x0 = np.zeros(4 * n)
        for i, sq in enumerate(init_squares):
            x0[i*4:i*4+4] = sq

        # Ensure initial is feasible w.r.t. box constraints by clamping
        for i in range(n):
            cx, cy, a, s = x0[i*4:i*4+4]
            s = max(0.0, min(s, 1.0))
            # clamp centre to [s/2, 1-s/2] roughly
            half = s * 0.5
            # for rotated square, max extent is half * sqrt(2)
            max_ext = half * math.sqrt(2.0)
            cx = max(max_ext, min(cx, 1.0 - max_ext))
            cy = max(max_ext, min(cy, 1.0 - max_ext))
            x0[i*4:i*4+4] = [cx, cy, a, s]

        # Build constraints for this n
        cons = make_constraints(n)

        # Bounds: cx, cy in [0,1], angle in [0,1], side in [0,1]
        bounds = []
        for _ in range(n):
            bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])

        # Run optimization
        try:
            res = minimize(neg_obj, x0, method='SLSQP', bounds=bounds,
                           constraints=cons, options={'maxiter': 1000, 'ftol': 1e-9, 'disp': False})
        except Exception:
            continue

        if res.success or res.status in (0, 1, 2):
            val = -res.fun
            # Check feasibility roughly
            # (we'll trust SLSQP but do a quick check)
            feasible = True
            if not np.all(np.isfinite(res.x)):
                feasible = False
            if feasible:
                if val > best_val:
                    best_val = val
                    best_v = res.x.copy()

    # If no feasible found, fall back to baseline
    if best_v is None:
        k = math.isqrt(n)
        side = 1.0 / k
        sqs = []
        for i in range(k):
            for j in range(k):
                sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        sqs += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sqs))
        return sqs[:n]

    # Extract best result
    result = []
    for i in range(n):
        cx, cy, a, s = best_v[i*4:i*4+4]
        # Clamp to valid ranges
        a = a % 1.0
        s = max(0.0, min(s, 1.0))
        # Adjust centre to fit inside if needed
        half = s * 0.5
        max_ext = half * math.sqrt(2.0)
        cx = max(0.0, min(cx, 1.0))
        cy = max(0.0, min(cy, 1.0))
        result.append((float(cx), float(cy), float(a), float(s)))
    return result
