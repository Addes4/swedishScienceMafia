import math, random, time

def solve(n):
    if n <= 0:
        return []
    random.seed(12345 + n)
    start_time = time.time()
    TIME_LIM = 55.0

    # Try to find best grid packing for n: use rows/cols close to sqrt(n),
    # fill with variable sizes (larger squares first, using a guillotine-ish layout).
    # Then jiggle with simulated annealing.

    def corners(cx, cy, ang, s):
        # ang in turns
        a = ang * 2.0 * math.pi
        ca, sa = math.cos(a), math.sin(a)
        h = s * 0.5
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
        return pts

    def in_unit(pts):
        for x, y in pts:
            if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
                return False
        return True

    def overlap(sq1, sq2):
        # SAT for convex polygons (squares)
        pts1 = corners(*sq1)
        pts2 = corners(*sq2)
        axes = []
        for pts in (pts1, pts2):
            for i in range(4):
                x1, y1 = pts[i]
                x2, y2 = pts[(i + 1) % 4]
                ex, ey = x2 - x1, y2 - y1
                # normal axis
                axes.append((-ey, ex))
        for ax, ay in axes:
            n1 = [ax * x + ay * y for x, y in pts1]
            n2 = [ax * x + ay * y for x, y in pts2]
            if max(n1) <= min(n2) + 1e-12 or max(n2) <= min(n1) + 1e-12:
                return False
        return True

    def valid_all(sqs):
        for i in range(len(sqs)):
            if not in_unit(corners(*sqs[i])):
                return False
        for i in range(len(sqs)):
            for j in range(i + 1, len(sqs)):
                if overlap(sqs[i], sqs[j]):
                    return False
        return True

    def score(sqs):
        return sum(s[3] for s in sqs)

    # Initial layout: row/col grid with sqrt(n) cols, then shrink to fit exactly
    cols = max(1, int(round(math.sqrt(n))))
    rows = (n + cols - 1) // cols
    # assign cell sizes: fill all cells with 1/cols
    base = []
    for idx in range(n):
        r = idx // cols
        c = idx % cols
        # center in cell, but final rows may be fewer columns
        w = 1.0 / cols
        h = 1.0 / rows
        cx = (c + 0.5) * w
        cy = (r + 0.5) * h
        side = min(w, h)
        base.append((cx, cy, 0.0, side))
    # scale down slightly for safety
    for i in range(n):
        cx, cy, a, s = base[i]
        base[i] = (cx, cy, a, s * 0.999)

    best = list(base)
    best_score = score(base)

    # improvement loop
    cur = list(best)
    cur_score = best_score

    temp = 0.02
    iters = 0
    while time.time() - start_time < TIME_LIM:
        iters += 1
        # pick a random square to modify
        i = random.randrange(n)
        cx, cy, a, s = cur[i]
        # propose
        which = random.random()
        if which < 0.45:
            # grow/shrink
            delta = random.gauss(0, 0.01)
            ns = max(0.0, min(1.0, s + delta))
            na = a
            ncx, ncy = cx, cy
        elif which < 0.7:
            # jiggle
            ncx = max(0.0, min(1.0, cx + random.gauss(0, 0.01)))
            ncy = max(0.0, min(1.0, cy + random.gauss(0, 0.01)))
            na = a
            ns = s
        elif which < 0.9:
            # rotate
            na = (a + random.gauss(0, 0.05)) % 1.0
            ncx, ncy = cx, cy
            ns = s
        else:
            # random teleport small
            ncx = random.random()
            ncy = random.random()
            na = random.random()
            ns = min(s, 0.5)

        if ns < 1e-9:
            return cur  # all zero basically
        cand = (ncx, ncy, na, ns)
        old = cur[i]
        cur[i] = cand
        # check validity
        ok = in_unit(corners(cand))
        if ok:
            for j in range(n):
                if j == i:
                    continue
                if overlap(cand, cur[j]):
                    ok = False
                    break
        if ok:
            cs = cur_score - old[3] + ns
            if cs >= cur_score or random.random() < math.exp((cs - cur_score) / max(temp, 1e-9)):
                cur_score = cs
                if cs > best_score + 1e-12:
                    best_score = cs
                    best = list(cur)
            else:
                cur[i] = old
        else:
            cur[i] = old

        # cooling
        temp *= 0.99995
        if temp < 1e-5:
            temp = 1e-5

        # occasionally restart from best
        if iters % 20000 == 0:
            cur = list(best)

    # final cleanup: remove tiny squares
    res = []
    for sq in best:
        cx, cy, a, s = sq
        if s < 1e-12:
            res.append((0.5, 0.5, 0.0, 0.0))
        else:
            res.append((max(0.0, min(1.0, cx)), max(0.0, min(1.0, cy)), a % 1.0, s))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
