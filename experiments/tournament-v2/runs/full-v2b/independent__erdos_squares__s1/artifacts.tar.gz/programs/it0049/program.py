import math
import random

# Deterministic pseudo-random for reproducibility
def _rand(seed):
    return random.Random(seed)

def _valid(squares, eps=1e-9):
    # Check containment and non-overlap of interiors for axis-aligned only (angle ignored mostly)
    # For general angles we use a simple SAT check on convex polygons.
    polys = []
    for (cx, cy, ang, s) in squares:
        if s <= 0:
            polys.append(None)
            continue
        a = ang * 2 * math.pi
        c, sn = math.cos(a), math.sin(a)
        h = s / 2
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x = cx + dx * c - dy * sn
            y = cy + dx * sn + dy * c
            pts.append((x, y))
        # containment
        for x, y in pts:
            if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                return False
        polys.append(pts)

    # SAT overlap test for convex polygons
    def polys_overlap(P, Q):
        for poly in (P, Q):
            n = len(poly)
            for i in range(n):
                x1, y1 = poly[i]
                x2, y2 = poly[(i+1) % n]
                ex, ey = x2 - x1, y2 - y1
                # normal
                nx, ny = -ey, ex
                # project both
                minP = min(x * nx + y * ny for x, y in P)
                maxP = max(x * nx + y * ny for x, y in P)
                minQ = min(x * nx + y * ny for x, y in Q)
                maxQ = max(x * nx + y * ny for x, y in Q)
                if maxP <= minQ + 1e-10 or maxQ <= minP + 1e-10:
                    return False
        return True

    for i in range(len(polys)):
        if polys[i] is None:
            continue
        for j in range(i+1, len(polys)):
            if polys[j] is None:
                continue
            if polys_overlap(polys[i], polys[j]):
                return False
    return True


def _make_grid(k, n):
    """k x k axis-aligned grid, extras as zero-size."""
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _perturb_and_improve(squares, iters=200, seed=12345):
    """Local search: try to increase side lengths while keeping validity.
    Keeps angles small or zero; tries slight shifts and growing the smallest ones."""
    rng = _rand(seed)
    best = [list(s) for s in squares]
    best_score = sum(s[3] for s in best)

    # Precompute which indices have positive side
    def score(sq):
        return sum(s[3] for s in sq)

    cur = [list(s) for s in best]

    for it in range(iters):
        # pick a random square with positive side and try to grow it
        idxs = [i for i, s in enumerate(cur) if s[3] > 0]
        if not idxs:
            break
        i = rng.choice(idxs)
        cand = [list(s) for s in cur]
        # try increasing side
        grow = rng.uniform(0.5, 1.5) * 0.02
        cand[i][3] += grow
        # try small shifts and angle jitter
        cand[i][0] += rng.uniform(-0.005, 0.005)
        cand[i][1] += rng.uniform(-0.005, 0.005)
        cand[i][2] += rng.uniform(-0.02, 0.02)
        # clamp
        cand[i][0] = min(1.0, max(0.0, cand[i][0]))
        cand[i][1] = min(1.0, max(0.0, cand[i][1]))
        cand[i][2] = cand[i][2] % 1.0
        cand[i][3] = min(1.0, max(0.0, cand[i][3]))

        if _valid(cand):
            sc = score(cand)
            if sc > best_score + 1e-12:
                best = [list(s) for s in cand]
                best_score = sc
                cur = [list(s) for s in cand]
            elif sc > score(cur):
                cur = [list(s) for s in cand]
        else:
            # maybe shrink a neighbour to allow growth of i? skip for simplicity
            pass

        # occasionally re-heat by restarting from best
        if it % 50 == 0:
            cur = [list(s) for s in best]

    return best


def solve(n):
    if n <= 0:
        return []

    # For very small n use simple known-ish layouts
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares split vertically: each 1 x 0.5 -> sum 1.0
        return [(0.5, 0.25, 0.0, 1.0), (0.5, 0.75, 0.0, 1.0)]
    if n == 3:
        # one full-height square and two stacked
        # Try: left square side 0.5 (full height), right split into two
        # Actually better: three equal squares in a row? k=1 grid gives 1.0 total.
        # Use: top half full width, bottom half split into two
        return [(0.5, 0.75, 0.0, 1.0), (0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5)]
    if n == 4:
        return _make_grid(2, n)
    if n == 5:
        # try 2x2 grid plus one zero in leftover? or 1 large + 4 small
        # Use grid of 2 plus extra zero
        base = _make_grid(2, 4)
        base.append((0.5, 0.5, 0.0, 0.0))
        return base

    k = math.isqrt(n)
    # If n is perfect square, grid is likely optimal
    if k * k == n:
        return _make_grid(k, n)

    # Otherwise, start with k x k grid and add zero-size extras, then try to improve
    base = _make_grid(k, n)

    # Better initialization: distribute extra squares in a row/column resize attempt
    # Try to give non-zero sizes to all n squares by using a finer partition idea:
    # Use a k x (k+1) or (k+1) x k grid if n fits, else more complex.
    # For simplicity, try a mixed grid: some rows have k+1 cells.
    # Build a partition into m rows where each row has variable number of columns.
    # We try to make all squares as equal as possible while fitting.

    # Approach: choose a grid with r rows and c columns where r*c >= n, r,c close.
    # Then use the first n cells and zero the rest, but adjust row heights/col widths.
    best = base
    best_score = sum(s[3] for s in best)

    # Try a few candidate grids (r, c) with r*c >= n, small product
    candidates = []
    for r in range(1, n+1):
        c = (n + r - 1) // r
        candidates.append((r, c))
        if c == 0:
            continue
    # keep those with product not too large
    candidates = [(r, c) for (r, c) in candidates if r * c <= n + max(3, n//4)]
    candidates = sorted(set(candidates), key=lambda rc: rc[0]*rc[1])[:20]

    for (r, c) in candidates:
        # row heights: try equal
        row_h = [1.0 / r] * r
        col_w = [1.0 / c] * c
        # assign squares
        sq = []
        cnt = 0
        for i in range(r):
            for j in range(c):
                if cnt >= n:
                    break
                cx = sum(col_w[:j]) + col_w[j]/2
                cy = sum(row_h[:i]) + row_h[i]/2
                s = min(row_h[i], col_w[j])
                sq.append([cx, cy, 0.0, s])
                cnt += 1
            if cnt >= n:
                break
        while len(sq) < n:
            sq.append([0.5, 0.5, 0.0, 0.0])
        sq = sq[:n]
        sc = sum(s[3] for s in sq)
        if sc > best_score:
            best_score = sc
            best = sq

    # Also try non-uniform: give some squares larger than cell min
    # Simple improvement: for each square, try to grow it into unused space if possible
    best = _perturb_and_improve(best, iters=300, seed=42)

    # Verify validity (should be valid)
    if not _valid(best):
        # fallback to grid
        return _make_grid(k, n)

    return [tuple(s) for s in best]
