import math
import random

# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _corners(cx, cy, ang, side):
    a = ang * 2.0 * math.pi
    c, s = math.cos(a), math.sin(a)
    h = side * 0.5
    return (
        (cx + h * ( c - s), cy + h * ( s + c)),
        (cx + h * (-c - s), cy + h * (-s + c)),
        (cx + h * (-c + s), cy + h * (-s - c)),
        (cx + h * ( c + s), cy + h * ( s - c)),
    )

def _overlap_avoid(sq_a, sq_b, eps=1e-12):
    """Return True if the two squares have intersecting interiors."""
    ax, ay, aa, asd = sq_a
    bx, by, ba, bsd = sq_b
    if asd <= eps or bsd <= eps:
        return False
    ca = _corners(ax, ay, aa, asd)
    cb = _corners(bx, by, ba, bsd)
    # separating axis test: axes of both squares
    for pts, other in ((ca, cb), (cb, ca)):
        for i in range(4):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % 4]
            nx = -(y2 - y1)
            ny = x2 - x1
            # project both onto normal
            proj_p = [nx * px + ny * py for px, py in pts]
            proj_o = [nx * px + ny * py for px, py in other]
            if max(proj_p) <= min(proj_o) + eps or max(proj_o) <= min(proj_p) + eps:
                return False
    return True

def _inside(cx, cy, ang, side):
    if side <= 0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    for px, py in _corners(cx, cy, ang, side):
        if px < -1e-12 or px > 1.0 + 1e-12 or py < -1e-12 or py > 1.0 + 1e-12:
            return False
    return True

def _clamp_inside(sq):
    cx, cy, ang, side = sq
    if side <= 0:
        return (min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), ang, 0.0)
    for _ in range(60):
        pts = _corners(cx, cy, ang, side)
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        dx = 0.0
        if min(xs) < 0.0:
            dx = -min(xs)
        elif max(xs) > 1.0:
            dx = 1.0 - max(xs)
        dy = 0.0
        if min(ys) < 0.0:
            dy = -min(ys)
        elif max(ys) > 1.0:
            dy = 1.0 - max(ys)
        if abs(dx) < 1e-13 and abs(dy) < 1e-13:
            break
        cx += dx
        cy += dy
        if min(xs) < -1e-9 or max(xs) > 1.0 + 1e-9 or min(ys) < -1e-9 or max(ys) > 1.0 + 1e-9:
            # shrink slightly if cannot fix by translation
            side *= 0.98
    return (cx, cy, ang, side)

# ---------------------------------------------------------------------------
# Feasibility repair
# ---------------------------------------------------------------------------

def _repair(squares, iterations=30):
    squares = [list(s) for s in squares]
    n = len(squares)
    for _ in range(iterations):
        changed = False
        # clamp inside
        for i in range(n):
            squares[i] = list(_clamp_inside(tuple(squares[i])))
        # resolve overlaps by shrinking the smaller (or either) square
        for i in range(n):
            for j in range(i + 1, n):
                si = squares[i]
                sj = squares[j]
                if si[3] <= 0 or sj[3] <= 0:
                    continue
                if _overlap_avoid(si, sj):
                    # shrink both slightly
                    if si[3] < sj[3]:
                        si[3] *= 0.86
                        if si[3] < 1e-10:
                            si[3] = 0.0
                    else:
                        sj[3] *= 0.86
                        if sj[3] < 1e-10:
                            sj[3] = 0.0
                    changed = True
        if not changed:
            break
    # final clamp
    for i in range(n):
        squares[i] = list(_clamp_inside(tuple(squares[i])))
    return [tuple(s) for s in squares]

# ---------------------------------------------------------------------------
# Initial solutions
# ---------------------------------------------------------------------------

def _grid_solution(n):
    if n == 0:
        return []
    k = int(math.isqrt(n))
    while k > 0 and k * k > n:
        k -= 1
    if k == 0:
        k = 1
    side = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    res = res[:n]
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]

def _rows_solution(n):
    """Unequal rows: place rows of squares, distribute sizes greedily."""
    if n == 0:
        return []
    # choose number of rows, each row has m_i squares
    best = _grid_solution(n)
    for rows in range(1, min(n, 12) + 1):
        for cols in range(1, min(n, 12) + 1):
            cap = rows * cols
            if cap >= n:
                # put n squares in rows*cols grid but allow some larger
                # simple equal grid then expand
                side = min(1.0 / cols, 1.0 / rows)
                res = []
                idx = 0
                for r in range(rows):
                    for c in range(cols):
                        if idx >= n:
                            break
                        x = (c + 0.5) * side
                        y = (r + 0.5) * side
                        res.append((x, y, 0.0, side))
                        idx += 1
                # use leftover space
                if res:
                    total = sum(s[3] for s in res)
                    if total > sum(s[3] for s in best):
                        best = res
                break
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]

def _staggered_solution(n):
    """Try shifted rows for better packing."""
    if n == 0:
        return []
    best = _grid_solution(n)
    for rows in range(1, min(n, 10) + 1):
        # distribute n squares roughly equally among rows
        base = n // rows
        rem = n % rows
        counts = [base + (1 if i < rem else 0) for i in range(rows)]
        # each row height = 1/rows, square side = min(1/count, 1/rows)
        res = []
        y = 0.0
        for r in range(rows):
            h = 1.0 / rows
            cnt = counts[r]
            if cnt == 0:
                continue
            side = min(1.0 / cnt, h)
            offset = (1.0 - cnt * side) / 2.0
            # stagger alternate rows
            if r % 2 == 1:
                offset = (1.0 - (cnt * side)) * 0.5
            for c in range(cnt):
                x = offset + (c + 0.5) * side
                if x - side * 0.5 < -1e-12:
                    x = side * 0.5
                if x + side * 0.5 > 1.0 + 1e-12:
                    x = 1.0 - side * 0.5
                res.append((x, y + h * 0.5, 0.0, side))
            y += h
        res = res[:n]
        res = _repair(res)
        if sum(s[3] for s in res) > sum(s[3] for s in best):
            best = res
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]

# ---------------------------------------------------------------------------
# Local search / simulated annealing
# ---------------------------------------------------------------------------

def _evaluate(squares):
    return sum(s[3] for s in squares)

def _perturb(squares, rng, temp=1.0):
    n = len(squares)
    sq = [list(s) for s in squares]
    # choose operation
    op = rng.random()
    if op < 0.35:
        # move a square
        i = rng.randrange(n)
        sq[i][0] += rng.gauss(0, 0.04 * temp)
        sq[i][1] += rng.gauss(0, 0.04 * temp)
    elif op < 0.55:
        # rotate
        i = rng.randrange(n)
        sq[i][2] += rng.gauss(0, 0.06 * temp)
        sq[i][2] %= 1.0
    elif op < 0.8:
        # grow a square
        i = rng.randrange(n)
        max_grow = 0.08 * temp
        sq[i][3] += rng.random() * max_grow
    else:
        # move and grow
        i = rng.randrange(n)
        sq[i][0] += rng.gauss(0, 0.03 * temp)
        sq[i][1] += rng.gauss(0, 0.03 * temp)
        sq[i][3] += rng.random() * 0.06 * temp
    # repair to feasibility
    sq = _repair(sq, iterations=10)
    return sq

def _local_search_initial(squares, rng, steps=600):
    cur = [list(s) for s in squares]
    cur_score = _evaluate(cur)
    best = [list(s) for s in cur]
    best_score = cur_score
    for t in range(steps):
        temp = max(0.02, 1.0 - t / float(steps))
        cand = _perturb(cur, rng, temp)
        cand_score = _evaluate(cand)
        if cand_score >= cur_score - 1e-9 * (1.0 - temp):
            cur = [list(s) for s in cand]
            cur_score = cand_score
        if cand_score > best_score:
            best = [list(s) for s in cand]
            best_score = cand_score
    return best, best_score

# ---------------------------------------------------------------------------
# Main solve
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side by side or stacked
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # one large on left, two stacked on right
        return [(0.5, 0.5, 0.0, 1.0 / 3.0)] * 0 + _repair([
            (0.25, 0.5, 0.0, 0.5),
            (0.75, 0.25, 0.0, 0.25),
            (0.75, 0.75, 0.0, 0.25),
        ])

    rng = random.Random(12345 + n)

    candidates = []

    # deterministic starts
    candidates.append(_grid_solution(n))
    candidates.append(_rows_solution(n))
    candidates.append(_staggered_solution(n))

    # random starts
    for _ in range(4):
        res = []
        for _ in range(n):
            side = rng.uniform(0.01, 1.0 / math.sqrt(n) * 1.5)
            cx = rng.uniform(side * 0.5, 1.0 - side * 0.5)
            cy = rng.uniform(side * 0.5, 1.0 - side * 0.5)
            ang = rng.random()
            res.append((cx, cy, ang, side))
        res = _repair(res)
        candidates.append(res)

    # evaluate and repair all
    best_sq = None
    best_sc = -1.0
    for c in candidates:
        c = _repair(c)
        sc = _evaluate(c)
        if sc > best_sc:
            best_sc = sc
            best_sq = c

    # local search refinement
    time_budget = 8.0
    import time
    start_time = time.time()
    round_no = 0
    while time.time() - start_time < time_budget:
        round_no += 1
        steps = 400
        if n > 50:
            steps = 250
        cand, sc = _local_search_initial(best_sq, rng, steps=steps)
        if sc > best_sc + 1e-12:
            best_sc = sc
            best_sq = cand
        # add perturbed variants to escape local optima
        for _ in range(2):
            var = _perturb(best_sq, rng, temp=0.7)
            var, vsc = _local_search_initial(var, rng, steps=steps // 2)
            if vsc > best_sc + 1e-12:
                best_sc = vsc
                best_sq = var
        # periodically restart from scratch with random
        if round_no % 3 == 0 and n <= 200:
            res = []
            for _ in range(n):
                side = rng.uniform(0.005, 1.0 / math.sqrt(n) * 1.5)
                cx = rng.uniform(side * 0.5, 1.0 - side * 0.5)
                cy = rng.uniform(side * 0.5, 1.0 - side * 0.5)
                ang = rng.random()
                res.append((cx, cy, ang, side))
            res = _repair(res)
            rsc = _evaluate(res)
            if rsc > best_sc:
                best_sc = rsc
                best_sq = res

    # final cleanup
    best_sq = _repair(best_sq, iterations=50)
    best_sq = [list(s) for s in best_sq]

    # pad with zero-size if needed
    while len(best_sq) < n:
        best_sq.append([0.5, 0.5, 0.0, 0.0])
    best_sq = best_sq[:n]

    # ensure all outputs are tuples, values in [0,1], angles in [0,1]
    out = []
    for cx, cy, ang, side in best_sq:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 1.0
        side = max(side, 0.0)
        # if side too large, shrink to fit
        if side > 0:
            tmp = (cx, cy, ang, side)
            tmp = _clamp_inside(tmp)
            cx, cy, ang, side = tmp
        out.append((cx, cy, ang, side))

    # final feasibility sweep
    out = _repair(out, iterations=40)
    return out[:n]
