import math
import random
import numpy as np

try:
    from scipy.optimize import minimize
    SCIPY = True
except Exception:
    SCIPY = False


def _rot(angle):
    c = math.cos(2.0 * math.pi * angle)
    s = math.sin(2.0 * math.pi * angle)
    return c, s


def _corners(cx, cy, angle, s):
    c, si = _rot(angle)
    h = 0.5 * s
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + c * x - si * y, cy + si * x + c * y))
    return out


def _overlap_amount(sq1, sq2):
    """Return a positive measure of overlap penalty (0 if disjoint interiors)."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 0.0 or s2 <= 0.0:
        return 0.0
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)

    axes = []
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 1e-15:
                axes.append((-ey / ln, ex / ln))

    min_overlap = None
    for ax, ay in axes:
        p1_proj = [x * ax + y * ay for x, y in p1]
        p2_proj = [x * ax + y * ay for x, y in p2]
        o = min(max(p1_proj), max(p2_proj)) - max(min(p1_proj), min(p2_proj))
        if o <= 0.0:
            return 0.0
        if min_overlap is None or o < min_overlap:
            min_overlap = o
    return min_overlap if min_overlap is not None else 0.0


def _penalty(squares):
    pen = 0.0
    m = len(squares)
    for i in range(m):
        cx, cy, a, s = squares[i]
        if s < 0:
            pen += 100.0 * (-s) ** 2
        # boundary penalty (soft)
        if s > 0:
            pts = _corners(cx, cy, a, s)
            for x, y in pts:
                if x < 0.0:
                    pen += 50.0 * x * x
                if x > 1.0:
                    pen += 50.0 * (x - 1.0) ** 2
                if y < 0.0:
                    pen += 50.0 * y * y
                if y > 1.0:
                    pen += 50.0 * (y - 1.0) ** 2
        for j in range(i + 1, m):
            o = _overlap_amount(squares[i], squares[j])
            if o > 0:
                pen += 200.0 * o * o
    return pen


def _total_side(squares):
    return sum(max(0.0, s[3]) for s in squares)


def _objective(vec, n):
    squares = []
    for i in range(n):
        cx = vec[4 * i]
        cy = vec[4 * i + 1]
        ang = vec[4 * i + 2]
        s = vec[4 * i + 3]
        squares.append((cx, cy, ang, max(0.0, s)))
    return -_total_side(squares) + _penalty(squares)


def _initial(n):
    # start with best square grid, then random tiny squares
    k = int(math.floor(math.sqrt(n)))
    while k * k > n:
        k -= 1
    while (k + 1) * (k + 1) <= n:
        k += 1
    sq = []
    side = 1.0 / k
    for i in range(k):
        for j in range(k):
            sq.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # extra squares small and placed in gaps or at centre
    rem = n - k * k
    for r in range(rem):
        # try to put in a corner-ish free space or center
        sq.append((0.5, 0.5, 0.0, 0.02))
    random.shuffle(sq)
    return sq


def _run_local(squares, n, steps=1200):
    # coordinate-wise random search / SA over vector
    vec = []
    for cx, cy, a, s in squares:
        vec.extend([cx, cy, a, s])
    vec = np.array(vec, dtype=float)

    best_vec = vec.copy()
    best_obj = _objective(vec, n)
    cur_obj = best_obj

    T0 = 0.02
    T1 = 0.0005
    rng = random.Random(12345)

    for it in range(steps):
        frac = it / max(1, steps - 1)
        T = T0 * (T1 / T0) ** frac

        cand = best_vec.copy() if rng.random() < 0.7 else vec.copy()
        idx = rng.randrange(4 * n)
        if idx % 4 == 0:
            cand[idx] += rng.gauss(0.0, 0.02 * (1.0 - 0.7 * frac))
        elif idx % 4 == 1:
            cand[idx] += rng.gauss(0.0, 0.02 * (1.0 - 0.7 * frac))
        elif idx % 4 == 2:
            cand[idx] += rng.gauss(0.0, 0.02 * (1.0 - 0.7 * frac))
        else:
            cand[idx] += rng.gauss(0.0, 0.02 * (1.0 - 0.7 * frac))

        cand[idx] = max(-0.2, min(1.2, cand[idx]))

        obj = _objective(cand, n)
        if obj < cur_obj or rng.random() < math.exp(-(obj - cur_obj) / (T + 1e-12)):
            vec = cand
            cur_obj = obj
            if obj < best_obj:
                best_obj = obj
                best_vec = cand.copy()

    # return best
    squares = []
    for i in range(n):
        squares.append((float(best_vec[4 * i]), float(best_vec[4 * i + 1]),
                        float(best_vec[4 * i + 2]), float(best_vec[4 * i + 3])))
    return squares


def _repair(squares, n):
    # project out overlaps greedily by shrinking tiny offenders
    for _ in range(20):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                if _overlap_amount(squares[i], squares[j]) > 1e-9:
                    # shrink both a bit
                    cx1, cy1, a1, s1 = squares[i]
                    cx2, cy2, a2, s2 = squares[j]
                    s1 *= 0.7
                    s2 *= 0.7
                    squares[i] = (cx1, cy1, a1, s1)
                    squares[j] = (cx2, cy2, a2, s2)
                    changed = True
        if not changed:
            break
    # clamp into unit square by shrinking
    for i in range(n):
        cx, cy, a, s = squares[i]
        pts = _corners(cx, cy, a, s)
        mnx = min(x for x, y in pts)
        mxx = max(x for x, y in pts)
        mny = min(y for x, y in pts)
        mxy = max(y for x, y in pts)
        if mnx < 0 or mxx > 1 or mny < 0 or mxy > 1:
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
            # shrink to fit roughly
            scale = 1.0
            if mxx - mnx > 1e-12:
                scale = min(scale, 1.0 / (mxx - mnx))
            if mxy - mny > 1e-12:
                scale = min(scale, 1.0 / (mxy - mny))
            s *= 0.95 * min(1.0, scale)
            s = max(0.0, min(1.0, s))
            cx = min(max(cx, s / 2), 1 - s / 2)
            cy = min(max(cy, s / 2), 1 - s / 2)
            squares[i] = (cx, cy, a, s)
    return squares


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    squares = _initial(n)

    # run a few restarts with local optimisation
    best = None
    best_score = -1e9
    restarts = 3 if n <= 20 else 2
    for r in range(restarts):
        if r == 0:
            cur = squares
        else:
            cur = _initial(n)
            # perturb
            for i in range(len(cur)):
                cx, cy, a, s = cur[i]
                cx = min(1.0, max(0.0, cx + random.uniform(-0.05, 0.05)))
                cy = min(1.0, max(0.0, cy + random.uniform(-0.05, 0.05)))
                a = (a + random.uniform(-0.05, 0.05)) % 1.0
                s = max(0.0, s * random.uniform(0.8, 1.2))
                cur[i] = (cx, cy, a, s)
            cur = _repair(cur, n)

        cur = _run_local(cur, n, steps=800 + 80 * min(n, 12))
        cur = _repair(cur, n)

        # final small local tweak
        cur = _run_local(cur, n, steps=300)

        # ensure valid
        cur = _repair(cur, n)
        score = _total_side(cur)
        if score > best_score:
            best_score = score
            best = cur

    # sanitize output
    out = []
    for cx, cy, a, s in best:
        s = max(0.0, min(1.0, float(s)))
        cx = min(1.0, max(0.0, float(cx)))
        cy = min(1.0, max(0.0, float(cy)))
        a = float(a) % 1.0
        out.append((cx, cy, a, s))

    # final safety: kill any remaining overlap by shrinking
    out = _repair(out, n)
    return out[:n]
