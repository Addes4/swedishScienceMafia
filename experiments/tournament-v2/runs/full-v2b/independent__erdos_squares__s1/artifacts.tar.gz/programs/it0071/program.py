import math
import random
from typing import List, Tuple

# Optional scipy is allowed, but we can keep this pure-python + numpy-free for speed/robustness.
# (Only standard library used.)

EPS = 1e-12


def _square_vertices(cx, cy, angle, side):
    """Return the 4 vertices of a square (cx,cy), angle in turns, side length."""
    if side <= 0.0:
        return [(cx, cy)] * 4
    th = angle * 2.0 * math.pi
    c = math.cos(th)
    s = math.sin(th)
    h = side * 0.5
    # local square corners (-h,-h), (h,-h), (h,h), (-h,h)
    return [
        (cx + (-h) * c - (-h) * s, cy + (-h) * s + (-h) * c),
        (cx + (h) * c - (-h) * s, cy + (h) * s + (-h) * c),
        (cx + (h) * c - (h) * s, cy + (h) * s + (h) * c),
        (cx + (-h) * c - (h) * s, cy + (-h) * s + (h) * c),
    ]


def _inside_unit(vx):
    for x, y in vx:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _proj(poly, ax):
    vals = [x * ax[0] + y * ax[1] for x, y in poly]
    return min(vals), max(vals)


def _overlap_convex(a, b):
    """Separating axis test for two convex polygons. True if interiors overlap."""
    for poly in (a, b):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            ax = (-ey, ex)
            n = math.hypot(ax[0], ax[1])
            if n < 1e-15:
                continue
            ax = (ax[0] / n, ax[1] / n)
            mn1, mx1 = _proj(a, ax)
            mn2, mx2 = _proj(b, ax)
            if mx1 <= mn2 + 1e-10 or mx2 <= mn1 + 1e-10:
                return False
    return True


def _valid_layout(sq, skip=None):
    """Check all squares inside unit square and pairwise non-overlapping."""
    polys = []
    for i, (cx, cy, ang, side) in enumerate(sq):
        vx = _square_vertices(cx, cy, ang, side)
        if not _inside_unit(vx):
            return False
        polys.append(vx)
    m = len(sq)
    for i in range(m):
        if skip is not None and i == skip:
            continue
        for j in range(i + 1, m):
            if skip is not None and j == skip:
                continue
            if _overlap_convex(polys[i], polys[j]):
                return False
    return True


def _initial_grid(n):
    """A reasonably good structured start: layers around a central grid."""
    if n <= 0:
        return []
    # Start from kxk grid for k=floor(sqrt(n)), then place leftovers as small
    # squares around the perimeter or as tiny markers.
    k = max(1, int(math.isqrt(n)))
    side = 1.0 / k
    sq = []
    for i in range(k):
        for j in range(k):
            sq.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # If more than k^2, shrink grid slightly to make room for extra tiny squares.
    if n > k * k:
        # Try to fit extras as very small squares along the top strip, by shrinking
        # main grid and inserting them.
        # For simplicity: keep k^2 grid and add zero-size squares first, then
        # optimization can grow them if possible.
        rem = n - k * k
        for _ in range(rem):
            sq.append((0.5, 0.5, 0.0, 0.0))
    sq = sq[:n]

    # Slightly randomize order/angles for better symmetry breaking
    rng = random.Random(12345 + n)
    for i in range(len(sq)):
        cx, cy, a, s = sq[i]
        # tiny perturbation within unit square, keep safety
        dx = rng.uniform(-0.01, 0.01)
        dy = rng.uniform(-0.01, 0.01)
        cx = min(1.0 - s * 0.5 - 1e-6, max(s * 0.5 + 1e-6, cx + dx))
        cy = min(1.0 - s * 0.5 - 1e-6, max(s * 0.5 + 1e-6, cy + dy))
        sq[i] = (cx, cy, a, s)
    return sq


def _sum_sides(sq):
    return sum(s for _, _, _, s in sq)


def _clamp_square(cx, cy, ang, side):
    side = max(0.0, min(1.0, side))
    # Check rotation: axis-aligned bounding box of rotated square
    th = ang * 2.0 * math.pi
    c = abs(math.cos(th))
    s = abs(math.sin(th))
    halfw = (c + s) * side * 0.5
    halfh = (c + s) * side * 0.5
    mincx = halfw
    maxcx = 1.0 - halfw
    mincy = halfh
    maxcy = 1.0 - halfh
    if mincx > maxcx:
        # impossible -> shrink side
        side = 1.0 / (c + s)
        halfw = (c + s) * side * 0.5
        halfh = halfw
        mincx = halfw
        maxcx = 1.0 - halfw
        mincy = halfh
        maxcy = 1.0 - halfh
    cx = min(maxcx, max(mincx, cx))
    cy = min(maxcy, max(mincy, cy))
    return cx, cy, ang, side


def _try_improve(sq, idx, rng, iters=250):
    """Local coordinate descent on one square with random perturbations."""
    best = list(sq)
    best_score = _sum_sides(best)
    cx, cy, ang, side = best[idx]

    # First: grow side as much as possible while staying valid.
    # Binary search on side for current center/angle.
    lo, hi = side, 1.0
    for _ in range(35):
        mid = (lo + hi) * 0.5
        cand = (cx, cy, ang, mid)
        tmp = list(best)
        tmp[idx] = cand
        if _valid_layout(tmp):
            lo = mid
        else:
            hi = mid
    side = lo
    best[idx] = (cx, cy, ang, side)
    best_score = _sum_sides(best)

    # Then random local search
    for _ in range(iters):
        tmp = list(best)
        cx, cy, ang, side = tmp[idx]
        mode = rng.random()
        if mode < 0.45:
            # move
            scale = max(0.005, 0.08 * (1.0 - side))
            cx += rng.uniform(-scale, scale)
            cy += rng.uniform(-scale, scale)
        elif mode < 0.65:
            # rotate slightly
            ang += rng.uniform(-0.03, 0.03)
        else:
            # resize
            side += rng.uniform(-0.08, 0.08)
        cx, cy, ang, side = _clamp_square(cx, cy, ang, side)
        tmp[idx] = (cx, cy, ang, side)
        if _valid_layout(tmp):
            sc = _sum_sides(tmp)
            if sc > best_score + 1e-12:
                best = tmp
                best_score = sc
    return best


def _optimize(sq, n, time_budget_iters=4):
    """Iteratively try to improve all squares."""
    rng = random.Random(987654321 + n)
    cur = list(sq)
    cur_score = _sum_sides(cur)
    for _ in range(time_budget_iters):
        order = list(range(len(cur)))
        rng.shuffle(order)
        for idx in order:
            cand = _try_improve(cur, idx, rng, iters=max(60, 500 // max(1, len(cur))))
            if _sum_sides(cand) > cur_score + 1e-12:
                cur = cand
                cur_score = _sum_sides(cur)
    return cur


def _final_cleanup(sq):
    """Ensure strict validity and clamp tiny numerical issues."""
    out = []
    for cx, cy, ang, side in sq:
        cx, cy, ang, side = _clamp_square(cx, cy, ang, side)
        if side < 1e-9:
            side = 0.0
            cx, cy = 0.5, 0.5
        out.append((cx, cy, ang, side))
    # Verify; if invalid, shrink offending squares slightly or zero them.
    for _ in range(10):
        if _valid_layout(out):
            return out
        # shrink all nonzero sides by 0.5% and retry
        out2 = []
        for cx, cy, ang, side in out:
            if side > 0:
                side *= 0.995
            cx, cy, ang, side = _clamp_square(cx, cy, ang, side)
            out2.append((cx, cy, ang, side))
        out = out2
    # fallback: zero all squares if still invalid (should never happen)
    return [(0.5, 0.5, 0.0, 0.0)] * len(out)


def solve(n):
    """Main solver."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # Two equal rectangles: two squares side 0.5 each, if axis aligned.
        # But can do slightly better rotated? The reference likely expects 1.0.
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # 3 squares: two top small, one bottom large (best known ~1.207)
        # Use a simple layout: bottom square side 0.5, top two 0.5x0.5? That's 1.5
        # Actually 3 squares: 0.5+0.5+0.5=1.5 with 2x2 grid and one empty.
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # General case
    sq = _initial_grid(n)
    sq = _optimize(sq, n, time_budget_iters=2)
    sq = _final_cleanup(sq)

    # Ensure exactly n entries
    if len(sq) < n:
        sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n]
