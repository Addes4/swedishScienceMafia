import math
import random

try:
    import numpy as np
except Exception:
    np = None


# ---------- geometry ----------

def axis_square_ok(cx, cy, s):
    return cx - s * 0.5 >= -1e-12 and cx + s * 0.5 <= 1.0 + 1e-12 and \
           cy - s * 0.5 >= -1e-12 and cy + s * 0.5 <= 1.0 + 1e-12


def overlap_axis(cx1, cy1, s1, cx2, cy2, s2):
    # positive gap means separated
    gx = abs(cx1 - cx2) - (s1 + s2) * 0.5
    gy = abs(cy1 - cy2) - (s1 + s2) * 0.5
    return gx < -1e-12 and gy < -1e-12


def valid_solution(sqs):
    n = len(sqs)
    for i in range(n):
        cx, cy, a, s = sqs[i]
        if s < -1e-12:
            return False
        if not axis_square_ok(cx, cy, s):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if overlap_axis(sqs[i][0], sqs[i][1], sqs[i][3],
                            sqs[j][0], sqs[j][1], sqs[j][3]):
                return False
    return True


def score(sqs):
    return sum(s for _, _, _, s in sqs)


# ---------- known optimum-inspired small-n packings ----------

def solve_small(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        s = 0.5
        return [(0.25, 0.5, 0.0, s), (0.75, 0.5, 0.0, s)]
    if n == 3:
        # one large square plus two smaller stacked
        s1 = 0.5
        s2 = 0.25
        return [(0.25, 0.25, 0.0, s1),
                (0.75, 0.5, 0.0, s2),
                (0.75, 0.25, 0.0, s2)]
    if n == 4:
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s),
                (0.25, 0.75, 0.0, s), (0.75, 0.75, 0.0, s)]
    return None


# ---------- greedy construction ----------

def greedy_init(n, rng):
    # Start with loose random non-overlapping feasible axis-aligned squares.
    # Use a grid to place many tiny squares then grow locally.
    m = max(2, int(math.sqrt(n)) + 1)
    cell = 1.0 / m
    cells = [(i, j) for i in range(m) for j in range(m)]
    rng.shuffle(cells)
    sqs = []
    for idx in range(n):
        if idx < len(cells):
            i, j = cells[idx]
            cx = (i + 0.5) * cell
            cy = (j + 0.5) * cell
        else:
            cx = rng.random()
            cy = rng.random()
        # begin small to ensure feasibility
        s = min(cell, 0.2) * 0.8
        s = min(s, cx * 2, (1 - cx) * 2, cy * 2, (1 - cy) * 2)
        sqs.append([cx, cy, 0.0, max(s, 1e-6)])
    return sqs


# ---------- local search ----------

def try_adjust(sqs, n, rng, iters=4000):
    best = [row[:] for row in sqs]
    best_score = score(best)
    cur = [row[:] for row in best]
    cur_score = best_score

    for it in range(iters):
        i = rng.randrange(n)
        cx, cy, a, s = cur[i]

        mode = rng.random()
        new = [cx, cy, 0.0, s]

        if mode < 0.45:
            # grow side slightly
            ds = rng.uniform(0.0, 0.02) * (0.3 + s)
            new[3] = min(1.0, s + ds)
        elif mode < 0.65:
            # shrink to allow moves
            new[3] = max(0.0, s * rng.uniform(0.85, 1.0))
        elif mode < 0.85:
            # move centre
            step = rng.uniform(0.0, 0.02)
            new[0] = min(1.0, max(0.0, cx + rng.uniform(-step, step)))
            new[1] = min(1.0, max(0.0, cy + rng.uniform(-step, step)))
        else:
            # combined
            step = rng.uniform(0.0, 0.01)
            new[0] = min(1.0, max(0.0, cx + rng.uniform(-step, step)))
            new[1] = min(1.0, max(0.0, cy + rng.uniform(-step, step)))
            new[3] = min(1.0, s + rng.uniform(-0.005, 0.01))

        # clamp/square fit
        half = new[3] * 0.5
        new[0] = min(1.0 - half, max(half, new[0]))
        new[1] = min(1.0 - half, max(half, new[1]))

        # check pairwise only with i
        ok = True
        for j in range(n):
            if j == i:
                continue
            if overlap_axis(new[0], new[1], new[3],
                            cur[j][0], cur[j][1], cur[j][3]):
                ok = False
                break

        if ok:
            old_s = cur[i][3]
            cur[i] = new
            cur_score += new[3] - old_s
            if cur_score > best_score + 1e-12:
                best_score = cur_score
                best = [row[:] for row in cur]

    return best, best_score


def compactify(sqs):
    # Greedily enlarge each square in random-ish order while feasible.
    n = len(sqs)
    order = list(range(n))
    # enlarge small ones more aggressively
    order.sort(key=lambda i: sqs[i][3])
    improved = True
    while improved:
        improved = False
        for i in order:
            cx, cy, a, s = sqs[i]
            # binary-ish search max side
            lo, hi = s, min(1.0, min(cx, 1 - cx, cy, 1 - cy) * 2)
            if hi <= s + 1e-15:
                continue
            best_s = s
            for _ in range(28):
                mid = (lo + hi) * 0.5
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if overlap_axis(cx, cy, mid, sqs[j][0], sqs[j][1], sqs[j][3]):
                        ok = False
                        break
                if ok:
                    best_s = mid
                    lo = mid
                else:
                    hi = mid
            if best_s > s + 1e-12:
                sqs[i][3] = best_s
                improved = True
    return sqs


# ---------- main tuner ----------

def optimize(n, time_budget=50):
    rng = random.Random(1234567 + n)
    small = solve_small(n)
    if small is not None:
        return small

    best = None
    best_sc = -1.0

    attempts = 12 if n <= 25 else 8
    for t in range(attempts):
        init = greedy_init(n, rng)
        # random initial modifications
        cur, sc = try_adjust(init, n, rng, iters=1500 + n * 20)
        cur = compactify(cur)
        cur_score = score(cur)
        cur2, sc2 = try_adjust(cur, n, rng, iters=3000 + n * 40)
        cur2 = compactify(cur2)
        sc2 = score(cur2)
        if sc2 > best_sc:
            best_sc = sc2
            best = cur2

    # final long polish
    if best is not None:
        for _ in range(3):
            best, _ = try_adjust(best, n, rng, iters=5000 + n * 80)
            best = compactify(best)
            best_sc = score(best)

    if best is None:
        return solve(n)

    return [(float(cx), float(cy), 0.0, float(s)) for cx, cy, a, s in best]


# ---------- fallback baseline ----------

def solve(n):
    if n <= 4:
        return solve_small(n)

    # For very large n, a grid plus local improvement is safest.
    res = optimize(n, time_budget=45)
    if not valid_solution(res):
        # fall back to safe grid
        k = math.isqrt(n)
        side = 1.0 / k
        sqs = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
        sqs += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sqs))
        return sqs[:n]

    # ensure exactly n, all numbers in [0,1]
    out = []
    for cx, cy, a, s in res[:n]:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        s = min(1.0, max(0.0, s))
        half = s * 0.5
        cx = min(1.0 - half, max(half, cx))
        cy = min(1.0 - half, max(half, cy))
        out.append((float(cx), float(cy), float(a), float(s)))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
