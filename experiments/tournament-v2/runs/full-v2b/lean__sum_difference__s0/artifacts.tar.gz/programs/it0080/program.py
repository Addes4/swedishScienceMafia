# EVOLVE-BLOCK-START
"""Mixed-radix product construction.

Build A = { sum_i d_i * P_i : d_i in D_i } where D_i are digit alphabets and
P_i are place values chosen large enough that the digit representations never
"carry" (so distinct digit-vectors give distinct integers). Then

    |A - A| = prod_i |D_i - D_i| ,   |A + A| = prod_i |D_i + D_i|

and

    log|A-A| / log|A+A| = ( sum_i log|D_i-D_i| ) / ( sum_i log|D_i+D_i| )

i.e. a *weighted average* of the per-position ratios log|D_i-D_i|/log|D_i+D_i|,
weighted by log|D_i+D_i|.  By mixing positions with high-ratio alphabets we can
beat any single repeated alphabet.  We search a small library of good alphabets
and greedily choose the multiset of positions maximizing the overall ratio under
the size cap of 4000 elements.
"""
import math
import random
import time
from itertools import product


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabets(deadline):
    """Collect a library of small alphabets with good log|D-D|/log|D+D|."""
    R = 40
    lib = {}
    # structured seeds
    seeds = [
        [0, 1], [0, 1, 2], [0, 1, 3], [0, 1, 2, 4], [0, 1, 2, 4, 8],
        [0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8, 16, 32], [0, 1, 3, 7, 15],
        [0, 1, 2, 3, 4, 5], [0, 1, 4, 9, 16], [0, 1, 2, 5, 10],
    ]
    for sp in seeds:
        dd, ss = _ddstats(sp)
        if dd >= 2 and ss >= 2:
            lib[tuple(sorted(set(sp)))] = (dd, ss)

    def consider(D):
        D = tuple(sorted(set(D)))
        if len(D) < 2 or len(D) > 22:
            return
        if D in lib:
            return
        dd, ss = _ddstats(D)
        if dd >= 2 and ss >= 2:
            lib[D] = (dd, ss)

    while time.time() < deadline:
        s = random.randint(2, 14)
        D = sorted(random.sample(range(0, R + 1), s))
        dd, ss = _ddstats(D)
        if dd < 2 or ss < 2:
            continue
        r = math.log(dd) / math.log(ss)
        for _ in range(300):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.75 and cand:
                cand[random.randrange(len(cand))] = random.randint(0, R)
            elif op < 0.88:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2 or len(cand) > 22:
                continue
            cdd, css = _ddstats(cand)
            if cdd < 2 or css < 2:
                continue
            cr = math.log(cdd) / math.log(css)
            if cr >= r:
                D, r, dd, ss = cand, cr, cdd, css
        if dd >= 2 and ss >= 2:
            consider(D)

    # keep only alphabets whose ratio is at least decent; dedupe by (dd, ss, size)
    out = []
    best_per = {}
    for D, (dd, ss) in lib.items():
        r = math.log(dd) / math.log(ss)
        key = (len(D), dd, ss)
        if key not in best_per or r > best_per[key][0]:
            best_per[key] = (r, D, dd, ss)
    for key, (r, D, dd, ss) in best_per.items():
        out.append((r, len(D), dd, ss, list(D)))
    out.sort(reverse=True)
    return out


def _select_positions(lib, cap=4000):
    """Greedily choose a multiset of alphabets (positions) maximizing the
    weighted-average ratio = sum log(dd) / sum log(ss), respecting the product
    size cap and an integer bit budget."""
    # We treat each position as contributing (log ss, log dd) with a size
    # multiplier |D|.  Overall ratio = total_log_dd / total_log_ss.
    # Greedy: repeatedly add the position giving the best ratio improvement
    # (max marginal gain), staying under the cap.
    # Precompute per alphabets sorted by "efficiency".
    cands = []
    for (r, sz, dd, ss, D) in lib[:120]:
        cands.append((sz, math.log(dd), math.log(ss), D))

    total_size = 1
    tot_dd = 0.0
    tot_ss = 0.0
    chosen = []
    while True:
        best_gain = -1.0
        best_idx = -1
        for i, (sz, ldd, lss, D) in enumerate(cands):
            if total_size * sz > cap:
                continue
            new_r = (tot_dd + ldd) / (tot_ss + lss) if (tot_ss + lss) > 0 else 0
            cur_r = (tot_dd / tot_ss) if tot_ss > 0 else 0
            gain = new_r - cur_r if tot_ss > 0 else new_r
            if gain > best_gain:
                best_gain = gain
                best_idx = i
        if best_idx < 0 or best_gain <= 1e-9:
            # also try to fill remaining capacity greedily even if no gain
            if best_idx < 0:
                break
        if best_idx < 0:
            break
        sz, ldd, lss, D = cands[best_idx]
        total_size *= sz
        tot_dd += ldd
        tot_ss += lss
        chosen.append(D)
        if best_gain <= 1e-12:
            break

    if not chosen:
        chosen = [[0, 1]]
        total_size = 2
    return chosen, total_size


def _build_mixed(chosen):
    """Build the mixed-radix product set."""
    # normalize each alphabet, compute place values to avoid carries
    norm = []
    for D in chosen:
        D = sorted(set(D))
        D = [d - D[0] for d in D]
        norm.append(D)
    # place value P_i must exceed (max span of any single digit) * current place,
    # choose multipliers = 2*span+1 cumulatively.
    places = []
    p = 1
    for D in norm:
        places.append(p)
        span = max(D)
        p *= (2 * span + 1 if span > 0 else 2)
    vals = [0]
    for D, pl in zip(norm, places):
        new = []
        for v in vals:
            for d in D:
                new.append(v + d * pl)
        vals = new
    return sorted(set(vals))


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    deadline = time.time() + 60
    lib = _search_alphabets(deadline)

    candidates = []
    # mixed-radix from greedy selection
    chosen, _ = _select_positions(lib)
    candidates.append(_build_mixed(chosen))
    # fall back to pure power constructions of the best alphabets
    for (r, sz, dd, ss, D) in lib[:8]:
        k = 1
        while sz ** (k + 1) <= 4000:
            k += 1
        candidates.append(_build_mixed([D] * k))
    candidates.append(_build_mixed([[0, 1, 2, 4, 8, 16]] * 4))

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        c = list(set(c))
        if len(c) > 4000:
            continue
        if max(abs(v) for v in c) > 10 ** 15:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    if best is None:
        best = [0, 1]
    return list(best)
# EVOLVE-BLOCK-END
