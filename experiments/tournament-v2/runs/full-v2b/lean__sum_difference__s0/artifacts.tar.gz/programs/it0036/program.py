# EVOLVE-BLOCK-START
"""Fast exact hill climber on a digit-construction seed."""
import math
import random
import time
import numpy as np


def _score_arr(a):
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0
    d = np.subtract.outer(a, a).ravel()
    s = np.add.outer(a, a).ravel()
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns == 0 or nd == 0:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _seed(B, k, digits_extra):
    # elements = sum d_i B^i with d_i in {0,1}; add one wide digit
    els = []
    for i in range(k):
        els.append(B ** i)
    # add wide digit variants
    base = sum(B ** i for i in range(k))
    for e in digits_extra:
        els.append(base + e)
    return els


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100.0

    # build candidate seeds from several bases
    seeds = []
    for B in (3, 4, 5, 6, 7, 2):
        for k in range(2, 9):
            if B ** (k) > 1e15:
                break
            base = sum(B ** i for i in range(k))
            els = [B ** i for i in range(k)]
            for e in (0, 1, 2, 3, -1, -2, B // 2, -B // 2):
                v = base + e
                if abs(v) <= 1e15:
                    els.append(v)
            seeds.append([x for x in els if abs(x) <= 1e15])

    # also original good seed
    seeds.append([7, 15, 18, 22, -3, -2])

    for seed in seeds:
        a = sorted(set(seed))
        if len(a) < 2:
            continue
        sc = _score_arr(a)
        if sc > best_score:
            best_score = sc
            best = a[:]

    # hill climbing with random restarts
    while time.time() < deadline:
        cur = best[:] if best else [7, 15, 18, 22, -3, -2]
        cur_score = _score_arr(cur)
        stall = 0
        while time.time() < deadline and stall < 400:
            cand = cur[:]
            r = random.random()
            if r < 0.45 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-3, 3)
            elif r < 0.8:
                cand.append(random.randint(-40, 40))
            else:
                if len(cand) > 3:
                    cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) > 60:
                stall += 1
                continue
            s = _score_arr(cand)
            if s >= cur_score:
                cur, cur_score = cand, s
                stall = 0
                if s > best_score:
                    best_score, best = s, cand[:]
            else:
                stall += 1
    return best if best else [7, 15, 18, 22, -3, -2]
# EVOLVE-BLOCK-END
