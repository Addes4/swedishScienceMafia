# EVOLVE-BLOCK-START
"""Construct A as a union of shifted copies of a small block.

A = { i*B + d : i in [0,n), d in D },  B > 2*span(D)  (no overlap between blocks).

Differences: a - a' with block indices i, i'. If i != i', the difference is
(i-i')*B + (d - d') which is determined by (i-i', d-d'); there are ~2n * |D-D|
distinct values (since |i-i'|*B separates them). If i == i', the difference is
d - d' with |D-D| values. So |A-A| ~ 2n*|D-D| + |D-D| = (2n+1)|D-D|, i.e. a
*linear* (in n) difference count from a quadratic-order construction -- exactly
the "many differences" regime.

Sums: a + a' = (i+i')*B + (d+d'). Since B separates, i+i' ranges over
[0, 2n-2] (2n-1 values) and d+d' ranges over D+D (|D+D| values), total
|A+A| ~ (2n-1)*|D+D|.

Ratio ~ log(2n|D-D|)/log(2n|D+D|) which, as n grows, tends to 1 but with the
constant |D-D|/|D+D| ratio baked in a favourable direction. We directly search
the realized exact score over n, B, and the alphabet D.
"""
import math
import random
import time


def _stats(vals):
    """Exact |A-A|, |A+A| using sets (A small)."""
    s = set(vals)
    dd = len({x - y for x in s for y in s})
    ss = len({x + y for x in s for y in s})
    return dd, ss


def _score(vals):
    s = set(vals)
    if len(s) < 2:
        return 0.0
    dd = len({x - y for x in s for y in s})
    ss = len({x + y for x in s for y in s})
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss) + (1 - 1 / len(s)) / 100


def _build_block(D, n, B):
    D = sorted(set(D))
    return sorted({i * B + d for i in range(n) for d in D})


def _best_block(D, cap=1200, deadline=None):
    """Given alphabet D, choose n and B to maximize the realized score."""
    D = sorted(set(D))
    if len(D) < 2:
        return [0, 1], -1.0
    span = max(D) - min(D)
    best_vals, best_s = None, -1.0
    # B must exceed span to avoid block overlap; scan a few multipliers.
    for B in range(span + 1, span + 1 + 40):
        for n in range(2, cap):
            if deadline and time.time() > deadline:
                return best_vals, best_s
            if n * len(D) > cap:
                break
            vals = _build_block(D, n, B)
            if len(vals) < 2:
                continue
            s = _score(vals)
            if s > best_s:
                best_s, best_vals = s, vals
    if best_vals is None:
        best_vals = _build_block(D, 2, span + 1)
        best_s = _score(best_vals)
    return best_vals, best_s


def _search_alphabet(deadline):
    """Hill-climb integer alphabets D to feed the block construction."""
    R = 40
    best_D = [0, 1, 2, 4, 8, 16]
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32], [0, 1, 4, 9, 16]]
    best_r = -1.0
    for sp in seed_pool:
        v, s = _best_block(sp, cap=600, deadline=deadline)
        if s > best_r:
            best_r, best_D = s, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 12)
        D = sorted(random.sample(range(0, R + 1), s))
        _, r = _best_block(D, cap=400, deadline=deadline)
        for _ in range(200):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.7 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            _, cr = _best_block(cand, cap=400, deadline=deadline)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def solve():
    deadline = time.time() + 100

    best_vals, best_s = None, -1.0

    # Try several structured alphabets first (fast, robust).
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5], [0, 1, 4, 9, 16],
               [0, 1, 3, 7, 15, 31]):
        v, s = _best_block(sp, cap=1000, deadline=deadline)
        if s > best_s:
            best_s, best_vals = s, v

    # Search the alphabet space.
    D, _ = _search_alphabet(min(deadline, time.time() + 60))
    v, s = _best_block(D, cap=1500, deadline=deadline)
    if s > best_s:
        best_s, best_vals = s, v

    # Also evaluate the original carry-free product set as a safety comparison.
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8]):
        sp = sorted(set(sp))
        k = 1
        while len(sp) ** (k + 1) <= 4000:
            k += 1
        span = max(sp) - min(sp)
        B = 2 * span + 1
        vals = set()
        # iterative product
        cur = {0}
        for _ in range(k):
            nxt = set()
            for v0 in cur:
                for d in sp:
                    nxt.add(v0 * B + d)
            cur = nxt
        vals = sorted(cur)
        sc = _score(vals)
        if sc > best_s:
            best_s, best_vals = sc, vals

    return list(best_vals)
# EVOLVE-BLOCK-END

