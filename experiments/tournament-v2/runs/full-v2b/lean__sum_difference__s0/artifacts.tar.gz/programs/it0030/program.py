# EVOLVE-BLOCK-START
"""Mojon-style digit construction: maximise log|A-A|/log|A+A|.

We build A = { sum_{i=0}^{k-1} d_i * B^i : d_i in D_i }
where most digit sets are {0,1} (small contribution to A+A), and one digit set
is a wide interval (big contribution to A-A).  We search over base B, number of
positions k, wide digit width w, and which position is wide.
"""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    nd, ns = len(diffs), len(sums)
    if ns < 2:
        return -1.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def _build(B, k, wide_pos, w):
    """Digits: wide_pos has range 0..w-1, others {0,1}."""
    sets = []
    for i in range(k):
        if i == wide_pos:
            sets.append(list(range(w)))
        else:
            sets.append([0, 1])
    A = [0]
    for i in range(k):
        pw = B ** i
        A = [x + d * pw for x in A for d in sets[i]]
    return A


def solve():
    bestA = None
    bestScore = -1.0
    deadline = time.time() + 100

    # candidate parameters
    params = []
    for B in [2, 3, 4, 5, 6, 7, 8]:
        for k in range(3, 13):
            for wp in range(k):
                for w in [2, 3, 4, 5, 6, 8]:
                    n = (w) * (2 ** (k - 1))
                    if n < 2 or n > 4000:
                        continue
                    maxabs = (B ** (k - 1)) * max(w, 1) + (B ** (k - 1))
                    if maxabs > 1e15:
                        continue
                    params.append((B, k, wp, w))

    # sort by heuristic size (bigger set usually helps bonus)
    params.sort(key=lambda p: -((p[3]) * (2 ** (p[1] - 1))))

    for (B, k, wp, w) in params:
        if time.time() > deadline:
            break
        A = _build(B, k, wp, w)
        if len(set(A)) != len(A):
            # ensure distinct by construction (bases >= w normally fine)
            A = list(set(A))
        if len(A) < 2 or len(A) > 4000:
            continue
        s, nd, ns = _score(A)
        if s > bestScore:
            bestScore = s
            bestA = A[:]
            # try to locally improve this near-optimal set quickly
            A2, s2 = _polish(A, bestScore, deadline)
            if s2 > bestScore:
                bestScore = s2
                bestA = A2

    if bestA is None:
        bestA = [0, 1]
    return sorted(set(int(x) for x in bestA))


def _polish(A, cur_score, deadline):
    import random
    A = list(set(A))
    step_limit = time.time() + 4.0
    while time.time() < step_limit and time.time() < deadline:
        i = random.randrange(len(A))
        old = A[i]
        A[i] = old + random.choice([-1, 1]) * random.choice([1, 2])
        s, nd, ns = _score(A)
        if s >= cur_score:
            cur_score = s
        else:
            A[i] = old
    return sorted(set(A)), cur_score
# EVOLVE-BLOCK-END
