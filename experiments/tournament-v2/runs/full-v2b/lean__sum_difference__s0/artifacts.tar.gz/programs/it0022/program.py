# EVOLVE-BLOCK-START
"""Digit-based construction: A = sums of digits d_i * B^i with a large leading alphabet
and small trailing alphabets, which tends to give |A-A| >> |A+A| when B is large enough
that digit blocks do not interfere destructively."""
import math
import time


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build(B, digits):
    """A = { sum d_i * B^i : d_i in range(digits[i]) }."""
    A = [0]
    p = 1
    for d in digits:
        newA = []
        for x in A:
            for k in range(d):
                newA.append(x + k * p)
        A = newA
        p *= B
    return A


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # Try digit constructions with a big leading digit and small trailing digits.
    candidates = []
    # Base range: large enough to separate blocks.
    for B in range(3, 60):
        for lead in range(2, 40):
            # trailing digits all 2 (binary-ish), increasing length
            for L in range(0, 8):
                digits = [lead] + [2] * L
                if sum(digits) > 4000:
                    continue
                size = 1
                for d in digits:
                    size *= d
                if size > 4000:
                    continue
                candidates.append((B, digits))
    # Also try mixed trailing digit sizes.
    for B in range(5, 40):
        for lead in (3, 4, 6, 8, 12, 20):
            for t in (2, 3):
                for L in range(0, 6):
                    digits = [lead] + [t] * L
                    size = 1
                    for d in digits:
                        size *= d
                    if size > 4000:
                        continue
                    candidates.append((B, digits))

    seen = set()
    for (B, digits) in candidates:
        key = (B, tuple(digits))
        if key in seen:
            continue
        seen.add(key)
        if time.time() > deadline:
            break
        A = _build(B, digits)
        if len(A) > 4000 or len(A) < 2:
            continue
        if max(abs(x) for x in A) > 10**15:
            continue
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A

    if best is None:
        return [7, 15, 18, 22, -3, -2]
    return sorted(set(best))
# EVOLVE-BLOCK-END
