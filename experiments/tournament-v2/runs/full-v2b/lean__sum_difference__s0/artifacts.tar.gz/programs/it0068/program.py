# EVOLVE-BLOCK-START
"""Construct A as a carry-free mixed-radix product set.

If A = { sum_i d_i B^i : d_i in D } with B large enough that no two digit-vectors
collide (no carries), then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so the objective log|A-A|/log|A+A| = log|D-D|/log|D+D| is independent of k.
We replicate the best alphabet to fill the size cap for the bonus.

Scoring uses a fast numpy vectorized unique-count so we can evaluate many
candidates within the time budget.
"""
import math
import time
from itertools import product

import numpy as np


def _np_stats(vals):
    """Fast |A-A|, |A+A| using numpy unique."""
    a = np.asarray(vals, dtype=np.int64)
    d = np.unique(a[:, None] - a[None, :])
    s = np.unique(a[:, None] + a[None, :])
    return d.size, s.size


def _np_score(vals):
    a = np.asarray(vals, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0
    d = np.unique(a[:, None] - a[None, :])
    s = np.unique(a[:, None] + a[None, :])
    if d.size < 2 or s.size < 2:
        return 0.0
    return math.log(int(d.size)) / math.log(int(s.size)) + (1 - 1 / n) / 100


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Small hill-climb over integer alphabets D maximizing log|D-D|/log|D+D|."""
    R = 34
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32],
                 [0, 1, 2, 4, 8, 16, 32, 64]]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random_len = 2 + int(time.time() * 1e6) % 12
        D = sorted(set(__import__('random').sample(range(0, R + 1), min(s, R + 1))))
        r = _ratio(D)
        for _ in range(300):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = (time.time() * 1e6) % 1.0
            if op < 0.7 and cand:
                i = int((time.time() * 1e6) % len(cand))
                cand[i] = int((time.time() * 1e7) % (R + 1))
            elif op < 0.85:
                cand.append(int((time.time() * 1e7) % (R + 1)))
            elif len(cand) > 2:
                cand.pop(int((time.time() * 1e6) % len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    """Product (subset-sum) set from alphabet D, largest size <= cap."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _build_mixed(alphas, cap=4000):
    """Carry-free mixed-radix product: position i uses alphabet alphas[i]."""
    alphas = [sorted(set(a)) for a in alphas]
    for a in alphas:
        if len(a) < 2:
            return None
    span = max(max(a) - min(a) for a in alphas)
    B = 2 * span + 1
    vals = [0]
    p = 1
    for a in alphas:
        base = min(a)
        newv = []
        for v in vals:
            for d in a:
                newv.append(v + (d - base) * p)
        p *= B
        vals = newv
        if len(vals) > 20000:
            return None
    return sorted(set(vals))


def solve():
    t0 = time.time()
    deadline = t0 + 55
    D, r = _search_alphabet(deadline)

    candidates = []

    # Direct product from best alphabet at max width
    candidates.append(_build(D))

    # Mixed constructions: combine high-ratio alphabet with a geometric-like
    # block sharing an extra large scale so differences spread more.
    struct = [
        [0, 1, 2, 4, 8, 16],
        [0, 1, 3, 7, 15],
        [0, 1, 2, 4, 8],
        [0, 1, 2, 4],
        [0, 1, 3],
        [0, 1, 2, 3, 4, 5],
    ]
    seen = set()
    for sp in struct + [D]:
        key = tuple(sorted(set(sp)))
        if key in seen:
            continue
        seen.add(key)
        candidates.append(_build(list(key)))

    # Try putting a couple of structured blocks in sequence (independent scales)
    bases = struct + [D]
    for a in bases:
        for b in bases:
            m = _build_mixed([a, b])
            if m:
                candidates.append(m)

    # Try three-block mixes using the strongest alphabets only
    strong = [D, [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8]]
    for a in strong:
        for b in strong:
            for c in strong:
                if time.time() > deadline:
                    break
                m = _build_mixed([a, b, c])
                if m and len(m) <= 4000:
                    candidates.append(m)

    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if not c or len(c) < 2 or len(c) > 4000:
            continue
        if time.time() > t0 + 115:
            break
        sc = _np_score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
