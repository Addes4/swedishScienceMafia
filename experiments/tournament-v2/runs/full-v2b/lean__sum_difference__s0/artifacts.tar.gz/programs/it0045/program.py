# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a tuned digit alphabet D.

If A = { sum_i d_i B^i : d_i in D } with B large enough that no two digit-vectors
collide (no carries), then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so the objective log|A-A|/log|A+A| = log|D-D|/log|D+D| is independent of k.
Therefore we only need to find a small integer alphabet D maximizing
log|D-D|/log|D+D|, then replicate it (largest k with |D|^k <= 4000) for the size bonus.

The alphabet search uses a fast boolean-convolution (via Python ints as big bitsets)
to compute |D-D| and |D+D| exactly, which lets us try far more candidate alphabets.
"""
import math
import random
import time
from itertools import product


def _ddss(D):
    """Exact (|D-D|, |D+D|) using integer bitsets (fast boolean OR-shift)."""
    D = sorted(set(D))
    lo = min(D)
    Dn = [d - lo for d in D]           # non-negative
    hi = max(Dn)
    if hi == 0:
        return 1, 1
    span = 2 * hi                      # both diffs and sums fit in [0, 2*hi]
    dmask = 0
    smask = 0
    for i in range(len(Dn)):
        di = Dn[i]
        for j in range(len(Dn)):
            dj = Dn[j]
            dmask |= 1 << (di - dj + hi)     # diff in [-hi, hi] shifted by hi
            smask |= 1 << (di + dj)          # sum in [0, 2*hi]
    dd = bin(dmask).count("1")
    ss = bin(smask).count("1")
    return dd, ss


def _ratio(D):
    dd, ss = _ddss(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Steepest-ascent / hill-climb over integer alphabets maximizing log|D-D|/log|D+D|."""
    R = 40
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32],
                 [0, 1, 2, 4, 8, 16, 32, 64]]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 14)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        # steepest-ascent local search with add/remove/move
        improved = True
        while improved and time.time() < deadline:
            improved = False
            best_move = None
            for i in range(len(D)):
                for v in range(0, R + 1):
                    if v == D[i]:
                        continue
                    cand = D[:]
                    cand[i] = v
                    cand = sorted(set(cand))
                    if len(cand) < 2:
                        continue
                    cr = _ratio(cand)
                    if cr > r + 1e-12:
                        r = cr
                        best_move = cand
                        improved = True
                if improved:
                    break
            if improved:
                D = best_move
            # try removals
            if not improved:
                for i in range(len(D)):
                    cand = D[:]
                    cand.pop(i)
                    if len(cand) < 2:
                        continue
                    cr = _ratio(cand)
                    if cr > r + 1e-12:
                        r = cr
                        best_move = cand
                        improved = True
                        break
                if improved:
                    D = best_move
            # try additions
            if not improved and len(D) < 16:
                for v in range(0, R + 1):
                    if v in D:
                        continue
                    cand = sorted(D + [v])
                    cr = _ratio(cand)
                    if cr > r + 1e-12:
                        r = cr
                        best_move = cand
                        improved = True
                        break
                if improved:
                    D = best_move
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    """Build the product set (subset sums) from alphabet D, largest size <= cap."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]          # normalize to start at 0
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1                     # no carries between digit positions
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    deadline = time.time() + 55
    D, r = _search_alphabet(deadline)

    candidates = []
    candidates.append(_build(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5], [0, 1, 2, 4, 8, 16, 32]):
        candidates.append(_build(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
