# EVOLVE-BLOCK-START
"""Geometric-progression construction tuned on the exact score, with local refinement."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _geo_score(b, n):
    # A = {b^i : 0..n-1}, but keep values bounded; evaluate exactly on small n
    a = [b ** i for i in range(n)]
    if max(a) > 10 ** 15:
        return -1.0, None
    return _score(a), a


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    deadline = time.time() + 110

    # 1) Scan geometric progressions over bases and lengths exactly.
    for b in range(2, 64):
        for n in range(2, 40):
            s, a = _geo_score(b, n)
            if s > best_score:
                best_score, best = s, a[:]
        if time.time() > deadline:
            break

    # 2) Local refinement from the best construction found.
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.6:
            i = random.randrange(len(cand))
            delta = random.randint(-3, 3)
            cand[i] += delta
        elif r < 0.8 and len(cand) < 60:
            cand.append(random.choice(cand) + random.randint(-2, 2))
        elif len(cand) > 3:
            i = random.randrange(len(cand))
            del cand[i]
        if len(set(cand)) < 2:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand[:], s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
