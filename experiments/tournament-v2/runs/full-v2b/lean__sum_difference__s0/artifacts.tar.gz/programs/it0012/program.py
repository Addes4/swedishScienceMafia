import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    ls = list(a)
    for i in range(n):
        xi = ls[i]
        for j in range(n):
            xj = ls[j]
            diffs.add(xi - xj)
            if j >= i:
                sums.add(xi + xj)
    # sums of all ordered pairs == same set; only computed i<=j, symmetric
    ld = len(diffs)
    lsm = len(sums)
    if ld < 2 or lsm < 2:
        return 0.0
    return math.log(ld) / math.log(lsm) + (1 - 1 / n) / 100


def _score_fast(ls):
    n = len(ls)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        xi = ls[i]
        for j in range(n):
            diffs.add(xi - ls[j])
            sums.add(xi + ls[j])
    ld = len(diffs)
    lsm = len(sums)
    if ld < 2 or lsm < 2:
        return 0.0
    return math.log(ld) / math.log(lsm) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 115
    rng = random.Random(12345)
    best = None
    best_score = -1.0

    # seed sets
    seeds = []
    # dense interval
    seeds.append(list(range(1, 16)))
    # geometric-ish
    seeds.append([2 ** i for i in range(10)])
    # mixed interval + doubling
    seeds.append([i for i in range(8)] + [16 * (1 + 2 ** j) for j in range(4)])

    for seed in seeds:
        cur = list(set(seed))
        cs = _score_fast(cur)
        if cs > best_score:
            best_score = cs
            best = cur[:]

    while time.time() < deadline:
        cur = best[:]
        cs = best_score
        T = 0.05
        steps = 0
        while time.time() < deadline and steps < 4000:
            steps += 1
            cand = cur[:]
            op = rng.random()
            if op < 0.65:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-2, 2)
                if cand[i] == 0:
                    cand[i] += 1
            elif op < 0.85:
                cand.append(rng.randint(-20, 20) or 1)
            elif op < 0.95 and len(cand) > 3:
                cand.pop(rng.randrange(len(cand)))
            else:
                if len(cand) >= 2:
                    i, j = rng.randrange(len(cand)), rng.randrange(len(cand))
                    cand[i], cand[j] = cand[j], cand[i]
            cand = list(dict.fromkeys(cand))
            if len(cand) < 2:
                continue
            s = _score_fast(cand)
            if s >= cs or rng.random() < math.exp((s - cs) / max(T, 1e-9)):
                cur, cs = cand, s
                if s > best_score:
                    best_score = s
                    best = cand[:]
            if time.time() > deadline:
                break
        # cool
        T *= 0.7

    return sorted(set(best))
# EVOLVE-BLOCK-END
