# EVOLVE-BLOCK-START
"""Mixed-radix digit construction with parameter search."""
import math
import random
import time
from itertools import product


def _score_sizes(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            diffs.add(ai - aj)
            diffs.add(aj - ai)
            sums.add(ai + aj)
    if len(sums) < 2:
        return 0.0, len(diffs), len(sums)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def _build(radices, digit_sets):
    """Elements are sums d_i * B^i with d_i in digit_sets[i]."""
    A = [0]
    mul = 1
    for r, ds in zip(radices, digit_sets):
        newA = []
        for base in A:
            for d in ds:
                newA.append(base + d * mul)
        A = newA
        mul *= r
    return A


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # candidate parameter vectors: (list of radices, list of digit alphabets)
    def make_rand():
        k = random.randint(5, 9)
        radices = []
        digit_sets = []
        for _ in range(k):
            r = random.randint(4, 30)
            radices.append(r)
            mode = random.random()
            if mode < 0.5:
                # {0,1} alphabet, plus occasional small extras
                ds = [0, 1]
            elif mode < 0.8:
                m = random.randint(2, 4)
                ds = list(range(m))
            else:
                m = random.randint(2, 3)
                ds = [0] + [random.randint(1, r - 1) for _ in range(m)]
                ds = sorted(set(ds))
            digit_sets.append(ds)
        return radices, digit_sets

    # seed some sensible ones
    seeds = []
    for k in range(5, 9):
        seeds.append(([2 + i for i in range(k)], [[0, 1]] * k))
    for k in range(5, 8):
        seeds.append(([4] * k, [[0, 1]] * k))
    for k in range(5, 7):
        seeds.append(([6] * k, [[0, 1, 2]] * k))

    def evaluate(radices, digit_sets):
        A = _build(radices, digit_sets)
        A = list(set(A))
        if len(A) > 4000:
            # subsample is not allowed; just truncate parameters => rebuild with fewer
            return -1.0, A
        s, nd, ns = _score_sizes(A)
        return s, A

    for radices, digit_sets in seeds:
        s, A = evaluate(radices, digit_sets)
        if s > best_score:
            best_score, best = s, A

    while time.time() < deadline:
        radices, digit_sets = make_rand()
        # local tweaks derived from best seed
        if best is not None and random.random() < 0.5:
            # attempt to grow current best structure by appending a small radix alphabet
            radices2 = radices[:]
            digit_sets2 = [list(x) for x in digit_sets]
            s, A = evaluate(radices2, digit_sets2)
        else:
            s, A = evaluate(radices, digit_sets)
        if s > best_score and A and len(A) <= 4000:
            best_score, best = s, A

    if best is None:
        return [7, 15, 18, 22, -3, -2]
    return sorted(set(best))
# EVOLVE-BLOCK-END
