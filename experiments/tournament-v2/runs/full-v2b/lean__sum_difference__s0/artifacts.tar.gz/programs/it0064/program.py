# EVOLVE-BLOCK-START
"""Two-block no-carry construction: A = P + I, where

  P = subset sums over a digit alphabet D repeated k times in base B (no carries),
  I = {0,1,...,m-1} an interval block.

For a no-carry product set, |P-P| = |D-D|^k and |P+P| = |D+D|^k.
Adding an interval block I changes the statistics, and we tune (D, k, m, B)
by evaluating the ACTUAL realized score of the full constructed set, rather
than a ratio-of-ratios proxy.
"""
import math
import random
import time
from itertools import product


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Hill-climb over small integer alphabets D maximizing the ratio proxy."""
    R = 34
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32], [0, 1, 2, 4, 6]]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 13)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        for _ in range(400):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.7 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _product_set(D, k, B):
    """Subset sums over D repeated k times in base B (no carries expected)."""
    D = sorted(set(D))
    if len(D) < 2 or k < 1:
        return []
    out = set()
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        out.add(v)
    return out


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 55
    cap = 4000

    D, r = _search_alphabet(deadline)

    candidates = []

    def add(A):
        A = sorted(set(A))
        if 2 <= len(A) <= cap:
            candidates.append(A)

    # Baseline structured alphabets and a good hand alphabet.
    alphabet_pool = [D, [0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
                     [0, 1, 2, 4], [0, 1, 2, 4, 8, 16, 32], [0, 1, 2, 3, 5, 8, 13]]

    # Pure products (no interval block).
    for DD in alphabet_pool:
        DD = sorted(set(DD))
        s = len(DD)
        if s < 2:
            continue
        span = max(DD) - min(DD)
        B = 2 * span + 1
        k = 1
        while s ** (k + 1) <= cap:
            k += 1
        add(_product_set(DD, k, B))

    # Two-block construction: product set P + interval I = {0..m-1}.
    # Try several alphabet/interval splits under the size cap.
    for DD in alphabet_pool:
        DDn = sorted(set(DD))
        s = len(DDn)
        if s < 2:
            continue
        DDn = [d - min(DDn) for d in DDn]
        span = max(DDn) - min(DDn)
        B = 2 * span + 1
        for k in range(1, 12):
            if s ** k > cap:
                break
            P = _product_set(DDn, k, B)
            if not P:
                continue
            psize = len(P)
            # interval length m so that psize * m ~ cap
            for m in (1, 2, 3, 4, 5, 8, 12, 16, 24, 32, 48, 64):
                if psize * m > cap:
                    break
                I = list(range(0, m))
                A = [p + i * (B ** k) for p in P for i in I]
                add(A)

    # Also try interval first, product as blocks (equivalent layout) with
    # a shift to break additive symmetry.
    for DD in [D, [0, 1, 2, 4, 8, 16], [0, 1, 3, 7, 15]]:
        DDn = sorted(set(DD))
        s = len(DDn)
        if s < 2:
            continue
        DDn = [d - min(DDn) for d in DDn]
        span = max(DDn) - min(DDn)
        B = 2 * span + 1
        for k in range(1, 10):
            if s ** k > cap:
                break
            P = _product_set(DDn, k, B)
            if not P:
                continue
            for m in (3, 5, 8, 16, 32):
                if len(P) * m > cap:
                    break
                for shift in (0, B ** k // 3, B ** k // 2):
                    A = [p + i * (B ** k) + shift for p in P for i in range(m)]
                    add(A)

    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    if best is None:
        best = [0, 1, 2, 4, 8, 16]
    return list(best)
# EVOLVE-BLOCK-END

