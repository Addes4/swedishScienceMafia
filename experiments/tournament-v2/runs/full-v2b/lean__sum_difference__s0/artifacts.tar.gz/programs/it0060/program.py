# EVOLVE-BLOCK-START
"""Construct A via no-carry mixed-radix digit expansion.

A = { sum_i d_i * P_i : d_i in D_i },  P_i = prod_{j<i} B_j
with each B_j larger than the span of D_j - D_j so there are no carries
between positions.

Then A - A = { sum_i e_i P_i : e_i in D_i - D_i }  (products of difference sets)
and A + A = { sum_i s_i P_i : s_i in D_i + D_i }   (products of sum sets),
so  |A-A| = prod |D_i - D_i|, |A+A| = prod |D_i + D_i|  EXACTLY.

Hence the objective = sum_i log|D_i-D_i| / sum_i log|D_i+D_i|, i.e. a weighted
average of the per-position ratios.  Maximising the whole thing means using
positions with the best individual ratio, weighted by their size contribution.

We search small integer alphabets D (a wide, long hill-climb) maximising
log|D-D|/log|D+D|, then tile the product so |A| <= 4000, mixing the best
alphabet with itself to keep the ratio maximal (product of identical ratios).
"""
import math
import random
import time
from itertools import product


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


# cache of D -> (ratio, |D|, log|D-D|, log|D+D|)
_CACHE = {}


def _info(D):
    key = tuple(sorted(set(D)))
    v = _CACHE.get(key)
    if v is None:
        dd, ss = _ddstats(key)
        if dd < 2 or ss < 2:
            v = (0.0, len(key), 0.0, 0.0)
        else:
            v = (math.log(dd) / math.log(ss), len(key),
                 math.log(dd), math.log(ss))
        _CACHE[key] = v
    return v


def _search_alphabet(deadline, seed_pool):
    """Hill-climb small integer alphabets D maximizing log|D-D|/log|D+D|."""
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _info(best_D)[0]
    for sp in seed_pool:
        r = _info(sp)[0]
        if r > best_r:
            best_r, best_D = r, list(sp)

    # Try a few radices R (alphabet value range)
    for R in (16, 24, 34, 48):
        while time.time() < deadline:
            s = random.randint(3, 14)
            D = sorted(random.sample(range(0, R + 1), s))
            r = _info(D)[0]
            for _ in range(300):
                if time.time() >= deadline:
                    break
                cand = D[:]
                op = random.random()
                if op < 0.7 and cand:
                    i = random.randrange(len(cand))
                    cand[i] = random.randint(0, R)
                elif op < 0.85:
                    cand.append(random.randint(0, R))
                elif len(cand) > 2:
                    cand.pop(random.randrange(len(cand)))
                cand = sorted(set(cand))
                if len(cand) < 2:
                    continue
                cr = _info(cand)[0]
                if cr >= r:
                    D, r = cand, cr
            if r > best_r:
                best_r, best_D = r, D[:]
        if time.time() >= deadline:
            break
    return best_D, best_r


def _build_product(D, cap=4000):
    """Build no-carry product set from identical alphabet D, size <= cap."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _build_mixed(alphas, cap=4000):
    """Build mixed-radix no-carry product from a list of alphabets alphas.

    Positions are added greedily while the product size stays <= cap.
    """
    alphas = [sorted(set(a)) for a in alphas if len(set(a)) >= 2]
    if not alphas:
        return [0, 1]
    # position i uses alphas[i % len(alphas)]
    seq = []
    size = 1
    i = 0
    while True:
        a = alphas[i % len(alphas)]
        if size * len(a) > cap:
            break
        seq.append(a)
        size *= len(a)
        i += 1
        if i > 100:
            break
    if not seq:
        return [0, 1]

    vals = [0]
    B = 1
    for a in seq:
        a = [d - min(a) for d in a]
        span = max(a) - min(a)
        base = 2 * span + 1
        if base < 1:
            base = 1
        new = []
        for v in vals:
            for d in a:
                new.append(v + d * B)
        vals = new
        B *= base
    return sorted(set(vals))


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    deadline = time.time() + 90

    seeds = [
        [0, 1, 2, 4, 8, 16],
        [0, 1, 2, 4, 8, 16, 32],
        [0, 1, 2, 4],
        [0, 1, 3, 7, 15],
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
        [0, 1, 2, 4, 8, 15],
        [7, 15, 18, 22, -3, -2],
    ]

    best_D, best_r = _search_alphabet(deadline, seeds)

    # Collect a diverse pool of good alphabets.
    pool = [best_D]
    for sp in seeds:
        if _info(sp)[0] > 0:
            pool.append(sp)
    # add some variants of best_D (drop an element, extend range)
    if len(best_D) > 3:
        pool.append(best_D[:-1])
        pool.append(best_D[1:])

    candidates = []

    # Pure products from each pool alphabet
    for D in pool:
        candidates.append(_build_product(D))

    # Mixed products: combine the best alphabet with itself and a couple others
    candidates.append(_build_mixed([best_D, best_D]))
    for D in pool:
        candidates.append(_build_mixed([best_D, D]))

    # The interval alphabet (full box) tends to have ratio 1 but huge size;
    # it never helps the ratio, but include a big fallback.
    candidates.append(_build_product([0, 1, 2, 4, 8, 16]))

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        if max(abs(x) for x in c) > 10 ** 15:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    if best is None:
        best = [0, 1, 2, 4, 8, 16]
    return list(best)
# EVOLVE-BLOCK-END
