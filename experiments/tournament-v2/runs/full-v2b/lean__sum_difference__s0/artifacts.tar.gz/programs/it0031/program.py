# EVOLVE-BLOCK-START
"""Search for A with many differences and few sums; maximize log|A-A|/log|A+A|."""
import math
import random
import time


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 2:
        return 1e9  # degenerate perfect case (won't really happen)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _seed_digit(B, digits, k):
    """A = { sum d_i * B^i : d_i in digits, i in [0,k) } (cartesian)."""
    cur = [0]
    pw = 1
    for _ in range(k):
        cur = [c + d * pw for c in cur for d in digits]
        pw *= B
        if len(cur) > 4000:
            break
    return sorted(set(cur))


def _best_seed():
    """Sweep digit-set parameters to get the best starting set."""
    best = None
    best_s = -1.0
    # digit alphabets of size 2..4, bases 2..6, depth small
    for B in range(2, 7):
        for k in range(2, 9):
            for alph in (
                [0, 1],
                [0, 1, 2],
                [0, 1, 3],
                [0, 1, B],
                [0, 1, 2, B],
                [0, 1, 2, 3],
                [0, 1, 2, B, B + 1],
            ):
                if max(alph) >= B + 1:
                    continue
                A = _seed_digit(B, alph, k)
                if not (2 <= len(A) <= 4000):
                    continue
                s = _score(A)
                if s > best_s:
                    best_s, best = s, A
    return best if best is not None else [0, 1]


def solve():
    deadline = time.time() + 100
    best = _best_seed()
    best_s = _score(best)
    cur = best[:]
    cur_s = best_s

    # larger neighborhood hill-climbing / annealing
    steps = 0
    while time.time() < deadline:
        steps += 1
        cand = cur[:]
        r = random.random()
        if r < 0.45 and cand:
            # shift an element
            i = random.randrange(len(cand))
            scale = max(1, abs(cand[i]) // 3 + 1)
            cand[i] += random.randint(-scale, scale)
        elif r < 0.75:
            # add a new element near an existing gap or random
            if len(cand) < 4000:
                if cand and random.random() < 0.7:
                    base = random.choice(cand)
                    cand.append(base + random.randint(-5, 5))
                else:
                    cand.append(random.randint(-50, 50))
        elif r < 0.9 and len(cand) > 3:
            # remove an element
            del cand[random.randrange(len(cand))]
        else:
            # big jump: re-seed perturbation of a subset
            if len(cand) > 4:
                i = random.randrange(len(cand))
                cand[i] *= random.choice([-1, 2, 3, 4])
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_s or (steps % 50 == 0 and random.random() < 0.05):
            cur, cur_s = cand, s
            if s > best_s:
                best, best_s = cand[:], s
        if steps % 100 == 0 and cur_s < best_s:
            cur, cur_s = best[:], best_s
    return best
# EVOLVE-BLOCK-END
