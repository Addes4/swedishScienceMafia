# EVOLVE-BLOCK-START
"""Construct A as a mixed no-carry product of digit alphabets.

If A = { sum_i d_i B_i : d_i in D_i } with the bases B_i chosen so that no
digit-vector collides (no carries), then differences and sums are exactly the
Minkowski products of the per-position difference/sum sets:

    A - A = D_1 - D_1 x ... x D_k - D_k   (in the B_i mixed radix)
    A + A = D_1 + D_1 x ... x D_k + D_k

hence |A-A| = prod |D_i - D_i| and |A+A| = prod |D_i + D_i|.  For a single
repeated alphabet the objective is just log|D-D|/log|D+D|; mixing alphabets
lets an interval block (large |D-D|) sit beside a high-ratio block.
"""
import math
import random
import time
from itertools import product


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Hill-climb over small integer alphabets D maximizing the ratio."""
    R = 34
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32]]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 13)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        for _ in range(400):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.7 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build_product(blocks, cap=4000):
    """blocks: list of digit alphabets. Build mixed-radix no-carry product."""
    blocks = [sorted(set(b)) for b in blocks if len(set(b)) >= 2]
    if not blocks:
        return [0, 1]
    # trim trailing blocks if product would exceed cap
    while len(blocks) > 1:
        sz = 1
        for b in blocks:
            sz *= len(b)
        if sz <= cap:
            break
        blocks.pop()
    sizes = [len(b) for b in blocks]
    n = 1
    for s in sizes:
        n *= s
    if n > cap:
        # drop blocks from the end until it fits
        while len(blocks) > 1:
            blocks.pop()
            n = 1
            for b in blocks:
                n *= len(b)
            if n <= cap:
                break
    # mixed radix bases: B_i = 2*span_i+1 ensures no carries
    bases = []
    mult = 1
    spans = [max(b) - min(b) for b in blocks]
    for i, b in enumerate(blocks):
        B = 2 * spans[i] + 1
        bases.append(B)
    vals = set()
    for combo in product(*blocks):
        v = 0
        p = 1
        for i, d in enumerate(combo):
            dd = d - min(blocks[i])
            v += dd * p
            p *= bases[i]
        vals.add(v)
    return sorted(vals)


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build_single(D, cap=4000):
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = set()
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.add(v)
    return sorted(vals)


def solve():
    deadline = time.time() + 60
    D, r = _search_alphabet(deadline)

    candidates = []
    candidates.append(_build_single(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5]):
        candidates.append(_build_single(sp))

    # Mixed blocks: a high-ratio alphabet repeated k times plus an interval
    # block (0..m-1) in a separate no-carry base.  The interval block adds a
    # large |D-D| factor at the cost of a modest |D+D| factor.
    best_ratio_alphabet = sorted(set(D))
    if len(best_ratio_alphabet) < 2:
        best_ratio_alphabet = [0, 1, 2, 4, 8, 16]
    sA = len(best_ratio_alphabet)
    for m in range(3, 14):
        interval = list(range(m))
        for kA in range(0, 9):
            blocks = [best_ratio_alphabet] * kA + [interval]
            tot = 1
            ok = True
            for b in blocks:
                tot *= len(b)
            if tot < 2:
                continue
            if tot > 4000:
                # recompute a fitting variant via _build_product (trims)
                pass
            cand = _build_product(blocks)
            if 2 <= len(cand) <= 4000:
                candidates.append(cand)

    # also a variety of alphabets each mixed with interval blocks
    alt_alphabets = [[0, 1, 3], [0, 1, 3, 7], [0, 1, 3, 7, 15],
                     [0, 1, 2, 5], [0, 1, 4], [0, 1, 2, 4, 8, 16]]
    for al in alt_alphabets:
        for m in range(3, 10):
            interval = list(range(m))
            for kA in range(1, 7):
                blocks = [al] * kA + [interval]
                cand = _build_product(blocks)
                if 2 <= len(cand) <= 4000:
                    candidates.append(cand)

    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    seen = set()
    for c in candidates:
        if len(c) < 2 or len(c) > 4000:
            continue
        key = (len(c), c[0], c[-1])
        if key in seen:
            continue
        seen.add(key)
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END

