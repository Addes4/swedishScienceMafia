# EVOLVE-BLOCK-START
"""Build A as a union of translated no-carry products, then score the realization.

The no-carry product over digit alphabet D gives a "box" B = sum D*P^i with
|B-B| = |D-D|^k and |B+B| = |D+D|^k.  If we form A = union_{s in S} (B + s*C)
for a large step C >> span(B), then:

    |A-A| >= |S-S| * (something like |B-B|)   (differences across shifts add up)
    |A+A| <= |S+S| * |B+B|  (in the worst case)  but often much smaller than
                             the cross-products since B+B sits in a short box.

We search for (D, k, S, C) maximizing the REALIZED score log|A-A|/log|A+A|
plus the size bonus.
"""
import math
import random
import time
from itertools import product


def _build(D, k, B):
    """Return the no-carry product set with digits D (length k), base B."""
    vals = set()
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.add(v)
    return sorted(vals)


def _stats(A):
    a = list(A)
    dd = len({x - y for x in a for y in a})
    ss = len({x + y for x in a for y in a})
    return dd, ss


def _score(A):
    if len(A) < 2:
        return 0.0
    dd, ss = _stats(A)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss) + (1 - 1 / len(A)) / 100


def _ratio_stats(dd, ss):
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _alphabet_ratio(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return _ratio_stats(dd, ss), dd, ss


def _search_alphabet(deadline, R=40):
    """Find a small D maximizing per-digit log|D-D|/log|D+D|."""
    best_D = [0, 1, 2, 4, 8, 16]
    r, _, _ = _alphabet_ratio(best_D)
    best_r = r
    seeds = [[0, 1], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
             [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32],
             [0, 1, 3, 4, 9, 11], [0, 1, 2, 3, 5, 8]]
    for sp in seeds:
        r, _, _ = _alphabet_ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(3, 12)
        D = sorted(random.sample(range(0, R + 1), s))
        r, _, _ = _alphabet_ratio(D)
        for _ in range(300):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.75 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.88:
                cand.append(random.randint(0, R))
            elif len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 3:
                continue
            cr, _, _ = _alphabet_ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _candidate_shifts(m, deadline):
    """Generate shift sets S of size m; S should have a large |S-S| and small |S+S|."""
    # Use an arithmetic-progression-like S: |S-S| = 2m-1, |S+S| = 2m-1; ratio ~ 1.
    # Better: use a Sidon-like S so that |S-S| is large; |S+S| ~ m^2/2 though.
    # Empirically the best is small m and few shifts (box dominates).
    options = []
    for s in range(1, min(m, 6) + 1):
        options.append(list(range(s)))
    # random tries
    while time.time() < deadline:
        s = random.randint(1, min(m, 8))
        S = sorted(random.sample(range(0, 200), s))
        options.append(S)
        if len(options) > 3000:
            break
    return options


def _shifts_stats(S):
    dd = len({a - b for a in S for b in S})
    ss = len({a + b for a in S for b in S})
    return dd, ss


def _build_union(D, k, B, S, C):
    """A = union_{s in S} (base + s*C)."""
    base = _build(D, k, B)
    span = max(base) - min(base)
    assert C > span
    A = set()
    for s in S:
        off = s * C
        for v in base:
            A.add(v + off)
    return sorted(A)


def solve():
    deadline = time.time() + 55
    D, r_single = _search_alphabet(deadline, R=40)
    D = sorted(set(D))
    Dn = [d - min(D) for d in D]
    span = max(Dn)
    B = 2 * span + 1

    # Base size: use the largest k such that |D|^k <= some budget; we will also
    # overlay shifts, so total size must stay <= 4000.
    s = len(Dn)
    best = None
    best_sc = -1.0

    # Try a variety of (k, |S|) allocations.
    configs = []
    for k in range(2, 7):
        if s ** k > 4000:
            break
        core = s ** k
        max_shifts = max(1, min(4000 // core, 20))
        for ns in range(1, max_shifts + 1):
            configs.append((k, ns))

    time_left = deadline - time.time()
    for (k, ns) in configs:
        if time.time() > deadline:
            break
        core = s ** k
        if core * ns > 4000:
            continue
        span_b = span * ((B ** k - 1) // (B - 1) if B > 1 else k)
        C = span_b + 1

        # Try a few S options.
        S_opts = [list(range(ns))]
        for _ in range(min(4, max(0, ns))):
            S_opts.append(sorted(random.sample(range(0, 80), ns)))
        # Small search over S to maximize realized score.
        best_S = S_opts[0]
        best_S_sc = -1.0
        A_try = _build_union(Dn, k, B, best_S, C)
        best_S_sc = _score(A_try)
        for S0 in S_opts[1:]:
            A0 = _build_union(Dn, k, B, S0, C)
            sc = _score(A0)
            if sc > best_S_sc:
                best_S_sc = sc
                best_S = S0
        # local search on S (small)
        S = best_S[:]
        cur = best_S_sc
        iters = 0
        while time.time() < deadline and iters < 40:
            iters += 1
            Sc = S[:]
            op = random.random()
            if op < 0.6 and Sc:
                i = random.randrange(len(Sc))
                Sc[i] = random.randint(0, 120)
            elif op < 0.9:
                Sc.append(random.randint(0, 120))
            elif len(Sc) > 1:
                Sc.pop(random.randrange(len(Sc)))
            Sc = sorted(set(Sc))
            if not Sc or len(Sc) * core > 4000:
                continue
            try:
                A0 = _build_union(Dn, k, B, Sc, C)
            except AssertionError:
                continue
            sc = _score(A0)
            if sc >= cur:
                cur, S = sc, Sc
        if cur > best_sc and len(_build_union(Dn, k, B, S, C)) <= 4000:
            best_sc, best = cur, _build_union(Dn, k, B, S, C)

    # Fallback candidates
    fallbacks = []
    try:
        fallbacks.append(_build_union(Dn, max(2, int(math.log(4000, max(2, s)))),
                                       B, [0], span * 2 + 1))
    except Exception:
        pass
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15]):
        try:
            spn = sorted(set(sp))
            spn = [d - min(spn) for d in spn]
            ss = len(spn)
            kk = 1
            while ss ** (kk + 1) <= 4000:
                kk += 1
            fallbacks.append(_build(spn, kk, 2 * max(spn) + 1))
        except Exception:
            pass

    for A in fallbacks:
        if A and len(A) <= 4000:
            sc = _score(A)
            if sc > best_sc:
                best_sc, best = sc, A

    if best is None:
        best = list(range(64))
    return list(best)
# EVOLVE-BLOCK-END
