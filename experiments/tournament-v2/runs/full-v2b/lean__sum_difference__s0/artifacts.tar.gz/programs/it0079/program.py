# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a tuned digit alphabet D.

If A = { sum_i d_i B^i : d_i in D } with B large enough that no two digit-vectors
collide (no carries), then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so the objective log|A-A|/log|A+A| = log|D-D|/log|D+D| is independent of k.
Therefore we only need to find a small integer alphabet D maximizing
log|D-D|/log|D+D|, then replicate it (largest k with |D|^k <= 4000) for the size bonus.
"""
import math
import random
import time
from itertools import product

try:
    import numpy as np
except Exception:
    np = None


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Search small integer alphabets D maximizing log|D-D|/log|D+D|."""
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)

    # structured seeds: powers of 2, powers of 2 minus patterns, Sidon-ish sets
    seeds = []
    for k in range(2, 13):
        seeds.append([2 ** i for i in range(k)])
        seeds.append([2 ** i - 1 for i in range(k)])
        seeds.append([3 ** i for i in range(k)])
        seeds.append(list(range(k)))                       # arithmetic
        seeds.append([i * i for i in range(k)])            # quadratic
        seeds.append([i * i + i for i in range(k)])
    for sp in seeds:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    R = 60
    while time.time() < deadline:
        s = random.randint(3, 14)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        for _ in range(600):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.65 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.8:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _build_fast(D, cap=4000):
    """Numpy-accelerated build."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    arr = np.array(D, dtype=np.int64)
    cur = np.array([0], dtype=np.int64)
    p = 1
    for _ in range(k):
        cur = (cur[:, None] + arr[None, :] * p).ravel()
        p *= B
    return sorted(set(cur.tolist()))


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    if np is not None and n <= 4000:
        arr = np.array(a, dtype=np.int64)
        diffs = np.unique((arr[:, None] - arr[None, :]).ravel())
        sums = np.unique((arr[:, None] + arr[None, :]).ravel())
        if len(diffs) < 2 or len(sums) < 2:
            return 0.0
        return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 60
    D, r = _search_alphabet(deadline)

    candidates = []
    candidates.append(_build_fast(D) if np is not None else _build(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8, 16, 32],
               [0, 1, 2, 4, 8], [0, 1, 3, 7, 15], [0, 1, 2, 4], [0, 1, 2, 3, 4, 5]):
        candidates.append(_build_fast(sp) if np is not None else _build(sp))

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
