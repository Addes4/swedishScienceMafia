# EVOLVE-BLOCK-START
"""Geometric progression construction: A = {b^i}. Sums b^i+b^j collide strongly,
differences b^i-b^j stay mostly distinct, maximizing log|A-A|/log|A+A|."""
import math


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    """Find A = {b^i : 0<=i<n} maximizing the ratio."""
    best = None
    best_score = -1.0
    # Try a range of bases and lengths (keep values within 1e15).
    for b in range(2, 40):
        # max n so that b^(n-1) <= 1e15
        n = 1
        v = 1
        while v * b <= 10**15:
            v *= b
            n += 1
        # try all lengths from ~4 up to n, and nearby
        lo = max(3, n - 5)
        for m in range(lo, n + 1):
            a = [b**i for i in range(m)]
            if a[-1] > 10**15:
                continue
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a
    if best is None:
        best = [1, 2, 4, 8, 16]
    return sorted(best)
# EVOLVE-BLOCK-END
