# EVOLVE-BLOCK-START
"""Search for a set A with large |A-A| and small |A+A| via exact-score simulated annealing."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _stats(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums), n


def solve():
    random.seed(12345)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    def full_score(a):
        return _score(a)

    # Candidate seeds: random widely-spaced powers of a large base plus small jitter.
    def make_seed():
        B = random.choice([2, 3, 4, 5, 6, 8, 10, 100, 1000])
        n = random.randint(6, 30)
        exps = sorted(random.sample(range(0, 2 * n + 10), n))
        A = []
        for e in exps:
            base_val = B ** e
            if base_val > 10 ** 14:
                break
            A.append(base_val + random.randint(-2, 2))
        return A

    # Explore seeds quickly to find good starting points.
    seeds = []
    for _ in range(400):
        s = make_seed()
        if 2 <= len(s) <= 4000:
            seeds.append((full_score(s), s))
        if time.time() > deadline - 100:
            break
    seeds.sort(reverse=True)
    if seeds and seeds[0][0] > best_score:
        best_score = seeds[0][0]
        best = seeds[0][1][:]

    # Simulated annealing with exact scoring on several restarts.
    restarts = 0
    while time.time() < deadline:
        restarts += 1
        # Start from best found or a fresh seed
        if random.random() < 0.7 and best:
            cur = best[:]
        elif seeds:
            cur = random.choice(seeds[:max(1, len(seeds) // 4)])[1][:]
        else:
            cur = make_seed()
        cur_score = full_score(cur)
        T = 0.05
        steps = 0
        while time.time() < deadline and steps < 20000:
            steps += 1
            cand = cur[:]
            op = random.random()
            if op < 0.45 and cand:
                # perturb an element by a power-of-base jump or small delta
                i = random.randrange(len(cand))
                if random.random() < 0.5:
                    e = random.randint(0, 60)
                    mag = random.choice([2, 3, 4, 5, 8, 10, 100]) ** e
                    if mag > 10 ** 15:
                        mag = random.randint(-1000, 1000)
                    cand[i] += random.choice([-1, 1]) * mag
                else:
                    cand[i] += random.randint(-5, 5)
            elif op < 0.75:
                # add a new element widely spaced
                e = random.randint(0, 50)
                mag = random.choice([2, 3, 5, 10]) ** e
                if mag > 10 ** 15:
                    mag = random.randint(1, 10 ** 6)
                cand.append(mag + random.randint(-2, 2))
            elif op < 0.9 and len(cand) > 4:
                # remove
                cand.pop(random.randrange(len(cand)))
            else:
                # shift whole set
                d = random.randint(-3, 3)
                cand = [x + d for x in cand]
            # bounds
            cand = [x for x in cand if abs(x) <= 10 ** 15]
            cand = list(set(cand))
            if len(cand) < 2 or len(cand) > 4000:
                continue
            cs = full_score(cand)
            if cs >= cur_score or random.random() < math.exp((cs - cur_score) / max(T, 1e-6)):
                cur = cand
                cur_score = cs
                if cs > best_score:
                    best_score = cs
                    best = cand[:]
            T *= 0.9995
            if T < 1e-4:
                T = 0.05
        if time.time() > deadline - 5:
            break

    return sorted(set(best))
# EVOLVE-BLOCK-END
