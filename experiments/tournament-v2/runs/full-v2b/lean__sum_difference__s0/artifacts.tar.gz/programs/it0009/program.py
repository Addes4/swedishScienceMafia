# EVOLVE-BLOCK-START
"""Search for A maximizing log|A-A|/log|A+A| using annealing over small integer sets."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    if ls < 2:
        return 0.0, ld, ls
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100, ld, ls


def _seed_geo(base, n, start=1):
    a = []
    v = start
    for _ in range(n):
        a.append(v)
        v *= base
        if v > 10**14:
            break
    return a


def solve():
    deadline = time.time() + 100
    best = [7, 15, 18, 22, -3, -2]
    best_score, _, _ = _score(best)

    seeds = []
    for base in (2, 3):
        for n in range(5, 26):
            seeds.append(_seed_geo(base, n))
    for base in (2, 3):
        g = _seed_geo(base, 15)
        seeds.append(g + [g[-1] * base + 1, g[-1] * base - 3, -g[1]])
    # small random seeds
    for _ in range(30):
        n = random.randint(5, 20)
        seeds.append([random.randint(-50, 50) for _ in range(n)])

    for seed in seeds:
        if time.time() > deadline:
            break
        cur = list(set(seed))
        cur_score, _, _ = _score(cur)
        T = 0.02
        iters = 3000
        for it in range(iters):
            if time.time() > deadline:
                break
            if it % 300 == 299:
                T *= 0.7
            cand = cur[:]
            r = random.random()
            if r < 0.6 and cand:
                i = random.randrange(len(cand))
                step = random.choice([1, 2, 3])
                cand[i] += random.randint(-step, step)
            elif r < 0.85:
                if len(cand) < 40:
                    base_elem = random.choice(cand) if cand else 1
                    cand.append(base_elem + random.randint(-5, 5))
            else:
                if len(cand) > 4:
                    i = random.randrange(len(cand))
                    cand.pop(i)
            cand = list(set(cand))
            if len(cand) < 4:
                continue
            s, _, _ = _score(cand)
            if s >= cur_score or random.random() < math.exp((s - cur_score) / max(T, 1e-6)):
                cur = cand
                cur_score = s
                if s > best_score:
                    best = cand[:]
                    best_score = s
    return sorted(set(best))
# EVOLVE-BLOCK-END
