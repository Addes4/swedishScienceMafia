# EVOLVE-BLOCK-START
"""Multi-scale digit construction with exact-score selection.

Idea: build A as sums of digits times powers of an increasing base, where the
digit alphabet sizes increase with position (the highest place uses the largest
alphabet).  Such sets are "sum-poor": the number of distinct sums is roughly
the product of (2*|D_i|-1), while the number of distinct differences gains an
extra factor because the extreme places dominate.  We evaluate exact scores and
keep the best; ties broken in favour of larger |A|.
"""
import math
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(base, sizes):
    """A = { sum d_i * base^i : 0 <= d_i < sizes[i] }."""
    A = [0]
    p = 1
    for s in sizes:
        if s <= 0:
            p *= base
            continue
        newA = []
        for x in A:
            for d in range(s):
                newA.append(x + d * p)
        A = newA
        p *= base
    return A


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # candidate parameter families
    candidates = []

    # Family 1: increasing alphabets in a large-ish base.
    for base in (3, 5, 7, 11, 13, 17, 23, 31, 41, 53):
        for maxsize in (3, 4, 5, 6):
            for k in range(2, 12):
                # alphabet sizes increasing from 2 up to maxsize
                sizes = []
                for i in range(k):
                    si = 2 + int(round((maxsize - 2) * i / max(1, k - 1)))
                    sizes.append(max(2, min(maxsize, si)))
                # cap total size
                total = 1
                for s in sizes:
                    total *= s
                if total > 3500:
                    continue
                candidates.append((base, tuple(sizes)))

    # Family 2: mostly binary with one wide top and one wide bottom place.
    for base in (5, 7, 11, 13, 17, 23, 31, 41, 53, 71, 101):
        for top in (3, 4, 5, 6, 8):
            for bot in (2, 3):
                for k in range(3, 14):
                    sizes = [bot] + [2] * (k - 2) + [top]
                    total = 1
                    for s in sizes:
                        total *= s
                    if total > 3500:
                        continue
                    candidates.append((base, tuple(sizes)))

    # Family 3: strictly increasing 2,3,4,5,... in moderate base.
    for base in (4, 6, 8, 10, 12, 16, 20, 24):
        for start in (2, 3):
            sizes = []
            s = start
            total = 1
            while total * s <= 3500 and len(sizes) < 20:
                sizes.append(s)
                total *= s
                s += 1
            if len(sizes) >= 2:
                candidates.append((base, tuple(sizes)))

    # Family 4: decreasing alphabets (wide at the bottom).
    for base in (3, 5, 7, 11, 13, 17, 23):
        for maxsize in (4, 5, 6, 8):
            for k in range(3, 14):
                sizes = []
                for i in range(k):
                    si = maxsize - int(round((maxsize - 2) * i / max(1, k - 1)))
                    sizes.append(max(2, min(maxsize, si)))
                total = 1
                for s in sizes:
                    total *= s
                if total > 3500:
                    continue
                candidates.append((base, tuple(sizes)))

    # de-duplicate
    seen = set()
    uniq = []
    for base, sizes in candidates:
        key = (base, sizes)
        if key not in seen:
            seen.add(key)
            uniq.append(key)

    time_limit = time.time() + 100
    for base, sizes in uniq:
        if time.time() > time_limit:
            break
        A = _build(base, sizes)
        if len(A) > 4000 or max(abs(x) for x in A) > 10**15:
            continue
        if len(A) < 2:
            continue
        s = _score(A)
        if s > best_score:
            best_score, best = s, A

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    # Light local refinement: perturb single elements to try to shrink A+A
    # without shrinking A-A too much.
    cur = best[:]
    cur_score = best_score
    deadline = time.time() + 118
    import random
    rng = random.Random(12345)
    while time.time() < deadline:
        cand = cur[:]
        i = rng.randrange(len(cand))
        step = rng.choice([-2, -1, 1, 2])
        cand[i] += step
        if len(set(cand)) < len(cand):
            continue
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s

    best = sorted(set(best))
    return best
# EVOLVE-BLOCK-END
