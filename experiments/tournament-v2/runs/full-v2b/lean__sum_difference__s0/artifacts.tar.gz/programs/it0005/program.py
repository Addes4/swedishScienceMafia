# EVOLVE-BLOCK-START
"""Construction: geometric progression with clustered gaps plus local refinement to
maximize log|A-A|/log|A+A|."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _stats(a):
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


def _score_from(dl, sl, n):
    if n < 2 or sl < 2:
        return 0.0
    return math.log(dl) / math.log(sl) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Try several bases for a near-geometric construction.  For a pure
    # geometric progression a_i = r^i, |A+A| ~ 2n and |A-A| ~ n^2, giving a
    # great ratio.  Small integer r close to 2 or 3 keeps the values bounded
    # while still producing many distinct differences.
    for r in (2, 3, 4, 5, 2, 3):
        n = 60
        while n >= 10:
            A = [0]
            v = 1
            for _ in range(n - 1):
                v *= r
                A.append(v)
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A[:]
            n -= 1

    # Local search: perturb elements, grow/shrink set.
    if best is None:
        best = [0, 1, 3, 7, 15]
    best = list(set(best))
    cur = best[:]
    cur_score = _score(cur)
    step = 1
    stall = 0
    while time.time() < deadline:
        cand = cur[:]
        move = random.random()
        if move < 0.6:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * step
        elif move < 0.8:
            cand.append(random.randint(0, 10) * step + (1 if cand else 1))
        elif len(cand) > 5:
            del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score or (s == cur_score and random.random() < 0.3):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
                stall = 0
        else:
            stall += 1
        if stall > 200:
            step = max(1, step // 2) if step > 1 else 1
            cur = best[:]
            cur_score = best_score
            stall = 0
            step = 1
    return sorted(set(best))
# EVOLVE-BLOCK-END
