# EVOLVE-BLOCK-START
"""Fast construction: cross of a geometric progression with a tiny sum-poor seed,
then a short exact local polish. Targets large A-A and small A+A directly."""
import math
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build(base, k, S):
    # A = { (i*len(S)+j) ... } no; use A = {i*base + s} for i in range(k), s in S
    return [i * base + s for i in range(k) for s in S]


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # A few seeds for S: small sets that are sum-poor but difference-rich.
    seeds = [
        [0, 1, 3],
        [0, 1, 3, 7],
        [0, 1, 4, 6],
        [0, 1, 3, 9],
        [0, 2, 5],
        [0, 1, 5, 11],
    ]

    deadline = time.time() + 40
    # Explore (base, k, S) grid cheaply using exact counts only on small candidates.
    for S in seeds:
        m = len(S)
        if m < 2:
            continue
        # smart base so that blocks don't overlap for sums: choose base large.
        for k in range(2, 9):
            if len(S) * k > 200:
                continue
            for base in (m + 2, m + 3, 2 * m + 1, 3 * m + 1, m * m + 1):
                if time.time() > deadline:
                    break
                cand = _build(base, k, S)
                s = _score(cand)
                if s > best_score:
                    best, best_score = cand[:], s
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # Short exact local polish (shift one element, accept improvements).
    cur = best[:]
    end = time.time() + 60
    step = 1
    while time.time() < end:
        improved = False
        for i in range(len(cur)):
            for d in (step, -step):
                cand = cur[:]
                cand[i] += d
                if len(set(cand)) != len(cand):
                    continue
                s = _score(cand)
                if s > best_score:
                    cur = cand
                    best, best_score = cand[:], s
                    improved = True
        if not improved:
            step += 1
            if step > 5:
                break
    return sorted(set(best))
# EVOLVE-BLOCK-END
