# EVOLVE-BLOCK-START
"""Two-block construction: A = (interval block) + (carry-free digit product).

We combine a consecutive "interval" block (which contributes many distinct
differences but relatively few distinct sums) with a no-carry digit-product
block built from a tuned alphabet D.  The blocks live in disjoint, widely
separated bases so the global difference/sum sets factor as Minkowski sums of
the block difference/sum sets, giving a richer |A-A|/|A+A| gap than a single
product.  We evaluate realized scores with a fast numpy unique-counter and
pick the best candidate that fits within the size cap and time budget.
"""
import math
import random
import time
from itertools import product

import numpy as np


def _count_pairs(vals, mode):
    """Fast vectorized count of distinct differences/sums of 1-D int array."""
    a = np.asarray(vals, dtype=np.int64)
    if mode == 'd':
        x = (a[:, None] - a[None, :]).ravel()
    else:
        x = (a[:, None] + a[None, :]).ravel()
    return int(np.unique(x).size)


def _score_np(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0.0
    dd = _count_pairs(a, 'd')
    ss = _count_pairs(a, 's')
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss) + (1 - 1.0 / n) / 100


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Hill-climb over small integer alphabets D, maximizing log|D-D|/log|D+D|."""
    R = 40
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32]]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 12)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        for _ in range(300):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.7 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D


def _product_block(D, k):
    """No-carry product set of alphabet D across k digit positions."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    if len(D) < 2:
        return [0, 1]
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _build(D, cap=4000):
    D = sorted(set(D))
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    return _product_block(D, k)


def _combine_interval(D, cap=4000):
    """Split size between an interval block and a digit-product block.

    Interval block {0..m-1} occupies the low range; the product block is
    shifted above it.  Differences then include the interval's wide
    consecutive range plus the product structure, while sums stay additive.
    """
    D = sorted(set(D))
    s = len(D)
    if s < 2:
        return [0, 1]
    best = None
    best_s = -1.0
    # try several interval lengths m and product sizes k
    for m in (1, 2, 3, 4, 6, 8, 12, 16, 24, 32):
        prod = _product_block(D, 1)
        k = 1
        while s ** (k + 1) * max(m, 1) <= cap:
            k += 1
        pb = _product_block(D, k)
        if m * len(pb) > cap:
            continue
        # place interval as low digits, product shifted beyond interval span
        low = list(range(m))
        span_low = m - 1
        B = max(2 * (max(D) - min(D)) + 1, 2 * span_low + 2)
        shifted = [B + v * B for v in pb]
        A = sorted(set(low + shifted))
        if len(A) > cap:
            A = A[:cap]
        sc = _score_np(A)
        if sc > best_s:
            best_s, best = sc, A
    return best if best is not None else _build(D, cap), best_s


def solve():
    deadline = time.time() + 50
    D = _search_alphabet(deadline)

    candidates = []
    candidates.append((_build(D), None))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5]):
        candidates.append((_build(sp), None))
    candidates.append(([7, 15, 18, 22, -3, -2], None))

    best = None
    best_s = -1.0
    for c, _ in candidates:
        if len(c) < 2:
            continue
        sc = _score_np(c)
        if sc > best_s:
            best_s, best = sc, c

    # Try the combined interval+product construction.
    for Dc in (D, [0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4]):
        if time.time() > deadline + 30:
            break
        A, sc = _combine_interval(Dc)
        if sc > best_s:
            best_s, best = sc, A

    return list(best)
# EVOLVE-BLOCK-END

