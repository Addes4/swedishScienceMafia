# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a tuned digit alphabet D.

If A = { sum_i d_i B^i : d_i in D } with B large enough that no two digit-vectors
collide (no carries), then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so the objective log|A-A|/log|A+A| = log|D-D|/log|D+D| is independent of k.
We search hard for a small integer alphabet D maximizing log|D-D|/log|D+D|,
then replicate it (largest k with |D|^k <= 4000) for the size bonus.
"""
import math
import random
import time
from itertools import product

import numpy as np


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Hill-climb / SA over small integer alphabets D, maximizing log|D-D|/log|D+D|."""
    R = 60
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [
        [0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
        [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32],
        [0, 1, 2, 4, 8, 16, 24, 32], [0, 1, 3, 4, 9, 10, 12],
        [0, 1, 2, 3, 5, 8, 13], [0, 1, 4, 10, 18],
        [0, 1, 2, 4, 7, 12, 20],
    ]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, list(set(sp))

    # Simulated annealing over alphabets
    while time.time() < deadline:
        s = random.randint(2, 14)
        D = sorted(set(random.sample(range(0, R + 1), s)))
        if len(D) < 2:
            continue
        r = _ratio(D)
        T0 = 0.02
        for step in range(2000):
            if time.time() >= deadline:
                break
            T = T0 * (1 - step / 2000.0) + 1e-4
            cand = D[:]
            op = random.random()
            if op < 0.75 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.90:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r or random.random() < math.exp((cr - r) / max(T, 1e-9)):
                D, r = cand, cr
                if r > best_r:
                    best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    """Build the product set (subset sums) from alphabet D, largest size <= cap."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]          # normalize to start at 0
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1                     # no carries between digit positions
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _score(a):
    a = np.array(sorted(set(a)), dtype=object)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    ld = len(diffs)
    ls = len(sums)
    if ld < 2 or ls < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def solve():
    # Leave a safety margin for the (fast) final scoring.
    deadline = time.time() + 90
    D, r = _search_alphabet(deadline)

    candidates = []
    candidates.append(_build(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5], [0, 1, 2, 4, 8, 16, 32],
               [0, 1, 2, 4, 7, 12, 20]):
        candidates.append(_build(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
