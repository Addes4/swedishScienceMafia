# EVOLVE-BLOCK-START
"""Constructive sets: maximize log|A-A| / log|A+A| via a mix of a Sidon-like
scaled block (giving many differences) and a dense low block (giving few sums)."""
import math
import time


def _ratio(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(B, k, extra):
    """A = scaled dense block + small nice block.

    Take base B.  Dense block: D = {0..B-1} scaled by big factor S -> many sums? we instead
    want few sums.  Use digit set: digits from {0,1} over k positions scaled by S gives
    Sidon-like diffs, and sums stay structured.
    Then add a small block {1..extra} at the bottom to create extra differences with few sums.
    """
    A = []
    # Sidon-like scaled part: sums of {0,1} digits
    for mask in range(1 << k):
        v = 0
        for i in range(k):
            if mask >> i & 1:
                v += B ** i
        A.append(v * S_scale(B, k))
    # dense low part
    for j in range(1, extra + 1):
        A.append(j)
    return A


def S_scale(B, k):
    return (B ** k) * (B ** k) + 1


def solve():
    best = [0, 1, 2, 4]
    best_score = -1.0
    deadline = time.time() + 100.0
    # sweep configurations; each evaluated exactly
    cands = []

    # Family 1: geometric-ish Sidon block scaled, plus dense prefix
    for k in range(3, 9):
        for B in (2, 3, 4):
            scale = 1
            for _ in range(k):
                scale *= B
            scale = scale * scale + 1
            sid = []
            for mask in range(1 << k):
                v = 0
                for i in range(k):
                    if mask >> i & 1:
                        v += B ** i
                sid.append(v * scale)
            for extra in (2, 3, 5, 8):
                cand = sid + list(range(1, extra + 1))
                cands.append(cand)

    # Family 2: mixed base digits {0,1} over nonuniform bases for tighter sums
    for bases in ([2, 4], [3, 6], [2, 3, 5], [2, 5, 9], [4, 9]):
        vals = [0]
        cur_bases = bases
        level = [0]
        for b in cur_bases:
            nxt = []
            m = max(level) + 1
            for v in level:
                for d in (0, 1):
                    nxt.append(v + d * (m and 0))
            level = nxt
        # build via incremental bases
        levels = [0]
        mult = 1
        for b in bases:
            newlev = []
            for v in levels:
                newlev.append(v)
                newlev.append(v + mult)
            levels = newlev
            mult *= b
        bigM = mult * mult + 1
        sid = [v * bigM for v in levels]
        for extra in (2, 3, 5):
            cands.append(sid + list(range(1, extra + 1)))

    # Family 3: pure dense interval scaled by huge factor vs small
    for big in (50, 100, 200, 500, 1000):
        for m in (4, 5, 6, 8):
            cand = [i * big for i in range(m)] + list(range(1, 3))
            cands.append(cand)

    for cand in cands:
        if time.time() > deadline:
            break
        s = _ratio(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

    # local polish: try small perturbations to improve
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        improved = False
        for i in range(len(cur)):
            for delta in (1, -1, 2, -2, 3, -3):
                trial = cur[:]
                trial[i] += delta
                if len(set(trial)) < len(trial):
                    continue
                s = _ratio(trial)
                if s > cur_score:
                    cur, cur_score = trial, s
                    improved = True
                    break
            if improved:
                break
        if not improved:
            break

    if cur_score > best_score:
        best = cur[:]
        best_score = cur_score

    return sorted(set(best))
# EVOLVE-BLOCK-END

