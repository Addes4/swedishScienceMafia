# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a tuned digit alphabet D.

If A = { sum_i d_i B^i : d_i in D } with B large enough that no two digit-vectors
collide (no carries), then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so the objective log|A-A|/log|A+A| = log|D-D|/log|D+D| is independent of k
(minor finite-size deviations aside).  We therefore search small integer
alphabets D maximizing the realized score of the full constructed set, and then
replicate D for the size bonus.
"""
import math
import random
import time
from itertools import product

import numpy as np


def _ratio_fast(D):
    """Return (log|D-D|/log|D+D|) using numpy on a small alphabet D."""
    D = np.array(sorted(set(D)), dtype=np.int64)
    n = D.size
    if n < 2:
        return 0.0
    dd = np.unique(D[:, None] - D[None, :]).size
    ss = np.unique(D[:, None] + D[None, :]).size
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _realized_score(D, cap=4000):
    """Build the product set from D (largest size <= cap) and score it."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return -1.0, None
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    a = np.array(sorted(set(vals)), dtype=np.int64)
    if a.size < 2:
        return -1.0, None
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    if diffs < 2 or sums < 2:
        return -1.0, None
    sc = math.log(diffs) / math.log(sums) + (1 - 1 / a.size) / 100
    return sc, list(map(int, a))


def _search_alphabet(deadline):
    """Hill-climb over small integer alphabets, maximizing the realized score."""
    R = 40
    best_D = [0, 1, 2, 4, 8, 16]
    _, best_a = _realized_score(best_D)
    best_sc = -1.0
    if best_a is not None:
        best_sc = _realized_score(best_D)[0]

    seed_pool = [[0, 1, 2, 4, 8, 16], [0, 1, 3, 7, 15], [0, 1, 2, 4, 8],
                 [0, 1, 2, 4], [0, 1, 2, 3, 5, 9, 15]]
    for sp in seed_pool:
        sc, _ = _realized_score(sp)
        if sc > best_sc:
            best_sc, best_D = sc, sp[:]

    while time.time() < deadline:
        s = random.randint(3, 12)
        D = sorted(random.sample(range(0, R + 1), s))
        sc, _ = _realized_score(D)
        for _ in range(120):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.7:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 3:
                continue
            cr, _ = _realized_score(cand)
            if cr >= sc:
                D, sc = cand, cr
        if sc > best_sc:
            best_sc, best_D = sc, D[:]
    return best_D, best_sc


def solve():
    deadline = time.time() + 100
    D, r = _search_alphabet(deadline)

    candidates = []
    _, a = _realized_score(D)
    if a is not None:
        candidates.append(a)
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 5, 9, 15]):
        _, a = _realized_score(sp)
        if a is not None:
            candidates.append(a)
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        a = np.array(sorted(set(c)), dtype=np.int64)
        if a.size < 2:
            continue
        diffs = np.unique(a[:, None] - a[None, :]).size
        sums = np.unique(a[:, None] + a[None, :]).size
        if diffs < 2 or sums < 2:
            continue
        sc = math.log(diffs) / math.log(sums) + (1 - 1 / a.size) / 100
        if sc > best_s:
            best_s, best = sc, list(map(int, a))

    return best
# EVOLVE-BLOCK-END
