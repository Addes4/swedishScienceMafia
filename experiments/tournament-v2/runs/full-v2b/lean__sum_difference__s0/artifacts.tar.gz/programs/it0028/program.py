# EVOLVE-BLOCK-START
"""Digit-seeded simulated annealing maximizing log|A-A|/log|A+A|."""
import math
import random
import time


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    ls = len(sums)
    if ls < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(ls) + (1 - 1 / n) / 100


def _seed():
    # Mojon-style: mixed radix digits. We want many differences, few sums.
    # Build A = { sum d_i * base_i : d_i in digit-alphabet_i }.
    # Use several candidate seeds and keep the best-scoring one.
    best = None
    best_s = -1
    for _ in range(30):
        k = random.randint(4, 7)
        bases = []
        b = 1
        alph = []
        for i in range(k):
            m = random.choice([2, 2, 3, 3, 4, 5, 6, 7])
            alph.append(m)
            bases.append(b)
            b *= m
        A = [0]
        for i in range(k):
            newA = []
            for x in A:
                for d in range(alph[i]):
                    newA.append(x + d * bases[i])
            A = newA
        if len(A) > 4000:
            continue
        s = _score(A)
        if s > best_s:
            best_s = s
            best = A[:]
    return best


def solve():
    seed = _seed()
    cur = seed[:]
    best = seed[:]
    best_score = _score(best)
    deadline = time.time() + 110
    T = 0.05
    step = 0
    maxv = 10 ** 15
    while time.time() < deadline:
        step += 1
        cand = cur[:]
        r = random.random()
        if r < 0.55:
            # shift a random element by a small multiple of a base power
            i = random.randrange(len(cand))
            pw = random.choice([1, 2, 4, 8, 16, 32, 64, 128])
            delta = random.randint(-1, 1) * pw
            cand[i] += delta
            if abs(cand[i]) > maxv:
                continue
        elif r < 0.85:
            # add a new small element
            if len(cand) < 4000:
                base = random.choice(cand)
                cand.append(base + random.randint(1, 256))
                if abs(cand[-1]) > maxv:
                    continue
        else:
            # remove an element
            if len(cand) > 8:
                cand.pop(random.randrange(len(cand)))
        # uniqueness check
        if len(set(cand)) < len(cand):
            continue
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand[:]
        elif random.random() < math.exp((s - best_score) / max(T, 1e-6)):
            cur = cand[:]
        if step % 2000 == 0:
            T *= 0.97
    return sorted(set(best))
# EVOLVE-BLOCK-END

