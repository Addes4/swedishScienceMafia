# EVOLVE-BLOCK-START
"""Greedy construction maximizing log|A-A| / log|A+A|."""
import math
import time


def _sizes(a):
    a = list(a)
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _sc(d, s, n):
    if s < 2 or d < 2 or n < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _eval(a):
    a = list(a)
    n = len(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return _sc(len(diffs), len(sums), n)


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # Candidate bases and seeds
    seeds = []
    # base-B digit construction with digits {0,1}: gives small sum sets
    for B in (2, 3, 4, 5, 6, 7, 8, 10, 16, 32):
        for k in range(3, 14):
            s = [B ** i for i in range(k)]
            seeds.append(s)
    # geometric plus small spread
    for B in (3, 4, 5):
        for k in range(3, 10):
            s = [B ** i for i in range(k)]
            s += [B ** k - 1, B ** k - 2]
            seeds.append(s)
    # initial diversity seed
    seeds.append([7, 15, 18, 22, -3, -2])

    for seed in seeds:
        if time.time() > deadline:
            break
        a = list(dict.fromkeys(seed))
        cur, cs = _sizes(a)
        cs_score = _sc(cur, cs, len(a))
        improved = True
        # local hill-climbing: try to add the best candidate element
        while improved and time.time() < deadline:
            improved = False
            # candidate additions
            maxv = max(abs(x) for x in a) * 2 + 5
            base = max(abs(x) for x in a)
            cands = set()
            for x in a:
                for y in a:
                    cands.add(x + y)
                    cands.add(x - y)
            cands = [c for c in cands if c not in a and abs(c) <= 10 ** 15]
            # limit candidate pool for speed
            if len(cands) > 2000:
                step = len(cands) // 2000 + 1
                cands = cands[::step]
            best_add = None
            best_gain = 0.0
            for c in cands:
                a2 = a + [c]
                d, s = _sizes(a2)
                sc = _sc(d, s, len(a2))
                if sc > cs_score:
                    if sc - cs_score > best_gain:
                        best_gain = sc - cs_score
                        best_add = c
            if best_add is not None:
                a.append(best_add)
                d, s = _sizes(a)
                cs_score = _sc(d, s, len(a))
                improved = True
                if cs_score > best_score:
                    best_score = cs_score
                    best = a[:]
            # also try removals/shifts to escape
        if cs_score > best_score:
            best_score = cs_score
            best = a[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return sorted(set(best))
# EVOLVE-BLOCK-END
