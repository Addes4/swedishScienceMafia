# EVOLVE-BLOCK-START
"""Construct A to maximize log|A-A|/log|A+A|.

Key idea: |A-A| is maximized when A is "difference-rich", but |A+A| grows fast with
additive structure. A classic near-optimal trade-off: take A to be a set whose sumset
is as small as possible relative to its difference set. 

We use the well-known "product over a prime-like base" trick but choose the digit
alphabet D at each level to directly maximize the realized ratio, and we try several
structured families (Sidon sets, product sets, mixed) then pick the best by measuring
the true objective on the actual built set.
"""
import math
import random
import time
from itertools import product


def _dd(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _dd(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _build(D, cap=4000):
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _search_alphabet(deadline):
    R = 40
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seeds = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
             [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32], [0, 1, 2, 3, 5, 8, 13],
             [0, 1, 4, 6, 13, 21], [0, 1, 2, 4, 8, 16, 32, 64]]
    for sp in seeds:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 14)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        for _ in range(500):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.7 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _greedy_sidon(n, deadline):
    """Greedy Sidon set (Mian-Chowla style) of size ~n, gives small |A+A|."""
    A = [0]
    sums = {0}
    for _ in range(n - 1):
        if time.time() > deadline:
            break
        c = A[-1] + 1
        while True:
            new = [c + a for a in A]
            ns = set(new) | {2 * c}
            if len(ns) == len(set(new)) + (0 if 2 * c in new else 1) and ns.isdisjoint(sums):
                A.append(c)
                sums |= ns
                break
            c += 1
    return A


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 55
    D, r = _search_alphabet(deadline)

    candidates = []
    candidates.append(_build(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 5, 8, 13], [0, 1, 4, 6, 13, 21]):
        candidates.append(_build(sp))

    # Sidon set family (small |A+A|, decent |A-A|)
    for n in (40, 60, 80, 100, 150, 200):
        try:
            candidates.append(_greedy_sidon(n, time.time() + 2))
        except Exception:
            pass

    # side candidate fallback
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2 or len(c) > 4000:
            continue
        if max(abs(x) for x in c) > 10**15:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
