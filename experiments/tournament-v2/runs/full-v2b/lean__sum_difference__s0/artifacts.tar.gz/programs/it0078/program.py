# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a tuned digit alphabet D.

If A = { sum_i d_i B^i : d_i in D } with B large enough that no two digit-vectors
collide (no carries), then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so the objective log|A-A|/log|A+A| = log|D-D|/log|D+D| is independent of k.
The size bonus, however, rewards the *realized* product set, so we jointly
choose the alphabet D and the number of digit positions k to maximize the
actual scored value on the constructed set.

We use a numpy-vectorized search over alphabets (including larger, Sidon-like
digit sets where |D-D| is nearly maximal while |D+D| stays small).
"""
import math
import random
import time

import numpy as np


def _stats_np(D):
    a = np.asarray(sorted(set(D)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0, 0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    return d, s


def _ratio_np(D):
    d, s = _stats_np(D)
    if d < 2 or s < 2:
        return 0.0
    return math.log(d) / math.log(s)


def _score_set(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    if a.size < 2:
        return 0.0
    d = np.unique(a[:, None] - a[None, :]).size
    s = np.unique(a[:, None] + a[None, :]).size
    if d < 2 or s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / a.size) / 100.0


def _build(D, k):
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2 or k < 1:
        return [0, 1]
    span = max(D) - min(D)
    B = 2 * span + 1
    # build via iterative cartesian product with numpy for speed
    vals = np.zeros(1, dtype=np.int64)
    for _ in range(k):
        vals = (vals[:, None] + np.asarray(D, dtype=np.int64)[None, :] ).reshape(-1)
        # multiply existing values by B at next step, so do it differently:
        break
    # correct carry-free build
    vals = np.zeros(1, dtype=np.int64)
    p = 1
    for _ in range(k):
        step = np.asarray(D, dtype=np.int64) * p
        vals = (vals[:, None] + step[None, :]).reshape(-1)
        p *= B
    return np.unique(vals)


def _best_coeffs_for(D, deadline, cap=4000):
    """Choose k giving best realized score for this alphabet D."""
    D = sorted(set(D))
    s = len(D)
    if s < 2:
        return None
    maxk = 1
    while s ** (maxk + 1) <= cap:
        maxk += 1
    best = None
    best_sc = -1.0
    for k in range(maxk, 0, -1):
        if s ** k > cap:
            continue
        A = _build(D, k)
        if A.size > cap:
            continue
        sc = _score_set(A)
        if sc > best_sc:
            best_sc, best = sc, (D[:], k)
        # prefer larger k if scores close (size bonus), but score already captures it
        if time.time() > deadline:
            break
    return best, best_sc


def _search(deadline, cap=4000):
    R = 60
    best = None
    best_sc = -1.0

    seed_pool = [
        [0, 1, 2, 4, 8, 16],
        [0, 1, 2, 4, 8, 16, 32],
        [0, 1, 2, 4, 8],
        [0, 1, 3, 7, 15],
        [0, 1, 2, 4, 8, 16, 32, 64],
        [0, 1, 2, 3, 5, 8, 13, 21, 34],
        [0, 1, 4, 9, 16, 25, 36],
    ]

    def consider(D):
        nonlocal best, best_sc
        D = sorted(set(int(x) for x in D))
        if len(D) < 2:
            return
        res = _best_coeffs_for(D, deadline, cap)
        if res is None:
            return
        (Dbest, k), sc = res
        if sc > best_sc:
            best_sc, best = sc, (Dbest, k)

    for sp in seed_pool:
        consider(sp)

    while time.time() < deadline:
        s = random.randint(4, 16)
        D = sorted(random.sample(range(0, R + 1), s))
        sc0 = _ratio_np(D)
        for _ in range(120):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.75 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.88:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio_np(cand)
            if cr >= sc0:
                D, sc0 = cand, cr
        consider(D)

    return best, best_sc


def solve():
    deadline = time.time() + 90
    best, best_sc = _search(deadline, cap=4000)
    if best is None:
        # fallback
        D = [0, 1, 2, 4, 8, 16]
        k = 4
        A = _build(D, k)
        return [int(x) for x in A]
    D, k = best
    A = _build(D, k)
    return [int(x) for x in A]
# EVOLVE-BLOCK-END

