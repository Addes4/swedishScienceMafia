# EVOLVE-BLOCK-START
"""Geometric progression with base 2: minimizes |A+A| relative to |A-A|."""
import math


def solve():
    """Return A = {2^i : 0 <= i < n} maximizing log|A-A|/log|A+A| plus size bonus."""
    best = None
    best_score = -1.0
    for n in range(2, 200):
        A = [1 << i for i in range(n)]
        # |A-A|: differences 2^j - 2^i = 2^i(2^(j-i)-1), distinct for distinct pairs (i,j), i<j
        # plus 0.  Number of distinct nonzero differences equals number of distinct
        # values 2^i * (2^k - 1) with i>=0, k>=1. For base 2 these are mostly unique.
        diffs = set()
        for i in range(n):
            for j in range(n):
                if i != j:
                    diffs.add(A[j] - A[i])
        diffs.add(0)
        sums = set()
        for i in range(n):
            for j in range(n):
                sums.add(A[i] + A[j])
        nd = len(diffs)
        ns = len(sums)
        if nd < 2 or ns < 2:
            continue
        score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
        if score > best_score:
            best_score = score
            best = A
    return best if best is not None else [1, 2]
# EVOLVE-BLOCK-END
