# EVOLVE-BLOCK-START
"""Digit/mixed-radix construction: maximize exact log|A-A|/log|A+A|."""
import math
import random
import time

import numpy as np


def _ratio_from_sets(A):
    A = np.asarray(sorted(set(int(x) for x in A)), dtype=np.int64)
    n = A.size
    if n < 2:
        return 0.0
    diffs = np.unique(A[:, None] - A[None, :]).size
    sums = np.unique(A[:, None] + A[None, :]).size
    if sums <= 1:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _build_digits(radices, digit_sets):
    """A = all sums of d_i * R^i with d_i in digit_sets[i], R = prod radices..."""
    vals = np.array([0], dtype=np.int64)
    place = 1
    for r, ds in zip(radices, digit_sets):
        ds = np.asarray(sorted(set(ds)), dtype=np.int64)
        vals = (vals[:, None] + (ds[None, :] * place)).ravel()
        place *= r
    return np.unique(vals)


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 115.0

    # A family: one "big" digit range at one position, {0,1} (or {0,1,2}) elsewhere.
    # This makes A-A large (many linear combinations) but A+A concentrated.
    big_ranges = [2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32]
    small_alphas = [[0, 1], [0, 1, 2], [0, 1, 3], [0, 2, 3]]
    base_choices = [2, 3, 4, 5, 6, 7, 8, 10, 12, 16]

    candidates = []
    # Build candidate configurations: place the big digit range at the top.
    for npos in range(1, 9):  # number of digit positions with {0,1}-like alphabets
        for big in big_ranges:
            for base in base_choices:
                if base < big:
                    continue
                # radices: small positions radix = base, big position radix = big (or base)
                for alpha in small_alphas:
                    radices = []
                    digit_sets = []
                    for _ in range(npos):
                        radices.append(base)
                        digit_sets.append(alpha)
                    # big digit position on top
                    radices.append(max(big, base))
                    digit_sets.append(list(range(big)))
                    candidates.append((radices, digit_sets))

    random.shuffle(candidates)

    # Track a few top candidates; but scoring is expensive, so use a fast bound first.
    for radices, digit_sets in candidates:
        if time.time() > deadline:
            break
        A = _build_digits(radices, digit_sets)
        if A.size < 2 or A.size > 4000:
            continue
        # quick evaluation
        try:
            s = _ratio_from_sets(A)
        except Exception:
            continue
        if s > best_score:
            best_score = s
            best = A.copy()

    if best is None:
        return [0, 1]

    # Local refinement: try tweaking the top-config radices / digit ranges via
    # small perturbations of actual elements to squeeze the ratio a bit.
    A = best.tolist()
    cur = A[:]
    cur_score = best_score
    t0 = time.time()
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-2, 2)
        if len(set(cand)) < len(cand):
            continue
        s = _ratio_from_sets(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END

