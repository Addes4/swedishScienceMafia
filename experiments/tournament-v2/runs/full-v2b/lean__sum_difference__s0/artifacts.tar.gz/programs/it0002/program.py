# EVOLVE-BLOCK-START
"""Greedy + local search construction for large |A-A|, small |A+A|.

Idea: geometric progressions give |A+A| ~ |A-A| ~ n^2/... but collisions in A+A
are fewer when elements are spread geometrically.  We build A greedily by adding
elements that maximize the current ratio, then refine with local search.
"""
import math
import random
import time


def _counts(a):
    a = list(a)
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums)


def _score(a):
    n = len(set(a))
    if n < 2:
        return 0.0
    d, s = _counts(a)
    if s == 0:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _greedy_build(rng, base, target_n):
    """Start from a seed, greedily add elements maximizing the score."""
    a = base[:]
    while len(a) < target_n:
        best_add = None
        best_s = _score(a)
        cands = set()
        # propose many candidate new elements around the current span
        span = max(abs(x) for x in a) if a else 1
        for _ in range(60):
            c = rng.randint(-2 * span, 2 * span)
            if abs(c) < 1e14:
                cands.add(c)
        # also try geometric-style values beyond current range
        hi = max(a) if a else 1
        for k in range(1, 40):
            cands.add(hi * 2 + k)
            cands.add(-hi * 2 - k)
        for c in cands:
            if c in a:
                continue
            t = a + [c]
            sc = _score(t)
            # bonus small for size, prefer additions that raise ratio
            if sc > best_s:
                best_s = sc
                best_add = c
        if best_add is None:
            # fall back: add far-out element to boost differences
            hi = max(abs(x) for x in a)
            best_add = rng.choice([2 * hi + rng.randint(1, 5), -2 * hi - rng.randint(1, 5)])
        a.append(best_add)
    return a


def _local_search(a, deadline, rng):
    best = list(set(a))
    best_s = _score(best)
    cur = best[:]
    cur_s = best_s
    while time.time() < deadline:
        cand = cur[:]
        i = rng.randrange(len(cand))
        step = rng.choice([-2, -1, 1, 2, -3, 3, -5, 5, -10, 10])
        cand[i] += step
        if len(set(cand)) < len(cand):
            continue
        sc = _score(cand)
        if sc > cur_s or (sc == cur_s and rng.random() < 0.5):
            cur, cur_s = cand, sc
            if sc > best_s:
                best, best_s = cand[:], sc
        else:
            if rng.random() < 0.05:
                cur, cur_s = best[:], best_s
    return best, best_s


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 100
    overall_best = None
    overall_s = -1.0

    seeds = [
        [0, 1, 3, 7, 15, 31, 63, 127],
        [1, 2, 4, 8, 16, 32, 64, 128, 256],
        [-100, -50, 0, 1, 2, 4, 8, 16, 32, 64],
        [0, 1, 4, 9, 16, 25, 36, 49, 64, 81],
        [random.randint(-50, 50) for _ in range(6)],
    ]

    attempt = 0
    while time.time() < deadline:
        rng2 = random.Random(rng.randint(0, 10**9))
        seed = seeds[attempt % len(seeds)]
        attempt += 1
        target = rng2.choice([8, 10, 12, 14, 16, 18, 20])
        a = _greedy_build(rng2, seed, target)
        sub_deadline = min(deadline, time.time() + 15)
        a, sc = _local_search(a, sub_deadline, rng2)
        if sc > overall_s:
            overall_s = sc
            overall_best = a[:]
            # small greedy extension
            while len(overall_best) < 30 and time.time() < deadline:
                cur = overall_best
                best_c = None
                best_s = _score(cur)
                span = max(abs(x) for x in cur)
                cands = set()
                for _ in range(80):
                    cands.add(rng2.randint(-3 * span, 3 * span))
                for c in cands:
                    if c in cur:
                        continue
                    s2 = _score(cur + [c])
                    if s2 > best_s:
                        best_s = s2
                        best_c = c
                if best_c is None:
                    break
                overall_best.append(best_c)
                overall_s = best_s

    if overall_best is None:
        overall_best = [1, 2, 4, 8, 16, 32, 64]
    return sorted(set(int(x) for x in overall_best))
# EVOLVE-BLOCK-END
