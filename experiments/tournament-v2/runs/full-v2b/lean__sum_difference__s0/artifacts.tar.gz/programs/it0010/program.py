# EVOLVE-BLOCK-START
"""Construct sets maximizing log|A-A|/log|A+A| via geometric progressions with local offset tuning."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _geo_score(b, n):
    """Score of A = {b^0, ..., b^(n-1)} computed exactly but efficiently."""
    vals = [b ** i for i in range(n)]
    if vals[-1] > 10 ** 15:
        return None, None
    return _score(vals), vals


def solve():
    best = None
    best_score = -1.0

    # 1) Sweep geometric progressions over bases and lengths within limits.
    for b in range(2, 60):
        for n in range(3, 60):
            if b ** (n - 1) > 10 ** 15:
                break
            if n > 4000:
                break
            s, vals = _geo_score(b, n)
            if s is not None and s > best_score:
                best_score = s
                best = vals[:]

    # 2) Also try slightly-perturbed geometric progressions and shifted versions.
    random.seed(12345)
    deadline = time.time() + 60
    if best is None:
        best = [1, 2, 4, 8, 16, 32, 64]
        best_score = _score(best)

    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6:
            # perturb a random element by a small amount
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1, -2, 2, -3, 3])
        elif op < 0.8 and len(cand) < 100:
            # try duplicating structure: insert mid value between two elements
            cand.append(random.choice(cand) * 2 + random.randint(-1, 1))
        elif len(cand) > 3:
            # drop an element
            cand.pop(random.randrange(len(cand)))
        cand = sorted(set(cand))
        if not cand or max(abs(x) for x in cand) > 10 ** 15 or len(cand) > 4000:
            continue
        try:
            s = _score(cand)
        except Exception:
            continue
        if s > best_score:
            best_score = s
            best = cand[:]
            cur = cand[:]
        elif random.random() < 0.02:
            cur = best[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
