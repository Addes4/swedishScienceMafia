# EVOLVE-BLOCK-START
"""Greedy construction maximizing log|A-A|/log|A+A|, plus local refinement."""
import math
import random
import time


def _ratio(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _counts(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def solve():
    random.seed(12345)
    best = [0]
    best_score = 0.0
    deadline = time.time() + 110

    # Candidate pool: powers of 2/3 and combinations build a rich difference set.
    pool = []
    for b in (2,):
        v = 1
        for _ in range(55):
            pool.append(v)
            v *= b
    # Add numbers with digits in {0,1} base 3 up to a limit for difference richness
    vals = set()
    def gen(prefix, depth, base, digits):
        if depth == 0:
            vals.add(prefix)
            return
        for d in digits:
            gen(prefix * base + d, depth - 1, base, digits)
    for base in (3,):
        gen(0, 12, base, [0, 1])
    pool.extend(sorted(vals))
    pool.extend([-v for v in list(vals)[:2000]])
    pool = sorted(set(pool))
    random.shuffle(pool)

    # Greedy: start from small seed sets that are difference-rich.
    seeds = [[0], [0, 1], [0, 1, 3], [0, 1, 2, 4]]
    for seed in seeds:
        cur = seed[:]
        improved = True
        while improved and time.time() < deadline:
            improved = False
            cd = len(set(x - y for x in cur for y in cur))
            cs = len(set(x + y for x in cur for y in cur))
            best_gain = 0.0
            best_add = None
            for cand in pool:
                if cand in cur:
                    continue
                nova = cur + [cand]
                nd, ns = _counts(nova)
                # ratio change: gain in log(diffs) minus penalty in log(sums)
                gain = (math.log(nd) - math.log(cd)) - (math.log(ns) - math.log(cs))
                if gain > best_gain:
                    best_gain = gain
                    best_add = cand
            if best_add is not None and best_gain > 0:
                cur.append(best_add)
                improved = True
            if len(cur) > 300:
                break
        sc = _ratio(cur)
        if sc > best_score:
            best, best_score = cur[:], sc

    # Local refinement with exact score using diverse element moves.
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.4 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1, -2, 2, -3, 3, 5, -5, 8, -8])
        elif op < 0.7:
            cand.append(random.choice(pool))
        elif len(cand) > 3:
            i = random.randrange(len(cand))
            del cand[i]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _ratio(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
