# EVOLVE-BLOCK-START
"""Construction + exact annealing for maximizing log|A-A|/log|A+A|."""
import math
import random
import time


def _diff_sum_sizes(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums)


def _score(a):
    n = len(set(a))
    if n < 2:
        return 0.0
    d, s = _diff_sum_sizes(a)
    if s <= 1 or d <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # Phase 1: geometric progressions with various bases/lengths.
    for b in range(2, 40):
        for n in range(2, 200):
            p = b ** (n - 1)
            if p > 10 ** 15:
                break
            a = [b ** i for i in range(n)]
            s = _score(a)
            if s > best_score:
                best_score = s
                best = a[:]

    # Try differences of two geometric progressions (Sidon-ish: blocks)
    # A = {B^i * c : ...} scaled to keep values bounded
    for b in range(2, 25):
        for n in range(2, 60):
            if b ** (n - 1) > 10 ** 15:
                break
            base = [b ** i for i in range(n)]
            for offset in range(1, 50):
                a = [x + offset for x in base]
                s = _score(a)
                if s > best_score:
                    best_score = s
                    best = a[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    # Phase 2: exact-score annealing over the best found set.
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        move = random.random()
        if move < 0.8:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1, -2, 2, -3, 3, -5, 5])
        elif move < 0.9 and len(cand) < 400:
            cand.append(random.choice(cur) + random.choice([-1, 1, -2, 2]))
        elif len(cand) > 3:
            cand.pop(random.randrange(len(cand)))
        cand = list(set(cand))
        if any(abs(x) > 10 ** 15 for x in cand):
            continue
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.05:
            cur = cand

    return sorted(set(best))
# EVOLVE-BLOCK-END
