# EVOLVE-BLOCK-START
"""Constructive attempt: base-B digit set with a low-sum alphabet, plus a fast exact scorer."""
import math
import time


def _diffs_sums(a):
    a = list(a)
    n = len(a)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score_counts(dc, sc, n):
    if n < 2 or sc < 2:
        return 0.0
    return math.log(dc) / math.log(sc) + (1 - 1 / n) / 100


def _score(a):
    dc, sc = _diffs_sums(a)
    return _score_counts(dc, sc, len(set(a)))


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Try constructive digit-set families: k positions, base B, digit alphabet D.
    # A = { sum d_i B^i : (d_0..d_{k-1}) in D^k } restricted to manageable size.
    deadline = time.time() + 100.0

    candidates = []

    # Family 1: full digit alphabet {0..m-1} on k positions, base B = big enough
    # to keep digits separated (then |A+A| = |A|^2/n ... actually box of sums).
    for k in range(2, 7):
        for B in range(2, 40):
            for m in range(2, 8):
                if time.time() > deadline:
                    break
                # only if not too many elements
                if m ** k > 4000:
                    continue
                A = set()
                # generate m^k digit vectors iteratively
                stack = [0]
                for _ in range(k):
                    newst = []
                    for v in stack:
                        for d in range(m):
                            newst.append(v + d * (B ** _))
                    stack = newst
                A = set(stack)
                if len(A) < 2:
                    continue
                candidates.append(list(A))

    # Evaluate candidates with pruning on |A-A| proxy cheapness: cap size
    for A in candidates:
        if len(A) > 2000:
            continue
        if time.time() > deadline:
            break
        s = _score(A)
        if s > best_score:
            best, best_score = A, s

    # local refinement of best
    cur = best[:]
    end2 = time.time() + 18.0
    import random
    while time.time() < end2:
        cand = cur[:]
        if random.random() < 0.7:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-1, 1)
        else:
            if len(cand) < 3500:
                cand.append(random.randint(-10, 10))
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.15:
            cur = best[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
