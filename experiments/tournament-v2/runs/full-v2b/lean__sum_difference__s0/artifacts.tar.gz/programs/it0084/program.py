# EVOLVE-BLOCK-START
"""Build A as a carry-free digit product, then refine the *actual* set by direct
swap-based hill-climbing on the realized objective log|A-A|/log|A+A| (plus size
bonus).  The product gives ratio = log|D-D|/log|D+D| for the digit alphabet;
local moves on A itself can collapse extra sums while keeping differences large,
pushing past the pure-product ceiling."""
import math
import random
import time
from itertools import product

try:
    import numpy as np
    _HAVE_NP = True
except Exception:
    _HAVE_NP = False


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    R = 40
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32],
                 [0, 1, 2, 4, 7, 12, 20], [0, 1, 2, 5, 9, 16, 28]]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 15)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        for _ in range(500):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.7 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _score_stats(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    if _HAVE_NP:
        arr = np.asarray(a, dtype=np.int64)
        d = arr[:, None] - arr[None, :]
        s = arr[:, None] + arr[None, :]
        nd = int(np.unique(d).size)
        ns = int(np.unique(s).size)
    else:
        nd = len({x - y for x in a for y in a})
        ns = len({x + y for x in a for y in a})
    if nd < 2 or ns < 2:
        return 0.0, nd, ns
    sc = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return sc, nd, ns


def _score(a):
    return _score_stats(a)[0]


def _refine(a, deadline, span_hint):
    a = sorted(set(a))
    best = a[:]
    best_sc, _, _ = _score_stats(best)
    lo = min(a)
    hi = max(a)
    width = hi - lo
    cur = a[:]
    cur_sc = best_sc
    step = max(1, width // 2)
    iters = 0
    while time.time() < deadline:
        iters += 1
        cand = cur[:]
        i = random.randrange(len(cand))
        if random.random() < 0.5:
            cand[i] = random.randint(lo - step, hi + step)
        else:
            cand[i] = cur[i] + random.randint(-step, step)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc >= cur_sc:
            cur, cur_sc = cand, sc
            if sc > best_sc:
                best, best_sc = cand[:], sc
        if iters % 400 == 0:
            # occasionally enlarge search span / perturb
            lo = min(cur)
            hi = max(cur)
            step = max(1, (hi - lo) // 2)
            if random.random() < 0.25:
                cur = best[:]
                cur_sc = best_sc
    return best, best_sc


def solve():
    deadline = time.time() + 55
    D, r = _search_alphabet(min(deadline, time.time() + 20))

    candidates = []
    candidates.append(_build(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5], [0, 1, 3, 7, 15, 31]):
        candidates.append(_build(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    # refine the best candidate by direct local search on the realized score
    if best is not None:
        ref, rsc = _refine(best, deadline, max(best) - min(best))
        if rsc > best_s:
            best, best_s = ref, rsc

    return list(best)
# EVOLVE-BLOCK-END
