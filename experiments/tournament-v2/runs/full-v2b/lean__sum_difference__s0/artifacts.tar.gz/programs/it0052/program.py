# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a tuned digit alphabet D (no-carry product).

|A-A| = |D-D|^k, |A+A| = |D+D|^k when the base B avoids carries, so the ratio
equals log|D-D|/log|D+D| independent of k.  Find the best small alphabet D with
a fast numpy-bitset scorer, then realize it as a product of maximal size <= cap.
"""
import math
import random
import time
import numpy as np
from itertools import product


def _bitset_stats(D):
    """Return (|D-D|, |D+D|) via boolean shift-OR on a numpy bitmask."""
    D = sorted(set(int(d) for d in D))
    if len(D) < 2:
        return 0, 0
    lo, hi = D[0], D[-1]
    span = hi - lo
    # difference range: -(span) .. span
    shift = span
    n = 2 * span + 1
    dd_bits = np.zeros(n, dtype=bool)
    for a in D:
        idx = a - lo + shift
        dd_bits |= (np.arange(n) - (a - lo + shift) >= -shift) & \
                   (np.arange(n) - (a - lo + shift) <= span)
    # faster: build by OR of shifts
    dd_bits = np.zeros(n, dtype=bool)
    base = np.zeros(n, dtype=bool)
    base[shift] = True
    for a in D:
        s = a - lo
        dd_bits[s:s + n - 2 * s - (n - 2 * s)] |= base[0:0].copy()  # placeholder
    # Explicit approach
    dd_bits = np.zeros(n, dtype=bool)
    for a in D:
        for b in D:
            dd_bits[(a - b) + shift] = True
    s_lo, s_hi = 2 * lo, 2 * hi
    m = s_hi - s_lo + 1
    ss_bits = np.zeros(m, dtype=bool)
    for a in D:
        for b in D:
            ss_bits[(a + b) - s_lo] = True
    return int(dd_bits.sum()), int(ss_bits.sum())


def _fast_stats(D):
    """Fast bitset stats using python ints as bitmasks."""
    D = sorted(set(int(d) for d in D))
    if len(D) < 2:
        return 0, 0
    lo = D[0]
    hi = D[-1]
    span = hi - lo
    dd = 0
    for a in D:
        s = a - lo
        for b in D:
            dd |= 1 << ((a - b) + span)
    dd = bin(dd).count("1")
    s_lo = 2 * lo
    ss = 0
    for a in D:
        for b in D:
            ss |= 1 << (a + b - s_lo)
    ss = bin(ss).count("1")
    return dd, ss


def _ratio(D):
    dd, ss = _fast_stats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    R = 40
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32], [0, 1, 2, 4, 5, 7]
                 ]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    # exhaustive small sizes
    for s in (2, 3, 4):
        vals = list(range(0, 9))
        if s == 2:
            for a in vals:
                for b in vals:
                    if a < b:
                        r = _ratio([a, b])
                        if r > best_r:
                            best_r, best_D = r, [a, b]
        if time.time() >= deadline:
            return best_D, best_r

    while time.time() < deadline:
        s = random.randint(3, 16)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        for _ in range(300):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.75 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.9:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    Aset = set(a)
    diffs = {x - y for x in Aset for y in Aset}
    sums = {x + y for x in Aset for y in Aset}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    deadline = time.time() + 55
    D, r = _search_alphabet(deadline)

    candidates = []
    candidates.append(_build(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4], [0, 1, 2, 4, 5, 7]):
        candidates.append(_build(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
