# EVOLVE-BLOCK-START
"""Construction search: base-b digit-restricted sets, tuned on the exact score."""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def _digit_set(base, length, digits):
    """All numbers sum(d_i * base^i) with d_i in `digits`, i in [0,length)."""
    vals = [0]
    for i in range(length):
        p = base ** i
        nv = []
        for v in vals:
            for d in digits:
                nv.append(v + d * p)
        vals = nv
        if len(vals) > 4000:
            break
    return sorted(set(vals))


def solve():
    best = [1, 2, 4, 8]
    best_score, _, _ = _score(best)
    deadline = time.time() + 110

    # Try digit-restricted constructions over many bases/lengths/digit sets.
    digit_sets = [
        (0, 1), (1, 2), (0, 2), (1,), (0, 1, 2),
    ]
    for base in range(2, 9):
        for digits in digit_sets:
            for length in range(2, 40):
                a = _digit_set(base, length, digits)
                if len(a) < 2 or len(a) > 4000:
                    if len(a) > 4000:
                        break
                    continue
                s, _, _ = _score(a)
                if s > best_score:
                    best, best_score = a[:], s

    # Pure geometric progressions (single generator chains).
    for base in range(2, 6):
        a = []
        v = 1
        while len(a) < 4000:
            a.append(v)
            v *= base
            if abs(v) > 10 ** 15:
                break
        if len(a) >= 2:
            s, _, _ = _score(a)
            if s > best_score:
                best, best_score = a[:], s

    # Local refinements: try replacing constructed set by its scaled/translated variants
    # and by restricting to first k elements (multiples).
    a0 = best[:]
    for mul in (1, 2, 3):
        for k in range(2, len(a0) + 1):
            a = [mul * x for x in a0[:k]]
            s, _, _ = _score(a)
            if s > best_score:
                best, best_score = a[:], s

    # Randomized hill-climb on element values around the best set (bounded time).
    import random
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        if random.random() < 0.4 and len(cand) < 4000:
            cand.append(random.randint(1, 10 ** 6))
        elif random.random() < 0.3 and len(cand) > 3:
            del cand[random.randrange(len(cand))]
        else:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * (2 ** random.randint(0, 12))
        s, _, _ = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = best[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
