# EVOLVE-BLOCK-START
"""Directly optimize the realized objective log|A-A|/log|A+A| + bonus.

Key facts used:
  * For an interval [0,n-1], |A-A| = 2n-1 and |A+A| = 2n-1, ratio ~ 1 (bad: sums big).
  * We want many differences (near Sidon / B_2-like: |A-A| ~ n^2) while sums stay small.
  * A near-arithmetic-progression with exponentially growing gaps gives many distinct
    differences but small sums, but that's the product construction already (~0.888).

We therefore do a direct swap-based local search on the actual set, scoring the true
|A-A| and |A+A| with numpy.  State is a sorted set of n integers; moves change one
element.  We keep n fixed per run and try several n, keeping the best realized score.
"""
import math
import random
import time

import numpy as np


def _score_np(a):
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return -1.0, 0, 0
    diffs = np.unique(a[:, None] - a[None, :])
    nd = diffs.size
    sums = np.unique(a[:, None] + a[None, :])
    ns = sums.size
    if nd < 2 or ns < 2:
        return -1.0, nd, ns
    sc = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return sc, nd, ns


def _local_search(a, deadline, max_steps=20000):
    """Swap-based local search maximizing realized score."""
    A = sorted(set(int(x) for x in a))
    n = len(A)
    if n < 2:
        return A
    Aset = set(A)
    best = A[:]
    best_sc, _, _ = _score_np(best)
    cur = A[:]
    cur_sc = best_sc
    span = max(A) - min(A) + 1
    step = 0
    while step < max_steps and time.time() < deadline:
        step += 1
        idx = random.randrange(n)
        old = cur[idx]
        # propose a new value near the current range
        lo = min(cur) - span
        hi = max(cur) + span
        if random.random() < 0.5:
            newval = old + random.choice([-2, -1, 1, 2])
        else:
            newval = random.randint(lo, hi)
        if newval in Aset and newval != old:
            continue
        cand = cur[:]
        cand[idx] = newval
        cand = sorted(set(cand))
        if len(cand) != n:
            continue
        sc, _, _ = _score_np(cand)
        if sc >= cur_sc - 1e-12:
            cur, cur_sc = cand, sc
            Aset.discard(old)
            Aset.add(newval)
            if sc > best_sc:
                best, best_sc = cand[:], sc
        step += 1
    return best


def _run_length(n, deadline):
    # start from a moderate interval / geometric mix
    base = list(range(n))
    # geometric-ish seed
    geo = []
    v = 0
    for i in range(n):
        geo.append(v)
        v += max(1, i)
    seeds = [base, geo]
    best = None
    best_sc = -1.0
    for s in seeds:
        r = _local_search(s, deadline)
        sc, _, _ = _score_np(r)
        if sc > best_sc:
            best_sc, best = sc, r
    return best, best_sc


def solve():
    deadline = time.time() + 110
    best = None
    best_sc = -1.0
    # try a range of sizes; smaller sets are faster per evaluation
    sizes = [12, 16, 20, 24, 28, 30, 32]
    per = (deadline - time.time()) / len(sizes)
    for n in sizes:
        sub_deadline = min(deadline, time.time() + per)
        r, sc = _run_length(n, sub_deadline)
        if sc > best_sc:
            best_sc, best = sc, r
        if time.time() >= deadline:
            break
    if best is None:
        best = [0, 1, 2, 4, 8, 16]
    return list(best)
# EVOLVE-BLOCK-END
