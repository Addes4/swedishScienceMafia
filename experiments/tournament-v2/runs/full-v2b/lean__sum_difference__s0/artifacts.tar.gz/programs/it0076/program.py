# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a tuned digit alphabet D.

If A = { sum_i d_i B^i : d_i in D } with B large enough that no two digit-vectors
collide (no carries), then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so the objective log|A-A|/log|A+A| = log|D-D|/log|D+D| is independent of k.
Therefore we only need to find a small integer alphabet D maximizing
log|D-D|/log|D+D|, then replicate it (largest k with |D|^k <= 4000) for the size bonus.
"""
import math
import random
import time

import numpy as np


def _ratio(D):
    """log|D-D| / log|D+D| for a small integer alphabet D (exact)."""
    D = np.unique(np.asarray(D, dtype=np.int64))
    if D.size < 2:
        return 0.0
    dd = np.unique(D[:, None] - D[None, :]).size
    ss = np.unique(D[:, None] + D[None, :]).size
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Simulated annealing over integer alphabets maximizing log|D-D|/log|D+D|."""
    best_D = [0, 1, 2, 4, 8, 16, 32]
    best_r = _ratio(best_D)

    seeds = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
             [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32],
             [0, 1, 2, 4, 8, 16, 32, 64], [0, 1, 2, 3, 6, 12, 24, 48],
             [0, 1, 2, 4, 8, 16, 32, 64, 128]]
    for sp in seeds:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    # search in a moderate range so alphabets can be spread out (few sums)
    R = 60
    while time.time() < deadline:
        s = random.randint(2, 14)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        T = 0.02
        for _ in range(500):
            if time.time() >= deadline:
                break
            T *= 0.995
            cand = D[:]
            op = random.random()
            if op < 0.65 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.82:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r or random.random() < math.exp((cr - r) / max(T, 1e-6)):
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    """Build the product set (subset sums) from alphabet D, largest size <= cap."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]          # normalize to start at 0
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1                     # no carries between digit positions
    # iterative product construction (avoid huge Python loops via numpy)
    vals = np.array([0], dtype=np.int64)
    p = 1
    for _ in range(k):
        vals = (vals[:, None] + np.asarray(D, dtype=np.int64)[None, :] * p).ravel()
        p *= B
    return np.unique(vals).tolist()


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0.0
    # full difference/sum sets (n^2 up to 16M, fine within time)
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    if diffs < 2 or sums < 2:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 70
    D, r = _search_alphabet(deadline)

    candidates = []
    candidates.append(_build(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 4, 8, 16, 32],
               [0, 1, 2, 4, 8, 16, 32, 64]):
        candidates.append(_build(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END

