# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a tuned digit alphabet D.

If A = { sum_i d_i B^i : d_i in D } with B large enough that no two digit-vectors
collide (no carries), then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so the objective log|A-A|/log|A+A| = log|D-D|/log|D+D| is independent of k.
We search for a small integer alphabet D maximizing the *realized* score of the
built set (ratio plus the size bonus), then build it at the largest feasible k.
"""
import math
import random
import time
from itertools import product

try:
    import numpy as np
    _HAVE_NP = True
except Exception:
    _HAVE_NP = False


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ddstats_np(D):
    """Bitset count of |D-D| and |D+D| via boolean shift-OR."""
    D = sorted(set(D))
    lo = min(D)
    hi = max(D)
    span = hi - lo
    size = 2 * span + 1
    # encode value v - lo as bit position
    bits = 0
    for d in D:
        bits |= 1 << (d - lo)
    # difference set: for each shift s, D & (D >> s)
    diff = 0
    for s in range(span + 1):
        if (bits & (bits >> s)) != 0:
            diff |= 1 << s
    dd = 2 * diff.bit_count() - (1 if (bits & 1) else 0)
    # sum set range [2*lo, 2*hi]
    sumbits = 0
    arr = [d - lo for d in D]
    for a in arr:
        for b in arr:
            sumbits |= 1 << (a + b)
    ss = sumbits.bit_count()
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _realized_score(D, cap=4000):
    """Score of the actual built product set (ratio + size bonus)."""
    A = _build(D, cap)
    n = len(A)
    if n < 2:
        return -1.0, A
    dd, ss = _ddstats(D)
    s = len(set(D))
    if s < 2:
        return -1.0, A
    k = 1
    Dn = sorted(set(D))
    while s ** (k + 1) <= cap:
        k += 1
    total = s ** k
    # ratio exact under no-carry
    if dd < 2 or ss < 2:
        return -1.0, A
    ratio = (k * math.log(dd)) / (k * math.log(ss))
    sc = ratio + (1 - 1 / total) / 100
    return sc, A


def _search_alphabet(deadline, cap=4000):
    best_D = [0, 1, 2, 4, 8, 16]
    best_sc, _ = _realized_score(best_D, cap)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32],
                 [0, 1, 2, 3, 5, 8, 13], [0, 1, 4, 9, 16, 25]]
    for sp in seed_pool:
        sc, _ = _realized_score(sp, cap)
        if sc > best_sc:
            best_sc, best_D = sc, sp[:]

    R = 40
    while time.time() < deadline:
        s = random.randint(2, 14)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        sc, _ = _realized_score(D, cap) if r > 0.9 else (-1.0, None)
        local_best = sc
        local_D = D[:]
        for _ in range(300):
            if time.time() >= deadline:
                break
            cand = local_D[:]
            op = random.random()
            if op < 0.7 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            rc = _ratio(cand)
            if rc <= r:
                continue
            csc, _ = _realized_score(cand, cap)
            if csc >= sc:
                local_D, sc, r = cand, csc, rc
        if sc > best_sc:
            best_sc, best_D = sc, local_D[:]
    return best_D, best_sc


def _build(D, cap=4000):
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    deadline = time.time() + 55
    D, r = _search_alphabet(deadline)

    candidates = []
    candidates.append(_build(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 5, 8, 13], [0, 1, 4, 9, 16, 25],
               [0, 1, 2, 3, 4, 5]):
        candidates.append(_build(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c
    return list(best)
# EVOLVE-BLOCK-END
