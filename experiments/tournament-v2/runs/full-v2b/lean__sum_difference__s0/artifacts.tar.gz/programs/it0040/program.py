# EVOLVE-BLOCK-START
"""Constructive search for A with large |A-A| and small |A+A|."""
import math
import random
import time
from itertools import product


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _digit_construction(B, d, digits):
    """A = all sums sum_i c_i * B^i with c_i in digits. Returns list."""
    A = [0]
    for i in range(d):
        pw = B ** i
        A = [a + c * pw for a in A for c in digits]
    return A


def _subset_digit_construction(B, d, max_elements=4000):
    """All integers with base-B digits in {0,1} over d positions (increasing values)."""
    A = [0]
    for i in range(d):
        pw = B ** i
        A = A + [a + pw for a in A]
        if len(A) > max_elements:
            # keep the most spread out? just truncate worst case
            A = A[:max_elements]
    return A


def solve():
    limit = 8 * 10 ** 9  # keep magnitudes sane
    best = None
    best_score = -1.0

    # Try {0,1}-digit families with various bases and depths.
    for B in range(2, 8):
        for d in range(2, 15):
            A = _subset_digit_construction(B, d)
            if len(A) > 4000 or len(A) < 3:
                continue
            if max(abs(x) for x in A) > 10 ** 15:
                continue
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A

    # Try mixed digit sets {0,1,...,k} for small k, various bases.
    for B in range(3, 12):
        for d in range(2, 10):
            for k in (1, 2):
                digits = list(range(k + 1))
                A = _digit_construction(B, d, digits)
                if len(A) > 4000 or len(A) < 3:
                    continue
                if max(abs(x) for x in A) > 10 ** 15:
                    continue
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A

    # Asymmetric digit sets: digits differ per position (powers of 3 growth)
    for B in range(2, 10):
        for d in range(3, 25):
            # use {0,1} at all but one position, wider elsewhere
            A = _subset_digit_construction(B, d)
            if len(A) > 4000:
                break
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A

    # Local refinement: allow translating and scaling the best set
    if best is not None:
        cand = list(best)
        cur_score = best_score
        deadline = time.time() + 100
        iters = 0
        while time.time() < deadline:
            iters += 1
            # random perturbation: add/remove an element from the construction
            c = cand[:]
            r = random.random()
            if r < 0.5 and len(c) > 3:
                c.pop(random.randrange(len(c)))
            elif r < 0.8:
                # add a random signed combination
                B = random.choice([2, 3, 4, 5])
                v = 0
                for i in range(random.randint(1, 8)):
                    v += random.choice([0, 1]) * (B ** i)
                if v != 0 and v not in c and abs(v) < 10 ** 15:
                    c.append(v)
            else:
                # shift by scalar multiple to alter sum collisions
                m = random.choice([1, 2, 3])
                c = [x * m for x in c]
            c = sorted(set(c))
            if len(c) < 3 or len(c) > 4000:
                continue
            s = _score(c)
            if s > cur_score:
                cur_score = s
                cand = c
                if s > best_score:
                    best_score = s
                    best = c

    return sorted(set(best)) if best else [0, 1, 3]
# EVOLVE-BLOCK-END
