# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a tuned digit alphabet D (carry-free base B).

If A = { sum_i d_i B^i : d_i in D } with B > 2*span(D), no two digit-vectors
collide, so exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

hence the objective log|A-A|/log|A+A| = log|D-D|/log|D+D|, independent of k.
We search D thoroughly for the best ratio, then replicate it (largest k with
|D|^k <= 4000) to gain the size bonus.
"""
import math
import random
import time
from itertools import product


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Exhaustive-ish + hill-climb search for D maximizing log|D-D|/log|D+D|."""
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)

    # structured seeds
    seeds = [
        [0, 1], [0, 1, 2], [0, 1, 3], [0, 1, 2, 4], [0, 1, 2, 4, 8],
        [0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8, 16, 32],
        [0, 1, 3, 7, 15], [0, 1, 3, 7, 15, 31],
        [0, 1, 2, 3], [0, 1, 2, 3, 4], [0, 1, 2, 3, 4, 5],
        [0, 1, 2, 3, 4, 6], [0, 1, 2, 4, 5, 6],
    ]
    for sp in seeds:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    # exhaustive over small ranges to be sure we don't miss the optimum
    for R in (8, 10):
        if time.time() >= deadline:
            break
        # all subsets containing 0 of size up to 6 within [0,R]
        others = list(range(1, R + 1))
        for size in (2, 3, 4, 5, 6):
            if time.time() >= deadline:
                break
            # limit blowup
            import itertools
            if math.comb(len(others), size - 1) > 60000:
                continue
            for comb in itertools.combinations(others, size - 1):
                if time.time() >= deadline:
                    break
                D = (0,) + comb
                r = _ratio(D)
                if r > best_r:
                    best_r, best_D = r, list(D)
            if best_r > 1.27:
                break

    # hill climbing refine around best
    R = 34
    while time.time() < deadline:
        D = best_D[:]
        r = best_r
        improved = True
        while improved and time.time() < deadline:
            improved = False
            for i in range(len(D)):
                for nv in range(0, R + 1):
                    if nv == D[i]:
                        continue
                    cand = D[:]
                    cand[i] = nv
                    cand = sorted(set(cand))
                    if len(cand) < 2:
                        continue
                    cr = _ratio(cand)
                    if cr > r:
                        D, r, improved = cand, cr, True
                        break
                if improved:
                    break
            # try adding / removing at end
            if not improved and time.time() < deadline:
                for nv in range(0, R + 1):
                    cand = sorted(set(D + [nv]))
                    cr = _ratio(cand)
                    if cr > r:
                        D, r, improved = cand, cr, True
                        break
        if r > best_r:
            best_r, best_D = r, D[:]
        if time.time() >= deadline:
            break

    return best_D, best_r


def _build(D, cap=4000):
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    deadline = time.time() + 55
    D, r = _search_alphabet(deadline)

    candidates = [_build(D)]
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5],
               [0, 1, 2, 4, 8, 16, 32], [0, 1, 3, 7, 15, 31]):
        candidates.append(_build(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
