# EVOLVE-BLOCK-START
"""Geometric progression construction: ratio b makes A+A tiny (few sums) but A-A large."""
import math
import time


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0, 0, 0
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100, len(diffs), len(sums)


def solve():
    """Return A maximizing log|A-A|/log|A+A|.

    Geometric progressions {b^0..b^(n-1)} have |A+A| ~ O(n) (only ~2n-1 values)
    while |A-A| can be close to n^2, giving an excellent ratio.
    """
    LIM = 10**15
    best = None
    best_score = -1.0

    deadline = time.time() + 110

    def try_set(a, refine=False):
        nonlocal best, best_score
        a = sorted(set(a))
        if len(a) < 2:
            return
        if max(abs(x) for x in a) > LIM:
            return
        s, nd, ns = _score(a)
        if s > best_score:
            best_score = s
            best = a[:]

    # Candidate geometric progressions across many bases and lengths.
    candidates = []
    for b in [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 16, 20, 24, 32]:
        a = []
        x = 1
        while x <= LIM and len(a) < 4000:
            a.append(x)
            if x > LIM // b:
                break
            x *= b
        candidates.append((b, a))

    # Also try offset geometric progressions (shifted by a constant).
    for b in [2, 3, 4, 5, 6, 8]:
        a = []
        x = 1
        while x <= LIM and len(a) < 4000:
            a.append(x)
            if x > LIM // b:
                break
            x *= b
        # pad with small elements and near-duplicates to grow A-A
        candidates.append((b, a))

    # Test base-2 style: interleave two geometric progressions with different ratios
    # so sums stay in few residue classes but differences multiply.
    for b1, b2 in [(2, 3), (2, 4), (3, 2), (2, 5), (3, 4)]:
        a = []
        x = 1
        while x <= LIM and len(a) < 2000:
            a.append(x)
            if x > LIM // b1:
                break
            x *= b1
        if a and a[-1] <= LIM // b2:
            y = a[-1] * b2
            while y <= LIM and len(a) < 4000:
                a.append(y)
                if y > LIM // b2:
                    break
                y *= b2
        candidates.append(((b1, b2), a))

    for b, a in candidates:
        try_set(a)

    # Local refinement: try adding/removing/replacing elements near the best.
    if best is not None:
        import random
        random.seed(12345)
        cur = best[:]
        # refine by trying to add elements that increase |A-A| while keeping |A+A| small
        base_pool = []
        for b in [2, 3, 4, 5]:
            x = 1
            while x <= LIM:
                base_pool.append(x)
                if x > LIM // b:
                    break
                x *= b
        # Try inserting extra elements and cleaning up
        while time.time() < deadline:
            cand = cur[:]
            # add an element
            if len(cand) < 4000:
                e = random.choice(base_pool)
                if e not in cand:
                    cand.append(e)
            # remove an element
            if len(cand) > 2 and random.random() < 0.3:
                del cand[random.randrange(len(cand))]
            cand = sorted(set(cand))
            if max(abs(x) for x in cand) > LIM:
                continue
            s, _, _ = _score(cand)
            if s > best_score:
                best_score = s
                best = cand[:]
                cur = cand[:]
            else:
                cur = best[:]
    return best if best else [1, 2, 4]
# EVOLVE-BLOCK-END

