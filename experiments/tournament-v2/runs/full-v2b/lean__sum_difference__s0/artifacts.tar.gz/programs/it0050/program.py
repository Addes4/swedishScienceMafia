# EVOLVE-BLOCK-START
"""Construct A to maximize log|A-A| / log|A+A|.

Idea: use a base-B no-carry "box" set
    S = { sum_i d_i B^i : d_i in D },   |S-S| = |D-D|^k, |S+S| = |D+D|^k.
Then take the union of several translates of S:
    A = union_j (S + t_j).
This keeps the sum set inside a union of a few boxes (small), while the
difference set is a union of many boxes (large), improving the ratio.
We search over the alphabet D and the translation offsets t_j, scoring
candidates exactly (with a size-limited exact scorer).
"""
import math
import random
import time
from itertools import product


def _stats(aset):
    aset = list(set(aset))
    if len(aset) < 2:
        return 0, 0
    dd = len({a - b for a in aset for b in aset})
    ss = len({a + b for a in aset for b in aset})
    return dd, ss


def _score_of(aset, bonus=True):
    dd, ss = _stats(aset)
    if dd < 2 or ss < 2:
        return 0.0
    r = math.log(dd) / math.log(ss)
    if bonus:
        r += (1 - 1 / len(set(aset))) / 100
    return r


def _ddss_alphabet(D, cap_terms=2500):
    """|D-D| and |D+D| for a small alphabet."""
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for a in D})
    return dd, ss


def _box(D, k):
    """All subset sums over alphabet D with k positions, using base B (no carries)."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    if len(D) < 2:
        return [0]
    span = max(D)
    B = 2 * span + 1
    vals = [0]
    for _ in range(k):
        nv = []
        for v in vals:
            for d in D:
                nv.append(v * B + d) if False else nv.append(v + d * (B ** _)) if False else None
        break
    # straightforward build
    vals = [0]
    p = 1
    for _ in range(k):
        nv = []
        for v in vals:
            for d in D:
                nv.append(v + d * p)
        vals = nv
        p *= B
    return sorted(set(vals))


def _build_union(D, k, offsets):
    S = _box(D, k)
    out = set()
    for t in offsets:
        for v in S:
            out.add(v + t)
    return sorted(out)


def _search(deadline):
    """Search alphabet D, box-depth k, and offsets, returning a candidate set."""
    R = 24
    best = [0, 1, 2, 4, 8, 16]
    best_score = _score_of(best)

    # alphabet seeds
    seeds = [[0, 1], [0, 1, 2], [0, 1, 3], [0, 1, 2, 4], [0, 1, 2, 4, 8],
             [0, 1, 3, 7], [0, 1, 2, 4, 8, 16], [0, 1, 2, 3, 4]]
    for sp in seeds:
        s = _score_of(sp)
        if s > best_score:
            best_score, best = s, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 9)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _score_of(D)
        for _ in range(60):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.7 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _score_of(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_score:
            best_score, best = r, D[:]
    return best, best_score


def _choose_k(D, cap):
    s = len(set(D))
    if s < 2:
        return 1
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    return k


def solve():
    deadline = time.time() + 90

    # --- Phase 1: find a good alphabet D ---
    D, dr = _search(min(deadline - 20, time.time() + 40))

    # --- Phase 2: build union-of-translates candidates ---
    best_set = None
    best_val = -1.0

    # Alphabet pool
    alphabets = [D,
                 [0, 1, 2, 4, 8, 16],
                 [0, 1, 2, 4, 8],
                 [0, 1, 3, 7, 15],
                 [0, 1, 2, 4],
                 [0, 1, 2, 3, 4],
                 [0, 1, 3, 4, 9]]

    # For each alphabet, choose k so the box fits within budget,
    # then add several offsets evenly spread across the digit span.
    for Dc in alphabets:
        Dc = sorted(set(Dc))
        if len(Dc) < 2:
            continue
        Dn = [d - min(Dc) for d in Dc]
        span = max(Dn)
        B = 2 * span + 1
        # try a few depths
        for k in range(1, 8):
            if len(Dn) ** k > 2200:
                break
            box = _box(Dn, k)
            if len(box) < 2:
                continue
            box_span = (B ** (k - 1)) * span if k >= 1 else span
            # candidate offsets: spread across the box span
            # use small multiples of the box span so boxes don't overlap much
            for ncopy in (1, 2, 3, 4, 5, 6, 8):
                step = box_span + 1
                offs = [int(j * step) for j in range(ncopy)]
                cand = _build_union(Dn, k, offs)
                if len(cand) > 4000 or len(cand) < 2:
                    continue
                sc = _score_of(cand)
                if sc > best_val:
                    best_val = sc
                    best_set = cand

    # --- Phase 3: local improvement over offsets for the best (D,k) found ---
    # (Reconstruct and slightly tweak offsets.)
    end = time.time() + 10
    if best_set is not None:
        # random small perturbations of the best set's generating offsets
        for Dc in alphabets:
            Dc = sorted(set(Dc))
            if len(Dc) < 2:
                continue
            Dn = [d - min(Dc) for d in Dc]
            span = max(Dn)
            B = 2 * span + 1
            for k in range(1, 8):
                if len(Dn) ** k > 2200:
                    break
                box_span = (B ** (k - 1)) * span if k >= 1 else span
                for _ in range(3):
                    if time.time() > end:
                        break
                    ncopy = random.randint(2, 7)
                    step = box_span + 1
                    offs = sorted(random.sample(range(0, step * ncopy + 1), ncopy))
                    cand = _build_union(Dn, k, offs)
                    if 2 <= len(cand) <= 4000:
                        sc = _score_of(cand)
                        if sc > best_val:
                            best_val = sc
                            best_set = cand

    if best_set is None or len(best_set) < 2:
        best_set = _build_union([0, 1, 2, 4, 8, 16], 2, [0, 1000])

    return list(best_set)
# EVOLVE-BLOCK-END

