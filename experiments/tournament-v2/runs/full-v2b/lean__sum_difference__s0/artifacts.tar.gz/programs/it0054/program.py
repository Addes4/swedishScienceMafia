# EVOLVE-BLOCK-START
"""Construct A as subset sums over a digit alphabet D chosen so that the
realized (not per-digit) ratio log|A-A|/log|A+A| is maximal at full size.

The no-carry product has |A-D differences| = |D-D|^k and |A+A| = |D+D|^k.
So the realized ratio equals log|D-D|/log|D+D| exactly, independent of k.
This is provably optimal for a given D, so the whole game is choosing D.
We use a fast numpy-bitset scorer for |D-D| and |D+D| and search hard.
"""
import math
import random
import time
import numpy as np


def _ddstats(D):
    """Return (|D-D|, |D+D|) using numpy shifts on an integer bitset."""
    D = np.unique(np.asarray(D, dtype=np.int64))
    if D.size < 2:
        return 0, 0
    D = D - D.min()
    span = int(D.max())
    W = span + 1
    words = (2 * W + 63) // 64 + 1
    mask = np.zeros(words, dtype=np.uint64)
    for d in D.tolist():
        mask[d >> 6] |= np.uint64(1) << np.uint64(d & 63)

    def shifted_or(width):
        acc = np.zeros(words, dtype=np.uint64)
        for d in D.tolist():
            sh = d
            wsh, bsh = sh >> 6, sh & 63
            if bsh == 0:
                acc[wsh:wsh + words] |= mask[:words - wsh] if wsh < words else 0
            else:
                src = mask
                piece = np.zeros(words, dtype=np.uint64)
                piece[wsh:wsh + words - wsh] = src[:words - wsh] if wsh < words else 0
                piece <<= np.uint64(bsh)
                if wsh + 1 < words:
                    upper = np.zeros(words, dtype=np.uint64)
                    n = words - (wsh + 1)
                    if n > 0:
                        upper[wsh + 1:wsh + 1 + n] = src[:n]
                    upper >>= np.uint64(64 - bsh)
                    piece |= upper
                acc |= piece
        # count bits
        return int(np.unpackbits(acc.view(np.uint8)).sum())

    dd = shifted_or(2 * W)
    ss = shifted_or(2 * W)
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    R = 40
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32],
                 [0, 1, 4, 9, 15], [0, 1, 3, 8, 17]]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 12)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        for _ in range(300):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.7 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    D = sorted(set(D))
    lo = min(D)
    D = [d - lo for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D)
    B = 2 * span + 1
    # iterative product with rolling array
    vals = [0]
    p = 1
    for _ in range(k):
        vals = [v + d * p for v in vals for d in D]
        p *= B
    return sorted(set(vals))


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    if a.size < 2:
        return 0.0
    dd = len(np.unique(a[:, None] - a[None, :]))
    ss = len(np.unique(a[:, None] + a[None, :]))
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss) + (1 - 1 / a.size) / 100


def solve():
    deadline = time.time() + 55
    D, r = _search_alphabet(deadline)

    candidates = [_build(D)]
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5]):
        candidates.append(_build(sp))
    candidates.append([1, 2, 4, 8, 16, 32, 64, 3, 5, 9, 17, 33])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2 or len(c) > 4000:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c
    return [int(x) for x in best]
# EVOLVE-BLOCK-END
