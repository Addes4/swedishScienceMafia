# EVOLVE-BLOCK-START
"""Constructive + local search for sets with many differences and few sums."""
import math
import random
import time


def _diffs_sums(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score_vals(nd, ns, n):
    if ns < 1 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    nd, ns = _diffs_sums(a)
    return _score_vals(nd, ns, len(a))


def _make_seed(rng, k):
    """Geometric progression: huge difference set, and separate sums mostly.
    Mix scales to try to collapse sums while keeping differences distinct."""
    base = rng.choice([2, 3, 4])
    vals = []
    x = 1
    for i in range(k):
        vals.append(x)
        x *= base
    # add a small arithmetic cluster offset to try to reduce sum distinctness
    off = rng.randint(-2, 2)
    vals = [v + off for v in vals]
    return sorted(set(vals))


def _local(a, rng, deadline, scale):
    """Hill-climb / anneal on the ratio."""
    best = a[:]
    nd, ns = _diffs_sums(best)
    best_s = _score_vals(nd, ns, len(best))
    cur = best[:]
    cur_s = best_s
    while time.time() < deadline:
        cand = cur[:]
        op = rng.random()
        if op < 0.6:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-scale, scale)
        elif op < 0.8:
            if len(cand) < 4000:
                cand.append(rng.randint(-scale, scale) + rng.choice(cand))
        elif op < 0.9:
            if len(cand) > 2:
                cand.pop(rng.randrange(len(cand)))
        else:
            i, j = rng.randrange(len(cand)), rng.randrange(len(cand))
            cand[i], cand[j] = cand[j], cand[i]
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        nd, ns = _diffs_sums(cand)
        s = _score_vals(nd, ns, len(cand))
        if s >= cur_s or rng.random() < 0.02:
            cur, cur_s = cand, s
        if s > best_s:
            best, best_s = cand[:], s
    return best, best_s


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_s = _score(best)

    attempts = 0
    while time.time() < deadline - 1:
        k = rng.randint(6, 200)
        seed = _make_seed(rng, k) if rng.random() < 0.5 else [
            rng.randint(-50, 50) for _ in range(k)
        ]
        seed = sorted(set(seed))
        if len(seed) < 2:
            continue
        # allocate a slice of time to this local search
        sub_deadline = min(time.time() + rng.uniform(1, 4), deadline)
        a, s = _local(seed, rng, sub_deadline, rng.choice([1, 2, 5, 20]))
        if s > best_s:
            best, best_s = a, s
        attempts += 1
    return sorted(set(best))
# EVOLVE-BLOCK-END
