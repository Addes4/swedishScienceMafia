# EVOLVE-BLOCK-START
"""Construct A as a union of a long arithmetic progression (few sums) with a
difference-rich perturbation, then refine with exact-score local search."""
import math
import random
import time


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def _score_only(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _greedy_search(seed, deadline):
    """Greedy: try to add an element maximizing score, then local swaps."""
    cur = sorted(set(seed))
    best = cur[:]
    best_s = _score_only(cur)
    # grow
    while time.time() < deadline and len(cur) < 4000:
        base_s = _score_only(cur)
        top = base_s
        top_x = None
        span = max(cur) - min(cur)
        step = max(1, span // (len(cur) + 1))
        for _ in range(60):
            x = random.choice(cur) + random.randint(-step, step) * random.choice([1, 2, 3])
            if x in cur:
                continue
            s = _score_only(cur + [x])
            if s > top:
                top = s
                top_x = x
        if top_x is None:
            break
        cur = sorted(cur + [top_x])
        if top > best_s:
            best_s = top
            best = cur[:]
    return best, best_s


def solve():
    deadline = time.time() + 60
    # Family 1: {0..k-1} plus scaled copy: A = [0,k) U {k + i*m : i in [0,m)}
    best = None
    best_s = -1.0
    # geometric powers with perturbing tail (Conway/Behrend-like).
    for log2B in [3, 4, 5, 6, 7, 8]:
        for n in range(3, 9):
            B = 2 ** log2B
            base = [B ** i for i in range(n)]
            # add small offsets
            for trial in range(3):
                cand = list(base)
                for i in range(n):
                    cand[i] += random.randint(0, B // 2)
                s = _score_only(cand)
                if s > best_s:
                    best_s = s
                    best = cand[:]
    # Family 2: interval union construction with intentionally small sumset.
    for k in [8, 10, 12, 16, 20, 24, 32]:
        for m in [2, 3, 4, 5]:
            for gap in [k, 2 * k, 4 * k, 8 * k]:
                A = list(range(k)) + [gap * m + i for i in range(m)]
                s = _score_only(A)
                if s > best_s:
                    best_s = s
                    best = A[:]
    # Refine the best by greedy.
    if best is None:
        best = list(range(4, 20))
    refined, rs = _greedy_search(best, time.time() + 50)
    if rs > best_s:
        best, best_s = refined, rs
    return sorted(set(best))
# EVOLVE-BLOCK-END
