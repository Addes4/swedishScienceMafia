# EVOLVE-BLOCK-START
"""Search for A with large |A-A|, small |A+A| via exact-score annealing with geometric seeds."""
import math
import random
import time


def _score_parts(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    val = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return val, len(diffs), len(sums)


def _score(a):
    return _score_parts(a)[0]


def _geom(base, n):
    return [base ** i for i in range(n)]


def solve():
    random.seed(12345)
    deadline = time.time() + 115

    # Seed pool: geometric progressions over many bases/lengths + small random sets
    seeds = []
    for base in range(2, 12):
        for n in range(3, 12):
            v = base ** (n - 1)
            if v <= 10**15:
                seeds.append(_geom(base, n))
    # dense intervals of odd-ish integers (sum-poor-ish)
    for n in range(4, 10):
        for step in range(1, 5):
            seeds.append([i * step for i in range(n)])

    best = None
    best_score = -1.0
    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score = sc
            best = s[:]

    # Exact-score simulated annealing with restarts
    cur = best[:]
    cur_score = best_score
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        r = random.random()
        if r < 0.45 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2, -3, 3,
                                      random.randint(-100, 100)])
        elif r < 0.7:
            # add element
            if cand:
                m = max(cand)
                cand.append(m + random.randint(1, 50))
            else:
                cand.append(random.randint(1, 10))
        elif r < 0.9:
            # remove element
            if len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
        else:
            # shift all
            d = random.randint(-30, 30)
            cand = [x + d for x in cand]

        cand = list(set(cand))
        if len(cand) > 25:
            cand = sorted(cand)[:25]
        if len(cand) < 2:
            continue
        sc = _score(cand)
        T = 0.02
        if sc >= cur_score or random.random() < math.exp((sc - cur_score) / max(T, 1e-6)):
            cur = cand
            cur_score = sc
            if sc > best_score:
                best = cand[:]
                best_score = sc
                cur = best[:]
                cur_score = best_score
        # periodic restart from best with perturbation
        if it % 4000 == 0:
            cur = best[:]
            for _ in range(random.randint(1, 3)):
                if cur:
                    i = random.randrange(len(cur))
                    cur[i] += random.randint(-20, 20)
            cur = list(set(cur))
            cur_score = _score(cur)

    return sorted(set(best))
# EVOLVE-BLOCK-END
