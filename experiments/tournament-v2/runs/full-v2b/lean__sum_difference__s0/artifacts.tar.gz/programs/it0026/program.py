# EVOLVE-BLOCK-START
"""Simulated annealing on exact sum/difference set ratio."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    al = list(a)
    for x in al:
        for y in al:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _seed():
    # multi-block digit construction: digits in [0,k) at a few well separated scales
    best = None
    best_s = -1
    for k in (2, 3, 4, 5, 6, 7, 8):
        for m in (2, 3, 4, 5):
            B = max(2 * k, 3)
            a = []
            for idx in range(k ** m):
                x = idx
                v = 0
                p = 1
                for _ in range(m):
                    v += (x % k) * p
                    x //= k
                    p *= B
                a.append(v)
            if len(a) > 200:
                continue
            s = _score(a)
            if s > best_s:
                best_s = s
                best = a
    # small good known set
    alt = [7, 15, 18, 22, -3, -2]
    if _score(alt) > best_s:
        best, best_s = alt, _score(alt)
    return best


def solve():
    random.seed(12345)
    best = _seed()
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score

    deadline = time.time() + 115
    T = 0.05
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.55:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-2, 2) * random.choice([1, 1, 1, 5, 25])
        elif r < 0.75 and len(cand) < 300:
            cand.append(random.randint(-50, max(50, max(cand, default=1) + 50)))
        elif r < 0.9 and len(cand) > 3:
            del cand[random.randrange(len(cand))]
        else:
            i = random.randrange(len(cand))
            cand[i] = random.randint(-60, 1200)
        cand = sorted(set(cand))
        s = _score(cand)
        if s >= cur_score or random.random() < math.exp((s - cur_score) / T):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        T *= 0.99995
        if T < 0.0005:
            T = 0.02
            cur, cur_score = best[:], best_score
    return best
# EVOLVE-BLOCK-END

