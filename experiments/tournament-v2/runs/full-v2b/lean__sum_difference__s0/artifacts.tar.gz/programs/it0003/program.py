# EVOLVE-BLOCK-START
"""Anneal over integer sets, seeded by geometric progressions (large |A-A|, smallish |A+A|)."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
            diffs.add(ai - a[j])
            diffs.add(a[j] - ai)
    ls = len(sums)
    if ls <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(ls) + (1 - 1 / n) / 100


def _seed():
    seeds = []
    # geometric progressions with various bases
    for b in (2, 3, 4, 5):
        for k in (12, 18, 24, 30, 40):
            if b ** (k - 1) < 10 ** 14:
                seeds.append([b ** i for i in range(k)])
    # mixed: geometric plus a small arithmetic cluster
    for b in (3, 4):
        base = [b ** i for i in range(20)]
        seeds.append(base + [base[-1] + d for d in range(1, 8)])
    # near-Sidon-ish random small
    seeds.append([9, 14, 22, 31, 44, 60, 89, 120, 165, 220, 300])
    return seeds


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    seeds = _seed()
    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    # local search / annealing
    for s in seeds:
        if time.time() > deadline:
            break
        cur = list(set(s))
        cur_score = _score(cur)
        T = 0.02
        step_scale = max(1, int(max(abs(x) for x in cur) ** 0.5) // 50 + 1)
        it = 0
        while time.time() < deadline:
            it += 1
            cand = cur[:]
            op = random.random()
            if op < 0.7:
                i = random.randrange(len(cand))
                delta = random.randint(-step_scale, step_scale)
                if delta == 0:
                    delta = 1
                cand[i] += delta
            elif op < 0.85 and len(cand) < 60:
                cand.append(random.choice([e for e in cand]) + random.randint(-step_scale, step_scale))
            elif len(cand) > 4:
                del cand[random.randrange(len(cand))]
            cand = list(set(cand))
            cs = _score(cand)
            if cs >= cur_score or random.random() < math.exp((cs - cur_score) / max(T, 1e-6)):
                cur, cur_score = cand, cs
                if cs > best_score:
                    best_score, best = cs, cand[:]
            if it % 4000 == 0:
                T *= 0.9
                if T < 1e-4:
                    T = 0.02
        # also try trimming / extending the best at the nd
    if best is None:
        best = [1, 2, 4]
    return sorted(set(best))
# EVOLVE-BLOCK-END
