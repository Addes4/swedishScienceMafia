# EVOLVE-BLOCK-START
"""Digit-restricted construction + exact-score greedy refinement."""
import math
import random
import time


def _score_len(nA, nD, nS):
    if nA < 2 or nS < 2 or nD < 1:
        return 0.0
    return math.log(nD) / math.log(nS) + (1 - 1 / nA) / 100


def _exact(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return _score_len(n, len(diffs), len(sums))


def _digit_set(b, digits, length):
    """All numbers with `length` base-b digits chosen from `digits` (leading allowed zero)."""
    res = [0]
    for _ in range(length):
        new = []
        for x in res:
            for d in digits:
                new.append(x * b + d)
        res = new
    return list(set(res))


def solve():
    best = None
    best_score = -1.0

    # Phase 1: scan digit-restricted constructions.
    for b in (2, 3, 4, 5, 7):
        for length in range(2, 9):
            if b ** length > 10**13:
                continue
            # try several digit subsets
            subsets = []
            subsets.append(list(range(b)))            # full: too many sums, skip-ish
            subsets.append(list(range(b - 1)))         # drop top digit
            subsets.append(list(range(1, b)))          # drop 0
            subsets.append([0, 1] if b > 2 else [0, 1])
            subsets.append(list(range(b))[::2])        # even digits
            subsets.append(list(range(b))[1::2])       # odd digits
            for digits in subsets:
                if len(digits) < 2:
                    continue
                try:
                    A = _digit_set(b, digits, length)
                except Exception:
                    continue
                if len(A) < 2 or len(A) > 4000:
                    continue
                if max(abs(x) for x in A) > 10**15:
                    continue
                s = _exact(A)
                if s > best_score:
                    best_score = s
                    best = sorted(A)

    if best is None:
        best = [0, 1, 2]
        best_score = _exact(best)

    best = sorted(set(best))

    # Phase 2: greedy add/remove refinement using exact score within budget.
    deadline = time.time() + 100.0
    cur = best[:]
    cur_score = _exact(cur)

    # candidate pool for insertion (small integers around existing range)
    lo = min(cur) - 64
    hi = max(cur) + 64
    pool = list(range(lo, hi + 1))

    improved = True
    while time.time() < deadline and improved:
        improved = False
        # try removals
        for i in range(len(cur)):
            cand = cur[:i] + cur[i + 1:]
            if len(cand) < 2:
                continue
            s = _exact(cand)
            if s > cur_score:
                cur, cur_score = cand, s
                improved = True
                break
        if improved:
            continue
        # try insertions
        cs = set(cur)
        random.shuffle(pool)
        for x in pool:
            if x in cs:
                continue
            cand = cur + [x]
            if len(cand) > 4000:
                continue
            s = _exact(cand)
            if s > cur_score:
                cur.append(x)
                cs.add(x)
                cur_score = s
                improved = True
                break

    if cur_score > best_score:
        best = sorted(set(cur))

    return sorted(set(best))
# EVOLVE-BLOCK-END
