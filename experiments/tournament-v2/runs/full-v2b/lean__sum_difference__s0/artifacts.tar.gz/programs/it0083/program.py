# EVOLVE-BLOCK-START
"""Construct A as carry-free digit-vectors over a tuned alphabet D.

For A = { sum_i d_i B^i : d_i in D } with B large enough to avoid carries,
    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k
so the objective is exactly log|D-D|/log|D+D|, independent of k.  Mixing
alphabets only yields a weighted average of these ratios, so the only lever
is to find the single best alphabet D.  We do a strong numpy-vectorized
simulated annealing over alphabets of size 6..13 over a wide integer range,
then replicate D (largest k with |D|^k <= 4000) for the size bonus.
"""
import math
import random
import time
from itertools import product

import numpy as np


def _ddstats_np(Darr):
    """(|D-D|, |D+D|) using numpy."""
    D = np.asarray(sorted(set(int(x) for x in Darr)), dtype=np.int64)
    if D.size < 2:
        return 0, 0
    dd = np.unique(D[:, None] - D[None, :]).size
    ss = np.unique(D[:, None] + D[None, :]).size
    return int(dd), int(ss)


def _ratio_np(Darr):
    dd, ss = _ddstats_np(Darr)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Simulated annealing over integer alphabets D maximizing the ratio."""
    R = 128
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio_np(best_D)

    seed_pool = [
        [0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8, 16, 32],
        [0, 1, 2, 4, 8, 16, 32, 64], [0, 1, 3, 7, 15, 31],
        [0, 1, 2, 4], [0, 1, 3, 7, 15], [0, 1, 2, 3, 5, 8, 13, 21, 34],
    ]
    for sp in seed_pool:
        r = _ratio_np(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(6, 13)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio_np(D)
        T = 0.02
        steps = 0
        while time.time() < deadline and steps < 600:
            steps += 1
            T = max(0.0005, T * 0.997)
            cand = D[:]
            op = random.random()
            if op < 0.6 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.78:
                cand.append(random.randint(0, R))
            elif op < 0.9 and len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            else:
                # shift entire set
                sh = random.randint(-8, 8)
                cand = [x + sh for x in cand]
            cand = sorted(set(cand))
            if len(cand) < 2 or len(cand) > 40:
                continue
            cr = _ratio_np(cand)
            if cr >= r or random.random() < math.exp((cr - r) / T):
                D, r = cand, cr
            if r > best_r:
                best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    """Subset-sum product set from alphabet D, largest size <= cap, carry-free."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    deadline = time.time() + 70
    D, r = _search_alphabet(deadline)

    candidates = [_build(D)]
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8, 16, 32],
               [0, 1, 2, 4, 8], [0, 1, 3, 7, 15], [0, 1, 2, 4],
               [0, 1, 2, 3, 5, 8, 13], [0, 1, 2, 3, 4, 5]):
        candidates.append(_build(sp))

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
