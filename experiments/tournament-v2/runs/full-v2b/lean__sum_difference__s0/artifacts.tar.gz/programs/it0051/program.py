# EVOLVE-BLOCK-START
"""Construct A as a base-B subset-sum set with a tuned digit alphabet D.

If A = { sum_{i<k} d_i B^i : d_i in D } and B > 2*span(D) so no digit carries
occur, then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so log|A-A|/log|A+A| equals log|D-D|/log|D+D|, independent of k.  We therefore
search hard for a small integer alphabet D maximizing that ratio, then realise
it at the largest feasible k for the size bonus.  A numpy boolean-bitset scorer
makes the alphabet search fast enough for simulated annealing.
"""
import math
import random
import time
from itertools import product

import numpy as np


def _ddstats_np(D):
    """|D-D| and |D+D| for a small integer set D, via numpy boolean bitsets."""
    D = np.unique(np.asarray(D, dtype=np.int64))
    m = int(D.min())
    d = D - m
    span = int(d.max())
    size = 2 * span + 1

    # differences: shift-OR a boolean mask by each element
    mask = np.zeros(size, dtype=bool)
    mask[d] = True
    acc = mask.copy()
    for v in d:
        s = int(v)
        if s == 0:
            continue
        shifted = np.zeros(size, dtype=bool)
        if s < size:
            shifted[s:] = mask[:size - s] if s > 0 else mask
        acc |= shifted
    dd = int(acc.sum())

    # sums: shift-OR a boolean mask by each element, offsets into 0..2*span
    mask2 = np.zeros(2 * span + 1, dtype=bool)
    mask2[d] = True
    acc2 = np.zeros(2 * span + 1, dtype=bool)
    for v in d:
        s = int(v)
        sh = np.zeros(2 * span + 1, dtype=bool)
        if s <= 2 * span:
            sh[s:] = mask2[:2 * span + 1 - s] if s > 0 else mask2
        acc2 |= sh
    ss = int(acc2.sum())
    return dd, ss


def _ratio_np(D):
    dd, ss = _ddstats_np(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Simulated-annealing search over small integer alphabets D."""
    best_D = [0, 1, 3]
    best_r = _ratio_np(best_D)

    seeds = [
        [0, 1], [0, 1, 3], [0, 1, 3, 7], [0, 1, 3, 7, 15], [0, 1, 3, 7, 15, 31],
        [0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8, 16, 32],
        [0, 1, 3, 7, 15], [0, 1, 2, 4], [0, 1, 2, 4, 8],
    ]
    for sp in seeds:
        r = _ratio_np(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    R = 40
    while time.time() < deadline:
        s = random.randint(2, 14)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio_np(D)
        T = 0.02
        for _ in range(600):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.65 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.82:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio_np(cand)
            if cr >= r or random.random() < math.exp((cr - r) / max(T, 1e-9)):
                D, r = cand, cr
            T *= 0.997
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    """Product set (subset sums) from alphabet D, largest size <= cap, no carries."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    deadline = time.time() + 55
    D, r = _search_alphabet(deadline)

    candidates = []
    candidates.append(_build(D))
    for sp in ([0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8],
               [0, 1, 3, 7], [0, 1, 2, 4], [0, 1, 2, 3, 4, 5]):
        candidates.append(_build(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
