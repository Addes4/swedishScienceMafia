# EVOLVE-BLOCK-START
"""Simulated annealing over integer sets maximizing log|A-A| / log|A+A|."""
import math
import random
import time

import numpy as np


def _score(arr):
    n = len(arr)
    if n < 2:
        return -1.0
    a = np.asarray(arr, dtype=np.int64)
    d = np.unique(a[:, None] - a[None, :])
    s = np.unique(a[:, None] + a[None, :])
    if len(s) < 2:
        return -1.0
    return math.log(len(d)) / math.log(len(s)) + (1.0 - 1.0 / n) / 100.0


def _digit_seed(k, base):
    vals = []
    for mask in range(1, 1 << k):
        v = 0
        p = 1
        for i in range(k):
            if mask >> i & 1:
                v += p
            p *= base
        vals.append(v)
    return vals


def solve():
    rng = random.Random(20240517)
    np.random.seed(20240517)
    deadline = time.time() + 110.0

    seeds = [
        [7, 15, 18, 22, -3, -2],
        [0, 1, 3, 4, 9, 10, 12, 13],
        [0, 1, 3, 4, 9, 10, 12, 13, 27, 28, 30, 31],
    ]
    for k in (7, 8, 9, 10):
        for base in (3, 4, 5, 7, 11):
            if 1 << k <= 900:
                seeds.append(_digit_seed(k, base))

    best = None
    best_sc = -1.0

    # a pool of candidate magnitudes to grow the set with
    def random_val(cur):
        base = rng.choice(cur) if cur else 0
        span = 1
        for _ in range(rng.randint(0, 6)):
            span *= rng.choice([2, 3, 5, 7, 11])
        return base + rng.randint(-span, span) * rng.choice([1, 2, 5])

    restart = 0
    while time.time() < deadline:
        if seeds:
            cur = [int(x) for x in seeds.pop()]
        else:
            cur = [int(x) for x in (best if best is not None else seeds[0])]
            if rng.random() < 0.3 and best is not None:
                # random perturbation restart
                cur = best[:]
                for _ in range(rng.randint(1, 3)):
                    if cur:
                        i = rng.randrange(len(cur))
                        cur[i] += rng.randint(-1000, 1000)

        cur = sorted(set(cur))
        cur_sc = _score(cur)
        # adaptive step
        T = 0.02
        step = 64

        local_best = cur[:]
        local_best_sc = cur_sc

        it = 0
        stall = 0
        while time.time() < deadline and it < 100000:
            it += 1
            cand = cur[:]
            r = rng.random()
            if r < 0.55 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-step, step)
            elif r < 0.75 and len(cand) < 60:
                cand.append(random_val(cand))
            elif r < 0.95 and len(cand) > 3:
                del cand[rng.randrange(len(cand))]
            elif cand:
                i = rng.randrange(len(cand))
                cand[i] = random_val(cand)

            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            sc = _score(cand)

            delta = sc - cur_sc
            if delta >= 0 or rng.random() < math.exp(delta / max(T, 1e-6)):
                cur, cur_sc = cand, sc
                if sc > local_best_sc:
                    local_best, local_best_sc = cand[:], sc
                    stall = 0
                else:
                    stall += 1

            if stall > 400 and step > 1:
                step = max(1, step // 2)
                stall = 0
            if it % 2000 == 0:
                T *= 0.97
                if T < 1e-4:
                    T = 0.02
                    step = 64

        if local_best_sc > best_sc:
            best, best_sc = local_best[:], local_best_sc
        restart += 1

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
