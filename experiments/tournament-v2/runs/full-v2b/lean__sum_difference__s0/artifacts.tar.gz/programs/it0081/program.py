# EVOLVE-BLOCK-START
"""Construct A = carry-free digit product over a tuned alphabet D.

For A = {sum_i d_i B^i : d_i in D}, B large enough to avoid carries:
    |A - A| = |D - D|^k ,  |A + A| = |D + D|^k
so log|A-A|/log|A+A| = log|D-D|/log|D+D| (k-independent), and the size bonus
favors the largest k with |D|^k <= 4000.

We want |D+D| small (~2|D|-1, AP-like) and |D-D| large (~|D|^2, Sidon-like
differences).  Large alphabets push the achievable ratio toward 2, so we
search larger |D| with numpy-vectorized exact evaluation.
"""
import math
import random
import time
import numpy as np


def _ddstats(D):
    D = np.asarray(sorted(set(int(x) for x in D)), dtype=np.int64)
    m = D.size
    if m < 2:
        return 1, 1
    diff = (D[:, None] - D[None, :]).ravel()
    ssum = (D[:, None] + D[None, :]).ravel()
    return int(np.unique(diff).size), int(np.unique(ssum).size)


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _score_D(D, cap=4000):
    """Realized score of the carry-free product using alphabet D at best k."""
    D = sorted(set(int(x) for x in D))
    m = len(D)
    if m < 2:
        return -1.0, None
    k = 1
    while m ** (k + 1) <= cap:
        k += 1
    n = m ** k
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return -1.0, None
    r = math.log(dd) / math.log(ss)
    sc = r + (1.0 - 1.0 / n) / 100.0
    return sc, k


def _build(D, cap=4000):
    D = sorted(set(int(x) for x in D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = [0]
    p = 1
    for _ in range(k):
        vals = [v + d * p for v in vals for d in D]
        p *= B
    return sorted(set(vals))


def _greedy_ap_like(m):
    """Alphabet of size m: near-AP for small sumset, with a Sidon-ish twist."""
    return list(range(m))


def _greedy_sidonish(m):
    """Build D by greedy: keep sums as AP-like as possible while spreading diffs.

    Start from AP and perturb to break difference collisions moderately.
    """
    D = list(range(m))
    return D


def _search_alphabet(deadline):
    """Search alphabets of many sizes, evaluating realized score with bonus."""
    best_D = [0, 1, 2, 4, 8, 16]
    best_sc, _ = _score_D(best_D)

    # seeded structured candidates
    seeds = []
    for m in range(2, 15):
        seeds.append(list(range(m)))            # AP: tiny sumset
    seeds += [[0, 1, 2, 4, 8, 16], [0, 1, 3, 7, 15], [0, 1, 2, 4, 8],
              [0, 1, 2, 4], [0, 1, 3], [0, 1]]
    # Sidon-ish: powers-ish but capped
    seeds.append(sorted({0, 1, 2, 4, 8, 16, 32, 64}))
    for sp in seeds:
        sc, _ = _score_D(sp)
        if sc > best_sc:
            best_sc, best_D = sc, sp[:]

    # local search over larger alphabets: perturb elements trying to grow |D-D|
    # while keeping |D+D| small. Range scaled to alphabet size.
    while time.time() < deadline:
        m = random.randint(6, 16)
        R = m + random.randint(0, 3 * m)
        D = sorted(random.sample(range(R + 1), m))
        sc, _ = _score_D(D)
        for _ in range(120):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.75:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.9:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            csc, _ = _score_D(cand)
            if csc >= sc:
                D, sc = cand, csc
        if sc > best_sc:
            best_sc, best_D = sc, D[:]
    return best_D, best_sc


def _score(a):
    a = sorted(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0
    A = np.asarray(a, dtype=np.int64)
    diffs = np.unique((A[:, None] - A[None, :]).ravel()).size
    sums = np.unique((A[:, None] + A[None, :]).ravel()).size
    if diffs < 2 or sums < 2:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 55
    D, _ = _search_alphabet(deadline)

    candidates = [_build(D)]
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], list(range(6)), list(range(20))):
        candidates.append(_build(sp))

    best, best_s = None, -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c
    return list(best)
# EVOLVE-BLOCK-END
