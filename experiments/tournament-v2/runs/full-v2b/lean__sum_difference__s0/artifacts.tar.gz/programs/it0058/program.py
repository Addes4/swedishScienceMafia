# EVOLVE-BLOCK-START
"""Construct A to maximize log|A-A|/log|A+A|.

Primary construction: no-carry base-B product over a tuned digit alphabet D
gives |A-A|=|D-D|^k and |A+A|=|D+D|^k.  This plateaus on per-digit ratio.
We additionally try structured "sum-box" constructions: take a large
box-like set B0 (subset sums of a dense digit set) whose sum set is a single
interval/box, then A = B0  U  (B0 + s) for several shifts s.  Differences grow
roughly linearly with the number of shifts times the box size, while the sum
set stays a modest union of boxes.
"""
import math
import random
import time
from itertools import product


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    R = 34
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32],
                 [0, 1, 2, 3, 5, 8, 13, 21], [0, 1, 2, 4, 8, 16, 32, 64]]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 14)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        for _ in range(400):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.7 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _build_box(cap=4000):
    """Subset sums over a dense prefix alphabet -> interval-like box."""
    D = [0, 1, 2, 3, 4, 5]
    return _build(D, cap)


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _multi_shift(base, shifts):
    """Union of base shifted by each shift."""
    a = set()
    for s in shifts:
        for v in base:
            a.add(v + s)
    return list(a)


def _search_multi(base, cap, deadline):
    """Greedily (randomly) choose shifts to maximize realized score."""
    base = sorted(set(base))
    span = max(base) - min(base)
    step = span + 1
    best = list(base)
    best_s = _score(best)
    m = len(base)
    max_copies = max(1, cap // max(1, m))
    while time.time() < deadline:
        n_copies = random.randint(1, min(max_copies, 12))
        shifts = [0]
        for _ in range(n_copies - 1):
            shifts.append(random.randint(1, 40) * step)
        cand = _multi_shift(base, shifts)
        if len(cand) > cap:
            continue
        sc = _score(cand)
        if sc > best_s:
            best_s, best = sc, cand[:]
    return best, best_s


def solve():
    deadline = time.time() + 55
    D, r = _search_alphabet(deadline) if time.time() < deadline else ([0, 1, 2, 4, 8, 16], 0.0)

    candidates = []
    candidates.append(_build(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5]):
        candidates.append(_build(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    # multi-shift refinement of the best small box core
    core = _build_box(2000)
    d2 = time.time() + 15
    ms, msc = _search_multi(core, 4000, d2)
    if msc > best_s:
        best_s, best = msc, ms

    return list(best)
# EVOLVE-BLOCK-END
