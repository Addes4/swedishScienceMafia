# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a digit alphabet D.

If A = { sum_i d_i B^i : d_i in D } with B large enough that no two digit-vectors
collide (no carries), then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so log|A-A|/log|A+A| = log|D-D|/log|D+D|, independent of k. We look for a small
integer alphabet D maximizing log|D-D|/log|D+D|, then replicate it (largest k
with |D|^k <= 4000) for the size bonus.
"""
import math
import random
import time
from itertools import product

import numpy as np


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Fast hill-climb over small integer alphabets D."""
    R = 30
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32],
                 [0, 1, 2, 3, 6, 12, 24], [0, 1, 4, 9, 16]]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    it = 0
    while time.time() < deadline:
        it += 1
        s = random.randint(2, 10)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        for _ in range(200):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.7 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    """Build carry-free product set from alphabet D, largest size <= cap."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _score_np(a):
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    if diffs.size < 2 or sums.size < 2:
        return 0.0
    return math.log(diffs.size) / math.log(sums.size) + (1 - 1 / n) / 100.0


def solve():
    deadline = time.time() + 55
    D, r = _search_alphabet(deadline)

    candidates = []
    candidates.append(_build(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5], [0, 1, 2, 4, 8, 16, 32]):
        candidates.append(_build(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score_np(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
