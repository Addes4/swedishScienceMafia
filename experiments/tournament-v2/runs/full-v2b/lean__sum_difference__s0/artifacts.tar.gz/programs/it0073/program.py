# EVOLVE-BLOCK-START
"""Construct A = subset-sums over a tuned digit alphabet D.

If A = { sum_i d_i B^i : d_i in D } with B > 2*(max D - min D) (no carries), then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so the objective log|A-A|/log|A+A| = log|D-D|/log|D+D| depends only on D.
Hence we search hard for a small integer alphabet D maximizing
log|D-D|/log|D+D|, then replicate it (largest k with |D|^k <= 4000) for the size bonus.
"""
import math
import random
import time
from itertools import combinations, product

import numpy as np


def _ratio_fast(D):
    """log|D-D|/log|D+D| for a (small) integer set D, using numpy."""
    D = np.unique(np.asarray(D, dtype=np.int64))
    m = len(D)
    if m < 2:
        return 0.0
    dd = len(np.unique(D[:, None] - D[None, :]))
    ss = len(np.unique(D[:, None] + D[None, :]))
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _exhaustive(best, deadline):
    """Check all small alphabets in a small range."""
    R = 20
    for size in range(2, 8):
        if time.time() >= deadline:
            return best
        for comb in combinations(range(R + 1), size):
            r = _ratio_fast(comb)
            if r > best[1]:
                best = (list(comb), r)
        if time.time() >= deadline:
            return best
    return best


def _sa_search(best, deadline):
    """Simulated-annealing over integer alphabets, many restarts."""
    R = 40
    seed_pool = [
        [0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8, 16, 32], [0, 1, 3, 7, 15],
        [0, 1, 2, 4, 8], [0, 1, 3, 6, 10], [0, 1, 2, 5, 10, 20],
        [0, 1, 4, 9, 16, 25], [0, 1, 2, 3, 4, 5, 6], [0, 1, 2, 4, 7, 11, 16],
    ]
    for sp in seed_pool:
        r = _ratio_fast(sp)
        if r > best[1]:
            best = (sp[:], r)

    while time.time() < deadline:
        sz = random.randint(4, 13)
        D = sorted(random.sample(range(R + 1), sz))
        r = _ratio_fast(D)
        T = 0.02
        for it in range(3000):
            if (it & 63) == 0 and time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.65 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.83:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio_fast(cand)
            if cr >= r or random.random() < math.exp((cr - r) / max(T, 1e-9)):
                D, r = cand, cr
            if r > best[1]:
                best = (D[:], r)
            T *= 0.9995
        if r > best[1]:
            best = (D[:], r)
    return best


def _build(D, cap=4000):
    """Build the carry-free product set from alphabet D, largest size <= cap."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _estimate(D):
    """Estimated full score = alphabet ratio + size bonus (identity is exact)."""
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    if dd < 2 or ss < 2:
        return 0.0
    A = _build(D)
    if len(A) < 2:
        return 0.0
    return math.log(dd) / math.log(ss) + (1 - 1 / len(A)) / 100


def solve():
    start = time.time()
    deadline = start + 100

    best = ([0, 1, 2, 4, 8, 16], _ratio_fast([0, 1, 2, 4, 8, 16]))
    best = _exhaustive(best, deadline)
    best = _sa_search(best, deadline)

    # Build candidates from the best alphabet and a few structured fallbacks,
    # selecting the one with the highest estimated (== exact) full score.
    cands = [best[0]]
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8, 16, 32], [0, 1, 3, 7, 15],
               [0, 1, 2, 4, 8], [0, 1, 3, 6, 10], [0, 1, 2, 5, 10, 20]):
        cands.append(sp)

    bestA = None
    best_s = -1.0
    for D in cands:
        A = _build(D)
        if len(A) < 2:
            continue
        try:
            sc = _estimate(D)
        except Exception:
            sc = 0.0
        if sc > best_s:
            best_s, bestA = sc, A

    return list(bestA)
# EVOLVE-BLOCK-END
