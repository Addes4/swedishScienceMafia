# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a tuned digit alphabet D.

If A = { sum_i d_i B^i : d_i in D } with B large enough that no two digit-vectors
collide (no carries), then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so the objective log|A-A|/log|A+A| = log|D-D|/log|D+D| is independent of k.
We only need a small integer alphabet D maximizing log|D-D|/log|D+D|, then
replicate it (largest k with |D|^k <= 4000) for the size bonus.

We use numpy boolean bitsets (shift-OR) to evaluate |D-D| and |D+D| exactly and
fast, enabling many more search iterations and larger alphabets.
"""
import math
import random
import time
from itertools import product

import numpy as np


def _ddstats(D):
    """Return (|D-D|, |D+D|) for a (small) integer set D using bitset shift-OR."""
    if len(D) < 2:
        return 0, 0
    D = sorted(set(D))
    mn = D[0]
    vals = [d - mn for d in D]
    span = vals[-1]
    # difference values live in [-span, span]; sums in [0, 2*span]
    dsize = 2 * span + 1
    ssize = 2 * span + 1
    # bitsets: bit i set => value (i + offset) present
    d_bits = np.zeros(dsize, dtype=np.bool_)
    s_bits = np.zeros(ssize, dtype=np.bool_)
    d_off = span
    for a in vals:
        for b in vals:
            d_bits[a - b + d_off] = True
            s_bits[a + b] = True
    return int(d_bits.sum()), int(s_bits.sum())


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    """Hill-climb over small integer alphabets D, maximizing log|D-D|/log|D+D|."""
    R = 60
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32],
                 [0, 1, 3, 9, 27], [0, 1, 2, 5, 13]]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 16)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        # steepest-ascent style local search
        for _ in range(600):
            if time.time() >= deadline:
                break
            improved = False
            # try single-element changes and small additions
            trials = []
            if D:
                for _ in range(6):
                    i = random.randrange(len(D))
                    cand = D[:]
                    cand[i] = random.randint(0, R)
                    trials.append(cand)
            for _ in range(3):
                trials.append(D + [random.randint(0, R)])
            if len(D) > 2:
                cand = D[:]
                cand.pop(random.randrange(len(cand)))
                trials.append(cand)
            # also global reseed occasionally
            for cand in trials:
                cand = sorted(set(cand))
                if len(cand) < 2:
                    continue
                cr = _ratio(cand)
                if cr > r:
                    D, r = cand, cr
                    improved = True
                    break
            if not improved:
                # random kick
                if random.random() < 0.3:
                    break
                cand = D[:]
                if cand:
                    cand[random.randrange(len(cand))] = random.randint(0, R)
                cand = sorted(set(cand))
                if len(cand) >= 2:
                    D, r = cand, _ratio(cand)
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    """Build the product set (subset sums) from alphabet D, largest size <= cap."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]          # normalize to start at 0
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1                     # no carries between digit positions
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    deadline = time.time() + 55
    D, r = _search_alphabet(deadline)

    candidates = []
    # product from best alphabet
    candidates.append(_build(D))
    # products from a few known structured alphabets as fallback
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5]):
        candidates.append(_build(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
