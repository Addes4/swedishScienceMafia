# EVOLVE-BLOCK-START
"""Geometric-progression seeded annealing for large |A-A| and small |A+A|."""
import math
import random
import time


def _score_layout(a):
    # a is a list of distinct ints
    n = len(a)
    if n < 2:
        return -1.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    if ls < 2:
        return -1.0, ld, ls
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100, ld, ls


def solve():
    random.seed(12345)
    deadline = time.time() + 115

    best_overall = None
    best_score = -2.0

    # candidate bases for geometric progressions
    bases = [2, 3, 4, 5, 6, 7]

    def make_geo(base, k, start=1):
        return [start * (base ** i) for i in range(k)]

    # try geometric seeds of various sizes/bases
    seeds = []
    for base in bases:
        for k in range(3, 12):
            try:
                g = make_geo(base, k)
            except OverflowError:
                break
            if all(abs(v) <= 10**15 for v in g):
                seeds.append(g)
    random.shuffle(seeds)

    for seed in seeds:
        if time.time() > deadline:
            break
        cur = seed[:]
        cs, _, _ = _score_layout(cur)
        # anneal
        T = 0.5
        local_deadline = min(deadline, time.time() + 12)
        while time.time() < local_deadline:
            cand = cur[:]
            op = random.random()
            if op < 0.65 or len(cand) < 3:
                # perturb one element by scaling / small nudge
                i = random.randrange(len(cand))
                r = random.random()
                if r < 0.5:
                    cand[i] = cand[i] + random.randint(-3, 3)
                elif r < 0.8:
                    cand[i] = cand[i] * random.choice([2, 3])
                else:
                    cand[i] = random.randint(-50, 50)
            elif op < 0.85:
                # grow
                if len(cand) < 60:
                    cand.append(random.randint(-50, 50))
            else:
                # shrink
                if len(cand) > 4:
                    cand.pop(random.randrange(len(cand)))
            cand = list(dict.fromkeys(cand))
            if len(cand) < 2:
                continue
            ns, _, _ = _score_layout(cand)
            if ns >= cs or random.random() < math.exp((ns - cs) / max(T, 1e-6)):
                cur = cand
                cs = ns
            T *= 0.9995
        if cs > best_score:
            best_score = cs
            best_overall = cur[:]

    # fallback
    if best_overall is None:
        best_overall = [1, 2, 4, 8, 16, 32]
    return sorted(set(best_overall))
# EVOLVE-BLOCK-END
