# EVOLVE-BLOCK-START
"""Deterministic mixed-radix digit-set construction.

Idea: A = { sum_i d_i * B^i }, where each d_i ranges over a small digit alphabet
D (e.g. {0,1} for some positions, {0,..,w-1} for one). Then A+A has digit sums
in a small box (few distinct sums), keeping |A+A| small, while A-A ranges over
positive/negative digits, making |A-A| large. We search over bases B, position
counts, and digit alphabets, scoring exactly, to maximize
log|A-A| / log|A+A|.
"""
import math
import itertools
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2 or len(diffs) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(digits_list, base):
    """digits_list: list of digit alphabets for positions 0..k-1."""
    a = [0]
    p = 1
    for d in digits_list:
        newa = []
        for v in a:
            for dd in d:
                newa.append(v + dd * p)
        a = newa
        p *= base
    return a


def solve():
    best = None
    best_score = -1.0

    # Try a family of constructions: k positions, digit alphabet {0,1} on all
    # but possibly one position which gets a wider range.
    candidates = []

    # Pure binary-digit constructions with varying base and position count.
    for k in range(2, 26):
        for base in range(2, 40):
            digits = [[0, 1]] * k
            a = _build(digits, base)
            if len(a) > 4000:
                continue
            candidates.append(a)

    # Mixed: one position with a wider alphabet to enlarge differences while
    # keeping sums concentrated.
    for k in range(2, 16):
        for base in range(2, 30):
            for w in range(2, 6):
                digits = [[0, 1]] * (k - 1) + [list(range(w))]
                a = _build(digits, base)
                if len(a) > 4000:
                    continue
                candidates.append(a)
            if time.time() > 100:
                break

    # Cap the number of candidates we score to stay in budget.
    for a in candidates:
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a
        if time.time() > 110:
            break

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    best = sorted(set(best))
    return best
# EVOLVE-BLOCK-END
