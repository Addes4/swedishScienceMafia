# EVOLVE-BLOCK-START
"""Search over digit-block (base-b Cartesian) constructions for large |A-A|, small |A+A|."""
import math
import itertools
import time


def _stats(a):
    a = list(set(a))
    if len(a) < 2:
        return 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    d, s = _stats(a)
    if s == 0:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def _grid(d1, d2, base):
    return [i + base * j for i in range(d1) for j in range(d2)]


def solve():
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # scan digit-block constructions over many bases and dims
    for base in range(2, 40):
        for d1 in range(1, 60):
            for d2 in range(1, 60):
                if time.time() > deadline:
                    break
                n = d1 * d2
                if n < 6 or n > 800:
                    continue
                a = _grid(d1, d2, base)
                sc = _score(a)
                if sc > best_score:
                    best_score = sc
                    best = a
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # local refinement: perturb elements to try to increase the score
    cur = list(best)
    cur_score = best_score
    step = 1
    while time.time() < deadline:
        cand = cur[:]
        i = int(time.time() * 1e6) % len(cand)
        cand[i] += (i % 3 - 1) * step
        sc = _score(cand)
        if sc > cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc
        step = (step % 7) + 1
    return sorted(set(best))
# EVOLVE-BLOCK-END
