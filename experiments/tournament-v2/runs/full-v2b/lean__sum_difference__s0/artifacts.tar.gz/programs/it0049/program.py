# EVOLVE-BLOCK-START
"""Construct A directly and maximize log|A-A|/log|A+A|.

Key realisation: the earlier answer used a no-carry digit product so that the
ratio equals log|D-D|/log|D+D| independent of size.  But |A| was capped at
|D|^k <= 4000, so D was small and the achievable ratio was limited.

Here we build a *large* alphabet (close to 4000 elements) directly.  A large
random-ish set already gives |A-A| near the full range and |A+A| somewhat
smaller; the objective is a ratio of logs so bigger alphabets help only if
|A-A| grows faster than |A+A|.  We therefore search over structured "Sidon-ish"
alphabets: A = { convolution of a small few-sums alphabet with a geometric
base } realized at full size.  Concretely we use A = D + B*E where D is a
few-sums alphabet (small |D+D|) and E is a sparse set, giving a controlled
product with the exact statistics of the digit construction but with the
digit sets tuned separately for differences and sums.
"""
import math
import random
import time
from itertools import product

_MASK = (1 << 64) - 1


def _bitset_stats(D):
    """|D-D| and |D+D| using Python big-int bitsets (fast, exact)."""
    D = list(set(D))
    if len(D) < 2:
        return 1, 1
    mn = min(D)
    D = [d - mn for d in D]
    hi = max(D)
    bits = 0
    for d in D:
        bits |= 1 << d
    # differences: OR of shifted bitmasks over offsets in [0, hi]
    # do it as: for each shift s, OR (bits << s) where s = d_i for d in D
    dif = 0
    for d in D:
        dif |= (bits << d)
        dif |= (bits >> d)
    # sum set: OR over pairs (a+b) -> shift bits by each a
    sm = 0
    for a in D:
        sm |= (bits << a)
    # normalize: popcount within sensible bounds
    # differences live in [-hi, hi] -> we used shifts, count bits in mask
    # count distinct nonneg differences: reconstruct properly
    # simpler exact counting:
    dset = set()
    for a in D:
        for b in D:
            dset.add(a - b)
    sset = set()
    for a in D:
        for b in D:
            sset.add(a + b)
    return len(dset), len(sset)


def _ratio(D):
    dd, ss = _bitset_stats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _fast_ratio(D, R=None):
    """Fast exact stats via bit operations on Python ints."""
    D = sorted(set(D))
    n = len(D)
    if n < 2:
        return 0.0
    mn = D[0]
    Dl = [d - mn for d in D]
    hi = Dl[-1]
    bits = 0
    for d in Dl:
        bits |= 1 << d
    # difference set: values from -hi..hi
    # count = popcount of OR of (bits >> a) << hi  for a in Dl
    dif = 0
    for a in Dl:
        dif |= bits >> a
    # dif is now positions [0, 2*hi] representing differences + hi
    sumset = 0
    for a in Dl:
        sumset |= bits << a
    # sumset positions [0, 2*hi]
    dd = bin(dif).count("1")
    ss = bin(sumset).count("1")
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss), dd, ss


def _build_product(D, cap=4000):
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _search_alphabet(deadline):
    """Greedy / annealing search for a small D with a very high ratio."""
    R = 48
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _fast_ratio(best_D)[0]
    seeds = [[0, 1, 2, 4, 8, 16], [0, 1, 3, 7, 15], [0, 1, 2, 4, 8],
             [0, 1, 2, 4, 8, 16, 32], [0, 1, 4, 10, 16]]
    for sp in seeds:
        r = _fast_ratio(sp)[0]
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 12)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _fast_ratio(D)[0]
        for _ in range(600):
            if time.time() >= deadline:
                break
            cand = D[:]
            q = random.random()
            if q < 0.65 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif q < 0.82:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            rr = _fast_ratio(cand)[0]
            if rr >= r:
                D, r = cand, rr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    res = _fast_ratio(a)
    if not res:
        return 0.0
    r, dd, ss = res
    return r + (1 - 1 / len(a)) / 100


def solve():
    deadline = time.time() + 90
    D, r = _search_alphabet(deadline)

    candidates = []
    candidates.append(_build_product(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8, 16, 32], [0, 1, 3, 7, 15],
               [0, 1, 2, 4, 8], [0, 1, 2, 4], [0, 1, 2, 3, 4, 5, 6, 7]):
        candidates.append(_build_product(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END

