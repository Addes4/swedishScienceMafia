# EVOLVE-BLOCK-START
"""Construct a set A with large difference set and small sum set.

Key idea: use a geometric progression base set B = {1, b, b^2, ...}.
For a geometric progression, sums have few representations but the *values*
a+b are numerous.  The trick used by good constructions is to combine a
geometric progression with a small additive perturbation so that A+A clusters
into a small number of values while A-A spreads out widely.

We build A = { B^i + j * t } and choose parameters so |A+A| is minimized
relative to |A-A|, evaluated exactly, then do a local search over parameters.
"""
import math
import time


def _metrics(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    if len(a) < 2:
        return 0.0
    d, s = _metrics(a)
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def solve():
    best = None
    best_score = -1.0

    # Try several parameterizations of a geometric-ish construction.
    # A = { base^i * step + offset_j }
    # We exploit that if A lies on a geometric progression, A+A tends to have
    # few distinct values when there is a shared additive structure.
    configs = []
    for b in (2, 3, 4, 5):
        for k in range(6, 16):
            for t in (1, 2, 3):
                configs.append((b, k, t))

    deadline = time.time() + 100

    for (b, k, t) in configs:
        if time.time() > deadline:
            break
        # geometric progression
        a = []
        x = 1
        for i in range(k):
            a.append(x)
            x *= b
        # add perturbing block to shrink A+A relative to A-A
        extra = []
        for j in range(1, t * 2 + 1):
            extra.append(j * b ** (k // 2))
        a.extend(extra)
        a = sorted(set(a))
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a

    # Local search refinement from the best config found.
    if best is None:
        best = [1, 2, 4, 8, 16, 32]
        best_score = _score(best)

    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        import random
        i = random.randrange(len(cand))
        cand[i] += random.choice([-2, -1, 1, 2])
        if random.random() < 0.04:
            cand.append(random.randint(1, b ** k))
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s

    return best if best else [1, 2, 4, 8, 16, 32]
# EVOLVE-BLOCK-END
