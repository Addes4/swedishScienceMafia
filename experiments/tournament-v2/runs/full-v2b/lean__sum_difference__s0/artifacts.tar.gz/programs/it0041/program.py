# EVOLVE-BLOCK-START
"""Constructive search: subset-sum families in base B with greedy exact scoring."""
import math
import itertools


def _score_vals(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    best = None
    best_score = -1.0

    # Try subset-sum families: A = { sum_{i in S} B^i : subsets } with k positions.
    # Sums collide heavily (digit vectors add), differences large => good ratio.
    for B in range(2, 7):
        for k in range(2, 14):
            pos = list(range(k))
            A = set()
            for mask in range(1 << k):
                v = 0
                for i in range(k):
                    if mask & (1 << i):
                        v += B ** i
                A.add(v)
            A = sorted(A)
            if A[-1] > 10**15:
                continue
            s = _score_vals(A)
            if s > best_score:
                best_score = s
                best = A[:]

    # Greedy add: try extending best with extra elements near multiples of B powers.
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score_vals(best)

    top = best
    B0 = 2
    # Determine base used (largest power spacing)
    base = None
    for B in range(2, 7):
        A = best
        diffs = sorted(set(b - a for a in A for b in A))
        # heuristic: skip
    # Greedy extension
    for _ in range(3):
        improved = False
        for cand_vals in [range(-50, 51)]:
            cur_score = _score_vals(top)
            for x in cand_vals:
                if x in top:
                    continue
                trial = top + [x]
                if max(abs(v) for v in trial) > 10**15:
                    continue
                s = _score_vals(trial)
                if s > cur_score:
                    top = trial
                    cur_score = s
                    improved = True
        if not improved:
            break
    if _score_vals(top) > best_score:
        best = top

    return sorted(set(best))
# EVOLVE-BLOCK-END
