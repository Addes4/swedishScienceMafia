# EVOLVE-BLOCK-START
"""Construct sets A with large difference set and small sum set.

Strategy: the extremal sets for maximizing log|A-A|/log|A+A| are close to
geometric progressions and to digit-restricted sets in a base b.  We combine:
  * a family of structured candidates (geometric progressions, digit-restricted
    sets in bases 2..6, unions of two GPs),
  * an exact-score simulated annealing / hill-climb in log-coordinate space that
    perturbs exponents and offsets, accepting neutral moves to escape plateaus.
All scoring is exact using Python integer sets, kept small so it is fast.
"""
import math
import random
import time


def _stats(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return None
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    return len(diffs), len(sums), n


def _score_vals(nd, ns, n):
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    st = _stats(a)
    if st is None:
        return 0.0
    return _score_vals(*st)


def _digit_set(base, digits, length):
    """All numbers sum(d_i base^i) with d_i in digits, i < length."""
    cur = [0]
    place = 1
    for _ in range(length):
        nxt = []
        for v in cur:
            for d in digits:
                nxt.append(v + d * place)
        cur = nxt
        place *= base
    return cur


def _geo(base, length):
    return [base ** i for i in range(length)]


def _candidates():
    out = []
    # geometric progressions
    for base in (2, 3, 4, 5, 6, 7, 8):
        for length in range(3, 14):
            out.append(_geo(base, length))
    # digit-restricted sets in small bases
    for base in (2, 3, 4, 5):
        for length in range(2, 9):
            digits_sets = [
                (0, 1), (1, 2), (0, 2), (1,), (2,),
                (0, 1, 2), (1, 3), (0, 1, 3),
            ]
            for dig in digits_sets:
                if len(dig) == 1:
                    # single nonzero digit -> geometric-ish
                    if dig[0] != 1:
                        pass
                    s = _digit_set(base, dig, length)
                    out.append(s)
                else:
                    s = _digit_set(base, dig, length)
                    out.append(s)
    return out


def solve():
    deadline = time.time() + 110

    best_a = [7, 15, 18, 22, -3, -2]
    best_st = _stats(best_a)
    best_score = _score_vals(*best_st)

    # evaluate structured candidates
    for cand in _candidates():
        if time.time() > deadline:
            break
        st = _stats(cand)
        if st is None:
            continue
        sc = _score_vals(*st)
        if sc > best_score:
            best_score = sc
            best_a = cand[:]
            best_st = st

    # hill climb in "scale/shift" space starting from the best
    def try_move(a, rng):
        cand = a[:]
        r = rng.random()
        if r < 0.45:
            # perturb one element by small multiplicative/ additive amount
            i = rng.randrange(len(cand))
            if rng.random() < 0.5 and cand[i] != 0:
                cand[i] = int(cand[i] * rng.choice([2, 3, 0.5, 0.25, 1.5]))
            else:
                cand[i] += rng.randint(-50, 50)
        elif r < 0.7:
            # scale whole set or add elements multiplicatively
            k = rng.choice([2, 3, 4, 5])
            if rng.random() < 0.5:
                cand = [x * k for x in cand]
            else:
                cand = cand + [x * k for x in cand]
        elif r < 0.85:
            # add a new element
            i = rng.randrange(len(cand))
            cand.append(cand[i] + rng.choice([1, 2, 3, -1, -2, 5, 10]))
        else:
            if len(cand) > 4:
                cand.pop(rng.randrange(len(cand)))
        return cand

    rng = random.Random(12345)
    cur_a = best_a[:]
    cur_st = best_st
    it = 0
    while time.time() < deadline:
        it += 1
        cand = try_move(cur_a, rng)
        cand = list(set(cand))
        st = _stats(cand)
        if st is None:
            continue
        sc = _score_vals(*st)
        if sc >= best_score:
            if sc > best_score:
                best_score = sc
                best_a = cand[:]
                best_st = st
            cur_a, cur_st = cand, st
        elif rng.random() < 0.02:
            cur_a, cur_st = cand, st
        elif rng.random() < 0.05:
            cur_a, cur_st = best_a[:], best_st
        # periodic restart to diversify
        if it % 20000 == 0:
            cur_a, cur_st = best_a[:], best_st

    return sorted(set(best_a))
# EVOLVE-BLOCK-END

