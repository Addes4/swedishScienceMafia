# EVOLVE-BLOCK-START
"""Construct A to maximize log|A-A| / log|A+A| over sets of up to 4000 integers.

Two families are tried and the best realized score is returned:

1. Carry-free digit products:  A = { sum_i d_i * B^i : d_i in D }.
   With B > 2*span(D) there are no carries, so exactly
       |A - A| = |D - D|^k ,  |A + A| = |D + D|^k
   and the objective equals log|D-D|/log|D+D|, independent of k.
   We search small alphabets D for a good ratio, then use the largest k
   with |D|^k <= 4000 for the size bonus.

2. Interval-mixed constructions:  A = I + B*C where I is a short interval
   and C is a carry-free digit product.  The interval keeps sums close
   together while widening the difference set.
"""
import math
import random
import time
from itertools import product

import numpy as np


# --------------------------------------------------------------------------
# fast numpy scorers
# --------------------------------------------------------------------------
def _fast_sizes(arr):
    """Return (|A-A|, |A+A|) for a 1-D integer numpy array using vectorized
    pairwise differences and sums plus np.unique."""
    arr = np.unique(np.asarray(arr, dtype=np.int64))
    n = arr.size
    if n < 2:
        return 0, 0
    # pairwise differences (n x n)
    diffs = arr[:, None] - arr[None, :]
    dd = np.unique(diffs).size
    sums = arr[:, None] + arr[None, :]
    ss = np.unique(sums).size
    return int(dd), int(ss)


def _score_arr(arr):
    arr = np.unique(np.asarray(arr, dtype=np.int64))
    n = arr.size
    if n < 2:
        return 0.0
    dd, ss = _fast_sizes(arr)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss) + (1.0 - 1.0 / n) / 100.0


# --------------------------------------------------------------------------
# alphabet statistics (pure python, small sets)
# --------------------------------------------------------------------------
def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    R = 40
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [
        [0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
        [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32], [0, 1, 2, 4, 8],
        [0, 1, 2, 3, 6, 12, 24], [0, 1, 4, 5, 16, 17],
    ]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 14)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        for _ in range(500):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.65 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.82:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


# --------------------------------------------------------------------------
# builders
# --------------------------------------------------------------------------
def _build_product(D, cap=4000):
    """Carry-free subset sums from alphabet D, largest size <= cap."""
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1 if span > 0 else 2
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _build_interval_product(D, m, cap=4000):
    """A = { i + B* (carry-free digit sum over D) : 0<=i<m }.

    Sizes restricted to <= cap; the (k, m) pair is chosen so that
    |D|^k * m <= cap.
    """
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2 or m < 1:
        return _build_product(D, cap)
    # choose largest k with s^k * m <= cap
    k = 0
    while s ** (k + 1) * m <= cap:
        k += 1
    if k == 0:
        # fall back to plain product / interval only
        if m > 1 and m <= cap:
            return list(range(m))
        return _build_product(D, cap)
    span = max(D) - min(D)
    inner_base = 2 * span + 1 if span > 0 else 2
    # outer base larger than inner span + interval length
    inner_max = (inner_base ** k - 1) // (inner_base - 1) * span if inner_base > 1 else span
    outer = inner_max + m + 1
    if outer > 10 ** 15 // max(1, inner_max + 1):
        # too big, fall back
        return _build_product(D, cap)
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= inner_base
        base = v * outer
        for i in range(m):
            vals.append(base + i)
    return sorted(set(vals))


# --------------------------------------------------------------------------
# solve
# --------------------------------------------------------------------------
def solve():
    deadline = time.time() + 100
    D, r = _search_alphabet(deadline - 60)

    candidates = []
    candidates.append(_build_product(D))
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5], [0, 1]):
        candidates.append(_build_product(sp))

    # interval-mixed candidates
    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], D):
        for m in (2, 3, 4, 5):
            candidates.append(_build_interval_product(sp, m))

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        if time.time() > deadline:
            break
        sc = _score_arr(c)
        if sc > best_s:
            best_s, best = sc, c

    if best is None:
        best = [0, 1]
    return [int(x) for x in best]
# EVOLVE-BLOCK-END
