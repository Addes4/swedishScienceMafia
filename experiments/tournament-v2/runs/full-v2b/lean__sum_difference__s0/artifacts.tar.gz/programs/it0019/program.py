# EVOLVE-BLOCK-START
"""Search over geometric-progression constructions plus exact-score local refinement."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _geo(b, n):
    return [b ** i for i in range(n)]


def solve():
    deadline = time.time() + 115
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Phase 1: scan geometric progressions.
    for b in range(2, 60):
        for n in range(2, 14):
            try:
                a = _geo(b, n)
            except OverflowError:
                continue
            if max(abs(x) for x in a) > 10**15:
                continue
            s = _score(a)
            if s > best_score:
                best, best_score = a, s

    # Phase 2: local refinement from the best candidate.
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        move = random.random()
        if move < 0.5 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2])
        elif move < 0.7 and cand:
            i = random.randrange(len(cand))
            cand[i] *= random.choice([2, 3])
        elif move < 0.85:
            cand.append(random.randint(1, 50))
        elif len(cand) > 3:
            cand.pop(random.randrange(len(cand)))
        cand = [x for x in cand if abs(x) <= 10**15]
        if len(set(cand)) < 2:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score
    return sorted(set(best))
# EVOLVE-BLOCK-END
