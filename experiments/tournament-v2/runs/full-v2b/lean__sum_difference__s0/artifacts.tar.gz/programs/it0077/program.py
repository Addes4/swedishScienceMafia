# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a digit alphabet D with no carries.

For A = { sum_i d_i B^i : d_i in D } with B large (no carries) we get
    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k
so the exponent k cancels in the log-ratio, and we only need the best small
alphabet D, then the largest k with |D|^k <= 4000 for the size bonus.

We search over larger alphabets (where the ratio is best) using numpy-vectorized
evaluation of |D-D| and |D+D| and a mix of structured seeds and local search.
"""
import math
import random
import time
from itertools import product

import numpy as np


def _ddstats(D):
    a = np.asarray(sorted(set(D)), dtype=np.int64)
    dd = np.unique(a[:, None] - a[None, :]).size
    ss = np.unique(a[:, None] + a[None, :]).size
    return int(dd), int(ss)


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    R = 60
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)

    seed_pool = [
        list(range(0, 2)),
        [0, 1, 3],
        [0, 1, 2, 4, 8, 16, 32, 64],
        [0, 1, 2, 4, 8, 16, 32],
        [0, 1, 2, 4, 8, 16],
        [0, 1, 3, 7, 15, 31, 63],
        [0, 1, 2, 4, 8],
        [0, 1, 3, 7, 15],
        [0, 1, 2, 3, 6, 12, 24, 48],
    ]
    for sp in seed_pool:
        sp = [d for d in sp if d <= R]
        if len(sp) >= 2:
            r = _ratio(sp)
            if r > best_r:
                best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(4, 16)
        D = sorted(set(random.sample(range(0, R + 1), min(s, R + 1))))
        if len(D) < 2:
            continue
        r = _ratio(D)
        for _ in range(300):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.65 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.82:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _score(a):
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    if a.size < 2:
        return 0.0
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    if diffs < 2 or sums < 2:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / a.size) / 100


def solve():
    deadline = time.time() + 70
    D, r = _search_alphabet(deadline)

    candidates = []
    candidates.append(_build(D))
    for sp in ([0, 1, 2, 4, 8, 16, 32], [0, 1, 2, 4, 8, 16],
               [0, 1, 3, 7, 15, 31], [0, 1, 2, 4, 8],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5]):
        candidates.append(_build(sp))
    candidates.append([7, 15, 18, 22, -3, -2])

    best = None
    best_s = -1.0
    for c in candidates:
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
