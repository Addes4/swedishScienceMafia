# EVOLVE-BLOCK-START
"""Construction: N = { sum d_i * B^i } with a large first alphabet and sparse later
digits, which makes A-A much larger than A+A.  A short exact-score hill climb
refines the best candidate."""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    if len(a) < 2:
        return 1, 1
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums)


def _score(a):
    d, s = _stats(a)
    n = len(set(a))
    if n < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _construct(B, alphabets):
    """A = { sum d_i B^i : d_i in alphabets[i] } as a flat list."""
    A = [0]
    p = 1
    for al in alphabets:
        newA = []
        for base in A:
            for d in al:
                newA.append(base + d * p)
        A = newA
        p *= B
    return A


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # coarse-to-fine search over mixed radix constructions
    canon = [(0, 1), (0, 2), (0, 3)]
    tries = 0
    while time.time() < deadline * 0.0 + time.time() + 0.001 and tries < 400:
        tries += 1
        B = random.choice([2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20, 24, 32, 40])
        k = random.randint(3, 9)
        alphabets = []
        for i in range(k):
            if i == 0:
                m = random.randint(3, 9)
                alphabets.append(tuple(range(m)))
            else:
                r = random.random()
                if r < 0.6:
                    alphabets.append((0, 1))
                elif r < 0.85:
                    alphabets.append((0, 1, 2))
                else:
                    m = random.randint(3, 5)
                    alphabets.append(tuple(range(m)))
        A = _construct(B, alphabets)
        if len(set(A)) != len(A) or len(A) > 4000:
            continue
        d, s = _stats(A)
        if d > 1 and s > 1:
            sc = math.log(d) / math.log(s) + (1 - 1 / len(A)) / 100
            if sc > best_score:
                best_score, best = sc, A[:]

    # fallback
    if best is None:
        best = [0, 1, 2, 3, 4, 5, 6, 7]
        best_score = _score(best)

    # exact-score local refinement
    cur = best[:]
    cur_score = best_score
    step = 1
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.choice([-step, step])
        if len(set(cand)) != len(cand):
            continue
        sc = _score(cand)
        if sc > cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc
        elif random.random() < 0.05:
            step = max(1, step - 1)
        else:
            step = min(step + 1, 64)
    return sorted(set(best))
# EVOLVE-BLOCK-END
