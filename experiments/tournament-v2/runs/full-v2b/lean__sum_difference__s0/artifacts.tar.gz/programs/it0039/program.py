# EVOLVE-BLOCK-START
"""Construction: A = set of integers whose base-B digits are in {0,1}.

For A = { sum_j c_j B^j : c_j in {0,1}, 0 <= j < k }:
  - A + A has digits in {0,1,2}, giving at most 3^k sums (in fact exactly 3^k distinct).
  - A - A has digits in {-1,0,1}, giving at most 3^k differences too, but bounded
    more tightly? Actually |A+A| = 3^k and |A-A| = 3^k when B is large enough.
That is not a win. The winning family uses digits in {0,1} for sums but differences
exploit independent digits to give |A-A| larger than |A+A|.

Known optimal: A = { i + j*M } style gives ratio ~2. The best known score is
obtained by a "near-optimal" set found by careful search, so we do a small local
search around a good seed.
"""
import math
import random
import time


def _score(a):
    A = list(set(a))
    n = len(A)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        xi = A[i]
        for j in range(n):
            xj = A[j]
            diffs.add(xi - xj)
            sums.add(xi + xj)
    return (math.log(len(diffs)) / math.log(len(sums))
            + (1 - 1 / n) / 100), len(diffs), len(sums)


def _greedy_seed():
    """Build a small set that maximizes |A-A| while keeping |A+A| small.

    Start from a compact arithmetic progression (small sums) and add points
    far apart to inflate differences.
    """
    best = None
    best_val = -1.0
    for base in (1, 3, 7, 15, 31):
        A = list(range(0, 2 * base + 1))
        val, _, _ = _score(A)
        if val > best_val:
            best_val = val
            best = A
    return best


def solve():
    best = _greedy_seed()
    best_val, _, _ = _score(best)
    cur = best[:]
    deadline = time.time() + 100

    # Multi-seed randomized hill-climb
    seeds = [best[:]]
    for _ in range(6):
        n = random.randint(4, 9)
        s = sorted(random.sample(range(-40, 41), n))
        seeds.append(s)

    for seed in seeds:
        cur = seed[:]
        cur_val, _, _ = _score(cur)
        T = 2.0
        while time.time() < deadline:
            cand = cur[:]
            op = random.random()
            if op < 0.5 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.choice([-2, -1, 1, 2]) * random.randint(1, 3)
            elif op < 0.8 and len(cand) < 12:
                cand.append(random.randint(-50, 50))
            elif len(cand) > 3:
                del cand[random.randrange(len(cand))]
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            val, _, _ = _score(cand)
            if val > cur_val or random.random() < math.exp(min(0.0, (val - cur_val) / max(T, 1e-6))):
                cur, cur_val = cand, val
            if cur_val > best_val:
                best, best_val = cur[:], cur_val
            T *= 0.9995
            if T < 1e-4:
                T = 2.0

    return sorted(set(best))
# EVOLVE-BLOCK-END
