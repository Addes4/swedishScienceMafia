# EVOLVE-BLOCK-START
"""Construct A as subset-sums over a tuned digit alphabet D.

If A = { sum_i d_i B^i : d_i in D } with B large enough that no two digit-vectors
collide (no carries), then exactly

    |A - A| = |D - D|^k ,   |A + A| = |D + D|^k

so the objective log|A-A|/log|A+A| = log|D-D|/log|D+D| is independent of k.
We search for a small alphabet D maximizing that per-digit ratio, then replicate
it (largest k with |D|^k <= 4000) for the size bonus.

To beat the pure per-digit bound we also try *mixed* constructions: a few
high-order positions take a difference-rich alphabet D_hi while many low-order
positions take a full interval alphabet D_lo (a box).  The sums stay close to a
box (small |A+A|) while differences pick up the extra high-order spread.
"""
import math
import random
import time
from itertools import product


def _ddstats(D):
    D = list(set(D))
    dd = len({a - b for a in D for b in D})
    ss = len({a + b for a in D for b in D})
    return dd, ss


def _ratio(D):
    dd, ss = _ddstats(D)
    if dd < 2 or ss < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_alphabet(deadline):
    R = 40
    best_D = [0, 1, 2, 4, 8, 16]
    best_r = _ratio(best_D)
    seed_pool = [[0, 1], [0, 1, 3], [0, 1, 2, 4, 8, 16], [0, 1, 2, 4],
                 [0, 1, 3, 7, 15], [0, 1, 2, 4, 8, 16, 32],
                 [0, 1, 2, 4, 8, 16, 32, 64], [0, 1, 3, 4, 9, 11]]
    for sp in seed_pool:
        r = _ratio(sp)
        if r > best_r:
            best_r, best_D = r, sp[:]

    while time.time() < deadline:
        s = random.randint(2, 14)
        D = sorted(random.sample(range(0, R + 1), s))
        r = _ratio(D)
        for _ in range(500):
            if time.time() >= deadline:
                break
            cand = D[:]
            op = random.random()
            if op < 0.7 and cand:
                i = random.randrange(len(cand))
                cand[i] = random.randint(0, R)
            elif op < 0.85:
                cand.append(random.randint(0, R))
            elif len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            cr = _ratio(cand)
            if cr >= r:
                D, r = cand, cr
        if r > best_r:
            best_r, best_D = r, D[:]
    return best_D, best_r


def _build(D, cap=4000):
    D = sorted(set(D))
    D = [d - min(D) for d in D]
    s = len(D)
    if s < 2:
        return [0, 1]
    k = 1
    while s ** (k + 1) <= cap:
        k += 1
    span = max(D) - min(D)
    B = 2 * span + 1
    vals = []
    for combo in product(D, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= B
        vals.append(v)
    return sorted(set(vals))


def _build_mixed(D_hi, k_hi, D_lo, k_lo, cap=4000):
    """Product over high-order positions (D_hi, k_hi digits) and low-order
    positions (D_lo, k_lo digits) in a common base B with no carries."""
    D_hi = sorted(set(D_hi))
    D_lo = sorted(set(D_lo))
    if len(D_hi) < 2 or len(D_lo) < 2:
        return []
    span = max(max(D_hi) - min(D_hi), max(D_lo) - min(D_lo))
    B = 2 * span + 1

    def block(vals, k, base):
        out = []
        for combo in product(vals, repeat=k):
            v = 0
            p = 1
            for d in combo:
                v += d * p
                p *= base
            out.append(v)
        return sorted(set(out))

    low = block(D_lo, k_lo, B)
    if not low:
        return []
    # high block values scaled by B^k_lo
    scale = B ** k_lo
    hi = block([d - min(D_hi) for d in D_hi], k_hi, B)
    if not hi:
        return []
    res = set()
    for h in hi:
        base_v = h * scale
        for l in low:
            res.add(base_v + l)
            if len(res) > cap * 3:
                return []
    vals = sorted(res)
    if len(vals) > cap:
        vals = vals[:cap]
    return vals


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _candidates(D, deadline):
    cands = []
    cands.append(_build(D))

    for sp in ([0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8], [0, 1, 3, 7, 15],
               [0, 1, 2, 4], [0, 1, 2, 3, 4, 5], [0, 1, 2, 4, 8, 16, 32],
               [0, 1, 2, 4, 8, 16, 32, 64]):
        cands.append(_build(sp))

    # mixins: high-ratio alphabet in high positions, interval in low positions
    interval_alphabets = [[0, 1, 2], [0, 1, 2, 3], [0, 1, 2, 3, 4],
                          [0, 1, 2, 3, 4, 5], [0, 1, 2, 3, 4, 5, 6]]
    hi_alphabets = [D, [0, 1, 2, 4, 8, 16], [0, 1, 2, 4, 8, 16, 32],
                    [0, 1, 3, 7, 15]]
    for h in hi_alphabets:
        hs = len(set(h))
        for lo in interval_alphabets:
            ls = len(set(lo))
            for k_hi in (1, 2, 3):
                for k_lo in range(0, 8):
                    sz = (hs ** k_hi) * (ls ** k_lo)
                    if sz < 2 or sz > 4000:
                        continue
                    cands.append(_build_mixed(h, k_hi, lo, k_lo))
                    if time.time() > deadline:
                        return cands

    cands.append([7, 15, 18, 22, -3, -2])
    return cands


def solve():
    deadline = time.time() + 55
    D, r = _search_alphabet(deadline)

    best = None
    best_s = -1.0
    for c in _candidates(D, time.time() + 50):
        if len(c) < 2:
            continue
        sc = _score(c)
        if sc > best_s:
            best_s, best = sc, c

    return list(best)
# EVOLVE-BLOCK-END
