# EVOLVE-BLOCK-START
"""Greedy largest-square packing with a simple free-rectangle list."""
import math


def _overlap_touch(cx, cy, s, rx, ry, rw, rh, eps=1e-12):
    """True if axis-aligned square strictly overlaps interior of rectangle."""
    mx = cx + s / 2 - eps
    nx = cx - s / 2 + eps
    my = cy + s / 2 - eps
    ny = cy - s / 2 + eps
    return nx < rx + rw and mx > rx and ny < ry + rh and my > ry


def _best_square_in_rect(rx, ry, rw, rh, placed, eps=1e-9):
    """Find largest axis-aligned square in rect avoiding placed squares.
    Try anchor positions at corners and at edges of placed squares."""
    cands = [(rx, ry), (rx + rw, ry + rh), (rx + rw, ry), (rx, ry + rh)]
    for (px, py, ps) in placed:
        cands.append((px + ps / 2, py + ps / 2))
        cands.append((px + ps / 2, py - ps / 2))
        cands.append((px - ps / 2, py + ps / 2))
        cands.append((px - ps / 2, py - ps / 2))
    best = (0.0, rx + rw / 2, ry + rh / 2)
    # corner anchors
    for (ax, ay) in cands:
        if ax < rx - 1e-12 or ax > rx + rw + 1e-12:
            continue
        if ay < ry - 1e-12 or ay > ry + rh + 1e-12:
            continue
        # grow square with lower-left at (ax, ay)
        maxw = rx + rw - ax
        maxh = ry + rh - ay
        s = min(maxw, maxh)
        for (px, py, ps) in placed:
            lx, ly = px - ps / 2, py - ps / 2
            ux, uy = px + ps / 2, py + ps / 2
            if lx < ax + s + 1e-12 and ux > ax - 1e-12 and ly < ay + s + 1e-12 and uy > ay - 1e-12:
                s = min(s, lx - ax) if lx >= ax else s
                s = min(s, ly - ay) if ly >= ay else s
        if s > best[0]:
            best = (s, ax + s / 2, ay + s / 2)
        # try lower-right aligned
        s2 = min(ax - rx, ry + rh - ay)
        for (px, py, ps) in placed:
            lx, ly = px - ps / 2, py - ps / 2
            ux, uy = px + ps / 2, py + ps / 2
            if lx < ax + 1e-12 and ux > ax - s2 - 1e-12 and ly < ay + s2 + 1e-12 and uy > ay - 1e-12:
                if ux <= ax:
                    s2 = min(s2, ax - ux)
                if ly >= ay:
                    s2 = min(s2, ly - ay)
        if s2 > best[0]:
            best = (s2, ax - s2 / 2, ay + s2 / 2)
        # try upper-left aligned
        s3 = min(rx + rw - ax, ay - ry)
        for (px, py, ps) in placed:
            lx, ly = px - ps / 2, py - ps / 2
            ux, uy = px + ps / 2, py + ps / 2
            if lx < ax + s3 + 1e-12 and ux > ax - 1e-12 and ly < ay + 1e-12 and uy > ay - s3 - 1e-12:
                if lx >= ax:
                    s3 = min(s3, lx - ax)
                if uy <= ay:
                    s3 = min(s3, ay - uy)
        if s3 > best[0]:
            best = (s3, ax + s3 / 2, ay - s3 / 2)
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # initial grid for k x k
    k = math.isqrt(n)
    squares = [((i + 0.5) / k, (j + 0.5) / k, 0.0, 1.0 / k) for i in range(k) for j in range(k)]
    placed = [(x, y, s) for (x, y, a, s) in squares]
    placed = [(x, y, s) for (x, y, a, s) in squares]
    remaining = n - len(squares)

    eps = 1e-9
    while remaining > 0:
        rects = [(0.0, 0.0, 1.0, 1.0)]
        # split free space into rectangles (simple tiling)
        free = [(0.0, 0.0, 1.0, 1.0)]
        newfree = []
        for (rx, ry, rw, rh) in free:
            sub = [(rx, ry, rw, rh)]
            for (px, py, ps) in placed:
                lx, ly = px - ps / 2, py - ps / 2
                ux, uy = px + ps / 2, py + ps / 2
                out = []
                for (sx, sy, sw, sh) in sub:
                    if ux <= sx or lx >= sx + sw or uy <= sy or ly >= sy + sh:
                        out.append((sx, sy, sw, sh))
                        continue
                    if lx > sx:
                        out.append((sx, sy, lx - sx, sh))
                    if ux < sx + sw:
                        out.append((ux, sy, sx + sw - ux, sh))
                    if ly > sy:
                        out.append((sx, sy, sw, ly - sy))
                    if uy < sy + sh:
                        out.append((sx, uy, sw, sy + sh - uy))
                sub = out
            newfree.extend(sub)
        # pick best square over all free rects
        best = (0.0, 0.5, 0.5)
        for (rx, ry, rw, rh) in newfree:
            if rw <= eps or rh <= eps:
                continue
            s, cx, cy = _best_square_in_rect(rx, ry, rw, rh, placed)
            if s > best[0]:
                best = (s, cx, cy)
        s, cx, cy = best
        placed.append((cx, cy, s))
        squares.append((cx, cy, 0.0, s))
        remaining -= 1

    return squares[:n]
# EVOLVE-BLOCK-END

