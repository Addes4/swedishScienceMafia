# EVOLVE-BLOCK-START
"""Squares in a unit square: maximise total side length.

Strategy: partition the unit square into up to five rectangular regions
(a main region plus a right strip, a top region that may be split into
two side-by-side sub-strips, and a small top-right corner block).
Each region is packed with equal squares via the best grid factorisation.
We search over the split fractions and the distribution of squares
between regions to maximise the total side sum; the best candidate is
then polished with a fine coordinate-descent.  Squares with side 0 fill
any remainder.
"""
import math


def _pack_grid(count, W, H):
    """Best equal-square grid for `count` squares inside a W x H box."""
    if count <= 0 or W <= 0 or H <= 0:
        return [], 0.0, 0
    best = None
    for a in range(1, count + 1):
        b = (count + a - 1) // a
        if a * b < count:
            continue
        s = min(W / a, H / b)
        total = s * count
        if best is None or total > best[0]:
            best = (total, a, b, s)
    if best is None:
        return [], 0.0, 0
    _, a, b, s = best
    sq = []
    used = 0
    for i in range(a):
        for j in range(b):
            if used >= count:
                break
            cx = (i + 0.5) * s
            cy = (j + 0.5) * s
            sq.append((cx, cy, 0.0, s))
            used += 1
        if used >= count:
            break
    return sq, s, used


def _layout3(n, nb, ns1, ns2, fw, fh):
    """Three-region layout:
      Main region: [0, 1-fw] x [0, 1-fh]  (holds nb squares)
      Right strip: [1-fw, 1] x [0, 1-fh]  (holds ns1 squares)
      Top strip:   [0, 1] x [1-fh, 1]     (holds ns2 squares)
    """
    mw, mh = 1.0 - fw, 1.0 - fh
    rw, rh = fw, 1.0 - fh
    tw, th = 1.0, fh

    big, bs, used_big = _pack_grid(nb, mw, mh)
    if nb > 0 and used_big < nb:
        return None
    s1, ss1, u1 = _pack_grid(ns1, rw, rh)
    if ns1 > 0 and u1 < ns1:
        return None
    s2, ss2, u2 = _pack_grid(ns2, tw, th)
    if ns2 > 0 and u2 < ns2:
        return None

    squares = []
    for (cx, cy, a, s) in big:
        squares.append((cx, cy, a, s))
    ox1 = mw
    for (cx, cy, a, s) in s1:
        squares.append((cx + ox1, cy, a, s))
    oy2 = mh
    for (cx, cy, a, s) in s2:
        squares.append((cx, cy + oy2, a, s))

    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss1 * u1 + ss2 * u2
    return total, squares[:n]


def _layout4(n, nb, ns1, ns2a, ns2b, fw, fh, g):
    """Four-region layout:
      Main region: [0, 1-fw] x [0, 1-fh]        (holds nb squares)
      Right strip: [1-fw, 1] x [0, 1-fh]        (holds ns1 squares)
      Top-left:    [0, g]    x [1-fh, 1]        (holds ns2a squares)
      Top-right:   [g, 1]    x [1-fh, 1]        (holds ns2b squares)
    """
    mw, mh = 1.0 - fw, 1.0 - fh
    rw, rh = fw, 1.0 - fh
    tlw, th = g, fh
    trw = 1.0 - g

    big, bs, used_big = _pack_grid(nb, mw, mh)
    if nb > 0 and used_big < nb:
        return None
    s1, ss1, u1 = _pack_grid(ns1, rw, rh)
    if ns1 > 0 and u1 < ns1:
        return None
    sa, ssa, ua = _pack_grid(ns2a, tlw, th)
    if ns2a > 0 and ua < ns2a:
        return None
    sb, ssb, ub = _pack_grid(ns2b, trw, th)
    if ns2b > 0 and ub < ns2b:
        return None

    squares = []
    for (cx, cy, a, s) in big:
        squares.append((cx, cy, a, s))
    ox1 = mw
    for (cx, cy, a, s) in s1:
        squares.append((cx + ox1, cy, a, s))
    oy2 = mh
    for (cx, cy, a, s) in sa:
        squares.append((cx, cy + oy2, a, s))
    for (cx, cy, a, s) in sb:
        squares.append((cx + g, cy + oy2, a, s))

    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss1 * u1 + ssa * ua + ssb * ub
    return total, squares[:n]


def _layout5(n, nb, ns1, ns2a, nsc, fw, fh, gx, gy):
    """Five-region layout (right column split + top-right corner)."""
    mw, mh = 1.0 - fw, 1.0 - fh
    rlw, rlh = fw, 1.0 - gy
    tsw, tsh = mw, fh
    cw, ch = fw, gy

    big, bs, used_big = _pack_grid(nb, mw, mh)
    if nb > 0 and used_big < nb:
        return None
    s1, ss1, u1 = _pack_grid(ns1, rlw, rlh)
    if ns1 > 0 and u1 < ns1:
        return None
    sa, ssa, ua = _pack_grid(ns2a, tsw, tsh)
    if ns2a > 0 and ua < ns2a:
        return None
    sc, ssc, uc = _pack_grid(nsc, cw, ch)
    if nsc > 0 and uc < nsc:
        return None

    squares = []
    for (cx, cy, a, s) in big:
        squares.append((cx, cy, a, s))
    ox1 = mw
    for (cx, cy, a, s) in s1:
        squares.append((cx + ox1, cy, a, s))
    oy2 = mh
    for (cx, cy, a, s) in sa:
        squares.append((cx, cy + oy2, a, s))
    oxc = mw
    oyc = 1.0 - gy
    for (cx, cy, a, s) in sc:
        squares.append((cx + oxc, cy + oyc, a, s))

    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss1 * u1 + ssa * ua + ssc * uc
    return total, squares[:n]


def _layout(n, n_big, split_frac, vertical):
    """Two-region layout (fallback / small n)."""
    if vertical:
        fw = split_frac
        bw, bh = fw, 1.0
        sw, sh = 1.0 - fw, 1.0
    else:
        fh = split_frac
        bw, bh = 1.0, fh
        sw, sh = 1.0, 1.0 - fh

    big, bs, used_big = _pack_grid(n_big, bw, bh)
    if used_big < n_big:
        return None
    rest = n - n_big
    small, ss, used_small = _pack_grid(rest, sw, sh)

    squares = list(big)
    ox = bw if vertical else 0.0
    oy = 0.0 if vertical else bh
    for (cx, cy, a, s) in small:
        squares.append((cx + ox, cy + oy, a, s))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss * used_small
    return total, squares[:n]


def _overlap(sq1, sq2):
    """Separating-axis non-overlap test for two axis-aligned squares."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 1e-12 or s2 <= 1e-12:
        return False
    # treat as axis-aligned (angles are 0 in this program)
    r1 = s1 * 0.5
    r2 = s2 * 0.5
    if abs(cx1 - cx2) >= r1 + r2 - 1e-9:
        return False
    if abs(cy1 - cy2) >= r1 + r2 - 1e-9:
        return False
    return True


def _layout_valid(squares):
    for i in range(len(squares)):
        cx, cy, a, s = squares[i]
        if s <= 1e-12:
            continue
        r = s * 0.5
        if cx - r < -1e-7 or cx + r > 1.0 + 1e-7:
            return False
        if cy - r < -1e-7 or cy + r > 1.0 + 1e-7:
            return False
    for i in range(len(squares)):
        if squares[i][3] <= 1e-12:
            continue
        for j in range(i + 1, len(squares)):
            if squares[j][3] <= 1e-12:
                continue
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _post_refine(squares):
    """Uniform scale about center, then greedy per-square grow."""
    if not squares:
        return squares
    # --- uniform scale via binary search ---
    lo, hi = 1.0, 1.0
    # find upper bound
    for _ in range(60):
        hi *= 1.1
        if hi > 5.0:
            break
        scaled = [(0.5 + (cx - 0.5) * hi, 0.5 + (cy - 0.5) * hi, a, s * hi)
                  for (cx, cy, a, s) in squares]
        if not _layout_valid(scaled):
            break
        lo = hi
    if lo > 1.0:
        best_scale = lo
        for _ in range(50):
            mid = (lo + hi) / 2
            scaled = [(0.5 + (cx - 0.5) * mid, 0.5 + (cy - 0.5) * mid,
                       a, s * mid) for (cx, cy, a, s) in squares]
            if _layout_valid(scaled):
                lo = mid
                best_scale = mid
            else:
                hi = mid
        squares = [(0.5 + (cx - 0.5) * best_scale,
                    0.5 + (cy - 0.5) * best_scale, a, s * best_scale)
                   for (cx, cy, a, s) in squares]

    # --- greedy per-square growth ---
    for _ in range(6):
        improved = False
        for i in range(len(squares)):
            cx, cy, a, s = squares[i]
            if s <= 1e-12:
                continue
            # max allowed half-size from unit box
            maxs = min(cx, 1.0 - cx, cy, 1.0 - cy) * 2.0
            for j in range(len(squares)):
                if j == i or squares[j][3] <= 1e-12:
                    continue
                ox, oy, oa, os_ = squares[j]
                # limit from this neighbor on x and y
                dx = abs(cx - ox) - os_ * 0.5
                dy = abs(cy - oy) - os_ * 0.5
                if dx >= 0 and dy >= 0:
                    continue
                if dx >= 0:
                    lim = 2.0 * dy
                elif dy >= 0:
                    lim = 2.0 * dx
                else:
                    lim = 2.0 * max(dx, dy)
                if lim < maxs:
                    maxs = lim
            if maxs > s + 1e-9:
                squares[i] = (cx, cy, a, maxs)
                improved = True
        if not improved:
            break
    return squares


def _coord_refine3(n, nb, ns1, ns2, init_fw, init_fh, budget=40):
    """Coordinate-descent refinement of (fw, fh) for the 3-region layout."""
    cfw, cfh = init_fw, init_fh
    best = _layout3(n, nb, ns1, ns2, cfw, cfh)
    best_t = best[0] if best else -1.0
    step = 0.08
    for _ in range(budget):
        improved = False
        for dfw in (-step, 0.0, step):
            for dfh in (-step, 0.0, step):
                nfw = cfw + dfw
                nfh = cfh + dfh
                if not (0.0 <= nfw <= 1.0 and 0.0 <= nfh <= 1.0):
                    continue
                r = _layout3(n, nb, ns1, ns2, nfw, nfh)
                if r and r[0] > best_t + 1e-12:
                    best_t = r[0]
                    best = r
                    cfw, cfh = nfw, nfh
                    improved = True
        if not improved:
            step *= 0.5
            if step < 1e-4:
                break
    return best_t, best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_total = -1.0
    best_squares = None

    # ---- two-region search (cheap baseline) ----
    for n_big in range(1, n + 1):
        for vertical in (True, False):
            lo, hi = 0.01, 0.99
            for _ in range(40):
                m1 = lo + (hi - lo) / 3
                m2 = hi - (hi - lo) / 3
                r1 = _layout(n, n_big, m1, vertical)
                r2 = _layout(n, n_big, m2, vertical)
                t1 = r1[0] if r1 else -1
                t2 = r2[0] if r2 else -1
                if t1 >= t2:
                    hi = m2
                else:
                    lo = m1
            for f in (lo, (lo + hi) / 2, hi):
                r = _layout(n, n_big, f, vertical)
                if r and r[0] > best_total:
                    best_total = r[0]
                    best_squares = r[1]

    # ---- three-region search ----
    for nb in range(0, n + 1):
        for ns1 in range(0, n - nb + 1):
            ns2 = n - nb - ns1
            if ns2 < 0:
                continue
            best_local = None
            for fi in range(1, 10):
                fw = fi / 10.0
                for fj in range(1, 10):
                    fh = fj / 10.0
                    r = _layout3(n, nb, ns1, ns2, fw, fh)
                    if r and (best_local is None or r[0] > best_local[0]):
                        best_local = (r[0], fw, fh)
            if best_local is None:
                continue
            tl, r = _coord_refine3(n, nb, ns1, ns2, best_local[1], best_local[2])
            if r and tl > best_total:
                best_total = tl
                best_squares = r[1]

    # ---- four-region search (top strip split into two) ----
    for nb in range(0, n + 1):
        for ns1 in range(0, n - nb + 1):
            rem = n - nb - ns1
            if rem < 0:
                continue
            for ns2a in range(0, rem + 1):
                ns2b = rem - ns2a
                best_local = None
                for fi in range(1, 6):
                    fw = fi / 6.0
                    for fj in range(1, 6):
                        fh = fj / 6.0
                        r = _layout3(n, nb, ns1, rem, fw, fh)
                        if r and (best_local is None or r[0] > best_local[0]):
                            best_local = (r[0], fw, fh)
                if best_local is None:
                    continue
                cfw, cfh = best_local[1], best_local[2]
                best4 = None
                for gi in range(1, 10):
                    g = gi / 10.0
                    r = _layout4(n, nb, ns1, ns2a, ns2b, cfw, cfh, g)
                    if r and (best4 is None or r[0] > best4[0]):
                        best4 = (r[0], cfw, cfh, g)
                if best4 is None:
                    continue
                bfw, bfh, bg = best4[1], best4[2], best4[3]
                step = 0.06
                for _ in range(30):
                    improved = False
                    for dfw in (-step, 0.0, step):
                        for dfh in (-step, 0.0, step):
                            for dg in (-step, 0.0, step):
                                nfw = bfw + dfw
                                nfh = bfh + dfh
                                ng = bg + dg
                                if not (0.0 <= nfw <= 1.0 and 0.0 <= nfh <= 1.0
                                        and 0.0 <= ng <= 1.0):
                                    continue
                                r = _layout4(n, nb, ns1, ns2a, ns2b,
                                             nfw, nfh, ng)
                                if r and r[0] > best4[0] + 1e-12:
                                    best4 = (r[0], nfw, nfh, ng)
                                    bfw, bfh, bg = nfw, nfh, ng
                                    improved = True
                    if not improved:
                        step *= 0.5
                        if step < 1e-4:
                            break
                if best4[0] > best_total:
                    r = _layout4(n, nb, ns1, ns2a, ns2b, bfw, bfh, bg)
                    if r:
                        best_total = r[0]
                        best_squares = r[1]

    # ---- five-region search (right column split + corner) ----
    for nb in range(0, n + 1):
        for ns1 in range(0, n - nb + 1):
            rem = n - nb - ns1
            if rem < 0:
                continue
            for ns2a in range(0, rem + 1):
                nsc = rem - ns2a
                best_local = None
                for fi in range(1, 6):
                    fw = fi / 6.0
                    for fj in range(1, 6):
                        fh = fj / 6.0
                        for gk in range(1, 6):
                            gy = gk / 6.0
                            r = _layout5(n, nb, ns1, ns2a, nsc,
                                         fw, fh, 0.0, gy)
                            if r and (best_local is None
                                      or r[0] > best_local[0]):
                                best_local = (r[0], fw, fh, gy)
                if best_local is None:
                    continue
                bfw, bfh, bgy = best_local[1], best_local[2], best_local[3]
                step = 0.06
                for _ in range(30):
                    improved = False
                    for dfw in (-step, 0.0, step):
                        for dfh in (-step, 0.0, step):
                            for dgy in (-step, 0.0, step):
                                nfw = bfw + dfw
                                nfh = bfh + dfh
                                ngy = bgy + dgy
                                if not (0.0 <= nfw <= 1.0 and 0.0 <= nfh <= 1.0
                                        and 0.0 <= ngy <= 1.0):
                                    continue
                                r = _layout5(n, nb, ns1, ns2a, nsc,
                                             nfw, nfh, 0.0, ngy)
                                if r and r[0] > best_local[0] + 1e-12:
                                    best_local = (r[0], nfw, nfh, ngy)
                                    bfw, bfh, bgy = nfw, nfh, ngy
                                    improved = True
                    if not improved:
                        step *= 0.5
                        if step < 1e-4:
                            break
                if best_local[0] > best_total:
                    r = _layout5(n, nb, ns1, ns2a, nsc, bfw, bfh, 0.0, bgy)
                    if r:
                        best_total = r[0]
                        best_squares = r[1]

    if best_squares is None:
        k = math.isqrt(n)
        s = 1.0 / k
        best_squares = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                        for i in range(k) for j in range(k)]
        while len(best_squares) < n:
            best_squares.append((0.5, 0.5, 0.0, 0.0))

    best_squares = _post_refine(best_squares)
    while len(best_squares) < n:
        best_squares.append((0.5, 0.5, 0.0, 0.0))
    return best_squares[:n]
# EVOLVE-BLOCK-END
