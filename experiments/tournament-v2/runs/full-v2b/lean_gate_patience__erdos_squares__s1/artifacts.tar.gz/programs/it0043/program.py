import math
import random

# EVOLVE-BLOCK-START

# ---------------- geometry helpers ----------------

def _corners(cx, cy, ang, side):
    th = 2.0 * math.pi * ang
    c, s = math.cos(th), math.sin(th)
    h = 0.5 * side
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for (lx, ly) in pts:
        out.append((cx + lx * c - ly * s, cy + lx * s + ly * c))
    return out


def _separated(a, b):
    for poly in (a, b):
        m = len(poly)
        for i in range(m):
            p0 = poly[i]
            p1 = poly[(i + 1) % m]
            nx = -(p1[1] - p0[1])
            ny = (p1[0] - p0[0])
            n = math.hypot(nx, ny)
            if n < 1e-15:
                continue
            nx /= n
            ny /= n
            pa = [pt[0] * nx + pt[1] * ny for pt in a]
            pb = [pt[0] * nx + pt[1] * ny for pt in b]
            if max(pa) <= min(pb) + 1e-9 or max(pb) <= min(pa) + 1e-9:
                return True
    return False


def _in_box(corners, box=1.0, eps=1e-9):
    for (x, y) in corners:
        if x < -eps or x > box + eps or y < -eps or y > box + eps:
            return False
    return True


def _is_valid(sqs):
    n = len(sqs)
    polys = []
    for (cx, cy, ang, side) in sqs:
        if not (0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0 and 0.0 <= ang <= 1.0):
            return False
        if not (0.0 <= side <= 1.0):
            return False
        cs = _corners(cx, cy, ang, side)
        if not _in_box(cs):
            return False
        polys.append(cs)
    for i in range(n):
        for j in range(i + 1, n):
            if not _separated(polys[i], polys[j]):
                return False
    return True


# ---------------- soft-penalty optimizer ----------------

def _soft_optimize(sqs, steps=400, seed=0):
    """Differentiable packing: allow overlaps, minimize a penalty; centers/sizes
    pulled to enlarge. Uses scipy L-BFGS-B with numerical gradients via autograd-free
    finite differences would be slow, so we compute analytic-ish gradient using numpy.
    We instead use a simpler approach: full parametric optimizer with scipy 'Nelder-Mead'
    would be too slow; use randomized coordinate growth with soft overlap tolerance.
    """
    try:
        import numpy as np
        from scipy.optimize import minimize
    except Exception:
        return sqs

    n = len(sqs)
    if n == 0:
        return sqs

    # parametrize: for each square cx, cy, ang, side
    x0 = np.zeros(4 * n)
    for i, (cx, cy, ang, sd) in enumerate(sqs):
        x0[4 * i] = cx
        x0[4 * i + 1] = cy
        x0[4 * i + 2] = ang
        x0[4 * i + 3] = sd

    # We'll use a soft penalty: sum of pairwise penetration depths + box violation.
    # Squares approximated as axis-aligned-ish via SAT projection onto a fixed set of axes
    # plus penalty for being outside. Use a "circle" relaxation? Better: exact SAT with
    # soft max. Implement pairwise soft separation using corners and 4 axes (2 per square),
    # using smooth-max/max. We approximate penetration as max(0, overlap).
    LXP = np.array([-1.0, 1.0, 1.0, -1.0])
    LYP = np.array([-1.0, -1.0, 1.0, 1.0])

    def corners_of(x):
        p = x.reshape(n, 4)
        cx = p[:, 0]; cy = p[:, 1]; ang = p[:, 2]; sd = p[:, 3]
        th = 2.0 * math.pi * ang
        c = np.cos(th); s = np.sin(th)
        h = 0.5 * sd
        X = cx[:, None] + h[:, None] * (LXP[None, :] * c[:, None] - LYP[None, :] * s[:, None])
        Y = cy[:, None] + h[:, None] * (LXP[None, :] * s[:, None] + LYP[None, :] * c[:, None])
        return X, Y

    def penalty(x):
        p = x.reshape(n, 4)
        cx = p[:, 0]; cy = p[:, 1]; ang = p[:, 2]; sd = p[:, 3]
        pen = 0.0
        # box penalty
        X, Y = corners_of(x)
        for arr in (X, Y):
            pen += np.sum(np.maximum(0.0, arr - 1.0)) ** 2
            pen += np.sum(np.maximum(0.0, -arr)) ** 2
        # overlap penalty via SAT: for each pair project corners on 4 candidate axes
        th = 2.0 * math.pi * ang
        c = np.cos(th); s = np.sin(th)
        # Build per-square two axes (cos,sin) and (-sin,cos)
        AX = np.stack([c, -s], axis=1)  # n,2
        AY = np.stack([s, c], axis=1)   # n,2
        for i in range(n):
            for j in range(i + 1, n):
                # candidate axes: 4
                for (nx, ny) in ((AX[i,0], AY[i,0]), (AX[i,1], AY[i,1]),
                                 (AX[j,0], AY[j,0]), (AX[j,1], AY[j,1])):
                    pi = X[i]*nx + Y[i]*ny
                    pj = X[j]*nx + Y[j]*ny
                    hi_i = pi.max(); lo_i = pi.min()
                    hi_j = pj.max(); lo_j = pj.min()
                    # gap: positive means separated
                    g1 = lo_j - hi_i
                    g2 = lo_i - hi_j
                    g = max(g1, g2)
                    if g < 0:
                        pen += g * g
        # maximize sum of sides => negative
        total = sd.sum()
        return pen * 50.0 - total

    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((1e-4, 1.0))

    try:
        res = minimize(penalty, x0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': steps, 'ftol': 1e-10, 'gtol': 1e-7})
        xb = res.x
    except Exception:
        return sqs

    p = xb.reshape(n, 4)
    out = []
    for i in range(n):
        out.append([min(1.0, max(0.0, float(p[i,0]))),
                    min(1.0, max(0.0, float(p[i,1]))),
                    p[i,2] % 1.0,
                    max(0.0, float(p[i,3]))])
    # repair: shrink squares until valid
    for _ in range(200):
        if _is_valid(out):
            return out
        for s in out:
            s[3] *= 0.98
    return sqs


def _grow_polish(sqs, iters=60):
    n = len(sqs)
    best = [list(s) for s in sqs]
    rng = random.Random(987)
    for it in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, sd = best[i]
            for dgrow in (0.03, 0.015, 0.007, 0.003, 0.001):
                for dxy in ((0, 0), (0.02, 0), (-0.02, 0), (0, 0.02), (0, -0.02),
                            (0.01, 0.01), (-0.01, 0.01), (0.01, -0.01), (-0.01, -0.01)):
                    ncx = min(1.0, max(0.0, cx + dxy[0]))
                    ncy = min(1.0, max(0.0, cy + dxy[1]))
                    nsd = sd + dgrow
                    if nsd > 1.0:
                        continue
                    test = [list(s) for s in best]
                    test[i] = [ncx, ncy, ang, nsd]
                    if _is_valid(test):
                        best = test
                        improved = True
                        break
                if improved:
                    break
        if not improved:
            break
    return best


def _angle_polish(sqs, iters=40):
    """Try small angle changes and center moves together for each square."""
    n = len(sqs)
    best = [list(s) for s in sqs]
    rng = random.Random(12345)
    for it in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, sd = best[i]
            for dth in (0.02, -0.02, 0.01, -0.01, 0.005, -0.005):
                for dg in (0.01, 0.005, 0.002, 0.0):
                    nang = (ang + dth) % 1.0
                    nsd = min(1.0, sd + dg)
                    test = [list(s) for s in best]
                    test[i] = [cx, cy, nang, nsd]
                    if _is_valid(test):
                        best = test
                        improved = True
                        break
                if improved:
                    break
        if not improved:
            break
    return best


# ---------------- seeds ----------------

def _seed_grid(n, rot=0.0):
    k = max(1, int(math.isqrt(n)))
    while k * k > n:
        k -= 1
    cells = []
    side = 1.0 / k
    for i in range(k):
        for j in range(k):
            cells.append([(i + 0.5) * side, (j + 0.5) * side, rot, side])
    while len(cells) < n:
        idx = max(range(len(cells)), key=lambda t: cells[t][3])
        cx, cy, ang, sd = cells[idx]
        hs = sd / 2.0
        a = [cx - hs / 2.0, cy, ang, sd / 2.0]
        b = [cx + hs / 2.0, cy, ang, sd / 2.0]
        cells[idx] = a
        cells.append(b)
    return cells[:n]


def _seed_grid2(n):
    best = None
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if cols * rows < n:
            continue
        w = 1.0 / cols
        h = 1.0 / rows
        s = min(w, h)
        cells = []
        count = 0
        for r in range(rows):
            for c in range(cols):
                if count >= n:
                    break
                cells.append([(c + 0.5) * w, (r + 0.5) * h, 0.0, s])
                count += 1
        if count == n:
            score = n * s
            if best is None or score > best[0]:
                best = (score, cells)
    return best[1] if best else _seed_grid(n)


def _seed_one_big(n):
    best = None
    k = max(1, int(math.isqrt(n - 1)))
    while k * k > n - 1:
        k -= 1
    m = n - 1
    for big in (0.5, 0.55, 0.6, 0.65, 0.7, 0.75):
        cells = [[big / 2.0, big / 2.0, 0.0, big * 0.98]]
        m_rem = m
        if m_rem <= 0:
            continue
        bandR = (1.0 - big)
        count = 0
        cells_f = []
        nb = bandR
        if nb > 1e-6:
            fc = max(1, int(math.floor(1.0 / max(nb, 1e-6))))
            fr = max(1, m_rem // fc)
            sz = min(1.0 / fc, nb / max(1, fr))
            for j in range(fr):
                for i in range(fc):
                    if count >= m_rem:
                        break
                    cells_f.append([(i + 0.5) * (1.0 / fc), big + (j + 0.5) * (nb / fr), 0.0, sz])
                    count += 1
        if count < m_rem:
            fc = max(1, m_rem - count)
            sz = min(bandR / fc, big)
            for i in range(fc):
                cells_f.append([big + (i + 0.5) * (bandR / fc), big / 2.0, 0.0, sz])
                count += 1
        for c in cells_f:
            cells.append(c)
        cells = cells[:n]
        while len(cells) < n:
            cells.append([0.5, 0.5, 0.0, 0.0])
        total = sum(s[3] for s in cells)
        if best is None or total > best[0]:
            best = (total, cells)
    return best[1] if best else _seed_grid(n)


def _shrink_grow(sqs, rounds=3):
    best = [list(s) for s in sqs]
    for r in range(rounds):
        t = [list(s) for s in best]
        for s in t:
            s[3] *= 0.88
        t = _soft_optimize(t, steps=250)
        t = _grow_polish(t, iters=50)
        t = _angle_polish(t, iters=40)
        t = _grow_polish(t, iters=50)
        if sum(s[3] for s in t) > sum(s[3] for s in best):
            best = t
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    seeds = []
    seeds.append(_seed_grid(n))
    seeds.append(_seed_grid2(n))
    seeds.append(_seed_one_big(n))
    base = _seed_grid(n)
    for s in base:
        s[3] *= 0.6
    seeds.append([list(s) for s in base])
    # rotated fillers variant
    sg = _seed_grid(n)
    for s in sg:
        s[2] = 0.25
    seeds.append(sg)

    best = None
    best_sum = -1.0
    for sd in seeds:
        t = [list(s) for s in sd]
        tries = 0
        while not _is_valid(t) and tries < 40:
            for s in t:
                s[3] *= 0.9
            tries += 1
        if not _is_valid(t):
            continue
        t = _grow_polish(t, iters=80)
        t = _soft_optimize(t, steps=300)
        if not _is_valid(t):
            t = [list(s) for s in sd]
            for s in t:
                s[3] *= 0.9
        t = _grow_polish(t, iters=80)
        t = _angle_polish(t, iters=50)
        t = _shrink_grow(t, rounds=2)
        if not _is_valid(t):
            continue
        ssum = sum(s[3] for s in t)
        if ssum > best_sum:
            best_sum = ssum
            best = t

    if best is None:
        best = _seed_grid(n)
        for s in best:
            s[3] *= 0.5

    tries = 0
    while not _is_valid(best) and tries < 40:
        for s in best:
            s[3] *= 0.9
            s[0] = min(1.0, max(0.0, s[0]))
            s[1] = min(1.0, max(0.0, s[1]))
        tries += 1

    return [(float(cx), float(cy), float(ang), float(sd)) for (cx, cy, ang, sd) in best]


# EVOLVE-BLOCK-END
