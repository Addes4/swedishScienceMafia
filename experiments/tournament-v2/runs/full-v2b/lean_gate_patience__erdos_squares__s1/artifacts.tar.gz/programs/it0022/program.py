# EVOLVE-BLOCK-START
"""Hierarchical grid + soft-repulsion packing optimizer.

Strategy:
  1. Build a good initial layout: a square-ish grid of k x k squares whose side
     is chosen as large as possible, then distribute any remainder as smaller
     squares or size-0 points.
  2. Refine with scipy.optimize.minimize over (cx, cy, angle, side) using a
     smooth differentiable objective that rewards total side length while
     penalising overlaps (via a soft distance measure between rotated squares).
  3. Run several restarts (varied initial layouts / random perturbations), keep
     the best feasible configuration, and finally repair any residual overlaps
     deterministically so the returned solution is valid.
"""
import math
import random
import numpy as np
from scipy.optimize import minimize


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _corners(cx, cy, angle, side):
    """Return the 4 corners of a rotated square as an array (4, 2)."""
    a = angle * 2.0 * math.pi
    c, s = math.cos(a), math.sin(a)
    h = side * 0.5
    # local corners
    pts = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    R = np.array([[c, -s], [s, c]], dtype=float)
    return pts @ R.T + np.array([cx, cy])


def _axes(angle):
    a = angle * 2.0 * math.pi
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, s], [-s, c]], dtype=float)


def _overlap_signed(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Signed separation for two rotated squares using SAT.

    Returns a negative number if the squares strictly overlap, zero if they
    just touch, positive otherwise.  It is a smooth approximation to the
    separation along the minimum-overlap axis.
    """
    if s1 <= 0.0 or s2 <= 0.0:
        return 1.0
    A = _axes(a1)
    B = _axes(a2)
    axes = np.concatenate([A, B], axis=0)  # (4, 2)
    c1 = _corners(cx1, cy1, a1, s1)
    c2 = _corners(cx2, cy2, a2, s2)
    # project both onto each axis
    best = 1e18
    for ax in axes:
        p1 = c1 @ ax
        p2 = c2 @ ax
        d = max(p1.min(), p2.min()) - min(p1.max(), p2.max())
        # d > 0 means separated on this axis; d < 0 means overlap
        if d > 0.0:
            # separated: SAT says no overlap, return positive margin
            return d
        if d > best - 1e18:
            pass
        if d > -best:
            # track the *largest* negative (i.e. least penetration axis)
            best = -d if False else best
    # all axes overlap; return the least penetration (maximum of d values)
    dmax = None
    for ax in axes:
        p1 = c1 @ ax
        p2 = c2 @ ax
        d = max(p1.min(), p2.min()) - min(p1.max(), p2.max())
        if dmax is None or d > dmax:
            dmax = d
    return dmax if dmax is not None else 0.0


def _penetration(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Amount of penetration (positive if overlapping)."""
    if s1 <= 0.0 or s2 <= 0.0:
        return 0.0
    A = _axes(a1)
    B = _axes(a2)
    axes = np.concatenate([A, B], axis=0)
    c1 = _corners(cx1, cy1, a1, s1)
    c2 = _corners(cx2, cy2, a2, s2)
    pen = np.inf
    sep = False
    for ax in axes:
        p1 = c1 @ ax
        p2 = c2 @ ax
        d = max(p1.min(), p2.min()) - min(p1.max(), p2.max())
        if d > 0.0:
            sep = True
            break
        pen = min(pen, -d)
    return 0.0 if sep else pen


def _pairs(n):
    return [(i, j) for i in range(n) for j in range(i + 1, n)]


# ---------------------------------------------------------------------------
# Feasibility repair
# ---------------------------------------------------------------------------

def _repair(squares, iters=400):
    """Shrink/separate squares until no interiors overlap.

    squares: list of [cx, cy, angle, side]
    Mutates in place and returns it.
    """
    sq = [list(s) for s in squares]
    n = len(sq)
    if n == 0:
        return sq
    # ensure inside [0,1]
    for s in sq:
        s[0] = min(max(s[0], 0.0), 1.0)
        s[1] = min(max(s[1], 0.0), 1.0)
        if s[3] < 0.0:
            s[3] = 0.0

    # first pass: scale down to fit in the unit box
    for s in sq:
        if s[3] <= 0.0:
            continue
        A = _axes(s[2])
        c = _corners(*s)
        mx = max(abs(p[0] - 0.5) for p in c)
        my = max(abs(p[1] - 0.5) for p in c)
        need = max(mx * 2.0, my * 2.0)
        if need > 1.0:
            s[3] *= 1.0 / need
            s[0] = min(max(s[0], 0.0), 1.0)
            s[1] = min(max(s[1], 0.0), 1.0)

    for _ in range(iters):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                si, sj = sq[i], sq[j]
                if si[3] <= 0.0 or sj[3] <= 0.0:
                    continue
                pen = _penetration(si[0], si[1], si[2], si[3],
                                   sj[0], sj[1], sj[2], sj[3])
                if pen > 1e-9:
                    changed = True
                    # shrink the larger one until separated
                    s_big = si if si[3] >= sj[3] else sj
                    s_small = sj if s_big is si else si
                    # try shifting apart along centre line
                    dx = sj[0] - si[0]
                    dy = sj[1] - si[1]
                    dist = math.hypot(dx, dy)
                    if dist < 1e-9:
                        dx, dy, dist = 1.0, 0.0, 1.0
                    shift = pen * 0.55
                    ux, uy = dx / dist, dy / dist
                    si[0] -= ux * shift
                    si[1] -= uy * shift
                    sj[0] += ux * shift
                    sj[1] += uy * shift
                    # clamp
                    si[0] = min(max(si[0], 0.0), 1.0)
                    si[1] = min(max(si[1], 0.0), 1.0)
                    sj[0] = min(max(sj[0], 0.0), 1.0)
                    sj[1] = min(max(sj[1], 0.0), 1.0)
                    # if still overlapping, shrink
                    pen2 = _penetration(si[0], si[1], si[2], si[3],
                                        sj[0], sj[1], sj[2], sj[3])
                    if pen2 > 1e-9:
                        shrink = max(0.0, 1.0 - (pen2 / max(s_big[3], 1e-9)) * 1.05)
                        s_big[3] *= shrink
        if not changed:
            break
    return sq


# ---------------------------------------------------------------------------
# Objective for optimizer
# ---------------------------------------------------------------------------

def _decode(x, n):
    """x has length 4*n -> list of [cx,cy,angle,side]."""
    sq = []
    for i in range(n):
        cx = x[4 * i]
        cy = x[4 * i + 1]
        ang = x[4 * i + 2]
        side = x[4 * i + 3]
        sq.append([cx, cy, ang, side])
    return sq


def _make_objective(n, pairs, lam):
    """Return objective f(x) and gradient-free wrapper.

    Objective: -sum(side) + lam * sum(penalty over pairs) + boundary penalty.
    Penalty is smooth-ish: max(0, -separation)^2.
    """
    def f(x):
        sq = _decode(x, n)
        # clamp implicit (bounds handle most)
        total = 0.0
        for s in sq:
            total -= max(s[3], 0.0)
        pen = 0.0
        for (i, j) in pairs:
            si, sj = sq[i], sq[j]
            if si[3] <= 0.0 or sj[3] <= 0.0:
                continue
            p = _penetration(si[0], si[1], si[2], si[3],
                             sj[0], sj[1], sj[2], sj[3])
            if p > 0.0:
                pen += p * p
        # boundary: keep corners inside [0,1]^2
        bpen = 0.0
        for s in sq:
            if s[3] <= 0.0:
                continue
            c = _corners(*s)
            for p in c:
                if p[0] < 0.0:
                    bpen += p[0] * p[0]
                elif p[0] > 1.0:
                    bpen += (p[0] - 1.0) ** 2
                if p[1] < 0.0:
                    bpen += p[1] * p[1]
                elif p[1] > 1.0:
                    bpen += (p[1] - 1.0) ** 2
        return total + lam * pen + lam * 4.0 * bpen
    return f


# ---------------------------------------------------------------------------
# Initial layouts
# ---------------------------------------------------------------------------

def _grid_layout(n, rng):
    """Square-ish grid; leftover squares sized smaller and placed greedily."""
    k = max(1, int(math.ceil(math.sqrt(n))))
    # try grid sizes around sqrt(n)
    best = None
    for kk in range(1, k + 2):
        if kk * kk >= n:
            side = 1.0 / kk
            sq = []
            for i in range(kk):
                for j in range(kk):
                    sq.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
            # fill remaining by small squares in gaps (just append size-0 here)
            while len(sq) < n:
                sq.append([0.5, 0.5, 0.0, 0.0])
            best = sq[:n]
            if kk * kk == n:
                return best
    return best


def _grid_plus_extra(n, rng):
    """k x k grid for the smallest k with k*k <= n, then add leftovers."""
    if n <= 0:
        return []
    k = int(math.isqrt(n))
    if k == 0:
        return [[0.5, 0.5, 0.0, 0.0] for _ in range(n)]
    side = 1.0 / (k + 0.4)  # slight margin so extras fit
    sq = []
    for i in range(k):
        for j in range(k):
            sq.append([(i + 0.5) * side + (1.0 - k * side) * 0.5,
                       (j + 0.5) * side + (1.0 - k * side) * 0.5,
                       0.0, side])
    extra = n - k * k
    # place extras along remaining strip, small
    if extra > 0:
        strip = 1.0 - k * side
        # choose small extra side
        es = min(side, strip / max(extra, 1) * 0.9) if strip > 0 else side * 0.3
        for t in range(extra):
            ex = (t + 0.5) / extra
            # place in bottom strip
            sq.append([ex, 1.0 - strip * 0.5, 0.0, min(es, strip * 0.9)])
    return sq


def _random_layout(n, rng):
    sq = []
    for _ in range(n):
        side = rng.uniform(0.02, 0.4)
        cx = rng.uniform(side * 0.5, 1.0 - side * 0.5)
        cy = rng.uniform(side * 0.5, 1.0 - side * 0.5)
        ang = rng.uniform(0.0, 1.0)
        sq.append([cx, cy, ang, side])
    return sq


# ---------------------------------------------------------------------------
# Main optimizer
# ---------------------------------------------------------------------------

def _optimize_layout(init, n, time_budget_pairs=2, lam=50.0):
    """Refine a layout with L-BFGS-B (or SLSQP) on soft penalty."""
    pairs = _pairs(n)
    if n == 0:
        return [], 0.0
    x0 = np.zeros(4 * n, dtype=float)
    for i, s in enumerate(init):
        x0[4 * i] = s[0]
        x0[4 * i + 1] = s[1]
        x0[4 * i + 2] = s[2]
        x0[4 * i + 3] = s[3]
    lb = np.zeros(4 * n)
    ub = np.ones(4 * n)
    f = _make_objective(n, pairs, lam)
    try:
        res = minimize(f, x0, method="L-BFGS-B", bounds=list(zip(lb, ub)),
                       options={"maxiter": 300, "ftol": 1e-10, "gtol": 1e-8})
        xs = res.x
    except Exception:
        xs = x0
    sq = _decode(xs, n)
    return sq, -f(xs)


def _total_side(sq):
    return sum(max(0.0, s[3]) for s in sq)


def _is_feasible(sq, tol=1e-7):
    n = len(sq)
    for i in range(n):
        for j in range(i + 1, n):
            if sq[i][3] <= 0.0 or sq[j][3] <= 0.0:
                continue
            if _penetration(sq[i][0], sq[i][1], sq[i][2], sq[i][3],
                            sq[j][0], sq[j][1], sq[j][2], sq[j][3]) > tol:
                return False
    return True


def solve(n):
    """Return n squares (cx, cy, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(1234567 + n)
    best_sq = None
    best_val = -1.0

    candidates = []
    candidates.append(_grid_layout(n, rng))
    candidates.append(_grid_plus_extra(n, rng))
    # a few randomized variants of the grid layout
    base = _grid_layout(n, rng)
    for _ in range(3):
        sq = [list(s) for s in base]
        for s in sq:
            s[0] += rng.uniform(-0.03, 0.03)
            s[1] += rng.uniform(-0.03, 0.03)
            s[2] += rng.uniform(-0.05, 0.05)
            s[3] *= rng.uniform(0.9, 1.05)
            s[0] = min(max(s[0], 0.0), 1.0)
            s[1] = min(max(s[1], 0.0), 1.0)
            s[3] = min(s[3], 1.0)
        candidates.append(sq)
    candidates.append(_random_layout(n, rng))

    # refine each candidate
    for init in candidates:
        sq, val = _optimize_layout(init, n)
        rep = _repair(sq)
        if not _is_feasible(rep, 1e-6):
            rep = _repair(rep, 800)
        v = _total_side(rep)
        # only accept genuinely feasible ones
        if _is_feasible(rep, 1e-5) and v > best_val:
            best_val = v
            best_sq = rep

    if best_sq is None:
        best_sq = _repair(_grid_layout(n, rng), 800)
        if not _is_feasible(best_sq, 1e-5):
            # fall back to grid scaled
            best_sq = []
            k = int(math.isqrt(n))
            if k == 0:
                k = 1
            side = 1.0 / k
            for i in range(k):
                for j in range(k):
                    best_sq.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
            while len(best_sq) < n:
                best_sq.append([0.5, 0.5, 0.0, 0.0])
            best_sq = best_sq[:n]

    # final safety: clamp everything
    out = []
    for s in best_sq[:n]:
        cx = min(max(s[0], 0.0), 1.0)
        cy = min(max(s[1], 0.0), 1.0)
        ang = s[2] % 1.0
        side = max(0.0, min(s[3], 1.0))
        # verify inside
        c = _corners(cx, cy, ang, side)
        inside = all(0.0 <= p[0] <= 1.0 and 0.0 <= p[1] <= 1.0 for p in c)
        if not inside:
            # shrink to fit
            mx = max(max(abs(p[0] - 0.5) for p in c) * 2.0,
                     max(abs(p[1] - 0.5) for p in c) * 2.0)
            if mx > 1.0 and side > 0.0:
                side *= 1.0 / mx
                c = _corners(cx, cy, ang, side)
        out.append((cx, cy, ang, side))

    # if any overlap remains, do a final repair then verify
    if not _is_feasible(out, 1e-6):
        out = _repair(out, 1500)
        out = [(min(max(s[0], 0.0), 1.0),
                min(max(s[1], 0.0), 1.0),
                s[2] % 1.0,
                max(0.0, s[3])) for s in out[:n]]

    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))

    return out[:n]
# EVOLVE-BLOCK-END
