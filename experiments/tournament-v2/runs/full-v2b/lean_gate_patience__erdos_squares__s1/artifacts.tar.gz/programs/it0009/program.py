# EVOLVE-BLOCK-START
"""Squares in a unit square: maximise total side length.

Strategy: partition the unit square into up to five rectangular regions
(a main region plus a right strip, a top region that may be split into
two side-by-side sub-strips, and a small top-right corner block).
Each region is packed with equal squares via the best grid factorisation.
We search over the split fractions and the distribution of squares
between regions to maximise the total side sum; the best candidate is
then polished with a fine coordinate-descent, and finally a greedy
"grow" pass absorbs any slack left inside each region.
"""
import math


def _pack_grid(count, W, H):
    """Best equal-square grid for `count` squares inside a W x H box."""
    if count <= 0 or W <= 0 or H <= 0:
        return [], 0.0, 0
    best = None
    for a in range(1, count + 1):
        b = (count + a - 1) // a
        if a * b < count:
            continue
        s = min(W / a, H / b)
        total = s * count
        if best is None or total > best[0]:
            best = (total, a, b, s)
    if best is None:
        return [], 0.0, 0
    _, a, b, s = best
    sq = []
    used = 0
    for i in range(a):
        for j in range(b):
            if used >= count:
                break
            cx = (i + 0.5) * s
            cy = (j + 0.5) * s
            sq.append((cx, cy, 0.0, s))
            used += 1
        if used >= count:
            break
    return sq, s, used


def _layout3(n, nb, ns1, ns2, fw, fh):
    mw, mh = 1.0 - fw, 1.0 - fh
    rw, rh = fw, 1.0 - fh
    tw, th = 1.0, fh

    big, bs, used_big = _pack_grid(nb, mw, mh)
    if nb > 0 and used_big < nb:
        return None
    s1, ss1, u1 = _pack_grid(ns1, rw, rh)
    if ns1 > 0 and u1 < ns1:
        return None
    s2, ss2, u2 = _pack_grid(ns2, tw, th)
    if ns2 > 0 and u2 < ns2:
        return None

    squares = []
    for (cx, cy, a, s) in big:
        squares.append((cx, cy, a, s))
    ox1 = mw
    for (cx, cy, a, s) in s1:
        squares.append((cx + ox1, cy, a, s))
    oy2 = mh
    for (cx, cy, a, s) in s2:
        squares.append((cx, cy + oy2, a, s))

    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss1 * u1 + ss2 * u2
    return total, squares[:n]


def _layout4(n, nb, ns1, ns2a, ns2b, fw, fh, g):
    mw, mh = 1.0 - fw, 1.0 - fh
    rw, rh = fw, 1.0 - fh
    tlw, th = g, fh
    trw = 1.0 - g

    big, bs, used_big = _pack_grid(nb, mw, mh)
    if nb > 0 and used_big < nb:
        return None
    s1, ss1, u1 = _pack_grid(ns1, rw, rh)
    if ns1 > 0 and u1 < ns1:
        return None
    sa, ssa, ua = _pack_grid(ns2a, tlw, th)
    if ns2a > 0 and ua < ns2a:
        return None
    sb, ssb, ub = _pack_grid(ns2b, trw, th)
    if ns2b > 0 and ub < ns2b:
        return None

    squares = []
    for (cx, cy, a, s) in big:
        squares.append((cx, cy, a, s))
    ox1 = mw
    for (cx, cy, a, s) in s1:
        squares.append((cx + ox1, cy, a, s))
    oy2 = mh
    for (cx, cy, a, s) in sa:
        squares.append((cx, cy + oy2, a, s))
    for (cx, cy, a, s) in sb:
        squares.append((cx + g, cy + oy2, a, s))

    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss1 * u1 + ssa * ua + ssb * ub
    return total, squares[:n]


def _layout5(n, nb, ns1, ns2a, nsc, fw, fh, gx, gy):
    mw, mh = 1.0 - fw, 1.0 - fh
    rlw, rlh = fw, 1.0 - gy
    tsw, tsh = mw, fh
    cw, ch = fw, gy

    big, bs, used_big = _pack_grid(nb, mw, mh)
    if nb > 0 and used_big < nb:
        return None
    s1, ss1, u1 = _pack_grid(ns1, rlw, rlh)
    if ns1 > 0 and u1 < ns1:
        return None
    sa, ssa, ua = _pack_grid(ns2a, tsw, tsh)
    if ns2a > 0 and ua < ns2a:
        return None
    sc, ssc, uc = _pack_grid(nsc, cw, ch)
    if nsc > 0 and uc < nsc:
        return None

    squares = []
    for (cx, cy, a, s) in big:
        squares.append((cx, cy, a, s))
    ox1 = mw
    for (cx, cy, a, s) in s1:
        squares.append((cx + ox1, cy, a, s))
    oy2 = mh
    for (cx, cy, a, s) in sa:
        squares.append((cx, cy + oy2, a, s))
    oxc = mw
    oyc = 1.0 - gy
    for (cx, cy, a, s) in sc:
        squares.append((cx + oxc, cy + oyc, a, s))

    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss1 * u1 + ssa * ua + ssc * uc
    return total, squares[:n]


def _layout(n, n_big, split_frac, vertical):
    if vertical:
        fw = split_frac
        bw, bh = fw, 1.0
        sw, sh = 1.0 - fw, 1.0
    else:
        fh = split_frac
        bw, bh = 1.0, fh
        sw, sh = 1.0, 1.0 - fh

    big, bs, used_big = _pack_grid(n_big, bw, bh)
    if used_big < n_big:
        return None
    rest = n - n_big
    small, ss, used_small = _pack_grid(rest, sw, sh)

    squares = list(big)
    ox = bw if vertical else 0.0
    oy = 0.0 if vertical else bh
    for (cx, cy, a, s) in small:
        squares.append((cx + ox, cy + oy, a, s))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss * used_small
    return total, squares[:n]


def _coord_refine3(n, nb, ns1, ns2, init_fw, init_fh, budget=40):
    cfw, cfh = init_fw, init_fh
    best = _layout3(n, nb, ns1, ns2, cfw, cfh)
    best_t = best[0] if best else -1.0
    step = 0.08
    for _ in range(budget):
        improved = False
        for dfw in (-step, 0.0, step):
            for dfh in (-step, 0.0, step):
                nfw = cfw + dfw
                nfh = cfh + dfh
                if not (0.0 <= nfw <= 1.0 and 0.0 <= nfh <= 1.0):
                    continue
                r = _layout3(n, nb, ns1, ns2, nfw, nfh)
                if r and r[0] > best_t + 1e-12:
                    best_t = r[0]
                    best = r
                    cfw, cfh = nfw, nfh
                    improved = True
        if not improved:
            step *= 0.5
            if step < 1e-4:
                break
    return best_t, best


# ---------- overlap test (separating axis) and greedy grow ----------

def _corners(cx, cy, ang, s):
    """Return the 4 rotated corners of a square."""
    h = s * 0.5
    t = ang * 2.0 * math.pi
    ca, sa = math.cos(t), math.sin(t)
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + p[0] * ca - p[1] * sa, cy + p[0] * sa + p[1] * ca)
            for p in pts]


def _overlap(sq1, sq2):
    """True if two squares share an interior point (SAT)."""
    c1 = _corners(*sq1)
    c2 = _corners(*sq2)
    for poly in (c1, c2):
        for k in range(4):
            ax = poly[(k + 1) % 4][0] - poly[k][0]
            ay = poly[(k + 1) % 4][1] - poly[k][1]
            nlen = math.hypot(ax, ay)
            if nlen < 1e-15:
                continue
            ax /= nlen
            ay /= nlen
            p1 = [ax * p[0] + ay * p[1] for p in c1]
            p2 = [ax * p[0] + ay * p[1] for p in c2]
            if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
                return False
    return True


def _grow_squares(squares, tol=1e-9, rounds=6):
    """Greedily grow each square while keeping the layout valid."""
    sq = [list(s) for s in squares]
    n = len(sq)
    # prune exact duplicates / overlaps first by shrinking slightly
    for _ in range(rounds):
        improved = False
        for i in range(n):
            s = sq[i][3]
            if s <= 1e-12:
                # zero square: try to give it a tiny positive size
                base = 1e-4
            else:
                base = s * 0.02
            # try increasing the side of square i
            lo, hi = s, s + max(base, 1e-3)
            # exponential search for a feasible larger size
            best_s = s
            trial = hi
            for _k in range(24):
                if trial > 1.0:
                    break
                cand = [sq[i][0], sq[i][1], sq[i][2], trial]
                # must stay inside unit box (use corners)
                cs = _corners(*cand)
                ok = all(-1e-12 <= x <= 1.0 + 1e-12 and
                         -1e-12 <= y <= 1.0 + 1e-12 for (x, y) in cs)
                if ok:
                    for j in range(n):
                        if j == i:
                            continue
                        if sq[j][3] <= 1e-12:
                            continue
                        if _overlap(cand, sq[j]):
                            ok = False
                            break
                if ok:
                    best_s = trial
                    trial = s + (trial - s) * 1.8
                else:
                    break
            if best_s > s + 1e-12:
                sq[i][3] = best_s
                improved = True
        if not improved:
            break
    return [tuple(x) for x in sq]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_total = -1.0
    best_squares = None

    # ---- two-region search ----
    for n_big in range(1, n + 1):
        for vertical in (True, False):
            lo, hi = 0.01, 0.99
            for _ in range(40):
                m1 = lo + (hi - lo) / 3
                m2 = hi - (hi - lo) / 3
                r1 = _layout(n, n_big, m1, vertical)
                r2 = _layout(n, n_big, m2, vertical)
                t1 = r1[0] if r1 else -1
                t2 = r2[0] if r2 else -1
                if t1 >= t2:
                    hi = m2
                else:
                    lo = m1
            for f in (lo, (lo + hi) / 2, hi):
                r = _layout(n, n_big, f, vertical)
                if r and r[0] > best_total:
                    best_total = r[0]
                    best_squares = r[1]

    # ---- three-region search ----
    for nb in range(0, n + 1):
        for ns1 in range(0, n - nb + 1):
            ns2 = n - nb - ns1
            if ns2 < 0:
                continue
            best_local = None
            for fi in range(1, 10):
                fw = fi / 10.0
                for fj in range(1, 10):
                    fh = fj / 10.0
                    r = _layout3(n, nb, ns1, ns2, fw, fh)
                    if r and (best_local is None or r[0] > best_local[0]):
                        best_local = (r[0], fw, fh)
            if best_local is None:
                continue
            tl, r = _coord_refine3(n, nb, ns1, ns2, best_local[1], best_local[2])
            if r and tl > best_total:
                best_total = tl
                best_squares = r[1]

    # ---- four-region search ----
    for nb in range(0, n + 1):
        for ns1 in range(0, n - nb + 1):
            rem = n - nb - ns1
            if rem < 0:
                continue
            for ns2a in range(0, rem + 1):
                ns2b = rem - ns2a
                best_local = None
                for fi in range(1, 6):
                    fw = fi / 6.0
                    for fj in range(1, 6):
                        fh = fj / 6.0
                        r = _layout3(n, nb, ns1, rem, fw, fh)
                        if r and (best_local is None or r[0] > best_local[0]):
                            best_local = (r[0], fw, fh)
                if best_local is None:
                    continue
                cfw, cfh = best_local[1], best_local[2]
                cg = 0.5
                best4 = None
                for gi in range(1, 10):
                    g = gi / 10.0
                    r = _layout4(n, nb, ns1, ns2a, ns2b, cfw, cfh, g)
                    if r and (best4 is None or r[0] > best4[0]):
                        best4 = (r[0], cfw, cfh, g)
                if best4 is None:
                    continue
                bfw, bfh, bg = best4[1], best4[2], best4[3]
                step = 0.06
                for _ in range(30):
                    improved = False
                    for dfw in (-step, 0.0, step):
                        for dfh in (-step, 0.0, step):
                            for dg in (-step, 0.0, step):
                                nfw = bfw + dfw
                                nfh = bfh + dfh
                                ng = bg + dg
                                if not (0.0 <= nfw <= 1.0 and 0.0 <= nfh <= 1.0
                                        and 0.0 <= ng <= 1.0):
                                    continue
                                r = _layout4(n, nb, ns1, ns2a, ns2b,
                                             nfw, nfh, ng)
                                if r and r[0] > best4[0] + 1e-12:
                                    best4 = (r[0], nfw, nfh, ng)
                                    bfw, bfh, bg = nfw, nfh, ng
                                    improved = True
                    if not improved:
                        step *= 0.5
                        if step < 1e-4:
                            break
                if best4[0] > best_total:
                    r = _layout4(n, nb, ns1, ns2a, ns2b, bfw, bfh, bg)
                    if r:
                        best_total = r[0]
                        best_squares = r[1]

    # ---- five-region search ----
    for nb in range(0, n + 1):
        for ns1 in range(0, n - nb + 1):
            rem = n - nb - ns1
            if rem < 0:
                continue
            for ns2a in range(0, rem + 1):
                nsc = rem - ns2a
                best_local = None
                for fi in range(1, 6):
                    fw = fi / 6.0
                    for fj in range(1, 6):
                        fh = fj / 6.0
                        for gk in range(1, 6):
                            gy = gk / 6.0
                            r = _layout5(n, nb, ns1, ns2a, nsc,
                                         fw, fh, 0.0, gy)
                            if r and (best_local is None
                                      or r[0] > best_local[0]):
                                best_local = (r[0], fw, fh, gy)
                if best_local is None:
                    continue
                bfw, bfh, bgy = best_local[1], best_local[2], best_local[3]
                step = 0.06
                for _ in range(30):
                    improved = False
                    for dfw in (-step, 0.0, step):
                        for dfh in (-step, 0.0, step):
                            for dgy in (-step, 0.0, step):
                                nfw = bfw + dfw
                                nfh = bfh + dfh
                                ngy = bgy + dgy
                                if not (0.0 <= nfw <= 1.0 and 0.0 <= nfh <= 1.0
                                        and 0.0 <= ngy <= 1.0):
                                    continue
                                r = _layout5(n, nb, ns1, ns2a, nsc,
                                             nfw, nfh, 0.0, ngy)
                                if r and r[0] > best_local[0] + 1e-12:
                                    best_local = (r[0], nfw, nfh, ngy)
                                    bfw, bfh, bgy = nfw, nfh, ngy
                                    improved = True
                    if not improved:
                        step *= 0.5
                        if step < 1e-4:
                            break
                if best_local[0] > best_total:
                    r = _layout5(n, nb, ns1, ns2a, nsc, bfw, bfh, 0.0, bgy)
                    if r:
                        best_total = r[0]
                        best_squares = r[1]

    if best_squares is None:
        k = math.isqrt(n)
        s = 1.0 / k
        best_squares = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                        for i in range(k) for j in range(k)]
        while len(best_squares) < n:
            best_squares.append((0.5, 0.5, 0.0, 0.0))

    # ---- greedy grow pass to absorb slack ----
    try:
        grown = _grow_squares(best_squares)
        # sanity check validity
        ok = True
        for i in range(len(grown)):
            cs = _corners(*grown[i])
            for (x, y) in cs:
                if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
                    ok = False
                    break
            if not ok:
                break
        if ok:
            for i in range(len(grown)):
                for j in range(i + 1, len(grown)):
                    if grown[i][3] > 1e-12 and grown[j][3] > 1e-12:
                        if _overlap(grown[i], grown[j]):
                            ok = False
                            break
                if not ok:
                    break
        if ok and sum(g[3] for g in grown) > best_total - 1e-12:
            best_squares = grown
    except Exception:
        pass

    return best_squares[:n]
# EVOLVE-BLOCK-END

