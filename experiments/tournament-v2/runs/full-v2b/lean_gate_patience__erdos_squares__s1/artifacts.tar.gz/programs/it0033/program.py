# EVOLVE-BLOCK-START
"""Packing n rotated squares in the unit square, maximising sum of side lengths.

Strategy
--------
1. Multi-seed generator: axis-aligned grids, plus "one big square in a corner
   and a grid of equal small squares filling the leftover L-shape" seeds.
2. For each seed, refine with a fast custom routine that repeatedly tries to
   grow squares and pushes overlapping ones apart using the exact
   separating-axis test.
3. Final polish with scipy SLSQP: maximise sum of sides subject to exact
   separation constraints (4 SAT axes per pair) and containment constraints.
   Keep only feasible improvements.
"""
import math
import random
import time

import numpy as np
from scipy.optimize import minimize


# --------------------------------------------------------------------------
# geometry
# --------------------------------------------------------------------------

def _corners(cx, cy, ang, side):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side * 0.5
    return np.array([
        [cx + (-h * ca - (-h) * sa), cy + (-h * sa + (-h) * ca)],
        [cx + (h * ca - (-h) * sa),  cy + (h * sa + (-h) * ca)],
        [cx + (h * ca - h * sa),     cy + (h * sa + h * ca)],
        [cx + (-h * ca - h * sa),    cy + (-h * sa + h * ca)],
    ])


def _sat_overlap(ca, cb):
    polys = (ca, cb)
    best = float("inf")
    for poly in polys:
        m = len(poly)
        for i in range(m):
            p0 = poly[i]
            p1 = poly[(i + 1) % m]
            ex = p1[0] - p0[0]
            ey = p1[1] - p0[1]
            ax_x, ax_y = ey, -ex
            nn = math.hypot(ax_x, ax_y)
            if nn < 1e-15:
                continue
            ax_x /= nn
            ax_y /= nn
            d0 = ca[:, 0] * ax_x + ca[:, 1] * ax_y
            d1 = cb[:, 0] * ax_x + cb[:, 1] * ax_y
            ov = min(d0.max(), d1.max()) - max(d0.min(), d1.min())
            if ov <= 0.0:
                return 0.0
            if ov < best:
                best = ov
    return best if best != float("inf") else 0.0


def _inside_penalty(corners):
    lo = corners.min(axis=0)
    hi = corners.max(axis=0)
    pen = 0.0
    if lo[0] < 0.0:
        pen += -lo[0]
    if lo[1] < 0.0:
        pen += -lo[1]
    if hi[0] > 1.0:
        pen += hi[0] - 1.0
    if hi[1] > 1.0:
        pen += hi[1] - 1.0
    return pen


def _feasible(squares):
    n = len(squares)
    cs = [_corners(*s) for s in squares]
    for i in range(n):
        if _inside_penalty(cs[i]) > 1e-9:
            return False
        if squares[i][3] < -1e-12:
            return False
    for i in range(n):
        if squares[i][3] <= 0.0:
            continue
        for j in range(i + 1, n):
            if squares[j][3] <= 0.0:
                continue
            if _sat_overlap(cs[i], cs[j]) > 1e-9:
                return False
    return True


# --------------------------------------------------------------------------
# seeds
# --------------------------------------------------------------------------

def _grid_seed(n, cols, rows, rot=0.0):
    side = 1.0 / max(cols, rows)
    sq = []
    for j in range(rows):
        for i in range(cols):
            if len(sq) >= n:
                break
            sq.append([(i + 0.5) * side, (j + 0.5) * side, rot, side])
        if len(sq) >= n:
            break
    return sq


def _corner_seed(n, big_side, corner):
    """One big square of side `big_side` in a corner, then grid-fill the L."""
    sq = [[0.0, 0.0, 0.0, big_side]]
    if corner == 0:
        cx, cy = big_side / 2.0, big_side / 2.0
        sq[0][0], sq[0][1] = cx, cy
        # remaining region: right strip + top strip
        # fill right strip with cols, top strip with cols
        rem = n - 1
        # choose grid in region [big_side,1]x[0,1] and [0,big_side]x[big_side,1]
        # try splitting rem into two rectangles
        best = None
        for a in range(rem + 1):
            b = rem - a
            # rectangle A: width (1-big_side), height 1 -> cell side sa
            # rectangle B: width big_side, height (1-big_side) -> cell side sb
            if a > 0:
                ca = max(1, int(round(math.sqrt(a * (1 - big_side) / 1.0))))
                ra = (a + ca - 1) // ca
                sa = min((1 - big_side) / ca, 1.0 / ra)
            else:
                ca = ra = 0
                sa = 0.0
            if b > 0:
                cb = max(1, int(round(math.sqrt(b * big_side / (1 - big_side)))))
                rb = (b + cb - 1) // cb
                sb = min(big_side / cb, (1 - big_side) / rb)
            else:
                cb = rb = 0
                sb = 0.0
            sc = a * sa + b * sb
            if best is None or sc > best[0]:
                best = (sc, ca, ra, sa, cb, rb, sb)
        _, ca, ra, sa, cb, rb, sb = best
        # place A squares (right strip)
        placed = 0
        for j in range(ra):
            for i in range(ca):
                if placed >= a if False else placed >= best[1] * best[2]:
                    break
        # simpler: just place a squares in right strip grid
        a_count = 0
        for j in range(ra):
            for i in range(ca):
                if a_count >= (best[1] * best[2]) and a_count >= a:
                    break
                if a_count >= a:
                    break
                cx0 = big_side + (i + 0.5) * (1 - big_side) / ca
                cy0 = (j + 0.5) * (1.0) / ra if ra else 0.0
                if cy0 + sa / 2 > 1 and False:
                    pass
                sq.append([cx0, cy0, 0.0, sa])
                a_count += 1
        # top strip
        b_count = 0
        for j in range(rb):
            for i in range(cb):
                if b_count >= b:
                    break
                cx0 = (i + 0.5) * big_side / cb
                cy0 = big_side + (j + 0.5) * (1 - big_side) / rb
                sq.append([cx0, cy0, 0.0, sb])
                b_count += 1
    else:
        # right-bottom style mirrors etc: just generalise by mirroring
        sq = _corner_seed(n, big_side, 0)
    # pad / truncate
    while len(sq) < n:
        sq.append([0.5, 0.5, 0.0, 0.0])
    return sq[:n]


# --------------------------------------------------------------------------
# fast grow / separate refinement
# --------------------------------------------------------------------------

def _refine(squares, iters, rng):
    n = len(squares)
    sq = [list(s) for s in squares]
    sq = [[min(max(s[0], 0.0), 1.0), min(max(s[1], 0.0), 1.0),
           s[2] % 1.0, max(0.0, s[3])] for s in sq]

    def val(sqs):
        return sum(s[3] for s in sqs)

    # fix containment first by shrinking
    for _ in range(200):
        cs = [_corners(*s) for s in sq]
        changed = False
        for i in range(n):
            pen = _inside_penalty(cs[i])
            if pen > 1e-9:
                sq[i][3] = max(0.0, sq[i][3] - pen * 1.2)
                # also recentre
                sq[i][0] = min(max(sq[i][0], sq[i][3] / 2), 1 - sq[i][3] / 2)
                sq[i][1] = min(max(sq[i][1], sq[i][3] / 2), 1 - sq[i][3] / 2)
                changed = True
        if not changed:
            break

    best = [s[:] for s in sq]
    best_val = val(best)

    pos_step = 0.25
    size_step = 0.25
    ang_step = 0.25

    for it in range(iters):
        kind = rng.random()
        i = rng.randrange(n)
        cand = [s[:] for s in best]
        s = cand[i]
        if kind < 0.5:
            # try to grow the chosen square
            s[3] = max(0.0, s[3] * (1.0 + rng.uniform(0.0, size_step)))
        elif kind < 0.75:
            s[0] = min(max(s[0] + rng.uniform(-pos_step, pos_step), 0.0), 1.0)
            s[1] = min(max(s[1] + rng.uniform(-pos_step, pos_step), 0.0), 1.0)
        else:
            s[2] = (s[2] + rng.uniform(-ang_step, ang_step)) % 1.0

        if _feasible(cand):
            v = val(cand)
            if v >= best_val - 1e-12:
                best = cand
                best_val = v
        else:
            # repair: shrink others / this one slightly
            s[3] = max(0.0, s[3] * 0.98)
            if _feasible(cand):
                v = val(cand)
                if v >= best_val - 1e-12:
                    best = cand
                    best_val = v

        if it % (8 * max(n, 1)) == 0:
            pos_step *= 0.93
            size_step *= 0.93
            ang_step *= 0.93
            pos_step = max(pos_step, 1e-4)
            size_step = max(size_step, 1e-4)
            ang_step = max(ang_step, 1e-4)

    return [tuple(s) for s in best]


# --------------------------------------------------------------------------
# SLSQP polish
# --------------------------------------------------------------------------

def _slsqp_polish(squares, n):
    x0 = np.array([c for s in squares for c in s], dtype=float)

    def unpack(x):
        return x.reshape(n, 4)

    def obj(x):
        return -np.sum(x[3::4])

    def jac(x):
        g = np.zeros_like(x)
        g[3::4] = -1.0
        return g

    def separation_constraints(x):
        y = unpack(x)
        out = []
        for i in range(n):
            ci = _corners(*y[i])
            sid_i = y[i][3]
            for j in range(i + 1, n):
                cj = _corners(*y[j])
                if sid_i <= 1e-9 or y[j][3] <= 1e-9:
                    continue
                # SAT: for each of the 4 axes (2 from each square) require
                # projections to be separated by >= eps
                for poly in (ci, cj):
                    for k in range(4):
                        p0 = poly[k]
                        p1 = poly[(k + 1) % 4]
                        ex, ey = p1[0] - p0[0], p1[1] - p0[1]
                        ax, ay = ey, -ex
                        nn = math.hypot(ax, ay)
                        if nn < 1e-15:
                            continue
                        ax /= nn
                        ay /= nn
                        d0 = ci[:, 0] * ax + ci[:, 1] * ay
                        d1 = cj[:, 0] * ax + cj[:, 1] * ay
                        # require separated: max(min...) <= min(max...) - eps
                        # equivalent: min(d0.max(), d1.max()) ... use gap:
                        # gap = min(d0.max(), d1.max()) - max(d0.min(), d1.min())
                        # require gap <= 0 (disjoint)
                        out.append(min(d0.max(), d1.max()) -
                                   max(d0.min(), d1.min()) + 1e-6)
        return np.array(out) if out else np.array([-1.0])

    def containment_constraints(x):
        y = unpack(x)
        out = []
        for i in range(n):
            ci = _corners(*y[i])
            lo = ci.min(axis=0)
            hi = ci.max(axis=0)
            out.append(-lo[0] - 1e-7)
            out.append(-lo[1] - 1e-7)
            out.append(hi[0] - 1.0 - 1e-7)
            out.append(hi[1] - 1.0 - 1e-7)
        return np.array(out)

    cons = [
        {"type": "ineq", "fun": separation_constraints},
        {"type": "ineq", "fun": containment_constraints},
    ]
    bounds = [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)] * n
    try:
        res = minimize(obj, x0, jac=jac, method="SLSQP",
                       bounds=bounds, constraints=cons,
                       options={"maxiter": 400, "ftol": 1e-9})
        y = res.x.reshape(n, 4)
        cand = [tuple(round(float(c), 9) for c in row) for row in y]
        if _feasible(cand):
            return cand
    except Exception:
        pass
    return None


# --------------------------------------------------------------------------
# public API
# --------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(9876 + n)
    t0 = time.time()
    deadline = t0 + 55.0

    seeds = []
    # grid seeds
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        if cols * rows < n:
            continue
        seeds.append(_grid_seed(n, cols, rows))
    # corner seeds: big square + filler
    for corner in (0,):
        for k in range(1, 30):
            big = min(0.99, 0.5 + 0.02 * k)
            if big >= 1.0:
                break
            seeds.append(_corner_seed(n, big, corner))

    best = None
    best_val = -1.0

    for seed in seeds:
        if time.time() > deadline - 2.0:
            break
        cand = _refine(seed, 4000 + 2000 * n, rng)
        v = sum(s[3] for s in cand)
        if v > best_val and _feasible(cand):
            best_val = v
            best = cand

    if best is None:
        best = _grid_seed(n, max(1, int(round(math.sqrt(n)))),
                          (n + max(1, int(round(math.sqrt(n)))) - 1) //
                          max(1, int(round(math.sqrt(n)))))
        best = [tuple(s) for s in best]
        best_val = sum(s[3] for s in best)

    # randomized restarts of refine, plus per-square growth of best
    attempts = 0
    while time.time() < deadline - 3.0:
        attempts += 1
        if attempts == 1:
            init = best
        else:
            init = []
            for s in best:
                init.append((min(max(s[0] + rng.uniform(-0.05, 0.05), 0.0), 1.0),
                             min(max(s[1] + rng.uniform(-0.05, 0.05), 0.0), 1.0),
                             (s[2] + rng.uniform(-0.1, 0.1)) % 1.0,
                             s[3]))
        cand = _refine(init, 3000 + 1000 * n, rng)
        v = sum(s[3] for s in cand)
        if v > best_val + 1e-12 and _feasible(cand):
            best_val = v
            best = cand
        if n <= 6 and attempts >= 6:
            break

    # SLSQP polish
    if time.time() < deadline:
        pol = _slsqp_polish(best, n)
        if pol is not None:
            v = sum(s[3] for s in pol)
            if v > best_val + 1e-9 and _feasible(pol):
                best = pol
                best_val = v

    # final cleanup to guarantee reportability
    out = []
    for s in best:
        cx = min(max(s[0], 0.0), 1.0)
        cy = min(max(s[1], 0.0), 1.0)
        ang = s[2] % 1.0
        side = min(max(s[3], 0.0), 1.0)
        out.append((cx, cy, ang, side))
    return out
# EVOLVE-BLOCK-END
