# EVOLVE-BLOCK-START
"""Grid/strip seeding plus exact-SAT greedy growth and SLSQP polish."""

import math
import random
import numpy as np
from scipy.optimize import minimize


# ---------------------------------------------------------------- geometry ---
def _axes(a):
    """Unit normals of the 4 support axes of a square rotated by angle a (turns)."""
    t = 2.0 * math.pi * a
    c, s = math.cos(t), math.sin(t)
    return ((c, s), (-s, c))


def _proj(cx, cy, ax, ay, a, s):
    """Projection interval [lo, hi] of a rotated square onto axis (ax, ay)."""
    h = 0.5 * s
    ux, uy = _axes(a)
    r = h * (abs(ux[0] * ax + ux[1] * ay) + abs(uy[0] * ax + uy[1] * ay))
    d = cx * ax + cy * ay
    return d - r, d + r


def _overlap_amount(sq1, sq2):
    """Return min overlap (<=0 means separated) along SAT axes of the two squares."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 0.0 or s2 <= 0.0:
        return -1.0
    best = -1.0
    for (ax, ay) in (list(_axes(a1)) + list(_axes(a2))):
        lo1, hi1 = _proj(cx1, cy1, ax, ay, a1, s1)
        lo2, hi2 = _proj(cx2, cy2, ax, ay, a2, s2)
        ov = min(hi1 - lo2, hi2 - lo1)
        if ov <= 0.0:
            return ov  # separating axis found
        if best < 0.0 or ov < best:
            best = ov
    return best


def _inside(cx, cy, a, s, eps=1e-9):
    if s <= 0.0:
        return True
    t = 2.0 * math.pi * a
    c, sn = abs(math.cos(t)), abs(math.sin(t))
    r = 0.5 * s * (c + sn)
    return (cx - r >= -eps and cx + r <= 1.0 + eps and
            cy - r >= -eps and cy + r <= 1.0 + eps)


def _radius(a, s):
    """AABB half-radius of a rotated square."""
    t = 2.0 * math.pi * a
    c, sn = abs(math.cos(t)), abs(math.sin(t))
    return 0.5 * s * (c + sn)


# ---------------------------------------------------------------- seeds ---
def _grid_seed(n):
    best = None
    for k in range(1, n + 1):
        for m in range(1, n + 1):
            if k * m < n:
                continue
            side = min(1.0 / k, 1.0 / m)
            cells = []
            for i in range(k):
                for j in range(m):
                    cx = (i + 0.5) * (1.0 / k)
                    cy = (j + 0.5) * (1.0 / m)
                    cells.append([cx, cy, 0.0, side])
            if best is None or len(cells) < len(best):
                best = cells
    return best if best is not None else []


def _strip_seed(n, vertical=True):
    best = None
    for k in range(1, n + 1):
        w = 1.0 / k
        side = w
        per = max(1, int(round(1.0 / side)))
        total = k * per
        if total < n:
            continue
        cells = []
        for i in range(k):
            for j in range(per):
                if vertical:
                    cx = (i + 0.5) * w
                    cy = (j + 0.5) * (1.0 / per)
                else:
                    cx = (j + 0.5) * (1.0 / per)
                    cy = (i + 0.5) * w
                cells.append([cx, cy, 0.0, side])
        if len(cells) >= n and (best is None or len(cells) < len(best)):
            best = cells
    return best if best is not None else []


def _slicing_seed(n):
    cells = [[0.5, 0.5, 0.0, 1.0]]
    while len(cells) < n:
        idx = max(range(len(cells)), key=lambda t: cells[t][3])
        cx, cy, ang, s = cells[idx]
        ns = s * 0.5
        d = s * 0.25
        cells.pop(idx)
        for dx in (-d, d):
            for dy in (-d, d):
                cells.append([cx + dx, cy + dy, ang, ns])
    cells.sort(key=lambda t: -t[3])
    return cells[:n]


def _big_plus_grid_seed(n):
    """One large square in a corner + grid of small squares in the L-shape."""
    if n < 2:
        return None
    best = None
    # large square side L in bottom-left corner; remaining area = L-shape
    for i in range(1, 40):
        L = i / 40.0
        # remaining L-shape: right strip (width 1-L, height 1) + top strip (width L, height 1-L)
        m = n - 1
        cells = [[L / 2.0, L / 2.0, 0.0, L]]
        # fill right strip with a grid
        got = 0
        # try grid counts
        area_r = (1.0 - L) * 1.0
        area_t = L * (1.0 - L)
        for kr in range(1, m + 1):
            for jr in range(1, m + 1):
                if got == m:
                    break
                if got + kr * jr <= m and kr * jr > 0:
                    pass
        # simpler: place small squares greedily in L-shape
        small_side = None
        for ss in range(1, 40):
            s = ss / 40.0
            # count how many fit in right strip
            cols_r = int((1.0 - L) / s + 1e-9)
            rows_r = int(1.0 / s + 1e-9)
            cols_t = int(L / s + 1e-9)
            rows_t = int((1.0 - L) / s + 1e-9)
            cnt = cols_r * rows_r + cols_t * rows_t
            if cnt >= m:
                small_side = s
                break
        if small_side is None:
            continue
        s = small_side
        cnt = 0
        cols_r = int((1.0 - L) / s + 1e-9)
        rows_r = int(1.0 / s + 1e-9)
        for a in range(cols_r):
            for b in range(rows_r):
                if cnt >= m:
                    break
                cx = L + (a + 0.5) * s
                cy = (b + 0.5) * s
                if cx + 0.5 * s <= 1.0 + 1e-9 and cy + 0.5 * s <= 1.0 + 1e-9:
                    cells.append([cx, cy, 0.0, s])
                    cnt += 1
            if cnt >= m:
                break
        cols_t = int(L / s + 1e-9)
        rows_t = int((1.0 - L) / s + 1e-9)
        for a in range(cols_t):
            for b in range(rows_t):
                if cnt >= m:
                    break
                cx = (a + 0.5) * s
                cy = L + (b + 0.5) * s
                if cx + 0.5 * s <= 1.0 + 1e-9 and cy + 0.5 * s <= 1.0 + 1e-9:
                    cells.append([cx, cy, 0.0, s])
                    cnt += 1
            if cnt >= m:
                break
        if cnt >= n:
            if best is None or sum(c[3] for c in cells[:n]) > sum(c[3] for c in best):
                best = cells[:n]
    return best


def _fit_seed(cells):
    idx = sorted(range(len(cells)), key=lambda i: -cells[i][3])
    placed = []
    for i in idx:
        cx, cy, a, s = cells[i]
        a = a % 0.5
        r = abs(math.cos(2.0 * math.pi * a)) + abs(math.sin(2.0 * math.pi * a))
        s = min(s, 1.0 / r if r > 1e-12 else 1.0)
        if not (0.0 <= cx <= 1.0):
            cx = 0.5
        if not (0.0 <= cy <= 1.0):
            cy = 0.5
        for _ in range(60):
            if not _inside(cx, cy, a, s):
                s *= 0.95
                continue
            ok = True
            for p in placed:
                if _overlap_amount((cx, cy, a, s), p) > 1e-12:
                    ok = False
                    break
            if ok:
                break
            s *= 0.9
        placed.append([cx, cy, a, max(s, 0.0)])
    return placed


# ---------------------------------------------------------------- growing ---
def _can_grow(cur, i, s_new, eps=1e-10):
    cx, cy, a, _ = cur[i]
    if not _inside(cx, cy, a, s_new, eps):
        return False
    test = (cx, cy, a, s_new)
    for j in range(len(cur)):
        if j == i:
            continue
        if _overlap_amount(test, cur[j]) > eps:
            return False
    return True


def _grow_all(cur, rounds=6, factors=(1.15, 1.08, 1.04, 1.02, 1.01, 1.005, 1.002)):
    n = len(cur)
    order = sorted(range(n), key=lambda i: -cur[i][3])
    improved = True
    rnd = 0
    while improved and rnd < rounds:
        improved = False
        rnd += 1
        for i in order:
            s = cur[i][3]
            for f in factors:
                ns = s * f
                if _can_grow(cur, i, ns):
                    cur[i][3] = ns
                    improved = True
                    break
    return cur


def _local_grow(cur, tries=400, rng=None):
    if rng is None:
        rng = random.Random(0)
    n = len(cur)
    best = [list(c) for c in cur]
    best_score = sum(c[3] for c in best)
    amp = 0.01
    for _ in range(tries):
        cand = [list(c) for c in best]
        i = rng.randrange(n)
        cx, cy, a, s = cand[i]
        d = amp
        ncx = min(max(cx + rng.uniform(-d, d), 0.0), 1.0)
        ncy = min(max(cy + rng.uniform(-d, d), 0.0), 1.0)
        na = (a + rng.uniform(-0.02, 0.02)) % 0.5
        if _inside(ncx, ncy, na, s):
            test = (ncx, ncy, na, s)
            good = True
            for j in range(n):
                if j == i:
                    continue
                if _overlap_amount(test, cand[j]) > 1e-10:
                    good = False
                    break
            if good:
                cand[i] = [ncx, ncy, na, s]
                _grow_all(cand, rounds=3)
                score = sum(c[3] for c in cand)
                if score > best_score + 1e-12:
                    best_score = score
                    best = cand
    return best


# ---------------------------------------------------------------- SLSQP ---
def _pack_slsqp(cur, maxiter=160, ftol=1e-10):
    """Maximise sum of side lengths s.t. SAT separation + containment.

    Variables: for each square [cx, cy, a, s].  Angles kept free within [0, 0.5].
    Constraints: for each pair, the max overlaps across 4 axes <= 0
    (expressed as: each of the 4 axis overlaps must be <= 0 -> 4 constraints).
    Containment: cx - r >= 0, cx + r <= 1, cy - r >= 0, cy + r <= 1.
    """
    n = len(cur)
    if n == 0:
        return None
    x0 = np.array([[c[0], c[1], c[2] % 0.5, c[3]] for c in cur], dtype=float).ravel()

    def unpack(x):
        return x.reshape(n, 4)

    def neg_obj(x):
        return -np.sum(x.reshape(n, 4)[:, 3])

    # Precompute pair list
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]

    def axis_overlap(ax, ay, cx1, cy1, a1, s1, cx2, cy2, a2, s2):
        h1 = 0.5 * s1
        t1 = 2.0 * math.pi * a1
        ux1 = (math.cos(t1), math.sin(t1))
        vx1 = (-math.sin(t1), math.cos(t1))
        r1 = h1 * (abs(ux1[0] * ax + ux1[1] * ay) + abs(vx1[0] * ax + vx1[1] * ay))
        d1 = cx1 * ax + cy1 * ay
        h2 = 0.5 * s2
        t2 = 2.0 * math.pi * a2
        ux2 = (math.cos(t2), math.sin(t2))
        vx2 = (-math.sin(t2), math.cos(t2))
        r2 = h2 * (abs(ux2[0] * ax + ux2[1] * ay) + abs(vx2[0] * ax + vx2[1] * ay))
        d2 = cx2 * ax + cy2 * ay
        # overlap = min(hi1-lo2, hi2-lo1)
        return min((d1 + r1) - (d2 - r2), (d2 + r2) - (d1 - r1))

    def cons(x):
        X = x.reshape(n, 4)
        out = []
        # pair SAT constraints
        for (i, j) in pairs:
            cx1, cy1, a1, s1 = X[i]
            cx2, cy2, a2, s2 = X[j]
            if s1 <= 1e-12 or s2 <= 1e-12:
                continue
            t1 = 2.0 * math.pi * a1
            t2 = 2.0 * math.pi * a2
            axes = [(math.cos(t1), math.sin(t1)), (-math.sin(t1), math.cos(t1)),
                    (math.cos(t2), math.sin(t2)), (-math.sin(t2), math.cos(t2))]
            for (ax, ay) in axes:
                ov = axis_overlap(ax, ay, cx1, cy1, a1, s1, cx2, cy2, a2, s2)
                out.append(-ov)  # want -ov >= 0  (ov <= 0)
        # containment
        for i in range(n):
            cx, cy, a, s = X[i]
            r = _radius(a, s)
            out.append(cx - r)
            out.append(1.0 - cx - r)
            out.append(cy - r)
            out.append(1.0 - cy - r)
        return np.array(out)

    # bounds: cx, cy in [0,1]; angle in [0, 0.5]; side in [0, 1]
    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 0.5))
        bounds.append((0.0, 1.0))

    try:
        res = minimize(neg_obj, x0, method='SLSQP', bounds=bounds,
                       constraints=[{'type': 'ineq', 'fun': cons}],
                       options={'maxiter': maxiter, 'ftol': ftol})
    except Exception:
        return None
    if res.x is None:
        return None
    X = res.x.reshape(n, 4)
    out = [list(X[i]) for i in range(n)]
    # verify feasibility strictly
    placed = []
    for c in sorted(out, key=lambda t: -t[3]):
        if not _inside(c[0], c[1], c[2] % 0.5, c[3], 1e-7):
            return None
        for p in placed:
            if _overlap_amount((c[0], c[1], c[2] % 0.5, c[3]), p) > 1e-7:
                return None
        placed.append((c[0], c[1], c[2] % 0.5, c[3]))
    return out


# ---------------------------------------------------------------- driver ---
def _seed_candidates(n):
    seeds = []
    seeds.append(_slicing_seed(n))
    seeds.append(_grid_seed(n))
    seeds.append(_strip_seed(n, True))
    seeds.append(_strip_seed(n, False))
    bg = _big_plus_grid_seed(n)
    if bg:
        seeds.append(bg)
    out = []
    seen = set()
    for s in seeds:
        if not s:
            continue
        key = tuple(sorted(round(c[3], 6) for c in s))
        if key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(20240517)

    best = None
    best_score = -1.0

    candidates = _seed_candidates(n)
    for seed in candidates:
        cur = _fit_seed(seed)
        if len(cur) < n:
            continue
        while len(cur) > n:
            cur.pop()
        _grow_all(cur, rounds=8)
        cur = _local_grow(cur, tries=120, rng=rng)
        _grow_all(cur, rounds=4)
        score = sum(c[3] for c in cur)
        if score > best_score:
            best_score = score
            best = [list(c) for c in cur]

    if best is None:
        best = _fit_seed(_slicing_seed(n))[:n]

    # SLSQP polish on the best and a couple of variants
    polishes = [best] + ([best] if n < 100 else [])
    polished_best = best
    polished_score = sum(c[3] for c in best)
    for attempt in range(3):
        slab = _pack_slsqp(best, maxiter=120 + 60 * attempt, ftol=1e-10)
        if slab is None:
            continue
        sc = sum(c[3] for c in slab)
        if sc > polished_score + 1e-9:
            polished_score = sc
            polished_best = slab
            best = slab  # allow iterating
    best = polished_best
    best_score = polished_score
    # re-grow after polish (SLSQP may shave sizes)
    _grow_all(best, rounds=4)

    # Final feasibility pass
    final = []
    placed = []
    for c in sorted(best, key=lambda t: -t[3]):
        cx, cy, a, s = c
        a = a % 0.5
        for _ in range(80):
            if _inside(cx, cy, a, s):
                break
            pred_ok = True
            for p in placed:
                if _overlap_amount((cx, cy, a, s), p) > 1e-10:
                    pred_ok = False
                    break
            r = _radius(a, s)
            if pred_ok and r <= 0.5 + 1e-9:
                break
            s *= 0.97
        placed.append((cx, cy, a, max(s, 0.0)))
        final.append((cx, cy, a, max(s, 0.0)))

    while len(final) < n:
        final.append((0.5, 0.5, 0.0, 0.0))
    final = final[:n]

    out = []
    for (cx, cy, a, s) in final:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    return out
# EVOLVE-BLOCK-END
