# EVOLVE-BLOCK-START
"""Grid baseline plus a physics-based tight packing of the leftover squares."""
import math
import random


def _overlap_area(a, b):
    # conservative axis-aligned bounding-box overlap check in rotated frame
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    # approximate using bounding radius
    ra = asz * math.sqrt(2.0) / 2.0
    rb = bsz * math.sqrt(2.0) / 2.0
    dx = ax - bx
    dy = ay - by
    d = math.hypot(dx, dy)
    return ra + rb - d


def solve(n):
    if n <= 0:
        return []
    k = math.isqrt(n)
    rem = n - k * k
    if rem == 0:
        side = 1.0 / k
        return [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]

    # Use k x k grid but shrink so leftover squares can fit in a strip.
    # Try several strip configurations and pick the best total.
    best = None

    # Configuration A: k*k grid occupying a (1) x (1-h) region, rem squares in strip.
    # Grid squares side s in [0,1-h]x[0,1]; strip height h. Rem squares fit in strip.
    def try_grid_strip(grid_cols, grid_rows, strip_count, vertical=True):
        # grid of grid_cols x grid_rows squares of side s, plus strip_count squares
        gs = grid_cols * grid_rows
        if gs > n:
            return None
        extra = n - gs
        # strip holds 'extra' squares
        # grid occupies side length gs_cols*s by gs_rows*s
        # We'll set both dimensions: use cells.
        # Place grid in a region of width W, height H, strip adjacent.
        best_local = None
        if vertical:
            # grid region width 1, height H; strip height 1-H width 1
            # grid squares side s: cols = grid_cols -> s = 1/grid_cols
            s = 1.0 / grid_cols
            H = grid_rows * s
            if H > 1:
                return None
            stripH = 1.0 - H
            if stripH <= 0 and extra > 0:
                return None
            # fill strip with extra squares in a row
            if extra > 0:
                ew = 1.0 / extra
                es = min(ew, stripH)
            else:
                es = 0.0
            total = gs * s + extra * es
            layout = []
            for i in range(grid_cols):
                for j in range(grid_rows):
                    layout.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
            if extra > 0:
                for m in range(extra):
                    layout.append(((m + 0.5) * ew, H + stripH / 2.0, 0.0, es))
            return total, layout
        return None

    candidates = []
    for cols in range(1, k + 1):
        for rows in range(1, k + 1):
            if cols * rows <= n and cols <= k and rows <= k:
                r = try_grid_strip(cols, rows, n - cols * rows, vertical=True)
                if r:
                    candidates.append(r)
    # Also plain grid for k
    if rem == 0:
        pass
    # Best of candidates
    for total, layout in candidates:
        layout = layout[:n]
        if best is None or total > best[0]:
            best = (total, layout)

    if best is None:
        side = 1.0 / k
        return [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)] + [(0.5, 0.5, 0.0, 0.0)] * rem

    # Local refinement: grow squares and relax positions.
    squares = [list(s) for s in best[1]]
    if len(squares) < n:
        squares += [[0.5, 0.5, 0.0, 0.0]] * (n - len(squares))

    edges = [(i, j) for i in range(n) for j in range(i + 1, n)]
    # physics-like relaxation
    for it in range(60):
        # grow
        grow = 0.002
        for s in squares:
            s[3] += grow
        # relaxation to remove overlaps
        for _ in range(30):
            moved = False
            for i, j in edges:
                o = _overlap_area(squares[i], squares[j])
                if o > 0:
                    moved = True
                    ax, ay, aa, asz = squares[i]
                    bx, by, ba, bsz = squares[j]
                    dx = ax - bx
                    dy = ay - by
                    d = math.hypot(dx, dy) + 1e-9
                    push = o * 0.5
                    ux, uy = dx / d, dy / d
                    squares[i][0] += ux * push
                    squares[i][1] += uy * push
                    squares[j][0] -= ux * push
                    squares[j][1] -= uy * push
            # clamp to box and shrink if needed
            for s in squares:
                r = s[3] * math.sqrt(2.0) / 2.0
                s[0] = min(max(s[0], r), 1 - r)
                s[1] = min(max(s[1], r), 1 - r)
            if not moved:
                break
        # check validity and revert growth if invalid
        ok = True
        for i, j in edges:
            if _overlap_area(squares[i], squares[j]) > 1e-6:
                ok = False
                break
        if not ok:
            for s in squares:
                s[3] -= grow
            break

    # final validity check; if invalid, fall back to grid
    ok = True
    max_o = 0.0
    for i, j in edges:
        o = _overlap_area(squares[i], squares[j])
        max_o = max(max_o, o)
    if max_o > 1e-4:
        side = 1.0 / k
        return [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)] + [(0.5, 0.5, 0.0, 0.0)] * rem

    return [(s[0], s[1], s[2], s[3]) for s in squares]
# EVOLVE-BLOCK-END
