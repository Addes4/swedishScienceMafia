import math
import random

# EVOLVE-BLOCK-START

# ---------------- geometry helpers ----------------

def _corners(cx, cy, ang, side):
    """Return 4 corners of a square (ang is fraction of a full turn)."""
    th = 2.0 * math.pi * ang
    c, s = math.cos(th), math.sin(th)
    h = 0.5 * side
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for (lx, ly) in pts:
        x = cx + lx * c - ly * s
        y = cy + lx * s + ly * c
        out.append((x, y))
    return out


def _axes(ang):
    """Unit axes (u, v) of the square with given angle."""
    th = 2.0 * math.pi * ang
    c, s = math.cos(th), math.sin(th)
    return (c, s), (-s, c)


def _project(corners, ax):
    ax0, ax1 = ax
    vals = [p[0] * ax0 + p[1] * ax1 for p in corners]
    return min(vals), max(vals)


def _overlap_area(a, b):
    """Exact overlap area of two convex polygons via Sutherland-Hodgman."""
    def inside(p, a0, a1, b0, b1):
        return (a1 - a0) * (p[1] - a0) - (b1 - b0) * (p[0] - a0) >= -1e-12

    def intersect(p, q, a0, a1, b0, b1):
        d1x = a1 - a0
        d1y = b1 - b0
        d2x = q[0] - p[0]
        d2y = q[1] - p[1]
        den = d1x * d2y - d1y * d2x
        if abs(den) < 1e-15:
            return q
        t = ((p[0] - a0) * d1y - (p[1] - b0) * d1x) / den
        return (p[0] + t * d2x, p[1] + t * d2y)

    def clip(poly, a0, a1, b0, b1):
        if not poly:
            return poly
        out = []
        m = len(poly)
        for i in range(m):
            cur = poly[i]
            nxt = poly[(i + 1) % m]
            cur_in = inside(cur, a0, a1, b0, b1)
            nxt_in = inside(nxt, a0, a1, b0, b1)
            if cur_in:
                out.append(cur)
            if cur_in != nxt_in:
                out.append(intersect(cur, nxt, a0, a1, b0, b1))
        return out

    poly = list(a)
    m = len(b)
    for i in range(m):
        b0 = b[i]
        b1 = b[(i + 1) % m]
        poly = clip(poly, b0[0], b0[1], b1[0], b1[1])
        if not poly:
            return 0.0
    area = 0.0
    k = len(poly)
    for i in range(k):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % k]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def _separated(a, b):
    """True if two convex polygons do not overlap in interior."""
    # SAT: test all edge normals of both polygons
    for poly in (a, b):
        m = len(poly)
        for i in range(m):
            p0 = poly[i]
            p1 = poly[(i + 1) % m]
            nx = -(p1[1] - p0[1])
            ny = (p1[0] - p0[0])
            n = math.hypot(nx, ny)
            if n < 1e-15:
                continue
            nx /= n
            ny /= n
            pa = [pt[0] * nx + pt[1] * ny for pt in a]
            pb = [pt[0] * nx + pt[1] * ny for pt in b]
            if max(pa) <= min(pb) + 1e-12 or max(pb) <= min(pa) + 1e-12:
                return True
    return False


def _in_box(corners, box=1.0, eps=1e-9):
    for (x, y) in corners:
        if x < -eps or x > box + eps or y < -eps or y > box + eps:
            return False
    return True


# ---------------- validity check of full config ----------------

def _is_valid(sqs):
    n = len(sqs)
    polys = []
    for (cx, cy, ang, side) in sqs:
        if not (0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0 and 0.0 <= ang <= 1.0):
            return False
        if not (0.0 <= side <= 1.0):
            return False
        cs = _corners(cx, cy, ang, side)
        if not _in_box(cs):
            return False
        polys.append(cs)
    for i in range(n):
        for j in range(i + 1, n):
            if not _separated(polys[i], polys[j]):
                return False
    return True


# ---------------- seeds ----------------

def _seed_grid(n):
    """Axis-aligned grid, then split cells to reach n."""
    k = max(1, int(math.isqrt(n)))
    while k * k > n:
        k -= 1
    cells = []
    side = 1.0 / k
    for i in range(k):
        for j in range(k):
            cells.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    # split largest squares until we have n
    while len(cells) < n:
        idx = max(range(len(cells)), key=lambda t: cells[t][3])
        cx, cy, ang, sd = cells[idx]
        hs = sd / 2.0
        # split into 4 and reduce count? Instead split into 2 halves
        a = [cx - hs / 2.0, cy, 0.0, sd / 2.0]
        b = [cx + hs / 2.0, cy, 0.0, sd / 2.0]
        cells[idx] = a
        cells.append(b)
    return cells[:n]


def _grow_polish(sqs, iters=200, verbose=False):
    """Feasibility-preserving local search: try to grow each square, then shift."""
    n = len(sqs)
    best = [list(s) for s in sqs]
    best_sum = sum(s[3] for s in best)

    def total(sqs_):
        return sum(s[3] for s in sqs_)

    improved = True
    rng = random.Random(12345)
    for it in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cur = best[i]
            cx, cy, ang, sd = cur
            # try growing this square
            # candidate side increases and nudge directions
            for dgrow in (0.02, 0.01, 0.005, 0.002):
                for dxy in ((0, 0), (0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01),
                            (0.005, 0.005), (-0.005, 0.005), (0.005, -0.005), (-0.005, -0.005)):
                    ncx = min(1.0, max(0.0, cx + dxy[0]))
                    ncy = min(1.0, max(0.0, cy + dxy[1]))
                    nsd = sd + dgrow
                    if nsd > 1.0:
                        continue
                    test = [list(s) for s in best]
                    test[i] = [ncx, ncy, ang, nsd]
                    if _is_valid(test):
                        best = test
                        improved = True
                        break
                if improved:
                    break
        if not improved:
            break
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    sqs = _seed_grid(n)
    # shrink slightly to guarantee validity
    for s in sqs:
        s[3] *= 0.98
    sqs = _grow_polish(sqs, iters=120)

    # final safety: if invalid, shrink all
    tries = 0
    while not _is_valid(sqs) and tries < 20:
        for s in sqs:
            s[3] *= 0.95
            s[0] = min(1.0, max(0.0, s[0]))
            s[1] = min(1.0, max(0.0, s[1]))
        tries += 1

    return [(float(cx), float(cy), float(ang), float(sd)) for (cx, cy, ang, sd) in sqs]


# EVOLVE-BLOCK-END
