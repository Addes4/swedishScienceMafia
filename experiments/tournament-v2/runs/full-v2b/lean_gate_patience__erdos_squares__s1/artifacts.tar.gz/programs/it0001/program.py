# EVOLVE-BLOCK-START
"""Heuristic layout search for packing squares in the unit square.

Start from a feasible grid and run randomised local improvement on
(side, cx, cy, angle) while maintaining disjoint interiors.  The objective
is the sum of side lengths.  Works for any n in the time budget.
"""
import math
import random


def _overlap_ok(a, b, margin):
    """Conservative overlap test between two possibly rotated squares.

    Uses separating-axis on the 4 edge normals of each square, with a small
    margin so accepted states keep clear of exact touching.
    """
    ax, ay, aa, asd = a
    bx, by, ba, bsd = b
    if asd <= 0.0 or bsd <= 0.0:
        return True
    for (cx, cy, ang, sd) in (a, b):
        c = math.cos(2 * math.pi * ang)
        s = math.sin(2 * math.pi * ang)
        # two axes of this square
        for (ux, uy) in ((c, s), (-s, c)):
            ha = _proj_half(a, ux, uy)
            hb = _proj_half(b, ux, uy)
            d = (bx - ax) * ux + (by - ay) * uy
            if abs(d) >= ha + hb - margin:
                return True
    return False


def _proj_half(sq, ux, uy):
    _, _, ang, sd = sq
    c = math.cos(2 * math.pi * ang)
    s = math.sin(2 * math.pi * ang)
    h = 0.5 * sd
    return h * (abs(c * ux + s * uy) + abs(-s * ux + c * uy))


def _feasible(squares, margin):
    m = len(squares)
    for i in range(m):
        x, y, ang, sd = squares[i]
        if sd < 0.0:
            return False
        if sd <= 0.0:
            continue
        # inside unit square (bounding geometry via support function)
        h = 0.5 * sd
        c = math.cos(2 * math.pi * ang)
        s = math.sin(2 * math.pi * ang)
        ex = h * (abs(c) + abs(s))
        ey = h * (abs(s) + abs(c))
        if x - ex < -margin or x + ex > 1 + margin:
            return False
        if y - ey < -margin or y + ey > 1 + margin:
            return False
        for j in range(i + 1, m):
            if not _overlap_ok(squares[i], squares[j], margin):
                return False
    return True


def _score(squares):
    return sum(sq[3] for sq in squares)


def solve(n):
    if n <= 0:
        return []
    # initial greedy grid
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    squares = [[(i + 0.5) * side, (j + 0.5) * side, 0.0, side]
               for i in range(k) for j in range(k)]
    squares = squares[:n]
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])

    margin = 1e-9
    cur = [list(s) for s in squares]
    if not _feasible(cur, margin):
        # fall back to a safe grid
        side = 1.0 / (math.isqrt(n) + 1)
        cur = [[(i + 0.5) * side, (j + 0.5) * side, 0.0, side]
               for i in range(k) for j in range(k)]
        cur = cur[:n]
        while len(cur) < n:
            cur.append([0.5, 0.5, 0.0, 0.0])

    best = [list(s) for s in cur]
    best_val = _score(best)

    rng = random.Random(12345 + n)
    iterations = 20000
    step0 = 0.1
    for it in range(iterations):
        t = it / float(iterations)
        temp = 0.05 * (1.0 - t) + 1e-4
        step = step0 * (1.0 - t) + 1e-3

        idx = rng.randrange(n)
        cand = [list(s) for s in cur]
        sd = cand[idx][3]
        mode = rng.random()
        if mode < 0.5:
            # try to grow
            cand[idx][3] = sd + step * rng.uniform(0.0, 1.0)
        elif mode < 0.8:
            cand[idx][0] += step * rng.uniform(-1.0, 1.0)
            cand[idx][1] += step * rng.uniform(-1.0, 1.0)
        elif mode < 0.9:
            cand[idx][2] = rng.uniform(0.0, 0.25)
        else:
            cand[idx][3] = max(0.0, sd + step * rng.gauss(0.0, 1.0))

        cand_val = _score(cand)
        delta = cand_val - _score(cur)
        accept = False
        if delta >= 0:
            accept = True
        elif temp > 0 and rng.random() < math.exp(delta / temp):
            accept = True
        if accept and _feasible(cand, margin):
            cur = cand
            cv = _score(cur)
            if cv > best_val:
                best_val = cv
                best = [list(s) for s in cur]

    # final greedy shrink-free polish: try growing each square
    improved = True
    while improved:
        improved = False
        for i in range(n):
            for _ in range(3):
                cand = [list(s) for s in best]
                cand[i][3] += 0.005
                if _feasible(cand, margin) and _score(cand) > best_val + 1e-12:
                    best = cand
                    best_val = _score(best)
                    improved = True

    return [tuple(s) for s in best]
# EVOLVE-BLOCK-END

