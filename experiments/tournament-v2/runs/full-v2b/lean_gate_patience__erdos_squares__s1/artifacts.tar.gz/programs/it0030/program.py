# EVOLVE-BLOCK-START
"""Force-directed packing of n rotated squares in the unit square.

Approach
--------
Each square is described by (cx, cy, angle, side).  We minimise a soft energy

    E = sum_{i<j} overlap_penalty(i, j)          (separate squares)
      + sum_i    boundary_penalty(i)             (keep inside the unit box)
      - lambda * sum_i side_i                    (make them big)

where the overlap penalty is the (approximate) area of intersection of the two
axis-projected bounding boxes, which is a smooth, cheap surrogate that pushes
squares apart.  Starting from a coarse grid we anneal lambda: first the squares
are spread out, then they are grown until the repulsion balances the growth
force.

To get the true (rotated) overlap we use a separating-axis test on the four
edge normals of each square.  That is exact for convex polygons and gives a
smooth penetration depth which we use as the penalty.
"""
import math
import random

import numpy as np


# ----------------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------------

def _corners(cx, cy, ang, side):
    """Return the four corners of the square as a (4, 2) array (counter-clockwise)."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side * 0.5
    local = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    rot = np.array([[ca, -sa], [sa, ca]], dtype=float)
    return local @ rot.T + np.array([cx, cy])


def _sat_overlap(corners_a, corners_b):
    """Exact penetration depth (minimum translation distance) of two convex polygons.

    Returns 0.0 if they are disjoint, otherwise a positive scalar measuring how
    far they overlap along the best separating axis.
    """
    polys = (corners_a, corners_b)
    best = float("inf")
    for poly in polys:
        m = len(poly)
        for i in range(m):
            p0 = poly[i]
            p1 = poly[(i + 1) % m]
            edge = p1 - p0
            # outward normal (polygons are given counter-clockwise)
            axis = np.array([edge[1], -edge[0]], dtype=float)
            n = math.hypot(axis[0], axis[1])
            if n < 1e-15:
                continue
            axis /= n
            # project both polygons
            mins = []
            maxs = []
            for q in polys:
                dots = q @ axis
                mins.append(dots.min())
                maxs.append(dots.max())
            # overlap along this axis
            ov = min(maxs[0], maxs[1]) - max(mins[0], mins[1])
            if ov <= 0.0:
                return 0.0
            if ov < best:
                best = ov
    return best if best != float("inf") else 0.0


def _inside_penalty(corners):
    """How far the polygon sticks out of the unit square (sum of violations)."""
    lo = corners.min(axis=0)
    hi = corners.max(axis=0)
    pen = 0.0
    if lo[0] < 0.0:
        pen += -lo[0]
    if lo[1] < 0.0:
        pen += -lo[1]
    if hi[0] > 1.0:
        pen += hi[0] - 1.0
    if hi[1] > 1.0:
        pen += hi[1] - 1.0
    return pen


# ----------------------------------------------------------------------------
# objective / gradient (finite differences are too slow, so we rely on a
# coordinate-descent / pattern search with a soft surrogate)
# ----------------------------------------------------------------------------

def _energy(squares, lam, w_overlap, w_bound):
    """Soft energy of the configuration."""
    e = 0.0
    n = len(squares)
    corners = [_corners(*s) for s in squares]
    for i in range(n):
        e += w_bound * _inside_penalty(corners[i])
    for i in range(n):
        if squares[i][3] <= 0.0:
            continue
        for j in range(i + 1, n):
            if squares[j][3] <= 0.0:
                continue
            e += w_overlap * _sat_overlap(corners[i], corners[j])
    e -= lam * sum(s[3] for s in squares)
    return e


# ----------------------------------------------------------------------------
# initial configuration: best grid (axis aligned), then split largest
# ----------------------------------------------------------------------------

def _grid_config(n):
    """A decent axis-aligned start: rows of near-equal squares."""
    best = None
    best_score = -1.0
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        if rows * cols < n:
            continue
        # number of "full" cells
        side = 1.0 / max(cols, rows)
        # score = total side length if all n squares had side `side`
        score = n * side
        if score > best_score:
            best_score = score
            best = (cols, rows, side)
    cols, rows, side = best
    squares = []
    for i in range(cols):
        for j in range(rows):
            if len(squares) >= n:
                break
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    return squares[:n]


# ----------------------------------------------------------------------------
# local search
# ----------------------------------------------------------------------------

def _refine(squares, budget, rng):
    """Simple stochastic hill climbing over (cx, cy, angle, side)."""
    n = len(squares)
    squares = [list(s) for s in squares]

    def total_side(sqs):
        return sum(s[3] for s in sqs)

    def feasible(sqs):
        corners = [_corners(*s) for s in sqs]
        for i in range(n):
            if _inside_penalty(corners[i]) > 1e-9:
                return False
            if sqs[i][3] < 0.0:
                return False
        for i in range(n):
            for j in range(i + 1, n):
                if sqs[i][3] <= 0.0 or sqs[j][3] <= 0.0:
                    continue
                if _sat_overlap(corners[i], corners[j]) > 1e-9:
                    return False
        return True

    # current best (keep the configuration, always feasible)
    best = [s[:] for s in squares]
    best_val = total_side(best)

    # step sizes
    pos_step = 0.5
    size_step = 0.5
    ang_step = 0.5
    it = 0
    while it < budget:
        it += 1
        # pick a random square and perturb
        i = rng.randrange(n)
        cand = [s[:] for s in best]
        s = cand[i]
        # random direction
        dx = rng.uniform(-pos_step, pos_step)
        dy = rng.uniform(-pos_step, pos_step)
        da = rng.uniform(-ang_step, ang_step)
        ds = rng.uniform(-size_step, size_step)
        s[0] = min(max(s[0] + dx, 0.0), 1.0)
        s[1] = min(max(s[1] + dy, 0.0), 1.0)
        s[2] = (s[2] + da) % 1.0
        s[3] = max(0.0, s[3] + ds)

        if feasible(cand):
            val = total_side(cand)
            if val >= best_val - 1e-12:
                best = cand
                best_val = val
                # occasionally shrink steps
                if it % (4 * n) == 0:
                    pos_step *= 0.85
                    size_step *= 0.85
                    ang_step *= 0.85
        else:
            # shrink steps when stuck
            if rng.random() < 0.002:
                pos_step *= 0.9
                size_step *= 0.9
                ang_step *= 0.9
        pos_step = max(pos_step, 1e-5)
        size_step = max(size_step, 1e-5)
        ang_step = max(ang_step, 1e-5)

    return [tuple(s) for s in best]


# ----------------------------------------------------------------------------
# public API
# ----------------------------------------------------------------------------

def solve(n):
    """Return n squares inside the unit square maximising the sum of side lengths."""
    if n <= 0:
        return []

    rng = random.Random(12345 + n)

    # A good analytical seed: perfect grid when possible, else grid + leftovers.
    start = _grid_config(n)

    # Try several restarts of hill climbing with time-aware budget.
    import time
    t0 = time.time()
    deadline = t0 + 55.0

    best = [tuple(s) for s in start]
    best_val = sum(s[3] for s in best)

    # scale budget: small n gets more restarts, large n fewer but longer
    attempts = 0
    while time.time() < deadline:
        attempts += 1
        if attempts == 1:
            init = [tuple(s) for s in start]
        else:
            # randomise start
            init = []
            for s in start:
                cx = min(max(s[0] + rng.uniform(-0.05, 0.05), 0.0), 1.0)
                cy = min(max(s[1] + rng.uniform(-0.05, 0.05), 0.0), 1.0)
                ang = (s[2] + rng.uniform(-0.1, 0.1)) % 1.0
                side = s[3]
                init.append((cx, cy, ang, side))

        # hill climb for a slice of time
        remaining = deadline - time.time()
        if remaining <= 0:
            break
        # each iteration is roughly constant cost; allocate iterations
        budget = int(min(200000, max(2000, remaining * 40000 / max(n, 1))))
        cand = _refine(init, budget, rng)
        val = sum(s[3] for s in cand)
        if val > best_val + 1e-12:
            best_val = val
            best = cand

        # stop early for small n (we usually converged)
        if n <= 6 and attempts >= 3:
            # refine once more with fine steps
            cand = _refine(best, 50000, rng)
            val = sum(s[3] for s in cand)
            if val > best_val + 1e-12:
                best_val = val
                best = cand
            break

    return best
# EVOLVE-BLOCK-END
