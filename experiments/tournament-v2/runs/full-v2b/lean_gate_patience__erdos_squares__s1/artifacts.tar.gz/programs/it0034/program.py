# EVOLVE-BLOCK-START
"""Packing n rotated squares in the unit square to maximise sum of sides.

Strategy
--------
We do NOT rely on a smooth surrogate.  Instead we generate a family of
structured seed layouts (axis aligned row/column grids, and "one big square
plus a filler grid" patterns), then apply a strict feasibility preserving
grow-and-nudge local search: candidate squares are enlarged and jiggled while
an exact separating-axis (SAT) test guarantees no interior overlap and full
containment.  The best feasible total side length over all seeds / restarts
wins.  This is robust for every n and needs no tuned energy weights.
"""
import math
import random
import time

# ----------------------------------------------------------------------------
# geometry
# ----------------------------------------------------------------------------

def _corners(cx, cy, ang, side):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side * 0.5
    return (
        (cx - h * ca + h * sa, cy - h * sa - h * ca),
        (cx + h * ca + h * sa, cy + h * sa - h * ca),
        (cx + h * ca - h * sa, cy + h * sa + h * ca),
        (cx - h * ca - h * sa, cy - h * sa + h * ca),
    )


def _sat_overlap(A, B):
    """Exact minimum translation distance (>0) if two convex polys overlap."""
    best = float("inf")
    for poly in (A, B):
        m = len(poly)
        for i in range(m):
            x0, y0 = poly[i]
            x1, y1 = poly[(i + 1) % m]
            ex, ey = x1 - x0, y1 - y0
            axx, axy = ey, -ex  # outward normal (CCW verts)
            nrm = math.hypot(axx, axy)
            if nrm < 1e-15:
                continue
            axx /= nrm
            axy /= nrm
            # project both polygons onto axis
            a_lo = a_hi = A[0][0] * axx + A[0][1] * axy
            for p in A[1:]:
                d = p[0] * axx + p[1] * axy
                if d < a_lo: a_lo = d
                if d > a_hi: a_hi = d
            b_lo = b_hi = B[0][0] * axx + B[0][1] * axy
            for p in B[1:]:
                d = p[0] * axx + p[1] * axy
                if d < b_lo: b_lo = d
                if d > b_hi: b_hi = d
            ov = min(a_hi, b_hi) - max(a_lo, b_lo)
            if ov <= 0.0:
                return 0.0
            if ov < best:
                best = ov
    return best if best != float("inf") else 0.0


def _outside(corners):
    pen = 0.0
    for x, y in corners:
        if x < 0.0: pen += -x
        if y < 0.0: pen += -y
        if x > 1.0: pen += x - 1.0
        if y > 1.0: pen += y - 1.0
    return pen


def _feasible(sqs, others_cache=None):
    n = len(sqs)
    cs = [_corners(*s) for s in sqs]
    for i in range(n):
        if sqs[i][3] < 0.0:
            return False
        if _outside(cs[i]) > 1e-11:
            return False
    for i in range(n):
        if sqs[i][3] <= 1e-12:
            continue
        for j in range(i + 1, n):
            if sqs[j][3] <= 1e-12:
                continue
            if _sat_overlap(cs[i], cs[j]) > 1e-11:
                return False
    return True


def _total(sqs):
    return sum(s[3] for s in sqs)


# ----------------------------------------------------------------------------
# structured seeds
# ----------------------------------------------------------------------------

def _grid(cols, rows, n):
    side = 1.0 / max(cols, rows)
    out = []
    for j in range(rows):
        for i in range(cols):
            if len(out) >= n:
                return out
            out.append([((i + 0.5) * side), ((j + 0.5) * side), 0.0, side])
    return out[:n]


def _big_plus_grid(big, n):
    """One square of side `big` placed in corner; fill rest with grid."""
    if big <= 0 or big >= 1:
        return None
    bx = by = big * 0.5
    cells = n - 1
    if cells <= 0:
        return [[bx, by, 0.0, big]]
    bw = 1.0 - big  # widths of remaining L region
    # assemble free rectangles: right strip, top strip
    right_area = bw * 1.0
    top_area = 1.0 * bw  # overlap handled by geometry
    # choose filler grid spacing from remaining region size
    # try a few configurations
    best = None
    best_score = -1.0
    for fcols in range(1, cells + 1):
        rows = (cells + fcols - 1) // fcols
        s = bw / max(fcols, rows)
        score = big + cells * s
        if score > best_score:
            best_score = score
            best = (fcols, rows, s)
    fcols, rows, s = best
    sqs = [[bx, by, 0.0, big]]
    cnt = 0
    # right strip
    for j in range(rows):
        for i in range(fcols):
            if cnt >= cells:
                break
            x = big + (i + 0.5) * s
            y = (j + 0.5) * s
            if x <= 1.0 and y <= 1.0:
                sqs.append([x, y, 0.0, s])
                cnt += 1
        if cnt >= cells:
            break
    # top strip for leftovers
    if cnt < cells:
        for j in range(rows + 1):
            for i in range(fcols):
                if cnt >= cells:
                    break
                x = (i + 0.5) * s
                y = big + (j + 0.5) * s
                if x <= 1.0 and y <= 1.0:
                    sqs.append([x, y, 0.0, s])
                    cnt += 1
            if cnt >= cells:
                break
    if cnt < cells:
        return None
    return sqs


def _seeds(n, rng):
    seeds = []
    # pure grids
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        g = _grid(cols, rows, n)
        if g and len(g) == n:
            seeds.append(g)
    # big + grid, sweeping the big size
    for big in [0.55, 0.6, 0.65, 0.7, 0.5, 0.45, 0.75]:
        b = _big_plus_grid(big, n)
        if b:
            seeds.append(b)
    # jittered grids
    base = _grid(max(1, int(round(math.sqrt(n)))), (n + max(1, int(round(math.sqrt(n)))) - 1) // max(1, int(round(math.sqrt(n)))), n)
    for _ in range(6):
        j = [[s[0] + rng.uniform(-0.03, 0.03),
              s[1] + rng.uniform(-0.03, 0.03),
              0.0,
              s[3]] for s in base]
        seeds.append(j)
    return seeds


# ----------------------------------------------------------------------------
# strict grow-and-nudge local search
# ----------------------------------------------------------------------------

def _repair(sqs, rng, tries=200):
    """nudge squares until feasible (only used on near-feasible starts)."""
    n = len(sqs)
    sqs = [s[:] for s in sqs]
    for _ in range(tries):
        if _feasible(sqs):
            return sqs
        # shrink / push the worst offender
        cs = [_corners(*s) for s in sqs]
        # find first violation and fix it
        fixed = False
        for i in range(n):
            if _outside(cs[i]) > 1e-11:
                x, y = cs[i][0]
                sqs[i][3] *= 0.98
                fixed = True
                break
        if fixed:
            continue
        for i in range(n):
            if sqs[i][3] <= 1e-12:
                continue
            for j in range(i + 1, n):
                if sqs[j][3] <= 1e-12:
                    continue
                ov = _sat_overlap(cs[i], cs[j])
                if ov > 1e-11:
                    sqs[i][3] = max(0.0, sqs[i][3] - ov * 0.5)
                    sqs[j][3] = max(0.0, sqs[j][3] - ov * 0.5)
                    fixed = True
                    break
            if fixed:
                break
        if not fixed:
            break
    return sqs


def _grow_nudge(sqs, rng, iterations):
    n = len(sqs)
    sqs = [s[:] for s in sqs]
    if not _feasible(sqs):
        sqs = _repair(sqs, rng)
    best = [s[:] for s in sqs]
    best_val = _total(best)

    pos_step = 0.02
    ang_step = 0.02
    for it in range(iterations):
        i = rng.randrange(n)
        cand = [s[:] for s in best]
        s = cand[i]
        # nudge
        s[0] += rng.uniform(-pos_step, pos_step)
        s[1] += rng.uniform(-pos_step, pos_step)
        s[2] = (s[2] + rng.uniform(-ang_step, ang_step)) % 1.0
        s[3] = max(0.0, s[3] + rng.uniform(-0.01, 0.02))
        s[0] = min(max(s[0], 0.0), 1.0)
        s[1] = min(max(s[1], 0.0), 1.0)
        if _feasible(cand):
            v = _total(cand)
            if v >= best_val - 1e-12:
                best = cand
                best_val = v
        # periodically try greedy growth of every square
        if it % (3 * n) == 0:
            for k in range(n):
                trial = [s[:] for s in best]
                trial[k][3] *= 1.02
                if _feasible(trial):
                    best = trial
                    best_val = _total(best)
        # anneal steps
        if it % (10 * n) == 0:
            pos_step *= 0.9
            ang_step *= 0.9
        pos_step = max(pos_step, 1e-4)
        ang_step = max(ang_step, 1e-4)
    return best


# ----------------------------------------------------------------------------
# public API
# ----------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    rng = random.Random(987654321 + n)
    t0 = time.time()
    deadline = t0 + 55.0

    seeds = _seeds(n, rng)
    best = None
    best_val = -1.0

    for sd in seeds:
        if time.time() > deadline:
            break
        if not _feasible(sd):
            sd = _repair(sd, rng)
            if not _feasible(sd):
                continue
        cand = _grow_nudge(sd, rng, 3000)
        v = _total(cand)
        if v > best_val:
            best_val = v
            best = cand

    # extended random restarts from the best found so far
    restart = 0
    while time.time() < deadline and best is not None:
        restart += 1
        cur = [s[:] for s in best]
        # shake
        for s in cur:
            s[0] = min(max(s[0] + rng.uniform(-0.05, 0.05), 0.0), 1.0)
            s[1] = min(max(s[1] + rng.uniform(-0.05, 0.05), 0.0), 1.0)
            s[2] = (s[2] + rng.uniform(-0.15, 0.15)) % 1.0
            s[3] *= 0.98
        if not _feasible(cur):
            cur = _repair(cur, rng)
            if not _feasible(cur):
                continue
        # allocate remaining time to iterations
        remaining = deadline - time.time()
        iters = int(min(30000, max(3000, remaining * 6000 / max(n, 1))))
        cand = _grow_nudge(cur, rng, iters)
        v = _total(cand)
        if v > best_val + 1e-12:
            best_val = v
            best = cand

    if best is None:
        best = [[0.5, 0.5, 0.0, 0.0] for _ in range(n)]
    return [tuple(s) for s in best]
# EVOLVE-BLOCK-END
