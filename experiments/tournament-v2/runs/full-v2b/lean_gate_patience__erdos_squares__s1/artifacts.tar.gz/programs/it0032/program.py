# EVOLVE-BLOCK-START
"""Packing n rotated squares in the unit square maximising the sum of side lengths.

Strategy
--------
For most n the best known configuration is a *dominant* large square (often
axis aligned in a corner) plus a grid of smaller squares filling the leftover
L-shaped / rectangular region.  We therefore

 1. generate a family of deterministic seeds: one large square in each corner
    (and along an edge) with a variable side, the rest of the unit square tiled
    by an equal-sized grid of small squares;
 2. also generate the plain best-grid seed and a "two big squares" seed;
 3. run a SAT-feasibility based grow/polish routine on every seed, which grows
    squares while nudging centres and angles to keep exact separation, and
    keeps the best strictly feasible result.

All geometric separation checks use the separating-axis theorem, which is exact
for convex polygons.
"""
import math
import random
import time

import numpy as np


# ----------------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------------

def _corners(cx, cy, ang, side):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side * 0.5
    local = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    rot = np.array([[ca, -sa], [sa, ca]], dtype=float)
    return local @ rot.T + np.array([cx, cy])


def _sat_overlap(ca, cb):
    """Minimum translation distance of two convex polygons (0 if disjoint)."""
    polys = (ca, cb)
    best = float("inf")
    for poly in polys:
        m = len(poly)
        for i in range(m):
            p0 = poly[i]
            p1 = poly[(i + 1) % m]
            edge = p1 - p0
            axis = np.array([edge[1], -edge[0]], dtype=float)
            nrm = math.hypot(axis[0], axis[1])
            if nrm < 1e-15:
                continue
            axis /= nrm
            mins = []
            maxs = []
            for q in polys:
                dots = q @ axis
                mins.append(dots.min())
                maxs.append(dots.max())
            ov = min(maxs[0], maxs[1]) - max(mins[0], mins[1])
            if ov <= 0.0:
                return 0.0
            if ov < best:
                best = ov
    return best if best != float("inf") else 0.0


def _inside_penalty(corners):
    lo = corners.min(axis=0)
    hi = corners.max(axis=0)
    pen = 0.0
    if lo[0] < 0.0:
        pen += -lo[0]
    if lo[1] < 0.0:
        pen += -lo[1]
    if hi[0] > 1.0:
        pen += hi[0] - 1.0
    if hi[1] > 1.0:
        pen += hi[1] - 1.0
    return pen


def _feasible(sqs, tol=1e-9):
    cs = [_corners(*s) for s in sqs]
    for i in range(len(sqs)):
        if sqs[i][3] < -1e-12:
            return False
        if _inside_penalty(cs[i]) > tol:
            return False
    for i in range(len(sqs)):
        for j in range(i + 1, len(sqs)):
            if sqs[i][3] <= 0.0 or sqs[j][3] <= 0.0:
                continue
            if _sat_overlap(cs[i], cs[j]) > tol:
                return False
    return True


def _total(sqs):
    return sum(s[3] for s in sqs)


# ----------------------------------------------------------------------------
# seed generators
# ----------------------------------------------------------------------------

def _grid_seed(n):
    best = None
    best_score = -1.0
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        side = 1.0 / max(cols, rows)
        score = n * side
        if score > best_score:
            best_score = score
            best = (cols, rows, side)
    cols, rows, side = best
    sqs = []
    for j in range(rows):
        for i in range(cols):
            if len(sqs) >= n:
                break
            sqs.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    return sqs[:n]


def _corner_big_seed(n, big, corner, small, cols_small, rows_small):
    """One big square of side `big` in `corner`; small equal squares tile the rest.

    The leftover region is the unit square minus the big square (an L-shape).
    We fill it with a grid of squares of side `small`, placed greedily on a
    lattice anchored at the opposite corner.
    """
    if corner == 0:      # bottom-left
        bx, by = big / 2.0, big / 2.0
        ox, oy = big, big
    elif corner == 1:    # bottom-right
        bx, by = 1.0 - big / 2.0, big / 2.0
        ox, oy = 0.0, big
    elif corner == 2:    # top-right
        bx, by = 1.0 - big / 2.0, 1.0 - big / 2.0
        ox, oy = 0.0, 0.0
    else:                # top-left
        bx, by = big / 2.0, 1.0 - big / 2.0
        ox, oy = big, 0.0

    sqs = [[bx, by, 0.0, big]]
    need = n - 1
    if need <= 0:
        return sqs
    # lattice over the residual rectangle region; skip cells overlapping big sq
    count = 0
    j = 0
    while count < need and j < rows_small:
        i = 0
        while count < need and i < cols_small:
            cx = ox + (i + 0.5) * small
            cy = oy + (j + 0.5) * small
            # does this small square overlap the big one?
            sx0, sy0 = cx - small / 2.0, cy - small / 2.0
            sx1, sy1 = cx + small / 2.0, cy + small / 2.0
            bx0, by0 = bx - big / 2.0, by - big / 2.0
            bx1, by1 = bx + big / 2.0, by + big / 2.0
            ox_ = min(sx1, bx1) - max(sx0, bx0)
            oy_ = min(sy1, by1) - max(sy0, by0)
            inside = (sx0 >= -1e-9 and sy0 >= -1e-9 and
                      sx1 <= 1.0 + 1e-9 and sy1 <= 1.0 + 1e-9)
            if inside and not (ox_ > 1e-6 and oy_ > 1e-6):
                sqs.append([cx, cy, 0.0, small])
                count += 1
            i += 1
        j += 1
    # pad remaining with tiny zero squares placed anywhere (will be grown)
    while len(sqs) < n:
        sqs.append([0.5, 0.5, 0.0, 0.0])
    return sqs[:n]


def _two_big_seed(n, big):
    sqs = [[big / 2.0, big / 2.0, 0.0, big],
           [1.0 - big / 2.0, 1.0 - big / 2.0, 0.0, big]]
    small = min(1.0 - big, 0.5)
    count = 2
    j = 0
    while count < n:
        for i in range(2):
            for k in range(2):
                if count >= n:
                    break
                cx = i * (1.0 - big) + ((1.0 - big) / 2.0)
                cy = k * (1.0 - big) + ((1.0 - big) / 2.0)
                # skip cells overlapping the big squares
                if i == 0 and k == 0:
                    continue
                if i == 1 and k == 1:
                    continue
                sqs.append([cx, cy, 0.0, small])
                count += 1
        j += 1
        if j > 10:
            break
    while len(sqs) < n:
        sqs.append([0.5, 0.5, 0.0, 0.0])
    return sqs[:n]


# ----------------------------------------------------------------------------
# grow / polish routine driven by exact feasibility
# ----------------------------------------------------------------------------

def _grow_polish(sqs, rng, iters):
    """Grow squares, nudging positions/angles, keeping strict feasibility."""
    n = len(sqs)
    best = [list(s) for s in sqs]
    best_val = _total(best)

    pos_step = 0.02
    ang_step = 0.02
    size_step = 0.02

    for it in range(iters):
        i = rng.randrange(n)
        cand = [s[:] for s in best]
        s = cand[i]
        # bias: try to grow
        if rng.random() < 0.6:
            ds = rng.uniform(0.0, size_step)
        else:
            ds = rng.uniform(-size_step, size_step)
        s[3] = max(0.0, s[3] + ds)
        s[0] = min(max(s[0] + rng.uniform(-pos_step, pos_step), 0.0), 1.0)
        s[1] = min(max(s[1] + rng.uniform(-pos_step, pos_step), 0.0), 1.0)
        s[2] = (s[2] + rng.uniform(-ang_step, ang_step)) % 1.0

        if _feasible(cand):
            val = _total(cand)
            if val >= best_val - 1e-12:
                best = cand
                best_val = val
            else:
                if rng.random() < 0.002:
                    pos_step *= 0.9
                    size_step *= 0.9
                    ang_step *= 0.9
        else:
            if rng.random() < 0.05:
                pos_step *= 0.95
                size_step *= 0.95
                ang_step *= 0.95
        pos_step = max(pos_step, 1e-5)
        size_step = max(size_step, 1e-5)
        ang_step = max(ang_step, 1e-5)
    return best


def _polish_sizes(sqs, rng, passes):
    """For each square try to enlarge it while keeping feasibility (coordinate ascent)."""
    n = len(sqs)
    best = [list(s) for s in sqs]
    for _ in range(passes):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            lo, hi = 0.0, 1.0
            best_s = best[i][3]
            for _ in range(20):
                mid = (lo + hi) / 2.0
                cand = [s[:] for s in best]
                cand[i][3] = mid
                if _feasible(cand):
                    best_s = mid
                    lo = mid
                else:
                    hi = mid
            if best_s > best[i][3] + 1e-9:
                best[i][3] = best_s
                improved = True
        if not improved:
            break
    return best


# ----------------------------------------------------------------------------
# public API
# ----------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(9876 + n)
    t0 = time.time()
    deadline = t0 + 52.0

    seeds = []

    # plain best grid
    seeds.append(_grid_seed(n))

    # dominant-square seeds: sweep big side and corners
    for corner in range(4):
        for big in np.linspace(0.35, 0.95, 25):
            big = float(big)
            rest = 1.0 - big
            for cols_small in range(1, n + 1):
                rows_small = max(1, (n - 1 + cols_small - 1) // cols_small)
                small = rest / max(cols_small, rows_small)
                if small <= 0:
                    continue
                seeds.append(_corner_big_seed(n, big, corner, small,
                                              cols_small, rows_small))

    # two-big seeds
    for big in np.linspace(0.3, 0.6, 12):
        seeds.append(_two_big_seed(n, float(big)))

    best = None
    best_val = -1.0

    for si, seed in enumerate(seeds):
        if time.time() > deadline:
            break
        cand = [list(s) for s in seed]
        # quick size polish first
        cand = _polish_sizes(cand, rng, 3)
        # grow/polish
        remaining = deadline - time.time()
        iters = int(min(6000, max(500, remaining * 3000 / max(n, 1))))
        cand = _grow_polish(cand, rng, iters)
        cand = _polish_sizes(cand, rng, 4)
        val = _total(cand)
        if val > best_val + 1e-9 and _feasible(cand):
            best_val = val
            best = cand

    if best is None:
        best = [list(s) for s in _grid_seed(n)]
        best = _polish_sizes(best, rng, 4)

    return [tuple(s) for s in best]
# EVOLVE-BLOCK-END
