# EVOLVE-BLOCK-START
"""Packing n rotated squares in the unit square to maximise the sum of sides.

Strategy
--------
We greedily search over *structured* layouts (a dominant square plus a grid of
fillers, pure grids, column/row splits) and polish each with a feasibility-
preserving "grow-and-refit" local search:

  * feasibility is checked exactly with the separating-axis test on the four
    edge normals of each square (exact for convex polygons) plus containment
    in [0,1]^2;
  * the polish loop repeatedly tries to enlarge one square at a time while
    nudging/rotating it, accepting any change that keeps the layout feasible
    and does not decrease the total side length.

This maximises sum(side) directly instead of optimising a soft penalty.
"""
import math
import random
import time

import numpy as np


# ---------------------------------------------------------------------------
# geometry
# ---------------------------------------------------------------------------

def _corners(cx, cy, ang, side):
    """Four corners (counter-clockwise) of a square as a (4,2) array."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side * 0.5
    local = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    rot = np.array([[ca, -sa], [sa, ca]], dtype=float)
    return local @ rot.T + np.array([cx, cy])


def _sat_overlap(ca, cb):
    """Exact penetration depth of two convex polygons; 0 if disjoint."""
    polys = (ca, cb)
    best = float("inf")
    for poly in polys:
        m = len(poly)
        for i in range(m):
            p0 = poly[i]
            p1 = poly[(i + 1) % m]
            ex, ey = p1[0] - p0[0], p1[1] - p0[1]
            ax, ay = ey, -ex
            n = math.hypot(ax, ay)
            if n < 1e-15:
                continue
            ax /= n
            ay /= n
            min0 = min1 = float("inf")
            max0 = max1 = -float("inf")
            for q in ca:
                d = q[0] * ax + q[1] * ay
                if d < min0: min0 = d
                if d > max0: max0 = d
            for q in cb:
                d = q[0] * ax + q[1] * ay
                if d < min1: min1 = d
                if d > max1: max1 = d
            ov = min(max0, max1) - max(min0, min1)
            if ov <= 0.0:
                return 0.0
            if ov < best:
                best = ov
    return 0.0 if best == float("inf") else best


def _inside_penalty(corners):
    lo = corners.min(axis=0)
    hi = corners.max(axis=0)
    pen = 0.0
    if lo[0] < 0.0: pen += -lo[0]
    if lo[1] < 0.0: pen += -lo[1]
    if hi[0] > 1.0: pen += hi[0] - 1.0
    if hi[1] > 1.0: pen += hi[1] - 1.0
    return pen


# ---------------------------------------------------------------------------
# feasibility of a whole configuration
# ---------------------------------------------------------------------------

def _feasible(squares, tol=1e-9):
    n = len(squares)
    corners = []
    for s in squares:
        if s[3] < -1e-12:
            return False
        c = _corners(s[0], s[1], s[2], max(s[3], 0.0))
        if _inside_penalty(c) > tol:
            return False
        corners.append(c)
    for i in range(n):
        if squares[i][3] <= 0.0:
            continue
        for j in range(i + 1, n):
            if squares[j][3] <= 0.0:
                continue
            if _sat_overlap(corners[i], corners[j]) > tol:
                return False
    return True


def _total(squares):
    return sum(max(s[3], 0.0) for s in squares)


# ---------------------------------------------------------------------------
# seeds
# ---------------------------------------------------------------------------

def _seed_grid(n, cols, rows, angle=0.0):
    """Uniform grid of `n` cells filling cols x rows."""
    side = 1.0 / max(cols, rows)
    sq = []
    for i in range(cols):
        for j in range(rows):
            if len(sq) >= n:
                break
            sq.append([(i + 0.5) * side, (j + 0.5) * side, angle, side])
    return sq[:n]


def _seed_dominant(n, big, cols, rows):
    """One big square in a corner plus a grid filling the L-shaped remainder."""
    big = min(big, 1.0)
    sq = [[big * 0.5, big * 0.5, 0.0, big]]
    rem = n - 1
    if rem <= 0:
        return sq
    # right strip and top strip
    rw = 1.0 - big
    cells = []
    if rw > 1e-9:
        for c in range(cols):
            for r in range(rows + 1):
                cells.append((big + (c + 0.5) * rw / cols,
                              (r + 0.5) / (rows + 1), rw / cols))
    for c in range(cols + 1):
        for r in range(rows):
            cells.append(((c + 0.5) / (cols + 1),
                          big + (r + 0.5) * rw / rows, rw / rows))
    # pick `rem` smallest cells
    cells.sort(key=lambda t: t[2])
    for cell in cells[:rem]:
        sq.append([cell[0], cell[1], 0.0, cell[2]])
    while len(sq) < n:
        sq.append([0.5, 0.5, 0.0, 0.0])
    return sq[:n]


def _seed_cols(n, cols):
    """Vertical columns, each split into equal squares."""
    sq = []
    w = 1.0 / cols
    for c in range(cols):
        cnt = max(1, round(n / cols))
        h = 1.0 / cnt
        side = min(w, h)
        for r in range(cnt):
            if len(sq) >= n:
                break
            sq.append([(c + 0.5) * w, (r + 0.5) * h, 0.0, side])
    return sq[:n]


def _seeds(n):
    out = []
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        if rows * cols >= n:
            out.append(_seed_grid(n, cols, rows))
    for cols in range(1, n + 1):
        if cols <= n:
            out.append(_seed_cols(n, cols))
    # dominant-square seeds
    for k in range(2, min(8, n)):
        for big_num in range(2, 6):
            big = big_num / 5.0
            for cols in range(1, 5):
                for rows in range(1, 5):
                    out.append(_seed_dominant(n, big, cols, rows))
    return out


# ---------------------------------------------------------------------------
# polish: grow-and-refit
# ---------------------------------------------------------------------------

def _grow_refit(squares, rng, iters):
    n = len(squares)
    sq = [list(s) for s in squares]
    # normalise into the box if slightly out
    for s in sq:
        c = _corners(s[0], s[1], s[2], s[3])
        lo = c.min(axis=0)
        hi = c.max(axis=0)
        dx = 0.0
        dy = 0.0
        if lo[0] < 0: dx = -lo[0]
        elif hi[0] > 1: dx = 1.0 - hi[0]
        if lo[1] < 0: dy = -lo[1]
        elif hi[1] > 1: dy = 1.0 - hi[1]
        s[0] += dx
        s[1] += dy
    if not _feasible(sq):
        return None
    val = _total(sq)
    best = [s[:] for s in sq]
    best_val = val

    # candidate step schedule
    for it in range(iters):
        i = rng.randrange(n)
        base = best[i]
        # try to grow it
        tried = False
        for grow in (0.06, 0.02, 0.005, 0.001):
            for _ in range(6):
                cand = [s[:] for s in best]
                s = cand[i]
                s[3] = min(s[3] + grow, 1.0)
                s[0] = min(max(s[0] + rng.uniform(-grow, grow), 0.0), 1.0)
                s[1] = min(max(s[1] + rng.uniform(-grow, grow), 0.0), 1.0)
                s[2] = (s[2] + rng.uniform(-grow, grow)) % 1.0
                if _feasible(cand):
                    v = _total(cand)
                    if v >= best_val - 1e-12:
                        best = cand
                        best_val = v
                        tried = True
                        break
            if tried:
                break
        if not tried:
            # random reposition to escape
            cand = [s[:] for s in best]
            s = cand[i]
            s[0] = min(max(s[0] + rng.uniform(-0.05, 0.05), 0.0), 1.0)
            s[1] = min(max(s[1] + rng.uniform(-0.05, 0.05), 0.0), 1.0)
            s[2] = (s[2] + rng.uniform(-0.2, 0.2)) % 1.0
            if _feasible(cand):
                v = _total(cand)
                if v > best_val + 1e-12:
                    best = cand
                    best_val = v
    return best


# ---------------------------------------------------------------------------
# public API
# ---------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    rng = random.Random(98765 + n)
    t0 = time.time()
    deadline = t0 + 55.0

    # special trivial cases
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_val = -1.0

    seed_list = _seeds(n)

    # quick pass: evaluate raw seeds (some are already feasible & good)
    for seed in seed_list:
        sq = [list(s) for s in seed]
        for s in sq:
            c = _corners(s[0], s[1], s[2], s[3])
            lo = c.min(axis=0); hi = c.max(axis=0)
            if lo[0] < 0: s[0] -= lo[0]
            elif hi[0] > 1: s[0] += 1.0 - hi[0]
            if lo[1] < 0: s[1] -= lo[1]
            elif hi[1] > 1: s[1] += 1.0 - hi[1]
        if _feasible(sq):
            v = _total(sq)
            if v > best_val:
                best_val = v
                best = [tuple(s) for s in sq]

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0) for _ in range(n)]
        best_val = 0.0

    # polish seeds by grow-refit, spending a slice of time each
    order = list(range(len(seed_list)))
    rng.shuffle(order)
    idx = 0
    while time.time() < deadline:
        if idx < len(order):
            seed = seed_list[order[idx]]
            idx += 1
        else:
            # random restart from current best
            seed = []
            for s in best:
                seed.append([min(max(s[0] + rng.uniform(-0.05, 0.05), 0.0), 1.0),
                             min(max(s[1] + rng.uniform(-0.05, 0.05), 0.0), 1.0),
                             (s[2] + rng.uniform(-0.1, 0.1)) % 1.0,
                             s[3]])
        iters = max(3000, int(60000 / max(n, 1)))
        cand = _grow_refit(seed, rng, iters)
        if cand is not None:
            v = _total(cand)
            if v > best_val + 1e-12:
                best_val = v
                best = [tuple(s) for s in cand]

    # final long polish from best
    remaining = deadline - time.time()
    if remaining > 0 and best is not None:
        cand = _grow_refit([list(s) for s in best], rng,
                           max(20000, int(remaining * 50000 / max(n, 1))))
        if cand is not None and _total(cand) > best_val + 1e-12:
            best = [tuple(s) for s in cand]

    return best
# EVOLVE-BLOCK-END
