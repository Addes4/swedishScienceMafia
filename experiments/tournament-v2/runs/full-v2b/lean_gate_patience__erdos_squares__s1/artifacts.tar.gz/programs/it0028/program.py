# EVOLVE-BLOCK-START
"""Grid/strip seeding plus continuous nonlinear optimization packing of squares."""

import math
import random
import numpy as np
from scipy.optimize import minimize


# ---------------------------------------------------------------- geometry ---
def _axes(a):
    t = 2.0 * math.pi * a
    c, s = math.cos(t), math.sin(t)
    return ((c, s), (-s, c))


def _proj(cx, cy, ax, ay, a, s):
    h = 0.5 * s
    ux, uy = _axes(a)
    r = h * (abs(ux[0] * ax + ux[1] * ay) + abs(uy[0] * ax + uy[1] * ay))
    d = cx * ax + cy * ay
    return d - r, d + r


def _overlap_amount(sq1, sq2):
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 0.0 or s2 <= 0.0:
        return -1.0
    best = -1.0
    for (ax, ay) in (list(_axes(a1)) + list(_axes(a2))):
        lo1, hi1 = _proj(cx1, cy1, ax, ay, a1, s1)
        lo2, hi2 = _proj(cx2, cy2, ax, ay, a2, s2)
        ov = min(hi1 - lo2, hi2 - lo1)
        if ov <= 0.0:
            return ov
        if best < 0.0 or ov < best:
            best = ov
    return best


def _inside(cx, cy, a, s, eps=1e-9):
    if s <= 0.0:
        return True
    t = 2.0 * math.pi * a
    c, sn = abs(math.cos(t)), abs(math.sin(t))
    r = 0.5 * s * (c + sn)
    return (cx - r >= -eps and cx + r <= 1.0 + eps and
            cy - r >= -eps and cy + r <= 1.0 + eps)


# Smooth signed overlap (positive = penetrating) for two squares, as a smooth
# approximation of the SAT max penetration. Used for gradient-based optimize.
def _smooth_overlap(sq1, sq2, tau=1e-3):
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 1e-12 or s2 <= 1e-12:
        return 0.0
    pen = []
    for (ax, ay) in (list(_axes(a1)) + list(_axes(a2))):
        lo1, hi1 = _proj(cx1, cy1, ax, ay, a1, s1)
        lo2, hi2 = _proj(cx2, cy2, ax, ay, a2, s2)
        pen.append(min(hi1 - lo2, hi2 - lo1))
    # smooth max of penetration (max is the binding SAT axis)
    m = max(pen)
    s = sum(math.exp((p - m) / tau) for p in pen)
    return m + tau * math.log(s)


def _containment_pen(cx, cy, a, s):
    if s <= 1e-12:
        return 0.0
    t = 2.0 * math.pi * a
    r = 0.5 * s * (abs(math.cos(t)) + abs(math.sin(t)))
    p = 0.0
    p = max(p, r - cx)
    p = max(p, cx + r - 1.0)
    p = max(p, r - cy)
    p = max(p, cy + r - 1.0)
    return p


# ------------------------------------------------------------------ seeds ---
def _grid_seed(n):
    best = None
    for k in range(1, n + 1):
        for m in range(1, n + 1):
            if k * m < n:
                continue
            side = min(1.0 / k, 1.0 / m)
            cells = []
            for i in range(k):
                for j in range(m):
                    cx = (i + 0.5) * (1.0 / k)
                    cy = (j + 0.5) * (1.0 / m)
                    cells.append([cx, cy, 0.0, side])
            if best is None or len(cells) < len(best):
                best = cells
    return best if best is not None else []


def _strip_seed(n, vertical=True):
    best = None
    for k in range(1, n + 1):
        w = 1.0 / k
        side = w
        per = max(1, int(round(1.0 / side)))
        total = k * per
        if total < n:
            continue
        cells = []
        for i in range(k):
            for j in range(per):
                if vertical:
                    cx = (i + 0.5) * w
                    cy = (j + 0.5) * (1.0 / per)
                else:
                    cx = (j + 0.5) * (1.0 / per)
                    cy = (i + 0.5) * w
                cells.append([cx, cy, 0.0, side])
        if len(cells) >= n and (best is None or len(cells) < len(best)):
            best = cells
    return best if best is not None else []


def _slicing_seed(n):
    cells = [[0.5, 0.5, 0.0, 1.0]]
    while len(cells) < n:
        idx = max(range(len(cells)), key=lambda t: cells[t][3])
        cx, cy, ang, s = cells[idx]
        ns = s * 0.5
        d = s * 0.25
        cells.pop(idx)
        for dx in (-d, d):
            for dy in (-d, d):
                cells.append([cx + dx, cy + dy, ang, ns])
    cells.sort(key=lambda t: -t[3])
    return cells[:n]


def _big_plus_grid_seed(n):
    """One large square + grid for the rest, several variants."""
    out = []
    for k in range(1, n):
        rest = n - k
        if rest <= 0:
            continue
        # large square side L placed bottom-left; grid in remaining region
        for L in (0.5, 0.55, 0.6, 0.65):
            cells = [[L / 2.0, L / 2.0, 0.0, L]]
            # remaining L-shape pack rest as grid squares
            for i in range(k):
                pass
            break
        break
    return out


def _fit_seed(cells):
    idx = sorted(range(len(cells)), key=lambda i: -cells[i][3])
    placed = []
    for i in idx:
        cx, cy, a, s = cells[i]
        a = a % 0.5
        t = 2.0 * math.pi * a
        r = abs(math.cos(t)) + abs(math.sin(t))
        s = min(s, 1.0 / r if r > 1e-12 else 1.0)
        if not (0.0 <= cx <= 1.0):
            cx = 0.5
        if not (0.0 <= cy <= 1.0):
            cy = 0.5
        for _ in range(60):
            if not _inside(cx, cy, a, s):
                s *= 0.95
                continue
            ok = True
            for p in placed:
                if _overlap_amount((cx, cy, a, s), p) > 1e-12:
                    ok = False
                    break
            if ok:
                break
            s *= 0.9
        placed.append([cx, cy, a, max(s, 0.0)])
    return placed


# ---------------------------------------------------------------- growing ---
def _can_grow(cur, i, s_new, eps=1e-10):
    cx, cy, a, _ = cur[i]
    if not _inside(cx, cy, a, s_new, eps):
        return False
    test = (cx, cy, a, s_new)
    for j in range(len(cur)):
        if j == i:
            continue
        if _overlap_amount(test, cur[j]) > eps:
            return False
    return True


def _grow_all(cur, rounds=6, factors=(1.15, 1.08, 1.04, 1.02, 1.01, 1.005, 1.002)):
    n = len(cur)
    order = sorted(range(n), key=lambda i: -cur[i][3])
    improved = True
    rnd = 0
    while improved and rnd < rounds:
        improved = False
        rnd += 1
        for i in order:
            s = cur[i][3]
            for f in factors:
                ns = s * f
                if _can_grow(cur, i, ns):
                    cur[i][3] = ns
                    improved = True
                    break
    return cur


# ------------------------------------------------- continuous optimization ---
def _pack_vec_to_sqs(v, n):
    out = []
    for i in range(n):
        out.append((v[4 * i], v[4 * i + 1], v[4 * i + 2] % 0.5, abs(v[4 * i + 3])))
    return out


def _feasible(sqs, tol=1e-7):
    n = len(sqs)
    for i in range(n):
        cx, cy, a, s = sqs[i]
        if s < -tol:
            return False
        if not _inside(cx, cy, a % 0.5, s, 1e-6):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap_amount(sqs[i], sqs[j]) > tol:
                return False
    return True


def _obj_penalty(v, n, w_pen):
    sqs = _pack_vec_to_sqs(v, n)
    total = sum(s for (_, _, _, s) in sqs)
    pen = 0.0
    for i in range(n):
        cx, cy, a, s = sqs[i]
        p = _containment_pen(cx, cy, a % 0.5, s)
        if p > 0:
            pen += p * p
    for i in range(n):
        for j in range(i + 1, n):
            ov = _overlap_amount(sqs[i], sqs[j])
            if ov > 0:
                pen += ov * ov
    return -total + w_pen * pen


def _optimize_layout(seed, n, maxiter=300, w_pen=1e5):
    sqs = _fit_seed(seed)
    while len(sqs) > n:
        sqs.pop()
    while len(sqs) < n:
        sqs.append([0.5, 0.5, 0.0, 0.0])
    _grow_all(sqs, rounds=6)
    v0 = []
    for (cx, cy, a, s) in sqs:
        v0.append(cx)
        v0.append(cy)
        v0.append(a % 0.5)
        v0.append(max(s, 1e-6))
    v0 = np.array(v0, dtype=float)

    best_feas = None
    best_feas_score = -1.0

    for w in (w_pen, w_pen * 10.0, 1e7):
        try:
            res = minimize(_obj_penalty, v0, args=(n, w),
                           method='Nelder-Mead',
                           options={'maxiter': maxiter, 'xatol': 1e-6,
                                    'fatol': 1e-9})
        except Exception:
            res = None
        if res is not None:
            v0 = res.x
        sqs = _pack_vec_to_sqs(v0, n)
        # repair to feasible
        sqs = _repair(sqs, n)
        if _feasible(sqs):
            sc = sum(s for (_, _, _, s) in sqs)
            if sc > best_feas_score:
                best_feas_score = sc
                best_feas = [list(c) for c in sqs]
    return best_feas


def _repair(sqs, n):
    """Greedily shrink offenders until feasible, then re-grow."""
    sqs = [list(c) for c in sqs]
    sqs.sort(key=lambda t: -t[3])
    placed = []
    for c in sqs:
        cx, cy, a, s = c
        a = a % 0.5
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        for _ in range(200):
            if _inside(cx, cy, a, s):
                ok = True
                for p in placed:
                    if _overlap_amount((cx, cy, a, s), p) > 1e-9:
                        ok = False
                        break
                if ok:
                    break
            s *= 0.96
            if s < 1e-9:
                s = 0.0
                break
        placed.append([cx, cy, a, max(s, 0.0)])
    _grow_all(placed, rounds=8)
    return placed


# ---------------------------------------------------------------- driver ---
def _seed_candidates(n):
    seeds = []
    seeds.append(_slicing_seed(n))
    seeds.append(_grid_seed(n))
    seeds.append(_strip_seed(n, True))
    seeds.append(_strip_seed(n, False))
    out = []
    seen = set()
    for s in seeds:
        if not s:
            continue
        key = tuple(sorted(round(c[3], 6) for c in s))
        if key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(20240517)

    best = None
    best_score = -1.0

    candidates = _seed_candidates(n)
    for seed in candidates:
        cur = _fit_seed(seed)
        if len(cur) < n:
            continue
        while len(cur) > n:
            cur.pop()
        _grow_all(cur, rounds=8)
        _grow_all(cur, rounds=4)
        score = sum(c[3] for c in cur)
        if score > best_score:
            best_score = score
            best = [list(c) for c in cur]

    # Continuous optimization on the best seed
    if best is not None:
        opt = _optimize_layout(best, n, maxiter=400)
        if opt is not None:
            sc = sum(c[3] for c in opt)
            if sc > best_score:
                best_score = sc
                best = opt

    if best is None:
        best = _fit_seed(_slicing_seed(n))[:n]

    # Final feasibility pass
    best = _repair(best, n)
    final = sorted(best, key=lambda t: -t[3])
    while len(final) < n:
        final.append([0.5, 0.5, 0.0, 0.0])
    final = final[:n]

    out = []
    for (cx, cy, a, s) in final:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    return out
# EVOLVE-BLOCK-END
