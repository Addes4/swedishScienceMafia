import math
import random

# EVOLVE-BLOCK-START

# ---------------- geometry helpers ----------------

def _corners(cx, cy, ang, side):
    th = 2.0 * math.pi * ang
    c, s = math.cos(th), math.sin(th)
    h = 0.5 * side
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for (lx, ly) in pts:
        x = cx + lx * c - ly * s
        y = cy + lx * s + ly * c
        out.append((x, y))
    return out


def _separated(a, b):
    for poly in (a, b):
        m = len(poly)
        for i in range(m):
            p0 = poly[i]
            p1 = poly[(i + 1) % m]
            nx = -(p1[1] - p0[1])
            ny = (p1[0] - p0[0])
            n = math.hypot(nx, ny)
            if n < 1e-15:
                continue
            nx /= n
            ny /= n
            pa = [pt[0] * nx + pt[1] * ny for pt in a]
            pb = [pt[0] * nx + pt[1] * ny for pt in b]
            if max(pa) <= min(pb) + 1e-9 or max(pb) <= min(pa) + 1e-9:
                return True
    return False


def _in_box(corners, box=1.0, eps=1e-9):
    for (x, y) in corners:
        if x < -eps or x > box + eps or y < -eps or y > box + eps:
            return False
    return True


def _is_valid(sqs):
    n = len(sqs)
    polys = []
    for (cx, cy, ang, side) in sqs:
        if not (0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0 and 0.0 <= ang <= 1.0):
            return False
        if not (0.0 <= side <= 1.0):
            return False
        cs = _corners(cx, cy, ang, side)
        if not _in_box(cs):
            return False
        polys.append(cs)
    for i in range(n):
        for j in range(i + 1, n):
            if not _separated(polys[i], polys[j]):
                return False
    return True


# -------- continuous (numpy/scipy) refinement --------

def _refine_slsqp(sqs, maxiter=200):
    try:
        import numpy as np
        from scipy.optimize import minimize
    except Exception:
        return sqs

    n = len(sqs)
    if n == 0:
        return sqs

    x0 = np.zeros(4 * n)
    for i, (cx, cy, ang, sd) in enumerate(sqs):
        x0[4 * i] = cx
        x0[4 * i + 1] = cy
        x0[4 * i + 2] = ang
        x0[4 * i + 3] = sd

    def unpack(x):
        return x.reshape(n, 4)

    def corners_np(x):
        p = unpack(x)
        cx = p[:, 0]
        cy = p[:, 1]
        ang = p[:, 2]
        sd = p[:, 3]
        th = 2.0 * math.pi * ang
        c = np.cos(th)
        s = np.sin(th)
        h = 0.5 * sd
        lx = np.array([-1.0, 1.0, 1.0, -1.0])
        ly = np.array([-1.0, -1.0, 1.0, 1.0])
        X = cx[:, None] + (h * (lx[None, :] * c[:, None] - ly[None, :] * s[:, None]))
        Y = cy[:, None] + (h * (lx[None, :] * s[:, None] + ly[None, :] * c[:, None]))
        return X, Y

    def axes_of(ang):
        th = 2.0 * math.pi * ang
        c = math.cos(th)
        s = math.sin(th)
        return [(c, s), (-s, c)]

    pair_axes = []
    for i in range(n):
        for j in range(i + 1, n):
            ci = _corners(*sqs[i])
            cj = _corners(*sqs[j])
            best_axis = None
            best_gap = -1e9
            cands = axes_of(sqs[i][2]) + axes_of(sqs[j][2])
            for (nx, ny) in cands:
                pa = [pt[0] * nx + pt[1] * ny for pt in ci]
                pb = [pt[0] * nx + pt[1] * ny for pt in cj]
                g1 = min(pb) - max(pa)
                g2 = min(pa) - max(pb)
                g = max(g1, g2)
                if g > best_gap:
                    best_gap = g
                    best_axis = ((nx, ny), 1 if g1 >= g2 else -1)
            pair_axes.append((i, j, best_axis[0], best_axis[1]))

    def objective(x):
        p = unpack(x)
        return -np.sum(p[:, 3])

    def obj_grad(x):
        g = np.zeros_like(x)
        g[3::4] = -1.0
        return g

    cons = []

    def make_box(x):
        X, Y = corners_np(x)
        return np.concatenate([X.ravel() - 1.0, -X.ravel(), Y.ravel() - 1.0, -Y.ravel()])
    cons.append({'type': 'ineq', 'fun': make_box})

    def make_overlap(x):
        p = unpack(x)
        cx = p[:, 0]; cy = p[:, 1]; ang = p[:, 2]; sd = p[:, 3]
        th = 2.0 * math.pi * ang
        c = np.cos(th); s = np.sin(th)
        h = 0.5 * sd
        vals = []
        lxA = np.array([-1.0, 1.0, 1.0, -1.0])
        lyA = np.array([-1.0, -1.0, 1.0, 1.0])
        for (i, j, (nx, ny), sign) in pair_axes:
            a = c[i] * nx + s[i] * ny
            b = -s[i] * nx + c[i] * ny
            base = cx[i] * nx + cy[i] * ny
            pi = base + h[i] * (lxA * a + lyA * b)
            a2 = c[j] * nx + s[j] * ny
            b2 = -s[j] * nx + c[j] * ny
            base2 = cx[j] * nx + cy[j] * ny
            pj = base2 + h[j] * (lxA * a2 + lyA * b2)
            if sign == 1:
                vals.append((np.min(pj) - np.max(pi)) - 1e-6)
            else:
                vals.append((np.min(pi) - np.max(pj)) - 1e-6)
        return np.array(vals) if vals else np.zeros(0)
    cons.append({'type': 'ineq', 'fun': make_overlap})

    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((1e-6, 1.0))

    try:
        res = minimize(objective, x0, jac=obj_grad, method='SLSQP',
                       bounds=bounds, constraints=cons,
                       options={'maxiter': maxiter, 'ftol': 1e-9})
    except Exception:
        return sqs

    p = unpack(res.x)
    out = []
    for i in range(n):
        cx = min(1.0, max(0.0, float(p[i, 0])))
        cy = min(1.0, max(0.0, float(p[i, 1])))
        ang = p[i, 2] % 1.0
        sd = max(0.0, float(p[i, 3]))
        out.append([cx, cy, ang, sd])

    if _is_valid(out):
        return out
    return sqs


# ---------------- seeds ----------------

def _seed_grid(n, rot=0.0):
    k = max(1, int(math.isqrt(n)))
    while k * k > n:
        k -= 1
    cells = []
    side = 1.0 / k
    for i in range(k):
        for j in range(k):
            cells.append([(i + 0.5) * side, (j + 0.5) * side, rot, side])
    while len(cells) < n:
        idx = max(range(len(cells)), key=lambda t: cells[t][3])
        cx, cy, ang, sd = cells[idx]
        hs = sd / 2.0
        a = [cx - hs / 2.0, cy, ang, sd / 2.0]
        b = [cx + hs / 2.0, cy, ang, sd / 2.0]
        cells[idx] = a
        cells.append(b)
    return cells[:n]


def _seed_grid2(n):
    best = None
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if cols * rows < n:
            continue
        w = 1.0 / cols
        h = 1.0 / rows
        s = min(w, h)
        cells = []
        count = 0
        for r in range(rows):
            for c in range(cols):
                if count >= n:
                    break
                cx = (c + 0.5) * w
                cy = (r + 0.5) * h
                cells.append([cx, cy, 0.0, s])
                count += 1
        if count == n:
            score = n * s
            if best is None or score > best[0]:
                best = (score, cells)
    return best[1] if best else _seed_grid(n)


def _seed_one_big(n):
    best = None
    k = max(1, int(math.isqrt(n - 1)))
    while k * k > n - 1:
        k -= 1
    m = n - 1
    gs = 1.0 / k
    for big in (0.5, 0.55, 0.6, 0.65, 0.7):
        cells = [[big / 2.0, big / 2.0, 0.0, big * 0.98]]
        m_rem = m
        if m_rem <= 0:
            continue
        bandR = (1.0 - big)
        rows = max(1, int(round(math.sqrt(m_rem))))
        cols = max(1, (m_rem + rows - 1) // rows)
        count = 0
        cells_f = []
        nb = bandR
        if nb > 1e-6:
            fc = max(1, int(math.floor(1.0 / max(nb, 1e-6))))
            fr = max(1, m_rem // fc)
            sz = min(1.0 / fc, nb / max(1, fr))
            for j in range(fr):
                for i in range(fc):
                    if count >= m_rem:
                        break
                    cx = (i + 0.5) * (1.0 / fc)
                    cy = big + (j + 0.5) * (nb / fr)
                    cells_f.append([cx, cy, 0.0, sz])
                    count += 1
        if count < m_rem:
            fc = max(1, m_rem - count)
            sz = min(bandR / fc, big)
            for i in range(fc):
                cx = big + (i + 0.5) * (bandR / fc)
                cy = big / 2.0
                cells_f.append([cx, cy, 0.0, sz])
                count += 1
        for c in cells_f:
            cells.append(c)
        cells = cells[:n]
        while len(cells) < n:
            cells.append([0.5, 0.5, 0.0, 0.0])
        total = sum(s[3] for s in cells)
        if best is None or total > best[0]:
            best = (total, cells)
    return best[1] if best else _seed_grid(n)


def _grow_polish(sqs, iters=60):
    n = len(sqs)
    best = [list(s) for s in sqs]
    rng = random.Random(987)
    for it in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, sd = best[i]
            for dgrow in (0.03, 0.015, 0.007, 0.003, 0.001):
                for dxy in ((0, 0), (0.02, 0), (-0.02, 0), (0, 0.02), (0, -0.02),
                            (0.01, 0.01), (-0.01, 0.01), (0.01, -0.01), (-0.01, -0.01)):
                    ncx = min(1.0, max(0.0, cx + dxy[0]))
                    ncy = min(1.0, max(0.0, cy + dxy[1]))
                    nsd = sd + dgrow
                    if nsd > 1.0:
                        continue
                    test = [list(s) for s in best]
                    test[i] = [ncx, ncy, ang, nsd]
                    if _is_valid(test):
                        best = test
                        improved = True
                        break
                if improved:
                    break
        if not improved:
            break
    return best


def _shrink_grow(sqs, rounds=4):
    best = [list(s) for s in sqs]
    for r in range(rounds):
        t = [list(s) for s in best]
        for s in t:
            s[3] *= 0.9
        t = _refine_slsqp(t, maxiter=200)
        t = _grow_polish(t, iters=40)
        t = _refine_slsqp(t, maxiter=200)
        t = _grow_polish(t, iters=40)
        if sum(s[3] for s in t) > sum(s[3] for s in best):
            best = t
    return best


# -------- reinsertion: rebuild one square into the free region --------

def _fit_square_among(others, box=1.0, tries=380, seed=12345):
    """Find (cx,cy,ang,side) with maximal side that fits in free space
    (inside unit box, not overlapping any of `others`). Returns best."""
    rng = random.Random(seed)
    best = None
    # candidate axes: edges of others give the 'gaps' we can slot into.
    ax_angs = set()
    for (cx, cy, ang, sd) in others:
        ax_angs.add(ang % 0.5)
        ax_angs.add((ang + 0.25) % 0.5)
    ax_angs = list(ax_angs)

    def fits(cx, cy, ang, sd):
        cs = _corners(cx, cy, ang, sd)
        if not _in_box(cs):
            return False
        for (ocx, ocy, oang, osd) in others:
            if _separated(cs, _corners(ocx, ocy, oang, osd)):
                continue
            return False
        return True

    # grid of candidate centers, angles from axes plus random
    for _ in range(tries):
        if rng.random() < 0.7 and ax_angs:
            ang = ax_angs[rng.randrange(len(ax_angs))] + rng.choice([0.0, 0.25])
        else:
            ang = rng.random()
        cx = rng.random()
        cy = rng.random()
        # growth search: increase side until it no longer fits
        lo, hi = 0.0, 0.5
        # bit of random probing
        sd = 0.0
        step = 0.5
        while step > 1e-5:
            if fits(cx, cy, ang, sd + step):
                sd += step
            else:
                step *= 0.5
        if sd > 0.0:
            # also gentle center nudge to increase
            for _ in range(6):
                moved = False
                for dx, dy in ((0.005, 0), (-0.005, 0)):
                    ncx = min(1.0, max(0.0, cx + dx))
                    ncy = min(1.0, max(0.0, cy + dy))
                    if fits(ncx, ncy, ang, sd + 0.002):
                        cx = ncx; cy = ncy; sd += 0.002
                        moved = True
                if not moved:
                    break
            if fits(cx, cy, ang, sd):
                if best is None or sd > best[3]:
                    best = [cx, cy, ang, sd]
    if best is None:
        best = [0.5, 0.5, 0.0, 0.0]
    return best


def _reinsert_polish(sqs, rounds=3, seed=777):
    n = len(sqs)
    if n == 0:
        return sqs
    best = [list(s) for s in sqs]
    rng = random.Random(seed)
    for r in range(rounds):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            others = [best[k] for k in range(n) if k != i]
            old = best[i][3]
            cand = _fit_square_among(others, seed=rng.randint(0, 10**9))
            if cand[3] > old + 1e-6:
                trial = [list(best[k]) for k in range(n)]
                trial[i] = cand
                if _is_valid(trial):
                    best = trial
                    improved = True
        if not improved:
            break
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    seeds = []
    seeds.append(_seed_grid(n))
    seeds.append(_seed_grid(n, rot=0.0))
    seeds.append(_seed_grid2(n))
    seeds.append(_seed_one_big(n))
    base = _seed_grid(n)
    for s in base:
        s[3] *= 0.6
    seeds.append([list(s) for s in base])

    best = None
    best_sum = -1.0
    for sd in seeds:
        t = [list(s) for s in sd]
        tries = 0
        while not _is_valid(t) and tries < 40:
            for s in t:
                s[3] *= 0.9
            tries += 1
        if not _is_valid(t):
            continue
        t = _grow_polish(t, iters=80)
        t = _refine_slsqp(t, maxiter=250)
        if not _is_valid(t):
            t = _grow_polish(t, iters=60)
        t = _shrink_grow(t, rounds=2)
        t = _reinsert_polish(t, rounds=3)
        t = _refine_slsqp(t, maxiter=250)
        if not _is_valid(t):
            t = _grow_polish(t, iters=60)
        if not _is_valid(t):
            continue
        ssum = sum(s[3] for s in t)
        if ssum > best_sum:
            best_sum = ssum
            best = t

    if best is None:
        best = _seed_grid(n)
        for s in best:
            s[3] *= 0.5

    # one more reinsertion round on the overall best
    t = _reinsert_polish(best, rounds=2, seed=31337)
    t = _refine_slsqp(t, maxiter=250)
    t = _grow_polish(t, iters=60)
    if _is_valid(t) and sum(s[3] for s in t) > sum(s[3] for s in best):
        best = t

    tries = 0
    while not _is_valid(best) and tries < 30:
        for s in best:
            s[3] *= 0.9
            s[0] = min(1.0, max(0.0, s[0]))
            s[1] = min(1.0, max(0.0, s[1]))
        tries += 1

    return [(float(cx), float(cy), float(ang), float(sd)) for (cx, cy, ang, sd) in best]


# EVOLVE-BLOCK-END
