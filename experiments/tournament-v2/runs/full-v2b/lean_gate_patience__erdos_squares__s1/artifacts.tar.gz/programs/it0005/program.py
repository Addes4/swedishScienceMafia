# EVOLVE-BLOCK-START
"""Squares in a unit square: maximise total side length.

Strategy: partition the unit square into up to three rectangular regions (a main
region plus a right strip and a top strip).  Each region is packed with equal
squares via the best grid factorisation.  We search over the split fractions and
the distribution of squares between regions to maximise the total side sum.
Squares with side 0 fill any remainder.
"""
import math


def _pack_grid(count, W, H):
    """Best equal-square grid for `count` squares inside a W x H box.

    Returns (squares, side, used) where squares are (cx, cy, 0, s) in a box anchored
    at origin, plus the number actually placed (<= count)."""
    if count <= 0 or W <= 0 or H <= 0:
        return [], 0.0, 0
    best = None
    for a in range(1, count + 1):
        b = (count + a - 1) // a
        if a * b < count:
            continue
        s = min(W / a, H / b)
        total = s * count
        if best is None or total > best[0]:
            best = (total, a, b, s)
    if best is None:
        return [], 0.0, 0
    _, a, b, s = best
    sq = []
    used = 0
    for i in range(a):
        for j in range(b):
            if used >= count:
                break
            cx = (i + 0.5) * s
            cy = (j + 0.5) * s
            sq.append((cx, cy, 0.0, s))
            used += 1
        if used >= count:
            break
    return sq, s, used


def _layout3(n, nb, ns1, ns2, fw, fh):
    """Three-region layout.

    Main region: [0, 1-fw] x [0, 1-fh]  (holds nb squares)
    Right strip: [1-fw, 1] x [0, 1]     (holds ns1 squares; note it spans below too - use full height)
    Actually use:
      Main region width (1-fw), height (1-fh)
      Right strip width fw, height (1-fh)
      Top strip width 1, height fh
    """
    mw, mh = 1.0 - fw, 1.0 - fh
    rw, rh = fw, 1.0 - fh
    tw, th = 1.0, fh

    big, bs, used_big = _pack_grid(nb, mw, mh)
    if nb > 0 and used_big < nb:
        return None
    s1, ss1, u1 = _pack_grid(ns1, rw, rh)
    if ns1 > 0 and u1 < ns1:
        return None
    s2, ss2, u2 = _pack_grid(ns2, tw, th)
    if ns2 > 0 and u2 < ns2:
        return None

    squares = []
    for (cx, cy, a, s) in big:
        squares.append((cx, cy, a, s))
    ox1 = mw
    for (cx, cy, a, s) in s1:
        squares.append((cx + ox1, cy, a, s))
    oy2 = mh
    for (cx, cy, a, s) in s2:
        squares.append((cx, cy + oy2, a, s))

    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss1 * u1 + ss2 * u2
    return total, squares[:n]


def _layout(n, n_big, split_frac, vertical):
    """Two-region layout (kept as a fallback / for small n)."""
    if vertical:
        fw = split_frac
        bw, bh = fw, 1.0
        sw, sh = 1.0 - fw, 1.0
    else:
        fh = split_frac
        bw, bh = 1.0, fh
        sw, sh = 1.0, 1.0 - fh

    big, bs, used_big = _pack_grid(n_big, bw, bh)
    if used_big < n_big:
        return None
    rest = n - n_big
    small, ss, used_small = _pack_grid(rest, sw, sh)

    squares = list(big)
    ox = bw if vertical else 0.0
    oy = 0.0 if vertical else bh
    for (cx, cy, a, s) in small:
        squares.append((cx + ox, cy + oy, a, s))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss * used_small
    return total, squares[:n]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_total = -1.0
    best_squares = None

    # ---- two-region search (cheap, good baseline) ----
    for n_big in range(1, n + 1):
        for vertical in (True, False):
            lo, hi = 0.01, 0.99
            for _ in range(40):
                m1 = lo + (hi - lo) / 3
                m2 = hi - (hi - lo) / 3
                r1 = _layout(n, n_big, m1, vertical)
                r2 = _layout(n, n_big, m2, vertical)
                t1 = r1[0] if r1 else -1
                t2 = r2[0] if r2 else -1
                if t1 >= t2:
                    hi = m2
                else:
                    lo = m1
            for f in (lo, (lo + hi) / 2, hi):
                r = _layout(n, n_big, f, vertical)
                if r and r[0] > best_total:
                    best_total = r[0]
                    best_squares = r[1]

    # ---- three-region search ----
    # distribute n into (nb, ns1, ns2); search fw, fh on a coarse grid then refine.
    for nb in range(0, n + 1):
        for ns1 in range(0, n - nb + 1):
            ns2 = n - nb - ns1
            if ns2 < 0:
                continue
            # skip pure 2-region duplicates handled already (ns2==0 and ns1==0 etc.)
            # coarse grid over fw, fh
            best_local = None
            for fi in range(1, 10):
                fw = fi / 10.0
                for fj in range(1, 10):
                    fh = fj / 10.0
                    r = _layout3(n, nb, ns1, ns2, fw, fh)
                    if r and (best_local is None or r[0] > best_local[0]):
                        best_local = (r[0], fw, fh)
            if best_local is None:
                continue
            # refine around best
            cfw, cfh = best_local[1], best_local[2]
            for _ in range(25):
                done = True
                step = 0.05 * (0.6 ** _)
                # local ternary-ish coordinate descent
                improved = False
                for dfw in (-step, 0.0, step):
                    for dfh in (-step, 0.0, step):
                        nfw = cfw + dfw
                        nfh = cfh + dfh
                        if not (0.0 <= nfw <= 1.0 and 0.0 <= nfh <= 1.0):
                            continue
                        r = _layout3(n, nb, ns1, ns2, nfw, nfh)
                        if r and r[0] > best_local[0] + 1e-12:
                            best_local = (r[0], nfw, nfh)
                            cfw, cfh = nfw, nfh
                            improved = True
                if not improved:
                    break
            if best_local[0] > best_total:
                r = _layout3(n, nb, ns1, ns2, best_local[1], best_local[2])
                if r:
                    best_total = r[0]
                    best_squares = r[1]

    if best_squares is None:
        k = math.isqrt(n)
        s = 1.0 / k
        best_squares = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                        for i in range(k) for j in range(k)]
        while len(best_squares) < n:
            best_squares.append((0.5, 0.5, 0.0, 0.0))

    return best_squares[:n]
# EVOLVE-BLOCK-END
