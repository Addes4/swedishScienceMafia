# EVOLVE-BLOCK-START
"""Hierarchical grid refinement plus soft-repulsion gradient polish.

Strategy:
1. Build the best near-square axis-aligned grid of k*m cells that fits n.
2. Greedily refine: split some cells into sub-squares and drop tiny ones,
   producing a candidate multiset of sizes at grid positions.
3. Use scipy.optimize.minimize (L-BFGS-B) on a smooth energy that penalises
   pairwise overlap (via a soft AABB overlap on rotated bounding aspects)
   and pushes squares inside the unit box, while rewarding total side length.
   Angles and sides are also variables, so packings tighten up.
"""

import math
import numpy as np
from scipy.optimize import minimize


def _overlap_energy(cx, cy, ang, s, w=1.0):
    """Differentiable-ish soft overlap penalty using separation along axes.

    For each pair, compute a smooth penalty from the axis-aligned bounding
    half-extents of the rotated squares (rotated squares fit in AABB of
    half-extent s*(|cos|+|sin|)/2). This is conservative (overestimates
    overlap) which is fine -- it prevents interpenetration.
    """
    n = len(s)
    ct = np.cos(2 * math.pi * ang)
    st = np.sin(2 * math.pi * ang)
    hx = 0.5 * s * (np.abs(ct) + np.abs(st))
    hy = 0.5 * s * (np.abs(ct) + np.abs(st))
    # gap along x and y for each pair
    dx = np.abs(cx[:, None] - cx[None, :])
    dy = np.abs(cy[:, None] - cy[None, :])
    ovx = np.maximum(0.0, hx[:, None] + hx[None, :] - dx)
    ovy = np.maximum(0.0, hy[:, None] + hy[None, :] - dy)
    ov = ovx * ovy  # conservative overlap area
    iu = np.triu_indices(n, 1)
    pen = np.sum(ov[iu] ** 2)
    # box barrier: push inside [0,1]^2
    lx = np.maximum(0.0, hx - cx) + np.maximum(0.0, cx + hx - 1.0)
    ly = np.maximum(0.0, hy - cy) + np.maximum(0.0, cy + hy - 1.0)
    pen += 100.0 * np.sum(lx ** 2 + ly ** 2)
    return w * pen


def _make_grid(n):
    """Return list of (cx, cy, ang, s) forming the best grid with <=n squares,
    then split the largest ones to reach exactly n."""
    # find the rectangle a x b with a*b <= n maximizing (a/b) close to 1 and product
    best = None
    for a in range(1, n + 1):
        b = n // a
        if b == 0:
            continue
        if a * b > n:
            continue
        prod = a * b
        aspect = max(a, b) / min(a, b)
        # prefer the max product; tie-break by square-ish
        key = (prod, -aspect)
        if best is None or key > best[0]:
            best = (key, a, b)
    _, a, b = best
    sx = 1.0 / a
    sy = 1.0 / b
    sq = []
    for i in range(a):
        for j in range(b):
            sq.append(((i + 0.5) * sx, (j + 0.5) * sy, 0.0, min(sx, sy)))
    # split the largest squares to get to n
    while len(sq) < n:
        idx = max(range(len(sq)), key=lambda k: sq[k][3])
        cx, cy, ang, s = sq.pop(idx)
        # split into two halves vertically
        h = s / 2.0
        sq.append((cx - h / 2.0, cy, ang, h))
        sq.append((cx + h / 2.0, cy, ang, h))
    return sq[:n]


def _to_array(sqs):
    arr = np.array(sqs, dtype=float)
    return arr[:, 0].copy(), arr[:, 1].copy(), arr[:, 2].copy(), arr[:, 3].copy()


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    base = _make_grid(n)
    cx, cy, ang, s = _to_array(base)

    # variable vector: [cx, cy, ang, s]
    x0 = np.concatenate([cx, cy, ang, s])

    def unpack(x):
        return x[:n].copy(), x[n:2 * n].copy(), x[2 * n:3 * n].copy(), x[3 * n:4 * n].copy()

    def obj(x):
        a, b, c, d = unpack(x)
        pen = _overlap_energy(a, b, c, d)
        return pen - 0.5 * np.sum(d)  # reward side length

    # bounds: centres in [0,1], angle in [-0.25,0.25] (mod symmetry), side in [0,1]
    lb = np.concatenate([np.zeros(n), np.zeros(n), -0.25 * np.ones(n), np.zeros(n)])
    ub = np.concatenate([np.ones(n), np.ones(n), 0.25 * np.ones(n), np.ones(n)])
    bounds = list(zip(lb, ub))

    try:
        res = minimize(obj, x0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': 300, 'maxfun': 5000})
        x = res.x
    except Exception:
        x = x0

    a, b, c, d = unpack(x)

    # final cleanup: shrink sizes so no overlaps remain, keeping order
    # iterative shrink of overlapping pairs (AABB-based conservative)
    for _ in range(30):
        ct = np.cos(2 * math.pi * c)
        st = np.sin(2 * math.pi * c)
        h = 0.5 * d * (np.abs(ct) + np.abs(st))
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                dx = abs(a[i] - a[j])
                dy = abs(b[i] - b[j])
                hx = h[i] + h[j]
                hy = h[i] + h[j]
                # overlap amount along each axis
                ox = hx - dx
                oy = hy - dy
                if ox > 1e-9 and oy > 1e-9:
                    shrink = max(ox, oy)
                    d[i] = max(0.0, d[i] - shrink)
                    d[j] = max(0.0, d[j] - shrink)
                    changed = True
        # clamp inside box
        ct = np.cos(2 * math.pi * c)
        st = np.sin(2 * math.pi * c)
        h = 0.5 * d * (np.abs(ct) + np.abs(st))
        a = np.clip(a, h, 1.0 - h)
        b = np.clip(b, h, 1.0 - h)
        if not changed:
            break

    out = []
    for i in range(n):
        out.append((float(np.clip(a[i], 0.0, 1.0)),
                    float(np.clip(b[i], 0.0, 1.0)),
                    float(c[i]),
                    float(max(0.0, d[i]))))
    return out
# EVOLVE-BLOCK-END
