import math
import numpy as np
from scipy.optimize import minimize

# EVOLVE-BLOCK-START


def _half_extent(angle, side):
    c = abs(math.cos(2 * math.pi * angle))
    s = abs(math.sin(2 * math.pi * angle))
    return 0.5 * side * (c + s)


def _sat_overlap(ci, ai, si, cj, aj, sj):
    """Max penetration depth over separating axes (positive = overlap)."""
    # two squares with axes at angles ai, aj -> candidate normals are their edge normals
    best = -1e18
    for a in (ai, aj):
        th = 2 * math.pi * a
        nx, ny = math.cos(th), math.sin(th)
        # project centers
        d = (ci[0] - cj[0]) * nx + (ci[1] - cj[1]) * ny
        # projected half-width of each square on this normal
        def proj_half(sq_angle, side):
            t = 2 * math.pi * (a - sq_angle)
            return 0.5 * side * (abs(math.cos(t)) + abs(math.sin(t)))
        ri = proj_half(ai, si)
        rj = proj_half(aj, sj)
        gap = ri + rj - abs(d)
        if gap > best:
            best = gap
    return best


def _feasible(cs, angs, sides, tol=1e-9):
    n = len(sides)
    for i in range(n):
        h = _half_extent(angs[i], sides[i])
        x, y = cs[i]
        if x - h < -tol or x + h > 1 + tol or y - h < -tol or y + h > 1 + tol:
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _sat_overlap(cs[i], angs[i], sides[i], cs[j], angs[j], sides[j]) > tol:
                return False
    return True


def _make_grid(n):
    k = max(1, math.isqrt(n))
    while k * k > n:
        k -= 1
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    return squares


def _overlap_penalty(centers, angles, sides, box=1.0):
    n = len(sides)
    pen = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            p = _sat_overlap(centers[i], angles[i], sides[i],
                             centers[j], angles[j], sides[j])
            if p > 0:
                pen += p * p
    for i in range(n):
        h = _half_extent(angles[i], sides[i])
        x, y = centers[i]
        pen += max(0.0, h - x) ** 2
        pen += max(0.0, x + h - box) ** 2
        pen += max(0.0, h - y) ** 2
        pen += max(0.0, y + h - box) ** 2
    return pen


def _polish(cs, angs, sides):
    """Strict feasibility-preserving grow/shrink + shift polish."""
    n = len(sides)
    cs = [list(c) for c in cs]
    angs = list(angs)
    sides = list(sides)
    shrink = 0.999
    # global scale down to guarantee feasibility
    for i in range(n):
        sides[i] *= shrink

    def total():
        return sum(sides)

    # grow pass
    for _ in range(60):
        improved = False
        for i in range(n):
            lo, hi = 0.0, 1.0 - sides[i]
            for _ in range(30):
                mid = 0.5 * (lo + hi)
                trial = sides[i] + mid
                if trial > 1.0:
                    break
                old = sides[i]
                sides[i] = trial
                if _feasible(cs, angs, sides):
                    lo = mid
                    improved = True
                else:
                    sides[i] = old
                    hi = mid
            sides[i] += lo
        if not improved:
            break
    # slight jitter shifts to escape local configs
    rng = np.random.default_rng(12345)
    for _ in range(200):
        i = int(rng.integers(0, n))
        j = int(rng.integers(0, 2))
        step = 0.004 * (1 if rng.random() > 0.5 else -1)
        nc = [cs[i][0], cs[i][1]]
        nc[j] += step
        if nc[0] < 0 or nc[0] > 1 or nc[1] < 0 or nc[1] > 1:
            continue
        old = cs[i]
        cs[i] = nc
        if _feasible(cs, angs, sides):
            continue
        cs[i] = old
    # final grow
    for _ in range(30):
        improved = False
        for i in range(n):
            lo, hi = 0.0, 1.0
            for _ in range(30):
                mid = 0.5 * (lo + hi)
                trial = sides[i] + mid
                old = sides[i]
                sides[i] = trial
                if _feasible(cs, angs, sides):
                    lo = mid
                    improved = True
                else:
                    sides[i] = old
                    hi = mid
            sides[i] += lo
        if not improved:
            break
    return cs, angs, sides


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    squares = _make_grid(n)
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.01])
    squares = squares[:n]

    # spread any coincident centres
    used = {}
    for s in squares:
        key = (round(s[0], 6), round(s[1], 6))
        if key in used:
            used[key] += 1
            s[0] = min(0.99, s[0] + 0.01 * used[key])
        else:
            used[key] = 0

    centers = np.array([[s[0], s[1]] for s in squares])
    angles = np.zeros(n)
    sides = np.array([s[3] for s in squares])

    def unpack(v):
        c = v[: 2 * n].reshape(n, 2)
        s = v[2 * n: 3 * n]
        return c, s

    def objective(v):
        c, s = unpack(v)
        s = np.clip(s, 0.0, 1.0)
        return _overlap_penalty(c, angles, s)

    init = np.concatenate([centers.ravel(), sides])
    init[2 * n: 3 * n] *= 0.98
    bounds = [(0.0, 1.0)] * (2 * n) + [(0.0, 1.0)] * n

    try:
        res = minimize(objective, init, method="L-BFGS-B", bounds=bounds,
                       options={"maxiter": 300, "ftol": 1e-12})
        c, s = unpack(res.x)
        s = np.clip(s, 0.0, 1.0)
        c = np.clip(c, 0.0, 1.0)
    except Exception:
        c = centers
        s = sides

    cs = [list(c[i]) for i in range(n)]
    angs = [float(angles[i]) for i in range(n)]
    sd = [float(s[i]) for i in range(n)]

    cs, angs, sd = _polish(cs, angs, sd)

    # If polish failed to make things feasible (shouldn't happen), shrink.
    if not _feasible(cs, angs, sd):
        scale = 0.5
        for _ in range(20):
            fd = [x * scale for x in sd]
            if _feasible(cs, angs, fd):
                sd = fd
                break
            scale *= 0.9

    result = []
    for i in range(n):
        x = min(1.0, max(0.0, cs[i][0]))
        y = min(1.0, max(0.0, cs[i][1]))
        a = float(angs[i]) % 1.0
        si = min(1.0, max(0.0, float(sd[i])))
        result.append((x, y, a, si))
    return result


# EVOLVE-BLOCK-END
