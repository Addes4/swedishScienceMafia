"""Greedy constructive packing with local continuous refinement.

Approach:
1.  Build an initial layout using a slicing tree / recursive guillotine
    partition of the unit square: split the current rectangle recursively,
    assigning squares of sizes proportional to a desired power-law.
2.  Refine all (cx, cy, angle, side) with a smooth penalty so that overlaps
    are pushed apart while a reward on sum(side) is maximised.
This is completely different from grid/evolution methods and generalises to
any n.
"""
import math
import random
import numpy as np
from scipy.optimize import minimize


def _initial_rects(n):
    """Return list of (x0,y0,x1,y1) rectangles partitioning [0,1]^2.
    Uses a recursive guillotine split choosing the split that balances
    areas with weights ~ desired square sizes (power law).
    """
    # desired relative sizes: precomputed large-to-small geometric decay
    # weights sorted descending
    w = [1.0 / (1.0 + 0.35 * i) for i in range(n)]
    s = sum(w)
    w = [x / s for x in w]

    rects = [(0.0, 0.0, 1.0, 1.0, w)]
    out = []
    # Split largest-weight rect repeatedly using a priority queue by weight
    import heapq
    heap = [(-1.0, 0, (0.0, 0.0, 1.0, 1.0, w))]
    counter = 1
    # We want exactly n leaves. Start with one; repeatedly split a leaf that
    # contains >=2 weights.
    leaves = [(0.0, 0.0, 1.0, 1.0, list(range(n)))]
    while len(leaves) < n:
        # find leaf with most indices and largest total weight
        best_i = max(range(len(leaves)), key=lambda i: len(leaves[i][4]))
        x0, y0, x1, y1, idxs = leaves.pop(best_i)
        # split indices into two roughly equal groups by cumulative weight
        sw = sum(w[i] for i in idxs)
        half = sw / 2.0
        acc = 0.0
        cut = 1
        for k, i in enumerate(idxs):
            acc += w[i]
            if acc >= half:
                cut = max(1, min(len(idxs) - 1, k + 1))
                break
        left = idxs[:cut]
        right = idxs[cut:]
        rw = sum(w[i] for i in right) / sw
        # choose vertical or horizontal split based on aspect ratio
        W = x1 - x0
        H = y1 - y0
        if W >= H:
            mx = x0 + W * (1.0 - rw)
            leaves.append((x0, y0, mx, y1, left))
            leaves.append((mx, y0, x1, y1, right))
        else:
            my = y0 + H * (1.0 - rw)
            leaves.append((x0, y0, x1, my, left))
            leaves.append((x0, my, x1, y1, right))

    result = [None] * n
    for (x0, y0, x1, y1, idxs) in leaves:
        for i in idxs:
            result[i] = (x0, y0, x1, y1)
    # fill leftovers (shouldn't happen) with tiny rects
    for i in range(n):
        if result[i] is None:
            result[i] = (0.0, 0.0, 0.0, 0.0)
    return result, w


def _rect_to_square(x0, y0, x1, y1):
    cx = (x0 + x1) / 2.0
    cy = (y0 + y1) / 2.0
    side = min(x1 - x0, y1 - y0)
    if side < 0:
        side = 0.0
    return cx, cy, 0.0, side


def _overlap_penalty(params, n):
    """params: flat array of length 4n = (cx, cy, angle, side) per square.
    Returns a penalty (>=0) measuring interior overlap plus bounding-box
    violation penalty (soft).
    """
    cx = params[0::4]
    cy = params[1::4]
    ang = params[2::4]
    s = params[3::4]
    s = np.maximum(s, 0.0)

    # bounding box: for rotated square, half-extent in x and y
    ca = np.cos(2.0 * math.pi * ang)
    sa = np.sin(2.0 * math.pi * ang)
    hx = 0.5 * s * (np.abs(ca) + np.abs(sa))
    hy = 0.5 * s * (np.abs(ca) + np.abs(sa))
    # actually for a rotated square, projections are s*(|cos|+|sin|)/2 on both axes
    proj = 0.5 * s * (np.abs(ca) + np.abs(sa))
    hx = proj
    hy = proj

    # box violation
    pen = 0.0
    ex = np.maximum(0.0, hx - cx) + np.maximum(0.0, cx + hx - 1.0)
    ey = np.maximum(0.0, hy - cy) + np.maximum(0.0, cy + hy - 1.0)
    pen += float(np.sum(ex * ex + ey * ey))

    # pairwise overlap (approximate SAT using bounding circles then
    # refined using projections on 4 axes: x, y, and the two square axes)
    # For efficiency, only consider pairs close enough via simple check.
    # n may be moderate so O(n^2) is fine up to ~200.
    if n <= 1:
        return pen

    # precompute axis data
    # axes for square i: directions (ca_i, sa_i) and (-sa_i, ca_i)
    for i in range(n):
        for j in range(i + 1, n):
            # quick reject via bounding boxes
            dx = abs(cx[i] - cx[j])
            dy = abs(cy[i] - cy[j])
            if dx > hx[i] + hx[j] or dy > hy[i] + hy[j]:
                continue
            # SAT on 4 axes
            minov = None
            # axis x: separation on x
            ov = hx[i] + hx[j] - dx
            if ov <= 0:
                continue
            minov = ov
            ov = hy[i] + hy[j] - dy
            if ov <= 0:
                continue
            if ov < minov:
                minov = ov
            # axis along square i orientation
            ux = ca[i]
            uy = sa[i]
            proj_i = 0.5 * s[i] * (abs(ux * ca[i] + uy * sa[i]) + abs(ux * -sa[i] + uy * ca[i]))
            proj_j = 0.5 * s[j] * (abs(ux * ca[j] + uy * sa[j]) + abs(ux * -sa[j] + uy * ca[j]))
            d = abs((cx[i] - cx[j]) * ux + (cy[i] - cy[j]) * uy)
            ov = proj_i + proj_j - d
            if ov <= 0:
                continue
            if ov < minov:
                minov = ov
            # axis along square j orientation
            ux = ca[j]
            uy = sa[j]
            proj_i = 0.5 * s[i] * (abs(ux * ca[i] + uy * sa[i]) + abs(ux * -sa[i] + uy * ca[i]))
            proj_j = 0.5 * s[j] * (abs(ux * ca[j] + uy * sa[j]) + abs(ux * -sa[j] + uy * ca[j]))
            d = abs((cx[i] - cx[j]) * ux + (cy[i] - cy[j]) * uy)
            ov = proj_i + proj_j - d
            if ov <= 0:
                continue
            if ov < minov:
                minov = ov
            pen += minov * minov
    return pen


def _objective(params, n, lam):
    s = params[3::4]
    s = np.maximum(s, 0.0)
    return -float(np.sum(s)) + lam * _overlap_penalty(params, n)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rects, w = _initial_rects(n)
    init = []
    for i, r in enumerate(rects):
        cx, cy, ang, side = _rect_to_square(*r)
        # try a small rotation for large squares to help packing later
        init.append((cx, cy, ang, side))

    x0 = np.array([[c[0], c[1], c[2], c[3]] for c in init], dtype=float).ravel()

    # clamp to valid range and small random perturbation
    rng = random.Random(12345)
    for i in range(n):
        x0[4 * i] = min(max(x0[4 * i], 0.0), 1.0)
        x0[4 * i + 1] = min(max(x0[4 * i + 1], 0.0), 1.0)
        x0[4 * i + 2] = rng.random()
        x0[4 * i + 3] = min(max(x0[4 * i + 3], 0.0), 1.0)

    best = x0.copy()
    best_val = -float(np.sum(best[3::4]))

    lam = 20.0
    # Iterative refinement: increase penalty weight to remove overlaps
    for it in range(4):
        try:
            res = minimize(
                _objective,
                best,
                args=(n, lam),
                method="L-BFGS-B",
                bounds=[(0.0, 1.0)] * (4 * n),
                options={"maxiter": 300, "ftol": 1e-9},
            )
            cand = res.x
            # enforce side >= 0
            cand = cand.copy()
            cand[3::4] = np.maximum(cand[3::4], 0.0)
            pen = _overlap_penalty(cand, n)
            if pen < 1e-6:
                val = float(np.sum(cand[3::4]))
                if val > best_val:
                    best_val = val
                    best = cand
            # even if overlap remains, keep best-by-score
            score = float(np.sum(cand[3::4])) - lam * pen
            if best is None or score > float(np.sum(best[3::4])) - lam * _overlap_penalty(best, n):
                best = cand
        except Exception:
            pass
        lam *= 3.0

    # Final: if overlaps remain, shrink sides to eliminate them greedily
    out = best.copy()
    # verify and greedily shrink overlapping squares
    for _ in range(20):
        pen = _overlap_penalty(out, n)
        if pen < 1e-9:
            break
        # shrink all sides slightly
        out[3::4] = np.maximum(out[3::4] * 0.99 - 1e-4, 0.0)

    result = []
    for i in range(n):
        cx = float(min(max(out[4 * i], 0.0), 1.0))
        cy = float(min(max(out[4 * i + 1], 0.0), 1.0))
        ang = float(out[4 * i + 2] % 1.0)
        side = float(max(out[4 * i + 3], 0.0))
        result.append((cx, cy, ang, side))
    return result
