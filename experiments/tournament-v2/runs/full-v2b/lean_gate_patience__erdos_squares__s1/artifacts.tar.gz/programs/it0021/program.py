"""Squares in a unit square: maximise sum of side lengths.

Method (general for any n):
1.  Build several candidate initial packings: a size-aware guillotine
    slicing tree, grid-like layouts, and "one large square plus strip" seeds.
2.  Refine continuously with a soft-penalty penalty (SAT-exact overlap +
    boundary violation) using L-BFGS-B, ramping the penalty weight.
3.  Post-process with a separating-axis-accurate greedy growth.
"""
import math
import random
import numpy as np
from scipy.optimize import minimize


# ---------- geometry helpers (separating axis theorem) ----------

def _corners(cx, cy, ang, s):
    ca = math.cos(2.0 * math.pi * ang)
    sa = math.sin(2.0 * math.pi * ang)
    hx = 0.5 * s
    pts = []
    for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        px = cx + sx * hx * ca + sy * hx * (-sa)
        py = cy + sx * hx * sa + sy * hx * ca
        pts.append((px, py))
    return pts


def _axes(ang):
    ca = math.cos(2.0 * math.pi * ang)
    sa = math.sin(2.0 * math.pi * ang)
    return (ca, sa), (-sa, ca)


def _project(pts, axis):
    a, b = axis
    d = [p[0] * a + p[1] * b for p in pts]
    return min(d), max(d)


def _overlap_depth(sq1, sq2):
    """Return penetration depth (>0 overlapping) of two squares by SAT."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 0 or s2 <= 0:
        return 0.0
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)
    axes = [_axes(a1)[0], _axes(a1)[1], _axes(a2)[0], _axes(a2)[1]]
    dmin = 1e18
    for ax in axes:
        lo1, hi1 = _project(p1, ax)
        lo2, hi2 = _project(p2, ax)
        ov = min(hi1, hi2) - max(lo1, lo2)
        if ov <= 0:
            return 0.0
        if ov < dmin:
            dmin = ov
    return dmin


def _in_bounds(sq):
    cx, cy, a, s = sq
    if s <= 0:
        return True
    ca = math.cos(2.0 * math.pi * a)
    sa = math.sin(2.0 * math.pi * a)
    hx = 0.5 * s * (abs(ca) + abs(sa))
    hy = hx
    return (cx - hx >= -1e-9 and cx + hx <= 1.0 + 1e-9 and
            cy - hx >= -1e-9 and cy + hx <= 1.0 + 1e-9)


def _total_overlap(layout):
    tot = 0.0
    n = len(layout)
    for i in range(n):
        for j in range(i + 1, n):
            tot += _overlap_depth(layout[i], layout[j]) ** 2
    for sq in layout:
        cx, cy, a, s = sq
        ca = math.cos(2.0 * math.pi * a)
        sa = math.sin(2.0 * math.pi * a)
        hx = 0.5 * s * (abs(ca) + abs(sa))
        if cx - hx < 0:
            tot += (cx - hx) ** 2
        if cx + hx > 1.0:
            tot += (cx + hx - 1.0) ** 2
        if cy - hx < 0:
            tot += (cy - hx) ** 2
        if cy + hx > 1.0:
            tot += (cy + hx - 1.0) ** 2
    return tot


# ---------- initial layouts ----------

def _slicing_layout(n):
    w = [1.0 / (1.0 + 0.30 * i) for i in range(n)]
    leaves = [(0.0, 0.0, 1.0, 1.0, list(range(n)))]
    while len(leaves) < n:
        best_i = max(
            range(len(leaves)),
            key=lambda i: len(leaves[i][4]) * (1.0 + sum(w[k] for k in leaves[i][4])),
        )
        x0, y0, x1, y1, idxs = leaves.pop(best_i)
        sw = sum(w[i] for i in idxs)
        half = sw / 2.0
        acc = 0.0
        cut = 1
        for k, i in enumerate(idxs):
            acc += w[i]
            if acc >= half:
                cut = max(1, min(len(idxs) - 1, k + 1))
                break
        left = idxs[:cut]
        right = idxs[cut:]
        lw = sum(w[i] for i in left)
        rw = sum(w[i] for i in right)
        frac_l = lw / (lw + rw)
        W = x1 - x0
        H = y1 - y0
        if W >= H:
            mx = x0 + W * frac_l
            leaves.append((x0, y0, mx, y1, left))
            leaves.append((mx, y0, x1, y1, right))
        else:
            my = y0 + H * frac_l
            leaves.append((x0, y0, x1, my, left))
            leaves.append((x0, my, x1, y1, right))

    layout = [None] * n
    for (x0, y0, x1, y1, idxs) in leaves:
        for i in idxs:
            cx = (x0 + x1) / 2.0
            cy = (y0 + y1) / 2.0
            side = min(x1 - x0, y1 - y0)
            layout[i] = (cx, cy, 0.0, max(side, 1e-6))
    for i in range(n):
        if layout[i] is None:
            layout[i] = (0.5, 0.5, 0.0, 0.0)
    return layout


def _grid_layout(n):
    """Approximate grid: choose (cols, rows); cells equal sized."""
    best = None
    best_min = -1.0
    for cols in range(1, n + 1):
        rows = max(1, (n + cols - 1) // cols)
        side = min(1.0 / cols, 1.0 / rows)
        if side > best_min:
            best_min = side
            best = (cols, rows)
    cols, rows = best
    layout = []
    cw = 1.0 / cols
    ch = 1.0 / rows
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            cx = (c + 0.5) * cw
            cy = (r + 0.5) * ch
            side = min(cw, ch)
            layout.append((cx, cy, 0.0, max(side, 1e-6)))
            idx += 1
        if idx >= n:
            break
    while len(layout) < n:
        layout.append((0.5, 0.5, 0.0, 0.0))
    return layout


def _large_plus_strip_layout(n, strip_side_k, vertical):
    """One large square occupying a strip of width L, and (n-1) equal small
    squares packed in the remaining strip.  Try a family of values for the
    large square side L and the number of small squares per line."""
    # Large square side L, remaining band width = 1 - L (or height).
    # Small squares of side t fill the band in a grid of (n-1) cells.
    # We explore L values; the small squares are placed in a k x m grid.
    m = n - 1
    # choose grid of small squares as balanced as possible within band
    results = []
    for L in [0.4 + 0.05 * i for i in range(13)]:
        band = 1.0 - L
        if band <= 1e-6:
            continue
        # place m small squares in the band: choose cols/rows in the band
        best = None
        best_t = -1.0
        for cols in range(1, m + 1):
            rows = max(1, (m + cols - 1) // cols)
            t = min(band / cols, 1.0 / rows)
            if t > best_t:
                best_t = t
                best = (cols, rows, t)
        if best is None:
            continue
        cols, rows, t = best
        layout = []
        if not vertical:
            # large square on the left
            layout.append((L / 2.0, 0.5, 0.0, L))
            cw = band / cols
            ch = 1.0 / rows
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= m:
                        break
                    cx = L + (c + 0.5) * cw
                    cy = (r + 0.5) * ch
                    layout.append((cx, cy, 0.0, max(t, 1e-6)))
                    idx += 1
        else:
            layout.append((0.5, L / 2.0, 0.0, L))
            cw = 1.0 / cols
            ch = band / rows
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= m:
                        break
                    cx = (c + 0.5) * cw
                    cy = L + (r + 0.5) * ch
                    layout.append((cx, cy, 0.0, max(t, 1e-6)))
                    idx += 1
        while len(layout) < n:
            layout.append((0.5, 0.5, 0.0, 0.0))
        results.append(layout)
    return results


def _initial_layouts(n):
    cands = [_slicing_layout(n), _grid_layout(n)]
    for vert in (False, True):
        cands.extend(_large_plus_strip_layout(n, 0, vert))
    return cands


# ---------- soft-penalty continuous refinement (SAT-exact overlap) ----------

def _pen_sat(params, n):
    cx = params[0::4]
    cy = params[1::4]
    ang = params[2::4]
    s = np.maximum(params[3::4], 0.0)

    ca = np.cos(2.0 * math.pi * ang)
    sa = np.sin(2.0 * math.pi * ang)
    proj = 0.5 * s * (np.abs(ca) + np.abs(sa))

    pen = 0.0
    ex = np.maximum(0.0, proj - cx) + np.maximum(0.0, cx + proj - 1.0)
    ey = np.maximum(0.0, proj - cy) + np.maximum(0.0, cy + proj - 1.0)
    pen += float(np.sum(ex * ex + ey * ey))

    # exact SAT projection test: use axes of both squares (4 axes).
    for k in range(2):
        if k == 0:
            ax, ay = ca, sa
        else:
            ax, ay = -sa, ca
        # projections of each square onto this axis direction (centered form)
        pi_ = 0.5 * s * (np.abs(ca * ax + sa * ay) +
                         np.abs((-sa) * ax + ca * ay))
        for i in range(n):
            if s[i] <= 0:
                continue
            for j in range(i + 1, n):
                if s[j] <= 0:
                    continue
                pj_ = 0.5 * s[j] * (np.abs(ca[j] * ax + sa[j] * ay) +
                                    np.abs((-sa[j]) * ax + ca[j] * ay))
                d = abs((cx[i] - cx[j]) * ax + (cy[i] - cy[j]) * ay)
                # quick reject using axis aligned bound
                if d >= pi_[i] + pj_ + 1e-6:
                    continue
                ov = pi_[i] + pj_ - d
                if ov <= 0:
                    continue
                pen += (ov * ov) * 0.25
    return pen


def _objective(params, n, lam):
    s = np.maximum(params[3::4], 0.0)
    return -float(np.sum(s)) + lam * _pen_sat(params, n)


# ---------- greedy growth post-processing ----------

def _greedy_grow(layout, rounds=40):
    layout = [list(sq) for sq in layout]
    n = len(layout)
    for _ in range(30):
        if _total_overlap(layout) < 1e-10:
            break
        for i in range(n):
            layout[i][3] *= 0.99
    for rnd in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -layout[i][3])
        for i in order:
            cx, cy, a, s = layout[i]
            best_s = s
            lo, hi = s, min(1.0, s * 1.8 + 0.05)
            for step in (0.05, 0.02, 0.005, 0.001):
                t = s
                while t + step <= hi + 1e-12:
                    cand = [cx, cy, a, t + step]
                    if not _in_bounds(cand):
                        break
                    ok = True
                    for j in range(n):
                        if j == i:
                            continue
                        if _overlap_depth(cand, layout[j]) > 1e-9:
                            ok = False
                            break
                    if ok:
                        t += step
                    else:
                        break
                if t > best_s:
                    best_s = t
            if best_s > s + 1e-9:
                layout[i][3] = best_s
                improved = True
        if not improved:
            break
    return [tuple(sq) for sq in layout]


def _refine_from(init, n, max_rounds=5):
    x0 = np.array(init, dtype=float).ravel()
    x0[3::4] = np.maximum(x0[3::4], 0.0)
    cur = x0.copy()
    lam = 15.0
    for it in range(max_rounds):
        try:
            res = minimize(
                _objective, cur, args=(n, lam), method="L-BFGS-B",
                bounds=[(0.0, 1.0)] * (4 * n),
                options={"maxiter": 400, "ftol": 1e-10},
            )
            cand = res.x.copy()
            cand[3::4] = np.maximum(cand[3::4], 0.0)
            pen = _pen_sat(cand, n)
            cur = cand
            if pen < 1e-7:
                break
        except Exception:
            pass
        lam *= 4.0

    layout = []
    for i in range(n):
        cx = float(min(max(cur[4 * i], 0.0), 1.0))
        cy = float(min(max(cur[4 * i + 1], 0.0), 1.0))
        ang = float(cur[4 * i + 2] % 1.0)
        side = float(max(cur[4 * i + 3], 0.0))
        layout.append([cx, cy, ang, side])

    layout = [list(sq) for sq in layout]
    for _ in range(60):
        if _total_overlap(layout) < 1e-10:
            break
        for i in range(n):
            layout[i][3] *= 0.98

    layout = _greedy_grow([tuple(sq) for sq in layout])

    if _total_overlap(layout) > 1e-7:
        layout = [list(sq) for sq in layout]
        for _ in range(80):
            if _total_overlap(layout) < 1e-10:
                break
            for i in range(n):
                layout[i][3] *= 0.97
        layout = [tuple(sq) for sq in layout]
    return layout


# ---------- entry ----------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_layout = None
    best_val = -1.0

    candidates = _initial_layouts(n)

    for init in candidates:
        layout = _refine_from(init, n)
        val = sum(sq[3] for sq in layout if sq[3] > 0)
        if val > best_val:
            best_val = val
            best_layout = layout

    # random perturbations of the slicing layout
    for sd in (1, 2):
        r = random.Random(sd)
        base = _slicing_layout(n)
        init = [
            (
                min(max(sq[0] + (r.random() - 0.5) * 0.02, 0), 1),
                min(max(sq[1] + (r.random() - 0.5) * 0.02, 0), 1),
                r.random() if sq[3] > 0.05 else sq[2],
                sq[3],
            )
            for sq in base
        ]
        layout = _refine_from(init, n)
        val = sum(sq[3] for sq in layout if sq[3] > 0)
        if val > best_val:
            best_val = val
            best_layout = layout

    out = []
    for sq in best_layout:
        cx = float(min(max(sq[0], 0.0), 1.0))
        cy = float(min(max(sq[1], 0.0), 1.0))
        ang = float(sq[2] % 1.0)
        side = float(max(sq[3], 0.0))
        out.append((cx, cy, ang, side))
    return out
