import math
import random

# EVOLVE-BLOCK-START

def _corners(cx, cy, ang, side):
    th = 2.0 * math.pi * ang
    c, s = math.cos(th), math.sin(th)
    h = 0.5 * side
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for (lx, ly) in pts:
        out.append((cx + lx * c - ly * s, cy + lx * s + ly * c))
    return out


def _separated(a, b, eps=1e-12):
    for poly in (a, b):
        m = len(poly)
        for i in range(m):
            p0 = poly[i]
            p1 = poly[(i + 1) % m]
            nx = -(p1[1] - p0[1])
            ny = (p1[0] - p0[0])
            nrm = math.hypot(nx, ny)
            if nrm < 1e-15:
                continue
            nx /= nrm
            ny /= nrm
            pa = [pt[0] * nx + pt[1] * ny for pt in a]
            pb = [pt[0] * nx + pt[1] * ny for pt in b]
            if max(pa) <= min(pb) + eps or max(pb) <= min(pa) + eps:
                return True
    return False


def _in_box(corners, box=1.0, eps=1e-9):
    for (x, y) in corners:
        if x < -eps or x > box + eps or y < -eps or y > box + eps:
            return False
    return True


def _is_valid(sqs):
    n = len(sqs)
    polys = []
    for (cx, cy, ang, side) in sqs:
        if not (0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0 and 0.0 <= ang <= 1.0):
            return False
        if not (0.0 <= side <= 1.0):
            return False
        cs = _corners(cx, cy, ang, side)
        if not _in_box(cs):
            return False
        polys.append(cs)
    for i in range(n):
        for j in range(i + 1, n):
            if not _separated(polys[i], polys[j]):
                return False
    return True


# ---------------- structured seeds ----------------

def _row_seed(n, gaps=0.0):
    """All squares in a row, equal sizes filling width then grown."""
    cells = []
    w = 1.0 / n
    for i in range(n):
        cells.append([(i + 0.5) * w, 0.5, 0.0, w * (1.0 - gaps)])
    return cells


def _grid_seed(n, big_frac=None):
    """One big square plus a grid of small fillers."""
    if big_frac is None:
        big_frac = 0.5
    big = big_frac
    # region for small squares: L-shape (right strip + top/bottom strip)
    smalls = []
    # place big in bottom-left
    bigsq = [big / 2.0, big / 2.0, 0.0, big]
    rem = n - 1
    if rem <= 0:
        return [bigsq]
    # top strip: width 1, height 1-big
    ht = 1.0 - big
    # right strip: width 1-big, height big
    wr = 1.0 - big
    # choose grid for top strip: rows=?, cols=?
    # try to divide smalls between top strip and right strip
    best = None
    for kt in range(1, rem + 1):
        for ct in range(1, rem + 1):
            if kt * ct > rem:
                continue
            kr = rem - kt * ct
            for cr in range(1, rem + 1):
                if kr == 0:
                    cand = (kt, ct, 0, 1)
                elif kr % cr == 0:
                    krr = kr // cr
                    if krr <= 0:
                        continue
                    cand = (kt, ct, krr, cr)
                else:
                    continue
                kt_, ct_, krr, cr_ = cand
                s_top = min(1.0 / ct_, ht / kt_) if kt_ > 0 and ct_ > 0 else 0
                s_right = min(wr / cr_, big / krr) if krr > 0 and cr_ > 0 else 0
                sc = 0.0
                cnt = 0
                if kt_ * ct_ > 0:
                    sc += kt_ * ct_ * s_top
                    cnt += kt_ * ct_
                if krr * cr_ > 0:
                    sc += krr * cr_ * s_right
                    cnt += krr * cr_
                if cnt == rem:
                    if best is None or sc > best[0]:
                        best = (sc, kt_, ct_, krr, cr_, s_top, s_right)
    if best is None:
        # fallback
        return _row_seed(n)
    sc, kt_, ct_, krr, cr_, s_top, s_right = best
    # place top strip squares
    if kt_ > 0 and ct_ > 0 and s_top > 1e-9:
        for r in range(kt_):
            for c in range(ct_):
                cx = (c + 0.5) * s_top
                cy = big + (r + 0.5) * s_top
                smalls.append([cx, cy, 0.0, s_top])
    # place right strip squares
    if krr > 0 and cr_ > 0 and s_right > 1e-9:
        for r in range(krr):
            for c in range(cr_):
                cx = big + (c + 0.5) * s_right
                cy = (r + 0.5) * s_right
                smalls.append([cx, cy, 0.0, s_right])
    return [bigsq] + smalls


def _grid_seed2(n, big_frac):
    """Two big squares plus fillers (symmetric)."""
    if n < 3:
        return _grid_seed(n, big_frac)
    bigsq = [big_frac / 2.0, big_frac / 2.0, 0.0, big_frac]
    rem = n - 1
    if rem <= 0:
        return [bigsq]
    # filler in top strip
    ht = 1.0 - big_frac
    smalls = []
    # top region only
    best = None
    for k in range(1, rem + 1):
        if rem % k != 0:
            continue
        c = rem // k
        s = min(1.0 / c, ht / k)
        if best is None or s > best[0]:
            best = (s, k, c)
    if best is None:
        return [bigsq] + _row_seed(rem) if rem > 0 else [bigsq]
    s, k, c = best
    for r in range(k):
        for col in range(c):
            cx = (col + 0.5) * s
            cy = big_frac + (r + 0.5) * s
            smalls.append([cx, cy, 0.0, s])
    return [bigsq] + smalls


def _thin_strip_seed(n):
    """All n squares equal, in a single thin strip, then grown."""
    s = 1.0 / n
    return [[(i + 0.5) * s, 0.5, 0.0, s] for i in range(n)]


# ---------------- polish ----------------

def _polish(sqs, iters=400, rng=None):
    if rng is None:
        rng = random.Random(999)
    n = len(sqs)
    best = [list(s) for s in sqs]

    all_angles = [i / 90.0 for i in range(0, 90, 5)]

    for it in range(iters):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            cx, cy, ang, sd = best[i]
            # try growing (with small nudges)
            found = False
            for dgrow in (0.02, 0.01, 0.005, 0.002, 0.001):
                for dxy in ((0, 0), (0.005, 0), (-0.005, 0), (0, 0.005), (0, -0.005),
                            (0.003, 0.003), (-0.003, 0.003), (0.003, -0.003), (-0.003, -0.003),
                            (0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01)):
                    ncx = min(1.0, max(0.0, cx + dxy[0]))
                    ncy = min(1.0, max(0.0, cy + dxy[1]))
                    nsd = sd + dgrow
                    if nsd > 1.0:
                        continue
                    test = [list(s) for s in best]
                    test[i] = [ncx, ncy, ang, nsd]
                    if _is_valid(test):
                        best = test
                        found = True
                        break
                if found:
                    break
            if found:
                improved = True
                continue
            # try rotating this square
            for na in all_angles:
                if abs(na - ang) < 1e-9:
                    continue
                test = [list(s) for s in best]
                test[i] = [cx, cy, na, sd]
                if _is_valid(test):
                    best = test
                    found = True
                    break
            if found:
                improved = True
        if not improved:
            break
    return best


def _compress_grow(sqs, iters=80):
    """Try to uniformly scale up the configuration about the centroid, then grow individually."""
    best = [list(s) for s in sqs]
    for _ in range(iters):
        cx0 = sum(s[0] for s in best) / len(best)
        cy0 = sum(s[1] for s in best) / len(best)
        # try scaling up around centroid
        grew = False
        for scale in (1.05, 1.03, 1.02, 1.01, 1.005):
            test = []
            ok = True
            for (cx, cy, ang, sd) in best:
                ncx = cx0 + (cx - cx0) * scale
                ncy = cy0 + (cy - cy0) * scale
                nsd = sd * scale
                test.append([ncx, ncy, ang, nsd])
            if _is_valid(test):
                best = test
                grew = True
                break
        if not grew:
            break
    return best


def _refit(sqs, rng):
    """Grow via local moves, alternating grow and shift."""
    best = _polish(sqs, iters=250, rng=rng)
    for _ in range(3):
        new = _polish(best, iters=150, rng=rng)
        if sum(s[3] for s in new) > sum(s[3] for s in best) + 1e-9:
            best = new
        else:
            break
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(2024)

    candidates = []

    # various big-square seeds
    for bf in (0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.3333, 0.6667, 0.35):
        candidates.append(_grid_seed(n, bf))
    for bf in (0.4, 0.5, 0.6):
        candidates.append(_grid_seed2(n, bf))
    candidates.append(_thin_strip_seed(n))
    candidates.append(_row_seed(n))

    # shrink seeds slightly for safety
    seeds = []
    for c in candidates:
        cc = [list(s) for s in c]
        # shrink
        for s in cc:
            s[3] *= 0.97
            s[0] = min(1.0, max(0.0, s[0]))
            s[1] = min(1.0, max(0.0, s[1]))
        if _is_valid(cc):
            seeds.append(cc)

    if not seeds:
        seeds.append(_thin_strip_seed(n))

    best = None
    best_sum = -1.0
    # time is limited, but n is small here
    for sd in seeds:
        polish = _refit(sd, rng)
        polish = _compress_grow(polish)
        polish = _polish(polish, iters=150, rng=rng)
        tot = sum(s[3] for s in polish)
        if tot > best_sum and _is_valid(polish):
            best_sum = tot
            best = polish

    if best is None:
        best = _thin_strip_seed(n)

    # final safety
    tries = 0
    while not _is_valid(best) and tries < 30:
        for s in best:
            s[3] *= 0.95
            s[0] = min(1.0, max(0.0, s[0]))
            s[1] = min(1.0, max(0.0, s[1]))
        tries += 1

    return [(float(cx), float(cy), float(ang), float(sd)) for (cx, cy, ang, sd) in best]


# EVOLVE-BLOCK-END
