# EVOLVE-BLOCK-START
"""Hybrid packing of n rotated squares in the unit square.

Pipeline
--------
1. Seed: several structured layouts (uniform grid, strip layouts, and a
   "dominant square + equal fill of the remaining L-region" family).
2. Grow: iteratively enlarge each square while keeping strict SAT
   feasibility (separation + containment).
3. Polish: soft-energy force-directed refinement on all (cx, cy, angle, side).
4. Best-of over all seeds / restarts, time-budgeted.
"""
import math
import random
import time

import numpy as np


# ----------------------------------------------------------------------------
# geometry
# ----------------------------------------------------------------------------

def _corners(cx, cy, ang, side):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side * 0.5
    local = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    rot = np.array([[ca, -sa], [sa, ca]], dtype=float)
    return local @ rot.T + np.array([cx, cy])


def _sat_overlap(ca, cb):
    """Penetration depth of two convex polygons (0 if disjoint)."""
    polys = (ca, cb)
    best = float("inf")
    for poly in polys:
        m = len(poly)
        for i in range(m):
            p0 = poly[i]
            p1 = poly[(i + 1) % m]
            e = p1 - p0
            axis = np.array([e[1], -e[0]], dtype=float)
            nrm = math.hypot(axis[0], axis[1])
            if nrm < 1e-15:
                continue
            axis /= nrm
            d0 = ca @ axis
            d1 = cb @ axis
            ov = min(d0.max(), d1.max()) - max(d0.min(), d1.min())
            if ov <= 0.0:
                return 0.0
            if ov < best:
                best = ov
    return best if best != float("inf") else 0.0


def _inside_penalty(corners):
    lo = corners.min(axis=0)
    hi = corners.max(axis=0)
    pen = 0.0
    if lo[0] < 0.0:
        pen += -lo[0]
    if lo[1] < 0.0:
        pen += -lo[1]
    if hi[0] > 1.0:
        pen += hi[0] - 1.0
    if hi[1] > 1.0:
        pen += hi[1] - 1.0
    return pen


def _feasible(sqs, tol=1e-9):
    n = len(sqs)
    cs = [_corners(*s) for s in sqs]
    for i in range(n):
        if sqs[i][3] < -tol:
            return False
        if _inside_penalty(cs[i]) > tol:
            return False
    for i in range(n):
        if sqs[i][3] <= tol:
            continue
        for j in range(i + 1, n):
            if sqs[j][3] <= tol:
                continue
            if _sat_overlap(cs[i], cs[j]) > tol:
                return False
    return True


def _total(sqs):
    return sum(s[3] for s in sqs)


# ----------------------------------------------------------------------------
# seeds
# ----------------------------------------------------------------------------

def _grid_seed(n):
    best = None
    best_score = -1.0
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        if rows * cols < n:
            continue
        side = 1.0 / max(cols, rows)
        score = n * side
        if score > best_score:
            best_score = score
            best = (cols, rows, side)
    cols, rows, side = best
    sqs = []
    for i in range(cols):
        for j in range(rows):
            if len(sqs) >= n:
                break
            sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    return sqs[:n]


def _dominant_seed(n, big_frac, corner):
    """One square of side `big_frac` in a corner, rest as equal grid in L-region."""
    if n < 2:
        return None
    big = big_frac
    # remaining L region: pick a layout for n-1 squares of side s around it
    rest = n - 1
    best = None
    best_val = -1.0
    # try a few splits of the L into two rectangles
    for k in range(1, rest + 1):
        # rectangle A (strip along one edge, k squares), rectangle B (rest)
        # horizontal strip height h_A, whatever; use simple grid-of-equal
        for cols_a in range(1, k + 1):
            rows_a = (k + cols_a - 1) // cols_a
            if cols_a * rows_a < k:
                continue
            for cols_b in range(1, rest - k + 1 if rest - k > 0 else 1):
                rem = rest - k
                if rem == 0:
                    rows_b = 0
                else:
                    rows_b = (rem + cols_b - 1) // cols_b
                # rough capacity: fit in (1 - big) strips
                w1 = 1.0 - big
                sA = min(w1 / max(cols_a, 1), 1.0 / max(rows_a, 1))
                sB = min(w1 / max(cols_b, 1), big / max(rows_b, 1)) if rem > 0 else 0.0
                val = big + k * sA + rem * sB
                if val > best_val:
                    best_val = val
                    best = (k, cols_a, rows_a, cols_b, max(rows_b, 0), sA, sB)
    if best is None:
        return None
    k, cols_a, rows_a, cols_b, rows_b, sA, sB = best
    sqs = []
    # place big square in chosen corner
    hb = big * 0.5
    if corner == 0:
        bx, by = hb, hb
    elif corner == 1:
        bx, by = 1.0 - hb, hb
    elif corner == 2:
        bx, by = hb, 1.0 - hb
    else:
        bx, by = 1.0 - hb, 1.0 - hb
    sqs.append((bx, by, 0.0, big))
    # strip A: along the bottom/left depending on corner, area (1-big) x 1
    placed = 0
    for i in range(cols_a):
        for j in range(rows_a):
            if placed >= k:
                break
            placed += 1
            sqs.append((None, None, 0.0, sA))
    # assign positions later
    # strip B
    for _ in range(n - 1 - k):
        sqs.append((None, None, 0.0, sB))
    # fill positions: pack strip A in a (1-big) x 1 slab opposite the big square
    idx = 1
    if corner in (0, 3):  # big at bottom, strip on right
        x0 = big
    else:
        x0 = 0.0
    # strip A occupies right/left slab width (1-big), full height
    for i in range(cols_a):
        for j in range(rows_a):
            if idx >= 1 + k:
                break
            cx = x0 + (i + 0.5) * sA
            cy = (j + 0.5) * sA
            sqs[idx] = (min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), 0.0, sA)
            idx += 1
    # strip B occupies the slab beside big square but only height `big`
    # (the blocked band). Put it adjacent to big square on the opposite side.
    if corner in (0, 3):
        xb0 = big
    else:
        xb0 = 0.0
    for i in range(cols_b):
        for j in range(rows_b):
            if idx >= n:
                break
            cx = xb0 + (i + 0.5) * sB
            cy = big + (j + 0.5) * sB if big + j * sB < 1.0 else (j + 0.5) * sB
            sqs[idx] = (min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), 0.0, sB)
            idx += 1
    # fix any None (shouldn't happen)
    for i in range(len(sqs)):
        if sqs[i][0] is None:
            sqs[i] = (0.5, 0.5, 0.0, 0.0)
    return sqs[:n]


# ----------------------------------------------------------------------------
# grow: enlarge each square while staying strictly feasible
# ----------------------------------------------------------------------------

def _grow(sqs, rng, rounds=60):
    n = len(sqs)
    sqs = [list(s) for s in sqs]
    for _ in range(rounds):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            old = sqs[i][3]
            lo, hi = old, old + 0.5
            cs = [_corners(*sqs[k]) for k in range(n)]
            # binary search the largest feasible side
            best = old
            for _ in range(30):
                mid = 0.5 * (lo + hi)
                if mid <= best + 1e-12:
                    lo = mid
                    continue
                trial = sqs[i][:]
                trial[3] = mid
                ct = _corners(*trial)
                if _inside_penalty(ct) > 1e-9:
                    hi = mid
                    continue
                ok = True
                for j in range(n):
                    if j == i or sqs[j][3] <= 1e-12:
                        continue
                    if _sat_overlap(ct, cs[j]) > 1e-9:
                        ok = False
                        break
                if ok:
                    best = mid
                    lo = mid
                else:
                    hi = mid
            if best > old + 1e-9:
                sqs[i][3] = best
                improved = True
        if not improved:
            break
    return [tuple(s) for s in sqs]


# ----------------------------------------------------------------------------
# soft-energy polish (force-directed)
# ----------------------------------------------------------------------------

def _energy_and_grad(sqs, lam, w_ov=1.0, w_bd=1.0, eps=1e-6):
    """Numerical-gradient soft energy: overlap + boundary - lam * sum(side)."""
    def energy(s):
        e = 0.0
        cs = [_corners(*x) for x in s]
        for i in range(len(s)):
            e += w_bd * _inside_penalty(cs[i])
        for i in range(len(s)):
            if s[i][3] <= 0.0:
                continue
            for j in range(i + 1, len(s)):
                if s[j][3] <= 0.0:
                    continue
                e += w_ov * _sat_overlap(cs[i], cs[j])
        e -= lam * sum(x[3] for x in s)
        return e

    x = np.array(sqs, dtype=float).ravel()
    g = np.zeros_like(x)
    base = energy([list(r) for r in x.reshape(-1, 4)])
    for k in range(len(x)):
        xp = x.copy()
        xp[k] += eps
        gp = energy([list(r) for r in xp.reshape(-1, 4)])
        g[k] = (gp - base) / eps
    return base, g


def _polish(sqs, rng, iters=4000):
    n = len(sqs)
    x = np.array([list(s) for s in sqs], dtype=float)
    lam = 0.3
    step = 0.02
    best = x.copy()
    best_val = _total([tuple(r) for r in x])
    for it in range(iters):
        if it % 200 == 199:
            lam *= 1.05
            step *= 0.95
        e0, g = _energy_and_grad([tuple(r) for r in x], lam)
        new = x - step * g.reshape(-1, 4)
        # clip
        new[:, 0] = np.clip(new[:, 0], 0.0, 1.0)
        new[:, 1] = np.clip(new[:, 1], 0.0, 1.0)
        new[:, 2] = np.mod(new[:, 2], 1.0)
        new[:, 3] = np.clip(new[:, 3], 0.0, 1.0)
        e1 = _energy_and_grad([tuple(r) for r in new], lam)[0]
        if e1 < e0:
            x = new
        else:
            step *= 0.98
        # track best feasible
        cand = [tuple(r) for r in x]
        if _feasible(cand, 1e-7):
            v = _total(cand)
            if v > best_val + 1e-12:
                best_val = v
                best = x.copy()
    cand = [tuple(r) for r in best]
    if _feasible(cand, 1e-9):
        return cand
    # fall back to original if polish broke feasibility
    return sqs


# ----------------------------------------------------------------------------
# public API
# ----------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []

    rng = random.Random(90210 + n)
    t0 = time.time()
    deadline = t0 + 55.0

    seeds = []
    seeds.append(_grid_seed(n))
    for bf in (0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7):
        for corner in range(4):
            s = _dominant_seed(n, bf, corner)
            if s is not None:
                seeds.append(s)

    best = None
    best_val = -1.0
    for seed in seeds:
        if time.time() > deadline:
            break
        cand = _grow(seed, rng, rounds=40)
        v = _total(cand)
        if _feasible(cand) and v > best_val + 1e-12:
            best_val = v
            best = cand

    # polish the top seeds with remaining time
    for seed in seeds:
        if time.time() > deadline:
            break
        grown = _grow(seed, rng, rounds=20)
        pol = _polish(grown, rng, iters=1500)
        if _feasible(pol):
            v = _total(pol)
            if v > best_val + 1e-12:
                best_val = v
                best = pol

    if best is None:
        best = _grid_seed(n)
        best_val = _total(best)

    # final fine-grown pass
    if time.time() < deadline:
        cand = _grow(best, rng, rounds=100)
        if _feasible(cand):
            v = _total(cand)
            if v > best_val + 1e-12:
                best_val = v
                best = cand

    return [tuple(s) for s in best]
# EVOLVE-BLOCK-END
