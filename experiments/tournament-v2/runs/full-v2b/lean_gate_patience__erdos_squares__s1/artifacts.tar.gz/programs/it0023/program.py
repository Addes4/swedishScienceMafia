# EVOLVE-BLOCK-START
"""Hierarchical grid-optimization packing of squares in the unit square."""

import math
import random
import numpy as np
from scipy.optimize import minimize


def _initial_squares(n):
    """Build a coarse axis-aligned grid, then split cells to reach n."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Start from a grid close to sqrt(n), but a bit coarser for refinement.
    k = max(1, int(math.sqrt(n)) - 1)
    side = 1.0 / k
    cells = []
    for i in range(k):
        for j in range(k):
            cx = (i + 0.5) * side
            cy = (j + 0.5) * side
            cells.append([cx, cy, 0.0, side])

    # Refine: repeatedly split the largest-area square into 2x2 smaller squares.
    # The side is halved, positions shifted by a quarter.
    while len(cells) < n:
        # pick the largest by side
        idx = max(range(len(cells)), key=lambda t: cells[t][3])
        cx, cy, ang, s = cells[idx]
        # split into up to 4; always 4 unless we need fewer.
        need = n - len(cells)
        if need >= 3:
            # split into 4
            ns = s * 0.5
            d = s * 0.25
            cells.pop(idx)
            for dx in (-d, d):
                for dy in (-d, d):
                    cells.append([cx + dx, cy + dy, ang, ns])
        else:
            # split into 2x2 but only keep enough: still split into 4 then truncate later
            ns = s * 0.5
            d = s * 0.25
            cells.pop(idx)
            for dx in (-d, d):
                for dy in (-d, dy if False else d):
                    cells.append([cx + dx, cy + dy, ang, ns])

    # If we overshot, trim extras (remove smallest)
    cells.sort(key=lambda t: -t[3])
    cells = cells[:n]

    # Clamp into [0,1]
    out = []
    for cx, cy, ang, s in cells:
        # ensure inside
        r = 0.5 * s * (abs(math.cos(2 * math.pi * ang)) + abs(math.sin(2 * math.pi * ang)))
        # actually max half-diagonal for rotation is s/2*(|cos|+|sin|), but s/2 is safe lower clamp
        h = 0.5 * s
        # Clamp so axis-aligned bounding box fits
        half = 0.5 * s * (abs(math.cos(2 * math.pi * ang)) + abs(math.sin(2 * math.pi * ang)))
        cx = min(max(cx, half), 1.0 - half)
        cy = min(max(cy, half), 1.0 - half)
        out.append((cx, cy, ang, s))
    return out


def _overlap_penalty(params, n):
    """Soft repulsion energy: sum of pairwise overlap + boundary violations."""
    x = params[:n]
    y = params[n:2 * n]
    a = params[2 * n:3 * n]
    s = params[3 * n:4 * n]

    # Keep in bounds via penalty
    pen = 0.0
    # half-extent of rotated square (projection on x and y)
    ca = np.cos(2 * np.pi * a)
    sa = np.sin(2 * np.pi * a)
    # A rotated square of side s has x-projection s/2*(|cos|+|sin|) and same for y
    hx = 0.5 * s * (np.abs(ca) + np.abs(sa))
    hy = hx  # by symmetry

    # Boundary penalties
    pen += np.sum(np.maximum(0.0, hx - x) ** 2)
    pen += np.sum(np.maximum(0.0, x + hx - 1.0) ** 2)
    pen += np.sum(np.maximum(0.0, hy - y) ** 2)
    pen += np.sum(np.maximum(0.0, y + hy - 1.0) ** 2)

    # Pairwise overlap penalty using circle approximation (safe-ish) plus OBB check.
    # Use direction-dependent support: distance between centres projected.
    for i in range(n):
        for j in range(i + 1, n):
            dx = x[i] - x[j]
            dy = y[i] - y[j]
            # separation along x-axis required to avoid overlap for two OBBs:
            # approximate by half-extents
            req_x = hx[i] + hx[j]
            req_y = hy[i] + hy[j]
            ox = req_x - abs(dx)
            oy = req_y - abs(dy)
            if ox > 0 and oy > 0:
                # overlapping bounding boxes; use overlap product as penalty
                pen += (ox * oy) ** 1.5 * 10.0
    
    # Slightly encourage larger total side
    pen += -0.001 * np.sum(s)
    return pen


def _refine(cells, n, time_budget=2.0):
    """Use scipy.optimize to reduce overlap and slightly grow/adjust."""
    # pack parameters
    x = np.array([c[0] for c in cells], dtype=float)
    y = np.array([c[1] for c in cells], dtype=float)
    a = np.array([c[2] for c in cells], dtype=float)
    s = np.array([c[3] for c in cells], dtype=float)

    p0 = np.concatenate([x, y, a, s])

    bounds = [(0.0, 1.0)] * (2 * n) + [(0.0, 0.5)] * n + [(0.0, 1.0)] * n

    def obj(p):
        return _overlap_penalty(p, n)

    try:
        res = minimize(obj, p0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': 300, 'ftol': 1e-12})
        p = res.x
    except Exception:
        p = p0

    x = p[:n]
    y = p[n:2 * n]
    a = p[2 * n:3 * n]
    s = p[3 * n:4 * n]

    # Clamp again
    out = []
    for i in range(n):
        si = max(0.0, min(1.0, s[i]))
        ai = a[i] % 0.5
        half = 0.5 * si * (abs(math.cos(2 * math.pi * ai)) + abs(math.sin(2 * math.pi * ai)))
        cx = min(max(x[i], half), 1.0 - half)
        cy = min(max(y[i], half), 1.0 - half)
        out.append((cx, cy, ai, si))
    return out


def _repair(cells):
    """Greedy repair: shrink squares that overlap; ensure inside bounds."""
    n = len(cells)
    # Sort by size descending so we preserve large ones
    idx = sorted(range(n), key=lambda i: -cells[i][3])
    placed = []
    for i in idx:
        cx, cy, a, s = cells[i]
        # shrink to fit bounds
        ai = a % 0.5
        ca = abs(math.cos(2 * math.pi * ai))
        sa = abs(math.sin(2 * math.pi * ai))
        # max side so that rotated square fits
        max_s = 1.0 / (ca + sa + 1e-12)
        s = min(s, max_s)
        # shrink until no overlap with placed
        for _ in range(40):
            hx = 0.5 * s * (ca + sa)
            hy = hx
            ok = True
            for (px, py, pa, ps) in placed:
                pca = abs(math.cos(2 * math.pi * pa))
                psa = abs(math.sin(2 * math.pi * pa))
                phx = 0.5 * ps * (pca + psa)
                phy = phx
                if abs(cx - px) < hx + phx - 1e-9 and abs(cy - py) < hy + phy - 1e-9:
                    ok = False
                    break
            if ok:
                break
            s *= 0.9
        if s < 1e-12:
            s = 0.0
        placed.append((cx, cy, ai, s))
    # Reorder to original indexing? Not required; return in any order.
    return [(cx, cy, a, s) for (cx, cy, a, s) in placed]


def _polish(cells, lock_free=True):
    """A final quick local search: try to grow each square greedily."""
    n = len(cells)
    # Convert to list of mutable
    cur = [[c[0], c[1], c[2], c[3]] for c in cells]

    def fits(i, s_new):
        cx, cy, a, _ = cur[i]
        ai = a % 0.5
        ca = abs(math.cos(2 * math.pi * ai))
        sa = abs(math.sin(2 * math.pi * ai))
        hx = 0.5 * s_new * (ca + sa)
        hy = hx
        if cx - hx < -1e-12 or cx + hx > 1 + 1e-12:
            return False
        if cy - hy < -1e-12 or cy + hy > 1 + 1e-12:
            return False
        for j in range(n):
            if j == i:
                continue
            px, py, pa, ps = cur[j]
            pca = abs(math.cos(2 * math.pi * (pa % 0.5)))
            psa = abs(math.sin(2 * math.pi * (pa % 0.5)))
            phx = 0.5 * ps * (pca + psa)
            phy = phx
            if abs(cx - px) < hx + phx - 1e-9 and abs(cy - py) < hy + phy - 1e-9:
                return False
        return True

    # Iterate: try growing each square
    for _ in range(3):
        changed = False
        for i in range(n):
            cx, cy, a, s = cur[i]
            # try a few growth factors
            for mult in (1.05, 1.02, 1.01, 1.005):
                ns = s * mult
                if fits(i, ns):
                    cur[i][3] = ns
                    changed = True
                    break
        if not changed:
            break
    return [(c[0], c[1], c[2], c[3]) for c in cur]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345)
    np.random.seed(12345)

    # Build a hierarchical initial layout
    cells = _initial_squares(n)

    # Try a few random perturbations to escape bad local minima
    best = None
    best_score = -1.0

    for trial in range(3):
        if trial == 0:
            cand = cells
        else:
            # perturb angles and positions slightly
            cand = []
            for (cx, cy, a, s) in cells:
                jitter = 0.02
                ncx = min(max(cx + random.uniform(-jitter, jitter), 0.0), 1.0)
                ncy = min(max(cy + random.uniform(-jitter, jitter), 0.0), 1.0)
                na = (a + random.uniform(-0.1, 0.1)) % 0.5
                cand.append((ncx, ncy, na, s))

        # Optimize soft repulsion
        opt = _refine(cand, n, time_budget=3.0)
        # Repair any remaining overlap
        rep = _repair(opt)
        # Polish by growing
        pol = _polish(rep)

        score = sum(c[3] for c in pol)
        if score > best_score:
            best_score = score
            best = pol

    # Final safety: ensure all inside and no gross overlaps (shrink if needed)
    final = _repair(best)

    # Make exactly n
    if len(final) < n:
        final += [(0.5, 0.5, 0.0, 0.0)] * (n - len(final))
    final = final[:n]

    # Clip all values to [0,1]
    out = []
    for (cx, cy, a, s) in final:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    return out
# EVOLVE-BLOCK-END
