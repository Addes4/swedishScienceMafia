# EVOLVE-BLOCK-START
"""Squares in a unit square: maximise total side length.

Strategy: choose a grid of a x b cells occupying a rectangle of width W and height H,
place the biggest possible equal squares there, then pack the leftover squares into the
remaining strip (right or top) using its own small grid. Search over splits to maximise
the total side sum.  Squares with side 0 fill any remainder.
"""
import math


def _pack_grid(count, W, H):
    """Best equal-square grid for `count` squares inside a W x H box.

    Returns (squares, side, used) where squares are (cx, cy, 0, s) in a box anchored
    at origin, plus the number actually placed (<= count)."""
    if count <= 0 or W <= 0 or H <= 0:
        return [], 0.0, 0
    best = None
    # try all factorisations a*b >= count, minimal a,b
    for a in range(1, count + 1):
        b = (count + a - 1) // a
        if a * b < count:
            continue
        s = min(W / a, H / b)
        total = s * count
        if best is None or total > best[0]:
            best = (total, a, b, s)
    if best is None:
        return [], 0.0, 0
    _, a, b, s = best
    sq = []
    used = 0
    for i in range(a):
        for j in range(b):
            if used >= count:
                break
            cx = (i + 0.5) * s
            cy = (j + 0.5) * s
            sq.append((cx, cy, 0.0, s))
            used += 1
        if used >= count:
            break
    return sq, s, used


def _layout(n, n_big, split_frac, vertical):
    """Build a layout with `n_big` big squares in a strip of size split_frac, rest beside."""
    if vertical:
        # big squares on left width = f, right strip width = 1-f full height
        fw = split_frac
        bw, bh = fw, 1.0
        sw, sh = 1.0 - fw, 1.0
    else:
        fh = split_frac
        bw, bh = 1.0, fh
        sw, sh = 1.0, 1.0 - fh

    big, bs, used_big = _pack_grid(n_big, bw, bh)
    if used_big < n_big:
        return None
    rest = n - n_big
    small, ss, used_small = _pack_grid(rest, sw, sh)

    squares = []
    for (cx, cy, a, s) in big:
        squares.append((cx, cy, a, s))
    ox = bw if vertical else 0.0
    oy = 0.0 if vertical else bh
    for (cx, cy, a, s) in small:
        squares.append((cx + ox, cy + oy, a, s))
    # pad with zero squares
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss * used_small
    return total, squares[:n]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_total = -1.0
    best_squares = None

    # candidate configurations: split into big group and small group in two strips
    for n_big in range(1, n + 1):
        for vertical in (True, False):
            # coarse to fine search over the split fraction
            lo, hi = 0.01, 0.99
            for _ in range(40):
                m1 = lo + (hi - lo) / 3
                m2 = hi - (hi - lo) / 3
                r1 = _layout(n, n_big, m1, vertical)
                r2 = _layout(n, n_big, m2, vertical)
                t1 = r1[0] if r1 else -1
                t2 = r2[0] if r2 else -1
                if t1 >= t2:
                    hi = m2
                else:
                    lo = m1
            for f in (lo, (lo + hi) / 2, hi):
                r = _layout(n, n_big, f, vertical)
                if r and r[0] > best_total:
                    best_total = r[0]
                    best_squares = r[1]

    if best_squares is None:
        # fallback: plain grid
        k = math.isqrt(n)
        s = 1.0 / k
        best_squares = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                        for i in range(k) for j in range(k)]
        while len(best_squares) < n:
            best_squares.append((0.5, 0.5, 0.0, 0.0))

    return best_squares[:n]
# EVOLVE-BLOCK-END
