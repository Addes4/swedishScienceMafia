"""Structured packing: search a small family of parametric layouts and pick
the best valid one.  Families:
  A) uniform m x k grid (m*k >= n), all squares equal, fill 1..n of them
  B) recursive guillotine split with a tunable aspect / balance exponent
  C) one large square in a corner plus a grid in the remaining L-shaped region
All layouts keep squares axis-aligned (angle 0) which is optimal for the
grid families; a separating-axis validator guarantees non-overlap.
"""
import math
import itertools


def _valid(sqs):
    """squares: list of (cx, cy, side). Check inside unit square and no
    interior overlap (axis aligned)."""
    n = len(sqs)
    for (cx, cy, s) in sqs:
        if s < 0:
            return False
        if s == 0:
            continue
        h = s / 2.0
        if cx - h < -1e-9 or cx + h > 1 + 1e-9:
            return False
        if cy - h < -1e-9 or cy + h > 1 + 1e-9:
            return False
    for i in range(n):
        xi0 = sqs[i][0] - sqs[i][2] / 2.0
        xi1 = sqs[i][0] + sqs[i][2] / 2.0
        yi0 = sqs[i][1] - sqs[i][2] / 2.0
        yi1 = sqs[i][1] + sqs[i][2] / 2.0
        for j in range(i + 1, n):
            xj0 = sqs[j][0] - sqs[j][2] / 2.0
            xj1 = sqs[j][0] + sqs[j][2] / 2.0
            yj0 = sqs[j][1] - sqs[j][2] / 2.0
            yj1 = sqs[j][1] + sqs[j][2] / 2.0
            ox = min(xi1, xj1) - max(xi0, xj0)
            oy = min(yi1, yj1) - max(yi0, yj0)
            if ox > 1e-9 and oy > 1e-9:
                return False
    return True


def _rect_layout(x0, y0, x1, y1, sizes, weights):
    """Place squares of given relative weights inside rectangle, guillotine."""
    recs = [(x0, y0, x1, y1, list(range(len(sizes))))]
    out = [None] * len(sizes)
    while recs:
        rx0, ry0, rx1, ry1, idxs = recs.pop()
        if len(idxs) == 1:
            i = idxs[0]
            cx = (rx0 + rx1) / 2.0
            cy = (ry0 + ry1) / 2.0
            s = min(rx1 - rx0, ry1 - ry0)
            out[i] = (cx, cy, max(s, 0.0))
            continue
        sw = sum(weights[i] for i in idxs)
        half = sw / 2.0
        acc = 0.0
        cut = 1
        for k, i in enumerate(idxs):
            acc += weights[i]
            if acc >= half:
                cut = max(1, min(len(idxs) - 1, k + 1))
                break
        left = idxs[:cut]
        right = idxs[cut:]
        rw = sum(weights[i] for i in right) / sw
        W = rx1 - rx0
        H = ry1 - ry0
        if W >= H:
            mx = rx0 + W * (1.0 - rw)
            recs.append((rx0, ry0, mx, ry1, left))
            recs.append((mx, ry0, rx1, ry1, right))
        else:
            my = ry0 + H * (1.0 - rw)
            recs.append((rx0, ry0, rx1, my, left))
            recs.append((rx0, my, rx1, ry1, right))
    return out


def _best_layout(n):
    best = None
    best_sum = -1.0

    def consider(sqs):
        nonlocal best, best_sum
        if len(sqs) != n:
            return
        if not _valid(sqs):
            return
        t = sum(s[2] for s in sqs)
        if t > best_sum + 1e-12:
            best_sum = t
            best = sqs

    # ---- Family A: grid m x k, fill with equal squares ----
    for m in range(1, n + 1):
        for k in range(1, n + 1):
            if m * k < n:
                continue
            if m > n + 1 or k > n + 1:
                continue
            s = min(1.0 / m, 1.0 / k)
            # place n squares in the grid (left to right, bottom to top)
            count = 0
            sqs = []
            for r in range(k):
                for c in range(m):
                    if count >= n:
                        break
                    cx = (c + 0.5) * (1.0 / m)
                    cy = (r + 0.5) * (1.0 / k)
                    sqs.append((cx, cy, s))
                    count += 1
                if count >= n:
                    break
            consider(sqs)

    # ---- Family B: guillotine recursive with power-law weights ----
    for p in (0.0, 0.35, 0.5, 0.7, 1.0, 1.5, 2.0):
        weights = [1.0 / (1.0 + p * i) for i in range(n)]
        sq = _rect_layout(0.0, 0.0, 1.0, 1.0, list(range(n)), weights)
        consider(sq)
        # reversed order (largest in other corner)
        w2 = [1.0 / (1.0 + p * (n - 1 - i)) for i in range(n)]
        sq2 = _rect_layout(0.0, 0.0, 1.0, 1.0, list(range(n)), w2)
        consider(sq2)

    # ---- Family C: big square in a corner + grid in the L region ----
    for bigf in (0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8):
        bs = bigf
        h = bs / 2.0
        big = (h, h, bs)  # bottom-left corner
        rem_n = n - 1
        if rem_n <= 0:
            consider([big])
            continue
        # remaining region: right strip [bs,1]x[0,1] and top strip [0,bs]x[bs,1]
        # try splitting rem_n between them and using grid fill
        for a in range(0, rem_n + 1):
            b = rem_n - a
            sqs = [big]
            ok = True
            # right strip
            if a > 0:
                W = 1.0 - bs
                H = 1.0
                # grid in strip: rows = a? use single column if W small
                # choose cols,rows such that cols*rows >= a and dims fit
                bestlocal = None
                bestlocal_sum = -1.0
                for cols in range(1, a + 1):
                    for rows in range(1, a + 1):
                        if cols * rows < a:
                            continue
                        s = min(W / cols, H / rows)
                        cnt = 0
                        loc = []
                        for r in range(rows):
                            for c in range(cols):
                                if cnt >= a:
                                    break
                                cx = bs + (c + 0.5) * (W / cols)
                                cy = (r + 0.5) * (H / rows)
                                loc.append((cx, cy, s))
                                cnt += 1
                            if cnt >= a:
                                break
                        sm = sum(x[2] for x in loc)
                        if sm > bestlocal_sum:
                            bestlocal_sum = sm
                            bestlocal = loc
                if bestlocal is not None:
                    sqs.extend(bestlocal)
            # top strip
            if b > 0:
                W = bs
                H = 1.0 - bs
                bestlocal = None
                bestlocal_sum = -1.0
                for cols in range(1, b + 1):
                    for rows in range(1, b + 1):
                        if cols * rows < b:
                            continue
                        s = min(W / cols, H / rows)
                        cnt = 0
                        loc = []
                        for r in range(rows):
                            for c in range(cols):
                                if cnt >= b:
                                    break
                                cx = (c + 0.5) * (W / cols)
                                cy = bs + (r + 0.5) * (H / rows)
                                loc.append((cx, cy, s))
                                cnt += 1
                            if cnt >= b:
                                break
                        sm = sum(x[2] for x in loc)
                        if sm > bestlocal_sum:
                            bestlocal_sum = sm
                            bestlocal = loc
                if bestlocal is not None:
                    sqs.extend(bestlocal)
            if len(sqs) == n:
                consider(sqs)

    return best, best_sum


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best, s = _best_layout(n)
    if best is None:
        # fallback: grid
        m = int(math.ceil(math.sqrt(n)))
        k = int(math.ceil(n / m))
        side = min(1.0 / m, 1.0 / k)
        best = []
        cnt = 0
        for r in range(k):
            for c in range(m):
                if cnt >= n:
                    break
                best.append(((c + 0.5) / m, (r + 0.5) / k, side))
                cnt += 1
            if cnt >= n:
                break
    return [(cx, cy, 0.0, side) for (cx, cy, side) in best]
