# EVOLVE-BLOCK-START
"""Squares in a unit square: maximise total side length.

Strategy: partition the unit square into up to five rectangular regions
(a main region plus a right strip, a top region that may be split into
two side-by-side sub-strips, and a corner block).  Each region is packed
with equal squares via the best grid factorisation.  We search over the
split fractions and the distribution of squares between regions to
maximise the total side sum.  The best candidate is then improved by a
continuous soft-penalty local search over per-square centre, side and
angle, so that unequal-sized (and slightly rotated) squares absorb the
slack the regular grids leave behind.
"""
import math
import random


# ----------------------------------------------------------------------
# grid packing
# ----------------------------------------------------------------------
def _pack_grid(count, W, H):
    """Best equal-square grid for `count` squares inside a W x H box."""
    if count <= 0 or W <= 0 or H <= 0:
        return [], 0.0, 0
    best = None
    for a in range(1, count + 1):
        b = (count + a - 1) // a
        if a * b < count:
            continue
        s = min(W / a, H / b)
        total = s * count
        if best is None or total > best[0]:
            best = (total, a, b, s)
    if best is None:
        return [], 0.0, 0
    _, a, b, s = best
    sq = []
    used = 0
    for i in range(a):
        for j in range(b):
            if used >= count:
                break
            cx = (i + 0.5) * s
            cy = (j + 0.5) * s
            sq.append((cx, cy, 0.0, s))
            used += 1
        if used >= count:
            break
    return sq, s, used


# ----------------------------------------------------------------------
# region layouts
# ----------------------------------------------------------------------
def _layout3(n, nb, ns1, ns2, fw, fh):
    mw, mh = 1.0 - fw, 1.0 - fh
    rw, rh = fw, 1.0 - fh
    tw, th = 1.0, fh

    big, bs, used_big = _pack_grid(nb, mw, mh)
    if nb > 0 and used_big < nb:
        return None
    s1, ss1, u1 = _pack_grid(ns1, rw, rh)
    if ns1 > 0 and u1 < ns1:
        return None
    s2, ss2, u2 = _pack_grid(ns2, tw, th)
    if ns2 > 0 and u2 < ns2:
        return None

    squares = []
    for sq in big:
        squares.append(sq)
    ox1 = mw
    for (cx, cy, a, s) in s1:
        squares.append((cx + ox1, cy, a, s))
    oy2 = mh
    for (cx, cy, a, s) in s2:
        squares.append((cx, cy + oy2, a, s))

    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss1 * u1 + ss2 * u2
    return total, squares[:n]


def _layout5_simple(n, nb, ns1, ns2a, nsc, fw, fh, gy):
    mw, mh = 1.0 - fw, 1.0 - fh
    rlw, rlh = fw, 1.0 - gy
    tsw, tsh = mw, fh
    cw, ch = fw, gy

    big, bs, used_big = _pack_grid(nb, mw, mh)
    if nb > 0 and used_big < nb:
        return None
    s1, ss1, u1 = _pack_grid(ns1, rlw, rlh)
    if ns1 > 0 and u1 < ns1:
        return None
    sa, ssa, ua = _pack_grid(ns2a, tsw, tsh)
    if ns2a > 0 and ua < ns2a:
        return None
    sc, ssc, uc = _pack_grid(nsc, cw, ch)
    if nsc > 0 and uc < nsc:
        return None

    squares = []
    for sq in big:
        squares.append(sq)
    ox1 = mw
    for (cx, cy, a, s) in s1:
        squares.append((cx + ox1, cy, a, s))
    oy2 = mh
    for (cx, cy, a, s) in sa:
        squares.append((cx, cy + oy2, a, s))
    oxc = mw
    oyc = 1.0 - gy
    for (cx, cy, a, s) in sc:
        squares.append((cx + oxc, cy + oyc, a, s))

    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss1 * u1 + ssa * ua + ssc * uc
    return total, squares[:n]


def _layout4(n, nb, ns1, ns2a, ns2b, fw, fh, g):
    mw, mh = 1.0 - fw, 1.0 - fh
    rw, rh = fw, 1.0 - fh
    tlw, th = g, fh
    trw = 1.0 - g

    big, bs, used_big = _pack_grid(nb, mw, mh)
    if nb > 0 and used_big < nb:
        return None
    s1, ss1, u1 = _pack_grid(ns1, rw, rh)
    if ns1 > 0 and u1 < ns1:
        return None
    sa, ssa, ua = _pack_grid(ns2a, tlw, th)
    if ns2a > 0 and ua < ns2a:
        return None
    sb, ssb, ub = _pack_grid(ns2b, trw, th)
    if ns2b > 0 and ub < ns2b:
        return None

    squares = []
    for sq in big:
        squares.append(sq)
    ox1 = mw
    for (cx, cy, a, s) in s1:
        squares.append((cx + ox1, cy, a, s))
    oy2 = mh
    for (cx, cy, a, s) in sa:
        squares.append((cx, cy + oy2, a, s))
    for (cx, cy, a, s) in sb:
        squares.append((cx + g, cy + oy2, a, s))

    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss1 * u1 + ssa * ua + ssb * ub
    return total, squares[:n]


# ----------------------------------------------------------------------
# geometry: separating axis for two squares
# ----------------------------------------------------------------------
_TWO_PI = 2.0 * math.pi


def _axes(cx, cy, a, s):
    """Return the four corner points of a square."""
    th = a * _TWO_PI
    c, si = math.cos(th), math.sin(th)
    h = s * 0.5
    ux, uy = c * h, si * h
    vx, vy = -si * h, c * h
    return ((cx - ux - vx, cy - uy - vy),
            (cx + ux - vx, cy + uy - vy),
            (cx + ux + vx, cy + uy + vy),
            (cx - ux + vx, cy - uy + vy))


def _overlap_depth(sq1, sq2):
    """Minimum translation distance to separate two convex squares.

    Returns (depth, axis_x, axis_y): depth > 0 means they overlap; the
    axis is a unit normal along which the penetration is `depth`.
    """
    p1 = _axes(*sq1)
    p2 = _axes(*sq2)
    best = None
    for poly in (p1, p2):
        for k in range(4):
            ax, ay = poly[k]
            bx, by = poly[(k + 1) % 4]
            nx, ny = -(by - ay), (bx - ax)
            ln = math.hypot(nx, ny)
            if ln < 1e-15:
                continue
            nx /= ln
            ny /= ln
            lo1 = hi1 = p1[0][0] * nx + p1[0][1] * ny
            for p in p1[1:]:
                d = p[0] * nx + p[1] * ny
                if d < lo1:
                    lo1 = d
                elif d > hi1:
                    hi1 = d
            lo2 = hi2 = p2[0][0] * nx + p2[0][1] * ny
            for p in p2[1:]:
                d = p[0] * nx + p[1] * ny
                if d < lo2:
                    lo2 = d
                elif d > hi2:
                    hi2 = d
            if hi1 < lo2 or hi2 < lo1:
                return None  # separated along this axis
            pen = min(hi1 - lo2, hi2 - lo1)
            if best is None or pen < best[0]:
                best = (pen, nx, ny)
    return best


# ----------------------------------------------------------------------
# continuous soft-penalty relaxation
# ----------------------------------------------------------------------
def _relax(squares, rounds=220, lam=60.0, mu=60.0,
           eta=0.35, rng=None, allow_angle=True):
    """Improve a layout by soft-penalty local search.

    State per square: (cx, cy, side, angle).  Objective:
        sum(side) - lam*overlap - mu*boundary_violation
    Penalties shrink geometrically so we settle into a valid layout.
    """
    if rng is None:
        rng = random.Random(12345)
    st = [[s[0], s[1], s[3], s[2]] for s in squares]
    m = len(st)

    def obj(state):
        tot = 0.0
        pen = 0.0
        # boundary
        for k in range(m):
            cx, cy, sd, an = state[k]
            if sd <= 0.0:
                tot += 0.0
                continue
            tot += sd
            pts = _axes(cx, cy, an, sd)
            vx = 0.0
            for p in pts:
                if p[0] < 0.0:
                    vx += -p[0]
                elif p[0] > 1.0:
                    vx += p[0] - 1.0
                if p[1] < 0.0:
                    vx += -p[1]
                elif p[1] > 1.0:
                    vx += p[1] - 1.0
            pen += vx * vx
        # pairwise overlap
        for i in range(m):
            for j in range(i + 1, m):
                if state[i][2] <= 1e-12 or state[j][2] <= 1e-12:
                    continue
                ov = _overlap_depth(state[i][:3] + (state[i][2],),
                                    state[j][:3] + (state[j][2],))
                if ov is not None:
                    pen += ov[0] * ov[0]
        return tot - lam * pen, tot, pen

    cur_obj, _, _ = obj(st)
    best_state = [row[:] for row in st]
    best_total = -1.0

    def total_of(state):
        return sum(max(0.0, r[2]) for r in state)

    def valid_of(state):
        # check validity strictly
        for k in range(m):
            cx, cy, sd, an = state[k]
            if sd <= 0:
                cx, cy, sd, an = 0.5, 0.5, 0.0, 0.0
            pts = _axes(cx, cy, an, sd)
            for p in pts:
                if p[0] < -1e-9 or p[0] > 1 + 1e-9 or \
                   p[1] < -1e-9 or p[1] > 1 + 1e-9:
                    return False
        for i in range(m):
            if state[i][2] <= 1e-12:
                continue
            for j in range(i + 1, m):
                if state[j][2] <= 1e-12:
                    continue
                ov = _overlap_depth(state[i][:3] + (state[i][2],),
                                    state[j][:3] + (state[j][2],))
                if ov is not None and ov[0] > 1e-7:
                    return False
        return True

    step = 0.02
    for it in range(rounds):
        if it % 30 == 29:
            lam *= 0.72
            mu *= 0.72
        improved_any = False
        order = list(range(m))
        rng.shuffle(order)
        for k in order:
            for _ in range(2):
                for dvar in range(4):
                    if dvar == 3 and not allow_angle:
                        continue
                    d = step if rng.random() < 0.5 else -step
                    scale = 1.0 if dvar < 2 else 0.6
                    old = st[k][dvar]
                    if dvar == 3:
                        st[k][dvar] += d * 0.05
                    else:
                        st[k][dvar] += d * scale
                    if st[k][2] < 0.0:
                        st[k][2] = 0.0
                    if st[k][0] < -0.05:
                        st[k][0] = -0.05
                    elif st[k][0] > 1.05:
                        st[k][0] = 1.05
                    if st[k][1] < -0.05:
                        st[k][1] = -0.05
                    elif st[k][1] > 1.05:
                        st[k][1] = 1.05
                    no, tv, pv = obj(st)
                    if no > cur_obj + 1e-15:
                        cur_obj = no
                        improved_any = True
                        if pv < 1e-6:
                            t = total_of(st)
                            if t > best_total + 1e-12 and valid_of(st):
                                best_total = t
                                best_state = [row[:] for row in st]
                    else:
                        st[k][dvar] = old
        if not improved_any:
            step *= 0.6
            if step < 1e-5:
                break

    # final validity fallback
    if not valid_of(st):
        t = total_of(st)
        if t > best_total:
            best_state = [row[:] for row in st]
            best_total = t
    out = []
    for (cx, cy, sd, an) in best_state:
        if sd < 0.0:
            sd = 0.0
        an = an - math.floor(an)
        out.append((cx, cy, an, sd))
    return best_total, out


# ----------------------------------------------------------------------
# coordinate descent helpers for the discrete layouts
# ----------------------------------------------------------------------
def _coord_refine3(n, nb, ns1, ns2, init_fw, init_fh, budget=40):
    cfw, cfh = init_fw, init_fh
    best = _layout3(n, nb, ns1, ns2, cfw, cfh)
    best_t = best[0] if best else -1.0
    step = 0.08
    for _ in range(budget):
        improved = False
        for dfw in (-step, 0.0, step):
            for dfh in (-step, 0.0, step):
                nfw = cfw + dfw
                nfh = cfh + dfh
                if not (0.0 <= nfw <= 1.0 and 0.0 <= nfh <= 1.0):
                    continue
                r = _layout3(n, nb, ns1, ns2, nfw, nfh)
                if r and r[0] > best_t + 1e-12:
                    best_t = r[0]
                    best = r
                    cfw, cfh = nfw, nfh
                    improved = True
        if not improved:
            step *= 0.5
            if step < 1e-4:
                break
    return best_t, best


def _layout(n, n_big, split_frac, vertical):
    if vertical:
        fw = split_frac
        bw, bh = fw, 1.0
        sw, sh = 1.0 - fw, 1.0
    else:
        fh = split_frac
        bw, bh = 1.0, fh
        sw, sh = 1.0, 1.0 - fh

    big, bs, used_big = _pack_grid(n_big, bw, bh)
    if used_big < n_big:
        return None
    rest = n - n_big
    small, ss, used_small = _pack_grid(rest, sw, sh)

    squares = list(big)
    ox = bw if vertical else 0.0
    oy = 0.0 if vertical else bh
    for (cx, cy, a, s) in small:
        squares.append((cx + ox, cy + oy, a, s))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    total = bs * used_big + ss * used_small
    return total, squares[:n]


# ----------------------------------------------------------------------
# main driver
# ----------------------------------------------------------------------
def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_total = -1.0
    best_squares = None

    def consider(r):
        nonlocal best_total, best_squares
        if r and r[0] > best_total:
            best_total = r[0]
            best_squares = r[1]

    # ---- two-region search (cheap baseline) ----
    for n_big in range(1, n + 1):
        for vertical in (True, False):
            lo, hi = 0.01, 0.99
            for _ in range(30):
                m1 = lo + (hi - lo) / 3
                m2 = hi - (hi - lo) / 3
                r1 = _layout(n, n_big, m1, vertical)
                r2 = _layout(n, n_big, m2, vertical)
                t1 = r1[0] if r1 else -1
                t2 = r2[0] if r2 else -1
                if t1 >= t2:
                    hi = m2
                else:
                    lo = m1
            for f in (lo, (lo + hi) / 2, hi):
                consider(_layout(n, n_big, f, vertical))

    # ---- three-region search ----
    for nb in range(0, n + 1):
        for ns1 in range(0, n - nb + 1):
            ns2 = n - nb - ns1
            if ns2 < 0:
                continue
            best_local = None
            for fi in range(1, 8):
                fw = fi / 8.0
                for fj in range(1, 8):
                    fh = fj / 8.0
                    r = _layout3(n, nb, ns1, ns2, fw, fh)
                    if r and (best_local is None or r[0] > best_local[0]):
                        best_local = (r[0], fw, fh)
            if best_local is None:
                continue
            tl, r = _coord_refine3(n, nb, ns1, ns2,
                                   best_local[1], best_local[2])
            if r:
                consider((tl, r[1]))

    # ---- four-region search ----
    for nb in range(0, n + 1):
        for ns1 in range(0, n - nb + 1):
            rem = n - nb - ns1
            if rem < 0:
                continue
            for ns2a in range(0, rem + 1):
                ns2b = rem - ns2a
                best_local = None
                for fi in range(1, 5):
                    fw = fi / 5.0
                    for fj in range(1, 5):
                        fh = fj / 5.0
                        r = _layout3(n, nb, ns1, rem, fw, fh)
                        if r and (best_local is None or r[0] > best_local[0]):
                            best_local = (r[0], fw, fh)
                if best_local is None:
                    continue
                cfw, cfh = best_local[1], best_local[2]
                best4 = None
                for gi in range(1, 8):
                    g = gi / 8.0
                    r = _layout4(n, nb, ns1, ns2a, ns2b, cfw, cfh, g)
                    if r and (best4 is None or r[0] > best4[0]):
                        best4 = (r[0], cfw, cfh, g)
                if best4 is None:
                    continue
                bfw, bfh, bg = best4[1], best4[2], best4[3]
                step = 0.06
                cur = best4
                for _ in range(25):
                    improved = False
                    for dfw in (-step, 0.0, step):
                        for dfh in (-step, 0.0, step):
                            for dg in (-step, 0.0, step):
                                nfw = bfw + dfw
                                nfh = bfh + dfh
                                ng = bg + dg
                                if not (0.0 <= nfw <= 1.0 and
                                        0.0 <= nfh <= 1.0 and
                                        0.0 <= ng <= 1.0):
                                    continue
                                r = _layout4(n, nb, ns1, ns2a, ns2b,
                                             nfw, nfh, ng)
                                if r and r[0] > cur[0] + 1e-12:
                                    cur = (r[0], nfw, nfh, ng)
                                    bfw, bfh, bg = nfw, nfh, ng
                                    improved = True
                    if not improved:
                        step *= 0.5
                        if step < 1e-4:
                            break
                r = _layout4(n, nb, ns1, ns2a, ns2b, bfw, bfh, bg)
                if r:
                    consider((r[0], r[1]))

    # ---- five-region search (right column split + corner) ----
    for nb in range(0, n + 1):
        for ns1 in range(0, n - nb + 1):
            rem = n - nb - ns1
            if rem < 0:
                continue
            for ns2a in range(0, rem + 1):
                nsc = rem - ns2a
                best_local = None
                for fi in range(1, 5):
                    fw = fi / 5.0
                    for fj in range(1, 5):
                        fh = fj / 5.0
                        for gk in range(1, 5):
                            gy = gk / 5.0
                            r = _layout5_simple(n, nb, ns1, ns2a, nsc,
                                                fw, fh, gy)
                            if r and (best_local is None or
                                      r[0] > best_local[0]):
                                best_local = (r[0], fw, fh, gy)
                if best_local is None:
                    continue
                bfw, bfh, bgy = best_local[1], best_local[2], best_local[3]
                step = 0.06
                cur = best_local
                for _ in range(25):
                    improved = False
                    for dfw in (-step, 0.0, step):
                        for dfh in (-step, 0.0, step):
                            for dgy in (-step, 0.0, step):
                                nfw = bfw + dfw
                                nfh = bfh + dfh
                                ngy = bgy + dgy
                                if not (0.0 <= nfw <= 1.0 and
                                        0.0 <= nfh <= 1.0 and
                                        0.0 <= ngy <= 1.0):
                                    continue
                                r = _layout5_simple(n, nb, ns1, ns2a, nsc,
                                                    nfw, nfh, ngy)
                                if r and r[0] > cur[0] + 1e-12:
                                    cur = (r[0], nfw, nfh, ngy)
                                    bfw, bfh, bgy = nfw, nfh, ngy
                                    improved = True
                    if not improved:
                        step *= 0.5
                        if step < 1e-4:
                            break
                r = _layout5_simple(n, nb, ns1, ns2a, nsc, bfw, bfh, bgy)
                if r:
                    consider((r[0], r[1]))

    if best_squares is None:
        k = math.isqrt(n)
        s = 1.0 / max(1, k)
        best_squares = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                        for i in range(k) for j in range(k)]
        while len(best_squares) < n:
            best_squares.append((0.5, 0.5, 0.0, 0.0))

    # ---- continuous relaxation polish ----
    try:
        rng = random.Random(9871 + n)
        rt, rsq = _relax(best_squares, rounds=200, lam=80.0, mu=80.0,
                         rng=rng, allow_angle=True)
        # only accept the relaxed layout if it is valid and no worse
        if rsq is not None and len(rsq) == n:
            tot = 0.0
            ok = True
            for (cx, cy, an, sd) in rsq:
                sd = max(0.0, sd)
                if sd <= 1e-12:
                    continue
                tot += sd
                pts = _axes(cx, cy, an, sd)
                for p in pts:
                    if p[0] < -1e-7 or p[0] > 1 + 1e-7 or \
                       p[1] < -1e-7 or p[1] > 1 + 1e-7:
                        ok = False
                        break
                if not ok:
                    break
            if ok:
                for i in range(n):
                    if rsq[i][3] <= 1e-12:
                        continue
                    for j in range(i + 1, n):
                        if rsq[j][3] <= 1e-12:
                            continue
                        ov = _overlap_depth(
                            (rsq[i][0], rsq[i][1], rsq[i][2], rsq[i][3]),
                            (rsq[j][0], rsq[j][1], rsq[j][2], rsq[j][3]))
                        if ov is not None and ov[0] > 1e-7:
                            ok = False
                            break
                    if not ok:
                        break
            if ok and tot >= best_total - 1e-6:
                # clamp tiny numerical excursions inside the box
                out = []
                for (cx, cy, an, sd) in rsq:
                    sd = max(0.0, sd)
                    cx = min(1.0, max(0.0, cx))
                    cy = min(1.0, max(0.0, cy))
                    if sd > 1.0:
                        sd = 1.0
                    an = an - math.floor(an)
                    out.append((cx, cy, an, sd))
                if len(out) == n:
                    best_squares = out
    except Exception:
        pass

    return best_squares[:n]
# EVOLVE-BLOCK-END
