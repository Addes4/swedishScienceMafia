# EVOLVE-BLOCK-START
"""Grid/strip seeding plus exact-SAT greedy growth packing of squares."""

import math
import random
import numpy as np
from scipy.optimize import minimize


# ---------------------------------------------------------------- geometry ---
def _axes(a):
    """Unit normals of the 4 support axes of a square rotated by angle a (turns)."""
    t = 2.0 * math.pi * a
    c, s = math.cos(t), math.sin(t)
    return ((c, s), (-s, c))


def _proj(cx, cy, ax, ay, a, s):
    """Projection interval [lo, hi] of a rotated square onto axis (ax, ay)."""
    h = 0.5 * s
    ux, uy = _axes(a)
    r = h * (abs(ux[0] * ax + ux[1] * ay) + abs(uy[0] * ax + uy[1] * ay))
    d = cx * ax + cy * ay
    return d - r, d + r


def _overlap_amount(sq1, sq2):
    """Return min overlap (<=0 means separated) along SAT axes of the two squares."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 0.0 or s2 <= 0.0:
        return -1.0
    best = -1.0
    for (ax, ay) in (list(_axes(a1)) + list(_axes(a2))):
        lo1, hi1 = _proj(cx1, cy1, ax, ay, a1, s1)
        lo2, hi2 = _proj(cx2, cy2, ax, ay, a2, s2)
        ov = min(hi1 - lo2, hi2 - lo1)
        if ov <= 0.0:
            return ov  # separating axis found
        if best < 0.0 or ov < best:
            best = ov
    return best


def _inside(cx, cy, a, s, eps=1e-9):
    if s <= 0.0:
        return True
    t = 2.0 * math.pi * a
    c, sn = abs(math.cos(t)), abs(math.sin(t))
    r = 0.5 * s * (c + sn)
    return (cx - r >= -eps and cx + r <= 1.0 + eps and
            cy - r >= -eps and cy + r <= 1.0 + eps)


# ------------------------------------------------------------------ seeds ---
def _grid_seed(n):
    """k x m grid of equal squares, best-fitting k*m >= n by removing extras."""
    best = None
    for k in range(1, n + 1):
        for m in range(1, n + 1):
            if k * m < n:
                continue
            side = min(1.0 / k, 1.0 / m)
            cells = []
            for i in range(k):
                for j in range(m):
                    cx = (i + 0.5) * (1.0 / k)
                    cy = (j + 0.5) * (1.0 / m)
                    cells.append([cx, cy, 0.0, side])
            if best is None or len(cells) < len(best):
                best = cells
    return best if best is not None else []


def _strip_seed(n, vertical=True):
    """Split into strips of equal repeated squares along one axis."""
    best = None
    for k in range(1, n + 1):
        w = 1.0 / k
        side = w
        per = max(1, int(round(1.0 / side)))
        total = k * per
        if total < n:
            continue
        cells = []
        for i in range(k):
            for j in range(per):
                if vertical:
                    cx = (i + 0.5) * w
                    cy = (j + 0.5) * (1.0 / per)
                else:
                    cx = (j + 0.5) * (1.0 / per)
                    cy = (i + 0.5) * w
                cells.append([cx, cy, 0.0, side])
        if len(cells) >= n and (best is None or len(cells) < len(best)):
            best = cells
    return best if best is not None else []


def _slicing_seed(n):
    """Recursive halving seed used previously."""
    cells = [[0.5, 0.5, 0.0, 1.0]]
    while len(cells) < n:
        idx = max(range(len(cells)), key=lambda t: cells[t][3])
        cx, cy, ang, s = cells[idx]
        ns = s * 0.5
        d = s * 0.25
        cells.pop(idx)
        for dx in (-d, d):
            for dy in (-d, d):
                cells.append([cx + dx, cy + dy, ang, ns])
    cells.sort(key=lambda t: -t[3])
    return cells[:n]


def _big_plus_grid_seed(n):
    """One large square in a corner plus a grid of small squares in the L-shape."""
    if n < 2:
        return []
    best = None
    for big_side in (0.5, 0.6, 0.65, 0.7):
        rest = n - 1
        for k in range(1, rest + 2):
            for m in range(1, rest + 2):
                if k * m < rest:
                    continue
                # region right of and above the big corner square
                avail_x = 1.0 - big_side
                avail_y = 1.0 - big_side
                sx = avail_x / k if k > 0 else 0
                sy = avail_y / m if m > 0 else 0
                side = min(sx, sy)
                if side <= 1e-9:
                    continue
                cells = [[big_side / 2.0, big_side / 2.0, 0.0, big_side]]
                for i in range(k):
                    for j in range(m):
                        cx = big_side + (i + 0.5) * sx
                        cy = big_side + (j + 0.5) * sy
                        cells.append([cx, cy, 0.0, side])
                if len(cells) < n:
                    continue
                score = sum(c[3] for c in cells[:n])
                if best is None or score > best[0]:
                    best = (score, cells[:n])
    return best[1] if best else []


def _fit_seed(cells):
    """Shrink-and-place a raw seed so nothing overlaps or leaves the box."""
    idx = sorted(range(len(cells)), key=lambda i: -cells[i][3])
    placed = []
    for i in idx:
        cx, cy, a, s = cells[i]
        a = a % 0.5
        t = 2.0 * math.pi * a
        r = abs(math.cos(t)) + abs(math.sin(t))
        s = min(s, 1.0 / r if r > 1e-12 else 1.0)
        if not (0.0 <= cx <= 1.0):
            cx = 0.5
        if not (0.0 <= cy <= 1.0):
            cy = 0.5
        for _ in range(60):
            if not _inside(cx, cy, a, s):
                s *= 0.95
                continue
            ok = True
            for p in placed:
                if _overlap_amount((cx, cy, a, s), p) > 1e-12:
                    ok = False
                    break
            if ok:
                break
            s *= 0.9
        placed.append([cx, cy, a, max(s, 0.0)])
    return placed


# ---------------------------------------------------------------- growing ---
def _can_grow(cur, i, s_new, eps=1e-10):
    cx, cy, a, _ = cur[i]
    if not _inside(cx, cy, a, s_new, eps):
        return False
    test = (cx, cy, a, s_new)
    for j in range(len(cur)):
        if j == i:
            continue
        if _overlap_amount(test, cur[j]) > eps:
            return False
    return True


def _grow_all(cur, rounds=6, factors=(1.15, 1.08, 1.04, 1.02, 1.01, 1.005, 1.002)):
    """Greedily grow every square; repeat until no improvement."""
    n = len(cur)
    order = sorted(range(n), key=lambda i: -cur[i][3])
    improved = True
    rnd = 0
    while improved and rnd < rounds:
        improved = False
        rnd += 1
        for i in order:
            s = cur[i][3]
            for f in factors:
                ns = s * f
                if _can_grow(cur, i, ns):
                    cur[i][3] = ns
                    improved = True
                    break
    return cur


def _local_grow(cur, tries=400, rng=None):
    """Randomised nudges + re-grow to squeeze extra total side length."""
    if rng is None:
        rng = random.Random(0)
    n = len(cur)
    best = [list(c) for c in cur]
    best_score = sum(c[3] for c in best)
    amp = 0.01
    for _ in range(tries):
        cand = [list(c) for c in best]
        i = rng.randrange(n)
        cx, cy, a, s = cand[i]
        d = amp
        ncx = min(max(cx + rng.uniform(-d, d), 0.0), 1.0)
        ncy = min(max(cy + rng.uniform(-d, d), 0.0), 1.0)
        na = (a + rng.uniform(-0.02, 0.02)) % 0.5
        if _inside(ncx, ncy, na, s):
            test = (ncx, ncy, na, s)
            good = True
            for j in range(n):
                if j == i:
                    continue
                if _overlap_amount(test, cand[j]) > 1e-10:
                    good = False
                    break
            if good:
                cand[i] = [ncx, ncy, na, s]
                _grow_all(cand, rounds=3)
                score = sum(c[3] for c in cand)
                if score > best_score + 1e-12:
                    best_score = score
                    best = cand
    return best


# ----------------------------------------------------------- exact refine ---
def _refine_slsqp(cur, n, maxiter=300):
    """SLSQP: maximise sum(side) subject to exact SAT separation & containment.

    Variables per square: cx, cy, angle, side (4n total).
    Constraint (gap) for pair (i,j): g = gap_{ij}(x) >= 0 where gap is the
    maximum over the 4 SAT axes of the (relative) projection separation.
    Containment is enforced by requiring each square inside [0,1]^2.
    """
    x0 = np.array([v for c in cur for v in (c[0], c[1], c[2] % 0.5, c[3])],
                  dtype=float)

    def unpack(x):
        return x.reshape(n, 4)

    def pair_gap(pi, pj):
        """>=0 means separated. Uses 4 axes of both squares."""
        cxi, cyi, ai, si = pi
        cxj, cyj, aj, sj = pj
        if si <= 1e-12 or sj <= 1e-12:
            return 1.0
        gaps = []
        for (ax, ay) in (list(_axes(ai)) + list(_axes(aj))):
            lo1, hi1 = _proj(cxi, cyi, ax, ay, ai, si)
            lo2, hi2 = _proj(cxj, cyj, ax, ay, aj, sj)
            # separation on this axis
            gaps.append(max(lo2 - hi1, lo1 - hi2))
        return max(gaps)

    # Precompute constraint index list (pairs that are "close" in current layout)
    pairs = []
    P = unpack(x0)
    for i in range(n):
        for j in range(i + 1, n):
            if P[i, 3] <= 1e-12 or P[j, 3] <= 1e-12:
                continue
            pairs.append((i, j))

    def neg_total(x):
        return -float(np.sum(x[3::4]))

    def neg_grad(x):
        g = np.zeros_like(x)
        g[3::4] = -1.0
        return g

    # Containment constraints: r <= cx, cx + r <= 1, etc.  r depends on angle.
    def containment(x):
        P = unpack(x)
        cons = []
        for i in range(n):
            cx, cy, a, s = P[i]
            t = 2.0 * math.pi * a
            c = abs(math.cos(t)) + abs(math.sin(t))
            r = 0.5 * s * c
            # cx - r >= 0 -> cx - r
            cons.append(cx - r)
            cons.append(1.0 - (cx + r))
            cons.append(cy - r)
            cons.append(1.0 - (cy + r))
        return np.array(cons)

    def separation(x):
        P = unpack(x)
        cons = []
        for (i, j) in pairs:
            cons.append(pair_gap(P[i], P[j]))
        return np.array(cons)

    def sep_jac(x):
        P = unpack(x)
        m = len(pairs)
        J = np.zeros((m, 4 * n))
        h = 1e-5
        for k, (i, j) in enumerate(pairs):
            base = pair_gap(P[i], P[j])
            for var in range(4):
                for (idx, sign) in ((i, 1.0), (j, -1.0)):
                    xp = x.copy()
                    xp[4 * idx + var] += h
                    Pp = unpack(xp)
                    g = pair_gap(Pp[i], Pp[j])
                    J[k, 4 * idx + var] = (g - base) / h
        return J

    def cont_jac(x):
        P = unpack(x)
        m = 4 * n
        J = np.zeros((m, 4 * n))
        h = 1e-5
        for i in range(n):
            base = containment(x)[4 * i:4 * i + 4]
            for var in range(4):
                xp = x.copy()
                xp[4 * i + var] += h
                gp = containment(xp)[4 * i:4 * i + 4]
                J[4 * i:4 * i + 4, 4 * i + var] = (gp - base) / h
        return J

    constraints = [
        {"type": "ineq", "fun": containment, "jac": cont_jac},
    ]
    if pairs:
        constraints.append({"type": "ineq", "fun": separation, "jac": None})

    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))   # cx
        bounds.append((0.0, 1.0))   # cy
        bounds.append((-1.0, 1.0))  # angle (wrapped)
        bounds.append((0.0, 1.0))   # side

    try:
        res = minimize(neg_total, x0, jac=neg_grad, method="SLSQP",
                       bounds=bounds, constraints=constraints,
                       options={"maxiter": maxiter, "ftol": 1e-9})
    except Exception:
        return None
    if res is None or not np.all(np.isfinite(res.x)):
        return None
    P = unpack(res.x)
    out = []
    for i in range(n):
        cx, cy, a, s = P[i]
        a = float(a) % 0.5
        s = max(float(s), 0.0)
        out.append([float(cx), float(cy), a, s])
    # Feasibility check (strict)
    for i in range(n):
        if not _inside(out[i][0], out[i][1], out[i][2], out[i][3], 1e-6):
            return None
        if out[i][3] <= 0:
            return None
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap_amount(out[i], out[j]) > 1e-6:
                return None
    return out


# ---------------------------------------------------------------- driver ---
def _clean(cur, n):
    """Drop 0-size squares and pad to exactly n."""
    placed = [list(c) for c in cur if c[3] > 1e-9]
    while len(placed) < n:
        placed.append([0.5, 0.5, 0.0, 0.0])
    return placed[:n]


def _seed_candidates(n):
    seeds = []
    seeds.append(_slicing_seed(n))
    seeds.append(_grid_seed(n))
    seeds.append(_strip_seed(n, True))
    seeds.append(_strip_seed(n, False))
    bg = _big_plus_grid_seed(n)
    if bg:
        seeds.append(bg)
    out = []
    seen = set()
    for s in seeds:
        if not s:
            continue
        key = tuple(sorted(round(c[3], 6) for c in s))
        if key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out


def solve(n):
    """Return n squares (cx, cy, angle, side) inside the unit square,
    maximising the sum of the side lengths."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(20240517)

    best = None
    best_score = -1.0

    candidates = _seed_candidates(n)
    for seed in candidates:
        cur = _fit_seed(seed)
        if len(cur) < n:
            continue
        while len(cur) > n:
            cur.pop()
        _grow_all(cur, rounds=8)
        cur = _local_grow(cur, tries=120, rng=rng)
        _grow_all(cur, rounds=4)
        cur = _clean(cur, n)
        # SLSQP refine of the (nearly) best seed so far
        ref = _refine_slsqp(cur, n, maxiter=250)
        if ref is not None:
            sref = sum(c[3] for c in ref)
            scur = sum(c[3] for c in cur)
            if sref > scur:
                cur = ref
        score = sum(c[3] for c in cur)
        if score > best_score:
            best_score = score
            best = [list(c) for c in cur]

    if best is None:
        best = _fit_seed(_slicing_seed(n))[:n]

    # Final feasibility pass
    final = []
    placed = []
    for c in sorted(best, key=lambda t: -t[3]):
        cx, cy, a, s = c
        a = a % 0.5
        for _ in range(80):
            if _inside(cx, cy, a, s):
                break
            s *= 0.97
        placed.append((cx, cy, a, max(s, 0.0)))
        final.append((cx, cy, a, max(s, 0.0)))

    while len(final) < n:
        final.append((0.5, 0.5, 0.0, 0.0))
    final = final[:n]

    out = []
    for (cx, cy, a, s) in final:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    return out
# EVOLVE-BLOCK-END
