import math
import numpy as np
from scipy.optimize import minimize

# EVOLVE-BLOCK-START


def _half_extent(angle, side):
    """Half-extents of the axis-aligned bounding box of a rotated square."""
    c = abs(math.cos(2 * math.pi * angle))
    s = abs(math.sin(2 * math.pi * angle))
    return 0.5 * side * (c + s)


def _overlap_penalty(centers, angles, sides, box=1.0):
    """Return total penalty: overlap area approximation + out-of-box."""
    n = len(sides)
    pen = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            dx = centers[i][0] - centers[j][0]
            dy = centers[i][1] - centers[j][1]
            hi = _half_extent(angles[i], sides[i])
            hj = _half_extent(angles[j], sides[j])
            ox = hi + hj - abs(dx)
            oy = hi + hj - abs(dy)
            if ox > 0 and oy > 0:
                pen += ox * oy
    for i in range(n):
        h = _half_extent(angles[i], sides[i])
        x, y = centers[i]
        pen += max(0.0, h - x) ** 2
        pen += max(0.0, x + h - box) ** 2
        pen += max(0.0, h - y) ** 2
        pen += max(0.0, y + h - box) ** 2
    return pen


def _make_grid(n):
    """Coarse grid producing up to n squares, then fill with tiny squares."""
    k = max(1, math.isqrt(n))
    while k * k > n:
        k -= 1
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    return squares


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    squares = _make_grid(n)

    # Ensure we have exactly n squares; pad with tiny squares in grid gaps.
    k = math.isqrt(n) if math.isqrt(n) * math.isqrt(n) <= n else math.isqrt(n)
    # Recompute grid size used
    kg = max(1, math.isqrt(n))
    while kg * kg > n:
        kg -= 1
    while len(squares) < n:
        # add a small square near centre
        squares.append([0.5, 0.5, 0.0, 0.01])
    squares = squares[:n]

    centers = np.array([[s[0], s[1]] for s in squares])
    angles = np.array([s[2] for s in squares])
    sides = np.array([s[3] for s in squares])

    # Cache angles fixed mostly (axis aligned is near optimal for grids).
    angles = np.zeros(n)

    def unpack(v):
        c = v[: 2 * n].reshape(n, 2)
        s = v[2 * n: 3 * n]
        return c, s

    def objective(v):
        c, s = unpack(v)
        s = np.clip(s, 0.0, 1.0)
        return _overlap_penalty(c, angles, s)

    # Start with slightly shrunk sides to allow feasibility, optimize.
    init = np.concatenate([centers.ravel(), sides])
    scale = 0.98
    init[2 * n: 3 * n] *= scale

    bounds = [(0.0, 1.0)] * (2 * n) + [(0.0, 1.0)] * n

    res = minimize(
        objective,
        init,
        method="L-BFGS-B",
        bounds=bounds,
        options={"maxiter": 400, "ftol": 1e-12, "gtol": 1e-10},
    )

    c, s = unpack(res.x)
    s = np.clip(s, 0.0, 1.0)
    c = np.clip(c, 0.0, 1.0)

    result = []
    for i in range(n):
        result.append((float(c[i][0]), float(c[i][1]), float(angles[i]), float(s[i])))
    return result


# EVOLVE-BLOCK-END
