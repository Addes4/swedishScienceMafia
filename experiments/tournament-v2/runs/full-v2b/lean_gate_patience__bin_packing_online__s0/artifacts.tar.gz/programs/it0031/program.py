# EVOLVE-BLOCK-START
"""Reserve-for-later best fit, scale-aware residual penalty.

Scores bins by fit tightness (small leftover preferred), with:
 - a strong bonus for an exact fill (leftover 0),
 - a smooth, scale-aware penalty for leaving a small unusable residual,
 - a mild preference for reusing non-empty bins rather than opening new ones.
"""
import numpy as np


# --- module-level state (persists across calls) ---
_state = {
    "n": 0,
    "min_seen": 101,
}


def _update_stats(item):
    st = _state
    st["n"] += 1
    if item < st["min_seen"]:
        st["min_seen"] = item


def priority(item, bins):
    _update_stats(item)

    bins = np.asarray(bins)
    leftover = bins - item  # >= 0 for all bins shown (item fits)

    # base: tightness -> smaller leftover is better
    score = -leftover.astype(np.float64)

    # mild bonus for using an existing (non-empty) bin instead of a fresh one
    nonempty = bins < 100
    score += 0.5 * nonempty

    # strong reward for exactly filling a bin
    score += 3.0 * (leftover == 0)

    # smooth, scale-aware penalty for tiny unusable residuals.
    # A residual below the smallest item seen so far can never be filled exactly.
    threshold = max(1, _state["min_seen"])
    # penalty decays smoothly from just under threshold up to threshold
    gap = np.clip(threshold - leftover, 0.0, None)
    score -= 1.5 * gap

    return score
# EVOLVE-BLOCK-END

