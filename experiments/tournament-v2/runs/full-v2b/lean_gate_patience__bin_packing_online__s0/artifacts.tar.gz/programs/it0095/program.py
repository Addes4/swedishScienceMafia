# EVOLVE-BLOCK-START
"""Adaptive smoothed best-fit using online item-size statistics."""
import numpy as np

# Online statistics of arriving item sizes.
_state = {"n": 0, "sum": 0.0, "min_item": 100.0}


def priority(item, bins):
    """Smoothed best-fit: prefer tight fits whose residue stays useful.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in (including unused = 100).
    """
    n = _state["n"] + 1
    _state["n"] = n
    _state["sum"] += item
    if item < _state["min_item"]:
        _state["min_item"] = float(item)

    mean_item = _state["sum"] / n
    # Typical small-item scale: blend observed minimum with a fraction of the mean.
    scale = max(_state["min_item"], 0.25 * mean_item, 1.0)

    b = bins.astype(np.float64)
    leftover = b - item  # >= 0

    # Primary: best fit (prefer smallest non-negative leftover).
    tight = -leftover

    # Residual-utility penalty: a residue much smaller than the typical item
    # scale is likely to become unusable waste; penalize softly.
    small = leftover < scale
    penalty = np.where(small, (scale - leftover) / scale, 0.0)

    # Prefer reusing a non-empty bin over opening a fresh one.
    reuse = np.where(b < 100.0, 1.0, 0.0)

    return tight - 1.5 * penalty + 4.0 * reuse
# EVOLVE-BLOCK-END
