# EVOLVE-BLOCK-START
"""Best fit with a mild fill-bias: prefer tight fits, breaking near-ties toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item          # leftover capacity after placing the item
    full_penalty = bins * 0.05      # small penalty for less-filled bins (larger remaining)
    return -(residual + full_penalty)
# EVOLVE-BLOCK-END

