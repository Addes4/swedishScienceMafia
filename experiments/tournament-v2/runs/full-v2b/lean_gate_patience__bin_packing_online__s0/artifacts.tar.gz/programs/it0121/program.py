# EVOLVE-BLOCK-START
"""Online bin choice: Best-Fit with a light residual-shaping tie-break."""
import numpy as np


def priority(item, bins):
    """Score bins for a Best-Fit style rule with a mild residual shaping term.

    All bins passed in fit the item. We reward small residuals (best-fit) but add a
    tiny deterministic adjustment so that near-empty leftovers are slightly less
    attractive than leftovers that can still host the common small items. This keeps
    best-fit dominant while gently avoiding bins that would become nearly useless.
    """
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item

    # Primary: best-fit => minimize residual.
    score = -residual

    # Mild shaping: penalize leaving a very small nonzero residual (hard to reuse),
    # and give a tiny reward for residuals in a "useful" band for typical items.
    small = (residual > 0) & (residual < 5)
    useful = (residual >= 20) & (residual <= 45)

    score = score - 0.5 * small.astype(np.float64)
    score = score + 0.2 * useful.astype(np.float64)

    # Strong reuse preference: avoid consuming fresh (untouched) bins.
    score = np.where(bins >= 100.0, score - 10000.0, score)

    return score
# EVOLVE-BLOCK-END
