# EVOLVE-BLOCK-START
"""Reserve-for-later best-fit with learned small-item threshold.

Scores bins by tightest fit (small leftover preferred), with a mild bonus for
reusing non-empty bins, an exact-fill reward, and a penalty for leftovers that
fall below a learned "small item" threshold where they are unlikely to be
useful again.
"""
import numpy as np

# --- empirical item statistics tracked across calls ---
_state = {
    "n": 0,
    "mean": 0.0,
    "m2": 0.0,
    "smallest": 101,
    "hist": np.zeros(101, dtype=np.float64),  # counts per integer size
}

# Window (in capacity units) within which we treat fits as "near-tied"
_WINDOW = 2.0
# Default small-item reference before enough data
_SMALL_DEFAULT = 8.0
_SMALL_MIN = 3.0
_SMALL_MAX = 25.0


def _update(item):
    s = _state
    s["n"] += 1
    d = item - s["mean"]
    s["mean"] += d / s["n"]
    s["m2"] += d * (item - s["mean"])
    if item < s["smallest"]:
        s["smallest"] = item
    if 1 <= item <= 100:
        s["hist"][item] += 1.0


def _small_threshold():
    """Low quantile of observed item sizes, used as the 'small item' reference."""
    s = _state
    total = s["hist"].sum()
    if total < 30:
        return _SMALL_DEFAULT
    # 10th percentile of the integer size histogram
    target = 0.10 * total
    c = 0.0
    for sz in range(1, 101):
        c += s["hist"][sz]
        if c >= target:
            t = float(sz)
            break
    else:
        t = _SMALL_DEFAULT
    if t < _SMALL_MIN:
        t = _SMALL_MIN
    if t > _SMALL_MAX:
        t = _SMALL_MAX
    return t


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    bins = np.asarray(bins)
    remaining = bins - item  # leftover capacity if item placed here
    rem_f = remaining.astype(np.float64)

    # Tightest fit dominant.
    score = -rem_f

    # Reuse of non-empty bins.
    score += np.where(bins < 100, 2.0, 0.0)

    # Exact fill strongly preferred.
    score += 4.0 * (remaining == 0)

    # Penalize dead slivers below the learned small-item threshold.
    small = _small_threshold()
    dead = (remaining > 0) & (rem_f < small)
    score -= 3.0 * dead.astype(np.float64)

    # Near-tie window: prefer residuals that are at least the small threshold
    # (reusable later) rather than dead slivers.
    best = score.max()
    near = np.abs(score - best) <= _WINDOW
    reusable = (remaining >= small) & (rem_f > 0)
    score += np.where(near & reusable, 0.5, 0.0)

    _update(item)
    return score
# EVOLVE-BLOCK-END
