# EVOLVE-BLOCK-START
"""Value-of-residue bin packing: prefer tight fits, but score the leftover by the
expected amount of it that future items can actually consume, estimated online."""
import numpy as np

_COUNTS = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL

    _COUNTS[item] += 1.0
    _TOTAL += 1.0

    b = np.asarray(bins, dtype=np.float64)
    leftover = b - float(item)

    total = _TOTAL if _TOTAL > 0 else 1.0
    p = _COUNTS / total  # item-size distribution estimate

    # Expected value of a residue r: approximate the expected amount of r that can
    # be filled by a greedy sequence of future items drawn from the histogram.
    # For each possible residue value r (integer 0..100), do a small greedy fill.
    sizes = np.nonzero(_COUNTS)[0]
    psizes = p[sizes]

    # value[r] = expected usable capacity of a bin with remaining r.
    # Build via backward DP: value[r] = sum_s p_s * (s + value[r-s]) for s<=r,
    # with leftover residue otherwise; approximate the "usable" amount.
    value = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        acc = 0.0
        # expected usable amount if we place one item s (s<=r) into residue r
        for s, ps in zip(sizes, psizes):
            if s > r:
                break
            acc += ps * (s + value[int(r - s)])
        miss = 1.0 - np.sum(psizes[sizes <= r])
        value[r] = acc + miss * 0.0
    # scale value to remaining capacity: value already in "usable capacity" units
    usual = value[np.clip(leftover, 0, 100).astype(np.int64)]

    # Fraction of the leftover that is actually usable.
    reusable = usual / np.maximum(leftover, 1.0)

    # Tightness: scale-invariant preference for small leftover (best-fit flavor).
    tightness = -leftover / (leftover + 20.0)

    exact = (leftover == 0.0).astype(np.float64)
    non_empty = (b < 100.0).astype(np.float64)

    score = tightness + 0.8 * reusable + 0.5 * exact + 0.02 * non_empty
    return score
# EVOLVE-BLOCK-END
