# EVOLVE-BLOCK-START
"""Best-fit with reuse, plus a tiny scrap-avoidance tie-break.

Primary rule: never open a new bin if any used bin can hold the item.
Among used bins, strict best-fit (smallest residual after placement) is best.
We add only a tiny tie-break: a nonzero residual too small to hold even the
smallest recently seen item is slightly worse than a cleaner residual.
Exact fills get a small bonus. All shaping is tiny so best-fit dominates.
"""
import numpy as np

_count = 0
_min_size = 1.0


def _resolve_min(item):
    return item


def _update_stats(item):
    global _count, _min_size
    _count += 1
    if _count == 1:
        _min_size = float(item)
    else:
        # decayed running minimum: tracks the small end of the distribution
        _min_size = min(float(item), _min_size + (float(item) - _min_size) * 0.001)
        if _min_size < 1.0:
            _min_size = 1.0


def priority(item, bins):
    """Return a priority per bin; highest wins."""
    _update_stats(item)

    bins = bins.astype(np.int64)
    residual = bins - item  # >=0 for fitting bins, <0 otherwise
    fits = residual >= 0

    # Used bins have remaining capacity < 100.
    used = bins < 100

    # Base: strongly prefer used bins over empty ones.
    score = used.astype(np.float64) * 1000.0

    # Among used bins, best-fit: prefer smallest residual -> larger score.
    rf = residual.astype(np.float64)
    score += np.where(fits, 100.0 - rf, -1000.0)

    # Tiny exact-fill bonus: closing a bin to exactly 0 is valuable.
    score += np.where(fits & (residual == 0), 0.05, 0.0)

    # Tiny scrap penalty: a nonzero residual smaller than the smallest item
    # we expect to see is unlikely to ever be reused usefully.
    thr = _min_size
    scrap = fits & (residual > 0) & (rf < thr)
    score -= np.where(scrap, 0.02, 0.0)

    return score
# EVOLVE-BLOCK-END
