# EVOLVE-BLOCK-START
"""Best-fit with histogram-supported residue matching.

Score is dominated by tightness (negative post-placement leftover).  A bonus is
added when the resulting leftover equals a size seen often in the online item
stream, since that residue is likely to be matched exactly by a future item of
that size, reducing wasted capacity.  A small non-empty-bin bonus encourages
filling open bins.
"""
import numpy as np

CAP = 100

# Online histogram over item sizes 1..100 (index 0 unused).
_hist = np.zeros(CAP + 1, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _total
    it = int(item)

    _hist[it] += 1.0
    _total += 1.0
    total = _total if _total > 0.0 else 1.0

    b = np.asarray(bins, dtype=np.float64)
    residual = b - it

    # Dominant term: tightest fit preferred.
    score = -residual

    # Bonus when leftover equals a commonly seen size (likely exact match later).
    r_idx = np.clip(np.round(residual).astype(np.int64), 0, CAP)
    freq = _hist[r_idx] / total
    score += freq * 8.0

    # Small exact-fit bonus.
    score += np.where(residual == 0, 3.0, 0.0)

    # Encourage filling already-open bins.
    score += np.where(b < CAP, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
