# EVOLVE-BLOCK-START
"""Online bin choice: Best-Fit primary + residue-match tie-break from online histogram."""
import numpy as np

# Running online histogram of item sizes (1..100), plus count.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    global _HIST, _COUNT

    # Update online histogram with the arriving item.
    _HIST[item] += 1.0
    _COUNT += 1.0

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item

    # Primary: best-fit -> maximize score => minimize residual among used bins.
    score = -residual

    # Residue-match bonus: reward leaving a residual that is a likely future item size.
    # Probability that some future item exactly equals this residual.
    prob = _HIST / _COUNT  # prob[s] ~ P(next item = s)
    # residual is float; clip to integer index range for lookup.
    idx = np.clip(residual.astype(np.int64), 0, 100)
    match = prob[idx]

    # Small bonus; strictly smaller than the unit spacing of best-fit residuals
    # (residuals differ by at least 1 in the relevant cases), so it only breaks
    # ties among equal-residual bins and never overrides tightness.
    score = score + 0.5 * match

    # Strong reuse preference: penalize opening/using a fresh (empty) bin.
    score = np.where(bins >= 100.0, score - 10000.0, score)

    return score
# EVOLVE-BLOCK-END
