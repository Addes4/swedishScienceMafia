# EVOLVE-BLOCK-START
"""Best-Fit that avoids creating residues too small to ever be reused.

score = -(leftover) - WASTE_PENALTY * (0 < leftover < min_item_seen) - NEW_BIN_PENALTY * (empty bin)
"""
import numpy as np

_CAP = 100
_NEW_BIN_PENALTY = 50.0
_WASTE_PENALTY = 30.0

_state = {"min_item": 100}


def priority(item, bins):
    bins = np.asarray(bins)
    if item < _state["min_item"]:
        _state["min_item"] = item
    m = _state["min_item"]

    leftover = bins - item
    score = -leftover.astype(np.float64)

    tiny = (leftover > 0) & (leftover < m)
    score[tiny] -= _WASTE_PENALTY

    empty = bins >= _CAP
    score[empty] -= _NEW_BIN_PENALTY

    return score
# EVOLVE-BLOCK-END
