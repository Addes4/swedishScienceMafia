# EVOLVE-BLOCK-START
"""Sum-of-squares bin packing: choose the bin minimizing the sum of squared
remaining capacities after placing the item. This convex objective naturally
avoids both tiny unusable slivers and leaving large open bins, and is combined
with a histogram-based exact-residue bonus."""
import numpy as np

_COUNTS = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL

    _COUNTS[item] += 1.0
    _TOTAL += 1.0

    b = np.asarray(bins, dtype=np.float64)
    leftover = b - float(item)

    # Sum-of-squares objective: prefer minimizing leftover^2 after placement.
    # Minimizing leftover^2 => maximize -(leftover^2). Normalize by 10000 so
    # the term stays in [-1, 1].
    sos = -(leftover * leftover) / 10000.0

    # Histogram-based bonus: reward leftovers matching common future item sizes.
    total = _TOTAL if _TOTAL > 0 else 1.0
    cum = np.concatenate(([0.0], np.cumsum(_COUNTS)))
    band = np.clip(0.125 * leftover, 4.0, 20.0)
    lo = np.clip(np.floor(leftover - band), 0, 100).astype(np.int64)
    hi = np.clip(np.floor(leftover), 0, 100).astype(np.int64)
    usefulness = (cum[hi + 1] - cum[lo]) / total

    # Exact-fit reward.
    exact = (leftover == 0.0).astype(np.float64)
    # Slight preference to use already-open bins over fresh ones.
    non_empty = (b < 100.0).astype(np.float64)

    score = sos + 0.6 * usefulness + 0.5 * exact + 0.02 * non_empty
    return score
# EVOLVE-BLOCK-END
