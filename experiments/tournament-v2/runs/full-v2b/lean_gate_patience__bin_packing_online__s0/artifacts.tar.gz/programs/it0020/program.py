# EVOLVE-BLOCK-START
"""Reserve-for-later best-fit ranking.

Scores each bin by how well the item fits (tight fits preferred), with a mild
bonus for reusing non-empty bins and a penalty for leaving small gaps that are
unlikely to be useful later given the empirical item-size distribution.
"""
import numpy as np

# --- empirical item statistics tracked across calls ---
_state = {
    "n": 0,
    "mean": 0.0,
    "m2": 0.0,
    "smallest": 101,        # smallest item seen so far
    "smallest_cap": 100,    # tightest cap we saw a small item fill
    "min_fill": 100,        # min residual gap that some later item exactly fit into
}

# Reference "small" threshold. Items at or below this are considered small and
# get extra preference for tightly filling a leftover gap later.
_SMALL = 15


def _update(item):
    """Update running statistics with a newly seen item size."""
    s = _state
    s["n"] += 1
    d = item - s["mean"]
    s["mean"] += d / s["n"]
    s["m2"] += d * (item - s["mean"])
    if item < s["smallest"]:
        s["smallest"] = item


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities (including empty bins = 100), in order.
    """
    bins = np.asarray(bins)
    remaining = bins - item            # leftover capacity if item placed here

    # Tightest fit first: smaller leftover is better.
    tight = -remaining.astype(np.float64)

    # Mild preference for non-empty bins (avoid opening fresh bins needlessly).
    non_empty = (bins < 100)
    reuse_bonus = np.where(non_empty, 2.0, 0.0)

    # Penalize leaving a "bad" small gap: a leftover > 0 that is below the
    # smallest plausible future item. Such gaps tend to be wasted.
    bad_gap = ((remaining > 0) & (remaining < 6)).astype(np.float64)
    gap_penalty = -3.0 * bad_gap

    # Reward exactly filling a bin (leftover zero): perfect tight fit.
    exact_fill = (remaining == 0).astype(np.float64)
    exact_bonus = 4.0 * exact_fill

    score = tight + reuse_bonus + gap_penalty + exact_bonus

    _update(item)
    return score
# EVOLVE-BLOCK-END
