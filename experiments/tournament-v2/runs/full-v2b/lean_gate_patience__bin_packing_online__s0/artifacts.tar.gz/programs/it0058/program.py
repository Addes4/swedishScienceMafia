# EVOLVE-BLOCK-START
"""Reserve-for-later ranker: blend tight fit, gap usability, and bin reuse."""
import numpy as np


class _Stats:
    def __init__(self):
        self.seen = 0
        self.small_count = 0
        self.small_sum = 0
        # running estimate of the low quantile of item sizes
        self.q = 20.0

    def update(self, item):
        self.seen += 1
        if self.seen <= 200 or item < self.q * 1.5:
            # exponential-ish tracking of a low quantile
            self.q += 0.02 * (item - self.q)
            if self.q < 1.0:
                self.q = 1.0


_stats = _Stats()


def priority(item, bins):
    """Score bins: tight fits good, unusable gaps penalized, non-empty bins favored."""
    _stats.update(item)

    rem = bins.astype(np.float64)
    leftover = rem - item

    # tight fit score: smaller leftover is better (best fit)
    tight = 1.0 / (1.0 + leftover)

    # gap usability: a leftover gap that is at least a typical small item is fine;
    # gaps below the empirical small-item scale are wasted space -> penalize.
    small = _stats.q
    usable = leftover / (small + item * 0.05)
    np.clip(usable, 0.0, 1.0, out=usable)

    # reuse bonus: prefer already-used bins (rem < 100) to avoid opening new bins
    used = rem < 100.0

    score = tight * (0.55 + 0.45 * usable)

    # discourage leaving a gap that no future small item can fill
    wasted = (leftover > 0) & (leftover < small * 0.6)
    score -= wasted * 0.35

    # prefer non-empty bins unless the fit is clearly better in an empty bin
    score += used * 0.15

    # among empty bins, don't burn the "best" empty ones excessively: no extra bias,
    # but slightly prefer later empty bins so earlier bins can accumulate odd smalls
    return score
# EVOLVE-BLOCK-END
