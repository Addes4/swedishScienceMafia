# EVOLVE-BLOCK-START
"""Adaptive best-fit with a distribution-aware dead-fragment penalty."""
import numpy as np


class _Stats:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.n = 0.0

    def add(self, size):
        self.hist[size] += 1.0
        self.n += 1.0


_STATE = _Stats()


def priority(item, bins):
    st = _STATE
    st.add(item)

    leftover = (bins - item).astype(np.float64)  # >= 0 for all shown bins

    # Online cumulative distribution of past items.
    n = st.n if st.n > 0 else 1.0
    cum = np.cumsum(st.hist) / n  # cum[k] = P(past item <= k)

    # "Fill probability" of a leftover L: chance a future item lands close to L,
    # i.e. leaves a tiny residue.  Use band [0.7*L, L].  Dead fragments (small
    # but rarely matched) get a low value.
    li = np.clip(leftover.astype(np.int64), 0, 100)
    lo = np.clip((leftover * 0.7).astype(np.int64), 0, 100)
    p_fill = cum[li] - cum[lo]

    # Non-empty bins discouraged from being skipped.
    nonempty = (bins < 100).astype(np.float64)

    # Dominant term: best fit (smallest leftover).  Small bonus for leftovers
    # that a future item can snugly fill; small bonus for reusing open bins.
    score = -leftover + 1.5 * p_fill + 0.4 * nonempty
    return score
# EVOLVE-BLOCK-END
