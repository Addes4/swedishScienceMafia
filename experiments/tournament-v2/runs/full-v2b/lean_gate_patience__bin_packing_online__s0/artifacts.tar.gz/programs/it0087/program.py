# EVOLVE-BLOCK-START
"""Best-Fit with an online small-residue penalty.

score = -(leftover) - NEW_BIN_PENALTY * (bins == capacity)
        - SMALL_RESIDUE_PENALTY * max(0, min_item - leftover)   (for nonempty bins)

Tracks the smallest item seen (and a smoothed estimate) to discourage
leaving residues that are too tiny to ever be filled by a future item.
"""
import numpy as np

_CAP = 100
_NEW_BIN_PENALTY = 50.0
_SMALL_RESIDUE_PENALTY = 1.0

_state = {"min_item": None, "count": 0}


def priority(item, bins):
    bins = np.asarray(bins)

    # Online estimate of the smallest typical item size.
    s = _state
    if s["min_item"] is None:
        s["min_item"] = float(item)
    else:
        # Decaying minimum: adapts if the distribution has rare small items.
        s["count"] += 1
        if item < s["min_item"]:
            s["min_item"] = float(item)
        # Slow upward drift so the estimate tracks the bulk of the distribution.
        s["min_item"] = s["min_item"] + 0.01 * max(0.0, 10.0 - s["min_item"])

    min_item = s["min_item"]

    leftover = (bins - item).astype(np.float64)
    score = -leftover

    empty = bins >= _CAP
    score[empty] -= _NEW_BIN_PENALTY

    # Penalize tiny residues only in nonempty bins.
    tiny = np.maximum(0.0, min_item - leftover)
    score -= _SMALL_RESIDUE_PENALTY * tiny
    score[empty] = -leftover[empty] - _NEW_BIN_PENALTY

    return score
# EVOLVE-BLOCK-END
