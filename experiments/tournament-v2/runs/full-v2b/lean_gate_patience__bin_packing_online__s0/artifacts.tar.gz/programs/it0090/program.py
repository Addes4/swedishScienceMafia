# EVOLVE-BLOCK-START
"""Best-Fit with an empty-bin penalty and an exact-fit bonus.

score = -(leftover) - NEW_BIN_PENALTY*(bins == capacity) + FIT_BONUS/(1+leftover)
"""
import numpy as np

_CAP = 100
_NEW_BIN_PENALTY = 50.0
_FIT_BONUS = 2.0


def priority(item, bins):
    bins = np.asarray(bins)
    leftover = (bins - item).astype(np.float64)
    score = -leftover
    score += _FIT_BONUS / (1.0 + leftover)
    score[bins >= _CAP] -= _NEW_BIN_PENALTY
    return score
# EVOLVE-BLOCK-END
