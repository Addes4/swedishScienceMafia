# EVOLVE-BLOCK-START
"""Residue-utility best fit driven by an online item-size histogram.

The idea: placing an item leaves a residual capacity r.  A residual is
"good" if future items can still pack it tightly (ideally fill it exactly),
and "bad" if it is a scrap too small for any likely future item.  We estimate
this from the empirical item-size distribution seen so far (an online
histogram), scoring each candidate residual by the expected residual capacity
that would end up wasted.  A mild reuse bonus still discourages opening new
bins.
"""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "hist": np.zeros(101, dtype=np.float64),  # counts of item sizes 1..100
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to highest (first on ties)."""
    n = _state["n"]
    hist = _state["hist"]

    if n > 0:
        probs = hist[1:] / n          # probs[s-1] = P(item == s)
        mean_item = _state["sum"] / n
    else:
        # Weak neutral prior (mean ~40).
        probs = np.full(100, 1.0 / 100.0, dtype=np.float64)
        mean_item = 40.0

    # Update statistics with the current (past) item.
    _state["n"] = n + 1
    _state["sum"] += item
    hist[item] += 1.0

    bins_f = bins.astype(np.float64)
    leftover = bins_f - item        # residual after placing (>= 0)
    lo = np.maximum(leftover, 0.0)

    # Smallest item size with non-trivial probability -> below this a residual
    # is (nearly) unusable scrap.
    if n > 0:
        cum = np.cumsum(probs)
        # effective "reachable" small size: 2nd percentile
        s_min = int(np.searchsorted(cum, 0.02)) + 1
    else:
        s_min = 1
    if s_min < 1:
        s_min = 1

    # Probability that some future item fits in the residual (i.e. item <= r).
    idx = np.clip(lo.astype(np.int64), 0, 100)
    fit_prob = np.where(lo > 0, probs[np.clip(idx - 1, 0, 99)], 0.0)

    # Expected wasted capacity beyond the largest single item that fits:
    # approximate by (r - mean_item) when r is comfortably large, small otherwise.
    waste = np.maximum(lo - mean_item, 0.0)

    # Scrap penalty: residuals in (0, s_min) are essentially unreusable.
    scrap = ((lo > 0.0) & (lo < s_min)).astype(np.float64)

    # Tight-fit base: smaller residual is better.
    tight = -leftover

    # Reward exact fills strongly.
    perfect = np.where(lo <= 0.0, 6.0, 0.0)

    # Penalize expected waste and unusable scraps.
    penalty = 1.2 * waste + 3.0 * scrap * (1.0 - fit_prob)

    # Mild reuse bonus: discourage opening brand-new bins.
    is_new = bins_f >= 100.0
    reuse_bonus = np.where(is_new, -6.0, 0.0)

    return tight - penalty + perfect + reuse_bonus
# EVOLVE-BLOCK-END
