# EVOLVE-BLOCK-START
"""Residue-value ranker using a fixed Weibull-shaped prior over future item sizes."""
import numpy as np

# Prior CDF over integer item sizes 0..100 for a Weibull-shaped distribution
# with mean ~40 (shape k=2, scale ~45 truncated to [1,100]). Precomputed.
_sizes = np.arange(0, 101, dtype=np.float64)


def _build_prior():
    k = 2.0
    scale = 45.0
    # Weibull pdf on sizes 1..100
    pdf = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        x = s / scale
        pdf[s] = (k / scale) * (x ** (k - 1.0)) * np.exp(-(x ** k))
    total = pdf.sum()
    if total <= 0:
        pdf = np.ones(101, dtype=np.float64)
        total = pdf.sum()
    pdf = pdf / total
    cdf = np.cumsum(pdf)
    cdf = np.clip(cdf, 0.0, 1.0)
    return pdf, cdf


_prior_pdf, _prior_cdf = _build_prior()


def priority(item, bins):
    """Score bins by best-fit tightness, rewarding leftovers a future item fits snugly."""
    n = bins.shape[0] if hasattr(bins, "shape") else len(bins)

    leftover = np.asarray(bins, dtype=np.float64) - float(item)

    # Probability that a single future item fits in the leftover (survival prob).
    idx = np.clip(leftover.astype(np.int64), 0, 100)
    p_fit = 1.0 - _prior_cdf[idx]  # P(next item <= leftover)

    # Probability the leftover is a "good" snug size (next item fills most of it):
    # use fraction of mass concentrated near the leftover.
    snug = np.zeros_like(leftover)
    for band in (0, 1, 2, 5):
        lo = np.clip(idx - band, 0, 100)
        snug += (_prior_cdf[idx] - _prior_cdf[lo])

    # Base: prefer small leftover (best fit).
    score = -leftover

    # Reward leftovers usable by a single future item.
    score += 8.0 * p_fit

    # Reward snug residuals.
    score += 4.0 * snug

    # Exact fit: dominant bonus.
    score += (leftover == 0).astype(np.float64) * 30.0

    # Small preference for non-empty bins to avoid opening new bins.
    nonempty = leftover < 100.0 - 1e-9
    score += nonempty.astype(np.float64) * 0.3

    return score
# EVOLVE-BLOCK-END

