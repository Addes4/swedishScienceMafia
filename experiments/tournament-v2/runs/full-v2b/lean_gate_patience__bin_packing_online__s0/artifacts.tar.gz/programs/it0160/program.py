# EVOLVE-BLOCK-START
"""Best-fit ranker for online bin packing.

Place each item into the bin whose remaining capacity is smallest while still
fitting (best fit). Exact fits naturally win. Ties go to the earliest bin.
This is the classic best-fit heuristic, which is strong for the given
Weibull-shaped item distribution.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    bins = np.asarray(bins, dtype=np.float64)
    leftover = bins - float(item)          # >= 0 for every shown bin

    # Best fit: smaller post-placement leftover -> higher score.
    # Destroy ties deterministically but keep best-fit dominant.
    return -leftover
# EVOLVE-BLOCK-END
