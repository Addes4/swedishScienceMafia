# EVOLVE-BLOCK-START
"""Best-fit with a strict open-bin preference.

The dominant term is tightness (negative leftover). Among fitting non-empty bins we
always want the tightest, so best-fit ordering is preserved. Opening a fresh bin
(remaining == 100) is penalized so we only do it when it strictly helps, and an
exact fit is strongly rewarded.

To keep the rule robust we scale the penalties by small constants so tightness
(the leading term) always dominates the tie-breaking adjustments.
"""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
}


def _update(item):
    _state["n"] += 1
    _state["sum"] += item


def priority(item, bins):
    _update(item)

    n = _state["n"]
    mean = _state["sum"] / n

    rem = bins.astype(np.float64)
    leftover = rem - item  # >= 0 for fitting bins

    # Primary: tightest fit (most negative leftover wins).
    score = -leftover

    # Penalize opening a fresh bin (remaining == 100) so we pack into already
    # opened bins unless a fresh bin gives a markedly tighter fit. Scale by mean
    # so the penalty stays meaningful but does not overturn tightness ordering.
    fresh = (rem >= 100.0).astype(np.float64)
    score -= fresh * (mean * 0.2)

    # Exact fit bonus.
    score += np.where(leftover == 0, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
