# EVOLVE-BLOCK-START
"""Online residual-value ranker: tightness plus expected reuse of leftover."""
import numpy as np


class _Stats:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.n = 0.0
        self.s = 0.0

    def add(self, size):
        self.hist[size] += 1.0
        self.n += 1.0
        self.s += size

    @property
    def mean(self):
        return self.s / self.n if self.n > 0 else 40.0


_STATE = _Stats()


def priority(item, bins):
    st = _STATE
    st.add(item)

    leftover = bins - item  # >= 0 for all shown bins
    L = leftover.astype(np.float64)

    # Best-fit tightness: prefer small leftover.
    tight = -L

    # Expected usefulness of the leftover: how many typical future items
    # (mean mu) it could still absorb. A leftover near a multiple of the
    # running mean is more likely to be filled without waste; a tiny leftover
    # is a dead fragment. Model usefulness as the fractional "coverage":
    #   frac = (L mod mu) / mu  -> how far past a mean-item boundary we are.
    # We want leftover to be just above the boundary (small waste ~ (mu-frac)).
    mu = st.mean
    if mu < 1.0:
        mu = 1.0

    # Waste if we next place a typical item: nearest-fit waste.
    # For leftover L, the residual after fitting floor(L/mu) mean-items.
    k = np.floor(L / mu)
    rem = L - k * mu                # residual capacity after using k mean items
    # small residual = good (tight fill), large residual wastes a slot
    reuse = -np.abs(rem - mu)       # prefer rem close to a full mean-item slot

    # Exact fit bonus.
    exact = (L == 0).astype(np.float64)

    # Discourage opening a fresh bin.
    nonempty = (bins < 100).astype(np.float64)

    score = tight + 1.2 * reuse + 3.0 * exact + 0.5 * nonempty
    return score
# EVOLVE-BLOCK-END

