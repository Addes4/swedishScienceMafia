# EVOLVE-BLOCK-START
"""Score bins by expected future fillability of the leftover."""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        # coarse histogram over sizes 1..100 (index = size)
        self.hist = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.n += 1
        self.hist[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    leftover = bins - item  # >= 0 by contract
    leftover = leftover.astype(np.float64)

    # Empirical size density: probability an item of size s arrives (>=1 smoothing).
    h = _stats.hist
    total = h.sum() + 1.0
    dens = (h + 0.5) / total  # smoothed density per exact size

    # Base: strong tight-fit preference.
    base = -leftover

    # Future-fillability bonus: if the residue equals a size that
    # empirically appears, it can likely be exactly filled later.
    lo = np.maximum(leftover.astype(np.int64), 0)
    lo = np.minimum(lo, 100)
    fill = dens[lo] * 400.0

    # Penalty for very small residues that are hard to use.
    tiny_pen = np.where(leftover < 5, (5.0 - leftover) * 1.5, 0.0)

    # Reuse bias: prefer already-open bins.
    nonempty = (bins < 100).astype(np.float64)
    reuse = nonempty * 2.0

    # Bonus for perfect fit.
    perfect = np.where(leftover < 0.5, 3.0, 0.0)

    return base + reuse + perfect + fill - tiny_pen
# EVOLVE-BLOCK-END
