# EVOLVE-BLOCK-START
"""Online value-function bin ranker.

For each candidate bin we estimate the probability that its post-placement
leftover is "dead" (no future single item can fit into it), using the online
empirical item-size CDF.  We prefer bins that fit tightly and whose leftover is
likely to be consumable by a future item.  A smooth preference toward larger
leftovers ranks reused bins ahead of fresh empty bins.
"""
import numpy as np

_CAP = 100
_HIST_MAX = 101
_hist = np.zeros(_HIST_MAX, dtype=np.float64)
_total = 0.0
_n = 0

_last_update = -1
_cdf = None


def _rebuild():
    global _cdf
    if _n == 0:
        p = np.full(_HIST_MAX, 1.0 / _CAP, dtype=np.float64)
        p[0] = 0.0
    else:
        p = _hist / _n
    # cdf[r] = P(future item <= r).  cumsum includes index 0 (=0), so shift.
    c = np.cumsum(p)
    _cdf = c


def _ensure():
    global _last_update
    if _last_update != _n:
        _rebuild()
        _last_update = _n


def priority(item, bins):
    global _n
    _hist[item] += 1.0
    _total += item
    _n += 1
    _ensure()

    b = bins.astype(np.float64)
    leftover = b - item
    np.clip(leftover, 0.0, _CAP, out=leftover)

    idx = leftover.astype(np.int64)
    # probability leftover is "dead": no future item fits into it
    dead = 1.0 - _cdf[idx]

    # reward larger leftovers (more reusable) as a smooth tie-break, and
    # penalize opening fresh empty bins very slightly.
    reuse = np.where(b < _CAP, leftover * 1e-3, -0.5)

    return -dead + reuse
# EVOLVE-BLOCK-END
