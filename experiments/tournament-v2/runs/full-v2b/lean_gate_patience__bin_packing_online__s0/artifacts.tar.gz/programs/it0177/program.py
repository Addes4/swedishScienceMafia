# EVOLVE-BLOCK-START
"""Residue-value ranker: tight fits, graded by the expected fill value of the leftover."""
import numpy as np


class _State:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)  # histogram of past item sizes
        self.n = 0.0
        self.total = 0.0

    def mean(self):
        return self.total / self.n if self.n > 0 else 40.0


_STATE = _State()


def priority(item, bins):
    st = _STATE
    leftover = bins - item  # post-placement remaining capacity, >= 0

    if st.n > 0:
        # pmf of past item sizes (index 0..100)
        pmf = st.counts / st.n
        # Expected fraction of a random future item that "fits snugly" into a leftover s:
        # sum over sizes x of pmf[x] * indicator(x <= s).  Grade by how much of the
        # distribution is covered, so larger reusable leftovers earn a smooth bonus.
        coverage = np.cumsum(pmf)  # coverage[s] = P(item <= s)
        useful = coverage[leftover]
        # Expected expected-fill value: also reward leftovers that can hold the
        # more common (higher-probability) item sizes, not just a binary fit prob.
        fill_val = np.zeros_like(leftover, dtype=np.float64)
        # accumulate E[x * 1{x<=s}] / mean = estimated usable fraction of capacity
        csum_x = np.cumsum(pmf * np.arange(101))  # sum_{x<=s} x*pmf[x]
        mean_size = st.mean()
        with np.errstate(divide="ignore", invalid="ignore"):
            fill_val = np.where(mean_size > 0, csum_x[leftover] / mean_size, 0.0)
        graded = 0.6 * useful + 0.4 * np.clip(fill_val, 0.0, 1.0)
    else:
        graded = np.zeros_like(leftover, dtype=np.float64)

    mean_size = st.mean()

    # Tightness: prefer small leftovers (negative leftover).
    score = -leftover.astype(np.float64)

    # Graded usefulness bonus.
    score += 6.0 * graded

    # Exact fit bonus.
    score += 8.0 * (leftover == 0)

    # Unsafe-band penalty: leftover very small but nonzero tends to become dead space.
    unsafe = (leftover > 0) & (leftover < max(3.0, mean_size * 0.25))
    score -= 5.0 * unsafe

    # Mild bonus for already-non-empty bins to discourage opening new bins.
    score += 0.5 * (bins < 100)

    # Update online statistics with the arriving item.
    st.counts[item] += 1.0
    st.n += 1.0
    st.total += item

    return score
# EVOLVE-BLOCK-END
