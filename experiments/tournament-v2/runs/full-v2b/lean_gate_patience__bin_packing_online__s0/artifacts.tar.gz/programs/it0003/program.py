# EVOLVE-BLOCK-START
"""Best fit with a learned bias against stranding tiny residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing item
    # Prefer tighter fits (smaller residual) in general.
    base = -(residual * 1000.0)
    # Penalize tiny nonzero residuals: such bins become hard to reuse,
    # so push the item to a bin leaving a slightly larger usable gap.
    tiny = (residual > 0) & (residual <= 4)
    penalty = tiny.astype(np.float64) * 400.0
    # Bonus for exactly filling a bin.
    exact = (residual == 0).astype(np.float64) * 300.0
    return base - penalty + exact
# EVOLVE-BLOCK-END

