# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware tie-break: tight fits, then resid fillability."""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),
    "total": 0.0,
    "count": 0,
}


def _update_stats(item):
    _state["hist"][int(item)] += 1.0
    _state["count"] += 1
    _state["total"] += 1.0
    if _state["count"] > 4000:
        # gentle decay keeps recent distribution, bounded cost
        _state["hist"] *= 0.5
        _state["total"] *= 0.5
        _state["count"] = 2000


def priority(item, bins):
    _update_stats(item)

    leftover = bins.astype(np.float64) - float(item)

    # dominant term: tightest fit
    score = -leftover

    # tie-break: among near-equal leftovers, prefer residual that matches
    # a commonly occurring item size (so the scrap is likely fillable later).
    hist = _state["hist"]
    tot = _state["total"]
    if tot > 0:
        # probability mass of item sizes at/under the residual
        # (residual r is "fillable" if common sizes <= r exist)
        cum = np.cumsum(hist)  # cum[s] = mass of sizes <= s
        r = np.clip(leftover, 0, 100).astype(np.int64)
        # mass strictly <= residual (as a set of fillable sizes)
        fillable = cum[r] / tot  # in [0,1]
        # prefer residuals with high fillable mass, but only as a small tie-break
        score += 1e-3 * fillable
        # explicit small bonus for residuals that are NOT awkward tiny scraps
        score += np.where(leftover < 1.0, 0.0, 1e-4)

    return score
# EVOLVE-BLOCK-END
