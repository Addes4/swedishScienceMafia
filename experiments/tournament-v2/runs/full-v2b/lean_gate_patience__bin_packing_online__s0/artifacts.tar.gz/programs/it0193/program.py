import numpy as np


class _Stats:
    """Online histogram of item sizes to measure residue productivity."""
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def add(self, item):
        self.counts[int(item)] += 1.0
        self.total += 1.0


_stats = _Stats()


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.float64)
    leftovers = bins - item

    scores = -leftovers

    usable = leftovers >= 1
    if _stats.total > 0.0:
        # Probability mass of past items that exactly equal each candidate residue,
        # i.e. how likely the leftover is to be filled exactly next.
        mass = _stats.counts / _stats.total
        r_int = np.clip(leftovers.astype(np.int64), 0, 100)
        exact_mass = mass[r_int]
        # Broader usefulness: fraction of items that fit at all.
        cum = np.concatenate(([0.0], np.cumsum(mass)))
        fit_prob = cum[r_int + 1]
        scores = scores + 3.0 * exact_mass * usable + 0.5 * fit_prob * usable

    scores = scores + np.where(leftovers == 0, 1e6, 0.0)
    scores = scores + 0.01 * (bins < 100.0)

    _stats.add(item)
    return scores
