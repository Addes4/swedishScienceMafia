# EVOLVE-BLOCK-START
"""
Adaptive best-fit with gap-utility ranking.

The item is placed into the bin where it fits most tightly, but among close
fits we prefer placements that leave remaining capacity which is less likely
to become unusable.  We learn the empirical item-size distribution online and
score a candidate bin by how "useful" its post-placement residual capacity is:
a residual that can still hold common future items is good, while a residual
too small for most items is penalized.
"""
import numpy as np


# ---------- online empirical distribution ----------
class _Stats:
    def __init__(self):
        # histogram over item sizes 1..100 (index 0 unused)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0
        # precomputed for utility lookup (refreshed lazily)
        self._util = None
        self._util_count = -1

    def add(self, size):
        self.hist[size] += 1.0
        self.count += 1.0
        self._util = None  # invalidate

    def utility_table(self, n_bins_seen):
        """
        For each possible remaining capacity r (0..100) return a score in [0,1]
        measuring how many typical future items can still fit in r.
        Uses a weighted prob that the next few draws fit.
        """
        if self._util is not None and self._util_count == self.count and self._util_nb == n_bins_seen:
            return self._util

        if self.count < 5.0:
            p = np.full(101, 1.0 / 100.0)
        else:
            p = self.hist / self.count  # p[s] prob of size s

        # k_eff: expected number of future items arriving per bin.  With ~5000
        # items over a growing set of bins, a typical bin sees a handful of items.
        # Use a soft length scale based on average load.
        avg_items_per_bin = 5000.0 / max(n_bins_seen, 1.0)
        k_eff = max(1.0, min(6.0, avg_items_per_bin))

        # probability that at least one of the next k_eff items fits in r
        # approx: 1 - (sum_{s>r} p[s])^k_eff
        unfit = np.zeros(101)
        # cumulative from the top
        cdf = np.cumsum(p)  # P(size <= x)
        unfit = 1.0 - cdf  # P(size > x)
        util = 1.0 - np.power(np.clip(unfit, 0.0, 1.0), k_eff)
        util[0] = 0.0
        self._util = util
        self._util_count = self.count
        self._util_nb = n_bins_seen
        return util


_STATS = _Stats()


def priority(item, bins):
    """Rank bins: tight fit plus utility of residual capacity."""
    _STATS.add(int(item))

    # number of bins that currently have been "opened" (capacity < 100)
    used = int(np.count_nonzero(bins < 100))
    util = _STATS.utility_table(used)

    residual = bins - item  # >= 0 guaranteed by harness

    # Best-fit term: strongly prefer tight fits (small residual).
    # Use a smooth, monotone decreasing function of residual.
    tight = -residual.astype(np.float64)

    # Utility term: residual that can host typical future items is rewarded.
    # Scale small relative to tightness so we stay near best-fit but break ties
    # toward more reusable bins.
    u = util[residual]

    # Mild preference for using already-open bins over fresh ones reduces
    # proliferation of nearly-empty bins.
    is_fresh = (bins == 100) & (item == 100) | (bins == 100)
    fresh_penalty = np.where(bins == 100, -0.05, 0.0)

    score = tight + 2.0 * u + fresh_penalty
    return score
# EVOLVE-BLOCK-END
