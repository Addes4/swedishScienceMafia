# EVOLVE-BLOCK-START
"""Reserve-for-later best fit.

Rank bins by how tightly the item fits, but:
  * give a bonus to already-used bins (avoid opening new ones),
  * penalize leaving a gap that is too small to hold a typical future item,
  * track running statistics of past item sizes to estimate typical sizes.
"""
import numpy as np

# Empirical state across calls (never sees future items).
_STATE = {
    "n": 0,
    "sum": 0.0,
    "min_seen": 101,
}


def _update_state(item):
    _STATE["n"] += 1
    _STATE["sum"] += item
    if item < _STATE["min_seen"]:
        _STATE["min_seen"] = item


def priority(item, bins):
    _update_state(item)

    bins = np.asarray(bins, dtype=np.int64)
    n = _STATE["n"]
    mean_item = (_STATE["sum"] / n) if n > 0 else 40.0
    # Typical small item threshold: roughly the lower part of the distribution.
    small = max(1.0, min(10.0, _STATE["min_seen"] if _STATE["min_seen"] <= 100 else 1))

    remainder = bins - item  # free space left if item goes here; >=0 by contract

    # Base: best fit -> prefer small remainder (tight fit).
    score = -(remainder.astype(np.float64))

    # Bonus for using an existing (non-full) bin rather than a fresh one.
    # Fresh bins have remaining capacity 100.
    used = bins < 100
    score += np.where(used, 1.5, 0.0)

    # Penalize creating small unusable gaps: if the leftover is positive but
    # tiny, it will likely be wasted, so avoid it.
    wasteful = (remainder > 0) & (remainder < small)
    score -= np.where(wasteful, 2.0, 0.0)

    # Mild preference for leaving gaps near a typical item size, so the gap
    # can be filled later.
    ideal = remainder - mean_item
    score -= np.where(remainder > 0, np.abs(ideal) * 0.05, 0.0)

    return score
# EVOLVE-BLOCK-END
