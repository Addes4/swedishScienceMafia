# EVOLVE-BLOCK-START
"""Value-of-residue online bin choice with a fixed, well-calibrated prior.

Items are drawn from a known Weibull-shaped distribution (mean ~40). Instead of estimating
the item-size CDF online from noisy early samples, we use a fixed prior CDF over sizes 1..100
built to approximate that distribution. For each bin we compute the post-placement leftover
and score it by tightness (prefer small leftover) plus a bonus proportional to the probability
that a future item can fit into that leftover (a convex function of the prior CDF), and an
extra bonus for exact fits. Exact fits dominate; otherwise reusable residues are favored over
dead-zone residues and fresh empty bins.
"""
import numpy as np

# Fixed prior over item sizes 1..100 approximating a Weibull-shaped distribution with mean ~40.
# We build it once as a plain numpy array of probabilities.
def _build_prior():
    x = np.arange(1, 101, dtype=np.float64)
    # Weibull(shape=1.8, scale~45) roughly matches mean ~40 shape; normalize to a pmf.
    k = 1.8
    lam = 45.0
    pdf = (k / lam) * (x / lam) ** (k - 1.0) * np.exp(-(x / lam) ** k)
    pdf = np.clip(pdf, 1e-9, None)
    return pdf / pdf.sum()

_PRIOR = _build_prior()
_CDF = np.concatenate(([0.0], np.cumsum(_PRIOR)))  # CDF[i] = P(item <= i), indices 0..100

_ALPHA = 30.0      # weight for residue usefulness
_PERFECT = 60.0    # bonus for an exact (zero-leftover) fit
_POW = 2.0         # convexity of the usefulness term


def priority(item, bins):
    """Return a score for every bin; item goes to the highest score (first on ties)."""
    leftover = bins - item  # numpy int64 array, >= 0 for every bin shown

    idx = np.clip(leftover, 0, 100).astype(np.int64)
    usefulness = _CDF[idx]
    if _POW != 1.0:
        usefulness = usefulness ** _POW

    score = -leftover.astype(np.float64) + _ALPHA * usefulness
    score[leftover == 0] += _PERFECT

    return score
# EVOLVE-BLOCK-END
