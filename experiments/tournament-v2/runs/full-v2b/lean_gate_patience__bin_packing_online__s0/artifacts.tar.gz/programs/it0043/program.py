# EVOLVE-BLOCK-START
"""Distribution-aware best-fit ranker.

Primary signal is best fit (small leftover), but residuals are scored by the
empirical probability that a future item will exactly fill or nearly fill the
remaining space, estimated from an online histogram of seen item sizes.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.hist = np.zeros(101, dtype=np.float64)

    def add(self, x):
        self.n += 1
        if 1 <= x <= 100:
            self.hist[x] += 1.0

    def prob_mass(self, lo, hi):
        """Fraction of seen items in [lo, hi]."""
        if self.n < 30:
            return 0.0
        lo = max(1, int(lo))
        hi = min(100, int(hi))
        if hi < lo:
            return 0.0
        return self.hist[lo:hi + 1].sum() / self.n


_STATS = _Stats()


def priority(item, bins):
    _STATS.add(item)

    cap = bins.astype(np.float64)
    leftover = cap - item

    # Best-fit dominant: strong negative reward for bigger leftover.
    score = -2.0 * leftover

    # Reward residuals that a future item is likely to fill exactly.
    # Probability that some future item equals the leftover (approx).
    uniq = np.unique(leftover[leftover >= 1])
    if uniq.size:
        for u in uniq:
            ui = int(u)
            p = _STATS.prob_mass(ui, ui)
            if p > 0:
                mask = (leftover == u)
                score[mask] += 6.0 * p

    # Small bonus for reusing already-open bins.
    score += np.where(cap < 100.0, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
