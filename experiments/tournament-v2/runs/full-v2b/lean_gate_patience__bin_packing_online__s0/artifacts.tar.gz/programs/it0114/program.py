# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with open-bin reuse and a residue-shape guard.

The primary signal is strict best-fit (least leftover after placing the item),
which is the principled online rule. On top of it we (a) strictly prefer reusing
any open bin over opening a fresh one, and (b) among equally-tight fits prefer
the bin with the larger current remaining capacity, keeping very tight bins
available for exact small-item fits later. This is the classic
best-fit-with-reuse rule and avoids the fragile residue-target heuristics that
tended to hurt performance.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0

    def update(self, item):
        self.n += 1.0
        self.sum += item

    @property
    def mean(self):
        if self.n >= 1.0:
            return self.sum / self.n
        return 40.0


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    b = bins.astype(np.float64)
    unused = b >= 100.0

    # Post-placement residue: smaller is better (strict best-fit).
    resid = b - float(item)

    # Primary: strict best-fit. Scale so 1 unit of residue ~ 0.01 score.
    fit = -resid / 100.0

    # Secondary: among equally tight bins, prefer the one with more room left,
    # preserving very tight bins for future exact fits. Small weight so it only
    # acts as a tie-break unless residues differ by a negligible amount.
    room = b / 100.0

    # Strictly prefer reusing a non-empty bin over opening a fresh one.
    reuse = np.where(unused, 0.0, 1.0)

    score = fit + 0.01 * room + 0.5 * reuse

    return score
# EVOLVE-BLOCK-END
