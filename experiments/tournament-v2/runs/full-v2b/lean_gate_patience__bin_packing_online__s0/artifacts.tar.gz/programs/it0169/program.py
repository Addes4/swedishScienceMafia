# EVOLVE-BLOCK-START
"""Residue-utility ranker: tightness plus online usefulness of the leftover."""
import numpy as np


class _Stats:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.n = 0.0

    def add(self, size):
        self.hist[size] += 1.0
        self.n += 1.0

    def update(self, size):
        self.add(size)
        return self


_STATE = _Stats()


def priority(item, bins):
    # Update online item histogram with the current item.
    st = _STATE
    st.add(item)

    leftover = bins - item  # >= 0 for all shown bins

    # Tightness: prefer small leftover (best fit).
    tight = -leftover.astype(np.float64)

    # Usefulness of a leftover L: probability that a future item's size is
    # close to L (i.e., would leave a very small residue). We approximate by
    # the empirical count of past items in a band just below/at L, weighted
    # by snugness. Build cumulative distribution for small sizes.
    hist = st.hist
    n = st.n if st.n > 0 else 1.0
    cum = np.cumsum(hist) / n  # cum[k] = P(past item <= k)

    L = leftover
    # Probability that a future item fits with residue <= ~0, i.e. fits snugly
    # into leftover: roughly P(item in [L*0.5, L]) approximating snug fit.
    lo = np.maximum((L * 0.5).astype(np.int64), 0)
    hi = np.minimum(L.astype(np.int64), 100)
    # clamp indices
    lo = np.clip(lo, 0, 100)
    hi = np.clip(hi, 0, 100)
    p_snug = cum[hi] - cum[lo]

    # Exact fit bonus
    exact = (L == 0).astype(np.float64)

    # Bonus for already-non-empty bins (remaining < 100) to discourage new bins.
    nonempty = (bins < 100).astype(np.float64)

    # Score: strong tightness priority, plus usefulness of residue, plus small bonuses.
    score = tight + 2.0 * p_snug + 3.0 * exact + 0.5 * nonempty
    return score
# EVOLVE-BLOCK-END
