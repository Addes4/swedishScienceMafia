# EVOLVE-BLOCK-START
"""Best-fit core with adaptive anti-new-bin bias and a dead-zone residual penalty."""
import numpy as np

_STATE = {"n": 0, "sum": 0.0}


def priority(item, bins):
    bins = np.asarray(bins)

    st = _STATE
    st["n"] += 1
    st["sum"] += item
    mean = st["sum"] / st["n"]

    leftover = bins - item  # remaining capacity after placing the item

    # Best fit: prefer the tightest fit (smallest leftover).
    score = -leftover.astype(np.float64)

    # Penalty for residuals in the "dead zone": nonzero but too small to be
    # reliably filled by a later typical item. Keeps bins near-full instead.
    threshold = min(mean, 30.0)
    dead = (leftover > 0) & (leftover < threshold)
    score -= np.where(dead, (threshold - leftover) * 0.15, 0.0)

    # Adaptive anti-new-bin bias: discourage opening a brand-new bin, but less
    # so when even the best existing fit leaves a large gap (poor packing).
    is_new = bins >= 100
    existing = ~is_new
    if existing.any():
        best_existing_leftover = leftover[existing].min()
    else:
        best_existing_leftover = 100.0
    # Bias shrinks as the best available fit gets worse (bigger leftover).
    bias = 3.0 + 0.20 * max(best_existing_leftover, 0.0)
    bias = min(bias, 18.0)
    score -= np.where(is_new, bias, 0.0)

    return score


def _reset():
    _STATE["n"] = 0
    _STATE["sum"] = 0.0
# EVOLVE-BLOCK-END
