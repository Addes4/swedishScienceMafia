# EVOLVE-BLOCK-START
"""Residue-hazard best fit: prefer tight fits, penalize leftovers that are too small
to be useful for likely future items, and mildly favor reusing non-empty bins."""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.small = 0  # count of items <= 25

    def update(self, item):
        self.n += 1
        self.sum += item
        if item <= 25:
            self.small += 1

    def mean(self):
        return self.sum / self.n if self.n else 40.0

    def small_frac(self):
        return self.small / self.n if self.n else 0.25


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)
    mean = _stats.mean()
    sf = _stats.small_frac()

    # "Useful item size" threshold: leftovers below this are unlikely to be
    # well-filled by a typical future item, so avoid creating them.
    # Blend tracked mean with a smallness estimate.
    useful = 0.55 * mean + 0.45 * (1.0 - sf) * 25.0
    if useful < 15.0:
        useful = 15.0
    if useful > 45.0:
        useful = 45.0

    # leftover after placing item in each bin
    leftover = bins - item

    # Base: tighter fit is better (more negative leftover -> lower score, so negate)
    base = -(leftover.astype(np.float64))

    # Penalty when leftover lands in the unsafe small band (0 <= leftover < useful).
    unsafe = np.where((leftover >= 0) & (leftover < useful), useful - leftover, 0.0)
    # Scale penalty so it meaningfully outweighs tightness differences.
    penalty = 1.8 * unsafe

    # Mild bonus for reusing non-empty bins (ones that don't have full capacity).
    reuse = np.where(bins < 100, 1.5, 0.0)

    return base - penalty + reuse
# EVOLVE-BLOCK-END
