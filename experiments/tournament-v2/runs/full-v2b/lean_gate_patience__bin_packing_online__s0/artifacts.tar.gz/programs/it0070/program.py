# EVOLVE-BLOCK-START
"""Best-fit with a cap on small, likely-unusable residual gaps."""
import numpy as np

_stats = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Score each candidate bin; highest wins (ties -> first).

    item: integer size 1..100.
    bins: numpy int64 remaining capacities of bins the item fits in, in bin order.
    """
    s = _stats
    s["n"] += 1
    s["sum"] += item
    mean = s["sum"] / s["n"]

    leftover = (bins - item).astype(np.float64)

    # Reward tight fit (small leftover).
    score = -leftover

    # Mildly prefer filling existing bins over opening unused ones.
    is_new = (bins == 100) & (item < 100)
    score -= is_new.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
