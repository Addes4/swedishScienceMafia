# EVOLVE-BLOCK-START
"""Value-of-residue ranker for online bin packing.

Score = best-fit tightness + reward for residuals that are likely to be
exactly consumable by one future item OR by a sum of two future items
(estimated from a self-convolution of the observed size histogram).
"""
import numpy as np


# ---------------------------------------------------------------- state
_hist = np.zeros(101, dtype=np.float64)      # counts of past item sizes
_n_items = 0

_SIZES = np.arange(101, dtype=np.float64)
_PAIR = None      # lazily computed pair-sum distribution (indices 0..200)
_PAIR_N = -1      # n_items at which _PAIR was computed


def _pair_dist():
    """Distribution over sums of two independent item sizes (0..200),
    estimated from the current histogram (with a uniform smoothing prior)."""
    h = _hist.copy()
    h[0] = 0.0
    if h.sum() <= 0:
        h = np.ones(101, dtype=np.float64)
        h[0] = 0.0
    # light smoothing so pair distribution is not too spiky
    h = h + 0.5
    h[0] = 0.0
    h /= h.sum()
    # convolution over sizes 1..100 -> sums 2..200
    conv = np.convolve(h[1:], h[1:])          # length 199, sums 2..200
    out = np.zeros(201, dtype=np.float64)
    out[2:201] = conv
    return out


def priority(item, bins):
    global _n_items, _PAIR, _PAIR_N

    bins = np.asarray(bins, dtype=np.float64)
    leftover = bins - float(item)
    r = np.clip(leftover, 0, None)

    tight = -leftover

    if _n_items == 0:
        useful = np.minimum(1.0, r / 50.0)
        pair = np.zeros_like(r)
    else:
        total = float(_n_items)
        cum = np.cumsum(_hist)
        r_int = r.astype(int)
        p_fit = cum[r_int] / total
        weighted = np.concatenate(([0.0], np.cumsum(_hist * _SIZES)))
        sums = weighted[r_int]
        cnts = cum[r_int]
        with np.errstate(divide="ignore", invalid="ignore"):
            fill = np.where(cnts > 0, sums / (cnts * np.maximum(r_int, 1)), 0.0)
        useful = p_fit * fill

        # reuse-by-two: probability a residual equals a sum of two items
        if _PAIR is None or _n_items - _PAIR_N >= 250:
            _PAIR = _pair_dist()
            _PAIR_N = _n_items
        pair = _PAIR[r_int]

    exact = (r == 0).astype(np.float64)
    empty = (bins == 100.0)
    nonempty_bonus = np.where(empty, 0.0, 1.0)

    score = (
        2.0 * tight
        + 40.0 * useful
        + 25.0 * pair
        + 30.0 * exact
        + 3.0 * nonempty_bonus
    )

    _hist[item] += 1.0
    _n_items += 1

    return score
# EVOLVE-BLOCK-END
