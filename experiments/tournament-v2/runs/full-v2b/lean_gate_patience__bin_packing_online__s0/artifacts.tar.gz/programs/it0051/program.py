# EVOLVE-BLOCK-START
"""Two-tier bin choice: exact-fit preference, else probability residual matches a common size."""
import numpy as np

_H = np.zeros(101, dtype=np.float64)
_N = 0.0


def priority(item, bins):
    global _N
    _H[item] += 1.0
    _N += 1.0

    total = _N + 1.0
    probs = (_H + 0.05) / total          # probs[s] = P(next item size == s)

    leftover = (bins - item).astype(np.float64)
    # clamp negatives (bins where item doesn't fit) far below fitting ones
    fits = bins >= item

    # Tier 1: prefer tightest leftover among fitting bins
    score = -leftover

    # Tier 2: reward residuals that are likely to be exactly filled next
    # (proportional to P(residual is a common item size)), scaled small
    resid = np.clip(bins - item, 0, 100).astype(np.int64)
    score += 8.0 * probs[resid]

    # Penalize opening fresh bins (residual == 100 - item, i.e. untouched bin)
    fresh = (bins == 100)
    score[fresh] -= 2.0

    # Non-fitting bins get very low score
    score[~fits] = -1e9

    return score
# EVOLVE-BLOCK-END
