# EVOLVE-BLOCK-START
"""Value-of-residue bin packing: prefer tight fits, but weight the leftover by how
useful it is likely to be for future items, estimated from an online histogram.

This version adds a sharper "exact match to likely future item" reward: the
probability mass of the single most common small item sizes near the residue,
which tends to capture the discrete nature of the Weibull-shaped sizes better
than a wide band average."""
import numpy as np

_COUNTS = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL

    _COUNTS[item] += 1.0
    _TOTAL += 1.0

    b = np.asarray(bins, dtype=np.float64)
    leftover = b - float(item)

    total = _TOTAL if _TOTAL > 0 else 1.0
    cum = np.concatenate(([0.0], np.cumsum(_COUNTS)))

    # Usefulness: probability that a future item lands snugly in this leftover.
    # Band scales with leftover so small residues are judged more finely.
    band = np.clip(0.125 * leftover, 4.0, 20.0)
    lo = np.clip(np.floor(leftover - band), 0, 100).astype(np.int64)
    hi = np.clip(np.floor(leftover), 0, 100).astype(np.int64)
    usefulness = (cum[hi + 1] - cum[lo]) / total

    # Tightness: strongly prefer small leftover, but scale-invariant so large
    # open bins are not dominated purely by absolute size.
    tightness = -leftover / (leftover + 20.0)

    # Exact-fit reward.
    exact = (leftover == 0.0).astype(np.float64)
    # Slight preference to use already-open bins over fresh ones.
    non_empty = (b < 100.0).astype(np.float64)

    score = tightness + 0.6 * usefulness + 0.5 * exact + 0.02 * non_empty
    return score
# EVOLVE-BLOCK-END

