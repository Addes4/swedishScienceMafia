# EVOLVE-BLOCK-START
"""Best-fit with empirical fill-awareness: reward exactly-fillable residuals, penalize stranded gaps."""
import numpy as np

_H = np.zeros(101, dtype=np.float64)   # hist of item sizes seen
_N = 0.0
_W = 0.0                                # sum of sizes seen

# precompute size axis once
_SIZES = np.arange(101, dtype=np.float64)


def priority(item, bins):
    global _N, _W
    _H[item] += 1.0
    _N += 1.0
    _W += item

    total = _N + 1.0
    probs = (_H + 0.05) / total

    leftover = bins - item                       # >= 0 for the bins shown
    left = np.clip(leftover, 0, 100).astype(np.int64)

    # usefulness: weighted mass of future items that fit in residual
    weighted = probs * _SIZES
    cw = np.cumsum(weighted)
    value = cw[left]

    # exact-fill probability: probability a future item equals the residual
    exact = probs[left]

    # stranded-gap penalty: prob mass of sizes in (residual, residual + median-ish)
    # i.e. items that are close but too big -> residual becomes hard waste.
    # Use cumulative distribution difference over a window above the residual.
    cdf = np.cumsum(probs)
    hi = np.clip(left + 12, 0, 100).astype(np.int64)
    stranded = cdf[hi] - cdf[left]

    score = -leftover.astype(np.float64)         # dominant best-fit
    score += 3.0 * exact                         # strongly reward exact fills
    score += 0.5 * value                         # retain useful mass
    score -= 2.0 * stranded                      # dislike stranding near-fit items

    full_mask = (bins == 100)
    score[full_mask] -= 1.0

    return score
# EVOLVE-BLOCK-END
