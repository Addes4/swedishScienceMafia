# EVOLVE-BLOCK-START
"""
Best-fit with sliver avoidance.

Place each item in the bin where it fits most tightly (smallest residual),
but penalize residuals that are too small to ever hold a future item.  We
track the smallest item size seen so far as a proxy for the smallest item
that might arrive again, and penalize leaving a residual below that value
(unless the residual is exactly zero, i.e. a perfect fill).
"""
import numpy as np


class _Stats:
    __slots__ = ("min_size",)

    def __init__(self):
        self.min_size = 101  # smallest item size seen so far

    def add(self, size):
        if size < self.min_size:
            self.min_size = size


_STATS = _Stats()


def priority(item, bins):
    _STATS.add(int(item))

    # Smallest item seen so far acts as the minimum useful residual.
    min_use = _STATS.min_size
    if min_use < 1:
        min_use = 1

    residual = (bins - item).astype(np.float64)

    # Tightness: strongly prefer smallest residual (best fit).
    score = -residual

    # Penalize tiny residuals that cannot hold the smallest known item,
    # except a perfect fill (residual == 0) which is always ideal.
    sliver = (residual > 0.0) & (residual < min_use)
    score = score - np.where(sliver, float(min_use), 0.0)

    # Mild preference for placing into an already-open bin over a fresh one
    # when residuals are otherwise similar (avoids opening new bins early).
    score = score - np.where(bins == 100, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
