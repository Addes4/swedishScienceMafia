# EVOLVE-BLOCK-START
"""Best-fit ranker augmented with an online-learned 'fillability' bonus.

Core idea (classic bin packing wisdom): best-fit alone leaves many tiny
unusable scraps.  We keep the strong best-fit + reuse structure, and add a
small, self-calibrating bonus for candidate bins whose *post-placement
residual* is a value that past items (or pairs of past items) could exactly
fill.  The statistics are estimated from the stream itself, so nothing is
tuned to a specific instance.
"""
import numpy as np

# --- module level online state (persists across calls) ---
_HIST = np.zeros(101, dtype=np.float64)   # counts of item sizes seen (1..100)
_SEEN = 0.0

# residual usefulness: precomputed lazily from _HIST
_UTIL = None
_UTIL_STAMP = -1


def _build_util():
    """Utility of a residual r (0..100): probability-like score that r can be
    exactly consumed by one future item, or by two future items, or is 0."""
    global _UTIL, _UTIL_STAMP
    tot = _HIST.sum()
    if tot <= 0:
        _UTIL = np.zeros(101, dtype=np.float64)
        _UTIL_STAMP = _SEEN
        return
    p = _HIST / tot                      # prob of a given size

    # single-item exact fill
    single = p.copy()

    # two-item exact fill: convolution of p with itself, restricted to <=100
    two = np.zeros(101, dtype=np.float64)
    # iterate over meaningful sizes to keep it cheap (only nonzero probs)
    nz = np.nonzero(_HIST)[0]
    for a in nz:
        pa = p[a]
        # b such that a+b <= 100
        bvec = nz[nz <= 100 - a]
        if bvec.size:
            two[a + bvec] += pa * p[bvec]

    util = np.zeros(101, dtype=np.float64)
    util[1:101] = np.maximum(single[1:101], two[1:101])
    util[0] = 0.0
    _UTIL = util
    _UTIL_STAMP = _SEEN


def priority(item, bins):
    global _HIST, _SEEN, _UTIL, _UTIL_STAMP

    rem = bins.astype(np.float64)
    leftover = rem - item

    # --- primary: best fit (smallest leftover is best) ---
    score = -leftover

    # --- reuse bonus: prefer already-used bins ---
    used = rem < 100.0
    score += used * 5.0

    # --- perfect fit: strongly reward filling a bin exactly ---
    score += (leftover == 0.0) * 20.0

    # --- learned fillability bonus on the residual after placement ---
    # rebuild the table occasionally (cheap, amortized)
    if _UTIL is None or (_SEEN - _UTIL_STAMP) > 200.0:
        _build_util()
    util = _UTIL
    # leftover in [0,100]; use it as an index into the usefulness table
    idx = np.clip(leftover.astype(np.int64), 0, 100)
    score += util[idx] * 3.0

    # record this item's size for future statistics
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _SEEN += 1.0

    return score
# EVOLVE-BLOCK-END
