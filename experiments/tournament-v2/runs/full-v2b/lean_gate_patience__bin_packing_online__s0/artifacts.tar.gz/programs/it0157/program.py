# EVOLVE-BLOCK-START
"""Value-of-residue ranker for online bin packing.

For each candidate bin we compute the post-placement leftover r = bins - item.
We score the bin by combining:
  * a tightness term (prefer small leftover),
  * the empirical probability that a future item fits in r,
  * a small extra bonus for exact fits (leftover == 0),
  * a mild bonus for already-non-empty bins to discourage opening new bins.
"""
import numpy as np


# ---------------------------------------------------------------- state
_hist = np.zeros(101, dtype=np.float64)      # counts of past item sizes
_n_items = 0

# precomputed constants
_SIZES = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    global _n_items

    bins = np.asarray(bins, dtype=np.float64)
    leftover = bins - float(item)          # can be >= 0 for all shown bins

    # tightness: smaller leftover -> higher score
    tight = -leftover

    # usefulness of the resulting leftover (vectorised)
    r = leftover
    r_safe = np.clip(r, 0, None).astype(int)

    if _n_items == 0:
        useful = np.minimum(1.0, r / 50.0)
    else:
        total = float(_n_items)
        # p_fit[r] = P(past item <= r); survival-style fit probability
        cum = np.cumsum(_hist)
        p_fit = cum[r_safe] / total
        # slight geometric sharpening: reward residues that are likely to fit
        useful = p_fit * p_fit

    # exact fits are especially valuable
    exact = (r == 0).astype(np.float64)

    # discourage opening brand-new bins (leftover == 100 - item means empty bin)
    empty = (bins == 100.0)
    nonempty_bonus = np.where(empty, 0.0, 1.0)

    score = (
        2.0 * tight                 # primary: best fit tendency
        + 180.0 * useful            # reward leftovers likely to be refilled
        + 120.0 * exact             # prefer perfect fits
        + 3.0 * nonempty_bonus      # mild preference to fill existing bins
    )

    # ---- online statistics update (after scoring, item is about to be placed)
    _hist[item] += 1.0
    _n_items += 1

    return score
# EVOLVE-BLOCK-END
