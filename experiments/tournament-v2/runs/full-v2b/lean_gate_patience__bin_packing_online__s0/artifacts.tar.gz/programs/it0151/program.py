# EVOLVE-BLOCK-START
"""Value-of-residue online bin choice with a prior-calibrated CDF.

For each bin we form the leftover after placing the item. Tightness (smaller leftover) is
rewarded, but we add a bonus proportional to the empirical usefulness of that leftover:
the probability, estimated online from the histogram of items seen so far, that a future
item could still fit into the remaining space. Exact fits get an additional bonus. This
keeps the strength of best-fit while discouraging residues that are too small to be reused.

To avoid the noisy early estimates of a pure online histogram, we mix the observed counts
with a fixed prior histogram (a Weibull-like shape with mean about 40) via pseudo-counts.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)   # counts of item sizes seen so far
_N = 0.0                                  # number of items seen so far
_ALPHA = 25.0                             # weight for residue usefulness
_PERFECT = 60.0                           # bonus for an exact (zero-leftover) fit
_PRIOR_W = 200.0                          # total pseudo-count weight of the prior

# Prior distribution over item sizes: smooth Weibull-like mass with mean ~40, plus a bit
# of mass near 100 for the large tail. This is only a rough guide; experiments adapt it.
_sizes = np.arange(1, 101, dtype=np.float64)


def _build_prior():
    """A simple shape prior with mean approximately 40 (Weibull k~1.3, lambda~44)."""
    k = 1.3
    lam = 44.0
    # Weibull pdf on the support 1..100.
    x = _sizes / lam
    pdf = (k / lam) * np.power(x, k - 1.0) * np.exp(-np.power(x, k))
    pdf = np.maximum(pdf, 1e-12)
    # Zero out below size 1 region already handled; add tiny mass on large sizes.
    pdf = pdf + 1e-4
    pdf = pdf / pdf.sum()
    return pdf


_PRIOR = _build_prior()


def priority(item, bins):
    """Return a score for every bin; item goes to the highest score (first on ties)."""
    global _N

    leftover = bins - item  # numpy int64 array, >= 0 for every bin shown

    # Mixed CDF: observed counts blended with the prior via pseudo-counts.
    counts = _HIST + _PRIOR_W * _PRIOR
    total = _N + _PRIOR_W
    cdf = np.cumsum(counts) / total
    cdf = np.clip(cdf, 0.0, 1.0)

    idx = np.clip(leftover, 0, 100).astype(np.int64)
    usefulness = cdf[idx]

    # Base: tightness (negative leftover => smaller is better). Add usefulness bonus.
    score = -leftover.astype(np.float64) + _ALPHA * usefulness
    score[leftover == 0] += _PERFECT

    # Update online statistics with the item just observed (not used for this decision).
    _HIST[item] += 1.0
    _N += 1.0

    return score
# EVOLVE-BLOCK-END

