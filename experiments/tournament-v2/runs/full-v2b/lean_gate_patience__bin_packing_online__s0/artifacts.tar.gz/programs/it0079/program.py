# EVOLVE-BLOCK-START
"""Reserve-for-later ranker: tight fit + gap penalty + reuse bias."""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.small_frac = 0.1  # fraction of items <= threshold

    def update(self, item):
        self.n += 1
        # running mean
        self.mean += (item - self.mean) / self.n
        # running fraction of small items (<= 15)
        thr = 15
        self.small_frac += ((1.0 if item <= thr else 0.0) - self.small_frac) / self.n


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    # empirical typical small item size
    small_thr = max(2.0, min(20.0, _stats.mean * 0.35))
    sf = _stats.small_frac

    leftover = bins - item  # >= 0 by contract

    # Base: prefer tight fit (small leftover -> higher score)
    base = -leftover.astype(np.float64)

    # Penalty for leaving a gap below typical small item size:
    # such gaps tend to be wasted. Scale by how common small items are.
    gap_pen = np.where(
        leftover < small_thr,
        (small_thr - leftover) * (0.5 + sf),
        0.0,
    )

    # Reuse bias: prefer already non-empty bins (remaining < 100)
    nonempty = (bins < 100).astype(np.float64)
    reuse = nonempty * 3.0

    # Slight bonus for near-perfect fits (leftover 0)
    perfect = np.where(leftover == 0, 2.0, 0.0)

    return base + reuse + perfect - gap_pen
# EVOLVE-BLOCK-END
