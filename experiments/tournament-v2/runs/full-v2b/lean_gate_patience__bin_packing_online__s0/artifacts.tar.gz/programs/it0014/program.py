# EVOLVE-BLOCK-START
"""Best-fit with empirical residual reusability.

Primary rule: tightest fit (smallest residual).
Tie-breaking / secondary nudge: prefer residuals that can still hold a typical
future item, based on running mean of past item sizes. Never looks at the future.
"""
import numpy as np

# Empirical state across calls.
_STATE = {
    "n": 0,
    "sum": 0.0,
}

# Large constant so tightness strictly dominates the nudge.
_TIGHT = 1000.0


def _update_state(item):
    _STATE["n"] += 1
    _STATE["sum"] += item


def priority(item, bins):
    _update_state(item)

    bins = np.asarray(bins, dtype=np.int64)
    n = _STATE["n"]
    mean_item = (_STATE["sum"] / n) if n > 0 else 40.0
    # A "typical" small item we hope to still fit into a residual.
    typical = max(1.0, mean_item * 0.5)

    remainder = bins - item  # residual if the item goes here; >= 0 by contract
    rem_f = remainder.astype(np.float64)

    # Primary: tightest fit (small residual preferred).
    score = -_TIGHT * rem_f

    # Secondary: reward residuals that can still hold a typical item.
    # (1.0 if rem >= typical, scaled down smoothly below that.)
    usable = np.minimum(1.0, rem_f / typical)
    score += 1.0 * usable

    # Tiny extra reward for an exact fill (perfect packing).
    score += np.where(remainder == 0, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END
