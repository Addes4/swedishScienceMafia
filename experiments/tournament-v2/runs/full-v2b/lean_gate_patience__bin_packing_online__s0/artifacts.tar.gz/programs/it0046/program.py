# EVOLVE-BLOCK-START
"""Histogram-based expected-value bin choice: score residuals by future fill probability."""
import numpy as np

_H = np.zeros(101, dtype=np.float64)   # hist of item sizes seen
_N = 0.0
_W = 0.0                                # sum of sizes seen


def priority(item, bins):
    global _N, _W
    # update histogram (light smoothing so early calls still work)
    _H[item] += 1.0
    _N += 1.0
    _W += item

    # Empirical distribution; add a tiny prior to avoid degenerate early behavior
    total = _N + 1.0
    probs = (_H + 0.05) / total   # probs[s] ~ P(future item == s)

    leftover = bins - item        # >= 0 for bins the item fits in

    # Expected future "fill value" of a residual R:
    # sum over sizes s <= R of probs[s] * s  -> mass that can still be packed there.
    # Precompute cumulative weighted mass once.
    sizes = np.arange(101, dtype=np.float64)
    weighted = probs * sizes
    cw = np.cumsum(weighted)      # cw[R] = sum_{s<=R} probs[s]*s

    left = np.clip(leftover, 0, 100).astype(np.int64)
    value = cw[left]              # higher = more useful residual space

    # Primary: prefer tightest leftover (best fit) to consolidate.
    score = -leftover.astype(np.float64)
    # Secondary: small bonus for residuals that retain large useful mass.
    score += 0.6 * value
    # Discourage opening a fresh bin (residual = 100 - item) slightly.
    full_mask = (bins == 100)
    score[full_mask] -= 1.0

    return score
# EVOLVE-BLOCK-END
