import numpy as np


class _Stats:
    """Online histogram of item sizes for residue usefulness estimation."""
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def add(self, item):
        self.counts[item] += 1.0
        self.total += 1.0


_stats = _Stats()


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.float64)
    leftovers = bins - item

    # Pure best-fit: prefer the smallest leftover (fullest bin the item still fits).
    # This is the dominant term and is known to beat worst-fit / first-fit on
    # Weibull-like random sizes.
    scores = -leftovers

    # Exact fit: always take it.
    scores = scores + np.where(leftovers == 0, 1e6, 0.0)

    _stats.add(item)
    return scores
