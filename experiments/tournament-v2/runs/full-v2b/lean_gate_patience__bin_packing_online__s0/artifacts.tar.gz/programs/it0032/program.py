# EVOLVE-BLOCK-START
"""Best fit with exact-close reward.

Primary rule: tightest fit (smallest leftover).  Secondary:
 - a strong reward when the item exactly fills a bin (leftover == 0),
 - a mild preference for existing (non-empty) bins over opening new ones.
No brittle absolute thresholds; the ranking adapts to item size.
"""
import numpy as np


_state = {"n": 0}


def priority(item, bins):
    _state["n"] += 1

    bins = np.asarray(bins)
    leftover = bins - item  # >= 0 for all bins shown

    score = -leftover.astype(np.float64)

    # strong reward for perfectly closing a bin
    score += 8.0 * (leftover == 0)

    # mild reward for reusing an already-open bin (avoid needless new bins)
    score += 0.5 * (bins < 100)

    return score
# EVOLVE-BLOCK-END
