# EVOLVE-BLOCK-START
"""Residue-utility ranker: tight fits, but avoid uselessly tiny leftovers."""
import numpy as np

# Online statistics of arriving item sizes.
_state = {"n": 0, "mean": 40.0, "small_frac": 0.25}

# Threshold below which a leftover gap is considered "too small to be useful".
_TINY = 15.0


def priority(item, bins):
    """Rank bins by tight fit, penalizing leftovers too small for future items.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in (including unused = 100).
    """
    # Update running item statistics (cheap, no future info).
    n = _state["n"] + 1
    mean = _state["mean"] + (item - _state["mean"]) / n
    small = _state["small_frac"] + ((1.0 if item <= 20 else 0.0) - _state["small_frac"]) / n
    _state["n"] = n
    _state["mean"] = mean
    _state["small_frac"] = small

    b = bins.astype(np.float64)
    leftover = b - item  # >= 0 since only fitting bins are shown

    # Tightness: prefer smaller leftover (best fit).
    tight = -leftover

    # Residue utility: leftover near 0 is perfect; but a leftover in the
    # "tiny but nonzero" band is bad because few future items fit there.
    # Penalize well below a typical small item size.
    tiny_pen = np.where((leftover > 0) & (leftover < _TINY), -( _TINY - leftover), 0.0)

    # Mild reuse bonus: prefer non-empty bins (leftover < 100) to avoid
    # opening a fresh bin unless the fit is genuinely good.
    reuse = np.where(b < 100, 1.0, 0.0)

    return tight + 1.5 * tiny_pen + 2.0 * reuse
# EVOLVE-BLOCK-END
