# EVOLVE-BLOCK-START
"""Residual-utility best-fit ranking.

For each candidate bin we compute the residual r = remaining - item.  We score
bins mainly by how "fillable" the residual is: using a learned histogram of past
item sizes we precompute the set of sums achievable by 1..3 future items and
reward residuals that lie in (or near) that set.  A mild tight-fit term still
prefers fuller bins and breaks ties toward smaller leftovers.
"""
import numpy as np

_HIST_SIZE = 101
_state = {
    "n": 0,
    "hist": np.zeros(_HIST_SIZE, dtype=np.float64),
    "freq": np.zeros(_HIST_SIZE, dtype=np.float64),
    "reach": None,   # boolean array length 101: reachable by <=3 typical items
    "cnt": 0,
}


def _update(item):
    s = _state
    s["n"] += 1
    if 1 <= item <= 100:
        s["hist"][item] += 1.0
    s["cnt"] += 1
    # Rebuild reachable-set cache occasionally.
    if s["cnt"] % 200 == 0 or s["reach"] is None:
        total = s["hist"].sum()
        if total > 0:
            freq = s["hist"] / total
        else:
            freq = np.zeros(_HIST_SIZE)
        s["freq"] = freq
        # Typical items: sizes with non-negligible frequency.
        thresh = max(1.0 / total, 1e-4) if total > 0 else 1.0
        typical = np.where(freq >= thresh, np.arange(_HIST_SIZE), 0).astype(np.int64)
        typical = typical[typical >= 1]
        reach = np.zeros(_HIST_SIZE + 1, dtype=bool)
        reach[0] = True
        # up to 3 typical items
        cur = np.zeros(_HIST_SIZE + 1, dtype=bool)
        cur[0] = True
        for _ in range(3):
            nxt = np.zeros(_HIST_SIZE + 1, dtype=bool)
            for t in typical:
                if t == 0:
                    continue
                # shift cur by t
                if t <= _HIST_SIZE:
                    nxt[t:] |= cur[: _HIST_SIZE + 1 - t]
            cur = nxt
            reach |= cur
        reach[0] = True
        s["reach"] = reach


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    bins = np.asarray(bins)
    remaining = bins - item
    rem_f = remaining.astype(np.float64)
    n = _state["n"]

    # Mild tight-fit term (smaller leftover slightly better).
    score = -rem_f * 1.5

    # Reuse non-empty bins.
    non_empty = (bins < 100)
    score += np.where(non_empty, 1.0, 0.0)

    # Strong reward for exactly filling a bin.
    score += 8.0 * (remaining == 0)

    reach = _state["reach"]
    if reach is not None and n > 100:
        rem_clip = np.clip(remaining, 0, 100)
        fillable = reach[rem_clip]
        # Strongly reward residuals that can be exactly filled by <=3 items.
        score += np.where(fillable & (remaining > 0), 6.0, 0.0)
        # Penalize residuals that cannot be filled and are tiny slivers.
        useless = (~fillable) & (remaining > 0) & (remaining < 20)
        score -= np.where(useless, 4.0, 0.0)

    _update(item)
    return score
# EVOLVE-BLOCK-END
