# EVOLVE-BLOCK-START
"""Waste-probability ranker for online bin packing.

For each candidate bin we form the post-placement leftover r = bins - item.
A leftover of r is "wasted" if no single future item can fill part of it;
this happens (in the one-item-fits view) when the next useful item is larger
than r. The probability that a leftover is unusable by any single future
item is 1 - F(r), where F is the item-size CDF. Smaller waste probability
means the bin stays reusable, so we prefer small r and we strongly prefer
r == 0 (perfectly filled). We blend a fixed Weibull-shaped prior with the
online empirical histogram so the estimate is well-calibrated immediately
yet adapts to the actual stream.
"""
import numpy as np

# ---------------------------------------------------------------- state
_hist = np.zeros(101, dtype=np.float64)      # counts of past item sizes
_n_items = 0

_SIZES = np.arange(101, dtype=np.float64)

# Fixed Weibull-shaped prior (scale chosen so mean ~ 40, as stated).
# pdf(x) ~ (k/c)(x/c)^(k-1) exp(-(x/c)^k) with k=1.5, c ~ 43.
_k = 1.5
_c = 43.0
_x = np.maximum(_SIZES, 1e-9)
_prior_w = (_k / _c) * (_x / _c) ** (_k - 1.0) * np.exp(-(_x / _c) ** _k)
_prior_w[0] = 0.0
_prior_w = _prior_w / _prior_w.sum()


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    global _n_items

    bins = np.asarray(bins, dtype=np.float64)
    leftover = bins - float(item)

    r = np.clip(leftover, 0, 100).astype(int)

    # Blend prior with empirical histogram (pseudo-count for stability).
    if _n_items == 0:
        p = _prior_w.copy()
    else:
        pseudo = 20.0
        counts = _hist + pseudo * _prior_w * 100.0
        p = counts / counts.sum()

    # Cumulative distribution: P(item <= r)
    cum = np.cumsum(p)
    cdf_r = cum[r]                      # in [0,1]
    waste = 1.0 - cdf_r                 # prob. leftover unusable by 1 item

    # tightness base: prefer small leftover (best-fit direction)
    tight = -leftover

    # perfect fits are the most valuable (leftover exhausted)
    exact = (r == 0).astype(np.float64)

    # discourage opening brand-new bins
    empty = (bins == 100.0)
    nonempty_bonus = np.where(empty, 0.0, 1.0)

    score = (
        2.0 * tight
        - 30.0 * waste          # penalize leftovers unlikely to be reused
        + 40.0 * exact
        + 3.0 * nonempty_bonus
    )

    _hist[item] += 1.0
    _n_items += 1

    return score
# EVOLVE-BLOCK-END
