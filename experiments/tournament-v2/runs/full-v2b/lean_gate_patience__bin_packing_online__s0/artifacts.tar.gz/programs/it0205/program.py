# EVOLVE-BLOCK-START
"""Value-of-residue ranker: tight fit plus online-histogram usefulness of the leftover."""
import numpy as np

# Online histogram of past item sizes (1..100). Tracks how likely a future item
# fits snugly into a given leftover residual.
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
_alpha = 0.02  # EMA smoothing so the histogram adapts to the running distribution.


def _update_hist(item):
    global _count
    _hist[item] += 1.0
    _count += 1.0
    # occasional decay to keep things bounded and adaptive
    if _count > 2000.0:
        _hist *= 0.5
        _count *= 0.5


def _usefulness(res):
    """Estimate of how useful a leftover capacity `res` is.

    Larger residual = more likely a future item fits; but we specifically reward
    residuals where a snug future match is plausible (fraction of past items that
    fit inside res, weighted toward near-fills).
    """
    if res <= 0 or res > 100:
        return -1.0
    # how many past items fit inside res, weighted by how snug they fill it
    fit = _hist[1:res + 1]
    if fit.sum() <= 0:
        # no data: prefer larger residuals mildly
        return 0.01 * res
    idx = np.arange(1, res + 1)
    # weight snug fits more (small leftover after placing that item)
    leftover = res - idx
    w = np.exp(-leftover / 8.0)
    score = float((fit * w).sum()) / (_count + 1.0)
    return score


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties)."""
    _update_hist(item)

    n = bins.shape[0]
    scores = np.empty(n, dtype=np.float64)

    for i in range(n):
        cap = int(bins[i])
        res = cap - item  # leftover after placing item here
        # core: tightness (prefer small positive leftover), large penalty for exact dead fill
        s = -res
        # value of the residual for future items
        s += 40.0 * _usefulness(res)
        # exact fit bonus
        if res == 0:
            s += 60.0
        # non-empty bin bonus (consolidation) unless we'd leave an awkward small residual
        if cap < 100:
            s += 1.5
            if 0 < res <= 5:
                s -= 2.0
        scores[i] = s

    return scores
# EVOLVE-BLOCK-END
