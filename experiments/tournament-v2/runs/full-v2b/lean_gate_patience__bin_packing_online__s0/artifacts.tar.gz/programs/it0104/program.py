# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with reusable-residue handling.

Primary signal is strict best-fit (smallest leftover after placing the item).
A strong reuse bonus prevents opening a fresh bin when an already-open bin
can take the item. A penalty discourages residues so small they cannot
realistically receive a future item, pushing items into bins where the
leftover remains usable.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0
        self.min_item = 100.0

    def update(self, item):
        self.n += 1.0
        self.sum += item
        if item < self.min_item:
            self.min_item = float(item)

    @property
    def mean(self):
        if self.n >= 1.0:
            return self.sum / self.n
        return 40.0


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    b = bins.astype(np.float64)
    unused = b >= 100.0

    # Post-placement residue.
    resid = b - float(item)

    # Strict best-fit: smallest non-negative residue preferred (least negative).
    fit = -resid

    # Threshold for "unusable" residues: scale with observed mean item size but
    # kept modest so we only punish truly tiny leftovers.
    thr = max(1.0, min(15.0, 0.5 * _stats.mean))

    tiny = np.where(resid < thr, (thr - resid) / thr, 0.0)

    # Strongly prefer reusing non-empty bins over opening a fresh one.
    reuse = np.where(unused, 0.0, 1.0)

    score = (fit / 100.0) + 0.5 * reuse - 0.25 * tiny

    return score
# EVOLVE-BLOCK-END
