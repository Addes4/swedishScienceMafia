# EVOLVE-BLOCK-START
"""Best-fit with fullness-weighted reuse preference."""
import numpy as np


def priority(item, bins):
    residual = bins - item

    # Base: tightest fit (smaller residual => higher score). Exact fit residual 0 dominates.
    score = -residual.astype(np.float64)

    # Bonus for reusing already-open bins, scaled by how full they currently are.
    used = bins < 100
    fullness = (100 - bins).astype(np.float64)  # 0 for empty bins
    score += np.where(used, 1000.0 + fullness, 0.0)

    return score
# EVOLVE-BLOCK-END
