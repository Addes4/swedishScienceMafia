# EVOLVE-BLOCK-START
"""Histogram-based expected-value bin choice with dead-residual awareness."""
import numpy as np

_H = np.zeros(101, dtype=np.float64)   # hist of item sizes seen
_N = 0.0


def priority(item, bins):
    global _N
    _H[item] += 1.0
    _N += 1.0

    # Empirical distribution with mild uniform smoothing
    total = _N + 20.0
    probs = (_H + 0.2) / total
    probs[0] = 0.0

    leftover = bins - item            # >= 0 for bins the item fits in
    left = np.clip(leftover, 0, 100).astype(np.int64)

    sizes = np.arange(101, dtype=np.float64)
    weighted = probs * sizes
    cw = np.cumsum(weighted)          # expected usable mass in residual R

    # Probability that residual R is exactly fillable by some future item size
    exact = probs[left] / max(probs.sum(), 1e-12)

    value = cw[left]

    # Primary: tightest leftover to consolidate.
    score = -leftover.astype(np.float64)
    # Secondary: retain useful mass.
    score += 0.6 * value
    # Reward residuals that are exact/high-probability item sizes.
    score += 2.0 * exact
    # Penalize opening fresh bins slightly.
    full_mask = (bins == 100)
    score[full_mask] -= 1.0

    return score
# EVOLVE-BLOCK-END
