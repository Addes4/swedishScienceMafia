# EVOLVE-BLOCK-START
"""Distribution-aware residue-utility best fit.

Keeps best-fit as the base signal, but scores a bin's post-placement leftover
by how "useful" that leftover is under the empirical item-size distribution
seen so far: leftovers that match likely future item sizes (or 0, a perfect
fill) are favored, tiny unusable scraps are mildly penalized.
"""
import numpy as np

# Empirical histogram of item sizes seen so far (1..100).  We use it to
# estimate the probability that a given leftover can be consumed later.
_hist = np.zeros(101, dtype=np.float64)
_n = 0
_sum = 0.0


def priority(item, bins):
    global _n, _sum

    # --- update online statistics with the arriving item -------------------
    if 1 <= item <= 100:
        _hist[item] += 1.0
    _n += 1
    _sum += item

    if _n > 1:
        mean_item = _sum / _n
        # empirical probability mass function (sizes 1..100)
        pmf = _hist[1:] / _n
    else:
        mean_item = 40.0
        pmf = np.full(100, 1.0 / 100.0)

    bins_f = bins.astype(np.float64)
    leftover = bins_f - item          # capacity remaining after placement (>= 0)

    # --- residue utility ---------------------------------------------------
    # Probability that a future item can *exactly* fit this leftover.
    # Indices: leftover L in [1,100] -> pmf index L-1.
    L = np.clip(leftover.astype(np.int64), 1, 100)
    exact_util = np.where(leftover > 0.0, pmf[L - 1], 0.0)

    # Probability that *some* future item is <= leftover (leftover is usable).
    cdf = np.cumsum(pmf)               # cdf[k-1] = P(size <= k)
    Cl = np.clip(leftover.astype(np.int64), 0, 100)
    usable_util = np.where(leftover > 0.0, cdf[np.maximum(Cl - 1, 0)], 0.0)

    # Scrap hazard: leftovers well below the mean item are mostly wasted.
    scrap_hi = max(6.0, 0.5 * mean_item)
    scrap = (leftover > 0.0) & (leftover < scrap_hi)
    hazard = scrap.astype(np.float64) * (scrap_hi - leftover + 1.0)

    # --- rank --------------------------------------------------------------
    score = (
        -leftover                       # best fit: tighter is better
        + 8.0 * exact_util              # reward likely exact refills
        + 3.0 * usable_util             # reward leftover that a future item can use
        - 1.2 * hazard                  # discourage tiny unusable scraps
    )

    # Strongly prefer reusing an already-open bin over opening a fresh one.
    is_new = bins_f >= 100.0
    score = score + np.where(is_new, -6.0, 0.0)

    return score
# EVOLVE-BLOCK-END

