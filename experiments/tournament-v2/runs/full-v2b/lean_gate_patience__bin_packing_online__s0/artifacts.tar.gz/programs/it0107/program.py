# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with an adaptive wasted-residue guard.

The principled online rule here is best-fit: place each item into the open bin
that minimizes the leftover space. Pure best-fit occasionally creates residues
too small to ever host a future item, which wastes capacity, so we add a mild
discount for bins whose post-placement residue falls below an online estimate
of the smallest likely future item (a low percentile of observed sizes). Reuse
of already-open bins is preferred over opening fresh ones, and ties are settled
by the primary best-fit signal.
"""
import numpy as np


def _quantile_from_hist(hist, total, q):
    """Approximate the q-quantile (0<=q<=1) of a histogram over sizes 1..100."""
    if total <= 0:
        return 1.0
    target = q * total
    cum = 0.0
    for size in range(1, 101):
        cum += hist[size]
        if cum >= target:
            return float(size)
    return 100.0


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0
        self.hist = np.zeros(101, dtype=np.float64)
        # Exponential decay keeps the estimate responsive to the stream.
        self.decay = 0.995

    def update(self, item):
        self.n += 1.0
        self.sum += item
        self.hist *= self.decay
        self.hist[int(item)] += 1.0

    @property
    def mean(self):
        if self.n >= 1.0:
            return self.sum / self.n
        return 40.0

    @property
    def low_q(self):
        total = float(self.hist.sum())
        if total < 20.0:
            return 1.0
        return _quantile_from_hist(self.hist, total, 0.05)


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    b = bins.astype(np.float64)
    unused = b >= 100.0

    # Post-placement residue: smaller is better (pure best-fit signal).
    resid = b - float(item)

    # Smallest likely future item; guard against creating useless tiny residues.
    small = _stats.low_q
    # Penalize residues below `small` (they can rarely be filled exactly).
    below = np.maximum(0.0, small - resid)

    # Primary: strict best-fit (tightest leftover is best).
    fit = -resid

    # Strongly prefer reusing already-open bins over opening a fresh one.
    reuse = np.where(unused, 0.0, 1.0)

    score = fit - 1.0 * below + 30.0 * reuse

    return score
# EVOLVE-BLOCK-END
