# EVOLVE-BLOCK-START
"""Best-fit with a "useful-residual" opening guard.

Among bins that can hold the item we use strict best-fit (smallest residual),
which keeps bins tightly packed and ties resolve to the earliest bin.  The
only refinement: we penalize reusing a bin when the leftover after placement
would be a tiny, mostly unusable scrap.  The threshold adapts online to a low
quantile of item sizes, so it never hurts when scraps are genuinely usable.
"""
import numpy as np

_count = 0
_mean = 40.0
# Running ordered sample of recent item sizes (small window) to estimate a
# low quantile cheaply without sorting large arrays every call.
_window = np.zeros(64, dtype=np.int64)
_wpos = 0


def _update_stats(item):
    global _count, _mean, _wpos
    _count += 1
    lr = 1.0 / _count if _count < 50 else 0.02
    _mean = (1.0 - lr) * _mean + lr * item
    _window[_wpos] = item
    _wpos = (_wpos + 1) % _window.size


def priority(item, bins):
    """Return a priority per bin; highest wins."""
    _update_stats(item)

    bins = bins.astype(np.int64)
    residual = bins - item  # >=0 for fitting bins, <0 otherwise
    fits = residual >= 0

    used = bins < 100

    # Base: strongly prefer used bins over empty ones.
    score = used.astype(np.float64) * 1000.0

    # Best-fit: prefer smaller residual among used bins.
    rf = residual.astype(np.float64)
    score += np.where(fits, 100.0 - rf, -1000.0)

    # Useful-residual guard: penalize leaving a scrap smaller than a low
    # quantile of recent item sizes.  Kept small so best-fit still dominates.
    if _count >= 64:
        thr = float(np.quantile(_window, 0.25))
    else:
        thr = 5.0
    if thr < 1.0:
        thr = 1.0
    if thr > 15.0:
        thr = 15.0
    scrap = fits & used & (residual < thr)
    score -= np.where(scrap, 3.0, 0.0)

    # Exact fills stay highly valuable.
    score += np.where(fits & (residual == 0), 50.0, 0.0)

    # Empty bins: resolve ties toward the first empty bin.
    empties = (bins >= 100)
    score += np.where(empties, -rf * 0.001, 0.0)

    return score
# EVOLVE-BLOCK-END
