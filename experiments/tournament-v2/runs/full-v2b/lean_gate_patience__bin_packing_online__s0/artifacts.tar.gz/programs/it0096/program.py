# EVOLVE-BLOCK-START
"""Histogram-based residue matching on top of best-fit."""
import numpy as np

# Online histogram of item sizes seen so far (indexed by size 1..100).
_hist = np.zeros(101, dtype=np.float64)
_state = {"n": 0}


def priority(item, bins):
    """Score bins to leave residues that match likely future item sizes.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in (including unused = 100).
    """
    b = bins.astype(np.int64)
    leftover = b - item  # >= 0 since only fitting bins are shown

    # Probability mass of a future item exactly equal to each residue.
    # Use a small floor so empties/small residues aren't totally ignored.
    n = _state["n"] + 1
    probs = _hist / max(n, 1.0)
    # Probability that residue r can be exactly filled later.
    exact_fill = probs[leftover]
    # A floor encourages leaving "common" residues even before data accumulates.
    exact_fill = exact_fill + 0.002

    # Best-fit tightness as a strong secondary signal (small leftover preferred).
    tight = -leftover.astype(np.float64)

    # Mild reuse bonus for non-empty bins.
    reuse = np.where(b < 100, 1.0, 0.0)

    score = 50.0 * exact_fill + tight + 0.5 * reuse

    # Update statistics after scoring (item assigned externally).
    _hist[item] += 1.0
    _state["n"] = n

    return score
# EVOLVE-BLOCK-END
