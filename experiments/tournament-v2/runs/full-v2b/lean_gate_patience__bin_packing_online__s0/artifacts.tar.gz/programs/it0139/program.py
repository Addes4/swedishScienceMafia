# EVOLVE-BLOCK-START
"""Best-fit with a scrap guard: strict tightest fit among used bins, but
penalize only post-placement residues provably too small to ever be reused
(below the smallest item size observed so far). Strong reuse bonus over new bins."""
import numpy as np

_state = {
    "n": 0,
    "min_item": 101,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = _state["n"]
    min_item = _state["min_item"]

    # Update online statistics *after* reading them (never use future items).
    _state["n"] = n + 1
    if item < min_item:
        _state["min_item"] = item
        min_item = item

    # Scrap threshold: a residue smaller than the smallest item ever seen can
    # never be filled again, so it is pure waste.
    scrap = float(min_item)  # min_item starts at 101 -> no scrap penalty early
    if scrap > 100.0:
        scrap = 1.0  # before seeing any item, treat minimal scraps as waste-free

    bins_f = bins.astype(np.float64)
    leftover = bins_f - item  # >= 0 for all bins shown

    # Base: tightest fit (smaller leftover is better).
    score = -leftover

    # Penalize unusable scraps (strictly positive but below the scrap threshold).
    is_scrap = (leftover > 0.0) & (leftover < scrap)
    score = score - 8.0 * is_scrap.astype(np.float64)

    # Perfect fill: reward strongly.
    perfect = (leftover <= 0.0)
    score = score + 5.0 * perfect.astype(np.float64)

    # Strong reuse bonus: avoid opening brand-new bins.
    is_new = bins_f >= 100.0
    score = score - 7.0 * is_new.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
