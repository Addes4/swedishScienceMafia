# EVOLVE-BLOCK-START
"""Best fit with large-item fresh-bin reservation.

Dominant rule: tightest fit (smallest leftover).  Tie-breakers learned from
past items:
 - mildly prefer reusing non-empty bins,
 - penalize residuals below the empirical small-item threshold (dead space),
 - give a small bonus to fresh (empty) bins when the arriving item is large,
   so big items don't shred partially-filled bins into slivers.
"""
import numpy as np


# --- module-level state (persists across calls) ---
_state = {
    "n": 0,
    "min_seen": 101,
    "sum": 0.0,
}


def _update_stats(item):
    st = _state
    st["n"] += 1
    st["sum"] += item
    if item < st["min_seen"]:
        st["min_seen"] = item


def priority(item, bins):
    _update_stats(item)

    bins = np.asarray(bins)
    leftover = bins - item  # >= 0 for all bins shown

    score = -leftover.astype(np.float64)

    nonempty = bins < 100
    score += 0.5 * nonempty

    min_seen = _state["min_seen"]
    threshold = max(1, min_seen)
    awkward = (leftover > 0) & (leftover < threshold)
    score -= 2.0 * awkward

    mean = _state["sum"] / max(1, _state["n"])
    if item > mean:
        empty = bins == 100
        score += 0.3 * empty

    return score
# EVOLVE-BLOCK-END
