# EVOLVE-BLOCK-START
"""Best-fit residual plus online residue-reuse value from smoothed histogram mass."""
import numpy as np


class _State:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)  # histogram of past item sizes
        self.n = 0.0
        self.total = 0.0

    def mean(self):
        return self.total / self.n if self.n > 0 else 40.0


_STATE = _State()


def priority(item, bins):
    st = _STATE

    leftover = bins - item  # post-placement remaining capacity, >= 0

    # Primary: best-fit tightness (prefer small leftovers).
    score = -leftover.astype(np.float64)

    if st.n > 0:
        pdf = st.counts / st.n  # pdf[s] = P(item == s)
        # smooth over +-1 to be robust
        sm = pdf.copy()
        sm[1:] += pdf[:-1]
        sm[:-1] += pdf[1:]
        # probability that some future item will exactly match this residue
        reuse = sm[leftover]
        score += 20.0 * reuse
    else:
        reuse = np.zeros_like(leftover, dtype=np.float64)

    # Exact-fit bonus on the current item.
    score += 8.0 * (leftover == 0)

    # Slight preference against opening brand-new bins.
    score += 0.5 * (bins < 100)

    # Update online statistics with the arriving item.
    st.counts[item] += 1.0
    st.n += 1.0
    st.total += item

    return score
# EVOLVE-BLOCK-END
