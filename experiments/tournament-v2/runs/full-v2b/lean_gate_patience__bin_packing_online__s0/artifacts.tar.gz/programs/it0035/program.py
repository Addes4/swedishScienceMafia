# EVOLVE-BLOCK-START
"""Best fit with adaptive reuse and close-out rewards.

Primary rule: tightest fit (smallest leftover).  Secondary:
 - a moderate reward when the item exactly fills a bin (leftover == 0),
 - a bonus for reusing an already-open bin, scaled by the fraction of the
   bin it fills (bigger, denser bins are preferred over opening new ones),
 - a mild penalty for leaving tiny residuals that few future items can use.
The ranking adapts to item size without brittle absolute thresholds.
"""
import numpy as np


_state = {"n": 0}


def priority(item, bins):
    _state["n"] += 1

    bins = np.asarray(bins)
    leftover = bins - item  # >= 0 for all bins shown

    score = -leftover.astype(np.float64)

    # reward for perfectly closing a bin
    score += 10.0 * (leftover == 0)

    # reward reuse of already-open bins, weighted by how full they become;
    # larger items placed into a partly-used bin are generally good.
    reuse = (bins < 100).astype(np.float64)
    fill_frac = item / np.maximum(bins, 1)
    score += 1.0 * reuse * (0.5 + 0.5 * fill_frac)

    # mild penalty for residuals too small to be useful
    score -= 0.3 * ((leftover > 0) & (leftover < 10))

    return score
# EVOLVE-BLOCK-END
