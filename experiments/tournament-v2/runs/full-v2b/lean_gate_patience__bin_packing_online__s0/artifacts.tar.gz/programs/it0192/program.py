import numpy as np


class _Stats:
    """Online histogram of item sizes for residue-value estimation."""
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        self.cum = np.zeros(102, dtype=np.float64)  # cum[r] = count of items <= r

    def add(self, item):
        self.counts[item] += 1.0
        self.total += 1.0
        # update cumulative lazily via full recompute is fine (101 entries)
        self.cum = np.concatenate(([0.0], np.cumsum(self.counts)))

    def match_value(self, residue):
        """Probability mass of past items whose size equals (or nearly fills) this residue."""
        if self.total < 1.0 or residue < 1:
            return 0.0
        r = int(residue)
        if r > 100:
            r = 100
        # Highest single-size mass at or just below the residue (a snug future fit)
        return self.counts[1:r + 1].max() / self.total if r >= 1 else 0.0


_stats = _Stats()


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.float64)
    leftovers = bins - item

    # Dominant: tightest fit (smallest leftover).
    scores = -leftovers

    # Value of residue: prefer leftovers that match a frequent item size,
    # so a future item of that common size can fill the bin exactly.
    usable = leftovers >= 1
    if _stats.total > 0.0:
        r_int = np.clip(leftovers.astype(np.int64), 0, 100)
        # single-size mass just below residue
        val = np.zeros_like(leftovers)
        nz = usable
        if np.any(nz):
            vals = _stats.counts[r_int[nz]] / _stats.total
            val[nz] = vals
        scores = scores + 3.0 * val * usable

    # Exact fit bonus (finish the bin).
    scores = scores + np.where(leftovers == 0, 1e6, 0.0)

    # Mild bonus to non-empty bins (avoid opening fresh bins when possible).
    scores = scores + 0.01 * (bins < 100.0)

    _stats.add(item)
    return scores
