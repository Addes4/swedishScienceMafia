# EVOLVE-BLOCK-START
"""Reserve for later: rank by how fillable the post-placement residual is,
estimated from the empirical item-size distribution (1- and 2-item fills)."""
import numpy as np

_state = {
    "sizes": [],
    "count": 0,
    "hist": None,        # normalized histogram over sizes 1..100
    "cdf": None,         # cumulative distribution
    "pair": None,        # pair-sum histogram (cap 100), normalized
    "built": 0,
}

_BINS_CAP = 100


def _rebuild():
    arr = np.asarray(_state["sizes"], dtype=np.int64)
    n = arr.size
    hist = np.bincount(arr, minlength=_BINS_CAP + 1).astype(np.float64)
    hist = hist / max(1.0, hist.sum())
    pair = np.zeros(_BINS_CAP + 1, dtype=np.float64)
    # pair sums capped at 100
    vals = np.nonzero(hist[1:])[0] + 1
    for v in vals:
        s = v + vals
        s = s[s <= _BINS_CAP]
        pair[s] += hist[v] * hist[vals[:s.size]]
    pair = pair / max(1.0, pair.sum())
    _state["hist"] = hist
    _state["pair"] = pair
    _state["built"] = n


def _update_stats(item):
    _state["sizes"].append(int(item))
    _state["count"] += 1
    n = _state["count"]
    if _state["hist"] is None or n - _state["built"] >= 25:
        # periodic rebuild; keep memory bounded
        if n > 3000:
            _state["sizes"] = _state["sizes"][-1500:]
        _rebuild()


def priority(item, bins):
    _update_stats(item)
    hist = _state["hist"]
    pair = _state["pair"]

    it = float(item)
    leftover = bins.astype(np.float64) - it   # residual after placing here
    residual = np.clip(leftover, 0.0, _BINS_CAP)
    ridx = residual.astype(np.int64)

    # usefulness of residual: probability it can be exactly filled by 1 or 2 items
    # (a residual of 0 is perfectly filled -> best)
    one = hist[ridx]
    two = pair[ridx]
    usefulness = one + two

    # rank: tight fit dominant, usefulness as refined tie-break
    score = -leftover + 6.0 * usefulness

    # small bonus for non-empty bins (avoid opening fresh bins)
    non_empty = bins < _BINS_CAP
    score += np.where(non_empty, 0.3, 0.0)

    return score
# EVOLVE-BLOCK-END
