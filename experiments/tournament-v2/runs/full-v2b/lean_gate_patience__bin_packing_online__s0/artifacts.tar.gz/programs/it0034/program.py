# EVOLVE-BLOCK-START
"""Best fit with exact-close reward, non-linear residual shaping.

Primary rule: tightest fit (smallest leftover), but the useful part of the
residual is shaped non-linearly so that residuals which are too small to be
reused (wasted space) are penalized more than their raw magnitude suggests.
Strong reward for exactly closing a bin; mild reward for reusing open bins.
"""
import numpy as np


_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    _state["n"] += 1
    _state["sum"] += item

    bins = np.asarray(bins)
    leftover = bins - item  # >= 0 for all bins shown

    # Non-linear shaping: the effective value of leftover fraction.
    frac = leftover / 100.0
    # reward tight fits strongly; sqrt compresses large leftovers so the
    # difference between a near-full bin and a moderately filled one is
    # emphasized (avoid leaving dead slivers).
    score = -(1.0 - np.sqrt(np.maximum(frac, 0.0))) * 10.0

    # strong reward for perfectly closing a bin
    score += 8.0 * (leftover == 0)

    # mild reward for reusing an already-open bin
    score += 0.5 * (bins < 100)

    return score
# EVOLVE-BLOCK-END
