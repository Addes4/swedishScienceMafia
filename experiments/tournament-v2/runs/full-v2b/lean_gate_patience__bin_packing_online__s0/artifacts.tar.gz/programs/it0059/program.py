# EVOLVE-BLOCK-START
"""Reserve-for-later ranker: blend tight fit, gap usability, and bin reuse."""
import numpy as np


class _Stats:
    def __init__(self):
        self.seen = 0
        self.small_count = 0
        self.small_sum = 0
        # running estimate of the low quantile of item sizes
        self.q = 20.0
        # set of item sizes seen so far (for exact-reuse detection)
        self.sizes = set()

    def update(self, item):
        self.seen += 1
        if self.seen <= 200 or item < self.q * 1.5:
            # exponential-ish tracking of a low quantile
            self.q += 0.02 * (item - self.q)
            if self.q < 1.0:
                self.q = 1.0
        if len(self.sizes) < 512:
            self.sizes.add(int(item))


_stats = _Stats()


def priority(item, bins):
    """Score bins: tight fits good, unusable gaps penalized, non-empty bins favored."""
    _stats.update(item)

    rem = bins.astype(np.float64)
    leftover = rem - item

    # tight fit score: smaller leftover is better (best fit)
    tight = 1.0 / (1.0 + leftover)

    # gap usability: a leftover gap that is at least a typical small item is fine;
    # gaps below the empirical small-item scale are wasted space -> penalize.
    small = _stats.q
    usable = leftover / (small + item * 0.05)
    np.clip(usable, 0.0, 1.0, out=usable)

    # reuse bonus: prefer already-used bins (rem < 100) to avoid opening new bins
    used = rem < 100.0

    score = tight * (0.55 + 0.45 * usable)

    # discourage leaving a gap that no future small item can fill
    wasted = (leftover > 0) & (leftover < small * 0.6)
    score -= wasted * 0.35

    # prefer non-empty bins unless the fit is clearly better in an empty bin
    score += used * 0.15

    # perfect-fit / exact-reuse bonus: leftover zero, or matches a seen size
    perfect = (leftover == 0.0)
    reusable = np.zeros_like(leftover, dtype=bool)
    if _stats.sizes:
        for s in _stats.sizes:
            reusable |= (leftover == s)
    score += perfect * 5.0
    score += reusable * 1.5

    return score
# EVOLVE-BLOCK-END

