# EVOLVE-BLOCK-START
"""Expected-residual ranker: prefer fits that don't strand tiny unusable leftovers."""
import numpy as np


class _Stats:
    """Tracks a running estimate of the item-size distribution online."""
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.small_frac = 0.25  # fraction of items <= 20 (rough prior)
        self.counts = np.zeros(101, dtype=np.float64)  # histogram of sizes

    def update(self, item):
        self.n += 1
        # exponential-ish running mean
        a = 1.0 / min(self.n, 200)
        self.mean = (1 - a) * self.mean + a * item
        self.counts[item] += 1.0
        # fraction of items <= 20
        small = self.counts[1:21].sum()
        total = self.counts[1:].sum()
        if total > 0:
            self.small_frac = small / total


_STATS = _Stats()


def priority(item, bins):
    """Score each bin by how much *future waste* its leftover capacity implies.

    Idea: after placing the item, the residual r = cap - item remains. A residual is
    "useful" only if some typical future item can still complete the bin nicely.
    We reward residuals that are near the top of the item distribution (so a future
    item can exactly/tightly fill) and punish strandings that are too small.
    """
    _STATS.update(item)

    bins = np.asarray(bins, dtype=np.float64)
    n = bins.size
    residual = bins - item

    # Typical useful item size: use the running mean as a benchmark "good fill" size.
    mean_item = _STATS.mean
    # Below this residual, the leftover is unlikely to be filled well -> waste.
    # We use a fraction of a typical small item as the threshold for "waste".
    waste_threshold = max(6.0, 0.35 * _STATS.small_frac * mean_item + 4.0)

    score = np.empty(n, dtype=np.float64)

    for i in range(n):
        r = residual[i]
        cap = bins[i]

        # tight-fit term: smaller residual (closer to a perfect fill) is better.
        tight = (100.0 - r)  # rewards tightness (r small => high)

        # Waste penalty: if residual is too small to be useful for another item,
        # it is essentially lost capacity.
        if r < waste_threshold:
            waste_pen = (waste_threshold - r) * 1.5
        else:
            # residual useful: mildly reward residuals that look like a full item slot
            # (i.e. residual near mean_item means a typical item fits snugly).
            waste_pen = -min(r, mean_item) * 0.05

        # Reuse bonus: strongly prefer not opening a fresh bin (cap==100).
        reuse = 0.0
        if cap >= 100.0:
            reuse = -40.0
        else:
            reuse = 0.0

        score[i] = tight - waste_pen + reuse

    return score
# EVOLVE-BLOCK-END
