# EVOLVE-BLOCK-START
"""Best-Fit with a large penalty for opening new bins.

score = -(leftover) - NEW_BIN_PENALTY * (bins == capacity)
"""
import numpy as np

_CAP = 100
_NEW_BIN_PENALTY = 50.0


def priority(item, bins):
    bins = np.asarray(bins)
    leftover = bins - item
    score = -leftover.astype(np.float64)
    score[bins >= _CAP] -= _NEW_BIN_PENALTY
    return score
# EVOLVE-BLOCK-END

