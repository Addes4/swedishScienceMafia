# EVOLVE-BLOCK-START
"""Best-fit residual plus online residue-reuse value from histogram mass and CDF fillability."""
import numpy as np


class _State:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)  # histogram of past item sizes
        self.n = 0.0
        self.total = 0.0

    def mean(self):
        return self.total / self.n if self.n > 0 else 40.0


_STATE = _State()


def priority(item, bins):
    st = _STATE

    leftover = bins - item  # post-placement remaining capacity, >= 0

    # Primary: best-fit tightness (prefer small leftovers).
    score = -leftover.astype(np.float64)

    if st.n > 0:
        pdf = st.counts / st.n  # pdf[s] = P(item == s)

        # Exact-match reuse: probability a future item exactly fills the residue.
        sm = pdf.copy()
        sm[1:] += pdf[:-1]
        sm[:-1] += pdf[1:]
        score += 20.0 * sm[leftover]

        # Fillability: probability that a future item fits snugly, i.e. residue is
        # at least ~a small/typical item so it can be usefully reused.
        cdf = np.cumsum(pdf)
        # P(item <= leftover): how likely a future item fits at all.
        fit = cdf[np.clip(leftover, 0, 100)]
        # Reward residues large enough to host a typical small item (good reuse
        # potential), which helps avoid dead fragments.
        score += 3.0 * fit

    # Exact-fit bonus on the current item.
    score += 8.0 * (leftover == 0)

    # Slight preference against opening brand-new bins.
    score += 0.5 * (bins < 100)

    # Update online statistics with the arriving item.
    st.counts[item] += 1.0
    st.n += 1.0
    st.total += item

    return score
# EVOLVE-BLOCK-END
