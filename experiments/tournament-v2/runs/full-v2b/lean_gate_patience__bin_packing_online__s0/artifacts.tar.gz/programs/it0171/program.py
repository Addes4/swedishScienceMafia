# EVOLVE-BLOCK-START
"""Best-fit with prior-calibrated fragmentation (dead-zone) penalty."""
import numpy as np


_STATE = {"hist": np.zeros(101, dtype=np.float64), "n": 0.0}


def priority(item, bins):
    st = _STATE
    st["hist"][item] += 1.0
    st["n"] += 1.0

    leftover = bins - item  # >= 0 for shown bins

    # Dominant: best fit -> prefer small leftover.
    tight = -leftover.astype(np.float64)

    # Reuse bonus: probability a future item snugly fills the leftover.
    hist = st["hist"]
    n = st["n"] if st["n"] > 0 else 1.0
    cum = np.cumsum(hist) / n

    L = leftover
    lo = np.clip((L * 0.5).astype(np.int64), 0, 100)
    hi = np.clip(L.astype(np.int64), 0, 100)
    p_snug = cum[hi] - cum[lo]

    exact = (L == 0).astype(np.float64)
    nonempty = (bins < 100).astype(np.float64)

    # Dead-zone penalty: leaving a tiny leftover (1..14) tends to create an
    # unusable fragment (smaller than most future items), wasting capacity.
    dead = ((L >= 1) & (L <= 14)).astype(np.float64)

    score = tight + 2.0 * p_snug + 3.0 * exact + 0.5 * nonempty - 1.5 * dead
    return score
# EVOLVE-BLOCK-END
