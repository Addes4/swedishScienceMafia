# EVOLVE-BLOCK-START
"""Learned-residual best-fit ranking.

Tightest fit is the dominant term, but ties among similarly tight fits are
broken by the probability that the residual can later be exactly filled by a
future item drawn from the learned item-size histogram.
"""
import numpy as np

_HIST_SIZE = 101
_state = {
    "n": 0,
    "hist": np.zeros(_HIST_SIZE, dtype=np.float64),
}


def _update(item):
    s = _state
    s["n"] += 1
    if 1 <= item <= 100:
        s["hist"][item] += 1.0


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    bins = np.asarray(bins)
    remaining = bins - item
    rem_f = remaining.astype(np.float64)

    # Tightest fit first: smaller leftover is better (dominant term).
    score = -rem_f * 10.0

    # Preference for reusing non-empty bins.
    score += np.where(bins < 100, 2.0, 0.0)

    # Reward exactly filling a bin.
    score += 6.0 * (remaining == 0)

    n = _state["n"]
    if n > 50:
        hist = _state["hist"]
        total = hist.sum()
        if total > 0:
            freq = hist / total
            idx = np.clip(remaining, 0, 100)
            # Probability mass of a future item exactly matching this residual.
            exact = freq[idx]
            # Cumulative mass of items that could still partly use the residual
            # (i.e. items smaller than or equal to the residual), as a proxy
            # for how "usable" the leftover is.
            cdf = np.cumsum(freq)
            usable = cdf[idx]
            bonus = 60.0 * exact + 6.0 * usable
            bonus = np.where(remaining > 0, bonus, 0.0)
            # Keep it subordinate to tightness (max ~ a few units).
            score += np.minimum(bonus, 4.0)
    else:
        # Fallback sliver penalty before we have statistics.
        score -= 3.0 * ((remaining > 0) & (remaining < 6))

    _update(item)
    return score
# EVOLVE-BLOCK-END
