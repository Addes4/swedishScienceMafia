# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a frequency-weighted residue bonus.

Primary signal is strict best-fit (least leftover after placing the item).
On top of that we reward placements whose post-placement residue matches a
likely future item size, where "likely" is measured by the empirical frequency
of that exact size in the observed item histogram (weighted toward the low end
where exact fits matter).  Reuse of open bins strictly dominates the residue
tie-break, so we never open a fresh bin while a fitting one exists.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0
        self.hist = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.n += 1.0
        self.sum += item
        self.hist[item] += 1.0

    @property
    def mean(self):
        if self.n >= 1.0:
            return self.sum / self.n
        return 40.0

    def freq_table(self):
        """Return an array where res[v] ~ probability that a future item is size v."""
        h = self.hist
        total = h.sum()
        if total < 20.0:
            f = np.zeros(101, dtype=np.float64)
            f[5] = f[10] = f[15] = 1.0 / 3.0
            return f
        return h / total


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    b = bins.astype(np.float64)
    unused = b >= 100.0

    resid = b - float(item)

    # Strict best-fit: smaller residue is better (tightest fit).
    fit = -resid / 100.0

    # Frequency-weighted residue reward: how likely is this exact residue value
    # to be filled by a future item?  Weighted toward the low range.
    freq = _stats.freq_table()
    idx = np.clip(resid.astype(np.int64), 0, 100)
    freq_at = freq[idx]
    # Mild low-end emphasis: exact matches on small sizes are most valuable.
    low_weight = 1.0 + 2.0 * (1.0 - np.clip(resid, 0.0, 25.0) / 25.0)
    bonus = 40.0 * freq_at * low_weight

    # Blur to a small neighborhood so near-matches still count a bit.
    shift1 = freq[np.clip(idx + 1, 0, 100)]
    shift2 = freq[np.clip(idx - 1, 0, 100)]
    bonus += 15.0 * (shift1 + shift2) * low_weight

    # Strictly prefer reusing a non-empty bin over opening a fresh one.
    reuse = np.where(unused, 0.0, 1.0)

    score = fit + 0.5 * reuse + bonus

    return score
# EVOLVE-BLOCK-END
