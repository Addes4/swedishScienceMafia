# EVOLVE-BLOCK-START
"""Tight-fit ranker with residue-utility shaping and reuse bias."""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.small_mean = 10.0
        self.n_small = 0

    def update(self, item):
        self.n += 1
        self.mean += (item - self.mean) / self.n
        if item <= 25:
            self.n_small += 1
            self.small_mean += (item - self.small_mean) / self.n_small


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    leftover = (bins - item).astype(np.float64)  # >= 0
    used = (100 - bins).astype(np.float64)

    # Base: prefer tight fit (small leftover).
    score = -leftover

    # Strong bonus for exactly filling a bin.
    score += np.where(leftover == 0.0, 4.0, 0.0)

    # Penalize leaving a residue too small to be usefully filled later.
    # Scale by a typical small item size learned online.
    small = _stats.small_mean
    dead = np.maximum(0.0, small - leftover) * (leftover > 0.0)
    score -= 0.35 * dead

    # Mild bonus for reusing bins that are already substantially full,
    # and for residues that look like a plausible future item size.
    score += 0.05 * used / 100.0

    return score
# EVOLVE-BLOCK-END
