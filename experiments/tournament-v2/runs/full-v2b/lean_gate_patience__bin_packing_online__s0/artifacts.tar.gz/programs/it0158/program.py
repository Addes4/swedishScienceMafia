# EVOLVE-BLOCK-START
"""Best-fit with a mild reuse tie-breaker for online bin packing.

The dominant signal for online packing is best-fit: put the item into the
bin with the smallest leftover that still fits.  We keep that as the primary
term and add only small tie-breakers so that, among bins with similar
leftover, we prefer ones that are already partially used (avoid opening new
bins) and, when the leftovers differ slightly, prefer residues that are
likely to be filled exactly by some future item.
"""
import numpy as np

# ---------------------------------------------------------------- state
_hist = np.zeros(101, dtype=np.float64)      # counts of past item sizes
_n_items = 0

_SIZES = np.arange(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    global _n_items

    bins = np.asarray(bins, dtype=np.float64)
    leftover = bins - float(item)          # >= 0 for all shown bins

    # primary: best fit (smallest leftover)
    tight = -leftover

    # exact fit bonus
    exact = (leftover == 0).astype(np.float64)

    # prefer partially-filled bins to avoid opening new ones
    empty = (bins == 100.0)
    nonempty = np.where(empty, 0.0, 1.0)

    # tie-breaker: probability some past item exactly equals this leftover
    if _n_items > 0:
        r = np.clip(leftover, 0, 100).astype(int)
        reuse = _hist[r] / float(_n_items)
    else:
        reuse = np.zeros_like(leftover)

    score = (
        4.0 * tight
        + 8.0 * exact
        + 0.5 * nonempty
        + 1.0 * reuse
    )

    _hist[item] += 1.0
    _n_items += 1

    return score
# EVOLVE-BLOCK-END
