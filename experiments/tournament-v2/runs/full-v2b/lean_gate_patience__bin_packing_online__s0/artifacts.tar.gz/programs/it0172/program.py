# EVOLVE-BLOCK-START
"""Best-fit with a mean-size feasibility guard on the leftover."""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.total = 0.0

    def add(self, size):
        self.n += 1.0
        self.total += float(size)


_STATE = _Stats()


def priority(item, bins):
    st = _STATE
    st.add(item)
    mean = st.total / st.n if st.n > 0 else 40.0

    leftover = bins.astype(np.float64) - item  # >= 0

    # Tightness: prefer small leftover (best fit).
    tight = -leftover

    # Guard: leftovers below the running mean item size are hard to refill
    # (a typical future item no longer fits snugly) -> add a penalty.
    deficit = np.maximum(mean - leftover, 0.0)

    # Small bonus for reusing already-open bins.
    nonempty = (bins < 100).astype(np.float64)

    # Exact fit is ideal.
    exact = (leftover == 0).astype(np.float64)

    score = tight - 0.5 * deficit + 0.5 * nonempty + 3.0 * exact
    return score
# EVOLVE-BLOCK-END
