# EVOLVE-BLOCK-START
"""Online bin ranker based on residue "fillability" relative to observed items.

We track an online histogram of item sizes.  For a candidate bin we look at the
post-placement leftover r and reward it when r is close to a *likely* future
item size (so the bin can be topped off tightly), and penalize it when r is a
small unusable scrap (smaller than the smallest item seen).  Ties are broken by
tightness (smaller leftover preferred) and reusing already-open bins.
"""
import numpy as np

_CAP = 100
_HIST_MAX = 101
_hist = np.zeros(_HIST_MAX, dtype=np.float64)
_n = 0
_min_seen = _CAP
_common = np.zeros(_HIST_MAX, dtype=np.float64)  # cached common sizes
_last_update = -1


def _ensure():
    """Recompute the set of "common" item sizes from the observed histogram."""
    global _last_update, _common
    if _last_update == _n:
        return
    if _n < 50:
        # Not enough data yet: treat all sizes as roughly equally likely.
        _common[:] = 1.0
        _common[0] = 0.0
    else:
        p = _hist / _n
        _common = (p >= 0.004).astype(np.float64)
        _common[0] = 0.0
        if _common.sum() == 0:
            _common[:] = 1.0
            _common[0] = 0.0
    _last_update = _n


def priority(item, bins):
    global _hist, _n, _min_seen
    _hist[item] += 1.0
    _n += 1
    if item < _min_seen:
        _min_seen = item
    _ensure()

    b = bins.astype(np.float64)
    leftover = b - item
    np.clip(leftover, 0.0, _CAP, out=leftover)
    idx = leftover.astype(np.int64)

    # fillability: 1 if the residue equals some common future item size
    fill = _common[idx]

    # scrap penalty: residue too small to ever be filled
    scrap = (leftover > 0) & (leftover < _min_seen)

    # tightness: prefer smaller leftover (fills bin)
    tight = -leftover

    # reuse existing open bins
    reuse = np.where(b < _CAP, 1.0, 0.0)

    return 4.0 * fill + tight + reuse - 8.0 * scrap
# EVOLVE-BLOCK-END
