# EVOLVE-BLOCK-START
"""Reserve-for-later best fit (reuse-aware)."""
import numpy as np

_STATE = {
    "n": 0,
    "sum": 0.0,
    "min_seen": 101,
    "sizes": [],
}


def _update_state(item):
    _STATE["n"] += 1
    _STATE["sum"] += item
    if item < _STATE["min_seen"]:
        _STATE["min_seen"] = item
    # keep a bounded reservoir of recent sizes for the histogram
    s = _STATE["sizes"]
    s.append(item)
    if len(s) > 400:
        del s[:100]


def priority(item, bins):
    _update_state(item)

    bins = np.asarray(bins, dtype=np.int64)
    n = _STATE["n"]
    mean_item = (_STATE["sum"] / n) if n > 0 else 40.0

    # Empirical histogram of recent item sizes -> probability a residual r is useful
    sizes = np.asarray(_STATE["sizes"], dtype=np.int64)
    hist = np.bincount(sizes, minlength=101).astype(np.float64)
    if hist.sum() == 0:
        hist = np.ones(101)
    hist /= hist.sum()

    remainder = bins - item  # >=0 by contract

    # Probability that a future item fits in the residual (at least one item size <= r)
    # = 1 - P(item > r).  Larger residual -> more reusable.
    cum_gt = np.cumsum(hist)[::-1]  # cum_gt[r] = P(size > r)
    useful = np.clip(1.0 - cum_gt[remainder], 0.0, 1.0)

    # Also reward residuals that several typical items could still hold (expected count)
    expected = remainder / max(mean_item, 1.0)

    # Base: prefer tight fit but primarily reward reusable residuals.
    score = 0.5 * useful + 0.4 * expected - 0.02 * remainder

    # Mild bonus for using an existing bin instead of opening a fresh one.
    used = bins < 100
    score += np.where(used, 0.05, 0.0)

    return score
# EVOLVE-BLOCK-END

