# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with adaptive tiny-residue penalty.

Primary signal is strict best-fit (least leftover after placing the item).
A strong reuse bonus keeps the algorithm from opening a fresh bin when an
already-open bin can take the item, and a mild penalty discourages leaving
a residue too small to be usable by any likely future item.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0
        self.min_item = 100.0
        self.counts = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.n += 1.0
        self.sum += item
        self.counts[int(item)] += 1.0
        if item < self.min_item:
            self.min_item = float(item)

    @property
    def mean(self):
        if self.n >= 1.0:
            return self.sum / self.n
        return 40.0

    def small_frac(self):
        # fraction of items that are small (<= 20), a proxy for usable residues
        if self.n < 1.0:
            return 0.0
        return float(self.counts[:21].sum()) / self.n


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    b = bins.astype(np.float64)
    unused = b >= 100.0

    # Post-placement residue.
    resid = b - float(item)

    # Strict best-fit: smallest non-negative residue preferred (least negative).
    fit = -resid

    # Adaptive tiny-residue threshold: residues below the smallest item seen
    # (bounded) are likely unusable, so penalize them.  Scale the threshold
    # down when small items are common (they can fill tiny gaps) and up when
    # items are bulky.
    sf = _stats.small_frac()
    base = max(1.0, min(20.0, _stats.min_item))
    thr = base * (1.0 - 0.5 * sf)

    tiny = np.where(resid < thr, (thr - resid) / thr, 0.0)

    # Strongly prefer reusing non-empty bins over opening a fresh one.
    reuse = np.where(unused, 0.0, 1.0)

    score = (fit / 100.0) + 0.5 * reuse - 0.15 * tiny

    return score
# EVOLVE-BLOCK-END
