# EVOLVE-BLOCK-START
"""Best-fit with residue shaping controlled by an online size quantile.

The idea: a residual is only "useful" if it is large enough to plausibly hold a
future item.  We track a low quantile of item sizes seen so far (cheap online
estimate).  Among used fitting bins we use strict best-fit, but add a bonus when
the resulting residual is >= this useful threshold, so bins don't get fragmented
into scraps too small to ever help.  Exact fills still get the top bonus.
"""
import numpy as np

_count = 0
_mean = 40.0
# Online estimate of a low quantile of item sizes (roughly the 10th percentile).
_q = 5.0

# Reservoir-free online quantile via a simple decaying min-clone: we track
# several order statistics cheaply by keeping a small sorted sample.
_small = []  # small sorted list of recent small item sizes
_SMALL_CAP = 401


def _update_stats(item):
    global _count, _mean, _q
    _count += 1
    lr = 1.0 / _count if _count < 50 else 0.02
    _mean = (1.0 - lr) * _mean + lr * item

    # Maintain a bounded reservoir-like set of small sizes to estimate a low
    # quantile robustly without storing everything.
    if item <= _q * 2 or len(_small) < _SMALL_CAP:
        _small.append(item)
        _small.sort()
        if len(_small) > _SMALL_CAP:
            # Drop the largest entries to keep it bounded and focused on smalls.
            del _small[_SMALL_CAP:]
    if _small:
        # 10th-percentile-ish index.
        idx = int(0.10 * (len(_small) - 1))
        _q = float(_small[idx])
    if _q < 1.0:
        _q = 1.0


def priority(item, bins):
    """Return a priority per bin; highest wins."""
    _update_stats(item)

    bins = bins.astype(np.int64)
    residual = bins - item  # >=0 for fitting bins
    fits = residual >= 0
    used = bins < 100

    rf = residual.astype(np.float64)
    thresh = _q

    # Base: prefer used bins over empty ones.
    score = used.astype(np.float64) * 1000.0

    # Among used bins, best-fit primary.
    score += np.where(fits, 100.0 - rf, -1000.0)

    # Exact fills are very valuable: close the bin.
    score += np.where(fits & (residual == 0), 50.0, 0.0)

    # Bonus when the leftover is large enough to be useful for a future item.
    useful = fits & used & (residual >= thresh) & (residual > 0)
    score += np.where(useful, 20.0, 0.0)

    # Penalize creating tiny useless scraps (residual in 1..thresh-1).
    scrap = fits & used & (residual > 0) & (residual < thresh)
    score -= np.where(scrap, 30.0, 0.0)

    # Empty bins: tiny gradient so ties resolve to the first empty bin.
    empties = (bins >= 100)
    score += np.where(empties, -rf * 0.001, 0.0)

    return score
# EVOLVE-BLOCK-END
