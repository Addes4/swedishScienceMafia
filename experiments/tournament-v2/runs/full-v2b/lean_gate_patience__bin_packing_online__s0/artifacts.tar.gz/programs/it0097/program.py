# EVOLVE-BLOCK-START
"""Adaptive best-fit with empty-bin reservation and residue-usefulness guard."""
import numpy as np

# Online statistics of arriving item sizes.
_state = {"n": 0, "sum": 0.0, "min_item": 100.0}


def priority(item, bins):
    """Best-fit tightness, with a reuse bonus and a residue-usefulness guard.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in (including unused = 100).
    """
    n = _state["n"] + 1
    _state["sum"] += item
    if item < _state["min_item"]:
        _state["min_item"] = float(item)
    _state["n"] = n

    mean_item = _state["sum"] / n
    # Residues below the smallest item seen are likely unusable.
    thr = max(_state["min_item"], 5.0)

    b = bins.astype(np.float64)
    leftover = b - item  # >= 0

    # Primary: best fit (prefer smallest leftover).
    tight = -leftover

    # Guard: penalize residues too small to be useful later.
    small_pen = np.where((leftover > 0) & (leftover < thr), -(thr - leftover), 0.0)

    # Reuse bonus for non-empty bins; stronger when the residue stays useful
    # (so we don't waste near-full bins on tiny items while keeping flexible ones).
    reuse = np.where(b < 100, 1.0, 0.0)
    useful_residue = np.where(leftover >= mean_item, 1.0, 0.0)

    return tight + 0.6 * small_pen + 3.0 * reuse + 1.5 * useful_residue
# EVOLVE-BLOCK-END
