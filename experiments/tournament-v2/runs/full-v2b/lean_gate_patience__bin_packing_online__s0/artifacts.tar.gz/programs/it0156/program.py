# EVOLVE-BLOCK-START
"""Value-of-residue ranker for online bin packing.

For each candidate bin we compute the post-placement leftover r = bins - item.
We score the bin by combining:
  * a tightness term (prefer small leftover),
  * an empirical "usefulness" of the leftover, estimated online from a
    histogram of previously seen item sizes: a leftover is useful if a
    future item is likely to fit in it (and, ideally, fit snugly),
  * a small extra bonus for exact fits (leftover == 0),
  * a mild bonus for already-non-empty bins to discourage opening new bins.
"""
import numpy as np


# ---------------------------------------------------------------- state
_hist = np.zeros(101, dtype=np.float64)      # counts of past item sizes
_n_items = 0

# precomputed constants
_SIZES = np.arange(101, dtype=np.float64)


def _snug_prob(r):
    """Probability (empirical) that a future item leaves leftover r when
    placed into an empty-or-larger bin -- approximated by P(item <= r)
    combined with a preference for items that nearly fill r.

    Returns a value in [0, 1] roughly measuring how 'useful' leftover r is.
    """
    if r <= 0:
        return 0.0
    if _n_items == 0:
        # no data: fall back to a simple monotone prior
        return min(1.0, r / 50.0)

    counts = _hist[1:int(r) + 1]              # items that fit in r
    total = _n_items
    p_fit = counts.sum() / total

    # snugness: among items that fit, how close do they get to r?
    if counts.sum() > 0:
        sizes = _SIZES[1:int(r) + 1]
        fill = (counts * sizes).sum() / (counts.sum() * r)   # mean fill ratio
    else:
        fill = 0.0

    return p_fit * fill


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    global _n_items

    bins = np.asarray(bins, dtype=np.float64)
    leftover = bins - float(item)          # can be >= 0 for all shown bins

    # tightness: smaller leftover -> higher score
    tight = -leftover

    # usefulness of the resulting leftover (vectorised)
    r = leftover
    r_safe = np.clip(r, 0, None).astype(int)

    if _n_items == 0:
        useful = np.minimum(1.0, r / 50.0)
    else:
        total = float(_n_items)
        # p_fit[r] = P(item <= r)
        cum = np.cumsum(_hist)
        p_fit = cum[r_safe] / total
        # mean fill ratio for items fitting in r
        weighted = np.concatenate(([0.0], np.cumsum(_hist * _SIZES)))
        sums = weighted[r_safe]                       # sum of sizes <= r
        cnts = cum[r_safe]
        with np.errstate(divide="ignore", invalid="ignore"):
            fill = np.where(cnts > 0, sums / (cnts * np.maximum(r_safe, 1)), 0.0)
        useful = p_fit * fill

    # exact fits are especially valuable
    exact = (r == 0).astype(np.float64)

    # discourage opening brand-new bins (leftover == 100 - item means empty bin)
    empty = (bins == 100.0)
    nonempty_bonus = np.where(empty, 0.0, 1.0)

    score = (
        2.0 * tight                 # primary: best fit tendency
        + 40.0 * useful             # reward leftovers that can be reused snugly
        + 30.0 * exact              # prefer perfect fits
        + 3.0 * nonempty_bonus      # mild preference to fill existing bins
    )

    # ---- online statistics update (after scoring, item is about to be placed)
    _hist[item] += 1.0
    _n_items += 1

    return score
# EVOLVE-BLOCK-END
