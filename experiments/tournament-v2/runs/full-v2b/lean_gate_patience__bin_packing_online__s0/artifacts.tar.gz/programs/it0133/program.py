# EVOLVE-BLOCK-START
"""Best-fit with reuse preference, exact-fit emphasis, and small-scrap penalty."""
import numpy as np


def priority(item, bins):
    residual = bins - item

    # Base: tightest fit (smaller residual => higher score).
    score = -residual.astype(np.float64)

    # Strong bonus for reusing already-open bins over fresh ones.
    used = bins < 100
    score += np.where(used, 500.0, 0.0)

    # Emphasize exact fits.
    score += np.where(residual == 0, 200.0, 0.0)

    # Mild penalty for leaving a tiny scrap in a used bin (residual small but nonzero).
    tiny = used & (residual > 0) & (residual < 10)
    score -= np.where(tiny, 5.0, 0.0)

    return score
# EVOLVE-BLOCK-END
