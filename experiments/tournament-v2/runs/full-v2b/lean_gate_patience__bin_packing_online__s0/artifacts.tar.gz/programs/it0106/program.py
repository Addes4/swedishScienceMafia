# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a dual critical-residue bonus.

Primary signal is strict best-fit (least leftover after placing the item).
We add a bonus when the post-placement residue is near a small "critical"
size (estimated online from the low end of observed items) or near an
mid-range target, so bins tend to be left with gaps sized for likely future
items. A strong reuse bonus keeps us from opening fresh bins unnecessarily.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0
        self.min_item = 100.0
        self.small_sum = 0.0
        self.small_n = 0.0

    def update(self, item):
        self.n += 1.0
        self.sum += item
        if item < self.min_item:
            self.min_item = float(item)
        if item <= 45:
            self.small_sum += item
            self.small_n += 1.0

    @property
    def mean(self):
        if self.n >= 1.0:
            return self.sum / self.n
        return 40.0

    @property
    def small_mean(self):
        if self.small_n >= 1.0:
            return self.small_sum / self.small_n
        return 20.0


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    b = bins.astype(np.float64)
    unused = b >= 100.0

    # Post-placement residue.
    resid = b - float(item)

    # Strict best-fit: smaller residue is better (tightest fit).
    fit = -resid

    # Critical residue: small gap that a likely future small item can fill.
    crit_small = max(1.0, min(15.0, _stats.min_item))
    near_small = np.abs(resid - crit_small)

    # Secondary target: mid-range gap.
    crit_mid = max(10.0, min(40.0, _stats.small_mean))
    near_mid = np.abs(resid - crit_mid)

    # Strongly prefer reusing non-empty bins over opening a fresh one.
    reuse = np.where(unused, 0.0, 1.0)

    score = (fit / 100.0) + 0.5 * reuse \
            - 0.10 * (near_small / 100.0) \
            - 0.04 * (near_mid / 100.0)

    return score
# EVOLVE-BLOCK-END
