# EVOLVE-BLOCK-START
"""Dual-criterion ranker: best-fit tightness plus online residue-match bonus.

Primary: prefer smallest resulting leftover (classic best fit).
Secondary (comparably weighted): reward leftovers r whose value matches a
size with high empirical mass, since such a hole is likely to be filled
exactly by a future item.  Weights are tuned so the residue signal wins
ties among bins with similar tightness.
"""
import numpy as np

_state = {
    "n": 0,
    "hist": np.zeros(101, dtype=np.float64),
}


def priority(item, bins):
    _state["n"] += 1
    _state["hist"][item] += 1.0

    n = _state["n"]
    mass = _state["hist"] / n  # empirical pmf over sizes 1..100

    rem = bins.astype(np.float64)
    leftover = rem - item  # >= 0

    # Primary: tightness.  Scale leftover down so it acts as a strong tiebreak
    # but leaves room for the residue signal to matter.
    score = -leftover * 0.5

    # Residue reuse: mass of the pmf at the exact leftover value.
    idx = np.clip(leftover.astype(np.int64), 0, 100)
    score += mass[idx] * 60.0

    # Exact-fit bonus.
    score += np.where(leftover == 0, 1.5, 0.0)

    return score
# EVOLVE-BLOCK-END
