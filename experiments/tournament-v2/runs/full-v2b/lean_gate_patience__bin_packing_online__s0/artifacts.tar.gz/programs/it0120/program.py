# EVOLVE-BLOCK-START
"""Online bin choice: Best-Fit plus a mild online-learned residue-match bonus.

Primary rule: classic Best-Fit (minimize residual among bins that fit), with a strong
penalty for opening a fresh bin. Secondary: a small bonus for leaving a residual that
matches a size we have recently seen online, so future items can close bins exactly.
"""
import numpy as np

# Decayed histogram of seen item sizes (index 1..100).
_hist = np.zeros(101, dtype=np.float64)
_decay = 0.999
_since_decay = 0


def priority(item, bins):
    global _since_decay
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item

    # Update online size histogram with mild exponential decay.
    _hist *= _decay
    _hist[item] += 1.0

    # Best-fit primary: smaller residual -> larger score.
    score = -residual

    # Reward residues that are likely to be matched exactly by a future item.
    # Only used bins (residual < capacity - item) get this; it is a small bonus.
    used = bins < 100.0
    res_idx = np.clip(residual.astype(np.int64), 0, 100)
    match = _hist[res_idx]
    # Normalize the bonus so it never dominates best-fit differences.
    bonus_scale = 1.0 / (1.0 + _hist.sum()) * 2000.0
    score = score + np.where(used, match * bonus_scale, 0.0)

    # Strong reuse preference: penalize opening/using a fresh (empty) bin.
    score = np.where(bins >= 100.0, score - 10000.0, score)

    return score
# EVOLVE-BLOCK-END
