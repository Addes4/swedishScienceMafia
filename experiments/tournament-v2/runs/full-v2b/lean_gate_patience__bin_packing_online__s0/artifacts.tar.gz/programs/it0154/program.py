# EVOLVE-BLOCK-START
"""Value-of-residue online bin choice (calibrated prior + tight fit).

For each bin we rank the post-placement leftover. We prefer (a) exact fits strongly, and
(b) otherwise tight fits, plus a bonus proportional to the empirical probability that the
leftover can still be filled by some future item. That probability is estimated by blending
an online histogram of observed items with a smooth prior (a Weibull-shaped density with
mean ~40, the known item distribution), so the estimate is well-calibrated from the very
first item and still adapts as counts accumulate.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)   # counts of item sizes seen so far
_N = 0.0                                  # number of items seen so far

# Smooth prior over item sizes 1..100 (Weibull-shaped, mean ~40), built once.
_PRIOR_W = np.zeros(101, dtype=np.float64)
for _s in range(1, 101):
    _x = (_s - 0.5) / 100.0
    _PRIOR_W[_s] = (_x ** 0.6) * np.exp(-(_x ** 1.9))
_PRIOR_W /= _PRIOR_W.sum()
_PRIOR_STRENGTH = 200.0                   # pseudo-count mass of the prior

_ALPHA = 20.0                             # weight for residue usefulness
_PERFECT = 60.0                           # bonus for an exact (zero-leftover) fit


def priority(item, bins):
    """Return a score for every bin; item goes to the highest score (first on ties)."""
    global _N

    leftover = bins - item  # numpy int64 array, >= 0 for every bin shown

    # Blended CDF: prior pseudo-counts plus observed counts, normalized.
    counts = _HIST + _PRIOR_STRENGTH * _PRIOR_W
    total = counts.sum()
    cdf = np.cumsum(counts) / total

    idx = np.clip(leftover, 0, 100).astype(np.int64)
    usefulness = cdf[idx]

    score = -leftover.astype(np.float64) + _ALPHA * usefulness
    score[leftover == 0] += _PERFECT

    # Update online statistics with the item just observed (not used for this decision).
    _HIST[item] += 1.0
    _N += 1.0

    return score
# EVOLVE-BLOCK-END
