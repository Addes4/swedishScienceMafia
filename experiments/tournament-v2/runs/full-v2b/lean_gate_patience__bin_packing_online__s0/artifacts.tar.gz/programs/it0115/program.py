# EVOLVE-BLOCK-START
"""Online bin packing: strict best-fit with open-bin reuse.

The item is placed into the bin that leaves the smallest post-placement
residue (tightest fit), which is the principled optimum for online packing.
Opening a fresh bin is only chosen when no open bin fits better. This removes
fragile, hand-tuned residue bonuses and lets tightest-fit dominate.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    b = bins.astype(np.float64)

    # Post-placement residue.
    resid = b - float(item)

    # Strict best-fit: smaller residue is better (tightest fit).
    fit = -resid

    # Strictly prefer reusing a non-empty bin over opening a fresh one.
    unused = b >= 100.0
    reuse = np.where(unused, 0.0, 1.0)

    # reuse term dominates by a large constant; ties among open bins fall to fit.
    return fit + 1000.0 * reuse
# EVOLVE-BLOCK-END

