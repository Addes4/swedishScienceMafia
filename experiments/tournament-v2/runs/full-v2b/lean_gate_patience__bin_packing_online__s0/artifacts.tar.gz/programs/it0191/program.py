import numpy as np


class _Stats:
    """Online histogram of item sizes for residue usefulness estimation."""
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def add(self, item):
        self.counts[item] += 1.0
        self.total += 1.0

    def usefulness(self, residue):
        # Fraction of past items that fit snugly into `residue` (size <= residue).
        # Dead-zone residues (too small to fit many items) get low value.
        if self.total < 1.0:
            return 0.0
        if residue < 1:
            return 0.0
        r = int(residue)
        if r > 100:
            r = 100
        fitting = self.counts[1:r + 1].sum()
        return fitting / self.total


_stats = _Stats()


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.float64)
    leftovers = bins - item

    # Tightness: prefer small leftover.  -(leftover) dominates.
    scores = -leftovers

    # Value of residue: a leftover is more valuable if future items are likely to fit it.
    # Apply only to actually-usable residues (>= 1). Scale by small weight so tightness dominates.
    usable = leftovers >= 1
    if _stats.total > 0.0:
        val = np.zeros_like(leftovers)
        r_int = np.clip(leftovers.astype(np.int64), 0, 100)
        # cumulative count of past items <= r, vectorized
        cum = np.concatenate(([0.0], np.cumsum(_stats.counts)))
        val = cum[r_int + 1] / _stats.total
        scores = scores + 5.0 * val * usable

    # Exact fit bonus.
    scores = scores + np.where(leftovers == 0, 1e6, 0.0)

    # Mild bonus to non-empty bins (avoid opening fresh bins when possible).
    nonempty_bonus = 0.01 * (bins < 100.0)
    scores = scores + nonempty_bonus

    _stats.add(item)
    return scores
