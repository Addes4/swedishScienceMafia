# EVOLVE-BLOCK-START
"""Best-fit core with a strong anti-new-bin bias and a mild dead-zone residual penalty."""
import numpy as np

_STATE = {"n": 0, "sum": 0.0}


def priority(item, bins):
    bins = np.asarray(bins)

    st = _STATE
    st["n"] += 1
    st["sum"] += item
    mean = st["sum"] / st["n"]

    leftover = bins - item  # remaining capacity after placing the item

    # Best fit: prefer the tightest fit (smallest leftover).
    score = -leftover.astype(np.float64)

    # Mild penalty for residuals in the "dead zone": nonzero but too small to
    # be reliably filled by a later typical item. Keeps bins near-full instead.
    threshold = min(mean, 30.0)
    dead = (leftover > 0) & (leftover < threshold)
    score -= np.where(dead, (threshold - leftover) * 0.15, 0.0)

    # Strongly discourage opening a brand-new bin unless the fit is very good.
    is_new = bins >= 100
    score -= np.where(is_new, 8.0, 0.0)

    return score


def _reset():
    _STATE["n"] = 0
    _STATE["sum"] = 0.0
# EVOLVE-BLOCK-END
