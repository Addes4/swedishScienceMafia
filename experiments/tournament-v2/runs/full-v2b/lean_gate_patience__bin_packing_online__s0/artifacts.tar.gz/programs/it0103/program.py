# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with adaptive low-percentile residue penalty.

Primary signal is strict best-fit (least leftover after placing the item).
A strong reuse bonus keeps the algorithm from opening a fresh bin when an
already-open bin can take the item, and a mild penalty discourages leaving
a residue too small to be usable by any likely future item. The penalty
threshold is an online estimate of a low percentile of the item-size
distribution (more robust than the running minimum).
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0
        self.hist = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.n += 1.0
        self.sum += item
        if 1 <= item <= 100:
            self.hist[item] += 1.0

    @property
    def mean(self):
        if self.n >= 1.0:
            return self.sum / self.n
        return 40.0

    def low_percentile(self, p=0.10, default=5.0):
        total = self.hist.sum()
        if total < 20.0:
            return default
        cum = np.cumsum(self.hist)
        target = p * total
        idx = int(np.searchsorted(cum, target))
        if idx < 1:
            idx = 1
        if idx > 100:
            idx = 100
        return float(idx)


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    b = bins.astype(np.float64)
    unused = b >= 100.0

    # Post-placement residue.
    resid = b - float(item)

    # Strict best-fit: smallest non-negative residue preferred (least negative).
    fit = -resid

    # Adaptive tiny-residue threshold: low percentile of observed item sizes,
    # bounded to a sane range. Residues below it are likely unusable.
    thr = _stats.low_percentile(0.10, default=5.0)
    thr = max(1.0, min(20.0, thr))

    tiny = np.where(resid < thr, (thr - resid) / thr, 0.0)

    # Strongly prefer reusing non-empty bins over opening a fresh one.
    reuse = np.where(unused, 0.0, 1.0)

    score = (fit / 100.0) + 0.5 * reuse - 0.20 * tiny

    return score
# EVOLVE-BLOCK-END
