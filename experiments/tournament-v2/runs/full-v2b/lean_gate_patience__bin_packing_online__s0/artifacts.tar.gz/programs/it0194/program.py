import numpy as np


class _Stats:
    """Online histogram of item sizes for residue usefulness estimation."""
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def add(self, item):
        self.counts[item] += 1.0
        self.total += 1.0

    def cum(self):
        # cumulative count of past items <= r, for r in 0..100
        return np.concatenate(([0.0], np.cumsum(self.counts)))


_stats = _Stats()

# weight for the residue-usefulness term relative to tightness (tightness has unit scale)
_W_VAL = 8.0


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.float64)
    leftovers = bins - item

    # Tightness: prefer small leftover.
    scores = -leftovers

    # Residue value: probability a future item fits into the leftover.
    # This rewards keeping residues that are actually usable.
    if _stats.total > 0.0:
        cum = _stats.cum()
        r_int = np.clip(leftovers.astype(np.int64), 0, 100)
        val = cum[r_int + 1] / _stats.total
        scores = scores + _W_VAL * val * (leftovers >= 1)

    # Exact fit bonus.
    scores = scores + np.where(leftovers == 0, 1e6, 0.0)

    # Mild bonus to non-empty bins (avoid opening fresh bins when possible).
    scores = scores + 0.01 * (bins < 100.0)

    _stats.add(item)
    return scores
