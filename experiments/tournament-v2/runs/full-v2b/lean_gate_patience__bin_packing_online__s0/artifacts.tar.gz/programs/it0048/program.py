# EVOLVE-BLOCK-START
"""Best-fit ranker with histogram-aware residual-consolidation bonuses."""
import numpy as np

_H = np.zeros(101, dtype=np.float64)   # hist of item sizes seen
_N = 0.0


def priority(item, bins):
    global _N
    _H[item] += 1.0
    _N += 1.0

    leftover = (bins - item).astype(np.float64)   # >= 0 for fitting bins
    left_int = np.clip(leftover, 0, 100).astype(np.int64)

    # Empirical probability of a future item size s
    total = _N + 1.0
    probs = (_H + 0.05) / total

    # Probability that a residual R is exactly filled by some future item.
    exact = probs[left_int]
    # Expected wasted space ratio when a single item is placed into residual R.
    sizes = np.arange(101, dtype=np.float64)
    weighted = probs * sizes
    cw = np.cumsum(weighted)
    exp_fill = cw[left_int]        # expected mass of one future item that fits

    # Primary: tightest leftover (best fit).
    score = -leftover
    # Strong reward for a residual that can be exactly filled (waste-free reuse).
    score += 3.0 * exact
    # Mild reward for residuals retaining useful mass.
    score += 0.4 * exp_fill
    # Discourage opening a brand new bin.
    score += np.where(bins == 100, -1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
