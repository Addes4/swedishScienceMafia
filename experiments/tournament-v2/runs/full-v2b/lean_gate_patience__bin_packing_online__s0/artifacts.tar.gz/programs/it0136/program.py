# EVOLVE-BLOCK-START
"""Best-fit with reuse preference plus a soft 'seal it shut' bonus for near-full bins."""
import numpy as np

_state = {"n": 0, "small": 10.0}


def priority(item, bins):
    # Track a rough lower quantile of item sizes seen so far (small-item threshold).
    n = _state["n"]
    _state["n"] = n + 1
    # Exponential-ish update toward the minimum-ish of observed small sizes.
    s = _state["small"]
    if item < s:
        s = s - (s - item) * 0.05
    else:
        s = s + (s * 0.0002)
    if s < 1.0:
        s = 1.0
    _state["small"] = s

    residual = bins - item

    # Base: tightest fit.
    score = -residual.astype(np.float64)

    used = bins < 100
    # Strong bonus for reusing already-open bins over empty ones.
    score += np.where(used, 1000.0, 0.0)

    # Extra: among used bins, mildly prefer those that would be nearly sealed
    # (leftover very small => unlikely reusable => better to finish them off).
    sealable = used & (residual <= s)
    score += np.where(sealable, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
