# EVOLVE-BLOCK-START
"""Adaptive best-fit / worst-fit hybrid.

For small items (relative to the empirical mean) best-fit minimizes wasted
residual and is near-optimal. For large items, best-fit tends to create many
tiny unusable slivers, so a mild worst-fit among bins that still fit helps
consolidate residuals. We switch based on the running mean of past items and
keep the rule deterministic (no future knowledge).
"""
import numpy as np

_STATE = {
    "n": 0,
    "sum": 0.0,
}

_TIGHT = 1000.0


def _update_state(item):
    _STATE["n"] += 1
    _STATE["sum"] += item


def priority(item, bins):
    _update_state(item)

    bins = np.asarray(bins, dtype=np.int64)
    n = _STATE["n"]
    mean_item = (_STATE["sum"] / n) if n > 0 else 40.0

    remainder = bins - item          # residual if placed here (>=0)
    rem_f = remainder.astype(np.float64)

    # Large-item regime: prefer larger residuals (worst-fit) to avoid slivers.
    if item > mean_item:
        score = rem_f  # larger residual preferred
        # But still strongly prefer an existing partially-filled bin over
        # opening a brand-new one (residual 100 - item).
        new_res = 100.0 - item
        is_fresh = (bins == 100)
        score = score - 0.5 * is_fresh
        return score

    # Small-item regime: tightest fit dominates.
    score = -_TIGHT * rem_f
    typical = max(1.0, mean_item * 0.5)
    usable = np.minimum(1.0, rem_f / typical)
    score += 1.0 * usable
    score += np.where(remainder == 0, 0.5, 0.0)
    return score
# EVOLVE-BLOCK-END
