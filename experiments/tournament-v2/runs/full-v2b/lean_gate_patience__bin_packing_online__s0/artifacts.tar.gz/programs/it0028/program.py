# EVOLVE-BLOCK-START
"""Tightest-fit with scale-aware reuse bonus.

Scores each bin by how tight the fit is (small leftover preferred), with a
bonus for reusing partially filled bins that scales with how full the bin is
relative to capacity, plus a small reward for exactly filling a bin.
"""
import numpy as np

_state = {
    "n": 0,
    "hist": np.zeros(101, dtype=np.float64),
}


def _update(item):
    s = _state
    s["n"] += 1
    if 1 <= item <= 100:
        s["hist"][item] += 1.0


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    bins = np.asarray(bins)
    remaining = bins - item
    rem_f = remaining.astype(np.float64)

    # Tightest fit first: smaller leftover is better (dominant term).
    score = -rem_f * 10.0

    # Scale-aware reuse bonus: prefer non-empty bins, scaled by fullness.
    fullness = (100.0 - rem_f) / 100.0
    non_empty = (bins < 100)
    score += np.where(non_empty, 3.0 * fullness, 0.0)

    # Reward exactly filling a bin.
    score += 5.0 * (remaining == 0)

    # Mild penalty for dead slivers that no typical future item can use.
    score -= 2.0 * ((remaining > 0) & (remaining < 6))

    _update(item)
    return score
# EVOLVE-BLOCK-END
