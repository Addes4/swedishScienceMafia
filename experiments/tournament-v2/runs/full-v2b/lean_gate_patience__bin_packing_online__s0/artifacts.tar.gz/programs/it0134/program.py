# EVOLVE-BLOCK-START
"""Best-fit with reuse preference plus a bonus for leftovers matching common item sizes."""
import numpy as np

_MAXHIST = 101
_count = np.zeros(_MAXHIST, dtype=np.float64)


def priority(item, bins):
    global _count
    _count[item] += 1.0
    # Decayed histogram, mode as the most common item size.
    if _count.sum() > 20000.0:
        _count *= 0.5
    mode = int(np.argmax(_count))

    residual = bins - item
    score = -residual.astype(np.float64)

    used = bins < 100
    score += np.where(used, 1000.0, 0.0)

    # Reward leftovers that match a common item size (useful scraps).
    useful = (residual == mode) | (residual == 0)
    score += np.where(used & useful, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
