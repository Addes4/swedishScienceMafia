# EVOLVE-BLOCK-START
"""Quadratic-tightness ranker (sum-of-squares proxy) with exact-fit bonus.

Items go into the bin minimizing the resulting residue, but with a nonlinear
penalty on the residue that mimics reducing the sum of squared residual capacity.
A separate large bonus is given to exact fills.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    diff = bins - item  # leftover residue after placement, >= 0 for fitting bins

    d = diff.astype(np.float64)
    # Quadratic tightness: strongly prefer bins that end up nearly full.
    # -(d) is linear best-fit; -d*d pushes harder toward full bins, like
    # minimizing the sum of squared residual capacities.
    score = -d - 0.05 * d * d

    # Exact fill gets a clear extra reward.
    exact = (d == 0).astype(np.float64)
    score += 2.0 * exact

    return score
# EVOLVE-BLOCK-END
