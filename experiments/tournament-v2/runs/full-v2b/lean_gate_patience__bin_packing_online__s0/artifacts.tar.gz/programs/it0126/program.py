# EVOLVE-BLOCK-START
"""Best-fit with reuse and online small-residue shaping."""
import numpy as np

_count = 0
_small = 8.0          # running estimate of a typical small item size
_min = 100.0          # running min-ish small size


def _update_stats(item):
    global _count, _small, _min
    _count += 1
    # decayed estimate of typical small item size (low quantile-ish)
    if item < _small or _count < 30:
        _small = 0.8 * _small + 0.2 * item
    else:
        _small = 0.999 * _small + 0.001 * item
    if item < _min:
        _min = item
    elif _count > 100:
        _min = min(100.0, _min * 1.0005 + 0.01)


def priority(item, bins):
    """Return a priority per bin; highest wins."""
    _update_stats(item)

    residual = bins.astype(np.int64) - item
    fits = residual >= 0
    used = bins < 100

    score = used.astype(np.float64) * 1000.0
    rf = residual.astype(np.float64)
    score += np.where(fits, 100.0 - rf, -1000.0)

    # Exact-fill bonus.
    score += np.where(fits & (residual == 0), 50.0, 0.0)

    # Prefer residuals close to a typical small item size (so a later small
    # item can close the bin), but only among fitting used bins with a
    # nonzero residual.
    s = _small
    if s < 1.0:
        s = 1.0
    close = np.abs(rf - s)
    bonus = np.where(fits & used & (residual > 0), -close * 0.02, 0.0)
    score += bonus

    empties = bins >= 100
    score += np.where(empties, -np.abs(rf) * 0.001, 0.0)

    return score
# EVOLVE-BLOCK-END
