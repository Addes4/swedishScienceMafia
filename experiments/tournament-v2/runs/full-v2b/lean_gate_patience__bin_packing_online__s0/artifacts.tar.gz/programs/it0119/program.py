# EVOLVE-BLOCK-START
"""Online bin choice: classic Best-Fit with open-bin reuse preference."""
import numpy as np


def priority(item, bins):
    """Score each bin: among bins that fit, prefer the tightest residual.

    Bins with remaining capacity 100 are untouched/empty. We strongly penalize
    them so a fresh bin is opened only when no already-used bin can take the item.
    """
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item

    # Best-fit: maximize score => minimize residual among used bins.
    score = -residual

    # Strong reuse preference: penalize opening/using a fresh (empty) bin.
    score = np.where(bins >= 100.0, score - 10000.0, score)

    return score
# EVOLVE-BLOCK-END
