# EVOLVE-BLOCK-START
"""Adaptive best-fit with dust penalty: avoid creating unusable tiny leftovers."""
import numpy as np


class _Stats:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.n = 0.0
        self.min_seen = 101.0
        self.total = 0.0

    def add(self, size):
        self.hist[size] += 1.0
        self.n += 1.0
        self.total += size
        if size < self.min_seen:
            self.min_seen = size


_STATE = _Stats()


def priority(item, bins):
    st = _STATE
    st.add(item)

    leftover = bins - item  # >= 0 for all shown bins
    L = leftover.astype(np.float64)

    # Minimum item size observed so far; a leftover below this is "dust" that
    # likely cannot be reused by any single future item.
    m = st.min_seen if st.min_seen <= 100.0 else 1.0
    if m < 1.0:
        m = 1.0

    # Dust: leftover smaller than the smallest item seen so far -> probably wasted.
    dust = (L < m).astype(np.float64)

    # Tightness: prefer small leftover (best fit).
    tight = -L

    # Exact fit: leftover that a future item can perfectly fill (best reward).
    exact = (L == 0).astype(np.float64)

    # Non-empty bin bonus: discourage opening new bins.
    nonempty = (bins < 100).astype(np.float64)

    # Level bonus: mildly prefer leaving a "round" large remaining capacity so
    # that bins stay reusable. Reward remainders that are multiples of common
    # item sizes is hard online; instead gently reward larger leftovers among
    # non-dust options to keep bins open for reuse.
    score = tight + 2.0 * exact + 0.4 * nonempty - 6.0 * dust
    return score
# EVOLVE-BLOCK-END
