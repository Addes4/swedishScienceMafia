# EVOLVE-BLOCK-START
"""Best-fit with reuse preference: tightest fit, strongly favor open bins over fresh ones."""
import numpy as np


def priority(item, bins):
    residual = bins - item

    # Base: tightest fit (smaller residual => higher score). Exact fit residual 0 dominates.
    score = -residual.astype(np.float64)

    # Strong bonus for reusing already-open bins (remaining capacity < 100 means bin in use).
    used = bins < 100
    score += np.where(used, 1000.0, 0.0)

    return score
# EVOLVE-BLOCK-END

