# EVOLVE-BLOCK-START
"""Best fit with a mild preference for already-used bins to delay opening new bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer tightest fit (smallest residual).
    # Tie-break nudge: penalize unused bins (residual == 100 - item means bin was empty).
    empty_residual = 100 - item
    is_empty = bins == 100
    score = -residual - 1e-6 * is_empty * (empty_residual + 1)
    return score
# EVOLVE-BLOCK-END
