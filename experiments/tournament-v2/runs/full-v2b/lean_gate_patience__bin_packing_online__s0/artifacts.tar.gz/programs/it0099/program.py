# EVOLVE-BLOCK-START
"""Online bin packing: multi-criteria ranker.

Blends tight-fit tightness with a residue-utility penalty based on the
empirical distribution of items seen so far, plus a mild reuse bonus
for already-non-empty bins to discourage opening new bins unnecessarily.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0
        self.sum_sq = 0.0
        self.small = 0.0  # count of items <= 20
        self.last_mean = 40.0
        self.last_small_frac = 0.25

    def update(self, item):
        self.n += 1.0
        self.sum += item
        self.sum_sq += float(item) * float(item)
        if item <= 20:
            self.small += 1.0
        if self.n >= 1.0:
            self.last_mean = self.sum / self.n
        if self.n >= 1.0:
            self.last_small_frac = self.small / self.n


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    n = _stats.n
    mean = _stats.last_mean
    small_frac = _stats.last_small_frac

    # Variance estimate for the empirical item distribution.
    if n >= 2.0:
        var = max(0.0, _stats.sum_sq / n - mean * mean)
    else:
        var = 250.0
    std = var ** 0.5

    # Typical "useful" residue: residues should be big enough for a likely future item.
    # Use a blend of mean and a quantile-ish estimate from small_frac.
    # If many small items, smaller residues are still useful.
    typical = mean
    # Penalty threshold: residues below this become increasingly unattractive.
    thr = max(1.0, 0.35 * typical + 0.15 * std)

    b = bins.astype(np.float64)
    unused = (b >= 100.0)

    fit = -(b - item)  # tightest fit => highest fit value (less negative)

    # Residue after placing the item.
    resid = b - float(item)

    # Utility of residue: low if residue is small (hard to reuse),
    # but also slightly penalize very large residues (wastes big bins early).
    # Smooth utility in [0,1].
    util = resid / (resid + thr)
    # Mild preference for moderately large residues is captured by util monotonicity.
    # Penalize very small residues more sharply:
    tiny = np.where(resid < thr, (thr - resid) / thr, 0.0)

    # Reuse bonus: strongly prefer filling existing non-empty bins over opening new ones.
    reuse = np.where(unused, 0.0, 1.0)

    # Scale factors relative to item capacity.
    scale = 100.0
    score = (
        0.30 * (fit / scale)
        + 0.25 * util
        - 0.25 * tiny
        + 0.20 * reuse
    )

    return score
# EVOLVE-BLOCK-END
