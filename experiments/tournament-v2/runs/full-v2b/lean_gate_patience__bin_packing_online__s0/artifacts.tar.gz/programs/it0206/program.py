# EVOLVE-BLOCK-START
"""Value-of-residue ranker: prefer tight fits, but reward leftovers that past items
could slot into snugly, using an online histogram of observed item sizes."""
import numpy as np

_CAP = 100
_HIST = np.zeros(_CAP + 1, dtype=np.float64)  # counts of observed item sizes
_SEEN = 0


def priority(item, bins):
    """Score each bin; item goes to the highest-scoring bin (first on ties).

    item: integer size 1..100.
    bins: numpy int64 remaining capacities of all bins the item fits in.
    """
    global _SEEN

    # Update online histogram with the current item (it is a past item for future calls).
    _HIST[item] += 1.0
    _SEEN += 1

    # Probability mass of observed items, smoothed with a uniform prior.
    total = _SEEN + _CAP
    probs = (_HIST + 1.0) / total  # length _CAP+1

    # For a leftover capacity c after placing the item, estimate usefulness:
    # expected best snug fit = probability that some future item is close to c.
    # We sum probability mass of items in a window [c-8, c] scaled by closeness.
    idx = np.arange _CAP + 1  # placeholder to keep line simple

    bins_f = bins.astype(np.float64)
    leftover = bins_f - float(item)

    # Build score vector.
    scores = np.empty(bins_f.shape[0], dtype=np.float64)
    for i in range(bins_f.shape[0]):
        c = leftover[i]
        tight = -(c)  # prefer tight fit
        exact = 1.0 if c == 0.0 else 0.0
        # usefulness of this residue: how much probability mass of past items
        # lies in a snug window around c.
        if c <= 0.0:
            useful = 0.0
        else:
            lo = int(max(0, c - 8))
            hi = int(min(_CAP, c))
            if hi >= lo:
                window = probs[lo:hi + 1]
                w = np.arange(window.shape[0], dtype=np.float64) + 1.0
                useful = float(np.sum(window * w)) / 8.0
            else:
                useful = 0.0
        nonempty = 1.0 if bins_f[i] < _CAP else 0.0
        scores[i] = tight + 6.0 * useful + 4.0 * exact + 0.5 * nonempty

    return scores
# EVOLVE-BLOCK-END
