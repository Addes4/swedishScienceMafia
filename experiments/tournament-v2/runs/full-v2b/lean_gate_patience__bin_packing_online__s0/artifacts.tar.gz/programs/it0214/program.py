# EVOLVE-BLOCK-START
"""Residue-value bin ranker.

Score each bin by how tightly the item fits (negative post-placement leftover),
augmented by an online histogram estimate of how useful that leftover would be
for future items (probability a future item fits snugly into it), plus a small
exact-fit bonus, a bonus for using already-open (non-empty) bins, and a mild
penalty for leftovers falling in a small "dead zone" band that rarely gets filled
well.
"""
import numpy as np

# Capacity is always 100.
CAP = 100

# Histogram over item sizes 1..100 (index 0 unused).  Used to estimate how often
# a future item would fit snugly into a given leftover.
_hist = np.zeros(CAP + 1, dtype=np.float64)
_total = 0.0

# Snug-fit window: a future item scoreing the leftover "well" is one that leaves
# the bin at most HALF_WINDOW below the item size left over.
_FIT_WINDOW = 8.0


def priority(item, bins):
    global _total
    it = int(item)

    # ---- update online histogram with this arriving item ------------------
    _hist[it] += 1.0
    _total += 1.0

    # ---- estimate usefulness of a leftover L ------------------------------
    # Fraction of past items that fit snugly into L: item size in [L-FIT, L].
    # More exactly: future item s uses leftover L with residue L-s small&>=0.
    # We also value L large enough to accept items near the mode of the distro.
    b = np.asarray(bins, dtype=np.float64)

    n = b.size
    # Post-placement leftover for each bin.
    residual = b - it

    # Base: prefer tight fits -> smaller residual is better.
    score = -residual

    # Histogram usefulness term.  For leftover L, usefulness ~ number of past
    # items that fit snugly (leaving 0..FIT_WINDOW slack).  Computed per distinct
    # residual via cumulative sums.
    cs = np.cumsum(_hist)  # cs[k] = count of items with size <= k
    total = _total if _total > 0.0 else 1.0

    lo = np.clip(np.round(residual - _FIT_WINDOW).astype(np.int64), 0, CAP)
    hi = np.clip(np.round(residual).astype(np.int64), 0, CAP)
    snug = cs[hi] - cs[lo]
    usefulness = snug / total

    # Weighted usefulness bonus (scaled to be comparable to tightness, but
    # secondary so tightness dominates).  Only bins that fit have residual >= 0.
    score += usefulness * 30.0

    # ---- exact-fit bonus --------------------------------------------------
    score += np.where(residual == 0, 6.0, 0.0)

    # ---- non-empty bin bonus (encourage filling open bins) ---------------
    # A bin is "open" if it is not full capacity.
    open_bin = b < CAP
    score += np.where(open_bin, 1.5, 0.0)

    # ---- dead-zone penalty -----------------------------------------------
    # Leftovers in (0, 2] are awkward (only size-1.. item fills snugly), mild
    # penalty to nudge toward 0 (exact fit) or clearly larger leftovers.
    dead = (residual > 0) & (residual <= 2)
    score -= np.where(dead, 3.0, 0.0)

    return score
# EVOLVE-BLOCK-END

