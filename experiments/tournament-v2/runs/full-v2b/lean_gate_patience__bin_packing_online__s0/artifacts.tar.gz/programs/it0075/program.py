# EVOLVE-BLOCK-START
"""Best-fit core with anti-new-bin bias and an adaptive residual-usability penalty."""
import numpy as np

_STATE = {"n": 0, "sum": 0.0, "small": 0}


def priority(item, bins):
    bins = np.asarray(bins)

    st = _STATE
    st["n"] += 1
    st["sum"] += item
    if item <= 30:
        st["small"] += 1
    mean = st["sum"] / st["n"]
    small_frac = st["small"] / st["n"]

    leftover = bins - item  # remaining capacity after placing the item

    # Best fit: prefer the tightest fit (smallest leftover).
    score = -leftover.astype(np.float64)

    # Penalty for residuals in the "dead zone": nonzero but too small to be
    # reliably filled by a later typical item. Keeps bins near-full instead.
    threshold = min(mean, 30.0)
    dead = (leftover > 0) & (leftover < threshold)
    score -= np.where(dead, (threshold - leftover) * 0.15, 0.0)

    # Extra, adaptive penalty on mid-range residuals whose fillability depends on
    # how often small items appear. The more small items typically available, the
    # more a moderately-sized gap can be reused, so scale the penalty downward.
    mid_lo = threshold
    mid_hi = threshold + 25.0
    mid = (leftover >= mid_lo) & (leftover < mid_hi)
    w = 0.10 * (1.0 - small_frac)
    score -= np.where(mid, w * (mid_hi - leftover), 0.0)

    # Strongly discourage opening a brand-new bin unless the fit is very good.
    is_new = bins >= 100
    score -= np.where(is_new, 8.0, 0.0)

    return score


def _reset():
    _STATE["n"] = 0
    _STATE["sum"] = 0.0
    _STATE["small"] = 0
# EVOLVE-BLOCK-END
