# EVOLVE-BLOCK-START
"""Online value-function bin ranker.

For each candidate bin we estimate how "unusable" its post-placement leftover is,
using the empirical distribution of item sizes seen so far.  The key signal is
the probability that the leftover cannot be filled by any single future item,
1 - CDF(leftover).  Bins whose leftover is likely to be consumed by a future
item are preferred.  A tight-fit term and a mild reuse bonus complete the rank.
"""
import numpy as np

_CAP = 100
_HIST_MAX = 101
_hist = np.zeros(_HIST_MAX, dtype=np.float64)
_total = 0.0
_n = 0

_last_update = -1
_unc = None  # 1 - CDF for each residue size


def _rebuild():
    global _unc
    sizes = np.arange(_HIST_MAX, dtype=np.float64)
    if _n == 0:
        # mild prior: assume small items common, so most residues usable
        p = np.ones(_HIST_MAX, dtype=np.float64)
        p[0] = 0.0
        p /= p.sum()
    else:
        p = _hist.copy()
        p[0] = 0.0
        p /= _n
    cdf = np.cumsum(p)
    # probability that no future single item fits into residue r
    _unc = 1.0 - cdf


def _ensure():
    global _last_update
    if _last_update != _n:
        _rebuild()
        _last_update = _n


def priority(item, bins):
    global _hist, _total, _n
    _hist[item] += 1.0
    _total += item
    _n += 1
    _ensure()

    b = bins.astype(np.float64)
    leftover = b - item
    np.clip(leftover, 0.0, _CAP, out=leftover)

    idx = leftover.astype(np.int64)
    # How unusable is this residue (higher = worse)?
    unc = _unc[idx]

    # Tight fit bonus: prefer leaving little room behind.
    tight = leftover / _CAP

    # Mild preference to reuse already-open bins rather than open new ones.
    reuse = np.where(b < _CAP, 0.02, 0.0)

    return -unc - 0.5 * tight + reuse
# EVOLVE-BLOCK-END
