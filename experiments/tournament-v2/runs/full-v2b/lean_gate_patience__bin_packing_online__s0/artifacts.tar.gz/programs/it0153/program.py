# EVOLVE-BLOCK-START
"""Value-of-residue online bin choice with calibrated prior.

For each bin we form the leftover after placing the item. Tightness (smaller leftover) is
rewarded, but we add a bonus proportional to the estimated usefulness of that leftover: the
probability that a future item could still fit into the remaining space. The estimate blends
a fixed prior distribution (Weibull-shaped, mean ~40) with the empirical histogram of items
seen so far, so it is well-calibrated from the first item yet adapts online. Exact fits get
an extra bonus.
"""
import numpy as np

# Fixed prior over item sizes 1..100 (Weibull-shaped, mean ~40, integer sizes).
# Build a discrete approximation of a Weibull(k=2, lambda=45) distribution.
_PRIOR = np.zeros(101, dtype=np.float64)
_shape = 2.0
_scale = 45.0
for s in range(1, 101):
    # approximate probability mass via survival-difference on integer buckets
    lo = (s - 0.5) / _scale
    hi = (s + 0.5) / _scale
    lo = max(lo, 0.0)
    F_lo = 1.0 - np.exp(-(lo ** _shape))
    F_hi = 1.0 - np.exp(-(hi ** _shape))
    _PRIOR[s] = max(F_hi - F_lo, 0.0)
if _PRIOR.sum() > 0:
    _PRIOR /= _PRIOR.sum()
_PRIOR_COUNTS = _PRIOR * 200.0   # pseudo-count strength of the prior

_HIST = _PRIOR_COUNTS.copy()     # blended counts
_N = float(_PRIOR_COUNTS.sum())  # effective count

_ALPHA = 25.0
_PERFECT = 60.0


def priority(item, bins):
    """Return a score for every bin; item goes to the highest score (first on ties)."""
    global _N

    leftover = bins - item  # numpy int64 array, >= 0 for every bin shown

    cdf = np.cumsum(_HIST) / _N

    idx = np.clip(leftover, 0, 100).astype(np.int64)
    usefulness = cdf[idx]

    score = -leftover.astype(np.float64) + _ALPHA * usefulness
    score[leftover == 0] += _PERFECT

    _HIST[item] += 1.0
    _N += 1.0

    return score
# EVOLVE-BLOCK-END
