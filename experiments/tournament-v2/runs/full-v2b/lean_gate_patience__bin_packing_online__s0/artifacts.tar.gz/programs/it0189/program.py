# EVOLVE-BLOCK-START
"""Strict best-fit ranker for online bin packing.

The dominant term is tightness (negative leftover). A tiny non-empty bonus breaks
ties in favor of already-opened bins without disturbing the fit ordering, and an
exact-fit bonus nails zero-residue placements.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def _update(item):
    _state["n"] += 1
    _state["sum"] += item


def priority(item, bins):
    _update(item)

    rem = bins.astype(np.float64)
    leftover = rem - item  # >= 0 for fitting bins

    # Primary: strict best fit (smallest leftover gets highest score).
    score = -leftover

    # Tie-break: prefer non-empty bins so already-opened bins are used first.
    nonempty = (rem < 100.0).astype(np.float64)
    score += nonempty * 1e-3

    # Exact fit bonus (subsumed by tightness but keeps it decisive on ties).
    score += np.where(leftover == 0, 1e-3, 0.0)

    return score
# EVOLVE-BLOCK-END
