# EVOLVE-BLOCK-START
"""Best fit with a tie-break that prefers remainders matching a typical item size."""
import numpy as np

_STATE = {"n": 0, "sum": 0.0}


def priority(item, bins):
    bins = np.asarray(bins)

    st = _STATE
    st["n"] += 1
    st["sum"] += item
    mean = st["sum"] / st["n"]

    leftover = (bins - item).astype(np.float64)  # capacity left after placing item

    # Primary: best fit (tightest leftover).  Secondary: reward leftovers that are
    # close to a typical future item size (so the bin stays fillable), and mildly
    # penalize leftovers in the tiny-but-nonzero dead zone.
    score = -leftover

    # Reward remainder near the running mean item size (a good "next item" fit).
    score -= np.abs(leftover - mean) * 0.03

    # Extra penalty for small nonzero remainders that are hard to fill.
    dead = (leftover > 0) & (leftover < 0.5 * mean)
    score -= np.where(dead, (0.5 * mean - leftover) * 0.2, 0.0)

    # Discourage opening a new bin.
    is_new = bins >= 100
    score -= np.where(is_new, 6.0, 0.0)

    return score


def _reset():
    _STATE["n"] = 0
    _STATE["sum"] = 0.0
# EVOLVE-BLOCK-END

