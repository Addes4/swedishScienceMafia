# EVOLVE-BLOCK-START
"""Best-fit core with an online fittability bonus for reusable leftovers."""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        # coarse size histogram over 1..100 (bucket per size)
        self.hist = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.n += 1
        self.mean += (item - self.mean) / self.n
        self.hist[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    leftover = bins - item  # >= 0 by contract
    lo = leftover.astype(np.float64)

    # Base: prefer tight fit (small leftover -> higher score). Strong weight so
    # this remains the dominant, best-fit-like term.
    score = -3.0 * lo

    # Fittability bonus: if the resulting leftover is a size that has been seen
    # (so it might be exactly refillable later), reward it. Use smoothed counts.
    n = max(1.0, _stats.n)
    prob = (_stats.hist + 0.5) / (n + 50.5)  # Laplace-smoothed size prob
    # map leftover (int-valued) to probability; non-zero leftovers get bonus,
    # perfect fit (leftover 0) handled separately.
    idx = leftover.astype(np.int64)
    idx = np.clip(idx, 0, 100)
    fit_bonus = np.where(leftover > 0, prob[idx] * 40.0, 0.0)

    # Bonus for near-perfect fits (leftover 0): perfect packing.
    perfect = np.where(leftover == 0, 5.0, 0.0)

    # Mild anti-new-bin bias: prefer reusing already non-empty bins.
    nonempty = (bins < 100).astype(np.float64)
    reuse = nonempty * 2.0

    return score + fit_bonus + perfect + reuse
# EVOLVE-BLOCK-END
