# EVOLVE-BLOCK-START
"""Best-fit ranker with a scrap-avoidance term.

Core idea: pure best-fit (smallest leftover) is near-optimal for this
distribution. The main loss comes from creating tiny unusable residuals.
So we still rank mainly by tightest fit, but penalize residuals that are
below a small threshold (hard to fill later), and give a modest reuse
bonus so used bins are preferred over opening new ones.
"""
import numpy as np

# smallest item size we realistically expect; residuals below this are scraps
SCRAP = 4.0


def priority(item, bins):
    rem = bins.astype(np.float64)
    leftover = rem - item

    # primary: best fit (smallest leftover is best)
    score = -leftover

    # penalize leaving a tiny scrap that is hard to reuse
    scrap = (leftover > 0.0) & (leftover < SCRAP)
    score -= scrap * 8.0

    # reuse bonus: prefer already-used bins, but bounded so we still
    # respect the tightness ordering
    used = rem < 100.0
    score += used * 3.0

    # perfect fit: strongly reward filling a bin exactly
    perfect = leftover == 0.0
    score += perfect * 20.0

    return score
# EVOLVE-BLOCK-END
