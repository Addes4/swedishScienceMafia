# EVOLVE-BLOCK-START
"""Reserve-for-later ranker with histogram-based gap quality.

Scores each bin by:
  * best-fit tightness (prefer small leftover capacity),
  * a mild bonus for reusing already-open (non-empty) bins,
  * a penalty for leaving a residual gap, scaled by an estimate of how
    many future items could still usefully fill it (poorly-fillable gaps
    are penalized more).

Empirical statistics of arriving items are tracked across calls.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.min_seen = 100
        self.hist = np.zeros(101, dtype=np.float64)  # size histogram

    def add(self, x):
        self.n += 1
        if x < self.min_seen:
            self.min_seen = x
        if 1 <= x <= 100:
            self.hist[x] += 1

    def fit_count(self, residual):
        """Number of observed items (in absolute count) that fit in residual."""
        r = int(residual)
        if r <= 0:
            return 0.0
        if r >= 100:
            return float(self.n)
        return float(self.hist[1:r + 1].sum())


_STATS = _Stats()


def priority(item, bins):
    _STATS.add(item)

    cap = bins.astype(np.float64)
    leftover = cap - item

    # Best-fit core: reward small leftover
    score = -leftover

    # Mild bonus for reusing already-open bins (cap < 100 means non-empty)
    score += np.where(cap < 100.0, 3.0, 0.0)

    # Gap-quality penalty: a residual gap is "better" (less penalized) when
    # many future items could still fit into it. Use a concave transform of
    # the fit-count so that very large residuals are not over-rewarded and
    # nearly-dead slivers are penalized most.
    if _STATS.n >= 20:
        n = float(_STATS.n)
        gaps = (leftover > 0) & (leftover < 100)
        if gaps.any():
            uniq = np.unique(np.floor(leftover[gaps]).astype(np.int64))
            # Precompute fit fraction (arcsine-transformed for concavity)
            frac_map = {}
            for u in uniq:
                f = _STATS.fit_count(int(u)) / n
                if f < 0.0:
                    f = 0.0
                elif f > 1.0:
                    f = 1.0
                frac_map[int(u)] = float(np.sqrt(f))
            pen = np.zeros_like(leftover)
            floorlo = np.floor(leftover).astype(np.int64)
            for u in uniq:
                u = int(u)
                mask = gaps & (floorlo == u)
                pen[mask] = 2.5 * (1.0 - frac_map[u])
            score -= pen

    return score
# EVOLVE-BLOCK-END

