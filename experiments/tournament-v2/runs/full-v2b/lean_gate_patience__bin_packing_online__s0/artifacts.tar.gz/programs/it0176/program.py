# EVOLVE-BLOCK-START
"""Residue-value ranker: tight fits, weighted by how useful the leftover tends to be online."""
import numpy as np


class _State:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)  # histogram of past item sizes
        self.n = 0.0
        self.total = 0.0

    def mean(self):
        return self.total / self.n if self.n > 0 else 40.0


_STATE = _State()


def priority(item, bins):
    st = _STATE
    # Online estimate of how often an item of size <= s arrives (usefulness of a residue s).
    if st.n > 0:
        csum = np.cumsum(st.counts) / st.n  # csum[s] = P(past item <= s)
    else:
        csum = None
    mean_size = st.mean()

    leftover = bins - item  # post-placement remaining capacity, >= 0
    lo = leftover.astype(np.float64)

    # Tightness: prefer small leftovers (negative leftover).
    score = -lo

    # Usefulness bonus: probability a (past) item fits snugly into this leftover.
    if csum is not None:
        useful = csum[leftover]
        score += 6.0 * useful

    # Exact fit bonus.
    score += 8.0 * (leftover == 0)

    # Reserve penalty: leftovers smaller than the typical item size are hard to refill.
    reserve = max(2.0, mean_size * 0.6)
    score -= 3.0 * (lo < reserve)

    # Unsafe-band penalty: leftover very small but nonzero tends to become dead space.
    unsafe = (leftover > 0) & (leftover < max(3.0, mean_size * 0.25))
    score -= 5.0 * unsafe

    # Mild bonus for already-non-empty bins to discourage opening new bins.
    score += 0.5 * (bins < 100)

    # Update online statistics with the arriving item.
    st.counts[item] += 1.0
    st.n += 1.0
    st.total += item

    return score
# EVOLVE-BLOCK-END

