# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with an adaptive unusable-residue penalty.

Primary signal is strict best-fit (least leftover after placing the item):
tightest fits preserve large contiguous free space for the mean-~40 items.
A strong reuse bonus discourages opening fresh bins, and a mild penalty
avoids leaving a residue smaller than the smallest item we expect to see,
which would strand that leftover.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0
        self.min_item = 100.0
        # Exponential moving average of small (< half mean) items, used as a
        # robust estimate of the smallest "typical" future item.
        self.small_ema = None

    def update(self, item):
        self.n += 1.0
        self.sum += item
        if item < self.min_item:
            self.min_item = float(item)
        m = self.mean
        if item <= 0.5 * m:
            if self.small_ema is None:
                self.small_ema = float(item)
            else:
                self.small_ema = 0.98 * self.small_ema + 0.02 * float(item)

    @property
    def mean(self):
        if self.n >= 1.0:
            return self.sum / self.n
        return 40.0

    @property
    def floor(self):
        # Expected smallest usable item: blend the EMA of small items with the
        # absolute minimum seen, clamped to a sane range.
        cand = self.min_item
        if self.small_ema is not None:
            cand = 0.5 * cand + 0.5 * self.small_ema
        return max(1.0, min(15.0, cand))


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    b = bins.astype(np.float64)
    unused = b >= 100.0

    # Post-placement residue.
    resid = b - float(item)

    # Strict best-fit: smallest non-negative residue preferred.
    fit = -resid

    # Penalize residues too small to be reused by a future item.
    thr = _stats.floor
    tiny = np.where(resid < thr, (thr - resid) / thr, 0.0)

    # Strongly prefer reusing non-empty bins over opening a fresh one.
    reuse = np.where(unused, 0.0, 1.0)

    score = (fit / 100.0) + 0.5 * reuse - 0.15 * tiny

    return score
# EVOLVE-BLOCK-END

