# EVOLVE-BLOCK-START
"""Residue-hazard ranker for online bin packing.

Score each bin by tightness (negative leftover), with an amplified tightness gap so
the best-fit bin dominates, plus a hazard penalty when the resulting leftover falls
into an "unsafe" band relative to online-tracked item statistics, and a small bonus
to non-empty bins so empty bins are not wasted.
"""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "small": 0,
}


def _update(item):
    _state["n"] += 1
    _state["sum"] += item
    if item <= 15:
        _state["small"] += 1


def priority(item, bins):
    _update(item)

    n = _state["n"]
    mean = _state["sum"] / n
    small_frac = _state["small"] / n

    rem = bins.astype(np.float64)
    leftover = rem - item  # >= 0 since only fitting bins are shown

    # Amplified best-fit: reward tight fits much more than loose ones.
    score = -leftover * 1.0 - (leftover * leftover) * 0.02

    # Unsafe band: leftovers small relative to mean item size are likely to become
    # unusable dead space. Penalize them, scaled by how common small items are.
    unsafe = mean * 0.5
    hazard = np.where(leftover < unsafe, (unsafe - leftover), 0.0)
    score -= hazard * (1.0 - small_frac) * 0.35

    # Mild bonus to non-empty bins (remaining < 100) to encourage packing into
    # already-opened bins rather than opening fresh ones when fit is similar.
    nonempty = (rem < 100.0).astype(np.float64)
    score += nonempty * 0.6

    # Exact-fit bonus.
    score += np.where(leftover == 0, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END

