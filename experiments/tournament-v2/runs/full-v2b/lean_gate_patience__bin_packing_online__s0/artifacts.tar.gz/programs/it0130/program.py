# EVOLVE-BLOCK-START
"""Residue-hazard ranker: tight fit, but avoid leftover residues too small to be useful."""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.small = 0  # count of items <= ~20

    def update(self, item):
        self.n += 1
        self.sum += item
        if item <= 20:
            self.small += 1

    def mean(self):
        if self.n == 0:
            return 40.0
        return self.sum / self.n

    def small_frac(self):
        if self.n == 0:
            return 0.0
        return self.small / self.n


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    mean = _stats.mean()
    # "Typical useful" leftover: an item around a quarter of the mean size,
    # so we dislike leaving tiny unusable slivers.
    useful = 0.35 * mean
    if useful < 5.0:
        useful = 5.0

    residual = bins - item

    # Base: best-fit tightness (smaller residual => higher score).
    score = -residual.astype(np.float64)

    # Penalize leftovers that are non-zero but too small to be useful later.
    tiny = (residual > 0) & (residual < useful)
    score -= np.where(tiny, (useful - residual) * 0.9, 0.0)

    # Extra penalty for nearly-full-but-not-full leftovers (very tight wastes room).
    near = (residual > 0) & (residual < 3)
    score -= np.where(near, 6.0, 0.0)

    # Mild bonus for reusing already non-empty bins (fraction full).
    # bins < 100 means the bin already has items.
    used_bonus = np.where(bins < 100, (100.0 - bins) * 0.05, 0.0)
    score += used_bonus

    # Slight preference to open fresh bins only when fit is perfect (residual 0).
    # (handled implicitly by tightness, no extra term)

    return score
# EVOLVE-BLOCK-END
