# EVOLVE-BLOCK-START
"""Adaptive best-fit: tight fits with a min-item-threshold residue guard."""
import numpy as np

# Online statistics of arriving item sizes.
_state = {"n": 0, "min_item": 100.0}


def priority(item, bins):
    """Best-fit with a small penalty for residues uselessly tiny for future items.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in (including unused = 100).
    """
    # Track the smallest item seen so far (proxy for "smallest likely future item").
    n = _state["n"] + 1
    if item < _state["min_item"]:
        _state["min_item"] = float(item)
    _state["n"] = n
    # Adaptive threshold: a residue smaller than the smallest item seen so far
    # is likely unusable; allow some headroom for variation.
    thr = max(_state["min_item"], 5.0)

    b = bins.astype(np.float64)
    leftover = b - item  # >= 0 since only fitting bins are shown

    # Primary: best fit (prefer smallest non-negative leftover).
    tight = -leftover

    # Penalize residues that fall below the usable-threshold band.
    small_pen = np.where((leftover > 0) & (leftover < thr), -(thr - leftover), 0.0)

    # Prefer reusing a non-empty bin over opening a fresh one.
    reuse = np.where(b < 100, 1.0, 0.0)

    return tight + 0.6 * small_pen + 3.0 * reuse
# EVOLVE-BLOCK-END
