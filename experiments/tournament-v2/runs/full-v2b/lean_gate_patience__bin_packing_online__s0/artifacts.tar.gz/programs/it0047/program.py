# EVOLVE-BLOCK-START
"""Expected-usefulness bin choice: rank by usable residual mass with best-fit dominance."""
import numpy as np

_H = np.zeros(101, dtype=np.float64)   # hist of item sizes seen
_N = 0.0
_W = 0.0


def priority(item, bins):
    global _N, _W
    _H[item] += 1.0
    _N += 1.0
    _W += item

    total = _N + 1.0
    probs = (_H + 0.05) / total

    sizes = np.arange(101, dtype=np.float64)
    # Expected number of future items that fit in residual R (usability).
    cprob = np.cumsum(probs)          # cprob[R] = P(s <= R)
    # Expected packed mass in residual R: sum_{s<=R} probs[s]*s
    cw = np.cumsum(probs * sizes)

    leftover = bins - item
    left = np.clip(leftover, 0, 100).astype(np.int64)

    # Usability of residual: expected fraction of a future item it can host.
    usable = cprob[left]
    mass = cw[left]

    # Primary: best fit (tightest leftover) to consolidate.
    score = -leftover.astype(np.float64)
    # Secondary: prefer residuals that still host common items (not dead slivers).
    score += 0.5 * usable + 0.3 * mass

    full_mask = (bins == 100)
    score[full_mask] -= 1.0

    return score
# EVOLVE-BLOCK-END
