# EVOLVE-BLOCK-START
"""Online value-function bin ranker.

For each candidate bin we estimate the expected residual "waste" of its
post-placement leftover, using the empirical distribution of item sizes seen so
far.  We prefer bins that (a) fit tightly and (b) whose leftover is likely to be
consumable by future items (small expected waste).  A small bonus encourages
filling already-used bins instead of opening fresh ones.
"""
import numpy as np

_CAP = 100
_HIST_MAX = 101
_hist = np.zeros(_HIST_MAX, dtype=np.float64)
_total = 0.0
_n = 0

# Precompute nothing heavy; recompute lazily but cheaply.
_last_update = -1
_waste = None


def _rebuild_waste():
    global _waste
    # Empirical distribution over item sizes.
    if _n == 0:
        p = np.zeros(_HIST_MAX, dtype=np.float64)
        # mild prior: uniform-ish over 1..100
    else:
        p = _hist / _n
    # expected fraction of a residue r that cannot be filled by a single future
    # item, approximated by the probability that a future item <= r fits.
    # usable fraction of r when a fitting item of size s <= r is placed is s/r.
    # We measure expected waste ~ r - E[best single fill], a cheap proxy.
    sizes = np.arange(_HIST_MAX, dtype=np.float64)
    # For each residue r, expected residual after offering one future item:
    # if the item fits (s<=r), leftover r-s; else r stays.  Take the min over
    # the *best* fitting item is optimistic; instead use expected residual over
    # the distribution, which correlates with long-run waste.
    cum = np.cumsum(p)  # cum[r] = P(item <= r)
    # E[residual | current residue r] over one random item:
    # sum_{s<=r} p_s * (r - s) + P(item > r) * r
    #   = r - sum_{s<=r} p_s * s
    es = np.cumsum(p * sizes)  # es[r] = E[s * 1(s<=r)]
    exp_res = sizes - es
    # Normalize by capacity to keep magnitudes modest.
    _waste = exp_res


def _ensure():
    global _waste, _last_update
    if _last_update != _n:
        _rebuild_waste()
        _last_update = _n


def priority(item, bins):
    global _hist, _total, _n
    _hist[item] += 1.0
    _total += item
    _n += 1
    _ensure()

    b = bins.astype(np.float64)
    leftover = b - item
    # guard against negative (shouldn't happen, harness only passes fitting bins)
    np.clip(leftover, 0.0, _CAP, out=leftover)

    idx = leftover.astype(np.int64)
    waste = _waste[idx]  # expected waste of the post-placement residue

    # Tiny bonus for reusing already-open (non-full) bins.
    reuse = np.where(b < _CAP, 0.5, 0.0)

    return -waste + reuse
# EVOLVE-BLOCK-END
