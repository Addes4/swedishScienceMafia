# EVOLVE-BLOCK-START
"""Residue-utility best fit: blend tight-fit tightness with a penalty for leaving
uselessly small leftovers, using an online histogram to estimate a useful
leftover threshold (approximate median item size)."""
import numpy as np

_bins_hist = np.zeros(101, dtype=np.int64)
_n = 0
_state = {"useful": 20.0}


def _median_size():
    total = _bins_hist.sum()
    if total == 0:
        return 40.0
    half = total / 2.0
    c = np.cumsum(_bins_hist)
    idx = int(np.searchsorted(c, half))
    if idx < 1:
        idx = 1
    elif idx > 100:
        idx = 100
    return float(idx)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest (first on ties)."""
    global _n
    # Update online histogram with the current item (now part of past statistics).
    _bins_hist[item] += 1
    _n += 1

    # Useful leftover threshold tracks a fraction of the empirical median size.
    med = _median_size()
    useful = 0.5 * med + 4.0
    if useful < 8.0:
        useful = 8.0
    elif useful > 45.0:
        useful = 45.0

    bins_f = bins.astype(np.float64)
    leftover = bins_f - item

    tight = -leftover

    is_zero = leftover <= 0.0
    unsafe = (leftover > 0.0) & (leftover < useful)
    hazard = unsafe.astype(np.float64) * (useful - leftover + 1.0)

    is_new = bins_f >= 100.0
    reuse_bonus = np.where(is_new, -6.0, 0.0)

    perfect = np.where(is_zero, 5.0, 0.0)

    return tight - 1.5 * hazard + reuse_bonus + perfect
# EVOLVE-BLOCK-END

