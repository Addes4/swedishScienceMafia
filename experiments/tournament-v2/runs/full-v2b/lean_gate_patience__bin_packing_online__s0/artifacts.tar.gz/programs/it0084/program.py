# EVOLVE-BLOCK-START
"""Best-fit with online item statistics and residue reservation."""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.small_frac = 0.1   # fraction of items <= small_thr
        self.small_thr = 15.0

    def update(self, item):
        self.n += 1
        self.mean += (item - self.mean) / self.n
        # adaptive small threshold: ~35% of running mean
        self.small_thr = max(2.0, min(20.0, self.mean * 0.35))
        self.small_frac += (
            (1.0 if item <= self.small_thr else 0.0) - self.small_frac
        ) / self.n


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    small_thr = _stats.small_thr
    sf = _stats.small_frac
    mean = _stats.mean

    leftover = bins - item  # >= 0 by contract

    # Base: prefer tight fit (small leftover -> higher score)
    base = -leftover.astype(np.float64)

    # Penalty for leaving a gap below the typical small item size:
    # such gaps tend to be wasted. Scale by how common small items are.
    gap_pen = np.where(
        leftover < small_thr,
        (small_thr - leftover) * (0.5 + sf),
        0.0,
    )

    # Reuse bias: prefer already non-empty bins (remaining < 100)
    nonempty = (bins < 100).astype(np.float64)
    reuse = nonempty * 3.0

    # Slight bonus for near-perfect fits (leftover 0)
    perfect = np.where(leftover == 0, 2.0, 0.0)

    # Reservation term: mildly favor bins whose leftover is still large
    # enough to hold a typical item, so that we don't fragment the bin
    # into residues that no normal item can use.  The reward grows with
    # how close leftover is to at least one mean-sized item.
    reserve = np.where(
        leftover >= mean,
        (leftover - mean) * 0.15,
        -0.15 * (mean - leftover),
    )

    return base + reuse + perfect - gap_pen + reserve
# EVOLVE-BLOCK-END
