# EVOLVE-BLOCK-START
"""Distribution-aware best-fit ranker.

Primary signal is best-fit (smallest leftover capacity).  On top of that we
nudge the choice using empirical knowledge of the item distribution:

  * a small explicit reward for exactly filling a bin,
  * a bonus for reusing already-open bins (cap < 100),
  * a mild penalty when the resulting residual is a "dead gap" that is
    unlikely to be filled by a future item (probability-weighted by the
    observed histogram).

All statistics are gathered online from arriving items only.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.hist = np.zeros(101, dtype=np.float64)  # count of sizes seen
        self.small = []  # sample of small sizes for percentile estimate

    def add(self, x):
        self.n += 1
        if 1 <= x <= 100:
            self.hist[x] += 1.0
        if len(self.small) < 1024:
            self.small.append(x)
        else:
            # reservoir-ish: replace the current max with x if smaller
            m = max(self.small)
            if x < m:
                self.small[self.small.index(m)] = x

    def p_small(self, q=0.05):
        if not self.small:
            return 1
        s = sorted(self.small)
        idx = min(len(s) - 1, max(0, int(q * len(s))))
        return max(1, s[idx])

    def fill_prob(self, residual):
        """Estimated fraction of future items that fit in `residual`."""
        if self.n < 20:
            return 1.0 if residual >= 1 else 0.0
        r = int(residual)
        if r <= 0:
            return 0.0
        if r >= 100:
            return 1.0
        return float(self.hist[1:r + 1].sum()) / max(1.0, self.n)


_STATS = _Stats()


def priority(item, bins):
    _STATS.add(item)

    cap = bins.astype(np.float64)
    leftover = cap - item
    safe_left = np.maximum(leftover, 0.0)

    # Core best-fit: smaller leftover is better.
    score = -leftover

    # Explicit reward for exactly filling a bin.
    score += 6.0 * (leftover == 0.0).astype(np.float64)

    # Prefer reusing already-open bins over opening a fresh one.
    score += 2.0 * (cap < 100.0).astype(np.float64)

    # Penalise residuals that are unlikely to be filled later: use the
    # empirical complement of the fill probability.
    thr = _STATS.p_small(0.05)
    small_gaps = (safe_left > 0) & (safe_left < 40)
    if small_gaps.any():
        uniq = np.unique(np.floor(safe_left[small_gaps])).astype(int)
        for u in uniq:
            mask = small_gaps & (np.floor(safe_left) == u)
            if mask.any():
                p = _STATS.fill_prob(u)
                # weight residuals a bit more heavily the larger they are
                score[mask] -= 1.5 * (1.0 - p) * (1.0 + u / 100.0)

    # Tiny dead-gap flag below the smallest typical item.
    dead = (safe_left > 0) & (safe_left < thr)
    score -= 3.0 * dead.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
