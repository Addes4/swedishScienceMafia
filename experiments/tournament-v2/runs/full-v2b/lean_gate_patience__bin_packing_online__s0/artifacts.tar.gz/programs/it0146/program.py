# EVOLVE-BLOCK-START
"""Online value-function bin ranker with a short multi-step residue value.

For each candidate bin we estimate the expected residual "waste" of its
post-placement leftover, using the empirical distribution of item sizes seen so
far.  We prefer bins that (a) fit tightly and (b) whose leftover is likely to be
consumable by future items (small expected waste).  A small bonus encourages
filling already-used bins instead of opening fresh ones.

The residue value uses a short lookahead: from a residue r, we repeatedly offer
the *best single fitting item* (greedy) and measure the expected leftover after a
few steps.  This captures whether scraps are likely to be usable without the
cost of a full dynamic program.
"""
import numpy as np

_CAP = 100
_HIST_MAX = 101
_STEPS = 3
_hist = np.zeros(_HIST_MAX, dtype=np.float64)
_total = 0.0
_n = 0

_last_update = -1
_waste = None
_sizes = np.arange(_HIST_MAX, dtype=np.float64)


def _rebuild_waste():
    global _waste
    if _n == 0:
        # No data yet: waste is just the residue itself (can't fill anything).
        _waste = _sizes.copy()
        return
    p = _hist / _n
    # Distribution over sizes 1..100 (index 0 unused, prob 0).
    p[0] = 0.0
    # For each residue r, expected value after _STEPS greedy fills.
    # Greedy: among items s<=r, pick the one that minimizes expected future waste;
    # approximate by picking the largest fitting size on average context, but we
    # instead take expected leftover after offering one random item and replacing
    # r by leftover (a value-iteration step), then iterate.
    sizes = _sizes
    # Precompute E[min(r, s)] style quantities can't be used directly for value
    # iteration over states, so do explicit O(STEPS * 101 * 100) computation.
    val = np.zeros(_HIST_MAX, dtype=np.float64)
    # Initialize: value = expected leftover after ONE random offer (no future).
    cum = np.cumsum(p)
    es = np.cumsum(p * sizes)
    val = sizes - es  # E[leftover after one random item from residue r]
    # Iterate value steps: from residue r, offer a random item; if it fits, we get
    # residue r-s with value val[r-s]; if not, residue stays r with value val[r].
    #   next[r] = sum_{s<=r} p_s * val[r-s] + P(s>r) * val[r]
    for _ in range(_STEPS - 1):
        nxt = np.empty(_HIST_MAX, dtype=np.float64)
        for r in range(_HIST_MAX):
            if r == 0:
                nxt[r] = 0.0
                continue
            s_vals = val[:r + 1][::-1]  # val[r-0], val[r-1], ..., val[0]
            fit = p[:r + 1]
            nxt[r] = np.dot(fit, s_vals) + (1.0 - cum[r]) * val[r]
        val = nxt
    _waste = val


def _ensure():
    global _waste, _last_update
    if _last_update != _n:
        _rebuild_waste()
        _last_update = _n


def priority(item, bins):
    global _hist, _total, _n
    _hist[item] += 1.0
    _total += item
    _n += 1
    _ensure()

    b = bins.astype(np.float64)
    leftover = b - item
    np.clip(leftover, 0.0, _CAP, out=leftover)

    idx = leftover.astype(np.int64)
    waste = _waste[idx]

    reuse = np.where(b < _CAP, 0.5, 0.0)

    return -waste + reuse
# EVOLVE-BLOCK-END
