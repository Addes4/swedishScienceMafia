# EVOLVE-BLOCK-START
"""Best-fit with an online residue-utility bonus toward common leftover sizes."""
import numpy as np

# Online statistics: coarse histogram of item sizes seen so far.
_NB = 101
_hist = np.zeros(_NB, dtype=np.float64)
_state = {"n": 0}


def priority(item, bins):
    """Best-fit primary, with a small bonus for residues matching common item sizes.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in (including unused = 100).
    """
    # Update online histogram.
    _hist[item] += 1.0
    _state["n"] += 1
    n = _state["n"]

    b = bins.astype(np.float64)
    leftover = b - item  # >= 0

    # Primary: strict best fit.
    tight = -leftover

    # Residue-utility bonus: reward leftovers that match sizes frequently seen.
    # Normalize histogram to a probability, smoothed.
    if n > 0:
        p = _hist / n
    else:
        p = _hist
    # Map each leftover to the probability mass of "a future item equal to leftover".
    li = np.clip(leftover.astype(np.int64), 0, _NB - 1)
    util = p[li]

    # Prefer reusing a non-empty bin over opening a fresh one.
    reuse = np.where(b < 100, 1.0, 0.0)

    return tight + 40.0 * util + 3.0 * reuse
# EVOLVE-BLOCK-END
