# EVOLVE-BLOCK-START
"""Online bin choice: classic Best-Fit with open-bin reuse preference."""
import numpy as np


def priority(item, bins):
    """Score each bin for Best-Fit: prefer the tightest residual among bins that fit.

    The item goes to the bin with the highest score. Since bins here all fit the item
    (the array only contains feasible bins), we simply reward smaller residuals.
    Unused bins (capacity 100) get a penalty so we only open a fresh bin when no
    already-used bin is available.
    """
    bins = np.asarray(bins, dtype=np.float64)
    n = bins.size
    residual = bins - item

    # Best-fit: maximize score => minimize residual among used bins.
    score = -residual

    # Strong reuse preference: penalize opening/using a fresh (empty) bin.
    score = np.where(bins >= 100.0, score - 10000.0, score)

    return score
# EVOLVE-BLOCK-END
