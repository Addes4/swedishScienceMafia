# EVOLVE-BLOCK-START
"""
Best-fit with a distribution-aware tie-break.

Primary rule: minimize the residual capacity after placement (best fit).
Tie-break: among residuals that are effectively equal, prefer the placement
whose residual is NOT a "dead sliver" -- i.e. a residual that is too small to
hold a typical item and thus likely never gets used again.  If several choices
leave equally tight residuals, the one with the larger (but still tight)
residual that can still host a common item is preferred.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0
        self._med = 40.0

    def add(self, size):
        self.hist[size] += 1.0
        self.count += 1.0


_STATS = _Stats()


def priority(item, bins):
    _STATS.add(int(item))

    # median-ish typical item size (cheap, stable): use mean of histogram
    if _STATS.count >= 100.0:
        s = np.arange(101, dtype=np.float64)
        total = _STATS.count
        mean = float(np.dot(s, _STATS.hist) / total)
    else:
        mean = 40.0
    typical = max(1.0, mean)

    residual = bins - item  # >= 0

    # Best-fit: prefer small residual.
    tight = -residual.astype(np.float64)

    # Dead-sliver penalty: a residual below ~half the typical item is unlikely
    # to ever be filled again, so it is "wasted".  Penalize it, but only mildly
    # so that best-fit still dominates genuine differences.
    sliver = residual < 0.5 * typical
    sliver_penalty = np.where(sliver, -0.5, 0.0)

    # Reward exactly filling a bin (residual 0 is optimal -- perfect fit).
    exact = np.where(residual == 0, 0.5, 0.0)

    score = tight + sliver_penalty + exact
    return score
# EVOLVE-BLOCK-END
