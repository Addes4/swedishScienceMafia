# EVOLVE-BLOCK-START
"""Online residue-reuse ranker.

For each candidate bin, compute the post-placement leftover L.  Using the
empirical histogram of item sizes observed so far, estimate two quantities:

  * reach[L] : whether L is exactly representable as a sum of a small number
    (1 or 2) of items drawn from the observed distribution, and how probable
    such a decomposition is (probability mass of exact single- or double-item
    fills).
  * best_fill[L] : probability that a single future item comes closest to
    filling L (i.e. max achievable fill probability).

Score = strong best-fit tightness  +  reuse bonus (from reach)  +  small
non-empty preference.  Exact fits get an overwhelming bonus.
"""
import numpy as np

_sizes = np.arange(0, 101, dtype=np.float64)


def _build_prior_pdf():
    k = 2.0
    scale = 45.0
    pdf = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        x = s / scale
        pdf[s] = (k / scale) * (x ** (k - 1.0)) * np.exp(-(x ** k))
    total = pdf.sum()
    if total <= 0:
        pdf = np.ones(101, dtype=np.float64)
        total = pdf.sum()
    return pdf / total


_prior_pdf = _build_prior_pdf()

# Online state
_count = np.zeros(101, dtype=np.float64)
_total = 0.0
# Cached convolution-based reach table (recomputed periodically)
_reach_cache = None
_reach_updates = 0
_last_total_for_cache = -1


def _rebuild_cache():
    """Recompute the single/double-item exact-fill probability table."""
    global _reach_cache, _last_total_for_cache
    if _total <= 0:
        pdf = _prior_pdf
    else:
        # Blend online empirical with prior for stability at small counts
        w = _total / (_total + 50.0)
        pdf = w * (_count / _total) + (1.0 - w) * _prior_pdf
    # Probability that a single item exactly fills a leftover of size L: pdf[L]
    single = pdf.copy()
    # Probability that two items sum to exactly L: convolution pdf*pdf
    double = np.convolve(pdf, pdf)
    reach = single.copy()
    m = min(double.shape[0], 101)
    reach[:m] += double[:m]
    # best single-fill: probability that some item <= L exists (max fill)
    cdf = np.cumsum(pdf)
    best_fill = np.clip(cdf, 0.0, 1.0)
    _reach_cache = (reach, best_fill)
    _last_total_for_cache = _total


def priority(item, bins):
    global _total
    # Update online statistics with this item (it arrives now).
    _count[int(item)] += 1.0
    _total += 1.0

    # Rebuild cache every so often (cheap, ~5000 calls total).
    if _reach_cache is None or _total - _last_total_for_cache >= 25.0:
        _rebuild_cache()

    reach, best_fill = _reach_cache

    b = np.asarray(bins, dtype=np.float64)
    leftover = b - float(item)
    idx = np.clip(leftover.astype(np.int64), 0, 100)

    score = -leftover                      # best-fit tightness
    score += 1.5 * best_fill[idx]          # usable by a future single item
    score += 6.0 * reach[idx]              # exact reuse (1 or 2 items)
    score += (leftover == 0).astype(np.float64) * 50.0
    nonempty = leftover < 100.0 - 1e-9
    score += nonempty.astype(np.float64) * 0.3
    return score
# EVOLVE-BLOCK-END
