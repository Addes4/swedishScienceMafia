# EVOLVE-BLOCK-START
"""Best-fit core with a moderate anti-new-bin bias and a residual-usability term."""
import numpy as np

_STATE = {"n": 0, "sum": 0.0}


def priority(item, bins):
    bins = np.asarray(bins)

    st = _STATE
    st["n"] += 1
    st["sum"] += item
    mean = st["sum"] / st["n"]

    leftover = bins - item  # remaining capacity after placing the item

    # Best fit: prefer the tightest fit (smallest leftover).
    score = -leftover.astype(np.float64)

    # Penalty for residuals that are too small to be reliably refilled by a
    # later typical item (nonzero but below a fraction of the mean item size).
    threshold = max(1.0, 0.5 * mean)
    dead = (leftover > 0) & (leftover < threshold)
    score -= np.where(dead, (threshold - leftover) * 0.1, 0.0)

    # Discourage opening a brand-new bin unless the fit is very good.
    is_new = bins >= 100
    score -= np.where(is_new, 4.0, 0.0)

    return score


def _reset():
    _STATE["n"] = 0
    _STATE["sum"] = 0.0
# EVOLVE-BLOCK-END
