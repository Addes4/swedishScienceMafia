# EVOLVE-BLOCK-START
"""Best-fit with online empirical fillability of the residual gap."""
import numpy as np

_stats = {"n": 0, "sum": 0.0, "min": 100.0, "hist": np.zeros(101, dtype=np.float64)}


def _update(item):
    s = _stats
    s["n"] += 1
    s["sum"] += item
    if item < s["min"]:
        s["min"] = item
    s["hist"][item] += 1.0


def priority(item, bins):
    """Score each candidate bin; highest wins (ties -> first)."""
    _update(item)

    s = _stats
    n = s["n"]
    mean = s["sum"] / n if n else 40.0
    hist = s["hist"]

    leftover = (bins - item).astype(np.float64)

    # Best fit: smaller leftover is better.
    score = -leftover

    # Fillability bonus: reward residuals that match a commonly seen item size,
    # or that are 0 (perfect fit). Estimate via histogram frequency.
    total = hist.sum()
    # frequency of each integer leftover size as a fraction in [0,1]
    freq = hist / total if total > 0 else np.zeros(101)

    # For each bin, leftover is integer; look up matchability.
    lo_int = np.clip(leftover.astype(np.int64), 0, 100)
    matchability = freq[lo_int]  # fraction of past items equal to this gap

    # Reward gaps likely to be exactly filled; penalize gaps too small to hold
    # even the smallest typical item.
    score += 3.0 * matchability

    typical_min = max(1.0, min(float(s["min"]), mean * 0.5))
    wasted = np.maximum(0.0, typical_min - leftover)
    score -= 0.5 * wasted

    # Mild anti-new-bin bias.
    is_new = (bins == 100) & (item < 100)
    score -= is_new.astype(np.float64) * 0.3

    return score
# EVOLVE-BLOCK-END
