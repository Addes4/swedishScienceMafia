# EVOLVE-BLOCK-START
"""Reserve-for-later best-fit ranking with representability lookahead.

Scores each bin by how well the item fits (tight fits preferred), with a mild
bonus for reusing non-empty bins, a reward for exactly filling bins, and a
lookahead term that rewards residuals which can be (nearly) filled by one or two
items drawn from the empirical past-size distribution; irreducible residuals are
penalized.
"""
import numpy as np

_state = {
    "n": 0,
    "hist": np.zeros(101, dtype=np.float64),
}


def _update(item):
    s = _state
    s["n"] += 1
    if 1 <= item <= 100:
        s["hist"][item] += 1.0


# Cache of representability scores keyed by residual, refreshed periodically.
_cache = {"tick": -1, "table": None}


def _build_table(hist, total):
    """For residuals 0..100 compute a representability score in roughly [-1,1].

    Higher when the residual r can be (nearly) filled by one or two future
    items, lower when r is an irreducible sliver (never fillable).
    """
    freq = hist / total if total > 0 else np.zeros(101)

    # Probability that a single future item exactly matches r.
    one = freq[0:101].copy()

    # Probability that two future items sum to r.
    two = np.zeros(101)
    # only iterate over sizes with non-negligible probability
    active = np.nonzero(freq > 1e-4)[0]
    for a in active:
        # b must be in [1, 100-a]; accumulate freq[a]*freq[b]
        lo = 1
        hi = 100 - a
        if hi < lo:
            continue
        two[a + lo:a + hi + 1] += freq[a] * freq[lo:hi + 1]

    # near misses: within +/-1 also count, slightly discounted
    rep = one.copy()
    rep[1:] += 0.5 * one[:-1]
    rep[:-1] += 0.5 * one[1:]
    rep += two
    rep[1:] += 0.5 * two[:-1]
    rep[:-1] += 0.5 * two[1:]

    # Scale
    table = rep * 1.0
    table[0] = 1.0  # exactly filled is ideal
    return table


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    bins = np.asarray(bins)
    remaining = bins - item
    rem_f = remaining.astype(np.float64)

    # Tightest fit first: smaller leftover is better (dominant term).
    score = -rem_f * 10.0

    # Preference for reusing non-empty bins.
    non_empty = (bins < 100)
    score += np.where(non_empty, 2.0, 0.0)

    # Reward exactly filling a bin.
    score += 4.0 * (remaining == 0)

    # Penalize tiny dead slivers that no future item can use.
    score -= 3.0 * ((remaining > 0) & (remaining < 6))

    n = _state["n"]
    if n > 50:
        hist = _state["hist"]
        total = hist.sum()
        # Refresh representability table only every few calls (expensive two-item
        # convolution), otherwise reuse cache.
        tick = n // 20
        if _cache["tick"] != tick or _cache["table"] is None:
            _cache["table"] = _build_table(hist, total)
            _cache["tick"] = tick
        table = _cache["table"]

        idx = np.clip(remaining, 0, 100)
        rep = table[idx]
        # Small bonus for representable residuals, penalty for irreducible ones.
        bon = (rep - 0.15) * 3.0
        bon = np.where(remaining > 0, bon, 0.0)
        score += np.minimum(np.maximum(bon, -2.0), 2.0)

    _update(item)
    return score
# EVOLVE-BLOCK-END
