# EVOLVE-BLOCK-START
"""Residue-hazard ranker: tight fit with a penalty for unsafe small leftovers."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Rank bins by tightness, penalizing post-placement leftovers in an unsafe band."""
    st = _state
    st["n"] += 1
    st["sum"] += item
    st["hist"][item] += 1.0

    n = st["n"]
    mean = st["sum"] / n
    # Track fraction of relatively small items seen so far.
    small_count = st["hist"][:max(1, int(mean))].sum() if mean >= 1 else 0.0
    small_frac = small_count / n

    # Useful-item threshold: a leftover is "dead" if too small to fit typical small items.
    # Scale the unsafe band with the observed distribution.
    danger_lo = 1.0
    danger_hi = max(2.0, mean * (0.35 + 0.25 * small_frac))

    leftover = bins - item  # remaining capacity after placing the item here

    # Tightness: prefer small leftover.
    score = -leftover.astype(np.float64)

    # Penalty for leftovers landing in the unsafe (dead-zone) band.
    in_danger = (leftover >= danger_lo) & (leftover < danger_hi)
    score -= in_danger.astype(np.float64) * (danger_hi - leftover)

    # Bonus for already-non-empty bins, to avoid opening new bins unnecessarily.
    nonempty = bins < 100
    score += nonempty.astype(np.float64) * 0.5

    # Strong bonus for exact fits.
    score += (leftover == 0).astype(np.float64) * 5.0

    return score
# EVOLVE-BLOCK-END
