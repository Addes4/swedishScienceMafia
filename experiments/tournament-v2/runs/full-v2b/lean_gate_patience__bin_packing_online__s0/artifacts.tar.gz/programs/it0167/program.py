# EVOLVE-BLOCK-START
"""Online best-fit with adaptive exact-fit bonus keyed on the empirical item histogram."""
import numpy as np

# Empirical counts over integer item sizes 1..100, updated online.
_hist = np.zeros(101, dtype=np.float64)
_seen = 0.0


def _update(item):
    global _seen
    s = int(item)
    if 1 <= s <= 100:
        _hist[s] += 1.0
    _seen += 1.0


def priority(item, bins):
    """Best-fit dominant; reward the leftover if it is a commonly seen size."""
    _update(item)

    n = bins.shape[0] if hasattr(bins, "shape") else len(bins)
    leftover = np.asarray(bins, dtype=np.float64) - float(item)

    idx = np.clip(leftover.astype(np.int64), 0, 100)

    # Base: best fit (smallest leftover).
    score = -leftover

    # Adaptive exact-fit reward: bonus proportional to how often this leftover
    # size has been observed as an item (a good future filler).
    if _seen > 0:
        freq = _hist[idx] / _seen
    else:
        freq = np.zeros_like(leftover)
    score += 40.0 * freq

    # Exact fit is always strongly preferred.
    score += (leftover == 0).astype(np.float64) * 30.0

    # Slight preference for non-empty bins to avoid opening new ones.
    score += (leftover < 100.0 - 1e-9).astype(np.float64) * 0.3

    return score
# EVOLVE-BLOCK-END
