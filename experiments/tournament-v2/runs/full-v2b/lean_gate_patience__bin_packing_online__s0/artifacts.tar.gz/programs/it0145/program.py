# EVOLVE-BLOCK-START
"""Online value-function bin ranker with multi-step residue valuation.

For each candidate bin we estimate the expected long-run waste of its
post-placement leftover using a dynamic-programming value function built from
the online empirical item-size distribution.  We prefer tightly-fitting bins
whose residue is likely to be consumable by future items, with a mild penalty
for opening fresh bins.
"""
import numpy as np

_CAP = 100
_HIST_MAX = 101
_hist = np.zeros(_HIST_MAX, dtype=np.float64)
_total = 0.0
_n = 0

_last_update = -1
_value = None   # value[r] = expected usable "reward" of a residue r
_small = 1.0    # smallest item seen so far (running min), used as hazard floor


def _rebuild_value():
    global _value
    if _n == 0:
        # prior: mildly favor tight fits; reward ~ fraction of residue
        sizes = np.arange(_HIST_MAX, dtype=np.float64)
        _value = sizes * 0.6
        return

    sizes = np.arange(_HIST_MAX, dtype=np.float64)
    p = _hist / _n

    # One-step expected residual after offering a single future item:
    #   E[res | r] = r - sum_{s<=r} p_s * s
    cum_s = np.cumsum(p * sizes)     # E[s * 1(s<=r)]
    exp_res1 = sizes - cum_s

    # Approximate multi-step value: the fraction of the residue that is expected
    # to be *consumable*, given that items are drawn i.i.d.  A cheap but
    # effective model: usable(r) ~ r * (1 - prod over s of (1 - p_s)^{?}).
    # Instead use expected packing efficiency: E[filled | r] via the expected
    # first fit remainder recursion approximated by geometric shrinkage.
    # Approximate steady-state usable fraction u(r):
    #   u(r) = (E[min(r, s)] + (1-P(s<=r)) * E[u(r - s) | s<=r])-ish
    # We implement a light fixed-point iteration on u over r=0..100.
    u = np.zeros(_HIST_MAX, dtype=np.float64)
    # init with single-step efficiency
    with np.errstate(divide='ignore', invalid='ignore'):
        u = np.where(sizes > 0, np.maximum(sizes - exp_res1, 0.0) / np.maximum(sizes, 1.0), 0.0)
    # A few iterations of the recursion u(r) = sum_{s<=r} p_s*(s + u(r-s)*(r-s)/(r)) / r
    # Simplified: u(r) = E over s<=r of [s + u(r-s)] / r
    for _ in range(6):
        new_u = np.zeros(_HIST_MAX, dtype=np.float64)
        # contribution: for each s, if s<=r, we place s and continue with r-s
        for r in range(1, _HIST_MAX):
            # expected filled fraction recursion: value(r) in [0, r]
            acc = 0.0
            for s in range(1, r + 1):
                ps = p[s]
                if ps == 0.0:
                    continue
                acc += ps * (s + u[r - s])
            # items larger than r waste nothing extra for this residue (item goes elsewhere)
            new_u[r] = acc
        u = new_u
    _value = u


def _ensure():
    global _value, _last_update
    if _last_update != _n:
        _rebuild_value()
        _last_update = _n


def priority(item, bins):
    global _hist, _total, _n, _small
    _hist[item] += 1.0
    _total += item
    _n += 1
    if item < _small:
        _small = item
    _ensure()

    b = bins.astype(np.float64)
    leftover = b - item
    np.clip(leftover, 0.0, _CAP, out=leftover)

    idx = leftover.astype(np.int64)
    usable = _value[idx]                 # expected consumable size of residue

    # Score: prefer tight fit (small leftover) and high usable reward.
    # Tight-fit term dominates; usable reward shapes tie-breaking.
    tight = -leftover * 0.12

    # Penalize openining new bins mildly; prefer using already-open bins.
    reuse = np.where(b < _CAP, 0.5, 0.0)

    return tight + usable + reuse
# EVOLVE-BLOCK-END
