# EVOLVE-BLOCK-START
"""Distribution-aware residual-utility ranker with tight-fit dominance."""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),  # counts of item sizes
    "count": 0,
    "mean": 40.0,
}


def _update_stats(item):
    it = int(item)
    if 1 <= it <= 100:
        _state["hist"][it] += 1.0
    _state["count"] += 1
    n = _state["count"]
    if n > 0:
        # running mean via histogram
        idx = np.arange(101, dtype=np.float64)
        _state["mean"] = float((_state["hist"] * idx).sum() / n)


def priority(item, bins):
    _update_stats(item)

    leftover = bins.astype(np.float64) - float(item)  # residual if placed here
    fits = leftover >= 0.0

    total = _state["count"]
    hist = _state["hist"]

    # Utility of a residual r: expected fill-mass from a future item that fits in r.
    # Useful residuals are those a common item size can nearly/exactly fill.
    # Build a utility lookup up to 100.
    if total >= 10:
        p = hist / total
        idx = np.arange(101)
        # weight each candidate future size s by its probability; a residual r is
        # "usable" to the degree it can host high-probability sizes.
        util = np.zeros(101, dtype=np.float64)
        # contribution: sum over s<=r of p[s] * s  (mass fillable), normalized
        cum_mass = np.cumsum(p * idx)
        util = cum_mass.copy()
        # bonus for exact-fill likelihood: p[r] if r is itself a common size
        util = util + 2.0 * p * 100.0  # emphasize common exact sizes
    else:
        util = np.zeros(101, dtype=np.float64)

    # clip residuals into [0,100] for lookup
    r = np.clip(leftover, 0.0, 100.0)
    r_idx = np.rint(r).astype(np.int64)
    resid_util = util[r_idx]

    # Dominant term: tight fit (small leftover). Secondary: residual utility.
    score = -leftover * 10.0 + resid_util
    score += np.where(fits, 0.0, -1e6)
    return score
# EVOLVE-BLOCK-END
