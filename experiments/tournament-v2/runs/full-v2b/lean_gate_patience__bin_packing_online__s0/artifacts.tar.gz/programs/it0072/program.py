# EVOLVE-BLOCK-START
"""Reserve-for-later ranker: reward tight fits, penalize unusable residues, mildly prefer reuse."""
import numpy as np

_STATE = {"n": 0, "sum": 0.0, "mean": 40.0}


def priority(item, bins):
    bins = np.asarray(bins)

    # Online empirical item-size statistics (running mean).
    st = _STATE
    st["n"] += 1
    st["sum"] += item
    mean = st["sum"] / st["n"]

    # Typical smallest useful item size: use a fraction of the running mean,
    # clamped to sane range. Gaps below this are likely wasted space.
    small = max(2.0, min(15.0, 0.15 * mean))

    leftover = bins - item  # remaining capacity after placing the item

    # Base: reward tight fits (small leftover) but never allow leftover < 0.
    score = -leftover.astype(np.float64)

    # Penalize residues that are too small to be useful for future items,
    # and also overly tiny ones more strongly.
    tiny = leftover < small
    score -= np.where(tiny, (small - leftover) * 2.0, 0.0)

    # Mild preference for reusing already-non-empty bins: opening a new bin
    # (leftover == 100 before placing) only when the fit is genuinely good.
    is_new = bins >= 100
    score -= np.where(is_new, 8.0, 0.0)

    return score


def _reset():
    _STATE["n"] = 0
    _STATE["sum"] = 0.0
    _STATE["mean"] = 40.0
# EVOLVE-BLOCK-END
