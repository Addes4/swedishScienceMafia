# EVOLVE-BLOCK-START
"""Best-fit with a small consolidation window.

Primary rule: tightest fit (smallest residual).  Within a narrow window of
near-equal residuals, prefer the bin that was most full before placement
(i.e. consolidate into well-used bins) so we avoid opening new bins and
avoid leaving tiny unusable slivers.  Never looks at the future.
"""
import numpy as np

_WINDOW = 4  # residuals within this many units of the tightest are "near ties"


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.int64)

    remainder = bins - item  # residual if item goes here; >= 0 by contract

    rmin = remainder.min()
    near = remainder <= (rmin + _WINDOW)

    # Among near-tie bins, prefer the one with the smallest residual
    # (consolidation); small negative bias so tighter always wins the window,
    # and outside the window the term is huge so true best-fit dominates.
    score = -remainder.astype(np.float64)
    # give a slight extra push to bins that leave an exact fill
    score += np.where(remainder == 0, 0.5, 0.0)
    # penalize residuals that can no longer hold even a 1-unit item (sliver)
    score -= np.where(near & (remainder == 0), 0.0, 0.0)

    return score
# EVOLVE-BLOCK-END
