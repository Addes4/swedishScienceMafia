# EVOLVE-BLOCK-START
"""Best-fit blended with a distribution-aware residual-usefulness table.

For each candidate bin we compute the post-placement leftover. Tight fits are
strongly preferred (dominant -leftover term). On top of that we add a small
bonus proportional to how "reusable" the leftover is, estimated from a running
histogram of observed item sizes: leftovers that can be (nearly) exactly filled
by a likely future item are preferred over awkward scraps. The table is cheap
to update and lookup is O(#bins).
"""
import numpy as np

_state = {
    "hist": np.zeros(101, dtype=np.float64),  # counts of observed sizes 1..100
    "count": 0,
    "useful": None,  # table usefulness[residual] for residual 0..100
}


def _rebuild_useful():
    hist = _state["hist"]
    total = hist.sum()
    if total <= 0:
        _state["useful"] = None
        return
    p = hist / total                      # probability of each size
    # usefulness of a residual r: expected number of future items (weighted by
    # their probability) that could exactly fit into r; approximated as the
    # probability mass of sizes <= r plus a bonus when an exact size exists.
    cum = np.cumsum(p)                    # cum[r] = P(size <= r)
    # scale by the value of the bin space; more space left is inherently worse,
    # so subtract a mild penalty proportional to r/size_of_typical_item.
    useful = np.zeros(101, dtype=np.float64)
    for r in range(1, 101):
        # mass of items that fit in r
        fit_mass = cum[r]
        # bonus for an exact fill (size == r) since that wastes nothing
        exact = p[r] if r <= 100 else 0.0
        useful[r] = fit_mass + 3.0 * exact
    # r == 0 (perfect fill) is maximally useful
    useful[0] = useful[1] + 5.0 if total > 0 else 0.0
    _state["useful"] = useful


def _update_stats(item):
    s = int(item)
    if 1 <= s <= 100:
        _state["hist"][s] += 1.0
    _state["count"] += 1
    n = _state["count"]
    # rebuild the table periodically (cheap, keeps it fresh without per-call cost)
    if n <= 50 or n % 25 == 0:
        _rebuild_useful()


def priority(item, bins):
    _update_stats(item)

    it = float(item)
    leftover = bins.astype(np.float64) - it   # remaining capacity if placed here

    # dominant term: tightest fit
    score = -leftover

    useful = _state["useful"]
    if useful is not None:
        # clip residuals to table range; residuals > 100 get no usefulness bonus
        idx = np.clip(leftover, 0.0, 100.0)
        lo = np.floor(idx).astype(np.int64)
        hi = np.minimum(lo + 1, 100)
        frac = idx - lo
        u = useful[lo] * (1.0 - frac) + useful[hi] * frac
        # only reward reusability for non-negative residuals (item fits)
        u = np.where(leftover >= 0.0, u, 0.0)
        score += 1.0 * u

    return score
# EVOLVE-BLOCK-END
