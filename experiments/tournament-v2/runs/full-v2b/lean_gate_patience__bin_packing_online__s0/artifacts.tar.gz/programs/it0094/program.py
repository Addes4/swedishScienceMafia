# EVOLVE-BLOCK-START
"""Adaptive best-fit with a large-bin reservation term for small items."""
import numpy as np

_state = {"n": 0, "min_item": 100.0}


def priority(item, bins):
    """Best-fit, lightly biased to save spacious bins for larger future items.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in (including unused = 100).
    """
    n = _state["n"] + 1
    if item < _state["min_item"]:
        _state["min_item"] = float(item)
    _state["n"] = n

    b = bins.astype(np.float64)
    leftover = b - item  # >= 0

    # Primary: best fit (prefer smallest non-negative leftover).
    tight = -leftover

    # Mild reuse bonus: prefer partially-filled bins over opening fresh ones.
    reuse = np.where(b < 100, 1.0, 0.0)

    # Reservation: when the item is small relative to typical (mean ~40),
    # avoid consuming a spacious bin, since big items likely still arrive.
    # Scale the penalty by how spacious the bin is and how small the item is.
    smallness = max(0.0, (40.0 - item) / 40.0)  # 0 for item>=40, ~1 for tiny
    reserve_pen = smallness * (b / 100.0)       # larger remaining capacity -> bigger penalty

    return tight + 3.0 * reuse - 2.0 * reserve_pen
# EVOLVE-BLOCK-END
