# EVOLVE-BLOCK-START
"""Tight best-fit with a bucket-stable index tie-break."""
import numpy as np

_state = {"count": 0}


def priority(item, bins):
    _state["count"] += 1

    leftover = bins.astype(np.float64) - float(item)

    # dominant term: prefer tightest fit (smallest leftover)
    score = -leftover

    # bucket the leftover: bins with (near) equal leftover get a stable
    # preference for the most recently opened bin (larger index), which
    # concentrates fill and avoids scattering scraps across old bins.
    order = np.arange(bins.shape[0], dtype=np.float64)
    buckets = np.round(leftover / 6.0)
    score -= 1e-3 * buckets                 # tiny monotone nudge
    score += 1e-4 * order                   # tie-break: newest bin first

    return score
# EVOLVE-BLOCK-END
