# EVOLVE-BLOCK-START
"""Best-Fit with an empty-bin penalty plus an online residue-utility tiebreak.

Primary signal: best-fit (minimize leftover).
Secondary signal: among bins whose leftover is close to the best, prefer the
residue that an upcoming item is most likely to fit into (estimated online from
a histogram of observed item sizes).
"""
import numpy as np

_CAP = 100
_NEW_BIN_PENALTY = 50.0
_TIE_TOL = 6.0          # leftovers within this of the best are "tied"
_HIST_BINS = 20         # histogram resolution for item-size estimate
_HIST_WINDOW = 400      # recent items used to estimate the size distribution


class _State:
    def __init__(self):
        self.hist = np.zeros(_HIST_BINS, dtype=np.float64)
        self.count = 0
        self.recent = []


_state = _State()


def _fit_prob(residues):
    """Rough probability that some upcoming item fits in a bin with given residue."""
    # fraction of recent items <= residue, via histogram
    edges = (_state.hist + np.cumsum(_state.hist))
    total = _state.count if _state.count > 0 else 1
    # cum fraction up to each residue
    result = np.zeros_like(residues, dtype=np.float64)
    binw = _CAP / _HIST_BINS
    idx = np.clip((residues / binw).astype(np.int64), 0, _HIST_BINS - 1)
    cum = np.cumsum(_state.hist) / total
    result = cum[idx]
    # exact small residues (still fittable by smallest items) get a floor
    result = np.maximum(result, 0.02)
    return result


def priority(item, bins):
    bins = np.asarray(bins)
    leftover = (bins - item).astype(np.float64)

    # update online size estimate
    _state.recent.append(item)
    if len(_state.recent) > _HIST_WINDOW:
        _state.recent.pop(0)
    _state.hist = np.zeros(_HIST_BINS, dtype=np.float64)
    for v in _state.recent:
        b = min(_HIST_BINS - 1, max(0, int((v - 1) / (_CAP / _HIST_BINS))))
        _state.hist[b] += 1.0
    _state.count = len(_state.recent)

    score = -leftover
    score[bins >= _CAP] -= _NEW_BIN_PENALTY

    # tiebreak: among bins with leftover close to the minimum, reward residues
    # that a future item is most likely to fit into
    valid = bins >= item
    if np.any(valid):
        best = leftover[valid].min()
        near = valid & (leftover <= best + _TIE_TOL)
        fp = _fit_prob(np.where(near, leftover, 0.0))
        score[near] += 0.35 * fp[near]

    return score
# EVOLVE-BLOCK-END
