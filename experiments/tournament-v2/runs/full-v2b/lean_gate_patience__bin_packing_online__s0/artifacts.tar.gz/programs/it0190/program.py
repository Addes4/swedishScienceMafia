# EVOLVE-BLOCK-START
"""Residue-adaptive best-fit ranker for online bin packing.

Primary term: tightest fit (best-fit). Secondary term: penalize leftovers that
fall into a dead-zone between ~1 and ~the smallest common item size, because
such residues can rarely be filled again. Reward near-exact fits strongly.
Track online min/max/mean item sizes to set the dead-zone boundary.
"""
import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "mn": 100,
}


def _update(item):
    _state["n"] += 1
    _state["sum"] += item
    if item < _state["mn"]:
        _state["mn"] = item


def priority(item, bins):
    _update(item)

    n = _state["n"]
    mean = _state["sum"] / n
    mn = _state["mn"]

    rem = bins.astype(np.float64)
    leftover = rem - item  # >= 0

    # Best-fit primary: tighter leftover is better.
    score = -leftover

    # Dead-zone penalty: leftovers in (0, mn) can't fit the smallest item seen,
    # so they're likely permanent waste. Scale penalty by how far into the zone.
    dz = (leftover > 0) & (leftover < mn)
    score -= np.where(dz, (mn - leftover) * 0.5, 0.0)

    # Exact-fit strong bonus.
    score += np.where(leftover == 0, 2.0, 0.0)

    # Slight preference for non-empty bins to avoid premature new bins.
    score += (rem < 100.0).astype(np.float64) * 0.3

    return score
# EVOLVE-BLOCK-END
