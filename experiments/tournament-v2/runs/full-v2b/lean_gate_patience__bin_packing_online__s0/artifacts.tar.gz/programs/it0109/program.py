# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a critical-residue bonus.

Primary signal is strict best-fit (least leftover after placing the item).
We add a modest bonus when the post-placement residue equals a small
"critical" size estimated online from the low end of observed items, so
bins tend to be left with a gap just large enough for a likely future
small item to fill exactly. A mild reuse bonus keeps us from opening
fresh bins unnecessarily, but residue quality dominates.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0
        self.min_item = 100.0

    def update(self, item):
        self.n += 1.0
        self.sum += item
        if item < self.min_item:
            self.min_item = float(item)

    @property
    def mean(self):
        if self.n >= 1.0:
            return self.sum / self.n
        return 40.0


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    b = bins.astype(np.float64)
    unused = b >= 100.0

    # Post-placement residue.
    resid = b - float(item)

    # Strict best-fit: smaller residue is better (tightest fit).
    fit = -resid

    # Critical residue: we would like to leave a small-but-usable gap,
    # tracking the low end of observed item sizes online.
    crit = max(1.0, min(20.0, _stats.min_item))
    near = np.abs(resid - crit)

    # Mild reuse bonus; residue quality still dominates.
    reuse = np.where(unused, 0.0, 1.0)

    score = (fit / 100.0) + 0.30 * reuse - 0.08 * (near / 100.0)

    return score
# EVOLVE-BLOCK-END
