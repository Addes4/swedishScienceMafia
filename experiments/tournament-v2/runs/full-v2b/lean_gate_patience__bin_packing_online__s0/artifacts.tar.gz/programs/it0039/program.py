# EVOLVE-BLOCK-START
"""Reserve-for-later ranker.

Scores each bin by a combination of:
  * best-fit tightness (prefer small leftover capacity),
  * a mild bonus for reusing already-open (non-empty) bins,
  * a penalty for leaving a residual gap that cannot usefully hold
    future items, scaled by the fraction of past items that would fit.

Empirical statistics of arriving items are tracked across calls.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.min_seen = 100
        self.small = []  # bounded sample of smallest sizes
        self.hist = np.zeros(101, dtype=np.float64)  # size histogram

    def add(self, x):
        self.n += 1
        if x < self.min_seen:
            self.min_seen = x
        if 1 <= x <= 100:
            self.hist[x] += 1
        if len(self.small) < 512:
            self.small.append(x)
        else:
            if x < self.small[-1]:
                self.small[-1] = x
        if self.n % 64 == 0:
            self.small.sort()

    def typical_small(self):
        if not self.small:
            return 1
        s = sorted(self.small)
        idx = max(0, int(0.05 * len(s)))
        return max(1, s[idx])

    def fit_fraction(self, residual):
        """Fraction of observed items that could still fit in `residual`."""
        if self.n < 20:
            return 1.0 if residual >= 1 else 0.0
        r = int(residual)
        if r <= 0:
            return 0.0
        if r >= 100:
            return 1.0
        fit = self.hist[1:r + 1].sum()
        return fit / max(1.0, self.n)


_STATS = _Stats()


def priority(item, bins):
    _STATS.add(item)

    thresh = _STATS.typical_small()

    cap = bins.astype(np.float64)
    leftover = cap - item

    # Best-fit core: reward small leftover
    tightness = -leftover

    # Mild bonus for reusing already-open bins (cap < 100 means non-empty)
    reuse = np.where(cap < 100.0, 3.0, 0.0)

    # Dead-gap flag: positive residual too small for a typical item
    dead = (leftover > 0) & (leftover < thresh)
    dead_penalty = 4.0 * dead.astype(np.float64)

    # Additional smooth penalty for residuals that few past items could fill:
    # scale by (1 - fit_fraction), weighting larger residuals a bit more.
    small_gaps = (leftover > 0) & (leftover < 40)
    resid_pen = np.zeros_like(leftover)
    if small_gaps.any():
        uniq = np.unique(np.floor(leftover[small_gaps]))
        frac_map = {int(u): _STATS.fit_fraction(u) for u in uniq}
        for u in uniq:
            ui = int(u)
            mask = small_gaps & (np.floor(leftover) == u)
            if mask.any():
                frac = frac_map[ui]
                resid_pen[mask] = 2.0 * (1.0 - frac)

    score = tightness + reuse - dead_penalty - resid_pen
    return score
# EVOLVE-BLOCK-END

