# EVOLVE-BLOCK-START
"""Reserve for later best-fit: tight fits, mild anti-new-bin bias, gap penalty."""
import numpy as np

_state = {
    "sizes": [],      # observed item sizes
    "min_typ": None,  # typical smallest item size (empirical small percentile)
    "mean": 40.0,
    "count": 0,
}


def _update_stats(item):
    _state["sizes"].append(int(item))
    _state["count"] += 1
    n = _state["count"]
    if n >= 20:
        arr = np.asarray(_state["sizes"], dtype=np.float64)
        # typical smallest item: 5th percentile
        _state["min_typ"] = float(np.percentile(arr, 5))
        _state["mean"] = float(arr.mean())
        # keep bounded memory: downsample occasionally
        if n > 2000:
            _state["sizes"] = _state["sizes"][-1000:]


def priority(item, bins):
    _update_stats(item)

    leftover = bins.astype(np.float64) - float(item)   # remaining capacity if placed here
    # base: prefer tight fits
    score = -leftover

    # mild bonus for already-non-empty bins (avoid opening fresh bins needlessly)
    non_empty = bins < 100
    score += np.where(non_empty, 1.0, 0.0)

    # penalize leftover gaps that are "too small" to likely be filled later
    mt = _state["min_typ"]
    if mt is not None and mt > 0:
        # gaps in (0, min_typ) are awkward: hard to reuse
        awkward = (leftover > 0.0) & (leftover < mt)
        score -= np.where(awkward, 2.0 * (1.0 - leftover / mt), 0.0)

    return score
# EVOLVE-BLOCK-END
