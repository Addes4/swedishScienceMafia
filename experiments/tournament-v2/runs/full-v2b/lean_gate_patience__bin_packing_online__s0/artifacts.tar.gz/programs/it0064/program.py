# EVOLVE-BLOCK-START
"""Best-fit ranker with consolidation: tightest fit wins, and among
similar fits we prefer fuller bins to pack existing bins harder."""
import numpy as np


def priority(item, bins):
    rem = bins.astype(np.float64)
    leftover = rem - item

    # primary: best fit (smallest leftover is best)
    score = -leftover

    # consolidation: prefer bins that are already well-used
    used = 100.0 - rem
    score += used * 0.01

    # reuse bonus: prefer already-used bins so we don't open new bins
    is_used = rem < 100.0
    score += is_used * 5.0

    # perfect fit: strongly reward filling a bin exactly
    perfect = leftover == 0.0
    score += perfect * 20.0

    return score
# EVOLVE-BLOCK-END

