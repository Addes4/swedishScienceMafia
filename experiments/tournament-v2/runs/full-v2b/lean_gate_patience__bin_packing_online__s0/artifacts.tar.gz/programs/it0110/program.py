# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a multi-target residue bonus.

Primary signal is strict best-fit (least leftover after placing the item),
which is the principled optimum for online packing. On top of that we reward
placements whose post-placement residue matches one of several likely future
item sizes (estimated online via a coarse histogram of small observed items),
so bins tend to be left with a gap just large enough for a likely small item
to fill exactly. Reuse of open bins strictly dominates the residue tie-break.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0
        # Coarse histogram over sizes 1..100 for small-item estimation.
        self.hist = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.n += 1.0
        self.sum += item
        self.hist[item] += 1.0

    @property
    def mean(self):
        if self.n >= 1.0:
            return self.sum / self.n
        return 40.0

    def small_targets(self):
        """Return a few likely small future item sizes (as an array)."""
        h = self.hist
        total = h.sum()
        if total < 20.0:
            return np.array([5.0, 10.0, 15.0], dtype=np.float64)
        # Consider only the low end (sizes up to ~25) where exact fits matter.
        lo = h[:26].copy()
        if lo.sum() <= 0.0:
            return np.array([5.0, 10.0, 15.0], dtype=np.float64)
        # Weight by frequency; pick the most common few low sizes.
        order = np.argsort(lo)[::-1]
        targets = []
        for idx in order:
            if lo[idx] <= 0.0:
                break
            targets.append(float(idx))
            if len(targets) >= 3:
                break
        if not targets:
            targets = [5.0, 10.0, 15.0]
        return np.array(targets, dtype=np.float64)


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    b = bins.astype(np.float64)
    unused = b >= 100.0

    # Post-placement residue.
    resid = b - float(item)

    # Strict best-fit: smaller residue is better (tightest fit).
    fit = -resid / 100.0

    # Critical-residue bonus: reward residues matching likely small future items.
    targets = _stats.small_targets()
    if targets.size > 0:
        d = np.abs(resid[:, None] - targets[None, :])
        near = np.min(d, axis=1)
    else:
        near = np.zeros_like(resid)
    bonus = 0.15 * (1.0 - np.minimum(near, 15.0) / 15.0)

    # Strictly prefer reusing a non-empty bin over opening a fresh one.
    reuse = np.where(unused, 0.0, 1.0)

    score = fit + 0.5 * reuse + bonus

    return score
# EVOLVE-BLOCK-END
