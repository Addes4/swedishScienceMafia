# EVOLVE-BLOCK-START
"""Reserve-for-later ranker: tight fits + strong anti-new-bin bias + gap penalty."""
import numpy as np

_stats = {"n": 0, "sum": 0.0, "min": 100.0}


def _update(item):
    s = _stats
    s["n"] += 1
    s["sum"] += item
    if item < s["min"]:
        s["min"] = item


def priority(item, bins):
    """Score each candidate bin; highest wins (ties -> first).

    item: integer size 1..100.
    bins: numpy int64 remaining capacities of bins the item fits in, in bin order.
    """
    _update(item)

    s = _stats
    mean = s["sum"] / s["n"] if s["n"] else 40.0
    typical_min = max(1.0, min(float(s["min"]), mean * 0.5))

    leftover = (bins - item).astype(np.float64)

    # Reward tight fit (small leftover).
    score = -leftover

    # Penalize leaving a gap too small to hold a typical small item.
    wasted = np.maximum(0.0, typical_min - leftover)
    score -= 0.6 * wasted

    # Strongly prefer already-non-empty bins to avoid opening new ones.
    is_new = (bins == 100) & (item < 100)
    score -= is_new.astype(np.float64) * 8.0

    return score
# EVOLVE-BLOCK-END
