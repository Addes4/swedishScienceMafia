# EVOLVE-BLOCK-START
"""Best-fit with residual-usability tie-breaking and reuse bias."""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.small_frac = 0.1

    def update(self, item):
        self.n += 1
        self.mean += (item - self.mean) / self.n
        thr = 15
        self.small_frac += ((1.0 if item <= thr else 0.0) - self.small_frac) / self.n


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    leftover = bins - item  # >= 0
    n = len(bins)

    # Base: tight fit dominates (small leftover -> higher score)
    base = -leftover.astype(np.float64)

    # Identify the tightest fit among existing bins
    nonempty = bins < 100
    best_left = leftover[nonempty].min() if np.any(nonempty) else None

    # Tie-break: among bins whose leftover is close to the best, prefer
    # a residual near a typical item size (more likely to be filled later).
    typ = _stats.mean
    tie = np.zeros(n, dtype=np.float64)
    if best_left is not None:
        near = (leftover - best_left) <= max(2.0, 0.05 * typ)
        # prefer residuals near typical item size
        closeness = -np.abs(leftover - typ)
        tie = np.where(near, closeness * 0.5, 0.0)

    # Reuse bias: avoid opening new bins
    reuse = (~nonempty).astype(np.float64) * -6.0

    # Extra penalty for tiny unusable residuals (below small-item threshold)
    small_thr = max(2.0, min(20.0, _stats.mean * 0.35))
    gap_pen = np.where((leftover > 0) & (leftover < small_thr),
                       (small_thr - leftover) * (0.5 + _stats.small_frac), 0.0)

    perfect = np.where(leftover == 0, 2.0, 0.0)

    return base + tie + reuse + perfect - gap_pen
# EVOLVE-BLOCK-END

