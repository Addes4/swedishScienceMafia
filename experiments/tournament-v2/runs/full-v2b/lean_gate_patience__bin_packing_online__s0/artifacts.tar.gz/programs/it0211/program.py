# EVOLVE-BLOCK-START
"""Best-fit tightness with an online-histogram exact-residue bonus.

We track an online histogram of arriving item sizes. For each candidate bin we
compute the residue r = remaining - item after placement. The score is dominated
by tightness (-r), with a small bonus when r equals a size that has been observed
frequently (so a future item is likely to fill it exactly). Exact fits get a
small extra nudge, and non-empty bins a tiny bonus.
"""
import numpy as np

# Online histogram of item sizes (integer 1..100).
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0

# Cached normalized histogram for residue-matching bonus.
_MATCH = None
_LAST_TOTAL = -1.0


def _build_tables():
    global _MATCH, _LAST_TOTAL
    if _total <= 0 or _total == _LAST_TOTAL:
        if _MATCH is None:
            _MATCH = np.zeros(101, dtype=np.float64)
        return
    p = _hist / _total  # probability mass of each item size 1..100
    _MATCH = p.copy()
    _MATCH[0] = 0.0
    _LAST_TOTAL = _total


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    global _total
    if 1 <= item <= 100:
        _hist[item] += 1.0
        _total += 1.0

    _build_tables()

    diff = bins - item  # leftover residue for each bin after placement
    tight = -diff.astype(np.float64)

    r_idx = np.clip(diff, 0, 100)
    match = _MATCH[r_idx]        # prob. residue equals a common future item size
    exact = (diff == 0).astype(np.float64)
    nonempty = (bins < 100).astype(np.float64)

    score = tight + 3.0 * match + 2.0 * exact + 0.5 * nonempty
    return score
# EVOLVE-BLOCK-END
