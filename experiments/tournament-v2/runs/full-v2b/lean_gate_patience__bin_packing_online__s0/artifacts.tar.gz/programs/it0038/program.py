# EVOLVE-BLOCK-START
"""Reserve-for-later ranker.

Scores each bin by a combination of:
  * best-fit tightness (prefer small leftover capacity),
  * a mild bonus for reusing already-open (non-empty) bins,
  * a penalty for leaving a residual gap that is too small to be useful
    (below the smallest typical item size seen so far).

Empirical statistics of arriving items are tracked across calls.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.sumsq = 0.0
        self.min_seen = 100
        # small quantile estimate via simple P-square-ish reservoir
        self.small = []  # keep a bounded sample of the smallest sizes

    def add(self, x):
        self.n += 1
        self.sum += x
        self.sumsq += x * x
        if x < self.min_seen:
            self.min_seen = x
        if len(self.small) < 512:
            self.small.append(x)
        else:
            # keep sampling smallest values
            if x < self.small[-1]:
                self.small[-1] = x
        # maintain sorted tail occasionally
        if self.n % 64 == 0:
            self.small.sort()

    def typical_small(self):
        if not self.small:
            return 1
        s = sorted(self.small)
        # 5th percentile-ish smallest typical size
        idx = max(0, int(0.05 * len(s)))
        return max(1, s[idx])


_STATS = _Stats()


def priority(item, bins):
    _STATS.add(item)

    # empirical smallest typical item size -> threshold for "useless" gaps
    thresh = _STATS.typical_small()

    cap = bins.astype(np.float64)
    leftover = cap - item

    # Best-fit core: reward small leftover
    tightness = -leftover

    # Mild bonus for reusing already-open bins (cap < 100 means non-empty)
    reuse = np.where(cap < 100.0, 3.0, 0.0)

    # Penalty for gaps that are positive but too small to fit a typical item
    bad_gap = ((leftover > 0) & (leftover < thresh)).astype(np.float64)
    gap_penalty = 4.0 * bad_gap

    score = tightness + reuse - gap_penalty
    return score
# EVOLVE-BLOCK-END
