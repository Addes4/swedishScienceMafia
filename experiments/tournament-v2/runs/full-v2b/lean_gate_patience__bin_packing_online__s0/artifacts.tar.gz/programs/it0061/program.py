# EVOLVE-BLOCK-START
"""Best-fit with a mild anti-fragmentation term: tightest fit wins,
reuse already-used bins, reward perfect fits, and slightly penalize
bins whose residual would remain awkwardly large relative to the item."""
import numpy as np


def priority(item, bins):
    rem = bins.astype(np.float64)
    leftover = rem - item

    # primary: best fit (smallest leftover is best)
    score = -leftover

    # reuse bonus: prefer already-used bins so we don't open new bins needlessly
    used = rem < 100.0
    score += used * 5.0

    # perfect fit: strongly reward filling a bin exactly
    perfect = leftover == 0.0
    score += perfect * 20.0

    # anti-fragmentation: mildly penalize residuals that stay large
    # (i.e. items placed into near-empty bins when a tighter fit exists)
    score -= np.maximum(leftover, 0.0) * 0.05

    return score
# EVOLVE-BLOCK-END
