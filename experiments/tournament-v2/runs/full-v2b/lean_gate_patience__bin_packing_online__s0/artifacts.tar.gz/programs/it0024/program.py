# EVOLVE-BLOCK-START
"""Best-fit with a learned sliver penalty.

Tightest fit stays dominant. We additionally penalize leftovers that are below a
learned small-item threshold (dead space), and give a modest reward for exactly
filling a bin. Statistics of past items are tracked across calls.
"""
import numpy as np

_HIST_SIZE = 101
_state = {
    "n": 0,
    "hist": np.zeros(_HIST_SIZE, dtype=np.float64),
}


def _update(item):
    s = _state
    s["n"] += 1
    if 1 <= item <= 100:
        s["hist"][item] += 1.0


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    bins = np.asarray(bins)
    remaining = bins - item
    rem_f = remaining.astype(np.float64)

    # Tightest fit first: smaller leftover is better (dominant term).
    score = -rem_f * 10.0

    # Reward exactly filling a bin.
    score += 4.0 * (remaining == 0)

    # Learned small-item threshold: residuals below this are effectively dead.
    n = _state["n"]
    if n > 50:
        hist = _state["hist"]
        total = hist.sum()
        if total > 0:
            sizes = np.arange(1, _HIST_SIZE)
            cum = np.cumsum(hist[1:]) / total
            # ~20th percentile of observed item sizes as the "small item" size
            idx = np.searchsorted(cum, 0.20)
            thr = int(sizes[min(idx, len(sizes) - 1)])
        else:
            thr = 6
    else:
        thr = 6
    thr = max(thr, 2)

    # Penalize residuals that are positive but below the small-item threshold.
    sliver = (remaining > 0) & (remaining < thr)
    score -= 3.0 * sliver

    _update(item)
    return score
# EVOLVE-BLOCK-END
