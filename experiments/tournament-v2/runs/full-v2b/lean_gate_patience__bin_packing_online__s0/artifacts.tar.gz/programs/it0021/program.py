# EVOLVE-BLOCK-START
"""Best-fit with a residual-reusability tie-break.

Primary rule: tightest fit (smallest leftover). Within a small grace window of
the tightest fit we break ties by preferring residuals that are themselves
plausible future item sizes (so they can be exactly filled later), using an
empirical histogram of past item sizes. Exact fills are always preferred.
"""
import numpy as np

# --- empirical item statistics tracked across calls ---
_state = {
    "n": 0,
    "mean": 0.0,
    "m2": 0.0,
    "smallest": 101,
    "hist": np.zeros(101, dtype=np.float64),   # counts of seen item sizes 1..100
}


def _update(item):
    s = _state
    s["n"] += 1
    d = item - s["mean"]
    s["mean"] += d / s["n"]
    s["m2"] += d * (item - s["mean"])
    if item < s["smallest"]:
        s["smallest"] = item
    if 1 <= item <= 100:
        s["hist"][item] += 1.0


# Grace window: residuals within this many units of the tightest fit are
# treated as approximate ties and compared by reusability.
_GRACE = 4.0


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities (including empty bins = 100), in order.
    """
    bins = np.asarray(bins)
    remaining = bins - item                 # leftover capacity if placed here
    rem_f = remaining.astype(np.float64)

    # Tightest fit dominant term.
    tight = -rem_f

    # --- reusability of the residual ---
    hist = _state["hist"]
    total = hist.sum()
    if total > 0:
        reuse = hist / total                # P(future item == r)
    else:
        reuse = np.zeros(101, dtype=np.float64)

    # Map each residual to its reuse probability (clamp out-of-range to 0).
    r_idx = np.clip(remaining, 0, 100).astype(np.int64)
    reuse_prob = reuse[r_idx]
    reuse_prob = np.where(remaining >= 0, reuse_prob, 0.0)

    # Bonus weight that only matters inside the grace window (approximate tie).
    tiebreak = 30.0 * reuse_prob

    # Strong bonus for exact fill.
    exact = (remaining == 0).astype(np.float64)
    exact_bonus = 8.0 * exact

    # Only apply the tie-break near the tightest fit: mask by proximity.
    best_rem = np.min(remaining[remaining >= 0]) if np.any(remaining >= 0) else 0
    near = (np.abs(rem_f - best_rem) <= _GRACE).astype(np.float64)

    score = tight + exact_bonus + tiebreak * near

    _update(item)
    return score
# EVOLVE-BLOCK-END
