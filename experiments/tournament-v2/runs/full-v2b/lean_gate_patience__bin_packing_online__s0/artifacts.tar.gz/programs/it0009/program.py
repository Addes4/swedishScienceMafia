# EVOLVE-BLOCK-START
"""
Adaptive best-fit with residual-utility ranking.

Prefer tight fits (best-fit), but among candidates reward residuals that can
still accept a typical future item and penalize residuals that are too small to
be usable.  A modest penalty discourages opening fresh (empty) bins, which
reduces bin proliferation.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0
        self._util = None
        self._util_count = -1.0

    def add(self, size):
        self.hist[size] += 1.0
        self.count += 1.0
        self._util = None

    def utility_table(self):
        if self._util is not None and self._util_count == self.count:
            return self._util
        if self.count < 5.0:
            cdf = np.linspace(0.0, 1.0, 101)
        else:
            p = self.hist / self.count
            cdf = np.cumsum(p)  # P(size <= x), index r means size<=r
        unfit = 1.0 - cdf            # P(size > r)
        # probability at least one of the next ~2 items fits in residual r
        util = 1.0 - np.clip(unfit, 0.0, 1.0) ** 2.0
        util[0] = 0.0
        self._util = util
        self._util_count = self.count
        return util


_STATS = _Stats()


def priority(item, bins):
    _STATS.add(int(item))
    util = _STATS.utility_table()

    residual = bins - item      # >= 0 guaranteed
    tight = -residual.astype(np.float64)
    u = util[residual]

    # Penalize opening a brand-new empty bin so used bins get consolidated.
    fresh_penalty = np.where(bins == 100, -2.0, 0.0)

    # Tightness dominates (scale 1.0 per unit residual); utility breaks ties
    # strongly (range up to ~4) so a residual that can host a typical item is
    # clearly preferred over one that cannot.
    score = tight + 4.0 * u + fresh_penalty
    return score
# EVOLVE-BLOCK-END
