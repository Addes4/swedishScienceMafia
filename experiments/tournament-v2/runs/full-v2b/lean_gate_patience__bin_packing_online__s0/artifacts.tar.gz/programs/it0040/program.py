# EVOLVE-BLOCK-START
"""Best-fit with mild open-bin / close-bin nudges.

Primary objective: smallest leftover capacity (best fit). Secondary terms
are small and bounded so they only break ties among comparable fits:
  * small bonus for reusing already-non-empty bins,
  * modest reward for exactly filling a bin (leftover 0).
Item-size statistics are tracked but used only for a tiny adaptive nudge.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.hist = np.zeros(101, dtype=np.float64)

    def add(self, x):
        self.n += 1
        if 1 <= x <= 100:
            self.hist[x] += 1.0

    def mean(self, default=40.0):
        if self.n < 20:
            return default
        total = self.hist.sum()
        if total <= 0:
            return default
        idx = np.arange(101, dtype=np.float64)
        return float((self.hist * idx).sum() / total)


_STATS = _Stats()


def priority(item, bins):
    _STATS.add(item)

    cap = bins.astype(np.float64)
    leftover = cap - item

    # Best-fit core: smallest leftover wins.
    score = -leftover

    # Mild preference to reuse already-open bins (cap < 100 => non-empty).
    score += np.where(cap < 100.0, 0.6, 0.0)

    # Modest reward for exactly closing a bin.
    score += np.where(leftover == 0.0, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
