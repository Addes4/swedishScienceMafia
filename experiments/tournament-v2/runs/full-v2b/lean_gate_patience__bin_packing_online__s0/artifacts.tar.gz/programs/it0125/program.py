# EVOLVE-BLOCK-START
"""Best-fit with reuse plus smooth residue shaping.

Primary rule: never open a new bin if any used bin can hold the item.
Among used fitting bins, strict best-fit (smallest residual) dominates.
A small smooth bonus favors moderate residues over tiny scraps, which
reduces the number of bins stuck with unusable leftover capacity, while
still strongly rewarding exact fills (residual 0).
"""
import numpy as np

_count = 0
_mean = 40.0


def _update_stats(item):
    global _count, _mean
    _count += 1
    lr = 1.0 / _count if _count < 50 else 0.02
    _mean = (1.0 - lr) * _mean + lr * item


def priority(item, bins):
    """Return a priority per bin; highest wins."""
    _update_stats(item)

    bins = bins.astype(np.int64)
    residual = bins - item  # >=0 for fitting bins, <0 otherwise
    fits = residual >= 0

    # Used bins have remaining capacity < 100.
    used = bins < 100

    # Base: strongly prefer used bins over empty ones.
    score = used.astype(np.float64) * 1000.0

    # Among used bins, best-fit dominates: smaller residual -> larger score.
    rf = residual.astype(np.float64)
    score += np.where(fits, 100.0 - rf, -1000.0)

    # Exact-fill bonus: closing a bin to exactly 0 is very valuable.
    score += np.where(fits & (residual == 0), 50.0, 0.0)

    # Smooth residue shaping: among used fitting bins slightly prefer
    # moderate residues (around ~mean item size) over tiny scraps, since
    # tiny scraps are hard to reuse. Bounded and small so best-fit order
    # is not overridden for clearly different residuals.
    mu = max(1.0, _mean)
    shaped = -np.abs(rf - mu) * 0.01
    score += np.where(fits & used & (residual != 0), shaped, 0.0)

    # Empty bins: mild preference for the first empty bin (stable order).
    empties = (bins >= 100)
    score += np.where(empties, -rf * 0.001, 0.0)

    return score
# EVOLVE-BLOCK-END
