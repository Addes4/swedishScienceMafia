# EVOLVE-BLOCK-START
"""Sum-of-squares ranker with an online residue-usefulness bonus."""
import numpy as np

CAP = 100
_bins = 101

# Online histogram of item sizes seen so far, plus count.
_hist = np.zeros(CAP + 1, dtype=np.float64)
_seen = 0.0


def _usefulness(res, hist, seen):
    """Estimate how likely a future item fits snugly into a leftover of size res.

    We compute P(item in [res*0.6, res]) roughly, i.e. the chance the leftover is
    nicely consumed. Uses the running histogram, smoothed.
    """
    if seen <= 0.0:
        # Offline default: distribution is Weibull-ish with mean ~40.
        # Smooth prior over sizes 1..100 with a reasonable shape.
        # Use a simple decreasing density favoring mid sizes.
        lo = int(res * 0.55)
        if lo < 1:
            lo = 1
        hi = int(res)
        if hi > CAP:
            hi = CAP
        if hi < lo:
            return 0.0
        x = np.arange(lo, hi + 1, dtype=np.float64)
        # crude prior density ~ shape favoring values near 25-60
        dens = np.exp(-((x - 40.0) ** 2) / (2 * 18.0 * 18.0))
        return float(dens.sum())
    lo = int(res * 0.55)
    if lo < 1:
        lo = 1
    hi = int(res)
    if hi > CAP:
        hi = CAP
    if hi < lo:
        return 0.0
    return float(hist[lo:hi + 1].sum() / seen)


def priority(item, bins):
    global _seen
    # Residual we would create in each bin.
    res = bins - item  # >= 0 for all shown bins

    # Sum-of-squares style: prefer large post-fill usage => smaller res with
    # larger current fill. score ~ (bins^2 - res^2) = item-dependent constant
    # plus 2*item*bins - item^2; but using squared residuals change:
    # delta = res^2 - bins^2 (negative when we fill up). Prefer more negative.
    delta = res.astype(np.float64) ** 2 - bins.astype(np.float64) ** 2

    # Tightness: strongly reward small residue (exact fit best).
    score = -delta  # positive; larger when residue smaller / bin fuller
    score = score * 1e-3

    # Residue usefulness bonus (probability a future item snugly fits).
    hist = _hist
    seen = _seen
    # Precompute usefulness for distinct residues to avoid repeated work.
    # Residues range 0..100.
    useful = np.empty(CAP + 1, dtype=np.float64)
    if seen > 0.0:
        csum = np.concatenate(([0.0], np.cumsum(hist)))
        for r in range(CAP + 1):
            lo = int(r * 0.55)
            if lo < 1:
                lo = 1
            hi = r
            if lo > hi:
                useful[r] = 0.0
            else:
                useful[r] = (csum[hi + 1] - csum[lo]) / seen
    else:
        x = np.arange(1, CAP + 1, dtype=np.float64)
        dens = np.exp(-((x - 40.0) ** 2) / (2 * 18.0 * 18.0))
        csum = np.concatenate(([0.0], np.cumsum(dens)))
        for r in range(CAP + 1):
            lo = int(r * 0.55)
            if lo < 1:
                lo = 1
            hi = r
            if lo > hi:
                useful[r] = 0.0
            else:
                useful[r] = csum[hi + 1] - csum[lo]

    ri = res.astype(np.int64)
    score = score + useful[ri] * 0.5

    # Exact fit bonus.
    score = score + (res == 0) * 0.3

    # Mild non-empty-bin bonus to encourage filling existing bins.
    score = score + (bins < CAP) * 0.01

    # Update online statistics with the arriving item (before placing).
    _hist[item] += 1.0
    _seen += 1.0

    return score
# EVOLVE-BLOCK-END
