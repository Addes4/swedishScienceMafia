# EVOLVE-BLOCK-START
"""Residue-value ranker: prefer tight fits, but value leftovers that future items can use.

We keep an online histogram of arriving item sizes. For a candidate bin we look at the
leftover space r = bin_remaining - item after placement, and score how "useful" that
residue is: how likely some future item fits snugly into it. A tight fit is strongly
preferred; small dead-zone residues (too small to be useful for typical items) are
penalized; exact fits and non-empty bins get small bonuses.
"""
import numpy as np

# Online histogram of item sizes (integer 1..100).
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0

# Precompute a usefulness kernel per residue lazily via cached arrays.
_USE = None
_DEAD = None


def _build_tables():
    """Build residue-usefulness and dead-zone tables from the current histogram."""
    global _USE, _DEAD
    if _total <= 0:
        # No data yet: mostly rely on tightness, mild dead-zone penalty.
        use = np.ones(101, dtype=np.float64)
        dead = np.zeros(101, dtype=np.float64)
        _USE = use
        _DEAD = dead
        return

    p = _hist / _total  # probability mass of each item size 1..100
    # Mean item size.
    sizes = np.arange(101, dtype=np.float64)
    mean_size = float(np.dot(p, sizes))

    use = np.zeros(101, dtype=np.float64)
    dead = np.zeros(101, dtype=np.float64)
    for r in range(0, 101):
        if r == 0:
            use[r] = 1.0  # exact fill is ideal
            dead[r] = 0.0
            continue
        # Snug-fit usefulness: sum of mass of item sizes in [r*0.85, r] roughly,
        # i.e. items that fit and leave little waste.
        lo = int(np.floor(0.8 * r))
        if lo < 1:
            lo = 1
        snug = float(np.sum(p[lo:r + 1])) if r >= lo else 0.0
        # Any-fit usefulness: mass of item sizes <= r.
        anyf = float(np.sum(p[1:r + 1])) if r >= 1 else 0.0
        use[r] = snug + 0.35 * anyf
        # Dead-zone: residue too small for most items but not exactly zero.
        # If r is well below the mean item size, it is awkward to use.
        if 0 < r < 0.55 * mean_size:
            dead[r] = 1.0 - (r / (0.55 * mean_size))
        else:
            dead[r] = 0.0

    _USE = use
    _DEAD = dead


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    global _total
    # Update online histogram with the arriving item.
    if 1 <= item <= 100:
        _hist[item] += 1.0
        _total += 1.0

    _build_tables()

    diff = bins - item  # leftover residue for each bin after placement
    # Tightness: strongly prefer small residue (best fit); scaled mildly.
    tight = -diff.astype(np.float64)

    # Clip residue into table range for usefulness lookup.
    r_idx = np.clip(diff, 0, 100)
    use = _USE[r_idx]
    dead = _DEAD[r_idx]

    exact = (diff == 0).astype(np.float64)
    nonempty = (bins < 100).astype(np.float64)

    score = tight + 6.0 * use - 5.0 * dead + 3.0 * exact + 1.0 * nonempty
    return score
# EVOLVE-BLOCK-END
