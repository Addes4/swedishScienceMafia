# EVOLVE-BLOCK-START
"""Best-fit dominant with a small, smooth residual-reusability bias.

The primary key is the tightest fit (smallest leftover). A tiny secondary
term nudges among near-ties toward leftovers that are themselves likely to be
exactly refilled, using a running estimate of the item-size distribution.
Never looks at the future.
"""
import numpy as np

_STATE = {
    "n": 0,
    "sum": 0.0,
    "counts": np.zeros(101, dtype=np.float64),  # empirical size histogram
}

# Tightness strictly dominates: the residual penalty is on the order of the
# item range (<=100), while the secondary bias is bounded by ~1.
_TIGHT = 1000.0


def _update_state(item):
    _STATE["n"] += 1
    _STATE["sum"] += item
    if 0 <= item <= 100:
        _STATE["counts"][item] += 1.0


def priority(item, bins):
    _update_state(item)

    bins = np.asarray(bins, dtype=np.int64)
    remainder = bins - item          # >= 0 by contract
    rem_f = remainder.astype(np.float64)

    # Primary: tightest fit.
    score = -_TIGHT * rem_f

    # Secondary: prefer leftovers that are "reachable" item sizes, i.e. the
    # residual itself is a plausible next item size -> high chance of being
    # exactly filled later, avoiding dead slivers. Also softly reward exact
    # fills.
    n = _STATE["n"]
    counts = _STATE["counts"]
    if n > 0 and counts.sum() > 0:
        probs = counts / counts.sum()
    else:
        probs = np.zeros(101, dtype=np.float64)

    # Probability mass near the residual size (smoothed over +-2).
    def mass(r):
        lo = int(max(0, r - 2))
        hi = int(min(100, r + 2))
        return probs[lo:hi + 1].sum()

    # Only meaningful for residuals in [1,100]; larger leftovers are treated
    # as freely reusable (not slivers), so give them the neutral max.
    safe_r = np.clip(remainder, 0, 100)
    # Vectorized smoothed mass via convolution-like gather.
    weights = np.zeros(101, dtype=np.float64)
    for d in range(-2, 3):
        idx = np.arange(0, 101) + d
        valid = (idx >= 0) & (idx <= 100)
        weights[valid] += probs[idx[valid]]

    mass_at_r = weights[safe_r]
    big = remainder > 100
    mass_at_r = np.where(big, 1.0, mass_at_r)

    score += 1.0 * mass_at_r

    # Tiny extra reward for a perfect fill.
    score += np.where(remainder == 0, 0.5, 0.0)

    return score
# EVOLVE-BLOCK-END

