# EVOLVE-BLOCK-START
"""Best-fit with reuse preference and exact-closure bonus."""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for fitting bins

    used = bins < 100

    # Base: tightest fit.
    score = -residual.astype(np.float64)

    # Strong bonus for reusing already-open bins.
    score += np.where(used, 1000.0, 0.0)

    # Extra bonus for residual that is small but nonzero (near-exact close), and for exact close.
    # Exact fit: residual == 0 -> strongly preferred.
    score += np.where(residual == 0, 500.0, 0.0)

    return score
# EVOLVE-BLOCK-END
