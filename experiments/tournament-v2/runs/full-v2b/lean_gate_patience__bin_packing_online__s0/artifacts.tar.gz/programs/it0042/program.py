# EVOLVE-BLOCK-START
"""Least-waste / reserve ranker.

Tracks arriving-item statistics and ranks candidate bins by how close the
post-placement residual is to a target residual equal to the median item size.
Packing which leaves a residual near one typical item keeps future large items
packable, while near-empty leaves (residual ~0) and large residuals are both
mildly discouraged. A small bonus for reusing already-open bins avoids opening
fresh bins unless the fit is genuinely good.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.hist = np.zeros(101, dtype=np.float64)

    def add(self, x):
        self.n += 1
        if 1 <= x <= 100:
            self.hist[x] += 1

    def median_item(self):
        if self.n < 20:
            return 40.0
        # weighted median from histogram
        total = self.hist[1:101].sum()
        if total <= 0:
            return 40.0
        c = 0.0
        half = total / 2.0
        for v in range(1, 101):
            c += self.hist[v]
            if c >= half:
                return float(v)
        return 40.0

    def mean_item(self):
        if self.n < 1:
            return 40.0
        tot = self.hist[1:101].sum()
        if tot <= 0:
            return 40.0
        return float((self.hist[1:101] * np.arange(1, 101)).sum() / tot)


_STATS = _Stats()


def priority(item, bins):
    _STATS.add(item)

    target = _STATS.median_item()

    cap = bins.astype(np.float64)
    leftover = cap - item

    # Distance of residual from the target reserve; smaller is better.
    # Clamp residual at 0 (exact fill is acceptable, not catastrophic).
    dist = np.abs(leftover - target)

    # Base: prefer residual close to the reserve target.
    score = -dist

    # Slight preference for already-open bins (non-empty => cap < 100).
    score += np.where(cap < 100.0, 2.0, 0.0)

    # Reward near-exact fills so closed bins are valued.
    score += np.where(leftover <= 0.5, 3.0, 0.0)

    # Penalize residuals that are positive but smaller than typical small item
    # (dead slivers) so we don't fragment.
    dead = (leftover > 0.5) & (leftover < target * 0.5)
    score -= 3.0 * dead.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
