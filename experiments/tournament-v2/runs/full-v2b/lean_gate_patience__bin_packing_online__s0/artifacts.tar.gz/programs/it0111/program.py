# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with adaptive residue shaping.

Primary signal is strict best-fit (least leftover after placing the item).
On top of that we (1) reward residues that match likely future small item
sizes (estimated online via a histogram) so bins tend to be left with a gap
just large enough for a likely small item, and (2) mildly penalize residues
that are so tiny they are unlikely to ever be filled by any future item
(below an online low percentile). Reuse of open bins strictly dominates.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0
        self.hist = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.n += 1.0
        self.sum += item
        self.hist[item] += 1.0

    @property
    def mean(self):
        if self.n >= 1.0:
            return self.sum / self.n
        return 40.0

    def small_targets(self):
        h = self.hist
        total = h.sum()
        if total < 20.0:
            return np.array([5.0, 10.0, 15.0], dtype=np.float64)
        lo = h[:26].copy()
        if lo.sum() <= 0.0:
            return np.array([5.0, 10.0, 15.0], dtype=np.float64)
        order = np.argsort(lo)[::-1]
        targets = []
        for idx in order:
            if lo[idx] <= 0.0:
                break
            targets.append(float(idx))
            if len(targets) >= 3:
                break
        if not targets:
            targets = [5.0, 10.0, 15.0]
        return np.array(targets, dtype=np.float64)

    def tiny_threshold(self):
        """Online estimate of a small item size; residues below this are
        unlikely to ever be filled usefully."""
        h = self.hist
        total = h.sum()
        if total < 50.0:
            return 1.0
        c = np.cumsum(h)
        target = 0.03 * total
        idx = int(np.searchsorted(c, target))
        if idx < 1:
            idx = 1
        return float(max(idx, 1))


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    b = bins.astype(np.float64)
    unused = b >= 100.0

    resid = b - float(item)

    # Strict best-fit: smaller residue is better (tightest fit).
    fit = -resid / 100.0

    # Critical-residue bonus: reward residues matching likely small future items.
    targets = _stats.small_targets()
    if targets.size > 0:
        d = np.abs(resid[:, None] - targets[None, :])
        near = np.min(d, axis=1)
    else:
        near = np.zeros_like(resid)
    bonus = 0.15 * (1.0 - np.minimum(near, 15.0) / 15.0)

    # Penalise tiny residues that no future item can realistically fill.
    thr = _stats.tiny_threshold()
    tiny_pen = 0.05 * np.maximum(0.0, (thr - resid) / max(thr, 1.0)) * (resid >= 0.0)

    # Strictly prefer reusing a non-empty bin over opening a fresh one.
    reuse = np.where(unused, 0.0, 1.0)

    score = fit + 0.5 * reuse + bonus - tiny_pen

    return score
# EVOLVE-BLOCK-END
