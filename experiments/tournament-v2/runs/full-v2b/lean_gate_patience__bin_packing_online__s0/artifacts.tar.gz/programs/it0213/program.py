# EVOLVE-BLOCK-START
"""Convex-tightness ranker.

For each candidate bin, let diff = remaining - item (post-placement residue >= 0).
We score with a mildly convex penalty on residue, which pushes items into fuller
bins and reduces fragmentation more than pure best-fit. Ties broken by preferring
non-empty bins, and exact fills get a bonus.
"""
import numpy as np

_C = 0.02


def priority(item, bins):
    diff = bins - item
    d = diff.astype(np.float64)

    score = -d - _C * d * d

    exact = (diff == 0).astype(np.float64)
    nonempty = (bins < 100).astype(np.float64)

    score = score + 1.0 * exact + 0.01 * nonempty
    return score
# EVOLVE-BLOCK-END
