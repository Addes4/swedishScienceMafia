# EVOLVE-BLOCK-START
"""Hybrid ranker: tight fit + residue-quality + reuse-existing-bin bonus."""
import numpy as np

# Online statistics of arriving items
_state = {"n": 0, "mean": 40.0, "min_small": 5.0, "sum": 0.0}


def priority(item, bins):
    """Score every bin: prefer tight fits, good residues, and reusing non-full bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (100 for unused), in bin order.
    """
    bins = np.asarray(bins)

    # Update online item statistics
    _state["n"] += 1
    _state["sum"] += item
    _state["mean"] = _state["sum"] / _state["n"]
    # Track a robust "typical small item" threshold (running min-ish, smoothed)
    if item < _state["min_small"]:
        _state["min_small"] = 0.7 * _state["min_small"] + 0.3 * item
    elif _state["n"] % 200 == 0:
        _state["min_small"] = _state["min_small"] * 1.01

    mean_item = _state["mean"]
    small_item = max(1.0, _state["min_small"])

    leftover = bins - item  # >= 0 for admissible bins

    # Base: best fit -> smaller leftover is better.
    score = -leftover.astype(np.float64)

    # Penalize residues that are too small to be useful for future items.
    # A residue near 0 is good (perfect fit), but residues in (0, small_item)
    # are generally wasted. Smoothly reward bins whose residue is either 0
    # or >= small_item, penalize tiny nonzero gaps.
    resid = leftover.astype(np.float64)
    tiny = (resid > 0) & (resid < small_item)
    if np.any(tiny):
        # penalty scales with how much smaller than a typical small item
        pen = (small_item - resid[tiny]) * 0.5
        score[tiny] -= pen

    # Bonus for reusing a non-empty bin (leftover < 100) to avoid opening new bins.
    # New bins (leftover == 100) are only opened for a strong fit.
    is_new = bins >= 100
    score[is_new] -= 8.0

    # Slight preference proportional to fill level: fuller bins are good to fill more.
    score += (100 - bins).astype(np.float64) * 0.02

    # Mild bias toward residues that align with typical item size (packability).
    if np.any(~is_new):
        good_resid = np.abs(resid - small_item) < small_item * 0.5
        score[good_resid & ~is_new] += 1.0

    return score
# EVOLVE-BLOCK-END
