# EVOLVE-BLOCK-START
"""Online bin packing: best-fit with a smooth residue-match bonus.

Primary signal is strict best-fit (least leftover after placing the item).
On top of that we reward placements whose post-placement residue is close to
a size that is likely to arrive later, using a smooth window over the full
online size histogram (so any recurring size -- not just a few peaks -- can
be matched). Reusing an open bin strictly dominates opening a fresh one.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0.0
        self.sum = 0.0
        self.hist = np.zeros(102, dtype=np.float64)  # counts for sizes 0..101

    def update(self, item):
        self.n += 1.0
        self.sum += item
        self.hist[item] += 1.0

    @property
    def mean(self):
        if self.n >= 1.0:
            return self.sum / self.n
        return 40.0

    def residue_prob(self, residues, tol=2.0):
        """Smooth probability (weighted count) of a future item matching each residue.

        Sums the observed histogram over sizes within `tol` of every residue,
        normalized by the total number of observations. Returns float array.
        """
        total = self.hist.sum()
        if total < 10.0:
            return np.zeros_like(residues)
        # Only residues that are valid leftover gaps (>=1) can be matched.
        r = np.clip(np.round(residues), 0, 101).astype(np.int64)
        w = np.zeros_like(residues)
        width = int(round(tol))
        for d in range(-width, width + 1):
            idx = np.clip(r + d, 0, 101)
            w += self.hist[idx]
        return w / total


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    _stats.update(item)

    b = bins.astype(np.float64)
    unused = b >= 100.0

    # Post-placement residue.
    resid = b - float(item)

    # Strict best-fit: smaller residue is better (tightest fit).
    fit = -resid / 100.0

    # Smooth residue-match bonus: reward residues that a likely future item
    # could fill to a near-exact degree. Zero out non-positive residues.
    rb = _stats.residue_prob(resid)
    rb = np.where(resid >= 1.0, rb, 0.0)
    bonus = 0.2 * rb

    # Strictly prefer reusing a non-empty bin over opening a fresh one.
    reuse = np.where(unused, 0.0, 1.0)

    score = fit + 0.5 * reuse + bonus
    score = np.where(np.isnan(score), -1e9, score)

    return score
# EVOLVE-BLOCK-END
