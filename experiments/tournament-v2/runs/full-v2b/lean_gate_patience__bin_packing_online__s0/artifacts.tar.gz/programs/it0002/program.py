# EVOLVE-BLOCK-START
"""Best fit with a small residual penalty to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer tight fits; subtract a tiny penalty proportional to the residual
    # so that among near-equal fits we favor leaving a very small remainder
    # (which tends to enable exact fills later).
    return -residual - 0.001 * residual
# EVOLVE-BLOCK-END
