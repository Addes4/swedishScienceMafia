# EVOLVE-BLOCK-START
"""Best-fit with residual-matching nudge.

Primary rule: tightest fit (smallest residual dominates).
Secondary nudge: prefer residuals that either are 0 (exact fill) or that match
sizes we have actually seen as items, since such residuals can later be filled
exactly. Statistics come only from past items; no future information is used.
"""
import numpy as np

_STATE = {
    "n": 0,
    "sum": 0.0,
    "seen": None,   # boolean lookup of item sizes seen so far (1..100)
}

_TIGHT = 1000.0


def _update_state(item):
    _STATE["n"] += 1
    _STATE["sum"] += item
    seen = _STATE["seen"]
    if seen is None:
        seen = np.zeros(101, dtype=bool)
        _STATE["seen"] = seen
    if 0 <= item <= 100:
        seen[item] = True


def priority(item, bins):
    _update_state(item)

    bins = np.asarray(bins, dtype=np.int64)
    remainder = bins - item
    rem_f = remainder.astype(np.float64)

    # Primary: tightest fit (smallest residual preferred).
    score = -_TIGHT * rem_f

    # Secondary: reward residuals that are exactly 0 (perfect fill) ...
    score += np.where(remainder == 0, 2.0, 0.0)

    # ... or that equal a size we have actually seen as an item (reusable gap).
    seen = _STATE["seen"]
    clipped = np.clip(remainder, 0, 100)
    reusable = seen[clipped]
    score += np.where(reusable & (remainder > 0), 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
