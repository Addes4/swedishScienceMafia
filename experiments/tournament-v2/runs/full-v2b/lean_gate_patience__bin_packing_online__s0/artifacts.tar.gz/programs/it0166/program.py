# EVOLVE-BLOCK-START
"""Best-fit dominant ranker with a residual-consolidation tie-break."""
import numpy as np


def priority(item, bins):
    rem = np.asarray(bins, dtype=np.int64)
    leftover = rem - item  # items that fit have leftover >= 0

    # Dominant term: prefer smallest leftover (classic best fit).
    # Scale leftovers to a small band so tie-breaks can act within them.
    score = -leftover.astype(np.float64) * 100.0

    # Exact fit bonus (strongly dominant over any tie-break).
    score += (leftover == 0).astype(np.float64) * 10000.0

    # Non-empty preference: avoid opening fresh bins when a fit exists elsewhere.
    nonempty = leftover < 100
    score += nonempty.astype(np.float64) * 5.0

    # Consolidation tie-break: count how often each leftover value occurs among
    # bins (post-placement), and reward residuals that already appear, so we
    # collapse many small residual classes into fewer distinct ones.
    # Use negative counts as the ordering key so higher count -> higher score,
    # but keep magnitude small so best-fit still dominates.
    # Map each leftover value to its frequency via sorting.
    order = np.argsort(leftover, kind="stable")
    counts = np.zeros(leftover.shape[0], dtype=np.float64)
    sorted_l = leftover[order]
    n = sorted_l.shape[0]
    i = 0
    while i < n:
        j = i + 1
        while j < n and sorted_l[j] == sorted_l[i]:
            j += 1
        counts[order[i:j]] = float(j - i)
        i = j
    # Reward being in a larger residual group (consolidate); cap influence.
    score += np.minimum(counts, 8.0) * 0.5

    return score
# EVOLVE-BLOCK-END
