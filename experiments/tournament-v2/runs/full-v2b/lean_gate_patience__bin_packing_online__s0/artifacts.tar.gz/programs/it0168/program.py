# EVOLVE-BLOCK-START
"""Residue-value ranker: score bins by expected future waste of the leftover,
using a fixed Weibull-shaped prior over future item sizes."""
import numpy as np

_sizes_pdf = None
_sizes_cdf = None
_seen_hist = None
_seen_total = 0.0


def _build_prior():
    k = 2.0
    scale = 45.0
    pdf = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        x = s / scale
        pdf[s] = (k / scale) * (x ** (k - 1.0)) * np.exp(-(x ** k))
    total = pdf.sum()
    if total <= 0:
        pdf = np.ones(101, dtype=np.float64)
        total = pdf.sum()
    pdf = pdf / total
    cdf = np.cumsum(pdf)
    cdf = np.clip(cdf, 0.0, 1.0)
    return pdf, cdf


def _build_convolve(pdf):
    # Two-item sum distribution (self-convolution over 1..100)
    conv = np.zeros(201, dtype=np.float64)
    p = pdf[1:101]
    for i in range(100):
        if p[i] <= 0:
            continue
        conv[i + 1:i + 101] += p[i] * p
    return conv


_sizes_pdf, _sizes_cdf = _build_prior()
_sizes_conv = _build_convolve(_sizes_pdf)


def priority(item, bins):
    """Rank bins by how well the leftover can absorb future items (low waste)."""
    global _seen_hist, _seen_total

    arr = np.asarray(bins, dtype=np.float64)
    leftover = arr - float(item)

    idx = np.clip(leftover.astype(np.int64), 0, 100)

    # Base better-fit term: prefer small leftover.
    score = -leftover

    # Exact fit: strongest signal.
    score += (leftover == 0).astype(np.float64) * 40.0

    # Probability a single future item exactly matches leftover (1-item fill).
    exact1 = _sizes_pdf[idx]
    score += 25.0 * exact1

    # Probability leftover equals a sum of two future items (2-item fill).
    conv_idx = np.clip(leftover.astype(np.int64), 0, 200)
    exact2 = _sizes_conv[conv_idx]
    score += 12.0 * exact2

    # Reward residuals large enough to still fit a typical item.
    p_fit = 1.0 - _sizes_cdf[idx]
    score += 6.0 * p_fit

    # Prefer non-empty bins slightly to consolidate.
    nonempty = leftover < 100.0 - 1e-9
    score += nonempty.astype(np.float64) * 0.4

    return score
# EVOLVE-BLOCK-END
