# EVOLVE-BLOCK-START
"""Tightness-dominant ranker with light histogram-based tie-breaking.

Best-fit (smallest positive residue) is a strong online rule for this distribution.
We keep tightness dominant and only break near-ties using an online histogram: a
residue gets a small bonus if it matches a common item size (likely to be filled
later), and exact fits get a modest extra bonus.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_total = 0.0

_USE = None
_LAST_N = -1


def _build_tables():
    global _USE, _LAST_N
    if _total <= 0:
        _USE = np.ones(101, dtype=np.float64)
        _LAST_N = 0
        return
    if _total == _LAST_N and _USE is not None:
        return
    p = _hist / _total
    sizes = np.arange(101, dtype=np.float64)
    # Probability mass of item sizes that fit into residue r and are reasonably snug.
    use = np.zeros(101, dtype=np.float64)
    csum = np.cumsum(p)  # csum[r] = mass of sizes <= r
    for r in range(1, 101):
        lo = max(1, int(np.floor(0.7 * r)))
        snug = csum[r] - csum[lo - 1]
        use[r] = snug
    _USE = use
    _LAST_N = _total


def priority(item, bins):
    global _total
    if 1 <= item <= 100:
        _hist[item] += 1.0
        _total += 1.0

    _build_tables()

    diff = bins - item
    diff_f = diff.astype(np.float64)

    # Dominant: prefer smallest residue (best fit).
    tight = -diff_f

    r_idx = np.clip(diff, 0, 100)
    use = _USE[r_idx]
    exact = (diff == 0).astype(np.float64)
    nonempty = (bins < 100).astype(np.float64)

    score = tight + 1.5 * use + 2.0 * exact + 0.5 * nonempty
    return score
# EVOLVE-BLOCK-END
