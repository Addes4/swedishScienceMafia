# EVOLVE-BLOCK-START
"""Value-of-residue bin packing: prefer tight fits, but weight the leftover by how
useful it is likely to be for future items, estimated from an online histogram."""
import numpy as np

# Running histogram over item sizes 1..100, used to estimate the usefulness of a
# candidate leftover capacity. Counts are kept as a module-level array.
_COUNTS = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _TOTAL

    # Update the online item-size statistics before scoring.
    _COUNTS[item] += 1.0
    _TOTAL += 1.0

    b = np.asarray(bins, dtype=np.float64)
    leftover = b - float(item)  # remaining capacity after placing the item

    # --- Usefulness of the leftover capacity ---
    # Estimate the probability that a future item lands snugly in this leftover,
    # i.e. the share of past items whose size is close to the leftover (within a
    # small band), which indicates the residue will be well used rather than wasted.
    total = _TOTAL if _TOTAL > 0 else 1.0
    band = 12.0
    lo = np.clip(np.floor(leftover - band), 0, 100).astype(np.int64)
    hi = np.clip(np.floor(leftover), 0, 100).astype(np.int64)
    # Cumulative counts up to each index for quick band sums.
    cum = np.concatenate(([0.0], np.cumsum(_COUNTS)))
    usefulness = (cum[hi + 1] - cum[lo]) / total

    # --- Tightness: prefer small leftover ---
    tightness = -leftover / 100.0

    # --- Exact-fit bonus and non-empty-bin bonus ---
    exact = (leftover == 0.0).astype(np.float64)
    non_empty = (b < 100.0).astype(np.float64)

    score = tightness + 0.6 * usefulness + 0.5 * exact + 0.02 * non_empty
    return score
# EVOLVE-BLOCK-END
