# EVOLVE-BLOCK-START
"""Online bin choice: best-fit with a small, bounded residue-usefulness bonus."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_N = 0


def priority(item, bins):
    global _HIST, _N
    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item
    # Best-fit primary: maximize score => minimize residual among used bins.
    score = -residual

    # Penalize opening a fresh bin strongly.
    score = np.where(bins >= 100.0, score - 10000.0, score)

    # Bounded residue-usefulness bonus: prefer leaving a residual that is a common
    # item size, so a future item can close the bin exactly.
    if _N > 0:
        h = _HIST.copy()
        h[0] = 0.0
        s = h.sum()
        if s > 0:
            prob = h / s
            idx = np.clip(residual.astype(np.int64), 0, 100)
            bonus = prob[idx]
            # small, bounded: at most ~0.5 of a residual unit
            score = score + 0.5 * bonus

    # Update histogram (decayed) with this item.
    _HIST *= 0.999
    _HIST[item] += 1.0
    _N += 1

    return score
# EVOLVE-BLOCK-END
