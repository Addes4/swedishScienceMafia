# EVOLVE-BLOCK-START
"""Best-fit residual with distribution-aware residue usability bonus."""
import numpy as np


class _State:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)  # histogram of past item sizes
        self.n = 0.0

    def pdf(self):
        if self.n <= 0:
            return None
        return self.counts / self.n


_STATE = _State()


def priority(item, bins):
    st = _STATE

    leftover = bins - item  # post-placement remaining capacity, >= 0

    # Primary: best-fit tightness (prefer small leftovers).
    score = -leftover.astype(np.float64)

    pdf = st.pdf()
    if pdf is not None:
        # Smooth histogram over a small window to be robust for rare sizes.
        sm = pdf.copy()
        sm[1:] += pdf[:-1]
        sm[:-1] += pdf[1:]

        # Exact residue-match mass: how likely a future item exactly fills this bin.
        reuse = sm[leftover]

        # Usability of the residue: probability that some future item still fits
        # snugly enough to leave a small waste.  Estimate using the mass of items
        # that fit within the leftover, weighted by how tightly they fill it.
        cdf = np.cumsum(sm)
        cdf = cdf / cdf[-1]
        # P(item <= leftover)
        p_fit = cdf[leftover]
        # average fill quality: relative size of fitting items
        sizes = np.arange(101, dtype=np.float64)
        weights = sm * sizes
        cumw = np.cumsum(weights)
        totalw = cumw[-1] if cumw[-1] > 0 else 1.0
        # expected item size given it fits
        with np.errstate(invalid="ignore", divide="ignore"):
            avg_fit = np.where(cumw[leftover] > 0, cumw[leftover] / totalw, 0.0)
        # fraction of leftover likely reused
        util = np.divide(avg_fit, np.maximum(leftover, 1.0))

        score += 25.0 * reuse
        score += 6.0 * p_fit * util

    # Exact-fit bonus on the current item.
    score += 8.0 * (leftover == 0)

    # Slight preference against opening brand-new bins.
    score += 0.5 * (bins < 100)

    # Update online statistics with the arriving item.
    st.counts[item] += 1.0
    st.n += 1.0

    return score
# EVOLVE-BLOCK-END
