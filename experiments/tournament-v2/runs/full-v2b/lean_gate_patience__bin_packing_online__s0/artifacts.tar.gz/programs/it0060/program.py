# EVOLVE-BLOCK-START
"""Best-fit ranker: tightest fit wins, with a reuse bonus so new bins
are opened only when an existing bin offers a genuinely good fit."""
import numpy as np


def priority(item, bins):
    rem = bins.astype(np.float64)
    leftover = rem - item

    # primary: best fit (smallest leftover is best)
    score = -leftover

    # reuse bonus: prefer already-used bins so we don't open new bins needlessly
    used = rem < 100.0
    score += used * 5.0

    # perfect fit: strongly reward filling a bin exactly
    perfect = leftover == 0.0
    score += perfect * 20.0

    return score
# EVOLVE-BLOCK-END
