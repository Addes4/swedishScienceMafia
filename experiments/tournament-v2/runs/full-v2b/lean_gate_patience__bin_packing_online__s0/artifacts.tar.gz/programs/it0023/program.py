# EVOLVE-BLOCK-START
"""Reserve-for-later best-fit ranking.

Scores each bin by how well the item fits (tight fits preferred), with a mild
bonus for reusing non-empty bins, a reward for exactly filling bins, and a small
bonus when the residual left behind matches a frequently-seen future item size.
"""
import numpy as np

_SMALL = 15
_HIST_SIZE = 101
_state = {
    "n": 0,
    "hist": np.zeros(_HIST_SIZE, dtype=np.float64),
}


def _update(item):
    s = _state
    s["n"] += 1
    if 1 <= item <= 100:
        s["hist"][item] += 1.0


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    bins = np.asarray(bins)
    remaining = bins - item
    rem_f = remaining.astype(np.float64)

    # Tightest fit first: smaller leftover is better (dominant term).
    score = -rem_f * 10.0

    # Preference for reusing non-empty bins.
    non_empty = (bins < 100)
    score += np.where(non_empty, 2.0, 0.0)

    # Reward exactly filling a bin.
    score += 4.0 * (remaining == 0)

    # Penalize tiny dead slivers that no future item can use.
    score -= 3.0 * ((remaining > 0) & (remaining < 6))

    # Small bonus if the residual matches a frequent past item size (reusable).
    n = _state["n"]
    if n > 50:
        hist = _state["hist"]
        total = hist.sum()
        freq = hist / total
        # score for each residual: frequency of that size, clamped to [0,1]
        idx = np.clip(remaining, 0, 100)
        bonus = freq[idx] * 40.0
        # only apply for positive residuals (a real leftover), keep it small
        bonus = np.where(remaining > 0, bonus, 0.0)
        # cap so it can't override tightness
        score += np.minimum(bonus, 3.0)

    _update(item)
    return score
# EVOLVE-BLOCK-END
