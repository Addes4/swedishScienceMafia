# EVOLVE-BLOCK-START
"""
Best-fit with tie-breaking utility, properly scaled.

Pure best-fit is the dominant rule.  In case of near-equal residuals, we
break ties by preferring residual capacities that can still host typical
future items (learned online), and by avoiding opening fresh bins.
"""
import numpy as np


# ---------- online empirical distribution ----------
class _Stats:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0
        self._util = None
        self._util_count = -1.0

    def add(self, size):
        self.hist[size] += 1.0
        self.count += 1.0
        self._util = None

    def utility_table(self):
        if self._util is not None and self._util_count == self.count:
            return self._util
        if self.count < 5.0:
            p = np.full(101, 1.0 / 100.0)
        else:
            p = self.hist / self.count
        cdf = np.cumsum(p)
        unfit = 1.0 - cdf          # P(size > r)
        # P(at least one of next few items fits in r)
        util = 1.0 - np.power(np.clip(unfit, 0.0, 1.0), 4.0)
        util[0] = 0.0
        self._util = util
        self._util_count = self.count
        return util


_STATS = _Stats()


def priority(item, bins):
    _STATS.add(int(item))
    util = _STATS.utility_table()

    residual = bins - item          # >= 0
    tight = -residual.astype(np.float64) * 100.0   # dominant term

    u = util[residual]                             # in [0,1]
    fresh = np.where(bins == 100, -1.0, 0.0)       # mild bias vs new bins

    # exact-fit bonus
    exact = np.where(residual == 0, 1.0, 0.0)

    score = tight + 2.0 * u + fresh + exact
    return score
# EVOLVE-BLOCK-END

