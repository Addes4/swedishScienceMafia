# EVOLVE-BLOCK-START
"""Best fit with tightening tie-break: prefer tight fits, break ties toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit). Secondary: slight preference for fuller bins.
    return -residual * 1000.0 - bins
# EVOLVE-BLOCK-END

