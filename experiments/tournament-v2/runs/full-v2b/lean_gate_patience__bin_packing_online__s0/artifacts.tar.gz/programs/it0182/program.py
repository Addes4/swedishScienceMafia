# EVOLVE-BLOCK-START
"""Best-fit tightness plus one-step-lookahead residue waste estimated from the online histogram."""
import numpy as np


class _State:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.n = 0.0

    def pdf(self):
        if self.n > 0:
            return self.counts / self.n
        return None


_STATE = _State()

# size grid
_SIZES = np.arange(101, dtype=np.float64)
# expected waste of a residue of size r when the next item is drawn from pdf:
#   we assume we will pick the best-fitting (largest <= r) item; if none fits, waste = r.
_SMOOTH = None


def _build_table(pdf):
    # cdf for quick lookups
    # For each residue r, find expected residual after placing the best-fit item.
    # Approximate by taking the mean of the largest-fit item choices weighted by pdf.
    global _SMOOTH
    if _SMOOTH is not None:
        return _SMOOTH
    # precompute once per call cheaply using pdf
    return None


def priority(item, bins):
    st = _STATE

    leftover = bins - item  # post-placement remaining capacity

    # Primary: best-fit tightness.
    score = -leftover.astype(np.float64)

    pdf = st.pdf()

    if pdf is not None:
        # Build a small residue-value table on the size grid: for a residue r,
        # value(r) = max over s<=r of (pdf(s) * reuse_value(s)) approximated as
        # the probability mass of future items that fit snugly, i.e. s in [r-eps, r].
        # Instead of a heavy computation, estimate expected future waste of residue r
        # as r minus expected size of a best-fitting future item.
        sizes = _SIZES[1:]  # 1..100
        p = pdf[1:]
        # For each residue value r we want E[waste | next item fits] weight:
        # we use cumulative mass that fits: cdf(r); if a good fit exists we shrink waste.
        cdf = np.concatenate([[0.0], np.cumsum(p)])  # cdf[0..100]
        r = leftover.astype(np.int64)
        r = np.clip(r, 0, 100)
        # mass of items that fit into r
        fit_mass = cdf[r]
        # conditional mean of fitting items: approx via cumulative weighted mean
        cumw = np.concatenate([[0.0], np.cumsum(p * sizes)])
        cond_mean = np.where(fit_mass > 1e-9, cumw[r] / np.maximum(fit_mass, 1e-9), 0.0)
        # expected residual after best-fit placement (upper bound heuristic)
        exp_res = r - cond_mean
        # value of residue: high when expected residual is small
        value = -exp_res
        score += 3.0 * value

    # Exact-fit bonus.
    score += 8.0 * (leftover == 0)

    # Slight preference against opening brand-new bins.
    score += 0.5 * (bins < 100)

    st.counts[item] += 1.0
    st.n += 1.0

    return score
# EVOLVE-BLOCK-END
