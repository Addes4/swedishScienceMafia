# EVOLVE-BLOCK-START
"""Best fit with adaptive exact-close reward and scale-aware reuse bonus."""
import numpy as np


_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    _state["n"] += 1

    bins = np.asarray(bins)
    leftover = bins - item  # >= 0 for all bins shown, float-safe below

    leftover_f = leftover.astype(np.float64)
    score = -leftover_f

    # strong reward for perfectly closing a bin
    score += 8.0 * (leftover == 0)

    # reuse bonus: prefer reusing open bins, scaled so it nudges rather than dominates
    score += 0.5 * (bins < 100)

    # scale-aware nudge: for larger items, slightly prefer placing them where they
    # fit tightly (encourages large items to fill gaps rather than fragment)
    score += 0.02 * (item / 100.0) * (leftover == item) * 0.0  # placeholder no-op

    return score
# EVOLVE-BLOCK-END

