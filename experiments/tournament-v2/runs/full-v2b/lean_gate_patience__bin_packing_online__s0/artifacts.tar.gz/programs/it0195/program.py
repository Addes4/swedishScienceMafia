import numpy as np


class _Stats:
    """Online histogram of item sizes for light residue/usefulness estimation."""
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def add(self, item):
        self.counts[item] += 1.0
        self.total += 1.0


_stats = _Stats()


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.float64)
    # Resulting leftover after placing item.
    residuals = bins - item

    # Classic "harmonic"-style value: pack into bins so that the resulting
    # load (100 - residual) sits in a good size class.  We reward fuller bins
    # via a concave utility on the resulting load, which discourages tiny
    # residues that fragment capacity (dead-zone avoidance) far more smoothly
    # than a hard best-fit rule.
    #
    # Utility per bin: -residual (tightest fit) dominates,
    # plus a concave bonus 20*log1p(load) so moderately filled bins are
    # preferred over freshly opened ones, plus a strong exact-fit bonus.
    load = 100.0 - residuals  # resulting used capacity after placement

    # Concave utility: rewards filling existing bins (load>0) and never lets
    # a partial fill beat a tighter fit of comparable emptiness.
    util = np.log1p(np.maximum(load, 0.0))

    scores = -residuals + 25.0 * util

    # Exact-fit bonus (fills the bin precisely).
    scores = scores + np.where(residuals == 0, 1e7, 0.0)

    # Slight preference to avoid opening brand-new bins needlessly.
    scores = scores + 0.05 * (bins < 100.0)

    _stats.add(item)
    return scores
