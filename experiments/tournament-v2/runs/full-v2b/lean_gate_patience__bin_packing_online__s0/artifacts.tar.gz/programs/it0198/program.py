# EVOLVE-BLOCK-START
"""Best-fit ranking with an online-histogram residue-matching bonus.

The dominant term is classic best-fit (smallest positive leftover wins),
because for Weibull-shaped sizes with mean ~40 it reliably packs bins tightly.
A secondary term rewards leftovers whose exact value matches the size of a
frequent past item, since such a residue can be filled precisely later rather
than wasting capacity -- a standard "residue usefulness" idea in bin packing.
"""
import numpy as np

# Running histogram over item sizes 1..100.
_COUNTS = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Score each candidate bin; highest score chosen (ties to first bin).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (capacity 100), in bin order.
    """
    global _TOTAL

    # Update online item-size statistics.
    _COUNTS[item] += 1.0
    _TOTAL += 1.0

    b = np.asarray(bins, dtype=np.float64)
    leftover = b - float(item)  # remaining capacity after placement

    total = _TOTAL if _TOTAL > 0 else 1.0

    # --- Dominant term: best-fit (prefer the smallest leftover) ---
    tightness = -leftover / 100.0

    # --- Residue-match bonus: does a frequent item size exactly fill the leftover? ---
    # Probability mass of items of size == leftover (rounded), normalized.
    idx = np.clip(np.rint(leftover), 0, 100).astype(np.int64)
    match = _COUNTS[idx] / total

    # --- Exact-fit bonus (leftover zero) ---
    exact = (leftover == 0.0).astype(np.float64)

    score = tightness + 0.35 * match + 0.25 * exact
    return score
# EVOLVE-BLOCK-END
