# EVOLVE-BLOCK-START
"""Best-fit core with adaptive anti-new-bin bias driven by online pack statistics."""
import numpy as np

_STATE = {"n": 0, "sum": 0.0, "sumsq": 0.0}


def priority(item, bins):
    bins = np.asarray(bins)

    st = _STATE
    st["n"] += 1
    st["sum"] += item
    st["sumsq"] += item * item
    n = st["n"]
    mean = st["sum"] / n
    var = max(st["sumsq"] / n - mean * mean, 0.0)
    std = var ** 0.5

    leftover = bins - item  # remaining capacity after placing the item

    # Best fit: prefer the tightest fit (smallest leftover).
    score = -leftover.astype(np.float64)

    # Penalize residuals that are small but nonzero: typically wasted space.
    # Scale the dead-zone by the observed spread of item sizes.
    threshold = min(mean, 35.0)
    dead = (leftover > 0) & (leftover < threshold)
    score -= np.where(dead, (threshold - leftover) * 0.15, 0.0)

    # Adaptive anti-new-bin bias: only open a fresh bin when even the best
    # existing fit leaves a large residual (i.e., a poor packing).
    is_new = bins >= 100
    best_existing_leftover = np.min(np.where(is_new, np.inf, leftover)) if np.any(~is_new) else 0.0
    if is_new.any():
        if np.any(~is_new):
            bias = 8.0 * (1.0 - min(best_existing_leftover / 50.0, 1.0))
        else:
            bias = 0.0
        score -= np.where(is_new, bias, 0.0)

    return score


def _reset():
    _STATE["n"] = 0
    _STATE["sum"] = 0.0
    _STATE["sumsq"] = 0.0
# EVOLVE-BLOCK-END
