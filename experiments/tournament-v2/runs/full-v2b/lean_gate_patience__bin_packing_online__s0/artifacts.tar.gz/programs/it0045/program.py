# EVOLVE-BLOCK-START
"""Reserve-for-later best fit: tight fits, anti-new-bin bias, gap penalty from stats."""
import numpy as np


_STATE = {"mn": 100.0, "n": 0}


def priority(item, bins):
    # Update empirical minimum item size (smooth)
    s = _STATE
    s["n"] += 1
    m = s["mn"]
    if item < m or s["n"] <= 1:
        s["mn"] = float(item)
        m = s["mn"]

    leftover = bins - item          # remaining capacity after placing (>=0)
    # Tight fits get higher score (negative leftover), stronger than plain best fit
    score = -leftover.astype(np.float64)

    # Mild anti-new-bin bias: full bins are unused (leftover == 100 - item)
    full_mask = (bins == 100)
    score[full_mask] += 1.5 * m     # discourage opening new bins

    # Penalize awkward small gaps below the smallest typical item
    small_gap = (leftover > 0) & (leftover < m)
    score[small_gap] -= 0.5 * m

    return score
# EVOLVE-BLOCK-END
