# EVOLVE-BLOCK-START
"""Best-Fit plus a small exact-fit bonus using an online size estimate.

score = -(leftover) - NEW_BIN_PENALTY * (bins == capacity)
        + EXACT_BONUS * (leftover is a plausible future item size)

The plausible-size check uses a running estimate of the smallest item seen
so far; leaving a residue in [min_seen, 2*min_seen] is treated as "fillable".
"""
import numpy as np

_CAP = 100
_NEW_BIN_PENALTY = 50.0
_EXACT_BONUS = 1.5

_state = {"min_item": 100}


def priority(item, bins):
    if item < _state["min_item"]:
        _state["min_item"] = item
    m = _state["min_item"]

    bins = np.asarray(bins)
    leftover = bins - item
    score = -leftover.astype(np.float64)
    score[bins >= _CAP] -= _NEW_BIN_PENALTY

    fillable = (leftover >= m) & (leftover <= 2 * m)
    score[fillable] += _EXACT_BONUS
    return score
# EVOLVE-BLOCK-END

