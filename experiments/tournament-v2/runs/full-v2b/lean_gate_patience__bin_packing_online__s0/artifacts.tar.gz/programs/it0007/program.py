# EVOLVE-BLOCK-START
"""
Best-fit with a learned penalty for unusable residual capacity.

We place each item into the bin where it fits most tightly, but we subtract a
small penalty proportional to the probability that the post-placement residual
capacity will be wasted (i.e. too small to accept typical future items).  The
empirical item-size distribution is learned online from the arriving items.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0
        self._pen = None
        self._pen_count = -1.0

    def add(self, size):
        self.hist[size] += 1.0
        self.count += 1.0
        self._pen = None  # invalidate

    def penalty_table(self):
        """
        For each residual capacity r (0..100), return a penalty in [0,1]
        equal to the probability that r cannot hold a future item, i.e.
        P(size > r).  Small residuals that cannot fit common items get a
        high (bad) penalty.
        """
        if self._pen is not None and self._pen_count == self.count:
            return self._pen

        if self.count < 5.0:
            # assume uniform sizes 1..100: P(size > r) = (100-r)/100
            cdf = np.arange(101, dtype=np.float64) / 100.0
        else:
            p = self.hist / self.count
            cdf = np.cumsum(p)

        pen = 1.0 - cdf  # P(size > r)
        pen[0] = 1.0
        self._pen = pen
        self._pen_count = self.count
        return pen


_STATS = _Stats()

# weight of the wasted-residual penalty relative to the tightness term
_PEN_W = 8.0


def priority(item, bins):
    """Rank bins: tightest fit, with a penalty for unusable residual."""
    _STATS.add(int(item))
    pen = _STATS.penalty_table()

    residual = bins - item  # >= 0 guaranteed by harness

    # Tightest fit dominates; break near-ties toward residuals more likely to
    # remain useful for future items.
    score = -residual.astype(np.float64) - _PEN_W * pen[residual]
    return score
# EVOLVE-BLOCK-END
