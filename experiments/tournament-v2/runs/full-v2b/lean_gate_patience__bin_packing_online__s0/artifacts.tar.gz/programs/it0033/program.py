# EVOLVE-BLOCK-START
"""Best fit with adaptive close-out reward.

Ranking is still dominated by tightest fit (smallest leftover).  On top of
that we add:
  - a strong reward when the item exactly fills a bin (leftover == 0),
  - a moderate reward when the leftover equals a size that has been observed
    reasonably often among past items (i.e. the residual is "consumable"
    by a likely future item), rather than an odd size nobody ever sends,
  - a mild reward for reusing an already-open bin (avoid needless new bins).

The frequency weights are estimated online from the items seen so far, so the
rule adapts without brittle absolute thresholds.
"""
import numpy as np


_state = {"n": 0, "count": None}


def priority(item, bins):
    _state["n"] += 1

    # maintain an online histogram of item sizes seen so far
    count = _state["count"]
    if count is None:
        count = np.zeros(101, dtype=np.float64)
        _state["count"] = count
    if 1 <= item <= 100:
        count[item] += 1.0

    total = _state["n"]
    freq = count / total  # empirical estimate of P(size == s)

    bins = np.asarray(bins)
    leftover = bins - item  # >= 0 for all bins shown

    score = -leftover.astype(np.float64)

    # strong reward for perfectly closing a bin
    score += 8.0 * (leftover == 0)

    # moderate reward when the residual is a commonly seen item size:
    # such bins remain fillable by likely future items.
    lo = leftover.astype(np.int64)
    valid = (lo >= 1) & (lo <= 100)
    weight = np.zeros_like(leftover, dtype=np.float64)
    weight[valid] = freq[lo[valid]]
    score += 4.0 * weight

    # mild reward for reusing an already-open bin (avoid needless new bins)
    score += 0.5 * (bins < 100)

    return score
# EVOLVE-BLOCK-END
