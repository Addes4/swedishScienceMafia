# EVOLVE-BLOCK-START
"""Sum-of-squares style ranker: convex potential favors consolidating items
into bins with the least resulting free space squared."""
import numpy as np


def priority(item, bins):
    """Score each candidate bin; highest wins (ties -> first).

    item: integer size 1..100.
    bins: numpy int64 remaining capacities of bins the item fits in, in bin order.
    """
    b = bins.astype(np.float64)
    used_before = 100.0 - b
    used_after = used_before + item

    # Change in sum of squared used capacities (lower is better -> negate).
    # delta = used_after^2 - used_before^2 = 2*used_before*item + item^2
    # Minimizing delta <=> minimizing used_before <=> maximizing leftover fit.
    # Add a small term rewarding tight fit explicitly for stability.
    score = -used_after * used_after + used_before * used_before

    # Tiebreak: prefer smaller resulting leftover (best fit) slightly.
    leftover = b - item
    score -= 1e-3 * leftover

    return score
# EVOLVE-BLOCK-END
