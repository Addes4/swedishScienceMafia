# EVOLVE-BLOCK-START
"""Best fit with convex waste and exact-close reward.

Base: tightest fit (smallest leftover).  We reshape the cost of a residual
so that near-zero residuals (perfect closes / very tight fits) are strongly
favoured, while moderately large residuals are only mildly penalized, using
a size-adaptive convex transform.  A bounded exact-fill bonus rewards
closing a bin, and a mild reuse bonus avoids opening new bins needlessly.
"""
import numpy as np


_state = {"n": 0}


def priority(item, bins):
    _state["n"] += 1

    bins = np.asarray(bins)
    leftover = (bins - item).astype(np.float64)  # >= 0

    # Normalize residual by item size to adapt ranking scale.
    scale = item if item > 0 else 1.0
    r = leftover / scale

    # Convex, size-adaptive waste: sharp near 0, gentle for large leftovers.
    score = -(r ** 1.5 + 0.25 * r)

    # Bounded exact-fill reward.
    score += 4.0 * (leftover == 0.0)

    # Mild reuse bonus for already-open bins.
    score += 0.5 * (bins < 100)

    return score
# EVOLVE-BLOCK-END
