# EVOLVE-BLOCK-START
"""Best-fit with reuse, plus residue shaping.

Primary rule: never open a new bin if any used bin can hold the item.
Among used bins, strict best-fit (smallest residual after placement) is best,
but we add a tiny bonus for exact fills (residual 0) so bins close cleanly.
"""
import numpy as np

_count = 0
_mean = 40.0


def _update_stats(item):
    global _count, _mean
    _count += 1
    lr = 1.0 / _count if _count < 50 else 0.02
    _mean = (1.0 - lr) * _mean + lr * item


def priority(item, bins):
    """Return a priority per bin; highest wins."""
    _update_stats(item)

    bins = bins.astype(np.int64)
    residual = bins - item  # >=0 for fitting bins, <0 otherwise
    fits = residual >= 0

    # Used bins have remaining capacity < 100.
    used = bins < 100

    # Base: strongly prefer used bins over empty ones.
    score = used.astype(np.float64) * 1000.0

    # Among used bins, best-fit: prefer smallest residual -> larger score.
    # residual in [0, 100]; convert to a descending score.
    rf = residual.astype(np.float64)
    # Invalid bins (don't fit) get pushed far down.
    score += np.where(fits, 100.0 - rf, -1000.0)

    # Exact-fill bonus: closing a bin to exactly 0 is very valuable.
    score += np.where(fits & (residual == 0), 50.0, 0.0)

    # Empty bins: mild preference for the first empty bin (stable order).
    # Already handled by used-preference; give empties a tiny gradient so
    # ties (all residual 100) resolve to the first bin.
    empties = (bins >= 100)
    score += np.where(empties, -rf * 0.001, 0.0)

    return score
# EVOLVE-BLOCK-END

