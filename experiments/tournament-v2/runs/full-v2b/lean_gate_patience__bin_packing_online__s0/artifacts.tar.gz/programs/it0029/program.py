# EVOLVE-BLOCK-START
"""Reserve-for-later best fit.

Scores bins by fit tightness, but:
 - mildly prefers non-empty bins (remaining < 100) to avoid opening new bins,
 - penalizes leaving a leftover gap that is too small to hold typical items,
   based on empirical statistics of arriving items.
"""
import numpy as np


# --- module-level state (persists across calls) ---
_state = {
    "n": 0,
    "min_seen": 101,
}


def _update_stats(item):
    st = _state
    st["n"] += 1
    if item < st["min_seen"]:
        st["min_seen"] = item


def priority(item, bins):
    _update_stats(item)

    bins = np.asarray(bins)
    leftover = bins - item  # >= 0 for all bins shown (item fits)

    # base: tightness -> smaller leftover is better (negative leftover)
    score = -leftover.astype(np.float64)

    # mild bonus for using an existing (non-empty) bin instead of a fresh one
    nonempty = bins < 100
    score += 0.5 * nonempty

    # penalize awkward small leftovers that won't hold a typical next item
    min_seen = _state["min_seen"]
    # items are integers; a leftover below the smallest item seen so far is "dead" space
    threshold = max(1, min_seen)
    awkward = (leftover > 0) & (leftover < threshold)
    score -= 2.0 * awkward

    return score
# EVOLVE-BLOCK-END
