# EVOLVE-BLOCK-START
"""Best-fit with empirical residual reusability (learned small-item scale)."""
import numpy as np

_STATE = {
    "n": 0,
    "sum": 0.0,
}

_TIGHT = 1e6  # strict dominance for tightness


def _update_state(item):
    _STATE["n"] += 1
    _STATE["sum"] += item


def priority(item, bins):
    _update_state(item)

    bins = np.asarray(bins, dtype=np.int64)
    n = _STATE["n"]
    mean_item = (_STATE["sum"] / n) if n > 0 else 40.0

    # Learned reference for a "small but common" future item.
    # Use a low fraction of the mean as a smooth proxy for the typical small item.
    small = max(1.0, mean_item * 0.35)

    remainder = bins - item  # >= 0 by contract
    rem_f = remainder.astype(np.float64)

    # Primary: tightest fit (smallest residual).
    score = -_TIGHT * rem_f

    # Secondary (tie-break only): reward residuals that can still hold a small item.
    usable = np.minimum(1.0, rem_f / small)
    score += 1.0 * usable

    # Reward exact fill (perfect packing) and discourage dead slivers (0 < rem < 1).
    score += np.where(remainder == 0, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
