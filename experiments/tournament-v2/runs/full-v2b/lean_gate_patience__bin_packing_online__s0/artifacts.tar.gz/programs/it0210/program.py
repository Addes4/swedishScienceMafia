# EVOLVE-BLOCK-START
"""Histogram-sharpened best-fit.

The dominant, reliable signal for this distribution is best-fit tightness.  We keep
that dominant (scale = large) and only break ties among nearly-equal leftovers by
rewarding a residue that exactly equals a frequently-seen future item size (so a
later item can plug the gap).  This is a lightweight online approximation of the
benefit of keeping "matchable" leftovers.
"""
import numpy as np

# Online histogram of item sizes (integer 1..100).
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0

# Cached probability mass per item size; rebuilt lazily.
_prob = None
_last_tot = -1.0


def _build():
    global _prob, _last_tot
    if _total <= 0:
        _prob = np.zeros(101, dtype=np.float64)
        _last_tot = _total
        return
    _prob = _hist / _total
    _last_tot = _total


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    global _total
    if 1 <= item <= 100:
        _hist[item] += 1.0
        _total += 1.0

    if _prob is None or _total != _last_tot:
        _build()

    diff = (bins - item).astype(np.float64)  # leftover after placement (>=0)

    # Dominant tightness signal: strongly prefer the smallest leftover.
    tight = -diff

    # Tie-breaker: residue that matches a common future item size is valuable.
    r_idx = np.clip(diff, 0, 100).astype(np.int64)
    match = _prob[r_idx]
    # Exact-fit bonus and small non-empty bonus.
    exact = (diff == 0).astype(np.float64)
    nonempty = (bins < 100).astype(np.float64)

    return tight + 0.5 * match + 0.05 * exact + 0.01 * nonempty
# EVOLVE-BLOCK-END
