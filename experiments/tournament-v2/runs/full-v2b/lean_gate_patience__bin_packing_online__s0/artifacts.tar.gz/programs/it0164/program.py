# EVOLVE-BLOCK-START
"""Best-fit plus prior-informed reuse potential of the post-placement leftover.

The two prior experiments that used a single-item survival term all plateaued
around 0.96, so instead of rewarding whether *some* item fits, we reward whether
the leftover is a *tight target*: either it can be exactly filled by one typical
item, or by a pair of typical items (self-convolution of the size pmf).  Small
leftovers are still preferred (classic best fit), with exact fits dominant.
"""
import numpy as np

_sizes = np.arange(0, 101, dtype=np.float64)


def _build_prior():
    k = 2.0
    scale = 45.0
    pdf = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        x = s / scale
        pdf[s] = (k / scale) * (x ** (k - 1.0)) * np.exp(-(x ** k))
    total = pdf.sum()
    if total <= 0:
        pdf = np.ones(101, dtype=np.float64)
        total = pdf.sum()
    pdf = pdf / total
    return pdf


_prior_pdf = _build_prior()

# Self-convolution: mass of sums of two items, over 0..200.  Normalize.
_pair_conv = np.convolve(_prior_pdf, _prior_pdf)
_pair_conv = _pair_conv / _pair_conv.sum()

# Precompute per-leftover reuse scores (leftover in 0..100).
_lv = np.arange(0, 101, dtype=np.int64)
_single = _prior_pdf[_lv]                       # P(item == leftover)
_pair = _pair_conv[_lv]                          # P(sum of two items == leftover)
# Smooth the pair mass a little so near-targets also count.
_pair_smooth = 0.5 * _pair + 0.5 * np.concatenate([_pair[1:], [0.0]])
_reuse = 20.0 * _single + 6.0 * _pair_smooth


def priority(item, bins):
    """Rank bins: strong exact-fit bonus, best-fit tightness, and reuse potential."""
    leftover = np.asarray(bins, dtype=np.float64) - float(item)
    idx = np.clip(leftover.astype(np.int64), 0, 100)

    # Primary: best fit (small leftover).
    score = -leftover

    # Prior-informed reuse potential of the resulting residue.
    score += _reuse[idx]

    # Exact fit: dominant bonus.
    score += (leftover == 0).astype(np.float64) * 40.0

    # Small preference for non-empty bins (avoid opening a fresh bin).
    nonempty = leftover < (100.0 - 1e-9)
    score += nonempty.astype(np.float64) * 0.3

    return score
# EVOLVE-BLOCK-END
