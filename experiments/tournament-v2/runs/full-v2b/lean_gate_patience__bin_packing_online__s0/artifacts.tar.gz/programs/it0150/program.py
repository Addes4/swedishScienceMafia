# EVOLVE-BLOCK-START
"""Value-of-residue online bin choice.

For each bin we form the leftover after placing the item. Tightness (smaller leftover) is
rewarded, but we add a bonus proportional to the empirical usefulness of that leftover:
the probability, estimated online from the histogram of items seen so far, that a future
item could still fit into the remaining space. Exact fits get an additional bonus. This
keeps the strength of best-fit while discouraging residues that are too small to be reused.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)   # counts of item sizes seen so far
_N = 0.0                                  # number of items seen so far
_ALPHA = 25.0                             # weight for residue usefulness
_PERFECT = 60.0                           # bonus for an exact (zero-leftover) fit


def priority(item, bins):
    """Return a score for every bin; item goes to the highest score (first on ties)."""
    global _N

    leftover = bins - item  # numpy int64 array, >= 0 for every bin shown

    # Empirical CDF of past item sizes, evaluated at each leftover (online estimate).
    if _N > 0.0:
        cdf = np.cumsum(_HIST) / _N
    else:
        cdf = np.linspace(0.0, 1.0, 101)

    idx = np.clip(leftover, 0, 100).astype(np.int64)
    usefulness = cdf[idx]

    # Base: tightness (negative leftover => smaller is better). Add usefulness bonus.
    score = -leftover.astype(np.float64) + _ALPHA * usefulness
    score[leftover == 0] += _PERFECT

    # Update online statistics with the item just observed (not used for this decision).
    _HIST[item] += 1.0
    _N += 1.0

    return score
# EVOLVE-BLOCK-END
