# EVOLVE-BLOCK-START
"""A residue-hazard based bin-choice rule.

Idea: instead of pure best fit, we score each candidate bin by how *useful*
its post-placement residual is likely to be. Bins whose residual would be
small (too small to hold a typical future item) are penalized, while bins
whose residual stays comfortably large are preferred; tighter fits get a
mild bonus. A reuse bonus discourages opening fresh bins.
"""
import numpy as np

# Online statistics of arriving items (per-process; the harness calls us fresh
# each instance, but state persists across calls within an instance).
_count = 0
_mean = 40.0
_small_frac = 0.15  # fraction of items that are "small" (<= ~0.25 * mean)


def _update_stats(item):
    global _count, _mean, _small_frac
    _count += 1
    # Exponential-ish online mean.
    lr = 1.0 / _count if _count < 50 else 0.02
    old_mean = _mean
    _mean = (1.0 - lr) * _mean + lr * item
    # Track fraction of small items relative to running mean.
    thresh = max(5.0, 0.3 * old_mean)
    is_small = 1.0 if item <= thresh else 0.0
    _small_frac = (1.0 - lr) * _small_frac + lr * is_small


def priority(item, bins):
    """Return a priority per bin; highest wins."""
    _update_stats(item)

    mean = _mean if _mean > 1.0 else 40.0
    # "Typical useful item" size: a bit below the mean, weighted by small fraction.
    typical = mean * (0.6 + 0.4 * (1.0 - _small_frac))
    if typical < 3.0:
        typical = 3.0

    residual = bins - item  # remaining capacity of each bin after placement

    # Hazard: penalize residuals that are too small to be useful (< typical),
    # but only mildly for moderate residuals so we don't stall.
    too_small = np.clip(typical - residual.astype(np.float64), 0.0, None)

    # Tightness bonus: prefer the tightest fit (smallest residual), scaled.
    tight = -residual.astype(np.float64) * 0.05

    # Reuse bonus: strongly prefer non-empty bins (residual < 100 means in use).
    in_use = (bins < 100).astype(np.float64) * 30.0

    # Empty bin has residual exactly 100; small extra penalty to reduce openings.
    is_empty = (bins >= 100).astype(np.float64)
    open_pen = is_empty * 8.0

    score = in_use + tight - too_small * 3.0 - open_pen
    return score
# EVOLVE-BLOCK-END
