# EVOLVE-BLOCK-START
"""Best-fit with online residual-matchability bonus.

Primary signal: smallest leftover (best fit).
Bonus: if the post-placement leftover is a value that appears often as an
item size (online histogram), the bin is preferred because it is likely to be
exactly refilled by a single future item, reducing wasted scraps.
"""
import numpy as np

_cnt = np.zeros(101, dtype=np.float64)   # histogram of seen item sizes
_n = 0
_sum = 0.0


def _update(item):
    global _n, _sum
    _cnt[item] += 1.0
    _n += 1
    _sum += item


def priority(item, bins):
    """Score bins (higher is better); tie -> first bin."""
    _update(item)

    leftover = (bins - item).astype(np.float64)

    # Matchability of the leftover: how often that size has appeared.
    li = np.clip(leftover.astype(np.int64), 0, 100)
    freq = _cnt[li]
    # Normalized matchability in [0,1].
    match = freq / (_n if _n else 1.0)

    # Main term: best fit (small leftover rewarded).
    score = -leftover

    # Bonus for leftovers that are common future item sizes (likely exact refill).
    score += 30.0 * match

    # Penalize scraps too small to ever be filled (below smallest seen item).
    small = 1.0
    seen_idx = np.nonzero(_cnt)[0]
    if seen_idx.size:
        small = float(seen_idx[0])
    scrap = np.maximum(0.0, small - leftover)
    scrap = np.where(leftover > 0.0, scrap, 0.0)
    score -= 1.5 * scrap

    # Prefer non-empty bins (avoid opening new ones) unless new bin is a great fit.
    is_new = (bins == 100) & (item < 100)
    score -= is_new.astype(np.float64) * 0.5

    return score
# EVOLVE-BLOCK-END
