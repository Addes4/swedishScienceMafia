# EVOLVE-BLOCK-START
"""Distribution-aware best fit.

Rank each candidate bin by a weighted combination of:
  - tightness of fit (small leftover is good),
  - a strong bonus when the leftover is a value that appears in the
    empirical item-size distribution (i.e. likely to be exactly reused),
  - a reuse bonus so fresh bins are only opened when worthwhile.
"""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _total
    rem = bins.astype(np.float64)
    leftover = rem - item

    # update empirical histogram of item sizes (online, no future info)
    _hist[item] += 1.0
    _total += 1.0

    # probability mass of each exact size seen so far (smoothed)
    prob = (_hist + 1.0) / (_total + 100.0)

    # reward leftovers that correspond to a likely exact future item size
    lo_int = np.clip(leftover, 0, 100).astype(np.int64)
    exact_likelihood = prob[lo_int]

    # primary: tight fit (smaller leftover preferred)
    score = -leftover * 1.0

    # strongly reward leftovers that are themselves plausible item sizes
    score += exact_likelihood * 30.0

    # perfect fit
    score += (leftover == 0.0) * 15.0

    # reuse bonus: don't open new bins unless necessary
    used = rem < 100.0
    score += used * 5.0

    return score
# EVOLVE-BLOCK-END
