import math
import itertools
import time
import random
from collections import defaultdict

def _make_progression(dims, gens, shifts=None):
    if shifts is None:
        shifts = [0] * len(dims)
    A = []
    ranges = [range(d) for d in dims]
    for indices in itertools.product(*ranges):
        val = 0
        for i, idx in enumerate(indices):
            val += idx * gens[i]
        A.append(val + sum(shifts[i] * (dims[i]//2) for i in range(len(dims))))
    unique = list(set(A))
    return unique

def _score_raw(A):
    A_set = set(A)
    if len(A_set) < 2:
        return -1e9
    diffs = {x - y for x in A_set for y in A_set}
    sums = {x + y for x in A_set for y in A_set}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(A_set)) / 100

def _score(A):
    return _score_raw(A)

def _tune_dims_gens(max_size=4000, max_val=1e15):
    best = None
    best_score = -1
    # try 2D and 3D progressions
    for d in [2, 3]:
        if d == 2:
            candidates = []
            for n1 in range(2, 60):
                for n2 in range(2, 60):
                    if n1 * n2 <= max_size and n1 * n2 >= 10:
                        # generators should be growing and not too symmetric
                        # Try g1 = 1, g2 = m where m > n1
                        for m in [n1 + 1, 2*n1 - 1, 3*n1 + 1]:
                            g1 = 1
                            g2 = m
                            if max(g2 * (n2-1), g1*(n1-1) + g2*(n2-1)) > max_val:
                                continue
                            candidates.append(([n1, n2], [g1, g2]))
            # random search over more generators
            for _ in range(200):
                n1 = random.randint(2, 55)
                n2 = random.randint(2, 55)
                if n1 * n2 > max_size or n1 * n2 < 10:
                    continue
                g1 = random.randint(1, 10)
                g2 = random.randint(g1 * n1 + 1, g1 * n1 * 10)
                if max(g2 * (n2-1), g1*(n1-1) + g2*(n2-1)) > max_val:
                    continue
                candidates.append(([n1, n2], [g1, g2]))
        else:  # d == 3
            candidates = []
            for n1 in range(2, 21):
                for n2 in range(2, 21):
                    for n3 in range(2, 21):
                        if n1 * n2 * n3 <= max_size and n1 * n2 * n3 >= 10:
                            g1 = 1
                            g2 = n1 + 1
                            g3 = n1 * n2 + 1
                            if g3 * (n3-1) > max_val:
                                continue
                            candidates.append(([n1, n2, n3], [g1, g2, g3]))
            # random
            for _ in range(200):
                n1 = random.randint(2, 15)
                n2 = random.randint(2, 15)
                n3 = random.randint(2, 15)
                if n1 * n2 * n3 > max_size or n1 * n2 * n3 < 10:
                    continue
                g1 = random.randint(1, 5)
                g2 = random.randint(g1 * n1 + 1, g1 * n1 * 6)
                g3 = random.randint(g2 * n2 + 1, g2 * n2 * 6)
                if g3 * (n3-1) > max_val:
                    continue
                candidates.append(([n1, n2, n3], [g1, g2, g3]))
        for dims, gens in candidates:
            A = _make_progression(dims, gens)
            if len(A) < 2:
                continue
            s = _score(A)
            if s > best_score:
                best_score = s
                best = A[:]
    return best, best_score

def _random_improve(A_init, max_size, max_val, deadline):
    best = list(A_init)
    best_score = _score(best)
    cur = best[:]
    # local search: add/remove elements, small perturbations
    while time.time() < deadline:
        cand = cur[:]
        if random.random() < 0.7:
            if len(cand) < max_size and random.random() < 0.4:
                # add a small integer near existing
                base = random.choice(cand)
                cand.append(base + random.randint(-5, 5))
            elif len(cand) > 5 and random.random() < 0.3:
                idx = random.randrange(len(cand))
                cand[idx] += random.randint(-3, 3)
            else:
                # replace
                idx = random.randrange(len(cand))
                cand[idx] += random.randint(-10, 10)
        else:
            # more drastic: small random set generation based on progression pattern
            if random.random() < 0.5:
                dims = [random.randint(2, 10) for _ in range(random.choice([2,3]))]
                gens = [1]
                for i in range(1, len(dims)):
                    gens.append(gens[-1] * dims[i-1] + random.randint(1, 5))
                A_small = _make_progression(dims, gens)
                cand = cand[:] + random.sample(A_small, min(len(A_small), 5))
            else:
                cand = cand[:len(cand)//2]
        # ensure distinct and within bounds
        cand = [x for x in cand if abs(x) <= max_val]
        if len(set(cand)) < 2:
            cand = cur[:]
        s = _score(cand)
        if s > best_score:
            best = cand[:]
            best_score = s
            cur = cand[:]
        elif s > _score(cur) or random.random() < 0.1:
            cur = cand[:]
        else:
            # revert occasionally
            if random.random() < 0.05:
                cur = best[:]
    return best

def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    deadline = time.time() + 115  # some margin
    # start with known good constructions
    best, best_score = _tune_dims_gens(max_size=4000, max_val=1e15)
    if best is None:
        best = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]
    # try some specific patterns known for high diff/sum ratio: Sidon sets, etc.
    # generalized arithmetic progressions with carefully chosen generators
    for n1, n2 in [(30, 30), (40, 40), (31, 31), (35, 35), (45, 45), (50, 50)]:
        if n1 * n2 <= 4000:
            A = _make_progression([n1, n2], [1, n1 + 1])
            s = _score(A)
            if s > best_score:
                best = A
                best_score = s
        # try with bigger step
        A = _make_progression([n1, n2], [1, 2*n1 + 1])
        s = _score(A)
        if s > best_score:
            best = A
            best_score = s
    for n1, n2, n3 in [(10,10,10), (12,12,12), (8,9,10), (9,10,11), (7,8,9)]:
        if n1*n2*n3 <= 4000:
            A = _make_progression([n1,n2,n3], [1, n1+1, n1*n2+1])
            s = _score(A)
            if s > best_score:
                best = A
                best_score = s
            A = _make_progression([n1,n2,n3], [1, 2*n1+1, 2*n1*n2+1])
            s = _score(A)
            if s > best_score:
                best = A
                best_score = s
    # also try arithmetic progression (special case) with different steps
    for n in range(100, min(4000, 2000)):
        step = random.randint(1, 100)
        start = 0
        A = [start + i * step for i in range(n)]
        s = _score(A)
        if s > best_score:
            best = A
            best_score = s
    # refine with local search
    best = _random_improve(best, 4000, 1e15, deadline)
    # final sort
    return sorted(set(best))

if __name__ == "__main__":
    A = solve()
    print(f"len: {len(A)}, score: {_score(A):.5f}")
