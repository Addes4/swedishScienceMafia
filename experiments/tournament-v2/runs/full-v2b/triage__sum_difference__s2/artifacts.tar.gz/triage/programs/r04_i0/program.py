import math
import time

def solve():
    """
    Constructs A using floor(M*(a + b*sqrt(2))) construction.
    This creates controlled collisions in sumset while difference set spreads more.
    """
    
    def compute_score(A):
        n = len(A)
        if n < 2:
            return 0.0
        A_sorted = sorted(list(set(A)))
        sums = set()
        diffs = set()
        
        for i in range(len(A_sorted)):
            for j in range(len(A_sorted)):
                sums.add(A_sorted[i] + A_sorted[j])
                diffs.add(A_sorted[i] - A_sorted[j])
                if len(sums) > 500000 or len(diffs) > 500000:
                    break
            if len(sums) > 500000:
                break
        
        log_diff = math.log(max(len(diffs), 1))
        log_sum = math.log(max(len(sums), 1))
        bonus = (1 - 1.0 / max(n, 1)) / 100
        return log_diff / log_sum + bonus
    
    best_score = 0
    best_set = []
    best_params = None
    
    time_limit = 110.0
    start_time = time.time()
    
    # Test various M values with different N
    M_values = [1000, 2500, 5000, 10000, 20000, 40000, 80000, 160000]
    N_values = [15, 20, 25, 30, 40, 50, 60, 75]
    
    for M in M_values:
        for N in N_values:
            if time.time() - start_time > time_limit:
                break
            
            A = set()
            sqrt2 = math.sqrt(2)
            for a in range(-N, N + 1):
                for b in range(-N, N + 1):
                    val = int((a + b * sqrt2) * M)
                    if abs(val) <= 1e15 and len(A) < 4000:
                        A.add(val)
            
            if len(A) < 100:
                continue
                
            score = compute_score(A)
            if score > best_score:
                best_score = score
                best_set = sorted(list(A))
                best_params = (M, N)
            
            if time.time() - start_time > time_limit - 1:
                break
    
    # Try power-of-2 based construction as alternative
    if time.time() - start_time < time_limit - 5:
        for n_bits in range(4, 14):
            for base in [2, 3, 5, 7]:
                if time.time() - start_time > time_limit:
                    break
                A = set()
                for i in range(n_bits * n_bits // 2):
                    val = base ** i
                    if abs(val) <= 1e15:
                        A.add(val)
                        A.add(val * base)
                if len(A) >= 50:
                    score = compute_score(A)
                    if score > best_score:
                        best_score = score
                        best_set = sorted(list(A))
    
    return best_set if best_set else [0, 1]

if __name__ == "__main__":
    result = solve()
    print(f"Size: {len(result)}, Score: {compute_score(result):.6f}")
