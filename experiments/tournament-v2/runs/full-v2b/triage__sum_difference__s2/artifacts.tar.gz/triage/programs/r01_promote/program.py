import math
import itertools
import random

def solve():
    """
    Find a finite set A of integers maximizing log|A-A| / log|A+A|.
    Uses structured constructions based on signed-digit representations
    and greedy optimization to boost the ratio.
    """
    
    def score(A):
        """Compute the objective for a list/set of integers."""
        a_set = set(A)
        n = len(a_set)
        if n < 2:
            return 0.0
        # Compute differences and sums efficiently
        diffs = set()
        sums = set()
        a_list = list(a_set)
        # Use sorted list for small optimization, but not necessary for n~4000
        # We'll do double loops; for n up to 4000, O(n^2) ~ 16M operations, okay
        for i in range(n):
            ai = a_list[i]
            for j in range(i, n):
                aj = a_list[j]
                diffs.add(ai - aj)
                diffs.add(aj - ai)
                sums.add(ai + aj)
        # diffs has all differences, size = |A-A|
        # sums has all sums, size = |A+A|
        if len(sums) == 0:
            return 0.0
        # Bonus: (1 - 1/n) / 100
        base = math.log(len(diffs)) / math.log(len(sums))
        return base + (1.0 - 1.0/n) / 100.0

    best_overall = []
    best_overall_score = 0.0

    # -----------------------------------------
    # Construction 1: Signed-digit numbers with base 3, bounded length, and digit-sum constraints
    # This naturally yields many differences via carries and constrained sums.
    # We'll generate all integers of the form sum_{i=0}^{L-1} d_i * 3^i with d_i in {-1,0,1}
    # but filter to keep set size ~1500-4000 and enforce some pattern to limit sums.
    
    def generate_signed_ternary(length, digit_bound, max_sum_digits=None):
        """
        Generate numbers using base 3 with digits in [-digit_bound, digit_bound].
        If max_sum_digits is given, only keep those with sum of absolute digit values <= max_sum_digits.
        """
        A = set()
        # Use iterative product over positions
        positions = list(range(length))
        # We'll do a recursive builder to avoid huge memory
        def rec(pos, current_val, abs_digit_sum):
            if pos == length:
                if current_val != 0:  # exclude zero? maybe keep zero for more differences
                    A.add(current_val)
                return
            # try all digits
            p3 = 3 ** pos
            for d in range(-digit_bound, digit_bound + 1):
                new_val = current_val + d * p3
                new_sum = abs_digit_sum + abs(d)
                if max_sum_digits is not None and new_sum > max_sum_digits:
                    continue
                rec(pos + 1, new_val, new_sum)
        rec(0, 0, 0)
        return A

    # Try various parameters for signed ternary
    for L in [10, 11, 12, 13, 14]:
        for max_sum in [L//2, L//2 + 1, L-2, L-1]:
            A_gen = generate_signed_ternary(L, 1, max_sum)
            if 100 <= len(A_gen) <= 4000:
                cur_score = score(list(A_gen))
                if cur_score > best_overall_score:
                    best_overall_score = cur_score
                    best_overall = sorted(list(A_gen))

    # -----------------------------------------
    # Construction 2: Generalized signed-digit with base 2 or 3 and constraints on digit occurrences
    # Use base 2 with digits {-1,0,1} yields more differences because subtraction often involves
    # borrowing across many digits, creating many distinct values.
    
    def generate_signed_binary(length, non_zero_limit=None):
        """
        Generate numbers with digits in {-1,0,1} but base 2.
        This is like balanced binary. If non_zero_limit is given, restrict max number of non-zero digits.
        """
        A = set()
        def rec(pos, current_val, non_zero_count):
            if pos == length:
                if current_val != 0:
                    A.add(current_val)
                return
            p2 = 2 ** pos
            for d in [-1, 0, 1]:
                new_val = current_val + d * p2
                new_count = non_zero_count + (1 if d != 0 else 0)
                if non_zero_limit is not None and new_count > non_zero_limit:
                    continue
                rec(pos + 1, new_val, new_count)
        rec(0, 0, 0)
        return A

    for L in range(12, 18):
        for nz_limit in [L//3, L//2, 2*L//3, L-3, L-1]:
            A_gen = generate_signed_binary(L, nz_limit)
            if 100 <= len(A_gen) <= 4000:
                cur_score = score(list(A_gen))
                if cur_score > best_overall_score:
                    best_overall_score = cur_score
                    best_overall = sorted(list(A_gen))

    # -----------------------------------------
    # Construction 3: Nested arithmetic progressions on geometric scales
    # e.g., A = { a * 2^i + b * 3^j } with bounded i,j and a,b in small ranges
    # This can create many differences but limited sums due to alignment.
    
    def generate_geometric_product():
        best_local = []
        best_local_score = 0
        # Use bases (2,3) and small coefficients
        for max_i in range(4, 8):
            for max_j in range(4, 8):
                A = set()
                for i in range(max_i):
                    for j in range(max_j):
                        for a in range(-1, 2):
                            for b in range(-1, 2):
                                val = a * (2**i) + b * (3**j)
                                if val != 0 and abs(val) <= 1e15:
                                    A.add(val)
                if 100 <= len(A) <= 4000:
                    cur = score(list(A))
                    if cur > best_local_score:
                        best_local_score = cur
                        best_local = sorted(A)
        for max_i in range(3, 6):
            for max_j in range(3, 6):
                for max_k in range(3, 5):
                    A = set()
                    for i in range(max_i):
                        for j in range(max_j):
                            for k in range(max_k):
                                for a, b, c in itertools.product([-1,0,1], repeat=3):
                                    val = a * (2**i) + b * (3**j) + c * (5**k)
                                    if val != 0 and abs(val) <= 1e15:
                                        A.add(val)
                    if 100 <= len(A) <= 4000:
                        cur = score(list(A))
                        if cur > best_local_score:
                            best_local_score = cur
                            best_local = sorted(A)
        return best_local, best_local_score

    geo_best, geo_score = generate_geometric_product()
    if geo_score > best_overall_score:
        best_overall_score = geo_score
        best_overall = geo_best

    # -----------------------------------------
    # Construction 4: Spaced power-of-two chains with small shifts
    # A = union of {2^k + c : c in small set} for k in range
    # The differences include large gaps, sums collide more.
    for n in [10, 12, 14, 16, 18]:
        for shift_range in [range(-2, 3), range(-1, 2)]:
            A = set()
            for k in range(1, n+1):
                base = 2 ** k
                for d in shift_range:
                    val = base + d
                    if abs(val) <= 1e15 and val != 0:
                        A.add(val)
            if 100 <= len(A) <= 4000:
                cur = score(list(A))
                if cur > best_overall_score:
                    best_overall_score = cur
                    best_overall = sorted(A)

    # -----------------------------------------
    # Local optimization: take current best and try small perturbations
    # (Greedy add/remove elements that improve the score)
    if best_overall:
        A_set = set(best_overall)
        best_score_local = best_overall_score
        # Try removing elements that might reduce sum-set size more than diff-set size
        # Or adding elements that increase diff-set without increasing sum-set too much.
        # We'll do a simple hill-climbing for a limited time.
        attempt_time = time.time()
        timeout = 100  # seconds for optimization
        improved = True
        iteration = 0
        while improved and (time.time() - attempt_time) < timeout:
            improved = False
            A_list = list(A_set)
            random.shuffle(A_list)
            # Try to add a new element derived from existing ones that might boost diffs
            # For example, pick two elements a,b and try a+b, a-b, 2a-b, etc.
            for _ in range(min(200, len(A_list))):
                if len(A_set) >= 4000:
                    break
                a = random.choice(A_list)
                b = random.choice(A_list)
                candidates = [a+b, a-b, b-a, 2*a - b, 2*b - a, a + 2*b, 2*a + b]
                for cand in candidates:
                    if cand != 0 and abs(cand) <= 1e15 and cand not in A_set:
                        new_set = A_set | {cand}
                        new_score = score(list(new_set))
                        if new_score > best_score_local:
                            best_score_local = new_score
                            A_set.add(cand)
                            improved = True
                            break
                if improved:
                    break
            # Try removal
            if not improved:
                # try removing an element that might shrink sums more than diffs
                for elem in list(A_set):
                    if len(A_set) <= 100:
                        break
                    new_set = A_set - {elem}
                    new_score = score(list(new_set))
                    if new_score > best_score_local:
                        best_score_local = new_score
                        A_set.remove(elem)
                        improved = True
                        break
            iteration += 1
            if iteration % 10 == 0:
                # occasionally re-evaluate full set score to avoid drift
                pass
        best_overall = sorted(list(A_set))
        best_overall_score = best_score_local

    # Ensure final set is within constraints: distinct, <=4000, abs <= 1e15
    final = sorted(list(set(best_overall)))
    if len(final) > 4000:
        final = final[:4000]
    if len(final) < 2:
        # fallback to a known good set
        final = [2**i for i in range(1, 61)]  # powers of two
    return final[:4000]  # ensure limit
