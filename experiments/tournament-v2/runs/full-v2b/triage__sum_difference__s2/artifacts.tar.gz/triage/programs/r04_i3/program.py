# EVOLVE-BLOCK-START
"""
A = union of arithmetic progressions with common difference d, lengths
forming a Sidon set, offsets well-separated.

Within each progression we get L_i difference values (k*d) and ~2L_i sum
values. If offsets are huge relative to within-progression ranges, the
cross-progression sums land in disjoint "buckets" (one bucket per pair
{s_i+s_j}), so |A+A| ~ sum_i 2L_i + O(n^2) instead of O(n^2 * L^2).
Meanwhile differences from distinct offset pairs s_i - s_j give many
values, so |A-A| explodes.
"""
import math
import time


def solve():
    t0 = time.time()

    def score(A):
        S = set(A)
        if len(S) < 2:
            return 0.0
        diffs = set()
        sums = set()
        for x in S:
            for y in S:
                diffs.add(x - y)
                sums.add(x + y)
        if not sums:
            return 0.0
        return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(S)) / 100

    def build(offsets, lengths, d):
        A = []
        for s, L in zip(offsets, lengths):
            for k in range(L):
                A.append(s + k * d)
        return A

    candidates = []

    # --- Family 1: equal-length progressions, offsets separated by L+1
    for n_prog in [6, 8, 10, 12, 15, 20, 25, 30, 40]:
        for Lprog in [3, 4, 5, 6, 8, 10, 12]:
            if n_prog * Lprog > 4000:
                continue
            d = 1
            step = Lprog * d + 1
            offsets = [i * step for i in range(n_prog)]
            A = build(offsets, [Lprog] * n_prog, d)
            if len(set(A)) == len(A) and max(abs(v) for v in A) <= 10**15:
                candidates.append(A)

    # --- Family 2: geometric (Sidon) lengths
    for n_prog in [8, 10, 12, 14, 16]:
        lengths = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768][:n_prog]
        d = 1
        maxL = max(lengths)
        step = maxL * d + 1
        offsets = [i * step for i in range(n_prog)]
        A = build(offsets, lengths, d)
        A = [a for a in A if abs(a) <= 10**15]
        if len(A) <= 4000 and len(set(A)) == len(A) and len(A) >= 2:
            candidates.append(A)

    # --- Family 3: fewer, longer progressions
    for n_prog in [3, 4, 5, 6]:
        for Lprog in [50, 80, 100, 150, 200, 300, 400]:
            if n_prog * Lprog > 4000:
                continue
            d = 1
            step = Lprog * d + 1
            offsets = [i * step for i in range(n_prog)]
            A = build(offsets, [Lprog] * n_prog, d)
            if len(set(A)) == len(A) and max(abs(v) for v in A) <= 10**15:
                candidates.append(A)

    # --- Family 4: greedy Sidon lengths, mixed sizes
    for n_prog in [10, 12, 14, 16, 18, 20]:
        sid = []
        sums_seen = set()
        L = 1
        while len(sid) < n_prog and L < 100000:
            ok = True
            # check new sums a_i + L and 2L don't collide
            for s in sid:
                if s + L in sums_seen:
                    ok = False
                    break
            if ok and 2 * L in sums_seen:
                ok = False
            if ok:
                for s in sid:
                    sums_seen.add(s + L)
                sums_seen.add(2 * L)
                sid.append(L)
            L += 1
        if len(sid) < n_prog:
            continue
        d = 1
        maxL = max(sid)
        step = maxL * d + 1
        offsets = [i * step for i in range(n_prog)]
        A = build(offsets, sid, d)
        A = [a for a in A if abs(a) <= 10**15]
        if len(A) <= 4000 and len(set(A)) == len(A) and len(A) >= 2:
            candidates.append(A)

    # --- Family 5: scaled versions of best candidates (multiply by big d)
    for n_prog in [8, 10, 12]:
        for Lprog in [4, 6, 8]:
            if n_prog * Lprog > 4000:
                continue
            for d in [1, 2, 3]:
                step = Lprog * d + 1
                offsets = [i * step for i in range(n_prog)]
                A = build(offsets, [Lprog] * n_prog, d)
                if len(set(A)) == len(A) and max(abs(v) for v in A) <= 10**15:
                    candidates.append(A)

    # Evaluate; dedupe candidates first
    seen_sigs = set()
    unique = []
    for A in candidates:
        sig = (len(A), tuple(A[:10]), tuple(A[-10:]))
        if sig in seen_sigs:
            continue
        seen_sigs.add(sig)
        unique.append(A)

    # Prioritize smaller candidates for speed, but evaluate all if time allows.
    unique.sort(key=len)
    best = None
    best_sc = -1.0
    for A in unique:
        # Skip huge ones if running low on time
        if len(A) > 600 and time.time() - t0 > 90:
            continue
        sc = score(A)
        if sc > best_sc:
            best_sc = sc
            best = A
        if time.time() - t0 > 110:
            break

    if best is None:
        best = [0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023, 2047, 4095]
    return best
# EVOLVE-BLOCK-END
