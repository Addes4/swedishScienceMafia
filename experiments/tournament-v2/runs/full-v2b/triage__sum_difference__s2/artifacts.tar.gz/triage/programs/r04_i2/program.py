# EVOLVE-BLOCK-START
"""
Construction: Möbius-transformed images of a structured base set over the rationals,
plus additive-combinatorial constructions calibrated to the score.

The key idea: A - A is large because we include many translates/dilates of a base
set (which are Möbius images of small arithmetic progressions). A + A is controlled
because the elements live in a low-dimensional module with many coincidences.

We combine several well-known inequalities-tightening constructions:
1. Sets of the form { m*2^i + k : small ranges }, giving |A+A| ~ product of ranges
   while |A-A| is boosted by the spread of the 2^i factors.
2. Generalised "geometric + arithmetic" mixtures.
3. Small maximisation / randomised local search around the best candidate.
"""
import math
import random
import time


def _score(A):
    a_set = set(A)
    n = len(a_set)
    if n < 2:
        return 0.0, 0, 0
    L = sorted(a_set)
    diffs = set()
    for i, x in enumerate(L):
        for y in L:
            diffs.add(x - y)
    sums = set()
    for x in L:
        for y in L:
            sums.add(x + y)
    ds = len(diffs)
    ss = len(sums)
    if ss == 0:
        return 0.0, ds, ss
    return math.log(ds) / math.log(ss) + (1 - 1 / n) / 100, ds, ss


def _score_fast(A):
    a_set = set(A)
    n = len(a_set)
    if n < 2:
        return 0.0
    L = sorted(a_set)
    diffs = set()
    for x in L:
        for y in L:
            diffs.add(x - y)
    sums = set()
    for x in L:
        for y in L:
            sums.add(x + y)
    ds = len(diffs)
    ss = len(sums)
    if ss == 0:
        return 0.0
    return math.log(ds) / math.log(ss) + (1 - 1 / n) / 100


def solve():
    random.seed(12345)
    t0 = time.time()
    LIMIT = 1e15
    best = []
    best_score = -1.0

    def consider(A):
        nonlocal best, best_score
        A = sorted(set(int(v) for v in A))
        if len(A) < 2 or len(A) > 4000:
            return
        if any(abs(v) > LIMIT for v in A):
            return
        # quick estimate to skip obvious losers
        try:
            s = _score_fast(A)
        except Exception:
            return
        if s > best_score:
            best_score = s
            best = A

    # ---------------------------------------------------------------
    # Construction A: geometric-progression base with additive clusters
    # A = { 2^i * m + j : i in I, m in M, j in J }
    # Difference set is large (varied 2^i, m, j); sum set collapses
    # because sums stay in the same shape with doubled coefficients.
    # ---------------------------------------------------------------
    for base in [2, 3, 4, 5]:
        for ni in [5, 6, 7, 8, 9, 10, 11, 12]:
            for nm in [1, 2, 3, 4, 5]:
                for nj in [1, 2, 3, 4, 5]:
                    if ni * nm * nj > 4000:
                        continue
                    if base ** (ni - 1) > LIMIT:
                        continue
                    A = set()
                    ok = True
                    for i in range(ni):
                        bi = base ** i
                        for m in range(1, nm + 1):
                            for j in range(nj):
                                v = bi * m + j
                                if abs(v) > LIMIT:
                                    ok = False
                                    break
                                A.add(v)
                            if not ok:
                                break
                        if not ok:
                            break
                    if not ok or len(A) < 2:
                        continue
                    if len(A) > 2200:  # score is expensive
                        continue
                    consider(A)

    # ---------------------------------------------------------------
    # Construction B: Möbius transforms of a base set (real arithmetic
    # analogue).  f(x) = (a x + b)/(c x + d).  We instead use integer
    # affine fractional combinations that stay integral.
    # ---------------------------------------------------------------
    # Base arithmetic progression B = {0, 1, ..., L-1}
    for L in [8, 12, 16, 20, 24, 30, 40, 50]:
        base_set = list(range(L))
        A = set()
        for a in [1, 2, 3]:
            for b in [0, 1, -1, 2, -2, 3, -3]:
                for c in [1, 2, 3, 4]:
                    for d in [1, 2, 3, 4, 5]:
                        # image of x -> (a*x+b)/(c*x+d): only keep integer values
                        for x in base_set:
                            den = c * x + d
                            if den == 0:
                                continue
                            num = a * x + b
                            if num % den == 0:
                                v = num // den
                                if abs(v) <= LIMIT:
                                    A.add(v)
        if 2 <= len(A) <= 800:
            consider(A)

    # ---------------------------------------------------------------
    # Construction C: sums of two scaled geometric progressions
    # A = { p*2^i + q*3^j : small ranges } -> many differences via the
    # cross terms, sums collide as 2*(symmetric value).
    # ---------------------------------------------------------------
    for ni in [4, 5, 6, 7, 8]:
        for nj in [4, 5, 6, 7, 8]:
            if 2 ** ni > LIMIT or 3 ** nj > LIMIT:
                continue
            A = set()
            for i in range(ni):
                for j in range(nj):
                    for sp in [1, -1]:
                        v = sp * 2 ** i + 3 ** j
                        if abs(v) <= LIMIT:
                            A.add(v)
            if 2 <= len(A) <= 1500:
                consider(A)

    # ---------------------------------------------------------------
    # Construction D: known strong families — {2^i} ∪ {2^i + 1} style
    # tuned to control A+A while keeping A-A large.
    # ---------------------------------------------------------------
    for n in [10, 12, 14, 16, 18, 20]:
        if 2 ** n > LIMIT:
            continue
        A = set()
        for i in range(n):
            A.add(2 ** i)
            A.add(2 ** i + 1)
            A.add(2 ** i - 1)
        consider(A)
        A = set()
        for i in range(n):
            for k in range(1, 4):
                v = 2 ** i * k
                if abs(v) <= LIMIT:
                    A.add(v)
        consider(A)

    # ---------------------------------------------------------------
    # Construction E: { a * 2^i + b * 3^j + c } with small c range to
    # force sum collisions.
    # ---------------------------------------------------------------
    for ni in [4, 5, 6]:
        for nj in [4, 5, 6]:
            for nc in [2, 3]:
                if 2 ** ni * 3 ** nj * nc > 3000:
                    continue
                A = set()
                for a in [1, 2]:
                    for i in range(ni):
                        for b in [1, 2]:
                            for j in range(nj):
                                for c in range(nc):
                                    v = a * 2 ** i + b * 3 ** j + c
                                    if abs(v) <= LIMIT:
                                        A.add(v)
                if 2 <= len(A) <= 1200:
                    consider(A)

    # ---------------------------------------------------------------
    # Local search around the best set so far.
    # ---------------------------------------------------------------
    if not best:
        best = [0, 1, 3]

    cur = list(best)
    cur_score = best_score
    # Cap size for search (score computation is O(n^2))
    if len(cur) > 260:
        cur = sorted(random.sample(cur, 260))
        cur_score = _score_fast(cur)

    budget = 110.0
    while time.time() - t0 < budget:
        trial = list(cur)
        # random operation: replace an element with a random nearby integer
        op = random.random()
        if op < 0.5 and len(trial) > 2:
            idx = random.randrange(len(trial))
            base = trial[idx]
            mag = max(1, abs(base) // 8)
            delta = random.randint(-mag, mag)
            new_val = base + delta
            if new_val in trial or abs(new_val) > LIMIT:
                continue
            trial[idx] = new_val
        elif op < 0.8:
            # add a new element
            if len(trial) >= 260:
                continue
            ref = random.choice(trial)
            new_val = ref + random.choice([1, -1, 2, -2, 3, -3, ref // 2, -ref // 2])
            if new_val in trial or abs(new_val) > LIMIT:
                continue
            trial.append(new_val)
        else:
            # remove an element
            if len(trial) <= 2:
                continue
            idx = random.randrange(len(trial))
            del trial[idx]

        trial = sorted(set(trial))
        if len(trial) < 2 or len(trial) > 260:
            continue
        s = _score_fast(trial)
        if s > cur_score:
            cur_score = s
            cur = trial
            consider(cur)

    return best
# EVOLVE-BLOCK-END
