"""
Construction: Union of geometric progressions with irrational-like ratios.
Using floor(q^i) values produces many differences but limited sums due to 
overlap patterns near integers.
"""
import math
import random

def score_set(A):
    """Compute the objective function value for set A."""
    if len(A) < 2:
        return 0.0
    A = set(A)
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) 

def generate_base_sequence(alpha, left, right):
    """Generate floor(alpha^i) for i in left..right (floor is 1 to ensure distinctness)."""
    seq = set()
    for i in range(left, right + 1):
        val = alpha ** i
        if val > 1e15:
            break
        if val > 0:
            seq.add(int(val))
    return seq

def generate_interpolating_set(seq, max_gap=50, fill_pattern='sparse'):
    """Generate sequence with controlled density."""
    if fill_pattern == 'dense':
        return list(seq)
    result = sorted(list(seq))
    # Filter to keep reasonable spacing
    filtered = [result[0]]
    for x in result[1:]:
        if x - filtered[-1] <= max_gap:
            filtered.append(x)
    return filtered

def generate_sequence_from_ratios(ratios, log_range, fill_threshold=None):
    """
    Generate set from union of geometric series with given ratios.
    For each ratio r and range [start, end], collect floor(r^i).
    """
    A = set()
    for r in ratios:
        s = generate_base_sequence(r, 5, 1000)
        A = A | s
    return list(A)

def generate_hierarchy_set(depth, start_exp, base_values=None):
    """
    Generate Cantor-like geometric hierarchy: 
    A = ∪_i {floor(b^k * v) : k in [0, depth]} for various b in different ranges
    """
    A = set()
    if base_values is None:
        base_values = [1.0001, 1.0002, 1.0003, 1.001, 1.002]
    for b in base_values:
        for k in range(start_exp, start_exp + depth):
            val = b ** k
            if val > 1e15 or val < 0:
                continue
            A.add(int(val))
    return list(A)

def mutate_set(A, mutation_count=100, mutation_range=50):
    """
    Try small mutations (shift by offsets in arithmetic progression).
    This preserves structure while exploring nearby configurations.
    """
    best_A = list(A)
    best_score = score_set(best_A)
    
    A = list(A)
    A.sort()
    
    for mut in range(mutation_count):
        mod = random.randint(1, 10000) * 2 + 1
        for value in range(-mutation_range, mutation_range + 1):
            modified = {(x + value) % mod for x in A}
            if len(modified) >= len(A) * 100 // 200:
                trial = list(modified)
                trial.sort()
                trial = [x for x in trial if abs(x) <= 1e15]
                if len(trial) >= max(10, len(A) * 0.9):
                    s = set(trial)
                    sc = score_set(s)
                    if sc > best_score:
                        best_score = sc
                        best_A = trial
    
    return best_A

def generate_optimal_set():
    """
    Main generation strategy using geometric unions with tailored ratios.
    From Behrend-style constructions adapted to integer constraints.
    """
    best_set = []
    best_score = -1
    
    def try_params(ratios_variants):
        for ratios in ratios_variants:
            for start_exp in range(8, 30, 2):
                for depth in range(3, 12):
                    for combine_mode in ['union', 'hybrid']:
                        try:
                            cnt_counts = (start_exp, depth)
                            A = generate_sequence_from_ratios(ratios, cnt_counts, fill_threshold=None)
                            if len(A) < 2 or len(A) > 3000:
                                continue
                            s = set(A)
                            if all(abs(x) <= 1e15 for x in s):
                                sc = score_set(s)
                                if sc > best_score:
                                    best_score = sc
                                    best_set = list(s)
                        except:
                            pass
        return best_set, best_score
    
    # Variant 1: Union of linear and slightly super-linear growth
    ratios_variants = [
        [1.0001, 1.0003, 1.001, 1.002],
        [1.0002, 1.0005, 1.0015, 1.0025],
        [1.00005, 1.00015, 1.00025, 1.0004, 1.0006],
        [1.0001, 1.0002, 1.0003, 1.0005, 1.0008, 1.0012, 1.002],
        [1.00015, 1.00025, 1.0004, 1.0006, 1.0009, 1.0015, 1.0025],
        [1.0002, 1.0004, 1.0007, 1.0010, 1.0015, 1.0020, 1.0030],
        [1.00005, 1.0001, 1.00015, 1.0002, 1.00025, 1.0003, 1.00035, 1.0004, 1.0005, 1.0006],
    ]
    
    candidates = []
    for ratios in ratios_variants:
        for exp_start in [10, 12, 15, 20, 25]:
            for dep in [5, 8, 10, 12, 15]:
                A = generate_sequence_from_ratios(ratios, (exp_start, exp_start + dep))
                try:
                    s = set(A)
                    if len(s) > 100 and max(100, len(A) // 2) <= len(s) <= 3500:
                        candidates.append((score_set(s), list(s)))
                except:
                    pass
        # Memory optimization: keep top candidates
        candidates.sort(reverse=True, key=lambda p: p[0])
        candidates = candidates[:50]
    
    # Also test hybrid sets
    for ratios in ratios_variants:
        for exp_start in range(12, 30, 3):
            for dep in range(4, 15, 2):
                try:
                    A = generate_sequence_from_ratios(ratios, (exp_start, dep))
                    s = set(A)
                    if len(s) > 80 and len(s) <= 3500:
                        c = score_set(s)
                        if c > best_score:
                            best_score = c
                            best_set = list(s)
                except:
                    pass
    
    # Variations using constrained powers-of-2 style hybridization
    for base, exp_range in [(2, 15), (3, 12), (20, 20), (50, 15)]:
        A = set()
        for i in range(exp_range):
            val = base ** i
            if val > 1e15:
                break
            A.addvaluation(val)
            for offset in range(-2, 3):
                shifted = val + offset
                if shifted > 0 and shifted <= 1e15 and shifted not in A:
                    A.add(shifted)
        if len(A) >= 100:
            s = set(A)
            sc = score_set(s)
            if sc > best_score:
                best_score = sc
                best_set = list(s)
    
    # Mutations and local opt search
    if len(best_set) >= 50:
        best_set = mutate_set(best_set, mutation_count=30, mutation_range=10)
        s = set(best_set)
        sc = score_set(s)
        if sc > best_score:
            best_score = sc
    
    for i in range(20):
        scrambled = [x + random.randint(-5, 5) for x in best_set]
        scrambled = sorted(list(set(scrambled)))
        if len(scrambled) >= len(best_set) * 0.95 and all(abs(v) <= 1e15 for v in scrambled):
            s = set(scrambled)
            if score_set(s) > best_score:
                best_score = score_set(s)
                best_set = list(s)
    
    best_set = sorted(best_set)
    return best_set

def solve():
    """
    Return the best set found that maximizes the log difference/sum ratio.
    """
    import time
    start = time.time()
    
    # Run with timeout safeguard
    def with_timeout(max_time=115):
        nonlocal best_set, best_score
        best_set = []
        best_score = -1
        
        results = generate_optimal_set()
        if results:
            best_score = results[0]
            best_set = results[1]
        
        if len(best_set) > 4000:
            best_set = sorted(best_set)[:4000]
            best_set = [x for x in best_set if abs(x) <= 1e15]
        
        return best_set
    
    result = with_timeout()
    
    # Ensure quality by reranking
    if result:
        filtered = sorted(result, key=abs)[:min(len(result), 3500)]
        score = score_set(filtered)
        if score < best_score and len(filtered) >= 0.5 * len(result):
            #fallback to original
            pass
    
    # Final cleanup
    final = sorted(set(result))
    A = [x for x in final if abs(x) <= 1e15 and x > 0]
    
    if len(A) < 10:
        # Try base sequence directly
        for base in [1.0001, 1.0002, 1.0003, 1.0004, 1.0005]:
            for start, end in [(5, 100), (8, 150), (10, 200), (12, 250), (15, 300)]:
                A = list(generate_base_sequence(base, start, end))
                if len(A) >= 100:
                    s = set(A)
                    sc = score_set(s)
                    if sc > 1.2:
                        A = sorted(s)
                        break
            if len(A) >= 100:
                break
    
    final_result = sorted(list(set(A[:min(len(A), 4000)])))
    
    # Double-check bounds and distinctness
    final_result = sorted([x for x in final_result if abs(x) <= 1e15])
    
    return final_result

if __name__ == "__main__":
    A = solve()
    print(f"Found set of size {len(A)}")
