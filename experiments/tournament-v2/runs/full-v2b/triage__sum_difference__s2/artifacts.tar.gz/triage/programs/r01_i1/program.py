import math
import random
import time
import itertools

def _score_exact(a):
    """Score for a list of distinct ints."""
    # Deduplicate
    seen = set()
    a_clean = []
    for x in a:
        if x not in seen:
            seen.add(x)
            a_clean.append(x)
    if len(a_clean) < 2:
        return 0.0
    # Compute diffs and sums via sets for efficiency
    diffs = set()
    sums = set()
    # For moderate sizes direct double loop is okay, but we use a fast approach
    for i in range(len(a_clean)):
        xi = a_clean[i]
        for j in range(i, len(a_clean)):
            xj = a_clean[j]
            diffs.add(xi - xj)
            diffs.add(xj - xi)
            sums.add(xi + xj)
            if i != j:
                sums.add(xi + xj)  # already added, just being explicit
    # Actually sums: a+b for all ordered pairs includes i,j and j,i if i!=j, but we want set of all sums.
    # The above double loop only gives combinations with repetition for sums: we need all ordered pairs.
    # Simpler: recompute carefully.
    # Let's do it correctly.
    diffs = {x - y for x in a_clean for y in a_clean}
    sums = {x + y for x in a_clean for y in a_clean}
    if len(diffs) < 2 or len(sums) < 2:
        return 0.0
    main = math.log(len(diffs)) / math.log(len(sums))
    bonus = (1.0 - 1.0 / len(a_clean)) / 100.0
    return main + bonus

def _random_set(size, low, high):
    """Return a sorted list of distinct ints in range [low, high]."""
    if size > high - low + 1:
        size = high - low + 1
    vals = set()
    while len(vals) < size:
        vals.add(random.randint(low, high))
    return sorted(vals)

def solve():
    random.seed(0)  # deterministic but that's fine for competition
    start_time = time.time()
    time_limit = 120  # seconds
    # Parameters
    initial_size = 30
    max_size = 4000  # the problem limit
    # We want a set A of distinct integers, absolute value <= 1e15.
    # We'll start with a moderate-sized set and grow it using simulated annealing moves.
    
    # Initialize with a random set from a small range to encourage small sums/diffs?
    # Actually we want large diff set, small sum set.
    # Known good constructions: arithmetic progressions have small sumset and diffset both about 2n-1.
    # We need something like a set with many differences, i.e., not too much additive structure.
    # Random sets tend to have sumset and diffset both near n^2, so ratio ~1.
    # To maximize log|diff|/log|sum| we want sumset as small as possible while diffset as large as possible.
    # If we take a set with many elements in a small interval, sumset ~ 2n-1, diffset ~ 2n-1, ratio ~1.
    # To increase diffset relative to sumset, we can take sets that are "STROKE" (like geometric progressions?) 
    # Actually, for integers, if we take a set with elements that grow fast (e.g., powers of 2), diffset large (approximately 2n(n-1)/2?), sumset also large.
    # Another idea: take a set that is symmetric around 0? That reduces sumset? If A = -A, sumset contains many zeroes? Not necessarily.
    # Known results: For sets with small sumset, diffset is not too large (Freiman-Ruzsa). But we want opposite.
    # The problem is to maximize diffset and minimize sumset simultaneously. 
    # We can attempt a greedy/SA approach to find a good set within limits.

    # We'll maintain current set as sorted list.
    # Moves:
    # - Add a random integer between -bound and bound, not already present.
    # - Remove a random element.
    # - Shift an element by a small delta (also avoiding collisions).
    # - Swap an element with a new random value.
    # Evaluate after each move and accept based on temperature.
    
    # Start temperature high.
    T_start = 0.05
    T_end = 1e-6
    # Cooling schedule: geometric cooling factor per iteration.
    # We'll run many iterations within time limit.
    
    # Initial set: random selection from range [-1000, 1000], size 50 maybe.
    cur = _random_set(50, -500, 500)
    cur_score = _score_exact(cur)
    best = cur[:]
    best_score = cur_score
    
    # We'll track time and adjust max iterations.
    iteration = 0
    max_iter_per_check = 2000
    # Annealing parameters
    T = T_start
    cooling_rate = 0.99995  # slow cooling
    
    while time.time() - start_time < time_limit - 2:  # reserve 2 seconds
        # Perform a batch of moves
        for _ in range(max_iter_per_check):
            T_current = T * (T_end / T_start) ** (iteration / 5e6)  # approximate, but we'll use explicit exponential decay
            # Actually use T = T_start * (cooling_rate ** iteration)
            T = T_start * (cooling_rate ** iteration)
            if T < T_end:
                T = T_end
            iteration += 1
            
            # Choose a move type
            move = random.choice(['add', 'remove', 'shift', 'replace'])
            if len(cur) >= max_size and move == 'add':
                move = 'remove'  # can't exceed limit
            if len(cur) <= 2 and move == 'remove':
                move = 'add'
            
            new_set = cur[:]
            if move == 'add':
                # Add random integer within a range that depends on current spread
                # To allow exploration, generate candidate from wide range but biased to current span.
                if random.random() < 0.7:
                    # Within current min-max +/- some margin
                    low = min(cur) - 100
                    high = max(cur) + 100
                else:
                    # Wider exploration
                    low = -10**8
                    high = 10**8
                cand_val = random.randint(low, high)
                attempts = 0
                while cand_val in set(new_set) and attempts < 20:
                    cand_val = random.randint(low, high)
                    attempts += 1
                if attempts >= 20:
                    continue
                new_set.append(cand_val)
            elif move == 'remove':
                idx = random.randrange(len(new_set))
                del new_set[idx]
            elif move == 'shift':
                idx = random.randrange(len(new_set))
                delta = random.randint(-3, 3)
                if delta == 0:
                    continue
                cand_val = new_set[idx] + delta
                if cand_val not in set(new_set):
                    new_set[idx] = cand_val
                else:
                    continue
            elif move == 'replace':
                idx = random.randrange(len(new_set))
                if random.random() < 0.7:
                    low = min(new_set) - 100
                    high = max(new_set) + 100
                else:
                    low = -10**8
                    high = 10**8
                cand_val = random.randint(low, high)
                attempts = 0
                while cand_val in set(new_set) and attempts < 20:
                    cand_val = random.randint(low, high)
                    attempts += 1
                if attempts >= 20:
                    continue
                new_set[idx] = cand_val
            
            # Compute score
            new_score = _score_exact(new_set)
            delta = new_score - cur_score
            
            # Metropolis acceptance
            if delta > 0 or (T > 0 and random.random() < math.exp(delta / T)):
                cur = new_set
                cur_score = new_score
                if cur_score > best_score:
                    best = cur[:]
                    best_score = cur_score
            
            # Occasionally restart to escape local optima? Not necessary with SA.
        
        # Check time
        if time.time() - start_time > time_limit - 2:
            break
    
    # Final set should be sorted distinct integers within the allowed bounds.
    # Ensure all values within [-1e15, 1e15]
    final = [x for x in best if abs(x) <= 10**15]
    if len(final) < 2:
        # Fallback to some known good set
        final = [-10, -5, -2, -1, 0, 1, 2, 5, 10]
    # Deduplicate and sort
    final = sorted(set(final))
    return final

if __name__ == "__main__":
    result = solve()
    # Print only the list to stdout? The problem expects just the function.
    # If we run directly we can print score for debugging.
    s = _score_exact(result)
    print("Score:", s, "Length:", len(result))
