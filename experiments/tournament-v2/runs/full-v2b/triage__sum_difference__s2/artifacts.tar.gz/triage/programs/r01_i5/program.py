# EVOLVE-BLOCK-START
"""Brute-force over small moduli then lift to integers by repetition patterns."""
import math
import random
import time
from itertools import combinations


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _analyze_mod(A, m):
    """Return set of differences modulo m and sums modulo m."""
    diffs = {((x - y) % m) for x in A for y in A}
    sums = {((x + y) % m) for x in A for y in A}
    return diffs, sums


def _brute_mod(m, k, deadline, rng):
    """Search for a k-subset of Z_m maximizing |diffs|/|sums| (as counts)."""
    if k > m:
        return None
    best = None
    best_val = -1.0
    # random restarts
    while time.time() < deadline:
        cur = rng.sample(range(m), k)
        cur_set = set(cur)
        d, s = _analyze_mod(cur, m)
        val = len(d) / max(1, len(s))
        # local search: swap elements
        improved = True
        while improved and time.time() < deadline:
            improved = False
            for i in range(k):
                for repl in range(m):
                    if repl in cur_set:
                        continue
                    trial = cur[:]
                    trial[i] = repl
                    dt, st = _analyze_mod(trial, m)
                    v = len(dt) / max(1, len(st))
                    if v > val:
                        val = v
                        cur = trial
                        cur_set = set(trial)
                        old = cur[i]
                        improved = True
                        break
                if improved:
                    break
        if val > best_val:
            best_val = val
            best = (cur[:], best_val)
    return best


def _lift(A, m, n_copies):
    """Lift a set mod m to integers: use residues A with multipliers of m."""
    result = []
    for c in range(n_copies):
        for a in A:
            result.append(a + c * m)
    return result


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 100
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    m = 24
    # try several sizes
    for k in range(6, 16):
        if time.time() >= deadline:
            break
        sub_deadline = min(deadline, time.time() + 5)
        result = _brute_mod(m, k, sub_deadline, rng)
        if result is None:
            continue
        A, val = result
        # try lifts with various shift sizes
        for gap in [m, 2 * m, 3 * m, m * m]:
            for nc in range(1, 8):
                if time.time() >= deadline:
                    break
                cand = _lift(A, gap, nc)
                if len(cand) > 4000:
                    break
                sc = _score(cand)
                if sc > best_score:
                    best_score = sc
                    best = cand[:]

    # final polish: try a few random variants of the best
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        i = rng.randrange(len(cand))
        cand[i] += rng.choice([-1, 1, -2, 2, -3, 3, -m, m])
        sc = _score(cand)
        if sc > best_score:
            best_score = sc
            best = cand[:]
            cur = cand[:]
        elif rng.random() < 0.2:
            cur = best[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
