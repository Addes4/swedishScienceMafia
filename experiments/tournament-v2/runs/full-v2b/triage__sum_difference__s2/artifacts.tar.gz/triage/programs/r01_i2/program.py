import math
import random
import time

def calculate_score(A):
    """Calculate the objective score for set A."""
    A = sorted(list(set(A)))
    n = len(A)
    if n < 2:
        return 0.0
    sums = {x + y for x in A for y in A}
    diffs = {x - y for x in A for y in A}
    if len(sums) <= 1:
        return 0.0
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / n) / 100.0
    return score

def solve():
    random.seed(42)
    deadline = time.time() + 120
    best_A = None
    best_score = 0.0
    
    def compute_geometric_set(n, base, rate):
        """Generate a geometric-like integer set."""
        s = set()
        cur = base
        for _ in range(n):
            s.add(cur)
            cur = int(cur * rate * 0.5 + 1)
            if cur <= 0:
                cur = max(cur, 1)
        return sorted(s)
    
    def compute_score_fast(A):
        A = sorted(list(set(A)))
        n = len(A)
        if n < 5:
            return 0.0
        s = len(A) * len(A) // 2
        d = n * (n - 1) // 2 + n
        return math.log(d) / math.log(s) if s > 1 else 0.0

    # Phase 1: Parameter sweep over geometric sequences
    for n in [15, 20, 25, 30]:
        for base in [100, 1000, 10000]:
            for rate in [2.8, 3.0, 3.5, 4.0, 5.0]:
                A = compute_geometric_set(n, base, rate)
                if not A:
                    continue
                score = calculate_score(A)
                if score > best_score:
                    best_score = score
                    best_A = A[:]
                if time.time() > deadline:
                    break
            if best_A and time.time() > deadline:
                break
        if best_A and time.time() > deadline:
            break

    if best_A is None:
        best_A = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384]

    # Phase 2: Local search - perturb elements to improve score
    best_A = sorted(list(set(best_A)))
    for _ in range(min(5000, int((deadline - time.time()) * 30))):
        if len(best_A) < 5:
            continue
        i = random.randint(1, len(best_A) - 2)
        old = best_A[i]
        delta = random.choice([-1, 1]) * random.choice([10, 100, 500])
        new = old + delta
        if new <= 0 or new in best_A:
            continue
        best_A[i] = new
        new_set = sorted(list(set(best_A)))
        score = calculate_score(new_set)
        if score >= best_score:
            best_score = score
            best_A = new_set
        else:
            best_A[i] = old
        if time.time() > deadline:
            break

    # Final cleanup and constraints
    valid_A = [x for x in best_A if 0 < x <= 1e15]
    valid_A = sorted(list(set(valid_A)))[:4000]
    
    # Optional: try AP-based family for additional candidates
    for start in [1000, 5000]:
        for d in [100, 50, 25]:
            for size in [20, 30, 40]:
                temp_A = [start + i * d for i in range(size)]
                s = calculate_score(temp_A)
                if s > best_score and time.time() < deadline:
                    best_score = s
                    best_A = sorted(temp_A)
    valid_A = [x for x in best_A if 0 < x <= 1e15]
    valid_A = sorted(list(set(valid_A)))[:4000]

    return sorted(list(set(valid_A)))
