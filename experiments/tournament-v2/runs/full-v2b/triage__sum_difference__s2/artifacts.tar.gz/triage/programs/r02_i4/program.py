import math
import random
import sympy as sp

def solve():
    """Return a list of distinct integers A with large difference set and small sum set."""
    
    def score_set(A):
        if len(A) < 2:
            return 0.0
        # Convert to set and compute
        a_set = set(A)
        n = len(a_set)
        
        # Efficient computation using vectorized operations if possible
        # For large sets, we need sampling
        if n <= 2000:
            diffs = set()
            sums = set()
            A_list = list(a_set)
            for i in range(n):
                ai = A_list[i]
                for j in range(i, n):
                    aj = A_list[j]
                    if i == j:
                        diffs.add(0)
                        sums.add(2 * ai)
                    else:
                        diffs.add(ai - aj)
                        diffs.add(aj - ai)
                        sums.add(ai + aj)
            return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/n) / 100
        else:
            # Sample for large sets
            sample_size = min(n, 1500)
            A_list = list(a_set)
            sampled = random.sample(A_list, sample_size)
            diffs = set()
            sums = set()
            for i in range(sample_size):
                ai = sampled[i]
                for j in range(i, sample_size):
                    aj = sampled[j]
                    if i == j:
                        diffs.add(0)
                        sums.add(2 * ai)
                    else:
                        diffs.add(ai - aj)
                        diffs.add(aj - ai)
                        sums.add(ai + aj)
            # Extrapolate? Just use sampled
            return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/n) / 100
    
    # Construction: A = {p * k + (i^2 mod p) : i in range, k in range}
    # This gives many squares mod p which sum to few squares but differences are richer
    random.seed(42)
    best_score = 0.0
    best_set = []
    
    # Try different primes and ranges
    primes = [101, 211, 307, 401, 503, 601, 701, 809, 907, 1009]
    
    for p in primes:
        # Generate quadratic residues mod p
        residues = set()
        for x in range(1, p):
            residues.add((x * x) % p)
        
        # For each residue, we'll create multiple integers by adding multiples of p
        # Choose a base multiplier to keep numbers in range
        base_val = 10**12
        scale = base_val // p
        
        for multiplicities in [1, 2, 3, 4, 5]:
            A = set()
            for res in residues:
                for k in range(multiplicities):
                    val = k * p + res
                    # Scale up
                    val *= scale
                    if abs(val) <= 10**15:
                        A.add(val)
            
            if len(A) >= 10 and len(A) <= 4000:
                score = score_set(list(A))
                if score > best_score:
                    best_score = score
                    best_set = list(A)
    
    # Try different construction: use multiple primes for better ratio
    for prime_size in [100, 150, 200, 250, 300, 350]:
        p = prime_size
        # Find a real prime near this size
        # Use sympy's nextprime
        try:
            p = sp.nextprime(prime_size)
        except:
            # Fallback
            for candidate in range(prime_size, prime_size + 50):
                is_prime = True
                for d in range(2, int(candidate**0.5) + 1):
                    if candidate % d == 0:
                        is_prime = False
                        break
                if is_prime:
                    p = candidate
                    break
        
        residues = set()
        for x in range(1, p):
            residues.add((x * x) % p)
        
        # Add multiple copies with spacing to increase set size while maintaining structure
        n_layers = 12
        spacing = 10**12
        A = set()
        for layer in range(n_layers):
            offset = layer * p * spacing
            for res in residues:
                val = offset + res * spacing
                if abs(val) <= 10**15:
                    A.add(val)
        
        if 500 <= len(A) <= 4000:
            score = score_set(list(A))
            if score > best_score:
                best_score = score
                best_set = list(A)
    
    # Try scaled quadratic residues with larger primes
    for p in [997, 2011, 3001, 4001, 5003, 6007]:
        residues = set()
        for x in range(1, p):
            residues.add((x * x) % p)
        
        # Scale each residue into a large integer
        factor = 10**12 // p
        A = set()
        for res in residues:
            A.add(res * factor)
        
        # Add shifted versions
        shifts = [0, p*factor, 2*p*factor, 3*p*factor]
        for shift in shifts:
            for res in residues:
                val = shift + res * factor
                if 0 < abs(val) <= 10**15:
                    A.add(val)
        
        if len(A) <= 4000:
            score = score_set(list(A))
            if score > best_score:
                best_score = score
                best_set = list(A)
    
    # Fine-tune: try to optimize a found good set
    if len(best_set) > 0:
        best_A = set(best_set)
        best_score = score_set(list(best_A))
        
        # Small mutations
        for iteration in range(1000):
            if random.random() < 0.3 and len(best_A) > 10:
                # Remove random element
                to_remove = random.choice(list(best_A))
                test_set = best_A - {to_remove}
                score = score_set(list(test_set))
                if score > best_score:
                    best_score = score
                    best_A = test_set
            else:
                # Try adding element
                max_val = max(best_A) if len(best_A) > 0 else 10**15
                min_val = min(best_A) if len(best_A) > 0 else -10**15
                
                # Generate candidate based on existing structure
                if len(best_A) > 0:
                    base = random.choice(list(best_A))
                    variation = random.randint(-100, 100) * random.choice([1, 31, 97, 211])
                    candidate = base + variation
                    if abs(candidate) <= 10**15 and candidate not in best_A:
                        test_set = set(list(best_A) + [candidate])
                        if len(test_set) <= 4000:
                            score = score_set(list(test_set))
                            if score > best_score:
                                best_score = score
                                best_A = test_set
        
        best_set = sorted(list(best_A))
    
    return best_set
