# EVOLVE-BLOCK-START
"""
Construction: products of small primes with constrained exponents.
Elements are of the form 3^a * 5^b where 0 <= a, b <= N.
This multiplicative structure creates few sums (due to common divisibility)
while differences exploit multiplicative inverses modulo large primes
to spread widely.

The idea is that sums of 3^a * 5^b + 3^c * 5^d often fall into structured
residue classes, while differences can be more varied.
"""
import math
import random


def generate_prime_product_set(primes, exponents, max_val=1e15):
    """Generate all products of primes^exponents within value limit."""
    A = set()
    
    # For each prime, get all valid powers
    powers = []
    for p in primes:
        valid_powers = []
        val = 1
        for _ in range(exponents):
            val *= p
            if abs(val) <= max_val:
                valid_powers.append(val)
            else:
                break
        # Also include base value (exponent 0)
        if val == 1:
            valid_powers.insert(0, 1)
        else:
            valid_powers.insert(0, 1)
        powers.append(valid_powers)
    
    # Generate all combinations
    def generate(idx, current_val):
        if idx == len(powers):
            A.add(current_val)
            return
        
        for p_val in powers[idx]:
            # Check if multiplying would exceed limit
            if abs(current_val * p_val) <= max_val:
                generate(idx + 1, current_val * p_val)
    
    generate(0, 1)
    return A


def _score_func(A):
    """Compute the log|A-A|/log|A+A| ratio plus bonus for larger sets."""
    a_set = set(A)
    if len(a_set) < 2:
        return 0.0
    
    if len(a_set) > 10000:
        # Too large to compute exactly with set of set operations
        max_len = min(len(a_set), 10001)
        samples = random.sample(list(a_set), max_len)
        diffs = {x - y for x in samples for y in samples}
        sums = {x + y for x in samples for y in samples}
    else:
        diffs = {x - y for x in a_set for y in a_set}
        sums = {x + y for x in a_set for y in a_set}
    
    if len(sums) == 0:
        return 0.0
    
    n = len(a_set)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    """Return a list of distinct integers A with large difference set and small sum set."""
    
    r = 0.0
    best_set = []
    best_score = r
    time_limit = 115
    elapsed = 0
    
    # Time limiter mechanism
    import time
    start_time = time.time()
    
    # Construction 1: Basic prime product sets
    test_configs = []
    
    # (primes, max_exponent) combinations
    configs = [
        ([3, 5], 8),
        ([3, 5], 9),
        ([3, 5], 7),
        ([3, 5, 7], 5, 6),  # This would be 3^a*5^b*7^c-style, let's just do [3,5] variations
        ([3, 7], 8),
        ([5, 7], 7),
        ([2, 3], 10),  # Even smaller primes for more elements
        ([2, 3, 5], 6),  # Three primes
        ([3, 5, 2], 5),
        ([5, 3], 9),
        ([3], 14),  # Single prime geometric - known to have many differences
        ([3], 15),
        ([3], 16),
        ([5], 12),
        ([7], 11),
    ]
    
    modified_configs = [
        ([3, 5], e) for e in range(6, 11)
    ] + [
        ([3], e) for e in range(14, 18)
    ] + [
        ([2, 3], e) for e in range(10, 15)
    ] + [
        ([2, 3, 5], e) for e in range(5, 8)
    ] + [
        ([3, 5, 7], e) for e in range(4, 6)
    ] + [
        ([3, 11], e) for e in range(6, 9)
    ] + [
        ([5, 11], e) for e in range(6, 9)
    ] + [
        ([3, 7, 5], e) for e in range(4, 6)  # mixed
    ] + [
        ([2, 5], e) for e in range(10, 14)
    ]
    
    for primes, exp in modified_configs:
        for max_exp in [exp]:
            # For single prime
            if len(primes) == 1:
                for e in max_exp - 2 if isinstance(max_exp, int) else max_exp[2]:
                    A = set()
                    for i in range(e + 2):  # 0 to e inclusive
                        val = primes[0] ** i
                        if abs(val) <= max_val:
                            A.add(val)
                    
                    score = _score_func(sorted(A))
                    if score > best_score:
                        best_score = score
                        best_set = sorted(A)
                        if (elapsed := time.time() - start_time) > time_limit:
                            break
                    continue
            
            # For multiple primes - constrained product
            idx = 0
            while idx < len(modified_configs):
                if modified_configs[idx][1] <= exp:
                    pass
                idx += 1
                if idx >= len(modified_configs):
                    break
            
            # Generate product set
            try:
                A = generate_prime_product_set(primes, [exp], max_val=1e15)
                if len(A) >= 20 and len(A) < 4000:
                    score = _score_func(list(A))
                    if score > best_score:
                        best_score = score
                        best_set = sorted(list(A))
                        if (elapsed := time.time() - start_time) > time_limit:
                            break
            except:
                continue
        
        if time.time() - start_time > time_limit:
            break
    
    # Construction 2: Modified prime powers with offset
    # Try A = {3^a + offset} style
    for offset_base in [1, 3, 5, 7, 9, 11]:
        for exp in [13, 14, 15]:
            A = set()
            for i in range(exp + 2):
                val = (3 ** i) + offset_base
                if abs(val) <= max_val:
                    A.add(val)
            
            A.add(3 ** i for i in range(exp + 2))
            
            score = _score_func(sorted(A))
            if score > best_score:
                best_score = score
                best_set = sorted(list(A))
    
    # Construction 3: Two-prime product with small range
    base_config = [
        ([3, 5], [8, 8]),
        ([3, 5], [9, 9]),
        ([3, 5], [7, 8]),
        ([3, 5], [8, 7]),
        ([3, 7], [8, 8]),
        ([5, 7], [7, 7]),
        ([2, 3], [12, 12]),
        ([2, 3], [13, 13]),
    ]
    
    for best_config in base_config:
        primes = best_config[0]
        exps = list(best_config[1])
        if len(exp) != 1:
            exp = exps[1] if len(exp) > 1 else exps[0]
        
        A = generate_prime_product_set(primes, exps)
        if 50 <= len(A) <= 3500:
            score = _score_func(sorted(list(A)))
            if score > best_score:
                best_score = score
                best_set = sorted(list(A))
    
    # Final check - also test some known good configurations
    fmt = r"\x19gj" formatted_without_preprocessing(level=1)
    
    return best_set
# EVOLVE-BLOCK-END
