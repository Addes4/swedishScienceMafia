import math
import time

def solve():
    """
    Construct A from values of quadratic forms with many automorphisms.
    Key idea: use numbers of the form x^2 + D*y^2 (or x^2 - D*y^2) up to a bound.
    The sum set has collisions because the form is closed under certain operations,
    while the difference set is larger.
    """
    LIMIT = 10**15
    MAX_SIZE = 4000

    best_score = -1.0
    best_set = []

    def score(A):
        s = set(A)
        n = len(s)
        if n < 2:
            return -1.0
        diffs = set()
        sums = set()
        sl = list(s)
        for x in sl:
            for y in sl:
                diffs.add(x - y)
                sums.add(x + y)
        if not sums:
            return -1.0
        return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/n) / 100

    # Strategy 1: Numbers of the form a^2 + b^2 (sums of two squares)
    # Many such numbers, and adding two sums of two squares tends to yield
    # another sum of two squares (Brahmagupta identity), giving coincidences.
    for bound in [10**7, 10**8]:
        A = set()
        m = int(math.isqrt(bound))
        for a in range(0, m + 1):
            aa = a * a
            if aa > bound:
                break
            for b in range(a, m + 1):
                v = aa + b * b
                if v > bound:
                    break
                A.add(v)
        if 0 < len(A) <= MAX_SIZE:
            sc = score(A)
            if sc > best_score:
                best_score = sc
                best_set = list(A)

    # Strategy 2: Numbers of the form a^2 + D*b^2 for various D, up to a bound
    for D in [1, 2, 3, 5]:
        for bound in [10**8, 10**9]:
            A = set()
            a_max = int(math.isqrt(bound))
            for a in range(0, a_max + 1):
                aa = a * a
                if aa > bound:
                    break
                # b_max such that aa + D*b*b <= bound
                rem = bound - aa
                if rem < 0:
                    continue
                b_max = int(math.isqrt(rem // D))
                for b in range(0, b_max + 1):
                    A.add(aa + D * b * b)
            if 0 < len(A) <= MAX_SIZE:
                sc = score(A)
                if sc > best_score:
                    best_score = sc
                    best_set = list(A)

    # Strategy 3: Numbers of the form a^2 - D*b^2 (indefinite forms)
    # These are more "multiplicative" in nature (norm forms), yielding many
    # additive coincidences.
    for D in [1, 2, 3, 5]:
        for bound in [10**8, 5 * 10**8]:
            A = set()
            a_max = int(math.isqrt(bound)) + 1
            for a in range(0, a_max + 1):
                aa = a * a
                # need aa - D*b*b in (0, bound] or negative range; we use positive magnitudes
                # b_max so that D*b*b < aa + bound, i.e. b roughly up to sqrt((aa+bound)/D)
                b_max = int(math.isqrt((aa + bound) // D)) + 1
                for b in range(0, b_max + 1):
                    v = aa - D * b * b
                    if abs(v) <= bound and v != 0:
                        A.add(v)
                        if len(A) > MAX_SIZE * 4:
                            break
                if len(A) > MAX_SIZE * 4:
                    break
            # Trim to MAX_SIZE by largest magnitude
            if len(A) > MAX_SIZE:
                A = set(sorted(A, key=lambda x: -abs(x))[:MAX_SIZE])
            if 0 < len(A) <= MAX_SIZE:
                sc = score(A)
                if sc > best_score:
                    best_score = sc
                    best_set = list(A)

    # Strategy 4: Norm forms of quadratic fields: a^2 + a*b + b^2 (Eisenstein),
    # a^2 + b^2, etc. These have extra symmetry.
    for form in ['eisenstein', 'gauss', 'd2', 'd3']:
        for bound in [10**8, 5 * 10**8]:
            A = set()
            m = int(math.isqrt(bound)) + 2
            for a in range(-m, m + 1):
                for b in range(-m, m + 1):
                    if form == 'eisenstein':
                        v = a * a + a * b + b * b
                    elif form == 'gauss':
                        v = a * a + b * b
                    elif form == 'd2':
                        v = a * a + 2 * b * b
                    else:
                        v = a * a - 3 * b * b
                    if 0 < abs(v) <= bound:
                        A.add(v)
                if len(A) > MAX_SIZE * 6:
                    break
            if len(A) > MAX_SIZE:
                A = set(sorted(A, key=lambda x: -abs(x))[:MAX_SIZE])
            if 0 < len(A) <= MAX_SIZE:
                sc = score(A)
                if sc > best_score:
                    best_score = sc
                    best_set = list(A)

    # Strategy 5: union structure - take sums of two elements from a small base
    # so that the sum set collapses.
    for base_bound in [10**4, 10**5, 10**6]:
        base = [i * i for i in range(1, int(math.isqrt(base_bound)) + 1)]
        A = set()
        for x in base:
            for y in base:
                v = x + y
                if v <= LIMIT:
                    A.add(v)
                if len(A) > MAX_SIZE * 3:
                    break
            if len(A) > MAX_SIZE * 3:
                break
        if len(A) > MAX_SIZE:
            A = set(sorted(A)[:MAX_SIZE])
        if 0 < len(A) <= MAX_SIZE:
            sc = score(A)
            if sc > best_score:
                best_score = sc
                best_set = list(A)

    if not best_set:
        best_set = [1, 2, 4, 8, 16, 32]

    return sorted(set(best_set))
