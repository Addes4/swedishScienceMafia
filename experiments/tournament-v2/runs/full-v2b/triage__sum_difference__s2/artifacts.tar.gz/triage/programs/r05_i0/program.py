# EVOLVE-BLOCK-START
"""
Construction: Union of short geometric progressions from different bases.
Uses carefully chosen sequences where sums from elements of same progression
cluster, but differences across progressions are diverse and spread out.
This creates |A+A| << |A-A| ratio.
"""
import math
from typing import List

def compute_score(A: List[int]) -> float:
    """Compute evaluation metric for set A."""
    if len(A) < 2:
        return 0.0
    s = set(A)
    sums = {a + b for a in s for b in s}
    diffs = {a - b for a in s for b in s}
    if len(sums) < 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(A)) / 100

def score_set(A: List[int]) -> float:
    """Wrapper for score computation."""
    return compute_score(A)

def construct_geometric_progressions(threshold=1e14) -> List[List[int]]:
    """Generate multiple short geometric progressions from different bases."""
    progressions = []
    
    # Base sequences to try
    bases = [2, 3, 5, 7, 11, 13]
    lengths = [6, 7, 8]
    offsets = [0, 1, 2, 3]
    
    for base in bases:
        for length in lengths:
            prog = []
            for k in range(1, length + 1):
                val = base ** k
                if abs(val) > threshold:
                    break
                progression = [val + offset for offset in offsets]
                # Deduplicate
                for p in progression:
                    prog.append(p)
            if len(prog) >= 5 and len(prog) < 4000:
                progressions.append(prog)
    
    return progressions

def construct_optimized(A_size_target=200):
    """
    Construct set A as union of carefully spaced geometric progressions.
    """
    # Main construction: selected powers from primes + small offset
    elements = []
    max_val = 1e14
    
    # Primary progressions with bases that have good additive/difference properties
    primary_bases = [2, 3, 4, 5, 7, 8, 13, 17]
    
    for base in primary_bases:
        length = min(12, A_size_target // len(primary_bases))
        for k in range(1, length + 1):
            val = base ** k
            if abs(val) <= max_val:
                # Add primary term
                elements.append(val)
                # Small variations for more structure
                for offset in [-1, 1]:
                    val2 = val + offset
                    if val2 not in elements and abs(val2) <= max_val:
                        elements.append(val2)
            else:
                break
    
    # Convert to set and sort
    A = sorted(set(elements))
    
    # Ensure we have enough elements
    while len(A) < 50 and len(elements) < 4000:
        if A:
            last = A[-1]
            next_val = last * 2
            if abs(next_val) <= max_val:
                if next_val not in A:
                    A.append(next_val)
        else:
            break
    
    return A

def construct_sum_differences_optimized():
    """
    Optimized construction for large difference/small sum ratio.
    Uses selected powers from primes with offsets to balance structure.
    """
    elements = []
    max_val = 1e14
    
    # Selected bases for geometric progressions
    bases = [3, 4, 5, 7, 8, 13, 17, 19, 23, 29, 31]
    
    for base in bases:
        # Generate 4-5 terms per base
        for k in range(1, min(5, 12)):
            val = base ** k
            if abs(val) > max_val:
                break
            # Core element
            elements.append(val)
            # Small offsets to create internal structure
            for offset in [-1, 1]:
                val2 = val + offset
                if abs(val2) <= max_val:
                    elements.append(val2)
    
    # Additional powers with larger gaps
    sparse_bases = [6, 9, 10, 12, 15, 20, 25, 30]
    for base in sparse_bases:
        for k in range(2, min(6, 12)):
            val = base ** k
            if abs(val) > max_val:
                break
            if val not in [abs(e) for e in elements] or val != any(abs(e) for e in elements if abs(e) == val):
                elements.append(val)
    
    # Deduplicate and filter to size range
    A = sorted(set(elements))
    A = [x for x in A if abs(x) <= max_val and -max_val <= x <= max_val]
    
    return A

def construct_power_union():
    """
    Union of powers from different bases with controlled offsets.
    """
    elements = set()
    max_val = 1e14
    count = 0
    
    # Phase 1: Powers of small primes with limited exponents
    bases = [2, 3, 5, 7]
    for base in bases:
        for k in range(1, 10):
            val = base ** k
            if abs(val) > max_val:
                break
            elements.add(val)
            # Add small offsets
            for offset in [-3, -2, -1, 1, 2, 3]:
                val2 = val + offset
                if abs(val2) <= max_val:
                    elements.add(val2)
    
    # Phase 2: Powers of composite bases
    comp_bases = [6, 8, 9, 10, 12, 15, 16, 18, 20, 21, 24, 25, 27, 28, 30]
    for base in comp_bases:
        for k in range(1, 8):
            val = base ** k
            if abs(val) > max_val:
                break
            elements.add(val)
            for offset in [-2, 2]:
                val2 = val + offset
                if abs(val2) <= max_val:
                    elements.add(val2)
    
    # Convert to sorted list
    A = sorted(elements)
    A = [x for x in A if -max_val <= x <= max_val]
    
    return A

def refine_set(A: List[int]) -> List[int]:
    """
    Refine set by exploring small mutations for better score.
    """
    if len(A) < 10:
        return A
    
    best_A = A[:]
    best_score = score_set(A)
    
    # Try small-value modifications
    improved = False
    
    for _ in range(20):
        A_new = best_A[:]
        
        # Try replacing one element
        for i in range(len(A_new)):
            original = A_new[i]
            
            # Find nearby non-conflicting value
            for delta in [1, -1, 2, -2, 3, -3]:
                candidate = original + delta
                if -1e14 <= candidate <= 1e14 and candidate not in A_new:
                    A_new[i] = candidate
                    new_score = score_set(A_new)
                    if new_score > best_score:
                        best_score = new_score
                        best_A = A_new[:]
                        improved = True
                    break
        
        if not improved:
            break
    
    return best_A

def construct_final():
    """
    Main construction combining geometric progressions with offsets.
    """
    # Build set from multiple geometric sequences
    elements = []
    limit = 1e14
    
    # Core construction: selected powers
    prime_bases = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31]
    
    for base in prime_bases:
        # Generate powers (4-6 terms each)
        count = min(6, 15)
        for k in range(1, count + 1):
            val = base ** k
            if abs(val) > limit:
                break
            elements.append(val)
            # Add offset variations (keeps sums clustered)
            for offset in [-1, 1, -2, 2]:
                val2 = val + offset
                if abs(val2) <= limit:
                    elements.append(val2)
            if len(elements) >= 300:
                break
        if len(elements) >= 300:
            break
    
    # Additional sparse terms for coverage
    sparse_bases = [6, 8, 9, 10, 14, 15, 16, 20, 25, 27, 32]
    for base in sparse_bases:
        for k in range(1, 5):
            val = base ** k
            if abs(val) > limit:
                break
            elements.append(val)
            for offset in [-1, 1]:
                val2 = val + offset
                if abs(val2) <= limit:
                    elements.append(val2)
    
    # Filter duplicates and sort
    A = sorted(set(elements))
    A = [x for x in A if abs(x) <= limit]
    
    # Remove elements with very large absolute values that create sparse sums
    trimmed_A = [x for x in A if abs(x) <= 1e14]
    
    # Refine
    A = refine_set(trimmed_A)
    
    # Ensure we meet minimum size requirements
    if len(A) < 200:
        A.extend([A[-1] * 2 for _ in range(40)])
        A = sorted(set(A))
    
    return A

def test_construction_names():
    """Helper to test multiple constructions and return best."""
    constructions = [
        construct_geometric_progressions(),
        construct_optimized(),
        construct_sum_differences_optimized(),
        construct_power_union(),
        construct_final(),
    ]
    
    best_set = []
    best_score = 0
    
    for i, s in enumerate(constructions):
        if not s:
            continue
        score = score_set(s)
        print(f"Construction {i+1} (size {len(s)}): score = {score:.6f}")
        if score > best_score:
            best_score = score
            best_set = s[:]
    
    return best_set

# Main solve function
def solve() -> List[int]:
    """
    Return a finite set A maximizing log|A-A|/log|A+A|
    constructed from geometric progressions in different bases.
    """
    global current_time
    current_time = 0
    
    # Start with timeout check
    import time
    start_time = time.time()
    timeout = 120
    
    print("Starting construction...")
    
    # Test multiple construction strategies
    test_set = test_construction_names()
    
    # Final refinement step
    if test_set:
        final_set = refine_set(test_set[:3000])  # Limit size during refinement
    else:
        final_set = construct_final()[:3000]
    
    # Ensure we don't exceed size limits
    final_set = sorted(list(set(final_set)))
    final_set = final_set[:min(4000, len(final_set))]
    
    # Final validation
    final_set = [x for x in final_set if abs(x) <= 1e15]
    
    final_score = score_set(final_set)
    print(f"Final set size: {len(final_set)}, Score: {final_score:.6f}")
    
    return final_set

if __name__ == "__main__":
    result = solve()
# EVOLVE-BLOCK-END
