# EVOLVE-BLOCK-START
"""
Construction: Sparse polynomial evaluation with modular arithmetic mixing.
Evaluates P(x) = sum c_i * x^{e_i} for random x, with various coefficient
and exponent patterns. This creates structured sets with good sum/difference ratio.
"""
import random
from math import log

def score_set(A):
    """Compute the score for a set of integers"""
    A = set(A)
    if len(A) < 2:
        return 0.0
    sums = set(a + b for a in A for b in A if abs(a + b) <= 1e15)
    diffs = set(a - b for a in A for b in A)
    if len(sums) < 2:
        return 0.0
    bonus = (1.0 - 1.0 / len(A)) / 100.0
    return log(len(diffs)) / log(len(sums)) + bonus

def solve():
    """Return a list of distinct integers A with large difference set and small sum set."""
    
    best_score = 0.0
    best_set = []
    
    # Construction 1: Pure powers of 3 (strong baseline)
    for n in range(15, 19):
        A = set()
        for i in range(n):
            val = 3 ** i
            if abs(val) <= 1e15:
                A.add(val)
        if len(A) >= n:
            s = score_set(A)
            if s > best_score:
                best_score = s
                best_set = sorted(A)
    
    # Construction 2: Powers of 3 with small addend spread
    for offset in range(5):
        A = set()
        for i in range(17):
            base_val = 3 ** i
            if abs(base_val) <= 1e15:
                A.add(base_val + offset)
        if len(A) >= 17:
            s = score_set(A)
            if s > best_score:
                best_score = s
                best_set = sorted(A)
    
    # Construction 3: Hybrid geometric with mixed bases
    hybrid_params = [(4, 9), (5, 8), (3, 10), (3, 11), (4, 10)]
    for base1, base2 in hybrid_params:
        A = set()
        power1, power2, max_n = [1, 1, 15]
        while max(power1, power2) * 2 <= 1e15 and len(A) < 200:
            if power1 <= power2 or power1 == power2:
                val = base1 ** power1
            else:
                val = base2 ** power2
            if val % 2 == 1 and val >= 1:
                A.add(val)
            power1 = 1 + power1
            power2 = 1 + power2
        if len(A) >= max_n:
            s = score_set(A)
            if s > best_score:
                best_score = s
                best_set = sorted(A)
    
    # Construction 4: Sparse polynomial evaluation P(x) = sum c_i * x^{e_i}
    poly_configs = [
        ([1, 3], [1, 2]),      # Quadratic
        ([1, 2], [1, 3]),      # Cubic-like growth
        ([7, 5], [2, 4, 6]),   # Sparse higher exponents
        ([3, 11], [1, 2]),     # Large coefficient
        ([5], [1, 3, 9, 27]),  # Very sparse
    ]
    for coeffs, exponents in poly_configs:
        for sample_size in [200, 500]:
            A = set()
            random.seed(42)
            for _ in range(sample_size * 2):
                x = random.randint(1, min(10000, 2**20))
                val = sum(c * (x ** e) for c, e in zip(coeffs, exponents))
                if 0 < abs(val) <= 1e15:
                    A.add(val)
            if len(A) >= 50:
                s = score_set(A)
                if s > best_score:
                    best_score = s
                    best_set = sorted(A)
    
    # Final cleanup
    final_set = sorted(list(set(best_set)))
    return final_set
# EVOLVE-BLOCK-END
