import math
import random
import time
import itertools

def _score_func(A):
    a_set = set(A)
    if len(a_set) < 2:
        return 0.0
    diffs = {x - y for x in a_set for y in a_set}
    sums = {x + y for x in a_set for y in a_set}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a_set)) / 100

def solve():
    """Return a list of distinct integers A with large difference set and small sum set."""
    best_score = 0.0
    best_set = []
    max_n = 4000
    max_abs = 10**15

    # Try constructions with two disjoint arithmetic progressions sharing the same difference
    # A1 = a + k*d, A2 = b + k*d, where b-a is not multiple of d
    # Sumset: (a+b) + (k1+k2)*d, union with 2a+..., 2b+... sizes ~ 3N instead of N
    # Diffset: many more combos: (a-b) + (k1-k2)*d, (b-a)+(k1-k2)*d, and self diffs -> ~4N
    
    # We want large N but N must be <= max_n/2, and values fit within limits
    # Maximize |diff|/|sum|: diff ~ 4N-3, sum ~ 3N-2 => ratio ~ 4/3 in log space
    
    for N in range(max_n//2, 10, -1):  # try large N first
        # Choose d such that N*d fits in bounds, and two offsets a,b with shift s not multiple of d
        max_d = max_abs // (N - 1)
        if max_d < 2:
            continue
        # Try different shifts s = b-a, not multiple of d, and ensure progressions disjoint
        for d in [max_d, max_d // 2, max_d // 3, max_d // 5, max_d // 10, max_d // 100]:
            if d < 1:
                continue
            # pick a such that both progressions start near 0, use shift s small relative to d
            # but s not multiple of d
            best_local = 0.0
            best_local_set = []
            for s in [1, -1, 2, -2, 3, -3, d//2 + 1, -(d//2 + 1)]:
                if s % d == 0:
                    continue
                # choose a to center around 0
                a_start = -((N // 2) * d)
                b_start = a_start + s
                # Ensure all values within bounds
                if abs(a_start) > max_abs or abs(a_start + (N-1)*d) > max_abs:
                    continue
                if abs(b_start) > max_abs or abs(b_start + (N-1)*d) > max_abs:
                    continue
                
                # Build progression sets
                A1 = [a_start + k*d for k in range(N)]
                A2 = [b_start + k*d for k in range(N)]
                # Ensure they are disjoint
                set1 = set(A1)
                set2 = set(A2)
                if set1 & set2:
                    continue
                A = A1 + A2
                
                if len(A) > max_n:
                    continue
                    
                score = _score_func(A)
                if score > best_local:
                    best_local = score
                    best_local_set = A
            if best_local > best_score:
                best_score = best_local
                best_set = best_local_set.copy()
                # If we already found large N with good ratio, break early
                if N >= 1000 and best_score > 1.2:
                    break
        if best_score > 1.2 and len(best_set) > 500:
            break  # we have a good solution

    # If above gave something decent, we can refine
    if best_set:
        cur_set = sorted(best_set)
    else:
        # Fallback: use known good structure
        cur_set = [3**i for i in range(1, 15)]

    # Local optimization by small tweaks (add/remove elements at boundaries)
    time_limit = time.time() + 5  # leave rest of time
    best_final = _score_func(cur_set)
    final_set = cur_set[:]
    
    # try small mutations near edges
    for _ in range(200):
        if time.time() > time_limit:
            break
        candidate = list(cur_set)
        idx = random.randrange(len(candidate))
        old_val = candidate[idx]
        for delta in [-1, 1, -2, 2, -d if 'd' in dir() else -1]:
            new_val = old_val + delta
            if abs(new_val) <= max_abs and new_val not in candidate:
                candidate[idx] = new_val
                sc = _score_func(candidate)
                if sc > best_final:
                    best_final = sc
                    final_set = candidate[:]
                    cur_set = candidate[:]
                    break
                candidate[idx] = old_val

    # Ensure within limits
    if len(final_set) > max_n:
        final_set = final_set[:max_n]
    
    return sorted(final_set)


if __name__ == "__main__":
    result = solve()
    print(len(result), _score_func(result))
