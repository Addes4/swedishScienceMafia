# EVOLVE-BLOCK-START
import math
import random
import time

def _score(A):
    s = set(A)
    if len(s) < 2:
        return 0.0
    diffs = set()
    sums = set()
    L = sorted(s)
    n = len(L)
    # build diffs and sums
    for i in range(n):
        ai = L[i]
        for j in range(i, n):
            aj = L[j]
            sums.add(ai + aj)
            diffs.add(aj - ai)
    if not sums:
        return 0.0
    # include negative differences
    nd = len(diffs)
    # differences set is symmetric: all distinct differences
    return math.log(len(s)) if False else (math.log(2*n*(n-1)/2 + n) if False else math.log(max(len(sums),1))) 

def score_exact(A):
    s = set(A)
    n = len(s)
    if n < 2:
        return 0.0
    L = list(s)
    diffs = set()
    sums = set()
    for x in L:
        for y in L:
            diffs.add(x - y)
            sums.add(x + y)
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/n) / 100


def build_from_sidon(M, target_size):
    # Generate a dense Sidon set S in [1, M]
    # Sidon: all pairwise sums a+b distinct (for ordered a<=b)
    # Greedy construction for best density given M
    # Use known: powers of 2 base representation gives Sidon, but density small.
    # Use greedy randomized search for Sidon in [1,M].
    # For large M we can pick S from {i*(q)+r} types.
    # Since only need many a/b ratios forming many values, use a simple Sidon: 
    # S = {2^i} is Sidon trivially but density log.
    # Use Singer difference set style approximation.
    # Practical: use greedy with a bitset to check Sidon condition.
    # For M up to maybe 2000, greedy works.
    S = []
    used_sums = set()
    # candidate order
    candidates = list(range(1, M + 1))
    random.seed(12345)
    # Greedy: add x if for all a,b in S, x+a not in used_sums and x+x not equal any sum
    for x in candidates:
        ok = True
        # check x + a for a in S
        for a in S:
            if x + a in used_sums:
                ok = False
                break
        if ok:
            # also need x + x unique and not in used sums
            if 2 * x in used_sums:
                ok = False
            if ok:
                # add
                for a in S:
                    used_sums.add(x + a)
                used_sums.add(2 * x)
                S.append(x)
                if len(S) >= target_size:
                    break
    return S


def build_A_from_ratios(S, R):
    A = set()
    seen = set()
    for a in S:
        for b in S:
            if a == b:
                continue
            # use a/b
            val = (a * R) // b
            if -10**15 <= val <= 10**15:
                A.add(val)
    return sorted(A)


def attempt(
    M_values=(50, 100, 200, 400, 600, 800, 1000, 1400, 1800, 2400, 3000),
    R_values=(10**6, 10**7, 10**8, 10**9, 10**10, 10**11, 10**12, 10**13, 10**14, 10**15 - 1),
    target_sizes=(20, 30, 40, 60, 80, 100, 140, 180),
):
    best = []
    best_score = -1.0
    deadline = time.time() + 110
    tried = 0
    for M in M_values:
        if time.time() > deadline:
            break
        # build Sidon set S with maximum size roughly ~sqrt(M)
        # but greedy may produce about sqrt(M) elements
        max_s = int(math.sqrt(M) * 4 + 10)
        S = build_from_sidon(M, min(max_s, M))
        if len(S) < 3:
            continue
        # limit S size to keep product manageable
        for ts in target_sizes:
            if ts > len(S) * len(S):
                continue
            if time.time() > deadline:
                break
            # use only first ts elements of S
            S_sub = S[:min(ts, len(S))]
            for R in R_values:
                if time.time() > deadline:
                    break
                A = build_A_from_ratios(S_sub, R)
                if len(A) < 2 or len(A) > 4000:
                    continue
                sc = score_exact(A)
                tried += 1
                if sc > best_score:
                    best_score = sc
                    best = A
        # also try full S with moderate R
        for R in (10**8, 10**10, 10**12):
            if time.time() > deadline:
                break
            A = build_A_from_ratios(S, R)
            if len(A) < 2 or len(A) > 4000:
                continue
            sc = score_exact(A)
            tried += 1
            if sc > best_score:
                best_score = sc
                best = A
    return best, best_score


def greedy_local_improve(A, time_budget=10.0):
    # Try adjusting elements by +-1, +-2 to improve score
    A = sorted(set(A))
    cur = A[:]
    cur_score = score_exact(cur)
    best = cur[:]
    best_score = cur_score
    deadline = time.time() + time_budget
    if len(cur) < 5:
        return best
    # sample a few elements to mutate
    idxs = list(range(len(cur)))
    random.seed(999)
    while time.time() < deadline:
        random.shuffle(idxs)
        improved = False
        for i in idxs[:min(8, len(idxs))]:
            for delta in (1, -1, 2, -2, 3, -3):
                cand = cur[:]
                nv = cand[i] + delta
                if nv in cur:
                    continue
                if abs(nv) > 10**15:
                    continue
                cand[i] = nv
                sc = score_exact(cand)
                if sc > best_score:
                    best_score = sc
                    best = cand[:]
                    cur = cand[:]
                    cur_score = sc
                    improved = True
                    break
            if improved:
                break
        if not improved:
            break
    return best


def solve():
    random.seed(42)
    best_A, best_sc = attempt()
    if len(best_A) < 2:
        # fallback
        best_A = [3**i for i in range(1, 12)]
        best_sc = score_exact(best_A)
    # local improvement
    improved = greedy_local_improve(best_A, time_budget=8.0)
    if score_exact(improved) > best_sc:
        best_A = improved
    # ensure distinct and within bounds
    best_A = sorted(set(best_A))
    best_A = [x for x in best_A if abs(x) <= 10**15][:4000]
    # final check on size
    if len(best_A) < 2:
        best_A = [0, 1]
    return best_A
# EVOLVE-BLOCK-END
