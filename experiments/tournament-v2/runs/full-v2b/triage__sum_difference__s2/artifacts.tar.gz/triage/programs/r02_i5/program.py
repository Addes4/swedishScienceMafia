# EVOLVE-BLOCK-START
"""
Construction: subset sums of a carefully chosen superincreasing-ish basis.

Idea (from problem statement):
  - Take a basis {g_1, ..., g_k} where g_i is roughly double g_{i-1}
    (a "superincreasing-like" set). Then subset sums A = {sum of subset}
    are almost in bijection with the subsets themselves, giving |A| = 2^k.
  - If the g_i were exactly superincreasing with ratio >= 2, then A+A would
    collapse badly because a+b = (S)+(T) is just the digitwise sum.
    To make |A+A| small but |A-A| large, use a *near-superincreasing*
    basis: ratio slightly less than 2 so carries happen, giving many
    distinct differences but overlapping sums.

  - Insert "spoiler" elements: occasionally break the doubling pattern
    with a smaller value, increasing the number of distinct differences
    without inflating the sum set (since the spoiler is small).

Concretely we use basis
    g_1 = 1
    g_i = g_{i-1} + g_{i-1} - e_i + extra structure...
and take ALL subset sums (bottom-up / bitset) so |A| is large (up to 4000).

We tune parameters to maximise log|A-A| / log|A+A| plus size bonus.
"""
import math
import time


def _subset_sums(basis):
    """All subset sums of basis, as a Python set, capped in size."""
    A = {0}
    for g in basis:
        new = set()
        for x in A:
            new.add(x + g)
        A |= new
    return A


def _eval(A):
    n = len(A)
    if n < 2:
        return -1.0, 0, 0
    diffs = set()
    for x in A:
        for y in A:
            diffs.add(x - y)
    sums = set()
    for x in A:
        for y in A:
            sums.add(x + y)
    if len(sums) == 0:
        return -1.0, len(diffs), 0
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _eval_fast(A):
    """Cheap approximate evaluator for tuning (uses set comprehensions)."""
    n = len(A)
    if n < 2:
        return -1.0
    Al = list(A)
    diffs = set()
    for x in Al:
        for y in Al:
            diffs.add(x - y)
    sums = set()
    for x in Al:
        for y in Al:
            sums.add(x + y)
    if not sums:
        return -1.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build_basis(k, ratio_num, ratio_den, spoiler_period, spoiler_scale_num, spoiler_scale_den,
                 cap=4 * 10 ** 15):
    """
    Build a basis of length k.
      - default step: g_{i+1} = g_i * ratio_num // ratio_den  (approx ratio)
      - every spoiler_period-th step, use a smaller increment ("spoiler")
        to break the superincreasing property and create carries.
    """
    basis = []
    g = 1
    basis.append(g)
    for i in range(1, k):
        step = (g * ratio_num) // ratio_den
        if step < 1:
            step = 1
        # spoiler: reduce the step occasionally
        if spoiler_period > 0 and i % spoiler_period == 0:
            step = (step * spoiler_scale_num) // spoiler_scale_den
            if step < 1:
                step = 1
        nxt = g + step
        if nxt > cap:
            break
        basis.append(nxt)
        g = nxt
    return basis


def solve():
    t0 = time.time()
    best_score = -1.0
    best_A = None

    # We have a 120s budget; budget most of it for evaluating candidate sets.
    # Note: full |A|^2 evaluation is O(n^2) which is expensive for n near 4000,
    # so we cap n for the *evaluation* stage and select a smaller good set.

    candidates = []

    # Candidate family: near-superincreasing bases with spoilers.
    # ratio_num/ratio_den controls growth (near 2 gives large A, slightly
    # under 2 gives lots of carries -> many differences).
    ratios = [
        (20, 10),  # exactly 2
        (19, 10),  # 1.9
        (18, 10),  # 1.8
        (17, 10),  # 1.7
        (16, 10),  # 1.6
        (15, 10),  # 1.5
        (190, 100),  # 1.90
        (195, 100),  # 1.95
        (185, 100),  # 1.85
        (175, 100),  # 1.75
    ]

    # Number of basis elements: |A| = 2^k, we want <= 4000 -> k <= 11
    # (2^11 = 2048, 2^12 = 4096 > 4000).
    ks = [9, 10, 11]

    spoiler_periods = [0, 2, 3, 4, 5]
    spoiler_scales = [(1, 2), (2, 3), (1, 3), (3, 4), (1, 4)]

    # Enumerate candidates, build subset sums, keep distinct nonzero sets.
    seen = set()
    for k in ks:
        for rn, rd in ratios:
            for sp in spoiler_periods:
                for sn, sd in spoiler_scales:
                    if sp == 0 and (sn, sd) != spoiler_scales[0]:
                        continue
                    basis = _build_basis(k, rn, rd, sp, sn, sd)
                    if len(basis) < 5:
                        continue
                    key = tuple(basis)
                    if key in seen:
                        continue
                    seen.add(key)
                    candidates.append(basis)

    # Also add pure powers-of-two bases (ratio exactly 2, no spoiler).
    for k in [10, 11]:
        basis = [2 ** i for i in range(k)]
        if tuple(basis) not in seen:
            seen.add(tuple(basis))
            candidates.append(basis)

    # Evaluate candidates that have manageable size (n <= ~1500, so n^2 <= 2.25M
    # set ops which is fine). Prefer larger n for the size bonus.
    tuned = []
    for basis in candidates:
        A = _subset_sums(basis)
        n = len(A)
        if n < 5 or n > 4000:
            continue
        tuned.append((basis, A, n))

    # Sort: try tuning on moderate-sized sets first (fast eval), then larger.
    tuned.sort(key=lambda t: -t[2])

    # Give a fair share of time to each candidate proportional to n^2 cost.
    deadline = t0 + 110  # leave margin

    for basis, A, n in tuned:
        if time.time() > deadline:
            break
        # Evaluate. Cost ~ n^2. Skip if n too large and we're running out of time.
        if n * n > 8_000_000 and time.time() > t0 + 60:
            continue
        try:
            sc, nd, ns = _eval(A)
        except MemoryError:
            continue
        if sc > best_score:
            best_score = sc
            best_A = A
            # Small refinement: try adding a few extra elements derived from
            # small perturbations of the basis, but only if time allows.

    if best_A is None:
        # Fallback: powers of two.
        best_A = _subset_sums([2 ** i for i in range(11)])

    A = sorted(best_A)

    # Final attempts: local refinement — try replacing the largest few basis
    # elements with nearby values (via re-deriving A) — but only if time left.
    # (We keep this cheap and bounded.)
    if time.time() < deadline and best_A is not None:
        # Try a small greedy expansion: add a few small "spoilery" numbers
        # that are sums/differences already present, in order to increase
        # |A-A| without growing |A+A| much.
        # We only add numbers that are already inside the difference span.
        base_list = A[:]
        base_set = set(base_list)
        tried = 0
        improved = True
        cur = base_set
        while improved and time.time() < deadline and tried < 4:
            improved = False
            tried += 1
            # candidate additions: a few small integers and a few sums
            cand_adds = set()
            step = 1
            while step <= 64:
                for s in (step, -step):
                    if 0 not in base_set:
                        cand_adds.add(s)
                step *= 2
            for x in list(cur)[:50]:
                for y in list(cur)[:50]:
                    cand_adds.add(x + y)
            # test each addition
            for c in list(cand_adds)[:30]:
                if c in cur:
                    continue
                if len(cur) >= 4000:
                    break
                trial = set(cur)
                trial.add(c)
                if len(trial) > 4000:
                    continue
                sc = _eval_fast(trial)
                if sc > best_score:
                    best_score = sc
                    cur = trial
                    improved = True
                    break
        A = sorted(cur)

    # Final safety: deduplicate, bound size and values.
    A = sorted(set(A))
    if len(A) > 4000:
        A = A[:4000]
    A = [x for x in A if -10 ** 15 <= x <= 10 ** 15]
    if len(A) < 2:
        A = [0, 1]
    return A
# EVOLVE-BLOCK-END
