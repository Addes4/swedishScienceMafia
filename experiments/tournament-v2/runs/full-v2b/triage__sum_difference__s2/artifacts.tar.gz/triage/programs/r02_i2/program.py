# EVOLVE-BLOCK-START
"""
Construction: Build A from a short interval [M, M+L] but delete a carefully 
chosen subset to break additive structure more than subtractive structure, 
for instance removing all multiples of some small prime p.
"""
import math
import time

def _score_func(A):
    """Compute score for a set A"""
    A = list(set(A))
    n = len(A)
    if n < 2:
        return 0.0, 0, 0, 0
    
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    
    log_diff = math.log(len(diffs)) if len(diffs) > 1 else 0
    log_sum = math.log(len(sums)) if len(sums) > 1 else 0
    if log_sum == 0:
        return 0.0, len(A), len(sums), len(diffs)
    
    score = log_diff / log_sum + (1 - 1 / len(A)) / 100
    return score, len(A), len(sums), len(diffs)

def solve():
    """Return a list of distinct integers A with large difference set and small sum set."""
    
    best_score = 0
    best_set = []
    
    # Strategy: Interval with multiplicative removal
    # Remove multiples of prime p to break additive structure more than subtractive
    
    # Vary interval starting position M and length L
    start_candidates = [(50000, 50), (500000, 100), (5000000, 200), (1e7, 50), (1e8, 100)]
    
    for M, L in start_candidates:
        for p in [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]:
            # Only consider primes where p <= L/2 for effective removal
            if p > L * 2:
                continue
            
            # Generate the interval
            interval = list(range(M, M + L))
            
            # Remove multiples of p
            A = [x for x in interval if x % p != 0]
            
            if len(A) < 10:
                continue
            
            score, n, s, d = _score_func(A)
            if score > best_score and n < 4000:
                best_score = score
                best_set = A
    
    # Try consecutive powers of 3 with multiplicative filtering
    for n_terms in [10, 12, 14, 16]:
        base_set = [3**i for i in range(n_terms)]
        A = [x for x in base_set if x >= 1 and x <= 1e15]
        if len(A) >= 5:
            score, n, s, d = _score_func(A)
            if score > best_score:
                best_score = score
                best_set = A
    
    # Try interval centered at prime powers with multiplicative removal
    for root in [2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 50, 100, 200]:
        for offset in [0, 50, 100, 200, 500, 1000, 2000]:
            M = root + offset * 100
            for length in [150, 300, 500, 700]:
                for p in [3, 5, 7, 11, 13]:
                    if length < p * 2:
                        continue
                    
                    interval = list(range(M, M + length))
                    A = [x for x in interval if x % p != 0]
                    
                    if len(A) < 20:
                        continue
                    
                    score, n, s, d = _score_func(A)
                    if score > best_score and len(A) < 4000:
                        best_score = score
                        best_set = A
    
    # Try higher values of M with larger intervals
    for base_m in [1e6, 1e7, 5e7, 1e8]:
        for length in [300, 500, 1000, 2000]:
            for p in [5, 7, 11, 13, 17, 19, 23]:
                if p > length * 3:
                    continue
                
                interval = list(range(int(base_m), int(base_m) + length))
                A = [x for x in interval if x % p != 0]
                
                if len(A) < 20 or len(A) >= 4000:
                    continue
                
                score, n, s, d = _score_func(A)
                if score > best_score:
                    best_score = score
                    best_set = A
    
    # Try set starting with prime offset intervals
    for start_prime in [101, 1000, 10000, 100000]:
        for length in [500, 1000, 2000, 3000]:
            for p in [3, 5, 7, 11, 13]:
                interval = list(range(start_prime, start_prime + length))
                A = [x for x in interval if x % p != 0]
                
                if len(A) < 20 or len(A) >= 4000:
                    continue
                
                score, n, s, d = _score_func(A)
                if score > best_score:
                    best_score = score
                    best_set = A
    
    # Try interval with different prime offsets for M
    for offset_sign in [1, -1]:
        for sign_m in [100000, 500000, 1000000, 5000000, 10000000]:
            M = sign_m * offset_sign
            for p in [3, 5, 7, 11, 13, 17]:
                for length in [400, 800, 1200, 1600]:
                    if p > length * 2:
                        continue
                    
                    interval = list(range(max(1, int(M)), max(1, int(M)) + length))
                    A = [x for x in interval if x % p != 0]
                    
                    if len(A) < 20 or len(A) >= 4000:
                        continue
                    
                    score, n, s, d = _score_func(A)
                    if score > best_score:
                        best_score = score
                        best_set = A
    
    # Fine-tuning: try smaller intervals with larger primes
    for length in [200, 400, 600, 800, 1000]:
        for start in range(10000, 300000, 10000):
            for p in [5, 7, 11, 13, 17, 19, 23]:
                if p > length * 2.5 or length < 2*p:
                    continue
                
                interval = list(range(start, start + length))
                A = [x for x in interval if x % p != 0]
                
                if len(A) < 20 or len(A) >= 4000:
                    continue
                
                score, n, s, d = _score_func(A)
                if score > best_score:
                    best_score = score
                    best_set = A
    
    # Very large scale search
    for base_m in [1e8, 1e9, 5e9]:
        for length in [1000, 2000, 3000]:
            for p in [5, 7, 11, 13, 17, 19, 23, 29, 31]:
                interval = list(range(int(base_m), int(base_m) + length))
                A = [x for x in interval if x % p != 0]
                
                if len(A) < 20 or len(A) >= 4000:
                    continue
                
                score, n, s, d = _score_func(A)
                if score > best_score:
                    best_score = score
                    best_set = A
    
    return list(best_set)
# EVOLVE-BLOCK-END
