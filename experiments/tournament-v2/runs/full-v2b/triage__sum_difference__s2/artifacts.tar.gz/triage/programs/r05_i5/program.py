import math
import random
from itertools import combinations

def solve():
    """
    Construct A as the set of integers n in [0, X] for which the sum of digits
    of n in base b1 equals the sum of digits of n in base b2.
    This imposes a strong additive linear constraint that shrinks the sumset
    while differences proliferate.
    """
    
    def digit_sum(n, base):
        """Return sum of digits of n in given base."""
        s = 0
        while n:
            s += n % base
            n //= base
        return s
    
    def score_set(A):
        """Compute log|A-A| / log|A+A| + bonus."""
        if len(A) < 2:
            return 0.0
        # Use set for fast inclusion, but compute with sorted list for differences/sums
        a_set = set(A)
        
        # Compute difference set size efficiently
        # Sort A for faster difference calculation?
        A_sorted = sorted(A)
        diffs = set()
        n = len(A_sorted)
        for i in range(n):
            ai = A_sorted[i]
            for j in range(i, n):
                diffs.add(ai - A_sorted[j])
                diffs.add(A_sorted[j] - ai)
        
        # Compute sum set size
        sums = set()
        for i in range(n):
            ai = A_sorted[i]
            # Use symmetry: only compute pairs (i <= j) and add both a_i + a_j (same)
            for j in range(i, n):
                sums.add(ai + A_sorted[j])
        
        if len(sums) == 0:
            return 0.0
        return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0/len(A)) / 100.0

    best_A = []
    best_score = 0.0
    
    # We need multiplicatively independent bases: log(b1)/log(b2) irrational
    # Use b1=2, b2=3. Another pair: (2,5), (3,5), (2,7), (3,7)
    # Try several base pairs and X ranges.
    
    base_pairs = [(2, 3), (2, 5), (3, 5), (2, 7), (3, 7)]
    
    for b1, b2 in base_pairs:
        # Range of numbers to consider
        # We need A size <= 4000, so X must be limited.
        # The density of numbers with equal digit sums decays roughly like 1/sqrt(digits).
        # For b1=2, b2=3, max digits ~ log2(X), so equality probability ~ 1/sqrt(log X).
        # To get ~4000 elements, X might be around 10^6 to 10^9.
        # Let's try several X bounds.
        
        # Estimate: for b1=2,b2=3, typical digit sum range for n up to 2^K is ~K/2 for base2,
        # and ~K*ln(2)/ln(3)*1.5 ~ 0.63*K*1.5 ~ 0.95K for base3? Actually base3 digit sum
        # of n approx log_3(n)* (3-1)/2 = log_3(n). So equality condition: sum2 ~ sum3.
        # Density is approx 1/sqrt(log n).
        
        # We'll search iteratively to find X that gives 200..4000 elements.
        
        # Start with a coarse estimate and refine.
        for target_size in [500, 1000, 2000, 3000, 4000]:
            # Binary search for X that yields approx target_size
            lo = 1
            hi = 10**15  # upper bound per problem
            # First find rough X via exponential search
            X_test = 1000
            while True:
                A = [n for n in range(X_test + 1) if digit_sum(n, b1) == digit_sum(n, b2)]
                if len(A) >= target_size:
                    break
                if X_test > 10**9:
                    X_test = min(X_test * 10, 10**12)
                    if X_test > 10**12:
                        break
                X_test *= 2
                if X_test > 10**12:
                    break
            
            if X_test > 10**12:
                continue
                
            # Now binary search for exact X to get close to target_size
            lo, hi = X_test // 2, X_test * 2
            best_X = lo
            best_diff = abs(len([n for n in range(lo + 1) if digit_sum(n, b1) == digit_sum(n, b2)]) - target_size)
            for _ in range(20):  # 20 steps enough
                mid = (lo + hi) // 2
                A_mid = [n for n in range(mid + 1) if digit_sum(n, b1) == digit_sum(n, b2)]
                sz = len(A_mid)
                if abs(sz - target_size) < best_diff:
                    best_diff = abs(sz - target_size)
                    best_X = mid
                if sz < target_size:
                    lo = mid + 1
                else:
                    hi = mid - 1
                if lo > hi:
                    break
            
            # Build final candidate A with best_X
            A = [n for n in range(best_X + 1) if digit_sum(n, b1) == digit_sum(n, b2)]
            # Ensure size within limits
            if len(A) > 4000:
                # Trim to 4000 by taking first 4000 or last 4000? 
                # Try both: maybe first 4000 has small values -> smaller sums?
                # For ratio, maybe smaller numbers work well. Let's try first 4000.
                A = A[:4000]
            if len(A) >= 10:
                sc = score_set(A)
                if sc > best_score:
                    best_score = sc
                    best_A = A[:]
    
    # Additional optimization: local search on the best found set.
    # We can try adding/removing elements to improve ratio.
    
    if best_A:
        best_set = set(best_A)
        best_A_sorted = sorted(best_set)
        best_score = score_set(best_A_sorted)
        
        # Try adding elements near existing ones that maintain ratio?
        # For small mutations: remove elements that might be hurting sumset size?
        # Actually, we want to maximize log|diffs|/log|sums|.
        # We could try to remove a few elements that cause many sums (duplicates) but few diffs.
        
        # Greedy removal: try removing each element and see if score improves.
        improved = True
        while improved and len(best_A_sorted) > 10:
            improved = False
            current_score = score_set(best_A_sorted)
            for i in range(len(best_A_sorted)):
                candidate = best_A_sorted[:i] + best_A_sorted[i+1:]
                sc = score_set(candidate)
                if sc > current_score:
                    best_A_sorted = candidate
                    current_score = sc
                    improved = True
                    break
        
        best_score = score_set(best_A_sorted)
        best_A = best_A_sorted
    
    # Finally, ensure we return something decent if nothing found
    if not best_A or len(best_A) < 2:
        # Fallback: balanced ternary set known to be good
        best_A = [3**i for i in range(1, 15)] + [3**i + 3**j for i in range(10) for j in range(i+1, 12)]
        best_A = sorted(set(best_A))
        if len(best_A) > 4000:
            best_A = best_A[:4000]
    
    return best_A

