import math
import random
import itertools

def solve():
    """
    Construct a set A with large difference set and small sum set.
    
    Strategy: Use a base-B signed-digit representation where digits come from a 
    small 'seed' set S that itself has good difference/sum ratio.
    The digit set S is sum-poor but difference-rich. When extended across multiple
    'digits' (positions in base B), the differences combine multiplicatively while
    sums are limited by carry patterns.
    
    Key: Choose S = {0, ±1, ±B^(k-1), ...} or similar with high difference/sum ratio.
    Then A = { sum_i d_i * B^i : d_i in S } for i = 0..N-1.
    Large B ensures minimal cross-digit sum interference for sums but allows difference
    diversity.
    """
    best_score = 0
    best_set = []
    
    # Helper to compute the objective
    def compute_score(A_list):
        A = set(A_list)
        if len(A) < 2:
            return -1
        diffs = set()
        sums = set()
        # For efficiency with larger sets, sample if too big
        if len(A) > 500:
            # Use sampling for very large sets during search
            sample_size = min(500, len(A))
            A_sample = random.sample(list(A), sample_size)
            for x in A_sample:
                for y in A_sample:
                    diffs.add(x - y)
                    diffs.add(y - x)
                    sums.add(x + y)
            # Extrapolate roughly for full set? No, just return sample score for guidance
            if len(sums) == 0:
                return -1
            return math.log(len(diffs) + 1) / math.log(len(sums) + 1) + (1 - 1/len(A))/100
        else:
            A_list_sorted = sorted(A)
            for i, x in enumerate(A_list_sorted):
                for y in A_list_sorted[i:]:  # symmetry for sums
                    sums.add(x + y)
                for y in A_list_sorted:
                    diffs.add(x - y)
            if len(sums) <= 1:
                return -1
            return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/len(A))/100
    
    # Strategy 1: Small seed S with high diff/sum ratio, extended multiplicatively via base
    # Let's search for good small seed sets S (size up to ~10) and then build A from them.
    
    # Precompute some seed candidates
    seed_candidates = []
    
    # Brute force small integer seeds
    candidate_values = list(range(-8, 9))
    for size in [3, 4, 5, 6]:
        for combo in itertools.combinations(candidate_values, size):
            S = set(combo)
            if 0 not in S:
                continue  # 0 often useful for structure
            diffs = {a - b for a in S for b in S}
            sums = {a + b for a in S for b in S}
            if len(sums) > 1:
                ratio = math.log(len(diffs)) / math.log(len(sums))
                if ratio > 1.0:
                    seed_candidates.append((ratio, sorted(S)))
    
    # Also try structured seeds: powers of 2 scaled
    for k in [2, 3, 4]:
        S = {0}
        for i in range(k):
            S.add(2**i)
            S.add(-2**i)
        S = sorted(S)
        diffs = {a - b for a in S for b in S}
        sums = {a + b for a in S for b in S}
        if len(sums) > 1:
            ratio = math.log(len(diffs)) / math.log(len(sums))
            seed_candidates.append((ratio, S))
    
    # Sort seeds by ratio descending
    seed_candidates.sort(key=lambda x: x[0], reverse=True)
    
    # For each promising seed, construct A using base-B expansion
    # We need A size <= 4000, elements abs <= 1e15
    # A = { sum_{i=0}^{N-1} d_i * B^i : d_i in S }
    # |A| = |S|^N, so choose N accordingly.
    
    for ratio_seed, S in seed_candidates[:50]:
        s = len(S)
        # Determine N such that s^N <= 4000
        max_N = int(math.log(4000) / math.log(s)) + 1
        for N in range(1, max_N + 1):
            # Need base B large enough to avoid sum collisions across digits
            # Sum of two numbers: each digit sum d_i + e_i in S+S, but if B is large,
            # carries rarely happen since S+S values are bounded.
            # Let M = max absolute value in S+S.
            S_vals = S
            max_sum_digit = max(abs(a + b) for a in S for b in S)
            # To avoid carries between digits, we need B > 2 * max_sum_digit * N? Actually 
            # during addition, if we don't carry, sum digits just elementwise addition.
            # We want some carries to limit sum set size; but too many carries may increase sum set.
            # Let's set B just slightly larger than max_sum_digit to allow some carries.
            B = max_sum_digit + 2
            # But also must keep elements within 1e15 absolute value.
            # Maximum element ~ max(|S|) * (B^N - 1)/(B-1) <= 1e15
            max_S_val = max(abs(v) for v in S)
            max_element = max_S_val * (B**N - 1) // (B - 1) if B > 1 else max_S_val * N
            if max_element > 1e15:
                continue
            
            # Generate A via recursive enumeration or iterative
            A = {0}
            for pos in range(N):
                new_A = set()
                base_pow = B ** pos
                for a in A:
                    for d in S:
                        new_A.add(a + d * base_pow)
                A = new_A
                if len(A) > 4000:
                    break
            if len(A) > 4000:
                # Try smaller N
                continue
            
            A_list = sorted(A)
            if len(A_list) >= 10:
                score = compute_score(A_list)
                if score > best_score:
                    best_score = score
                    best_set = A_list
    
    # Strategy 2: Direct construction using two-level hierarchy
    # S1 = seed with high diff/sum, S2 = { sum s_i * B^i } with small N.
    # Try varying B slightly around optimal
    
    for ratio_seed, S in seed_candidates[:30]:
        s = len(S)
        for N in [2, 3, 4]:
            if s**N > 4000:
                continue
            # Search around B = max(|S+S|) + delta
            S_sum_abs = max(abs(a+b) for a in S for b in S)
            for delta in range(0, 5):
                B = S_sum_abs + 1 + delta
                max_S_val = max(abs(v) for v in S)
                max_element = max_S_val * (B**N - 1) // (B - 1) if B > 1 else max_S_val * N
                if max_element > 1e15:
                    continue
                # Generate
                A = {0}
                for pos in range(N):
                    base_pow = B ** pos
                    new_A = set()
                    for a in A:
                        for d in S:
                            new_A.add(a + d * base_pow)
                    A = new_A
                if len(A) > 4000:
                    break
                A_list = sorted(A)
                if len(A_list) >= 10:
                    score = compute_score(A_list)
                    if score > best_score:
                        best_score = score
                        best_set = A_list
    
    # Strategy 3: Try sets from known literature on difference/sum sets
    # Example: A = { sum_{i=0}^{k-1} c_i * (2^m)^i } with c_i in {-1,0,1}
    for m in [3,4,5,6]:
        B = 2**m
        for N in [3,4,5]:
            if 3**N > 4000:
                continue
            # S = {-1,0,1}
            S = [-1, 0, 1]
            A = {0}
            max_val = 0
            for pos in range(N):
                base_pow = B ** pos
                new_A = set()
                for a in A:
                    for d in S:
                        new_A.add(a + d * base_pow)
                A = new_A
            # filter zeros? keep zero maybe.
            A_list = sorted(A)
            if len(A_list) > 4000:
                continue
            if max(abs(x) for x in A_list) > 1e15:
                continue
            if len(A_list) >= 10:
                score = compute_score(A_list)
                if score > best_score:
                    best_score = score
                    best_set = A_list
    
    # Strategy 4: Try random mutations on best found so far
    if best_set:
        current_best = best_set[:]
        start_time = time.time()
        while time.time() - start_time < 30:  # spend up to 30 seconds on local search
            # Mutate: change one element slightly
            A_mut = current_best[:]
            idx = random.randint(0, len(A_mut)-1)
            old_val = A_mut[idx]
            # Try changing by small amount
            for delta in [1, -1, 2, -2, 3, -3]:
                new_val = old_val + delta
                if new_val in A_mut:
                    continue
                if abs(new_val) > 1e15:
                    continue
                A_mut[idx] = new_val
                score = compute_score(A_mut)
                if score > best_score:
                    best_score = score
                    best_set = sorted(A_mut)
                    current_best = best_set[:]
                    break
            else:
                # Try swap two elements
                if len(A_mut) >= 4:
                    i, j = random.sample(range(len(A_mut)), 2)
                    A_mut[i], A_mut[j] = A_mut[j], A_mut[i]
                    score = compute_score(A_mut)
                    if score > best_score:
                        best_score = score
                        best_set = sorted(A_mut)
                        current_best = best_set[:]
        # Also try adding/removing elements
        start_time2 = time.time()
        while time.time() - start_time2 < 30:
            A_mut = current_best[:]
            if len(A_mut) < 4000 and random.random() < 0.5:
                # add element
                candidates_add = []
                for _ in range(50):
                    new_val = random.randint(-int(1e14), int(1e14))
                    if new_val not in A_mut:
                        candidates_add.append(new_val)
                for new_val in candidates_add:
                    A_test = A_mut + [new_val]
                    score = compute_score(A_test)
                    if score > best_score:
                        best_score = score
                        best_set = sorted(A_test)
                        current_best = best_set[:]
                        break
            else:
                # remove element
                if len(A_mut) > 2:
                    idx = random.randint(0, len(A_mut)-1)
                    A_test = A_mut[:idx] + A_mut[idx+1:]
                    score = compute_score(A_test)
                    if score > best_score:
                        best_score = score
                        best_set = sorted(A_test)
                        current_best = best_set[:]
    
    # Ensure result is within bounds
    final = sorted(set(best_set))
    # If still empty, fallback
    if not final:
        # Fallback: Simple balanced ternary
        N = 8
        B = 4
        S = [-1, 0, 1]
        A = {0}
        for pos in range(N):
            base_pow = B ** pos
            new_A = set()
            for a in A:
                for d in S:
                    new_A.add(a + d * base_pow)
            A = new_A
        final = sorted(A)
    
    return final

import time
