# EVOLVE-BLOCK-START
"""
Construction: iterative greedy addition from a structured base set.

1. Generate a rich "candidate pool" P of integers with good difference/sum properties:
   - balanced ternary numbers with bounded length (base 3, digits -1,0,1)
   - powers of 2 times small offsets
   - sparse combinations
2. Start with a small seed A (e.g., first few elements).
3. Repeatedly add the candidate x in P \ A that maximises the ratio improvement:
   score = log|A' - A'| / log|A' + A'|
   where A' = A ∪ {x}
4. Stop when |A| reaches 4000.
5. Return A as a sorted list.

We maintain difference and sum sets incrementally for speed.
"""

import math
import random
import time

def solve():
    # --- parameters ---
    MAX_SIZE = 4000
    MAX_ABS = 10**15

    # --- generate candidate pool ---
    # Balanced ternary: numbers of form sum_{i=0}^{L-1} d_i * 3^i, d_i in {-1,0,1}
    # Limit L so that 3^L <= MAX_ABS
    # Also add some variations
    
    candidates = set()
    
    # 1. Powers of 3 * small offsets
    L3 = 0
    while 3**L3 <= MAX_ABS:
        p = 3**L3
        for k in range(-4, 5):
            v = p * k
            if v != 0 and abs(v) <= MAX_ABS:
                candidates.add(v)
        L3 += 1
    
    # 2. Balanced ternary with several digits
    # generate all numbers with up to 12 digits (3^12 ~ 5e5 << MAX_ABS, but with combinations grows)
    # Too many if we do all, so restrict total number by random sampling
    
    max_ternary_digits = 12
    # sample random balanced ternary numbers
    for _ in range(20000):
        val = 0
        for i in range(max_ternary_digits):
            d = random.choice([-1, 0, 1])
            val += d * (3**i)
        if val != 0 and abs(val) <= MAX_ABS:
            candidates.add(val)
    
    # 3. Powers of 2 scaled
    L2 = 0
    while 2**L2 <= MAX_ABS:
        p = 2**L2
        for kf in [1, 3, 5, 7, 9, 11]:
            v = p * kf
            if v <= MAX_ABS and v >= -MAX_ABS:
                candidates.add(v)
                candidates.add(-v)
        L2 += 1
    
    # 4. Some semi-random structured numbers
    for _ in range(15000):
        # combine two powers of 2 and 3 with small offset
        i2 = random.randint(0, 40)
        i3 = random.randint(0, 25)
        p2 = 2**i2 if 2**i2 <= MAX_ABS else 1
        p3 = 3**i3 if 3**i3 <= MAX_ABS else 1
        c = p2 * random.randint(-2, 2) + p3 * random.randint(-2, 2)
        if c != 0 and abs(c) <= MAX_ABS:
            candidates.add(c)
    
    # 5. More from typical 'good' sets: arithmetic progressions of powers
    for base in [2,3,5,7]:
        for i in range(30):
            if base**i > MAX_ABS: break
            p = base**i
            for step in [1, 2, 3, 5, 7, 11]:
                for cnt in range(1, 6):
                    v = p + step*cnt
                    if v <= MAX_ABS and v >= -MAX_ABS:
                        candidates.add(v)
                    candidates.add(-v)
    
    candidates = list(set(candidates))
    # filter out zeros and duplicates
    candidates = [x for x in candidates if x != 0]
    # limit pool size
    if len(candidates) > 50000:
        random.shuffle(candidates)
        candidates = candidates[:50000]
    
    # sort for reproducibility
    candidates.sort()
    
    # --- initialize A with a few 'good' elements ---
    # choose from first few balanced ternary numbers
    A = [3, 9, 27, 81, 243, 729, 2187, 6561]  # powers of 3
    A_set = set(A)
    remaining = [x for x in candidates if x not in A_set]
    
    # compute initial difference and sum sets
    diffs = set()
    for x in A:
        for y in A:
            diffs.add(x - y)
    
    sums = set()
    for x in A:
        for y in A:
            if x <= y:  # avoid duplicate work but still compute all
                sums.add(x + y)
    # Actually need all pairs for proper counting
    sums_full = set()
    for x in A:
        for y in A:
            sums_full.add(x + y)
    sums = sums_full
    
    best_ratio = math.log(len(diffs)) / math.log(len(sums))
    
    # --- greedy addition ---
    start_time = time.time()
    
    while len(A) < MAX_SIZE and remaining and (time.time() - start_time) < 100:
        # we will try a batch of candidates to pick the best
        batch_size = min(500, len(remaining))
        if batch_size == 0:
            break
        
        # sample a batch
        batch = random.sample(remaining, batch_size)
        
        best_x = None
        best_new_score = -1
        
        for x in batch:
            # compute changes incrementally
            new_diffs = diffs.copy()
            new_sums = sums.copy()
            
            # add differences x - y and y - x for y in A
            for y in A:
                new_diffs.add(x - y)
                new_diffs.add(y - x)
                new_sums.add(x + y)
            new_diffs.add(0)  # x-x=0 already present if size>1, but ensure
            
            # compute new ratio
            num_diffs = len(new_diffs)
            num_sums = len(new_sums)
            # prevent log(1) cases (possible for sum=1 if set size 1, but we start with several)
            if num_sums <= 1:
                continue
            
            try:
                score = math.log(num_diffs) / math.log(num_sums)
            except:
                continue
            
            if score > best_new_score:
                best_new_score = score
                best_x = x
        
        if best_x is None:
            # if none improved, just add random one to grow
            best_x = remaining[0] if remaining else None
            if best_x is None:
                break
            # compute its effect to update sets (we must update diffs/sums)
            new_diffs = diffs.copy()
            new_sums = sums.copy()
            for y in A:
                new_diffs.add(best_x - y)
                new_diffs.add(y - best_x)
                new_sums.add(best_x + y)
            diffs = new_diffs
            sums = new_sums
            best_new_score = math.log(len(diffs)) / math.log(len(sums))
        else:
            # update sets with best_x
            for y in A:
                diffs.add(best_x - y)
                diffs.add(y - best_x)
                sums.add(best_x + y)
        
        A.append(best_x)
        A_set.add(best_x)
        remaining.remove(best_x)
        best_ratio = best_new_score
        
        # Optional: remove some elements if it improves? No, we just add.
    
    # if we haven't reached 4000, fill with remaining candidates
    while len(A) < MAX_SIZE and remaining:
        x = remaining.pop(0)
        if x not in A_set:
            for y in A:
                diffs.add(x - y)
                diffs.add(y - x)
                sums.add(x + y)
            A.append(x)
            A_set.add(x)
    
    # final sort
    A.sort()
    return A

# EVOLVE-BLOCK-END
