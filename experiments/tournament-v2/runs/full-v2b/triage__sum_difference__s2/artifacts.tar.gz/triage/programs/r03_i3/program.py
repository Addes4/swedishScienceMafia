# EVOLVE-BLOCK-START
"""
Implementation idea: fixed-weight binary code with randomized subset selection.
These codes create sets where addition is constrained (few carry variations)
but subtraction yields diverse results due to borrow patterns.
"""
import math
import random
import time
from itertools import combinations


def weight_one_numbers(max_val):
    """Generate all numbers in (0, max_val] whose binary has exactly 1 bit set."""
    result = []
    for i in range(1, int(math.log2(max_val)) + 2):
        val = 1 << i
        if val > max_val:
            break
        result.append(val)
    result.append(-val)
    return sorted(list(set(result)))


def weight_two_numbers(max_val):
    """Generate all numbers with exactly 2 bits set."""
    result = []
    tips = int(math.log2(max_val)) + 2
    for i in range(tips):
        for j in range(i + 1, tips):
            val = (1 << i) + (1 << j)
            if 0 < val <= max_val:
                result.append(val)
                result.append(-val)
    return sorted(set(result))


def weight_three_numbers(min_bit, max_bit, count_per_pair=3):
    """Generate numbers with 3 bits set."""
    result = set()
    n_range = max_bit - min_bit + 2
    for combo in combinations(range(min_bit, max_bit + 1, 2), 3):
        val = sum(1 << b for b in combo)
        if val <= 1e15:
            result.add(val)
            result.add(-val)
    return sorted(result)


def score_set(A):
    """Calculate the sum-difference ratio score for set A."""
    if len(A) < 3:
        return 0.0
    
    A_set = set(A)
    max_len = min(40000, len(A))
    
    sums = set()
    diffs = set()
    count = 0
    start = time.time()
    
    for x in A_set:
        for y in A_set:
            if count >= max_len:
                break
            sums.add(x + y)
            diffs.add(x - y)
            count += 1
            if time.time() - start > 10:
                break
        if time.time() - start > 10:
            break
    
    if len(sums) < 3:
        return 0.0
        
    log_ratio = math.log(len(diffs)) / math.log(len(sums))
    bonus = (1 - 1 / len(A)) / 100
    return log_ratio + bonus


def solve():
    """Return a list of distinct integers A with large difference set and small sum set."""
    
    random.seed(42)
    start_time = time.time()
    
    max_val = 1e15
    n_bits = 64
    min_bits = 35
    target_size = 3000
    current_pool_size = 0
    
    pool_sign_low = []
    pool_sign_high = []
    
    for _ in range(200):
        p = weight_three_numbers(min_bits, n_bits)
        if p:
            if len(p) + current_pool_size > target_size:
                p = p[len(current_pool_size):]
                if not p:
                    continue
            pool_sign_low.extend(sorted([x for x in p if x > 0]))
            pool_sign_high.extend(sorted([x for x in p if x < 0]))
            current_pool_size += len(p) * 2
        if time.time() - start_time > 115:
            break
    
    if not pool_sign_low:
        return [1, 2, 4]
    
    # Greedy filter candidates
    best_set = []
    best_score = score_set([x for x in pool_sign_low[:50]])
    best_size = len(best_set)
    
    cur_set = [pool_sign_low[0]]
    best_set = cur_set.copy()
    
    for c in sorted(pool_sign_low[1:]) + sorted(pool_sign_high[:100]):
        if time.time() - start_time > 118:
            break
        
        cur_set_plus = cur_set + [c] if c not in cur_set else cur_set
        if len(cur_set_plus) <= target_size:
            new_score = score_set(cur_set_plus)
            if new_score > best_score:
                best_score = new_score
                best_set = cur_set_plus[:target_size]
                if len(best_set) >= 200:
                    cur_set = best_set
                    time.sleep(0.01)
    
    # Return the best set found
    size = len(best_set)
    if size < 3:
        return [0, 1, 2]
    
    return sorted(best_set[:target_size])


# EVOLVE-BLOCK-END
