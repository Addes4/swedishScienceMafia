import math
import itertools

def solve():
    """
    Construct A as image of multivariate linear form over symmetric lattice box.
    A = {sum_{i} c_i * x_i : x_i in [-k_i, k_i]} with super-exponential c_i.
    This creates many differences but relatively fewer sums.
    """
    best_score = 0.0
    best_A = []
    
    def score(A):
        sA = set(A)
        if len(sA) < 2:
            return 0.0
        # Compute differences and sums
        diffs = set()
        sums = set()
        L = list(sA)
        n = len(L)
        # If set is too large, sample (but we aim for smallish sets anyway)
        for i in range(n):
            ai = L[i]
            for j in range(i, n):
                aj = L[j]
                diffs.add(ai - aj)
                diffs.add(aj - ai)
                sums.add(ai + aj)
        if len(sums) == 0:
            return 0.0
        return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0/len(sA)) / 100.0
    
    # Try various super-exponential growth rates and box sizes
    # We'll generate A by Cartesian product of ranges - need to keep total size under ~2000
    # Use base such that coefficients grow fast
    bases_to_try = [10, 20, 50, 100, 500]
    box_dims = [2, 3, 4, 5]
    box_radii = [1, 2, 3, 4, 5]
    
    for base in bases_to_try:
        for dim in box_dims:
            for radius in box_radii:
                # Total size = (2*radius+1)^dim
                size = (2*radius + 1) ** dim
                if size > 4000 or size < 10:
                    continue
                
                # Use coefficients c_i = base^i (or some variation)
                coeffs = [base ** i for i in range(dim)]
                
                # Generate all lattice points
                ranges = [list(range(-radius, radius+1)) for _ in range(dim)]
                A = []
                for xs in itertools.product(*ranges):
                    val = sum(c * x for c, x in zip(coeffs, xs))
                    A.append(val)
                
                # Check if distinct
                if len(set(A)) != len(A):
                    continue
                
                sc = score(A)
                if sc > best_score:
                    best_score = sc
                    best_A = A[:]
    
    # Also try mixed radii for better ratio
    for base in [50, 100, 200, 500, 1000]:
        # dim=2 with different radii
        for r1 in range(1, 8):
            for r2 in range(1, 8):
                size = (2*r1+1) * (2*r2+1)
                if size > 4000 or size < 30:
                    continue
                coeffs = [1, base]  # c0=1, c1=base
                ranges = [range(-r1, r1+1), range(-r2, r2+1)]
                A = []
                for x0 in ranges[0]:
                    for x1 in ranges[1]:
                        A.append(coeffs[0]*x0 + coeffs[1]*x1)
                if len(set(A)) != len(A):
                    continue
                sc = score(A)
                if sc > best_score:
                    best_score = sc
                    best_A = A[:]
    
    # 3D with mixed radii
    for base in [30, 50, 100, 200]:
        for r1 in range(1, 5):
            for r2 in range(1, 5):
                for r3 in range(1, 5):
                    size = (2*r1+1)*(2*r2+1)*(2*r3+1)
                    if size > 4000 or size < 30:
                        continue
                    coeffs = [1, base, base*base]
                    ranges = [range(-r1, r1+1), range(-r2, r2+1), range(-r3, r3+1)]
                    A = []
                    for x0 in ranges[0]:
                        for x1 in ranges[1]:
                            for x2 in ranges[2]:
                                A.append(coeffs[0]*x0 + coeffs[1]*x1 + coeffs[2]*x2)
                    if len(set(A)) != len(A):
                        continue
                    sc = score(A)
                    if sc > best_score:
                        best_score = sc
                        best_A = A[:]
    
    # Further optimization: tweak best found set with small perturbations
    if best_A and len(best_A) > 5:
        import random
        random.seed(42)
        A_set = set(best_A)
        # Try removing/adding small values at the boundary
        # We'll try expanding slightly in one coordinate
        # For 2D sets, we can try adding a few more points
        best_A_list = sorted(best_A)
        for _ in range(20):
            new_set = set(best_A_list)
            # perturb some elements
            for _ in range(min(5, len(best_A_list)//10 + 1)):
                idx = random.randrange(len(best_A_list))
                delta = random.choice([-2,-1,1,2])
                val = best_A_list[idx] + delta
                if abs(val) <= 1e15 and val not in new_set:
                    new_set.discard(best_A_list[idx])
                    new_set.add(val)
            if len(new_set) > 1:
                sc = score(list(new_set))
                if sc > best_score:
                    best_score = sc
                    best_A = list(new_set)
                    best_A_list = sorted(best_A)
    
    return best_A

