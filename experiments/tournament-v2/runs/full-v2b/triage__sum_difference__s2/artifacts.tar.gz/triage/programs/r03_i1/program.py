"""
Construction using Pisot numbers: A = { round(C * phi^t) : t = 0..N-1 }
where phi is the golden ratio. The Pisot property means phi^t is exponentially
close to integers. With a suitable scaling, differences remain distinct while
sums can collide due to algebraic relations among the Pisot powers.
"""
import math


def solve():
    # Golden ratio and its sqrt
    sqrt5 = math.sqrt(5.0)
    phi = (1.0 + sqrt5) / 2.0
    
    best_A = []
    best_score = -1.0
    
    # We'll try many scalings C and lengths N, picking the best by actual score.
    # Scoring: log|A-A| / log|A+A| + (1 - 1/|A|)/100
    # To evaluate cheaply we compute DIFFERENT from SUMS using the structure.
    
    # Candidate lengths. Keep |A| <= 4000.
    lengths = [500, 1000, 2000, 3000, 4000]
    
    # We need a scaling C large enough that rounding is stable and distinct.
    # Use C around 1e12 so that C * phi^N stays under 1e15 for N up to ~70?
    # But we want N up to 4000... phi^t grows exponentially so C must shrink.
    # Instead, use *negative* powers: A = { round(C / phi^t) } won't help either.
    # So for large N we need a different scheme.
    
    # Alternative: use powers of a Pisot that grow slowly, but phi grows.
    # Better: use A_t = round(C * phi^t) for small N (limited by 1e15 / C).
    # With C = 1e12, phi^t <= 1e3 => t <= 14. Too few.
    
    # So use the *other* direction: A = { round(C * phi^{-t}) }? That shrinks.
    # Instead, use integer parts of C*phi^t mod something? 
    
    # Practical approach: use base b where b is a Pisot number close to 1, e.g.
    # the smallest Pisot number (plastic number) or use a different tactic.
    
    # The plastic number rho ~ 1.3247 satisfies rho^3 = rho + 1.
    # Still exponential.
    
    # For many elements, we can take A = { round(C * phi^t) : t in S } for a 
    # carefully chosen subset S, OR use combinations.
    
    # Direct large-scale approach: we want ~4000 elements. phi^t for t=1..4000
    # exceeds 1e15 quickly (phi^40 ~ 1e8, phi^70 ~ 1e14, phi^75 > 1e15).
    # So only ~70 powers fit. 
    
    # Use shifted: A_t = round(C * (phi^t + phi^{-t})) = round(C * L_t) where
    # L_t is the Lucas number. These grow like phi^t too.
    
    # To get thousands of elements, use products/sums of Pisot powers with
    # bounded exponents: A = { sum_i e_i * M^i } for M a Pisot power scaling.
    
    # Simplest effective idea: use base B = round(C * phi) for integer C, then
    # A = { B^t mod P } won't be reliable.
    
    # Let's just use the direct near-integer Pisot sequence with N up to ~70,
    # and also try a "beatty-like" sequence using floor of multiples of phi.
    
    # Beatty sequence: a_t = floor(t * alpha) for irrational alpha.
    # Differences t*alpha - s*alpha = (t-s)*alpha, distinct by irrationality.
    # Sums: (t+s)*alpha and floor the results. For t+s < N, distinct mostly.
    # Sum set size ~ 2N, difference set size ~ N^2. Ratio ~ log(N^2)/log(2N) ~ 2
    # Not great but let's try Pisot-specific.
    
    # Best: use A = { floor(C * phi^t) mod M }? skip.
    
    # Try direct: A = { round(C * phi^t) : t = 0..N-1 } with optimal C.
    # Since phi^t for t up to ~70 fits if C ~ 1, use C = large prime? 
    # If C too large, phi^t * C exceeds 1e15. If C small, rounding errors 
    # accumulate unpredictably but the Pisot property means phi^t is VERY close
    # to Fibonacci-based integers; specifically phi^t = F_t * phi + F_{t-1}, 
    # and F_t * phi ≈ complex... Actually phi^t = (L_t + F_t*sqrt5)/2, so 
    # round(phi^t) = L_t/2 if L_t even, else (L_t+1)/2. 
    
    # Let's compute exact: c_t = nearest integer to phi^t equals:
    #   for t even: L_t/2 + ... actually phi^t + psi^t = L_t where psi=(1-sqrt5)/2.
    #   psi^t -> 0. So phi^t = L_t - psi^t. So round(phi^t) = L_t (nearest).
    # So A_t = L_t (Lucas numbers) for t = 0..N-1.
    # These are distinct near-integers! Differences: L_s - L_t. Sums: L_s + L_t.
    
    # Lucas: L_t = phi^t + psi^t. Sum: L_s + L_t = phi^s + phi^t + small.
    # Difference: similar.
    
    # Let's just try many candidate sets and score them.
    
    def score(A):
        s = set(A)
        if len(s) < 2:
            return -1.0
        # compute diffs and sums
        lst = list(s)
        diffs = set()
        sums = set()
        n = len(lst)
        for i in range(n):
            xi = lst[i]
            for j in range(n):
                xj = lst[j]
                diffs.add(xi - xj)
                sums.add(xi + xj)
        if len(sums) == 0:
            return -1.0
        return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / len(s)) / 100.0
    
    # Candidate 1: Lucas numbers
    def lucas_upto(N):
        L = [2, 1]
        while len(L) < N:
            L.append(L[-1] + L[-2])
        return L[:N]
    
    # Candidate 2: near-integers via phi^t with various scalings
    def pisot_seq(N, C):
        # A_t = round(C * phi^t) for t = 0..N-1, ensure within 1e15
        res = []
        val = C
        for t in range(N):
            r = int(round(val))
            if abs(r) > 10**15:
                break
            res.append(r)
            val *= phi
        return res
    
    best = []
    best_sc = -1.0
    
    # Try Lucas numbers (small N because huge)
    for N in [30, 40, 45, 50, 60, 70]:
        A = lucas_upto(N)
        # filter to fit
        A = [x for x in A if abs(x) <= 10**15]
        if len(A) >= 2:
            sc = score(A)
            if sc > best_sc:
                best_sc = sc
                best = A
    
    # Try pisot sequences with different C
    for C in [1, 2, 3, 5, 7, 10, 100, 1000, 10000]:
        for N in [40, 50, 60, 65, 70]:
            A = pisot_seq(N, C)
            if len(A) >= 2:
                sc = score(A)
                if sc > best_sc:
                    best_sc = sc
                    best = A
    
    # Filter distinct and within range
    A = sorted(set(best))
    A = [x for x in A if abs(x) <= 10**15][:4000]
    if len(A) < 2:
        A = [1, 2]
    return A
# EVOLVE-BLOCK-END
