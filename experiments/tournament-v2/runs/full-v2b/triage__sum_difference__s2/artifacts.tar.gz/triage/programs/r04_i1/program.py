import math
import itertools
import random
import time

def solve():
    """
    Construct A as all integers whose balanced ternary representation has exactly k 
    nonzero digits (from {-1, 1}), with a maximum length L.
    
    This fixed-weight constraint keeps sum set small (sums have at most 2k nonzero digits,
    often less due to cancellations) while differences can produce a wider range
    of Hamming weights, giving a larger difference set.
    """
    def score_func(A):
        a_set = set(A)
        if len(a_set) < 2:
            return 0.0
        diffs = {x - y for x in a_set for y in a_set}
        sums = {x + y for x in a_set for y in a_set}
        if len(sums) == 0:
            return 0.0
        return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a_set)) / 100

    best_score = 0
    best_set = []

    # Generate all numbers with exactly k nonzero balanced ternary digits of length L
    # Balanced ternary digits: -1, 0, 1. We use base 3, powers 3^i.
    # To stay within 4000 elements, we need to limit combinations.
    
    # Strategy: use combinatorial generation for small L and k
    # For bigger sets, we can use a hash-based approach or sample.
    
    # We'll try multiple (L, k) pairs and keep the best.
    # Also, we can consider using base 3 but with a shift to avoid symmetry?
    
    # Since time limit is 120s, we can afford to explore many combinations.
    
    def generate_weight_k_set(L, k, max_size=4000):
        """Generate all numbers with exactly k nonzero balanced ternary digits of length L."""
        # If C(L, k) * 2^k is too large, we subsample to max_size.
        from math import comb
        num_combos = comb(L, k) * (2 ** k)
        if num_combos == 0:
            return []
        if num_combos <= max_size:
            # generate all
            positions = range(L)
            result = []
            for pos_combo in itertools.combinations(positions, k):
                for signs in itertools.product([-1, 1], repeat=k):
                    val = 0
                    for p, s in zip(pos_combo, signs):
                        val += s * (3 ** p)
                    result.append(val)
            return result
        else:
            # sample randomly to get up to max_size
            positions = list(range(L))
            result = set()
            # We'll do random sampling, but ensure distinct
            while len(result) < max_size:
                pos_combo = sorted(random.sample(positions, k))
                signs = [random.choice([-1, 1]) for _ in range(k)]
                val = 0
                for p, s in zip(pos_combo, signs):
                    val += s * (3 ** p)
                result.add(val)
            return list(result)

    # Since L can't be too large because 3^L <= 1e15 => L <= log3(1e15) ~ 31.4, so L <= 31
    # But we need |A| up to 4000. For L=31, max combos is huge, we sample.
    
    # Also consider using base 3 but with digits {-1,0,1} and we restrict weight.
    # We'll optimize over L and k.
    
    # Quick evaluation loop
    start_time = time.time()
    time_limit = 110  # seconds, leave some margin
    
    # Prefer larger sets if score similar, but bonus handles that.
    
    # We'll try a grid of L and k, plus some focused search.
    candidate_params = []
    # For L up to maybe 30, but with sampling to 4000.
    for L in range(5, 32):
        # k from 1 to L, but weight near L/2 might give balanced tradeoff?
        for k in range(1, L+1):
            # estimate size: C(L,k)*2^k
            from math import comb
            est_size = comb(L, k) * (2 ** k)
            if est_size == 0:
                continue
            if est_size <= 2000:
                # we can generate full set, might be small but could score high
                candidate_params.append((L, k, est_size))
            elif est_size <= 50000:
                # we'll sample to 4000
                candidate_params.append((L, k, 4000))
            else:
                # too many to sample effectively? still could sample to 4000.
                candidate_params.append((L, k, 4000))
    
    # Sort by estimated size? We'll just iterate and keep best.
    # To avoid too many evaluations, we can prune if L too high and k too extreme.
    
    # But we'll just loop, evaluating only if time permits.
    for L, k, target_size in candidate_params:
        if time.time() - start_time > time_limit:
            break
        A = generate_weight_k_set(L, k, max_size=target_size)
        if len(A) < 2:
            continue
        score = score_func(A)
        if score > best_score:
            best_score = score
            best_set = A[:]
    
    # Additionally, try some random refinement: hill-climbing on best found set
    if best_set:
        # Use local search: try to add/remove elements that improve score
        current_set = set(best_set)
        current_score = score_func(list(current_set))
        improved = True
        iterations = 0
        while improved and iterations < 200 and time.time() - start_time < time_limit:
            improved = False
            iterations += 1
            # Try small mutations: add a random element from a larger pool?
            # Instead, we can try to remove one element and maybe add another.
            if len(current_set) > 50:
                # Try to generate candidate numbers from similar weight constraints
                # to see if we can replace an element.
                elements = list(current_set)
                for _ in range(5):  # try a few random replacements
                    i = random.randrange(len(elements))
                    removed = elements[i]
                    # generate a new number from same L,k? But we don't know original L,k.
                    # Instead, we can generate from a range of nearby weights.
                    # Better: try a random balanced ternary number with weight near k_guess
                    # We'll just try random small changes.
                    new_val = removed + random.choice([-2, -1, 1, 2])
                    if new_val not in current_set and abs(new_val) <= 1e15:
                        new_set = set(current_set)
                        new_set.remove(removed)
                        new_set.add(new_val)
                        new_score = score_func(list(new_set))
                        if new_score > current_score:
                            current_set = new_set
                            current_score = new_score
                            improved = True
                            elements = list(current_set)  # refresh
                            break  # break inner loop, continue outer
        best_set = list(current_set)
        best_score = current_score
    
    # If still not great, fallback to a strong known construction
    if best_score < 0.9:
        # Use structured set: all numbers up to 3^13 with weight <= something?
        # Actually, use balanced ternary numbers with weight exactly floor(L/2)
        # That often yields good ratio.
        for L in [14, 15, 16, 17, 18]:
            k = L // 2
            A = generate_weight_k_set(L, k, max_size=4000)
            score = score_func(A)
            if score > best_score:
                best_score = score
                best_set = A

    # Ensure we return list of ints, sorted, distinct, <=4000, |x|<=1e15
    final = sorted(set(best_set))
    if len(final) > 4000:
        # trim to first 4000
        final = final[:4000]
    return final

if __name__ == "__main__":
    res = solve()
    print(len(res))
