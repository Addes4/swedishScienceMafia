"""
Build A using iterated affine maps: start with small seeds, repeatedly apply 
x → M*x + s_j for several distinct shifts s_j. This creates a tree structure
where differences between branches are rich (due to different affine histories)
but sums remain constrained because all elements lie in a union of few affine
images of the initial set.
"""
import math
import time
from itertools import product


def solve():
    """Return a list of distinct integers A with large difference set and small sum set."""
    
    def score_set(A_set):
        """Compute score for a set."""
        A_list = list(A_set)
        n = len(A_list)
        if n < 2:
            return 0.0
        
        # Compute difference set size
        diffs = set()
        for i in range(n):
            ai = A_list[i]
            for j in range(i + 1, n):
                diff = ai - A_list[j]
                diffs.add(diff)
                diffs.add(-diff)
        # Add zero differences
        diffs.add(0)
        diff_size = len(diffs)
        
        # Compute sum set size
        sums = set()
        for i in range(n):
            ai = A_list[i]
            for j in range(i, n):
                sums.add(ai + A_list[j])
        sum_size = len(sums)
        
        if sum_size <= 1:
            return 0.0
        
        base_score = math.log(diff_size) / math.log(sum_size)
        bonus = (1.0 - 1.0 / n) / 100.0
        return base_score + bonus
    
    def compute_sets_size(A_list):
        """Compute both diff and sum set sizes efficiently."""
        n = len(A_list)
        diffs = set()
        sums = set()
        for i in range(n):
            ai = A_list[i]
            for j in range(i, n):
                aj = A_list[j]
                sums.add(ai + aj)
                diff = ai - aj
                diffs.add(diff)
                diffs.add(-diff)
        return len(diffs), len(sums)
    
    best_score = 0.0
    best_set = []
    
    start_time = time.time()
    time_limit = 115  # seconds, leave some margin
    
    # Try different parameters for the affine construction
    # Key idea: M should be relatively large compared to shifts to keep sums constrained
    # while differences between different branches create rich difference structure
    
    for M in [7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43]:
        for depth in range(5, 10):
            # Generate shifts that are small relative to M
            shifts = []
            for s in range(1, min(M, 10)):
                shifts.append(s)
                shifts.append(-s)
            shifts = list(set(shifts))
            
            if len(shifts) < 2:
                continue
            
            # Start with seeds
            seeds = [0, 1, -1, 2, -2, 3, -3]
            seeds = [s for s in seeds if abs(s) < M]
            
            current_set = set(seeds)
            prev_set = set(seeds)
            
            # Build iteratively
            for d in range(depth):
                new_vals = set()
                for val in prev_set:
                    for s in shifts:
                        new_val = M * val + s
                        if abs(new_val) <= 1e15:
                            new_vals.add(new_val)
                # Prune: keep values that are not too close together to maintain diversity
                # but not so aggressive that we lose the structure
                if len(new_vals) > 4000:
                    # Sort and sample evenly
                    sorted_vals = sorted(new_vals)
                    step = max(1, len(sorted_vals) // 4000)
                    new_vals = set(sorted_vals[::step][:4000])
                
                prev_set = new_vals
                current_set = current_set | new_vals
                
                if len(current_set) > 4000:
                    # Trim to 4000 elements while maintaining structure
                    sorted_all = sorted(current_set)
                    step = len(sorted_all) // 4000
                    current_set = set(sorted_all[::step][:4000])
                
                if len(current_set) < 10:
                    break
            
            if 10 <= len(current_set) <= 4000:
                score = score_set(current_set)
                if score > best_score:
                    best_score = score
                    best_set = sorted(current_set)
    
    # Also try combining multiple trees with different M values
    for combo_size in [1500, 2000, 2500, 3000, 3500]:
        combined = set()
        M_values = [7, 13, 19, 31, 43, 61]
        shifts_base = [1, -1, 2, -2, 3, -3]
        
        for M in M_values:
            if len(combined) >= combo_size:
                break
            
            # Build a tree with this M
            sub_set = set([0, 1, -1, 2, -2])
            prev = set([0, 1, -1])
            
            for depth_val in range(8):
                new_vals = set()
                for v in prev:
                    for s in shifts_base:
                        nv = M * v + s
                        if abs(nv) <= 1e15 and nv not in combined:
                            new_vals.add(nv)
                
                # Add to both sub_set and combined
                for nv in new_vals:
                    if len(combined) < combo_size:
                        combined.add(nv)
                        sub_set.add(nv)
                
                prev = new_vals
                if len(prev) == 0:
                    break
        
        if len(combined) > 100:
            score = score_set(combined)
            if score > best_score:
                best_score = score
                best_set = sorted(combined)
    
    # Optimization: try varying M dynamically and prune for max ratio
    for M in [10, 11, 13, 17, 19, 23]:
        for seed_set in [[0, 1, -1], [0, 1, -1, 2, -2], [0, 1, -1, 2, -2, 3, -3, 5, -5]]:
            shifts = [s for s in range(-(M//2), M//2 + 1) if s != 0 and abs(s) <= 8]
            
            A = set(seed_set)
            frontier = set(seed_set)
            
            for iteration in range(12):
                if time.time() - start_time > time_limit:
                    break
                
                next_frontier = set()
                for val in frontier:
                    for s in shifts:
                        new_val = M * val + s
                        if abs(new_val) <= 1e15 and new_val not in A:
                            # Check if adding this value improves the ratio
                            A_test = A | {new_val}
                            if len(A_test) <= 4000:
                                # Quick heuristic: value should increase diff set
                                # more than sum set
                                next_frontier.add(new_val)
                
                # Sort by how much they'd improve the score (approximate)
                if len(next_frontier) + len(A) > 4000:
                    # Keep only the best candidates
                    candidates = list(next_frontier)
                    # Prefer larger absolute values for more differences
                    candidates.sort(key=lambda x: -abs(x))
                    next_frontier = set(candidates[:4000 - len(A)])
                
                A = A | next_frontier
                frontier = next_frontier
                
                if len(A) >= 4000:
                    break
            
            if 50 <= len(A) <= 4000:
                score = score_set(A)
                if score > best_score:
                    best_score = score
                    best_set = sorted(A)
    
    # Fine-tuning: try to improve the best set with local mutations
    if len(best_set) > 0:
        for _ in range(100):
            if time.time() - start_time > time_limit:
                break
            
            A_list = list(best_set)
            n = len(A_list)
            
            # Try removing elements that might be hurting the ratio
            for i in range(min(5, n)):
                test_set = set(A_list)
                test_set.discard(A_list[i])
                if len(test_set) > 1:
                    score = score_set(test_set)
                    if score > best_score:
                        best_score = score
                        best_set = sorted(test_set)
                        A_list = best_set
            
            # Try adding new elements near existing ones
            if len(A_list) < 4000:
                existing = set(A_list)
                candidates = []
                for val in A_list:
                    for delta in range(-2, 3):
                        if delta != 0:
                            new_val = val + delta
                            if abs(new_val) <= 1e15 and new_val not in existing:
                                candidates.append(new_val)
                
                if candidates and len(candidates) > 0:
                    candidate_set = set(candidates[:50])  # limit
                    for new_val in candidate_set:
                        test_set = existing | {new_val}
                        if len(test_set) <= 4000:
                            score = score_set(test_set)
                            if score > best_score:
                                best_score = score
                                best_set = sorted(test_set)
                                existing = test_set
                                A_list = best_set
    
    return best_set
