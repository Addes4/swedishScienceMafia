import math
import random
import time

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    random.seed(0)
    population_size = 20
    elite_size = 4
    max_generations = 100000
    mutation_rate = 0.3
    max_mutation = 10
    time_limit = 110
    
    def random_set(size):
        return [random.randint(-50, 50) for _ in range(size)]
    
    def tournament_select(population, scores, k=3):
        best_idx = random.randrange(len(population))
        for _ in range(k - 1):
            idx = random.randrange(len(population))
            if scores[idx] > scores[best_idx]:
                best_idx = idx
        return population[best_idx][:]
    
    def crossover(parent1, parent2):
        # Take union of half elements from each parent, with some randomness
        combined = list(set(parent1 + parent2))
        random.shuffle(combined)
        target_size = random.randint(
            max(2, min(len(parent1), len(parent2))),
            max(len(parent1), len(parent2))
        )
        if len(combined) > target_size:
            return combined[:target_size]
        else:
            return combined
    
    def mutate(individual):
        if len(individual) == 0:
            return individual[:]
        mutated = individual[:]
        # Mutate values
        for i in range(len(mutated)):
            if random.random() < mutation_rate:
                mutated[i] += random.randint(-max_mutation, max_mutation)
        # Add/remove elements
        if random.random() < 0.1:
            mutated.append(random.randint(-100, 100))
        if random.random() < 0.05 and len(mutated) > 3:
            idx = random.randrange(len(mutated))
            mutated.pop(idx)
        return mutated
    
    # Initialize population with variety
    population = []
    for _ in range(population_size):
        size = random.randint(5, 25)
        population.append(random_set(size))
    
    best_solution = population[0][:]
    best_score = _score(best_solution)
    
    start_time = time.time()
    generation = 0
    
    while time.time() - start_time < time_limit:
        # Evaluate population
        scores = [_score(ind) for ind in population]
        
        # Update best
        for ind, score in zip(population, scores):
            if score > best_score:
                best_score = score
                best_solution = ind[:]
        
        # Elitism: keep best individuals
        elite_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:elite_size]
        new_population = [population[i][:] for i in elite_indices]
        
        # Generate offspring
        while len(new_population) < population_size:
            parent1 = tournament_select(population, scores, k=3)
            parent2 = tournament_select(population, scores, k=3)
            child = crossover(parent1, parent2)
            child = mutate(child)
            new_population.append(child)
        
        population = new_population
        
        # Periodic injection of fresh random individuals to maintain diversity
        if generation % 20 == 0 and generation > 0:
            for i in range(2):
                if len(population) > 0:
                    idx = random.randrange(len(population))
                    size = random.randint(5, 30)
                    population[idx] = random_set(size)
        
        generation += 1
    
    return sorted(set(best_solution))
