# Research notebook: sum_difference

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.887449.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Use number-theoretic constructions such as generalized arithmetic progressions: take A = {∑_{i=1}^d k_i * g_i : 0 ≤ k_i < n_i} for carefully chosen generators g | 0.70 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 1 | Perform global discrete optimization via simulated annealing: start from a random set of moderate size, then repeatedly perturb by adding/removing elements or s | 0.55 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.887449 |
| 4 | Hybrid genetic algorithm with crossover: maintain a population of candidate sets, select parents by score, generate offspring by taking unions/intersections of  | 0.53 | middle | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | not_better | 0.887449 |
| 5 | Brute-force over small moduli then lift: search for an optimal set modulo m (say m up to 30-50) that maximizes the ratio of /A-A/ to /A+A/ locally, then lift to | 0.52 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.886624 |
| 3 | Use a signed-digit representation: build A as all integers whose balanced ternary (or base-B with digits in [-d, d]) expansion has bounded length and digit sum  | 0.51 | long_shot | Qwen/Qwen3.5-9B:together | improved | 0.904849 |
| 2 | Exploit Sidon sets or B2 sequences: construct or locally search for sets where all pairwise sums are distinct (so /A+A/ is maximal for its size), then scale and | 0.12 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.879571 |

Promotion: Qwen/Qwen3.5-9B:together found an improvement; deepseek-ai/DeepSeek-V4-Pro:deepinfra refined it -> invalid (0.000000).

Best after round 1: **0.904849** (spent $0.03)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Use random subsets of a structured "base set" known to have good ratio (like the balanced ternary set) and apply iterative local search that greedily adds the s | 0.33 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.822491 |
| 3 | Take two disjoint arithmetic progressions with the same difference but staggered start points, e.g. A = {a + k·d : 0 ≤ k < N} ∪ {b + k·d : 0 ≤ k < N} where b -  | 0.28 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 5 | Generate A by taking all subset sums of a carefully chosen basis {g_1, ..., g_k} where each g_i is roughly double the previous, except occasionally inserting a  | 0.17 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.788102 |
| 4 | Construct A as the set of all numbers of the form f(x) = x^2 mod p for x in some range, lifted to integers by adding large multiples of p; the quadratic structu | 0.13 | middle | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | invalid | 0.000000 |
| 0 | Construct A as a union of a few geometric progressions with distinct ratios, e.g. A = {⌊α^i⌋} ∪ {⌊β^j⌋}, choosing α, β close to 1 so that sums mostly overlap bu | 0.12 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 2 | Build A from a short interval of integers [M, M+L] but delete a carefully chosen subset to break additive structure more than subtractive structure, for instanc | 0.09 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 2: **0.904849** (spent $0.06)

## Round 3

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Build A as iterated application of an affine map to seeds: start with a few small integers, repeatedly apply x → M*x + s_j for several distinct shifts s_j, but  | 0.31 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 0 | Construct A as the image of a multivariate linear form evaluated over a high-dimensional lattice box, like A = {∑ c_i x_i : x_i in [-k_i, k_i] integers} where c | 0.30 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.790103 |
| 1 | Use a set of the form A = { a_t = floor(C * φ^t) : t = 1…N } where φ is a Pisot number (like the golden ratio) and C is a large scaling factor; Pisot powers are | 0.15 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.867844 |
| 5 | Construct A as the set of discriminants or invariants of quadratic forms (or similar algebraic objects) that have many automorphisms; for instance, take all int | 0.11 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 2 | Generate A by taking all products (or sums) of a fixed set of small primes raised to constrained heights, e.g., A = { 3^a * 5^b : 0≤a,b≤N } for suitable N; the  | 0.09 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 3 | Employ random subset selection from a huge precomputed candidate pool that has good modular sum-difference profile: generate all integers in [−L,L] whose binary | 0.08 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 3: **0.904849** (spent $0.09)

## Round 4

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Build A using a convolutional sparse code: start with a short seed set S, then define A = { sum_{t=0}^{T-1} c_t * B^t : c_t in S } for a large base B, but where | 0.35 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.884995 |
| 1 | Construct A as all integers n ≤ X whose balanced ternary representation has exactly k nonzero digits (fixed Hamming weight in signed digits), for carefully chos | 0.22 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 3 | Take A as the union of several disjoint arithmetic progressions with the same difference d but lengths forming a Sidon set themselves, i.e., A = U_i { s_i + k*d | 0.22 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.839557 |
| 2 | Employ a "quotient set" trick: let A be the image of a large subset of a finite field F_p under a rational function f(x) = (ax+b)/(cx+d), for many distinct Möbi | 0.04 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 5 | Use a randomized algebraic construction: let A be the set of integer values taken by evaluating a sparse polynomial P(x) = sum c_j x^{e_j} mod q over many rando | 0.03 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 0 | Use a structured lattice set A = { a + b*sqrt(2) : a,b in [-N,N] integers } mapped to integers via a very fine rational approximation of sqrt(2) (e.g., floor(M  | -0.01 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.796858 |

Best after round 4: **0.904849** (spent $0.12)

## Round 5

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 5 | Construct A as the set of all integers n in [0, X] for which the sum of digits of n in base b1 equals the sum of digits of n in base b2, for two multiplicativel | 0.17 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.885065 |
| 4 | Adopt a "product of small sets" in different bases: let S and T be small sets of integers with excellent individual difference-to-sum ratios, then define A = {  | 0.16 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | api_error |  |
| 2 | Use a "tilted lattice" construction: A = { (x·u + y·v) mod L : 0 ≤ x,y < N } where u,v are large coprime integers and L is chosen so that the mod operation crea | -0.01 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | api_error |  |
| 1 | Build A by taking all integers of the form floor(R * (a/b)) where a,b are from a dense Sidon set S in [1,M] and R is a huge scaling factor; the Sidon property o | -0.01 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.870744 |
| 3 | Construct A as the set of values of a random function f from a large domain D to integers, where f is built to have many "difference certificates" (pairs (x,y)  | -0.03 | long_shot | Qwen/Qwen3.5-9B:together | api_error |  |
| 0 | Construct A as a union of a few carefully spaced short geometric progressions in different bases, e.g. {⌊c_1·α_1^k⌋} ∪ {⌊c_2·α_2^k⌋} ∪ …, where the ratios α_i a | -0.14 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 5: **0.904849** (spent $0.14)

