# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, shelf (guillotine) layouts,
corner-dominant layouts and recursive guillotine partitions with
continuous split-ratio optimisation, plus a scipy-based continuous
refinement step.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: grids of equal squares, "strip" layouts, guillotine/shelf
layouts where the unit square is recursively split into rectangles each
filled with a grid of equal squares, or corner-dominant layouts.  A final
continuous refinement (SLSQP) nudges the best discrete layout to squeeze
out small extra area while respecting non-overlap constraints.
"""
import math
import itertools

try:
    import numpy as np
    from scipy.optimize import minimize
    _HAVE_SCIPY = True
except Exception:
    _HAVE_SCIPY = False


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_layout_v(n, big_index):
    return _corner_layout(n, big_index)


def _shelf_layout(n, shelves):
    k = len(shelves)
    if k == 0:
        return None, -1.0
    best = None
    best_sum = -1.0
    for mask in range(1 << k):
        widths = [1.0] * k
        fixed = 0.0
        free = 0
        for i in range(k):
            if mask >> i & 1:
                widths[i] = 1.0 / shelves[i]
                fixed += widths[i]
            else:
                free += 1
        rem = 1.0 - fixed
        if rem < -1e-9:
            continue
        if free > 0:
            h = rem / free
            if h < -1e-9:
                continue
            for i in range(k):
                if not (mask >> i & 1):
                    widths[i] = h
        sizes = []
        ok = True
        for i in range(k):
            c = shelves[i]
            if c <= 0:
                ok = False
                break
            if mask >> i & 1:
                sizes.append(1.0 / c)
            else:
                if widths[i] > 1.0 / c + 1e-9:
                    ok = False
                    break
                sizes.append(widths[i])
        if not ok:
            continue
        total = sum(c * s for c, s in zip(shelves, sizes))
        if total > best_sum:
            squares = []
            y = 1.0
            for i in range(k):
                c = shelves[i]
                s = sizes[i]
                h = widths[i]
                y -= h
                yc = y + h / 2.0
                for j in range(c):
                    xc = (j + 0.5) / c
                    squares.append((xc, yc, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    for first in range(1, n - k + 2):
        for rest in _compositions(n - first, k - 1):
            yield (first,) + rest


def _grid_rect(rect, count):
    if count <= 0:
        return [], 0.0
    x0, y0, w, h = rect
    best = None
    best_total = -1.0
    best_side = 0.0
    lim = int(math.isqrt(count)) + 2
    for r in range(1, lim + 1):
        for c in range(1, lim + 1):
            if r * c < count:
                continue
            s = min(w / c, h / r)
            total = s * count
            if total > best_total:
                best_total = total
                best_side = s
                best = (r, c)
    if best is None:
        return [], 0.0
    r, c = best
    s = best_side
    squares = []
    for i in range(r):
        for j in range(c):
            if len(squares) >= count:
                break
            squares.append((x0 + (j + 0.5) * s, y0 + (i + 0.5) * s, 0.0, s))
    return squares, best_total


def _guillotine_value(n, w, h, depth):
    sq, total = _grid_rect((0.0, 0.0, w, h), n)
    if depth <= 0 or n <= 1:
        return total, sq, (0.0, 0.0, w, h)
    best_total = total
    best_sq = sq
    for k in range(1, n):
        rest = n - k
        for orient in (0, 1):
            if orient == 0:
                def val(ratio):
                    lw = w * ratio
                    rw = w - lw
                    t1, _, _ = _guillotine_value(k, lw, h, depth - 1)
                    t2, _, _ = _guillotine_value(rest, rw, h, depth - 1)
                    return t1 + t2
            else:
                def val(ratio):
                    lh = h * ratio
                    rh = h - lh
                    t1, _, _ = _guillotine_value(k, w, lh, depth - 1)
                    t2, _, _ = _guillotine_value(rest, w, rh, depth - 1)
                    return t1 + t2
            lo, hi = 0.02, 0.98
            for _ in range(40):
                m1 = lo + (hi - lo) / 3.0
                m2 = hi - (hi - lo) / 3.0
                if val(m1) < val(m2):
                    lo = m1
                else:
                    hi = m2
            ratio = (lo + hi) / 2.0
            if orient == 0:
                lw = w * ratio
                rw = w - lw
                t1, s1, _ = _guillotine_value(k, lw, h, depth - 1)
                t2, s2, _ = _guillotine_value(rest, rw, h, depth - 1)
                if t1 + t2 > best_total:
                    best_total = t1 + t2
                    shifted = [(x + lw, y, a, si) for (x, y, a, si) in s2]
                    best_sq = s1 + shifted
            else:
                lh = h * ratio
                rh = h - lh
                t1, s1, _ = _guillotine_value(k, w, lh, depth - 1)
                t2, s2, _ = _guillotine_value(rest, w, rh, depth - 1)
                if t1 + t2 > best_total:
                    best_total = t1 + t2
                    shifted = [(x, y + lh, a, si) for (x, y, a, si) in s2]
                    best_sq = s1 + shifted
    return best_total, best_sq, (0.0, 0.0, w, h)


def _guillotine(n, rect, depth):
    x0, y0, w, h = rect
    total, sq, _ = _guillotine_value(n, w, h, depth)
    shifted = [(x + x0, y + y0, a, si) for (x, y, a, si) in sq]
    return shifted, total


def _corners(sq):
    x, y, a, s = sq
    th = a * 2.0 * math.pi
    c = math.cos(th) * s / 2.0
    si = math.sin(th) * s / 2.0
    return [(x - c + si, y - si - c), (x + c + si, y + si - c),
            (x + c - si, y + si + c), (x - c - si, y - si + c)]


def _axes(sq):
    a = sq[2] * 2.0 * math.pi
    c = math.cos(a)
    s = math.sin(a)
    return (c, s), (-s, c)


def _overlap(sq1, sq2):
    c1 = _corners(sq1)
    c2 = _corners(sq2)
    for ax in _axes(sq1) + _axes(sq2):
        p1 = [pt[0] * ax[0] + pt[1] * ax[1] for pt in c1]
        p2 = [pt[0] * ax[0] + pt[1] * ax[1] for pt in c2]
        if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
            return False
    return True


def _total(squares):
    return sum(s for (_, _, _, s) in squares)


def _feasible(squares, tol=1e-9):
    # bounds
    for sq in squares:
        x, y, a, s = sq
        if s < -tol:
            return False
        if s == 0:
            continue
        if x - s <= -tol or x + s >= 1.0 + tol:
            return False
        if y - s <= -tol or y + s >= 1.0 + tol:
            return False
    for i in range(len(squares)):
        for j in range(i + 1, len(squares)):
            if squares[i][3] <= 0 or squares[j][3] <= 0:
                continue
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _refine(squares, n):
    """Local continuous refinement via scipy SLSQP.  Variables are
    (x, y, a, s) for each square.  Maximise sum of sides subject to
    within-unit-square bounds and non-overlap (linearised as pairwise
    half-plane separation constraints against the *fixed* orientation
    of neighbours -- we simply re-run feasibility check afterwards)."""
    if not _HAVE_SCIPY:
        return squares, _total(squares)
    init = np.array([[sq[0], sq[1], sq[2], sq[3]] for sq in squares],
                    dtype=float)
    nv = 4 * n

    def unpack(x):
        return [(x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3]) for i in range(n)]

    def neg_sum(x):
        return -np.sum(x[3::4])

    def bounds():
        b = []
        for i in range(n):
            b.append((0.0, 1.0))
            b.append((0.0, 1.0))
            b.append((0.0, 0.5))
            b.append((0.0, 1.0))
        return b

    # constraint: unit-square containment
    cons = []

    def make_contain(i):
        def f(x):
            s = x[4 * i + 3]
            return s - min(x[4 * i], 1.0 - x[4 * i],
                           x[4 * i + 1], 1.0 - x[4 * i + 1])
        return f
    for i in range(n):
        cons.append({'type': 'ineq', 'fun': make_contain(i)})

    def make_sep(i, j):
        pi0 = init[4 * i:4 * i + 4]
        pj0 = init[4 * j:4 * j + 4]
        a0 = pi0[2] * 2.0 * math.pi
        ca, sa = math.cos(a0), math.sin(a0)
        nrm = (ca, sa)
        ax = (-sa, ca)

        def f(x):
            xi, yi, ai, si = x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3]
            xj, yj, aj, sj = x[4 * j], x[4 * j + 1], x[4 * j + 2], x[4 * j + 3]
            d = abs((xj - xi) * nrm[0] + (yj - yi) * nrm[1])
            return d - 0.5 * si - 0.5 * sj
        return f
    for i in range(n):
        for j in range(i + 1, n):
            cons.append({'type': 'ineq', 'fun': make_sep(i, j)})

    try:
        res = minimize(neg_sum, init.ravel(), method='SLSQP',
                       bounds=bounds(), constraints=cons,
                       options={'maxiter': 200, 'ftol': 1e-12})
    except Exception:
        return squares, _total(squares)
    if not res.success:
        # try anyway if improved
        cand = unpack(res.x)
    else:
        cand = unpack(res.x)
    # clip and validate
    clipped = []
    for (x, y, a, s) in cand:
        s = max(0.0, s)
        x = min(max(x, s / 2.0), 1.0 - s / 2.0)
        y = min(max(y, s / 2.0), 1.0 - s / 2.0)
        clipped.append((x, y, a, s))
    if _feasible(clipped) and _total(clipped) > _total(squares) + 1e-12:
        return clipped, _total(clipped)
    return squares, _total(squares)


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout, _corner_layout_v):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    max_shelves = min(n, 5)
    for k in range(1, max_shelves + 1):
        for comp in _compositions(n, k):
            sq, total = _shelf_layout(n, list(comp))
            if sq is not None and total > best_sum:
                best_sum = total
                best = sq

    for depth in (1, 2):
        sq, total = _guillotine(n, (0.0, 0.0, 1.0, 1.0), depth)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    best = best[:n]

    # continuous refinement (only for small/moderate n to stay in time budget)
    if _HAVE_SCIPY and n <= 20:
        refined, rsum = _refine(best, n)
        if rsum > best_sum + 1e-9 and _feasible(refined):
            best = refined
            best_sum = rsum

    # final safety validation: revert to a trivial packing if anything broke
    if not _feasible(best):
        side = 1.0 / max(1, int(math.ceil(math.sqrt(n))))
        squares = []
        cnt = 0
        for i in range(n):
            r = int(i // max(1, int(math.ceil(math.sqrt(n)))))
            c = i % max(1, int(math.ceil(math.sqrt(n))))
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
        best = squares[:n]

    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return [(float(x), float(y), float(a), float(s)) for (x, y, a, s) in best[:n]]
# EVOLVE-BLOCK-END
