# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, corner-dominant and rotated corner layouts."""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_rotated_strips(n):
    """One big axis-aligned square in a corner (side t), plus rotated squares
    of side r placed in the two remaining corner gaps at 45 degrees.

    A square of side r rotated 45 deg has bounding box side r*sqrt2. Placed in
    a right triangle gap of legs (1-t) it can have side up to (1-t)/(1+sqrt2)*sqrt2
    i.e. the largest square in a right isoceles triangle. We simply use fixed
    rotated squares along the two strips and fill the middle with a grid.
    """
    best = None
    best_sum = -1.0
    sq2 = math.sqrt(2.0)
    m = n - 1
    # Place the big square in bottom-left corner of side t; top strip height h=1-t,
    # right strip width h. In each strip place rotated squares at 45 deg whose
    # diagonal rests on the strip; a rotated square e with axis-aligned bbox
    # width e*sq2 fits in strip of width h if we center it, e <= h/sq2.
    # We instead tile the top strip with `kt` rotated squares and right strip
    # with `kr` rotated squares, then remaining fill grid in the top-right block.
    for t100 in range(1, 100):
        t = t100 / 100.0
        h = 1.0 - t
        if h <= 1e-6:
            continue
        # rotated square in strip: bounding box must fit width h within strip
        # cell along strip of width h; squares laid in a row of width 1 (top).
        for kt in range(0, m + 1):
            kr = m - kt
            e = h / sq2
            if e <= 0:
                continue
            # total just this: t + m*e
            total = t + m * e
            if total > best_sum:
                squares = [(t / 2.0, t / 2.0, 0.0, t)]
                # top strip rotated squares
                if kt > 0:
                    step_x = 1.0 / kt
                    for j in range(kt):
                        squares.append(((j + 0.5) * step_x, t + h / 2.0, 0.125, e))
                if kr > 0:
                    step_y = t / kr
                    for i in range(kr):
                        squares.append((t + h / 2.0, (i + 0.5) * step_y, 0.125, e))
                while len(squares) < n:
                    squares.append((0.5, 0.5, 0.0, 0.0))
                best_sum = total
                best = squares[:n]
    return best, best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    sq, total = _corner_layout(n, 0)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    sq, total = _corner_rotated_strips(n)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    return best
# EVOLVE-BLOCK-END
