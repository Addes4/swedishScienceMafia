# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips and corner-dominant layouts.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: either a grid of equal squares whose count exceeds n, or a
"strip" layout where one row/column contains fewer, larger squares that
stretch into the leftover region, or a corner-dominant layout with one big
square plus a grid filling the remaining L-shaped region.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    """rows x cols grid, but the last column holds 'extra' larger squares."""
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    """rows x cols grid, last row has fewer, larger squares in leftover height."""
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout_v(n, big_index):
    """Big square in bottom-left, side t; remaining L-region filled with a
    uniform grid of side s chosen to maximize t + m s."""
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s_max = 1.0
        if kr > 0:
            s_max = min(s_max, 1.0 / (kr + 1))
        if kt > 0:
            s_max = min(s_max, 1.0 / kt)
        s_max = min(s_max, 0.5)
        if s_max <= 0:
            continue
        s = s_max
        t = 1.0 - s
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_rect_layout(n):
    """Big square side t in bottom-left corner. Remaining L-shaped region:
    top strip [0,1]x[t,1] (height 1-t) and right strip [t,1]x[0,t] (width 1-t).
    Fill top strip with an r x c grid (c columns, r rows) of equal side s,
    and right strip with a single column of kr squares also of side s.
    Maximize t + (r*c + kr)*s over integer dims and continuous s,t.
    Constraints:
      top:    c*s <= 1,  r*s <= 1-t
      right:  s <= 1-t,  kr*s <= t
    With t = 1-s (push t as large as possible given top height 1-t>=s):
      right: s<=1-t trivial, kr*s <= 1-s -> s <= 1/(kr+1)
      top:   c*s<=1 -> s<=1/c
    total = (1-s) + (rc+kr)*s = 1 + (rc+kr-1)*s, maximized by largest s.
    """
    best = None
    best_sum = -1.0
    for c in range(1, n + 2):
        for r in range(1, n + 2):
            top_cells = r * c
            if top_cells > n - 1 + n // 1:
                # allow overshoot but need kr>=0; kr = n-1-top_cells
                pass
            kr = n - 1 - top_cells
            if kr < 0:
                continue
            s = 1.0
            if c > 0:
                s = min(s, 1.0 / c)
            if kr > 0:
                s = min(s, 1.0 / (kr + 1))
            s = min(s, 0.5)
            if s <= 0:
                continue
            t = 1.0 - s
            if t <= 0:
                continue
            # verify feasibility
            if c * s > 1.0 + 1e-9 or r * s > (1.0 - t) + 1e-9:
                continue
            if kr > 0 and kr * s > t + 1e-9:
                continue
            total = t + (top_cells + kr) * s
            if total > best_sum:
                squares = [(t / 2.0, t / 2.0, 0.0, t)]
                for i in range(r):
                    for j in range(c):
                        squares.append(((j + 0.5) * s, t + (i + 0.5) * s, 0.0, s))
                for y in _centered_positions(kr, t):
                    squares.append((t + s / 2.0, y, 0.0, s))
                best_sum = total
                best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_rect_layout2(n):
    """Top strip holds r rows x c cols grid of side s; right strip holds a
    column of kr squares of side s2 possibly different, with t chosen
    optimally. Generalize: right column squares size s2, top grid size s1.
    Constraints:
      s1 <= 1/c, r*s1 <= 1-t
      s2 <= 1-t, kr*s2 <= t
    total = t + r*c*s1 + kr*s2.
    For fixed t, choose s1 = min(1/c, (1-t)/r), s2 = min(1-t, t/kr).
    Search t over a grid.
    """
    best = None
    best_sum = -1.0
    for c in range(1, n + 2):
        for r in range(1, n + 2):
            top_cells = r * c
            kr = n - 1 - top_cells
            if kr < 0:
                continue
            for ti in range(1, 200):
                t = ti / 200.0
                s1 = min(1.0 / c, (1.0 - t) / r)
                if kr > 0:
                    s2 = min(1.0 - t, t / kr)
                else:
                    s2 = 0.0
                if s1 <= 0:
                    continue
                total = t + top_cells * s1 + kr * s2
                if total > best_sum:
                    squares = [(t / 2.0, t / 2.0, 0.0, t)]
                    for i in range(r):
                        for j in range(c):
                            squares.append(
                                ((j + 0.5) * s1, t + (i + 0.5) * s1, 0.0, s1))
                    for y in _centered_positions(kr, t):
                        squares.append((t + s2 / 2.0, y, 0.0, s2))
                    best_sum = total
                    best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    sq, total = _corner_layout_v(n, 0)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    sq, total = _corner_rect_layout(n)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    sq, total = _corner_rect_layout2(n)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    return best
# EVOLVE-BLOCK-END
