# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips and corner-dominant layouts.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: either a grid of equal squares whose count exceeds n, or a
"strip" layout where one row/column contains fewer, larger squares that
stretch into the leftover region, or a corner-dominant layout with one big
square plus a grid filling the remaining L-shaped region.  Additionally we
try slightly rotated strip squares and a fine continuous tuning of the
corner layout to gain a little extra area.
"""
import math


def _overlap_ok(squares, eps=1e-9):
    """Check bounds and pairwise non-overlap. Returns True if valid."""
    polys = []
    for (cx, cy, ang, s) in squares:
        if s <= 0:
            continue
        if s > 1 + eps or cx < -eps or cx > 1 + eps or cy < -eps or cy > 1 + eps:
            return False
        # corners
        th = ang * 2 * math.pi
        c, sn = math.cos(th), math.sin(th)
        h = s / 2.0
        pts = []
        for (dx, dy) in ((-h, -h), (h, -h), (h, h), (-h, h)):
            pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
            # bounds
        for (px, py) in pts:
            if px < -1e-7 or px > 1 + 1e-7 or py < -1e-7 or py > 1 + 1e-7:
                return False
        polys.append(pts)
    m = len(polys)
    for i in range(m):
        for j in range(i + 1, m):
            if _sat_overlap(polys[i], polys[j]):
                return False
    return True


def _sat_overlap(A, B):
    """Separating Axis Theorem overlap test for two convex polygons."""
    for poly in (A, B):
        n = len(poly)
        for k in range(n):
            x1, y1 = poly[k]
            x2, y2 = poly[(k + 1) % n]
            ax, ay = -(y2 - y1), (x2 - x1)
            # project both
            amin = bmin = float('inf')
            amax = bmax = float('-inf')
            for (x, y) in A:
                p = x * ax + y * ay
                if p < amin: amin = p
                if p > amax: amax = p
            for (x, y) in B:
                p = x * ax + y * ay
                if p < bmin: bmin = p
                if p > bmax: bmax = p
            if amax <= bmin + 1e-9 or bmax <= amin + 1e-9:
                return False
    return True


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout_general(n):
    """Big square in bottom-left, side t; remaining L-region filled with
    kr squares of size a in the right column and kt squares of size b in the
    top row, sizes independent. Maximize t + kr*a + kt*b.
    """
    m = n - 1
    best = None
    best_sum = -1.0
    # Sweep t; for each t the right column has width (1-t), height t, so it can
    # hold kr squares if kr*a <= t and a <= 1-t. Top row has height (1-t),
    # width 1: kt*b <= 1 and b <= 1-t.
    # To maximize we set a = min((1-t), t/kr), b = min((1-t), 1/kt).
    ts = [i / 400.0 for i in range(1, 400)]
    for kr in range(0, m + 1):
        kt = m - kr
        for t in ts:
            rem = 1.0 - t
            a = rem
            if kr > 0:
                a = min(a, t / kr)
            b = rem
            if kt > 0:
                b = min(b, 1.0 / kt)
            if kr > 0 and a <= 0:
                continue
            if kt > 0 and b <= 0:
                continue
            total = t + kr * a + kt * b
            if total > best_sum:
                squares = [(t / 2.0, t / 2.0, 0.0, t)]
                # right column
                for y in ([(i + 0.5) * t / kr for i in range(kr)] if kr > 0 else []):
                    squares.append((t + a / 2.0, y, 0.0, a))
                if kr > 0:
                    # center the stack vertically
                    squares[1:1 + kr] = [
                        (t + a / 2.0, y, 0.0, a)
                        for y in _centered_positions(kr, t)
                    ]
                # top row
                if kt > 0:
                    for x in _centered_positions(kt, 1.0):
                        squares.append((x, t + b / 2.0, 0.0, b))
                # verify
                if len(squares) == n and _overlap_ok(squares):
                    best_sum = total
                    best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_rotated(n):
    """Big square in bottom-left plus strips, where the strip squares are
    slightly rotated to use diagonal clearance.  We try small angles and
    validate non-overlap, keeping the best feasible total.
    """
    m = n - 1
    best = None
    best_sum = -1.0
    angles = [0.0, 0.02, -0.02, 0.05, -0.05, 0.125, -0.125]
    for kr in range(0, m + 1):
        kt = m - kr
        for t in [i / 200.0 for i in range(1, 200)]:
            rem = 1.0 - t
            # allow strip squares slightly bigger by using diagonal clearance
            for ang in angles:
                # bounding box of rotated square side s at angle ang
                c = abs(math.cos(ang * 2 * math.pi)) + abs(math.sin(ang * 2 * math.pi))
                a = rem / c
                if kr > 0:
                    a = min(a, t / c / kr if kr else a)
                b = rem / c
                if kt > 0:
                    b = min(b, 1.0 / c / kt)
                if (kr > 0 and a <= 0) or (kt > 0 and b <= 0):
                    continue
                total = t + kr * a + kt * b
                if total <= best_sum:
                    continue
                squares = [(t / 2.0, t / 2.0, 0.0, t)]
                if kr > 0:
                    for y in _centered_positions(kr, t):
                        squares.append((t + a / 2.0, y, ang, a))
                if kt > 0:
                    for x in _centered_positions(kt, 1.0):
                        squares.append((x, t + b / 2.0, ang, b))
                if len(squares) == n and _overlap_ok(squares):
                    best_sum = total
                    best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout_general, _corner_rotated):
        sq, total = fn(n)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    return best
# EVOLVE-BLOCK-END
