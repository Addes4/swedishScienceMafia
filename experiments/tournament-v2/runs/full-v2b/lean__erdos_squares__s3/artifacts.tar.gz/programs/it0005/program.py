# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips and corner-dominant layouts.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: either a grid of equal squares whose count exceeds n, or a
"strip" layout where one row/column contains fewer, larger squares that
stretch into the leftover region, or a corner-dominant layout with one big
square plus a grid filling the remaining L-shaped region.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    """rows x cols grid, but the last column holds 'extra' larger squares."""
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    """rows x cols grid, last row has fewer, larger squares in leftover height."""
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _corner_layout(n, big_index):
    """One big square of side t in the bottom-left corner; the remaining
    L-shaped region (top strip height 1-t, right strip width 1-t) is filled
    with equal squares of side s forming a grid.

    Big square occupies [0,t]x[0,t]. The L-region can be tiled by:
      - right strip: width (1-t), height t -> a column of squares
      - top strip:  width 1,   height (1-t) -> a row of squares
    We grid these uniformly with side s given the counts, then choose t,s.
    """
    m = n - 1
    best = None
    best_sum = -1.0
    # try all splits of m squares between right column (kr) and top row (kt)
    for kr in range(0, m + 1):
        kt = m - kr
        # right strip is width (1-t), height t, kr squares stacked: need
        #   s <= (1-t) and kr*s <= t
        # top strip is width 1, height (1-t), kt squares: s <= (1-t), kt*s <= 1
        # combine: s <= min(1-t, t/kr if kr else inf, (1-t), 1/kt if kt else inf)
        # choose s = min over the following given t
        # We parametrize by s and require t >= kr*s and 1-t >= s and kt*s<=1
        #   -> t >= kr*s  and t <= 1-s
        # feasible iff kr*s <= 1-s  -> s <= 1/(kr+1)  (when kr>0)
        # also t >= s (big square not smaller than the rest? allow any)
        # maximize total = t + m*s  s.t. t = 1-s (push t up) when kr>0 else t=?
        # With t = 1 - s: need kr*s <= t = 1-s -> s <= 1/(kr+1)
        #   and kt*s <= 1 -> s <= 1/kt
        #   and big square must fit: t <= 1 (true), and t >= s: 1-s>=s -> s<=0.5
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        # safety: big square must not overlap; also t>=kr*s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            # right strip: x in [t,1], width 1-t=s, stack kr squares in height t
            for i in range(kr):
                squares.append((t + s / 2.0, (i + 0.5) * t / max(kr, 1), 0.0, s))
            # top strip: y in [t,1], height 1-t=s, place kt squares across width 1
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            # fix right strip vertical spacing to t/kr<=? use s spacing centered
            if kr > 0:
                squares[1:1 + kr] = [
                    (t + s / 2.0, y, 0.0, s)
                    for y in _centered_positions(kr, t)
                ]
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [ (i + 0.5) * step for i in range(k) ]


def _corner_layout_v(n, big_index):
    """Big square in bottom-left, side t; remaining L-region filled with a
    uniform grid of side s chosen to maximize t + m s. Here we let the right
    column have kr squares and top row kt squares, but instead of forcing
    t=1-s we search over s finely and set t=1-s as the aggressive bound."""
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        lo, hi = 1e-6, 1.0
        # t as function of s: t = 1 - s is maximal t while top strip height 1-t=s
        # but constraint kr*s <= t. We want to solve directly.
        # Constraints: s <= 1-t, kr*s <= t (if kr>0), kt*s <= 1 (if kt>0)
        # Maximize f(s) = t + m*s where t = min(1, ...). Since we want t large,
        # set t = 1 - s (top strip exactly full). Then kr*s <= 1-s.
        s_max = 1.0
        if kr > 0:
            s_max = min(s_max, 1.0 / (kr + 1))
        if kt > 0:
            s_max = min(s_max, 1.0 / kt)
        s_max = min(s_max, 0.5)
        if s_max <= 0:
            continue
        s = s_max
        t = 1.0 - s
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout, _corner_layout_v):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    return best
# EVOLVE-BLOCK-END

