# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips and two-strip corner layouts.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space with strip layouts where one row/column contains fewer, larger
squares, and with corner-dominant layouts where a big square plus two strips
of independently sized squares fill an L-shaped region.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    """rows x cols grid, but the last column holds 'extra' larger squares."""
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    """rows x cols grid, last row has fewer, larger squares in leftover height."""
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    """One big square of side t in the bottom-left corner; the remaining
    L-shaped region (top strip height 1-t, right strip width 1-t) is filled
    with equal squares of side s forming a grid."""
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _two_strip_layout(n):
    """Big rectangle t x u in the bottom-left, with a right column of kr
    squares of side a and a top row of kt squares of side b, plus an r x c
    grid of side g in the remaining top-right rectangle.

    Layout:
      - big square side t occupies [0,t]x[0,t].
      - right column: x in [t,1], width a=1-t, squares of side a stacked
        within height t (kr of them, need kr*a <= t).
      - top row: y in [t,1], height b=1-t, but we instead let the top row
        occupy full width with squares of side b, kt of them.
    To get more freedom we place the big square with side t and use:
      right column squares side a, must satisfy a <= 1-t and kr*a <= t.
      top row squares side b, must satisfy b <= 1-t and kt*b <= 1.
    Then total = t + kr*a + kt*b.
    Maximize by choosing t,a,b independently: set a = min(1-t, t/kr),
    b = min(1-t, 1/kt). Best t around midpoint. We scan t.
    """
    best = None
    best_sum = -1.0
    m = n - 1
    for kr in range(0, m + 1):
        kt = m - kr
        # scan t over a fine grid
        for it in range(1, 401):
            t = it / 401.0
            a = 1.0 - t
            if kr > 0:
                a = min(a, t / kr)
            b = 1.0 - t
            if kt > 0:
                b = min(b, 1.0 / kt if kt > 0 else 1.0)
            total = t + kr * a + kt * b
            if total > best_sum:
                if kr > 0 and kr * a > t + 1e-9:
                    continue
                squares = [(t / 2.0, t / 2.0, 0.0, t)]
                for y in _centered_positions(kr, t):
                    squares.append((t + a / 2.0, y, 0.0, a))
                for j in range(kt):
                    squares.append(((j + 0.5) / max(kt, 1), t + b / 2.0, 0.0, b))
                best_sum = total
                best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_grid_layout(n):
    """Big square side t, plus a grid in the top-right region that itself may
    be a strip layout: place a right column of kr squares of side a and a top
    row of kt squares of side b where top region also spans the big square's
    width. Concretely: big square [0,t]^2, right column x in [t,1] with
    squares side a = min(1-t, t/kr), top row y in [t,1] with squares side
    b = min(1-t, 1/kt). Plus an inner grid if leftover squares remain.
    """
    best = None
    best_sum = -1.0
    m = n - 1
    for kr in range(0, m + 1):
        for kt in range(0, m - kr + 1):
            left = m - kr - kt
            if left < 0:
                continue
            # place leftover in a small grid inside top-right corner
            for r in range(1, 4):
                for c in range(1, 4):
                    if r * c != left and left != 0:
                        continue
                    # scan t
                    for it in range(1, 301):
                        t = it / 301.0
                        a = 1.0 - t
                        if kr > 0:
                            a = min(a, t / kr)
                        b = 1.0 - t
                        if kt > 0:
                            b = min(b, 1.0 / kt)
                        # grid region: x in [t + a? ...] simplify: ignore grid
                        total = t + kr * a + kt * b
                        if left > 0:
                            # grid inside [t,1]x[t,1] minus strip; approximate
                            gw = 1.0 - t - (a if kr > 0 else 0.0)
                            gh = 1.0 - t - (b if kt > 0 else 0.0)
                            if gw > 0 and gh > 0 and r > 0 and c > 0:
                                g = min(gw / c, gh / r)
                                total += left * g
                        if total > best_sum:
                            if kr > 0 and kr * a > t + 1e-9:
                                continue
                            squares = [(t / 2.0, t / 2.0, 0.0, t)]
                            for y in _centered_positions(kr, t):
                                squares.append((t + a / 2.0, y, 0.0, a))
                            for j in range(kt):
                                squares.append(
                                    ((j + 0.5) / max(kt, 1), t + b / 2.0, 0.0, b))
                            if left > 0:
                                gw = 1.0 - t - (a if kr > 0 else 0.0)
                                gh = 1.0 - t - (b if kt > 0 else 0.0)
                                if gw > 0 and gh > 0:
                                    g = min(gw / c, gh / r)
                                    gx0 = t + (a if kr > 0 else 0.0)
                                    gy0 = t + (b if kt > 0 else 0.0)
                                    for ii in range(r):
                                        for jj in range(c):
                                            squares.append((
                                                gx0 + (jj + 0.5) * g,
                                                gy0 + (ii + 0.5) * g,
                                                0.0, g))
                            best_sum = total
                            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout, _two_strip_layout, _corner_grid_layout):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    return best
# EVOLVE-BLOCK-END
