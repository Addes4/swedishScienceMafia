# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, shelf (guillotine) layouts,
corner-dominant layouts and a recursive guillotine partition search.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: grids of equal squares, "strip" layouts, guillotine/shelf
layouts where the unit square is recursively split into rectangles each
filled with a grid of equal squares, or corner-dominant layouts. A recursive
guillotine search over splits and leaf grids generalizes all of these.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_layout_v(n, big_index):
    return _corner_layout(n, big_index)


def _shelf_layout(n, shelves):
    """Fill the unit square with horizontal shelves of given heights, each
    shelf filled by a row of equal squares whose size is min(shelf_height,
    width/count)."""
    k = len(shelves)
    if k == 0:
        return None, -1.0
    best = None
    best_sum = -1.0
    for mask in range(1 << k):
        widths = [1.0] * k
        fixed = 0.0
        free = 0
        for i in range(k):
            if mask >> i & 1:
                widths[i] = 1.0 / shelves[i]
                fixed += widths[i]
            else:
                free += 1
        rem = 1.0 - fixed
        if rem < -1e-9:
            continue
        if free > 0:
            h = rem / free
            if h < -1e-9:
                continue
            for i in range(k):
                if not (mask >> i & 1):
                    widths[i] = h
        sizes = []
        ok = True
        for i in range(k):
            c = shelves[i]
            if c <= 0:
                ok = False
                break
            if mask >> i & 1:
                sizes.append(1.0 / c)
            else:
                if widths[i] > 1.0 / c + 1e-9:
                    ok = False
                    break
                sizes.append(widths[i])
        if not ok:
            continue
        total = sum(c * s for c, s in zip(shelves, sizes))
        if total > best_sum:
            squares = []
            y = 1.0
            for i in range(k):
                c = shelves[i]
                s = sizes[i]
                h = widths[i]
                y -= h
                yc = y + h / 2.0
                for j in range(c):
                    xc = (j + 0.5) / c
                    squares.append((xc, yc, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _compositions(n, k):
    """Yield all compositions of n into k positive parts."""
    if k == 1:
        yield (n,)
        return
    for first in range(1, n - k + 2):
        for rest in _compositions(n - first, k - 1):
            yield (first,) + rest


# ---------------------------------------------------------------------------
# Recursive guillotine partition: split the unit square into rectangles, each
# leaf filled with a grid of equal squares.  Search over splits, ratios and
# leaf grids to maximize total side length.
# ---------------------------------------------------------------------------

def _best_grid_in_rect(w, h, budget):
    """Fill a w x h rectangle with a grid of equal axis-aligned squares,
    using at most `budget` squares.  Returns (total_side, rows, cols, side)
    or None if not feasible."""
    best = None
    best_total = -1.0
    lim = int(math.isqrt(budget)) + 2
    for r in range(1, lim + 1):
        for c in range(1, lim + 1):
            if r * c > budget:
                continue
            side = min(w / c, h / r)
            if side <= 0:
                continue
            total = side * r * c
            if total > best_total:
                best_total = total
                best = (total, r, c, side)
    return best


def _guillotine_best(w, h, budget, depth, memo):
    """Best total side length of filling w x h rectangle with at most
    `budget` squares using grids and recursive guillotine splits."""
    if budget <= 0:
        return None
    key = (round(w, 6), round(h, 6), budget, depth)
    if key in memo:
        return memo[key]

    best_leaves = None
    best_total = -1.0

    # Leaf: single grid
    g = _best_grid_in_rect(w, h, budget)
    if g is not None:
        total, r, c, side = g
        cells = r * c
        # Use exactly `cells` squares (<= budget); encode as a single leaf.
        best_total = total
        best_leaves = ('grid', r, c, side, cells)

    if depth > 0 and budget >= 2:
        # Try splitting vertically (into left/right) and horizontally.
        # Candidate split fractions keeping integer-ish allocation.
        cands = [i / 12.0 for i in range(1, 12)]
        for frac in cands:
            w1 = w * frac
            w2 = w - w1
            if w1 <= 1e-9 or w2 <= 1e-9:
                continue
            for b1 in range(1, budget):
                b2 = budget - b1
                left = _guillotine_best(w1, h, b1, depth - 1, memo)
                if left is None:
                    continue
                right = _guillotine_best(w2, h, b2, depth - 1, memo)
                if right is None:
                    continue
                tot = left[0] + right[0]
                if tot > best_total:
                    best_total = tot
                    best_leaves = ('vsplit', w1, left, right)

        for frac in cands:
            h1 = h * frac
            h2 = h - h1
            if h1 <= 1e-9 or h2 <= 1e-9:
                continue
            for b1 in range(1, budget):
                b2 = budget - b1
                top = _guillotine_best(w, h1, b1, depth - 1, memo)
                if top is None:
                    continue
                bot = _guillotine_best(w, h2, b2, depth - 1, memo)
                if bot is None:
                    continue
                tot = top[0] + bot[0]
                if tot > best_total:
                    best_total = tot
                    best_leaves = ('hsplit', h1, top, bot)

    if best_leaves is None:
        memo[key] = None
        return None
    res = (best_total, best_leaves)
    memo[key] = res
    return res


def _emit_guillotine(node, x0, y0, w, h, squares):
    if node is None:
        return
    kind = node[0]
    if kind == 'grid':
        _, r, c, side, _cells = node
        for i in range(r):
            for j in range(c):
                cx = x0 + (j + 0.5) * side + (w - c * side) / 2.0
                cy = y0 + (i + 0.5) * side + (h - r * side) / 2.0
                squares.append((cx, cy, 0.0, side))
    elif kind == 'vsplit':
        _, w1, left, right = node
        _emit_guillotine(left, x0, y0, w1, h, squares)
        _emit_guillotine(right, x0 + w1, y0, w - w1, h, squares)
    elif kind == 'hsplit':
        _, h1, top, bot = node
        _emit_guillotine(bot, x0, y0, w, h1, squares)
        _emit_guillotine(top, x0, y0 + h1, w, h - h1, squares)


def _recursive_guillotine(n):
    memo = {}
    res = _guillotine_best(1.0, 1.0, n, depth=2, memo=memo)
    if res is None:
        return None, -1.0
    total, node = res
    squares = []
    _emit_guillotine(node, 0.0, 0.0, 1.0, 1.0, squares)
    # If we produced fewer squares than n, pad with zero-size points.
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    # Recompute total from actual squares to be safe.
    return squares, sum(sq[3] for sq in squares)


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout, _corner_layout_v):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    max_shelves = min(n, 5)
    for k in range(1, max_shelves + 1):
        for comp in _compositions(n, k):
            sq, total = _shelf_layout(n, list(comp))
            if sq is not None and total > best_sum:
                best_sum = total
                best = sq

    # Recursive guillotine search (only for modest n to stay in time budget).
    if n <= 40:
        sq, total = _recursive_guillotine(n)
        if sq is not None and total > best_sum + 1e-9:
            best_sum = total
            best = sq

    return best
# EVOLVE-BLOCK-END
