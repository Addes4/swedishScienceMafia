# EVOLVE-BLOCK-START
"""Pack n squares as a near-square grid chosen to fit, plus zero-size extras.

For perfect squares this is optimal. For other n we try a range of grid
dimensions (rows x cols) with equal sized squares, plus we optionally split
one row/column to use the leftover space, improving on the plain isqrt grid.
"""
import math


def _equal_grid(n, rows, cols):
    """Return n squares in a rows x cols grid of equal squares (last cells zero)."""
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    # Candidate rectangular grids: r rows, c cols with r*c >= n.
    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, side = _equal_grid(n, r, c)
            total = side * n
            if total > best_sum:
                best_sum = total
                best = sq

    return best
# EVOLVE-BLOCK-END
