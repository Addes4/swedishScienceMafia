# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, shelf (guillotine) layouts,
corner-dominant layouts and recursive guillotine partitions with
continuous split-ratio optimisation, followed by a continuous
coordinate-ascent refinement that allows small shifts, resizes and
rotations of individual squares.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: grids of equal squares, "strip" layouts, guillotine/shelf
layouts where the unit square is recursively split into rectangles each
filled with a grid of equal squares, or corner-dominant layouts.  Finally
a local continuous optimiser squeezes the packing using a non-overlap
penalty and separating-axis checks.
"""
import math
import random


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_layout_v(n, big_index):
    return _corner_layout(n, big_index)


def _shelf_layout(n, shelves):
    k = len(shelves)
    if k == 0:
        return None, -1.0
    best = None
    best_sum = -1.0
    for mask in range(1 << k):
        widths = [1.0] * k
        fixed = 0.0
        free = 0
        for i in range(k):
            if mask >> i & 1:
                widths[i] = 1.0 / shelves[i]
                fixed += widths[i]
            else:
                free += 1
        rem = 1.0 - fixed
        if rem < -1e-9:
            continue
        if free > 0:
            h = rem / free
            if h < -1e-9:
                continue
            for i in range(k):
                if not (mask >> i & 1):
                    widths[i] = h
        sizes = []
        ok = True
        for i in range(k):
            c = shelves[i]
            if c <= 0:
                ok = False
                break
            if mask >> i & 1:
                sizes.append(1.0 / c)
            else:
                if widths[i] > 1.0 / c + 1e-9:
                    ok = False
                    break
                sizes.append(widths[i])
        if not ok:
            continue
        total = sum(c * s for c, s in zip(shelves, sizes))
        if total > best_sum:
            squares = []
            y = 1.0
            for i in range(k):
                c = shelves[i]
                s = sizes[i]
                h = widths[i]
                y -= h
                yc = y + h / 2.0
                for j in range(c):
                    xc = (j + 0.5) / c
                    squares.append((xc, yc, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    for first in range(1, n - k + 2):
        for rest in _compositions(n - first, k - 1):
            yield (first,) + rest


def _grid_rect(rect, count):
    if count <= 0:
        return [], 0.0
    x0, y0, w, h = rect
    best = None
    best_total = -1.0
    best_side = 0.0
    lim = int(math.isqrt(count)) + 2
    for r in range(1, lim + 1):
        for c in range(1, lim + 1):
            if r * c < count:
                continue
            s = min(w / c, h / r)
            total = s * count
            if total > best_total:
                best_total = total
                best_side = s
                best = (r, c)
    if best is None:
        return [], 0.0
    r, c = best
    s = best_side
    squares = []
    for i in range(r):
        for j in range(c):
            if len(squares) >= count:
                break
            squares.append((x0 + (j + 0.5) * s, y0 + (i + 0.5) * s, 0.0, s))
    return squares, best_total


def _guillotine_value(n, w, h, depth):
    sq, total = _grid_rect((0.0, 0.0, w, h), n)
    if depth <= 0 or n <= 1:
        return total, sq, (0.0, 0.0, w, h)
    best_total = total
    best_sq = sq
    for k in range(1, n):
        rest = n - k
        for orient in (0, 1):
            if orient == 0:
                def val(ratio):
                    lw = w * ratio
                    rw = w - lw
                    t1, _, _ = _guillotine_value(k, lw, h, depth - 1)
                    t2, _, _ = _guillotine_value(rest, rw, h, depth - 1)
                    return t1 + t2
            else:
                def val(ratio):
                    lh = h * ratio
                    rh = h - lh
                    t1, _, _ = _guillotine_value(k, w, lh, depth - 1)
                    t2, _, _ = _guillotine_value(rest, w, rh, depth - 1)
                    return t1 + t2
            lo, hi = 0.02, 0.98
            for _ in range(40):
                m1 = lo + (hi - lo) / 3.0
                m2 = hi - (hi - lo) / 3.0
                if val(m1) < val(m2):
                    lo = m1
                else:
                    hi = m2
            ratio = (lo + hi) / 2.0
            if orient == 0:
                lw = w * ratio
                rw = w - lw
                t1, s1, _ = _guillotine_value(k, lw, h, depth - 1)
                t2, s2, _ = _guillotine_value(rest, rw, h, depth - 1)
                if t1 + t2 > best_total:
                    best_total = t1 + t2
                    shifted = [(x + lw, y, a, si) for (x, y, a, si) in s2]
                    best_sq = s1 + shifted
            else:
                lh = h * ratio
                rh = h - lh
                t1, s1, _ = _guillotine_value(k, w, lh, depth - 1)
                t2, s2, _ = _guillotine_value(rest, w, rh, depth - 1)
                if t1 + t2 > best_total:
                    best_total = t1 + t2
                    shifted = [(x, y + lh, a, si) for (x, y, a, si) in s2]
                    best_sq = s1 + shifted
    return best_total, best_sq, (0.0, 0.0, w, h)


def _guillotine(n, rect, depth):
    x0, y0, w, h = rect
    total, sq, _ = _guillotine_value(n, w, h, depth)
    shifted = [(x + x0, y + y0, a, si) for (x, y, a, si) in sq]
    return shifted, total


# ---------------------------------------------------------------------------
# continuous refinement
# ---------------------------------------------------------------------------

def _corner_pts(cx, cy, ang, s):
    """Return the 4 corners of the square."""
    a = ang * 2.0 * math.pi
    ca = math.cos(a)
    sa = math.sin(a)
    h = s * 0.5
    pts = []
    for (px, py) in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + px * ca - py * sa, cy + px * sa + py * ca))
    return pts


def _overlap_amount(sq1, sq2):
    """Approximate overlap depth between two squares using SAT.  Returns
    maximum penetration depth (0 if separated)."""
    c1 = _corner_pts(*sq1)
    c2 = _corner_pts(*sq2)
    min_pen = float('inf')
    for poly in (c1, c2):
        for i in range(4):
            ax = poly[i]
            bx = poly[(i + 1) % 4]
            ex = bx[0] - ax[0]
            ey = bx[1] - ax[1]
            # normal
            nx = -ey
            ny = ex
            ln = math.hypot(nx, ny)
            if ln < 1e-15:
                continue
            nx /= ln
            ny /= ln
            # project both
            p1 = [p[0] * nx + p[1] * ny for p in c1]
            p2 = [p[0] * nx + p[1] * ny for p in c2]
            o1 = max(p1) - min(p1)
            o2 = max(p2) - min(p2)
            overlap = min(max(p1), max(p2)) - max(min(p1), min(p2))
            if overlap <= 0:
                return 0.0
            min_pen = min(min_pen, overlap)
    return min_pen if min_pen != float('inf') else 0.0


def _total_penalty(squares):
    n = len(squares)
    pen = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            o = _overlap_amount(squares[i], squares[j])
            if o > 0:
                pen += o * o
    return pen


def _clamp_square(s):
    cx, cy, ang, side = s
    side = max(0.0, min(1.0, side))
    h = side * 0.5
    # ensure within [0,1]^2 bounding box
    cx = max(h, min(1.0 - h, cx))
    cy = max(h, min(1.0 - h, cy))
    ang = ang % 1.0
    return (cx, cy, ang, side)


def _evaluate(squares):
    pen = _total_penalty(squares)
    total = sum(s[3] for s in squares)
    return total - 1e6 * pen, pen, total


def _refine(squares, rng, iterations=60):
    cur = [ _clamp_square(s) for s in squares ]
    cur_score, cur_pen, cur_total = _evaluate(cur)
    n = len(cur)
    if n == 0:
        return cur
    step_c = 0.02
    step_s = 0.02
    step_a = 0.02
    for it in range(iterations):
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for idx in order:
            best_local = cur_score
            best_val = cur[idx]
            for dcx, dcy in ((step_c, 0), (-step_c, 0), (0, step_c), (0, -step_c),
                             (step_c, step_c), (-step_c, step_c),
                             (step_c, -step_c), (-step_c, -step_c)):
                s = cur[idx]
                cand = _clamp_square((s[0] + dcx, s[1] + dcy, s[2], s[3]))
                trial = list(cur)
                trial[idx] = cand
                sc, pen, tot = _evaluate(trial)
                if sc > best_local + 1e-12:
                    best_local = sc
                    best_val = cand
            for ds in (step_s, -step_s):
                s = cur[idx]
                cand = _clamp_square((s[0], s[1], s[2], s[3] + ds))
                trial = list(cur)
                trial[idx] = cand
                sc, pen, tot = _evaluate(trial)
                if sc > best_local + 1e-12:
                    best_local = sc
                    best_val = cand
            for da in (step_a, -step_a):
                s = cur[idx]
                cand = _clamp_square((s[0], s[1], s[2] + da, s[3]))
                trial = list(cur)
                trial[idx] = cand
                sc, pen, tot = _evaluate(trial)
                if sc > best_local + 1e-12:
                    best_local = sc
                    best_val = cand
            if best_local > cur_score + 1e-12:
                cur[idx] = best_val
                cur_score = best_local
                improved = True
        if not improved:
            step_c *= 0.5
            step_s *= 0.5
            step_a *= 0.5
            if step_c < 1e-4:
                break
    # verify: only keep if penalty zero
    final_score, final_pen, final_total = _evaluate(cur)
    if final_pen < 1e-9:
        return cur
    return squares


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout, _corner_layout_v):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    max_shelves = min(n, 5)
    for k in range(1, max_shelves + 1):
        for comp in _compositions(n, k):
            sq, total = _shelf_layout(n, list(comp))
            if sq is not None and total > best_sum:
                best_sum = total
                best = sq

    for depth in (1, 2):
        sq, total = _guillotine(n, (0.0, 0.0, 1.0, 1.0), depth)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n

    squares = [tuple(s) for s in best]
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]

    # continuous refinement (limited iters to stay within time budget)
    rng = random.Random(12345)
    iters = 40 if n <= 30 else 20
    refined = _refine(squares, rng, iterations=iters)
    refined_sum = sum(s[3] for s in refined)
    if refined_sum >= best_sum - 1e-9 and _total_penalty(refined) < 1e-9:
        squares = refined

    return squares
# EVOLVE-BLOCK-END

