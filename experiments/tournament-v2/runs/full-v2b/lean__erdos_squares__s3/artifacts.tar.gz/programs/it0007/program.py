# EVOLVE-BLOCK-START
"""Pack n squares by recursive guillotine subdivision plus grid packing.

We search over guillotine partitions of the unit square into rectangles.
For a rectangle (W,H) and an integer count k we compute the best sum of k
equal squares packed as an a x b grid (a*b = k, side = min(W/a, H/b)).
We then allow a single vertical or horizontal cut and split k between the two
sub-rectangles, recursing. This generalizes plain grids, single/double strips
and corner-dominant layouts, and can capture the classic optimal packings.
"""
import math
from functools import lru_cache


def _grid_best(W, H, k):
    """Best total side of k equal squares gridded inside W x H."""
    if k <= 0:
        return 0.0
    best = 0.0
    a = 1
    while a * a <= k:
        if k % a == 0:
            b = k // a
            s = min(W / a, H / b)
            best = max(best, s * k)
            s = min(W / b, H / a)
            best = max(best, s * k)
        a += 1
    return best


def _pack_grid(W, H, k, ox, oy):
    """Return squares packing k equal squares gridded in W x H at offset."""
    if k <= 0:
        return []
    best = -1.0
    chosen = (1, k)
    a = 1
    while a * a <= k:
        if k % a == 0:
            b = k // a
            for (aa, bb) in ((a, b), (b, a)):
                s = min(W / aa, H / bb)
                if s * k > best:
                    best = s * k
                    chosen = (aa, bb)
        a += 1
    aa, bb = chosen
    s = min(W / aa, H / bb)
    res = []
    for i in range(bb):
        for j in range(aa):
            res.append((ox + (j + 0.5) * s, oy + (i + 0.5) * s, 0.0, s))
    return res


# memoized best value of a rectangle region with k squares
_memo = {}


def _rect_best(W, H, k):
    if k <= 0:
        return 0.0
    key = (round(W, 6), round(H, 6), k)
    if key in _memo:
        return _memo[key]
    best = _grid_best(W, H, k)
    # try one vertical cut
    if k >= 2:
        for k1 in range(1, k):
            k2 = k - k1
            # a small set of candidate cut positions
            for frac in (0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8):
                x = W * frac
                v = _rect_best(x, H, k1) + _rect_best(W - x, H, k2)
                if v > best:
                    best = v
                y = H * frac
                v = _rect_best(W, y, k1) + _rect_best(W, H - y, k2)
                if v > best:
                    best = v
    _memo[key] = best
    return best


def _rect_pack(W, H, k, ox, oy):
    """Return list of squares packing k squares in W x H at offset (ox,oy)."""
    if k <= 0:
        return []
    best = _grid_best(W, H, k)
    choice = ('grid',)
    if k >= 2:
        for k1 in range(1, k):
            k2 = k - k1
            for frac in (0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8):
                x = W * frac
                v = _rect_best(x, H, k1) + _rect_best(W - x, H, k2)
                if v > best + 1e-12:
                    best = v
                    choice = ('v', k1, k2, x)
                y = H * frac
                v = _rect_best(W, y, k1) + _rect_best(W, H - y, k2)
                if v > best + 1e-12:
                    best = v
                    choice = ('h', k1, k2, y)
    if choice[0] == 'grid':
        return _pack_grid(W, H, k, ox, oy)
    if choice[0] == 'v':
        _, k1, k2, x = choice
        return (_rect_pack(x, H, k1, ox, oy) +
                _rect_pack(W - x, H, k2, ox + x, oy))
    else:
        _, k1, k2, y = choice
        return (_rect_pack(W, y, k1, ox, oy) +
                _rect_pack(W, H - y, k2, ox, oy + y))


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    _memo.clear()
    best = None
    best_sum = -1.0

    # guillotine packing (unified family)
    sq = _rect_pack(1.0, 1.0, n, 0.0, 0.0)
    total = _rect_best(1.0, 1.0, n)
    if total > best_sum:
        best_sum = total
        best = sq

    # plain grids as a safety net
    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    best = best[:n]
    # clamp into unit square
    out = []
    for (x, y, a, s) in best:
        out.append((min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0), a, min(s, 1.0)))
    return out
# EVOLVE-BLOCK-END
