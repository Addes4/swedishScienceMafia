# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, corner-dominant layouts, and a final
continuous polish step that locally optimises every square's position, angle
and side under non-overlap constraints (projected coordinate ascent).
"""
import math
import random


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout_v(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s_max = 1.0
        if kr > 0:
            s_max = min(s_max, 1.0 / (kr + 1))
        if kt > 0:
            s_max = min(s_max, 1.0 / kt)
        s_max = min(s_max, 0.5)
        if s_max <= 0:
            continue
        s = s_max
        t = 1.0 - s
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


# --------------------------- geometry helpers ---------------------------

def _corners(cx, cy, ang, side):
    """Return the 4 corner points of a square (CCW rotation by ang)."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side / 2.0
    pts = []
    for sx, sy in ((1, 1), (-1, 1), (-1, -1), (1, -1)):
        dx, dy = sx * h, sy * h
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _axes(cx, cy, ang, side):
    """Return two unit axes (u, v) of the square and half-extent h."""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    return (ca, sa), (-sa, ca), side / 2.0


def _separation_overlap(sq1, sq2, eps=1e-9):
    """SAT overlap test for two oriented squares; True if interiors overlap."""
    (c1x, c1y, a1, s1) = sq1
    (c2x, c2y, a2, s2) = sq2
    if s1 <= 0 or s2 <= 0:
        return False
    u1, v1, h1 = _axes(c1x, c1y, a1, s1)
    u2, v2, h2 = _axes(c2x, c2y, a2, s2)
    axes = [u1, v1, u2, v2]
    dc = (c2x - c1x, c2y - c1y)
    for ax, ay in axes:
        r1 = h1 * (abs(u1[0] * ax + u1[1] * ay) + abs(v1[0] * ax + v1[1] * ay))
        r2 = h2 * (abs(u2[0] * ax + u2[1] * ay) + abs(v2[0] * ax + v2[1] * ay))
        d = abs(dc[0] * ax + dc[1] * ay)
        if d >= r1 + r2 - eps:
            return False
    return True


def _inside_unit(sq, eps=1e-7):
    cx, cy, ang, side = sq
    if side <= 0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    for x, y in _corners(cx, cy, ang, side):
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def _valid(squares):
    n = len(squares)
    for i in range(n):
        if not _inside_unit(squares[i]):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _separation_overlap(squares[i], squares[j]):
                return False
    return True


def _total(squares):
    return sum(s[3] for s in squares)


def _clamp_inside(sq):
    cx, cy, ang, side = sq
    if side <= 0:
        return (min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), ang, 0.0)
    # shrink side first so corners fit, then clamp centre
    cx = min(1.0, max(0.0, cx))
    cy = min(1.0, max(0.0, cy))
    for _ in range(60):
        if _inside_unit((cx, cy, ang, side)):
            return (cx, cy, ang, side)
        side *= 0.97
        if side < 1e-6:
            return (cx, cy, ang, 0.0)
    return (cx, cy, ang, side)


def _polish(squares, iters=60):
    """Projected coordinate ascent: repeatedly try to grow each square and
    nudge its centre, keeping the whole configuration valid."""
    cur = [tuple(s) for s in squares]
    cur = [_clamp_inside(s) for s in cur]
    n = len(cur)
    if n == 0:
        return cur
    for _ in range(iters):
        improved = False
        for i in range(n):
            cx, cy, ang, side = cur[i]
            # try to grow this square
            best = cur[i]
            best_tot = _total(cur)
            for grow in (1.06, 1.03, 1.015, 1.008):
                cand = (cx, cy, ang, side * grow)
                cand = _clamp_inside(cand)
                if cand[3] <= side + 1e-12:
                    continue
                trial = cur[:]
                trial[i] = cand
                ok = True
                for j in range(n):
                    if j != i and _separation_overlap(cand, trial[j]):
                        ok = False
                        break
                if ok and _inside_unit(cand):
                    tot = _total(trial)
                    if tot > best_tot + 1e-12:
                        best = cand
                        best_tot = tot
            # try to nudge centre in 8 directions to unlock more growth later
            if best[3] <= side + 1e-12:
                deltas = [(0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01)]
                dsz = side * 0.01 if side > 0 else 0.0
                for dx, dy in deltas:
                    for gr in (1.02, 1.005):
                        cand = (cx + dx, cy + dy, ang, side + dsz * (gr - 1.0) / 0.01 * 0.0 + side * (gr - 1.0))
                        cand = _clamp_inside(cand)
                        trial = cur[:]
                        trial[i] = cand
                        ok = True
                        for j in range(n):
                            if j != i and _separation_overlap(cand, trial[j]):
                                ok = False
                                break
                        if ok and _inside_unit(cand) and _total(trial) > best_tot + 1e-12:
                            best = cand
                            best_tot = _total(trial)
            if best_tot > _total(cur) + 1e-12:
                cur[i] = best
                improved = True
        if not improved:
            break
    return cur


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    sq, total = _corner_layout_v(n, 0)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n

    # continuous polish
    polished = _polish(best, iters=80)
    if _valid(polished) and _total(polished) > best_sum:
        return polished

    if _valid(best):
        return best
    # final safety fallback
    safe = [_clamp_inside(s) for s in best]
    return safe
# EVOLVE-BLOCK-END
