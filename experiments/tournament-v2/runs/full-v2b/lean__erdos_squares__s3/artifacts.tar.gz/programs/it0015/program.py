# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, corner-dominant layouts, and a
big-square-plus-L-region family where the right column and top row use
independent square sizes and the leftover region may also hold a grid.

All candidate layouts are validated (containment in the unit square and
pairwise non-overlap) before being accepted, so an infeasible arithmetic
combination can never crash or return an invalid packing.
"""
import math


def _valid(squares, tol=1e-9):
    for (cx, cy, a, s) in squares:
        if s <= 0:
            continue
        if s > 1.0 + tol:
            return False
        if cx < s / 2.0 - tol or cx > 1.0 - s / 2.0 + tol:
            return False
        if cy < s / 2.0 - tol or cy > 1.0 - s / 2.0 + tol:
            return False
    # rotated squares are only produced axis-aligned here; check AABB overlap
    active = [(cx, cy, s) for (cx, cy, a, s) in squares if s > 1e-12]
    for i in range(len(active)):
        xi, yi, si = active[i]
        for j in range(i + 1, len(active)):
            xj, yj, sj = active[j]
            dx = abs(xi - xj)
            dy = abs(yi - yj)
            if dx < (si + sj) / 2.0 - tol and dy < (si + sj) / 2.0 - tol:
                return False
    return True


def _finish(squares, n):
    out = list(squares)
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    return _finish(squares, n), side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    k = n - rows * full_cols
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    squares = _finish(squares, n)
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    k = n - full_rows * cols
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    squares = _finish(squares, n)
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n):
    """One big square of side t in a corner; remaining L-region filled with a
    uniform grid of side s = min constraints maximizing t + m s."""
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        if s <= 0:
            continue
        t = 1.0 - s
        if t <= 0 or s <= 0:
            continue
        if kr > 0 and kr * s > t + 1e-9:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-9:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            if _valid(_finish(squares, n)):
                best_sum = total
                best = squares
    if best is None:
        return None, -1.0
    return _finish(best, n), best_sum


def _big_L_layout(n):
    """Big square of side t in bottom-left. Right column (width 1-t) holds kr
    squares of side a; top row (height 1-t) holds kt squares of side b. a and b
    are independent, bounded by the strip width/height and counts. We then may
    grow t subject to a <= 1-t and b <= 1-t."""
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        # given t, max a = min(1-t, t/kr) ; max b = min(1-t, 1/kt)
        # total = t + kr*a + kt*b ; search t finely.
        t_lo, t_hi = 0.0, 1.0
        for step in range(201):
            t = t_lo + (t_hi - t_lo) * step / 200.0
            if t <= 1e-9 or t >= 1.0 - 1e-9:
                continue
            a = 1.0 - t
            if kr > 0:
                a = min(a, t / kr)
            b = 1.0 - t
            if kt > 0:
                b = min(b, 1.0 / kt)
            if a < 0 or b < 0:
                continue
            if kr > 0 and a <= 0:
                continue
            if kt > 0 and b <= 0:
                continue
            total = t + kr * a + kt * b
            if total > best_sum:
                w = 1.0 - t
                squares = [(t / 2.0, t / 2.0, 0.0, t)]
                # right column: width w=t? No: right strip width = 1-t = a (if a<=1-t)
                for i in range(kr):
                    y = (i + 0.5) * (t / kr) if kr > 0 else 0.5
                    squares.append((t + a / 2.0, y, 0.0, a))
                for j in range(kt):
                    x = (j + 0.5) / kt if kt > 0 else 0.5
                    squares.append((x, t + b / 2.0, 0.0, b))
                if _valid(_finish(squares, n)):
                    best_sum = total
                    best = squares
    if best is None:
        return None, -1.0
    return _finish(best, n), best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum and _valid(sq):
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum and _valid(sq):
                    best_sum = total
                    best = sq

    for fn in (_corner_layout, _big_L_layout):
        sq, total = fn(n)
        if sq is not None and total > best_sum and _valid(sq):
            best_sum = total
            best = sq

    if best is None:
        best = _equal_grid(n, 1, n)[0]
    return best
# EVOLVE-BLOCK-END
