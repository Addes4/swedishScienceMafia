# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips and corner-dominant layouts.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: either a grid of equal squares whose count exceeds n, or a
"strip" layout where one row/column contains fewer, larger squares that
stretch into the leftover region, or a corner-dominant layout with one big
square plus a grid filling the remaining L-shaped region.

A final continuous polish grows squares to absorb leftover slack, validated
with a separating-axis overlap check so packings always stay valid.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corners(sq):
    x, y, a, s = sq
    th = a * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s / 2.0
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((x + dx * c - dy * sn, y + dx * sn + dy * c))
    return pts


def _axes(sq):
    a = sq[2] * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    return [(c, sn), (-sn, c)]


def _overlap(sq1, sq2):
    """Separating axis test for two rotated squares. True if interiors overlap."""
    if sq1[3] <= 1e-15 or sq2[3] <= 1e-15:
        return False
    c1 = _corners(sq1)
    c2 = _corners(sq2)
    axes = _axes(sq1) + _axes(sq2)
    for ax, ay in axes:
        p1 = [px * ax + py * ay for px, py in c1]
        p2 = [px * ax + py * ay for px, py in c2]
        if max(p1) <= min(p2) + 1e-12 or max(p2) <= min(p1) + 1e-12:
            return False
    return True


def _valid(sqs):
    for sq in sqs:
        x, y, a, s = sq
        if s < 0:
            return False
        # containing within unit square via corner check
        for px, py in _corners(sq):
            if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                return False
    n = len(sqs)
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap(sqs[i], sqs[j]):
                return False
    return True


def _polish(sqs, budget_iters=200):
    """Grow each square as much as possible (validated) to absorb slack."""
    sqs = [list(sq) for sq in sqs]
    n = len(sqs)
    # coordinate/scale ascent: try to enlarge each square going around,
    # accepting growths that keep validity.
    improved = True
    iters = 0
    while improved and iters < budget_iters:
        improved = False
        iters += 1
        for i in range(n):
            cur = tuple(sqs[i])
            best_s = cur
            # binary search on side growth
            lo, hi = cur[3], cur[3] + 0.5
            for _ in range(30):
                mid = (lo + hi) / 2.0
                cand = [s for s in sqs]
                cand[i] = [cur[0], cur[1], cur[2], mid]
                ok = True
                for j in range(n):
                    if j == i:
                        continue
                    if _overlap(tuple(cand[i]), tuple(cand[j])):
                        ok = False
                        break
                if ok:
                    # containment
                    for px, py in _corners(tuple(cand[i])):
                        if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                            ok = False
                            break
                if ok:
                    lo = mid
                else:
                    hi = mid
            if lo > cur[3] + 1e-9:
                sqs[i] = [cur[0], cur[1], cur[2], lo]
                improved = True
        # also try to grow by scaling all sides together (uniform blow-up)
        scale_lo, scale_hi = 1.0, 3.0
        best_scale = 1.0
        for _ in range(30):
            mid = (scale_lo + scale_hi) / 2.0
            cand = [[s[0], s[1], s[2], s[3] * mid] for s in sqs]
            if _valid(cand):
                scale_lo = mid
                best_scale = mid
            else:
                scale_hi = mid
        if best_scale > 1.0 + 1e-9:
            sqs = [[s[0], s[1], s[2], s[3] * best_scale] for s in sqs]
            improved = True
    return [tuple(s) for s in sqs]


def _clip(sqs, n):
    out = list(sqs)[:n]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    # clamp to [0,1]
    res = []
    for x, y, a, s in out:
        res.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)),
                    a % 1.0, min(1.0, max(0.0, s))))
    return res


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    def consider(sq, total):
        nonlocal best, best_sum
        if sq is not None and total > best_sum:
            try:
                if _valid([list(t) for t in sq]):
                    best_sum = total
                    best = sq
            except Exception:
                pass

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            consider(sq, total)

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                consider(sq, total)

    for fn in (_corner_layout,):
        sq, total = fn(n, 0)
        consider(sq, total)

    if best is None:
        best = _equal_grid(n, int(math.ceil(math.sqrt(n))), int(math.ceil(math.sqrt(n))))[0]

    # continuous polish
    try:
        polished = _polish([list(t) for t in best])
        # verify polished validity
        raw = [(x, y, a % 1.0, s) for (x, y, a, s) in polished]
        if _valid([list(t) for t in raw]):
            psum = sum(t[3] for t in raw)
            if psum > best_sum + 1e-9:
                best = raw
                best_sum = psum
    except Exception:
        pass

    return _clip(best, n)
# EVOLVE-BLOCK-END
