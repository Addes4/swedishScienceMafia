# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips and corner-dominant layouts.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: either a grid of equal squares whose count exceeds n, or a
"strip" layout where one row/column contains fewer, larger squares that
stretch into the leftover region, or a corner-dominant layout with one big
square plus a grid filling the remaining L-shaped region, or a two-corner
layout with two large squares plus a grid filling the remaining region.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    """rows x cols grid, but the last column holds 'extra' larger squares."""
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    """rows x cols grid, last row has fewer, larger squares in leftover height."""
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    """One big square of side t in the bottom-left corner; the remaining
    L-shaped region (top strip + right strip) is filled with equal squares."""
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_layout_v(n, big_index):
    """Same as corner layout but explicit search over splits (dedup variant)."""
    return _corner_layout(n, big_index)


def _two_corner_layout(n):
    """Two big squares in opposite corners (bottom-left and top-right) of side t,
    plus m = n-2 smaller squares of side s. The free region is:
      - top-left block: width (1-t), height (1-t)
      - bottom-right block: width (1-t), height (1-t)
    plus strips. We use a simple feasible parametrization: place the two big
    squares diagonally; the remaining two rectangles each (1-t) x 1 and
    1 x (1-t) can host the small squares. Require s <= 1-t and grid them.
    Maximize 2t + m*s subject to the small squares fitting in the two corner
    rectangles (each of size (1-t) x (1-t)) and the connecting strips.
    """
    m = n - 2
    if m < 0:
        return None, -1.0
    best = None
    best_sum = -1.0
    # The two opposite-corner rectangles are (1-t) x (1-t). Put ka small squares
    # in the top-left block and kb in the bottom-right block; blocks are
    # (1-t) x (1-t). Choose s so ka squares fit as a grid: s <= (1-t)/ceil(sqrt(ka)).
    for t_num in range(0, 41):
        t = 1.0 - t_num * 0.0125
        if t <= 0 or t >= 1.0:
            continue
        avail = 1.0 - t
        if avail <= 1e-9:
            continue
        # maximize small side given they must fit in two blocks of size avail x avail.
        # distribute m among the two blocks optimally by trying a split
        for ka in range(0, m + 1):
            kb = m - ka
            # each block of size avail x avail must hold ka (resp kb) squares as a grid
            sa = avail / max(1, math.ceil(math.sqrt(ka))) if ka > 0 else avail
            sb = avail / max(1, math.ceil(math.sqrt(kb))) if kb > 0 else avail
            s = avail
            if ka > 0:
                s = min(s, sa)
            if kb > 0:
                s = min(s, sb)
            # also a single small square can sit in the remaining full strips
            s = min(s, avail)
            if s <= 0:
                continue
            # feasibility: use conservative grid side s = avail / max(1, ceil(sqrt(max(ka,kb))))
            if ka > 0 and sa < s - 1e-12:
                continue
            if kb > 0 and sb < s - 1e-12:
                continue
            total = 2.0 * t + m * s
            if total > best_sum + 1e-12:
                squares = []
                # big square bottom-left at [0,t]x[0,t]
                squares.append((t / 2.0, t / 2.0, 0.0, t))
                # big square top-right at [1-t,1]x[1-t,1]
                squares.append((1.0 - t / 2.0, 1.0 - t / 2.0, 0.0, t))
                # top-left block: [0, avail] x [t, 1]
                cnt = 0
                ga = max(1, math.ceil(math.sqrt(ka))) if ka > 0 else 0
                if ka > 0:
                    for i in range(ga):
                        for j in range(ga):
                            if cnt >= ka:
                                break
                            squares.append(((j + 0.5) * s, t + (i + 0.5) * s, 0.0, s))
                            cnt += 1
                        if cnt >= ka:
                            break
                # bottom-right block: [t, 1] x [0, avail]
                cnt = 0
                gb = max(1, math.ceil(math.sqrt(kb))) if kb > 0 else 0
                if kb > 0:
                    for i in range(gb):
                        for j in range(gb):
                            if cnt >= kb:
                                break
                            squares.append((t + (j + 0.5) * s, (i + 0.5) * s, 0.0, s))
                            cnt += 1
                        if cnt >= kb:
                            break
                best_sum = total
                best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout, _corner_layout_v):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    sq, total = _two_corner_layout(n)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    return best
# EVOLVE-BLOCK-END
