# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips and corner-dominant layouts.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: either a grid of equal squares whose count exceeds n, or a
"strip" layout where one row/column contains fewer, larger squares that
stretch into the leftover region, or a corner-dominant layout with one big
square plus a grid filling the remaining L-shaped region.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    """rows x cols grid, but the last column holds 'extra' larger squares."""
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    """rows x cols grid, last row has fewer, larger squares in leftover height."""
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    """One big square of side t in the bottom-left corner; the remaining
    L-shaped region (top strip height 1-t, right strip width 1-t) is filled
    with equal squares of side s forming a grid. Search joint t and s."""
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_layout_general(n):
    """Big square side t in bottom-left. Remaining L-region:
      right strip  : x in [t,1], y in [0,t]   (width 1-t, height t)
      top strip    : x in [0,1], y in [t,1]   (width 1,   height 1-t)
    Fill right strip with kr equal squares side b (b<=1-t, kr*b<=t),
    fill top strip with kt equal squares side c (c<=1-t, kt*c<=1).
    Float search over t, exact optimal b and c given t.
    """
    m = n - 1
    if m < 0:
        return None, -1.0
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        # scan t
        steps = 600
        for it in range(1, steps):
            t = 1.0 - it / float(steps)
            if t <= 1e-9 or t >= 1.0:
                continue
            # right strip size
            b = 1.0 - t  # width limit
            if kr > 0:
                b = min(b, t / kr)
            else:
                b = 0.0
            # top strip size
            c = 1.0 - t  # height limit
            if kt > 0:
                c = min(c, 1.0 / kt)
            else:
                c = 0.0
            if b < 0:
                b = 0.0
            if c < 0:
                c = 0.0
            total = t + kr * b + kt * c
            if total > best_sum:
                squares = [(t / 2.0, t / 2.0, 0.0, t)]
                if kr > 0 and b > 0:
                    for y in _centered_positions(kr, t):
                        squares.append((t + b / 2.0, y, 0.0, b))
                if kt > 0 and c > 0:
                    for j in range(kt):
                        squares.append(((j + 0.5) / kt, t + c / 2.0, 0.0, c))
                best_sum = total
                best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_two_rect(n):
    """Big corner square side t; the top strip filled by an a x b grid of
    equal squares and the right strip filled by c x d grid of equal squares,
    with independent sub-grids and exact sizes. Brute over grid shapes."""
    m = n - 1
    if m <= 0:
        return None, -1.0
    best = None
    best_sum = -1.0
    # distribute m as: right rectangle grid r1 rows x r2 cols (only in right strip)
    # top rectangle grid t1 rows x t2 cols (only in top strip)
    for r1 in range(0, m + 1):
        for r2 in range(0, m + 1):
            if r1 == 0 or r2 == 0:
                # degenerate -> handled by general
                continue
            if r1 * r2 > m:
                continue
            rem = m - r1 * r2
            for t1 in range(0, rem + 1):
                for t2 in range(0, rem + 1):
                    if t1 == 0 or t2 == 0:
                        continue
                    if t1 * t2 != rem:
                        continue
                    steps = 400
                    for it in range(1, steps):
                        t = 1.0 - it / float(steps)
                        if t <= 1e-9:
                            continue
                        # right strip: width 1-t, height t
                        # r1 stacked vertically, r2 across horizontally
                        b = min((1.0 - t) / r2, t / r1)
                        # top strip: width 1, height 1-t
                        # t1 rows, t2 cols
                        c = min(1.0 / t2, (1.0 - t) / t1)
                        if b <= 0 or c <= 0:
                            continue
                        total = t + r1 * r2 * b + t1 * t2 * c
                        if total > best_sum:
                            squares = [(t / 2.0, t / 2.0, 0.0, t)]
                            # right strip
                            w_r = 1.0 - t
                            for i in range(r1):
                                for j in range(r2):
                                    x = t + (j + 0.5) * (w_r / r2)
                                    y = (i + 0.5) * (t / r1)
                                    squares.append((x, y, 0.0, b))
                            # top strip
                            h_t = 1.0 - t
                            for i in range(t1):
                                for j in range(t2):
                                    x = (j + 0.5) * (1.0 / t2)
                                    y = t + (i + 0.5) * (h_t / t1)
                                    squares.append((x, y, 0.0, c))
                            best_sum = total
                            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout, _corner_layout_general, _corner_two_rect):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    return best
# EVOLVE-BLOCK-END
