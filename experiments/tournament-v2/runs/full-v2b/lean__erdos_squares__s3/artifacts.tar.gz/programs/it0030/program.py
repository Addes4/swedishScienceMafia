# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, shelf (guillotine) layouts,
corner-dominant layouts, and a center-diamond family."""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_layout_v(n, big_index):
    return _corner_layout(n, big_index)


def _shelf_layout(n, shelves):
    k = len(shelves)
    if k == 0:
        return None, -1.0
    best = None
    best_sum = -1.0
    for mask in range(1 << k):
        widths = [1.0] * k
        fixed = 0.0
        free = 0
        for i in range(k):
            if mask >> i & 1:
                widths[i] = 1.0 / shelves[i]
                fixed += widths[i]
            else:
                free += 1
        rem = 1.0 - fixed
        if rem < -1e-9:
            continue
        if free > 0:
            h = rem / free
            if h < -1e-9:
                continue
            for i in range(k):
                if not (mask >> i & 1):
                    widths[i] = h
        sizes = []
        ok = True
        for i in range(k):
            c = shelves[i]
            if c <= 0:
                ok = False
                break
            if mask >> i & 1:
                sizes.append(1.0 / c)
            else:
                if widths[i] > 1.0 / c + 1e-9:
                    ok = False
                    break
                sizes.append(widths[i])
        if not ok:
            continue
        total = sum(c * s for c, s in zip(shelves, sizes))
        if total > best_sum:
            squares = []
            y = 1.0
            for i in range(k):
                c = shelves[i]
                s = sizes[i]
                h = widths[i]
                y -= h
                yc = y + h / 2.0
                for j in range(c):
                    xc = (j + 0.5) / c
                    squares.append((xc, yc, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    for first in range(1, n - k + 2):
        for rest in _compositions(n - first, k - 1):
            yield (first,) + rest


def _center_diamond(n, kr):
    """One big square rotated 45 deg centered at (0.5,0.5) with side D,
    and kr axis-aligned small squares of side s in the corner region
    outside the diamond but inside the unit square.

    A 45-deg square (diamond) centered at center with half-diagonal
    a = D/sqrt(2) along the axes occupies |x-0.5|+|y-0.5| <= a.  The
    remaining region near each corner is a right triangle.  We place
    small axis-aligned squares near corners.

    Simpler valid construction: place the diamond so its four vertices
    touch the midpoints of the unit square sides (a = 0.5), giving
    D = sqrt(2)/2.  Then each corner triangle has legs 0.5 and 0.5.
    Place small squares of side s in corners: a square of side s
    centered at (s/2, s/2) etc. must not intersect the diamond, i.e.
    |x-0.5|+|y-0.5| >= a for all points of the square.  Worst point is
    the square corner nearest the center.
    """
    m = n - 1
    if kr != m:
        # we only attempt all remaining squares as corner squares
        pass
    best = None
    best_sum = -1.0
    # scan diamond half-diagonal a in (0, 0.5], and small side s
    steps = 60
    for ia in range(1, steps + 1):
        a = 0.5 * ia / steps
        D = a * math.sqrt(2.0)
        # corner triangle legs = 0.5 - (a - 0.5)?? For a<=0.5 vertex along
        # axis at distance a from center => gap along axis = 0.5 - a.
        # Small squares placed in the four corners.  Number we can fit:
        # along each edge we have free length 0.5 - a on both ends.
        if a >= 0.5 - 1e-12:
            continue
        gap = 0.5 - a  # free length from corner to diamond along axis
        # We place small axis-aligned squares in corners.  A square of
        # side s centered at (cx,cy) with cx=cy=s/2 (touching corner).
        # Non-overlap with diamond: nearest square point to center is
        # (s, s); require |s-0.5|+|s-0.5| >= a  =>  2*|0.5-s| >= a
        # plus the square must fit within unit square: s <= 0.5.
        # For corner square that's the constraint.  Solve s.
        # Additionally can place squares along edges (mid-edge rows).
        for is_ in range(1, steps + 1):
            s = 0.5 * is_ / steps
            if s <= 0:
                continue
            # check corner square at (s/2,s/2)
            if 2.0 * abs(0.5 - s) < a - 1e-9:
                continue
            # how many corner squares of this size fit?
            # four corners each hold 1; along top/bottom edge between
            # corner squares we can fit floor((1 - 2s)/s) more per edge
            # but must also clear diamond. Place conservatively only the
            # four corner squares plus edge squares that stay in corner-ish.
            count_per_edge = 0
            avail = 0.5 - a  # distance along axis from corner to diamond
            if s <= avail + 1e-9:
                count_per_edge = 1
            tot = 4 * count_per_edge
            if tot < 1:
                continue
            # use as many small squares as we have (up to tot), extras zero
            ksmall = min(m, tot)
            total = D + ksmall * s
            if total > best_sum:
                squares = [(0.5, 0.5, 0.25, D)]
                pos = []
                if count_per_edge:
                    pos = [(s / 2.0, s / 2.0), (1 - s / 2.0, s / 2.0),
                           (s / 2.0, 1 - s / 2.0), (1 - s / 2.0, 1 - s / 2.0)]
                for (px, py) in pos[:ksmall]:
                    squares.append((px, py, 0.0, s))
                while len(squares) < n:
                    squares.append((0.5, 0.5, 0.0, 0.0))
                best_sum = total
                best = squares[:n]
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout, _corner_layout_v):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    max_shelves = min(n, 5)
    for k in range(1, max_shelves + 1):
        for comp in _compositions(n, k):
            sq, total = _shelf_layout(n, list(comp))
            if sq is not None and total > best_sum:
                best_sum = total
                best = sq

    sq, total = _center_diamond(n, n - 1)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n

    return best
# EVOLVE-BLOCK-END
