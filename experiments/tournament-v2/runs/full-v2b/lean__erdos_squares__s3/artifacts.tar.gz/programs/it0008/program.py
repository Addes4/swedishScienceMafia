# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips and corner-dominant layouts.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: either a grid of equal squares whose count exceeds n, or a
"strip" layout where one row/column contains fewer, larger squares that
stretch into the leftover region, or a corner-dominant layout with one big
square plus a grid filling the remaining L-shaped region, or a diagonal
layout with two big squares in opposite corners.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _two_big_diag_layout(n):
    """Two big squares of equal side t in opposite corners (bottom-left and
    top-right). The remaining two opposite corner regions (top-left width t,
    height 1-t; bottom-right width 1-t, height t) are filled with equal
    squares of side s. Distribute m = n-2 small squares between the two
    regions (k1 in top-left, k2 in bottom-right) and maximize 2t + m s.
    """
    m = n - 2
    if m < 0:
        return None, -1.0
    best = None
    best_sum = -1.0
    for k1 in range(0, m + 1):
        k2 = m - k1
        # top-left region: width t, height (1-t). constraint k1*s <= t and s<=1-t
        # bottom-right region: width (1-t), height t. k2*s <= 1-t and s<=t
        # Maximize 2t + m s. Set t = 1 - s (top-left height) to allow big region.
        # Constraints: k1*s <= t = 1-s   -> s <= 1/(k1+1)
        #              k2*s <= 1-t = s   -> k2*s <= s -> k2 <= 1 (else infeasible)
        # But bottom-right width = 1-t = s so only k2<=1 fits. Instead let t
        # be free-ish: we solve for the s that satisfies both.
        # We parametrize s and require t >= k1*s, t >= s (big square region for
        # bottom-right height), and 1-t >= s (top-left height), 1-t >= k2*s.
        # => t >= max(k1*s, s) and t <= 1 - max(s, k2*s).
        # Feasible iff max(k1*s,s) + max(s,k2*s) <= 1.
        # t set to mid of the interval for max total (total indep of t). Use t
        # large enough: t = 1 - max(s, k2*s).
        # choose s to maximize 2t + m*s = 2(1 - max(s,k2*s)) + m*s
        # Search s over a grid.
        for s in _candidate_sides(m):
            A = max(k1 * s, s)
            B = max(s, k2 * s)
            if A + B > 1.0 + 1e-12:
                continue
            t = 1.0 - B  # top strip height
            # ensure big squares fit: t <= 1, t >= A
            if t < A - 1e-12:
                continue
            if t <= 0 or s <= 0:
                continue
            total = 2.0 * t + m * s
            if total > best_sum:
                squares = []
                # bottom-left big square [0,t]x[0,t]
                squares.append((t / 2.0, t / 2.0, 0.0, t))
                # top-right big square [1-t,1]x[1-t,1]
                squares.append((1.0 - t / 2.0, 1.0 - t / 2.0, 0.0, t))
                # top-left region: x in [0,t], y in [1-(1-t),1] = [t,1]
                # height = 1-t, width = t; place k1 squares stacked vertically
                y0 = t
                for i in range(k1):
                    squares.append((t / 2.0, y0 + (i + 0.5) * (1.0 - t) / max(k1, 1), 0.0, s))
                # bottom-right region: x in [t,1] width 1-t, y in [0,t]
                x0 = t
                for j in range(k2):
                    squares.append((x0 + (j + 0.5) * (1.0 - t) / max(k2, 1), t / 2.0, 0.0, s))
                best_sum = total
                best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _candidate_sides(m):
    """A set of candidate small-square sides to try."""
    cands = set()
    for k in range(1, m + 4):
        cands.add(1.0 / k)
        cands.add(1.0 / (k + 1))
        cands.add(1.0 / (2.0 * k))
    for i in range(1, 200):
        cands.add(i / 200.0)
    return sorted(cands)


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout,):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    sq, total = _two_big_diag_layout(n)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    return best
# EVOLVE-BLOCK-END
