# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, corner-dominant and two-tier layouts."""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _two_tier(n):
    """Bottom shelf with kr equal squares of side a; remaining (n-kr) squares
    tiled as an r x c grid in the top rectangle of height 1-a.
    Also try two shelves stacked (bottom row of k1 squares of side a1,
    a middle region filled with a grid, etc.).  Try the transposed variant.
    Enumerate kr, r, c and validate  a = min(1/kr, ...) style bounds.
    """
    best = None
    best_sum = -1.0
    for transpose in (False, True):
        for kr in range(1, n + 1):
            m = n - kr
            if m < 0:
                continue
            # bottom shelf: kr squares in a row of width 1 -> a <= 1/kr
            # shelf height = a
            a_max = 1.0 / kr
            # remaining m squares in region height (1-a), width 1
            if m == 0:
                # just kr squares in a shelf; but we want to use full height
                # a = 1/kr if that equals full -> only if kr==1
                a = a_max
                total = kr * a
                if total > best_sum + 1e-12:
                    best_sum = total
                    sq = []
                    for j in range(kr):
                        sq.append(((j + 0.5) * a, a / 2.0, 0.0, a))
                    best = sq
                    best_tr = transpose
                continue
            lim = int(math.isqrt(m)) + 2
            for r in range(1, lim + 1):
                for c in range(1, lim + 1):
                    if r * c < m:
                        continue
                    # top region: height (1-a), width 1 -> s = min(1/c, (1-a)/r)
                    # also a <= 1/kr and a <= 1 (fit)
                    # maximize kr*a + m*s over a in [0, 1/kr]
                    # s = min(1/c, (1-a)/r)
                    # Two regimes: if (1-a)/r <= 1/c i.e. a >= 1 - r/c, s=(1-a)/r
                    #   total = kr*a + m*(1-a)/r  -> increasing if kr > m/r
                    # else s = 1/c constant in a -> maximize a.
                    for a in _candidate_a(kr, m, r, c, a_max):
                        if a <= 0 or a > a_max + 1e-12 or a >= 1.0:
                            continue
                        h = 1.0 - a
                        if h <= 1e-12:
                            continue
                        s = min(1.0 / c, h / r)
                        if s <= 0:
                            continue
                        # feasibility: grid r x c inside height h, width 1
                        if c * s > 1.0 + 1e-12 or r * s > h + 1e-12:
                            continue
                        total = kr * a + m * s
                        if total > best_sum + 1e-12:
                            sq = []
                            for j in range(kr):
                                sq.append(((j + 0.5) * a, a / 2.0, 0.0, a))
                            # top grid: r rows, c cols, side s, inside y in [a,1]
                            # width: c*s <= 1, center it
                            x0 = (1.0 - c * s) / 2.0
                            for i in range(r):
                                for j in range(c):
                                    if len(sq) >= n:
                                        break
                                    sq.append((x0 + (j + 0.5) * s,
                                               a + (i + 0.5) * s, 0.0, s))
                            while len(sq) < n:
                                sq.append((0.5, 0.5, 0.0, 0.0))
                            sq = sq[:n]
                            if transpose:
                                sq = [(y, x, ang, sd) for (x, y, ang, sd) in sq]
                            best = sq
                            best_sum = total
    if best is None:
        return None, -1.0
    # validate
    for s in best:
        if not _ok(s):
            return None, -1.0
    if not _nonoverlap(best):
        return None, -1.0
    return best, best_sum


def _candidate_a(kr, m, r, c, a_max):
    """Candidate shelf heights a for two-tier layout."""
    cands = set()
    cands.add(a_max)
    # boundary a = 1 - r/c where regime switches (if valid)
    b = 1.0 - r / float(c)
    if 0 < b < a_max:
        cands.add(b)
    # also allow the value maximizing linear piece
    cands.add(0.0)
    # small grid of a values around boundaries
    for t in (0.25, 0.5, 0.75):
        cands.add(a_max * t)
    return [x for x in cands if 0 <= x <= a_max]


def _ok(s):
    cx, cy, ang, side = s
    if not (0.0 <= side <= 1.0 + 1e-9):
        return False
    if not (0.0 <= cx <= 1.0 + 1e-9 and 0.0 <= cy <= 1.0 + 1e-9):
        return False
    # check square fits (bounding radius)
    h = side * 0.5
    if cx - h < -1e-7 or cx + h > 1.0 + 1e-7:
        return False
    if cy - h < -1e-7 or cy + h > 1.0 + 1e-7:
        return False
    return True


def _corners(s):
    cx, cy, ang, side = s
    th = ang * 2.0 * math.pi
    c = math.cos(th) * side * 0.5
    si = math.sin(th) * side * 0.5
    pts = []
    for dx, dy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        pts.append((cx + dx * c - dy * si, cy + dx * si + dy * c))
    return pts


def _overlap(s1, s2):
    p1 = _corners(s1)
    p2 = _corners(s2)
    if not _rect_overlap(p1, p2):
        return False
    # SAT: check axes of both
    for pts in (p1, p2):
        for k in range(4):
            ax, ay = pts[k]
            bx, by = pts[(k + 1) % 4]
            nx, ny = -(by - ay), (bx - ax)
            n1 = _proj(p1, nx, ny)
            n2 = _proj(p2, nx, ny)
            if n1[1] <= n2[0] + 1e-9 or n2[1] <= n1[0] + 1e-9:
                return False
    return True


def _proj(pts, nx, ny):
    vals = [p[0] * nx + p[1] * ny for p in pts]
    return (min(vals), max(vals))


def _rect_overlap(p1, p2):
    x1 = [p[0] for p in p1]; y1 = [p[1] for p in p1]
    x2 = [p[0] for p in p2]; y2 = [p[1] for p in p2]
    if max(x1) <= min(x2) + 1e-12 or max(x2) <= min(x1) + 1e-12:
        return False
    if max(y1) <= min(y2) + 1e-12 or max(y2) <= min(y1) + 1e-12:
        return False
    return True


def _nonoverlap(squares):
    n = len(squares)
    for i in range(n):
        if squares[i][3] <= 1e-12:
            continue
        for j in range(i + 1, n):
            if squares[j][3] <= 1e-12:
                continue
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    sq, total = _two_tier(n)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    return best
# EVOLVE-BLOCK-END
