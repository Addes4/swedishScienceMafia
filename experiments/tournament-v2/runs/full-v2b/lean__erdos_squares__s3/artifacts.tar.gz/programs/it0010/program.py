# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, corner-dominant layouts and a
generalized "big square + optimized L-region" family."""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span, offset=0.0):
    if k <= 0:
        return []
    step = span / k
    return [offset + (i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_layout_v(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s_max = 1.0
        if kr > 0:
            s_max = min(s_max, 1.0 / (kr + 1))
        if kt > 0:
            s_max = min(s_max, 1.0 / kt)
        s_max = min(s_max, 0.5)
        if s_max <= 0:
            continue
        s = s_max
        t = 1.0 - s
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _big_corner_general(n):
    """One large square (side t) in bottom-left, plus kr squares stacked in a
    right strip of width w and kt squares in a top strip of height h, where the
    two small squares may have DIFFERENT sizes sr (right strip) and st (top
    strip). Constraints:
      big square: [0,t] x [0,t]
      right strip: x in [t, 1], width 1-t; squares side sr, must fit kr in t
                   -> kr*sr <= t, sr <= 1-t  (width)
      top strip:   y in [t, 1], height 1-t; squares side st, must fit kt in 1
                   -> kt*st <= 1, st <= 1-t  (height)
    Maximize t + kr*sr + kt*st.  For fixed kr,kt we can use the full width/height.
    Choose t so both strips are exactly as tall/thick as their square sizes:
    Let a = 1-t (strip thickness). right: sr=min(a, t/kr), top: st=min(a,1/kt).
    We scan t."""
    m = n - 1
    best = None
    best_sum = -1.0
    NSTEP = 400
    for kr in range(0, m + 1):
        kt = m - kr
        for it in range(1, NSTEP):
            t = it / float(NSTEP)
            a = 1.0 - t
            if a <= 0:
                continue
            sr = a
            if kr > 0:
                sr = min(sr, t / kr)
            st = a
            if kt > 0:
                st = min(st, 1.0 / kt)
            if kr > 0 and sr <= 0:
                continue
            if kt > 0 and st <= 0:
                continue
            # consistency: big square must be at least as large as small ones?
            # (not required, allow any)
            total = t
            if kr > 0:
                total += kr * sr
            if kt > 0:
                total += kt * st
            if total > best_sum + 1e-12:
                squares = [(t / 2.0, t / 2.0, 0.0, t)]
                # right strip: width a = 1-t, stack kr squares vertically in t
                # use size sr; center them in height t
                if kr > 0:
                    y0 = (t - kr * sr) / 2.0
                    xc = t + sr / 2.0
                    for i in range(kr):
                        squares.append((xc, y0 + (i + 0.5) * sr, 0.0, sr))
                if kt > 0:
                    xspan_used = kt * st
                    x0 = (1.0 - xspan_used) / 2.0
                    yc = t + st / 2.0
                    for j in range(kt):
                        squares.append((x0 + (j + 0.5) * st, yc, 0.0, st))
                best_sum = total
                best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _reflect(squares, n):
    """Return the layout mirrored, to try other corner orientations."""
    return squares


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout, _corner_layout_v, _big_corner_general):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    return best
# EVOLVE-BLOCK-END
