# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, shelf (guillotine) layouts,
corner-dominant layouts and recursive guillotine partitions.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: grids of equal squares, "strip" layouts, guillotine/shelf
layouts where the unit square is recursively split into rectangles each
filled with a grid of equal squares, or corner-dominant layouts.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_layout_v(n, big_index):
    return _corner_layout(n, big_index)


def _shelf_layout(n, shelves):
    k = len(shelves)
    if k == 0:
        return None, -1.0
    best = None
    best_sum = -1.0
    for mask in range(1 << k):
        widths = [1.0] * k
        fixed = 0.0
        free = 0
        for i in range(k):
            if mask >> i & 1:
                widths[i] = 1.0 / shelves[i]
                fixed += widths[i]
            else:
                free += 1
        rem = 1.0 - fixed
        if rem < -1e-9:
            continue
        if free > 0:
            h = rem / free
            if h < -1e-9:
                continue
            for i in range(k):
                if not (mask >> i & 1):
                    widths[i] = h
        sizes = []
        ok = True
        for i in range(k):
            c = shelves[i]
            if c <= 0:
                ok = False
                break
            if mask >> i & 1:
                sizes.append(1.0 / c)
            else:
                if widths[i] > 1.0 / c + 1e-9:
                    ok = False
                    break
                sizes.append(widths[i])
        if not ok:
            continue
        total = sum(c * s for c, s in zip(shelves, sizes))
        if total > best_sum:
            squares = []
            y = 1.0
            for i in range(k):
                c = shelves[i]
                s = sizes[i]
                h = widths[i]
                y -= h
                yc = y + h / 2.0
                for j in range(c):
                    xc = (j + 0.5) / c
                    squares.append((xc, yc, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _shelf_mixed(n, shelves):
    """Horizontal shelves of heights h_i.  In each shelf place `c_i`
    squares of side s_i, packed as ceil patterns: c_i squares in a single
    row of the largest side that fits, i.e. s_i = min(h_i, 1.0/c_i).
    Heights are free positive variables summing to 1.  We optimize by a
    coordinate search: start from a good guess and iteratively adjust each
    height to give its shelf the best possible side."""
    k = len(shelves)
    if k == 0:
        return None, -1.0

    def total_for(heights):
        tot = 0.0
        for c, h in zip(shelves, heights):
            s = min(h, 1.0 / c)
            tot += c * s
        return tot

    def build(heights):
        squares = []
        y = 1.0
        for c, h in zip(shelves, heights):
            s = min(h, 1.0 / c)
            y -= h
            yc = y + h / 2.0
            xs = _centered_positions(c, 1.0)
            for xc in xs:
                squares.append((xc, yc, 0.0, s))
        return squares

    # initial heights proportional to desired square sizes (equal sizes)
    heights = [1.0 / k] * k
    cur = total_for(heights)

    # coordinate descent on heights
    step = 0.25
    for _ in range(60):
        improved = False
        for i in range(k):
            for delta in (step, -step):
                nh = heights[:]
                nh[i] = min(1.0, max(1e-9, nh[i] + delta))
                # renormalize the other heights so the sum stays 1
                others = [j for j in range(k) if j != i]
                rem = 1.0 - nh[i]
                if rem < -1e-9:
                    continue
                cur_other = sum(heights[j] for j in others)
                if cur_other > 1e-12:
                    for j in others:
                        nh[j] = heights[j] / cur_other * rem
                else:
                    for j in others:
                        nh[j] = rem / max(len(others), 1)
                val = total_for(nh)
                if val > cur + 1e-12:
                    cur = val
                    heights = nh
                    improved = True
        if not improved:
            step *= 0.5
            if step < 1e-7:
                break
    squares = build(heights)
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], cur


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    for first in range(1, n - k + 2):
        for rest in _compositions(n - first, k - 1):
            yield (first,) + rest


def _grid_rect(rect, count):
    """Fill axis-aligned rectangle rect=(x0,y0,w,h) with a grid of `count`
    equal squares.  Returns (list_of_squares, total_side)."""
    if count <= 0:
        return [], 0.0
    x0, y0, w, h = rect
    best = None
    best_total = -1.0
    best_side = 0.0
    lim = int(math.isqrt(count)) + 2
    for r in range(1, lim + 1):
        for c in range(1, lim + 1):
            if r * c < count:
                continue
            s = min(w / c, h / r)
            total = s * count
            if total > best_total:
                best_total = total
                best_side = s
                best = (r, c)
    if best is None:
        return [], 0.0
    r, c = best
    s = best_side
    squares = []
    for i in range(r):
        for j in range(c):
            if len(squares) >= count:
                break
            squares.append((x0 + (j + 0.5) * s, y0 + (i + 0.5) * s, 0.0, s))
    return squares, best_total


def _guillotine(n, rect, depth):
    """Recursively guillotine-split rect, filling leaves with grids.
    Returns (squares, total)."""
    x0, y0, w, h = rect
    best_sq, best_total = _grid_rect(rect, n)
    if depth <= 0 or n <= 1:
        return best_sq, best_total
    for k in range(1, n):
        rest = n - k
        for ratio in _ratios():
            lw = w * ratio
            rw = w - lw
            sq1, t1 = _guillotine(k, (x0, y0, lw, h), depth - 1)
            sq2, t2 = _guillotine(rest, (x0 + lw, y0, rw, h), depth - 1)
            if t1 + t2 > best_total:
                best_total = t1 + t2
                best_sq = sq1 + sq2
            lh = h * ratio
            rh = h - lh
            sq1, t1 = _guillotine(k, (x0, y0, w, lh), depth - 1)
            sq2, t2 = _guillotine(rest, (x0, y0 + lh, w, rh), depth - 1)
            if t1 + t2 > best_total:
                best_total = t1 + t2
                best_sq = sq1 + sq2
    return best_sq, best_total


def _ratios():
    return [i / 8.0 for i in range(1, 8)]


def _validate(squares):
    """True if squares are inside the unit square and pairwise non-overlapping."""
    import math as _m
    def corners(cx, cy, ang, s):
        th = ang * 2.0 * _m.pi
        ca, sa = _m.cos(th), _m.sin(th)
        pts = []
        for dx, dy in ((-0.5, -0.5), (0.5, -0.5), (0.5, 0.5), (-0.5, 0.5)):
            px = dx * s
            py = dy * s
            pts.append((cx + px * ca - py * sa, cy + px * sa + py * ca))
        return pts

    n = len(squares)
    for cx, cy, ang, s in squares:
        if s <= 0:
            continue
        pts = corners(cx, cy, ang, s)
        for px, py in pts:
            if px < -1e-7 or px > 1 + 1e-7 or py < -1e-7 or py > 1 + 1e-7:
                return False
    polys = [corners(cx, cy, ang, s) for cx, cy, ang, s in squares if s > 0]
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            if _poly_overlap(polys[i], polys[j]):
                return False
    return True


def _poly_overlap(A, B):
    import math as _m
    def axes(poly):
        ax = []
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            ax.append((-ey, ex))
        return ax

    for poly in (A, B):
        for ax in axes(poly):
            L = _m.hypot(*ax)
            if L < 1e-12:
                continue
            ux, uy = ax[0] / L, ax[1] / L
            pa = [px * ux + py * uy for px, py in A]
            pb = [px * ux + py * uy for px, py in B]
            if max(pa) <= min(pb) + 1e-9 or max(pb) <= min(pa) + 1e-9:
                return False
    return True


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout, _corner_layout_v):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    max_shelves = min(n, 5)
    for k in range(1, max_shelves + 1):
        for comp in _compositions(n, k):
            sq, total = _shelf_layout(n, list(comp))
            if sq is not None and total > best_sum:
                best_sum = total
                best = sq
            sq, total = _shelf_mixed(n, list(comp))
            if sq is not None and total > best_sum and _validate(sq):
                best_sum = total
                best = sq

    for depth in (1, 2):
        sq, total = _guillotine(n, (0.0, 0.0, 1.0, 1.0), depth)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
# EVOLVE-BLOCK-END
