# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips and corner-dominant layouts.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space using a corner-dominant layout where one large square sits in a
corner and the remaining L-shaped region is tiled by a grid of equal squares,
with the counts on the two strips and the corner choice all searched.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, corner):
    """Big square of side t in a corner; remaining L-region tiled by a grid.

    corner is one of 'bl','br','tl','tr'.  The two strips of the L-region have
    thickness determined by t.  We place kr squares along the vertical strip and
    kt along the horizontal strip, all of side s, tuning t and s.
    """
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        # Constraints for big square in a corner with side t:
        #   vertical strip width = 1-t, must fit one column of s: s <= 1-t
        #   vertical strip height = t, must stack kr squares: kr*s <= t
        #   horizontal strip height = 1-t, must fit one row of s: s <= 1-t
        #   horizontal strip width = 1, must hold kt squares: kt*s <= 1
        # Maximize total = t + m*s.  Push t as large as possible: t = 1 - s.
        s_max = 1.0
        if kr > 0:
            s_max = min(s_max, 1.0 / (kr + 1))
        if kt > 0:
            s_max = min(s_max, 1.0 / kt)
        s_max = min(s_max, 0.5)
        if s_max <= 0:
            continue
        s = s_max
        t = 1.0 - s
        total = t + m * s
        if total > best_sum:
            squares = _build_corner(kr, kt, t, s, corner)
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _build_corner(kr, kt, t, s, corner):
    """Construct the packing for a given corner and parameters."""
    squares = []
    # Place big square center according to corner.
    if corner == 'bl':
        cx, cy = t / 2.0, t / 2.0
    elif corner == 'br':
        cx, cy = 1.0 - t / 2.0, t / 2.0
    elif corner == 'tl':
        cx, cy = t / 2.0, 1.0 - t / 2.0
    else:  # 'tr'
        cx, cy = 1.0 - t / 2.0, 1.0 - t / 2.0
    squares.append((cx, cy, 0.0, t))

    # Vertical strip: width s, height t (or height 1 depending on corner).
    # For 'bl'/'br' big square at bottom: vertical strip beside it, height t.
    #   it occupies x in [t,1] (bl) at width 1-t=s, squares stacked in height t.
    # For 'tl'/'tr': vertical strip beside big square, occupying height t.
    if corner == 'bl':
        vx = t + s / 2.0
        for y in _centered_positions(kr, t):
            squares.append((vx, y, 0.0, s))
        hy = t + s / 2.0
        for j in range(kt):
            squares.append(((j + 0.5) / max(kt, 1), hy, 0.0, s))
    elif corner == 'br':
        vx = (1.0 - t) - s / 2.0
        for y in _centered_positions(kr, t):
            squares.append((vx, y, 0.0, s))
        hy = t + s / 2.0
        for j in range(kt):
            squares.append(((j + 0.5) / max(kt, 1), hy, 0.0, s))
    elif corner == 'tl':
        vx = t + s / 2.0
        for y in _centered_positions(kr, t):
            squares.append((vx, 1.0 - t + y, 0.0, s))
        hy = (1.0 - t) - s / 2.0
        for j in range(kt):
            squares.append(((j + 0.5) / max(kt, 1), hy, 0.0, s))
    else:  # 'tr'
        vx = (1.0 - t) - s / 2.0
        for y in _centered_positions(kr, t):
            squares.append((vx, 1.0 - t + y, 0.0, s))
        hy = (1.0 - t) - s / 2.0
        for j in range(kt):
            squares.append(((j + 0.5) / max(kt, 1), hy, 0.0, s))
    return squares


def _two_strip_layout(n):
    """a x b grid plus extra squares in a right strip and a top strip."""
    best = None
    best_sum = -1.0
    limit = int(math.isqrt(n)) + 3
    for a in range(1, limit + 1):
        for b in range(1, limit + 1):
            cells = a * b
            if cells > n:
                continue
            k = n - cells
            if k == 0:
                continue
            # grid in [0, b*s] x [0, a*s] with s = min(1/b,1/a) but allow
            # leftover right strip width 1-b*s and top strip height 1-a*s.
            s = min(1.0 / b, 1.0 / a)
            rw = 1.0 - b * s
            th = 1.0 - a * s
            # distribute k between right strip (kr) and top strip (kt)
            for kr in range(0, k + 1):
                kt = k - kr
                # right strip width rw, height a*s -> column of squares side
                # sr = min(rw, a*s/kr) if kr>0
                # top strip height th, width b*s -> row of squares side
                # st = min(th, b*s/kt) if kt>0
                sr = min(rw, a * s / kr) if kr > 0 else 0.0
                st = min(th, b * s / kt) if kt > 0 else 0.0
                total = cells * s + kr * sr + kt * st
                if total > best_sum:
                    sq = []
                    for i in range(a):
                        for j in range(b):
                            sq.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
                    if kr > 0:
                        xc = b * s + rw / 2.0
                        for y in _centered_positions(kr, a * s):
                            sq.append((xc, y, 0.0, sr))
                    if kt > 0:
                        yc = a * s + th / 2.0
                        for x in _centered_positions(kt, b * s):
                            sq.append((x, yc, 0.0, st))
                    best_sum = total
                    best = sq[:n]
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _refine(squares, max_iter=200):
    """Greedily try to grow the largest squares while keeping validity."""
    if not squares:
        return squares
    sq = [list(t) for t in squares]
    for _ in range(max_iter):
        improved = False
        # sort indices by current side descending, try grow each
        order = sorted(range(len(sq)), key=lambda i: -sq[i][3])
        for idx in order:
            step = sq[idx][3] * 0.05 + 1e-4
            side = sq[idx][3] + step
            if side > 1.0:
                continue
            cand = list(sq[idx])
            cand[3] = side
            if _valid(sq, idx, cand):
                sq[idx] = cand
                improved = True
        if not improved:
            break
    return [tuple(t) for t in sq]


def _corners(s):
    cx, cy, ang, side = s
    h = side / 2.0
    # axis aligned bounding box (rotation angle ignored for simplicity as these
    # layouts use angle 0)
    return (cx - h, cy - h, cx + h, cy + h)


def _valid(sq, idx, cand):
    if cand[3] <= 0:
        return True
    ax0, ay0, ax1, ay1 = _corners(cand)
    if ax0 < -1e-9 or ay0 < -1e-9 or ax1 > 1.0 + 1e-9 or ay1 > 1.0 + 1e-9:
        return False
    for j in range(len(sq)):
        if j == idx:
            continue
        bx0, by0, bx1, by1 = _corners(sq[j])
        if ax0 < bx1 - 1e-9 and bx0 < ax1 - 1e-9 and \
           ay0 < by1 - 1e-9 and by0 < ay1 - 1e-9:
            return False
    return True


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for corner in ('bl', 'br', 'tl', 'tr'):
        sq, total = _corner_layout(n, corner)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    sq, total = _two_strip_layout(n)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    refined = _refine(best)
    refined_sum = sum(t[3] for t in refined)
    if refined_sum > best_sum:
        best = refined
        best_sum = refined_sum

    return best
# EVOLVE-BLOCK-END
