# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, partial strips plus local refinement.

For perfect squares a plain grid is optimal. For other n we exploit leftover
space via grids, "strip" layouts, and a final numerical refinement that grows
individual squares while resolving overlaps.
"""
import math
import random


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append([(j + 0.5) * side, (i + 0.5) * side, 0.0, side])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append([(j + 0.5) * s, (i + 0.5) * s, 0.0, s])
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append([xc, y0 + (i + 0.5) * ss, 0.0, ss])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append([(j + 0.5) * s, (i + 0.5) * s, 0.0, s])
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append([x0 + (j + 0.5) * ss, yc, 0.0, ss])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _overlap(sq, a, b):
    """True if squares a and b (axis aligned) share interior."""
    ax, ay, aa, as_ = sq[a]
    bx, by, ba, bs = sq[b]
    # half extents (axis-aligned, ignore rotation)
    ha = as_ / 2.0
    hb = bs / 2.0
    if ha <= 0 or hb <= 0:
        return False
    return (abs(ax - bx) < ha + hb - 1e-12) and (abs(ay - by) < ha + hb - 1e-12)


def _resolve(sq, iters=40):
    """Push overlapping squares apart (axis-aligned), keep inside unit square."""
    n = len(sq)
    for _ in range(iters):
        moved = False
        for a in range(n):
            for b in range(a + 1, n):
                ax, ay, _, as_ = sq[a]
                bx, by, _, bs = sq[b]
                ha, hb = as_ / 2.0, bs / 2.0
                if ha <= 0 or hb <= 0:
                    continue
                dx = bx - ax
                dy = by - ay
                ox = (ha + hb) - abs(dx)
                oy = (ha + hb) - abs(dy)
                if ox > 1e-12 and oy > 1e-12:
                    moved = True
                    if ox < oy:
                        shift = ox / 2.0 + 1e-9
                        if dx >= 0:
                            sq[a][0] -= shift
                            sq[b][0] += shift
                        else:
                            sq[a][0] += shift
                            sq[b][0] -= shift
                    else:
                        shift = oy / 2.0 + 1e-9
                        if dy >= 0:
                            sq[a][1] -= shift
                            sq[b][1] += shift
                        else:
                            sq[a][1] += shift
                            sq[b][1] -= shift
        # clamp inside
        for s in sq:
            h = s[3] / 2.0
            if h <= 0:
                continue
            s[0] = min(max(s[0], h), 1.0 - h)
            s[1] = min(max(s[1], h), 1.0 - h)
        if not moved:
            break
    return sq


def _valid_with_growth(sq, a, new_size):
    """Check if square a can have new_size without overlapping others."""
    ax, ay, _, _ = sq[a]
    ha = new_size / 2.0
    if ha > 0.5 + 1e-9:
        return False
    if ax - ha < -1e-9 or ax + ha > 1.0 + 1e-9:
        return False
    if ay - ha < -1e-9 or ay + ha > 1.0 + 1e-9:
        return False
    n = len(sq)
    for b in range(n):
        if b == a:
            continue
        bx, by, _, bs = sq[b]
        hb = bs / 2.0
        if hb <= 0:
            continue
        if (abs(ax - bx) < ha + hb - 1e-9) and (abs(ay - by) < ha + hb - 1e-9):
            return False
    return True


def _refine(sq, rounds=6):
    """Try to grow squares one by one, resolving overlaps after each pass."""
    n = len(sq)
    best = [s[:] for s in sq]
    best_sum = sum(s[3] for s in sq)
    for _ in range(rounds):
        improved = False
        order = list(range(n))
        random.shuffle(order)
        for a in order:
            cur = sq[a][3]
            target = min(1.0, cur * 1.25 + 0.01)
            # try growing
            trial = [s[:] for s in sq]
            trial[a][3] = target
            if _valid_with_growth(trial, a, target):
                sq[a][3] = target
                improved = True
            else:
                # binary search for max feasible
                lo, hi = cur, target
                for _ in range(18):
                    mid = (lo + hi) / 2.0
                    if _valid_with_growth(sq, a, mid):
                        lo = mid
                    else:
                        hi = mid
                if lo > cur + 1e-9:
                    sq[a][3] = lo
                    improved = True
        _resolve(sq, iters=6)
        cur_sum = sum(s[3] for s in sq)
        if cur_sum > best_sum + 1e-12:
            best_sum = cur_sum
            best = [s[:] for s in sq]
        if not improved:
            break
    return best, best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345 + n)

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    # local refinement of the best structured candidate
    rsq, rtotal = _refine([s[:] for s in best])
    if rtotal > best_sum:
        best = rsq
        best_sum = rtotal

    # final validity resolution (no overlaps) preserving sizes
    best = _resolve([s[:] for s in best], iters=60)

    return [(s[0], s[1], 0.0, s[3]) for s in best]
# EVOLVE-BLOCK-END
