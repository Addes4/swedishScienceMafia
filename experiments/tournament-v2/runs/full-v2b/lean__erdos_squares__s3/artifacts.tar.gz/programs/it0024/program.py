# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips and corner-dominant layouts,
then polish the best candidate with a separating-axis overlap resolver."""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


# ---------- geometry helpers ----------

def _rot(angle):
    a = 2.0 * math.pi * angle
    return math.cos(a), math.sin(a)


def _verts(cx, cy, ang, h):
    ca, sa = _rot(ang)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _axes(vs):
    out = []
    for i in range(4):
        ex = vs[(i + 1) % 4][0] - vs[i][0]
        ey = vs[(i + 1) % 4][1] - vs[i][1]
        L = math.hypot(ex, ey)
        if L > 1e-15:
            out.append((-ey / L, ex / L))
    return out


def _overlap(a, b):
    """Return (penetration_depth, mvt_direction) if squares overlap interiors."""
    va = _verts(*a)
    vb = _verts(*b)
    min_pen = float('inf')
    min_axis = None
    for ax in _axes(va) + _axes(vb):
        pa = [(vx * ax[0] + vy * ax[1]) for vx, vy in va]
        pb = [(vx * ax[0] + vy * ax[1]) for vx, vy in vb]
        pen = min(max(pa), max(pb)) - max(min(pa), min(pb))
        if pen <= 1e-12:
            return None
        if pen < min_pen:
            min_pen = pen
            min_axis = ax
    # orient axis from a-centre to b-centre
    dx = b[0] - a[0]
    dy = b[1] - a[1]
    if min_axis[0] * dx + min_axis[1] * dy < 0:
        min_axis = (-min_axis[0], -min_axis[1])
    return min_pen, min_axis


def _in_bounds(sq):
    vs = _verts(*sq)
    for vx, vy in vs:
        if vx < -1e-9 or vx > 1.0 + 1e-9 or vy < -1e-9 or vy > 1.0 + 1e-9:
            return False
    return True


def _polish(squares, iters=60):
    """Iteratively enlarge and resolve overlaps. Returns improved list or None."""
    sq = [list(s) for s in squares]
    n = len(sq)
    if n == 0:
        return None
    best = [list(s) for s in sq]
    best_sum = sum(s[3] for s in sq)

    for _ in range(iters):
        # current sum, grow the smallest squares first
        order = sorted(range(n), key=lambda i: sq[i][3])
        # try to grow each square slightly
        for i in order:
            if sq[i][3] <= 0:
                continue
            sq[i][3] *= 1.01
        # resolve overlaps by pushing apart
        for _ in range(40):
            moved = False
            for i in range(n):
                for j in range(i + 1, n):
                    ov = _overlap(sq[i], sq[j])
                    if ov is None:
                        continue
                    pen, ax = ov
                    push = pen * 0.5 + 1e-6
                    si = sq[i][3]
                    sj = sq[j][3]
                    tot = si + sj
                    if tot <= 1e-12:
                        continue
                    wi = sj / tot
                    wj = si / tot
                    sq[i][0] -= ax[0] * push * wi
                    sq[i][1] -= ax[1] * push * wi
                    sq[j][0] += ax[0] * push * wj
                    sq[j][1] += ax[1] * push * wj
                    moved = True
            # clamp into bounds
            for i in range(n):
                if not _in_bounds(sq[i]):
                    vs = _verts(*sq[i])
                    xs = [v[0] for v in vs]
                    ys = [v[1] for v in vs]
                    dx = 0.0
                    dy = 0.0
                    if min(xs) < 0:
                        dx = -min(xs)
                    if max(xs) > 1.0:
                        dx = 1.0 - max(xs)
                    if min(ys) < 0:
                        dy = -min(ys)
                    if max(ys) > 1.0:
                        dy = 1.0 - max(ys)
                    sq[i][0] += dx
                    sq[i][1] += dy
            if not moved:
                break
        # shrink back to feasibility if still overlapping or out of bounds
        ok = True
        if any(not _in_bounds(s) for s in sq):
            ok = False
        if ok:
            for i in range(n):
                for j in range(i + 1, n):
                    if _overlap(sq[i], sq[j]) is not None:
                        ok = False
                        break
                if not ok:
                    break
        if not ok:
            break
        cur = sum(s[3] for s in sq)
        if cur > best_sum + 1e-12:
            best_sum = cur
            best = [list(s) for s in sq]
        else:
            break

    if best_sum > sum(s[3] for s in squares) + 1e-9:
        return best
    return None


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    sq, total = _corner_layout(n, 0)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    # polish
    if best is not None:
        polished = _polish(best)
        if polished is not None:
            best = polished

    return best
# EVOLVE-BLOCK-END
