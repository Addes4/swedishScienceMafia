# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips, corner-dominant layouts,
and rotated-diamond fillings of leftover gaps.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space using equal grids, strip layouts, corner-dominant layouts,
or tilted (45 degree) squares that nest into residual gaps.
"""
import math


def _valid(squares, eps=1e-9):
    """Check all squares lie in [0,1]^2 and pairwise do not overlap."""
    polys = []
    for (cx, cy, ang, s) in squares:
        if s < -eps:
            return False
        if s <= eps:
            continue
        if cx < -eps or cx > 1 + eps or cy < -eps or cy > 1 + eps:
            return False
        h = s / 2.0
        th = ang * 2.0 * math.pi
        c, sn = math.cos(th), math.sin(th)
        # corners
        pts = []
        for (dx, dy) in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x = cx + dx * c - dy * sn
            y = cy + dx * sn + dy * c
            if x < -eps or x > 1 + eps or y < -eps or y > 1 + eps:
                return False
            pts.append((x, y))
        polys.append(pts)
    # SAT overlap test between convex polygons
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            if _poly_overlap(polys[i], polys[j], eps):
                return False
    return True


def _poly_overlap(a, b, eps):
    for poly in (a, b):
        n = len(poly)
        for k in range(n):
            x1, y1 = poly[k]
            x2, y2 = poly[(k + 1) % n]
            ax, ay = -(y2 - y1), (x2 - x1)
            # project both
            amin = amax = None
            for (px, py) in a:
                d = px * ax + py * ay
                if amin is None or d < amin:
                    amin = d
                if amax is None or d > amax:
                    amax = d
            bmin = bmax = None
            for (px, py) in b:
                d = px * ax + py * ay
                if bmin is None or d < bmin:
                    bmin = d
                if bmax is None or d > bmax:
                    bmax = d
            if amax <= bmin + eps or bmax <= amin + eps:
                return False
    return True


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout_v(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s_max = 1.0
        if kr > 0:
            s_max = min(s_max, 1.0 / (kr + 1))
        if kt > 0:
            s_max = min(s_max, 1.0 / kt)
        s_max = min(s_max, 0.5)
        if s_max <= 0:
            continue
        s = s_max
        t = 1.0 - s
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            if _valid(squares):
                best_sum = total
                best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _tilted_gap_layout(n):
    """Big square in a corner (side t), the remaining L-region split into two
    strips (right column and top row). Along the inner corner of the L we
    place one or more 45-degree rotated squares that nest diagonally into the
    residual gap, boosting total length.
    """
    m = n - 1
    best = None
    best_sum = -1.0
    # big square bottom-left; right strip width w_r, top strip height h_t
    for kt in range(0, m + 1):          # squares along top row
        kr = m - kt                      # squares in right column
        for kr_tilt in range(0, min(kr, 3) + 1):
            kr_axis = kr - kr_tilt
            # geometry: right strip occupies [t,1] x [0,t], width = 1-t.
            # axis squares of side s in right strip: s <= 1-t, kr_axis*s<=t
            # tilted squares of 45deg: bounding box is d = side*sqrt2.
            # place them stacked in right strip too.
            # top row: kt squares across width 1, side s, height <= 1-t
            # choose s to maximize.
            # Crude joint search over s then set t = 1 - s if needed.
            # We use: t is big square side. right strip width = 1-t.
            # For simplicity assume all strip squares same side s.
            # constraints:
            #   s <= 1 - t                          (fit in strip width)
            #   (kr_axis + kr_tilt)*s <= t ... only if stacked axis-aligned
            #   kt * s <= 1
            # maximize t + m*s.
            # push t = 1 - s (top strip fully used): kr_axis*s <= t and
            # kt*s<=1
            s_max = 1.0
            if kt > 0:
                s_max = min(s_max, 1.0 / kt)
            if kr_axis > 0:
                s_max = min(s_max, 1.0 / (kr_axis + 1))
            if kr_tilt > 0:
                # tilted squares: side s has footprint ~s*sqrt2 in the strip;
                # height s*sqrt2 each stacked; must fit in t and width 1-t
                s_max = min(s_max, 1.0 / (1.0 + kr_tilt * math.sqrt(2.0)))
            s_max = min(s_max, 0.5)
            if s_max <= 1e-9:
                continue
            s = s_max
            t = 1.0 - s
            if t <= 0:
                continue
            total = t + m * s
            if total <= best_sum:
                continue
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            # right column axis squares
            for y in _centered_positions(kr_axis, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            # right column tilted squares (45 deg), stacked above axis ones
            # place them centered horizontally in right strip
            xc = t + (1.0 - t) / 2.0
            diag = s * math.sqrt(2.0)
            base = sum(1.0 for _ in range(kr_axis)) * (t / max(kr_axis, 1)) if kr_axis else 0.0
            y_cur = base
            ok = True
            for _ in range(kr_tilt):
                yc = y_cur + diag / 2.0
                if yc + diag / 2.0 > t + 1e-9:
                    ok = False
                    break
                squares.append((xc, yc, 0.125, s))
                y_cur += diag
            if not ok:
                continue
            # top row squares
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            while len(squares) < n:
                squares.append((0.5, 0.5, 0.0, 0.0))
            squares = squares[:n]
            if _valid(squares):
                best_sum = total
                best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    sq, total = _corner_layout_v(n, 0)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    sq, total = _tilted_gap_layout(n)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    return best
# EVOLVE-BLOCK-END
