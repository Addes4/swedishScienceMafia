# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids and partial strips.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: either a grid of equal squares whose count exceeds n, or a
"strip" layout where one row/column contains fewer, larger squares that
stretch into the leftover region. We also try L-shaped leftovers where both
a right strip and a top strip hold larger squares.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _l_layout(n, rows, cols, kc, kr):
    """a x b grid at bottom-left, kc squares in right strip, kr in top strip.

    The grid occupies [0, b*s]x[0, a*s].  The right strip of width
    strip_w = b2*s (where the strip squares are of side b2*s) ... we instead
    parameterize: strip squares side = sw in right strip, sh in top strip.
    The right strip spans width sw and height a*s, holding kc squares stacked.
    The top strip spans height sh and width (cols*s + sw), holding kr squares.
    We require kc*sw <= a*s (height of right strip) is NOT needed; instead the
    right strip squares stacked vertically need kc*sw <= a*s and sw<=sw.
    """
    if kc < 0 or kr < 0:
        return None, -1.0
    if kc == 0 and kr == 0:
        return None, -1.0
    if rows < 1 or cols < 1:
        return None, -1.0
    # base grid side s from rows x cols
    s = min(1.0 / cols, 1.0 / rows)
    grid_w = cols * s
    grid_h = rows * s
    # right strip width available = 1 - grid_w, but its height constrained by
    # top strip: right strip occupies y in [0, grid_h], full height of grid.
    right_w_avail = 1.0 - grid_w
    top_h_avail = 1.0 - grid_h
    if kc > 0 and right_w_avail <= 1e-12:
        return None, -1.0
    if kr > 0 and top_h_avail <= 1e-12:
        return None, -1.0
    # choose right strip side sw and top strip side sh.
    # right strip: kc squares stacked, side sw <= right_w_avail, kc*sw <= grid_h
    # top strip: kr squares in a row of width grid_w + sw, side sh,
    #           sh <= top_h_avail, kr*sh <= grid_w + sw
    # Optimize: try sw values.
    best = None
    best_total = -1.0
    # candidate sw: right_w_avail, grid_h/kc
    sw_cands = []
    if kc > 0:
        sw_cands.append(right_w_avail)
        sw_cands.append(grid_h / kc)
        sw_cands.append(min(right_w_avail, grid_h / kc))
    else:
        sw_cands.append(0.0)
    for sw in sw_cands:
        if sw < 0:
            continue
        if kc > 0 and (sw > right_w_avail + 1e-12 or kc * sw > grid_h + 1e-12):
            continue
        width_for_top = grid_w + (sw if kc > 0 else 0.0)
        if kr > 0:
            sh = min(top_h_avail, width_for_top / kr)
        else:
            sh = 0.0
        if kr > 0 and sh <= 1e-12:
            continue
        total = rows * cols * s + kc * sw + kr * sh
        if total > best_total:
            best_total = total
            best = (s, sw, sh, kc, kr)
    if best is None:
        return None, -1.0
    s, sw, sh, kc, kr = best
    grid_w = cols * s
    grid_h = rows * s
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    # right strip: kc squares of side sw, stacked, left edge at grid_w
    if kc > 0 and sw > 1e-12:
        xc = grid_w + sw / 2.0
        used_h = kc * sw
        y0 = (grid_h - used_h) / 2.0
        for i in range(kc):
            squares.append((xc, y0 + (i + 0.5) * sw, 0.0, sw))
    # top strip: kr squares of side sh, in a row, bottom edge at grid_h
    if kr > 0 and sh > 1e-12:
        width_for_top = grid_w + (sw if kc > 0 else 0.0)
        used_w = kr * sh
        x0 = (width_for_top - used_w) / 2.0
        yc = grid_h + sh / 2.0
        for j in range(kr):
            squares.append((x0 + (j + 0.5) * sh, yc, 0.0, sh))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    return squares, best_total


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    # L-shaped leftovers: grid + right strip + top strip
    for r in range(1, limit + 2):
        for c in range(1, limit + 2):
            grid_cells = r * c
            if grid_cells > n:
                continue
            rem = n - grid_cells
            if rem < 1:
                continue
            for kc in range(0, rem + 1):
                kr = rem - kc
                sq, total = _l_layout(n, r, c, kc, kr)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    return best
# EVOLVE-BLOCK-END
