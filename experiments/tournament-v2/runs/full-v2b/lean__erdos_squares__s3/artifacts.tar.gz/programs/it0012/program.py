# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips, corner-dominant layouts,
and a general two-region (strip + grid) splitter with refined strip sizing."""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    """rows x cols grid, but the last column holds 'extra' larger squares."""
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    """rows x cols grid, last row has fewer, larger squares in leftover height."""
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _two_region(n):
    """General two-region splitter.

    Split the unit square by a horizontal cut at height h.
    * Bottom region [0,1]x[0,h]: pack k equal squares of side a.
      Best row arrangement: a = min(1/k, h) with squares in a single row
      (a = min(1/k, h)), OR stack them in p rows of q columns (a=min(1/q,h/p)).
    * Top region [0,1]x[h,1] of height (1-h): pack r*c = n-k equal squares of
      side s = min(1/c, (1-h)/r).
    Search k, and for the grid region all (r,c); choose h to maximize
    k*a + (n-k)*s. Also do the transposed (vertical cut) version.
    """
    best = None
    best_sum = -1.0
    limit = int(math.isqrt(n)) + 3

    for k in range(1, n):
        gc = n - k
        # grid region options for gc squares
        grid_opts = []
        for r in range(1, limit + 1):
            for c in range(1, limit + 1):
                if r * c == gc:
                    grid_opts.append((r, c))
        if not grid_opts:
            continue
        # strip region: pack k squares of side a in height h (full width 1)
        # options for strip packing: p rows, q cols with p*q>=k, side=min(1/q,h/p)
        strip_opts = []
        for p in range(1, k + 1):
            q = (k + p - 1) // p
            strip_opts.append((p, q))
        # also single row / single column variants covered above

        # For each (strip p,q) and (grid r,c), find best h numerically.
        # strip side a(h) = min(1/q, h/p)  (increasing in h until h=p/q)
        # grid side s(h) = min(1/c, (1-h)/r)
        # total = k*a + gc*s ; a increases, s decreases -> scan.
        for (p, q) in strip_opts:
            a_cap = 1.0 / q
            for (r, c) in grid_opts:
                s_cap = 1.0 / c
                # For h in [0,1]: a = min(a_cap, h/p); s = min(s_cap,(1-h)/r)
                # Try the kink points exactly plus a scan.
                cand_h = set()
                cand_h.add(0.0)
                cand_h.add(1.0)
                cand_h.add(p * a_cap)          # h where strip saturates
                cand_h.add(1.0 - r * s_cap)    # h where grid saturates
                # crossings
                for hh in (0.0, 1.0):
                    cand_h.add(hh)
                for h in list(cand_h):
                    cand_h.add(min(max(h, 0.0), 1.0))
                # finer scan
                steps = 200
                for i in range(steps + 1):
                    cand_h.add(i / steps)

                for h in cand_h:
                    if h < 0.0 or h > 1.0:
                        continue
                    a = min(a_cap, h / p)
                    if (1.0 - h) < 0:
                        continue
                    s = min(s_cap, (1.0 - h) / r)
                    if a <= 0 or s <= 0:
                        continue
                    total = k * a + gc * s
                    if total > best_sum:
                        sq = _build_two_region(n, k, p, q, r, c, h, a, s, transpose=False)
                        if sq is not None:
                            best_sum = total
                            best = sq

    # transposed version: vertical cut at width w, left region strip, right grid
    for k in range(1, n):
        gc = n - k
        grid_opts = []
        for r in range(1, limit + 1):
            for c in range(1, limit + 1):
                if r * c == gc:
                    grid_opts.append((r, c))
        if not grid_opts:
            continue
        strip_opts = []
        for p in range(1, k + 1):
            q = (k + p - 1) // p
            strip_opts.append((p, q))
        for (p, q) in strip_opts:
            a_cap = 1.0 / q
            for (r, c) in grid_opts:
                s_cap = 1.0 / c
                steps = 200
                for i in range(steps + 1):
                    w = i / steps
                    a = min(a_cap, w / p)
                    s = min(s_cap, (1.0 - w) / r)
                    if a <= 0 or s <= 0:
                        continue
                    total = k * a + gc * s
                    if total > best_sum:
                        sq = _build_two_region(n, k, p, q, r, c, w, a, s, transpose=True)
                        if sq is not None:
                            best_sum = total
                            best = sq

    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _build_two_region(n, k, p, q, r, c, cut, a, s, transpose):
    """Build the packing: strip region of k squares side a in first strip
    (rows p, cols q, side a), grid region of gc=n-k squares side s (rows r,
    cols c). cut is the strip thickness along the split axis."""
    squares = []

    def place_grid(x0, y0, w, hh, rr, cc, side):
        # rr x cc grid inside rect [x0,x0+w] x [y0,y0+hh]
        if rr * cc <= 0:
            return
        cw = side
        ch = side
        ox = (w - cc * cw) / 2.0
        oy = (hh - rr * ch) / 2.0
        for i in range(rr):
            for j in range(cc):
                cx = x0 + ox + (j + 0.5) * cw
                cy = y0 + oy + (i + 0.5) * ch
                squares.append((cx, cy, 0.0, side))

    if not transpose:
        # bottom strip of height cut, then top region
        # strip: p rows, q cols, side a, inside [0,1]x[0,cut]
        place_grid(0.0, 0.0, 1.0, cut, p, q, a)
        place_grid(0.0, cut, 1.0, 1.0 - cut, r, c, s)
    else:
        # left strip of width cut
        place_grid(0.0, 0.0, cut, 1.0, q, p, a)
        place_grid(cut, 0.0, 1.0 - cut, 1.0, c, r, s)

    if len(squares) < n:
        return None
    # validate non-overlap roughly (strip vs grid by construction).
    return squares[:n]


def _validate(squares):
    boxes = []
    for (cx, cy, ang, side) in squares:
        if side <= 1e-12:
            continue
        th = ang * 2 * math.pi
        co, si = math.cos(th), math.sin(th)
        h = side / 2.0
        corners = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            corners.append((cx + dx * co - dy * si, cy + dx * si + dy * co))
        boxes.append(corners)
    # crude SAT overlap check
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            if _overlap(boxes[i], boxes[j]):
                return False
    return True


def _overlap(A, B):
    def axes(P):
        ax = []
        for i in range(len(P)):
            x1, y1 = P[i]
            x2, y2 = P[(i + 1) % len(P)]
            ax.append((-(y2 - y1), x2 - x1))
        return ax

    def proj(P, ax):
        d = [x * ax[0] + y * ax[1] for (x, y) in P]
        return min(d), max(d)

    for ax in axes(A) + axes(B):
        n = math.hypot(*ax)
        if n < 1e-15:
            continue
        ax = (ax[0] / n, ax[1] / n)
        a1, a2 = proj(A, ax)
        b1, b2 = proj(B, ax)
        if a2 <= b1 + 1e-9 or b2 <= a1 + 1e-9:
            return False
    return True


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout,):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    sq, total = _two_region(n)
    if sq is not None and total > best_sum and _validate(sq):
        best_sum = total
        best = sq

    return best
# EVOLVE-BLOCK-END
