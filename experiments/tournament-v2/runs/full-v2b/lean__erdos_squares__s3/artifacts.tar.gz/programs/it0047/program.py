# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, shelf (guillotine) layouts,
corner-dominant layouts, recursive guillotine partitions, and a final
continuous scale/push refinement to squeeze out extra side length.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _shelf_layout(n, shelves):
    k = len(shelves)
    if k == 0:
        return None, -1.0
    best = None
    best_sum = -1.0
    for mask in range(1 << k):
        widths = [1.0] * k
        fixed = 0.0
        free = 0
        for i in range(k):
            if mask >> i & 1:
                widths[i] = 1.0 / shelves[i]
                fixed += widths[i]
            else:
                free += 1
        rem = 1.0 - fixed
        if rem < -1e-9:
            continue
        if free > 0:
            h = rem / free
            if h < -1e-9:
                continue
            for i in range(k):
                if not (mask >> i & 1):
                    widths[i] = h
        sizes = []
        ok = True
        for i in range(k):
            c = shelves[i]
            if c <= 0:
                ok = False
                break
            if mask >> i & 1:
                sizes.append(1.0 / c)
            else:
                if widths[i] > 1.0 / c + 1e-9:
                    ok = False
                    break
                sizes.append(widths[i])
        if not ok:
            continue
        total = sum(c * s for c, s in zip(shelves, sizes))
        if total > best_sum:
            squares = []
            y = 1.0
            for i in range(k):
                c = shelves[i]
                s = sizes[i]
                h = widths[i]
                y -= h
                yc = y + h / 2.0
                for j in range(c):
                    xc = (j + 0.5) / c
                    squares.append((xc, yc, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    for first in range(1, n - k + 2):
        for rest in _compositions(n - first, k - 1):
            yield (first,) + rest


def _grid_rect(rect, count):
    if count <= 0:
        return [], 0.0
    x0, y0, w, h = rect
    best = None
    best_total = -1.0
    best_side = 0.0
    lim = int(math.isqrt(count)) + 2
    for r in range(1, lim + 1):
        for c in range(1, lim + 1):
            if r * c < count:
                continue
            s = min(w / c, h / r)
            total = s * count
            if total > best_total:
                best_total = total
                best_side = s
                best = (r, c)
    if best is None:
        return [], 0.0
    r, c = best
    s = best_side
    squares = []
    for i in range(r):
        for j in range(c):
            if len(squares) >= count:
                break
            squares.append((x0 + (j + 0.5) * s, y0 + (i + 0.5) * s, 0.0, s))
    return squares, best_total


def _guillotine_value(n, w, h, depth):
    sq, total = _grid_rect((0.0, 0.0, w, h), n)
    if depth <= 0 or n <= 1:
        return total, sq, (0.0, 0.0, w, h)
    best_total = total
    best_sq = sq
    for k in range(1, n):
        rest = n - k
        for orient in (0, 1):
            if orient == 0:
                def val(ratio):
                    lw = w * ratio
                    rw = w - lw
                    t1, _, _ = _guillotine_value(k, lw, h, depth - 1)
                    t2, _, _ = _guillotine_value(rest, rw, h, depth - 1)
                    return t1 + t2
            else:
                def val(ratio):
                    lh = h * ratio
                    rh = h - lh
                    t1, _, _ = _guillotine_value(k, w, lh, depth - 1)
                    t2, _, _ = _guillotine_value(rest, w, rh, depth - 1)
                    return t1 + t2
            lo, hi = 0.02, 0.98
            for _ in range(40):
                m1 = lo + (hi - lo) / 3.0
                m2 = hi - (hi - lo) / 3.0
                if val(m1) < val(m2):
                    lo = m1
                else:
                    hi = m2
            ratio = (lo + hi) / 2.0
            if orient == 0:
                lw = w * ratio
                rw = w - lw
                t1, s1, _ = _guillotine_value(k, lw, h, depth - 1)
                t2, s2, _ = _guillotine_value(rest, rw, h, depth - 1)
                if t1 + t2 > best_total:
                    best_total = t1 + t2
                    shifted = [(x + lw, y, a, si) for (x, y, a, si) in s2]
                    best_sq = s1 + shifted
            else:
                lh = h * ratio
                rh = h - lh
                t1, s1, _ = _guillotine_value(k, w, lh, depth - 1)
                t2, s2, _ = _guillotine_value(rest, w, rh, depth - 1)
                if t1 + t2 > best_total:
                    best_total = t1 + t2
                    shifted = [(x, y + lh, a, si) for (x, y, a, si) in s2]
                    best_sq = s1 + shifted
    return best_total, best_sq, (0.0, 0.0, w, h)


def _guillotine(n, rect, depth):
    x0, y0, w, h = rect
    total, sq, _ = _guillotine_value(n, w, h, depth)
    shifted = [(x + x0, y + y0, a, si) for (x, y, a, si) in sq]
    return shifted, total


def _refine(sq):
    """Continuous refinement: keep axis-aligned squares, try to increase the
    total by a greedy per-square enlargement that only accepts strictly
    feasible moves, then do a uniform scale-up using leftover slack."""
    sq = [list(s) for s in sq if s[3] > 1e-12]
    if not sq:
        return sq

    def ok_all(cand):
        # cand: list [cx, cy, angle, side]
        for cx, cy, a, s in cand:
            if s <= 1e-12:
                return False
            h = s / 2.0
            if cx - h < -1e-9 or cx + h > 1.0 + 1e-9:
                return False
            if cy - h < -1e-9 or cy + h > 1.0 + 1e-9:
                return False
        for i in range(len(cand)):
            cx1, cy1, a1, s1 = cand[i]
            h1 = s1 / 2.0
            for j in range(i + 1, len(cand)):
                cx2, cy2, a2, s2 = cand[j]
                h2 = s2 / 2.0
                if abs(cx1 - cx2) < h1 + h2 - 1e-9 and abs(cy1 - cy2) < h1 + h2 - 1e-9:
                    return False
        return True

    improved = True
    it = 0
    while improved and it < 40:
        improved = False
        it += 1
        # try growing each square about its center by small step
        for i in range(len(sq)):
            for step in (0.02, 0.01, 0.005, 0.001):
                grow = sq[i][3] * (1.0 + step)
                old = sq[i][3]
                sq[i][3] = grow
                if ok_all(sq):
                    improved = True
                else:
                    sq[i][3] = old
        # try nudging each square in 4 directions
        for i in range(len(sq)):
            for dx, dy in ((0.002, 0.0), (-0.002, 0.0), (0.0, 0.002), (0.0, -0.002)):
                ox, oy = sq[i][0], sq[i][1]
                sq[i][0] += dx
                sq[i][1] += dy
                if ok_all(sq):
                    improved = True
                else:
                    sq[i][0], sq[i][1] = ox, oy

    # final uniform scale-up if there is global slack
    lo, hi = 1.0, 1.0
    # find minimal bounding extent to see if we can scale
    minx = min(s[0] - s[3] / 2.0 for s in sq)
    maxx = max(s[0] + s[3] / 2.0 for s in sq)
    miny = min(s[1] - s[3] / 2.0 for s in sq)
    maxy = max(s[1] + s[3] / 2.0 for s in sq)
    w = maxx - minx
    h = maxy - miny
    if w > 1e-9 and h > 1e-9:
        C = min(1e9, min(1.0 / w, 1.0 / h))
    else:
        C = 1e9
    if C > 1.0:
        # scale about bounding box center, then translate to fit
        cx0 = (minx + maxx) / 2.0
        cy0 = (miny + maxy) / 2.0
        for s in sq:
            s[0] = cx0 + (s[0] - cx0) * C
            s[1] = cy0 + (s[1] - cy0) * C
            s[3] = s[3] * C
        # translate into [0,1]
        minx = min(s[0] - s[3] / 2.0 for s in sq)
        maxx = max(s[0] + s[3] / 2.0 for s in sq)
        miny = min(s[1] - s[3] / 2.0 for s in sq)
        maxy = max(s[1] + s[3] / 2.0 for s in sq)
        tx = 0.5 - (minx + maxx) / 2.0
        ty = 0.5 - (miny + maxy) / 2.0
        # clamp shift so nothing leaves [0,1]
        if minx + tx < 0:
            tx = -minx
        if maxx + tx > 1:
            tx = 1.0 - maxx
        if miny + ty < 0:
            ty = -miny
        if maxy + ty > 1:
            ty = 1.0 - maxy
        for s in sq:
            s[0] += tx
            s[1] += ty
    return sq


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    sq, total = _corner_layout(n, 0)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    max_shelves = min(n, 5)
    for k in range(1, max_shelves + 1):
        for comp in _compositions(n, k):
            sq, total = _shelf_layout(n, list(comp))
            if sq is not None and total > best_sum:
                best_sum = total
                best = sq

    for depth in (1, 2):
        sq, total = _guillotine(n, (0.0, 0.0, 1.0, 1.0), depth)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n

    # continuous refinement
    try:
        refined = _refine(best)
        rsum = sum(s[3] for s in refined)
        if rsum > best_sum + 1e-9:
            best = refined
            best_sum = rsum
    except Exception:
        pass

    best = [(float(x), float(y), float(a), float(s)) for (x, y, a, s) in best]
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
# EVOLVE-BLOCK-END
