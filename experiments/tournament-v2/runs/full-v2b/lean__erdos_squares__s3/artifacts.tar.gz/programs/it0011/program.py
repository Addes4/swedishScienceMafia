# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips, corner layouts and
row+grid layouts."""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _row_grid_layout(n):
    """Bottom strip with kr equal squares of side a placed side by side
    (occupying the full width, height a). Top region of height 1-a tiled by
    an r x c grid of equal squares of side s = min(1/c, (1-a)/r).
    Count: kr + r*c = n. Also transposed (left column + right grid)."""
    best = None
    best_sum = -1.0
    for kr in range(1, n):
        rc = n - kr
        if rc < 1:
            continue
        # bottom strip: kr squares across width 1 -> a <= 1/kr
        for r in range(1, rc + 1):
            if rc % r != 0:
                continue
            c = rc // r
            # choose a: bottom squares of side a, need kr*a<=1 -> a<=1/kr
            # top grid side s = min(1/c, (1-a)/r); maximize kr*a + rc*s
            # a in [0, 1/kr]
            def total_of(a):
                if a < 0 or a > 1.0 / kr + 1e-15:
                    return -1.0
                s = min(1.0 / c, (1.0 - a) / r)
                if s <= 0:
                    return -1.0
                return kr * a + rc * s
            # total_of is piecewise linear in a; optimum at breakpoints
            cands = [0.0, 1.0 / kr]
            # where (1-a)/r == 1/c -> a = 1 - r/c
            a_break = 1.0 - r / float(c)
            cands.append(a_break)
            best_a = None
            best_t = -1.0
            for a in cands:
                a = max(0.0, min(a, 1.0 / kr))
                tt = total_of(a)
                if tt > best_t:
                    best_t = tt
                    best_a = a
            a = best_a
            if a is None or a <= 0:
                continue
            s = min(1.0 / c, (1.0 - a) / r)
            if s <= 0:
                continue
            total = kr * a + rc * s
            if total > best_sum:
                squares = []
                for j in range(kr):
                    squares.append(((j + 0.5) / kr, a / 2.0, 0.0, a))
                for i in range(r):
                    for j in range(c):
                        squares.append(((j + 0.5) * s,
                                        a + (i + 0.5) * s, 0.0, s))
                best_sum = total
                best = squares
        # transposed: left column + right grid
        for r in range(1, rc + 1):
            if rc % r != 0:
                continue
            c = rc // r
            def total_of_v(a):
                if a < 0 or a > 1.0 / kr + 1e-15:
                    return -1.0
                s = min(1.0 / c, (1.0 - a) / r)
                if s <= 0:
                    return -1.0
                return kr * a + rc * s
            cands = [0.0, 1.0 / kr, 1.0 - r / float(c)]
            best_a = None
            best_t = -1.0
            for a in cands:
                a = max(0.0, min(a, 1.0 / kr))
                tt = total_of_v(a)
                if tt > best_t:
                    best_t = tt
                    best_a = a
            a = best_a
            if a is None or a <= 0:
                continue
            s = min(1.0 / c, (1.0 - a) / r)
            if s <= 0:
                continue
            total = kr * a + rc * s
            if total > best_sum:
                squares = []
                for j in range(kr):
                    squares.append((a / 2.0, (j + 0.5) / kr, 0.0, a))
                for i in range(r):
                    for j in range(c):
                        squares.append((a + (j + 0.5) * s,
                                        (i + 0.5) * s, 0.0, s))
                best_sum = total
                best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    sq, total = _corner_layout(n, 0)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    sq, total = _row_grid_layout(n)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    return best
# EVOLVE-BLOCK-END
