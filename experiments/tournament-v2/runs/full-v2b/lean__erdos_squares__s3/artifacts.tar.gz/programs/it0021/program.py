# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, corner layouts, then polish with a
validated continuous local search that enlarges squares into leftover space."""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s = 1.0
        if kr > 0:
            s = min(s, 1.0 / (kr + 1))
        if kt > 0:
            s = min(s, 1.0 / kt)
        s = min(s, 0.5)
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0 or s <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


# ---------- validated geometry helpers ----------

def _corners(x, y, a, s):
    ca = math.cos(2 * math.pi * a)
    sa = math.sin(2 * math.pi * a)
    h = s / 2.0
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((x + dx * ca - dy * sa, y + dx * sa + dy * ca))
    return pts


def _overlap(sq1, sq2):
    p1 = _corners(*sq1)
    p2 = _corners(*sq2)
    for poly, other in ((p1, p2), (p2, p1)):
        for i in range(len(poly)):
            ax = poly[i]
            bx = poly[(i + 1) % len(poly)]
            nx = -(bx[1] - ax[1])
            ny = (bx[0] - ax[0])
            mn1 = min(p[0] * nx + p[1] * ny for p in poly)
            mx1 = max(p[0] * nx + p[1] * ny for p in poly)
            mn2 = min(p[0] * nx + p[1] * ny for p in other)
            mx2 = max(p[0] * nx + p[1] * ny for p in other)
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return False
    return True


def _valid(pack):
    for x, y, a, s in pack:
        if s <= 0:
            continue
        h = s / 2.0
        c = math.cos(2 * math.pi * a)
        si = math.sin(2 * math.pi * a)
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            px = x + dx * c - dy * si
            py = y + dx * si + dy * c
            if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                return False
    m = len(pack)
    for i in range(m):
        for j in range(i + 1, m):
            if pack[i][3] <= 0 or pack[j][3] <= 0:
                continue
            if _overlap(pack[i], pack[j]):
                return False
    return True


def _clip(pack):
    """Return pack with squares individually clipped to the unit square."""
    out = []
    for x, y, a, s in pack:
        out.append((min(max(x, 0.0), 1.0), min(max(y, 0.0), 1.0), a, s))
    return out


def _polish(pack, iters=400, seed=12345):
    """Validated coordinate-ascent: enlarge the smallest squares, jitter to
    relieve overlaps. Accept only valid improving / neutral moves."""
    import random
    rng = random.Random(seed)
    cur = _clip([tuple(p) for p in pack])
    if not _valid(cur):
        # attempt to shrink all a hair to gain validity
        cur = [(x, y, a, s) for (x, y, a, s) in cur]
    best = [tuple(p) for p in cur]
    best_sum = sum(p[3] for p in best)

    import time
    t0 = time.time()
    step = 0
    while step < iters and time.time() - t0 < 0.6:
        step += 1
        idx = min(range(len(cur)), key=lambda i: cur[i][3])
        x, y, a, s = cur[idx]
        moved = False
        for ds in (0.02, 0.01, 0.005, 0.002, 0.001):
            cand = (x, y, a, s + ds)
            trial = cur[:]
            trial[idx] = cand
            if _valid(trial):
                cur = trial
                moved = True
                break
        if not moved:
            # small random jitter of centre / angle to open space
            for _ in range(6):
                dx = rng.uniform(-0.02, 0.02)
                dy = rng.uniform(-0.02, 0.02)
                da = rng.uniform(-0.02, 0.02)
                trial = cur[:]
                trial[idx] = (x + dx, y + dy, (a + da) % 1.0, s)
                if _valid(trial):
                    cur = trial
                    break
        tot = sum(p[3] for p in cur)
        if tot > best_sum + 1e-12:
            best_sum = tot
            best = [tuple(p) for p in cur]
    return best, best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    sq, total = _corner_layout(n, 0)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    # Polish the top few distinct seeds; keep the best validated result.
    seeds = [best]
    # also seed a plain grid of the right count
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c >= n:
                sq2, tot2 = _equal_grid(n, r, c)
                seeds.append(sq2)
                break
        else:
            continue
        break

    polished, psum = _polish(best)
    if psum > best_sum and _valid(polished):
        best = polished
        best_sum = psum

    if not _valid(best):
        # fallback: shrink into a guaranteed valid grid
        best, _ = _equal_grid(n, int(math.isqrt(n)) + 1, int(math.isqrt(n)) + 1)
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))
        best = best[:n]

    return best
# EVOLVE-BLOCK-END
