# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips and corner-dominant layouts.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: either a grid of equal squares whose count exceeds n, or a
"strip" layout where one row/column contains fewer, larger squares that
stretch into the leftover region, or a corner-dominant layout.  A final
continuous polish step (SLSQP) refines the best candidate.
"""
import math

try:
    import numpy as np
    from scipy.optimize import minimize
    _HAVE_SCIPY = True
except Exception:
    _HAVE_SCIPY = False


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout_v(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s_max = 1.0
        if kr > 0:
            s_max = min(s_max, 1.0 / (kr + 1))
        if kt > 0:
            s_max = min(s_max, 1.0 / kt)
        s_max = min(s_max, 0.5)
        if s_max <= 0:
            continue
        s = s_max
        t = 1.0 - s
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


# ---------------- geometry helpers ----------------

def _corners(cx, cy, ang, s):
    """Return the 4 corners of a square (full-turn fraction angle)."""
    th = ang * 2.0 * math.pi
    c, si = math.cos(th), math.sin(th)
    h = s / 2.0
    pts = []
    for dx, dy in ((h, h), (h, -h), (-h, -h), (-h, h)):
        pts.append((cx + dx * c - dy * si, cy + dx * si + dy * c))
    return pts


def _rect_axes(ang):
    th = ang * 2.0 * math.pi
    c, si = math.cos(th), math.sin(th)
    u = (c, si)
    v = (-si, c)
    return u, v


def _proj(pts, axis):
    vals = [px * axis[0] + py * axis[1] for px, py in pts]
    return min(vals), max(vals)


def _overlap_amount(sq_a, sq_b):
    """Positive min-translation overlap using separating axis theorem."""
    ax, ay, aa, sa = sq_a
    bx, by, ba, sb = sq_b
    pa = _corners(ax, ay, aa, sa)
    pb = _corners(bx, by, ba, sb)
    axes = list(_rect_axes(aa)) + list(_rect_axes(ba))
    min_overlap = float('inf')
    for axis in axes:
        lo_a, hi_a = _proj(pa, axis)
        lo_b, hi_b = _proj(pb, axis)
        ov = min(hi_a, hi_b) - max(lo_a, lo_b)
        if ov <= 0:
            return -1.0  # separated
        if ov < min_overlap:
            min_overlap = ov
    return min_overlap


def _valid(squares, tol=1e-9):
    n = len(squares)
    for i in range(n):
        x, y, a, s = squares[i]
        if s < -tol:
            return False
        if not (-tol <= x <= 1 + tol and -tol <= y <= 1 + tol):
            return False
        if s > 1 + tol:
            return False
        # inside unit square
        for px, py in _corners(x, y, a, s):
            if px < -1e-7 or px > 1 + 1e-7 or py < -1e-7 or py > 1 + 1e-7:
                return False
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap_amount(squares[i], squares[j]) > 1e-9:
                return False
    return True


def _polish(squares, time_budget_iters=200):
    if not _HAVE_SCIPY:
        return squares
    n = len(squares)
    if n <= 1:
        return squares

    def unpack(z):
        out = []
        for i in range(n):
            out.append((z[4 * i], z[4 * i + 1], z[4 * i + 2], z[4 * i + 3]))
        return out

    def objective(z):
        return -sum(z[4 * i + 3] for i in range(n))

    # constraints: for each pair, overlap <= 0 -> use SAT min-translation
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]

    def make_con(i, j):
        def con(z):
            a = (z[4 * i], z[4 * i + 1], z[4 * i + 2], z[4 * i + 3])
            b = (z[4 * j], z[4 * j + 1], z[4 * j + 2], z[4 * j + 3])
            return -_overlap_amount(a, b)  # >= 0 means separated
        return con

    cons = [{'type': 'ineq', 'fun': make_con(i, j)} for i, j in pairs]

    z0 = []
    bounds = []
    for (x, y, a, s) in squares:
        z0.extend([x, y, a, s])
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((0.05, 1.0))
    z0 = np.array(z0, dtype=float)

    try:
        res = minimize(objective, z0, method='SLSQP', bounds=bounds,
                       constraints=cons,
                       options={'maxiter': 60, 'ftol': 1e-9})
        cand = unpack(res.x)
        if _valid(cand):
            cur_sum = sum(sq[3] for sq in squares)
            new_sum = sum(sq[3] for sq in cand)
            if new_sum > cur_sum + 1e-7:
                return cand
    except Exception:
        pass
    return squares


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout_v,):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    # continuous polish of best candidate
    if best is not None and n <= 60:
        polished = _polish(best)
        if polished is not None:
            ps = sum(sq[3] for sq in polished)
            if ps > best_sum + 1e-7 and _valid(polished):
                best = polished

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0) for _ in range(n)]
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
# EVOLVE-BLOCK-END
