# EVOLVE-BLOCK-START
"""Pack n squares using grids, mixed grids, strips and corner-dominant layouts."""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_big_rect(n):
    """Big square side t in bottom-left corner, remaining m=n-1 small equal
    squares of side s placed as an r x c grid filling the region x>t OR y>t.

    Key idea: the small squares fill the rectangle [t,1] x [0,1] (right strip)
    and [0,t] x [t,1] (top strip). Choose t so the tightest fit works.
    """
    m = n - 1
    best = None
    best_sum = -1.0
    # split m into kr (right, height 1) and kt (top, width t) -- but top region
    # is [0,t]x[t,1], so kt squares across width t:   kt*s <= t ; height s<=1-t
    # right region [t,1]x[0,1]: columns c: c*s <= 1-t, rows kr/c: (kr/c)*s <= 1
    for kr in range(0, m + 1):
        kt = m - kr
        # right strip: choose c columns. try all column counts
        for c in range(1, kr + 1) if kr > 0 else [0]:
            if kr > 0:
                rows_r = (kr + c - 1) // c
                s_r = min((1.0 - 1e-9), 1.0)
                # solve: c*s <= 1-t, rows_r*s <= 1, s <= 1-t
                # and top: kt*s <= t (if kt>0), s <= 1-t
                # Maximize t + m*s. Set t = 1 - s (tightest top bound) when kt>0
                # and r constraint c*s <= 1-t = s -> c*s<=s impossible unless c<=1
                pass
    # Simpler robust approach: exhaustive scan over t and grid shape.
    ts = [i / 400.0 for i in range(1, 400)]
    for t in ts:
        # right strip [t,1]x[0,1], top strip [0,t]x[t,1] (disjoint)
        rw = 1.0 - t  # right width
        th = 1.0 - t  # top height
        # candidate: put jr squares in right strip (grid), jt in top strip
        for jr in range(0, m + 1):
            jt = m - jr
            # right strip as c x rr grid: side = min(rw/c, 1/rr)
            sr = 0.0
            if jr > 0:
                for c in range(1, jr + 1):
                    rr = (jr + c - 1) // c
                    sr = max(sr, min(rw / c, 1.0 / rr))
            # top strip as ct x rt grid within width t, height th
            st = 0.0
            if jt > 0:
                for ct in range(1, jt + 1):
                    rt = (jt + ct - 1) // ct
                    st = max(st, min(t / ct, th / rt))
            # need a single common small size? allow different sizes: total
            if jr > 0 and jt > 0:
                ss = min(sr, st)
                tot = t + jr * ss + jt * ss
            elif jr > 0:
                ss = sr
                tot = t + jr * ss
            elif jt > 0:
                ss = st
                tot = t + jt * ss
            else:
                ss = 0.0
                tot = t
            if tot > best_sum:
                best_sum = tot
                squares = [(t / 2.0, t / 2.0, 0.0, t)]
                if jr > 0:
                    # find best c for jr
                    bc, bsr = 1, 0.0
                    for c in range(1, jr + 1):
                        rr = (jr + c - 1) // c
                        val = min(rw / c, 1.0 / rr)
                        if val > bsr:
                            bsr, bc = val, c
                    rr = (jr + bc - 1) // bc
                    for idx in range(jr):
                        ci = idx % bc
                        ri = idx // bc
                        squares.append((t + (ci + 0.5) * bsr,
                                        (ri + 0.5) * bsr, 0.0, bsr))
                    ss_use = min(bsr, st) if jt > 0 else bsr
                else:
                    ss_use = st
                if jt > 0:
                    bct, bst = 1, 0.0
                    for ct in range(1, jt + 1):
                        rt = (jt + ct - 1) // ct
                        val = min(t / ct, th / rt)
                        if val > bst:
                            bst, bct = val, ct
                    ss_use = min(ss_use, bst) if jr > 0 else bst
                    squares = squares[:1]
                    if jr > 0:
                        bc = 1
                        bsr = 0.0
                        for c in range(1, jr + 1):
                            rr = (jr + c - 1) // c
                            val = min(rw / c, 1.0 / rr)
                            if val > bsr:
                                bsr, bc = val, c
                        rr = (jr + bc - 1) // bc
                        for idx in range(jr):
                            ci = idx % bc
                            ri = idx // bc
                            squares.append((t + (ci + 0.5) * ss_use,
                                            (ri + 0.5) * ss_use, 0.0, ss_use))
                    rt = (jt + bct - 1) // bct
                    for idx in range(jt):
                        ci = idx % bct
                        ri = idx // bct
                        squares.append(((ci + 0.5) * ss_use,
                                        t + (ri + 0.5) * ss_use, 0.0, ss_use))
                    tot = t + jr * ss_use + jt * ss_use
                    if tot > best_sum:
                        best_sum = tot
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    sq, total = _corner_big_rect(n)
    if sq is not None and total > best_sum:
        best_sum = total
        best = sq

    if best is None:
        best = _equal_grid(n, 1, n)[0]
    return best
# EVOLVE-BLOCK-END
