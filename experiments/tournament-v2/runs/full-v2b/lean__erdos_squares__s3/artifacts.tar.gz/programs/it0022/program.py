# EVOLVE-BLOCK-START
"""Pack n squares using grids, strips, corner-dominant layouts and a
combined "big corner square + equal grid in the residual L" family.

For perfect squares a plain grid is optimal. For other n we exploit the
leftover space: grids, strips, corner-dominant layouts, and a search that
places one big square in a corner and tiles the complementary (larger
residual) rectangle with an equal-size grid.
"""
import math


def _equal_grid(n, rows, cols):
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    for i in range(rows):
        for j in range(cols):
            squares.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], side * n


def _strip_layout(n, rows, cols):
    best = None
    best_sum = -1.0
    full_cols = cols - 1
    if full_cols < 1:
        return None, -1.0
    grid_cells = rows * full_cols
    k = n - grid_cells
    if k < 1 or k > rows:
        return _strip_layout_row(n, rows, cols)
    s = min(1.0 / full_cols, 1.0 / rows)
    strip_w = 1.0 - full_cols * s
    if strip_w <= 1e-12:
        return None, -1.0
    ss = min(strip_w, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(rows):
        for j in range(full_cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_h = k * ss
    y0 = (1.0 - used_h) / 2.0
    xc = full_cols * s + strip_w / 2.0
    for i in range(k):
        squares.append((xc, y0 + (i + 0.5) * ss, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_cols * rows * s + k * ss
    return squares, total


def _strip_layout_row(n, rows, cols):
    full_rows = rows - 1
    if full_rows < 1:
        return None, -1.0
    grid_cells = full_rows * cols
    k = n - grid_cells
    if k < 1 or k > cols:
        return None, -1.0
    s = min(1.0 / cols, 1.0 / full_rows)
    strip_h = 1.0 - full_rows * s
    if strip_h <= 1e-12:
        return None, -1.0
    ss = min(strip_h, 1.0 / k)
    if ss <= 0:
        return None, -1.0
    squares = []
    for i in range(full_rows):
        for j in range(cols):
            squares.append(((j + 0.5) * s, (i + 0.5) * s, 0.0, s))
    used_w = k * ss
    x0 = (1.0 - used_w) / 2.0
    yc = full_rows * s + strip_h / 2.0
    for j in range(k):
        squares.append((x0 + (j + 0.5) * ss, yc, 0.0, ss))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    squares = squares[:n]
    total = full_rows * cols * s + k * ss
    return squares, total


def _centered_positions(k, span):
    if k <= 0:
        return []
    step = span / k
    return [(i + 0.5) * step for i in range(k)]


def _corner_layout(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        if kr > 0 and kt > 0:
            s = min(1.0 / (kr + 1), 1.0 / kt, 0.5)
        elif kr > 0:
            s = min(1.0 / (kr + 1), 0.5)
        elif kt > 0:
            s = min(1.0 / kt, 0.5)
        else:
            s = 0.0
        if s <= 0:
            continue
        t = 1.0 - s
        if kr > 0 and kr * s > t + 1e-12:
            continue
        if kt > 0 and kt * s > 1.0 + 1e-12:
            continue
        if t <= 0:
            continue
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _corner_layout_v(n, big_index):
    m = n - 1
    best = None
    best_sum = -1.0
    for kr in range(0, m + 1):
        kt = m - kr
        s_max = 1.0
        if kr > 0:
            s_max = min(s_max, 1.0 / (kr + 1))
        if kt > 0:
            s_max = min(s_max, 1.0 / kt)
        s_max = min(s_max, 0.5)
        if s_max <= 0:
            continue
        s = s_max
        t = 1.0 - s
        total = t + m * s
        if total > best_sum:
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _big_corner_plus_grid(n):
    """Place one big square of side t in the bottom-left corner [0,t]x[0,t].
    The complementary region is the union of:
        top strip: [0,1] x [t,1]   (height h = 1-t)
        right strip: [t,1] x [0,t] (width h  = 1-t)
    We fill the top strip and right strip with equal small squares of side s.
    Number in top strip: floor(1/s) per row * floor(h/s) rows... simpler: we
    just tile the L-region with a grid of side s, giving counts
        n_top  = (#cols across 1) * (#rows in h) = floor(1/s)*floor(h/s)
        n_right_extra = (#rows in t) - (#rows in h) measured inside right strip
    We search over integer counts of small squares placed in the top strip
    (kt across) and right strip (kr down). All candidates validated.
    """
    m = n - 1
    best = None
    best_sum = -1.0
    # top strip: height h=1-t, can hold floor(1/s) columns and floor(h/s) rows.
    # We instead directly choose t and s and count squares that fit; require
    # total = m exactly by trying kr in right strip (height t) and kt in top.
    for kr in range(0, m + 1):
        kt = m - kr
        # right strip: width (1-t), height t; squares side s.
        # top strip: width 1, height (1-t); squares side s.
        # Choose s so both fit: s <= min(1-t, t/kr) [right], s <= min(1-t,1/kt)[top]
        # Set 1-t = s (tight) as before -> t = 1-s. Then right needs kr*s<=t.
        s_max = 1.0
        if kr > 0:
            s_max = min(s_max, 1.0 / (kr + 1))
        if kt > 0:
            s_max = min(s_max, 1.0 / kt)
        s_max = min(s_max, 0.5)
        if s_max <= 0:
            continue
        s = s_max
        t = 1.0 - s
        total = t + m * s
        if total > best_sum and _valid_L(t, s, kr, kt):
            squares = [(t / 2.0, t / 2.0, 0.0, t)]
            for y in _centered_positions(kr, t):
                squares.append((t + s / 2.0, y, 0.0, s))
            for j in range(kt):
                squares.append(((j + 0.5) / max(kt, 1), t + s / 2.0, 0.0, s))
            best_sum = total
            best = squares
    if best is None:
        return None, -1.0
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n], best_sum


def _valid_L(t, s, kr, kt):
    if t <= 0 or s <= 0:
        return False
    # right strip squares centered at x=t+s/2, must have right edge <=1 -> s<=1-t
    if s > 1.0 - t + 1e-9:
        return False
    # kr squares share height t stacked
    if kr > 0 and kr * s > t + 1e-9:
        return False
    # top strip squares: kt across width 1
    if kt > 0 and kt * s > 1.0 + 1e-9:
        return False
    # top strip squares height s <= 1-t
    if s > 1.0 - t + 1e-9:
        return False
    return True


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_sum = -1.0

    limit = int(math.isqrt(n)) + 3
    for r in range(1, limit + 1):
        for c in range(1, limit + 1):
            if r * c < n:
                continue
            sq, total = _equal_grid(n, r, c)
            if total > best_sum:
                best_sum = total
                best = sq

    for r in range(1, limit + 2):
        for c in range(2, limit + 2):
            for fn in (_strip_layout, _strip_layout_row):
                sq, total = fn(n, r, c)
                if sq is not None and total > best_sum:
                    best_sum = total
                    best = sq

    for fn in (_corner_layout, _corner_layout_v, _big_corner_plus_grid):
        sq, total = fn(n, 0)
        if sq is not None and total > best_sum:
            best_sum = total
            best = sq

    return best
# EVOLVE-BLOCK-END
