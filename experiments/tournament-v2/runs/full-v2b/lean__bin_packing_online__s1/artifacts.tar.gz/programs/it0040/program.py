# EVOLVE-BLOCK-START
"""Best-fit refined by a stateful, mean-item-size-aware wastage penalty."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0


_state = _State()


def priority(item, bins):
    """Rank bins by best-fit score plus a smooth wastage penalty.

    The penalty is largest for residuals that are a bit smaller than a typical
    future item, since such gaps waste capacity; very small or reasonably large
    residuals are penalized less.
    """
    s = _state
    # Update running mean of observed item sizes.
    s.n += 1
    s.mean += (item - s.mean) / s.n
    m = s.mean

    residual = (bins - item).astype(np.float64)
    score = -residual

    # Wastage: gaps that can't quite hold a typical item are costly.
    # w peaks when residual is about m/2 (too small for a typical item but
    # still large enough to fragment), decays for tiny and large residuals.
    r = residual
    # smooth bump centered slightly below the mean item size
    center = 0.55 * m
    width = 0.5 * m
    bump = np.exp(-((r - center) ** 2) / (2.0 * width * width))
    # only consider residuals that are actually smaller than a typical item
    below = (r < m) & (r >= 1)
    score -= 6.0 * bump * below

    return score
# EVOLVE-BLOCK-END
