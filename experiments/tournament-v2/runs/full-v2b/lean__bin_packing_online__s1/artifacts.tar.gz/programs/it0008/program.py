# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware residual bonus.

Track a running histogram of seen item sizes. Score each candidate bin by
tightness of fit (residual after placement) plus a bonus proportional to how
well the residual matches historically common item sizes. This nudges the
packer to leave residuals that later items can fill, reducing fragmentation.
"""
import numpy as np

# Histogram over the 101 possible item sizes; updated online.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    global _COUNT
    # Update histogram with the arriving item (past information only).
    _HIST[item] += 1.0
    _COUNT += 1
    if _COUNT == 1:
        weights = np.ones(101, dtype=np.float64)
    else:
        weights = _HIST / _COUNT
    # Prefer residuals matching likely future items.
    # For a bin with remaining capacity b, residual after placing = b - item.
    residual = bins - item  # >= 0 for all shown bins
    # Bonus: how likely future items equal this residual (small residual -> easy to fill).
    bonus = weights[np.clip(residual, 0, 100)]
    return -residual.astype(np.float64) + 30.0 * bonus
# EVOLVE-BLOCK-END
