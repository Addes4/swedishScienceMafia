# EVOLVE-BLOCK-START
"""Best-fit plus an expected-future-wastage penalty estimated online."""
import numpy as np

_CAP = 100
_counts = np.zeros(_CAP + 1, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Rank bins: prefer tight fits, penalize leftovers unlikely to be reused."""
    global _total
    # Update an online histogram of item sizes seen so far.
    _counts[item] += 1.0
    _total += 1.0

    residual = bins - item

    # Base: tight fit is good (small residual -> high score).
    score = -residual.astype(np.float64)

    # Estimate probability that a future item exactly fills the residual,
    # using the empirical distribution of past item sizes. Exact/near-exact
    # reusable leftovers get a bonus; unusable slivers get penalized.
    probs = _counts / _total
    # A leftover of size r can still be usefully used if some item equals r.
    fill_prob = probs[np.clip(residual, 0, _CAP)]

    # Reward residuals that match (or nearly match) observed item sizes.
    score += 12.0 * fill_prob

    # Penalize tiny unusable slivers that are very unlikely to be filled.
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver

    return score
# EVOLVE-BLOCK-END
