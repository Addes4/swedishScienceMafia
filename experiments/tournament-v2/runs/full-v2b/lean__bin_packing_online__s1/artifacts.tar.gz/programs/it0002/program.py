# EVOLVE-BLOCK-START
"""Bounded best-fit: treat any bin that leaves a small residual as equally tight,
then prefer the emptiest among them to preserve flexibility."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    # Bounded best fit: residuals within `slack` of the minimum tight fit are seen as
    # equivalent, and among those we prefer the bin with the largest remaining capacity
    # (emptiest) to keep small-residual bins available for future large items.
    valid = resid >= 0
    slack = 15
    # priority: dominant term ensures best fit; secondary term adjusts within the band
    return -resid + (bins * 0) - (valid * 0) - np.where(resid <= slack, -1e-3 * bins, 0.0)
# EVOLVE-BLOCK-END
