# EVOLVE-BLOCK-START
"""Best-fit with mean-adaptive sliver penalty, complement bonus, exact-fill reward,
and a min-item-size hard-waste term."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_min_item = 100


def priority(item, bins):
    global _hist, _n, _sum, _mean, _min_item
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n
    if item < _min_item:
        _min_item = item

    residual = bins - item
    score = -residual.astype(np.float64)

    exact = (residual == 0)
    score += 12.0 * exact

    thr = 0.5 * _mean
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    # Hard-waste: residual below the smallest item ever seen cannot be refilled,
    # so penalize it more than an ordinary sliver of equal size.
    if _min_item > 1:
        hard = (residual >= 1) & (residual < _min_item)
        score -= 6.0 * hard

    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0

    if _n > 20.0:
        score += 2.0 * np.exp(-((residual - _mean) ** 2) / (2.0 * 12.0 ** 2))

    return score
# EVOLVE-BLOCK-END
