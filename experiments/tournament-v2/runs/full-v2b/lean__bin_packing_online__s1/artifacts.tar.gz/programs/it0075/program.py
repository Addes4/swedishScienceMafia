# EVOLVE-BLOCK-START
"""Best-fit with mean-adaptive sliver penalty and historical fillability bonus."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Mean-adaptive sliver penalty: residual too small to likely be refilled
    # wastes capacity. Threshold scales with typical item size.
    thr = 0.5 * _mean
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    # Soft bonus for residuals in a still-useful mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Historical fillability: reward residual r by the frequency of past items
    # that could fit into it (size <= r), emphasising exact/near completions.
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        # cumulative mass of items with size <= r
        csum = np.cumsum(_hist)  # csum[k] = mass of sizes <= k
        total = csum[100] + 1e-9
        fits = csum[res_clipped] / total  # prob next item fits in residual
        score += 6.0 * fits

        # exact completion: past items that exactly match the residual
        exact = _hist[res_clipped] / total
        score += 30.0 * exact

    return score
# EVOLVE-BLOCK-END

