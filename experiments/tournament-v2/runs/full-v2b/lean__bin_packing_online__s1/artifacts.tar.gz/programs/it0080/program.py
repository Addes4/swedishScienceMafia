# EVOLVE-BLOCK-START
"""Best-fit with mean-adaptive sliver penalty, complement bonus, exact-fill reward,
and smallest-item-size fillability bonus."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean, and smallest item seen.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_min_item = 100


def priority(item, bins):
    global _hist, _n, _sum, _mean, _min_item
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n
    if item < _min_item:
        _min_item = item

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    exact = (residual == 0)
    score += 12.0 * exact

    # Mean-adaptive sliver penalty: residual too small to likely be refilled
    # wastes capacity. Threshold scales with typical item size.
    thr = 0.5 * _mean
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    # Soft bonus for residuals in a still-useful mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Stateful complement bonus: reward residuals that can be filled exactly
    # by a recently common item size (wider +/-2 window).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0

    # Pairing bonus: reward residuals close to the running mean item size,
    # since such a bin is likely to be topped off by a single typical item.
    if _n > 20.0:
        score += 2.0 * np.exp(-((residual - _mean) ** 2) / (2.0 * 12.0 ** 2))

    # Smallest-item fillability bonus: leftovers that are small multiples of the
    # smallest item seen are cheaply completable by the most flexible filler.
    if _min_item > 0:
        m = _min_item
        fillable = (residual == m) | (residual == 2 * m) | (residual == 3 * m)
        score += 1.0 * fillable

    return score
# EVOLVE-BLOCK-END
