# EVOLVE-BLOCK-START
"""Best-fit with mean-adaptive sliver penalty, empirical small-item floor,
a multi-item capacity bonus, recent-item pair-complement signals, and a
histogram-based pair-sum complement signal."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean, the previous item size, and a short
# rolling window of recent item sizes.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_prev = 0.0
_recent = np.zeros(8, dtype=np.float64)  # ring of last few items
_recent_idx = 0


def priority(item, bins):
    global _hist, _n, _sum, _mean, _prev, _recent, _recent_idx
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    exact = (residual == 0)
    score += 16.0 * exact

    # Empirical thresholds from the smoothed histogram of past items.
    if _n > 30.0:
        total = _hist.sum() + 1e-9
        cum = np.cumsum(_hist)
        small_thr = float(np.searchsorted(cum, 0.15 * total))
        if small_thr < 1.0:
            small_thr = 1.0
        sliver_thr = float(np.searchsorted(cum, 0.20 * total))
        if sliver_thr < 1.0:
            sliver_thr = 1.0
    else:
        small_thr = max(1.0, 0.5 * _mean)
        sliver_thr = max(1.0, 0.5 * _mean)

    # Data-driven sliver penalty: residual too small to likely be refilled.
    thr = sliver_thr
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    # Residuals below the empirical smallest plausible item are truly
    # unfillable; penalize in proportion to how far below they fall.
    unfillable = (residual >= 1) & (residual < small_thr)
    if unfillable.any():
        score -= 3.0 * unfillable * (small_thr - residual)

    # Multi-item capacity bonus: a bin whose residual can still hold several
    # typical items is more reusable; modest reward with diminishing returns.
    typical = 0.5 * _mean
    if typical < 1.0:
        typical = 1.0
    kfit = np.floor(np.maximum(residual, 0) / typical)
    score += 1.2 * np.sqrt(kfit)

    # Stateful complement bonus: reward residuals fillable exactly by a common
    # item size (wider +/-2 window).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0
        score += 3.0 * (freq / total) * 100.0

        # Pair-complement bonus using a short rolling window of recent items.
        if _n > 8.0:
            accum = np.zeros_like(res_clipped, dtype=np.float64)
            for w in range(_recent.shape[0]):
                want = int(round(_recent[w]))
                if want < 1:
                    continue
                cand = np.clip(res_clipped - want, 0, 100).astype(np.int64)
                accum += _hist[cand]
            score += 1.8 * (accum / total) * 100.0

        # Pair-sum complement bonus: residual close to (current item + a
        # common past item size).
        comp = res_clipped - int(item)
        if comp.size:
            cclip = np.clip(comp, 0, 100).astype(np.int64)
            pair_sum = _hist[cclip]
            score += 1.5 * (pair_sum / total) * 100.0

        # Near-miss penalty: residual r just below a frequent item size s
        # (r < s <= r + delta) wastes the gap that s cannot fill. Weighted by s
        # frequency; smaller than before to avoid double-counting with sliver.
        s1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        s2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        near_miss = 0.5 * s1 + 0.4 * s2
        score -= 1.2 * (near_miss / total) * 100.0 * (residual > 0)

    _prev = float(item)
    _recent[_recent_idx % _recent.shape[0]] = float(item)
    _recent_idx += 1
    return score
# EVOLVE-BLOCK-END
