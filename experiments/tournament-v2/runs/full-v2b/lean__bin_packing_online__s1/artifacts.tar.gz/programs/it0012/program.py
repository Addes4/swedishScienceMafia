# EVOLVE-BLOCK-START
"""Best fit with a light, learned preference for residuals that match common item sizes."""
import numpy as np

# Persistent state: exponential-decay histogram of observed item sizes.
_hist = np.zeros(101, dtype=np.float64)
_decay = 0.995


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist

    # Update the running histogram with the new item.
    _hist *= _decay
    _hist[item] += 1.0

    residual = bins - item  # remaining capacity after placing the item here

    # Base: best fit (smallest residual is best).
    score = -residual.astype(np.float64)

    # Small bonus for residuals that match commonly seen item sizes,
    # so that partially filled bins stay fillable later.
    # p[size] is the recent relative frequency of item size `size`.
    total = _hist.sum()
    if total > 0.0:
        probs = _hist / total
        # Clamp residual indices to valid range; residuals are in [0, 100].
        idx = np.clip(residual, 0, 100).astype(np.int64)
        # For residual r, reward how likely a future item fits exactly (size == r).
        match = probs[idx]
        score += 0.35 * match

    return score
# EVOLVE-BLOCK-END
