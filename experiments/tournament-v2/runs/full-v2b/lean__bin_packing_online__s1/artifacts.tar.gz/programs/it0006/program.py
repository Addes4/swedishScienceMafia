# EVOLVE-BLOCK-START
"""Best fit with small-item packing preference (modified best fit)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (tightest fit first)
    score = -residual.astype(np.float64)
    # For small items, mildly prefer partially-filled bins with lots of free space
    # (avoid stuffing small items into nearly full bins, which wastes their flexibility).
    small = item <= 15
    if small:
        partial = bins < 100
        score += 0.001 * (100 - bins) * partial
    return score
# EVOLVE-BLOCK-END
