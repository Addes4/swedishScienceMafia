# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty, exact-fill reward, and histogram-mode completion bonus."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_mode = 40


def priority(item, bins):
    global _hist, _n, _sum, _mean, _mode
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    # Track the most frequent recent item size (histogram mode over 1..100).
    _mode = int(np.argmax(_hist[1:101])) + 1

    residual = bins - item
    score = -residual.astype(np.float64)

    # Exact-fill reward: strictly optimal, wastes nothing.
    exact = (residual == 0)
    score += 12.0 * exact

    # Sliver penalty: residuals too small to likely be refilled.
    thr = 0.5 * _mean
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    # Completion bonus: reward residuals that the most common item size
    # (the mode) can exactly fill, since that is the most likely single
    # item to close this bin. Scale by how dominant the mode is.
    if _n > 20.0:
        total = _hist.sum() + 1e-9
        mode_share = _hist[_mode] / total
        match = (residual == _mode)
        score += (3.0 + 30.0 * mode_share) * match
        near = (residual == _mode - 1) | (residual == _mode + 1)
        score += (1.0 + 10.0 * mode_share) * near

    return score
# EVOLVE-BLOCK-END

