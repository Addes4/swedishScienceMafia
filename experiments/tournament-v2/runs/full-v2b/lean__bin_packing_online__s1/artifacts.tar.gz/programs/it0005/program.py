# EVOLVE-BLOCK-START
"""Best fit with a tiny bin-index tie-break penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest wins, ties go to first bin.

    Primary criterion: residual capacity after placing the item (best fit).
    Tiny secondary penalty on bin index only affects exact residual ties.
    """
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    residual = (bins - item).astype(np.float64)
    # Tiny penalty on bin index; magnitude far below 1 so it only breaks exact ties.
    return -residual - 1e-9 * idx
# EVOLVE-BLOCK-END
