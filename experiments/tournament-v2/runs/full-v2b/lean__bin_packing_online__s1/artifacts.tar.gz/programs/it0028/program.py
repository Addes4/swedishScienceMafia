# EVOLVE-BLOCK-START
"""Best-fit with an adaptive residual-quality penalty learned online."""
import numpy as np


class _State:
    def __init__(self):
        self.hist = np.zeros(101, dtype=np.float64)  # counts of item sizes
        self.n = 0
        self.mean = 40.0

    def update(self, item):
        self.hist[item] += 1.0
        self.n += 1
        # running mean with mild blending
        self.mean += (item - self.mean) / max(self.n, 1)


_state = _State()


def priority(item, bins):
    """Rank bins: prefer tight fits, but penalize leftovers that waste capacity.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    residual = bins - item  # leftover capacity if placed here
    # Base: tight fit is good (small residual -> high score)
    score = -residual.astype(np.float64)

    # Adaptive sliver threshold: gaps below a fraction of the mean item size
    # are unlikely to be filled, so they waste capacity.
    mean = _state.mean
    sliver_hi = max(6.0, min(20.0, 0.4 * mean))

    sliver = (residual >= 1) & (residual <= sliver_hi)
    score -= 8.0 * sliver

    # Slight bonus for residuals that can still accept a typical item.
    useful_lo = max(30.0, 0.85 * mean)
    useful_hi = min(70.0, 1.6 * mean)
    useful = (residual >= useful_lo) & (residual <= useful_hi)
    score += 1.5 * useful

    _state.update(int(item))
    return score
# EVOLVE-BLOCK-END

