# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty plus a clean future-fill probability bonus."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    exact = (residual == 0)
    score += 10.0 * exact

    # Mean-adaptive sliver penalty: residual too small to likely be refilled
    # wastes capacity. Threshold scales with typical item size.
    thr = 0.5 * _mean
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    # Soft bonus for residuals in a still-useful mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Clean future-fill bonus: reward residuals that are a plausible size for
    # a future item, so the bin can be topped off. Uses the decayed histogram
    # directly (probability the next item equals this residual), with mild
    # +/-1 smoothing to avoid overfitting exact values.
    if _n > 20.0:
        total = _hist.sum() + 1e-9
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        nearby = freq + 0.5 * (lo1 + hi1)
        score += 6.0 * (nearby / total) * 100.0

    return score
# EVOLVE-BLOCK-END

