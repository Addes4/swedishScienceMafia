# EVOLVE-BLOCK-START
"""Best-fit with mean-adaptive sliver penalty, empirical small-item floor,
a multi-item capacity bonus, previous-item pair-complement, a
histogram-based pair-sum complement signal, and a refill-success signal."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean, and the previous item size.
# Also track which residual capacities got refilled by a later item.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_prev = 0.0
_cum = None  # cached cumulative distribution of past items
# Counts of residual values that were later exactly refilled by an item.
_refill = np.zeros(101, dtype=np.float64)
_prev_residual = 0  # residual left by the previous placement (item's fit)


def priority(item, bins):
    global _hist, _n, _sum, _mean, _prev, _cum, _refill, _prev_residual
    # If the previous placement left a residual that this item now exactly
    # fills, record that the residual value "item" is refillable.
    if 1 <= int(item) <= 100 and _prev_residual == int(item):
        _refill[int(item)] += 1.0
    _refill *= 0.999

    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    exact = (residual == 0)
    score += 16.0 * exact

    # Empirical "smallest plausible item": the 15th-percentile item size seen
    # so far.
    if _n > 30.0:
        total = _hist.sum() + 1e-9
        cum = np.cumsum(_hist)
        small_thr = float(np.searchsorted(cum, 0.15 * total))
        if small_thr < 1.0:
            small_thr = 1.0
        sliver_thr = float(np.searchsorted(cum, 0.20 * total))
        if sliver_thr < 1.0:
            sliver_thr = 1.0
    else:
        small_thr = max(1.0, 0.5 * _mean)
        sliver_thr = max(1.0, 0.5 * _mean)

    # Data-driven sliver penalty.
    thr = sliver_thr
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    # Residuals below the empirical smallest plausible item are truly
    # unfillable; penalize in proportion.
    unfillable = (residual >= 1) & (residual < small_thr)
    if unfillable.any():
        score -= 3.0 * unfillable * (small_thr - residual)

    # Multi-item capacity bonus.
    typical = 0.5 * _mean
    if typical < 1.0:
        typical = 1.0
    kfit = np.floor(np.maximum(residual, 0) / typical)
    score += 1.2 * np.sqrt(kfit)

    # Stateful complement bonus: reward residuals that can be filled exactly
    # by a recently common item size (wider +/-2 window).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0
        # Sharper bonus for an exact match to a common item size.
        score += 3.0 * (freq / total) * 100.0

        # Pair-complement bonus for the previous item.
        if _prev >= 1.0:
            want = _prev
            cand = np.clip(res_clipped - want, 0, 100).astype(np.int64)
            pair_freq = _hist[cand]
            score += 2.0 * (pair_freq / total) * 100.0

        # Pair-sum complement bonus.
        comp = res_clipped - int(item)
        if comp.size:
            cclip = np.clip(comp, 0, 100).astype(np.int64)
            pair_sum = _hist[cclip]
            score += 1.5 * (pair_sum / total) * 100.0

        # Refill-success bonus: reward residuals whose value has empirically
        # been exactly refilled by a later item, signalling genuine reuse.
        refill_total = _refill.sum() + 1e-9
        rfreq = _refill[res_clipped]
        rlo = _refill[np.clip(res_clipped - 1, 0, 100)]
        rhi = _refill[np.clip(res_clipped + 1, 0, 100)]
        rnear = rfreq + 0.5 * (rlo + rhi)
        score += 3.0 * (rnear / refill_total) * 100.0

    # Dead-space penalty.
    if _n > 50.0:
        dead = (residual >= 1) & (residual < typical)
        score -= 1.0 * dead * np.maximum(0.0, 1.0 - 0.5 * _mean / np.maximum(_mean, 1.0))

    # Expected-waste penalty.
    if _n > 40.0:
        cum = np.cumsum(_hist)
        total_hist = cum[-1] + 1e-9
        res_int = np.clip(residual, 0, 100).astype(np.int64)
        p_larger = 1.0 - cum[np.clip(res_int - 1, 0, 100)] / total_hist
        p_larger = np.clip(p_larger, 0.0, 1.0)
        score -= 2.0 * p_larger * (residual > 0)

    _prev = float(item)
    # Record the residual this placement would leave (best-scoring bin).
    if bins.size:
        best_idx = int(np.argmax(score))
        _prev_residual = int(bins[best_idx] - item)
    return score
# EVOLVE-BLOCK-END
