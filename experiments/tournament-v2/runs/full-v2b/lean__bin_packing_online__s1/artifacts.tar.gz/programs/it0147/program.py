# EVOLVE-BLOCK-START
"""Best-fit with mean-adaptive sliver penalty, a stable minimum-size estimate,
an exact-fill reward, a same-item bonus, and a near-residual frequency
complement signal."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_prev = 0.0
_min_seen = 100.0
_recent = np.zeros(8, dtype=np.float64)
_recent_idx = 0


def priority(item, bins):
    global _hist, _n, _sum, _mean, _prev, _min_seen, _recent, _recent_idx
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n
    if item < _min_seen:
        _min_seen = item

    residual = bins - item
    score = -residual.astype(np.float64)

    total_hist = _hist.sum() + 1e-9

    # Exact-fill reward weighted by how common the just-filled size is.
    exact = (residual == 0)
    if exact.any():
        freq_here = float(_hist[min(max(item, 0), 100)]) / total_hist
        score += (10.0 + 12.0 * freq_here * 100.0 / 5000.0) * exact

    # Stable "small item" threshold: use the minimum size seen so far, which
    # is a robust lower bound on what can ever fill a small residual.
    if _n > 30.0:
        small_thr = max(1.0, float(_min_seen))
    else:
        small_thr = max(1.0, 0.5 * _mean)

    # Sliver penalty: residual below the smallest plausible item wastes space.
    sliver = (residual >= 1) & (residual < small_thr)
    if sliver.any():
        score -= 8.0 * sliver * (small_thr - residual)

    # Same-item bonus.
    same = (residual == item)
    if same.any():
        score += 1.5 * same

    # Multi-item capacity bonus.
    typical = 0.5 * _mean
    if typical < 1.0:
        typical = 1.0
    kfit = np.floor(np.maximum(residual, 0) / typical)
    score += 1.2 * np.sqrt(kfit)

    # Near-residual frequency complement signal (sharp, low-noise).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0
        score += 3.0 * (freq / total) * 100.0

    _prev = float(item)
    _recent[_recent_idx % _recent.shape[0]] = float(item)
    _recent_idx += 1
    return score
# EVOLVE-BLOCK-END

