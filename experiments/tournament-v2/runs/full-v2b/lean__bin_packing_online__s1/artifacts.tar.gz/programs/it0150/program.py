# EVOLVE-BLOCK-START
"""Best-fit with exact-fill reward, empirical sliver penalty, and a single
calibrated expected-waste term. Reduced overlapping signals to avoid the
noisy collisions that hurt recent experiments."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item
    res = residual.astype(np.float64)
    score = -res

    total = _hist.sum() + 1e-9

    # Exact fill: strictly best, slightly weighted by how common the size is.
    exact = (residual == 0)
    if exact.any():
        freq_here = float(_hist[item]) / total
        score += (8.0 + 6.0 * np.sqrt(freq_here)) * exact

    # Empirical thresholds.
    cum = np.cumsum(_hist)
    if _n > 30.0:
        small_thr = float(np.searchsorted(cum, 0.15 * total))
        sliver_thr = float(np.searchsorted(cum, 0.25 * total))
    else:
        small_thr = max(1.0, 0.5 * _mean)
        sliver_thr = max(1.0, 0.5 * _mean)
    small_thr = max(1.0, small_thr)
    sliver_thr = max(1.0, sliver_thr)

    # Sliver penalty: residual too small to likely be refilled.
    sliver = (residual >= 1) & (residual < sliver_thr)
    score -= 6.0 * sliver

    # Unfillable penalty, proportional to how far below the small threshold.
    unfillable = (residual >= 1) & (residual < small_thr)
    if unfillable.any():
        score -= 4.0 * unfillable * (small_thr - res)

    # Single calibrated expected-waste term: probability that no future item
    # fits into this residual, scaled by remaining size.
    if _n > 40.0:
        res_int = np.clip(residual, 0, 100).astype(np.int64)
        p_larger = 1.0 - cum[np.clip(res_int - 1, 0, 100)] / total
        p_larger = np.clip(p_larger, 0.0, 1.0)
        score -= 1.5 * p_larger * (residual > 0) * np.sqrt(res + 1.0)

    # Small same-item bonus: stacking identical sizes.
    same = (residual == item)
    if same.any():
        score += 1.0 * same

    return score
# EVOLVE-BLOCK-END
