# EVOLVE-BLOCK-START
"""Best fit with a residual-usefulness correction driven by a seen-item histogram."""
import numpy as np

# Histogram of item sizes seen so far (index 1..100), shared across calls.
_SIZE_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Score each bin by tightness plus expected future usefulness of its residual."""
    global _TOTAL
    # Update running distribution of item sizes.
    _SIZE_HIST[item] += 1.0
    _TOTAL += 1.0

    # Residual after placing the item in each candidate bin.
    residual = bins - item  # >= 0 for all shown bins

    # Probability that a future item fits exactly into a residual of size r:
    # estimate P(next item <= r) from the empirical histogram.
    cdf = np.cumsum(_SIZE_HIST) / _TOTAL
    # cdf[r] gives approximate probability that a future item is <= r.
    r_clipped = np.clip(residual, 0, 100).astype(np.int64)
    p_fit = cdf[r_clipped]

    # Prefer tight fits (small residual) but reward residuals that are likely
    # to accept a future item (high p_fit) when the residual is large.
    # Dominant term keeps best-fit behavior; correction is small.
    score = -(residual.astype(np.float64)) + 3.0 * p_fit * (residual >= item)
    return score
# EVOLVE-BLOCK-END
