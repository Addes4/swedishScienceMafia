# EVOLVE-BLOCK-START
"""Best-fit with histogram-based fillability, complement, and pairing bonuses."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean, and a smoothed running mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Smooth penalty proportional to strand-risk of the leftover: small
    # residuals that can't fit much are risky, but a bit of slack is fine.
    sliver = np.clip(20.0 - residual, 0.0, 20.0)
    score -= 0.6 * sliver

    # Soft bonus for residuals in a still-useful mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Stateful complement bonus: reward residuals that can be filled exactly
    # by a recently common item size (wider +/-2 window).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0

    # Pairing bonus: reward residuals close to the running mean item size,
    # since such a bin is likely to be topped off by a single typical item.
    if _n > 20.0:
        score += 2.0 * np.exp(-((residual - _mean) ** 2) / (2.0 * 12.0 ** 2))

    # Fillability bonus: estimate the probability the leftover can be reduced
    # further by a typical future item, using the cumulative histogram up to
    # the residual size. Higher fillability => leftover less likely stranded.
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        cum = np.cumsum(_hist)  # cum[s] = count of items with size <= s
        total = _hist.sum() + 1e-9
        fillable = cum[res_clipped] / total
        score += 3.0 * fillable
        # Also reward the residual being fairly small so cumulative fill risk
        # of leaving a large unusable gap is lower.
        score -= 0.02 * np.clip(residual - 30.0, 0.0, 70.0)

    return score
# EVOLVE-BLOCK-END

