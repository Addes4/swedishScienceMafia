# EVOLVE-BLOCK-START
"""Best fit with a small closing bonus for residuals that are likely fillable."""
import numpy as np

_counts = np.ones(101, dtype=np.float64)


def priority(item, bins):
    """Rank bins: tightest fit, with a bonus when the residual matches common item sizes."""
    global _counts
    # Decayed histogram of past item sizes (Laplace-smoothed).
    _counts *= 0.999
    _counts[item] += 1.0

    residual = bins - item  # remaining capacity after placement (>= 0)
    # Base: prefer smallest residual (best fit).
    score = -residual.astype(np.float64)

    # Bonus proportional to how common the residual size is (a fillable small gap),
    # but only for small residuals where a single item could close the bin.
    w = _counts / _counts.sum()
    small = (residual > 0) & (residual <= 20)
    score[small] += 0.5 * w[residual[small]]
    return score
# EVOLVE-BLOCK-END
