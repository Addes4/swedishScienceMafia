# EVOLVE-BLOCK-START
"""Best-fit guided by online-estimated expected waste of residuals."""
import numpy as np


class _State:
    def __init__(self):
        # counts of observed item sizes 1..100
        self.hist = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def update(self, item):
        self.hist[item] += 1.0
        self.total += 1.0


_S = _State()


def priority(item, bins):
    _S.update(item)
    residual = (bins - item).astype(np.float64)

    # Empirical size distribution (smoothed over a small window).
    if _S.total >= 30.0:
        h = _S.hist / _S.total
        # kernel smooth with width 2 (neighbors +/-2)
        k = np.array([1.0, 2.0, 3.0, 2.0, 1.0])
        k /= k.sum()
        sm = np.convolve(h, k, mode="same")
        # cumulative probability: P(item <= r) approximated
        cdf = np.cumsum(sm)
        # probability a future item exactly fits residual r (bins of size ~r)
        # approximate: expected fill fraction for a gap of size r
        # chance to close gap r exactly = p(r)
        pr = sm
        # expected wasted space in a gap of size r: r * (1 - E[coverage])
        # E[coverage] ~ P(any item <= r) weighted; use sum over s<=r of p(s)*s / r
        fill = np.zeros_like(residual)
        rs = residual.astype(np.int64)
        for i, r in enumerate(rs):
            if r <= 0:
                fill[i] = 1.0
            elif r <= 100:
                fill[i] = np.sum(pr[1:r + 1] * np.arange(1, r + 1)) / r
            else:
                fill[i] = 1.0
        # score: prefer low expected waste = r * (1 - fill)
        ew = residual * (1.0 - np.minimum(fill, 1.0))
        score = -ew
        # tiny exact-fit bonus
        score += 0.5 * (residual == 0)
    else:
        score = -residual
        score -= 8.0 * ((residual >= 1) & (residual <= 15))

    return score
# EVOLVE-BLOCK-END
