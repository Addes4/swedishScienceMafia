# EVOLVE-BLOCK-START
"""Best-fit with histogram-driven expected-remainder penalty and pairing bonus."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item
    score = -residual.astype(np.float64)  # best-fit slope

    # Penalize tiny unusable leftovers (slivers waste capacity).
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver

    # Soft bonus for residuals in a still-useful mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    if _n > 20.0:
        total = _hist.sum() + 1e-9
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)

        # Complement bonus: reward residuals fillable by a common item size.
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0

        # Expected-remainder penalty: for each residual r (1..100), estimate
        # the probability that a future item lands and leaves a small useless
        # remainder. Approximate by weighting item frequencies by the resulting
        # small-remainder indicator; penalize residuals whose typical fills
        # strand space. This gently favors residuals that keep bins tight.
        idx = np.arange(101, dtype=np.int64)  # candidate residual values
        # For each residual r, compute expected stranded space when the next
        # item j is placed: allow only j <= r. Wasted = r - j when the leftover
        # (r-j) is small-but-nonzero (unusable-ish) else 0 for exact fill.
        # Vectorize per-bin via lookup: precompute penalty table over residuals.
        if not hasattr(priority, "_pen_table") or priority._pen_n != int(_n) // 50:
            # Recompute penalty table lazily (changes slowly with histogram).
            hist = _hist
            tot = hist.sum() + 1e-9
            # weight each item size j by its historical frequency
            j = np.arange(101, dtype=np.float64)
            hw = hist / tot
            pen = np.zeros(101, dtype=np.float64)
            for r in range(1, 101):
                # items j in [1..r]
                hi = int(r)
                hvec = hw[1:hi + 1]
                rem = r - np.arange(1, hi + 1, dtype=np.float64)
                # stranded space: small nonzero remainders are wasted
                waste = np.where((rem >= 1) & (rem <= 15), rem, 0.0)
                pen[r] = np.dot(hvec, waste)
            priority._pen_table = pen
            priority._pen_n = int(_n) // 50
        pen = priority._pen_table
        score -= 3.0 * pen[res_clipped]

        # Pairing bonus: reward residuals close to the running mean item size.
        score += 2.0 * np.exp(-((residual - _mean) ** 2) / (2.0 * 12.0 ** 2))

    return score
# EVOLVE-BLOCK-END

