# EVOLVE-BLOCK-START
"""Best-fit augmented with an online-learned residual "closability" score.

We keep a histogram of item sizes seen so far.  When ranking a bin we look at
the residual r = bins - item that would result.  A residual is good if it is
likely to be *closed* by a future item, i.e. if some frequently seen item size
is close to r (then one more item finishes the bin almost exactly).  We combine
that closability with plain best-fit tightness.
"""
import numpy as np

_SIZE = 101
_hist = np.zeros(_SIZE, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    global _count
    # --- update online histogram -------------------------------------
    _hist[item] += 1.0
    _count += 1.0

    residual = (bins - item).astype(np.float64)  # leftover if placed here

    # Base: prefer tight fits.
    score = -residual

    # Closability: how likely is this residual to be matched by a future item?
    # Use the running histogram as an estimate of P(next item == r).
    # A small window around r counts as "almost closed".
    freq = _hist
    # weighted count of item sizes within +-2 of each residual
    # (vectorised with a small convolution)
    closable = np.zeros_like(residual)
    lo = np.maximum(residual - 2.0, 0).astype(np.int64)
    hi = np.minimum(residual + 2.0, _SIZE - 1).astype(np.int64)
    # cumulative histogram for fast window sums
    cum = np.concatenate(([0.0], np.cumsum(freq)))
    closable = cum[hi + 1] - cum[lo]
    if _count > 0:
        closable = closable / _count

    # Reward residuals that are likely to be closed soon.
    score += 60.0 * closable

    # Penalize unusable tiny slivers that nothing seen so far can close.
    sliver = (residual >= 1) & (residual <= 12) & (closable < 1e-9)
    score -= 12.0 * sliver

    return score
# EVOLVE-BLOCK-END
