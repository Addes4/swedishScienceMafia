# EVOLVE-BLOCK-START
"""Harmonic-style online packing: keep residuals within the item's power-of-two class."""
import numpy as np


def priority(item, bins):
    """Rank bins for harmonic-style packing.

    For an item of size s, let k be its power-of-two class (2^k <= s < 2^(k+1)).
    The harmonic invariant is that a bin receiving a class-k item should end with
    residual capacity below the class threshold, i.e. residual < 2^k (or the bin
    becomes (nearly) full / cannot fit future items of the same class).  We prefer
    placements satisfying this invariant, and within the preferred set use
    best-fit tightness; otherwise fall back to plain best-fit.
    """
    # power-of-two class of the item
    k = int(item).bit_length() - 1
    thr = 1 << k  # 2^k

    residual = bins - item  # remaining capacity after placing the item here
    fits = residual >= 0

    # Preferred: residual below the class threshold (bin closes out its class)
    # Also allow residual == 0 (perfectly full) which trivially satisfies this.
    preferred = fits & (residual < thr)

    # Score: main term is "preferred" (1) vs not (0); tiebreak by best-fit
    # (smaller residual = higher score). Non-fitting bins get a strongly
    # negative score so they are never chosen when a fitting bin exists.
    score = np.where(fits, -residual.astype(np.float64), -1e9)
    score = score + np.where(preferred, 1e6, 0.0)
    return score
# EVOLVE-BLOCK-END
