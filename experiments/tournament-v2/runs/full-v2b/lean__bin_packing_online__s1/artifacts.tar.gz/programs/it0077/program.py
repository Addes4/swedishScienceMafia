# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty and empirical smallest-size waste avoidance."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean, and a running minimum/quantile tracker.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_min_seen = 100.0


def priority(item, bins):
    global _hist, _n, _sum, _mean, _min_seen
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.998
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n
    if item < _min_seen:
        _min_seen = item

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Sharp sliver penalty tuned to the empirical typical item size.
    # A leftover that cannot be filled by a typical upcoming item wastes space.
    sliver_thr = 0.55 * _mean
    if sliver_thr < 1.0:
        sliver_thr = 1.0
    sliver = (residual >= 1) & (residual < sliver_thr)
    score -= 9.0 * sliver

    # Extra penalty for residuals too small to ever be usefully filled again
    # (below the smallest item seen so far, but positive). This directly
    # targets unusable waste.
    dead = (residual >= 1) & (residual < _min_seen)
    score -= 6.0 * dead

    # Soft bonus for residuals in a still-useful mid range (can be topped off).
    useful = (residual >= 35) & (residual <= 65)
    score += 1.2 * useful

    # Stateful fill-probability: reward residuals that match common recent
    # item sizes (so a single upcoming item of a common size tops the bin off).
    if _n > 30.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        nearby = freq + 0.5 * (lo1 + hi1)
        score += 5.0 * (nearby / total) * 100.0

    return score
# EVOLVE-BLOCK-END
