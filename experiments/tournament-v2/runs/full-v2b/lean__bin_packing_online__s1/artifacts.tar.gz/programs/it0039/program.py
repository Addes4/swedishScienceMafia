# EVOLVE-BLOCK-START
"""Best-fit with a smooth, size-aware penalty on hard-to-refill residuals."""
import numpy as np

_mean = 40.0      # running estimate of typical item size
_count = 0.0


def priority(item, bins):
    """Rank bins: prefer tight fits, but softly penalize residuals too small
    to hold a typical future item.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    global _mean, _count
    _count += 1.0
    _mean += (float(item) - _mean) / _count

    residual = (bins - item).astype(np.float64)  # leftover if placed here

    # Base: classic best-fit.
    score = -residual

    # Smooth penalty: residuals well below the typical item size are unlikely
    # to be refilled, so waste capacity. Largest penalty near residual ~ 0.
    scale = max(_mean, 1.0)
    penalty = np.exp(-residual / (scale * 0.5))  # ~1 at r=0, decays with r
    score -= 6.0 * penalty

    return score
# EVOLVE-BLOCK-END
