# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty and a cheap stateful exact-completion bonus."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100).
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0

# Cached top completion sizes (most frequent historical item sizes).
_top_sizes = np.array([40], dtype=np.int64)


def priority(item, bins):
    global _hist, _n, _top_sizes
    # Update smoothed histogram of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0

    residual = bins - item  # leftover capacity if placed here

    # Primary best-fit: strongly prefer the smallest usable residual.
    score = -residual.astype(np.float64)

    # Penalize tiny unusable leftovers (slivers waste capacity).
    sliver = (residual >= 1) & (residual <= 12)
    score -= 6.0 * sliver

    # Stateful exact-completion bonus: reward a residual that is itself a
    # frequent historical item size, since such a bin is likely to be closed
    # exactly by a typical upcoming item.
    if _n > 50.0:
        # Recompute the small set of most frequent sizes occasionally.
        if int(_n) % 64 == 0:
            order = np.argsort(_hist[1:101])[::-1]
            _top_sizes = (order[:8] + 1).astype(np.int64)
        tot = _hist.sum() + 1e-9
        for s in _top_sizes:
            mass = _hist[s] / tot
            score += 3.0 * mass * (np.abs(residual - s) <= 1)

    return score
# EVOLVE-BLOCK-END

