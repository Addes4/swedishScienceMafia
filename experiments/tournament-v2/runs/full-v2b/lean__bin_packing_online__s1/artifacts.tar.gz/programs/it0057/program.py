# EVOLVE-BLOCK-START
"""Best-fit with fillable-sliver exemption, complement bonus, and mean pairing."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item
    score = -residual.astype(np.float64)

    # Sliver penalty, but exempt residuals that are historically common item
    # sizes (fillable slivers), which are not truly wasted capacity.
    sliver = (residual >= 1) & (residual <= 15)
    if _n > 20.0:
        total = _hist.sum() + 1e-9
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        freq = _hist[res_clipped] / total
        fillable = (freq > 0.002) & sliver
        score -= 8.0 * (sliver & ~fillable)
    else:
        score -= 8.0 * sliver

    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    if _n > 20.0:
        total = _hist.sum() + 1e-9
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0

    if _n > 20.0:
        score += 2.0 * np.exp(-((residual - _mean) ** 2) / (2.0 * 12.0 ** 2))

    return score
# EVOLVE-BLOCK-END
