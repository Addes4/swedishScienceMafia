# EVOLVE-BLOCK-START
"""Best-fit with a smooth empirical-waste term and a histogram-based
exact-complement bonus."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Decaying histogram of past item sizes; running mean.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: wastes nothing.
    score += 16.0 * (residual == 0)

    # Empirical CDF of past items, used to estimate how "dead" a residual is.
    if _n > 30.0:
        total = _hist.sum() + 1e-9
        cdf = np.cumsum(_hist) / total          # cdf[s] = P(item <= s)
        small_thr = float(np.searchsorted(np.cumsum(_hist), 0.15 * (total)))
        if small_thr < 1.0:
            small_thr = 1.0
    else:
        cdf = None
        small_thr = max(1.0, 0.5 * _mean)

    # Smooth waste term: for a positive residual r, the probability that a
    # future item is <= r is P(fit); the complement 1 - P(fit) is the chance
    # the residual can never be used. Penalize proportionally, capped so it
    # never overwhelms best-fit.
    res_clipped = np.clip(residual, 0, 100).astype(np.int64)
    if cdf is not None:
        pfit = cdf[res_clipped]                 # in [0,1]
        waste = 1.0 - pfit
        # Only meaningful for small residuals; scale down for large ones.
        score -= 6.0 * waste
    else:
        thr = max(1.0, 0.5 * _mean)
        score -= 8.0 * ((residual >= 1) & (residual < thr))

    # Residuals below the empirical small-item threshold: still unfillable.
    unfillable = (residual >= 1) & (residual < small_thr)
    if unfillable.any():
        score -= 3.0 * unfillable * (small_thr - residual)

    # Multi-item capacity bonus: mildly favor bins that can still hold
    # several typical items.
    typical = max(1.0, 0.5 * _mean)
    kfit = np.floor(np.maximum(residual, 0) / typical)
    score += 1.2 * np.sqrt(kfit)

    # Stateful complement bonus: reward residuals fillable exactly by a
    # recently common item size.
    if _n > 20.0:
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0
        score += 3.0 * (freq / total) * 100.0

    return score
# EVOLVE-BLOCK-END
