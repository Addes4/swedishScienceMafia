# EVOLVE-BLOCK-START
"""Best-fit with mean-adaptive sliver penalty, empirical small-item floor,
a sharp histogram-convolution pair-complement signal, and a frequency-weighted
exact-fill reward."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_prev = 0.0


def priority(item, bins):
    global _hist, _n, _sum, _mean, _prev
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item
    score = -residual.astype(np.float64)

    total = _hist.sum() + 1e-9

    # Exact-fill reward, weighted by how common the just-filled size is.
    exact = (residual == 0)
    if exact.any():
        freq_here = float(_hist[min(max(item, 0), 100)]) / total
        score += (10.0 + 12.0 * freq_here * 100.0 / 5000.0) * exact

    # Empirical smallest plausible item (15th pct) and sliver threshold (20th pct).
    if _n > 30.0:
        cum = np.cumsum(_hist)
        small_thr = float(np.searchsorted(cum, 0.15 * total))
        sliver_thr = float(np.searchsorted(cum, 0.20 * total))
    else:
        small_thr = max(1.0, 0.5 * _mean)
        sliver_thr = max(1.0, 0.5 * _mean)
    if small_thr < 1.0:
        small_thr = 1.0
    if sliver_thr < 1.0:
        sliver_thr = 1.0

    sliver = (residual >= 1) & (residual < sliver_thr)
    score -= 8.0 * sliver

    unfillable = (residual >= 1) & (residual < small_thr)
    if unfillable.any():
        score -= 3.0 * unfillable * (small_thr - residual)

    # Same-item bonus.
    same = (residual == item)
    if same.any():
        score += 1.5 * same

    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)

        # Nearby-frequency complement signal (+/-2 window around residual).
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0
        score += 3.0 * (freq / total) * 100.0

        # Pairwise-complement signal: residual == current item + a common size.
        # This means the leftover can be closed by the current item followed by
        # a typical future item, so it is genuinely reusable capacity.
        comp = res_clipped - int(item)
        cclip = np.clip(comp, 0, 100).astype(np.int64)
        pair_sum = _hist[cclip]
        score += 2.0 * (pair_sum / total) * 100.0

        # Fused pair + current item: residual == item + one more typical item
        # formed from the histogram convolved with the current size.
        # Reward residual that itself is close to a common size plus item.
        score += 1.2 * ((pair_sum > 0) * (freq / total) * 100.0)

    # Expected-waste penalty: probability that no single future item fits.
    if _n > 40.0:
        cum = np.cumsum(_hist)
        total_hist2 = cum[-1] + 1e-9
        res_int = np.clip(residual, 0, 100).astype(np.int64)
        p_larger = 1.0 - cum[np.clip(res_int - 1, 0, 100)] / total_hist2
        p_larger = np.clip(p_larger, 0.0, 1.0)
        score -= 2.0 * p_larger * (residual > 0)

    _prev = float(item)
    return score
# EVOLVE-BLOCK-END
