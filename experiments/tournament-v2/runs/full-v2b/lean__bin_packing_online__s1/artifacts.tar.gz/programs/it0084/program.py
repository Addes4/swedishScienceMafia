# EVOLVE-BLOCK-START
"""Best-fit with graded waste-avoidance using observed minimum item size."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum/count, mean, and minimum item size observed.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_min_item = 100.0


def priority(item, bins):
    global _hist, _n, _sum, _mean, _min_item
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n
    if item < _min_item:
        _min_item = float(item)

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    exact = (residual == 0)
    score += 11.0 * exact

    # Graded waste-avoidance penalty.
    # Residuals below the smallest item seen so far can never be exactly
    # refilled -> guaranteed permanent waste (strong penalty).
    # Residuals in [min_item, min_item + mean/2) are very likely to waste
    # (hard to fill) -> milder graded penalty.
    m = _min_item
    r = residual.astype(np.float64)
    guaranteed = (r >= 1) & (r < m)
    score -= 9.0 * guaranteed

    band_hi = m + max(1.0, 0.5 * _mean)
    in_band = (r >= m) & (r < band_hi)
    # Linear decay of penalty across the band.
    frac = (band_hi - r) / max(1.0, band_hi - m)
    score -= 3.0 * in_band * frac

    # Stateful complement bonus: reward residuals fillable exactly by a
    # recently common item size (wider +/-2 window).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0

    # Pairing bonus: reward residuals close to a single typical item size,
    # since such a bin is likely to be topped off by one more item.
    if _n > 20.0:
        score += 2.0 * np.exp(-((residual - _mean) ** 2) / (2.0 * 12.0 ** 2))

    return score
# EVOLVE-BLOCK-END
