# EVOLVE-BLOCK-START
"""Best-fit with mean-adaptive sliver penalty, empirical small-item floor,
a multi-item capacity bonus, recent-item pair-complement signals, a
histogram-based pair-sum complement signal, and a pool-residual
consolidation signal."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_prev = 0.0
_recent = np.zeros(8, dtype=np.float64)
_recent_idx = 0
_cum = None


def priority(item, bins):
    global _hist, _n, _sum, _mean, _prev, _cum, _recent, _recent_idx
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item
    score = -residual.astype(np.float64)

    total_hist = _hist.sum() + 1e-9

    exact = (residual == 0)
    if exact.any():
        freq_here = float(_hist[min(max(item, 0), 100)]) / total_hist
        score += (10.0 + 12.0 * freq_here * 100.0 / 5000.0) * exact

    if _n > 30.0:
        total = _hist.sum() + 1e-9
        cum = np.cumsum(_hist)
        small_thr = float(np.searchsorted(cum, 0.15 * total))
        if small_thr < 1.0:
            small_thr = 1.0
        sliver_thr = float(np.searchsorted(cum, 0.20 * total))
        if sliver_thr < 1.0:
            sliver_thr = 1.0
    else:
        small_thr = max(1.0, 0.5 * _mean)
        sliver_thr = max(1.0, 0.5 * _mean)

    thr = sliver_thr
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    unfillable = (residual >= 1) & (residual < small_thr)
    if unfillable.any():
        score -= 3.0 * unfillable * (small_thr - residual)

    same = (residual == item)
    if same.any():
        score += 1.5 * same

    typical = 0.5 * _mean
    if typical < 1.0:
        typical = 1.0
    kfit = np.floor(np.maximum(residual, 0) / typical)
    score += 1.2 * np.sqrt(kfit)

    # Pool-residual consolidation: bins sharing the same leftover capacity form
    # a "class" the current item can help close. Reward residuals that already
    # occur elsewhere in the pool so like-size leftovers are consolidated.
    res_int = np.clip(residual, 0, 100).astype(np.int64)
    pool_counts = np.bincount(bins.astype(np.int64), minlength=101)
    if _n > 10.0:
        # residual after placing; count of bins currently holding that residual
        share = pool_counts[np.clip(res_int, 0, 100)]
        score += 0.8 * np.log1p(share)

    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0
        score += 3.0 * (freq / total) * 100.0

        if _n > 8.0:
            accum = np.zeros_like(res_clipped, dtype=np.float64)
            for w in range(_recent.shape[0]):
                want = int(round(_recent[w]))
                if want < 1:
                    continue
                cand = np.clip(res_clipped - want, 0, 100).astype(np.int64)
                accum += _hist[cand]
            score += 1.8 * (accum / total) * 100.0

            for w in range(_recent.shape[0]):
                want = int(round(_recent[w]))
                if want < 1:
                    continue
                target = item + want
                hit = (residual == target)
                if hit.any():
                    score += 7.0 * hit

        comp = res_clipped - int(item)
        if comp.size:
            cclip = np.clip(comp, 0, 100).astype(np.int64)
            pair_sum = _hist[cclip]
            score += 1.5 * (pair_sum / total) * 100.0

    if _n > 50.0:
        dead = (residual >= 1) & (residual < typical)
        score -= 1.0 * dead * np.maximum(0.0, 1.0 - 0.5 * _mean / np.maximum(_mean, 1.0))

    if _n > 40.0:
        cum = np.cumsum(_hist)
        total_hist2 = cum[-1] + 1e-9
        p_larger = 1.0 - cum[np.clip(res_int - 1, 0, 100)] / total_hist2
        p_larger = np.clip(p_larger, 0.0, 1.0)
        score -= 2.0 * p_larger * (residual > 0)

    _prev = float(item)
    _recent[_recent_idx % _recent.shape[0]] = float(item)
    _recent_idx += 1
    return score
# EVOLVE-BLOCK-END
