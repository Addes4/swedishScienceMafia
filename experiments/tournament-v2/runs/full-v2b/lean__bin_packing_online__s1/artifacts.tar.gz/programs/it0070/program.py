# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty, useful-residual bonus, and exact-completion bonus."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Penalize tiny unusable leftovers (slivers waste capacity).
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver

    # Soft bonus for residuals in a still-useful mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Stateful exact-completion bonus: reward residuals where the current item
    # plus the leftover equals a frequently seen past size (item synthesized a
    # previously common bin fill).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        combo = np.clip(res_clipped + item, 0, 100)
        total = _hist.sum() + 1e-9
        freq = _hist[combo]
        score += 4.0 * (freq / total) * 100.0

    # Pairing bonus: reward residuals close to the running mean item size,
    # since such a bin is likely to be topped off by a single typical item.
    if _n > 20.0:
        score += 2.0 * np.exp(-((residual - _mean) ** 2) / (2.0 * 12.0 ** 2))

    return score
# EVOLVE-BLOCK-END

