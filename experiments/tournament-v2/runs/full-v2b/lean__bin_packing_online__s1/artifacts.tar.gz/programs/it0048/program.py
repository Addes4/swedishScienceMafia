# EVOLVE-BLOCK-START
"""Best-fit with histogram-based expected wastage and complement bonus."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 0..100).
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    global _hist, _n
    # Update smoothed histogram of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0

    residual = bins - item  # leftover capacity if placed here
    r = residual.astype(np.float64)
    score = -r

    # Penalize tiny unusable leftovers (slivers waste capacity).
    sliver = (r >= 1) & (r <= 12)
    score -= 8.0 * sliver

    if _n > 20.0:
        total = _hist.sum() + 1e-9
        # Cumulative probability that a future item fits this residual.
        # fit_prob[r] = P(item <= r): chance the bin can still accept something.
        cum = np.cumsum(_hist) / total
        rc = np.clip(residual, 0, 100).astype(np.int64)
        fit_prob = cum[rc]

        # Expected stranded capacity: if a future item fits, assume we can use
        # roughly a typical fraction; scale penalty by (1 - fit_prob).
        # A residual that nothing fits (fit_prob ~ 0) is almost fully wasted.
        score -= 6.0 * (1.0 - fit_prob) * np.minimum(r, 40.0) / 40.0

        # Complement bonus: reward residuals near a common past size.
        freq = _hist[rc]
        lo = _hist[np.clip(rc - 1, 0, 100)]
        hi = _hist[np.clip(rc + 1, 0, 100)]
        nearby = freq + 0.5 * (lo + hi)
        score += 3.0 * (nearby / total) * 100.0

    return score
# EVOLVE-BLOCK-END
