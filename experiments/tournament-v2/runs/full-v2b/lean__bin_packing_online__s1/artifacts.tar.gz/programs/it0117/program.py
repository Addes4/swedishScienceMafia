# EVOLVE-BLOCK-START
"""Best-fit with mean-adaptive sliver penalty, empirical small-item floor,
a multi-item capacity bonus, and a smooth expected-waste term."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    exact = (residual == 0)
    score += 16.0 * exact

    # Empirical "smallest plausible item": the 15th-percentile item size seen
    # so far. A residual below this is unlikely to ever be exactly refilled.
    if _n > 30.0:
        total = _hist.sum() + 1e-9
        cum = np.cumsum(_hist)
        small_thr = float(np.searchsorted(cum, 0.15 * total))
        if small_thr < 1.0:
            small_thr = 1.0
    else:
        small_thr = max(1.0, 0.5 * _mean)

    # Mean-adaptive sliver penalty: residual too small to likely be refilled
    # wastes capacity. Threshold scales with typical item size.
    thr = 0.5 * _mean
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    # Smooth expected-waste term: a residual r can still be partly filled by
    # future items up to size r. Remaining capacity beyond the largest item
    # that could fit is the expected fraction of r that stays wasted. Penalize
    # in proportion to the probability mass of past items larger than r.
    if _n > 50.0:
        total = _hist.sum() + 1e-9
        res_clip = np.clip(residual, 0, 100).astype(np.int64)
        # Mass of items strictly larger than residual => can never fit it.
        larger_mass = 1.0 - np.cumsum(_hist)[res_clip] / total
        # Scale by residual size so larger dead residuals hurt more.
        score -= 2.0 * larger_mass * np.maximum(residual, 0)

    # Multi-item capacity bonus: a bin whose residual can still hold several
    # typical (mean-sized) items is more reusable than one that can hold only
    # a single one, so prefer keeping such bins in play. Best-fit still
    # dominates via the -residual term.
    typical = 0.5 * _mean
    if typical < 1.0:
        typical = 1.0
    kfit = np.floor(np.maximum(residual, 0) / typical)
    # Diminishing returns: only modestly reward extra item capacity.
    score += 1.2 * np.sqrt(kfit)

    # Stateful complement bonus: reward residuals that can be filled exactly
    # by a recently common item size (wider +/-2 window).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0
        # Sharper bonus for an exact match to a common item size.
        score += 3.0 * (freq / total) * 100.0

    return score
# EVOLVE-BLOCK-END
