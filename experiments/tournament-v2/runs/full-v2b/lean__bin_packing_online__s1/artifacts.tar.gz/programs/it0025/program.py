# EVOLVE-BLOCK-START
"""Best fit refined with a small-residual penalty.

Pure best-fit minimizes the leftover after placement, which often leaves a tiny
sliver of residual capacity that no future item can use.  Here we score bins by
their post-placement residual, but add a penalty proportional to how *useless*
that residual is: very small residuals are discouraged (they waste the bin's
remaining space), while residuals that are large enough to still host typical
items are preferred.  Ties fall back to plain best fit.
"""
import numpy as np

# A residual below this many units is (nearly) unusable by future items.
_USELESS = 6


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # Base: best fit -- smaller residual is better (rank by negative residual).
    score = -residual.astype(np.float64)

    # Penalize residuals that are tiny but nonzero: they close the bin off
    # without gaining the "full bin" benefit.  Exact fits (residual 0) keep
    # their strong preference; a wasted sliver does not.
    tiny_waste = (residual > 0) & (residual < _USELESS)
    score[tiny_waste] -= 1.0 + (residual[tiny_waste] > 0) * 0.5

    return score
# EVOLVE-BLOCK-END
