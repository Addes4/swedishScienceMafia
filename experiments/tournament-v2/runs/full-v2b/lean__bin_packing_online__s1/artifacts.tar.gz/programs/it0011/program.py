# EVOLVE-BLOCK-START
"""Best fit with a small harmonization bonus for residuals that later small items can fill."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _hist, _count
    # update a running frequency estimate of seen items (exponential-ish via normalization)
    _hist[item] += 1.0
    _count += 1.0

    # residual after placing item into each candidate bin
    resid = bins - item

    # exact fill is always preferred
    exact = (resid == 0)

    # estimate probability a future item can exactly fill a residual r that is small
    # use histogram mass at r (probability an item of size r appears)
    # plus a mild preference for very small residuals (abandon cost low)
    p_fill = _hist[1:101] / max(_count, 1.0)

    # map residual (1..99) to probability of exact fill; residual 0 handled separately
    r = np.clip(resid, 0, 99).astype(np.int64)
    bonus = p_fill[np.clip(r - 1, 0, 99)]
    # tiny extra preference for leaving tiny or empty residuals (empty=100 unused handled too)
    bonus = bonus + 0.001 * (resid <= 2)

    score = -(resid.astype(np.float64)) + 5.0 * bonus + 1000.0 * exact
    # unused bins (100 remaining) should not get phantom residual of 100+
    score[bins == 100] = -(100.0 - item)  # neutral baseline for unused bins
    return score
# EVOLVE-BLOCK-END
