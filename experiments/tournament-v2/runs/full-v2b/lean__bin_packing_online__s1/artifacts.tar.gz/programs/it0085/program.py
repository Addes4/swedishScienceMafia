# EVOLVE-BLOCK-START
"""Best-fit with exact-fill reward, stateful complement bonus, and a
histogram-based expected-fillability term that replaces hand-tuned thresholds."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    exact = (residual == 0)
    score += 12.0 * exact

    res_clipped = np.clip(residual, 0, 100).astype(np.int64)

    if _n > 20.0:
        total = _hist.sum() + 1e-9

        # Expected fillability: probability that a future item is small enough
        # to fit in this residual. Residuals with a high chance of being
        # topped off are valuable; those with a low chance are near-permanent
        # waste.  cum[k] = mass of items with size <= k.
        cum = np.cumsum(_hist)
        fit_mass = cum[res_clipped] / total  # P(item <= residual)
        # Reward residuals that remain fillable, penalize those that don't.
        score += 6.0 * fit_mass

        # Complement bonus: reward residuals exactly fillable by a common item
        # size (wide +/-2 window from the decayed histogram).
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0

    return score
# EVOLVE-BLOCK-END
