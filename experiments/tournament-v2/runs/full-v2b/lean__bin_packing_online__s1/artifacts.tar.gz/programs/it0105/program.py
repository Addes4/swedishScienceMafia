# EVOLVE-BLOCK-START
"""Best-fit with mean-adaptive sliver penalty, empirical small-item floor,
a multi-item capacity bonus, and a histogram-weighted refill potential term."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item
    score = -residual.astype(np.float64)

    exact = (residual == 0)
    score += 16.0 * exact

    if _n > 30.0:
        total = _hist.sum() + 1e-9
        cum = np.cumsum(_hist)
        small_thr = float(np.searchsorted(cum, 0.15 * total))
        if small_thr < 1.0:
            small_thr = 1.0
    else:
        small_thr = max(1.0, 0.5 * _mean)

    thr = 0.5 * _mean
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 6.0 * sliver

    unfillable = (residual >= 1) & (residual < small_thr)
    if unfillable.any():
        score -= 3.0 * unfillable * (small_thr - residual)

    typical = 0.5 * _mean
    if typical < 1.0:
        typical = 1.0
    kfit = np.floor(np.maximum(residual, 0) / typical)
    score += 1.2 * np.sqrt(kfit)

    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 5.0 * (nearby / total) * 100.0
        score += 4.0 * (freq / total) * 100.0
        # Broader refill potential: cumulative fraction of past items that
        # could fit in this residual (scaled), rewarding residuals that match
        # the bulk of the size distribution rather than a narrow band.
        fitcum = np.cumsum(_hist[:101])[np.clip(res_clipped, 0, 100)]
        score += 2.0 * (fitcum / total)

    return score
# EVOLVE-BLOCK-END
