# EVOLVE-BLOCK-START
"""Best-fit with a residual-quality penalty: avoid creating unusable slivers."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits, but penalize leftovers that waste capacity.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    residual = bins - item  # leftover capacity if placed here
    # Base: tight fit is good (small residual -> high score)
    score = -residual.astype(np.float64)
    # Penalize tiny unusable leftovers (1..15): they rarely get filled by
    # Weibull-distributed items, so they waste capacity.
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver
    # Slight bonus for residuals in a "still useful" mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful
    return score
# EVOLVE-BLOCK-END
