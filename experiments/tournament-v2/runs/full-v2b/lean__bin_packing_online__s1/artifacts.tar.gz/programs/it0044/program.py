# EVOLVE-BLOCK-START
"""Best-fit with a soft "fillable leftover" bonus around the typical item size."""
import numpy as np

_mu = 40.0
_n = 0


def priority(item, bins):
    """Rank bins: prefer tight fits, softly reward leftovers near a typical item size.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    global _mu, _n

    residual = (bins - item).astype(np.float64)  # leftover if placed here

    # Strong preference for tight fits (classic best-fit).
    score = -residual

    # Penalize tiny unusable leftovers: they rarely get filled.
    sliver = (residual >= 1) & (residual <= 12)
    score -= 6.0 * sliver

    # Soft bonus for leftovers close to the running mean item size, since
    # a leftover of about one typical item is still producible/fillable.
    mu = _mu
    dist = np.abs(residual - mu)
    score += 3.0 * np.exp(-(dist * dist) / (2.0 * (mu * 0.5) ** 2))

    # Update running mean of observed item sizes (after scoring).
    _n += 1
    _mu += (item - _mu) / _n

    return score
# EVOLVE-BLOCK-END
