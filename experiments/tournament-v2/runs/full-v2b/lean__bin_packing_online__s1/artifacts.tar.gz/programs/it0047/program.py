# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty plus a soft stateful complement bonus (sharpened)."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100).
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    global _hist, _n
    # Update smoothed histogram of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Penalize tiny unusable leftovers (slivers waste capacity).
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver

    # Soft bonus for residuals in a still-useful mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Stateful complement bonus: reward residuals close to common past sizes,
    # since such a leftover bin can likely be filled exactly soon.
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        # Frequency of the exact residual and its immediate neighbors,
        # since a residual within +/-1 of a common size is nearly as fillable.
        freq = _hist[res_clipped]
        lo = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi = _hist[np.clip(res_clipped + 1, 0, 100)]
        nearby = freq + 0.5 * (lo + hi)
        score += 3.0 * (nearby / total) * 100.0

    return score
# EVOLVE-BLOCK-END
