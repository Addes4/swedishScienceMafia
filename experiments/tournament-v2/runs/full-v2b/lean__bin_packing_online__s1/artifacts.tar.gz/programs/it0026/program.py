# EVOLVE-BLOCK-START
"""Best fit with a dead-zone penalty: avoid leaving mid-size residues that no
average item can reuse, while still filling tight gaps for large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (ties -> first).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins that fit the item.
    """
    residual = bins - item  # leftover after placing item (>= 0)

    if item > 50:
        # Large items: pure best fit (tightest fit wins).
        return -residual

    # Small/medium items: reward residuals that are either nearly closable
    # (tiny leftover) or comfortably large (>= 40, can still host a mean item).
    # Penalize the "dead zone" of residues that waste a bin without closing it.
    closable = 8
    # score: prefer near-zero residual, else prefer large residual, else neutral
    tight = np.where(residual <= closable, 100.0 - residual, 0.0)
    roomy = np.where(residual >= 40, residual, 0.0)
    mid_penalty = np.where((residual > closable) & (residual < 40), -1.0, 0.0)
    return tight + roomy + mid_penalty
# EVOLVE-BLOCK-END
