# EVOLVE-BLOCK-START
"""Best-fit with a sliver penalty plus a learned residual-match bonus."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits, penalize wasteful slivers, reward
    residuals near recently seen item sizes.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    residual = bins - item  # leftover capacity if placed here
    # Base: tight fit is good (small residual -> high score)
    score = -residual.astype(np.float64)
    # Penalize tiny unusable leftovers (1..15): they rarely get filled by
    # Weibull-distributed items, so they waste capacity.
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver
    # Slight bonus for residuals in a "still useful" mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Stateful size-frequency memory: items cluster (Weibull shape), so a
    # residual close to a frequently seen item size is likely to be filled.
    hist = priority.hist
    if hist is None:
        hist = np.zeros(102, dtype=np.float64)
        priority.hist = hist
    # Reward residuals near common previously seen sizes.
    idx = np.clip(residual, 0, 101).astype(np.int64)
    score += 0.15 * hist[idx]
    # Update memory with the current item (decay for adaptivity).
    hist *= 0.999
    hist[item] += 1.0
    return score


priority.hist = None
# EVOLVE-BLOCK-END
