# EVOLVE-BLOCK-START
"""Best-fit with exact-fill reward, sliver penalty, and a typical-item-size target."""
import numpy as np

# State: running statistics of item sizes seen so far.
_n = 0.0
_sum = 0.0
_mean = 40.0
_max = 1.0


def priority(item, bins):
    global _n, _sum, _mean, _max
    _n += 1.0
    _sum += item
    _mean = _sum / _n
    if item > _max:
        _max = float(item)

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    exact = (residual == 0)
    score += 16.0 * exact

    # Sliver penalty: residuals too small to be refilled waste capacity.
    thr = 0.5 * _mean
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    # Residuals below half of the largest item seen are hard to fill.
    unfillable = (residual >= 1) & (residual < _max * 0.5)
    score -= 3.0 * unfillable

    # Soft bonus for residuals near one typical item size (distribution mode).
    target = _mean
    useful = (residual >= target - 15) & (residual <= target + 15)
    score += 1.5 * useful

    return score
# EVOLVE-BLOCK-END
