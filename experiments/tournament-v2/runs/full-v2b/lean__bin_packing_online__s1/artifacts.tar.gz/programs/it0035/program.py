# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty plus a bonus for finishing near-full bins."""
import numpy as np

_state = {"seen": 0}


def priority(item, bins):
    residual = bins - item  # leftover if placed here
    score = -residual.astype(np.float64)

    # Penalize tiny unusable leftovers.
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver
    # Mild bonus for residuals that can still hold a typical item.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Bonus for placing into the fullest bin among those that fit, to
    # consolidate small residuals instead of opening/making many partial bins.
    below = residual < 0
    if not below.all():
        # among fitting bins, residual is bins - item; fullest bin => smallest residual
        fit_res = np.where(below, np.iinfo(np.int64).max, residual)
        min_res = fit_res.min()
        score += 1.0 * (fit_res == min_res)

    return score
# EVOLVE-BLOCK-END

