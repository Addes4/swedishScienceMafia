# EVOLVE-BLOCK-START
"""Best fit with a penalty for leaving awkward mid-size residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for bins we're allowed to use

    # Base: best fit — tighter fit (smaller residual) is better.
    score = -residual.astype(np.float64)

    # Penalize residuals that sit in an "awkward" zone: too big to write off, but
    # too small to reliably absorb another item.  Wasted space roughly hurts when
    # the residual is non-trivial, so a residual near item/2..item is bad.
    # Peak penalty around the middle of the residual range (roughly 25-45).
    center = 32.0
    width = 18.0
    awkward = np.exp(-((residual - center) / width) ** 2)
    score -= 0.6 * awkward

    # Slightly reward residuals small enough to be effectively wasted (cheap to abandon).
    small = (residual < 10).astype(np.float64)
    score += 0.4 * small

    return score
# EVOLVE-BLOCK-END
