# EVOLVE-BLOCK-START
"""Best-fit plus learned residual fillability, with anti-sliver penalty."""
import numpy as np

# State kept across calls: for each residual value, count how often a bin with
# that residual was later filled (closed) by a subsequent item.
_FILL = np.zeros(101, dtype=np.float64)   # successes
_SEEN = np.zeros(101, dtype=np.float64)   # opportunities
_PREV = None      # residual of last placed bin
_LASTITEM = None  # size of last placed item


def priority(item, bins):
    global _PREV, _LASTITEM

    # Observe whether the previously created residual got closed by this item.
    if _PREV is not None and _PREV == item:
        _FILL[_PREV] += 1.0
    if _LASTITEM is not None:
        # Any bin that had residual == item got filled this step (approx. via prev).
        pass

    residual = bins - item  # leftover capacity if placed here

    # Base: tight fit is good.
    score = -residual.astype(np.float64)

    # Penalize tiny unusable leftovers.
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver

    # Slight bonus for still-useful mid-range residuals.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Learned fillability: promote residuals that historically get refilled.
    # Sample size normalization to avoid noise from rare residuals.
    total = _SEEN.sum()
    with np.errstate(divide="ignore", invalid="ignore"):
        rate = _FILL / np.maximum(_SEEN, 1.0)
    # Record the new opportunity for the residual we're about to create.
    # (approximate: we credit the chosen bin's residual next call via _PREV)
    score += 2.0 * rate[residual.clip(0, 100)]

    # Tentatively mark opportunity for candidate residuals (soft, cheap).
    _SEEN[residual.clip(0, 100)] += 1.0 / max(len(residual), 1)

    _LASTITEM = item
    _PREV = None  # will be set by harness? we can't know; approximate below
    # We cannot observe the chosen bin, so approximate: assume best (max score).
    best = int(np.argmax(score))
    _PREV = int(residual[best]) if len(residual) else None

    return score
# EVOLVE-BLOCK-END
