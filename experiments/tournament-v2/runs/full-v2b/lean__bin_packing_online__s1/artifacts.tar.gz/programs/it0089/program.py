# EVOLVE-BLOCK-START
"""Best-fit with evidence-graded waste penalty plus complement and pair bonuses."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean, and running minimum item size.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_min_item = 100.0


def priority(item, bins):
    global _hist, _n, _sum, _mean, _min_item
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n
    if item < _min_item:
        _min_item = float(item)

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    exact = (residual == 0)
    score += 16.0 * exact

    # Evidence-graded waste penalty: for each residual, estimate the fraction
    # of recent item mass that fits in it. Small fractions mean the residual is
    # hard to ever refill -> penalize proportionally.
    if _n > 20.0:
        total = _hist.sum() + 1e-9
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        # cumulative mass of items <= residual
        cum = np.cumsum(_hist)
        fit_frac = cum[res_clipped] / total
        # residuals below the minimum seen item are permanently unfillable
        size_pen = (1.0 - fit_frac)
        score -= 10.0 * size_pen
        # extra hard penalty for guaranteed-unfillable residuals
        score -= 6.0 * (residual >= 1) * (residual < _min_item)

        # Complement bonus: reward residuals matching a common item size.
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1)
        score += 4.0 * (nearby / total) * 100.0
        score += 3.0 * (freq / total) * 100.0

    # Pairing bonus: reward residuals near twice the running mean item size.
    if _n > 20.0:
        score += 1.5 * np.exp(-((residual - 2.0 * _mean) ** 2) / (2.0 * 16.0 ** 2))

    return score
# EVOLVE-BLOCK-END
