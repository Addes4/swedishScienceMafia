# EVOLVE-BLOCK-START
"""Best-fit with a smooth residual-waste penalty sized by the mean item."""
import numpy as np


def priority(item, bins):
    """Rank bins by tight fit, with a smooth penalty for wasteful residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    residual = (bins - item).astype(np.float64)
    # Base: tight fit is good.
    score = -residual
    # Penalize residuals that cannot usefully hold a typical future item
    # (mean item size ~40): waste grows as residual falls below ~40.
    typical = 40.0
    # amount of the residual that is "stranded" below a typical item size
    stranded = np.maximum(0.0, typical - residual)
    score -= 0.35 * stranded
    # Mild bonus for residuals just above the typical size (still fillable).
    score += 0.5 * ((residual >= typical) & (residual <= 2.0 * typical))
    return score
# EVOLVE-BLOCK-END
