# EVOLVE-BLOCK-START
"""Best fit with a mild penalty for opening fresh bins.

Pure best fit allocates tightly, but with Weibull-sized items it tends to
open many half-used bins.  Penalising empty (residual == 100) bins slightly
makes the policy prefer stuffing an existing partial bin whenever the
tightness difference is small, concentrating free space and reducing the
total number of bins opened.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item
          fits in, including unused bins (remaining capacity 100), in bin order.
    """
    residual_after = bins - item          # remaining capacity if placed here
    # Base: best fit (smaller residual_after is better).
    score = -(residual_after.astype(np.float64))
    # Mild penalty for using a completely empty bin: prefer reusing partial bins.
    score -= 0.5 * (bins == 100)
    return score
# EVOLVE-BLOCK-END
