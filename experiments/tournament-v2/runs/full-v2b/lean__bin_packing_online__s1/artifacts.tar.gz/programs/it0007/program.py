# EVOLVE-BLOCK-START
"""Hybrid bin-choice rule: size-class-aware scoring."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Tightness term: prefer small residual after placing.
    tight = -residual.astype(np.float64)

    # For items larger than half capacity, pure best fit is near-optimal.
    if item >= 50:
        return tight

    # For smaller items, add a small bonus for bins where the residual
    # after placement is a good match for typical future item sizes,
    # discouraging leaving large unusable gaps. Prefer to consume bins
    # whose post-placement residual is small enough that they stay
    # near-full (favoring full bins without wasting exact-fit bins).
    # Use a smooth preference for residuals in a moderate band.
    frac = residual.astype(np.float64) / 100.0
    # Mild preference for residuals around 20-40 (typical item sizes).
    target = 0.30
    match_bonus = -np.abs(frac - target)

    # Weight the bonus modestly to not override best fit much.
    return tight + 2.0 * match_bonus
# EVOLVE-BLOCK-END

