# EVOLVE-BLOCK-START
"""Best-fit with a clean expected-waste penalty driven by the empirical
past-item distribution, plus a sharp exact-fill and complement signal."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_recent = np.zeros(8, dtype=np.float64)
_recent_idx = 0
_cum = None


def priority(item, bins):
    global _hist, _n, _sum, _mean, _cum, _recent, _recent_idx
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item
    score = -residual.astype(np.float64)

    total = _hist.sum() + 1e-9
    cum = np.cumsum(_hist)
    _cum = cum
    res_int = np.clip(residual, 0, 100).astype(np.int64)

    # Exact-fill reward scaled by frequency of the just-filled size.
    exact = (residual == 0)
    if exact.any():
        freq_here = float(_hist[min(max(item, 0), 100)]) / total
        score += (10.0 + 12.0 * freq_here * 100.0 / 5000.0) * exact

    # Expected-waste penalty: residual r can only be "used up" if a future
    # item is <= r. The probability that a future item overshoots r is the
    # tail mass above r; weight the leftover waste by its residual size.
    if _n > 40.0:
        p_larger = 1.0 - cum[np.clip(res_int - 1, 0, 100)] / total
        p_larger = np.clip(p_larger, 0.0, 1.0)
        # Smaller residuals that are unlikely to be filled are pure waste.
        score -= 2.5 * p_larger * (residual > 0)

    # Bonus when residual equals the current item (stack identical sizes).
    same = (residual == item)
    if same.any():
        score += 1.5 * same

    # Reward residuals matching common past item sizes (likely exact refill).
    if _n > 20.0:
        freq = _hist[res_int]
        lo1 = _hist[np.clip(res_int - 1, 0, 100)]
        hi1 = _hist[np.clip(res_int + 1, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1)
        score += 4.0 * (nearby / total) * 100.0

        # Sharp complement: residual == current item + a recent item size.
        for w in range(_recent.shape[0]):
            want = int(round(_recent[w]))
            if want < 1:
                continue
            hit = (residual == item + want)
            if hit.any():
                score += 7.0 * hit

    _recent[_recent_idx % _recent.shape[0]] = float(item)
    _recent_idx += 1
    return score
# EVOLVE-BLOCK-END
