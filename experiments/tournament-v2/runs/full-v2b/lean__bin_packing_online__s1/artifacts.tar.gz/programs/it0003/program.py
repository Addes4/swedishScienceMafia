# EVOLVE-BLOCK-START
"""Best fit with a mild fill-bias to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (small residual is best => -residual).
    # Secondary: slight preference for bins that are already well-filled (low remaining),
    # to avoid wasting nearly-empty bins / opening new ones unnecessarily.
    return -residual.astype(np.float64) - 0.05 * (100 - bins) / 100.0
# EVOLVE-BLOCK-END
