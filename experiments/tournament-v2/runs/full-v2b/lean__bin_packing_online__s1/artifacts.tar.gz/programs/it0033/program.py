# EVOLVE-BLOCK-START
"""Best-fit with a residual-value curve tuned to the Weibull item distribution.

Prefer tight fits, but treat a post-placement residual as "wasted" when it is
too small to reliably hold a future item but too large to be closed by a near
match. Exact fills and residuals that can still hold a mean-size item are good.
"""
import numpy as np


def priority(item, bins):
    """Rank bins by the value of the residual left after placing the item.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    residual = bins - item  # leftover capacity if placed here
    r = residual.astype(np.float64)

    # Base drive: tighter fit is better.
    score = -r

    # Mid residuals (16..38) are the most wasteful: too big to be closed by an
    # exact match often enough, too small to hold an item near the mean (~40).
    trap = (residual >= 16) & (residual <= 38)
    score -= 6.0 * trap

    # Tiny unusable slivers (1..8) waste almost nothing but are rarely filled.
    sliver = (residual >= 1) & (residual <= 8)
    score -= 3.0 * sliver

    # Residuals in [40, 60] can still accept a mean-size item: keep them useful.
    useful = (residual >= 40) & (residual <= 60)
    score += 2.0 * useful

    return score
# EVOLVE-BLOCK-END
