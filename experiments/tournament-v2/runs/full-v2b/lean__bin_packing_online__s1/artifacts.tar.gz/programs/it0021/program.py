# EVOLVE-BLOCK-START
"""Best-fit variant using a sum-of-squares (balanced residual) ranking."""
import numpy as np


def priority(item, bins):
    """Rank bins by how balanced the resulting residuals are.

    We use a local surrogate of the global sum-of-squares objective:
    placing the item into a bin with residual r leaves r* = r - item.
    A sum-of-squares criterion prefers bins whose residual is large,
    so we reward large residuals while still giving a small bias toward
    tightness for small residuals (to avoid wasting nearly-full bins).
    """
    residual = bins - item
    # Sum-of-squares surrogate: bigger residual is better (balanced packing),
    # but give slight preference to tighter fits when residual is small.
    score = -(residual.astype(np.float64) ** 2) + 0.35 * residual
    return score
# EVOLVE-BLOCK-END
