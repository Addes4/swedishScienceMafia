# EVOLVE-BLOCK-START
"""Best-fit with exact-fill reward and a mild stateful complement bonus."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item
    score = -residual.astype(np.float64)

    # Strong reward for exactly filling a bin.
    exact = (residual == 0)
    score += 20.0 * exact

    # Penalize leaving a sliver too small to be refilled by a typical item.
    thr = 0.5 * _mean
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 6.0 * sliver

    # Mild stateful complement bonus: reward residuals that were recently
    # seen as item sizes (so they may be filled exactly).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        score += 3.0 * (freq / total) * 100.0

    return score
# EVOLVE-BLOCK-END
