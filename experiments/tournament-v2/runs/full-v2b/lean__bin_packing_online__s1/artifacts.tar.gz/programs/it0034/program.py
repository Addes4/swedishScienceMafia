# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty plus an online learned 'fillability' bonus."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits, penalize tiny leftovers, reward useful residuals.

    Additionally keep light state: for each observed post-placement residual we
    remember which residuals tended to get closed soon after. This nudges the
    rule away from gaps that empirically linger.
    """
    residual = bins - item  # leftover capacity if placed here (>= 0)

    # Base score: tight fit is good.
    score = -residual.astype(np.float64)

    # Penalize tiny unusable leftovers.
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver

    # Bonus for residuals in a "still useful" mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    return score
# EVOLVE-BLOCK-END
