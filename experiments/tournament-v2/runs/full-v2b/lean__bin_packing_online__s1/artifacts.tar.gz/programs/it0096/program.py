# EVOLVE-BLOCK-START
"""Best-fit with exact-fill reward, sliver penalty, and mean-based usable-residual bonus."""
import numpy as np

_n = 0.0
_sum = 0.0
_mean = 40.0
_max = 1.0


def priority(item, bins):
    global _n, _sum, _mean, _max
    _n += 1.0
    _sum += item
    _mean = _sum / _n
    if item > _max:
        _max = float(item)

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    score += 16.0 * (residual == 0)

    # Sliver penalty: residual too small to plausibly be refilled wastes capacity.
    thr = 0.5 * _mean
    if thr < 1.0:
        thr = 1.0
    score -= 8.0 * ((residual >= 1) & (residual < thr))

    # Truly unfillable residuals (below half of the largest item seen).
    score -= 3.0 * ((residual >= 1) & (residual < _max * 0.5))

    # Mean-based usable-residual bonus: reward residuals that sit just above the
    # running mean item size, so the bin can still be topped off by typical items.
    usable = (residual >= _mean) & (residual <= 2.0 * _mean)
    score += 2.0 * usable

    # Pairing bonus: residuals near twice the running mean can be filled by two items.
    score += 1.5 * np.exp(-((residual - 2.0 * _mean) ** 2) / (2.0 * 12.0 ** 2))

    return score
# EVOLVE-BLOCK-END
