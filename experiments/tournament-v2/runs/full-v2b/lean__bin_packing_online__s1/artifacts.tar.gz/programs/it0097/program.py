# EVOLVE-BLOCK-START
"""Best-fit with a data-driven fillability bonus from the decayed item histogram."""
import numpy as np

# State: decayed histogram of item sizes seen so far (indices 1..100),
# plus running count for warm-up gating.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0


def priority(item, bins):
    global _hist, _n
    # Update decayed histogram of past items.
    _hist *= 0.995
    _hist[item] += 1.0
    _n += 1.0

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: strictly the best outcome, outweigh everything.
    exact = (residual == 0)
    score += 20.0 * exact

    # Data-driven fillability: total probability mass of item sizes that fit
    # in this residual. A residual that most items cannot fit is nearly wasted.
    if _n > 10.0:
        total = _hist.sum() + 1e-9
        # Cumulative mass of sizes <= residual (a size <= residual can still fit).
        csum = np.cumsum(_hist)  # csum[k] = mass of sizes <= k
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        fit_mass = csum[res_clipped] / total          # prob next item fits here
        score += 6.0 * fit_mass

        # Complement bonus: mass of sizes that would exactly finish the residual.
        comp = _hist[res_clipped] / total
        score += 4.0 * comp

    return score
# EVOLVE-BLOCK-END

