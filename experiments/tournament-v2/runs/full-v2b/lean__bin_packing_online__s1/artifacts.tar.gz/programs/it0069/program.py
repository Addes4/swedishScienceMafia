# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty and a cheap stateful exact-fill bonus."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100).
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0

# Cache of the most frequent recent item sizes, refreshed periodically.
_top_sizes = np.zeros(0, dtype=np.int64)
_top_weights = np.zeros(0, dtype=np.float64)
_refresh_at = 0


def _refresh_top():
    global _top_sizes, _top_weights
    h = _hist[1:101]
    order = np.argsort(h)[::-1][:12]
    sizes = order + 1
    w = h[order]
    tot = h.sum() + 1e-9
    _top_sizes = sizes.astype(np.int64)
    _top_weights = w / tot


def priority(item, bins):
    global _hist, _n, _refresh_at, _top_sizes, _top_weights

    _hist *= 0.998
    _hist[item] += 1.0
    _n += 1.0

    residual = bins - item
    res = residual.astype(np.float64)
    score = -res

    # Penalize tiny unusable leftovers (slivers waste capacity).
    sliver = (residual >= 1) & (residual <= 12)
    score -= 7.0 * sliver

    # Stateful exact-fill bonus: reward residuals that match a common recent
    # item size, so a single typical item can complete the bin.
    if _n > 30.0:
        if _n >= _refresh_at:
            _refresh_top()
            _refresh_at = _n + 25.0
        bonus = np.zeros(res.shape[0], dtype=np.float64)
        for s, w in zip(_top_sizes, _top_weights):
            bonus += w * (residual == s)
        score += 300.0 * bonus

    return score
# EVOLVE-BLOCK-END

