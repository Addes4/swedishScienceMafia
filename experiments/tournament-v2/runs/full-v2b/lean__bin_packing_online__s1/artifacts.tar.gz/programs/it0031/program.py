# EVOLVE-BLOCK-START
"""Best-fit with a smooth, mild anti-sliver bias."""
import numpy as np


def priority(item, bins):
    """Rank bins: mostly best-fit, with a small penalty for near-zero residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    residual = (bins - item).astype(np.float64)  # leftover if placed here
    # Strongly prefer tight fits.
    score = -residual
    # Mildly penalize residuals that are too small to be useful later.
    # The penalty fades smoothly from residual 0 to ~20.
    small = np.clip(residual, 0.0, 20.0) / 20.0
    score -= 4.0 * ((1.0 - small) ** 2) * (residual >= 1.0)
    return score
# EVOLVE-BLOCK-END
