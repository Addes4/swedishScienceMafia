# EVOLVE-BLOCK-START
"""Class-aware fill targeting: prefer bins whose accumulated fill reaches a class target."""
import numpy as np

# Granularity of fill targets (bin capacity is 100).
G = 20
TARGETS = tuple(range(G, 101, G))  # 20,40,...,100


def _class_target(item):
    """Smallest target >= item (so the item can help reach that target)."""
    for t in TARGETS:
        if t >= item:
            return t
    return 100


def priority(item, bins):
    """Score bins by how closely placing `item` reaches the item's class target.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (capacity 100 total).
    """
    filled = 100 - bins  # amount already used in each bin
    target = _class_target(item)
    after = filled + item  # fill if placed here

    # Distance from reaching the target; exact hit is best, overshoot is penalized.
    diff = after - target
    # Prefer exact/small positive reach; heavily penalize overshoot beyond target.
    score = -np.abs(diff) - 5.0 * np.maximum(diff, 0)
    return score
# EVOLVE-BLOCK-END

