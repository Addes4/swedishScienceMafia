# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty plus histogram-driven complement/pairing bonus."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Penalize tiny unusable leftovers (slivers waste capacity).
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver

    if _n > 20.0:
        total = _hist.sum() + 1e-9
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)

        # Complement bonus: reward residuals that can be filled exactly
        # by a recently common item size.
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0

        # Pairing bonus: reward residuals that a typical future item would
        # fill with only a small leftover. For residual r, an item of size s
        # leaves leftover r-s. Reward residuals where a common item size is
        # close to but not exceeding r (small leftover => little waste).
        # Weight by item frequency so common sizes dominate.
        pair = np.zeros_like(score)
        for d in range(0, 6):
            s = res_clipped - d
            valid = (s >= 1) & (s <= 100)
            sc = np.where(valid, s, 1)
            pair += _hist[sc] * np.exp(-0.5 * (d / 3.0) ** 2) * valid
        score += 3.0 * (pair / total) * 100.0

    return score
# EVOLVE-BLOCK-END

