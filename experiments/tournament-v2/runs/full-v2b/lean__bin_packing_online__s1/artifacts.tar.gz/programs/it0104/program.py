# EVOLVE-BLOCK-START
"""Best-fit with exact-fill reward, an empirical expected-fill-value term
derived from the running histogram, and a light sliver penalty."""
import numpy as np

# State: decayed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Update decayed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    exact = (residual == 0)
    score += 16.0 * exact

    # Expected-fill value: for each residual, sum the probability mass of
    # item sizes (from the decayed histogram) that fit within that residual.
    # A residual that can be filled by many common item sizes is more valuable
    # to keep around than one that can only be filled by rare sizes.
    if _n > 30.0:
        total = _hist.sum() + 1e-9
        p = _hist / total
        cum = np.cumsum(p)  # cum[s] = P(item <= s)
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        # Mass of items that fit within each residual.
        fill_mass = cum[res_clipped]
        score += 6.0 * fill_mass

        # Smallest plausible item (15th percentile) for sliver detection.
        small_thr = float(np.searchsorted(cum, 0.15))
        if small_thr < 1.0:
            small_thr = 1.0
    else:
        small_thr = max(1.0, 0.5 * _mean)

    # Sliver penalty: residuals too small to be refilled by any commonly-seen
    # small item are likely wasted capacity.
    unfillable = (residual >= 1) & (residual < small_thr)
    score -= 3.0 * unfillable * (small_thr - residual)

    # Mean-adaptive sliver penalty for residuals below half the mean.
    thr = 0.5 * _mean
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 4.0 * sliver

    return score
# EVOLVE-BLOCK-END
