# EVOLVE-BLOCK-START
"""Best-fit with an online "usable residual" bonus to avoid dead gaps."""
import numpy as np


# Module-level persistent state (allowed: kept between calls).
_hist = np.zeros(101, dtype=np.float64)   # histogram of past item sizes
_count = 0
_median = 40.0


def priority(item, bins):
    """Rank bins: tight-fit dominant, plus a bonus for a usable residual."""
    global _count, _median, _hist

    # Update online estimate of the item-size distribution.
    if 1 <= item <= 100:
        _hist[item] += 1.0
        _count += 1
        if _count % 50 == 0:
            cum = np.cumsum(_hist)
            half = cum[-1] * 0.5
            _median = float(np.searchsorted(cum, half) + 1)

    residual = bins - item  # remaining capacity if item placed here

    # Dominant term: tight fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Bonus: avoid creating dead gaps. Reward exact fill or residual large
    # enough to still be useful for a typical (median-sized) future item.
    usable = (residual == 0) | (residual >= _median)
    score += 0.5 * usable.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
