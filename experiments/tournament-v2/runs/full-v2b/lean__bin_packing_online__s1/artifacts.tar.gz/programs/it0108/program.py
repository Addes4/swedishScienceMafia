# EVOLVE-BLOCK-START
"""Best-fit plus smooth residual-value based on the running item histogram."""
import numpy as np

_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item
    score = -residual.astype(np.float64)

    # Exact fill is the ideal outcome.
    exact = (residual == 0)
    score += 16.0 * exact

    # Smooth fullness value: a residual r is "valuable" proportionally to how
    # much of the past item-size distribution falls at or below r, i.e. the
    # chance a random future item fits and how close to full we are.  Use the
    # cumulative histogram mass up to r as a proxy for refill likelihood.
    res_clipped = np.clip(residual, 0, 100).astype(np.int64)
    total = _hist.sum() + 1e-9
    cum = np.cumsum(_hist) / total  # cum[k] = P(item <= k)
    can_fit = cum[res_clipped]      # probability a future item fits here
    # Reward residuals that are likely refillable (high can_fit) modestly.
    score += 2.0 * can_fit

    # Expected waste: a residual r that no common item can exactly fill is
    # likely to remain as dead capacity. Penalize proportionally.
    freq = _hist[res_clipped] / total
    score -= 6.0 * (1.0 - can_fit) * (res_clipped > 0)

    # Complement bonus: reward residuals matching a common recent item size.
    lo1 = _hist[np.clip(res_clipped - 1, 0, 100)] / total
    hi1 = _hist[np.clip(res_clipped + 1, 0, 100)] / total
    score += 3.0 * (freq + 0.5 * (lo1 + hi1)) * 100.0

    return score
# EVOLVE-BLOCK-END
