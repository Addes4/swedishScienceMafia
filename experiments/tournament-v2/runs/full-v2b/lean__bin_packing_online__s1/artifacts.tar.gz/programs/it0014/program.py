# EVOLVE-BLOCK-START
"""Best fit enhanced by a running histogram of item sizes.

Score = -(residual after placement)   [tight fit, dominant]
      + gamma * E[items absorbed by residual]

E[items absorbed by residual r] is approximated from a decaying histogram of
past item sizes: sum over sizes s <= r of p(s), i.e. roughly the probability
the residual can still fit a typical future item times an estimate of how many.
This gently biases toward bins whose leftover is likely usable, breaking the
plateaus of pure best-fit without hurting tight fits.
"""
import numpy as np

CAP = 100
# decaying histogram over item sizes 1..100
_hist = np.zeros(CAP + 1, dtype=np.float64)
_decay = 0.995
_gamma = 1.5


def priority(item, bins):
    global _hist
    # update histogram with the arriving item (only past info used for scoring)
    _hist *= _decay
    _hist[item] += 1.0

    residual = bins - item  # >= 0 for all bins shown

    # expected number/utility of items absorbable by a residual r:
    # approximate as (fraction of past items <= r) scaled by r / mean_item
    total = _hist.sum()
    if total <= 0:
        return -(residual)

    cum = np.cumsum(_hist)  # cum[s] = mass of sizes <= s
    mean_item = float(np.dot(np.arange(1, CAP + 1), _hist[1:]) / total)
    if mean_item <= 0:
        mean_item = 40.0

    r = residual.astype(np.int64)
    r = np.clip(r, 0, CAP)
    p_fit = cum[r] / total                 # prob a future item fits
    util = p_fit * (r / mean_item)         # approx count of absorbable items

    return -(residual) + _gamma * util
# EVOLVE-BLOCK-END
