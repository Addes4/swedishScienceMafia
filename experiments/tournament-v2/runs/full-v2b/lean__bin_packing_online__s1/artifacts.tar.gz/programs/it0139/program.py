# EVOLVE-BLOCK-START
"""Best-fit with adaptive sliver penalty, empirical exact-fill rewards, and a
single principled expected-waste signal derived from the past-item distribution."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean, the previous item size, and a short
# rolling window of recent item sizes.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_prev = 0.0
_recent = np.zeros(8, dtype=np.float64)  # ring of last few items
_recent_idx = 0


def priority(item, bins):
    global _hist, _n, _sum, _mean, _prev, _recent, _recent_idx
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    total_hist = _hist.sum() + 1e-9

    # Exact-fill reward, weighted by how common the just-filled size is.
    exact = (residual == 0)
    if exact.any():
        freq_here = float(_hist[min(max(item, 0), 100)]) / total_hist
        score += (10.0 + 12.0 * freq_here * 100.0 / 5000.0) * exact

    # Empirical small-item floor: 15th-percentile / 20th-percentile of past
    # item sizes. Residuals below these are unlikely to be refilled.
    if _n > 30.0:
        cum = np.cumsum(_hist)
        total = cum[-1] + 1e-9
        small_thr = float(np.searchsorted(cum, 0.15 * total))
        if small_thr < 1.0:
            small_thr = 1.0
        sliver_thr = float(np.searchsorted(cum, 0.20 * total))
        if sliver_thr < 1.0:
            sliver_thr = 1.0
    else:
        small_thr = max(1.0, 0.5 * _mean)
        sliver_thr = max(1.0, 0.5 * _mean)

    # Sliver penalty: residual too small to likely be refilled wastes capacity.
    sliver = (residual >= 1) & (residual < sliver_thr)
    score -= 8.0 * sliver

    # Residuals below the empirical smallest plausible item are unfillable.
    unfillable = (residual >= 1) & (residual < small_thr)
    if unfillable.any():
        score -= 3.0 * unfillable * (small_thr - residual)

    # Bonus when the residual equals the current item (stack identical sizes).
    same = (residual == item)
    if same.any():
        score += 1.5 * same

    # Multi-item capacity bonus: bins that can still hold several typical
    # items stay in play. Best-fit still dominates via the -residual term.
    typical = 0.5 * _mean
    if typical < 1.0:
        typical = 1.0
    kfit = np.floor(np.maximum(residual, 0) / typical)
    score += 1.2 * np.sqrt(kfit)

    # Principled expected-waste signal: for each residual r, estimate the
    # probability that the leftover capacity is stranded (no single future
    # item fits it) using the empirical size distribution, and penalize the
    # stranded capacity accordingly. This is the true driver of extra bins.
    if _n > 40.0:
        cum = np.cumsum(_hist)
        total_hist2 = cum[-1] + 1e-9
        res_int = np.clip(residual, 0, 100).astype(np.int64)
        # Probability that a future item is strictly larger than r.
        p_larger = 1.0 - cum[np.clip(res_int - 1, 0, 100)] / total_hist2
        p_larger = np.clip(p_larger, 0.0, 1.0)
        score -= 2.0 * p_larger * (residual > 0)

    # Direct exact pair-completion bonus: residual equals the current item plus
    # one of the recent item sizes, a high-precision closure signal.
    if _n > 8.0:
        for w in range(_recent.shape[0]):
            want = int(round(_recent[w]))
            if want < 1:
                continue
            target = item + want
            hit = (residual == target)
            if hit.any():
                score += 7.0 * hit

    _prev = float(item)
    _recent[_recent_idx % _recent.shape[0]] = float(item)
    _recent_idx += 1
    return score
# EVOLVE-BLOCK-END
