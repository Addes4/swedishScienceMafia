# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty, complement bonus, and fillability bonus."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Penalize tiny unusable leftovers (slivers waste capacity).
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver

    # Soft bonus for residuals in a still-useful mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Stateful complement bonus: reward a residual r by the historical mass
    # of items that would fit into r and leave only a small leftover
    # (i.e. items of size close to but not exceeding r).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        # items that fill this bin nearly fully: sizes in [r-3, r]
        m0 = _hist[res_clipped]
        m1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        m2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        m3 = _hist[np.clip(res_clipped - 3, 0, 100)]
        fillmass = m0 + 0.8 * m1 + 0.5 * m2 + 0.3 * m3
        score += 5.0 * (fillmass / total) * 100.0

    # Pairing bonus: reward residuals close to the running mean item size,
    # since such a bin is likely to be topped off by a single typical item.
    if _n > 20.0:
        score += 2.0 * np.exp(-((residual - _mean) ** 2) / (2.0 * 12.0 ** 2))

    return score
# EVOLVE-BLOCK-END
