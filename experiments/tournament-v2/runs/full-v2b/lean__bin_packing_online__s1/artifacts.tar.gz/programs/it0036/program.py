# EVOLVE-BLOCK-START
"""Best-fit with a distribution-scaled penalty on unusably small residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits, mildly penalize small leftovers.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    # Stateful running mean of item sizes (adapts to the distribution).
    state = priority.state
    state["n"] += 1
    m = state["mean"] + (item - state["mean"]) / state["n"]
    state["mean"] = m

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Penalize residuals that are too small to plausibly hold a future item.
    # Scale the penalty smoothly by how far below the mean item size they are.
    mu = max(m, 1.0)
    small = residual < mu
    # penalty in [0, ~1] grows as residual shrinks below mu
    frac = (mu - residual) / mu
    penalty = np.where(small, frac * frac, 0.0)
    score -= 6.0 * penalty

    return score


priority.state = {"n": 0, "mean": 40.0}
# EVOLVE-BLOCK-END
