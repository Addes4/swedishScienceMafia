# EVOLVE-BLOCK-START
"""Best-fit with size-aware wastage penalty."""
import numpy as np

_sum = 0.0
_cnt = 0


def priority(item, bins):
    """Rank bins: prefer tight fits, penalize unusable small leftovers."""
    global _sum, _cnt
    _sum += item
    _cnt += 1
    mean = _sum / _cnt

    residual = bins - item  # leftover capacity if placed here

    # Base: classic best-fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Penalize residuals that are too small to hold a typical future item,
    # but only when they are meaningfully below the running mean item size.
    scale = mean if mean > 1.0 else 40.0
    frac = residual.astype(np.float64) / scale
    sliver = (residual >= 1) & (frac < 0.6)
    score -= 6.0 * sliver

    return score
# EVOLVE-BLOCK-END
