# EVOLVE-BLOCK-START
"""Best-fit with mean-adaptive sliver penalty, empirical small-item floor,
a multi-item capacity bonus, and a previous-item pair-complement signal."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean, and the previous item size.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_prev = 0.0


def priority(item, bins):
    global _hist, _n, _sum, _mean, _prev
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    exact = (residual == 0)
    score += 16.0 * exact

    # Empirical "smallest plausible item": the 15th-percentile item size seen
    # so far. A residual below this is unlikely to ever be exactly refilled and
    # should be treated as wasted capacity.
    if _n > 30.0:
        total = _hist.sum() + 1e-9
        cum = np.cumsum(_hist)
        small_thr = float(np.searchsorted(cum, 0.15 * total))
        if small_thr < 1.0:
            small_thr = 1.0
        sliver_thr = float(np.searchsorted(cum, 0.20 * total))
        if sliver_thr < 1.0:
            sliver_thr = 1.0
    else:
        small_thr = max(1.0, 0.5 * _mean)
        sliver_thr = max(1.0, 0.5 * _mean)

    # Data-driven sliver penalty: residual too small to likely be refilled
    # wastes capacity. Threshold is the empirical 20th-percentile item size.
    thr = sliver_thr
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    # Residuals below the empirical smallest plausible item are truly
    # unfillable; penalize in proportion to how far below they fall.
    unfillable = (residual >= 1) & (residual < small_thr)
    if unfillable.any():
        score -= 3.0 * unfillable * (small_thr - residual)

    # Multi-item capacity bonus: a bin whose residual can still hold several
    # typical (mean-sized) items is more reusable than one that can hold only
    # a single one, so prefer keeping such bins in play. Best-fit still
    # dominates via the -residual term.
    typical = 0.5 * _mean
    if typical < 1.0:
        typical = 1.0
    kfit = np.floor(np.maximum(residual, 0) / typical)
    # Diminishing returns: only modestly reward extra item capacity.
    score += 1.2 * np.sqrt(kfit)

    # Stateful complement bonus: reward residuals that can be filled exactly
    # by a recently common item size (wider +/-2 window).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0
        # Sharper bonus for an exact match to a common item size.
        score += 3.0 * (freq / total) * 100.0

        # Pair-complement bonus: placing the current item into a bin leaves a
        # residual that a *pair* of common items could fill exactly. Reward a
        # residual that equals prev + a common item size, and also residuals
        # that the current item's residual could be closed by (prev + item)
        # sized arrivals, capturing two-item lookahead.
        if _prev >= 1.0:
            want = _prev
            cand = np.clip(res_clipped - want, 0, 100).astype(np.int64)
            pair_freq = _hist[cand]
            score += 2.0 * (pair_freq / total) * 100.0

    # Critical small-item reserve: residuals that are too small to ever hold a
    # mean-sized item are dead space unless a rare small item fits them exactly.
    # Softly discourage leaving such residuals unless almost-full so that bins
    # are consolidated more aggressively.
    if _n > 50.0:
        dead = (residual >= 1) & (residual < typical)
        # Only penalize when this residual is genuinely hard to reuse:
        # i.e. no common past item is close to the residual size.
        score -= 1.0 * dead * np.maximum(0.0, 1.0 - 0.5 * _mean / np.maximum(_mean, 1.0))

    _prev = float(item)
    return score
# EVOLVE-BLOCK-END

