# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware penalty on awkward residuals.

The gap left after a placement is only useful if future items can fill it.
Using a running histogram of item sizes, we score each bin by the residual
it would leave, adding a penalty when that residual falls in a range that
matches few likely future items (a "dead zone"), and no penalty when it is
0 (closed) or large enough to accept a typical item.
"""
import numpy as np

# persistent histogram over item sizes 1..100
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0


def priority(item, bins):
    global _count
    _count += 1.0
    _hist[item] += 1.0
    n = _count

    resid = bins - item  # residual after placing into each bin

    # Probability that a future item of size >= s arrives: tail probability.
    # We want residuals that are either 0 or can accept a substantial item.
    # Estimate from the running histogram (shifted by 1 for safe indexing).
    if n < 50:
        # not enough data; fall back to pure best fit
        return -resid

    h = _hist
    total = h.sum()
    # cumulative from the top: prob(item >= k)
    # tail[s] = P(size >= s)
    tail = np.zeros(102, dtype=np.float64)
    c = 0.0
    for s in range(100, 0, -1):
        c += h[s]
        tail[s] = c / total
    # tail[s] for s in 0..101
    tail[0] = 1.0
    tail[101] = 0.0

    # Score = prefer small residual (best fit) but reward residuals that are
    # likely fillable: a residual r has value ~ Expected number of items that
    # still fit. Approximate: value(r) = sum_{s<=r} P(size=s) * (something).
    # Simpler: penalize residuals whose matching probability is tiny.
    rs = np.clip(resid, 0, 100).astype(np.int64)

    # fillability: probability a random future item fits in residual r
    fill = np.array([1.0 - tail[r + 1] if r < 100 else 1.0 for r in range(101)])

    # Dead zone: mid residuals that are large enough to be "open" but too
    # small to accept a typical item, wasted slots. Penalize low fillability,
    # but allow r == 0 (perfectly closed) to score best.
    dead = (fill < 0.5) & (rs > 0)

    # base best-fit (smaller residual => higher score)
    score = -resid.astype(np.float64)
    # penalty for awkward residuals
    score = score - 30.0 * dead.astype(np.float64)
    # bonus for fully closed bins
    score = score + 5.0 * (rs == 0).astype(np.float64)
    return score
# EVOLVE-BLOCK-END
