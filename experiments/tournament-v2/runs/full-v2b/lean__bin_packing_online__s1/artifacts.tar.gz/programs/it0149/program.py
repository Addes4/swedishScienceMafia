# EVOLVE-BLOCK-START
"""Best-fit with mean-adaptive sliver penalty, empirical small-item floor,
a histogram-based refill-compatibility signal, and a weighted exact-fill
reward."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean, the previous item size, and a short
# rolling window of recent item sizes.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_prev = 0.0


def priority(item, bins):
    global _hist, _n, _sum, _mean, _prev
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    total_hist = _hist.sum() + 1e-9

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    # Weight by how common the just-filled size is.
    exact = (residual == 0)
    if exact.any():
        freq_here = float(_hist[min(max(item, 0), 100)]) / total_hist
        score += (10.0 + 12.0 * freq_here * 100.0 / 5000.0) * exact

    # Empirical percentiles of past item sizes.
    if _n > 30.0:
        total = _hist.sum() + 1e-9
        cum = np.cumsum(_hist)
        small_thr = float(np.searchsorted(cum, 0.15 * total))
        if small_thr < 1.0:
            small_thr = 1.0
        sliver_thr = float(np.searchsorted(cum, 0.20 * total))
        if sliver_thr < 1.0:
            sliver_thr = 1.0
    else:
        small_thr = max(1.0, 0.5 * _mean)
        sliver_thr = max(1.0, 0.5 * _mean)

    # Data-driven sliver penalty: residual too small to likely be refilled.
    thr = sliver_thr
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    # Residuals below the empirical smallest plausible item are unfillable.
    unfillable = (residual >= 1) & (residual < small_thr)
    if unfillable.any():
        score -= 3.0 * unfillable * (small_thr - residual)

    # Bonus when the residual equals the current item: encourages stacking
    # identical sizes in the same bin.
    same = (residual == item)
    if same.any():
        score += 1.5 * same

    # Refill-compatibility signal: reward residuals that match a commonly seen
    # item size (so the leftover is likely to be exactly closed soon).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1)
        score += 3.5 * (nearby / total) * 100.0

        # Pair-complement: residual equal to (current item + a common past
        # item size) could be closed on the very next item.
        comp = np.clip(res_clipped - int(item), 0, 100).astype(np.int64)
        score += 1.5 * (_hist[comp] / total) * 100.0

    _prev = float(item)
    return score
# EVOLVE-BLOCK-END

