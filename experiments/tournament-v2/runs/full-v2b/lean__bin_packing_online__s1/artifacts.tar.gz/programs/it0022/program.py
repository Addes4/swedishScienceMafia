# EVOLVE-BLOCK-START
"""Best fit, augmented by the empirical popularity of the leftover size.

Plain best-fit only cares about leaving the *smallest* residual.  A residual is
only useful if some future item can actually fill it.  We therefore keep a
running histogram of the item sizes seen so far and add a bonus proportional to
how popular the leftover size is: a bin whose post-placement residual equals a
very common item size is worth choosing even if a rival bin would leave a
slightly smaller residual.  This is a genuine reordering (the bonus magnitude
can exceed one unit of residual), unlike small monotonic tweaks around best-fit.
"""
import numpy as np

# Laplace-smoothed empirical histogram of observed item sizes (index 1..100).
_hist = np.ones(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _hist
    _hist[item] += 1.0

    bins = np.asarray(bins)
    residual = (bins - item).astype(np.int64)

    # Base: best fit (smaller residual is better).
    score = -residual.astype(np.float64)

    # Bonus: leftover capacity that matches a frequently seen item size is more
    # likely to be filled later, so it is not wasted.
    total = _hist[1:].sum()
    pop = _hist[np.clip(residual, 0, 100)] / total
    score += 3.0 * pop

    return score
# EVOLVE-BLOCK-END
