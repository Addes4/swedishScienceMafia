# EVOLVE-BLOCK-START
"""Best-fit augmented by an empirical item-size histogram: prefer residuals that
match sizes seen so far, not just the current item."""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    global _HIST, _TOTAL

    # Update the running histogram (exponential-free, simple counts).
    _HIST[item] += 1.0
    _TOTAL += 1.0
    probs = _HIST / _TOTAL  # probability mass per size 1..100

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - item  # remaining capacity after placing the item

    # Base term: best fit (smaller residual is better).
    score = -residual

    # Secondary term: for each candidate residual r, estimate how likely a future
    # item will fit snugly.  We reward residuals that leave a small residual
    # after fitting a typical future item s <= r, weighted by p(s).
    # Approximate by summing over s in a small window of likely sizes.
    sizes = np.arange(1, 101, dtype=np.float64)
    p = probs[1:101]
    mask = sizes[None, :] <= residual[:, None]  # (nbins, 100)
    # after fitting s, leftover = r - s ; smaller leftover is better -> reward
    leftover = residual[:, None] - sizes[None, :]
    # weight each s by p(s); prefer s that exactly consumes residual (leftover 0)
    contrib = np.where(mask, p[None, :] / (1.0 + leftover), 0.0)
    score = score + 0.001 * contrib.sum(axis=1)

    return score
# EVOLVE-BLOCK-END
