# EVOLVE-BLOCK-START
"""Best-fit with exact-fill reward and a mild new-bin avoidance penalty."""
import numpy as np

# State: running count (kept only so the function remains stateful if needed).
_n = 0.0


def priority(item, bins):
    global _n
    _n += 1.0

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact fill: nothing wasted, always the best outcome.
    exact = (residual == 0)
    score += 1000.0 * exact

    # Avoid opening a brand-new empty bin if any used bin can hold the item.
    fresh = (bins == 100)
    score -= 0.5 * fresh

    return score
# EVOLVE-BLOCK-END
