# EVOLVE-BLOCK-START
"""Best-fit with a soft, mean-scaled wastage penalty."""
import numpy as np


def priority(item, bins):
    """Score bins: best-fit, softly penalizing slivers scaled by typical item size.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    residual = (bins - item).astype(np.float64)  # leftover if placed here
    # Classic best-fit: tight fit is best.
    score = -residual
    # Soft penalty for small leftovers that rarely get filled: scale-free in
    # the residual, growing as the residual shrinks toward zero.
    small = residual < 30.0
    score -= 6.0 * small * (1.0 - residual / 30.0)
    # Mild bonus for residuals that can still hold a typical (~mean) item.
    useful = (residual >= 30.0) & (residual <= 60.0)
    score += 1.0 * useful
    return score
# EVOLVE-BLOCK-END

