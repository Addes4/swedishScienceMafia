# EVOLVE-BLOCK-START
"""Best-fit with smooth mean-graded sliver penalty and light completion bonus."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Smooth mean-adaptive sliver penalty: residuals that are small relative to
    # the typical item size are unlikely to be refilled, so they waste capacity.
    # Grade smoothly instead of a hard step to avoid over-penalizing middling
    # residuals that may still be useful.
    m = _mean
    if m < 1.0:
        m = 1.0
    # Penalty grows as residual shrinks below ~0.5*mean.
    smallness = np.clip((0.5 * m - residual) / (0.5 * m + 1e-9), 0.0, 1.0)
    score -= 6.0 * smallness * smallness

    # Soft reward for residuals near the running mean: a bin that can be topped
    # off by a single typical item.
    if _n > 20.0:
        score += 2.0 * np.exp(-((residual - m) ** 2) / (2.0 * 14.0 ** 2))

    # Light completion bonus: reward residuals matching a common recent item
    # size (so the bin can be exactly finished later).
    if _n > 30.0:
        total = _hist.sum() + 1e-9
        rc = np.clip(residual, 0, 100).astype(np.int64)
        exact = _hist[rc] / total
        score += 3.0 * exact * 100.0

    return score
# EVOLVE-BLOCK-END
