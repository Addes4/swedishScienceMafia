# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty, complement bonus, and near-mean pairing bonus."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean, and a smoothed running mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Penalize tiny unusable leftovers (slivers waste capacity).
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver

    # Soft bonus for residuals in a still-useful mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Stateful complement bonus: reward residuals that can be filled exactly
    # by a recently common item size (wider +/-2 window).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        nearby = freq.copy()
        # Multi-scale steep-falloff window: closer sizes weighted much more.
        for d in range(1, 5):
            w = 0.7 ** d
            lo = _hist[np.clip(res_clipped - d, 0, 100)]
            hi = _hist[np.clip(res_clipped + d, 0, 100)]
            nearby += w * (lo + hi)
        score += 4.0 * (nearby / total) * 100.0

    # Pairing bonus: reward residuals close to the running mean item size,
    # since such a bin is likely to be topped off by a single typical item.
    if _n > 20.0:
        score += 3.0 * np.exp(-((residual - _mean) ** 2) / (2.0 * 12.0 ** 2))

    return score
# EVOLVE-BLOCK-END
