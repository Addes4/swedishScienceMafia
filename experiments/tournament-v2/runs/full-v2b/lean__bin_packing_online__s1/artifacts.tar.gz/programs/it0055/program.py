# EVOLVE-BLOCK-START
"""Best-fit with sliver penalty, complement bonus, and histogram-based pairing."""
import numpy as np

# State: smoothed histogram of item sizes seen so far (indices 1..100),
# running sum and count for the mean.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0


def priority(item, bins):
    global _hist, _n, _sum, _mean
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Penalize tiny unusable leftovers (slivers waste capacity).
    sliver = (residual >= 1) & (residual <= 15)
    score -= 8.0 * sliver

    # Soft bonus for residuals in a still-useful mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Stateful complement bonus: reward residuals that can be filled exactly
    # by a recently common item size (wider +/-2 window).
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0

        # Histogram-based pairing bonus: for each residual, sum the
        # probability mass of future items that would leave a small
        # residual, i.e. items that nearly exactly fill this bin. This
        # directly estimates how likely the leftover can be consumed.
        # residual is r; a future item of size ~r fills exactly.
        # Also reward r + s staying small-ish for a common next item.
        # Compute expected remaining slack after best single future item.
        cnt = len(residual)
        idx = res_clipped
        # probability mass at exact fill and one step under
        p_exact = _hist[idx] / total
        p_under = _hist[np.clip(idx - 1, 0, 100)] / total
        fill_prob = p_exact + 0.7 * p_under
        score += 30.0 * fill_prob

    # Pairing bonus: reward residuals close to the running mean item size,
    # since such a bin is likely to be topped off by a single typical item.
    if _n > 20.0:
        score += 2.0 * np.exp(-((residual - _mean) ** 2) / (2.0 * 12.0 ** 2))

    return score
# EVOLVE-BLOCK-END

