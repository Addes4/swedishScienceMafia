# EVOLVE-BLOCK-START
"""Best-fit with exact-fill reward and an expected-future-waste penalty.

The penalty approximates the probability that a residual cannot be refilled
by any future item, using an online histogram of observed item sizes.
"""
import numpy as np

# State: decayed histogram of item sizes (indices 1..100), running stats.
_hist = np.zeros(101, dtype=np.float64)
_n = 0.0
_sum = 0.0
_mean = 40.0
_max = 1.0


def priority(item, bins):
    global _hist, _n, _sum, _mean, _max
    # Update smoothed histogram / running statistics of past items.
    _hist *= 0.999
    _hist[item] += 1.0
    _n += 1.0
    _sum += item
    _mean = _sum / _n
    if item > _max:
        _max = float(item)

    residual = bins - item  # leftover capacity if placed here
    score = -residual.astype(np.float64)

    # Exact-fill reward: placing here wastes nothing, strictly best outcome.
    exact = (residual == 0)
    score += 16.0 * exact

    # Mean-adaptive sliver penalty: residual too small to likely be refilled
    # wastes capacity. Threshold scales with typical item size.
    thr = 0.5 * _mean
    if thr < 1.0:
        thr = 1.0
    sliver = (residual >= 1) & (residual < thr)
    score -= 8.0 * sliver

    # Residuals below the smallest plausible item are truly unfillable.
    unfillable = (residual >= 1) & (residual < _max * 0.5)
    score -= 3.0 * unfillable

    # Soft bonus for residuals in a still-useful mid range.
    useful = (residual >= 35) & (residual <= 65)
    score += 1.5 * useful

    # Expected-future-fill term: reward residuals that a plausible next item
    # can land on exactly, estimated from the online histogram.
    if _n > 20.0:
        res_clipped = np.clip(residual, 0, 100).astype(np.int64)
        total = _hist.sum() + 1e-9
        freq = _hist[res_clipped]
        lo1 = _hist[np.clip(res_clipped - 1, 0, 100)]
        hi1 = _hist[np.clip(res_clipped + 1, 0, 100)]
        lo2 = _hist[np.clip(res_clipped - 2, 0, 100)]
        hi2 = _hist[np.clip(res_clipped + 2, 0, 100)]
        nearby = freq + 0.6 * (lo1 + hi1) + 0.3 * (lo2 + hi2)
        score += 4.0 * (nearby / total) * 100.0
        # Sharper bonus for an exact match to a common item size.
        score += 3.0 * (freq / total) * 100.0

    return score
# EVOLVE-BLOCK-END
