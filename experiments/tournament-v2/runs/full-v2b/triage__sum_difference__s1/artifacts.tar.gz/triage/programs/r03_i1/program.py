# EVOLVE-BLOCK-START
"""Two-scale set optimization using Bayesian-style hill climbing for large |A-A| and small |A+A|."""
import math
import random
import time
from functools import lru_cache


def compute_score(A):
    """Compute (-1) * log|A-A| / log|A+A| using a set. Returns positive ratio."""
    A_set = set(A)
    n = len(A_set)
    if n < 2:
        return 0.0
    
    # Compute sums
    sums = set()
    for a in A_set:
        for b in A_set:
            sums.add(a + b)
    
    # Compute differences
    diffs = set()
    for a in A_set:
        for b in A_set:
            diffs.add(a - b)
    
    if len(summons) < 2 or len(diffs) < 2:
        return 0.0
    
    score = math.log(len(diffs)) / math.log(len(summons))
    score += (1 - 1.0 / n) / 100.0
    return score


def solve():
    best_a = []
    deadline = time.time() + 115.0
    
    # We'll build a two-scale set:
    # Part 1: Dense consecutive block [s, s+L-1]
    # Part 2: Geometric progression [T * r^i for i in range(M)]
    # We need to carefully choose s, L, T, r, M
    
    # Let's first create a fixed structure and then search over parameters
    r = 1.04  # Base 1.04 to keep elements from growing too fast but still creating distinct sums
    base_block_size = 800
    geom_size = 1200
    shift = 10**12
    
    # We need to make sure we don't hit boundaries (1e15).
    # Let's carefully choose the starting point for the block so that block + geom doesn't overflow.
    
    best_score = 0.0
    best_set = None
    
    # Try a few different configurations in parallel
    candidates = []
    
    # Configuration 1: Try the basic two-scale structure
    configs = [
        # (base_block_start, block_size, geom_start, geom_base, geom_count)
        (0, 1000, 10**12, 1.05, 2000),
        (500000000000000, 200, 10**10, 1.03, 1500),
        (0, 500, 10**11, 1.06, 1500),
        (1000, 300, 10**11, 1.04, 1800),
        (0, 250, 10**11, 1.05, 1600),
    ]
    
    # Prime search over configurations with local evolution
    for config_idx, conf in enumerate(configs):
        start_s = conf[0]
        base_size = conf[1]
        geom_shift = conf[2]
        geom_r = conf[3]
        geom_count = conf[4]
        
        cur_a = list(range(start_s, start_s + base_size))
        
        # Add geometric progression far away
        cur_geometric = []
        for i in range(geom_count):
            val = int(geom_shift * (geom_r ** i))
            cur_geometric.append(val)
        
        candidate = cur_a + cur_geometric
        candidate = list(set(candidate))
        
        best_config_score = compute_score(candidate)
        if best_config_score > best_score:
            best_score = best_config_score
            best_set = candidate
        
        # Now do local optimization on this configuration
        # Keep track of recent good configurations
        recent = [candidate]
        
        for _ in range(50):  # Max iterations per config
            if time.time() > deadline:
                break
            
            # Find best recent config
            best_local = max(recent, key=lambda x: compute_score(x))
            if compute_score(best_local) <= best_score:
                recent.append(best_local)
                best_local_score = best_score
                continue
                    
            idx = random.randint(0, len(best_local) - 1)
            
            # Try a small mutation
            mutated = best_local[:]
            
            # Mutate a random element
            base_elements = [e for e in mutated if e < 10**11]
            large_elements = [e for e in mutated if e >= 10**11]
            
            if random.random() < 0.7:
                if len(base_elements) > 0:
                    elem = base_elements[random.randint(0, len(base_elements) - 1)]
                    mutated[idx] = elem + random.randint(-5, 5)
                    mutated = [x for x in set(mutated) if x < 10**14]
            else:
                if len(large_elements) > 0:
                    elem = large_elements[random.randint(0, len(large_elements) - 1)]
                    mutated[idx] = elem + int(elem * 0.01 * random.choice([-1, 1]))
                    mutated = [x for x in set(mutated) if abs(x) <= 10**15]
            
            # Probability to add/remove elements
            if random.random() < 0.1 and len(mutated) < 3500:
                val = random.randint(10**8, 10**9) if len([x for x in mutated if x < 10**11]) < 1000 else random.randint(10**10, 10**11)
                mutated.append(val)
                mutated = list(set(mutated))
            
            if random.random() < 0.05 and len(mutated) > 800:
                if len(mutated) > 1:
                    mutated.pop(len(mutated) - 1)
            
            # Check mutated validity and score
            mutated = sorted(list(set(mutated)))
            mutated = mutated[:3800]  # Cap at 3800 to avoid expensive computation
            
            if len(mutated) < 2:
                continue
                
            current_score = compute_score(mutated)
            if current_score >= best_score:
                recent.append(mutated)
                best_score = current_score
                best_set = mutated
    
    # If we haven't broken the barrier, try the official baseline structure
    if best_score < 1.20:
        baseline = [7, 15, 18, 22, -3, -2]
        best_score_lines = compute_score(baseline)
        if best_score_lines > best_score:
            best_score = best_score_lines
            best_set = baseline
    
    # Final cleanup
    if best_set is None:
        best_set = []
    
    return sorted(list(set(best_set)))

# Helper for local testing
def compute_score_s(a):
    s = set([a])
    return 0

if __name__ == "__main__":
    # Run the solve function
    result = solve()
    print(f"Final set size: {len(result)}")
    print(f"Set: {result}")
# EVOLVE-BLOCK-END
