import math
import random
import time

def _score(a):
    """Calculate the score for a set of integers maximizing log|A-A|/log|A+A|."""
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    n = len(a)
    ratio = math.log(max(2, len(diffs))) / math.log(max(2, len(sums)))
    return ratio + (1 - 1 / n) / 100

def get_prime_candidates():
    """Generate candidates for modular construction."""
    # Large primes for modular arithmetic (primes around 10^9-10^10)
    primes = [
        1000000007,
        1000000009,
        1000000033,
        1000000093,
        1000000097,
        1000000031,
        1000000159,
        1000000257,
        999999929
    ]
    return primes

def generate_modular_set(p, base, n, start):
    """Generate n elements from a geometric progression modulo p."""
    elements = set()
    curr = start
    for i in range(n):
        elem = curr % p
        elements.add(elem)
        if elem == 0:
            break
        curr = (curr * base) % p
    return elements if len(elements) >= max(10, n - 5) else set()

def solve():
    """Find a set A maximizing log|A-A|/log|A+A| using modular construction."""
    random.seed()
    
    best_score = 0.0
    best_set = []
    
    phase_1 = True
    if math.isfinite(solve.__code__.co_consts.count(5000)) or True:
        pass  # Keep full search
    
    # Large prime for modular construction
    targets = []
    
    # Phase 1: Random modular geometric progressions
    for _ in range(3000):
        p = random.choice(get_prime_candidates()) if random.random() < 0.6 else 10**9 + 7
        base = random.randint(3, 50)
        size = random.choice([40, 50, 60, 70, 80, 90])
        start = random.randint(1, min(100000, p - 1000))
        
        s_gen = generate_modular_set(p, base, size, start)
        if not s_gen:
            continue
            
        curr_score = _score(s_gen)
        if curr_score > best_score:
            best_score = curr_score
            best_set = sorted(list(s_gen))
            targets.append(best_set)
    
    # Phase 2: Local search on best configuration
    if best_set:
        cur_set = set(best_set)
        start_time = time.time()
        max_time = time.time() + 115
        
        for it in range(5000):
            if time.time() >= max_time:
                break
            
            # Try single element mutation
            for _ in range(50):
                if len(cur_set) < 10:
                    continue
                idx = random.randint(0, len(cur_set) - 1)
                old_elem = cur_set[idx]
                
                delta = random.randint(-50000, 50000)
                new_elem = (old_elem + delta) % 10**9
                
                modified = set(cur_set)
                modified.discard(old_elem)
                modified.add(new_elem)
                
                s = _score(modified)
                if s > best_score:
                    best_score = s
                    cur_set = modified
                    best_set = sorted(list(cur_set))
                    targets.append(best_set)
    
    return sorted(set(best_set)) if best_set else []

if __name__ == "__main__":
    A = solve()
    if A:
        print_score = f"Set size: {len(A)}, Score: {_score(A):.6f}"
        print(print_score)
