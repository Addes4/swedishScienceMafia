# EVOLVE-BLOCK-START
"""Continuous relaxation: Gaussian probability clouds -> smooth proxy for
|A-A| / |A+A|, gradient ascent on the means, then discretize & hill-climb.

Idea:
  Place n Gaussian "clouds" with means mu_i and a common bandwidth h.
  The mixture density is p(x) = (1/n) sum_i N(x; mu_i, h^2).
  Difference/sum densities:  d(z) = int p(x) p(x - z) dx  (a mixture of
  Gaussians centered at mu_i - mu_j with variance 2h^2), and
  s(z) = int p(x) p(z - x) dx (centers mu_i + mu_j, variance 2h^2).
  We use continuous entropies as a smooth stand-in for the log-counts:
      H(X-Y) = -int d log d,  H(X+Y) = -int s log s
  (differential entropies ~ log of the effective volume / number of distinct
  values).  We maximise H(X-Y) - H(X+Y), which pushes differences apart and
  sums together.

  Gradients are obtained by Monte-Carlo: sample pairs of mixture components
  (a,b) i.e. Gaussian means for the differences, and use the reparameterization
  trick / score-function estimator for the entropy via the "entropy of a
  Gaussian mixture" identity computed by pairwise interactions.

  Because exact entropy of a Gaussian mixture has no closed form, we use the
  well-known variational upper bound (Huber et al.) whose gradient is cheap:
      H(mixture) <= sum_k w_k ( -log w_k + H(N_k) )  ... we instead use the
  simpler and effective proxy based on the "kernel-density collision" energy:
      En(X) = -log sum_{k,l} w_k w_l K(mu_k - mu_l)
  with K a Gaussian kernel.  Maximising the difference entropy and minimising
  the sum entropy gives a smooth objective whose gradient we compute exactly.

  After optimisation we snap the means to integers and locally hill-climb
  using the exact discrete score.
"""
import math
import random
import time

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None


# ---------------------------------------------------------------- exact score
def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


# ------------------------------------------------------------- smooth proxy
def _kernel_energy(centers, w, h):
    """Smooth proxy for log(#distinct values) of a mixture of Gaussians with
    means `centers` (shape (m,2)) at bandwidth h and weights w (shape (m,)).

    E = -log sum_{k,l} w_k w_l exp(-|c_k - c_l|^2 / (4 h^2))
        + log(4*pi*h^2)/... (constant shift handled by caller)

    Larger E <-> the components are spread out (many distinct values).
    """
    # pairwise squared distances
    diff = centers[:, None, :] - centers[None, :, :]
    d2 = np.sum(diff * diff, axis=2)
    K = np.exp(-d2 / (4.0 * h * h))
    ww = w[:, None] * w[None, :]
    coll = np.sum(ww * K)
    coll = max(coll, 1e-300)
    return -math.log(coll)


def _grad_energy(centers, w, h):
    """Gradient of _kernel_energy wrt `centers` (shape (m,2))."""
    diff = centers[:, None, :] - centers[None, :, :]
    d2 = np.sum(diff * diff, axis=2)
    K = np.exp(-d2 / (4.0 * h * h))
    ww = w[:, None] * w[None, :]
    coll = np.sum(ww * K)
    coll = max(coll, 1e-300)
    # d(coll)/d(c_k) = sum_l w_k w_l * exp(...) * (-2 (c_k - c_l) / (4 h^2))
    #                = -(1/(2 h^2)) sum_l w_k w_l K_kl (c_k - c_l)
    grad_coll = -(1.0 / (2.0 * h * h)) * np.sum(
        (ww * K)[:, :, None] * diff, axis=1
    )
    # d E / d c = -(1/coll) * d coll / d c
    return -grad_coll / coll


def _continuous_objective(mu, h, w=None):
    """mu: (n,) real means. Build difference centers mu_i - mu_j and
    sum centers mu_i + mu_j, compute entropylike energy for both, return
    (score, grad wrt mu)."""
    n = len(mu)
    if w is None:
        w = np.full(n, 1.0 / n)

    # difference components: mu_i - mu_j for i != j  (plus zero diagonal)
    diff_c = (mu[:, None] - mu[None, :]).reshape(-1, 1)
    sum_c = (mu[:, None] + mu[None, :]).reshape(-1, 1)
    ww = (w[:, None] * w[None, :]).reshape(-1)

    E_diff = _kernel_energy(diff_c, ww, h)
    E_sum = _kernel_energy(sum_c, ww, h)

    # objective: want differences spread (large E_diff),
    #            sums clustered (small E_sum) -> maximise E_diff - E_sum
    obj = E_diff - E_sum

    # gradients
    g_diff = _grad_energy(diff_c, ww, h)   # (m,1)
    g_sum = _grad_energy(sum_c, ww, h)     # (m,1)

    # assemble chain rule to mu: diff_c[(i,j)] = mu_i - mu_j
    gd = g_diff.reshape(n, n)
    gs = g_sum.reshape(n, n)

    grad = np.zeros(n)
    # d obj / d mu_k = sum_{i,j} dE_diff/d(c_ij) * dc_ij/dmu_k
    #                - sum_{i,j} dE_sum/d(s_ij)  * ds_ij/dmu_k
    # c_ij = mu_i - mu_j : d/dmu_k = +1 if i=k, -1 if j=k
    # s_ij = mu_i + mu_j : d/dmu_k = +1 if i=k, +1 if j=k
    col_diff = gd.sum(axis=0)     # sum_j gd[i,j] over i -> contribution as "i=k"
    row_diff = gd.sum(axis=1)     # sum_i gd[i,j] over j
    grad += row_diff - col_diff

    col_sum = gs.sum(axis=0)
    row_sum = gs.sum(axis=1)
    grad -= row_sum + col_sum

    return obj, grad


# ------------------------------------------------------------- discretize
def _snap_and_hill(mu, deadline):
    """Snap real means to integers, then local hill-climb with exact score."""
    base = sorted({int(round(x)) for x in mu})
    if len(base) < 2:
        base = [0, 1]

    def sc(a):
        return _score(a)

    best = list(base)
    best_score = sc(best)
    cur = list(best)

    # also try a few shifted/quantized variants
    for shift in (0, -1, 1):
        cand = sorted({int(round(x)) + shift for x in mu})
        if cand:
            s = sc(cand)
            if s > best_score:
                best, best_score, cur = cand, s, cand

    step = 1
    fails = 0
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-step, step) or 1
        # occasional add/remove
        r = random.random()
        if r < 0.06 and len(cand) < 200:
            cand.append(random.choice(cand) + random.randint(-5, 5))
        elif r < 0.09 and len(cand) > 4:
            del cand[random.randrange(len(cand))]
            if len(cand) < 2:
                continue
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = sc(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand[:]
            fails = 0
        else:
            fails += 1
            if fails > 40:
                cur = best[:]
                fails = 0
                step = 1 if step > 1 else 1
            if random.random() < 0.15:
                cur = best[:]
    return best


# ---------------------------------------------------------------- driver
def solve():
    if np is None:
        # fallback tiny search if numpy missing (should not happen)
        return [7, 15, 18, 22, -3, -2]

    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # a pool of good small seeds helps escape local optima
    seeds = [
        [7, 15, 18, 22, -3, -2],
        [0, 1, 3, 7, 12, 20],
        [1, 2, 4, 8, 16, 32],
    ]

    trials = 0
    while time.time() < deadline * 0.999 and (best is None or time.time() < deadline):
        trials += 1
        # choose size
        if best is None:
            n = random.choice([6, 8, 10, 12])
        else:
            n = int(len(best) * random.uniform(0.8, 1.3))
            n = max(4, min(60, n))

        if trials <= len(seeds):
            mu0 = np.array(seeds[trials - 1], dtype=float)
            n = len(mu0)
        else:
            mu0 = np.random.randn(n) * random.uniform(2, 8)

        mu = mu0.copy().astype(float)
        h = random.uniform(0.6, 1.6)

        # gradient ascent (Adam-ish) on the continuous proxy
        lr = 0.15
        m_v = np.zeros_like(mu)
        v_v = np.zeros_like(mu)
        beta1, beta2 = 0.9, 0.999
        eps = 1e-8
        it = 0
        max_it = 400
        while it < max_it and time.time() < deadline:
            it += 1
            try:
                obj, grad = _continuous_objective(mu, h)
            except Exception:
                break
            if np.any(np.isnan(grad)) or np.any(np.isinf(grad)):
                break
            # normalise gradient for stability
            gn = np.linalg.norm(grad)
            if gn > 1e3:
                grad = grad / gn * 1e3
            m_v = beta1 * m_v + (1 - beta1) * grad
            v_v = beta2 * v_v + (1 - beta2) * grad * grad
            mh = m_v / (1 - beta1 ** it)
            vh = v_v / (1 - beta2 ** it)
            step = lr * mh / (np.sqrt(vh) + eps)
            # damp large moves
            mu = mu + step
            lr *= 0.997
            if lr < 1e-3:
                lr = 1e-3

        # discretize + hill-climb on the exact discrete objective
        t_left = deadline - time.time()
        if t_left <= 0:
            t_left = 1.0
        cand = _snap_and_hill(mu, time.time() + max(0.5, min(6.0, t_left * 0.4)))
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]

        if best is None:
            best = sorted({int(round(x)) for x in mu}) or [0, 1]

    # final polishing pass with the remaining time
    if best is not None:
        cand = _snap_and_hill(best, deadline)
        s = _score(cand)
        if s > best_score:
            best, best_score = cand, s

    return sorted(set(best))


# ================================================================ local test
if __name__ == "__main__":
    t0 = time.time()
    A = solve()
    print("n =", len(A), "time =", round(time.time() - t0, 2))
    print("score =", _score(A))
    print("sample =", A[:30])
# EVOLVE-BLOCK-END
