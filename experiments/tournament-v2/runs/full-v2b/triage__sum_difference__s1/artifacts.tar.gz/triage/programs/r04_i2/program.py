# EVOLVE-BLOCK-START
"""Greedy Sidon set + integer-programming-chosen large-scale sum-free breakers.

Strategy:
  1) Build a large Sidon set S (all pairwise sums distinct) inside a bounded range,
     so |S+S| = |S|(|S|+1)/2 is as concentrated as possible while |S-S| stays large.
  2) Add a small set B of large-scale "breakers" that:
       - create many new differences with S (each b - s distinct),
       - avoid creating new sums among themselves (B is sum-free wrt B+B),
       - avoid colliding with S+S so |A+A| stays small.
     Selection via scipy MILP (integer programming with lazy/constraint formulation),
     falling back to greedy if the solver is unavailable.

Maximise log|A-A| / log|A+A| plus small size bonus.
"""
import math
import random
import time

try:
    import numpy as np
    from scipy.optimize import milp, LinearConstraint, Bounds
    _HAS_MILP = True
except Exception:
    _HAS_MILP = False


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _greedy_sidon(n, bound):
    """Greedy Sidon set: add smallest integer keeping all pairwise sums distinct."""
    S = []
    sumset = set()
    cand = 0
    while len(S) < n and cand <= bound:
        ok = True
        new_sums = set()
        for s in S:
            v = s + cand
            if v in sumset or v in new_sums:
                ok = False
                break
            new_sums.add(v)
        d = cand + cand
        if d in sumset or d in new_sums:
            ok = False
        if not ok:
            cand += 1
            continue
        for v in new_sums:
            sumset.add(v)
        sumset.add(d)
        S.append(cand)
        cand += 1
    return S


def _milp_breakers(S, n_break, hi):
    """Use MILP to choose breakers b_1..b_k (scaled by a big base M) such that:
       - B is sum-free: no b_i + b_j = b_k (i<=j)
       - B+S adds no new sums to S+S collisions beyond recorded ones
       We formulate a feasibility/optimization over candidate base multipliers.
    Returns a list of breakers or None."""
    if not _HAS_MILP:
        return None
    base = hi  # large scale
    # Candidate breakers are base * t for t in a small set of integers.
    # Constraint B sum-free: for all i,j,k in candidates with i+j=k, x_i+x_j+x_k <= 2.
    cand = list(range(1, 200))
    idx = {t: i for i, t in enumerate(cand)}
    m = len(cand)
    # Objective: prefer candidates that create many new differences and few sums.
    sumset = set()
    for a in S:
        for b in S:
            sumset.add(a + b)
    # Cost of candidate t: fewer new sums is better (maximize new diffs).
    new_sums_per = []
    for t in cand:
        b = base * t
        ns = 0
        for s in S:
            if b + s in sumset:
                ns += 1
        new_sums_per.append(ns)
    # We want to choose k candidates minimizing total extra sums.
    c = np.array(new_sums_per, dtype=float)
    # Sum-free constraints: for triples (i,j,k) with cand[i]+cand[j]==cand[k],
    # x_i + x_j + x_k <= 2.  Build as sparse-ish LinearConstraint.
    rows = []
    for i in range(m):
        for j in range(i, m):
            tsum = cand[i] + cand[j]
            if tsum in idx:
                k = idx[tsum]
                row = np.zeros(m)
                row[i] += 1
                row[j] += 1
                row[k] += 1
                rows.append(row)
    constraints = []
    if rows:
        A = np.vstack(rows)
        constraints.append(LinearConstraint(A, -np.inf, 2))
    # Also require exactly n_break selected.
    Aeq = np.ones((1, m))
    constraints.append(LinearConstraint(Aeq, n_break, n_break))
    integrality = np.ones(m)
    bounds = Bounds(np.zeros(m), np.ones(m))
    try:
        res = milp(c=c, constraints=constraints, integrality=integrality,
                   bounds=bounds, options={"time_limit": 20})
    except Exception:
        return None
    if res is None or not res.success or res.x is None:
        return None
    chosen = [cand[i] for i in range(m) if res.x[i] > 0.5]
    if len(chosen) != n_break:
        return None
    return [base * t for t in chosen]


def _greedy_breakers(S, n_break, base):
    """Greedy fallback: pick sum-free large-scale breakers minimizing extra sums."""
    sumset = {a + b for a in S for b in S}
    breakers = []
    t = 1
    while len(breakers) < n_break and t < 5000:
        b = base * t
        ok = True
        # sum-free relative to existing breakers
        for x in breakers:
            if b - x in breakers or b + x in set(breakers):
                ok = False
                break
        if not ok:
            t += 1
            continue
        # no new self-sums and limited collisions with S+S
        if b + b in sumset:
            t += 1
            continue
        for x in breakers:
            if b + x in sumset:
                ok = False
                break
        if not ok:
            t += 1
            continue
        breakers.append(b)
        t += 1
    return breakers


def _local_polish(A, deadline):
    """Small local search improving score of the assembled set."""
    cur = list(A)
    best = cur[:]
    best_score = _score(best)
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.choice([-2, -1, 1, 2, -5, 5])
        if random.random() < 0.1 and len(cand) < 60:
            cand.append(random.randint(-50, 50))
        if random.random() < 0.05 and len(cand) > 5:
            cand.pop(random.randrange(len(cand)))
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.15:
            cur = best[:]
    return best


def solve():
    deadline_overall = time.time() + 110

    best = None
    best_score = -1.0

    # Try several Sidon base sizes / bounds.
    configs = [
        (28, 1400),
        (32, 2000),
        (36, 2600),
        (40, 3400),
        (24, 1000),
    ]

    for n_sidon, bound in configs:
        if time.time() > deadline_overall:
            break
        S = _greedy_sidon(n_sidon, bound)
        if len(S) < 4:
            continue

        # Normalize Sidon set to be a pure Sidon (all diffs distinct too if possible).
        base_scale = 10 ** 10
        breakers = None
        if _HAS_MILP:
            breakers = _milp_breakers(S, min(10, max(3, len(S) // 4)), base_scale)
        if not breakers:
            breakers = _greedy_breakers(S, min(10, max(3, len(S) // 4)), base_scale)

        A = list(S) + list(breakers)
        A = sorted(set(A))

        polish_deadline = min(deadline_overall, time.time() + 15)
        A2 = _local_polish(A, polish_deadline)
        sc = _score(A2)
        if sc > best_score:
            best_score = sc
            best = A2

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    # Final light polish if time remains.
    if time.time() < deadline_overall:
        best = _local_polish(best, min(deadline_overall, time.time() + 20))

    # Validate bounds.
    best = [int(x) for x in best if abs(int(x)) <= 10 ** 15]
    best = sorted(set(best))[:4000]
    if len(best) < 2:
        best = [0, 1]
    return best
# EVOLVE-BLOCK-END
