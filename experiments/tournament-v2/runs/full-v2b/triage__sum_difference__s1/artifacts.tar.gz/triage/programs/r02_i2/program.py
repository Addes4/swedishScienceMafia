"""Bose–Chowla-based Sidon-like construction, then prune-and-grow local search
with O(|A|) incremental updates of difference and sum sets."""

import math
import random
import time


def _build_bose_chowla(q, prime):
    """Return a Sidon set of size q modulo p = q^2 + q + 1 (if q+1 is prime)."""
    p = q * q + q + 1
    # Generator of the multiplicative group (not always primitive but works for many primes)
    # We find a primitive root g of p (p must be prime).
    # Factor p-1 = q*(q+1)
    factors = [q, q + 1]
    for g in range(2, p):
        ok = True
        for f in factors:
            if pow(g, (p - 1) // f, p) == 1:
                ok = False
                break
        if ok:
            break
    theta = g  # primitive root
    log_theta = {1 % p: 0}
    cur = 1
    for i in range(1, p - 1):
        cur = cur * theta % p
        log_theta[cur] = i
    A = []
    # Take powers alpha^i for i=0..q-1, then map to additive representation using log
    alpha = pow(theta, (p - 1) // q, p)
    cur = 1
    for _ in range(q):
        A.append(log_theta[cur])
        cur = cur * alpha % p
    return A


def _make_base_set(size_target):
    """Produce a base set of distinct integers (Sidon-like) of at least size_target
    using repeated Bose–Chowla blocks modulo different primes, shifted to avoid overlaps."""
    blocks = []
    shift = 0
    q = 2
    total = 0
    # Generate primes (q+1 prime) for Bose-Chowla
    while total < size_target:
        # find next prime such that q+1 and q^2+q+1 are prime (challenging; relax)
        # We use simpler: pick q such that p = q^2 + q + 1 is prime (Singer set)
        # Actually Bose–Chowla requires only p prime, not q+1.
        while True:
            q += 1
            p = q * q + q + 1
            # primality test (simple)
            if all(p % d for d in range(2, int(p ** 0.5) + 1)):
                break
        A = _build_bose_chowla(q, p)
        A = [x + shift for x in A]
        # shift next block far enough to avoid sum collisions (differences unaffected if separated enough)
        # Sums vs differences colliding between blocks can hurt sum set size, so separate by large gap.
        # We choose gap at least 2*max_abs_value of block.
        max_abs = max(abs(x) for x in A)
        blocks.append(A)
        shift += 2 * max_abs + 1 + random.randint(1, 50)  # some randomness
        total += len(A)
    base = []
    for b in blocks:
        base.extend(b)
    return base


class IncrementalScore:
    """Maintain current set, difference set, sum set and compute score incrementally."""

    def __init__(self, initial):
        self.elements = set(initial)
        self.diffs = set()
        self.sums = set()
        self.elem_list = list(self.elements)
        # Build initial sets
        for i, x in enumerate(self.elem_list):
            for y in self.elem_list[i:]:
                self.diffs.add(x - y)
                self.diffs.add(y - x)
                self.sums.add(x + y)

    def add(self, x):
        if x in self.elements:
            return
        # add differences and sums with all existing elements
        for y in self.elements:
            self.diffs.add(x - y)
            self.diffs.add(y - x)
            self.sums.add(x + y)
        self.diffs.add(0)
        self.sums.add(x + x)
        self.elements.add(x)
        self.elem_list.append(x)

    def remove(self, x):
        if x not in self.elements:
            return
        # We cannot easily decrement counts, so we rebuild after removal (cheaper than O(n^2) per removal if n small)
        pass  # We'll handle removals via full rebuild after multiple ops (see below)

    def score(self):
        n = len(self.elements)
        if n < 2:
            return 0.0
        dsize = len(self.diffs)
        ssize = len(self.sums)
        return math.log(dsize) / math.log(ssize) + (1 - 1 / n) / 100

    def copy(self):
        new = IncrementalScore([])
        new.elements = set(self.elements)
        new.diffs = set(self.diffs)
        new.sums = set(self.sums)
        new.elem_list = list(self.elements)
        return new


def _greedy_prune(inc, max_removals=200):
    """Remove elements that improve the score the most, one by one, using incremental
    rebuild after each removal to keep O(n) per step (n = current size)."""
    improved = True
    steps = 0
    while improved and steps < max_removals:
        improved = False
        best_val = inc.score()
        best_to_remove = None
        # Try each element removal
        current_elems = list(inc.elements)
        for x in current_elems:
            # simulate removal
            inc.elements.remove(x)
            # rebuild diffs/sums from scratch (O(n^2) but n is small at this stage, say <= 1000)
            new_diffs = set()
            new_sums = set()
            L = list(inc.elements)
            for i, a in enumerate(L):
                for j in range(i, len(L)):
                    b = L[j]
                    new_sums.add(a + b)
                    new_diffs.add(a - b)
                    new_diffs.add(b - a)
            old_diffs, old_sums = inc.diffs, inc.sums
            inc.diffs = new_diffs
            inc.sums = new_sums
            sc = inc.score()
            if sc > best_val:
                best_val = sc
                best_to_remove = x
            # revert
            inc.elements.add(x)
            inc.diffs = old_diffs
            inc.sums = old_sums
        if best_to_remove is not None:
            # actually remove best_to_remove permanently
            inc.elements.remove(best_to_remove)
            # rebuild sets
            new_diffs = set()
            new_sums = set()
            L = list(inc.elements)
            for i, a in enumerate(L):
                for j in range(i, len(L)):
                    b = L[j]
                    new_sums.add(a + b)
                    new_diffs.add(a - b)
                    new_diffs.add(b - a)
            inc.diffs = new_diffs
            inc.sums = new_sums
            inc.elem_list = L
            improved = True
            steps += 1
    return inc


def _greedy_grow(inc, pool, max_additions=400):
    """Add elements from pool that improve score, O(|A|*|pool|) each step."""
    improved = True
    steps = 0
    # Precompute current score
    while improved and steps < max_additions:
        improved = False
        best_val = inc.score()
        best_candidate = None
        for cand in pool:
            if cand in inc.elements:
                continue
            # simulate add using incremental update O(|A|)
            tmp_diffs = set(inc.diffs)
            tmp_sums = set(inc.sums)
            for y in inc.elements:
                tmp_diffs.add(cand - y)
                tmp_diffs.add(y - cand)
                tmp_sums.add(cand + y)
            tmp_diffs.add(0)
            tmp_sums.add(cand + cand)
            n = len(inc.elements) + 1
            dsize = len(tmp_diffs)
            ssize = len(tmp_sums)
            sc = math.log(dsize) / math.log(ssize) + (1 - 1 / n) / 100
            if sc > best_val:
                best_val = sc
                best_candidate = cand
        if best_candidate is not None:
            inc.add(best_candidate)
            steps += 1
            improved = True
    return inc


def solve():
    """Return list of distinct integers A maximizing log|A-A|/log|A+A|."""
    random.seed(time.time())
    T_start = time.time()
    deadline = T_start + 115  # leave some margin

    # 1. Generate a good base set from Bose-Chowla blocks (Sidon sets)
    base_set = _make_base_set(300)  # aim ~300 elements, will later prune/grow
    A = list(set(base_set))  # ensure distinct
    if len(A) < 2:
        A = [1, 3, 7, 12, 20]

    inc = IncrementalScore(A)

    # 2. Prune phase
    inc = _greedy_prune(inc, max_removals=200)

    # 3. Generate a large pool of candidate integers for addition
    # We'll use shifts of the base set and random combinations to explore
    pool = set()
    # add variations of existing elements and some completely random numbers
    for _ in range(20000):
        if random.random() < 0.7:
            pool.add(random.choice(inc.elem_list) + random.randint(-50, 50))
        else:
            pool.add(random.randint(-10**6, 10**6))
    # remove current elements
    pool = [x for x in pool if x not in inc.elements]

    # 4. Grow phase
    inc = _greedy_grow(inc, pool, max_additions=400)

    # 5. Alternate prune-grow a few more times if time permits
    for _ in range(3):
        if time.time() > deadline - 5:
            break
        inc = _greedy_prune(inc, max_removals=100)
        smaller_pool = list(pool)  # re-use pool but filter out existing
        smaller_pool = [x for x in smaller_pool if x not in inc.elements]
        inc = _greedy_grow(inc, smaller_pool, max_additions=300)

    # 6. Final fine-tuning: random local moves with score acceptance
    cur = inc.elem_list[:]
    best = list(inc.elements)
    best_score = inc.score()
    while time.time() < deadline:
        cand = Inc(incrementalScore)([])  # not needed, we'll just mutate copy
        # Perform one random removal + add from pool
        if len(cur) > 5 and random.random() < 0.4:
            idx = random.randrange(len(cur))
            removed = cur[idx]
            cand_elem = list(cur)
            cand_elem.pop(idx)
            # add a random pool element
            new_elt = random.choice(pool) if pool and random.random() < 0.5 else removed + random.randint(-30, 30)
            if new_elt not in cand_elem:
                cand_elem.append(new_elt)
        else:
            cand_elem = list(cur)
            for i in range(len(cand_elem)):
                if random.random() < 1 / len(cand_elem):
                    cand_elem[i] += random.randint(-5, 5)
        # Evaluate new set with incremental update O(n)
        test_inc = IncrementalScore(cand_elem)
        sc = test_inc.score()
        if sc >= best_score:
            best_score = sc
            best = cand_elem
            cur = cand_elem
            # Update pool with new candidates
            for x in cand_elem:
                pool.append(x + random.randint(-200, 200))
        elif random.random() < 0.1:
            cur = best[:]

    return sorted(set(best))
