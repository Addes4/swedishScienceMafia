# EVOLVE-BLOCK-START
"""Construct A as the image of a Cartesian product B x C under a linear map x -> alpha*x + beta (mod M),
hoping sums stay structured while differences become nearly all distinct.

We use B, C of size ~sqrt(N) each, and search over (alpha, beta, M) to minimize |A+A|.
"""
import math
import random
import time
from itertools import product


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for y in a[i:]:
            diffs.add(x - y)
            if x != y:
                diffs.add(y - x)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def _score_fast(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    sums = set()
    for i in range(n):
        xi = a[i]
        for j in range(i, n):
            sums.add(xi + a[j])
    diffs = set()
    for i in range(n):
        xi = a[i]
        for j in range(n):
            diffs.add(xi - a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(B, C, alpha, beta, M):
    """A = { (alpha*(b + t*len(C) + c) + beta) mod M }, mapping (b,c)->b*|C|+c index."""
    lc = len(C)
    out = []
    for b in B:
        base = b * lc
        for c in C:
            out.append((alpha * (base + c) + beta) % M)
    return out


def solve():
    deadline = time.time() + 110
    rng = random.Random(12345)

    # Base sets B, C chosen to make sums small (arithmetic progressions) but distinct products.
    # Use small geometric-like / AP bases.
    N = 4000
    # choose sizes roughly sqrt
    sb = 63
    sc = 63  # 3969 elements
    # B and C as random-ish sets: try APs with different gaps to make sums structured.
    B = [i * 1 for i in range(sb)]
    C = [i * 1 for i in range(sc)]

    best_A = _build(B, C, 1, 0, 10**9)
    best_score = _score_fast(best_A)

    # Try to optimize alpha, beta over moderate M.
    M = 10**12
    # large coprime alpha for mixing
    trials = 0
    while time.time() < deadline:
        trials += 1
        alpha = rng.randrange(10**6, 10**11)
        if alpha % 2 == 0:
            alpha += 1
        beta = rng.randrange(0, M)
        A = _build(B, C, alpha, beta, M)
        s = _score_fast(A)
        if s > best_score:
            best_score = s
            best_A = A[:]
        # Early stop on time check occasionally
        if trials % 5 == 0 and time.time() >= deadline:
            break

    return sorted(set(best_A))
# EVOLVE-BLOCK-END
