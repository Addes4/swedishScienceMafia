import math
import time
import random
import numpy as np
from scipy.sparse import lil_matrix, csr_matrix
from scipy.sparse.linalg import eigsh

def _score_set(s):
    if len(s) < 2:
        return 0.0
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(s)) / 100

def solve():
    deadline = time.time() + 115
    # 1) Build a large initial pool using quasirandom numbers
    #    We want many differences, few sum collisions.
    #    Use numbers around a geometric progression with carefully chosen ratios.
    pool_size = 400  # Start with reasonable size, then grow/select
    max_val = 10**14
    # generate pool: use pairwise sums of small seeds to get structured set
    small_seeds = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
    # build base set from products
    base = []
    for i in range(1, 6):
        for s in small_seeds:
            base.append(s**i)
    base = sorted(set(base))
    pool = set()
    # create combinations
    for a in base:
        for b in base:
            v = a * b
            if v <= max_val:
                pool.add(v)
    pool = sorted(pool)[:pool_size]
    pool = list(pool)
    
    # 2) Iterative refinement using eigenvector-based pruning
    best_set = sorted(pool)[:200]
    best_score = _score_set(best_set)
    
    iteration = 0
    while time.time() < deadline:
        iteration += 1
        current = list(best_set)
        # Compute sum-collision graph
        # Nodes: elements of current set
        # Edge between i and j if sum with some k equals sum with some l (collision)
        n = len(current)
        if n < 30:
            break
        # Build adjacency for sum collisions (approximate)
        # For efficiency, find all sums and map them to indices
        vals = current
        sum_to_pairs = {}
        for i in range(n):
            vi = vals[i]
            for j in range(i, n):
                s = vi + vals[j]
                if s not in sum_to_pairs:
                    sum_to_pairs[s] = []
                sum_to_pairs[s].append((i, j))
        # Build adjacency: connect all nodes that participate in a shared sum
        adj = lil_matrix((n, n), dtype=np.float32)
        for pairs in sum_to_pairs.values():
            if len(pairs) >= 2:
                # connect all distinct nodes among these pairs
                nodes = set()
                for p in pairs:
                    nodes.add(p[0])
                    nodes.add(p[1])
                nodes = list(nodes)
                for u in nodes:
                    for v in nodes:
                        if u != v:
                            adj[u, v] = 1
        adj = adj.tocsr()
        
        # Compute leading eigenvector of adjacency (measure of sum collision involvement)
        if adj.nnz == 0:
            # no collisions, already optimal? Try to add?
            break
        try:
            # Find largest eigenvector
            eigvals, eigvecs = eigsh(adj, k=1, which='LM', maxiter=200, tol=1e-6)
            vec = eigvecs[:, 0].real
            # ensure positive
            if vec.max() < 0:
                vec = -vec
            weights = np.abs(vec)
        except Exception as e:
            weights = np.ones(n)
        
        # Compute difference contribution: number of unique differences each element participates in
        # Approximate by counting difference pairs
        diff_contrib = np.zeros(n)
        vals_set = set(vals)
        all_diffs = set()
        for i in range(n):
            vi = vals[i]
            for j in range(n):
                if i != j:
                    all_diffs.add(vi - vals[j])
        # Estimate per-element contribution by removing it and counting lost diffs
        # Too expensive, approximate using degree in difference graph
        # Actually compute contribution as number of differences that would disappear if element removed
        # Better: use heuristic: element's degree in difference-sum duality
        # We'll approximate by counting how many times it appears in difference pairs.
        # Timed loop, so ok to approximate here.
        # For speed, assign diff_contrib based on difference coverage sampling
        # Random sampling of pairs
        sample_size = min(n*5, n*n)
        indices = np.random.choice(n, size=(sample_size,2))
        unique_diffs = set()
        for idx in indices:
            unique_diffs.add(vals[idx[0]] - vals[idx[1]])
        for i in range(n):
            vi = vals[i]
            cnt = 0
            for d in unique_diffs:
                # if removing i loses this diff? check if only i produces it
                # simpler: contribution proportional to number of pairs with i
                # we'll just count number of pairs where i appears
                pass
        # Fast approximation: diff_contrib = number of times element participates in sampled differences
        diff_count = np.zeros(n)
        for idx in indices:
            i, j = idx
            diff_count[i] += 1
            diff_count[j] += 1
        diff_contrib = diff_count
        
        # Ratio: weight / (diff_contrib + 1e-9)
        ratio = weights / (diff_contrib + 1e-9)
        # Remove elements with highest ratio (big collision involvement, low diff contribution)
        # Sort indices by ratio descending
        order = np.argsort(-ratio)
        to_remove = []
        # Try removing up to 10% of elements
        remove_count = max(1, int(n * 0.05))
        for idx in order[:remove_count]:
            to_remove.append(idx)
        new_vals = [vals[i] for i in range(n) if i not in to_remove]
        
        # Optionally, add some new elements from pool not in current set, prioritizing large diffs
        # For now, just prune.
        cand_set = new_vals
        if len(cand_set) < 50:
            # add back some pool elements
            pool_set = set(pool)
            existing = set(cand_set)
            candidates = list(pool_set - existing)
            random.shuffle(candidates)
            add_count = min(20, len(candidates))
            cand_set.extend(candidates[:add_count])
        
        if len(cand_set) >= 2:
            s = _score_set(cand_set)
            if s > best_score:
                best_score = s
                best_set = sorted(cand_set)
            elif random.random() < 0.1:
                # accept anyway to avoid stuck
                best_set = sorted(cand_set)
        # Periodically, reinitialize from pool if too small
        if len(best_set) < 100:
            best_set = sorted(pool)[:200]
            best_score = _score_set(best_set)
    
    # Final polish: local search on best set
    cur = best_set[:]
    cur_score = _score_set(cur)
    polish_time = min(30, deadline - time.time())
    end_polish = time.time() + polish_time
    while time.time() < end_polish:
        cand = cur[:]
        if len(cand) > 10 and random.random() < 0.1:
            idx = random.randrange(len(cand))
            del cand[idx]
        else:
            idx = random.randrange(len(cand))
            cand[idx] += random.randint(-2, 2)
        if random.random() < 0.1 and len(cand) < 300:
            cand.append(random.choice(pool))
        s = _score_set(cand)
        if s > cur_score:
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best_set = cand[:]
    return sorted(set(best_set))
