import math
import random
import time


def _fast_stats(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, 0.0
    # differences
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
        for j in range(i + 1, n):
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


def _score_from(d, s, n):
    if s <= 1 or n < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _full_score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for i in range(n):
        for j in range(i, n):
            sums.add(a[i] + a[j])
    return _score_from(len(diffs), len(sums), n), len(diffs), len(sums)


def _greedy_build(target_n, rng):
    """Randomized greedy: build set keeping differences mostly distinct and
    trying to keep sumset small by staying near a progression-ish structure."""
    A = [0]
    used_d = {0}
    for _ in range(target_n - 1):
        best_c = None
        best_val = None
        # try several candidates, pick the one with fewest new sum collisions
        for _ in range(40):
            base = rng.choice(A)
            step = rng.choice([1, 1, 2, 2, 3, 5, 8, 13, -1, -2, -3, 4, 7])
            c = base + step
            # estimate new sums
            new_sums = set()
            for x in A:
                new_sums.add(x + c)
            new_sums.add(2 * c)
            # score: prefer small number of NEW sums, many new diffs
            old_sums = set()
            for i in range(len(A)):
                for j in range(i, len(A)):
                    old_sums.add(A[i] + A[j])
            added_s = len(new_sums - old_sums)
            new_d = set()
            for x in A:
                new_d.add(x - c)
                new_d.add(c - x)
            added_d = len(new_d - used_d)
            val = added_d - 3.0 * added_s
            if best_val is None or val > best_val:
                best_val = val
                best_c = c
        A.append(best_c)
        for x in A[:-1]:
            used_d.add(x - best_c)
            used_d.add(best_c - x)
        used_d.add(0)
    return A


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # candidate sizes
    sizes = [50, 80, 100, 120, 150, 200, 256, 300]

    # seed best with simple known good structure
    seed = [i * i for i in range(30)]
    sc, _, _ = _full_score(seed)
    best, best_score = seed, sc

    while time.time() < deadline:
        n = rng.choice(sizes)
        A = _greedy_build(n, rng)
        sc, d, s = _full_score(A)
        if sc > best_score:
            best, best_score = A[:], sc

        # local search
        cur = A[:]
        cur_score = sc
        for _ in range(3000):
            if time.time() > deadline:
                break
            cand = cur[:]
            op = rng.random()
            if op < 0.7 and len(cand) > 2:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-2, -1, 1, 2, 3, -3, 5])
            elif op < 0.85 and len(cand) < 400:
                cand.append(cand[rng.randrange(len(cand))] + rng.choice([1, 2, 3, -1, -2]))
            elif len(cand) > 3:
                del cand[rng.randrange(len(cand))]
            cand = list(set(cand))
            if len(cand) < 2:
                continue
            cs, _, _ = _full_score(cand)
            if cs >= cur_score:
                cur, cur_score = cand, cs
                if cs > best_score:
                    best, best_score = cand[:], cs

    return sorted(set(best))
