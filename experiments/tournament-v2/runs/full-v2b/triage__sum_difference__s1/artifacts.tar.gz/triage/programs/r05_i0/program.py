import math
import random
import time
import numpy as np

def _score(a):
    """Calculate the score for set A."""
    a = set(a)
    if len(a) < 2:
        return 0.0
    
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    
    if len(sums) < 2:
        return 0.0
    
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def compute_collision_penalty(a):
    """Compute heuristic score for how many sum collisions (for refinement)."""
    a = sorted(a)
    n = len(a)
    collision_count = 0
    for i in range(n):
        for j in range(i + 1, n):
            for k in range(j + 1, min(n, j + 20)):
                if a[i] + a[j] == a[k] + a[0]:
                    collision_count += 1
    return collision_count

def solve():
    """Return a list of distinct integers maximizing log|A-A|/log|A+A|."""
    random.seed(42)
    deadline = time.time() + 120
    best_A = []
    best_score = 0.0
    
    # Initial set: multiple arithmetic progressions with different prime steps
    P = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73]
    offsets = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]
    
    A = []
    for i, p in enumerate(P):
        for j in range(150):
            val = p * (offsets[i % len(offsets)] + j)
            A.append(val)
    
    A = list(set(A))
    A.sort()
    
    cur = A[:]
    best_A = cur[:]
    best_score = _score(best_A)
    
    # Iterative improvement
    max_iterations = 80
    for iteration in range(max_iterations):
        improved = False
        
        # Try removing one element
        for i in range(len(cur)):
            test_A = cur[:i] + cur[i+1:]
            score = _score(test_A)
            if score > best_score:
                best_A = test_A[:]
                best_score = score
                cur = test_A
                improved = True
        if improved:
            continue
        
        # Try adding one new element
        for base in [10000, 20000, 50000, 100000]:
            for scale in [2, 3, 5, 7, 11]:
                candidate = base * (1000 + scale * 100 * (iteration + 1))
                test_A = set(cur)
                test_A.add(candidate)
                score = _score(list(test_A))
                if score > best_score:
                    best_A = list(test_A)
                    cur = best_A[:]
                    best_score = score
                    improved = True
        if improved:
            continue
        
        # Try compressing pairs (iterative compression step)
        n = len(cur)
        coll_pairs = [(cur[i], cur[j]) for i in range(n) for j in range(i + 1, min(n, i + 10))]
        coll_pairs.sort(key=lambda x: compute_collision_penalty(set([x[0], x[1]])), reverse=True)
        
        for i, j in coll_pairs[:3]:
            if len(cur) < 500:
                # Replace one of the pair with a new scaled value
                base = 1000000
                new_val = base + base * (i * j)
                test_A = list(set(cur))
                test_A[i] = test_A[i] if i != len(test_A)//2 else new_val
                test_A = list(set(test_A))
            else:
                # Merge elements near same collision cluster
                continue
                test_A = list(nearly d=10))
                if score > best_score:
                    best_A = test_A[:]
                    cur = best_A[:]
                    best_score = score
                    improved = True
        if improved:
            continue
        
        if not improved:
            break
    
    return sorted(set(best_A)[:4000])

if __name__ == "__main__":
    result = solve()
