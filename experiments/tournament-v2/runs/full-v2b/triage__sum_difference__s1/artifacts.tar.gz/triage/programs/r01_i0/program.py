import math
import random
import time

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    """
    Use a geometric progression combined with a small additive set to get many differences
    while keeping sums relatively constrained.
    """
    best = None
    best_score = 0.0
    deadline = time.time() + 110  # leave some margin

    # Parameters to explore
    base_candidates = [2, 3, 4, 5]
    small_set_options = [
        [-1, 0, 1],
        [-2, -1, 0, 1, 2],
        [-1, 0, 1, 2],
        [-2, -1, 0],
        [-3, -2, -1, 0, 1, 2, 3],
        [0, 1, 2, 3, 4],
        [-2, -1, 0, 1],
        [-3, -1, 0, 1, 3],
        [-5, -2, 0, 2, 5],
    ]
    # Length of geometric progression (number of distinct powers)
    max_len = 4000 // 7  # rough upper bound to avoid exceeding 4000
    
    while time.time() < deadline:
        base = random.choice(base_candidates)
        small = random.choice(small_set_options)
        # choose length to keep total elements <= 4000
        max_k = min(max_len, 4000 // len(small))
        if max_k < 3:
            max_k = 3
        k = random.randint(5, max_k)
        # generate A = { c * base**i : c in small, i in 0..k-1 }
        A = []
        pow_val = 1
        for i in range(k):
            for c in small:
                A.append(c * pow_val)
            pow_val *= base
            # avoid integer overflow / too large numbers
            if abs(pow_val) > 1e15:
                break
        
        if len(A) > 4000:
            # trim randomly
            A = random.sample(A, 4000)
        
        # quick mutate local search on this set
        A = list(set(A))
        if len(A) < 3:
            continue
        
        # try some local changes to improve
        for _ in range(5):
            mut = A[:]
            # small perturbation
            for _ in range(random.randint(1, 10)):
                idx = random.randrange(len(mut))
                mut[idx] += random.choice([-1, 1]) * random.randint(1, max(1, abs(mut[idx])//100 + 1))
            # occasionally drop an element
            if len(mut) > 10 and random.random() < 0.3:
                mut.pop(random.randrange(len(mut)))
            # occasionally add a near element
            if len(mut) < 4000 and random.random() < 0.3:
                mut.append(mut[random.randrange(len(mut))] + random.choice([-1, 1]))
            mut = list(set(mut))
            if len(mut) > 4000:
                mut = mut[:4000]
            if len(mut) >= 3:
                s = _score(mut)
                if s > best_score:
                    best = mut[:]
                    best_score = s

        s = _score(A)
        if s > best_score:
            best = A[:]
            best_score = s

    # If nothing found, return a simple fallback
    if best is None:
        best = [3**i for i in range(8)] + [-3**i for i in range(8)]
    
    # final local refinement on best
    refine_deadline = time.time() + 5
    cur = best[:]
    cur_score = best_score
    while time.time() < refine_deadline:
        cand = cur[:]
        if len(cand) > 3 and random.random() < 0.5:
            # modify one element slightly
            idx = random.randrange(len(cand))
            cand[idx] += random.choice([-1, 1]) * random.randint(1, max(1, abs(cand[idx])//50 + 1))
        if random.random() < 0.2 and len(cand) < 4000:
            cand.append(cand[random.randrange(len(cand))] + random.choice([-1, 1]))
        if random.random() < 0.1 and len(cand) > 5:
            cand.pop(random.randrange(len(cand)))
        cand = list(set(cand))
        if len(cand) > 4000:
            continue
        s = _score(cand)
        if s > cur_score:
            cur = cand[:]
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
        elif random.random() < 0.2:
            # explore somewhere else
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))[:4000]
