# EVOLVE-BLOCK-START
"""Simulated annealing with a slowly decaying temperature and a richer neighbourhood.

Idea: maximise  log|A-A| / log|A+A| (+ tiny size bonus).  We run a simulated
annealing search whose temperature decays very slowly and which accepts
temporary score drops to escape local optima.  The neighbourhood includes
single/multiple element perturbations, additions, removals, and scaling of
subset ranges (mirroring the set around / dilating a region), which is a
classic trick for keeping the difference set large while restricting sums.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _neighbor(a, rng):
    """Return a mutated copy of list a using a rich neighbourhood."""
    cand = a[:]
    op = rng.random()
    if not cand:
        return [rng.randint(1, 50)]
    if op < 0.30:
        # perturb several elements by small amounts
        k = rng.randint(1, max(1, len(cand) // 4))
        for _ in range(k):
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-4, 4)
    elif op < 0.50:
        # add a few new elements
        k = rng.randint(1, 3)
        for _ in range(k):
            anchor = rng.choice(cand)
            cand.append(anchor + rng.randint(-20, 20))
    elif op < 0.65 and len(cand) > 4:
        # remove a few elements (prefer extremes)
        k = rng.randint(1, max(1, len(cand) // 5))
        for _ in range(k):
            if len(cand) <= 4:
                break
            cand.pop(rng.randrange(len(cand)))
    elif op < 0.80 and len(cand) > 3:
        # scale a contiguous-ish subset around its centre
        lo = rng.randrange(len(cand))
        hi = min(len(cand), lo + rng.randint(2, 6))
        block = cand[lo:hi]
        c = sum(block) / len(block)
        s = rng.choice([1, 2, 3, 4, -1, -2, 0])
        if s == 0:
            block = [int(c + (x - c) * (1 / max(1e-9, rng.uniform(0.3, 3.0))))
                     for x in block]
        else:
            block = [int(round(c + (x - c) * s)) for x in block]
        cand[lo:hi] = block
    elif op < 0.92:
        # reflect a subset: A -> 2c - x keeps differences, shifts sums
        c = rng.choice(cand)
        idxs = rng.sample(range(len(cand)), k=rng.randint(1, max(1, len(cand) // 3)))
        for i in idxs:
            cand[i] = 2 * c - cand[i]
    else:
        # large random jump
        cand = [rng.randint(-60, 60) for _ in range(rng.randint(4, 12))]
    # dedupe, clamp size and magnitude
    cand = list(dict.fromkeys(cand))
    if len(cand) > 4000:
        rng.shuffle(cand)
        cand = cand[:4000]
    cand = [max(-10**15, min(10**15, x)) for x in cand]
    return cand


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    rng = random.Random(12345)

    # Seed candidates: a Sidon-like / sparse set plus the known-good baseline.
    seeds = [
        [7, 15, 18, 22, -3, -2],
        [1, 2, 4, 8, 16, 32, 64, 128],
        [0, 1, 3, 7, 12, 20, 30, 44, 65, 80],
        [1, 3, 7, 15, 31, 63, 127, 255],
    ]

    best = None
    best_score = -1.0

    t0 = time.time()
    deadline = t0 + 100.0  # keep some margin under the 120s limit

    # Phase 1: quickly evaluate seeds to pick a starting point.
    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score = sc
            best = s[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    cur = best[:]
    cur_score = best_score

    # Simulated annealing with very slow cooling (geometric, T0 large-ish).
    T0 = 1.0
    T_min = 1e-4
    it = 0
    # Estimate iterations for slow decay: many iterations, tune alpha lazily.
    while True:
        now = time.time()
        if now >= deadline:
            break
        # Slowly decaying temperature: exponential in iteration count, floor at T_min.
        # We'll compute temperature directly from elapsed progress for slow decay.
        progress = (now - t0) / (deadline - t0)
        # Temperature decays as (1-progress)^2 from T0 to near T_min (very slow early).
        T = T_min + (T0 - T_min) * (1.0 - progress) ** 2

        cand = _neighbor(cur, rng)
        cscore = _score(cand)
        delta = cscore - cur_score
        if delta >= 0 or rng.random() < math.exp(delta / max(T, 1e-9)):
            cur = cand
            cur_score = cscore
            if cscore > best_score:
                best = cand[:]
                best_score = cscore
        it += 1

        # Occasional restarts from a fresh random set if stuck.
        if it % 4000 == 0 and rng.random() < 0.25:
            cur = _neighbor(best, rng)
            cur_score = _score(cur)

    # Final polish: greedy hill-climb from the best solution.
    while time.time() < deadline + 15.0:
        cand = _neighbor(best, rng)
        cs = _score(cand)
        if cs > best_score:
            best = cand
            best_score = cs
        if time.time() >= deadline + 15.0:
            break

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
