import math
import random
import time

def compute_score(A):
    """Compute the score for a set A."""
    A = set(A)
    if len(A) < 2:
        return 0.0
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    if len(diffs) < 1 or len(sums) < 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(A)) / 100

def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    random.seed(42)
    
    # Geometric progression parameters (bases 2 and 3 are multiplicatively independent)
    b1, b2 = 2, 3
    max_exp = 20  # exponents for each base; b^exp stays within 1e15
    
    # Generate candidates from both progressions
    candidates = set()
    for e in range(max_exp + 1):
        candidates.add(b1 ** e)
        candidates.add(b2 ** e)
    # Add some negative counterparts for more structure
    candidates = list(candidates)
    
    # Do a controlled "block" approach with greedy filtering
    best_score = -1.0
    best_A = []
    deadline = time.time() + 120
    
    base_set = list(candidates)
    base_set.sort()
    
    # Greedily remove elements that least improve the score
    # We want to minimize the impact on the score ratio
    for i in range(50):
        cur_A = base_set[:]
        best_red = cur_A
        
        if len(cur_A) >= 4:
            diffs = set(x - y for x in cur_A for y in cur_A)
            sums = set(x + y for x in cur_A for y in cur_A)
            diffs_vals = [len(diffs) for _ in range(1)]
            sums_vals = [len(sums) for _ in range(1)]
            base_score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(cur_A)) / 100 if len(diffs) > 1 and len(sums) > 1 else 0
            
            if i == 0:
                best_red = cur_A[:]
                best_A = best_red
                best_score = base_score
                continue

            # Removal candidates: pick element minimizing increase in sum-set cost vs loss in difference-set benefit
            idx_to_remove = -1
            best_gain = float('inf')
            current_diffs = {x - y for x in cur_A for y in cur_A}
            current_sums = {x + y for x in cur_A for y in cur_A}
            diff_size = len(current_diffs)
            sum_size = len(current_sums)

            # We want to remove elements that cause minimal loss in difference size while keeping sum set small
            for idx in range(len(cur_A)):
                candidate = cur_A[:]
                candidate.remove(cur_A[idx])
                if len(candidate) < 1:
                    continue
                new_diffs = {x - y for x in candidate for y in candidate}
                new_sums = {x + y for x in candidate for y in candidate}
                ndiff = len(new_diffs)
                nsum = len(new_sums)

                new_score = math.log(ndiff) / math.log(nsum) + (1 - 1 / len(candidate)) / 100 if ndiff > 1 and nsum > 1 else 0

                    # Check can remove element if improvement or acceptable degradation < 10%
                if new_score >= base_score * 0.95:
                    if idx_to_remove == -1 or best_gain < current_score:
                        best_gain = new_score - base_score
                        idx_to_remove = idx
                        best_candidate = cur_A[:]
                        best_candidate.pop(idx)

            if idx_to_remove == -1:
                break
            cur_A = best_candidate[:]

        # Periodically check if we've reached a worthy set
        if compute_score(cur_A) > best_score:
            best_A = cur_A[:]
            best_score = compute_score(cur_A)

        if best_score > 1.15:
            break
    
    # Take best set found
    if best_score > 0.7:
        final_A = sorted(best_A)
    else:
        final_A = sorted(base_set)
    
    return final_A
