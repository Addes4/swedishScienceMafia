import math
import random
import time

def _score(a):
    a_set = set(a)
    if len(a_set) < 2:
        return 0.0
    diffs = {x - y for x in a_set for y in a_set}
    sums = {x + y for x in a_set for y in a_set}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a_set)) / 100

def solve():
    best = None
    best_score = -1.0
    
    start_time = time.time()
    deadline = start_time + 115
    
    # Try multiple parameter configurations
    for prime in [101, 127, 131, 137, 149, 151, 179, 181, 191, 197, 199, 211, 223, 227, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641, 643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809, 811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977, 983, 991, 997, 1009, 1013, 1019, 1021, 1031, 1033, 1039, 1049, 1051, 1061, 1063, 1069, 1087, 1091, 1093, 1097, 1103, 1109, 1117, 1123, 1129, 1151, 1153, 1163, 1171, 1181, 1187, 1193, 1201, 1213, 1217, 1223, 1229, 1231, 1237, 1249, 1259, 1277, 1279, 1283, 1289, 1291, 1297, 1301, 1303, 1307, 1319, 1321, 1327, 1361, 1367, 1373, 1381, 1399, 1409, 1423, 1427, 1429, 1433, 1439, 1447, 1451, 1453, 1459, 1471, 1481, 1483, 1487, 1489, 1493, 1499, 1511, 1523, 1531, 1543, 1549, 1553, 1559, 1567, 1571, 1579, 1583, 1597, 1601, 1607, 1609, 1613, 1619, 1621, 1627, 1637, 1657, 1663, 1667, 1669, 1693, 1697, 1699, 1709, 1721, 1723, 1733, 1741, 1747, 1753, 1759, 1777, 1783, 1787, 1789, 1801, 1811, 1823, 1831, 1847, 1861, 1867, 1871, 1873, 1877, 1879, 1889, 1901, 1907, 1913, 1931, 1933, 1949, 1951, 1973, 1979, 1987, 1993, 1997, 1999]:
        target_size = min(4000, prime - 1)
        
        # Generate points evenly spaced in GF(p)
        base_p = prime
        step = (prime - 1) // (target_size + 1) if target_size + 1 < prime else 1
        
        # Try different polynomial degrees and coefficients for hill-climbing
        for degree in [2, 3, 4]:
            for base_coeff in range(2, 10):
                for offset in range(3, 5):
                    candidate = []
                    elem_list = []
                    
                    if target_size + 1 <= base_p:
                        # Take elements evenly distributed in [1, p-2]
                        for i in range(target_size):
                            x = base_coeff * (i * step + 1) + offset
                            if x < base_p - 1:
                                candidate.append(x)
                                vals = []
                            else:
                                break
                    
                    if len(candidate) < target_size:
                        # Fill remaining space linearly
                        for i in range(len(candidate), target_size):
                            prev = candidate[i - 1] if i > 0 else 1
                            candidate.append(prev + offset)
                    
                    candidate = list(set(candidate))[:target_size]
                    candidate.sort()
                    candidate = [x for x in candidate if abs(x) <= 1e15]
                    
                    if len(candidate) < 3:
                        continue
                    
                    s = _score(candidate)
                    if s > best_score:
                        best_score = s
                        best = candidate
                    
                        if best is not None and s > 1.25:
                            if time.time() - start_time > 55:
                                break
                            if best_score > s:
                                best, best_score = candidate, s
                            if time.time() - start_time > 105:
                                break
            
            if best is not None and len(best) > 100:
                if time.time() - start_time > 100:
                    break
        
        if best is not None and s > 1.25:
            if time.time() - start_time > 80:
                break
        
        if time.time() - start_time > 105:
            break
        if s > 1.25:
            if time.time() - start_time > 95:
                break
    
    # Check standard arithmetic progression
    n = 2000
    for start in range(1, 100):
        for gap in range(2, 200):
            if gap == 1:
                continue
            A = [start + gap * i for i in range(n)]
            if all(abs(x) <= 1e15 for x in A):
                s = _score(A)
                if s > best_score:
                    best, best_score = A[:], s
    
    if best is None:
        return best
    return best[:best_score]

if __name__ == "__main__":
    import sys
    print(_score(solve()))
