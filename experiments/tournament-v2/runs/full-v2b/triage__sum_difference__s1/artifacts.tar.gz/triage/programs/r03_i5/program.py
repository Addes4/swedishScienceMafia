import math
import random
import time
import numpy as np
from scipy.optimize import minimize, Bounds
from scipy.special import logsumexp

# Try to use a jitted kernel smoother if numba is available (standard library only, so fall back)
try:
    from numba import njit
    _HAS_NUMBA = True
except ImportError:
    _HAS_NUMBA = False

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def _soft_count(values, sigma):
    """Differentiable estimate of number of distinct values using Gaussian kernel density.
    
    Given a set of values, we approximate the probability density function as a mixture of
    Gaussians centered at each value with width sigma. The 'effective number of distinct values'
    is 1 / sum_{i,j} w_i w_j K(v_i, v_j) where K is a normalized Gaussian.
    For large sigma this tends to 1; for sigma->0 it tends to the number of distinct values.
    """
    # values: numpy array of floats (pairwise differences or sums)
    # We compute pairwise squared distances efficiently.
    diff = values[:, None] - values[None, :]  # shape (n, n)
    # normalized Gaussian kernel with sum-to-one property: exp(-d^2/(2 sigma^2))
    kernel = np.exp(-0.5 * (diff / sigma) ** 2)
    # effective count: 1 / (mean of kernel over all pairs)
    # This is the inverse participation ratio
    avg_kernel = np.mean(kernel)
    if avg_kernel < 1e-12:
        return len(values)  # degenerate
    return 1.0 / max(avg_kernel, 1e-12)

def _continuous_score(x, sigma_diff=1.0, sigma_sum=1.0):
    """Compute log|A-A| / log|A+A| using soft counts for a real-valued set x."""
    n = len(x)
    if n < 2:
        return np.array(0.0)
    # All pairwise differences
    pair_diff = x[:, None] - x[None, :]
    pair_diff = pair_diff.flatten()
    # All pairwise sums
    pair_sum = x[:, None] + x[None, :]
    pair_sum = pair_sum.flatten()
    
    diff_count = _soft_count(pair_diff, sigma_diff)
    sum_count = _soft_count(pair_sum, sigma_sum)
    
    # Add small epsilon to avoid log(0 or negative)
    diff_count = max(diff_count, 1.0)
    sum_count = max(sum_count, 1.0)
    
    return np.log(diff_count) / np.log(sum_count)

def _objective_and_grad(x, sigma_diff=2.0, sigma_sum=3.0):
    """Returns negative score (for minimization) and gradient using automatic differentiation
    or finite differences. For performance we use finite differences.
    """
    # finite-difference gradient
    eps = 1e-8
    n = len(x)
    f0 = _continuous_score(x, sigma_diff, sigma_sum)
    grad = np.zeros(n)
    for i in range(n):
        x_pert = x.copy()
        x_pert[i] += eps
        fp = _continuous_score(x_pert, sigma_diff, sigma_sum)
        grad[i] = (fp - f0) / eps
    return -f0, -grad

def _polish_discrete(x, steps=2000):
    """Given a real-valued array, round to distinct integers and then perform local random search
    to improve discrete score."""
    # First round to nearby integers, enforce distinctness
    rounded = np.round(x).astype(int)
    # make distinct
    seen = set()
    A = []
    for val in rounded:
        while val in seen:
            val += 1
        seen.add(val)
        A.append(val)
    A.sort()
    
    # simple local search to improve discrete score
    best_A = A[:]
    best_score = _score(best_A)
    cur = best_A[:]
    for _ in range(steps):
        cand = cur[:]
        i = random.randrange(len(cand))
        old_val = cand[i]
        # try small modifications
        cand[i] += random.choice([-2, -1, 1, 2])
        # ensure distinctness by adjusting if collision
        if cand.count(cand[i]) > 1:
            # simple fix: shift all later duplicates up
            vals = sorted(cand)
            new_vals = []
            last = -10**18
            for v in vals:
                if v <= last:
                    v = last + 1
                new_vals.append(v)
                last = v
            cand = new_vals
        s = _score(cand)
        if s > best_score:
            best_A = cand[:]
            best_score = s
            cur = cand[:]
        elif random.random() < 0.2:
            cur = best_A[:]
    return best_A

def solve():
    """Generate A using continuous relaxation + gradient-based optimization + polishing."""
    # Parameters
    target_size = 80  # start with moderate size; we can expand later
    # Initialization: a random set with some structure (e.g., geometric progression)
    # We'll try a few seeds and take the best.
    
    np.random.seed(42)
    random.seed(42)
    deadline = time.time() + 115  # total budget 120s, leave 5s margin
    
    best_overall = None
    best_overall_score = -1
    
    sigma_diff = 1.5
    sigma_sum = 2.5
    
    # The optimization landscape is highly non-convex; run multiple restarts
    for trial in range(100):
        if time.time() > deadline:
            break
        
        n = target_size
        # Initialize with a set that already has some structure: e.g., perturbed geometric progression
        # which is known to have many differences for few sums.
        base = np.geomspace(1, 1000, n) * (random.random() * 10 + 1)
        x0 = base + np.random.normal(0, base * 0.05, n)
        x0.sort()
        
        # Run L-BFGS-B (gradient-based) to optimize continuous score
        bounds = Bounds([-1e15]*n, [1e15]*n)
        try:
            res = minimize(
                fun=lambda x: _objective_and_grad(x, sigma_diff, sigma_sum),
                x0=x0,
                jac=True,
                method='L-BFGS-B',
                bounds=bounds,
                options={'maxiter': 50, 'ftol': 1e-12, 'gtol': 1e-12, 'disp': False, 'maxls': 20}
            )
            x_opt = res.x
        except Exception:
            x_opt = x0
        
        # Apply discrete polishing
        A = _polish_discrete(np.sort(x_opt), steps=5000)
        sc = _score(A)
        if sc > best_overall_score:
            best_overall_score = sc
            best_overall = A[:]
            # maybe increase size if we are doing well
            if len(best_overall) < 4000 and sc > 0.9:
                target_size = min(4000, len(best_overall) + 20)
        
        # occasionally restart with random
        if trial % 10 == 0:
            target_size = random.randint(30, min(4000, 120))
    
    # Final intensive polish on the best found set
    if best_overall is not None:
        best_overall = _polish_discrete(np.array(best_overall, dtype=float), steps=20000)
    
    # Ensure size <= 4000 and integers within bounds
    A = sorted(set(best_overall[:4000]))
    return A

if __name__ == "__main__":
    A = solve()
    print(f"Score: {_score(A)}")
    print(f"Size: {len(A)}")
