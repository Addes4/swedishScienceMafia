import math
import random
import time


def _sets(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return diffs, sums


def _score_counts(nd, ns, n):
    if ns < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    diffs, sums = _sets(a)
    return _score_counts(len(diffs), len(sums), len(a))


def _incremental_contrib(a, S):
    """For element x not in set S, compute (delta_nd, delta_ns) if added to S."""
    diffs = set()
    sums = set()
    for u in S:
        for v in S:
            diffs.add(u - v)
            sums.add(u + v)
    base_d = len(diffs)
    base_s = len(sums)
    nd_new = set(diffs)
    ns_new = set(sums)
    for u in S:
        nd_new.add(u - x)
        nd_new.add(x - u)
        ns_new.add(u + x)
        ns_new.add(x + u)
    nd_new.add(0)
    ns_new.add(2 * x)
    return len(nd_new) - base_d, len(ns_new) - base_s


def solve():
    deadline = time.time() + 110

    best_overall = None
    best_overall_score = -1.0

    # Several seeds / strategies
    seeds = []
    seeds.append([7, 15, 18, 22, -3, -2])
    # geometric-ish seed
    seeds.append([1, 2, 4, 8, 16, 32, 64])
    seeds.append([1, 3, 9, 27, 81, 243])
    seeds.append([0, 1, 3, 7, 12, 20, 30, 40])

    pool_max = 1200

    while time.time() < deadline:
        S = list(seeds[random.randrange(len(seeds))])
        S = list(set(S))
        random.shuffle(S)

        # Maintain score
        cur_diffs, cur_sums = _sets(S)
        cur_score = _score_counts(len(cur_diffs), len(cur_sums), len(S))

        improved = True
        rounds = 0
        while improved and time.time() < deadline:
            improved = False
            rounds += 1

            # Pass 1: try removals (elements that hurt ratio)
            if len(S) > 3:
                order = list(range(len(S)))
                random.shuffle(order)
                for idx in order:
                    if time.time() > deadline:
                        break
                    if idx >= len(S):
                        continue
                    x = S[idx]
                    T = S[:idx] + S[idx + 1:]
                    d2, s2 = _sets(T)
                    sc = _score_counts(len(d2), len(s2), len(T))
                    if sc > cur_score + 1e-12:
                        S = T
                        cur_diffs, cur_sums = d2, s2
                        cur_score = sc
                        improved = True
                        break

            # Pass 2: try additions from a candidate pool
            if time.time() > deadline:
                break
            # candidate pool: random values plus perturbations
            candidates = set()
            span = 1
            for x in S:
                span = max(span, abs(x))
            span = min(span * 4 + 50, 10 ** 12)
            for _ in range(40):
                candidates.add(random.randint(-span, span))
            for x in S:
                candidates.add(x + random.randint(-3, 3))
                candidates.add(-x)
            for _ in range(10):
                candidates.add(random.randint(-span // 2, span // 2))
            candidates -= set(S)

            base_d = len(cur_diffs)
            base_s = len(cur_sums)
            best_gain = None
            best_x = None
            best_ns_len = 0
            best_nd_len = 0
            n_cur = len(S)

            for x in candidates:
                if time.time() > deadline:
                    break
                nd_new = set(cur_diffs)
                ns_new = set(cur_sums)
                for u in S:
                    nd_new.add(u - x)
                    nd_new.add(x - u)
                    ns_new.add(u + x)
                    ns_new.add(x - u * 0)  # no-op safe
                    ns_new.add(x + u)
                nd_new.add(0)
                ns_new.add(2 * x)
                nd = len(nd_new)
                ns = len(ns_new)
                sc = _score_counts(nd, ns, n_cur + 1)
                if sc > cur_score + 1e-12:
                    if best_gain is None or sc > best_gain:
                        best_gain = sc
                        best_x = x
                        best_nd_len = nd
                        best_ns_len = ns

            if best_x is not None and len(S) < 4000:
                S.append(best_x)
                cur_diffs, cur_sums = _sets(S)
                cur_score = _score_counts(len(cur_diffs), len(cur_sums), len(S))
                improved = True

        if cur_score > best_overall_score:
            best_overall_score = cur_score
            best_overall = S[:]

    if best_overall is None:
        best_overall = [7, 15, 18, 22, -3, -2]
    return sorted(set(best_overall))
