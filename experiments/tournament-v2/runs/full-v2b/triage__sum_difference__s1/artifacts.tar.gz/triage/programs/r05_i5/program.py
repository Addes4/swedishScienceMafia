import math
import random
import time
from scipy.linalg import sqrtm

def score_set(A):
    if len(A) < 8:
        return -100.0
    A = set(A)
    sums = set()
    diffs = set()
    for x in A:
        for y in A:
            sums.add(x + y)
            diffs.add(x - y)
    ns, nd = len(sums), len(diffs)
    if ns < 5 or nd < 5:
        return -100.0
    score = math.log(nd) / math.log(ns) + (1 - 1/len(A)) / 100
    return score

def make_exp_set(k, M=1000000):
    S = set()
    p = 1
    for i in range(k):
        base = 3**((i+1)//2) + random.randint(0, M//10000)
        val = base + random.randint(-5, 5)
        if val % 7 in [1,3]:
            S.add(val)
    return sorted(S)

def make_quad_set(k=4000):
    S = set()
    for i in range(k//2):
        a = 2**i + random.randint(0, 100) if i > 0 else i
        S.add(a)
    return sorted(list(S))[:k]

def make_structured(k, base=25, gap=50):
    S = set()
    for i in range(k):
        val = base + gap*i + random.randint(0, gap//2)
        if val % 11 != 0:
            S.add(val)
    return sorted(list(S))[:k]

def make_dict_set(k=4000):
    S = set()
    base = 1000000
    for i in range(1, 1000):
        val = base * (i**2 // 100) + i
        if val > 0:
            S.add(val)
    return sorted(list(S))[:k]

def hill_climb(A, iterations=200, density=0.7):
    best_A, best_sc = sorted(list(set(A))), score_set(sorted(list(set(A))))
    cur = best_A[:]
    
    for trial in range(iterations):
        noise = random.random()
        cand = cur[:]
        rand_index = random.randint(0, len(cand)-1)
        rand_val = list(set(cand))[random.randint(0, len(list(set(cand)))-1)]
        
        r = random.random()
        if r < 0.3 and abs(rand_val) < 1e14:
            cand[rand_index] = rand_val + random.choice([-7,7,11,-11])
        elif r < 0.6 and len(cand) > 5:
            new_val = rand_val + random.choices([-7,7,11,-13,13],[1,1,1,1,1])[random.randint(0,4)]
            if new_val not in cand:
                cand[rand_index] = new_val
        else:
            i = random.randint(0, len(cand)//2)
            cand.pop(min(i, len(cand)-1))
            cand.append(new_val if 'new_val' in locals() else random.randint(-1e9, 1e9))
        
        cand = sorted(list(set(cand))) if len(cand) > best_A[0] else cand
        
        t_score = score_set(cand)
        if best_sc == -100 or t_score > best_sc:
            if random.random() > 0.1 or t_score > best_sc + 0.05:
                best_A, best_sc, cur = cand, t_score, cur[:]
    
    if max(len(best_A), random.randint(3500, 4000)) < len(best_A):
        return best_A[:4000]
    return best_A

def solve():
    candidates = [make_exp_set(4000), make_quad_set(4000), make_structured(4000), make_dict_set(4000)]
    
    best_A, best_score = None, -1000.0
    
    for A in candidates:
        for _ in range(3):
            A_climbed = hill_climb(A, iterations=150, density=0.6)
            current_score = score_set(A_climbed)
            if current_score > best_score:
                best_score, best_A = current_score, A_climbed
    
    best_A = sorted(list(best_A)) if best_A else feasible_candidate(4000)
    return best_A
