# EVOLVE-BLOCK-START
"""Entropy-injection greedy search.

We treat A as a set whose difference multiset should have high multiplicity entropy
(many distinct differences) while its sum multiset should have low collision entropy
(few distinct sums).  Start from an arithmetic progression (which has a small ratio of
distinct differences to distinct sums but is a good geometric scaffold), then repeatedly
inject new elements chosen from a random pool, greedily keeping the injection that best
improves the objective.  Pairwise interactions are estimated with fast set counts.
"""
import math
import random
import time


def _counts(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def solve():
    random.seed(12345)
    deadline = time.time() + 110.0

    best = None
    best_score = -1.0

    # several restarts with different arithmetic progressions / initial seeds
    starts = [
        list(range(0, 40)),
        [2 * i for i in range(0, 40)],
        [3 * i + 1 for i in range(0, 40)],
        [7, 15, 18, 22, -3, -2],
    ]

    for start in starts:
        a = sorted(set(start))
        # local greedy improvement by injecting candidates
        cur = a[:]
        improved = True
        while improved and time.time() < deadline:
            improved = False
            # random pool of candidate integers
            pool_size = 60
            base = len(cur)
            lo = min(cur) - 3 * base - 10
            hi = max(cur) + 3 * base + 10
            cands = set()
            while len(cands) < pool_size:
                cands.add(random.randint(lo, hi))
            cands.difference_update(cur)

            best_cand = None
            best_gain = 1e-9
            cur_s = _score(cur)
            for x in cands:
                if time.time() > deadline:
                    break
                trial = cur + [x]
                ts = _score(trial)
                gain = ts - cur_s
                if gain > best_gain:
                    best_gain = gain
                    best_cand = x
            if best_cand is not None and len(cur) < 4000:
                cur.append(best_cand)
                improved = True

        if _score(cur) > best_score:
            best_score = _score(cur)
            best = cur[:]
        if time.time() > deadline:
            break

    # refine best via local +/- moves on elements and injections while time remains
    if best is None:
        best = list(range(0, 40))

    while time.time() < deadline:
        cand = best[:]
        mode = random.random()
        if mode < 0.6 and len(cand) < 4000:
            # inject a point near existing cluster
            x = random.choice(cand) + random.randint(-5, 5)
            if x not in cand:
                cand.append(x)
        elif mode < 0.85:
            # perturb an element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-2, 2)
        else:
            # remove an element if large enough
            if len(cand) > 10:
                i = random.randrange(len(cand))
                cand.pop(i)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > best_score:
            best_score = s
            best = cand[:]
        elif random.random() < 0.05 and s > best_score - 0.2:
            best = cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
