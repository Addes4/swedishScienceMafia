import math
import random
import time
from collections import defaultdict

def _score_set(A_set):
    """Compute score for a set of integers; used for final evaluation."""
    if len(A_set) < 2:
        return 0.0
    diffs = set()
    sums = set()
    lst = list(A_set)
    n = len(lst)
    for i in range(n):
        for j in range(n):
            diffs.add(lst[i] - lst[j])
            sums.add(lst[i] + lst[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(A_set)) / 100

def solve():
    deadline = time.time() + 110  # leave some margin
    best_A = None
    best_score = -float('inf')
    
    # We'll try several starting configurations and select the best.
    # The core idea: greedy difference-injecting with incremental updates.
    # We maintain current A as a list (order not critical for set operations),
    # current diff set and sum set as Python sets, and also a "candidate pool"
    # from which we choose the best element to add each step.
    
    # For each run we pick a small initial arithmetic progression to keep initial sum-set small.
    # We also maintain "frontier" candidates around various scales.
    
    # Parameters
    MAX_SET_SIZE = 400
    CANDIDATE_POOL_SIZE = 500  # we'll refresh candidates frequently
    
    # We'll run several independent builds with different parameters and seeds.
    for trial in range(10):
        random.seed(trial * 12345 + int(time.time()*1000) % 10000)
        
        # Initial A: a short arithmetic progression (gives tiny sum/difference)
        # Choose length between 4 and 8, common difference small but not zero.
        init_len = random.randint(4, 8)
        diff_val = random.randint(1, 3) * random.choice([1, -1])
        start_val = random.randint(-5, 5)
        A = [start_val + i * diff_val for i in range(init_len)]
        
        # Ensure distinct
        A = list(set(A))
        if len(A) < 3:
            continue
        
        # Build diff and sum sets incrementally
        diffs = set()
        sums = set()
        n = len(A)
        for i in range(n):
            for j in range(n):
                diffs.add(A[i] - A[j])
                sums.add(A[i] + A[j])
        
        current_score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(A)) / 100
        
        # We'll use a pool of candidate integers: the union of several scaled ranges.
        # The pool will be periodically refreshed to include values near current A and random large scales.
        def generate_candidates(A_cur, size=200):
            candidates = set()
            if not A_cur:
                return list(range(-20, 21))
            # Nearby values based on current set
            for _ in range(size // 2):
                base = random.choice(A_cur)
                # small perturbation
                cand = base + random.randint(-5, 5)
                candidates.add(cand)
                # moderate jump
                cand = base + random.randint(-50, 50)
                candidates.add(cand)
            # Add random scales: powers of two multiplied by small integers
            for _ in range(size // 4):
                # scale from 2**k where k between 4 and 30
                k = random.randint(4, 30)
                scale = 1 << k
                # multiply by small odd integer
                odd = random.choice([1, 3, 5, 7, 9, 11, 13, 15, -1, -3, -5, -7, -9])
                candidates.add(scale * odd)
            # Some completely random numbers with large magnitude
            for _ in range(size // 4):
                magnitude = 10**random.randint(6, 14)
                val = random.randint(-magnitude, magnitude)
                candidates.add(val)
            # Remove existing elements
            existing_set = set(A_cur)
            candidates -= existing_set
            # Ensure integers
            candidates = [int(c) for c in candidates]
            # limit number
            if len(candidates) > size:
                candidates = random.sample(candidates, size)
            return list(candidates)
        
        # Greedy addition loop
        # We'll keep track of the best found during this trial
        trial_best_A = A[:]
        trial_best_score = current_score
        
        no_improve_count = 0
        
        while time.time() < deadline and len(A) < MAX_SET_SIZE:
            # Refresh candidate pool occasionally
            if random.random() < 0.3 or no_improve_count > 20:
                candidates = generate_candidates(A, CANDIDATE_POOL_SIZE)
            else:
                candidates = generate_candidates(A, CANDIDATE_POOL_SIZE // 2)
            
            best_cand = None
            best_gain_ratio = -1.0
            
            # Precompute current sizes for ratio
            len_diffs = len(diffs)
            len_sums = len(sums)
            # For each candidate compute new diffs and sums counts without actually adding
            # to sets (costly to copy). We'll compute incremental addition counts.
            # For a candidate x, new diffs: x - a for all a in A, and a - x for all a in A.
            # new sums: x + a for all a in A. (Also x+x and x-x but that's one diff 0 and one sum 2x, negligible)
            # Since we're just comparing ratios, we can approximate the effect on log.
            # But we need exact counts to update afterwards. So we'll calculate delta_diffs and delta_sums.
            
            for x in candidates:
                # Count new differences that would be added
                new_diffs = set()
                new_sums = set()
                for a in A:
                    d1 = x - a
                    d2 = a - x
                    if d1 not in diffs:
                        new_diffs.add(d1)
                    if d2 not in diffs:
                        new_diffs.add(d2)
                    s1 = x + a
                    if s1 not in sums:
                        new_sums.add(s1)
                # Also x - x = 0 (but 0 likely already in diffs if A has more than 1); ignore if already present.
                # x + x = 2x, check
                if 0 not in diffs:
                    new_diffs.add(0)
                if 2*x not in sums:
                    new_sums.add(2*x)
                
                delta_d = len(new_diffs)
                delta_s = len(new_sums)
                
                # Avoid adding if no new diffs (pointless)
                if delta_d == 0:
                    continue
                
                # We want to maximize the ratio increase. Instead of recomputing full log, we can use the
                # derivative-like criterion: the gain in numerator vs denominator.
                # We'll compute the new log|D| = log(len_diffs + delta_d)
                # new log|S| = log(len_sums + delta_s)
                # Score change approximated by delta_logD - delta_logS? Actually ratio change.
                new_log_d = math.log(len_diffs + delta_d)
                new_log_s = math.log(len_sums + delta_s)
                new_ratio = new_log_d / new_log_s
                # Also include size bonus change (tiny)
                # But for selection we just use ratio gain.
                gain = new_ratio - (math.log(len_diffs) / math.log(len_sums))
                
                # Prefer larger deltas if equal gain? Not needed.
                if gain > best_gain_ratio:
                    best_gain_ratio = gain
                    best_cand = (x, new_diffs, new_sums, delta_d, delta_s)
            
            if best_cand is None or best_gain_ratio <= 0:
                # Stuck; maybe try removing an element? But we keep trying.
                no_improve_count += 1
                if no_improve_count > 50:
                    # reset candidates drastically
                    no_improve_count = 0
                continue
            else:
                no_improve_count = 0
            
            x, ndiffs_set, nsums_set, dd, ds = best_cand
            # Add x to A
            A.append(x)
            # Update diffs and sums with the new sets
            diffs.update(ndiffs_set)
            sums.update(nsums_set)
            
            # Recompute current score (exact)
            current_score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(A)) / 100
            
            # Update trial best
            if current_score > trial_best_score:
                trial_best_score = current_score
                trial_best_A = A[:]
        
        # After loop, trial_best_A may be the best during this trial.
        if trial_best_score > best_score:
            best_score = trial_best_score
            best_A = trial_best_A[:]
    
    # If for some reason we failed, return a trivial set
    if best_A is None or len(best_A) < 2:
        best_A = [0, 1, 3]
    
    # Remove duplicates just in case
    best_A = sorted(set(best_A))
    # Truncate to max 4000 elements (but we limited to 400, so fine)
    return best_A

# The hidden test will call solve()
