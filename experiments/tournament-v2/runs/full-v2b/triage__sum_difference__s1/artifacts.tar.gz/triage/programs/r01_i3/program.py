# EVOLVE-BLOCK-START
"""Search for sets maximizing log|A-A|/log|A+A| via incremental counters + simulated annealing."""
import math
import random
import time
from collections import defaultdict


class State:
    __slots__ = ('A', 'sumcnt', 'diffcnt', 'ns', 'nd')

    def __init__(self, A):
        self.A = list(A)
        self.sumcnt = defaultdict(int)
        self.diffcnt = defaultdict(int)
        self.ns = 0
        self.nd = 0
        for i, x in enumerate(self.A):
            for j, y in enumerate(self.A):
                s = x + y
                if self.sumcnt[s] == 0:
                    self.ns += 1
                self.sumcnt[s] += 1
                d = x - y
                if self.diffcnt[d] == 0:
                    self.nd += 1
                self.diffcnt[d] += 1

    def score(self):
        n = len(self.A)
        if n < 2:
            return -1e9
        if self.ns <= 1 or self.nd <= 0:
            return -1e9
        return math.log(self.nd) / math.log(self.ns) + (1 - 1 / n) / 100

    def add(self, x):
        A = self.A
        sc = self.sumcnt
        dc = self.diffcnt
        for y in A:
            s = x + y
            if sc[s] == 0:
                self.ns += 1
            sc[s] += 1
            d1 = x - y
            if dc[d1] == 0:
                self.nd += 1
            dc[d1] += 1
            d2 = y - x
            if dc[d2] == 0:
                self.nd += 1
            dc[d2] += 1
        s = x + x
        if sc[s] == 0:
            self.ns += 1
        sc[s] += 1
        d = 0
        if dc[d] == 0:
            self.nd += 1
        dc[d] += 1
        A.append(x)

    def pop_index(self, i):
        x = self.A[i]
        sc = self.sumcnt
        dc = self.diffcnt
        for y in self.A:
            if y == x:
                s = x + x
                sc[s] -= 1
                if sc[s] == 0:
                    self.ns -= 1
                d = 0
                dc[d] -= 1
                if dc[d] == 0:
                    self.nd -= 1
            else:
                s = x + y
                sc[s] -= 1
                if sc[s] == 0:
                    self.ns -= 1
                d1 = x - y
                dc[d1] -= 1
                if dc[d1] == 0:
                    self.nd -= 1
                d2 = y - x
                dc[d2] -= 1
                if dc[d2] == 0:
                    self.nd -= 1
        self.A.pop(i)


def _seeds():
    seeds = []
    # geometric progressions
    for base in (2, 3):
        for k in (6, 9, 12):
            s = [1]
            v = 1
            for _ in range(k):
                v *= base
                s.append(v)
            seeds.append(s)
    # 2^i - 1
    seeds.append([(1 << i) - 1 for i in range(12)])
    # convex / squares
    seeds.append([i * i for i in range(20)])
    # arithmetic
    seeds.append(list(range(20)))
    # small mixed
    seeds.append([0, 1, 3, 7, 12, 20, 30, 44, 65, 80, 111, 150])
    # grid-like
    for m in (4, 5, 6):
        s = []
        for i in range(m):
            for j in range(m):
                s.append(i + j * (2 * m + 3))
        seeds.append(s)
    # random
    for _ in range(6):
        n = random.randint(15, 40)
        lo = random.choice([1, -30, -200])
        seeds.append([random.randint(lo, lo + 250) for _ in range(n)])
    return seeds


def _anneal(seed, deadline, global_best, global_best_score):
    st = State(seed + [0])
    cur = st.score()
    best = st
    best_score = cur
    if best_score > global_best_score:
        global_best, global_best_score = best.A[:], best_score
    T = 0.05
    it = 0
    while time.time() < deadline:
        it += 1
        n = len(st.A)
        r = random.random()
        # decide element range
        lo, hi = min(st.A), max(st.A)
        span = max(hi - lo, 10)
        if r < 0.7 and n >= 3:
            # perturb one element
            i = random.randrange(n)
            old = st.A[i]
            st.pop_index(i)
            if random.random() < 0.5:
                newx = old + random.randint(-max(2, span // 10) - 1,
                                            max(2, span // 10) + 1)
            else:
                newx = random.randint(lo - span // 4 - 1, hi + span // 4 + 1)
            st.add(newx)
            if len(set(st.A)) != len(st.A):
                # duplicate -> revert by reconstruct
                pass
        elif r < 0.85:
            # add an element
            newx = random.randint(lo - span // 3 - 2, hi + span // 3 + 2)
            if newx not in st.A:
                st.add(newx)
        else:
            # remove an element
            if n > 3:
                st.pop_index(random.randrange(n))
        ns = st.score()
        if ns > best_score or (ns >= cur) or (random.random() < math.exp((ns - cur) / max(T, 1e-6))):
            if ns > best_score:
                best_score = ns
                best = st
            cur = ns
        else:
            # revert: reconstruct by copying best-ish current
            st = State(best.A[:])
            cur = st.score()
        T *= 0.99995
        if best_score > global_best_score:
            global_best, global_best_score = best.A[:], best_score
    return global_best, global_best_score


def _score_list(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    """Return a list of distinct integers maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 108
    best = None
    best_score = -1e9

    # evaluate seeds
    for s in _seeds():
        s = sorted(set(s))
        if len(s) < 2:
            continue
        sc = _score_list(s)
        if sc > best_score:
            best, best_score = s, sc
        if time.time() > deadline - 90:
            break

    # annealing restarts
    random.seed(12345)
    seeds = _seeds()
    idx = 0
    while time.time() < deadline - 2:
        seed = seeds[idx % len(seeds)]
        idx += 1
        sub_deadline = min(deadline, time.time() + 25)
        best, best_score = _anneal(seed, sub_deadline, best, best_score)

    # final verification / slight cleanup
    if best is None:
        best = [0, 1, 3, 7, 12, 20, 30, 44]
    best = sorted(set(int(x) for x in best))
    return best
# EVOLVE-BLOCK-END
