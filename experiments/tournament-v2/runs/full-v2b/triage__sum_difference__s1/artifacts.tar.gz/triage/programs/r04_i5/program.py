# EVOLVE-BLOCK-START
import math
import random
import time

import numpy as np


# ---------------------------------------------------------------------------
# Exact score of an integer set
# ---------------------------------------------------------------------------
def _exact_score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) < 1:
        return 0.0, 0
    s = math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0
    return s, n


# ---------------------------------------------------------------------------
# Smoothed proxy  (continuous, differentiable-ish, cheap to estimate)
# ---------------------------------------------------------------------------
class SmoothedScore:
    """Score proxy computed by convolving the difference/sum distributions.

    A vector x of length n encodes gaps:  a_0 = x_0, a_{i+1} = a_i + |x_{i+1}|.
    The proxy counts "effective distinct values" via Gaussian kernel density:
        N_eff(S) = 1 / sum_v p(v)^2   (participation ratio / inverse Simpson)
    where p is a normalised kernel density over the multiset of differences/sums.
    This proxy is smooth in the a_i, so CMA-ES can climb it.
    """

    def __init__(self, band):
        self.band = float(band)

    def _set_from_gaps(self, gaps, n):
        a = np.empty(n, dtype=np.float64)
        a[0] = gaps[0]
        for i in range(1, n):
            a[i] = a[i - 1] + abs(gaps[i])
        return a

    def _participation(self, vals):
        """Inverse-Simpson effective count of a 1-D point cloud (sorted)."""
        m = vals.size
        if m == 0:
            return 1.0
        idx = np.argsort(vals, kind="stable")
        v = vals[idx]
        d = np.diff(v)
        # pairwise squared distances via band-limited kernel: only neighbours
        # within the kernel band matter (approximation).
        band = self.band
        # normalised weights per point using local contributions
        # w_i = sum_j exp(-(d_ij/h)^2) ; estimate via local window
        h2 = band * band
        # window radius in index space (heuristic): points within 3*band
        left = np.searchsorted(v, v - 3.0 * band, side="left")
        right = np.searchsorted(v, v + 3.0 * band, side="right")
        w = np.zeros(m, dtype=np.float64)
        # Use prefix over pairwise kernel inside window; O(m * W).
        for i in range(m):
            lo = left[i]
            hi = right[i]
            seg = v[lo:hi]
            w[i] = np.exp(-((seg - v[i]) ** 2) / h2).sum()
        wsum = w.sum()
        if wsum <= 0.0:
            return 1.0
        p = w / wsum
        return 1.0 / float(np.sum(p * p))

    def value(self, gaps):
        n = gaps.size
        a = self._set_from_gaps(gaps, n)
        # differences
        di = (a[:, None] - a[None, :]).ravel()
        si = (a[:, None] + a[None, :]).ravel()
        nd = self._participation(di)
        ns = self._participation(si)
        if ns < 1.0:
            return -1e9
        return math.log(max(nd, 1.0)) / math.log(max(ns, 1.0))


# ---------------------------------------------------------------------------
# CMA-ES (lightweight, standard-lib + numpy only)
# ---------------------------------------------------------------------------
class CMAES:
    def __init__(self, x0, sigma0, popsize=None):
        self.n = x0.size
        self.xmean = x0.astype(np.float64).copy()
        n = self.n
        if popsize is None:
            popsize = 4 + int(3 * math.log(n))
        self.lam = popsize
        self.mu = popsize // 2
        w = np.log(self.mu + 0.5) - np.log(np.arange(1, self.mu + 1))
        self.weights = w / w.sum()
        self.mueff = 1.0 / np.sum(self.weights ** 2)

        self.cc = (4 + self.mueff / n) / (n + 4 + 2 * self.mueff / n)
        self.cs = (self.mueff + 2) / (n + self.mueff + 5)
        self.c1 = 2 / ((n + 1.3) ** 2 + self.mueff)
        self.cmu = min(1 - self.c1,
                       2 * (self.mueff - 2 + 1 / self.mueff) / ((n + 2) ** 2 + self.mueff))
        self.damps = 1 + 2 * max(0, math.sqrt((self.mueff - 1) / (n + 1)) - 1) + self.cs

        self.pc = np.zeros(n)
        self.ps = np.zeros(n)
        self.B = np.eye(n)
        self.D = np.ones(n)
        self.C = np.eye(n)
        self.invsqrtC = np.eye(n)

        self.chiN = math.sqrt(n) * (1 - 1 / (4 * n) + 1 / (21 * n * n))
        self.sigma = sigma0
        self.eigeneval = 0
        self.counteval = 0

    def ask(self):
        self.z = np.random.randn(self.lam, self.n)
        self.y = self.z @ (self.B * self.D)
        self.x = self.xmean + self.sigma * self.y
        return self.x

    def tell(self, fitness):
        self.counteval += self.lam
        order = np.argsort(fitness)[::-1]
        xold = self.xmean.copy()
        ysel = self.y[order[:self.mu]]
        self.xmean = self.xmean + self.sigma * (self.weights @ ysel)

        yw = (self.xmean - xold) / self.sigma
        invsd = self.invsqrtC @ yw
        self.ps = (1 - self.cs) * self.ps + math.sqrt(self.cs * (2 - self.cs) * self.mueff) * invsd

        hsig_num = np.linalg.norm(self.ps)
        hsig = hsig_num / math.sqrt(1 - (1 - self.cs) ** (2 * self.counteval / self.lam)) / self.chiN
        hsig = 1.0 if hsig < 1.4 + 2.0 / (self.n + 1) else 0.0

        self.pc = (1 - self.cc) * self.pc + hsig * math.sqrt(self.cc * (2 - self.cc) * self.mueff) * yw

        artmp = self.y[order[:self.mu]]
        C = ((1 - self.c1 - self.cmu) * self.C
             + self.c1 * (np.outer(self.pc, self.pc)
                          + (1 - hsig) * self.cc * (2 - self.cc) * self.C)
             + self.cmu * (artmp.T @ (self.weights[:, None] * artmp)))
        self.C = np.triu(C) + np.triu(C, 1).T

        self.sigma *= math.exp((self.cs / self.damps) * (hsig_num / self.chiN - 1))

        if self.counteval - self.eigeneval > self.lam / (self.c1 + self.cmu) / self.n / 10:
            self.eigeneval = self.counteval
            self.C = np.triu(self.C) + np.triu(self.C, 1).T
            D2, self.B = np.linalg.eigh(self.C)
            D2 = np.maximum(D2, 1e-30)
            self.D = np.sqrt(D2)
            self.invsqrtC = self.B @ np.diag(1 / self.D) @ self.B.T


# ---------------------------------------------------------------------------
# Integer post-processing (hill climbing / local repair)
# ---------------------------------------------------------------------------
def _hill_climb(a, deadline, max_step=40, passes=3):
    a = sorted(set(int(v) for v in a))
    if len(a) < 2:
        return a
    cur_score, _ = _exact_score(a)
    best = a[:]
    best_score = cur_score

    def try_move(arr):
        nonlocal best, best_score
        s, _ = _exact_score(arr)
        if s > best_score:
            best_score = s
            best = arr[:]
            return True, s
        return False, s

    for _ in range(passes):
        improved = False
        i = 0
        while i < len(best):
            for step in (1, -1, 2, -2, 3, -3):
                cand = best[:]
                nv = cand[i] + step
                cand[i] = nv
                cand = sorted(set(cand))
                if len(cand) < 2:
                    continue
                s, _ = _exact_score(cand)
                if s > best_score:
                    best = cand
                    best_score = s
                    improved = True
                    break
            if time.time() > deadline:
                return best
            i += 1
        if not improved:
            break
    return best


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _random_seed_set(n, scale):
    vals = set()
    while len(vals) < n:
        vals.add(random.randint(-scale, scale))
    return sorted(vals)


def _gaps_from_set(a):
    a = sorted(a)
    g = [float(a[0])]
    for i in range(1, len(a)):
        g.append(float(abs(a[i] - a[i - 1])))
    return np.array(g)


def _set_from_gaps_int(gaps):
    a = [int(round(gaps[0]))]
    for i in range(1, len(gaps)):
        a.append(a[-1] + max(1, int(round(abs(gaps[i])))))
    return sorted(set(a))


# ---------------------------------------------------------------------------
# Main solver
# ---------------------------------------------------------------------------
def solve():
    random.seed(12345)
    np.random.seed(12345)
    deadline = time.time() + 115.0

    best_set = [7, 15, 18, 22, -3, -2]
    best_score, _ = _exact_score(best_set)

    # sizes to explore; bias toward moderate sets where ratio is high
    sizes = [6, 7, 8, 9, 10, 12, 14, 16, 20, 24, 30, 40]

    # seeds with known good structure (Sidon-like / greedy)
    def greedy_sidon(n):
        a = [0]
        used_d = {0}
        used_s = {0}
        x = 1
        while len(a) < n and x < 10 * n * n + 100:
            ok = True
            nd = set()
            ns = set()
            for y in a:
                nd.add(x - y)
                nd.add(y - x)
                ns.add(x + y)
            if len(nd & used_d) == 0:
                a.append(x)
                used_d |= nd
                used_s |= ns
            x += 1
        return a

    for n in sizes:
        try:
            sid = greedy_sidon(n)
            if len(sid) >= 2:
                sc, _ = _exact_score(sid)
                if sc > best_score:
                    best_score = sc
                    best_set = sid[:]
        except Exception:
            pass

    band = 6.0
    proxy = SmoothedScore(band)

    trial = 0
    while time.time() < deadline - 8:
        n = random.choice(sizes)
        trial += 1

        # ---- seed for CMA-ES ----
        if trial % 4 == 0:
            base = _random_seed_set(n, max(20, 4 * n))
        else:
            if len(best_set) >= 2:
                # perturb current best / resize
                base = best_set[:]
                if len(base) > n:
                    base = sorted(random.sample(base, n))
                while len(base) < n:
                    base.append(base[-1] + random.randint(1, 5))
            else:
                base = [1, 3]

        gaps0 = _gaps_from_set(base)
        if gaps0.size < 2:
            continue

        sigma0 = max(1.0, 0.6 * np.mean(np.abs(gaps0)) + 1.0)
        es = CMAES(gaps0, sigma0)

        local_best_gaps = gaps0.copy()
        local_best_proxy = proxy.value(gaps0)
        no_improve = 0

        gen = 0
        while time.time() < deadline - 8 and gen < 220:
            gen += 1
            X = es.ask()
            fits = np.empty(X.shape[0])
            for k in range(X.shape[0]):
                try:
                    fits[k] = proxy.value(X[k])
                except Exception:
                    fits[k] = -1e9
            es.tell(fits)

            j = int(np.argmax(fits))
            if fits[j] > local_best_proxy + 1e-9:
                local_best_proxy = float(fits[j])
                local_best_gaps = X[j].copy()
                no_improve = 0
            else:
                no_improve += 1

            es.sigma = min(es.sigma, 3.0 * sigma0)
            if no_improve > 90:
                break

        # ---- round to integers & repair ----
        cand = _set_from_gaps_int(local_best_gaps)
        if len(cand) < 2:
            continue

        sc, _ = _exact_score(cand)
        if sc > best_score:
            best_score = sc
            best_set = cand[:]

        repaired = _hill_climb(cand, deadline - 2)
        rsc, _ = _exact_score(repaired)
        if rsc > best_score:
            best_score = rsc
            best_set = repaired[:]

    # final polish on the overall best
    polished = _hill_climb(best_set, deadline, passes=4)
    psc, _ = _exact_score(polished)
    if psc > best_score:
        best_set = polished

    # safety: ensure constraints
    out = sorted(set(int(v) for v in best_set))
    out = [v for v in out if abs(v) <= 10**15]
    if len(out) > 4000:
        out = out[:4000]
    if len(out) < 2:
        out = [1, 2]
    return out
# EVOLVE-BLOCK-END
