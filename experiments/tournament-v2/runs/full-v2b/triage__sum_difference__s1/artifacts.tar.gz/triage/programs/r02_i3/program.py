# EVOLVE-BLOCK-START
"""Union of a dense arithmetic progression with sparse outliers from a different scale,
then local search refinement."""
import math
import random
import time


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1 or ld <= 0:
        return 0.0
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def solve():
    random.seed(20240517)
    deadline = time.time() + 115

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Phase 1: try many AP + outlier configurations
    for _ in range(2000):
        if time.time() > deadline:
            break
        n = random.choice([4, 6, 8, 10, 15, 20, 30, 50])
        m = random.choice([1, 2, 3, 5, 8, 12])
        d = random.choice([1, 2, 3, 4, 5, 7])
        base = random.randint(-100, 100)
        span = random.choice([50, 500, 5000, 100000])
        a = [base + i * d for i in range(n)]
        used = set(a)
        cnt = 0
        while len(a) < n + m and cnt < 300:
            cnt += 1
            v = random.randint(-span, span)
            if v not in used:
                used.add(v)
                a.append(v)
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a[:]

    # Phase 2: hill climbing / SA on best
    cur = best[:]
    cur_score = best_score
    step = 50
    last_improve = time.time()
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.5:
            i = random.randrange(len(cand))
            delta = random.randint(-step, step)
            if delta == 0:
                delta = 1
            cand[i] += delta
        elif r < 0.7:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1, 2, -2, 3, -3])
        elif r < 0.82 and len(cand) < 100:
            cand.append(random.randint(-100000, 100000))
        elif r < 0.92 and len(cand) > 4:
            i = random.randrange(len(cand))
            cand.pop(i)
        else:
            i = random.randrange(len(cand))
            j = random.randrange(len(cand))
            cand[i], cand[j] = cand[j], cand[i]

        if len(set(cand)) != len(cand):
            continue
        s = _score(cand)
        if s > cur_score or random.random() < 0.03:
            cur = cand
            cur_score = s
            if s > best_score:
                best = cand[:]
                best_score = s
                last_improve = time.time()
        if time.time() - last_improve > 20:
            cur = best[:]
            cur_score = best_score
            last_improve = time.time()
            step = max(1, step // 2)

    return sorted(set(best))


if __name__ == "__main__":
    r = solve()
    print(len(r), _score(r))
# EVOLVE-BLOCK-END
