# EVOLVE-BLOCK-START
"""
Construct A as a random subset of a Minkowski sum B + C, where B is a small set
and C a scaled geometric progression.  The sumset A + A is contained in
B + B + C + C, so it stays small, while the difference set can be much larger.
A simulated annealing / hill-climbing procedure refines the chosen subset
so that sum collisions are broken without introducing new ones.
"""

import math
import random
import time

# ----------------------------------------------------------------------------
# scoring helper (kept identical to the evaluator's spirit)
# ----------------------------------------------------------------------------


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    bonus = (1.0 - 1.0 / n) / 100.0
    return math.log(len(diffs)) / math.log(len(sums)) + bonus


# ----------------------------------------------------------------------------
# construction of the candidate universe
# ----------------------------------------------------------------------------


def _build_universe(seed):
    """Return the sorted list of all elements of B + C for a random choice
    of B and C."""
    rnd = random.Random(seed)

    # A tiny base set B.  B + B is very small, so the sumset of B+C stays
    # bounded even before moving to C.
    B = [0, 1, 4]

    # A scaled geometric progression C.  Geometric progressions have a
    # very rich difference structure (many distinct differences) but also
    # many sum collisions -- exactly what we want.
    r = rnd.choice([2, 3])
    m = rnd.choice([10, 11, 12])
    start = rnd.randint(0, 2)
    C = []
    v = start
    for i in range(m):
        C.append(v)
        v *= r
        if v > 10 ** 6:
            break
    # optionally squeeze a few extra values in
    if len(C) > 2 and rnd.random() < 0.5:
        C.append(C[-1] + C[-2])
    C = sorted(set(C))

    # Minkowski sum B + C
    universe = sorted({b + c for b in B for c in C})
    return universe, B, C


# ----------------------------------------------------------------------------
# local-search refinement (simulated annealing style)
# ----------------------------------------------------------------------------


def _refine(universe, target, seed, deadline):
    rnd = random.Random(seed)
    n_uni = len(universe)
    if n_uni == 0:
        return []

    # start from a random subset
    k = min(target, n_uni)
    chosen = set(rnd.sample(range(n_uni), k))

    cur_val = _score([universe[i] for i in chosen])
    best_chosen = set(chosen)
    best_val = cur_val

    T0 = 0.02
    temp = T0
    step = 0

    while time.time() < deadline:
        step += 1
        # geometric cooling
        temp = T0 * (0.9995 ** step)
        if temp < 1e-6:
            temp = 1e-6

        # perturb: swap one element
        mode = rnd.random()
        if mode < 0.7 and chosen:
            # remove one
            out = rnd.choice(list(chosen))
            chosen.discard(out)
            if len(chosen) < target:
                # add a fresh one not already in
                for _ in range(5):
                    cand_in = rnd.randrange(n_uni)
                    if cand_in not in chosen:
                        chosen.add(cand_in)
                        break
        else:
            # swap attempt
            if chosen:
                out = rnd.choice(list(chosen))
                cand_in = rnd.randrange(n_uni)
                if cand_in not in chosen:
                    chosen.discard(out)
                    chosen.add(cand_in)

        new_val = _score([universe[i] for i in chosen])

        if new_val >= cur_val or rnd.random() < math.exp((new_val - cur_val) / max(temp, 1e-9)):
            cur_val = new_val
            if new_val > best_val:
                best_val = new_val
                best_chosen = set(chosen)

    return [universe[i] for i in best_chosen]


# ----------------------------------------------------------------------------
# main entry point
# ----------------------------------------------------------------------------


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    deadline = time.time() + 110  # leave a little margin

    best = None
    best_score = -1.0

    # Try several constructions with different seeds / universes.
    seed = 0
    while time.time() < deadline:
        seed += 1
        universe, B, C = _build_universe(seed)

        if len(universe) < 2:
            continue

        target = min(4000, len(universe))

        # Local search within this universe.
        cand = _refine(universe, target, seed, min(deadline, time.time() + 20))

        if len(cand) >= 2:
            s = _score(cand)
            if s > best_score:
                best_score = s
                best = cand

        # also consider some simpler sub-universes
        # e.g. proportions of B+C
        if len(universe) >= 8:
            for frac in (0.5, 0.75):
                k = max(4, int(len(universe) * frac))
                sub = universe[:k]
                if len(sub) >= 2:
                    s2 = _score(sub)
                    if s2 > best_score:
                        best_score = s2
                        best = sub

    if best is None:
        best = [0, 1, 4]

    # Deduplicate and sort, respecting the size constraint.
    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]

    return best


# EVOLVE-BLOCK-END
