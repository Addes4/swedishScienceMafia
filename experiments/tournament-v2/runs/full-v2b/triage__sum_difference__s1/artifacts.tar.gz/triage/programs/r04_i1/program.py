import math
import time

def sieve(n):
    """Generate primes up to n using Sieve of Eratosthenes"""
    sieve = [True] * (n + 1)
    sieve[0] = sieve[1] = False
    for i in range(2, int(n**0.5) + 1):
        if sieve[i]:
            for j in range(i*i, n + 1, i):
                sieve[j] = False
    return [i for i in range(n + 1) if sieve[i]]

def main():
    start_time = time.time()
    all_primes = sieve(200000)
    
    best_score = -1.0
    best_set = []
    
    deadline = start_time + 120
    
    # Precompute primes to control product range
    primes1 = [p for p in all_primes if 100 <= p <= 10000]
    primes2 = [p for p in all_primes if 11000 <= p <= 100000]
    
    for i in range(500):  # Limit iterations
        for j in range(500):
            if time.time() > deadline:
                break
            
            # Create subsets with controlled size
            p_start = max(100, primes0)
            p_end = min(10000, p_start + 100)
            q_start = max(11000, q_start)
            q_end = min(100000, q_start + 50)
            
            p_vals = [p for p in all_primes if p_start <= p <= p_end]
            q_vals = [p for p in all_primes if q_start <= p <= q_end]
            
            products = [p * q for p in p_vals for q in q_vals]
            
            if len(products) < 10 or any(x < 1 for x in products):
                continue
            
            # Remove duplicates
            products = sorted(set(products))
            
            # Calculate score
            sums = set()
            diffs = set()
            for idx, a in enumerate(products):
                for b in products[idx:]:
                    sums.add(a + b)
                    diffs.add(a - b)
            
            if not sums or not diffs:
                continue
            
            score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / len(products)) / 100
            
            score_bonus = (1 - 1/len(products)) / 100
            score_ratio = math.log(len(diffs)) / math.log(len(sums))
            final_score = score_ratio + score_bonus
            
            if final_score > best_score:
                best_score = final_score
                best_set = products[:min(len(products), 4000)]
    
    # Continue search with heuristic if still good
    # Use best set as anchor to explore variations
    
    return best_set

def solve():
    # Reset best state function
    start = time.time()
    best_score = -1.0
    best_A = []
    
    primes = sieve(150000)
    # Search with interval sweep
    for p_lo in primes[:1000]:
        if time.time() - start > 115:
            break
        for p_hi in primes[min(p_lo + 20, len(primes) - 1):]:
            if time.time() - start > 115:
                break
            for q_lo in primes[max(p_lo, p_hi + 30):]:
                if time.time() - start > 115:
                    break
                for q_hi in primes[min(q_lo + 10, len(primes) - 1):]:
                    if time.time() - start > 115:
                        break
                    
                    p_subset = [p for p in primes if p_lo <= p <= p_hi]
                    q_subset = [p for p in primes if q_lo <= p <= q_hi]
                    
                    if not p_subset or not q_subset:
                        continue
                    
                    limit = 3500
                    if len(p_subset) * len(q_subset) > 4000:
                        p_subset = p_subset[:50]
                        q_subset = q_subset[:50]
                        if len(p_subset) * len(q_subset) < 5:
                            continue
                    
                    prod_list = [p * q for p in p_subset for q in q_subset]
                    prod_list = sorted(set(prod_list))
                    
                    if len(prod_list) < 10:
                        continue
                    
                    deadline = start + 118
                    if time.time() > deadline:
                        break
                    
                    sums = {prod_list[i] + prod_list[j] for i in range(len(prod_list)) for j in range(len(prod_list))}
                    diffs = {prod_list[i] - prod_list[j] for i in range(len(prod_list)) for j in range(len(prod_list))}
                    
                    if len(sums) < 10 or len(diffs) < 10:
                        continue
                    
                    score = math.log(len(diffs)) / math.log(len(sums)) + (len(prod_list) / len(prod_list) - 1e-15) / 100
                    
                    if score > best_score:
                        best_score = score
                        best_A = prod_list[:min(len(prod_list), 4000)]
    
    # Final optimization
    if len(best_A) > 1:
        sums = set(best_A[0] + b for b in best_A)
        diffs = set(best_A[0] - b for b in best_A)
        
        best_A = sorted(best_A)
    
    return best_A
# This is getting too verbose. Let me implement a cleaner version.
