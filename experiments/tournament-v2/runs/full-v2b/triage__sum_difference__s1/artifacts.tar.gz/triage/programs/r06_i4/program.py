"""
Construct A as a union of shifted copies of a base set B that has small doubling.
Use B = generalized arithmetic progression of dimension 2, and shifts that grow
like powers of a large base so that differences between different shifts are unique.
We search over shift exponents to optimize the ratio.
"""
import math
import itertools
import time


def base_set_gap2(L1, L2):
    """Return a 2-dim arithmetic progression B = {i*d1 + j*d2 : 0<=i<L1, 0<=j<L2}
    with d1=1, d2 = L1 so that B+B has size ~4*|B| if we don't overlap, but we
    structure to keep sums small. We'll use a more sophisticated base set."""
    d1 = 1
    d2 = L1  # makes B a subset of [0, L1*L2) so B+B subset of [0, 2*L1*L2)
    B = [i * d1 + j * d2 for i in range(L1) for j in range(L2)]
    return B


def score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    sumset = {x + y for x in a for y in a}
    diffset = {x - y for x in a for y in a}
    return math.log(len(diffset)) / math.log(len(sumset)) + (1 - 1 / len(a)) / 100


def optimize_shifts(B, max_shift, max_copies, time_limit):
    """
    Given base set B, find shift exponents e0, e1, ... (each >=0) such that
    A = union_i (B * base^ei) and shifts are powers of 'base'.
    base is chosen large: roughly max_shift. 
    We search for combination giving best score.
    """
    # B is small enough to compute sums/diffs quickly.
    # Represent shift sets as integers: for exponent e, shift = base**e.
    # We'll use base = max_shift, and constrain total elements <= 4000.
    nB = len(B)
    max_copies_cap = min(max_copies, 4000 // nB)
    
    base = max_shift  # Actually use a huge base to ensure differences unique.
    # But we must keep numbers within 1e15.
    max_exponent = int(math.log(1e15, base)) - 1
    # Available exponents from 0..max_exponent.
    exponents = list(range(max_exponent + 1))
    
    best_A = B[:]
    best_score = score(best_A)
    best_exponents = [0]
    
    # Greedy/iterative improvement: add shifts one by one.
    deadline = time.time() + time_limit * 0.9  # Leave time for final build
    
    # Precompute B+B and B-B sets as Python sets for faster scoring when building A gradually.
    B_set = set(B)
    Bsum = {x + y for x in B for y in B}
    Bdiff = {x - y for x in B for y in B}
    
    # We'll maintain A_set, sumset, diffset incrementally.
    A_set = set(B)
    Sumset = set(Bsum)
    Diffset = set(Bdiff)
    current_exponents = [0]
    n = nB
    
    # Helper to compute score from incremental sets
    def incremental_score():
        return math.log(len(Diffset)) / math.log(len(Sumset)) + (1 - 1 / n) / 100
    
    # For each candidate exponent e (not already used), compute new elements and sets.
    while time.time() < deadline and len(current_exponents) < max_copies_cap:
        best_improvement = 0.0
        best_e = None
        best_new_sets = None
        # Try each possible new shift
        for e in exponents:
            if e in current_exponents:
                continue
            shift = base ** e
            new_elements = {b * shift for b in B}
            # Quick check: if new elements exceed 1e15, skip
            if max(new_elements) > 1e15:
                continue
            # Compute new sumset and diffset estimates
            # For sums between new and existing:
            # candidate sumset = old_sumset ∪ (new+new) ∪ (new+old) ∪ (old+new)
            # Since symmetric.
            # For diffs: old_diffset ∪ (new-new) ∪ (new-old) ∪ (old-new)
            # Because base is huge, cross terms likely disjoint, but we compute exactly.
            
            # Build test sets
            test_A = A_set | new_elements
            # Compute sums and diffs quickly using loops over B (small) and existing shifts.
            # We can incrementally update using known relations.
            # Better: recompute from scratch is okay because total size small (<4000).
            # But with many iterations we need speed. Since B small, we can compute cross sums/diffs via loops.
            
            # Estimate via formula? No, need exact for comparison. Use direct small compute.
            # Here we approximate: we know Bsum, Bdiff, and cross terms:
            # cross sums: a + b' where a in old, b' in new. Since old is union of shifted B's,
            # we can compute by iterating over existing shifts.
            # We'll just compute new sum/diff incremental using loops over old shifts.
            pass
        
        # Because the search space is small, we can simply evaluate all combinations
        # of up to max_copies_cap exponents (maybe 5-6) with exhaustive search.
        # Let's do a systematic small search.
        break  # skip incremental; we'll use combinatorial scan below.
    
    # Combinatorial search for best combination of exponents (max 5 shifts due to 4000 limit
    # with base sets of size maybe 100-200).
    # We'll try base set sizes ~100 => nB=100 => max copies 40, but we want few copies to keep sumset small.
    # Actually, we want very few copies, like 3-5.
    
    # Let's design base set B with very small sumset. Use a "Sidon-like" but for sums?
    # We'll use a specialized B: all numbers from 0 to K-1, for some K.
    # That gives sumset = [0, 2K-2] ~ 2K, diffset = [-(K-1), K-1] ~ 2K-1.
    # That yields ratio log(2K-1)/log(2K) < 1.
    # But we need high ratio, so we want sumset much smaller than diffset.
    # For that, we want B to be an arithmetic progression: B = {0, d, 2d, ..., (m-1)d}.
    # Then sumset = {0, d, 2d, ..., 2(m-1)d} size 2m-1, diffset = {-(m-1)d, ..., (m-1)d} size 2m-1.
    # So same size. Ratio ~1. Not enough.
    # The key idea: use multiple shifted copies with huge gaps between shifts.
    # Then sumset is roughly (B+B) + (shift_i+shift_j) but shift_i+shift_j are few values if we use few shifts.
    # Diffset gets (B-B) + (shift_i - shift_j) where cross differences are all distinct because gaps huge.
    # So we want many shifts => many cross differences, each giving full B-B cardinality.
    # So diffset ~ (#shifts)^2 * |B-B|, sumset ~ (#sums of shifts) * |B+B|.
    # To maximize ratio, we want #shifts large but #distinct sums of shifts small.
    # This suggests using shifts that form a sum-free set or small sumset themselves.
    # For example, take shift exponents as a set S such that S+S is small (e.g., powers of 2? Actually powers of 2 have many sums.
    # Better: choose shifts as a geometric progression: shift_i = base^i. Then sums base^i+base^j are mostly distinct, so many sums -> bad.
    # So we want S such that S+S has few elements, but S-S has many. That's exactly the same problem but for shifts themselves.
    # We can use a set S that is an arithmetic progression: e.g., S = {0, d, 2d, ..., (k-1)d} but then shift values = C^S?
    # Wait we want shift values = growth^{exponent}. So if exponents are arithmetic progression, shift values = base^{a + i*d} = (base^a)*(base^d)^i.
    # That is geometric progression in values. So sums of values are not few.
    # The "shifts chosen as powers of a large base" in the idea meant: shifts are powers of a base, but we can choose exponents S that form a set with small sumset (as integers). Then shift values are base^S, but base is huge. Then sumset of shift values: base^s + base^t. Since base huge, base^s + base^t ≈ max(base^s, base^t) unless s=t. So the cardinality of sumset of shift values is approximately 2|S|-1 (if S sorted). But if base is huge, base^s + base^t are all distinct for distinct (s,t) unordered? Actually if s != t, base^s + base^t is dominated by the larger exponent, and since base huge, no collisions. So the number of distinct sums is exactly |S|*(|S|+1)/2, just like integers. So we don't gain.
    # So we need a different structure: use shifts that are themselves a set with small doubling (as integers, not as exponents). But shifts need to be huge to isolate B copies.
    # Idea: take B as a 2-dim progression (size ~N) with small sumset. Then take shifts as a Sidon set (or B2 set) to maximize differences, but we want shift sums to be few -> that suggests shifts forming a small interval? That makes sums many.
    # Wait we want few sums of shifts, so shifts should be very sparse but have many differences. A geometric progression has many differences and many sums. Not good.
    # Perhaps we can use shifts that are all multiples of a large number, forming a progression: e.g., shifts = {M, 2M, 3M, ..., kM}. Then sums = {2M, 3M, ..., 2kM} size 2k-1, diffs = {-(k-1)M,..., (k-1)M} size 2k-1. Same.
    # So ratio from shift set alone is ~1. But when combined with B, we get:
    # A = union_{i=1..k} (B + shift_i). Then A+A = union_{i,j} (B+B + shift_i+shift_j). 
    # The number of distinct sums of shift_i+shift_j is at most 2k-1 (since they are multiples of M). So |A+A| <= (2k-1)*|B+B|.
    # A-A = union_{i,j} (B-B + shift_i - shift_j). Differences of shifts are multiples of M, range from -(k-1)M to (k-1)M, so at most 2k-1 distinct values. Then |A-A| <= (2k-1)*|B-B|.
    # So ratio log((2k-1)|B-B|)/log((2k-1)|B+B|) ≈ same as single copy's ratio. No improvement.
    
    # We need cross differences to explode: shift_i - shift_j must be all distinct for i≠j. That requires shift set to have many differences (like Sidon set). But then shift sums will also be many (since Sidon sets have many sums typically).
    # The breakthrough: use shifts that are elements of a set with very small sumset but large difference set: i.e., a set that itself solves the problem recursively!
    # That is, use A = B + S where S is an optimal set for the same problem, scaled appropriately.
    # Then |A+A| = |B+B + S+S| <= |B+B| * |S+S|, and |A-A| = |B-B + S-S| = |B-B| * |S-S| (if B-B and S-S are sufficiently generic to produce full product, which happens if B and S have appropriate structure).
    # So log|A-A|/log|A+A| ≈ (log|B-B|+log|S-S|) / (log|B+B|+log|S+S|). If S has ratio r, and B has ratio ~1, overall ratio < r. So we need B with ratio >1 to boost.
    # So base set B itself must have high ratio. That's the key.
    
    # How to get B with high ratio without using multiple copies? For a single set, it's known that a set can have many differences and few sums if it is "sum-difference balanced" e.g., arithmetic progressions have ratio 1, geometric progressions have ratio log(2n-1)/log(2n-1)=1. So no.
    # Except: sets like {0, 1, 3, 7, 15, ...} powers of 2? Sumset = all numbers with at most two bits set? Many. Difference set also many. Not good.
    # Actually the problem asks to find a set with large difference set and small sum set. Known constructions use "MSTD sets" (more sums than differences) but we want the opposite: more differences than sums. These are called "DST sets" (difference dominates sum). It's known that such sets exist, e.g., using union of intervals.
    # Example: A = [0, k] ∪ [M, M+k] with M huge. Then:
    # A+A = [0,2k] ∪ [M, M+2k] ∪ [2M, 2M+2k] -> size approx 3*(2k). (plus some overlap maybe)
    # A-A = [-(M+k), M+k] essentially full interval of length ~2M dominated by M, so size ~2M.
    # Choose M >> k. Then |A-A| ~ 2M, |A+A| ~ 6k. Ratio log(2M)/log(6k). Pick k small, M huge -> ratio >1. But we are limited by 4000 integers and max absolute value 1e15. So we can use many small blocks separated by huge gaps.
    # This is exactly the idea: take a base block B (like an interval) and place copies with large gaps so that differences between blocks cover a huge contiguous range (all cross differences distinct and densely fill), while sums stay within separate blocks (each block sumset small).
    
    # So plan: B = a dense interval [-L, L] (size 2L+1). Then B+B = [-2L, 2L] size 4L+1, B-B = [-2L, 2L] same. Not good ratio. But if we take multiple copies shifted by large gaps, cross differences between different copies become full intervals of length ~ gap, giving huge diffset.
    # To maximize ratio, we want many copies with carefully chosen gaps so that cross differences overlap minimally but sums stay confined.
    # Known construction: take A = union_{i=0}^{m-1} (a_i + B) where B = {0,1,...,k-1}, and shifts a_i chosen such that a_{i+1} - a_i >> k. Then A+A consists of blocks around a_i + a_j. Since gaps large, a_i + a_j are all distinct ordered pairs? Actually sums of shifts produce values spread out. To keep sumset small, we need a_i + a_j to take few distinct values. That requires shifts themselves to have small sumset - exactly the same problem recursively.
    # So we can use a structured set of shifts that is itself a union of blocks. Thus we can build a multi-scale structure.
    # This leads to a "Cantor-like" set or something?
    
    # Simpler: Use shifts that are in geometric progression: a_i = C * R^i. Then sums a_i + a_j are all distinct because of uniqueness of base-R representation if R > 2? Actually any two such sums can coincide? Example: 1 + 100 = 10 + 91? Not if R large enough. But distinctness means many sums, so sumset large.
    
    # So instead, make shifts have very small sumset: e.g., shifts form an arithmetic progression: a_i = i * D, i=0..m-1. Then sums range from 0 to 2(m-1)D, step D, so size 2m-1. That's small! But then cross differences: a_i - a_j = (i-j)D, so they also form arithmetic progression from -(m-1)D to (m-1)D, size 2m-1, same. So no gain.
    
    # The trick: make B itself a set with very small sumset compared to its size, but large difference set. Is that possible? For a single block B = interval [0,k-1], sumset size 2k-1, diffset size 2k-1. Ratio=1.
    # But if B is a "sum-free" set, e.g., all numbers > N/2? Then sumset small. However we need B to be an interval to make cross differences fill large intervals.
    
    # Wait: if we use B = {0, G} a two-element set, then B+B={0,G,2G} size 3, B-B={-G,0,G} size 3. Ratio=1.
    # If we use B = {0, a, b} then sums can be small if we choose a+b small? Not really.
    
    # There's known construction: A = {0, 1, 3, 7, 15, ...}? No.
    
    # Let's look up known results: Maximizing |A-A|/|A+A| is equivalent to minimizing doubling constant. Sets with small doubling are approximate groups, like arithmetic progressions, which have doubling ~2. Sets with large difference set but small sum set are "MSTD" reversed. Known that for finite sets in integers, it's easy to have |A-A| > |A+A| by taking union of far intervals. The maximum possible ratio of logs was studied: the supremum is 2? Actually known that |A-A| <= |A+A|^2 / |A|? Or something. Check: Plünnecke–Ruzsa inequalities: |A+A| <= |A-A|^? Not directly. However, we can achieve log|A-A|/log|A+A| arbitrarily close to 2? No there is a bound: |A-A| <= |A+A|^2 / |A|? I'm not sure.
    
    # But from the benchmark, best known score 1.28155 means ratio ~ exp(1.28155) ≈ 3.6? Actually score = log|A-A|/log|A+A|. If |A-A| = 3.6^log|A+A|, that's not direct. For example, if |A+A|=100, |A-A|=100^1.28155 ≈ 316. So moderate.
    
    # Let's try to construct a union of many small intervals with huge gaps between them, but choose the positions to minimize the sumset size while difference set becomes huge.
    # Suppose we take m blocks each of size k, placed at positions x_1 < x_2 < ... < x_m with huge gaps: x_{i+1} - x_i > 2*k*m + something.
    # Then A+A will consist of the union over i<=j of (block_i + block_j) shifted by x_i+x_j. Since gaps are huge, these sums for different (i,j) pairs will not overlap if the set of sums x_i+x_j are all distinct and separated by > block sum size. The number of distinct block-pair sums is at most m(m+1)/2. If we force these sums to be few (e.g., many collisions), we can shrink sumset.
    # How to make many x_i + x_j collisions? That's equivalent to having the shift set S = {x_i} have small sumset.
    # We can choose S as an arithmetic progression: x_i = i*D for i=0..m-1, with D very large > (k * ?). Then x_i+x_j = (i+j)*D, which ranges from 0 to 2(m-1)D, step D, so only 2m-1 distinct sums. That's few!
    # But then cross differences: x_i - x_j = (i-j)*D, again only 2m-1 distinct values. So difference set of A would be only (2m-1) times k^2? Actually A-A = union_{i,j} (block_i - block_j + x_i - x_j). Since x_i - x_j takes few values, the total diffset size ≈ (2m-1) * (size of block diff set). If block is an interval of length k, block diff set size 2k-1. So |A-A| ≈ (2m-1)*(2k-1). Sumset size ≈ (2m-1)*(2k-1) as well (since block sum set size is also 2k-1). Ratio=1.
    
    # So arithmetic progression for shifts gives no advantage.
    
    # We need shift set S such that S+S is small but S-S is large. That's the same type of problem, so we can use a recursive construction.
    
    # Known recursive MSTD construction by Nathanson: sets with more sums than differences, but we can reverse for differences.
    # Actually, there is a known construction of sets with |A-A| > |A+A|: take A = {0, 2, 3, 4, 7, 11, 12, 14}? This gives something? I recall a paper "Sets with more differences than sums" by some authors. They gave explicit constructions using base 3 representations.
    # Indeed, one can use a set defined by allowed digits: A = numbers whose base-K representation uses only digits from a set D. Then sumset corresponds to sums digitwise with carries. If D+ (digitwise sumset) is small, the sumset is small, while difference set can be large.
    # This is promising.
    
    # Consider base M large. Define A = { sum_{i=0}^{L-1} d_i * M^i : d_i in D } where D subset of {0,1,...,M-1}.
    # Then A+A consists of numbers whose digits are in D+D (with carries possible). If M is large enough compared to max digit sum, there are no carries across digits because max digit sum < M. Then A+A is exactly the set of numbers with digits in D+D. So |A+A| = |D+D|^L.
    # Similarly A-A, if we also ensure no borrow (e.g., M large enough so that - (M-1) ...), then digits are in D-D (with possible negative). If we allow negative digits, difference set size = |D-D|^L.
    # Thus ratio = L*log|D-D| / (L*log|D+D|) = log|D-D|/log|D+D|, which is independent of L. So we get a constant ratio >1 if we can choose D with |D-D| > |D+D|.
    # So the problem reduces to finding a digit set D subset of integers (can be not contiguous) with many differences and few sums.
    # Furthermore, we can choose M huge so that no carries/borrows, and L such that total size = |D|^L <= 4000, and numbers < 1e15.
    
    # So we just need to find a good digit set D of small size (say |D|=2,3,4...) and exponent L to get large ratio.
    
    # For |D|=2: D = {a,b}. Then D+D = {2a, a+b, 2b} size 3. D-D = {0, a-b, b-a} size 3 if a!=b. So ratio=1.
    # |D|=3: maybe we can get |D-D| > |D+D|?
    # Let D = {0,1,3}. Sumset: {0,1,2,3,4,6} size 6. Diffset: {-3,-2,-1,0,1,2,3} size 7. Ratio log7/log6 ≈ 1.086. Modest.
    # D={0,1,4}: sumset {0,1,2,4,5,8} size 6, diffset {-4,-3,-1,0,1,3,4} size 7, same ratio.
    # D={0,2,3}: sums {0,2,3,4,5,6} size 6, diffs {-3,-2,-1,0,1,2,3} size 7.
    # D={0,1,5}: sums {0,1,2,5,6,10} size 6, diffs {-5,-4,-1,0,1,4,5} size 7.
    # Many give ratio 1.086.
    # For |D|=4: try to maximize diffset. D={0,1,3,7}? Sumset: compute. We need systematic search.
    
    # Better: use D as a geometric progression? D = {0, 1, a, a^2?} no.
    
    # Let's search small digit sets with high diff/sum ratio.
    
    best_D = None
    best_ratio = 0.0
    # Search up to size 6, digits up to maybe 20.
    for size in range(2, 7):
        # Use combinations from range, but search smart.
        for comb in itertools.combinations(range(30), size):
            if comb[0] != 0:  # we can always shift so that min is 0, no loss
                # Actually we can shift D by subtracting min, but then sums/diffs scale? Shifting doesn't change cardinalities.
                # Let's enforce min=0 for canonical search.
                continue
            D = list(comb)
            sumset_d = set()
            for a in D:
                for b in D:
                    sumset_d.add(a+b)
            diffset_d = set()
            for a in D:
                for b in D:
                    diffset_d.add(a-b)
            if len(diffset_d) > len(sumset_d):
                r = math.log(len(diffset_d)) / math.log(len(sumset_d))
                if r > best_ratio:
                    best_ratio = r
                    best_D = D[:]
                    #print("Found D", D, "sum", len(sumset_d), "diff", len(diffset_d), "ratio", r)
    
    # Found D = [0, 1, 3, 7, 12, 20]? Actually we need exhaustive search up to maybe 50 to find good ones.
    # But we can also consider non-integer digits? No.
    
    # From known results, there are sets achieving ratio > 1.2. For size 6 maybe better.
    
    # Since we can choose M huge, we can take L such that |D|^L <= 4000, using best D.
    # Also numbers must be < 1e15 => M^L * max_digit <= 1e15.
    
    # So algorithm: find optimal D (size n) with high diff/sum log ratio.
    # Then pick L = floor(log_{n}(4000)) but ensure M is large enough to avoid carries.
    # M must be > max(D)+max(D) = 2*max(D). To be safe, M = 2*max(D)+1 or larger.
    # Then total size N = n^L. Numbers: max value = (M^L - 1)/(M-1) * max(D) ≈ M^L * max(D) / (M-1). So about M^L.
    # We can increase M to make numbers larger but still within 1e15.
    # Actually the ratio is independent of M, as long as no carries.
    
    # So we can make A huge and still fit constraints.
    
    # But careful: difference set cardinality computed as |D-D|^L assumes no borrow, which requires M > max(|D-D|). That's larger: M > max_diff = max(D)-min(D) = max(D) (since min 0). So M > max(D) is enough? Let's check: when subtracting y from x, the digitwise difference may be negative, but we can represent using negative digits. However, the resulting integer is still formed with possibly negative digits? The base representation with digits in D-D may be not unique if carries. To ensure uniqueness (and thus cardinality exactly |D-D|^L), we need M > max(D-D) = max(D) (since min 0, max dif = max -0). Actually if D-D includes negative numbers, we can just allow digits in range [ -max(D), max(D) ], and to avoid overlap between different digit positions, we need the ranges to be disjoint. That requires M > 2*max(D). Because if we have digits from -U to U, then two different digit vectors could produce the same integer if there's carry: e.g., (0, U) vs (1, - (M-U)?). To prevent, we need each digit position to be isolated: the maximum absolute value contributed by lower digits must be less than the spacing between possible values of the current digit. Standard condition: if max digit magnitude is U, we need M > 2U such that (U + U*M^(L-1)) < M^L? Actually the condition for unique representation with digits from a set S is that M > max(S) - min(S). For S = D-D, min = -max(D), max = max(D), so M > 2*max(D) ensures no overlapping ranges. But we can also use signed digits directly; still the condition is M > max(D-D) - min(D-D) = 2*max(D).
    # So choose M = 2*max(D) + 1.
    
    # Then |A-A| = (|D-D|)^L, |A+A| = (|D+D|)^L.
    # So score = L*log|D-D| / (L*log|D+D|) + small bonus = log|D-D|/log|D+D| + bonus.
    # Thus the score is exactly the digit set's ratio, independent of L (except bonus favors larger |A|). So we should make |A| as large as possible (up to 4000) to get bonus.
    # So we need to find D that maximizes r = log|D-D|/log|D+D|, and then choose L such that |D|^L <= 4000 but as large as possible.
    # And also ensure elements <= 1e15.
    
    # We can search D up to size maybe 7 or 8, because n^L must be <=4000.
    # For n=2, max L=11 (2^11=2048), 2^12=4096>4000, so L=11.
    # n=3, 3^7=2187, 3^8=6561>4000, L=7.
    # n=4, 4^5=1024, 4^6=4096>4000, L=5.
    # n=5, 5^4=625, 5^5=3125, 5^6=15625 -> L=5.
    # n=6, 6^4=1296, 6^5=7776 -> L=4.
    # n=7, 7^4=2401 -> L=4.
    # n=8, 8^3=512, 8^4=4096 -> L=3.
    # n=9, 9^3=729, 9^4=6561 -> L=3.
    # So we need to test n from 2 to maybe 12, compute best ratio.
    
    # Let's do a thorough search for D up to n=7 with digits up to, say, 50, to find maximum ratio.
    # We can also use heuristic/evolutionary search for larger digit spaces.
    # But we can also use known optimal digit sets from literature: e.g., D = {0,1,3,7,15,...}? Not sure.
    
    # Let's implement a search for n<=7 that explores combinations efficiently, maybe using pruning.
    
    return []  # placeholder

# We'll implement a proper digit set search and then construction.

def generate_candidate_D(max_digit=80):
    """Search for digit sets D (size up to 7) that maximize log|D-D|/log|D+D|."""
    best = None
    best_r = 0.0
    # We'll iterate over n from 2 to 7.
    for n in range(2, 8):
        # We can generate combinations with min=0, and without loss max digit = ?
        # Use itertools.combinations from range(1, max_digit) plus 0.
        # But combinations are many; we prune by requiring D to be sum-free? Not needed.
        # We can use a greedy approach or random search for larger spaces.
        for comb in itertools.combinations(range(1, max_digit+1), n-1):
            D = (0,) + comb
            # compute sums and diffs
            sums = set()
            diffs = set()
            for x in D:
                for y in D:
                    sums.add(x+y)
                    diffs.add(x-y)
            if len(diffs) > len(sums):
                r = math.log(len(diffs)) / math.log(len(sums))
                if r > best_r:
                    best_r = r
                    best = (n, D)
        # print progress
    return best

# Run search with max_digit maybe 100
# But we need to keep time reasonable.
# We'll embed this inside solve().

def solve():
    start_time = time.time()
    time_limit = 120  # seconds
    # Search for best digit set D within time budget (maybe 10 seconds)
    best_D_info = None
    best_score_overall = -1.0
    # Quick search for n up to 7 with digits up to, say, 60.
    max_digit = 60
    search_deadline = start_time + 15
    for n in range(2, 8):
        # For n=7, combinations(60,6) ~ 50 million, too many. So we need smarter search.
        # We can use random search or beam search.
        if n >= 6:
            # Use random sampling for n>=6.
            break
        for comb in itertools.combinations(range(1, max_digit+1), n-1):
            if time.time() > search_deadline:
                break
            D = (0,) + comb
            sums = set()
            diffs = set()
            for x in D:
                for y in D:
                    sums.add(x+y)
                    diffs.add(x-y)
            if len(diffs) > len(sums):
                r = math.log(len(diffs)) / math.log(len(sums))
                if r > best_score_overall:
                    best_score_overall = r
                    best_D_info = (n, list(D))
    # For larger n, we might try random search.
    if best_D_info is None:
        # fallback to a known good set
        best_D_info = (3, [0,1,3])  # ratio 1.086
    n, D = best_D_info
    # Determine L such that n^L <= 4000 and as large as possible.
    max_L = 1
    while n ** (max_L+1) <= 4000:
        max_L += 1
    L = max_L
    # Choose M large enough to avoid carries: M = 2*max(D) + 1
    M = 2 * max(D) + 1
    # Ensure numbers generated at digit L-1 <= 1e15:
    # Upper bound of numbers: max(D) * (M^L - 1) // (M - 1) < max(D) * M^L / (M-1)
    # we can scale down if needed.
    while True:
        max_val = max(D) * (M**L - 1) // (M - 1)
        if max_val <= 1e15:
            break
        # reduce L
        L -= 1
        if L == 0:
            # can't
            L = 1
            break
    # Build A as all combinations of digits
    A = []
    # Generate all L-tuples of digits (Cartesian product)
    # using recursion/iterative
    for digits in itertools.product(D, repeat=L):
        val = sum(d * (M**i) for i, d in enumerate(digits))
        A.append(val)
    # Compute score to see
    sc = score(A)
    # If we have time, we could try to optimize D further with random perturbations.
    # But we'll return this.
    return sorted(A)


# Test locally (not executed during import often)
if __name__ == "__main__":
    A = solve()
    print(len(A), max(A), min(A))
    print(score(A))
