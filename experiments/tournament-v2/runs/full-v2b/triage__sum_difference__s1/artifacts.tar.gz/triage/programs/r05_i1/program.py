# EVOLVE-BLOCK-START
"""Cubic polynomial set A = {f(1),...,f(N)} with optimized coefficients,
followed by local point swaps. Maximise log|A-A|/log|A+A|."""
import math
import random
import time


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
            if i != j:
                diffs.add(ai - a[j])
                diffs.add(a[j] - ai)
    # include 0 implicitly? 0 is in A-A since a-a=0
    diffs.add(0)
    nd, ns = len(diffs), len(sums)
    if ns <= 1:
        return 0.0, nd, ns, n
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns, n


def _eval_poly(a, b, c, d, N, x0=1):
    return [a * x * x * x + b * x * x + c * x + d
            for x in range(x0, x0 + N)]


def _score_poly(a, b, c, d, N, x0=1):
    vals = _eval_poly(a, b, c, d, N, x0)
    return _score(vals)


def solve():
    deadline = time.time() + 110.0
    random.seed(12345)

    best_A = None
    best_s = -1e18

    # ---- Phase 1: search over cubic coefficients ----
    # Try small-integer coefficients and random ones.
    candidates = []
    # Heuristic seeds: small coefficients produce interesting collision structure.
    for a in range(1, 5):
        for b in range(-6, 7):
            for c in range(-12, 13):
                candidates.append((a, b, c, 0))

    # random integer coefficient candidates
    for _ in range(3000):
        a = random.randint(1, 12)
        b = random.randint(-30, 30)
        c = random.randint(-60, 60)
        d = random.randint(-30, 30)
        candidates.append((a, b, c, d))

    # Also include values not in AP (x0 offset) and even/odd-ish structures.
    N_choices = [30, 40, 50, 60, 70, 80]

    # Evaluate a manageable subset quickly by scoring at moderate N,
    # then refine the best ones.
    scored = []
    count = 0
    for (a, b, c, d) in candidates:
        if time.time() > deadline * 0.45:
            break
        N = 40
        # only need coefficients up to scaling mostly; scale ~ irrelevant to ratio
        v = _eval_poly(a, b, c, d, N)
        s, nd, ns, n = _score(v)
        scored.append((s, a, b, c, d))
        count += 1

    scored.sort(reverse=True)
    top = scored[:40]

    # ---- Phase 2: refine N and scale for top candidates ----
    refine = []
    for (s0, a, b, c, d) in top:
        if time.time() > deadline * 0.7:
            break
        for N in [20, 30, 40, 50, 60, 70]:
            # shift x0 too
            for x0 in [1, 0, -2, 2, 5]:
                v = _eval_poly(a, b, c, d, N, x0)
                s, nd, ns, n = _score(v)
                refine.append((s, a, b, c, d, N, x0))
    refine.sort(reverse=True)

    if refine:
        s, a, b, c, d, N, x0 = refine[0]
        best_A = _eval_poly(a, b, c, d, N, x0)
        best_s = s

    # ---- Phase 3: local search over coefficient + x0 tweaks ----
    if refine:
        cur = list(refine[0])
    else:
        cur = [0.0, 2, -1, 3, 0, 40, 1]
        best_A = _eval_poly(cur[1], cur[2], cur[3], cur[4], cur[5], cur[6])
        best_s = _score(best_A)[0]

    # local coordinate descent on (a,b,c,d,N,x0)
    _, ca, cb, cc, cd, cN, cx0 = cur

    def curset():
        return _eval_poly(ca, cb, cc, cd, cN, cx0)

    cs = _score(curset())[0]
    temp = 0.02
    while time.time() < deadline * 0.9:
        na, nb, nc, nd, nN, nx0 = ca, cb, cc, cd, cN, cx0
        which = random.randrange(6)
        if which == 0:
            na += random.randint(-2, 2)
            if na == 0:
                na = 1
        elif which == 1:
            nb += random.randint(-3, 3)
        elif which == 2:
            nc += random.randint(-4, 4)
        elif which == 3:
            nd += random.randint(-4, 4)
        elif which == 4:
            nN += random.randint(-4, 4)
            nN = max(10, min(120, nN))
        else:
            nx0 += random.randint(-2, 2)
        v = _eval_poly(na, nb, nc, nd, nN, nx0)
        s = _score(v)[0]
        if s > cs or random.random() < temp:
            ca, cb, cc, cd, cN, cx0 = na, nb, nc, nd, nN, nx0
            cs = s
            if s > best_s:
                best_s = s
                best_A = v
        temp *= 0.9999
        if temp < 1e-4:
            temp = 1e-4

    # ---- Phase 4: local swaps / perturbations on the set values ----
    A = list(best_A)
    bs = _score(A)[0]
    while time.time() < deadline:
        cand = A[:]
        op = random.random()
        n = len(cand)
        if op < 0.55 and n > 2:
            # perturb one element
            i = random.randrange(n)
            cand[i] += random.randint(-3, 3)
        elif op < 0.75:
            # tweak two elements jointly (a "shear")
            i = random.randrange(n)
            delta = random.randint(-4, 4)
            cand[i] += delta
            if n > 1:
                j = random.randrange(n)
                cand[j] -= delta
        elif op < 0.9 and n < 200:
            # append a value near the extremes
            lo = min(cand)
            hi = max(cand)
            cand.append(random.randint(lo - 5, hi + 5))
        else:
            # try shifting whole set (shouldn't matter, harmless)
            pass

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)[0]
        if s >= bs:
            bs = s
            A = cand
            if s > best_s:
                best_s = s
                best_A = A[:]

    return sorted(set(best_A))
# EVOLVE-BLOCK-END
