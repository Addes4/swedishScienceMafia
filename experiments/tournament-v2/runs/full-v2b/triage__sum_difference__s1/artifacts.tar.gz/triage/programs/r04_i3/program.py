import math
import random
import time
import itertools


def _score(a):
    """Compute the metric: log|A-A| / log|A+A| + small bonus"""
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    """Generate A via multiplicative modulo scheme and local refinement."""
    random.seed(42)
    best_set = []
    best_score = 0.0
    deadline = time.time() + 110  # leave some margin

    # Parameters to search over
    N_candidates = [100, 150, 200, 250, 300]
    P_candidates = [10**9 + 7, 10**9 + 9, 10**9 + 21, 10**9 + 33, 
                     2*10**9 + 11, 2*10**9 + 63]

    while time.time() < deadline:
        N = random.choice(N_candidates)
        P = random.choice(P_candidates)
        # Choose r as a rational a/b to keep things integer-friendly
        a = random.randint(2, P-2)
        b = random.randint(2, P-2)
        r = a * pow(b, -1, P) % P  # modular inverse
        
        # Generate set
        cur = []
        x = random.randint(1, P-1)  # starting value
        for _ in range(N):
            val = (P * ((x * pow(P, -1, 1) ) % 1))  # frac part
            # Actually better: x mod P, then scale to [0, P-1]
            cur.append(x)
            x = (x * r) % P
        
        # Rescale to avoid huge numbers, keep around 0
        shift = min(cur)
        cur = [v - shift for v in cur]
        
        # Local refinement: reduce sum collisions by nudging points
        for _ in range(200):
            i = random.randrange(len(cur))
            old_val = cur[i]
            # Try small shifts
            best_local = _score(cur)
            best_val = old_val
            for delta in [-2, -1, 0, 1, 2]:
                cur[i] = old_val + delta
                s = _score(cur)
                if s > best_local:
                    best_local = s
                    best_val = cur[i]
            cur[i] = best_val

        s = _score(cur)
        if s > best_score:
            best_score = s
            best_set = cur[:]

    return sorted(set(best_set))
