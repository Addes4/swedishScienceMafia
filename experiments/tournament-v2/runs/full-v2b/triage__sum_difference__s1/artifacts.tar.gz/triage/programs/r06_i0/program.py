import math
import random
import time

def _score_ratio(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    d = len(diffs)
    s = len(sums)
    if s <= 1:
        return 0.0, d, s
    ratio = math.log(d) / math.log(s)
    return ratio, d, s

def _bonus(n):
    return (1 - 1.0 / n) / 100.0 if n > 0 else 0.0

def _sidon(p):
    # Graph of quadratic x -> x^2 mod p is Sidon-like in Z_p x Z_p
    # Map to integers: represent (x, x^2) as x*p + x^2 (base p)
    A = []
    for x in range(p):
        A.append(x * p + (x * x) % p)
    return A

def _eval(A):
    A = list(set(A))
    n = len(A)
    if n < 2:
        return -1e18, n, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = A[i]
        for j in range(n):
            aj = A[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    d = len(diffs)
    s = len(sums)
    if s <= 1:
        return -1e18, n, d, s
    val = math.log(d) / math.log(s) + _bonus(n)
    return val, n, d, s

def _rotate(A, mod, unit, shift):
    return [( (x * unit + shift) % mod ) for x in A]

def _greedy_prune(A, target_size, time_budget, seed):
    rnd = random.Random(seed)
    A = list(set(A))
    if len(A) <= target_size:
        return A
    # Greedy removal: try removing elements that contribute least to difference uniqueness
    # Use approximate scoring via sample
    cur = A[:]
    while len(cur) > target_size:
        best_val = None
        best_idx = -1
        # sample candidate removals
        idxs = list(range(len(cur)))
        rnd.shuffle(idxs)
        sample = idxs[:max(5, len(cur)//4)]
        for idx in sample:
            cand = cur[:idx] + cur[idx+1:]
            val, n, d, s = _eval(cand)
            if best_val is None or val > best_val:
                best_val = val
                best_idx = idx
            if time.time() > time_budget:
                break
        if best_idx == -1:
            best_idx = sample[0]
        cur.pop(best_idx)
    return cur

def _local_improve(A, time_budget, seed):
    rnd = random.Random(seed)
    cur = list(set(A))
    best_val, _, _, _ = _eval(cur)
    best = cur[:]
    steps = 0
    while time.time() < time_budget:
        steps += 1
        cand = cur[:]
        # Try removing an element
        if len(cand) > 3 and rnd.random() < 0.4:
            idx = rnd.randrange(len(cand))
            cand.pop(idx)
        # Try adding an element near existing
        if rnd.random() < 0.5:
            base = rnd.choice(cur)
            delta = rnd.randint(-1000, 1000)
            newval = base + delta
            if newval not in cand:
                cand.append(newval)
        # Try shift an element
        if rnd.random() < 0.5 and cand:
            idx = rnd.randrange(len(cand))
            cand[idx] += rnd.randint(-10, 10)
        cand = list(set(cand))
        val, _, _, _ = _eval(cand)
        if val > best_val:
            best_val = val
            best = cand[:]
            cur = cand[:]
    return best

def solve():
    start = time.time()
    deadline = start + 110
    best_A = []
    best_val = -1e18

    # Try several primes
    primes = [13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]
    configs = []
    for p in primes:
        for unit in range(1, p):
            configs.append((p, unit))
    random.Random(12345).shuffle(configs)

    sidon_cache = {}
    for p, unit in configs[:200]:
        if time.time() > deadline * 0.5:
            break
        if p not in sidon_cache:
            sidon_cache[p] = _sidon(p)
        base = sidon_cache[p]
        mod = p * p
        # shift is 0, already in [0, mod)
        A = _rotate(base, mod, unit, 0)
        # normalize to smaller range by centering
        A = [x - (mod // 2) for x in A]
        val, n, d, s = _eval(A)
        if val > best_val:
            best_val = val
            best_A = A[:]

    # Now try greedy pruning + local improvement on the best
    if best_A:
        target = max(8, len(best_A) * 3 // 4)
        A2 = _greedy_prune(best_A, target, deadline * 0.7, 999)
        val2, _, _, _ = _eval(A2)
        if val2 > best_val:
            best_val = val2
            best_A = A2[:]

    # Random local search from multiple seeds
    seeds = [1, 2, 3, 4, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53]
    for seed in seeds:
        if time.time() > deadline:
            break
        budget = min(deadline, time.time() + max(2, (deadline - time.time()) / 4))
        if best_A:
            start_A = best_A[:]
        else:
            start_A = [random.randint(-1000, 1000) for _ in range(30)]
        improved = _local_improve(start_A, budget, seed)
        val_i, _, _, _ = _eval(improved)
        if val_i > best_val:
            best_val = val_i
            best_A = improved[:]

    # Final cleanup: ensure distinct, within bounds
    result = sorted(set(best_A))
    if len(result) > 4000:
        result = result[:4000]
    result = [int(x) for x in result if abs(x) <= 10**15]
    if len(result) < 2:
        result = [7, 15, 18, 22, -3, -2]
    return result
