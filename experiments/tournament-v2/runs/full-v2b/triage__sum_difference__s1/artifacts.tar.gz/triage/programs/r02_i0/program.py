import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 110

    # Try several base configurations
    base_configs = [
        ([0, 1, 3], 1.2),
        ([0, 1, 4], 1.15),
        ([0, 1, 3, 7], 1.1),
        ([0, 1, 2, 5], 1.2),
        ([0, 1, 6], 1.1),
        ([0, 1, 3], 1.05),
        ([0, 2, 5], 1.15),
    ]

    for base_set, extra in base_configs:
        if time.time() > deadline:
            break
        bmax = max(base_set)
        # geometric base slightly larger than max(B)
        g_min = bmax + extra
        for g in [g_min, g_min + 0.5, g_min + 1.0]:
            if time.time() > deadline:
                break
            for n in range(8, 24):
                if time.time() > deadline:
                    break
                # A = base union {round(g^i)}
                A = set(base_set)
                for i in range(n):
                    try:
                        val = int(round(g ** i))
                    except (OverflowError, ValueError):
                        break
                    if abs(val) > 10**15:
                        break
                    A.add(val)
                if len(A) < 2:
                    continue
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = sorted(A)

    # Local search refining the geometric exponents and base elements
    if best is None:
        best = [0, 1, 3, 5, 9, 17, 33, 65]
        best_score = _score(best)

    # Represent candidate as list of integers; mutate individual elements
    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.5:
            # perturb an existing element
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2])
        elif op < 0.8:
            # add a new element (geometric-ish)
            mx = max(abs(x) for x in cand)
            nv = int(mx * (1 + random.random()))
            if abs(nv) <= 10**15:
                cand.append(nv)
        else:
            # remove an element
            if len(cand) > 3:
                idx = random.randrange(len(cand))
                cand = cand[:idx] + cand[idx + 1:]

        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if any(abs(x) > 10**15 for x in cand):
            continue
        s = _score(cand)
        if s >= cur_score or random.random() < 0.05:
            cur, cur_score = cand, s
        if s > best_score:
            best, best_score = cand[:], s
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))


if __name__ == "__main__":
    A = solve()
    print(len(A), _score(A))
