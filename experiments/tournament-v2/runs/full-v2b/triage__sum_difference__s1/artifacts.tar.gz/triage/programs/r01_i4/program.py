import math
import random
import time


def score_set(seeds, a_list):
    """Convert binary mask to set and compute objective score."""
    a = set()
    for b in seeds:
        if b == 1:
            a_list_sorted = sorted(a_list)
            a.add(a_list_sorted[b])
    a = list(a)
    if len(a) < 2:
        return 0.0

    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}

    log_diffs = math.log(len(diffs))
    log_sums = math.log(len(sums))
    bonus = (1 - 1 / len(a)) / 100
    return log_diffs / log_sums + bonus


def convert_mask_to_set(mask, pool):
    """Convert binary mask to set."""
    a = {sorted(pool)[i] for i, b in enumerate(mask) if b == 1}
    return a


def pool_generator(num, start=10):
    """Generate candidate pool with exponential spacing."""
    pool = [start * (2 ** i) for i in range(num)]
    # Extend the pool with additional values to widen the range
    for j in range(num // 3):
        pool.append(pool[-1] * 10 + j)
    return pool


def solve():
    """Return a list of distinct integers A that maximize the objective."""
    deadline = time.time() + 120
    pool = pool_generator(120, 5)
    n_pool = len(pool)
    
    best_score = 0
    best_set = []
    
    def score(a):
        return score_set([1] * len(a), a)

    def evaluate(mask):
        s = score(mask)
        if s > best_score:
            best_score = s
        return s
    
    def get_unique_mask(mask):
        candidate = convert_mask_to_set(mask, pool)
        if len(candidate) < 2:
            return None
        key = tuple(sorted(candidate))
        return key
    
    pop_size = 300
    pop = []
    seen_keys = {}
    
    age_limit = 5000
    
    for gen in range(1000):
        timeout = deadline - time.time()
        if timeout <= 0:
            break
        time.sleep(timeout / 10)
        if gen < 50:
            gen_size = 100
        elif gen < 100:
            gen_size = 200
        else:
            gen_size = 300
            
        for _ in range(min(gen_size, pop_size)):
            mask = [random.randint(0, 1) for _ in range(n_pool)]
            candidate = convert_mask_to_set(mask, pool)
            if len(candidate) < 2:
                continue
            key = tuple(sorted(candidate))
            if key in seen_keys:
                pop.pop()
                seen_keys.pop(key)
            else:
                pop.append(mask)
                seen_keys[key] = True

        top_k = sorted(pop, key=lambda m: score(m), reverse=True)[:int(pop_size * 0.8)]

        for i in range(min(pop_size, pop_size + 10)):
            age = len(seen_keys) % age_limit
            if age == 0:
                mask = [random.randint(0, 1) for _ in range(n_pool)]
            else:
                mask = pop[i % min(len(pop), pop_size)]
            local_pop = [mask[:]]
            local_best_score = score(mask)
            s = 0
            bd = deadline - time.time()
            while bd > 0 and len(local_pop) < 20:
                if random.random() < 0.01:
                    s = max(sum(x - y for x in range(n_pool)), sum(x - y for x in range(n_pool)))
                for j in range(len(local_pop)):
                    cand = local_pop[j]
                    score_s = score(cand)
                    if score_s > local_best_score:
                        local_best_score = score_s
                        local_best = cand[:]
                if random.random() < 0.1:
                    i_pick = random.randint(0, min(len(pool) - 1, 100))
                    cand = convert_mask_to_set(local_best, pool)
                    cand_list = list(cand)
                    idx = random.randint(0, len(cand_list) - 1)
                    cand_list[idx] = random.choice([x for x in pool if x not in cand_list])
                bd -= 0.01
                if bd <= 0:
                    break
            pop.append(local_best)
    
    best_mask = max(pop, key=lambda m: score(m)) if pop else [1]*n_pool
    return list(convert_mask_to_set(best_mask, pool))


if __name__ == "__main__":
    print(solve())
