"""Strategy: Union of arithmetic progression base with small step and tail offsets with large multiplier M.
Differences become ~O(|A|·M) while sums stay clustered in ~O(|A|) intervals."""
import math
import random
import time

def score(A):
    A = list(set(A))
    if len(A) < 2:
        return 0.0
    diffs = set(x - y for x in A for y in A)
    sums = set(x + y for x in A for y in A)
    if len(sums) == 0:
        return 0.0
    bonus = (1 - 1 / len(A)) / 100
    return math.log(len(diffs)) / math.log(len(sums)) + bonus

def solve():
    """Main solver returning A as a list of distinct integers."""
    random.seed(42)
    baseline_score = -1
    baseline_set = None
    
    base_len = 400
    base_step = 1
    tail_fname = base_len * 4
    
    # Grid search parameters
    for L in range(200, 1600, 300):
        for M in [10**8, 5*10**8, 1.5*10**9, 3*10**9]:
            for ratio in [0.4, 0.45, 0.5, 0.55]:
                A = []
                base_vals = list(range(0, L, base_step))
                tail_multiplier = M
                
                # Assign elements to base-only layer, or base + tail
                for idx, val in enumerate(base_vals):
                    if idx % 3 == 0:
                        A.append(val)
                    else:
                        tail_offset = random.randint(1, 5)
                        if random.random() < ratio:
                            A.append(val)
                        else:
                            A.append(val + tail_multiplier * tail_offset)
                
                A = sorted(set(A))
                max_val = max(A) if A else 0
                if len(A) > 1 and abs(max_val) <= 1e15:
                    s = score(A)
                    if s > baseline_score:
                        baseline_score = s
                        baseline_set = A[:]
    
    if baseline_set is None or score(baseline_set) < 0.0:
        baseline_set = list(range(0, 2000))
    
    baseline_candidates = [baseline_set[:]]
    
    # Local search and random repairs
    random.shuffle(baseline_candidates)
    
    for A in baseline_candidates:
        cur_score = score(A)
        A = sorted(list(set(A)))
        if cur_score > 0.0:
            deadline = time.time() + 20
            count = 0
            while time.time() < deadline and count < 3000:
                i = random.randrange(min(50, len(A)))
                base_val = A[i]
                perturbed = sorted(list(set([x for x in [base_val - 1, base_val, base_val + 1] if x not in set(A)][:1])))
                if not perturbed:
                    perturbed = [base_val + random.randint(1, 20)]
                
                s = score(perturbed)
                if s >= cur_score and score(perturbed) > 0.0:
                    cur = list(A)
                    cur[i] = perturbed[0]
                    if score(cur) > cur_score:
                        cur_score = score(cur)
    best_A = sorted(list(set(best_A)))
    
    return best_A
