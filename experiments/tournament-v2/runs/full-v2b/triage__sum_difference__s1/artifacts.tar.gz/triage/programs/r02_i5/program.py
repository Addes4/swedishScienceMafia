import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls < 2:
        ls = 2
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _eval_seq(seq):
    a = sorted(set(seq))
    return _score(a), a


def _make(C, d, N, shifts):
    a = []
    for i in range(1, N + 1):
        v = int(math.floor(C * (i ** d)))
        v += shifts[i % len(shifts)]
        a.append(v)
    return a


def _local_search(a, best_score, best, deadline):
    a = a[:]
    n = len(a)
    while time.time() < deadline:
        cand = a[:]
        op = random.random()
        if op < 0.6:
            i = random.randrange(n)
            step = random.choice([-2, -1, 1, 2])
            cand[i] += step
        elif op < 0.8:
            i = random.randrange(n)
            cand[i] += random.randint(-30, 30)
        elif op < 0.9:
            cand.append(cand[-1] + random.randint(1, 40))
        else:
            if n > 3:
                i = random.randrange(n)
                cand.pop(i)
        cset = sorted(set(cand))
        if len(cset) < 2:
            continue
        s = _score(cset)
        if s > best_score:
            best_score = s
            best = cset
            a = cand
        elif s > best_score - 0.005:
            a = cand
    return best, best_score


def solve():
    random.seed(12345)
    deadline = time.time() + 118

    best = None
    best_score = -1.0

    # Candidate parameter grid
    param_sets = []
    Ns = [20, 30, 40, 60, 100, 150]
    ds = [1.4, 1.5, 1.6, 1.7, 1.8, 2.0]
    Cs = [1.0, 1.5, 2.0, 2.5, 3.0]

    for N in Ns:
        for d in ds:
            for C in Cs:
                param_sets.append((C, d, N))

    # For each parameter combo, try a few random-shift variants
    evaluated = []
    for (C, d, N) in param_sets:
        if time.time() > deadline - 5:
            break
        for trial in range(3):
            nsh = random.choice([1, 2, 3])
            shifts = [random.randint(-N, N) for _ in range(nsh)]
            seq = _make(C, d, N, shifts)
            s, a = _eval_seq(seq)
            evaluated.append((s, a, C, d, N, shifts))
            if s > best_score:
                best_score = s
                best = a

    evaluated.sort(key=lambda x: -x[0])

    # Refine top candidates with local search
    top = evaluated[:8]
    for (s0, a0, C, d, N, shifts) in top:
        if time.time() > deadline - 10:
            break
        b, bs = _local_search(a0, best_score, best, deadline - 5)
        if bs > best_score:
            best_score = bs
            best = b

    # Final polish of the overall best with remaining time
    if best is not None:
        best, best_score = _local_search(best, best_score, best, deadline)

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return list(best)
