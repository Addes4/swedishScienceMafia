# EVOLVE-BLOCK-START
"""Union of arithmetic progressions with genetic optimization for max log|A-A|/log|A+A|."""
import math
import random
import time
from itertools import product

def compute_score(params):
    """Compute score for a set of arithmetic progression parameters."""
    if not params:
        return 0.0
    
    # Parameters: each entry is [start, step, length]
    A = set()
    for pr in params:
        start, step, length = pr
        A.update(start + i * step for i in range(length))
    
    n = len(A)
    if n < 3:
        return 0.0
    
    # Fast difference and sum set computation using sets
    diffs = set()
    sums = set()
    
    # Convert to list for enumeration
    A_list = list(A)
    
    for i, x in enumerate(A_list):
        diffs.add(0)
        sums.add(2*x)
        for j, y in enumerate(A_list[:i+1]):
            diffs.add(x - y)
            sums.add(x + y)
        # Use slicing optimization
        for y in range(i + 1, len(A_list)):
            diffs.add(A_list[i] - A_list[y])
            sums.add(A_list[i] + A_list[y])
    
    # Calculate score
    log_diff = math.log(len(diffs) if len(diffs) > 1 else 2)
    log_sum = math.log(len(sums) if len(sums) > 1 else 2)
    
    if log_sum <= 0:
        return 0.0
    
    score = log_diff / log_sum + (1 - 1 / n) / 100
    return score

def generate_initial_pop(size, num_progs=3):
    """Generate initial population of progression parameter sets."""
    pop = []
    for _ in range(size):
        params = []
        primes = [10**9 + 7, 10**9 + 9, 10**9 + 21, 10**9 + 33]
        p = random.choice(primes)
        
        for _ in range(num_progs):
            # Step sizes from different progression classes
            step = random.choice([1, 2, 3, 5, 7, 11, 13, 17, 19])
            start = random.randint(-1000000, 1000000)
            length = random.randint(10, 50)
            params.append([start, step, length])
        
        pop.append(params)
    return pop

def crossover(parent1, parent2):
    """Perform block-wise crossover between two parents."""
    params1 = [tuple(p) for p in parent1]
    params2 = [tuple(p) for p in parent2]
    
    # Try segment-based crossover
    crossover_point = random.randint(1, len(params1))
    if crossover_point < len(params1) and crossover_point < len(params2):
        child = params1[:crossover_point] + params2[crossover_point:]
    else:
        child = params1[:]
    
    # Random mutation
    for i in range(len(child)):
        if random.random() < 0.2:
            child[i] = list(child[i])
            child[i][0] = random.randint(-2000000, 2000000)  # start
            child[i][1] = random.choice([1, 2, 3, 5, 7, 11, 13, 17, 19, 31, 41])  # step
            child[i][2] = random.randint(8, 60)  # length
    
    return child

def mutate(params):
    """Mutate a single parameter set."""
    for i in range(len(params)):
        if random.random() < 0.4:
            params[i] = list(params[i])
            params[i][0] = random.randint(-3000000, 3000000)
            params[i][1] = random.choice([1, 2, 3, 4, 5, 7, 8, 9, 11, 13, 17, 19, 23, 29])
            params[i][2] = random.randint(10, 70)
    
    # Occasionally add/remove progression
    if random.random() < 0.1 and len(params) < 6:
        p = [0]
        params.append(p)
    elif random.random() < 0.1 and len(params) > 2:
        idx = random.randint(0, len(params) - 1)
        params.pop(idx)
    
    return params

def evolve(population, generations=200):
    """Evolve population using genetic algorithm."""
    best_params = None
    best_score = -1e10
    best_score_time = time.time() + 120
    
    for gen in range(generations):
        if time.time() >= best_score_time:
            break
        
        # Selection: choose parents proportional to score
        scores = [compute_score(p) for p in population]
        
        # Sort and select top performers
        combined = list(zip(scores, population, range(len(population))))
        combined.sort(key=lambda x: x[0], reverse=True)
        
        # Tournament selection
        parents = []
        for _ in range(min(10, len(population))):
            idx = random.randint(0, len(populated) - 1)
            parents.append(population[idx])
        
        for parent in random.choice(combined[:10][:5]):
            parents.append(parent)
        
        # Variations
        population = []
        
        while len(population) < min(len(population) * 2, 60):
            choice = random.random()
            if choice < 0.6:
                p1, p2 = random.choice(combined), random.choice(combined)
                child = crossover(p1, p2)
                child = mutate(child)
            else:
                child = random.choice(population)
                child = mutate(child)
            
            population.append(child)
        
        # Evaluate and keep best
        new_scores = [compute_score(p) for p in population]
        
        # Update best
        for i, p in enumerate(population):
            if new_scores[i] > best_score:
                best_score = new_scores[i]
                best_params = p.copy()
        
        population = population[new_scores.index(max(new_scores)):].extend(population[10:])
        population = population[:len(population)//2]
    
    return best_params if best_params is not None else population[0]

def optimize_with_push():
    """Additional optimization passes."""
    params = []
    
    # Try classic constructions
    # Vinogradov's construction: unions of APs with different moduli
    base_constructions = [
        [[0, 1, 50], [0, 3, 30], [0, 5, 20]],
        [[0, 1, 40], [1, 2, 35], [2, 3, 30]],
        [[0, 1, 60], [0, 2, 40], [0, 3, 30]],
    ]
    
    for bc in base_constructions:
        score = compute_score(bc)
        if score > 1.2:
            params.append(bc)
    
    # Random search with smart structure
    for iteration in range(200):
        num_progs = random.randint(3, 6)
        params_candidate = []
        
        dict_steps = {1: [0, 1], 2: [0, 1], 3: [0, 1], 5: [0, 1]}
        for _ in range(num_progs):
            step_base = random.choice([1, 2, 3, 5, 7, 11, 13, 17, 19])
            step = step_base
            if step < 3:
                step += 1
            start = random.randint(-500000, 500000)
            length = random.randint(20, 80)
            params_candidate.append([start, step, length])
        
        score = compute_score(params_candidate)
        if score > max([compute_score(p) for p in params]) if params else 0:
            params.append(params_candidate)
    
    return params[0] if params else None

def solve():
    """Return a list of distinct integers A making |A-A| large and |A+A| small."""
    random.seed(42)
    start_time = time.time()
    deadline = start_time + 118
    
    # Phase 1: Evolutionary search
    pop_size = 50
    population = generate_initial_pop(pop_size)
    
    # Evaluate initial population
    for p in population:
        pass  # scored internally
    
    while time.time() < deadline - 10:
        # Perform crossover and mutation with scoring
        new_generation = []
        
        # Selection pressure
        scores = []
        for p in population:
            s = compute_score(p)
            scores.append(s)
        
        # Keep best
        best_idx = scores.index(max(scores))
        new_generation.append(population[best_idx].copy())
        
        # Generate offspring
        while len(new_generation) < 60:
            p1 = random.choice(population)
            p2 = random.choice(population)
            
            if random.random() < 0.7:
                child = crossover(p1, p2)
            else:
                child = mutate(p1)
            
            child = mutate(child)
            new_generation.append(child)
        
        # Evaluate new generation
        for p in new_generation:
            s = compute_score(p)
        
        # Replace oldest
        population = new_generation[:pop_size]
    
    # Phase 2: Local optimization
    final_params = evolve(population, generations=50)
    
    # Phase 3: Tweak and finalize
    best_params = [final_params]
    
    # Additional structured trials
    # Try specific step patterns known to work well
    patterns = [
        [[0, 1, 40], [0, 2, 30], [0, 3, 20]],
        [[0, 1, 50], [1, 2, 40], [2, 3, 30]],
        [[0, 1, 35], [0, 2, 45], [0, 3, 55]],
        [[0, 1, 60], [1, 3, 40], [2, 5, 25]],
        [[0, 1, 45], [0, 2, 35], [1, 4, 25]],
    ]
    
    for pattern in patterns:
        s = compute_score(pattern)
        best_params.append(pattern)
    
    # Select best
    final_params = max(best_params, key=compute_score)
    
    # Expand and refine if possible
    if time.time() < deadline:
        expanded_params = []
        for pr in final_params:
            expanded_params.append([pr[0], pr[1], pr[2] * (1 + random.randint(0, 5)//10)])
        
        final_params = expanded_params
    
    # Finalize set
    A = set()
    for pr in final_params:
        start, step, length = pr
        for i in range(length):
            A.add(start + i * step)
    
    A = list(A)
    
    return sorted(A)
# EVOLVE-BLOCK-END
