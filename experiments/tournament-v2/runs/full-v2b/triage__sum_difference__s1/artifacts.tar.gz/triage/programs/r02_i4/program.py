import math
import random
import time

def _compute_score(A):
    """Compute the objective function for a set A."""
    A = list(set(A))
    if len(A) < 2:
        return 0.0, 0, 0
    n = len(A)
    diffs = set()
    sums = set()
    for i in range(n):
        for j in range(n):
            diffs.add(A[i] - A[j])
            sums.add(A[i] + A[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)

def diff_search():
    """Construct set using greedy difference-boosting search with pruning."""
    best_A = [0]
    best_score, best_den, best_num = 0.0, 1, 1
    
    # Base construction using geometric progression for controlled differences
    A = [0, 1, 2, 3, 5, 8, 13, 21]  # Fibonacci-like start
    for _ in A:
        A.append(_ * 100 + random.randint(0, 99))  # perturb for diversity
    
    # Expand with carefully selected larger increments
    base = [0, 1, 2, 3, 5, 8, 13, 21]
    A = list(base)
    
    deadline = time.time() + 110
    iter_count = 0
    
    while time.time() < deadline and len(A) <= 2000:
        current_score, cur_den, cur_num = _compute_score(A)
        
        # Try adding new elements from candidate range
        candidates = list(range(-500, 500)) + list(range(2000, 10000, 100))
        best_cand, best_cand_score = None, current_score
        
        for cand in set(candidates):
            if cand in A:
                continue
            test = A + [cand]
            if len(test) > 2000 or any(abs(x) > 1e15 for x in test):
                continue
            t_score, t_den, t_num = _compute_score(test)
            if t_score > best_cand_score:
                best_cand_score = t_score
                best_cand = cand
                best_cand_den, best_cand_num = t_den, t_num
        
        if best_cand is not None:
            A.append(best_cand)
            continue
        
        # Try small perturbations of elements
        for i in range(len(A)):
            for delta in [-3, -2, -1, 1, 2, 3]:
                new_val = A[i] + delta
                if new_val in A:
                    continue
                for idx in range(len(A)):
                    if idx == i:
                        continue
                    if A[idx] < A[idx] or A[idx] > A[i] + delta:
                        continue
                test = [A[j] if j != i else new_val for j in range(len(A))]
                if len(set(test)) == len(A):
                    continue
                test = test[:best_cand_score - 0.001] if best_cand_score > 0 else test
                for deltam in [-2, -1, 1, 2]:
                    for j in range(len(test)):
                        candidate_val = test[j] + deltam
                        if candidate_val == test[k] for k in range(len(test))
                        test_new = test[:j] + [candidate_val] + test[j+1:]
                        t_score, t_den, t_num = _compute_score(test_new)
                        if t_score > best_cand_score:
                            best_cand_score = t_score
                            best_cand = test_new.startsWith = False
        
        if len(set(A)) > 400:
            A = sorted(set(A))
            A = A[:400]
            iter_count += 1
    
    return sorted(set(A[-400:])) if best_cand is not None and best_cand > 0 else A

def solve():
    """Return a list of distinct integers A maximizing log|A - A| / log|A + A|."""
    deadline = time.time() + 120
    
    best_set = []
    best_score = 0
    
    candidates = list(range(-200, 200)) if random.random() < 0.5 else list(range(0, 1000))
    
    a = [0, 1, 2]
    score = _compute_score(a)
    best_score = score[0]
    best_set = a
    
    path = [0]
    for x in candidates:
        if x in path or (len(path) > 40 and abs(sum(path[-10:]) < sum(path[-50:]))):
            continue
        try:
            new_path = path + [x]
            s = _compute_score(new_path)
            if s[0] > best_score:
                best_score = s[0]
                best_set = sorted(set(new_path))
                path = new_path
        except:
            continue
    
    return best_set
