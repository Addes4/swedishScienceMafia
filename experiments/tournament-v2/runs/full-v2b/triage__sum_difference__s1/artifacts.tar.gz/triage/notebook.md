# Research notebook: sum_difference

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.887449.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Directly construct a set using known near-optimal theoretical families, like a truncated "Mian-Chowla" sequence or a greedy construction that minimizes new sums | 0.70 | favourite | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra (swapped) | not_better | 0.887449 |
| 0 | Use a Sidon-set-like construction: build A from a geometric progression (e.g., powers of 2 or a carefully chosen base) multiplied by a small integer set, to kee | 0.58 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.887449 |
| 5 | Instead of local random changes, compute the marginal contribution of each element to /A-A/ and /A+A/, and greedily add/remove elements that improve the ratio,  | 0.55 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 1 | Implement a simulated annealing variant with a temperature that decays slowly, allowing temporary score drops, and use a more expressive neighborhood (add/remov | 0.53 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 4 | Use a genetic algorithm with crossover: represent sets as bitstrings over a pool of candidate integers, evolve populations, and mix with local tweaking to escap | 0.46 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 2 | Precompute candidate elements from a random modular arithmetic progression modulo a large prime, then run local search only on those preselected modular residue | 0.39 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 1: **0.887449** (spent $0.01)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Exploit the fact that log/A-A/ / log/A+A/ benefits from A being “almost” a set with small doubling but with a few outlier elements that create many new differen | 0.47 | favourite | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra (swapped) | not_better | 0.887449 |
| 2 | Start with a known good infinite family (like a shifted version of a Bose–Chowla Sidon set or a Singer-set-based construction) and then “prune and grow”: greedi | 0.34 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 5 | Take A = { a_i = floor( C * i^d ) + random_shift } for i = 1..N, where C and d are tuned so that differences grow roughly like a power law, guaranteeing a large | 0.31 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 0 | Build A as a union of two carefully scaled sets: a small “base” set B (e.g., {0,1,3}) and a large geometric progression {g^i} for a base g slightly larger than  | 0.28 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 1 | Use a “product construction” over a finite field: generate A as the set of evaluations of a low-degree polynomial at many points in GF(p). Choose the polynomial | 0.26 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 4 | Formulate the problem as maximizing the difference set size while constraining the sumset size to be below a target, and use an integer linear programming (or S | 0.19 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 2: **0.887449** (spent $0.03)

## Round 3

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Pre-construct a set that is exactly the image of a degree-2 polynomial over a finite field GF(p) with p chosen so the set size is near 4000. Sumset size is boun | 0.37 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 2 | Use a “difference-injecting” greedy algorithm: start from a very small sum set (e.g., a k-term arithmetic progression) and repeatedly add the integer that maxim | 0.27 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.881511 |
| 4 | Construct A as a random subset of a “Minkowski sum” of two carefully chosen small sets B and C (e.g., B = {0,1,4}, C = scaled geometric progression), then apply | 0.12 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 3 | Represent A as a union of several arithmetic progressions with different step sizes that share a small set of residues modulo a large prime. The differences wit | 0.12 | middle | Qwen/Qwen3.5-9B:together (swapped) | invalid | 0.000000 |
| 5 | Dynamically generate A by solving a continuous relaxation: treat elements as real variables, model /A − A/ and /A + A/ via pairwise distance/sum histograms appr | 0.05 | long_shot | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | invalid | 0.000000 |
| 1 | Build A as a “two-scale” set: a dense block of consecutive integers (size ~2000) to make many differences, plus an interleaved geometric progression with base b | 0.04 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 3: **0.887449** (spent $0.06)

## Round 4

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Generate A by taking the set of all products p * q where p and q are primes from disjoint intervals [P1, P2] and [Q1, Q2], chosen so that /A/ ≈ 4000. The multip | 0.05 | favourite | Qwen/Qwen3.5-9B:together (swapped) | not_better | 0.809852 |
| 3 | Represent A as the orbit of a single integer under repeated multiplication by a fixed rational number r modulo a large prime P, i.e., A = { floor(P * frac(r^i)) | 0.05 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 2 | Start with a greedy Sidon set (all pairwise sums distinct) within a bounded range, then deliberately add a small number of carefully chosen “duplicate sum break | 0.03 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 5 | Use an evolutionary strategy that operates directly on the sorted list of elements: encode A as a real-valued vector of increments (gaps between consecutive sor | 0.02 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 0 | Construct A as the union of a “base” arithmetic progression of length L with small step d, and a “tail” set formed by adding large random multiples of a factor  | 0.00 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 4 | Build A as a random subset of the union of two disjoint geometric progressions with bases b1 and b2 that are multiplicatively independent (log b1 / log b2 irrat | -0.08 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 4: **0.887449** (spent $0.07)

## Round 5

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Use a spectral approach: build a large initial pool of integers, compute the adjacency matrix of their pairwise sums, and use the leading eigenvector of the sum | 0.18 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.805269 |
| 2 | Represent A as a union of a few "frequency-hopping" sequences: for each of several primes p_j, include numbers of the form f_j(k) mod p_j + M_j for k in a range | 0.14 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | no_code |  |
| 1 | Define A as the set of values of a cubic polynomial f(x)=ax^3+bx^2+cx+d evaluated at x=1..N. For suitably chosen coefficients, the sumset size is bounded by a p | 0.12 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.862925 |
| 4 | Construct A as the Cartesian product of two sets B and C of sizes roughly sqrt(4000) each, but then apply a random linear map x → αx + β (mod M) to "mix" the pr | 0.10 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.789473 |
| 5 | Model the problem as finding a set A inside a large finite cyclic group Z_M that maximizes edge density in the difference graph while minimizing it in the sum g | 0.07 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 0 | Start with a large set constructed by taking all integers in a few long arithmetic progressions with distinct steps that are pairwise incommensurable (e.g., pri | 0.04 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 5: **0.887449** (spent $0.09)

## Round 6

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Form A as the union of a few shifted copies of a “base set” B that has very small doubling constant (e.g., a generalized arithmetic progression of dimension 2). | 0.30 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.885055 |
| 2 | Build A as a “multiscale arithmetic progression” where elements are of the form a_i = floor(i*s + r_i*M) for i in 1..N, with M being a large multiplier, s a sma | 0.10 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | no_code |  |
| 0 | Start from a finite-field Sidon-like set (e.g., graph of a quadratic polynomial over GF(p)) and apply a series of random “rotations” in Z/nZ by multiplying by a | 0.08 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 5 | Use a “difference-completion” strategy: start with a target count D of differences and use the Lovász local lemma or a randomized greedy algorithm to construct  | 0.02 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 3 | Treat the problem as maximizing the min-entropy of the difference multiset while minimizing the collision entropy of the sum multiset, and use a greedy “entropy | -0.03 | long_shot | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra (swapped) | not_better | 0.788670 |
| 1 | Embed the problem in a continuous relaxation where each element is a probability cloud (a Gaussian) in R, define a differentiable proxy for /A-A/ and /A+A/ via  | -0.17 | long_shot | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra (swapped) | invalid | 0.000000 |

Best after round 6: **0.887449** (spent $0.15)

