import numpy as np


def priority(item, bins):
    # Best-fit: prefer the bin that leaves the smallest remaining capacity.
    # Add a tiny bonus for nearly-filled bins to break ties toward tighter packing.
    remaining = bins - item

    # Primary: smaller remaining capacity is better, so score is negative remaining.
    # Secondary tie-break: slightly prefer bins that already have some load
    # (remaining < 100) over unused bins, to avoid opening new bins unnecessarily.
    used = bins < 100

    # Scale the used-bin bonus so it only breaks ties, never overrides fit quality.
    # Max capacity is 100, so remaining ranges 0..99. A 1e-3 bonus is safe.
    return -remaining + 0.001 * used
