import numpy as np


class _State:
    def __init__(self):
        self.tick = 0
        self.last_used = {}

    def reset(self):
        self.tick = 0
        self.last_used.clear()


_state = _State()


def priority(item, bins):
    """Best fit with a deterministic old-bin tie-break for equal residual capacity."""
    bins = np.asarray(bins)

    # Primary: best fit.  Smaller remaining space after insertion is better,
    # so use negative residual space.
    residual = bins - item
    scores = -residual.astype(np.float64)

    # Secondary: among equally tight bins, prefer the least-recently used bin.
    # This is added as a tiny score perturbation so it does not change the
    # main best-fit ordering.
    _state.tick += 1
    t = _state.tick

    # Only perturb bins that are not brand new.  New bins are already handled
    # naturally by best fit when they are the tight fit.
    # The perturbation is much smaller than 1, so it only breaks exact ties.
    perturb = np.zeros(len(bins), dtype=np.float64)
    for i, cap in enumerate(bins):
        last = _state.last_used.get(int(cap), 0)
        # Smaller last-used tick should score slightly higher.
        perturb[i] = 1.0 / (1.0 + (t - last))

    scores += 1e-9 * perturb

    # Record use of the selected bin.  The winning index is deterministic:
    # highest score, first on ties.
    best = int(np.argmax(scores))
    cap = int(bins[best])
    _state.last_used[cap] = t

    return scores
