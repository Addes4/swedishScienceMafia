"""Online bin choice: prefer tight fits in non-empty bins, defer empty bins."""

import numpy as np


def priority(item, bins):
    """Score bins so the item goes to the tightest non-empty fit, else an empty bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of fitting bins.
    """
    rem = np.asarray(bins, dtype=np.int64)
    # Non-empty bins have remaining capacity < 100.
    nonempty = rem < 100
    # For non-empty bins: tighter fit -> smaller residual capacity -> higher score.
    # Empty bins get a large negative bias so they are chosen only if no non-empty fit.
    score = np.where(nonempty, -rem, -(rem + 10000))
    return score.astype(np.int64)
