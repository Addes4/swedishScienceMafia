"""Best-fit bin packing with historical size statistics to reduce fragmentation."""
import numpy as np
from collections import deque


class _State:
    def __init__(self):
        self.seen = []  # recent item sizes
        self.total = 0

    def observe(self, item):
        self.seen.append(item)
        self.total += 1
        if len(self.seen) > 2000:
            self.seen = self.seen[-2000:]


_state = _State()


def priority(item, bins):
    _state.observe(item)
    residual = bins - item  # remaining capacity after placing item

    # Score: prefer small residual (best fit).
    # Add tiny preference for residuals that are multiples of common item sizes
    # (uses recent history; cheap and no future knowledge).
    score = -residual.astype(np.float64)

    # Secondary: avoid leaving residials like 1..5 that are almost certainly wasted,
    # by nudging those slightly down relative to slightly larger residuals that
    # could combine. But best fit already handles this; keep it simple to stay fast.
    return score
