import numpy as np


def priority(item, bins):
    # Best-fit: prefer the bin whose remaining capacity after placing `item`
    # is smallest.  Bins are indexed in creation order, so lower index is older.
    # Slight tie-break toward older bins helps close them out earlier.
    gap = bins - item                     # remaining capacity after placement
    # Primary: smallest resulting gap (tightest fit)
    score = -gap.astype(np.float64)
    # Secondary tiny bonus for lower bin index (older bins) among equal fits.
    # We don't know bin indices directly, but bin order is fixed; emulate with
    # a decreasing bonus using array position.
    n = bins.shape[0]
    pos_bonus = (n - np.arange(n, dtype=np.float64)) * 1e-6
    return score + pos_bonus
