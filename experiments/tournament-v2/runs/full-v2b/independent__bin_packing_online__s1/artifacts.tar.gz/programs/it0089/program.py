import numpy as np

# Tunable priority weights.
# Higher = prefer tighter fit. Exact fit gets a dominant bonus.
EXACT_BONUS = 10_000
NEW_BIN_PENALTY = 0.40   # discourage opening brand-new bins, but not absolutely
RESIDUAL_WEIGHT = 1.0    # prefer smallest leftover capacity (best fit)
TINY_RESIDUAL_PENALTY = 0.0


def priority(item, bins):
    """Best-fit with exact-fit dominance and a mild new-bin penalty.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Returns a per-bin score; the item goes to the highest score (first wins ties).
    """
    b = bins.astype(np.float64)
    residual = b - item            # >= 0 for all shown bins

    # Base: strongly prefer the smallest residual (tightest fit).
    score = -RESIDUAL_WEIGHT * residual

    # Exact fit gets a dominant bonus.
    score += EXACT_BONUS * (residual == 0)

    # Mildly discourage opening brand-new bins to reduce bin count / fragmentation.
    score -= NEW_BIN_PENALTY * (b >= 100)

    # Prefer not to leave a tiny, likely-unusable residual (unless exact):
    # slight penalty when residual is very small but nonzero.
    if TINY_RESIDUAL_PENALTY:
        score -= TINY_RESIDUAL_PENALTY * ((residual > 0) & (residual < 3))

    return score
