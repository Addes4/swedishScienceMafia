import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.hist = [0] * 101


_state = _State()


def priority(item, bins):
    """Rank bins by a stateful best-fit rule that avoids wasting large residual gaps."""
    st = _state
    st.calls += 1
    st.hist[item] += 1

    # Remaining capacity after placing the item. Lower is tighter/better.
    rem = bins - item

    # Prefer tighter fits, but slightly discourage filling a bin exactly if it is
    # still early; this leaves some bins with small residue for possible future fits.
    # The penalty is tiny and mainly breaks near-ties toward less wasteful placements.
    score = -rem.astype(np.float64)

    # Small bonus for creating a small but nonzero residue versus zero residue.
    # Zero residue is usually good, but over-committing early can hurt later.
    # This is intentionally very mild.
    score += 0.02 * (rem == 0)

    # Mildly prefer bins that are not perfectly empty when the item is small-to-medium,
    # because keeping completely empty bins intact helps absorb future large items.
    if item <= 60:
        score -= 0.01 * (bins == 100)

    return score
