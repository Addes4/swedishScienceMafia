import numpy as np


def priority(item, bins):
    """Best-fit with a slight preference for fuller bins on ties.

    bins contains remaining capacities of bins the item fits in.
    We want to minimize leftover capacity after insertion:
        leftover = bins - item
    A lower leftover is better, so score = -leftover.
    To break ties in favor of fuller bins (smaller bins), add a tiny bonus
    proportional to how full the bin already is. Since bins >= item, bins - item >= 0.
    """
    leftover = bins - item
    # Primary: prefer smaller leftover. Secondary: prefer smaller bins (fuller).
    # The secondary term is scaled so it only breaks ties and never overrides.
    return -(leftover.astype(np.float64) * 1000.0 + bins.astype(np.float64))
