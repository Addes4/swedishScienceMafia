import numpy as np


def priority(item, bins):
    """Best fit with slight tie-breaking toward preserving empty bins.

    Highest score wins. Score is based on:
      - strongly preferring tight fits: smaller leftover after placement is better
      - mildly preferring to keep some completely empty bins available
      - mildly preferring to fill bins that are already somewhat full
    """
    # Exact best fit term: negative remaining capacity after placing item.
    leftover = bins - item

    # Prefer tighter fits: lower leftover is better.
    score = -leftover.astype(np.float64)

    # Small bonus for placing into bins that are already in use rather than opening
    # brand-new bins, but only when the item does not fit perfectly.
    # This helps avoid consuming empty bins too early.
    score += 0.02 * (100 - bins)

    # Very small bonus for preserving completely empty bins.
    score += 0.01 * (bins == 100)

    return score
