"""Hybrid online bin packing: best-fit with exact-fit preference and limited state."""

import numpy as np


def priority(item, bins):
    """Score bins for an arriving item.

    The item goes to the highest-scoring bin (first on ties).  We primarily use
    best fit: the bin with the smallest remaining capacity that still fits the
    item.  Exact fits are promoted because they close a bin perfectly without
    changing its residual slack.  A small state-dependent nudge helps avoid
    wasting a good bin when the current item is unusually small/large.
    """
    fit = bins >= item
    # Best-fit score: larger for tighter fits (smaller remaining capacity).
    # bins - item is nonnegative where the item fits.
    score = -(bins - item).astype(np.float64)

    # Strongly prefer exact fits: remaining == item.
    exact = bins == item
    if np.any(exact):
        score[exact] += 1000.0

    # Mild preference for bins that will be left with a useful residual.
    # This is a tie-breaker / soft heuristic, not a hard rule.
    residual = bins - item
    # Favour residuals near a small positive value, but keep best-fit dominant.
    # Use a compact penalty that vanishes at exact fit and grows with residual.
    # (The exact bonus above already handles exact fits.)
    score -= 0.002 * (residual.astype(np.float64) ** 2)

    # Prefer emptier bins only very slightly when there is no tight fit.
    # This helps avoid fragmenting medium bins for small items.
    if item <= 25:
        score += 0.0005 * bins.astype(np.float64)

    # Never score unfitting bins positively; the harness should only show fitting bins,
    # but this makes the rule safe if any are present.
    score[~fit] = -1e18

    return score
