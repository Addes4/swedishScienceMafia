import numpy as np


def priority(item, bins):
    # Prefer exact fits strongly, then best fit, while treating empty bins
    # as slightly less attractive than near-exact fits to reduce fragmentation.
    residuals = bins - item
    scores = -residuals.astype(np.float64)

    # Exact fit: dominant bonus.
    scores[bins == item] += 1e6

    # Unused/empty bins: small penalty so they are used only when reasonable.
    scores[bins == 100] -= 5.0

    # Slight preference for tighter fits among non-exact bins.
    scores -= residuals * 0.001

    # Avoid NaN just in case; all arithmetic above stays finite.
    return np.nan_to_num(scores, nan=-1e18, posinf=1e18, neginf=-1e18)
