"""Online bin packing: adaptive best-fit with residual-aware scoring.

Strategy: essentially best-fit-decreasing-like greedy, but online. For each
item we score each feasible bin by a combination of:
  - how tightly the item fits (small residual after placement), and
  - a small preference for bins that are already partially filled (to avoid
    fragmenting the empty bins too early), controlled by a parameter that
    adapts to the observed mean item size.

This mixes best-fit (tight residual) with a bias that helps when items are
large relative to capacity. The bias is kept small so it never dominates
the classic best-fit ordering.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0.0
        self.small_count = 0


_state = _State()


def priority(item, bins):
    """Return a score for every bin in `bins`; highest score wins (ties: first).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (only bins the item fits).
    """
    _state.n += 1
    _state.total += item
    if item <= 25:
        _state.small_count += 1

    # adaptive mean item size
    if _state.n > 0:
        mean_item = _state.total / _state.n
    else:
        mean_item = 40.0

    # residual after placing item
    residual = bins - item
    # negative residual: lower is better -> we return negative residual
    # (best fit baseline).
    score = -residual.astype(np.float64)

    # Bias toward non-empty bins when items are small on average: this reduces
    # the number of bins opened early. When items are large, keep pure best fit.
    # remaining capacity 100 means empty bin.
    empty_mask = (bins == 100)
    if mean_item < 38.0:
        # small bias: prefer already-used bins slightly
        score += 0.02 * (~empty_mask).astype(np.float64)

    # Very small items: stronger tie-break to fill tight gaps first.
    if item <= 10:
        # prefer bins whose residual is small but nonzero (use tiny gaps)
        score += np.where((residual > 0) & (residual <= 10), 0.05, 0.0)

    return score
