import numpy as np


def priority(item, bins):
    """Score bins: prefer tight fits (small remaining capacity after placement), with
    a mild preference against using fresh/empty bins when a suitable fit exists.
    """
    rem_after = bins - item
    # Base: best fit -> smallest remaining capacity after placing item.
    score = -rem_after.astype(np.float64)
    # Slight penalty for using bins that would remain very empty, encouraging tighter packing.
    score -= 0.02 * rem_after.astype(np.float64)
    # Small bonus for bins that become exactly full.
    score += (rem_after == 0).astype(np.float64) * 0.5
    return score
