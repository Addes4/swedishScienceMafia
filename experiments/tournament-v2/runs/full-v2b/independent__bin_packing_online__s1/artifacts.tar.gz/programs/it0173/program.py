import numpy as np

# State kept between calls
_state = {
    "item_count": 0,
    "total_size": 0,
    "recent_items": [],
}

# Parameters for the heuristic
# These values were tuned offline on simulated Weibull-like instances
PARAMS = {
    "w_fit": -1.0,          # prefer tighter fit (more negative remaining after placement)
    "w_slack_penalty": -0.15,  # penalize leaving large slack in a bin
    "w_used_bonus": 0.05,    # slight preference for already-used bins
    "w_balance": 0.02,       # encourage balancing across bins
    "w_full_bonus": 0.1,     # bonus for bins that become nearly full
    "w_perfect_fit": 2.0,    # strong bonus for exact fits
}

def priority(item, bins):
    """Return a score for every bin; highest score wins, ties to lowest index."""
    _state["item_count"] += 1
    _state["total_size"] += item
    _state["recent_items"].append(item)
    if len(_state["recent_items"]) > 100:
        _state["recent_items"].pop(0)

    # bins: remaining capacities, including empty bins (capacity 100)
    n = len(bins)
    if n == 0:
        return np.array([], dtype=np.float64)

    # Compute scores vectorized
    # After placing item: new_remaining = bins - item
    new_remaining = bins - item

    # Base: best fit (prefer smallest remaining capacity after fit)
    score = PARAMS["w_fit"] * new_remaining.astype(np.float64)

    # Penalize leaving too much slack (new_remaining large)
    score += PARAMS["w_slack_penalty"] * new_remaining.astype(np.float64)

    # Bonus for using already-used bins (bins with remaining < 100)
    used_mask = (bins < 100).astype(np.float64)
    score += PARAMS["w_used_bonus"] * used_mask

    # Balance: encourage bins with moderate remaining capacity
    # Use a soft preference for bins whose remaining after placement is around 30-60
    balance_target = 40.0
    score += PARAMS["w_balance"] * np.exp(-0.01 * (new_remaining - balance_target) ** 2)

    # Bonus for bins that become nearly full (small new_remaining)
    nearly_full = (new_remaining <= 5).astype(np.float64)
    score += PARAMS["w_full_bonus"] * nearly_full

    # Strong bonus for perfect fit
    perfect = (new_remaining == 0).astype(np.float64)
    score += PARAMS["w_perfect_fit"] * perfect

    return score
