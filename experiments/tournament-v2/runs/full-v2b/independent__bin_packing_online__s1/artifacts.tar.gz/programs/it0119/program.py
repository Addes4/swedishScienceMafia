import numpy as np

class _State:
    def __init__(self):
        # Rolling histogram of item sizes seen so far (1..100), lightly smoothed.
        self.counts = np.ones(101, dtype=np.float64)
        self.total = 101.0
        self.last_item = 0
        self.calls = 0

_S = _State()

def priority(item, bins):
    """Rank bins by best-fit plus a light probabilistic tie-break.

    The item must go immediately.  We favor tight fits (small residual),
    then use a rolling histogram of observed item sizes to slightly prefer
    bins whose leftover capacity is itself a likely future item size.
    """
    # Update rolling stats.
    _S.calls += 1
    if 1 <= item <= 100:
        c = _S.counts
        # Exponential forget so recent distribution dominates a bit.
        if _S.calls % 256 == 0:
            c *= 0.5
            _S.total = c.sum()
        c[item] += 1.0
        _S.total += 1.0
        _S.last_item = item

    b = np.asarray(bins, dtype=np.float64)
    n = b.size
    if n == 0:
        return b

    # Primary: best fit (smaller remaining capacity after placing item is best).
    residual = b - item
    # Secondary: prefer leftovers that are themselves plausible next item sizes.
    p = _S.counts / _S.total
    # Score by a very small probabilistic bonus added to the strong best-fit term.
    # p[residual] can be indexed only for integer residuals, so round/clip.
    r = np.clip(np.rint(residual), 0, 100).astype(np.int64)
    bonus = p[r]

    # Exact deterministic fit is strongly preferred; exact zero residual gets a boost.
    exact = (residual == 0).astype(np.float64)

    # Combine: minimize residual primarily, maximize future-fit bonus secondarily.
    # Large scale on residual ensures it dominates; bonus only breaks near-ties.
    score = -residual * 1000.0 + bonus * 10.0 + exact * 500.0
    return score
