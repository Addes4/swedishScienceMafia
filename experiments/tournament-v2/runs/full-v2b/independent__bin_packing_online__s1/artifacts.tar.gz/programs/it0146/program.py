import numpy as np


def priority(item, bins):
    """Rank bins by fit quality.

    Primary: prefer bins where the item leaves a very small leftover.
    Secondary: best fit (smallest remaining capacity after placing the item).
    """
    rem = bins - item

    # Score: higher is better.
    # Exact fits get the largest boost, then very small residuals,
    # then ordinary best-fit behavior.
    score = -rem.astype(np.float64)

    # Prefer exact/near-exact fills strongly. This reduces fragmentation.
    score += 1000.0 * (rem == 0)
    score += 200.0 * ((rem > 0) & (rem <= 3))
    score += 80.0 * ((rem > 3) & (rem <= 8))

    # Slightly avoid completely empty bins unless the item is large,
    # preserving them for future larger items when possible.
    if item < 50:
        score -= 1e-6 * (bins == 100)
    else:
        score += 1e-6 * (bins == 100)

    return score
