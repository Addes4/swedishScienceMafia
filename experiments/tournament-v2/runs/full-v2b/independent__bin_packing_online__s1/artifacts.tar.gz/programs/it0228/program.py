"""Online bin packing: best fit with persistent bin-use tracking."""

import numpy as np


class _Tracker:
    def __init__(self):
        self.seen = 0
        self.item_sum = 0.0
        self.item_count = 0
        # estimates of bin activity (not strictly necessary, but harmless)
        self.hist = np.zeros(101, dtype=np.int64)

    def observe(self, item):
        self.item_count += 1
        self.item_sum += item
        if 0 <= item <= 100:
            self.hist[item] += 1


_tracker = _Tracker()


def priority(item, bins):
    """Best-fit with a bias toward reusing already-open bins.

    A bin that has less remaining capacity can fit the item less tightly after
    insertion, so best fit wants the smallest remaining capacity >= item.
    Ties (equal remaining capacity) are resolved by bin order by the harness.
    To avoid opening new bins prematurely, we slightly prefer bins that already
    have some item in them (remaining capacity < 100) over completely empty bins.
    """
    _tracker.observe(item)

    b = np.asarray(bins, dtype=np.int64)

    # Lower remaining capacity after placement is better => -(b - item).
    base = -(b - item).astype(np.float64)

    # Small bonus for already-used bins (remaining < 100), scaled so that it
    # never overrides a genuine best-fit preference but breaks near-ties.
    used_bonus = np.where(b < 100, 1.0, 0.0)

    # Prefer, among used bins, ones that are a bit less full if item fits, to
    # keep room for future items? Actually best fit already handles tightness.
    # Add a very small deterministic bin-index-independent term: favor older
    # (lower index) used bins slightly by using remaining capacity directly.
    # This reduces the number of distinct open bins.
    tie = 1e-6 * (-b.astype(np.float64))

    return base + 0.5 * used_bonus + tie
