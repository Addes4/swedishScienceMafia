import numpy as np


class BinChoice:
    def __init__(self):
        self.calls = 0
        self.sum_items = 0.0
        self.count_items = 0
        self.seen = {}

    def observe(self, item):
        self.calls += 1
        self.sum_items += item
        self.count_items += 1
        self.seen[item] = self.seen.get(item, 0) + 1

    def avg(self):
        if self.count_items == 0:
            return 40.0
        return self.sum_items / self.count_items


_state = BinChoice()


def priority(item, bins):
    """State-aware best-fit with a mild balance term; highest score wins, ties leftmost."""
    _state.observe(item)

    # bins is a numpy int64 array of remaining capacities for bins the item fits in.
    # We prefer tight fits, but avoid making already nearly-full bins the default when
    # a slightly less tight bin may leave a more useful residual capacity.
    rem = bins.astype(np.float64)
    residual = rem - item

    # Best-fit score: larger when residual capacity after placing is smaller.
    tight = -residual

    # Mild anti-fragmentation / balance term.  A bin that is exactly full is generally
    # excellent; otherwise prefer some spread so many medium residuals remain available.
    # The coefficient is deliberately small so this never overrides clear best-fit gains.
    target_delta = 0.35 * _state.avg()
    balance = -np.abs(residual - target_delta)

    # Very slight preference for bins with higher remaining capacity is harmful for bin count,
    # so instead give a tiny bonus to bins that become nearly full.
    near_full = 0.0
    if item <= 100:
        near_full = -np.maximum(residual - 1.0, 0.0) * 0.01

    # Give a small deterministic nudge to lower-index bins only via tie behavior, since
    # the harness handles ties by first occurrence.  Returning float scores is fine.
    scores = tight + 0.08 * balance + near_full

    # Avoid NaN and preserve shape.
    scores = np.asarray(scores, dtype=np.float64)
    scores[~np.isfinite(scores)] = -1e18
    return scores
