import numpy as np


def priority(item, bins):
    """Best fit: choose the bin with the least remaining capacity after placing the item."""
    return -(bins - item)
