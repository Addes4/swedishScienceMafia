"""Adaptive best-fit with a learned residual-utility bias for online bin packing."""

import numpy as np


# Running statistics of observed items (online, no future information).
_STATE = {
    "count": 0.0,
    "sum": 0.0,
    "sumsq": 0.0,
    "small_threshold": 0.0,
}


def _update_stats(item):
    s = _STATE
    s["count"] += 1.0
    s["sum"] += float(item)
    s["sumsq"] += float(item) * float(item)
    n = s["count"]
    mean = s["sum"] / n
    var = max(0.0, s["sumsq"] / n - mean * mean)
    sd = var ** 0.5
    # Conservative estimate of a "small-ish" item: roughly the 25th percentile
    # of a distribution with this mean/sd. This is used to value leftovers.
    s["small_threshold"] = max(0.0, mean - 0.6745 * sd)


def priority(item, bins):
    """Rank bins for best fit, with a mild bonus for leftovers that can still be useful."""
    _update_stats(item)

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - float(item)  # leftover capacity after placing the item

    # Best-fit core: prefer the smallest nonnegative residual.
    # Small epsilon ensures deterministic tie-breaking by bin index.
    eps = 1e-9
    score = -residual

    # Bonus: a leftover that is at least the estimated small-item size is more useful
    # than a tiny unusable scrap, so avoid creating near-zero fragments.
    if _STATE["count"] > 10.0 and _STATE["small_threshold"] > 0.0:
        t = _STATE["small_threshold"]
        # Smooth bonus: rises as residual approaches the small-item threshold.
        usefulness = np.minimum(residual, t) / t
        # Slight preference for residuals that can hold a typical small item.
        score += 0.02 * usefulness

    # Do not reward huge empty bins too much; best fit already handles tightness.
    # Tiny deterministic component to break exact ties by lower index.
    score -= eps * np.arange(bins.shape[0], dtype=np.float64)

    return score
