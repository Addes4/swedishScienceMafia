import numpy as np


def priority(item, bins):
    # Best-fit: prefer bins whose remaining capacity is closest to the item size.
    # Add a tiny bonus for bins that are already more filled, to reduce fragmentation.
    return -(bins - item) - 1e-6 * bins
