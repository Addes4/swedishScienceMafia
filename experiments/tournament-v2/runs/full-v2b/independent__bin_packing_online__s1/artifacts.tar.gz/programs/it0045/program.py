import numpy as np

# Online statistics for item sizes (updated from calls only, no future info)
_stats = {
    "n": 0,
    "sum": 0.0,
    "sumsq": 0.0,
    "hist": np.zeros(101, dtype=np.int64),
}

def _update_stats(item):
    _stats["n"] += 1
    _stats["sum"] += item
    _stats["sumsq"] += item * item
    _stats["hist"][item] += 1

def _mean_std():
    n = _stats["n"]
    if n < 2:
        return 40.0, 20.0
    m = _stats["sum"] / n
    var = max(1e-9, _stats["sumsq"] / n - m * m)
    return m, var ** 0.5

def _fraction_leq(x):
    if x <= 0:
        return 0.0
    if x >= 100:
        return 1.0
    h = _stats["hist"]
    return float(h[:int(x) + 1].sum()) / max(1, _stats["n"])

def priority(item, bins):
    _update_stats(item)

    n_bins = bins.shape[0]
    scores = np.empty(n_bins, dtype=np.float64)

    # Empty bins are remaining capacity 100 (unused), all identical
    empty_mask = (bins == 100)

    # Remaining capacities of partially filled usable bins
    used_mask = ~empty_mask
    cap = bins[used_mask]

    # Best-fit base: prefer tightest fit among used bins
    # Score larger for smaller leftover after placing item
    if cap.size:
        leftover = cap - item
        # Strong preference for exact fit
        scores_used = 1000.0 - leftover.astype(np.float64)
        # Even stronger bonus for exact fit
        exact = (leftover == 0)
        scores_used[exact] += 10000.0
        # Prefer fits that leave a small chunk that is a common item size
        m, s = _mean_std()
        # Penalize leftover that is unlikely to be useful (too small)
        # leftover >= item_min means at least a 1-size item could still fit; keep mild
        # Bonus when leftover is in a "hard to fill" small range is bad; prefer leftover
        # around a typical remaining gap: reward leftover that is a plausible next item
        # small bonus for leftover near one standard deviation below mean
        target = max(1.0, m - 0.5 * s)
        scores_used -= 0.15 * np.abs(leftover - target)
        scores[used_mask] = scores_used
    else:
        scores[used_mask] = 0.0

    # Empty bins: opening cost. Prefer not to open a new bin when a used bin is decent.
    # Reward empty bins less than any reasonable used-bin fit.
    # Base shared score plus a small value for very full empty-bin availability.
    if empty_mask.any():
        # Fraction of items that are > item, i.e. unlikely to be placed later in residual
        # Number of items already seen: opening a new bin costs approx one full bin.
        # Prefer empty bins only when used bins are bad (large leftover).
        scores[empty_mask] = -50.0

    # If no used bins exist, just pick first empty (all equal)
    if not used_mask.any():
        scores[empty_mask] = 0.0

    # Avoid NaN
    scores = np.nan_to_num(scores, nan=-1e9, posinf=1e9, neginf=-1e9)
    return scores
