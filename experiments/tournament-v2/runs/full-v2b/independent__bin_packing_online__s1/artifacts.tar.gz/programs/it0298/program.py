import numpy as np

# Weibull-shaped item distribution, mean ~40, capacity 100.
# Use a composite score favoring bins whose residual after placing the item
# is close to either 0 (perfect fit) or a slack region near the mean item size,
# while strongly preferring tighter fits.

TARGET_SLACK = 40.0  # typical future item size
ALPHA = 1.0          # weight for tightness (best-fit)
BETA = 0.02          # weight for target residual shape
EPS = 1e-6

def priority(item, bins):
    residual = bins - item  # remaining capacity if item placed here
    # Base: prefer smaller residual (tighter fit)
    tight = -residual.astype(np.float64)
    # Shape term: prefer residual near 0 or near TARGET_SLACK
    # Use a soft measure: penalize distance to nearest of {0, TARGET_SLACK}
    dist0 = residual.astype(np.float64)
    distT = np.abs(residual.astype(np.float64) - TARGET_SLACK)
    shape = -np.minimum(dist0, distT)
    score = ALPHA * tight + BETA * shape
    # Never place into a bin where it wouldn't fit (shouldn't happen given input)
    score = np.where(residual < 0, -1e9, score)
    # Ensure no NaN
    score = np.nan_to_num(score, nan=-1e9)
    return score
