"""Best-fit bin-choice rule for online bin packing.

The item is placed into the fitting bin with the smallest remaining capacity
(i.e. the tightest fit). This is the classic best-fit online heuristic and
tends to outperform first-fit on item distributions with many small and some
large items, like the Weibull-shaped sizes here. Ties are broken in favor of
the earliest bin, which the harness already does automatically since it picks
the first bin with the highest score.
"""
import numpy as np


def priority(item, bins):
    """Score every fitting bin; highest score wins (ties go to first bin).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    # Tightest fit: smallest remaining capacity that still accommodates item.
    # Returning -(bins - item) makes tightest fits highest-scoring.
    return -(bins - item)
