"""Online bin packing with a best-fit / almost-full-bin heuristic.

Key idea:
- Best fit alone is decent, but near the end of a bin's fill, placing an item that
  leaves a tiny residual capacity is very valuable (it wastes little).
- We also want to avoid putting items into a bin if that would leave a residual that
  is likely to be useless for future items (e.g. less than the smallest likely item).
- Since items arrive from a Weibull-like distribution with mean ~40, there are many
  small items. A residual below ~5 is usually unusable, so forcing a bin nearly full
  is good.
- Randomised tie-breaking and a tiny stateful nudge helps avoid pathological patterns.
"""

import numpy as np

# Module-level state: simple running statistics of observed items.
_STATE = {
    "n": 0,
    "sum": 0.0,
    "sumsq": 0.0,
}


def _update_stats(item):
    _STATE["n"] += 1
    _STATE["sum"] += item
    _STATE["sumsq"] += item * item


def priority(item, bins):
    """Rank bins for the current item; higher score wins (ties -> earliest bin)."""
    _update_stats(item)

    # Estimate distribution statistics on the fly.
    n = _STATE["n"]
    mean = _STATE["sum"] / n
    var = max(_STATE["sumsq"] / n - mean * mean, 0.0)
    sd = var ** 0.5

    # Rough estimate of a "small item" threshold.  For a Weibull-like
    # distribution with mean 40, a reasonable lower quantile is around
    # max(1, mean - 1.5*sd).  Residuals below this are often wasted.
    small_cut = max(3.0, mean - 1.5 * sd)

    # Best fit: prefer smallest residual that still fits (largest item - residual).
    residual = bins.astype(np.float64) - float(item)

    # Base score: strongly favour tight fits (small residual).
    # Using a monotone decreasing function gives strict best-fit ordering.
    score = -residual

    # Huge bonus for leaving a residual that is below the useful-item threshold,
    # because that bin is effectively closed and its leftover space is wasted
    # anyway; filling it now costs nothing extra.
    close_bonus = 0.0
    nearly_full = residual < small_cut
    score = score + nearly_full * (1000.0 + item)

    # Mild preference for larger bins when residuals are comparable, to keep
    # medium residuals available for future items.  This is a small tie-break
    # relative to the tight-fit ordering.
    score = score + 0.01 * bins.astype(np.float64)

    # Deterministic tiny nudge based on bin index to reduce systematic bias
    # toward low indices, but small enough not to override real preferences.
    idx = np.arange(len(bins), dtype=np.float64)
    score = score - 1e-7 * idx

    return score
