import numpy as np


def priority(item, bins):
    # bins are remaining capacities of bins this item fits in.
    # Best-fit: minimize residual capacity (bins - item).
    residual = bins - item

    # Strongly prefer tight fits, but add a small penalty for creating very tiny
    # residual slack (hard to reuse) while not just maximizing fill greedily.
    # This is essentially best-fit with a gentle anti-fragmentation tiebreak.
    score = -residual.astype(np.float64)

    # tiny penalty for leaving a small but nonzero gap (residuals 1..~15),
    # making the packer prefer either a perfect fit or a roomier bin.
    small_gap_penalty = np.where((residual > 0) & (residual <= 15),
                                 0.5 * (16.0 - residual),
                                 0.0)
    score -= small_gap_penalty

    return score
