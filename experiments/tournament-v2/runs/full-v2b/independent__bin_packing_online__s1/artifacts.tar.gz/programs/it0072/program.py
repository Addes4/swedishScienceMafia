import numpy as np

# Tunable parameters (kept modest to generalize across unseen instances)
SMALL_GAP = 4          # residual capacity <= this is considered "bad" unless it is 0
SMALL_GAP_PENALTY = 0.15
LARGE_ALMOST = 100     # unused/empty bins


def priority(item, bins):
    """Rank bins for online bin packing.

    Primary objective: best fit (minimize left-over capacity after placement).
    Secondary tweak: slightly penalize placements that leave tiny unusable gaps.
    """
    rem = bins - item                    # remaining capacity if item placed here
    score = -rem.astype(np.float64)      # best fit baseline

    # Penalize leaving a tiny positive residual (wasted space fragments).
    # Exact fills (rem == 0) remain best.
    bad = (rem > 0) & (rem <= SMALL_GAP)
    score[bad] -= SMALL_GAP_PENALTY

    return score
