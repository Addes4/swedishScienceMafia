import numpy as np

_state = {
    "seen": 0,
    "opened": 0,
}


def priority(item, bins):
    # Best fit: prefer the bin that leaves the least remaining capacity.
    # Slight preference for already-used bins when the fit is close,
    # to reduce unnecessary opening of new bins.
    rem = bins - item                 # remaining capacity if placed here
    # Higher score = better. Tighter fit gets higher score.
    score = -rem.astype(np.float64)

    # Mild bonus for used bins (not full/capacity-100) to preserve empty bins.
    # This helps avoid fragmenting fresh capacity for no reason.
    used = bins < 100
    score += used * 0.25

    # Tiny deterministic tie-breaker: prefer larger remaining after placement?
    # No - best fit already handles tightness. Keep order-stable.
    return score
