import numpy as np


class OnlineStats:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0
        self.hist = np.zeros(101, dtype=np.int64)

    def update(self, x):
        self.n += 1
        delta = x - self.mean
        self.mean += delta / self.n
        self.m2 += delta * (x - self.mean)
        self.hist[x] += 1

    @property
    def std(self):
        if self.n < 2:
            return 0.0
        return (self.m2 / (self.n - 1)) ** 0.5


_stats = OnlineStats()


def priority(item, bins):
    _stats.update(item)
    n = _stats.n
    # After some warmup, we know roughly the item distribution.
    # Best-fit score: prefer smallest remaining capacity that still fits.
    # bins contains only bins where item fits (remaining >= item).
    # Tightest fit -> smallest (bins - item) -> most negative -(bins - item)? 
    # Baseline uses -(bins - item): larger when bins-item is smaller (tighter).
    base = -(bins - item).astype(np.float64)

    if n < 50:
        return base

    # Adaptive: estimate typical item size from history.
    mean_item = _stats.mean
    # Bins that would be exactly filled by this item get a bonus.
    leftover = bins - item

    # Bonus for desirable leftover: close to a "next item" typical size or 0.
    # Penalize leftovers that are too small to be useful if they're nonzero and awkward.
    # Simple heuristic: strong preference for exact fit (leftover 0),
    # then preference for leftovers near mean_item (good for future fit),
    # penalize tiny leftovers that fragment.
    bonus = np.zeros_like(base)

    # Exact fit gets big bonus
    bonus += (leftover == 0) * 5.0

    # Leftover close to mean item size: good, likely to fit a typical next item
    scale = max(mean_item, 1.0)
    # reward leftovers that can hold a typical item
    bonus += 1.0 * (leftover >= mean_item) * (leftover < 2 * scale)
    # penalize very small leftovers (fragmentation)
    bonus -= 0.5 * (leftover > 0) * (leftover < 0.25 * scale) * (1.0 - leftover / scale)

    # Combine: base already orders tightly; bonus refines.
    return base + bonus
