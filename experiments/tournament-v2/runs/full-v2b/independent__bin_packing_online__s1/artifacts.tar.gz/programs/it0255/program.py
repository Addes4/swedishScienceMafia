import numpy as np


def priority(item, bins):
    """Best fit: prefer the bin with the smallest remaining capacity that still fits.

    Ties are broken slightly toward used bins so that already-opened bins fill up before
    new bins are touched when capacities are equal.
    """
    remaining = bins - item
    # Higher score for smaller remaining capacity; add a tiny preference for used bins.
    return -(remaining.astype(np.float64)) + 1e-6 * (bins < 100).astype(np.float64)
