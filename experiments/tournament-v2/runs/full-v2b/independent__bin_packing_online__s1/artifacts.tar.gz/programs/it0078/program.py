import numpy as np


def priority(item, bins):
    """Rank bins by a blend of best-fit tightness and preference for non-empty bins.

    The item goes to the highest score, ties to the first bin. Main idea:
    choose the bin whose remaining capacity after placing the item is smallest,
    but slightly prefer bins that are already in use to avoid opening new bins
    when the packing quality is otherwise similar.
    """
    leftover = bins - item
    # Lower leftover is better, so use negative leftover.
    # Add a tiny bonus for bins that are not completely empty (capacity < 100),
    # encouraging consolidation without materially changing near-tight choices.
    in_use = (bins < 100).astype(np.float64)
    return -leftover.astype(np.float64) + 1e-6 * in_use
