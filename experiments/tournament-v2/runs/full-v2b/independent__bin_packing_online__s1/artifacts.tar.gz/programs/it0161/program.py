import numpy as np


def priority(item, bins):
    """Score bins by best fit, with a mild preference for already-used bins on ties."""
    rem_after = bins - item
    # Best fit: minimize remaining capacity after placing the item.
    # Add a tiny preference for bins that were already less empty (bins < 100),
    # without disturbing the main best-fit ordering.
    used_bonus = (bins < 100).astype(np.float64) * 0.01
    return -rem_after.astype(np.float64) + used_bonus
