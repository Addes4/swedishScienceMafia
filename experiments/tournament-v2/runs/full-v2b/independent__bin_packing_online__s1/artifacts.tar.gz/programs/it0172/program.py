import numpy as np


def priority(item, bins):
    """
    Score each available bin for an arriving item.

    Bin choice rule:
      - Prefer bins where the item fits tightly (best fit).
      - Slightly penalize completely empty bins so that an existing partially
        filled bin is preferred unless the fit is clearly bad.
      - Strongly prefer bins that will be filled exactly.

    The item goes to the bin with the highest score; ties go to the first bin.
    """
    rem_after = bins - item

    # Base score: smaller remaining capacity after placing is better.
    # Use a smooth inverse-like penalty, scaled to be well behaved.
    score = -rem_after.astype(np.float64)

    # Extra reward for an exact fit: this closes a bin cleanly.
    score += (rem_after == 0) * 50.0

    # Small penalty for using a brand-new/empty bin (remaining capacity 100).
    # This reduces uselessly opening new bins when existing bins have room.
    is_empty = (bins == 100)
    score -= is_empty * 3.0

    # Mild preference for bins that are already fairly full, beyond pure
    # best-fit, to consolidate space and leave larger empty bins for big items.
    score -= (bins / 100.0) * 0.5

    return score
