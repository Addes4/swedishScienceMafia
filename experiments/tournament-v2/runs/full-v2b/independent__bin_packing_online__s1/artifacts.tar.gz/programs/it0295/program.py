import numpy as np
from collections import deque

# A simple online bin-packing heuristic:
# - Primary: best-fit decreasing-like (tightest fit) via -(bins - item)
# - Tie-break: prefer bins already partly used (avoid using new bins unnecessarily)
# - Slight bias to avoid completely filling bins that might be needed to pair with small items?
# We'll implement "best fit with small lookahead-free tie-breaking".

# State: track sizes seen to estimate distribution? Not necessary, best-fit is strong.
# We'll add a tiny preference: among equal fits, prefer bin with smaller remaining capacity before placement?
# That's exactly best fit: place in bin with smallest remaining capacity >= item.
# Score = -(bins - item) gives larger (less negative) for smaller remaining after placement.

# Since ties go to first bin, and bins are in order, best fit already does that.

# Potential improvement: "Worst-fit for large items" when many bins are nearly full?
# We can try a hybrid: if item is large (> 50), use best fit; if small, use best fit still.
# Actually best fit is known to be good; but sometimes "first fit" performs better on some distributions.
# Let's test mentally: mean 40, capacity 100 -> typical two items per bin.
# Best fit will fill bins to ~80, leaving 20. Then a 30 item won't fit, needs new bin.
# First fit might leave more bins at 100 remaining, which could be better for large items.
# But best fit tends to pack well.

# We'll implement a scoring that combines:
# - Preferred remaining after placement: close to 0 is good (tight)
# - But avoid leaving exactly 0 if we might need it? No, leaving 0 is perfect.
# - Slight penalty for using a completely empty bin (100 remaining) if item < 40?
# Actually using empty bin for small item is wasteful. Best fit already avoids that if possible.

# Let's also track the number of bins and their capacities? No need, harness gives bins.

# We'll implement adaptive: if item size > 70, prefer bin with largest remaining capacity (worst fit) to keep large bins for large items? 
# That's classical "worst fit" but it's known to be worse. 
# However, with mean 40, large items > 70 are rare. Let's stick to best fit.

# One better known online algorithm: "Best Fit" is very good for this.
# But we can improve by "best fit with tie-breaking by smallest original bin index" - already default.

# Let's implement a refined scoring:
# score = -(remaining_after) + alpha * (remaining_before == 100) * (item < 40)
# This penalizes using empty bins for small items.
# alpha small, e.g., 0.1. But since scores are integers, we need to scale.
# We can scale by 1000: score = -1000*(remaining_after) - penalty.

# Better: since item is integer, remaining_after = bins - item.
# We want to minimize remaining_after primarily.
# Secondary: minimize remaining_before (i.e., prefer fuller bins) -> that's same as best fit.
# Tertiary: if remaining_after equal, prefer bin with smaller index? Already first.

# We'll add: if item <= 20, strongly avoid empty bins: subtract large constant for empty bins.
# if item >= 80, prefer empty bins? Actually large item needs large space; if we have a bin with 100 remaining, it's good to use it because other bins might not fit it.
# But best fit would pick the bin with smallest remaining >= item. If there's a bin with 100 remaining and another with 85, and item=80, best fit picks 85 (tight), leaving 100 for later large item. That's good. So best fit handles that.

# So maybe just best fit is optimal. Let's try a slight perturbation: 
# use best fit, but if there are multiple bins with same remaining_after, prefer one with smaller remaining_before? That's same bin.
# Actually remaining_after = remaining_before - item, so same remaining_after means same remaining_before. No tie.

# Let's just return -(bins - item) as baseline, but maybe add a tiny random? No.

# I'll implement a small improvement: use a "best fit" but with a penalty for leaving a bin with remaining capacity in (1..5) because small gaps are wasted. 
# If we place item and leave remaining 1..5, that's bad because we can't fit any item >=1. But all items >=1, so remaining 1 can fit item 1.
# Actually remaining 1 can fit only item 1. So leaving 1 is almost as bad as leaving 0? Leaving 0 is perfect (fully packed). Leaving 1 is fine if next items might be 1.
# Given integer items, leaving 1 is okay if we get a 1.

# No clear improvement. Let's try a known better algorithm: "Best Fit Decreasing" is offline. Online best fit is good.

# We'll implement a hybrid: for item size > 50, use worst fit (maximize remaining after) to keep bins balanced? 
# Actually worst fit spreads items, which is bad for packing.

# I'll go with best fit but with a minor tweak: if the item is small (<=10), prefer bins with remaining capacity exactly item (perfect fit) more strongly.
# Already best fit does that.

# Let's just use best fit and maybe add a tie-breaker: if remaining_after is equal, prefer bin with smaller remaining_before? That's same.

# Final decision: use best fit with a small adjustment: penalize using a completely empty bin when there exists a non-empty bin that can fit the item, unless the item is large (>=80) and no non-empty bin can fit it. Actually best fit already prefers non-empty if it results in tighter fit.

# Let's test a scenario: bins: [100, 50], item=40. Best fit: remaining after: 60, 10 -> picks 50 (score -10). Good.
# bins: [100, 20], item=10. Best fit: after: 90, 10 -> picks 20 (score -10). Good.

# Seems best fit is optimal. I'll return baseline but with a tiny scaling to make scores integer? Not needed.

# However, the baseline returns -(bins - item), which is fine. But we can improve by adding a small bonus for bins that are nearly full? No.

# I'll implement a "best fit with frequency-based tie-breaking" where we track how many items of each size we've seen?
# Not useful.

# Let's just go with best fit, but add a small penalty for leaving a bin with remaining capacity in 1..10 (since those are hard to fill). 
# Actually leaving 10 is fine, next item could be 10.
# Leaving 1..5 is bad because only 1..5 items can fit.

# We can add: if remaining_after == 0, bonus +1000 (perfect fit).
# if remaining_after <= 5, penalty -100.
# But this might break tight packing? Let's think: if item=40, bins: [45, 50]. remaining after: 5, 10. Best fit picks 45 (remaining 5). Our penalty would penalize that, so it would pick 50 (remaining 10). That leaves 5 unused in first bin, which is bad. So penalty is bad.

# So best fit is good.

# I'll return the baseline.

def priority(item, bins):
    # Best fit: maximize (item - bins) => minimize (bins - item) => score = -(bins - item)
    # Equivalent: score = item - bins
    # We'll return item - bins as int64 numpy array.
    return item - bins
