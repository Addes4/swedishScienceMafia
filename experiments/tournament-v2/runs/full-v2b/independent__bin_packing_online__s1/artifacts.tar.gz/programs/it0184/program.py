"""Online bin packing: best-fit priority with fragmentation-aware scoring.

Items arrive one at a time. We rank bins so the item goes to the tightest fitting
bin (best fit), which is a strong online heuristic. Unused bins (capacity 100) are
ranked normally and will be chosen when no partially-filled bin fits.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest (first on ties)."""
    rem = bins.astype(np.int64, copy=False)
    residual = rem - item  # leftover capacity after placing item == rem - item

    # Best fit: smallest residual gets the highest score.
    score = -residual.astype(np.float64)

    # Small bonus for residuals that are essentially zero (perfectly filled):
    # reduces number of bins by consolidating.
    score += np.where(residual <= 1, 0.25, 0.0)

    return score
