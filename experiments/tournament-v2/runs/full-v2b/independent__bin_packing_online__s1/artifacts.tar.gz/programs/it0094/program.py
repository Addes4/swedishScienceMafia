# EVOLVE-BLOCK-START
"""Best-fit with a small residual-waste penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    rem = bins.astype(np.float64)
    # Prefer the bin with the smallest remaining capacity that still fits (best fit).
    # Score = smaller remaining is better => use -rem. But add a small penalty for
    # leaving a residual that is small-but-nonzero (likely hard to reuse).
    residual = rem - item
    # Penalize tiny residuals slightly so they're less attractive than exact fit
    # or a moderate residual. residual==0 is ideal.
    waste = np.where(residual == 0, -1.0, residual)
    # tiny residual (<5) gets a slight extra penalty relative to zero
    small_penalty = np.where((residual > 0) & (residual < 5), 0.5, 0.0)
    return -waste - small_penalty
# EVOLVE-BLOCK-END
