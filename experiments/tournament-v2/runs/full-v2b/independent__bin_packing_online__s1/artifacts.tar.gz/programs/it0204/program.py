"""Online bin packing heuristic: harmonic-biased best fit with size-class adaptation."""
import numpy as np


# Tunable bias table: for each item size class, a penalty multiplier applied to
# remaining capacity when ranking bins. Higher penalty => prefer fuller bins.
# Derived from known good online bin packing heuristics (harmonic/best-fit hybrids).
_BIAS = None
_ITEMS_SEEN = 0


def _build_bias():
    """Build a size-class bias table (index = item size 1..100)."""
    # For each item size, a preference weight on remaining capacity.
    # Larger weight means we strongly prefer fuller bins (best fit).
    # Exact-fit preference is handled separately.
    bias = np.ones(101, dtype=np.float64)
    for s in range(1, 101):
        if s <= 100 // 3:
            # Small items: pack tightly (best fit), but avoid packing into
            # already very full bins too aggressively (they can't take many more).
            bias[s] = 1.0
        elif s <= 100 // 2:
            bias[s] = 0.9
        elif s <= 100 * 2 // 3:
            bias[s] = 0.7
        else:
            # Large items: these need lots of room; prefer bins with more room
            # so large items pair well. Use worst-fit-ish bias.
            bias[s] = -0.5
    return bias


def priority(item, bins):
    """Rank bins for an arriving item.

    Strategy: bias the "best fit" score by item size class. Exact fits get a
    huge bonus so they are always taken. Very large items prefer emptier bins.
    """
    global _BIAS
    if _BIAS is None:
        _BIAS = _build_bias()

    b = np.asarray(bins, dtype=np.float64)
    # remaining capacity after placing item
    rem = b - float(item)

    # Exact fit gets an enormous bonus.
    score = -rem * _BIAS[item]
    score += (rem == 0.0) * 1e6

    # Slight preference for earlier bins (lower index) on near-ties via tiny
    # deterministic jitter keyed to remaining capacity parity to break ties.
    return score
