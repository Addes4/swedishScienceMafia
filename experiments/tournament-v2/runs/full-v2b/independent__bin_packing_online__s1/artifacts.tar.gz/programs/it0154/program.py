"""Improved online bin packing: tilted best-fit packing rule.

Strategy:
- Prefer the bin whose remaining capacity after placement is smallest (best fit),
  but avoid opening a fresh bin unless the item does not fit well anywhere.
- Apply a mild penalty for perfectly emptied bins / new bins so the algorithm
  consolidates around existing partial bins before using an empty one.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # Best fit: rank by smallest remaining capacity after placing the item.
    remaining_after = bins - item

    # Primary score: strongly prefer tightest fit.
    score = -remaining_after.astype(np.float64)

    # Mildly discourage using unused bins (remaining capacity 100) when viable
    # non-empty bins exist, but never enough to override a clearly better fit.
    score -= (bins == 100).astype(np.float64) * 0.25

    # Slight preference for bins that become empty? No: emptying a bin is neutral
    # capacity-wise, but using it fully is good. Best fit already captures this.

    return score
