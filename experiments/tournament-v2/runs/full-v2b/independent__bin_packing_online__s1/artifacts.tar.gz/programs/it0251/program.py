"""Best-fit with tie-breaking toward earlier bins for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties to first bin.

    Score: prefer bins that fit most tightly (smallest remaining capacity after
    placing the item), then earlier bins. This is the classic Best Fit rule,
    which is strong for online bin packing on Weibull-like size distributions.
    """
    # Tightest fit: smallest residual capacity (bins - item) is best.
    # Negate so higher score = tighter fit. Add tiny index bonus for tie-break.
    n = bins.shape[0]
    # Index bonus: earlier indices get a tiny positive nudge.
    idx_bonus = (n - np.arange(n, dtype=np.float64)) * 1e-6
    return -(bins.astype(np.float64) - item) + idx_bonus
