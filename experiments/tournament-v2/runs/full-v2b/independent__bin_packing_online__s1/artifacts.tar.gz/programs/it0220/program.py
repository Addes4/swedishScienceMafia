"""Best-fit variant with tie-breaking that favors partially filled bins."""
import numpy as np


def priority(item, bins):
    """Rank bins by fit tightness, then by how full the bin already is.

    A smaller remaining capacity after placement (tighter fit) gets a higher score.
    Among bins with the same resulting remaining capacity, prefer those that are
    already more used (smaller current remaining capacity), which avoids wasting
    near-empty bins and tends to reduce total bin count.
    """
    # After placement, remaining capacity = bins - item (all bins shown already fit).
    after = bins - item
    # Higher score for smaller `after` (tighter fit).
    # Tie-break: prefer smaller current `bins` (more used bin) -> add small epsilon term.
    # Use float scoring; `after` ranges 0..99, so epsilon 0.5 is safe for integer ties.
    return -(after.astype(np.float64)) - 0.5 * (bins.astype(np.float64))
