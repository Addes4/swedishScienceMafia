import numpy as np

# EVOLVE-BLOCK-START
"""Adaptive best-fit bin packing.

We rank bins primarily by residual space after placing the item (best fit),
with a small preference for non-empty bins so that partially filled bins get
reused, and a tiny deterministic tie-breaking perturbation to avoid always
making identical choices in degenerate cases.
"""


class Packer:
    def __init__(self):
        self.calls = 0
        self.item_sum = 0

    def priority(self, item, bins):
        self.calls += 1
        self.item_sum += item

        # bins: remaining capacities (int). We only see bins where item fits.
        # Primary: best fit -> minimize residual capacity (bins - item).
        # So score high when (bins - item) is small => score = -(bins - item).
        residual = bins - item

        # Small bonus for bins that are already used (remaining < 100),
        # to encourage consolidation into partially filled bins.
        used_bonus = np.where(bins < 100, 0.25, 0.0)

        # Deterministic tie-break perturbation based on item and capacity.
        # Scaled small so it never overrides the main ordering meaningfully.
        tie = (bins * 7919 + item * 104729) % 97
        tie = tie.astype(np.float64) * 1e-6

        return (-residual.astype(np.float64)) + used_bonus + tie


_packer = Packer()


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    return _packer.priority(item, bins)
# EVOLVE-BLOCK-END
