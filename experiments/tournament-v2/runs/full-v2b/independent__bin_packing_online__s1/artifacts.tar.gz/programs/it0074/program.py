import numpy as np

# Parameters tuned roughly for the stated Weibull-shaped distribution with mean ~40.
# The rule is a bounded best-fit with a mild bias toward avoiding tiny leftovers.
_SMALL_LEFT_PENALTY = 0.02
_USEFUL_MIN = 8
_MAX_ITEM = 100


def priority(item, bins):
    """Rank bins by a best-fit rule with a small penalty for leaving a tiny unusable remainder.

    Highest score wins; ties go to the earliest bin. We subtract the remaining capacity after
    placing the item (so tight fits rank high) and add a mild penalty when the leftover is
    positive but very small, since such a residue often cannot accommodate future items.
    """
    leftover = bins - item

    # Default score: prefer the tightest fitting bin (smallest leftover).
    score = -leftover.astype(np.float64)

    # Mild penalty for creating a small but nonzero leftover that is likely wasted.
    # Penalize leftovers in (0, _USEFUL_MIN) proportionally to how small they are.
    small = (leftover > 0) & (leftover < _USEFUL_MIN)
    if np.any(small):
        # Penalty grows as leftover shrinks toward 1; exact zero leftover is not penalized.
        penalty = _SMALL_LEFT_PENALTY * (_USEFUL_MIN - leftover[small]) / _USEFUL_MIN
        score[small] -= penalty

    # Slight preference for using already-open bins over completely empty ones only when
    # the fit is otherwise comparable: an empty bin has leftover 100-item, which is already
    # strongly deprioritized by best-fit, so no extra term is needed.
    return score
