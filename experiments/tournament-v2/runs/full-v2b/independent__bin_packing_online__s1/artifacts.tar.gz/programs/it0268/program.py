import numpy as np


def priority(item, bins):
    """Score bins: prefer bins that leave a small leftover and are not empty.

    Empty bins have remaining capacity 100.  To avoid opening a new bin when
    some partially filled bin can still hold the item reasonably well, give
    completely empty bins a large penalty.  Among usable bins, favour the
    fullest bin that still fits (best fit), which tends to keep larger free
    spaces available for later large items.  Ties fall back to the first bin.
    """
    # Largest possible "reasonable" leftover scales with item size.
    # Prefer smallest leftover, then fullest existing bin.
    leftover = bins - item

    # Penalise opening a brand-new bin.  The penalty is finite so that if the
    # only fitting bins are empty ones, one is still selected.
    empty_penalty = (bins >= 100).astype(np.float64) * 80.0

    # Primary: prefer tight fit.  Secondary: prefer bins that already contain
    # something (fuller), i.e. smaller remaining capacity before placing.
    return -leftover.astype(np.float64) - 0.001 * bins.astype(np.float64) - empty_penalty
