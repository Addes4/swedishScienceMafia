# EVOLVE-BLOCK-START
"""Best fit with a small lookahead-free tie adjustment."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Best-fit: prefer smallest residual >= 0.
    score = -residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
