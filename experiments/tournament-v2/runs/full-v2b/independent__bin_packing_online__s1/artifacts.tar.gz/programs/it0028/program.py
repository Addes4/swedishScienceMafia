"""Online bin packing with a best-fit-style one-step lookahead priority."""

import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score.

    The idea is to score each feasible bin by applying a best-fit-like rule to the
    residual gap it would create.  Bins where the item leaves a remainder that is
    neither very small nor very large tend to pack better in practice.
    """
    # bins is an int64 numpy array of remaining capacities where item fits.
    rem = bins.astype(np.int64, copy=False)
    gap = rem - item

    # Primary: prefer tight fits (small remaining gap).
    # Secondary: slightly prefer bins that already contain items, i.e. smaller rem,
    # because leaving empty bins untouched is useful for future larger items.
    # The coefficient is tiny so it does not override the packing-quality score.
    score = -gap * 1000 - rem

    return score
