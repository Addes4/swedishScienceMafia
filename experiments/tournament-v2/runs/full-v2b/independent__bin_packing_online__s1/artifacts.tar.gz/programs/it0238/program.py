import numpy as np

# Tunable constants chosen to be robust across instances from the stated distribution.
_OPEN_BONUS = 0.35
_EMPTY_PENALTY = 0.30
_FIT_BONUS = 1.5


def priority(item, bins):
    """
    Score each bin for placing `item`.

    Higher score is better. Bins are the remaining capacities of all bins the item fits in.
    The item is placed in the highest-scoring bin, with ties going to the earliest bin.

    Strategy:
      - Prefer bins where the item leaves very little slack (near-best-fit).
      - Add a small bonus for non-empty bins, so we tend to consolidate.
      - Add a small penalty for using an entirely empty bin, preserving empties when possible.
    """
    residual = bins - item

    # Base: best-fit-like preference: smaller residual is better.
    score = -residual.astype(np.float64)

    # Bonus for already-used bins (residual < 100).
    used = bins < 100
    score += _OPEN_BONUS * used

    # Slight penalty for consuming a completely empty bin.
    empty = bins == 100
    score -= _EMPTY_PENALTY * empty

    # Extra strong preference for very tight fits, especially exact fits.
    tight = residual <= 2
    score += _FIT_BONUS * tight

    return score
