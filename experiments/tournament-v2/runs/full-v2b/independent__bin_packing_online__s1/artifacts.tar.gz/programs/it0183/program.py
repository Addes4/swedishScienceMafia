import numpy as np

# Precompute thresholds for size classes.
# Using fractions of capacity 100.  These are tuned to harmonic-like packing.
# Classes:
# A: 50 < s <= 100  -> must go in near-empty bin
# B: 100/3 < s <= 50  -> pair with another same-class or <50 item
# C: 25 < s <= 100/3 -> groups of 3
# D: 20 < s <= 25   -> groups of 4-ish
# E: 100/6 < s <= 20 -> groups of 5-ish
# Then general small items <= 100/6.

# We'll define preferred residual capacity ranges for each class.
# The core idea: given item size s, we prefer bins whose remaining capacity r
# is close to some "ideal partner" capacity such that s+r is near 100 or near
# a good combination boundary.

def _classify(s):
    if s > 50:
        return 0
    elif s > 100.0 / 3.0:
        return 1
    elif s > 25:
        return 2
    elif s > 20:
        return 3
    elif s > 100.0 / 6.0:
        return 4
    else:
        return 5


# Precompute for each item size 1..100 the preferred residual capacity range
# (low, high) for tighter matching.
# For class 0 items (s>50): only bins with r >= s matter; we want the smallest r >= s (best fit).
# For class 1 (33.33<s<=50): we want to pair with another item so total close to 100.
#   Ideal partner is 100-s roughly, but partner may be in same class.
#   Prefer residual r in [s, 100-s] if 100-s >= s? No, s>33.3 so 100-s<66.7.
#   We prefer bins with r >= s and r in a band near 100-s to fill the bin.
# For class 2 (25<s<=33.33): groups of 3. Ideal total 100, so after one item, remaining 100-s.
#   Prefer bins with residual in [s, 67] roughly.
# Simpler: implement heuristic score.

def priority(item, bins):
    """
    Score each bin. Higher score = chosen. Ties -> first bin.
    item: int
    bins: np.ndarray int64 of remaining capacities for bins the item fits in.
    """
    s = int(item)
    n = len(bins)
    if n == 0:
        return np.zeros(0, dtype=float)

    r = bins.astype(np.float64)
    c = 100.0

    # Basic best fit: prefer smaller remaining capacity (tight fit).
    # Score = -(r - s) = s - r, so larger for smaller r.  Actually we'll build
    # a more nuanced score.

    # Start with best-fit base score.
    score = -r

    cls = _classify(s)

    # Compute preferred residual target depending on class.
    if cls == 0:
        # Large items > 50: best fit is already good.  Slight preference for
        # bins that are nearly empty if possible?  Best fit is fine.
        pass
    elif cls == 1:
        # 33.3 < s <= 50.  Want to pair with items that make sum close to 100.
        # Ideal partner size p = 100 - s, but p could be small or large.
        # Prefer bins with residual r such that r + s is close to 100, i.e. r close to 100-s.
        # But also must ensure r >= s? Not necessarily, r can be anything >= s since item fits.
        # We can pair with a smaller item later.  Prefer residual near 100-s.
        target = 100.0 - s
        # Reward closeness to target, but only if target >= s (i.e. s <= 50).
        # For s>50 target<50<s, impossible to have r near target while r>=s.
        # So for s<=50, target>=50>=s? If s<=50, target>=50>=s. yes.
        if s <= 50:
            diff = np.abs(r - target)
            # Add bonus for being close to target.
            score += 5.0 * np.exp(-diff / 10.0)
        # Also slight penalty for very large residuals (wasteful).
        # Already handled by -r.
    elif cls == 2:
        # 25 < s <= 33.33.  Groups of 3: total ~100.
        # Ideal residual after placing this item is 100 - s, and then we want
        # remaining to be splittable into two items.  Prefer bins with residual
        # in [s, 100-s]?  Actually we want to eventually fill to 100.
        # Prefer residual near 100 - s (so that remaining after is s' = 100-s-? )
        # Simpler: prefer residual in [2*s, 100-s]? Let's just aim for total 100.
        target = 100.0 - s
        # target is between 66.67 and 75.
        diff = np.abs(r - target)
        score += 3.0 * np.exp(-diff / 12.0)
    elif cls == 3:
        # 20 < s <= 25.  Groups of 4 (or 5).
        # Aim for total 100.  After one item, remaining 100-s.
        target = 100.0 - s
        diff = np.abs(r - target)
        score += 2.0 * np.exp(-diff / 15.0)
    elif cls == 4:
        # 16.67 < s <= 20.  Groups of 5-6.
        target = 100.0 - s
        diff = np.abs(r - target)
        score += 1.5 * np.exp(-diff / 20.0)
    else:
        # Very small items <= 16.67.  Best fit is good to fill gaps.
        # Slight preference for bins that are more full (smaller r) already in -r.
        pass

    # Additional general heuristic: prefer bins that are more full (smaller r),
    # which is -r already.

    # To break ties, the harness uses first bin.  We can add a tiny bias toward
    # earlier bins? No, fixed order is fine.

    return score
