import numpy as np

def priority(item, bins):
    # Best fit: minimize remaining capacity after placing the item
    return -(bins - item)
