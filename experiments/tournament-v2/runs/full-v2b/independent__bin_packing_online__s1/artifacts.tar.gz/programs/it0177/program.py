"""Online bin packing heuristic: best fit with empty-bin penalty and slight used-bin preference."""
import numpy as np


def priority(item, bins):
    """Score bins: prefer tight fits, avoid opening new bins unnecessarily.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of fitting bins, in bin order.
    """
    # Best-fit residual: smaller remaining capacity after placement is better.
    residual = bins - item

    # Identify completely unused bins (remaining capacity exactly 100).
    empty = (bins == 100)

    # Primary: smaller residual is better -> use negative residual.
    score = -residual.astype(np.float64)

    # Penalize using an empty bin: subtract a bonus so used bins win ties/close calls.
    # Magnitude chosen to be small relative to typical item sizes (mean ~40),
    # enough to break near-ties toward already-open bins without overriding fit.
    score -= 8.0 * empty

    # Slight preference for fuller bins: a tiny tie-breaker based on residual.
    # (Tighter fits already favored; this nudges equal-residual cases.)
    return score
