import numpy as np


def priority(item, bins):
    # Score bins: highest score = best choice.
    # Primary: exact fit (remaining == item).
    # Secondary: best fit by minimal leftover after placing item.
    # Add a slight preference for fuller bins to reduce fragmentation.
    leftover = bins - item  # bins are guaranteed to fit the item (>= 0)

    # Exact fit gets a large bonus; otherwise prefer smaller leftover.
    # We use negative leftover so higher score means tighter fit.
    score = -leftover.astype(np.float64)

    # Big bonus for exact fit.
    exact = leftover == 0
    if np.any(exact):
        score[exact] += 1e6

    # Prefer bins that are already more full (smaller remaining capacity before placing)
    # to avoid unnecessarily opening/using fresh bins.
    score -= bins.astype(np.float64) * 1e-3

    return score
