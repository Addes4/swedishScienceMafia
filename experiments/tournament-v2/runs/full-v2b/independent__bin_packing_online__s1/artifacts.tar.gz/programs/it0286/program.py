import numpy as np

# Online bin packing priority rule.
#
# The goal is to choose a bin that tends to minimize total bins for arrivals drawn
# i.i.d. from a fixed Weibull-shaped distribution with mean about 40.
#
# The rule below is a tuned best-fit variant:
# - Exact fit is almost always taken.
# - Otherwise, prefer bins where the remaining capacity after placement is small,
#   but not necessarily the absolute minimum: very small residuals can create hard-to-fill
#   bins, while moderately small residuals are often useful for packing future small items.
# - Unused bins (capacity 100) are slightly discouraged unless the item is large,
#   because opening a fresh bin too early can waste capacity.

def priority(item, bins):
    # bins: remaining capacities. We rank by a score; highest wins.
    # Only bins that can fit the item are shown, so bins >= item.
    rem = bins.astype(np.int64, copy=False)
    after = rem - item

    # Base score: prefer tight residual after placement.
    # We use a nonlinear penalty on residual to smooth best-fit.
    # Larger residual -> lower score.
    # The exponent slightly below 1 encourages not always taking the absolute tightest
    # when residuals are tiny.
    score = -(after.astype(np.float64) ** 0.92)

    # Exact fit bonus: taking an exact fit is usually excellent.
    score += (after == 0) * 50.0

    # Discourage opening unused bins unless the item is reasonably large.
    # For small items, using a partially-filled bin is usually better.
    # For large items, a fresh bin may be necessary and is fine.
    # unused bins have rem == 100.
    unused = rem >= 100
    if item >= 55:
        # Large item: fresh bin is acceptable, mild preference based on fit.
        score += unused * 0.5
    elif item >= 35:
        # Medium: neutral.
        score += unused * 0.0
    else:
        # Small: strongly prefer existing partially-filled bins when possible.
        score -= unused * 2.0

    # Prefer bins whose residual after placement is in a "good" range for future packing.
    # Residual around 10-40 is often useful. Residual > 70 is wasteful.
    s = after.astype(np.float64)
    score += np.where((s >= 8) & (s <= 45), 0.75, 0.0)
    score -= np.where(s > 70, 1.5, 0.0)

    # Slight preference for stable bins (more already filled) over nearly empty bins,
    # unless the item is large. This is captured by unused penalty above.
    # For non-unused, prefer bins with smaller residual slightly more directly already.

    # Tie-breaking naturally goes to first bin; return float scores.
    return score
