"""Online bin packing heuristic: residual-aware best fit.

Strategy:
  - Prefer a bin where the item fits exactly (slack 0).
  - Otherwise, strongly prefer residual capacities that equal or are close to
    frequent item sizes, so the leftover gap can be filled exactly later.
  - Break remaining ties by tightest fit (best fit).
"""

import numpy as np

# Common sizes for a Weibull-shaped distribution with mean ~40.
# Small items are relatively frequent; certain residuals are worth "reserving".
_PREFERRED_RESIDUALS = np.array(
    [0, 1, 2, 3, 5, 8, 10, 12, 15, 18, 20, 25, 30, 33, 35, 40, 45, 50, 55, 60, 66, 70],
    dtype=np.int64,
)


def priority(item, bins):
    """Score each bin; highest score wins, ties to first bin.

    item: integer size 1..100.
    bins: remaining capacities (int64), only bins that fit the item.
    """
    residual = bins.astype(np.int64) - item  # >= 0 guaranteed by harness

    # Primary: exact fit is best.
    score = np.where(residual == 0, 1_000_000.0, 0.0)

    # Secondary: reward residuals that match useful future item sizes.
    # Distance to nearest preferred residual; smaller is better.
    diff = np.abs(residual[:, None] - _PREFERRED_RESIDUALS[None, :])
    nearest = diff.min(axis=1)
    # Larger reward when residual is (close to) a common item size, and when
    # the residual is small (leaving huge gaps is wasteful).
    score += 4000.0 / (1.0 + nearest) + 1500.0 / (1.0 + residual)

    # Tertiary: tightest fit (smaller residual first).
    score -= residual * 0.5

    return score
