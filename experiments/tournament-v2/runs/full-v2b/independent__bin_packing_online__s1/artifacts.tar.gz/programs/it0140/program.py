"""Best-fit with new-bin hysteresis for online bin packing."""
import numpy as np


def priority(item, bins):
    """Rank bins so an item goes into the tightest fitting used bin if possible.

    Scores are arranged so that filled bins beat unused bins, and among bins
    that fit, the ones with least remaining capacity after placement are best.
    """
    remaining = 100 - bins
    residual_after = bins - item

    # Prefer used bins over completely empty bins, then minimize remaining
    # capacity after placement.  The large offset for empty bins prevents
    # opening a new bin when any existing bin can accept the item.
    return np.where(bins == 100, -1.0e9, -residual_after.astype(np.float64))
