import numpy as np

_state = {"items": []}


def priority(item, bins):
    # Best fit: prefer smallest remaining capacity that still fits the item.
    # Add a tiny bias favoring bins that become "well matched" and
    # discouraging leaving tiny useless gaps when a better fit exists.
    residual = bins - item  # >= 0 guaranteed

    # Base: tighter fit is better.
    score = -residual.astype(np.float64)

    # Slight preference to keep residual small; penalize leaving the bin
    # with a residual that is unlikely to be useful (very small leftover).
    # Also mildly prefer filling bins that already have the item's "partner".
    small_gap_penalty = np.where((residual > 0) & (residual < 10), residual * 0.5, 0.0)
    score -= small_gap_penalty

    # Mildly discourage using a completely empty bin (capacity 100) if an
    # existing bin can take the item well; helps delay new bin openings.
    empty = (bins == 100)
    score -= empty.astype(np.float64) * 0.1

    return score
