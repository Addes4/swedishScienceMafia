"""Online bin packing: size-class-aware best fit with residual-gap value.

The policy is essentially best fit, but instead of scoring a bin only by its
residual capacity after the item, it scores the *residual gap* left behind.
A residual gap is valuable when it is a size that future items are likely to
fit into tightly.  We estimate, online, the empirical distribution of item
sizes seen so far (in coarse integer size classes), and value a leftover gap
by the probability (mass) of items that are <= the gap, weighted toward tight
fits.  This nudges the packer away from leaving awkward small residues.

State is kept between calls but only consists of statistics of past items,
which is allowed.
"""

import numpy as np

# ---------------------------------------------------------------------------
# Online statistics
# ---------------------------------------------------------------------------
CAP = 100
_NBINS_HIST = CAP + 1          # histogram of observed item sizes 1..100
_hist = np.zeros(_NBINS_HIST, dtype=np.float64)
_count = 0.0

# exponential smoothing of the size histogram, so recent items matter more
_DECAY = 0.999

# ---------------------------------------------------------------------------
# Precomputed value of leaving a residual gap of g (0..100)
# ---------------------------------------------------------------------------
# We value a gap g by the smoothed probability mass of items that can fit in
# g, with extra weight on items that nearly fill g (tight packing).
def _build_gap_value(hist):
    total = hist.sum()
    if total <= 0:
        # fallback: uniform prior
        p = np.ones(_NBINS_HIST, dtype=np.float64)
        p[0] = 0.0
        total = p.sum()
    else:
        p = hist.copy()
        p[0] = 0.0

    # cumulative mass of items of size <= g
    cum = np.cumsum(p)

    # "tightness" weight: items close to the gap size are more valuable to
    # place now (they otherwise waste a whole bin).  Use a soft kernel.
    gvals = np.arange(_NBINS_HIST, dtype=np.float64)
    # value(g) = sum_s p[s] * w(s, g) for s <= g
    # w(s,g) = 1 + alpha * (s / g)  (favor nearly-full placements), and
    # placing an item into a gap removes g and creates g-s.
    # We approximate the immediate value as the mass that can fit times a
    # tightness bonus, minus a penalty proportional to the expected new gap.
    alpha = 0.75

    val = np.empty(_NBINS_HIST, dtype=np.float64)
    for g in range(_NBINS_HIST):
        if g <= 0:
            val[g] = -1e9
            continue
        # mass of items fitting in g
        pm = p[1:g + 1]
        if pm.size == 0:
            val[g] = -1e9
            continue
        s = np.arange(1, g + 1, dtype=np.float64)
        w = 1.0 + alpha * (s / g)           # tight fit bonus
        fit_mass = pm.sum() / total
        tight = (pm * w).sum() / total
        # expected leftover after best tight placement (weighted)
        expected_left = (pm * (g - s)).sum() / max(pm.sum(), 1e-9)
        # value: reward ability to absorb items, reward tightness, and small
        # residual gaps are less flexible (weak penalty).
        val[g] = tight * (1.0 + 0.02 * fit_mass) - 0.004 * expected_left
    return val


# ---------------------------------------------------------------------------
# Policy
# ---------------------------------------------------------------------------
_recent = []          # sliding window of recent item sizes (bounded)
_WINDOW = 400


def priority(item, bins):
    """Return a score per bin; highest score wins, ties to first bin."""
    global _count

    bins = np.asarray(bins)
    n = bins.shape[0]

    # ---- update online statistics with the arriving item -----------------
    _hist[int(item)] += 1.0
    _count += 1.0
    _recent.append(int(item))
    if len(_recent) > _WINDOW:
        del _recent[0:len(_recent) - _WINDOW]

    # ---- build a gap-valued score ---------------------------------------
    # Use histogram combining long-term counts and recent window.
    if _count > 0:
        if _count > 1.0:
            _hist *= _DECAY  # gentle forgetting
        hist = _hist.copy()
        for s in _recent:
            hist[s] += 1.0
    else:
        hist = _hist.copy()

    gap_val = _build_gap_value(hist)

    # Residual capacity in each bin after placing the item.
    residual = bins - item
    residual = np.where(residual >= 0, residual, -1)

    scores = np.empty(n, dtype=np.float64)

    # Base: prefer tight fit (best fit).  Strong enough to dominate when
    # gap values are close.
    # Primary: smallest nonnegative residual.
    # Secondary: gap value of the residual.
    # Tertiary: prefer bins already used (lower remaining capacity is handled
    #           by primary/secondary; among unused all equal, index order wins).

    for i in range(n):
        r = residual[i]
        if r < 0:
            scores[i] = -1e18
            continue
        # best-fit term: tighter fit => higher score.  Scale modestly so the
        # gap-value tie-breaker can act within near-equal residuals.
        bestfit = -float(r)
        gv = float(gap_val[int(r)])
        # Slight preference for keeping very small residuals only if they have
        # future value; otherwise avoid them.
        scores[i] = bestfit * 1.0 + gv * 6.0

    return scores
