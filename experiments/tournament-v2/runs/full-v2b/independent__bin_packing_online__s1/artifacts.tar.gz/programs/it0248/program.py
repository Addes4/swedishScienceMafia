"""Online bin packing: best fit with a small leftover-avoidance bonus."""

import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    The item is an integer 1..100, and bins holds remaining capacities.
    We use best-fit (fill tightly) but penalize leaving extremely small
    leftovers, which are unlikely to be usable by future items.
    """
    remaining_after = bins - item  # >= 0 for all provided bins

    # Base: prefer smallest remaining capacity (best fit).
    base = -remaining_after

    # Small penalty for leftovers in (0, ~20): these are mostly wasted.
    # Larger leftovers are still useful, so no penalty there.
    leftover = remaining_after.astype(np.float64)
    penalty = np.where((leftover > 0) & (leftover < 20), 1.0, 0.0)

    return base.astype(np.float64) - penalty
