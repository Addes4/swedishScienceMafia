import numpy as np


def priority(item, bins):
    """Best-fit with a small penalty for leaving tiny residual capacity.

    The arriving item must be placed immediately. The main rule is best fit:
    choose the bin with the smallest remaining capacity that still fits the
    item. This tends to leave larger holes for future items.

    A small adjustment discourages creating a bin whose remaining capacity is
    too small to be useful later: if placing the item leaves residual capacity
    below a threshold, that bin is slightly less attractive. The threshold is
    adaptive on the item size, but always small compared with normal best-fit
    differences.
    """
    rem = bins - item

    # Primary score: lower remaining capacity is better.
    score = rem.astype(np.float64)

    # Penalize residuals that are too small to fit many future items.
    # The threshold grows mildly with item size but stays small.
    threshold = 12 + item // 8
    penalty = np.where((rem >= 0) & (rem < threshold), 0.25 * (threshold - rem), 0.0)

    # Return negative score because higher score wins.
    return -(score + penalty)
