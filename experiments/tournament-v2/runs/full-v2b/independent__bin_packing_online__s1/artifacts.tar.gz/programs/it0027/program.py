import numpy as np


class _PackerState:
    def __init__(self):
        # Running histogram of observed item sizes (1..100).
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        # Cache: for each item size, probability-weighted score for common exact fits.
        self._cache_size = -1
        self._score_cache = None

    def observe(self, item):
        self.counts[item] += 1.0
        self.total += 1.0
        self._cache_size = -1

    def probs(self):
        if self.total <= 0:
            return None
        return self.counts / self.total

    def expected_match_value(self, cap):
        """Approximate value of leaving remaining capacity `cap` for future items."""
        p = self.probs()
        if p is None:
            # Early: assume roughly uniform over 1..100.
            if cap < 1:
                return 0.0
            return min(cap, 100) / 100.0
        # Value is probability mass of future items fitting exactly or nearly exactly.
        # Weight exact fit heavily, near fit modestly.
        lo = max(1, cap - 8)
        hi = min(100, cap)
        if hi < lo:
            return 0.0
        exact = p[hi] if hi <= 100 else 0.0
        near = 0.0
        for s in range(lo, hi):
            near += p[s] * (1.0 - (hi - s) / 9.0)
        return exact * 1.0 + near * 0.15


_state = _PackerState()


def priority(item, bins):
    """Hybrid best-fit with a light preference for preserving useful residual capacities."""
    _state.observe(item)

    bins = np.asarray(bins)
    n = bins.shape[0]
    if n == 0:
        return bins.astype(np.float64)

    # Base: best fit. Higher score = smaller remaining capacity after placement.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Very small nudge: prefer bins whose residual capacity has higher expected
    # future usefulness, but only enough to break close ties.
    caps = np.unique(residual)
    if caps.size > 1:
        adj = np.zeros(n, dtype=np.float64)
        # For typical sizes, evaluate a bounded number of distinct residual values.
        for cap in caps:
            if cap < 0:
                continue
            adj[residual == cap] = _state.expected_match_value(int(cap))
        score += adj * 0.02

    # Exact fit should be strongly preferred.
    exact = residual == 0
    if np.any(exact):
        score[exact] += 10.0

    # Unused bins should be chosen only when they are genuinely the tightest fit,
    # but avoid opening a new bin if an existing bin can take the item with a
    # reasonable residual. Since `bins` only includes fitting bins, unused bins
    # have cap 100 and thus already rank poorly under best-fit.
    return score
