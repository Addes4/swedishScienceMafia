import numpy as np

# State for online statistics.
_state = {
    "count": 0,
    "sum": 0.0,
}


def priority(item, bins):
    """Rank bins for an online bin-packing heuristic.

    The rule favours:
      1. exact fits,
      2. near-exact fits,
      3. bins whose remaining capacity after insertion is likely to be
         reusable for items from the known Weibull-like distribution,
      4. delaying the use of completely empty bins.
    """
    global _state

    # Keep a light running estimate of the item distribution.  This is not
    # used to fit a model, but it helps choose a sensible threshold for
    # deciding when an imperfect fit is still preferable to opening a new bin.
    _state["count"] += 1
    _state["sum"] += float(item)
    mean_item = _state["sum"] / _state["count"] if _state["count"] else 40.0

    b = bins.astype(np.float64, copy=False)

    # Residual capacity after placing the item.
    residual = b - float(item)

    # A bin with residual 0 is perfect.  Otherwise, high residual is bad:
    # it means the bin was not a tight fit.  Empty bins get an explicit
    # penalty so partially filled bins are preferred when they can absorb
    # the item without creating a very awkward residual.
    #
    # Use a smooth score rather than pure best fit.  Pure best fit can be
    # too greedy and strand medium-sized gaps; the quadratic term makes
    # the rule slightly more willing to use a bin with a moderately larger
    # gap when its resulting residual is still useful.
    score = -residual - 0.012 * residual * residual

    # Strongly prefer exact fits and small residuals.
    exact = residual == 0
    score[exact] += 5.0

    # Avoid opening new bins unless the item is large relative to what
    # remains in existing bins, or no tight fit exists.
    empty = residual == 100.0 - float(item)
    if np.any(empty):
        # If there is a non-empty bin whose residual is not too much worse
        # than opening a new bin, penalise empty bins heavily.
        nonempty = ~empty
        if np.any(nonempty):
            best_nonempty_residual = np.min(residual[nonempty])
            # The more a partially filled bin can take this item, the less
            # attractive a fresh bin is.
            empty_penalty = 1.5 + 0.05 * (100.0 - item)
            # If the item is large, opening a new bin is often unavoidable.
            if item >= 55:
                empty_penalty *= 0.35
            elif item >= 35:
                empty_penalty *= 0.7
            score[empty] -= empty_penalty
        else:
            # Only empty bins exist: no need to penalise.
            pass

    # Slight preference for earlier bins among equal scores is handled by
    # the harness (ties go to first bin), so no index adjustment is needed.
    return score
