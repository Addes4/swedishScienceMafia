import numpy as np


_HIST = np.zeros(101, dtype=np.int32)

def priority(item, bins):
    _HIST[item] += 1

    # Base best-fit: larger score means smaller remaining capacity after placing item.
    score = 100.0 - (bins - item)

    # Strongly prefer exact fits.
    score += (bins == item) * 1000.0

    # Mildly discourage leaving a gap that has recently been a common item size,
    # because such a gap may soon be filled well.
    gap = bins - item
    valid = gap >= 0
    common = np.zeros_like(score, dtype=np.float64)
    if item < 100:
        # Only consider positive gaps that fit in histogram range.
        gap_clipped = np.clip(gap, 0, 100).astype(np.int64)
        common[valid] = _HIST[gap_clipped[valid]] / (_HIST.sum() + 1.0)
    score -= common * 50.0

    # Tiny bias toward earlier bins helps ties and keeps behavior deterministic.
    score -= np.arange(len(bins), dtype=np.float64) * 1e-9
    return score
