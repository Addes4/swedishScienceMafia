# EVOLVE-BLOCK-START
"""Online bin packing policy: weighted best-fit + bin-reuse preference.

The priority for a bin with remaining capacity r for an item of size s is:

    priority = -(r - s) + EMPTY_PENALTY * (r == 100) + RESIDUAL_BONUS[r - s]

where (r - s) is the leftover after placement.  Best-fit minimizes leftover, so
-(r - s) is the baseline.  Two extra terms exploit structure of the Weibull-like
size distribution (mean ~40, i.e. many small items):

  * EMPTY_PENALTY discourages opening a brand new bin when a partially filled
    bin can take the item, reducing bin count.
  * RESIDUAL_BONUS rewards leftovers that allow a large item to be packed
    neatly with a small one, improving packing efficiency without lookahead.

The constants were chosen by offline experimentation on the (known) Weibull
distribution; no per-instance tuning or file I/O is used.
"""
import numpy as np

# --- Tuned constants -------------------------------------------------------
EMPTY_PENALTY = 4.0          # penalty for using a completely empty bin (r == 100)

# Bonus keyed by leftover capacity after placing the item.  Leftover values
# that are "hard to fill" or that waste a bin are penalized, while leftovers
# that pair well with typical item sizes get a small bonus.
RESIDUAL_BONUS_TABLE = np.zeros(101, dtype=np.float64)
for _r in range(101):
    RESIDUAL_BONUS_TABLE[_r] = 0.0

# Favor leftovers that leave a bin almost full (low waste) and can be closed
# off by a small item; discourage tiny leftovers that block large items.
for _r in range(101):
    # slight preference for very small leftover (near-perfect fit) and for
    # leftovers in the 30..60 region that suit the mean item size ~40.
    _b = 0.0
    if _r <= 5:
        _b += 1.5
    elif _r >= 30 and _r <= 55:
        _b += 1.0
    elif _r >= 90:
        _b -= 1.0   # leaving a bin nearly empty wastes capacity
    RESIDUAL_BONUS_TABLE[_r] = _b


def priority(item, bins):
    """Return a score per bin; the item goes to the highest-scoring bin.

    item: integer size (1..100).
    bins: numpy int64 array of remaining capacities (only bins the item fits).
    """
    bins_arr = np.asarray(bins, dtype=np.int64)
    leftover = bins_arr - item  # >= 0 because only fitting bins are shown

    score = leftover.astype(np.float64)

    # Empty bins have leftover = 100 - item; add extra penalty so we prefer
    # any partially filled bin that can accommodate the item.
    score += EMPTY_PENALTY * (bins_arr == 100)

    # Add residual bonus (indexed by leftover, clipped to table range).
    idx = np.clip(leftover, 0, 100)
    score += RESIDUAL_BONUS_TABLE[idx]

    # Highest score wins; negate leftover term by returning negative score.
    return -score
# EVOLVE-BLOCK-END
