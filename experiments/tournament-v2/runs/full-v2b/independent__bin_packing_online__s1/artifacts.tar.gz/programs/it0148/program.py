import numpy as np


def priority(item, bins):
    # Best-fit style: prefer the smallest remaining capacity that still fits item.
    # We score higher for bins closer to being exactly filled by the item.
    #
    # Tie-breaking / refinement: when two bins leave similar slack, favor the one
    # whose post-placement remainder is >= some useful threshold (so the leftover
    # bin stays reusable), and also slightly favor already-fuller bins.

    left = bins - item  # remaining capacity after placing (>=0 by construction)

    # Primary: best fit -> smaller leftover is better (closer fit)
    score = -left.astype(np.float64)

    # Secondary nudge: avoid leaving a tiny unusable remainder (1..9) when an
    # alternative with the same tight fit exists. Penalize tiny leftovers slightly.
    tiny = (left > 0) & (left < 10)
    score -= tiny * 0.5

    # Tertiary nudge: minor preference to bins that are already more full
    # (i.e., smaller current remaining capacity) to keep large-empty bins for big items.
    score -= 0.001 * bins.astype(np.float64)

    return score
