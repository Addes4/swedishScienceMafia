import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin whose remaining capacity after placing item is smallest.
    # Score: -(bins - item), so tighter fits (larger original fill) get higher scores.
    return -(bins - item)
