import numpy as np


class _PackerState:
    def __init__(self):
        self.calls = 0


_state = _PackerState()


def priority(item, bins):
    # Best-fit with a gentle harmonic-style tie-break:
    # Prefer the smallest remaining capacity after placement.
    # If several bins give the same residual, prefer the one that is already
    # more filled (smaller residual), which is naturally the same here.
    #
    # The extra term below makes fully opening a new bin slightly less attractive
    # than using an existing bin when both leave a similar residual.
    _state.calls += 1

    residual = bins - item

    # Higher score is better.
    # Main rule: best fit -> smaller residual wins.
    # Small correction: if residual is zero, strongly prefer that bin.
    # Otherwise penalize very large residual (new/empty bins) slightly.
    score = -residual.astype(np.float64)

    # Strong bonus for exact fit.
    score += (residual == 0).astype(np.float64) * 20.0

    # Mild bonus for bins that become quite full but not exact.
    # This helps packing density without changing the dominant best-fit order too much.
    score += np.where((residual > 0) & (residual <= 5), 2.0, 0.0)
    score += np.where((residual > 5) & (residual <= 15), 0.5, 0.0)

    # Slight preference against opening brand-new bins when an existing bin is close.
    score -= (bins == 100).astype(np.float64) * 0.25

    return score
