import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.anchor = None  # index of the currently kept-empty anchor bin


_state = _State()


def priority(item, bins):
    """Adaptive best-fit / anchor-preserving bin choice."""
    n = len(bins)
    _state.calls += 1

    # Identify the empty bin (remaining capacity 100) with smallest index.
    # Bins array is in fixed bin order; unused bins have capacity 100.
    empty_mask = bins == 100

    # Score array: default best-fit (tightest fit first)
    scores = -(bins - item).astype(np.float64)

    # Anchor preservation: keep exactly one full-empty bin available for large items.
    # Find the first empty bin; protect it unless the item is large enough that
    # consuming it is worthwhile, or no other reasonable bin exists.
    if empty_mask.any():
        anchor = int(np.argmax(empty_mask))
        # If the item is large (close to capacity), using a fresh bin is fine.
        # Otherwise, penalize the anchor bin so smaller items prefer already-open bins.
        if item < 70:
            scores[anchor] -= 1e6
        else:
            # For large items, using the anchor is acceptable; don't protect strongly.
            pass

    # Slight preference to bins that become "nicely full" after placement:
    # residual r = bins - item; avoid tiny leftovers to reduce fragmentation.
    residual = bins - item
    # Small bonus for residual near a small threshold (highly packed bin).
    frag_bonus = np.where(residual <= 3, 0.5, 0.0)
    scores += frag_bonus

    return scores
