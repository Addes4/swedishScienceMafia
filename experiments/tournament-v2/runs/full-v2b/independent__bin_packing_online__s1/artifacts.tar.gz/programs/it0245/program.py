import numpy as np


def priority(item, bins):
    """Rank bins by best fit: prefer the smallest resulting remaining capacity.

    A small preference is given to bins that fit exactly, since such placements
    tend to reduce future fragmentation without hurting the greedy structure.
    """
    remaining_after = bins - item
    exact_bonus = (remaining_after == 0).astype(np.float64)
    return exact_bonus * 0.5 - remaining_after
