import numpy as np


class _State:
    def __init__(self):
        self.calls = 0

_state = _State()


def priority(item, bins):
    """Best-fit priority with a mild penalty for opening fresh/empty bins.

    The item is assigned to the bin maximizing the returned score.
    Higher score = better placement.
    """
    # Primary: best fit -> smallest remaining capacity after placing item.
    # score = -(bins - item) = item - bins, larger for bins with less free space.
    score = (item - bins).astype(np.float64)

    # Mild penalty for untouched bins (remaining capacity == 100).
    # This discourages opening a new bin when an existing bin can fit reasonably.
    # Penalty is small enough not to override a good tight fit substantially.
    empty_mask = (bins == 100)
    if empty_mask.any():
        score[empty_mask] -= 0.5

    return score
