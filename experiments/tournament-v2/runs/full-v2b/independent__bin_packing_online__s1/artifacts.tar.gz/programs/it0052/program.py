import numpy as np


def priority(item, bins):
    # Best fit: rank by remaining capacity after placing the item.
    # Smaller residual (tighter fit) => higher score.
    # Secondary preference: among equal residuals, prefer higher bin index
    # (more recently opened), which tends to pack better.
    residual = bins - item
    n = residual.shape[0]
    eps = 1e-9
    idx = np.arange(n, dtype=np.float64)
    return -residual + eps * idx
