import numpy as np

_STATE = {"sum": 0.0, "count": 0, "res_min": 8.0}

def priority(item, bins):
    st = _STATE
    # update running mean estimate (Weibull mean ~40)
    st["sum"] += item
    st["count"] += 1
    mean = st["sum"] / st["count"] if st["count"] else 40.0
    # minimum useful residual: don't leave a gap too small to hold typical small items
    # small items often appear even with mean 40; keep threshold modest and adaptive
    if st["count"] < 50:
        res_min = 8.0
    else:
        res_min = max(8.0, min(25.0, 0.35 * mean * 0.5))

    residual = bins - item  # remaining capacity after placing item
    # prefer smallest residual, but penalize residuals below res_min
    score = -residual.astype(np.float64)
    penalty = np.where(residual < res_min, (res_min - residual).astype(np.float64) * 2.0, 0.0)
    score -= penalty
    # tiny bias toward lower index (older bins) to keep fresh capacity in newer bins
    score += np.arange(len(bins), dtype=np.float64) * 1e-6
    return score
