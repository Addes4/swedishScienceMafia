import numpy as np


def priority(item, bins):
    """Rank bins: prefer tightest fit, then lower indices.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins that can fit the item.
    """
    # Primary objective: smallest remaining capacity after placing the item.
    # This is equivalent to maximizing -(bins - item), i.e., preferring bins
    # whose residual capacity equals item most closely.
    residual = bins - item

    # For unused bins (capacity 100), residual is large; best-fit already avoids them.
    # Add a small index bias so that among equally good fits we use earlier bins,
    # which is harmless and can reduce fragmentation in rare ties.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)

    # Scale so residual dominates; index only breaks exact ties.
    return -residual.astype(np.float64) * 1000.0 - idx
