import numpy as np

def priority(item, bins):
    # Best-fit variant: prefer bins where residual after placing is small,
    # but avoid exact-fit (residual 0) slightly to preserve flexibility.
    residual = bins - item
    score = -residual.astype(np.float64)
    # Penalize exact fit (residual 0) by a small amount
    score[residual == 0] -= 0.5
    # Slight bonus for already-used bins (residual < 100) to consolidate
    score[bins < 100] += 0.01
    return score
