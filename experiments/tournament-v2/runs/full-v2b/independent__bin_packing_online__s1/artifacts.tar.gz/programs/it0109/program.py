"""Stateful hybrid best-fit bin packing priority."""

import numpy as np


class _State:
    """Running stats on arriving items to shape residual-fit preferences."""
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.sumsq = 0.0
        # approximate item-size histogram (bucketed), for future-fit scoring
        self.hist = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.n += 1
        self.sum += item
        self.sumsq += item * item
        self.hist[item] += 1.0

    def mean(self):
        return self.sum / self.n if self.n else 40.0

    def std(self):
        if self.n < 2:
            return 20.0
        m = self.mean()
        v = self.sumsq / self.n - m * m
        return np.sqrt(v) if v > 0 else 1.0

    def typical_sizes(self):
        """Return a small array of sizes that appear often (used as target residuals)."""
        h = self.hist
        total = h.sum()
        if total < 5:
            return np.array([20.0, 40.0, 60.0, 80.0])
        # pick top-mass sizes (rounded)
        idx = np.nonzero(h)[0]
        if idx.size == 0:
            return np.array([40.0])
        return idx.astype(np.float64)


_STATE = _State()


def priority(item, bins):
    """Best fit, plus a mild preference for residuals that match typical item sizes."""
    bins = np.asarray(bins)
    _STATE.update(item)

    leftover = bins - item  # remaining capacity after placing item

    # Primary: best fit -> prefer smaller leftover. Use negative leftover.
    score = -leftover.astype(np.float64)

    # Secondary (small weight): prefer residuals that are likely to be exactly fillable
    # by common item sizes, reducing fragmentation. Compute distance to nearest
    # "good" leftover (a typical item size or 0).
    typ = _STATE.typical_sizes()
    if typ.size:
        # distance from leftover to the closest typical size
        diff = np.abs(leftover[:, None] - typ[None, :])
        dmin = diff.min(axis=1)
        # Also reward residual == 0 (perfect fill)
        perfect = (leftover == 0).astype(np.float64)
        score += 0.05 * (-dmin) + 5.0 * perfect

    # Very small tie-break to prefer lower-index bins deterministically (already first-tie),
    # no need to perturb.
    return score
