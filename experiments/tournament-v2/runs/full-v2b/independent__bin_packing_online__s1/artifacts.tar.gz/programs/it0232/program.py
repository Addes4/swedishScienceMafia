import numpy as np


def priority(item, bins):
    """Rank bins for online bin packing.

    The main idea is best-fit, but with a small preference for keeping
    apparently well-used bins together instead of spreading items across
    many partially filled bins.  Since unused bins have remaining capacity
    100, subtracting a usage bonus discourages opening a new bin unless the
    resulting fit is substantially better.
    """
    # Best-fit component: smaller remaining capacity after placement is better.
    leftover = bins - item

    # Reward bins that are already reasonably full, but do not overwhelm
    # the primary best-fit objective.  Remaining cap 100 means unused bin.
    used = bins < 100

    # A modest bonus for placing into an already used bin.
    bonus = np.where(used, 0.5, 0.0)

    # Strongly reward leaving a very small remainder, which usually reduces
    # fragmentation and helps pack items tightly.
    tight_bonus = np.where(leftover <= 5, 1.0, 0.0)

    return -(leftover.astype(np.float64)) + bonus + tight_bonus
