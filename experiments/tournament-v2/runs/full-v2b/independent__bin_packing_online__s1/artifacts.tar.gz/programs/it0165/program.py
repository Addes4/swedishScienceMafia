"""Online bin packing priority rule: modified best fit with new-bin penalty.

Best fit alone tends to leave many partially-filled bins.  Adding a modest
penalty for choosing an empty bin (remaining capacity 100, possibly minus the
item) encourages filling existing bins before opening new ones, which lowers
the total bin count on Weibull-ish item distributions around mean 40.
"""

import numpy as np

# Penalty (in capacity units) applied to bins that are still completely empty.
# A small positive value biases the packer toward used bins without destroying
# the tight-fit ordering among non-empty bins.
_NEW_BIN_PENALTY = 3.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    The base score is the negative leftover capacity after placing the item
    (i.e. best fit).  Bins that are currently empty (remaining capacity 100)
    get a fixed penalty so that, all else equal, we prefer packing into a bin
    that is already open.
    """
    residual = bins - item                 # remaining space after placing item
    score = -residual.astype(np.float64)   # tighter fit -> higher score
    empty_mask = bins == 100               # unused bins all start at 100
    score[empty_mask] -= _NEW_BIN_PENALTY
    return score
