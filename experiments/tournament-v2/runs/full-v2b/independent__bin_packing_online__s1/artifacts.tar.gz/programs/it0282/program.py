"""Adaptive best-fit with fragmentation-aware scoring for online bin packing.

The item is placed into the bin with the smallest residual capacity that is still
at least `item`, but ties and near-ties are broken by a secondary score that
encourages filling bins that are already fairly full while avoiding leaving
awkward medium residuals.  This is essentially best-fit with a small
tie-preserving perturbation based on the residual plus the item size.
"""
import numpy as np


def priority(item, bins):
    # Residual after placing item in each bin.
    residual = bins - item

    # Primary: prefer tighter fits (smaller residual).  Since higher score wins,
    # we negate residual.  Ties (same residual) keep bin order.
    # Secondary: slight preference for bins that become "well filled" rather than
    # leaving a residual that is neither tiny nor large.  The term below is small
    # and non-breaking for exact ties because integer residuals yield distinct
    # scores only when residuals differ.
    #
    # score = -residual - alpha * f(residual), where f is a mild penalty for
    # residuals in the middle range (fragmentation-prone sizes).
    alpha = 1e-6

    # A smooth penalty centered around half capacity: residuals near 50 are worst
    # for future packing, tiny residuals are best.
    # Use a quadratic bump that is zero at 0 and 100.
    frag = (residual * (100 - residual)).astype(np.float64)

    score = -residual.astype(np.float64) - alpha * frag
    return score
