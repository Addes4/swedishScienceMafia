import numpy as np


def priority(item, bins):
    """Best-fit style priority with residual smoothing.

    The item goes to the bin where it fits most tightly, but we slightly
    penalize leaving either very little or very much room, which avoids
    fragmenting bins on distributions with many medium-sized items.
    """
    rem_after = bins - item

    # Primary: minimize remaining capacity after placing the item.
    # Secondary: prefer bins that are not completely empty and not almost full,
    # which spreads risk and reduces future fragmentation.
    score = -rem_after.astype(np.float64)

    # Small reward for using bins with a moderate residual, discouraging
    # both near-exact fills that create tiny unusable gaps and perfect
    # empty bins that waste a fresh bin.
    mid = 50.0
    score += 0.02 * (1.0 - np.abs(rem_after.astype(np.float64) - mid) / mid)

    return score
