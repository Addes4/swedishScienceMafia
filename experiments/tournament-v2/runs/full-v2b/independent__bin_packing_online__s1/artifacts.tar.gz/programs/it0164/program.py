import numpy as np


# Persistent state: track how many items we have seen and simple stats.
# This lets us adapt the tie-breaking slightly without seeing the future.
_STATE = {
    "n_items": 0,
    "sum_size": 0.0,
}


def priority(item, bins):
    """
    Score each bin: highest score wins, ties to earliest bin.

    Core idea: Best-Fit. The item should go to the bin where the leftover
    capacity after placement is smallest (tightest fit). This minimizes
    wasted space and tends to reduce total bins used.

    Tie-breaking: many bins may give the same leftover capacity. Among those,
    prefer bins that are currently less full? Actually, for best-fit the
    standard rule is just minimize leftover. When leftovers tie, choosing
    the bin with the larger original... but we only have remaining capacity.

    If multiple bins have equal leftover after placement (bins - item equal),
    that means their remaining capacities are equal too. Then tie goes to
    first bin automatically, which is fine.

    We add a very small secondary term to break near-ties in a way that
    favors filling already-partially-used bins (concentrating items), which
    helps close bins and reduce open-bin count.

    The scoring: primary = -(leftover) => smaller leftover is better.
    Since scores are compared with >, higher score = better.
    So score = -(bins - item) = item - bins. Smaller bin remaining => higher.

    Add tiny epsilon based on bin index to keep first-bin tie-break consistent
    with harness (it already does first on ties, so not needed).

    We also incorporate a mild preference for bins that are currently
    non-empty (remaining < 100) to encourage consolidation, reducing the
    number of partially-filled open bins.

    Actually best-fit already does this implicitly: tightest fits are
    usually in already-used bins. For items larger than 50, tightest fit
    may be an empty bin (100-item leftover) if no used bin fits well.

    We keep it simple and robust: pure best fit with a small consolidation
    bonus.
    """
    leftover = bins - item  # remaining capacity after placing item, >= 0

    # Primary: prefer smallest leftover (tightest fit).
    score = -leftover.astype(np.float64)

    # Secondary tiny bonus: prefer bins that are already partially filled
    # (remaining < 100), i.e., used bins, to encourage consolidation.
    used = (bins < 100)
    score += used.astype(np.float64) * 1e-6

    # Tertiary: slightly prefer bins with smaller remaining capacity (more full)
    # to pack densely. Already captured by primary mostly.
    score -= bins.astype(np.float64) * 1e-9

    return score
