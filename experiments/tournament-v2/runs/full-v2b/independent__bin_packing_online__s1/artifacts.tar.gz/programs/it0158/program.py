import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "sumsq": 0.0,
    "mean": 40.0,
}


def priority(item, bins):
    s = _state
    s["n"] += 1
    s["sum"] += item
    s["sumsq"] += item * item
    n = s["n"]
    mean = s["sum"] / n
    var = s["sumsq"] / n - mean * mean
    if var < 1.0:
        var = 1.0
    sd = var ** 0.5
    s["mean"] = mean

    rem = bins.astype(np.float64)

    # Best-fit: prefer the bin whose remaining capacity is closest to item.
    score = -(rem - item)

    # Avoid opening/using empty bins unless the item is large relative to the
    # observed distribution: reward non-full used bins slightly, and penalize
    # pristine bins when the item is not unusually large.
    used = rem < 100.0
    empty = rem == 100.0

    large = item > (mean + 0.75 * sd)

    # Slight bonus for used bins that still have room, encouraging packing.
    score += 0.25 * used

    # Small penalty for pristine bins for small/medium items; remove it for
    # large items where opening a fresh bin is often necessary.
    if not large:
        score -= 0.5 * empty

    # Favor leaving a reasonable leftover; avoid tiny unusable remainders.
    leftover = rem - item
    score -= 0.01 * (leftover < 0.35 * mean)

    return score
