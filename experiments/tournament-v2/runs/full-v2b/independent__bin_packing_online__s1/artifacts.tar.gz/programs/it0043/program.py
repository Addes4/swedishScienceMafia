"""Adaptive best-fit for online bin packing.

The core idea: classic best-fit tends to be strong for online bin packing, but we can
improve it by biasing the choice toward bins whose remaining capacity after placement is
"useful" for future items.  We maintain an online histogram of arriving item sizes and,
for each candidate bin, estimate the expected waste that would remain if the item were
placed there: a leftover is "good" if some typical future item size can fill it well,
and "bad" if it is an awkward size that likely becomes permanent waste.

We combine:
  * a strong best-fit term (prefer tightest fit),
  * a small learned residual-quality term derived from the observed size histogram.

The learned term is kept small so the algorithm remains robust (best-fit dominance) but
can break ties toward leaving easily-reusable fragments.
"""

import numpy as np

# ---- module-level state (persists across calls within an instance) ----
_HIST = np.zeros(101, dtype=np.float64)   # smoothed histogram of item sizes
_TOTAL = 0.0                              # total weight observed
_CALLS = 0

# Typical "filler" item sizes to probe: we track a distribution and reward leftovers
# that match common future item sizes.
_ITEMS = np.arange(1, 101, dtype=np.float64)


def _prob(size):
    """Smoothed probability that a future item has the given size (1..100)."""
    if _TOTAL <= 0.0:
        # uninformative prior: prefer all sizes roughly equally
        return 1.0 / 100.0
    return _HIST[int(size)] / _TOTAL


def priority(item, bins):
    global _TOTAL, _CALLS

    _CALLS += 1

    # ---- update the observed size histogram (with slight smoothing / decay) ----
    # Exponentiated-decay style: shrink everything a touch and add the new item.
    if _TOTAL > 0.0:
        decay = 0.995
        _HIST *= decay
        _TOTAL *= decay
    _HIST[item] += 1.0
    _TOTAL += 1.0

    # ---- compute a future-usefulness score of each possible leftover ----
    # For a leftover capacity L, the expected "value" is the probability that a random
    # future item size s <= L occurs, weighted to emphasize near-exact fits (so the
    # leftover can be fully consumed).  High value => good leftover.
    def leftover_value(L):
        if L <= 0:
            return -1e9
        # probability mass of item sizes s <= L, tilted toward s close to L
        sizes = _ITEMS[:_ if False else 0]  # placeholder, replaced below
        return 0.0

    # Vectorized leftover value: for each bin capacity L, sum over s<=L of prob(s)*fit
    # where fit is large when s close to L (leaves small residue) and also when the
    # residue L-s is itself a common size.
    # We precompute cumulative arrays once per call (cheap, <=101 entries).

    # probability vector
    if _TOTAL > 0.0:
        p = _HIST / _TOTAL
    else:
        p = np.full(101, 1.0 / 100.0)

    def bin_score(remain_after):
        # remain_after: array of remaining capacities AFTER placing the item.
        # We want to reward leftovers that are likely to be filled exactly or nearly.
        r = remain_after
        # index-safe
        idx = np.clip(r, 0, 100).astype(np.int64)
        # expected chance that some future item exactly matches r (perfect fill)
        exact = p[idx] if p.ndim == 1 else np.zeros_like(r, dtype=np.float64)
        # expected best near-fill: max over s<=r of p[s] * closeness
        # approximate with: probability mass up to r times average closeness, plus a
        # small bonus for small leftovers (easy to fully pack) and zero leftover.
        cum = np.concatenate(([0.0], np.cumsum(p)))  # cum[k] = sum_{s<k} p[s]
        cum = np.clip(cum, 0.0, 1.0)
        mass_up_to = cum[np.clip(idx, 0, 100)]
        # closeness: leftover r filled by item s leaving r-s; reward small |r - s|
        # use probability of an item in [r-2, r]
        lo = np.clip(idx - 2, 0, 100)
        near = cum[np.clip(idx + 1, 0, 100)] - cum[lo]
        return 2.0 * exact + 1.5 * near + 0.5 * mass_up_to + 0.0 * (idx == 0)

    remain_after = bins - item
    bf = -(bins - item).astype(np.float64)          # best fit: tightest first
    # leftover usefulness: reward remain_after that can be consumed well by future items
    lu = bin_score(remain_after)
    # Also slightly prefer *smaller* leftover that is not tiny-awkward, and zero exact fill.
    exact_zero = (remain_after == 0).astype(np.float64) * 1.0

    # Combine: best-fit dominates; learned usefulness breaks ties.
    score = bf * 1.0 + lu * 0.35 + exact_zero * 0.5
    return score
