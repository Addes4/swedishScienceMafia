"""Adaptive best-fit bin packing priority rule.

The item goes to the bin that fits it most tightly, which minimizes wasted
space and tends to keep few bins open.  A tiny tie-breaking bonus is given
to already-used bins so that partially filled bins are consolidated before
opening a fresh bin, and the scoring is made deterministic and monotone.
"""

import numpy as np

# Class-level state for light adaptation (kept simple to avoid overfitting).
_last_item = 0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    Strategy: best fit (smallest remaining capacity after placing the item),
    with a small bonus for bins that are already partially used so that we
    pack existing bins before touching empty ones.
    """
    global _last_item

    # Remaining capacity after placing the item.  Smaller is a tighter fit.
    leftover = bins - item

    # Base score: prefer tight fits.  Use a large negative scale so that the
    # tie-breaking term below never overturns the primary ordering.
    score = -leftover.astype(np.float64)

    # Tie-breaking bonus: prefer bins that are not completely empty (index of
    # fully unused bins has remaining capacity 100).  This encourages filling
    # partially used bins first and avoids scattering items.
    used_bonus = (bins < 100).astype(np.float64) * 0.5

    # Slight extra preference for a bin whose new remaining capacity matches
    # the current item size (i.e., leaves room for another identical item),
    # a cheap heuristic that tends to improve packing efficiency.
    match_bonus = (leftover == item).astype(np.float64) * 0.25

    score = score + used_bonus + match_bonus

    _last_item = item
    return score
# EVOLVE-BLOCK-END
