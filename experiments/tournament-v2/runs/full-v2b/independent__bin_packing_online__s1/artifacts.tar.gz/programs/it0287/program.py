import numpy as np

_STATE = {
    "n": 0,
    "sum": 0,
    "small": 0,
    "large": 0,
    "last_small_item": 0,
    "small_streak": 0,
}


def priority(item, bins):
    st = _STATE
    st["n"] += 1
    st["sum"] += int(item)

    is_small = item <= 30
    is_large = item >= 55

    if is_small:
        st["small"] += 1
        st["small_streak"] += 1
        st["last_small_item"] = int(item)
    else:
        st["small_streak"] = 0

    if is_large:
        st["large"] += 1

    n = st["n"]
    avg = st["sum"] / n
    small_frac = st["small"] / n
    large_frac = st["large"] / n

    # Mostly best fit: prefer the tightest residual that still fits.
    # When there has been a run of small items, slightly favor bins with
    # residuals that can absorb a following small item without wasting space.
    if st["small_streak"] >= 4 and small_frac > 0.45:
        # Anti-fragmentation phase: prefer residual just above the item,
        # but add a mild preference for residuals that are not too large.
        residual = bins - item
        # Reward residuals that leave usable small-item space (<= 30)
        # and penalize residuals that are nearly empty.
        usable = np.where(residual <= 30, 1.0, 0.0)
        return usable * 100.0 - residual.astype(np.float64) + item * 0.01
    else:
        # Best fit: maximize -(residual), i.e. smallest remaining capacity.
        return -(bins - item).astype(np.float64)
