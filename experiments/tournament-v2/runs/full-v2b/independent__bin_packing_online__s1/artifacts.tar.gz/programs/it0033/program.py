"""Best fit with empty-bin tie-breaking tweaks."""
import numpy as np


def priority(item, bins):
    """Score bins; item goes to the highest-scoring bin (first on ties)."""
    # Base: best fit -> smaller resulting capacity is better.
    residual = bins - item

    # Bonus for exact fill (leaves zero). This strongly prefers perfect fits.
    exact = (residual == 0)

    # Slight penalty for opening a brand-new empty bin (residual 100-item),
    # to save empties for later large items when a nonempty bin also fits.
    is_empty = (bins == 100)

    # Main score: negative residual (tighter fit is higher).
    score = -residual.astype(np.float64)

    # Exact fill gets a large boost so it beats a merely tight fit.
    score += exact.astype(np.float64) * 1000.0

    # Penalize using an empty bin when alternatives exist.
    score -= is_empty.astype(np.float64) * (0.5 - 1e-6)

    return score
