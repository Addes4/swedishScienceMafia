import numpy as np

def priority(item, bins):
    T = 20.0
    rem = bins - item
    # compute penalty for small remainders
    # we only penalize if rem > 0 and rem < T
    # penalty = (T - rem) * (item / T)
    mask = (rem > 0) & (rem < T)
    penalty = np.where(mask, (T - rem) * (item / T), 0.0)
    score = -rem - penalty
    return score
