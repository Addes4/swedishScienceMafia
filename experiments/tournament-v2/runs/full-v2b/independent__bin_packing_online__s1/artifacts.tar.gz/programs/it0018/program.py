import numpy as np

# Module-level state, not used heavily, but kept for clarity.
_state = {}

def priority(item, bins):
    """Score bins to place `item` using a tuned best-fit / residual-utility rule.

    item: int size 1..100
    bins: np.int64 array of remaining capacities (only bins the item fits in)
    Returns score array; highest score wins, ties to first bin.
    """
    rem_after = bins - item  # residual capacity if item placed here

    # Best-fit: prefer smaller residual after placement, i.e. tighter fit.
    # But we penalize residuals that are very small but nonzero, since they
    # waste space. Residuals of 0 are perfect. Unused bins (bins==100) are
    # treated specially: prefer filling partially used bins first.
    score = -rem_after.astype(np.float64)

    # Bonus for exact fit
    score += (rem_after == 0) * 1000.0

    # Penalize tiny nonzero residuals (wasted slivers)
    # residual 1..5 gets a penalty proportional to how small it is
    sliver_mask = (rem_after > 0) & (rem_after < 6)
    score -= sliver_mask * (10.0 - rem_after)

    # Deprioritize completely unused bins slightly so we consolidate
    unused = (bins == 100)
    score -= unused * 50.0

    return score
