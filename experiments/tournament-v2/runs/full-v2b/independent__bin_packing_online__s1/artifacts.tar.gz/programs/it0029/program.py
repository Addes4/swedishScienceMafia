"""Online bin packing heuristic: protected best fit.

Score = preference for the bin with the smallest remaining capacity that still
fits the item (best fit), but with a small correction that penalizes creating
a residual gap too small to accept a typical incoming item, and a small bonus
for keeping some room in bins that are nearly full already handled implicitly.

The function keeps light state (running mean item size) across calls to adapt.
"""
import numpy as np


_STATE = {
    "sum": 0.0,
    "n": 0,
}


def priority(item, bins):
    # Update running statistics about arriving items (used only for tuning).
    _STATE["sum"] += float(item)
    _STATE["n"] += 1
    mean_item = _STATE["sum"] / _STATE["n"]

    # Remaining capacity after placing the item in each bin.
    # bins contains only bins the item fits in, so residual >= 0.
    residual = bins - item

    # Base: strong preference for tightest fit (small residual).
    score = -residual.astype(np.float64)

    # Penalize creating an unusably small gap.  A gap is useless if it is
    # smaller than the smallest item that is reasonably likely; approximate
    # that by a fraction of the running mean.  This mildly discourages
    # fragmenting bins into slivers.
    useless = max(1.0, 0.25 * mean_item)
    small = np.maximum(0.0, useless - residual.astype(np.float64))
    score -= 0.5 * small

    # Slight bonus for using bins that are already partially filled
    # (i.e. residual not equal to full capacity minus item), which
    # consolidates items instead of opening fresh bins.
    full_res = 100.0 - float(item)
    used_fraction = 1.0 - residual.astype(np.float64) / max(1.0, full_res)
    score += 1e-3 * used_fraction

    return score
