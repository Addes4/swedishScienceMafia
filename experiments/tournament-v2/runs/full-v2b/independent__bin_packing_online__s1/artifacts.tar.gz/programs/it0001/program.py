import numpy as np

_rng = np.random.default_rng(12345)

def priority(item, bins):
    # Best-fit: prefer bins that become as full as possible
    rem_after = bins - item

    # Penalize small leftover fragments that are too small to be useful
    # (assuming min item size ~1, but values < item are impossible anyway)
    score = -rem_after.astype(np.float64)

    # Slight randomization to avoid pathological ties and add robustness
    score += _rng.random(len(bins)) * 1e-3

    return score
