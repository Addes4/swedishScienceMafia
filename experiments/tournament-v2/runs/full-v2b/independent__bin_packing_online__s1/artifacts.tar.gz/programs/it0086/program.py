"""Best-fit bin packing with aging: fill older bins first among near-equal fits."""
import numpy as np

# State: bins are presented in fixed index order. We track the "age" of each bin
# (number of items placed after the bin was opened). Aging promotes reusing older
# partially-filled bins over freshly opened bins with similar fit, which tends to
# reduce fragmentation and close bins sooner.

_state = {
    "open_time": [],   # index -> call number when first seen as a partially filled bin
    "open": [],        # index -> bool, currently has been used
    "call": 0,
    "used": [],        # index -> number of items placed into bin
}


def _ensure(n):
    while len(_state["open"]) < n:
        _state["open"].append(False)
        _state["used"].append(0)
        _state["open_time"].append(_state["call"])


def priority(item, bins):
    _state["call"] += 1
    n = len(bins)
    _ensure(n)

    b = np.asarray(bins, dtype=np.int64)
    open_arr = np.array(_state["open"][:n], dtype=bool)
    # A bin counts as "open" (already in use) if its remaining capacity < 100.
    in_use = b < 100
    _state["open"] = in_use.tolist()
    for i in range(n):
        if in_use[i] and _state["used"][i] == 0:
            _state["used"][i] = 1
            _state["open_time"][i] = _state["call"]

    # Tighter fit -> higher score. bins - item is leftover after placing.
    leftover = b - item

    # Aging bonus: bins open longer get a bonus, scaled so it can break near-ties
    # without overriding substantial fit differences.
    age = np.array(
        [_state["call"] - _state["open_time"][i] if in_use[i] else 0 for i in range(n)],
        dtype=np.float64,
    )

    # Base: strongly prefer tight fit (small leftover). Use negative leftover so
    # smaller leftover -> higher score. If item exactly fills, leftover == 0 best.
    score = -leftover.astype(np.float64)

    # Small bonus for older bins; scale tiny relative to fit resolution (1 unit).
    score += 0.01 * age

    # Tiny deterministic tiebreaker favoring earlier bin index (harness already
    # breaks ties by first index, but this makes ordering explicit/stable).
    score -= 1e-6 * np.arange(n, dtype=np.float64)

    return score
