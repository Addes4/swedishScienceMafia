import numpy as np


def priority(item, bins):
    """Best-fit with a slight bonus for tight/exact fits."""
    slack = bins - item
    # Strongly prefer bins with the least remaining space after placing the item.
    # A tiny extra preference for exact/near-exact fits reduces fragmentation.
    score = -(slack.astype(np.float64))
    score += 1.0 / (slack + 1.0)
    return score
