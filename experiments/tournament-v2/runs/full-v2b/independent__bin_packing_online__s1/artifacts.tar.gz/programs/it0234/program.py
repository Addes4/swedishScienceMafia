import numpy as np


class _Priority:
    def __init__(self):
        # Counts of item sizes seen so far (1..100). Start zero.
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def update(self, item):
        self.counts[item] += 1.0
        self.total += 1.0

    def reusability_score(self, leftover):
        """Higher if leftover capacity is a plausible future item size."""
        if leftover <= 0 or self.total == 0:
            return 0.0
        # Probability that a future item exactly matches this leftover.
        p_exact = self.counts[leftover] / self.total
        # Also reward leftovers that are common enough nearby.
        lo = max(1, leftover - 3)
        hi = min(100, leftover + 3)
        p_near = self.counts[lo:hi + 1].sum() / self.total
        return p_exact + 0.25 * p_near


_state = _Priority()


def priority(item, bins):
    global _state
    item = int(item)
    bins = np.asarray(bins)

    # Base score: best fit = smallest leftover capacity (tightest fit).
    leftover = bins - item
    base = -leftover.astype(np.float64)

    # Bonus for leaving a leftover capacity that is likely usable later.
    # We only care about bins that actually fit (leftover >= 0).
    if _state.total > 0:
        bonus = np.zeros(len(bins), dtype=np.float64)
        valid = leftover >= 0
        if np.any(valid):
            # Vectorized enough for numpy arrays; leftovers are small ints.
            lo = leftover[valid]
            exact = _state.counts[lo]
            near = np.zeros(len(lo), dtype=np.float64)
            for k in range(len(lo)):
                lv = int(lo[k])
                a = max(1, lv - 3)
                b = min(100, lv + 3)
                near[k] = _state.counts[a:b + 1].sum()
            bonus[valid] = exact / _state.total + 0.25 * near / _state.total
        # Small weight so best-fit remains dominant.
        base = base + 0.15 * bonus

    # Prefer not to open a brand-new bin unless necessary: unused bins have capacity 100,
    # so better-fit choices almost always win; add tiny penalty for using an empty bin.
    base = base - 0.001 * (bins == 100)

    _state.update(item)
    return base
