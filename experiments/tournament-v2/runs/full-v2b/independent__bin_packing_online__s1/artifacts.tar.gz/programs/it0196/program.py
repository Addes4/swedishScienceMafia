"""Refined best fit: prefer exact fits, then smallest residual."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Large bonus for an exact fit (residual 0).
    exact_bonus = np.where(residual == 0, 1e6, 0)
    # Base: smallest residual is best (tightest fit).
    return exact_bonus - residual
