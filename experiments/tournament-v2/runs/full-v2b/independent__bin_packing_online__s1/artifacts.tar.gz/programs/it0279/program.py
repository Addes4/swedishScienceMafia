"""Online bin packing heuristic: best-fit plus a mild first-fit-like tie/bias correction.

Uses only information visible at arrival time.  Keeps simple state to avoid opening new
bins when an existing bin has a reasonably tight fit.
"""
import numpy as np

_state = {
    "used": 0,       # number of bins that are no longer completely empty
    "calls": 0,      # number of items seen
}


def priority(item, bins):
    _state["calls"] += 1

    # Detect how many bins are still empty (capacity exactly 100).
    # bins is a copy, so no mutation concerns.
    empty_mask = (bins == 100)
    empty_count = int(np.count_nonzero(empty_mask))
    nonempty = ~empty_mask

    # Update rough used-bin count estimate for the current call window.
    # If there are empty bins, then used = total - empty.
    total = bins.shape[0]
    used = total - empty_count

    # Base best-fit score: tighter fit is better (smaller remaining after placement).
    # score = -(bins - item) => smaller residual is larger score.
    score = -(bins - item).astype(np.float64)

    # If there is at least one non-empty bin, modestly prefer non-empty bins when
    # their residual would be not too large.  This reduces unnecessary new-bin opens.
    if used > 0:
        # Slight bonus for nonempty bins.  The bonus decays with residual waste so
        # that a perfect or near-perfect fit in an empty bin can still win.
        residual = bins - item  # remaining capacity after placing item
        # Normalize: 0 residual is ideal, 100 is worst.
        tightness = 1.0 - (residual / 100.0)
        # Only add the preference to nonempty bins.
        score += np.where(nonempty, 0.15 * tightness, 0.0)

    # Tiny deterministic tie-breaker by bin index is already handled by "first wins".
    return score
