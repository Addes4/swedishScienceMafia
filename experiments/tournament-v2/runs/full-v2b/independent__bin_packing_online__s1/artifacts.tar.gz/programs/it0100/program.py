"""Best-fit bin packing: choose the bin with the smallest remaining capacity that still fits the item.

This is the standard online best-fit heuristic. It is optimal among online rules for many
distributions and particularly well-suited for Weibull-shaped item sizes. Ties go to the first
bin (lowest index), which favours older/unused bins and helps keep bins compact.
"""

import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the bin that is filled most tightly after placing the item.
    # Equivalent to minimizing remaining capacity after placement, i.e. maximizing -(bins - item).
    # Since item is constant across bins, this is just minimizing bins.
    return -bins
