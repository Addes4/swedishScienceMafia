import numpy as np

_last_items = []


def priority(item, bins):
    global _last_items

    # Keep a short memory of recent items (not strictly needed, but harmless).
    _last_items.append(int(item))
    if len(_last_items) > 16:
        _last_items.pop(0)

    b = bins.astype(np.int64)

    # Main rule: best fit, i.e. prefer the smallest remaining capacity that still fits.
    # This is exactly the classic best-fit heuristic and is very strong for online
    # bin packing with i.i.d. item sizes.
    scores = -b

    # Slight tie-breaking / stabilization: among bins with the same remaining capacity,
    # prefer the one with the smaller index. Since ties already go to the first bin,
    # we don't add index terms. We do, however, slightly prefer not to open a brand-new
    # bin if an existing bin can fit the item with very little waste.
    #
    # The expression below keeps best-fit dominant, while giving a tiny preference to
    # bins that are already partially used over completely empty bins. This helps avoid
    # pouring small residual space into fresh bins when a suitable existing bin exists.
    scores = scores.astype(np.float64)
    scores -= 1e-6 * (b == 100)

    return scores
