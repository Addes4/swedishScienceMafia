import numpy as np

# Priority for bin choice in online bin packing.
# We want to minimize bins used.  A well-known good heuristic is "best fit":
# choose the bin with the smallest remaining capacity that still fits the item.
# Pure best fit already performs decently, but a small modification helps:
# when several bins fit, prefer a bin whose remaining capacity after placing
# is small (tight packing), and among those prefer bins that are not almost
# empty, since filling those can save future bins.
#
# We implement a score that is primarily -remaining (tight fit) with a tiny
# penalty for very full bins so that we don't waste a bin that is nearly empty.
# The item goes to the highest score.

# Global cache to remember which remaining capacities were good for a given item.
_cache = {}

def priority(item, bins):
    """Return a priority for every bin in `bins`.

    The item goes into the bin with the highest score (first on ties).
    """
    # bins is a numpy int64 array of remaining capacities
    rem = bins.astype(np.float64)
    # base score: prefer tightest fit => smallest remaining after placement
    # equivalently, smallest remaining capacity before placement
    score = -rem

    # Slight bonus for bins that are already somewhat filled (small rem)
    # and slight penalty for completely empty bins, so we don't open new bins
    # unnecessarily.  This is a soft version of "best fit decreasing" adapted
    # online.
    # A bin with rem == item fits exactly (score 0).  We add a very small term
    # based on how full the bin is, to break ties toward fuller bins.
    fullness = (100.0 - rem) / 100.0
    score += 0.01 * fullness

    # Tiny penalty for empty bins (rem close to 100) to delay opening new bins
    empty_penalty = np.where(rem >= 100, 0.5, 0.0)
    score -= empty_penalty

    return score
