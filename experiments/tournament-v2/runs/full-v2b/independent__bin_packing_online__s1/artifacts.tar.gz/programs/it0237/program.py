import numpy as np


def priority(item, bins):
    """Score bins for online bin packing.

    Strategy: use an adjusted best-fit that prefers bins where the leftover
    capacity after placing the item is small, but adds a mild preference for
    already-used bins (remaining capacity below 100) to avoid opening new bins
    too early.  Exact fits are strongly favored, then low residual capacity.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    rem = bins - item  # residual capacity if this item is placed here

    # Strongly favor exact fits.
    # Then prefer small residuals.
    # Give a tiny bonus to non-empty bins (capacity < 100) to reduce bin openings.
    used_bonus = np.where(bins < 100, 0.25, 0.0)

    # The primary score: negative residual.  We add a small nonlinear term
    # so that very good fits (small residual) are distinguished more clearly.
    score = -(rem.astype(np.float64)) - 0.001 * (rem.astype(np.float64) ** 2) + used_bonus

    # If a bin is unused (remaining capacity 100), avoid it unless necessary.
    # Already handled by used_bonus, but make the preference slightly stronger
    # for unused bins so that partial bins are filled first.
    # (This is equivalent to subtracting 0.25 from used_bonus for unused bins.)
    # Already included via used_bonus = 0 for unused bins.

    return score
