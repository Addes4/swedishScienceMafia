"""Online bin packing via best-fit with light reservation for large items."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fit, but slightly penalize filling a nearly empty bin
    too much when the item is small, keeping room for larger future items."""
    # Best-fit distance: how much capacity remains after placing the item.
    remaining_after = bins - item

    # For small items, discourage using bins with a lot of free space if there are
    # already tighter bins available. For large items, pure best-fit is best.
    if item <= 25:
        # Strongly prefer tight fits, but avoid making a fresh bin worse than needed.
        score = -remaining_after - 0.02 * bins
    elif item <= 60:
        score = -remaining_after
    else:
        # Large items: pure best-fit; exact fits are especially valuable.
        score = -remaining_after + 0.001 * (remaining_after == 0)

    return score
