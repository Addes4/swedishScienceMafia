import numpy as np

# ---- tunable constants ----
ALPHA_EXACT = 0.12        # penalty for using a bin whose leftover exactly equals the item
BETA_RESID = 0.010        # reward for leaving a residual that is a likely future item size
GAMMA_SMALL = 0.0015      # slight preference for leaving very small / unusable slack

# Running frequency estimate of item sizes (1..100).  Initialized to a gentle prior.
_hist = np.ones(101, dtype=np.float64)
_hist[0] = 0.0
_total = float(_hist[1:].sum())
_MIN_TOTAL = 1.0

def _prob(size):
    """Estimated probability that a future item has this size (smoothed)."""
    if size < 1 or size > 100:
        return 0.0
    return _hist[size] / max(_total, _MIN_TOTAL)

def priority(item, bins):
    # Update running histogram with the newly arrived item (no future info used).
    global _total
    if 1 <= item <= 100:
        _hist_item = _hist[item]
        _hist[item] = _hist_item + 1.0
        _total += 1.0

    bins = np.asarray(bins, dtype=np.float64)
    residual = bins - float(item)

    # Base rule: best fit -> tighter residual favored.
    score = -residual

    # Penalize burning an exact-fit bin unless it is clearly beneficial.
    score -= ALPHA_EXACT * (residual == 0.0)

    # Slight shape preference: leaving a small but usable residual is often good,
    # but leaving a residual that is a frequent item size is better.
    p = np.array([_prob(int(r)) if r >= 1 else 0.0 for r in residual], dtype=np.float64)
    score += BETA_RESID * p

    # Mild preference to keep large empty bins available, tiny nudge for very small slack.
    score -= GAMMA_SMALL * residual

    return score
