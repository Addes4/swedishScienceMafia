# EVOLVE-BLOCK-START
"""Adaptive best-fit bin packing heuristic."""
import numpy as np

_state = {"count": 0, "sum": 0.0}
# Common small item sizes to prefer as leftovers (helps pack gaps)
_GOOD_REM = np.zeros(101, dtype=np.float64)
for _r in (0, 1, 2, 3, 5, 8, 10, 15, 20, 25, 30, 40, 50):
    _GOOD_REM[_r] = 1.0


def priority(item, bins):
    """Score bins: best-fit with consolidation and leftover-quality bonuses."""
    rem = bins.astype(np.float64)
    # After placing, remaining capacity would be rem - item.
    left = rem - item

    # Best-fit base: tighter fit (smaller leftover) is better -> negative leftover.
    score = -left

    # Bonus for perfectly filling a bin (leftover 0).
    score += np.where(left == 0, 2.0, 0.0)

    # Bonus for leaving a "nice" remainder (small standard sizes).
    score += _GOOD_REM[np.clip(left, 0, 100).astype(np.int64)] * 1.5

    # Slight preference for fuller bins to consolidate waste into fewer bins,
    # but not so strong it dominates tight-fit.
    score += (100.0 - rem) * 0.02

    # Prefer unused bins (rem==100) last among equal fits handled by tie order,
    # instead give a tiny penalty so we don't open new bins unnecessarily.
    score -= np.where(rem == 100.0, 1e-3, 0.0)

    return score
# EVOLVE-BLOCK-END
