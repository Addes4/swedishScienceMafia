import numpy as np

_SMALL_CACHE = {}

def priority(item, bins):
    # Best-fit: prefer smallest remaining capacity after placing item.
    slack = bins - item

    # Base score: higher is better; best fit means smaller slack.
    score = -slack.astype(np.float64)

    # Small bonus for using completely empty bins only when item is large enough
    # to avoid wasting pristine capacity on tiny items.
    if item >= 25:
        score += (bins == 100) * 1e-3

    # Slight penalty for leaving tiny unusable remainders, which tend to fragment bins.
    # remainders 1..3 are especially bad late in packing.
    small_rem = (slack >= 0) & (slack <= 3)
    score -= small_rem * 1e-4

    # Prefer bins whose remainder is a "nice" complement for common medium/large items.
    # This is a soft heuristic, not tuned aggressively.
    if item <= 40:
        good_gap = (slack >= 20) & (slack <= 60)
        score += good_gap * 2e-5

    return score
