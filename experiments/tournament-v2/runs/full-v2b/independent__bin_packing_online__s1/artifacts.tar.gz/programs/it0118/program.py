import numpy as np


def priority(item, bins):
    """Best fit: prefer the bin whose remaining capacity after placing the item is smallest.

    Smaller post-placement remaining capacity means a tighter fit, which tends to reduce
    wasted space and the number of bins needed in online packing.
    """
    return -(bins - item)
