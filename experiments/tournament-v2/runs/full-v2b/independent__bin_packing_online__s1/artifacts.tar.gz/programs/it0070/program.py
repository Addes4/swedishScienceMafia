import numpy as np


def priority(item, bins):
    # Base: tightly fit (larger score for smaller leftover)
    leftover = bins - item
    # Best fit: minimize leftover
    score = -leftover.astype(np.float64)

    # Mild preference for bins that are already fuller (smaller remaining capacity)
    # so that we don't spread items across many partially-filled bins.
    # Penalize perfectly empty bins slightly to avoid opening new bins unnecessarily.
    score -= (bins == 100) * 0.5

    return score
