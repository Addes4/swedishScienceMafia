import numpy as np


class _State:
    def __init__(self):
        self.counter = 0


_state = _State()


def priority(item, bins):
    _state.counter += 1
    # Strong best-fit: maximize item - remaining = -remaining (mod item)
    # But add a tiny, deterministic, bin-index-dependent perturbation so that
    # among nearly-tied bins (many equal residual capacities) we don't always
    # pick the same bin.  The perturbation is small enough to almost never
    # override a genuinely tighter fit but breaks exact ties in a scattered way.
    n = bins.shape[0]
    # vectorized deterministic pseudo-random jitter in [0, 1)
    idx = np.arange(n, dtype=np.int64)
    # mix counter, item, and index
    x = (idx * 1103515245 + _state.counter * 12345 + item * 1013904223) & 0x7fffffff
    x = (x ^ (x >> 13)) * 1274126177
    x = (x ^ (x >> 16)) & 0x7fffffff
    jitter = (x % 1000) / 1000.0
    return -(bins - item) + jitter * 0.01
