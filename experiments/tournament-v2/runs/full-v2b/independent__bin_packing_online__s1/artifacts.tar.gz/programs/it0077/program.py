import numpy as np


class _State:
    def __init__(self):
        # recent item statistics to adapt tie-breaking pressure
        self.seen = 0
        self.sum_item = 0.0
        self.last_gap = 0
        self.reuse_bias = 0.0


_state = _State()


def priority(item, bins):
    """Best-fit with adaptive slight reuse bias.

    Primary: choose tightest fit (smallest remaining capacity after placing item).
    Secondary: slightly prefer already-used bins with small leftovers to
    consolidate packing and reduce fragmentation.
    """
    st = _state
    st.seen += 1
    st.sum_item += float(item)

    # running mean of item sizes (used to modulate the reuse pressure)
    mean_item = st.sum_item / float(st.seen)

    # Best-fit residual gap
    gap = bins - item

    # Base score strongly favors small residual capacity.
    # Use negative gap scaled; smaller gap => higher score.
    # Add a small consolidation bonus for bins that are neither empty nor full.
    # Empty bins have gap == 100 - item; leave them as fallback.
    empty_gap = 100 - item

    # is_used: bins that are not untouched full-capacity bins
    # (remaining less than 100 means something is already inside)
    used = bins < 100

    # Tiny bias: among similarly tight bins, prefer ones that are already in use
    # and closer to full, to avoid opening new bins.
    # Adaptive magnitude based on mean item size; small enough to keep best-fit primary.
    bias = 0.02 + 0.10 * (mean_item / 100.0)

    # residual advantage: prefer small gap
    score = -gap.astype(np.float64)

    # consolidation bonus: reward used bins with small residuals more
    consolidation = np.where(used, 1.0 / (gap.astype(np.float64) + 1.0), 0.0)
    score += bias * consolidation

    # never violate fit; all bins shown fit, so gap >= 0.
    # Slight penalty for opening an empty bin when used alternatives exist.
    # This is already captured by consolidation bonus.

    st.last_gap = int(gap.min()) if gap.size else 0
    return score
