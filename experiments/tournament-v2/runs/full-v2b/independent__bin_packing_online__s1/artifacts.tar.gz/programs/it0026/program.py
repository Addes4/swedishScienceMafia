import numpy as np


def priority(item, bins):
    """Best fit: prefer the bin the item fits most tightly.

    Additional heuristics:
    - Slightly penalize completely empty bins (remaining capacity 100) so that
      partially filled bins are preferred, reducing fragmentation.
    - Among nearly equally tight bins, prefer the one with smaller remaining
      capacity (best fit), then earlier bin index.
    """
    # remaining capacity after placing item
    residual = bins - item

    # Best fit: smaller residual is better -> negative residual.
    score = -residual.astype(np.float64)

    # Penalize still-empty bins a bit so we consolidate into used bins.
    # Only applies to bins that are exactly empty (capacity == 100).
    empty_mask = bins >= 100
    score[empty_mask] -= 0.5

    return score
