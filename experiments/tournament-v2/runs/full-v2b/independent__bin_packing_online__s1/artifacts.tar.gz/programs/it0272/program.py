import numpy as np


def priority(item, bins):
    # How much capacity would remain if this item were placed in each bin.
    remaining_after = bins - item

    # Primary rule: best fit -> minimize leftover space.
    # Secondary rule: among equal leftovers, prefer bins that are already fuller
    # (smaller remaining capacity before placement), which tends to keep bins packed.
    # Since bins only contains bins the item fits in, unused bins have remaining 100
    # and will naturally get the worst score for most items.
    return -(remaining_after * 1000 + bins)
