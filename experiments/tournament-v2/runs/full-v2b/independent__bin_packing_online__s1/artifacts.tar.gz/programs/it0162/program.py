import numpy as np
from collections import deque

# History of recent item sizes and observed counts to bias bin choice.
_item_counts = np.zeros(101, dtype=np.int32)
_recent = deque(maxlen=256)
_calls = 0

# Bonus for creating residuals that are common in recent history.
def _residual_bonus(res):
    # res is remaining capacity after placing item.  Higher if res is a plausible future item.
    if res <= 0:
        return -1e9
    # Use recent frequency, smoothed.  Future items look like past items in distribution.
    return float(_item_counts[res]) + 0.25 * float(_item_counts[min(100, res + 1)]) + 0.1

def priority(item, bins):
    global _calls, _item_counts, _recent
    _calls += 1
    _item_counts[item] += 1
    _recent.append(item)

    # bins are remaining capacities of bins that can fit item.
    # Score components:
    # 1) Prefer tight fits with residual not too small (avoid useless near-zero waste).
    # 2) Prefer residuals that have appeared often recently (will likely be needed).
    # 3) Slightly prefer using already-used bins over opening unused bins.
    rem = bins.astype(np.float64, copy=False)

    # Tightness: closer to item means better packing.
    tight = -np.abs(rem - item)

    # Residual after placement.
    res = rem - item

    # Bonus for exact fill or useful residual.
    bonus = np.empty_like(res)
    for i in range(res.shape[0]):
        bonus[i] = _residual_bonus(res[i])

    # Opening a new bin (remaining capacity 100) is slightly discouraged when
    # another bin can take the item, because it increases bin count.
    unused_penalty = np.where(rem >= 100.0, -2.0, 0.0)

    # Prefer bins with smaller remaining capacity if residuals are comparable.
    # This is essentially best-fit with residual shaping.
    return tight * 1.0 + bonus * 0.8 + unused_penalty
