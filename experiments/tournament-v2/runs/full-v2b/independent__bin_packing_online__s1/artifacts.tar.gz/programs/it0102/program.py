import numpy as np


def priority(item, bins):
    """Score bins so that the tightest sensible fit is chosen.

    Primary rule: best fit (smallest remaining capacity that still fits).
    Secondary rule: avoid using an empty bin if a nearly-as-good partial bin exists.
    """
    # bins are remaining capacities of bins the item fits in.
    # Best fit: higher score for smaller remaining capacity after placing item.
    residual = bins - item

    # Strongly prefer tighter fits. This is the classic best-fit packing rule.
    score = -residual.astype(np.float64)

    # Slightly penalize opening unused bins when a partially used bin is only a little worse.
    # An unused bin has remaining capacity 100, so residual is 100 - item.
    empty_mask = bins == 100
    score[empty_mask] -= 0.05

    return score
