import numpy as np


def priority(item, bins):
    """Best-fit with a mild penalty for leaving a bin with a tiny remainder.

    We want to pack tightly (best fit), but a bin left with a small remaining
    capacity (1..item-1) is often wasted because most future items won't fit.
    So we add a small bonus for exact fits and a small penalty for leaving a
    tiny residual capacity.
    """
    remaining = bins - item

    # Base: prefer the tightest fit -> smaller remaining gets higher score.
    score = -remaining.astype(np.float64)

    # Exact fit (remaining == 0): strong but not overwhelming push.
    score[remaining == 0] += 0.5

    # Penalize leaving a very small residual (wasted) capacity.
    # residual in 1..9 is likely wasted for a mean-40 distribution.
    tiny = (remaining > 0) & (remaining < 10)
    score[tiny] -= 0.25 * (10 - remaining[tiny])

    return score
