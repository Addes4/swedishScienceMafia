import numpy as np

def priority(item, bins):
    # bins: remaining capacities of bins the item fits in.
    # Strategy: strongly prefer tight fits on partially-used bins,
    # but avoid opening fresh bins (cap == 100) unless necessary.
    # We use a score combining:
    #   - tightness: smaller remaining capacity after placement is better
    #   - penalize using a completely empty bin
    # The item always fits (bins contains only fitting bins), so cap >= item.

    # remaining capacity after placing item
    rem = bins - item

    # Base score: prefer tightest fit (smaller rem). Use negative rem.
    score = -rem.astype(np.float64)

    # Penalize bins that are currently completely empty (cap == 100),
    # so a fresh bin is chosen only when no partially used bin is acceptable.
    empty = (bins == 100)
    score[empty] -= 1000.0

    # Small tie-break: prefer bins that become well-filled (smaller rem),
    # already captured. Also slightly prefer lower-index bins for stability
    # by adding a tiny decreasing term.
    n = bins.shape[0]
    if n > 0:
        score -= np.arange(n) * 1e-9

    return score
