import numpy as np


class _BinPackingPolicy:
    def __init__(self):
        self.count = 0
        self.sum_item = 0.0
        self.recent = []
        self.recent_cap = 64

    def observe(self, item):
        self.count += 1
        self.sum_item += float(item)
        if len(self.recent) >= self.recent_cap:
            # circular-ish reset to avoid unbounded list growth
            self.recent = self.recent[self.recent_cap // 2:]
        self.recent.append(int(item))


_policy = _BinPackingPolicy()


def priority(item, bins):
    p = _policy
    p.observe(item)

    # Best-fit base: prefer bins with the smallest remaining capacity that still fit.
    # Since unused bins have capacity 100 and the item fits, bins array contains only fitting bins.
    rem = bins.astype(np.float64)

    # Strong best-fit score.
    score = -rem

    # Slight preference for bins that are already partially used over completely empty bins.
    # This helps consolidation and reduces opening new bins, while best-fit still dominates.
    score += (rem < 100).astype(np.float64) * 0.35

    # Mild anti-fragmentation: avoid leaving tiny unusable gaps if possible.
    # A residual capacity just below common small item sizes is less useful.
    residual = rem - float(item)

    # Penalize residuals that are too small to hold typical future items, but not zero.
    small_penalty = np.zeros_like(residual)
    small_penalty += (residual > 0) & (residual < 3)
    small_penalty += (residual >= 3) & (residual < 6) * 0.35
    score -= small_penalty * 0.15

    # Slight preference for residuals that remain large enough for mean-sized future items,
    # but only as a tie-breaker after best-fit.
    if p.count > 0:
        mean_item = p.sum_item / p.count
    else:
        mean_item = 40.0

    # Reward residuals that are near a useful packing remainder, very mildly.
    useful = residual - mean_item
    score -= np.abs(useful) * 0.002

    # Encourage filling bins closer to full when item is large, less important when small.
    closeness = rem / 100.0
    score -= closeness * 0.01

    return score
