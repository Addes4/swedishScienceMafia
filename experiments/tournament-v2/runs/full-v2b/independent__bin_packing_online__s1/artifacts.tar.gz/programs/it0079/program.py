import numpy as np


def priority(item, bins):
    # Best-fit: prefer smallest remaining capacity that still fits.
    tight = -bins

    # Small bonus for occupied bins (capacity < 100) to encourage packing into
    # already-used bins rather than opening new ones.
    occupied = (bins < 100).astype(np.int64)

    # Prefer bins whose residual after placing is small, but slightly favor
    # residuals that are "useful" for future items (avoid leaving tiny gaps
    # for big items by not over-rewarding near-full bins when item is small).
    residual = bins - item

    # Favor residuals that are neither too tiny nor too large, using a simple
    # concave-ish shaping. This helps reduce fragmentation over time.
    # Score increases as residual approaches a moderate value.
    shaped = -(np.abs(residual - 15))

    return tight * 1000 + shaped * 3 + occupied * 50
