"""Best-fit with a small twist: score bins to pack tightly while avoiding leaving
awkward small remainders that cannot fit future items."""
import numpy as np


def priority(item, bins):
    # prefer bins with the smallest remaining capacity after placing (tightest fit),
    # but give an extra bonus to bins that would become nearly full or exactly full.
    rem_after = bins - item

    # base: tightly fitting bins have smaller remainder -> higher score
    score = -rem_after.astype(np.float64)

    # strongly favor exact fills (remainder 0)
    score += 1000.0 * (rem_after == 0)

    # discourage leaving a remainder smaller than the smallest common item sizes;
    # such crumbs are mostly unusable. Items are Weibull-ish, often fairly large.
    # A remainder in the 1..10 range rarely fits anything useful.
    crumb = (rem_after > 0) & (rem_after < 10)
    score -= 50.0 * crumb

    # Slightly prefer larger bins when fit is equal-ish so we keep small bins clean.
    score += 0.001 * bins.astype(np.float64)

    return score
