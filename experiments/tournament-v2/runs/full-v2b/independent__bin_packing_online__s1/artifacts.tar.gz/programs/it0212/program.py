"""Best-fit style rule with residual-gap awareness for online bin packing."""

import numpy as np

# We keep a tiny amount of global state only to optionally discourage opening
# many new bins when a good existing fit is already available.  This is not
# necessary for correctness; it just biases toward reuse.
_state = {
    "calls": 0,
    "item_sum": 0.0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    Strategy: rank by resulting residual capacity, favoring near-exact fits,
    but avoid leaving a tiny positive residual that likely cannot be reused.
    """
    _state["calls"] += 1
    _state["item_sum"] += float(item)

    # Resulting remaining capacity if this item is placed in each bin.
    residual = bins - item  # bins is guaranteed to contain only fitting bins

    # Score: higher is better.
    # Best fit means we prefer the smallest non-negative residual.
    # We add a small preference against residuals in (0, small_threshold),
    # because such gaps are often wasted, and a slight preference for
    # residual == 0 (perfect fit).
    scores = -residual.astype(np.float64)

    # Perfect fit bonus: strongly prefer exact placement.
    scores = np.where(residual == 0, scores + 1000.0, scores)

    # Penalize tiny residuals that are unlikely to be useful.
    # This helps avoid fragmenting capacity into unusable slivers.
    tiny = (residual > 0) & (residual < 10)
    scores = np.where(tiny, scores - 5.0, scores)

    # Slight preference for reusing lower-index (existing) bins over unused bins
    # is not needed because bin order already breaks ties, and best-fit handles it.
    # But we can mildly prefer larger bins (more remaining capacity) only when
    # residuals are equal, which ties already resolve by first bin.  Leave as-is.

    return scores
