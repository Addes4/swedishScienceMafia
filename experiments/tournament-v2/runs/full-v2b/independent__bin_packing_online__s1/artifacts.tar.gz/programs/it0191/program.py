import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.small = 0
        self.large = 0
        self.empty_used = 0

    def update(self, item):
        self.count += 1
        if item <= 40:
            self.small += 1
        else:
            self.large += 1


_state = _State()


def priority(item, bins):
    """Rank bins: prefer tight fits, but slightly discourage opening new bins for small items."""
    n = len(bins)
    rem = bins.astype(np.int64)
    score = 1000.0 - (rem - item).astype(np.float64)

    # Bins that are completely empty (remaining capacity == 100) are "new bins".
    empty = (rem == 100)
    if empty.any():
        # For smaller items, make opening a fresh bin a bit less attractive.
        # Threshold around the mean (~40) so that large items can still open bins
        # when no good option exists, while small items prefer existing bins.
        if item <= 45:
            score[empty] -= 35.0 + 0.8 * (45 - item)
        else:
            score[empty] += 2.0 * (item - 45)

    # Slight bias toward lower-index bins for deterministic tie-breaking is already
    # handled by the harness (first max wins); no explicit index term needed.
    return score
