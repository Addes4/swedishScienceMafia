"""Improved bin-choice rule: tight-fit with anti-fragmentation bias."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits, and slightly prefer non-empty bins.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (unused bins = 100).
    """
    # Tightness: smaller remaining after placing -> higher score.
    # - (bins - item) is best-fit for used bins.
    fit = -(bins - item)

    # Slight preference for bins that are already open (remaining < 100)
    # to avoid opening brand-new bins unnecessarily, reducing bin count.
    used_bonus = np.where(bins < 100, 1.0, 0.0)

    return fit + 0.5 * used_bonus
