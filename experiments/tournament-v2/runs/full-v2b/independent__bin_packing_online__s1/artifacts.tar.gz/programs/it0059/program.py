import numpy as np

_STATE = {
    "count": 0,
    "sum": 0.0,
    "small": 0,
    "medium": 0,
    "large": 0,
}

def priority(item, bins):
    """
    Adaptive best-fit + residual-value rule.

    The item is placed into the bin with the highest score. The score favors:
      1. tight fit (small positive residual after placing),
      2. residual capacities that are unlikely to waste space,
      3. avoiding unnecessarily opening new bins when a good fit exists.
    """
    global _STATE

    n = bins.shape[0]
    scores = np.empty(n, dtype=np.float64)

    # --- update online statistics from observed items ---
    _STATE["count"] += 1
    _STATE["sum"] += float(item)

    if item <= 25:
        _STATE["small"] += 1
    elif item <= 65:
        _STATE["medium"] += 1
    else:
        _STATE["large"] += 1

    cnt = _STATE["count"]

    # Estimate how often small/medium/large are useful for filling gaps.
    p_small = (_STATE["small"] + 1.0) / (cnt + 3.0)
    p_medium = (_STATE["medium"] + 1.0) / (cnt + 3.0)
    p_large = (_STATE["large"] + 1.0) / (cnt + 3.0)

    # Rough mean item size; distribution mean is about 40.
    mean_item = _STATE["sum"] / cnt if cnt else 40.0

    rem_after = bins - item

    # Prefer tight fits: a small remaining capacity is good.
    # But pure best fit can be too rigid; add a mild preference for residuals
    # that are likely to be useful later.
    fit_score = -rem_after.astype(np.float64) * 2.0

    # Value of the residual bin after placing the item.
    # Residuals around common item sizes are attractive if those item sizes remain likely.
    useful_small = np.exp(-((rem_after - 15.0) / 12.0) ** 2)
    useful_medium = np.exp(-((rem_after - 40.0) / 20.0) ** 2)
    useful_large = np.exp(-((rem_after - 70.0) / 22.0) ** 2)

    residual_value = (
        1.5 * p_small * useful_small
        + 1.2 * p_medium * useful_medium
        + 1.0 * p_large * useful_large
    )

    # Very low residual capacity is usually excellent because it closes a bin efficiently.
    close_bonus = 0.0
    close_threshold = max(3.0, min(18.0, mean_item * 0.30))
    close_bonus = np.where(rem_after <= close_threshold, 6.0, 0.0)
    exact_bonus = np.where(rem_after <= 1.0, 12.0, 0.0)

    # Opening a completely unused bin should be less attractive than fitting an existing bin,
    # unless the fit is terrible. This helps avoid unnecessary new bins.
    empty_penalty = np.where(bins == 100, -4.0, 0.0)

    # Slight penalty for leaving huge gaps in already-used bins; those gaps can often still be filled.
    waste_penalty = np.where((bins < 100) & (rem_after > 55.0), -2.5, 0.0)

    scores[:] = (
        fit_score
        + residual_value
        + close_bonus
        + exact_bonus
        + empty_penalty
        + waste_penalty
    )

    # Tie-break slightly toward earlier bins by making earlier scores marginally larger.
    # The harness already breaks ties by first bin, but this ensures a stable preference.
    scores += (np.arange(n, dtype=np.float64) * -1e-7)

    return scores
