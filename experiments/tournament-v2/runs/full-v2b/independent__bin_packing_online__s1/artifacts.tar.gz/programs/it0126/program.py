import numpy as np

_sizes = []
_state = {"sizes": [], "sum": 0, "count": 0, "hist": np.zeros(101, dtype=np.int64)}

def priority(item, bins):
    # Update running statistics
    st = _state
    st["sizes"].append(item)
    st["sum"] += item
    st["count"] += 1
    if item < 101:
        st["hist"][item] += 1

    # Best fit base score: prefer bins where after placing, remaining is smallest (tightest)
    rem = bins - item
    # rem >= 0 guaranteed by harness

    # Prefer exact fill
    score = -rem.astype(np.float64)

    # Bonus if resulting remainder matches a frequent item size (so it can be filled later)
    # Build a simple frequency bonus using the histogram we maintain.
    hist = st["hist"]
    total = st["count"]
    if total > 0:
        # Avoid division by zero; compute normalized frequency for remainder values
        # For efficiency, only boost remainders that have been seen many times.
        # Use a piecewise lookup: remainders up to 100.
        freq = hist / float(total)
        # Only consider remainders >= 0; rem is int array
        # Clip rem to 0..100 for lookup
        idx = np.clip(rem, 0, 100)
        bonus = freq[idx] * 10.0  # weight for matching common sizes
        score += bonus

    # Slight preference for bins with less remaining capacity overall (better fit)
    # This is already captured by -rem. Add a small term for larger item counts? no.

    return score
