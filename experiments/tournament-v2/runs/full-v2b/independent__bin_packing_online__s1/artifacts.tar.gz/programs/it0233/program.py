"""Best-fit with a small tie-break to favor filling bins more evenly."""
import numpy as np


def priority(item, bins):
    # Primary: tightest fit (smallest remaining capacity after placing).
    # Secondary: among equally good fits, prefer the bin with larger remaining
    # capacity so we fill already-open bins more instead of opening new ones.
    return -(bins - item) - 1e-6 * bins
