import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum = 0
        self.counts = np.zeros(101, dtype=np.int64)
        # adaptive parameter: prefer lower-index (older/fuller) bins when residuals are close
        self.eps = 0.0

    def observe(self, item):
        self.n += 1
        self.sum += item
        self.counts[item] += 1
        if self.n % 250 == 0:
            # crude estimate of packing pressure: average item size
            # larger mean items -> more rounding loss -> stronger preference for exact fits
            self.eps = min(1.0, max(0.0, (self.sum / self.n - 35.0) / 25.0))


_state = _State()


def priority(item, bins):
    """Score bins: primarily least remaining capacity (best fit), with a small
    tie-break that favors using already-nonempty bins first."""
    _state.observe(item)

    # primary: tightest fit (smallest residual)
    score = -(bins - item).astype(np.float64)

    # secondary: prefer bins that are already in use (residual < 100) over unused bins
    # and among used bins prefer lower residual exactly; this is already in primary.
    # Add a tiny index-based tie-break: earlier bins slightly preferred when equal.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    score -= idx * 1e-6

    # Adaptive extra: when average item size is large, exact fits matter more.
    # Slightly boost bins whose residual exactly equals item (perfect fit).
    if _state.eps > 0.0:
        exact = (bins == item).astype(np.float64)
        score += exact * _state.eps

    return score
