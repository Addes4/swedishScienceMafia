# EVOLVE-BLOCK-START
"""Adaptive best-fit for online bin packing.

The item is placed in the bin where it fits most tightly, but a small
adjustable penalty encourages leaving some slack in bins that are nearly
full.  The penalty is adapted from the recent history of item sizes so
that the rule behaves like pure best-fit when items are small or very
large, and like almost-worst-fit when many medium items are arriving.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.recent = []
        self.window = 64


_state = _State()


def priority(item, bins):
    st = _state
    st.n += 1
    st.sum += item
    st.recent.append(item)
    if len(st.recent) > st.window:
        st.recent.pop(0)

    mean_recent = sum(st.recent) / len(st.recent)

    # Main score: prefer tightest fit (minimise remaining capacity after placement).
    # bins is remaining capacity, so tightest fit means smallest bins >= item.
    rem_after = bins - item  # >= 0 because only fitting bins are passed

    # Base: negative remaining capacity -> higher score for smaller remaining capacity.
    score = -rem_after.astype(np.float64)

    # Adaptive slack preference.  When recent items are near half capacity,
    # keeping some room in a bin is valuable for future medium items.
    # We add a bonus to bins whose remaining capacity is close to a
    # target slack, and a mild penalty for bins that would become too full.
    target_slack = max(0.0, min(50.0, 100.0 - mean_recent))
    # Only apply a soft preference; small magnitude keeps best-fit dominant.
    slack_bonus = -0.06 * np.abs(rem_after.astype(np.float64) - target_slack)
    score += slack_bonus

    # Slight preference for bins with more remaining capacity among very full
    # candidates helps avoid locking the last slot of a nearly-full bin.
    score += 0.02 * bins.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
