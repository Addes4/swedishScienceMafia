import numpy as np


def priority(item, bins):
    # bins: remaining capacities of bins the item fits in
    # We rank by a score; higher is better.
    #
    # Main idea:
    # - Best fit minimizes waste for the arriving item.
    # - For larger items, strongly prefer existing partially used bins
    #   over opening new bins, because large items have few packing options.
    #
    # This remains a greedy online rule, but biases bin choice depending on item size.

    rem = bins.astype(np.int64, copy=False)

    # base score: best fit (smaller leftover after placing = higher priority)
    # leftover = rem - item
    # We want smallest leftover, so score = -(rem - item)
    score = -(rem - item)

    # A small deterministic tie-breaker based on bin order can be avoided by numpy's stable selection.
    # But the harness picks first max on ties, so we can leave score as is for standard best fit.

    # For relatively large items, prefer bins that are already somewhat occupied
    # and whose remaining capacity is not too close to the item size
    # (to avoid leaving a useless sliver).
    #
    # Since we never see future items, the tradeoff is heuristic:
    # large items should mostly fill bins, but leaving exactly 0 is ideal when possible.
    if item >= 50:
        # Encourage using partially filled bins over empty bins.
        # Empty bins have rem=100. Add a bonus for rem < 100.
        # Also, if leftover after placing is 0, strongly prefer that.
        leftover = rem - item
        # Bonus for exact fit
        exact = (leftover == 0).astype(np.int64) * 1000
        # Penalize opening new bins slightly for large items
        not_empty_bonus = (rem < 100).astype(np.int64) * 10
        # Avoid leftovers in awkward mid-range if possible
        # (e.g., leftover 10-30 can still be useful, but less than small slivers)
        awkward = ((leftover > 0) & (leftover < item) & (leftover < 20)).astype(np.int64) * (-5)
        score = score + exact + not_empty_bonus + awkward

    elif item >= 25:
        # Medium items: mild preference for non-empty bins, still best fit
        exact = (rem == item).astype(np.int64) * 100
        not_empty_bonus = (rem < 100).astype(np.int64) * 2
        score = score + exact + not_empty_bonus

    else:
        # Small items: pure best fit is strong; add tiny exact-fit bonus
        exact = (rem == item).astype(np.int64) * 10
        score = score + exact

    return score
