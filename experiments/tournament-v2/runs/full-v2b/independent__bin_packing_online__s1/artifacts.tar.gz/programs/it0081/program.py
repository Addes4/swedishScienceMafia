import numpy as np

class BinState:
    def __init__(self):
        self.total_items = 0
        self.sum_sizes = 0.0
        # We'll track a running mean to adapt threshold
        self.mean_size = 40.0

    def update(self, item):
        self.total_items += 1
        self.sum_sizes += item
        self.mean_size = self.sum_sizes / self.total_items

_state = BinState()

def priority(item, bins):
    _state.update(item)
    # Best-fit: prefer bins with remaining capacity closest to item (tightest fit)
    # Discourage opening new bins (rem=100) unless necessary.
    # We use a score: higher for bins with smaller leftover after placing item.
    leftover = bins - item
    # Avoid negative leftover (shouldn't happen since bins contains only fitting bins)
    leftover = np.maximum(leftover, 0)
    # Score: smaller leftover -> higher score. Also penalize full bins (leftover==0) slightly less.
    score = -leftover.astype(np.float64)
    # Add tiny bonus for using a partially filled bin over an empty one (remaining == 100)
    # This encourages packing existing bins tighter before opening new ones.
    # Using a small epsilon so it only breaks ties.
    score += np.where(bins == 100, -1e-6, 0.0)
    return score
