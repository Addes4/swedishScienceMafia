import numpy as np


def priority(item, bins):
    """Best fit with a mild preference for tight fits over empty bins."""
    # bins is a numpy array of remaining capacities; unused bins have capacity 100.
    # Prefer bins that leave the least residual capacity after placing the item.
    residual = bins - item
    # Among bins that already contain something (capacity < 100), score higher for tighter fits.
    # Empty bins get a small penalty so tight fits are preferred when beneficial.
    scores = -residual.astype(np.float64)
    empty_mask = (bins == 100)
    scores[empty_mask] -= 0.5  # slight discouragement for opening a new bin
    return scores
