import numpy as np


def priority(item, bins):
    # remaining capacity after placing item in each bin
    after = bins - item

    # base score: prefer least remaining space after placing (best fit)
    score = -after.astype(np.float64)

    # Exact fit gets a big bonus (avoid wasting a perfect match)
    score += np.where(after == 0, 1000.0, 0.0)

    # Penalize leftover gaps in the "hard to fill" mid-range (say 30..70)
    # Those middling remainders tend to become unusable fragments.
    gap_penalty = np.where((after >= 30) & (after <= 70), 50.0, 0.0)
    score -= gap_penalty

    # Slight preference for fuller bins (smaller remaining capacity = more utilized)
    # to discourage opening too many partially-used bins.
    score -= 0.01 * bins.astype(np.float64)

    return score
