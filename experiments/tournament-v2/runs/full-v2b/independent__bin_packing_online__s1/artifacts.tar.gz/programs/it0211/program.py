import numpy as np

_MIN_ITEM = 1

def priority(item, bins):
    rem = bins.astype(np.float64)          # remaining capacities
    after = rem - item                     # leftover if we place here
    # Primary: prefer tightest fit (smallest leftover).
    score = -after
    # Favourable leftovers are small (near 0) OR leave a remainder that
    # is a likely future item size; penalise remainders that are tiny but
    # nonzero (unusable / fragmenting) slightly by shrinking them further.
    # We keep it simple: a small bonus for exact fit.
    score = score + (after == 0).astype(np.float64) * 0.5
    # Penalise leaving a small positive remainder that is unlikely to be
    # exactly matched (fragmentation), without disturbing tightness order.
    frag = (after > 0) & (after < _MIN_ITEM)
    score = score - frag.astype(np.float64) * 0.25
    return score
