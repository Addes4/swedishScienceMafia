import numpy as np

# State to track bin fill levels (we can infer it from bins array each call)
# We'll keep a simple counter of items seen to enable adaptive behavior.

_state = {
    "calls": 0,
    "total_items": 0,
}

def priority(item, bins):
    """
    Scoring rule for online bin packing.
    
    Strategy:
    - Primary: Best Fit Decreasing-like: prefer the bin where the item fits
      most tightly (smallest remaining capacity after placing).
    - Secondary: Prefer bins that are already open (partially filled) to
      avoid opening new bins unnecessarily.
    - We add a tiny tie-break based on bin index to favor earlier bins.
    
    Since `bins` only contains bins the item *fits* in, and unused bins
    have capacity 100, we can distinguish open bins (capacity < 100).
    """
    _state["calls"] += 1
    _state["total_items"] += item
    
    # remaining after placement
    rem_after = bins - item
    
    # Base score: negative remaining capacity (best fit = tightest fit)
    # Lower remaining capacity after placement is better.
    score = -rem_after.astype(np.float64)
    
    # Bonus for partially filled bins (avoid opening new bins)
    # A bin with remaining capacity 100 is unused. Tiny bonus for used bins.
    used = (bins < 100).astype(np.float64)
    score += used * 0.5
    
    # Bonus for bins that become perfectly full (remaining == 0) -- exact fit
    exact_fit = (rem_after == 0).astype(np.float64)
    score += exact_fit * 2.0
    
    # Small bonus for bins that end up with very low remaining capacity (< 10)
    # to encourage compact packing.
    small_rem = (rem_after < 10).astype(np.float64)
    score += small_rem * 0.3
    
    # Tie-break: earlier bins (lower index) get slightly higher score
    # Since bins array is in bin index order, we can add a tiny decreasing value.
    n = len(bins)
    if n > 0:
        # Add tiny value decreasing with index; ensures ties go to first bin anyway
        score += np.linspace(0, 0.01, n, endpoint=False)
    
    return score
