import numpy as np

_STATE = {
    "n": 0,
    "sum": 0.0,
    "small": 0,
    "large": 0,
}

def priority(item, bins):
    s = _STATE
    s["n"] += 1
    s["sum"] += float(item)
    if item <= 40:
        s["small"] += 1
    else:
        s["large"] += 1

    # Convert to float once; bins is small enough per call.
    b = bins.astype(np.float64, copy=False)

    # Best fit: prefer the smallest remaining capacity >= item.
    # Since all shown bins fit item, smaller b is better.
    fit_score = -b * 1.0

    # Mild preference for fuller bins to reduce fragmentation:
    # fullness = 100 - remaining.
    # This is equivalent to a negative multiple of b, so maintain a balance.
    mean_item = s["sum"] / s["n"] if s["n"] else 40.0

    # Target remaining capacity after placement: moderately small for small items,
    # larger for large items. This is a soft tie-breaker, not a capacity violation.
    if item <= 20:
        target = 100.0 - min(95.0, mean_item * 0.8)
    elif item <= 50:
        target = 100.0 - min(90.0, mean_item * 0.5)
    else:
        target = 100.0 - min(80.0, mean_item * 0.25)

    # Deviation penalty around target.
    dev = np.abs(b - target)

    # Primary: tight fit; secondary: target closeness.
    # Keep primary dominant to preserve online best-fit behavior.
    return fit_score * 1000.0 - dev
