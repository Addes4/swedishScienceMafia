import numpy as np


class Packer:
    """Best-fit with a small "open a new bin" hysteresis.

    The item is placed in the bin it fits most tightly (classic best fit).
    However, if the tightest fit still wastes more than a threshold, and an
    empty bin is available, we prefer the empty bin.  This avoids leaving
    many half-full bins with unusable gaps, which tends to help for a
    continuous Weibull-like size distribution with mean ~40.
    """

    def __init__(self):
        self._threshold = 0.0  # will be adapted

    def priority(self, item, bins):
        # Score = negative remaining-capacity-after-placement (best fit).
        # Empty bins have residual 100 and would naturally score worst, so
        # we must explicitly boost them when best fit would waste too much.
        residual = bins - item  # remaining capacity if item is placed here

        # Best-fit score (higher is better): tighter fit -> higher score.
        score = -residual.astype(np.float64)

        # Identify empty bins (capacity 100) and the best non-empty fit.
        empty_mask = bins >= 100

        # Find minimal residual among all bins (best fit candidate).
        min_res = int(residual.min())

        # If even the best fit wastes more than threshold, prefer an empty bin.
        # threshold chosen to balance opening new bins vs. fragmentation.
        # For mean item ~40, waste > ~25 suggests the bin becomes hard to use.
        WASTE_LIMIT = 25

        if min_res > WASTE_LIMIT:
            # Boost empty bins above any non-empty bin.
            score = np.where(empty_mask, 1.0, score - 1000.0)
        else:
            # Slight preference for empty bins only to break ties toward
            # reducing the number of active bins when fit is equally good.
            score = np.where(empty_mask, score - 0.5, score)

        return score


_packer = Packer()


def priority(item, bins):
    return _packer.priority(item, bins)
