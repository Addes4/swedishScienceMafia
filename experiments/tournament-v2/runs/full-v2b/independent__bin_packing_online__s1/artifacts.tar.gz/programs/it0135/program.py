import numpy as np

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Strategy:
    - Prefer exact or near-exact fits (small resulting leftover capacity).
    - Slight preference for bins that lead to smaller absolute leftover.
    - Ties broken by bin index automatically by harness.
    """
    leftover = bins - item
    # Primary: minimize leftover (best fit). Secondary: minimize leftover squared
    # to sharpen preference for near-perfect fits.
    return -leftover.astype(np.float64) - 0.001 * (leftover.astype(np.float64) ** 2)
