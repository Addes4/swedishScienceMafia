"""Online bin packing via adaptive best-fit with fragmentation-aware scoring."""
import numpy as np

_STATE = {
    "sizes": None,
    "count": 0,
    "sum": 0.0,
}

# Score constants tuned for Weibull-like mean ~40 integer sizes.
# The item goes into the bin with the highest score; ties -> first bin.
# Base: prefer tightest fit (maximize item - residual = minimize residual).
# Penalty: creating residual r in (0, item) can strand capacity if r is tiny.
# Bonus: mild preference for residuals near a target band to reduce waste.
_W_TIGHT = 1.0
_W_WASTE = 0.35   # penalize tiny leftovers
_W_LARGE = 0.06   # slight penalty for needlessly large leftovers
_TARGET = 40.0    # typical item size; residuals near this are useful


def _waste_penalty(residual):
    # residual after placement; penalize small positive residuals < ~12
    # smooth: penalty largest for residual 0..small, fading by ~15
    r = np.maximum(residual, 0)
    return np.where(r < 15.0, (15.0 - r) / 15.0, 0.0) * (r > 0)


def priority(item, bins):
    """Return per-bin priorities for placing `item`; highest score wins."""
    # bins: remaining capacities >= item (only bins that fit)
    residual = bins - item  # capacity left if item is placed here

    # Tightest-fit base: smaller residual is better.
    score = -(_W_TIGHT * residual.astype(np.float64))

    # Penalize creating tiny, unusable leftovers.
    score -= _W_WASTE * _waste_penalty(residual)

    # Slight preference against huge leftovers; favors bins that were already used.
    score -= _W_LARGE * residual.astype(np.float64) * 0.0  # placeholder to keep formula explicit
    # Encourage residuals within a useful band around TARGET.
    band = np.abs(residual.astype(np.float64) - _TARGET)
    score -= 0.002 * band

    # Update running statistics (optional lightweight adaptation).
    _STATE["count"] += 1
    _STATE["sum"] += float(item)

    return score
