import numpy as np

_state = {"last_bin": -1}


def priority(item, bins):
    """
    Score bins for best-fit decreasing-like behavior under an online setting.

    The item goes into the bin with the highest score. We rank bins primarily by
    tightness (smallest remaining capacity after placement), with a small bias
    towards bins that are currently in active use to avoid fragmenting unused bins.
    """
    # Residual capacity if placed in each bin
    residual = bins - item

    # Base: prefer smallest positive residual (best fit). Empty-bin penalty
    # deters putting small items into fresh bins when a fitting used bin exists.
    score = -residual.astype(np.float64)

    # Strongly prefer exact fit (residual == 0) to close bins
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize near-empty/unused bins slightly so small items consolidate
    score -= np.where(bins == 100, 5.0, 0.0)

    # Penalize bins with very large residual relative to item, encouraging
    # use of fuller bins first
    score -= np.maximum(residual, 0) * 0.001

    return score
