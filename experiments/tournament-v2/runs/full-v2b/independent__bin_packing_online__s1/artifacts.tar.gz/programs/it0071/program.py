"""Online bin packing: nearly best fit with a mild fullness-avoidance bias."""
import numpy as np

_DEF = None


def priority(item, bins):
    # Standard best fit: choose the bin with the smallest remaining capacity
    # that still fits the item.  Ties go to the first bin.
    #
    # To improve slightly over pure best fit, we apply a tiny penalty to bins
    # that would become exactly full (leftover 0) and a still tinier penalty
    # to bins that would leave only 1 unit free.  Exact-full bins cannot accept
    # any future item, so leaving a small residual is often better.  The
    # penalty is kept far smaller than 1 capacity unit so it only breaks ties.
    #
    # score = -(remaining_capacity - item)  [best fit]
    #       - exact_full_penalty * (leftover == 0)
    #       - tiny_penalty * (leftover == 1)

    leftover = bins - item  # all entries >= 0 because bins only contains fitting bins

    score = -leftover.astype(np.float64)

    # Tie-break penalties (only matter when two bins have identical leftover,
    # since all leftover differences are at least 1).
    score -= 1e-6 * (leftover == 0)
    score -= 1e-9 * (leftover == 1)

    return score
