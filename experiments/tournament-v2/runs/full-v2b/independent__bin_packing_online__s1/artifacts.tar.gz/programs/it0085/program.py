"""Online bin packing: best fit with a leftover-aware tie-break.

The item goes to the bin where it fits most tightly (best fit).  Since sizes
are Weibull-shaped with mean ~40, the optimal packing is dominated by matching
items that sum near 100, so the primary key is the leftover capacity after
placement.  A tiny state-driven adjustment discourages filling bins in a way
that creates permanently-unusable small leftovers.
"""
import numpy as np

# Track a running estimate of the item-size distribution so that "useless
# leftover" thresholds adapt to the instance.
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    # Update running stats (cheap, scalar ops only).
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    # Best fit: smallest remaining capacity that still fits the item.
    leftover = bins - item            # >= 0 guaranteed by harness
    score = -leftover.astype(np.float64)

    # If the leftover after placing is below the smallest typical item size,
    # that bin becomes hard to reuse.  Slightly penalize such leftovers so
    # that, among near-equal fits, we prefer bins that keep usable space.
    min_useful = max(1.0, 0.25 * mean)
    small = leftover < min_useful
    score -= small.astype(np.float64) * 0.5

    # Mild preference for already-fuller bins to close them out (encourages
    # using existing bins before opening fresh ones only through ordering).
    return score
