import numpy as np

# Keep state, but only for a mild adaptive threshold based on item-size history.
_call_count = 0
_sum_items = 0
_small_items = 0


def priority(item, bins):
    """Rank bins so the item is placed as tightly as possible without over-packing.

    The core rule is best fit: prefer bins whose remaining capacity is closest to the
    item size.  For larger items we slightly prefer less-empty bins so that nearly full
    bins stay available for smaller items, while for small items we allow exact fits
    more aggressively.
    """
    global _call_count, _sum_items, _small_items

    _call_count += 1
    _sum_items += item
    if item <= 10:
        _small_items += 1

    # bins: remaining capacities of bins that can hold `item`.
    # Higher score wins; ties go to earliest bin.
    #
    # Candidate bin quality: prefer bins with small residual after placement:
    #   residual = bins - item
    # But add a small penalty for using nearly-full bins for medium/large items,
    # to preserve exact-fit opportunities for future small items.
    residual = bins - item

    if item <= 5:
        # Tiny items: pure best fit, but break ties toward the fullest bin.
        score = -residual.astype(np.float64)
        score += 1e-6 * bins
        return score

    if item <= 15:
        # Small items: best fit with a slight preference for tighter bins.
        score = -residual.astype(np.float64)
        score -= 0.002 * bins
        return score

    # Medium/large items: best fit, but avoid consuming a bin that is exactly
    # full except for this item if another bin leaves it more breathing room.
    # This is a smooth version of "leave exact fits for small future items".
    score = -residual.astype(np.float64)

    # Penalize placing a large item into a bin whose remaining capacity is very
    # close to the item size (i.e. would nearly fill it), because such bins are
    # valuable for future exact fits.  The penalty is tiny and only affects ties
    # or near-ties.
    nearly_exact = (residual <= 3).astype(np.float64)
    score -= 0.05 * nearly_exact

    # Prefer fully empty bins only when there is no better tight fit.
    score += 1e-9 * (bins == 100)

    return score
