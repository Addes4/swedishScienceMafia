"""Online bin packing priority: best fit with a mild bias against opening fresh bins."""
import numpy as np


def priority(item, bins):
    """Rank bins by residual capacity after placing `item`, preferring fuller existing bins.

    The item should go to the bin where it fits most tightly.  A tiny bonus for bins
    that are already partially filled discourages using empty bins unless necessary,
    which tends to reduce the number of bins on Weibull-shaped inputs.
    """
    residual = bins - item

    # Primary rule: smaller residual => higher score.
    score = -residual.astype(np.float64)

    # Slight preference for already-used bins (remaining < 100) over unused ones.
    score += np.where(bins < 100, 0.001, 0.0)

    return score
