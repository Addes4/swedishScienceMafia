import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0

    def update(self, x):
        self.n += 1
        delta = x - self.mean
        self.mean += delta / self.n
        self.m2 += delta * (x - self.mean)

    @property
    def std(self):
        if self.n < 2:
            return 15.0
        return float(np.sqrt(self.m2 / self.n))


_state = _State()


def priority(item, bins):
    global _state
    _state.update(item)

    # Main heuristic: best fit (smallest residual).
    # Penalize unusable/awkward residuals and empty-bin starts a bit.
    # The mean/std estimate is only used as a gentle regularizer.
    std = max(5.0, min(30.0, _state.std))
    empty = bins == 100

    # residual after placing item
    residual = bins - item

    # Best fit: lower residual gets higher score.
    score = -residual.astype(np.float64)

    # Slightly discourage leaving tiny unusable gaps (hard to fill later),
    # without hurting exact fits (residual == 0).
    tiny = (residual > 0) & (residual < std * 0.5)
    score[tiny] -= 0.5

    # Slightly prefer not to open new bins unless fitting is poor.
    score[empty] -= 0.25

    return score
