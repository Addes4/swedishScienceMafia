"""Best-fit-like online bin packing heuristic with a slight penalty for new bins."""
import numpy as np


def priority(item, bins):
    """Score bins: higher is better.

    The item goes into the bin with the highest score. Ties go to the first bin.

    We use a best-fit policy, preferring bins with the smallest remaining capacity
    after placement.  A tiny bonus for full (or near-full) bins is added, which
    tends to preserve larger free bins for future items in this Weibull-like
    distribution where moderately sized items are frequent.

    Parameters
    ----------
    item : int
        Size of the arriving item (1..100).
    bins : numpy int64 array
        Remaining capacity of every bin the item fits in, including unused bins
        (remaining capacity 100), in bin order.

    Returns
    -------
    numpy array of scores, same length as bins.
    """
    # Remaining capacity after placing the item.
    remaining_after = bins - item

    # Base score: prefer the tightest fit (smallest remaining after placement),
    # but avoid using mostly-empty bins unless necessary.
    # We invert remaining_after so larger means better, and add a small bonus
    # for bins that become completely full (remaining_after == 0).
    score = -(remaining_after.astype(np.float64))

    # Small bonus for exactly full bins; this can help reduce waste.
    score += np.where(remaining_after == 0, 0.25, 0.0)

    return score
