import numpy as np


def priority(item, bins):
    """Best-fit with a mild preference for already-used bins.

    Score is higher for smaller leftover capacity after insertion.
    Add a small bonus for non-empty bins to avoid opening a new bin
    unless it is meaningfully better than reusing an existing one.
    """
    leftover = bins - item
    score = -leftover.astype(np.float64)

    # Prefer bins that already contain items (remaining capacity < 100).
    # This slightly biases against opening unused bins when the fit is close.
    score += np.where(bins < 100, 0.05, 0.0)

    return score
