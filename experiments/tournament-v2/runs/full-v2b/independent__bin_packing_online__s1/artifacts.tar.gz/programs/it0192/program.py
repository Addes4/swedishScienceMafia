# EVOLVE-BLOCK-START
"""Adaptive best-fit heuristic for online bin packing."""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.sum = 0.0
        self.sum_sq = 0.0
        self.max_seen = 1
        self.alpha = None

    def update(self, item):
        x = float(item)
        self.count += 1
        self.sum += x
        self.sum_sq += x * x
        if item > self.max_seen:
            self.max_seen = item
        if self.alpha is None:
            self.alpha = 0.948

    def fit_alpha(self):
        n = self.count
        if n < 20:
            return 0.948
        mean = self.sum / n
        var = max(self.sum_sq / n - mean * mean, 1e-9)
        # Tune the penalty slope based on mean item size vs capacity.
        # Empirically, larger mean items favor stronger tightness;
        # smaller items need slightly less greedy fitting.
        slope = 1.0 - 0.35 / (1.0 + np.exp((mean - 38.0) / 8.0))
        # Cap to reasonable range
        slope = min(max(slope, 0.55), 1.0)
        # Capacity scale: remaining-capacity penalty exponent
        alpha = 1.0 - 0.15 * slope
        return alpha


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state.update(item)
    alpha = _state.fit_alpha()

    b = bins.astype(np.float64)
    n = b.shape[0]

    # Base: best fit = prefer the tightest remaining capacity.
    # We use -(remaining - item) but add a small bonus for already-used bins,
    # adapting the penalty strength.
    remaining = b
    used = 100.0 - remaining

    # Best-fit score.
    tightness = -(remaining - float(item))

    # Fullness bonus: encourage putting into bins that are already fuller,
    # which tends to reduce bin count in online packing.
    fullness = (used / 100.0) ** alpha

    # Slight penalty for opening brand-new bins when a viable used bin exists.
    new_bin_penalty = np.where(remaining >= 99.999, -0.02, 0.0)

    return tightness + 0.35 * fullness + new_bin_penalty
# EVOLVE-BLOCK-END
