import numpy as np


def priority(item, bins):
    """Priority for each bin: prefer the bin that becomes fullest after placement.

    This is essentially best fit (smallest remaining capacity after the item), but
    the score is made strictly monotone in the post-placement remaining capacity
    so that ties are resolved toward fuller bins consistently.
    """
    after = bins - item
    # Higher score for smaller remaining capacity after placement.
    # Negative remaining capacity gives exact best-fit ordering.
    return -after
