import numpy as np

def priority(item, bins):
    """
    Score bins for placing the current item.
    Primary: best-fit (prefer bins whose remaining capacity is closest to item).
    Tie-break / slight bias: prefer bins that are more full (smaller remaining capacity),
    which encourages consolidation and can reduce bin count.
    """
    # Best-fit: score = -(bins - item) = item - bins  -> higher for tighter fit
    # Add a small term preferring fuller bins: -bins * epsilon
    # Use integer-safe arithmetic to avoid float issues; scale epsilon small.
    return (item - bins) * 1000 - bins
