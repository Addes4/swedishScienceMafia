"""Online bin packing heuristic: best-fit with a small-residual guard.

For each arriving item, score fitting bins by a combination of:
  - tightness (prefer small remaining capacity after placing the item)
  - a penalty for leaving a residual that is too small to be useful.

This is essentially Best Fit with a threshold penalty, a well-known improvement
for online bin packing under random item sizes.
"""
import numpy as np

# Residual sizes below this threshold are considered "wasted" and penalized,
# since they can rarely accommodate another item.  Chosen from the fact that
# item sizes are Weibull with mean ~40, so residuals far below that tend to
# strand capacity.
_RESIDUAL_THRESHOLD = 12.0
_PENALTY = 3.0


def priority(item, bins):
    """Score each fitting bin; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of bins the item fits in,
          including unused bins (remaining capacity 100), in fixed bin order.
    """
    residual = bins - item
    # Primary objective: minimize residual (best fit).  We turn it into a
    # maximization score by taking the negative residual.
    score = -residual.astype(np.float64)
    # Penalize residuals that are too small to be useful, encouraging the
    # item to go into a bin that will later be more fillable.
    small = residual < _RESIDUAL_THRESHOLD
    score[small] -= _PENALTY * (_RESIDUAL_THRESHOLD - residual[small])
    return score
