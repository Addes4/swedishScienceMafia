import numpy as np

_S = {}

def priority(item, bins):
    # Track recent item sizes to estimate the local distribution (light adaptation).
    hist = _S.setdefault("hist", np.zeros(101, dtype=np.float64))
    hist[item] += 1.0
    total = hist.sum()
    seen = _S.get("seen", 0)
    _S["seen"] = seen + 1

    b = bins.astype(np.float64)
    # Remaining capacity after placing item (smaller = tighter fit).
    new_rem = b - float(item)

    # Best-fit base: strongly prefer bins that become nearly full,
    # but avoid making a bin exactly full if it is a freshly opened bin
    # and items are small (save full bins for larger residual patterns is not relevant
    # since capacity is enforced anyway).
    base = -new_rem

    # Slight preference for filling bins that already have some used space:
    # used = 100 - b.
    used = 100.0 - b

    # Avoid leaving a bin with residual capacity that is just below a typical item?
    # A mild penalty for residuals in [1, 5] (hard to reuse), bonus for zero residual.
    score = base

    # Extra bonus for perfect fit (new_rem == 0).
    score += (new_rem == 0).astype(np.float64) * 0.25

    # Penalize leaving tiny unusable gaps.
    tiny = (new_rem > 0) & (new_rem <= 3)
    score -= tiny.astype(np.float64) * 0.35

    # Mild balancing: prefer not to touch completely empty bins unless fit is very good.
    empty = (b == 100.0)
    score -= empty.astype(np.float64) * 0.05

    # Stateful tweak: if we have seen many items and the average size is near 40,
    # slightly prefer tighter fits (best fit) over opening bins.
    if total > 50:
        mean_item = float((hist * np.arange(101)).sum() / total)
        if mean_item < 45.0:
            score -= empty.astype(np.float64) * 0.05

    return score
