import numpy as np

# Global state
_hist = np.zeros(101, dtype=np.int64)  # index 0 unused, 1..100
_total_seen = 0

def priority(item, bins):
    global _hist, _total_seen
    # Update histogram with current item? Actually, we should update after placing? 
    # We can update before or after, but we need the histogram for scoring. 
    # Using current item in histogram might bias, but it's fine.
    # However, we don't know if the item will be placed, but it will be. So we can update now.
    _hist[item] += 1
    _total_seen += 1

    n = len(bins)
    scores = np.empty(n, dtype=np.float64)
    # Precompute frequencies
    freqs = _hist / _total_seen if _total_seen > 0 else np.zeros(101)

    # Parameters
    alpha = 50.0
    penalty_threshold = 10
    penalty = 50.0

    for i, c in enumerate(bins):
        L = c - item
        if L == 0:
            scores[i] = 1e6
        else:
            base = -L
            bonus = alpha * freqs[L] if L <= 100 else 0.0
            pen = penalty if L < penalty_threshold else 0.0
            scores[i] = base + bonus - pen
    return scores
