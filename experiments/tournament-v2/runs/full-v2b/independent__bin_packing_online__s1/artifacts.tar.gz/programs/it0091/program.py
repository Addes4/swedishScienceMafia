import numpy as np


class Packer:
    def __init__(self):
        # Histogram of seen item sizes to estimate typical residuals.
        self.size_counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0

    def observe(self, item):
        self.size_counts[item] += 1.0
        self.total += 1.0

    def priority(self, item, bins):
        self.observe(item)
        # Best fit: prefer bins where the leftover after placing is smallest.
        leftover = bins - item  # all >= 0 since bins shown only fit the item

        # Adaptive component: reward bins whose resulting leftover is a size
        # that has been frequently seen, so future items are likely to fit tightly.
        # Use a smoothed probability estimate over leftover sizes.
        probs = (self.size_counts[leftover] + 1.0) / (self.total + 101.0)

        # Primary: tightest fit. Secondary: leftover that matches common item sizes.
        score = -leftover.astype(np.float64) + probs
        return score


_packer = Packer()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    return _packer.priority(item, bins)
