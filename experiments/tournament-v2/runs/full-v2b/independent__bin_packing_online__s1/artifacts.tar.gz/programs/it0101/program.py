import numpy as np

# State (bounded, distribution-level only)
_STATS = {
    "seen": 0,
    "sum": 0.0,
    "bins_opened": 0,
}
# Constants
CAP = 100
# Threshold below which we treat item as "small" (helps decide whether it's worth
# opening a fresh bin or squeezing into an existing near-full bin)
_SMALL = 30


def priority(item, bins):
    """Best-fit variant: tightest fit, with a slight preference for fuller bins.

    Primary rule: highest remaining-capacity-tightness (classic Best Fit).
    Tie-breaking / near-tie shaping: prefer bins whose current remaining capacity
    is closer to `item` (tighter fit), which minimizes waste. For small items we
    add a small bonus for already-used bins to discourage needless new-bin opening.
    """
    # bins: remaining capacity of fitting bins (unused = 100)
    # Best Fit priority: larger score when remaining capacity is closer to item
    # Use negative absolute leftover (less leftover => higher score).
    leftover = bins - item

    # Base score: tightest fit first.
    score = -leftover.astype(np.float64)

    # Mild shaping: among equal/near-equal fits, prefer bins that are already fuller
    # (lower remaining capacity before placement => less likely to strand space).
    # This is a small, bounded adjustment and cannot overturn a strictly better fit.
    score *= 1.0  # keep as float

    # Bonus for using an existing bin over a pristine unused bin (capacity == 100),
    # only meaningful for items that leave the unused bin nearly empty afterwards.
    # Small magnitude to preserve fit ordering.
    unusedness = (bins == CAP) & (leftover > (CAP - item - _SMALL))
    # Actually: discourage opening new bins for small items.
    if item <= _SMALL:
        is_unused = (bins == CAP)
        # Prefer non-unused bins slightly
        score += np.where(is_unused, -1.0, 0.0)

    # Slight preference for fuller (smaller remaining) bins as a secondary signal.
    # Scale tiny relative to 1 unit of leftover difference.
    score += -0.01 * bins.astype(np.float64)

    # Track stats (optional, harmless)
    _STATS["seen"] += 1
    _STATS["sum"] += item

    return score
