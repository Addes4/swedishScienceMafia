import numpy as np


def priority(item, bins):
    """Rank bins for an arriving item.

    Primary idea: best fit (smallest remaining capacity that still fits the item).
    To improve packing, we slightly penalize bins that would become very full
    (leaving little space) and add a tiny tie-breaking term.
    """
    residual = bins - item
    # Best fit: prefer smaller residual capacity after placing the item.
    # We use a small nonlinear penalty to avoid overly full bins when possible.
    score = -residual.astype(np.float64)
    # Mild preference for bins that are not extremely full after placement.
    # residual == 0 is unavoidable sometimes, but otherwise avoid tiny residuals.
    score -= 0.02 / (residual.astype(np.float64) + 1.0)
    # Tiny deterministic tie-break using bin capacity and item to stabilize choices.
    score += 1e-6 * (bins.astype(np.float64) % 97)
    return score
