"""Online bin packing: best-fit with perfect-fit and gap-avoidance priority."""
import numpy as np

# Track simple global stats (allowed to keep state between calls).
_state = {"n": 0}


def priority(item, bins):
    """Return a priority for every bin; highest wins (ties go to first).

    Strategy:
      - Perfect fit (remaining == item): highest priority.
      - Otherwise best fit: minimize leftover capacity.
      - Extra tiebreak: avoid leaving a small leftover that few items fit.
    """
    _state["n"] += 1

    leftover = bins - item  # remaining capacity after placing item (>=0)

    # Higher score is better.  Primary: perfect fit.
    perfect = (leftover == 0).astype(np.float64)

    # Secondary: prefer smaller leftover (best fit).
    # Normalize leftover to [0,1]; smaller is better -> negate.
    neg_leftover = -leftover.astype(np.float64)

    # Tertiary: penalize leftovers in the "bad small gap" region
    # (1..19) where few items can fit, encouraging tighter or fuller bins.
    gap_penalty = np.where((leftover >= 1) & (leftover <= 19),
                           leftover.astype(np.float64) * 0.01,
                           0.0)

    score = perfect * 1000.0 + neg_leftover - gap_penalty
    return score
