import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        # track sum of squares to estimate mean/variance
        self.sumsq = 0.0

    def update(self, x):
        self.count += 1
        self.total += x
        self.sumsq += float(x) * float(x)

    def mean(self):
        if self.count == 0:
            return 40.0
        return self.total / self.count


_stats = _Stats()


def priority(item, bins):
    """Best fit with consolidation bias.

    Rank bins primarily by tightest fit (smallest remaining capacity after placing),
    but add a mild tendency to fill already-used bins to reduce bin count.
    """
    _stats.update(item)

    bins = np.asarray(bins)
    remaining_after = bins - item

    # Primary: tightest fit => smallest remaining after placement
    # We want highest score to win, so negate.
    score = -(remaining_after).astype(np.float64)

    mean = _stats.mean()

    # Consolidation bonus: slightly prefer bins that are already more full
    # (less remaining capacity), scaled small so it doesn't override best-fit.
    used = bins < 100
    fullness = (100.0 - bins) / 100.0  # 0 for empty, up to ~1

    # Encourage packing into partially filled bins rather than opening new ones.
    score += 0.30 * fullness

    # Add a small penalty for completely empty (unused) bins to delay opening
    # new ones, scaled by how far into the process we are.
    progress = min(1.0, _stats.count / 200.0)
    score -= 0.15 * progress * (bins == 100)

    return score
