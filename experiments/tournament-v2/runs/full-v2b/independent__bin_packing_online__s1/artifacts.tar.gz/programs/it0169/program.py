"""Online bin packing: adaptive best-fit with a closing threshold.

Idea
----
Pure best-fit packs tight but can strand small residual capacities that later
medium items cannot use.  Pure worst-fit avoids this but wastes space early.

Here we estimate the online mean item size (exponential moving average) and use
it to bias best-fit: among bins the item fits into, we strongly prefer bins
whose remaining capacity after placing the item is either very small (nearly
closed) or large enough to still accept an average future item.  This keeps a
supply of "open" bins for small/medium arrivals while still closing gaps.

The score is a smooth function of the post-placement remaining capacity r:

    score = -|r - target(item)|        if r < mean_est
    score =  large + r                 otherwise

i.e. we prefer r as close as possible to the item's own size band, but we
reward large leftover space to preserve open bins.  On ties, the first bin
wins (the harness supplies bins in fixed index order, which naturally tends
to fill earlier bins).
"""
import numpy as np

# State kept between calls.
_state = {
    "mean": 40.0,          # EMA estimate of item size
    "n": 0.0,
}


def priority(item, bins):
    """Return a priority per bin; highest score gets the item."""
    # Update online mean estimate of item sizes (exponential moving average).
    n = _state["n"]
    m = _state["mean"]
    # Use a decreasing learning rate that converges quickly but stays adaptive.
    alpha = 1.0 / (n + 2.0)
    m = m + alpha * (float(item) - m)
    _state["mean"] = m
    _state["n"] = n + 1.0

    # Post-placement remaining capacity for each candidate bin.
    r = bins.astype(np.float64) - float(item)

    # Target leftover: we like to either nearly close a bin or leave room for
    # a typical future item.  Scale with the online mean.
    target = 0.5 * m

    # Bins that would remain below the target are treated as "closing" bins:
    # we prefer them to end as empty as possible (small r), i.e. tight fit.
    # Bins that would remain above the target are "open" bins: we prefer them
    # to keep plenty of space, so we rank them by decreasing r.
    small = -np.abs(r - target)      # best for bins that will close

    # A large constant ensures open bins (r >= target) always beat closing bins,
    # and among them more free space is better.
    big = 1.0e6 + r

    score = np.where(r < target, small, big)

    # Slight preference for the lowest-index bin among identical scores is the
    # harness default (first on ties), so no extra term is needed.
    return score
