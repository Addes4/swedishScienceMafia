import numpy as np


def priority(item, bins):
    # Modify best fit slightly to encourage packing into partially-filled bins
    # rather than repeatedly consuming fresh bins or leaving awkward residuals.
    residual = bins - item

    # Prefer small residual (tight fit). Ties broken by lower index naturally.
    score = -residual.astype(np.float64)

    # Slight extra preference for bins whose residual after placement is small
    # but not zero, reducing fragmentation of medium bins.
    # Penalise using completely empty bins when partially-filled ones are viable.
    empty_penalty = np.where(bins == 100, 0.5, 0.0)

    return score - empty_penalty
