import numpy as np

_last_items = []
_sum = 0.0
_count = 0

def priority(item, bins):
    global _sum, _count
    _sum += item
    _count += 1
    avg = _sum / _count

    residual = bins - item
    # Base best-fit: smaller residual -> higher score
    score = -residual.astype(np.float64)

    # Slightly prefer bins that are neither too empty (large residual, wasteful)
    # nor exactly full, to avoid fragmenting and to keep flexibility.
    # Penalize bins that would become exactly 0 (perfect fill) only mildly,
    # since perfect fill is actually good but may be rare.
    # Encourage leaving small residual (tight fit).
    # Add a small preference to bins with residual close to 0 but > 0.
    tightness = 1.0 / (residual + 1.0)
    score += 0.05 * tightness

    # Avoid placing large items into near-empty bins if a large item is expected.
    # If item is large (above average), prefer tighter fits more strongly.
    if item > avg:
        score -= 0.02 * bins.astype(np.float64)

    # If item is small, prefer bins that are already fairly full to consolidate.
    else:
        score -= 0.01 * bins.astype(np.float64)

    return score
