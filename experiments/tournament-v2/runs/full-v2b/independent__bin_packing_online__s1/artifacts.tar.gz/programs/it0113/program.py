"""Online bin packing: prefer exact fits, then tightest fit, then reuse over opening new bins."""
import numpy as np


def priority(item, bins):
    """Return a score per bin; highest score wins, ties go to the first bin.

    item: integer size 1..100.
    bins: numpy int64 array of remaining capacities (100 for unused bins), in bin order.
    """
    # Prefer bins that fit exactly (score highest).
    exact = (bins == item).astype(np.float64) * 1e9
    # Then prefer the tightest fit: smaller remaining capacity after placing item.
    residual = bins - item
    tight = -residual.astype(np.float64)
    # Small preference for already-used bins (residual < 100 - item means bin already had items).
    # Unused bins have bins == 100; penalize opening them slightly.
    used_bonus = np.where(bins < 100, 1.0, 0.0)
    return exact + tight + used_bonus
