import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.exact = 0

    def observe(self, item):
        self.n += 1
        self.sum += float(item)


_state = _State()


def priority(item, bins):
    """Best-fit with a small-size leftover penalty and empty-bin preservation."""
    _state.observe(item)

    # Residual after placing the item.
    rem = bins - item

    # Prefer tight fits: lower remaining capacity gets a higher score.
    score = -rem.astype(np.float64)

    # Do not eagerly create very small unusable leftovers unless necessary.
    # A leftover of 1..3 is usually bad, while 0 is perfect.
    small = (rem > 0) & (rem <= 3)
    score[small] -= 1.5 + (4 - rem[small])

    # Strongly reward exact fits.
    exact = rem == 0
    score[exact] += 25.0

    # Avoid opening/using completely empty bins when a used bin fits well.
    empty = bins == 100
    score[empty] -= 0.75

    # If the item is large, empty bins are more valuable; penalize opening them slightly more.
    if item >= 60:
        score[empty] -= 0.5

    # Slight preference to keep mid-sized pockets available for future medium items.
    # Penalize leaving capacity just below a typical item size around the running mean.
    mean = _state.sum / _state.n if _state.n else 40.0
    target = int(round(mean))
    if 1 <= target <= 100:
        near = (rem > 0) & (rem < target)
        score[near] -= 0.1

    return score
