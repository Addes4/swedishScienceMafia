"""Online best-fit with a small tie-break preference and light state.

The score is designed so the best fitting bin is generally chosen, but among
nearly equally good bins we prefer already-used bins (lower remaining capacity)
to keep the number of open bins small.  A tiny penalty is applied to completely
empty bins so they are only used when clearly necessary.
"""
import numpy as np


def priority(item, bins):
    # Precise best fit: prefer smallest remaining capacity that still fits.
    # Add a small bias against perfectly empty bins to reduce bin count.
    # Bins are given only if they fit, so remaining >= item always.
    rem = bins.astype(np.float64)

    # Base score: negative remaining capacity => tighter fit scores higher.
    score = -rem

    # Penalty for empty (capacity 100) bins so we don't open new bins eagerly.
    # A very small epsilon keeps best-fit as the dominant criterion.
    score -= np.where(rem == 100.0, 1e-6, 0.0)

    return score
