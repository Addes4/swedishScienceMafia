"""Online bin packing: best fit with residual shaping.

The main rule is Best Fit: place the item into the feasible bin with the
smallest remaining capacity (tightest fit).  A tiny secondary term discourages
leaving very small residual capacities, which are hard to fill later, while
still preserving the core best-fit ordering.
"""
import numpy as np


def priority(item, bins):
    # Bins array contains remaining capacities of all feasible bins.
    # Best fit: maximize -(remaining - item), i.e. minimize remaining.
    # Secondary shaping: slightly prefer residuals that are not too small,
    # to avoid wasting bins on tiny leftover spaces.
    residual = bins - item
    base = -residual.astype(np.float64)

    # Penalize very small residuals (1..8) slightly; keep this tiny so it
    # only breaks near-ties in base score.
    small = np.clip(9 - residual, 0, 8).astype(np.float64)
    penalty = 0.01 * small

    return base - penalty
