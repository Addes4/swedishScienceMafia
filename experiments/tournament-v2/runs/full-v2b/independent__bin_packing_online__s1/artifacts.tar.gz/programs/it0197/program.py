"""Best-fit style rule with exact-fit and residual-aware scoring."""

import numpy as np

# Cache for small complement counts: not needed for scoring, but harmless.
def priority(item, bins):
    # bins: remaining capacities of bins that fit the item.
    # We want the bin whose remaining capacity is closest to item,
    # i.e. minimize residual = bins - item.
    #
    # To avoid wasting perfectly matching residual space, strongly prefer
    # exact fits (residual 0). Otherwise, prefer small positive residuals
    # that are more likely to be filled by common item sizes (mean ~40).
    residual = bins - item

    # Base: tighter fit is better.
    # Use a nonlinear penalty to sharpen around exact fits.
    score = -residual

    # Strongly boost exact fits so they are never skipped.
    score = np.where(residual == 0, 1e9, score)

    # Mild preference for residuals that are themselves plausible item sizes.
    # Common small residuals are more useful than awkward ones.
    # Penalize very large leftovers less than medium awkward ones.
    # This is a smooth heuristic, not tuned to a specific instance.
    nice = (residual <= 40)
    score = np.where(nice & (residual > 0), score + 0.5, score)

    return score
