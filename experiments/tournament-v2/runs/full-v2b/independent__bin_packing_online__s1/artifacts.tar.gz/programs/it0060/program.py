import numpy as np


def priority(item, bins):
    """Best-fit with a gentle penalty for creating hard-to-use small gaps.

    The item goes into the bin with the highest score.  We rank by:
      1. tightest fit (smallest residual capacity), and
      2. a small tie-breaker that prefers placements that do not leave a
         leftover capacity in the awkward range just below typical large items.
    """
    residual = bins - item

    # Tightest fit gets the highest score.
    score = -residual.astype(np.float64)

    # Small bonus for placements whose new residual is either zero or
    # reasonably large, and a penalty for residuals that are likely to be
    # stranded (for example 1..20 when large items are common).
    # This is deliberately mild so best-fit still dominates.
    r = residual
    # Prefer exact fills very slightly.
    score += (r == 0) * 0.25
    # Slight dislike for tiny leftovers that cannot fit much.
    score -= ((r > 0) & (r < 15)) * 0.15
    # Slight dislike for residuals just under common large sizes.
    score -= ((r >= 55) & (r < 75)) * 0.05

    return score
