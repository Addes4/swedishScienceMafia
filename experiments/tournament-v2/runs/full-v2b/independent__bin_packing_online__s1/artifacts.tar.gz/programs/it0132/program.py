"""Best-fit with slight preference against opening new bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Best fit: most tightly fitting bin first (small residual after placement).
    A tiny bonus is given to already-used bins to avoid opening a new bin on ties.
    """
    residual = bins - item
    # Primary: smaller residual is better (best fit).
    # Secondary: tiny bonus for bins that are not yet empty (avoid opening new bins).
    score = -residual.astype(np.float64)
    score += np.where(bins < 100, 0.001, 0.0)
    # Tertiary: prefer tightest overall (smaller remaining capacity), stable tie-break.
    score += (100 - bins) * 1e-6
    return score
