import numpy as np


def priority(item, bins):
    """Adaptive best-fit with fragmentation penalty.

    Prefer bins that leave little waste, but penalize bins whose residual
    after placing the item would be small enough to be nearly unusable.
    This behaves like best fit while reducing the creation of tiny fragments.
    """
    residual = bins - item
    scores = -residual.astype(np.float64)

    # Penalize very small residuals: an almost-full bin with a tiny leftover
    # is unlikely to receive another item. Slightly prefer leftovers that can
    # still host common small items.
    small = residual < item
    waste_penalty = np.where(small, (item - residual) * 0.01, 0.0)

    # Slight preference for not touching completely empty bins unless needed.
    empty_bonus = np.where(bins == 100, -0.05, 0.0)

    return scores - waste_penalty + empty_bonus
