import numpy as np


class Packer:
    def __init__(self):
        self.n_calls = 0
        self.mean_item = 40.0
        self.sum_item = 0.0
        self.item_count = 0
        # Smooth estimate of typical item size; starts at the known mean.
        self.smooth_mean = 40.0
        self.last_item = 40

    def priority(self, item, bins):
        self.n_calls += 1
        self.item_count += 1
        self.sum_item += item

        # Exponential moving average of item sizes (adapts slowly, no future peeking).
        self.smooth_mean = 0.98 * self.smooth_mean + 0.02 * item
        self.last_item = item

        # Best fit: prefer the bin with the smallest remaining capacity that still fits.
        # bins is an int64 numpy array of remaining capacities (>= item).
        closeness = -(bins - item)

        # Detect unused bins (capacity 100). Prefer using non-empty bins when fits
        # are reasonably close, to avoid opening new bins prematurely.
        unused_mask = (bins == 100)

        # Base score: tighter fit is better.
        score = closeness.astype(np.float64)

        # Bonus for already-used bins (non-100 capacity) to discourage opening new bins.
        # Magnitude scales mildly with the typical item size; small enough not to
        # override a significantly better exact fit.
        used_refill_bonus = 0.35 * self.smooth_mean
        score = np.where(unused_mask, score, score + used_refill_bonus)

        # Among near-equal fits, favor the most loaded used bin (smallest remaining)
        # again through closeness already; done implicitly.

        return score


_packer = Packer()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    return _packer.priority(item, bins)
