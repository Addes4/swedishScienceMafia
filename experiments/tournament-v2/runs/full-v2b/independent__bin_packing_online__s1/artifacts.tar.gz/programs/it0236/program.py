import numpy as np


def priority(item, bins):
    """Best-fit: prefer the bin the item fits most tightly. Unused bins (capacity 100)
    are naturally least preferred for items < 100, so they are only chosen when necessary."""
    return -(bins - item)
