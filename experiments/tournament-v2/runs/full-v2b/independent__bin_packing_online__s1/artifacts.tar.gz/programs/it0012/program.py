import numpy as np

# Keep this simple so it remains valid when called with the evolving harness.

def priority(item, bins):
    # Best-fit with a small bias toward already-used bins.
    # `bins` only contains bins the item fits in; unused bins have 100.
    # Score lower remaining capacity higher, but slightly penalize 100-cap bins
    # so we reuse partially filled bins before opening new ones.
    # Add a tiny index-based tie-breaker to encourage deterministic reuse.
    rem = bins.astype(np.int64, copy=False)
    score = -(rem - item)
    # Disfavor unused bins a bit relative to equally fitting used bins.
    score = score.astype(np.float64, copy=False)
    score[rem == 100] -= 0.01
    return score
