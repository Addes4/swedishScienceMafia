import numpy as np

# Global state
_counts = np.zeros(101, dtype=np.float64)
_seen = 0


def priority(item, bins):
    global _counts, _seen

    # Update observed item distribution.
    _counts[item] += 1.0
    _seen += 1

    n = bins.shape[0]
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # Score bins. Main term: best fit (prefer smallest residual capacity >= item).
    # This is equivalent to preferring the largest used capacity in a bin that still fits.
    residuals = bins.astype(np.int64)

    # Base best-fit score: negative leftover (higher is better).
    # Small tie-break to prefer fuller bins (same as -(bins-item)).
    score = -(residuals - item).astype(np.float64)

    # Add a mild "usefulness" term: bins whose residual capacity equals a frequently
    # observed item size are slightly preferred, because they may be filled exactly.
    # Avoid overfitting to early random samples: weight grows slowly and is capped.
    if _seen > 0:
        freq = _counts / _seen
        # Weight is intentionally small so it does not override tight fit.
        # Cap total influence.
        w = min(1.0, _seen / 500.0) * 0.35
        # For each bin residual r, reward if r corresponds to a common future item size.
        # Use vectorized lookup over residuals (0..100). Residual 0 is useless.
        idx = np.clip(residuals, 0, 100).astype(np.int64)
        bonus = freq[idx] * 100.0  # typical freq on the order 0..1, scale to comparable units
        score += w * bonus

    # Prefer bins that are already somewhat full on exact ties, preserving compactness.
    # (Already encoded in -residual; keep a tiny extra term for deterministic stability.)
    return score
