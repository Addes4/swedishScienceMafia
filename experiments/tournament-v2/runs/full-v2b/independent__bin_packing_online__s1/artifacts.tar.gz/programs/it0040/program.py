import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.sum = 0
        self.sum2 = 0.0
        self.alpha = 0.0

    def update(self, item):
        self.count += 1
        self.sum += item
        self.sum2 += float(item) * item


_STATE = _State()


def priority(item, bins):
    st = _STATE
    st.update(item)

    n = bins.size
    idx = np.arange(n, dtype=np.float64)

    # Best-fit score: prefer smallest remaining capacity that still fits.
    score = -bins.astype(np.float64)

    # Estimate a soft "normal" remaining capacity to avoid wasting bins.
    mean = st.sum / st.count if st.count else 40.0
    var = max(0.0, (st.sum2 / st.count if st.count else 1600.0) - mean * mean)
    sigma = max(8.0, min(25.0, var ** 0.5))

    # Avoid placing into bins that become too full early; slight preference for fit.
    # Penalize bins whose remaining after placement is very small, but less strongly
    # once many items have been seen and tight packing matters more.
    tight = bins.astype(np.float64) - item
    reserve = max(0.0, min(18.0, 0.45 * mean - 0.35 * sigma))
    if st.count < 4000:
        score -= (tight < reserve).astype(np.float64) * (reserve - tight) * 0.08

    # Mild preference for using bins in index order when capacities are close.
    score -= idx * 1e-7

    return score
