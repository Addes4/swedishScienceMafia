import numpy as np


def priority(item, bins):
    """
    Score each candidate bin for the arriving item.

    We use a refined best-fit rule:
      - Strongly prefer bins whose residual after placing the item is small (best fit),
        but additionally reward residuals that are "useful" (>= some small threshold),
        and penalize residuals that are too tiny to be useful.
      - Prefer fuller bins (smaller remaining capacity) to reduce fragmentation.
      - Also prefer bins that already exist (remaining <= 100 - something) over completely
        empty bins when the fit quality is comparable, to keep the number of open bins low.

    The returned score is maximized. Higher score = better bin.
    """

    # residual capacity left after placing this item
    residual = bins - item

    # Base score: best fit => smaller residual is better.
    # Use a large negative weight on residual.
    score = -1000.0 * residual

    # Penalize tiny unusable residuals that would strand capacity.
    # A residual in [1, 9] is often wasted space; penalize it.
    tiny = (residual >= 1) & (residual <= 9)
    score -= np.where(tiny, 500.0 * residual, 0.0)

    # Slightly reward medium-useful residuals (10..item range) to encourage good packing.
    useful = (residual >= 10) & (residual <= 60)
    score += np.where(useful, 5.0 * residual, 0.0)

    # Prefer bins that are already partially filled (smaller current remaining capacity),
    # to consolidate and avoid opening completely new bins when fits are similar.
    # Empty bins have remaining 100; give them a small penalty relative to used bins.
    score -= np.where(bins >= 100, 50.0, 0.0)

    # Prefer bins that will be exactly full.
    exact = residual == 0
    score += np.where(exact, 10000.0, 0.0)

    return score
