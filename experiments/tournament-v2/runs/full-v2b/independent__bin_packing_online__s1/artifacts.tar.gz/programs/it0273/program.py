import numpy as np


# Adaptive online bin packing.
# Uses a set of scoring experts and mixes them by their recent observed efficiency.
# State is small and updated every call.

class _State:
    def __init__(self):
        # weights for experts; updated multiplicatively by realized "waste efficiency"
        self.w = np.ones(4, dtype=np.float64)
        self.eta = 0.02
        self.last_scores = None
        self.last_item = None
        self.last_bins_snapshot = None
        # running statistics
        self.n = 0
        self.sum_item = 0.0
        self.sum_bins_used_est = 0.0

_state = _State()


def _expert_scores(item, bins):
    """Return a (k, n) matrix of expert scores."""
    n = bins.shape[0]
    rem = bins.astype(np.float64)

    # Expert 0: best fit (tightest remaining after placement)
    e0 = -(rem - item)

    # Expert 1: worst fit (leave most room)
    e1 = rem

    # Expert 2: fit-preference with strong bonus for near-exact fits,
    # and penalty for leaving a tiny unusable residual.
    residual = rem - item  # >= 0 for bins shown
    # bonus sharp near 0, decay as residual grows
    exact_bonus = np.exp(-residual / 3.0)
    # penalty for leaving residuals that are too small to hold typical items
    # items mean ~40, so residuals in [1,10] are somewhat wasteful but can combine
    small_pen = 1.0 / (1.0 + np.exp((residual - 8.0) / 2.0))
    e2 = -residual + 6.0 * exact_bonus - 2.0 * small_pen

    # Expert 3: favor bins whose remaining capacity is closest to item+typical item,
    # i.e., keep large empty bins for future use by slightly penalizing them.
    # Prefer not to use completely empty bins unless needed.
    empty_pen = (rem >= 99.0).astype(np.float64) * 0.5
    e3 = -np.abs(residual - 40.0) - empty_pen

    return np.vstack([e0, e1, e2, e3])


def priority(item, bins):
    global _state
    bins = np.asarray(bins)

    # Update expert weights based on the previous decision's outcome, if possible.
    # We measure efficiency of the previous placement: how much residual space
    # remained in the chosen bin vs. ideal. This is a lightweight bandit signal.
    if _state.last_scores is not None and _state.last_bins_snapshot is not None:
        prev_bins = _state.last_bins_snapshot
        chosen = _state.last_choice
        if chosen < prev_bins.shape[0]:
            # residual in chosen bin after placing previous item
            res = prev_bins[chosen] - _state.last_item
            # reward: tight fits are good, but not creating near-zero waste that blocks
            # small items; use a smooth reward in [0,1]
            if res < 0:
                res = 0.0
            # ideal residual depends on typical item ~40; but tight pack is usually best
            reward = np.exp(-res / 20.0)
            # Update each expert by how close its ranking agreed with good outcome:
            # multiplicative update using score assigned to chosen bin.
            sc = _state.last_scores  # shape (k, n_prev)
            if sc.shape[1] > chosen:
                vals = sc[:, chosen]
                # normalize to avoid blowup
                vals = vals - vals.max()
                w_update = np.exp(_state.eta * (reward - 0.5) * np.tanh(vals))
                _state.w *= w_update
                # renormalize
                _state.w /= _state.w.sum()
                # keep bounded
                _state.w = np.clip(_state.w, 0.05, 20.0)
                _state.w /= _state.w.sum()

    scores = _expert_scores(item, bins)
    # weighted mixture
    w = _state.w.reshape(-1, 1)
    mixed = (scores * w).sum(axis=0)

    # Save state for next call
    _state.last_scores = scores
    _state.last_item = item
    _state.last_bins_snapshot = bins.copy()
    _state.last_choice = int(np.argmax(mixed))
    _state.n += 1
    _state.sum_item += item

    return mixed
