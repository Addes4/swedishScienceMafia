import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.perfect = 0
        self.small = 0


_state = _State()


def priority(item, bins):
    _state.calls += 1
    if item <= 20:
        _state.small += 1

    # Strict best-fit style ranking: strongly prefer tightest feasible fit.
    # A small bonus for lower-index (older) bins helps coalesce leftovers,
    # but never overrides a meaningfully tighter fit.
    slack = bins.astype(np.float64) - float(item)

    # Perfect fit gets overwhelming priority.
    score = -slack

    # Prefer leftover capacity that is still useful (>= item) but small:
    # this naturally emerges from -slack, so add a mild tie-breaking pressure
    # toward bins with capacities that are likely to be filled later.
    # Bins with slack exactly equal to common item sizes are slightly favored,
    # encouraging chains of exact fills without tuning to a specific instance.
    for s in (10, 20, 30, 40, 50, 60):
        score = np.where(slack == s, score + 0.01, score)

    # Deterministic tiny index preference to avoid fragmentation ties.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    score = score - idx * 1e-6

    return score
