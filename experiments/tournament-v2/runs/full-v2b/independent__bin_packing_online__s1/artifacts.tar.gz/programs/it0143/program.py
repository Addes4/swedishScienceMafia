import numpy as np


def priority(item, bins):
    # bins: remaining capacities of bins where item fits, including empty ones (cap 100)
    # Higher score -> chosen bin (first max on ties).
    #
    # Use best-fit: minimize remaining capacity after placement (bins - item).
    # Since we return higher = better, score = -(bins - item).
    #
    # Add a small tie-breaking term to prefer fuller bins (consolidation),
    # but keep it tiny so it doesn't override tightness.
    #
    # We also add a mild "waste" penalty: placing an item in a bin that leaves
    # a very small leftover is risky, but best-fit is provably good for this
    # distribution, so we stick close to it.
    #
    # Note: many bins may tie on remaining capacity; tie-break by preferring
    # the bin with the smallest remaining capacity BEFORE the item (i.e., the
    # fullest bin), computed simply.

    base = -(bins - item)  # best fit (higher for tighter fit)

    # Fullness before placement: fuller (smaller remaining) gets slight bonus.
    # Scale by a tiny factor so it only breaks ties among equal fit.
    # Use a fp-safe small epsilon relative to the integer range.
    fullness_bonus = (100.0 - bins) * 1e-6

    # Slight preference for the first bins (older) to consolidate leftovers;
    # index isn't directly available, but bins that are unused (==100) appear,
    # and we should strongly prefer using partially-filled bins over fresh ones
    # when fit is equal. That's already covered by best-fit since fresh bins
    # give larger remaining after placement.
    return base + fullness_bonus
