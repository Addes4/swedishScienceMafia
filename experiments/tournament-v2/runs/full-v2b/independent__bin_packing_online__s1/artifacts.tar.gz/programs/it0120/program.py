import numpy as np

def priority(item, bins):
    # Best-fit: prefer bin with smallest remaining capacity that still fits.
    # bins already only contains bins where item fits, so remaining capacity >= item.
    # Score = -(bins - item) means tighter fits get higher scores.
    # Add a tiny bias: among equally-tight fits, prefer lower-index bins (tie handled by harness).
    # Also slightly prefer bins that would be left with very small residual (waste reduction).
    residual = bins - item
    # Primary: tighter fit (smaller residual) is better -> higher score.
    # Secondary: avoid leaving bins with tiny but nonzero residual if it hurts future large items?
    # For online BFD-like, tightest fit is generally strongest. Use pure best fit with
    # a negligible tie-break favoring bins that become exactly zero or nearly zero.
    score = -residual.astype(np.float64)
    # Tiny bonus for leaving zero residual (perfect fill) and for very small residual.
    # This doesn't change ordering except among identical residuals, which are already tied.
    score += 1e-9 * (residual == 0)
    return score
