import numpy as np


def priority(item, bins):
    """Best fit with a small index bias toward older, nearly-fitting bins.

    item: integer size 1..100
    bins: numpy int64 array of remaining capacities (all bins where item fits)
    Return: array of scores; highest score wins, ties to first bin.
    """
    # Base best-fit score: more negative means tighter fit
    base = -(bins - item)

    # Small bonus for older bins (lower index) when the fit is already tight.
    # This encourages using existing bins instead of opening new ones.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    # Bonus decays with index, and only applies when remaining capacity is small.
    # "Small" relative to item means the bin is already fairly full.
    tightness = np.maximum(0.0, (item - (bins - item)).astype(np.float64))
    index_bonus = -1e-3 * idx * tightness

    return base.astype(np.float64) + index_bonus
