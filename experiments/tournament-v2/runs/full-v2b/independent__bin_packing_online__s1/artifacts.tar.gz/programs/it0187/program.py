import numpy as np

# Precompute a score table over possible (item, remaining capacity) pairs.
# Rows are item sizes 1..100, columns are bin remaining capacities 1..100.
# For a given item, larger score means better bin.
MAXC = 100
ITEM_MIN, ITEM_MAX = 1, 100

# Base: strongly prefer the tightest fit among non-empty bins.
# For a bin with remaining capacity r >= item, the leftover after placing is r - item.
# We want to minimize leftover, but also be slightly conservative about opening new bins.
# A fixed, smooth rule:
#   score = -leftover * 1000 - (r == 100) * penalty
# where penalty discourages using completely empty bins unless needed.
# The factor 1000 ensures fit quality dominates over the new-bin penalty.
# The penalty is modest: avoids using an empty bin when a reasonably tight fit exists.
PENALTY_NEW = 4000

SCORE = np.zeros((ITEM_MAX + 1, MAXC + 1), dtype=np.int64)
for item in range(ITEM_MIN, ITEM_MAX + 1):
    for r in range(item, MAXC + 1):
        leftover = r - item
        s = -leftover * 1000
        if r == MAXC:
            s -= PENALTY_NEW
        SCORE[item, r] = s


def priority(item, bins):
    """Score bins by tight-fit preference with a mild penalty for opening new bins."""
    item = int(item)
    # bins is a numpy int64 array of remaining capacities; all should be >= item by contract.
    # Clamp indices for safety.
    r = np.asarray(bins, dtype=np.int64)
    r_clamped = np.clip(r, 0, MAXC)
    # Only entries >= item are visible, but clamp item as well.
    it = item
    if it < ITEM_MIN:
        it = ITEM_MIN
    elif it > ITEM_MAX:
        it = ITEM_MAX
    return SCORE[it, r_clamped]
