import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.sum2 = 0.0

    def add(self, x):
        self.n += 1
        self.sum += x
        self.sum2 += x * x

    @property
    def mean(self):
        if self.n == 0:
            return 40.0
        return self.sum / self.n

    @property
    def std(self):
        if self.n < 2:
            return 25.0
        m = self.mean
        v = self.sum2 / self.n - m * m
        if v <= 1e-9:
            return 1.0
        return v ** 0.5


_stats = _Stats()


def priority(item, bins):
    """Best-fit with a small learned residual-gap penalty and stable tie-breaking."""
    _stats.add(item)

    # Base best-fit score: most negative remaining capacity after the item is placed.
    base = -(bins - item)

    # Small penalty for creating residuals that are known bad from the observed size stats.
    # A residual r is "bad" if it is too small to fit a typical item, but wastes space.
    # We use a smooth penalty centered near the observed lower range.
    m = _stats.mean
    s = _stats.std
    low = max(1.0, m - 0.5 * s)

    residual = bins - item
    # Penalize residuals in (0, low) that are likely to remain stranded.
    gap_pen = np.where(
        (residual > 0) & (residual < low),
        0.01 * (low - residual) / max(low, 1.0),
        0.0,
    )

    # Slight preference for earlier bins on exact ties, but very small so best-fit dominates.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    tie = -1e-7 * idx

    return base - gap_pen + tie
