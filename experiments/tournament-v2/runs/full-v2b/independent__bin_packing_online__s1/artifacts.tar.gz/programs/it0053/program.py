import numpy as np


def priority(item, bins):
    # Best fit: choose the bin where the item leaves the least wasted space.
    # Score = residual capacity after placing the item, maximized.
    # A tiny negative multiple of bin index breaks ties in favor of earlier bins
    # without materially affecting the fit decision.
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    residual = bins.astype(np.float64) - float(item)
    return residual - 1e-9 * idx
