import numpy as np


# The item sizes are drawn from a fixed Weibull-shaped distribution with mean about 40.
# For online bin packing, a good practical rule is:
# - put the item into the tightest possible existing bin when that bin becomes nearly full,
# - otherwise avoid filling bins too shallowly by preferring bins whose remaining capacity
#   lies in a favorable range for future items.
#
# We use a deterministic, distribution-aware priority rule.  Since only the relative order
# of scores matters and unused bins have capacity 100, we give unused bins a score that
# depends on the item size, so they are chosen only when no attractive partially-filled bin
# exists.

def priority(item, bins):
    # bins: int64 array of remaining capacities, all >= item.
    # Return scores where larger is better.

    # Exact or near-exact fits should be taken immediately.
    waste = bins - item

    # A bin with waste 0 is perfect.  Next-best are small positive wastes.
    # For larger remaining capacities, we prefer to keep bins in a "sweet spot":
    # not too empty (bad packing density) and not too full (poor future flexibility).
    #
    # Mean item size is about 40, so reserving around 40-60 free capacity is useful.
    # We map remaining capacity after placing the item (waste) to a priority that
    # combines: (a) favor low waste, (b) mildly favor mid-range residual capacity.
    #
    # The exact constants are chosen to be robust across the stated distribution.

    # Normalize waste; waste=0 should be overwhelmingly preferred.
    exact_bonus = (waste == 0) * 1000.0

    # Small wastes are strongly preferred.
    small_bonus = np.where((waste > 0) & (waste <= 5), 200.0 - 10.0 * waste, 0.0)

    # Among non-tight bins, favor leaving a moderate amount of free space.
    # This helps avoid creating bins with tiny unusable remnants.
    target = 45.0  # approximate favorable residual capacity
    mid_bonus = np.exp(-((waste - target) ** 2) / (2.0 * 20.0 ** 2))

    # Unused bins (remaining capacity exactly 100) should not be opened if a usable
    # partially-filled bin exists.  However, for large items we may need them.
    unused_penalty = np.where(bins == 100, -20.0, 0.0)

    # Very large remaining capacities are not useful unless the item is large.
    # Prefer smaller remaining capacity among otherwise similar bins.
    remaining_penalty = bins * 0.05

    scores = exact_bonus + small_bonus + mid_bonus + unused_penalty - remaining_penalty

    # Ensure no NaN and return as float array.
    return scores.astype(np.float64)
