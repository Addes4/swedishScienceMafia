import numpy as np

# State kept across calls (allowed by the problem).
_state = {
    "n": 0,
    "sum": 0.0,
    "big": 0,      # count of items > 50
}


def priority(item, bins):
    """Adaptive best-fit bin choice.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (bins the item fits in),
          in fixed bin order, including empty bins (capacity 100).

    Returns an array of scores; the item goes to the highest (first on ties).
    """
    # ---- update running statistics (never sees the future) ----
    st = _state
    st["n"] += 1
    st["sum"] += item
    if item > 50:
        st["big"] += 1

    b = bins.astype(np.float64)
    residual = b - item  # remaining capacity after placing the item here

    # Primary: best fit (prefer smallest resulting residual).
    score = -residual

    # Bonus for exactly filling a bin: keep such a perfect fit attractive.
    score += 2.0 * (residual <= 0)

    # Mild preference to avoid stranding a bin with a residual that is
    # too small for a "typical" medium item but not full either.
    # Estimate typical item size from the running mean.
    mean_item = st["sum"] / st["n"] if st["n"] else 40.0
    typical = mean_item
    # small residual (but > 0) that can't host a typical item is slightly bad
    stranded = (residual > 0) & (residual < typical) & (b < 100)
    score -= 0.5 * stranded

    # Slight preference for using an already-nonempty bin over a fresh empty
    # one only when the fit is comparably tight is already covered by best fit.
    # Nudge empty bins up a touch when the item is large so big items consume
    # fresh space cleanly rather than fragmenting a nearly-full bin.
    if item >= 60:
        score += 0.25 * (b >= 100)

    return score
