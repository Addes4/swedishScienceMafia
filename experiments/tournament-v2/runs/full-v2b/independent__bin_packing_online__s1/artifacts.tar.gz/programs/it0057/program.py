"""Online bin packing heuristic.

Strategy: best-fit with a light preference against opening brand-new bins.
Placing an item into the bin with the smallest remaining capacity (best fit)
tends to pack tightly.  We add a small penalty to empty bins (remaining == 100)
so that the algorithm consumes partially filled bins first and only opens a
new bin when necessary.  Because unused bins are always present (many of them),
we cannot simply exclude them; instead we nudge their score downward.
"""

import numpy as np

# Penalty applied to totally empty bins so they are chosen last.
_EMPTY_PENALTY = 1.0


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    # Best fit: tighter fit (smaller remaining capacity) => higher score.
    score = -(bins - item).astype(np.float64)

    # Discourage opening a fresh bin while partially filled ones are available.
    # Empty bins have remaining capacity exactly 100.
    score[bins == 100] -= _EMPTY_PENALTY

    return score
