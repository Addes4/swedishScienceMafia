"""Online bin packing with a tuned best-fit plus fragmentation-aware scoring."""
import numpy as np


# Running statistics across calls (never sees future items).
_state = {
    "count": 0,
    "sum": 0,
    "sum_sq": 0,
}


def priority(item, bins):
    """Score bins so the item goes to the best-fitting bin.

    item: integer size 1..100.
    bins: numpy int64 array of remaining capacities (item fits in all of them).
    """
    # Update running mean/variance estimate of item sizes.
    c = _state["count"]
    s = _state["sum"]
    ss = _state["sum_sq"]
    c += 1
    s += item
    ss += item * item
    _state["count"] = c
    _state["sum"] = s
    _state["sum_sq"] = ss

    mean = s / c
    var = max(ss / c - mean * mean, 0.0)
    std = var ** 0.5

    # Remaining capacity after placing the item.
    rem = bins - item

    # Base: prefer tightest fit (smallest remainder).
    # Exact fit gets a big bonus to eliminate perfect matches.
    score = -rem.astype(np.float64)

    # Small bonus for bins that become full.
    score += np.where(rem == 0, 5.0, 0.0)

    # Prefer remainders that are unlikely to be useful for future items.
    # A remainder below the typical item size is wasteful, so reward it modestly.
    # Use a smooth threshold around the running mean.
    small = np.maximum(mean - rem, 0.0)
    score += 0.15 * small

    # Slightly penalize leaving a remainder that nearly matches a whole item
    # (could cause fragmentation), but keep this weak.
    near_full_bin = np.maximum(rem - 100.0, 0.0)
    score -= 0.02 * near_full_bin

    # Avoid always dumping into the first empty bin when many empties exist.
    # Adding a tiny index-based jitter breaks ties in favor of later bins
    # only in near-tie situations, which helps spread usage without hurting
    # the primary best-fit decision.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    score -= idx * 1e-9

    return score
