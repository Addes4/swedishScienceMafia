import numpy as np


def priority(item, bins):
    """Rank bins for an arriving item.

    Strategy: best-fit style, with a preference for exact fits and for
    leftovers that are either zero or large enough to remain useful.
    Tiny leftovers just below common item sizes are penalized.
    """
    rem = bins.astype(np.int64)
    after = rem - item

    score = np.empty(rem.shape, dtype=np.float64)

    # Base: prefer tightest fit (smallest remaining capacity that fits).
    score[:] = -rem

    # Strongly prefer exact fits.
    exact = after == 0
    score[exact] += 1_000_000.0

    # Penalize creating small unusable leftovers (e.g. 1..5), which
    # fragment capacity without being able to hold typical items.
    small = (after > 0) & (after <= 5)
    score[small] -= 1000.0

    # Mildly favor larger leftovers, to keep a spread of usable bins.
    score += 0.01 * after

    # Tiny tie-breaker toward earlier bins.
    score -= 1e-7 * np.arange(rem.shape[0], dtype=np.float64)

    return score
