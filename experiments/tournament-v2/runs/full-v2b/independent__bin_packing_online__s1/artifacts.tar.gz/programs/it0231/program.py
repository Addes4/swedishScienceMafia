import numpy as np


def priority(item, bins):
    # Best-fit: prefer the smallest remaining capacity that still fits the item.
    # score = -(bins - item) means smaller leftover => higher score.
    scores = -(bins - item).astype(np.float64)

    # Slight preference for opening a fresh bin (capacity exactly 100)
    # over filling a bin so full it would leave a tiny unusable remainder.
    # This reduces fragmentation with Weibull-shaped item sizes.
    fresh = (bins == 100)
    leftover = bins - item

    # Penalize leaving leftovers too small to hold many future item sizes.
    # Sizes are roughly in [1,100]; leftovers < ~20 are often wasted space.
    waste_penalty = np.zeros_like(scores)
    small = (leftover >= 0) & (leftover < 20)
    waste_penalty[small] = -0.05 * (20 - leftover[small])

    # Reward fresh bins modestly so we don't always cram partial bins.
    fresh_bonus = np.zeros_like(scores)
    fresh_bonus[fresh] = 0.35

    return scores + waste_penalty + fresh_bonus
