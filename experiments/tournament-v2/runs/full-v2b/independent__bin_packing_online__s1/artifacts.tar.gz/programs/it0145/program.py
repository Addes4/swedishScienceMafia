import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin that leaves the least remaining capacity after placement.
    # Equivalent to minimizing (bins - item), i.e. maximizing -(bins - item).
    # Tie-break slightly in favor of fuller bins by using the bin remaining capacity itself.
    return -(bins - item) - 1e-9 * bins
