import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.mean = 40.0
        # histogram of residual capacities we've created
        # track typical item sizes
        self.sizes = []

    def update(self, item):
        self.count += 1
        # exponential moving average of item sizes
        alpha = 0.02
        self.mean = (1 - alpha) * self.mean + alpha * item


_state = _State()


def _residual_value(cap):
    """Value of a residual capacity `cap` (after placing). Higher is better to leave.
    We want residuals that can still fit a typical item or pack well."""
    if cap == 0:
        # perfectly full - great (nothing wasted)
        return 4.0
    if cap < 1:
        return 0.0
    # a residual is useful if it can hold a typical item
    m = _state.mean
    v = 0.0
    if cap >= m:
        v = 3.0
    # prefer residuals that are near multiples of typical item size or small enough
    # penalize tiny unusable gaps (cap > 0 but < some min likely item size)
    return v


def priority(item, bins):
    _state.update(item)
    m = _state.mean

    # Best fit: smaller residual (closer to 0) better.
    residual = bins - item  # remaining capacity after placing

    # Base score: negative residual -> tightest fit highest
    scores = -residual.astype(np.float64)

    # Bonus for exactly filling a bin
    scores += np.where(residual == 0, 50.0, 0.0)

    # Penalize leaving small unusable-ish gaps (residual between 1 and ~ half mean)
    # such gaps waste space; prefer to make bin fuller next time.
    small_gap = (residual > 0) & (residual < max(2.0, m * 0.5))
    scores -= np.where(small_gap, 15.0, 0.0)

    # Slight preference to leave residuals that can fit another typical item
    good_res = (residual >= m)
    scores += np.where(good_res, 3.0, 0.0)

    # Prefer opening/using bins that are already more full (smaller residual)
    # already handled by -residual.

    # Secondary tie-break: prefer lower remaining capacity generally (tightest)
    scores += -0.001 * residual

    return scores
