"""Online bin packing: adaptive size-aware best fit.

The policy mainly chooses the bin that minimizes leftover space, but it also learns
which leftover gaps tend to be hard to reuse for future items and mildly prefers
bins that avoid creating such gaps.  This is done with no future information.
"""

import numpy as np

# Empirically useful target gaps: sizes that often cannot be filled well later.
# The rule is still dominated by best-fit; these only break close alternatives.
_GOOD_GAPS = {0: 3.0, 1: 1.4, 2: 0.7, 3: 0.25, 4: 0.08, 5: 0.02}
_ITEM_HIST = np.zeros(101, dtype=np.float64)
_ITEM_COUNT = 0.0


def _item_prob(size):
    """Smoothed empirical probability of an item of the given integer size."""
    total = _ITEM_COUNT + 101.0
    return (_ITEM_HIST[size] + 1.0) / total


def _expected_fill_goodness(gap):
    """Score how reusable a remaining gap of this size is for future items.

    Smaller gaps that are exactly consumable by common item sizes are better.
    Larger gaps are generally better than medium awkward gaps.
    """
    if gap <= 0:
        return 100.0
    # Probability that a future item will exactly need at most this gap.
    # Prefer gaps that are likely to be closed soon by a single item.
    p_close = 0.0
    for s in range(1, min(gap, 100) + 1):
        p_close += _item_prob(s)
    # Prefer very small rather than medium gaps; large gaps are flexible.
    return 10.0 / (1.0 + gap) + 0.35 * p_close + 0.0015 * gap * gap


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest score."""
    global _ITEM_COUNT

    # Update a smoothed histogram of arriving item sizes.
    if 1 <= item <= 100:
        _ITEM_HIST[item] += 1.0
        _ITEM_COUNT += 1.0

    bins = np.asarray(bins, dtype=np.int64)
    leftover = bins - item

    # Primary term: prefer the smallest leftover (best fit).
    # Secondary term: avoid leftovers that are awkward for future items.
    # The scale is chosen so best-fit still dominates for meaningful differences.
    score = -leftover.astype(np.float64)

    # Small adjustment based on gap quality, bounded so it does not override large
    # differences in leftover capacity.
    n = len(bins)
    for i in range(n):
        lf = int(leftover[i])
        if lf < 0:
            # Should not be present because bins is prefiltered, but keep safe.
            score[i] = -1e18
        else:
            # Bonus for gaps that are easy to reuse or avoid locking up odd sizes.
            # The coefficient is deliberately modest.
            score[i] += 0.035 * _expected_fill_goodness(lf) - 0.001 * (lf % 7)

    return score
