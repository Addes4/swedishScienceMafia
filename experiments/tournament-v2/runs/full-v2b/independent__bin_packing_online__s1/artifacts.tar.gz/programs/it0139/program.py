"""Greedy online bin packing: convex best-fit residual scoring."""
import numpy as np


def priority(item, bins):
    """Rank bins by a convex function of residual capacity after placing `item`.

    We want to place the item so that the resulting residual is small
    (tight fit), but with a slight preference for bins that are already
    fuller is captured naturally because residual after placement is
    bins - item.  A convex decreasing-in-residual score punishes leaving
    large gaps more than small ones, encouraging well-filled bins.
    """
    residual = bins - item  # remaining capacity if item placed here
    # Convex score: smaller residual => much higher score.
    # Use a quadratic force toward tight fits while keeping a linear
    # term so that among equal residuals the first bin is chosen.
    return -(residual.astype(np.float64) ** 2) - 0.01 * residual
