import numpy as np

# State kept across calls
_state = {
    "count": 0,
    "total": 0.0,
}


def priority(item, bins):
    """Best-fit rule: choose the bin with the least remaining capacity that still fits.

    Score = -(remaining_capacity - item) = item - remaining_capacity.
    The highest score (closest remaining capacity to item, i.e. tightest fit) wins.
    Ties go to the earliest bin, which preserves low bin indices for full bins
    and tends to reuse existing bins before opening new ones.

    A tiny bonus is added to bins that are near the top of the size range so that
    large items preferentially fill / close off almost-full bins, which reduces
    fragmenting of large bins for large items.
    """
    # Pure best-fit: maximize (item - remaining). Equivalent to minimizing remaining.
    # Add a minuscule secondary term to prefer slightly fuller bins (lower remaining)
    # deterministically without breaking best-fit ordering.
    rem = bins.astype(np.int64)
    # Primary: tighter fit wins -> score = item - rem
    # Secondary tie-breaker already handled by array order (first wins),
    # so best-fit order is exactly (item - rem).
    score = (item - rem).astype(np.float64)
    return score
