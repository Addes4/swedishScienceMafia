import numpy as np

# Global state: small adaptive statistics. These are safe because the problem
# allows keeping state between calls but never exposes future items.
_sum_items = 0.0
_count_items = 0.0


def priority(item, bins):
    """Best-fit packing with an adaptive tie-breaker.

    The item is placed in a bin that leaves as little remaining capacity as
    possible.  Among bins with identical leftover capacity, we prefer bins
    whose resulting remainder is less likely to be useful for future items,
    estimated from the running mean of observed item sizes.
    """
    global _sum_items, _count_items

    # Maintain a smoothed mean item size.  The mean of the distribution is
    # around 40, so this starts useful and adapts to the instance.
    _sum_items += float(item)
    _count_items += 1.0
    mean_item = _sum_items / _count_items

    # Core score: minimize remaining capacity after placement.
    remaining = bins - item
    primary = -remaining.astype(np.float64)

    # Secondary score: slightly prefer bins whose leftover capacity is far from
    # common future item sizes.  A leftover that is too small to matter or too
    # large to be tightly filled is slightly better than one exactly matching a
    # typical future item.
    # This is intentionally weak so it only breaks near-ties.
    # Distance from the running mean, normalized by capacity.
    dist = np.abs(remaining.astype(np.float64) - mean_item) / 100.0

    # Also slightly reward using entirely full bins (remaining == 0), and
    # penalize tiny remainders only a little (they are usually fine).
    full_bonus = (remaining == 0).astype(np.float64) * 1e-6

    return primary + 0.01 * dist + full_bonus
