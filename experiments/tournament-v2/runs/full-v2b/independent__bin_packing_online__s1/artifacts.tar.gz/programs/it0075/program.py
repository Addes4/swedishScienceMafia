"""Best fit with consolidation bias and light distribution tracking.

The item goes to the bin with the highest score; ties go to the first such bin.
Primary term: prefer tightly fitting bins (best fit), i.e. small residual.
Secondary term: mildly prefer lower-index (earlier/used) bins to consolidate,
reducing the number of bins opened and improving packing efficiency.
"""

import numpy as np

# State kept between calls.
_ema = 40.0          # exponential moving average of item sizes
_count = 0


def priority(item, bins):
    global _ema, _count

    # Update running estimate of the item size distribution (for mild modulation).
    _count += 1
    alpha = 0.02
    _ema = (1.0 - alpha) * _ema + alpha * item

    bins = np.asarray(bins, dtype=np.float64)
    n = bins.shape[0]
    if n == 0:
        return bins

    # Residual capacity left after placing the item.
    residual = bins - item  # >= 0 since bins only contain fitting bins (capacity >= item)

    # Bin index; unused bins have residual 100 - item (large), so they rank worse,
    # naturally favoring already-used bins that still fit.
    idx = np.arange(n, dtype=np.float64)

    # Core: best fit -> smaller residual is better.
    core = -residual

    # Mild consolidation bias: favor lower indices (earlier bins). This opens fewer
    # bins and tends to pack better over the sequence. Scale kept small so true
    # best-fit choice dominates when residuals differ meaningfully.
    # Normalize index contribution so it never overrides a real residual gap.
    bias = -idx * 1e-3

    # Slight preference to leave larger free space for future items when residuals
    # are close: penalize leaving a tiny unusable sliver lightly via a smooth term.
    # (Encourage "good" residuals that leave a useful remainder.)
    # This term is very small and only breaks near-ties.
    frac = residual / 100.0
    sliver_penalty = -0.02 * (1.0 / (1.0 + np.exp((frac - 0.05) * 60.0)))
    # i.e. strongly penalize residual near 0 (a wasted sliver), smoothly vanishing
    # for larger residuals. Magnitude < 0.02 so it only breaks near-ties.

    score = core + bias + sliver_penalty
    return score
