# EVOLVE-BLOCK-START
"""Best fit with a gentle preference for tighter fits and slight avoidance of new bins."""
import numpy as np

_state = {"last_item": 0, "count": 0}

def priority(item, bins):
    # Best fit score: negative leftover space after placing item.
    # Nearly-full bins (small leftover) get highest scores.
    score = -(bins - item).astype(np.float64)

    # If a bin is exactly full after placement, strongly prefer it.
    exact = (bins == item)
    score[exact] += 1e6

    # Unused bins have remaining capacity 100; slightly penalize them so we
    # consume partially filled bins before opening a fresh one, but keep the
    # penalty small enough that best fit still dominates.
    unused = (bins == 100)
    score[unused] -= 0.25

    _state["last_item"] = item
    _state["count"] += 1
    return score
# EVOLVE-BLOCK-END
