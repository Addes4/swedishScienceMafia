import numpy as np

# Persistent state for online adaptation.
_state = {
    "n": 0,
    "mean": 40.0,
    "alpha": 0.01,  # EWMA smoothing for item-size mean estimate
}


def priority(item, bins):
    """Score bins for online bin packing.

    Strategy: best-fit with a mild penalty for leaving very small unusable gaps.
    Also maintains a running estimate of the typical item size to decide when a gap is "too small"
    to be useful for future items. High score = preferred bin.
    """
    s = _state
    s["n"] += 1
    # Update EWMA of item size (mean ~40 distribution).
    s["mean"] = (1.0 - s["alpha"]) * s["mean"] + s["alpha"] * float(item)
    typical = s["mean"]

    # Remaining capacity for each candidate bin.
    rem = bins.astype(np.float64)
    after = rem - float(item)

    # Best-fit base score: smaller leftover is better.
    score = -after

    # Penalize creating tiny leftovers unlikely to be usable by future items.
    # If leftover is positive but much smaller than the typical item, the residual may be wasted.
    # Use a soft threshold around 0.5 * typical, tapering to 0 penalty for large gaps.
    small = np.maximum(0.0, 0.5 * typical - after)
    # Only penalize strictly positive leftovers that are small; exact fits (after==0) are ideal.
    penalty = np.where(after > 0.0, small, 0.0)
    score -= 0.05 * penalty

    return score
