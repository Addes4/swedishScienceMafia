import numpy as np


def priority(item, bins):
    # Best fit: prefer the feasible bin where the remaining capacity is closest to the item.
    # bins contains only bins where remaining >= item, so bins - item >= 0.
    leftover = bins - item

    # Main score: smaller leftover is better.
    score = -leftover.astype(np.float64)

    # Small preference for non-empty bins to reduce unnecessary opening of new bins.
    # Unused bins have remaining capacity exactly 100, so penalize them very slightly.
    # This rarely changes the best-fit choice but helps in exact-fit / near-fit ties.
    score -= 1e-6 * (bins == 100)

    return score
