"""Online bin packing heuristic.

Strategy:
- Mostly use best-fit (tightest remaining capacity).
- Keep a lightweight online histogram of observed item sizes.
- Slightly prefer bins where the leftover capacity after placing the item is a
  common future item size, which tends to preserve useful bins and reduce waste.
"""

import numpy as np

# Online histogram over item sizes 1..100.
_size_count = np.zeros(101, dtype=np.float64)
_total = 0.0
_prob = np.zeros(101, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    global _total

    # Update empirical distribution over observed item sizes.
    if 1 <= item <= 100:
        _size_count[item] += 1.0
        _total += 1.0
        if _total > 0:
            _prob[:] = _size_count / _total

    # bins are the remaining capacities after guaranteeing `item` fits.
    residual = np.asarray(bins, dtype=np.int64) - item

    # Base: best fit. Prefer smaller residual capacity.
    score = -residual.astype(np.float64)

    # Secondary: penalize residuals that have very low probability of being
    # useful for a future item. This slightly favors placing items so that the
    # leftover space remains packable.
    if _total >= 20.0:
        # Probability mass of future items that fit into this residual.
        useful = np.zeros(residual.shape, dtype=np.float64)
        for r in range(0, 101):
            if r > 0:
                useful[residual == r] = _prob[1:r + 1].sum() if r >= 1 else 0.0
            elif r == 0:
                useful[residual == 0] = 1.0  # perfectly filled is excellent

        # Small weight relative to primary best-fit score.
        score += 0.25 * useful

    return score
