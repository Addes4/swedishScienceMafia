# EVOLVE-BLOCK-START
"""Adaptive best fit with residual-value bias based on observed sizes."""
import numpy as np


class _State:
    def __init__(self):
        # Histogram of observed item sizes 1..100
        self.counts = np.zeros(101, dtype=np.float64)
        self.total = 0.0
        self.calls = 0

    def observe(self, item):
        self.counts[item] += 1.0
        self.total += 1.0
        self.calls += 1

    def prob(self, size):
        # Probability that an item of exactly `size` arrives (smoothed)
        if self.total <= 0:
            return 1.0 / 100.0
        return (self.counts[size] + 1.0) / (self.total + 100.0)

    def prob_fit(self, cap):
        # Estimated probability a future item fits in remaining capacity `cap`
        if cap <= 0:
            return 0.0
        if cap >= 100:
            return 1.0
        # Sum probabilities for sizes <= cap
        s = 0.0
        for sz in range(1, int(cap) + 1):
            s += self.counts[sz] if sz <= 100 else 0.0
        denom = self.total + 100.0
        # Add smoothing mass
        s += min(cap, 100) * 1.0
        return s / denom


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _state

    # Observe the item (online learning)
    _state.observe(item)

    # bins is numpy int64 array of remaining capacities; all >= item
    n = len(bins)
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    b = bins.astype(np.float64)
    residual = b - float(item)

    # Base: prefer tight fits (best fit)
    base = -residual

    # Adaptive residual penalty: prefer residuals that are small OR large-but-useful.
    # Use estimated probability that residual capacity is useful (>= some future item).
    # We compute value of a residual as expected number of future items fitting, but
    # simpler: penalize residuals that are unlikely either to be filled well or reused.
    probs = np.array([_state.prob_fit(r) for r in residual], dtype=np.float64)

    # A good residual is one that is either very small (wasted but little) or has
    # high chance of being useful later. We balance tightness and future usefulness.
    # Normalize base to be comparable.
    # tightness score: higher for smaller residual
    max_res = max(100.0, float(item))
    tight = 1.0 - (residual / max_res)

    # usefulness score: probability it will fit a future item, but we don't want
    # to hoard large bins (unused bins have residual 100). To avoid fragmentation,
    # slightly prefer bins with smaller residual among similar usefulness.
    # Combine: priority = tight + alpha * usefulness, with alpha adaptive.
    alpha = 0.35

    # Additional anti-fragmentation: if residuals are equal up to 0, prefer earlier
    # (tie-break happens naturally by first index, so no change needed).

    # But for small residuals (< 15), usefulness is low anyway, so tight dominates.
    score = tight + alpha * probs

    # If many bins have identical score (e.g., unused bins with same residual),
    # prefer the one with smaller index automatically by argmax tie-breaking.

    # Ensure no NaN
    score = np.nan_to_num(score, nan=-1e9, posinf=1e9, neginf=-1e9)

    return score
# EVOLVE-BLOCK-END
