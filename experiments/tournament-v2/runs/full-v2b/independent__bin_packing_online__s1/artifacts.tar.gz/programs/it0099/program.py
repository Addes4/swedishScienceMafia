import numpy as np


def priority(item, bins):
    # Base rule: best fit = smallest leftover capacity after placing item.
    # bonus for partially used bins (capacity < 100) to discourage opening new bins.
    leftover = bins - item
    # Prefer tightest fit (min leftover). Add tiny bonus for used bins.
    used_bonus = (bins < 100).astype(np.float64) * 1e-6
    return -leftover + used_bonus
