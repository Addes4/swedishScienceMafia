"""Adaptive best-fit online bin packing."""
import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.sum_item = 0.0
        self.sum_sq = 0.0
        self.max_item = 0
        # Histogram of item sizes seen so far, used to estimate future demand.
        self.hist = np.zeros(101, dtype=np.int64)

    def observe(self, item):
        x = int(item)
        self.count += 1
        self.sum_item += x
        self.sum_sq += x * x
        if x > self.max_item:
            self.max_item = x
        self.hist[x] += 1


_state = _State()
_known_waste = {}


def _expected_future_leftover_proxy(item, remaining):
    """A cheap heuristic value of leaving `remaining` space after a bin is sealed."""
    # Best-fit wants small residual. But very tiny residual bins are unusable;
    # moderately small residuals are still often usable for small future items.
    r = int(remaining)
    if r == 0:
        return 0.0
    # Prefer residuals that are either very small (fully packed) or exactly
    # compatible with common smaller item sizes.
    # Small residual is generally good; penalize wasted capacity mildly.
    return -float(r)


def priority(item, bins):
    global _state
    _state.observe(item)

    bins = np.asarray(bins, dtype=np.int64)
    n = bins.size
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    leftover = bins - int(item)

    # Base rule: best fit (smallest leftover wins).
    # We make it slightly nonlinear so that among close residuals, more useful
    # gap sizes are favored over awkward ones.
    scores = np.empty(n, dtype=np.float64)

    # Common item sizes from observed history. If few samples, just use best fit.
    total = max(_state.count, 1)
    # Small-item prevalence matters: gaps that can take 1..30 are valuable.
    small_mass = float(_state.hist[1:41].sum()) / total
    mid_mass = float(_state.hist[41:71].sum()) / total
    large_mass = float(_state.hist[71:101].sum()) / total

    # If most items are small/medium, slight preference for bins with residual
    # capacity in a usable range, while still packing tightly.
    # For a residual r, its "utility" roughly increases if r can hold common
    # future item sizes.  We approximate this by a smooth concave reward.
    for i in range(n):
        r = int(leftover[i])
        if r < 0:
            scores[i] = -1e9
            continue

        # Primary: minimize leftover.
        base = -r

        if total >= 20:
            # Reward residuals that are likely to be filled by future items.
            # A bin with leftover r can potentially host an item of size up to r.
            # Given observed distribution, estimate probability that r helps.
            # Smooth approximation using CDF at r.
            if r == 0:
                util = 0.0
            else:
                # Empirical probability that a future item is <= r.
                util = float(_state.hist[1:r + 1].sum()) / total
            # Tiny residual is almost as good as exact; moderate residual is
            # still useful if small items are common.
            bonus = (small_mass * util + 0.25 * mid_mass * util)
            # Scale bonus small relative to leftover so best-fit remains dominant.
            scores[i] = base + 6.0 * bonus
        else:
            scores[i] = base

    # Prefer later bins on exact ties? No: harness ties go to first bin, which
    # naturally keeps early bins packed and helps reuse. Best-fit already does
    # this. Add a tiny decreasing bias by bin index for stability.
    scores -= np.arange(n, dtype=np.float64) * 1e-9

    return scores
