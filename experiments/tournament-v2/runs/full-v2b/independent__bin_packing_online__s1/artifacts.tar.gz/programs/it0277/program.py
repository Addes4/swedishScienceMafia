import numpy as np

# Online bin packing heuristic.  The basic idea is best fit, but we add a
# small dynamic adjustment based on the observed mean item size.  This helps
# because the distribution is Weibull-shaped with mean around 40, so items are
# often large and perfect/exact fits matter.
#
# The function is called 5000 times per instance.  We keep only two running
# statistics: number of items seen and total size seen (as ints).  The state is
# global but the harness creates a fresh process for each instance in practice;
# even if not, the running mean becomes accurate quickly.

_items = 0
_total = 0

def priority(item, bins):
    global _items, _total

    _items += 1
    _total += item

    # Estimate mean item size (start from 40 to avoid a poor early estimate).
    mean = _total / _items if _items > 0 else 40.0

    # Base score: best fit.  bins is int64 remaining capacity.
    rem = bins.astype(np.float64)

    # For an item of size s and remaining capacity r, the leftover after
    # placing is r - s.  Best fit maximizes -(r - s).
    score = -(rem - item)

    # A perfect fit should be strongly preferred for all but very small items.
    # This is especially valuable when items are large relative to capacity.
    # Use a smooth bonus that grows with item size.
    # For item == remaining capacity, leftover == 0.
    perfect = (rem == item)
    score[perfect] += 1000.0 + 10.0 * item

    # When item is large, avoid wasting capacity that could have made a future
    # exact fit.  A bin whose remaining capacity is just above item but too small
    # to be useful for another typical item is slightly penalized.  The threshold
    # is based on the estimated mean.
    if item >= 50:
        # Prefer bins that end up with very small leftover (< 0.3 * mean) or
        # very large leftover (>= mean), depending on item.
        leftover = rem - item
        # Bonus for ending with small leftover (tight packing).
        score += np.where(leftover < max(1.0, 0.25 * mean), 5.0, 0.0)
        # Small penalty for leftover that is awkward: just below mean but not tiny.
        awkward = (leftover > 0) & (leftover < 0.5 * mean)
        score -= np.where(awkward, 1.5, 0.0)
    else:
        # For small items, avoid using a mostly full bin if a nearly empty bin is
        # available?  Best fit already handles this, but we add a tiny bias to
        # keep some empty space for medium/large future items.
        # Strongly prefer bins with large remaining capacity for small items is
        # bad (would waste bins).  Instead, prefer bins with moderate remaining
        # capacity so that small items fill gaps.
        # Tiny penalty for using a bin that is almost empty (leftover > 75).
        score -= np.where((rem > 75) & (item < 20), 0.5, 0.0)

    return score
