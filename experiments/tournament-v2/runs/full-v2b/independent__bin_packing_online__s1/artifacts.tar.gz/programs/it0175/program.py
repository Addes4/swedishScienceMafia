import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`.

    The item goes to the bin with the highest score; ties go to the first bin.

    Strategy: mostly best fit, but with a small bonus for bins that are already
    somewhat full so that empty bins are preserved as long as possible.  This
    helps reduce fragmentation in online bin packing.
    """
    # Primary: prefer tightest fit (smallest remaining capacity >= item).
    # In bins, remaining capacities are >= item.  -(bins) gives higher score
    # to smaller remaining capacity, i.e. tightest fit.
    score = -bins.astype(np.float64)

    # Secondary: small preference for bins that are already somewhat used.
    # This discourages spreading items over many nearly-empty bins.
    used = 100.0 - bins.astype(np.float64)
    score += 0.05 * used

    # Tiny tie-breaker: for this item, slightly prefer bins whose remaining
    # capacity matches a complementary size, a cheap online residue heuristic.
    # If the item and remaining capacity sum near 100, the bin can be filled well.
    complement = (bins.astype(np.float64) + item) - 100.0
    score -= 0.002 * np.abs(complement)

    return score
