import numpy as np


class _State:
    def __init__(self):
        # Precomputed thresholds for a Weibull-like distribution with mean ~40.
        # These breakpoints approximate the item-size distribution's CDF and
        # are used to make the scoring robust to the exact scale.
        self.q = np.array(
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 16, 18, 20, 22, 24,
             26, 28, 30, 33, 36, 39, 42, 45, 48, 51, 54, 57, 60, 63, 66,
             69, 72, 75, 78, 81, 84, 87, 90, 93, 96, 100],
            dtype=np.int64,
        )
        # Weights encourage using bins whose residual capacity is just above
        # an item size breakpoint, i.e. a soft best-fit / harmonic packing.
        self.w = 1.0 / (self.q.astype(np.float64) + 1.0)


_state = _State()


def priority(item, bins):
    """Rank bins by a distribution-aware soft best-fit score."""
    b = bins.astype(np.float64, copy=False)

    # Main term: tighter fit gets higher score, with sublinear penalty.
    base = -(b - float(item)) / (b + 1.0)

    # Bonus for residual capacities that cross useful size-class thresholds.
    # This helps pack items of similar sizes together without exact matching.
    q = _state.q
    w = _state.w

    # For each bin, find the smallest threshold >= item whose residual capacity
    # is at least that threshold.  Vectorized and cheap.
    residual = b
    # closeness of residual capacity to a threshold, weighted.
    # (threshold - item) positive -> room for another small/medium item later.
    diff = residual[:, None] - q[None, :]
    # reward being just at/above a threshold, penalize wasting large bins.
    near = np.exp(-np.abs(diff) / (q[None, :] + 1.0))
    bonus = (near * w[None, :]).sum(axis=1)

    # Slight preference for exactly filling (residual == item).
    exact = (residual == float(item)).astype(np.float64)

    # Prefer not to open/use completely empty bins unless item is large.
    empty_pen = 0.0
    if item < 70:
        empty_pen = (residual >= 100.0).astype(np.float64) * 0.35
    elif item < 85:
        empty_pen = (residual >= 100.0).astype(np.float64) * 0.10

    score = base + 0.28 * bonus + 0.55 * exact - empty_pen
    return score
