import numpy as np

_STATE = {
    "opened": 0,
    "count": 0,
}


def priority(item, bins):
    """Best-fit with a preference for already-used bins when residuals tie.

    We score bins by how tightly the item fits (smaller remaining capacity after
    placement is better), but we add a tiny bonus for bins that are already
    partially used so that we do not open new bins unnecessarily.  When several
    bins have identical residual, the first in bin order wins, which naturally
    favors earlier/older bins.
    """
    _STATE["count"] += 1
    # Number of bins that are not completely empty.
    used_mask = bins < 100
    used = int(used_mask.sum())

    residual = bins - item

    # Primary: best fit (smallest residual after placing item, i.e. largest negative).
    # Secondary: prefer used bins slightly over empty bins of equal fit.
    score = -residual.astype(np.float64) + 0.0

    # Tiny nudge to used bins so that among equal-fit choices we keep filling
    # existing bins rather than opening a fresh bin.  Magnitude is small enough
    # not to overcome any real fit difference (residuals are integers).
    score += 0.25 * used_mask.astype(np.float64)

    return score
