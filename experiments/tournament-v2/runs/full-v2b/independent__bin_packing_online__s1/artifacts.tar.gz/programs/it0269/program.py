import numpy as np

_BIN_CAPACITY = 100


def priority(item, bins):
    """Rank bins for an arriving item.

    The rule is a hybrid between best-fit and worst-fit:
    - Strongly prefer bins where the item leaves a small remainder.
    - If no bin can be filled well, prefer putting the item into an existing bin
      rather than opening a fresh one, unless the fresh bin placement is clearly better.
    - Once many bins exist, bias slightly toward fuller bins to keep the bin count low.

    Parameters
    ----------
    item : int
        Size of the arriving item, 1..100.
    bins : np.ndarray
        Remaining capacities of bins the item fits into, in bin order.

    Returns
    -------
    np.ndarray
        Scores of the same length as bins; highest score wins.
    """

    item = int(item)
    caps = np.asarray(bins, dtype=np.int64)
    n = caps.shape[0]

    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # Remainder left after placing the item.
    rem = caps - item

    # Best-fit component: smaller remaining space is better.
    score = -(rem.astype(np.float64))

    # Strongly reward exact or near-exact fits, since these waste no bin capacity.
    # This helps avoid opening a new bin when an existing one can be nearly filled.
    exact_bonus = np.where(rem == 0, 1e6, 0.0)
    near_bonus = np.where((rem > 0) & (rem <= 3), 3e3, 0.0)

    # If the item is large, it is especially important to place it well.
    if item >= 60:
        bonus_scale = 2.0
    elif item >= 40:
        bonus_scale = 1.5
    else:
        bonus_scale = 1.0

    score += exact_bonus + near_bonus * bonus_scale

    # Discourage opening brand-new empty bins unless no good alternative exists.
    # Empty bins have remaining capacity equal to the full capacity.
    empty = caps == _BIN_CAPACITY
    score -= np.where(empty, 25.0, 0.0)

    # Slightly prefer fuller bins as the number of bins grows, which reduces
    # fragmentation without overly harming current placements.
    fullness = (_BIN_CAPACITY - caps).astype(np.float64) / _BIN_CAPACITY
    score += fullness * 6.0

    # Deterministic tie-break: earlier bins win, as required, but a tiny
    # index penalty makes the preference explicit and smooth.
    idx = np.arange(n, dtype=np.float64)
    score -= idx * 1e-6

    return score
