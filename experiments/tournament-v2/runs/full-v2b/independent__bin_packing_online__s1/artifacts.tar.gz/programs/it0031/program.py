import numpy as np


class _State:
    def __init__(self):
        self.n_items = 0
        self.sum_sq = 0.0
        self.sum_item = 0.0
        self.hist = np.zeros(101, dtype=np.int64)


_state = _State()


def priority(item, bins):
    """
    Score bins by best-fit, with a small learned adjustment based on
    observed item-size statistics.

    Core idea:
      - Prefer the bin where the item leaves the least free space (best fit).
      - Slightly discourage putting items into already very full bins if many
        similar-sized items are expected, and slightly reward filling holes.
    """
    global _state

    # --- online statistics (mild, not over-tuned) ---
    _state.n_items += 1
    _state.sum_item += item
    _state.sum_sq += item * item
    _state.hist[item] += 1

    n = _state.n_items
    mean = _state.sum_item / n
    var = max(_state.sum_sq / n - mean * mean, 0.0)
    std = var ** 0.5

    # bins: remaining capacities of feasible bins, numpy int64
    rem = bins.astype(np.float64)
    leftover = rem - float(item)

    # Primary: tight fit -> larger score when leftover is smaller.
    score = -leftover

    # Secondary adjustment:
    # Penalize bins that would become extremely full when item sizes tend to
    # be small/medium (many future items), reward slightly more balanced fill.
    # This term is deliberately weak so best-fit remains dominant.
    fill_after = 100.0 - leftover          # used capacity after placement
    target_fill = 100.0 - mean             # heuristic target used level
    score += 0.02 * (target_fill - fill_after)

    # Mild bonus for using unused bins less eagerly, since fresh bins keep
    # flexibility for large upcoming items when variance is high.
    unused_mask = (rem >= 99.0)
    if np.any(unused_mask):
        score[unused_mask] -= 0.05 * (std / 40.0)

    return score
