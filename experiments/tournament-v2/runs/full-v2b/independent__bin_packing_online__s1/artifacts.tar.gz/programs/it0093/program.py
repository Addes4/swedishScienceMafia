"""Online bin packing: adaptive tight-fit / worst-fit hybrid."""

import numpy as np


class _State:
    def __init__(self):
        # Running estimate of recent item sizes
        self.n = 0
        self.mean_item = 0.0
        # Exponential moving average of item sizes
        self.ema = 0.0
        self.alpha = 0.02
        # Threshold for "good tight fit": below this capacity we prefer tight fit
        # Adaptive threshold (roughly one item's average size)
        self.thresh = 25


_state = _State()


def priority(item, bins):
    # Update running statistics of items seen so far
    _state.n += 1
    if _state.n == 1:
        _state.ema = float(item)
    else:
        _state.ema = (1.0 - _state.alpha) * _state.ema + _state.alpha * float(item)
    # Threshold: below this remaining capacity, prefer tight fit.
    # Slightly above mean item size to favor filling near-full bins, but not too high
    # so we still pack larger remaining bins with medium items.
    _state.thresh = _state.ema * 0.85 + 6.0

    cap = bins  # remaining capacities of fitting bins (numpy int64 array)

    # Tight-fit score: bins with smaller remaining capacity (but >= item) get higher score
    # We use -(cap) so smaller cap -> larger score, but ensure item fits (given).
    tight = -(cap.astype(np.float64))

    # Worst-fit score: bins with larger remaining capacity get higher score
    worst = cap.astype(np.float64)

    # Decide based on remaining capacity:
    # If there is a bin that leaves a small residual (<= thresh-ish), do tight fit there.
    residual = cap - item
    # Prefer tight fit when the resulting residual is small (bins near full after placing)
    # Otherwise prefer worst-fit among reasonably fitting bins to avoid tiny fragments.

    # Score construction:
    # For bins where residual <= thresh: strong preference for small residual (tight fit).
    # For other bins: mild preference for larger remaining capacity (worst fit),
    # but less than the tight-fit rewards, so tight fit dominates when available.
    scores = np.empty_like(tight)

    small_res = residual <= _state.thresh
    # Large constant so tight-fit bins always outrank non-tight-fit bins
    scores[small_res] = -residual[small_res].astype(np.float64)
    # Non tight-fit bins: prefer largest remaining capacity (worst fit), scaled small
    scores[~small_res] = -0.001 * cap[~small_res].astype(np.float64)

    return scores
