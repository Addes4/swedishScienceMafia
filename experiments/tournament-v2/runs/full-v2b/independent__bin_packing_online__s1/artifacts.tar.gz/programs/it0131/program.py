import numpy as np
from bisect import bisect_left, bisect_right

# ---------- tunable params ----------
K_CAND = 24          # number of candidate bins whose exact future cost we evaluate
H_FUT = 80           # horizon length for the DP (simulated future items)
DP_NSTATES = 400     # cap on DP dictionaries
EPS = 1e-6           # tiny per-index perturbation for tie breaking

# ---------- pseudo-random future items (deterministic, no RNG state issues) ----------
_rng = np.random.RandomState(987654321)
_FUTURE = _rng.weibull(1.5, size=20000) * 45.0
_FUTURE = np.clip(_FUTURE, 1, 100).astype(np.int64)
_future_ptr = 0

def _next_future(n):
    global _future_ptr
    if _future_ptr + n > len(_FUTURE):
        _future_ptr = 0
    out = _FUTURE[_future_ptr:_future_ptr + n]
    _future_ptr += n
    return out

# ---------- exact-ish bin packing cost via DP over capacity multiset ----------
def _bins_used_exact(caps, items):
    """
    caps: list/array of remaining capacities of currently open bins (all >= 1)
    items: array of future item sizes
    Returns approximate minimal additional bins needed (DP over sorted caps multiset).
    Uses full capacity profile; caps are ints <= 100.
    """
    # represent state as sorted tuple of capacities (descending)
    caps = [int(c) for c in caps if c > 0]
    caps.sort(reverse=True)
    state = tuple(caps)
    # memo: state -> (cost) using recursion with dictionary
    memo = {}

    def solve(st, idx):
        if idx >= len(items):
            return 0
        key = (st, idx)
        v = memo.get(key)
        if v is not None:
            return v
        it = int(items[idx])
        # try fitting into existing bins
        best = None
        seen_caps = set()
        for i in range(len(st)):
            c = st[i]
            if c >= it and c not in seen_caps:
                seen_caps.add(c)
                new_c = c - it
                lst = list(st)
                lst.pop(i)
                if new_c > 0:
                    lst.append(new_c)
                lst.sort(reverse=True)
                ns = tuple(lst)
                cand = solve(ns, idx + 1)
                if best is None or cand < best:
                    best = cand
        # or open new bin
        lst = list(st)
        new_c = 100 - it
        if new_c > 0:
            lst.append(new_c)
        lst.sort(reverse=True)
        ns = tuple(lst)
        cand_new = 1 + solve(ns, idx + 1)
        if best is None or cand_new < best:
            best = cand_new
        memo[key] = best
        return best

    return solve(state, 0)


def priority(item, bins):
    n = len(bins)
    scores = np.full(n, -1e18, dtype=np.float64)

    # Candidate bins: the best-fit bins (tightest skip) plus a few worst-fit ones
    # Sort bin indices by remaining capacity ascending (tightest first)
    order = np.argsort(bins, kind="stable")
    cand_set = set()
    # tightest K_CAND bins
    for idx in order[:K_CAND]:
        cand_set.add(int(idx))
    # also least-tight that still fit (already all fit), add a couple of largest for diversity
    for idx in order[-3:]:
        cand_set.add(int(idx))

    # Greedy baseline score for safety (best fit) - only needed if DP fails
    # build candidate evaluation
    future = _next_future(H_FUT)

    cand_list = list(cand_set)
    # For each candidate bin j, compute cost: 1 if item placed in j (bin already open),
    # then optimal packing cost of remaining capacities (including j's reduced capacity)
    # plus the future items.
    # Baseline capacities = all bins' capacities except we consider item placed in j:
    base_caps = [int(b) for b in bins if b > 0]  # all fit bins have b>=item

    for j in cand_list:
        caps_j = list(base_caps)
        # find j-th bin capacity? We need to reduce exactly bin j's capacity.
        # base_caps currently is a multiset, we must remove one occurrence of bins[j]
        bj = int(bins[j])
        caps_j.remove(bj)
        new_cj = bj - item
        if new_cj > 0:
            caps_j.append(new_cj)
        # cost = DP over caps_j + future items
        # To keep DP small, cap number of bins considered
        caps_j.sort(reverse=True)
        if len(caps_j) > 18:
            caps_j = caps_j[:18]
        cost = _bins_used_exact(caps_j, future)
        # lower cost is better => score = -cost
        scores[j] = -cost * 1000.0 - j * EPS

    # any non-candidate bins get a very bad score
    return scores
