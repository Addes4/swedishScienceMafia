import numpy as np
from collections import deque

class _Learner:
    def __init__(self):
        # Exponential moving histogram over item sizes (1..100)
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0
        self.total = 0.0
        # Cache some sums for the score computation
        self.recent_items = deque(maxlen=200)
        # Track distribution drift (weibull mean ~40)
        self.run_mean = 40.0

    def update(self, item):
        self.count += 1
        # Decay old counts slightly (moving window effect)
        if self.count % 16 == 0:
            self.hist *= 0.97
        self.hist[item] += 1.0
        self.total += item
        self.recent_items.append(item)
        # Running mean estimate (exponential)
        alpha = 0.01
        self.run_mean = (1 - alpha) * self.run_mean + alpha * item

_learner = _Learner()

# Precompute the histogram array index range
_HIST_IDX = np.arange(101, dtype=np.float64)

def priority(item, bins):
    global _learner
    _learner.update(item)

    n = len(bins)

    # Best-fit base score: negative remaining capacity after placement.
    # residual = bins - item (>=0 since bins filtered to fit)
    residual = bins - item

    # Base score favors smallest residual (tightest fit).
    score = -residual.astype(np.float64)

    # Tie-break / adjustment: prefer residuals that are unlikely to be useful
    # for future items. If residual equals a very common item size, it may be
    # better to fill it next time (i.e., that bin is "attractive" to leave).
    # Conversely, if residual is a rare size, waste is less costly now.
    # Compute probability mass near that residual in learned histogram.
    hist = _learner.hist
    hsum = hist.sum()
    if hsum > 0:
        # For each residual, mass of items that fit exactly or nearly:
        # approximate using histogram value at residual (smoothed).
        # Smooth with neighbors.
        r = residual  # int64 array, 0..100
        # clamp
        r_clamped = np.clip(r, 0, 100)
        # simple 3-point smoothing of the histogram
        hs = hist.copy()
        hs[1:] += hist[:-1] * 0.5
        hs[:-1] += hist[1:] * 0.5
        mass = hs[r_clamped] / (hsum + 1e-9)
        # Large residual preference: if residual is close to 100 (unused bin),
        # we should strongly prefer tight fit instead, handled by base score.
        # Adjustment magnitude should be small relative to base (which is in 0..100).
        # Base score range: -99..0. Adjustment range: -0.6..0.
        penalty = mass * 1.0
        # Only penalize when residual is a plausible future item (size >= 1).
        score -= penalty

    # Small deterministic bias: prefer later bins among equal scores to reduce
    # fragmentation? Actually ties go to first bin; harness handles that.
    # Slight preference for bins with residual that is a common size is
    # implemented via the penalty above (we penalize leaving a common size).

    return score
