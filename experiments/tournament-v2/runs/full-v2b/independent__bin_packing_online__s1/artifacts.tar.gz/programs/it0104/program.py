import numpy as np

# Online bin-choice rule for stochastic bin packing (Weibull-like sizes, mean ~40).
#
# Strategy:
#  - Strongly prefer tight fits (small residual after placing item) => classic best fit.
#  - Discourage placements that create unusable small residuals (waste).
#  - Slightly prefer reusing existing partially used bins over opening new ones.
#
# The distributions are unknown at runtime except that sizes are 1..100 and mean ~40.
# We keep light state: running mean of observed item sizes (for waste estimation).

_state = {
    "n": 0,
    "sum": 0.0,
    "mean": 40.0,
}


def priority(item, bins):
    # Update running mean estimate of item sizes (used to gauge "useful" residual)
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]
    _state["mean"] = mean

    bins = np.asarray(bins)

    residual = bins - item            # remaining capacity after placing item
    # Base: prefer small residual (best fit). Negative because higher score wins.
    score = -residual.astype(np.float64)

    # Penalize creating unusably small residual fragments.
    # A fragment of size r is "wasted" if r < some threshold (small compared to mean item).
    # We use a soft penalty that grows as residual shrinks below ~mean/4.
    threshold = max(2.0, mean * 0.25)
    # waste penalty only applies when residual is small but positive
    small = residual < threshold
    if np.any(small):
        # penalty magnitude: how far below threshold
        pen = np.where(small, (threshold - residual), 0.0)
        score -= 0.5 * pen

    # Mild preference to reuse already-open bins (avoid fresh 100-capacity bins
    # if it means opening a new bin). Reusing bins concentrates load.
    fresh = bins == 100
    if np.any(fresh):
        score[fresh] -= 3.0

    # Avoid leaving a bin with exactly zero residual? No: perfect fit is ideal.
    # Slight bonus for perfect fits (residual == 0).
    score += np.where(residual == 0, 1.0, 0.0)

    # Guarantee no NaNs
    score = np.nan_to_num(score, nan=-1e9)

    return score
