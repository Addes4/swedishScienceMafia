import numpy as np


def priority(item, bins):
    """Return a score for each bin; highest score wins (ties go to the first).

    Strategy: best fit with a small penalty for leaving very little space.
    This keeps bins tightly packed while slightly discouraging the creation
    of nearly-full bins that can no longer accept small items.
    """
    remaining_after = bins - item
    # Best fit: smaller remaining capacity is better.
    score = -remaining_after.astype(np.float64)

    # Mildly penalize exact or near-exact fills so small later items retain options.
    # This is a soft preference, not a hard constraint.
    tight = remaining_after <= 2
    score[tight] -= 0.25 * (3 - remaining_after[tight])

    # Slightly prefer using already-open bins over fresh bins when fit is similar.
    # Fresh bins have remaining capacity 100; this is a gentle push away from waste.
    fresh = bins == 100
    score[fresh] -= 0.05

    return score
