import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "sum2": 0.0,
    "counts": None,
}

def priority(item, bins):
    # --- Online stats: estimate typical item size / distribution shape ---
    s = _state
    s["n"] += 1
    s["sum"] += item
    s["sum2"] += float(item) * float(item)

    n = s["n"]
    mean = s["sum"] / n
    var = max(0.0, s["sum2"] / n - mean * mean)
    std = var ** 0.5

    # Small-item regime: pure best fit is usually excellent.
    # Large-item regime: avoid leaving tiny useless holes, so add a penalty
    # for residuals that are too small to fit a plausible future item.
    # target_res = typical future item size we'd like to leave room for.
    target_res = max(1.0, min(60.0, mean * 0.9))

    r = (bins - item).astype(np.float64)  # remaining capacity after placement

    # Base best-fit preference
    score = -r

    # Penalize very small residuals (fragmentation waste), especially when
    # item is large relative to current mean.
    # penalty grows as residual shrinks below a soft threshold.
    soft = max(4.0, min(25.0, target_res))
    small_pen = 0.0
    if item >= 25:
        # only apply when item is not tiny
        pen_scale = 1.0 + (item / 100.0) * 2.0
        # smooth penalty: high for r near 0, zero for r >= soft
        small_pen = pen_scale * np.exp(-r / max(1.0, soft))

    # Mild bonus for residuals close to target_res (keeps bins in useful sizes)
    near_bonus = -0.15 * np.abs(r - target_res) / max(1.0, target_res)

    # Slight preference to use already non-empty bins rather than 100-capacity
    # (reduce number of open bins): empty bins have r = 100 - item.
    # If item is small, opening new bins is often bad.
    empty_pen = np.where(bins == 100, 1.0, 0.0)
    if item <= 30:
        empty_pen = empty_pen * 2.0
    else:
        empty_pen = empty_pen * 0.5

    denom = max(1.0, std)
    score = score + near_bonus - small_pen - empty_pen * (10.0 / denom)

    # Ensure strict finite and no NaN
    score = np.nan_to_num(score, nan=-1e18, posinf=1e18, neginf=-1e18)
    return score
