import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0.0
        self.fullish = 0
        self.last_item = 40.0

    def update(self, item):
        self.n += 1
        self.total += item
        self.last_item = 0.9 * self.last_item + 0.1 * item

    @property
    def mean_item(self):
        if self.n == 0:
            return 40.0
        return self.total / self.n


_state = _State()


def priority(item, bins):
    _state.update(item)

    # Remaining capacity after placing this item.
    rem = bins - item

    # Main criterion: leave as little empty space as possible.
    score = -rem.astype(np.float64)

    # Mildly discourage leaving tiny unusable fragments.
    # If the leftover is smaller than a typical future item, it is less useful.
    mean = _state.mean_item
    if item >= 50:
        # Large items: prefer exact-ish fits, but tiny leftovers are still bad.
        score -= 0.004 * np.where((rem > 0) & (rem < mean * 0.5), rem, 0.0)
    else:
        # Small items: packing tightly matters more; discourage useless fragments.
        score -= 0.002 * np.where((rem > 0) & (rem < mean * 0.35), rem, 0.0)

    # Very slight preference for bins that already have some item(s), which tends
    # to reduce the number of active bins without changing the tightness order.
    score += 0.00005 * (100 - bins)

    return score
