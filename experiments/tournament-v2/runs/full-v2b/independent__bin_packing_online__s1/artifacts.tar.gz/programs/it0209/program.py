import numpy as np

_rng = np.random.default_rng(12345)


def priority(item, bins):
    """Score bins by tightest fit (best fit), with a tiny random tie-breaker.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary score: prefer the smallest remaining capacity after placement,
    # i.e. the tightest fit (best fit).
    primary = -(bins - item)

    # Tiny random perturbation for tie-breaking. It is scaled small enough
    # that it only matters between bins with identical residual capacity.
    n = bins.shape[0]
    noise = _rng.random(n) * 1e-3

    return primary + noise
