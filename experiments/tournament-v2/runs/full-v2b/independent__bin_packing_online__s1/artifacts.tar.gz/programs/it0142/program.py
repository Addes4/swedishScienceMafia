import numpy as np


def priority(item, bins):
    """Best-fit with a small tie-breaking preference for fuller bins.

    The item is placed in the bin whose remaining capacity is closest to the item size.
    Among equally tight bins, earlier bins are preferred by the harness on ties, so we add a
    tiny decreasing term based on bin fullness to stabilize behavior without changing the
    essential best-fit decision.
    """
    # Primary: smaller remaining capacity after placing item is better.
    # Equivalent to maximizing -(bins - item).
    # Add a very small secondary preference for bins with less remaining capacity
    # so that ties are broken toward tighter bins first.
    return -(bins - item) - 1e-9 * bins
