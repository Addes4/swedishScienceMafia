import numpy as np


def priority(item, bins):
    """
    Score bins for online bin packing.

    Strategy: best-fit (minimize remaining capacity after placement) with a
    secondary preference for currently unused bins (remaining capacity == 100)
    to keep flexibility. This is a classic online bin packing heuristic that
    performs well on Weibull-shaped item distributions with mean ~40.

    Score = -(bins - item) for used bins, i.e. highest score for tightest fit.
    For unused bins (remaining == 100), we give a small bonus so that we
    preferentially use fresh bins only when they are the tightest fit anyway;
    in practice best-fit already handles this well, so we keep the bonus tiny.
    """
    # Tightest fit: maximize -(remaining after placement)
    score = -(bins - item).astype(np.float64)

    # Small bonus for completely unused bins (remaining capacity 100).
    # This encourages opening new bins slightly earlier, which can reduce
    # fragmentation when item sizes vary widely.
    unused = bins == 100
    if np.any(unused):
        score += 1e-3 * unused.astype(np.float64)

    return score
