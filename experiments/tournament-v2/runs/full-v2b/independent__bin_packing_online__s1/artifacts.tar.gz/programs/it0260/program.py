import numpy as np

# State for online statistics (running mean of item sizes seen so far)
_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """
    Online bin choice rule.

    Strategy:
    - Primary: best fit (minimize remaining slack after placing the item),
      i.e. prefer the bin whose remaining capacity is closest to the item size.
    - Tie-breaker 1: prefer bins that are already partially filled (higher used space)
      so we don't spread items too thinly across many bins.
    - Tie-breaker 2: slight penalty on creating very small leftover capacity
      that is likely unusable for future items.
    """
    global _state
    _state["n"] += 1
    _state["sum"] += item

    # Running mean estimate of item sizes (used to judge "useful" leftovers)
    mean_item = _state["sum"] / _state["n"] if _state["n"] > 0 else 40.0

    # Remaining capacity after placing item in each bin
    remaining_after = bins - item  # all >= 0 by problem guarantee (bins shown all fit)

    # --- Primary score: best fit ---
    # Lower remaining_after is better => use negative remaining_after.
    # Use float to allow smooth tie-breaking.
    slack = remaining_after.astype(np.float64)

    # --- Penalty for useless tiny leftovers ---
    # A leftover smaller than a typical future item is nearly wasted; penalize it.
    # Scale: leftovers near 0 are penalized more than leftovers near mean_item.
    tiny = np.maximum(0.0, mean_item - slack) / mean_item  # in [0, 1] roughly

    # --- Bonus for existing fill (reuse bins that already hold items) ---
    # Used space before placing: 100 - bins. For unused bins this is 0.
    used = (100.0 - bins.astype(np.float64))
    if used.size > 0:
        max_used = used.max()
        if max_used > 0:
            fill_bonus = used / max_used  # in [0, 1]
        else:
            fill_bonus = np.zeros_like(used)
    else:
        fill_bonus = np.zeros_like(used)

    # Combine: higher score = better.
    # Dominant term: -slack (best fit). Secondary terms are small perturbations.
    score = -slack - 0.5 * tiny + 0.1 * fill_bonus

    return score
