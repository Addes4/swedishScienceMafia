import numpy as np


def priority(item, bins):
    # Tightest-fit first: smallest remaining capacity that still fits the item.
    # Since bins only contains bins where item fits, bins >= item always holds.
    rem = bins.astype(np.int64, copy=False)
    # Primary: prefer smallest remaining capacity after placing (equiv. smallest bins).
    # Secondary: prefer bins that are already partially used (not exactly 100) slightly,
    # because it keeps the number of open/active bins low and reduces fragmentation.
    placed = np.where(rem == 100, 0, 1)
    # Score: higher is better. Tightest fit gives -(rem); add small bonus for used bins.
    # A small bonus also breaks ties deterministically in favor of used bins.
    return -(rem - item) + placed * 1e-6
