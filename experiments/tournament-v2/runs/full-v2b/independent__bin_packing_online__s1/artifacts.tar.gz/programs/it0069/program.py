import numpy as np


class PackerState:
    def __init__(self):
        self.n_calls = 0
        self.sum_items = 0.0
        self.full_bins = 0

    def update(self, item):
        self.n_calls += 1
        self.sum_items += item


_STATE = PackerState()


def priority(item, bins):
    """Adaptive best-fit ranking for online bin packing.

    The item is placed in the bin with the highest score.
    We mostly prefer tight fits, but add small bonuses for exact fill,
    for leaving bins empty, and for avoiding very small remainders.
    """
    _STATE.update(item)

    # bins: remaining capacity of candidate bins, in bin-index order.
    b = bins.astype(np.float64)

    # Base: tighter fit is better.  -(remaining - item)
    score = -(b - float(item))

    # Strongly reward exact fits, since they perfectly close a bin.
    score += 0.35 * (b == float(item))

    # Mildly prefer unused bins over creating tiny unusable remainders.
    score += 0.002 * (b == 100.0)

    # Penalize remainders that are too small to be useful for typical future items.
    rem = b - float(item)
    score -= 0.0008 * np.where(rem < 8.0, (8.0 - rem), 0.0)

    # Slight preference for bins whose resulting remainder is in a good range.
    score += 0.0004 * np.exp(-((rem - 20.0) / 18.0) ** 2)

    return score
