# EVOLVE-BLOCK-START
"""Adaptive best-fit rule for online bin packing."""
import numpy as np


class PackerState:
    def __init__(self):
        # Exponential moving average of item sizes, used to adapt the unused-bin bias.
        self.mean = 40.0
        self.alpha = 0.002
        self.calls = 0

    def update(self, item):
        self.calls += 1
        self.mean = (1.0 - self.alpha) * self.mean + self.alpha * float(item)


_STATE = PackerState()


def priority(item, bins):
    """Rank bins for the arriving item.

    Prefer the tightest fitting bin with some content.  Unused bins (capacity 100)
    are penalized slightly so that space is reserved for future items unless the
    current item is fairly large relative to the observed mean.
    """
    _STATE.update(item)

    # Best-fit score: tighter fits have smaller residual capacity.
    # Add a small bias against completely empty bins.  The bias grows when items
    # have recently been small on average, encouraging consolidation.
    empty_bias = max(0.0, 8.0 - 0.15 * _STATE.mean)

    is_empty = bins == 100
    score = -(bins - item).astype(np.float64)
    score[is_empty] -= empty_bias

    return score
# EVOLVE-BLOCK-END
