import numpy as np


def priority(item, bins):
    # State tracking whether each bin index is considered "active" (already opened)
    # and the capacity at which it was left. This helps prefer slightly less full
    # open bins over empty ones when the item is small, and prefer tight fits when
    # the item would otherwise leave too much waste.
    global _opened, _last_rem

    n = len(bins)
    if '_opened' not in globals() or len(_opened) != n:
        _opened = np.zeros(n, dtype=bool)
        _last_rem = np.full(n, 100, dtype=np.int64)

    rem = bins.astype(np.int64, copy=False)
    scores = np.empty(n, dtype=np.float64)

    # Heuristic scoring:
    # - Strongly prefer non-empty bins where item fits tightly (best fit),
    #   but add a bonus for bins whose remaining capacity is close to item,
    #   and a small penalty for opening brand-new bins (rem == 100).
    # - For items > 50, prefer to place into bins that become nearly full.
    # - For small items, slightly avoid filling medium bins too early by
    #   slightly preferring larger leftovers with better future potential.
    for i in range(n):
        r = rem[i]
        if r < item:
            scores[i] = -1e18
            continue

        waste = r - item  # remaining capacity after placement

        if r == 100:
            # new bin penalty; less severe when item is large, since large
            # items benefit from fresh bins
            if item >= 70:
                base = -0.5
            elif item >= 40:
                base = -2.0
            else:
                base = -8.0
            score = base
        else:
            # Prefer tighter fits. Strongest term is -waste.
            score = -float(waste)

            # Extra reward for leaving very little remaining capacity:
            # finishing a bin is good.
            if waste == 0:
                score += 20.0
            elif waste <= 2:
                score += 10.0
            elif waste <= 5:
                score += 4.0
            elif waste <= 10:
                score += 1.0

            # Small bonus for using a bin already in use over opening a new one
            score += 3.0

            # For large items, don't try to squeeze into bins that are already
            # nearly full unless it fits well; this is already handled by
            # -waste.  For very small items, prefer bins that leave more room
            # for future medium items, unless a tight fit finishes a bin.
            if item <= 15:
                # prefer larger remaining space a bit, to preserve ability to
                # match medium items later, but still value tight fits
                score += 0.05 * min(r, 60)

        scores[i] = score

    # Ensure deterministic tie-breaking by index: the harness picks first max.
    return scores
