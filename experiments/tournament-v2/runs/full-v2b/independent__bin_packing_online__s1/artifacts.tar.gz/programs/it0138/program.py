"""Online bin packing: best-fit with waste-aware penalties for small unusable gaps."""
import numpy as np

_ALPHA = 0.15  # penalty weight for creating hard-to-fill small gaps


def priority(item, bins):
    """Rank bins so the item goes into a good bin; highest score wins (first on ties).

    Strategy: prefer tightest fit (best fit), but discourage leaving behind gaps so
    small that likely-future items cannot fill them, and lightly prefer already-used
    bins to avoid opening fresh ones prematurely.
    """
    rem_after = bins - item  # remaining capacity if item placed in each bin

    # Base: best fit -> smaller leftover is better.
    score = -rem_after.astype(np.float64)

    # Penalty for creating a leftover gap in the (0, item) window that is awkward:
    # a gap smaller than typical item sizes wastes capacity, so penalize it more
    # as it gets smaller but nonzero.
    small = (rem_after > 0) & (rem_after < item)
    if np.any(small):
        penalty = _ALPHA * (item - rem_after)
        score = np.where(small, score - penalty, score)

    # Slight preference for bins that are already in use (remain < 100) when fits
    # are otherwise comparable, to consolidate.
    full_bin = bins == 100
    score = np.where(full_bin & (rem_after == 0), score, score)
    score = score + np.where(bins < 100, 1e-6, 0.0)

    # Exact fit (rem_after == 0) is always strongly favored.
    score = np.where(rem_after == 0, 1e9, score)

    return score
# EVOLVE-BLOCK-END
