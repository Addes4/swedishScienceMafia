"""Online bin packing priority: best-fit with a size-aware penalty for opening fresh bins."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tightest fit, but discourage using empty bins for smaller items.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    # Best fit: smaller remaining capacity after placing the item is better.
    score = -(bins - item)

    # Penalize completely unused bins (remaining == 100) more strongly for small items,
    # so that small items fill existing bins instead of wasting a fresh bin.
    empty = bins == 100
    if item < 100 and np.any(empty):
        # Penalty grows as item gets smaller, making empty bins unattractive for small items.
        penalty = (100 - item) * 0.5
        score = score - empty * penalty

    return score
