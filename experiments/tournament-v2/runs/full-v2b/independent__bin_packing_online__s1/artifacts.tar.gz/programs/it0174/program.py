import numpy as np


def priority(item, bins):
    # bins: remaining capacities of bins the item fits in.
    # Highest score wins; ties go to the first bin.
    #
    # Basic strategy: best fit = put item in the fullest bin it fits into.
    # score = -(remaining - item) equivalently remaining.
    #
    # Improvements:
    # 1) Strongly prefer bins that become full or nearly full.
    # 2) Among otherwise similar choices, prefer already-used bins over empty ones.
    # 3) For small items, keep large empty bins available by using a moderate
    #    best-fit bias rather than always filling the emptiest bin.

    # Best-fit score: smaller remaining capacity is better.
    score = -bins.astype(np.float64)

    # Encourage finishing bins: if item exactly fills the bin, huge bonus.
    exact = bins == item
    score[exact] += 1e6

    # Slight bonus for bins that will be left with very little capacity.
    leftover = bins - item
    score += np.where((leftover >= 0) & (leftover <= 5), 50.0 - leftover * 5.0, 0.0)

    # Avoid using empty bins unless necessary: unused bins have remaining 100.
    # Prefer used bins over empty bins, but only mildly, so packing stays tight.
    score += np.where(bins == 100, -20.0, 0.0)

    # For large items, be more aggressive about best fit (tight packing matters).
    if item >= 50:
        score += -bins.astype(np.float64) * 0.5

    return score
