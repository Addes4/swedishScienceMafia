import numpy as np

def priority(item, bins):
    n = len(bins)
    # Detect unused bins (remaining capacity 100)
    unused_mask = bins == 100
    n_unused = unused_mask.sum()
    n_used = n - n_unused

    # If no used bins yet, just use the first unused bin
    if n_used == 0:
        # Score: highest for the first bin (unused)
        scores = np.zeros(n, dtype=np.float64)
        scores[0] = 1.0
        return scores

    # If the item is large, prefer to open a new bin unless a perfect fit exists
    # If the item is small, prefer to fit into existing bins tightly
    # Use a threshold based on item size and current utilization
    used_bins = bins[~unused_mask]
    total_used_cap = 100 - used_bins.mean()  # average fill fraction? Actually mean remaining = average free space
    avg_free = used_bins.mean()
    utilization = 1.0 - avg_free / 100.0  # fraction of used bins' capacity that is filled

    scores = np.zeros(n, dtype=np.float64)

    # Best-fit score for used bins: tightest fit (smallest remaining)
    # Higher score for smaller remaining capacity that still fits
    fit_mask = bins >= item
    # For used bins that fit
    used_fit = fit_mask & (~unused_mask)
    if used_fit.any():
        # Score based on remaining capacity after placement: smaller is better
        remaining_after = bins[used_fit] - item
        # Normalize: best fit gets high score
        # Use negative remaining, scaled
        scores[used_fit] = 100.0 - remaining_after  # ranges from item to 100

    # For unused bins: give a moderate score if no perfect fit exists
    # Prefer opening new bin only if item is large or no good tight fit
    best_fit_remaining = None
    if used_fit.any():
        best_fit_remaining = (bins[used_fit] - item).min()

    # Threshold: if item is large (> 50) or best fit leaves too much waste (> 30), prefer new bin
    if n_unused > 0:
        if best_fit_remaining is None:
            # No used bin fits, must use unused
            scores[unused_mask] = 1.0
        else:
            waste = best_fit_remaining
            # Heuristic: if waste > threshold, opening new bin might be better
            # threshold depends on item size
            threshold = max(10, item * 0.5)
            if waste > threshold or item > 60:
                # Give unused bins a slightly higher score to prefer opening new
                scores[unused_mask] = 100.0 - item + 50  # ensure higher than best fit
            else:
                # Otherwise stick with used bins
                scores[unused_mask] = 0.0

    # Ensure unused bins have a score even if fit_mask is False (they always fit since cap 100 >= item)
    # Actually unused bins always fit, but they might be in fit_mask
    # Handle case where item fits in unused bins but not used bins
    if not used_fit.any() and n_unused > 0:
        scores[unused_mask] = 1.0

    # Tie-breaking: first bin wins, so we don't need to adjust order

    return scores
