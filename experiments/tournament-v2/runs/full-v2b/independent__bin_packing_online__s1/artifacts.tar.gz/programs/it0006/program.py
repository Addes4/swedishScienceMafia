import numpy as np

# Global state
_item_counts = np.zeros(101, dtype=np.int64)
_total_items = 0

# Capacity preference weights: computed from typical Weibull(mean 40) item-size distribution.
# Values chosen to mildly favor filling bins to capacities that are commonly reachable
# as sums of small/medium items, without overcomplicating the online decision.
_PREF = np.zeros(101, dtype=np.float64)

def _init_pref():
    # Build an approximate histogram of the Weibull-like size distribution.
    # mean ~40, shape ~1.5 => CDF known approximately. We sample deterministically.
    # We only need rough weights, so use a discretized Weibull(shape=1.5) scaled to mean 40.
    shape = 1.5
    # For Weibull with shape k and mean m, scale lam = m / Gamma(1 + 1/k)
    import math
    gamma = math.gamma(1.0 + 1.0 / shape)
    lam = 40.0 / gamma
    # Evaluate probability mass per integer size 1..100
    probs = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        x = (s + 0.5) / lam
        x0 = max((s - 0.5) / lam, 0.0)
        cdf_hi = 1.0 - math.exp(-(x ** shape))
        cdf_lo = 1.0 - math.exp(-(x0 ** shape))
        probs[s] = max(cdf_hi - cdf_lo, 0.0)
    probs = probs / probs.sum()

    # Expected residual desirability: for a bin with remaining capacity c,
    # we prefer c if c is close to a size that often appears, or a good combo.
    # Simple heuristic: prefer leaving capacity equal to common small/medium item sizes,
    # and also prefer capacities that are multiples of common sizes.
    # We'll use a smoothed function of probs plus bonus for capacities that are
    # sums of two common items (approximated by convolution).
    conv = np.convolve(probs[1:], probs[1:])  # sums of two items (indices 0..198)
    combo = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        idx = s - 2  # conv index for sum s when both items >=1
        if 0 <= idx < len(conv):
            combo[s] = conv[idx]

    for c in range(101):
        # Base: small residual capacities are generally bad (waste), large are okay.
        # We want bins to be fillable later, so residual that matches a likely item
        # or sum of items is good.
        w = 0.0
        if c == 0:
            w = 1.0  # perfectly full is ideal
        elif c <= 100:
            # probability that a future item exactly fits
            p_fit = probs[c] if c <= 100 else 0.0
            p_combo = combo[c] if c <= 100 else 0.0
            # prefer residuals that are likely to be exactly filled by one or two items
            w = 0.3 * p_fit + 0.7 * p_combo
            # penalize very small unusable residuals (1..5) slightly
            if c < 6:
                w *= 0.3
        _PREF[c] = w


_init_pref()

def priority(item, bins):
    global _total_items
    _total_items += 1
    _item_counts[item] += 1

    # bins: remaining capacities of bins item fits into.
    # Best-fit: score = -(bins - item) = item - bins, higher for smaller residual.
    # We add a small adaptive preference for residual capacities that are "good".
    # Since bins array is int64, compute residual after placing item.
    residual = bins - item

    # Base best-fit score.
    score = -residual.astype(np.float64)

    # Add preference for the residual capacity left after placement.
    # residual is 0..99 (item placed, capacity decreases).
    # Use vectorized lookup.
    pref = _PREF[residual]

    # Weight the preference. Small weight to not override best-fit too much.
    # Adaptive: if we have seen many items, trust preference more.
    w = 0.15
    score += w * pref

    return score
