"""Best-fit with empty-bin penalty for online bin packing."""

import numpy as np


def priority(item, bins):
    """Rank bins for best-fit packing.

    The item goes to the bin with the highest score.  Bins are ranked by
    how tightly the item fits (smaller remaining capacity after placement
    is better), with a small penalty applied to currently empty bins so
    that partially filled bins are preferred when the fit is comparable.
    """
    remaining = bins - item

    # Primary objective: minimize leftover space after placement.
    score = -remaining.astype(np.float64)

    # Empty bins (remaining capacity 100 before placement) get a small
    # penalty.  This avoids opening a fresh bin when a partial bin can
    # accept the item with an almost equally tight fit.
    score -= 0.6 * (bins == 100)

    return score
