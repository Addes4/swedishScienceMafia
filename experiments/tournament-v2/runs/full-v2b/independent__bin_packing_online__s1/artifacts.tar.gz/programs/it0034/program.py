import numpy as np

# State kept across calls: counts of observed item sizes.
_counts = np.zeros(101, dtype=np.float64)
_seen = 0

# Precompute a smooth prior over item sizes (Weibull-shaped, mean ~40).
# We use a simple empirical-ish prior so early calls are not blind.
_prior = None


def _init_prior():
    global _prior
    if _prior is None:
        x = np.arange(1, 101, dtype=np.float64)
        # Weibull-ish shape: scale chosen so mean approx 40, shape around 2.
        shape = 2.0
        scale = 45.0
        w = (shape / scale) * (x / scale) ** (shape - 1.0) * np.exp(-(x / scale) ** shape)
        w = w / w.sum()
        _prior = w


def priority(item, bins):
    global _seen, _counts
    _init_prior()
    _counts[item] += 1.0
    _seen += 1.0

    # Blend prior with observed counts.
    # Use a modest smoothing so the rule adapts quickly but stays stable.
    alpha = 200.0
    probs = (_counts[1:] + alpha * _prior) / (_seen + alpha)
    probs = probs / probs.sum()

    # For each bin, estimate the expected "waste" if we place this item there.
    # A bin with remaining capacity r will, in a simple model, be filled by
    # future items drawn from probs; we favor bins whose remaining capacity
    # is close to a likely item size or to a likely sum of item sizes.
    # A cheap and effective proxy: prefer bins where (r - item) is small but
    # also likely to be exactly coverable by a future item.
    rem = bins.astype(np.float64) - float(item)

    # Best-fit base: smaller remaining is better.
    score = -rem

    # Bonus if the leftover capacity is likely to be exactly matchable by a
    # future item (reduces fragmentation).
    # P(leftover == k) approximated by probs[k-1].
    left = rem.astype(np.int64)
    valid = (left >= 1) & (left <= 100)
    match_bonus = np.zeros_like(rem)
    if np.any(valid):
        idx = left[valid] - 1
        match_bonus[valid] = probs[idx]

    # Weight the match bonus; tune modestly.
    score += 25.0 * match_bonus

    # Small preference for earlier bins to keep packing compact.
    # (Bin order is fixed; this breaks ties toward lower indices already.)
    return score
