"""Learned bin-choice rule: best-fit with residual-capacity shaping."""
import numpy as np

# Tuned constants for the Weibull-like item distribution (mean ~40, sizes 1..100).
# The base rule is best-fit: prefer the bin with the smallest remaining capacity
# that still fits.  A mild bonus is added for residuals near 0 and near 100,
# because those bins are either efficiently closed or left almost open.
_W_NEAR_ZERO = 0.35
_W_NEAR_FULL = 0.12
_W_MID = -0.18
_MID_LO = 18.0
_MID_HI = 72.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties to first."""
    residual = np.asarray(bins, dtype=np.float64) - float(item)

    # Primary term: best-fit.  Smaller residual => higher score.
    score = -residual

    # Shape only the residual after placing the item, without breaking best-fit
    # ordering in the common regime.
    near_zero = np.maximum(0.0, 1.0 - residual / 8.0)
    near_full = np.maximum(0.0, 1.0 - (100.0 - residual) / 10.0)

    # Mid-range residuals are slightly less attractive: they tend to fragment.
    mid = ((residual >= _MID_LO) & (residual <= _MID_HI)).astype(np.float64)

    score += _W_NEAR_ZERO * near_zero
    score += _W_NEAR_FULL * near_full
    score += _W_MID * mid

    return score
