import numpy as np


def priority(item, bins):
    """Best-fit with a small tie-break bias.

    Score each bin so that the item is placed into the tightest feasible bin.
    A small bonus is added when the placement leaves exactly 0 remaining
    capacity, and a tiny penalty is applied when placing into a completely
    empty bin while non-empty alternatives exist.
    """
    # Primary: tighter fit (smaller resulting remainder) gets higher score.
    # Since the item goes to the highest score, use negative remainder.
    score = -(bins - item)

    # Small bonus for exactly filling a bin (remainder 0) to encourage perfect packing.
    score = score + 0.01 * (bins == item)

    # Slight penalty for using a completely empty bin when other bins are available,
    # to avoid opening new bins unnecessarily.
    score = score - 0.001 * (bins == 100)

    return score
