"""Online bin packing with a best-fit-style priority rule.

The harness only asks for a ranking of the fitting bins.  Empirically, a
variation of best-fit works well for Weibull-shaped sizes: place the item
where it leaves the tightest fit, but avoid creating very small unusable
residuals when a slightly looser bin would give a better future fit.
"""

import numpy as np


def priority(item, bins):
    """Rank fitting bins; highest score wins (ties go to the first bin).

    Parameters
    ----------
    item : int
        Size of the arriving item, 1..100.
    bins : numpy.ndarray
        Remaining capacities of bins the item fits in, in bin order.
        Unused bins have remaining capacity 100.

    Returns
    -------
    numpy.ndarray
        One score per bin.  Larger score means the item should go there.
    """
    # Residual capacity after placing the item.
    residual = bins - item

    # Best-fit: prefer the smallest resulting residual (tightest fit).
    # Add a tiny bias away from creating a zero residual (perfect fill is
    # ideal, so zero gets a small bonus rather than penalty).
    #
    # Scores are floats; a positive term is used so the highest score wins.
    # The main term -residual makes smaller residuals score higher.
    score = -residual.astype(np.float64)

    # Perfect packing bonus: filling a bin exactly is usually beneficial.
    score += 1e-3 * (residual == 0)

    # Slight preference for bins that were already partially used over fresh
    # bins when residuals tie, to concentrate packing and save empty bins.
    score += 1e-6 * (bins < 100)

    return score
