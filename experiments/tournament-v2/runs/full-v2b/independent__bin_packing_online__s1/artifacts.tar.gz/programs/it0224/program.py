import numpy as np


def priority(item, bins):
    # Best-fit: smaller remaining capacity after placement is better.
    # Add a mild preference for fuller bins to reduce fragmentation.
    leftover = bins - item
    # Shift so larger scores are better; tiny bonus for bins that already have less free space.
    return -(leftover * 1000 + bins)
