import numpy as np


def priority(item, bins):
    """Best-fit with a mild consolidation bias.

    Highest score goes to the bin with the smallest remaining capacity after
    placing the item, i.e. the tightest fit. Bins that are still completely
    empty (remaining capacity 100) get a slight penalty so that partially
    filled bins are preferred and fewer bins are opened.
    """
    rem = bins.astype(np.int64, copy=False)
    leftover = rem - item

    # Tightest fit has smallest leftover >= 0, so score by -leftover.
    score = -leftover.astype(np.float64)

    # Penalize completely empty bins a little (rem == 100 means unused).
    score[rem == 100] -= 1e-3

    return score
