import numpy as np

class _State:
    def __init__(self):
        # Running stats for observed items
        self.n = 0
        self.sum = 0.0
        self.sumsq = 0.0

_state = _State()


def priority(item, bins):
    """
    Online bin-choice rule.

    Strategy:
      - Best-fit (tightest fit) is generally strong for online packing.
      - To avoid leaving small unusable gaps, we add a mild bias that prefers
        bins whose leftover after placing would be either 0 or reasonably large,
        rather than tiny fragments.
      - A learned mean item size adapts the fragment-avoidance threshold.

    Returns a score per bin; highest score wins (ties -> first bin).
    """
    b = np.asarray(bins, dtype=np.int64)

    # Update running mean estimate of item size (cheap, O(1))
    _state.n += 1
    _state.sum += item
    _state.sumsq += item * item
    mean = _state.sum / _state.n if _state.n else 40.0

    leftover = b - item  # remaining capacity if item placed (>=0 because bins shown all fit)

    # Base score: prefer tightest fit -> smaller leftover is better.
    # Use negative leftover so higher is better.
    score = -leftover.astype(np.float64)

    # Fragment avoidance: penalize leftovers that are small but nonzero,
    # since they tend to become unusable "dust". The penalty grows for
    # leftovers in (0, threshold), threshold scaled to typical item size.
    # Tiny (0) leftover is perfect: no penalty.
    thr = max(6.0, 0.28 * mean)
    # smooth penalty: peak near half threshold, zero at 0 and at/above threshold
    lf = leftover.astype(np.float64)
    # penalty = 1 - (|lf - thr/2| / (thr/2)) clamped, only for 0 < lf < thr
    pen = np.zeros_like(lf)
    mask = (lf > 0) & (lf < thr)
    if np.any(mask):
        center = thr * 0.5
        pen[mask] = 1.0 - np.abs(lf[mask] - center) / center

    # Weight of penalty. Moderate so best-fit still dominates close calls.
    score -= 1.6 * pen

    # Faint preference for exact fits to slightly break ties toward full bins.
    score += 0.35 * (leftover == 0).astype(np.float64)

    # Very small deterministic tie-breaker by original bin order handled by
    # argmax first-tie semantics; nothing needed here.

    return score
