import numpy as np


def priority(item, bins):
    """Best-fit with slight preference for already-used bins.

    Score = (remaining after placing) + small penalty for unused bins.
    The item goes to the bin with the highest score (first on ties).
    """
    # Remaining capacity after placing the item (negative values = tighter fit).
    residual = bins - item

    # Prefer bins that are not empty (remaining 100). Empty bins get a small
    # penalty so we only open a new bin when it is clearly the best fit.
    # This reduces the number of bins opened in practice without hurting
    # packing quality much.
    unused_penalty = np.where(bins == 100, 0.5, 0.0)

    # Higher score = better. Best fit means smallest residual after placing,
    # i.e. maximize -(residual). Subtract penalty for unused bins.
    score = -(residual.astype(np.float64)) - unused_penalty
    return score
