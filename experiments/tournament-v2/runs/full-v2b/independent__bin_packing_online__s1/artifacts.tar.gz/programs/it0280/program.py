import numpy as np

# Global state for online statistics
_state = {
    "sum_items": 0.0,
    "count": 0,
    "mean": 40.0,
}

def priority(item, bins):
    """
    Bin-choice rule for online bin packing with capacity 100.

    Strategy: modified best fit.
      - Prefer bins where placing the item leaves small remaining space (tight fit).
      - Add a tiny bias against leaving very large remainders empty (100), to avoid
        wasting fresh bins on large items if a tight fit exists.
      - Track running mean of items to slightly adjust preferences adaptively.

    item: integer size 1..100
    bins: np.int64 array of remaining capacities (only bins that fit item)
    return: np.array same length with scores; highest score selected.
    """
    global _state

    # Update online mean estimate (used for adaptive tie-breaking subtlety)
    _state["sum_items"] += float(item)
    _state["count"] += 1
    if _state["count"] > 0:
        _state["mean"] = _state["sum_items"] / _state["count"]

    n = len(bins)
    if n == 0:
        return np.array([], dtype=np.float64)

    b = bins.astype(np.float64)

    # After placing item, remaining capacity:
    rem = b - float(item)

    # Base score: best fit => smaller remaining is better.
    # Use negative remaining so highest score wins.
    score = -rem

    # Penalize using a completely empty bin (rem == 100 - item) when there are
    # alternatives, because that wastes a fresh bin. Small penalty only.
    fresh_mask = (b == 100.0)
    score -= fresh_mask.astype(np.float64) * 0.05

    # Slight preference for exact or near-exact fill: bonus for rem close to 0
    # (already captured by -rem, but make it superlinear for very tight fits).
    # Add small extra reward when rem == 0
    score += (rem == 0.0).astype(np.float64) * 0.01

    # Tie-breaking: stable by bin index (first wins ties). numpy argmax handles that.
    return score
