"""Best-fit with a slight full-bin bias for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: best fit -> smallest remaining capacity after placement.
    # Equivalent to smallest current remaining capacity (since item is constant).
    # Add a tiny bonus for bins that would become very full, to encourage closing them.
    remaining_after = bins - item
    score = -remaining_after.astype(np.float64)

    # Small bonus for tight fits: prefer bins that become nearly full.
    # This is monotone with best-fit but slightly strengthens the preference
    # for low remaining capacity when there are near-ties.
    score += 1e-3 * (100.0 - bins.astype(np.float64))

    return score
