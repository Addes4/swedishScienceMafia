"""Online bin packing: score bins by expected future usability.

The rule is a blend of best-fit and a residual-target heuristic:
- Placing an item into a bin with residual r leaves r - item.
- Small residuals are good (tight packing), but extremely small residuals
  often become unusable waste.
- We maintain an online estimate of the item-size distribution (histogram
  smoothed by recent arrivals) and reward leaving a residual that matches
  a likely future item size, i.e. residuals that can be filled exactly or
  nearly exactly later.

This is computed vectorized over all candidate bins each call.
"""

import numpy as np

# ------------------------- helper state -------------------------

_cap = 100
_hist = np.ones(_cap + 1, dtype=np.float64)  # Laplace-ish prior over sizes 1..100
_hist_count = 0
_recent = np.zeros(_cap + 1, dtype=np.float64)
_recent_count = 0

# Weighting between pure best-fit tightness and future-target reward.
_ALPHA = 0.55


def priority(item, bins):
    """Return a score per bin; item goes to the highest scoring (first on ties).

    item: int, 1..100
    bins: np.int64 array of remaining capacities of fitting bins
    """
    global _hist, _hist_count, _recent, _recent_count

    bins = np.asarray(bins)
    n = bins.shape[0]

    # Update online size statistics (learning the distribution over time).
    if 1 <= item <= _cap:
        _recent[item] += 1.0
        _recent_count += 1
        if _recent_count >= 64:
            _hist = _hist * 0.9 + _recent * 0.1
            _hist_count += 1
            _recent.fill(0.0)
            _recent_count = 0

    # Residual capacity after placing the item.
    resid = bins - item
    # All bins passed in fit the item, but be defensive.
    resid = np.where(resid < 0, 0, resid)

    # --- component 1: best-fit tightness (smaller residual is better) ---
    # Normalize residual into [0,1]; closer to 0 => higher tightness.
    tight = 1.0 - resid.astype(np.float64) / _cap

    # --- component 2: future-fit reward ---
    # Probability mass of future items that could exactly/ nearly fill resid.
    # Reward residuals that are "common sizes" or that leave a commonly
    # reachable remainder. We use a smoothed histogram lookup.
    hist = _hist
    hist = hist / hist.sum()

    # For each bin, reward = hist mass at exactly resid, plus nearby mass
    # (within a small tolerance), encouraging residuals that future items
    # can fill tightly.
    r = resid.astype(np.int64)
    r = np.clip(r, 0, _cap)

    # exact-match reward
    exact = hist[r]

    # near-match reward: mass of sizes within +/- 3 of residual
    near = np.zeros(n, dtype=np.float64)
    for d in range(1, 4):
        lo = np.clip(r - d, 0, _cap)
        hi = np.clip(r + d, 0, _cap)
        near += hist[lo] + hist[hi]
    near *= 0.5

    # Penalize leaving tiny residuals (likely wasted space) modestly,
    # but not so much that we avoid tight fits entirely.
    tiny_penalty = np.where((r > 0) & (r < 5), 0.15 * (5 - r) / 5.0, 0.0)

    future = exact + near - tiny_penalty

    # --- combine ---
    score = _ALPHA * tight + (1.0 - _ALPHA) * future

    # Slight preference for fuller bins (lower residual) as tie-breaker,
    # encoded by subtracting a tiny fraction of residual.
    score = score - 1e-6 * resid.astype(np.float64)

    return score
