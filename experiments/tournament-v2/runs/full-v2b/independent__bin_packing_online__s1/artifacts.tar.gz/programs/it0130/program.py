"""Adaptive best-fit for online bin packing.

Core idea: choose the bin whose remaining capacity after placing the item is
smallest (best fit), but add a light bonus for leaving a *usable* residual gap
and a small penalty for producing tiny unusable slivers.  A running estimate of
the observed item-size distribution lets us set the "gap" thresholds online.
"""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0
        self.counts = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.n += 1
        d = item - self.mean
        self.mean += d / self.n
        self.m2 += d * (item - self.mean)
        self.counts[item] += 1.0

    def std(self):
        if self.n < 2:
            return 20.0
        return max(1.0, (self.m2 / (self.n - 1)) ** 0.5)


_s = _State()


def priority(item, bins):
    global _s
    _s.update(item)

    cap = bins.astype(np.float64)
    residual = cap - float(item)

    # Base: best fit -> smallest residual gets highest score.
    score = -residual

    # Running scale of item sizes (used to judge "small" gaps).
    sigma = _s.std()
    tiny = max(1.0, min(6.0, 0.25 * sigma))

    # Penalise residuals that are too small to ever hold a typical item,
    # and give a modest bonus to residuals near the item size (good
    # complementary fit), which tends to keep free space consolidated.
    small_mask = residual < tiny
    score = score - 1.5 * small_mask * (tiny - residual)

    # Slight preference for bins whose residual can still accept at least
    # one average-sized item when the item itself is on the small side.
    if item < _s.mean:
        avg = _s.mean
        good = residual >= avg
        score = score + 0.6 * good

    # Prefer exactly-full placements strongly.
    exact = residual <= 0.0
    score = score + 5.0 * exact

    return score
