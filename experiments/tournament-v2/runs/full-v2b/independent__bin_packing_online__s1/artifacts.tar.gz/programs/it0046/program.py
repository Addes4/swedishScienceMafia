import numpy as np

# State across calls (per-instance, but harmless if shared since distribution is fixed)
_state = {
    "calls": 0,
    "sum_item": 0.0,
    "sum_sq": 0.0,
}

# Parameters tuned for Weibull-shaped, mean ~40, integer 1..100, cap=100
# We use a size-dependent blend between best-fit and a target residual.
# For small items, prioritize filling tightly (best-fit). For large items,
# avoid leaving unusable fragments to preserve flexibility.

def priority(item, bins):
    global _state
    _state["calls"] += 1
    _state["sum_item"] += item
    _state["sum_sq"] += item * item

    n = bins.shape[0]
    residual = bins - item  # remaining capacity if placed here

    # For bins where item doesn't fit, bins array only shows fitting bins,
    # but be safe: mark non-fitting with very low score.
    fits = bins >= item

    # Size-dependent target residual: smaller items can tolerate smaller residual
    # (tighter packing), larger items benefit from leaving balanced room.
    # target ~ item * alpha + beta, clamped
    alpha = 0.35
    beta = 4.0
    target = alpha * item + beta
    # Cap target to avoid absurd values
    if target > 60.0:
        target = 60.0

    # Score: prefer residual close to target, but also prefer larger residual
    # when bins are nearly full to avoid wasting capacity.
    # Use negative abs deviation from target; unused bins (residual 100-item)
    # naturally have high residual and get moderate score.

    # Primary term: closeness to target residual
    dev = np.abs(residual - target).astype(np.float64)

    # Secondary: slight preference for fuller bins (lower residual) to pack
    # efficiently, but only when residual is already below target.
    # This encourages filling tight bins first.

    # Combine: score = -dev * w1 + fill_bonus
    # fill_bonus favors bins with residual <= target (i.e., fuller bins)
    fill_bonus = np.where(residual <= target, 1.0, 0.0)

    # Also heavily prefer bins that are "used" (residual < 100 - item? no)
    # Unused bins have bins == 100. We don't want to open new bins unless
    # necessary. Penalize unused bins slightly.
    unused = bins == 100
    unused_penalty = np.where(unused, -2.0, 0.0)

    score = -dev + 2.0 * fill_bonus + unused_penalty

    # If no bin fits (shouldn't happen since unused bins included with cap 100),
    # fall back to best-fit.
    if not np.any(fits):
        return -(bins - item)

    # Non-fitting bins get low score
    score = np.where(fits, score, -1e9)

    return score
