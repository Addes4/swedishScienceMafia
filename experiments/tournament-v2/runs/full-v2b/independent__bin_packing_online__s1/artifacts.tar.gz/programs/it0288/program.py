import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "small_count": 0,
    "threshold": 40.0,
}


def priority(item, bins):
    """Best-fit-like rule with adaptive threshold favoring small usable residuals."""
    global _state

    # Update light-weight online statistics (mean estimate for threshold adaptation).
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    # Threshold tracks roughly half the mean: bins with residual below this are
    # considered "tight but usable" and are preferred strongly.
    threshold = 0.5 * mean_item
    _state["threshold"] = 0.85 * _state["threshold"] + 0.15 * threshold

    residual = bins - item  # remaining capacity if item placed here; >= 0 guaranteed

    # Empty bins (residual == 100 - item) should be a last resort.
    unused = (residual >= 100 - item).astype(np.float64)

    # Base: prefer smaller residual (best fit).
    score = -residual.astype(np.float64)

    # Bonus for mid-range residuals: avoid both tiny unusable fragments and large waste.
    # A residual close to the threshold is attractive because it packs tightly yet
    # still leaves room for typical future small items.
    t = _state["threshold"]
    # Gaussian-like bonus centered at threshold, wider for larger items.
    width = max(5.0, 0.35 * item)
    bonus = 8.0 * np.exp(-0.5 * ((residual - t) / width) ** 2)
    score += bonus

    # Penalize creating bins with very small residuals (< ~10) slightly less than
    # wasting space, but still discourage fragments that can only take tiny items.
    tiny = (residual < max(3.0, 0.15 * item)).astype(np.float64)
    score -= 3.0 * tiny

    # Strongly discourage opening unused bins unless no reasonable option exists.
    score -= 25.0 * unused

    # Tiny deterministic perturbation by bin index to stabilize ties consistently
    # in favor of earlier bins (already default, but makes intent explicit).
    score += np.arange(len(bins), dtype=np.float64) * -1e-9

    return score
