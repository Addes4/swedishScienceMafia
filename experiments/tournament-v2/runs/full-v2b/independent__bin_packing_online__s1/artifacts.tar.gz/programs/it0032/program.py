import numpy as np


def priority(item, bins):
    # Best-fit score: prefer bins with remaining capacity just above item size.
    # Add a small penalty for completely empty bins so we don't open new bins
    # unless needed, which improves online packing efficiency.
    # bins is a numpy int64 array of remaining capacities.
    # The item must fit: bins >= item. (Harness probably filters, but be safe.)

    # Compute tightness: smaller remaining capacity after placing item is better.
    # Equivalent to minimizing (bins - item), so score = -(bins - item).
    # Additionally, penalize empty bins slightly.
    waste = bins - item  # non-negative for fitting bins

    # Penalty for empty bins (remaining capacity exactly 100).
    # A small penalty discourages opening new bins when a non-empty option exists.
    empty_penalty = (bins == 100).astype(np.float64) * 1e-3

    # Primary: minimize waste. Secondary: avoid empty bins.
    return -waste.astype(np.float64) - empty_penalty
