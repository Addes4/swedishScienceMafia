"""Adaptive best-fit with reserve scoring."""

import numpy as np


class _State:
    """Track online statistics about item sizes and bin usage."""
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.sum_sq = 0.0
        self.bins_seen = 0
        self.used = 0
        self.large_threshold = 60.0
        self.n_large = 0.0

    def update(self, item, bins):
        x = float(item)
        self.n += 1
        self.sum += x
        self.sum_sq += x * x
        self.bins_seen = max(self.bins_seen, int(bins.size))
        if x >= self.large_threshold:
            self.n_large += 1.0

    def mean(self):
        if self.n == 0:
            return 40.0
        return self.sum / self.n

    def sd(self):
        if self.n < 2:
            return 25.0
        m = self.mean()
        var = max(0.0, self.sum_sq / self.n - m * m)
        return float(np.sqrt(var))


_S = _State()


def priority(item, bins):
    """Score bins using best-fit plus a small reserve for future large items."""
    _S.update(item, bins)

    b = np.asarray(bins, dtype=np.int64)
    x = int(item)

    # Base: best fit. Prefer bins where the residual after placing is small.
    residual = b - x
    base = -residual.astype(np.float64)

    # Online estimate of typical item size.
    mean_item = _S.mean()
    sd_item = _S.sd()

    # Target residual: keep some bins near a useful fill level so that
    # medium/large future items can still be placed without opening a new bin.
    target_residual = max(0.0, 0.5 * mean_item - 0.15 * sd_item)
    if target_residual > 35.0:
        target_residual = 35.0

    # Prefer bins whose remaining capacity after placement is close to target.
    # This is a gentle tie-breaker on top of best-fit.
    score = base - 0.02 * np.abs(residual - target_residual)

    # If the item is large, avoid leaving awkward small residual gaps in bins
    # that could otherwise accept another medium item later.
    if x >= _S.large_threshold:
        # penalize residuals that are nonzero but too small for a typical item
        gap = residual.astype(np.float64)
        awkward = np.where((gap > 0) & (gap < 0.5 * mean_item), 1.0, 0.0)
        score -= 0.005 * awkward

    # Strongly favor opened bins over completely empty bins only when the fit is
    # reasonable; this keeps bin count lower.
    near_full = residual <= max(0, int(0.25 * mean_item))
    score += 0.001 * near_full.astype(np.float64)

    # Ties go to the first bin; add a tiny index-based decay so that newer unused
    # bins are slightly less attractive, preserving room in older vacant bins.
    idx = np.arange(b.size, dtype=np.float64)
    score -= 1e-9 * idx

    return score
