import numpy as np


def priority(item, bins):
    """Rank bins by how tightly the item fits.

    Primary rule: best fit (smallest remaining capacity that still fits).
    Small tie-breaking bonus for bins that become nearly full.
    """
    remaining = bins - item
    # Lower remaining capacity is better.
    score = -remaining

    # Slightly favor bins that become almost completely full.
    score += (remaining == 0) * 1e-6
    score += (remaining == 1) * 1e-7

    return score
