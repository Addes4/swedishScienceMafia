import numpy as np


def priority(item, bins):
    """Best fit with an adaptive bias against opening new bins too early.

    Bins with smaller remaining capacity after insertion get higher priority.
    When several bins tie in residual capacity, prefer the one that is already
    used (smaller remaining capacity before insertion) to avoid wasting empty bins.
    """
    # Residual capacity if the item is placed here.
    residual = bins - item

    # Best fit score: maximize by taking negative residual.
    # Add a small secondary preference for more-filled bins, scaled to stay
    # below one capacity unit so it only breaks ties in residual.
    used = 100 - bins  # larger for bins that are already more filled
    return -(residual) + used / 1000.0
