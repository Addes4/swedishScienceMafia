"""Improved online bin packing rule.

The main scoring idea is to avoid wasting a nearly-empty bin on a small item
while still packing tightly when possible.  Pure best fit sometimes opens many
nearly-full bins and then has trouble with later large items.  A mild penalty
on very large remaining capacities encourages using already-started bins.

This rule is deterministic, only depends on the current item and visible bins,
and keeps no state, so it generalises to unseen instances from the distribution.
"""

import numpy as np


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.int64)

    # A bin is "usable" exactly when it fits, but be defensive.
    # Score is higher for bins that fit the item more tightly.
    residual = bins - item

    # Main term: best fit.  Smaller residual => higher score.
    score = -residual.astype(np.float64)

    # Mild penalty for opening a completely unused bin for a smallish item.
    # This reserves capacity-100 bins for larger arrivals and reduces the number
    # of bins that end up partially filled and unusable for medium/large items.
    # The penalty is small enough not to dominate genuine tight-fit choices.
    unused = bins == 100
    if item < 80:
        score = score - 0.15 * unused.astype(np.float64)

    # For very small items, add a slightly stronger preference for non-empty bins,
    # because small items are the ones most likely to fit later almost anywhere.
    if item <= 20:
        nonempty = bins < 100
        score = score + 0.20 * nonempty.astype(np.float64)

    # Extremely large items should not distort bin choices: use essentially best fit.
    return score
