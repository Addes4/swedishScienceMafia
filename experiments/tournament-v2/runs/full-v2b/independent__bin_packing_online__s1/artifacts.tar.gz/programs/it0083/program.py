"""Best-fit with tie-breaking heuristics for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`.

    Strategy: mainly best-fit (tightest remaining capacity >= item).  We add
    small tie-breaking nudges:
      * Prefer bins whose residual after placing becomes very small (waste
        reduction / almost-full bonus).
      * Slightly prefer unused bins (capacity == 100) so that already-opened
        bins stay available for medium items, but only mildly so.
    """
    # Best fit score: smaller residual after placement is better.
    residual = bins - item

    # Primary term: tighter fit is better -> negative residual (larger is better).
    score = -residual.astype(np.float64)

    # Bonus for leaving a bin almost perfectly full (residual small) - emphasizes
    # completing bins to reduce the number of open bins.
    score += 0.5 / (residual.astype(np.float64) + 1.0)

    # Mild preference for unused bins so we don't prematurely fragment bins that
    # are already partly used, unless the fit is much tighter elsewhere.
    unused = (bins == 100).astype(np.float64)
    score += 0.01 * unused

    return score
