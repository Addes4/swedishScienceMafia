import numpy as np


def priority(item, bins):
    """Hybrid online bin packing priority.

    The item goes to the highest score, ties go to the first bin.

    Strategy:
    - Prefer tight fits in already-used bins (best-fit).
    - Avoid opening new bins for small/medium items when possible.
    - For very large items, favor near-exact fits.
    - Add a small bonus to bins whose residual after placement is in a
      "useful" range, reducing fragmentation.
    """
    residual = bins - item

    # Base: negative residual => tighter fit is better.
    score = -residual.astype(np.float64)

    used = bins < 100
    unused = ~used

    # Strongly discourage putting small items into fresh bins.
    # This reduces bin count when many small items arrive.
    if item <= 20:
        score[unused] -= 150.0
    elif item <= 40:
        score[unused] -= 80.0
    elif item <= 60:
        score[unused] -= 30.0
    else:
        score[unused] += 5.0

    # Mildly prefer used bins over unused, all else equal.
    score[used] += 2.0

    # Penalize leaving a bin almost empty if the item is small,
    # because such residual may be hard to use later.
    # Bonus for residuals that are likely useful for mean ~40 distribution.
    useful = (residual >= 20) & (residual <= 60)
    score[useful] += 1.0

    # Very large items: prioritize near-exact fit more aggressively.
    if item >= 80:
        score += np.where(residual >= 0, 5.0 / (1.0 + residual), -10.0)

    return score
