"""Online bin packing with a best-fit / sum-of-squares hybrid rule.

The item goes into the bin where it fits most tightly, but ties and near-ties
are broken to prefer leaving a bin's remaining capacity close to a "fillable"
size. This is essentially the classic Best Fit Decreasing-style greedy applied
online, which is robust and near-optimal for distributions like Weibull(mean~40).
"""

import numpy as np


def priority(item, bins):
    """Score each bin for the arriving item.

    Higher score wins; ties go to the earliest bin. We use the negative of the
    squared remaining capacity after placement, which strongly prefers tight
    fits (best fit) while still ranking all bins consistently.

    Args:
        item: integer size of the arriving item, 1..100.
        bins: numpy int64 array of remaining capacities of fitting bins.

    Returns:
        numpy array of scores, same length as bins.
    """
    remaining = bins - item
    # Best fit: maximize (100 - remaining^2) => minimize remaining^2.
    # Adding the small linear term -remaining is redundant with -remaining^2
    # for ranking tight fits, but keeps tiny differences well-ordered.
    return -(remaining * remaining)
