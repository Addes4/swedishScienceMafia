import numpy as np

# Precompute a "usefulness"/"awkwardness" score for each possible residual capacity.
# The goal: after placing the item, the leftover capacity should ideally be either
# very small (waste) or a size that future items are likely to exactly/ nearly fill.
# We approximate this by considering the item distribution.
#
# We use a simple heuristic table tuned to typical Weibull-shaped distributions with mean ~40:
# - residuals that are common item sizes are good (easy to fill later) -> lower priority
# - residuals that are rare/awkward are bad (hard to fill) -> higher priority to avoid creating them
#
# But also best-fit tight packing primarily by residual, then use awkwardness as tiebreak.

# Build an approximate item size distribution: Weibull with mean 40, clipped to [1,100].
# k=2 (Rayleigh-like) gives mean = scale * sqrt(pi)/2 => scale ~ 45.1 for mean 40.
# We'll just use a discrete approximation over integers 1..100.

_rng_cache = None

def _build_pmf():
    # Approximate Weibull(shape=2, scale chosen so mean=40) over 1..100
    scale = 40.0 / 0.886226925452758  # sqrt(pi)/2
    # Weibull CDF: 1 - exp(-(x/scale)^k), k=2
    xs = np.arange(0, 102, dtype=float)
    cdf = 1.0 - np.exp(-(xs / scale) ** 2.0)
    pmf = np.diff(cdf)  # pmf for sizes 1..101
    pmf = pmf[:100]
    pmf = np.clip(pmf, 1e-12, None)
    pmf /= pmf.sum()
    return pmf

_PMF = _build_pmf()

def _awkwardness_table():
    # For each residual r in 0..100, estimate how hard it is to fill exactly
    # in the future: probability that some combination of future items sums to r is complex.
    # Simpler proxy: probability that an item fits exactly (or near) residual.
    # We want residual that is a common item size (easy to fill) => low awkwardness.
    # residual near 0 => fine (bin is essentially full).
    # residual large => many chances to fill, so not too awkward.
    # Mid-range residuals that are uncommon sizes are awkward.
    awkward = np.zeros(101, dtype=float)
    for r in range(101):
        if r == 0:
            awkward[r] = 0.0
            continue
        # Exact fit probability
        p_exact = _PMF[r-1] if 1 <= r <= 100 else 0.0
        # Near fit: items within 5 of residual
        lo = max(0, r-6)
        hi = min(100, r+5)
        p_near = _PMF[lo:hi].sum() if hi > lo else 0.0
        # Awkwardness: high if exact fit improbable AND near fit not large
        # Also residual small is generally good (less wasted space)
        # Scale awkwardness inversely with how fillable it is.
        # Use log to compress.
        fillable = p_exact * 3.0 + p_near * 0.5 + (1.0 if r <= 5 else 0.0)
        awkward[r] = 1.0 / (1.0 + fillable * 20.0)
    return awkward

_AWKWARD = _awkwardness_table()

# State: track average item size seen so far (adaptive)
_state = {"sum": 0.0, "count": 0}

def priority(item, bins):
    # Best fit: prefer bin where item fits most tightly (smallest residual after placement)
    residual = bins - item  # >= 0 for bins item fits in (all shown bins fit by contract)
    # Primary: smaller residual is better -> negate
    # Secondary: avoid creating awkward residuals; but only as a tiebreak with small weight.
    # We combine: score = -residual * BIG - awkward_weight * awkward[residual]
    # BIG ensures best-fit dominates.
    aw = _AWKWARD[np.clip(residual, 0, 100)]
    score = -residual.astype(float) * 1000.0 - aw * 1.0

    # Adaptive: if average item size is large, prefer even tighter fits (already handled)
    # Update state
    _state["sum"] += item
    _state["count"] += 1

    return score
