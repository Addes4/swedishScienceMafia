import numpy as np


def priority(item, bins):
    """Best-fit with a gentle fragmentation penalty.

    Put the item where it leaves the smallest residue, but slightly de-prioritize
    bins that would end with a very small leftover (to keep tiny gaps from being
    created too early). Ties go to the earlier bin because scores are strictly
    ordered by residual, then residual-vs-threshold.
    """
    residual = bins - item

    # Base: strongly prefer small residual (classic best fit).
    score = -residual.astype(np.float64)

    # Mild penalty for making a bin almost full but not quite:
    # residuals in 1..3 are slightly worse than residuals of 0 or larger gaps.
    tiny = (residual > 0) & (residual <= 3)
    score[tiny] -= 0.25 * residual[tiny]

    return score
