import numpy as np


class _Policy:
    def __init__(self):
        self.count = 0
        self.sum_sizes = 0.0
        self.sum_sq = 0.0
        self.lam = 0.015

    def update(self, item):
        self.count += 1
        self.sum_sizes += item
        self.sum_sq += item * item

        n = self.count
        mean = self.sum_sizes / n
        var = max(0.0, self.sum_sq / n - mean * mean)
        # Smaller items benefit slightly more from residual smoothing;
        # large fill values are much more important near full bins.
        target = 0.013 + 0.0000015 * var
        self.lam += (target - self.lam) * 0.002


_policy = _Policy()


def priority(item, bins):
    """Exact fit first, otherwise penalize wasted space with an adaptive coefficient."""
    _policy.update(item)

    # bins is an int64 array of remaining capacities.
    # Score: very large bonus for zero residual, then closeness to exactly filling.
    residual = bins - item
    score = -1000000.0 * residual

    # Extra preference for bins that become nearly full, controlled by adaptive lambda.
    near = bins - item
    score += _policy.lam * np.where(near < 0, 0.0, (100 - near).astype(np.float64) ** 2)

    # Prefer the fuller bin when residuals are equal, but keep exact-fit dominance.
    score += -0.001 * bins
    return score
