"""Best-fit with slight preference for fuller bins to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Score bins so the item goes into the tightest fit, preferring fuller bins on ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    residual = bins - item
    # primary: smallest residual; secondary: smaller remaining capacity (fuller bin)
    return -(residual.astype(np.float64) + 1e-3 * bins)
