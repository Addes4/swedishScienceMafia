"""Online bin packing: adaptive best fit with freshness preference."""

import numpy as np

# Tunable parameters
ALPHA = 0.85        # weight on immediate fit quality
BETA = 0.10         # weight on residual capacity preference (lower residual better)
GAMMA = 0.05        # weight on freshness (higher remaining capacity gets bonus)
TARGET_FILL = 70    # ideal remaining capacity after placing (smaller -> tighter)
STATE = {"calls": 0, "sum_item": 0}


def priority(item, bins):
    """Return a priority score for every bin.

    Strategy:
      - Prefer bins where placing the item leaves a small residual (best fit).
      - Slightly prefer bins whose resulting remaining capacity is close to a target
        derived from the observed mean item size, to reduce fragmentation.
      - Slightly prefer fuller bins (already used) over empty ones to consolidate.
    """
    global STATE
    STATE["calls"] += 1
    STATE["sum_item"] += item
    n = STATE["calls"]
    mean_item = STATE["sum_item"] / n if n else 40.0

    # Target remaining capacity after placement (tuned to distribution mean)
    target_rem = max(0.0, min(100.0, 100.0 - mean_item))

    # Resulting remaining capacities
    new_rem = bins - item

    # Components
    # 1) best fit: prefer small new_rem (more negative new_rem => higher score)
    fit_score = -(new_rem.astype(np.float64))

    # 2) closeness to target residual: penalize deviation
    dev = np.abs(new_rem.astype(np.float64) - target_rem)
    target_score = -dev

    # 3) freshness: prefer bins with lower remaining capacity (already used) slightly
    #    i.e., smaller bins value => higher score
    freshness_score = -(bins.astype(np.float64))

    # Combine
    score = ALPHA * fit_score + BETA * target_score + GAMMA * freshness_score

    # Tiny deterministic tie-breaker: prefer earlier bins
    # (since ties go to first, we don't need explicit ordering bonus)

    return score
