import numpy as np


def priority(item, bins):
    # Best-fit: prefer the bin with the smallest remaining capacity that still fits.
    # Largest remaining capacity among those (i.e. tightly fitting) gets highest score.
    # Empty/full-capacity bins are mildly de-prioritized so we don't open new bins early.
    remaining_after = bins - item
    score = -remaining_after.astype(np.float64)

    # De-prioritize untouched bins slightly: using an existing partially-filled bin
    # tends to pack better than opening a new one, especially for mean ~40 items.
    empty = bins == 100
    score[empty] -= 1e-6

    return score
