import numpy as np


def priority(item, bins):
    """Rank bins for online bin packing.

    Strategy:
    - Strongly prefer non-empty bins that fit tightly (best fit among used bins).
    - Avoid placing into completely empty bins unless no used bin fits.
    - Among used bins, slightly prefer leftover capacities that are unlikely to be
      wasted, using a soft penalty around small leftovers that are hard to fill.
    """
    rem = bins.astype(np.float64)
    empty = (rem == 100.0)

    # Best-fit residual: smaller residual -> better.
    residual = rem - float(item)

    # Penalize using empty bins so they remain available for future larger items.
    # The penalty must be large enough to dominate ordinary residual differences
    # when any used bin is available, but not so large as to make scoring unstable.
    score = -residual

    # Mildly penalize leftovers that are very small, because such bins are
    # typically hard to reuse well; prefer slightly larger leftovers.
    leftover = residual
    small_penalty = np.where(leftover < 12.0, (12.0 - leftover) * 0.2, 0.0)
    score -= small_penalty

    # Avoid opening new bins unless necessary.
    score[empty] -= 1000.0

    return score
