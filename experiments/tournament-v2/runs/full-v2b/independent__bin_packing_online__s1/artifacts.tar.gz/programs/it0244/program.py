"""Online bin packing with a best-fit bin-choice rule."""
import numpy as np


def priority(item, bins):
    """Score bins by best-fit: prefer the tightest remaining capacity that fits.

    The item goes to the highest-scoring bin; ties go to the first bin.
    Unused bins (capacity 100) are preferred only when no used bin can fit,
    which best-fit handles naturally since fit is always checked.
    """
    # Best fit: smallest remaining capacity that still fits.  Negate so that
    # the highest score corresponds to the tightest fit.
    return -(bins - item)
