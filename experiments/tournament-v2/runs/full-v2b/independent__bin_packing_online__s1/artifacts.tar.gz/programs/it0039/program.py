import numpy as np


def priority(item, bins):
    """Priority rule for online bin packing.

    Main idea: choose the tightest fitting non-empty bin when possible,
    but when the item is large, prefer opening an empty bin over
    fragmenting a nearly-full bin.
    """
    # bins: remaining capacities of bins that fit the item
    # Lower remaining capacity after placing means tighter fit:
    # score = -(remaining - item) = item - remaining
    score = item - bins

    # Penalize using an empty bin unless it's really beneficial.
    # Empty bins have remaining capacity 100.
    # For large items, using an empty bin is often good because
    # they won't fit well with others.
    # For small items, avoid empty bins to pack tightly.

    # Mark empty bins (capacity 100) with a penalty.
    # The penalty grows for smaller items, so small items strongly
    # prefer existing bins, while large items may choose empty bins.
    # Threshold tuned for Weibull mean ~40.
    empty_mask = bins == 100
    if np.any(empty_mask):
        # Penalty magnitude: larger for small items.
        # At item=50 penalty is small; at item=10 penalty is large.
        penalty = 100.0 - 2.0 * item
        # Ensure penalty is non-negative so large items aren't rewarded
        # too aggressively; cap at some value.
        if penalty < 0:
            penalty = 0.0
        score[empty_mask] -= penalty

    return score
