import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.item_sum = 0.0
        self.n = 0


_state = _State()


def priority(item, bins):
    # Update running statistics (used only in a mild, conservative way).
    _state.calls += 1
    _state.n += 1
    _state.item_sum += item

    # bins: remaining capacity of every bin the item fits in (int64), fixed order.
    # The item goes to the highest score; ties -> first bin.

    rem = bins.astype(np.float64)

    # Residual space left after placing the item.
    residual = rem - float(item)

    # Base rule: best fit -- smaller residual (tighter fit) is better.
    # score = -residual  => maximize
    score = -residual

    # Slight bias: prefer bins that still have decent room left when item is large,
    # to preserve ability to place future large items. This is a soft adjustment.
    # For small items, strong best-fit is good.
    # Large items (say >= 50): favor bins with more remaining capacity so that a bin
    # is not left with an unusable tiny sliver.
    if item >= 50:
        # Nudge toward larger remaining capacity among feasible bins.
        score = score + 0.05 * rem

    # Avoid leaving a bin in (0, item) unusable state is already handled by best fit.
    # Mild penalty on wasting nearly-full bins: residual very small is good (tight),
    # residual zero is perfect, so nothing extra needed.

    # Encourage using existing partially-filled bins over opening fresh 100s when
    # the item is small-to-medium, to reduce bin count. Unused bins have rem == 100.
    # Penalize fresh bins slightly unless item is large.
    if item < 50:
        # penalize rem == 100 (fresh) a touch
        fresh = (rem >= 99.5)
        score = score - 0.5 * fresh

    # For large items, slightly reward fresh bins (rem==100) since a large item in an
    # almost-full bin may leave an unusable remainder.
    if item >= 70:
        fresh = (rem >= 99.5)
        score = score + 0.5 * fresh

    return score
