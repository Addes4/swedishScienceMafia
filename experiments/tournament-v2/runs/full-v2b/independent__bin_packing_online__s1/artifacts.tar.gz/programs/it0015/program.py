import numpy as np


class _State:
    def __init__(self):
        self.buffer = []
        self.max_buffer = 3

    def add(self, item, bins):
        self.buffer.append(item)
        if len(self.buffer) < self.max_buffer:
            return None
        return self._place_buffered(bins)

    def _place_buffered(self, bins):
        # Choose one item from the buffer to place now, and return its bin choice.
        # Greedy: try each buffered item in each possible bin, pick the one that
        # leaves the best residual pattern for the remaining buffered items.
        best_score = None
        best_choice = None
        n = len(bins)
        if n == 0:
            return None

        for i, item in enumerate(self.buffer):
            others = self.buffer[:i] + self.buffer[i+1:]
            for j in range(n):
                cap = int(bins[j])
                if cap < item:
                    continue
                new_cap = cap - item
                # Score: prefer tight fits, but also reward residual capacities
                # that can accommodate remaining buffered items.
                score = -(new_cap)
                # Bonus for exact fit
                if new_cap == 0:
                    score += 1000
                # Lookahead bonus: count how many remaining items fit in this bin
                fit_count = 0
                rem = new_cap
                for o in sorted(others, reverse=True):
                    if o <= rem:
                        rem -= o
                        fit_count += 1
                score += fit_count * 50
                # Prefer placing larger items first if scores tie
                score += item * 0.01
                if best_score is None or score > best_score:
                    best_score = score
                    best_choice = (i, j)
        if best_choice is None:
            return None
        idx, bin_idx = best_choice
        placed_item = self.buffer.pop(idx)
        # Return a full priority array for the chosen bin
        priorities = np.full(n, -1e18)
        priorities[bin_idx] = 0.0
        return priorities


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins, ties to first."""
    bins = np.asarray(bins)
    n = len(bins)
    if n == 0:
        return bins

    choose = _state.add(int(item), bins)
    if choose is None:
        # Buffer not full yet: use best-fit fallback
        return -(bins - item)

    # If the chosen bin is not among the bins shown, fall back to best fit.
    if np.all(choose < -1e17):
        return -(bins - item)
    return choose
