import numpy as np

def priority(item, bins):
    # Best-fit: maximize remaining capacity difference? Actually minimize leftover.
    # bins are remaining capacities. We want tightest fit -> smallest (bins - item).
    # Score = -(bins - item).
    # Tie-break: prefer smaller index (already default).
    # Additional heuristic: penalize using a completely empty bin (capacity 100)
    # unless necessary, to leave empty bins for future items.
    # But we can't see future, still a common effective tweak: give slightly
    # lower score to bins with remaining capacity == 100 when item is small.
    leftover = bins - item
    scores = -leftover.astype(np.float64)
    # Slight penalty for opening brand-new bins for smallish items
    # (only when there are existing partially-filled bins that also fit).
    if item <= 50:
        # penalize fresh bins a bit
        scores = np.where(bins == 100, scores - 0.5, scores)
    return scores
