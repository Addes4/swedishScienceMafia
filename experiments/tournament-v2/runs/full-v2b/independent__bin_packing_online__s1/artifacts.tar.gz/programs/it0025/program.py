"""Best-fit online bin packing: choose the bin with the least remaining capacity that fits."""
import numpy as np

_used = None
_last_len = None


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (capacity 100), in bin order.
    """
    global _used, _last_len

    n = len(bins)
    if _used is None or _last_len is None or _last_len != n:
        if _used is not None and _last_len is not None and n >= _last_len:
            # extend usage flags for newly opened bins
            pad = np.zeros(n - _last_len, dtype=np.int32)
            _used = np.concatenate([_used, pad])
        else:
            _used = np.zeros(n, dtype=np.int32)
        _last_len = n

    # Best fit: minimize remaining capacity after placement.
    # bins >= item guaranteed by harness (only fitting bins shown).
    # Slightly prefer already-used bins to avoid opening new bins unnecessarily.
    score = -bins.astype(np.float64)

    # tiny bias: used bins get a small bonus, unused get a small penalty
    used_mask = _used > 0
    score = score + np.where(used_mask, 1e-3, 0.0)

    # update state: we don't know chosen bin, but harness picks argmax.
    # Mark the top candidate as used (approximation of chosen bin).
    idx = int(np.argmax(score))
    _used[idx] += 1

    return score
