import numpy as np


def priority(item, bins):
    """Rank bins by a modified best-fit rule with a reserve to preserve flexible capacity."""
    # Remaining capacity after placing the item
    rem = bins - item

    # Base score: prefer tighter fits (fuller bins), i.e. smaller remaining capacity.
    # Use negative remaining so higher score = smaller rem.
    score = -rem.astype(np.float64)

    # Penalize bins that would become very full but not exactly full,
    # because they may be hard to use for future items. Exact fits are ideal.
    # Also mildly penalize completely empty bins to encourage using existing space.
    # The penalty is small so best-fit still dominates.
    penalty = np.zeros_like(score)
    # near-full but not exact: rem in (0, 10]
    mask_near_full = (rem > 0) & (rem <= 10)
    penalty[mask_near_full] = 0.5 * (11 - rem[mask_near_full])
    # prefer exact fit strongly
    penalty[rem == 0] = -5.0
    # slightly discourage opening new bins when item is large
    mask_empty = (bins == 100)
    penalty[mask_empty] += 0.2 * item

    return score + penalty
