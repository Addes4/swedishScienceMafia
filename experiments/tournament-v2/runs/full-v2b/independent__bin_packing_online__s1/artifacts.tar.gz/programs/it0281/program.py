import numpy as np

# Tunable constants (fixed, not tuned to individual instances)
EPS_EMPTY_PENALTY = 0.5   # discourage opening new bins when a used bin fits
FULL_BIN_FLAT = 0.0

def priority(item, bins):
    """
    Best-fit with a small penalty for choosing empty (unused) bins.
    Highest score wins; ties go to the first bin.

    score = -(remaining_after_placement) - penalty_if_empty
    """
    bins = np.asarray(bins, dtype=np.int64)
    remaining_after = bins - item  # always >= 0 since only fitting bins are shown

    scores = -remaining_after.astype(np.float64)

    # Penalize opening a brand-new bin (remaining capacity exactly 100)
    empty_mask = (bins == 100)
    if np.any(empty_mask):
        scores[empty_mask] -= EPS_EMPTY_PENALTY

    return scores
