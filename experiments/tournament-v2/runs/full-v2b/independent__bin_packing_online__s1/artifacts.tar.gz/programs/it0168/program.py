"""Best-fit with capacity-utilization tie-breaking for online bin packing."""

import numpy as np

_scale = 1.0


def priority(item, bins):
    """Rank bins: best fit first, with a mild penalty for leaving excess slack.

    The item must be placed immediately. Best-fit generally performs well for
    Weibull-shaped sizes with mean ~40. We add a tiny secondary term that
    slightly prefers bins whose remaining capacity after placement leaves
    usable space, avoiding opening new bins too eagerly when a modest fit
    exists.
    """
    # Primary: smaller remaining-after-placement is better -> negative.
    # residual = bins - item (>=0 for all shown bins).
    residual = bins - item

    # Secondary: among similar residuals, prefer bins where the residual is
    # still reasonably large but not exactly zero, so future items have room.
    # This is a soft shape, tiny relative to the unit spacing of residuals
    # (residuals are integers), so it only breaks near-ties without changing
    # strict best-fit ordering.
    small_bonus = residual / (bins + 1.0)

    return -(residual.astype(np.float64)) + 0.25 * small_bonus
