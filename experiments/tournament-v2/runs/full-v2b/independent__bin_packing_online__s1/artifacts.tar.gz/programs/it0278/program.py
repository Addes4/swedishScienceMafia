import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin whose remaining capacity is closest to the item size.
    # Slightly prefer fuller bins on ties by penalizing larger remaining capacity.
    # bins is int64; return float scores.
    return -(bins - item).astype(np.float64) - 1e-9 * bins
