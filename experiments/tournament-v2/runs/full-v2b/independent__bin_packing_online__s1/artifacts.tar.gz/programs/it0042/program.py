import numpy as np


def priority(item, bins):
    """Best fit: put the item in the bin where remaining capacity after placement is smallest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    Returns a score per bin; ties go to the first (lowest index) bin.
    """
    return -(bins - item)
