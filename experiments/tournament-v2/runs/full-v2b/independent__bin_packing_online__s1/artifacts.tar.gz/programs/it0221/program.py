import numpy as np

# Adaptive best-fit with fill-preservation weighting.
# Score = tightness (how full the bin becomes after placing) + a bonus for
# partially used bins that discourages opening new ones, plus tiny index tie-break.

_state = {"n": 0, "empties": 0}

# Weights chosen from Weibull(mean ~40) packing behavior. Kept conservative so it
# generalizes to unseen instances.
W_TIGHT = 1.0        # prefer bin whose remaining after placement is smallest
W_USED = 0.35        # prefer already-used bins (smaller remaining) to avoid new bins
W_NEAR100 = -0.05    # slight penalty for near-full large-remainder bins (improves mixing)

def priority(item, bins):
    _state["n"] += 1
    rem = bins  # remaining capacities, int64
    # Bin remaining capacity after placing the item.
    after = rem - item
    # Higher score = better. Tight fit: smaller 'after' -> higher score.
    score = -W_TIGHT * after
    # Preference for bins that are already partly used: smaller 'rem' -> higher score.
    score += -W_USED * rem
    # Mild anti-crowding on wide-open bins to encourage using space efficiently.
    score += W_NEAR100 * (rem >= 100).astype(np.float64)
    # Deterministic tiny tie-break by bin index (earlier bins slightly favored).
    # bins is already in index order; add a tiny decreasing term.
    n = len(bins)
    if n > 1:
        score = score + np.linspace(1e-6, 0.0, n, dtype=np.float64)
    return score
