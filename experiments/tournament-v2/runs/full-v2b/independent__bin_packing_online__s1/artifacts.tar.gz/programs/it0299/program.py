import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum_items = 0.0
        self.counts = np.zeros(101, dtype=np.int64)
        self.calls = 0


_state = _State()


def priority(item, bins):
    """Improved online bin packing priority.
    
    Mostly best-fit, with a lightweight bias that avoids spending the last
    usable bin when the remaining capacity would be wasted on the current item.
    """
    # Record past statistics. This is only used for adaptive tie-breaking.
    _state.n += 1
    _state.sum_items += float(item)
    if 0 <= item <= 100:
        _state.counts[item] += 1
    _state.calls += 1

    bins = np.asarray(bins)
    rem = bins

    # Main packing rule: best fit = smallest remaining capacity that still fits.
    # priority must be higher for better bins, so use negative leftover slack.
    score = -(rem - item).astype(np.float64)

    # A small secondary preference: avoid leaving a bin with tiny unusable gaps
    # if another bin has almost the same fit. This helps when exact best fit
    # would create many 1..3 unit fragments.
    slack = rem - item
    near_exact = (slack >= 0) & (slack <= 2)
    score += near_exact * 0.25

    # Encourage using bins that are already partially loaded rather than
    # repeatedly opening/using high-capacity bins, except when the item is
    # large enough that tightness matters more.
    if item <= 70:
        # Prefer bins closer to full, but keep the effect tiny so best-fit
        # remains dominant.
        used = 100.0 - rem.astype(np.float64)
        score += used * (1e-4)

    # For larger items, avoid dangerous fragmentation: strongly prefer bins
    # where the leftover is either very small or large enough to be useful.
    if item >= 60:
        leftover = rem - item
        useful = (leftover == 0) | (leftover >= 25) | (leftover >= item)
        score += useful.astype(np.float64) * 0.05

    return score
