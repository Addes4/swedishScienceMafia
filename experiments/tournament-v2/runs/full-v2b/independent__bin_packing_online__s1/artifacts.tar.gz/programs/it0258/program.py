import numpy as np


def priority(item, bins):
    """Score each bin: prefer bins with the least remaining capacity after placement.

    Pure best fit: maximize item - remaining = minimize remaining - item.
    Add a tiny decreasing index-based bonus to make deterministic tie-breaking bias
    toward earlier bins, which is the standard first-fit-style behavior for ties.
    """
    # Base score: higher for tighter fit (smaller remaining capacity after placing item)
    score = item - bins.astype(np.float64)

    # Tiny deterministic tie-break favor toward lower bin indices (first bins)
    # This does not affect non-tied comparisons because the base score is integer-like.
    n = bins.shape[0]
    score = score + (n - np.arange(n, dtype=np.float64)) * 1e-9

    return score
