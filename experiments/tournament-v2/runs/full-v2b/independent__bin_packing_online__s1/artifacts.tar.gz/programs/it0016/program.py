import numpy as np


def priority(item, bins):
    """Aging best fit: prefer tight fits, but encourage reuse of older partial bins."""
    # Best-fit score: higher is better, so use negative residual capacity after insertion.
    residual = bins - item

    # Prefer nonzero partial bins slightly over completely empty bins when their fit is similar.
    # Empty bins have residual 100 - item; demote them just a touch to consolidate.
    empty_penalty = (bins == 100) * 0.05

    # Convert to score: smaller residual is better.
    score = -residual.astype(np.float64) - empty_penalty

    return score
