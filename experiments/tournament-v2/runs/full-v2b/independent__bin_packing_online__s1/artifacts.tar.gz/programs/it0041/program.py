import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "small_bins": {},   # bin_size -> remaining capacity, for small items
}

def priority(item, bins):
    """
    Hybrid bin-choice rule:
      - Large items: strict best fit (minimize residual space).
      - Small items: best fit, but with a mild penalty for opening fresh bins,
        and a tiny bias toward bins that are already partially used.
    """
    n_old = _state["n"]
    _state["n"] = n_old + 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    # Score: higher is better. Base is negative leftover space (best fit).
    base = -(bins.astype(np.float64) - item)

    if item >= 40:
        # Large item: pure best fit.
        return base

    # Small item. Add a small bonus for bins that are neither empty nor nearly full.
    # Prefer using existing partial bins slightly over opening completely new ones.
    rem_after = bins.astype(np.float64) - item

    # Penalize opening new empty bins (remaining capacity = 100 before placement).
    new_bin_penalty = np.where(bins == 100, -1.5, 0.0)

    # Mild preference for moderately filled bins: residual after placement near half-full.
    # Lower leftover is good, but too-low leftover wastes future flexibility.
    # Use a gentle quadratic centered a bit above zero.
    ideal_leftover = max(10.0, min(35.0, 100.0 - mean_item))
    flex_bonus = -0.02 * np.abs(rem_after - ideal_leftover)

    # Slight reward for bins already in use (not empty), to reduce bin count.
    used_bonus = np.where(bins < 100, 0.2, 0.0)

    return base + new_bin_penalty + flex_bonus + used_bonus
