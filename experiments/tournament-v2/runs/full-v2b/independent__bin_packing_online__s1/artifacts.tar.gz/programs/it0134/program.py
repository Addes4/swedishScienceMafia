"""Improved online bin packing: class-aware best fit with adaptive bias.

The main idea is that pure best fit (minimize remaining capacity after placement)
is strong for large items, while for small items it is often better to leave
bins with capacities that future items of similar size can use.  We maintain a
small amount of state (a rolling histogram of recent item sizes) to estimate
which size class is currently dominant, and add a small bias to the best-fit
score so that bins with remaining capacity near typical future item sizes are
slightly preferred.  The bias is kept small so that capacity feasibility and
tight packing still dominate.
"""

import numpy as np

# ---------------------------------------------------------------------------
# Module-level state (persists across calls within one instance)
# ---------------------------------------------------------------------------
_state = {
    "n": 0,
    "sum": 0.0,
    # rolling histogram of recent item sizes (integer sizes 1..100)
    "hist": np.zeros(101, dtype=np.float64),
    # exponential decay weight
    "decay": 0.995,
    # cached distribution estimate
    "mean": 40.0,
    "small_cut": 25,     # items <= small_cut are "small"
    "large_cut": 60,     # items > large_cut are "large"
}

# Precompute a lookup: for a given remaining capacity r (0..100),
# estimate "desirability" of keeping that bin around.
# We want bins that are nearly full to be preferred (small r), but also
# bins whose remaining capacity matches the typical item size slightly
# preferred to avoid fragmenting.  The lookup is rebuilt occasionally.

_LOOKUP = None
_LOOKUP_VERSION = -1


def _rebuild_lookup(mean, hist):
    """Build a table mapping remaining capacity r -> small additive bias."""
    global _LOOKUP, _LOOKUP_VERSION
    # estimate a characteristic "future item size" from the histogram
    total = hist.sum()
    if total < 10:
        typ = mean
    else:
        # weighted median of recent items
        c = np.cumsum(hist)
        # find median index
        half = total * 0.5
        idx = int(np.searchsorted(c, half))
        idx = max(1, min(100, idx))
        typ = float(idx)

    # For each remaining capacity r (0..100), bias:
    #   - strong preference for small r (nearly full bins)
    #   - weak preference for r close to typical item size
    r = np.arange(101, dtype=np.float64)
    # base: we want to fill bins, so smaller remaining capacity better.
    # best-fit score is -(bins - item) = item - bins, i.e. larger when bins smaller.
    # We add a gentle bump around typ to encourage leaving bins sized for typical items.
    bump = np.exp(-((r - typ) ** 2) / (2.0 * max(4.0, typ * 0.5) ** 2))
    # scale bump weight; keep small so it doesn't dominate
    bias = 0.15 * bump
    _LOOKUP = bias.astype(np.float64)
    _LOOKUP_VERSION += 1
    return _LOOKUP


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    # --- update state ---
    _state["n"] += 1
    _state["sum"] += item
    h = _state["hist"]
    h *= _state["decay"]
    h[item] += 1.0
    mean = _state["sum"] / _state["n"]
    _state["mean"] = mean

    # --- ensure lookup is up to date (rebuild periodically) ---
    global _LOOKUP
    if _LOOKUP is None or _state["n"] % 64 == 0:
        _rebuild_lookup(mean, h)
    lookup = _LOOKUP

    # --- base best-fit score ---
    # bins: remaining capacity of each bin (item fits, so bins >= item)
    # best fit: put item in bin where remaining after placement is smallest.
    # score = -(remaining_after) = -(bins - item) = item - bins
    # equivalently larger score for smaller bins.
    base = -(bins.astype(np.float64) - float(item))

    # --- adaptive bias ---
    # index into lookup by remaining capacity (clip to 0..100)
    idx = np.clip(bins.astype(np.int64), 0, 100)
    bias = lookup[idx]

    # --- class-specific tweaks ---
    # For large items, we care mostly about tight packing (reduce fragmentation),
    # so reduce the bias.  For small items, bias can help.
    if item > _state["large_cut"]:
        bias = bias * 0.2
    elif item <= _state["small_cut"]:
        bias = bias * 1.2

    # Also: slight preference for used-but-not-full bins over completely empty
    # bins when item is small, to avoid opening new bins unnecessarily.
    # Empty bins have bins == 100.  If item is small and there exist bins with
    # some capacity used, we can nudge against empty bins.
    if item <= _state["small_cut"]:
        empty_mask = (bins == 100)
        # best-fit already penalizes empty bins (remaining 100 is large),
        # but add extra nudge to prefer partially filled bins slightly.
        bias = np.where(empty_mask, bias - 0.5, bias)

    score = base + bias
    return score
