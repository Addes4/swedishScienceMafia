"""Online bin packing: best-fit with a mild reserve bias for Weibull-shaped sizes."""
import numpy as np


def priority(item, bins):
    # Best-fit component: prefer smallest remaining capacity that still fits.
    # Score = -residual (higher score for tighter fit).
    base = -(bins - item)

    # Reserve bias: mildly discourage consuming almost-full bins and fully-empty
    # bins in ways that reduce future packing flexibility. We reward residuals
    # that leave room for a typical item (~40) plus a small item, and slightly
    # penalize leaving very small or very large residuals.
    residual = bins - item
    # Gaussian-ish preference centered at 40 (mean item size), width 25.
    pref = -((residual - 40.0) ** 2) / (2.0 * 25.0 * 25.0)

    # Combine: best-fit dominates; reserve bias acts as a small tie-breaker.
    return base + 0.05 * pref
