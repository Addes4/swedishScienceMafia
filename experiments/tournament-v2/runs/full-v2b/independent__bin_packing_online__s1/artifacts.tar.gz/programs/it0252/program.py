import numpy as np


def priority(item, bins):
    # Best-fit: choose the bin with the smallest remaining capacity that still fits.
    # bins only contains bins where item fits, so bins >= item.
    # Penalize completely empty bins slightly so partially used bins are preferred.
    # This mimics best-fit-decreasing well enough for online use.
    rem = bins - item
    empty_penalty = (bins == 100).astype(np.int64) * 1
    return -(rem + empty_penalty)
