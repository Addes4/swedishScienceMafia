import numpy as np


def priority(item, bins):
    """Best fit: prefer the bin with the least remaining capacity after placing item.

    Score = -(remaining after placement). Higher score => tighter fit.
    We add a tiny bonus for bins that would become exactly full, which tends to
    slightly reduce waste without changing the main best-fit ordering.
    """
    after = bins - item
    # Main term: tightest fit (most negative "after" gets highest score).
    score = -after.astype(np.float64)
    # Small bonus for exact fills.
    score += 1e-6 * (after == 0)
    # Tiny bias toward lower indices on exact ties, matching harness tie-break.
    score += 1e-12 * (-np.arange(bins.shape[0]))
    return score
