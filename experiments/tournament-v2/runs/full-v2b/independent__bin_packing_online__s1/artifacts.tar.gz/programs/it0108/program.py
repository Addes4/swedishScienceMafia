import numpy as np

def priority(item, bins):
    # Best-fit with a mild preference for almost-full bins and used bins.
    # Lower residual (bin capacity after placement) gets higher score.
    residual = bins - item

    # Penalize residuals quadratically so nearly-full bins are strongly preferred.
    score = -residual * residual

    # Small bonus for used bins (capacity < 100) to avoid opening new bins.
    used_bonus = np.where(bins < 100, 1.0, 0.0)
    score = score.astype(np.float64) + used_bonus

    return score
