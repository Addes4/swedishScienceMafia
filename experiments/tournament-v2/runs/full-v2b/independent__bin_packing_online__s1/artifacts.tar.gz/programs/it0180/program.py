"""Improved online bin packing: exact-fit bonus + best-fit with empty-bin penalty."""
import numpy as np


def priority(item, bins):
    """Score each candidate bin; highest score wins (ties -> first bin).

    item: integer size of arriving item, 1..100.
    bins: remaining capacities of bins it fits in, in fixed bin order.
    """
    # Primary term: best fit -> prefer smallest residual that still fits.
    residual = bins - item  # >= 0 for all bins shown

    # Strong bonus for exact fill (residual == 0).
    score = -residual.astype(np.float64)

    # Reward tight fits strongly (small residual), penalize large waste.
    score += 5.0 / (1.0 + residual)

    # Mildly discourage opening brand-new bins: an untouched bin has residual == 100.
    # Penalize it a little so we tend to fill partially-used bins first.
    score -= 2.0 * (residual == 100)

    # Extra: slight preference to keep bins that are nearly full (residual small)
    # already handled by 1/residual term.

    return score
