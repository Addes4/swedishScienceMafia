import numpy as np


def priority(item, bins):
    """Rank bins for immediate online bin packing.

    Strategy:
    - Best Fit: prefer the tightest packing, i.e. smallest remaining capacity >= item.
    - Slightly penalize creating tiny residual gaps that are likely unusable.
    - Prefer existing non-empty bins over unused bins if fit quality is comparable.
    """
    # Remaining capacity after placing item in each bin.
    rem = bins - item

    # Base score: tightest fit wins. Higher score for smaller remaining capacity after placement.
    # bins is int64, item is int; rem may be negative for non-fitting bins but harness
    # only shows bins the item fits in, so rem >= 0 here.
    score = -rem.astype(np.float64)

    # Penalize residual capacities that are very small but not zero, because they are
    # often hard to reuse. This slightly favors exact fits and moderate small gaps over
    # leaving, say, 1..4 units in otherwise closed bins.
    # Smooth bonus/penalty shape, kept mild so it doesn't override best fit.
    small = (rem > 0) & (rem < 8)
    score[small] -= (8.0 - rem[small].astype(np.float64)) * 0.15

    # Encourage reuse of already-open bins rather than spreading into fresh bins.
    # Any bin with remaining < 100 is considered open. Prefer these mildly.
    open_bins = bins < 100
    score[open_bins] += 0.01

    return score
