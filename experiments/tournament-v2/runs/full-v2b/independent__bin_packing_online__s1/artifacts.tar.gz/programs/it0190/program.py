import numpy as np

# Running histogram of observed item sizes (1..100). Updated once per call.
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0
# Exponentially decayed histogram to adapt within an instance.
_decay = 0.999

def priority(item, bins):
    global _total
    # Update histogram with the current item.
    _counts *= _decay
    _counts[item] += 1.0
    _total = _total * _decay + 1.0

    # Feasible residual capacities after placing the item.
    residual = bins - item  # >= 0 guaranteed by harness filtering

    n = bins.shape[0]

    # Base score: best fit -> smaller residual is better.
    score = -residual.astype(np.float64)

    # Boost bins whose residual matches a frequently seen item size,
    # so that leftover space is likely usable later.
    # Normalize histogram to probabilities.
    probs = _counts / _total if _total > 0 else _counts
    match = probs[residual.clip(0, 100)]

    # Weight: larger for small items (they can fill gaps flexibly),
    # smaller for large items where tight fit matters more.
    w = 0.5 if item < 20 else (0.2 if item < 40 else 0.05)
    score += w * match * 10.0

    # Prefer perfectly filling a bin (residual 0) strongly.
    score += (residual == 0) * 1e6

    # Prefer using lower-index bins / keep unused full bins available later:
    # give a tiny bonus to non-full bins (more likely already partially used)
    # so that the item tightens existing partially-used bins rather than opening new ones.
    used_bonus = (bins < 100).astype(np.float64) * 0.01
    score += used_bonus

    return score
