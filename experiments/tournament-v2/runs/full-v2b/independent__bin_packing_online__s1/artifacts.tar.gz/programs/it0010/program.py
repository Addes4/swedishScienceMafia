"""Online bin packing: hybrid best-fit with fragmentation-aware tie-breaking."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of bins the item fits in,
          including unused bins (remaining cap 100), in bin order.
    """
    # Remaining capacity after placing the item in each bin.
    rem = bins - item

    # Primary: best fit => prefer smallest leftover capacity.
    # Score is negative leftover, but add a tiny tie-break term.
    # For equal leftover, prefer bins that are already open (capacity < 100),
    # because opening new bins tends to be more expensive long-run.
    is_new = bins == 100

    # Secondary tie-break: among equal leftovers, prefer fuller bins slightly,
    # and avoid opening brand-new bins when an existing bin ties.
    # Also, for large items prefer exact-ish fits; for small items mild spread.
    score = -rem.astype(np.float64)

    # Tiny preference for used bins on exact ties (opening new bin only on strict win).
    score += np.where(is_new, -0.25, 0.0)

    # Slight class-based nudge to counter fragmentation:
    # small items can go into nearly-full bins; big items prefer leaving room.
    if item <= 33:
        # small: prefer tighter fits a bit more
        score += (-rem) * 0.02
    elif item >= 67:
        # large: mild preference to not leave awkward medium gaps
        score += np.where(rem <= 10, 0.10, 0.0)

    return score
