import numpy as np


def priority(item, bins):
    """Rank bins for online bin packing.

    The item is small/medium most of the time (~40 mean), so tight packing helps.
    Large items matter more because mistakes there cost whole bins.
    """
    # Remaining capacity after placing the item.
    rem = bins - item

    # Base: best fit -- prefer the smallest leftover.
    # Use a slight nonlinearity so near-exact fits and avoiding tiny scraps are both favored.
    score = -rem.astype(np.float64)

    # Strong bonus for exact fit or near-exact fit.
    score += 30.0 * (rem <= 0)          # rem == 0 always, since item fits
    score += 12.0 * (rem == 0)
    score += 6.0 * ((rem > 0) & (rem <= 3))

    # Penalize creating very small free space (1..8), which is usually unusable.
    small = (rem > 0) & (rem <= 8)
    score -= 8.0 * small

    # Slight preference to fill bins already partially used rather than fresh ones,
    # but do not overdo it: sometimes a fresh bin is correct.
    fresh = bins == 100
    score -= 2.0 * fresh

    # For large items, opening a fresh bin can be better than fragmenting existing ones.
    # Reward fresh bins more as item size grows.
    if item >= 55:
        score += (item - 55) * 0.8 * fresh

    # Avoid leaving a bin with too little room to fit typical items unnecessarily.
    # Remaining in 10..35 is often still useful; penalize only extreme near-fulls.
    score -= 0.15 * np.maximum(0, 10 - rem)

    return score
