"""Online bin packing: best fit with mild fragmentation-aware tie-breaking."""

import numpy as np

# Running statistics kept between calls (never future information).
_count = 0
_sum = 0.0
# Rough target residual: avoid filling bins down to tiny unusable gaps when possible.
_TARGET_MEAN = 40.0


def priority(item, bins):
    """Rank bins; highest score wins, ties go to the earliest bin.

    Approach: best fit (smallest residual after placement), with a secondary
    preference for bins whose residual is not so small that they become
    effectively unusable for typical future items.
    """
    global _count, _sum

    # Update running mean item size (used only as a soft heuristic).
    _count += 1
    _sum += item
    mean_item = _sum / _count if _count else _TARGET_MEAN

    # residual after placing this item
    residual = bins - item

    # Primary: best fit => prefer small residual.
    # Secondary: slightly penalize residuals far below the typical item size,
    # which tend to waste a bin that can no longer accept a normal item.
    # Use a smooth penalty that is negligible for good medium residuals.
    penalty = np.maximum(0.0, mean_item * 0.5 - residual)
    penalty = penalty * 0.01

    # Small deterministic tie-breaker favoring bins closer to full but not
    # below a useful residual; this also spreads decisions away from exact ties.
    score = -(residual.astype(np.float64) + penalty)

    # Add a tiny index-based jitter to break ties in a stable, non-arbitrary way.
    # Earlier bins get a negligible boost, matching the required tie rule anyway.
    if len(score) > 1:
        idx = np.arange(len(score), dtype=np.float64)
        score = score - idx * 1e-9

    return score
