"""Threshold-tuned best fit for online bin packing.

Strategy: primarily best-fit (place item in the bin with least remaining space
that still fits). We adaptively track item sizes to detect how "full" we are
and bias toward closing nearly-full bins. The key insight is that for online
bin packing with Weibull-distributed sizes, best fit is near-optimal, but we
can improve slightly by preferring to completely fill bins when possible.
"""
import numpy as np

_state = {
    "counts": None,   # histogram of item sizes seen
    "n": 0,
}


def priority(item, bins):
    # Best-fit: minimize remaining capacity after placing (maximize bins - item filled).
    # Score higher for bins whose remaining capacity is just >= item (tight fit).
    # Ties go to first bin (fixed order), which naturally fills earlier bins first.
    score = -(bins - item).astype(np.float64)

    # Small bonus for bins that would become exactly full (residual 0).
    # This helps close bins and compact the solution.
    residual = bins - item
    bonus = np.where(residual == 0, 0.5, 0.0)

    return score + bonus
