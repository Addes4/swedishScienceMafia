"""Best-fit bin choice for online bin packing.

The item is placed into the bin that leaves the least remaining capacity
after the placement. This is the classic Best Fit heuristic, which is strong
for online bin packing. A small tie-breaking bias favors bins that are not
completely empty, because unused bins are always available and it is never
harmful to use partially filled ones before opening a new one.
"""
import numpy as np


def priority(item, bins):
    bins = np.asarray(bins, dtype=np.int64)
    after = bins - item
    # Primary: smallest remaining capacity after placing item.
    # Secondary: prefer already-used bins slightly over completely empty ones.
    return -after * 1024 - (bins == 100).astype(np.int64)
