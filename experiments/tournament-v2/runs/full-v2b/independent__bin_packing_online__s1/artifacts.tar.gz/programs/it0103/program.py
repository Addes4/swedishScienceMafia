"""Online bin packing: best-fit with a mild anti-new-bin bias."""
import numpy as np


def priority(item, bins):
    # Best fit: smallest remaining capacity that still fits -> most negative (bins - item).
    # Add a tiny penalty for completely empty bins so partially-used bins get filled first,
    # without ever overriding a genuine best-fit choice.
    residual = bins - item  # >= 0 for all shown bins
    score = -residual.astype(np.float64)
    # Empty bins have residual == 100 - item; nudge them slightly down.
    score -= 1e-3 * (bins == 100)
    return score
