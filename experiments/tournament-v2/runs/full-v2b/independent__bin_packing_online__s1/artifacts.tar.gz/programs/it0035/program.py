import numpy as np
from collections import deque

class PackingState:
    def __init__(self):
        self.item_count = 0
        self.total_size = 0
        self.size_hist = np.zeros(101, dtype=np.int64)  # histogram
        self.bin_caps = []  # we don't really track exact bin caps; harness does
        # We can accumulate recent item sizes for adaptive scoring
        self.recent_sizes = deque(maxlen=200)
        self.bins_used_est = 0.0
        self.avg_size = 40.0

    def update(self, item):
        self.item_count += 1
        self.total_size += item
        self.size_hist[item] += 1
        self.recent_sizes.append(item)
        if len(self.recent_sizes) >= 50:
            self.avg_size = sum(self.recent_sizes) / len(self.recent_sizes)

state = PackingState()

def priority(item, bins):
    global state
    state.update(item)
    
    n = len(bins)
    if n == 0:
        return np.array([], dtype=np.float64)
    
    # Score: prefer bins that after placement have low remaining capacity (best fit)
    # but with a slight penalty for leaving large bins too empty (encourage filling).
    # Also add a tiny bias toward lower index bins to break ties preferentially (harness already does first-max).
    remaining_after = bins - item  # this is >=0 for all shown bins
    
    # Base score: negative remaining after (higher for tighter fit)
    base = -remaining_after.astype(np.float64)
    
    # Add small bonus for bins that are nearly full but not quite (fragmentation reduction)
    # If a bin would be left with a tiny residual, it's good.
    # Also discourage using a completely empty bin (remaining == 100) when a tighter fit exists.
    # But we must still allow empty bins early.
    
    # Adaptive parameter: as we progress, prefer to close bins that have small remaining capacity.
    # Determine how "full" each bin is (capacity = 100).
    used_before = 100 - bins  # in [0, 100]
    
    # We want to minimize residual after placement, but also consider the fill ratio.
    # A proven online heuristic: best fit with a threshold to close bins when residual is small.
    # Since we only rank, we can boost bins that would become >= some threshold used.
    
    residual = remaining_after.astype(np.float64)
    
    # Score components:
    # 1. Main term: prefer smaller residual (best fit)
    # Weight: we want strong best fit, so weight 1.0
    score = -residual  # higher for smaller residual
    
    # 2. Bonus for closing bins: if residual is very small (<= 10), give extra boost
    # Such a bin becomes almost full; using it saves space.
    close_bonus = np.where((residual <= 10) & (residual > 0), 5.0, 0.0)
    score += close_bonus
    
    # 3. Penalty for using an empty bin when a non-empty bin can fit the item well.
    # If bin was empty (bins == 100), and residual is large, penalize it slightly.
    # Only when there are other bins that fit.
    empty_bins = (bins == 100)
    # If all bins are empty, no penalty needed.
    if np.any(~empty_bins):
        # Penalize empty bins by a small amount
        score = np.where(empty_bins, score - 0.1, score)
    
    # 4. Slight preference for bins that are already well-filled (higher used_before)
    # to reduce number of active bins. This helps avoid spreading items thinly.
    # Weight: small, e.g. 0.001 * used_before
    score += 0.001 * used_before.astype(np.float64)
    
    # Ensure no NaNs
    score = np.nan_to_num(score, nan=-1e9)
    
    return score
