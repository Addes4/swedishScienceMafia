import numpy as np

_last_since_open = 0

def priority(item, bins):
    # Best-fit: strongest preference for tightest fit (smallest remaining capacity >= item).
    # Add a tiny secondary term to prefer using already-open bins over untouched capacity-100 bins,
    # and to break ties toward lower index (handled by harness).
    # bins are all remaining capacities >= item.
    rem = bins.astype(np.float64)
    score = -(rem - item)  # primary: smaller rem -> larger score

    # Penalize perfectly empty bins slightly to encourage filling partially used bins first.
    # This reduces fragmentation without sacrificing best-fit tightness.
    score -= (rem == 100.0).astype(np.float64) * 0.02

    # Slight preference against leaving tiny unusable gaps: if rem == item exactly, that's perfect.
    score -= (rem == item).astype(np.float64) * 0.0  # no-op; keep best-fit exact

    # Favor bins that are not almost full but have small residuals, preserving large bins.
    # A tiny monotone bonus for smaller remaining capacity already exists, so no extra needed.

    return score
