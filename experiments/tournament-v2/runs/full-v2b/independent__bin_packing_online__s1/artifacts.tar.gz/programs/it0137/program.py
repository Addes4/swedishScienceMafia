import numpy as np

def priority(item, bins):
    # Best-fit baseline: prefer smallest residual capacity that still fits.
    residual = bins - item

    # Penalize residuals that are likely to be hard to fill later.
    # Items have mean ~40, so a residual below ~20 is often wasteful,
    # while large residuals (unused bins) should remain attractive.
    # Use a smooth penalty: score higher when residual is either very small
    # (perfect fit) or quite large (keeps flexibility), lower for awkward midsize leftovers.
    scores = -residual.astype(np.float64)

    # Extra reward for exact/near-exact fits.
    scores += 200.0 / (residual + 1.0)

    # Mild penalty for leaving small unusable gaps.
    scores -= 0.05 * np.maximum(0.0, 25.0 - residual)

    # Prefer unused bins slightly less than tightly fitting partially filled bins
    # to encourage filling existing bins first.
    scores -= 0.02 * (bins == 100)

    return scores
