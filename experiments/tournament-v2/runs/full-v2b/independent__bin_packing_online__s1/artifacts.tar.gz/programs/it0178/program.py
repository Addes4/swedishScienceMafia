import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Strategy:
    - Prefer bins that after placing the item have the smallest remaining capacity (best fit).
    - Strongly reward bins that become exactly full (remaining capacity 0 after placement),
      since perfect fits reduce waste.
    - Slight preference for lower-index bins on ties is handled automatically by the harness.
    """
    remaining_after = bins - item  # >= 0 for bins the item fits in

    # Base score: best fit => smallest remaining_after => higher score.
    # Use negative remaining capacity.
    score = -remaining_after.astype(np.float64)

    # Bonus for perfect fit (exactly full).
    perfect = (remaining_after == 0)
    score[perfect] += 1000.0

    # Small bonus to discourage leaving tiny unusable remainders (1..item-1) later.
    # Encourage leaving larger gaps rather than small ones when not perfect,
    # but only secondary to best fit. This helps reduce fragmentation slightly.
    # For a bin that won't be full, prefer leaving a remainder that is at least
    # the minimum item size (assume 1) — already handled by best fit.
    # Add a tiny nudge: prefer larger absolute remainder among near-ties? No,
    # best fit is primary. Keep it simple and robust.

    return score
