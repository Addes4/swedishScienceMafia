"""Online bin packing: best-fit with empty-bin reservation.

Strategy:
- Score bins by best-fit: smaller remaining capacity after placement is better.
- If there exists at least one non-empty bin that can fit the item, penalize
  completely empty bins so we don't open new bins unnecessarily.
- This hybrid rule performs well across the Weibull-shaped item distribution.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins.

    item: integer size, 1..100
    bins: numpy int64 array of remaining capacities (only bins that fit)
    """
    # Best-fit score: prefer bins whose remaining capacity is closest to item.
    scores = -(bins - item)

    # Prefer non-empty (partially used) bins over completely empty ones.
    # Empty bins have remaining capacity 100.
    empty_mask = (bins == 100)
    if not np.all(empty_mask):
        # There is at least one non-empty bin available; penalize empty bins.
        scores = scores.astype(np.float64)
        scores[empty_mask] -= 1000.0

    return scores
