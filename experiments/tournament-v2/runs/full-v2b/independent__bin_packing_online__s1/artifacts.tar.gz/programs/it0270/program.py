import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    # Online estimate of mean item size.
    _state["n"] += 1
    _state["sum"] += item
    mean = _state["sum"] / _state["n"]

    # Target residual after placing an item.  Under a mean ~40 distribution,
    # leaving a small residual tends to strand short items, so encourage
    # moderate residuals but still strongly prefer bins that fit tightly.
    # Score combines tightness with a mild preference for a target remainder.
    rem_after = bins - item
    # target = around half mean, clipped to [0, 100]
    target = min(100.0, max(0.0, mean * 0.5))
    # Penalize deviation from target, plus prefer tighter fits.
    score = -np.abs(rem_after - target) - 0.001 * rem_after
    return score
