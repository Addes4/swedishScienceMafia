"""Online best-fit variant: tightly pack items while slightly discouraging new bins."""
import numpy as np


def priority(item, bins):
    # Best fit: prefer smallest remaining capacity that still fits the item.
    slack = bins - item  # >= 0 because bins is only bins the item fits in
    # Exact fit gets a strong bonus (reduces bins by using no leftover).
    exact = (slack == 0)
    # New/empty bins have remaining capacity 100 -> slack = 100 - item.
    # Prefer used bins a bit over opening a fully empty bin.
    empty = (bins == 100)
    score = -slack.astype(np.float64)
    score += exact.astype(np.float64) * 1e6
    score -= empty.astype(np.float64) * 1e-3
    return score
# EVOLVE-BLOCK-END
