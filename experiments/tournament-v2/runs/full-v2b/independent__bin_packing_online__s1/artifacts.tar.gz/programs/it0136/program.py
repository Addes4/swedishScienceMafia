"""Best fit with a light online heuristic adjustment."""

import numpy as np

# Online statistics of item sizes seen so far.
_n = 0
_sum = 0.0
_mean = 40.0

# Cache avoiding repeated allocation.
_scratch = None


def _update(item):
    global _n, _sum, _mean, _scratch
    _n += 1
    _sum += item
    _mean = _sum / _n


def priority(item, bins):
    """Rank bins: primarily best-fit, with a small bias toward balanced fill.

    The main signal is remaining capacity after placing the item (bins - item):
    smaller is better, so score = -(bins - item).  A secondary term slightly
    prefers resulting residuals that are more likely to be usefully filled.
    """
    _update(item)

    # residual capacity after placing the item in each bin
    rem = bins - item  # all >= 0 since harness only passes fitting bins

    # Base best-fit score.
    score = -rem.astype(np.float64)

    # Small tie-breaking bias: prefer residual that is either very small
    # (nearly full bin) or close to a typical item size (easy future fit).
    # Use a smooth function of rem relative to current mean.
    m = _mean
    if m < 1.0:
        m = 1.0

    # closeness to a multiple/typical fill chunk; scaled tiny so it rarely
    # overrides best fit but breaks near-ties toward fuller bins.
    frac = rem / m
    # reward small residuals a bit more via a convex penalty on rem
    score -= 0.02 * rem.astype(np.float64)

    return score
