import numpy as np

_calls = 0
_sum_items = 0.0
_bins_opened_est = 0.0

# Target average leftover fraction. Around 0.12-0.20 often helps Weibull(mean 40).
def _target_gap(item):
    # Adaptive: early items more flexible, later prefer tighter packing.
    # 5000 calls expected; use gradual tightening.
    t = min(1.0, _calls / 5000.0)
    frac = 0.22 - 0.10 * t
    return item * frac + (100 - item) * (0.04 - 0.02 * t)

def priority(item, bins):
    global _calls, _sum_items, _bins_opened_est
    _calls += 1
    _sum_items += item

    rem = np.asarray(bins, dtype=np.float64)
    waste = rem - float(item)  # nonnegative for shown bins

    # Pure best fit baseline
    base = -waste

    # Adaptive target residual after placing item.
    tg = _target_gap(item)

    # Penalize residuals far above target (wasteful opening big gaps),
    # and mildly penalize residuals far below target (too tight, blocks future fits).
    diff = waste - tg
    # Asymmetric: over-target penalty a bit stronger than under-target.
    pen = np.where(diff > 0, 0.35 * diff, 0.18 * (-diff))

    # Encourage using already well-utilized bins rather than nearly empty bins
    # by adding a small bonus for lower remaining capacity, but not overriding best fit.
    util_bonus = 0.02 * (100.0 - rem)

    return base - pen + util_bonus
