import numpy as np

class BinPacker:
    def __init__(self):
        self.sum_items = 0
        self.count = 0
        self.ema_size = 40.0  # running estimate of mean item size

    def priority(self, item, bins):
        self.sum_items += item
        self.count += 1
        # exponential moving average of item sizes
        self.ema_size = 0.98 * self.ema_size + 0.02 * item

        # residual capacity after placing this item
        resid = bins - item

        # We want to place in the bin with smallest residual (best fit),
        # but we slightly penalize creating very small residuals that may waste space.
        # Score = -(resid) but with a small bonus for moderate residuals near ema_size.
        # We'll implement: prefer smallest resid; if resid == 0, huge bonus.
        score = -resid.astype(np.float64)

        # Bonus for exact fit
        score[resid == 0] += 1000.0

        # Small adjustment: bins that leave room for an average item are slightly favored
        # to avoid creating tiny unusable gaps.
        # But we must be careful not to break best-fit too much.
        # We'll add a tiny term that favors residuals closer to ema_size.
        # This is a heuristic.
        # However, since scores are compared, we just add a very small epsilon based on
        # residual distance to ema_size.
        # Actually, let's just use pure best-fit with exact fit bonus to keep it simple.
        # The exact fit bonus is already strong.

        return score

# The harness will instantiate BinPacker and call priority on it? No, the problem says
# Write priority(item, bins). So we need a module-level function.

_state = {
    'sum_items': 0,
    'count': 0,
    'ema_size': 40.0,
}

def priority(item, bins):
    _state['sum_items'] += item
    _state['count'] += 1
    _state['ema_size'] = 0.98 * _state['ema_size'] + 0.02 * item

    resid = bins - item  # numpy int64 array
    # Ensure resid is non-negative (the harness only gives bins where item fits)
    # Best fit: smallest residual gets highest score.
    # Score = -resid, with a large bonus for exact fit.
    score = (-resid).astype(np.float64)

    # Exact fit bonus: resid == 0
    score[resid == 0] += 1000.0

    # Very small bonus to avoid leaving unusable tiny gaps? For now, keep pure best-fit.
    # Maybe add a tiny preference for bins that would still have room for the average item?
    # Let's add a tiny score bonus proportional to how close residual is to ema_size.
    # This might help pack better on average.
    # But we must ensure it doesn't override best-fit significantly.
    # We'll use a small weight.
    # ema = _state['ema_size']
    # score += 0.001 * (-np.abs(resid - ema))

    return score
