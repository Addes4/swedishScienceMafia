import numpy as np

def priority(item, bins):
    """
    Best fit with a tweak: for large items, if there is an empty bin and the tightest
    fitting bin would leave a small residual (<10), prefer the empty bin to avoid
    creating a tiny residual that may be wasted.
    """
    res = bins - item
    scores = -res.astype(np.float64)  # ensure float for scoring
    if item > 50:
        empty = (bins == 100)
        if np.any(empty):
            perfect = (res == 0)
            if not np.any(perfect):
                min_bins = np.min(bins)
                min_res = min_bins - item
                if 0 < min_res < 10:
                    # boost empty bins to win over best fit
                    scores[empty] = 1.0
    return scores
