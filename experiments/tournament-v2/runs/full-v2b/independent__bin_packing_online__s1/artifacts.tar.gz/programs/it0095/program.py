"""Online bin packing heuristic.

Approach: score each feasible bin by a weighted combination of
    - "fit tightness": prefers bins where placing the item leaves little waste
    - "residual structure": mildly rewards leaving a residual capacity that is
      more likely to be useful for future items.

The weighting adapts to the arriving item size. Small items are packed tightly
(best-fit-like) to fill holes; large items get a slightly stronger preference
for bins where the placement leaves a moderate residual rather than near-zero,
reducing the tendency to waste large bins on tiny leftovers.
"""

import numpy as np

# Reused scratch state (size resets each call).
_STATE = {
    "calls": 0,
    "new_bins": 0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of feasible bins.
    """
    b = np.asarray(bins, dtype=np.int64)
    n = b.shape[0]

    # Remaining capacity after placing the item.
    rem = b - item

    # Basic best-fit: smaller residual => higher priority.
    score = -rem.astype(np.float64)

    # Adaptive bias: for larger items, slightly prefer bins that will retain a
    # usable residue (not zero, not the untouched full bin unless necessary).
    if item >= 55:
        # Reward moderate residues more than near-zero ones.
        # Peak around residual ~ 25..40.
        residue_bonus = -0.012 * (rem - 32.0) ** 2
        # Suppress opening brand-new bins a bit more strongly for big items.
        fresh_penalty = np.where(b == 100, -6.0, 0.0)
        score = score + residue_bonus + fresh_penalty
    elif item >= 30:
        residue_bonus = -0.006 * (rem - 22.0) ** 2
        fresh_penalty = np.where(b == 100, -3.0, 0.0)
        score = score + residue_bonus + fresh_penalty
    else:
        # Small items: pure best fit, but lightly discourage opening a new bin
        # when an existing hole can absorb them.
        fresh_penalty = np.where(b == 100, -1.5, 0.0)
        score = score + fresh_penalty

    # Tiny deterministic tie-break favoring earlier bins among equals
    # (already first-on-ties, but this keeps scores strictly ordered).
    score = score - np.arange(n, dtype=np.float64) * 1e-9

    return score
