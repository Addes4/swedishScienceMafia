import numpy as np

# Cache for the scoring array.  It is safe because item sizes are 1..100.
# We rank bins primarily by how well their post-placement residual capacity
# matches likely future item sizes.  The item size distribution is unknown
# exactly, but it is Weibull-shaped with mean near 40 and integer support 1..100.
# A residual capacity r is valuable if it is near a common item size, because
# then a future item can use that bin without wasting much.
#
# The score for a bin with remaining capacity b is:
#   base = -abs((b - item) - target) + small tie-break
# where target is a "good residual" value.  Best-fit is safe; this attempts to
# improve on it by slightly preferring residuals that align with common sizes.
#
# Without distribution parameters, we use a hand-selected set of target
# residual capacities around the likely mean and common Weibull modes.

_targets = np.array(
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30,
     32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 54, 56, 58, 60, 62, 64, 66,
     68, 70, 72, 74, 76, 78, 80, 82, 84, 86, 88, 90, 92, 94, 96, 98, 100],
    dtype=np.int64
)

# Weighted preference: residuals near the central region (around 40) are most
# likely useful.  This is a soft prior rather than a hard rule.
_target_weight = np.exp(-0.5 * ((_targets - 40.0) / 22.0) ** 2)

# Score table indexed by residual capacity r = b - item, for r in 0..100.
# Precompute once.  For each residual r, score it by the maximum weighted
# proximity to a target residual.
_SCORE = np.zeros(101, dtype=np.float64)
for r in range(101):
    if r == 0:
        # Perfectly filling the bin is generally good: no leftover capacity.
        _SCORE[r] = 0.0
    else:
        d = np.abs(_targets - r)
        # Prefer being exactly on a useful target; nearby is almost as good.
        val = np.max(_target_weight * np.exp(-0.5 * (d / 1.5) ** 2))
        _SCORE[r] = val

# Small deterministic tie-break: among equal post-placement residuals, prefer
# the bin with smaller remaining capacity before placement?  This is subtle.
# Best-fit already does that by using -r.  We want to keep best-fit's strong
# performance, so we combine: primary signal is the residual usefulness,
# secondary is best-fit tightness.
#
# The final score is:
#   1000 * usefulness(r) - r
# where usefulness(r) is in [0,1].  Thus usefulness dominates, and among
# equal-usefulness residuals the tightest fit wins (largest r => smaller -r,
# so we use -r as tie-break: smaller residual r gives larger -r, i.e. best fit).


def priority(item, bins):
    """Rank bins by expected future usefulness of their residual capacity.

    The item is placed in the bin maximizing a score that combines
    (a) how useful the leftover capacity is for likely future items, and
    (b) best-fit tightness as a conservative tie-breaker.
    """
    r = bins - item
    # r is guaranteed >= 0 because bins only contains bins the item fits in.
    # Clamp for safety.
    r = np.clip(r, 0, 100)
    usefulness = _SCORE[r]
    return 1000.0 * usefulness - r.astype(np.float64)
