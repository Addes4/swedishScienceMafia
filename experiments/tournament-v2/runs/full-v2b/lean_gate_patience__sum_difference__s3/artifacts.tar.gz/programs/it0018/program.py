# EVOLVE-BLOCK-START
"""Search directly for an integer set A maximizing log|A-A|/log|A+A|.

Approach: the product/digit construction A = {sum d_i B^i : d_i in S} gives
|A-A| = |S-S|^k and |A+A| = |S+S|^k (base B large enough), so the ratio equals
log|S-S|/log|S+S|. We search hard for a sum-poor digit set S (large |S-S|,
small |S+S|), then tensor it in base B to fill up to 4000 elements, gaining the
size bonus. A final greedy local search on A polishes the ratio.
"""
import math
import itertools
import random
import time

import numpy as np


def _stats(S):
    D = set()
    U = set()
    for a in S:
        for b in S:
            D.add(a - b)
            U.add(a + b)
    return U, D


def _ratio(S):
    U, D = _stats(S)
    if len(U) < 2 or len(D) < 2:
        return -1.0
    return math.log(len(D)) / math.log(len(U))


def _unique_count_np(arr):
    if arr.size == 0:
        return 0
    return np.unique(arr).size


def _score_np(A):
    A = np.asarray(A, dtype=np.int64)
    n = A.size
    if n < 2:
        return 0.0
    d = (A[:, None] - A[None, :]).ravel()
    s = (A[:, None] + A[None, :]).ravel()
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _best_digit_set(deadline):
    """Search for a digit set S minimizing |S+S| relative to |S-S|."""
    bestS = (0, 1)
    bestR = -1.0

    # exhaustive on tiny alphabets
    R = 10
    for sz in range(2, 5):
        for comb in itertools.combinations(range(-R, R + 1), sz):
            r = _ratio(comb)
            if r > bestR:
                bestR = r
                bestS = comb
            if time.time() > deadline:
                return bestS, bestR

    # keep a pool of good seeds and hill-climb
    pool = [bestS]
    for sz in range(3, 8):
        for comb in itertools.combinations(range(-6, 7), sz):
            if _ratio(comb) >= bestR - 0.02:
                pool.append(comb)
            if time.time() > deadline:
                break

    # random restarts + local search over digit values
    while time.time() < deadline:
        if random.random() < 0.5 and pool:
            S = set(random.choice(pool))
        else:
            sz = random.randint(4, 25)
            S = set(random.sample(range(-60, 61), sz))
        r = _ratio(S)
        if r > bestR:
            bestR = r
            bestS = tuple(sorted(S))
        for _ in range(200):
            if time.time() > deadline:
                break
            T = list(S)
            T[random.randrange(len(T))] = random.randint(-80, 80)
            T = set(T)
            if len(T) < 2:
                continue
            rr = _ratio(T)
            if rr > bestR:
                bestR = rr
                bestS = tuple(sorted(T))
                pool.append(bestS)
            if rr >= r:
                S, r = T, rr
    return bestS, bestR


def _tensor(S, k, B):
    A = [0]
    p = 1
    for _ in range(k):
        nxt = []
        for a in A:
            for d in S:
                nxt.append(a + d * p)
        A = nxt
        p *= B
    return A


def solve():
    deadline = time.time() + 95.0

    S, _ = _best_digit_set(time.time() + 45.0)
    S = [int(x) for x in S]

    # base large enough that digit blocks don't interact in sums/differences
    us, ds = _stats(S)
    maxd = max(abs(x) for x in ds) if ds else 1
    B = maxd + 1
    if B < 2:
        B = 2
    maxabs = max(abs(x) for x in S)

    bestA = None
    k = 1
    while True:
        size = len(S) ** k
        if size > 4000:
            break
        mag = maxabs * (B ** k - 1) // (B - 1) if B > 1 else 0
        if mag > 10 ** 15:
            break
        A = _tensor(S, k, B)
        if len(set(A)) <= 4000:
            bestA = A
            bestk = k
        k += 1

    if bestA is None:
        bestA = list(S)

    cand = sorted(set(int(x) for x in bestA))

    # fill remaining capacity with a sum-poor greedy extension to boost |A| bonus
    cap = 4000
    if len(cand) < cap:
        used = set(cand)
        diffs = set()
        sums = set(cand)
        for a in cand:
            for b in cand:
                diffs.add(a - b)
        # greedy: add x maximizing (new diffs) while minimizing (new sums)
        train = cand[:]
        for _ in range(cap - len(cand)):
            if time.time() > deadline - 20.0:
                break
            best_x = None
            best_val = -1.0
            base = random.randrange(len(train))
            for _try in range(60):
                x = train[random.randrange(len(train))] + random.randint(-200, 200)
                if x in used or abs(x) > 10 ** 15:
                    continue
                new_d = set()
                new_s = set()
                for a in train:
                    new_d.add(x - a)
                    new_d.add(a - x)
                    new_s.add(x + a)
                gain_d = len(new_d - diffs)
                cost_s = len(new_s - sums)
                val = gain_d / (1.0 + cost_s)
                if val > best_val:
                    best_val = val
                    best_x = x
            if best_x is None:
                break
            used.add(best_x)
            for a in train:
                diffs.add(best_x - a)
                diffs.add(a - best_x)
                sums.add(best_x + a)
            train.append(best_x)
        cand = sorted(used)

    if len(cand) > 4000:
        cand = cand[:4000]
    cand = [int(x) for x in cand if abs(x) <= 10 ** 15]
    if len(cand) < 2:
        return [0, 1, 3]
    return cand
# EVOLVE-BLOCK-END
