# EVOLVE-BLOCK-START
"""Search for sets with large difference set and small sum set.

Strategy: try several structured families
  * symmetric geometric chains  {0} ∪ {±b^i}
  * one/two-sided geometric chains {b^i}
  * digit-product sets {sum d_i b^i}
plus a direct search over unions of scaled geometric chains that keep the
sum set essentially linear while the difference set grows like n^2.
"""
import math
import time
import itertools
import numpy as np


def _count_unique(a, chunk=400):
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    n = len(a)
    ds = set()
    ss = set()
    for s in range(0, n, chunk):
        blk = a[s:s + chunk]
        ds.update(np.unique(blk[:, None] - a[None, :]).tolist())
        ss.update(np.unique(blk[:, None] + a[None, :]).tolist())
    return len(ds), len(ss)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _count_unique(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _build(D, b, k):
    vals = [0]
    pw = 1
    for _ in range(k):
        vals = [v + d * pw for d in D for v in vals]
        pw *= b
    return vals


def _digit_candidates():
    raw = []
    for lo in range(-4, 5):
        for hi in range(lo, lo + 5):
            D = list(range(lo, hi + 1))
            if 2 <= len(D) <= 5:
                raw.append(D)
    for size in (2, 3, 4):
        for c in itertools.combinations(range(-2, 5), size):
            raw.append(list(c))
    for D in ([0, 1, 2, 4], [0, 1, 2, 4, 8], [1, 2, 4, 8, 16],
              [-1, 0, 1], [0, 1, 3], [0, 1, 3, 7], [0, 1, 3, 7, 15],
              [0, 1, 3, 9, 27], [-2, -1, 0, 1], [0, 1, 2, 3]):
        raw.append(D)

    seen = set()
    scored = []
    for D in raw:
        t = tuple(sorted(D))
        if t in seen:
            continue
        seen.add(t)
        ss = len({x + y for x in D for y in D})
        dd = len({x - y for x in D for y in D})
        if ss < 2 or dd < 2:
            continue
        r = math.log(dd) / math.log(ss)
        scored.append((r, D))
    scored.sort(reverse=True)
    return [D for r, D in scored if r > 1.10][:20]


def _try(candidate, best, best_sc):
    candidate = sorted(set(candidate))
    if not (2 <= len(candidate) <= 4000):
        return best, best_sc
    if abs(candidate[0]) > 10 ** 15 or abs(candidate[-1]) > 10 ** 15:
        return best, best_sc
    s = _score(candidate)
    if s > best_sc:
        return candidate, s
    return best, best_sc


def solve():
    deadline = time.time() + 108

    best = [7, 15, 18, 22, -3, -2]
    best_sc = _score(best)

    # 1) Symmetric geometric chains  {0} +- {b^i}
    for b in (2, 3, 4, 5, 6, 7):
        for k in range(2, 14):
            A = sorted(set([0] + [b ** i for i in range(k)] + [-(b ** i) for i in range(k)]))
            best, best_sc = _try(A, best, best_sc)

    # 2) One-sided geometric chains
    for b in (2, 3):
        for k in range(2, 60):
            A = [b ** i for i in range(k)]
            if max(A) > 10 ** 15:
                break
            best, best_sc = _try(A, best, best_sc)

    # 3) Two-sided geometric with unequal counts
    for b in (2, 3):
        for kp in range(1, 12):
            for km in range(1, 12):
                A = sorted(set([0] + [b ** i for i in range(kp)] + [-b ** i for i in range(km)]))
                best, best_sc = _try(A, best, best_sc)

    # 4) Union of two scaled geometric chains (near-optimal Moser-like family)
    #    A = {b^i} ∪ {c b^j} for small c, various b.
    for b in (2, 3, 4, 5):
        for c in (1, 2, 3, 4, 5, 6, 7, 8):
            for k1 in range(2, 16):
                for k2 in range(2, 16):
                    if time.time() > deadline:
                        break
                    chain1 = [b ** i for i in range(k1)]
                    chain2 = [c * (b ** j) for j in range(k2)]
                    A = sorted(set(chain1 + chain2 + [-x for x in chain1] + [-x for x in chain2]))
                    if len(set(A)) > 4000:
                        break
                    best, best_sc = _try(A, best, best_sc)
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # 5) Mixed chains at distinct scales: {a^i} ∪ {b^j}
    for a in (2, 3):
        for b in (3, 4, 5):
            if a == b:
                continue
            for k1 in range(2, 14):
                for k2 in range(2, 14):
                    if time.time() > deadline:
                        break
                    chain1 = [a ** i for i in range(k1)]
                    chain2 = [b ** j for j in range(k2)]
                    A = sorted(set(chain1 + chain2 + [-x for x in chain1] + [-x for x in chain2]))
                    if len(set(A)) > 4000:
                        break
                    best, best_sc = _try(A, best, best_sc)
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # 6) Digit-product search
    cands = _digit_candidates()
    bases = list(range(2, 33))
    size_search = 1500

    for D in cands:
        if time.time() > deadline:
            break
        dsz = len(D)
        k = 1
        while dsz ** (k + 1) <= size_search:
            k += 1
        if k < 2:
            continue
        for b in bases:
            if time.time() > deadline:
                break
            for kk in (k, max(2, k - 1)):
                if dsz ** kk > size_search:
                    continue
                A = _build(D, b, kk)
                if len(set(A)) < 3:
                    continue
                best, best_sc = _try(A, best, best_sc)

    # 7) Extend best alphabet toward cap
    for D in cands:
        if time.time() > deadline:
            break
        dsz = len(D)
        for b in (2, 3, 4, 5, 8, 16, 32):
            if time.time() > deadline:
                break
            k = 1
            while dsz ** (k + 1) <= 4000:
                k += 1
            if k < 2 or dsz ** k > 4000:
                continue
            A = _build(D, b, k)
            if len(set(A)) < 3:
                continue
            best, best_sc = _try(A, best, best_sc)

    best = sorted(set(best))
    best = [x for x in best if abs(x) <= 10 ** 15]
    if len(best) > 4000:
        best = best[:4000]
    if len(best) < 2:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
