# EVOLVE-BLOCK-START
"""Search directly for an integer set A maximizing log|A-A|/log|A+A|.

Core idea: pick a base-B digit set S with good log|S-S|/log|S+S| ratio, tensor
it up to as large a set as fits (<=4000, |value|<=1e15), then run a directed
local search on the *full* set using fast numpy scoring to push the ratio up
further by exploiting extra sum-collisions from the periodic structure.
"""
import math
import itertools
import random
import time

import numpy as np


def _stats(S):
    U = set()
    D = set()
    for a in S:
        for b in S:
            U.add(a + b)
            D.add(a - b)
    return U, D


def _ratio(S):
    U, D = _stats(S)
    if len(U) < 2 or len(D) < 2:
        return -1.0
    return math.log(len(D)) / math.log(len(U))


def _score_np(A):
    A = np.asarray(A, dtype=np.int64)
    n = A.size
    if n < 2:
        return 0.0
    d = A[:, None] - A[None, :]
    s = A[:, None] + A[None, :]
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _best_digit_set(deadline):
    # Small exhaustive search over tiny alphabets.
    bestS = (0, 1)
    bestR = -1.0
    R = 12
    for sz in range(2, 6):
        for comb in itertools.combinations(range(-R, R + 1), sz):
            r = _ratio(comb)
            if r > bestR:
                bestR = r
                bestS = comb

    # Hill climb on digit alphabet (bigger sizes).
    while time.time() < deadline:
        sz = random.randint(5, 20)
        S = set(random.sample(range(-120, 121), sz))
        r = _ratio(S)
        if r > bestR:
            bestR = r
            bestS = tuple(sorted(S))
        for _ in range(80):
            if time.time() > deadline:
                break
            T = list(S)
            T[random.randrange(len(T))] = random.randint(-120, 120)
            T = set(T)
            if len(T) < 2:
                continue
            rr = _ratio(T)
            if rr > bestR:
                bestR = rr
                bestS = tuple(sorted(T))
            if rr >= r:
                S = T
                r = rr
    return list(bestS)


def _tensor(S, max_n=4000, max_mag=10 ** 15):
    U, D = _stats(S)
    B = max(max(abs(x) for x in U), max(abs(x) for x in D)) + 1
    if B < 2:
        B = 2
    maxabs = max(abs(x) for x in S)
    bestA = None
    k = 1
    while True:
        size = len(S) ** k
        if size > max_n:
            break
        mag = maxabs * (B ** k - 1) // (B - 1) if B > 1 else 0
        if mag > max_mag:
            break
        A = [0]
        p = 1
        for _ in range(k):
            nxt = []
            for a in A:
                for d in S:
                    nxt.append(a + d * p)
            A = nxt
            p *= B
        if len(set(A)) <= max_n:
            bestA = A
        k += 1
    if bestA is None:
        bestA = list(S)
    return sorted(set(int(x) for x in bestA))


def solve():
    deadline = time.time() + 100.0

    S = _best_digit_set(time.time() + 35.0)
    cand = _tensor(S)

    # Direct directed local search on the full candidate set.
    work = list(cand)
    base_score = _score_np(work)
    n = len(work)

    # Neighborhood: perturb coordinates and shifts, accept improving moves.
    climb = time.time() + 60.0
    span = 1
    if n >= 2:
        span = max(1, (work[-1] - work[0]) // max(1, n))
    step = max(1, span)
    while time.time() < climb:
        i = random.randrange(n)
        old = work[i]
        r = random.random()
        if r < 0.45:
            work[i] = old + random.randint(-step, step)
        elif r < 0.80:
            work[i] = old - old // 2 if old != 0 else old + step
        else:
            work[i] = old + step
        work[i] = int(work[i])
        if abs(work[i]) > 10 ** 15:
            work[i] = old
            continue
        # keep sorted-unique
        if work[i] in work and work[i] != old:
            work[i] = old
            continue
        sc = _score_np(work)
        if sc > base_score:
            base_score = sc
            work.sort()
        else:
            work[i] = old

    cand = sorted(set(int(x) for x in work))
    if len(cand) > 4000:
        cand = cand[:4000]
    cand = [int(x) for x in cand if abs(x) <= 10 ** 15]
    if len(cand) < 2:
        return [0, 1, 3]
    return cand
# EVOLVE-BLOCK-END
