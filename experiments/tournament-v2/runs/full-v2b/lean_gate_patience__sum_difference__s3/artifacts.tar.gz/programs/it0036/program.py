# EVOLVE-BLOCK-START
"""Construct sets with many differences, few sums.

Main idea: use unions of scaled geometric chains A = {0} u union_j {+/- c_j * b^i}.
Doubling a signed term cancels or stays in the compressed family, so |A+A|
stays small while |A-A| approaches |A|^2.  We search over (base, multipliers,
lengths) and pick the best by an exact (time-bounded) score.
"""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return -1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _geometric_sym(k, base=2, c=1):
    a = [0]
    p = 1
    for _ in range(k):
        a.append(c * p)
        a.append(-c * p)
        p *= base
    return a


def _union_chains(base, mults, length):
    """{0} u {+/- c * base^i : c in mults, i in 0..length-1}."""
    a = [0]
    p = 1
    for _ in range(length):
        for c in mults:
            a.append(c * p)
            a.append(-c * p)
        p *= base
    return a


def solve():
    deadline = time.time() + 100.0
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    def consider(a):
        nonlocal best, best_score
        a = list(set(a))
        if not (2 <= len(a) <= 4000):
            return
        if max(abs(x) for x in a) > 10**15:
            return
        s = _score(a)
        if s > best_score:
            best_score, best = s, a

    # 1) single symmetric geometric sets
    for base in (2, 3):
        for c in (1, 2, 3):
            k = 1
            while True:
                a = _geometric_sym(k, base, c)
                if len(a) > 4000:
                    break
                if max(abs(x) for x in a) > 10**15:
                    break
                consider(a)
                k += 1
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # 2) unions of scaled geometric chains
    mult_sets = [
        [1, 2], [1, 3], [1, 2, 3], [1, 2, 4], [1, 3, 9], [1, 2, 3, 4],
        [1, 5], [2, 3], [1, 2, 5], [1, 2, 3, 4, 5],
    ]
    for base in (2, 3, 4):
        for mults in mult_sets:
            if max(mults) >= base and base == 2:
                pass
            k = 1
            while True:
                if time.time() > deadline:
                    break
                a = _union_chains(base, mults, k)
                if len(a) > 4000:
                    break
                if max(abs(x) for x in a) > 10**15:
                    break
                consider(a)
                k += 1
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    return sorted(set(best))
# EVOLVE-BLOCK-END
