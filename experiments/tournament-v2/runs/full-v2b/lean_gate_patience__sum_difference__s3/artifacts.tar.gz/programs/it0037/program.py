import math
import time
from itertools import product


def _score(a):
    a = set(a)
    if len(a) < 2:
        return -1e9
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build(b, digits, positions):
    """All sums of d*p for d in digits, p in positions."""
    cur = {0}
    for p in positions:
        nxt = set()
        for v in cur:
            for d in digits:
                nxt.add(v + d * p)
        cur = nxt
    return cur


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    deadline = time.time() + 110

    # search parameters
    for npos in range(2, 7):
        if time.time() > deadline:
            break
        for b in range(3, 30):
            if time.time() > deadline:
                break
            for k in range(2, 6):
                if time.time() > deadline:
                    break
                if k ** npos > 4000:
                    continue
                # digit alphabets: consecutive blocks including 0, plus symmetric
                candidates = []
                for start in range(0, b):
                    ds = list(range(start, min(start + k, b)))
                    if len(ds) == k:
                        candidates.append(tuple(ds))
                # symmetric around some center
                for c in range(1, b):
                    off = k // 2
                    ds = [c - off + i for i in range(k)]
                    if all(0 <= d < b for d in ds):
                        candidates.append(tuple(ds))

                seen = set()
                for digits in candidates:
                    if digits in seen:
                        continue
                    seen.add(digits)
                    positions = [b ** i for i in range(npos)]
                    a = _build(b, digits, positions)
                    if not (2 <= len(a) <= 4000):
                        continue
                    if max(abs(x) for x in a) > 10 ** 15:
                        continue
                    s = _score(list(a))
                    if s > best_score:
                        best_score = s
                        best = sorted(a)

    # refine: try shifting / scaling the best found structure lightly
    return sorted(set(best))
