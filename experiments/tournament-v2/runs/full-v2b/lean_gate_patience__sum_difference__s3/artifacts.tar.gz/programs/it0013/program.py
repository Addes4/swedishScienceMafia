# EVOLVE-BLOCK-START
"""Base-b digit-pattern search followed by a fast local optimizer on |A-A|/|A+A|."""
import math
import time
import numpy as np


def _fast_sizes(a):
    a = np.asarray(list(set(int(x) for x in a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0, 0
    d = a[:, None] - a[None, :]
    s = a[:, None] + a[None, :]
    return np.unique(d).size, np.unique(s).size


def _score_from_sizes(nd, ns, n):
    if ns <= 0 or n < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score_fast(a):
    nd, ns = _fast_sizes(a)
    n = len(set(a))
    return _score_from_sizes(nd, ns, n), nd, ns


def _build(base, digit_set, dim):
    A = [0]
    p = 1
    for _ in range(dim):
        A = list({a + d * p for a in A for d in digit_set})
        p *= base
        if len(A) > 4000:
            return None
    return A


def _local_optimize(a, deadline):
    a = sorted(set(int(x) for x in a))
    best_score, _, _ = _score_fast(a)
    best = list(a)
    n = len(a)
    if n < 2:
        return best, best_score
    span = max(a) - min(a) if len(a) > 1 else 1
    scale = max(1, span // max(1, n))
    rng = np.random.default_rng(12345)
    steps = 0
    while time.time() < deadline:
        steps += 1
        arr = list(best)
        mode = steps % 3
        if mode == 0:
            # perturb one element
            i = int(rng.integers(n))
            delta = int(rng.integers(-scale, scale + 1))
            if delta == 0:
                delta = 1
            arr[i] = arr[i] + delta
        elif mode == 1:
            # mirror one element around center
            i = int(rng.integers(n))
            lo, hi = min(arr), max(arr)
            arr[i] = lo + hi - arr[i]
        else:
            # small block shift
            i = int(rng.integers(n))
            j = min(n, i + int(rng.integers(1, 4)))
            shift = int(rng.integers(-scale, scale + 1)) or 1
            for k in range(i, j):
                arr[k] += shift
        arr = sorted(set(arr))
        if len(arr) < 2 or len(arr) > 4000:
            continue
        if max(abs(x) for x in arr) > 10**15:
            continue
        s, nd, ns = _score_fast(arr)
        if s > best_score:
            best_score = s
            best = arr
            n = len(arr)
            span = max(arr) - min(arr)
            scale = max(1, span // max(1, n))
    return best, best_score


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 90  # leave room for local optimization

    digit_candidates = []
    for k in range(2, 6):
        digit_candidates.append(tuple(range(k)))
        digit_candidates.append(tuple(range(-k, k + 1)))
    digit_candidates += [
        (0, 1), (0, 1, 3), (0, 1, 2, 4), (0, 1, 4), (0, 2, 3),
        (-1, 0, 1), (-2, -1, 0, 1, 2), (0, 1, 5), (0, 3, 4),
        (0, 1, 2, 5), (0, 1, 3, 4), (1, 3, 4), (1, 2, 4),
        (0, 1, 2, 3, 4, 5), (0, 1, 2, 4, 5, 6),
    ]
    seen = set()
    dc = []
    for d in digit_candidates:
        key = tuple(sorted(set(d)))
        if key not in seen and len(key) >= 2:
            seen.add(key)
            dc.append(key)
    digit_candidates = dc

    bases = list(range(3, 30))

    trials = []
    for d in digit_candidates:
        for b in bases:
            maxdim = 1
            while len(d) ** maxdim <= 4500:
                maxdim += 1
            for dim in range(1, maxdim):
                trials.append((b, d, dim))
    trials.sort(key=lambda t: (-len(t[1]), t[2]))

    for base, dset, dim in trials:
        if time.time() > deadline:
            break
        A = _build(base, dset, dim)
        if A is None or len(A) < 8 or len(A) > 4000:
            continue
        s, nd, ns = _score_fast(A)
        if s > best_score:
            best_score = s
            best = list(A)

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    # Local optimization phase.
    opt_deadline = time.time() + max(0, 120 - (time.time() - (deadline - 90)))
    remaining = 118 - (time.time() - (deadline - 90))
    end = time.time() + max(1.0, remaining)
    cand, cs = _local_optimize(best, end)
    if cs > best_score:
        best_score = cs
        best = cand

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
