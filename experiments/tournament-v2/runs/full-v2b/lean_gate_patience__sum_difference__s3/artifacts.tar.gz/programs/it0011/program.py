# EVOLVE-BLOCK-START
"""Block-power construction search.

Key idea: take powers of a large base B (so differences between distinct powers are
"far apart" and mostly distinct), and then take several scaled/offset copies of this
power set.  Copies produce heavy sum collisions (since c1*B^i + c2*B^j patterns overlap
across copies) while the difference set keeps expanding.  We score exactly using the
problem's own figure of merit (including the (1 - 1/|A|)/100 size bonus) and search a
small parameter grid with the full time budget.
"""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    diffs = set()
    sums = set()
    for x in a:
        xd = x
        for y in a:
            diffs.add(xd - y)
            sums.add(xd + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _valid(a):
    if not (2 <= len(a) <= 4000):
        return False
    return all(abs(x) <= 10**15 for x in a)


def solve():
    deadline = time.time() + 110.0
    best = []
    best_score = -1.0

    def consider(a):
        nonlocal best, best_score
        s = set(a)
        if not _valid(s):
            return
        a = sorted(s)
        sc = _score(a)
        if sc > best_score:
            best_score = sc
            best = a

    # --- Family A: single power set, controlled length (baseline sanity) ---
    LIMIT = 10**15
    for B in [2, 3, 4, 5, 6, 7, 10, 16, 31, 100, 1000, 10**4, 10**6, 10**9, 10**12]:
        powers = []
        v = 1
        while v <= LIMIT:
            powers.append(v)
            v *= B
        consider(powers)
        if time.time() > deadline:
            return best

    # --- Family B: union of scaled copies of the same power set ---
    # A = { c_j * B^i } for a small set of multipliers c_j.  Sums collide across copies.
    multipliers_sets = [
        [1, 2], [1, 3], [1, 2, 3], [1, 2, 4], [1, 3, 9], [1, 2, 3, 4],
        [1, 2, 5], [1, 2, 3, 5], [1, 2, 4, 8], [1, 1, 2], [2, 3, 5],
        [1, 2, 3, 4, 5], [1, 2, 3, 4, 6], [1, 3, 5, 7], [1, 2, 4, 8, 16],
    ]
    bases = [2, 3, 4, 5, 6, 7, 10, 16, 31, 100, 1000, 10**4, 10**6]

    for B in bases:
        powers = []
        v = 1
        while v * max(multipliers_sets[0]) <= LIMIT:
            powers.append(v)
            v *= B
        for mults in multipliers_sets:
            if time.time() > deadline:
                return best
            cmax = max(mults)
            # build truncated list of powers such that c*p <= LIMIT
            cut = []
            for p in powers:
                if p * cmax <= LIMIT:
                    cut.append(p)
                else:
                    break
            for k in range(2, len(cut) + 1):
                base_set = cut[:k]
                a = []
                for c in mults:
                    for p in base_set:
                        a.append(c * p)
                consider(a)
                if time.time() > deadline:
                    return best

    # --- Family C: copies with additive offsets, which further boost collisions ---
    # A = { c_j * B^i + o_j }
    offsets = [0, 1, -1, 2, -2]
    for B in [2, 3, 5, 10, 100, 1000, 10**6]:
        powers = []
        v = 1
        while v * 4 <= LIMIT:
            powers.append(v)
            v *= B
        for c1, c2 in [(1, 2), (1, 3), (1, 2), (2, 3), (1, 4)]:
            for o1 in offsets:
                for o2 in offsets:
                    if time.time() > deadline:
                        return best
                    for k in range(2, len(powers) + 1):
                        base_set = powers[:k]
                        a = []
                        for p in base_set:
                            a.append(c1 * p + o1)
                            a.append(c2 * p + o2)
                        consider(a)
                        if time.time() > deadline:
                            return best

    # --- Family D: mixed — powers plus a geometric tail with different ratio ---
    for B in [3, 5, 10, 100, 1000]:
        for C in [B * B, B + 1, 2 * B, B * B + 1]:
            if time.time() > deadline:
                return best
            a = []
            v = 1
            while v <= LIMIT:
                a.append(v)
                v *= B
            w = 1
            while w <= LIMIT:
                a.append(w)
                w *= C if C > 1 else 1
            consider(a)

    # --- Family E: final local refinement around the best found (single-element moves) ---
    import random
    random.seed(987654321)
    if best:
        cur = list(best)
        cur_sc = best_score
        while time.time() < deadline:
            cand = list(cur)
            i = random.randrange(len(cand))
            step = random.choice([1, -1])
            mag = 10 ** random.randint(0, 8)
            cand[i] += step * mag
            consider(cand)
            if best_score > cur_sc:
                cur = list(best)
                cur_sc = best_score
            else:
                cur = list(best)
                cur_sc = best_score

    return best
# EVOLVE-BLOCK-END
