# EVOLVE-BLOCK-START
"""Search over base-b digit-product sets A = { sum d_i b^i : d_i in D }.

Theory: A-A has digits in D-D, A+A has digits in D+D, so the ratio
log|D-D|/log|D+D| (modulo carries) governs the asymptotic score. We enumerate
digit alphabets D broadly, and for each we build the full integer set A at the
largest length fitting the 4000-element cap, scoring it exactly.
"""
import math
import time
import itertools
import numpy as np


def _count_unique(a, chunk=400):
    """Return (|A-A|, |A+A|) via chunked numpy uniqueness."""
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    n = len(a)
    ds = set()
    ss = set()
    for s in range(0, n, chunk):
        blk = a[s:s + chunk]
        ds.update(np.unique(blk[:, None] - a[None, :]).tolist())
        ss.update(np.unique(blk[:, None] + a[None, :]).tolist())
    return len(ds), len(ss)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _count_unique(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _build(D, b, k):
    vals = [0]
    pw = 1
    for _ in range(k):
        vals = [v + d * pw for d in D for v in vals]
        pw *= b
    return vals


def _digit_ratio(D):
    ss = len({x + y for x in D for y in D})
    dd = len({x - y for x in D for y in D})
    if ss < 2 or dd < 2:
        return -1.0
    return math.log(dd) / math.log(ss)


def _candidate_alphabets():
    """Enumerate all D within a window, keeping top digit-ratio ones."""
    raw = []
    # All subsets of a wide integer window, sizes 2..6
    window = list(range(-3, 5))  # -3..4
    for size in range(2, 7):
        for c in itertools.combinations(window, size):
            raw.append(list(c))
    # Some hand-picked multiplicative-flavoured alphabets
    for D in ([0, 1, 2, 4], [0, 1, 2, 4, 8], [1, 2, 4, 8, 16],
              [-1, 0, 1], [0, 1, 3], [0, 1, 3, 7], [0, 1, 3, 7, 15],
              [0, 1, 3, 9, 27], [0, 1, 2, 3], [-2, -1, 0, 1],
              [0, 2, 3], [0, 1, 4], [0, 1, 2, 5], [-1, 0, 1, 2]):
        raw.append(D)

    seen = set()
    scored = []
    for D in raw:
        t = tuple(sorted(D))
        if t in seen:
            continue
        seen.add(t)
        r = _digit_ratio(D)
        if r < 0:
            continue
        scored.append((r, list(D)))
    scored.sort(key=lambda x: -x[0])
    return scored


def solve():
    deadline = time.time() + 108

    best = [7, 15, 18, 22, -3, -2]
    best_sc = _score(best)

    # Strong known family: symmetric geometric chains
    for b in (2, 3, 4, 5, 6, 7):
        for k in range(2, 14):
            A = sorted(set([0] + [b ** i for i in range(k)] + [-(b ** i) for i in range(k)]))
            if not (2 <= len(A) <= 4000):
                continue
            if abs(A[-1]) > 10 ** 15:
                continue
            s = _score(A)
            if s > best_sc:
                best_sc = s
                best = A

    # One-sided geometric chains
    for b in (2, 3):
        for k in range(2, 60):
            A = [b ** i for i in range(k)]
            if max(A) > 10 ** 15:
                break
            s = _score(A)
            if s > best_sc:
                best_sc = s
                best = A

    # Two-sided geometric with independent counts
    for b in (2, 3):
        for kp in range(1, 12):
            for km in range(1, 12):
                pos = [b ** i for i in range(kp)]
                neg = [-b ** i for i in range(km)]
                A = sorted(set([0] + pos + neg))
                if not (2 <= len(A) <= 4000):
                    continue
                if abs(A[-1]) > 10 ** 15 or abs(A[0]) > 10 ** 15:
                    continue
                s = _score(A)
                if s > best_sc:
                    best_sc = s
                    best = A

    # Digit-product search, ranked by digit-level ratio
    scored_alphas = _candidate_alphabets()
    bases = list(range(2, 25))

    # First pass: top alphabets by digit ratio, full-size builds
    for r, D in scored_alphas[:200]:
        if time.time() > deadline:
            break
        dsz = len(D)
        if dsz < 2:
            continue
        # maximal k with dsz^k <= 4000
        k = 0
        p = 1
        while p * dsz <= 4000:
            p *= dsz
            k += 1
        if k < 2:
            continue
        for b in bases:
            if time.time() > deadline:
                break
            # ensure no overflow / giant values
            if b ** (k - 1) > 10 ** 15:
                break
            A = _build(D, b, k)
            if len(set(A)) < 3:
                continue
            s = _score(A)
            if s > best_sc:
                best_sc = s
                best = A

    # Second pass: also try k-1 for the very best alphabets
    for r, D in scored_alphas[:40]:
        if time.time() > deadline:
            break
        dsz = len(D)
        k = 0
        p = 1
        while p * dsz <= 4000:
            p *= dsz
            k += 1
        for kk in (max(2, k - 1), max(2, k - 2)):
            for b in (2, 3, 4, 5, 8, 16, 32):
                if time.time() > deadline:
                    break
                if b ** (kk - 1) > 10 ** 15:
                    break
                A = _build(D, b, kk)
                if len(set(A)) < 3:
                    continue
                s = _score(A)
                if s > best_sc:
                    best_sc = s
                    best = A

    best = sorted(set(best))
    best = [x for x in best if abs(x) <= 10 ** 15]
    if len(best) > 4000:
        best = best[:4000]
    if len(best) < 2:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
