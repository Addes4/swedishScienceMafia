# EVOLVE-BLOCK-START
"""Search over base-b digit-product sets A = { sum d_i b^i : d_i in D }.

Theoretical guide: the difference set A-A has digits in D-D while A+A has
digits in D+D, so a large ratio log|D-D|/log|D+D| at the digit level (with
carries possibly tweaking it) points at good alphabets. We find the best
small alphabets D by exhaustive/local search, prune by the cheap digit-level
estimate, then score the actual integer set exactly.
"""
import math
import time
import itertools
import random
import numpy as np


def _count_unique(a, chunk=400):
    """Return (|A-A|, |A+A|) via chunked numpy uniqueness."""
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    n = len(a)
    ds = set()
    ss = set()
    for s in range(0, n, chunk):
        blk = a[s:s + chunk]
        ds.update(np.unique(blk[:, None] - a[None, :]).tolist())
        ss.update(np.unique(blk[:, None] + a[None, :]).tolist())
    return len(ds), len(ss)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _count_unique(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _build(D, b, k):
    vals = [0]
    pw = 1
    for _ in range(k):
        vals = [v + d * pw for d in D for v in vals]
        pw *= b
    return vals


def _digit_ratio(D):
    ss = len({x + y for x in D for y in D})
    dd = len({x - y for x in D for y in D})
    if ss < 2 or dd < 2:
        return 0.0
    return math.log(dd) / math.log(ss)


def _search_seeds():
    """Find small integer sets D maximizing the digit-level ratio."""
    scored = []

    # Exhaustive over small ranges, fixing min=0 (translation invariant ratio)
    for size in (3, 4, 5):
        for c in itertools.combinations(range(0, 14), size - 1):
            D = [0] + list(c)
            r = _digit_ratio(D)
            scored.append((r, D))

    # Local random search over slightly larger sets
    rng = random.Random(12345)
    for _ in range(6000):
        size = rng.randint(3, 7)
        D = sorted(set(rng.randint(-12, 12) for _ in range(size)))
        if len(D) < 3:
            continue
        r = _digit_ratio(D)
        scored.append((r, D))

    # Greedy hill-climb refinement of the best ones
    scored.sort(key=lambda t: -t[0])
    for _, seed in scored[:15]:
        cur = list(seed)
        cur_r = _digit_ratio(cur)
        improved = True
        while improved:
            improved = False
            for i in range(len(cur)):
                for delta in (-3, -2, -1, 1, 2, 3):
                    trial = sorted(set(cur[:i] + [cur[i] + delta] + cur[i + 1:]))
                    if len(trial) < 3:
                        continue
                    r = _digit_ratio(trial)
                    if r > cur_r + 1e-12:
                        cur, cur_r = trial, r
                        improved = True
                        break
                if improved:
                    break

    seen = set()
    out = []
    scored2 = scored + [(cur_r, cur)]
    scored2.sort(key=lambda t: -t[0])
    for r, D in scored2:
        t = tuple(sorted(D))
        if t in seen:
            continue
        seen.add(t)
        if r > 1.15:
            out.append((r, list(D)))
        if len(out) >= 40:
            break
    return out


def solve():
    deadline = time.time() + 105

    best = [7, 15, 18, 22, -3, -2]
    best_sc = _score(best)

    # Strong known family: symmetric geometric chains
    for b in (2, 3, 4, 5, 6, 7):
        for k in range(2, 14):
            A = sorted(set([0] + [b ** i for i in range(k)] + [-(b ** i) for i in range(k)]))
            if not (2 <= len(A) <= 4000):
                continue
            if abs(A[-1]) > 10 ** 15:
                continue
            s = _score(A)
            if s > best_sc:
                best_sc = s
                best = A

    # One-sided geometric chain
    for b in (2, 3):
        for k in range(2, 60):
            A = [b ** i for i in range(k)]
            if max(A) > 10 ** 15:
                break
            s = _score(A)
            if s > best_sc:
                best_sc = s
                best = A

    # Two-sided geometric with different counts
    for b in (2, 3):
        for kp in range(1, 12):
            for km in range(1, 12):
                A = sorted(set([0] + [b ** i for i in range(kp)] + [-b ** i for i in range(km)]))
                if not (2 <= len(A) <= 4000):
                    continue
                if abs(A[-1]) > 10 ** 15 or abs(A[0]) > 10 ** 15:
                    continue
                s = _score(A)
                if s > best_sc:
                    best_sc = s
                    best = A

    if len(best) == len(set(best)):
        pass  # placeholder

    # Seed-based digit search: use best small alphabets as D
    seeded = _search_seeds()
    cands = [D for r, D in seeded]
    # also keep classic hand-picked ones
    cands += [[0, 1, 2, 4], [0, 1, 2, 4, 8], [0, 1, 3, 7], [0, 1, 3, 7, 15],
              [0, 1, 3, 9, 27], [0, 1, 2, 4, 8, 16], [0, 1, 3, 9, 27, 81]]

    # dedupe
    seen = set()
    uniq = []
    for D in cands:
        t = tuple(sorted(D))
        if t in seen:
            continue
        seen.add(t)
        uniq.append(list(D))
    cands = uniq

    bases = list(range(2, 33))

    for D in cands:
        if time.time() > deadline:
            break
        dsz = len(D)
        k = 1
        while dsz ** (k + 1) <= 1500:
            k += 1
        if k < 2:
            continue
        for b in bases:
            if time.time() > deadline:
                break
            for kk in (k, max(2, k - 1)):
                if dsz ** kk > 1500:
                    continue
                A = _build(D, b, kk)
                if len(set(A)) < 3:
                    continue
                s = _score(A)
                if s > best_sc:
                    best_sc = s
                    best = A

    # Extend best alphabets toward the element cap
    for D in cands:
        if time.time() > deadline:
            break
        dsz = len(D)
        for b in (2, 3, 4, 5, 8, 16, 32):
            if time.time() > deadline:
                break
            k = 1
            while dsz ** (k + 1) <= 4000:
                k += 1
            if k < 2 or dsz ** k > 4000:
                continue
            A = _build(D, b, k)
            if len(set(A)) < 3:
                continue
            s = _score(A)
            if s > best_sc:
                best_sc = s
                best = A

    best = sorted(set(best))
    best = [x for x in best if abs(x) <= 10 ** 15]
    if len(best) > 4000:
        best = best[:4000]
    if len(best) < 2:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
