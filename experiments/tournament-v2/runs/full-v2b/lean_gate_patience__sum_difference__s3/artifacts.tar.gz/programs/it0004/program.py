# EVOLVE-BLOCK-START
"""Optimize log|A-A|/log|A+A| with a Bezout/quadratic-residue construction plus local search."""
import math
import random
import time


def _score(a):
    sa = set(a)
    n = len(sa)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    lst = list(sa)
    for x in lst:
        for y in lst:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    """Faster scoring reusing sets via iteration over indices."""
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _qr_sidon(p):
    """Quadratic residues mod p as a Sidon-like structure."""
    return [(i * i) % p for i in range(p)]


def _build_bezout(n, gap):
    """Build A = {i*gap + (i^2 mod m)}."""
    # choose m prime-ish near n
    m = n
    while True:
        ok = True
        i = 2
        while i * i <= m:
            if m % i == 0:
                ok = False
                break
            i += 1
        if ok and m > 2:
            break
        m += 1
    a = []
    seen = set()
    for i in range(n):
        v = i * gap + (i * i) % m
        if v in seen:
            v = i * gap + (i * i) % m + gap * m
        seen.add(v)
        a.append(v)
    return a


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 110

    # Try several constructions and parameter choices
    trials = []
    for n in (40, 60, 80, 100, 120, 150, 180, 200, 250, 300):
        for gap in (2 * n, 4 * n, n, 3 * n, 5 * n):
            trials.append((n, gap))

    random.shuffle(trials)

    for n, gap in trials:
        if time.time() > deadline:
            break
        a = _build_bezout(n, gap)
        s = _score_fast(a)
        if s > best_score:
            best_score = s
            best = a[:]

    # local search refinement
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        # random perturbation
        cand = cur[:]
        op = random.random()
        if op < 0.6:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-2, 2)
        elif op < 0.8 and len(cand) < 400:
            cand.append(random.randint(-1000, 1000))
        elif len(cand) > 5:
            i = random.randrange(len(cand))
            del cand[i]

        if len(set(cand)) < len(cand):
            continue

        s = _score_fast(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
