# EVOLVE-BLOCK-START
"""Search directly for an integer set A maximizing log|A-A|/log|A+A|.

Core idea: tensor a digit set S in a large base B. Then |A-A| = |S-S|^k and
|A+A| = |S+S|^k, so the ratio equals log|S-S|/log|S+S| independent of dimension,
while the bonus favors large |A| = |S|^k (capped at 4000). So the whole game is:
find a small digit set S with the best ratio, then tensor it as far as fits.
"""
import math
import itertools
import random
import time

import numpy as np


def _ratio_np(S):
    """log|S-S| / log|S+S| via numpy, S a 1-D int array."""
    d = S[:, None] - S[None, :]
    s = S[:, None] + S[None, :]
    nd = np.unique(d).size
    ns = np.unique(s).size
    if nd < 2 or ns < 2:
        return -1.0
    return math.log(nd) / math.log(ns)


def _ratio_set(S):
    S = np.asarray(sorted(set(S)), dtype=np.int64)
    if S.size < 2:
        return -1.0
    return _ratio_np(S)


def _score_np(A):
    A = np.asarray(A, dtype=np.int64)
    n = A.size
    if n < 2:
        return 0.0
    d = A[:, None] - A[None, :]
    s = A[:, None] + A[None, :]
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _find_digit_set(deadline):
    """Iterated local search over integer digit sets to maximize ratio."""
    bestS = (0, 1)
    bestR = _ratio_set(bestS)

    # Seeds: small dense windows around origin for several sizes.
    seeds = []
    for sz in range(2, 6):
        for comb in itertools.combinations(range(-3, 4), sz):
            seeds.append(comb)
    # a few random wider seeds
    for _ in range(40):
        sz = random.randint(5, 12)
        seeds.append(tuple(sorted(random.sample(range(-60, 61), sz))))

    for sd in seeds:
        r = _ratio_set(sd)
        if r > bestR:
            bestR = r
            bestS = sd

    # Iterated local search: mutate one element, accept improvements / sideways.
    while time.time() < deadline:
        sz = random.randint(4, 16)
        # start from bestS plus random extras, or a random set
        if random.random() < 0.5 and len(bestS) <= sz:
            base = set(bestS)
            while len(base) < sz:
                base.add(random.randint(-80, 80))
            S = base
        else:
            S = set(random.sample(range(-80, 81), sz))
        r = _ratio_set(S)
        if r > bestR:
            bestR = r
            bestS = tuple(sorted(S))
        Tt = list(S)
        local = 300
        for _ in range(local):
            if time.time() > deadline:
                break
            T = Tt[:]
            idx = random.randrange(len(T))
            if random.random() < 0.7:
                T[idx] = random.randint(-80, 80)
            else:
                # shift an element by a small amount
                T[idx] += random.randint(-5, 5)
            Tset = set(T)
            if len(Tset) < 2:
                continue
            rr = _ratio_set(Tset)
            if rr > bestR:
                bestR = rr
                bestS = tuple(sorted(Tset))
            if rr >= r:
                Tt = T
                r = rr
    return list(bestS), bestR


def solve():
    deadline = time.time() + 100.0

    ds_deadline = time.time() + 45.0
    S, bestR = _find_digit_set(ds_deadline)

    # ---- Tensor S in base B as far as fits ----
    Uset = set()
    Dset = set()
    for a in S:
        for b in S:
            Uset.add(a + b)
            Dset.add(a - b)
    B = max(max(abs(x) for x in Uset), max(abs(x) for x in Dset)) + 1
    if B < 2:
        B = 2
    maxabs = max(abs(x) for x in S)

    bestA = None
    k = 1
    while True:
        size = len(S) ** k
        if size > 4000:
            break
        mag = maxabs * (B ** k - 1) // (B - 1) if B > 1 else 0
        if mag > 10 ** 15:
            break
        A = [0]
        p = 1
        for _ in range(k):
            nxt = []
            for a in A:
                for d in S:
                    nxt.append(a + d * p)
            A = nxt
            p *= B
        if len(set(A)) <= 4000:
            bestA = A
        k += 1

    if bestA is None:
        bestA = list(S)

    cand = sorted(set(int(x) for x in bestA))

    if len(cand) > 4000:
        cand = cand[:4000]
    cand = [int(x) for x in cand if abs(x) <= 10 ** 15]
    if len(cand) < 2:
        return [0, 1, 3]
    return cand
# EVOLVE-BLOCK-END
