# EVOLVE-BLOCK-START
"""Direct hill-climbing on A using a fast numpy scorer for the sum/difference ratio."""
import math
import random
import numpy as np


def _score(a):
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    if sums == 0:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _score_set(A):
    a = np.asarray(A, dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    if sums == 0:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def solve():
    random.seed(12345)
    np.random.seed(12345)

    # Seed: base-3 digit tensor {-1,0,1}^k plus {0,3}-style, known strong family.
    def build(digits, base, k):
        vals = [0]
        p = 1
        ds = sorted(digits)
        for _ in range(k):
            vals = [v + d * p for v in vals for d in ds]
            p *= base
        return sorted(set(vals))

    best = build({-1, 0, 1}, 3, 7)
    # crop to <=4000 if needed
    if len(best) > 4000:
        best = best[:4000]
    best_score = _score_set(best)

    seeds = []
    for k in range(2, 8):
        for base in (2, 3, 4, 5):
            for digits in ({-1, 0, 1}, {0, 1}, {0, 1, 2}, {-1, 1}, {-2, -1, 0, 1, 2}):
                A = build(digits, base, k)
                if 2 <= len(A) <= 4000:
                    seeds.append(A)
    for A in seeds:
        if max(abs(x) for x in A) > 10**15:
            continue
        s = _score_set(A)
        if s > best_score:
            best, best_score = A, s

    # Local search: coordinate perturbation with occasional larger jumps.
    A = list(best)
    cur = best_score
    span = max(abs(x) for x in A) + 1
    for it in range(3000):
        B = list(A)
        mode = random.random()
        if mode < 0.6 and len(B) > 2:
            # perturb a few coordinates
            for _ in range(random.randint(1, 3)):
                i = random.randrange(len(B))
                delta = random.choice([-3, -2, -1, 1, 2, 3]) * max(1, span // 50)
                B[i] += delta
        elif mode < 0.85 and len(B) > 2:
            # replace a coordinate
            i = random.randrange(len(B))
            B[i] = random.randint(-span, span)
        else:
            # random restart-ish: shuffle value from elsewhere
            if len(B) > 2:
                i, j = random.sample(range(len(B)), 2)
                B[i] = B[j] + random.randint(-2, 2)
        B = sorted(set(B))
        if len(B) < 2 or len(B) > 4000:
            continue
        if max(abs(x) for x in B) > 10**15:
            continue
        s = _score_set(B)
        if s > cur:
            A, cur = B, s
            if s > best_score:
                best, best_score = B, s
        # occasional accept equal to escape plateaus
        elif s == cur and random.random() < 0.1:
            A = B

    return sorted(set(best))
# EVOLVE-BLOCK-END
