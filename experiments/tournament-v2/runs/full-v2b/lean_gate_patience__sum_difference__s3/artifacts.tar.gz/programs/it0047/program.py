# EVOLVE-BLOCK-START
"""Search over base-b digit constructions A = { sum_{i<L} d_i b^i : d_i in S }
with a fast exact scorer (set-based difference/sum computations) plus tuning of
the geometric/subset-sum family A = { sum of b^i over subsets of {0..k-1} }.

The key is to search a wider space of (base b, digit alphabet S, length L) and
score each candidate exactly, keeping the best log|A-A|/log|A+A|.
"""

import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) == 0 or len(diffs) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(S, b, L):
    vals = [0]
    pw = 1
    for _ in range(L):
        new = []
        for v in vals:
            for d in S:
                new.append(v + d * pw)
        vals = new
        pw *= b
    return sorted(set(vals))


def _subset_sums(b, k):
    """A = { sum_{i in T} b^i : T subset of {0..k-1} }."""
    vals = [0]
    pw = 1
    for _ in range(k):
        vals = vals + [v + pw for v in vals]
        pw *= b
    return sorted(set(vals))


def _digit_sets():
    cands = []
    for k in range(2, 8):
        cands.append(tuple(range(k)))
    cands.append((0, 2))
    cands.append((0, 3))
    cands.append((0, 1, 3))
    cands.append((0, 1, 4))
    cands.append((0, 2, 3))
    cands.append((0, 2, 5))
    cands.append((0, 1, 2, 4))
    cands.append((0, 1, 3, 7))
    cands.append((0, 1, 4, 6))
    cands.append((0, 2, 5, 9))
    cands.append((0, 1, 2, 5, 8))
    cands.append((0, 1, 3, 4, 9))
    out = []
    seen = set()
    for s in cands:
        s = tuple(sorted(set(s)))
        if len(s) >= 2 and s not in seen:
            seen.add(s)
            out.append(s)
    return out


def solve():
    deadline = time.time() + 100
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    best = sorted(set(best))

    digits = _digit_sets()

    # Phase 1: geometric/subset-sum family A = { sum b^i over subsets }.
    for b in range(2, 6):
        for k in range(2, 25):
            if 2 ** k > 4000:
                break
            if time.time() > deadline:
                break
            A = _subset_sums(b, k)
            if len(A) < 2 or len(A) > 4000:
                continue
            sc = _score(A)
            if sc > best_score:
                best_score = sc
                best = A[:]
        if time.time() > deadline:
            break

    # Phase 2: base-b digit-product families.
    for S in digits:
        d = len(S)
        if d < 2:
            continue
        for L in range(2, 9):
            size = d ** L
            if size < 6 or size > 1400:
                continue
            span = max(S) - min(S)
            for b in range(span + 1, span + 12):
                if time.time() > deadline:
                    break
                A = _build(S, b, L)
                if len(A) < 2:
                    continue
                sc = _score(A)
                if sc > best_score:
                    best_score = sc
                    best = A[:]
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # Phase 3: quick local refinement.
    if time.time() < deadline:
        cur = best[:]
        cur_score = best_score
        rng_state = 987654321
        while time.time() < deadline:
            rng_state = (1103515245 * rng_state + 12345) & 0x7FFFFFFF
            i = rng_state % len(cur)
            delta = (rng_state >> 8) % 5 - 2
            cand = cur[:]
            cand[i] += delta
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            sc = _score(cand)
            if sc >= cur_score:
                cur = cand
                cur_score = sc
                if sc > best_score:
                    best_score = sc
                    best = cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
