# EVOLVE-BLOCK-START
"""Structured digit-pattern construction for sets with many differences and few sums."""
import math
import time
from itertools import product

_START = time.time()
_BUDGET = 110.0


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(digits, base, k):
    """A = { sum_i d_i * base^i : d_i in digits }, all digit strings."""
    A = set()
    digits = list(digits)
    for combo in product(digits, repeat=k):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= base
        A.add(v)
    return list(A)


def _quick_ratio(digits, base, k):
    """Estimate ratio without building full score, for pruning."""
    d = len(set(digits))
    return d ** k


def solve():
    best = [0, 1]
    best_score = _score(best)

    # Candidate digit alphabets that tend to give additive collisions but
    # distinct differences in base-b expansion.
    digit_choices = [
        {0, 1},
        {0, 1, 2},
        {0, 1, 3},
        {0, 1, 4},
        {0, 1, 5},
        {0, 1, 2, 3},
        {0, 1, 3, 4},
        {0, 1, 4, 5},
        {1, 2},
        {1, 3},
        {1, 4},
        {1, 2, 3},
        {-1, 0, 1},
        {-1, 1},
        {-2, -1, 0, 1, 2},
    ]

    # Family A: digit patterns over small bases.
    for digits in digit_choices:
        ds = tuple(sorted(digits))
        d = len(set(digits))
        for base in range(2, 16):
            for k in range(2, 9):
                if _quick_ratio(digits, base, k) > 4000:
                    continue
                if _quick_ratio(digits, base, k) < 2:
                    continue
                if time.time() - _START > _BUDGET:
                    return sorted(set(best))
                A = _build(digits, base, k)
                if len(A) < 2 or len(A) > 4000:
                    continue
                mx = max(abs(x) for x in A)
                if mx > 10**15:
                    continue
                s = _score(A)
                if s > best_score:
                    best, best_score = A, s

    # Family B: full digit ranges [0, r] over bases -> arithmetic-like additive structure.
    for r in range(1, 6):
        digits = set(range(r + 1))
        d = r + 1
        for base in range(2, 16):
            for k in range(2, 9):
                if d ** k > 4000 or d ** k < 2:
                    continue
                if time.time() - _START > _BUDGET:
                    return sorted(set(best))
                mx = max(abs(x) for x in A) if False else None
                A = _build(digits, base, k)
                if len(A) < 2 or len(A) > 4000:
                    continue
                mx = max(abs(x) for x in A)
                if mx > 10**15:
                    continue
                s = _score(A)
                if s > best_score:
                    best, best_score = A, s

    return sorted(set(best))
# EVOLVE-BLOCK-END
