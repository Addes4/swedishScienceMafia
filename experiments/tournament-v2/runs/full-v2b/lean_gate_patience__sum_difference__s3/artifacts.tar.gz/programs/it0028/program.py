# EVOLVE-BLOCK-START
"""Construct sets via base-b digit patterns, where modular/additive collisions
force |A+A| small while base-b uniqueness keeps differences distinct."""
import math
import itertools
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(b, S, length):
    """A = {sum d_i b^i : d_i in S, i in 0..length-1}."""
    a = [0]
    p = 1
    for _ in range(length):
        a = [x + d * p for x in a for d in S]
        p *= b
    return a


def solve():
    """Return A with large |A-A| and small |A+A| using base-b digit constructions."""
    deadline = time.time() + 100.0
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Digit set families: start from a base digit set and add a few others.
    seeds = [
        [0, 1],
        [0, 1, 2],
        [0, 1, 3],
        [0, 1, 2, 3],
        [-1, 0, 1],
        [-1, 0, 1, 2],
        [0, 1, 2, 4],
        [-2, -1, 0, 1, 2],
    ]

    tried = set()
    for S0 in seeds:
        for b in range(3, 26):
            for extra in range(0, 3):
                S = S0[:]
                # deterministically expand digit set a bit
                k = len(S)
                for e in range(extra):
                    base = S0[e % len(S0)]
                    cand_d = base + (e + 1) * (1 if e % 2 == 0 else -1)
                    if cand_d not in S:
                        S.append(cand_d)
                S = sorted(set(S))
                if max(abs(d) for d in S) >= b:
                    continue
                # choose length so |A| stays under 4000 and max abs <= 1e15
                maxlen = 1
                while len(S) ** (maxlen + 1) <= 4000 and b ** (maxlen + 1) <= 10**15:
                    maxlen += 1
                for length in range(2, maxlen + 1):
                    key = (b, tuple(S), length)
                    if key in tried:
                        continue
                    tried.add(key)
                    if time.time() > deadline:
                        break
                    a = _build(b, S, length)
                    if len(a) > 4000:
                        continue
                    if max(abs(x) for x in a) > 10**15:
                        continue
                    s = _score(a)
                    if s > best_score:
                        best_score, best = s, a
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # Scale the best structure by a multiplier to grow magnitudes (ratio invariant).
    best = sorted(set(best))
    if _score(best) < best_score:
        best = _build(3, [0, 1], 2)
    return best
# EVOLVE-BLOCK-END
