# EVOLVE-BLOCK-START
"""Parametric base-representation search: build A from digit patterns in a large base.

Idea: choose a large base B. Represent integers as sums of digits * B^i. If digits are
chosen from a set D with |D+D| small relative to |D-D|, the resulting integer set inherits
this. We search over (B, digit-set) families and also directly over small digit vectors,
scoring exactly by the true integer difference/sum sets.
"""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build_from_digits(digits, base):
    # digits: list of (index, digit) pairs
    return [d * (base ** i) for (i, d) in digits]


def solve():
    random.seed(12345)
    deadline = time.time() + 110

    best = []
    best_score = -1.0

    def consider(a):
        nonlocal best, best_score
        a = sorted(set(a))
        if len(a) < 2 or len(a) > 4000:
            return
        if max(abs(x) for x in a) > 10**15:
            return
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a

    # ---- Family 1: base expansion with digit set {0,1,...,m-1} concentrated on few positions
    # Sums of digits-over-a-small-alphabet then have controlled sum set sizes.
    # We take digits all equal to 1 at many positions => A = {B^i} (powers), plus offsets.
    # For pure powers B^i (i=0..k-1): diffs are all distinct-ish, sums collide only via
    # cross terms B^i+B^j; ratio is good for large B.
    bases = [2, 3, 4, 5, 7, 10, 16, 31, 100, 1000, 10**4, 10**6, 10**9, 10**12, 10**15]
    for B in bases:
        for k in range(2, 800):
            a = [B ** i for i in range(k)]
            if a[-1] > 10**15:
                break
            consider(a)
            if time.time() > deadline:
                return best

    # ---- Family 2: powers of B with small digit multiplicities: shift by c*B^i
    for B in [3, 5, 10, 100, 1000, 10**6, 10**9, 10**12]:
        for k in range(2, 400):
            if B ** (k - 1) > 10**15:
                break
            for c in [1, 2, 3, -1]:
                a = [c * (B ** i) for i in range(k)]
                consider(a)
            if time.time() > deadline:
                return best

    # ---- Family 3: union of two power progressions (still structured sums)
    for B in [10, 100, 1000, 10**6]:
        for k in range(2, 200):
            if B ** (k - 1) > 10**15:
                break
            base_set = [B ** i for i in range(k)]
            for extra in [B ** (k + 1), 2 * B ** k, -B ** k]:
                a = base_set + [extra]
                consider(a)
            if time.time() > deadline:
                return best

    # ---- Family 4: digit vectors over a small alphabet {0,1} at sparse index positions with base B
    # We pick p positions and all 0/1 digit vectors -> set size 2^p; base large enough that
    # distinct digit vectors give distinct integers and sums mostly unique per vector-pair.
    for B in [10, 100, 1000, 10**4, 10**6]:
        for p in range(2, 13):
            positions = list(range(p))
            if B ** (p - 1) > 10**15:
                break
            for mask in range(1, 1 << p):
                a = [B ** i for i in positions if (mask >> i) & 1]
                consider(a)

    # ---- Family 5: random local search seeded from best power set (refinement)
    if best:
        cur = list(best)
        cur_score = best_score
        while time.time() < deadline:
            cand = list(cur)
            i = random.randrange(len(cand))
            delta = random.choice([-1, 1]) * random.randint(1, max(1, 10 ** random.randint(0, 6)))
            cand[i] += delta
            if random.random() < 0.1 and len(cand) < 3000:
                cand.append(random.randint(1, 10**12))
            consider(cand)
            if best_score > cur_score:
                cur, cur_score = list(best), best_score
            elif random.random() < 0.2:
                cur, cur_score = list(best), best_score

    return best
# EVOLVE-BLOCK-END
