# EVOLVE-BLOCK-START
"""Search over base-b digit-product sets A = { sum d_i b^i : d_i in D }.

Theoretical guide: the difference set A-A has digits in D-D while A+A has
digits in D+D, so a large ratio log|D-D|/log|D+D| at the digit level (with
carries possibly tweaking it) points at good alphabets. We prune alphabets by
this cheap estimate, then score the actual integer set with a fast exact
scorer, and finally extend the best pattern toward the 4000-element cap.
"""
import math
import time
import itertools
import numpy as np


def _count_unique(a, chunk=400):
    """Return (|A-A|, |A+A|) via chunked numpy uniqueness."""
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    n = len(a)
    ds = set()
    ss = set()
    for s in range(0, n, chunk):
        blk = a[s:s + chunk]
        ds.update(np.unique(blk[:, None] - a[None, :]).tolist())
        ss.update(np.unique(blk[:, None] + a[None, :]).tolist())
    return len(ds), len(ss)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _count_unique(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _build(D, b, k):
    vals = [0]
    pw = 1
    for _ in range(k):
        vals = [v + d * pw for d in D for v in vals]
        pw *= b
    return vals


def _digit_candidates():
    raw = []
    for lo in range(-4, 5):
        for hi in range(lo, lo + 5):
            D = list(range(lo, hi + 1))
            if 2 <= len(D) <= 5:
                raw.append(D)
    for size in (2, 3, 4):
        for c in itertools.combinations(range(-2, 5), size):
            raw.append(list(c))
    for D in ([0, 1, 2, 4], [0, 1, 2, 4, 8], [1, 2, 4, 8, 16],
              [-1, 0, 1], [0, 1, 3], [0, 1, 3, 7], [0, 1, 3, 7, 15],
              [0, 1, 3, 9, 27], [-2, -1, 0, 1], [0, 1, 2, 3]):
        raw.append(D)

    seen = set()
    scored = []
    for D in raw:
        t = tuple(sorted(D))
        if t in seen:
            continue
        seen.add(t)
        ss = len({x + y for x in D for y in D})
        dd = len({x - y for x in D for y in D})
        if ss < 2 or dd < 2:
            continue
        r = math.log(dd) / math.log(ss)
        scored.append((r, D))
    scored.sort(reverse=True)
    return [D for r, D in scored if r > 1.10][:20]


def solve():
    deadline = time.time() + 108

    best = [7, 15, 18, 22, -3, -2]
    best_sc = _score(best)

    # Strong known family: symmetric geometric chains A = {0} +- {sum b^i subsets}
    # Primary: {0} +- {b^i : i<k}
    for b in (2, 3, 4, 5, 6, 7):
        for k in range(2, 14):
            A = sorted(set([0] + [b ** i for i in range(k)] + [-(b ** i) for i in range(k)]))
            if not (2 <= len(A) <= 4000):
                continue
            if abs(A[-1]) > 10 ** 15:
                continue
            s = _score(A)
            if s > best_sc:
                best_sc = s
                best = A

    # Chain A = {2^i : i<k} (one-sided geometric) - differences ~ n^2, sums bigger
    for b in (2, 3):
        for k in range(2, 60):
            A = [b ** i for i in range(k)]
            if max(A) > 10 ** 15:
                break
            s = _score(A)
            if s > best_sc:
                best_sc = s
                best = A

    # Two-sided geometric with different counts
    for b in (2, 3):
        for kp in range(1, 12):
            for km in range(1, 12):
                pos = [b ** i for i in range(kp)]
                neg = [-b ** i for i in range(km)]
                A = sorted(set([0] + pos + neg))
                if not (2 <= len(A) <= 4000):
                    continue
                if abs(A[-1]) > 10 ** 15 or abs(A[0]) > 10 ** 15:
                    continue
                s = _score(A)
                if s > best_sc:
                    best_sc = s
                    best = A

    # Digit-product search
    cands = _digit_candidates()
    bases = list(range(2, 33))
    size_search = 1500

    for D in cands:
        if time.time() > deadline:
            break
        dsz = len(D)
        k = 1
        while dsz ** (k + 1) <= size_search:
            k += 1
        if k < 2:
            continue
        for b in bases:
            if time.time() > deadline:
                break
            for kk in (k, max(2, k - 1)):
                if dsz ** kk > size_search:
                    continue
                A = _build(D, b, kk)
                if len(set(A)) < 3:
                    continue
                s = _score(A)
                if s > best_sc:
                    best_sc = s
                    best = A

    # Extend best alphabet toward the element cap if promising
    for D in cands:
        if time.time() > deadline:
            break
        dsz = len(D)
        for b in (2, 3, 4, 5, 8, 16, 32):
            if time.time() > deadline:
                break
            k = 1
            while dsz ** (k + 1) <= 4000:
                k += 1
            if k < 2 or dsz ** k > 4000:
                continue
            A = _build(D, b, k)
            if len(set(A)) < 3:
                continue
            s = _score(A)
            if s > best_sc:
                best_sc = s
                best = A

    best = sorted(set(best))
    best = [x for x in best if abs(x) <= 10 ** 15]
    if len(best) > 4000:
        best = best[:4000]
    if len(best) < 2:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
