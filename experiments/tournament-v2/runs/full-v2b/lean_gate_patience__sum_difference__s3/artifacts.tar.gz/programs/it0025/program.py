# EVOLVE-BLOCK-START
"""Mixed-radix digit construction: many differences, few sums."""
import math
import numpy as np
from itertools import product


def _score_np(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0.0
    # differences
    d = a[:, None] - a[None, :]
    nd = np.unique(d).size
    s = a[:, None] + a[None, :]
    ns = np.unique(s).size
    if ns == 0:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _build_mixed(digit_sets, base):
    """A = sum_i d_i * base^i, d_i in digit_sets[i]."""
    A = [0]
    p = 1
    for ds in digit_sets:
        newA = []
        for v in A:
            for d in ds:
                newA.append(v + d * p)
        A = newA
        p *= base
    return list(set(A))


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score_np(best)

    # Candidate small digit sets (sum-poor, difference-rich)
    base_sets = [
        {0, 1},
        {0, 1, 3},
        {0, 1, 3, 7},
        {0, 1, 4},
        {0, 1, 4, 9},
        {-1, 0, 1},
        {-1, 1},
        {-2, -1, 1, 2},
        {0, 1, 2, 4},
        {0, 1, 5, 11},
    ]

    def consider(A):
        nonlocal best, best_score
        if len(A) < 2 or len(A) > 4000:
            return
        if max(abs(x) for x in A) > 10**15:
            return
        s = _score_np(A)
        if s > best_score:
            best, best_score = list(A), s

    # 1) pure tensor over base b, size limited to fill near 4000
    for ds in base_sets:
        for base in range(3, 16):
            k = 1
            sz = 1
            while sz * len(ds) <= 4000 and k < 9:
                sz *= len(ds)
                k += 1
            for kk in range(max(1, k - 1), k + 1):
                if kk < 1:
                    continue
                A = _build_mixed([ds] * kk, base)
                consider(A)

    # 2) mixed-radix: alternate two digit sets at different powers of base
    pairs = [
        ({0, 1}, {0, 1, 3}),
        ({0, 1}, {0, 1, 4}),
        ({-1, 0, 1}, {0, 1, 3}),
        ({0, 1, 3}, {0, 1, 4}),
        ({-1, 1}, {0, 1, 3}),
        ({0, 1}, {0, 1, 5}),
    ]
    for base in range(3, 16):
        for a, b in pairs:
            for k in range(2, 10):
                sz = 1
                dss = []
                for i in range(k):
                    d = a if i % 2 == 0 else b
                    dss.append(d)
                    sz *= len(d)
                if sz < 2 or sz > 4000:
                    continue
                A = _build_mixed(dss, base)
                consider(A)

    # 3) asymmetric: one "doubling" base-2 digit set {0,1} tensored to Sidon-ish
    for base in [2, 3, 4]:
        for k in range(2, 13):
            if 2 ** k > 4000:
                break
            A = _build_mixed([{0, 1}] * k, base)
            consider(A)

    # 4) large random-ish digit sets giving near-4000 sets
    for ds in [{0, 1, 3, 7, 15}, {0, 1, 3, 7}, {0, 1, 4, 11, 20}]:
        for base in range(5, 20):
            k = int(math.log(4000) / math.log(len(ds))) + 1
            for kk in range(max(1, k - 1), k + 1):
                if len(ds) ** kk > 4000 or kk < 1:
                    continue
                A = _build_mixed([ds] * kk, base)
                consider(A)

    best = sorted(set(int(x) for x in best))
    return best
# EVOLVE-BLOCK-END
