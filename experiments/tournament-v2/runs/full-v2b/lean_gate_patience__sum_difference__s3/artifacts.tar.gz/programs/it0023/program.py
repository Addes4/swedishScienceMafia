# EVOLVE-BLOCK-START
"""Structured digit-pattern construction for sets with many differences and few sums."""
import math
from itertools import product
import numpy as np


def _score(a):
    a = np.array(sorted(set(a)), dtype=np.int64)
    if len(a) < 2:
        return 0.0
    d = np.unique(a[:, None] - a[None, :])
    s = np.unique(a[:, None] + a[None, :])
    if len(s) == 0:
        return 0.0
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / len(a)) / 100


def _build(digit_set, base, k):
    """Build A = sums over positions i=0..k-1 of d_i * base^i, d_i in digit_set."""
    cur = np.array([0], dtype=object)
    p = 1
    for i in range(k):
        digits = np.array(sorted(digit_set), dtype=object)
        cur = (cur[:, None] + digits[None, :] * p).ravel()
        p *= base
    A = sorted(set(int(x) for x in cur))
    return A


def _tensor_score(digit_set, base, k):
    A = _build(digit_set, base, k)
    if len(A) < 2 or len(A) > 4000:
        return None, None
    if max(abs(x) for x in A) > 10**15:
        return None, None
    return _score(A), A


def _search_digit_sets():
    """Iterated local search over digit sets, scored by the tensor of the result."""
    bases = [2, 3, 4, 5, 6]
    best_score = -1.0
    best = [7, 15, 18, 22, -3, -2]

    # seed digit sets
    seeds = [
        {0, 1}, {-1, 0, 1}, {0, 1, 2}, {0, 1, 3}, {0, 1, 2, 3},
        {0, 1, 3, 4}, {0, 1, 4, 5}, {0, 1, 2, 4}, {1, 2}, {1, 2, 3},
        {0, 1, 2, 5}, {0, 1, 6}, {0, 1, 2, 3, 4}, {-1, 1}, {0, 2},
        {0, 1, 2, 4, 8},
    ]

    for seed in seeds:
        S = set(seed)
        for base in bases:
            # choose k so size fits <= 4000
            k = 1
            sz = len(S)
            while sz * len(S) <= 4000 and k < 12:
                sz *= len(S)
                k += 1
            if sz < 2:
                continue
            sc, _ = _tensor_score(S, base, k)
            if sc is not None and sc > best_score:
                best_score = sc
                best = _build(S, base, k)

    # local search: perturb digits
    rng = np.random.RandomState(12345)
    for seed in seeds:
        for base in bases:
            S = set(seed)
            for it in range(200):
                T = set(S)
                move = rng.randint(3)
                if move == 0 and len(T) > 2:
                    T.discard(int(rng.choice(sorted(T))))
                elif move == 1:
                    T.add(int(rng.randint(-8, 9)))
                else:
                    T = set(S)
                    T.add(int(rng.randint(-8, 9)))
                if len(T) < 2 or len(T) > 12:
                    continue
                k = 1
                sz = len(T)
                while sz * len(T) <= 4000 and k < 12:
                    sz *= len(T)
                    k += 1
                if sz < 2:
                    continue
                sc, A = _tensor_score(T, base, k)
                if sc is not None and sc > best_score:
                    best_score = sc
                    best = A
                    S = T
    return best


def solve():
    best = _search_digit_sets()

    # Fallback / extra explicit strong family: base-3 with {-1,0,1}
    for base, k in [(3, 7), (2, 11), (4, 5)]:
        try:
            A = _build({-1, 0, 1}, base, k)
            if 2 <= len(A) <= 4000 and max(abs(x) for x in A) <= 10**15:
                s = _score(A)
                if s > _score(best):
                    best = A
        except Exception:
            pass

    best = sorted(set(int(x) for x in best))
    return best
# EVOLVE-BLOCK-END
