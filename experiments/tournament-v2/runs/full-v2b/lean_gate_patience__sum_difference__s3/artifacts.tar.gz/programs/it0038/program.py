# EVOLVE-BLOCK-START
"""Structured construction: A = { sum d_i b^i : d_i in S } for small digit sets S and base b.

Idea: choose a base b and a small digit alphabet S (a Sidon-like set) so that
distinct base-b representations keep differences distinct (|A-A| large), while
the additive structure collapses many sums (|A+A| small). We search over digit
alphabets S, bases b and lengths k, then score exactly and keep the best.
"""
import math
import time
import itertools


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for j in range(i, n):
            y = a[j]
            sums.add(x + y)
            diffs.add(x - y)
            diffs.add(y - x)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1.0 / n) / 100


def _build(S, b, k):
    """All base-b numbers with k digits drawn from S (low->high order)."""
    vals = [0]
    pw = 1
    for _ in range(k):
        vals = [v + d * pw for d in S for v in vals]
        pw *= b
    return vals


def _digit_sets(limit):
    """Small candidate digit alphabets S."""
    cands = []
    # contiguous and near-contiguous alphabets
    for lo in range(-limit, limit + 1):
        for hi in range(lo, lo + min(4, 2 * limit + 1)):
            S = list(range(lo, hi + 1))
            if len(S) >= 2:
                cands.append(S)
    # Sidon-ish sets with a few elements
    base_pool = list(range(-limit, limit + 1))
    for size in (2, 3, 4):
        for combo in itertools.combinations(base_pool, size):
            S = list(combo)
            ss = {x + y for x in S for y in S}
            if len(ss) == size * (size + 1) // 2:  # Sidon-like
                cands.append(S)
    # ensure includes symmetric alphabet
    cands.append([-1, 0, 1])
    return cands


def _polish(a, deadline):
    """Greedy local polish keeping distinctness."""
    a = sorted(set(a))
    best = a[:]
    best_score = _score(best)
    step = 3
    while time.time() < deadline:
        improved = False
        for i in range(len(a)):
            for d in (-step, step):
                cand = a[:]
                cand[i] += d
                if cand[i] in cand[:i] + cand[i + 1:]:
                    continue
                s = _score(cand)
                if s > best_score:
                    best, best_score, a = cand[:], s, cand
                    improved = True
        if not improved:
            if step > 1:
                step -= 1
            else:
                break
    return best


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # baseline fallback
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    digit_cands = _digit_sets(3)
    bases = [3, 4, 5, 6, 7, 8, 10, 12, 16, 20]

    for S in digit_cands:
        if time.time() > deadline:
            break
        for b in bases:
            if b <= max(S) or b <= -min(S) + 1:
                continue
            for k in (2, 3, 4, 5, 6):
                if time.time() > deadline:
                    break
                if len(S) ** k > 4000:
                    continue
                A = _build(S, b, k)
                A = list(set(A))
                if len(A) < 2:
                    continue
                # rough prefilter
                n = len(A)
                if n > 4000:
                    continue
                s = _score(A)
                if s > best_score:
                    best, best_score = A[:], s

    # polish the best construction
    if best is not None:
        polished = _polish(best, deadline)
        ps = _score(polished)
        if ps > best_score:
            best, best_score = polished, ps

    best = sorted(set(best))
    best = [x for x in best if abs(x) <= 10**15]
    if len(best) > 4000:
        best = best[:4000]
    return best
# EVOLVE-BLOCK-END
