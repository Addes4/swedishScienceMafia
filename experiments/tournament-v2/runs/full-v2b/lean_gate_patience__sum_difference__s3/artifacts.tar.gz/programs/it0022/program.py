# EVOLVE-BLOCK-START
"""Structured digit-pattern construction for sets with many differences and few sums."""
import math
from itertools import combinations_with_replacement, product


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _candidate_from_digits(digits, base):
    """A = { sum d_i * b^i : each d_i in digits }, all length-k digit strings."""
    k = len(base) if isinstance(base, (list, tuple)) else None
    return None


def _build(digit_set, base, k):
    """Build A = sums over positions i=0..k-1 of d_i * base^i, d_i in digit_set."""
    sets = [digit_set]
    for i in range(1, k):
        sets.append(digit_set)
    A = []
    for combo in product(*sets):
        v = 0
        p = 1
        for d in combo:
            v += d * p
            p *= base
        A.append(v)
    return list(set(A))


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Family 1: digit-pattern sets in base b with small digit alphabets.
    # We want additive collisions (few sums) but distinct differences.
    # Try symmetric-ish digit sets and small bases.
    digit_choices = [
        {0, 1},
        {0, 1, 2},
        {0, 1, 3},
        {0, 1, 2, 3},
        {0, 1, 3, 4},
        {0, 1, 4, 5},
        {0, 1, 2, 4},
        {1, 2},
        {1, 2, 3},
        {1, 2, 4},
        {1, 3, 4},
        {0, 1, 2, 5},
        {0, 1, 6},
        {0, 1, 2, 3, 4},
    ]
    digit_choices += [{0, 1, d} for d in range(2, 9)]
    digit_choices += [{1, d} for d in range(2, 30)]

    # Also allow negative digits (shifts collapse differences)
    digit_choices += [{-1, 0, 1}, {-1, 1}, {-2, -1, 0, 1, 2}, {-1, 0, 1, 2}]

    tried = set()
    for digits in digit_choices:
        ds = tuple(sorted(digits))
        for base in range(2, 13):
            for k in range(2, 8):
                key = (ds, base, k)
                if key in tried:
                    continue
                tried.add(key)
                # limit size
                sz = len(digits) ** k
                if sz < 2 or sz > 3500:
                    continue
                A = _build(digits, base, k)
                if len(A) < 2 or len(A) > 4000:
                    continue
                mx = max(abs(x) for x in A)
                if mx > 10**15:
                    continue
                s = _score(A)
                if s > best_score:
                    best, best_score = A, s

    # Family 2: Cantor-like / small-sum sets: use A of form {0..n} mapped via base-b
    # digits from {0,1} gives subset-sum sets, known to have good difference/sum ratio.
    for base in range(2, 15):
        for k in range(2, 8):
            if 2 ** k > 3500:
                continue
            A = _build({0, 1}, base, k)
            if len(A) < 2:
                continue
            mx = max(abs(x) for x in A)
            if mx > 10**15:
                continue
            s = _score(A)
            if s > best_score:
                best, best_score = A, s

    # Family 3: shifted digit sets to reduce sums: use {-c..} patterns
    for base in range(2, 11):
        for k in range(2, 7):
            for r in range(1, 5):
                digits = set(range(r + 1))
                if len(digits) ** k > 3500:
                    continue
                A = _build(digits, base, k)
                if len(A) < 2:
                    continue
                s = _score(A)
                if s > best_score:
                    best, best_score = A, s

    # Family 4: perfect difference set style - arithmetic structure
    # A = { i + n*j : i in 0..m-1, j in 0..t-1 } gives grid, large diff, moderate sum.
    best = sorted(set(best))
    return best
# EVOLVE-BLOCK-END
