# EVOLVE-BLOCK-START
"""Construct sets with many differences, few sums.

Main families:
  * symmetric geometric: {0} u {+/- b^i}
  * binary digit sets: {sum d_i 2^i : d_i in S} for small S
  * union-of-two-geometrics.
Scored exactly, best kept.
"""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return -1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _geometric_sym(k, b=2):
    a = [0]
    p = 1
    for _ in range(k):
        a.append(p)
        a.append(-p)
        p *= b
    return a


def _digit_set(S, b, length):
    a = [0]
    p = 1
    for _ in range(length):
        a = [x + d * p for x in a for d in S]
        p *= b
    return a


def solve():
    deadline = time.time() + 100.0
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    def consider(a):
        nonlocal best, best_score
        a = list(set(a))
        if not (2 <= len(a) <= 4000):
            return
        if max(abs(x) for x in a) > 10**15:
            return
        s = _score(a)
        if s > best_score:
            best_score, best = s, a

    # 1) symmetric geometric sets, various bases
    for b in (2, 3):
        k = 1
        while True:
            a = _geometric_sym(k, b)
            if len(a) > 4000 or b ** (k - 1) > 10**15:
                break
            consider(a)
            k += 1
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # 2) one-sided powers of base b
    for b in (2, 3):
        k = 1
        while k <= 4000 and b ** (k - 1) <= 10**15:
            consider([b ** i for i in range(k)])
            k += 1
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # 3) digit tensors over small alphabets and bases
    seeds = [[0, 1], [-1, 0, 1], [0, 1, 2], [-1, 1], [0, 1, -2],
             [-2, -1, 0, 1, 2], [0, 1, 3], [-1, 0, 2], [1, 2], [0, 2],
             [-3, -1, 1, 3], [0, 1, 4]]
    for S0 in seeds:
        for b in range(2, 13):
            for length in range(2, 9):
                if time.time() > deadline:
                    break
                S = S0
                if max(abs(d) for d in S) >= b:
                    continue
                if len(S) ** length > 4000:
                    continue
                try:
                    if b ** (length - 1) > 10**15:
                        continue
                    a = _digit_set(S, b, length)
                except Exception:
                    continue
                consider(a)

    # 4) union of two geometrics / midpoints
    for b in (2, 3):
        for c in (1, 2, 3):
            k = 1
            while True:
                a = [0]
                p = 1
                for _ in range(k):
                    a.append(c * p)
                    a.append(-c * p)
                    p *= b
                if len(a) > 4000 or c * p // b > 10**15:
                    break
                consider(a)
                k += 1
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break

    # 5) {0} u {2^i} u {2^i + 2^(i+1)} (few-sum binary variants)
    for k in range(2, 25):
        base = [0] + [2 ** i for i in range(k)]
        a = list(base)
        for i in range(k - 1):
            a.append(2 ** i + 2 ** (i + 1))
        if max(a) > 10**15:
            break
        consider(a)
        if time.time() > deadline:
            break

    return sorted(set(best))
# EVOLVE-BLOCK-END

