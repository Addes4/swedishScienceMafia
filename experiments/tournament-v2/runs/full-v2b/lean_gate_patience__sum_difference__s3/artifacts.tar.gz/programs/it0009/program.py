# EVOLVE-BLOCK-START
"""Direct optimization of log|A-A|/log|A+A| over structured integer families.

Key structural facts used:
  * For A = {1, b, b^2, ..., b^(k-1)} with b large, the pair sums b^i + b^j are all
    distinct (as base-b digits) EXCEPT the symmetric ones, so |A+A| = k(k+1)/2.
    Likewise differences b^i - b^j are distinct, so |A-A| = k(k-1)+1.
    => ratio log(k^2)/log(k^2/2) -> 2 as k grows (approached from above slowly).
  * To push the ratio higher we want |A-A| to exceed ~k^2 relative to |A+A|:
    combine the powers set with a few additive shifts / small digit patterns so that
    many new differences appear while few new sums appear.
We score exactly and keep the best over a broad parameter sweep plus local search.
"""
import math
import time
import random


def _stats(a):
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            if i <= j:
                sums.add(ai + aj)
    # add symmetric sums explicitly (same values, no new elements) -> fine
    return math.log(len(diffs)) / math.log(len(sums)), len(diffs), len(sums)


def _score(a):
    if len(a) < 2:
        return 0.0
    s, _, _ = _stats(a)
    return s + (1 - 1 / len(a)) / 100


def solve():
    random.seed(987654321)
    deadline = time.time() + 115

    best = []
    best_score = -1.0

    def consider(a):
        nonlocal best, best_score
        if len(a) < 2 or len(a) > 4000:
            return
        a = sorted(set(a))
        if len(a) < 2 or len(a) > 4000:
            return
        if max(abs(x) for x in a) > 10**15:
            return
        s = _score(a)
        if s > best_score:
            best_score = s
            best = list(a)

    MAXV = 10**15

    # ---- Family A: pure powers of b, b^i for i=0..k-1 ----
    bases = list(range(2, 60)) + [100, 1000, 10**4, 10**6, 10**9, 10**12]
    for B in bases:
        for k in range(2, 5000):
            if B ** (k - 1) > MAXV:
                break
            a = [B ** i for i in range(k)]
            consider(a)
            if time.time() > deadline:
                return best

    # ---- Family B: powers shifted by a fixed offset c: {c + b^i} ----
    for B in [2, 3, 5, 10, 100, 1000, 10**6, 10**9]:
        for k in range(2, 400):
            if B ** (k - 1) > MAXV:
                break
            for c in [1, 2, 3, -1, -2, 7, 13]:
                a = [c + B ** i for i in range(k)]
                consider(a)
            if time.time() > deadline:
                return best

    # ---- Family C: powers plus a small common multiplier and a few anchor points ----
    for B in [3, 5, 10, 100, 1000, 10**6]:
        for k in range(2, 300):
            if B ** (k - 1) > MAXV:
                break
            pows = [B ** i for i in range(k)]
            for extra in [B ** (k + 1), 2 * B ** k, 3 * B ** k, -B ** k, B ** k + 1]:
                if abs(extra) > MAXV:
                    continue
                consider(pows + [extra])
            if time.time() > deadline:
                return best

    # ---- Family D: two interleaved geometric progressions (digit sets) ----
    # A = {b^i} union {2*b^i} for i=0..k-1 : sums stay ~ (2k)^2/2, differences gain.
    for B in [2, 3, 5, 10, 100, 1000, 10**6]:
        for k in range(2, 120):
            if B ** (k - 1) > MAXV // 2:
                break
            a = [B ** i for i in range(k)] + [2 * (B ** i) for i in range(k)]
            consider(a)
            if time.time() > deadline:
                return best

    # ---- Family E: digit-block construction over base b with digit set {0,1}
    # A = all sums of distinct powers b^i for i in a chosen sparsity pattern.
    # Choose contiguous blocks of exponents; sums of block elements collide less.
    for B in [2, 3, 5, 10, 100]:
        for k in range(2, 20):
            if B ** (k - 1) > MAXV:
                break
            # all subsets of {0..k-1} of size <= 2 plus the full power set elements is too big;
            # instead use a fixed window and offsets
            for start in [0, 1]:
                pows = [B ** (start + i) for i in range(k)]
                consider(pows)
            if time.time() > deadline:
                return best

    # ---- Family F: locally refine the current best ----
    if best:
        cur = list(best)
        cur_score = best_score
        n = len(cur)
        step = max(1, 10**(14 - int(math.log10(max(1, max(abs(x) for x in cur))))))
        while time.time() < deadline:
            cand = list(cur)
            i = random.randrange(len(cand))
            # multiplicative-ish perturbation to try to shift a power exponent
            r = random.random()
            if r < 0.5:
                cand[i] = cand[i] * random.choice([2, 3, 5])
            elif r < 0.8:
                cand[i] = cand[i] + random.randint(-1000, 1000)
            else:
                cand[i] = cand[i] - random.randint(0, cand[i])
            if abs(cand[i]) == 0:
                cand[i] = random.randint(1, 1000)
            if random.random() < 0.05 and len(cand) < 4000:
                cand.append(random.randint(1, MAXV))
            consider(cand)
            if best_score > cur_score:
                cur, cur_score = list(best), best_score
            elif random.random() < 0.1:
                cur, cur_score = list(best), best_score

    return best
# EVOLVE-BLOCK-END
