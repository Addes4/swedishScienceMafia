# EVOLVE-BLOCK-START
"""Construct sets with many differences, few sums.

Family searched: A = {0} u { +/- j*b^i : i<k, j in J }  for small multiplier
sets J and bases b.  With |J| small the sum set stays nearly linear in the
number of levels while the difference set grows quadratically, and using
several multipliers per level raises the element count (hence the ratio)
within the value bound 1e15.
"""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return -1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _make(b, J, k):
    a = [0]
    p = 1
    for _ in range(k):
        for j in J:
            a.append(j * p)
            a.append(-j * p)
        p *= b
    return a


def solve():
    deadline = time.time() + 100.0
    best = [0]
    best_score = -1e9

    def consider(a):
        nonlocal best, best_score
        a = list(set(a))
        if not (2 <= len(a) <= 4000):
            return
        if max(abs(x) for x in a) > 10**15:
            return
        s = _score(a)
        if s > best_score:
            best_score, best = s, a

    multi_sets = [[1], [1, 2], [1, 3], [1, 2, 3], [1, 2, 4],
                  [1, 3, 9], [1, 2, 5], [2, 3], [1, 4]]
    for b in range(2, 8):
        for J in multi_sets:
            k = 1
            while True:
                if time.time() > deadline:
                    break
                a = _make(b, J, k)
                if len(a) > 4000:
                    break
                if abs((max(J)) * b ** (k - 1)) > 10**15:
                    break
                consider(a)
                k += 1
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # polish: greedy add/remove around best
    improved = True
    while improved and time.time() < deadline:
        improved = False
        cur = list(best)
        for x in range(-40, 41):
            cand = cur + [x]
            if len(set(cand)) != len(cand):
                continue
            if max(abs(v) for v in cand) > 10**15 or len(cand) > 4000:
                continue
            s = _score(cand)
            if s > best_score:
                best_score, best = s, cand
                improved = True
                break

    return sorted(set(best))
# EVOLVE-BLOCK-END
