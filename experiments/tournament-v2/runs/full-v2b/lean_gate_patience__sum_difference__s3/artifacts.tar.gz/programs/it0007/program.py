# EVOLVE-BLOCK-START
"""Bose-Chowla Sidon set construction for maximal |A-A| with small |A+A|.

For a prime p ≡ 3 (mod 4), the set S = { x : x = i + (i^2 mod p), 0 <= i < p } ... 
Actually the classic Bose-Chowla: for prime p, A = { 2p*i + (i^2 mod p) : 0 <= i < p }
is a Sidon set in Z, so A-A has ~ p^2 distinct values (maximal). We try several
primes p and variants, score exactly, and keep the best.
"""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _primes_up_to(n):
    sieve = bytearray([1]) * (n + 1)
    sieve[0:2] = b"\x00\x00"
    i = 2
    while i * i <= n:
        if sieve[i]:
            sieve[i*i::i] = b"\x00" * len(sieve[i*i::i])
        i += 1
    return [i for i in range(2, n + 1) if sieve[i]]


def solve():
    deadline = time.time() + 110

    best = []
    best_score = -1.0

    def consider(a):
        nonlocal best, best_score
        a = sorted(set(a))
        if len(a) < 2 or len(a) > 4000:
            return
        if max(abs(x) for x in a) > 10**15:
            return
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a

    primes = _primes_up_to(2000)

    # Bose-Chowla Sidon set: A = { 2p*i + (i^2 mod p) : 0 <= i < p }.
    # Base 2p ensures A-A distinct (Sidon in Z). Size = p (<=4000).
    for p in primes:
        if p < 3 or p > 4000:
            continue
        M = 2 * p
        a = [M * i + (i * i) % p for i in range(p)]
        if a[-1] > 10**15:
            continue
        consider(a)
        if time.time() > deadline:
            return best

    # Variant: A = { p*i + (i^2 mod p) } (Erdos-Turan-like, still often near-Sidon)
    for p in primes:
        if p < 3 or p > 4000:
            continue
        M = p
        a = [M * i + (i * i) % p for i in range(p)]
        if a[-1] > 10**15:
            continue
        consider(a)
        if time.time() > deadline:
            return best

    # Variant: base = p plus small multiplier tuned to reduce sum collisions
    for p in primes:
        if p < 5 or p > 2000:
            continue
        for mult in (1, 2, 3):
            M = mult * p + 1
            a = [M * i + (i * i) % p for i in range(p)]
            if a[-1] > 10**15:
                continue
            consider(a)
        if time.time() > deadline:
            return best

    # Bezout/Singer-like: A = { i + (i^2 mod p) * K } with K chosen large enough
    for p in primes:
        if p < 5 or p > 2000:
            continue
        for K in (p, p + 1, 2 * p):
            a = [i + K * ((i * i) % p) for i in range(p)]
            if a[-1] > 10**15:
                continue
            consider(a)
        if time.time() > deadline:
            return best

    return best
# EVOLVE-BLOCK-END
