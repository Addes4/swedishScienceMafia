# EVOLVE-BLOCK-START
"""Construct A with large difference set and small sum set.

Strategy: start from a Sidon-like set (quadratic-residue / Ruzsa construction over a
prime) which makes |A-A| near maximal (~n^2), then refine with a fast local search that
directly maximizes log|A-A|/log|A+A| using a bounded neighbourhood, over the full budget.
"""
import math
import random
import time


def _score_fast(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            if i <= j:
                sums.add(ai + aj)
    nd = len(diffs)
    ns = len(sums)
    if ns <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _sidon_ruzsa(p):
    """Ruzsa's construction of a Sidon set from prime p."""
    elems = []
    for x in range(p):
        # map x into Z_{p^2-p} via CRT-ish representation
        val = x + p * ((2 * x * x) % p)
        elems.append(val)
    return elems


def solve():
    best = None
    best_score = -1.0

    deadline = time.time() + 110.0

    # Candidate seeds: Sidon constructions + denser small structures
    seeds = []
    for p in [13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53]:
        try:
            s = _sidon_ruzsa(p)
            seeds.append(sorted(set(s)))
        except Exception:
            pass
    # Also simple geometric progression (differences mostly distinct)
    seeds.append([2 ** i for i in range(14)])
    # Interval balanced
    seeds.append(list(range(20)))
    seeds.append(list(range(0, 40, 2)))

    for seed in seeds:
        for _ in range(3):
            a = seed[:]
            sc = _score_fast(a)
            if sc > best_score:
                best_score, best = sc, a[:]

    # Local search / simulated annealing over the best structures found.
    rng = random.Random(12345)
    cur = best[:]
    cur_score = best_score
    t_scale = 0.02

    while time.time() < deadline:
        cand = cur[:]
        op = rng.random()
        if op < 0.55:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-4, 4)
        elif op < 0.75:
            cand.append(cand[rng.randrange(len(cand))] + rng.randint(-6, 6))
        elif op < 0.9 and len(cand) > 4:
            del cand[rng.randrange(len(cand))]
        else:
            # shift whole set (translation) - sometimes helps local structure
            d = rng.randint(-3, 3)
            cand = [x + d for x in cand]
        if len(cand) < 3 or len(cand) > 4000:
            continue
        sc = _score_fast(cand)
        if sc >= cur_score or rng.random() < math.exp((sc - cur_score) / t_scale):
            cur, cur_score = cand, sc
            if sc > best_score:
                best_score, best = sc, cand[:]
        if rng.random() < 0.02:
            cur, cur_score = best[:], best_score

    return sorted(set(best))


# EVOLVE-BLOCK-END
