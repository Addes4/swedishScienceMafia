# EVOLVE-BLOCK-START
"""Search for sum-poor, difference-rich sets via base representations and structured families."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    random.seed(12345)
    deadline = time.time() + 110

    best = []
    best_score = -1.0

    def consider(a):
        nonlocal best, best_score
        a = sorted(set(a))
        if len(a) < 2 or len(a) > 4000:
            return
        if max(abs(x) for x in a) > 10**15:
            return
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a

    # Build a sum-poor set from base-B digitizations where the digit set has a
    # small sumset but large difference set. Represent A as subset sums over
    # disjoint base-B "digits" so that integer sums mirror digit-vector sums.
    #
    # Core idea: use A = { sum_{i in S} B^i : S in F } where F is a family of
    # subsets of positions. Then A+A corresponds to (S union T as multiset) and
    # A-A to (S minus T). Choosing F so that pairwise unions collide a lot while
    # differences stay distinct.
    #
    # Easier tractable: use positions 0..k-1 with weights B^i; take F = all
    # subsets of size exactly 2 (Edges). Then |A| = C(k,2). Sums of two edges
    # (4 elements with multiplicity) collapse; differences stay large.

    # Strategy 1: F = all 2-subsets of {0,...,k-1}, weights = powers of base B.
    for B in [2, 3, 5, 10, 100, 1000, 10**4]:
        for k in range(4, 130):
            if k * (k - 1) // 2 > 4000:
                break
            if B ** (k - 1) > 10**15:
                break
            a = []
            for i in range(k):
                for j in range(i + 1, k):
                    a.append(B ** i + B ** j)
            consider(a)
            if time.time() > deadline:
                return best

    # Strategy 2: digit set D with small |D+D| relative to |D-D|, over base B,
    # taking all vectors supported on a small number of positions p.
    for B in [10, 100, 1000, 10**4, 10**6]:
        for p in range(2, 11):
            if B ** (p - 1) > 10**15:
                break
            # subset-sum over p positions with digits from {0,1}
            size = 1 << p
            if size > 4000:
                break
            vals = []
            for mask in range(1, size):
                v = 0
                for i in range(p):
                    if (mask >> i) & 1:
                        v += B ** i
                vals.append(v)
            consider(vals)
            if time.time() > deadline:
                return best

    # Strategy 3: A = {q^i} plus small tweaks; base q powers give all-distinct
    # sums which is bad, so instead use arithmetic progressions in a large step.
    # Sub-strategy: A = {i*M + r_i} where r_i chosen from a small digit set D
    # such that D+D is tiny. Use r_i in {0} for all i (just AP) -> sums collide
    # perfectly but diffs also collide. Balance: A = AP of length n with step 1
    # gives ratio ~1, so scale: A = union of d APs.
    for d in range(2, 40):
        for step in [1, 2, 3, 5, 10, 100, 1000, 10**6]:
            for nseg in range(1, 4000 // d + 1):
                n = d * nseg
                if n < 2 or n > 4000:
                    continue
                a = []
                for s in range(d):
                    for t in range(nseg):
                        a.append(s * step + t)
                if max(abs(x) for x in a) > 10**15:
                    continue
                consider(a)
            if time.time() > deadline:
                return best

    # Strategy 4: random hill climbing on top of best structured set.
    if best:
        cur = list(best)
        cur_score = best_score
        stall = 0
        while time.time() < deadline:
            cand = list(cur)
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, 1000)
            consider(cand)
            if best_score > cur_score:
                cur, cur_score = list(best), best_score
                stall = 0
            else:
                stall += 1
                if stall > 200:
                    cur, cur_score = list(best), best_score
                    stall = 0

    return best
# EVOLVE-BLOCK-END
