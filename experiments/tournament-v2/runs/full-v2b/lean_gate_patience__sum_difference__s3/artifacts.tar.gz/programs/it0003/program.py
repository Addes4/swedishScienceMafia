# EVOLVE-BLOCK-START
"""Many differences, few sums: structured Sidon-style construction + exact-scored local search."""
import math
import random
import time


def _counts(a):
    a = list(set(a))
    if len(a) < 2:
        return 0, 0, 0
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for j, y in enumerate(a):
            diffs.add(x - y)
            sums.add(x + y)
    return len(a), len(diffs), len(sums)


def _score(a):
    n, d, s = _counts(a)
    if n < 2 or s < 2 or d < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _sidon_quadratic(p, n):
    """Erdos-Turan style Sidon set: {2*p*k + (k*k mod p)}."""
    return [2 * p * k + (k * k) % p for k in range(n)]


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Try several structured constructions, choose the best by exact score.
    candidates = []
    # Simple superincreasing powers-of-2-ish sets (many differences).
    for n in (6, 8, 10):
        candidates.append([1 << i for i in range(n)])
    # Erdős-Turán quadratic Sidon constructions at various primes / sizes.
    for p in (11, 13, 17, 19, 23, 29, 31, 37, 41):
        for n in range(5, min(p, 40)):
            candidates.append(_sidon_quadratic(p, n))
    for c in candidates:
        s = _score(c)
        if s > best_score:
            best, best_score = c[:], s

    cur = best[:]
    deadline = time.time() + 108
    step = 1
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.7 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-step, step])
        elif op < 0.85:
            cand.append(max(cand) + random.randint(1, step + 1))
        elif len(cand) > 3:
            cand.pop(random.randrange(len(cand)))
        # occasionally add spreads using big power-of-two steps
        if random.random() < 0.02 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([1 << random.randint(1, 12), -(1 << random.randint(1, 12))])
        cand = list(set(cand))
        if len(cand) < 3:
            continue
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
            step = 1
        else:
            if random.random() < 0.15:
                cur = best[:]
                step = 1
            else:
                step = random.choice([1, 1, 1, 2, 4])
    return sorted(set(best))
# EVOLVE-BLOCK-END
