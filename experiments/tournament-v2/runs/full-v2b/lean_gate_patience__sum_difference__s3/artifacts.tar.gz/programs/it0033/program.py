# EVOLVE-BLOCK-START
"""Construct sets with many differences, few sums.

Main family: A = {0} u {+/- c_i * b^i}.  Because every element is a signed
multiple of a power of b, sums frequently coincide or cancel, so |A+A| stays
close to linear in |A|, while the difference set A-A is much richer, giving
|A-A| ~ |A|^2.  We search over bases b, scale patterns c_i and mixes.
"""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return -1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _sym(base, k, c=1):
    a = [0]
    p = 1
    for _ in range(k):
        a.append(c * p)
        a.append(-c * p)
        p *= base
    return a


def _sym2(base, k, c1, c2):
    """Two interleaved symmetric geometric scales."""
    a = [0]
    p = 1
    for _ in range(k):
        a.append(c1 * p)
        a.append(-c1 * p)
        if c2 != c1:
            a.append(c2 * p)
            a.append(-c2 * p)
        p *= base
    return a


def _tensor(b, S, length):
    a = [0]
    p = 1
    for _ in range(length):
        a = [x + d * p for x in a for d in S]
        p *= b
    return a


def solve():
    deadline = time.time() + 100.0
    best = [0, 1, -1, 2, -2, 4, -4]
    best_score = _score(best)

    def consider(a):
        nonlocal best, best_score
        try:
            a = list(set(a))
        except Exception:
            return
        if not (2 <= len(a) <= 4000):
            return
        if max(abs(x) for x in a) > 10**15:
            return
        s = _score(a)
        if s > best_score:
            best_score, best = s, a

    # 1) symmetric geometric, any base, any scale
    for base in range(2, 9):
        for c in (1, 2, 3, 4):
            k = 1
            while True:
                if c * base ** (k - 1) > 10**15:
                    break
                a = _sym(base, k, c)
                if len(a) > 4000:
                    break
                consider(a)
                k += 1
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # 2) two interleaved scales (richer difference set)
    for base in range(2, 7):
        for c1 in (1, 2):
            for c2 in (1, 3, 5):
                if c2 == c1:
                    continue
                k = 1
                while True:
                    if max(c1, c2) * base ** (k - 1) > 10**15:
                        break
                    a = _sym2(base, k, c1, c2)
                    if len(a) > 4000:
                        break
                    consider(a)
                    k += 1
                    if time.time() > deadline:
                        break
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # 3) tensors of small sign/sum-poor digit sets
    seeds = [[0, 1], [-1, 0, 1], [0, 1, 2], [-1, 1], [0, 1, -2], [0, 1, 3]]
    for S0 in seeds:
        for b in range(2, 12):
            for length in range(2, 8):
                if time.time() > deadline:
                    break
                if max(abs(d) for d in S0) >= b:
                    continue
                if len(S0) ** length > 4000:
                    continue
                if b ** (length - 1) > 10**15:
                    continue
                consider(_tensor(b, S0, length))
        if time.time() > deadline:
            break

    return sorted(set(best))
# EVOLVE-BLOCK-END
