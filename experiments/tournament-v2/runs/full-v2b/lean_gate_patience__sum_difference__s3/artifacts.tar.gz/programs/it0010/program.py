# EVOLVE-BLOCK-START
"""Geometric sets with sum-poor structure.

Key: for A = {b^0, b^1, ..., b^(k-1)} with large |b|, every sum b^i+b^j (i<=j) has a
unique base-b-ish representation, so |A+A| = k(k+1)/2 (minimal, only the i<=j symmetry).
Differences b^i-b^j are essentially all distinct for distinct (i,j) with i>j, giving
|A-A| ≈ k^2. This makes log|A-A|/log|A+A| ≈ log(k^2)/log(k^2/2) -> 1 as k grows, but
the additive bonus (1-1/|A|)/100 favors large k. We search over bases b (signed),
lengths k, small perturbations, and mixed constructions to maximize the exact score.
"""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _score_fast(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            aj = a[j]
            d = ai - aj
            diffs.add(d)
            diffs.add(-d)
            sums.add(ai + aj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    random.seed(987654321)
    deadline = time.time() + 110
    LIMIT = 10 ** 15

    best = []
    best_score = -1.0

    def consider(a):
        nonlocal best, best_score
        a = list(set(a))
        if len(a) < 2 or len(a) > 4000:
            return
        if any(abs(x) > LIMIT for x in a):
            return
        s = _score_fast(a)
        if s > best_score:
            best_score = s
            best = sorted(a)

    # ---- Family A: pure geometric powers b^i, signed bases, large k (bonus driven)
    for B in [2, 3, 4, 5, 7, 10, 100, 1000, 10**4, 10**6, 10**9, 10**12]:
        for sign in (1, -1):
            b = sign * B
            a = []
            v = 1
            for k in range(4000):
                a.append(v)
                v *= b
                if abs(v) > LIMIT:
                    break
            if len(a) >= 2:
                consider(a[:])
            if time.time() > deadline:
                return best

    # ---- Family B: signed geometric sets, mixing + and - powers
    for B in [2, 3, 4, 5, 7, 10, 100, 1000, 10**4, 10**6]:
        pos = []
        v = 1
        for _ in range(2000):
            pos.append(v)
            v *= B
            if v > LIMIT:
                break
        neg = [-x for x in pos[1:]]
        for kp in range(2, len(pos) + 1):
            for kn in range(0, min(len(neg), kp) + 1):
                a = pos[:kp] + neg[:kn]
                consider(a)
            if time.time() > deadline:
                return best

    # ---- Family C: geometric plus small offsets to break some sum collisions
    if best:
        cur = list(best)
        cur_score = best_score
        while time.time() < deadline:
            cand = list(cur)
            n = len(cand)
            op = random.random()
            if op < 0.5 and n > 2:
                i = random.randrange(n)
                cand[i] += random.choice([-1, 1]) * random.randint(1, 10 ** random.randint(0, 5))
            elif op < 0.8 and n < 4000:
                base = random.choice(cur)
                cand.append(base + random.choice([-1, 1]) * random.randint(1, 10 ** random.randint(0, 6)))
            else:
                i = random.randrange(n)
                cand[i] = -cand[i]
            consider(cand)
            if best_score > cur_score:
                cur, cur_score = list(best), best_score
            elif random.random() < 0.3:
                cur, cur_score = list(best), best_score

    return best
# EVOLVE-BLOCK-END
