# EVOLVE-BLOCK-START
"""Construct sets via base-b digit patterns, where modular/additive collisions
force |A+A| small while base-b uniqueness keeps differences distinct."""
import math
import time
import random
import numpy as np


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _fast_score(arr):
    """arr: numpy int64 array of the set. Returns score (float)."""
    n = arr.size
    if n < 2:
        return 0.0
    d = arr[:, None] - arr[None, :]
    s = arr[:, None] + arr[None, :]
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _build(b, S, length):
    """A = {sum d_i b^i : d_i in S, i in 0..length-1}."""
    a = [0]
    p = 1
    for _ in range(length):
        a = [x + d * p for x in a for d in S]
        p *= b
    return a


def _build_multiset(bases, Ssets):
    """Mixed radix: position i has its own base and digit set."""
    a = [0]
    p = 1
    for b, S in zip(bases, Ssets):
        a = [x + d * p for x in a for d in S]
        p *= b
    return a


def _best_len(S, limit=4000):
    """Max length so that |S|^length <= limit."""
    k = len(S)
    if k < 2:
        return 1
    L = 1
    while k ** (L + 1) <= limit:
        L += 1
    return L


def solve():
    deadline = time.time() + 100.0
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # 1) Broad sweep over tensored digit sets.
    seeds = [
        [0, 1],
        [0, 1, 2],
        [0, 1, 3],
        [0, 1, 2, 3],
        [-1, 0, 1],
        [-1, 0, 1, 2],
        [0, 1, 2, 4],
        [-2, -1, 0, 1, 2],
        [0, 1, 2, 3, 4],
        [0, 2, 3, 5],
    ]

    tried = set()
    for S0 in seeds:
        for b in range(3, 30):
            S = sorted(set(S0))
            if max(abs(d) for d in S) >= b:
                continue
            Lmax = _best_len(S)
            # cap by magnitude constraint
            while Lmax >= 1 and b ** Lmax > 10 ** 15:
                Lmax -= 1
            for length in range(2, Lmax + 1):
                key = (b, tuple(S), length)
                if key in tried:
                    continue
                tried.add(key)
                if time.time() > deadline:
                    break
                a = _build(b, S, length)
                if len(a) > 4000:
                    continue
                if max(abs(x) for x in a) > 10 ** 15:
                    continue
                s = _score(a)
                if s > best_score:
                    best_score, best = s, a
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # 2) Greedy/random local search over digit sets S at a fixed base-length
    #    using the fast numpy scorer on the tensored-type pattern.
    #    We tensor a *pattern* over positions to reach near size 4000.
    rng = random.Random(12345)

    def try_digit_set(S, b):
        nonlocal best, best_score
        S = sorted(set(S))
        if len(S) < 2:
            return
        if max(abs(d) for d in S) >= b:
            return
        Lmax = _best_len(S)
        while Lmax >= 1 and b ** Lmax > 10 ** 15:
            Lmax -= 1
        if Lmax < 2:
            return
        a = _build(b, S, Lmax)
        if len(a) > 4000:
            return
        if max(abs(x) for x in a) > 10 ** 15:
            return
        if time.time() > deadline:
            return
        s = _score(a)
        if s > best_score:
            best_score = s
            best = a

    # local search: start from small sets and mutate
    while time.time() < deadline:
        k = rng.randint(2, 4)
        b = rng.randint(k + 1, 25)
        S = rng.sample(range(-b + 1, b), min(k, 2 * b - 1))
        # greedy improvement
        cur = sorted(set(S))
        for _ in range(rng.randint(5, 30)):
            if time.time() > deadline:
                break
            try_digit_set(cur, b)
            # mutate: add/remove/replace one digit
            cand = cur[:]
            op = rng.random()
            if op < 0.5 and len(cand) < 5:
                d = rng.randint(-b + 1, b - 1)
                if d not in cand:
                    cand.append(d)
            elif op < 0.8 and len(cand) > 2:
                cand.pop(rng.randrange(len(cand)))
            elif len(cand) > 0:
                i = rng.randrange(len(cand))
                cand[i] = rng.randint(-b + 1, b - 1)
            cand = sorted(set(cand))
            if len(cand) >= 2 and max(abs(d) for d in cand) < b:
                # accept if tensor score improves (approx via try keeping best)
                cur = cand

    best = sorted(set(best))
    if _score(best) < best_score - 1e-12:
        best = _build(3, [0, 1], 2)
    return best
# EVOLVE-BLOCK-END
