# EVOLVE-BLOCK-START
"""Construct sets with many differences, few sums.

Best known family here: A = {0} u {+/- 2^i : i=0..k-1} (symmetric geometric),
giving |A-A| ~ 2|A|^2 while |A+A| stays small.  We also try:
  * one-sided powers of two {2^i},
  * powers with an offset / phase,
  * small tensors of sum-poor digit sets,
  * "binary geometric" sets and shifted variants,
  * a Singer-style near-perfect-difference base (dense differences),
then pick the best by an exact score.
"""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return -1e9
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _geometric_sym(k):
    """{0} u {+/- 2^i : i=0..k-1}."""
    a = [0]
    p = 1
    for _ in range(k):
        a.append(p)
        a.append(-p)
        p *= 2
    return a


def _tensor(b, S, length):
    a = [0]
    p = 1
    for _ in range(length):
        a = [x + d * p for x in a for d in S]
        p *= b
    return a


def solve():
    deadline = time.time() + 100.0
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    def consider(a):
        nonlocal best, best_score
        a = list(set(a))
        if not (2 <= len(a) <= 4000):
            return
        if max(abs(x) for x in a) > 10**15:
            return
        s = _score(a)
        if s > best_score:
            best_score, best = s, a

    # 1) symmetric geometric sets of growing size (main family)
    k = 1
    while len(_geometric_sym(k)) <= 4000 and 2 ** (k - 1) <= 10**15:
        consider(_geometric_sym(k))
        k += 1
        if time.time() > deadline:
            break

    # 2) one-sided powers of two {2^i}
    k = 1
    while k <= 4000 and 2 ** (k - 1) <= 10**15:
        consider([2 ** i for i in range(k)])
        k += 1
        if time.time() > deadline:
            break

    # 3) symmetric geometric with base 2 but a leading 0 and shifted powers
    #    A = {0} u {+/- (2^i - 1) : i=1..k}
    for shift in (1, 2, 3):
        k = 1
        while True:
            a = [0]
            p = 1
            for _ in range(k):
                a.append(p - shift)
                a.append(-(p - shift))
                p *= 2
            if len(a) > 4000 or p // 2 > 10**15:
                break
            if len(a) >= 2:
                consider(a)
            k += 1
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # 4) geometric with a scale/phase: c * {+/- base^i}
    for base in (2, 3):
        for c in (1, 2, 3):
            k = 1
            while True:
                a = [0]
                p = 1
                for _ in range(k):
                    a.append(c * p)
                    a.append(-c * p)
                    p *= base
                if len(a) > 4000 or (c * p) // base > 10**15:
                    break
                consider(a)
                k += 1
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break

    # 5) tensors of small digit sets
    seeds = [[0, 1], [-1, 0, 1], [0, 1, 2], [-1, 1], [0, 1, -2]]
    for S0 in seeds:
        for b in range(2, 12):
            for length in range(2, 8):
                if time.time() > deadline:
                    break
                S = S0
                if max(abs(d) for d in S) >= b:
                    continue
                if len(S) ** length > 4000:
                    continue
                try:
                    if b ** (length - 1) > 10**15:
                        continue
                    a = _tensor(b, S, length)
                except Exception:
                    continue
                consider(a)

    # 6) "union of few-sum digit tensor with geometric tail"
    #    A = T u (T + G) where G is a geometric set; breaks product structure.
    def tail_union(b, S, length, tmax):
        T = _tensor(b, S, length)
        if not T:
            return None
        base = max(abs(x) for x in T) + 1
        off = base * b
        a = list(T)
        p = 1
        for _ in range(tmax):
            for x in T:
                a.append(x + p * off)
            p *= 2
            if len(a) > 4000 or p > 10**15:
                break
        return a

    for S0 in seeds:
        for b in range(2, 8):
            for length in range(1, 5):
                if time.time() > deadline:
                    break
                S = S0
                if max(abs(d) for d in S) >= b:
                    continue
                if len(S) ** length > 200:
                    continue
                for tmax in range(1, 8):
                    a = tail_union(b, S, length, tmax)
                    if a is None:
                        continue
                    consider(a)

    return sorted(set(best))
# EVOLVE-BLOCK-END
