# EVOLVE-BLOCK-START
"""Find a digit set S maximizing log|S-S|/log|S+S|, then tensor it in base B.

For A = { sum_{i<k} d_i * B^i : d_i in S } with B > max|s+-s'| for all s,s' in S,
there are no carries, so |A-A| = |S-S|^k and |A+A| = |S+S|^k. Hence
score = log|S-S|/log|S+S| (dimension independent), and the bonus grows with |A|=|S|^k.
So we maximize the ratio over small S, then tensor to maximize |A| <= 4000.
"""
import math
import itertools
import random
import time


def _stats(S):
    U = set()
    D = set()
    for a in S:
        for b in S:
            U.add(a + b)
            D.add(a - b)
    return U, D


def _ratio(S):
    U, D = _stats(S)
    if len(U) < 2 or len(D) < 2:
        return -1.0
    return math.log(len(D)) / math.log(len(U))


def _score_exact(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0


def solve():
    deadline = time.time() + 100.0

    bestS = None
    bestR = -1.0

    # ---- Exhaustive search over tiny digit sets ----
    R = 10
    for sz in range(2, 6):
        for comb in itertools.combinations(range(-R, R + 1), sz):
            r = _ratio(comb)
            if r > bestR:
                bestR = r
                bestS = comb

    # ---- Randomized / hill-climbed search for larger digit sets ----
    climb_deadline = deadline * 0.65
    while time.time() < climb_deadline:
        sz = random.randint(5, 14)
        S = set(random.sample(range(-200, 201), sz))
        r = _ratio(S)
        if r > bestR:
            bestR = r
            bestS = tuple(sorted(S))
        # local hill climb: perturb one element at a time
        for _ in range(30):
            if time.time() > climb_deadline:
                break
            T = list(S)
            T[random.randrange(len(T))] = random.randint(-200, 200)
            T = set(T)
            if len(T) < 2:
                continue
            rr = _ratio(T)
            if rr > bestR:
                bestR = rr
                bestS = tuple(sorted(T))
            if rr >= r:
                S = T
                r = rr

    if bestS is None:
        bestS = (0, 1, 3)
    S = list(bestS)

    # ---- Tensor S into a base-B digit set with as many dims as fit ----
    U, D = _stats(S)
    maxU = max(abs(x) for x in U)
    maxD = max(abs(x) for x in D)
    B = max(maxU, maxD) + 1
    if B < 2:
        B = 2
    maxabs = max(abs(x) for x in S)

    # choose dimension k: maximize |S|^k <= 4000 and magnitude fits in 1e15
    bestA = None
    k = 1
    while True:
        size = len(S) ** k
        if size > 4000:
            break
        # magnitude bound for base-B representation
        mag = maxabs * (B ** k - 1) // (B - 1) if B > 1 else 0
        if mag > 10 ** 15:
            break
        # build A
        A = [0]
        p = 1
        for _ in range(k):
            nxt = []
            for a in A:
                for d in S:
                    nxt.append(a + d * p)
            A = nxt
            p *= B
        if len(set(A)) <= 4000:
            bestA = A
        k += 1

    if bestA is not None:
        cand = sorted(set(int(x) for x in bestA))
        if len(cand) <= 4000 and all(abs(x) <= 10 ** 15 for x in cand):
            return cand

    # ---- Fallback: directly return the best small S ----
    return sorted(set(int(x) for x in S))
# EVOLVE-BLOCK-END
