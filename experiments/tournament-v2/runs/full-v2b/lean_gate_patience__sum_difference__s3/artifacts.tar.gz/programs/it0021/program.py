# EVOLVE-BLOCK-START
"""Search for an integer set A maximizing log|A-A|/log|A+A|.

The base-B digit-tensor construction is exact and ratio-preserving:
for A = {sum d_i B^i : d_i in S} with B larger than any |S±S| element,
|A-A| = |S-S|^k and |A+A| = |S+S|^k, so the score equals
log|S-S|/log|S+S| (independent of k), while the bonus favors large |A|.
Hence we search hard for a digit set S with a good exact ratio using a
numpy-accelerated iterated local search, then tensor it as far as fits.
"""
import math
import itertools
import random
import time

import numpy as np


def _stats_np(S):
    S = np.asarray(list(S), dtype=np.int64)
    d = S[:, None] - S[None, :]
    s = S[:, None] + S[None, :]
    return np.unique(d).size, np.unique(s).size


def _ratio_np(S):
    nd, ns = _stats_np(S)
    if ns < 2 or nd < 2:
        return -1.0
    return math.log(nd) / math.log(ns)


def _score_np(A):
    A = np.asarray(A, dtype=np.int64)
    n = A.size
    if n < 2:
        return 0.0
    d = A[:, None] - A[None, :]
    s = A[:, None] + A[None, :]
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _ils_digit_set(deadline, rng):
    """Iterated local search over digit sets, numpy-scored."""
    vlo, vhi = -60, 60
    bestS = None
    bestR = -1.0

    # Seed candidates: small windows / arithmetic patterns.
    seeds = [
        {-1, 0, 1},
        {-2, -1, 0, 1, 2},
        set(range(-3, 4)),
        set(range(-2, 3)) | {4, -4},
    ]

    while time.time() < deadline:
        # Either start from a seed or a random set.
        if rng.random() < 0.4:
            S0 = set(rng.choice(seeds))
            if rng.random() < 0.5:
                # perturb the seed
                for _ in range(rng.randint(1, 3)):
                    S0.add(rng.randint(vlo, vhi))
        else:
            sz = rng.randint(3, 22)
            S0 = set(rng.sample(range(vlo, vhi + 1), sz))

        S = set(S0)
        r = _ratio_np(S)
        if r > bestR:
            bestR, bestS = r, frozenset(S)

        # Local search with a decreasing step size.
        for it in range(400):
            if time.time() > deadline:
                break
            step = max(1, 8 - it // 50)
            T = set(S)
            op = rng.random()
            if op < 0.6:
                T = set(T)
                T.discard(next(iter(T)) if False else rng.choice(tuple(T)))
                T.add(rng.randint(vlo, vhi))
            elif op < 0.85:
                x = rng.choice(tuple(T))
                T.discard(x)
                T.add(x + rng.randint(-step, step))
            else:
                T.add(rng.randint(vlo, vhi))
            if len(T) < 3:
                continue
            rr = _ratio_np(T)
            if rr > bestR:
                bestR, bestS = rr, frozenset(T)
            if rr >= r:
                S, r = T, rr
        # Occasionally restart from the global best.
        if bestS is not None and rng.random() < 0.3:
            S = set(bestS)
            for _ in range(rng.randint(0, 2)):
                S.add(rng.randint(vlo, vhi))

    return sorted(bestS), bestR


def solve():
    deadline = time.time() + 95.0
    rng = random.Random(12345)

    S, bestR = _ils_digit_set(deadline - 20.0, rng)

    # ---- Tensor S in base B as far as fits ----
    U = set()
    D = set()
    for a in S:
        for b in S:
            U.add(a + b)
            D.add(a - b)
    B = max(max(abs(x) for x in U), max(abs(x) for x in D)) + 1
    if B < 2:
        B = 2
    maxabs = max(abs(x) for x in S)

    bestA = None
    k = 1
    while True:
        size = len(S) ** k
        if size > 4000:
            break
        mag = maxabs * (B ** k - 1) // (B - 1) if B > 1 else 0
        if mag > 10 ** 15:
            break
        A = [0]
        p = 1
        for _ in range(k):
            nxt = []
            for a in A:
                for d in S:
                    nxt.append(a + d * p)
            A = nxt
            p *= B
        if len(set(A)) <= 4000:
            bestA = A
        k += 1

    if bestA is None:
        bestA = list(S)

    cand = sorted(set(int(x) for x in bestA))

    # ---- Quick direct hill-climb on full candidate (vectorized) ----
    if len(cand) >= 8:
        base_score = _score_np(cand)
        work = cand[:]
        climb = min(deadline, time.time() + 18.0)
        while time.time() < climb:
            i = rng.randrange(len(work))
            j = rng.randrange(len(work))
            old = work[i]
            nv = work[j] + rng.randint(-3, 3)
            if nv == old or nv in work:
                continue
            work[i] = nv
            sc = _score_np(work)
            if sc > base_score:
                base_score = sc
                cand = sorted(set(work))
            else:
                work[i] = old
        cand = sorted(set(work))

    if len(cand) > 4000:
        cand = cand[:4000]
    cand = [int(x) for x in cand if abs(x) <= 10 ** 15]
    if len(cand) < 2:
        return [0, 1, 3]
    return cand
# EVOLVE-BLOCK-END
