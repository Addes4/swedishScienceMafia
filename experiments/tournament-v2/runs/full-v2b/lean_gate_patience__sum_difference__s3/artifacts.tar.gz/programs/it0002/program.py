# EVOLVE-BLOCK-START
"""Sidon-set construction maximizing |A-A| with a refinement step to shrink |A+A|."""
import math
import random
import time


def _metrics(a):
    a = list(set(a))
    if len(a) < 2:
        return 0, 0, 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    nd, ns = len(diffs), len(sums)
    score = math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100
    return nd, ns, score


def _sidon_set(n, p, mult):
    """Golomb/Sidon-like set: x_i = mult*i + (i*i mod p). Differences mostly distinct."""
    return [mult * i + (i * i) % p for i in range(n)]


def solve():
    deadline = time.time() + 110
    best_a, _, best_s = None, None, -1.0

    # Try several Sidon constructions and pick best; then locally refine.
    candidates = []
    for p in (101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157,
              163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227,
              229, 233, 239, 241, 251):
        for mult in (2 * p, 3 * p, 4 * p, 6 * p, 8 * p, 10 * p, 12 * p):
            for n in (40, 60, 80, 100, 120, 140, 160):
                if n > p:
                    continue
                candidates.append(_sidon_set(n, p, mult))

    for a in candidates:
        if time.time() > deadline - 40:
            break
        nd, ns, s = _metrics(a)
        if s > best_s:
            best_s, best_a = s, a

    # Local refinement: perturb one element and accept if score improves.
    cur = best_a[:]
    cur_s = best_s
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-2, 2)
        nd, ns, s = _metrics(cand)
        if s >= cur_s:
            cur, cur_s = cand, s
            if s > best_s:
                best_a, best_s = cand[:], s

    return sorted(set(best_a))
# EVOLVE-BLOCK-END
