# EVOLVE-BLOCK-START
"""Digit-tensor construction with numpy scoring for many differences and few sums."""
import math
import time
import numpy as np


def _score_arr(A):
    A = np.unique(np.asarray(A, dtype=np.int64))
    n = A.size
    if n < 2:
        return 0.0, 0
    # differences
    d = (A[:, None] - A[None, :]).ravel()
    d = np.unique(d)
    # sums
    s = (A[:, None] + A[None, :]).ravel()
    s = np.unique(s)
    if s.size == 0:
        return 0.0, n
    val = math.log(d.size) / math.log(s.size) + (1 - 1 / n) / 100
    return val, n


def _build(digits, base, k):
    """A = { sum d_i * base^i : d_i in digits }, dense via iterative cartesian."""
    A = np.array([0], dtype=np.int64)
    p = 1
    for _ in range(k):
        ds = np.array(sorted(digits), dtype=np.int64)
        A = (A[:, None] + ds[None, :] * p).ravel()
        A = np.unique(A)
        p *= base
    return A


def _build_mixed(digit_sets, base):
    """A with per-position digit sets."""
    A = np.array([0], dtype=np.int64)
    p = 1
    for ds in digit_sets:
        d = np.array(sorted(ds), dtype=np.int64)
        A = (A[:, None] + d[None, :] * p).ravel()
        A = np.unique(A)
        p *= base
        if A.size > 4000:
            break
    return A


def solve():
    t0 = time.time()
    budget = 100.0

    best = None
    best_score = -1.0

    # candidate digit set seeds
    seeds = [
        {0, 1}, {0, 1, 2}, {0, 1, 3}, {-1, 0, 1}, {-1, 1},
        {-2, -1, 0, 1, 2}, {0, 1, 2, 3}, {0, 1, 3, 4}, {0, 1, 4, 5},
    ]
    seeds += [{0, 1, d} for d in range(2, 10)]
    seeds += [{1, d} for d in range(2, 20)]

    # ---------- Family 1: single digit set, search base/k ----------
    for digits in seeds:
        for base in range(2, 13):
            for k in range(2, 9):
                if len(digits) ** k > 4000:
                    continue
                if len(digits) ** k < 2:
                    continue
                A = _build(digits, base, k)
                if A.size < 2 or A.size > 4000:
                    continue
                if np.max(np.abs(A)) > 10**15:
                    continue
                s, _ = _score_arr(A)
                if s > best_score:
                    best_score = s
                    best = A.copy()
        if time.time() - t0 > budget * 0.5:
            break

    # ---------- Family 2: local search on digit sets (time-bounded) ----------
    def score_digits(ds, base, k):
        A = _build(ds, base, k)
        if A.size < 2 or A.size > 4000:
            return -1.0, None
        if np.max(np.abs(A)) > 10**15:
            return -1.0, None
        s, _ = _score_arr(A)
        return s, A

    cur_seeds = [{-1, 0, 1}, {0, 1}, {0, 1, 2}, {-1, 0, 1, 2}, {0, 1, 3}]
    for ds0 in cur_seeds:
        ds = set(ds0)
        for base in [3, 4, 5, 6]:
            # find best k for this size
            kbest = 2
            for k in range(2, 9):
                if len(ds) ** k <= 4000:
                    kbest = k
                else:
                    break
            curb, curA = score_digits(ds, base, kbest)
            if curA is None:
                continue
            improved = True
            while improved and time.time() - t0 < budget:
                improved = False
                # try adding a digit
                m = max(ds) if ds else 0
                mn = min(ds) if ds else 0
                for cand in list(range(mn - 1, m + 2)):
                    if cand in ds:
                        continue
                    nd = set(ds)
                    nd.add(cand)
                    if len(nd) ** kbest > 4000 or len(nd) < 2:
                        continue
                    s, A = score_digits(nd, base, kbest)
                    if s > curb:
                        ds, curb, curA = nd, s, A
                        improved = True
                        break
                if improved:
                    continue
                # try removing a digit
                for cand in list(ds):
                    if len(ds) <= 2:
                        break
                    nd = set(ds)
                    nd.discard(cand)
                    s, A = score_digits(nd, base, kbest)
                    if s > curb:
                        ds, curb, curA = nd, s, A
                        improved = True
                        break
            if curA is not None and curb > best_score:
                best_score = curb
                best = curA.copy()

    # ---------- Family 3: mixed radix, per-position digit sets ----------
    # combine sum-poor small digit sets across positions
    mixed_families = [
        ([{-1, 0, 1}] * 7, 3),
        ([{0, 1}] * 8, 3),
        ([{-1, 0, 1}] * 6, 4),
        ([{0, 1}] * 6, 5),
        ([{-2, -1, 0, 1, 2}] * 5, 3),
        ([{-1, 0, 1}] * 5, 6),
        ([{0, 1}] * 5, 7),
        ([{-1, 0, 1}] * 8, 3),
    ]
    for dsets, base in mixed_families:
        A = _build_mixed(dsets, base)
        if A.size < 2 or A.size > 4000:
            continue
        if np.max(np.abs(A)) > 10**15:
            continue
        s, _ = _score_arr(A)
        if s > best_score:
            best_score = s
            best = A.copy()

    if best is None:
        best = np.array([0, 1], dtype=np.int64)

    return [int(x) for x in np.unique(best)]
# EVOLVE-BLOCK-END
