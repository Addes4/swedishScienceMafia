# EVOLVE-BLOCK-START
"""Find a digit set S maximizing log|S-S|/log|S+S|, then tensor it in base B.

For A = { sum_{i<k} d_i * B^i : d_i in S } with B > max|s+-s'| for all s,s' in S,
there are no carries, so |A-A| = |S-S|^k and |A+A| = |S+S|^k. Hence
score = log|S-S|/log|S+S| (dimension independent), and the bonus grows with |A|=|S|^k.
So we maximize the ratio over small S, then tensor to maximize |A| <= 4000.
"""
import math
import itertools
import random
import time

import numpy as np


def _ratio(S):
    S = np.asarray(sorted(set(int(x) for x in S)), dtype=np.int64)
    if len(S) < 2:
        return -1.0
    D = (S[:, None] - S[None, :]).ravel()
    U = (S[:, None] + S[None, :]).ravel()
    nd = len(np.unique(D))
    nu = len(np.unique(U))
    if nu < 2 or nd < 2:
        return -1.0
    return math.log(nd) / math.log(nu)


def _stats(S):
    S = np.asarray(sorted(set(int(x) for x in S)), dtype=np.int64)
    D = set((S[:, None] - S[None, :]).ravel().tolist())
    U = set((S[:, None] + S[None, :]).ravel().tolist())
    return U, D


def solve():
    deadline = time.time() + 100.0

    bestS = None
    bestR = -1.0

    # ---- Exhaustive search over tiny digit sets ----
    R = 12
    for sz in range(2, 6):
        for comb in itertools.combinations(range(-R, R + 1), sz):
            r = _ratio(comb)
            if r > bestR:
                bestR = r
                bestS = comb
        if time.time() > deadline * 0.25:
            break

    # ---- Structured seeds ----
    seeds = []
    if bestS is not None:
        seeds.append(tuple(bestS))
    # geometric-ish and small dense seeds
    for b in (2, 3, 4):
        for k in range(2, 8):
            seeds.append(tuple(sorted(int(b ** i) for i in range(k))))
    for c in (1, 3, 5):
        for k in range(2, 10):
            seeds.append(tuple(sorted(range(0, k * c + 1, c))))

    # ---- Long hill-climb maximizing the ratio ----
    climb_deadline = deadline * 0.9
    rng = random.Random(12345)
    for seed0 in seeds:
        if time.time() > climb_deadline:
            break
        r = _ratio(seed0)
        if r > bestR:
            bestR, bestS = r, tuple(sorted(set(seed0)))
        S = set(seed0)
        for _ in range(400):
            if time.time() > climb_deadline:
                break
            T = set(S)
            if rng.random() < 0.5 and len(T) > 2:
                T.discard(rng.choice(sorted(T)))
            else:
                T.add(rng.randint(-300, 300))
            if len(T) < 2:
                continue
            rr = _ratio(T)
            if rr >= r:
                S, r = T, rr
                if rr > bestR:
                    bestR, bestS = rr, tuple(sorted(T))

    # ---- Randomized multi-element perturbation restarts ----
    while time.time() < climb_deadline:
        sz = rng.randint(4, 20)
        S = set(rng.sample(range(-300, 301), sz))
        r = _ratio(S)
        if r > bestR:
            bestR, bestS = r, tuple(sorted(S))
        for _ in range(60):
            if time.time() > climb_deadline:
                break
            T = set(S)
            T.discard(rng.choice(sorted(T)) if rng.random() < 0.5 else min(T))
            T.add(rng.randint(-300, 300))
            if len(T) < 2:
                continue
            rr = _ratio(T)
            if rr >= r:
                S, r = T, rr
                if rr > bestR:
                    bestR, bestS = rr, tuple(sorted(T))

    if bestS is None:
        bestS = (0, 1, 3)
    S = list(bestS)

    # ---- Tensor S into a base-B digit set with as many dims as fit ----
    U, D = _stats(S)
    maxU = max(abs(x) for x in U)
    maxD = max(abs(x) for x in D)
    B = max(maxU, maxD) + 1
    if B < 2:
        B = 2
    maxabs = max(abs(x) for x in S)

    bestA = None
    k = 1
    while True:
        size = len(S) ** k
        if size > 4000:
            break
        mag = maxabs * (B ** k - 1) // (B - 1) if B > 1 else 0
        if mag > 10 ** 15:
            break
        A = [0]
        p = 1
        for _ in range(k):
            nxt = []
            for a in A:
                for d in S:
                    nxt.append(a + d * p)
            A = nxt
            p *= B
        if len(set(A)) <= 4000:
            bestA = A
        k += 1

    if bestA is not None:
        cand = sorted(set(int(x) for x in bestA))
        if len(cand) <= 4000 and all(abs(x) <= 10 ** 15 for x in cand):
            return cand

    return sorted(set(int(x) for x in S))
# EVOLVE-BLOCK-END
