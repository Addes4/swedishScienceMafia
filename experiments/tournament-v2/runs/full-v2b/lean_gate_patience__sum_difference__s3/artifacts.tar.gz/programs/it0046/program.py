# EVOLVE-BLOCK-START
"""Structured base-b digit-pattern construction for sets with many differences and few sums.

Idea: build A = { sum_{i=0}^{L-1} d_i * b^i : d_i in S }, where S is a small digit
alphabet and b is a base large enough that base-b representations are unique.  Then
every element of A has a unique base-b digit string, so differences of two elements
are essentially determined by their digitwise difference vector.  By contrast sums
build up carries / collisions much more readily, so |A+A| tends to stay small.

To make |A - A| large we want the difference set of A to be as big as possible.  For
the "product" set construction this is governed by the difference set of S and how
carries interact; we simply enumerate small candidate (S, b, L) triples, score them
exactly, and keep the best.

Scoring is exact: we materialise |A| up to a few thousand elements and compute the
difference and sum sets directly.  A time budget keeps the whole thing well under
the 120 s limit.
"""

import math
import time
from itertools import combinations


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    if len(sums) == 0 or len(diffs) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(S, b, L):
    """A = { sum d_i * b^i : d_i in S }, as a sorted list of ints."""
    vals = [0]
    pw = 1
    for _ in range(L):
        new = []
        for v in vals:
            for d in S:
                new.append(v + d * pw)
        vals = new
        pw *= b
    return sorted(set(vals))


def _digit_sets():
    """Small digit alphabets to try."""
    cands = []
    # intervals starting at 0
    for k in range(2, 7):
        cands.append(tuple(range(k)))
    # intervals with a gap
    cands.append((0, 2))
    cands.append((0, 3))
    cands.append((0, 1, 3))
    cands.append((0, 1, 4))
    cands.append((0, 2, 3))
    cands.append((0, 2, 5))
    cands.append((0, 1, 2, 4))
    # Sidon-ish / sparse sets that give big difference sets
    cands.append((0, 1, 3, 7))
    cands.append((0, 1, 4, 6))
    cands.append((0, 2, 5, 9))
    cands.append((0, 1, 2, 5, 8))
    cands.append((0, 1, 3, 4, 9))
    # shifted variants (include negative digits to shift mass)
    base = list(cands)
    for s in base:
        cands.append(tuple(-d for d in s))
    out = []
    seen = set()
    for s in cands:
        s = tuple(sorted(set(s)))
        if len(s) >= 2 and s not in seen:
            seen.add(s)
            out.append(s)
    return out


def solve():
    deadline = time.time() + 100
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    best = sorted(set(best))

    digits = _digit_sets()

    # Enumerate bases and lengths.  Keep |A| <= ~1200 for exact scoring speed
    # but also allow a few larger sets near the end if time permits.
    tried = 0
    for S in digits:
        d = len(S)
        if d < 2:
            continue
        for L in range(2, 9):
            size = d ** L
            if size < 6 or size > 1400:
                continue
            smin = min(S)
            smax = max(S)
            span = smax - smin
            # plausible bases: large enough to separate digits, but not absurd
            for b in range(span + 1, span + 12):
                if time.time() > deadline:
                    break
                A = _build(S, b, L)
                if len(A) < 2:
                    continue
                tried += 1
                sc = _score(A)
                if sc > best_score:
                    best_score = sc
                    best = A[:]
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # Local refinement: small integer perturbations of the best found set,
    # but keep it cheap (only a handful of moves).
    if time.time() < deadline:
        cur = best[:]
        cur_score = best_score
        rng_state = 12345
        while time.time() < deadline:
            rng_state = (1103515245 * rng_state + 12345) & 0x7FFFFFFF
            i = rng_state % len(cur)
            delta = (rng_state >> 8) % 5 - 2
            cand = cur[:]
            cand[i] += delta
            cand = sorted(set(cand))
            sc = _score(cand)
            if sc >= cur_score:
                cur = cand
                cur_score = sc
                if sc > best_score:
                    best_score = sc
                    best = cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
