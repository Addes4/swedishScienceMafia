# EVOLVE-BLOCK-START
"""Construct sets from base-b digit patterns where sums collide but differences stay distinct."""
import math
import itertools
import time


def _score_exact(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    if len(sums) == 0:
        return 0.0, 0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs)


def _build(base, digit_set, dim):
    """A = all sums of digits*digit_set over dim places."""
    A = [0]
    p = 1
    for _ in range(dim):
        nd = [a + d * p for a in A for d in digit_set]
        A = list(set(nd))
        p *= base
        if len(A) > 4000:
            return None
    return A


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # Candidate digit sets: consecutive-ish blocks and symmetric/small sets.
    digit_candidates = []
    for k in range(2, 6):
        digit_candidates.append(tuple(range(k)))
        digit_candidates.append(tuple(range(-k, k + 1)))
    digit_candidates += [
        (0, 1), (0, 1, 3), (0, 1, 2, 4), (0, 1, 4), (0, 2, 3),
        (-1, 0, 1), (-2, -1, 0, 1, 2), (0, 1, 5), (0, 3, 4),
        (0, 1, 2, 5), (0, 1, 3, 4), (1, 3, 4), (1, 2, 4),
        (0, 1, 2, 3, 4, 5), (0, 1, 2, 4, 5, 6),
    ]
    # dedupe
    seen = set()
    dc = []
    for d in digit_candidates:
        key = tuple(sorted(set(d)))
        if key not in seen and len(key) >= 2:
            seen.add(key)
            dc.append(key)
    digit_candidates = dc

    bases = list(range(3, 30))

    trials = []
    for d in digit_candidates:
        for b in bases:
            maxdim = 1
            while len(d) ** maxdim <= 4500:
                maxdim += 1
            for dim in range(1, maxdim):
                # quick size estimate; collisions may shrink
                trials.append((b, d, dim))

    # Shuffle-ish: prioritize more digits (bigger potential diff sets)
    trials.sort(key=lambda t: (-len(t[1]), t[2]))

    for base, dset, dim in trials:
        if time.time() > deadline:
            break
        A = _build(base, dset, dim)
        if A is None or len(A) < 8 or len(A) > 4000:
            continue
        s, nd = _score_exact(A)
        if s > best_score:
            best_score = s
            best = list(A)

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
