# EVOLVE-BLOCK-START
"""Bose/Béh-Sidon construction refined by exact-score hill climbing."""
import math
import random
import time


def _score(a):
    a = list(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(n_max=4000):
    # Bose-Chowla / Beh style: A = { i*M + (i*i mod p) }
    # choose p prime ~ n, M large so that offsets don't collide.
    best = None
    best_score = -1.0
    for p in (251, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317,
              331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401):
        n = min(p, n_max)
        M = 1_000_000
        A = [i * M + ((i * i) % p) for i in range(n)]
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A
    return best, best_score


def solve():
    """Return A with large A-A and small A+A."""
    best, best_score = _build()
    cur = best[:]
    cur_score = best_score
    n = len(cur)
    deadline = time.time() + 110
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        i = random.randrange(n)
        step = random.randint(-1000, 1000) if random.random() < 0.7 else random.randint(-50, 50)
        cand[i] += step
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        # occasional restart to best
        if it % 400 == 0 and cur_score < best_score:
            cur = best[:]
            cur_score = best_score
    return sorted(set(best))
# EVOLVE-BLOCK-END
