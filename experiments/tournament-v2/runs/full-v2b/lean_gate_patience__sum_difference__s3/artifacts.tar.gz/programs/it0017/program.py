# EVOLVE-BLOCK-START
"""Search directly for an integer set A maximizing log|A-A|/log|A+A|.

Key facts:
 - For A = { sum d_i B^i : d_i in S } (digit tensoring, B larger than any |S+-S|),
   |A-A| = |S-S|^k and |A+A| = |S+S|^k, so the figure of merit is exactly
   log|S-S| / log|S+S|, independent of k.
 - The bonus (1 - 1/|A|)/100 favors larger |A|, so we take the largest k with |S|^k <= 4000.

So the whole game is: find the best small digit set S (minimize |S+S| relative to
|S-S|), then tensor it to fill 4000. We search S hard with a fast numpy scorer.
"""
import math
import itertools
import random
import time

import numpy as np


def _score_digits(S):
    """Return (log|S-S|/log|S+S|, |S-S|, |S+S|) for the small digit set S."""
    a = np.asarray(S, dtype=np.int64)
    n = a.size
    if n < 2:
        return -1.0, 0, 0
    d = np.unique((a[:, None] - a[None, :]).ravel())
    s = np.unique((a[:, None] + a[None, :]).ravel())
    nd, ns = d.size, s.size
    if nd < 2 or ns < 2:
        return -1.0, nd, ns
    return math.log(nd) / math.log(ns), nd, ns


def _search_digit_sets(deadline):
    """Find a digit set S with a great |S-S|/|S+S| ratio."""
    bestS = (0, 1)
    bestR = -1.0

    # ---- exhaustive tiny alphabets ----
    R = 10
    for sz in range(2, 5):
        for comb in itertools.combinations(range(-R, R + 1), sz):
            r, _, _ = _score_digits(comb)
            if r > bestR:
                bestR = r
                bestS = comb

    # ---- randomized multi-restart hill climb on larger digit sets ----
    # We bias towards sets whose pairwise sums collide a lot: seed with
    # arithmetic-progression-like / structured sets, then climb.
    rng = random.Random(12345)
    climb_deadline = deadline
    while time.time() < climb_deadline:
        sz = rng.randint(4, 24)
        span = rng.choice([30, 60, 120, 300, 1000])
        if rng.random() < 0.5:
            # structured seed: scaled arithmetic-ish pattern
            step = rng.randint(1, max(1, span // sz))
            S = set(x * step + rng.randint(-1, 1) for x in range(sz))
        else:
            S = set(rng.sample(range(-span, span + 1), min(sz, 2 * span + 1)))
        if len(S) < 2:
            continue
        r, _, _ = _score_digits(S)
        if r > bestR:
            bestR = r
            bestS = tuple(sorted(S))
        # steepest-ish ascent with random restarts
        cur_r = r
        for _ in range(300):
            if time.time() > climb_deadline:
                break
            T = list(S)
            T[rng.randrange(len(T))] = rng.randint(-span, span)
            T = set(T)
            if len(T) < 2:
                continue
            rr, _, _ = _score_digits(T)
            if rr > bestR:
                bestR = rr
                bestS = tuple(sorted(T))
            if rr >= cur_r:
                S = T
                cur_r = rr
        # occasional basin hopping: keep best if improved, else jump
        if rng.random() < 0.3:
            S = set(bestS)

    return bestS, bestR


def solve():
    deadline = time.time() + 100.0

    bestS, bestR = _search_digit_sets(time.time() + 80.0)
    S = list(bestS)

    if len(S) < 2:
        S = [0, 1]

    # ---- tensor S in base B as far as fits (|A| <= 4000, |coords| <= 1e15) ----
    # B must exceed every element of |S+-S| so digits are read off uniquely.
    a = np.asarray(S, dtype=np.int64)
    dmax = int(np.max(np.abs(a[:, None] - a[None, :])))
    smax = int(np.max(np.abs(a[:, None] + a[None, :])))
    B = max(dmax, smax) + 1
    if B < 2:
        B = 2
    maxabs = max(abs(x) for x in S)

    bestA = None
    bestk = 0
    for k in range(1, 20):
        size = len(S) ** k
        if size > 4000:
            break
        mag = maxabs * (B ** k - 1) // (B - 1) if B > 1 else 0
        if mag > 10 ** 15:
            break
        A = [0]
        p = 1
        for _ in range(k):
            nxt = []
            for av in A:
                for dv in S:
                    nxt.append(av + dv * p)
            A = nxt
            p *= B
        if len(set(A)) <= 4000:
            bestA = A
            bestk = k

    if bestA is None:
        bestA = list(S)

    cand = sorted(set(int(x) for x in bestA))
    if len(cand) > 4000:
        cand = cand[:4000]
    cand = [int(x) for x in cand if abs(x) <= 10 ** 15]
    if len(cand) < 2:
        return [0, 1, 3]
    return cand
# EVOLVE-BLOCK-END
