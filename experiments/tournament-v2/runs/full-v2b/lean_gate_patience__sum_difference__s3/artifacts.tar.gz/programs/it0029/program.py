# EVOLVE-BLOCK-START
"""Structured search over base-b digit tensors, emphasising symmetric digit
sets (which force many additive collisions while keeping many differences),
with fast exact scoring and a broad deterministic sweep."""
import math
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(b, S, length):
    a = [0]
    p = 1
    for _ in range(length):
        a = [x + d * p for x in a for d in S]
        p *= b
    return a


def solve():
    deadline = time.time() + 100.0
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    seeds = [
        [0, 1],
        [0, 1, 2],
        [0, 1, 3],
        [-1, 0, 1],
        [-1, 0, 1, 2],
        [-2, -1, 0, 1, 2],
        [-1, 0, 1, 3],
        [-3, -1, 0, 1, 3],
        [-2, -1, 0, 1, 2, 3],
        [-1, 0, 1, 2, 3, 4],
        [0, 1, 2, 4, 8],
        [-4, -2, -1, 0, 1, 2, 4],
    ]

    tried = set()
    for S0 in seeds:
        for b in range(3, 40):
            # try the seed and a couple of deterministic expansions
            variants = [S0[:]]
            for extra in range(1, 3):
                S = S0[:]
                k = len(S)
                for e in range(extra):
                    base = S0[e % len(S0)]
                    cand = base + (e + 1) * (1 if e % 2 == 0 else -1)
                    if cand not in S:
                        S.append(cand)
                variants.append(sorted(set(S)))
            for S in variants:
                if max(abs(d) for d in S) >= b:
                    continue
                n0 = len(S)
                maxlen = 0
                while (n0 ** (maxlen + 1) <= 4000
                       and b ** (maxlen + 1) <= 10**15):
                    maxlen += 1
                for length in range(2, maxlen + 1):
                    key = (b, tuple(S), length)
                    if key in tried:
                        continue
                    tried.add(key)
                    if time.time() > deadline:
                        break
                    a = _build(b, S, length)
                    if len(a) > 4000:
                        continue
                    if max(abs(x) for x in a) > 10**15:
                        continue
                    s = _score(a)
                    if s > best_score:
                        best_score, best = s, a
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    best = sorted(set(best))
    if _score(best) < best_score:
        best = _build(3, [0, 1], 2)
    return best
# EVOLVE-BLOCK-END
