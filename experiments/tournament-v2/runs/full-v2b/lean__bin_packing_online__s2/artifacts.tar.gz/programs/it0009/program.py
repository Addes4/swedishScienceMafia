# EVOLVE-BLOCK-START
"""Best fit with a small reservation preference to reduce new-bin creation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    # Pure best-fit baseline: tighter fit (smaller remaining capacity) is better.
    base = -(bins - item)

    # Bonus for bins whose remaining capacity after placement is a small positive
    # "reservable" gap that could absorb future small items, so we don't waste it.
    slack = bins - item  # 0 for an exact fit
    bonus = 0.0 * slack
    # Small positive gaps (1..10) are valuable for future tiny items; slightly
    # prefer leaving such a gap over fragmenting with a larger one.
    bonus = np.where((slack >= 1) & (slack <= 10), 0.02, 0.0)

    return base + bonus
# EVOLVE-BLOCK-END
