# EVOLVE-BLOCK-START
"""Hybrid best fit: best fit normally, but small items preferentially into partially filled bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    if item <= 25:
        # For small items, prefer filling bins that are already somewhat used but
        # still have some slack (avoid squeezing into a nearly-full bin).
        # Score = prefer smallest remaining capacity that is >= item + 13.
        target = bins >= (item + 13)
        if target.any():
            return np.where(target, -(bins - item), -1e9)
    # Default: best fit (smallest remaining capacity that fits).
    return -(bins - item)
# EVOLVE-BLOCK-END

