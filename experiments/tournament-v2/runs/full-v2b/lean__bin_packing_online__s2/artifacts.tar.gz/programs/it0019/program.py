# EVOLVE-BLOCK-START
"""Best fit with a bonus for closing bins completely."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Bonus: strongly prefer to fully close a bin (residual 0).
    score += 1000.0 * (residual == 0)
    # Mild bonus: prefer leaving a larger-than-tiny residual over a tiny unusable one.
    score += 0.0001 * (residual >= 5)
    return score
# EVOLVE-BLOCK-END
