# EVOLVE-BLOCK-START
"""Best-fit with an exact-fill preference and a sharp modal tie-break.

Core rule: classic best-fit (smallest resulting residual).  On top of that we
strongly reward an exact fill (residual 0), and add a tiny tie-break that
prefers residuals equal to a frequently observed item size, using the live
empirical histogram.  All secondary terms use small integer-like magnitudes so
they only break near-ties and never override best-fit.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant: best fit -> smaller resulting residual is better.
    score = -r * 1000.0

    # Strong reward for exact fill (no leftover).
    score += (residual == 0).astype(np.float64) * 500.0

    # Tiny modal tie-break: reward residuals equal to a common item size.
    n = _stats.count
    if n > 0:
        freq = _stats.sizes / n
        rr = np.clip(residual, 0, 100).astype(np.int64)
        score += freq[rr] * 10.0

    # Prefer reusing already-open bins over completely fresh ones.
    score -= (bins >= 100).astype(np.float64)

    return score
# EVOLVE-BLOCK-END
