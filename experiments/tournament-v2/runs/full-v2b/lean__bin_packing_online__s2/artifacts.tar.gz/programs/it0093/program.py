# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware perfect-match tiebreak.

Primary rule: classic best-fit (smaller resulting residual is better).
Secondary, small reward: residual close to the empirical mean item size,
which tends to be a good candidate for being filled by a future item.
This keeps the strong best-fit behavior while nudging toward residuals
that can be cleanly consumed later.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0

    def update(self, item):
        self.count += 1
        self.total += item


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: classic best fit.
    score = -r

    # Distribution-aware target residual: empirical mean item size.
    mean_item = _stats.total / _stats.count

    # Small bonus when residual matches the expected next-item size.
    # Using an exponential kernel keeps it smooth and bounded.
    diff = r - mean_item
    score += 0.05 * np.exp(-(diff * diff) / 200.0)

    # Tiny tiebreak: prefer reusing already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.001

    return score
# EVOLVE-BLOCK-END

