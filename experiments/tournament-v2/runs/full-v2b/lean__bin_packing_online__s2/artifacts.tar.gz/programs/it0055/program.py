# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with expected-waste / fill-potential ranking.

For each candidate bin we look at the resulting residual r = bins - item.
Two considerations drive the score:

1. Best fit: a smaller residual is generally better (base = -r).
2. Distribution awareness: a residual that is a "good fit" for the observed
   size distribution is worth more.  We estimate, for each residual r, the
   probability that the *next* item can be placed nicely and, more importantly,
   the expected leftover waste if we subsequently pack items greedily into r.

The key quantity is the expected number of items (drawn from the empirical
distribution) that fit into a residual of size r, and the expected residual
after one such item.  Residuals where the distribution packs tightly (i.e. the
expected leftover after a greedy fill is small relative to r) are preferred.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()

# Cache of fill-potential values keyed by residual 0..100.
_cache_key = -1
_fill = None
_waste = None


def _build_tables(count):
    """Compute fill-potential and expected-waste tables for residuals 0..100."""
    global _cache_key, _fill, _waste
    if count == _cache_key:
        return
    _cache_key = count
    freq = _stats.sizes / max(count, 1)
    cdf = np.cumsum(_stats.sizes) / max(count, 1)

    r = np.arange(101, dtype=np.float64)
    # Probability that a single future item fits in residual r.
    fit_prob = np.zeros(101)
    for i in range(101):
        fit_prob[i] = cdf[min(i, 100)]

    # Expected fraction of residual filled by one item: E[min(item, r)] / r.
    mean = _stats.total / max(count, 1)
    fillfrac = np.zeros(101)
    for i in range(1, 101):
        # E[min(item, i)] = sum_s freq[s] * min(s, i)
        e = np.sum(freq[1:101] * np.minimum(np.arange(1, 101), i))
        fillfrac[i] = e / i

    _fill = fillfrac
    _waste = 1.0 - fit_prob


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    rr = np.clip(residual, 0, 100).astype(np.int64)

    # Base: best fit -> smaller resulting residual is better.
    score = -residual.astype(np.float64)

    if _stats.count > 0:
        _build_tables(_stats.count)

        # Reward residuals that the distribution fills efficiently.
        score += _fill[rr] * 30.0

        # Penalize residuals that are unlikely to accept a future item
        # (stranded space).
        score -= _waste[rr] * 20.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
