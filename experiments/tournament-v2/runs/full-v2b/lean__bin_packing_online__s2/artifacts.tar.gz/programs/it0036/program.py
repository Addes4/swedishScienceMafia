# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware smooth penalty for stranding bins."""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0

    def update(self, item):
        self.count += 1
        self.total += item


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    _stats.update(item)

    mean_item = _stats.total / _stats.count
    T = float(mean_item) * 0.8

    residual = bins - item
    residual_f = residual.astype(np.float64)

    # Smooth penalty for residuals that are hard to reuse: strongest for tiny
    # positive residuals, fading out as the residual approaches a typical item size.
    small = (residual_f > 0) & (residual_f < T)
    penalty = np.where(small, T - residual_f, 0.0)

    # Reward exact fills strongly.
    exact = (residual == 0).astype(np.float64) * 40.0

    return -(residual_f) - penalty + exact
# EVOLVE-BLOCK-END
