# EVOLVE-BLOCK-START
"""Best fit with an exact-fill bonus: prefer sealing a bin completely."""
import numpy as np


def priority(item, bins):
    """Rank bins; item goes to highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities of all bins it fits in.
    """
    residual = bins - item
    # Base: best fit (smallest residual after placement is best).
    score = -residual.astype(np.float64)
    # Small bonus for perfectly sealing a bin (residual == 0) so exact
    # fills win near-ties without disturbing clear best-fit choices.
    score += (residual == 0) * 0.1
    return score
# EVOLVE-BLOCK-END
