# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with waste and fit-volume terms."""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    if _stats.count > 0:
        freq = _stats.sizes / _stats.count  # freq[s] = P(item == s)

        cdf = np.cumsum(_stats.sizes) / _stats.count

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(item > r): stranded space.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 60.0

        # Perfect-refill bonus: residual equals a common size or decomposes
        # into two common sizes.
        one = freq[rr]
        two = np.zeros_like(one)
        for s in range(1, 101):
            k = np.arange(1, s)
            if k.size:
                two_s = float(np.dot(freq[k], freq[s - k]))
                if two_s:
                    two[rr == s] += two_s
        match = np.maximum(one, 0.5 * two)
        score += match * 30.0

        # Fit-volume: reward residuals in dense mass region (many future
        # items fit and would pack tightly). Approximate by probability that
        # a fresh item fits within r, weighted by how well it fits.
        fits = np.where(residual >= 1, 1.0 - cdf[np.clip(rr - 1, 0, 100)], 0.0)
        # fraction of the residual that the average fitting item occupies
        score += fits * 3.0

    # Tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
