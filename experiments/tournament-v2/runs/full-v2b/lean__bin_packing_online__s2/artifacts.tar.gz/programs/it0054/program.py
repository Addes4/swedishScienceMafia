# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a waste-probability penalty and an
expected-fill reward.

For each candidate bin we compute the resulting residual r = bins - item.
We keep the classic best-fit base (-r), subtract a penalty proportional to the
probability mass of future items that are too large to fit in r (so residuals
that would be stranded are discouraged), and add a reward for residuals that
the next item is likely to fill well (E[min(item, r)] / r).
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    if _stats.count > 0:
        freq = _stats.sizes / _stats.count  # freq[s] = P(item == s)
        cdf = np.cumsum(_stats.sizes) / _stats.count

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Waste penalty: mass of future items too big to fit in residual r.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 60.0

        # Expected-fill reward: E[min(item, r)] / r.
        # E[min(item, r)] = sum_{s<r} s*freq[s] + r*P(item >= r).
        sizes_idx = np.arange(101, dtype=np.float64)
        below_mass = np.cumsum(sizes_idx * freq)  # sum_{s<=k} s*freq[s]
        # sum_{s<r} s*freq[s] = below_mass[r-1] (or 0 if r==0)
        r_high = np.clip(rr, 0, 100)
        idx_prev = np.clip(r_high - 1, 0, 100)
        sum_below = np.where(rr > 0, below_mass[idx_prev], 0.0)
        prob_ge_r = np.where(rr >= 100, 0.0, 1.0 - (cdf[idx_prev] if True else 0.0))
        # P(item >= r) = 1 - P(item <= r-1)
        p_le_prev = np.where(rr > 0, cdf[idx_prev], 0.0)
        prob_ge_r = np.where(rr >= 100, 0.0, 1.0 - p_le_prev)
        exp_fill = sum_below + r_high * prob_ge_r
        # Normalize by residual to get a fill fraction in [0, 1].
        frac = np.where(r_high > 0, exp_fill / np.maximum(r_high, 1.0), 0.0)
        score += frac * 20.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
