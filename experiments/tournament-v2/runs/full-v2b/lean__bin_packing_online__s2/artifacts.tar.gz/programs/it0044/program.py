# EVOLVE-BLOCK-START
"""Distribution-aware best-fit: prefer bins whose residual after placement is reusable.

A bin is only truly "stranded" if its leftover capacity cannot fit a typical future
item.  We estimate the item-size distribution online and score each candidate bin by
(a) preferring small residuals (best fit) and (b) rewarding residuals that can be
consumed by typical future items (fillability).  A tiny tiebreak nudges toward
reusing already-open bins rather than grabbing fresh ones.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()

# Cache the last computed fillability lookup so we don't recompute every call.
_fill_cache = {"count": -1, "table": None}


def _fillability_table():
    """For each residual capacity 0..100, estimate how likely at least one
    observed future item fits into it (i.e., it is not a permanently stranded
    sliver).  We use the probability that the residual is >= some typical
    item size, weighted by that size's frequency."""
    if _fill_cache["count"] == _stats.count:
        return _fill_cache["table"]
    freq = _stats.sizes / _stats.count if _stats.count else np.zeros(101)
    # table[r] = probability a random future item s <= r, i.e. sum_{s<=r} freq[s].
    cdf = np.cumsum(freq)
    table = cdf[:101].copy()
    _fill_cache["count"] = _stats.count
    _fill_cache["table"] = table
    return table


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)
    b = bins.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    # Distribution-aware fillability: reward residuals that can still accept
    # some likely future item (larger "prob an item fits" is better).
    table = _fillability_table()
    if _stats.count > 0:
        valid = (residual >= 0) & (residual <= 100)
        fill = np.zeros(r.shape, dtype=np.float64)
        # log-prob makes low-fill residuals strongly penalized, high-fill rewarded.
        fill[valid] = table[residual[valid].astype(np.int64)]
        score += fill * 25.0

    # Penalize residuals that are too small to accept anything likely.
    if _stats.count > 0:
        usable = table[residual.clip(0, 100).astype(np.int64)]
        score -= ((residual >= 0) & (usable < 0.1)).astype(np.float64) * 15.0

    # Small tiebreak: reuse already-open bins (residual < 100) over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
