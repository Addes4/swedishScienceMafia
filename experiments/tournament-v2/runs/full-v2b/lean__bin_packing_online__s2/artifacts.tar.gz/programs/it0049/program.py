# EVOLVE-BLOCK-START
"""Distribution-aware best fit.

Core rule: best fit -- place the item in the fitting bin that leaves the smallest
residual.  This keeps bins packed tightly and is a classic strong online heuristic
for Weibull-shaped sizes.

Two light distribution-aware refinements:
1) A residual that exactly equals a commonly observed item size is "reusable"
   (a future item will fill it exactly), so reward such residuals a bit.
2) Prefer reusing already-open bins over opening a fresh bin (tiny tiebreak).
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Core: best fit -> smallest residual is best.
    score = -r

    # Reward residuals that are exactly a commonly-seen item size (reusable).
    if _stats.count >= 50:
        freq = _stats.sizes / _stats.count
        match = np.zeros(r.shape, dtype=np.float64)
        valid = (residual >= 1) & (residual <= 100)
        idx = residual[valid].astype(np.int64)
        match[valid] = freq[idx]
        score += match * 20.0

    # Tiny tiebreak: prefer already-open bins to fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.05

    return score
# EVOLVE-BLOCK-END
