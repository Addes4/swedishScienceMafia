# EVOLVE-BLOCK-START
"""Best-fit with a distribution-derived expected-waste tiebreak.

The dominant term is classic best-fit (smallest resulting residual).  Ties
(and near-ties) are broken by the expected "stranded space" of a residual,
estimated online from the empirical item-size distribution: the space r that
is smaller than the next arriving item is wasted.  We also give a small bonus
when a residual exactly equals a commonly observed item size, since it can be
filled perfectly.  All distribution terms are scaled well below 1 so they
cannot reorder clearly better (smaller-residual) bins.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count or n == 0:
        return
    freq = _stats.sizes / n
    cdf = np.cumsum(_stats.sizes) / n
    two = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best fit -> smaller residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Probability the next item is too large for this residual -> wasted space.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        # Expected wasted space attributable to this residual.
        waste = prob_too_big * residual
        # Bonus: residual exactly matches a common single or pair of sizes.
        match = np.maximum(freq[rr], two[rr])

        # Both scaled < 1 so they only break near-ties, not override best-fit.
        score -= waste / 100.0
        score += match * 0.5

    # Tiny tiebreak: prefer already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.01

    return score
# EVOLVE-BLOCK-END
