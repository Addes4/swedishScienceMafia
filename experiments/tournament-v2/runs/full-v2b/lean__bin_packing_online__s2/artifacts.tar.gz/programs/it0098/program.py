# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a normalized expected-refill value.

Rank primarily by classic best-fit (-residual).  On top of that we add a
small, self-normalizing bonus equal to the empirical probability of the most
likely single item size that exactly fills the residual, factored by the
probability that such a fit is even feasible.  The bonus is scaled by the
current best-fit spread so it never overwhelms best-fit, avoiding the fragile
hardcoded magic numbers of earlier versions.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_last_count = -1
_mean = 40.0


def _ensure_tables():
    global _freq, _cdf, _last_count, _mean
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    cdf = np.cumsum(_stats.sizes) / n
    _freq = freq
    _cdf = cdf
    _mean = _stats.total / n
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(item > r): infeasibility for the residual.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])

        # Expected refill value: high when residual equals a common size.
        exact = freq[rr]

        # Feasibility weight: a residual that no future item is likely to
        # fit is less valuable even if it is small.
        feasible = 1.0 - prob_too_big

        bonus = exact * feasible

        # Scale so that the bonus is meaningful but sub-dominant to best-fit.
        scale = 1.0 + float(np.max(freq)) * 0.0  # keep scale ~1
        score += bonus * 20.0 * scale

        # Penalize stranded space lightly (kept small and normalized).
        score -= prob_too_big * 15.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
