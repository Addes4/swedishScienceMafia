# EVOLVE-BLOCK-START
"""Best-fit with a bounded, smoothed distribution tiebreaker.

Pure best-fit (-r) dominates.  Distribution information (stranded-space
probability, usability) is added as a strictly bounded correction with
magnitude well under 1, so it only breaks ties between equal residuals.
Tables are Gaussian-smoothed and refreshed lazily as items arrive.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_last_count = -1


def _smooth(freq):
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    return K.dot(w)


def _ensure_tables():
    global _freq, _cdf, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n
    sw = _smooth(freq)
    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw
    _freq = sm
    _cdf = cdf
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        cdf = _cdf
        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Bounded correction, magnitude well under 1 (tie-breaker only).
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 0.4

        usability = np.where(residual >= 100, 1.0, cdf[rr])
        score += usability * 0.2

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.01

    return score
# EVOLVE-BLOCK-END
