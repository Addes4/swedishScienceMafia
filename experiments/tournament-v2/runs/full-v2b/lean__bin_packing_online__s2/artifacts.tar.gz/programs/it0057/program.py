# EVOLVE-BLOCK-START
"""Best-fit with waste-probability penalty and fillability reward.

For each candidate bin we compute the resulting residual r = bins - item.
Base score is classic best-fit (-r). We subtract a penalty proportional to the
probability mass of future items that are too large to fit in r (so residuals
that would be stranded are discouraged), and add a reward proportional to the
probability mass of future items that DO fit in r (fillability), which favors
residuals aligned with common item sizes.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    if _stats.count > 0:
        cdf = np.cumsum(_stats.sizes) / _stats.count

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Waste penalty: P(item > r) mass that cannot fit.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 50.0

        # Fillability reward: P(item <= r) mass that does fit.
        prob_fit = np.where(residual >= 100, 1.0, cdf[rr])
        score += prob_fit * 8.0

    # Tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
