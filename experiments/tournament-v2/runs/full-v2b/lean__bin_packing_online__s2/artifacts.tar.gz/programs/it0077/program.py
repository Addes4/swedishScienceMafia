# EVOLVE-BLOCK-START
"""Distribution-aware best-fit.

The dominant term is classic best-fit: prefer the smallest resulting residual.
Small, bounded corrections refine the choice using the observed item-size
distribution:
  * reward residuals that exactly equal a common item size (perfect refill),
  * mildly reward residuals decomposable into two common item sizes,
  * mildly penalize residuals that are too small to fit a typical next item
    (stranded space).
All corrections are scaled so best-fit remains the primary ordering.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n
    cdf = np.cumsum(_stats.sizes) / n
    two = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best fit (smallest residual is best).
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Perfect-refill bonus: residual equal to a common size, or a common
        # sum of two sizes. Bounded in [0, 1] by construction.
        one = freq[rr]
        match = np.maximum(one, two[rr])
        score += match * 0.6

        # Mild stranded-space penalty: probability no future item fits.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 0.5

    # Tiny tiebreak: prefer reusing already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.05

    return score
# EVOLVE-BLOCK-END

