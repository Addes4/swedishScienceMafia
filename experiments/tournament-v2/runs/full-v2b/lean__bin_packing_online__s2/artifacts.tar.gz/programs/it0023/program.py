# EVOLVE-BLOCK-START
"""Best-fit variant that consolidates items into already-used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Resulting residual after placing the item.
    residual = bins - item
    # Tightness: prefer smallest residual (dominant term, scaled so it always wins).
    tight = -(residual.astype(np.float64))
    # Consolidation bonus: prefer bins that are already more full (smaller remaining capacity),
    # i.e. avoid opening/using lightly-used bins. Small so it only breaks near-ties.
    fullness = -(bins.astype(np.float64))
    return tight * 1000.0 + fullness
# EVOLVE-BLOCK-END
