# EVOLVE-BLOCK-START
"""Best-fit dominated with a tiny distribution-aware tiebreak.

The residual ordering from classic best-fit is made strictly dominant by a
large multiplier.  Distribution knowledge only breaks exact-residual ties:
residuals that can be exactly closed by one or two frequently observed item
sizes get a small bonus, favouring bins that can be perfectly refilled.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_two = None
_last_count = -1


def _ensure_tables():
    global _freq, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    two = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: classic best-fit (smaller residual is better).
    score = -r * 1000.0

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        two = _two
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Tie-break bonus: residual exactly fillable by one common size,
        # or by two common sizes.  Kept tiny (scale < 1) so it never
        # overrides the residual ordering.
        match = np.maximum(freq[rr], two[rr])
        score += match

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 1e-3

    return score
# EVOLVE-BLOCK-END

