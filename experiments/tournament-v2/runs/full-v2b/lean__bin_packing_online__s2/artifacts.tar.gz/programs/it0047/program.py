# EVOLVE-BLOCK-START
"""Distribution-aware bin choice: combine best-fit with a match-made reuse score.

Items arrive online. We keep an online estimate of the item-size distribution.
For each candidate bin we compute the residual after placement and score it by
(a) best fit (small residual preferred) and (b) a "reuse potential" term that
rewards residuals which can be neatly filled by typical future items, penalizing
slivers that are too small to fit anything meaningful.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    mean_item = _stats.total / _stats.count if _stats.count else 40.0
    T = max(1.0, mean_item * 0.5)

    residual = bins - item
    r = residual.astype(np.float64)
    b = bins.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    # Penalize unusable slivers (too small to fit a typical item).
    sliver = ((residual > 0) & (residual < T)).astype(np.float64)
    score -= sliver * 20.0

    # Match-made term: reward residuals that a typical item (or a couple of them)
    # can fill nearly exactly, which keeps the bin useful.
    if _stats.count > 0:
        freq = _stats.sizes / _stats.count
        match = np.zeros(r.shape, dtype=np.float64)
        valid = (residual >= 1) & (residual <= 100)
        idx = residual[valid].astype(np.int64)
        match[valid] = freq[idx]
        # Also reward residuals that are close to a sum of two typical items.
        score += match * 30.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END

