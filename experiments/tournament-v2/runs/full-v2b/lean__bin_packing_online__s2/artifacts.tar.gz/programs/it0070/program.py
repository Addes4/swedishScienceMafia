# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a light exact-refill preference.

Base score is classic best-fit.  On top of it we add a small bounded bonus when
the resulting residual equals a frequently observed item size (so the bin can be
closed exactly by a future item), while penalizing residuals only mildly when they
are too small to fit most future items.  The bonus is kept small so best-fit
remains the dominant signal.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    _freq = _stats.sizes / n
    _cdf = np.cumsum(_stats.sizes) / n
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Primary signal: best fit -> smallest resulting residual is best.
    score = -r

    _ensure_tables()

    if _freq is not None:
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Small bonus when residual equals a common item size (exact refill).
        score += _freq[rr] * 4.0
        # Mild penalty for residuals too small for most future items.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - _cdf[rr])
        score -= prob_too_big * 3.0

    # Slight preference to reuse already-open bins.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.05

    return score
# EVOLVE-BLOCK-END
