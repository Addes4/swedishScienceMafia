# EVOLVE-BLOCK-START
"""Distribution-aware best-fit: prefer bins whose residual after placement is reusable.

The key idea is that a bin is only truly "stranded" if its leftover capacity cannot fit
a typical future item.  We estimate the item-size distribution online and score each
candidate bin by (a) preferring small residuals (best fit) and (b) giving a bonus when
the resulting residual is close to a value that a real item in the 1..100 range could
use up, i.e. it aligns with an actually observed item size.  Slivers below the smallest
plausible item are penalized.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        # Exponential-ish memory of recent item sizes to gauge what sizes are common.
        self.sizes = np.zeros(101, dtype=np.float64)  # histogram of observed sizes

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    mean_item = _stats.total / _stats.count if _stats.count else 40.0
    # Smallest "common" item size: use a low percentile of the observed distribution,
    # but keep a floor so early calls behave sensibly.
    T = max(1.0, mean_item * 0.5)

    residual = bins - item

    # Base: best fit -> smaller residual gets higher score.
    score = -residual.astype(np.float64)

    # Penalize leaving a sliver too small to hold a typical item, unless exact fill.
    sliver = ((residual > 0) & (residual < T)).astype(np.float64)
    score -= sliver * 20.0

    # Reward residuals that exactly equal a frequently-seen item size (reusable).
    # Use big bins with residual 100 (still unused) as neutral, not penalized.
    return score
# EVOLVE-BLOCK-END
