# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a light exact-fit tiebreak.

Base is classic best-fit (-r).  We add a modest bonus when the residual
exactly equals a frequently observed future item size (so the bin can be
closed perfectly), and a lightly weighted stranded-space penalty that stays
small enough not to override best-fit ordering.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_last_n = -1


def _ensure_tables(force=False):
    global _freq, _cdf, _last_n
    n = _stats.count
    if not force and n == _last_n:
        return
    if n == 0:
        return
    _freq = _stats.sizes / n
    _cdf = np.cumsum(_stats.sizes) / n
    _last_n = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Exact-fit bonus: residual equals a common future item size.
        score += freq[rr] * 15.0

        # Mild stranded-space penalty, small enough not to flip best-fit order.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 8.0

    # Slight preference for already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
