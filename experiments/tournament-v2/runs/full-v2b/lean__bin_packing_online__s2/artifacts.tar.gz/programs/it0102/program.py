# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a warmup phase.

For the first fraction of the stream we use pure best-fit to lay down a solid
packing skeleton without being misled by noisy early statistics.  After warmup
we add a modest stranded-space penalty and a perfect-refill bonus driven by the
empirical size distribution.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1

_WARMUP = 750  # ~15% of 5000


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    cdf = np.cumsum(_stats.sizes) / n
    # two[s] = P(two independent items sum exactly to s), for s in 0..100
    two = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    # Warmup: pure best-fit, plus small preference for already-open bins.
    if _stats.count <= _WARMUP:
        fresh = (bins >= 100).astype(np.float64)
        score -= fresh * 0.1
        return score

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(item > r): for r>=100 it's 0; else 1 - CDF(r).
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 40.0

        # Perfect-refill bonus: residual exactly equal to a common size,
        # or decomposable into two common sizes.
        one = freq[rr]
        match = np.maximum(one, two[rr])
        score += match * 30.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END

