# EVOLVE-BLOCK-START
"""Best-fit with a parametric Weibull-edged distribution model.

Items are drawn from a Weibull-shaped distribution.  Instead of a noisy
empirical histogram, we fit a Weibull distribution to the running mean and
variance of observed items (method of moments) to get a smooth, stable
estimate of the size distribution from the first few items.  Best-fit (-r)
remains the dominant term; a small usability bonus and stranded-space penalty
derived from the fitted model guide tie-breaking toward residuals that can
still be filled.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sumsq = 0.0

    def update(self, item):
        self.count += 1
        self.total += item
        self.sumsq += item * item


_stats = _Stats()
_ready = False
_cdf = None
_pdf = None
_last_count = -1
_pdf_lookup = None  # pdf evaluated at integer sizes 1..100
_cdf_lookup = None  # cdf evaluated at integer sizes 1..100


def _fit_weibull():
    n = _stats.count
    mean = _stats.total / n
    var = _stats.sumsq / n - mean * mean
    if var <= 1e-6:
        var = 1.0
    cv = (var ** 0.5) / max(mean, 1e-6)
    # Approximate shape from coefficient of variation (Weibull heuristic).
    # For Weibull, cv ~ 1; smaller cv -> larger shape k.
    k = max(0.8, min(6.0, 1.2 / max(cv, 0.05)))
    lam = max(1.0, mean)
    return k, lam


def _build_tables():
    global _cdf_lookup, _pdf_lookup, _ready, _last_count
    k, lam = _fit_weibull()
    xs = np.arange(1, 101, dtype=np.float64)
    # CDF of Weibull(k, lam) scaled so that mass on 1..100 approximates 1.
    z = (xs / lam) ** k
    cdf_raw = 1.0 - np.exp(-z)
    # density (unnormalized) used only for relative comparisons
    pdf_raw = (k / lam) * (xs / lam) ** (k - 1.0) * np.exp(-z)
    tot = pdf_raw.sum()
    if tot > 0:
        pdf_raw = pdf_raw / tot
    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:] = cdf_raw
    cdf[100] = max(cdf[100], cdf_raw[-1])
    # ensure monotone nondecreasing and within [0,1]
    cdf = np.clip(cdf, 0.0, 1.0)
    np.maximum.accumulate(cdf, out=cdf)
    _cdf_lookup = cdf
    _pdf_lookup = pdf_raw
    _ready = True
    _last_count = _stats.count


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    # Refit occasionally (every call up to 50, then every 20) to stay fresh
    # but cheap.
    n = _stats.count
    if not _ready or n <= 50 or n % 20 == 0:
        _build_tables()

    if _ready:
        cdf = _cdf_lookup
        rr = np.clip(residual, 1, 100).astype(np.int64)
        zero = residual <= 0
        # P(future item > r): stranded space probability.
        prob_too_big = np.where(zero | (residual >= 100), 0.0, 1.0 - cdf[rr])
        # Usability: probability at least one future item fits in r.
        usability = np.where(residual >= 100, 1.0, cdf[rr])
        usability = np.where(zero, 0.0, usability)

        score -= prob_too_big * 12.0
        score += usability * 4.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
