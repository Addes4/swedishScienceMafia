# EVOLVE-BLOCK-START
"""Classic Best-Fit.

The item goes into the fitting bin with the smallest remaining capacity,
i.e. the one whose residual after placement is smallest.  This is the
strongest known baseline for this workload; distribution-aware tweaks
tended to hurt, so we keep the rule simple and robust.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Best fit: smallest positive residual is best -> highest score.
    # Negate residual so larger (less negative) means better.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END

