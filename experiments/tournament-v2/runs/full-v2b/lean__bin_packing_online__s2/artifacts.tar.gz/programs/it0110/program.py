# EVOLVE-BLOCK-START
"""Best-fit with a single principled tie refinement.

Primary term: -residual (classic best-fit, dominant).
Refinement: penalize residuals that are likely to strand space.  A residual r
is bad if future items are probably larger than r (dead space).  We measure the
probability P(future item > r) and penalize it, but scaled by a small factor so
best-fit dominance is preserved and only near-ties are affected.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n
    cdf = np.cumsum(_stats.sizes) / n
    _freq = freq
    _cdf = cdf
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        cdf = _cdf
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(future item > r): dead space probability.  0 when r >= 100.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        # Small penalty preserves best-fit dominance on clear differences
        # but breaks near-ties toward bins that can still absorb items.
        score -= prob_too_big * 1.5

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.05

    return score
# EVOLVE-BLOCK-END

