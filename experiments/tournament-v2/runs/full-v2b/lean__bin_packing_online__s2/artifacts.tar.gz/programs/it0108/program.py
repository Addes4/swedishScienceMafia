# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware near-tie refinement.

Score = -residual (classic best-fit, dominant for any residual gap >= 1).
For residuals within 1 of each other the exact unit difference is preserved
by an epsilon multiplier so best-fit ordering is never violated.  A small
refill bonus, using the empirical probability that the residual can be
exactly closed by one future item, only nudges truly near-equal choices.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_last_count = -1


def _ensure_tables():
    global _freq, _last_count
    n = _stats.count
    if n == _last_count or n == 0:
        return
    _freq = _stats.sizes / n
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best fit -> smaller residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        rr = np.clip(residual, 0, 100).astype(np.int64)
        one = _freq[rr]
        # Tiny bonus: never exceeds 0.5, so it cannot flip a difference of 1
        # in residual (which contributes 1.0 to score).
        score += one * 0.5

    return score
# EVOLVE-BLOCK-END

