# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with waste-probability penalty and refill bonus."""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)
        self.dirty = True
        self.cdf = None
        self.freq = None
        self.two = None

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0
        self.dirty = True

    def refresh(self):
        if not self.dirty:
            return
        n = self.count
        self.freq = self.sizes / n
        self.cdf = np.cumsum(self.sizes) / n
        freq = self.freq
        # two[s] = sum_{k=1}^{s-1} freq[k]*freq[s-k] for s=1..100
        two = np.zeros(101, dtype=np.float64)
        for s in range(1, 101):
            k = np.arange(1, s)
            if k.size:
                two[s] = float(np.dot(freq[k], freq[s - k]))
        self.two = two
        self.dirty = False


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)
    _stats.refresh()

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    cdf = _stats.cdf
    freq = _stats.freq
    two = _stats.two

    rr = np.clip(residual, 0, 100).astype(np.int64)

    # P(item > r): stranded-space probability.
    prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
    # Weight anyway by residual magnitude so large stranded space hurts more.
    score -= prob_too_big * (60.0 + 0.5 * r)

    # Perfect-refill bonus.
    one = freq[rr]
    two_b = two[rr]
    match = np.maximum(one, 0.6 * two_b)
    score += match * 30.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
