# EVOLVE-BLOCK-START
"""Distribution-aware best-fit using an expected-fit-count score.

We keep best-fit as the base but rescale it so the dominant signal is still
"smaller residual", then add a bounded bonus for residuals that the empirical
size distribution can likely refill, and a bounded penalty for residuals that
are likely to be stranded.  All weights are expressed relative to the mean
item size so they stay meaningful across the distribution.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_mean = 40.0
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _two, _mean, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    cdf = np.cumsum(_stats.sizes) / n
    # two[s] = P(two independent items sum exactly to s), for s in 0..100
    two = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        k = np.arange(1, s)
        two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _mean = max(1.0, float(_stats.total) / n)
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Refill bonus: residual that matches a common single size or a
        # common two-item sum is likely to be closed exactly later.
        one = freq[rr]
        match = np.maximum(one, two[rr])
        score += match * (0.9 * _mean)

        # Stranding penalty: large residuals that are still too small to
        # accept typical items waste space.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * (1.4 * _mean)

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.05

    return score
# EVOLVE-BLOCK-END
