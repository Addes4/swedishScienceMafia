# EVOLVE-BLOCK-START
"""Best-fit with a mild probability-based tiebreak.

Rank primarily by best-fit (-residual) so the dominant rule stays robust,
then add a small bonus for residuals that exactly match a likely next item
size, scaled by the empirical probability but capped so it only breaks ties.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_last_count = -1


def _ensure_tables():
    global _freq, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    _freq = _stats.sizes / n
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Bonus for exact single-item refill, capped so it only breaks ties.
        one = freq[rr]
        score += np.minimum(one, 0.05) * 1.0

    # Tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.01

    return score
# EVOLVE-BLOCK-END
