# EVOLVE-BLOCK-START
"""Distribution-aware best-fit: prefer bins whose residual after placement is reusable.

A bin is only truly "stranded" if its leftover capacity cannot fit a typical future
item.  We estimate the item-size distribution online and score each candidate bin by
(a) preferring small residuals (best fit) and (b) rewarding residuals that align with
an actually observed item size (Sum-of-Squares style "match made").  A tiny tiebreak
nudges toward reusing already-open bins rather than grabbing fresh ones.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    mean_item = _stats.total / _stats.count if _stats.count else 40.0
    T = max(1.0, mean_item * 0.5)

    residual = bins - item
    r = residual.astype(np.float64)
    b = bins.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    # Penalize unusable slivers.
    sliver = ((residual > 0) & (residual < T)).astype(np.float64)
    score -= sliver * 20.0

    # Reward residuals that match a commonly-seen item size (reusable).
    if _stats.count > 0:
        freq = _stats.sizes / _stats.count
        match = np.zeros(r.shape, dtype=np.float64)
        valid = (residual >= 1) & (residual <= 100)
        idx = residual[valid].astype(np.int64)
        match[valid] = freq[idx]
        score += match * 30.0

    # Small tiebreak: reuse already-open bins (residual < 100) over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
