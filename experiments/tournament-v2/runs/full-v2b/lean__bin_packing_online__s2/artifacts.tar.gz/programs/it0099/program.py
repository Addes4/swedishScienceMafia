# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a normalized closeability score.

For each candidate bin we compute the resulting residual r = bins - item.
Base is classic best-fit (-r).  On top we add:

  * a "closeability" bonus proportional to the empirical probability that
    some single observed item size exactly equals r (i.e. this bin can be
    perfectly closed by the next item), and
  * a normalized stranded-space penalty proportional to the fraction of the
    residual that is likely to never be filled (P(item > r) weighted by r).

All terms are scaled relative to the residual magnitude so no fixed magic
constants dominate, keeping best-fit as the primary rule.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    _freq = _stats.sizes / n          # freq[s] = P(item == s)
    _cdf = np.cumsum(_stats.sizes) / n  # cdf[s] = P(item <= s)
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Closeability: probability the residual equals a common item size.
        # Scaled by residual so the bonus is bounded and comparable to -r.
        close = freq[rr]
        score += close * 40.0

        # Stranded-space penalty: the portion of the residual that future
        # items are unlikely to fill (prob next item exceeds r). Weight by
        # residual size so larger hopeless gaps are penalized more.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * r * 0.6

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
