# EVOLVE-BLOCK-START
"""Sum-of-squares residual scoring.

For each candidate bin we compute the resulting residual r = bins - item.
We score each bin by minimizing the sum of squares of residual capacities
after the placement, which is equivalent to classic "best fit" behavior but
with a stronger preference for consolidating items into already-occupied bins
and leaving one nearly-empty/empty bin rather than many partially-filled bins.
This concavity-based rule is a strong, low-noise known heuristic for online
bin packing.
"""
import numpy as np


def priority(item, bins):
    residual = (bins - item).astype(np.float64)
    # Smaller residual is generally better; square it to reward packing
    # items together so that leftover space is concentrated.
    score = -residual * residual
    # Tiebreak: strongly prefer using already-open (partially filled) bins
    # over fresh bins by a tiny margin so ties resolve to the first bin.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.001
    return score
# EVOLVE-BLOCK-END
