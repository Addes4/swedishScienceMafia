# EVOLVE-BLOCK-START
"""Best-fit bin packing.

Classic best-fit: choose the bin with the smallest remaining capacity that
still fits, which current experiments show outperforms the distribution-aware
heuristic variants on this Weibull item distribution.
"""
import numpy as np


def priority(item, bins):
    # Best-fit: the largest item that still fits leaves the smallest residual.
    residual = bins - item
    # Maximize score => prefer smallest non-negative residual.
    return -residual.astype(np.float64)
# EVOLVE-BLOCK-END
