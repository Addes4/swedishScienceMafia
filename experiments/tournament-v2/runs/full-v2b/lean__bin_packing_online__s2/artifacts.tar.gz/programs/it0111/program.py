# EVOLVE-BLOCK-START
"""Best-fit dominant rule with tiny distribution-aware tiebreaks.

The residual (bins - item) drives the decision with a large multiplier so
that smaller residual always wins.  Only when residuals are essentially
equal do the distribution-aware terms (stranded-space penalty and
closable-bin bonus) break the tie.  This keeps classic best-fit intact
while still preferring bins whose leftover can be neatly reused.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    cdf = np.cumsum(_stats.sizes) / n
    # two[s] = P(two independent items sum exactly to s), for s in 0..100
    two = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant best-fit term: larger multiplier makes residual differences
    # always outweigh the tiny tiebreak terms below.
    score = -r * 1000.0

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(item > r): stranded-space risk for this residual.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 0.5

        # Closable-bin bonus: residual matches a common size, or sums of two.
        one = freq[rr]
        match = np.maximum(one, two[rr])
        score += match * 0.5

    # Tiny tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.001

    return score
# EVOLVE-BLOCK-END
