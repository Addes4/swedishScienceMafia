# EVOLVE-BLOCK-START
"""Best fit with a near-tie preference for fuller bins (reduces fragmentation)."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: smaller residual after placement (classic best fit).
    # Near-tie (within 1) preference for the bin that was already fuller,
    # i.e. smaller pre-placement residual, to smooth out fragmentation.
    return -(residual.astype(np.float64) * 2.0) - bins.astype(np.float64)
# EVOLVE-BLOCK-END
