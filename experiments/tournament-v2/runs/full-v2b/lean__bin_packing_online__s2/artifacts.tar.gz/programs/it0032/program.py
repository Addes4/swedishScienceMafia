# EVOLVE-BLOCK-START
"""Best fit with a guard against leaving uselessly small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer tightest fit (smallest residual), but slightly penalize residuals
    # that are too small to be reusable by a typical future item.
    # Mean item ~40, so a residual below ~10 is nearly useless; treat those
    # as if they were slightly larger so a fresh bin may win instead.
    tiny = residual < 10
    score = -residual.astype(np.float64)
    score = np.where(tiny, -residual.astype(np.float64) - 5.0, score)
    return score
# EVOLVE-BLOCK-END
