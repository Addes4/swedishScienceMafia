# EVOLVE-BLOCK-START
"""Distribution-aware best-fit + reusable-residual scoring.

We estimate the item-size distribution online.  For each candidate bin we score the
resulting residual r = bins - item by:
  (a) best-fit: prefer smaller r,
  (b) reuse: reward r that can exactly fit a common future item size,
  (c) waste: penalize r that is too small to be useful (below a small percentile of
      the observed sizes), scaled by how unlikely it is to be reusable.
A tiny nudge prefers already-open bins over fresh ones.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)
    b = bins.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    if _stats.count > 0:
        freq = _stats.sizes / _stats.count

        # Waste penalty: residual r is at risk if no observed size fits into it.
        # Use cumulative distribution: prob(useful) ~ 1 - CDF(r-1).
        cdf = np.cumsum(freq)  # cdf[s] = P(size <= s)
        rc = np.clip(residual, 0, 100).astype(np.int64)
        prob_fit = np.where(residual >= 1, 1.0 - cdf[np.maximum(rc - 1, 0)], 0.0)
        waste = 1.0 - prob_fit  # small residuals mostly unusable
        score -= waste * 10.0

        # Reuse reward: residual equal to a commonly seen item size.
        match = np.where((residual >= 1) & (residual <= 100), freq[rc], 0.0)
        score += match * 30.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
