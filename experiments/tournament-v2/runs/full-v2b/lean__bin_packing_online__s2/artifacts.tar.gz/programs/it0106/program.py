# EVOLVE-BLOCK-START
"""Best-fit with a light exact-fill tie-break bonus.

The dominant term is classic best-fit: prefer the smallest resulting residual.
A small bonus, proportional to the empirical probability that the residual can
be exactly filled by one future item, refines near-ties without overriding the
core best-fit ordering (the bonus coefficient is kept well below 1).
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_last_count = -1


def _ensure_tables():
    global _freq, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    _freq = _stats.sizes / n
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Small bonus for residuals that could be exactly closed by one item.
        # Coefficient < 1 so best-fit remains dominant.
        score += freq[rr] * 0.5

    return score
# EVOLVE-BLOCK-END

