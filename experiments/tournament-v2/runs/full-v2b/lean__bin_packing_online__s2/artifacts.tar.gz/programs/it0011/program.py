# EVOLVE-BLOCK-START
"""Best fit with a tiny position tie-breaker to consolidate into earlier bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    # Prefer the tightest fit (smallest remaining capacity), i.e. largest -(bins - item).
    # Add a tiny bonus for lower bin indices so ties consolidate into earlier bins.
    base = -(bins - item).astype(np.float64)
    idx = np.arange(n, dtype=np.float64)
    return base - idx * 1e-6
# EVOLVE-BLOCK-END
