# EVOLVE-BLOCK-START
"""Best-fit with a bounded, distribution-aware tie-break.

Primary rule: classic best fit (place into the bin with the smallest
non-negative residual, i.e. maximize -residual).

Tie-break (magnitude strictly less than 1, so it can never override
best-fit): prefer residuals that are likely to be exactly refillable by a
single future item, and penalize residuals that no typical future item can
ever fill (dead space).  Both signals come from a smoothed empirical CDF
of the item sizes observed so far and fade in as data accumulates.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _last_count
    n = _stats.count
    if n == _last_count or n == 0:
        return
    freq = _stats.sizes / n  # empirical P(item == s)

    # Light Gaussian smoothing over integer sizes 1..100.
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    sw = K.dot(w)

    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw

    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    _freq = sm
    _cdf = cdf
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best fit.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Refill bonus: probability a future item exactly equals this residual.
        refill = freq[rr]

        # Dead-space penalty: probability that no typical future item fits.
        # (1 - CDF(r)); for r >= 100 this is 0.
        dead = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])

        # Bounded tie-break strictly below 1 in magnitude.
        score += 0.6 * refill - 0.3 * dead

    return score
# EVOLVE-BLOCK-END
