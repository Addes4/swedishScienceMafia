# EVOLVE-BLOCK-START
"""Best fit with a mild "fullness" bonus to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Score each fitting bin; highest wins.

    Primary: best fit (smallest remaining capacity >= item).
    Secondary: slight preference for already-fuller bins, controlled by a
    small weight on the remaining-capacity term.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in.
    """
    slack = bins - item
    # Best fit is -slack.  Adding a small multiple of -bins (i.e. preferring
    # fuller bins) breaks near-ties toward fuller bins without overriding the
    # tightest-fit choice.
    return -(slack) - 0.05 * bins
# EVOLVE-BLOCK-END

