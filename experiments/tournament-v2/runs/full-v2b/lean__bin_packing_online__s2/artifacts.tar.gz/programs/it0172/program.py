# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a waste-probability penalty.

For each candidate bin we compute the resulting residual r = bins - item.
Base is classic best-fit (-r).  We subtract a penalty proportional to the
probability that future items are too large to fit in r (stranded space),
and add a bounded "perfect refill" bonus when r can be exactly decomposed
into one or two frequently observed item sizes.  A usability term rewards
residuals likely to fit at least one more future item.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _smooth(freq):
    """Gaussian-smooth the size distribution over integer sizes 1..100."""
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    sw = K.dot(w)
    return sw


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)

    sw = _smooth(freq)
    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw

    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    two = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        idx = np.arange(1, s)
        if idx.size:
            two[s] = float(np.dot(sm[idx], sm[s - idx]))

    _freq = sm
    _cdf = cdf
    _two = two
    _last_count = n


# Precompute the set of item sizes we care about for gap checking.
_k = np.arange(1, 101, dtype=np.int64)


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(item > r): stranded space.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 55.0

        # Perfect-refill bonus.
        one = freq[rr]
        match = np.maximum(one, two[rr])
        score += match * 32.0

        # Second-fit on the last step of convolution.
        second = np.zeros_like(r)
        for s in range(1, 101):
            ps = freq[s]
            if ps <= 1e-6:
                continue
            rr2 = np.clip(residual - s, 0, 100).astype(np.int64)
            valid = residual - s >= 0
            contrib = np.where(valid, freq[rr2], 0.0)
            second += ps * contrib
        score += np.minimum(second, 1.0) * 12.0

        # Usability: probability that at least one future item fits in r.
        usability = np.where(residual >= 100, 1.0, cdf[rr])
        score += usability * 8.0

        # Small-gap penalty: if residual is just above a common size
        # (a wasted sliver that can rarely be filled), dampen it a bit.
        # For each residual, find the largest common size <= r and measure
        # the gap; penalize gaps in (0, 2] that waste a sliver.
        gap_pen = np.zeros_like(r)
        for s in range(1, 100):
            ps = freq[s]
            if ps <= 1e-4:
                continue
            gap = residual - s
            hit = (gap > 0.0) & (gap <= 2.0)
            gap_pen += np.where(hit, ps, 0.0)
        score -= np.minimum(gap_pen, 1.0) * 3.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END

