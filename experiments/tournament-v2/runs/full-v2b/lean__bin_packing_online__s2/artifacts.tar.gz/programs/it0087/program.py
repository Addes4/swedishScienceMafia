# EVOLVE-BLOCK-START
"""Best-fit with a light distribution-aware residual preference.

Primary rule: classic best-fit (smallest resulting residual wins).
Tiebreak: among near-tie residuals, prefer the one where a future item is
most likely to land with small leftover, estimated from past-item stats.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_last_count = -1


def _ensure_tables():
    global _freq, _last_count
    n = _stats.count
    if n == _last_count or n == 0:
        return
    _freq = _stats.sizes / n
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = (bins - item).astype(np.float64)
    r = np.clip(residual, 0, 100).astype(np.int64)

    # Dominant term: best fit.
    score = -residual

    _ensure_tables()
    if _freq is not None:
        freq = _freq

        # Expected leftover if a random future item is packed into residual r:
        # sum over sizes s <= r of freq[s] * (r - s).
        # We want small expected leftover -> subtract it as a small tiebreak.
        # Compute using cumulative sums of freq and s*freq.
        cdf = np.cumsum(freq)          # cdf[s] = P(item <= s)
        sf = freq * np.arange(101)     # s * P(item=s)
        csum = np.cumsum(sf)           # sum_{s<=k} s*P(item=s)

        # expected leftover for residual rr
        p_fit = cdf[r]                 # probability item fits
        exp_s = csum[r]                # E[s * 1(s<=r)]
        exp_leftover = r * p_fit - exp_s
        # Normalize; only acts as a small tiebreak on top of best-fit.
        score -= exp_leftover * 0.05

    # Small preference for reusing already-open bins.
    score -= (bins >= 100).astype(np.float64) * 0.01

    return score
# EVOLVE-BLOCK-END

