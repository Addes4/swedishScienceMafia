# EVOLVE-BLOCK-START
"""Best fit with a small bias toward fuller bins to avoid opening many partial bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: tightest fit (smallest remaining capacity after placing item).
    # Secondary: slight preference for already-fuller bins (smaller remaining capacity now).
    return -(bins - item) * 1000.0 - bins
# EVOLVE-BLOCK-END

