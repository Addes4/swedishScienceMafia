# EVOLVE-BLOCK-START
"""Best-fit with a mild distribution-aware tiebreak.

Primary key: best fit (smallest residual) - this was the strongest component
in earlier experiments. Secondary: among residuals that are close, prefer one
that equals a common future item size (so it can be cleanly refilled), and
apply only a mild penalty for residuals likely to strand space.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_last_count = -1
_REBUILD = 64


def _ensure_tables():
    global _freq, _cdf, _last_count
    n = _stats.count
    if n == 0 or (n - _last_count) < _REBUILD:
        return
    freq = _stats.sizes / n
    cdf = np.cumsum(_stats.sizes) / n
    _freq = freq
    _cdf = cdf
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best fit.
    score = -r

    _ensure_tables()

    if _freq is not None:
        cdf = _cdf
        freq = _freq

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Mild stranded-space penalty: only for residuals where future items
        # are likely too big.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 5.0

        # Mild preference: residual exactly a common item size.
        score += freq[rr] * 3.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.05

    return score
# EVOLVE-BLOCK-END
