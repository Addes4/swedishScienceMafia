# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with cached two-item closure bonus.

Base is classic best-fit (-r).  We add a bonus proportional to the empirical
probability that the residual can be exactly closed by ONE common item size
(freq[r]) or by TWO common item sizes (sum_k freq[k]*freq[r-k], the
self-convolution of the size distribution).  A residual likely to be closed
exactly by future items is effectively free space, so this rewards packing
efficiency beyond greedy best-fit.  The convolution is cached and refreshed
only when the accumulated statistics change.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)
        self.conv = np.zeros(201, dtype=np.float64)
        self.conv_at = -1

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0

    def get_conv(self):
        if self.conv_at != self.count:
            freq = self.sizes / self.count if self.count else self.sizes
            f = freq[0:101]
            self.conv = np.convolve(f, f)  # index s -> P(two items sum to s)
            self.conv_at = self.count
        return self.conv


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    if _stats.count > 0:
        freq = _stats.sizes / _stats.count
        conv = _stats.get_conv()

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(residual exactly matched by one future item)
        one = freq[rr]
        # P(residual exactly matched by two future items)
        two = conv[rr]

        # Reward residuals that can be exactly consumed by future items.
        score += one * 30.0
        score += two * 15.0

        # Penalize stranded residuals: probability the next item is too big.
        cdf = np.cumsum(_stats.sizes) / _stats.count
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 40.0

    # Small tiebreak: prefer reusing already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
