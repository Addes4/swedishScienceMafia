# EVOLVE-BLOCK-START
"""Best fit with a tiny consolidation bonus to break near-ties toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Dominant term: prefer the smallest residual (classic best fit).
    # Tiny secondary term: prefer bins that stay fuller (smaller residual already covered),
    # but push away from leaving a too-small residual that wastes a bin for future items.
    tiny = residual < 5
    return -residual + 1e-6 * tiny
# EVOLVE-BLOCK-END
