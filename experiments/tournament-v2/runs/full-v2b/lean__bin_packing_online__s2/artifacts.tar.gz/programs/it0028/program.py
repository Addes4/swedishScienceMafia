# EVOLVE-BLOCK-START
"""Best fit with a gentle anti-fragmentation guard."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tightest fit (smallest residual). Residual is in [0, 100-item].
    # Add a tiny tie-break bonus for bins that end up completely full, which slightly
    # prefers consolidating over leaving small unused gaps.
    return -residual + 0.001 * (residual == 0)
# EVOLVE-BLOCK-END
