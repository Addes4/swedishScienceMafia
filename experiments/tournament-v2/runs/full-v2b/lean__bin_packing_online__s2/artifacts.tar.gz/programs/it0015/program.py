# EVOLVE-BLOCK-START
"""Best fit with a small fullness tie-break to consolidate leftover capacity."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    slack = bins - item
    # Primary: tightest fit (smallest resulting slack).
    # Tie-break: prefer the fuller bin (smaller current remaining), scaled down
    # enough not to override a genuinely better fit.
    return -slack * 1000.0 - bins
# EVOLVE-BLOCK-END
