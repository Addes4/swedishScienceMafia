# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware stranded-space avoidance.

Core idea: classic best-fit (-r) minimizes leftover, but leaves small
residuals that are too small for any future item (stranded space).  We
penalize residuals whose probability of being used by at least one future
item is low, and reward residuals that can be exactly refilled.

All distribution terms are scaled so that they act as principled tie-breaks
on top of best-fit, but strong enough to avoid greedy stranding mistakes.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None      # smoothed P(item == s), s in 0..100
_cdf = None       # P(item <= s)
_two = None       # P(two items sum to s)
_last_count = -1


def _smooth(freq):
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.2
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    return K.dot(w)


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n

    sw = _smooth(freq)
    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw

    cdf = np.zeros(101, dtype=np.float64)
    cdf[0] = 0.0
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    two = np.zeros(101, dtype=np.float64)
    idx_all = np.arange(1, 101)
    for s in range(2, 101):
        lo = max(1, s - 100)
        hi = min(100, s - 1)
        if hi >= lo:
            idx = np.arange(lo, hi + 1)
            two[s] = float(np.dot(sm[idx], sm[s - idx]))

    _freq = sm
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best-fit (smaller residual preferred).
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Probability that NO future item fits in this residual
        # (i.e. residual stays stranded).  = P(next item > r).
        prob_strand = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_strand * 40.0

        # Reward residuals that can be exactly refilled by one or two items
        # (reduces leftover and packs tightly).
        one = freq[rr]
        match = np.maximum(one, two[rr])
        score += match * 30.0

        # Perfect fill is always excellent.
        perfect = (residual == 0).astype(np.float64)
        score += perfect * 60.0

        # Usability: reward residuals likely to fit at least one more item.
        usability = np.where(residual >= 100, 1.0, cdf[rr])
        score += usability * 6.0

    # Prefer reusing already-open bins over fresh ones (tiny tiebreak).
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END

