# EVOLVE-BLOCK-START
"""Best fit on resulting residual, with a tie-break preferring bins whose current
residual is closest to the item size (tighter placement, less leftover fragmentation)."""
import numpy as np


def priority(item, bins):
    """Rank bins: minimize residual after placement; break ties by current residual proximity."""
    residual = bins - item
    # Primary: smallest residual (best fit). Secondary: current residual closest to item.
    # Encode as a single scalar dominated by the primary key.
    secondary = -np.abs(bins - item)
    return -residual * 1e6 + secondary
# EVOLVE-BLOCK-END
