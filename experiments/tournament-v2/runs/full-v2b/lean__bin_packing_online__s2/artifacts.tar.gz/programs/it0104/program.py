# EVOLVE-BLOCK-START
"""Beſt-fit with a distribution-aware tiebreak on the residual.

Primary score is classic best-fit (-residual).  Ties are broken (on a tiny
scale) by the empirical likelihood that the residual can be exactly closed
by one or two future items, which reduces stranded space without upsetting
the dominant best-fit ordering.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    cdf = np.cumsum(_stats.sizes) / n
    # two[s] = P(two independent items sum exactly to s), for s in 0..100
    two = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Primary: best fit -> smaller resulting residual is better.
    # Scale by a large constant so the tiebreak below never overrides it.
    score = -r * 1000.0

    _ensure_tables()

    if _freq is not None:
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Likelihood the residual can be exactly closed by one or two items.
        match = np.maximum(_freq[rr], _two[rr])
        score += match

    # Small tiebreak: prefer reusing already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.5

    return score
# EVOLVE-BLOCK-END

