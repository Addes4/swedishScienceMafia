# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware expected-residual tie-breaker.

For each candidate bin compute residual r = bins - item.
Dominant term: -r (classic best fit).
Tie-breaker: expected residual after optimally absorbing one future item
drawn from the empirical distribution, E[max(0, r - s)], subtracted with a
small weight so it refines near-ties without overriding best-fit ordering.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_exp = None  # _exp[r] = E[max(0, r - s)] for r in 0..100
_last_count = -1


def _ensure_tables():
    global _freq, _exp, _last_count
    n = _stats.count
    if n == _last_count or n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    sizes = np.arange(101, dtype=np.float64)
    exp_val = np.zeros(101, dtype=np.float64)
    for r in range(101):
        diff = r - sizes
        diff = np.where(diff > 0, diff, 0.0)
        exp_val[r] = float(np.dot(freq, diff))
    _freq = freq
    _exp = exp_val
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant: classic best fit.
    score = -r * 1000.0

    _ensure_tables()

    if _exp is not None:
        rr = np.clip(residual, 0, 100).astype(np.int64)
        expected_res = _exp[rr]
        # Higher is still better with score direction: subtract small tie-breaker.
        score -= expected_res * 1.0

    # Mild tiebreak: prefer reusing already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.01

    return score
# EVOLVE-BLOCK-END

