# EVOLVE-BLOCK-START
"""Best-fit augmented with expected-next-leftover (waste) minimization.

For each candidate bin residual r we estimate how much space will remain after
the next item is placed.  Placing now leaves r; a future item s (with s <= r)
leaves r - s.  We reward residuals whose expected leftover under the smoothed
empirical item distribution is small, i.e. residuals that are likely to be
refilled tightly.  Best-fit (-r) stays the dominant term and the waste term is
kept below 1 in magnitude so it only breaks near-ties.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_last_count = -1


def _smooth(freq):
    """Gaussian-smooth the size distribution over integer sizes 1..100."""
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    return K.dot(w)


def _ensure_tables():
    global _freq, _cdf, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n

    sw = _smooth(freq)
    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw

    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    _freq = sm
    _cdf = cdf
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Expected size of a future item conditioned on it fitting in r.
        # E[s | s <= r] = sum_{s<=r} s * p[s] / P(s <= r).
        # Precompute prefix sums of s*p[s] and p[s].
        sp = freq * np.arange(101)
        cum_sp = np.cumsum(sp)      # cum_sp[r] = sum_{s<=r} s p[s]
        cum_p = cdf                  # P(s <= r)
        safe_p = np.where(cum_p > 1e-9, cum_p, 1.0)
        exp_fit = cum_sp[rr] / safe_p[rr]      # 0 when nothing fits

        # Expected leftover after filling with the next fitting item.
        exp_left = np.where(residual >= 100, 0.0, rr - exp_fit)
        exp_left = np.clip(exp_left, 0.0, None)

        # Reward small expected leftover (tight refill). Scale < 1 so best-fit
        # dominates; only near-ties between residuals get reordered.
        score -= exp_left * 0.6

        # Mild penalty for stranded space: probability nothing fits in r.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 20.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.05

    return score
# EVOLVE-BLOCK-END
