# EVOLVE-BLOCK-START
"""Best-fit with a sharp perfect-fill / exact-refill tie-break.

The dominant term is classic best-fit (-residual): smaller leftover is better.
On top of that we add a strong bonus for a residual of exactly 0 (immediate
perfect fill) and a moderate bonus when the residual equals a frequently
observed item size (so a single future item can refill it exactly).  The
distribution term is scaled to be small relative to the best-fit gaps, so it
only breaks near-ties rather than overriding best-fit.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_last_count = -1


def _ensure_tables():
    global _freq, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n
    _freq = freq
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best fit.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Exact-refill bonus: residual is a common item size.
        score += freq[rr] * 6.0
        # Strong preference for immediate perfect fill.
        score += np.where(residual == 0, 1.0, 0.0)

    # Slight preference for reusing a partially-filled open bin over a fresh one.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
