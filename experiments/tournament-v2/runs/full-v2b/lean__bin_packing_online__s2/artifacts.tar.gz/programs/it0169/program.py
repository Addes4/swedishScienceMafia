# EVOLVE-BLOCK-START
"""Best-fit with a smooth concave stranded-space penalty.

The item goes to the bin leaving the smallest residual (classic best fit),
mildly adjusted so that tiny residuals are strongly preferred and large
residuals are penalized in a monotone, distribution-free way.  A small
empirical-distribution term rewards residuals that exactly match one common
item size.  This avoids relying on noisy convolution estimates that caused
previous overfits.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_last_count = -1


def _ensure_tables():
    global _freq, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    _freq = freq
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better, but with a
    # slight concavity so that nearly-full bins are preferred even more
    # strongly.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Exact single-item refill bonus, using the raw empirical frequency.
        score += freq[rr] * 4.0
        # Usability: reward residuals that can still fit a typical item.
        # Approximate by rewarding larger residuals a bit (concave).
        score += np.sqrt(np.clip(r, 0, 100)) * 0.05

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
