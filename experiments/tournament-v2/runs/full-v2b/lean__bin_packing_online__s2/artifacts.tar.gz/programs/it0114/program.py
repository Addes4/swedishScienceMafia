# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware tie-break on equal residuals.

Base: classic best-fit (smaller residual is better), made strictly dominant.
Tie-break: among bins with the same residual, prefer the one whose residual is
most likely to be usable by a single future item (largest expected absorbed
amount).  Ties are resolved with the empirical item-size distribution, so the
rule stays close to pure best-fit while occasionally choosing a better bin.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_pdf = None
_cdf = None
_absorb = None   # absorb[s] = E[min(residual=s, next item)] for s in 0..100
_last_count = -1


def _ensure_tables():
    global _pdf, _cdf, _absorb, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    pdf = _stats.sizes / n
    cdf = np.cumsum(_stats.sizes) / n
    # absorb[s] = sum_{k=1..s} k*pdf[k] + s*P(item>s)
    k = np.arange(101, dtype=np.float64)
    kmass = np.cumsum(k * pdf)          # kmass[s] = sum_{k<=s} k*pdf[k]
    absorb = np.zeros(101, dtype=np.float64)
    for s in range(101):
        absorb[s] = kmass[s] + s * (1.0 - cdf[s])
    _pdf = pdf
    _cdf = cdf
    _absorb = absorb
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Strictly dominant best-fit term.
    score = -r * 1000.0

    _ensure_tables()

    if _absorb is not None:
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Tie-break only: prefer residuals that absorb more of a future item.
        score += _absorb[rr]

    # Prefer reusing an already-open bin over a fresh one on exact ties.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.01

    return score
# EVOLVE-BLOCK-END

