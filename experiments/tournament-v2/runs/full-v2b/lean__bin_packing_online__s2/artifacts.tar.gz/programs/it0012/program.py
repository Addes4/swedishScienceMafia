# EVOLVE-BLOCK-START
"""Best fit with nonlinear slack preference (best-fit dominant, consolidation tie-break)."""
import numpy as np


def priority(item, bins):
    """Score each bin: strongly prefer tight fits, mildly prefer fuller bins."""
    residual = bins - item  # >= 0 for bins shown
    # Dominant term: tightest fit (larger score for smaller residual).
    # Nonlinear compression of residual: exponent < 1 keeps large-residual bins discernible
    # while letting near-fit (residual small) dominate, and adding a tiny linear
    # consolidation term nudges ties toward fuller bins.
    r = residual.astype(np.float64)
    tight = -np.sqrt(r)
    # small tie-break preferring fuller bins (smaller current remaining capacity)
    full = -0.02 * bins.astype(np.float64)
    return tight + full
# EVOLVE-BLOCK-END
