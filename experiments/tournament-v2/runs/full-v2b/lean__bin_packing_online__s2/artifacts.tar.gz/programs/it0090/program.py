# EVOLVE-BLOCK-START
"""Distribution-aware best fit.

Primary rule: classic best fit -- put the item in the bin with the smallest
remaining capacity that still fits it (base score = -residual).

Tiebreak: among bins whose residuals are essentially equal, prefer the residual
that is most likely to be exactly refilled by a future item.  This is a small,
distribution-derived nudge that only matters when best-fit residuals tie.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_last_count = -1


def _ensure_tables():
    global _freq, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    _freq = _stats.sizes / n
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: smaller residual is better (best fit).
    score = -r

    _ensure_tables()

    if _freq is not None:
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Small bonus for residuals likely to be exactly refilled next.
        score += _freq[rr] * 0.5

    # Tiny tiebreak: slightly prefer reusing bins that are already partially
    # full (residual < 100) over untouched bins of capacity 100.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.01

    return score
# EVOLVE-BLOCK-END
