# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a stranded-space penalty.

For each candidate bin we compute the resulting residual r = bins - item.
Base is classic best-fit (-r).  We subtract a penalty proportional to the
expected space that will be permanently stranded in r (items that don't fit
leave the residual untouched), and add a bounded "perfect refill" bonus when
r can be exactly decomposed into one or two frequently observed item sizes.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_waste = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _two, _waste, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    cdf = np.cumsum(_stats.sizes) / n
    # two[s] = P(two independent items sum exactly to s), for s in 0..100
    two = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    # waste[r] = expected size of items that do NOT fit in residual r
    #          = sum_{s > r} freq[s] * s   (high for small residuals)
    waste = np.zeros(101, dtype=np.float64)
    for r in range(101):
        if r < 100:
            waste[r] = float(np.dot(freq[r + 1:101], np.arange(r + 1, 101)))
    _freq = freq
    _cdf = cdf
    _two = two
    _waste = waste
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        two = _two
        waste = _waste

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Penalty: expected permanently stranded space in this residual.
        score -= waste[rr] * 1.2

        # Perfect-refill bonus: residual exactly equal to a common size,
        # or decomposable into two common sizes.
        one = freq[rr]
        match = np.maximum(one, two[rr])
        score += match * 30.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END

