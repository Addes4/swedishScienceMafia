# EVOLVE-BLOCK-START
"""Best-fit with distribution-aware tie-breakers.

Classic best-fit (-residual) dominates.  The distribution terms are bounded
strictly below 1 in magnitude, i.e. they are pure tie-breakers: they only
decide between bins that produce the *same* residual, so they can never
override the greedy choice.  Among tied residuals we slightly prefer a bin
whose residual matches (or can be filled exactly by) typical future items,
to reduce stranded space.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _smooth(freq):
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    return K.dot(w)


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n

    sw = _smooth(freq)
    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw

    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    two = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        idx = np.arange(1, s)
        if idx.size:
            two[s] = float(np.dot(sm[idx], sm[s - idx]))

    _freq = sm
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant: best fit.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Tie-breaker only: bounded to sub-unit magnitude.
        one = freq[rr]
        match = np.maximum(one, two[rr])
        usability = np.where(residual >= 100, 1.0, cdf[rr])
        tie = 0.3 * match + 0.1 * usability

        # reuse-lean: tiny nudge toward already-open bins
        fresh = (bins >= 100).astype(np.float64)
        tie -= fresh * 0.05

        score = score + tie

    return score
# EVOLVE-BLOCK-END
