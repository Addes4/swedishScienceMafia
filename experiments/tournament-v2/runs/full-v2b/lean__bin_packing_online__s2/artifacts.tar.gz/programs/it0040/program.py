# EVOLVE-BLOCK-START
"""One-step-lookahead bin choice.

For each candidate bin we compute the residual r = bins - item and estimate how much of
that residual is likely to remain forever unusable, given the empirical item-size
distribution seen so far.  Concretely, waste(r) is approximated as the fraction of the
residual that is smaller than the smallest "common" item, so a leftover that no typical
future item can fill is expensive, while a leftover that matches common item sizes is
cheap.  The bin with the lowest estimated waste wins; ties fall back to best-fit.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    counts = _stats.sizes
    total = counts.sum()
    if total > 0:
        p = counts / total
    else:
        p = np.zeros(101, dtype=np.float64)

    residual = bins - item  # remaining capacity after placing the item

    # Smallest item size with meaningful probability (~5th percentile of observed dist),
    # floored at 1.  A residual below this is essentially unusable for future items.
    cdf = np.cumsum(p)
    if total > 0:
        small = int(np.searchsorted(cdf, 0.05))
        small = max(1, small)
    else:
        small = 20

    r = residual.astype(np.float64)

    # Estimated stranded waste: residual that is positive but too small for a typical item.
    waste = np.where((r > 0) & (r < small), r, 0.0)

    # Also treat tiny positive residuals below the minimum observed size as fully wasted.
    waste = np.where((r > 0) & (r < 1), r, waste)

    # Primary: minimize stranded waste (lower is better -> negate).
    score = -waste

    # Secondary: among equal waste, prefer best fit (smaller residual).
    score -= 0.001 * r

    # Slight preference to place into already-open (non-empty) bins over fresh 100s,
    # to avoid opening new bins when waste is otherwise comparable.
    score -= 0.0001 * (bins == 100).astype(np.float64)

    return score
# EVOLVE-BLOCK-END
