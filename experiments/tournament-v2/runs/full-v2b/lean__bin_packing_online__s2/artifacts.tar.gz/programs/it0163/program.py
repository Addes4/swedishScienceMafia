# EVOLVE-BLOCK-START
"""Concave best-fit: penalize residual waste concavely.

Classic best-fit minimizes the raw residual.  Pure sum-of-squares favors
filling near-full bins too aggressively.  A safer, distribution-agnostic
rule is to score by the residual with a mild concave penalty, which keeps
best-fit's strong behavior while gently preferring to leave small,
useful residuals rather than large stranded gaps.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item
    r = residual.astype(np.float64)

    # Base best-fit: prefer small residual.
    score = -r

    # Mild concavity: reward reductions in waste superlinearly for small r.
    score += np.sqrt(np.maximum(r, 0.0)) * 0.3

    # Reuse open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
