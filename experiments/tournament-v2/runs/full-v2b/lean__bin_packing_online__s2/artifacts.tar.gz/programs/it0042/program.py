# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a Sum-of-Squares reusability bonus.

We estimate the item-size distribution online.  For each candidate bin we take the
resulting residual r and reward it when r can be exactly tiled by observed item
sizes (the Sum-of-Squares principle): a residual is "reusable" if common item sizes
divide it.  Best-fit (-r) remains the base ordering; a stranding penalty avoids
unusable slivers; a tiny tiebreak prefers reusing open bins over fresh ones.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    mean_item = _stats.total / _stats.count if _stats.count else 40.0
    T = max(1.0, mean_item * 0.5)

    residual = bins - item
    r = residual.astype(np.float64)
    b = bins.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    # Penalize unusable slivers.
    sliver = ((residual > 0) & (residual < T)).astype(np.float64)
    score -= sliver * 20.0

    # Sum-of-Squares reusability reward: a residual r is reusable if common item
    # sizes tile it exactly.  Reward the best exact-tiling coverage of r.
    if _stats.count > 0:
        freq = _stats.sizes / _stats.count
        # candidate residual values that appear
        valid = (residual >= 1) & (residual <= 100)
        rv = residual[valid].astype(np.int64)
        # For each distinct residual value in rv, compute sum of freq[s] over
        # observed sizes s that divide the residual (exact tiling of one step).
        uniq = np.unique(rv)
        cover = {}
        total_freq = float(np.sum(freq))
        for val in uniq:
            acc = 0.0
            # check divisors of val (observed sizes only)
            for s in range(1, val + 1):
                if val % s == 0 and freq[s] > 0.0:
                    acc += freq[s]
            cover[val] = acc / total_freq if total_freq > 0 else 0.0
        match = np.zeros(r.shape, dtype=np.float64)
        for i in np.nonzero(valid)[0]:
            match[i] = cover[rv[i - np.nonzero(valid)[0][0]]] if False else 0.0
        # fast vectorized fill
        match_vals = np.array([cover[v] for v in rv], dtype=np.float64)
        match[valid] = match_vals
        score += match * 30.0

    # Small tiebreak: reuse already-open bins (residual < 100) over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
