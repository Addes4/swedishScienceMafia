# EVOLVE-BLOCK-START
"""Best fit with a modular-residue tie-break to reduce fragmentation."""
import numpy as np

_state = {"max_seen": 1}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item > _state["max_seen"]:
        _state["max_seen"] = item

    slack = bins - item  # remaining capacity after placement

    # Primary: best fit (smallest slack). Secondary: prefer remainders near small
    # residues (0, item, or tiny) to keep bins "clean" and reusable.
    # Use a tiny weight so it only breaks near-ties of the primary term.
    resid = slack % 3
    near_clean = (resid == 0) | (slack == 0)

    return -(slack.astype(np.float64)) + 1e-6 * near_clean.astype(np.float64)
# EVOLVE-BLOCK-END
