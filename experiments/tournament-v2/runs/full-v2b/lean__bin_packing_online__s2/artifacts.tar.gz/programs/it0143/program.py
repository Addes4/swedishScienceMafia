# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with least-waste refill tie-break.

For each candidate bin we compute the resulting residual r = bins - item.
Base is classic best-fit (-r).  On top we add a bounded tie-break that
rewards residuals whose *best next refill* will leave little waste: for each
residual r we find the largest observed item size s <= r and measure the
resulting leftover (r - s), preferring small leftovers (near-perfect refills)
and residuals equal to a common item size.  A stranded-space penalty softly
discourages residuals too small to accept typical future items.  All
tie-break terms are scaled to stay strictly subordinate to best-fit, and the
empirical distribution terms fade in as more items are observed.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_best_refill = None   # best_refill[r] = largest observed size <= r (smoothed)
_leftover = None      # leftover[r] = r - best_refill[r]
_last_count = -1


def _smooth(freq):
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    return K.dot(w)


def _ensure_tables():
    global _freq, _cdf, _best_refill, _leftover, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n

    sw = _smooth(freq)
    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw

    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    # For each residual r find the most probable next item <= r, and the
    # resulting expected leftover.  Work on integer residuals 0..100.
    best_refill = np.zeros(101, dtype=np.float64)
    leftover = np.zeros(101, dtype=np.float64)
    sizes = np.arange(1, 101, dtype=np.float64)
    for r in range(0, 101):
        if r < 1:
            best_refill[r] = 0.0
            leftover[r] = float(r)
            continue
        idx = np.arange(1, r + 1)
        wts = sm[idx]
        tot = wts.sum()
        if tot <= 0:
            best_refill[r] = 0.0
            leftover[r] = float(r)
            continue
        # most probable fitting size
        j = np.argmax(wts)
        s = idx[j]
        best_refill[r] = float(s)
        leftover[r] = float(r - s)

    _freq = sm
    _cdf = cdf
    _best_refill = best_refill
    _leftover = leftover
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        cdf = _cdf
        freq = _freq
        leftover = _leftover

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Least-waste refill: smaller expected leftover is better, scaled
        # strictly below 1 so best-fit remains dominant.
        waste = leftover[rr]
        score -= waste * 0.5

        # Small bonus for residuals equal to a common item size (exact fit).
        score += freq[rr] * 0.5

        # Stranded-space: penalize residuals too small to fit typical items.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 0.3

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.01

    return score
# EVOLVE-BLOCK-END
