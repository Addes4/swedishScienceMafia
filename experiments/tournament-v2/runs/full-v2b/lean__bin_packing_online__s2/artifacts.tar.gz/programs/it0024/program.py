# EVOLVE-BLOCK-START
"""Best fit, but avoid leaving a residual too small to be useful for average items."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    """Return a priority for every bin; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _state["sum"] += item
    _state["n"] += 1
    mean_item = _state["sum"] / _state["n"]

    residual = bins - item  # all >= 0 since only fitting bins are shown

    # Prefer leaving a residual that can still hold a typical future item.
    useful = residual >= mean_item
    # Among useful placements, choose smallest residual (tight but still open).
    # Among non-useful, choose smallest residual (plain best fit).
    # Encode as a single score: useful bins get a large bonus, then rank by -residual.
    score = np.where(useful, 1.0e6, 0.0) - residual.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
