# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a smoothed stranded-space penalty.

Base is classic best-fit (-residual).  We add a small distribution-derived
tiebreak: penalize residuals by the probability that the next item is too
large to fit, and reward residuals that exactly match a frequent item size.
Weights are kept small so best-fit stays dominant and we do not overfit.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_cdf = None
_freq = None
_last_count = -1


def _ensure_tables():
    global _cdf, _freq, _last_count
    n = _stats.count
    if n == _last_count or n == 0:
        return
    freq = _stats.sizes / n
    _cdf = np.cumsum(_stats.sizes) / n
    _freq = freq
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        cdf = _cdf
        freq = _freq

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Probability the residual cannot accommodate a future item.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 5.0

        # Small bonus when the residual matches a common exact size.
        score += freq[rr] * 3.0

    # Prefer reusing already-open bins over fresh ones on ties.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.05

    return score
# EVOLVE-BLOCK-END
