# EVOLVE-BLOCK-START
"""Best fit with a distribution-aware penalty for stranding bins with tiny residuals."""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0

    def update(self, item):
        self.count += 1
        self.total += item


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _stats.update(item)

    # Estimate a typical item size from history (mean ~40 for the target distribution).
    # Use a fraction of the mean as the "hard to reuse" residual threshold.
    mean_item = _stats.total / _stats.count
    T = float(mean_item) * 0.6  # roughly 24 for mean 40

    residual = bins - item

    # Penalize leaving a residual too small to fit a typical future item,
    # unless the bin is filled exactly (residual == 0).
    penalty = ((residual > 0) & (residual < T)).astype(np.float64)

    return -(residual + penalty * 30.0)
# EVOLVE-BLOCK-END

