# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with fillability and stranded-space penalty.

For each candidate bin we compute the resulting residual r = bins - item.
The dominant term is classic best-fit (-r).  To that we add two
distribution-derived corrections using only past items:

  * a "stranded space" penalty: residuals r whose remaining room is smaller
    than most future item sizes are nearly unusable, so we subtract a term
    proportional to P(next item > r);
  * a "fillability" bonus: residuals that can be exactly completed by one or
    two commonly-observed item sizes are valuable, so we add a term based on
    max(P(item == r), P(two items sum to r)).
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    cdf = np.cumsum(_stats.sizes) / n
    # two[s] = P(two independent items sum exactly to s), for s in 0..100
    two = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(next item > r); for r>=100 this is 0.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 22.0

        # Fillability: residual matched by a single common size or a pair.
        one = freq[rr]
        match = np.maximum(one, two[rr])
        # Emphasize small residuals that can be *exactly* completed.
        score += match * 45.0 * (1.0 + 0.02 * (100.0 - r) / 100.0)

    # Tiny tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
