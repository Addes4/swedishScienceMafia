# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with adaptive conSolidation bias.

Best-fit base (prefer smallest usable residual), a sliver penalty, and a
Sum-of-Squares style reuse reward.  The reuse-vs-fresh tiebreak is scaled by
how "open" the packing already is: early on we prefer to fill existing
partial bins; later we are less reluctant to open new ones.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    mean_item = _stats.total / _stats.count if _stats.count else 40.0
    T = max(1.0, mean_item * 0.5)

    residual = bins - item
    r = residual.astype(np.float64)
    b = bins.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    # Penalize unusable slivers.
    sliver = ((residual > 0) & (residual < T)).astype(np.float64)
    score -= sliver * 20.0

    # Reward residuals that match a commonly-seen item size (reusable).
    if _stats.count > 0:
        freq = _stats.sizes / _stats.count
        match = np.zeros(r.shape, dtype=np.float64)
        valid = (residual >= 1) & (residual <= 100)
        idx = residual[valid].astype(np.int64)
        match[valid] = freq[idx]
        score += match * 30.0

    # Adaptive consolidation: prefer reusing already-open bins.
    # The bonus shrinks as the number of untouched bins grows relative to
    # how many items we have seen, avoiding a hard fixed constant.
    fresh = (bins >= 100).astype(np.float64)
    open_bins = 1.0 - fresh
    seen = max(1.0, float(_stats.count))
    # Ratio of open bins to items seen: high early, decays over time.
    bias = 1.0 / (1.0 + seen / 50.0)
    score -= fresh * bias * 0.2

    return score
# EVOLVE-BLOCK-END

