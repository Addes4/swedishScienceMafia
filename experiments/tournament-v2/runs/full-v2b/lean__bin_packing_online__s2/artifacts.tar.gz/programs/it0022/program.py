# EVOLVE-BLOCK-START
"""Sum of Squares (SS) heuristic: place item to minimize the resulting total of squared
remaining capacities. This generalizes best-fit while strongly consolidating residues."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Minimize sum over bins of residual^2; the change from placing here is
    # residual^2 - bins^2 = -2*item*bins + item^2, so maximize (2*item*bins - item^2)
    # equivalently maximize bins (fuller bins preferred), scaled by item.
    return -(bins * bins - residual * residual)
# EVOLVE-BLOCK-END
