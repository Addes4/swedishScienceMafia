# EVOLVE-BLOCK-START
"""Best-fit with a reusable-residual bonus.

Classic best fit (prefer the smallest residual that still leaves a bin usable) is
strong online.  The main loss comes from residuals that no future item can fill,
i.e. stranded slivers.  To judge whether a residual r is "reusable", we score it
by how well it can be packed by the typical item sizes seen so far: a residual is
good if it can be exactly covered by a multiset of common item sizes (match-made),
which is exactly the Sum-of-Squares intuition.

We build the size histogram online and, every so often, compute a small
packability table pack[r] = best fraction of r coverable by common sizes, using an
unbounded-knapsack style DP over the most frequent sizes.  The table is cheap
(101 entries) and cached.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)


_stats = _Stats()

# cached packability estimate: pack[r] in [0,1], fraction of a residual of size
# r that can be exactly covered using common item sizes.
_pack = np.zeros(101, dtype=np.float64)
_pack_count = -1


def _rebuild_pack():
    """Compute how well residuals 0..100 can be exactly filled by common sizes."""
    global _pack_count
    if _stats.count == 0:
        _pack.fill(0.0)
        _pack_count = 0
        return

    freq = _stats.sizes / _stats.count
    # candidate "building block" sizes: reasonably common, not tiny
    cand = [s for s in range(1, 101) if freq[s] >= 0.005]
    if not cand:
        cand = [int(round(_stats.total / _stats.count)) or 1]

    # unbounded knapsack: reachable[r] = smallest number of items to exactly sum to r
    INF = 10 ** 9
    reach = np.full(101, INF, dtype=np.int64)
    reach[0] = 0
    for r in range(1, 101):
        best = INF
        for s in cand:
            if s <= r and reach[r - s] + 1 < best:
                best = reach[r - s] + 1
        reach[r] = best

    # pack[r]: exact-fill gets 1.0, otherwise fall back to how much of r is
    # covered by the best exact-fill plus the leftover's size ratio.
    for r in range(101):
        if reach[r] < INF:
            _pack[r] = 1.0
        else:
            # largest exactly-fillable prefix
            best = 0.0
            for rest in range(r - 1, 0, -1):
                if reach[rest] < INF:
                    best = rest / r
                    break
            _pack[r] = best

    _pack_count = _stats.count


def priority(item, bins):
    _stats.update(item)

    # rebuild packability occasionally (cheap, distribution changes slowly)
    if _stats.count - _pack_count >= 25 or _pack_count < 0:
        _rebuild_pack()

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    # Reward reusability of the residual (exact-fillable residuals are great).
    valid = (residual >= 0) & (residual <= 100)
    reuse = np.zeros(r.shape, dtype=np.float64)
    idx = residual[valid].astype(np.int64)
    reuse[valid] = _pack[idx]
    score += reuse * 15.0

    # Penalize stranded slivers (residual that can't be filled well).
    score -= (1.0 - reuse) * 8.0 * (residual > 0).astype(np.float64)

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
