# EVOLVE-BLOCK-START
"""Best fit with a small consolidation bonus toward bins already used."""
import numpy as np


class _State:
    def __init__(self):
        # map from (current remaining capacity) -> item count, approximated
        self.count = {}


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    counts = _state.count
    scores = np.empty(len(bins), dtype=np.float64)
    for i, cap in enumerate(bins):
        cap = int(cap)
        residual = cap - item
        c = counts.get(cap, 0)
        scores[i] = -residual + 0.001 * c
    # update counts on the chosen bin (highest score, first tie)
    best = int(np.argmax(scores))
    cap = int(bins[best])
    residual = cap - item
    counts[cap] = counts.get(cap, 0) + 1
    counts[residual] = counts.get(residual, 0)
    return scores
# EVOLVE-BLOCK-END
