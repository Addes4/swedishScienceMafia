# EVOLVE-BLOCK-START
"""Adaptive best-fit with expected-refill tiebreak.

Primary term: classic best-fit (smaller residual is better).
Secondary term: small bonus for residuals likely to be exactly refilled by
one or two common future item sizes, and a mild penalty for residuals so
small that almost nothing fits (stranded space).

The empirical size distribution is tracked online; the O(100*100) convolution
table is rebuilt only every REBUILD_EVERY calls to avoid per-call overhead.
"""
import numpy as np

REBUILD_EVERY = 16
SMOOTH = 2.0  # Laplace-ish smoothing so early estimates are non-degenerate


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None


def _ensure_tables(force=False):
    global _freq, _cdf, _two
    n = _stats.count
    if n == 0:
        return
    if not force and _freq is not None and (n % REBUILD_EVERY) != 0:
        return
    denom = n + SMOOTH * 100.0
    freq = (_stats.sizes + SMOOTH) / denom  # freq[s] = P(item == s)
    cdf = np.cumsum(_stats.sizes + SMOOTH) / denom
    two = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best fit (smaller residual better).
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Probability that the residual can be exactly refilled by one or
        # two common item sizes (useful to close the bin).
        one = freq[rr]
        match = np.maximum(one, two[rr])
        score += match * 1.0

        # Penalty for (near-)stranded residual: probability nothing future
        # fits.  Scaled modestly so best-fit stays dominant.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * (r * 0.02)

    return score
# EVOLVE-BLOCK-END
