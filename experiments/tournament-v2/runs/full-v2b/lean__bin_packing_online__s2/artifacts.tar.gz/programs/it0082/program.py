# EVOLVE-BLOCK-START
"""Best-fit with a smooth, distribution-aware residual-quality tiebreak.

Classic best-fit (smallest residual) is the dominant term. As a tiebreak we
score each residual by how well it can absorb future items: we reward residual
values that are likely to be exactly matched (or nearly matched) by one or two
future items, using the empirical size distribution. Because sizes are
continuous-ish, we use a smooth match measure (probability that a future item
falls in a small window around the residual) rather than exact equality.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _last_count
    n = _stats.count
    if n == _last_count or n == 0:
        return
    freq = _stats.sizes / n
    cdf = np.cumsum(_stats.sizes) / n
    _freq = freq
    _cdf = cdf
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best fit (smaller residual better).
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Smooth single-item match: probability a future item lands within +-2
        # of the residual (so the bin can likely be filled exactly). Weighted
        # window smoothing over the empirical distribution.
        window = np.zeros(101, dtype=np.float64)
        for d in (-2, -1, 0, 1, 2):
            w = 1.0 - abs(d) / 3.0  # triangular
            idx = np.clip(rr + d, 0, 100)
            window += w * freq[idx]
        score += window * 25.0

        # Mild stranded-space penalty: residual so small few items fit.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 25.0

    # Slight preference to reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END

