# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with misfit penalty and refill bonus.

For each candidate bin we compute residual r = bins - item.
Base is classic best-fit (-r).  We subtract a penalty for residuals that are
unlikely to be exactly refilled by one or two common future items (wasted
space), and add a bounded bonus when r matches a common size or a sum of two
common sizes.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    cdf = np.cumsum(_stats.sizes) / n
    two = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Probability the residual can be exactly refilled by one or two
        # future items drawn from the empirical distribution.
        if 0 < item <= 100:
            pass
        one = freq[rr]
        two_p = two[rr]
        # Chance that the residual is exactly a single item OR a sum of two.
        refill = 1.0 - (1.0 - one) * (1.0 - two_p)

        # Misfit: residual space is likely stranded -> penalize harder when
        # it is large relative to capacity (more wasted space).
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])

        # Weighted by residual size to prioritize saving the most space.
        score -= prob_too_big * 6.0
        score += refill * 8.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END

