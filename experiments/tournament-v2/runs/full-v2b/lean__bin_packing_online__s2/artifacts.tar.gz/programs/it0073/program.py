# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with an expected-refill bonus.

Primary key stays classic best-fit: smaller resulting residual r = bins - item
wins.  On top we add a small bonus for residuals that the arrival distribution
can plausibly close exactly: either r equals a common item size, or r can be
split into two sizes that both occur with decent probability.  A modest
penalty discourages large residuals whose wasted space will likely never be
reclaimed.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_next_rebuild = 0
_REBUILD_EVERY = 16


def _rebuild():
    global _freq, _cdf, _two, _next_rebuild
    n = _stats.count
    freq = _stats.sizes / n
    cdf = np.cumsum(_stats.sizes) / n
    two = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _next_rebuild = n + _REBUILD_EVERY


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit.
    score = -r

    if _freq is None or _stats.count >= _next_rebuild:
        _rebuild()

    freq = _freq
    cdf = _cdf
    two = _two

    rr = np.clip(residual, 0, 100).astype(np.int64)
    # Reward residuals the distribution can likely close exactly.
    one = freq[rr]
    pair = two[rr]
    match = np.maximum(one, pair)
    score += match * 20.0

    # Light penalty for space that will probably never be reused.
    prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
    score -= prob_too_big * residual * 0.3

    # Prefer already-open bins over fresh ones on ties.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.01

    return score
# EVOLVE-BLOCK-END

