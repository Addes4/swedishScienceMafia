# EVOLVE-BLOCK-START
"""Best fit with a penalty for stranding bins with tiny residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Penalize leaving a residual that is too small to fit most future items,
    # unless the bin is filled exactly (residual == 0).
    T = 25
    penalty = ((residual > 0) & (residual < T)).astype(np.int64)
    return -(residual + penalty * 30)
# EVOLVE-BLOCK-END
