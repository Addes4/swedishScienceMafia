# EVOLVE-BLOCK-START
"""Best-fit for large items; consolidation rule for small items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    slack = bins - item  # remaining capacity after placement
    if item >= 50:
        # Pure best fit: smallest remaining capacity still fitting.
        return -bins
    # For small items: prefer the fullest bin that still leaves at least
    # `item` units free after placement (room for a similar-sized partner),
    # otherwise fall back to best fit.
    room = slack >= item
    score = np.where(room, -slack, -slack - 100000.0)
    return score
# EVOLVE-BLOCK-END

