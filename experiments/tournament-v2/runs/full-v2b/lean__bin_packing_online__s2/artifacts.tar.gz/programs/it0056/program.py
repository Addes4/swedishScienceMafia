# EVOLVE-BLOCK-START
"""Best-fit with an expected-utilization tiebreak.

The classic best-fit rule (minimize the resulting residual) is a strong baseline
for online bin packing.  We refine it with a cheap distribution-aware tiebreak:
for a candidate residual r, estimate how much of r a future item would use,
E[min(item, r)], and reward residuals where that usage fraction is high.  This
naturally prefers residuals that align with common item sizes without relying on
arbitrary penalty constants.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: classic best-fit -> smaller residual is better.
    score = -r

    if _stats.count > 0:
        freq = _stats.sizes / _stats.count  # freq[s] = P(item == s)

        # Expected amount of a future item absorbed by residual r:
        #   E[min(item, r)] = sum_{s<=r} s*freq[s] + r * P(item>r)
        sizes = np.arange(101, dtype=np.float64)
        weighted = sizes * freq                    # s * P(item==s)
        cdf_w = np.cumsum(weighted)                # sum_{s<=k} s*P(item==s)
        cdf = np.cumsum(freq)                      # P(item<=k)

        rr = np.clip(residual, 0, 100).astype(np.int64)
        tail = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        expected_use = cdf_w[rr] + rr * tail

        # Utilization fraction: how fully r would be consumed.
        util = np.where(residual > 0,
                        expected_use / np.maximum(residual, 1.0),
                        1.0)
        score += util * 50.0

    # Mild tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
