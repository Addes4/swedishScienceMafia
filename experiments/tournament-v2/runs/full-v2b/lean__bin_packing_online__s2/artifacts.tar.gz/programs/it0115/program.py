# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with stranded-space penalty and refill bonuses.

For each candidate bin we compute the resulting residual r = bins - item.
Base is classic best-fit (-r).  We penalize stranded space (probability that
future items are too large to fit), reward residuals that exactly match one or
two common item sizes, and give a small bounded bonus for residuals that can
absorb more expected future items.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_reuse = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _two, _reuse, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    cdf = np.cumsum(_stats.sizes) / n
    # two[s] = P(two independent items sum exactly to s), for s in 0..100
    two = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))

    # reuse[r] = expected number of future items a residual r can absorb,
    # approximated as sum_s freq[s] * (r // s), capped to keep it bounded.
    idx = np.arange(1, 101)
    reuse = np.zeros(101, dtype=np.float64)
    for r in range(0, 101):
        cnt = r // idx
        np.clip(cnt, 0, 4, out=cnt)
        reuse[r] = float(np.dot(freq[idx], cnt))

    _freq = freq
    _cdf = cdf
    _two = two
    _reuse = reuse
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two
        reuse = _reuse

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(item > r): for r>=100 it's 0; else 1 - CDF(r).
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 60.0

        # Perfect-refill bonus: residual exactly equal to a common size,
        # or decomposable into two common sizes.
        one = freq[rr]
        match = np.maximum(one, two[rr])
        score += match * 30.0

        # Small bounded bonus for residuals that can absorb more expected
        # future items (encourages keeping useful open space together).
        score += reuse[rr] * 3.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END

