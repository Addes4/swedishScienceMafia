# EVOLVE-BLOCK-START
"""Best-fit with a tiny, bounded exact-refill tiebreak.

Classic best-fit ranks bins by the smallest resulting residual.  To this we
add a strictly bounded bonus (< 1) proportional to the empirical probability
that the residual can be *exactly* closed by one or two future items.  Since
the base term is -r with integer steps of 1, this bonus only ever breaks ties
between bins whose residuals would otherwise compare equal under best-fit;
it never overrides the best-fit ordering.  This keeps the strong best-fit
core while favouring, among equally-good fits, the residual most likely to be
refilled perfectly.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count or n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    cdf = np.cumsum(_stats.sizes) / n
    # two[s] = P(two independent items sum exactly to s), for s in 0..100
    two = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Probability this residual is exactly a single common size.
        one = freq[rr]
        # Probability it is exactly the sum of two common sizes.
        match = np.maximum(one, two[rr])
        # Bounded to < 1 so it can never change the best-fit ordering.
        score += match * 0.9

    return score
# EVOLVE-BLOCK-END
