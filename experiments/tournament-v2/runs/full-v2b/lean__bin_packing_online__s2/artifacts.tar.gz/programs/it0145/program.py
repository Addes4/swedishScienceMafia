# EVOLVE-BLOCK-START
"""Best-fit with an exact-refill tie-break.

Base rule: classic best-fit (smallest resulting residual wins).  On top, a
small bounded bonus prefers residuals that are equal to a frequently observed
item size, since such residuals are likely to be exactly refilled by a future
item, reducing stranded space.  The bonus magnitude is kept below the smallest
meaningful gap in the base term, so best-fit always dominates.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0

    def freq(self):
        if self.count == 0:
            return None
        return self.sizes / self.count


_stats = _Stats()
_freq = None
_last_count = -1


def _ensure_freq():
    global _freq, _last_count
    n = _stats.count
    if n == _last_count:
        return
    _freq = _stats.freq()
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best-fit -> smaller resulting residual is better.
    score = -r

    _ensure_freq()
    if _freq is not None:
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Probability that the residual equals a common exact item size.
        match = _freq[rr]
        # Bounded bonus, always below 1 unit so best-fit still dominates.
        score += match * 0.5

    return score
# EVOLVE-BLOCK-END
