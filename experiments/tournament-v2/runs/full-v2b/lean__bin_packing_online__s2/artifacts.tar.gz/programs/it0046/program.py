# EVOLVE-BLOCK-START
"""Best-fit with a fixed, distribution-agnostic "fill potential" tiebreak.

The distribution is Weibull-shaped with mean ~40, so residual capacity is most
useful when it exactly matches a whole number of typical item sizes.  Rather
than estimating the distribution online (noisy, adds variance), we use a fixed
set of representative item sizes and reward residuals that are exact multiples
of them -- a Sum-of-Squares-inspired "match made" bonus -- on top of a plain
best-fit base.  A tiny tiebreak consolidates already-open bins.
"""
import numpy as np

# Representative item sizes for this distribution (mean ~40, heavy small tail).
_TYPICAL = np.array([10, 15, 20, 25, 30, 35, 40, 45, 50, 60, 70, 80], dtype=np.float64)


def priority(item, bins):
    r = (bins - item).astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    # Reward residuals that are exact multiples of a typical item size:
    # such residuals can be filled precisely, so keep them aligned.
    match = np.zeros(r.shape, dtype=np.float64)
    valid = r > 0
    rv = r[valid]
    for s in _TYPICAL:
        # how close rv is to a multiple of s (1 at exact, decays with distance)
        k = np.round(rv / s)
        k = np.where(k < 1, 1.0, k)
        near = np.abs(rv - k * s)
        match[valid] += 1.0 / (1.0 + near)

    # Slightly prefer residuals that are exact matches (strongest reuse).
    score += match * 2.0

    # Tiny tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
