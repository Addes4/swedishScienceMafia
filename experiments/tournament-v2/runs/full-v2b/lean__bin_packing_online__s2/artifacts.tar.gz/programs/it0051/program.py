# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a fillability reward.

For each candidate bin we compute the resulting residual r = bins - item.
Base score is best-fit (-r).  Then we add a reward proportional to how well the
residual can be reused: we greedily pack the most common observed item sizes
into r and reward residuals whose leftover after that greedy packing is small
(so future items are likely to fill it nearly perfectly, avoiding stranded
slivers).  A tiny tiebreak prefers already-open bins.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()

# Cache for the fillability table, keyed by item-count bucket.
_cache_key = -1
_fill_table = None


def _build_fill_table(count):
    """For each residual r in 0..100, greedy-pack common sizes and return the
    leftover (smaller leftover => more reusable)."""
    sizes = _stats.sizes
    total = _stats.count
    # Mean size of observed items; used as a fallback before data accrues.
    mean_size = (_stats.total / total) if total > 0 else 40.0

    # Order observed item sizes by frequency (descending), only positive counts.
    order = [s for s in range(1, 101) if sizes[s] > 0]
    order.sort(key=lambda s: -sizes[s])

    leftover = np.zeros(101, dtype=np.float64)
    for r in range(101):
        rem = r
        # Greedy: repeatedly take the most frequent size that still fits.
        # Bound iterations to keep this cheap.
        for _ in range(4):
            placed = False
            for s in order[:15]:
                if s <= rem:
                    rem -= s
                    placed = True
                    break
            if not placed:
                break
        leftover[r] = rem
    return leftover, mean_size


def priority(item, bins):
    global _cache_key, _fill_table
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    # Rebuild the fillability table periodically (cheap, every 25 items).
    if _stats.count // 25 != _cache_key:
        _cache_key = _stats.count // 25
        _fill_table = _build_fill_table(_stats.count)

    leftover, mean_size = _fill_table

    rr = np.clip(residual, 0, 100).astype(np.int64)
    # Reward residuals that greedily pack neatly (small leftover).
    # Normalize by expected item count scale.
    score -= (leftover[rr] / max(mean_size, 1.0)) * 20.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
