# EVOLVE-BLOCK-START
"""Distribution-aware expected-fit scoring.

Idea: for each candidate bin we form the residual r.  A bin is "good" if its
residual is likely to be exactly matched by a future item (so the bin can be
closed) or is itself small (best-fit).  We combine:

    score = -r                                     (classic best-fit)
            + W * P(next item == r)                (perfect single refill)
            + W2 * P(two future items sum to r)     (perfect double refill)

with modest weights so that best-fit stays the dominant ordering and the
distributional terms only break close calls.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1
_rebuild_period = 49


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == 0 or (n == _last_count):
        return
    if _last_count >= 0 and n - _last_count < _rebuild_period and n < 500:
        return
    freq = _stats.sizes / n
    cdf = np.cumsum(_stats.sizes) / n
    two = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        k = np.arange(1, s)
        two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)

        one = freq[rr]
        dbl = two[rr]
        match = np.maximum(one, dbl)

        # Bonus for residuals that a future item (or pair) can exactly fill.
        score += match * 15.0

    # Small tiebreak: prefer reusing already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END

