# EVOLVE-BLOCK-START
"""Distribution-aware fill-efficiency ranking.

For each candidate bin we compute the resulting residual r = bins - item.
Bins are ranked by the expected efficiency with which a future item drawn from
the empirical size distribution would fill that residual,
    E[min(item, r)] / r   (for r > 0; r == 0 gets the best score),
blended with the classic best-fit base to break ties toward tighter packing.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Classic best fit: smaller residual is better.
    score = -r

    if _stats.count > 0:
        freq = _stats.sizes / _stats.count  # freq[s] = P(item == s)
        sizes = np.arange(101, dtype=np.float64) * freq

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # E[min(item, r)] computed from the empirical distribution.
        emin = np.zeros(rr.shape, dtype=np.float64)
        for cap in range(0, 101):
            mask = rr == cap
            if not mask.any():
                continue
            if cap == 0:
                emin[mask] = 0.0
            else:
                # sum_s min(s, cap) * P(s)
                emin[mask] = sizes[:cap + 1].sum() - cap * freq[:cap + 1].sum() + cap * freq[cap + 1:].sum()

        with np.errstate(divide="ignore", invalid="ignore"):
            eff = np.where(rr > 0, emin / np.maximum(rr, 1), 1.0)
        eff = np.nan_to_num(eff, nan=1.0)

        # Reward high fill efficiency.
        score += eff * 80.0

        # Small penalty for residuals that are likely to be stranded
        # (too small to hold most future items).
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - np.cumsum(freq)[rr])
        score -= prob_too_big * 20.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END

