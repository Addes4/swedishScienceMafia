# EVOLVE-BLOCK-START
"""Best fit, with a mild preference to keep near-empty open bins available."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    Pure best fit ranks by -(bins - item). We slightly perturb that so that among
    bins with essentially the same tightness we prefer the fuller bin, which
    reduces the number of very tight but scarce slots consumed early.
    """
    slack = bins - item
    return -slack - 0.01 * bins
# EVOLVE-BLOCK-END

