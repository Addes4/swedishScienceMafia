# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a strictly subordinate tie-breaker.

Base is classic best-fit (-r).  Distribution-aware terms are kept small
(bounded) so they only refine the ordering among near-equal residuals,
never overriding best-fit.  Terms: a small stranded-space penalty
(P(future item too big to fit in residual)) and a small usability bonus
(P(at least one future item fits in residual)), plus a bounded exact
refill bonus.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    cdf = np.cumsum(_stats.sizes) / n
    # two[s] = P(two independent items sum exactly to s), for s in 0..100
    two = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    # Multiplied by a large factor so best-fit ordering is always dominant.
    score = -r * 1000.0

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(item > r): for r>=100 it's 0; else 1 - CDF(r).
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 6.0

        # Perfect-refill bonus: residual exactly equal to a common size,
        # or decomposable into two common sizes.
        one = freq[rr]
        match = np.maximum(one, two[rr])
        score += match * 4.0

        # Usability: probability that at least one future item fits in r.
        usability = np.where(residual >= 100, 1.0, cdf[rr])
        score += usability * 2.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.5

    return score
# EVOLVE-BLOCK-END
