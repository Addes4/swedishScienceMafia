# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a waste-probability penalty.

For each candidate bin we compute the resulting residual r = bins - item.
Base is classic best-fit (-r).  We subtract a penalty proportional to the
probability that future items are too large to fit in r (stranded space),
and add bounded "perfect refill" bonuses when r can be exactly decomposed
into one, two or three frequently observed item sizes.

To keep calls cheap the empirical tables are rebuilt only every
`_REBUILD_EVERY` calls and reused in between.  Distribution terms fade in
with the number of observed items so early calls behave like pure
best-fit.
"""
import numpy as np

_REBUILD_EVERY = 25


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_one = None
_two = None
_three = None
_last_rebuild = -1


def _smooth(freq):
    """Gaussian-smooth the size distribution over integer sizes 1..100."""
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    return K.dot(w)


def _ensure_tables():
    global _freq, _cdf, _one, _two, _three, _last_rebuild
    n = _stats.count
    if n == 0:
        return
    if _freq is not None and (n - _last_rebuild) < _REBUILD_EVERY:
        return

    freq = _stats.sizes / n  # freq[s] = P(item == s)

    sw = _smooth(freq)
    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw

    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    # two[s] = P(two independent items sum exactly to s)
    two = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        idx = np.arange(1, s)
        if idx.size:
            two[s] = float(np.dot(sm[idx], sm[s - idx]))

    # three[s] = P(three independent items sum exactly to s), built from two
    three = np.zeros(101, dtype=np.float64)
    for s in range(3, 101):
        idx = np.arange(1, s)
        if idx.size:
            three[s] = float(np.dot(sm[idx], two[s - idx]))
        if three[s] > 1.0:
            three[s] = 1.0

    _freq = sm
    _cdf = cdf
    _one = sm
    _two = two
    _three = three
    _last_rebuild = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two
        three = _three

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Stranded space: P(item > r) = 1 - CDF(r) for r < 100.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 55.0

        # Perfect-refill bonuses: residual equal to a common size, or
        # decomposable into two / three common sizes.
        one = freq[rr]
        match = np.maximum(one, two[rr])
        match = np.maximum(match, three[rr] * 2.0)
        score += match * 30.0

        # Second-fit: probability residual can be left as (r - s) for some
        # common item size s, rewarding residuals that pair well with typical
        # items.
        second = np.zeros_like(r)
        for s in range(1, 101):
            ps = freq[s]
            if ps <= 1e-6:
                continue
            rr2 = np.clip(residual - s, 0, 100).astype(np.int64)
            valid = residual - s >= 0
            contrib = np.where(valid, freq[rr2], 0.0)
            second += ps * contrib
        score += np.minimum(second, 1.0) * 12.0

        # Usability: probability that at least one future item fits in r.
        usability = np.where(residual >= 100, 1.0, cdf[rr])
        score += usability * 8.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
