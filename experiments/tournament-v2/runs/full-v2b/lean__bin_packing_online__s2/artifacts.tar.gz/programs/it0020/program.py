# EVOLVE-BLOCK-START
"""Best fit with a mild anti-fragmentation penalty on loose fits."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Best fit tightness dominates; small penalty for leaving a small unusable residual
    # (1..15) that future mean-40 items will likely skip, encouraging better consolidation.
    small = (residual > 0) & (residual < 15)
    score = -residual.astype(np.float64) - 0.5 * small
    # tiny preference for fuller bins on ties to consolidate
    score = score - 1e-4 * bins
    return score
# EVOLVE-BLOCK-END
