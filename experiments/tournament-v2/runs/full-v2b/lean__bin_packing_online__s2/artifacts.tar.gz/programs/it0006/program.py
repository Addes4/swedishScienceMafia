# EVOLVE-BLOCK-START
"""Best fit with a small slack-shaping term.

Pure best fit (tightest remaining capacity that still fits) is a strong rule for this
Weibull-shaped distribution.  We keep that primary ordering and add a very small
secondary term that rewards packing into bins which end up "reasonably full" rather
than leaving a sliver of slack, which tends to reduce fragmentation in the tail of
small items without ever overriding a clearly tighter fit.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = bins.astype(np.float64)
    # Primary: tightest fit -> minimize remaining capacity after placement.
    # We express it as a large negative term.
    post = b - item  # remaining capacity if placed here

    # Secondary: mild shaping of the slack left behind.  We prefer solutions whose
    # resulting slack is small in a squared sense (keeps tight fits tight) but we
    # only let this act on a small scale so it cannot flip well-separated fits.
    slack_term = -0.001 * post

    # Tertiary: a tiny push toward already-full bins among near-ties.
    perf_term = 0.0005 * (100.0 - b)

    return -post + slack_term + perf_term
# EVOLVE-BLOCK-END

