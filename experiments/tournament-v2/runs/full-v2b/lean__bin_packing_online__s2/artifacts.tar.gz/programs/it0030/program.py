# EVOLVE-BLOCK-START
"""Best fit with a minimum-usable-residual guard (SwiftFit-flavored)."""
import numpy as np

_min_seen = [101]  # smallest item size seen so far (101 = none yet)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    if item < _min_seen[0]:
        _min_seen[0] = item

    residual = bins - item  # all >= 0 since bins are shown only if item fits

    # Penalize placements that leave a residual too small to ever be reused.
    m = _min_seen[0]
    too_small = residual < m

    # Primary: smallest residual; demote unusable residuals so they lose ties.
    score = -residual.astype(np.float64)
    if too_small.any() and not too_small.all():
        # place after usable bins by subtracting a large constant
        score = np.where(too_small, score - 1e6, score)

    return score
# EVOLVE-BLOCK-END
