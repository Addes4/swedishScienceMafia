# EVOLVE-BLOCK-START
"""Best fit with a graded penalty for stranding bins with small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item

    # A bin whose residual is positive but small tends to be stranded: it is
    # unlikely to accept future items, wasting the space already used.  Penalize
    # such residuals, with the penalty decreasing as the residual grows, but
    # never penalize an exact fit (residual == 0).
    T = 30
    r = residual.astype(np.int64)
    # penalty is larger for smaller (but nonzero) residuals
    penalty = np.where((r > 0) & (r < T), (T - r), 0).astype(np.int64)
    return -(residual + penalty * 2)
# EVOLVE-BLOCK-END
