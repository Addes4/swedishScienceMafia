# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with expected-residual refinement.

We keep classic best-fit (-r) as the base signal, then refine it using the
empirical item-size distribution:

  * stranded penalty: subtract c1 * P(next item > r)
  * expected-refill: estimate the expected residual after the next fitting
    item is placed into this bin, and subtract c2 * that expected leftover
    (this prefers residuals that will end up cleanly near zero)
  * exact-refill bonus: small bonus when r equals a common size or splits
    into two common sizes.

The distribution terms are suppressed until enough items have been seen,
and they fade in gradually, to avoid early-game noise.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_expected = None
_last_count = -1


def _smooth(freq):
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    return K.dot(w)


def _ensure_tables():
    global _freq, _cdf, _two, _expected, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n
    sw = _smooth(freq)
    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw

    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    two = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        idx = np.arange(1, s)
        if idx.size:
            two[s] = float(np.dot(sm[idx], sm[s - idx]))

    # expected[s] = expected residual (s - x) after the next item x placed,
    # given x <= s, using smoothed density restricted to [1, s].
    # = s - E[x | x <= s]
    sizes = np.arange(1, 101, dtype=np.float64)
    weighted = sizes * sm[1:101]
    cweighted = np.cumsum(weighted)         # sum_{x<=s} x * f(x)
    cprob = np.cumsum(sm[1:101])            # sum_{x<=s} f(x)
    cond_mean = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        p = cprob[s - 1]
        if p > 1e-9:
            cond_mean[s] = cweighted[s - 1] / p
        else:
            cond_mean[s] = s
    expected = np.zeros(101, dtype=np.float64)
    expected[1:101] = sizes - cond_mean[1:101]
    expected = np.clip(expected, 0.0, 100.0)

    _freq = sm
    _cdf = cdf
    _two = two
    _expected = expected
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two
        expected = _expected

        rr = np.clip(residual, 0, 100).astype(np.int64)

        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 40.0

        # Expected residual after next fitting item; lower is better.
        exp_left = expected[rr]
        score -= exp_left * 0.45

        one = freq[rr]
        match = np.maximum(one, two[rr])
        score += match * 20.0

    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END

