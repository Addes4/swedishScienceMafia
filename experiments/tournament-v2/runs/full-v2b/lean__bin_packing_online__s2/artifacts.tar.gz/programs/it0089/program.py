# EVOLVE-BLOCK-START
"""Best-fit with a smooth, distribution-derived residual-shape tiebreak.

Primary rule: classic best-fit (-residual).  As a small tiebreak we reward
residuals that are likely to be *well consumed* by a future item, using a
smoothed empirical distribution of past item sizes.  Specifically we estimate,
for each candidate residual r, the expected leftover after placing a random
future item that fits:
      e(r) = sum_{s<=r} freq[s] * ((r - s) if freq-scaled...)
and reward small expected leftover.  The weight is small so best-fit dominates.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_exp_after = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _exp_after, _last_count
    n = _stats.count
    if n == _last_count or n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    # light smoothing to avoid overfitting
    freq = (freq * n + 1.0) / (n + 101.0)
    cdf = np.cumsum(freq)
    cdf = cdf / cdf[-1]

    # exp_after[r] = expected leftover after placing a fitting future item,
    # weighted by probability that such an item appears; for r in 0..100.
    # E[(r - s)^+ * P(s)] / P(fit) but we just use unnormalized mass.
    exp_after = np.zeros(101, dtype=np.float64)
    for r in range(101):
        if r == 0:
            exp_after[r] = 0.0
            continue
        s = np.arange(1, r + 1)
        w = freq[s]
        exp_after[r] = float(np.dot(w, (r - s)))

    _freq = freq
    _cdf = cdf
    _exp_after = exp_after
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # reward small expected leftover (negative penalty, small weight)
        score -= _exp_after[rr] * 0.5

    # Tiny tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.01

    return score
# EVOLVE-BLOCK-END
