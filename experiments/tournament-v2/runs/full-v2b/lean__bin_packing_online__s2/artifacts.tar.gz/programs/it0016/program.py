# EVOLVE-BLOCK-START
"""Best fit with online-observed residual desirability."""
import numpy as np

# Small state: counts of observed item sizes.
_COUNT = np.zeros(101, dtype=np.int64)
_TOTAL = 0


def priority(item, bins):
    """Rank bins by resulting residual, mildly favoring residuals that past items can fill."""
    global _TOTAL
    _COUNT[item] += 1
    _TOTAL += 1

    r = bins - item  # remaining capacity after placing item

    # Base: prefer tightest fit (smallest residual).
    score = -r.astype(np.float64)

    # Mild bonus for residuals that are exactly some previously seen item size,
    # or close to the mean observed item size, which tends to reduce waste.
    if _TOTAL >= 50:
        seen = _COUNT[1:101] > 0
        exact = np.zeros(101, dtype=bool)
        exact[1:101] = seen

        safe = np.clip(r, 0, 100)
        bonus = np.where(exact[safe], 0.35, 0.0)

        mean_size = float(np.dot(np.arange(1, 101), _COUNT[1:])) / float(_TOTAL)
        bonus += 0.05 * np.exp(-((safe - mean_size) ** 2) / (2.0 * (0.35 * mean_size + 1.0) ** 2))

        score += bonus

    # Preserve true best-fit as the dominant term.
    return score
# EVOLVE-BLOCK-END
