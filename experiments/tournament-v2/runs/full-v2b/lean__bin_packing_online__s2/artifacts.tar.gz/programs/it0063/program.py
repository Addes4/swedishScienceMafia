# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with expected-waste penalty.

We keep the reliable best-fit base and replace the hand-tuned bonus/penalty
with an estimate of how well the residual r can be filled by the empirical
size distribution.  Bins whose residual coincides with likely item sizes (or
sums of likely sizes) are preferred because they are more likely to be closed
exactly; bins with awkward residuals are penalized.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()

# Cached convolution and cdf, recomputed when stats move enough.
_cache = {"n": -1, "conv": None, "cdf": None}


def _refresh():
    n = _stats.count
    if n == _cache["n"]:
        return
    freq = _stats.sizes / n
    # self-convolution freq2[s] = P(two items sum to s), s = 2..200
    conv = np.convolve(freq, freq)
    cdf = np.cumsum(_stats.sizes) / n
    _cache["n"] = n
    _cache["conv"] = conv
    _cache["cdf"] = cdf


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    if _stats.count > 8:
        _refresh()
        conv = _cache["conv"]
        cdf = _cache["cdf"]

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(next item too big for residual): stranded-space risk.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 50.0

        # Fillability: probability the residual can be exactly matched by
        # one item (freq[rr]) or a pair summing to rr (conv).  Reward the
        # best of the two, so residuals that can be perfectly closed are
        # strongly preferred.
        one = _stats.sizes[rr] / _stats.count
        two = np.zeros_like(one)
        # conv index k corresponds to sum k; valid sums 2..200.
        for s in range(2, 101):
            two[rr == s] = conv[s]
        match = np.maximum(one, two)
        score += match * 25.0

    # Small tiebreak: don't open fresh bins unnecessarily.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
