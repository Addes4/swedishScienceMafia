# EVOLVE-BLOCK-START
"""Best-fit with a light, robust distribution-aware tiebreak.

Classic best-fit (smaller residual is better) is the dominant signal.  Small
distribution-aware adjustments only break ties among residuals that are close
in size, so the near-optimal best-fit ordering is preserved while we nudge
placements toward residuals that a typical future item can complete.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_last_count = -1


def _ensure_tables():
    global _freq, _cdf, _last_count
    n = _stats.count
    if n == _last_count or n == 0:
        return
    freq = _stats.sizes / n

    # light smoothing over integer sizes 1..100
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = K.dot(w)

    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sm[1:101])
    cdf[100] = 1.0

    _freq = sm
    _cdf = cdf
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant signal: best fit (smaller residual better).
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Small nudge: residuals that are exact sizes of common items get a
        # tiny bonus (bounded well below 1 so best-fit ordering dominates).
        one = freq[rr]
        score += np.minimum(one * 8.0, 0.4)

        # Mild stranded-space penalty, also bounded small.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 0.4

        # Prefer residuals that at least fit a typical future item.
        usability = np.where(residual >= 100, 1.0, cdf[rr])
        score += usability * 0.2

    # Tiny tiebreak: reuse open (non-empty) bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 1e-3

    return score
# EVOLVE-BLOCK-END
