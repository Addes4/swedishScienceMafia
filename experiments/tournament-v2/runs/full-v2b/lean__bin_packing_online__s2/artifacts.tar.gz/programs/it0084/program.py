# EVOLVE-BLOCK-START
"""Best-fit dominated scoring with a tiny distribution-aware tiebreak.

The dominant signal is classic best-fit: put the item in the bin that leaves
the smallest non-negative residual.  Ties (and near-ties) are broken by a
small bonus when the residual can be exactly consumed by one common future
item size or a sum of two common sizes, estimated from past items.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_two = None
_last_count = -1


def _ensure_tables():
    global _freq, _two, _last_count
    n = _stats.count
    if n == _last_count or n == 0:
        return
    freq = _stats.sizes / n
    two = np.zeros(101, dtype=np.float64)
    for s in range(1, 101):
        k = np.arange(1, s)
        if k.size:
            two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant: best fit (smaller residual is better).
    score = -r

    _ensure_tables()

    if _freq is not None:
        rr = np.clip(residual, 0, 100).astype(np.int64)
        match = np.maximum(_freq[rr], _two[rr])
        score += match * 0.5

    return score
# EVOLVE-BLOCK-END
