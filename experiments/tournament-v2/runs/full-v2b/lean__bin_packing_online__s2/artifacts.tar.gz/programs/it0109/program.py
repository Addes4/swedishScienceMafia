# EVOLVE-BLOCK-START
"""Expected-residual best fit.

For each candidate bin, compute the resulting residual r = bins - item.
Score the bin by the *negative expected residual* after one more future
item is placed optimally into that residual:

    E[r'] = sum_s freq[s] * max(0, r - s)

This single distribution-derived quantity penalises both loose fits
(large r) and residuals that future items cannot absorb (stranded space),
with no hand-tuned weights.  A small tiebreak prefers reusing fresh bins
last so best-fit ordering is preserved on ties.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_expres = None
_last_count = -1

# Precomputed expected-residual table for every residual 0..100 is rebuilt
# when the empirical distribution changes.
_ER = None


def _ensure_tables():
    global _freq, _cdf, _ER, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n
    # cdf[k] = P(item <= k) for k in 0..100
    cdf = np.cumsum(_stats.sizes) / n

    # ER[r] = sum_s freq[s] * max(0, r - s)   for r in 0..100
    #        = sum_{s < r} freq[s] * (r - s)
    s = np.arange(0, 101, dtype=np.float64)
    # matrix approach: ER[r] = sum_s freq[s]*max(0, r-s)
    diff = np.maximum(0.0, np.arange(101)[:, None] - np.arange(101)[None, :])
    ER = diff.dot(freq)  # shape (101,)
    _freq = freq
    _cdf = cdf
    _ER = ER
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    _ensure_tables()

    if _ER is not None:
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # Negative expected residual after one more optimal future placement.
        score = -_ER[rr]
    else:
        # Before any stats, fall back to classic best fit.
        score = -r

    # Tiebreak: prefer bins that are already open (residual < 100) so we do
    # not open fresh bins needlessly; fresh bins have remaining capacity 100.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.01

    return score
# EVOLVE-BLOCK-END
