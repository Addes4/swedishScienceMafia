# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a calibrated waste-probability penalty.

For each candidate bin compute the resulting residual r = bins - item.
Base score is best-fit (-r). We subtract a penalty proportional to the
probability mass of future items that are too large to fit in r, and add a
reward when r exactly equals a frequently observed item size.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item

    # Base: best fit -> smaller resulting residual is better.
    score = -residual.astype(np.float64)

    if _stats.count > 0:
        freq = _stats.sizes / _stats.count  # freq[s] = P(item == s)

        # Waste penalty: mass of future items that could NOT fit in residual r.
        cdf = np.cumsum(_stats.sizes) / _stats.count

        rr = np.clip(residual, 0, 100).astype(np.int64)
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 55.0

        # Exact "match made": reward residuals equal to a frequent item size.
        match = freq[rr]
        score += match * 30.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
