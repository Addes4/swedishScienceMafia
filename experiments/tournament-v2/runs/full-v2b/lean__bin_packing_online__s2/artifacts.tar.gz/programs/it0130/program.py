# EVOLVE-BLOCK-START
"""Best-fit with bounded, tie-breaking distribution signals.

Classic best-fit (-residual) is kept as the dominant term.  Among bins that
give the same residual we use distribution-aware signals that are strictly
smaller than 1 in magnitude, so they can only break ties and never override
the best-fit choice.  Signals: probability the residual strands space (future
items too large to fit) and probability at least one future item fits in it.
The empirical distribution is Gaussian-smoothed over integer sizes.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_cdf = None
_last_count = -1


def _ensure_tables():
    global _cdf, _last_count
    n = _stats.count
    if n == _last_count or n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    sw = K.dot(w)
    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0
    _cdf = cdf
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _cdf is not None:
        cdf = _cdf
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(item > r): stranded-space risk.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        # Usability: probability at least one future item fits in r.
        usability = np.where(residual >= 100, 1.0, cdf[rr])
        # Strictly bounded (<1) tie-breakers favoring usable, non-stranded space.
        score += usability * 0.5 - prob_too_big * 0.5

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.25

    return score
# EVOLVE-BLOCK-END

