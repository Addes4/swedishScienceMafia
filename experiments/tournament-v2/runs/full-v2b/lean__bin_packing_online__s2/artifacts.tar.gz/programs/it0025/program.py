# EVOLVE-BLOCK-START
"""Best fit with residual refill bias: prefer placing items where the leftover is close to the item size."""
import numpy as np


def priority(item, bins):
    """Score bins: highest score wins, ties to first.

    Prefer the bin whose residual after placement is closest to `item`
    (so the leftover space is likely to be refilled by a similar-sized item),
    which acts as a mild harmonic-style packing rule around best fit.
    """
    residual = bins - item
    # Distance between resulting residual and the item size.
    return -np.abs(residual - item)
# EVOLVE-BLOCK-END

