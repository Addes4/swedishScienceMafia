# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a waste-probability penalty.

For each candidate bin we compute the resulting residual r = bins - item.
We keep the classic best-fit base (-r), subtract a penalty proportional to the
probability mass of future items that are too large to fit in r (so residuals
that would be stranded are discouraged), and add a small reward when r exactly
equals a frequently observed item size (a "match made").
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    if _stats.count > 0:
        freq = _stats.sizes / _stats.count  # freq[s] = P(item == s)

        # Waste penalty: mass of future items that could NOT fit in residual r.
        # P(item > r) = 1 - CDF(r).  Larger residual => smaller penalty.
        cdf = np.cumsum(_stats.sizes) / _stats.count
        cdf100 = cdf[100] if cdf.shape[0] > 100 else 1.0

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(item > r): for r>=100 it's 0; else 1 - CDF(r).
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 60.0

        # Exact "match made": reward residuals equal to a frequent item size.
        match = freq[rr]
        score += match * 25.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
