# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with periodic statistics refresh.

Earlier versions rebuilt the empirical distribution tables on every call
(an O(100^2) convolution each time), which is pure overhead and unnecessary.
Here the tables refresh only every 32 items.  The score is classic best-fit
(smaller residual is better) plus a mild penalty for residuals that are too
small to accept a likely future item, plus a modest bonus when the residual
can be exactly matched by one or two common item sizes.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1
_REFRESH = 32


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == 0:
        return
    # Rebuild only every _REFRESH items (and on the first call).
    if _freq is not None and n - _last_count < _REFRESH:
        return
    freq = _stats.sizes / n
    cdf = np.cumsum(_stats.sizes) / n
    two = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        k = np.arange(1, s)
        two[s] = float(np.dot(freq[k], freq[s - k]))
    _freq = freq
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    freq = _freq
    if freq is not None:
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(a future item is too large to fit in this residual).
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 40.0

        # Exact-refill bonus: residual equals a common size or a sum of two.
        match = np.maximum(freq[rr], two[rr])
        score += match * 25.0

    return score
# EVOLVE-BLOCK-END

