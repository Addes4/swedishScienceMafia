# EVOLVE-BLOCK-START
"""Online bin packing: smooth best-fit biased toward reusable residuals.

The rule keeps a tiny online histogram of item sizes seen so far.  Instead of
purely minimizing the residual capacity after placement, it also mildly prefers
residuals that match (or come close to) the most frequent recent item sizes,
which tend to be reusable later, reducing tiny unusable leftovers.
"""
import numpy as np

# simple exponential moving statistics kept across calls
_state = {
    "n": 0,
    "mean": 40.0,
}

# small histogram of sizes in 5-point buckets (1..100 -> 20 buckets)
_hist = np.zeros(20, dtype=np.float64)


def priority(item, bins):
    """Return a score for every bin; the item goes to the highest score."""
    global _hist
    _state["n"] += 1
    # decay old counts so the histogram reflects recent/slowly-changing sizes
    _hist *= 0.999
    b = (item - 1) // 5
    if 0 <= b < 20:
        _hist[b] += 1.0

    # representative reusable sizes: centers of the three most frequent buckets
    order = np.argsort(_hist)[::-1][:3]
    centers = (order * 5 + 3).astype(np.float64)  # bucket centers approx

    residual = bins - item  # remaining capacity after placing the item

    # base: best fit -> smallest residual is best
    score = -residual.astype(np.float64)

    # bonus: residual close to a common future item size (small, tie-breaking)
    for c in centers:
        score += 0.02 * np.exp(-0.5 * ((residual - c) / 6.0) ** 2)

    return score
# EVOLVE-BLOCK-END
