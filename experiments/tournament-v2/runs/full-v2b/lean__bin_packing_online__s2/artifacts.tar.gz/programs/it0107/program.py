# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware tie-breaker.

Primary term is classic best-fit (-residual).  A small secondary bonus
rewards bins whose residual is more likely to fit a future item, computed
from the empirical CDF of items seen so far.  Because the bonus is bounded
and its weight is tiny relative to residual differences, best-fit still
dominates; the bonus only refines choices among near-equal residuals.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_cdf = None
_last_count = -1


def _ensure_tables():
    global _cdf, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    _cdf = np.cumsum(_stats.sizes) / n
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Dominant term: best fit.
    score = -r

    _ensure_tables()

    if _cdf is not None:
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(future item <= residual): higher residual -> more likely to be reusable.
        # For residual >= 100, cdf=1; for residual 0, cdf is P(item<=0)=0.
        p_fit = _cdf[rr]
        score += p_fit * 0.5

    # Slight preference for reusing already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.01

    return score
# EVOLVE-BLOCK-END
