# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with bounded, subordinate tie-breaks.

Base score is classic best-fit (-r).  On top we add small (<1 magnitude)
distribution-based signals that only break ties between equal residuals:
- a stranded-space penalty for residuals that most future items exceed,
- a "fillable" bonus for residuals matching one or two common sizes,
- a usability term rewarding residuals that fit at least one more item.

Because the combined tie-break magnitude is kept well under 1 (the minimum
gap between distinct integer residuals), pure best-fit always dominates and
these signals only choose among equally-good bins.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _smooth(freq):
    """Gaussian-smooth the size distribution over integer sizes 1..100."""
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    sw = K.dot(w)
    return sw


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)

    sw = _smooth(freq)
    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw

    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    two = np.zeros(101, dtype=np.float64)
    k = np.arange(1, 101, dtype=np.float64)
    for s in range(2, 101):
        idx = np.arange(1, s)
        if idx.size:
            two[s] = float(np.dot(sm[idx], sm[s - idx]))

    _freq = sm
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r * 10.0

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Probability no future item fits (residual too small): penalize.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        # Perfect-refill: residual matches a common size or two-item sum.
        one = freq[rr]
        match = np.maximum(one, two[rr])
        # Usability: probability at least one future item fits.
        usability = np.where(residual >= 100, 1.0, cdf[rr])

        # Combined bounded tie-break, magnitude kept < 1.
        tiebreak = (-prob_too_big * 0.55) + match * 0.30 + usability * 0.10
        score += tiebreak

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.001

    return score
# EVOLVE-BLOCK-END
