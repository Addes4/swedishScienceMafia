# EVOLVE-BLOCK-START
"""Hybrid best fit: tight fit for large items, pack small items into already-full open bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    if item >= 35:
        # pure best fit: tightest remaining capacity that still fits
        return -(bins - item)
    # small item: strongly prefer already-opened, fairly-full bins (remaining <= 50),
    # but still rank by tightness among them.
    tightness = -(bins - item)
    # bonus for bins that are already at most half-empty
    bonus = np.where(bins <= 50, 1000.0, 0.0)
    return tightness + bonus
# EVOLVE-BLOCK-END
