# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with light stranded-space shaping.

Classic best-fit (-r) is the dominant base.  On top of it we add small,
bounded distribution-aware nudges: a penalty for residuals likely too small
for a future item (stranded space) and a mild bonus for residuals near a
typical future item size.  Weights are kept small so the best-fit ordering is
only nudged.  The empirical size distribution is Gaussian-smoothed.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_mean = 0.0
_last_count = -1


def _smooth(freq):
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    return K.dot(w)


def _ensure_tables():
    global _freq, _cdf, _mean, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n

    sw = _smooth(freq)
    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw

    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    _freq = sm
    _cdf = cdf
    _mean = _stats.total / n
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit.
    score = -r

    _ensure_tables()

    if _freq is not None:
        cdf = _cdf
        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Stranded-space penalty: probability next item is too big for r.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        score -= prob_too_big * 6.0

        # Mild bonus for residual near a typical future item size.
        typical = _mean
        near = np.exp(-0.5 * ((r - typical) / 12.0) ** 2)
        score += near * 1.5

    # Small tiebreak: prefer sllightly less-full open bins? use fresh penalty.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
