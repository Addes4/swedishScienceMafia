# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a waste-probability penalty.

For each candidate bin we compute the resulting residual r = bins - item.
Base is classic best-fit (-r).  We subtract a penalty proportional to the
probability that future items are too large to fit in r (stranded space),
and add a bounded bonus when r can be filled by exactly one common item size.
A usability term rewards residuals likely to fit at least one more future
item.  Distribution terms stay strictly below the unit best-fit gap so they
only break ties among equal residuals.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _smooth(freq):
    """Gaussian-smooth the size distribution over integer sizes 1..100."""
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    sw = K.dot(w)
    return sw


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n  # freq[s] = P(item == s)

    sw = _smooth(freq)
    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw

    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    # two[s] = P(two independent items sum exactly to s), using smoothed freq
    two = np.zeros(101, dtype=np.float64)
    for s in range(2, 101):
        idx = np.arange(1, s)
        if idx.size:
            two[s] = float(np.dot(sm[idx], sm[s - idx]))

    _freq = sm
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf

        rr = np.clip(residual, 0, 100).astype(np.int64)

        # Subordinate distribution terms (total magnitude < 1).
        # P(item > r): stranded space penalty.
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        # Bonus: residual exactly equals a plausible future item size.
        match = freq[rr]
        # Usability: probability at least one future item fits in r.
        usability = np.where(residual >= 100, 1.0, cdf[rr])

        score += (-prob_too_big * 0.30 + match * 0.35 + usability * 0.20)

    # Tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
