# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: classify the item, then pick the tightest bin within the class."""
import numpy as np


def _class_bounds(item):
    # Harmonic thresholds: for item fraction f, choose k = ceil(1/f), then the
    # preferred remaining capacity range is [item, 100/(k-1)) if k >= 2, else [item, 100].
    f = item / 100.0
    if f <= 0.0:
        return 100.0
    k = int(np.ceil(1.0 / f))
    if k <= 1:
        return 100.0
    return 100.0 / (k - 1)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    upper = _class_bounds(item)
    fits_class = bins < upper
    # Within the preferred class, pick the tightest fit (smallest remaining capacity).
    # Outside the class, fall back to tightest fit among all remaining bins.
    # Score: prefer in-class bins, then prefer smaller remaining capacity.
    score = -(bins.astype(np.float64))
    score = score + np.where(fits_class, 0.0, -1000.0)
    return score
# EVOLVE-BLOCK-END

