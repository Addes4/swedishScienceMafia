# EVOLVE-BLOCK-START
"""Best-fit with strictly subordinate distribution-aware tie-breaking.

Base is classic best-fit (-r), which empirically is very strong here.
The distribution terms (stranded-space penalty, perfect-refill bonus,
usability bonus) are rescaled to lie in (-0.5, 0.5) so that they only
ever break ties between residuals of equal size: the gap between any two
distinct integer residuals is at least 1, so terms bounded below 1 cannot
reorder them.  This keeps best-fit dominant while still using the learned
size distribution to choose the best residual among equals.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_cdf = None
_two = None
_last_count = -1


def _smooth(freq):
    """Gaussian-smooth the size distribution over integer sizes 1..100."""
    k = np.arange(1, 101, dtype=np.float64)
    w = freq[1:101]
    sigma = 1.5
    d = k[:, None] - k[None, :]
    K = np.exp(-0.5 * (d / sigma) ** 2)
    K /= K.sum(axis=1, keepdims=True)
    sw = K.dot(w)
    return sw


def _ensure_tables():
    global _freq, _cdf, _two, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = _stats.sizes / n

    sw = _smooth(freq)
    sm = np.zeros(101, dtype=np.float64)
    sm[1:101] = sw

    cdf = np.zeros(101, dtype=np.float64)
    cdf[1:101] = np.cumsum(sw)
    cdf[100] = 1.0

    two = np.zeros(101, dtype=np.float64)
    k = np.arange(1, 101, dtype=np.float64)
    for s in range(2, 101):
        idx = np.arange(1, s)
        if idx.size:
            two[s] = float(np.dot(sm[idx], sm[s - idx]))

    _freq = sm
    _cdf = cdf
    _two = two
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r.astype(np.float64)

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        cdf = _cdf
        two = _two

        rr = np.clip(residual, 0, 100).astype(np.int64)
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        match = np.maximum(freq[rr], two[rr])
        usability = np.where(residual >= 100, 1.0, cdf[rr])

        # Combine into a single bounded signal in roughly [-1, 1].
        signal = (usability * 0.6) + (match * 0.8) - (prob_too_big * 0.6)
        # Squash to (-0.5, 0.5) so it can never override best-fit ordering.
        score += 0.5 * np.tanh(signal)

    # Tiebreak: reuse already-open bins over fresh ones (kept tiny).
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 1e-4

    return score
# EVOLVE-BLOCK-END
