# EVOLVE-BLOCK-START
"""Best fit with a distribution-adaptive, smoothly graded stranding penalty."""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.hist = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.hist[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    _stats.update(item)

    # Empirical distribution of items seen so far (including the current one).
    count = _stats.count
    hist = _stats.hist

    # Threshold T: a low percentile of observed item sizes.  Residuals below T are
    # "hard to reuse" and get penalized, with the penalty smoothly decreasing to 0 at T.
    cum = np.cumsum(hist)
    target = 0.28 * count
    T = int(np.searchsorted(cum, target, side="left"))
    if T < 1:
        T = 1

    residual = bins - item  # remaining capacity after placing; >= 0 since the bin fits

    # Smooth, graded penalty over the stranding window (0, T).
    rc = np.clip(residual, 0, 100)
    frac = np.clip(1.0 - rc / float(T), 0.0, 1.0)
    penalty = 40.0 * frac

    # No penalty for an exact fill (residual == 0) and for residuals at/above T.
    penalty = np.where(residual <= 0, 0.0, penalty)
    penalty = np.where(residual >= T, 0.0, penalty)

    return -(residual + penalty)
# EVOLVE-BLOCK-END
