# EVOLVE-BLOCK-START
"""Distribution-aware best-fit with a stranded-space penalty.

For each candidate bin we compute the resulting residual r = bins - item.
Base is classic best-fit (-r).  We subtract a penalty proportional to the
amount of space that is likely to be stranded (probability that future items
are too large to fit in r, times the residual), and add a bounded
"perfect refill" bonus when r can be exactly decomposed into one or two
frequently observed item sizes.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.sizes[item] += 1.0


_stats = _Stats()


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # Base: best fit -> smaller resulting residual is better.
    score = -r

    if _stats.count > 0:
        freq = _stats.sizes / _stats.count  # freq[s] = P(item == s)

        cdf = np.cumsum(_stats.sizes) / _stats.count

        rr = np.clip(residual, 0, 100).astype(np.int64)
        # P(item > r): for r>=100 it's 0; else 1 - CDF(r).
        prob_too_big = np.where(residual >= 100, 0.0, 1.0 - cdf[rr])
        # Stranded space: residual that future items likely cannot use.
        score -= prob_too_big * r * 2.0

        # Perfect-refill bonus: residual exactly equal to a common size,
        # or decomposable into two common sizes.
        one = freq[rr]
        two = np.zeros_like(one)
        for s in range(1, 101):
            k = np.arange(1, s)
            if k.size:
                two_s = float(np.dot(freq[k], freq[s - k]))
                if two_s:
                    two[rr == s] += two_s
        match = np.maximum(one, 0.5 * two)
        score += match * 30.0

    # Small tiebreak: reuse already-open bins over fresh ones.
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.1

    return score
# EVOLVE-BLOCK-END
