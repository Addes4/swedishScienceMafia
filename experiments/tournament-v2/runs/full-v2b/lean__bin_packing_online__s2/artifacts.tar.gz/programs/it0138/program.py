# EVOLVE-BLOCK-START
"""Best-fit with an exact-fill priority and a sharp empirical refill tie-break.

The empirical evidence is that best-fit dominates.  So the ranking is:
  1. strong bonus when the placement exactly fills a bin (residual == 0),
  2. classic best-fit: smaller residual is better,
  3. a sharp tie-break rewarding residuals that equal a frequently observed
     exact item size (so the bin can likely be refilled precisely),
  4. a small penalty for residuals that are too small to accept the typical
     arriving item (stranded space).
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.count = 0
        self.sizes = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.sizes[item] += 1.0


_stats = _Stats()
_freq = None
_last_count = -1


def _ensure_tables():
    global _freq, _last_count
    n = _stats.count
    if n == _last_count:
        return
    if n == 0:
        return
    freq = np.zeros(101, dtype=np.float64)
    freq[1:101] = _stats.sizes[1:101] / n
    _freq = freq
    _last_count = n


def priority(item, bins):
    _stats.update(item)

    residual = bins - item
    r = residual.astype(np.float64)

    # 2. best-fit base
    score = -r

    # 1. exact fill is highly preferred
    score += (residual == 0).astype(np.float64) * 5.0

    _ensure_tables()

    if _freq is not None:
        freq = _freq
        rr = np.clip(residual, 0, 100).astype(np.int64)
        # 3. sharp refill match: residual equals a common exact size
        match = freq[rr]
        score += match * 20.0

        # 4. stranded space: residual too small for the typical item
        # typical item ~ use mean of distribution via freq-weighted avg
        # cheap proxy: penalize tiny nonzero residuals
        tiny = ((residual > 0) & (residual < 8)).astype(np.float64)
        score -= tiny * 1.5

    # prefer reuse of already-open bins over fresh ones
    fresh = (bins >= 100).astype(np.float64)
    score -= fresh * 0.05

    return score
# EVOLVE-BLOCK-END
