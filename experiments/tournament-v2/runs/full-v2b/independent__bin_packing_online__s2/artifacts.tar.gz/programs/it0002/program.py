import numpy as np

_OPENED = 0

def priority(item, bins):
    """Best-fit with a slight bias toward already-used bins to reduce fragmentation."""
    global _OPENED

    # residual waste after placing item
    waste = bins - item
    score = -waste.astype(np.float64)

    # Favor bins that are not full/empty-style ties. After a bin has been used,
    # its residual capacity is below 100; untouched bins remain exactly 100.
    # A very small bonus for used bins helps avoid opening extra bins in ties.
    used_bonus = (bins < 100).astype(np.float64) * 1e-6
    score += used_bonus

    return score
