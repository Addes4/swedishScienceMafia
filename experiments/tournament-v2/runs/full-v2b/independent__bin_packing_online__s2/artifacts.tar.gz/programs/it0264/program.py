import numpy as np


def priority(item, bins):
    """Score bins for an online bin-packing heuristic.

    The returned score is highest for the bin that leaves the smallest positive
    residual capacity after placing the item.  Ties are resolved in favour of
    earlier bins by the harness.  A slight bonus is given to bins that are
    already relatively full, which encourages consolidation and reduces the
    number of partially used bins.
    """
    # Residual capacity after placing the item in each bin.
    residual = bins - item

    # Base score: prefer the smallest usable residual (best fit).
    score = -residual.astype(np.float64)

    # Small bonus for bins that are already more occupied.  This helps avoid
    # opening new bins when an existing bin can still accommodate the item.
    # The bonus is scaled to stay smaller than the integer residual differences
    # in most cases, but it still breaks ties favourably.
    occupied = 100.0 - bins.astype(np.float64)
    score += 0.02 * occupied

    return score
