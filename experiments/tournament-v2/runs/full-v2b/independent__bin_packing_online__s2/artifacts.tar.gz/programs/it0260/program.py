import numpy as np

_state = {
    "count": 0,
    "sum": 0,
}

def priority(item, bins):
    global _state
    _state["count"] += 1
    _state["sum"] += item

    # Best-fit style: prefer the bin where remaining capacity after placing is smallest,
    # but discourage opening a completely unused bin unless nothing else works.
    # Score = 1000 - remaining_after (higher for tighter fits).
    remaining_after = bins - item

    # Give a mild bonus to already-used bins so unused bins are not opened prematurely.
    # Unused bins have remaining capacity exactly 100; used bins usually less.
    unused_penalty = np.where(bins == 100, 1.0, 0.0)

    # Primary: smaller remaining after placement is better -> larger score.
    # Secondary: penalize choosing fresh bins.
    scores = 1000.0 - remaining_after - unused_penalty

    return scores.astype(np.float64)
