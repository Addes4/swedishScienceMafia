"""Best fit with small size-class-aware scoring to pack tightly without fragmenting."""

import numpy as np


def priority(item, bins):
    # Best fit: smaller remaining capacity after (i.e. bins closer to item size) is better.
    # bins - item is residual room if we place the item; we want minimal residual.
    # Score higher for smaller residual.
    residual = bins - item

    # Primary score: tightest fit.
    score = -residual.astype(np.float64)

    # Prefer placing into already-used bins over opening a brand-new empty bin,
    # unless the empty bin gives a perfect fit (residual 0) which is ideal.
    # Empty bins have bins == 100.
    is_empty = (bins == 100)
    # Penalize empty bins slightly so nonempty bins are preferred, but small
    # enough that a much tighter fit in an empty bin still wins.
    score -= is_empty * 0.01

    return score
