import numpy as np


def priority(item, bins):
    """Rank bins by best fit: prefer tightest fit, but avoid leaving tiny residuals."""
    residual = bins - item

    # Score: smaller residual is better (so negative residual).
    # Add a small penalty for residuals in (0, item) that are hard to fill later.
    # Penalty term: encourage residuals that are either 0 (perfect) or reasonably large.
    score = -residual.astype(np.float64)

    # For bins that are used (residual < 100), extra shaping:
    used = bins < 100
    if np.any(used):
        r = residual[used].astype(np.float64)
        # Penalize very small positive residuals (waste risk)
        # and reward near-perfect fits.
        penalty = np.where(r > 0, 1.0 / (r + 1.0), 0.0)
        score[used] -= 0.05 * penalty

    return score
