import numpy as np


class _State:
    def __init__(self):
        self.calls = 0


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    Best-fit plus a gentle age bias: among bins with the same remaining capacity,
    prefer the one whose index position suggests it was opened earlier.
    """
    _state.calls += 1

    # Primary rule: best fit (smallest remaining slack for this item).
    # bins are remaining capacities of bins the item fits in, so item <= bins.
    slack = bins - item

    # Tie-break: prefer earlier-indexed bins (already more committed / older).
    # Bin index in the provided array corresponds to fixed bin order.
    idx = np.arange(bins.shape[0], dtype=np.float64)

    # Score: higher is better.
    # Dominant term chooses tightest fit; tiny term breaks ties toward earlier bins.
    return -(slack.astype(np.float64)) - idx * 1e-9
