import numpy as np


class Packer:
    """Stateful best-fit variant: prefer tight fits, with a slight bias against fresh bins."""

    def __init__(self):
        # Number of items observed so far, useful for a mild tie-break.
        self.n = 0
        # Running estimate of the mean item size.
        self.total = 0.0
        # Bias for unused bins: start slightly negative so a tight fit elsewhere wins.
        self.empty_bias = -0.5

    def priority(self, item, bins):
        self.n += 1
        self.total += item

        # Best-fit score: bins whose remaining capacity is closest to item (small residual)
        # get the highest score. Add a small penalty for completely empty bins to delay
        # opening new ones, but keep it below 1 so exact fits always dominate.
        residual = bins - item
        # Score is higher for smaller residual. Convert to a bounded preference.
        # For used bins: -residual (i.e., larger remaining -> lower score, but still
        # scaled). For empty bins (100), subtract the bias.
        score = -residual.astype(np.float64)
        # Empty bins are at 100 remaining. Penalize opening new bins slightly.
        score[bins == 100] += self.empty_bias
        return score


_packer = Packer()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score."""
    return _packer.priority(item, bins)
