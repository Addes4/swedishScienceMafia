import numpy as np

# We use a lightweight adaptive policy:
# score(bin) = -remaining_after + small_bias * (bin_index-based tie shaping)
#
# The baseline best-fit is optimal to place item in bin with smallest remaining capacity
# that still fits. We add a tiny penalty for bins that would become nearly empty after
# placement when item is large, because those bins become hard to reuse. Conversely,
# for small items we favor bins that are nearly full (best-fit).
#
# Concretely:
#   remaining_after = bins - item
#   score = -remaining_after  (best fit)
#   plus 0.02 * (remaining_after / 100.0) * item_factor
#
# item_factor is small for small items (they can fit anywhere), larger for big items
# (they should avoid creating awkwardly small remainders).
#
# We also maintain simple moving statistics to adjust item_factor smoothly.

_state = {
    "n": 0,
    "mean_item": 40.0,
}

def priority(item, bins):
    global _state
    _state["n"] += 1
    n = _state["n"]
    # running mean of items observed so far (online estimate)
    _state["mean_item"] += (item - _state["mean_item"]) / n

    rem_after = bins - item

    # Best-fit base score
    score = -rem_after.astype(np.float64)

    # Adaptive shaping:
    # Large items (above current mean) should be placed into bins whose remainder
    # is not too small, because tiny remainders waste capacity for future items.
    # We bias slightly against creating remainders in [1, 10] for large items.
    #
    # Small items (below mean) benefit from filling tight spots -> no extra penalty.
    #
    # Bias magnitude kept tiny so best-fit remains dominant.
    mean_item = _state["mean_item"]
    if item >= mean_item:
        # penalize remainders that are small but positive (hard to fill),
        # but not zero (perfect fit) and not large (plenty of room).
        # Use a smooth bump centered around low remainders.
        # rem_after in [0,100]
        r = rem_after
        bump = np.exp(-((r - 5.0) ** 2) / (2.0 * (5.0 ** 2)))
        # But zero remainder is ideal -> suppress bump at r==0
        bump = np.where(r <= 0, 0.0, bump)
        # Scale by how large the item is relative to mean
        strength = 0.03 * min(1.0, (item - mean_item) / 60.0 + 0.3)
        score -= strength * bump
    else:
        # For small items, slightly prefer bins that are more full already
        # (i.e., smaller remaining after) - this is just amplification of best-fit
        # We also avoid leaving large bins almost untouched if a tight fit exists,
        # but best-fit already handles that.
        score += 0.0

    return score
