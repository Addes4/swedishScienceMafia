import numpy as np

def priority(item, bins):
    # Best fit: prefer bin where remaining-after-placement is smallest.
    # Exact fit gets extreme preference (score += 1000) to close bins perfectly.
    remaining_after = bins - item
    score = -remaining_after.astype(np.float64)
    # exact fit bonus
    score = np.where(remaining_after == 0, score + 1000.0, score)
    # slight preference to keep larger bins available? No—best fit is strong baseline.
    return score
