import numpy as np

# Stateless, but uses arrival count via a module-level counter as allowed (state across calls).
_call_count = 0

def priority(item, bins):
    """
    Online bin packing priority rule.

    Strategy:
      - Early phase: encourage using empty bins (rem cap == 100) to avoid fragmenting
        partially filled bins before enough items have arrived.
      - Main phase: Best Fit: prefer bin with smallest remaining capacity that fits the item.
      - Minor deterministic tie-break: earlier bins first (implicit by tiny + index hedge),
        though harness already breaks ties by first index.

    Return: numpy array of scores, same length as bins.
    """
    global _call_count
    _call_count += 1

    b = bins.astype(np.int64, copy=False)

    # Score 1: best fit closeness: larger is better, so use (item - rem) or -rem+item.
    # Since item constant across bins, ranking by -(rem) is equivalent.
    base = -b.astype(np.float64)  # smaller remaining -> higher score

    # Score 2: slight preference for empty bins early (bin capacity appears as 100).
    # Use a decaying bonus so behavior converges to pure best-fit quickly.
    # t = number of calls so far; bonus = large early, ~0 later.
    t = _call_count
    empty = (b == 100)

    # Bonus schedule: after ~200 items, mostly ignore this.
    # Peak bonus strong enough to dominate best-fit differences early.
    bonus_empty = 80.0 / (1.0 + 0.04 * (t - 1)) if t < 1000 else 0.0

    scores = base + bonus_empty * empty.astype(np.float64)

    # Tiny tie-break: earlier bins get infinitesimally higher score, but harness already
    # picks first on ties, so this is redundant. Keep zero to avoid over-tuning.
    return scores
