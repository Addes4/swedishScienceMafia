import numpy as np

# Weibull(shape k, scale lam) with mean ~40. Estimate: k~1.4, lam~43.7 gives mean ~39.8
_K = 1.4
_LAM = 43.7

# Precompute a lookup: for a residual capacity r, estimate expected "wasted space" / usefulness.
# We use the probability that a random future item fits exactly well.
# Build empirical-ish weighting via the Weibull pdf over integer sizes 1..100.
_sizes = np.arange(1, 101, dtype=np.float64)
_pdf = (_K / _LAM) * (_sizes / _LAM) ** (_K - 1.0) * np.exp(-(_sizes / _LAM) ** _K)
_pdf = np.maximum(_pdf, 0.0)
_pdf_sum = _pdf.sum()
_pdf = _pdf / _pdf_sum

# Probability mass below various thresholds
_cdf = np.cumsum(_pdf)
# prob_fit[r] = P(item size <= r), for r in 0..100
prob_fit = np.concatenate(([0.0], _cdf))

# Expected useful fill: for residual r, expected size of an item that fits,
# weighted by probability. We want residuals that will likely be filled well.
_expected_fill = np.zeros(101, dtype=np.float64)
for r in range(1, 101):
    w = _pdf[:r]
    ws = w.sum()
    if ws > 0:
        _expected_fill[r] = (w * _sizes[:r]).sum() / ws

# Score table per residual capacity: high if residual likely to be filled by a future item
# and low waste. Heuristic combination.
score_table = np.zeros(101, dtype=np.float64)
for r in range(101):
    if r == 0:
        # A full bin: perfect, no waste.
        score_table[r] = 1000.0
    else:
        pf = prob_fit[r]
        # Expected resulting waste if we place nothing more: residual r stays wasted
        # Reward residuals that are large enough to be useful AND have high fill prob.
        # Penalize residuals too small to fit typical items.
        score_table[r] = pf * r + 50.0 * pf

def priority(item, bins):
    residual = bins - item  # remaining capacity after placing
    return score_table[residual]
