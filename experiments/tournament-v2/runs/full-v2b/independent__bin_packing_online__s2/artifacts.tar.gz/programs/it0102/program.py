import numpy as np

# Cached desirability tables for each item size.
# For a bin with remaining capacity r, placing a new item of size s leaves r - s.
# We assign scores that prefer residuals around the typical future item size.
_TABLE = {}

def _build():
    # Approximate the item distribution: Weibull(shape ~ 1.5, scale so mean ~ 40).
    # Use a simple quantile/weight approximation to score residual capacities.
    # Scores are higher when the leftover capacity can still fit a typical item well.
    sizes = np.arange(1, 101, dtype=np.float64)
    # Weibull shape 1.5, scale chosen so mean = 40: mean = scale * Gamma(1 + 1/1.5)
    shape = 1.5
    # scipy may be available, but avoid importing if unnecessary.
    try:
        from math import gamma
        scale = 40.0 / gamma(1.0 + 1.0 / shape)
        pdf = (shape / scale) * (sizes / scale) ** (shape - 1.0) * np.exp(-(sizes / scale) ** shape)
    except Exception:
        # Fallback: roughly mean-40 distribution
        pdf = np.exp(-0.5 * ((sizes - 40.0) / 20.0) ** 2)
    pdf = pdf / pdf.sum()

    # Desirability of a residual capacity r: expected ability to place future items.
    # We want to avoid tiny unusable leftovers and avoid huge empty bins if tighter fits suffice.
    for s in range(1, 101):
        res = np.arange(0, 101 - s + 1, dtype=np.float64)
        # Probability that a random future item fits in residual res.
        fit_prob = np.array([pdf[:int(r)].sum() for r in res]) if True else None
        # Value: prefer residuals that fit typical items, with mild preference for smaller waste.
        # Score = fit_prob - small penalty for wasted space that is too small to be useful.
        score = fit_prob - 0.002 * (100.0 - res)
        _TABLE[s] = score
    return _TABLE

_build()

def priority(item, bins):
    s = int(item)
    score0 = _TABLE.get(s)
    if score0 is None:
        # Should not happen for 1..100, but compute on demand.
        _build()
        score0 = _TABLE[s]
    n = len(bins)
    b = np.asarray(bins, dtype=np.int64)
    idx = b - s
    # Any bin shown should fit, but clip defensively.
    idx = np.clip(idx, 0, len(score0) - 1)
    return score0[idx]
