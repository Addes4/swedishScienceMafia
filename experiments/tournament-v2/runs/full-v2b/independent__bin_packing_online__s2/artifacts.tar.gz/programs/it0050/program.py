import numpy as np

class BinPacker:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.int64)
        self.total = 0
        self.samples = []

    def priority(self, item, bins):
        # update stats
        self.counts[item] += 1
        self.total += 1

        # Compute a penalty for leftover capacity after placing the item,
        # preferring bins where the remainder is small (best fit), but also
        # consider how likely that remainder is to be useful later.
        rem = bins - item
        # Avoid division by zero; rem=0 is perfect fit -> best.
        # Score: higher is better. Use negative remainder plus small bonus for exact fits.
        score = -rem.astype(np.float64)
        # Bonus for exact fit
        score[rem == 0] += 0.5
        # Small bonus for leaving a remainder that matches common item sizes seen so far
        # (reservation heuristic). Only consider nonzero remainders.
        if self.total > 50:
            freq = self.counts.astype(np.float64) / self.total
            # Only reward remainders > 0 and <= 100
            mask = (rem > 0) & (rem <= 100)
            # reward proportional to observed frequency of that remainder size
            bonus = np.zeros_like(score)
            bonus[mask] = freq[rem[mask]] * 0.1
            score += bonus

        return score

_inst = BinPacker()

def priority(item, bins):
    return _inst.priority(item, bins)

# EVOLVE-BLOCK-END
