import numpy as np

# Global state: maximum achievable sum for each capacity 0..100
max_sum = np.zeros(101, dtype=np.int64)
seen = np.zeros(101, dtype=bool)
seen_sizes = []

def recompute_max_sum():
    """Recompute the unbounded knapsack max sum <= r for r=0..100."""
    global max_sum
    max_sum[0] = 0
    for r in range(1, 101):
        best = max_sum[r-1]
        for s in seen_sizes:
            if s <= r:
                val = s + max_sum[r-s]
                if val > best:
                    best = val
        max_sum[r] = best

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global seen, seen_sizes
    if not seen[item]:
        seen[item] = True
        seen_sizes.append(item)
        recompute_max_sum()
    # Score = max_sum[new_remaining] - max_sum[current_remaining] - epsilon * new_remaining
    # Higher score is better. The epsilon breaks ties in favour of tighter fits.
    new_remaining = bins - item
    scores = max_sum[new_remaining] - max_sum[bins] - 1e-6 * new_remaining
    return scores
