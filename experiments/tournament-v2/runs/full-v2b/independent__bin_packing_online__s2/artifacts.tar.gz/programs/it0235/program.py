import numpy as np


def priority(item, bins):
    # Best-fit: prefer the bin whose remaining capacity is closest to the item size.
    # Ties are broken by preferring bins with less remaining capacity (i.e. fuller bins),
    # which helps avoid unnecessarily opening new bins.
    #
    # bins is int64; we return a float score. The item goes to the highest score, ties to first.
    # Primary key: minimize (bins - item)  -> maximize -(bins - item)
    # Secondary key: minimize bins          -> maximize -bins
    #
    # Combining lexicographically via a large multiplier keeps the primary key dominant.
    return -((bins - item).astype(np.float64) * 1000.0 + bins.astype(np.float64))
