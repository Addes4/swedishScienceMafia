import numpy as np


def priority(item, bins):
    # Best-fit style: prefer bins where the remaining capacity after placing
    # the item is as small as possible.  Add a mild convex penalty that
    # discourages leaving very small unusable gaps, which helps online packing.
    rem = bins - item
    # Values are nonnegative.  Smaller rem => higher score.
    # A quadratic term makes almost-full bins less attractive than bins that
    # leave a slightly larger but still well-utilized residual capacity.
    score = -(rem + 0.02 * rem * rem)
    # Prefer later bins very slightly among equal scores to reduce early
    # fragmentation; the harness still uses first-on-ties after this.
    score = score - 1e-9 * np.arange(len(bins), dtype=np.float64)
    return score
