"""Adaptive threshold bin packing: worst-fit for small items, best-fit for large ones."""
import numpy as np


def priority(item, bins):
    """Return a priority per bin. Highest score wins; ties go to the first bin.

    Strategy: for small items prefer emptier bins (worst-fit) so that large residual
    gaps remain available for future large items; for larger items use best-fit to
    reduce fragmentation. Thresholds chosen for a Weibull-like size distribution
    with mean ~40.
    """
    # Score: we want highest = best.
    # best-fit term: prefer smaller residual capacity (tighter) -> -(bins)
    # worst-fit term: prefer larger residual capacity (emptier) -> +(bins)
    if item <= 30:
        # worst-fit among fitting bins; prefer more empty bins to keep flexibility
        # Use bins directly (larger remaining => higher score).
        # Slight tie-break toward slightly larger (emptier) bins is automatic.
        return bins.astype(np.float64)
    elif item <= 55:
        # intermediate: balance by preferring bins that leave a residual that is
        # itself a "useful" size. Prefer residual close to around 0 or to ~40-60.
        # Simple robust choice: mild best-fit with penalty for leaving tiny residual.
        resid = bins - item  # remaining capacity after placing (>=0)
        # Prefer leaving a medium/large residual (good for future medium items),
        # but not so empty that we waste a fresh bin. Best-fit-ish.
        # Higher score for smaller residual, but reward residual in [20,60].
        score = -(resid.astype(np.float64))
        # small bonus to avoid creating unusably tiny slivers (<... ) is handled by best fit
        return score
    else:
        # large items: pure best-fit to pack tightly
        return -(bins.astype(np.float64))
