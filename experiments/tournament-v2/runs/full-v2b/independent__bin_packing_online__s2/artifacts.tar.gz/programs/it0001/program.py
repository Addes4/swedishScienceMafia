import numpy as np


class _State:
    def __init__(self):
        self.n = 0


_state = _State()


def priority(item, bins):
    """Best-fit score with a slight bias against fresh bins.

    bins: remaining capacities, all >= item.
    Return negative remaining capacity (smaller remaining = better fit, higher score).
    """
    # Best fit: most tightly fitting bin gets the highest score.
    # Score = -(remaining capacity). Ties go to the first bin (lowest index).
    return -(bins.astype(np.float64))
