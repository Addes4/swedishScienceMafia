import numpy as np


def priority(item, bins):
    """Rank bins by fit quality: exact fit first, then tight fits, then non-empty leftovers."""
    fits = bins >= item
    if not np.any(fits):
        return np.zeros(len(bins), dtype=np.float64)

    residual = bins - item

    # Zero residual is an exact fill: best possible.
    exact = (residual == 0) & fits
    if np.any(exact):
        scores = np.full(len(bins), -1e9, dtype=np.float64)
        scores[exact] = 1e9
        return scores

    # Prefer bins with small positive residual, but strongly discourage opening a new bin.
    # A partially used bin that gives a reasonable fit should beat an empty bin.
    scores = np.full(len(bins), -1e9, dtype=np.float64)

    used = bins < 100

    # Tight-fit score for used bins.
    used_fits = fits & used
    if np.any(used_fits):
        scores[used_fits] = 1000.0 - residual[used_fits].astype(np.float64)

    # Empty bins are allowed only when no usable partial bin exists,
    # or as a modest fallback.
    empty_fits = fits & (~used)
    if np.any(empty_fits):
        scores[empty_fits] = -residual[empty_fits].astype(np.float64)

    return scores
