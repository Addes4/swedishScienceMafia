import numpy as np


def priority(item, bins):
    """Return a score per bin; highest score wins, ties go to the first bin.

    Best-fit plus a small secondary term that prefers leaving residual slack
    close to the item size, which helps pack the medium-sized items from this
    Weibull-shaped distribution more tightly.
    """
    residual = bins - item

    # Primary: best fit (smallest residual that still fits).
    # Secondary: mild preference for residual near item size.
    score = -residual.astype(np.float64)
    score += 0.05 * np.abs(residual - item)

    return score
