import numpy as np


def priority(item, bins):
    """
    Best-fit variant with a mild preference against opening new bins.

    bins contains the remaining capacity of every currently open bin plus all unused bins
    (capacity 100).  The item should go into the bin with the highest score.

    The score is highest for the tightest fitting bin, i.e. the smallest remaining
    capacity that is still >= item.  Bins that are exactly full after insertion get
    the best score; completely empty bins are mildly discouraged so that small items
    tend to fill existing bins before new bins are opened.
    """
    # Remaining capacity after placing this item.
    leftover = bins - item

    # Base: best fit -> prefer smaller leftover, but only among fitting bins.
    # Since bins only contains fitting bins, smaller leftover is better.
    score = -(leftover.astype(np.float64))

    # Mildly discourage opening brand-new bins.  Empty bins have remaining capacity 100.
    # This is a constant penalty, independent of item size, so it does not disturb the
    # ordering among partially filled bins.
    score[bins == 100] -= 0.5

    return score
