"""Best fit with a mild large-item tie-bias for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base rule: best fit = smallest remaining capacity (tightest fit).
    # Score is higher for smaller remaining capacity.
    score = -bins.astype(np.float64)

    # Mild bias: for large items, prefer bins that are already more filled
    # in a way that is slightly stronger than pure best fit, while for small
    # items best fit dominates. This helps avoid opening new bins for large
    # items when an existing bin can absorb them reasonably well.
    if item >= 25:
        # Penalize empty bins slightly so large items tend to reuse existing bins.
        empty = bins == 100
        score[empty] -= 0.05 * item

    # Tiny deterministic tie-break toward earlier bins is already handled by
    # the harness (first highest on ties), so no extra term is needed.
    return score
