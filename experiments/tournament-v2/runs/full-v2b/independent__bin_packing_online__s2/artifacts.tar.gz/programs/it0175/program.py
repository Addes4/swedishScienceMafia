import numpy as np

# Optional shared state across calls (not used heavily here, but allowed)
_STATE = {"count": 0, "sum": 0}


def priority(item, bins):
    """Rank bins for the arriving item.

    Combines:
      * Best-fit (tighter bins preferred) - strong baseline.
      * Slight penalty for opening new bins (remaining capacity == 100).
      * Slight bonus for bins whose resulting remaining capacity is a "useful"
        size relative to typical item sizes (~40), so leftovers are neither too
        small nor too large to be wasted.
    """
    bins = np.asarray(bins)

    # Core best-fit score: smaller remaining capacity -> higher score.
    # Scale so this dominates.
    base = -(bins.astype(np.float64))

    # Penalize using completely empty (unused) bins unless the item needs it.
    # Only penalize when there is some non-empty alternative that fits.
    new_bin_penalty = np.where(bins == 100, 0.35, 0.0)

    # After placing, remaining = bins - item. Reward "round" leftovers around
    # half a typical item (~20) which can combine with future items, and around
    # typical item sizes to catch exact matches. Use a mild smooth bonus.
    rem = bins.astype(np.float64) - float(item)
    # bonus for leftover near 0 (exact-ish fit) and near ~40/2 aggregates
    exact_bonus = np.exp(-np.abs(rem) / 3.0) * 0.9
    mid_bonus = np.exp(-((rem - 20.0) ** 2) / (2.0 * 15.0 ** 2)) * 0.25

    score = base + exact_bonus + mid_bonus - new_bin_penalty
    return score
