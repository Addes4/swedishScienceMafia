import numpy as np


# Optional state: track how many items each bin has received, keyed by bin identity
# not available (only remaining capacity array is given), so we exploit capacity patterns.
# Strategy: score = -(remaining_capacity_after_placement) primary, i.e. best fit,
# with a secondary preference based on exact-fit opportunities and a tiny bias
# toward bins that become perfectly full, then bins with smaller residual.
# We also add a deterministic perturbation based on bin index to break cycles
# in a way that tends to spread load cleanly (low-index bias reduced).

def priority(item, bins):
    """
    Best-fit with enhancements:
      - Strong preference for exact fit (remaining == item).
      - Then minimize resulting residual capacity.
      - Add tiny fractional tie-breakers based on residual smallness and index.
    """
    b = bins.astype(np.int64)
    residual = b - item  # >= 0 for all shown bins

    # Base: we want minimal residual -> negative residual.
    score = -residual.astype(np.float64)

    # Small bonus for exact fit to strongly prefer it over any other placement.
    exact = (residual == 0)
    score += exact * 0.5

    # Mild preference for placing in bins with smaller residual
    # (already dominant), but add a sub-unit bias so that among equal residuals
    # we pick the bin with the smallest index (first), which the harness does anyway.
    # To reduce pathological patterns, add a deterministic index-based epsilon
    # that slightly favors early bins only when residuals are large (lots of space),
    # encouraging consolidation instead of spreading.
    n = len(b)
    idx = np.arange(n)
    # epsilon in [0, 1e-6), extremely small so it only breaks exact ties
    score += (1.0 - idx / max(n, 1)) * 1e-7

    return score
