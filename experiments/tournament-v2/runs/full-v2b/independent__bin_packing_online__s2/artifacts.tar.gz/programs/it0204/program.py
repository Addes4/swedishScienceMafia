import numpy as np

def priority(item, bins):
    # bins: remaining capacities of bins the item fits into (>= item)
    # score higher = better choice
    # Strongly prefer exact fit.
    exact = (bins == item)
    # For non-exact bins, best fit: smaller residual after placement is better.
    residual = bins - item
    # Avoid residual 1-4 by penalizing tiny leftovers slightly (hard to reuse).
    tiny_penalty = np.where((residual > 0) & (residual < 5), 1.0, 0.0)
    # Weight: exact fit dominates; otherwise minimize residual with small penalty.
    score = -residual.astype(np.float64)
    score[exact] = 1e9
    score -= tiny_penalty * 0.5
    return score
