import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        # small adaptive parameter: how strongly we prefer tight fits
        self.tight = 1.0
        # track whether tight-fit choices seem to create many new bins
        self.recent_new = 0
        self.recent_placed = 0
        # item size histogram for light statistics
        self.size_counts = np.zeros(101, dtype=np.int64)
        # residual histogram for light feedback
        self.resid_counts = np.zeros(101, dtype=np.int64)

        # extra preference for leaving very small residues (0..5) or
        # exactly matching common item sizes.
        self.match_bonus = 0.25


_S = _State()


def priority(item, bins):
    """Score bins for online bin packing.

    A blend of best fit with mild adaptations:
      - primary: tightest fit (small residual), mostly best-fit
      - bonus for exact fit / near-exact fit
      - penalty for leaving residues that are awkward for the item distribution
    """
    global _S

    n = bins.shape[0]
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    _S.calls += 1
    if item >= 0 and item <= 100:
        _S.size_counts[item] += 1

    rem = bins.astype(np.int64)
    resid = rem - item  # >= 0 because bins shown only if item fits

    # Base: tightest fit. We prefer smaller residual.
    # Use a smooth monotonic transform so tiny differences still matter.
    base = -resid.astype(np.float64)

    # Exact-fit strong bonus.
    exact = (resid == 0).astype(np.float64)

    # Near-exact small-residue bonus (helps avoid fragmenting almost-full bins).
    near = np.zeros(n, dtype=np.float64)
    small = resid <= 5
    if np.any(small):
        near[small] = (6.0 - resid[small].astype(np.float64)) / 6.0

    # Residual-utility penalty: leaving a residue that is unlikely to be
    # exactly useful later is mildly discouraged. Use observed item histogram
    # to estimate how "useful" a residue is.
    counts = _S.size_counts
    total = float(counts.sum()) + 1.0
    # probability mass at each possible future item size, Laplace-smoothed
    p = (counts.astype(np.float64) + 1.0) / total
    # utility of residual r: how much of the item-size distribution is <= r
    # (a residue at least as large as an incoming item can still accept it).
    # Precompute cumulative distribution.
    cdf = np.cumsum(p)
    util = np.zeros(101, dtype=np.float64)
    for r in range(101):
        util[r] = cdf[r] if r <= 100 else 1.0

    resid_clipped = np.clip(resid, 0, 100)
    util_vals = util[resid_clipped]

    # Prefer bins whose residual is more likely to fit future items: higher util.
    # But we must not overwhelm best-fit; weight is modest and adaptive.
    w = 0.35

    score = base
    score += 2.0 * exact
    score += 0.5 * near
    score += w * util_vals

    # Adaptive nudge: if recently we have been creating many new bins,
    # prefer tighter fits more (because fragmentation is costly).
    if _S.recent_placed >= 32:
        new_rate = _S.recent_new / max(1, _S.recent_placed)
        # new_rate near 1 means almost every placement opens a new bin -> be tighter
        score += (new_rate - 0.3) * 0.5 * (-resid.astype(np.float64))
        if _S.recent_placed >= 256:
            _S.recent_new = 0
            _S.recent_placed = 0

    # Small tie-break toward earlier bins is inherent (max picks first).
    return score
