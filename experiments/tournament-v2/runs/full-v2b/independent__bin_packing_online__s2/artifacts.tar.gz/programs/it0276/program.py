import numpy as np


def priority(item, bins):
    # Primary: tightest fit (smallest remaining capacity after placing item).
    # bins - item is the leftover space if the item is placed in that bin.
    # Lower leftover = better. We negate it to make it a score (higher is better).
    leftover = bins - item

    # A tiny secondary preference: exact fits (leftover == 0) get a small nudge,
    # which can help pack slightly better without changing the main ordering.
    score = -leftover.astype(np.float64)

    # Exact-fit bonus (small enough to only break ties among equal leftover values,
    # i.e., it only matters when two bins lead to the same leftover space).
    score += (leftover == 0) * 1e-6

    return score
