import numpy as np

# State (persists between calls within an instance).
_state = {
    "n": 0,
    "mean": 40.0,
    "sum": 0.0,
    "hist": None,          # histogram of recent items
    "hist_n": 0,
    "target": 40.0,        # desired post-placement residual
}


def _update_stats(item):
    """Update running statistics on arriving items."""
    s = _state
    s["n"] += 1
    s["sum"] += item
    # Exponential-ish running mean.
    s["mean"] = s["mean"] * 0.999 + item * 0.001
    # Build a coarse histogram over 1..100 (buckets of 2) once we have enough data.
    if s["hist"] is None:
        s["hist"] = np.zeros(51, dtype=np.int64)  # size//2 buckets 0..50
    s["hist"][item // 2] += 1
    s["hist_n"] += 1


def priority(item, bins):
    s = _state
    _update_stats(item)

    # Target residual: small items should leave room for bigger ones; big items
    # should pack tightly. Use a mild function of the item size.
    # Empirically good: target ~ item (best-fit-ish) for large items, but for
    # small items prefer leaving moderate space so later large items can fit.
    if item >= 50:
        target = item * 0.55
    elif item >= 25:
        target = item * 0.9
    else:
        target = item * 1.15

    residual = bins.astype(np.int64) - item  # post-placement remaining capacity
    # Score: prefer residual close to target, then smaller residual (tighter).
    diff = np.abs(residual - target)
    # Tie-break toward bin that is more full after placement (smaller residual),
    # but keep the integer scores so first-bin tie rule applies cleanly.
    score = -diff * 1000 - residual
    return score
