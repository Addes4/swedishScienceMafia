import numpy as np


def priority(item, bins):
    # bins: remaining capacities. Best fit wants smallest leftover: bins - item.
    # Score higher for smaller leftover, but make empty bins less attractive
    # when a non-empty bin can fit tightly.
    leftover = bins - item

    # Base score: tightly fitting bins first.
    score = -leftover.astype(np.float64)

    # Penalize empty bins slightly so they are used mainly when no good
    # partially-filled bin is available. Unused bins have capacity 100.
    empty_mask = bins == 100
    score[empty_mask] -= 6.0

    # Strongly prefer bins that leave a very small remainder, but not at the
    # cost of always filling exactly to zero if that wastes a near-empty bin.
    # A mild bonus for leaving capacity that can still accommodate a small item.
    small_rem = (leftover >= 0) & (leftover <= 10)
    score[small_rem] += 0.5

    return score
