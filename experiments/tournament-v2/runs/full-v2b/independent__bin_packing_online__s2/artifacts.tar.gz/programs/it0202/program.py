"""Online bin packing: adaptive threshold best-fit priority rule."""

import numpy as np


class _State:
    def __init__(self):
        self.n_obs = 0
        self.total = 0.0
        self.max_item = 1
        # exponential moving average of item sizes
        self.ema = 40.0

    def observe(self, item):
        self.n_obs += 1
        self.total += item
        if item > self.max_item:
            self.max_item = item
        a = 0.02
        self.ema = (1.0 - a) * self.ema + a * item


_st = _State()


def priority(item, bins):
    """Rank bins so the item lands in the tightest fitting bin, with a mild
    adaptive preference for packing remainders near the running item scale."""
    _st.observe(item)

    # bins: remaining capacities of bins this item fits in (cap >= item)
    rem = bins.astype(np.float64)
    leftover = rem - item

    # Best-fit score: smaller leftover is better.
    # Add a tiny secondary term rewarding leftovers that align with the
    # typical item size, encouraging useful residual gaps.
    scale = _st.ema if _st.ema > 1.0 else 40.0

    # Prefer to leave a remainder close to a typical item size, but only
    # weakly so that best-fit dominates.
    align = -np.abs(leftover - scale)

    # Slight bias against opening brand-new empty bins (rem == 100) when the
    # item is not large, to concentrate load and reduce bin count.
    new_bin_penalty = np.where(rem >= 100.0, 0.0, 1.0)
    if item < scale:
        new_bin_penalty = new_bin_penalty  # keep shape, effect via weight below
        empty = (rem >= 100.0).astype(np.float64)
        new_penalty = -empty * 0.5
    else:
        new_penalty = np.zeros_like(rem)

    # Primary: tightest fit (least leftover). Tie-break: alignment, then avoid
    # opening new bins unnecessarily.
    score = -leftover + 1e-3 * align + 1e-2 * new_penalty

    return score
