"""Best-fit bin packing: choose the bin with the least remaining capacity that fits the item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: smaller remaining capacity after placing is preferred.
    # Equivalent to minimizing (bins - item), i.e., maximizing -(bins - item).
    return -(bins - item)
# EVOLVE-BLOCK-END
