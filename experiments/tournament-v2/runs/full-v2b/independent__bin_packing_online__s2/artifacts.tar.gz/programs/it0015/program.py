import numpy as np


def priority(item, bins):
    """
    Online bin-choice rule.

    Core idea: best fit.
      - Prefer bins with the smallest remaining capacity that still fits the item.
      - This packs items tightly and tends to leave larger empty bins available.
      - Completely empty bins (capacity == 100) are slightly penalized so we
        first try to fill partially used bins, reducing the number of open bins.

    Return a score per bin; highest score wins (first wins ties).
    """
    # Smaller remaining capacity after placing item = tighter fit = higher score.
    # We compute -(bins - item), but add a small bonus for non-empty bins.
    score = -(bins - item).astype(np.float64)

    # Penalize completely empty bins slightly so we don't open new ones
    # when an existing partially-filled bin can take the item.
    # Empty bins have remaining capacity 100.
    empty_mask = (bins == 100)
    score[empty_mask] -= 1e-6

    # Also give a tiny bonus to bins whose remaining capacity is close to item
    # (exact fit preference), though best fit already handles this.
    return score
