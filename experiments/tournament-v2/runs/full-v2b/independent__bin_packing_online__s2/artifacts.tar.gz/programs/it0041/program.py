import numpy as np


def priority(item, bins):
    """Best fit: prefer the bin whose remaining capacity after placing the item is smallest."""
    return -(bins - item)
