import numpy as np


def priority(item, bins):
    """Best-fit with a mild preference for leaving useful residual capacity.

    The item is placed into the fullest bin that can still fit it, but bins whose
    residual after placement would be very small are slightly penalized. This
    approximates best fit while avoiding tiny unusable leftovers.
    """
    residual = bins - item

    # Bins that fit perfectly or near-perfectly are good.
    # Bins whose residual is very small (but nonzero) are slightly less attractive
    # than bins that also fit tightly but leave a more usable remainder.
    score = -residual.astype(np.float64)

    # Small bonus for perfect fit, and slight penalty for tiny unusable leftovers.
    score += np.where(residual == 0, 0.25, 0.0)
    score -= np.where((residual > 0) & (residual < np.maximum(1, item // 4)), 0.05, 0.0)

    return score
