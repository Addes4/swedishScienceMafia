import numpy as np


def priority(item, bins):
    """Rank bins for an arriving item.

    The item goes to the highest score; ties go to the first bin.
    Strategy: mostly best fit, but strongly prefer exact fits, and slightly
    penalize using completely empty bins before existing partially-filled bins.
    """
    # Residual capacity after placing the item.
    residual = bins - item

    # Base best-fit score: smaller residual is better.
    score = -residual.astype(np.float64)

    # Strong bonus for an exact fit.
    score += (residual == 0) * 1000.0

    # Slight preference for using already-opened bins rather than empty ones.
    empty = bins == 100
    score -= empty * 0.25

    return score
