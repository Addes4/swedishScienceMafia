"""Online bin packing heuristic: best fit with exact-fit bonus and used-bin bias."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary score: tightest fit (smallest remaining capacity after placement).
    # Use negative remaining capacity so larger score = tighter fit.
    score = -(bins - item)

    # Strong bonus for exact fill: if a bin would become exactly full, take it.
    # This avoids wasting a perfect-fit opportunity.
    exact = (bins == item).astype(np.int64)
    score += exact * 1000

    # Slight bonus for bins that are not unused (remaining capacity < 100).
    # This consolidates existing partially filled bins before opening a new one,
    # which tends to reduce total bin count in online packing.
    used = (bins < 100).astype(np.int64)
    score += used * 0.5

    return score
