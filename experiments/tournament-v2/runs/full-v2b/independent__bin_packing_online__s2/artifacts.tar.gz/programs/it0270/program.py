"""Best fit with a mild bias against opening new bins when the residual is large."""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for all shown bins
    # Primary: place in the bin with the smallest residual (tightest fit).
    # Secondary: when residuals tie, prefer lower bin remaining capacity (fuller bins),
    # which keeps large empty bins free for future items.
    score = -residual.astype(np.float64) * 1000.0 - bins.astype(np.float64)
    return score
