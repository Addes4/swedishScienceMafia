"""Hybrid best-fit/worst-fit bin choice rule."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Use worst-fit for small items to leave large bins open for later large items,
    # and best-fit for large items to pack them tightly.
    if item <= 50:
        return bins
    return -(bins - item)
