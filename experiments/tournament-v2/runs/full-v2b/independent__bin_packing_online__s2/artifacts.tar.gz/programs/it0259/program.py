import numpy as np

# Lightweight online state: exponentially weighted mean item size.
_state = {
    "n": 0.0,
    "mean": 40.0,
    "mean_sq": 1600.0,
}


def _update(item):
    # EWMA-ish online estimate; alpha decays so early info matters but later
    # adapts quickly.  Cap influence to stay stable over 5000 steps.
    n = _state["n"] + 1.0
    _state["n"] = n
    alpha = 1.0 / min(n, 200.0)
    m = _state["mean"]
    q = _state["mean_sq"]
    _state["mean"] = (1.0 - alpha) * m + alpha * item
    _state["mean_sq"] = (1.0 - alpha) * q + alpha * (item * item)


def priority(item, bins):
    _update(item)

    bins = np.asarray(bins)
    leftover = bins - item  # remaining capacity after placing item here

    # Best-fit priority: prefer smaller leftover (i.e. tighter fit).
    # Score = -leftover, so highest score == smallest leftover.
    score = -leftover.astype(np.float64)

    # Distribution-aware adjustment.
    # If the item is small relative to typical items, avoid wasting a fresh bin
    # on it: penalize nearly-empty bins a bit so it tends to fill existing gaps.
    mean = _state["mean"] if _state["mean"] > 1e-9 else 40.0
    ratio = item / mean

    # When item << mean, we expect more items soon and want to reserve fresh
    # bins.  When item >= mean, pure best-fit is already good.
    if ratio < 0.85:
        # Bins that are completely empty (leftover == 100 - item) get a penalty.
        # Scale penalty smoothly; stronger for very small items.
        pen_strength = (0.85 - ratio) * 8.0
        # Empty-bin leftover is exactly "bins == 100". Use bins == 100 mask.
        empty_mask = bins >= 100
        score[empty_mask] -= pen_strength * (100.0 - item)

        # Also slightly prefer bins with decent existing utilization for small
        # items over almost-empty bins: penalize large leftover generally.
        score -= pen_strength * 0.05 * leftover.astype(np.float64)

    # Never give NaN; score is finite.
    return score
