import numpy as np

STATE = {
    "counts": np.zeros(101, dtype=np.float64),  # observed item counts per size
    "total": 0.0,
    "freq": None,
}

# Initialize with a rough Weibull-like prior (mean about 40, shape ~1.5-2)
if STATE["freq"] is None:
    x = np.arange(1, 101, dtype=np.float64)
    # approximate Weibull pdf with shape k=1.7, scale=45 (mean ~ 40)
    k, lam = 1.7, 45.0
    pdf = (k / lam) * (x / lam) ** (k - 1.0) * np.exp(-(x / lam) ** k)
    pdf = pdf / pdf.sum()
    STATE["freq"] = pdf


def _update_freq(item):
    STATE["counts"][item] += 1.0
    STATE["total"] += 1.0
    if STATE["total"] >= 1.0:
        # blend observed counts with prior (prior weight decreases over time)
        w = 20.0 / (20.0 + STATE["total"])
        obs = STATE["counts"] / STATE["total"]
        STATE["freq"] = w * STATE["freq"] + (1.0 - w) * obs
        STATE["freq"] /= STATE["freq"].sum()


def priority(item, bins):
    """Rank bins: best-fit with gap-aware scoring and light consolidation preference."""
    _update_freq(item)

    bins = bins.astype(np.float64)
    rem = bins - item  # remaining capacity if placed

    # Base score: prefer smaller resulting remaining capacity (best fit)
    score = -rem

    # Penalize unusable leftover gaps: a leftover r is bad if no typical future item
    # can fit, i.e., r is small relative to the typical item size. Reward bins that
    # leave either ~0 or a "useful" larger residue.
    freq = STATE["freq"]
    # expected usefulness of a leftover r: probability a future item <= r can fill some
    cdf = np.cumsum(freq)  # cdf[s-1] = P(item <= s)
    # But leftover is unusable mainly when it is below the minimum common item size.
    # Compute a smooth penalty based on small leftover values.
    small_pen = np.where(rem < 20.0, (20.0 - rem), 0.0) * 0.35
    # Slight reward for bins that are almost full after placing (tight but not tiny waste)
    tight_bonus = np.where(rem <= 0.0, 2.0, 0.0)
    # Reward leaving a residue that is likely reachable/completable: peak reward near 0
    residue_reward = 0.15 * np.exp(-rem / 8.0)

    score = score - small_pen + tight_bonus + residue_reward

    # Prefer bins that are already partly used (avoid opening new bins early)
    # This is implicit in best fit but strengthen it slightly.
    used = 100.0 - bins  # amount already used
    score = score + 0.02 * used

    # Avoid placing a small item into an almost-empty bin when a tighter bin exists
    empty_like = np.where(bins >= 95.0, 1.0, 0.0)
    score = score - 0.5 * empty_like * np.where(item < 30, 1.0, 0.0)

    return score
