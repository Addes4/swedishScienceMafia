import numpy as np

def priority(item, bins):
    # Find the best-fit bin (tightest fit) if any bin can accommodate the item
    # bins contains only bins the item fits in (all bins shown fit the item)
    # Basic best fit: minimize remaining capacity after placement
    best_fit_scores = -(bins - item)  # higher is better (smaller remaining capacity)

    # Detect if there is an "almost full" bin that should be filled now
    # If the tightest fit leaves a small remainder, prefer it strongly
    # Otherwise, if there is an empty/very empty bin, avoid it unless necessary
    # We can add a mild preference for filling bins with less remaining capacity,
    # but not opening new bins too early.

    # Compute a bonus for bins that will become nearly full
    # This is essentially best fit, but with a small push toward perfect fits
    remainder = bins - item
    # Perfect fit (remainder 0) gets a big bonus
    perfect_bonus = (remainder == 0) * 1e6

    # Penalize leaving large empty space (opening new bins too early)
    # Actually best fit already does this; we just strengthen it slightly
    # Use a non-linear score: prefer bins with smaller remainder, but more so for small remainders
    # e.g., score = -remainder - 0.01 * remainder^2
    # This makes tight fits even more attractive.
    score = -remainder - 0.01 * remainder * remainder + perfect_bonus

    # Convert to numpy float array
    return score.astype(np.float64)
