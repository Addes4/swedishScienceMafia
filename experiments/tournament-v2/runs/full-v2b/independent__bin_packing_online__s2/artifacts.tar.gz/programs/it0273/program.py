import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "last_bin": 0,
}


def priority(item, bins):
    """Adaptive best-fit with utilization-aware anti-fragmentation heuristic."""
    st = _state
    st["n"] += 1
    st["sum"] += item

    # Estimate the mean and use it to decide how greedy to be.
    mean_item = st["sum"] / st["n"]
    cap = 100.0

    # Number of "active" bins (not entirely empty) among the shown bins.
    active = np.count_nonzero(bins < 100)

    # Score: prefer best fit by default.
    # Tightness term: smaller remaining-after is better.
    after = bins - item

    # Base score strongly favors tight fits (least remaninder after placement).
    score = -after.astype(np.float64)

    # Mild preference to avoid leaving tiny unusable gaps:
    # penalize creating a remainder in (0, mean_item/2) which likely can't be reused soon.
    small_gap = (after > 0) & (after < (mean_item * 0.5) + 1)
    score -= small_gap.astype(np.float64) * (mean_item * 0.3 + 5.0)

    # If many bins are active and mean item is large, slightly prefer exact fits.
    exact = (bins == item)
    score += exact.astype(np.float64) * (mean_item * 0.5)

    return score
