import numpy as np


# Common item sizes in a Weibull-shaped distribution (mean ~40) tend to produce
# residuals that are hard to reuse.  We bias against leaving very small gaps.
_DANGER_CAPACITIES = np.array(
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
    dtype=np.int64,
)


def priority(item, bins):
    """Best fit, but penalize leaving a hard-to-fill residual capacity.

    The item goes to the bin with the highest score; ties go to the first such bin.
    """
    residual = bins - item  # remaining capacity after placing the item here

    # Base score: prefer tighter fit (smaller residual).
    score = -residual.astype(np.float64)

    # Penalize residuals that are unlikely to be exactly filled by future items
    # and that waste usable capacity.  A modest penalty is enough to nudge
    # choices toward bins whose residual is either zero or moderately large.
    danger = (residual > 0) & (residual <= 20)
    score -= danger * (21.0 - residual) * 0.5

    # Strongly prefer exact fits.
    score[residual == 0] += 1000.0

    return score
