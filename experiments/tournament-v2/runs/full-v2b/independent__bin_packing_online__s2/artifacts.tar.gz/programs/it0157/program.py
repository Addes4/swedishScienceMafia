import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mass = 0.0
        # tuning constants
        self.empty_bias = 2.0          # baseline preference for empty bins
        self.pressure_scale = 0.18     # how strongly packing pressure raises bias


_STATE = _State()


def priority(item, bins):
    """Rank bins: mostly best-fit, with controlled opening of empty bins.

    items average around 40/100, so best-fit alone works well. Opening a new
    empty bin too eagerly wastes space; delaying it too long hurts feasibility.
    We estimate how much total item mass has arrived relative to a rough capacity
    model and raise the empty-bin score when the system is under pressure.
    """
    global _STATE
    st = _STATE
    st.n += 1
    st.mass += item

    b = bins
    # Index of first empty bin (remaining capacity exactly 100).
    # Unused bins have capacity 100; used bins have <= 99 remaining.
    # Note: an empty bin could also be a used bin with remaining 100? No:
    # capacity is 100 and any item is >=1, so after use remaining <= 99.
    is_empty = (b == 100)

    # Best-fit base score: smaller remaining-after-placement is better.
    # score = -(b - item) = item - b
    score = item - b.astype(np.float64)

    # Estimate pressure: expected mass if items keep arriving at observed mean.
    # Optimal bins lower bound ~ ceil(total_mass / 100), but online uncertainty
    # means we can't fill perfectly. Use a soft measure of how many bins are
    # effectively opened so far.
    #
    # We don't see all bins, only those the item fits in. However, number of
    # bins seen grows over time; use item count as a proxy for total items.
    # Mean item so far:
    mean_item = st.mass / st.n

    # Expected total mass at end if 5000 items.
    # The harness uses 5000 items. We can use a fixed horizon here.
    horizon = 5000
    expected_total = mean_item * horizon

    # Lower-bound bins.
    lb = expected_total / 100.0

    # Current opened bins can be estimated by observing the max bin index in the
    # shown array? The array includes bins the item fits in. Empty bins are
    # capacity 100. Non-empty bins with remaining < item are excluded. So the
    # array length is not total bins. Use a cheap proxy: number of items / avg
    # items per bin. Average items per bin is roughly 100/mean_item.
    expected_bins = st.n / max(1e-9, (100.0 / max(1e-9, mean_item)))

    # Pressure ratio: how many bins we expect to need vs what a good packer uses.
    # Near lb means tight; a bit above means room.
    pressure = max(0.0, expected_bins / max(1.0, lb) - 1.0)

    # Empty-bin bonus: base plus pressure-driven. When many empty bins are
    # available, this encourages using a fresh bin only when needed.
    empty_bonus = st.empty_bias + st.pressure_scale * pressure * 100.0

    # Apply bonus to empty bins. Because empty bins have b=100, their base
    # score is item-100 (very low). The bonus must overcome that.
    # We want empty bins to win only when no reasonably tight non-empty bin
    # exists. Best non-empty score is at most item-1 (b>=1). Empty base is
    # item-100. Difference ~99. Give empty bins a bonus around 90-100 so they
    # compete but generally lose to tight bins.
    score[is_empty] += empty_bonus

    # Slight preference for earlier bins (lower index) is automatic via ties,
    # but we avoid adding index noise to keep determinism.

    return score
