import numpy as np


def priority(item, bins):
    # Prefer bins that fit tightly, but reward bins that are already somewhat full.
    # Score = -remaining_after_placement - alpha * log(remaining_before + 1)
    # Larger alpha makes us pack into existing bins more aggressively.
    alpha = 0.9
    rem_after = bins - item
    return -(rem_after + alpha * np.log(bins + 1.0))
