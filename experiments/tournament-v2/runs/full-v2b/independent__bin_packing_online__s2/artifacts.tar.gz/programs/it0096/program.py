import numpy as np

# state shared across calls
_state = {
    "count": 0,
    "sum": 0.0,
}


def priority(item, bins):
    s = _state
    s["count"] += 1
    s["sum"] += float(item)

    # Keep bins that are not empty from being preferred for tiny items,
    # and generally prefer tight fits for small items, loose fits for large items.
    # Threshold adapts slightly with the observed mean (mean ~40).
    mean = s["sum"] / s["count"] if s["count"] > 0 else 40.0

    # For large items, prefer bins with MORE remaining space (worst fit)
    # so big items don't get stuck in nearly-full bins.
    # For small items, best fit (tightest) packs better.
    cutoff = 55.0

    if item >= cutoff:
        # worst fit: maximize remaining capacity
        score = bins.astype(np.float64)
        # strongly avoid empty bins for large items? Empty bins are fine, but
        # use them only when needed; give a tiny bias to already-used bins
        # that still have room, to consolidate.
        score = score - 0.001 * (bins - 100.0)  # bins==100 -> -0.001*(0)=0, used bins slightly favored
        return score
    else:
        # best fit: tightest fit = minimize remaining-after
        return -(bins - item).astype(np.float64)
