import numpy as np


def priority(item, bins):
    rem = bins - item
    # Prefer bins that fit most tightly.
    score = -rem.astype(np.float64)

    # Slightly discourage opening a completely empty bin when an existing
    # bin with the same residual after placement is available.
    # Bins with remaining capacity 100 are the unused ones.
    score -= 1e-6 * (bins == 100)

    # Gentle bias toward using bins that become exactly full or nearly full.
    score += 1e-3 * (rem == 0)

    return score
