import numpy as np

# --- tunables ---
FULL_CAP = 100

def priority(item, bins):
    """Score bins by a best-fit/next-fit hybrid.

    Highest score goes to the bin minimizing residual capacity after placing the item,
    but with a tie-break that slightly prefers already-used bins over fresh empty bins,
    to reduce unnecessary new-bin openings.
    """
    residual = bins - item  # remaining capacity after placing

    # Primary: prefer tight fits (small residual).
    # Secondary within equal residual: prefer bins that already contain items
    # (capacity < 100) so we don't open a new bin when a used bin fits equally well.
    score = -residual.astype(np.float64)

    # Bonus for non-empty bins (remaining < FULL_CAP), tiny so it only breaks ties.
    used = bins < FULL_CAP
    score += used * 1e-6

    return score
