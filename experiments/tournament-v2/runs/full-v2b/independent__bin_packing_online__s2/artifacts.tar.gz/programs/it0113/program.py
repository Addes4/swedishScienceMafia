import numpy as np

def priority(item, bins):
    # Best fit: prefer smallest remaining capacity after placing the item.
    # Slightly penalize empty bins (remaining capacity 100) to discourage opening new bins.
    # This keeps behavior close to best-fit while improving utilization.
    leftover = bins - item
    # Penalty only for empty bins. Must be larger than any possible leftover difference
    # but small enough not to force impossible packing choices.
    # Since leftover ranges 0..(100-item), penalty of 1 is safe and effective.
    return -leftover - (bins == 100).astype(np.int64)
