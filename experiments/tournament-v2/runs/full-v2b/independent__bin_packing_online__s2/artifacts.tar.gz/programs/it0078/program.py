"""Online bin packing: best-fit with consolidation preference."""
import numpy as np


def priority(item, bins):
    """
    item: int, size of arriving item
    bins: np.int64 array, remaining capacities of bins the item fits in
    return: scores (higher = preferred)
    """
    residual = bins - item  # remaining capacity after placing

    # Base: prefer smallest residual (tightest fit) -> best fit.
    score = -residual.astype(np.float64)

    # Slight bonus for bins that are already used (bins capacity < 100),
    # to prefer consolidating over opening new bins when residuals tie-ish.
    used = (bins < 100).astype(np.float64)

    # Exact fit bonus: residual == 0 is ideal.
    exact = (residual == 0).astype(np.float64)

    # Keep score scale: best fit dominates, exact fit strongly preferred,
    # then used bins preferred over fresh ones.
    return score + 0.5 * exact + 0.25 * used
