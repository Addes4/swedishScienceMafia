import numpy as np

# EVOLVE-BLOCK-START
"""Online bin packing: score bins to prefer tight fits and avoid wasting new bins."""
import numpy as np


def priority(item, bins):
    """Rank bins (highest score wins).

    Core idea: best fit, i.e. prefer the bin whose remaining capacity is closest to
    the item size (minimizes leftover slack). Exact fits get a strong bonus. To avoid
    needlessly opening new bins, bins that remain essentially empty (capacity 100) are
    slightly penalized when a good fit exists elsewhere.
    """
    # Slack after placing the item in each bin.
    slack = bins - item

    # Base score: prefer small slack (best fit).
    score = -slack.astype(np.float64)

    # Strong bonus for exact fits (slack == 0).
    score += (slack == 0) * 1000.0

    # Mild penalty for using a completely unused bin (capacity 100) unless it's the
    # only option; discourages opening fresh bins when existing ones can absorb it.
    score += (bins == 100) * (-0.5)

    return score
# EVOLVE-BLOCK-END
