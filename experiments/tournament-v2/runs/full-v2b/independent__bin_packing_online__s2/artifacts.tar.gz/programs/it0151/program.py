import numpy as np

# Online bin packing: hybrid best-fit with residue preference and bin-use pressure.
#
# The item must be placed immediately. We mostly want best-fit (smallest remaining
# capacity that still fits), which keeps bins full and avoids fragmentation.
#
# To improve over pure best-fit, we add a mild preference for residual capacities
# that are "useful" leftovers (common item sizes / complements), and a small push
# to consume already-open bins before opening a fresh one.

# Distribution is Weibull-ish with mean ~40. Common item sizes cluster around
# roughly 15..70. Leaving a residual near common item sizes allows future items
# to fill bins more completely. We build a soft value for residual r.
_GOOD_RESIDUALS = np.zeros(101, dtype=np.float64)
for r in range(1, 101):
    # Value peaks at residuals that equal or closely match likely future items.
    # Use a smooth bump around the mean region and a few harmonics for robustness.
    x = r
    v = np.exp(-((x - 40.0) ** 2) / (2 * 16.0 ** 2))
    v += 0.5 * np.exp(-((x - 30.0) ** 2) / (2 * 12.0 ** 2))
    v += 0.5 * np.exp(-((x - 50.0) ** 2) / (2 * 12.0 ** 2))
    v += 0.35 * np.exp(-((x - 20.0) ** 2) / (2 * 8.0 ** 2))
    v += 0.35 * np.exp(-((x - 60.0) ** 2) / (2 * 8.0 ** 2))
    _GOOD_RESIDUALS[r] = v


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins the item fits in,
          including unused bins (capacity 100), in bin order.
    """
    b = np.asarray(bins, dtype=np.int64)
    residual = b - item  # remaining capacity after placing item; all >= 0

    # Base: prefer tightest fit (small residual), i.e. largest -(residual).
    base = -residual.astype(np.float64)

    # Residue preference: mild bonus if the post-placement residual is a
    # "useful" size that future items can likely fill.
    residue_bonus = _GOOD_RESIDUALS[np.clip(residual, 0, 100)]

    # Prefer not to open completely fresh bins when a used bin works well.
    # Fresh bins have b == 100; penalize them slightly unless they are clearly best.
    fresh_penalty = np.where(b >= 100, 1.5, 0.0)

    # Also slightly prefer bins whose original load is high (small current b),
    # naturally handled by base, but add tiny tie-breaker by bin index stability.
    score = base + 0.35 * residue_bonus - fresh_penalty

    return score
