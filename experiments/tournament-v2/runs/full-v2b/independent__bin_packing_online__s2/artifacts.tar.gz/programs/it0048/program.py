import numpy as np


def priority(item, bins):
    """Score bins for best-fit with a preference against opening new bins.

    The item goes to the bin with the highest score (first on ties).
    We prefer the tightest fitting bin, but slightly penalize using a
    completely empty bin (remaining capacity 100) so that we only open a
    new bin when no partially-filled bin can accommodate the item.
    """
    # Distance to full: smaller is better (tighter fit)
    slack = bins - item  # >= 0 for bins the item fits in

    # Base score: heavily prefer tight fits among non-empty bins.
    # Penalize using a fresh, entirely empty bin.
    is_empty = bins >= 100
    score = -slack.astype(np.float64)
    score -= is_empty.astype(np.float64) * 1000.0

    # Bonus for an exact fit on a non-empty bin.
    exact = (slack == 0) & (~is_empty)
    score += exact.astype(np.float64) * 10.0

    return score
