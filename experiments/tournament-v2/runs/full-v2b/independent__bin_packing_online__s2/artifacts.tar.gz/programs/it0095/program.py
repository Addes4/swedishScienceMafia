"""Best fit with empty-bin reservation for online bin packing."""

import numpy as np


def priority(item, bins):
    """Score each bin: highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities the item fits into,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base score: best fit (smaller remaining capacity after placement is better).
    # We use remaining capacity minus item: lower is better -> higher priority.
    score = -(bins - item).astype(np.float64)

    # Reserve completely empty bins: strongly penalize using them if any
    # non-empty candidate exists. Empty bins have remaining capacity 100.
    # Since all bins in `bins` fit the item, capacity 100 means unused.
    empty_mask = (bins == 100)
    if not np.all(empty_mask):
        # Penalize empty bins so they are chosen only when no partial bin fits.
        score[empty_mask] -= 1e6

    # Tiny tie-break: slightly prefer earlier bins, matching harness tie rule.
    # (Doesn't affect main ordering meaningfully.)
    score -= np.arange(bins.shape[0], dtype=np.float64) * 1e-9

    return score
