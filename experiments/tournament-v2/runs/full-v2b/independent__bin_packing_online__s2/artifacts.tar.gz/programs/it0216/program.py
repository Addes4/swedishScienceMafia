import numpy as np


def priority(item, bins):
    # Best Fit: prefer the fullest bin that still fits the item.
    # Give unused bins (capacity 100) a small penalty so we reuse existing bins.
    scores = -(bins - item)
    scores[bins == 100] -= 1
    return scores
