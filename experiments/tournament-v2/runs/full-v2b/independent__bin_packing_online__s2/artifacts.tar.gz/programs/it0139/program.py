import numpy as np


def priority(item, bins):
    """Best-fit variant: strongly prefer tight fits in already-used bins."""
    # Best fit: minimize remaining capacity after placement.
    # Add a small preference against very empty bins so we pack used bins more densely.
    return (item - bins) * 1000 - bins
