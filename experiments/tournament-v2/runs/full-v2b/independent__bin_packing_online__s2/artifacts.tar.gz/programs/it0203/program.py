import numpy as np

# Tunable constants (fixed, not per-instance).
LARGE_ITEM = 62          # items >= this are "large"
PERFECT_FIT_BONUS = 1e6  # huge bonus for exact fit
NEAR_FIT_BONUS = 1e4     # bonus for a near-perfect fit band

_class_cache = {}

def _desirability(item):
    """Heuristic desirability value of a residual capacity after placing `item`.

    Best-fit in general: prefer smaller residual (fuller bin).  But reserving
    a bin whose residual equals a common future item size is valuable, so we
    perturb slightly.
    """
    # Common future item sizes concentrated around ~30-50 for Weibull(mean40).
    # Penalize leaving residuals in the "sweet spot" that many items could use,
    # except very small residuals which are naturally good.
    if item >= LARGE_ITEM:
        # For big items: fill as tightly as possible, small residual preferred
        # strongly; a few tiny residual bands are extra desirable.
        res = -item  # placeholder, computed later
    return 0

def priority(item, bins):
    b = np.asarray(bins)
    residual = b - item  # remaining capacity after placing item (>=0)

    # Base best-fit score: prefer smallest residual => larger filled bin.
    score = -residual.astype(np.float64)

    # Exact / near-perfect fit is heavily rewarded.
    exact = residual == 0
    if exact.any():
        score[exact] += PERFECT_FIT_BONUS

    # For larger items, strongly prefer tight fits (fragmentation acceptable
    # because large items are rare and hard to place later).
    if item >= LARGE_ITEM:
        score -= 0.5 * residual.astype(np.float64)

    # Avoid leaving a residual in a commonly-occurring item-size band, since
    # that bin would be very useful later.  Slight penalty keeps it available.
    # Band derived from mean~40 Weibull: typical items 10..60.
    band = (residual >= 18) & (residual <= 60)
    score[band] -= 3.0

    # Slightly reward leaving a very small residual (almost full) and also very
    # small residuals are already top of best-fit; this reinforces.
    tiny = (residual > 0) & (residual <= 8)
    score[tiny] += 1.0

    # Reward using a fresh empty bin only when item is large (otherwise avoid
    # opening new bins). Fresh bins have residual 100-item.
    empty = residual == (100 - item)
    score[empty] -= 6.0  # discourage opening new bins

    return score
