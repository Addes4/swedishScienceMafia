"""Online bin packing: adaptive best-fit with distribution-aware tie-breaking and reuse bias."""

import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.total = 0
        self.size_hist = np.zeros(101, dtype=np.int64)
        self.bin_use = None
        self.last_item = 0
        self.recent = []


_ST = _State()


def priority(item, bins):
    st = _ST
    st.calls += 1
    st.total += int(item)
    st.size_hist[int(item)] += 1
    st.last_item = int(item)
    st.recent.append(int(item))
    if len(st.recent) > 200:
        st.recent = st.recent[-200:]

    n = len(bins)
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    b = bins.astype(np.float64)
    it = float(item)

    # Base: tightly-fit preference (best fit), scaled so all scores finite.
    # Larger remaining capacity otherwise gets mild reuse bias to consolidate.
    residual = b - it

    # Prefer exact/near-exact fits strongly.
    # residual >= 0 guaranteed by harness for shown bins.
    exact = (residual == 0.0)

    # Adaptive: late in the stream, favor filling partially used bins to avoid opening new ones.
    progress = min(1.0, st.calls / 5000.0)
    mean_item = st.total / max(1, st.calls)

    # Distribution-aware: items near mean should prefer medium fills; very large items prefer tight fits.
    # This term softly biases by how close residual is to a target waste.
    target_waste = 0.0 if it >= mean_item else max(0.0, min(30.0, mean_item - it) * 0.5)
    waste_pen = -np.abs(residual - target_waste)

    # Strong preference for best fit, plus consolidation of used bins.
    score = -residual * 4.0 + waste_pen * 0.15

    # Mild randomization to avoid pathological lock-in, deterministic and numpy-only.
    # Based on item and bin ranking, not on hidden global randomness.
    jitter = ((b * 0.0) + ((np.arange(n) * 1103515245 + int(item) * 12345) % 1000) / 1000.0 - 0.5)
    score += jitter * 0.02

    # Prefer reusing already-started bins instead of fresh full bins when fit quality ties.
    score += (b < 100.0) * 0.01

    # Avoid opening a new bin if a nearly-full used bin can take it reasonably.
    used_mask = (b < 100.0)
    if np.any(used_mask):
        best_used = np.min(residual[used_mask]) if np.any(used_mask) else np.inf
        # If any used bin fits, de-prioritize completely unused bins slightly.
        unused_mask = (b == 100.0)
        score += unused_mask * (-0.05)

    # Exact fits should win decisively.
    score += exact * 10.0

    # Late-game: strongly consolidate.
    if progress > 0.5:
        score += used_mask * (0.05 * progress)

    # Ensure finite, no NaN.
    score = np.nan_to_num(score, nan=0.0, posinf=1e9, neginf=-1e9)
    return score
