import numpy as np


def priority(item, bins):
    # Small items (< 40): best fit + slight preference for non-full bins to spread
    # Larger items (>= 40): worst fit + slight preference for tighter fits
    if item < 40:
        # Best fit: maximize remaining - item closeness
        return -(bins - item)
    else:
        # Worst fit: maximize remaining capacity, but avoid completely empty bins for large items
        # Slight bonus for bins that are somewhat used but still fit
        return bins


