import numpy as np

def priority(item, bins):
    # Best fit: maximize item - remaining, i.e. minimize leftover.
    # Add a tiny preference for bins with less remaining capacity to break ties
    # toward fuller bins without changing best-fit ordering materially.
    return -(bins - item) * 1000 - bins
