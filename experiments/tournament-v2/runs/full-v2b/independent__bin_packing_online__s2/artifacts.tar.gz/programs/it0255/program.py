import numpy as np

_state = {
    "item_count": 0,
    "sum_item": 0,
    "bias": 0.0,
}


def priority(item, bins):
    """Best-fit with a mild reserve-large-bins bias.

    Primary target: choose bin with smallest remaining capacity that still fits
    (best fit). Secondary: avoid wasting fresh/empty bins when smaller gaps exist.
    """
    st = _state
    st["item_count"] += 1
    st["sum_item"] += item

    # A tiny, stable bias: prefer tighter fits, but penalize using very empty bins.
    # This effectively makes the rule "best-fit, but don't open a new bin unless needed"
    # without explicitly knowing which bins were used.
    # (bins - item) is the leftover after placing; we minimize it.
    leftover = bins - item

    # score: higher is better. Base is negative leftover (tightest fit).
    score = -leftover.astype(np.float64)

    # Penalize choosing bins with large remaining capacity (near 100), encouraging
    # reuse of partially filled bins instead of consuming fresh capacity.
    # The penalty is strongest when many empty bins remain and mild otherwise.
    # Scale kept very small so it never dominates the best-fit ordering.
    score -= 0.002 * (bins - item).astype(np.float64)

    return score
