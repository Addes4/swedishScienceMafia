import numpy as np


def priority(item, bins):
    """Score bins for online bin packing.

    This is essentially best fit: put the item into the bin with the smallest
    residual capacity that still fits it. Small adjustments encourage using
    already-open bins before starting new ones, while avoiding too many
    exactly-filled bins that could have absorbed slightly smaller future items.
    """
    remaining = bins - item

    # Primary: prefer the tightest possible fit after placing the item.
    score = -remaining.astype(np.float64)

    # If placing the item fills a bin exactly, slightly penalize it so a bin
    # with a tiny bit of slack is preferred when capacities are close.
    score -= 0.15 * (remaining == 0)

    # Prefer reusing non-empty bins over empty bins when fits are comparable,
    # because starting a fresh bin usually costs more in the long run.
    score += 0.01 * (bins < 100)

    # Keep bins with more remaining space slightly less attractive than very
    # tightly fitting non-exact placements, without overriding best fit.
    score -= 1e-6 * bins.astype(np.float64)

    return score
