import numpy as np

# Mean item size is about 40, capacity is 100.
# We want to avoid leaving residuals that are too small to be useful,
# while still packing tightly.

_MEAN = 40.0


def priority(item, bins):
    rem_after = bins - item

    # Base best-fit: prefer smallest remaining capacity after placement.
    # But add a penalty for residuals that are likely useless or awkward.
    # A residual is considered awkward if it is positive but smaller than
    # a typical item size, because it may never be filled.
    # We give a mild bonus for residuals that are either 0 (perfect fit)
    # or large enough to accept another average item.

    # Score: lower rem_after is better; so we use negative rem_after.
    score = -rem_after.astype(np.float64)

    # Penalize small positive residuals (waste that is hard to reuse).
    # Residuals in (0, _MEAN) get a penalty increasing as they get smaller.
    # Residual 0 gets no penalty.
    small = (rem_after > 0) & (rem_after < _MEAN)
    # Penalty: e.g., (1 - rem_after/_MEAN) * weight
    penalty = np.where(small, (1.0 - rem_after / _MEAN) * 0.5, 0.0)
    score -= penalty

    # Slight preference for bins that are already partially used
    # (bins with remaining capacity 100 are unused; using a new bin is costly).
    # This encourages filling existing bins before opening new ones.
    # However, best-fit already tends to do this; we add a small bonus
    # for bins with rem_after == 0 (exact fit) to strongly prefer them.
    exact = (rem_after == 0)
    score = np.where(exact, score + 10.0, score)

    # Also prefer bins that are nearly full over completely empty bins
    # when residuals are similar; this is naturally handled by best-fit.

    return score
