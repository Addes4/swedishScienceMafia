import numpy as np

_state = {
    "sizes": [],           # recent item sizes
    "n_seen": 0,
    "last_remainders": None,
    "bin_count": 0,
}

def _wbin_score(item, bins, alpha, beta, gamma):
    """
    Score bins as:
      alpha * tightness + beta * reserve_value - gamma * fragmentation_penalty
    tightness      : -(remaining - item) / 100          (prefer tight fit)
      reserve_value  : remaining / 100                    (preserve large bins)
      fragmentation  : 1 / (1 + (remaining - item))       (avoid leaving tiny gaps)
    """
    rem = bins.astype(np.float64)
    gap = rem - item
    # prefer small non-negative gaps
    tight = -gap / 100.0
    # prefer preserving large remaining capacity (helps future big items)
    reserve = rem / 100.0
    # avoid producing tiny leftovers
    frag = 1.0 / (1.0 + np.maximum(gap, 0.0))
    return alpha * tight + beta * reserve - gamma * frag


def priority(item, bins):
    st = _state
    st["n_seen"] += 1
    st["sizes"].append(int(item))
    if len(st["sizes"]) > 400:
        st["sizes"] = st["sizes"][-400:]

    # Adaptive weights: early on favour best-fit; later favour preserving large bins
    # and avoiding fragmentation because large items are still likely (Weibull tail).
    n = st["n_seen"]
    # mean observed item size, used to know how "full" typical bins are
    mean_size = float(np.mean(st["sizes"])) if st["sizes"] else 40.0

    # Weights tuned to balance tight packing and future-proofing.
    # As packing progresses, preserving emptiness helps fit rare large items.
    alpha = 0.62
    beta = 0.30
    gamma = 0.08

    # Slight adaptation: if mean size is high, be a bit more conservative about filling bins.
    if mean_size > 42.0:
        alpha = 0.58
        beta = 0.34
        gamma = 0.08
    elif mean_size < 38.0:
        alpha = 0.68
        beta = 0.25
        gamma = 0.07

    scores = _wbin_score(item, bins, alpha, beta, gamma)

    # Small deterministic tie-breaker favouring earlier bins to reduce fragmentation over time.
    # (Bins array order is fixed; adding index-based tiny bias preserves stable packing.)
    idx = np.arange(scores.shape[0], dtype=np.float64)
    scores -= idx * 1e-9

    return scores
