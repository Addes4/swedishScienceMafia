import numpy as np

def priority(item, bins):
    # Remaining capacity after placing the item.
    rem = bins - item

    # Prefer bins that become exactly full, then tighter fits.
    # Avoid tiny leftover bins if possible by allowing a small penalty for very small remains.
    # Base score: negative remaining capacity (so smaller remainder => higher score).
    score = -rem.astype(np.float64)

    # Strong bonus for exact fill.
    score[rem == 0] += 1000.0

    # Mild preference against leaving a very small remainder (1..3), since those are hard to reuse.
    small = (rem > 0) & (rem < 4)
    score[small] -= 2.0

    # Slight preference for using an existing non-empty bin over opening a new one:
    # unused bins have bins == 100 before placement. Penalize those a bit.
    unused = (bins == 100)
    score[unused] -= 0.1

    return score
