import numpy as np

# State: keep track of how many bins have been opened/used.
# This helps bias against opening fresh bins unless the fit is very good.
_state = {"used": 0, "item_count": 0}

def priority(item, bins):
    global _state

    n = bins.shape[0]
    _state["item_count"] += 1

    # A bin is "virgin" (unused) when remaining capacity is 100.
    is_virgin = (bins == 100)

    # Slack after placing item in each bin.
    slack = bins - item  # >= 0 for all bins shown

    # Best fit: smaller slack is better. Primary ranking by slack ascending.
    # Add a small penalty for using virgin bins, to delay opening new bins.
    # The penalty should be large enough to prefer filling non-virgin bins
    # whenever they can fit, but not so large that it causes visible waste.
    # We scale it slightly with item size so tiny items do not force bad fits.
    penalty = 0.35 * item + 6.0

    score = -slack.astype(np.float64)
    score[is_virgin] -= penalty

    return score
