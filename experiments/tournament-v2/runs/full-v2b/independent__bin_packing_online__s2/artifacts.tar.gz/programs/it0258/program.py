import numpy as np

# EVOLVE-BLOCK-START
"""Adaptive best-fit with residual usefulness scoring for online bin packing."""

# --- online distribution estimate (coarse histogram) ---
_HIST = np.zeros(101, dtype=np.float64)
_N = 0
_MEAN = 40.0
# running estimate of typical item size (for residual usefulness)
_USEFUL_THRESHOLD = 40.0

def _update_stats(item):
    global _N, _HIST, _MEAN, _USEFUL_THRESHOLD
    _HIST[item] += 1.0
    _N += 1
    # incremental mean
    _MEAN += (item - _MEAN) / _N
    # estimate quantile-ish threshold: median-ish item size
    if _N >= 32 and (_N & (_N - 1)) == 0:  # occasionally recompute
        cdf = np.cumsum(_HIST) / _N
        # find median-ish size
        idx = np.searchsorted(cdf, 0.5)
        if idx < 1:
            idx = 1
        if idx > 100:
            idx = 100
        _USEFUL_THRESHOLD = float(idx)
    else:
        # smooth update
        _USEFUL_THRESHOLD = 0.99 * _USEFUL_THRESHOLD + 0.01 * _MEAN


def priority(item, bins):
    """Rank bins: prefer tight fit, but penalize residuals that are hard to reuse."""
    _update_stats(item)

    # residual capacity after placing item
    residual = bins - item  # >= 0 for all shown bins

    # Base: best-fit => smaller residual is better => score = -residual
    score = -residual.astype(np.float64)

    # Penalize residuals that are too small to fit a typical future item,
    # because they are effectively wasted (unless zero, which is perfect).
    t = _USEFUL_THRESHOLD
    # small residual (< t) but > 0 => penalize
    small_mask = (residual > 0) & (residual < t)
    # Penalty proportional to how "wasted" the residual is; larger t -> penalty
    score[small_mask] -= (t - residual[small_mask]) * 0.01

    # Slight bonus for completely filling a bin (residual 0)
    score[residual == 0] += 0.5

    # Slight bonus for bins that leave a residual still reasonably large
    # (avoid making tiny unusable leftovers)
    # (handled above)

    return score
# EVOLVE-BLOCK-END
