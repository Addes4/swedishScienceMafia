import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.last_big = 0
        self.seen = 0


_S = _State()


def priority(item, bins):
    n = _S.n
    _S.n += 1

    # Light online adaptation of the item-size estimate.
    # This cannot see the future, only past arrivals.
    if n < 20:
        alpha = 1.0 / (n + 1)
    else:
        alpha = 0.002
    _S.mean += alpha * (item - _S.mean)

    # Remaining capacities are given for bins that fit the item.
    b = bins.astype(np.float64, copy=False)

    # Best-fit baseline. Large positive score for tight fits.
    # bins - item is small when the bin is nearly full after placement.
    base = -(b - item)

    # Encourage using existing partially-filled bins rather than opening new ones.
    # Unused bins have capacity exactly 100. Penalize them mildly, more for small items.
    unused = (b == 100)
    existing = ~unused

    # For small items, prefer tighter existing bins; for large items, avoid wasting
    # a large empty bin unless necessary.
    if item < _S.mean:
        open_bonus = 2.0
    else:
        open_bonus = 0.8

    score = base.copy()

    # Add a small bonus for already-used bins (prevents needless new bins).
    score += open_bonus * existing.astype(np.float64)

    # Tie-break very slightly toward higher remaining capacity among equivalent best fits,
    # which tends to leave room for future large items.
    score += 0.001 * b

    # Deterministic tiny index bias: earlier bins win exact ties, matching harness rule.
    # (No explicit index available, but the input order is stable.)
    return score
