"""Adaptive best-fit with residual-size shaping and a threshold for opening new bins.

Track fill levels of bins ourselves (fixed bin order guaranteed), then score bins so that
the historically fullest fitting bin wins, with a mild preference for leaving residuals that
match frequently-seen item sizes. This combines best-fit's waste minimization with a light
anti-fragmentation / matching bias suited to the Weibull-shaped size distribution.
"""
import numpy as np

_CAP = 100

# running statistics over arriving items
_seen = 0
_sum = 0.0
_hist = np.zeros(_CAP + 1, dtype=np.int64)


def _reset():
    global _seen, _sum, _hist
    _seen = 0
    _sum = 0.0
    _hist = np.zeros(_CAP + 1, dtype=np.int64)


# track fill level of each bin by its index. bins array is always in fixed bin order,
# with unused bins represented by remaining capacity 100.
_fill = []
_last_len = -1


def priority(item, bins):
    global _seen, _sum, _hist, _fill, _last_len

    bins = np.asarray(bins)
    n = bins.shape[0]

    # reset state when a new instance starts (bin count grows monotonically within one
    # instance from 1 to #items; a decrease or fresh first call signals a new instance)
    if n < _last_len or (_last_len == -1):
        _reset()
        _fill = [0] * n
    elif n > len(_fill):
        _fill.extend([0] * (n - len(_fill)))
    _last_len = n

    # infer each bin's remaining capacity from our internal fill state, kept in sync
    # remaining = 100 - fill. Reconstruct remaining array.
    remaining = np.empty(n, dtype=np.int64)
    for i in range(n):
        remaining[i] = _CAP - _fill[i]

    # sanity: if our internal state diverged from harness-reported bins, trust harness
    # (items only ever reduce capacity, so reconcile any mismatch defensively)
    mismatch = np.where(remaining != bins)[0]
    if mismatch.size:
        for i in mismatch:
            remaining[i] = int(bins[i])
            _fill[i] = _CAP - int(bins[i])

    # update statistics with this item
    _hist[item] += 1
    _seen += 1
    _sum += item
    mean = _sum / _seen

    # Build a residual-match score: prefer leaving a residual equal to a common item size.
    # Compute weight for each possible residual once per call (cheap: 101 entries).
    r = remaining  # fits bins only (remaining >= item, but array may contain all fitting bins)
    # frequency-weighted match score for residual value v: how often v occurs as item size
    match_score = _hist.astype(np.float64)

    # For each bin, residual after placing item = remaining - item.
    residual = r - item

    # score components:
    # 1) Best-fit: smaller residual is better.
    # 2) Residual-match: residual matching a frequent item size is a bonus (future reuse).
    # 3) Prefer fuller bins (same as smaller remaining).
    eff = np.empty(n, dtype=np.float64)
    # weight of residual by frequency of that exact size (mild, to avoid over-fitting)
    clipped = np.clip(residual, 0, _CAP)
    freq_bonus = match_score[clipped]
    # normalize bonus
    denom = float(_seen) if _seen else 1.0
    freq_bonus = freq_bonus / denom

    # primary: best fit — penalize residual
    eff = -residual.astype(np.float64)
    # secondary: future-fit bonus (small weight)
    eff += 3.0 * freq_bonus
    # tertiary: prefer bins with more remaining capacity used (fuller bins)
    eff += -0.001 * remaining.astype(np.float64)

    # Slight bias: for large items, avoid fragmenting medium bins by keeping large empty bins
    # for large items. Encourage putting large items in bins that become nearly full.
    if item >= 60:
        # strongly prefer tight fits for big items
        eff += -0.5 * residual.astype(np.float64)

    return eff
# EVOLVE-BLOCK-END
