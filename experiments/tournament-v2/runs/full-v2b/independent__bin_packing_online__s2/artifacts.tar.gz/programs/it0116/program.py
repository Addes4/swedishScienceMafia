import numpy as np


def priority(item, bins):
    """
    Score bins for an incoming item.

    Higher score wins. Main idea:
    - Prefer bins where the item fits most tightly (best fit).
    - Slightly penalize creating large residual gaps, to reduce fragmentation.
    - Strongly prefer exact fits.
    """
    residual_after = bins - item

    # Best-fit: smaller residual after placement is better.
    # Exact fit gets a large bonus.
    score = -residual_after.astype(np.float64)

    # Mild penalty for leaving a very large residual (fragmentation avoidance).
    # This helps avoid filling mostly-empty bins when tighter bins exist.
    score -= 0.15 * residual_after * residual_after / 100.0

    # Strong bonus for exact fit.
    score += 250.0 * (residual_after == 0)

    # Slight preference for fuller bins among near-ties helps reduce waste.
    score += 0.01 * (100 - bins)

    return score
