"""Online bin packing: hybrid best-fit with fullness bias.

The priority ranks bins primarily by how tightly the item fits (best fit),
but adds a small bonus for bins that are already more full, which tends to
pack small items into partially used bins instead of opening new ones, and
a small penalty for opening a brand new bin unless the item is large.
"""
import numpy as np


def priority(item, bins):
    # remaining capacity after placing the item
    residual = bins - item  # always >= 0 since only fitting bins are shown

    # "slack-normalized" tightest fit: smaller residual is better.
    # Scale residual down so big residuals don't dominate the fullness term.
    score = -residual.astype(np.float64)

    # Fullness bonus: bins with less remaining capacity (fuller) get a boost.
    # capacity is 100, so (100 - bins) is the used amount.
    used = 100.0 - bins.astype(np.float64)
    score += 0.15 * used

    # Penalize opening fresh bins (remaining == 100) slightly, but less so
    # for large items which cannot easily share.
    fresh = (bins == 100)
    if fresh.any():
        penalty = 0.05 * item  # larger items penalize fresh bins less
        score -= fresh.astype(np.float64) * penalty

    return score
