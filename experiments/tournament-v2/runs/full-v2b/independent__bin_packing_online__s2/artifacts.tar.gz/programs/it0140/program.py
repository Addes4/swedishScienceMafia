import numpy as np


def priority(item, bins):
    """Best fit with a mild preference for non-empty bins.

    The item goes into the bin with the highest score.
    bins: remaining capacities of bins the item fits in (including unused bins at 100).
    """
    # Primary rule: prefer the tightest fit (smallest leftover after placement).
    # leftover = bins - item, so larger score means smaller leftover.
    score = -np.asarray(bins, dtype=np.int64)

    # Mildly prefer bins that are already in use over completely empty bins.
    # This helps keep the number of open bins lower and avoids spreading items too much.
    score = score.astype(np.float64)
    score += np.where(bins < 100, 0.5, 0.0)

    return score
