"""Online bin packing: tightest-fit (best fit) with a residual tie-break.

Best fit is used as the primary rule: the score decreases as the remaining
capacity after placing the item grows, so a bin that fits most tightly wins,
and completely empty bins (capacity 100) are only used when no partially
filled bin can take the item.  Among near-equal fits a slight preference is
given to bins whose residual capacity is large enough to still be useful for
a future item, which reduces the number of bins that end up with tiny
unusable gaps.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (only bins the item fits).
    """
    residual = bins - item

    # Primary: tightest fit -> smaller residual is better.
    score = -residual.astype(np.float64)

    # Secondary: mildly discourage residuals that are too small to be filled
    # again but too large to be zero (wasted space).  A residual that is
    # exactly 0 is ideal, very small residuals are slightly worse than a
    # moderately sized one.
    # Reward exact fills and useful residuals over tiny unusable gaps.
    tiny = (residual > 0) & (residual < 10)
    score[tiny] -= 2.0

    # Prefer using already-opened bins over empty ones beyond the natural
    # tightest-fit preference (empty bins have residual 100 - item).
    empty = bins == 100
    score[empty] -= 0.5

    return score
