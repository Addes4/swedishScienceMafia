"""Adaptive best-fit bin packing with reservation threshold.

Strategy:
- Keep track of the running mean item size (online estimate).
- For each item, prefer bins where placing it leaves a remainder that is
  either zero (perfect fit) or too small to be useful (< mean/2), i.e.
  "tight" placements.
- Among non-tight placements, rank ones that leave a remainder close to
  a typical small item (so the leftover can still hold something),
  favoring fuller bins.
- Tie-break toward lower bin index (default behavior via stable scoring).

This is essentially best-fit with a slack-aware preference that avoids
creating medium-sized unusable leftovers, reducing fragmentation for
Weibull-shaped item distributions (mean ~40).
"""
import numpy as np

# Module-level state for running statistics.
_count = 0
_sum = 0.0


def priority(item, bins):
    global _count, _sum
    _count += 1
    _sum += item
    mean = _sum / _count

    remain = bins - item  # remainder after placing item

    # Score: higher is better.
    # Primary: prefer perfect or near-perfect fits (small nonnegative remainder).
    # Secondary: prefer leaving a remainder that is either tiny (wasted is fine
    #   since it's small) or large enough to hold a typical item.
    # Tertiary: prefer fuller bins (lower bin index handled by argsort stability).

    # small remainder (< threshold) is good: tight packing.
    thresh = max(1.0, mean * 0.5)

    # Base score: tighter fits get higher scores.
    # Use negative remainder so smaller remainder => higher score.
    score = -remain.astype(np.float64)

    # Bonus for leaving a remainder big enough to be reusable later,
    # which encourages filling up partially used bins.
    reusable = (remain >= mean * 0.75) & (remain > 0)
    score = score + reusable * 2.0

    # Strong bonus for leaving essentially nothing or a tiny scrap.
    tiny = remain < thresh
    score = score + tiny * 1.5

    # Perfect fit gets the largest bonus.
    perfect = remain == 0
    score = score + perfect * 3.0

    return score
