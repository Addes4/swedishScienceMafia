"""Online bin packing: best-fit with penalties for tiny leftover fragments and exact fits."""
import numpy as np


def priority(item, bins):
    """Score bins: prefer exact fit, then tight fit, avoid leaving fragments below a threshold."""
    rem_after = bins - item
    # Base: tightest fit (negative remaining after placement).
    score = -rem_after.astype(np.float64)

    # Strong bonus for exact fit.
    score += (rem_after == 0) * 1000.0

    # Penalize creating tiny unusable leftovers.
    # Items range 1..100; fragments smaller than ~10 are usually hard to reuse.
    small = (rem_after > 0) & (rem_after < 10)
    score -= small * 80.0

    # Slight preference for more-filled bins over empty ones beyond the base rule.
    # (Already handled by -rem_after, but emphasize filling near-full bins.)
    return score
