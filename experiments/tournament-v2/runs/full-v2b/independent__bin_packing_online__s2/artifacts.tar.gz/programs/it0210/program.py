import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.max_item = 0
        # histogram of observed item sizes to estimate distribution
        self.hist = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.count += 1
        self.total += item
        self.hist[item] += 1.0
        if item > self.max_item:
            self.max_item = item

    def mean(self):
        if self.count == 0:
            return 40.0
        return self.total / self.count


_STATE = _State()


def priority(item, bins):
    """Hybrid best-fit / reserve-aware rule.

    Score = -(remaining - item)  (best fit), but for large-empty bins we modify
    the effective weight so that we do not waste a big fresh bin on a small item
    when better-fitting used bins exist. Simultaneously we slightly prefer
    filling bins close to full.
    """
    _STATE.update(item)

    # remaining capacity after placing item
    rem_after = bins - item  # all >= 0 since bins only contains fitting bins

    # Best-fit component: prefer smallest leftover. Score higher for smaller rem_after.
    # Use negative rem so higher is better.
    score = -rem_after.astype(np.float64)

    # Reserve-aware adjustment: discourage putting small items into near-empty
    # (large) bins when there are tighter bins. We look at original remaining cap.
    # Bins with remaining == 100 are unused/fresh.
    mean = _STATE.mean()

    # If item is small relative to mean, penalize using very empty bins,
    # reserving them for future large items.
    if item < mean:
        # penalty grows for emptier bins; stronger for smaller items
        smallness = (mean - item) / (mean + 1e-9)
        # extra penalty on fresh/empty bins
        empty_mask = (bins >= 100)
        score -= smallness * 2.0 * empty_mask.astype(np.float64)
        # also mildly penalize large remaining capacities (keeping them free)
        score -= smallness * 0.05 * bins.astype(np.float64)

    # Slight preference to fill bins that are already substantially used
    # (encourage consolidation), reduce number of partially-filled bins.
    used = 100.0 - bins.astype(np.float64)
    score += 0.01 * used

    return score
