"""Online bin packing: adaptive best-fit with a fresh-bin penalty.

Strategy
--------
The item is placed into the bin that yields the *tightest* fit, i.e. the bin
with the smallest remaining capacity after insertion.  Ties (which happen when
several bins have the same remaining capacity, e.g. the many unused bins of
capacity 100) go to the first bin in the array as required.

A small, state-tracking penalty is applied to unused bins (remaining capacity
exactly 100) so that items preferentially fill partially used bins instead of
opening a brand new one.  This reduces the number of simultaneously open bins
in the early phase and tends to save bins overall.  The penalty is a tiny
fraction of a capacity unit, so it only breaks the tie among equally tight
fits and never overrides a genuinely tighter real bin.
"""

import numpy as np

# State kept between calls (never sees future items).
_state = {
    "n_items": 0,
    "n_open_bins": 0,   # bins that are no longer completely empty
    "penalty": 0.5,     # initial fresh-bin penalty (in capacity units, < 1)
}


def priority(item, bins):
    """Score every bin; the item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    st = _state

    # Remaining capacity after inserting the item.  Smaller is a tighter fit.
    after = bins - item

    # Base score: negative remaining capacity => highest score = tightest bin.
    score = -after.astype(np.float64)

    # Fresh-bin penalty: discourage using completely empty bins when a
    # partially filled bin offers an equally tight (or nearly as tight) fit.
    # Only applies to unused bins.  The penalty is < 1 capacity unit so it
    # cannot change the choice between bins whose fits genuinely differ.
    empty = (bins == 100)
    if empty.any() and not empty.all():
        score[empty] -= st["penalty"]

    # Lightly adapt the penalty: as the instance progresses and many bins are
    # open, slightly *reduce* the bias toward squeezing into full bins, since
    # the tightest-fit already dominates; keep it small and stable.
    if st["n_items"] < 50:
        st["penalty"] = 0.5
    else:
        # modest decay toward a small but nonzero value
        st["penalty"] = max(0.15, st["penalty"] * 0.999)

    st["n_items"] += 1

    return score
