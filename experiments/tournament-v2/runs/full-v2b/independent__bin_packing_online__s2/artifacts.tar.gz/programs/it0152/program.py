import numpy as np


def priority(item, bins):
    """Best fit with a slight preference for already-used bins on near-ties."""
    # Primary score: prefer the smallest remaining capacity that still fits.
    # Secondary tie-break: prefer non-empty bins to avoid opening new bins when
    # capacities are equal, while still respecting the primary best-fit ordering.
    # bins == 100 marks unused bins in this interface.
    tightness = -(bins - item)

    # Tiny bonus for used bins, small enough not to override meaningful
    # differences in remaining capacity, but enough to settle exact ties.
    used_bonus = np.where(bins < 100, 1e-6, 0.0)

    return tightness + used_bonus
