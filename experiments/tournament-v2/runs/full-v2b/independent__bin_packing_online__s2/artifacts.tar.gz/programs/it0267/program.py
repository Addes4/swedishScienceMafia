import numpy as np

# Keep minimal state so behavior can adapt slightly without overfitting.
_state = {
    "n": 0,
    "sum": 0.0,
    "mean": 40.0,
}


def priority(item, bins):
    """Rank bins for online bin packing: mostly best-fit plus a mild residual preference."""
    bins = np.asarray(bins, dtype=np.int64)

    # Update running statistics (cheap, bounded, no future information).
    _state["n"] += 1
    _state["sum"] += float(item)
    if _state["n"] & 63 == 0:
        _state["mean"] = _state["sum"] / float(_state["n"])
    mean = _state["mean"]

    # Remaining capacity after placing the item.
    rem = bins - item

    # Best-fit: prefer smallest positive residual.
    # Add a small secondary term that favors residuals near the historical mean item size,
    # because such residuals are more likely to be filled by future typical items.
    residual_score = -np.abs(rem - mean)

    # Primary sorting is by rem, secondary by usefulness of residual.
    # Since higher score wins, use a large negative rem plus a small bonus.
    return -100000.0 * rem + 0.01 * residual_score
