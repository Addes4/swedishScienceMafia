import numpy as np


def priority(item, bins):
    remaining_after = bins - item
    # Primary: best fit (smallest remaining capacity after placing).
    # Secondary: avoid opening brand new bins (capacity 100) too eagerly.
    # bins == 100 means unused; add a tiny penalty so any fitting used bin wins ties.
    return -(remaining_after) - 0.001 * (bins == 100)
