import numpy as np


def priority(item, bins):
    """
    Online bin-choice rule.

    Score bins primarily by how full they become after inserting the item
    (best fit), with a small bias against unused bins and a mild adjustment
    for the residual capacity left behind.
    """
    residual = bins - item

    # Base: strongly prefer the tightest fit (small remaining capacity).
    # Larger score means better.
    score = -residual

    # Prefer already-used bins slightly over opening a fresh one.
    # Unused bins have remaining capacity 100, hence residual == 100 - item.
    score += (bins != 100) * 0.25

    # Mild preference for residuals that are either very small or very large.
    # Medium residuals tend to be hard to fill later.
    # Use a small parabolic penalty around mid-range residuals.
    mid_penalty = -0.002 * (residual - 35.0) * (residual - 35.0)
    score += mid_penalty

    return score
