# EVOLVE-BLOCK-START
"""Hybrid best-fit / smart-fill online bin packing rule."""
import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.hist = np.zeros(101, dtype=np.float64)
        self.res_hist = np.zeros(101, dtype=np.float64)

    def update(self, item, residual):
        self.n += 1
        a = 0.995 if self.n > 100 else 0.98
        self.mean = a * self.mean + (1.0 - a) * item
        self.hist[item] += 1.0
        self.res_hist[residual] += 1.0


_S = _State()


def priority(item, bins):
    """Rank bins for the arriving item using a blend of best fit and future-fill heuristics.

    item: integer size 1..100.
    bins: numpy int64 array of remaining capacities the item fits in, in bin order.
    """
    bins = np.asarray(bins, dtype=np.int64)
    residual = bins - item
    res_f = residual.astype(np.float64)

    # Base: prefer tightest fit (smallest residual). Strong but not absolute.
    score = -res_f

    # Discourage leaving a tiny residual that few future items can use,
    # but only mildly, so best-fit dominance is preserved.
    tiny = (res_f > 0) & (res_f < 12)
    if np.any(tiny):
        score[tiny] -= 0.75 * (12.0 - res_f[tiny])

    # Encourage residuals that are historically common for arriving items,
    # i.e. values likely to be filled later by a typical item size.
    # Estimate from observed item sizes and the current mean.
    mu = _S.mean
    # Gaussian-like desirability: residuals near typical upcoming items are good.
    desir = np.exp(-((res_f - mu) ** 2) / (2.0 * (0.55 * mu) ** 2 + 1.0))
    score += 1.25 * desir

    # If the item fits a used bin with very little left over, prefer it.
    used_tight = (res_f > 0) & (res_f <= max(2.0, 0.12 * item))
    if np.any(used_tight):
        score[used_tight] += 3.0

    # Slightly prefer putting items into already-opened bins to avoid new bins,
    # but only when the resulting residual remains reasonably large.
    opened = res_f < (100 - item - 1)  # bins that were already used
    if np.any(opened):
        score[opened] += 0.35

    # Avoid opening a new bin for very small items when a used bin can take it
    # without becoming nearly full.
    if item <= 25:
        fresh = res_f >= (100 - item)
        if np.any(fresh):
            score[fresh] -= 1.0

    # Deterministic subtle tie-break: prefer lower residual on exact ties.
    score += (-res_f) * 1e-9

    return score
# EVOLVE-BLOCK-END
