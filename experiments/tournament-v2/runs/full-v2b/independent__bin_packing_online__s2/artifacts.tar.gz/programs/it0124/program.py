import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    A best-fit rule: prefer the bin whose remaining capacity is closest to the item size.
    When several bins would have the same leftover capacity, prefer an already-used bin
    (remaining capacity < 100) over a fresh bin, and otherwise keep the earliest bin.
    """
    leftover = bins - item

    # Primary: minimize leftover capacity = prefer tightest fit.
    score = -leftover.astype(np.float64)

    # Secondary tie-breaker: among equal leftovers, prefer used bins over empty ones.
    # A tiny bonus for used bins only affects exact ties after the main score.
    used = bins < 100
    score += used * 1e-6

    return score
