import numpy as np


def priority(item, bins):
    residual = bins - item
    # Primary: best fit (smallest residual after placement = tightest fit).
    # Bins with residual == 0 get the highest score.
    score = -residual.astype(np.float64)

    # Tie-break / consolidation: among otherwise equal picks, prefer bins that
    # are not completely empty (residual < 100 means bin already has items).
    # Give a tiny bonus to non-empty bins so that filling up used bins is
    # preferred over opening a fresh one when fits are equivalent.
    non_empty_bonus = np.where(residual < 100 - item, 0.01, 0.0)

    return score + non_empty_bonus
