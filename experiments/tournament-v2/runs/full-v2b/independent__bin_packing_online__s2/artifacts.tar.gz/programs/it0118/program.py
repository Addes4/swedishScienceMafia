import numpy as np

class _State:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        self.sum_sq = 0.0
        self.large_threshold = 70.0
        self.reserve_penalty = 0.0

_state = _State()


def priority(item, bins):
    """
    Bin-choice rule for online bin packing.

    Uses tightest-fit (best-fit) as the core rule, but slightly penalizes leaving
    a bin with a very small residual capacity when the item is large, which helps
    preserve usable space for future large items.  The penalty is kept small and
    is adapted online so it only mildly nudges choices.
    """
    s = _state
    s.n += 1
    s.sum += item
    s.sum_sq += item * item

    # Adapt threshold for "large" items toward upper quantile of observed sizes.
    if s.n >= 20:
        mean = s.sum / s.n
        var = max(0.0, s.sum_sq / s.n - mean * mean)
        std = var ** 0.5
        # Roughly 80th percentile under a moderately skewed distribution.
        s.large_threshold = mean + 0.85 * std
        # Keep it in a sane range.
        if s.large_threshold < 55.0:
            s.large_threshold = 55.0
        elif s.large_threshold > 90.0:
            s.large_threshold = 90.0

    # Penalize bins that would be left with tiny residual space; this mildly
    # discourages fragmenting capacity into unusable slivers.
    residual = bins - item
    small_residual_penalty = np.where(residual < 15, (15 - residual) * 0.002, 0.0)

    # Slight preference against filling a bin completely when the item is large,
    # unless it lands exactly, to preserve a bin that can still take small items.
    exact_penalty = 0.0
    if item >= s.large_threshold:
        exact_penalty = np.where(residual == 0, 0.5, 0.0)
    else:
        # For small/medium items, exact fits are fine and desirable.
        exact_penalty = np.where(residual == 0, -0.2, 0.0)

    # Base: best fit (higher score for smaller remaining capacity).
    score = -residual.astype(np.float64)

    # Prefer larger bins (more remaining capacity) slightly for large items, so
    # small bins remain available for small items.
    if item >= s.large_threshold:
        score += 0.01 * bins.astype(np.float64)

    score -= small_residual_penalty
    score -= exact_penalty

    return score
