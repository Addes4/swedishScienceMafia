import numpy as np


def priority(item, bins):
    """Best-fit with a mild anti-fragmentation bias against fresh bins."""
    leftover = bins - item

    # Best fit: smaller leftover is better, so score is -leftover.
    score = -leftover.astype(np.float64)

    # Slightly discourage opening brand-new bins unless the item is large.
    # Remaining capacity 100 means the bin is unused. If item is small,
    # prefer packing it into an existing partially filled bin.
    empty_mask = bins == 100
    if item < 60:
        score[empty_mask] -= 2.0
    elif item < 85:
        score[empty_mask] -= 1.0

    return score
