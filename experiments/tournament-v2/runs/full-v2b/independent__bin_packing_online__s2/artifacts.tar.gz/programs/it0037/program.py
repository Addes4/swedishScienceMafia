import numpy as np


def priority(item, bins):
    """Score bins for best-fit packing with a mild anti-new-bin bias for small items.

    The item goes into the highest-scoring bin; ties go to the first bin.
    We prefer the bin with the least remaining capacity that still fits the item
    (classic best fit). For small/medium items we slightly prefer bins that are
    already partly filled over completely empty bins, which tends to reduce the
    number of bins opened for the common small arrivals.
    """
    # Best fit: smaller remaining capacity after placement is better.
    # scores = -(bins - item) = item - bins.
    scores = item - bins

    # Mild preference against opening brand-new empty bins for small items.
    # Empty bins have remaining capacity 100 -> base score = item - 100.
    # For items well below a typical bin complement (~40), avoid fresh bins.
    if item <= 50:
        # Add a tiny penalty to empty bins only, keeping ordering otherwise strict.
        # This preserves best-fit ordering among non-empty bins.
        empty_mask = bins == 100
        if empty_mask.any():
            scores = scores.astype(np.float64, copy=True)
            scores[empty_mask] -= 1e-3

    return scores
