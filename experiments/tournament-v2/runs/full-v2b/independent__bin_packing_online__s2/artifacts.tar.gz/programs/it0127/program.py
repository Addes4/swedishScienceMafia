import numpy as np


def priority(item, bins):
    """Best fit with slight tie-breaking structure.

    Return -(remaining capacity) so the item goes to the fullest bin it fits in.
    """
    return -bins
