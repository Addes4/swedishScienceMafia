"""Online bin packing heuristic: smoothed best-fit with fragment-aware tie-breaking."""
import numpy as np


def priority(item, bins):
    """Score bins by closeness of remaining capacity to the item size.

    Bins are ranked primarily by the leftover space (bins - item), which is a
    best-fit rule. To break ties and reduce fragmentation, bins that are more
    full (smaller remaining capacity) receive a slight bonus. The item goes to
    the highest-scoring bin (first on ties).
    """
    leftover = bins - item
    # Primary: prefer smallest non-negative leftover (tightest fit).
    # Secondary: prefer the most-filled bin (smallest remaining capacity),
    # encoded as a small additive term that only matters within equal leftover.
    # bins are int64 with values 1..100 (item fits), leftover >= 0.
    score = -leftover * 1000.0 - bins
    return score
