"""Hybrid best-fit bin packing priority rule.

Strategy:
- Track recent item statistics to adapt a "tolerance" for near-best fits.
- Strongly prefer bins where the item fits almost perfectly (minimal leftover).
- Among close candidates, prefer the bin that leaves the smallest positive remainder,
  which keeps bins tightly packed.
- Encourage using existing bins over opening new ones by penalizing leftover==100
  slightly, but only when a reasonable alternative exists.
"""
import numpy as np

_state = {"n": 0, "sum": 0.0, "max_seen": 0}


def priority(item, bins):
    # Update running statistics (cheap, bounded work).
    _state["n"] += 1
    _state["sum"] += float(item)
    if item > _state["max_seen"]:
        _state["max_seen"] = item

    b = bins.astype(np.float64)
    leftover = b - float(item)  # guaranteed >= 0

    # Base score: tighter fit (smaller leftover) is better.
    score = -leftover

    # Bonus for exact fits, scaled to dominate.
    exact = (leftover == 0.0)
    score = score + exact * 50.0

    # Small penalty for opening brand-new bins (leftover == 100 - item means untouched).
    # Prefer reusing existing partially-filled bins when fits are comparable.
    untouched = (b == 100.0)
    score = score - untouched * 0.75

    # Extra preference for filling bins that would otherwise be nearly wasted:
    # if leftover after placement is tiny (<= 10), nudge up.
    tiny = (leftover > 0.0) & (leftover <= 10.0)
    score = score + tiny * 0.5

    # Avoid leaving a remainder that blocks mid-size items (remainder in (item, item+30]).
    bad_gap = (leftover > 0.0) & (leftover <= 30.0)
    score = score - bad_gap * 0.25

    return score
