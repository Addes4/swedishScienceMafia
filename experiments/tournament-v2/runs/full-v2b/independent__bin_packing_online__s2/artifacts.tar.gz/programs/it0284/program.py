import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum = 0
        self.hist = np.zeros(101, dtype=np.float64)

    def update(self, item):
        self.n += 1
        self.sum += item
        if 0 <= item <= 100:
            self.hist[item] += 1.0


_S = _State()


def priority(item, bins):
    """Hybrid best-fit that discourages opening brand-new bins too eagerly."""
    _S.update(item)

    # Tight fit score: larger is better when remaining capacity is just above item.
    # -(bins - item) ranks tightest fit first.
    tight = -(bins - item)

    # Penalize fully empty bins slightly so that partially filled bins are used first.
    # This helps avoid consuming fresh bins when an existing bin can absorb the item.
    empty_penalty = np.where(bins == 100, 0.25, 0.0)

    # If many bins are nearly empty, stronger preference to consolidate.
    # If the arriving items are small, opening new bins is less harmful.
    avg = (_S.sum / _S.n) if _S.n else 40.0
    scale = 0.5 * (40.0 / max(avg, 1.0))

    # Also slightly prefer bins that become less fragmented:
    # after placement, remaining capacity closer to a typical future item is good.
    target = min(100.0, max(1.0, avg))
    post = bins - item
    frag = -np.abs(post - target) * 0.01

    score = tight - empty_penalty * scale + frag
    return score
