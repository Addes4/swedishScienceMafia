import numpy as np


def priority(item, bins):
    """Rank bins by fit; prefer tighter fits while mildly discouraging tiny residuals."""
    # Best fit: smaller residual capacity is better.
    residual = bins - item

    # Slight preference for residuals that are not too tiny and not too large:
    # exact fits are great, but after that avoid leaving very small unusable gaps.
    # This is a deterministic, instance-independent shaping.
    gap_cost = residual.astype(np.float64)

    # Bonus for exact fits.
    exact = (residual == 0)
    score = -gap_cost
    score[exact] += 0.25

    # Penalize large open bins very slightly so we tend to fill existing bins.
    score -= 0.001 * (bins == 100)

    return score
