"""Online bin packing: best fit with a mild preference against opening new bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the bin that leaves the least remaining capacity after placing.
    score = -(bins - item)

    # Mildly discourage using a completely empty bin if any used bin fits similarly well.
    # This helps avoid unnecessary new bins without changing the tight-fit ordering much.
    score = score.astype(np.float64, copy=False)
    score[bins == 100] -= 1e-6

    return score
