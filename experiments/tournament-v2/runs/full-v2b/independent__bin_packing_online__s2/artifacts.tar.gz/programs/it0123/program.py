"""Online bin packing: best-fit with strong preference against unused bins.

The rule is simple but effective for the stated distribution: among bins that are not
empty, put the item in the bin it fits most tightly (largest remaining capacity ≤ item
plus slack).  Empty bins (remaining capacity 100) get a very low priority, so a new bin is
opened only when no partially filled bin can fit the item.  This is the classic Best Fit
heuristic, expressed as a priority score.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # bins are remaining capacities of bins the item fits in (rem >= item or rem == 100).
    # Prefer bins that are already in use (rem < 100) and fit tightly:
    # score = -(rem - item) for used bins, but subtract a large constant for empty bins.
    used = bins < 100
    score = -(bins - item).astype(np.float64)
    score[~used] -= 1e9  # strongly discourage opening a new bin
    return score
