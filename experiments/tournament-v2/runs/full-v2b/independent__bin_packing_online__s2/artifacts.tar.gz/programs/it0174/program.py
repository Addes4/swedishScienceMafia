"""Best fit with a small usage-based tie-break for online bin packing."""

import numpy as np


def priority(item, bins):
    """Rank bins by tightest fit; break ties toward bins already used."""
    remaining_after = bins - item
    # Primary: smaller leftover is better, so use negative leftover.
    scores = -remaining_after.astype(np.float64)

    # Secondary: among equal leftovers, prefer bins with smaller index or past use?
    # We cannot know past use from bins alone, but unused bins have capacity 100.
    # Prefer not to open a new bin if another bin fits equally well.
    # This tiny bias favors currently fuller bins, which are already open.
    scores += (100 - bins) * 1e-6

    return scores
