import numpy as np


def priority(item, bins):
    """Score bins for the online bin packing decision.

    The harness has already filtered to bins where the item fits, so all
    remaining capacities are >= item.  We want to avoid opening new bins
    while still packing tightly, so prefer smaller remaining capacity
    (best fit), with a slight bias against completely empty bins.
    """
    # Best-fit score: larger for tighter fits.
    score = -bins

    # Mildly discourage brand-new empty bins.  With 100-capacity bins,
    # an empty bin has remaining capacity exactly 100.  This keeps the
    # item from needlessly opening a new bin when a suitable partially
    # filled bin exists, but still allows it when necessary.
    score = score.astype(np.float64)
    score[bins == 100] -= 1e-6

    return score
