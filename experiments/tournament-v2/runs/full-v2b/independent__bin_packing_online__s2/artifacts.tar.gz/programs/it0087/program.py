import numpy as np


def priority(item, bins):
    # Prefer tight fits (best-fit), but avoid opening new bins too eagerly.
    # Score higher for smaller leftover after placing the item.
    # Add a slight bonus for already-used bins over untouched bins (cap == 100),
    # unless the item is large enough that a fresh bin is efficient.
    leftover = bins - item

    # Base: negative leftover => tighter fit is better.
    score = -(leftover.astype(np.float64))

    # Penalize using a completely empty bin (remaining capacity 100) more strongly
    # for small/medium items, so we fill up existing bins first.
    # For large items, using an empty bin is often necessary and fine.
    empty_mask = (bins == 100)
    if empty_mask.any():
        # Penalty magnitude depends on item size: small items avoid empty bins.
        # Cap so it never dominates exact fit ordering among used bins.
        penalty = 0.5 + (100 - item) * 0.02
        # But if item is large (> 60), reduce penalty since fresh bin is reasonable.
        if item > 60:
            penalty *= 0.2
        score[empty_mask] -= penalty

    return score
