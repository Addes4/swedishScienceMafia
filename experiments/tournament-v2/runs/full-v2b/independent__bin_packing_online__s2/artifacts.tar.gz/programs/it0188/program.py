"""Best-fit online bin packing rule.

The item is placed into the bin with the smallest remaining capacity that can
still accommodate it.  Ties are broken by preferring the earliest bin index.
"""

import numpy as np


def priority(item, bins):
    # Highest score -> chosen bin.  Best fit wants the smallest remaining
    # capacity among bins that can hold the item.  Negating the remaining
    # capacity means tighter bins get higher scores.
    #
    # The tiny index-based term resolves ties in favour of lower indices
    # (the harness would do this anyway, but making it explicit is harmless).
    n = bins.shape[0]
    idx = np.arange(n, dtype=np.float64)
    return -(bins.astype(np.float64)) - idx * 1e-9
