"""Online bin packing: capacity-window best fit with tie-breakers.

Idea: pure best fit packs small items into the tightest bin, which tends to
break up bins that could have been filled by a later medium item.  Instead,
for each arriving item we rank bins by how close their remaining capacity is
to an ideal target zone, then, within that zone, by tightness of fit.

The target zone is chosen from the item size: small items prefer bins that
still have plenty of room (so they don't consume the last slot of a nearly
full bin), medium items prefer closing bins, and large items prefer a bin
that will be left with a small remainder.

All decisions use only information available at call time, so this is a
legitimate online heuristic.
"""
import numpy as np


def priority(item, bins):
    """Score every bin; highest score wins (ties go to first bin)."""
    b = bins.astype(np.float64)

    # --- Ideal remaining capacity target ------------------------------
    # For an item of size `item`, the ideal bin has remaining capacity
    # close to `target`.  Small items: target stays large (don't squeeze
    # into tight bins).  Large items: target should be close to item so
    # the remainder after placing is near zero.
    if item <= 25:
        target = 100.0 - item * 1.5
    elif item <= 60:
        target = item * 1.4
    else:
        target = item * 1.05

    # Clamp to legal range.
    if target < item:
        target = item
    if target > 100.0:
        target = 100.0

    # --- Distance from ideal target -----------------------------------
    dist = np.abs(b - target)

    # --- Tie-break: prefer tighter fit (smaller leftover after place) --
    leftover = b - item  # >= 0 by construction (only fitting bins shown)

    # --- Small penalty for using a completely empty bin ---------------
    # Slightly discourage consuming a fresh bin when another bin could
    # host the item, encouraging packing into already-open bins.
    empty_penalty = np.where(b >= 100.0, 0.35, 0.0)

    # --- Small bonus for filling a bin nearly completely --------------
    # (leftover < 5) closes the bin efficiently.
    close_bonus = np.where(leftover < 5.0, 0.25, 0.0)

    score = -dist - 0.05 * leftover - empty_penalty + close_bonus
    return score
