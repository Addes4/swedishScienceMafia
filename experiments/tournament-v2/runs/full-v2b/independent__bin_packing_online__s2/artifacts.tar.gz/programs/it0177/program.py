import numpy as np

def priority(item, bins):
    # Best-fit style: prefer bins where the item fits tightly.
    # Penalize using empty bins (remaining capacity == 100) to delay opening new bins.
    # Add a small term to encourage using bins whose leftover capacity is small,
    # which tends to pack better for Weibull-like distributions.
    rem = bins
    score = -(rem - item).astype(np.float64)
    # Strong penalty for opening a new bin: only do it if no reasonable fit exists.
    score[rem == 100] -= 0.5
    return score
