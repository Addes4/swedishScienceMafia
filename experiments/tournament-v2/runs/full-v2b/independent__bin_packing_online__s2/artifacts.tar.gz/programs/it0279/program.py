import numpy as np

def priority(item, bins):
    # Prefer bins where the remaining capacity after insertion is smallest
    # (best fit), but mildly favor already-used bins so we don't open new ones
    # when a reasonably good fit is available.
    remaining_after = bins - item
    # Score: lower remaining_after is better (we negate it).
    # Add a small bonus for used bins (bins with capacity < 100) to encourage
    # filling existing bins before opening new ones.
    used_bonus = np.where(bins < 100, 1.0, 0.0)
    # To avoid opening a new bin when a used bin can take the item with
    # decent tightness, we can slightly penalize unused bins.
    # But the main driver remains best-fit.
    return -remaining_after + 0.01 * used_bonus
