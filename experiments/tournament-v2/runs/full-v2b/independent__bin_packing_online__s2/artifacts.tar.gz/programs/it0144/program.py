"""Stateful best-fit bin-choice rule for online bin packing.

Core idea: place each item into the bin where it fits most tightly (best fit),
which is a strong online heuristic for minimizing bins. Ties are broken in favor
of already-used bins (to avoid opening unused capacity needlessly) and then by
bin order. To further reduce fragmentation, we track the last few item sizes and
nudge scores slightly so that bins whose residual capacities match common recent
item sizes are preferred.
"""

import numpy as np

_state = {
    "recent": [],
    "max_recent": 8,
}


def priority(item, bins):
    """Return a score for every bin; item goes to the highest score (first on ties)."""
    recent = _state["recent"]

    # Base: tightest fit. Larger score = better fit.
    scores = -(bins - item).astype(np.float64)

    # Prefer bins that are already partially used over completely empty bins
    # when capacities are otherwise similar, to avoid opening new bins early.
    # Unused bins have capacity exactly 100; used bins normally have < 100.
    # Give a small bonus to bins with residual capacity in (0, 100).
    unused = bins == 100
    scores += np.where(unused, 0.0, 0.25)

    # Exact-fit bonus: strongly prefer a bin whose residual exactly equals item.
    scores += np.where(bins == item, 1.0, 0.0)

    # Fragmentation avoidance: slightly prefer residual capacities that match
    # frequent recent item sizes, so leftover space is likely usable soon.
    if recent:
        hist = {}
        for r in recent:
            hist[r] = hist.get(r, 0) + 1
        bonus = np.zeros_like(scores, dtype=np.float64)
        cap = bins.astype(np.int64)
        for r, c in hist.items():
            bonus += np.where(cap == r, 0.05 * c, 0.0)
        scores += bonus

    # Deterministic, tiny index-based tie-break: earlier bins get slightly
    # higher score on exact ties, preserving stable behavior.
    scores += np.linspace(0.0, 0.001, num=len(bins), endpoint=False)

    # Update recent-item memory for future calls.
    recent.append(int(item))
    if len(recent) > _state["max_recent"]:
        del recent[0]

    return scores
