# EVOLVE-BLOCK-START
"""Best fit: put the item in the tightest bin it fits into."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Highest priority to the smallest remaining capacity (tightest fit),
    # but only among bins where the item fits.  The harness already filters
    # to fitting bins, so we simply negate remaining capacity.
    return -bins
# EVOLVE-BLOCK-END
