"""Best-fit with adaptive tie handling.

Put each item into the fitting bin with the least remaining capacity after
placement (classic best fit). Ties are broken by a mild preference for bins
that already contain items, avoiding unnecessary opening of fresh bins.
"""
import numpy as np


def priority(item, bins):
    """Score bins for an arriving item; highest score wins (first on ties)."""
    # Best fit: smallest residual capacity after placing item.
    residual = bins - item

    # Prefer used bins slightly over unused (capacity exactly 100) ones when
    # residual capacities are close, to reduce the number of opened bins.
    used_penalty = np.where(bins >= 100, 1.0, 0.0)

    return -(residual.astype(np.float64)) - 0.5 * used_penalty
