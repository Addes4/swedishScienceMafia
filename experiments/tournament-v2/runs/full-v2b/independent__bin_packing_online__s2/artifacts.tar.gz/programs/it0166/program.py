import numpy as np


class _State:
    def __init__(self):
        self.step = 0
        self.opened = 0
        self.cnt = 0
        self.sizes = []
        self.rem = {}
        self.total_open = 0


_state = _State()


def priority(item, bins):
    st = _state
    st.step += 1

    n = len(bins)
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # Small state: estimate how full currently live bins are.
    # bins includes unused bins with remaining 100, so n is total bins.
    # Prefer bins that already have some content, but do not overfill perfectly.
    rem = bins.astype(np.float64)

    # Main score: best fit (smallest remaining capacity that still fits).
    best_fit = -(rem - item)

    # Slight preference against completely empty bins to reduce premature opening
    # when other reasonable fits exist.
    empty_penalty = np.where(rem >= 100.0, -0.75, 0.0)

    # Prefer residual capacities around 25-60 over both tiny and huge residuals,
    # because size-40-ish items pack well into such gaps.
    residual = rem - item
    residual_pref = np.zeros_like(rem)
    # Continuous preference for leaving a useful gap.
    # Peak around leaving 35 capacity, mild preference for leaving 20..55.
    residual_pref += 1.25 * np.exp(-((residual - 35.0) / 28.0) ** 2)

    # Avoid bins where the item would leave a very small unusable remainder,
    # except when that remainder is exactly 0 (perfect fill is good).
    tiny = (residual > 0) & (residual < 12)
    residual_pref += np.where(tiny, -1.1, 0.0)

    perfect = residual == 0
    residual_pref += np.where(perfect, 3.0, 0.0)

    # Prefer larger remaining capacity among near-ties to keep many options later,
    # but only very slightly.
    spacious = 0.015 * (rem - item)

    score = best_fit + empty_penalty + residual_pref + spacious

    # Deterministic tie handling: harness picks first max, so add tiny index-based
    # epsilon to make behavior stable but not rely on hidden ordering.
    idx = np.arange(n, dtype=np.float64)
    score -= 1e-8 * idx

    return score
