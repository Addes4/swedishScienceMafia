import numpy as np

_STATE = {
    "n": 0.0,
    "sum": 0.0,
    "sum2": 0.0,
    "recent": [],
}


def priority(item, bins):
    st = _STATE
    st["n"] += 1.0
    st["sum"] += item
    st["sum2"] += item * item

    n = st["n"]
    mean = st["sum"] / n
    var = max(0.0, st["sum2"] / n - mean * mean)
    sd = var ** 0.5

    # Track a short window to estimate current local mean.
    rec = st["recent"]
    rec.append(item)
    if len(rec) > 64:
        del rec[0]
    local_mean = sum(rec) / len(rec)

    # Slight adjustment: when recent items are smaller than average,
    # prefer tighter fits even more; when larger, spread out slightly.
    adapt = (mean - local_mean) / (sd + 1.0)
    if adapt > 0.25:
        adapt = 0.25
    elif adapt < -0.25:
        adapt = -0.25

    rem = bins.astype(np.float64)
    load = 100.0 - rem

    # Best-fit: leftover after placing item, lower is tighter.
    left = rem - item

    # Primary score: prefer small leftovers, with a tiny bonus for fuller bins.
    score = -left + 0.001 * load

    # Slight adaptive tie-breaking: avoid placing into an almost-full bin
    # if adaptation suggests items are currently small (keep those for later).
    # Conversely, if items are large, fill bins a bit more aggressively.
    fullness = load / 100.0
    score += adaptive_factor(adapt) * fullness

    return score


def adaptive_factor(adapt):
    # map [-0.25, 0.25] into a small coefficient
    return -0.02 * adapt
