"""Online bin packing: adaptive best-fit with residual-space shaping.

Strategy:
- Prefer bins where the item fits most tightly (classic best fit).
- Add a small bonus for bins whose remaining capacity after placing the item
  falls into "good" residual categories (0, small, or matching typical item sizes),
  to reduce fragmentation over time.
- Use an online exponential moving average of item sizes to slightly penalize
  leaving capacities that are much smaller than typical future items (those bins
  would become hard to fill efficiently).
"""

import numpy as np

_state = {
    "mean_item": 40.0,
    "count": 0,
    "alpha": 0.02,
}

def priority(item, bins):
    b = np.asarray(bins, dtype=np.int64)

    # Update running mean estimate of item sizes (online, no future info).
    _state["count"] += 1
    n = _state["count"]
    a = 1.0 / min(n, 50.0)  # start faster, stabilize
    _state["mean_item"] = (1.0 - a) * _state["mean_item"] + a * float(item)
    mean_item = _state["mean_item"]

    residual = b - item  # remaining capacity after placing item

    # Base: best fit -> strongly prefer small residual (tight fit).
    # Use a nonlinear transform so exact fit dominates.
    score = -residual.astype(np.float64)

    # Bonus for exact fit and near-exact fits.
    # Exact fit (residual == 0) gets a large bonus.
    score += np.where(residual == 0, 50.0, 0.0)
    # Very tight fits get a moderate bonus.
    score += np.where((residual > 0) & (residual <= 2), 5.0, 0.0)

    # Mild penalty for leaving a small residual that is likely too small
    # to be useful for future average items, but not exactly zero.
    # If residual is positive but much less than typical item size,
    # that bin becomes somewhat "wasted"; still better than large residual.
    small_thresh = 0.25 * mean_item
    penalty = np.where((residual > 0) & (residual < small_thresh),
                       -0.5 * (small_thresh - residual), 0.0)
    score += penalty

    # Tiny bonus to keep a few bins near full (small residual) rather than
    # spreading items: already captured by -residual.

    # Slight preference for placing into bin index order when scores tie
    # (harness handles ties, but make it explicit with index-based epsilon).
    # This encourages filling earlier bins first, which helps bin count.
    idx = np.arange(b.size, dtype=np.float64)
    score += -1e-6 * idx

    # Ensure no NaNs.
    score = np.nan_to_num(score, nan=-1e9, posinf=1e9, neginf=-1e9)

    return score
