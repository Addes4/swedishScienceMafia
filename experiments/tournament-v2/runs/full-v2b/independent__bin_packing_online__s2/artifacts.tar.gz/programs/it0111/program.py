import numpy as np


def priority(item, bins):
    """Score bins for online bin packing.

    Highest score wins; ties go to the first bin.
    The rule is primarily best-fit, with small anti-fragmentation adjustments:
    - Prefer residual capacities that are small but not impossible to reuse.
    - Prefer non-empty bins over brand-new bins when fit quality is similar.
    """
    residual = bins - item

    # Base: best fit prefers the smallest non-negative residual.
    # Use a smooth score instead of a sharp inverse to avoid overreacting to tiny differences.
    score = -residual.astype(np.float64)

    # Mild preference against opening fresh bins if an existing bin fits comparably well.
    # New/unused bins have remaining capacity 100 before choosing.
    is_unused = (bins == 100)
    score[is_unused] -= 0.5

    # Slight tendency to avoid leaving awkward medium residuals (e.g. 40-70),
    # because the item distribution has mean around 40 and such gaps may be hard to fill.
    medium_gap = (residual >= 40) & (residual <= 70)
    score[medium_gap] -= 0.25

    # Prefer very tight fits a bit more strongly.
    tight = residual <= 10
    score[tight] += 0.25

    return score
