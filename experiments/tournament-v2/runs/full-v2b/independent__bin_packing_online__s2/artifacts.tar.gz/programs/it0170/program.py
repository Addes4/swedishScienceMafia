import numpy as np

_STATE = {
    "seen": {},
    "total": 0,
}

def priority(item, bins):
    # Update simple residual statistics on arrival.
    # We track item sizes seen so far to bias toward bins that create
    # residuals equal to common item sizes, improving future fit.
    seen = _STATE["seen"]
    seen[item] = seen.get(item, 0) + 1
    _STATE["total"] += 1

    # Residuals after placing item in each bin.
    residual = bins - item

    # Base: best fit (smallest residual first) => score = -residual.
    # Small bonus if residual matches a frequently seen item size,
    # weighted lightly to avoid harming generalization.
    scores = -residual.astype(np.float64)

    total = _STATE["total"]
    if total > 0:
        # Frequency-based bonus for exact residual match.
        # Normalize by total to keep magnitude bounded.
        bonus = np.zeros_like(scores)
        for i, r in enumerate(residual):
            if r >= 1:
                f = seen.get(int(r), 0)
                if f:
                    bonus[i] = f / total
        scores += 0.5 * bonus

    # Strongly discourage opening new bins when a used bin can fit:
    # residual == 100 - item corresponds to a fresh bin.
    fresh = (bins == 100)
    scores[fresh] -= 0.25

    return scores
