import numpy as np


class _State:
    def __init__(self):
        # Running statistics of observed items (for adaptive thresholds).
        self.count = 0
        self.mean = 0.0
        self.m2 = 0.0
        # Histogram-ish quantile estimates: store recent items compactly.
        self.samples = np.empty(5000, dtype=np.int64)
        self.nsamp = 0


_STATE = _State()


def _update_stats(item):
    s = _STATE
    s.count += 1
    delta = item - s.mean
    s.mean += delta / s.count
    s.m2 += delta * (item - s.mean)
    if s.nsamp < len(s.samples):
        s.samples[s.nsamp] = item
        s.nsamp += 1
    else:
        # Reservoir-ish: replace a random-ish slot deterministically.
        idx = (item * 2654435761 + s.count) % len(s.samples)
        s.samples[idx] = item


def _quantile(q):
    s = _STATE
    if s.nsamp == 0:
        return 40.0
    n = s.nsamp
    k = int(q * (n - 1))
    # Use numpy partition on a view for a robust quantile.
    arr = s.samples[:n]
    try:
        return float(np.partition(arr, k)[k])
    except Exception:
        return float(np.median(arr))


def priority(item, bins):
    """Hybrid best-fit + reservation rule for online bin packing."""
    _update_stats(item)

    bins = np.asarray(bins)
    rem = bins - item  # remaining capacity after placing item

    # Some bins may not actually fit (shouldn't happen), guard anyway.
    fits = rem >= 0

    n = len(bins)
    score = np.full(n, -1e18, dtype=np.float64)
    if not np.any(fits):
        # Fallback: nothing reported as fitting; prefer largest remaining.
        return bins.astype(np.float64)

    # Adaptive thresholds based on observed item sizes.
    # A "small" future item is roughy around the 25th percentile; a "typical"
    # item around the median.  We use these to decide whether a leftover gap
    # is worth reserving.
    q25 = _quantile(0.25)
    q50 = _quantile(0.50)
    q75 = _quantile(0.75)

    # The minimum leftover we consider "useful" to keep for future items.
    min_useful = max(1.0, q25)

    idx = np.nonzero(fits)[0]
    r = rem[idx].astype(np.float64)

    # Best-fit component: strongly prefer near-zero leftover.
    bf = -r

    # Reservation component: penalize leaving a "useless" small gap that is
    # too small for most future items but wastes capacity.  Reward leaving a
    # gap that is comfortably large; modestly reward near-perfect fills.
    useless = np.where((r > 0) & (r < min_useful), 1.0, 0.0)
    useful_gap = np.where(r >= min_useful, 1.0, 0.0)

    # Prefer exact/near fits for large items, but for smaller items allow
    # reserving a good-sized gap.
    if item >= q75:
        # Large item: prioritize tight fit.
        score[idx] = bf - 3.0 * useless
    elif item <= q25:
        # Small item: avoid creating tiny useless leftovers; prefer placing
        # into a bin that already has a substantial but not perfect gap, or
        # fill a near-exact gap.
        score[idx] = bf - 4.0 * useless + 0.5 * useful_gap
    else:
        score[idx] = bf - 2.0 * useless

    # Mild bias toward already-open bins (bin index order is fixed; unused
    # bins have remaining capacity exactly 100).  Opening new bins is a last
    # resort, so give a small bonus to bins that are not full capacity.
    opened = (bins[idx] != 100).astype(np.float64)
    score[idx] += 0.25 * opened

    return score
