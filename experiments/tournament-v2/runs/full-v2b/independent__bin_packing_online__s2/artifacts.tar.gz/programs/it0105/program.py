import numpy as np


def priority(item, bins):
    # Best fit: maximize (item - bins), i.e. minimize remaining capacity after placement.
    # Add a tiny deterministic tie-breaker based on the bin index (first bins slightly preferred)
    # to encourage filling earlier bins before opening new ones.
    n = bins.shape[0]
    # Primary: tightest fit
    score = -(bins - item).astype(np.float64)
    # Secondary: prefer earlier bins slightly when fits are equal or nearly equal.
    # Use a small oscillation-free index penalty.
    idx = np.arange(n, dtype=np.float64)
    score -= 1e-6 * idx
    # Tiny bonus for bins that are not empty (remaining < 100), to postpone new-bin creation.
    score += 1e-9 * (bins < 100).astype(np.float64)
    return score
