import numpy as np


def priority(item, bins):
    """Rank bins by how tightly the item fits, preferring residuals that stay useful.

    Higher score = better bin. Ties are broken by requiring fewer "dead" residuals.
    """
    # Remaining capacity after placing the item in each bin.
    rem = bins - item

    # Primary: best fit (smallest residual first). Higher score wins.
    # Score is negative residual so the tightest fit gets the largest score.
    score = -(rem.astype(np.float64))

    # Secondary preference: among equal residuals, avoid creating residuals that are
    # too small to be useful for typical future items. Add a tiny bonus/penalty
    # based on how "wasteful" the resulting residual is.
    # Residuals in (0, 20) tend to be hard to reuse; residual==0 is perfect.
    # Use a small magnitude so it only breaks near-ties.
    small = (rem > 0) & (rem < 20)
    # Dead-space penalty: counts residual slivers.
    penalty = small.astype(np.float64) * 0.01

    return score - penalty
