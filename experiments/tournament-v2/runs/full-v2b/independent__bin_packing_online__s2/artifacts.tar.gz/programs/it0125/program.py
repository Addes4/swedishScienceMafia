"""Best fit with smoothing / tie-breaking for online bin packing."""

import numpy as np


class _State:
    def __init__(self):
        self.seen = 0
        self.hist = np.zeros(101, dtype=np.float64)


_state = _State()


def priority(item, bins):
    """Rank bins: prefer tightest fit (best fit), with mild tie-breaking.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (only bins where item fits,
          plus unused bins with capacity 100), in bin order.

    Returns an array of scores; highest score wins, ties go to the earliest bin.
    """
    # --- track item statistics (state is allowed and cheap) -----------------
    _state.seen += 1
    _state.hist[item] += 1.0
    # Exponential forgetting so recent distribution dominates slightly.
    if _state.seen % 64 == 0:
        _state.hist *= 0.98

    b = bins.astype(np.float64, copy=False)

    # Core: best fit -> smallest remaining capacity after placing the item.
    # remaining_after = bins - item, so maximize -(bins - item).
    score = -(b - item)

    # Mild tie-breaking: among equally tight bins, prefer bins whose resulting
    # leftover is a "common" size, which tends to reduce fragmentation.
    leftover = b - item  # >= 0 for shown bins

    # Frequency of left-over sizes among past items, used as a tiny bonus.
    # Normalize so it never overwhelms the primary best-fit ordering.
    hist = _state.hist
    total = hist.sum()
    if total > 0:
        freq = hist / total
        # Common leftovers are slightly favored. This is a small perturbation.
        score += 1e-3 * freq[leftover.astype(np.int64)]

    # Secondary tie-break against perfectly full bins only when tied, handled
    # naturally by the score above; explicit epsilon keeps determinism.
    score += 1e-9 * (-np.arange(bins.shape[0]))

    return score
