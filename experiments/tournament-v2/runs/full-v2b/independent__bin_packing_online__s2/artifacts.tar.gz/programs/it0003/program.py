"""Online bin packing: a best-fit rule with a mild residue-aware tie-break.

The item is placed in the bin whose remaining capacity is closest to the item
size (best fit), which is a strong online heuristic for this distribution.
We add a small adaptive term based on recent item sizes to avoid creating bins
with tiny leftovers that can no longer fit typical items.

Only the current call is needed; a little state is kept for adaptation.
"""
import numpy as np

_state = {
    "n": 0,          # number of items seen
    "recent": [],    # queue of recent item sizes
    "recent_sum": 0,
}


def priority(item, bins):
    """Return a score per bin; the item goes to the highest score (first on ties).

    Parameters
    ----------
    item : int
        Size of the arriving item, 1..100.
    bins : numpy.ndarray
        Remaining capacity of every bin the item fits in (int64), in bin order.

    Returns
    -------
    numpy.ndarray
        One score per bin.
    """
    st = _state

    # Maintain a short moving average of recent item sizes (cheap, no numpy)
    st["n"] += 1
    rec = st["recent"]
    rec.append(item)
    st["recent_sum"] += item
    if len(rec) > 50:
        st["recent_sum"] -= rec.pop(0)

    avg = st["recent_sum"] / len(rec)

    # Best fit: prefer the bin whose remaining capacity is closest to the item.
    # Score = -(remaining - item) so tighter fits score higher.
    base = -(bins - item)

    # Mild residue-aware adjustment. After placing, the leftover is
    # leftover = bins - item. Small leftovers (< avg/2) are hard to reuse;
    # give them a slight penalty so we prefer leftovers that remain useful.
    leftover = bins - item
    # Reward leftovers that are near the typical item size, penalize tiny ones.
    # Keep the influence small so best-fit dominance is preserved.
    adaptive = -(np.abs(leftover - avg) * 0.02)

    return base + adaptive
