import numpy as np

_STATE = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Rank bins: prefer tightest fit, but keep some empty bins in reserve."""
    # Maintain a running mean of item sizes (cheap, stateful).
    s = _STATE
    s["n"] += 1
    s["sum"] += item
    mean_item = s["sum"] / s["n"]

    # residual after placing item into each bin
    resid = bins - item  # bins only contains bins the item fits in, so resid >= 0

    # Base: prefer small residual (best fit). Negate so larger score = better.
    score = -(resid.astype(np.float64))

    # Reward non-empty bins slightly so empty bins (capacity 100) are conserved.
    # Magnitude scaled small so it only breaks near-ties.
    empty_mask = (bins == 100)
    score += np.where(empty_mask, 0.0, 0.25)

    # Additionally, if a bin would be left nearly full (tiny residual), strongly prefer it,
    # which packs tightly and closes bins.
    near_full = resid <= 3
    score += np.where(near_full, 1.0, 0.0)

    # Guard: for large items, avoid filling the last very-empty bin too aggressively
    # by mildly penalizing perfectly empty bins only when item is large.
    if item > mean_item * 1.5:
        score -= np.where(empty_mask, 0.5, 0.0)

    return score
