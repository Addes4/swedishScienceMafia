import numpy as np


def priority(item, bins):
    """Best fit: prefer the bin with the least remaining capacity after placing item."""
    return -(bins - item)
