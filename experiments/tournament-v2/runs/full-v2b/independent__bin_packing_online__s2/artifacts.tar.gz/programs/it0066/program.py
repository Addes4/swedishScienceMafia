"""Online bin packing: adaptive best-fit with fragmentation-aware penalties.

Strategy (fits the required online, one-item-at-a-time model):

For each bin that the arriving item fits in, we compute a score built from two ideas:

1. Best fit on residual capacity: after placing the item, the new remaining capacity
   `r = cap - item`. A *smaller* final residual is generally better because it packs
   tightly and wastes less space. So the base score is `-r`.

2. Fragmentation penalty: a residual that is small but non-zero (say 1..threshold)
   is wasted unless a future item can exactly use it. At the same time, keeping some
   large bins fully empty (residual 100) is valuable as a reserve for big items.
   We add a mild penalty for leaving a "useless small hole" and a small premium for
   keeping a few bins completely free, but not for every bin (otherwise we would
   scatter items and waste capacity).

The relative weights were chosen to be robust across the Weibull-shaped item
distribution (mean ~40) rather than tuned to any single instance. Classic best fit
is the main driver (it is near-optimal for this distribution), and the adjustments
only break ties and handle leftovers intelligently.
"""

import numpy as np


def priority(item, bins):
    """Return a score for every bin; the item goes to the highest (first on ties).

    item: integer size of arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of bins the item fits in,
          including unused bins (remaining cap 100), in bin order.
    """
    bins = np.asarray(bins, dtype=np.int64)

    # Residual capacity of each candidate bin after placing the item.
    residual = bins - item  # guaranteed >= 0 for all bins shown

    # Base: best fit -> most negative residual (tightest remaining space) wins.
    score = -residual.astype(np.float64)

    # Fragment penalty: a tiny leftover (1..6) is essentially wasted, since the
    # distribution produces few items that small. Penalize it slightly.
    small_hole = (residual > 0) & (residual <= 6)
    score[small_hole] -= 0.6

    # Reserve premium: keep a handful of completely empty bins as a reserve for
    # large items. Only reward the empty bins mildly and only when many exist,
    # to avoid scattering items across many half-empty bins.
    n_empty = int(np.count_nonzero(bins == 100))
    if n_empty > 3:
        score[bins == 100] += 0.25

    # Perfect-fit bonus: filling a bin exactly is always ideal.
    exact = residual == 0
    if np.any(exact):
        score[exact] += 1.0

    # Near-perfect fit (leaves almost no residual) bonus.
    near = (residual > 0) & (residual <= 2)
    score[near] += 0.3

    return score
