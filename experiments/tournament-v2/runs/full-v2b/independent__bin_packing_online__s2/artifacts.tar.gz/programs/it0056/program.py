"""Online bin packing: graded best-fit priority rule."""
import numpy as np


def priority(item, bins):
    # Classify by leftover capacity after placing the item.
    # Prefer exact fits, then very small leftovers (<= 5), then general best-fit.
    residual = bins - item
    score = -residual.astype(np.float64)

    # Strong bonus for exact fit.
    score[residual == 0] += 1e6

    # Strong bonus for very tight fits (leave little waste).
    tight = (residual > 0) & (residual <= 5)
    score[tight] += 1e4 - residual[tight]

    return score
