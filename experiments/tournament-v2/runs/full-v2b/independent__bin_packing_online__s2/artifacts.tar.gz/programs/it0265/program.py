import numpy as np


def priority(item, bins):
    # Best fit: prefer the bin that leaves the least remaining capacity after placement.
    # Score = -(remaining_after) = item - remaining_before, so larger for tighter bins.
    return -(bins - item)
