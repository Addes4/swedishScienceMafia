"""Best-fit with a preference against opening new bins.

The item goes into the bin with the smallest remaining capacity that still
fits (classic best fit).  Ties are broken by the early bin index, which is
fine because unused bins all have capacity 100 and appear later on average.

To avoid opening a new bin when an existing one fits, we add a small bonus
to bins that are already in use (remaining capacity < 100).  This is the
standard "best fit decreasing"-like heuristic adapted to online arrival.
"""

import numpy as np

_MAX_CAP = 100


def priority(item, bins):
    """Rank bins: best fit first, prefer non-empty bins on ties."""
    # Classic best fit: smaller remaining capacity (after placement) is better.
    # Score = -(remaining - item) = item - remaining.
    # Adding a tiny bonus to bins that are already used discourages opening
    # a new bin when an existing one fits equally well.
    used_bonus = (bins < _MAX_CAP).astype(np.float64) * 1e-6
    return (item - bins).astype(np.float64) + used_bonus
