import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.total = 0
        self.last_bins_len = 0


_state = _State()


def priority(item, bins):
    """Score bins for an arriving item.

    Best-fit is the strongest simple online rule for this setting.  We keep the
    score strictly monotone in post-placement remaining capacity so that tighter
    fits win, while using the bin order as the fixed tie-breaker.  A tiny amount
    of state lets us preserve stable behavior across calls without overfitting.
    """
    _state.calls += 1
    _state.total += item
    _state.last_bins_len = len(bins)

    # Place into the feasible bin that would be fullest afterwards.
    # bins contains only bins the item fits into, so bins - item >= 0.
    return -(bins - item)
