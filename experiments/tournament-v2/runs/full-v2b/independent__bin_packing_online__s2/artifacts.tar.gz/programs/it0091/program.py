"""Online bin packing heuristic based on best-fit with fit-quality weighting."""

import numpy as np


def priority(item, bins):
    """Score each bin so the item goes into the best-fitting one.

    The main objective is to leave as little unused capacity as possible,
    while slightly favouring bins that become nearly full.
    """
    bins = np.asarray(bins)

    # Smaller slack is better: slack = remaining capacity after placing item.
    slack = bins - item

    # Strongly prefer tight fits, but add a tiny reward for making a bin full
    # or nearly full. This mirrors best-fit and avoids unnecessary new bins.
    score = -(slack.astype(np.float64))

    # Very small bonus for bins whose resulting fill fraction is high.
    # Use remaining capacity after placement; full bins get no special
    # preference beyond the slack term, but near-full bins are slightly
    # preferred over partially empty ones with the same slack.
    original = bins.astype(np.float64)
    # Avoid division by zero; capacity is 100 here.
    fill_after = (100.0 - slack.astype(np.float64)) / 100.0
    score += 1e-6 * fill_after

    return score
