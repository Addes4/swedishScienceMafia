import numpy as np


def priority(item, bins):
    # Best-fit style score: prefer bin with smallest remaining capacity that still fits item.
    # bins contains only bins where item fits, so remaining capacity >= item.
    # We maximize a score; smaller remaining capacity => larger score.
    # Add a tiny deterministic tie-break favoring earlier bins with exactly matching slack,
    # but that is handled by tie rules. Use a small bonus for tighter fits.
    slack = bins - item
    # Primary: prefer smallest slack (tightest fit).
    # Secondary: prefer bins already partially used to avoid opening new bins unnecessarily.
    # Since unused bins have capacity 100 and are included, tightest fit naturally avoids them.
    # Use negative slack, scaled to ensure integer distinctions dominate tie-breaking.
    # Bonus for bins with small remaining capacity after placement.
    remaining_after = bins - item
    score = -remaining_after.astype(np.float64) * 1000.0 - bins.astype(np.float64)
    return score
