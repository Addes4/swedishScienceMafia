import numpy as np

def priority(item, bins):
    """
    Online bin packing priority rule.
    Use best fit (smallest remaining capacity that fits), but if the item is small
    (< 50) and the best fit would leave a small positive leftover (1..9),
    heavily penalize that bin so that an unused bin (or a bin with a larger leftover)
    is chosen instead. This avoids creating nearly useless small gaps.
    """
    remaining = bins
    leftover = remaining - item
    # default: best fit (maximize -leftover)
    score = -leftover.astype(np.float64)
    if item < 50:
        used = remaining != 100
        # penalize used bins that would leave a small positive leftover
        mask = used & (leftover > 0) & (leftover < 10)
        score[mask] = -leftover[mask] - 100.0
    return score
