import numpy as np


def priority(item, bins):
    """Best-fit priority with index tie-breaking to prefer earlier bins slightly.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities, in bin order.
    """
    n = bins.shape[0]
    # Prefer the smallest remaining capacity after placing the item (best fit).
    # Add a tiny index-based term so ties go to earlier bins, matching the harness's
    # tie rule and avoiding arbitrary numpy instability.
    rem_after = bins - item
    idx = np.arange(n, dtype=np.float64)
    return -(rem_after.astype(np.float64) + idx * 1e-9)
