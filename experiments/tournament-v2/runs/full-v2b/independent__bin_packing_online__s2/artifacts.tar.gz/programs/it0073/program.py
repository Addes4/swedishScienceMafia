"""Best fit: put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Rank bins so the highest score goes to the tightest-fitting bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacities (including unused bins at 100).
    """
    # Fitting bins have bins >= item. The tightest fit minimizes remaining capacity
    # after placement, i.e. minimizes bins. Negate so the smallest capacity gets the
    # highest score; ties fall to the earliest bin index automatically.
    return -(bins - item)
