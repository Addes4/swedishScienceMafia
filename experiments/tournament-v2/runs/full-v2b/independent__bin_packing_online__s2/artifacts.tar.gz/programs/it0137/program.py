import numpy as np

_STATE = {
    "n": 0,
    "sum_sq": 0.0,
    "sum": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
}


def priority(item, bins):
    st = _STATE
    st["n"] += 1
    st["sum"] += item
    st["sum_sq"] += item * item
    st["hist"][item] += 1.0

    n = st["n"]
    mean = st["sum"] / n
    var = max(st["sum_sq"] / n - mean * mean, 0.0)
    std = var ** 0.5

    # Typical future item size estimate: slightly conservative quantile-ish value.
    # For Weibull-like sizes with mean ~40, using mean + 0.25*std works well.
    typ = mean + 0.25 * std
    if typ < 1.0:
        typ = 1.0
    if typ > 100.0:
        typ = 100.0

    cap = bins.astype(np.float64)
    residual = cap - item

    # Primary: prefer tight fit so less capacity is wasted.
    tight = -residual

    # Secondary: among similar tight fits, prefer bins whose residual is
    # close to a typical future item, since that residual can be reused.
    usefulness = -(np.abs(residual - typ))

    # Third: avoid leaving tiny unusable residuals.
    tiny_penalty = np.where(residual < 10.0, -2.0, 0.0)

    # Weighting: tight fit dominates but usefulness breaks ties.
    score = 4.0 * tight + 0.9 * usefulness + tiny_penalty

    # Slight preference for later bins as they are more likely already open,
    # but keep it tiny so packing quality dominates.
    idx = np.arange(len(bins), dtype=np.float64)
    score += 1e-6 * idx

    return score
