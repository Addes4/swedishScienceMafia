import numpy as np

def priority(item, bins):
    n = bins.shape[0]
    score = np.empty(n, dtype=np.float64)
    # Base: best fit (prefer smallest remaining capacity that still fits).
    # Penalize unused bins (capacity 100) slightly when there are already used bins
    # with enough room, to reduce opening new bins.
    used_exists = np.any(bins < 100)
    if used_exists:
        # Small penalty for completely empty bins, but only if item is not too large.
        # Larger items are more likely to need a fresh bin anyway.
        penalty = 0.5 if item <= 60 else 0.0
    else:
        penalty = 0.0

    for i in range(n):
        cap = bins[i]
        s = -cap  # smaller remaining capacity -> higher score
        if cap == 100 and penalty > 0.0:
            s -= penalty
        score[i] = s
    return score
