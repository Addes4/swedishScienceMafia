import numpy as np


def priority(item, bins):
    # Best fit: prefer bin with smallest remaining capacity after placing item.
    # Score = negative leftover.
    leftover = bins - item

    # Bonus: slightly favor bins that become exactly full or nearly full,
    # because they leave no awkward residual capacity.
    # Also slightly prefer partially-used bins over completely empty ones
    # is already implicit (empty has leftover 100-item, largest).
    score = -leftover.astype(np.float64)

    # Small extra push for bins that would be exactly filled (leftover == 0)
    score[leftover == 0] += 0.5

    # Small penalty for freshly-empty bins (bins == 100) to avoid opening
    # new bins when an existing one fits adequately.
    score[bins == 100] -= 0.25

    return score
