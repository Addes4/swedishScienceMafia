import numpy as np


def priority(item, bins):
    """Rank bins by preferring tight fits, while mildly discouraging tiny leftovers."""
    residual = bins - item
    # Lower residual is better (best fit), so use negative residual.
    # Add a small penalty for residuals that are very small but nonzero,
    # and a tiny preference for exactly full bins.
    score = -residual.astype(np.float64)

    # Slightly prefer exact fits (residual == 0).
    score[residual == 0] += 1e-6

    # Mildly discourage leaving very small unusable gaps.
    small = (residual > 0) & (residual < 5)
    score[small] -= 0.01 * (5 - residual[small])

    return score
