import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum = 0
        self.sumsq = 0
        self.hist = np.zeros(101, dtype=np.int64)
        self.quantiles = None
        self.update_every = 64

    def update(self, item):
        self.n += 1
        self.sum += item
        self.sumsq += item * item
        self.hist[item] += 1
        if self.n >= 32 and self.n % self.update_every == 0:
            self._compute_quantiles()

    def _compute_quantiles(self):
        c = np.cumsum(self.hist)
        if c[-1] == 0:
            self.quantiles = None
            return
        probs = np.linspace(0.05, 0.95, 19)
        targets = probs * c[-1]
        qs = []
        j = 1
        for t in targets:
            while j <= 100 and c[j] < t:
                j += 1
            qs.append(j)
        self.quantiles = np.array(qs, dtype=np.int64)

    def mean(self):
        return self.sum / self.n if self.n else 40.0

    def score_waste(self, waste):
        # Estimate usefulness of a bin with given remaining capacity after placing current item.
        # Smaller waste tends to be good, but some wastes are especially bad because they
        # cannot fit common future item sizes.
        if self.quantiles is None or self.n < 32:
            return -waste
        q = self.quantiles
        # Penalize capacities just below common item sizes. Reward capacities that are
        # themselves near common item sizes as they may fit a single future item tightly.
        s = 0.0
        for x in q:
            if waste < x:
                s -= 0.008 * (x - waste)
            else:
                s += 0.0015 * min(waste - x, 20)
        # Mildly prefer very full bins, but not overwhelmingly.
        s -= 0.02 * waste
        return s


_state = _State()


def priority(item, bins):
    """Return scores for bins; highest score gets the item."""
    _state.update(item)
    b = np.asarray(bins, dtype=np.int64)

    # Post-placement remaining capacity.
    waste = b - item

    # Pure best-fit component: strongly prefer the smallest feasible remaining capacity.
    score = -10.0 * waste.astype(np.float64)

    # Add distribution-aware adjustment based on leftover capacity.
    q = _state.quantiles
    if q is not None and _state.n >= 32:
        wf = waste.astype(np.float64)
        adj = np.zeros_like(wf)

        # For each common quantile threshold, penalize leftovers just below it,
        # and mildly reward leftovers near/above it.
        for x in q:
            below = wf < x
            adj += np.where(below, -0.35 * (x - wf), 0.015 * np.minimum(wf - x, 20.0))

        # Slight bonus for exactly useful remaining capacities.
        for x in q:
            adj += np.where(wf == x, 0.8, 0.0)

        score += adj

    # Prefer unused bins only when item is large, to avoid opening new bins too easily.
    if item >= 70:
        score += np.where(b == 100, 1.5, 0.0)

    # Avoid tiny unusable leftovers when possible.
    score += np.where((waste > 0) & (waste < 8), -1.0, 0.0)

    return score
