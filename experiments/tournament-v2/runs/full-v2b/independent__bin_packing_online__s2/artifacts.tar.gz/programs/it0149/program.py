import numpy as np


def priority(item, bins):
    """Best fit, with a small preference for nonempty bins among equal fits.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin.
    """
    # Primary: tightest fit (smallest remaining capacity after placing item).
    score = -(bins - item)

    # Secondary: prefer bins that are already in use over completely empty bins.
    # This is only a tiny tie-breaker, so it does not disturb true best fit.
    score = score.astype(np.float64)
    score += (bins < 100).astype(np.float64) * 1e-6

    return score
