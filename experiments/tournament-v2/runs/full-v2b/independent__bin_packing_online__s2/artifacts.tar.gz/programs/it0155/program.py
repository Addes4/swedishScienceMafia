"""Distribution-aware best-fit heuristic.

The item sizes are drawn from a Weibull-shaped distribution with mean ~40.
Classic online bin packing theory shows that for such sizes, filling bins to
capacity levels that align with the item-size distribution (harmonic-style
packing) is near-optimal.  We implement a refined Best-Fit:

    score = -(residual_after_placement) + bonus

where `bonus` rewards placing the item so that the bin's residual lands in a
"good" region (near 0) and penalizes residuals that waste usable space for
typical future items (roughly rounded to multiples of common item sizes).

Bins are ranked so that the tightest fit wins, with a small tie-break bias
toward bins whose post-placement residual is a value in a preferred set
(computed from a discretized Weibull mean-40 distribution).  This keeps the
heuristic O(1) per call and robust across instances.
"""
import numpy as np

# Precompute preferred residuals: multiples/co-residues of typical item sizes.
# Weibull(shape~1.5, scale~44) has mean ~40.  Common sizes cluster below 100.
# Preferred residuals are values that leave little unusable slack.
_PREF = np.zeros(101, dtype=np.float64)
for r in range(101):
    # distance from the nearest "useful" residual threshold.
    # Value 0 is ideal; residuals near typical item sizes are good (can be
    # filled exactly); residuals just below a size are wasteful.
    d = 0.0
    for s in (10, 15, 20, 25, 30, 35, 40, 50, 60, 70, 80, 90, 100):
        diff = r - s
        if diff >= 0 and diff < 3:
            d += 0.5
    _PREF[r] = d

# Strong preference for small residuals, mild preference for "harmonically good"
# residuals.  Scale chosen so it never overrides the primary best-fit ordering.
_W = 0.15


def priority(item, bins):
    """Rank bins: mostly tightest fit, with a residual-quality bonus."""
    residual = bins - item  # remaining capacity after placing the item (>=0)
    # Primary term: smaller residual => higher score.
    score = -residual.astype(np.float64)
    # Secondary term: reward residuals that are "harmonically good".
    # _PREF is indexed by residual; clip to [0,100].
    r = np.clip(residual, 0, 100)
    score = score + _W * _PREF[r]
    return score
