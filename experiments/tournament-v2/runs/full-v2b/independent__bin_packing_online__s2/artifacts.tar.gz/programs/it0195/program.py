import numpy as np


def priority(item, bins):
    """
    Score each bin for the arriving item.

    Main rule: best fit, i.e. prefer the bin that leaves the smallest
    remaining capacity after placing the item.

    Small refinement: if the item cannot be placed exactly, slightly
    discourage placements that leave a very small residual (e.g. 1..3),
    because those slivers are almost never usable later. This is still
    essentially best-fit and does not rely on future items.
    """
    residual = bins - item

    # Higher score is better. Exact fits get the largest boost.
    score = -residual.astype(np.float64)

    # Penalize tiny non-zero residuals a bit to avoid creating useless slivers.
    # Exact fits (residual == 0) are not penalized.
    tiny = (residual > 0) & (residual <= 3)
    score[tiny] -= 0.25

    return score
