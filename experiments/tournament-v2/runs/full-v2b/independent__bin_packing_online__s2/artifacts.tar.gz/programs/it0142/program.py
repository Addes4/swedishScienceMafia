import numpy as np

# Persistent state: count how many items have been placed in each bin index.
_use_count = np.zeros(20000, dtype=np.int64)
_capacity_template = None


def priority(item, bins):
    global _use_count, _capacity_template

    n = len(bins)

    # Grow the usage counter if needed.
    if _use_count.shape[0] < n:
        new = np.zeros(n * 2, dtype=np.int64)
        new[: _use_count.shape[0]] = _use_count
        _use_count = new

    # Residual after placing item in each bin (smaller is better for best-fit).
    resid = bins - item  # item is guaranteed to fit in all shown bins

    # Best-fit primary score: prefer smaller residual.
    # Secondary: prefer bins that have been used less (spread load),
    # tertiary: prefer lower bin index (already handled by tie order).
    # Combine into a single float score.
    # Residual range is 0..100, usage count can grow large; scale usage modestly.
    usage = _use_count[:n].astype(np.float64)

    # Primary term dominates; usage acts only as a tie-breaker among equal residuals.
    score = -(resid.astype(np.float64)) - usage * 1e-6

    return score
