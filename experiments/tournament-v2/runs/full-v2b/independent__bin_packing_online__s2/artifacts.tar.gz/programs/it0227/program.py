"""Best-fit with a mild penalty for leaving very small residuals.

Items ~40 on average. Best-fit minimizes immediate waste, but on a Weibull
distribution it can trap space: a bin reduced to a tiny remainder is wasted,
while it would have been better to leave a moderately full bin for a good fit.
We use pure best-fit (tightest) as the primary rule, which is hard to beat
online, and add a tiny score nudge so that among near-equal fits we prefer
bins whose residual after placing is not a small unusable sliver.
"""
import numpy as np


def priority(item, bins):
    residual = bins - item  # >= 0 for all shown bins
    # Primary: pack as tightly as possible (smallest residual -> highest score).
    score = -residual.astype(np.float64)
    # Secondary nudge: penalize leaving a small but nonzero residual, which is
    # hard to fill later. Residual 0 (perfect fit) is best and unpenalized.
    small = (residual > 0) & (residual < item)
    score[small] -= 0.5
    return score
