import numpy as np

_state = {
    "n": 0,
    "sum": 0.0,
    "sumsq": 0.0,
    "sizes": None,
    "cnt": 0,
}


def priority(item, bins):
    # Update running statistics of seen items
    s = _state
    s["n"] += 1
    s["sum"] += item
    s["sumsq"] += item * item

    n = s["n"]
    mean = s["sum"] / n
    var = max(s["sumsq"] / n - mean * mean, 0.0)
    std = var ** 0.5

    # Small residual threshold: treat bins whose leftover after placing
    # would be very small as excellent (they become effectively "closed").
    # Also avoid making a bin have a moderate leftover that could be filled.
    residual = bins - item  # bins only includes those where item fits (residual >= 0)

    # Base: best fit -> prefer smallest residual.
    score = -residual.astype(np.float64)

    # Threshold to encourage closing bins: strong bonus for near-perfect fits.
    # Use a threshold derived from the distribution (small items common in Weibull).
    close_thresh = max(1.0, min(10.0, 0.25 * std))
    # Bonus for leaving very little space (bins get "closed")
    score += 50.0 * (residual <= close_thresh)

    # Slight preference to keep larger bins free: when residual is large,
    # deprioritize (best fit already handles this), but add mild pressure to
    # not waste big empty bins on items that fit well elsewhere.
    # Empty bins have residual 100 - item; penalize using them unless item is large.
    empty_residual = 100 - item
    is_empty = (bins == 100)
    # Penalize empty bins mildly, scaled by how much space would remain
    score -= 0.5 * is_empty.astype(np.float64) * (empty_residual > 0.5 * (100 - mean))

    return score
