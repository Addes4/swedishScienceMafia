import numpy as np


def priority(item, bins):
    """Score bins for an arriving item.

    Primary rule: best fit (smallest remaining capacity after placement).
    Tie-break: prefer bins that are already more used (smaller remaining capacity),
    which tends to preserve empty bins for difficult future items without hurting
    the classic best-fit worst-case behavior.
    """
    # best fit: minimize (bins - item) == maximize -(bins - item)
    tightness = -(bins - item)

    # small preference for fuller bins (smaller remaining capacity) to avoid
    # opening new bins unnecessarily when several fits are equally tight.
    usage_bias = -bins.astype(np.float64)

    # Combine: tightness dominates; usage_bias only breaks near-ties.
    # Amplify tightness so integer differences dominate the fractional bias.
    return tightness.astype(np.float64) * 1_000_000.0 + usage_bias
