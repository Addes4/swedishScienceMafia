"""Improved online bin packing: best-fit with slight tuning for large items."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tightest fit (best fit).

    Score is higher for smaller remaining capacity, so the item goes to the
    fullest bin it still fits in. This minimizes wasted space and tends to
    produce compact packings for Weibull-distributed sizes (mean ~40).
    """
    # Best fit: smallest remaining capacity (i.e., tightest packing).
    # Bins with remaining capacity 100 (unused) are naturally last.
    return -bins
