"""Improved best-fit: prefer bins that become full, with tight-fit preference."""
import numpy as np


def priority(item, bins):
    remaining_after = bins - item
    # Primary: pack as tightly as possible -> minimize remaining capacity after placement.
    # Add a bonus for placing into bins that end up very full (remaining_after small).
    # Use a steep linear score so ordering is dominated by tightness,
    # but slightly reward bins whose remaining capacity is already small.
    score = -(remaining_after.astype(np.float64))
    # Extra emphasis when the bin becomes nearly full (remaining_after <= item, i.e. bin half full)
    score += np.where(remaining_after <= item, 0.25, 0.0)
    # Small preference for bins already more filled (larger item relative to bin used)
    score += 0.001 * (100 - bins)
    return score
