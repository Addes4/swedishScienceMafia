import numpy as np

# State: track whether we have seen many items, and adapt a cutoff.
# We use a simple adaptive rule: when a bin can be made nearly full, do it.
# Otherwise, best fit tends to be strong for this distribution.
#
# The key idea is to bias toward filling bins to exact/exact-ish capacities
# because the item sizes are up to 100 and mean ~40; best fit is good but
# can fragment.  A soft "fill tight" rule improves packing slightly.

_CALLS = 0
_FILL_CUTOFF = 0  # residual after placement considered "tight"


def priority(item, bins):
    global _CALLS
    _CALLS += 1

    # remaining capacity after placing item
    rem = bins - item  # bins already filtered to those >= item

    # Score: primary goal is smallest remainder (best fit).
    # Add a strong bonus when the remainder is very small, to fill bins tightly.
    # A bonus that grows as remainder approaches 0.
    # This is a continuous version of "if fits tightly, do it".
    #
    # score = -rem + bonus
    # where bonus = lambda / (rem + 1)
    #
    # lambda can be tuned.  Since mean item ~40, remainder scale ~0..100.
    # A modest bonus encourages tight packing without hurting worst cases.
    lam = 8.0
    score = -rem.astype(np.float64) + lam / (rem.astype(np.float64) + 1.0)

    # Slight preference for lower-index bins on ties is handled by harness
    # (ties go to first).  To be deterministic and stable, we leave as is.
    return score
