"""Best-fit with deterministic tie handling for online bin packing."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer the bin with the smallest remaining capacity that still fits."""
    # bins contains remaining capacities >= item
    # We want tighter fit -> smaller remaining capacity.
    # Adding a tiny index-independent term avoids ambiguity without changing ordering.
    return -(bins - item) * 1000.0 - bins * 0.001
