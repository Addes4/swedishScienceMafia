import numpy as np

def priority(item, bins):
    # Best-fit: maximize bin fullness after placing the item.
    # A slight convex shaping encourages packing into nearly-full bins,
    # which typically reduces the number of bins on Weibull-like item sizes.
    rem = bins - item
    # Primary score: prefer smallest remaining capacity (tightest fit).
    # Secondary tie-breaker: prefer bins that were already more full before placement.
    # We can encode this smoothly without changing the greedy order too much.
    # Score = -(remaining) + eps * (capacity before placement)
    # Since bins order breaks ties, a tiny eps only affects exact near-ties.
    return -rem.astype(np.float64) + 1e-9 * (100 - bins).astype(np.float64)
