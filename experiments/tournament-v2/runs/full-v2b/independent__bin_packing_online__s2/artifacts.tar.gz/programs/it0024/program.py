import numpy as np


def priority(item, bins):
    """Rank bins by tightest residual fit, with slight preference for less-full bins on ties."""
    residual = bins - item
    # Primary: prefer smallest residual (tightest fit).
    # Secondary: among equal residuals, prefer bins that are already more used
    # (smaller remaining capacity before placement), which consolidates load.
    return -residual.astype(np.float64) * 1000.0 - bins.astype(np.float64)
