import numpy as np

# Adaptive bin-choice rule for online bin packing.
# Combines best-fit with a dynamic reservation heuristic based on observed item sizes.

_state = {
    "count": 0,
    "hist": np.zeros(101, dtype=np.float64),  # histogram of item sizes
    "warm": 200,  # number of items before using adaptive part
}


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties to first bin."""
    global _state
    _state["count"] += 1
    n = _state["count"]
    if item >= 1:
        _state["hist"][item] += 1.0

    # Base: best fit (prefer smallest remaining capacity >= item).
    # Score higher for bins whose remaining capacity is just above item.
    rem = bins.astype(np.float64)

    # Primary best-fit term: tighter fit gets higher score.
    # Use negative remaining capacity (smaller remaining => better).
    score = -rem

    # Adaptive term: prefer bins whose remaining capacity equals a "supported" size,
    # i.e. a size that still occurs often in future, so that a perfect fill can happen.
    if n > _state["warm"]:
        h = _state["hist"]
        total = h.sum()
        if total > 0:
            # Probability that a random future item exactly fits a bin with remaining r.
            prob = h / total
            # For each bin with remaining capacity r, reward if r is a likely item size.
            r_int = rem.astype(np.int64)
            # clamp to valid index
            r_clip = np.clip(r_int, 0, 100)
            reward = prob[r_clip]
            # Scale reward modestly so it breaks ties but doesn't override fit quality.
            score = score + 40.0 * reward

    # Slight discouragement of opening entirely new bins (remaining 100)
    # to keep them for large items: small penalty for untouched bins.
    score = score - 0.05 * (rem == 100.0)

    return score
