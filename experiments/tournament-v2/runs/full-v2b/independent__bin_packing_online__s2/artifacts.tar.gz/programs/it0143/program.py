import numpy as np

# Precompute a small set of "useful" remainders (common item sizes under the
# Weibull-ish distribution mean ~40). Leaving these free can help future items.
_USEFUL = np.array([1, 2, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50,
                    55, 60, 65, 70, 75, 80, 90, 100], dtype=np.int64)


def priority(item, bins):
    # Remaining capacity after placing the item.
    rem = bins - item
    # Base score: best fit => minimize remaining capacity => maximize -rem.
    score = -rem.astype(np.float64)
    # Small bonus when the leftover equals a likely future item size exactly.
    # This encourages "perfect" packings without overriding best-fit much.
    bonus = np.isin(rem, _USEFUL).astype(np.float64) * 0.5
    return score + bonus
