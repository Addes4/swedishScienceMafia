import numpy as np


def priority(item, bins):
    """Rank bins so the item goes to the tightest fitting bin.

    bins: remaining capacities of bins the item fits in, including unused bins (cap 100).
    We use best fit: prefer the bin with the smallest remaining capacity that still fits
    (i.e. largest used capacity = 100 - remaining). Unused bins have remaining 100 and
    thus the lowest priority, encouraging packing into already-open bins first.
    A tiny tie-break favoring lower remaining capacity is already implicit.
    """
    # Higher score -> chosen. Best fit wants smallest remaining capacity among fitting bins.
    return -(bins)
