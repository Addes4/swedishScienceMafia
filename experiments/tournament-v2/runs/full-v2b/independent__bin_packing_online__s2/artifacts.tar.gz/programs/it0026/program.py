<change>
I'll use a refined Best-Fit rule: strongly prefer exact fits (residual 0), then rank by smallest nonzero residual, while mildly rewarding bins that are already partially filled to encourage consolidation and avoid opening new bins unnecessarily. A tiny tie-breaking bonus favors reusing the fullest bins so residuals become large and reusable.
</change>

