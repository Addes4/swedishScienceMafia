"""Online bin packing: adaptive best-fit with aging and size-aware tie-breaking."""
import numpy as np

_state = {
    "n": 0,
    "sum_size": 0.0,
    "recent": 0.0,
    "alpha": 0.02,
    "bins_seen": 0,
}

def priority(item, bins):
    """Rank bins greedily by best fit with size-aware penalties for fragmentation."""
    st = _state
    st["n"] += 1
    st["sum_size"] += item
    # exponential moving average of recent item sizes
    st["recent"] = (1.0 - st["alpha"]) * st["recent"] + st["alpha"] * item
    mean_size = st["sum_size"] / st["n"]

    # Remaining capacity after placing this item.
    rem = bins - item

    # Base: best fit (prefer smallest leftover capacity).
    score = -rem.astype(np.float64)

    # Penalize bins whose leftover is small enough that average future items won't fit,
    # but reward exact/near-exact fits slightly less than best-fit so we don't create
    # hard-to-refill tiny gaps too eagerly.
    # A leftover below the recent mean size is likely wasted; scale penalty smoothly.
    waste = np.maximum(0.0, st["recent"] - rem)
    score -= 0.35 * waste

    # Encourage using bins that already contain items (lower remaining capacity)
    # to keep the number of open bins under control.
    score -= 0.0015 * bins.astype(np.float64)

    # Slight preference to keep one bin available for large items: if item is large,
    # prefer fuller bins more strongly.
    if item >= 70:
        score -= 0.05 * rem.astype(np.float64)

    # Avoid all-equal scores causing bad tie breaks by adding a tiny index bias later is handled
    # by the harness (first on ties), so no extra index term.
    return score
