import numpy as np

class _Learner:
    def __init__(self):
        # score[c] estimates how good it is to leave a bin with remaining capacity c
        # after placing an item.  Higher means better (less likely to be wasted).
        self.score = np.zeros(101, dtype=np.float64)
        # counts how often each residual capacity has been observed
        self.count = np.zeros(101, dtype=np.float64)
        self.t = 0

    def update(self, item, residual):
        self.t += 1
        # Reward a residual by how much capacity is still available: small residuals
        # are usually more valuable because they waste less space, but a full bin
        # (residual 0) is ideal, so use a concave transform.
        reward = 1.0 - (residual / 100.0)
        lr = 0.05
        if self.count[residual] == 0:
            self.score[residual] = reward
        else:
            self.score[residual] += lr * (reward - self.score[residual])
        self.count[residual] += 1.0

    def bin_score(self, item, residual):
        # Base best-fit tendency: prefer small residual after placement.
        base = -(residual)
        # Learned correction, scaled; exploration bonus for under-observed residuals.
        bonus = self.score[residual] * 20.0
        explore = 5.0 / (1.0 + self.count[residual])
        return base + bonus + explore


_learner = _Learner()


def priority(item, bins):
    n = len(bins)
    residual = bins - item  # remaining capacity if item placed here
    scores = np.empty(n, dtype=np.float64)
    for i in range(n):
        r = int(residual[i])
        scores[i] = _learner.bin_score(item, r)
    return scores
