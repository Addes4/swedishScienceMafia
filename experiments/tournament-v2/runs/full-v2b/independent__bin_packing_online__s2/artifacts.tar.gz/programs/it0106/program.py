import numpy as np


def priority(item, bins):
    """
    Rank bins by a modified best-fit rule.

    Core idea: usually prefer the tightest fit (smallest remaining capacity),
    but slightly discourage filling the last few units of already nearly-full bins
    if the incoming item is not very small. This preserves tight bins for tiny
    future items and tends to reduce the total number of bins used.
    """
    remaining = bins.astype(np.float64)

    # Base best-fit score: higher is better, so use negative remaining capacity.
    score = -remaining

    # If the item is not tiny, mildly penalize bins that would become nearly full
    # unless the fit is extremely tight. This is a gentle occupancy-aware
    # adjustment, not a hard reservation.
    if item >= 10:
        after = remaining - item
        # Penalize bins that end with very little leftover capacity.
        # The penalty is strongest for leftovers near 0 and fades by ~15.
        tight = np.clip((15.0 - after) / 15.0, 0.0, 1.0)
        score -= 0.35 * tight

    return score
# EVOLVE-BLOCK-END
