"""Online bin packing: enhanced best fit.

Core rule: best fit (choose the bin that leaves the smallest residual capacity).
Two gentle refinements that never override the main signal for distinct residuals:
  * exact fits (residual 0) are strongly preferred;
  * a tiny preference against residuals smaller than the smallest item seen so far
    (such residuals are usually wasted), applied with a small weight so it only
    breaks near-ties and cannot cause large extra waste.
"""
import numpy as np

_state = {"min_item": 100}


def priority(item, bins):
    """Score each candidate bin; the arriving item goes to the highest score.

    item: integer size 1..100.
    bins: numpy int64 remaining capacities (all bins the item fits in).
    """
    if item < _state["min_item"]:
        _state["min_item"] = item

    # Remaining capacity after placing the item (always >= 0 for shown bins).
    r = (bins - item).astype(np.float64)

    # Primary signal: tightest fit, i.e. smallest residual (best fit).
    score = -r

    # Exact fits are especially valuable.
    score += 1e9 * (r == 0.0)

    # Small tie-breaking nudge: prefer leaving residuals that remain fillable.
    t = _state["min_item"]
    if t > 1:
        score -= (r < t) * 0.5

    return score
