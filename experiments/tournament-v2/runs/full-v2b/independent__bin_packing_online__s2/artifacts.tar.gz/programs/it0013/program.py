import numpy as np

_state = {
    "seen": 0,
    "sum": 0.0,
    "items": 0,
    "threshold": 50,
}


def priority(item, bins):
    """Score bins so the item is usually placed best-fit, with a small worst-fit bias."""
    b = np.asarray(bins, dtype=np.int64)

    # Track recent arrival sizes to adapt the worst-fit threshold mildly.
    _state["seen"] += 1
    _state["sum"] += float(item)
    _state["items"] += 1

    if _state["items"] >= 100:
        mean = _state["sum"] / _state["items"]
        # If arrivals are large, be more willing to use a fresh bin.
        if mean > 42.0:
            _state["threshold"] = 45
        elif mean < 38.0:
            _state["threshold"] = 60
        else:
            _state["threshold"] = 50
        _state["items"] = 0
        _state["sum"] = 0.0

    fit = b >= item
    if not np.any(fit):
        # Should not happen in normal use, but keep a valid score array.
        return np.zeros(len(b), dtype=np.float64)

    residual = b - item
    # Best-fit component: tighter fit gets higher score.
    score = -residual.astype(np.float64)

    # Mild worst-fit preference for bins that are nearly empty, especially for
    # small items. This helps avoid leaving many unusable small remainders.
    if item <= _state["threshold"]:
        # Slightly reward completely empty bins and bins with very large room.
        score += (b == 100).astype(np.float64) * 0.15
        score += np.maximum(0, b - 80).astype(np.float64) * 0.002

    # Bins that cannot hold the item must not be selected.
    score[~fit] = -1e12
    return score
