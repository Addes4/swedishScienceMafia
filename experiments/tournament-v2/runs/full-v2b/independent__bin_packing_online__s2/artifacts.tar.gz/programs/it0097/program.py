import numpy as np


def priority(item, bins):
    """Score bins: prefer tight fits, but strongly avoid leaving small remnants.

    score = -(remaining - item) - alpha * (remaining - item) ** 2
    The quadratic term makes tight fits (small leftover) much more attractive
    than merely adequate fits, reducing fragmentation.
    """
    gap = bins - item
    # Prefer small gap; penalize larger gaps disproportionately.
    # alpha tuned so that an exact fit is strongly favored.
    return -gap - 0.15 * gap * gap
