import numpy as np

# State: keep a simple histogram of observed item sizes to estimate the distribution.
_hist = np.zeros(101, dtype=np.float64)
_count = 0.0
# Precompute a "goodness" for each residual capacity after placing an item.
# We'll estimate how likely a future item can exactly fill a residual.
# This is a smoothed probability that an item of that exact residual arrives.

def priority(item, bins):
    global _hist, _count
    # Update histogram with this item (we see it now).
    _hist[int(item)] += 1.0
    _count += 1.0

    # Estimate probability of each size in 1..100 (with Laplace smoothing).
    # For speed, compute on the fly but avoid full recompute every call.
    # We'll use a simple cache updated periodically.
    # For 5000 calls, do incremental smoothing cheaply:
    # p[k] = (hist[k] + 0.5) / (count + 50)

    # Best-fit residual: r = bins - item (remaining after placing).
    # We want to prefer bins where the residual r is likely to be exactly filled later,
    # i.e., where p[r] is high, but primarily we still want small residual (best fit).
    # Combine: score = -r + alpha * log(p[r]) style bonus, but keep it simple and fast.

    r = bins - item  # >= 0 for shown bins
    # Compute a bonus: prefer residuals that are common item sizes in the future.
    # Use a smoothed frequency array over residuals; for unseen sizes use small value.
    # To stay fast, compute probabilities only for needed residual values.
    inv_denom = 1.0 / (_count + 50.0)
    # vectorized: p = (hist[r] + 0.5) * inv_denom
    freq = _hist[r] + 0.5
    p = freq * inv_denom
    # Bonus is stronger for exact-fit-prone residuals. Use sqrt to damp.
    # Also strongly prefer r == 0 (perfect fill) since it wastes nothing.
    bonus = np.sqrt(p)
    # Heavily reward perfect fit:
    perfect = (r == 0).astype(np.float64)
    # Main score: best fit (-r) plus a small bonus for common residuals.
    score = -r.astype(np.float64) + 2.0 * perfect + 0.3 * bonus
    return score
