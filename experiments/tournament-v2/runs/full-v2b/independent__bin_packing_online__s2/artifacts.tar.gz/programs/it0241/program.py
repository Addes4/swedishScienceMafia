import numpy as np


def priority(item, bins):
    # Best Fit: prefer the bin whose remaining capacity after placement is smallest.
    # Return the negative of leftover space so the tightest fit gets the highest score.
    return -(bins - item)
