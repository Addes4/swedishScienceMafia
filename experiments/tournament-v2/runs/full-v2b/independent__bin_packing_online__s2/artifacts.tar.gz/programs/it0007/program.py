# EVOLVE-BLOCK-START
"""Best-fit with adaptive large-item reserve for online bin packing."""
import numpy as np

# Kept state: exponential moving average of recent item sizes.
_state = {"ema": 40.0, "count": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Update running estimate of item sizes (no future info used).
    _state["count"] += 1
    alpha = 2.0 / (min(_state["count"], 200) + 1.0)
    _state["ema"] = (1.0 - alpha) * _state["ema"] + alpha * item
    avg = _state["ema"]

    # Base best-fit score: smaller leftover is better.
    leftover = bins - item
    score = -leftover.astype(np.float64)

    # Adaptive reserve: for small/medium items, slightly discourage leaving very
    # little free space, because a large item may need it later. If the arriving
    # item is large, tighten packing instead.
    large_ref = max(60.0, avg * 1.5)
    if item >= large_ref:
        # Large item: strong best fit, fill tight.
        score *= 1.0
    else:
        # Penalize bins that would be almost full after placing a small item,
        # since that wastes a bin that could have held a large item.
        waste = np.maximum(0.0, 10.0 - leftover.astype(np.float64))
        score -= waste * 0.35

    return score
# EVOLVE-BLOCK-END
