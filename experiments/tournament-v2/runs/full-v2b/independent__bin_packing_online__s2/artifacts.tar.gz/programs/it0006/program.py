"""Online bin packing: improved best-fit with fullness preference."""
import numpy as np


def priority(item, bins):
    """Rank bins: best-fit, with a slight preference for fuller bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    residual = bins - item

    # Base: best fit (smaller residual after placing => tighter fit).
    # Add a mild preference for bins that were already fuller (smaller `bins`),
    # so nearly-full bins get topped off and closed.
    # Scale so best-fit remains dominant and fullness is a tie-breaker.
    score = -residual.astype(np.float64) - 0.02 * bins.astype(np.float64)

    # Slightly discourage using completely empty (unused) bins when other
    # options exist, so empty bins are conserved for large items.
    score -= 0.05 * (bins == 100)

    return score
