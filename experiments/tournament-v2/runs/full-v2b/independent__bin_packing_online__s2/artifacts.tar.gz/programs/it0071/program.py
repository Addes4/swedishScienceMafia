import numpy as np


def priority(item, bins):
    """Score bins by best fit, with a small preference for bins that are not too empty.

    The main rule is best fit: prefer the bin whose remaining capacity is closest
    to the item size.  A tiny penalty on large remaining capacity breaks near ties
    in a way that encourages tighter packing without destroying best-fit behavior.
    """
    return -(bins - item) - 1e-6 * bins
