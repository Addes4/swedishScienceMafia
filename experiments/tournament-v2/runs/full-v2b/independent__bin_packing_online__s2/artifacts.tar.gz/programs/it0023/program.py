"""Online bin packing: best-fit with waste penalty and empty-bin avoidance."""
import numpy as np

# Items are Weibull-shaped with mean ~40. Leftovers below this are usually wasted.
WASTE_THRESHOLD = 12.0
EMPTY_BIN_PENALTY = 6.0
FULL_BIN = 100


def priority(item, bins):
    """Rank bins for the arriving item; highest score wins (first on ties)."""
    remaining_after = bins - item

    # Base: best fit -> prefer smallest leftover.
    score = -remaining_after.astype(np.float64)

    # Penalize leftovers that are too small to likely be filled again.
    small = remaining_after < WASTE_THRESHOLD
    score -= np.where(small, (WASTE_THRESHOLD - remaining_after) * 1.5, 0.0)

    # Slightly prefer using already-open (partially filled) bins over untouched ones,
    # to avoid consuming fresh bins unnecessarily.
    is_empty = bins == FULL_BIN
    score -= np.where(is_empty, EMPTY_BIN_PENALTY, 0.0)

    return score
