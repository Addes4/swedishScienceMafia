import numpy as np


def priority(item, bins):
    # Best fit: smallest remaining capacity after placing the item.
    # Since the item goes to the highest score, use negative leftover.
    # This favors bins that become exactly full, then tight fits.
    return -(bins - item)
