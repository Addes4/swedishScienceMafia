import numpy as np

class _Tracker:
    def __init__(self):
        self.counts = np.zeros(101, dtype=np.int64)
        self.total = 0
        self.alpha = 0.0

_tracker = _Tracker()


def priority(item, bins):
    # Update online histogram of observed item sizes.
    _tracker.counts[item] += 1
    _tracker.total += 1

    n = bins.size
    # Default: best fit, i.e. smallest residual after placement.
    # residual = bins - item.  We want to avoid tiny unusable residuals
    # and prefer residuals that are themselves common future item sizes
    # or combinations thereof.
    #
    # Use a score that strongly prefers smaller positive residual,
    # but slightly deprioritizes residuals that are too small relative
    # to the typical item size.
    resid = bins - item  # >= 0 for all shown bins

    # Keep score finite and deterministic, favor tight fit.
    # A residual of 0 is best; residual just below a common item size is bad
    # because that slot may be hard to fill later.
    score = -resid.astype(np.float64)

    # Small penalty for residuals that are too small to be likely useful,
    # based on observed minimum positive item size.  This is very cheap.
    c = _tracker.counts
    total = _tracker.total
    if total >= 20:
        # probability weight that a residual r can accommodate some future item
        # computed from empirical distribution; approximate with min positive item.
        # Find smallest observed positive item size.
        idx = 1
        while idx <= 100 and c[idx] == 0:
            idx += 1
        min_item = idx if idx <= 100 else 1
        # Penalize residuals smaller than min_item (except zero) mildly.
        small = (resid > 0) & (resid < min_item)
        score[small] -= 0.5
    else:
        # Early: just best fit.
        pass

    return score
