import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum = 0
        # approximate histogram of item sizes; useful to bias toward remainders
        self.hist = np.zeros(101, dtype=np.int64)
        self.n_hist = 0

    def observe(self, item):
        self.n += 1
        self.sum += item
        if item < 101:
            self.hist[item] += 1
            self.n_hist += 1

    def pressure(self, rem, item):
        # Prefer bins whose remainder after placing is close to a size that is
        # likely to appear, so that the leftover space can later be filled well.
        if self.n_hist < 50:
            return 0.0
        left = rem - item
        if left <= 0:
            return 0.0
        # Sum probabilities of item sizes not exceeding left, but taper the
        # benefit for large leftovers so exact/near-exact fits dominate.
        h = self.hist[:left + 1]
        p = h.sum() / float(self.n_hist)
        # Geometric taper: very useful small leftovers are better than big ones.
        # Scale so it refines, not overrides, best-fit.
        return p * (1.0 - left / 100.0)


_s = _State()


def priority(item, bins):
    _s.observe(item)
    # Primary: best fit (tightest remaining capacity). Ties/near-ties are broken
    # by the chance that the leftover capacity will later be usable.
    best_fit = -(bins - item) * 1000.0
    bonus = np.array([_s.pressure(int(b), item) for b in bins], dtype=np.float64)
    return best_fit + bonus
