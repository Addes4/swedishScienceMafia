import numpy as np


def priority(item, bins):
    # Best fit: smallest remaining capacity after placing the item.
    residual = bins - item  # remaining capacity after placing in this bin

    # Primary: prefer bins that leave the least wasted space (tightest fit).
    # Pure best fit minimizes residual, but we add two corrective terms:
    #  1) Slight preference for already-used bins (residual < 100 - item) over
    #     opening/using a fresh bin, which reduces bin count modestly.
    #  2) A small penalty for bins that would end up nearly full but not full,
    #     encouraging exact fills (residual == 0) without disturbing primary order.

    # Identify unused bins (remaining capacity == 100).
    is_fresh = (bins == 100)

    # Score: higher is better. Base score strongly favors small residual.
    score = -residual.astype(np.float64)

    # Bonus for perfectly filling a bin.
    score += 2.0 * (residual == 0)

    # Mild bonus for using an already-opened bin instead of a fresh one.
    score -= 0.5 * is_fresh

    # Avoid leaving a tiny but nonzero remainder (1..4) if possible, unless
    # the alternative is also bad; tiny penalty pushes toward cleaner packing.
    tiny = (residual > 0) & (residual <= 4)
    score -= 0.1 * tiny

    return score
