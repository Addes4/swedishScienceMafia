import numpy as np

_state = {
    "last": {},
    "seen": 0,
}

def priority(item, bins):
    # Best fit with a bias: strongly prefer bins that become very full,
    # but avoid opening a new bin unless necessary.
    # Since bins are ordered, lower index bins tend to be older/more filled.
    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    # Main term: prefer the smallest remaining capacity after placing item
    # (classic best fit). Add a tiny index penalty to avoid spreading items
    # into new bins when equivalent choices exist.
    remaining_after = bins - item

    # Normalize into roughly [0,1] where 0 means exactly filled.
    # Use squared tightness to strongly reward near-perfect fits.
    tight = 1.0 - (remaining_after.astype(np.float64) / 100.0)
    tight = np.clip(tight, 0.0, 1.0)

    # Favor more-filled bins (smaller remaining capacity -> larger tight),
    # and within equal tightness favor earlier bins.
    idx = np.arange(n, dtype=np.float64)
    scores = tight * 1000.0 - idx * 1e-9

    # If a bin would be exactly filled, give a large bonus.
    exact = remaining_after == 0
    scores[exact] += 1e6

    return scores
