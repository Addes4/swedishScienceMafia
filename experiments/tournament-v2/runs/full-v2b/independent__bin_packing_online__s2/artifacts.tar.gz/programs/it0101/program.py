import numpy as np

def priority(item, bins):
    # Best fit: minimize remaining capacity after placing the item.
    # Equivalent to maximizing -(bins - item), i.e., maximizing item - bins.
    # Add a small bonus for fuller bins to strengthen tight packing among ties.
    # bins are remaining capacities; unused bins have 100.
    # Score higher = better.
    # Tight fit first: smaller remaining-after is better -> score = item - bins.
    # Secondary: prefer bins with smaller current remaining capacity (fuller bins)
    # to consolidate space.  Use a tiny epsilon to avoid changing primary order.
    return (item - bins).astype(np.float64) + 1e-9 * (-bins)
