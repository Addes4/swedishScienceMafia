import numpy as np

# State: track whether we've opened a new bin in this call chain indirectly via bins contents.
# bins is a copy each call, so we only use the current array.

def priority(item, bins):
    n = bins.shape[0]

    # Score vector.
    scores = np.empty(n, dtype=np.float64)

    # For each bin, score = -(remaining - item) for fitting bins (best fit),
    # but add a penalty for using a completely fresh bin (remaining == 100)
    # when the item is not sufficiently large, to reserve fresh bins.
    # Also add a small tie-break to prefer fuller bins.

    # We only see bins where item fits (all have remaining >= item).
    rem = bins.astype(np.float64)

    # Base: tightest fit => smallest remaining.
    base = -rem

    # Penalize opening a fresh bin for small items.
    # Threshold: only use fresh bins for items >= 50; below that, penalize.
    if item < 50:
        # strong penalty so fresh bins are last resort
        penalty = np.where(rem >= 100.0, -1000.0, 0.0)
    elif item < 70:
        penalty = np.where(rem >= 100.0, -200.0, 0.0)
    else:
        penalty = np.zeros(n, dtype=np.float64)

    # Small preference for bins that already have some items (rem < 100) even when using fresh
    # not needed since penalty handles it.

    scores = base + penalty

    # Tie-break: prefer lower bin index (handled by harness on ties) so no extra.
    return scores
