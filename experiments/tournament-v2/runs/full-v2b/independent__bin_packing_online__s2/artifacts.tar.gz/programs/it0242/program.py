"""Online bin packing: scored best-fit with item-size-dependent waste penalty."""
import numpy as np


def priority(item, bins):
    """Rank bins by a mix of tight fit and a small, item-dependent fudge.

    The item goes into the bin with the highest score; ties go to the first bin.
    For large items we prefer the tightest fit (minimize leftover).
    For small items we allow a tiny tolerance so they can fill nearly-full bins
    without leaving unusable slivers, which improves overall packing density.

    item: integer size of arriving item, 1..100.
    bins: numpy int64 remaining capacities of all fitting bins, in index order.
    """
    leftover = bins - item

    # Base: best fit (most negative leftover gets highest score)
    score = -leftover.astype(np.float64)

    # For small/medium items, gently reward bins that become exactly full or
    # leave a residual that can still hold a small item; penalize awkward residuals.
    # A residual of 0 is ideal; small residuals 1..9 are usually wasted.
    if item <= 60:
        # penalize tiny wasted slivers a bit, reward exact fill strongly
        small_waste = (leftover > 0) & (leftover < 10)
        score += np.where(small_waste, -0.5, 0.0)
        score += np.where(leftover == 0, 0.25, 0.0)

    # For large items, pure best fit is best; add negligible index tiebreak
    # so earlier bins are slightly favored, keeping the bin count stable.
    score += -1e-6 * np.arange(bins.shape[0], dtype=np.float64)

    return score
