"""Online bin packing with a best-fit-like scoring rule tuned for Weibull items."""
import numpy as np


def priority(item, bins):
    """Rank bins for the arriving item.

    The item goes to the bin with the highest score (first on ties).

    Strategy: primarily best fit (smallest remaining capacity that still fits),
    because best-fit tends to pack tightly. We use a monotone transform of the
    remaining capacity that increases the preference for fuller bins, while
    adding a mild preference against opening brand-new bins (remaining == 100)
    unless no partially filled bin is a reasonable fit.
    """
    remaining = bins.astype(np.float64)

    # Base: prefer bins with the smallest remaining capacity after placing,
    # i.e. tightest fit. -(remaining - item) equals -(remaining) + item,
    # item is constant across bins, so equivalently prefer small remaining.
    fit_slack = remaining - item

    # Score: strongly prefer small residual slack (best fit).
    score = -fit_slack

    # Mild extra: avoid wasting a nearly-empty bin if a good fit exists.
    # This helps keep spare large-capacity bins for future large items.
    # The effect is strongest for small items, negligible for large items.
    if item < 100:
        # Penalize bins that would remain very empty after placement,
        # but only mildly so genuine tight fits still win.
        waste = (remaining - item) / 100.0
        score = score - 0.5 * waste * (1.0 - item / 100.0)

    return score
