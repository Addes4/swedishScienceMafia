import numpy as np


def priority(item, bins):
    """Best-fit with a soft preference for already-used bins and good residual fit.

    Higher score wins. Ties broken by first bin.
    """
    # Primary: tighter fit is better => smaller (bins - item) => higher -(bins - item)
    rem = bins - item  # residual space after placing; >=0 since bins shown fit
    # Prefer small residual. Add a tiny penalty for completely full unused bins?
    # Used bins have remaining capacity < 100 (mostly); fresh bins have 100.
    # A small bonus for used bins helps avoid opening new bins unnecessarily but
    # must not override fit quality.
    bonus = np.where(bins < 100, 1e-6, 0.0)
    return -rem.astype(np.float64) + bonus
