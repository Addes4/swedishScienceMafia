import numpy as np


def priority(item, bins):
    """Best-fit with a mild preference for using already-open bins.

    The item must go into a feasible bin (bins >= item).  Among feasible bins we
    strongly prefer the tightest fit (smallest residual capacity), which is the
    standard Best-Fit rule.  A tiny secondary bonus is given to bins whose
    residual capacity is below 100 so that, in a tie, an already-used bin is
    chosen before opening a fresh one.  This never changes the primary ranking
    of tightness and so cannot hurt Best-Fit's packing quality, while it breaks
    equal-capacity ties in favor of existing bins.
    """
    residual = bins - item          # >= 0 for every bin shown
    score = -residual.astype(np.float64)
    # Reward bins that are not full/unused in a way that only breaks ties:
    # unused bins have residual == 100 -> penalty 200; used bins get <=199.
    score -= (bins == 100).astype(np.float64) * 200.0
    return score
