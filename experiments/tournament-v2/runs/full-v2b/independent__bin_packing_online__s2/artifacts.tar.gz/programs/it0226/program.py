import numpy as np


def priority(item, bins):
    """Best fit with mild anti-new-bin bias.

    The item should go to the feasible bin where it leaves the least remaining
    capacity (best fit).  If several bins are nearly equal, prefer an already
    opened bin over a completely empty bin, since opening a new bin is costly.
    """
    leftover = bins - item

    # Base score: prefer smaller resulting leftover capacity.
    score = -leftover.astype(np.float64)

    # Small penalty for bins that are still completely empty.  This breaks ties
    # toward existing partially-filled bins while preserving best-fit ordering.
    score[bins == 100] -= 0.25

    return score
