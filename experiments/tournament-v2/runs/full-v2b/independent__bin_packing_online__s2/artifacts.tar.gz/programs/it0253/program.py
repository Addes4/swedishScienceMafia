"""Online bin packing: best-fit with residual-size learning and near-perfect-fit preference."""

import numpy as np

_SIZE = 101
# Lightweight state: smoothed frequency of item sizes seen so far.
_counts = np.zeros(_SIZE, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Score each candidate bin; highest score wins, ties to earliest bin."""
    global _total
    _counts[item] += 1.0
    _total += 1.0

    # Base score: best fit (largest remaining capacity <= is punished after item).
    # Equivalent to preferring bins whose leftover after placement is smallest.
    leftover = bins - item

    # Avoid leaving tiny unusable gaps unless that gap itself is a likely future item.
    # Estimate probability of each leftover value from past item frequencies.
    freq = _counts / _total
    gap_value = freq[leftover] * 100.0  # scale to reasonable range

    # Strongly prefer exact fits; otherwise prefer small leftovers, but reward
    # leftovers matching popular item sizes.
    exact = (leftover == 0).astype(np.float64) * 1000.0

    # Main score: minimize leftover, with modest preference for useful gaps.
    score = -leftover.astype(np.float64) + gap_value + exact

    # Soft bonus for bins that were already partially used, to reduce fragmentation.
    used = (bins < 100).astype(np.float64) * 0.01
    return score + used
