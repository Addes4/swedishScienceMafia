"""Best-fit with slight fullness bias: pack items as tightly as possible."""
import numpy as np


def priority(item, bins):
    """Return priorities: prefer bins whose remaining capacity minus item is smallest.

    Equivalent to best fit: choose bin with smallest remaining capacity that still fits.
    Score = -(bin_remaining - item); highest score goes to tightest fitting bin.
    Ties go to the first bin, which naturally favors earlier (fuller) bins.
    """
    return -(bins - item)
