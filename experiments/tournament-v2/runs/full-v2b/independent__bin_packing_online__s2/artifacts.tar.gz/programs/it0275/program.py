import numpy as np


def priority(item, bins):
    # Prefer the bin with the smallest remaining capacity after placing the item.
    # This is equivalent to best fit, but expressed directly to avoid overflow and
    # to keep tie-breaking deterministic (first bin wins).
    # Slight curvature favors tighter fits and reduces fragmentation.
    residual = bins - item
    return -residual * (101.0 / (residual + 1.0))
