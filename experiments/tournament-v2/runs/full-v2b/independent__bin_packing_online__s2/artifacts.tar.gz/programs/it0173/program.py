import numpy as np


class OnlineBinPacker:
    def __init__(self):
        self.calls = 0
        self.seen_items = 0
        self.mean_item = 40.0
        self.best_fit_weight = 1.0

    def update(self, item):
        self.calls += 1
        self.seen_items += 1
        # Online running mean, kept only for possible light adaptation.
        self.mean_item += (item - self.mean_item) / self.seen_items


_PACKER = OnlineBinPacker()


def priority(item, bins):
    """Rank bins for the current item.

    The main rule is best-fit: prefer the bin with the smallest remaining capacity
    that still fits the item.  A small secondary term discourages creating or using
    moderately-filled bins when an empty bin and a tight bin are close in quality.
    """
    _PACKER.update(item)

    bins = np.asarray(bins, dtype=np.float64)
    rem = bins - item

    # Best fit score: lower remaining capacity after placement is better.
    # We use negative remaining capacity so that the highest score wins.
    best_fit = -rem

    # Mild anti-fragmentation adjustment.
    # - Perfect fits and near-perfect fits are strongly favored.
    # - Completely empty bins are slightly favored over creating a new partly-filled bin.
    # - Otherwise, bins with larger remaining capacity after placement are slightly penalized,
    #   already captured by best_fit; this term mostly helps break close ties.
    after = rem
    empty_bin_bonus = np.where(bins >= 100.0, 0.02, 0.0)

    # Prefer placements that either almost fill a bin or use an empty bin.
    closeness = (100.0 - after) / 100.0
    tiny_bonus = 0.0005 * closeness

    return best_fit + empty_bin_bonus + tiny_bonus
