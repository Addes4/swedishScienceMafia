import numpy as np

# Online histogram of item sizes (Laplace-smoothed), used to estimate how
# "useful" a leftover remainder is (a remainder equal to a common item size
# can later be filled exactly).
_counts = np.ones(101, dtype=np.float64)
_total = 101.0


def priority(item, bins):
    global _counts, _total

    # Learn the current item's size before scoring.
    _counts[item] += 1.0
    _total += 1.0

    rem = (bins - item).astype(np.float64)          # resulting free capacity
    base = -rem                                      # best fit: tighter is better
    idx = rem.astype(np.int64)
    prob = _counts[idx] / _total                     # likely future item uses this gap
    bonus = 8.0 * prob                               # kept < 1: only breaks ties
    return base + bonus
