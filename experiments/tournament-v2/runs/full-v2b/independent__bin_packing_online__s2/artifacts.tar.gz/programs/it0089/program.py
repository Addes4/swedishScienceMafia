"""Online bin packing priority rule: prefer exact fits, then fullest suitable bin."""

import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Prefer exact fits strongly.
    exact = bins == item
    # For non-exact bins, prefer fuller bins (smaller remaining capacity).
    # Empty bins (remaining capacity 100) should be least preferred.
    # Score: exact fits get a huge boost; otherwise use -remaining capacity.
    scores = -bins.astype(np.float64)
    scores[exact] = 1e6
    # Make empty bins less attractive than any used bin.
    empty = bins == 100
    # If the item itself is 100, exact match already covers empty bins and that's fine.
    if item < 100:
        scores[empty] -= 1e5
    return scores
