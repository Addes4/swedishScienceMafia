import numpy as np


class _State:
    def __init__(self):
        # Track count of items seen and their sizes for a crude online estimate.
        self.n = 0
        self.sum_sizes = 0.0
        # Number of bins whose residual is exactly capacity (untouched bins).
        self.empty_bins = 0
        # Threshold residual below which a bin is "nearly full".
        self.nearly_full = 25


_STATE = _State()


def priority(item, bins):
    """Heuristic bin-choice rule for online bin packing.

    item: integer size of arriving item (1..100).
    bins: numpy int64 array of remaining capacities of bins the item fits in.

    Returns a score per bin; highest score wins. Ties -> first bin.
    """
    st = _STATE
    st.n += 1
    st.sum_sizes += item

    b = bins.astype(np.float64)
    residual = b - item  # capacity left if item placed here; >= 0 guaranteed

    # Base preference: best fit -> smaller residual is better.
    score = -residual

    # Reserve untouched bins (residual == 100) slightly: prefer to use
    # partially-filled bins first, to keep full-capacity bins available
    # for large items. But if the item is large, using an empty bin is fine.
    empty_mask = (b == 100.0)
    if item < 60:
        score = np.where(empty_mask, score - 8.0, score)
    else:
        # Large items: mild penalty for empty bins only if item can't fill much
        score = np.where(empty_mask, score - 1.0, score)

    # Encouragement to consolidate: strongly reward making a bin close to full
    # (residual small) beyond linear best-fit, reducing fragmentation.
    # Small residuals get a bonus; moderately large residuals get a slight penalty.
    small_res_mask = residual <= st.nearly_full
    score = np.where(small_res_mask, score + (st.nearly_full - residual) * 0.5, score)

    return score
