import numpy as np


def priority(item, bins):
    """
    Online bin packing heuristic.

    Main idea:
    - Use best fit: prefer the bin whose remaining capacity is closest to the item.
    - Add a small bonus for partially used bins, so we don't open a fresh bin
      unless it is meaningfully better.
    - Add a very small index-based tie-breaker to keep behavior deterministic.
    """
    # Smaller (bins - item) means a tighter fit.
    fit_gap = bins - item

    # For an unused bin, remaining capacity is exactly 100.
    # Prefer partially used bins when the fit gap is similar.
    is_unused = (bins == 100).astype(np.int64)

    # Primary: best fit (negative gap).
    # Secondary: small penalty for unused bins.
    # Tertiary: tiny stable tie-breaker.
    idx = np.arange(bins.shape[0], dtype=np.int64)
    return -(fit_gap * 1000) - is_unused * 10 - idx * 1e-6
