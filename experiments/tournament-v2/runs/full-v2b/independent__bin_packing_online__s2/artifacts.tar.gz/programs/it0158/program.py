import numpy as np


def priority(item, bins):
    """Rank bins for online bin packing.

    Primary rule: best fit (smallest remaining capacity after placement).
    Secondary tweak: slightly prefer remainders that are less likely to be wasted,
    while still mainly following best fit.
    """
    rem = bins - item  # remaining capacity after putting the item in this bin

    # Best fit: smaller remainder is better.
    score = -rem.astype(np.float64)

    # Mildly penalize very small remainders, because they often become unusable.
    # This is a tiny correction: it should not override best fit in general.
    tiny = rem <= 3
    score[tiny] -= 0.25 * (4 - rem[tiny])

    return score
