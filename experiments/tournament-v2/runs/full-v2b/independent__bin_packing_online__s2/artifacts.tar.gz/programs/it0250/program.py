"""Online bin packing: prefer tight fits but discourage opening fresh bins."""
import numpy as np


def priority(item, bins):
    """Score each bin; highest wins. Bins are remaining capacities (int64).

    Core idea: best-fit (smallest residual after placing the item) is near-optimal
    online for many distributions. We add a penalty for empty bins (capacity 100)
    so that an item only opens a new bin when no existing bin gives a comparably
    tight fit. This reduces bin count on Weibull-like size distributions.
    """
    residual = bins - item  # >= 0 for all bins shown
    # Base: prefer the tightest fit (smallest residual).
    score = -residual.astype(np.float64)
    # Penalize unused bins slightly so existing partially-filled bins are favored.
    # The penalty is a small fraction of capacity so it only flips near-ties.
    empty = bins == 100
    score[empty] -= 1.0
    return score
