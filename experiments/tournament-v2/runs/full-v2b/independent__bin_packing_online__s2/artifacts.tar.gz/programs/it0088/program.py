"""Online bin packing: best fit plus a small anti-fragmentation tie-breaker."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Remaining capacity after placing the item.
    rem = bins - item

    # Best fit: prefer the smallest positive remainder.
    # To reduce fragmentation, slightly penalize remainders in the 1..12 range:
    # such leftovers are hard to reuse, whereas a fuller bin or a more open bin
    # can be better aligned with future items.
    leftover_penalty = np.where((rem > 0) & (rem <= 12), 0.35, 0.0)

    # Slight preference for using existing partially filled bins over opening
    # brand-new bins when fits are otherwise similar.
    new_bin_penalty = np.where(bins == 100, 0.10, 0.0)

    return -(rem.astype(np.float64) + leftover_penalty + new_bin_penalty)
