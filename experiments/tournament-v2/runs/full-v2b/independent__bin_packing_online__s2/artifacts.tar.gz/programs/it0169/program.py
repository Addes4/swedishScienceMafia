import numpy as np


def priority(item, bins):
    """
    Online bin-packing priority rule.

    Primary strategy: best fit (smallest remaining capacity after placement).
    Secondary strategy: lightly discourage opening/using very empty bins,
    which tends to reduce fragmentation across the 5000-item horizon.
    """
    # Best-fit score: larger (less negative) is better.
    # slack = bins - item is the remaining capacity after placing the item.
    slack = bins - item

    # Penalize large remaining bins slightly so we don't waste fresh bins.
    # This keeps best-fit dominance (slack varies by at least 1) while
    # breaking close calls toward already-used bins.
    # Scale is small relative to integer slack differences.
    score = -slack.astype(np.float64) - 0.002 * bins.astype(np.float64)

    return score
