"""Online bin packing: best-fit with fragmentation-aware tie-breaking."""
import numpy as np

USEFUL = 10  # a leftover below this is considered wasted/fragmenting


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    rem = bins - item  # remaining capacity if item placed here

    # Base: prefer tighter fits (smaller remainder). Negate so highest score wins.
    score = -rem.astype(np.float64)

    # Penalize bins that would be left with a tiny, likely-unusable leftover,
    # unless the fit is exact (rem == 0), which is ideal.
    small_leftover = (rem > 0) & (rem < USEFUL)
    score -= small_leftover * 5.0

    # Slight bonus for exact fits and for keeping large empty bins reserved:
    # exact fit is best; otherwise prefer leaving a comfortable chunk usable.
    exact = (rem == 0)
    score += exact * 3.0

    return score
