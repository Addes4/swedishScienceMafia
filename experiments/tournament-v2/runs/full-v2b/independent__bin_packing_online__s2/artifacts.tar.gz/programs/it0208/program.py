import numpy as np

# Online estimator of the item size distribution to inform the scoring.
_hist = np.zeros(101, dtype=np.float64)
_alpha = 0.02          # exponential forgetting for size frequencies
_total = 0.0           # total weighted observations

def priority(item, bins):
    global _hist, _total
    # ---- update running size histogram -------------------------------
    _hist *= (1.0 - _alpha)
    _hist[item] += _alpha
    _total = _hist.sum()

    # probability of observing an item of a given size
    p = _hist / _total if _total > 0 else np.full(101, 1.0 / 100.0)

    # small sizes (likely to still be placeable into a leftover) get weight
    small_weight = 0.0
    for s in range(1, 21):
        small_weight += p[s]
    # typical leftover that is "waste": below what most items need
    waste_scale = 0.0
    for s in range(1, 26):
        waste_scale += p[s] * s

    rem = np.asarray(bins, dtype=np.float64)
    leftover = rem - item          # remaining capacity after placing item

    # Best-fit core: prefer smallest non-negative leftover.
    # Penalise leftovers that are too small to be useful (create scrap).
    scrap = np.where(leftover < 15.0, 1.0, 0.0)
    penalty = scrap * (1.0 - small_weight) * waste_scale

    # Slight preference for keeping big empty bins free for large future items.
    fresh = np.where(rem >= 100.0, 1.0, 0.0)

    score = -leftover - penalty - 0.5 * fresh
    return score
