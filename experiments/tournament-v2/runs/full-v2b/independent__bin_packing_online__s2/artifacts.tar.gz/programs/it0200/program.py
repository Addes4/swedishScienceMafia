"""Online bin packing heuristic: conservative best-fit with empty-bin reservation."""

import numpy as np

# Running statistics for the sizes seen so far (online adaptation).
_count = 0
_sum = 0.0
_sum_sq = 0.0

# Tuned reference distribution mean (~40) and std.
_TARGET_MEAN = 40.0
_TARGET_STD = 22.0


def priority(item, bins):
    """Rank bins for the arriving item; highest score wins (ties -> first/LBY index).

    Strategy:
      - Among bins that already contain items (remaining < 100), prefer the
        tightest fit (best fit / smallest leftover).
      - Strongly discourage opening brand-new bins (remaining == 100) unless
        there is no good existing fit.
      - Slightly modulate the empty-bin penalty based on whether the current
        item is larger or smaller than the observed average, reserving empty
        bins for larger incoming items.
    """
    global _count, _sum, _sum_sq
    _count += 1
    _sum += item
    _sum_sq += item * item

    n = bins.size
    b = bins.astype(np.float64)

    # Top-level score: smaller remaining capacity gets higher score.
    score = -b

    empty = (bins == 100)

    # Penalty for using a completely empty bin (opening a new bin).
    # Base penalty large enough that any existing bin wins over an empty one
    # when a reasonable fit exists, but scaled by how tight the fit is.
    # Smaller items get a higher penalty: keep empty bins for big items.
    #
    # Estimate running mean/std of item sizes.
    if _count > 1:
        mean = _sum / _count
        var = max(_sum_sq / _count - mean * mean, 0.0)
        std = var ** 0.5 if var > 0 else _TARGET_STD
    else:
        mean = _TARGET_MEAN
        std = _TARGET_STD

    # z > 0 => item larger than average => reduce empty-bin penalty.
    z = (item - mean) / (std + 1e-9)
    z = float(np.clip(z, -2.0, 2.0))

    # Base empty penalty: bigger than max possible remaining difference (100).
    # Actually we want empty bins to be chosen only when they clearly beat
    # existing bins. Using a penalty around 55 keeps behavior close to best fit
    # but avoids exhausting partially filled bins inefficiently.
    base_penalty = 55.0
    penalty = base_penalty * (1.0 - 0.18 * z)

    # Apply the penalty to empty bins only.
    score = np.where(empty, score - penalty, score)

    # Small preference to keep bins more tightly packed: already encoded by -b.
    # Encourage filling bins that are already fairly full (small remaining)
    # rather than leaving many bins with medium leftovers.
    return score
