import numpy as np

class BestFitTieBreak:
    def __init__(self):
        # State: track recent item sizes for light adaptivity
        self.recent = []
        self.count = 0

    def priority(self, item, bins):
        # Best fit: prefer smallest remaining capacity >= item
        # Score higher for tighter fit, break ties preferring "better" residuals.
        # We want residual r = bins - item.
        # A perfect fill (r == 0) is best. Otherwise, avoid r in 1..small
        # because those leftover capacities are hard to fill later.
        # We use a score that is primarily -(bin_remaining - item) so best-fit wins,
        # then add a tiny tie-breaker that penalizes very small residuals (1..5)
        # and slightly favors residuals that are near item sizes (easier to pair).
        
        remainder = bins - item  # >= 0 for shown bins
        
        # Primary: tighter fit is better (smaller remainder)
        score = -remainder.astype(np.float64)
        
        # Tie-breaker: prefer perfect fill (remainder 0) strongly
        # Penalize remainders that are "awkward" (1..9) slightly less fit than they are
        # since they waste space. Add a small bonus for remainder==0.
        # Use a small epsilon relative to differences so it only affects ties.
        eps = 1e-6
        
        # bonus for exact fill
        exact = (remainder == 0).astype(np.float64)
        score += eps * 2.0 * exact
        
        # penalize tiny remainders (1..5) slightly, as they are nearly unusable
        tiny = ((remainder >= 1) & (remainder <= 5)).astype(np.float64)
        score -= eps * 1.0 * tiny
        
        # Slightly favor remainders that equal or exceed common item sizes? 
        # Without distribution info, just slight preference for larger residuals
        # when fit is equal (handled by first index already).
        
        return score


# Module-level state
_state = BestFitTieBreak()

def priority(item, bins):
    """Entry point: returns scores for each bin. Highest score wins (first on ties)."""
    return _state.priority(item, bins)
