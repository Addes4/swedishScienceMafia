# EVOLVE-BLOCK-START
"""Online bin packing: best fit with a mild completion bias.

The arriving item must be placed immediately.  Best fit (pack into the currently
tightest bin that still fits) is a strong, distribution-agnostic online rule.  We
add a very small preference for bins whose remaining capacity is already small, so
that nearly-full bins tend to be completed and closed instead of being left as
fragments.  This is the classic best-fit heuristic; the added bias is deliberately
tiny so it never overrides the tightness ordering in a harmful way.
"""
import numpy as np


def priority(item, bins):
    """Rank bins for the arriving item; highest score wins, first on ties.

    item: integer size 1..100.
    bins: numpy int64 array of remaining capacities (all bins the item fits in).
    """
    # Best fit: the bin with the smallest remaining capacity that can still hold
    # the item gets the highest score.  Adding `item` turns "remaining capacity"
    # into "resulting leftover", and negating makes the smallest leftover best.
    #
    # A tiny tie-breaking nudge towards already-tight bins encourages closing them.
    # It is scaled to be strictly smaller than one unit of resulting leftover so it
    # cannot reverse the true best-fit preference.
    bins = np.asarray(bins)
    leftover = bins - item
    return -leftover + (100 - bins) * 1e-6
# EVOLVE-BLOCK-END
