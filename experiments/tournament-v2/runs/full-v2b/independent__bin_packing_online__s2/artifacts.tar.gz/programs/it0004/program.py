"""Hybrid best-fit: prefer tightest fit, strongly prefer exact fills, mild tie-break by index."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 because only fitting bins are shown

    # Base: best fit -> smallest residual gets highest score.
    score = -residual.astype(np.float64)

    # Strongly favor bins that become exactly full (residual == 0).
    exact_full = (residual == 0)
    score[exact_full] += 1000.0

    # Mildly favor leaving a small but nonzero residual to avoid burning fresh bins.
    # (Already captured by -residual; exact-full override dominates.)

    # Tiny deterministic tie-break: earlier bins slightly preferred when residuals equal.
    n = bins.shape[0]
    if n > 0:
        score -= np.arange(n, dtype=np.float64) * 1e-6

    return score
