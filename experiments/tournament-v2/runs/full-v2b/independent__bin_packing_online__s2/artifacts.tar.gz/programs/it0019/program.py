"""Online bin packing heuristic: adaptive best-fit with tie-breaking.

Mostly use best-fit (place item so remaining capacity after placement is smallest),
but add tiny bias against unused bins and use online statistics to break near-ties
in favor of bins that have historically received similar-sized items.
"""
import numpy as np

# Small state kept across calls for the current instance.
_STATE = {
    'count': 0,
    'sum_items': 0.0,
    'bins_used': 0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest priority wins (first on ties)."""
    n = len(bins)
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # --- update simple online stats (instance-level, reset not needed per call) ---
    _STATE['count'] += 1
    _STATE['sum_items'] += float(item)
    mean_item = _STATE['sum_items'] / _STATE['count'] if _STATE['count'] else 40.0

    # --- core: best fit -> smaller remaining capacity after placement is better ---
    remaining_after = bins - item  # item already fits, so >= 0
    # Primary score: negative of remaining after (tighter fit = higher score).
    score = -(remaining_after.astype(np.float64))

    # --- tie-breaking / small bias ---
    # Unused bins (capacity still 100) are slightly penalized so we don't open a
    # new bin when an existing one fits nearly as tightly.  This encourages
    # consolidation without changing the basic best-fit ordering much.
    is_unused = (bins == 100)
    # Penalty magnitude: small relative to 1 unit of remaining capacity, so it
    # only affects ties or near-ties (within a fraction of a capacity unit).
    score[is_unused] -= 0.35

    # Secondary tie-break: among bins with similar leftover, prefer the one whose
    # "leftover" is a plausible future fit.  Use fractional part of remaining
    # capacity relative to a typical item size to add a tiny deterministic jitter,
    # breaking ties toward more useful partial fills.
    if mean_item > 0:
        frac = remaining_after.astype(np.float64) / mean_item
        score -= 0.01 * (frac - np.floor(frac))

    # Final tiny tie-break on bin order is implicit: equal scores -> first wins.
    return score
