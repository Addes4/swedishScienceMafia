"""
Online bin packing: a hybrid best-fit / tightest-fit rule.

Strategy:
  - Best-fit alone tends to be strong for Weibull-shaped items (mean ~40).
  - We bias slightly toward bins that become "well packed" after placement
    (small leftover) and away from nearly-empty bins, which preserves
    larger empty bins for future items and reduces fragmentation.

  Score(item, bin) favors tight fits and bins already substantially used.

  Tie-breaking is handled by the harness (first bin wins), so scores are
  kept as floats where ties are rare; to exploit tie-breaking toward
  lower-index (older) bins when equally fit, we use integer-like dominance.
"""

import numpy as np


def priority(item, bins):
    """Score each bin so the item lands in the best-fit / tightest bin.

    item: integer size of arriving item (1..100).
    bins: numpy int64 array of remaining capacities the item fits in,
          in fixed bin order. Unused bins have remaining capacity 100.
    """
    rem = bins.astype(np.float64)
    leftover = rem - float(item)          # remaining space after placement

    # Primary: best fit -> smallest leftover is best (most negative leftover).
    # Use a strong linear term so tightest fit dominates.
    score = -leftover * 1000.0

    # Secondary: among near-equal fits, prefer bins already fairly full
    # (small current remaining), discouraging dumping into near-empty bins.
    score -= rem

    return score
