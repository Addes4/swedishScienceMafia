"""Best-fit bin packing: place each item in the fullest bin that still fits it.

The item goes to the bin with the smallest remaining capacity that is >= item size,
which minimizes wasted space per placement. Ties are broken by original bin order
(achieved by returning scores that are monotone in remaining capacity but not equal).

We return scores = -(bins - item) so the tightest fit gets the highest score.
To break ties toward earlier bins deterministically without changing the choice,
we add a tiny decreasing offset based on bin index. Because `bins` is a copy in
fixed bin order, index derived from position works.
"""
import numpy as np


def priority(item, bins):
    # Primary: prefer smallest remaining capacity that fits => tightest fit.
    # Secondary (tiny): prefer lower bin index on ties.
    fit = bins - item
    n = bins.shape[0]
    # tiny index-based tie-break; magnitude far below integer gaps so it never
    # overrides the true best-fit comparison for distinct capacities.
    idx = np.arange(n, dtype=np.float64)
    return -(fit.astype(np.float64)) * 1024.0 - idx * 1e-6
