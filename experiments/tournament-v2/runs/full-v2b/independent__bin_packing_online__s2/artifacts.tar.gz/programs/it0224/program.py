import numpy as np


def priority(item, bins):
    # Best-fit: smaller remaining capacity after placing is better.
    # Penalize unused bins slightly so we prefer to reuse bins.
    # score = -(bins - item) + small bonus for non-full bins
    remaining_after = bins - item
    score = -remaining_after.astype(np.float64)

    # Prefer not to open brand new bins (remaining capacity == 100) unless needed.
    # A small penalty makes us choose an existing partially filled bin when
    # the resulting waste difference is small.
    score -= (bins == 100).astype(np.float64) * 0.5

    return score
