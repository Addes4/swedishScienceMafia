"""Randomized best-fit variant for online bin packing.

This keeps the classic best-fit idea (prefer the smallest sufficient remaining
capacity) but occasionally chooses a markedly looser bin when the item is large
relative to the best candidate.  The randomization is seeded deterministically
per process, so it is stable across calls and not tuned to any single instance.
"""

import numpy as np


class _State:
    __slots__ = ("rng",)

    def __init__(self):
        # Deterministic, fast RNG.  The exact seed is not important as long as
        # the behaviour is consistent across the hidden instances.
        self.rng = np.random.default_rng(0x9E3779B97F4A7C15)


_state = _State()


def priority(item, bins):
    """Rank bins for an arriving item using a randomized best-fit rule."""
    # Work on a float copy to avoid any integer overflow surprises.
    remaining = bins.astype(np.float64, copy=False)

    # Primary score: tightest fit gets the largest value.
    score = -remaining

    best = int(np.argmin(remaining))
    best_rem = remaining[best]

    # For a large item, sometimes deliberately take a much looser bin instead
    # of the tightest one.  This helps avoid creating many near-full bins that
    # later items cannot use well.  The trigger is deterministic per call via a
    # cheap hash-like function of the item and the best remaining capacity.
    if item >= 50 and best_rem < item + 8:
        h = (item * 1000003 + int(best_rem) * 9176 + _state.rng.integers(0, 1 << 30)) & 0xFFFF
        if h < 2185:  # roughly 1 in 30 for these large, tight fits
            # Prefer a bin with substantially more room, if one exists.
            slack = remaining - best_rem
            candidates = np.flatnonzero((slack > 12) & (remaining >= item))
            if candidates.size:
                # Among looser bins, prefer the one that is not excessively
                # empty, again in the best-fit spirit but shifted upward.
                chosen = int(candidates[np.argmin(remaining[candidates])])
                score[chosen] += 1e6

    return score
