import numpy as np


def priority(item, bins):
    # Best-fit: prefer the bin whose remaining capacity is closest to the item.
    # Slightly penalize completely empty bins so they are opened only when useful.
    scores = -(bins - item)
    scores[bins == 100] -= 0.01
    return scores
