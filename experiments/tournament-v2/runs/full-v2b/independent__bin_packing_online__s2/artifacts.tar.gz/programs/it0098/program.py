import numpy as np


def priority(item, bins):
    # Best-fit: minimize leftover capacity after placing the item.
    # On ties, prefer bins with larger remaining capacity (emptier bins),
    # which slightly helps preserve tight fits for future items.
    rem_after = bins - item
    return -rem_after.astype(np.float64) + 1e-7 * bins.astype(np.float64)
