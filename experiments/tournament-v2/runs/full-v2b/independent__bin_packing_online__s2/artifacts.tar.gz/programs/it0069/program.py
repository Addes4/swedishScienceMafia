import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: maximize negative leftover.  Add a tiny preference for lower-index bins
    # to make tie-breaking deterministic and slightly favor already-packed early bins.
    leftover = bins - item
    idx = np.arange(bins.shape[0], dtype=np.float64)
    return -leftover - 1e-6 * idx
