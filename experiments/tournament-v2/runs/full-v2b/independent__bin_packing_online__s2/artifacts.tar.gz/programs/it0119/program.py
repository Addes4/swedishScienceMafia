import numpy as np


class _State:
    def __init__(self):
        # Running statistics of seen item sizes to inform bin selection.
        self.count = 0
        self.mean = 40.0
        # Histogram over sizes 1..100 (smoothed) to estimate probability of future items.
        self.hist = np.ones(101, dtype=np.float64)
        self.hist /= self.hist.sum()


_state = _State()


def priority(item, bins):
    """Score each bin; the item goes to the highest score (first on ties).

    Approach: adaptive best-fit. Prefer bins whose remaining capacity after the item
    is smallest, but discount opening a fresh (empty) bin, and use a running estimate
    of item sizes to slightly prefer filling bins well for likely future items.
    """
    s = _state

    # Update running statistics with the arriving item.
    s.count += 1
    # Exponential-ish running mean (decay ~ 1/400 keeps it responsive over 5000 items)
    alpha = 1.0 / min(s.count, 400)
    s.mean = (1.0 - alpha) * s.mean + alpha * item
    # Update smoothed histogram
    s.hist[item] += 1.0
    total = s.hist.sum()
    if total > 1e7:
        s.hist *= 0.5
        total = s.hist.sum()
    prob = s.hist / total

    b = bins.astype(np.float64)
    # Remaining capacity after placing item.
    remaining_after = b - item

    # Best fit: smaller remaining after is better.
    score = -remaining_after

    # Estimate the expected "waste" if we leave this slack: probability some future
    # item can't fit and we still have to leave it unused. Prefer to avoid tiny
    # unusable slacks: penalize very small positive residuals slightly.
    small_slack = np.where(remaining_after > 0, remaining_after, np.inf)
    score -= 0.02 * np.where(small_slack < 5.0, (5.0 - small_slack), 0.0)

    # Discount packing into a brand-new bin (remaining == 100 suggests unused bin).
    # Slightly discourage opening new bins; keep scarce empty bins for larger items.
    is_fresh = b >= 100.0
    # Prefer not to open a new bin unless the item is relatively large.
    big_item = item >= s.mean
    penalty = 3.0 if not big_item else 0.5
    score = np.where(is_fresh, score - penalty, score)

    return score
