import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sum_sizes = 0.0
        self.hist = np.zeros(101, dtype=np.float64)
        self.recent = []
        self.max_recent = 200

_state = _State()


def _reset_state():
    _state.n = 0
    _state.sum_sizes = 0.0
    _state.hist[:] = 0.0
    _state.recent = []


def priority(item, bins):
    bins = np.asarray(bins)
    n_bins = bins.shape[0]

    # Update running stats
    _state.n += 1
    _state.sum_sizes += item
    _state.hist[item] += 1.0
    if len(_state.recent) < _state.max_recent:
        _state.recent.append(item)
    else:
        # circular-ish: replace oldest
        _state.recent[_state.n % _state.max_recent] = item

    if n_bins == 0:
        return np.array([], dtype=np.float64)

    item_f = float(item)

    # Remaining space after placing item
    rem_after = bins.astype(np.float64) - item_f

    # Score: primary = best fit (smaller rem_after is better)
    # Base: negative rem_after (so higher is better)
    score = -rem_after

    # Strong bonus for exact fit (rem_after == 0)
    exact_mask = (rem_after == 0.0)
    if exact_mask.any():
        score = score + exact_mask.astype(np.float64) * 1000.0

    # Bonus for near-exact fits (rem_after small)
    # and penalty for leaving medium-sized holes (bad for future mid items)
    # Only apply when not exact
    non_exact = ~exact_mask
    if non_exact.any():
        r = rem_after[non_exact]
        # Near-exact bonus: e.g., 1..10 leftover gets a bonus shrinking with size
        near_bonus = np.where(r <= 10.0, (10.0 - r) * 5.0, 0.0)
        # Fragmentation penalty: leaving 11..50 free is bad because many items are ~40
        # Slight penalty increasing with leftover up to some point
        frag_penalty = np.where((r > 10.0) & (r < 60.0), (r - 10.0) * 0.05, 0.0)
        score[non_exact] = score[non_exact] + near_bonus - frag_penalty

    # Discourage opening brand-new bins unless necessary: unused bins have capacity 100,
    # i.e., rem_after = 100 - item. If there are already partially-used bins,
    # slightly penalize fresh bins to reduce bin count.
    if n_bins > 1:
        fresh_mask = (bins == 100) & (item_f < 100.0)
        if fresh_mask.any():
            # Count how many bins are non-fresh (already used)
            used = np.count_nonzero(bins < 100)
            if used > 0:
                # small penalty for opening a new bin; grows if many used bins
                penalty = min(2.0, 0.2 + 0.01 * used)
                score[fresh_mask] = score[fresh_mask] - penalty
            else:
                # Very first item(s): no penalty; best-fit handles it.
                pass

    return score
