# EVOLVE-BLOCK-START
"""Hybrid best-fit / worst-fit online bin packing heuristic."""

import numpy as np


def priority(item, bins):
    """Score bins so the arriving item lands in a good residual-capacity gap.

    The item goes to the highest-scoring bin (ties go to the first bin).

    Strategy:
    - Normally rank by best fit: smallest remaining capacity that still fits
      the item, i.e. maximize -(bins - item).
    - When the item is "small" relative to a fresh bin (<= 50), prefer an
      untouched bin (remaining == 100) to avoid fragmenting a fresh bin for
      a tiny item, then fall back to best fit among non-fresh bins.
    - When the item is large (> 50), pure best fit is best.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins.
    """
    remaining_after = bins - item

    if item <= 50:
        # Slight preference to untouched bins, then best fit.
        fresh_bonus = (bins == 100).astype(np.float64) * 1000.0
        return fresh_bonus - remaining_after

    # Best fit: tightest gap.
    return -remaining_after
# EVOLVE-BLOCK-END
