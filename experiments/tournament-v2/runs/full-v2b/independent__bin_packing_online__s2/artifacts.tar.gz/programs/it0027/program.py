"""Hybrid online bin-packing priority rule.

Core idea: score bins by residual capacity after insertion, with incentives:
  - prefer tight fits (Best Fit) to limit fragmentation
  - slightly discourage opening fresh (100-capacity) bins
  - mildly reward leaving a bin with residual >= median-ish leftover
This is a lightweight tuned heuristic (no learning, no state needed) that
matches Best-Fit performance on Weibull(mean ~40) workloads while shaving
off some fragmentation via the fresh-bin penalty.
"""
import numpy as np

# Precompute a scale factor once
_INV100 = 1.0 / 100.0


def priority(item, bins):
    # residual after placing item into each bin
    residual = bins - item  # all entries >= 0 because harness filters fitting bins

    # Score: higher is better.
    # Base: negative residual (i.e., Best Fit) -> tighter fits score higher.
    score = -residual.astype(np.float64)

    # Penalize opening completely fresh bins (remaining capacity == 100)
    # so that partially-filled bins are preferred when fit quality is similar.
    fresh = (bins == 100)
    score -= fresh.astype(np.float64) * 1.5

    # Mild bonus for bins that will still have meaningful room left,
    # which helps future medium items; saturates quickly.
    leftover_bonus = np.minimum(residual, 20).astype(np.float64) * 0.02
    score += leftover_bonus

    return score
