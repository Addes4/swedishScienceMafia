import numpy as np

# State: exponentially weighted estimate of recent item size.
_state = {
    "mean": 40.0,
    "count": 0,
}


def priority(item, bins):
    """Rank bins by an adaptive best-fit rule with slight anti-fragmentation bias."""
    global _state

    # Update a running mean item size.  The distribution is stationary, so this
    # mainly helps us set the desired post-placement slack.
    c = _state["count"]
    _state["mean"] = (_state["mean"] * c + item) / (c + 1.0)
    _state["count"] = c + 1

    # Desired remaining capacity after inserting the item.  A small positive
    # slack avoids filling bins too perfectly and leaving awkward leftovers.
    # Using a fraction of the recent mean keeps the rule adaptive.
    target_slack = 0.15 * _state["mean"]

    # After placing, remaining capacity would be bins - item.
    post = bins.astype(np.float64) - item

    # Score: prefer post-placement remaining capacity close to target_slack.
    # Empty bins (post == 100 - item, i.e. bins == 100) are slightly penalized
    # so that we keep using already-open bins before opening new ones, which
    # tends to reduce bin count on this distribution.
    score = -np.abs(post - target_slack)

    # Slight preference for non-empty bins.  The penalty is small enough not to
    # override best-fit choices when they matter, but large enough to avoid
    # opening a fresh bin when a decent existing fit exists.
    score -= 0.01 * (bins == 100)

    return score
