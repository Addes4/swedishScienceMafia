import numpy as np

_STATE = {
    "seen": {},          # bin index -> was ever used? (not strictly needed here)
    "items": 0,
    "sum_items": 0.0,
    "waste": 0.0,
}

def priority(item, bins):
    """
    Online bin packing priority.

    Best-fit-like rule with extra preference for exact/perfect fits, but avoids
    treating completely empty bins as if they were a tight fit when an existing
    useful bin can absorb the item.

    Since `bins` contains only bins the item fits in, an unused bin has capacity 100.
    """
    bins = np.asarray(bins, dtype=np.int64)

    # Score components:
    # - perfect fit (remaining == item) gets a very large bonus
    # - otherwise prefer the smallest remaining capacity (best fit)
    # - slight reward for non-empty bins to pack before opening new ones
    rem = bins

    # Exact fit is extremely valuable.
    perfect = (rem == item)

    # Best fit: smaller remaining capacity is better.
    # Use negative remaining capacity; scale so exact-fit bonus dominates.
    score = -rem.astype(np.float64)

    # Penalize unused bins slightly relative to already-used ones.
    score += np.where(rem == 100, -0.25, 0.0)

    # Strongly prefer exact fits.
    score += np.where(perfect, 1_000_000.0, 0.0)

    return score
