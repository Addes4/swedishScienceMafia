import numpy as np


def priority(item, bins):
    """Best fit with a mild preference for already-used bins."""
    # Primary score: tighter fit = larger (less remaining capacity after placing item).
    score = -(bins - item)

    # Secondary: among bins with the same residual, prefer bins that are already in use
    # (remaining capacity < 100) over completely unused bins. This avoids opening a new
    # bin when an existing one gives the same tight residual.
    used_bonus = (bins < 100).astype(np.int64)
    return score.astype(np.int64) * 128 + used_bonus
