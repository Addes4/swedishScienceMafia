import numpy as np

_state = {
    "count": 0,
    "sum": 0.0,
}

def priority(item, bins):
    _state["count"] += 1
    _state["sum"] += item
    avg = _state["sum"] / _state["count"]
    
    n = len(bins)
    # Score: prefer bins where remaining capacity after placing is small (tight fit).
    # Tie-break unused bins (cap 100) slightly: if avg is small, opening new bins is cheap;
    # if avg is large, better to fill existing partially-used bins.
    scores = np.empty(n, dtype=np.float64)
    for i in range(n):
        rem = bins[i]
        leftover = rem - item
        if rem == 100:
            # unused bin: small preference to avoid opening unless necessary
            penalty = 0.01 * (100.0 - avg) if avg < 100 else 0.0
            scores[i] = -leftover - penalty
        else:
            scores[i] = -leftover
    return scores
