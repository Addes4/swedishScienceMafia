import numpy as np

def priority(item, bins):
    # Best fit: prefer bins where the remaining capacity after placing is smallest.
    # bins >= item always (harness filters), so bins - item >= 0.
    residual = bins - item
    
    # Avoid opening new bins (capacity 100) unless necessary:
    # add a small penalty to empty bins so partial bins are preferred.
    # Penalty must be small enough not to override genuine better fits.
    score = -residual.astype(np.float64)
    empty = (bins == 100)
    score[empty] -= 1e-6 * item  # prefer using existing partial bins first
    
    return score
