import numpy as np

# We track some global state to adaptively bias placement.
_state = {
    "count": 0,
    "item_sum": 0.0,
    "bin_open_count": 0,
}

def priority(item, bins):
    """Rank bins for best-fit with adaptive tuning for Weibull-like item sizes."""
    # Best-fit score: prefer bins where the remaining space after placement is smallest.
    # residual = bins - item
    # We want to minimize residual, i.e. maximize -residual.
    # But we also want to avoid opening new bins needlessly when a reasonably tight fit exists,
    # and to prefer filling bins completely when close.
    
    residual = bins - item
    
    # Base score: tighter fit is better (higher score).
    # Use -(residual) so smaller residual -> higher score.
    score = -residual.astype(np.float64)
    
    # Strongly prefer exact fills (residual == 0) and very tight fits.
    # Add a large bonus for residual == 0, small bonus for residual small.
    tight_bonus = np.where(residual == 0, 1000.0,
                  np.where(residual <= 5, 50.0,
                  np.where(residual <= 10, 10.0, 0.0)))
    score += tight_bonus
    
    # Penalize using a completely empty bin (remaining capacity == 100) slightly,
    # to encourage consolidation. But if item > 50, pairing may be impossible, so less penalty.
    # Since mean ~40, most items < 60; pairing is often possible.
    empty_mask = (bins == 100)
    if item <= 60:
        score -= np.where(empty_mask, 2.0, 0.0)
    else:
        # Large items: don't penalize empty bins much; they need space.
        score -= np.where(empty_mask, 0.5, 0.0)
    
    # Slight preference for bins that already contain something but still have space
    # (i.e., partially filled, not full). This helps avoid fragmentation.
    # A bin with remaining capacity between item and 100 (nonzero residual) is partially filled.
    partial_mask = (bins < 100) & (bins >= item)
    score += np.where(partial_mask, 1.0, 0.0)
    
    # Update global stats (not used for scoring here, but could be for adaptation).
    _state["count"] += 1
    _state["item_sum"] += item
    
    return score
