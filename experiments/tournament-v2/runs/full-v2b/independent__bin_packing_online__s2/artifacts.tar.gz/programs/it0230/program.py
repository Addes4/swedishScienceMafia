import numpy as np


def priority(item, bins):
    """Rank bins for an arriving item.

    Strategy:
    - Prefer bins that already contain something over completely empty bins,
      unless no non-empty bin can fit the item.
    - Among fitting bins, use best fit: smallest remaining capacity that can
      still hold the item.
    - Add a tiny deterministic tie-breaking term based on bin index to make
      behavior stable and reduce accidental bad fragmentation.
    """
    # Base score: best fit over non-empty bins. Empty bins get a small penalty.
    # bins are remaining capacities, so smaller capacity that still fits is better.
    fit = bins - item

    # Penalize completely empty bins slightly so items tend to fill existing bins first.
    empty_penalty = np.where(bins == 100, 0.01, 0.0)

    # Tiny index-based tie breaker: earlier bins very slightly preferred.
    # This is stable and deterministic.
    idx = np.arange(bins.shape[0], dtype=np.float64)
    index_tie = -idx * 1e-6

    # Higher score is better. Best fit means we want smaller remaining capacity
    # after placement, i.e. smaller (bins - item), so use negative.
    score = -(fit.astype(np.float64)) - empty_penalty + index_tie

    return score
