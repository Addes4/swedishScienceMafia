"""Best-fit variant with quadratic fullness bias."""
import numpy as np


def priority(item, bins):
    """Rank bins by a combination of fit tightness and fullness.

    The item goes into the bin with the highest score (first on ties).
    We prefer bins with small remaining capacity (best fit), but add a
    quadratic term encouraging fuller bins to reduce fragmentation.
    Unused bins (capacity 100) get the lowest priority when a used bin
    can hold the item.
    """
    # Best fit: smaller remaining capacity is better -> negative remaining
    # Quadratic fullness bonus: penalize large remaining capacity more
    # Use float to allow smooth combination
    remaining = bins.astype(np.float64)
    # Score: prefer tight fit (low remaining) and fuller bins
    # -(remaining) primary, plus small quadratic encouragement of fullness
    score = -remaining - 0.01 * (remaining * remaining) / 100.0
    # Unused bins (remaining == 100) should only be used if necessary.
    # Since all bins shown fit the item, unused bins have remaining 100.
    # Give them a slight extra penalty so used bins are preferred.
    score = np.where(bins == 100, score - 1.0, score)
    return score
