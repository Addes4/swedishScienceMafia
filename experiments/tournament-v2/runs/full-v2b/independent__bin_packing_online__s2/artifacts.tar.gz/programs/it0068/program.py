import numpy as np

# Tunable parameters (kept mild to avoid overfitting a single instance)
_TYPICAL_SMALL = (2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 20, 25, 30, 40)

# State across calls: track how many items seen (to allow slight adaptation)
_state = {"n": 0}


def priority(item, bins):
    """Rank bins: mostly best fit, with a bonus for useful residual gaps and
    a mild penalty for opening fresh bins."""
    bins = np.asarray(bins, dtype=np.int64)
    n = _state["n"]
    _state["n"] = n + 1

    leftover = bins - item  # >= 0 for all shown bins

    # Base score: prefer tighter fit (smaller leftover).
    score = -(leftover.astype(np.float64))

    # Bonus if the leftover capacity is exactly a common small-to-medium item size,
    # so the residual gap can still hold a typical future item without waste.
    bonus = np.zeros_like(score)
    for t in _TYPICAL_SMALL:
        bonus += (leftover == t) * 0.6
    score += bonus

    # Prefer used bins over completely empty bins slightly, to conserve empty bins.
    # Empty bins have remaining capacity 100 (and fit the item).
    empty = (bins == 100)
    score -= empty * 0.05

    # Strongly avoid reducing a bin to leftover 0 unless item is large, since that
    # perfectly fills only marginally better than leaving a small reusable gap.
    # (Tiny extra reward for exact fill, but not overriding gap usefulness.)
    score += (leftover == 0) * 0.1

    # Tie-break deterministically by original bin order: ties go to first, which
    # numpy argmax already handles. Ensure no NaN.
    return score
