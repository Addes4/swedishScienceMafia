import numpy as np


def priority(item, bins):
    """Score bins for online bin packing.

    Best-fit puts the item in the fullest bin in which it fits (smallest
    remaining capacity).  A small step function penalty is added to unused
    bins so that we prefer placing items into already-open bins, reserving
    empty bins until truly necessary.  This is the classic almost-best-fit
    improvement and is distribution-independent.

    Parameters
    ----------
    item : int
        Size of the arriving item (1..100).
    bins : numpy.ndarray[int64]
        Remaining capacities of the bins the item fits in, in bin order.

    Returns
    -------
    numpy.ndarray
        Higher score => better bin.  Ties broken by first occurrence.
    """
    cap = np.asarray(bins)

    # Best fit: prefer the bin with the least leftover space after placing.
    leftover = cap - item            # >= 0 by contract

    # Penalize completely empty bins slightly so that they are kept in reserve.
    # Using a value smaller than 1 guarantees best-fit ordering among used bins
    # is never violated (integer capacities), while any used bin beats an empty
    # one when the leftover difference is below the penalty threshold.
    is_empty = cap >= 100

    # Negative scores: smaller leftover is better, empty bins get extra penalty.
    score = -(leftover.astype(np.float64))
    score -= is_empty.astype(np.float64) * 0.5

    return score
