import numpy as np

_state = {
    "last_item": 0,
    "seen": 0,
}

def priority(item, bins):
    """Rank bins: exact fits first, then best fit, with mild anti-waste tie-breaking."""
    bins = np.asarray(bins, dtype=np.int64)

    # Best-fit component: smaller remaining capacity after placement is better.
    # Since penalizing residual space is equivalent to favoring bins whose current
    # free space is closest to the item size.
    best_fit = -(bins - item)

    # Exact-fit bonus: strongly prefer a bin that becomes exactly full.
    exact = (bins == item)

    # Mild preference for lower current remaining capacity among non-exact fits
    # to avoid spreading large items into large empty bins unnecessarily.
    # This is already included in best_fit, but adding a small tapered term helps
    # break close cases more consistently.
    tightness = -bins

    # Small bias against very empty bins, which tends to preserve them for future
    # large items; exact fits and tight fits dominate.
    empty_penalty = (bins >= 100).astype(np.int64)

    # Slight preference against almost-empty bins if they are not exact fits.
    almost_empty_penalty = ((bins > 90) & (~exact)).astype(np.int64)

    # Freshly opened bins get a tiny bonus only when many bins are available and
    # the item is not close to exact-fitting anything, encouraging consolidation.
    many_open = len(bins) > 8
    fresh_bonus = ((bins == 100).astype(np.int64) * (1 if many_open else 0))

    score = (
        exact.astype(np.int64) * 1_000_000
        + best_fit * 100
        + tightness
        - empty_penalty * 2
        - almost_empty_penalty * 2
        + fresh_bonus * 3
    )

    _state["last_item"] = int(item)
    _state["seen"] += 1
    return score
