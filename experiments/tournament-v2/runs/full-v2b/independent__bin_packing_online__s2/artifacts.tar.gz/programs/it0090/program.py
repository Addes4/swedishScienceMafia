import numpy as np


_CAP = 100.0
_STATE = {
    "t": 0,
    "sum": 0.0,
    "sum2": 0.0,
    "hist": np.zeros(101, dtype=np.float64),
    "last_items": [],
}


def priority(item, bins):
    st = _STATE
    t = st["t"]
    s = item
    st["t"] = t + 1
    st["sum"] += s
    st["sum2"] += s * s

    h = st["hist"]
    if s <= 100:
        h[s] += 1.0

    b = bins.astype(np.float64, copy=False)
    rem = b

    # Updated mean and variance estimate.
    cnt = float(st["t"])
    mu = st["sum"] / cnt
    var = max(0.0, st["sum2"] / cnt - mu * mu)
    sd = np.sqrt(var)

    # A simple scale: around item mean 40, sd maybe 20-30.
    # Bin appropriateness is mostly about leaving useful residual capacity.
    # Approximate best-fit score.
    slack = rem - s

    # Favor exact fits and small positive slack.
    # Use a smooth convex penalty rather than pure -slack, to avoid
    # always opening a new bin when a close fit exists.
    tight = -slack - 0.012 * slack * slack

    # Avoid leaving very small unusable residual capacity (1..10),
    # because such bins are hard to reuse.
    tiny_pen = np.where((slack >= 0) & (slack <= 12), -2.5 * (13.0 - slack), 0.0)

    # Mild preference for fuller bins early, but allow almost-full bin closing.
    fill = rem / _CAP

    # Dynamic: when many items already arrived, prefer tight fits more strongly.
    # Early, spread items to learn capacity distribution; later, pack tightly.
    progress = cnt / 5000.0
    # progress grows to 1.0
    best_weight = 0.45 + 0.50 * progress
    spread_weight = 0.35 * (1.0 - progress)

    # Best-fit component (largest remaining below item goes first after fit).
    # bins only contains fitting bins, so rem >= s.
    bf = -(rem - s)

    # Worst-fit / spread component: larger remaining capacity gets higher score.
    wf = rem

    # Exact-fit and low-slack bonus.
    exact_bonus = np.where(slack == 0, 4.0, 0.0)
    low_slack_bonus = np.where((slack >= 1) & (slack <= 5), 0.8 * (6.0 - slack), 0.0)

    # Avoid opening fresh bins too eagerly: unused bins have rem == 100.
    fresh_pen = np.where(rem >= 99.5, -0.35, 0.0)

    # Prefer bins with residual capacity near a typical future item if possible.
    # Expected benefit of leaving rem-s capacity: rough surrogate.
    # Compute kernel density-ish score from histogram of past items.
    if t >= 20:
        probs = h / cnt
        # Probability that residual slack can fit a future item.
        # For each bin, sum probabilities of items <= slack.
        # Vectorize via cumulative sum.
        cdf = np.cumsum(probs)
        cdf = np.clip(cdf, 0.0, 1.0)

        # mapping slack values to indices 0..100
        idx = np.clip(slack.astype(np.int64), 0, 100)
        fit_prob = cdf[idx]
        fit_prob = np.where(slack <= 0, 0.0, fit_prob)
    else:
        # prior: item sizes roughly Weibull-ish, use smooth approximation.
        # Use logistic-like CDF with mean 40, scale 28.
        fit_prob = 1.0 / (1.0 + np.exp(-(slack - mu) / max(sd, 8.0)))
        fit_prob = np.where(slack <= 0, 0.0, fit_prob)

    # Reward bins whose residual capacity is likely reusable.
    reuse = 2.0 * fit_prob - 0.35 * (1.0 - fit_prob)

    # Score assembly.
    score = (
        best_weight * bf
        + spread_weight * wf
        + tight
        + tiny_pen
        + 0.55 * fill
        + exact_bonus
        + low_slack_bonus
        + fresh_pen
        + 1.2 * reuse
    )

    # Tie-break deterministically toward earlier bins by adding tiny descending.
    n = score.shape[0]
    if n > 0:
        score = score - np.arange(n, dtype=np.float64) * 1e-12

    # Safety: replace non-finite with very low.
    score = np.nan_to_num(score, nan=-1e9, posinf=1e9, neginf=-1e9)
    return score
