import numpy as np


def priority(item, bins):
    """
    Best fit with a small bias against creating zero-capacity bins.

    The item should go to the feasible bin whose remaining capacity after
    placement is smallest, but if that would leave a bin exactly full, we
    slightly prefer a bin that leaves a tiny positive remainder.  This avoids
    locking away perfectly matched bins and gives better long-run packing on
    the Weibull-like size distribution.

    Args:
        item: integer size of the arriving item, 1..100.
        bins: numpy int64 array of remaining capacities of all bins the item fits.

    Returns:
        numpy array of scores, one per bin. Highest score wins.
    """
    remaining = bins - item

    # Primary criterion: tighter fit is better (smaller remaining is better).
    score = -remaining.astype(np.float64)

    # Secondary preference: avoid exactly filling a bin if an almost-as-good
    # bin exists.  A tiny negative bonus for remaining == 0 implements this.
    # The magnitude is small enough not to change the ordering of distinct
    # remaining capacities, but it breaks ties and softly discourages zeros.
    score -= (remaining == 0).astype(np.float64) * 1e-6

    return score
