import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.threshold = 100.0


_state = _State()


def priority(item, bins):
    """Best fit: score bins by how tightly the item fits.

    Since ties go to the first bin, and unused bins have remaining capacity 100,
    we slightly prefer bins that are already partially used so that we do not
    open new bins unnecessarily.
    """
    _state.calls += 1

    remaining = bins - item  # >= 0 by construction

    # Base best-fit score: smaller remaining after placement is better.
    score = -remaining.astype(np.float64)

    # Slight preference for non-empty bins (remaining < 100) to avoid opening
    # a fresh bin when an existing bin can take the item reasonably well.
    # Bins not shown are those the item does not fit in, so all shown.
    unused = (bins == 100)
    # Penalize unused bins modestly; this encourages consolidation.
    score -= unused.astype(np.float64) * 0.5

    return score
