import numpy as np

class _State:
    def __init__(self):
        self.n = 0
        self.mean_item = 40.0
        self.res_hist = np.zeros(101, dtype=np.float64)
        self.item_hist = np.zeros(101, dtype=np.float64)
        self.bin_count = 0
        self.total_used = 0

_S = _State()

def priority(item, bins):
    n = len(bins)
    residual = bins - item

    # Update running statistics (cheap, O(1))
    _S.n += 1
    alpha = min(1.0, 50.0 / _S.n) if _S.n > 0 else 1.0
    _S.mean_item = (1.0 - alpha) * _S.mean_item + alpha * item
    if item <= 100:
        _S.item_hist[item] += 1.0

    # Best-fit main score: smaller residual => higher priority
    # Base score is negative residual (so smaller residual wins)
    score = -residual.astype(np.float64)

    # Secondary refinement: prefer residuals in a "good" band.
    # A residual in [1, ~item] can often be filled by typical items;
    # residuals near 0 are perfect; large residuals waste space.
    # Penalize residuals that are "medium but not fillable" less than doing nothing.
    # We use a smooth preference: bins that leave residual close to the mean item
    # size are more likely to be filled exactly by future items.
    target = _S.mean_item
    # Penalize residuals far from 0 and far from being a good combination.
    # However, main rule must remain best-fit. Add small epsilon tie-breakers.
    eps = 1e-6

    # Prefer exact fits strongly (already handled by -residual)
    # Add small bonus for residuals near typical item sizes (good packing potential)
    # but keep magnitude tiny so it only breaks near-ties.
    good = np.exp(-((residual - target) ** 2) / (2.0 * (target + 1.0) ** 2))
    good = np.where(residual == 0, 1.0, good * 0.01)

    # Slight preference for lower bin index among equals (stable, deterministic)
    idx = np.arange(n, dtype=np.float64)

    score = score + eps * good - 1e-9 * idx

    return score
