"""Online bin packing: best fit with improved tie-breaking and adaptive scoring."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer the bin with the smallest remaining capacity that still fits.
    # remaining after placing = bins - item; smaller is better -> negative.
    residual = bins - item

    # Primary: tightest fit (most negative residual = smallest leftover gets highest score)
    score = -residual.astype(np.float64)

    # Secondary: slight preference to avoid leaving tiny unusable gaps.
    # Penalize larger leftover slightly less than absolute best fit to spread?
    # Instead, add a tiny bonus for bins that become nearly full (residual 0..5),
    # to consolidate and free up empty bins.
    bonus = np.where(residual <= 5, 0.5, 0.0)
    score += bonus

    # Tertiary: tie-break by bin order (already first wins ties), keep float.
    return score
