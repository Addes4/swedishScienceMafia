import numpy as np


def priority(item, bins):
    """Best-fit: prefer the bin with the smallest remaining capacity that fits.

    We compute the residual capacity after placing the item and negate it so the
    smallest residual gets the highest score.  Ties are broken implicitly by
    stable first-index selection in the harness, which favors earlier bins and
    helps keep the number of open bins low.
    """
    return -(bins - item)
