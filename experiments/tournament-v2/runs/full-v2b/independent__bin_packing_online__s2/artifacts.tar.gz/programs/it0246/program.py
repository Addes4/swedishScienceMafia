"""Hybrid best-fit with tight-fit bias for online bin packing."""
import numpy as np


def priority(item, bins):
    # Score bins: prefer the bin where the item leaves the least slack
    # afterward, but slightly favor bins that are already fuller.
    # Use a convex penalty: heavily penalize large remaining capacities.
    slack = bins - item  # >= 0 for all shown bins
    # Convert to float for stable arithmetic.
    s = slack.astype(np.float64)
    # Best fit: smallest slack first. Add a mild preference for bins
    # that are near full (to consolidate).
    # Score = -(slack) - small tiebreak based on fullness pattern.
    score = -s
    # Slight bonus for leaving a very small slack (helps avoid waste).
    score += 0.02 / (1.0 + s)
    return score
