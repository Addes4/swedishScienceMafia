import numpy as np


def priority(item, bins):
    # Prefer the bin with the smallest remaining capacity after placement (best fit),
    # with a tiny bias toward earlier bins to encourage concentrated packing.
    residual = bins - item
    idx = np.arange(len(bins), dtype=np.int64)
    return -(residual.astype(np.float64) * 1.0 + idx * 1e-6)
