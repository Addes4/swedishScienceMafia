"""Best fit with a concave residual penalty and stable tie-breaking."""
import numpy as np


def priority(item, bins):
    """
    Score bins for best-fit placement.

    The item goes into the bin with the highest score; ties go to the earliest bin.
    We score using the residual capacity after placing the item:
      score = -(residual) - alpha * residual^2 / 100
    This is a monotone decreasing function of residual, so it behaves like best fit,
    but it slightly exaggerates the preference for small residuals (exact fits,
    and tight packs). The quadratic term is mild so that fit quality dominates.

    bins: remaining capacities of bins the item fits in (numpy int64 array).
    """
    residual = bins - item  # >= 0 for all shown bins

    # Concave-friendly residual penalty: prefer smaller residual strongly,
    # with a mild extra bonus for very small residuals.
    # Use float math; length is at most number of bins so far.
    r = residual.astype(np.float64)
    score = -r - 0.01 * r * r

    # Slight preference for earlier bins (lower index) among equal residuals,
    # implemented as a tiny decreasing offset with index. Since ties go to the
    # first bin anyway, this mainly breaks ties among nearly equal scores.
    n = score.shape[0]
    # tiny index-based nudge, negligible compared to residual differences
    # (max nudge ~ 1e-3 across all bins)
    nudge = -np.arange(n, dtype=np.float64) * (1e-3 / max(n, 1))
    return score + nudge
