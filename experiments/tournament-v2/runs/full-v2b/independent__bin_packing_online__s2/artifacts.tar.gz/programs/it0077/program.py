import numpy as np


class Packer:
    def __init__(self):
        self.n = 0
        self.mean = 40.0
        self.counts = np.zeros(101, dtype=np.int64)

    def observe(self, item):
        self.n += 1
        self.counts[item] += 1
        # running mean
        self.mean += (item - self.mean) / self.n


_packer = Packer()


def priority(item, bins):
    p = _packer
    p.observe(item)

    # Estimate typical item size; used to value remainders that are useful for future items.
    m = p.mean if p.n > 1 else 40.0

    rem = bins  # remaining capacities of candidate bins
    # Best fit core: prefer smaller remaining capacity after placing (i.e. tighter fit).
    tight = -rem

    # Value of leftover capacity: prefer leftovers close to a typical item size,
    # so that future items can use them well. Also mildly penalize tiny/unusable scraps.
    leftover = rem - item

    # Score leftovers: peaks when leftover ~ m (can fit a typical item).
    # Use a smooth, monotone-ish preference that rewards leftovers near m.
    score = tight.astype(np.float64) * 1.0

    # Bonus for leftovers that can accommodate at least one typical item,
    # with a penalty for wasting good space.
    can_fit = (leftover >= m) & (leftover > 0)

    # Prefer exact fits slightly.
    exact = (leftover == 0)

    # Prefer bins that are neither empty nor nearly full unless necessary.
    # Small bonus for using existing bins with moderate leftover.
    moderate = (leftover >= m) & (leftover <= 2.0 * m)

    score += 0.05 * exact.astype(np.float64)
    score += 0.01 * moderate.astype(np.float64)

    # Penalize leaving very small unusable scraps vs leaving 0 (exact) or enough for m.
    small_scrap = (leftover > 0) & (leftover < max(1.0, m / 3.0))
    score -= 0.02 * small_scrap.astype(np.float64)

    return score
