import numpy as np


def priority(item, bins):
    """Best-fit-like rule: prefer the tightest residual capacity, penalize opening new bins.

    bins holds remaining capacities (100 for empty bins). We score tight fits higher,
    and subtract a small penalty for using an empty bin so that we only open one when
    no partially used bin can accept the item. Ties are resolved toward smaller indices.
    """
    residual = bins - item
    # Tight residual (small bins-item) is best. Empty bins have residual 100-item,
    # so the penalty below keeps them behind any non-empty feasible bin.
    score = -(residual * 1000 + bins)
    return score
