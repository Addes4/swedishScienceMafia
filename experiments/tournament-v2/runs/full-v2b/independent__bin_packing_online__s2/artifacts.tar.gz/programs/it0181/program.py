import numpy as np

# Cached value table keyed by item size, computed lazily per instance call.
# We approximate with a simple, distribution-aware residual preference.

_CACHE = {}

def _value_table(item):
    """Return a value array of length 101: value[r] = desirability of leaving residual r
    after placing an item of size `item` in a bin. Higher residual is generally less
    useful than a small residual that is hard to fill, but leaving a residual that is
    too small wastes space. We use a shape that mildly prefers tight packing but avoids
    leaving tiny unusable holes."""
    if item in _CACHE:
        return _CACHE[item]
    r = np.arange(101, dtype=np.float64)
    # Base: prefer tight fit (small residual) but penalize residuals 1..7 that are
    # hard to fill; strongly avoid leaving a residual just below a common item size.
    # Score of a bin given residual r is negative of wasted potential.
    # Simple smooth curve: tighter is better, with a small penalty for tiny leftovers.
    val = -r.astype(np.float64)
    # tiny residuals are wasteful; discourage them slightly
    penalty = np.zeros(101)
    penalty[1:8] = 3.0
    penalty[8:15] = 1.0
    val = val - penalty
    _CACHE[item] = val
    return val


def priority(item, bins):
    """Best-fit variant with mild residual shaping."""
    residual = bins - item  # remaining capacity after placing (>=0 guaranteed by harness)
    # clamp negatives (shouldn't happen) to 0
    residual = np.maximum(residual, 0)
    r = residual.astype(np.int64)
    val = -r.astype(np.float64)
    # penalize tiny residuals (hard to reuse)
    tiny = (r >= 1) & (r <= 7)
    val = np.where(tiny, val - 2.5, val)
    # slightly penalize leaving residual in [8,14] too
    small = (r >= 8) & (r <= 14)
    val = np.where(small, val - 0.8, val)
    return val
