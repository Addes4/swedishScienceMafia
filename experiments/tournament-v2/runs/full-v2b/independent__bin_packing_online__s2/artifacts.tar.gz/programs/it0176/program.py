import numpy as np


def priority(item, bins):
    # Best-fit baseline: smaller remaining capacity after placement is better.
    base = -(bins - item)

    # For smaller items, encourage using fuller bins to avoid creating too many
    # partially filled bins. The cutoff is chosen conservatively so the rule
    # behaves like best fit for medium/large items.
    if item <= 30:
        # Prefer bins whose remaining capacity is small, but not so small that
        # we are just wasting a near-full bin on a tiny item.
        # Score is still a linear function on bins:
        #   maximize base + alpha * (100 - bins)
        # This gently pushes small items toward bins with less free space.
        alpha = 0.15
        return base + alpha * (100 - bins)

    return base
