import numpy as np


def priority(item, bins):
    """Best-fit with a mild preference against consuming fresh bins for small items."""
    rem = bins.astype(np.int64)

    # Primary: tightest fit (smallest remaining capacity after placing item)
    # Secondary: keep a few unused bins untouched when many good fits exist
    score = -(rem - item)

    # Slight bonus for exact fits.
    score = score.astype(np.float64)
    score[rem == item] += 1e6

    # Mildly discourage using completely unused bins for small items when possible.
    # Empty bins have remaining capacity 100.
    empty = (rem == 100)
    if item < 60 and np.count_nonzero(~empty) > 0:
        score[empty] -= 0.5 + (60 - item) * 0.01

    # Prefer older/non-empty bins very slightly for larger items so empty bins
    # can absorb large future arrivals.
    if item >= 60:
        score[empty] += 0.01

    return score
