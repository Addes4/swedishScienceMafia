# EVOLVE-BLOCK-START
"""Best-fit with a tie-break that discourages opening new bins too early."""
import numpy as np


def priority(item, bins):
    # Primary: minimize leftover space (best fit).
    # Secondary: among equal leftover, prefer bins that are already less empty,
    # so we fill partially-used bins before consuming fresh capacity-100 bins.
    residual = bins - item
    # residual >= 0 for all shown bins.
    # Larger score is better.  We want small residual, and for equal residual
    # a smaller current remaining capacity (i.e. more filled bin).
    # residual is in [0, 99]; remaining is in [item, 100].
    # Combine without overflow/float issues.
    return -(residual * 128 + bins)
# EVOLVE-BLOCK-END
