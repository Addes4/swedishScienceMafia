import numpy as np

class State:
    def __init__(self):
        self.total_items = 0
        self.total_size = 0.0
        self.mean_item = 40.0
        self.bin_used_total = 0
        self.items_seen = 0
        self.last_worst = None

_state = State()

def priority(item, bins):
    # Update running mean of item sizes
    _state.items_seen += 1
    n = _state.items_seen
    _state.total_size += item
    _state.mean_item += (item - _state.mean_item) / min(n, 200)

    # We can't see future items, but distribution is Weibull-shaped mean ~40.
    # Best fit generally good for packing. Slight adaptation:
    # Prefer bins that after placement leave a remainder close to 0,
    # but if many nearly-empty bins exist, spread a bit.
    rem = bins.astype(np.float64)
    after = rem - item

    # Score: prefer small positive after (best fit), penalize large after,
    # strongly prefer exact fits.
    score = -after

    # Bonus for exact fit
    exact_mask = (after == 0)
    score[exact_mask] += 1000.0

    # Slight preference to leave remainder that is a "good" size
    # (small enough to be filled but not wasting). For Weibull mean ~40,
    # items often in 10..70 range. Penalize leftover between 1 and 30 a bit
    # only if alternative exact/best fit unavailable.
    # Actually standard best-fit is near-optimal for many distributions;
    # keep it simple and robust.

    return score
