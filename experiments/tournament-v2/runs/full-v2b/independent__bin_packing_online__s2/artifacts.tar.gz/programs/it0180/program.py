import numpy as np


class _State:
    def __init__(self):
        self.calls = 0
        self.total = 0

    def update(self, item):
        self.calls += 1
        self.total += int(item)


_state = _State()


def priority(item, bins):
    _state.update(item)
    # Best fit: minimize remaining capacity after placing the item.
    score = -(bins - item)
    # Slight preference for non-empty bins (remaining < 100) to avoid opening new bins.
    score = score + 0.001 * (bins < 100)
    return score
