import numpy as np

def priority(item, bins):
    # Prefer bins that leave little slack after placing the item (best fit),
    # but penalize opening brand-new bins slightly to encourage packing.
    # Small deterministic tie-breaking by bin order is already handled by the
    # harness (first highest wins), so we just need a good score.
    slack = bins - item
    # Score: higher for tighter fits (smaller slack).
    # Add a tiny preference for bins that are not completely empty.
    # Empty bins have remaining capacity 100; after placement slack = 100 - item.
    # We penalize using an empty bin a little to avoid opening new bins early.
    score = -slack.astype(np.float64)
    # Penalty for using an empty bin (remaining capacity == 100)
    score -= (bins == 100) * 0.01
    return score
