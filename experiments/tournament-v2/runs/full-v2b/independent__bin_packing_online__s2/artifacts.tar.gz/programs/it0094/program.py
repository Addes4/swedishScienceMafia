import numpy as np

_STATE = {
    "calls": 0,
    "prefix": None,
    "last_item": 0,
    "item_counts": None,
    "sum_items": 0,
}

def priority(item, bins):
    """Online bin-choice rule: hybrid best-fit with light late-stage consolidation."""
    st = _STATE
    st["calls"] += 1
    st["last_item"] = item
    st["sum_items"] += item

    # Track simple item statistics for a scale-aware tweak.
    if st["item_counts"] is None:
        st["item_counts"] = np.zeros(101, dtype=np.int64)
    st["item_counts"][item] += 1
    avg = st["sum_items"] / st["calls"]

    b = np.asarray(bins, dtype=np.int64)
    n = b.size

    if n == 0:
        return np.zeros(0, dtype=np.float64)

    # Base score: prefer the tightest fit (least residual capacity after placement).
    residual = b - item
    score = -residual.astype(np.float64)

    # Slight preference for more-used bins when their residual is reasonably small.
    # This reduces premature opening of brand-new bins in the middle/late phase.
    if st["calls"] > 50:
        # used bins generally have capacity < 100; fresh bins have capacity == 100.
        used = b < 100
        if used.any():
            # Penalize bins that would leave a large unusable-ish residual.
            # For item sizes around 40, residual near 60 is often poor; residual small is good.
            # Avoid being too aggressive to preserve best-fit's robustness.
            penalty = np.zeros(n, dtype=np.float64)
            penalty[used] = np.maximum(0.0, residual[used] - (100 - item) * 0.15) * 0.015
            score -= penalty

    # Tie-break: among equal scores, prefer the first bin as required by harness.
    return score
