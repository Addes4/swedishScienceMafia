"""Best fit with a distribution-aware tie-break for online bin packing."""
import numpy as np

# Running statistics of item sizes to estimate the distribution.
_item_sum = 0.0
_item_sq_sum = 0.0
_count = 0
_mean = 40.0
_std = 20.0


def priority(item, bins):
    global _item_sum, _item_sq_sum, _count, _mean, _std

    # Update running mean/std (Welford-ish incremental).
    _count += 1
    _item_sum += item
    _item_sq_sum += item * item
    if _count > 1:
        var = (_item_sq_sum - _item_sum * _item_sum / _count) / (_count - 1)
        _std = max(1.0, var ** 0.5)
    _mean = _item_sum / _count

    # Best fit: prefer the bin with the smallest remaining capacity that still fits.
    # Primary score: larger (closer to zero) means better fit.
    fit_score = -(bins - item)

    # Distribution-aware adjustment: a remainder r is more "wasteful" if it is
    # significantly smaller than the typical item size, since it will be hard
    # to fill efficiently later.
    remainder = bins - item
    # How many typical items could still fit? Use a soft measure.
    typical = max(1.0, _mean)
    # Penalize remainders that are too small to hold a typical item, while
    # still rewarding the tightest possible fit.
    waste_penalty = np.where(remainder < typical * 0.5, -1.0, 0.0)

    # Combine: best fit dominates, penalty breaks near-ties.
    return fit_score + waste_penalty
