import numpy as np


def priority(item, bins):
    """Score bins to tightly pack items while avoiding unnecessary new bins.

    Primary rule: best fit (smallest remaining capacity that still fits).
    Secondary rule: strongly prefer non-empty bins over opening a new bin,
    since future items can often fill the leftover space.
    """
    # bins is a copy of remaining capacities for bins this item fits in.
    # Smaller remaining capacity after placing = tighter fit.
    fit_left = bins - item

    # Tighter fit gets higher score.
    score = -fit_left.astype(np.float64)

    # Penalize completely empty bins (remaining capacity 100 before placement)
    # to reduce the number of open bins held in reserve.
    empty = bins >= 100
    score[empty] -= 1e6

    return score
