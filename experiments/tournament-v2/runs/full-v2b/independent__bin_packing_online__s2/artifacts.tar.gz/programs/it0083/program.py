import numpy as np


def priority(item, bins):
    """Best fit with a mild preference to avoid using completely empty bins for large items."""
    # Best fit: higher score for tighter fit -> -(remaining - item)
    score = item - bins.astype(np.float64)

    # Penalize empty bins slightly more for large items.
    # For small items, opening a new bin is often fine; for large items,
    # we prefer existing partially filled bins to reduce waste.
    empty = bins == 100
    if item >= 30:
        score = score - empty * item * 0.5
    else:
        score = score - empty * 0.5

    return score
