import numpy as np

def priority(item, bins):
    # Score = -(remaining after put) = -bins + item
    # So highest score = smallest remaining capacity after placing item.
    # However, to avoid wasting a fresh bin on a small item when other bins can fit,
    # we add a tiny penalty for using an empty bin (remaining capacity == 100).
    scores = -(bins - item)
    # Penalize empty bins slightly so they are used only when necessary.
    # The penalty must not change relative order among non-empty bins.
    empty_penalty = 1e-6
    scores = scores.astype(np.float64)
    scores[bins == 100] -= empty_penalty
    return scores
