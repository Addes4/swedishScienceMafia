import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.total = 0
        self.open_bins = 0
        self.penalty = 0.0
        self.warm = []


_S = _State()


def priority(item, bins):
    """
    Adaptive best fit.

    Bins are ranked by "tightness": smaller remaining capacity after placement is better.
    To avoid opening new bins too eagerly early on, we give a bonus to already-open bins.
    The bonus is estimated online from the average item size and current packing density.
    """
    s = _S

    # Track simple statistics of arriving items
    s.n += 1
    s.total += item

    if s.n <= 200:
        s.warm.append(item)

    # Estimate typical item size
    if s.warm:
        avg = s.total / s.n
    else:
        avg = 40.0

    # Number of bins with capacity 100 is a proxy for unused bins
    n_unused = int(np.count_nonzero(bins == 100))
    n_used = len(bins) - n_unused

    # Density of used bins: how full they are on average
    if n_used > 0:
        used_caps = bins[bins < 100]
        mean_used_cap = float(np.mean(used_caps)) if used_caps.size else 100.0
    else:
        mean_used_cap = 100.0

    # Adaptive penalty for choosing an unused bin (capacity == 100).
    # When item size is large relative to capacity, opening fresh bins is more necessary.
    # When many bins are already open and not too full, favor filling them.
    frac_unused = n_unused / max(1, len(bins))
    item_frac = item / 100.0

    # Base penalty small; increase if we have many partially-filled bins
    base_pen = 0.15 * avg / 100.0

    # Stronger preference to avoid fresh bins when many are already open
    fill_pressure = (1.0 - frac_unused) * (1.0 - item_frac) * 0.4

    # If mean used capacity is high, opening new bins is less costly
    cap_factor = max(0.0, (mean_used_cap - 30.0) / 70.0)

    penalty = base_pen + fill_pressure * (1.0 - 0.5 * cap_factor)

    # Score: prefer tight fit. Lower remaining capacity after placement is better.
    # For each bin with capacity c >= item, residual = c - item.
    # Main term: -residual. Unused bins get additional penalty.
    residual = bins.astype(np.float64) - float(item)
    score = -residual

    # Penalize unused bins (capacity exactly 100) to encourage consolidation.
    # Also slightly penalize bins with very low remaining capacity to avoid
    # creating nearly-full bins that block future items.
    unused_mask = bins == 100
    score[unused_mask] -= penalty * 100.0

    # Small preference against leaving tiny residuals (less than average item size),
    # because that wastes a bin that might be reusable.
    small_resid = (residual >= 0) & (residual < avg * 0.5)
    score[small_resid] -= 0.5

    return score
