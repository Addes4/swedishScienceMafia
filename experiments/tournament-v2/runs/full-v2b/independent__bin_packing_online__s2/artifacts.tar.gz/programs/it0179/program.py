import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    global _state
    _state["sum"] += item
    _state["n"] += 1
    avg = _state["sum"] / _state["n"]

    residual = bins - item

    # Primary: best fit (smallest residual).
    # Secondary: prefer non-empty bins slightly; empty bins (residual 100-item) are
    # penalized a touch, scaled by how typical the item size is.
    scale = 0.5 if item >= avg else 0.25
    penalty = np.where(bins == 100, scale, 0.0)

    return -(residual.astype(np.float64) + penalty)
