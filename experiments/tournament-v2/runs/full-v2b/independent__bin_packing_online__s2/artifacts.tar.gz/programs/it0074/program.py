import numpy as np


def priority(item, bins):
    remaining_after = bins - item
    # Base: tighter fit is better -> smaller remaining_after is better.
    # Use -remaining_after so larger is better; exact fit (0 remaining) gets bonus.
    score = -remaining_after.astype(np.float64)
    # Large bonus for perfect fit
    exact_mask = (remaining_after == 0)
    score[exact_mask] += 1e9
    # Small bonus for near-perfect fit (within a few units) to prefer almost-full bins
    near_mask = (remaining_after > 0) & (remaining_after <= 3)
    score[near_mask] += 1e3
    return score
