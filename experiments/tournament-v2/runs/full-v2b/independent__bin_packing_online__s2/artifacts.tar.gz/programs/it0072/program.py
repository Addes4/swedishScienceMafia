"""Online bin packing: best-fit with a mild anti-fragmentation tie bias."""
import numpy as np


class _State:
    n_items = 0
    total = 0.0


def priority(item, bins):
    _State.n_items += 1
    _State.total += item
    avg = _State.total / _State.n_items

    residual = bins - item  # remaining capacity after placing item; >= 0

    # Primary: best fit -> smaller residual is better.
    # Slight penalty for using completely empty bins (residual == 100 - item)
    # to conserve fresh bins, and a small preference for bins whose residual
    # is still large enough for an average item (reduce unusable fragments).
    empty_res = 100 - item
    is_empty = (bins == 100)

    score = -residual.astype(np.float64)

    # Discourage opening brand-new bins unless necessary.
    score[is_empty] -= 0.5

    # Mildly prefer resid that can still fit an average item, breaking exact ties.
    score += 0.01 * (residual >= avg).astype(np.float64)

    return score
