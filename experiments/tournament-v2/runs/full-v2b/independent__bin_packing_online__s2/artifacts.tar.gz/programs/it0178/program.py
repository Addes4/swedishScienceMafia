import numpy as np

_started = False
_item_count = 0
_bin_count = 0
_avg_item = 40.0


def priority(item, bins):
    """Rank bins by a tight-fit rule with a slight preference for already-used bins.

    The returned value is a score where larger is better.  The item is placed in the
    bin with the largest remaining capacity that is still less than or equal to
    item + a small allowance for nearly-full bins.  A modest penalty for empty bins
    encourages filling existing bins instead of opening new ones.
    """
    global _started, _item_count, _bin_count

    _item_count += 1
    _bin_count = max(_bin_count, int(len(bins)))

    # Remaining capacity after placing the item.
    waste = bins - item

    # Prefer bins that become as full as possible (small waste), but do not
    # absolutely forbid opening a new bin when no existing bin is available.
    score = -waste.astype(np.float64)

    # Bias against completely empty bins.  This is most useful early on when
    # many bins are still empty; it helps avoid scattering items across new bins.
    empty_penalty = 4.0
    score -= empty_penalty * (bins == 100)

    # Slight preference for bins that are already fairly full, which tends to
    # reduce fragmentation in Weibull-like item streams.
    fullness_bonus = (100 - bins) * 0.01
    score += fullness_bonus

    return score
