import numpy as np


def priority(item, bins):
    """Best fit with a mild preference for tighter fits and protection of large empty bins."""
    rem = bins - item

    # Base: prefer bins that leave the least remaining space (best fit).
    score = -rem.astype(np.float64)

    # If the item is small, discourage placing it into very empty bins.
    # This keeps large empty bins available for large future items.
    if item <= 40:
        score -= (bins >= 90) * 5.0

    # Mild bonus for bins that become nearly full, improving packing density.
    score += (rem <= 5) * 2.0

    return score
