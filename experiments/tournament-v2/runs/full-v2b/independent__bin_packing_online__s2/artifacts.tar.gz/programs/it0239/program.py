import numpy as np


def priority(item, bins):
    # Best-fit with a small tie-breaking preference for using fresher bins
    # when several bins give the same remainder, and for preserving bins whose
    # remaining capacity is close to a typical item size.
    rem = bins - item  # remaining capacity after placing the item

    # Base: prefer smallest remainder (best fit).
    score = -rem.astype(np.float64)

    # Mild preference against leaving a bin with exactly enough room for an
    # average item (~40), since that bin may be useful later.
    avg = 40.0
    # If the post-placement remainder is in a "sweet spot", slightly penalize it.
    dist_to_avg = np.abs(rem.astype(np.float64) - avg)
    # Only apply to positive remainders that are near the average item size.
    sweet = (rem > 0) & (dist_to_avg < 12.0)
    score[sweet] -= 0.75

    # Prefer not to leave very small slivers either, unless it is a perfect fit.
    tiny = (rem > 0) & (rem <= 4)
    score[tiny] -= 0.25

    return score
