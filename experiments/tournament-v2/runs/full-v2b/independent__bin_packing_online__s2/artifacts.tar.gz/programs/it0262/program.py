import numpy as np


def priority(item, bins):
    # Best fit: prefer the smallest remaining capacity that still fits the item.
    # Add a tiny bias toward bins with more remaining capacity to keep slots open
    # for future items, which helps online packing without changing clear best-fit choices.
    return -(bins - item) - 1e-6 * bins
