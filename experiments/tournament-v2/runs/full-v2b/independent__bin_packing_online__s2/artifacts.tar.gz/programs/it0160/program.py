import numpy as np


def priority(item, bins):
    """Best-fit with a tiny capacity-aware reservation bonus.

    Score higher for bins whose remaining capacity is closest to the item
    (best fit), but give a small bonus to bins that would be left with a
    little room, so small future items can still be packed efficiently.
    All decisions depend only on the current item and bins.
    """
    # Primary: prefer bins with remaining capacity just enough for item.
    # secondary term heavily outweighs the bonus for normal capacities.
    remaining_after = bins - item

    # Bonus for leaving a modest "tight" leftover rather than a large one.
    # This rewards bins whose leftover is small but nonzero (good for small items).
    # For leftover 0 the bonus is zero (perfect fit is still good), and for large
    # leftovers the bonus vanishes.  Use a smooth, bounded function.
    leftover = remaining_after.astype(np.float64)
    # reward small positive leftovers a bit; magnitudes kept small so best-fit dominates.
    bonus = 0.001 * (leftover < 10) * (leftover > 0) * leftover

    # Base best-fit: higher score when leftover is smaller.
    score = -leftover + bonus
    return score
