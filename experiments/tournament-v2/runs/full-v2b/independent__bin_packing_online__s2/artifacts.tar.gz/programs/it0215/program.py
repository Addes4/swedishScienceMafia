import numpy as np


def priority(item, bins):
    """Rank bins using a refined best-fit rule with a small gap-utility adjustment."""
    # Primary: best fit = smallest remaining capacity after placement.
    # Secondary: prefer remainders that are neither tiny (hard to reuse) nor very large.
    rem = bins - item

    # Base scores: higher is better. Strongly prefer smaller remainder.
    score = -rem.astype(np.float64)

    # Small preference against leaving 1..9 units, because such gaps are often wasted.
    # This nudges the packer to avoid creating near-unusable small residuals.
    tiny_penalty = np.where((rem > 0) & (rem < 10), 0.25 * (10 - rem), 0.0)

    # Small preference against opening/using very empty bins unless needed.
    # This is already implied by best fit, but a mild bonus for fuller bins helps
    # keep partially filled bins consolidated.
    empty_penalty = np.where(rem > 70, 0.02 * (rem - 70), 0.0)

    score -= tiny_penalty
    score -= empty_penalty

    return score
