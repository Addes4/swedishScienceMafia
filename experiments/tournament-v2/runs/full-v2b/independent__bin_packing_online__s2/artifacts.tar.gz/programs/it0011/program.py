import numpy as np


class _State:
    def __init__(self):
        self.n = 0
        self.sizes = []
        # empirically, best fit is strong for this distribution; we add a mild
        # residual-aware term that discourages leaving tiny unusable gaps.
        self.recent = []


_S = _State()


def priority(item, bins):
    """Score bins: prefer tight fits, but penalize residuals that are too small
    to be useful relative to the typical item size seen so far.
    """
    bins = np.asarray(bins, dtype=np.int64)

    # Update stats (bounded work per call).
    _S.n += 1
    _S.sizes.append(int(item))
    if len(_S.sizes) > 256:
        # keep a moving window / subsample cheaply
        _S.sizes = _S.sizes[-256:]
    # mean of recent items
    m = float(np.mean(_S.sizes)) if _S.sizes else 40.0

    residual = bins - item
    # best fit base: smaller residual is better
    # tie-break toward bins with more remaining capacity only when residual is
    # of the same tightness class.
    score = -residual.astype(np.float64)

    # Penalize leaving a small sliver residual (< about a third of mean item size),
    # since small residuals rarely fit future items; a bit of extra penalty
    # proportional to how useless the sliver is.
    thresh = max(1.0, 0.33 * m)
    small = residual < thresh
    # penalty increases as residual shrinks below threshold
    score -= np.where(small, (thresh - residual) * 0.5, 0.0)

    return score
