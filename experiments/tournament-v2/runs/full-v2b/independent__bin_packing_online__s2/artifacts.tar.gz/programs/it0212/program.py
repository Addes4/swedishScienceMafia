import numpy as np

# Keep track of allocation history to provide deterministic tie-breaking.
_state = {
    "used": {},      # bin_index -> count of times used
    "last_open": None,
}


def priority(item, bins):
    """Best-fit with a small deterministic tie-break toward already-used bins.

    The harness gives us all bins the item fits in, including completely unused bins
    (remaining capacity 100).  Best fit minimizes leftover space, but many equal-capacity
    bins can occur.  Breaking those ties by preferring bins that have already been used
    tends to preserve empty bins for larger future items without significantly hurting
    packing density.
    """
    global _state

    n = len(bins)
    # Base score: tighter fit is better.  For integer capacities this is exact best-fit.
    score = -(bins - item)

    # Deterministic tie-break: prefer used bins slightly over unused ones.
    # We do not know bin indices directly except through position in the given array.
    # The array is in fixed bin order, so position is a stable proxy.
    # Bins with remaining capacity 100 are likely unused; give them a tiny penalty.
    # This is intentionally very small so it only affects exact ties.
    for i in range(n):
        if bins[i] == 100:
            score[i] -= 0.001

    return score
