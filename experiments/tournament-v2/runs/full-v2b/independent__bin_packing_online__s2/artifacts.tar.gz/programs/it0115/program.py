import numpy as np


def priority(item, bins):
    """Best-fit with a mild emphasis on leaving a small remainder.

    Higher score wins; ties go to the first bin.  We mainly use best fit
    (smallest resulting free space), i.e. minimize residual = bins - item.
    A slight extra reward goes to residuals that are very small, which
    helps close out nearly-filled bins.
    """
    residual = bins - item           # >= 0 for every bin shown
    # Primary: prefer tight fits (small residual -> large negative score).
    score = -residual.astype(np.float64)
    # Secondary: penalize residuals in the awkward mid-range a touch and
    # reward tiny residuals, so bins get closed rather than left half-full.
    # This is a small perturbation that never overturns a clear best fit
    # except among near-equal candidates.
    score += 1e-3 * (residual < 5)
    return score
