"""Online bin packing: refined best fit favoring tightly closed bins.

At each arrival, score every fitting bin primarily by how well the item fills it
(minimize remaining capacity after placement = best fit).  As a tie-breaker,
prefer bins with smaller resulting "waste" compared to a learned item-size scale,
which gently encourages closing nearly-full bins and avoids leaving many medium
gaps.  No future information is used; only a running mean of item sizes informs
the tie-break, so the rule stays close to best-fit while adapting slightly to
the observed distribution.
"""

import numpy as np


# Running statistics over observed items (persist across calls).
_state = {
    "n": 0,
    "sum": 0.0,
}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of fitting bins.
    """
    # Update running mean of item sizes (cheap, O(1)).
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    # After placing the item, remaining capacity:
    rem = bins - item

    # Primary: best fit -> most negative remaining is best, so score = -rem.
    # Secondary tie-break: prefer placements that leave either a very small
    # residual (close the bin) or a residual at least around the typical item
    # size (leave a usable gap), penalizing awkward medium residuals.
    # Small penalty only, so it never overrides a clearly better fit.
    scale = max(mean_item, 1.0)
    residual = rem.astype(np.float64)
    # Penalize residuals near half the typical item size (hard to fill later).
    awkward = np.exp(-((residual - 0.5 * scale) ** 2) / (2.0 * (0.35 * scale) ** 2 + 1.0))
    # Also slightly reward nearly-full closes (residual near 0) beyond best-fit.
    close_bonus = np.exp(-residual / (0.25 * scale + 1.0))

    score = -residual.astype(np.float64) - 0.05 * awkward + 0.02 * close_bonus
    return score
