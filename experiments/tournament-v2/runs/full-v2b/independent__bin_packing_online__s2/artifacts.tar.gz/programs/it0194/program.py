"""Best-fit-style online bin packing with tie-breaking toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Score every bin for an incoming item; highest score gets the item.

    Primary rule: minimize leftover space after placing the item (best fit).
    Tie-break: prefer bins that are already more full (smaller remaining
    capacity), which reduces fragmentation and delays opening new bins.
    Unused bins (remaining == 100) get a slight penalty so they are not
    chosen unless nothing else fits well.
    """
    # leftover after placement; smaller is better -> negate
    leftover = bins - item

    # Main score: tightest fit first.
    score = -leftover.astype(np.float64)

    # Small tie-break: prefer fuller bins (smaller remaining capacity).
    score -= 1e-3 * bins.astype(np.float64)

    # Penalize opening brand-new bins slightly.
    score[bins == 100] -= 1e-2

    return score
