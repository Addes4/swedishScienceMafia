"""Best-fit with tie-breaking toward useful residual capacities."""
import numpy as np


def priority(item, bins):
    # Tightest fit first (most negative residual is best).
    residual = bins - item

    # Penalize residuals that are very small but nonzero? No: tight is good.
    # Secondary: prefer residual 0 strongly (exact fill).
    exact_bonus = np.where(residual == 0, 1000.0, 0.0)

    # Tertiary: among nonzero residuals, prefer bins whose remaining space
    # after placement is a "large enough" chunk to be reusable, but still tight.
    # We construct a smooth preference: smaller residual is better, but avoid
    # leaving tiny unusable scraps (1..19) when a slightly larger residual
    # would be more useful.
    frag = np.where((residual > 0) & (residual < 20), -0.5, 0.0)

    # Slight preference for already-used bins over fresh 100-capacity bins
    # to reduce opening new bins when fit is comparable.
    used_bonus = np.where(bins < 100, 0.1, 0.0)

    # Primary key is tight fit: -residual dominant.
    score = -residual * 10.0 + exact_bonus + frag + used_bonus
    return score
