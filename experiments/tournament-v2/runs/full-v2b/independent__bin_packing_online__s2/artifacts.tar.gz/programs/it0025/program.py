import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Tightest-fit: leftover capacity after placing the item.
    leftover = bins - item

    # Score: lower leftover is better, so use negative leftover.
    score = -leftover.astype(np.float64)

    # Small penalty for opening a fresh/empty bin.  This encourages using
    # partial bins first (best-fit-decreasing-like behaviour).
    score -= np.where(bins == 100, 0.5, 0.0)

    # Tiny preference for fuller bins (lower remaining capacity) as a tie-break,
    # without overpowering the fit criterion.
    score -= bins.astype(np.float64) * 1e-3

    return score
