import numpy as np


def priority(item, bins):
    # Best fit: prefer the smallest remaining capacity that still fits.
    # Add a small bias against totally empty bins so partially used bins are favored,
    # which reduces wasted capacity and tends to lower bin count.
    rem = bins
    score = -(rem - item).astype(np.float64)
    # Penalize bins with full remaining capacity (unused bins) slightly.
    score[rem == 100] -= 0.5
    return score
