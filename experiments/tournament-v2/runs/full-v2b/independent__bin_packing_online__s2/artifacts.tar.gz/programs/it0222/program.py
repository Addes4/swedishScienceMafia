import numpy as np

_state = {"h": 123456789}

def priority(item, bins):
    # Primary score: best fit (prefer smallest remaining capacity that still fits).
    score = -(bins - item).astype(np.float64)
    # Tiny tie-breaker based on a per-call pseudo-random sequence and item/size,
    # to avoid always filling earlier tied bins in the same patterned way.
    _state["h"] = (_state["h"] * 1103515245 + 12345) & 0x7fffffff
    r = (_state["h"] >> 8) & 0xffff
    t = (r + (item * 2654435761)) & 0xffff
    score += (t - 32768) * 1e-9
    return score
