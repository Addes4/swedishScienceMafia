# EVOLVE-BLOCK-START
"""Hybrid best-fit with complement-aware scoring for online bin packing."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best fit: prefer smallest remaining capacity that still fits.
    # Score = -(bins - item) => higher for tighter fit.
    leftover = bins - item

    # Complement bonus: for larger items, prefer exact complement (leftover==0).
    # Best-fit already does this, but we strengthen it for big items.
    score = -(leftover).astype(np.float64)

    if item > 50:
        # These items are hard to combine; strongly prefer tight fit.
        # Add bonus for exact/near-exact complement.
        score += -0.5 * leftover
    elif item <= 20:
        # Small items: mild preference for tighter bins to consolidate leftovers,
        # but not so aggressive that we fragment. Best fit is good here already.
        pass

    # Slight penalty for starting a new bin (leftover == 100 - item on empty bin)
    # to discourage opening new bins when existing ones can hold it.
    # Empty bin has remaining capacity 100.
    empty_leftover = 100 - item
    is_empty = (bins == 100)
    # Penalize empty bins moderately; but if item is large and nothing else fits,
    # this penalty is irrelevant since only empties qualify anyway.
    score -= is_empty * 1.0

    return score
# EVOLVE-BLOCK-END
