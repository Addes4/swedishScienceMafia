import numpy as np


class Packer:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.recent = []
        self.max_recent = 30

    def priority(self, item, bins):
        self.count += 1
        self.total += item
        self.recent.append(item)
        if len(self.recent) > self.max_recent:
            self.recent.pop(0)

        # Estimate the typical item size and the current global mean.
        if self.count > 0:
            mean_item = self.total / self.count
        else:
            mean_item = 40.0

        if self.recent:
            recent_mean = sum(self.recent) / len(self.recent)
        else:
            recent_mean = mean_item

        # Scale is roughly the standard deviation of the Weibull-like sizes.
        # Avoid filling a bin so tightly that it cannot accept typical items.
        reserve = 0.45 * recent_mean

        remaining = np.asarray(bins, dtype=np.float64)
        slack = remaining - item

        # Primary best-fit: prefer the bin with the smallest positive slack.
        # We invert slack because higher score wins.
        score = -slack

        # Mildly discourage using a bin if doing so leaves it too fragmented
        # for a typical item, but only when that bin is not nearly full.
        too_small = (remaining < item + reserve) & (remaining < 95.0)
        score = score - 0.35 * too_small.astype(np.float64)

        # Slightly prefer bins that are already partially used over empty bins,
        # but not so much that it harms packing.
        empty = remaining == 100
        score = score - 0.15 * empty.astype(np.float64)

        # Encourage using bins that leave enough space for the current item
        # without creating a very awkward small remainder.
        near_perfect = (allegedly := (remaining >= item)) & (remaining - item <= 2)
        score = score + 0.1 * near_perfect.astype(np.float64)

        return score


_packer = Packer()


def priority(item, bins):
    return _packer.priority(item, bins)
