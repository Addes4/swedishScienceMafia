"""Online bin packing: best-fit with a small stateful balancing term.

The primary signal is best fit (place the item in the bin it fits most
tightly).  A secondary, stateful signal tracks the total item size ever
assigned to each bin index, so that, all else equal, packs go into bins
that have historically received less material.  This tends to smooth out
pathological cases where best-fit repeatedly closes bins early.
"""
import numpy as np


class _State:
    def __init__(self):
        # total size of items ever assigned to each bin index
        self.load = []


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins, ties go first.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin,
          including untouched bins (remaining capacity 100), in bin order.
    """
    n = len(bins)
    load = _state.load

    # Extend the state if new bins have appeared.
    if len(load) < n:
        load.extend([0] * (n - len(load)))

    # Primary: best fit -> smaller remaining slack (bins - item) is better.
    slack = bins - item

    # Secondary: prefer bins that have historically received less material.
    # Scale is small enough that best-fit dominates but large enough to
    # break persistent ties toward balance.
    loads = np.asarray(load[:n], dtype=np.float64)

    # Convert load preference into a per-item-scaled nudge.
    # Normalize by item so the term stays well below 1.
    balance = -loads / 10000.0

    score = -(slack) + balance
    return score
