import numpy as np

class _State:
    def __init__(self):
        self.n = 0
        self.sum = 0.0
        # Common useful remainders for future items (rough guess for Weibull mean 40)
        self.targets = np.array([0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 60, 70, 80])
        self.counts = np.zeros(self.targets.shape[0], dtype=np.float64)

_state = _State()

def priority(item, bins):
    # Update simple online stats
    _state.n += 1
    _state.sum += item

    b = bins.astype(np.float64)

    # Score 1: best-fit (primary). Higher score = tighter fit.
    best_fit = -(b - item)

    # Score 2: prefer leftovers that are likely to be filled by future items.
    # For each bin, leftover after placing item:
    leftover = b - item
    # distance to nearest "useful" target remainder
    # smaller distance -> higher bonus
    d = np.abs(leftover[:, None] - _state.targets[None, :]).min(axis=1)
    # Bonus is strongest when leftover is small (avoid wasting large gap? no)
    # We want leftover to match a likely item size. But any leftover is fine if small.
    # Give bonus for leftover very close to a target, and also for leftover very small.
    target_bonus = 3.0 / (1.0 + d)
    small_bonus = 2.0 / (1.0 + leftover)
    heuristic = target_bonus + small_bonus

    # Combine: best-fit dominates for larger items; heuristic matters more for smaller items.
    # For item >= 60, stick near pure best-fit to avoid stranding capacity.
    alpha = 1.0 if item >= 60 else 0.2
    score = best_fit + alpha * heuristic

    return score
