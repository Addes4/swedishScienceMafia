# EVOLVE-BLOCK-START
"""Hybrid best-fit/first-fit ranking for online bin packing.

The item is placed into the bin that, after placement, leaves the least
remaining capacity (best fit).  Among nearly equally tight bins we prefer
bins that are already well utilized, which tends to pack bins more fully
and reduce the total bin count on Weibull-distributed item sizes.

score = -(remaining_after_placement) - alpha * (100 - remaining_before)
       = -(bins - item) - alpha * (100 - bins)

Smaller leftover gets higher score.  alpha is a small constant so that
exact best-fit decisions still dominate, while ties / near-ties are broken
toward fuller bins.
"""

import numpy as np

_ALPHA = 1e-3


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties)."""
    # remaining capacity after placing the item
    leftover = bins - item
    # utilization of the bin before placement (0..100)
    used_before = 100 - bins
    return -(leftover.astype(np.float64) + _ALPHA * used_before)
# EVOLVE-BLOCK-END
