import numpy as np

# Empirical-ish Weibull-shaped distribution (mean ~40) used only for heuristic tie-breaking.
# We precompute the probability that a random future item fits in a remaining capacity.
_rng = np.random.default_rng(12345)
_sample = _rng.weibull(1.5, size=20000) * 43.0
_sample = np.clip(_sample, 1, 100).astype(np.int64)
_hist = np.bincount(_sample, minlength=101).astype(np.float64)
_hist[0] = 0.0
_hist /= _hist.sum()
_cum = np.cumsum(_hist)  # _cum[x] = P(item <= x)
_pfit = 1.0 - _cum  # _pfit[x] = P(item > x)


def priority(item, bins):
    """Score bins by tight fit, preferring bins whose remaining space is likely usable."""
    rem = bins - item  # leftover capacity after placing item
    # Primary: best fit (smallest leftover), ties broken by larger "waste" that is less likely
    # to be useful later. Score higher for smaller leftover.
    score = -rem.astype(np.float64)

    # Tie-breaker: among equal leftovers, prefer the bin whose resulting leftover is less likely
    # to remain wasted, i.e. larger leftover is slightly better if it can still hold many items.
    # Use a tiny weight so it only affects ties / near-ties.
    leftover = rem.astype(np.int64)
    leftover[leftover < 0] = 0
    # Probability that leftover capacity is "useful" (can hold at least something). Reward
    # moderate leftovers slightly over tiny unusable scraps.
    useful = _pfit[leftover]
    score += 1e-6 * useful

    # Slight preference for already-fuller bins (earlier bins are not necessarily better, but
    # using more of existing bins reduces bin count); negligible weight to avoid disruption.
    score += 1e-9 * (100 - bins)

    return score
