import numpy as np


def priority(item, bins):
    """
    Best-fit rule.

    Score bins so that the item goes into the fitting bin with the smallest
    remaining capacity (tightest fit). If several bins have the same remaining
    capacity, their original bin order decides the tie.
    """
    return -(bins - item)
