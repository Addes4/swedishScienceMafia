import numpy as np


def priority(item, bins):
    """Best fit, but strongly prefer non-empty bins over completely empty ones.

    bins contains remaining capacities of bins the item fits in, in fixed bin order.
    Unused bins have remaining capacity 100.

    Strategy:
      - For non-empty bins (remaining < 100): score = -(remaining - item), so the
        tightest fit has the highest score.
      - For empty bins (remaining == 100): score = -(100 - item) - BIG, so they are
        only chosen if no non-empty bin fits. Among empty bins ties go to the first,
        which is fine since they are interchangeable.
    """
    rem = bins - item  # residual capacity after placing item; lower is tighter fit

    # Base best-fit score: negative residual (higher = tighter fit)
    score = -rem.astype(np.float64)

    # Penalize completely empty bins so we avoid opening a fresh bin unless needed.
    empty_mask = (bins == 100)
    score[empty_mask] -= 1e9

    return score
