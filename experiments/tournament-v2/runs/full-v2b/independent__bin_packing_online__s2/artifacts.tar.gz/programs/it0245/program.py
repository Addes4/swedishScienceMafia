import numpy as np

_REMAINING = 100

# Global statistics to adapt to the distribution without seeing future items.
_count = 0
_sum = 0
_sum_sq = 0
_hist = np.zeros(_REMAINING + 1, dtype=np.int64)


def priority(item, bins):
    """
    Score each bin. Higher score = better choice. Ties go to earliest bin.

    The rule is a tuned best-fit variant:
    - Strongly prefer bins where the item fits tightly (small leftover).
    - Penalise leftover capacities that are small but non-zero (hard to reuse).
    - Slightly favour leaving unused bins empty when many bins are already open.
    """
    global _count, _sum, _sum_sq, _hist

    # Update online statistics.
    _count += 1
    _sum += item
    _sum_sq += item * item
    _hist[item] += 1

    # bins: remaining capacity of every bin the item fits in.
    # Higher score wins.
    leftover = bins - item  # >= 0 for all shown bins

    # Base: best fit. Prefer smaller leftover.
    score = -leftover.astype(np.float64)

    # Penalise leftovers that are small but still leave some capacity,
    # because they are awkward for future items.
    # Use a smooth penalty that is large for leftover in (0, ~20).
    small_left = np.clip(20.0 - leftover, 0.0, 20.0)
    score -= 0.35 * small_left

    # Slightly penalise using completely empty bins early on,
    # to keep them available for large future items.
    # The penalty decreases as more bins have been opened / used.
    if _count > 0:
        mean = _sum / _count
        var = max(0.0, _sum_sq / _count - mean * mean)
        std = var ** 0.5
    else:
        mean = 40.0
        std = 20.0

    # Estimate how rare large items are: if std is high, keep empty bins longer.
    # Number of unused bins among shown bins (remaining == 100).
    unused = (bins == _REMAINING)
    empty_penalty = 0.15 * (1.0 + std / 40.0)
    score -= empty_penalty * unused.astype(np.float64)

    # Also mildly prefer not to create a leftover that exactly matches 0
    # if another bin has slightly larger leftover but still usable.
    # This is already handled by small_left penalty.

    return score
