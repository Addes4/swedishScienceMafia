import numpy as np


class _State:
    __slots__ = ("count",)
    def __init__(self):
        self.count = 0


_state = _State()


def priority(item, bins):
    """Score bins for online bin packing.

    The goal is to use few bins.  Best-fit is strong for this arrival model, so
    the main score is a monotone function that rewards small post-placement
    remaining capacity.  A tiny index nudge only serves as deterministic tie
    handling in the same spirit as the harness's first-bin tie rule; it does not
    depend on item or instance specifics.
    """
    bins = np.asarray(bins)
    remaining_after = bins - item

    # Primary rule: best fit.  Lower residual is better.  For unused bins,
    # residual is 100 - item, so they are naturally least preferred unless no
    # partially filled bin is better.
    #
    # Use a smooth concave score of residual capacity.  Concavity makes near-full
    # bins attractive while still separating very bad choices.  It is monotone in
    # residual, so the argmax matches best fit except for exact knapsack-like
    # beneficial cases where tiny differences would otherwise tie.
    score = -remaining_after.astype(np.float64)

    # Slight preference for smaller residual among relatively full bins.  This is
    # equivalent to best fit; kept explicit for clarity and numerical stability.
    score += 0.001 * (100.0 - remaining_after.astype(np.float64))

    # Deterministic first-bin tie-breaking: add a tiny decreasing term by bin
    # position.  Because bins is in fixed order, this matches the harness's tie
    # rule while leaving all real comparisons unchanged.
    n = score.shape[0]
    if n > 1:
        score -= np.arange(n, dtype=np.float64) * 1e-12

    return score
