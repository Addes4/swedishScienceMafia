"""Improved best fit: prefer tight fits, but discourage tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a score for every bin; item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item                      # remaining capacity after placing
    score = -residual.astype(np.float64)        # best fit: smallest residual first

    # Mildly penalize leaving a tiny, likely-unusable gap (1..5) so we prefer
    # gap 0 (perfect fill) or a slightly larger tight gap over a sliver.
    waste = (residual > 0) & (residual < 6)
    score[waste] -= 6.0

    return score
