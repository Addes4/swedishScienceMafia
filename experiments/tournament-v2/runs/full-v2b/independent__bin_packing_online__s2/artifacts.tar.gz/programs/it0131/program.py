import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.total = 0.0


_st = _State()


def priority(item, bins):
    n = bins.shape[0]
    # score: best fit -> prefer smallest remaining capacity after placement
    rem = bins - item  # what would be left
    # base: tighter fit is better (smaller rem). Empty bins (rem == 100 - item) penalized slightly.
    score = -rem.astype(np.float64)

    # small bonus for bins that are already partially used (not full/empty bin)
    # distinguish empty bins (original capacity 100) => bins == 100
    empty = bins == 100
    score += np.where(empty, -0.5, 0.0)

    # prefer bins that leave a very small or zero remainder (perfect/exact fits)
    score += np.where(rem == 0, 0.5, 0.0)

    # mild extra preference to avoid creating many near-empty bins:
    # if item is large, tighten more on already-used bins
    _st.count += 1
    _st.total += item
    avg = _st.total / _st.count
    if item >= avg:
        score += np.where(~empty, 0.25, 0.0)

    return score
