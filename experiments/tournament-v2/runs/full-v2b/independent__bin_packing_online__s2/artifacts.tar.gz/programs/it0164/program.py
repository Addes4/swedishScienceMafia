import numpy as np

# Reference item size for "usefulness" of a remainder (mean of distribution ~40).
# We want to avoid leaving remainders that can't fit most items.
_TARGET = 40.0


def priority(item, bins):
    """Rank bins: prefer exact fits, else best fit with a fragmentation penalty.

    item: integer size 1..100.
    bins: numpy int64 array of remaining capacities (>= item), in bin order.
    """
    rem = np.asarray(bins, dtype=np.float64)
    leftover = rem - item  # remaining capacity after placing item here

    # Base: best fit -> smaller leftover is better.
    score = -leftover

    # Penalize leaving a small, hard-to-use remainder (fragmentation).
    # A leftover in (0, some small threshold) is wasteful; a leftover >= item-ish
    # ranges are fine. Use a smooth penalty around very small remainders.
    small = leftover < _TARGET
    # penalty grows as leftover shrinks toward 0 (but exact 0 leftover is ideal -> handled by base)
    frag_penalty = np.where(
        (leftover > 0) & small,
        (_TARGET - leftover) * 0.5,
        0.0,
    )
    score -= frag_penalty

    # Strong bonus for exact fit.
    score += np.where(leftover == 0, 1000.0, 0.0)

    return score
