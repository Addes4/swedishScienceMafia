"""Best-fit bin packing with mild utilization preference for online items."""
import numpy as np


def priority(item, bins):
    """Score bins by best fit: prefer the smallest remaining capacity that can hold item.

    The returned value is -(bins - item), so a smaller post-placement residual capacity
    yields a higher score. Ties naturally go to the earliest bin index.
    """
    return -(bins - item)
