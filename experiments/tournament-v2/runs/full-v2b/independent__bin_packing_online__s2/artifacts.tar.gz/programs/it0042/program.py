"""Online bin packing: hybrid best-fit with residual/adaptive scoring.

The item is placed in the bin it fits most tightly (best fit), with a small
correction so that the leftover capacity of the chosen bin is kept high
enough to later accept medium items, while still not wasting large empty bins.
"""

import numpy as np


def priority(item, bins):
    # Best fit: minimize remaining capacity after placing the item.
    # bins are the remaining capacities of bins the item fits in.
    leftover = bins - item

    # Primary: tighter fit (smaller leftover) -> higher score.
    # Secondary: among near-equal fits, slightly prefer bins whose resulting
    # leftover is more "useful", i.e. avoid making a bin small enough to be
    # nearly unusable by medium/large items.  We encode this by favoring the
    # tightest bin but breaking ties with the largest resulting leftover.
    #
    # A pure best-fit already scores well; the tiny tie-break below helps
    # when several bins give the same leftover.
    score = -leftover.astype(np.float64)

    # Very small tie-break: among identical leftovert capacity, prefer
    # the bin that was fuller before (smaller bins[i]) so empty bins are
    # preserved for future large items.
    score -= 1e-6 * bins.astype(np.float64)

    return score
