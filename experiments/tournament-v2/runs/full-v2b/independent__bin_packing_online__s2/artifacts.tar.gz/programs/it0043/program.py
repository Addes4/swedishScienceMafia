"""Variance-aware best fit for online bin packing.

Primary rule: best fit (smallest residual capacity after placing the item).
Tie-break / near-tie nudge: a tiny deterministic perturbation computed from a
running estimate of item size statistics keeps the rule robust without seeing
future items, and helps avoid pathological tie ordering.
"""
import numpy as np


class _Stats:
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.m2 = 0.0

    def update(self, x):
        self.n += 1
        d = x - self.mean
        self.mean += d / self.n
        self.m2 += d * (x - self.mean)


_state = _Stats()


def priority(item, bins):
    _state.update(item)

    # Best fit: tighter packing gets higher priority (less leftover space).
    score = -(bins - item).astype(np.float64)

    # Small deterministic perturbation to break ties toward bins whose residual
    # after placement is closer to a half-item, which tends to reduce the number
    # of awkward leftovers. Scale is tiny so it never overrides best fit.
    residual = bins - item
    if _state.n > 1:
        var = _state.m2 / _state.n
        scale = min(0.5, float(var) ** 0.5 * 0.01)
    else:
        scale = 0.0

    # Prefer residuals that are close to multiples of the mean item size (or 0),
    # with the preference weighted by 1/(item size) so small items are flexible.
    if scale > 0.0 and item > 0:
        mu = _state.mean
        if mu <= 0.0:
            mu = 1.0
        frac = np.abs((residual / mu) - np.round(residual / mu))
        score += -scale * frac

    return score
