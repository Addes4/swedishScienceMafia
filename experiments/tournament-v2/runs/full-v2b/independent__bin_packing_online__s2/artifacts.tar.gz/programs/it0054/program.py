"""Online bin packing: best-fit with anti-fragmentation tie-breaking.

The item arrives online and must be placed immediately. The classic strong online
heuristic is Best Fit: place the item into the bin where it fits most tightly
(i.e. the bin that will have the smallest remaining capacity afterwards). This
naturally prefers packing items so bins become exactly full, which minimizes the
number of bins used.

We implement Best Fit with a small deterministic tweak: among bins with the same
resulting remaining capacity, we prefer the bin that is currently fuller (less
remaining capacity), to keep the emptier bins available for larger future items.
This never changes the primary best-fit decision, only tie-breaking, so it stays
safe and fast.
"""

import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties).

    Best fit: maximize (item - remaining) == minimize remaining capacity after
    placing the item.  The item only fits in bins with remaining >= item, but we
    still rank all bins monotonically so the harness picks the tightest fit.
    """
    # remaining capacity after placing the item
    after = bins - item
    # Primary: prefer smallest "after" (tightest fit) -> negative after.
    # Tiny secondary term (tie-break): prefer the currently fuller bin
    # (smaller current remaining capacity) to preserve empty space.
    return -after.astype(np.float64) - 1e-6 * bins.astype(np.float64)
