import numpy as np

# Module-level state (allowed by rules).
_calls = 0
_state = {
    "seen": None,   # array-like of remaining capacities snapshot (optional)
}

# Tuned constants for a Weibull-shaped item distribution (mean ~40, capacity 100).
# We score each bin mostly by tightness of fit, with bonuses for "good" residues.
# These constants were chosen to favor leaving bins in useful residual ranges.
BONUS_SMALL = 3      # bonus multiplier for very tight fits
NEWBIN_PENALTY = 5   # penalty for choosing a completely empty bin
NEAR_FULL_BONUS = 2  # bonus for bins that are nearly full (residue small)

# Residue ranges considered "useful" to preserve for future packing
GOOD_RESIDUES = (0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 15, 18, 20,
                 24, 28, 30, 34, 36, 40, 45, 50)


def priority(item, bins):
    """Score bins for best-fit with heuristic capacity-class adjustments."""
    global _calls
    _calls += 1

    bins = np.asarray(bins)

    # Residual after placing item in each bin.
    resid = bins - item

    # Base best-fit score: prefer smaller residual (tighter fit).
    # Negate so smaller resid => higher score.
    score = -resid.astype(np.float64)

    # Bonus for extremely tight fits (resid small but nonzero).
    tight = (resid >= 0) & (resid <= 3)
    score += BONUS_SMALL * tight

    # Penalize opening brand-new bins (resid == 100 - item means bin was empty).
    empty = bins == 100
    score -= NEWBIN_PENALTY * empty

    # Bonus for near-full bins (small residual) to consolidate waste.
    near_full = (resid >= 0) & (resid <= 8)
    score += NEAR_FULL_BONUS * near_full

    # Small bonus if the resulting residual is in a "good" range.
    good = np.zeros(len(bins), dtype=np.float64)
    for r in GOOD_RESIDUES:
        good += (resid == r)
    score += 0.5 * good

    # Tie-break implicitly by bin order via stable ordering: numpy argmax picks first max.
    return score
