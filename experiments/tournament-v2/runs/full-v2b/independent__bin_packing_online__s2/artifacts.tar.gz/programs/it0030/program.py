import numpy as np


class _State:
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.avg = 40.0


_state = _State()


def priority(item, bins):
    # Update running statistics of arriving items.
    _state.count += 1
    _state.total += item
    if _state.count & 63 == 0:
        _state.avg = _state.total / _state.count

    rem = bins
    # Best fit: tighter fit (smaller remaining capacity after placement) is better.
    score = -(rem - item).astype(np.float64)

    # Prefer to keep completely unused bins (cap 100) available when we can.
    # Penalize picking a fresh empty bin; scale penalty by item size so that
    # large items (which need fresh space anyway) are barely affected.
    empty_penalty = (100.0 - item) * 0.35
    score[rem == 100] -= empty_penalty

    # Slight adaptive bias: when recent items are large, favor bins with more
    # remaining capacity (to keep small gaps for small items); when small,
    # favor tighter fits. This keeps the classic best-fit ordering otherwise.
    bias = (_state.avg - 40.0) * 0.02
    if bias != 0.0:
        score += rem * bias

    return score
