import numpy as np

class Packer:
    def __init__(self):
        self.buf = []
        self.step = 0

    def priority(self, item, bins):
        # Hybrid best-fit with mild anti-fragmentation for large items.
        # For large items, spread across fuller bins to preserve small gaps for small items.
        if item >= 60:
            # Prefer bins that fit but leave a usable remainder, avoid creating tiny gaps.
            rem = bins - item
            score = np.where(rem >= 20, rem * 0.01, rem)
            score = score - (bins == 100) * 0.01
        else:
            # Best fit: tightest remaining capacity after placing.
            score = -(bins - item)
            # Slight preference for non-empty bins to reduce bin count usage.
            score = score - (bins == 100) * 0.001
        return score

_packer = Packer()

def priority(item, bins):
    return _packer.priority(item, bins)
