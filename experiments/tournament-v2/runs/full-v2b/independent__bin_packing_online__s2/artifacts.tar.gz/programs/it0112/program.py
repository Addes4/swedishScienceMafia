import numpy as np


def priority(item, bins):
    """Rank bins for best-fit packing with a mild tightness bonus.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of bins it fits in, including empty bins
          (remaining capacity 100). Return a score per bin; highest is chosen, ties go to
          the first bin.
    """
    rem = bins
    residual_after = rem - item
    # Strongly prefer the tightest fit (smallest residual), as in best fit.
    base = -residual_after.astype(np.float64)

    # Slight bonus for leaving a residual that is not too tiny and not too large,
    # which balances avoiding fragment pockets with avoiding wasting large bins.
    # This is monotone-safe: the bonus is small enough not to override tightness
    # differences except between very close fits.
    r = residual_after.astype(np.float64)
    bonus = np.zeros_like(r)
    # Favor residuals around 20-60 when item is small, but keep it tiny.
    if item <= 40:
        bonus = -(np.abs(r - 35.0)) * 1e-4
    else:
        # For larger items, mostly pure best fit.
        bonus = -(np.abs(r - 10.0)) * 1e-5

    return base + bonus
