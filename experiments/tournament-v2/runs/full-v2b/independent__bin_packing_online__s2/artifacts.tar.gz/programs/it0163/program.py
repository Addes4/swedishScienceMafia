import numpy as np


def priority(item, bins):
    # Best-fit: place the item in the bin where it leaves the least remaining capacity.
    # This is equivalent to maximizing (item - remaining_capacity), i.e. minimizing slack.
    # Exact fits are naturally favored.
    return bins
