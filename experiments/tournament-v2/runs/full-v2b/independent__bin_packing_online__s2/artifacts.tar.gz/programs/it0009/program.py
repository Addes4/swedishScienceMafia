"""Online bin packing with a learned residue-aware bin-choice rule.

Key idea: pure best-fit (tightest fit) leaves small unusable residues. We refine it by
preferring bins whose remaining capacity after placing the item is either:
  - exactly 0 (perfect fill), or
  - a "large" capacity so the bin stays useful for several more items,
and by down-weighting bins that would be left with a tiny, hard-to-fill residue.

Since item sizes are drawn from a fixed Weibull-like distribution (mean ~40), we also
track observed item frequencies to estimate how likely a given leftover capacity will be
usable by future items. This is done fully online with no peeking at the future.
"""
import numpy as np

# Global state kept between calls: histogram of item sizes seen so far.
_HIST = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    """Return a priority for every bin; item goes to the highest score (first on ties)."""
    global _HIST, _TOTAL

    bins = np.asarray(bins)
    remain_after = bins - item  # remaining capacity if item placed here

    # Update online histogram of item sizes (for estimating future fill usefulness).
    _HIST[item] += 1.0
    _TOTAL += 1.0

    # Empirical probability that some future item can fill a residual of size r.
    # We approximate P(usable) = sum_{s <= r} p(s), i.e. chance an item fits exactly
    # or leaves room. Use cumulative distribution over observed sizes, with a smooth
    # prior for unseen sizes (uniform-ish) to avoid early-call bias.
    p = _HIST / _TOTAL if _TOTAL > 0 else np.full(101, 1.0 / 100.0)
    # cumulative from full 100 down: chance an item of size <= r exists (fit)
    cdf = np.cumsum(p)  # cdf[r] = P(size <= r)

    # Score bins by how useful their post-placement capacity is:
    # - A perfect fill (remain_after == 0) is best: eliminates the bin's leftover.
    # - Otherwise prefer larger remain_after (still roomy) but penalize tiny leftovers
    #   that are unlikely to ever be filled exactly.
    # Use cdf to measure "fillability": high cdf at remain_after means a small item
    # range could still fit; but we specifically value capacity that can host typical
    # (~mean) items, so reward remain_after near multiples of the mean.
    mean_size = 40.0
    if _TOTAL > 20:
        # estimate mean from observed histogram
        sizes = np.arange(101, dtype=np.float64)
        obs_mean = float((_HIST * sizes).sum()) / _TOTAL
        if obs_mean > 1.0:
            mean_size = obs_mean

    # fillability: probability that a typical item fits into the leftover gap
    # (useful rooms stay valuable). Combine with residue penalty.
    # Avoid leaving a residue in (0, min_size_observed] region that is too small
    # to fit common items -> penalize leftovers smaller than the 10th percentile.
    # Compute a small-size threshold from histogram.
    if _TOTAL > 5:
        cum = np.cumsum(p)
        idx = np.searchsorted(cum, 0.10)
        min_typ = max(1, int(idx))
    else:
        min_typ = 1

    score = remain_after.astype(np.float64)

    # Reward perfect fits strongly.
    score = np.where(remain_after == 0, 1e6, score)

    # Penalize residues that are too small to fit a typical (10th pct) item.
    # remain_after in (0, min_typ) is a wasted sliver.
    sliver = (remain_after > 0) & (remain_after < min_typ)
    score = np.where(sliver, score - 5000.0, score)

    # Slight bonus for leaving a capacity that is close to a multiple of mean_size,
    # suggesting it might be filled by a combination of future items.
    # Reward bins that, when packed with typical items, waste little.
    if mean_size >= 1.0:
        waste = remain_after % mean_size
        waste = np.minimum(waste, mean_size - waste)
        score = score + (mean_size - waste) * 0.05

    return score
