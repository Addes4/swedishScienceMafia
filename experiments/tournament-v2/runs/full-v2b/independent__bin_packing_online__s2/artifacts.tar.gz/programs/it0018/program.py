import numpy as np


def priority(item, bins):
    # Prefer the tightest fit: smaller remaining capacity after placing the item.
    # This is equivalent to best fit, but slightly reinforces lower remaining
    # capacity values so that nearly full bins are used before opening new ones.
    residual = bins - item
    return -(residual.astype(np.float64) + 0.001 * residual * residual)
