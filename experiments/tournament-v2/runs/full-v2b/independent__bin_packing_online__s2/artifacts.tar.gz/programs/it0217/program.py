import numpy as np


class _State:
    """Keeps a tiny amount of aggregate state between calls.

    We track the average item size seen so far, and use it to slightly
    prefer bins whose remaining capacity is just under a few typical items.
    This is cheap and distribution-agnostic.
    """
    def __init__(self):
        self.count = 0
        self.total = 0.0
        self.mean = 40.0

    def update(self, item):
        self.count += 1
        self.total += item
        self.mean = self.total / self.count


_state = _State()


def priority(item, bins):
    """Best fit with a mild preference for filling nearly-complete bins.

    bins: remaining capacities of bins the item fits in (numpy int64).
    """
    _state.update(item)

    # base score: best fit (smaller remaining capacity after placing = better)
    # residual = bins - item, prefer smallest non-negative residual
    residual = bins - item
    score = -residual.astype(np.float64)

    # Mild boost for bins that are close to full: if residual is small,
    # closing the bin is good because it may leave fewer partially-filled bins.
    # Use a small relative bonus so it only breaks near-ties.
    mean = _state.mean if _state.mean > 0 else 40.0
    # normalized tightness: 1 when residual ~ 0, 0 when residual ~ mean
    tightness = np.maximum(0.0, 1.0 - residual.astype(np.float64) / mean)
    score += 0.5 * tightness

    # Small preference for lower bin indices on ties already handled by harness;
    # keep result finite and tie-friendly.
    return score
