import numpy as np


def priority(item, bins):
    """Return scores for placing `item` into bins.

    Strategy: Best-fit with a strong bonus for exact fits, and mildly
    discourage using an empty bin when a partially filled bin is available.
    """
    fits = bins >= item
    scores = np.full(bins.shape, -1e9, dtype=np.float64)

    # Remaining capacity after placing the item
    rem = bins - item

    # Primary: prefer smallest remaining capacity (tightest fit = best fit).
    # Secondary: exact fits are strongly preferred to preserve large bins.
    score = -rem.astype(np.float64)

    # Small bonus for empty bins is bad: we want to fill existing bins first.
    # Penalize empty bins slightly so they are used only when necessary.
    empty = bins == 100
    score[empty] -= 1e6

    # Bonus for exact fit (remaining 0 after placement).
    exact = rem == 0
    score[exact] += 1e9

    scores[fits] = score[fits]
    return scores
