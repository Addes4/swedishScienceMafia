"""Online bin packing: adaptive best-fit rule."""
import numpy as np


def priority(item, bins):
    """Rank bins by tightest fit, with slight preference for exact/near-exact fills.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    Return scores; highest score is chosen, ties to first bin.
    """
    # Remaining capacity after placing the item (smaller is tighter fit).
    residual = bins - item

    # Base score: prefer smallest residual.  Use negative residual so larger score wins.
    score = -residual.astype(np.float64)

    # Small bonus for exact fill (residual == 0), and slight penalty for leaving
    # large residual in previously-used bins that are far from full.
    score += 0.5 * (residual == 0)

    # Prefer using already-opened bins (residual < 100) over fresh bins when fits are
    # otherwise similar: add tiny bonus proportional to used capacity.
    used = 100.0 - bins.astype(np.float64)
    score += 1e-6 * used

    return score
