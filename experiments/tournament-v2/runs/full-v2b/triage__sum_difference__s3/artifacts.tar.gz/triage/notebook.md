# Research notebook: sum_difference

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.887449.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 2 | Pre-seed the search with a large Sidon set or B_2[g] set (e.g., greedy Sidon sequence or modular Sidon set from finite fields) that already has small additive e | 0.61 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.887449 |
| 0 | Replace the naive local random walk with a greedy 2-opt or 3-opt neighbourhood search that swaps or perturbs elements to directly increase the ratio /A-A/ / /A+ | 0.52 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.887449 |
| 3 | Restrict the search to sets contained in a structured arithmetic progression or a union of a few intervals, since the best known constructions often live in rel | 0.51 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 5 | Use a genetic algorithm that maintains a population of sets, with crossover (e.g., concatenating two sets and then selecting a subset that optimizes the score)  | 0.50 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 1 | Use a simulated annealing or Metropolis–Hastings metaheuristic that accepts moves decreasing the score with a temperature-dependent probability, cooling slowly  | 0.48 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 4 | Jointly evolve the set and a scaling factor: generate candidate sets in a small integer range and also search over a multiplier (geometric scaling) to place the | 0.22 | long_shot | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | not_better | 0.879564 |

Best after round 1: **0.887449** (spent $0.03)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 5 | Precompute a large library of small sets with excellent sum-difference ratios (via exhaustive search up to size ~10), then assemble larger sets by concatenating | 0.39 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 0 | Explicitly construct a set A as a union of a few widely spaced geometric progressions (e.g., {c * q^i}) so that the sumset is highly clustered while the differe | 0.38 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.887449 |
| 4 | Dynamically adjust the set size during search by adding elements that increase the difference set more than the sumset, and removing elements that contribute di | 0.29 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 1 | Use integer programming or constraint solving (e.g., with Z3 or OR-Tools CP-SAT) to find the optimal set of size n within a bounded interval, modeling the sum a | 0.24 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 2 | Start from a known near-extremal construction like a truncated additive basis or a set derived from Singer difference sets, then apply a hill-climbing search th | 0.09 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 3 | Instead of local mutations, use a gradient-free optimizer like CMA-ES or differential evolution on the sorted set representation, treating the set as a vector i | 0.05 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 2: **0.887449** (spent $0.05)

## Round 3

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | **Parameterized modular constructions with tuning**: generate A as a union of a few shifted copies of a set of the form {x mod p : x in some progression}, param | 0.23 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.887449 |
| 0 | **Negatively correlated pair sampling for marginal gain**: maintain exact /A-A/ and /A+A/, and for each candidate element to add or remove, estimate the net cha | 0.16 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.844930 |
| 1 | **Quasi-random submodular optimization**: frame the ratio as maximizing /A-A/ while penalizing /A+A/, initialize with a decent seed set, then iteratively add th | 0.16 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 2 | **Discrete Fourier-transform (DFT) guided search**: compute the additive energy or convolution of A via DFTs over a cyclic group; use the Fourier coefficients t | 0.14 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 3 | **Simulated annealing with restart and diversity bonuses**: run multiple short simulated annealing chains from different random initial sets (including translat | 0.05 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 5 | **Graph-based difference-sum trade-off**: treat elements as nodes in a weighted graph where edges correspond to differences and sums; run a max-cut-like heurist | 0.05 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 3: **0.887449** (spent $0.07)

## Round 4

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Regularly inject completely new random sets of varying sizes throughout the search, replacing the current set entirely rather than mutating, to restart explorat | 0.06 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 2 | Represent the set as a binary vector over a bounded integer interval and apply a continuous relaxation (e.g., projected gradient ascent on the log-ratio) with e | 0.06 | favourite | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra (swapped) | not_better | 0.887449 |
| 1 | Use a divide-and-conquer strategy: partition the target integer range into blocks, optimize a small representative subset within each block independently for a  | 0.05 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 3 | Construct A iteratively by solving a sequence of integer linear programs (ILPs) that maximize the minimum gap between difference set size and sum set size, usin | -0.05 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 5 | Formulate the problem as finding a largest subset of a precomputed pool of integers whose sumset avoids a forbidden set of values, then use a MAX-SAT solver or  | -0.06 | long_shot | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | not_better | 0.887449 |
| 4 | Adopt a "randomized rounding" of known extremal combinatorial designs: take a known construction (like a Bose–Chowla set or Singer set), randomly perturb each e | -0.10 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.887449 |

Best after round 4: **0.887449** (spent $0.09)

## Round 5

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Construct A as a union of two sets B and C placed far apart: B is a small set with an excellent difference-to-sum ratio, and C is a much larger Sidon set scaled | 0.21 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.886624 |
| 1 | Represent A as the evaluation of a low-degree polynomial f(x) over a finite field GF(p) at a carefully chosen subset of field elements, then optimize the subset | 0.13 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.887449 |
| 4 | Treat the characteristic function of A as a binary sequence and apply a greedy bit-flipping algorithm that uses fast Walsh–Hadamard transform (over a cyclic gro | 0.06 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.875491 |
| 5 | Formulate the log-ratio maximization as a continuous optimization over the sorted set's consecutive gaps: parameterize A by its gaps g_i = a_{i+1} - a_i, approx | 0.03 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 2 | Use a neural network to learn a continuous embedding of integers into a latent space where the sum-difference trade-off becomes a separable optimization, then d | -0.01 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.883497 |
| 0 | Build the set A via a greedy algorithm that explicitly maximizes a lower bound on /A-A///A+A/ derived from the sizes of restricted sumsets: at each step, add th | -0.03 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.886624 |

Best after round 5: **0.887449** (spent $0.11)

## Round 6

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Construct A as a generalized arithmetic progression A = {∑_{j=1}^d k_j g_j : 0 ≤ k_j < L_j} with small dimension d and optimized step lengths g_j via a global s | 0.12 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.788104 |
| 5 | Generate A by concatenating several short orbits of a carefully chosen linear congruence x → ax + b mod N placed far apart, with the multiplier a and shifts cho | 0.06 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.883033 |
| 1 | Use a subspace evasive set over ℤ_m: generate A = {x : x mod p_i falls in a small pre-image set S_i for several distinct primes p_i, and x mod m lies in a chose | 0.01 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887449 |
| 3 | Model /A-A/ and /A+A/ via the moments of the difference and sum multisets: maximize the empirical variance of differences while minimizing the variance of sums  | 0.01 | middle | Qwen/Qwen3.5-9B:together (swapped) | invalid | 0.000000 |
| 4 | Embed A into a higher-dimensional lattice Λ = {∑ a_i v_i : a_i ∈ A} where the v_i are independent vectors chosen so that the projection onto the sums direction  | -0.02 | long_shot | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | not_better | 0.887449 |
| 2 | Represent A as the set of positions of 1s in a long binary string, and apply a genetic programming approach that evolves the characteristic string directly usin | -0.05 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 6: **0.887449** (spent $0.14)

