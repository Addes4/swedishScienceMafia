# EVOLVE-BLOCK-START
"""
Simulated annealing with restarts and diversity bonuses for set optimization.
Maximize log|A - A| / log|A + A| + (1 - 1/|A|) / 100
"""
import math
import random
import time


def _score_a(A):
    """Calculate the optimization score for set A."""
    if len(A) < 2:
        return -1e9
    try:
        a_set = set(A)
        diff = {x - y for x in a_set for y in a_set}
        sums = {x + y for x in a_set for y in a_set}
        if len(diffs) == 0 or len(sums) == 0:
            return -1e9
        score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(A)) / 100
        return score
    except Exception:
        return -1e9


def _invariant_seed(n):
    """Generate a structured n-element set with good difference/sum properties."""
    if n <= 0:
        return []
    # Use a combination of powers and arithmetic progress
    if n <= 4:
        # Small geometric-like sets
        return list(range(1, n + 1)) * n // n + [n * 2, n * 3] if n > 2 else [1, 2, 3]
    base = n
    result = []
    for i in range(n):
        if i < base // 2:
            result.append(2 ** i)
        elif i < base:
            result.append(2 ** (i - base // 2) * 3)
        else:
            result.append(2 * i + base)
    return result[:n]


def _random_seed(n, start):
    """Generate a random n-element set around start."""
    spacing = 1000
    return [start + i * spacing + random.randint(-10, 10) for i in range(n)]


def _mutate(A, scale=100):
    """Apply various mutations to set A."""
    if len(A) < 3:
        return A[:]
    A = A[:]
    op = random.random()
    
    if op < 0.3:
        # Modify an element
        i = random.randrange(len(A))
        change = random.randint(-scale, scale)
        A[i] = A[i] + change
    
    elif op < 0.6:
        # Add a new element
        base = max(abs(x) for x in A) + 1
        A.append(base * 2 + random.randint(-10, 10))
    
    elif op < 0.8 and len(A) > 5:
        # Remove an element
        del A[random.randrange(len(A))]
    
    else:
        # Swap elements
        if len(A) >= 2:
            i, j = random.sample(range(len(A)), 2)
            A[i], A[j] = A[j], A[i]
    
    return list(set(A))[:60]


def _swap_merge(A1, A2):
    """Try to merge two sets and keep the best."""
    if len(A1) < 2 or len(A2) < 2:
        return None
    # Take union, but limit size
    merged = list(A1) + list(A2)
    # Keep top k by quality
    merged_set = set(merged)
    best = []
    for val in sorted(abs(x) for x in merged_set):
        if len(best) >= 60:
            break
        try:
            best.append(val)
        except:
            break
    score = _score_a(best)
    return best if score > _score_a(A1) and score > _score_a(A2) else list(set(A1))


def _best_subsample(candidates, k=30):
    """Take best candidates and diversify."""
    if len(candidates) <= k:
        return list(set(candidates))
    # Score each, take best 2k, merge if needed
    scored = []
    for cand in candidates:
        sc = _score_a(cand)
        if sc > -10:
            scored.append((sc, cand))
    scored.sort(reverse=True)
    top = [sc[1] for sc in scored[:k * 2]]
    return list(set(top))


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    deadline = time.time() + 119
    best_result = None
    best_score = -1e9
    best_A = []
    
    n = 50
    
    for iteration in range(20):
        # Multiple restarts with different seeds
        current_best = []
        current_score = -1e9
        
        # Different seed strategies
        seeds = [
            _invariant_seed(n),
            _random_seed(n, 1),
            _random_seed(n, 10),
            _random_seed(n, 100),
            _random_seed(n, 1000),
            list(range(1, n // 4 + 1)) + [x * 2 for x in range(n // 2, n)],
            [2 ** i for i in range(n)],
            [10 ** i for i in range(n)],
        ]
        
        # Temperature schedule for SA
        k = 20  # initial temperature
        beta_end = 1.5
        beta_curr = 2.0
        min_iter = 100
        max_iter = 500
        
        for seed_seeds in seeds:
            if not seed_seeds or len(seed_seeds) < 2:
                continue
            A = seed_seeds[:n] + [x for x in range(random.randint(1000, 5000)) if x % 7 != 0][:n - len(A)]
            
            # SA loop
            temp = k
            for step in range(max_iter):
                if time.time() > deadline:
                    break
                
                A_mut = _mutate(A, scale=50 if step < max_iter // 2 else 100)
                sc = _score_a(A_mut)
                
                current_best = A[:]
                current_score = sc
                if sc < best_score:
                    sc_ls = 0.3
                    temp_ls = temp * sc_ls
                else:
                    temp_ls = min(200, temp * 1.1)
                
                if sc >= best_score:
                    A = A_mut[:]
            
            # Save good results
            if current_score > best_score:
                best_score = current_score
                best_A = list(set(A))
                if len(best_A) < 3:
                    best_A = [1, 2, 3]
        
        # One-time global merge attempt
        if len(best_A) >= 5:
            variation = sorted(list(set(best_A)))[1:]
            test = [best_A[i] + (variation[i] if i < len(variation) else 0) for i in range(min(len(best_A), 15))]
            sc_test = _score_a(test)
            if sc_test > best_score and len(test) > len(best_A):
                best_A, best_score = list(test), sc_test
    
    # Final refinement on the best result
    A = list(set(best_A))
    if len(A) < 2:
        A = [1, 2]
    A = sorted(A)
    
    deadline = time.time() + 30
    for _ in range(50):
        if time.time() > deadline:
            break
        
        A = A[:]
        if not A:
            break
        i = random.randrange(len(A))
        delta = random.randint(-20, 20)
        A[i] += delta
        A = sorted(list(set(A)))
        if len(A) < 2:
            break
    
    return list(A)

solve()
# EVOLVE-BLOCK-END
