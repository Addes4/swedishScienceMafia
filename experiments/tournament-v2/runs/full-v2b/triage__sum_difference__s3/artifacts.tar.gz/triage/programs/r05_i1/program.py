import math
import random
import time
from itertools import combinations

def _modinv(x, p):
    return pow(x, p - 2, p)

def _score_from_field_points(p, points):
    # points: list of ints mod p
    a = set(points)
    if len(a) < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add((x - y) % p)
            sums.add((x + y) % p)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def _evaluate_monomial(exp, points, p):
    # exp is a single integer exponent
    return [pow(x, exp, p) for x in points]

def _evaluate_polynomial(exponents, coeffs, points, p):
    res = [0] * len(points)
    for e, c in zip(exponents, coeffs):
        if c % p == 0:
            continue
        for i, x in enumerate(points):
            res[i] = (res[i] + c * pow(x, e, p)) % p
    return res

def _random_subset(points, k):
    return sorted(random.sample(points, k))

def _mutate_subset(current, allowed_points, p):
    cur = list(current)
    if random.random() < 0.3 and len(cur) > 5:
        # remove random element
        idx = random.randrange(len(cur))
        del cur[idx]
    if random.random() < 0.4:
        # add new point not in cur
        available = [pt for pt in allowed_points if pt not in cur]
        if available:
            cur.append(random.choice(available))
    if random.random() < 0.5:
        # swap one point
        available = [pt for pt in allowed_points if pt not in cur]
        if available and cur:
            idx = random.randrange(len(cur))
            cur[idx] = random.choice(available)
    return sorted(set(cur))

def _local_search_subset(initial_points, p, allowed_points, deadline, best_overall):
    cur_points = list(initial_points)
    cur_score = _score_from_field_points(p, cur_points)
    best_points = cur_points[:]
    best_score = cur_score
    
    while time.time() < deadline:
        # generate neighbor
        cand = _mutate_subset(cur_points, allowed_points, p)
        if len(cand) < 2:
            continue
        s = _score_from_field_points(p, cand)
        if s >= best_score:
            best_score = s
            best_points = cand[:]
            cur_points = cand[:]
            cur_score = s
        elif random.random() < 0.1:
            # jump back to best to escape local minima
            cur_points = best_points[:]
            cur_score = best_score
        else:
            # sometimes accept worse
            pass
    return best_points, best_score

def solve():
    random.seed(2024)  # deterministic for reproducibility, but can be removed
    deadline = time.time() + 118  # leave margin
    best_overall_score = 0.0
    best_overall_set = [1, 2, 3]  # fallback
    
    # We will try several small primes and polynomial constructions
    # With low-degree monomials, f(x)=x^k or f(x)=a*x^k+b*x^m etc.
    # Simple approach: pick a subset of GF(p) and evaluate f(x)=x (identity) or f(x)=x^d
    # We iterate over primes and monomial degrees.
    
    prime_candidates = [101, 199, 307, 401, 503, 601, 701, 809, 907, 1009, 2003, 3001, 4001, 5003, 6007, 7001, 8009, 9001, 10007]
    # Limit size: at most 4000 elements; with primes up to ~10000 we can take subsets up to p.
    
    for p in prime_candidates:
        if time.time() > deadline:
            break
        allowed_points = list(range(p))
        # We will try a few monomial degrees
        for deg in [1, 2, 3, 5, 7, 11]:
            if time.time() > deadline:
                break
            # evaluate f(x) = x^deg mod p
            vals = [pow(x, deg, p) for x in allowed_points]
            # Use these values as our candidate set A modulo p, but we need actual integers.
            # The difference/sum sets are considered modulo p, but the problem uses absolute integers.
            # We can map them back to integers in [-p/2, p/2] interval to satisfy the absolute value bound 1e15.
            # This mapping preserves differences mod p? No, the actual difference set uses integer subtraction.
            # However if we treat the points as integers in [0, p-1], differences mod p can differ from integer differences
            # when wrap-around occurs. But for small p relative to bound, wrap-around rarely happens if values are centered.
            # To be safe, we can center them: map x to x if x <= p//2 else x - p.
            # Then differences in Z are exactly the differences modulo p because the set resides in an interval of length < p.
            # Actually sumset can have wrap-around issues, but we can ensure that A is small enough so that no wrap-around.
            # We'll keep the direct mapping 0..p-1 for scoring, but note that A-A and A+A in Z != mod p if wrap.
            # So we better guarantee that sumset stays within [-p+1, 2p-2] which might cause wrap? 
            # But if we treat integer A as subset of [0, p-1] then A+A is subset of [0, 2p-2]; the difference A-A subset of [-(p-1), p-1].
            # If we want to compute actual integer sumset size, we can't use modulo arithmetic faithfully.
            # However, the problem allows any integers up to 1e15 absolute. We can simply use the set {x mod p} as integers 0..p-1,
            # and compute their exact integer difference and sum sets, which will be large (size O(p^2)) if we take many points.
            # Wait, the score metric is log|A-A|/log|A+A|. For a subset of [0, p-1], the sumset size is at most 2p-1.
            # If we take a set A such that f(x) is a permutation polynomial (like x^k with gcd(k,p-1)=1), then the image is a permutation,
            # meaning A is a subset of all elements. If we take many points, difference set becomes full [0,p-1] (size p) and sumset maybe full [0,2p-2] (size 2p-1).
            # This gives log p / log (2p) ~ < 1. But we want larger ratio. 
            # The idea is to choose a subset that has many differences but few sums. For additive combinatorics, sets like geometric progressions or
            # coset of a multiplicative subgroup have small sumset. In a finite field, a multiplicative subgroup G has small product set, but we want sumset.
            # The "polynomial evaluation" idea: choose f(x)=x^2 maybe? If we take A = {x^2 mod p : x in S} for a subset S, then A is subset of quadratic residues,
            # which is a subgroup of size (p-1)/2. Sumset of a subgroup might be small? Actually sumset of a subgroup can be the whole field or large.
            # But we can try to pick A to be a union of a few cosets of a multiplicative subgroup to get many differences via group structure and small sumset.
            # Simpler: we directly search for subset S of [0,p-1] that optimizes score using local search. That's the _local_search_subset approach above.
            # Let's just use that: for each p and each degree, we take the initial set as the image of a random subset S of size ~ p//2.
            # Then local search mutates this subset S (of domain points) and compute A = f(S) mod p, treating them as integers 0..p-1.
            
            # To avoid wrap-around distorting sums/diffs, we need to ensure that A (as integers in [0, p-1]) has sumset within a range where subtraction/ addition
            # doesn't wrap modulo p relative to integer arithmetic. Actually integer sumset/diffset is exactly the set of all possible sums/differences mod p, but without modulo reduction.
            # For integers a,b in [0, p-1], a+b is in [0, 2p-2]; this is distinct for each pair (a,b) unless a+b = a'+b' with different pairs.
            # So the size of integer sumset equals the number of distinct sums modulo p as well? Not exactly: a+b (mod p) can have collisions if a+b >= p, because a+b mod p = a+b-p.
            # But if we treat A as integers 0..p-1, the integer sumset includes numbers up to 2p-2, and the integer differences include negative numbers.
            # The size of integer sumset |A+A| is at most 2p-1 but may be less due to collisions. The mod p sumset would be exactly the set of sums mod p, which is smaller if collisions happen.
            # Since the problem definition uses actual integer addition and subtraction, we must compute exact integer sets, not modulo p.
            # But we can still search over A as subsets of [0, p-1] and compute actual integer sum/diff sizes; the search space is huge.
            # Our local search will evaluate _score_from_field_points using modulo p for quick scoring? No, that function currently computes modulo p sets; that's not correct for real score.
            # Let's fix _score_from_field_points to compute actual integer sum and diff sets from the subset of integers in [0, p-1].
            # We'll rename to _score_integer and pass the integer list.
            # However, the number of integers in A may be up to 4000, p maybe 5000, so computing all pairs (O(n^2)) is fine.
            pass
    
    # Given the time, let's directly implement a local search over integer sets using a nice structured initial guess.
    # Known optimal constructions: sets with small doubling constant but large difference constant. 
    # For example, a geometric progression: A = {g^i : i=1..k} has small sumset? Not really. 
    # Better: A = {x_i = i*d} + B where B is a basis. Not trivial.
    # Since time is short, we'll use a generic random local search with smarter mutation and larger n, using fast set operations.
    
    # We'll generate initial set as a random subset of a range and apply operations.
    random.seed(42)
    n = 100  # starting size
    # We'll aim for sets of size ~4000 eventually.
    best_set = list(range(1, 21))  # dummy
    best_score = 0.0
    
    # Use local search similar to the evolved block but with more intelligence:
    # - start with a set derived from a low-discrepancy sequence?
    # - use simulated annealing
    def score_intset(s):
        if len(s) < 2:
            return 0.0
        # compute exact diffs and sums using integers
        # careful: O(n^2) per evaluation, n up to maybe 2000 for time constraints.
        # We can limit size to keep scoring fast.
        # Use list for fast iteration.
        lst = list(s)
        diffset = set()
        sumset = set()
        for i in range(len(lst)):
            ai = lst[i]
            for j in range(len(lst)):
                aj = lst[j]
                sumset.add(ai + aj)
                diffset.add(ai - aj)
        return math.log(len(diffset)) / math.log(len(sumset)) + (1 - 1 / len(lst)) / 100

    # Heuristic: use a set that is a union of some arithmetic progressions with different moduli, to get many differences.
    # Try random search.
    cur = [random.randint(-10**12, 10**12) for _ in range(50)]
    cur_score = score_intset(cur)
    best_set = cur[:]
    best_score = cur_score
    
    # Mutation: swap, add, remove, perturb
    while time.time() < deadline:
        if len(cur) < 2:
            cur = best_set[:]
            continue
        cand = list(cur)
        op = random.random()
        if op < 0.5:
            # change value of one element
            idx = random.randrange(len(cand))
            cand[idx] += random.randint(-10, 10)
        elif op < 0.8:
            # add new random integer
            if len(cand) < 4000:
                cand.append(random.randint(-10**14, 10**14))
        elif op < 0.95:
            # remove random
            if len(cand) > 5:
                del cand[random.randrange(len(cand))]
        else:
            # shuffle subset
            random.shuffle(cand)
        # ensure distinct
        cand_set = set(cand)
        if len(cand_set) < 2:
            continue
        cand = list(cand_set)
        s = score_intset(cand_set)
        if s > best_score:
            best_score = s
            best_set = cand[:]
            cur = cand
            cur_score = s
        elif s > cur_score or random.random() < 0.01:
            cur = cand
            cur_score = s
        else:
            # occasionally reset to best
            if random.random() < 0.001:
                cur = best_set[:]
                cur_score = best_score
        # periodically try to grow set with smart additions
        if len(cur) < 4000 and random.random() < 0.01:
            # add multiple elements that don't increase sumset much?
            # naive: add elements within a small range to keep sumset low.
            pass

    return sorted(set(best_set))[:4000]
    
