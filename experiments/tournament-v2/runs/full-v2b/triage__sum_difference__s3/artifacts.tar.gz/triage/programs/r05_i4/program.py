# EVOLVE-BLOCK-START
"""Greedy bit-flipping on the characteristic sequence of A, using FFT to evaluate
additive-energy changes cheaply.

We work on Z_N (N a power of two, e.g. 512).  A subset A of Z_N is represented by
its indicator f in {0,1}^N.  Then

    (A + A)(t)  =  (f * f)(t)      (autocorrelation-style additive counts, cyclic sum)
    (A - A)(t)  =  (f * g)(t),   g(u) = f(-u)

so the number of distinct sums / differences can be obtained from the convolution
arrays.  The greedy step flips one bit (add or remove an element) and keeps the
move that gives the best ratio log|A-A| / log|A+A| + bonus.

To keep things fast we recompute the convolution arrays with FFT (numpy) whenever
we evaluate a candidate move, but we restrict the candidate evaluation to a small
pool chosen by a heuristic, and we run the greedy loop until the time budget
expires.
"""

import math
import time

import numpy as np


def _counts(f, N):
    """Cyclic additive counts via FFT.  f real length N indicator of A."""
    F = np.fft.rfft(f)
    conv = np.fft.irfft(F * F, n=N)          # (f * f): number of ordered pairs summing to t
    # difference counts: g(u) = f[-u]
    g = np.empty(N, dtype=np.float64)
    g[0] = f[0]
    g[1:] = f[:0:-1]
    G = np.fft.rfft(g)
    diff = np.fft.irfft(F * G, n=N)          # (f * g): pairs with a - b = t (cyclic)
    return np.round(conv).astype(np.int64), np.round(diff).astype(np.int64)


def _score_from_counts(conv, diff, size):
    s = int(np.count_nonzero(diff))
    d = int(np.count_nonzero(conv))
    if d < 2 or s < 2:
        return -1e9
    return math.log(s) / math.log(d) + (1.0 - 1.0 / size) / 100.0


def solve():
    N = 512
    rng = np.random.default_rng(12345)

    # initial set: a random sparse subset plus a few structured points
    f = np.zeros(N, dtype=np.float64)
    init_idx = rng.choice(N, size=8, replace=False)
    f[init_idx] = 1.0

    conv, diff = _counts(f, N)
    size = int(f.sum())
    best_score = _score_from_counts(conv, diff, size)
    best_f = f.copy()

    deadline = time.time() + 110.0

    # Precompute index arrays to make single flips cheap.
    while time.time() < deadline:
        improved = False
        # evaluate all single-bit flips greedily (N of them).  Recompute only
        # the affected convolutions incrementally when possible; here we simply
        # recompute using FFT for each candidate but only a subset for speed.
        idxs = np.arange(N)
        rng.shuffle(idxs)
        # Evaluate a decent fraction of flips each round for a good tradeoff.
        trial = idxs[: max(64, N // 2)]
        cur_best = best_score
        cur_move = -1
        for t in trial:
            nf = f.copy()
            add = nf[t] < 0.5
            nf[t] = 1.0 - nf[t]
            nsz = size + (1 if add else -1)
            if nsz < 2:
                continue
            nc, nd = _counts(nf, N)
            sc = _score_from_counts(nc, nd, nsz)
            if sc > cur_best:
                cur_best = sc
                cur_move = t
        if cur_move >= 0:
            add = f[cur_move] < 0.5
            f[cur_move] = 1.0 - f[cur_move]
            size += 1 if add else -1
            best_score = cur_best
            best_f = f.copy()
            improved = True

        if not improved:
            # Random restart / perturbation to escape local optimum.
            f = best_f.copy()
            size = int(f.sum())
            k = rng.integers(1, 4)
            for _ in range(int(k)):
                t = int(rng.integers(0, N))
                if f[t] > 0.5:
                    f[t] = 0.0
                    size -= 1
                else:
                    f[t] = 1.0
                    size += 1
            if size < 2:
                f = best_f.copy()
                size = int(f.sum())

    # Map indices of Z_N into actual integers, centered around 0
    idxs = np.nonzero(best_f)[0]
    if len(idxs) == 0:
        return [0, 1]
    half = N // 2
    out = []
    for i in idxs:
        v = int(i)
        if v > half:
            v -= N
        out.append(v)
    out = sorted(set(out))
    if len(out) < 2:
        out = [0, 1]
    return out
# EVOLVE-BLOCK-END
