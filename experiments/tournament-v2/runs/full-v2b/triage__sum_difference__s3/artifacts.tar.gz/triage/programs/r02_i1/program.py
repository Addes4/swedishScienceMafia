import math
import random
import time
import numpy as np


def _score(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return -1e9
    # sum and difference sets
    s = a[:, None] + a[None, :]
    d = a[:, None] - a[None, :]
    ms = np.unique(s).size
    md = np.unique(d).size
    if ms <= 1:
        return -1e9
    return math.log(md) / math.log(ms) + (1.0 - 1.0 / n) / 100.0


def _score_fast(a):
    """Score from a sorted list (python) - avoids numpy overhead for small n."""
    n = len(a)
    if n < 2:
        return -1e9
    sums = set()
    diffs = set()
    for x in a:
        for y in a:
            sums.add(x + y)
            diffs.add(x - y)
    ms = len(sums)
    md = len(diffs)
    if ms <= 1:
        return -1e9
    return math.log(md) / math.log(ms) + (1.0 - 1.0 / n) / 100.0


def solve():
    random.seed(12345)
    deadline = time.time() + 115.0

    best = None
    best_score = -1.0

    def consider(arr):
        nonlocal best, best_score
        arr = sorted(set(arr))
        if len(arr) < 2:
            return -1e9
        sc = _score_fast(arr)
        if sc > best_score:
            best_score = sc
            best = arr[:]
        return sc

    # ---- structured seeds ----
    seeds = []
    # arithmetic progression
    for n in (30, 50, 80, 120, 200):
        seeds.append(list(range(n)))
    # AP with a hole / perturbations
    for n in (40, 70, 110):
        base = list(range(n))
        arr = base[:]
        if arr:
            arr[-1] += random.randint(1, 5)
        seeds.append(sorted(set(arr)))
    # union of two APs with different offsets
    for n in (30, 60, 100):
        half = n // 2
        A = list(range(half))
        M = n * 3
        A += [M + i for i in range(n - half)]
        seeds.append(sorted(set(A)))
    # random sparse subsets
    for _ in range(20):
        n = random.randint(30, 200)
        R = random.randint(n, 5 * n)
        seeds.append(sorted(random.sample(range(R + 1), min(n, R + 1))))

    for sd in seeds:
        if time.time() > deadline:
            break
        consider(sd)

    # ---- simulated annealing / local search ----
    restart = 0
    while time.time() < deadline:
        restart += 1
        # pick an initial configuration
        if best is not None and random.random() < 0.5:
            cur = best[:]
            # perturb
            for _ in range(random.randint(1, 5)):
                if cur and random.random() < 0.8:
                    i = random.randrange(len(cur))
                    cur[i] += random.randint(-3, 3)
            cur = sorted(set(cur))
        else:
            n = random.randint(30, 260)
            R = random.randint(n, 4 * n)
            if R + 1 >= n:
                cur = sorted(random.sample(range(R + 1), n))
            else:
                cur = list(range(n))

        cur_score = _score_fast(cur)
        if cur_score > best_score:
            best_score = cur_score
            best = cur[:]

        T = 0.08
        stag = 0
        local_deadline = min(time.time() + random.uniform(3.0, 8.0), deadline)

        while time.time() < local_deadline:
            cand = cur
            op = random.random()
            if op < 0.45 and cand:
                # modify one element
                cand = cand[:]
                i = random.randrange(len(cand))
                span = max(2, len(cand))
                delta = random.randint(-span, span)
                cand[i] += delta
                cand = sorted(set(cand))
            elif op < 0.65 and len(cand) < 380:
                # add element
                lo = cand[0]
                hi = cand[-1]
                spread = max(2, (hi - lo))
                v = random.randint(lo - spread, hi + spread)
                cand = sorted(set(cand + [v]))
            elif op < 0.80 and len(cand) > 15:
                # remove element
                cand = cand[:]
                i = random.randrange(len(cand))
                cand.pop(i)
            else:
                # big move: shift a block / scale-ish
                cand = cand[:]
                k = random.randint(1, max(1, len(cand) // 4))
                lo = random.randrange(len(cand))
                hi = min(len(cand), lo + k)
                d = random.choice([-2, -1, 1, 2])
                for i in range(lo, hi):
                    cand[i] += d * (i - lo + 1)
                cand = sorted(set(cand))

            if len(cand) < 2:
                continue
            s = _score_fast(cand)
            if s > cur_score or (T > 1e-6 and random.random() < math.exp((s - cur_score) / T)):
                if abs(s - cur_score) < 1e-12 and random.random() > 0.3:
                    pass
                else:
                    cur, cur_score = cand, s
                    if s > best_score:
                        best_score = s
                        best = cand[:]
                        stag = 0
            stag += 1
            T *= 0.9995
            if T < 1e-4:
                T = 0.02

        # ---- extension phase on the global best ----
        if best is not None and time.time() < deadline and random.random() < 0.35:
            cur = best[:]
            cur_score = best_score
            for _ in range(random.randint(1, 4)):
                if len(cur) < 380:
                    lo = cur[0]
                    hi = cur[-1]
                    spread = max(2, hi - lo)
                    v = random.randint(lo - spread, hi + spread)
                    if v not in cur:
                        cur = sorted(cur + [v])
            cs = _score_fast(cur)
            if cs > best_score:
                best_score = cs
                best = cur[:]

    return sorted(set(best)) if best else [0, 1]
