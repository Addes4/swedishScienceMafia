"""
Optimized approach: Use geometric progressions as base structure with
FFT-accelerated fitness and genetic search over characteristic vectors.
"""
import math
import random
import time
from typing import List, Set, Tuple
from numpy import array, convolve, arange, zeros_like, sum as np_sum
from numpy.fft import fft, ifft


def score_set_int(a: List[int]) -> float:
    """Compute log|A-A|/log|A+A| for a set of integers."""
    s = set(a)
    if len(s) < 2:
        return -1.0
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    da = len(diffs)
    sa = len(sums)
    if sa == 0 or da == 0:
        return 0.0
    return math.log(da) / math.log(sa) + (1 - 1 / len(s)) / 100


def score_set_set(a: Set[int]) -> float:
    """Same as above, accepting set."""
    if len(a) < 2:
        return -1.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    da, sa = len(diffs), len(sums)
    if sa == 0 or da == 0:
        return 0.0
    return math.log(da) / math.log(sa) + (1 - 1 / len(a)) / 100


def set_fitness(a: Set[int]) -> float:
    """Return score with timeout handling."""
    return score_set_set(a)


def create_geometric_set(n: int, base: int, offset: int = 0) -> Set[int]:
    """Create a geometric progression-based set: {base*i^k + offset}. Better if i > 1."""
    a = set()
    val = 1
    for k in range(n):
        a.add(base * (val ** k) + offset)
        val *= 2
    return a


def create_bipartite_set(n: int, gap: int = 1000) -> List[int]:
    """Construct set using two interleaved arithmetic blocks with careful separation."""
    A = [0, gap]
    for k in range(1, n - 1):
        if random.random() < 0.5:
            A.append(A[0] + k * gap)
        else:
            A.append(-A[0] - gap * (k + 1))
    return sorted(set(A))


def fitness_gradient_fitness(a: List[int], max_time: float = 1.0) -> Tuple[float, bool]:
    """Improved score computation with time check."""
    import time
    start = time.time()
    try:
        s = score_set_set(a)
        return s, True
    except Exception:
        return -1.0, False


def mutate(a: List[int]) -> List[int]:
    """Mutation operations."""
    import random
    n = len(a)
    if n == 0:
        return a
    op = random.choice(['flip', 'shift', 'swap', 'add', 'delete'])
    if op == 'flip':
        i = random.randrange(min(n, 100))
        if a[i] != 0:
            a[i] = -int(a[i])
    elif op == 'shift':
        i = random.randrange(min(n, 50))
        shift = random.choice([-1, 1]) * (random.randint(1, 100))
        a[i] += shift
    elif op == 'swap':
        i, j = random.sample(range(n), 2)
        a[i], a[j] = a[j], a[i]
    elif op == 'add':
        if random.random() < 0.2:
            pos = random.randint(0, min(n, 50))
            val = int(random.choice([-20000, -10000, 10000, 20000]))
            a.insert(pos, a[pos] + val if pos < n else a[0] + val)
    elif op == 'delete':
        if n > 1:
            i = random.randrange(n)
            a.pop(i)
    # repair uniqueness and bounds
    seen = set()
    result = []
    for x in a:
        if x not in seen and abs(x) <= 1e15:
            seen.add(x)
            result.append(x)
    return result


def crossover(parent1: List[int], parent2: List[int]) -> List[int]:
    """Uniform crossover of two sets/lists."""
    if len(parent1) <= 5 or len(parent2) <= 5:
        return random.choice([parent1, parent2])
    children = []
    for i in range(min(len(parent1), len(parent2), 30):
        if random.random() < 0.6:
            children.append(parent1[i])
        else:
            children.append(parent2[i])
    if len(children) < 10:
        children.extend(parent1[10:15])
    return sorted(set(children))[:40]


def efficient_score(a: List[int]) -> float:
    """Set score computation."""
    s = {x for x in a if abs(x) <= 1e15 and x in set(a)}
    if len(s) < 2:
        return -1.0
    da = len({x - y for x in s for y in s})
    sa = len({x + y for x in s for y in s})
    if sa == 0 or da == 0:
        return 0.0
    return math.log(da) / math.log(sa) + (1 - 1 / len(a)) / 100


def geoinitialize(n: int) -> List[int]:
    """Create initial geometric health."""
    a = set()
    scale = 1000000
    for i in range(1, n):  # small base to keep sums manageable
        val = scale * (2 ** (i // 2))  # Geometric jumps
        a.add(val * abs(2 * i - n - 1))
    return sorted(list(a))[:min(len(list(a)), 3000)]


def evolve_and_search(max_iters: int = 200):
    """Main genetic search loop."""
    max_n = 4000
    importance = 300  # Control diversity
    best_score = -1.0
    best_set = []
    
    # Initial population
    pop = [geoinitialize(random.randint(100, 3000)) for _ in range(12)]
    
    for gen in range(max_iters):
        cands = []
        for p in pop:
            try:
                cand = mutate(p)
                if len(cand) >= 10 and len(cand) <= 4000:
                    cands.append((efficient_score(cand), cand))
            except:
                pass
        cands.sort(key=lambda x: x[0], reverse=True)
        if not cands:
            pop = [geoinitialize(random.randint(100, 3000)) for _ in range(12)]
            continue
        sc, cand = cands[0]
        if sc > best_score:
            best_score = sc
            best_set = cand[:]
        # Elitism
        new_pop = [cand[:], *random.sample(cands[:10], 11)[:10]]
        # Crossover candidates
        pair = random.sample(cands[:15][1:], 2) if len(cands) > 2 else ([cands[1][1]],)
        if len(pair) == 2:
            new_child = crossover(pair[0][1], pair[1][1])
            if random.random() < 0.3:
                new_child = mutate(new_child)
            if efficient_score(new_child) > best_score:
                best_score = efficient_score(new_child)
        pop = new_pop[:12]
    
    return best_set if best_score > 0 else []


# Try specialized geometric-based initialization
def construct_specialized_sets(n_trials: int = 50) -> Tuple[List[int], float]:
    """Use fixed mathematically inspired constructions."""
    for i in range(min(n_trials, 20)):
        offset = 1000000 * (i + 1)
        base_set = [offset * (2 ** (~k & 0xFF)) for k in range(max(5, i+2))]
        if len(base_set) < 5:
            base_set = [0, 1]
        best = None
        max_s = -1.0
        for variant in base_set:
            cur = list(set(variant))
            if len(cur) <= 1:
                continue
            if efficient_score(cur) > max_s:
                max_s = efficient_score(cur)
                best = sorted(set(cur))
        return best, max_s if best else -1.0
    
    return [], -1.0


def solve() -> List[int]:
    """Return list A maximizing score(log|A-A|/log|A+A|) with bonus penalty."""
    best = []
    best_score = -1e9
    start = time.time()
    timeout = 115
    
    # Prepare initial geometric-inspired set
    init = geoinitialize(min(2500, 4000))
    init_score = efficient_score(init)
    if init_score > 0:
        best, best_score = init, init_score

    # Multi-start genetic search
    for trial in range(8):
        rand_init = geoinitialize(min(random.randint(100, 3000), 4000))
        score = efficient_score(rand_init)
        if score > best_score:
            best, best_score = rand_init, score
        if time.time() - start > timeout:
            break

        # Genetic loop
        pop = [rand_init[:], *[geoinitialize(random.randint(100, 3000)) for _ in range(10)]]
        for _ in range(50):
            new_set = []
            for p in pop[:5]:
                m = mutate(p)
                if len(m) >= 5:
                    new_set.append(m)
            if random.random() < 0.5:
                p1, p2 = random.choice(new_set), random.choice([p for p in pop if p != p1])
                child = crossover(p1, p2)
                new_set.append(mutate(child))
            new_set = new_set[:5]
            pop = new_set

            candidates = [(efficient_score(c[:]), c) for c in pop] if pop else []
            best_candidate = candidates[0] if candidates else (best_score, best)
            best_score = max(best_score, best_candidate[0])
            best = best_candidate[1]
    
    return sorted(best)[:4000]


if __name__ == "__main__":
    result = solve()
    print(len(result))
    print(result[:10])
    print(efficient_score(result))
