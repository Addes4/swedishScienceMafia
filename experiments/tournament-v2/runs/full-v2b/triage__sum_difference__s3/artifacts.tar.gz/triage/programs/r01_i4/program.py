import math
import random
import time

def _score(a):
    if not isinstance(a, list) or len(a) < 2:
        return 0.0
    s = set(a)
    if len(s) != len(a):
        return 0.0
    size = len(s)
    diffs = set()
    sums = set()
    # optimize by using list
    l = list(s)
    for i, x in enumerate(l):
        for y in l[i:]:
            d = x - y
            diffs.add(d)
            diffs.add(-d)
            sums.add(x + y)
        sums.add(x + x)  # diagonal
    # Adjust for missing self differences; they are 0
    diffs.add(0)
    log_diff = math.log(len(diffs))
    log_sum = math.log(len(sums))
    return log_diff / log_sum + (1.0 - 1.0 / size) / 100.0

def _mutate(cur, small_range):
    """mutate current list of small integers in place; returns new list."""
    cand = cur[:]
    # slightly shift one element
    idx = random.randrange(len(cand))
    cand[idx] += random.randint(-small_range, small_range)
    # occasional insert
    if random.random() < 0.05:
        cand.append(random.randint(-small_range*2, small_range*2))
    # occasional delete
    if random.random() < 0.03 and len(cand) > 5:
        del cand[random.randrange(len(cand))]
    # occasional complete scramble
    if random.random() < 0.01:
        cand = [random.randint(-small_range, small_range) for _ in range(len(cur))]
    return cand

def _scale_and_score(base_list, scale, offset=0):
    """Apply scaling and optional offset, return scored list."""
    scaled = [x * scale + offset for x in base_list]
    return _score(scaled), scaled

def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A| + bonus."""
    random.seed(42)  # deterministic but varied in evolution
    deadline = time.time() + 110  # leave some margin
    
    # We maintain a pool of base sets (small integers) and their best scale/offset
    # Base sets are small integer lists; scale is searched geometrically
    
    best_score = 0.0
    best_scaled_list = [7, 15, 18, 22, -3, -2]  # fallback
    
    # Initial population of base sets
    base_population = []
    for _ in range(30):
        size = random.randint(15, 40)
        base = [random.randint(-15, 15) for _ in range(size)]
        base_population.append(base)
    
    # Also include current best base representation
    small_best_base = [0, 1, 4, 6]  # a good small set
    base_population.append(small_best_base)
    
    small_range = 10  # for mutations
    
    # Parameters for scale search
    scale_min_pow = 0
    scale_max_pow = 12  # 2^12 ~ 4096, combined with offset gives large numbers
    max_val = 10**15
    
    while time.time() < deadline:
        # Pick a random base to evolve
        idx = random.randrange(len(base_population))
        base = base_population[idx]
        cand_base = _mutate(base, small_range)
        
        # Try to optimize scale for this candidate base
        # We use random search over scale and offset, plus local refinement
        best_local_score = 0.0
        best_local_list = None
        best_scale = 1
        best_offset = 0
        
        # Quick random search for scale/offset
        for _ in range(200):
            # Choose scale as power of 2 times small factor
            scale_pow = random.uniform(scale_min_pow, scale_max_pow)
            scale = int(2 ** scale_pow)
            # add small multiplier variation
            scale = int(scale * random.uniform(0.8, 1.2))
            if scale < 1: scale = 1
            
            offset = random.randint(-2 * max_val // scale, 2 * max_val // scale) if scale > 0 else random.randint(-100, 100)
            # ensure values in range
            max_abs_val = max(abs(x)*scale + abs(offset) for x in cand_base) if cand_base else 0
            if max_abs_val > max_val:
                # Rescale to fit
                if max_abs_val > 0:
                    scale = int(scale * max_val / max_abs_val * 0.99)
                    if scale < 1: scale = 1
                offset = random.randint(-max_val//scale, max_val//scale) if scale > 0 else 0
            
            sc, lst = _scale_and_score(cand_base, scale, offset)
            if sc > best_local_score:
                best_local_score = sc
                best_local_list = lst
                best_scale = scale
                best_offset = offset
        
        # Local hill climbing for scale/offset
        for _ in range(50):
            # vary scale slightly
            new_scale = best_scale
            if random.random() < 0.7:
                new_scale = int(best_scale * random.uniform(0.9, 1.1))
            else:
                new_scale = best_scale + random.randint(-5, 5)
            if new_scale < 1: new_scale = 1
            
            new_offset = best_offset + random.randint(-10, 10)
            
            # check range
            max_abs_val = max(abs(x)*new_scale + abs(new_offset) for x in cand_base) if cand_base else 0
            if max_abs_val > max_val:
                continue
            
            sc, lst = _scale_and_score(cand_base, new_scale, new_offset)
            if sc > best_local_score:
                best_local_score = sc
                best_local_list = lst
                best_scale = new_scale
                best_offset = new_offset
        
        # Replace if better than population member
        if best_local_score > _score(base_population[idx]):
            base_population[idx] = cand_base
            # also keep track of the best scaled version
            if best_local_score > best_score:
                best_score = best_local_score
                best_scaled_list = best_local_list
        
        # Occasionally replace a random base with cand_base regardless
        if random.random() < 0.05:
            base_population[random.randrange(len(base_population))] = cand_base
        
        # Maintain population diversity: occasionally generate fresh base
        if random.random() < 0.02:
            size = random.randint(15, 50)
            base_population[random.randrange(len(base_population))] = [random.randint(-15, 15) for _ in range(size)]
    
    # Final refinement: try to improve the best scaled list directly by small shifts
    cur_best = best_scaled_list[:]
    cur_score = best_score
    for _ in range(2000):
        cand = cur_best[:]
        idx = random.randrange(len(cand))
        cand[idx] += random.randint(-2, 2)
        s = _score(cand)
        if s > cur_score:
            cur_best = cand
            cur_score = s
    return sorted(set(cur_best))

if __name__ == "__main__":
    result = solve()
    print(f"Len: {len(result)}, score: {_score(result):.5f}")
