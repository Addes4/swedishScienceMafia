import math
import random
import time
import numpy as np
import scipy.optimize as opt

def compute_score(A):
    if not A:
        return 0.0
    A = sorted(list(set(A)))
    n = len(A)
    if n < 2:
        return 0.0
    diffs = set(x - y for x in A for y in A)
    sums = set(x + y for x in A for y in A)
    if not sums:
        return 0.0
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return score

def construct_A(params):
    a0, a1, bases, n_terms = params[:4]
    A = [a0 + i * a1 for i in range(n_terms)]
    return A

def optimize_A():
    best_A = None
    best_score = -float('inf')
    found = False
    
    # Strategy 1: Two arithmetic progressions with different bases
    for b in range(2, 10):
        for c in range(3, 6):
            for k in range(3, 20):
                A = [b * 3**i + j * c for i in range(3) for j in range(k)]
                score = compute_score(A)
                if score > best_score:
                    best_score = score
                    best_A = sorted(set(A))
    
    # Strategy 2: Geometric progression + linear offset
    for base in [2, 3, 5, 7]:
        for offset in range(-50, 50, 5):
            for n in range(5, 15):
                A = [offset + base**i for i in range(n)]
                score = compute_score(A)
                if score > best_score:
                    best_score = score
                    best_A = sorted(set(A))
    
    # Strategy 3: Multi-level construction
    for m in range(3, 6):
        base = 2**m
        for d in range(1, 4):
            A = [d * base + i for i in range(base, base + d * base, d)]
            if A and len(set(A)) >= 5:
                score = compute_score(A)
                if score > best_score:
                    best_score = score
                    best_A = sorted(set(A))
    
    # Strategy 4: Neural-style embedding using scipy optimization
    def params_to_A(params):
        a0, a1, a2 = params[:3]
        A = np.clip(a0 + np.arange(10) * a1, -1e12, 1e12)
        A = A + np.random.randint(-10, 10, size=10) + np.random.randint(0, 100)
        return A.astype(int)
    
    # Strategy 5: Set from powers with multiple blocks
    for block_base in [1, 2]:
        for num_blocks in [3, 4, 5]:
            powers = 3**np.arange(num_blocks)
            offsets = powers + np.random.randint(-100, 100, size=num_blocks)
            candidates = [10*p + o for p, o in zip(powers, offsets)]
            for combo in [(1, 2), (2, 1), (1, 3), (3, 1), (1, 1), (2, 2)]:
                if 0 in combo:
                    A = [combo[0]*3**i for i in range(num_blocks)] + \
                             [combo[1]*3**i + j*2 for i in range(num_blocks) for j in range(combo[0])]
                    A = sorted(set(A))
                    score = compute_score(A)
                    if score > best_score:
                        best_score = score
                        best_A = A
    
    # Local refinement
    if best_A:
        candidates = [generate_local(A, rate=0.4) for A in [best_A]]
        best_A = max(candidates, key=lambda x: compute_score(x))
    
    return best_A

def generate_local(current, rate=0.3):
    A = sorted(list(set(current)))
    n = len(A)
    if n < 5:
        return current
    
    mutated = current[:]
    rate = min(rate, 0.5)
    
    for _ in range(n):
        idx = random.randint(0, n - 1)
        delta = random.randint(-10, 10)
        mutated[idx] += delta
        if mutated[idx] in A and mutated[idx] != current[idx]:
            break
    
    return mutated

def refine_integer_set(A):
    A = sorted(list(set(A)))
    if len(A) < 5:
        return A
    
    for _ in range(100):
        improved = False
        candidates = []
        for i in range(len(A)):
            for delta in [-10, -9, -8, 8, 9, 10]:
                cand = A[:]
                cand[i] += delta
                candidates.append(cand)
        
        for cand in candidates:
            if set(cand) == set(A):
                continue
            score = compute_score(cand)
            if score > compute_score(A):
                A = sorted(list(set(cand)))
                improved = True
                break
    
    if not improved:
        # Try removing elements
        for i in range(len(A)):
            cand = A[:i] + A[i+1:]
            score = compute_score(cand)
            if score > compute_score(A):
                A = sorted(list(set(cand)))
                break
    
    return A

def solve():
    start = time.time()
    A = np.array([0, 1, 4, 6, 9, 15], dtype=int)
    
    # Use known high-performing constructions
    constructions = []
    
    # Construction 1: Powers of 2 with base set
    for i in range(3):
        base_construction = [2**j + k*3 for j in range(5) for k in range(4)]
        constructions.append(sorted(set(int(x) for x in base_construction)))
    
    # Construction 2: Hybrid (powers of 3 + small set)
    for mult in [1, 2, 3]:
        for add in range(-10, 10):
            A_con = [mult*3**j + add for j in range(5)]
            A_con = sorted(set(int(x) for x in A_con))
            if len(A_con) >= 5:
                constructions.append(A_con)
    
    # Construction 3: Geometric + arithmetic
    for g_base in [2, 3, 5, 7]:
        for a_step in [1, 2, 3]:
            A_con = [g_base**j + i*a_step for j in range(5) for i in range(2)]
            A_con = sorted(set(int(x) for x in A_con))
            if len(A_con) >= 5:
                constructions.append(A_con)
    
    # Pick best from constructions
    best_A = max(constructions, key=lambda x: compute_score(x))
    best_score = compute_score(best_A)
    
    # Fine-tune with insertion deletions
    for _ in range(100):
        A = best_A[:]
        mutants = []
        for i in range(len(best_A)):
            for delta in [-5, -3, 3, 5, 10]:
                cand = A[:]
                cand[i] += delta
                if len(set(cand)) >= 5 and abs(cand[i]) < 1e15:
                    mutants.append(cand)
        
        candidates = mutants + [A]
        A = max(candidates, key=lambda x: compute_score(x))
        if compute_score(A) <= best_score:
            break
        best_score = compute_score(A)
        best_A = A
    
    # Apply agresive integer refinement
    A = refine_integer_set(best_A)
    
    # Ensure constraints
    A = sorted(set(A))
    A = [x for x in A if abs(x) <= 1e15]
    
    # Bonus refinement for maximum size and score
    deadline = time.time() + 110
    while time.time() < deadline and len(A) < 200:
        improved = False
        for _ in range(50):
            improved = False
            for i in range(len(A)):
                for delta in [-20, -10, 10, 20]:
                    cand = A[:]
                    if len(cand) >= 5:
                        cand[i] += delta
                        if len(set(cand)) >= 5:
                            score = compute_score(cand)
                            if score > compute_score(A):
                                A = sorted(list(set(cand)))
                                improved = True
                                break
                if improved:
                    break
            if improved:
                break
        if not improved:
            break
    
    late_stray = sorted(list(set(A)))
    if time.time() < time.time() + 15:
        pass
    
    return late_stray

# Main execution
def main():
    result = solve()
    score = compute_score(result)
    print(f"Set size: {len(result)}")
    print(f"Score: {score:.6f}")
    print(f"Max value: {max(result) if result else 0}")
    print(f"Min value: {min(result) if result else 0}")

if __name__ == "__main__":
    main()
