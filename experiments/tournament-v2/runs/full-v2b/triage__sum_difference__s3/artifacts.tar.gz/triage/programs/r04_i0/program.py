# EVOLVE-BLOCK-START
"""Enhanced random local search with restart injections, larger search space, and parameter tuning."""
import math
import random
import time

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def _random_set(size, val_range):
    """Generate a random set of given size with values in [-val_range, val_range]."""
    if size > 2 * val_range + 1:
        size = 2 * val_range + 1
    if size <= 0:
        size = 2
    # Use sampling without replacement to guarantee distinct values
    return random.sample(range(-val_range, val_range + 1), size)

def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    # Initial best: start with a known good seed
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    cur = best[:]
    
    deadline = time.time() + 120
    last_injection = time.time()
    injection_interval = 5.0  # seconds between fresh injections
    
    # Parameter ranges for random exploration
    val_range_options = [20, 50, 100, 200, 500, 1000]
    size_options = [4, 5, 6, 7, 8, 10, 12, 15, 20, 25]
    
    iteration = 0
    while time.time() < deadline:
        iteration += 1
        
        # Periodic injection: completely replace current solution with a fresh random set
        if time.time() - last_injection > injection_interval:
            size = random.choice(size_options)
            val_range = random.choice(val_range_options)
            cur = _random_set(size, val_range)
            last_injection = time.time()
            # Evaluate this new random set
            s = _score(cur)
            if s >= best_score:
                best, best_score = cur[:], s
            continue
        
        # Standard mutation: modify current solution
        cand = cur[:]
        
        # Operations on the candidate
        if len(cand) > 0:
            # Mutate an element
            idx = random.randrange(len(cand))
            cand[idx] += random.randint(-5, 5)  # wider mutation range
        
        # Occasionally add/remove elements
        if random.random() < 0.08 and len(cand) < 30:  # allow larger sets
            cand.append(random.randint(-200, 200))
        if random.random() < 0.03 and len(cand) > 3:
            cand.pop(random.randrange(len(cand)))
        
        # Occasionally scale all values to explore different magnitude regions
        if random.random() < 0.01:
            factor = random.choice([2, 3, 5, 10, -2, -1])
            cand = [x * factor for x in cand]
        
        # Ensure distinct elements
        cand = list(set(cand))
        if len(cand) < 2:
            cand = _random_set(random.choice(size_options), random.choice(val_range_options))
        
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.15:  # soft reset to best occasionally
            cur = best[:]
        # else keep current for next iteration
    
    return sorted(set(best))
# EVOLVE-BLOCK-END
