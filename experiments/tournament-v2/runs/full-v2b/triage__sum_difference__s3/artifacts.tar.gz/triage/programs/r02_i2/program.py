# EVOLVE-BLOCK-START
"""
Construct near-extremal sets using Singer-like difference sets combined 
with hill-climbing refinement that preserves structural invariants for dense difference sets with sparse sum sets.

The construction uses a derived method from Singer difference set theory, 
specifically leveraging properties of projective geometries where the ring Z_q for prime q provides 
natural difference-rich and sum-sparse elements.
"""
import math
import random
import time


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    sums = {x + y for x in a for y in a}
    diffs = {x - y for x in a for y in a}
    ssum = len(sums)
    sdiff = len(diffs)
    return math.log(ssdiff) / math.log(ssum if ssum > 1 else ssum) + (1.0 - 1.0 / n) / 100


def _generate_singer_segment(q_prime):
    """Generate elements based on Singer difference set principles for prime q"""
    modulus = q_prime
    elements = []
    for i in range(q_prime):
        v = (i * (i + 1)) % modulus
        if 0 <= v < modulus:
            elements.append(v)
    return sorted(set(elements))


def _build_far_spaced_set(n, base_gap=10000):
    """Construct a set with large differences and restricted sums using geometric spacing."""
    elements = [base_gap * (i * i + i // 2) for i in range(n)]
    return sorted(elements)


def _hill_climbed_from_seed(start_set, trials=5000, noise_range=5):
    """Refine a given set using hill-climbing while preserving combinatorial structure."""
    current = list(sorted(set(start_set)))
    current_n = len(current)

    if current_n < 2:
        return current[:]

    best_current = current[:]
    best_score = _score(best_current)

    deadline = time.time() + 45

    while time.time() < deadline:
        improved = False
        candidate = current[:]
        n = len(candidate)
        if n == 0:
            break

        op = random.uniform(0, 1)

        if op < 0.4:
            # Flip sign
            idx = random.randrange(max(1, n - 1))
            candidate[idx] = -candidate[idx]
        elif op < 0.7:
            # Relocate element to nearby
            idx = random.randrange(n)
            delta = random.randint(-noise_range, noise_range)
            candidate[idx] + delta

        elif op < 0.9:
            # Insert random unrelated value
            val = random.randint(1000000, 20000000000)
            if val not in candidate and len(candidate) < 4000:
                candidate.append(val)
                candidate = sorted(set(candidate))

        n = len(candidate)

        if n < 2:
            candidate[:] = [0, 1]
            n = 2

        candidate = sorted(set(candidate))
        if len(candidate) < len(best_current):
            continue

        score_now = _score(candidate)
        if score_now >= best_score:
            best_score = score_now
            best_current[:] = candidate[:]
            current[:] = candidate[:]
            improved = True
            if improved and random.random() < 0.05:
                # Occasional restart with minor variation
                random.seed()
                break
        elif random.random() < 0.1:
            current = best_current[:]

        if not improved and random.random() < 0.02:
            # Occasionally abandon and reseed
            break

    return best_current


def _construct_structured_set(m, spacing=10000):
    """Construct using structure similar to Singer set segments + spacing to control sums"""
    # This approximates a Singer-like delta set in Z_m
    elements = []
    offset = 0
    squares = [(i * i + i) % m * spacing for i in range(m)]
    for i in range(m):
        for j in range(-1, 2):
            val = squares[i] * (i + j * 0.1 + 0.5)
            elements.append(int(val))
    elements = sorted(set(elements))
    # Re-normalize if required
    mod = 1_000_000_000
    return sorted(set(x % mod for x in elements))


def solve():
    """Return a list of distinct integers A maximizing log|A - A| / log|A + A|."""

    best_set = None
    best_score = 0.0

    # Initial seed construction
    # Use a combination of Singer-like structure + hill climb refinement
    candidates_to_try = [
        (500, 1000000),       # Singer-like across modulus
        (7, 17, 37900),       # Starting set: manual construction from problem knowledge
        (100, 20_000_000),    # Wide spacing geometric
    ]

    time_limit = time.time() + 110

    # Construct strongly
    pats = [(_seed_interleave + 1000) * (i * 17) for i in range(4, 50)]
    base_set = sorted(set(pats[:50]))

    best = base_set[:]
    best_score = _score(best)
    if len(base_set) < 3:
        base_set = [0, 20, 500]
        base_set = _hill_climbed_from_seed(base_set, trials=1000)

    import random

    while time.time() < time_limit:
        # Try constructing from random seeds
        for siz in [10, 20, 30, 50]:
            start_vals = [i * (i + 1) * 10000 + i * 1000 for i in range(siz)]

            refined = _hill_climbed_from_seed(start_vals, trials=5000, noise_range=5)
            s = _score(refined)
            if s > best_score:
                best_score = s
                best = refined[:]
        if random.random() < 0.5:
            refined = _hill_climbed_from_seed(best[:], trials=3000, noise_range=3)
            s = _score(refined)
            if s > best_score:
                best_score = s
                best = refined[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
