import math
import random
import time

def _score(a):
    """Calculate the score for a set A."""
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in set(a) for y in set(a)}
    sums = {x + y for x in set(a) for y in set(a)}
    if len(sums) < 2:
        return 0.0
    r = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100
    return r, len(a), len(diffs), len(sums)

def build_initial_structure(n, seed=0):
    """Construct an initial set using a structured polynomial-like layout."""
    rng = random.Random(seed)
    elements = []
    base = 1000
    step = 50000
    offset = 50000
    for i in range(n // 2):
        elements.append(i * step + offset)
    for i in range(n // 2):
        elements.append(i * step + offset + n * step // 10)
    return list(set(elements))

def paddle_shuffle(elements):
    """Create a腥配 randomized version of elements."""
    rng = random.Random(42)
    padded = elements[:]
    for i in range(len(padded)):
        shift = rng.randint(-100, 100)
        padded[i] += shift
    return list(set(padded))

def greedy_optimize(perturbed_set, max_steps=2000):
    """Remove elements greedily to improve score."""
    rng = random.Random(100)
    best_set = list(set(perturbed_set))
    best_score = _score(best_set)[0]
    
    # Shuffle to explore different removal orderings
    for _ in range(max_steps):
        shuffled = list(best_set)
        rng.shuffle(shuffled)
        cur_score = best_score
        cur_set = best_set[:]
        
        for i in range(len(shuffled)):
            elem = shuffled[i]
            test_set = [x for x in cur_set if x != elem]
            if len(test_set) < 5:
                break
            test_score = _score(test_set)[0]
            if test_score > cur_score:
                cur_score = test_score
                cur_set = test_set
        
        if test_score > best_score:
            best_set, best_score = cur_set, test_score
    return best_set

def run_random_perturb(base, perturb_factor=15, rng_seed=123):
    """Apply small random perturbations to base elements."""
    rng = random.Random(rng_seed)
    perturbed = []
    for x in base:
        shift = int(rng.randint(-perturb_factor, perturb_factor))
        perturbed.append(x + shift)
    return list(set(perturbed))

def run_random_sequence(base, num_sequences=500, max_iter=50):
    """Run multiple perturbation sequences and optimize, keeping the best."""
    rng = random.Random(999)
    global_best = list(set(base))
    global_score = _score(global_best)[0]
    
    seen = [frozenset(global_best)]
    
    for seq in range(num_sequences):
        start_ops = 10000 + seq * 5000
        rng_override = random.Random(777 + seq)
        
        cur_perturbed = list(set(base))
        for i in range(len(cur_perturbed)):
            shift = int(rng_override.randint(-20, 20))
            cur_perturbed[i] += shift
        
        cur_perturbed = sorted(set(cur_perturbed))
        seen.add(frozenset(cur_perturbed))
        
        for _ in range(max_iter):
            cur_set = list(cur_perturbed)
            rng_override.shuffle(cur_set)
            
            best_in_seq = list(cur_set)
            best_in_seq_score = _score(best_in_seq)[0]
            
            for i in range(len(cur_set)):
                elem = cur_set[i]
                test = [x for x in best_in_seq if x != elem]
                if len(test) < 5:
                    break
                s = _score(test)[0]
                if s > best_in_seq_score:
                    best_in_seq = test
                    best_in_seq_score = s
            
            if best_in_seq_score > global_score:
                global_score = best_in_seq_score
                global_best = list(set(best_in_seq))
    
    return global_best

def solve():
    """Main solver using randomized rounding + greedy post-processing."""
    start_time = time.time()
    max_time = 120
    base_n = 800 // 5  # Initial size for polynomial-ish layout
    best_set = None
    best_score = 0.0
    
    for seed in range(50):
        if time.time() - start_time > max_time:
            break
        rng = random.Random(seed)
        initial = build_initial_structure(base_n, seed)
        if len(initial) < 4:
            continue
        perturbed = run_random_perturb(initial, perturb_factor=100, rng_seed=seed)
        optimized = greedy_optimize(perturbed, max_steps=1000)
        score, _, _, _ = _score(optimized)
        if score > best_score:
            best_score = score
            best_set = optimized
    
    if best_set is None or len(best_set) < 5:
        fallback = list(range(0, min(1000, 370)))
        return sorted(fallback)
    
    # Ensure final set meets problem constraints
    result = list(set(best_set))
    result = sorted([x for x in result if abs(x) <= 1e15])
    
    return result
