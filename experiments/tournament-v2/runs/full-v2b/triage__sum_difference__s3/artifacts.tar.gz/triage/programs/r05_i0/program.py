import math
import heapq
import random
import time

def _score(a):
    """Compute the score for a set A."""
    a = set(a)
    if len(a) < 2:
        return -float('inf')
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def _estimate_impact(candidate, current_A):
    """Estimate impact of adding candidate to A."""
    new_sums = set()
    new_diffs = set()
    
    for x in current_A:
        new_sums.add(candidate + x)
        new_diffs.add(candidate - x)
    
    new_sums.add(candidate + candidate)
    new_diffs.add(candidate - candidate)
    
    return len(new_sums) - max(0, len(new_sums.intersection({x+y for x in current_A for y in current_A}))), \
           len(new_diffs)

def _precompute_candidates(n_candidates, base=2):
    """Precompute a pool of candidate integers."""
    candidates = set()
    
    # Geometric-like progression (powers of 2 with offsets)
    for i in range(n_candidates):
        # Create values like 2^i, 2^i + 1, 2^i + 2, etc.
        block_size = min(4, n_candidates // (i + 1)) if n_candidates > 0 else 4
        gap = 1 << i
        for offset in range(block_size):
            val = gap + offset
            if abs(val) <= 1e15:
                candidates.add(val)
            val = gap - (block_size - 1 - offset)
            if val >= gap - block_size and val <= gap:
                if abs(val) <= 1e15:
                    candidates.add(val)
            
            # Higher powers
            val_large = (1 << i) * (i + 1) + offset
            if abs(val_large) <= 1e15:
                candidates.add(val_large)
    
    return list(candidates)

def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A|."""
    deadline = time.time() + 120
    
    # Start with a strategic initial set
    initial_set = {0, 1, 3, 9, 27, 81}  # Geometric progression base 3
    current_A = sorted(list(initial_set))
    
    # Precompute a large candidate pool
    all_candidates = _precompute_candidates(2000)
    used_candidates = set(all_candidates)
    candidates = all_candidates[:]
    
    # Priority queue: (-estimated_gain, candidate)
    # We'll score based on expected increase in differences vs sums
    
    heap = []
    for cand in candidates:
        # Estimate collision ratio
        new_sums = {cand + x for x in current_A}
        new_sums.add(cand + cand)
        sum_collisions = len({s for s in new_sums if s in {x+y for x in current_A for y in current_A}})
        
        new_diffs = {cand - x for x in current_A}
        new_diffs.add(cand - cand)
        
        # Favor candidates that add many differences with few new sum collisions
        score = len(new_diffs) - 0.5 * max(0, sum_collisions)
        if score > 1.5:
            heapq.heappush(heap, (-score, cand))
    
    best_A = list(current_A)
    best_score = _score(best_A)
    current_score = best_score
    
    while time.time() < deadline and heap:
        neg_score, cand = heapq.heappop(heap)
        
        if cand in used_candidates:
            continue
        
        test_A = list(current_A) + [cand]
        test_score = _score(test_A)
        
        if test_score > best_score:
            if len(test_A) <= 4000:
                best_A = test_A
                best_score = test_score
                used_candidates.add(cand)
                current_A = test_A
                
                # Refill heap
                for c in range(min(50, len(candidates) - 500)):
                    new_cand = candidates[c]
                    if new_cand not in used_candidates:
                        new_sums = {new_cand + x for x in current_A}
                        new_sums.add(new_cand + new_cand)
                        sum_collisions = len({s for s in new_sums if s in {x+y for x in current_A for y in current_A}})
                        new_diffs = {new_cand - x for x in current_A}
                        new_diffs.add(new_cand - new_cand)
                        score = len(new_diffs) - 0.5 * max(0, sum_collisions)
                        if score > 1.0:
                            heapq.heappush(heap, (-score, new_cand))
    
    # Return sorted list of unique integers
    return sorted(set(best_A))

if __name__ == "__main__":
    result = solve()
    score = _score(result)
    print(f"Set size: {len(result)}")
    print(f"Score: {score:.6f}")
    print(f"Diffs: {len({x-y for x in result for y in result})}")
    print(f"Sums: {len({x+y for x in result for y in result})}")
