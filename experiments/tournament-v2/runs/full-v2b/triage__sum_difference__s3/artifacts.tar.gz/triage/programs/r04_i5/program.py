import math
import random
import time
from itertools import combinations
import numpy as np
from scipy.optimize import minimize, Bounds, LinearConstraint
from scipy.sparse import csr_matrix

def score_set(A):
    """Compute the score for a set A."""
    A = set(A)
    if len(A) < 2:
        return 0.0
    diff_set = {x - y for x in A for y in A}
    sum_set = {x + y for x in A for y in A}
    return math.log(len(diff_set)) / math.log(len(sum_set)) + (1 - 1 / len(A)) / 100

def solve():
    """
    Find a finite set of integers with large difference set and small sum set.
    
    Uses a continuous relaxation / SDP-like heuristic:
    1. Generate a pool of candidate integers.
    2. Formulate as selecting a subset that maximizes differences while controlling sums.
    3. Solve a relaxed quadratic program to get soft assignments.
    4. Round to a discrete set.
    5. Apply local search to refine.
    """
    np.random.seed(42)
    random.seed(42)
    deadline = time.time() + 110  # Leave 10 seconds buffer
    
    # Step 1: Generate candidate pool
    # Use multiple techniques to build diverse candidates
    pool = set()
    
    # Small integers that might work well
    for i in range(-30, 31):
        pool.add(i)
    
    # Some structured sets known to be good for sum-difference problems
    # Arithmetic progressions with different ratios
    for d in [2, 3, 4, 5, 6, 7]:
        for start in [-50, -20, 0, 20, 50]:
            for k in range(20):
                pool.add(start + k * d)
                
    # Geometric-like progressions
    for r in [2, 3]:
        for start in [1, -1, 2, -2, 5, -5]:
            val = start
            for _ in range(20):
                if abs(val) <= 10**6:
                    pool.add(val)
                else:
                    break
                val *= r
    
    # Random sampling for diversity
    for _ in range(2000):
        pool.add(random.randint(-5000, 5000))
    
    # Take a manageable subset for the relaxation
    pool = sorted(set(pool))
    max_pool_size = 500
    if len(pool) > max_pool_size:
        # Select diverse subset
        indices = np.linspace(0, len(pool) - 1, max_pool_size, dtype=int)
        pool = [pool[i] for i in indices]
    
    pool = list(pool)
    n = len(pool)
    
    # Precompute difference and sum set sizes for evaluation
    # We want to MAXIMIZE log|A-A| / log|A+A|
    # This is equivalent to maximizing |A-A| subject to |A+A| <= K for some K
    # Or we can maximize |A-A| - lambda * |A+A|
    
    # Build constraint: we want many pairs to have distinct differences
    # and many pairs to have overlapping sums (to reduce sumset size)
    
    # Relaxation: let x_i in [0,1] be the "probability" of including element i
    # Then |A-A| is approximated by number of distinct differences weighted by probabilities
    # |A+A| is approximated by number of distinct sums
    
    # Create symmetric matrices for differences and sums
    diff_matrix = np.zeros((n, n), dtype=int)
    sum_matrix = np.zeros((n, n), dtype=int)
    
    pool_arr = np.array(pool)
    
    # Precompute unique diff values and sum values
    all_diffs = set()
    all_sums = set()
    for i in range(n):
        for j in range(n):
            all_diffs.add(pool[i] - pool[j])
            all_sums.add(pool[i] + pool[j])
    
    diff_list = sorted(all_diffs)
    sum_list = sorted(all_sums)
    
    nd = len(diff_list)
    ns = len(sum_list)
    
    # Map each diff to an index
    diff_to_idx = {d: i for i, d in enumerate(diff_list)}
    sum_to_idx = {s: i for i, s in enumerate(sum_list)}
    
    # For each diff, the set of pairs (i,j) that produce it
    diff_pairs = [[] for _ in range(nd)]
    sum_pairs = [[] for _ in range(ns)]
    
    for i in range(n):
        for j in range(n):
            d = pool[i] - pool[j]
            s = pool[i] + pool[j]
            diff_pairs[diff_to_idx[d]].append((i, j))
            sum_pairs[sum_to_idx[s]].append((i, j))
    
    # We want to maximize |A-A| - lambda * |A+A|
    # Where |A-A| is the number of diffs that have at least one pair selected
    # For relaxation: probability that a diff appears is roughly 
    # 1 - product over all pairs (1 - x_i * x_j)
    # which is complex. Use a simpler proxy: sum over pairs x_i * x_j
    # However we want DISTINCT diffs, so we should measure the number of diffs with at least one pair,
    # not the total pair count.
    
    # Better approach: use log-barrier or just direct optimization of a surrogate
    # Surrogate: maximize sum_d min(1, sum_{i,j in pairs(d)} x_i x_j) - lambda * sum_s min(1, sum_{i,j in pairs(s)} x_i x_j)
    # This is still not smooth.
    
    # Alternative: use a MAX-CUT like relaxation where we want differences to be distinct
    # For each pair (i,j) contributing to a diff, we want the diff to appear,
    # i.e., at least one such pair should be selected.
    # This is MAX-SAT style, but we can relax: for each diff d, the indicator y_d is >= any x_i * x_j, 
    # and we want to maximize sum y_d while minimizing sum of sum indicators.
    
    # Let's try a simpler continuous optimization: 
    # Maximize something like sum_{i,j} x_i x_j * w_{i,j} where w encourages new diffs
    # We can weight pairs by 1/(number of pairs producing that diff) to avoid double counting.
    
    # Build weight matrix: w_diff[i,j] = 1 / count(diff(i,j))
    diff_pair_counts = np.zeros((n, n))
    sum_pair_counts = np.zeros((n, n))
    
    for d_idx, pairs in enumerate(diff_pairs):
        weight = 1.0 / len(pairs) if len(pairs) > 0 else 0
        for i, j in pairs:
            diff_pair_counts[i, j] += weight
    
    for s_idx, pairs in enumerate(sum_pairs):
        weight = 1.0 / len(pairs) if len(pairs) > 0 else 0
        for i, j in pairs:
            sum_pair_counts[i, j] += weight
    
    # Objective: maximize sum_{i,j} x_i x_j diff_pair_counts - lambda * sum_{i,j} x_i x_j sum_pair_counts
    # Subject to x_i in [0,1]
    # This is a quadratic program (non-convex because we maximize, not minimize).
    
    # Use a heuristic: solve iteratively with linearized objective (like Frank-Wolfe)
    # Then round.
    
    # Initial guess: random
    x = np.random.rand(n) * 0.5 + 0.25
    
    lambda_val = 2.0  # Adjustable parameter
    
    # Simple gradient ascent with projection
    def objective(x):
        x = np.clip(x, 0, 1)
        # Compute pairwise products using outer product
        x2 = np.outer(x, x)
        diff_term = np.sum(x2 * diff_pair_counts)
        sum_term = np.sum(x2 * sum_pair_counts)
        return -(diff_term - lambda_val * sum_term)  # negative for minimization
    
    def gradient(x):
        x = np.clip(x, 0, 1)
        # Gradient of diff_term w.r.t. x_i: sum_j x_j * (diff_pair_counts[i,j] + diff_pair_counts[j,i])
        # diff_pair_counts is symmetric? Not necessarily (i,j) and (j,i) can be different in weight?
        # But for diff, weight depends on the pair, not order; however we added for (i,j) only,
        # we need symmetric matrix.
        grad = np.zeros(n)
        for i in range(n):
            for j in range(n):
                if i != j:
                    grad[i] += x[j] * (diff_pair_counts[i, j] + diff_pair_counts[j, i])
                    grad[i] -= lambda_val * x[j] * (sum_pair_counts[i, j] + sum_pair_counts[j, i])
        return -grad  # negative because we minimize
    
    # Run optimization
    for iteration in range(500):
        g = gradient(x)
        # Line search
        best_obj = float('inf')
        best_alpha = 0
        for alpha in [0.001, 0.005, 0.01, 0.02, 0.05, 0.1]:
            new_x = np.clip(x - alpha * g, 0, 1)
            obj_val = objective(new_x)
            if obj_val < best_obj:
                best_obj = obj_val
                best_alpha = alpha
        x = np.clip(x - best_alpha * g, 0, 1)
        if np.max(np.abs(g * (x * (1-x)))) < 1e-6:
            break
    
    # Rounding: select elements with high x values, but ensure sumset is controlled
    threshold = np.quantile(x, 0.7)
    selected_indices = np.where(x > threshold)[0]
    A = [pool[i] for i in selected_indices]
    
    if len(A) > 4000:
        A = sorted(np.random.choice(A, 4000, replace=False))
        
    best_score = score_set(A)
    best_A = A[:]
    
    # Local search refinement
    time_for_local = deadline - time.time()
    if time_for_local > 30:
        # Try local search
        cur_A = best_A[:]
        start_local = time.time()
        while time.time() < deadline:
            cand = cur_A[:]
            i = random.randrange(len(cand))
            cand[i] += random.randint(-10, 10)
            # ensure within bounds
            if abs(cand[i]) > 1e14:
                cand[i] = cur_A[i]
            if random.random() < 0.1:
                cand.append(random.choice(pool))
            if random.random() < 0.05 and len(cand) > 5:
                cand = cand[:random.randrange(len(cand)-1)]
            s = score_set(cand)
            if s > best_score:
                best_score = s
                best_A = cand[:]
                cur_A = cand[:]
            elif random.random() < 0.2:
                cur_A = best_A[:]
    
    return sorted(set(best_A))

if __name__ == "__main__":
    # quick test
    A = solve()
    print(f"Set size: {len(A)}")
    print(f"Score: {score_set(A)}")
