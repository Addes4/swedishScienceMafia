import math
import random
import time
import numpy as np
from scipy.optimize import minimize, differential_evolution
from itertools import combinations

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    """Optimize set A via lattice embedding approach.
    
    Idea: Represent elements of A as small integers a_i. 
    Embed into a higher-dimensional space to separate sums and differences.
    We parametrize basis vectors v_i that map a_i to points in R^d.
    Optimize basis to maximize spread of differences while minimizing collisions of sums.
    Then decode a good integer set A from the optimized continuous parameters.
    """
    start_time = time.time()
    deadline = start_time + 110  # leave margin
    
    # Phase 1: Start with a good known set structure (e.g., geometric progression-like)
    # to initialize search. We'll refine using direct search first.
    
    # We'll use a two-stage approach:
    # 1. Fast random local search to get a decent set
    # 2. Use that set size to determine lattice embedding dimension and refine
    
    # Quick baseline: generate candidates from known constructions
    # (MSTD sets: More Sums Than Differences, but we want opposite: many diffs, few sums)
    # Use almost arithmetic progression with some perturbations
    
    best_set = None
    best_score = 0.0
    
    # Try to find good initial set via heuristic search
    # Use simulated annealing on small integers
    def random_set(n, max_val=50):
        return [random.randint(-max_val, max_val) for _ in range(n)]
    
    # Fast greedy construction: start with set that has many differences
    # Use a set with structure: many differences but sums concentrated
    # Example: take numbers with bounded sum but diverse differences
    # Try: set of form {a_i = i * d + r_i} with small r_i variations
    
    for n in [30, 40, 50, 60, 70, 80, 90, 100, 120]:
        if time.time() > deadline - 20:
            break
        # base set: modified Sidon-like or difference-rich
        base = list(range(0, 3*n, 3))[:n]
        # perturb
        for attempt in range(20):
            if time.time() > deadline - 20:
                break
            cur = base[:]
            # add random perturbations to increase differences
            for i in range(len(cur)):
                cur[i] += random.randint(-5, 5)
            # occasionally drop some elements and add new ones
            if random.random() < 0.3:
                cur = cur[:-2] + [random.randint(-10, 10) for _ in range(2)]
            score = _score(cur)
            if score > best_score:
                best_score = score
                best_set = cur[:]
    
    # Now we have some baseline
    if best_set is None:
        best_set = [7, 15, 18, 22, -3, -2]
        best_score = _score(best_set)
    
    # Phase 2: Continuous optimization of basis vectors for the lattice embedding
    # The idea: we have a candidate set size m = len(best_set)
    # We want to find m vectors v_i in R^d such that:
    # - Projection onto "difference" subspace maximizes pairwise distances
    # - Projection onto "sum" subspace minimizes collisions
    
    m = len(best_set)
    # Choose embedding dimension: larger d allows more separation
    d = min(m, 30)  # limit dimension for speed
    
    # Represent basis as matrix V of size m x d
    # Objective: maximize (log number of distinct differences) / (log number of distinct sums)
    # For a continuous relaxation: approximate using distances
    
    def lattice_score(V_flat):
        """Evaluate score for a given basis matrix (flattened)."""
        V = V_flat.reshape(m, d)
        # Generate all pairwise sum and difference vectors in embedding
        pts = V  # each row is a_i * v_i? Actually we embed points as combinations.
        # Wait, the lattice is {∑ a_i v_i : a_i ∈ A}. But A is our set of integers.
        # Here we are treating the elements of A as coefficients a_i for basis vectors v_i.
        # That means each lattice point corresponds to an element a ∈ A scaled by its vector.
        # Actually, simpler: we map each a ∈ A to a point v_a in R^d.
        # Then sumset corresponds to {v_a + v_b : a,b ∈ A}
        # diffset corresponds to {v_a - v_b : ...}
        # But we want the number of distinct sums/differences in the integer set to reflect in the lattice.
        # To optimize, we want the lattice sums to have many collisions (so small distinct count)
        # and differences to have few collisions (large distinct count).
        
        # Since we can't directly count distinct integers, we approximate:
        # The number of distinct sums is related to clustering of sum vectors.
        # We want sum vectors to coincide as much as possible.
        # The number of distinct differences relates to spread of diff vectors.
        
        # We'll compute all sum and diff vectors.
        sum_vecs = []
        diff_vecs = []
        for i in range(m):
            for j in range(i, m):
                s = pts[i] + pts[j]
                d = pts[i] - pts[j]
                sum_vecs.append(s)
                if i != j:
                    diff_vecs.append(d)
                    diff_vecs.append(-d)
        
        # Convert to arrays
        sum_arr = np.array(sum_vecs)
        diff_arr = np.array(diff_vecs)
        
        # Approximate number of distinct sums/diffs by clustering with a threshold
        # We want to minimize number of clusters for sums, maximize for diffs.
        # Use a differentiable proxy: sum of Gaussian similarities.
        # For sums: encourage clustering (many near each other) -> large similarities
        # For diffs: encourage spreading (few near each other) -> small similarities
        
        # Scale parameter
        if len(sum_arr) > 0:
            sum_std = np.std(sum_arr)
            diff_std = np.std(diff_arr)
            sigma_s = max(sum_std, 1e-8) * 0.5
            sigma_d = max(diff_std, 1e-8) * 0.5
        else:
            return -1e9
        
        # Compute pairwise distances for sums (sample to reduce O(N^2))
        # Use random subset if too many
        n_sums = len(sum_arr)
        n_diffs = len(diff_arr)
        
        # For sums: we want them to be as similar as possible -> maximize pairwise similarity
        # Sample pairs
        if n_sums > 1000:
            idx_s = np.random.choice(n_sums, 1000, replace=False)
            sum_sub = sum_arr[idx_s]
        else:
            sum_sub = sum_arr
        if n_diffs > 1000:
            idx_d = np.random.choice(n_diffs, 1000, replace=False)
            diff_sub = diff_arr[idx_d]
        else:
            diff_sub = diff_arr
        
        # Compute mean pairwise similarity for sums
        # Similarity = exp(-||u-v||^2 / (2*sigma^2))
        # We want this to be large (sums cluster)
        sum_sim = 0.0
        n_ss = len(sum_sub)
        if n_ss > 1:
            # compute only a sample of pairs
            npairs = min(5000, n_ss*(n_ss-1)//2)
            i1 = np.random.randint(0, n_ss, npairs)
            i2 = np.random.randint(0, n_ss, npairs)
            # ensure i1 != i2
            diff_vec = sum_sub[i1] - sum_sub[i2]
            dist_sq = np.sum(diff_vec**2, axis=1)
            sum_sim = np.mean(np.exp(-dist_sq / (2 * sigma_s**2)))
        
        # For diffs: we want them to be as different as possible -> minimize similarity
        diff_sim = 0.0
        n_dd = len(diff_sub)
        if n_dd > 1:
            npairs = min(5000, n_dd*(n_dd-1)//2)
            i1 = np.random.randint(0, n_dd, npairs)
            i2 = np.random.randint(0, n_dd, npairs)
            diff_vec = diff_sub[i1] - diff_sub[i2]
            dist_sq = np.sum(diff_vec**2, axis=1)
            diff_sim = np.mean(np.exp(-dist_sq / (2 * sigma_d**2)))
        
        # Objective: maximize sum_sim - diff_sim (or ratio)
        # But we also need to avoid trivial solution where all vectors collapse to 0.
        # Add regularization: variance of points should be non-negligible
        pts_var = np.var(pts)
        
        # Combine: we want large sum_sim, small diff_sim, and non-zero variance
        score = sum_sim - diff_sim + 0.01 * pts_var
        return score
    
    # Starting point for optimization: use random initial basis
    # But we can also use our best_set to initialize the basis meaningfully
    # We'll set each basis vector along a separate dimension initially
    V_init = np.zeros((m, d))
    for i in range(min(m, d)):
        V_init[i, i] = 1.0
    # Add some random
    V_init += np.random.normal(0, 0.1, (m, d))
    
    # Optimize continuously
    # Use gradient-based optimizer
    try:
        res = minimize(lambda x: -lattice_score(x), V_init.flatten(),
                      method='L-BFGS-B', options={'maxiter': 200, 'disp': False})
        V_opt = res.x.reshape(m, d)
    except:
        V_opt = V_init
    
    # Now decode: from the optimized basis, we need to extract integer set A
    # that would produce the lattice structure.
    # The continuous optimization gave us positions in R^d corresponding to each a in A.
    # But we need actual integers. We can try to find integer coordinates that preserve 
    # the pairwise distance structure approximately.
    
    # Idea: use the pairwise distance matrix between the V_opt points,
    # and find 1D embedding that preserves rank of distances approximately.
    # Then scale and round to integers.
    
    # Compute distance matrix of points in embedding
    pts_opt = V_opt
    # We'll project onto 1D via PCA or just take first principal component
    # Center the points
    mean_pt = np.mean(pts_opt, axis=0)
    centered = pts_opt - mean_pt
    # SVD to find dominant direction
    U, s, Vt = np.linalg.svd(centered, full_matrices=False)
    # Project onto first singular vector
    proj1 = np.dot(centered, Vt[0])  # m-dimensional
    
    # Now we have 1D coordinates that preserve spread of differences and clusters of sums
    # as learned from the continuous optimization.
    # Scale and round to integers while keeping them distinct.
    # We want integer set A from these coordinates.
    # Multiply by a large factor and round, then adjust to make all distinct.
    scale_factor = 1000 / (np.max(np.abs(proj1)) + 1e-8)
    A_continuous = proj1 * scale_factor
    A_int = np.round(A_continuous).astype(int)
    
    # Ensure all distinct
    # If there are duplicates, perturb slightly
    uniq = set()
    A_final = []
    for val in A_int:
        while val in uniq:
            val += random.randint(-5, 5)
        uniq.add(val)
        A_final.append(int(val))
    
    score_new = _score(A_final)
    
    if score_new > best_score:
        best_score = score_new
        best_set = A_final[:]
    
    # Phase 3: Refine the set with direct search on the integer set
    # Use the lattice-optimized set as a starting point for random local search
    cur = best_set[:]
    cur_score = best_score
    
    # Adaptive search: modify elements, add/remove, toward the deadline
    while time.time() < deadline - 5:
        cand = cur[:]
        if len(cand) > 0:
            i = random.randrange(len(cand))
            # Change by small amount, allowing bigger jumps occasionally
            delta = random.randint(-20, 20)
            cand[i] += delta
            # Keep within bounds
            if abs(cand[i]) > 1e9:
                cand[i] = cand[i] % 1000000  # wrap
        
        # Occasionally add a new element that helps
        if random.random() < 0.1 and len(cand) < 4000:
            new_val = random.randint(-10000, 10000)
            cand.append(new_val)
        
        # Occasionally remove an element
        if random.random() < 0.05 and len(cand) > 5:
            idx = random.randrange(len(cand))
            cand.pop(idx)
        
        # Compute score
        cand_set = set(cand)
        if len(cand_set) >= 2:
            # Quick score computation (optimized)
            diffs = set()
            sums = set()
            cand_list = list(cand_set)
            n = len(cand_list)
            for i in range(n):
                xi = cand_list[i]
                for j in range(i, n):
                    xj = cand_list[j]
                    diffs.add(xi - xj)
                    diffs.add(xj - xi)
                    sums.add(xi + xj)
                    if i != j:
                        sums.add(xi + xj)  # already added
            # Actually loops above double count, but it's okay for score ratio
            # Let's recalc cleanly
        cand_set_list = list(set(cand))
        if len(cand_set_list) >= 2:
            diffs = set()
            sums = set()
            for xi in cand_set_list:
                for xj in cand_set_list:
                    diffs.add(xi - xj)
                    sums.add(xi + xj)
            s = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/len(cand_set_list))/100
        else:
            s = 0.0
        
        if s >= cur_score:
            cur = cand_set_list[:]
            cur_score = s
            if s > best_score:
                best_score = s
                best_set = cand_set_list[:]
        elif random.random() < 0.05:
            # reset to best occasionally
            cur = best_set[:]
            cur_score = best_score
    
    # Ensure distinct and within limits
    final = sorted(set(best_set))
    if len(final) > 4000:
        final = final[:4000]
    # Limit magnitude to 1e15
    final = [x for x in final if abs(x) <= 1e15]
    
    return final
