import math
import random
import time

import numpy as np


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _counts_from_gaps(gaps):
    """Given positive real gaps, estimate |A-A| and |A+A| for A = cumulative sums."""
    # positions of points along a line starting at 0
    n = len(gaps) + 1
    pos = np.concatenate(([0.0], np.cumsum(gaps)))
    # all pairwise sums of positions (difference multiset magnitude)
    # |A-A| ~ number of distinct values of |x-y|; use rounded values on fine grid
    diff_vals = set()
    for i in range(n):
        for j in range(n):
            diff_vals.add(round(pos[i] - pos[j], 6))
    return len(diff_vals), n

def _distinct_sums(pos):
    s = set()
    n = len(pos)
    for i in range(n):
        for j in range(n):
            s.add(round(pos[i] + pos[j], 6))
    return len(s)


def _continuous_score(gaps):
    n = len(gaps) + 1
    if n < 2:
        return -1e9
    pos = np.concatenate(([0.0], np.cumsum(gaps)))
    nd = _distinct_sums(-pos)  # |A-A| distinct count (shift)
    ns = _distinct_sums(pos)
    if ns < 2:
        return -1e9
    return math.log(nd) / math.log(ns)


def solve():
    random.seed(12345)
    np.random.seed(12345)
    deadline = time.time() + 110.0

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Try several starting configurations and sizes
    for n in [4, 5, 6, 7, 8, 10, 12, 16, 20]:
        if time.time() > deadline:
            break
        # random integer start
        base = sorted(random.sample(range(-40, 41), n))
        cur = base
        cur_score = _score(cur)

        # local integer search: hill climbing on the log-ratio
        stall = 0
        while time.time() < deadline and stall < 400:
            cand = cur[:]
            i = random.randrange(n)
            delta = random.choice([-5, -3, -2, -1, 1, 2, 3, 5])
            cand[i] += delta
            if len(set(cand)) < n:
                stall += 1
                continue
            s = _score(cand)
            if s > cur_score:
                cur, cur_score = cand, s
                stall = 0
            else:
                stall += 1
            if cur_score > best_score:
                best, best_score = sorted(set(cur)), cur_score

        # gap-based continuous refinement
        if time.time() < deadline:
            srt = sorted(set(cur))
            d = np.array([srt[i + 1] - srt[i] for i in range(len(srt) - 1)], dtype=float)
            if len(d) >= 1:
                for _ in range(200):
                    if time.time() > deadline:
                        break
                    cand_g = d.copy()
                    i = random.randrange(len(d))
                    cand_g[i] += np.random.normal(0, 2.0)
                    if cand_g[i] < 1:
                        cand_g[i] = 1.0
                    cs = _continuous_score(cand_g)
                    if cs >= _continuous_score(d):
                        d = cand_g
                # reconstruct integer set
                pos = np.concatenate(([0.0], np.cumsum(d)))
                ints = sorted(set(int(round(p)) for p in pos))
                if len(ints) >= 2:
                    # recenter
                    ints = [x - ints[0] for x in ints]
                    sc = _score(ints)
                    if sc > best_score:
                        best, best_score = ints, sc

        # Additional random restart tweaks
        for _ in range(50):
            if time.time() > deadline:
                break
            cand = cur[:]
            k = random.randrange(1, 4)
            for _ in range(k):
                i = random.randrange(n)
                cand[i] += random.randint(-10, 10)
            cand = sorted(set(cand))
            if len(cand) >= 2:
                s = _score(cand)
                if s > best_score:
                    best, best_score = cand, s

    return sorted(set(best))


if __name__ == "__main__":
    print(solve())
