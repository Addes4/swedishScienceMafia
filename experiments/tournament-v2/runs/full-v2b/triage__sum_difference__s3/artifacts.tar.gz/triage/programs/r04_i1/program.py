# EVOLVE-BLOCK-START
"""Divide-and-conquer sums/differences search.

Partition the integer range into blocks; within each block run a small
simulated-annealing / local search optimising a local difference/sum ratio.
Then combine block representatives into a final set that inherits good global
properties.  A global polish pass then improves the combined set.
"""
import math
import random
import time

random.seed(12345)


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return -1e18
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    ld = math.log(len(diffs))
    ls = math.log(len(sums))
    if ls <= 0:
        return -1e18
    return ld / ls + (1 - 1 / len(a)) / 100


def _local_search(block, base, seed_set, iters, deadline):
    """Optimise a small candidate set drawn from `block`, starting from seed_set."""
    cur = list(set(seed_set))
    if not cur:
        cur = [random.choice(block)]
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    temp = 0.05
    while iters[0] > 0 and time.time() < deadline:
        iters[0] -= 1
        cand = cur[:]
        op = random.random()
        if op < 0.55 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, max(2, base))
        elif op < 0.8:
            cand.append(random.choice(block))
        elif op < 0.9 and len(cand) > 2:
            del cand[random.randrange(len(cand))]
        else:
            if cand:
                i = random.randrange(len(cand))
                cand[i] = random.choice(block)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score or random.random() < math.exp((s - cur_score) / max(temp, 1e-9)):
            cur, cur_score = cand, s
        if s > best_score:
            best, best_score = cand[:], s
        temp *= 0.9995
        if temp < 1e-4:
            temp = 0.05
    return best, best_score


def solve():
    """Return a list of distinct integers A with large |A-A| and small |A+A|."""
    deadline = time.time() + 115.0

    # Divide the integer range into blocks of varying scale.
    # A few overlapping blocks around 0 (small magnitude integers give many
    # collisions in the sum set but distinct differences), plus larger blocks.
    block_specs = [
        (-12, 12),
        (-25, 25),
        (-50, 50),
        (-120, 120),
        (-300, 300),
        (-800, 800),
        (-2500, 2500),
        (-8000, 8000),
        (-30000, 30000),
        (-120000, 120000),
        (-500000, 500000),
    ]

    # Phase 1: independently optimise a representative subset in each block.
    representatives = []
    for (lo, hi) in block_specs:
        if time.time() > deadline * 0.5:
            break
        block = list(range(lo, hi + 1))
        # Seed with a spread inside the block.
        k = max(3, min(12, hi - lo + 1))
        seed = random.sample(block, min(k, len(block)))
        iters = [2000]
        best, bs = _local_search(block, max(2, (hi - lo) // 4), seed, iters, deadline * 0.5)
        representatives.extend(best)

    # Phase 2: combine all representatives into a global candidate set.
    combined = list(set(representatives))
    if len(combined) < 2:
        combined = [7, 15, 18, 22, -3, -2]

    # Phase 3: global polish using joint local search.
    total_range = 600000
    merged_block = list(range(-total_range, total_range + 1))
    iters = [40000]
    best, best_score = _local_search(
        merged_block, 50000, combined, iters, deadline * 0.97
    )

    # Phase 4: try perturbing the best with larger multiplicative shifts
    # drawn from the various block scales, keeping improvements.
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        for _ in range(random.randint(1, 3)):
            op = random.random()
            if op < 0.5 and cand:
                i = random.randrange(len(cand))
                scale = random.choice([1, 3, 10, 50, 200, 1000, 5000, 20000])
                cand[i] += random.choice([-1, 1]) * random.randint(1, max(1, scale))
            elif op < 0.75:
                cand.append(random.choice(block_specs)[0] + random.randint(0, 2000))
            elif cand and len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
        if s > best_score:
            best, best_score = cand[:], s

    best = sorted(set(best))
    if len(best) > 4000:
        best = best[:4000]
    if not best or max(abs(x) for x in best) > 10**15:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
