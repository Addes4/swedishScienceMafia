import math
import random
import time
import itertools
import sys

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    """
    Construct A as a generalized arithmetic progression:
    A = { sum_{j=1}^d k_j * g_j : 0 <= k_j < L_j }
    with small dimension d, optimized step lengths g_j and bounding box L_j.
    Global search over parameters followed by local mutations.
    """
    random.seed(42)  # reproducibility
    deadline = time.time() + 115

    # Dimension candidates: 2 or 3
    dims = [2, 3]
    best_A = [0, 1]
    best_score = _score(best_A)
    
    # Global parameter search
    # For each dimension, generate candidate step vectors and box sizes
    # We try to keep total size reasonable ( < 4000 )
    max_total_size = 4000
    
    # Heuristic bounds for step sizes: small to moderate integers
    step_ranges = {
        2: [ (1, 30), (30, 200) ],
        3: [ (1, 20), (20, 80), (80, 250) ]
    }
    
    # Pre-generate a diverse set of box size tuples that multiply to <= max_total_size
    # For each dimension, we'll sample a few.
    
    def generate_L_tuples(d, max_prod, num_samples=50):
        # Generate tuples of length d with product <= max_prod, with some distribution
        tuples = []
        ranges = [range(1, min(50, max_prod)+1) for _ in range(d)]
        # brute force for small d
        if d == 2:
            for a in range(1, min(60, int(max_prod**0.5)+5)):
                for b in range(a, max_prod//a + 1):
                    if a*b <= max_prod and a*b >= 10:
                        tuples.append((a, b))
            random.shuffle(tuples)
            return tuples[:num_samples*2]
        elif d == 3:
            # random sampling
            for _ in range(num_samples*10):
                a = random.randint(1, 30)
                b = random.randint(1, 30)
                c = random.randint(1, min(30, max_prod//(a*b)))
                if a*b*c <= max_prod and a*b*c >= 10:
                    tuples.append((a, b, c))
            # add some symmetric ones
            for a in range(1, 15):
                for b in range(a, 15):
                    c = max_prod // (a*b)
                    if c >= 1:
                        tuples.append((a,b,c))
            random.shuffle(tuples)
            return tuples[:num_samples*2]
        return tuples
    
    # Global search loop
    for d in dims:
        step_ranges_d = step_ranges[d]
        # sample step vectors: each component from its range
        # we'll try a grid of step vectors
        step_samples = []
        if d == 2:
            for g1 in range(step_ranges_d[0][0], step_ranges_d[0][1]+1, 5):
                for g2 in range(step_ranges_d[1][0], step_ranges_d[1][1]+1, 10):
                    step_samples.append((g1, g2))
            # add some random
            for _ in range(100):
                g1 = random.randint(*step_ranges_d[0])
                g2 = random.randint(*step_ranges_d[1])
                step_samples.append((g1, g2))
        elif d == 3:
            for g1 in range(step_ranges_d[0][0], step_ranges_d[0][1]+1, 3):
                for g2 in range(step_ranges_d[1][0], step_ranges_d[1][1]+1, 7):
                    for g3 in range(step_ranges_d[2][0], step_ranges_d[2][1]+1, 20):
                        step_samples.append((g1, g2, g3))
            for _ in range(200):
                g1 = random.randint(*step_ranges_d[0])
                g2 = random.randint(*step_ranges_d[1])
                g3 = random.randint(*step_ranges_d[2])
                step_samples.append((g1, g2, g3))
        
        random.shuffle(step_samples)
        step_samples = step_samples[:200]
        
        L_tuples = generate_L_tuples(d, max_total_size, num_samples=100)
        
        for steps in step_samples:
            # Ensure steps are distinct and increasing? Not required but helps uniqueness
            # We'll keep as is.
            # Compute basis for progression
            for L in L_tuples:
                if time.time() > deadline:
                    break
                # Build set A
                if d == 2:
                    A = [k1*steps[0] + k2*steps[1] for k1 in range(L[0]) for k2 in range(L[1])]
                else:  # d==3
                    A = [k1*steps[0] + k2*steps[1] + k3*steps[2] 
                         for k1 in range(L[0]) for k2 in range(L[1]) for k3 in range(L[2])]
                if len(A) > 4000 or len(A) < 10:
                    continue
                # make distinct
                A = list(set(A))
                if len(A) < 10:
                    continue
                sc = _score(A)
                if sc > best_score:
                    best_score = sc
                    best_A = A[:]
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # Local mutation phase: fine-tune the best found progression parameters
    # Extract parameters from best_A? We'll assume it's a progression and try to optimize L_j and steps.
    # But best_A might be from any search; we can instead start from best_A and apply mutations directly to the set.
    # We'll do a hill climbing on the set itself, and also try to tweak L_j if we can infer them.
    cur = best_A[:]
    cur_score = best_score
    # Hill climbing on the set: add/remove small perturbations, shift elements
    # Similar to baseline but with wider search range and longer time.
    while time.time() < deadline:
        cand = cur[:]
        # Mutation types:
        r = random.random()
        if r < 0.3 and len(cand) < 3800:
            # add an element that might be near existing ones
            base = random.choice(cand)
            cand.append(base + random.randint(-5, 5))
        elif r < 0.6 and len(cand) > 10:
            # remove random
            idx = random.randrange(len(cand))
            del cand[idx]
        elif r < 0.9:
            # modify an element
            idx = random.randrange(len(cand))
            cand[idx] += random.randint(-10, 10)
        else:
            # shift subset
            shift = random.randint(-20, 20)
            for i in range(len(cand)):
                if random.random() < 0.3:
                    cand[i] += shift
        
        # ensure distinct
        cand = list(set(cand))
        if len(cand) < 5:
            continue
        sc = _score(cand)
        if sc >= cur_score:
            cur = cand[:]
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best_A = cand[:]
        elif random.random() < 0.05:
            cur = best_A[:]
            cur_score = best_score

    return sorted(set(best_A))

if __name__ == "__main__":
    # quick test
    A = solve()
    print(f"Score: {_score(A):.6f}, len={len(A)}")
