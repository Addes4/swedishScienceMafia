# EVOLVE-BLOCK-START
"""
DFT-guided search for sets with large difference set and small sum set.

Idea
----
Work in a cyclic group Z_m.  Represent A by its indicator vector f (0/1).
The additive energy E(A) = #{(a,b,c,d) in A^4 : a+b = c+d} equals sum_k |f_hat(k)|^4
(Parseval / convolution identity).  Large E means lots of additive structure, i.e.
small sum set and small difference set.  We want big difference set but small sum
set which is contradictory, so a better signal is the *direction* of structure.

We use the DFT of the convolution g = f * f  (the sumset multiplicity vector).
g[t] = #{ (a,b) in A^2 : a+b = t (mod m) }.
A small sum set means g is concentrated on few residues, but we must avoid the
strongly structured (arithmetic-progression-like) configurations because they
also collapse the difference set.  Random-ish sets with a good ratio tend to
look like: A spread over a modulus where the doubling map is far from being
a bijection onto a small image... In practice the best known construction for
this problem is a short arithmetic progression with a few "twisted"/Sidon-like
extra elements.

Strategy implemented here (practical, within time budget):
 1. Seed candidates: Sidon-ish sets, short APs with random offset perturbations,
    and the classical small example.
 2. Score candidates exactly with plain integer sets (no modulus wraparound,
    since wraparound would corrupt the real difference/sum counts).
 3. Use a DFT over a chosen modulus m ~ 2*max|A| to compute sumset multiplicity
    spectrum; the low-frequency (DC and near-DC) energy is the additive-energy
    proxy.  Use it as a *tie-breaker / secondary objective*: among candidates of
    nearly equal ratio, prefer the one with smaller peak sumset multiplicity,
    which empirically correlates with a genuinely smaller |A+A|.
 4. Local search: perturb, accept improvements; occasionally do a "frequency
    aware" move that pushes an element away from the most over-represented sum.
"""
import math
import random
import time


def _counts(a):
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return diffs, sums


def _ratio(a):
    n = len(a)
    if n < 2:
        return 0.0
    d, s = _counts(a)
    ls = len(s)
    if ls <= 1:
        return float('inf')
    return math.log(len(d)) / math.log(ls)


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    d, s = _counts(a)
    ls = len(s)
    if ls <= 1:
        return 0.0
    return math.log(len(d)) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def _dft_energy_proxy(a, m):
    """Return (peak, low_freq_energy) of the sumset multiplicity spectrum.

    We build convolution g of indicator with itself mod m via naive O(n^2) accumulation,
    then take the real DFT (only need |F|^4 sums, but we use a cheap proxy:
    we compute the DFT of g and return the total spectral energy and the DC value.
    Using the identity sum_k |g_hat(k)|^2 = m * sum_t g[t]^2 and
    sum_k |f_hat(k)|^4 = (1/m) * sum_k |g_hat(k)|^2 * ... we simply compute
    directly the additive energy from counts of sums mod m.
    """
    n = len(a)
    g = [0] * m
    for i in range(n):
        ai = a[i] % m
        for j in range(n):
            g[(ai + a[j]) % m] += 1
    # additive energy E = sum_t g[t]^2  (this equals number of quadruples a+b=c+d mod m)
    E = 0
    peak = 0
    for v in g:
        E += v * v
        if v > peak:
            peak = v
    return peak, E


def _cool_choices(a, m, peak_bad):
    """Return residues t (mod m) that are the most over-represented sums."""
    g = {}
    for x in a:
        for y in a:
            t = (x + y) % m
            g[t] = g.get(t, 0) + 1
    items = sorted(g.items(), key=lambda kv: -kv[1])
    return [t for t, c in items[:max(1, len(items) // 8)] if c >= peak_bad]


def solve():
    deadline = time.time() + 115.0
    random.seed(12345)

    # ---- seed pool ---------------------------------------------------------
    def sidon_like(n, spread):
        """Greedy-ish Sidon set: pairwise sums mostly distinct."""
        s = [0]
        tries = 0
        while len(s) < n and tries < 200 * n:
            tries += 1
            c = random.randint(0, spread)
            ok = True
            seen = set()
            for x in s + [c]:
                for y in s + [c]:
                    v = x + y
                    if v in seen:
                        ok = False
                        break
                    seen.add(v)
                if not ok:
                    break
            if ok:
                s.append(c)
        return s

    seeds = []
    # known good small example
    seeds.append([7, 15, 18, 22, -3, -2])
    # short APs with perturbations
    for _ in range(30):
        k = random.randint(5, 12)
        d = random.randint(1, 4)
        base = [i * d + random.randint(-2, 2) for i in range(k)]
        seeds.append(base)
    # Sidon-ish sets (large difference set, moderate sums)
    for _ in range(30):
        seeds.append(sidon_like(random.randint(6, 16), random.randint(30, 200)))
    # tiny random
    for _ in range(20):
        seeds.append([random.randint(-15, 15) for _ in range(random.randint(5, 9))])

    best = None
    best_score = -1.0
    best_proxy = None
    for s in seeds:
        s = sorted(set(s))
        if len(s) < 2:
            continue
        sc = _score(s)
        if sc > best_score:
            best, best_score = s, sc

    # ---- local search ------------------------------------------------------
    cur = best[:]
    cur_score = best_score
    m = 4 * max(1, max(abs(x) for x in cur) if cur else 1)

    steps = 0
    while time.time() < deadline:
        steps += 1
        cand = cur[:]
        move = random.random()
        if move < 0.55:
            # perturb an element
            i = random.randrange(len(cand))
            span = max(1, int(3 * (1 + abs(cand[i])) ** 0.5))
            cand[i] += random.randint(-span, span)
        elif move < 0.8:
            # add a new element near an existing one, away from dense sums
            if len(cand) < 4000:
                j = random.randrange(len(cand))
                delta = random.choice([-1, 1]) * random.randint(1, 6)
                cand.append(cand[j] + delta)
        else:
            # remove an element (keeps ratio often high, loses bonus)
            if len(cand) > 4:
                cand.pop(random.randrange(len(cand)))

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue

        sc = _score(cand)
        if sc >= cur_score:
            # frequency-aware secondary check: keep it if not worse on additive energy
            m2 = 4 * max(1, max(abs(x) for x in cand))
            if m2 > 400000:
                m2 = 400000
            if len(cand) <= 64:
                peak, E = _dft_energy_proxy(cand, m2)
            else:
                peak, E = 0, 0
            if sc > cur_score or best_proxy is None or peak <= best_proxy[0]:
                cur, cur_score = cand, sc
                if sc > best_score:
                    best, best_score = cand[:], sc
                    best_proxy = (peak, E)
        elif random.random() < 0.03:
            cur, cur_score = best[:], best_score

        # periodic restart from a fresh perturbation of best
        if steps % 20000 == 0:
            cur = best[:]
            if cur:
                i = random.randrange(len(cur))
                cur[i] += random.randint(-20, 20)
                cur = sorted(set(cur))
                cur_score = _score(cur)

    return best
# EVOLVE-BLOCK-END
