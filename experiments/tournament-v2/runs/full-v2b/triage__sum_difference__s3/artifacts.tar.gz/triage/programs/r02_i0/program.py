import math
import random
import time
import itertools
from itertools import combinations

def evaluate_set(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    # Compute size of sumset and diffset
    # For large sets, use a faster algorithm: sort and use two-sum/two-diff ideas? 
    # But here we aim for moderate sizes, so straightforward sets work if not too large.
    # We'll limit candidate size to <= 500 during optimization to keep fast.
    diffs = set()
    sums = set()
    # For small sets, direct double loop is fine. If len(a) gets large, we can sample?
    # We'll just compute.
    arr = sorted(a)
    # Use set comprehensions
    n = len(arr)
    for i in range(n):
        x = arr[i]
        for j in range(i, n):
            y = arr[j]
            sums.add(x + y)
            if i != j:
                diffs.add(abs(x - y))  # careful: we need all differences, not just absolute
    # But we need full diff set: a - b for all ordered pairs (including sign)
    # So better to compute properly:
    diffs = {x - y for x in arr for y in arr}
    sums = {x + y for x in arr for y in arr}
    if len(sums) == 0:
        return 0.0
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(arr)) / 100
    return score

def construct_geometric_set(params):
    """params: list of (center, q, length, shift) for each cluster.
       Each cluster: a_i = center * (q ** k) for k=0..length-1, then overall shift added to all elements.
       We'll have several clusters separated by large gaps to keep sums clustered.
       The idea: within a cluster, sums concentrate because geometric progression sums also form geometric-like structure with few distinct values.
       Differences spread more because differences between different clusters will be large distinct values.
       We'll optimize parameters to maximize score.
    """
    clusters = []
    for center, q, length, shift in params:
        # center and q integers? to keep integer set
        # We'll use integer center and integer exponentiation? q must be integer >1.
        # We'll use integer arithmetic.
        arr = []
        val = center
        for _ in range(length):
            arr.append(val)
            val *= q
        clusters.append([x + shift for x in arr])
    # Merge all clusters, ensure distinct integers
    A = list(set(itertools.chain.from_iterable(clusters)))
    if len(A) < 2:
        return None
    return A

def random_params():
    # generate random parameters for clusters
    num_clusters = random.randint(2, 4)
    params = []
    for _ in range(num_clusters):
        center = random.randint(1, 5)
        q = random.randint(2, 4)
        length = random.randint(3, 6)
        shift = random.randint(-100, 100)
        params.append((center, q, length, shift))
    return params

def mutate_params(params):
    params = params[:]
    if random.random() < 0.3 and len(params) > 1:
        # remove cluster
        idx = random.randrange(len(params))
        del params[idx]
    if random.random() < 0.3:
        # add cluster
        params.append((random.randint(1,5), random.randint(2,4), random.randint(3,6), random.randint(-100,100)))
    # mutate one cluster
    idx = random.randrange(len(params))
    c, q, l, s = params[idx]
    if random.random() < 0.5:
        c += random.randint(-2,2)
        if c <= 0: c = 1
    if random.random() < 0.5:
        q += random.randint(-1,1)
        if q < 2: q = 2
    if random.random() < 0.5:
        l += random.randint(-2,2)
        if l < 2: l = 2
        if l > 10: l = 10
    if random.random() < 0.5:
        s += random.randint(-50,50)
    params[idx] = (c, q, l, s)
    return params

def param_score(params):
    A = construct_geometric_set(params)
    if A is None or len(A) < 2:
        return -1
    if len(A) > 4000:  # too large for efficient scoring? We'll skip
        return -1
    # evaluate
    return evaluate_set(A)

def solve() -> list:
    best_params = None
    best_score = -1
    deadline = time.time() + 115  # leave some margin
    # start with some hand-tuned seed
    seed_params = [(1,2,5,0), (100,2,5,0)]  # two clusters separated by 100
    # also try some others
    cur_params = seed_params
    cur_score = param_score(cur_params)
    if cur_score > best_score:
        best_score = cur_score
        best_params = cur_params[:]
    
    # simulated annealing / random hill climbing with restarts
    while time.time() < deadline:
        # maybe restart
        if random.random() < 0.1:
            cur_params = random_params()
            cur_score = param_score(cur_params)
        cand_params = mutate_params(cur_params)
        cand_score = param_score(cand_params)
        if cand_score > cur_score:
            cur_params = cand_params
            cur_score = cand_score
            if cur_score > best_score:
                best_score = cur_score
                best_params = cur_params[:]
        elif random.random() < 0.2:  # accept worse
            cur_params = cand_params
            cur_score = cand_score
    
    if best_params is not None:
        A = construct_geometric_set(best_params)
        A = sorted(set(A))
        # ensure within limits
        if len(A) > 4000:
            A = A[:4000]
        return A
    else:
        # fallback
        return [0,1,2,4,8,16]
