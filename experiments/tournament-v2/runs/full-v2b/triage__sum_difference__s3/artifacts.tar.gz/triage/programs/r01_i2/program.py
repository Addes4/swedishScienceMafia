import math
import random
import time
from itertools import combinations

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def greedy_sidon(n, start=1):
    """Generate a Sidon set (all sums a+b distinct) greedily."""
    a = [start]
    sums = {2 * start}
    for x in range(start + 1, start + 1000000):
        ok = True
        for y in a:
            if x + y in sums:
                ok = False
                break
        if ok:
            a.append(x)
            for y in a:
                sums.add(x + y)
            if len(a) >= n:
                break
    return a

def modular_sidon(p, n):
    """Generate a modular Sidon set using quadratic residues modulo a prime p."""
    # We want p large enough such that residues are distinct mod p
    a = []
    for x in range(1, p):
        y = (x * x) % p
        if y not in a:
            a.append(y)
            if len(a) >= n:
                break
    return a

def solve():
    best = None
    best_score = 0.0
    deadline = time.time() + 110  # leave some margin

    # Use a pre-seeded Sidon set (or B2 sequence) as starting point
    # Greedy Sidon produces good difference-sums ratio
    # We'll try a few sizes and pick best after local search
    sizes_to_try = [30, 50, 70, 90, 120, 150, 200]
    
    for size in sizes_to_try:
        if time.time() > deadline:
            break
            
        # Generate a base Sidon set (greedy)
        base_set = greedy_sidon(size, start=1)
        # Convert to list of ints
        cur = base_set[:]
        
        # Quick local search to improve
        cur_score = _score(cur)
        best_local = cur[:]
        best_local_score = cur_score
        
        start_time = time.time()
        # Spend proportionally more time on larger sets
        time_budget = min(deadline - time.time(), 15 + size * 0.5)
        
        while time.time() < start_time + time_budget and time.time() < deadline:
            cand = cur[:]
            op = random.random()
            if op < 0.6:
                # modify one element
                i = random.randrange(len(cand))
                delta = random.randint(-5, 5)
                if delta != 0:
                    cand[i] += delta
            elif op < 0.85 and len(cand) > 5:
                # remove one element
                i = random.randrange(len(cand))
                cand.pop(i)
            elif op < 0.95 and len(cand) < 4000:
                # add a new element near existing ones
                base = cand[random.randrange(len(cand))]
                new_val = base + random.randint(-10, 10)
                while new_val in cand:
                    new_val = base + random.randint(-10, 10)
                cand.append(new_val)
            else:
                # swap one element with random
                i = random.randrange(len(cand))
                cand[i] = random.randint(-50, 50)
                
            # Ensure distinct
            if len(set(cand)) != len(cand):
                continue
                
            s = _score(cand)
            if s > cur_score or random.random() < 0.01:
                cur = cand
                cur_score = s
                if s > best_local_score:
                    best_local = cand[:]
                    best_local_score = s
        
        if best_local_score > best_score:
            best = best_local[:]
            best_score = best_local_score

    # Also try modular construction with prime
    if time.time() < deadline:
        size = 80
        p = 1009  # prime > size
        base_set = modular_sidon(p, size)
        cur = base_set[:]
        cur_score = _score(cur)
        best_local = cur[:]
        best_local_score = cur_score
        
        start_time = time.time()
        time_budget = min(deadline - time.time(), 30)
        while time.time() < start_time + time_budget and time.time() < deadline:
            cand = cur[:]
            op = random.random()
            if op < 0.6:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-3, 3)
            elif op < 0.85 and len(cand) > 5:
                cand.pop(random.randrange(len(cand)))
            elif op < 0.95 and len(cand) < 4000:
                base = cand[random.randrange(len(cand))]
                new_val = base + random.randint(-5, 5)
                while new_val in cand:
                    new_val = base + random.randint(-5, 5)
                cand.append(new_val)
            if len(set(cand)) != len(cand):
                continue
            s = _score(cand)
            if s > cur_score or random.random() < 0.01:
                cur = cand
                cur_score = s
                if s > best_local_score:
                    best_local = cand[:]
                    best_local_score = s
        
        if best_local_score > best_score:
            best = best_local[:]
            best_score = best_local_score

    # If we still have time, try extended Sidon sets with small modifications
    if time.time() < deadline and best is not None:
        cur = best[:]
        cur_score = best_score
        while time.time() < deadline:
            cand = cur[:]
            op = random.random()
            if op < 0.5:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-2, 2)
            elif op < 0.8 and len(cand) < 4000:
                # Add new element preserving good sum-difference properties
                # try to pick value that doesn't create many new sums
                base = cand[random.randrange(len(cand))]
                cand.append(base + random.randint(-3, 3))
            elif len(cand) > 50:
                i = random.randrange(len(cand))
                cand.pop(i)
            if len(set(cand)) != len(cand):
                continue
            s = _score(cand)
            if s > cur_score:
                cur = cand
                cur_score = s
                if s > best_score:
                    best = cand[:]
                    best_score = s
            elif random.random() < 0.001:
                cur = best[:]
                cur_score = best_score

    return sorted(set(best)) if best is not None else [0, 1]
