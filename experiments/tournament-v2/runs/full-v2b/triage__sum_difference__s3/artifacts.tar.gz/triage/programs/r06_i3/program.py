import math
import time
import numpy as np

def _compute_stats(A):
    if len(A) < 2:
        return 0.0, 0.0
    A = np.array(A)
    sums = np.add.outer(A, A).reshape(-1)
    diffs = np.subtract.outer(A, A).reshape(-1)
    mean_sums = np.mean(sums)
    var_sums = np.var(sums)
    mean_diffs = np.mean(diffs)
    var_diffs = np.var(diffs)
    return sum(np.unique(diffs)), sum(np.unique(sums)), var_sums, var_diffs, len(A)

def _heuristic_score(A):
    diffs, sums, var_s, var_d, n = _compute_stats(A)
    if n < 2 or sum(diffs) == 1 or sum(sums) == 1:
        return 0.0
    ratio = math.log(sum(diffs)) / math.log(sum(sums)) + (1 - 1/n)/100
    bonus = 0.0
    if var_s < 1e-9:
        bonus += 0.01
    if var_d > 1e10:
        bonus += 0.001
    return ratio + bonus

def _gradient_step(A):
    best_move = 0
    best_score = _heuristic_score(A)
    A = list(A)
    for i in range(len(A)):
        for delta in [-1, 1]:
            cand = A[:]
            temp = assign_to = False
            if delta == 1:
                if A[i] + 1 not in set(A) and A[i] + 1 <= 1e15:
                    temp = True
                    assign_to = True
            else:
                if A[i] - 1 not in set(A) and A[i] - 1 >= -1e15:
                    temp = True
                    assign_to = True
            if temp:
                cand[i] += delta
                cand_score = _heuristic_score(cand)
                if cand_score > best_score + 0.0001:
                    best_score = cand_score
                    best_move = delta
    return A if best_score == _heuristic_score(A) else cand if best_move != 0 else A

def solve():
    best = [0] * 30
    best[0] = 0
    best[1] = 1
    best[2] = 2 * 10**9
    best[3] = best[2] + 1
    best[4] = best[2] + 2
    best[5] = best[2] + 3
    best_score = _heuristic_score(best)
    cur = best[:]
    deadline = time.time() + 120
    while time.time() < deadline:
        for _ in range(200):
            candidate = cur[:]
            if random.random() > 0.5:
                idx = random.randrange(len(candidate))
                diff = random.choice([-1, 1])
                target = candidate[idx] + diff
                if abs(target) <= 1e15 and target not in candidate:
                    candidate[idx] = target
                else:
                    continue
                if len(candidate) < 4500:
                    candidate = candidate + [random.randint(1, 1000) + random.randint(1, 1000)*10**9 if random.random() < 0.3 else random.randint(1, 1000)]
                candidate = sorted(set(candidate))
                score = _heuristic_score(candidate)
                if score > best_score:
                    best, best_score, cur = candidate, score, candidate
            elif random.random() < 0.1 and len(cur) > 10:
                remove_idx = random.randrange(len(cur))
                cur = cur[:remove_idx] + cur[remove_idx+1:]
                cur = list(set(cur))
                cur.sort()
                if len(cur) < 9:
                    cur.append(1000)
                    cur.sort()
                score = _heuristic_score(cur)
                if score > best_score:
                    best, best_score, cur = cur, score, cur
        cur = best[:]
    return sorted(set(cur))
