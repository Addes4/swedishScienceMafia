import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) == 0:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _diffs_count(a):
    return len({x - y for x in a for y in a})


def _sums_count(a):
    return len({x + y for x in a for y in a})


def _score_fast(diffs, sums, n):
    if sums == 0 or n < 2:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _subset_optimize(pool, k, budget_deadline):
    """Greedy/randomized subset selection to maximize score."""
    pool = list(set(pool))
    random.shuffle(pool)
    # Start with best k from random greedy
    n = len(pool)
    if n <= k:
        return pool

    best = None
    best_score = -1e9
    # multiple tries of greedy add
    tries = 3
    for _ in range(tries):
        if time.time() > budget_deadline:
            break
        cur = []
        # seed with random element
        cur = [pool[0]]
        remaining = pool[1:]
        while len(cur) < k:
            if time.time() > budget_deadline:
                break
            best_add = None
            best_add_score = -1e9
            # sample a few candidates
            for cand in random.sample(remaining, min(len(remaining), 30)):
                trial = cur + [cand]
                s = _score(trial)
                if s > best_add_score:
                    best_add_score = s
                    best_add = cand
            if best_add is None:
                break
            cur.append(best_add)
            remaining.remove(best_add)
        s = _score(cur)
        if s > best_score:
            best_score = s
            best = cur[:]
    return best if best else pool[:k]


def solve():
    random.seed(12345)
    deadline = time.time() + 110

    pop_size = 24
    population = []
    # seed with diverse random small sets
    for _ in range(pop_size):
        k = random.randint(5, 12)
        base = [random.randint(-50, 50) for _ in range(k)]
        population.append(list(set(base)))

    # ensure a good seed similar to baseline
    population.append([7, 15, 18, 22, -3, -2])

    scored = [( _score(ind), ind) for ind in population]
    scored.sort(key=lambda x: -x[0])

    best_score = scored[0][0]
    best = scored[0][1][:]

    gen = 0
    while time.time() < deadline:
        gen += 1
        scored.sort(key=lambda x: -x[0])
        elites = [ind for _, ind in scored[:4]]

        new_pop = [e[:] for e in elites]

        while len(new_pop) < pop_size and time.time() < deadline:
            p1 = random.choice(elites if random.random() < 0.5 else [e for _, e in scored])
            p2 = random.choice([e for _, e in scored])

            # Crossover: concatenate and select subset
            pool = p1 + p2 + [random.randint(-80, 80) for _ in range(random.randint(0, 4))]
            k = random.randint(5, max(5, min(len(pool), 14)))
            child = _subset_optimize(pool, k, deadline)

            # Mutation
            mut_rate = 0.7
            if random.random() < mut_rate:
                cm = child[:]
                for _ in range(random.randint(1, 3)):
                    op = random.random()
                    if op < 0.5 and cm:
                        i = random.randrange(len(cm))
                        cm[i] += random.randint(-15, 15)
                    elif op < 0.75:
                        cm.append(random.randint(-100, 100))
                    elif len(cm) > 3:
                        cm.pop(random.randrange(len(cm)))
                child = list(set(cm))

            # occasional local polish
            if random.random() < 0.3 and time.time() < deadline:
                child2 = child[:]
                improved = True
                iters = 0
                while improved and iters < 30 and time.time() < deadline:
                    improved = False
                    iters += 1
                    cur_s = _score(child2)
                    for _ in range(8):
                        cm = child2[:]
                        if cm:
                            i = random.randrange(len(cm))
                            cm[i] += random.choice([-2, -1, 1, 2])
                        else:
                            continue
                        ns = _score(cm)
                        if ns > cur_s:
                            child2 = cm
                            cur_s = ns
                            improved = True
                            break
                child = child2

            child = list(set(child))
            new_pop.append(child)

        population = new_pop
        for ind in population:
            s = _score(ind)
            if s > best_score:
                best_score = s
                best = ind[:]

        # restart diversity if stagnating
        if gen % 40 == 0 and time.time() < deadline - 20:
            for _ in range(pop_size // 3):
                k = random.randint(5, 14)
                population.append([random.randint(-200, 200) for _ in range(k)])

    return sorted(set(best))
# EVOLVE-BLOCK-END
