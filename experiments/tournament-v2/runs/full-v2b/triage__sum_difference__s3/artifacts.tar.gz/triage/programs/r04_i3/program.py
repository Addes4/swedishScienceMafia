# EVOLVE-BLOCK-START
"""Construct A by an iterative heuristic inspired by column generation:
grow A incrementally, at each step trying new candidate integers that
maximise the difference-set / sum-set size ratio. We use scipy.optimize.linprog
to solve relaxed LP surrogates that guide candidate selection.
"""
import math
import random
import time
from itertools import combinations

import numpy as np
from scipy.optimize import linprog


def _sizes(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return 0, 0
    diffs = set()
    sums = set()
    lst = list(s)
    for i in range(n):
        ai = lst[i]
        for j in range(n):
            aj = lst[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return len(diffs), len(sums)


def _score(a):
    s = set(a)
    if len(s) < 2:
        return 0.0
    d, sm = _sizes(s)
    if sm <= 1:
        return 0.0
    return math.log(d) / math.log(sm) + (1 - 1 / len(s)) / 100


def _greedy_grow(base, pool, deadline, rng):
    """Grow a set from base by adding elements from pool, choosing additions
    that maximise the score. Uses an LP relaxation as guidance but falls
    back on exact evaluation for the final choice."""
    cur = list(set(base))
    cur_d, cur_s = _sizes(cur)
    improved = True
    while improved and time.time() < deadline:
        improved = False
        best_add = None
        best_score = math.log(cur_d) / math.log(max(cur_s, 2)) if cur_s > 1 else 0.0
        sample = pool if len(pool) <= 60 else rng.sample(pool, 60)
        for x in sample:
            if x in cur:
                continue
            d2, s2 = _sizes(cur + [x])
            if s2 <= 1:
                continue
            sc = math.log(d2) / math.log(s2)
            if sc > best_score + 1e-12:
                best_score = sc
                best_add = x
        if best_add is not None:
            cur.append(best_add)
            cur_d, cur_s = _sizes(cur)
            improved = True
    return cur


def _lp_candidates(cur, pool, rng, topk=40):
    """Use a small LP relaxation to rank candidates.

    Model: we want to encourage new differences and discourage new sums.
    For each candidate x, the marginal new differences are |{x - a : a in A}
    union {a - x : a in A}| and marginal new sums are |{x + a : a in A} union
    {a + x : a in A} Plus the self terms. Since x+x is a single new sum and
    0 is already there, we approximate the 'cost' as number of new sums and
    'gain' as number of new diffs. We rank by gain/cost via an LP over
    relaxed real weights summing to 1, then take top-k. This is heuristic
    guidance for column generation.
    """
    A = list(set(cur))
    diff_set = set()
    sum_set = set()
    for a in A:
        for b in A:
            diff_set.add(a - b)
            sum_set.add(a + b)

    cands = []
    for x in pool:
        if x in A:
            continue
        new_d = 0
        new_s = 0
        for a in A:
            if (x - a) not in diff_set:
                new_d += 1
            if (a - x) not in diff_set:
                new_d += 1
            if (x + a) not in sum_set:
                new_s += 1
            if (a + x) not in sum_set:
                new_s += 1
        if (x + x) not in sum_set:
            new_s += 1
        cands.append((x, new_d, new_s))

    if not cands:
        return []

    # LP: maximize sum w_i * new_d_i  s.t. sum w_i * new_s_i <= budget,
    # sum w_i = 1, w_i >= 0. (column generation surrogate)
    total_new_s = sum(c[2] for c in cands)
    budget = max(1, total_new_s // max(1, len(cands))) + 1

    c_obj = np.array([-c[1] for c in cands], dtype=float)  # maximize gain
    A_ub = np.array([[c[2] for c in cands]], dtype=float)
    b_ub = np.array([budget], dtype=float)
    A_eq = np.ones((1, len(cands)), dtype=float)
    b_eq = np.array([1.0], dtype=float)
    bounds = [(0, 1)] * len(cands)
    try:
        res = linprog(c_obj, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq,
                      bounds=bounds, method="highs")
        if res.success and res.x is not None:
            w = res.x
            order = np.argsort(-w)
            ranked = [cands[i][0] for i in order[:topk]]
            return ranked
    except Exception:
        pass
    # fallback: rank by gain - 0.5*cost
    cands.sort(key=lambda c: -(c[1] - 0.5 * c[2]))
    return [c[0] for c in cands[:topk]]


def _build_from_seed(seed, deadline, rng, pool_size=200):
    """Column-generation-style construction from a seed set."""
    base = list(set(seed))
    if len(base) < 2:
        return base
    # Initial pool: perturbations of base plus small integers
    maxv = max(abs(x) for x in base) + 40
    lo = -maxv
    hi = maxv
    pool = list(range(lo, hi + 1))
    rng.shuffle(pool)
    pool = pool[:pool_size]

    cur = base[:]
    cur_d, cur_s = _sizes(cur)

    while time.time() < deadline:
        ranked = _lp_candidates(cur, pool, rng, topk=25)
        if not ranked:
            break
        # Evaluate top candidates exactly, pick best
        best_add = None
        best_sc = math.log(cur_d) / math.log(max(cur_s, 2)) if cur_s > 1 else 0.0
        for x in ranked:
            if x in cur:
                continue
            d2, s2 = _sizes(cur + [x])
            if s2 <= 1:
                continue
            sc = math.log(d2) / math.log(s2)
            if sc > best_sc + 1e-12:
                best_sc = sc
                best_add = x
        if best_add is None:
            # delayed column generation: inject new columns (candidates) from
            # perturbations of current set
            newcols = []
            for a in cur:
                for delta in (-1, 1, -2, 2):
                    newcols.append(a + delta)
            newcols = [c for c in newcols if c not in cur and c not in pool]
            if not newcols:
                break
            pool.extend(rng.sample(newcols, min(len(newcols), 40)))
            cur_d, cur_s = _sizes(cur)
            # also try one more direct greedy step before bailing
            ranked2 = _lp_candidates(cur, pool, rng, topk=25)
            for x in ranked2:
                if x in cur:
                    continue
                d2, s2 = _sizes(cur + [x])
                if s2 <= 1:
                    continue
                sc = math.log(d2) / math.log(s2)
                if sc > best_sc + 1e-12:
                    best_sc = sc
                    best_add = x
            if best_add is None:
                break
        cur.append(best_add)
        cur_d, cur_s = _sizes(cur)

    return cur


def solve():
    """Construct A by iterative growth guided by LP-relaxed candidate ranking
    (a heuristic column generation), maximising log|A-A|/log|A+A|."""
    rng = random.Random(12345)
    deadline = time.time() + 110

    # Strong seed sets known to have good structure (Sidon-like with small sums).
    seeds = [
        [1, 2, 4, 8, 16],
        [0, 1, 4, 9, 15],
        [7, 15, 18, 22, -3, -2],
        [1, 2, 5, 9, 14, 20],
        [0, 1, 2, 5, 7, 12],
        [1, 3, 6, 10, 15, 21],
    ]

    best = None
    best_score = -1.0

    per_trial = max(2.0, 100.0 / max(1, len(seeds)))

    for seed in seeds:
        if time.time() >= deadline:
            break
        t_end = min(deadline, time.time() + per_trial)
        cand = _build_from_seed(seed, t_end, rng)
        # prune: remove elements that don't hurt
        cand = list(set(cand))
        cand = _prune(cand)
        sc = _score(cand)
        if sc > best_score:
            best_score = sc
            best = cand[:]

    # Local search polish on the best found
    if best is not None:
        best = _local_search(best, deadline, rng)
        sc = _score(best)
        if sc > best_score:
            best_score = sc

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return sorted(set(best))


def _prune(a):
    """Remove elements one at a time if removal doesn't reduce the score."""
    a = list(set(a))
    changed = True
    while changed:
        changed = False
        base_sc = _score(a)
        for i in range(len(a)):
            trial = a[:i] + a[i + 1:]
            if len(trial) < 2:
                continue
            if _score(trial) >= base_sc - 1e-12:
                a = trial
                changed = True
                break
    return a


def _local_search(a, deadline, rng, iters=100000):
    """Random local search: small perturbations and additions."""
    best = list(set(a))
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score
    count = 0
    while time.time() < deadline and count < iters:
        count += 1
        cand = cur[:]
        op = rng.random()
        if op < 0.5 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-4, 4)
        elif op < 0.85:
            cand.append(rng.randint(-30, 30))
        elif op < 0.95 and len(cand) > 4:
            i = rng.randrange(len(cand))
            cand = cand[:i] + cand[i + 1:]
        else:
            if cand:
                i = rng.randrange(len(cand))
                cand[i] = -cand[i]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        try:
            sc = _score(cand)
        except ZeroDivisionError:
            continue
        if sc >= best_score:
            best = cand[:]
            best_score = sc
            cur = cand[:]
            cur_score = sc
        elif sc > cur_score or rng.random() < 0.05:
            cur = cand[:]
            cur_score = sc
        if rng.random() < 0.02:
            cur = best[:]
            cur_score = best_score
    return best
# EVOLVE-BLOCK-END
