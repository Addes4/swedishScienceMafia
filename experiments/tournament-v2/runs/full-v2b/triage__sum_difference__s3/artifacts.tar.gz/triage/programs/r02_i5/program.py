import math
import random
import time
from itertools import combinations, product

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def _exhaustive_search(size, max_val):
    """Exhaustive search for best sum-difference ratio for sets of given size with elements in [-max_val, max_val]."""
    best_score = 0.0
    best_set = None
    # Generate all candidate values
    vals = list(range(-max_val, max_val+1))
    # For small sizes, iterate over all combinations
    for comb in combinations(vals, size):
        # Ensure set is symmetric-ish? No restriction.
        s = _score(comb)
        if s > best_score:
            best_score = s
            best_set = comb
    return list(best_set), best_score

def _generate_building_blocks():
    """Generate a library of small sets with excellent sum-difference ratios."""
    library = []
    # Exhaustive search up to size 8, values in small range
    # We'll focus on sizes 4-8, with max absolute value around 10
    for size in range(4, 9):
        best, sc = _exhaustive_search(size, 10)
        if best is not None:
            library.append((best, sc))
    # Also include some known good sets
    known = [
        [0, 1, 4, 6],  # classic MSTD-like
        [0, 1, 3, 8, 9, 11],
        [-2, -1, 0, 1, 2, 5],
        [0, 1, 4, 10, 12, 17],
        [0, 1, 3, 7, 12, 20, 30],
        [0, 1, 4, 9, 15, 22, 32, 34],
    ]
    for k in known:
        library.append((k, _score(k)))
    # Deduplicate and sort by score
    library = sorted(set((tuple(sorted(s)), sc) for s, sc in library), key=lambda x: x[1], reverse=True)
    return [list(s) for s, _ in library]

def _combine_blocks(blocks, translations):
    """Combine blocks with given translations (list of offsets)."""
    A = []
    for block, t in zip(blocks, translations):
        for x in block:
            A.append(x + t)
    return A

def _random_partition(n, k):
    """Randomly partition n into k positive parts."""
    if k <= 1:
        return [n]
    cuts = sorted(random.sample(range(1, n), k-1))
    parts = [cuts[0]] + [cuts[i] - cuts[i-1] for i in range(1, k-1)] + [n - cuts[-1]]
    random.shuffle(parts)
    return parts

def _evolve_combined(initial_blocks, time_budget=100):
    """Evolve translations and block selection to maximize score."""
    deadline = time.time() + time_budget
    library = _generate_building_blocks()
    # Start with a random combination of some blocks
    n_blocks = random.randint(10, 30)
    selected_blocks = [random.choice(library) for _ in range(n_blocks)]
    # Assign random translations with some spacing
    total_span = 5000
    translations = sorted(random.sample(range(-total_span, total_span), n_blocks))
    
    best_A = _combine_blocks(selected_blocks, translations)
    best_score = _score(best_A)
    best_blocks = selected_blocks[:]
    best_trans = translations[:]
    
    cur_blocks = selected_blocks[:]
    cur_trans = translations[:]
    
    while time.time() < deadline:
        # Mutation
        if random.random() < 0.3:  # change a block
            idx = random.randrange(len(cur_blocks))
            cur_blocks[idx] = random.choice(library)
        if random.random() < 0.3:  # adjust a translation
            idx = random.randrange(len(cur_trans))
            cur_trans[idx] += random.randint(-200, 200)
        if random.random() < 0.1:  # add a block
            cur_blocks.append(random.choice(library))
            cur_trans.append(random.randint(-total_span, total_span))
        if random.random() < 0.1 and len(cur_blocks) > 5:  # remove a block
            idx = random.randrange(len(cur_blocks))
            del cur_blocks[idx]
            del cur_trans[idx]
        
        # Ensure translations are distinct? Not strictly necessary but helps
        if len(set(cur_trans)) < len(cur_trans):
            # reassign clashing ones
            used = set()
            for i, t in enumerate(cur_trans):
                while t in used:
                    t += random.randint(-100, 100)
                cur_trans[i] = t
                used.add(t)
        
        A = _combine_blocks(cur_blocks, cur_trans)
        s = _score(A)
        if s >= best_score:
            best_score = s
            best_blocks = cur_blocks[:]
            best_trans = cur_trans[:]
            # Keep searching from new best
        else:
            # revert sometimes
            if random.random() < 0.2:
                cur_blocks = best_blocks[:]
                cur_trans = best_trans[:]
    
    return best_blocks, best_trans, best_score

def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    random.seed(42)  # reproducibility within time limit
    deadline = time.time() + 115  # leave some margin
    
    best_overall = None
    best_overall_score = 0.0
    
    while time.time() < deadline:
        # Run evolution in remaining time
        time_left = deadline - time.time()
        if time_left < 2:
            break
        blocks, trans, score = _evolve_combined(None, time_budget=min(time_left, 30))
        A = _combine_blocks(blocks, trans)
        # Ensure within constraints
        A = list(set(A))
        if len(A) > 4000:
            # trim randomly but keep best set
            A = random.sample(A, 4000)
        if any(abs(x) > 1e15 for x in A):
            continue
        s = _score(A)
        if s > best_overall_score:
            best_overall_score = s
            best_overall = A
    
    # Final local polishing: simple hill climbing on the best set
    if best_overall is not None:
        cur = best_overall[:]
        cur_score = best_overall_score
        polish_deadline = time.time() + 5
        while time.time() < polish_deadline:
            cand = cur[:]
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
            # occasionally add/remove
            if random.random() < 0.02 and len(cand) < 4000:
                cand.append(random.randint(-10000, 10000))
            if random.random() < 0.02 and len(cand) > 50:
                del cand[random.randrange(len(cand))]
            s = _score(cand)
            if s > cur_score:
                cur_score = s
                cur = cand
        best_overall = cur[:]
    
    return sorted(set(best_overall)) if best_overall else [0, 1, 4, 6]

if __name__ == "__main__":
    result = solve()
    print("Score:", _score(result))
    print("Length:", len(result))
