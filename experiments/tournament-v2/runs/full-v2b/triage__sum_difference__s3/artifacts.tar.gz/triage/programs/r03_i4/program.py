import math
import random
import time
from itertools import product, combinations

def evaluate(A):
    """Compute score = log|A-A| / log|A+A| + small bonus."""
    if not isinstance(A, set):
        A = set(A)
    n = len(A)
    if n < 2:
        return 0.0
    # Compute difference and sum sets efficiently (O(n^2) but n small here)
    A_list = list(A)
    diffs = set()
    sums = set()
    for x in A_list:
        for y in A_list:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0

def build_modular_set(modulus, shifts, step, size):
    """Generate a set: union_{s in shifts} { i*step + s : i=0..size-1 } mod modulus,
    then center around 0 for smaller numbers.
    Returns a list of integers."""
    base = []
    for s in shifts:
        for i in range(size):
            val = (i * step + s) % modulus
            # center: map values into [-modulus//2, modulus//2]
            if val > modulus // 2:
                val -= modulus
            base.append(val)
    # remove duplicates
    return sorted(set(base))

def local_search(A, iterations=2000, temp_start=1.0, temp_end=0.01):
    """Simple simulated annealing local search on integer set A.
    Mutations: change one element by small delta, add/remove elements."""
    cur = sorted(set(A))
    cur_score = evaluate(cur)
    best = cur[:]
    best_score = cur_score
    
    n = len(cur)
    for i in range(iterations):
        # adaptive temperature
        t = temp_start * (temp_end / temp_start) ** (i / iterations)
        cand = cur[:]
        # random mutation
        idx = random.randrange(len(cand))
        # change by -3..3 (excluding 0 to avoid no-change)
        delta = random.choice([-3,-2,-1,1,2,3])
        cand[idx] += delta
        # occasionally add/remove
        if random.random() < 0.1 and len(cand) < 200:
            # add a new element near existing ones
            base_val = random.choice(cand)
            cand.append(base_val + random.randint(-5,5))
        if random.random() < 0.05 and len(cand) > 5:
            cand.pop(random.randrange(len(cand)))
        # ensure distinct
        if len(set(cand)) != len(cand):
            continue
        cand_score = evaluate(set(cand))
        if cand_score > cur_score or random.random() < math.exp((cand_score - cur_score)/t):
            cur = cand
            cur_score = cand_score
            if cur_score > best_score:
                best = cur[:]
                best_score = cur_score
    return best

def solve():
    random.seed(42)
    deadline = time.time() + 110  # leave some margin
    
    best_overall = None
    best_score_overall = -float('inf')
    
    # Parameter search space
    # modulus candidates: experiment with primes and composites around 50-500
    moduli = [61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397]
    # step values: co-prime to modulus gives full progression
    steps = [1, 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31]
    # number of shifted copies
    num_shifts_options = [1, 2, 3, 4]
    # size of each progression
    sizes = [5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 17, 20]
    
    # Random search over discrete parameters
    trials = 0
    while time.time() < deadline:
        modulus = random.choice(moduli)
        step = random.choice(steps)
        if math.gcd(step, modulus) != 1:
            continue
        k = random.choice(num_shifts_options)
        # select k distinct shifts
        shifts = random.sample(range(modulus), k)
        size = random.choice(sizes)
        # ensure total elements not too large (at most ~2000 for speed, later we can expand)
        total_elems = k * size
        if total_elems > 4000 or total_elems < 5:
            continue
        
        A = build_modular_set(modulus, shifts, step, size)
        if len(A) < 5:
            continue
        
        # Quick score check before local search
        score0 = evaluate(A)
        if score0 > best_score_overall * 0.9:  # only refine promising ones
            # Apply local search
            A_refined = local_search(A, iterations=300 if total_elems > 100 else 500,
                                     temp_start=1.0, temp_end=0.01)
            score_ref = evaluate(A_refined)
            if score_ref > best_score_overall:
                best_score_overall = score_ref
                best_overall = A_refined
        trials += 1
        # Every 50 trials, do a more focused search around current best if exists
        if trials % 50 == 0 and best_overall is not None:
            # try varying shifts or modulus around best
            for _ in range(5):
                if time.time() > deadline:
                    break
                # tweak parameters of best guess? Hard without storing params, but we can
                # apply further local search with more iterations on best_overall
                A_more = local_search(best_overall, iterations=1000, temp_start=0.5, temp_end=0.001)
                s = evaluate(A_more)
                if s > best_score_overall:
                    best_score_overall = s
                    best_overall = A_more
    
    # Final intensive local search on best result
    if best_overall is not None:
        final = local_search(best_overall, iterations=5000, temp_start=0.2, temp_end=1e-6)
        if evaluate(final) > best_score_overall:
            best_overall = final
    else:
        # fallback
        best_overall = [7, 15, 18, 22, -3, -2]
    
    # Ensure distinct, within bounds, at most 4000
    res = sorted(set(best_overall))
    if len(res) > 4000:
        # trim randomly to 4000, but preserve good set properties? just keep first 4000
        res = res[:4000]
    # ensure absolute value <= 1e15
    res = [x for x in res if abs(x) <= 1e15]
    return res

if __name__ == "__main__":
    A = solve()
    print("Score:", evaluate(A))
    print("Length:", len(A))
