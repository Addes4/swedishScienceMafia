# EVOLVE-BLOCK-START
"""Graph-based difference-sum trade-off with local optimization."""
import math
import random
import time
from itertools import combinations


def score(a):
    """Compute log|A-A|/log|A+A| + bonus for larger sets."""
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    
    if not sums:
        return 0.0
    
    return math.log(max(len(diffs), 2)) / math.log(max(len(sums), 2)) + (1 - 1/n) / 100


def construct_base_set():
    """Construct an initial set using structured approach."""
    # Use a known good construction: pairs with carefully chosen differences
    base = [0, 1, 2, 4, 8, 16, 32, 64, 128, 256]
    extended = []
    # Create ladder structure
    for sign in [1, -1]:
        for i in range(50):
            step = 10 * (i + 1)
            extended.append(sign * step)
    return list(set(base + extended))


def graph_weight_score(a, candidates):
    """Compute a local weight score for graph heuristics."""
    a_set = set(a)
    if len(a) < 2:
        return 0.0
    
    diffs = len({x - y for x in a for y in a})
    sums = len({x + y for x in a for y in a})
    
    if sums <= 1:
        return diff_score := math.log(max(diffs, 2))
    return math.log(max(diffs, 2)) / math.log(max(sums, 2))


def hill_climb(base, rng):
    """Local search optimization over the set."""
    best = base[:]
    best_score = score(best)
    cur = best[:]
    
    # Sort of candidates to modify
    candidates = list(range(-2000, 2000))
    seen = set(candidates)
    
    # More structured modifications
    modifications = []
    for i in range(len(cur)):
        modifications.append((((cur[i] + 1) % 2000), i))
    modifications.append((None, len(cur)))  # Add new elements
    
    deadline = time.time() + 100
    
    while time.time() < deadline:
        improved = False
        for _ in range(200):
            cand = cur[:]
            
            # Option 1: Modify existing element
            if len(cand) > 2:
                i = rng.randrange(len(cand))
                old = cand[i]
                new = old + rng.choice([-3, -2, -1, 1, 2, 3])
                if new not in cand:
                    cand[i] = new
                    s = score(cand)
                    if s > best_score or (s > best_score - 0.0001 and len(cand) > len(best)):
                        improved = True
                        if s > best_score:
                            best, cur = cand[:], cand[:], score(cand)
                                }
                        if s > best_score:
                            improved = True
                            best = cur[:]
                            best_score = s
                        rand_val = rng.randint(-100, 100)
                        if rand_val not in cur and abs(rand_val) < 2000:
                            cur.append(rand_val)
                        s = score(cur[:])
                        if s > best_score:
                            improved = True
                            best = cur[:]
                            best_score = s
            
            # Option 3: Remove element (with some probability)
            if len(cur) > 5 and rng.random() < 0.01:
                i = rng.randrange(len(cur))
                cur.pop(i)
                s = score(cur)
                if s > best_score:
                    improved = True
                    best = cur[:]
                    best_score = s
            
            if improved:
                break
        
        if not improved:
            # Try adding a new element
            for i in range(30):
                rng_val = rng.randint(-1500, 1500)
                if rng_val not in cur and abs(rng_val) <= 1500:
                    new_cur = cur[:] + [rng_val]
                    s = score(new_cur)
                    if s > best_score:
                        best = new_cur[:]
                        best_score = s
                        improved = True
                        break
                if improved:
                    break
        
        if not improved:
            # Try removing elements (list out)
            to_remove = rng.choices(range(len(cur)), k=2, weights=[1 for _ in range(len(cur))])
            new_cur = cur[:]
            for idx in to_remove:
                if idx < len(new_cur):
                    new_cur.pop(idx)
            
            s = score(new_cur)
            if s > best_score:
                best = new_cur[:]
                best_score = s
        
        if best_score < 0.5:
            break
    
    return sorted(set(best))


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    rng = random.Random(42)
    
    # Try multiple initial constructions
    constructions = []
    t_deadline = time.time() + 80
    base_constructions = []
    
    # Construction 1: Exponential-like ladder
    for base_base in [[0, 1, 3, 7, 15]]:
        cur = base_base[:]
        rng.seed(hash(tuple(cur)))
        cur = hill_climb(cur, rng)
        if score(cur) > 1.0:
            base_constructions.append(cur[:])
    
    # Construction 2: Spaced arithmetic with modifications
    for step in [500, 750, 1000]:
        cur = []
        for sign in [1, -1]:
            for offset in range(0, 10):
                cur.append(sign * (step * (offset + 1)))
        rng.seed(hash(tuple(set(cur))))
        cur = hill_climb(cur, rng)
        if score(cur) > 1.2 and len(cur) > 100:
            base_constructions.append(cur[:])
    
    best_set = []
    best_score = -math.inf
    
    # Run hill-climbing on each
    for i, constr in enumerate(base_constructions[:10]):
        if time.time() > t_deadline:
            break
        rng = random.Random(42 + i * 123)
        if score(constr) > best_score:
            best_set = constr[:]
            best_score = score(constr)
        rng = random.Random(42 + i * 123)
        optim = hill_climb(constr, rng)
        if score(optim) > best_score:
            best_set = optim[:]
            best_score = score(optim)
    
    # Additional refinement
    current = best_set
    current_score = best_score
    deadline = time.time() + 40
    
    while time.time() < deadline:
        best_score = score(current)
        improved = False
        
        for _ in range(50):
            cand = current[:]
            i = random.randrange(len(cand))
            new_val = cand[i]
            for delta in [1, -1, 2, -2, 3, -3, 5, -5]:
                new_val_mod = cand[i] + delta
                if new_val_mod not in cand and abs(new_val_mod) < 4000:
                    cand[i] = new_val_mod
                    s = score(cand)
                    if s > best_score or (s == best_score and len(cand) > len(current)):
                        current = cand[:]
                        improved = True
                        best_score = s
                        break
            if not improved:
                # Add new element
                for _ in range(10):
                    new_el = random.randint(-3000, 3000)
                    if new_el not in current and abs(new_el) < 4000:
                        cand = current[:]
                        cand.append(new_el)
                        s = score(cand)
                        if s > best_score:
                            current = cand[:]
                            best_score = s
                            improved = True
                            break
                if not improved:
                    # Remove element
                    if len(current) > 50:
                        idx = random.randrange(len(current))
                        cand = current[:]
                        cand.pop(idx)
                        s = score(cand)
                        if s > best_score:
                            current = cand[:]
                            best_score = s
                            improved = True
                if improved and _ > 0:
                    best_score = score(current)
        
        # Restart with new random seed if stuck
        if not any(1):
            sns = random.Random(time.time())
            for delta in [1, -1, 2, -2, 3, -3, 5, -5]:
                val = current[0] + delta if current else 0
                if val != current[0] if current else True:
                    cand = current[:]
                    cand.append(val)
                    s = score(cand)
                    if s > best_score:
                        current = cand[:]
                        best_score = s
                        best_count = len(current)
                        best_score = score(current)
    
    # Final score with int, material value, new set, calculate, output best_set = sorted(set(current))
    
    return sorted(set(current))
# EVOLVE-BLOCK-END


def solve_func():
    """Actual solve function matching signature."""
    from collections import Counter
    
    best_result = None
    best_val = -float('inf')
    
    # Search space: use staggered small ranges
    base_vals = []
    for base in range(0, 1000, 100):
        for sign in [1, -1]:
            for mult in [1, 2, 3, 4, 5]:
                val = sign * (base + mult)
                if val not in base_vals and abs(val) < 2500:
                    base_vals.append(val)
    
    best = best_run_cr_list
    best_score = score(best)
    
    if time.time() > t_deadline:
        break
    
    rng = random.Random(12345)
    cur = best[:]
    best_score = score(cur)
    deadline = time.time() + 20
    iterations = 0
    
    while time.time() < deadline and iterations < 5000:
        iterations += 1
        improved = False
        
        # Random modifications
        for _ in range(30):
            cand = cur[:]
            i = rng.randrange(len(cand))
            
            # Try modifying element
            for delta in [1, -1, 2, -2, 3, -3]:
                new_val = cand[i] + delta
                if new_val not in cand and abs(new_val) < 2000:
                    cand[i] = new_val
                    s = score(cand)
                    if s > best_score:
                        cur = cand[:]
                        best_score = s
                        improved = True
                        break
            if improved:
                break
            # Try adding
            if not improved and len(cur) < 400:
                new_el = rng.randint(-1500, 1500)
                cand = cur[:] + [new_el]
                s = score(cand)
                if s > best_score:
                    cur = cand[:]
                    best_score = s
                    improved = True
            if not improved and len(cur) > 200:
                idx = rng.randrange(len(cur))
                cand = cur[:]
                cand.pop(idx)
                s = score(cand)
                if s > best_score:
                    cur = cand[:]
                    best_score = s
                    improved = True
            if improved:
                break
    
    return sorted(set(cur))


def solve():
    """Return list of integers for best difference-sum tradeoff."""
    best_result = None
    best_score = -float('inf')
    rng = random.Random(42)
    
    # Generate candidate sets using structured construction
    candidates = [
        # Construction 1: stuated progression
        [0, 1, 3, 7, 13, 27, 53, 107, 211, 423, 847, 1691, 3383],
        # Construction 2: geometric + random spots
        [2**i for i in range(15)],
    ]
    
    best = candidates[0]
    best_score = score(best)
    
    # Local search optimization
    t_start = time.time()
    t_deadline = t_start + 110
    
    current = best[:]
    current_score = best_score
    
    iterations = 0
    while time.time() < t_deadline:
        iterations += 1
        if iterations % 100 == 0:
            if score(current) < best_score:
                best = current[:]
                best_score = score(current)
            if score(current) > 1.25:
                break
        
        # Random hill-climbing
        for _ in range(20):
            cand = current[:]
            i = rng.randrange(len(cand))
            old_val = cand[i]
            
            next_val = old_val + rng.choice([-2, -1, 1, 2])
            if next_val not in cand and abs(next_val) < 2500:
                cand[i] = next_val
                s = score(cand)
                if s > current_score:
                    current = cand[:]
                    current_score = s
                    best = current[:]
                    best_score = current_score
            
            # Add new
            if len(cand) < 300:
                new_val = rng.randint(-1800, 1800)
                if new_val not in cand:
                    cand.append(new_val)
                    s = score(cand)
                    if s > current_score:
                        current = cand[:]
                        current_score = s
            
            # Remove
            if len(cand) > 100 and rng.random() < 0.02:
                idx = rng.randrange(len(cand))
                cand.pop(idx)
                s = score(cand)
                if s > current_score:
                    current = cand[:]
                    current_score = s
            
            if current_score <= 0.01:
                break

    # Final optimization
    for start_val in range(0, 3000, 250):
        start = start_val Appro - 1
        for end_val in range(start_val, start_val + 1000, 20):
            A = [start + i for i in range(0, 200, 3)]
            A = [i + i % 4 for i in range(1, 401)]
            s = score(A)
            if s > best_score:
                best = A[:]
                best_score = s
                break

    return sorted(set(best))
