import math
import random
import time
from collections import Counter

def compute_sets(A):
    """Compute diff and sum sets for a given list A."""
    diffs = set()
    sums = set()
    for i, x in enumerate(A):
        for j, y in enumerate(A):
            diffs.add(x - y)
            sums.add(x + y)
    return diffs, sums

def score_from_sets(A, diffs, sums):
    """Compute score given precomputed sets."""
    if len(A) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1/len(A)) / 100

def score(A):
    """Compute score for a list A."""
    if len(A) < 2:
        return 0.0
    diffs, sums = compute_sets(A)
    return score_from_sets(A, diffs, sums)

def remove_diffs_sums(diffs, sums, A, idx):
    """Remove contributions of A[idx] from diffs and sums, returns new diffs/sums."""
    x = A[idx]
    new_diffs = diffs.copy()
    new_sums = sums.copy()
    
    # Check each other element to see if removing x eliminates any diff/sum
    for j, y in enumerate(A):
        if j == idx:
            continue
        
        d1 = x - y
        d2 = y - x
        s1 = x + y
        
        # Check if d1 appears only due to x,y pair
        count_d1 = 0
        for k, z in enumerate(A):
            if k == idx:
                continue
            if z - y == d1:
                count_d1 += 1
            if x - z == d1 and k != j:
                count_d1 += 1
        # Actually simpler: just recompute might be faster for small sets
        # Let's just recompute
    
    # For small sets, recompute is fine - let's use a more efficient approach
    return compute_sets([A[i] for i in range(len(A)) if i != idx])

def add_element_diffs_sums(diffs, sums, A_without, new_x):
    """Add a new element to the set and update diffs/sums incrementally."""
    new_diffs = diffs.copy()
    new_sums = sums.copy()
    for y in A_without:
        new_diffs.add(new_x - y)
        new_diffs.add(y - new_x)
        new_sums.add(new_x + y)
    new_diffs.add(0)  # x - x
    new_sums.add(new_x + new_x)
    return new_diffs, new_sums

def replace_element(A, diffs, sums, idx, new_val):
    """Replace A[idx] with new_val, updating diffs and sums incrementally."""
    if new_val in A:
        return None, None, None
    
    # Remove old element's contributions
    old_x = A[idx]
    new_diffs = set()
    new_sums = set()
    
    # Build new sets without old_x, then add new_val
    for i, x in enumerate(A):
        if i == idx:
            continue
        for j, y in enumerate(A):
            if j == idx:
                continue
            new_diffs.add(x - y)
            new_sums.add(x + y)
    
    # Now add new_val contributions
    for y in A:
        if y == old_x:
            continue
        new_diffs.add(new_val - y)
        new_diffs.add(y - new_val)
        new_sums.add(new_val + y)
    new_diffs.add(0)
    new_sums.add(2 * new_val)
    
    new_A = A[:]
    new_A[idx] = new_val
    return new_A, new_diffs, new_sums

def local_optimize(A, time_limit):
    """Perform local search with 2-opt and 3-opt moves."""
    best_A = A[:]
    best_diffs, best_sums = compute_sets(best_A)
    best_score = score_from_sets(best_A, best_diffs, best_sums)
    
    cur_A = best_A[:]
    cur_diffs, cur_sums = best_diffs.copy(), best_sums.copy()
    cur_score = best_score
    
    # Tabu search parameters
    tabu_list = []  # list of (value, position) pairs recently tried
    tabu_tenure = 50
    
    # Statistics
    total_moves = 0
    accepted_moves = 0
    
    while time.time() < time_limit:
        # Try different move types
        move_type = random.random()
        
        if move_type < 0.4:
            # 2-opt: swap two elements
            i, j = random.sample(range(len(cur_A)), 2)
            old_i, old_j = cur_A[i], cur_A[j]
            
            # Check tabu
            if ((old_i, i), (old_j, j)) in tabu_list or ((old_j, j), (old_i, i)) in tabu_list:
                continue
            
            new_A = cur_A[:]
            new_A[i], new_A[j] = old_j, old_i
            
            if len(set(new_A)) < len(new_A):  # duplicate check
                continue
            
            new_diffs, new_sums = compute_sets(new_A)
            new_score = score_from_sets(new_A, new_diffs, new_sums)
            
        elif move_type < 0.7:
            # Perturb one element by small amount
            i = random.randrange(len(cur_A))
            old_val = cur_A[i]
            
            # Try values that might change the structure
            delta = random.randint(-5, 5)
            if delta == 0:
                delta = 1
            new_val = old_val + delta
            
            if new_val in cur_A:
                continue
            
            if (new_val, i) in tabu_list:
                continue
            
            new_A = cur_A[:]
            new_A[i] = new_val
            new_diffs, new_sums = compute_sets(new_A)
            new_score = score_from_sets(new_A, new_diffs, new_sums)
            
        elif move_type < 0.85:
            # Replace one element with a completely new value
            if len(cur_A) < 4000:
                i = random.randrange(len(cur_A))
                old_val = cur_A[i]
                
                # Generate a new value that might improve the ratio
                # Try values from the current diff set or reasonable range
                candidates = list(cur_diffs) + list(range(-100, 101))
                new_val = random.choice(candidates)
                
                while new_val in cur_A:
                    new_val = random.choice(candidates)
                
                if (new_val, i) in tabu_list:
                    continue
                
                new_A = cur_A[:]
                new_A[i] = new_val
                new_diffs, new_sums = compute_sets(new_A)
                new_score = score_from_sets(new_A, new_diffs, new_sums)
            else:
                continue
                
        else:
            # Add an element (if under size limit)
            if len(cur_A) < 4000:
                # Try to add element that minimizes new sums while maximizing new diffs
                best_cand = None
                best_improvement = -float('inf')
                
                for _ in range(20):  # Sample candidates
                    cand_val = random.randint(-1000, 1000)
                    if cand_val in cur_A:
                        continue
                    
                    # Quick estimate: count new diffs vs new sums
                    new_diffs_est = len(cur_diffs)
                    new_sums_est = len(cur_sums)
                    
                    for y in cur_A[:min(50, len(cur_A))]:  # Approximate with subset
                        d1, d2 = cand_val - y, y - cand_val
                        s1 = cand_val + y
                        if d1 not in cur_diffs:
                            new_diffs_est += 1
                        if d2 not in cur_diffs:
                            new_diffs_est += 1
                        if s1 not in cur_sums:
                            new_sums_est += 1
                    
                    if 0 not in cur_diffs:
                        new_diffs_est += 1
                    if 2*cand_val not in cur_sums:
                        new_sums_est += 1
                    
                    if len(cur_A) + 1 >= 2:
                        improvement = math.log(new_diffs_est) / math.log(new_sums_est) - cur_score
                        if improvement > best_improvement:
                            best_improvement = improvement
                            best_cand = cand_val
                
                if best_cand is not None:
                    new_A = cur_A + [best_cand]
                    new_diffs, new_sums = compute_sets(new_A)
                    new_score = score_from_sets(new_A, new_diffs, new_sums)
                else:
                    continue
            else:
                continue
        
        # Accept if better or with some probability (simulated annealing)
        total_moves += 1
        if new_score > cur_score or random.random() < 0.1 * (1 - total_moves / 50000):
            cur_A, cur_diffs, cur_sums, cur_score = new_A, new_diffs, new_sums, new_score
            accepted_moves += 1
            
            # Update tabu list
            if move_type < 0.4:  # swap
                tabu_list.append(((old_i, i), (old_j, j)))
            elif move_type < 0.7:  # perturb
                tabu_list.append((new_val, i))
            else:
                tabu_list.append((new_val, i))
            
            if len(tabu_list) > tabu_tenure:
                tabu_list.pop(0)
            
            if new_score > best_score:
                best_score = new_score
                best_A = new_A[:]
                best_diffs, best_sums = new_diffs.copy(), new_sums.copy()
                total_moves = 0  # Reset to encourage more exploration
        
        # Occasionally restart from best known
        if total_moves > 2000 and random.random() < 0.01:
            cur_A = best_A[:]
            cur_diffs, cur_sums = best_diffs.copy(), best_sums.copy()
            cur_score = best_score
            total_moves = 0
            tabu_list = []
    
    return best_A, best_score

def generate_initial_sets():
    """Generate multiple promising initial configurations."""
    candidates = []
    
    # Configuration 1: Arithmetic progression-like (many diffs, relatively few sums)
    # Use two interleaved arithmetic progressions with different steps
    n = 50
    A = []
    for i in range(n):
        if i % 2 == 0:
            A.append(i * 10)
        else:
            A.append(i * 10 + 3)
    candidates.append(A)
    
    # Configuration 2: Powers of 2 (Sidon set - all sums distinct, but diffs also many)
    A = [2**i for i in range(15)]
    candidates.append(A)
    
    # Configuration 3: Combination approach - base set with small multipliers
    base = list(range(-10, 11))
    multipliers = [1, 100, 10000]
    A = []
    for m in multipliers:
        for b in base:
            A.append(m * b)
    A = list(set(A))
    candidates.append(A)
    
    # Configuration 4: Fibonacci-like (grows fast, gives many diffs, controlled sums)
    A = [1, 2]
    for i in range(30):
        A.append(A[-1] + A[-2] + random.randint(-1, 1))
    candidates.append(A)
    
    # Configuration 5: From the baseline program's best result
    A = [7, 15, 18, 22, -3, -2]
    candidates.append(A)
    
    # Configuration 6: Geometric progression variants
    A = [int(3**i) for i in range(20)]
    candidates.append(A)
    
    # Configuration 7: Mixed structure
    A = []
    for i in range(60):
        if i % 3 == 0:
            A.append(i * 7)
        elif i % 3 == 1:
            A.append(-i * 11)
        else:
            A.append(i * 13 - 5)
    candidates.append(A)
    
    return candidates

def optimize_with_strategy(A, time_budget):
    """Optimize a given starting set with the given time budget."""
    start_time = time.time()
    end_time = start_time + time_budget
    
    # First, try quick improvements
    best_A, best_score = local_optimize(A, end_time)
    
    return best_A, best_score

def solve():
    """Return a list of distinct integers optimizing the ratio."""
    total_time = 115  # Leave some margin
    start_time = time.time()
    deadline = start_time + total_time
    
    # Generate initial candidates
    initial_sets = generate_initial_sets()
    
    # Score all initial candidates quickly
    scored_candidates = []
    for A in initial_sets:
        s = score(A)
        scored_candidates.append((s, A))
    
    # Sort by score, take top ones
    scored_candidates.sort(reverse=True)
    
    # Allocate more time to better candidates
    best_overall_A = None
    best_overall_score = -float('inf')
    
    # Quick optimization for top candidates
    num_to_optimize = min(5, len(scored_candidates))
    time_per_candidate = max(10, (deadline - time.time()) / num_to_optimize)
    
    for i in range(num_to_optimize):
        if time.time() > deadline:
            break
        
        remaining = deadline - time.time()
        budget = min(time_per_candidate, remaining)
        
        A = scored_candidates[i][1]
        optimized_A, opt_score = optimize_with_strategy(A, budget)
        
        if opt_score > best_overall_score:
            best_overall_score = opt_score
            best_overall_A = optimized_A
    
    # If we have time, try to grow the best set
    if best_overall_A is not None and len(best_overall_A) < 4000:
        cur_A = best_overall_A[:]
        cur_score = best_overall_score
        
        while time.time() < deadline and len(cur_A) < 4000:
            # Try to add elements that maintain the structure
            if len(cur_A) >= 4000:
                break
                
            # Generate candidate additions
            best_cand = None
            best_new_score = cur_score
            
            # Sample from difference set and small perturbations
            diffs, sums = compute_sets(cur_A)
            
            for _ in range(100):
                if time.time() > deadline:
                    break
                
                # Try values from various strategies
                r = random.random()
                if r < 0.3:
                    # Small perturbation of existing sum
                    cand = random.choice(list(sums)) + random.randint(-10, 10)
                elif r < 0.6:
                    # Multiple of a difference
                    if diffs:
                        cand = random.choice(list(diffs)) * random.randint(2, 5)
                else:
                    # Random within range
                    cand = random.randint(-10000, 10000)
                
                if cand in cur_A:
                    continue
                
                # Quick estimate
                test_A = cur_A + [cand]
                test_score = score(test_A)
                
                if test_score > best_new_score:
                    best_new_score = test_score
                    best_cand = cand
            
            if best_cand is not None and best_new_score > cur_score:
                cur_A.append(best_cand)
                cur_score = best_new_score
                best_overall_A = cur_A[:]
                best_overall_score = cur_score
            else:
                break  # Can't improve by adding
    
    if best_overall_A is None:
        best_overall_A = [7, 15, 18, 22, -3, -2]
    
    # Ensure all elements are distinct
    best_overall_A = list(set(best_overall_A))
    
    # Final verification
    if len(best_overall_A) > 4000:
        best_overall_A = best_overall_A[:4000]
    
    for x in best_overall_A:
        if abs(x) > 1e15:
            # Rescale if needed
            scale = 1e15 / max(abs(y) for y in best_overall_A)
            best_overall_A = [int(y * scale) for y in best_overall_A]
            break
    
    return best_overall_A
