import math
import random
import time
import itertools
import numpy as np
from scipy.optimize import minimize, differential_evolution, basinhopping

def score_of_set(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def is_sidon(arr):
    """Check if set has all pairwise sums distinct (Sidon property)."""
    s = set()
    for i in range(len(arr)):
        for j in range(i, len(arr)):
            val = arr[i] + arr[j]
            if val in s:
                return False
            s.add(val)
    return True

def make_sidon(n, max_val):
    """Generate a Sidon set of size ~n using greedy algorithm within [0, max_val]."""
    # Simple greedy: add smallest number that doesn't create duplicate sums
    sidon = [0]
    sums_set = {0}
    for _ in range(1, n):
        for candidate in range(sidon[-1] + 1, max_val + 1):
            conflict = False
            # check with all previous elements
            for x in sidon:
                if x + candidate in sums_set:
                    conflict = True
                    break
            if not conflict:
                sidon.append(candidate)
                for x in sidon:
                    sums_set.add(x + candidate)
                break
    return sidon

def random_sidon(n, max_val, attempts=100):
    """Try to get a larger Sidon set by random search with rebuilding."""
    best = make_sidon(n, max_val)
    for _ in range(attempts):
        # Random perturbation: start with small seed and grow
        seed = sorted(random.sample(range(max_val + 1), min(10, max_val)))
        # Make sums set from seed
        sums_set = set()
        for i in range(len(seed)):
            for j in range(i, len(seed)):
                sums_set.add(seed[i] + seed[j])
        current = seed[:]
        for _ in range(len(seed), n):
            found = False
            # try random starts to avoid bias
            for _ in range(max_val):
                cand = random.randint(0, max_val)
                ok = True
                for x in current:
                    if x + cand in sums_set:
                        ok = False
                        break
                if ok:
                    current.append(cand)
                    for x in current:
                        sums_set.add(x + cand)
                    found = True
                    break
            if not found:
                break
        if len(current) > len(best):
            best = current[:]
    return best

def evaluate_config(b, c, shift):
    """
    Given B (excellent small set) and C (Sidon set) and shift (offset between them),
    compute the combined set A = B ∪ (C + shift).
    Returns score, diff size, sum size.
    """
    # Shift C by a large amount to separate from B
    c_shifted = [x + shift for x in c]
    a = b + c_shifted
    return score_of_set(a)

def optimize_shift(b, c, min_shift, max_shift):
    """Find shift that maximizes score using coarse-fine search."""
    best_shift = min_shift
    best_score = -1
    # Coarse grid
    for shift in np.linspace(min_shift, max_shift, 200):
        s = evaluate_config(b, c, int(shift))
        if s > best_score:
            best_score = s
            best_shift = int(shift)
    # Fine tune around best
    for delta in range(-100, 101, 10):
        shift = best_shift + delta
        if shift < min_shift or shift > max_shift:
            continue
        s = evaluate_config(b, c, shift)
        if s > best_score:
            best_score = s
            best_shift = shift
    return best_shift, best_score

def local_search_c(start_c, b, shift, steps=1000):
    """Hill-climb on C (keeping Sidon property) to maximize score with B."""
    c = start_c[:]
    best_c = c[:]
    best_score = evaluate_config(b, c, shift)
    n = len(c)
    max_val_c = max(c) + 100
    # precompute allowed moves: we'll do small perturbations that keep Sidon property
    # Simple hill climbing: try replacing one element with another preserving Sidon
    for _ in range(steps):
        # pick a random element to replace
        idx = random.randrange(n)
        old_val = c[idx]
        # candidate values: try small changes
        found_better = False
        for d in list(range(-5, 6)) + list(range(-50, 51, 10)):
            new_val = old_val + d
            if new_val < 0 or new_val in c:
                continue
            # Check if replacing old_val with new_val preserves Sidon in C
            # We need to check all pairs involving new_val
            ok = True
            for j in range(n):
                if j == idx:
                    continue
                s1 = new_val + c[j]
                # check against all pairs not involving idx
                for k in range(j, n):
                    if k == idx:
                        continue
                    if c[j] + c[k] == s1:
                        ok = False
                        break
                if not ok:
                    break
                # also check if new_val + new_val conflicts with any existing sum (but not with old pairs that included old_val)
            if not ok:
                continue
            # deeper check: compute sums of c after replacement and ensure they are all distinct
            # Since Sidon check can be expensive, we do quick probabilistic check:
            temp_c = c[:]
            temp_c[idx] = new_val
            # quick test: all sums distinct
            sums_set = set()
            sidon_ok = True
            for i in range(n):
                for j in range(i, n):
                    s_val = temp_c[i] + temp_c[j]
                    if s_val in sums_set:
                        sidon_ok = False
                        break
                    sums_set.add(s_val)
                if not sidon_ok:
                    break
            if not sidon_ok:
                continue
            # Now evaluate with B
            new_score = evaluate_config(b, temp_c, shift)
            if new_score > best_score:
                best_score = new_score
                best_c = temp_c[:]
                found_better = True
                # keep c updated? Actually we'll do greedy: accept improvement and break to update c
                c = temp_c[:]
                break
        # If no improvement, keep c as is for next iteration (maybe backtrack later)
        # For simplicity, we just continue with current c
        if not found_better:
            # possible small random restart
            if random.random() < 0.01:
                c = best_c[:]  # revert to best
    return best_c, best_score

def generate_excellent_b(size=5):
    """Generate a small B with high difference-to-sum ratio via random search."""
    # Known good small sets from literature: e.g., {0,1,4,9,11} has many diffs vs sums
    candidates = [
        [0, 1, 4, 9, 11],
        [0, 2, 7, 20, 24],
        [0, 1, 6, 8, 18],
        [0, 1, 4, 13, 28],
        [0, 1, 4, 14, 22],
        [0, 1, 4, 10, 12],
        [0, 2, 5, 12, 14],
        [0, 3, 8, 12, 17],
    ]
    best_b = candidates[0]
    best_r = 0
    for cand in candidates:
        s = set(cand)
        diffs = len({x - y for x in s for y in s})
        sums = len({x + y for x in s for y in s})
        ratio = math.log(diffs) / math.log(sums)
        if ratio > best_r:
            best_r = ratio
            best_b = cand
    return sorted(set(best_b))

def generate_large_c(size, max_val_factor=20):
    """Generate a large Sidon set of given size with elements up to roughly max_val_factor*size^2."""
    # For Sidon sets, max element grows quadratically. Use O(n^2) range.
    max_val = size * size * max_val_factor
    # Try to build a good Sidon set using greedy with some randomness
    c = random_sidon(size, max_val, attempts=200)
    return c

def solve():
    best_A = [7, 15, 18, 22, -3, -2]  # fallback
    best_score = score_of_set(best_A)
    deadline = time.time() + 115  # keep margin

    # We'll try different sizes
    # B small, excellent
    b = generate_excellent_b(5)
    # We'll try multiple C sizes and shifts, then hill-climb
    for size_c in [30, 35, 40, 45, 50, 55, 60, 65, 70]:
        if time.time() > deadline:
            break
        # Generate Sidon set C
        c = random_sidon(size_c, size_c * size_c * 20, attempts=150)
        if len(c) < size_c:
            continue
        # The shift must be large enough so that B and C+shift don't overlap in a way 
        # that reduces differences too much, but not too large to keep numbers small?
        # We'll set shift such that min(C+shift) > max(B) + something.
        # Actually we want interactions to create many diffs. 
        # We'll separate by a distance comparable to spread of C.
        min_c = min(c)
        max_c = max(c)
        spread_c = max_c - min_c
        # We want shift so that C+shift is far enough to not overlap with B in values,
        # but near enough that differences B - C+shift and vice versa are new.
        # We'll experiment with shift starting at max(b) + spread_c + 1 to something larger.
        min_shift = max(b) + 1
        max_shift = max_c + max(b) * 5  # some large but not extreme
        # Optimization of shift
        shift, sc = optimize_shift(b, c, min_shift, max_shift)
        if sc > best_score:
            best_score = sc
            # construct best A
            c_shifted = [x + shift for x in c]
            best_A = list(set(b + c_shifted))
            # Keep sorted
            best_A = sorted(set(best_A))
        
        # Now hill-climb on C with this shift
        c_improved, sc_improved = local_search_c(c, b, shift, steps=3000)
        if sc_improved > best_score:
            best_score = sc_improved
            c_shifted = [x + shift for x in c_improved]
            best_A = sorted(set(b + c_shifted))
        
        # Try also varying shift slightly after improvement
        new_shift, sc_new = optimize_shift(b, c_improved, shift - 1000, shift + 1000)
        if sc_new > best_score:
            best_score = sc_new
            c_shifted = [x + new_shift for x in c_improved]
            best_A = sorted(set(b + c_shifted))
        
        # limit size to 4000
        if len(best_A) > 4000:
            # trim? but unlikely
            best_A = best_A[:4000]
        
    # Final phase: try to locally search on best A directly
    # We'll do small perturbations on A (keeping distinctness) to see if we can improve
    # But careful with time
    cur_A = best_A[:]
    cur_score = best_score
    for _ in range(10000):
        if time.time() > deadline:
            break
        cand = cur_A[:]
        # mutation: change one element slightly
        idx = random.randrange(len(cand))
        old = cand[idx]
        cand[idx] += random.randint(-3, 3)
        # ensure distinct
        if len(set(cand)) < len(cand):
            continue
        s = score_of_set(cand)
        if s > cur_score:
            cur_score = s
            cur_A = cand[:]
            best_A = cur_A[:]
            best_score = s
        elif random.random() < 0.05:
            cur_A = best_A[:]
    return sorted(set(best_A))

if __name__ == "__main__":
    print(solve())
