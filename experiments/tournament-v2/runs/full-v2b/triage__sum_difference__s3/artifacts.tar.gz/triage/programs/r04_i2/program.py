import math
import random
import time

try:
    import numpy as np
except ImportError:
    np = None


def _logratio(mask):
    """mask: boolean numpy array over interval [0, M). Returns log|A-A|/log|A+A| + bonus."""
    idx = np.nonzero(mask)[0]
    n = len(idx)
    if n < 2:
        return -1e9, 0, 0
    # Differences of indices map to integer differences directly (interval spacing 1)
    di = idx[:, None] - idx[None, :]
    si = idx[:, None] + idx[None, :]
    nd = np.unique(di).size
    ns = np.unique(si).size
    if ns < 2 or nd < 2:
        return -1e9, nd, ns
    sc = math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0
    return sc, nd, ns


def _score_list(a):
    s = set(a)
    n = len(s)
    if n < 2:
        return -1e9, 0, 0
    diffs = {x - y for x in s for y in s}
    sums = {x + y for x in s for y in s}
    nd, ns = len(diffs), len(sums)
    if ns < 2 or nd < 2:
        return -1e9, nd, ns
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0, nd, ns


def solve():
    """Continuous relaxation: soft membership over an integer interval, projected gradient
    ascent on the log-ratio, then sample discrete sets and polish with local search."""
    random.seed(12345)
    if np is not None:
        np.random.seed(12345)

    # Candidate constructions to seed / compare.
    best_list = [4, 8, 9, 13, 15, 18, 22, -3, -2, -1, 0, 1]
    best_score, _, _ = _score_list(best_list)

    # A symmetric perturbed construction (symmetric sets often give good ratios).
    def make_symmetric(base):
        b = set(base)
        return sorted(b | {-x for x in b})

    # Try several structured seeds.
    seeds = []
    # 1) Sidon-ish/B_h style set with collisions
    seeds.append([0, 1, 4, 10, 16, 22, 28, 35, 42])
    # 2) arithmetic progression with gaps
    seeds.append([0, 1, 2, 4, 8, 16, 24, 32])
    # 3) near-symmetric set
    seeds.append(make_symmetric([0, 1, 3, 7, 12, 20, 30]))
    # 4) random mask-ish
    seeds.append(sorted(random.sample(range(-40, 41), 20)))

    for sd in seeds:
        sc, _, _ = _score_list(sd)
        if sc > best_score:
            best_score, best_list = sc, sorted(set(sd))

    deadline = time.time() + 100.0

    if np is not None:
        # ---- Continuous relaxation over a bounded interval [lo, hi) ----
        M = 200  # interval length
        offset = -M // 2
        # soft membership probability p in [0,1]^M
        p = np.full(M, 0.5, dtype=float)
        # seed p from best_list
        for v in best_list:
            j = v - offset
            if 0 <= j < M:
                p[j] = 0.95

        def soft_objective(p):
            # differentiable surrogate: expected log difference-count vs sum-count.
            # Approximate |A-A| and |A+A| using soft coverage of each achievable value.
            # diff value d realized by pair (i,j) with i-j=d: prob ~ p_i*p_j
            # Use autocorrelation-like sums.
            pij = np.outer(p, p)
            nd = float(np.sum(pij))
            # For sums, count distinct index-sums weighted by prob.
            # Approximate via entropy to favor spreading / collisions differently.
            # We use: coverage proxy = sum over values of (1 - prod(1 - contributions))
            # Simplified: use number of "active" pairs and penalize sum-value concentration.
            # Heuristic gradient-friendly surrogate:
            idx = np.nonzero(p > 0.5)[0]
            if len(idx) < 2:
                return -1e9
            di = idx[:, None] - idx[None, :]
            si = idx[:, None] + idx[None, :]
            ndv = np.unique(di).size
            nsv = np.unique(si).size
            if nsv < 2 or ndv < 2:
                return -2.0
            return math.log(ndv) / math.log(nsv) + (1.0 - 1.0 / len(idx)) / 100.0

        def local_continuous(p):
            sc = soft_objective(p)
            step = 0.15
            for _ in range(6):
                improved = False
                for j in range(M):
                    for dv in (step, -step):
                        old = p[j]
                        p[j] = min(1.0, max(0.0, p[j] + dv))
                        ns = soft_objective(p)
                        if ns > sc:
                            sc = ns
                            improved = True
                        else:
                            p[j] = old
                if not improved:
                    step *= 0.5
                if step < 0.01:
                    break
            return sc

        # Run continuous local search with restarts, sample discrete from p.
        while time.time() < deadline * 0.85:
            # randomize start
            if random.random() < 0.5:
                p = np.random.rand(M) * 0.3 + (np.random.rand(M) < 0.2) * 0.7
            else:
                p = np.full(M, 0.4)
                for v in best_list:
                    j = v - offset
                    if 0 <= j < M:
                        p[j] = 0.9
                p += (np.random.rand(M) - 0.5) * 0.2
            p = np.clip(p, 0.0, 1.0)

            cs = local_continuous(p)

            # Sample discrete sets from the soft distribution.
            for _ in range(200):
                thr = random.uniform(0.2, 0.8)
                mask = p > thr
                idx = np.nonzero(mask)[0]
                if len(idx) < 2:
                    continue
                cand = sorted(int(j + offset) for j in idx)
                sc, _, _ = _score_list(cand)
                if sc > best_score:
                    best_score, best_list = sc, cand

            # Also do discrete polish on the best sampled candidate.
            cand = sorted(int(j + offset) for j in np.nonzero(p > 0.5)[0])
            if len(cand) >= 2:
                sc = _score_list(cand)[0]
                cur, cur_score = cand[:], sc
                # greedy local search
                t2 = time.time() + 0.4
                while time.time() < t2:
                    nc = cur[:]
                    op = random.random()
                    if op < 0.5 and nc:
                        i = random.randrange(len(nc))
                        nc[i] += random.choice([-3, -2, -1, 1, 2, 3])
                    elif op < 0.8:
                        nc.append(random.randint(offset, offset + M - 1))
                    elif len(nc) > 3:
                        nc.pop(random.randrange(len(nc)))
                    ns, _, _ = _score_list(nc)
                    if ns >= cur_score:
                        cur, cur_score = nc, ns
                        if ns > best_score:
                            best_score = ns
                            best_list = sorted(set(nc))
                if cur_score > best_score:
                    best_score, best_list = cur_score, sorted(set(cur))

    # ---- Final intensive discrete local search (always runs) ----
    cur = best_list[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.6 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
        elif r < 0.8:
            cand.append(random.randint(-60, 60))
        elif r < 0.95 and len(cand) > 2:
            cand.pop(random.randrange(len(cand)))
        else:
            # symmetric expansion
            v = random.randint(1, 50)
            cand.append(v)
            cand.append(-v)
        s, _, _ = _score_list(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best_score = s
                best_list = sorted(set(cand))
        elif random.random() < 0.05:
            cur = best_list[:]
            cur_score = best_score

    res = sorted(set(int(x) for x in best_list))
    # enforce constraints
    res = [x for x in res if abs(x) <= 10**15]
    if len(res) > 4000:
        res = res[:4000]
    if len(res) < 2:
        res = [0, 1]
    return res
