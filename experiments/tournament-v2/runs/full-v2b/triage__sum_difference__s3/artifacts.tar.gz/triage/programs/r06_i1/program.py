# EVOLVE-BLOCK-START
"""Subspace evasive set construction over Z_m with modular pre-image constraints.

Idea: Build A = {x in [0, m) : x mod p_i in S_i for several distinct primes p_i,
plus optionally a structured constraint (e.g. digits, quadratic residues)}. Such sets
have few additive relations (few sums) while retaining many differences.

We also do a final local-search filter to push the ratio up while keeping
|A + A| small (forcing sums into few residue classes).
"""
import math
import random
import time
from itertools import product


def _stats(a):
    a = list(a)
    if len(a) < 2:
        return 0.0, 0, 0
    aset = a
    diffs = set()
    sums = set()
    n = len(aset)
    for i in range(n):
        ai = aset[i]
        for j in range(n):
            diffs.add(ai - aset[j])
            sums.add(ai + aset[j])
    return math.log(len(diffs)) / math.log(len(sums)), len(diffs), len(sums)


def _score(a):
    val, _, _ = _stats(a)
    na = len(set(a))
    if na < 2:
        return 0.0
    return val + (1 - 1 / na) / 100


def _crt_mod_set(m, primes_sets):
    """Return sorted list of x in [0,m) satisfying x % p in S for all (p,S)."""
    residues = list(range(m))
    for p, S in primes_sets:
        S = set(S)
        residues = [r for r in residues if (r % p) in S]
    return residues


def _build_candidate(m, p1, S1, p2, S2, p3, S3):
    """A over Z_m constrained by three prime pre-images, then lifted to integers."""
    primes_sets = [(p1, S1), (p2, S2), (p3, S3)]
    residues = _crt_mod_set(m, primes_sets)
    return residues


def solve():
    random.seed(12345)
    deadline = time.time() + 110

    primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]

    best = None
    best_score = -1.0

    # Range of moduli to try: use products of small primes for rich CRT structure.
    moduli = []
    for m in range(60, 5000):
        # prefer numbers with many small prime factors
        moduli.append(m)
    random.shuffle(moduli)

    # Stage 1: randomized search over modulus + pre-image sizes.
    while time.time() < deadline * 0.6:
        m = random.choice(moduli)
        chosen = random.sample(primes, 3)
        chosen.sort()
        psets = []
        ok = True
        for p in chosen:
            k = random.randint(max(1, p // 3), max(1, p - 1))
            S = random.sample(range(p), min(k, p))
            psets.append((p, S))
        # ensure subset of [0,m) nonempty and not too big
        residues = list(range(m))
        for p, S in psets:
            Sset = set(S)
            residues = [r for r in residues if (r % p) in Sset]
            if len(residues) > 800:
                residues = residues[::1]
        n = len(residues)
        if n < 8 or n > 900:
            continue
        sc = _score(residues)
        if sc > best_score:
            best_score = sc
            best = residues[:]

    # Stage 2: local search / filtering on the best structured set.
    if best is None:
        best = list(range(1, 50))
        best_score = _score(best)

    cur = best[:]
    cur_score = best_score

    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.4 and len(cand) > 2:
            # shift a value
            i = random.randrange(len(cand))
            cand[i] += random.randint(-m // 4 - 1, m // 4 + 1)
        elif op < 0.6 and len(cand) > 3:
            # remove an element
            i = random.randrange(len(cand))
            cand.pop(i)
        elif op < 0.8:
            # add element drawn from a residue class that keeps sums sparse
            cand.append(random.randrange(-m, m))
        else:
            # swap two elements' residues by shifting to reduce sums
            if len(cand) >= 2:
                i, j = random.sample(range(len(cand)), 2)
                cand[i], cand[j] = cand[j], cand[i]

        cand = list(set(cand))
        if len(cand) < 2 or len(cand) > 900:
            continue

        # subsample for speed when large
        if len(cand) > 300:
            sample = random.sample(cand, 300)
            sc_est = _score(sample)
        else:
            sc_est = _score(cand)

        if sc_est >= cur_score:
            cur, cur_score = cand, _score(cand) if len(cand) <= 300 else sc_est
            if cur_score > best_score:
                best_score = cur_score
                best = cand[:]
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score

    best = sorted(set(best))
    if len(best) < 2:
        best = [0, 1]
    # clamp to allowed range
    best = [int(x) for x in best if abs(int(x)) <= 10**15]
    if len(best) < 2:
        best = [0, 1]
    if len(best) > 4000:
        best = best[:4000]
    return best
# EVOLVE-BLOCK-END
