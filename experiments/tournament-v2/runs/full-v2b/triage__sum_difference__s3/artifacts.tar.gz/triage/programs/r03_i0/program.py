import math
import random
import time
from collections import defaultdict

def _set_to_sorted(A):
    return sorted(set(A))

def _compute_diff_sum_counts(A):
    """Return (len_diffs, len_sums) for set A (list of ints)."""
    sA = set(A)
    diffs = set()
    sums = set()
    for x in sA:
        for y in sA:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)

def _score_from_lens(len_diffs, len_sums, n):
    if len_sums == 0 or len_diffs == 0:
        return -1.0
    return math.log(len_diffs) / math.log(len_sums) + (1.0 - 1.0 / n) / 100.0

def _exact_score(A):
    if len(A) < 2:
        return 0.0
    ld, ls = _compute_diff_sum_counts(A)
    return _score_from_lens(ld, ls, len(A))

def _estimate_marginal_gains(A, candidates, sample_size=80, repeats=3):
    """
    Given current set A (list of ints), estimate the change in log-ratio if we add each candidate.
    Uses random sampling of existing elements to approximate the new diffs/sums.
    Returns list of (candidate, estimated_delta_score).
    """
    n = len(A)
    setA = set(A)
    # Precompute current exact counts
    cur_ld, cur_ls = _compute_diff_sum_counts(A)

    # We'll approximate with random samples of existing elements
    # Compute sample diffs/sums from full set? That's expensive. Instead sample pairs.
    # For a candidate x, the new diffs are: (x - y) and (y - x) for y in A, plus existing.
    # We'll estimate how many of those are *new* using a sample of y's.
    sample_indices = random.sample(range(n), min(sample_size, n))
    sample_A = [A[i] for i in sample_indices]
    sample_set = set(sample_A)

    # For existing diffs/sums, we can approximate by the current full set,
    # but we need to know if a candidate's generated diff/sum is already present.
    # We can sample a subset of existing diffs/sums to test membership cheaply,
    # but building full sets is expensive. Better: use a hash set built once per call.

    # Since we call this repeatedly, building full diff/sum sets each time is okay if set size moderate.
    # If A is up to ~4000, diff set can be up to ~4000^2=16M, too large. So sample.
    # We'll estimate new unique diffs/sums from candidate using sampled existing elements.

    estimated_deltas = []
    # Build full diff/sum for sampled elements only? Not accurate.
    # Instead: for each candidate, count how many sample pairs produce new diffs/sums.
    # We'll approximate the proportion of new among all pairs using sample.

    # For diffs: from candidate x, we get 2*n diffs (x-y, y-x) but some may be duplicates.
    # We'll just use sampling: among sampled y's, count new diffs, scale by n/sample_size.

    for cand in candidates:
        new_diff_count = 0
        new_sum_count = 0
        # test with sampled y's
        for y in sample_A:
            d1 = cand - y
            d2 = y - cand
            s1 = cand + y
            # We need to know if d1,d2,s1 are already in the full diff/sum sets.
            # That requires building those sets or another sampling.
            # We'll use a second level sampling: test membership in a random sample of existing diffs/sums.
            # But that's noisy. Instead, we build a small hash set of all diffs/sums from a *random subset* of A
            # (size sample_size) to approximate membership.
            # To reduce variance, we do this for each candidate? Expensive. 
            # Better: precompute sampled diff/sum sets for global use.
        # Actually, we can precompute diff/sum sets from the sampled A:
        sampled_diffs = set()
        sampled_sums = set()
        for i in range(len(sample_A)):
            for j in range(len(sample_A)):
                sampled_diffs.add(sample_A[i] - sample_A[j])
                sampled_sums.add(sample_A[i] + sample_A[j])

        # Now for candidate, check against sampled sets.
        # This gives a noisy estimate but may work for relative ordering.
        for y in sample_A:
            d1 = cand - y
            d2 = y - cand
            s1 = cand + y
            if d1 not in sampled_diffs:
                new_diff_count += 1
            if d2 != d1 and d2 not in sampled_diffs:
                new_diff_count += 1
            if s1 not in sampled_sums:
                new_sum_count += 1

        # Scale by (n / sample_size)
        scale = n / len(sample_A) if sample_A else 1
        est_new_diffs = new_diff_count * scale
        est_new_sums = new_sum_count * scale

        # New set sizes after adding cand
        new_n = n + 1
        new_ld = cur_ld + est_new_diffs
        new_ls = cur_ls + est_new_sums

        # The candidate itself added, new diffs sum to 0? Actually bound.
        old_score = _score_from_lens(cur_ld, cur_ls, n)
        new_score = _score_from_lens(max(1,new_ld), max(1,new_ls), new_n)
        delta = new_score - old_score
        estimated_deltas.append((cand, delta))
    return estimated_deltas

def _greedy_add_phase(A, max_adds=20, sample_size=80):
    """Add elements greedily using estimated marginal gains."""
    cur = list(A)
    setA = set(cur)
    # Generate candidate pool: random small variations around current elements + some random.
    candidates = []
    for _ in range(200):
        x = random.choice(cur) + random.randint(-10, 10)
        if x not in setA:
            candidates.append(x)
    if not candidates:
        return cur
    # Evaluate
    scores = _estimate_marginal_gains(cur, candidates, sample_size)
    # pick top few
    scores.sort(key=lambda x: x[1], reverse=True)
    added = 0
    for cand, delta in scores:
        if delta > 0 and added < max_adds:
            cur.append(cand)
            setA.add(cand)
            added += 1
    return cur

def _greedy_remove_phase(A, max_removes=10):
    """Remove elements that harm least."""
    cur = list(A)
    if len(cur) <= 5:
        return cur
    cur_ld, cur_ls = _compute_diff_sum_counts(cur)
    base_score = _score_from_lens(cur_ld, cur_ls, len(cur))
    # Evaluate each element removal by exact recomputation (since removal is cheaper with O(n^2) for one?)
    # For moderate n (<4000), computing diff/sum set each removal is O(n^2) ~ 16M ops, too slow many times.
    # We'll approximate using sampling.
    removals = []
    n = len(cur)
    sample_indices = random.sample(range(n), min(100, n))
    setA = set(cur)
    # For removal, we could approximate by assuming each element contributes average to diffs/sums.
    # Simpler: sample and estimate.
    # We'll just compute exact for removal candidates? Use sampling to order.
    # Since we only need to pick a few worst, we can approximate and then verify.
    # Here we'll just pick random removals if score improves? Actually we want to drop if score improves.
    # Greedy removal: try each element, compute score if removed exactly (but O(n^3) if done naively).
    # Instead, we randomly try removing a few elements and keep if improves.
    for _ in range(max_removes*5):
        if len(cur) <= 5:
            break
        i = random.randrange(len(cur))
        cand = cur[:i] + cur[i+1:]
        s = _exact_score(cand)
        if s > base_score:
            cur = cand
            base_score = s
    return cur

def _local_search(A, steps):
    cur = list(A)
    best = cur[:]
    best_score = _exact_score(cur)
    for _ in range(steps):
        i = random.randrange(len(cur))
        old_val = cur[i]
        cur[i] += random.randint(-2, 2)
        if cur[i] in cur:
            cur[i] = old_val
        s = _exact_score(cur)
        if s >= best_score:
            best_score = s
            best = cur[:]
        elif random.random() < 0.2:
            cur[i] = old_val
    return best

def solve():
    # Start with a known good configuration (could evolve from scratch, but we start with some set)
    A = [7, 15, 18, 22, -3, -2, 1, 4, 9, 11, -5, 20, 0, 3, 8, 14, -1, 6, 13, 19, 5, 10, 12, 16, 21]
    A = list(set(A))
    random.shuffle(A)
    best = A[:]
    best_score = _exact_score(best)
    
    deadline = time.time() + 115  # leave margin
    iter_count = 0
    while time.time() < deadline:
        # Phase 1: add greedily
        cur = _greedy_add_phase(best, max_adds=15, sample_size=min(100, len(best)))
        # Phase 2: remove some
        cur = _greedy_remove_phase(cur, max_removes=5)
        # Phase 3: local search
        cur = _local_search(cur, steps=200)
        s = _exact_score(cur)
        if s > best_score:
            best = cur[:]
            best_score = s
        # ensure size not exceed 4000
        if len(best) > 4000:
            best = best[:4000]
        iter_count += 1

    return sorted(set(best))
