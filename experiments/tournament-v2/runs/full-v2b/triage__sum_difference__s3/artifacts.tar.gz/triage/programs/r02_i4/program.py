import math
import random
import time


def _sets(a):
    a = list(set(a))
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return diffs, sums


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    d, s = _sets(a)
    if len(s) < 2:
        return 0.0
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / n) / 100


def _marginal_gain(diffs, sums, a_set, x, nd, ns):
    """Exact marginal contribution of adding x: change in |D| and |S|."""
    new_d = 0
    for y in a_set:
        for v in (x - y, y - x, x + y):
            pass
    # compute exact added diff/sum counts
    diff_add = set()
    sum_add = set()
    for y in a_set:
        diff_add.add(x - y)
        diff_add.add(y - x)
        sum_add.add(x + y)
    return len(diff_add - diffs), len(sum_add - sums)


def solve():
    """Dynamically adjust set size: add elements with high diff-gain relative to
    sum-gain, remove elements whose removal reduces sumset more than diffset."""
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    deadline = time.time() + 110

    # Start from a richer seed.
    seeds = [
        [7, 15, 18, 22, -3, -2],
        [0, 1, 3, 7, 12, 20, -5, -11],
        [1, 2, 4, 8, 16, 32, -3, -7, -13],
        [0, 1, 3, 7, 15, 31, 63, -1, -5, -11, -23, -47],
    ]

    cur = None
    cur_score = -1.0
    for s0 in seeds:
        sc = _score(s0)
        if sc > cur_score:
            cur = sorted(set(s0))
            cur_score = sc

    pool = [cur]

    while time.time() < deadline:
        cur = None
        cur_score = -1.0
        for cand in pool:
            sc = _score(cand)
            if sc > cur_score:
                cur = cand
                cur_score = sc
        if cur is None:
            cur = best[:]
            cur_score = best_score

        a = list(set(cur))
        n = len(a)
        diffs, sums = _sets(a)
        nd, ns = len(diffs), len(sums)

        # Try add: evaluate candidate x values.
        # Candidate pool: sums/diffs of existing elements and random offsets.
        candidates = set()
        for x in a:
            for y in a:
                candidates.add(x + y)
                candidates.add(x - y)
                candidates.add(y - x)
        # Some structured growing positions
        mx = max(a); mn = min(a)
        for k in range(1, 30):
            candidates.add(mx + k)
            candidates.add(mn - k)
        for _ in range(40):
            candidates.add(random.randint(mn - 50, mx + 50))
        candidates.discard(0)
        candidates -= set(a)

        # Evaluate best add by score improvement (exact via marginal gains).
        best_add = None
        best_add_score = cur_score
        cand_list = list(candidates)
        random.shuffle(cand_list)
        for x in cand_list[:120]:
            if len(a) + 1 > 4000:
                break
            dd, ds = _marginal_gain(diffs, sums, a, x, nd, ns)
            if dd <= 0:
                continue
            new_n = n + 1
            newD = nd + dd
            newS = ns + ds
            if newS < 2:
                continue
            score = math.log(newD) / math.log(newS) + (1 - 1 / new_n) / 100
            if score > best_add_score:
                best_add_score = score
                best_add = x

        new_a = a[:]
        new_score = cur_score
        if best_add is not None:
            new_a = a + [best_add]
            new_score = best_add_score

        # Try remove: elements whose removal shrinks |S| a lot relative to |D|.
        best_rem = None
        best_rem_score = new_score
        if n > 4:
            order = list(range(len(new_a)))
            random.shuffle(order)
            for idx in order[:60]:
                x = new_a[idx]
                rem = new_a[:idx] + new_a[idx + 1:]
                if len(rem) < 2:
                    continue
                sc = _score(rem)
                if sc > best_rem_score:
                    best_rem_score = sc
                    best_rem = rem

        if best_rem is not None:
            new_a = best_rem
            new_score = best_rem_score

        # Also try small perturbations of coordinates.
        pert = new_a[:]
        if random.random() < 0.7 and pert:
            i = random.randrange(len(pert))
            pert[i] += random.randint(-2, 2)
            pert = list(set(pert))
        pert_score = _score(pert)

        if pert_score > new_score:
            new_a, new_score = pert, pert_score

        if new_score > best_score:
            best = sorted(set(new_a))
            best_score = new_score

        # Update pool with best few.
        pool.append(new_a)
        pool = sorted(pool, key=_score, reverse=True)[:4]

    return sorted(set(best))
