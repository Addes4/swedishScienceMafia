import math
import random
import time


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(len(a)):
        ai = a[i]
        for j in range(len(a)):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100.0


def _build(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return diffs, sums


def solve():
    deadline = time.time() + 110

    # seed
    best = [7, 15, 18, 22, -3, -2]
    best_diffs, best_sums = _build(best)
    best_score = (math.log(len(best_diffs)) / math.log(len(best_sums))
                  + (1 - 1 / len(best)) / 100.0)

    pool_min, pool_max = -60, 60

    a = list(set(best))
    cur_diffs, cur_sums = _build(a)

    # greedy expansion with lazy evaluations
    while time.time() < deadline:
        improved = False
        # candidate pool = integers not in a, within bounded interval
        in_a = set(a)
        pool = [x for x in range(pool_min, pool_max + 1) if x not in in_a]
        if not pool:
            break

        n = len(a)
        base_score = (math.log(len(cur_diffs)) / math.log(len(cur_sums))
                      + (1 - 1 / n) / 100.0)

        # compute incremental gains
        gains = []
        for x in pool:
            new_d = set(cur_diffs)
            new_s = set(cur_sums)
            for ai in a:
                new_d.add(x - ai)
                new_d.add(ai - x)
                new_s.add(x + ai)
            new_d.add(0)
            new_s.add(2 * x)
            nd, ns = len(new_d), len(new_s)
            sc = math.log(nd) / math.log(ns) + (1 - 1 / (n + 1)) / 100.0
            gains.append((sc, x))

        gains.sort(reverse=True)
        # try best candidates
        for sc, x in gains[:8]:
            if sc > best_score:
                a2 = a + [x]
                a2 = list(set(a2))
                d2, s2 = _build(a2)
                sc2 = (math.log(len(d2)) / math.log(len(s2))
                       + (1 - 1 / len(a2)) / 100.0)
                if sc2 > best_score:
                    best = a2[:]
                    best_score = sc2
                    best_diffs, best_sums = d2, s2
                    improved = True
            if time.time() > deadline:
                break

        if improved:
            a = best[:]
            cur_diffs, cur_sums = best_diffs, best_sums
            pool_min -= 5
            pool_max += 5
        else:
            # local perturbation to escape
            if len(a) < 200:
                x = random.randint(pool_min, pool_max)
                a2 = list(set(a + [x]))
            else:
                break
            d2, s2 = _build(a2)
            sc2 = (math.log(len(d2)) / math.log(len(s2))
                   + (1 - 1 / len(a2)) / 100.0) if len(a2) >= 2 else 0.0
            if sc2 > best_score:
                best = a2[:]
                best_score = sc2
                best_diffs, best_sums = d2, s2
                a = best[:]
                cur_diffs, cur_sums = best_diffs, best_sums
            else:
                break

    return sorted(set(best))
