import math
import random
import time

def _score(A):
    A = set(A)
    n = len(A)
    if n < 2:
        return 0.0
    diffs = {x - y for x in A for y in A}
    sums = {x + y for x in A for y in A}
    return math.log(len(diffs) / len(sums)) + (1 - 1 / n) / 100

def is_valid(A):
    return len(A) == len(set(A)) and all(x == int(x) for x in A)

def solve():
    """Use differential evolution to maximize log|A - A| / log|A + A|."""
    random.seed(42)
    deadline = time.time() + 120
    
    # Start with a structured base set using geometric progression
    base = [1]
    for i in range(8):
        base.append(base[-1] * 3 + i + 1)
    
    # Initialize population of candidate sets
    pop_size = 30
    dim = len(base)
    
    # Generate initial population with small perturbations
    X = []
    for i in range(pop_size):
        pop = []
        for j in range(dim):
            val = base[j] + random.randint(-3, 3)
            if val > 2000 or val < -2000:
                val = base[j] + random.randint(-5, 5)
            pop.append(float(val))
        X.append(pop)
    
    # Random scramble as initial step size
    F = 0.7
    C = 2  # constraint for small perturbation to avoid duplicates early
    
    best_solution = sorted(list(base))
    best_score = _score(best_solution)
    
    n_elite = pop_size // 4
    
    while time.time() < deadline:
        X_new = []
        
        Sort_indices = sorted(range(len(X)), key=lambda i: _score(list(set(round(v) for v in X[i])) if is_valid([round(v) for v in X[i]]) else []))
        
        # Get current elite set
        elite_size = min(n_elite, len(Sort_indices))
        elite_indices = Sort_indices[:elite_size]
        
        for i in range(pop_size):
            if random.random() < 0.1:  # Keep some without mutation
                candidate = X[i][:]
            else:
                # Mutation: differential evolution style
                m1 = random.choice(elite_indices)
                m2 = random.choice(elite_indices)
                if m1 == m2:
                    m2 = random.choice(elite_indices)
                    
                target = X[m1][:]
                
                for dim_idx in range(len(target)):
                    delta = X[m1][dim_idx] - X[m2][dim_idx]
                    perturbation = F * delta + random.uniform(-0.5, 0.5) * C
                    target[dim_idx] = float(target[dim_idx]) + perturbation
                
                candidate = target
            
            # Round to integers and remove duplicates
            try:
                ints = [int(round(x)) for x in candidate]
                if len(set(ints)) == len(ints):
                    scores = [is_valid([round(v) for v in candidate]) and 1.0 
                             else 0.0 for candidate in candidate]
                    X_new.append(ints)
                else:
                    candidate = X[i][:]
                    X_new.append(list(candidate))
            except:
                candidate = X[i][:]
                X_new.append(list(candidate))
        
        X = []
        for cand in X_new:
            if all(float(x) == int(x) for x in cand):
                X.append([float(x) for x in cand])
            else:
                X.append(X[-2][:])
        
        # Keep best
        for i in range(pop_size):
            if i < len(X):
                A = [int(round(v)) for v in X[i]]
                s = _score(A)
                A_int = set(A)
                if s > best_score:
                    best_solution = sorted(list(A_int))
                    best_score = s
        
        if len(X) < 10:
            break
    
    return best_solution

# For verification and final output
if __name__ == "__main__":
    result = solve()
    print(f"Found {len(result)} elements: {result}")
    if len(result) >= 2:
        diffs = {x - y for x in result for y in result}
        sums = {x + y for x in result for y in result}
        ratio = math.log(len(diffs)) / math.log(len(sums))
        print(f"Score: {ratio:.6f}")
        print(f"Diff set size: {len(diffs)}, Sum set size: {len(sums)}")
    else:
        print("Invalid solution")
