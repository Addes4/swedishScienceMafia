import math
import random
import time

def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a}
    sums = {x + y for x in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100

def solve():
    # Initial set using a construction known to perform well
    initial = [7, 15, 18, 22, -3, -2]
    best = initial[:]
    best_score = _score(best)
    cur = best[:]
    
    # Simulated annealing parameters
    temp = 1000.0
    cooling_rate = 0.9995
    min_temp = 0.1
    
    deadline = time.time() + 115
    
    while temp > min_temp and time.time() < deadline:
        # Generate a candidate by perturbing a random element
        cand = cur[:]
        i = random.randrange(len(cand))
        change = random.randint(-20, 20)
        cand[i] += change
        if cand[i] in cur and i != cand.index(cand[i]):
            # If new value conflicts, pick a completely new value
            cand[i] = random.randint(1, 1000)
        elif cand[i] in cur:
            cand[i] += 1 + random.randint(0, 50)
        
        # Sometimes try insertion or deletion
        if random.random() < 0.1 and len(cand) < 3000:
            cand.append(random.randint(1, 2000))
        if random.random() < 0.05 and len(cand) >= 7:
            cand = cand[:-1]
        cand = list(set(cand))
        if len(cand) < 2:
            cand = cur[:]
            continue
        
        ns = _score(cand)
        
        # Accept with Metropolis-Hastings probability
        if ns >= best_score:
            cand.sort()
            if time.time() > deadline or not cand:
                return cand
            cur = cand[:]
            best, best_score = cand[:], ns
            if best_score > best_score:
                best = cand[:]
                best_score = ns
        else:
            delta = ns - best_score
            if random.random() < math.exp(delta / temp):
                cand.sort()
                if time.time() > deadline or not cand:
                    return cand
                cur = cand[:]
        
        # Cool down
        temp *= cooling_rate
    
    # Final local search
    for _ in range(500):
        cand = cur[:]
        i = random.randrange(len(cand))
        if len(cand) < 3000:
            cand.append(random.randint(1, 2000))
        if len(cand) > 300 and random.random() < 0.3:
            cand = cand[:len(cand) - 1]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        ns = _score(cand)
        if ns >= best_score:
            cand.sort()
            cur = cand[:]
    
    cur.sort()
    return cur

def main():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    cur = best[:]
    temp = 1000.0
    cooling_rate = 0.9996
    min_temp = 0.01
    deadline = time.time() + 115
    while temp > min_temp and time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        change = random.randint(-50, 50)
        cand[i] += change
        if len(cand) < 3000:
            cand.append(random.randint(1, 2000))
        if len(cand) > 300 and random.random() < 0.3:
            cand = cand[:len(cand) - 1]
        cand = list(set(cand))
        if len(cand) < 2:
            cand = cur[:]
            continue
        ns = _score(cand)
        if ns > best_score:
            best_score = ns
            best = cand[:]
            cur = cand[:]
        elif ns > best_score * 0.9999 and random.random() < math.exp((ns - best_score) / temp):
            cur = cand[:]
        temp *= cooling_rate
    cur.sort()
    return cur

if __name__ == "__main__":
    A = solve()
    print(A)
