# EVOLVE-BLOCK-START
"""Structured search: sets inside small intervals / arithmetic progressions.

Idea: the best known constructions for many-differences/few-sums live in small
ranges.  We search systematically over sets drawn from a short interval [0, m]
(equivalently an AP), plus unions of a couple of intervals, using a fast
bitset-based evaluation and hill climbing / exhaustive local moves.
"""

import math
import random
import time


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100.0


# ---------- fast evaluation using bitmasks ----------

def _eval_mask(mask, offset=0):
    """Given a bitmask of chosen integers (bit i => offset+i in set),
    return (n, |A-A|, |A+A|)."""
    if mask == 0:
        return 0, 0, 0
    # extract element list
    elems = []
    m = mask
    while m:
        b = m & -m
        elems.append(b.bit_length() - 1 + offset)
        m ^= b
    n = len(elems)
    # differences via shifting
    diffs = 0
    for e in elems:
        diffs |= (mask >> e) if e >= 0 else 0
        # simpler: use direct set for correctness
    # Fallback: direct computation is fine for small sets
    dset = set()
    sset = set()
    for x in elems:
        for y in elems:
            dset.add(x - y)
            sset.add(x + y)
    return n, len(dset), len(sset)


def _eval_list(elems):
    n = len(elems)
    if n < 2:
        return 0.0, 0, 0
    dset = set()
    sset = set()
    for x in elems:
        for y in elems:
            dset.add(x - y)
            sset.add(x + y)
    return None, len(dset), len(sset)


def solve():
    """Maximise log|A-A|/log|A+A| using structured constructions."""
    deadline = time.time() + 100
    rng = random.Random(12345)

    best_a = [0, 1, 3, 7]
    best_score = -1.0

    def try_set(a):
        nonlocal best_a, best_score
        a = sorted(set(a))
        if len(a) < 2:
            return
        d = set()
        s = set()
        for x in a:
            for y in a:
                d.add(x - y)
                s.add(x + y)
        if len(s) <= 1:
            return
        sc = math.log(len(d)) / math.log(len(s)) + (1 - 1 / len(a)) / 100.0
        if sc > best_score:
            best_score = sc
            best_a = a[:]

    # ---- Try small dense intervals [0, m] with selected subsets ----
    # Exhaustive over subsets for very small m is too big; do randomized
    # restart hill-climb restricted to [0, m].
    for m in [6, 7, 8, 9, 10, 11, 12, 13, 14, 16, 18, 20, 24, 30]:
        universe = list(range(0, m + 1))
        # initial: random subset of size ~ sqrt-ish
        for restart in range(40):
            if time.time() > deadline:
                return best_a
            k = rng.randint(2, len(universe))
            cur = sorted(rng.sample(universe, k))
            cur_sc = _score(cur)
            improved = True
            while improved and time.time() < deadline:
                improved = False
                # try adds / removes / single shifts within interval
                for idx in range(len(cur)):
                    for delta in (-1, 1):
                        cand = cur[:]
                        cand[idx] += delta
                        if cand[idx] < 0 or cand[idx] > m:
                            continue
                        cand = sorted(set(cand))
                        if len(cand) < 2:
                            continue
                        sc = _score(cand)
                        if sc > cur_sc:
                            cur, cur_sc = cand, sc
                            improved = True
                # try remove
                for idx in range(len(cur)):
                    cand = cur[:idx] + cur[idx + 1:]
                    if len(cand) < 2:
                        continue
                    sc = _score(cand)
                    if sc > cur_sc:
                        cur, cur_sc = cand, sc
                        improved = True
                # try add unused
                used = set(cur)
                for v in universe:
                    if v in used:
                        continue
                    cand = sorted(cur + [v])
                    sc = _score(cand)
                    if sc > cur_sc:
                        cur, cur_sc = cand, sc
                        improved = True
            try_set(cur)

    # ---- Two intervals union ----
    for _ in range(400):
        if time.time() > deadline:
            return best_a
        a = rng.randint(2, 8)
        b = rng.randint(2, 8)
        base1 = 0
        base2 = rng.randint(10, 40)
        s1 = sorted(rng.sample(range(0, a + 2), min(a, a + 2)))
        s2 = sorted(rng.sample(range(0, b + 2), min(b, b + 2)))
        cur = sorted(set(s1 + [base2 + v for v in s2]))
        cur_sc = _score(cur)
        improved = True
        while improved and time.time() < deadline:
            improved = False
            for idx in range(len(cur)):
                for delta in (-2, -1, 1, 2):
                    cand = cur[:]
                    cand[idx] += delta
                    cand = sorted(set(cand))
                    if len(cand) < 2 or len(cand) > 40:
                        continue
                    sc = _score(cand)
                    if sc > cur_sc:
                        cur, cur_sc = cand, sc
                        improved = True
            for idx in range(len(cur)):
                cand = cur[:idx] + cur[idx + 1:]
                if len(cand) < 2:
                    continue
                sc = _score(cand)
                if sc > cur_sc:
                    cur, cur_sc = cand, sc
                    improved = True
        try_set(cur)

    # ---- AP-based structured sets: {0, d, 2d, ..., } plus a few extras ----
    for d in range(1, 12):
        for k in range(2, 25):
            if time.time() > deadline:
                return best_a
            base = [i * d for i in range(k)]
            try_set(base)
            # tweak a few elements
            for _ in range(20):
                cand = base[:]
                for _ in range(rng.randint(1, 3)):
                    j = rng.randrange(len(cand))
                    cand[j] += rng.randint(-2, 2)
                try_set(sorted(set(cand)))

    # ---- final polish on best ----
    cur = best_a[:]
    cur_sc = best_score
    while time.time() < deadline:
        improved = False
        for idx in range(len(cur)):
            for delta in (-1, 1, -2, 2, -3, 3):
                cand = cur[:]
                cand[idx] += delta
                cand = sorted(set(cand))
                if len(cand) < 2 or len(cand) > 60:
                    continue
                sc = _score(cand)
                if sc > cur_sc:
                    cur, cur_sc = cand, sc
                    improved = True
        for idx in range(len(cur)):
            cand = cur[:idx] + cur[idx + 1:]
            if len(cand) < 2:
                continue
            sc = _score(cand)
            if sc > cur_sc:
                cur, cur_sc = cand, sc
                improved = True
        used = set(cur)
        for _ in range(15):
            v = rng.randint(-5, max(cur) + 5) if cur else 0
            if v in used:
                continue
            cand = sorted(cur + [v])
            sc = _score(cand)
            if sc > cur_sc:
                cur, cur_sc = cand, sc
                improved = True
        if not improved:
            break
        try_set(cur)

    return best_a


if __name__ == "__main__":
    res = solve()
    print(sorted(res))
    print(_score(res))
# EVOLVE-BLOCK-END
