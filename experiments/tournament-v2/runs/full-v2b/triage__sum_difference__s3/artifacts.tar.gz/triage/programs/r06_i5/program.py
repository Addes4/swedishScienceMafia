import math
import random
import itertools
import time
import numpy as np

def evaluate_from_orbits(N, multiplier, shifts, starts, lengths):
    """Build A from concatenated orbits of the map x -> (multiplier * x + shift) % N.
    Each orbit starts at starts[k], runs for lengths[k] steps, and is offset by offset_base[k] * N
    to keep blocks far apart.
    """
    # Place orbits far apart to avoid cross-orbit cancellations messing up sum structure
    offset_base = list(range(0, 20000 * len(starts), 20000))  # large enough spacing
    A = set()
    for off, s, shift, L in zip(offset_base, starts, shifts, lengths):
        x = s % N
        for _ in range(L):
            val = off * N + x
            A.add(val)
            x = (multiplier * x + shift) % N

    if len(A) < 2:
        return 0.0, set()

    # Fast difference and sum computation using numpy for moderate sizes
    lst = list(A)
    arr = np.array(lst, dtype=np.int64)
    # differences
    diffs = set()
    # Do in blocks if too large, but here max len ~ 2000 is fine
    for x in arr:
        diffs.update((x - arr).tolist())
    # sums
    sums = set()
    for x in arr:
        sums.update((x + arr).tolist())

    score = math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / len(A)) / 100.0
    return score, A

def mutate_params(params):
    """params = (N, multiplier, shifts_list, starts_list, lengths_list)"""
    N, mult, shifts, starts, lengths = params
    # small changes to N (keep odd? preferable for multiplier coprime)
    if random.random() < 0.2:
        N = N + random.choice([-2, -1, 0, 1, 2])
        N = max(50, min(2000, N))
        if N % 2 == 0:
            N += 1  # keep odd to allow multiplier with large order
    # change multiplier
    if random.random() < 0.3:
        mult = (mult + random.randint(-5, 5)) % N
        # ensure multiplier is coprime to N for full orbit lengths
        while math.gcd(mult, N) != 1 and mult != 0:
            mult = (mult + random.choice([-1, 1])) % N
        if mult == 0:
            mult = 1
    # change shifts
    for i in range(len(shifts)):
        if random.random() < 0.3:
            shifts[i] = (shifts[i] + random.randint(-3, 3)) % N
    # change starts
    for i in range(len(starts)):
        if random.random() < 0.3:
            starts[i] = (starts[i] + random.randint(-10, 10)) % N
    # change lengths
    for i in range(len(lengths)):
        if random.random() < 0.3:
            lengths[i] = max(2, lengths[i] + random.choice([-1, 0, 1]))
            lengths[i] = min(200, lengths[i])  # keep orbits moderate

    # occasionally add a new orbit
    if random.random() < 0.1 and len(shifts) < 12:
        shifts.append(random.randint(0, N-1))
        starts.append(random.randint(0, N-1))
        lengths.append(random.randint(4, 30))
    # remove orbit if too many
    if random.random() < 0.05 and len(shifts) > 2:
        idx = random.randrange(len(shifts))
        shifts.pop(idx)
        starts.pop(idx)
        lengths.pop(idx)

    return (N, mult, shifts, starts, lengths)

def solve():
    """Generate A as concatenation of orbits of affine map mod N, tune parameters via EA."""
    random.seed(42)
    np.random.seed(42)

    # Initial candidate parameters (designed to give many differences & few sums)
    N = 307  # a prime, odd
    multiplier = 17   # high order mod N
    shifts = [3, 43, 89, 121, 200, 250]
    starts = [1, 50, 100, 150, 200, 250]
    lengths = [12, 10, 11, 9, 10, 8]
    
    best_params = (N, multiplier, shifts[:], starts[:], lengths[:])
    best_score, best_set = evaluate_from_orbits(*best_params)
    print(f"Initial score: {best_score:.6f}, size: {len(best_set)}")

    deadline = time.time() + 115  # allow some margin
    iterations = 0
    temp = 0.02  # small chance of accepting worse solutions for exploration

    while time.time() < deadline:
        iterations += 1
        cand_params = mutate_params(best_params)
        score, cand_set = evaluate_from_orbits(*cand_params)
        if score >= best_score or random.random() < temp:
            if score > best_score:
                best_score = score
                best_set = cand_set
                best_params = cand_params
                print(f"Iter {iterations}: new best score {best_score:.6f}, size {len(best_set)}")
            else:
                # accept worse with small prob
                best_params = cand_params  # move in parameter space
        # occasionally restart to avoid local optima
        if random.random() < 0.002:
            # partial restart around current best
            N = best_params[0]
            mult = best_params[1]
            new_shifts = [(s + random.randint(-5,5)) % N for s in best_params[2]]
            new_starts = [(s + random.randint(-10,10)) % N for s in best_params[3]]
            new_lengths = [max(2, l + random.choice([-1,0,1])) for l in best_params[4]]
            best_params = (N, mult, new_shifts, new_starts, new_lengths)

    # final result: list of integers from best set, sorted, max 4000 elements
    final_list = sorted(best_set)
    if len(final_list) > 4000:
        # trim randomly? but EA should keep it below. If not, take first 4000 (suboptimal but safe)
        final_list = final_list[:4000]
    return final_list

if __name__ == "__main__":
    result = solve()
    # quick validation
    print(f"Returned list length: {len(result)}")
