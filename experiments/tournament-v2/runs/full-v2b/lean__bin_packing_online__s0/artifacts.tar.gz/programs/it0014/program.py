# EVOLVE-BLOCK-START
"""Best fit with a small consolidation incentive to avoid opening new bins for small items."""
import numpy as np

_mean = 40.0
_seen = 0

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _seen
    _seen += 1
    # base: prefer tightest fit (smallest residual)
    residual = bins - item
    score = -residual.astype(np.float64)
    # consolidation: slightly reward using an already-used bin (not capacity 100)
    used = bins < 100
    # bonus grows with item size so small items strongly consolidate, large items still open bins
    bonus = (item / 100.0) * 100.0 * used
    score += bonus * 0.5
    return score
# EVOLVE-BLOCK-END
