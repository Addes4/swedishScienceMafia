# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight best-fit with closeability.

Primary signal is best-fit: place the item so the smallest residual remains,
concentrating gaps into tight, reuse-able units.  A strong exact-fill bonus
immediately wins when a residual is zero.  A histogram-based bonus rewards
residuals equal to a frequently-seen item size, since those are likely to be
filled exactly by a future item.  Empty bins are kept slightly less attractive
so they stay free for large items.
"""
import numpy as np

SMALL = 20.0

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit -> prefer smallest residual (tightest packing).
    score = -residual.astype(np.float64)

    # Exact fill: no waste at all, always wins.
    score += np.where(residual == 0, 1e6, 0.0)

    # Histogram bonus: residual matches a frequent past item size -> likely
    # to be closed exactly by a future item.
    if _COUNT > 50:
        prob = _HIST / _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        score += 1000.0 * prob[ri]

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 0.5, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
