# EVOLVE-BLOCK-START
"""Online bin-choice rule: normalized best-fit with reusable-gap awareness.

Prefer the bin where the item fits most tightly relative to that bin's
remaining space, so partial bins keep getting topped up and gaps concentrate.
A strong exact-fill bonus dominates; a small penalty discourages leaving
slivers too small to hold any future item; and empty bins are slightly
devalued so they stay available for large arrivals.
"""
import numpy as np

SMALL = 20.0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    bins_f = bins.astype(np.float64)
    res_f = residual.astype(np.float64)

    # Normalized best fit: reward a large item relative to the bin's space.
    fit = item / np.maximum(bins_f, 1.0)
    score = 100.0 * fit

    # Still reward small absolute residual (tight packing).
    score -= 0.5 * np.clip(res_f, 0.0, 100.0)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 20.0, 0.0)

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 3.0, 0.0)

    return score
# EVOLVE-BLOCK-END

