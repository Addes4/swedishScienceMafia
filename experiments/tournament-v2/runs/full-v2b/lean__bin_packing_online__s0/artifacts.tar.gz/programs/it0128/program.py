# EVOLVE-BLOCK-START
"""Online bin-choice rule: best-fit with slight empty-bin preference.

Pure best-fit (smallest residual) concentrates gaps, which empirically packs
well for Weibull-distributed sizes.  A strong exact-fill bonus captures the
rare perfect closures, and a mild penalty on lifeless slivers avoids wasting
a bin on an unusable remainder.  Empty bins are slightly penalized so they
stay available for large items.
"""
import numpy as np


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit -> prefer smallest residual (tightest packing).
    score = -residual.astype(np.float64)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < 15)
    score -= np.where(sliver, 40.0, 0.0)

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 3.0, 0.0)

    return score
# EVOLVE-BLOCK-END
