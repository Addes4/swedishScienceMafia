# EVOLVE-BLOCK-START
"""Online bin-choice rule: best-fit with modular closeability.

Items arrive with a Weibull-shaped size distribution (mean ~40).  The best
way to concentrate gaps into reusable, closeable units is to prefer placing
the current item so that the resulting residual is close to a multiple of the
typical item size -- i.e., a residual that a whole number of future items can
fill exactly.  Combined with a strong exact-fill bonus and residual-size
heuristics (no useless slivers), this packs bins near to capacity.
"""
import numpy as np

# Typical future item size (distribution mean ~40).
TYP = 40.0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item
    r = residual.astype(np.float64)

    # Strong exact fill: perfect.
    score = np.where(residual == 0, 1000.0, 0.0)

    # Modular closeability: reward residuals close to a multiple of TYP.
    # distance to nearest multiple of TYP (clipped residual).
    rc = np.clip(r, 0.0, 100.0)
    m = rc / TYP
    dist = np.abs(m - np.round(m)) * TYP  # distance to nearest multiple
    score += np.where(residual > 0, 20.0 - 0.5 * dist, 0.0)

    # Best-fit tie-breaker: prefer smaller residual (concentrate gaps).
    score -= 0.5 * np.clip(r, 0.0, 100.0)

    # Penalize useless slivers (residual too small to host a small item).
    sliver = (residual > 0) & (residual < 12)
    score -= np.where(sliver, 25.0, 0.0)

    # Mildly prefer already-used bins to keep empty bins free for large items.
    score += np.where(bins < 100, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END

