# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  Two usability tiers (small and typical) let the
rule favor gaps that remain broadly reusable across the size distribution.
A deterministic prior over the size distribution gives a small secondary
nudge toward residuals likely to be filled exactly later, without swamping
the best-fit ordering.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0

# Deterministic prior over item sizes (Weibull-shaped, mean ~40).
# Used only as a mild, bounded secondary signal.
_SIZES = np.arange(101, dtype=np.float64)
# Approximate Weibull(shape~1.5, scale~44) pmf-like weight.
_sh = 1.5
_sc = 44.0
_PRIOR = (_sh / _sc) * (_SIZES / _sc) ** (_sh - 1.0) * np.exp(-(_SIZES / _sc) ** _sh)
_PRIOR[0] = 0.0
_PRIOR = _PRIOR / _PRIOR.sum()

# Gaussian smoothing over +-8 offsets.
_OFFS = np.arange(-8, 9)
_W = np.exp(-(_OFFS.astype(np.float64) ** 2) / (2.0 * 3.0 ** 2))


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    r = np.clip(residual.astype(np.float64), 0.0, None)
    score = -np.sqrt(r)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    small_ok = residual >= SMALL
    score += np.where(small_ok, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Mild prior-based bonus: residuals likely to be exactly filled later.
    ri = np.clip(residual, 0, 100).astype(np.int64)
    smoothed = np.zeros_like(r)
    for off, wt in zip(_OFFS, _W):
        idx = np.clip(ri + off, 0, 100)
        smoothed += wt * _PRIOR[idx]
    peak = smoothed.max()
    if peak > 0:
        smoothed = smoothed / peak
    score += 8.0 * smoothed

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
