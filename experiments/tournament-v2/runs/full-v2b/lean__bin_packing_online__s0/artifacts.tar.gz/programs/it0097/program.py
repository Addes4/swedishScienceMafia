# EVOLVE-BLOCK-START
"""Online bin-choice rule: score residuals by empirical future-fill likelihood.

We keep a small running sample of past item sizes.  After hypothetically placing
the item in a bin, the leftover residual is either 0 (perfect, wonderful) or
positive.  A positive residual is useful only if some future item can fit into
it.  We estimate the probability that the next item fits in the residual using
the empirical distribution seen so far, and reward residuals accordingly, while
keeping a mild best-fit tendency and gently preferring already-used bins.
"""
import numpy as np

_SIZES = []          # running sample of past item sizes
_MAXSAMPLE = 512
_CAP = 100


def _fit_prob(residual, item):
    """Estimate probability a future item fits in `residual`."""
    r = residual
    # exact fill is always great
    p = np.where(r == 0, 1.0, 0.0)
    # empirical fraction of past items that would fit
    if len(_SIZES) >= 8:
        arr = np.array(_SIZES[-_MAXSAMPLE:], dtype=np.float64)
        # fraction of sampled sizes <= residual
        # sort once per call for speed
        s = np.sort(arr)
        frac = np.searchsorted(s, r, side='right') / s.size
        p = np.where(r > 0, frac, p)
    return p


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item

    score = -residual.astype(np.float64)

    # reward residuals likely to be filled by a future item
    fitp = _fit_prob(residual, item)
    score += 40.0 * fitp

    # strong bonus for exact fill
    score += np.where(residual == 0, 200.0, 0.0)

    # penalty for slivers no observed item can fit (already covered by fitp,
    # but add a small extra nudge against tiny positive residuals)
    score -= np.where((residual > 0) & (residual < 15), 8.0, 0.0)

    # gently prefer already-used bins
    score += np.where(bins < _CAP, 2.0, 0.0)

    _SIZES.append(int(item))
    if len(_SIZES) > 4 * _MAXSAMPLE:
        del _SIZES[:2 * _MAXSAMPLE]

    return score
# EVOLVE-BLOCK-END
