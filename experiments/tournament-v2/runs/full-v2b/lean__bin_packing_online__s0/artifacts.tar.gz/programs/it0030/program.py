# EVOLVE-BLOCK-START
"""Best fit with a residual-usability tie-break: minimize leftover, but avoid slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer tighter fits (smaller residual).
    # Tie-break: prefer residual == 0, then residual >= item (still usable), then larger residual.
    score = -residual.astype(np.float64)
    # bonus for exact fill
    score = score + 1e-3 * (residual == 0)
    # bonus for residual that can still hold a same-sized item
    score = score + 1e-4 * (residual >= item)
    return score
# EVOLVE-BLOCK-END
