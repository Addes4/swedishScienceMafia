# EVOLVE-BLOCK-START
"""Best fit that penalizes stranding small slivers in otherwise-usable bins."""
import numpy as np


def priority(item, bins):
    """Priority for every bin; highest score wins, ties go to the earliest bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 remaining capacities (item fits in each), unused bins have 100.
    """
    residual = (bins - item).astype(np.float64)
    # Best fit: prefer smallest residual.
    scores = -residual
    # Penalize residuals that are small but nonzero (hard-to-use slivers),
    # where the bin is nearly full. Slivers below ~15 waste a usable bin.
    sliver = (residual > 0) & (residual < 15.0)
    scores[sliver] -= (15.0 - residual[sliver]) * 0.5
    # Exact fills are always best.
    scores[residual == 0] += 50.0
    return scores
# EVOLVE-BLOCK-END
