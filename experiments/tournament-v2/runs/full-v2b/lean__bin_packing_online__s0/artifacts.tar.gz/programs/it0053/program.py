# EVOLVE-BLOCK-START
"""Adaptive best fit with a guarded preference against tiny unusable slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    # post-placement residual for every fitting bin
    residual = bins - item

    # Base score: best fit (prefer smallest residual). Higher score wins.
    score = -residual.astype(np.float64)

    # Identify empty bins (residual == 100) which we can use as fallback.
    empty = (bins == 100)

    # Running estimate of a small item size: approximate via the minimum residual
    # that is still non-zero among non-empty bins; fall back to 1.
    nonempty = ~empty
    if np.any(nonempty):
        res_ne = residual[nonempty]
        pos = res_ne[res_ne > 0]
        small_est = int(np.min(pos)) if pos.size > 0 else 1
    else:
        small_est = 1

    # If the tightest non-empty placement would create a sliver smaller than
    # small_est (and can't hold anything), and an empty bin exists, prefer the
    # empty bin by giving it a slightly higher score than the sliver.
    best_nonempty = None
    if np.any(nonempty):
        best_nonempty = int(np.min(residual[nonempty]))

    if best_nonempty is not None and 0 < best_nonempty < small_est and np.any(empty):
        # boost empty bins just above the best-so-far tightest placement
        score[empty] = score[empty] + 1e-3

    return score
# EVOLVE-BLOCK-END
