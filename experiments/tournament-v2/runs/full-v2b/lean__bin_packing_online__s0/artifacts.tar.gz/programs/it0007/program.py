# EVOLVE-BLOCK-START
"""Best-fit with a mild preference to fill existing bins over opening new ones."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # remaining capacity after placing the item
    # Base: best-fit (smallest residual) is strongest.
    score = -residual.astype(np.float64)
    # Slight bonus for used (non-empty) bins to discourage opening new bins.
    used = bins < 100
    score += 0.5 * used
    # Extra bonus for near-perfect fits to keep tight packing dominant.
    score += 0.25 * (residual < item)
    return score
# EVOLVE-BLOCK-END
