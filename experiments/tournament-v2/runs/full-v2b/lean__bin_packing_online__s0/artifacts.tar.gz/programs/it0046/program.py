# EVOLVE-BLOCK-START
"""Best fit with sliver avoidance: prefer best fit, but avoid residuals too small to fit common items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # residual >= 0 by construction (only fitting bins are shown)
    # Sliver threshold: residuals in [1, TH-1] are often unusable for typical future items.
    TH = 6
    is_sliver = (residual > 0) & (residual < TH)
    # Base score: best fit (smaller residual -> higher score)
    score = -residual.astype(np.float64)
    # Penalize sliver residuals so a usable alternative is preferred when available.
    score = np.where(is_sliver, score - 1000.0, score)
    return score
