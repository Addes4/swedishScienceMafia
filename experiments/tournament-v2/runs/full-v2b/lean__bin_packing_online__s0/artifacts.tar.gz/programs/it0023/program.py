# EVOLVE-BLOCK-START
"""Best-fit, but flip to worst-fit among sliver residuals (below running mean)."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    # Update running mean of item sizes (state persists between calls).
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    resid = bins - item  # residual after placement, >= 0

    # Best fit normally: smaller residual => higher score.
    # But residuals below the running mean are likely stranded slivers; among
    # those prefer the *larger* residual so the leftover stays reusable.
    score = -resid.astype(np.float64)
    sliver = resid < mean
    score[sliver] = resid[sliver].astype(np.float64)  # reward larger slivers

    return score
# EVOLVE-BLOCK-END
