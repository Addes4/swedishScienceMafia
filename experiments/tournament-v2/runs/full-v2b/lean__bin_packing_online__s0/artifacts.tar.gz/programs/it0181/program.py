# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  Two usability tiers (small and typical) let the
rule favor gaps that remain broadly reusable across the size distribution.
A synthetic Weibull-shaped size distribution (mean ~40) estimates which
residuals are likely to be exactly filled by a future item.
Empty bins are kept slightly less attractive so they stay free for large
items.
"""
import numpy as np
from math import gamma

SMALL = 20.0
TYPICAL = 40.0

# --- Build a synthetic size distribution matching the stated Weibull shape
# (mean about 40).  We choose a Weibull with a moderate shape so that the
# distribution is broad, then discretize onto integer sizes 1..100.
def _build_dist():
    target_mean = 40.0
    shape = 2.0  # broad, right-skewed like the description
    # mean = scale * Gamma(1 + 1/shape)
    scale = target_mean / gamma(1.0 + 1.0 / shape)
    sizes = np.arange(0, 101, dtype=np.float64)
    # Weibull pdf on integers via CDF differences (clamped at 100).
    s = (sizes + 0.5) / scale
    cdf_hi = 1.0 - np.exp(-np.clip(s, 0.0, None) ** shape)
    s = np.clip(sizes - 0.5, 0.0, None) / scale
    cdf_lo = 1.0 - np.exp(-np.clip(s, 0.0, None) ** shape)
    pmf = np.clip(cdf_hi - cdf_lo, 0.0, None)
    pmf[0] = 0.0
    pmf[100] = 1.0 - cdf_lo[100]
    tot = pmf.sum()
    if tot > 0:
        pmf /= tot
    return pmf

_DIST = _build_dist()

# Precompute smoothed distribution for residual-fill likelihood.
def _smooth(p, window):
    out = np.zeros_like(p)
    w = np.exp(-0.5 * (np.arange(-window, window + 1) / (window / 2.0)) ** 2)
    w /= w.sum()
    for off, wt in zip(range(-window, window + 1), w):
        idx = np.clip(np.arange(0, 101) + off, 0, 100)
        out += wt * p[idx]
    return out

_FILL = _smooth(_DIST, 3)


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    r = np.clip(residual.astype(np.float64), 0.0, None)
    score = -np.sqrt(r)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    score += np.where(residual >= SMALL, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Distribution-based exact-fill bonus: favor residuals that a future
    # item of the true size distribution is likely to fill exactly.
    ri = np.clip(residual, 0, 100).astype(np.int64)
    score += 60.0 * _FILL[ri]

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
