# EVOLVE-BLOCK-START
"""Online bin-choice rule: best-fit with empirical closeability.

Prefer exact fills strongly.  Otherwise use best-fit (smallest residual) so
gaps concentrate, with a large bonus for residuals that match a frequently
seen past item size (likely to be exactly closed by a future item).
Empty bins are kept slightly less attractive so they stay free for large items.
"""
import numpy as np

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best-fit -> prefer smallest residual.
    score = -residual.astype(np.float64)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 100000.0, 0.0)

    # Empirical closeability: if a residual equals a size we've seen often,
    # a future item may fill it exactly, so strongly favor such residuals.
    if _COUNT > 20:
        prob = _HIST / _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        lo = np.clip(ri - 1, 0, 100)
        hi = np.clip(ri + 1, 0, 100)
        smoothed = 0.1 * prob[lo] + 0.8 * prob[ri] + 0.1 * prob[hi]
        score += 4000.0 * smoothed

    # Gently prefer already-used bins (keeps empty bins for large items).
    score += np.where(bins < 100, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END

