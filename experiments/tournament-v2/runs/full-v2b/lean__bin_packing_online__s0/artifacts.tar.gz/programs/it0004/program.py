# EVOLVE-BLOCK-START
"""Best fit with a small fill-level tie-break preference for used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (small residual after placing). Secondary: prefer more-filled bins
    # (smaller remaining capacity) so that unused bins are opened only when necessary.
    # The tiny weight keeps best-fit dominant while nudging near-ties toward used bins.
    return -residual * 1024.0 - (100 - bins)
# EVOLVE-BLOCK-END
