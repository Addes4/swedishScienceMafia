# EVOLVE-BLOCK-START
"""Harmonic-style bin choice: match the residual to the item's harmonic size class."""
import numpy as np

# Harmonic class boundaries (fractions of capacity 100).
# Classes: (1/2,1], (1/3,1/2], (1/4,1/3], (1/5,1/4], (1/6,1/5], (1/7,1/6],
# (1/8,1/7], (1/9,1/8], (1/10,1/9], (1/13,1/10], (1/16,1/13], ... small.
_BOUNDS = [50, 34, 25, 20, 17, 15, 13, 12, 11, 10, 8, 7, 6, 5, 4]


def _class_id(size):
    """Return a harmonic class index for a size (item or residual)."""
    for i, b in enumerate(_BOUNDS):
        if size > b:
            return i
    return len(_BOUNDS)


def priority(item, bins):
    """Return a priority for every bin; highest wins, first on ties.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    residual = bins - item  # >= 0 for all bins shown
    # Base: prefer tighter fit (smaller residual).
    base = -residual.astype(np.float64)

    # Penalize non-zero residuals whose size class differs from the item's class.
    item_cls = _class_id(item)
    res_cls = np.empty(residual.shape, dtype=np.int64)
    for i, b in enumerate(_BOUNDS):
        res_cls[residual <= b] = i  # placeholder, fixed below
    # Recompute res_cls properly via np.digitize-like loop.
    res_cls = np.full(residual.shape, len(_BOUNDS), dtype=np.int64)
    for i in range(len(_BOUNDS) - 1, -1, -1):
        res_cls[residual <= _BOUNDS[i]] = i + 1

    # A residual is "good" if it's 0 or shares the item's class.
    good = (residual == 0) | (res_cls == item_cls)
    bonus = np.where(good, 1e6, 0.0)

    return base + bonus
# EVOLVE-BLOCK-END

