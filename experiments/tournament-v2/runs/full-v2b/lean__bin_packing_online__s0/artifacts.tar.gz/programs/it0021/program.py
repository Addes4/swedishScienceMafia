# EVOLVE-BLOCK-START
"""Best fit, but favor residuals that remain usable for a typical future item."""
import numpy as np

_state = {"sum": 0.0, "n": 0}


def priority(item, bins):
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]

    residual = bins - item  # space left after placing the item

    # Base: best fit (prefer smallest residual).
    score = -residual.astype(np.float64)

    # Strongly prefer exact fits.
    score[residual == 0] += 1e6

    # Bonus for residuals that can still hold a typical future item.
    reusable = residual >= mean
    score[reusable] += 0.5

    # Mild penalty for residuals too small to be useful but nonzero
    # (stranded slivers), so we avoid creating them when a better option exists.
    tiny = (residual > 0) & (residual < mean * 0.5)
    score[tiny] -= 0.5

    return score
# EVOLVE-BLOCK-END
