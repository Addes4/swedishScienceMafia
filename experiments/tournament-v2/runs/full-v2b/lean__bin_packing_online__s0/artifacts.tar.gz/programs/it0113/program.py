# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  Two usability tiers (small and typical) let the
rule favor gaps that remain broadly reusable across the size distribution.
Additionally, track an empirical histogram of past item sizes so residuals
that are likely to be exactly filled by a future item are favored.
Empty bins are kept slightly less attractive so they stay free for large
items.  A small online value table records, for each residual bucket, how
often such a gap was later reused, letting the rule adapt its usability
preferences to the real distribution.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0

# Online value table keyed by residual bucket (0..100).
# _GAP_SEEN[r]:    number of times a placement left residual bucket r (r>0)
# _GAP_REUSED[r]:  number of those bins that were later reused (=it fit again)
_GAP_SEEN = np.zeros(101, dtype=np.float64)
_GAP_REUSED = np.zeros(101, dtype=np.float64)

# Track per-bin residual so we can credit reuse at the next call.
_BIN_RES = {}
_NO = np.int64(0)


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT, _GAP_SEEN, _GAP_REUSED, _BIN_RES

    # Credit reuse: for each bin that still exists from before, if it was
    # changed since we last saw it, a prior gap got reused.
    n = bins.shape[0]
    # Only bins with index < n can be known; index is stable.
    for idx in range(n):
        prev = _BIN_RES.get(idx)
        if prev is not None and prev > 0:
            if bins[idx] != prev + 100:  # something changed the bin
                # It was used again (or reduced). Credit exactly once.
                b = prev if prev <= 100 else 100
                _GAP_REUSED[b] += 1.0
                _BIN_RES[idx] = None
            elif bins[idx] == 100:
                # Bin got freed entirely (shouldn't happen), drop tracking.
                _BIN_RES[idx] = None

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit -> prefer smallest residual (tightest packing).
    # Bounded so it doesn't dominate the soft usability terms.
    score = -np.clip(residual.astype(np.float64), 0.0, 60.0)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    small_ok = residual >= SMALL
    score += np.where(small_ok, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Empirical-fill bonus: if a residual equals a size we've seen often,
    # a future item may fill it exactly, so favor such residuals.
    if _COUNT > 50:
        prob = _HIST / _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        lo = np.clip(ri - 1, 0, 100)
        hi = np.clip(ri + 1, 0, 100)
        smoothed = 0.25 * prob[lo] + 0.5 * prob[ri] + 0.25 * prob[hi]
        score += 300.0 * smoothed

    # Online residual-value bonus: reward residuals whose observed future
    # reuse rate is high, adapting to the real distribution.
    if _COUNT > 200:
        ri = np.clip(residual, 0, 100).astype(np.int64)
        seen = _GAP_SEEN[ri]
        reused = _GAP_REUSED[ri]
        # Smoothed reuse rate with a small prior; uncertain buckets ~ neutral.
        rate = (reused + 0.5) / (seen + 1.0)
        # Only trust buckets with some observations.
        conf = seen / (seen + 20.0)
        score += 40.0 * conf * rate

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    # Record gaps we are about to create; credit reuse on later calls.
    chosen = int(np.argmax(score)) if score.size else 0
    # Update per-bin residual snapshot for the chosen bin.
    if n:
        # After placement the chosen bin's remaining capacity will be residual.
        new_res = int(residual[chosen])
        b = new_res if new_res <= 100 else 100
        if b > 0:
            _GAP_SEEN[b] += 1.0
            _BIN_RES[chosen] = new_res
            _BIN_RES[chosen] = new_res  # store residual value
        else:
            _BIN_RES[chosen] = None

    return score
# EVOLVE-BLOCK-END

