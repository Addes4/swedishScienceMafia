# EVOLVE-BLOCK-START
"""Best fit with a small consolidation bonus toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    residual = bins - item
    # Primary: tightest fit (smallest residual) -> maximize -residual.
    # Secondary: prefer bins that leave less total capacity, encouraging consolidation
    # and preserving empty bins for future large items. Small weight keeps best-fit dominant.
    return -(residual) * 64.0 - (bins - item) * 0.0 - bins * 0.001
# EVOLVE-BLOCK-END
