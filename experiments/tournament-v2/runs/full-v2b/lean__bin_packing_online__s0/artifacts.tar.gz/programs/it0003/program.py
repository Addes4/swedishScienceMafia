# EVOLVE-BLOCK-START
"""Best fit, with a mild preference to reuse open bins before opening new ones."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Base: best fit -> smallest remaining capacity after placement.
    score = -(bins - item)

    # Unused bins have remaining capacity exactly 100. Penalize them slightly so we
    # reuse already-open bins when a good fit exists, but still open a new bin when
    # the item would otherwise cause a lot of waste.
    score = score - 0.5 * (bins == 100)

    return score
# EVOLVE-BLOCK-END
