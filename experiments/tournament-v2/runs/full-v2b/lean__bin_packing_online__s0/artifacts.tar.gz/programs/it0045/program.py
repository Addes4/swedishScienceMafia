# EVOLVE-BLOCK-START
"""Best fit with a light online tie-break that avoids unusable slivers."""
import numpy as np

# Online size-frequency table (shared across calls).
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _total
    # Update frequency table (item sizes observed so far).
    _counts[item] += 1.0
    _total += 1.0

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit (smallest non-negative residual). Use negative residual.
    score = -residual.astype(np.float64)

    # Secondary bias: reward residuals that are exactly 0 (perfectly full) and
    # residuals that are large enough to fit a common small upcoming item.
    # Estimate a "small item" threshold from the lower quartile of seen sizes.
    if _total >= 50.0:
        cum = np.cumsum(_counts)
        # smallest size s such that at least 25% of items are <= s
        target = 0.25 * _total
        idx = np.searchsorted(cum, target)
        small = max(1, int(idx))
    else:
        small = 1

    # Penalize residuals in (0, small): these can't take a typical small item.
    sliver = (residual > 0) & (residual < small)
    score = score - 0.01 * sliver.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
