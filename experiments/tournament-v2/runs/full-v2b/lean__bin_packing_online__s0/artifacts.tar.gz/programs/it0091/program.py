# EVOLVE-BLOCK-START
"""Best fit with a small anti-stranding penalty based on recent large item sizes."""
import numpy as np


class _Stats:
    def __init__(self):
        self.recent = []
        self.thresh = 1

    def update(self, item):
        self.recent.append(int(item))
        if len(self.recent) > 200:
            self.recent.pop(0)
        # 90th percentile of recent items, approximating a size below which
        # residual capacity is likely to be stranded.
        s = sorted(self.recent)
        self.thresh = s[int(0.9 * (len(s) - 1))]


_stats = _Stats()


def priority(item, bins):
    """Best fit, plus a small penalty for residuals in the stranded dead zone."""
    residual = bins - item
    # Base: prefer smaller residual (best fit). Use float for smooth combination.
    score = -residual.astype(np.float64)
    thresh = _stats.thresh
    # Penalize positive residuals that cannot hold a typical large item.
    dead = (residual > 0) & (residual < thresh)
    score -= dead.astype(np.float64) * 0.5
    _stats.update(item)
    return score
# EVOLVE-BLOCK-END
