# EVOLVE-BLOCK-START
"""Guided best fit: best fit, but softly penalize leaving unusable slivers."""
import numpy as np

_count = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global _total
    residual = bins - item
    # running estimate of a typical small item size (mode-ish lower quantile)
    if _total > 0:
        order = np.arange(1, 101)
        w = _count[1:] / _total
        cw = np.cumsum(w)
        thr = float(order[np.searchsorted(cw, 0.25)])
    else:
        thr = 8.0
    # penalty for creating slivers strictly below the typical small item
    pen = np.where(residual < thr, (thr - residual), 0.0)
    score = -residual.astype(np.float64) - 0.5 * pen
    # update frequency estimate with this item
    _count[item] += 1.0
    _total += 1.0
    return score
# EVOLVE-BLOCK-END
