# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  Two usability tiers (small and typical) let the
rule favor gaps that remain broadly reusable across the size distribution.
Additionally, track an empirical histogram of past item sizes so residuals
that are likely to be exactly filled by a future item are favored, and reward
gaps that could be cleanly closed by a pair of likely future items.
Empty bins are kept slightly less attractive so they stay free for large
items.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0

# Cached normalized distribution (rebuilt when histogram grows enough).
_PROB = np.zeros(101, dtype=np.float64)
_PAIR = np.zeros(101, dtype=np.float64)  # pair-closure likelihood per residual
_PROB_COUNT = 0


def _refresh_tables():
    """Recompute normalized probabilities and pair-closure scores."""
    global _PROB, _PAIR, _PROB_COUNT
    prob = _HIST / max(_COUNT, 1.0)
    _PROB[:] = prob

    # Concentrate on the most probable item sizes so the pair analysis stays
    # cheap and meaningful.
    thresh = 0.002
    idx = np.where(prob > thresh)[0]
    idx = idx[idx >= 1]
    if idx.size:
        ps = prob[idx]
        # score[r] = sum_s prob[s] * prob[r - s] for s <= r (s a likely item)
    else:
        ps = np.zeros(0)

    pair = np.zeros(101, dtype=np.float64)
    for i, s in enumerate(idx):
        w = ps[i]
        # residual r after placing s leaves r - s; reward if that remainder is
        # itself a likely item size (clean two-item closure).
        if s < 101:
            pair[s:] += w * prob[0:101 - s]
    _PAIR[:] = pair
    _PROB_COUNT = _COUNT


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit -> prefer smallest residual (tightest packing).
    # Bounded so it doesn't dominate the soft usability terms.
    score = -np.clip(residual.astype(np.float64), 0.0, 60.0)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    small_ok = residual >= SMALL
    score += np.where(small_ok, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    if _COUNT > 50:
        if _COUNT - _PROB_COUNT > 200:
            _refresh_tables()
        prob = _PROB

        # Empirical-fill bonus: if a residual equals a size we've seen often,
        # a future item may fill it exactly, so favor such residuals.
        ri = np.clip(residual, 0, 100).astype(np.int64)
        lo = np.clip(ri - 1, 0, 100)
        hi = np.clip(ri + 1, 0, 100)
        smoothed = 0.1 * prob[lo] + 0.8 * prob[ri] + 0.1 * prob[hi]
        score += 300.0 * smoothed

        # Pair-closure bonus: reward gaps that a pair of likely items could
        # cleanly close, so multi-item completion wastes less.
        score += 120.0 * _PAIR[ri]

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
