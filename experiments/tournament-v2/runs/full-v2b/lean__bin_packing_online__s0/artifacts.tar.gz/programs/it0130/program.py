# EVOLVE-BLOCK-START
"""Online bin-choice rule: best fit with dead-residual penalty.

The item goes into the fullest bin it fits in (smallest residual) so that
gaps are concentrated into a few bins and stay reusable.  Exact fills get a
huge bonus.  Residuals that are positive yet smaller than the smallest item
size seen so far are forever useless, so they are heavily penalized.  Empty
bins are left slightly free for large items.
"""
import numpy as np

# Smallest item size observed so far (tracked across calls).
_MIN_SEEN = 101


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _MIN_SEEN

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit -> prefer smallest residual (tightest packing).
    score = -np.clip(residual.astype(np.float64), 0.0, 100.0)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize slivers we know are useless: positive residual smaller than
    # the smallest item ever seen can never be filled again.
    dead = (residual > 0) & (residual < _MIN_SEEN)
    score -= np.where(dead, 50.0, 0.0)

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    # Track the smallest item size seen so far (after scoring).
    if 1 <= item < _MIN_SEEN:
        _MIN_SEEN = item

    return score
# EVOLVE-BLOCK-END
