# EVOLVE-BLOCK-START
"""Online bin-choice rule: sharp best-fit with reusable-gap awareness.

Reward exact fills strongly.  Among non-exact placements, use a convex
(quadratic) penalty on the residual so the rule is far more decisive about
choosing the very tightest gap, since that is where waste accumulates.
A light usability tier protects gaps that remain broadly reusable, and a
sliver penalty discourages leaving unusably small gaps.  A small empirical
histogram acts only as a tie-breaker so it cannot override tightness.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item
    r = residual.astype(np.float64)
    r = np.clip(r, 0.0, None)

    # Primary: convex best-fit -> strongly prefer the tightest gap.
    score = -(r * r) / 100.0

    # Exact fill: no waste at all, strongly preferred but not absolute.
    score += np.where(residual == 0, 200.0, 0.0)

    # Residual can host at least a small item: valuable.
    score += np.where(residual >= SMALL, 3.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 5.0 - 0.03 * np.clip(r - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 20.0, 0.0)

    # Empirical-fill bonus used purely as a tie-breaker.
    if _COUNT > 50:
        prob = _HIST / _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        lo = np.clip(ri - 1, 0, 100)
        hi = np.clip(ri + 1, 0, 100)
        smoothed = 0.1 * prob[lo] + 0.8 * prob[ri] + 0.1 * prob[hi]
        score += 5.0 * smoothed

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 1.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END

