# EVOLVE-BLOCK-START
"""Hybrid: best-fit among bins that won't leave a sliver; otherwise best-fit."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # A "safe" bin either becomes exactly full (residual 0) or leaves room for a
    # reasonably common small item. Slivers below the threshold are demoted.
    threshold = 13
    safe = (residual <= 0) | (residual >= threshold)
    # Best-fit score: smaller residual is better.
    score = -(residual)
    # Demote unsafe bins by a large constant so safe bins always win when present.
    score = np.where(safe, score, score - 1000.0)
    return score
# EVOLVE-BLOCK-END
