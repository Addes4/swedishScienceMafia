# EVOLVE-BLOCK-START
"""Best fit restricted to partially-filled bins; open a new bin only when necessary."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tightest fit among used bins; strongly deprioritize empty bins.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    used = bins < 100
    # Best-fit residual among used bins: -(residual) via -(bins - item).
    score = -(bins - item)
    # Empty bins get a large penalty so they are chosen only if no used bin fits.
    score = np.where(used, score, score - 1000.0)
    return score
# EVOLVE-BLOCK-END
