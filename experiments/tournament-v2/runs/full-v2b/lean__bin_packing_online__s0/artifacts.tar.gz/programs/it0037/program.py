# EVOLVE-BLOCK-START
"""Best fit with a tiny bonus for residuals that are themselves likely to be filled soon."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit (smaller residual -> higher score).
    score = -residual.astype(np.float64)
    # Tiny bonus when the residual is a "small" size that is still useful,
    # i.e. a leftover in a moderately common item-size band.
    small = (residual >= 1) & (residual <= 30)
    score += 1e-3 * small
    return score
# EVOLVE-BLOCK-END
