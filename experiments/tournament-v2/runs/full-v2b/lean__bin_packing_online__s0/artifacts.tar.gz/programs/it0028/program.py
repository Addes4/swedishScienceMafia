# EVOLVE-BLOCK-START
"""Best fit with a small amount of seeded tie-randomization to reduce pathological
stranding of tiny residuals. Keeps deterministic best-fit as the dominant rule."""
import numpy as np


class _State:
    def __init__(self):
        self.rng = np.random.default_rng(12345)


_state = _State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every fitting bin, in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Primary: best fit -> smallest residual gets highest score.
    score = -residual.astype(np.float64)

    # Add tiny random jitter so near-equal residuals break ties in a varied way.
    jitter = _state.rng.random(residual.shape[0]) * 0.5
    score += jitter

    return score
# EVOLVE-BLOCK-END
