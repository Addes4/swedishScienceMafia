# EVOLVE-BLOCK-START
"""Best fit with a small anti-sliver guard based on recent item sizes."""
import numpy as np
from collections import deque


class State:
    def __init__(self):
        self.recent = deque(maxlen=200)


_state = State()


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score.

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every bin the item fits in, in bin order.
    """
    residuals = bins - item  # >= 0 for all bins shown

    # Track recent items to estimate a small typical item size.
    _state.recent.append(int(item))
    if len(_state.recent) >= 20:
        arr = np.fromiter(_state.recent, dtype=np.float64)
        # 20th percentile as an estimate of small-but-usable residuals
        thr = float(np.percentile(arr, 20))
        thr = max(1.0, min(thr, 20.0))
    else:
        thr = 1.0

    # Best-fit residual (minimum residual).
    min_res = int(residuals.min())

    # Sliver penalty: strongly penalize residuals below the threshold so that,
    # if a non-sliver option exists, it is preferred; otherwise best-fit wins.
    score = -residuals.astype(np.float64)

    # Only penalize genuinely tiny residuals.
    small = residuals < thr
    if small.any() and (~small).any():
        # Shift sliver bins below all non-sliver bins while keeping order.
        score = np.where(small, -residuals - 1000.0, -residuals)

    return score
# EVOLVE-BLOCK-END
