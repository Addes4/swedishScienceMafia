# EVOLVE-BLOCK-START
"""Best-fit with a penalty for leaving unfillable slivers (residual < min item)."""
import numpy as np

_MIN_ITEM = [1]


def priority(item, bins):
    if item < _MIN_ITEM[0]:
        _MIN_ITEM[0] = item
    residual = bins - item
    # Dead zone: residual between 1 and min item seen -> likely wasted.
    dead = (residual > 0) & (residual < _MIN_ITEM[0])
    score = -residual.astype(np.float64)
    score[dead] -= 1000.0
    return score
# EVOLVE-BLOCK-END
