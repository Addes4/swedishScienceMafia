# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  Two usability tiers (small and typical) let the
rule favor gaps that remain broadly reusable across the size distribution.
A modest empirical histogram of past item sizes acts as a tie-breaker:
among near-equal residuals, favor those likely to be exactly filled soon.
Empty bins are kept slightly less attractive so they stay free for large
items.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0

# Two smoothing scales for the fill-probability estimate.
_OFFS1 = np.arange(-6, 7)
_W1 = np.exp(-(_OFFS1.astype(np.float64) ** 2) / (2.0 * 2.0 ** 2))
_OFFS2 = np.arange(-12, 13)
_W2 = np.exp(-(_OFFS2.astype(np.float64) ** 2) / (2.0 * 5.0 ** 2))


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item

    r = np.clip(residual.astype(np.float64), 0.0, None)
    score = -np.sqrt(r)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    small_ok = residual >= SMALL
    score += np.where(small_ok, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Empirical-fill term: a small tie-breaker among near-equal residuals.
    # Only active for non-exact, usable residuals so it never overrides the
    # primary best-fit ordering by a large margin.
    if _COUNT > 50:
        prob = _HIST / _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        smoothed = np.zeros_like(r)
        for off, wt in zip(_OFFS1, _W1):
            idx = np.clip(ri + off, 0, 100)
            smoothed += wt * prob[idx]
        smoothed2 = np.zeros_like(r)
        for off, wt in zip(_OFFS2, _W2):
            idx = np.clip(ri + off, 0, 100)
            smoothed2 += wt * prob[idx]
        combined = 0.6 * smoothed + 0.4 * smoothed2
        peak = combined.max()
        if peak > 0:
            combined = combined / peak
        score += 6.0 * combined

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
