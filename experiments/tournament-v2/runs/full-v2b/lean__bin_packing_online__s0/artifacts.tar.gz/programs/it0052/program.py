# EVOLVE-BLOCK-START
"""Best fit with a concave residual cost to sharpen tie-breaking toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    We use best fit: minimize the residual capacity after placement. To make the
    ranking more decisive and avoid leaving many nearly-equal residuals, we apply a
    strictly concave, monotone-decreasing transform of the residual so that smaller
    residuals are strongly preferred while larger residuals are compressed.
    """
    residual = bins - item
    # Concave, decreasing penalty on residual: -(residual ** 0.5).
    # sqrt is strictly increasing, so -sqrt is strictly decreasing => best fit preserved,
    # but the curvature sharpens the preference for the fullest bins.
    return -np.sqrt(residual.astype(np.float64))
# EVOLVE-BLOCK-END

