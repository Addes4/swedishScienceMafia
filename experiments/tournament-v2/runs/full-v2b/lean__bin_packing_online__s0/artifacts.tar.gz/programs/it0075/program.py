# EVOLVE-BLOCK-START
"""Convex-cost best fit: prefer tight fits but mildly discourage tiny slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest score.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: minimize residual (best fit). Add a small convex term so that,
    # among near-equal tight fits, we slightly prefer leaving a larger residual
    # (avoiding tiny stranded slivers) while perfect fills (residual 0) remain best.
    alpha = 0.02
    score = -residual.astype(np.float64) + alpha * (residual.astype(np.float64) ** 2) / 100.0
    return score
# EVOLVE-BLOCK-END
