# EVOLVE-BLOCK-START
"""Online bin-choice rule: best-fit with a two-item fill lookahead.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated.  Then add a lookahead term that
rewards residuals which the empirical size distribution says are likely to be
exactly closed by a future item — encouraging the creation of cleanly
fillable gaps rather than merely small ones.  Empty bins are kept slightly
less attractive so they stay free for large items.
"""
import numpy as np

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item
    rf = residual.astype(np.float64)

    # Primary: best fit -> prefer smallest residual (tightest packing),
    # bounded so the soft terms below still matter.
    score = -np.clip(rf, 0.0, 40.0)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize slivers that can never hold any useful item.
    score -= np.where((residual > 0) & (residual < 10), 20.0, 0.0)

    # Lookahead: reward residuals likely to be exactly closable by a future
    # item, per the empirical size distribution of past items.
    if _COUNT > 20:
        prob = _HIST / _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        lo = np.clip(ri - 1, 0, 100)
        hi = np.clip(ri + 1, 0, 100)
        # probability mass near this residual size
        near = 0.25 * prob[lo] + 0.5 * prob[ri] + 0.25 * prob[hi]
        score += 120.0 * near
        # extra weight for residuals at common sizes
        score += 80.0 * prob[ri]

    # Gently prefer already-used bins (keeps empty bins for large items).
    score += np.where(bins < 100, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
