# EVOLVE-BLOCK-START
"""Distribution-aware best fit."""
import numpy as np

# Fixed item-size distribution characteristics (Weibull-shaped, mean ~40).
_SIZE_MEAN = 40.0
_SIZE_SHAPE = 1.8


def _size_weights():
    # Discretized probability mass of item sizes 1..100.
    x = np.arange(1, 101, dtype=np.float64)
    scale = _SIZE_MEAN / 0.8882
    probs = (x / scale) ** (_SIZE_SHAPE - 1.0) * np.exp(-((x / scale) ** _SIZE_SHAPE))
    probs += 1e-9
    return probs


_W = _size_weights()


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    # Base: best fit -> smaller residual is better.
    score = -1000.0 * resid
    # Reward residuals that a future item can plausibly complete exactly.
    # Map residual to its expected "match desirability": weight of items that fit it.
    r = np.clip(resid, 0, 100)
    w = _W[r.astype(np.int64)]
    score = score + 50.0 * w
    return score
# EVOLVE-BLOCK-END
