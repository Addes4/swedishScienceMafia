# EVOLVE-BLOCK-START
"""Best fit with a learned penalty against creating tiny unusable slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for fitting bins

    # Base best-fit score: prefer the smallest residual.
    score = -residual.astype(np.float64)

    # Penalize residuals that are small but non-zero, since such slivers are often
    # unusable by future items and effectively waste space. The threshold adapts to
    # the item size: for small items tiny residuals are fine, for larger items they
    # are increasingly wasteful.
    thr = max(1.0, 0.25 * float(item))
    small = (residual > 0) & (residual < thr)
    if small.any():
        # Concave penalty: strongest just below the threshold-independent tiny range,
        # tapering off as residual approaches the threshold.
        frac = residual[small] / thr
        score[small] -= 2.0 * (1.0 - frac)

    return score
# EVOLVE-BLOCK-END
