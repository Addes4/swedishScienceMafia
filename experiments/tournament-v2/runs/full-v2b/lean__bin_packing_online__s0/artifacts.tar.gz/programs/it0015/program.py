# EVOLVE-BLOCK-START
"""Best fit with occasional randomization to escape pathological packings."""
import numpy as np

_rng = np.random.default_rng(12345)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base best-fit score: tightest fit (smallest residual) is best.
    score = -residual.astype(np.float64)
    # Small random jitter to break ties among near-equal fits, controlled.
    # Only jitter when residuals are reasonably large (avoid disturbing exact/near fits).
    if residual.size > 0:
        # Jitter magnitude scales down for tight fits so it rarely overrides good fits.
        # Apply jitter proportional to a small epsilon.
        eps = 0.01
        jitter = _rng.random(residual.size)
        score = score * (1.0 + eps * jitter)
    return score
# EVOLVE-BLOCK-END
