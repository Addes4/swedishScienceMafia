# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  A static Weibull-shaped prior (matching the item
size distribution, mean ~40) provides a smooth, low-variance estimate of how
likely a residual is to be exactly closed by a future item.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0

# Static prior over item sizes (Weibull-shaped, mean ~40).  Precomputed once.
_SIZE = np.arange(101, dtype=np.float64)
_SHAPE = 1.6
_SCALE = 44.0
# Weibull pdf on 1..100, shifted to avoid zero at 0.
_PRIOR = (_SHAPE / _SCALE) * (_SIZE / _SCALE) ** (_SHAPE - 1.0) * np.exp(
    -(_SIZE / _SCALE) ** _SHAPE
)
_PRIOR[0] = 0.0
_total = _PRIOR.sum()
if _total > 0:
    _PRIOR = _PRIOR / _total


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item
    resid_f = residual.astype(np.float64)

    # Primary: best fit -> prefer smallest residual (tightest packing).
    score = -np.clip(resid_f, 0.0, 60.0)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    score += np.where(residual >= SMALL, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(resid_f - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Closeability bonus: if a residual is likely to be exactly closed by a
    # future item, favor it.  Scale by the residual so small/medium gaps that
    # are closeable get a meaningful but non-dominating boost.
    if residual.size:
        ri = np.clip(residual, 0, 100).astype(np.int64)
        prob = _PRIOR[ri]
        scale = 40.0 * np.exp(-np.clip(resid_f, 0.0, None) / 50.0)
        score += scale * prob

    # Gently prefer already-used bins (keeps empty bins for large items).
    score += np.where(bins < 100, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
