# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold a typical future item and penalize tiny unusable slivers.  Empty
bins are kept slightly less attractive so they stay free for large items.
"""
import numpy as np

TYPICAL = 40.0
SLIVER = 20.0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit -> prefer smallest residual (tightest packing).
    score = -residual.astype(np.float64)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual large enough to host a typical item is valuable; favor
    # moderately reusable gaps over huge ones so future items can close them.
    usable = residual >= SLIVER
    bonus = 5.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(usable, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SLIVER)
    score -= np.where(sliver, 30.0, 0.0)

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END

