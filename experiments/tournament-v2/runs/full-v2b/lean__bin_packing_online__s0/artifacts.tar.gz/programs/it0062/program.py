# EVOLVE-BLOCK-START
"""Best fit, but reserve completely empty bins for when nothing else fits."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    empty = bins == 100
    if not empty.all():
        # Prefer non-empty bins via best-fit; demote empty bins strongly.
        score = -(bins - item).astype(np.float64)
        score[empty] -= 1000.0
        return score
    return -(bins - item)
# EVOLVE-BLOCK-END

