# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  Two usability tiers (small and typical) let the
rule favor gaps that remain broadly reusable across the size distribution.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0

# Common residual targets that future items are likely to exactly fill.
# Derived from typical item sizes near the distribution mean (~40).
_GAP_TARGETS = (40, 60, 80)


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    r = np.clip(residual.astype(np.float64), 0.0, None)
    score = -np.sqrt(r)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    small_ok = residual >= SMALL
    score += np.where(small_ok, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Small bonus for residuals matching likely future fill sizes.
    for t in _GAP_TARGETS:
        score += np.where(np.abs(residual - t) <= 1, 1.5, 0.0)

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
