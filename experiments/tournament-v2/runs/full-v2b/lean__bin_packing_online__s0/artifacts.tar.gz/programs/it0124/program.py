# EVOLVE-BLOCK-START
"""Online bin-choice rule: exact fill, sliver avoidance, then best fit.

The dominant signal is: never create a sliver (a residual too small to hold
any item we are likely to see again), and close gaps exactly whenever possible.
Between usable residuals, prefer the tightest fit so gaps stay concentrated.
A small empty-bin reservation keeps a few bins free for large items.
"""
import numpy as np

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0

# Smallest item size that has appeared with meaningful frequency so far.
# Until enough data is collected, assume a conservative small threshold.
_MIN_USEFUL = 8.0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT, _MIN_USEFUL

    residual = bins - item  # remaining capacity after placing the item
    r = residual.astype(np.float64)

    # Base: best fit (prefer smallest residual) but tightly bounded so the
    # tiered structure below dominates.
    score = -np.clip(r, 0.0, 30.0)

    # Exact fill: perfect, no waste.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Sliver penalty: positive residual too small to ever be reusable.
    sliver = (residual > 0) & (r < _MIN_USEFUL)
    score -= np.where(sliver, 200.0, 0.0)

    # Reusable gap bonus: residual at least the smallest useful size.
    score += np.where(residual >= _MIN_USEFUL, 5.0, 0.0)

    # Reserve empty bins slightly for large arrivals.
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1
        if _COUNT >= 30:
            # Recompute the smallest item size carrying real mass.
            prob = _HIST / _COUNT
            sizes = np.arange(1, 101)
            # Ignore the very smallest bucket to avoid a single rare tiny item
            # pinning the threshold too low; require at least 3% mass.
            significant = sizes[(prob[1:] >= 0.03)]
            _MIN_USEFUL = float(significant[0]) if significant.size else 8.0

    return score
# EVOLVE-BLOCK-END
