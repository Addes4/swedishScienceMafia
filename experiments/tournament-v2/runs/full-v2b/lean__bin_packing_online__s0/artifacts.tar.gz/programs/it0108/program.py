# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with distribution-aware reuse value.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals whose
remaining capacity is likely to be filled by a future item, estimated from an
empirical histogram of past item sizes.  Empty bins are kept slightly less
attractive so they stay free for large items.
"""
import numpy as np

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item
    r = residual.astype(np.float64)

    # Primary: best fit -> prefer smallest residual (tightest packing).
    score = -r

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < 20)
    score -= np.where(sliver, 30.0, 0.0)

    # Distribution-aware reuse value: expected chance a future item (drawn
    # from the empirical distribution) fits exactly into this residual.
    if _COUNT > 50:
        prob = _HIST / _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        # Probability mass of item sizes <= residual (residual is reusable).
        cdf = np.cumsum(prob)
        # Reward residuals that can still host common future items.
        score += 120.0 * cdf[ri]
        # Extra reward if residual exactly matches a frequent future size.
        score += 200.0 * prob[ri]

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
