# EVOLVE-BLOCK-START
"""Baseline: best fit. Put the item in the bin it fits most tightly."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # pure best fit baseline: prefer the smallest residual
    score = -residual.astype(np.float64)
    # small bonus to discourage slivers: residuals that are zero or >= 30 are usable
    score += np.where((residual == 0) | (residual >= 30), 0.5, 0.0)
    return score
# EVOLVE-BLOCK-END

