# EVOLVE-BLOCK-START
"""Online bin-choice rule: rank bins by the future usefulness of the residual.

For each candidate bin we look at the residual r = capacity - item that would
remain.  A residual is useful if it can still hold a future item.  Rather than
minimizing r (best fit) or using arbitrary constants, we estimate, from the
running empirical distribution of item sizes seen so far, the probability that
a future item fits in r.  Bins whose residual stays usable score higher, exact
fills get a large bonus, and unused bins are slightly discouraged so we keep
them in reserve for large items.
"""
import numpy as np

CAP = 100.0


class _Stats:
    def __init__(self):
        self.sizes = np.zeros(0, dtype=np.float64)

    def add(self, item):
        self.sizes = np.append(self.sizes, float(item))


_stats = _Stats()


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    _stats.add(item)

    residual = bins - item  # remaining capacity after placing the item

    # Empirical CDF of past item sizes -> probability a future item fits.
    # P(fit in r) = P(size <= r).
    if _stats.sizes.size:
        sorted_sizes = np.sort(_stats.sizes)
        n = sorted_sizes.size
        # searchsorted on sorted residuals, vectorized
        idx = np.searchsorted(sorted_sizes, residual, side='right')
        pfit = idx.astype(np.float64) / n
    else:
        pfit = np.ones_like(residual, dtype=np.float64)

    # Base: prefer residuals that remain likely to accept a future item.
    score = pfit

    # Strong bonus for an exact fill (no wasted space at all).
    score += np.where(residual == 0, 1.0, 0.0)

    # Penalize tiny residuals that almost certainly can't host anything.
    score -= 0.5 * np.where((residual > 0) & (residual < 10), 1.0, 0.0)

    # Mild preference for already-used bins (keep empty bins for big items).
    score += np.where(bins < CAP, 0.05, 0.0)

    # Best-fit tie-break: among equal usefulness, smaller residual is better.
    score -= 1e-6 * residual

    return score
# EVOLVE-BLOCK-END
