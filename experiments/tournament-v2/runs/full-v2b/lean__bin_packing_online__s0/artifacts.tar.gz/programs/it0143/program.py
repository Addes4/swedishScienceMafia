# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  Two usability tiers (small and typical) let the
rule favor gaps that remain broadly reusable across the size distribution.
A light deterministic bonus favors residuals near the distribution mean, which
are likely to be exactly filled by a future item.  Empty bins are kept slightly
less attractive so they stay free for large items.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit -> prefer smallest residual (tightest packing).
    score = -np.clip(residual.astype(np.float64), 0.0, 60.0)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    score += np.where(residual >= SMALL, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Deterministic modal-gap bonus: residuals near the distribution mean are
    # likely claoseable by a typical future item.
    score += 8.0 * np.exp(-((residual - 40.0) / 18.0) ** 2)

    # Prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 3.0, 0.0)

    return score
