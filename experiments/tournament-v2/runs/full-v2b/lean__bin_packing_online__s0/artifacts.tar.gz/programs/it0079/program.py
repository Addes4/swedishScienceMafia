# EVOLVE-BLOCK-START
"""Near-best-fit with a residual-usefulness tie-break.

Primary key: best fit (smallest post-placement residual).
Secondary key: prefer residuals that are themselves likely future item sizes
(so the bin can still be completed rather than stranded as a tiny sliver).
"""
import numpy as np

# Distribution of item sizes is roughly Weibull-shaped with mean ~40 over 1..100.
# Precompute a static weight per possible residual size: larger weight = more useful.
_RESID = np.zeros(101, dtype=np.float64)
for s in range(101):
    # Heuristic usefulness: probability an item fits exactly in a slot of size s.
    # Peak around typical item sizes, taper off towards tiny unusable and huge slots.
    _RESID[s] = min(s, 100) / 100.0

# Precompute a per-size score lookup: prefer smallest residual (best fit),
# with a small secondary preference for "useful" residuals.
_LOOKUP = np.array(_RESID, dtype=np.float64)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    residual = bins - item
    # Primary: best fit -> smaller residual is better.
    # Secondary (tiny epsilon): prefer residual sizes that are useful for future items.
    return -residual.astype(np.float64) + 1e-3 * _LOOKUP[np.clip(residual, 0, 100)]
# EVOLVE-BLOCK-END
