# EVOLVE-BLOCK-START
"""Best fit that avoids creating unusable slivers, using a running mean item size."""
import numpy as np

_state = {"n": 0, "sum": 0.0, "mean": 40.0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    s = _state
    if s["n"] > 0:
        mean = s["sum"] / s["n"]
    else:
        mean = 40.0
    s["n"] += 1
    s["sum"] += item

    residual = bins - item  # post-placement residual, >= 0 for all shown bins

    # Primary: tightest fit. But treat very small slivers as worse than a clean fit,
    # so prefer leaving a residual that can still hold a typical future item,
    # or a residual of exactly 0.
    # Map each residual r to an "effective" residual:
    #   r == 0            -> 0        (perfect)
    #   0 < r < mean      -> mean     (sliver: penalize, push to next tier)
    #   r >= mean         -> r        (usable leftover, normal best fit)
    eff = np.where(residual == 0, 0.0,
                   np.where(residual < mean, float(mean) + residual, residual.astype(float)))
    return -eff
# EVOLVE-BLOCK-END
