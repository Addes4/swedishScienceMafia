# EVOLVE-BLOCK-START
"""Reserved-empty-bin best fit: pack tightly into non-empty bins; only open a new
bin when no partially-filled bin can hold the item."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: remaining capacity of every fitting bin, in bin order.
    """
    # Best-fit base: smaller post-placement residual => higher priority.
    score = -(bins - item)

    # Penalize fully empty bins (remaining capacity == 100) so that, whenever a
    # partially-filled bin can hold the item, we use it instead of opening a new
    # one. Empty bins remain the fallback when nothing else fits.
    score = np.where(bins == 100, score - 1000, score)

    return score
# EVOLVE-BLOCK-END
