# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  Two usability tiers (small and typical) let the
rule favor gaps that remain broadly reusable across the size distribution.
Additionally, track an empirical histogram of past item sizes so residuals
that are likely to be exactly filled by a future item are favored, and so
gaps that can be closed by a likely next item (leaving ~0 or a usable gap)
are preferred over gaps that would strand slivers.
Empty bins are kept slightly less attractive so they stay free for large
items.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit -> prefer smallest residual (tightest packing).
    # Bounded so it doesn't dominate the soft usability terms.
    score = -np.clip(residual.astype(np.float64), 0.0, 60.0)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    small_ok = residual >= SMALL
    score += np.where(small_ok, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Empirical-fill bonus: if a residual equals a size we've seen often,
    # a future item may fill it exactly, so favor such residuals.
    if _COUNT > 50:
        prob = _HIST / _COUNT
        # Probability mass that a randomly sized future item lands in the
        # residual bucket (sharpened toward exact matches).
        ri = np.clip(residual, 0, 100).astype(np.int64)
        lo = np.clip(ri - 1, 0, 100)
        hi = np.clip(ri + 1, 0, 100)
        smoothed = 0.1 * prob[lo] + 0.8 * prob[ri] + 0.1 * prob[hi]
        score += 300.0 * smoothed

        # Complementarity: reward residuals that leave a clean closure or a
        # still-usable gap after one likely next item is placed.
        # For each residual r, estimate best over s of P(item in s) weighted
        # by whether (r - s) is ~0 or a reasonable remaining gap.
        r = np.clip(residual.astype(np.float64), 0.0, 100.0)
        # Grid of candidate next-item sizes (1..100), weighted by probability.
        s = np.arange(1, 101, dtype=np.float64)          # (S,)
        ps = prob[1:101]                                  # (S,)
        rem = r[:, None] - s[None, :]                     # (B, S)
        valid = rem >= 0
        # Value of the leftover: tiny leftover is great, but not a useless sliver.
        leftover = np.where(rem <= 0, 8.0, np.where(rem < SMALL, -6.0, 1.5))
        contrib = np.where(valid, ps[None, :] * leftover, -1e9)
        best = np.max(contrib, axis=1)
        best = np.maximum(best, 0.0)
        score += 60.0 * best

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
