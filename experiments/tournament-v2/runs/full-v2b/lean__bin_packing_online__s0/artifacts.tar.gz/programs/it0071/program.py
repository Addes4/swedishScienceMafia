# EVOLVE-BLOCK-START
"""Best fit with online residual-reuse tie-breaking.

Primary rule: best fit (minimize post-placement residual).
Tie-break window: among bins leaving a nearly-tight residual, prefer residuals
that match a frequently observed item size, so future items can fill them.
"""
import numpy as np

_freq = np.zeros(101, dtype=np.float64)
_count = 0


def priority(item, bins):
    global _count
    # update size statistics from past items (item arriving now is added after ranking)
    key = item
    # primary: strongest negative residual -> highest score (best fit)
    residual = bins - item
    primary = -residual.astype(np.float64)

    # secondary term: reward residuals matching popular small sizes
    if _count > 0:
        # normalize frequencies of residuals; weight only small/medium residuals
        resid_idx = np.clip(residual, 0, 100).astype(np.int64)
        match = _freq[resid_idx] / _count
    else:
        match = np.zeros_like(primary)

    score = primary + 0.5 * match
    # record this item for future calls
    _freq[key] += 1.0
    _count += 1
    return score
# EVOLVE-BLOCK-END
