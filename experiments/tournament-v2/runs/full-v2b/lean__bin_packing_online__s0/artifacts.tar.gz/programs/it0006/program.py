# EVOLVE-BLOCK-START
"""Best fit with a bin-index tie-break toward later bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    idx = np.arange(bins.shape[0], dtype=np.int64)
    # Primary: small residual after placement (best fit).
    # Secondary: prefer larger bin index among ties via a tiny fractional bonus.
    return -(bins - item) + idx * 1e-6
# EVOLVE-BLOCK-END
