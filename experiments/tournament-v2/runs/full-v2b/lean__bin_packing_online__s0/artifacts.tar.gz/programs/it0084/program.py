# EVOLVE-BLOCK-START
"""Best fit with a capacity-preserving tiebreaker among equal residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: prefer the smallest post-placement residual (tightest fit).
    # Secondary (tiny weight): among near-equal residuals, prefer the bin with
    # more remaining capacity, i.e. leave the emptier bin usable for later items.
    return -residual + 1e-3 * bins
# EVOLVE-BLOCK-END

