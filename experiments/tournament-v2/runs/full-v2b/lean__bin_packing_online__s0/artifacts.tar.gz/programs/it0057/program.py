# EVOLVE-BLOCK-START
"""Best fit with a mild guard against creating useless small residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins: tightest fit, but slightly penalize residuals too small to be reused.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 for all shown bins

    # Online estimate of "small item" scale: track a smooth minimum of residuals we leave
    # behind, so the guard adapts to the actual distribution rather than a fixed constant.
    state = priority.state
    if state is None:
        state = {"small": 5.0, "n": 0}
        priority.state = state

    state["n"] += 1
    small = state["small"]

    # Penalize residuals below the small-item scale, softly (<= 1 unit) so that the
    # tightest fit still wins whenever residuals differ meaningfully.
    penalty = np.minimum(1.0, np.maximum(0.0, small - residual)) * 0.5

    score = -(residual.astype(np.float64) + penalty)

    # Update the running small-item estimate toward the minimum seen residual that is > 0.
    valid = residual[residual > 0]
    if valid.size:
        m = float(valid.min())
        state["small"] = small + 0.02 * (m - small)

    return score


priority.state = None
# EVOLVE-BLOCK-END
