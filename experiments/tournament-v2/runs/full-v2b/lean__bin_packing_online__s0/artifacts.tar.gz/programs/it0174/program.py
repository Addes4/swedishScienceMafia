# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills and near-exact fills.  Among non-exact placements,
prefer the smallest residual (best fit) so gaps are concentrated, but boost
residuals that can still hold future items.  Two usability tiers (small and
typical) let the rule favor gaps that remain broadly reusable across the size
distribution.  Empty bins are kept slightly less attractive so they stay free
for large items.  The empirical histogram was removed because it repeatedly
hurt scores; the core best-fit/usability rule dominates.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    r = np.clip(residual.astype(np.float64), 0.0, None)
    # Best-fit core: tighter residuals score higher.  Slightly steeper slope
    # spreads the gaps more aggressively toward the smallest fit.
    score = -np.sqrt(r) - 0.02 * r

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Near-exact fill: residuals small enough to be filled by a tiny item are
    # almost as valuable as an exact fill, so reward them in a graded way.
    near = (residual > 0) & (residual <= 5)
    score += np.where(near, 40.0 - 6.0 * np.clip(residual - 1, 0.0, None), 0.0)

    # Residual can host at least a small item: valuable.
    small_ok = residual >= SMALL
    score += np.where(small_ok, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 5) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
