# EVOLVE-BLOCK-START
"""Two-candidate best fit: prefer tight fits, but avoid stranding unusable slivers."""
import numpy as np

_state = {"counts": None, "min_seen": 101, "n": 0}


def _ensure():
    if _state["counts"] is None:
        _state["counts"] = np.zeros(101, dtype=np.float64)
    return _state["counts"]


def priority(item, bins):
    counts = _ensure()
    _state["n"] += 1
    if item < _state["min_seen"]:
        _state["min_seen"] = item
    counts[item] += 1.0

    # post-placement residual for each bin
    resid = bins - item  # bins all >= item by construction

    # Base score: best fit -> smaller residual is better (higher score).
    # score = -resid, tie broken by first bin as required.
    # Now detect if the best-fit residual is a "useless sliver".
    best = resid.min()

    # Minimum plausible future item size observed so far (start conservative).
    mins = _state["min_seen"]
    if mins > 100:
        mins = 1

    # If the tightest placement leaves a sliver smaller than any item we've seen,
    # it can likely never be filled. In that case, among bins leaving a residual
    # >= mins, prefer the smallest such residual (keeps bins full but usable);
    # otherwise fall back to pure best fit.
    if best > 0 and best < mins:
        # usable candidates: residual >= mins, prefer smallest residual
        usable = resid >= mins
        if usable.any():
            # score: non-usable bins get -inf-like penalty; usable scored by -resid
            scores = np.where(usable, -resid.astype(np.float64), -1e12)
            return scores
        # no usable candidate: pure best fit (accept sliver)
        return -resid.astype(np.float64)

    return -resid.astype(np.float64)
# EVOLVE-BLOCK-END
