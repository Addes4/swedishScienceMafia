# EVOLVE-BLOCK-START
"""Distribution-aware best fit: prefer tight fits, then fillable residuals."""
import numpy as np

# Coarse prior on item sizes (Weibull-shaped, mean ~40, mass on 1..100).
# Build a smooth desirability over residual capacities: residual r is "good"
# if many future items are <= r and could eventually complete it.
_R = np.arange(101)
# Approximate item density: Weibull(k=2, lambda=45) truncated to 1..100.
_x = _R.astype(np.float64)
_k, _lam = 2.0, 45.0
_density = (_k / _lam) * (_x / _lam) ** (_k - 1) * np.exp(-(_x / _lam) ** _k)
_density[0] = 0.0
_density /= _density[1:].sum()
# For a residual r, desirability is the probability mass of items that can fit
# into r times the chance some sequence completes it; use cumulative mass <= r
# weighted to favor moderate residuals (avoid tiny stranded slivers).
_cum = np.cumsum(_density)  # P(item <= r)
# Usability: fraction of residual capacity that items can actually consume.
# A residual r is more usable if the typical item (mean 40) fits well.
_typ = _R / 40.0
_use = np.minimum(_typ, 1.0) * _cum
# Blend: prefer residuals where expected consumed fraction is high.
_DESIR = 0.5 * _cum + 0.5 * _use  # in [0,1]


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: tighter fit (smaller residual) is better.
    tight = -residual.astype(np.float64)
    # Secondary: prefer residuals that are broadly fillable / usable.
    desir = _DESIR[residual]
    return tight * 1.0 + desir * 0.5
# EVOLVE-BLOCK-END
