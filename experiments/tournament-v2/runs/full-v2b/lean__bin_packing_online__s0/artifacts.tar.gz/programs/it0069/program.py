# EVOLVE-BLOCK-START
"""Distribution-aware best fit: prefer residuals that future items can fill."""
import numpy as np

# Approximate Weibull(shape~2, scale~45)-like size probabilities are unknown exactly,
# so use a smooth weighting over residuals instead of hardcoded classes.
_SIZES = np.arange(1, 101, dtype=np.float64)
# weight a residual r by how "useful" it is: large residuals are reusable, tiny ones are waste.
# value(r) = r  (more free space is more reusable) is the neutral choice,
# so score = -(post residual) + small bonus for residual being "packable".
# Simpler and robust: pure best fit but break ties toward bins that still have room to be filled.
def priority(item, bins):
    residual = bins - item
    # primary: minimize residual (best fit)
    # secondary (tiny): prefer bins whose residual is large enough to admit a small item later,
    # i.e. avoid finishing off a bin leaving 1..(min_common-1) unusable.
    # Tie-break magnitude kept small so it rarely overrides best-fit.
    penalty = np.where((residual > 0) & (residual < 5), 1e-3, 0.0)
    return -residual + penalty
# EVOLVE-BLOCK-END
