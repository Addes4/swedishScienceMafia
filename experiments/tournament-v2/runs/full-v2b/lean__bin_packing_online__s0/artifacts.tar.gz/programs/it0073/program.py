# EVOLVE-BLOCK-START
"""Best-fit with a distribution-aware residual-reuse tie-break.

Primary ranking: smallest post-placement residual (classic best fit).
Tie-break: among bins leaving a nearly-identical residual, prefer the residual
that is more likely to be reusable by a future item from the known
Weibull-shaped size distribution (mean ~40).  Reusable residuals are those
that can still accommodate a common item size, so the item is placed so as to
avoid stranding a sliver that no future item can fill.
"""
import numpy as np

# Precompute a smooth approximation of the item-size CDF/PDF for the Weibull
# distribution (shape ~2, scale ~45 gives mean ~40).  This is a fixed,
# non-tuned background table; it uses no instance-specific information.
_SIZES = np.arange(1, 101, dtype=np.float64)


def _weibull_pdf(sizes, shape=2.0, scale=45.0):
    x = sizes / scale
    return (shape / scale) * x ** (shape - 1.0) * np.exp(-(x ** shape))


_PDF = _weibull_pdf(_SIZES)
_PDF = _PDF / _PDF.sum()

# Residual desirability: how likely a residual can accept a common future item.
# Integral of pdf over sizes <= residual (probability a random item fits).
_CDF = np.cumsum(_PDF)  # _CDF[k-1] = P(item <= k)


def priority(item, bins):
    """Score bins: strongly prefer best-fit, then prefer reusable residuals."""
    post = bins - item  # residual after placing the item here

    # Base: best fit -> larger score for smaller residual.
    base = -(post.astype(np.float64))

    # Reuse bonus: probability that a fresh item would still fit in this bin.
    # Clip residuals to a valid index range (>=0 since the item fits).
    idx = np.clip(post, 0, 100).astype(np.int64)
    fit_prob = np.where(idx > 0, _CDF[idx - 1], 0.0)

    # Weight so the bonus only breaks (near-)ties between comparable residuals,
    # not the primary best-fit ordering.
    return base + 0.5 * fit_prob
# EVOLVE-BLOCK-END
