# EVOLVE-BLOCK-START
"""Best fit with a residual-match bonus tuned to the item-size distribution.

Primary key is best fit (smallest post-placement residual -> largest priority).
A small bonus is added when the post-placement residual is close to a typical
item size, since such residuals are more likely to be exactly completed later.
"""
import numpy as np

# Typical item sizes for the Weibull-shaped distribution (mean ~40, range 1..100).
# A rough histogram used only to give residuals that "look fillable" a nudge.
_TYPICAL = np.array([5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80])


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit: smaller residual -> better. Use negative for "higher is better".
    key = -residual.astype(np.float64)
    # Bonus: residual close to a typical future item size is easier to complete.
    dist = np.abs(residual[:, None] - _TYPICAL[None, :]).min(axis=1)
    key += 0.01 / (1.0 + dist)
    return key
# EVOLVE-BLOCK-END
