# EVOLVE-BLOCK-START
"""Best fit with a bonus for residuals that leave useful gaps."""
import numpy as np

# Common small item sizes near the lower tail of the Weibull(mean ~40) distribution.
_USEFUL = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15])


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Base: best fit, prefer smallest residual.
    score = -residual.astype(np.float64)
    # Bonus: if the residual is a "useful" small size, nudge it up a bit.
    bonus = np.zeros(residual.shape, dtype=np.float64)
    mask = residual < 16
    if mask.any():
        r = residual[mask]
        # distance to nearest useful size; closer => higher bonus
        d = np.min(np.abs(r[:, None] - _USEFUL[None, :]), axis=1)
        bonus[mask] = -d * 0.01
    return score + bonus
# EVOLVE-BLOCK-END
