# EVOLVE-BLOCK-START
"""Online bin-choice rule: tightened best-fit with reusability shaping.

The empirical histogram proved noisy across instances, so this version drops
it and relies on a deterministic rule.  Score is dominated by best-fit (small
residual = tight packing), with exact fills heavily rewarded and unusable
slivers strongly penalized.  A deterministic complement term favors residuals
that sit near common item sizes (so the gap is easily reused), and empty bins
carry only a mild penalty.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item
    r = residual.astype(np.float64)

    # Primary: best fit -> prefer smallest residual (tightest packing).
    score = -np.clip(r, 0.0, 60.0)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    score += np.where(residual >= SMALL, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(r - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Deterministic complement bonus: favor residuals near the mode of the
    # size distribution (~40) and its multiples, where gaps reuse well.
    d = np.abs(r - TYPICAL)
    score += 6.0 / (1.0 + d)

    # Gently prefer already-used bins (keeps empty bins for large items).
    score += np.where(bins < 100, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
