# EVOLVE-BLOCK-START
"""Best fit with an exact-fit bonus and a mild penalty for opening a fresh bin."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    score = -residual.astype(np.float64)
    # Strongly reward exact fits.
    score += (residual == 0) * 200.0
    # Mildly penalize using a completely empty bin (capacity 100) when the
    # item is not itself near capacity, to encourage consolidation.
    score -= (bins == 100).astype(np.float64) * (0.5 if item < 90 else 0.0)
    return score
# EVOLVE-BLOCK-END
