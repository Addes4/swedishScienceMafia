# EVOLVE-BLOCK-START
"""Best-fit with a penalty for creating tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual.astype(np.float64)
    # Strongly avoid leaving a tiny residual (dead space smaller than a quarter item);
    # prefer an exact fit, then any residual, over leaving a tiny unusable gap.
    tiny = residual < (item // 4)
    score -= tiny * 1000.0
    score += (residual == 0) * 500.0
    return score
# EVOLVE-BLOCK-END
