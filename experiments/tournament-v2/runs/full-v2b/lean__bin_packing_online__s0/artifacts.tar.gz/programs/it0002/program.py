# EVOLVE-BLOCK-START
"""Hybrid best-fit: prefer tight fits, but rank by residual in a smoothed way to reduce fragmentation."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer the smallest residual (best fit), but give a tiny bonus to already-used bins
    # so that opening a fresh bin is only done when it is clearly better.
    score = -residual.astype(np.float64)
    # Slight preference for non-full (used) bins over empty (capacity 100) bins.
    used = bins < 100
    score += 1e-6 * used
    return score
# EVOLVE-BLOCK-END

