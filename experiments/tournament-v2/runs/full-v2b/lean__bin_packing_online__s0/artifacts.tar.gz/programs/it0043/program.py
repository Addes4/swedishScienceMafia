# EVOLVE-BLOCK-START
"""Best fit with a penalty for residuals that are too small to be useful."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    # Best-fit score: strongly prefer the smallest non-negative residual.
    score = -resid.astype(np.float64)
    # Penalize residuals in the "sliver" range (1..10), which waste capacity
    # because few arriving items are small enough to fill them.
    sliver = (resid > 0) & (resid <= 10)
    score -= 8.0 * sliver
    return score
# EVOLVE-BLOCK-END
