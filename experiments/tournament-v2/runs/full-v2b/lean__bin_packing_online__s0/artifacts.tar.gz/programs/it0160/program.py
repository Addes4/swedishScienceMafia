# EVOLVE-BLOCK-START
"""Online bin-choice rule: best-fit with a smooth reusability value.

Core idea: tightly pack (smallest residual) but slightly favor residuals that
remain broadly usable.  Exact fills are strongly rewarded.  A single smooth
"expected usefulness" term, derived from an empirical histogram of past item
sizes, replaces the previous pile of hand-tuned threshold bonuses.
"""
import numpy as np

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0

# Precompute the smoothing window (near-matches weighted more).
_OFFS = np.arange(-4, 5)
_W = np.array([0.15, 0.35, 0.60, 0.85, 1.0, 0.85, 0.60, 0.35, 0.15])


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item

    r = np.clip(residual.astype(np.float64), 0.0, None)
    score = -np.sqrt(r)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Smooth reusability value: a residual is more valuable the more likely a
    # future item can fit exactly into it.  Use a smoothed empirical density.
    if _COUNT > 50:
        prob = _HIST / _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        smoothed = np.zeros_like(r)
        for off, wt in zip(_OFFS, _W):
            idx = np.clip(ri + off, 0, 100)
            smoothed += wt * prob[idx]
        score += 60.0 * smoothed

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
