# EVOLVE-BLOCK-START
"""Online bin-choice rule: best-fit with empirical future-usability weighting.

The score for a bin is driven by two things:
  1) An exact-fill bonus when the item perfectly closes the bin.
  2) A "future usability" term: the probability that the residual gap can
     still accept some future item, estimated from the running histogram of
     past item sizes.  Residuals that stay broadly usable across the actual
     size distribution are preferred; tiny slivers are naturally penalized
     because almost no future item fits them.

Empty bins are kept slightly less attractive so they stay free for big items.
The empirical histogram adapts to whatever distribution is in play.
"""
import numpy as np

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item
    r = np.clip(residual.astype(np.float64), 0.0, None)

    # Best-fit core: smaller residual preferred, concave so exact fills win big.
    score = -np.sqrt(r)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Future-usability term from the running size histogram: probability that
    # the residual gap can still accept a future item.
    if _COUNT > 50:
        prob = _HIST / _COUNT
        # P(residual can accept a future item) = P(size <= residual).
        cdf = np.cumsum(prob)  # cdf[k] = P(size <= k)
        ri = np.clip(residual, 0, 100).astype(np.int64)
        usable = cdf[ri]
        # Reward broadly usable gaps; scale modestly so best-fit core dominates.
        score += 20.0 * usable

    # Penalize near-empty slivers that block usefulness but can't be refilled.
    sliver = (residual > 0) & (residual < 10)
    score -= np.where(sliver, 5.0, 0.0)

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1.0

    return score
# EVOLVE-BLOCK-END
