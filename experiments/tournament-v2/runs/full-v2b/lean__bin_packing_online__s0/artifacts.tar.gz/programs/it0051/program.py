# EVOLVE-BLOCK-START
"""Best fit with a preference for fresh bins on large items."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual
    # Prefer a fresh (empty) bin when the item is large, so we don't create
    # tight, awkward residuals in bins that could still hold several small items.
    if item > 55:
        score = score + (bins == 100) * (item - 55) * 2.0
    return score
# EVOLVE-BLOCK-END
