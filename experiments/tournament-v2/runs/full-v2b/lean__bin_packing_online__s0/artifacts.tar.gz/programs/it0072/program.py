# EVOLVE-BLOCK-START
"""Best fit with residual-usability tie-breaking tuned to the Weibull size distribution."""
import numpy as np

# Precompute a smooth proxy for the item-size distribution (Weibull-shaped, mean ~40 on 1..100).
_SIZES = np.arange(1, 101, dtype=np.float64)
# Weibull(k=~1.6, lambda=~45) clipped to 1..100, renormalized; mean ~40.
_k = 1.6
_lam = 45.0
_w = (_k / _lam) * (_SIZES / _lam) ** (_k - 1.0) * np.exp(-(_SIZES / _lam) ** _k)
_w = np.clip(_w, 1e-9, None)
_w /= _w.sum()

# For a residual r, value = expected fraction of r that can be filled by a future item.
# Approximate: a residual r is "usable" if a typical item can still fit; slivers near 0 are waste.
# Build a table indexable by residual 0..100.
_RES_VALUE = np.empty(101, dtype=np.float64)
for r in range(101):
    if r == 0:
        _RES_VALUE[r] = 0.0
    else:
        # Probability that some item of size <= r arrives and fits well; weight small items less
        # so we don't overrate tiny residuals. Use cumulative mass up to r scaled by r.
        cum = _w[:_SIZES.to_numpy() <= r].sum() if hasattr(_SIZES, "to_numpy") else _w[:_SIZES <= r].sum()
        cum = _w[:r].sum() if r <= 100 else 1.0
        _RES_VALUE[r] = cum if r < 1 else (cum)

# Simpler, robust table: residual usability ~ min(r, expected item) / expected item
_EXP_ITEM = float((_SIZES * _w).sum())
_RES_VALUE = np.minimum(np.arange(101, dtype=np.float64), _EXP_ITEM) / _EXP_ITEM


def priority(item, bins):
    """Rank bins by best-fit, with a mild preference for residuals that remain useful."""
    residual = bins - item
    # Primary: prefer smaller residual (best fit). Secondary: prefer more usable residual.
    usability = _RES_VALUE[residual]
    # Weight usability lightly so best-fit dominates; ties/near-ties resolved toward less waste.
    return -residual + 0.5 * usability
# EVOLVE-BLOCK-END
