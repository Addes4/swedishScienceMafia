# EVOLVE-BLOCK-START
"""Best fit, but avoid creating useless small residuals whenever possible."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Threshold: a residual below this is likely too small to be useful again.
    # Items have mean ~40, so residuals under ~25 are often wasted; reserve
    # capacity for bins that end at 0 or leave a reasonably usable gap.
    threshold = 25
    good = (residual == 0) | (residual >= threshold)
    # Prefer good bins (tightest among them); otherwise fall back to plain best fit.
    score = np.where(good, -(residual), -(residual) - 1000)
    return score
# EVOLVE-BLOCK-END
