# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  Two usability tiers (small and typical) let the
rule favor gaps that remain broadly reusable across the size distribution.
A light, principled exact-fill probability term (modeled Weibull-like sizes)
favors residuals likely to be filled exactly by a future item.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0

# Approximate probability that a future item exactly equals each residual 0..100,
# from a Weibull-shaped distribution with mean ~40.  Used as a light tie-breaker.
_PROB = np.zeros(101, dtype=np.float64)
for k in range(1, 101):
    x = float(k)
    # Weibull(shape ~1.6, scale ~44) discretized, roughly mean 40.
    pdf = (1.6 / 44.0) * (x / 44.0) ** 0.6 * np.exp(-((x / 44.0) ** 1.6))
    _PROB[k] = pdf
# Smooth slightly so nearby residuals share credit.
_sm = _PROB.copy()
for off in range(1, 4):
    _sm[off:] += 0.5 * _PROB[:-off]
    _sm[:-off] += 0.5 * _PROB[off:]
_PROB = _sm
_PROB /= _PROB.sum()


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    r = np.clip(residual.astype(np.float64), 0.0, None)
    score = -np.sqrt(r)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    score += np.where(residual >= SMALL, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    score += np.where(typical_ok, 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None), 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Light, principled exact-fill probability: favor residuals a future item
    # is likely to match exactly.  Kept small so best-fit core dominates.
    ri = np.clip(residual, 0, 100).astype(np.int64)
    score += 400.0 * _PROB[ri]

    # Gently prefer already-used bins (keeps empty bins for large items).
    score += np.where(bins < 100, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END

