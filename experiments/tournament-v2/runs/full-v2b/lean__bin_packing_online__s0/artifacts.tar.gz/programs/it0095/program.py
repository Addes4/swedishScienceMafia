# EVOLVE-BLOCK-START
"""Online bin-choice rule: prefer placements that leave a reusable residual.

Best fit minimizes the leftover gap, but a tiny leftover (1..20) can never hold
another item, so it is wasted capacity.  Instead we prefer the bin whose
residual after placement is either an exact fill (0) or large enough to still be
useful for a typical future item.  This keeps remaining capacity packable.
"""
import numpy as np

# Typical item size of the Weibull-shaped distribution (mean ~40).
TYPICAL = 40.0
# Residuals below this can rarely hold another item -> sliver.
SLIVER = 20.0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    # Base: prefer smaller residual (best fit), but measured in "usability" terms.
    score = -residual.astype(np.float64)

    # Strong bonus for a perfect fill (residual 0): no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize slivers (positive residual too small to be useful).
    sliver = (residual > 0) & (residual < SLIVER)
    score -= np.where(sliver, 30.0, 0.0)

    # Mild preference for residuals near a typical item size so the gap stays
    # fillable by a future item.
    score -= 0.05 * np.abs(residual - TYPICAL)

    return score
# EVOLVE-BLOCK-END
