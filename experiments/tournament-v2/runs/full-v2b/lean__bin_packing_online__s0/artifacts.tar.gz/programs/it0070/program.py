# EVOLVE-BLOCK-START
"""Randomized-key best fit: rank bins by residual, with tiny deterministic jitter."""
import numpy as np

_rng = np.random.default_rng(12345)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Best-fit base score: prefer smallest residual after placement.
    residual = bins - item
    jitter = _rng.random(bins.shape[0]) * 0.5
    return -residual.astype(np.float64) + jitter
# EVOLVE-BLOCK-END
