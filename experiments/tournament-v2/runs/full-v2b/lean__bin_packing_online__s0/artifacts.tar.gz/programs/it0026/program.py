# EVOLVE-BLOCK-START
"""Best fit with a size-aware residual-reuse tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item  # remaining capacity after placing the item
    # Primary: best fit -> smallest residual (all residuals >= 0 since item fits).
    # Secondary tie-break: for small items, break exact ties in residual by using a
    # deterministic bin-order-independent-ish key. Since ties go to first bin anyway,
    # keep primary key dominant and add a tiny secondary term that only matters on ties.
    score = -resid.astype(np.float64)
    # On equal residual, favor residuals that can still hold a "typical" small item.
    # This is a pure tie-break (tiny epsilon), so best-fit selection is preserved.
    reuse = np.where((resid == 0), 0, resid >= 40)
    score = score * 1000.0 + reuse.astype(np.float64)
    return score
# EVOLVE-BLOCK-END
