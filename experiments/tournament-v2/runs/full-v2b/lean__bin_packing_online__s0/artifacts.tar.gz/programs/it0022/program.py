# EVOLVE-BLOCK-START
"""Best fit with a stateful, mean-aligned tie-break on the residual."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smallest residual). Secondary: residual close to a multiple
    # of the running mean item size, so leftovers stay reusable.
    mean = _state.get("mean", 40.0)
    n = _state.get("n", 0)
    m = mean if mean > 1.0 else 40.0
    # distance to nearest multiple of m
    d = residual % m
    align = np.minimum(d, m - d)
    # scale into a small secondary term; primary dominates by construction.
    score = -(residual * 1000.0) - align
    # state update: exponential mean of item sizes
    _state["n"] = n + 1
    a = 0.01
    _state["mean"] = (1.0 - a) * mean + a * item
    return score


_state = {"mean": 40.0, "n": 0}
# EVOLVE-BLOCK-END
