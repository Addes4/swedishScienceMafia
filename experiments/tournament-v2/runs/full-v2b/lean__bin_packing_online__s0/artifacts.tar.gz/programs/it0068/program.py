# EVOLVE-BLOCK-START
"""Two-dimensional best fit: primary term is post-placement residual,
secondary term (small) prefers the bin that was already fuller."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`.

    Primary: minimize post-placement residual (best fit).
    Secondary (tiny weight): prefer bins that were fuller before placement,
    which empirically reduces stranded small residuals.
    """
    residual_after = bins - item
    return -residual_after.astype(np.float64) - 0.001 * bins.astype(np.float64)
# EVOLVE-BLOCK-END
