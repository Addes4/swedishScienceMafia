# EVOLVE-BLOCK-START
"""Best fit with a mild consolidation bonus toward fuller bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary: best fit (smallest residual after placement) -> negative.
    # Secondary: small bonus for fuller bins to consolidate packing.
    fullness = 100 - bins
    return -residual + 1e-3 * fullness
# EVOLVE-BLOCK-END
