# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Core idea: exact fills are strongly rewarded, otherwise we prefer the
smallest residual (best fit) so that gaps stay concentrated.  A residual
that can still host a small future item is more useful than one that
cannot, so we give such residuals a modest bonus.  Empty bins are kept
slightly less attractive so they stay free for large items.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item
    rf = residual.astype(np.float64)

    # Primary: best fit -> prefer smallest residual (tightest packing).
    # Bounded so it doesn't dominate the soft usability terms.
    score = -np.clip(rf, 0.0, 60.0)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    small_ok = residual >= SMALL
    score += np.where(small_ok, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(rf - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Empirical-fill bonus: if a residual equals a size we've seen often,
    # a future item may fill it exactly, so favor such residuals.
    # Sharp: weight the exact bucket heavily, near-misses only lightly.
    if _COUNT > 50:
        prob = _HIST / _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        lo = np.clip(ri - 1, 0, 100)
        hi = np.clip(ri + 1, 0, 100)
        smoothed = 0.1 * prob[lo] + 0.8 * prob[ri] + 0.1 * prob[hi]
        score += 200.0 * smoothed

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
