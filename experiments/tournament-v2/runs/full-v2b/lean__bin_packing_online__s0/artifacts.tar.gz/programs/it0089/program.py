# EVOLVE-BLOCK-START
"""Best fit with a bonus for perfect/very tight fills."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit primary: smaller residual is better.
    score = -residual.astype(np.float64)
    # Strong bonus for perfect fills (residual 0) so we never pass them up.
    score += 0.5 * (residual == 0)
    return score
# EVOLVE-BLOCK-END
