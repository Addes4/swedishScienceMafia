# EVOLVE-BLOCK-START
"""Best fit with a small preference to delay opening brand-new bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    # Best-fit base score: smaller residual is better.
    score = -resid.astype(np.float64)
    # Penalize using a completely empty (100) bin: give any existing non-full bin a boost
    # so we consolidate before opening a new one, unless best-fit is clearly better.
    empty = bins >= 100
    score[empty] -= 0.5
    return score
# EVOLVE-BLOCK-END
