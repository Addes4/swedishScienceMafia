# EVOLVE-BLOCK-START
"""Best fit with a sliver-avoidance guard.

Pure best fit minimizes the leftover, but it often leaves tiny residuals that
cannot fit any later item, effectively wasting that capacity.  We keep best fit
as the primary rule but, when several bins fit, prefer one whose residual after
placement is either zero or large enough to still accept a small upcoming item.
The "small" threshold adapts upward over time using observed item sizes.
"""
import numpy as np


class _State:
    n = 0
    total = 0
    small_count = 0

    @classmethod
    def update(cls, item):
        cls.n += 1
        cls.total += item
        # crude running estimate of a "small" item size (10th percentile-ish)
        if cls.n <= 1:
            cls.avg_small = float(item)
        else:
            a = 0.002
            cls.avg_small = (1.0 - a) * cls.avg_small + a * float(item)


def priority(item, bins):
    _State.update(item)
    residual = bins - item  # leftover if item placed in each bin (>=0 since it fits)

    # threshold: below this leftover a later item is unlikely to fit well
    thr = max(8.0, min(20.0, _State.avg_small))

    safe = (residual == 0) | (residual >= thr)
    score = -residual.astype(np.float64)
    # give safe bins a strong bonus so they win over unsafe-but-tighter bins
    bonus = 1000.0
    return score + bonus * safe
# EVOLVE-BLOCK-END
