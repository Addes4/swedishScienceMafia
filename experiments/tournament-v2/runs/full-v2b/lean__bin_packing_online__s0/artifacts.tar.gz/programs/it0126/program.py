# EVOLVE-BLOCK-START
"""Online bin-choice rule: best-fit with empirical exact-fill awareness.

Primary signal is best-fit (smallest residual) with a strong exact-fill bonus.
A histogram of past item sizes identifies residuals that a future item is
likely to fill exactly; such residuals get a large bonus so gaps are
concentrated into closeable units. Empty bins are mildly de-preferred to keep
them available for large items.
"""
import numpy as np

SMALL = 20.0

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit -> prefer smallest residual (tightest packing).
    score = -np.clip(residual.astype(np.float64), 0.0, 60.0)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Empirical-fill bonus: residuals matching a frequently-seen item size are
    # likely to be closed exactly by a future item.
    if _COUNT > 50:
        prob = _HIST / _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        score += 200.0 * prob[ri]

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 20.0, 0.0)

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
