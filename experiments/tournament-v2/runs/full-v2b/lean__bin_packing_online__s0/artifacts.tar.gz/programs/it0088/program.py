# EVOLVE-BLOCK-START
"""Best fit with empty-bin reservation.

Primary rule: minimize the post-placement residual (best fit).  But prefer
already-used bins over empty ones by a modest penalty, keeping empty bins free
for future large items.  The penalty is small enough to be overridden by a
meaningfully better fit, so tight fits still win.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Best fit primary: prefer smallest residual.
    score = -residual.astype(np.float64)
    # Empty bins (residual == 100 - item) get a modest penalty so they are only
    # chosen when no used bin gives a comparably tight fit.
    empty_mask = bins == 100
    score -= 2.0 * empty_mask
    return score
# EVOLVE-BLOCK-END
