# EVOLVE-BLOCK-START
"""Online bin-choice rule: best-fit with achievable-gap targeting.

Core: strongly reward exact fills; otherwise prefer the tightest residual
(best-fit) to concentrate gaps. Then reward residuals that the empirical
size distribution predicts are likely to be exactly filled by a future item,
and lightly prefer already-used bins so empty bins stay available for large
items.
"""
import numpy as np

_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins.astype(np.float64) - item

    # Best-fit base: tighter residual is better.
    score = -residual

    # Exact fill: ideal, no waste.
    score += np.where(residual == 0, 1e6, 0.0)

    # Empirical probability that a future item exactly fills this residual.
    if _COUNT > 50:
        prob = _HIST / _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        lo = np.clip(ri - 1, 0, 100)
        hi = np.clip(ri + 1, 0, 100)
        smoothed = 0.15 * prob[lo] + 0.7 * prob[ri] + 0.15 * prob[hi]
        score += 200.0 * smoothed

    # Gently prefer already-used bins so empty bins remain for large items.
    score += np.where(bins < 100, 3.0, 0.0)

    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
