# EVOLVE-BLOCK-START
"""Best-fit with harmonic residual shaping.

Pure best-fit picks the bin minimizing resulting residual. That is optimal for
filling single bins but fragments the free space into many unusable slivers.
We keep best-fit as the primary key but add a small secondary preference for
residuals that are themselves "completable": a residual of 0 (exact fit) or a
residual that matches a stored set of good target residuals derived from a
running histogram of item sizes. This nudges the packing toward residuals that
future items can fill, without changing the tightness ordering much.
"""
import numpy as np

_STATE = {"n": 0, "sum": 0, "hist": np.zeros(101, dtype=np.float64)}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    st = _STATE
    st["n"] += 1
    st["sum"] += item
    st["hist"][item] += 1.0

    residual = bins - item  # resulting free space per bin (>= 0)

    # Primary: prefer tight fits (small residual). Use -residual as base score.
    score = -residual.astype(np.float64)

    # Secondary: nudge residuals that are exactly 0 or that equal a plausible
    # upcoming item size (so a future item can fill the bin completely).
    # Estimate upcoming sizes from the running histogram.
    n = st["n"]
    if n > 50:
        hist = st["hist"]
        total = hist.sum()
        # A residual r is "good" with weight proportional to the probability of
        # an item exactly size r arriving (small smoothing to allow all r).
        probs = (hist + 0.5) / (total + 0.5 * 101.0)
        # Bonus for residual r is the probability that an arriving item can fill
        # it exactly, plus a big bonus for residual 0.
        bonus = 0.0 * residual  # placeholder to keep float types
        bonus = probs[residual.astype(np.int64)] * 6.0
        score = score + bonus
        # Extra explicit bonus for exact fits.
        score = score + np.where(residual == 0, 0.25, 0.0)

    return score
# EVOLVE-BLOCK-END
