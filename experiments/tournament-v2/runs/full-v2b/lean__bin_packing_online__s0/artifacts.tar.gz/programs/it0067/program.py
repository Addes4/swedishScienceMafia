# EVOLVE-BLOCK-START
"""Best fit with a dead-zone penalty on unusable residuals."""
import numpy as np


def priority(item, bins):
    """Rank bins by residual after placement, penalizing unusable slivers.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    residual = bins - item

    # Dead zone: residuals too small to fit the smallest items seen recently,
    # but large enough to waste capacity. Penalize them so we prefer bins that
    # leave a residual usable by a typical small item.
    # Small item sizes in this distribution are roughly 1..15; penalize leaving
    # a residual in [1, 14] more than leaving 0 or leaving >= 15.
    dead = (residual >= 1) & (residual <= 14)
    # Base best-fit: prefer smallest residual. Add penalty for dead zone.
    return -residual - 1000.0 * dead
# EVOLVE-BLOCK-END
