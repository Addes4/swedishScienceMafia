# EVOLVE-BLOCK-START
"""Size-class adaptive best fit."""
import numpy as np

_state = {"n": 0, "sum": 0.0}


def priority(item, bins):
    """Score each bin; highest score wins (ties go to the first bin).

    Uses best-fit (tightest residual) as the base, with an adaptive
    size-class blend: large items slightly prefer fuller bins (leave a
    bigger residual for future large items), small items stay tight.
    """
    _state["n"] += 1
    _state["sum"] += item
    mean_item = _state["sum"] / _state["n"]

    residual = bins - item

    # Base: tightest residual is best.
    base = -residual.astype(np.float64)

    if item >= mean_item:
        # Large-ish item: mildly prefer bins that were fuller (smaller bins).
        # Scaled so it only breaks near-ties, never overrides tightness.
        base += 0.05 * -(bins.astype(np.float64))

    return base
# EVOLVE-BLOCK-END
