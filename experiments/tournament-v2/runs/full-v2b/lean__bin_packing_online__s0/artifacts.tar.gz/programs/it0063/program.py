# EVOLVE-BLOCK-START
"""Best fit with a mild preference for fuller bins among near-ties."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # residual after placement (smaller residual = tighter fit = better)
    residual = bins - item
    # primary: tightest fit; secondary: prefer already-fuller bins
    return -residual * 1000.0 - bins
# EVOLVE-BLOCK-END
