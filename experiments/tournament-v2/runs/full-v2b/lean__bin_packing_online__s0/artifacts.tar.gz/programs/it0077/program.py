# EVOLVE-BLOCK-START
"""Best-fit with a small bonus for residuals that are likely to be refilled exactly."""
import numpy as np


def priority(item, bins):
    """Rank bins: prefer tight fits, with a nudge toward reusable residuals.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Prefer small residuals (best fit). Add a tiny bonus to push perfect fills
    # (residual 0) ahead of near-ties, since a completed bin is pure profit.
    score = -residual.astype(np.float64)
    score += 1e-3 * (residual == 0)
    return score
# EVOLVE-BLOCK-END

