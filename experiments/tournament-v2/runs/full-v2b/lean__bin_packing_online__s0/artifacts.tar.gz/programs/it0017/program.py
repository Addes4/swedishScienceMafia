# EVOLVE-BLOCK-START
"""Best-fit with a residual "usefulness" bonus learned from a running item histogram."""
import numpy as np

# state
_hist = np.zeros(101, dtype=np.float64)   # counts of seen item sizes
_seen = 0
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _seen, _total

    # update histogram with the arriving item (before scoring is fine; it is a past item)
    _hist[item] += 1.0
    _seen += 1
    _total += item

    resid = bins - item  # remaining capacity after placing item here

    # Probability mass of past items that exactly equals each possible residual.
    # A residual r is "useful" if some past item size == r (then a future similar item fills it exactly).
    # Normalize the histogram to a probability vector over sizes 0..100 (index 0 unused).
    if _seen > 0:
        p = _hist / _seen
    else:
        p = _hist

    # For each bin, usefulness of the residual equals p[resid] (probability a future item exactly fills it).
    # Clip residual to valid range for indexing (resid is 0..100).
    r = resid
    np.clip(r, 0, 100, out=r)
    usefulness = p[r.astype(np.int64)]

    # Primary: best fit (smaller residual better). Secondary: usefulness bonus.
    # Use a weighted combination: strongly prefer tight fits, add the usefulness bonus scaled.
    score = -(resid) + 5.0 * usefulness
    return score
# EVOLVE-BLOCK-END
