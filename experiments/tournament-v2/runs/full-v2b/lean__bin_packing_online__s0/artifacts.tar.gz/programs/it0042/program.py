# EVOLVE-BLOCK-START
"""Best fit with a mild sliver-avoidance bonus.

Standard best fit minimizes the residual (bins - item), i.e. score = -(bins - item).
Pure best fit already performs near the best known online rule, but it occasionally
creates tiny useless slivers (residual 1..9) that can never hold another item and thus
waste capacity.  We keep best fit as the dominant criterion and only add a *tiny*
bonus (strictly smaller than the granularity that could reorder genuinely different
residuals) that slightly prefers bins whose resulting residual is either 0 (perfectly
full) or large enough to be usable (>= 10).  This breaks near-ties in favour of
non-sliver residuals without ever overriding a clearly better fit.
"""
import numpy as np


def priority(item, bins):
    """Score each fitting bin; highest score wins, ties to the first bin.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities of all fitting bins (unused = 100).
    """
    residual = bins - item
    # Dominant term: best fit (minimize residual => maximize -(residual)).
    score = -residual.astype(np.float64)
    # Mild bonus: prefer residuals that are 0 or large enough to be usable.
    good = (residual == 0) | (residual >= 10)
    score += good.astype(np.float64) * 0.5
    return score
# EVOLVE-BLOCK-END
