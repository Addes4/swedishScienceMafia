# EVOLVE-BLOCK-START
"""Online bin-choice rule: concentrated best-fit with modal-gap targeting.

Primary signal is best-fit (smallest residual after placement) so gaps are
concentrated rather than scattered.  Exact fills get a huge reward.  A single
soft term favors residuals that are large enough to remain usable (>= a small
threshold) while a penalty suppresses unusably tiny slivers.  Empty bins are
mildly deprioritized to keep them available for large items.  A light
empirical term rewards residuals matching frequently seen item sizes so that
gaps can be closed exactly by likely future items.
"""
import numpy as np

SMALL = 20.0

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT

    residual = bins - item  # remaining capacity after placing the item
    res = residual.astype(np.float64)

    # Primary: best fit -> prefer smallest residual, bounded gently.
    score = -np.minimum(res, 50.0)

    # Exact fill: ideal, no waste.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can still host a small item: valuable, keep gap reusable.
    score += np.where(residual >= SMALL, 5.0, 0.0)

    # Suppress unusable slivers (positive but smaller than SMALL).
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 25.0, 0.0)

    # Empirical closeability: favor residuals equal to likely future sizes.
    if _COUNT > 50:
        prob = _HIST / _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        score += 200.0 * prob[ri]

    # Mildly prefer already-used bins to keep empties for large items.
    score += np.where(bins < 100, 1.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
