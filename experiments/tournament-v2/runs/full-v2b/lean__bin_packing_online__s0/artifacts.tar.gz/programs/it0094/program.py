# EVOLVE-BLOCK-START
"""Best fit with an explicit penalty for small unusable residual slivers."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    r = bins - item
    score = -(r.astype(np.float64))
    # Reward perfect fills and penalize tiny unusable slivers (0 < r <= 20).
    score += np.where(r == 0, 8.0, 0.0)
    small = (r > 0) & (r <= 20)
    score -= np.where(small, (21.0 - r) * 0.5, 0.0)
    return score
# EVOLVE-BLOCK-END
