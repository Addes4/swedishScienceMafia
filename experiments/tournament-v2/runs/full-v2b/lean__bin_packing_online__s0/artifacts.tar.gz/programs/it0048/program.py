# EVOLVE-BLOCK-START
"""Best fit with a concave penalty on the post-placement residual.

Classic best fit minimizes the leftover capacity in the chosen bin. Pure best fit
often leaves tiny slivers (residual 1..k) that can never accept a real item, so
those bins are effectively wasted. We keep the "pack tight" spirit but score bins
by the leftover *after* placement, transformed so that extremely small leftovers
are penalized relative to slightly larger ones. This nudges the choice toward a
bin whose leftover is small but still usable, without ever diverging far from
best fit (the dominant behavior on the Weibull mixture).
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Concave transform of the residual: we want to *maximize* priority, and we
    # prefer small residuals, so use the negative of a concave increasing map.
    # With sqrt, residuals 0..10 give -0,-1,-1.41,-1.73,-2,-2.24,...  The map is
    # monotone, so ordering is unchanged for exact values; using a scaled integer
    # residual with a mild floor on the very small values breaks ties toward
    # usable slivers while staying essentially best-fit.
    r = residual.astype(np.float64)
    # Penalize residuals in the "dead zone" (1..12) since items have mean ~40 and
    # rarely fit there; treat them as worse than a slightly larger leftover.
    pen = np.where((r >= 1) & (r <= 12), r + 6.0, r)
    return -pen
# EVOLVE-BLOCK-END
