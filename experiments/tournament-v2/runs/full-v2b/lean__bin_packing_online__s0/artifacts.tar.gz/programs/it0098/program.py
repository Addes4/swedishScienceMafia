# EVOLVE-BLOCK-START
"""Online bin-choice rule: prefer placements that leave a reusable residual.

Best fit minimizes the leftover gap, but a tiny leftover can never hold another
item, so it is wasted capacity.  We prefer the bin whose residual after
placement is either an exact fill (0) or large enough to still be useful for a
typical future item, and we gently prefer already-used bins (capacity < 100) to
keep empty bins available for large future items.
"""
import numpy as np

TYPICAL = 40.0
SLIVER = 20.0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    score = -residual.astype(np.float64)

    # Strong bonus for a perfect fill (no waste).
    score += np.where(residual == 0, 1000.0, 0.0)

    # Penalize slivers (positive residual too small to be useful).
    sliver = (residual > 0) & (residual < SLIVER)
    score -= np.where(sliver, 30.0, 0.0)

    # Mild preference for residuals near a typical item size so the gap stays
    # fillable by a future item.
    score -= 0.05 * np.abs(residual - TYPICAL)

    # Prefer building on already-partially-filled bins; keeping some empty
    # bins for large items.  Scale the preference so it never overrides the
    # residual-quality ranking but reliably drives packing density.
    used = bins < 100
    score += np.where(used, TYPICAL, 0.0)

    return score
# EVOLVE-BLOCK-END
