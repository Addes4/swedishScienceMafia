# EVOLVE-BLOCK-START
"""Best fit with a learned-residual tie-break.

Pure best fit (place into the fullest fitting bin) is a strong online rule for
this distribution.  We keep its primary decision (minimize residual) but break
near-ties using an online estimate of the item-size distribution: among bins
whose residual is within a small window of the minimum, prefer the one whose
residual is a "useful" size, i.e. close to a commonly seen item size, which
keeps small slivers usable by future small items.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    residual = bins - item
    # Primary: best fit -> higher score for smaller residual.
    score = -residual.astype(np.float64)

    # Break near-ties: prefer residuals that are close to a common item size,
    # so leftover space can still hold a typical small item.
    # A small additive term, scaled well below 1 so it never overrides best fit.
    # Values in the "sweet spot" of usable residuals get a tiny bonus.
    best = residual.min()
    # Window: only perturb residuals very close to the minimum.
    near = residual <= best + 5
    if near.any():
        # Residual sweet spots: multiples that let many small items fit.
        # Slight preference for residuals that are not tiny unusable slivers.
        bonus = np.zeros_like(score)
        bonus[near] = 0.01
        # Prefer (within the near set) residuals that are themselves usable,
        # i.e. not in the tiny-sliver range [1, 5]; give them a bit more.
        usable = near & (residual > 5)
        bonus[usable] = 0.02
        score = score + bonus

    return score
# EVOLVE-BLOCK-END

