# EVOLVE-BLOCK-START
"""Best fit, but keep one empty bin in reserve to avoid opening new bins prematurely."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    n = bins.shape[0]
    empty = bins >= 100  # fully empty bins
    nonempty_fit = ~empty  # partially filled bins that can fit the item

    # If any partially-filled bin can fit the item, only rank those (avoid opening new bins).
    # Otherwise fall back to best fit over all bins.
    if nonempty_fit.any():
        # Score partially-filled bins by tightest fit; empty bins get very low score.
        scores = np.where(nonempty_fit, -(bins - item), np.iinfo(np.int64).min)
    else:
        scores = -(bins - item)
    return scores
# EVOLVE-BLOCK-END
