# EVOLVE-BLOCK-START
"""Best fit with light deterministic tie-breaking noise to avoid pathological slivers."""
import numpy as np

_state = {"mass": 0}


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    total = int(bins.shape[0])
    resid = bins - item  # remaining capacity after placing item

    # Base: prefer tightest fit (smallest residual).
    best = int(resid.min())

    # Tiny deterministic noise for near-best candidates to diversify ties.
    _state["mass"] = (_state["mass"] * 1000003 + item * 2654435761) & 0x7FFFFFFF
    seed = _state["mass"]
    idx = np.arange(total, dtype=np.int64)
    noise = ((idx * 1103515245 + seed * 12345 + 7) & 0xFFFF) / 65536.0

    # Candidates within a small window of best get noise; others are strictly worse.
    score = -resid.astype(np.float64)
    window = 3.0
    mask = resid <= best + window
    score[mask] += noise[mask] * 0.9
    return score
# EVOLVE-BLOCK-END
