# EVOLVE-BLOCK-START
"""Best fit with a small bonus for keeping bins able to fit another similar item."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    score = -residual.astype(np.float64)
    # bonus for bins that will still fit another item of this size
    score += 1e-6 * (residual >= item)
    return score
# EVOLVE-BLOCK-END
