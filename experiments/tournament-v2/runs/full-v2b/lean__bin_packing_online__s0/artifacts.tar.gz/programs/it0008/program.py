# EVOLVE-BLOCK-START
"""Best fit with exact-fit bonus and empty-bin penalty."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    b = bins.astype(np.float64)
    residual = b - item

    # Base: prefer smallest residual (best fit).
    score = -residual

    # Strong bonus for exact fit (residual == 0).
    score += 1000.0 * (residual == 0)

    # Mild bonus for near-perfect fits (residual small relative to a bin).
    score += 50.0 * (residual <= 2)

    # Penalize opening a fresh bin (residual would be 100 - item, untouched bin).
    score -= 3.0 * (b == 100.0)

    return score
# EVOLVE-BLOCK-END
