# EVOLVE-BLOCK-START
"""Best fit with a guard against creating tiny unusable residuals."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Best fit primary score: higher (less negative) is better.
    base = -residual.astype(np.float64)
    # Penalize tiny positive residuals that are likely unusable, but leave 0 alone.
    tiny = (residual > 0) & (residual < item)
    base[tiny] -= 1e-6 * (item - residual[tiny])
    return base
# EVOLVE-BLOCK-END

