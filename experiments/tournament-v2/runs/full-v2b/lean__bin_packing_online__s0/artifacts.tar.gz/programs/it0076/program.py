# EVOLVE-BLOCK-START
"""Best fit with a size-aware residual-completion tie-break.

Primary rule: choose the bin with the smallest post-placement residual (best fit).
Tie-break: among bins that leave (nearly) the same residual, prefer the bin whose
resulting residual exactly equals a frequently-seen item size, since such a residual
is likely to be exactly filled by a future item, avoiding stranded slivers.
State: a running count of observed item sizes across calls.
"""
import numpy as np

# running frequency of item sizes seen so far (index 1..100)
_FREQ = np.zeros(101, dtype=np.float64)
_TOTAL = 0.0


def priority(item, bins):
    global _TOTAL
    n = bins.shape[0]

    # post-placement residual for each bin
    resid = bins - item  # non-negative for bins we are shown

    # update item-size statistics (used to weight residual desirability)
    _FREQ[item] += 1.0
    _TOTAL += 1.0

    # frequency weight of a residual value r: how often we've seen exactly r
    # normalize mildly to keep the term bounded
    freq = _FREQ / (1.0 + _TOTAL)

    # primary key: smaller residual is better -> use negative residual as score
    # secondary: exact-match bonus for the residual being a common item size
    #           (helps future items exactly complete the bin)
    # We scale the bonus small enough that it only breaks near-ties.
    match_bonus = freq[resid.clip(0, 100)]

    # tiny bonus also to prefer smaller residuals (best-fit) strongly
    return -resid.astype(np.float64) + 0.5 * match_bonus
# EVOLVE-BLOCK-END
