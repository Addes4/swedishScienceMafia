# EVOLVE-BLOCK-START
"""Best fit with a tie-break that favors reusing already-used bins."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Prefer the tightest fit: minimize remaining capacity after placing the item.
    residual = bins - item
    # Tie-break: slightly favor bins that are already partially used (smaller bins),
    # so we avoid opening fresh bins when the tightness is comparable.
    used = 100 - bins
    return -residual.astype(np.float64) + 1e-3 * used
# EVOLVE-BLOCK-END

