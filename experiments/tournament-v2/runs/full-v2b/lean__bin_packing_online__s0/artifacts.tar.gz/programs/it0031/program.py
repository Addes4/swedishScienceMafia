# EVOLVE-BLOCK-START
"""Best fit with a penalty for leaving unusable slivers.

Pure best fit minimizes the immediate leftover, which tends to create tiny
slivers that no future item can use.  Here we still prefer tight fits, but we
add a small penalty when the resulting residual falls in the "sliver zone"
(positive but smaller than a typical item size), nudging the choice toward
bins whose leftover is either exactly zero or large enough to still be useful.
"""
import numpy as np

MEAN_ITEM = 40.0


def priority(item, bins):
    residual = bins - item  # >= 0 because bins only contains fitting bins

    # Tight fit: smaller residual -> larger score.
    score = -residual.astype(np.float64)

    # Penalize non-zero residuals that are too small to accept a typical item.
    sliver = (residual > 0) & (residual < MEAN_ITEM)
    penalty = np.where(sliver, (MEAN_ITEM - residual) / MEAN_ITEM, 0.0)
    score -= 0.5 * penalty

    return score
# EVOLVE-BLOCK-END
