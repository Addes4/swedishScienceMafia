# EVOLVE-BLOCK-START
"""Sum-of-squares balancing bin choice.

Score each bin by how much the item reduces the squared unused capacity of the
bin, i.e. prefer placements that leave the emptiest bins emptier and fill fuller
bins tightly. Falls back to best-fit among equally good candidates.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array of remaining capacities (including empty bins = 100).
    """
    residual = bins - item
    # Prefer filling tightest when residual is tiny, otherwise reduce squared waste.
    score = -(residual * residual)
    return score
# EVOLVE-BLOCK-END
