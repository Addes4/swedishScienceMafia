# EVOLVE-BLOCK-START
"""Best fit with sliver avoidance: prefer exact fills and usable residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item  # >= 0 since item fits

    # Threshold below which a residual is considered a "sliver" (hard to reuse).
    # Distribution mean ~40, so a residual smaller than ~20 is unlikely to be filled.
    sliver = 20

    # Base score: tightly packed bins rank higher (smaller residual -> higher score).
    score = -residual.astype(np.float64)

    # Penalize slivers: residuals in (0, sliver) are bad because they strand capacity.
    # Exact fill (residual == 0) is best; residuals >= sliver are fine (reusable).
    is_sliver = (residual > 0) & (residual < sliver)
    score[is_sliver] -= 1000.0

    # Also mildly penalize opening brand-new bins (residual would be 100 - item),
    # to avoid premature bin opening, unless nothing else fits.
    new_bin = residual == (100 - item) if item < 100 else np.zeros_like(residual, dtype=bool)
    score[new_bin] -= 1.0

    return score
# EVOLVE-BLOCK-END
