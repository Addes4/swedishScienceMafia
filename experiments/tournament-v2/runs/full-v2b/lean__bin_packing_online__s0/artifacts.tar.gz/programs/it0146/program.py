# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  Two usability tiers (small and typical) let the
rule favor gaps that remain broadly reusable across the size distribution.
A deterministic static prior for closeable residuals replaces the noisy
empirical histogram: residuals matching a likely future item size get a mild
boost so gaps can be closed exactly.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0

# Static prior over item sizes (Weibull-shaped, mean ~40).
_GRID = np.arange(101, dtype=np.float64)
_LAM = 45.0
_SHAPE = 1.5
_W = (_SHAPE / _LAM) * (_GRID / _LAM) ** (_SHAPE - 1.0) * np.exp(-(_GRID / _LAM) ** _SHAPE)
_W[0] = 0.0
_W = _W / _W.sum()


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit -> prefer smallest residual (tightest packing).
    score = -np.clip(residual.astype(np.float64), 0.0, 60.0)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    small_ok = residual >= SMALL
    score += np.where(small_ok, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Static closeability bonus: reward residuals that a likely future item
    # can fill exactly, using the deterministic size prior instead of noisy
    # empirical counts.  Near-misses are weighted lightly.
    ri = np.clip(residual, 0, 100).astype(np.int64)
    lo = np.clip(ri - 1, 0, 100)
    hi = np.clip(ri + 1, 0, 100)
    smoothed = 0.15 * _W[lo] + 0.7 * _W[ri] + 0.15 * _W[hi]
    score += 150.0 * smoothed

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
