# EVOLVE-BLOCK-START
"""Online bin-choice rule: best-fit with a sharp single-item gap-closure bonus.

Core idea: prefer the tightest feasible placement (smallest residual) so gaps
stay concentrated and reusable, but boost a residual strongly when it matches a
currently common item size, since a future arrival is then likely to close it
exactly.  Scores are computed with cheap numpy ops to respect the time limit.
"""
import numpy as np

SMALL = 20.0

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0.0

# Cached probability vector, refreshed periodically.
_PROB = None
_LAST_REFRESH = -1


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT, _PROB, _LAST_REFRESH

    residual = bins - item  # remaining capacity after placing the item
    resid_f = residual.astype(np.float64)

    # Primary: best fit -> smallest residual, bounded so soft terms can act.
    score = -np.clip(resid_f, 0.0, 60.0)

    # Exact fill: ideal.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Gap-closure bonus from the empirical size distribution: if residual is a
    # common item size, reward it; if residual is a sliver (< SMALL) that no
    # likely item fits, penalize it.
    if _COUNT > 50:
        if _LAST_REFRESH < 0 or _COUNT - _LAST_REFRESH >= 64:
            _PROB = _HIST / _COUNT
            _LAST_REFRESH = _COUNT
        prob = _PROB
        ri = residual
        # bucket probability at the exact residual (clip to valid range)
        idx = np.clip(ri, 0, 100).astype(np.int64)
        gap_ok = (ri > 0) & (ri <= 100)
        bonus = np.where(gap_ok, 400.0 * prob[idx], 0.0)
        score += bonus

    # Sliver penalty: positive residuals too small to hold a small item.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Slight preference for already-used bins over empty ones.
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1.0

    return score
# EVOLVE-BLOCK-END
