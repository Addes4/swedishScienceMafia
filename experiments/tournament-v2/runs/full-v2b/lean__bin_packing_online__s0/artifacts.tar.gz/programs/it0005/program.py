# EVOLVE-BLOCK-START
"""Best-fit variant: pack tightly, but avoid opening a new bin when a used bin is equally tight."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    score = -residual.astype(np.float64)
    # Prefer non-empty bins (bins whose remaining capacity < 100) over empty ones
    # when their tightness is identical, to avoid opening unnecessary new bins.
    used = (bins < 100)
    score += used * 1e-3
    return score
# EVOLVE-BLOCK-END
