# EVOLVE-BLOCK-START
"""Best fit with a mild preference for filling bins that leave small residuals."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    residual = bins - item
    # Primary goal: smallest resulting residual (best fit).
    # Slight secondary bias: among near-equal residuals prefer the bin that is more filled
    # (smaller residual) encoded by the residual itself; add a tiny penalty for leaving a
    # residual exactly equal to the item (a bin that this exact item could have fully used).
    score = -residual.astype(np.float64)
    # Penalize the case where residual equals item, so we avoid creating a slot that
    # duplicates the current item size unnecessarily.
    score -= 1e-3 * (residual == item).astype(np.float64)
    return score
# EVOLVE-BLOCK-END
