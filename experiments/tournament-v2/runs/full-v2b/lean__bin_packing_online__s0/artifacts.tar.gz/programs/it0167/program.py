# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  Reusability is estimated empirically by convolving
the running histogram of past item sizes, so residuals whose fill probability
is high under the actual distribution are favored.
Empty bins are kept slightly less attractive so they stay free for large items.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0

# Empirical histogram of past item sizes, accumulated across calls.
_HIST = np.zeros(101, dtype=np.float64)
_COUNT = 0
# Cached cumulative accessibility (prob that an item of size >= s exists).
_ACCESS = None
_ACCESS_COUNT = -1


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    global _HIST, _COUNT, _ACCESS, _ACCESS_COUNT

    residual = bins - item  # remaining capacity after placing the item

    r = np.clip(residual.astype(np.float64), 0.0, None)
    score = -np.sqrt(r)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    small_ok = residual >= SMALL
    score += np.where(small_ok, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Empirical reusability: probability that some future item fits exactly
    # or that the residual can still accept a future item.  Recompute the
    # cumulative accessibility lazily when the histogram changes.
    if _COUNT > 50:
        if _ACCESS is None or _ACCESS_COUNT != _COUNT:
            prob = _HIST / _COUNT
            # prob_fit[s] = probability that an arriving item has size <= s
            cum = np.cumsum(prob)  # cum[s] = P(size <= s)
            # accessibility of residual s ~ P(size <= s) (can still receive
            # some item) but weighted by whether it can be filled well.
            _ACCESS = cum
            _ACCESS_COUNT = _COUNT
        ri = np.clip(residual, 0, 100).astype(np.int64)
        # Reward residuals that are likely to be (nearly) exactly filled:
        # look at local density around the residual.
        prob = _HIST / _COUNT
        smoothed = np.zeros_like(r)
        w = 0.25
        smoothed += prob[np.clip(ri, 0, 100)]
        smoothed += w * prob[np.clip(ri - 1, 0, 100)]
        smoothed += w * prob[np.clip(ri + 1, 0, 100)]
        score += 40.0 * smoothed
        # Also lightly reward broad reusability (can accept an item).
        score += 5.0 * _ACCESS[ri]

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    # Update histogram with the current item (after scoring).
    if 1 <= item <= 100:
        _HIST[item] += 1.0
        _COUNT += 1

    return score
# EVOLVE-BLOCK-END
