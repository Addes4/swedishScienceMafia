# EVOLVE-BLOCK-START
"""Hybrid best-fit that avoids leaving residuals too small to ever be refilled.

Items arrive one at a time. Plain best-fit (tightest residual) is near-optimal for
this distribution, so we keep it as the base rule. The one systematic waste in
online best-fit is committing an item to a nearly-full bin and leaving behind a
residual sliver that no future item is likely to fit, thereby "sealing" capacity.
We track an online estimate of a low-order statistic of the item-size distribution
(roughly the smallest items that keep showing up) and, when the tightest placement
would create a residual below that estimate, we instead choose the fullest bin
whose residual would remain at least that estimate. If no such bin exists we fall
back to best-fit.
"""
import numpy as np


# Small state kept between calls.
_state = {"counts": None, "n": 0, "min_seen": 101}


def _update_stats(item):
    # Histogram of observed item sizes for a cheap online percentile estimate.
    if _state["counts"] is None:
        _state["counts"] = np.zeros(102, dtype=np.int64)
    _state["counts"][item] += 1
    _state["n"] += 1
    if item < _state["min_seen"]:
        _state["min_seen"] = item


def _low_quantile(frac):
    counts = _state["counts"]
    n = _state["n"]
    if counts is None or n < 50:
        return 1
    target = frac * n
    cum = np.cumsum(counts)
    idx = int(np.searchsorted(cum, target))
    if idx < 1:
        idx = 1
    if idx > 100:
        idx = 100
    return idx


def priority(item, bins):
    """Return a priority for every bin; highest score wins, ties to first bin."""
    _update_stats(item)

    residual = bins - item  # what would remain after placing the item here

    # Current best-fit choice: minimize residual (most negative score wins as max).
    # Score = -residual, so higher score == smaller residual.
    base_score = -residual.astype(np.float64)

    # Online estimate of a low-order item size (items that realistically recur).
    q = _low_quantile(0.02)
    if q < 1:
        q = 1
    # Only bother avoiding slivers smaller than the item itself.
    if q > item:
        q = item
    if q <= 1:
        return base_score

    # Find the tightest residual among fitting bins.
    best_res = residual.min()
    if best_res >= q:
        # No sliver risk; plain best fit.
        return base_score

    # Prefer the fullest bin whose residual would stay >= q (i.e. smallest
    # residual that is still at least q). Score those bins by their residual so
    # the tightest acceptable one wins; all unacceptable bins get a large
    # negative score.
    acceptable = residual >= q
    if not acceptable.any():
        return base_score

    score = np.where(acceptable, -residual.astype(np.float64), -1e9)
    return score
# EVOLVE-BLOCK-END
