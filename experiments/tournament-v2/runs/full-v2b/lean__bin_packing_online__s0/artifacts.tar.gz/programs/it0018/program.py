# EVOLVE-BLOCK-START
"""Best fit with a residual-quality bonus based on a running mean item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Running mean of item sizes, kept on the function object.
    n, s = getattr(priority, "n", 0), getattr(priority, "s", 0.0)
    mu = s / n if n else 40.0

    residual = bins - item  # remaining capacity after placing the item here

    # Base: prefer tightest fit (smallest residual).
    score = -residual.astype(np.float64)

    # Bonus for leaving a residual that can host a typical item usefully,
    # and a big bonus for exact fits (residual 0) and small residuals.
    m = max(mu, 1.0)
    score += 0.5 * np.exp(-residual / m)          # rewards small residuals smoothly
    score += 2.0 * (residual == 0)                # exact fit

    # Update state.
    priority.n = n + 1
    priority.s = s + item
    return score
# EVOLVE-BLOCK-END
