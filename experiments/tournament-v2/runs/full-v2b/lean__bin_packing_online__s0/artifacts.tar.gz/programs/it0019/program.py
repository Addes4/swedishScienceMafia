# EVOLVE-BLOCK-START
"""Best fit with a stateful residual-usability rule.

The plain best-fit rule packs items tightly, but often leaves behind residuals
too small to fit any future item ("dust").  We keep a running estimate of the
typical item size and, whenever a bin's resulting residual would still be a
reasonable fraction of a typical item, we prefer the *tightest* such fit; if no
bin leaves a usable residual we simply take the tightest fit overall.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest."""
    # Running state about past items (kept across calls).
    state = priority.state
    n = state[0]
    mean = state[1]
    # Exponential moving mean of item sizes.
    alpha = 0.02
    mean = mean + alpha * (item - mean)
    n += 1
    state[0] = n
    state[1] = mean

    residual = bins - item

    # Threshold below which a residual is considered "dust" (hard to reuse).
    threshold = 0.35 * mean

    # Reward bins whose residual is >= threshold (usable) by a strong factor,
    # then strictly prefer the tightest among those.  Bins below threshold get
    # a lower priority but are still ordered by tightness.
    usable = residual >= threshold
    return np.where(usable, 1e6, 0.0) - residual


priority.state = [0, 40.0]
# EVOLVE-BLOCK-END
