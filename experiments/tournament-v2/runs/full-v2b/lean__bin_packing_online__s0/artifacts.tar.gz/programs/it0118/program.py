# EVOLVE-BLOCK-START
"""Online bin-choice rule: exact-fill first, then best fit.

Score: strongly reward bins that the item fills exactly; otherwise prefer the
smallest residual (best fit) so leftover gaps are concentrated and reusable.
Empty bins (residual == 100 before placing) are slightly less attractive so
they stay free for large items.
"""
import numpy as np


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    # Best fit: smaller residual is better.
    score = -residual.astype(np.float64)

    # Exact fill dominates everything.
    score += np.where(residual == 0, 1e6, 0.0)

    # Mildly prefer already-used bins (keep empty bins for large items).
    score += np.where(bins < 100, 1.0, 0.0)

    return score
# EVOLVE-BLOCK-END
