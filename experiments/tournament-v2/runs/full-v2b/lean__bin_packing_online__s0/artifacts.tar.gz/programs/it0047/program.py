# EVOLVE-BLOCK-START
"""Smart best fit: place the item in the bin whose post-placement residual is the
smallest residual that is still 'usable' (large enough to hold a typical item),
strongly penalizing creation of tiny unusable slivers."""
import numpy as np

# Typical item size for this distribution is ~40; usable residual threshold.
USABLE = 12


def priority(item, bins):
    """Return a priority for every bin; highest score gets the item."""
    residual = bins - item  # >= 0 for fitting bins
    score = np.empty(residual.shape, dtype=np.float64)

    # Penalty is largest for the smallest positive unusable residuals.
    unusable = (residual > 0) & (residual < USABLE)
    score[:] = -residual.astype(np.float64)
    # Subtract a big penalty from unusable residuals so usable ones win.
    score[unusable] -= 1000.0 + (USABLE - residual[unusable]) * 10.0
    return score
# EVOLVE-BLOCK-END
