# EVOLVE-BLOCK-START
"""Best fit with fuller-bin tie-breaking."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Primary: best fit (smallest post-placement residual -> least negative).
    primary = -(bins - item)
    # Secondary: among equal residuals, prefer the fuller bin (smaller remaining capacity).
    # Scaled small enough never to override the primary ordering.
    secondary = -(bins.astype(np.float64)) * 1e-3
    return primary + secondary
# EVOLVE-BLOCK-END
