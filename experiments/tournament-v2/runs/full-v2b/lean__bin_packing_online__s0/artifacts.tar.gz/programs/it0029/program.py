# EVOLVE-BLOCK-START
"""Best fit with a small residual-quality nudge toward reusable leftovers."""
import numpy as np

_state = {"sum": 0.0, "n": 0, "target": 40.0}


def priority(item, bins):
    """Rank bins: best fit first, nudged to avoid unusable slivers."""
    _state["sum"] += item
    _state["n"] += 1
    mean = _state["sum"] / _state["n"]
    # target residual size: a typical upcoming item (clamped)
    target = max(8.0, min(60.0, mean))

    residual = bins - item  # >= 0 since item fits

    # Base: best fit -> prefer smallest residual. Use negative residual so
    # highest score = tightest fit.
    score = -residual.astype(np.float64)

    # Nudge: penalize residuals that are small but nonzero (unusable slivers),
    # reward residuals that are 0 (perfect) or >= target (still reusable).
    # Penalty magnitude kept small so best-fit ordering is mostly preserved.
    sliver = (residual > 0) & (residual < target)
    score -= 0.5 * sliver.astype(np.float64)

    return score
# EVOLVE-BLOCK-END
