# EVOLVE-BLOCK-START
"""Residual-utility best fit tuned to the item-size distribution (mean ~40)."""
import numpy as np

# Precompute a static utility over residuals 0..100.
# Items are Weibull-shaped with mean ~40; a residual is "usable" if it can fit
# a likely upcoming item. Exact fills are best; mid residuals (~30-60) are good;
# tiny slivers (<~15) are nearly wasted capacity and are heavily penalized.
_r = np.arange(101)
# expected chance a residual of size r receives at least one future item:
# approximate survival via a smooth step that is 0 at r=0 and rises with r.
_usable = 1.0 - np.exp(-(_r / 28.0) ** 1.6)
_util = _r + 45.0 * _usable - 35.0 * (1.0 - _usable)

def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    res = bins - item
    res = np.clip(res, 0, 100)
    return _util[res]
# EVOLVE-BLOCK-END
