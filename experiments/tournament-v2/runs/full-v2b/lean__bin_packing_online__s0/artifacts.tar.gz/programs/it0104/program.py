# EVOLVE-BLOCK-START
"""Online bin-choice rule: tight packing with reusable-gap awareness.

Strongly reward exact fills.  Among non-exact placements, prefer the smallest
residual (best fit) so gaps are concentrated, but boost residuals that can
still hold future items.  Two usability tiers (small and typical) let the
rule favor gaps that remain broadly reusable across the size distribution.
Empty bins are kept slightly less attractive so they stay free for large
items.  The 'typical' tier is adapted online from the running mean of past
item sizes so the rule tracks the actual distribution.
"""
import numpy as np

SMALL = 20.0
_TYPICAL_REF = 40.0  # reference mean used before enough history accumulates


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    # Adapt the 'typical' size tier to the observed distribution.
    state = priority.__dict__
    n = state.get('n', 0) + 1
    mean = state.get('mean', 0.0)
    mean += (item - mean) / n
    state['n'] = n
    state['mean'] = mean
    typical = _TYPICAL_REF + 0.5 * (mean - _TYPICAL_REF) if n > 50 else _TYPICAL_REF

    residual = bins - item  # remaining capacity after placing the item

    # Primary: best fit -> prefer smallest residual (tightest packing).
    score = -residual.astype(np.float64)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    small_ok = residual >= SMALL
    score += np.where(small_ok, 4.0, 0.0)

    # Residual can host a typical item: even more valuable.
    typical_ok = residual >= typical
    bonus = 6.0 - 0.03 * np.clip(residual - typical, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Gently prefer already-used bins (keeps empty bins for large items).
    used = bins < 100
    score += np.where(used, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
