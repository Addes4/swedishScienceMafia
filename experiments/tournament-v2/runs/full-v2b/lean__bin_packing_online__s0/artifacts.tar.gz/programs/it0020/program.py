# EVOLVE-BLOCK-START
"""Best fit with a stateful penalty for stranded residuals."""
import numpy as np

_mean = 40.0
_n = 0


def priority(item, bins):
    global _mean, _n
    _mean = (_mean * _n + item) / (_n + 1)
    _n += 1

    residual = bins - item
    # Penalize residuals that are too small to fit a typical item (stranded space),
    # but only mildly, so best-fit ordering is mostly preserved.
    m = _mean
    # score: tighter fit is better (more negative residual => higher score).
    # Add a penalty for residuals in (0, m) since they may be wasted.
    penalty = np.where((residual > 0) & (residual < m), 0.5 * (m - residual) / m, 0.0)
    return -residual - penalty
# EVOLVE-BLOCK-END
