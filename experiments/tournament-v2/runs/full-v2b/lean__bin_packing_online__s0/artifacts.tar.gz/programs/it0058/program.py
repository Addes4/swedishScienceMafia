# EVOLVE-BLOCK-START
"""Best fit with near-tie broken toward the less-full bin to preserve flexibility."""
import numpy as np


def priority(item, bins):
    residual = bins - item
    # Base: prefer tightest fit (small residual).
    # Among bins whose residual is within a small epsilon of the best, prefer the
    # less-full bin before placement (i.e., larger residual) for flexibility.
    best = residual.min()
    eps = 3
    close = (residual - best) <= eps
    # For close bins, give a bonus proportional to the remaining space after
    # placement (less-full bins get slightly higher score), so ties/near-ties
    # favor flexibility without overriding genuine tight fits.
    score = -residual.astype(np.float64)
    score += np.where(close, 0.01 * residual, 0.0)
    return score
# EVOLVE-BLOCK-END
