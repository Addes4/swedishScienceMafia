# EVOLVE-BLOCK-START
"""Best fit with a targeted anti-stranding tie-break."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    Primary key: smallest post-placement residual (best fit).
    Tie-break: within a tiny window of the best residual, prefer residuals that are
    close to the item size scale (good candidates to be completed later) over tiny slivers.
    """
    residual = bins - item
    # Primary: prefer smaller residual (best fit) -> use negative residual.
    # Secondary: give a small bonus to residuals in a "useful" mid-range (not tiny slivers,
    # not huge leftovers) so near-ties favor fillable bins.
    # Use a smooth bonus that peaks around typical remaining-usable capacity.
    # Keep it tiny so it never overrides best-fit outside near-ties.
    bonus = np.where((residual >= 15) & (residual <= 45), 0.5, 0.0)
    # Penalize tiny positive slivers slightly.
    penalty = np.where((residual > 0) & (residual < 10), 0.5, 0.0)
    return -residual + bonus - penalty
# EVOLVE-BLOCK-END
