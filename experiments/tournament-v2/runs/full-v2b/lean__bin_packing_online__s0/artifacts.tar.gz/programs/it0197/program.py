# EVOLVE-BLOCK-START
"""Online bin-choice rule: best-fit with exact-fill and reuse-aware tiers.

Prefer the smallest residual (best fit) so that leftover gaps are concentrated
into a few bins and larger gaps remain reusable.  Strongly reward exact fills.
Add usability tiers for gaps that can still host a small or typical future item,
and penalize slivers that are too small to be reused.  Empty bins are kept
slightly less attractive so they stay available for large incoming items.
"""
import numpy as np

SMALL = 20.0
TYPICAL = 40.0


def priority(item, bins):
    """Score every bin; highest score wins, ties to first."""
    residual = bins - item  # remaining capacity after placing the item

    r = np.clip(residual.astype(np.float64), 0.0, None)

    # Base: best-fit (smallest residual preferred), concave so large residuals
    # are only mildly worse than small ones.
    score = -np.sqrt(r)

    # Exact fill: no waste at all.
    score += np.where(residual == 0, 1000.0, 0.0)

    # Residual can host at least a small item: valuable.
    score += np.where(residual >= SMALL, 4.0, 0.0)

    # Residual can host a typical item: even more valuable; mildly declining
    # bonus to keep larger gaps from being wasteful.
    typical_ok = residual >= TYPICAL
    bonus = 6.0 - 0.03 * np.clip(residual - TYPICAL, 0.0, None)
    score += np.where(typical_ok, bonus, 0.0)

    # Penalize slivers: positive but too small to ever be useful.
    sliver = (residual > 0) & (residual < SMALL)
    score -= np.where(sliver, 30.0, 0.0)

    # Gently prefer already-used bins (keeps empty bins for large items).
    score += np.where(bins < 100, 2.0, 0.0)

    return score
# EVOLVE-BLOCK-END
