# EVOLVE-BLOCK-START
"""Best fit with a small target-residual bias around the typical large item size."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    resid = bins - item
    # Primary: best fit (smallest non-negative residual).
    base = -resid.astype(np.float64)
    # Tiny bonus for residuals that are "just below" a typical large item (~40),
    # making them likely to be filled exactly by a future item.
    target = 40.0
    diff = np.abs(resid - target)
    bonus = 1.0 / (1.0 + diff)
    return base + 0.001 * bonus
# EVOLVE-BLOCK-END
