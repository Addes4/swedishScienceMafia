# EVOLVE-BLOCK-START
"""Best fit with a self-calibrating bonus for leaving residuals that match common item sizes."""
import numpy as np

_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; item goes to the highest score."""
    global _total
    # Update running item-size histogram (Laplace-smoothed).
    _counts[item] += 1.0
    _total += 1.0

    residual = bins - item  # remaining capacity after placing item
    # Probability weight that a residual r can be exactly matched by a future item.
    probs = (_counts + 1.0) / (_total + 101.0)  # smoothed distribution over sizes 0..100
    # Weight for each residual (clip to valid range), scaled relative to typical density.
    idx = np.clip(residual, 0, 100).astype(np.int64)
    density = probs[idx]
    # Only reward residuals > 0 (a future item could fill it); residual 0 is already perfect.
    bonus = np.where(residual > 0, density, 0.0)

    # Primary: minimize residual (best fit). Secondary: prefer fillable residuals.
    # Scale bonus so it only breaks near-ties, not override best fit.
    return -(residual) + 20.0 * bonus
# EVOLVE-BLOCK-END

