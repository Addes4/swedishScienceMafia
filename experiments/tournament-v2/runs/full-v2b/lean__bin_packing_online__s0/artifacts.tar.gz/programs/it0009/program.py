# EVOLVE-BLOCK-START
"""Best fit augmented with a distribution-aware residual bonus.

We track a running histogram of item sizes seen so far. For each candidate bin we
prefer small resulting residuals (best fit), but we add a bonus when the resulting
residual is close to a size we expect to see again soon, so a future item can nearly
fill that bin. This reduces the number of "hopeless" residuals left behind.
"""
import numpy as np

# Running histogram of item sizes (1..100) accumulated across calls.
_hist = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _hist, _total

    # Update the running distribution estimate.
    _hist[item] += 1.0
    _total += 1.0
    p = _hist / _total  # probability mass per size

    # Residual after placing this item into each bin.
    residual = bins - item

    # Best-fit base score: prefer the smallest non-negative residual.
    score = -residual.astype(np.float64)

    # Bonus: how much probability mass sits at sizes near this residual.
    # A residual r is "good" if items of size close to r are likely to arrive,
    # so the bin can be packed to near-zero waste later.
    r = residual.astype(np.int64)
    # clip to valid range; exact fits (r == 0) already maximally rewarded by base.
    rc = np.clip(r, 0, 100)
    # local mass around residual (within +-2)
    lo = np.clip(rc - 2, 0, 100)
    hi = np.clip(rc + 2, 0, 100)
    csum = np.concatenate(([0.0], np.cumsum(p)))
    mass = csum[hi + 1] - csum[lo]

    score = score + 3.0 * mass
    return score
# EVOLVE-BLOCK-END
