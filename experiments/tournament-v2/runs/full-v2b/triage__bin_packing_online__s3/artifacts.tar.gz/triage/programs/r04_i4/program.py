"""Markov-chain look-ahead: score bins by how well they can accommodate the
predicted *next* item after placing the current one.

We keep a 3-state Markov chain (small <30, medium 30-60, large >60) with
online transition counts. For each candidate bin we compute:

  base_score = -slack + w * q90_regret           # standard best-fit + regret

  look_score = sum( p_next(state) * bin_score_for_size(residual, next_size) )
               where bin_score_for_size = max(0, residual - next_size) ** 0.5

  final_score = alpha * base_score + (1-alpha) * look_score

The weight alpha shifts from 0.6→1.0 as the instance progresses, so early
items are heavily look-ahead while later items trust the learned policy.
"""
import numpy as np


# -- persistent state --------------------------------------------------------
_state = {
    # Markov counts: trans[from][to]
    "trans": np.ones((3, 3), dtype=np.int64),  # Laplace smoothing
    "prev_state": None,  # state of the last seen item (0,1,2 or None)
    # adaptive parameters moved online
    "count": 0,
    "large": 0,
    "w": 0.9,
    "floor": 58.0,
    "alpha": 0.6,
    # cached transition probabilities (updated lazily)
    "_probs": np.full((3, 3), 1.0/3.0),
    "_dirty": True,
}


def _state_idx(size):
    """Map item size to Markov state 0/1/2."""
    if size < 30:
        return 0
    if size <= 60:
        return 1
    return 2


def priority(item, bins):
    st = _state
    cur = _state_idx(item)
    prev = st["prev_state"]
    st["prev_state"] = cur
    st["count"] += 1
    if item >= 60:
        st["large"] += 1

    # --- update Markov counts -----------------------------------------------
    if prev is not None:
        st["trans"][prev, cur] += 1
        st["_dirty"] = True

    # --- recompute transition probabilities lazily --------------------------
    if st["_dirty"]:
        t = st["trans"]
        row_sums = t.sum(axis=1, keepdims=True)
        st["_probs"] = t / row_sums
        st["_dirty"] = False
    probs = st["_probs"][cur]  # p(next | current)

    # --- adaptive weight / floor (same as parent) ---------------------------
    n = st["count"]
    f_large = st["large"] / n

    st["w"] += 0.01 * (0.10 - f_large)
    st["w"] = max(0.4, min(1.6, st["w"]))

    st["floor"] += 0.05 * (0.10 - f_large)
    st["floor"] = max(50.0, min(78.0, st["floor"]))

    # --- alpha: blend factor, shifts toward pure regret-fit over time -------
    st["alpha"] = min(1.0, 0.6 + 0.4 * (n / 2000.0))  # fast ramp to ~1.0

    # --- per-bin scoring ----------------------------------------------------
    cap = bins.astype(np.float64)
    slack = cap - item
    q90 = np.percentile(cap, 90.0)
    regret = q90 - cap

    # base score
    if item >= st["floor"]:
        base = slack + 0.05 * regret
    else:
        base = -slack + st["w"] * regret

    # look-ahead score: expected quality of residual for next item
    residuals = cap - item  # leftover capacity *if* we put item here
    # For each possible next size we evaluate how well the residual fits.
    # Representative size per state: 15, 45, 75.
    next_rep = np.array([15.0, 45.0, 75.0])
    # score for a given residual r and next size s: r-s if positive, else 0
    # raised to 0.5 so that tightly fitting is rewarded but not too sharp.
    look = np.zeros_like(cap)
    for ns, rep in enumerate(next_rep):
        room = np.maximum(0.0, residuals - rep) ** 0.5
        look += probs[ns] * room

    # combine
    score = st["alpha"] * base + (1.0 - st["alpha"]) * look

    return score
