import numpy as np
from collections import defaultdict

_state = {
    "item_sizes": [],
    "class_centers": None,
    "bin_assignments": defaultdict(lambda: None),  # bin_idx -> class label
    "bin_prototypes": None,                        # class label -> target residual
    "n_classes": 5,
    "update_every": 100,
    "count": 0,
}


def _update_clusters(st):
    sizes = np.array(st["item_sizes"])
    if len(sizes) < st["n_classes"] * 10:
        return
    # Simple online clustering: percentiles as initial centers
    pcts = np.linspace(0, 100, st["n_classes"] + 1)[1:-1]
    centers = np.percentile(sizes, pcts)
    st["class_centers"] = centers
    # Prototype residual capacity for each class:
    # Larger items -> larger residual (emptier bins), smaller items -> smaller residual
    # Map class centers roughly to target residuals (capacity 100 - typical fill)
    scaled = centers / 100.0
    # Residual = 100 * (1 - scaled) * 0.8 + 10 (ensures some room)
    target_residuals = 100 * (1 - scaled) * 0.7 + 15.0
    st["bin_prototypes"] = target_residuals


def _assign_class(item, st):
    if st["class_centers"] is None:
        return 0
    dists = np.abs(st["class_centers"] - item)
    return int(np.argmin(dists))


def priority(item, bins):
    st = _state
    st["count"] += 1
    st["item_sizes"].append(item)
    if len(st["item_sizes"]) > 2000:
        st["item_sizes"] = st["item_sizes"][-2000:]

    if st["count"] % st["update_every"] == 0:
        _update_clusters(st)

    item_class = _assign_class(item, st)

    cap = bins.astype(np.float64)
    n_bins = len(cap)
    scores = np.full(n_bins, -np.inf, dtype=np.float64)

    # For each bin, compute score based on prototype matching
    for i in range(n_bins):
        if cap[i] < item:
            continue  # shouldn't happen per harness, but safe
        post_residual = cap[i] - item

        # Current bin's assigned class
        current_class = st["bin_assignments"].get(i, None)

        # Score: how close post-placement residual is to item_class prototype
        if st["bin_prototypes"] is not None:
            target_res = st["bin_prototypes"][item_class]
            # Base score: negative distance to target
            base_score = -abs(post_residual - target_res)

            # Penalty if this placement moves bin away from its own best class prototype
            if current_class is not None:
                own_target = st["bin_prototypes"][current_class]
                current_dist = abs(cap[i] - own_target)
                new_dist = abs(post_residual - own_target)
                penalty = (new_dist - current_dist) * 0.5
            else:
                penalty = 0.0

            # Bonus for staying within same class (encourages stability)
            stability_bonus = 5.0 if current_class == item_class else 0.0

            scores[i] = base_score - penalty + stability_bonus
        else:
            # Fallback: best-fit
            scores[i] = - (cap[i] - item)

    # Choose best bin
    best_idx = np.argmax(scores)
    if np.isneginf(scores[best_idx]):
        # All bins infeasible? shouldn't happen, fallback to first feasible
        feasible = np.where(cap >= item)[0]
        if len(feasible) > 0:
            best_idx = feasible[0]

    # Update bin assignment for chosen bin
    st["bin_assignments"][best_idx] = item_class

    return scores
