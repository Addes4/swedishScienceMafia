# EVOLVE-BLOCK-START
"""Precautionary-savings bin choice.

For each bin that can accept the current item we ask: if this bin takes the item, how
much room is left, and how many future items (drawn from the empirical size distribution
seen so far) could that remaining room still hold?  A bin that keeps a lot of *usable*
residual space is valuable, because it can absorb many future small/medium items instead
of forcing a brand new bin.

Concretely, for a candidate bin with remaining capacity r that takes an item of size s,
the residual is r - s.  Using the empirical CDF F of item sizes seen so far we estimate
the expected number of future items that residual can hold as

        savings(bin) = residual / E[size | size <= residual]

where E[size | size <= residual] is the conditional mean size below the residual (a
cheaper, well-behaved proxy for the expected number of items a gap of that size can
accommodate).  If residual can hold no item at all (residual < min observed size) the
savings is zero, so such bins are naturally discouraged.

We combine the immediate tightness (best fit) with the precautionary savings:

        score = -(r - s) + w * savings

The weight w grows with the number of open bins, making the balancer favour
future-flexible bins more strongly exactly when fragmentation pressure is highest.
For large items we tilt towards larger absolute residual (roomy bins) because the
conditional-mean term alone under-rewards big open gaps.
"""
import numpy as np


# --- module level online state -------------------------------------------------
_state = {
    "sizes": [],          # list of past item sizes
    "n": 0,
}


def priority(item, bins):
    st = _state
    st["n"] += 1
    st["sizes"].append(int(item))

    cap = bins.astype(np.float64)
    r = cap - item                       # residual if this bin takes the item

    # --- empirical distribution of past sizes --------------------------------
    n = st["n"]
    # Use the recent window for adaptivity but keep the full history for stability.
    arr = np.asarray(st["sizes"], dtype=np.float64)
    if arr.size > 2000:
        arr = arr[-2000:]

    # sorted once per call; 5000 calls * ~2000 log 2000 is fine.
    srt = np.sort(arr)
    m = srt.size

    # fraction of items at or below each residual: searchsorted gives the count
    # of past items <= residual.
    cnt_le = np.searchsorted(srt, r, side="right").astype(np.float64)

    # conditional mean size among items <= residual, for the bins that keep some room.
    # cumulative sum lets us get the sum of the smallest cnt_le items per bin.
    csum = np.concatenate(([0.0], np.cumsum(srt)))
    idx = cnt_le.astype(np.int64)
    sum_le = csum[idx]

    # mean of items that fit in the residual; guard against zero-count
    with np.errstate(divide="ignore", invalid="ignore"):
        mean_le = np.where(cnt_le > 0, sum_le / np.maximum(cnt_le, 1.0), np.inf)

    # expected number of additional items the residual could hold:
    # a gap of size r holds ~ (r / mean size of items that fit).  If no item fits
    # (cnt_le == 0 or mean_le == inf) the savings is zero.
    with np.errstate(divide="ignore", invalid="ignore"):
        savings = np.where(np.isfinite(mean_le) & (cnt_le > 0),
                           r / mean_le, 0.0)
    savings = np.maximum(savings, 0.0)

    # --- weight grows with the number of open (non-empty) bins ----------------
    # number of bins still in use: those that are not pristine full-capacity bins.
    full = float(cap.max()) if cap.size else 100.0
    n_open = float(np.count_nonzero(cap < full - 1e-9)) + 1.0
    # normalize by a soft reference so the weight stays in a sane range and keeps
    # increasing with bin count.  log keeps it gently increasing.
    w = 0.5 + 1.5 * np.log1p(n_open) / np.log1p(5000.0)
    w = float(np.clip(w, 0.5, 3.0))

    # --- large items: tilt toward roomy bins ---------------------------------
    large = item >= 60.0
    if large:
        # for large items prefer big absolute residuals (safe, roomy bins)
        return r * (1.0 + w) + w * savings
    else:
        # small/medium: trade best-fit tightness against precautionary savings
        return -(r) + w * savings
# EVOLVE-BLOCK-END

