# EVOLVE-BLOCK-START
"""Reserve-bin heuristic with an adaptive size threshold.

Best fit alone (pack into the tightest gap) is strong for small items but hurts when a
large item arrives later: it scatters medium items across many bins, leaving few spots
that can hold the big arrivals.  Here we keep a soft "reserve floor": while the current
item is small we would rather drop it into the tightest gap (concentrating the small
items and preserving large open bins).  When the item itself is large we flip the rule
and steer it toward the largest remaining capacity so it fits without wasting a
nearly-full bin's residual.

The size boundary at which we flip is estimated online from the items seen so far:
we track the recent large-item rate and nudge the threshold up or down.  No future
information is used.
"""
import numpy as np


# --- module level online state -------------------------------------------------
_state = {
    "count": 0,
    "large": 0,
    "threshold": 60.0,
}


def _reset_if_needed():
    # nothing instance-specific is leaked: the harness creates fresh state per run by
    # importing the module; but be safe if the array length hints at a restart size.
    pass


def priority(item, bins):
    st = _state
    st["count"] += 1

    # Adaptive threshold, nudged by how often genuinely large items arrive.
    # Mean size ~40, so 60+ is comfortably in the upper tail.
    if item >= 60:
        st["large"] += 1

    n = st["count"]
    f_large = st["large"] / n  # fraction of items that were large so far

    # Target: keep a modest reserve for the large tail.  If large items are rarer than
    # ~10% we can afford to be more aggressive (lower threshold => pack tightly more
    # often); if they are common we raise the threshold so medium items also get the
    # roomy-bin treatment.
    target = 0.10
    st["threshold"] += 0.5 * (target - f_large)
    if st["threshold"] < 45.0:
        st["threshold"] = 45.0
    elif st["threshold"] > 80.0:
        st["threshold"] = 80.0

    cap = bins.astype(np.float64)

    if item >= st["threshold"]:
        # Large item: prefer the fullest bin that can still hold it, but only among
        # bins that have a comfortable amount of space, to avoid fragmenting a nearly
        # full bin whose little gap could otherwise host a future small item.
        slack = cap - item
        # Penalize bins that are nearly full slightly less than empty ones: use a
        # concave-in-slack score so large-capacity bins are favoured.
        return slack
    else:
        # Small item: tightest fit (best fit), exactly the baseline behaviour.
        return -(cap - item)
# EVOLVE-BLOCK-END
