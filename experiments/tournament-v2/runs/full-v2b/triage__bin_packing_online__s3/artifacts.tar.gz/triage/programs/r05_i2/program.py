# EVOLVE-BLOCK-START
"""Fit-match-by-history: KDE-prediction of perfect-fit likelihood.

Track empirical distribution of item sizes that previously achieved slack=0
(perfect fit). For each arriving item, estimate the likelihood it will
find a bin fitting exactly using Gaussian kernel density estimation. Score
bin-choices by combining this fit-likelihood with the slack penalty.

Score = scale * (KDE_likelihood - penalty), penalizing both slack
and the probability of generating new perfect-fit opportunities.
"""
import numpy as np


# Track all perfect-fit occurrences
_fit_evidence = np.empty(0, dtype=np.float64)
_fit_cap = 20000
_fit_idx = 0


def priority(item: int, bins: np.ndarray) -> np.array:
    """Return priorities for bins that the item fits in."""
    global _fit_evidence, _fit_cap
    
    # Slack after placement (smaller is better)
    slack = bins - item
    
    # Track perfect-fit evidence (item sizes that fill residual capacity)
    if np.any(slack == 0):
        perfect_mask = slack == 0
        _fit_evidence = np.concatenate([
            _fit_evidence,
            item * np.ones(np.sum(perfect_mask), dtype=np.float64)
        ])
        _fit_evidence = _fit_evidence[-_fit_cap:]
        _fit_idx = 0
    
    # Compute KDE-based fit likelihood
    fit_scores = np.abs(item - slack)
    
    # Avoid zero fit likelihood
    if len(_fit_evidence) <= 1 and _fit_evidence.size > 0:
        mean = _fit_evidence[0]
        std = 5.0
    else:
        mean = float(np.mean(_fit_evidence))
        std = float(np.std(_fit_evidence))
        std = max(std, 1.0)
    
    # Gaussian KDE fit score (using single-bandwidth approximation)
    fit_likelihood = np.exp(-0.5 * ((item - mean) ** 2) / (2.0 * std ** 2))
    
    # Scale confidence based on fit likelihood
    scale = 0.5 + 0.1 * fit_likelihood
    
    # Compute final priority score: fit_likelihood - slack
    priority_scores = scale * (fit_likelihood - slack)
    
    return priority_scores


def gaussian_fit(item_size, evidence):
    """Gaussian KDE fit likelihood on item sizes from perfect fits."""
    if len(evidence) < 100:
        mean = np.mean(evidence)
        std = max(np.std(evidence), 0.5)
    else:
        std = 2.0
        mean = np.mean(evidence)
    
    score = np.exp(-0.5 * ((item_size - mean) ** 2) / (2.0 * std ** 2))
    return score


def fit_estimate(item_size, evidence, slack):
    """Estimate fit likelihood from evidence via Gaussian KDE."""
    if len(evidence) == 0:
        return 0.0
    
    mean = np.mean(evidence)
    std = max(np.std(evidence), 0.5)
    score = np.exp(-0.5 * ((item_size - mean) ** 2) / (2.0 * std ** 2))
    confidence = min(1.0, 0.1 + 0.9 * (len(evidence) / _fit_cap))
    return score * confidence + 1e-6


if __name__ == "__main__":
    pass

# EVOLVE-BLOCK-END
