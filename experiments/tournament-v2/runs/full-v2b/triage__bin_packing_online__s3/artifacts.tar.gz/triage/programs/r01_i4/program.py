import numpy as np

state = {
    'mean_remaining': 100.0,
    'open_count': 0,
    'decay': 0.999
}

def priority(item, bins):
    """
    Worst-fit variant with controlled fragmentation:
    - If there are bins whose remaining capacity is above a threshold (50% of mean remaining
      capacity of open bins), pick the one with the largest remaining capacity among those.
    - Otherwise, fall back to best-fit (smallest capacity that fits).
    """
    global state

    # Identify open bins (remaining < 100) - we approximate without tracking explicitly
    # but we can compute the threshold based on tracked statistics.
    # 'open bins' are those with remaining < 100.
    open_mask = bins < 100
    n_open = np.sum(open_mask)
    
    if n_open > 0:
        # Update exponential moving average of mean remaining capacity of open bins
        mean_open = np.mean(bins[open_mask])
        state['mean_remaining'] = (state['decay'] * state['mean_remaining'] +
                                   (1 - state['decay']) * mean_open)
    else:
        # No open bins, reset mean to 100
        state['mean_remaining'] = 100.0

    threshold = 0.5 * state['mean_remaining']
    
    # Among bins above threshold, worst-fit (largest remaining capacity)
    above_threshold = bins >= threshold
    
    if np.any(above_threshold):
        # Worst-fit among those above threshold: largest remaining capacity
        # We want highest score for largest capacity, but tie-breaking to first such bin.
        # Since we want the bin with the highest score, we return -capacity for best-fit normally,
        # but here we want remaining capacity directly (larger is better).
        # So return `bins` for those above threshold, and -infinity for others.
        scores = np.where(above_threshold, bins.astype(float), -np.inf)
        return scores
    else:
        # Fall back to best-fit: smallest remaining capacity that fits
        # Negative remaining capacity gives highest score to smallest capacity (least negative)
        return -bins.astype(float)
