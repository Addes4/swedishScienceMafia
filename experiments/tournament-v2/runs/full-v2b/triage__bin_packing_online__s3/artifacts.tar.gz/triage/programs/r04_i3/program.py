# EVOLVE-BLOCK-START
"""Frequency-based phantom bin packing: 
Maintain online histogram of item sizes seen. Maintain for each real bin an estimate
of how many future items of the most-common size can still fit. Score by combining
residual capacity with penalties for reducing that future fit capacity.

This helps preserve bin space that can accommodate the most-frequent item type,
reducing fragmentation risk.
"""
import numpy as np

# Global state: item size histogram and most common size
_state = {
    'hist': np.zeros(101, dtype=np.int64),
    'n': 0,
    'most_common_size': 40,
}


def priority(item, bins):
    st = _state

    # Update histogram for this item
    st['hist'][item] += 1
    st['n'] += 1

    # Track most common size (use 10-item window or last seen as fallback)
    if item > st['most_common_size']:
        st['most_common_size'] = item

    # Determine which "phantom bins" would be used to track future common-size items
    common = st['most_common_size']
    q75_cap = np.quantile(bins, 0.75, method='linear')
    q25_cap = np.quantile(bins, 0.25, method='linear')
    cp = bins.astype(float)

    # Slack: amount of space left after placing the item
    slack = cp - item

    # Identify bins that could fit at least one future common-size item after placing current
    can_fit_common = (cp >= item + common)
    n_can_fit = np.sum(can_fit_common)

    # Count how many bins would lose their ability to fit future common items after placement
    # (phantom bin penalty)
    loss = n_can_fit - np.sum((cp >= item + common + common))

    # Compute score: prefer low slack, but penalize future fit loss strongly
    score = slack
    if n_can_fit > 0 or loss > 0:
        avg_res_might_fit = np.quantile(bins[cp >= item + common], 50, method='linear')
        score += 10 * loss
        score += (avg_res_might_fit - cp) * 0.1

    return score.astype(np.float32)
# EVOLVE-BLOCK-END
