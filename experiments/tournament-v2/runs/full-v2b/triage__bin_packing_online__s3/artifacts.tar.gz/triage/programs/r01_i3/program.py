import numpy as np

# Maintain a fast-adapting histogram of item sizes
HIST_BINS = np.arange(0, 101, 5)  # 20 bins: (0,5],(5,10],...,(95,100]
HIST_COUNT = None
HIST_DECAY = 0.995
TOTAL_COUNT = 0


def _init_state():
    global HIST_COUNT, TOTAL_COUNT
    HIST_COUNT = np.ones(len(HIST_BINS) - 1, dtype=np.float64) * 1e-6  # pseudo-count
    TOTAL_COUNT = len(HIST_BINS) * 1e-6


def priority(item, bins):
    global HIST_COUNT, TOTAL_COUNT

    if HIST_COUNT is None:
        _init_state()

    # Update model with observed item
    idx = np.searchsorted(HIST_BINS, item, side='right') - 1
    if idx >= 0:
        HIST_COUNT *= HIST_DECAY
        HIST_COUNT[idx] += 1.0
        TOTAL_COUNT = HIST_COUNT.sum() + 1e-9

    # Current bin capacities (bins already filtered to those that fit)
    caps = bins.copy()
    n_bins = len(caps)

    # Monte Carlo samples for each bin
    num_samples = 80
    # Sample future items (all bins share the same future streams; vectorized)
    # Sample from empirical histogram
    probs = HIST_COUNT / TOTAL_COUNT
    # Generate random items efficiently
    sampled_indices = np.random.choice(len(probs), size=num_samples, p=probs)
    # Transform to item sizes: pick uniform inside each bin range
    bin_edges = np.array([HIST_BINS[:-1], HIST_BINS[1:]])
    low = bin_edges[0, sampled_indices]
    high = bin_edges[1, sampled_indices]
    future_items = np.random.randint(low, high + 1, size=num_samples).astype(np.int64)

    # Estimate extra bins for each candidate
    scores = np.empty(n_bins, dtype=np.float64)

    # For speed, process bins in batches inside a loop
    # Heuristic: future items won't fill more than sum(items)//100 extra bins
    cap_indices = np.arange(n_bins)

    for i in cap_indices:
        remaining = caps[i]
        bins_used = 0
        # Simple simulation of packing remaining items with Best Fit heuristic
        open_caps = [remaining]
        for itm in future_items:
            # find bin it fits in with least space left
            best_idx = -1
            best_space = 101
            for j, c in enumerate(open_caps):
                if c >= itm and (c - itm) < best_space:
                    best_space = c - itm
                    best_idx = j
            if best_idx >= 0:
                open_caps[best_idx] -= itm
            else:
                bins_used += 1
                open_caps.append(100 - itm)
        # Total bins estimate: current number of bins (we know position index? Not exactly; approximate)
        # We approximate current bin count as number of non-full bins seen so far not exactly known,
        # but we just compare relative merit, so offset doesn't matter.
        total_bins_est = bins_used  # relative number of extra bins
        scores[i] = -total_bins_est

    return scores
