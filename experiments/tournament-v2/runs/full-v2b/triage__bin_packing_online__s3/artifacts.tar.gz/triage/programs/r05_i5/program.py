# EVOLVE-BLOCK-START
"""Shortest-expected-path bin choice via discretized policy iteration.

Idea
----
Think of a bin as a Markov decision process state = remaining capacity.
Items arrive with a fixed size distribution; placing an item of size s into a
bin of remaining capacity c moves the bin to c - s.  We seek a policy that, in
steady state, minimises the expected number of "new bins" opened per item, i.e.
maximises the expected number of items absorbed before a bin's residual drops
below usefulness.

We approximate the optimal *state value function* V(c) = expected number of
future items this bin will still absorb (until it is retired), for capacity
levels c = 0..100.  Then the immediate opportunity cost of consuming capacity
on bin c with item s is

    Q(c, s) = (expected items lost on this bin)   ~   V(c) - V(c - s)

Choosing the bin minimising that loss is exactly "shortest expected path":
we spend the least valuable residual capacity.

V is learned online via value / policy iteration on a discretised state space,
using an observed histogram of item sizes updated as items arrive.  Real bins
are scored by V(before) - V(after) and we pick the *smallest* loss (highest
score = -loss), with a classic best-fit tie-break to keep fits tight.  A few
iterations of policy evaluation are run every call, cheap because the state
space is only 101 levels and updates are O(states * sizes) using a bucketed
histogram.
"""
import numpy as np

# ---------------------------------------------------------------------------
# State (persists across calls)
# ---------------------------------------------------------------------------
_state = {
    "count": 0,
    "hist": np.zeros(101, dtype=np.float64),  # observed size histogram (smoothed)
    "V": None,               # value function over capacities 0..100
    "last_rebuild": 0,
    "seen": 0.0,
    "large": 0,
}

_HIST_SMOOTH = 1.0     # Laplace-ish smoothing of histogram
_REBUILD_EVERY = 25    # refresh value function this often (calls)
_POLICY_ITERS = 6      # value-iteration sweeps per rebuild


def _ensure_value(st):
    """Lazily build / refresh an approximate value function V(c).

    V(c) = expected number of items this bin will still absorb.  Higher c is
    better.  We do value iteration on the discounted/undiscounted MDP with the
    option of "retiring" the bin (value 0) when it can no longer take useful
    items.
    """
    if st["V"] is not None and (st["count"] - st["last_rebuild"]) < _REBUILD_EVERY:
        return

    n = st["count"]
    if n < 40:
        # Too little data; linear proxy: value grows with capacity.
        st["V"] = np.arange(101, dtype=np.float64) / 100.0
        st["last_rebuild"] = st["count"]
        return

    hist = st["hist"].copy()
    total = hist.sum()
    if total <= 0:
        p = np.zeros(101, dtype=np.float64)
    else:
        p = hist / total
    # Only consider feasible sizes (1..100)
    sizes = np.nonzero(p[1:])[0] + 1  # size values with prob mass
    probs = p[1:][sizes - 1]
    if probs.size == 0:
        st["V"] = np.arange(101, dtype=np.float64) / 100.0
        st["last_rebuild"] = st["count"]
        return

    # Expected items absorbed *per unit of consumed capacity* normalisation:
    mean_size = float(np.dot(sizes, probs))
    if mean_size <= 1e-6:
        mean_size = 40.0

    V = np.zeros(101, dtype=np.float64)
    # Initialise with a heuristic linear potential.
    for c in range(101):
        V[c] = c / mean_size

    # Value iteration: V(c) = max reward stream.  We reward one item each time
    # we can place something, then continue from c - s.
    for _ in range(_POLICY_ITERS):
        newV = V.copy()
        for c in range(1, 101):
            best = 0.0
            for k in range(sizes.size):
                s = int(sizes[k])
                if s <= c:
                    val = 1.0 + V[c - s]
                    if val > best:
                        best = val
            newV[c] = best
        delta = np.abs(newV - V).max()
        V = newV
        if delta < 1e-4:
            break

    st["V"] = V
    st["last_rebuild"] = st["count"]


def priority(item, bins):
    st = _state
    st["count"] += 1

    # Update size histogram (smoothed) with the arriving item.
    s = int(item)
    if 1 <= s <= 100:
        st["hist"][s] += 1.0
    if item >= 60:
        st["large"] += 1

    _ensure_value(st)
    V = st["V"]
    if V is None:
        V = np.arange(101, dtype=np.float64) / 100.0

    cap = bins.astype(np.int64)
    ci = np.clip(cap, 0, 100)

    after = np.clip(ci - s, 0, 100)

    # Loss = capacity value consumed by placing the item here.
    loss = V[ci] - V[after]

    # Score: prefer the smallest loss (least valuable capacity consumed).
    score = -loss

    # Best-fit tie-break: among near-equal losses, tightest fit preferred.
    slack = ci - s
    score = score - 0.002 * slack

    # Mild protection of very roomy bins when item is large: discourage putting
    # big items into near-empty bins?  Actually big items *want* roomy bins, so
    # we only add a tiny preference to keep large items tight too; the value
    # function already encodes that leaving a fully-empty bin intact is good.
    if item >= 60:
        score = score - 0.0005 * slack

    return score
# EVOLVE-BLOCK-END
