# EVOLVE-BLOCK-START
"""Reserve-bin heuristic with an adaptive size threshold and capacity-weighted scoring.

When the incoming item is small, we prefer bins where it leaves the *largest* gap after
placement — this avoids creating many nearly-full bins that cannot host future medium/large
items. For large items, we prefer bins with the largest remaining capacity to keep roomy
bins open as long as possible. An adaptive threshold, controlled by a PID-like rule on the
observed large-item rate, decides which regime to use. Using the same score direction for
both regimes (maximise post-placement residual, not minimise gap) removes the discontinuity
in the original code and substantially reduces fragmentation.
"""
import numpy as np


# --- module level online state -------------------------------------------------
_state = {
    "count": 0,
    "large": 0.0,        # EMA-filtered count of large items
    "threshold": 62.0,   # items with size >= threshold go to the "large" regime
}
# Tune EMA half-life: ~200 items
_alpha = 0.0035


def _reset_if_needed():
    # Nothing to do — the harness reloads the module for each instance.
    pass


def priority(item, bins):
    st = _state
    st["count"] += 1

    # Update an exponential moving average of "large" arrivals.
    # Large is defined relative to a fixed reference, not the adaptive threshold,
    # so the EMA responds to genuine distribution shifts rather than its own output.
    is_large = 1.0 if item >= 65 else 0.0
    st["large"] += _alpha * (is_large - st["large"])

    # --- PID-like adaptive threshold ---
    # Target: large-item EMA around 0.10.  If the distribution produces fewer large items
    # we can push the threshold down (pack more items aggressively); if many large items
    # appear we raise the threshold so more items get the "large-item" treatment.
    target = 0.10
    error = target - st["large"]
    # Integral-like update with bounds:
    st["threshold"] += 0.25 * error
    if st["threshold"] < 42.0:
        st["threshold"] = 42.0
    elif st["threshold"] > 85.0:
        st["threshold"] = 85.0

    cap = bins.astype(np.float64)

    if item >= st["threshold"]:
        # Large-item regime: prefer bins with the most free space so we keep a few
        # "reserve" bins wide open and avoid wasting a half-full bin on a large item.
        return cap
    else:
        # Small-item regime: prefer the bin where the remaining capacity *after*
        # placing the item is largest.  This naturally gives best-fit behaviour
        # while actively avoiding the creation of very tight leftover gaps.
        residual = cap - item
        return residual
# EVOLVE-BLOCK-END
