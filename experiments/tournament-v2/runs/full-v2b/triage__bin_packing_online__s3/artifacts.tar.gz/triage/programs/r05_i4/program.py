# EVOLVE-BLOCK-START
"""Dual-mode bin-choice with surplus/critical phase detection.

In "surplus" mode (remaining capacity / estimated remaining load > 1.1) we use
the regret-weighted policy from the original, but add a bonus for the emptiest
bins proportional to log(ratio). This fills bins more aggressively when we have
plenty of room.

In "critical" mode (ratio <= 1.1) we switch to strict best-fit on all bins,
conserving space exactly. The threshold is adaptive based on observed item
sizes, making it robust to the distribution.
"""
import numpy as np


_state = {
    "count": 0,
    "large": 0,
    "w": 0.9,
    "floor": 58.0,
    "total_items": 0,
    "total_size": 0,
    "total_bin_capacity_created": 0,
}


def priority(item, bins):
    st = _state
    st["count"] += 1
    st["total_items"] += 1
    st["total_size"] += item

    if item >= 60:
        st["large"] += 1

    n = st["count"]
    f_large = st["large"] / n

    # Adapt w and floor as before
    st["w"] += 0.01 * (0.10 - f_large)
    st["w"] = max(0.4, min(1.6, st["w"]))

    st["floor"] += 0.05 * (0.10 - f_large)
    st["floor"] = max(50.0, min(78.0, st["floor"]))

    # -- Phase detection --
    # Total bin capacity created so far (each bin = 100)
    current_bins_total_capacity = len(bins) * 100.0
    # Remaining total capacity in existing bins
    remaining_capacity = np.sum(bins)
    # Add unused bins' capacity (they are included with 100, so remaining_capacity
    # already accounts for them). We just need the ratio of remaining capacity to
    # estimated remaining load.

    # Estimate remaining load: assume future items have the same mean size as seen so far.
    # Total items in this instance is 5000.
    mean_item_so_far = st["total_size"] / st["total_items"] if st["total_items"] > 0 else 1.0
    remaining_items = 5000 - st["total_items"]
    estimated_remaining_load = max(1, remaining_items * mean_item_so_far)

    ratio = remaining_capacity / estimated_remaining_load if estimated_remaining_load > 0 else 99.0

    cap = bins.astype(np.float64)
    slack = cap - item

    if ratio <= 1.1:
        # Critical mode: strict best-fit. We still consider all bins, but pure
        # best-fit means minimizing slack (most negative score, but since tie goes
        # to first, we just return -slack, so larger -slack = smaller slack wins,
        # except we want the smallest slack, so return -slack).
        return -slack

    # Surplus mode: regret-weighted policy with a bonus for emptiest bins
    q90 = np.percentile(cap, 90.0)
    regret = q90 - cap

    # Bonus for emptiest bins: proportional to log(ratio) and to how empty the bin is
    # (larger cap gets more bonus). This makes us fill up emptier bins faster.
    log_ratio = np.log(max(1.0001, ratio))
    # Scale factor: a bin at capacity 100 gets log_ratio, at 0 gets 0.
    bonus = (cap / 100.0) * log_ratio * 0.5

    if item >= st["floor"]:
        # Large item: prefer roomy bins
        return slack + 0.05 * regret + bonus
    else:
        return -slack + st["w"] * regret + bonus
# EVOLVE-BLOCK-END
