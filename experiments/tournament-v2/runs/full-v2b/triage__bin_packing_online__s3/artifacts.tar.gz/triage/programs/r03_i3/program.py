import numpy as np


# --- module level online state -------------------------------------------------
class _State:
    def __init__(self):
        self.count = 0
        # Reservoir for estimating quantiles: maintain a fixed-size sample of item sizes.
        self.reservoir = np.zeros(200, dtype=np.float64)
        self.reservoir_size = 0
        self.reservoir_capacity = len(self.reservoir)


_state = _State()


def priority(item, bins):
    st = _state
    st.count += 1

    # --- Reservoir sampling to maintain a uniform random sample of item sizes ---
    if st.reservoir_size < st.reservoir_capacity:
        st.reservoir[st.reservoir_size] = item
        st.reservoir_size += 1
    else:
        # Randomly decide to replace an existing element with probability capacity / count
        # Standard reservoir sampling (Algorithm R)
        j = np.random.randint(0, st.count)
        if j < st.reservoir_capacity:
            st.reservoir[j] = item

    # --- Estimate quantile (ECDF) of the current item ---
    if st.reservoir_size == 0:
        quantile = 0.5  # fallback
    else:
        # Fraction of reservoir values that are <= current item
        sample = st.reservoir[:st.reservoir_size]
        quantile = np.mean(sample <= item)

    # --- Blend best-fit and worst-fit using the quantile as weight ---
    # capacity left in each bin
    cap = bins.astype(np.float64)

    # best-fit score: prefer bin with smallest remaining capacity (tightest fit)
    # -> more negative is better? We need scoring such that highest score wins.
    # Let best_fit = -(remaining capacity) : larger (closer to 0) = tighter.
    best_fit = -cap

    # worst-fit score: prefer bin with largest remaining capacity
    # Let worst_fit = remaining capacity
    worst_fit = cap

    # weight: quantile. Small quantile -> mostly best-fit; large quantile -> mostly worst-fit.
    # Convex combination: (1 - quantile)*best_fit + quantile*worst_fit
    score = (1.0 - quantile) * best_fit + quantile * worst_fit

    return score
