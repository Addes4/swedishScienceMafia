# EVOLVE-BLOCK-START
"""Best-fit augmented with a histogram of past item sizes.

For each candidate bin we estimate how likely its post-placement residual can be
filled by a future item, using the empirical size distribution of items seen so
far. Binaries whose residual is 'reachable' (there exist past items <= residual)
are preferred, with a mild best-fit tie-breaker to pack tightly.
"""
import numpy as np


class _State:
    def __init__(self):
        # Histogram over item sizes 1..100 (cumulative use).
        self.hist = np.zeros(101, dtype=np.float64)
        self.count = 0.0
        # Precomputed cumulative mass: cmass[r] = mass of sizes <= r
        self.cmass = np.zeros(101, dtype=np.float64)

    def observe(self, item):
        self.hist[item] += 1.0
        self.count += 1.0
        # Rebuild cumulative mass (cheap: 101 entries).
        self.cmass = np.cumsum(self.hist)
        self.cmass /= max(self.count, 1.0)


_STATE = _State()


def priority(item, bins):
    """Rank bins by estimated long-run usefulness of the resulting residual."""
    st = _STATE
    # Update the estimate *after* using it for this item, to avoid leakage of
    # the current item into its own decision.
    cmass = st.cmass  # mass of past items with size <= t, for t in 0..100
    have_info = st.count >= 50.0

    bins = np.asarray(bins, dtype=np.int64)
    res = bins - item  # residual remaining in each bin after placing the item

    # Reachability: probability mass of past items with size <= residual.
    # Larger is better: the hole can plausibly still be filled.
    reach = cmass[np.clip(res, 0, 100)]

    if have_info:
        # Score: strongly reward reachable residuals; among those, prefer
        # smaller residual (tighter, i.e. best-fit) to avoid scattering holes.
        # Normalize residual to [0,1]-ish and combine.
        # Reach dominates; tightness breaks ties and slightly guides.
        score = reach - 0.15 * (res / 100.0)
    else:
        # Cold start: pure best fit.
        score = -res.astype(np.float64)

    # Record the arriving item for future estimates.
    st.observe(item)
    return score
# EVOLVE-BLOCK-END
