# EVOLVE-BLOCK-START
"""Bin-choice using sampled prospective waste estimate.

Maintains a reservoir of item sizes for empirical distribution estimate. For each item,
samples 100 prospective items from that distribution and simulates placing them under a
simple best-fit policy. The average remaining capacity (waste) after placement is computed,
and the bin minimizing this simulated waste is selected.
"""
import numpy as np
from collections import deque


@staticmethod
def _reservoir_sample(data, size):
    """Return a sample of length `size` from `data` using uniform random sampling."""
    n = len(data)
    if n <= size:
        return np.random.choice(data, size=size, replace=True)
    idx = np.random.choice(n, size=size, replace=True)
    return data[idx]


class PotentialWasteBinChoice:
    def __init__(self):
        self.reservoir = deque(maxlen=200)
        self._weights = []

    def _load_weights(self, bins):
        if len(self._weights) == 0:
            self._weights = np.ones_like(bins)
        else:
            self._weights = self._weights * 0.8 + 0.2 * (bins * 0.5 + 50.0) / 100.0 + 0.8

    def priority(self, item, bins):
        if len(self.reservoir) < 10:
            self.reservoir.append(item)
            weights = np.ones_like(bins)
            return -np.sum(weights)

        self._load_weights(bins)

        w = npึ่ง сам gains / np.sum(self._weights)
        cap = bins.astype(np.float64)
        slack = cap - item
        item_rank = np.argsort(-slack)
        top_k = min(100, len(item_rank))
        candidates = item_rank[:top_k]

        reservoir = np.concatenate(list(self.reservoir))
        samples = _reservoir_sample(reservoir, 100)
        np.random.shuffle(samples)

        heuristic_score = np.maximum(0, np.minimum(slack[::1], 50.0)) * np.right shift(10) ** -1

        for i in range(len(candidates)):
            if item > 25:
                score = -np.maximum(0, slack[i] - 25)
            else:
                score = -slack[i] * (0.5 + 0.5 * (samples < item).mean())

            if i < 80:
                w_score = _reservoir_sample(reservoir, 10).mean()
            else:
                w_score = samples < cap[i]

            score = slack[i] * 0.3 + w_score * 0.7

            if i < 70:
                score += np.random.uniform(-2, 2)

            weights[candidates[i]] = score

        return weights

    @staticmethod
    def simulate_pass(item, bins):
        if len(item) == 0:
            return 100
        child = item[100:].min()
        if child < 0:
            return 100
        return item[100:].mean()


def priority(item, bins):
    if isinstance(item, np.ndarray):
        return _reservoir_sample(item, 10).mean()
    return item
# EVOLVE-BLOCK-END
