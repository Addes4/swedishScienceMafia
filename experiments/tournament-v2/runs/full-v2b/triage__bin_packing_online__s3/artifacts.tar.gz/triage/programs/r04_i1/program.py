# EVOLVE-BLOCK-START
"""Best-fit with residue-class balance preservation.

Rationale
---------
Pure best fit wastes bins because small items are packed into bins that a
future, better-fitting item could have completed.  A cheap online proxy for
"is this placement going to leave an unusable hole?" is to look at the
post-placement residual modulo a small integer M.  Some residue classes
(and small residual values in general) are far more likely to be the exact
complement of a future item than others.

We maintain two slowly-adapted tables, keyed by the post-placement residual
r = cap - item, bucketed to modulus M and to a coarse magnitude band:

* `demand[res]` -- counts how often, in the recent past, an arriving item
  would have fitted exactly (or nearly exactly) into a bin whose residual
  was this value.  Concretely: when item `s` arrives, we credit demand for
  residues r in [max(0,s-2), s] on the bins we *did not* choose, i.e. the
  complements we left unsatisfied.  This is the "mismatch" signal.

* `fill[res]` -- counts how often we actually produced a post-placement
  residual of this value; used to normalise demand so that a residue is
  only valued if it is also achievable (keeps the table from exploding).

The score blends the classic best-fit term with a bonus for placing the
item such that the resulting residual lands in a residue class that has
been in high demand: this fills historically hard-to-satisfy gaps and
leaves the empty-bin pool intact for genuinely large arrivals.

The tables are updated online only, never seeing future items, and adapt
slowly (exponential decay) so they track the fixed distribution without
overfitting to any single instance.
"""
import numpy as np

_M = 11               # modulus for residue classes
_NB = 12              # magnitude bands (residual // 9, capped)
_BW = 100.0 / _NB     # band width

_state = {
    "count": 0,
    "large": 0,
    "w": 0.9,          # regret weight, adapted online
    "floor": 58.0,     # size above which we shift to "roomy bin" mode
    # adaptive tables, index [band, residue]
    "demand": np.zeros((_NB, _M), dtype=np.float64),
    "fill": np.zeros((_NB, _M), dtype=np.float64),
}


def _cell(r):
    """Map a post-placement residual to (band, residue) indices."""
    b = int(r // _BW)
    if b < 0:
        b = 0
    elif b >= _NB:
        b = _NB - 1
    return b, int(r) % _M


def priority(item, bins):
    st = _state
    st["count"] += 1

    if item >= 60:
        st["large"] += 1

    n = st["count"]
    f_large = st["large"] / n

    # Adapt the large-item handling online.
    st["w"] += 0.01 * (0.10 - f_large)
    if st["w"] < 0.4:
        st["w"] = 0.4
    elif st["w"] > 1.6:
        st["w"] = 1.6

    st["floor"] += 0.05 * (0.10 - f_large)
    if st["floor"] < 50.0:
        st["floor"] = 50.0
    elif st["floor"] > 78.0:
        st["floor"] = 78.0

    cap = bins.astype(np.float64)
    slack = cap - item                      # >= 0, small = tight fit
    q90 = np.percentile(cap, 90.0)
    regret = q90 - cap                      # positive => comparatively full

    # --- balance-preservation term -------------------------------------
    # Normalised demand for the residue we would create in each bin.
    dem = st["demand"]
    fl = st["fill"]
    # ratio of demand to (fill + 1): residues we rarely produce but that are
    # often "wanted" get a strong bonus.  Clip to a gentle range.
    ratio = dem / (fl + 1.0)
    np.clip(ratio, 0.0, 3.0, out=ratio)

    # Map each bin's post-placement residual to a table cell.
    n_bins = cap.shape[0]
    resid = slack.astype(np.int64)
    np.clip(resid, 0, 99, out=resid)
    bands = resid // int(_BW)
    np.clip(bands, 0, _NB - 1, out=bands)
    res_mod = resid % _M
    bonus = ratio[bands, res_mod]           # per-bin demand bonus

    # --- combine -------------------------------------------------------
    if item >= st["floor"]:
        # Large item: land it in a roomy slot; keep the fit tight.
        score = slack + 0.05 * regret + 0.4 * bonus
    else:
        score = -slack + st["w"] * regret + 1.6 * bonus

    # --- online table update (after scoring, using chosen bin) ---------
    # The item goes into the highest-scoring bin (ties -> first).  We update
    # the tables to reflect: (a) the residue we just created, (b) the
    # complements we did *not* satisfy among the remaining bins.
    best = int(np.argmax(score))
    b, m = _cell(int(slack[best]))
    fl[b, m] += 1.0

    # Unchosen bins with residual >= item would have been exact fits for a
    # range of future items around the complement; credit demand for the
    # residue they *would* have produced had this item gone there.
    others = np.ones(n_bins, dtype=bool)
    others[best] = False
    if others.any():
        r_oth = slack[others].astype(np.int64)
        np.clip(r_oth, 0, 99, out=r_oth)
        b_o = r_oth // int(_BW)
        np.clip(b_o, 0, _NB - 1, out=b_o)
        m_o = r_oth % _M
        # Credit demand for residues in the "wanted band" of the item size.
        lo = max(0, item - 2)
        # only bins whose residual lies in [lo, item] get credit
        mask = (r_oth >= lo) & (r_oth <= item)
        if mask.any():
            bb = b_o[mask]
            mm = m_o[mask]
            np.add.at(dem, (bb, mm), 1.0)

    # Slow exponential decay keeps the tables adaptive and bounded.
    if (n & 63) == 0:
        dem *= 0.995
        fl *= 0.995

    return score
# EVOLVE-BLOCK-END
