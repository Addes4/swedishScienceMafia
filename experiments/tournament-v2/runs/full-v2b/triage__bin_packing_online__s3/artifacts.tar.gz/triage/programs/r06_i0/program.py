# EVOLVE-BLOCK-START
"""Density-aware adaptive bin selection.

The strategy uses an exponential histogram of recent item sizes to estimate
stream density, then dynamically switches between best-fit (for high density)
and regret-based worst-fit (for low density), based on online mean and variance.
"""
import numpy as np

_state = {
    "count": 0,
    "weights": np.zeros(500, dtype=np.float64),
    "alpha": 0.995,
}


def priority(item, bins):
    st = _state
    st["count"] += 1

    # Update exponential histogram with item size
    st["weights"] = st["weights"] * st["alpha"] + item

    w = st["weights"]
    total = w.sum()
    if total < 1e-6:
        # Fallback: always use best-fit
        return bins - item

    # Weighted mean estimate of recent item sizes
    recent_mean = w.sum() / total
    if recent_mean <= 0:
        recent_mean = item

    # Weighted variance estimate
    recent_var = (w * (w - recent_mean)**2).sum() / total
    recent_std = np.sqrt(recent_var) if recent_var > 0 else 0

    # Normalize by expected standard deviation (mean around 40, so expect std ~30-50)
    cv_factor = recent_std / recent_mean if recent_mean > 0 else 1
    normalized_std = cv_factor

    # Determine density: high density = many small items (low normalized std)
    # When std is low relative to mean → stream is dense with small items
    # When std is high → stream has larger, more variable items
    is_dense = normalized_std < 1.2

    if is_dense:
        # High density: prefer best-fit (fill tighter first)
        return bins - item
    else:
        # Low density: prefer worst-fit with regret (preserve gaps)
        cap = bins.astype(np.float64)
        q90 = np.percentile(cap, 90.0)
        slack = cap - item
        regret = q90 - cap

        # Highest regret = furthest from 90th → keep them for large items
        return regret * 0.5 - slack
# EVOLVE-BLOCK-END
