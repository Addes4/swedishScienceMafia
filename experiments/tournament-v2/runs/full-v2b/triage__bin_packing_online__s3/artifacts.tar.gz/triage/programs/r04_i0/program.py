# EVOLVE-BLOCK-START
"""Weibull-aware expected-waste bin ranking.

We maintain an online maximum-likelihood fit of a Weibull(size) distribution
to the sizes seen so far.  The CDF F and the residual-mass function

    R(r) = E[size - r | size > r] * P(size > r)

are used to estimate, for any bin with remaining capacity `c`, how much of
that capacity will be wasted once the stream of remaining items finishes
placing into it.  A bin that is being chosen now has residual `c - item`
after the placement; smaller expected waste is better.

Concretely, for a bin that currently has residual capacity `r`, the expected
waste W(r) is modeled as:

    W(0) = 0
    W(r) = sum over items that could still arrive of max(0, size - (r - used))

Rather than a full DP we use the smooth closed form based on the residual
mass: a bin of residual r wastes roughly

    w(r) ~ r - integral_0^r P(size <= u) du  ... proportional to F-distribution

More useful and stable is the "fill fraction" heuristic derived from the
Weibull fit:

    expected utilisation of a residual r,
        r * F(r) + integral_0^r (r - x) dF(x)
      = integral_0^r F(x) dx

so the expected *waste* of a residual-r bin is

    w(r) = r - integral_0^r F(x) dx = integral_0^r (1 - F(x)) dx
         = integral_0^r SF(x) dx

which we approximate numerically with the fitted Weibull survival function
SF.  Lower w(r) is better.  We combine this exact-in-the-model term with a
tiny best-fit tiebreak so the ranking is never flat.

The fit is a moment-based Weibull estimator updated online (cheap, no scipy
calls in the hot path beyond the vectorised survival evaluation, and numpy
only).  Shape k and scale lambda are updated from log-sizes:

    E[ln X] = ln lambda + psi(1)/k  -> gives k from var of ln X.

All computation is O(len(bins)) per item and uses only numpy.
"""
import numpy as np

_state = {
    "n": 0,
    "s1": 0.0,       # sum of log sizes
    "s2": 0.0,       # sum of log-size squares
    "k": 2.0,        # Weibull shape
    "lam": 40.0,     # Weibull scale
    "grid": None,    # cached grid of residual capacities
    "KINT": None,    # cached integral table
}


def _update_fit(item):
    st = _state
    st["n"] += 1
    if item <= 0:
        return
    lx = np.log(float(item))
    st["s1"] += lx
    st["s2"] += lx * lx
    n = st["n"]
    if n < 20:
        return
    mean = st["s1"] / n
    var = st["s2"] / n - mean * mean
    if var < 1e-6:
        return
    # psi(1) = -gamma, psi'(1) = pi^2/6 = 1.6449340668482264
    # var(ln X) = pi^2 / (6 k^2)
    k = np.pi / np.sqrt(6.0 * var)
    if k < 0.3:
        k = 0.3
    elif k > 12.0:
        k = 12.0
    # mean(ln X) = ln lam - gamma / k
    gamma = 0.5772156649015329
    lam = np.exp(mean + gamma / k)
    if lam < 1.0:
        lam = 1.0
    elif lam > 120.0:
        lam = 120.0
    st["k"] = k
    st["lam"] = lam


def _integral_table(k, lam, upto):
    """Return array T[0..upto] with T[r] = integral_0^r SF(x) dx,
    where SF is the Weibull survival function.  Vectorised."""
    xs = np.arange(upto + 1, dtype=np.float64)
    z = xs / lam
    sf = np.exp(-np.power(z, k))
    # cumulative trapezoid, step 1
    T = np.empty(upto + 1, dtype=np.float64)
    T[0] = 0.0
    if upto > 0:
        seg = 0.5 * (sf[:-1] + sf[1:])
        np.cumsum(seg, out=T[1:])
    return T


def priority(item, bins):
    st = _state
    _update_fit(item)

    cap = bins.astype(np.float64)
    residual = cap - item          # residual after placing here, >= 0
    residual = np.maximum(residual, 0.0)

    # Build/refresh the expected-waste table for integer residuals 0..100.
    upto = 100
    T = st["KINT"]
    if T is None or st.get("last_k") != st["k"] or st.get("last_lam") != st["lam"]:
        T = _integral_table(st["k"], st["lam"], upto)
        st["KINT"] = T
        st["last_k"] = st["k"]
        st["last_lam"] = st["lam"]

    # Expected waste of a bin with integer residual r is T[r].
    # Interpolate linearly for fractional residuals.
    ri = np.clip(residual, 0.0, float(upto))
    lo = np.floor(ri).astype(np.int64)
    hi = np.minimum(lo + 1, upto)
    frac = ri - lo
    waste = T[lo] * (1.0 - frac) + T[hi] * frac

    # Lower expected waste is better.  Add a tiny best-fit tiebreak so ties
    # among near-identical wastes resolve toward the tighter fit.
    tiny = 1e-4 * residual
    score = -waste - tiny
    return score
# EVOLVE-BLOCK-END
