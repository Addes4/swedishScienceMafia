# EVOLVE-BLOCK-START
"""Online actor-critic bin ranking with a potential-based reward shaping.

Idea
----
We score each candidate bin with a *linear* function of a small feature vector
and learn the coefficient vector online (actor-critic style) instead of relying
on hand-tuned constants.  The episode reward is `-waste` (equivalently the
negative number of bins used beyond the lower bound), which is only known at
the end of the episode.  To make each one-step decision trainable we use
potential-based reward shaping:

    r_t = gamma * Phi(s_{t+1}) - Phi(s_t)

where the potential Phi measures how "healthy" the current bin configuration
is.  A natural, cheap potential is a function of the observed residual
capacities:

    Phi(state) = -alpha * mean(residual) + beta * frac_open_bins

i.e. keeping total residual capacity high (bins not fragmented) is good, and
keeping the number of opened bins low is good.  The shaped reward telescopes
and, for gamma = 1, exactly equals the true episodic reward plus a boundary
term, so per-step updates optimize the real objective.

The critic is a linear value estimate V(s) = w . phi(state).  For each arriving
item we score bins with the actor's linear rule

    score(bin) = a . f(bin, item)

and pick the argmax.  After the pick we compute the shaped reward and update
both actor and critic with a standard temporal-difference / policy-gradient
step.  All quantities are scalar numpy operations, so 5000 calls run well
inside the time limit.
"""
import numpy as np


# ---------------------------------------------------------------- state ----
_state = {
    # Actor weights over bin+item features.
    "a": np.array([-1.0, 0.55, 0.18, 0.05, -0.10], dtype=np.float64),
    # Critic weights over global state features.
    "w": np.zeros(4, dtype=np.float64),
    # Running statistics for normalization.
    "steps": 0.0,
    "mean_r": 0.0,
    "var_r": 1.0,
    # Last decision context (for the update on the *next* call).
    "prev_feat": None,   # feature vector of the bin chosen last time
    "prev_sfeat": None,  # global state features before the last placement
    "prev_pot": 0.0,
}

# Learning rates (small; decisions are noisy and bins many).
_ALPHA_ACTOR = 0.010
_ALPHA_CRITIC = 0.020
_GAMMA = 0.999          # near-undiscounted so shaping ~ truth
_EPS = 1e-8


# ------------------------------------------------------------- features ----
def _state_features(cap):
    """Global features describing the current set of usable bins."""
    n = cap.shape[0]
    if n == 0:
        return np.zeros(4, dtype=np.float64)
    mean_res = float(np.mean(cap))
    # How many bins are essentially empty vs partially used.
    frac_full = float(np.mean(cap < 60.0))
    frac_empty = float(np.mean(cap >= 99.0))
    # Dispersion of residuals: high spread => fragmented pool.
    std_res = float(np.std(cap))
    return np.array([mean_res / 100.0, frac_full, frac_empty, std_res / 100.0],
                    dtype=np.float64)


def _potential(sfeat):
    """Scalar potential Phi(s) from global state features.

    Rewards keeping mean residual high and the pool unfragmented.
    """
    return float(sfeat[0] * 1.0 - 0.5 * sfeat[3] + 0.3 * sfeat[2])


def _bin_features(cap, item):
    """Per-bin feature matrix used by the actor.

    Columns:
      0: slack            = residual - item (want tight fit => negative weight)
      1: normalized residual (prefer fuller bins moderately)
      2: regret vs 90th percentile of residual capacity
      3: fit quality      = item / residual (packing efficiency)
      4: is-roomy flag    = residual >= 100 - item (room for another like item)
    """
    n = cap.shape[0]
    slack = cap - item
    norm_res = cap / 100.0
    q90 = np.percentile(cap, 90.0)
    regret = (q90 - cap) / 100.0
    fit = item / np.maximum(cap, 1.0)
    roomy = (cap >= (100.0 - item)).astype(np.float64)
    feats = np.empty((n, 5), dtype=np.float64)
    feats[:, 0] = slack / 100.0
    feats[:, 1] = norm_res
    feats[:, 2] = regret
    feats[:, 3] = fit
    feats[:, 4] = roomy
    return feats


# ---------------------------------------------------------------- update ---
def _td_update(shaped_reward, sfeat):
    """One actor-critic step using the *stored* previous decision."""
    st = _state
    prev_feat = st["prev_feat"]
    prev_sfeat = st["prev_sfeat"]
    if prev_feat is None or prev_sfeat is None:
        return

    # Critic: linear value estimates.
    v_prev = float(st["w"] @ prev_sfeat)
    v_cur = float(st["w"] @ sfeat)
    target = shaped_reward + _GAMMA * v_cur
    td_err = target - v_prev

    # Normalize reward scale so learning rates behave consistently.
    st["steps"] += 1.0
    m = st["mean_r"]
    st["mean_r"] += (td_err - m) / st["steps"]
    st["var_r"] += (td_err - m) * (td_err - st["mean_r"])
    scale = 1.0 / np.sqrt(st["var_r"] / st["steps"] + _EPS)
    g = float(np.clip(td_err * scale, -5.0, 5.0))

    # Critic update.
    st["w"] += _ALPHA_CRITIC * g * prev_sfeat
    np.clip(st["w"], -5.0, 5.0, out=st["w"])

    # Actor update: gradient of chosen-score w.r.t. its own features.
    st["a"] += _ALPHA_ACTOR * g * prev_feat
    np.clip(st["a"], -5.0, 5.0, out=st["a"])


# ------------------------------------------------------------------ main ---
def priority(item, bins):
    st = _state
    cap = bins.astype(np.float64)

    # Global state features *before* placement.
    sfeat = _state_features(cap)

    # Apply the pending actor-critic update from the previous decision, using
    # the potential-based shaped reward on the transition we just completed.
    cur_pot = _potential(sfeat)
    shaped = _GAMMA * cur_pot - st["prev_pot"]
    _td_update(shaped, sfeat)
    st["prev_pot"] = cur_pot

    # Actor scores every candidate bin.
    feats = _bin_features(cap, item)
    scores = feats @ st["a"]

    # Store the feature vector of the bin we are about to choose *before*
    # knowing which one the harness picks (it picks argmax; ties -> first).
    best = int(np.argmax(scores))
    st["prev_feat"] = feats[best].copy()
    st["prev_sfeat"] = sfeat.copy()

    # Return scores; ensure no NaN and finite.
    scores = np.nan_to_num(scores, nan=0.0, posinf=1e9, neginf=-1e9)
    return scores
# EVOLVE-BLOCK-END
