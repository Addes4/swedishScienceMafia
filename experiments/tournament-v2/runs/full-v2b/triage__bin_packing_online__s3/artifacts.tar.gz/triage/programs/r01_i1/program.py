# EVOLVE-BLOCK-START
"""Hybrid: tightness - epsilon * (rejection count) to prefer fresher bins on ties."""
import numpy as np


_eps = 1e-9                    # tiny tie-breaker: newer (less rejected) bins win
_rej = None                    # rejection counter, allocated on first call


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global _rej, _eps
    
    # initialise the rejection tracker with the same length as the number of bins
    if _rej is None or len(_rej) < len(bins):
        # extend if more bins appear (first call or growth due to new unused bins)
        old = _rej if _rej is not None else np.zeros(0, dtype=np.int64)
        _rej = np.zeros(len(bins), dtype=np.int64)
        _rej[:len(old)] = old
    
    # The harness passes **all** bins (including unnecessary ones), so we keep _rej aligned.
    # However, bins is a copy; we only need the length for indexing.
    # At the end we record which bin index was chosen and increment rejections for the others.
    
    # Compute scores: prefer tight fit, then lower rejection count.
    scores = -(bins - item) - _eps * _rej[:len(bins)]
    
    # The real bin choice happens after this function returns, so we cannot update _rej here.
    # Instead, we update _rej lazily based on the fact that the harness always calls
    # priority() exactly once per item and places the item into the bin we rank highest.
    # We need to know WHICH bin was chosen. We can detect that by storing the scores we
    # returned and checking on the next call which bin has been modified (capacity decreased
    # by item). However, we cannot see the bins before the call. An alternative is to
    # maintain a "call counter" and simulate the placement retroactively.
    # Simpler: we augment the global state with the last bins array and last item to
    # retroactively update rejections.
    
    # We'll store current bins reference and item for the next call to compute the chosen index.
    # Actually we can just store them globally:
    global _last_item, _last_bins
    if '_last_item' in globals() and _last_item is not None:
        # Figure out which bin was chosen: it's the one whose capacity decreased by _last_item.
        # The harness gives us fresh bins copy each time, but bin ordering is fixed.
        # previous bins: _last_bins   current bins: bins
        # The chosen bin index is where (previous capacity - current capacity) == _last_item.
        # However, if a new unused bin was added, lengths can differ. We'll align to min length.
        prev = _last_bins
        cur = bins
        n = min(len(prev), len(cur))
        diff = prev[:n] - cur[:n]
        chosen_mask = (diff == _last_item)
        if chosen_mask.any():
            idx = int(np.argmax(chosen_mask))  # first match if multiple (ties handled by harness)
            # increment rejections for all bins *except* the chosen one
            _rej[:n] += 1
            _rej[idx] -= 1
    
    # Save current item and bins for next call retroactive update
    _last_item = item
    _last_bins = bins.copy()  # copy because the harness may reuse the array
    
    return scores
# EVOLVE-BLOCK-END
