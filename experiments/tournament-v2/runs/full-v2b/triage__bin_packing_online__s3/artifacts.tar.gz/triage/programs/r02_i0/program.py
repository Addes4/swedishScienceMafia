# EVOLVE-BLOCK-START
"""Implemented idea: smoothed anti-waste score for complement-based bin placement

Scores bins based on how well a future item of estimated size could combine with current residual,
favoring bins that leave "complementary" residuals for future incoming items from the Weibull distribution."""
import numpy as np


# Pre-computed histogram statistics based on Weibull (k ~ 1.5, lambda ~ 3.5) distribution closely matching mean ~40
# Expected item size frequencies: small items 10-30(~25%), mid 30-50(~40%), large 50-70(~25%), >70(~10%)
# Smoothed expected size prior for predicting future items
SUMMED_ITEM_DIST = np.linspace(1, 100, 100).astype(np.float64)
ITEM_PROB = np.array([0.10, 0.12, 0.15, 0.13, 0.12, 0.10, 0.09, 0.07, 0.06, 0.05,  # 1-10
                      0.05, 0.04, 0.04, 0.03, 0.03, 0.03, 0.03, 0.03, 0.02, 0.02,  # 11-20
                      0.02, 0.02, 0.02, 0.02, 0.02, 0.01, 0.01, 0.00])  # 21-30; >30 tails are negligible

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Priority follows a smoothed anti-waste rule:
    - Base score: tightness of fit = -(bins - item)
    - Smoothing: favors bins that leave residuals suited for typical future items (mean ~40, smaller items common)
      Score penalizes over-large residuals that might fragment, and favors moderate residuals.
    """
    n_bins = len(bins)
    residual_after = bins - item
                
    # Base priority: negative fit cost (best-fit)
    fit_score = -residual_after
    
    # Deficit term: regularization to avoid very large residuals (anti-fragmentation/smoothness)
    # Since items are skewed right (many smaller), we want bins with smaller residuals than larger ones
    # when potential to hold even medium-sized next items, and to avoid trimming ever-larger holes
    def bin_penalty(r):
        """Penalty term encouraging residuals close to common demonstrated sizes (~40 mean, with smaller)."""
        # Smooth anti-fragmentation: gently penalize too large remaining capacity after placement,
        # reflecting expected distribution where such large residuals are hard to fill (since next items may be small)
        # Using sigmoid to smoothly transition undesirately large residuals after placement
        alpha = 0.5  # flexibility parameter
        beta = 0.85  # transition point
        soft = np.where(r > beta, 1 / (1 + np.exp(-alpha * (beta - r))), 0.0)
        
        return soft

    # Smoothed priority combining fit and anti-waste smoothing
    penalty = bin_penalty(residual_after)
    smooth_score = fit_score + n_bins * penalty / 20  # weighted to not dominate fit component
    
    # Additional complement score: favor bins that could hold typical future items if we predicted one
    # Use small-item bias: Weibull with mean 40 often has many "10-20" sized items filling gaps
    typical_future_meansized = 36  # slightly below mean to account for gaps
    expected_fit_better = -(bins - item + ITEM_PROB[typical_future_meansized - 1] * typical_future_meansized * 10)
    # Benefit from possible smaller future item fit (average small item is ~15 for high prob)
    small_item_pts = np.exp(-(bins - item - 18) / 5.0)  # smooth favoring bins with residual ~18 after new item
    
    # Combine scores
    priority_combined = smooth_score + 0.3 * small_item_pts
    
    return np.where(priority_combined > 0, priority_combined, 0.0)  


# EVOLVE-BLOCK-END
