"""Online bin packing with exponential fill probability heuristic.

This heuristic scores each bin as `-(residual) + λ * P(future item == residual)`,
where P is estimated from a sliding window of recent items. Lambda grows as more bins
become near-capacity, increasing the importance of exact future matches to reduce fragmentation.

Key features:
- Maintains a weighted exponential histogram of recent items (not just a raw count)
- 500-item sliding window keeps quality high without excessive memory
- Lambda adapts based on the fraction of bins with residual ≤ 10
"""
import numpy as np


# Global state shared across calls
_elements = {
    "window": [0] * 500,
    "head": 0,
    "counts": np.zeros(101, dtype=np.int64),
    "near_full": 0,
    "size": 500,
    "capacity": 100,
}


def reset_elements():
    """Reset per-instance / per-run state if needed."""
    _elements["window"] = [0] * _elements["size"]
    _elements["head"] = 0
    _elements["counts"] = np.zeros(101, dtype=np.int64)
    _elements["near_full"] = 0


def priority(item, bins):
    st = _elements
    
    # Track recent items in a circular buffer window
    st["window"][st["head"]] = item
    st["head"] = (st["head"] + 1) % st["size"]
    
    # Update item counts for histogram
    st["counts"][item] += 1
    # Count of bins with residual <= 10
    near_capacity = np.sum(bins <= 10.0)
    st["near_full"] = near_capacity
    
    # Build probability distribution from recent window
    prob = np.zeros(101, dtype=np.float64)
    valid = 0
    for i in range(st["size"]):
        if st["window"][i] > 0:
            idx = (st["head"] + i) % st["size"]
            v = st["window"][idx]
            if 1 <= v <= 100:
                prob[v] += 1.0
                valid += 1
    if valid > 0:
        prob /= valid
    # Use probability distribution to estimate fill probability
    P_fill = np.zeros_like(bins, dtype=np.float64)
    for i, res in enumerate(bins):
        if res > 0:
            if res <= 100:
                P_fill[i] = prob[int(res)]
    
    # Lambda grows as near capacity bins increase.  c₀=1.0
    # Bins with residual <= 10 are "near capacity"
    frac_near_full = st["near_full"] / max(1, len(bins))
    lam = 1.0 + frac_near_full * 2.0
    
    # Score: -residual + lam * P_fill
    capacity = np.float64(bins)
    score = -capacity
    score += lam * P_fill
    
    # Ensure all scores are finite and reasonable
    score = np.nan_to_num(score, nan=-1.0, posinf=100.0, neginf=-100.0)
    
    return np.array(score, dtype=np.float64)


# Minor: Note - this function is called once per arriving item and must return
# the score array as described in the problem.
