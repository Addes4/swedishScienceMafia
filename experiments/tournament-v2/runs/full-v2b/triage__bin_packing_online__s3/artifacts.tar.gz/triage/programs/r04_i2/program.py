# EVOLVE-BLOCK-START
"""Regret-weighted best-fit with an adaptive EWMA reference.

The core ranking is a linear blend of two quantities:

1. `slack = residual_capacity - item`  -- classic best fit.

2. `regret = ewma_reference - residual_capacity`  -- how far this bin's
   remaining capacity sits below an exponentially weighted moving average
   of the capacities of recently active bins.  A large positive regret means
   the bin is comparatively full, a negative regret means it is unusually
   empty.  The EWMA is updated on every placement with decay factor alpha;
   bins that are "active" (used recently or just opened) contribute to the
   EWMA with a weight proportional to their current capacity.  This makes the
   reference adapt fluidly to shifting phases in the item stream.

The blend `-slack + w * regret` therefore actively pulls the most-empty bins
down toward the moving reference band while never cheating a nearly-full bin
out of a small item.  The weight `w` and a soft large-item floor are tuned
from the observed large-item rate, all online.
"""
import numpy as np


_state = {
    "count": 0,
    "large": 0,
    "w": 0.9,          # regret weight, adapted online
    "floor": 58.0,     # size above which we shift to "roomy bin" mode
    "ewma": 100.0,     # exponentially weighted moving average of "active" bin capacities
    "alpha": 0.02,     # decay factor for EWMA (higher = faster adaptation)
}


def priority(item, bins):
    st = _state
    st["count"] += 1

    if item >= 60:
        st["large"] += 1

    n = st["count"]
    f_large = st["large"] / n

    # If large items are rarer than ~10% we can be greedy; the more common they
    # are, the more we must protect empty bins (raise weight, lower floor).
    st["w"] += 0.01 * (0.10 - f_large)
    if st["w"] < 0.4:
        st["w"] = 0.4
    elif st["w"] > 1.6:
        st["w"] = 1.6

    st["floor"] += 0.05 * (0.10 - f_large)
    if st["floor"] < 50.0:
        st["floor"] = 50.0
    elif st["floor"] > 78.0:
        st["floor"] = 78.0

    cap = bins.astype(np.float64)
    slack = cap - item
    regret = st["ewma"] - cap  # positive => bin is comparatively full

    if item >= st["floor"]:
        # Large item: push it toward the emptiest viable bins so it lands in a
        # roomy slot; slight regret term for fine-tuning.
        return slack + 0.05 * regret

    return -slack + st["w"] * regret


def after_placement(chosen_bin_capacity_after):
    """Update the EWMA reference *after* the item has been placed.

    The harness calls this (see below) with the remaining capacity of the bin
    that actually received the item, so we can incorporate its new state and
    decay the old EWMA.  We weight the chosen bin's capacity by sqrt(alpha)
    to give recently touched bins extra influence while keeping the EWMA stable.
    """
    st = _state
    alpha = st["alpha"]
    # Blend: new observation is the updated capacity of the just-used bin.
    # Using a higher effective weight for the immediate action makes the EWMA
    # more responsive to the current phase.
    st["ewma"] = (1.0 - alpha) * st["ewma"] + alpha * chosen_bin_capacity_after


# The harness expects only priority(), but we can hook into placement
# by wrapping the public function.  The eval system only calls priority(),
# so we provide a pure priority() and a mechanism to update state.
# However, the harness does NOT call after_placement automatically.
# We need to infer the chosen bin from the scores inside priority()
# by computing them and then updating the EWMA based on the top-scoring bin.
# Since priority() receives a *copy* of the bins array, we can safely
# recompute the scores, find the winner, and then update EWMA using
# the winner's capacity minus the item.
#
# Implementation note: the original priority function is called once per item.
# We augment it to also perform the EWMA update after choosing the bin.
# Because the harness owns the actual bin state and only uses our returned
# scores to pick a bin, we can simulate our own placement by computing which
# bin *will* be chosen and updating our EWMA accordingly.  This is valid
# because our scores determine the harness's choice deterministically.


def priority(item, bins):
    st = _state
    st["count"] += 1

    if item >= 60:
        st["large"] += 1

    n = st["count"]
    f_large = st["large"] / n

    st["w"] += 0.01 * (0.10 - f_large)
    if st["w"] < 0.4:
        st["w"] = 0.4
    elif st["w"] > 1.6:
        st["w"] = 1.6

    st["floor"] += 0.05 * (0.10 - f_large)
    if st["floor"] < 50.0:
        st["floor"] = 50.0
    elif st["floor"] > 78.0:
        st["floor"] = 78.0

    cap = bins.astype(np.float64)
    slack = cap - item
    regret = st["ewma"] - cap

    if item >= st["floor"]:
        scores = slack + 0.05 * regret
    else:
        scores = -slack + st["w"] * regret

    # Determine which bin the harness will choose (highest score, ties to first).
    best_idx = int(np.argmax(scores))
    # Compute the capacity of that bin after placing the item.
    chosen_after = bins[best_idx] - item
    # Update the EWMA reference with this "just-used" bin state.
    st["ewma"] = (1.0 - st["alpha"]) * st["ewma"] + st["alpha"] * chosen_after

    return scores
# EVOLVE-BLOCK-END
