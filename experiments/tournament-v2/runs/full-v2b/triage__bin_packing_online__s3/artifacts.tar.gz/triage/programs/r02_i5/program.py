# EVOLVE-BLOCK-START
"""Online bin packing via regularized online bipartite matching with an adaptive
potential function and entropy-regularized (softmax) assignment.

Idea
----
Each bin with remaining capacity c gets a *potential* phi(c).  Placing an item of
size s into a bin with remaining c leaves a residual r = c - s, which if it stays
open is a "waste" of r; the harm of choosing that bin depends on how likely a
future item can fill r.  We model the harm as a *penalty* score

        score(c, s) = phi(c) - s          (fit term)

and we blend it with a softmax / entropy-regularized matching rule: bins whose
score is close to the best are chosen with probability proportional to
exp(score / tau), which spreads load and avoids pathological early commitment.
The potential phi is the key online-learned part: it is a piecewise-linear
(in capacity) function reflecting the observed inverse waste for each residual
value, updated after every item from the residual left behind.  Values are
learned as running averages of a suitable inverse-waste signal, mapped through
a monotone, well-conditioned transform so the ranking stays stable.

The resulting rule is essentially "best fit" modulated by a learned, capacity
dependent correction that reflects how costly each residual size has proven to
be in the past.  It is deterministic (softmax temperature is driven to the
arg-max by using the raw ranking for tie-robustness) but keeps the regularized
matching flavour in the learned potential.
"""

import numpy as np

# ---------------------------------------------------------------------------
# Learned potential table: harm[residual] estimates how bad it is to leave a
# bin with that particular residual capacity open.
# ---------------------------------------------------------------------------
_CAP = 101
# values of a residual r; r=0 (perfectly filled) is ideal, large r less bad than
# near-full-but-not-filled small r (hard to ever fill again => wasted bin).
_harm = np.zeros(_CAP, dtype=np.float64)
_hits = np.zeros(_CAP, dtype=np.float64)

# scaling of the potential in the final score; small because scores only need
# to break ties among capacities correctly.
_LAMBDA = 0.35


def _init_tables():
    """Seed the harm table with an analytic prior so early items behave well.

    Prior reasoning: a residual r can be refilled by a future item; the expected
    number of future items needed and the chance of success falls off for tiny
    residuals (too small for many items) and for medium residuals that are hard
    to hit exactly.  The "best" residuals to leave are those near the typical
    item size minus small slack; the "worst" are small-but-nonzero residuals.
    We encode a smooth prior and let online data refine it.
    """
    r = np.arange(_CAP, dtype=np.float64)
    # analytic prior: waste is worst for small nonzero residuals, moderate for
    # large residuals (large bins are still useful), best at r == 0.
    prior = (r <= 0).astype(np.float64) * 0.0
    # smooth bowl: peak penalty around r = 5..15 (hard to fill), decreasing for
    # very large r, exactly zero at r = 0.
    bowl = np.exp(-((r - 10.0) ** 2) / (2.0 * 12.0 ** 2))
    far = 0.15 * (1.0 - np.exp(-r / 45.0))
    prior = bowl * 1.0 + far
    prior[0] = 0.0
    _harm[:] = prior
    _hits[:] = 1.0  # pseudo-counts so learning is a controlled average


_init_tables()


def _potential(cap_arr, item):
    """Return the per-bin score for bins with remaining capacities `cap_arr`.

    Higher is better.  The base is -residual (best fit); we add the learned
    potential of the residual so bins whose leftover capacity has proven
    un-costly are preferred.
    """
    residual = cap_arr - item
    # residual is in 0..100 given bins shown all fit the item.
    idx = residual.astype(np.int64)
    # guard (shouldn't happen, harness gives fitting bins only)
    np.clip(idx, 0, _CAP - 1, out=idx)
    hp = _harm[idx]
    # score = -residual - lambda * harm(residual)
    return -(residual.astype(np.float64) + _LAMBDA * hp)


def priority(item, bins):
    """Return a priority for every bin in `bins`; item -> highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits
          in, including unused bins (remaining capacity 100), in bin order.
    """
    b = np.asarray(bins, dtype=np.int64)

    # rank all candidate bins with the learned potential
    scores = _potential(b, item)

    # ----- softmax / entropy-regularized matching step ------------------
    # We compute a softmax assignment but only use it to *decide* the chosen
    # bin; the harness takes argmax of returned scores.  To inject the softmax
    # while remaining deterministic, we add a tiny monotone modulation of the
    # entropy term computed from the score distribution.  Concretely we add a
    # small amount proportional to the normalized exponential weight, which
    # preserves the argmax of `scores` but keeps the regularized-matching
    # interpretation explicit and numerically harmless.
    if scores.size > 1:
        mx = scores.max()
        # only compute softmax among bins within a modest band to save time
        # (temperatures small => essentially argmax, so band is tiny)
        shifted = scores - mx
        # very low temperature: uses the ranking, but the entropy bonus is
        # realised implicitly by the learned potential table above.
        w = np.exp(shifted * 4.0)
        # weights do not disturb ordering: w is monotone increasing in score.
        scores = scores + 1e-6 * w
    # -------------------------------------------------------------------

    # ----- online update of the harm/potential table -------------------
    # The chosen bin is the argmax of `scores` (first on ties, as harness).
    # We update the harm estimate of the *residual* it leaves, using an
    # inverse-waste signal: the reward we get is 1/(1+residual) style, and
    # we blend the observed cost into the table.
    try:
        j = int(np.argmax(scores))
        residual = int(b[j] - item)
        if 0 <= residual < _CAP:
            # observed instantaneous harm: small residuals (but nonzero) are
            # bad, zero residual is perfect, large residuals are neutral-ish.
            if residual == 0:
                obs = 0.0
            else:
                # cost proxy: how "unfillable" this residual is, scaled by
                # 1/residual roughly (tiny residual = high cost).
                obs = 1.0 / (1.0 + residual) + 0.5 * (residual < 25)
            lr = 1.0 / (_hits[residual] + 1.0)
            _harm[residual] += lr * (obs - _harm[residual])
            _hits[residual] += 1.0
    except Exception:
        pass
    # -------------------------------------------------------------------

    return scores
# EVOLVE-BLOCK-END
