# EVOLVE-BLOCK-START
"""Multiplicative fit x scarcity bin-choice rule.

For each candidate bin we form two factors and return their product:

1. ``fit`` -- a Gaussian-shaped reward on ``slack = residual - item``, peaking
   at zero slack.  Tight fits (slack ~ 0) score near 1, while slack of one or
   two item-widths decays smoothly so that a snug bin is strongly preferred but
   not infinitely so.  This replaces a hard "-slack" linear term with a bounded,
   self-normalizing preference that cannot be gamed by one huge residual.

2. ``scarcity`` -- an exponential penalty for depleting capacity from bins
   whose residual is below a dynamically tracked threshold, taken as the low
   quantile (20th percentile) of the currently open bins.  Bins below the
   threshold are "scarce": they carry little optionality for the future, so
   every unit taken from them is charged exponentially.  Bins above the
   threshold are abundant and are essentially free to consume.

Because the two factors multiply, a bin only gets drained despite its scarcity
when the fit is *exceptionally* good -- a tight geometric match overrides the
scarcity charge.  Otherwise the abundant bins absorb the item and scarce bins
are preserved, which keeps empty bins available for large future arrivals.

The scarcity threshold quantile and the penalty strength are adapted online
from the running mean item size, so the rule sharpens when items are small
(more fragmentation risk) and relaxes when items are large.
"""
import numpy as np


_state = {
    "count": 0,
    "sum": 0.0,
    "q": 20.0,      # low quantile defining the scarcity threshold
    "strength": 0.030,  # exponential penalty slope per unit below threshold
    "width": 26.0,  # slack decay scale for the fit term
}


def priority(item, bins):
    st = _state
    st["count"] += 1
    st["sum"] += item

    mean_item = st["sum"] / st["count"]

    # Adapt the scarcity quantile: when items are on the small side we look
    # further up the capacity distribution to define "scarce".
    target_q = 24.0 - 12.0 * (mean_item / 100.0)
    st["q"] += 0.02 * (target_q - st["q"])
    if st["q"] < 8.0:
        st["q"] = 8.0
    elif st["q"] > 30.0:
        st["q"] = 30.0

    # Penalty slope scales with item size: big items consume more optionality
    # per placement, so depleting a scarce bin costs more.
    st["strength"] += 0.001 * ((item / 60.0) - st["strength"] / 0.030)
    st["strength"] = min(max(st["strength"], 0.010), 0.060)

    cap = bins.astype(np.float64)
    slack = cap - item

    # --- fit term: rewards near-zero slack, smooth Gaussian bump ---
    width = st["width"]
    fit = np.exp(-(slack * slack) / (2.0 * width * width))
    # slight extra pull toward the tightest fit
    fit /= (1.0 + 0.010 * slack)

    # --- scarcity term: exponential drain charge below the threshold ---
    thr = np.percentile(cap, st["q"])
    # amount of capacity below the threshold (0 if bin is above it)
    below = np.maximum(thr - cap, 0.0)
    scarcity = np.exp(-st["strength"] * below)

    score = fit * scarcity
    return score
# EVOLVE-BLOCK-END
