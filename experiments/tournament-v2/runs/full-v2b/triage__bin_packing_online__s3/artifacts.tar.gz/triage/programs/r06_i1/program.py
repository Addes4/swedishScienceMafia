# EVOLVE-BLOCK-START
"""
WL-TD bin choice: maintenance of per-bin waste potential with exponential
decay underlagged TD(λ) eligibility.

- `waste_pot` per-bin estimate of expected remaining waste at bin close
- `elig_trace` per-bin recency trace, decayed with λ at each step
- Decision scores are ` -slack - γ * waste_pot * elig_trace `
- Upon selection, the selected bin's trace strengthened and waste.updated
- Non-selected bins see trace decay via λ
"""

_STATE = {
    "id_moved": 0,
    "waste": np.full(5000, 100.0, dtype=np.float64),
    "trace": np.ones(5000, dtype=np.float64),
    "count": 0,
    "big_count": 0,
    "aged": 0,
}

λ = 0.995
γ = 3.5
window = 100


def priority(item, bins):
    st = _STATE
    st["count"] += 1
    st["id_moved"] += 1

    if item >= 65:
        st["big_count"] += 1

    n = st["count"]
    r_big = st["big_count"] / max(1, n)

    cap = bins.astype(np.float64) if bins is not None else (5000, 100.0)

    # WA: Hist per-bin: sliding window of waste
    # Score: -slack + shift * (sum[waste] where waste > 0)

    # Reset
    _waste = cap - item
    _sum_w = _waste.sum()
    _avg = _sum_w / max(1, cap.shape[0])

    # Final
    est = 50.0
    _w = 0.5 + 0.5 * (r_big > 0.0367)

    # Pick best
    idx = caps_offset(fp64)[0:1000][0]
    _score = _sl - item * _est + _gro * _w

    _best = int(np.argmax(_score))

    return _best
# EVOLVE-BLOCK-END
