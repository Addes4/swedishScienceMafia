import numpy as np
from collections import deque

# ---------- kernel regressor for expected extra-bins cost ----------
# We maintain a sparse set of "prototype" (item, residual_after) pairs and
# their target values (observed extra bins needed later).  The target is
# updated online from experience: when a bin is *used*, we know what happened
# next.  Because we cannot change the past, we store a short history of
# decisions and later assign credit.

class KernelValue:
    """Online Nadaraya-Watson kernel regression with Gaussian kernel."""
    def __init__(self, bw_item=12.0, bw_res=12.0, max_points=2000):
        self.bw_item = bw_item
        self.bw_res = bw_res
        self.max_points = max_points
        self.X = np.empty((0, 2), dtype=np.float64)   # (item, residual_after)
        self.y = np.empty((0,), dtype=np.float64)
        self.count = 0

    def add(self, item, resid_after, target):
        pt = np.array([[item, resid_after]], dtype=np.float64)
        if self.X.shape[0] >= self.max_points:
            # keep a random-ish subset by replacing oldest
            idx = self.count % self.max_points
            self.X[idx] = pt
            self.y[idx] = target
        else:
            self.X = np.vstack([self.X, pt])
            self.y = np.append(self.y, target)
        self.count += 1

    def predict(self, items, resids):
        """Return expected extra-bins for each (item, resid_after)."""
        if self.X.shape[0] == 0:
            return np.zeros_like(items)
        pts = np.column_stack([items, resids])
        # pairwise squared distances
        # (N_pts, N_proto) = sum (pt_i - proto_j)^2 / bw^2
        d_item = (pts[:, 0][:, None] - self.X[:, 0][None, :]) / self.bw_item
        d_res = (pts[:, 1][:, None] - self.X[:, 1][None, :]) / self.bw_res
        sq_dists = d_item**2 + d_res**2
        # Gaussian kernel
        K = np.exp(-0.5 * sq_dists)
        denom = K.sum(axis=1) + 1e-12
        return (K @ self.y) / denom


# ---------- global state ----------
_state = {
    "kv": KernelValue(),
    "eta": 0.12,          # learning influence, adapted online
    "count": 0,
    "large_count": 0,
    # For delayed credit assignment we keep a short FIFO of recent decisions.
    "history": deque(maxlen=120),
    # Keep track of bins we've seen so we can detect when a bin is reused.
    # The harness gives bins as a numpy int64 array of *remaining capacities*.
    # We track the last-known bins array to detect closure (capacity drop).
    "prev_bins": None,
    "prev_bins_id": None,  # not used except to detect change
    # Rolling estimate of extra bins per item to scale targets.
    "running_extra": 0.0,
    "alpha_extra": 0.002,
}


def priority(item, bins):
    st = _state
    n_total = st["count"] + 1
    st["count"] = n_total
    if item >= 60:
        st["large_count"] += 1

    f_large = st["large_count"] / n_total
    # Adapt eta: higher large-item rate => trust learned cost more.
    target_eta = 0.05 + 0.25 * f_large
    st["eta"] += 0.01 * (target_eta - st["eta"])
    if st["eta"] < 0.02:
        st["eta"] = 0.02
    elif st["eta"] > 0.40:
        st["eta"] = 0.40

    # --- credit assignment from previous step ---
    current_bins = bins.copy()
    if st["prev_bins"] is not None:
        prev = st["prev_bins"]
        # capacity changes from prev to current (ignoring new empty bins)
        min_len = min(len(prev), len(current_bins))
        p = prev[:min_len]
        c = current_bins[:min_len]
        used_mask = (c < p)  # bin consumed capacity
        if used_mask.any():
            # For each used bin, we approximate how many *extra* bins it cost.
            # We simply count how many new bins appeared (capacity 100 that
            # are now < 100 or below).
            new_bins_count = 0
            for k in range(len(prev), len(current_bins)):
                if current_bins[k] < 100:
                    new_bins_count += 1
            # Also if a previously partially filled bin was filled completely,
            # that also counts as "one more bin used now".
            # Simple proxy: average extra bins per consumed bin.
            n_used = used_mask.sum()
            extra_per_used = new_bins_count / n_used if n_used > 0 else 0.0
            # Exponential moving average of extra bins.
            st["running_extra"] = (1 - st["alpha_extra"]) * st["running_extra"] + st["alpha_extra"] * extra_per_used

            # Now assign credit to past decisions that correspond to those used bins.
            # We go through history in reverse chronological order.
            if st["history"]:
                # For each consumed bin we need to find the corresponding decision.
                # The harness fills bins in index order (ties to first), but we
                # only know which bin was chosen from history.  We recorded
                # (item, chosen_bin_capacity_before, chosen_bin_index?) at decision
                # time.  However, bin index can shift? Harness keeps bins in fixed
                # order; unused bins are appended at the end? The problem says
                # "There are as many bins as items; unused bins have remaining
                # capacity 100 and are included." So bin order is stable.
                # We can match by looking at the bin's capacity before.
                # We recorded (item, cap_before, bin_index).  The bin_index
                # is valid as long as no bins before it were removed (they aren't).
                idx_used = np.where(used_mask)[0]
                for idx in idx_used:
                    # find most recent history entry whose bin_index == idx
                    for h in reversed(st["history"]):
                        if h[2] == idx:
                            h_item = h[0]
                            h_cap_before = h[1]
                            h_cap_after = c[idx]  # current remaining capacity
                            # Target: the observed extra bins per this bin,
                            # scaled slightly.
                            target = st["running_extra"]
                            st["kv"].add(h_item, h_cap_after, target)
                            # Remove this entry to avoid double-use
                            st["history"].remove(h)
                            break
        # also update if some bins from history were closed but not captured?
        # The used_mask catches any decrease; that's enough.

    st["prev_bins"] = current_bins

    # --- scoring for current item ---
    cap = bins.astype(np.float64)
    slack = cap - item   # larger slack = emptier bin
    resid_after = cap - item  # same as slack
    # predicted extra bins for each candidate
    extra = st["kv"].predict(np.full_like(cap, item), resid_after)
    # score: prefer small slack (tight fit), minus penalty for predicted cost
    scores = -slack - st["eta"] * extra

    # Record the decision for future credit (we'll fill after harness picks)
    # We cannot know which bin will be chosen until after the call,
    # but we can store all candidates? We store the best-score bin index.
    best_idx = int(np.argmax(scores))
    st["history"].append((item, cap[best_idx], best_idx))

    return scores
