import numpy as np
from collections import defaultdict

class QLearningBinPacker:
    def __init__(self):
        # Q-learning parameters
        self.alpha = 0.1  # learning rate
        self.gamma = 0.9  # discount factor
        self.epsilon = 0.1  # exploration rate
        
        # Tile coding for state representation
        # We'll discretize item size and bin fullness into tiles
        self.n_tiles = 8
        self.n_tilings = 4
        
        # State space: item size (0-100) and bin residual capacity (0-100)
        # We'll normalize both to [0,1] and use tile coding
        self.item_size_w = np.linspace(0, 1, self.n_tiles + 1)  # boundaries for tiles
        self.residual_w = np.linspace(0, 1, self.n_tiles + 1)
        
        # Q-table: maps (item_tile, residual_tile, tiling_index) to Q-value
        self.Q = defaultdict(float)
        
        # Episode memory
        self.episode_states = []
        self.episode_actions = []
        self.episode_rewards = []
        
        # Bin tracking within episode
        self.bin_states = []  # track residual capacities of all bins
        self.step_count = 0
        
    def get_tiles(self, item_size, residual):
        """Get active tiles for a given item size and residual capacity."""
        # Normalize to [0, 1]
        item_norm = item_size / 100.0
        residual_norm = residual / 100.0
        
        active_tiles = []
        
        # Apply tilings with different offsets
        for tiling in range(self.n_tilings):
            # Shift the boundaries for each tiling
            offset = tiling / (self.n_tilings * self.n_tiles)
            
            # Find item tile
            item_pos = item_norm + offset
            item_tile = int(item_pos * self.n_tiles)
            if item_tile >= self.n_tiles:
                item_tile = self.n_tiles - 1
            if item_tile < 0:
                item_tile = 0
                
            # Find residual tile
            resid_pos = residual_norm + offset
            resid_tile = int(resid_pos * self.n_tiles)
            if resid_tile >= self.n_tiles:
                resid_tile = self.n_tiles - 1
            if resid_tile < 0:
                resid_tile = 0
                
            active_tiles.append((item_tile, resid_tile, tiling))
            
        return active_tiles
    
    def get_q_value(self, item_size, residual):
        """Get the Q-value for a state-action pair (action is choosing a bin with this residual)."""
        tiles = self.get_tiles(item_size, residual)
        q_val = 0.0
        for tile in tiles:
            q_val += self.Q[tile]
        return q_val / len(tiles)
    
    def update_q_value(self, item_size, residual, reward, next_item_size=None, next_residuals=None):
        """Update Q-value for a state-action pair."""
        tiles = self.get_tiles(item_size, residual)
        
        # Current Q-value
        current_q = self.get_q_value(item_size, residual)
        
        # Next state value (max over possible next residuals if available)
        if next_residuals is not None and len(next_residuals) > 0:
            next_q_values = [self.get_q_value(next_item_size, r) for r in next_residuals]
            max_next_q = max(next_q_values)
        else:
            max_next_q = 0.0
            
        # TD error
        td_error = reward + self.gamma * max_next_q - current_q
        
        # Update each tile
        for tile in tiles:
            self.Q[tile] += self.alpha * td_error / len(tiles)
    
    def end_episode(self):
        """Apply Q-learning updates for the entire episode."""
        if len(self.episode_states) < 2:
            self.reset_episode()
            return
            
        # Go through episode in reverse order for proper credit assignment
        for t in range(len(self.episode_states) - 1):
            item_size = self.episode_states[t][0]
            residual = self.episode_states[t][1]
            reward = self.episode_rewards[t]
            
            next_item_size = self.episode_states[t+1][0]
            # For next state, consider all bin residuals that were available
            next_residuals = self.bin_states[t+1] if t+1 < len(self.bin_states) else [100.0]
            
            self.update_q_value(item_size, residual, reward, next_item_size, next_residuals)
        
        # Final state update (no next state)
        if len(self.episode_states) > 0:
            final_item = self.episode_states[-1][0]
            final_residual = self.episode_states[-1][1]
            final_reward = self.episode_rewards[-1]
            self.update_q_value(final_item, final_residual, final_reward)
        
        self.reset_episode()
    
    def reset_episode(self):
        """Reset episode memory."""
        self.episode_states = []
        self.episode_actions = []
        self.episode_rewards = []
        self.bin_states = []
        self.step_count = 0

# Global instance of the learner
learner = QLearningBinPacker()

def priority(item, bins):
    """
    Return a priority for every bin in `bins`; the item goes to the highest (first on ties).
    
    Uses Q-learning with tile coding to estimate expected future bins needed.
    """
    global learner
    
    # If exploration, choose randomly
    if np.random.random() < learner.epsilon:
        scores = np.random.rand(len(bins))
        # Still record state for learning
        best_bin_idx = np.argmax(scores)
        best_residual = bins[best_bin_idx]
        
        # Record current state and action
        learner.episode_states.append((item, best_residual))
        learner.episode_actions.append(best_bin_idx)
        
        # Update future state estimates
        if hasattr(learner, 'previous_item'):
            # Reward for previous step: -1 if new bin was opened, else 0
            prev_bin_idx = learner.episode_actions[-2] if len(learner.episode_actions) > 1 else 0
            prev_residual = learner.episode_states[-2][1] if len(learner.episode_states) > 1 else 100
            prev_item = learner.episode_states[-2][0] if len(learner.episode_states) > 1 else 0
            
            # Check if previous action opened a new bin
            if prev_residual == 100:  # was a fresh bin
                reward = -1.0  # penalty for using a new bin
            else:
                reward = 0.0  # no penalty for using existing bin
                
            learner.episode_rewards.append(reward)
        
        learner.previous_item = item
        
        # Check if episode is done (5000 items)
        learner.step_count += 1
        if learner.step_count >= 5000:
            learner.end_episode()
            learner.step_count = 0
            
        return scores
    
    # Compute Q-values for each bin
    q_values = np.zeros(len(bins))
    for i, residual in enumerate(bins):
        q_values[i] = learner.get_q_value(item, residual)
    
    # The higher the Q-value, the better (we want to minimize negative rewards)
    # Since we get -1 for new bins, higher Q means better
    scores = q_values
    
    # Record current state
    if len(bins) > 0:
        best_idx = np.argmax(scores)
        best_residual = bins[best_idx]
        
        learner.episode_states.append((item, best_residual))
        learner.episode_actions.append(best_idx)
        
        # Give reward for previous step
        if hasattr(learner, 'previous_item'):
            prev_bin_idx = learner.episode_actions[-2] if len(learner.episode_actions) > 1 else 0
            prev_residual = learner.episode_states[-2][1] if len(learner.episode_states) > 1 else 100
            
            if prev_residual == 100:
                reward = -1.0
            else:
                reward = 0.0
            
            learner.episode_rewards.append(reward)
        
        learner.previous_item = item
        
        # Check if episode is done
        learner.step_count += 1
        if learner.step_count >= 5000:
            learner.end_episode()
            learner.step_count = 0
    
    return scores
