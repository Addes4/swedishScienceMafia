# EVOLVE-BLOCK-START
"""Power-of-two gap partitioning with occupancy-entropy shaping.

Idea
----
Partition possible post-placement residual capacities into power-of-two
intervals: [1,2), [2,4), [4,8), [8,16), [16,32), [32,64), [64,128).
Call these gap "classes" 0..6 (class 6 also absorbs capacity 100 / unused).

For every candidate bin we look at the class its *post-placement* residual
capacity would fall into.  We maintain an online estimate of how many open
bins currently sit in each class.  Placing an item so that the resulting gap
lands in a *sparse* class is rewarded: sparse classes are the scarce "gap
sizes" of the packing, and keeping the multiset of gap sizes diverse makes it
easier to fit the unpredictable future sizes without opening new bins.

Scoring:
    score = -slack + alpha * sparse_bonus
where
    slack        = residual_capacity - item   (classic best-fit pressure,
                                                small slack preferred)
    sparse_bonus = (max_count - count_of_target_class) / max_count
                   -> 1 when the target class is empty, 0 when it is the most
                      populated class.
    alpha        = adapted from the entropy of the class-occupancy
                   distribution.  High entropy (already diverse) -> keep alpha
                   modest; low entropy (collapsed onto few classes) -> raise
                   alpha to spread gaps out again.

The alpha adaptation is fully online: we recompute the occupancy histogram
from the bins array each call (cheap, one bincount) and update a running
smoothed entropy.  No files, no future items.

This generalises best-fit: it still packs tightly (-slack dominates), but it
avoids stacking every bin into the same gap-size class, which is exactly what
preserves the ability to accept large items later.
"""

import numpy as np

# ---------------------------------------------------------------------------
# Tunables (kept small and stable; the key knob is adapted online)
# ---------------------------------------------------------------------------
_EDGES = np.array([1, 2, 4, 8, 16, 32, 64, 128], dtype=np.float64)
_N_CLASSES = len(_EDGES) - 1  # 7 classes: [1,2) ... [64,128)

_state = {
    "count": 0,
    "alpha": 0.35,        # sparse-class reward weight, adapted by entropy
    "ent_ema": None,      # smoothed entropy of class occupancy
    "hi": 0.0,            # running max class count (for normalization)
}


def _class_of(cap):
    """Map residual capacities (float array) to a power-of-two class index."""
    # np.searchsorted with side='right' minus 1 gives the interval index.
    idx = np.searchsorted(_EDGES, cap, side="right") - 1
    # capacities >= 128 land in last class; clamp.
    np.clip(idx, 0, _N_CLASSES - 1, out=idx)
    return idx.astype(np.int64)


def priority(item, bins):
    st = _state
    st["count"] += 1

    cap = bins.astype(np.float64)

    # ---- current occupancy of classes among open bins -------------------
    cur_cls = _class_of(cap)
    counts = np.bincount(cur_cls, minlength=_N_CLASSES).astype(np.float64)
    total = counts.sum()
    if total <= 0:
        total = 1.0

    # ---- entropy of the occupancy distribution, smoothed online ---------
    p = counts / total
    nz = p[p > 0]
    ent = float(-(nz * np.log(nz)).sum())
    max_ent = float(np.log(_N_CLASSES))
    rel_ent = ent / max_ent if max_ent > 0 else 0.0

    if st["ent_ema"] is None:
        st["ent_ema"] = rel_ent
    else:
        st["ent_ema"] = 0.98 * st["ent_ema"] + 0.02 * rel_ent

    # ---- adapt alpha ----------------------------------------------------
    # If the packing is already diverse (rel_ent near 1) alpha can stay low;
    # if it has collapsed (rel_ent low) push alpha up to re-diversify.
    target_alpha = 0.15 + 0.55 * (1.0 - st["ent_ema"])
    st["alpha"] += 0.02 * (target_alpha - st["alpha"])
    if st["alpha"] < 0.05:
        st["alpha"] = 0.05
    elif st["alpha"] > 0.9:
        st["alpha"] = 0.9
    alpha = st["alpha"]

    # ---- post-placement classes for each candidate bin ------------------
    new_cap = cap - item
    new_cap = np.where(new_cap < 0.0, 0.0, new_cap)  # unfit bins (should be absent)
    new_cls = _class_of(np.maximum(new_cap, 1.0))
    # Items that exactly fill a bin (new_cap == 0) are perfect: give them the
    # strongest sparse signal by treating them as an extra "full" class of
    # occupancy 0, i.e. maximal bonus.
    filled = new_cap < 1.0

    # ---- sparse bonus: reward landing in a lightly populated class ------
    max_count = counts.max()
    if max_count <= 0:
        max_count = 1.0
    st["hi"] = 0.98 * st["hi"] + 0.02 * max_count if st["hi"] > 0 else max_count
    denom = max(max_count, 1.0)

    target_count = counts[new_cls]
    sparse_bonus = (denom - target_count) / denom
    # filled bins get the best possible bonus
    sparse_bonus = np.where(filled, 1.0, sparse_bonus)

    # ---- final score ----------------------------------------------------
    slack = cap - item
    return -slack + alpha * sparse_bonus
# EVOLVE-BLOCK-END
