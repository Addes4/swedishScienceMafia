"""
Simulated Annealing-inspired Online Bin Packing.
Uses negative residual plus noise that decays with item count.
Less-used bins receive more exploration (temperature/usage scaling).
Music album: bin usage tracking, decaying temperature, noise scale.
"""
import numpy as np
import random

# Module-level persistent state (maintained across calls)
_bin_usage = np.zeros(5000, dtype=np.int64)  # One per possible bin slot
_placement_count = 0
_temp = 5.0
_decay_rate = 1 / 1000.0  # Temperature halves every 1000 items

def _ensure_bin_size(bins):
    """Bins array may vary in size; pad to max possible size."""
    max_size = 5000  # Problem states as many bins as items
    if bins.shape[0] < max_size:
        bins = np.pad(bins, (0, max_size - bins.shape[0]), constant_values=bins.max() + 1)
    return bins

def priority(item, bins):
    """
    Compute priority scores for each bin.
    Higher score = more preferred bin.
    Ties resolved by index (first wins).
    """
    global _bin_usage, _placement_count, _temp

    _placement_count += 1

    # Clip temperature bounds to avoid degenerate behavior
    _temp = max(0.01, _temp * (1.0 - _decay_rate * min(_placement_count, 5000)))

    # Base: negative residual (tighter fit = higher priority)
    residual = bins - item  # remaining space after placement
    base_priority = -residual

    # Scaling factor for usage-based exploration:
    # higher usage count → lower relative noise
    usage_scale = 1.0 + _bin_usage * 0.01

    # Noise term: decaying Gaussian magnitude
    # Closer to zero means more exploration; noise vanishes with experience.
    noise_shape = base_priority.shape
    random.seed(42 + item + _placement_count)
    noise = np.random.normal(loc=0.0, scale=_temp / np.sqrt(usage_scale), size=noise_shape)

    priority_scores = base_priority + noise

    return priority_scores.astype(np.float64)
