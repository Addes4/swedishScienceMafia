import numpy as np

# --- module-level online state (per instance starts fresh via module reload) ---
_centroid_count = 3
_ema_alpha = 0.5
_centroids = np.zeros((3, 100), dtype=np.float64)
_item_count = 0


def _select_centroid(residual_bins):
    """Select centroid for given binned residuals.
    We compute K-means-like assignment using current centroids.
    """
    distances = np.zeros(r.residuals.shape, dtype=np.float64)
    for k in range(_centroid_count):
        distances[:, k] = np.abs(residual_bins - _centroids[k, 0])
    min_d = distances.min(axis=1)
    return min_d


def priority(item, bins):
    global _item_count, _centroids
    _item_count += 1

    cap = bins.astype(np.float64)
    n_bins = len(bins)

    # Initialize centroids if not done (first item of run)
    if _item_count == 1:
        _centroids = np.full((3, 100), np.nan, dtype=np.float64)

    # Compute negative Euclidean distance to nearest centroid
    residuals = cap
    candidate_indices = np.where(residuals >= item)[0]

    if len(candidate_indices) == 0:
        # No bins fit, shouldn't happen under normal conditions
        scores = -np.inf
        for i in range(n_bins):
            if residuals[i] >= item:
                scores[i] = 0
            else:
                scores[i] = -np.inf
        return scores

    # Distance is just |residual - centroid| since centroid is scalar per centroids[k,0]
    # But we can generalize if we have multivariate centroids
    distances = np.full(len(candidate_indices), np.inf, dtype=np.float64)
    for k in range(min(3, _centroid_count)):
        if not np.isnan(_centroids[k, 0]):
            dist = np.abs(residuals[candidate_indices] - _centroids[k, 0])
            distances = np.minimum(distances, dist)

    # Score: negative distance, with heavier preference for closer bins
    scores = -distances.copy()

    # For bins that don't fit: assign a large penalty
    non_candidates = np.where(candidate_indices == n_bins, candidate_indices, [])
    for i in range(n_bins):
        if i not in candidate_indices:
            scores[i] = -np.inf

    # Tie-breaking: favor smaller index
    # Scores already ordered; return scores
    return scores
