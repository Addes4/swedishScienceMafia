# EVOLVE-BLOCK-START
"""Fragility-aware bin choice rule.

The key insight: many bins end up with "unfillable" gaps -- small residual
capacities that can never be exactly filled by any future combination of
arriving item sizes.  This rule maintains an online histogram of recent item
sizes and, for each bin under consideration, computes a fragility score:
the probability that the bin's remaining capacity (after placing the item)
cannot be partitioned into an integer combination of frequently arriving items.
The item is placed in the bin that minimizes this post-placement fragility,
weighted against the slack to also favour tight fits when fragility is similar.
"""
import numpy as np
from collections import deque


_state = {
    # sliding window of recent sizes for online distribution estimation
    "window": deque(maxlen=300),
    "size_counts": np.zeros(101, dtype=np.int64),  # 0..100
    "freq": np.zeros(101, dtype=np.float64),        # empirical pmf
    "dirty": True,          # recompute DP when histogram changes meaningfully
    "dp_table": None,       # reachable[cap] for cap in 0..100
    "last_update": 0,       # count at last DP rebuild
}


def _update_histogram(item):
    st = _state
    old_val = st["window"][0] if len(st["window"]) == st["window"].maxlen else None
    st["window"].append(item)
    st["size_counts"][item] += 1

    if old_val is not None:
        st["size_counts"][old_val] -= 1

    # Mark dirty; actual DP recomputation is deferred until needed and
    # is done at most every 50 items to save time.
    st["dirty"] = True


def _maybe_rebuild_dp():
    st = _state
    if not st["dirty"]:
        return
    if len(st["window"]) < 10:
        # Not enough data yet
        st["freq"][:] = 0.0
        st["dp_table"] = None
        st["dirty"] = False
        return

    # Build empirical pmf from window
    total = len(st["window"])
    counts = st["size_counts"]
    # Smooth with a tiny Dirichlet-like prior to avoid zero probabilities
    # for sizes that haven't appeared recently but might.
    prior = 0.5
    freq = (counts.astype(np.float64) + prior) / (total + prior * 101)
    st["freq"] = freq

    # DP: reachable[c] = probability that capacity c can be formed by
    # a multiset of independent draws from freq.
    # We treat *future* items as independent draws from freq, so the
    # probability that a bin with remaining capacity C can eventually be
    # filled exactly is reachable_C.  Fragility = 1 - reachable_C.
    MAX_CAP = 100
    reachable = np.zeros(MAX_CAP + 1, dtype=np.float64)
    reachable[0] = 1.0  # capacity 0 is trivially fillable

    # Because item sizes are positive and we only need up to 100,
    # a simple unbounded knapsack-like DP with self-convolution works.
    # We do a probability-generating function approach.
    for size in range(1, 101):
        p = freq[size]
        if p == 0.0:
            continue
        # For each existing reachable capacity, adding one item of this size
        # yields a new reachable capacity.  Since items are iid, we can
        # iterate capacities from high to low and do:
        for c in range(MAX_CAP, size - 1, -1):
            if reachable[c - size] > 0:
                # Condition on eventually getting any number of such items:
                # probability that at least one such item appears in the
                # sequence is actually complicated, but we approximate
                # by the probability that a single step reaches it,
                # which is the correct "fragility" proxy for our ranking.
                # We want the probability that some multiset exactly sums to c.
                reachable[c] = max(reachable[c], reachable[c - size] * p)
        # This single-pass DP isn't exact for multi-item combos because
        # of the max; we need a proper convolution.  Let's do a cleaner
        # method: unbounded knapsack with "at least one combination"
        # approximated by iterative convolution.
        # Actually we can do exact DP with a small state space.
    # Instead of the above hack, use a proper DP over count of items.
    # Since max capacity is only 100, we can do exact probability via
    # generating functions: F(x) = prod_{s} 1/(1 - freq[s] x^s) truncated.
    # Numerically, iterate multiplication of polynomials up to degree 100.
    poly = np.zeros(MAX_CAP + 1, dtype=np.float64)
    poly[0] = 1.0
    for s in range(1, 101):
        p = freq[s]
        if p == 0.0:
            continue
        # Multiply by 1/(1 - p x^s) = sum_{k>=0} p^k x^{k s}
        # We truncate at MAX_CAP.
        new_poly = poly.copy()
        for c in range(MAX_CAP + 1):
            if poly[c] == 0.0:
                continue
            k = 1
            while True:
                idx = c + k * s
                if idx > MAX_CAP:
                    break
                new_poly[idx] += poly[c] * (p ** k)
                k += 1
        poly = new_poly

    # poly[c] is unnormalized "weight"; the probability that a random
    # sequence eventually exactly hits c is poly[c] / Z, where
    # Z = sum over all possible totals?  Actually the generating function
    # gives the sum over compositions.  For a true probability we need
    # the absorption probability.  But relative comparisons are enough:
    # we just need a monotonic fragility score.  Normalize by max.
    if poly.sum() > 0:
        poly = poly / poly.sum()
    # Fragility = 1 - poly
    # We store fragility directly.
    fragility = 1.0 - poly
    # Edge case: capacity 0 has fragility 0.
    st["dp_table"] = fragility
    st["dirty"] = False
    st["last_update"] = st["count"]


_state["count"] = 0


def priority(item, bins):
    st = _state
    st["count"] += 1

    # Update sliding window and histogram
    _update_histogram(item)

    # Rebuild DP table periodically
    if st["count"] - st["last_update"] >= 50 or st["dp_table"] is None:
        _maybe_rebuild_dp()

    cap = bins.astype(np.int64)
    slack = cap - item

    if st["dp_table"] is not None:
        # Fragility after placing item
        frag = st["dp_table"][slack]
    else:
        # Fallback: simple best-fit
        frag = slack.astype(np.float64)

    # If multiple bins have similar fragility, prefer tighter fit (small slack).
    # Score: lower is better. Small slack = good, low fragility = good.
    # We want to MINIMIZE a combination.
    # Typical slack 0..100, typical fragility 0..1, so weight fragility by ~100
    # to make them comparable.
    score = slack + 120.0 * frag  # weight chosen empirically

    # Edge: for very large items that nearly fill a bin, fragility is less relevant
    # and a good fit is paramount.
    if item >= 70:
        score = slack + 40.0 * frag

    return -score  # harness picks highest score, so we negate
# EVOLVE-BLOCK-END
