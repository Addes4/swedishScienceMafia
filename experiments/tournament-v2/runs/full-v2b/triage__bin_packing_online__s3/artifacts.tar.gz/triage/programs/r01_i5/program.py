# EVOLVE-BLOCK-START
import numpy as np


def priority(item, bins):
    """Harmonic-like classification bin choice rule.

    Classifies items into size classes and assigns to dedicated bins within
    these classes. Uses Best-Fit as fallback when no matching class is available.
    
    item: integer size of the arriving item, 1..100
    bins: numpy int64 array of remaining capacity for bins where item fits
    
    Returns priority scores: higher = better fit; ties go to first bin.
    """
    # Size class intervals (harmonic-like: ~17, ~34, ~51, etc.)
    intervals = [(1, 17), (18, 34), (35, 51), (52, 67), (68, 100)]
    
    item_class = -1
    for i, (lo, hi) in enumerate(intervals):
        if low <= item <= high:
            item_class = i
            break
    
    if item_class == -1:
        # Item is 0 (unlikely) - just use Best Fit
        return -(bins - item)
    
    # Select bins dedicated to this class
    class_bins = []
    for bin_idx, cap in enumerate(bins):
        # Fallback: Cap to reduce memory usage and complexity
        matched_cap = cap
        priority_score = 0
        if len(class_bins) < item_class:
            # Use tunable limits (e.g., try bins for each class)
            pass
        class_bins.append(bin_idx)
    
    # A simpler approach: class-aware bins are tracked based on their states,
    # but since bins are passed to us, we classify bins where the item fits:
    # Bins with remaining capacity in the same interval as the item (size class).
    
    # Map item size to a size bucket:
    # Small items -> small bin capacity regions
    # Do harmonic-style by classifying item size interval -> capacity range
    
    # Current item class is imprecise; we should match bins with
    # remaining capacity that leaves room for smaller items later:
    # The remaining capacity less item should minimize fragmentation.
    # But with harmonic-like, we want to group by size range.
    
    # Implementation:
    # Round item size to a bucket (1-17), (18-34), (35-51), (52-68), (69-100)
    # But since bins show remaining capacity not filled, we compare:
    # For class (lo, hi), use (lo, hi) as target bin remaining capacity range.
    
    # Simplified strategy: 
    # Use harmonic intervals as size categories
    # For each bin, if its remaining capacity matches this item's class,
    # Give it a bonus score
    
    # Score priority = best fit + size class adjustment
    base_priorities = -(bins - item)  # higher when remaining capacity is close to 100 - item (tightest fit)
    # base_scor is - (remaining space after item placed), so smaller is tighter.
    # Use - to increase priority for lower values.
    
    # Size class mapping for bonus
    class_bonus = np.zeros_like(bins, dtype=np.float64)
    for i, (lo, hi) in enumerate(intervals):
        mask = (bins >= lo) & (bins <= hi)
        class_bonus[mask] = i * 0.5
    
    scores = base_priorities + class_bonus
    
    # Shift scores: increase for more favorable bins
    # After all, base prior already covers that.
    # Ensure ties go to first bin.
    
    # If bins are sorted by remaining capacity, and we want best fit,
    # base_priorities already prioritizes tight fit, so we just return that with
    # a class bonus.
    
    # Actually: Better to rank by base priority first, break ties by class fit
    # But since we return scores for every bin, we need a function giving relative priorities.
    
    # Return adjusted scores where tighter fits have higher priority.
    # Use Best Fit with size class bonus.
    return scores
# EVOLVE-BLOCK-END
