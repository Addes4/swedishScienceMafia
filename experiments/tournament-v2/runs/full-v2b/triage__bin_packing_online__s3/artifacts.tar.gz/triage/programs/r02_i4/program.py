import numpy as np
from collections import deque

K = 5  # lookahead buffer size

# Internal state: we keep a short history of the last K items that have already been placed,
# together with the bin capacities just before each placement.
# When a new item arrives, we pack the K+1 items (the new one plus the buffered last K)
# via an exhaustive search over permutations to minimize total waste.
# Then we commit the placement for the *oldest* item in the buffer.

class LookaheadState:
    def __init__(self):
        # items that have arrived but whose final bin choice is not yet committed
        self.buffer_items = deque()
        # snapshot of bins before each buffered item was placed; we keep the actual bin array
        self.buffer_bins_snapshot = None  # will be a 1D numpy array of capacities (all bins, including unused)
        self.current_bins = None          # current state after all placements so far
        self.bin_count = 0

    def reset_if_needed(self, bins):
        # Called at the very beginning or when bin layout changes due to new bins
        if self.current_bins is None:
            self.current_bins = bins.copy()
            self.bin_count = len(bins)

state = LookaheadState()

def waste(bin_capacity, item_size):
    return bin_capacity - item_size

def evaluate_placement(bins_snapshot, items_sequence):
    """Given initial bins capacities (1D np array) and a list of items (sizes),
    simulate greedy best-fit placement of those items and return total waste added.
    Best-fit: pick the bin with smallest remaining capacity that still fits the item,
    ties go to first such bin. This is deterministic."""
    bins = bins_snapshot.copy()
    total_waste = 0
    for it in items_sequence:
        # find bins that can fit item
        eligible = np.where(bins >= it)[0]
        if len(eligible) == 0:
            # Need a new bin (implicitly available: all unused bins have capacity 100)
            # Find first bin with capacity 100 (unused)
            new_bin_idx = np.where(bins == 100)[0][0]
            bins[new_bin_idx] -= it
            total_waste += 100 - it
        else:
            # best fit: smallest remaining capacity
            capacities = bins[eligible]
            best_idx_in_eligible = np.argmin(capacities)
            chosen_idx = eligible[best_idx_in_eligible]
            bins[chosen_idx] -= it
            total_waste += (bins[chosen_idx] + it - it)  # actually update wastage: old cap - new cap = item size? Wait waste is space left empty?
            # Actually waste added for this item = remaining capacity after placing
            # But we need the waste accumulated over all items: we can just compute final waste minus initial waste,
            # or sum (remaining after placement). Let's compute total waste at the end.
    # waste = sum(bins) - sum of initial empty space? Better: compute total used capacity vs total bin capacity
    # But we only care about the relative ordering of placements for the same initial bins.
    # Straightforward: use total remaining capacity after all placements as metric (we want minimum).
    return np.sum(bins)


def priority(item, bins):
    global state
    state.reset_if_needed(bins)
    
    # bins is the current capacity array that the item fits into (it shows all bins: used and unused)
    # We are allowed to maintain our own version of capacities; we trust bins reflects reality.
    # However, bins is a copy, so we need to keep our own updated version.
    if state.current_bins is None:
        state.current_bins = bins.copy()
    else:
        # Since we simulate all placements ourselves, we should just use our own state.current_bins.
        # But we must ensure it matches reality. For simplicity, we rely on our simulation.
        # Actually, the harness calls priority with the true current bins. We can update ours to match,
        # but we have to account for the fact that we may have buffered items whose placements not yet applied.
        # Instead, we always use the harness-supplied bins as ground truth and adjust.
        pass

    # Incorporate new item into buffer
    state.buffer_items.append(item)
    if state.buffer_bins_snapshot is None:
        # this is the first item ever
        state.buffer_bins_snapshot = bins.copy()
    # When buffer length exceeds K+1, we need to commit the oldest item.
    # But we only call priority once per item; the buffer size grows until K+1 then we commit one each call.
    
    # We must return scores for the current item placement based on lookahead.
    # Standard approach: if buffer has >= K+1 items, we find the best permutation for all items in buffer,
    # commit the oldest item's placement, and then use that to decide current bin?
    # Actually, we are being asked to score bins for the *current* item (the one just added to buffer).
    # To do lookahead, we evaluate all possible bin choices for the *current* item (the new one) 
    # by simulating the packing of all buffered items (including future commitment order)
    # and pick the bin that leads to minimum total waste for the whole buffer.
    # Then we return a priority array where the chosen bin gets highest score.
    
    K_actual = K
    if len(state.buffer_items) <= K_actual + 1:
        # Not enough items to commit yet, we can still decide the best bin for the current item
        # by considering all possible bins it could go into, and then simulating the rest (future items not yet seen) - but we don't see future.
        # Instead, we wait until buffer full, then decide.
        # For early items, just use best-fit temporarily.
        # We'll return best-fit scores for now.
        eligible = np.where(bins >= item)[0]
        if len(eligible) == 0:
            # shouldn't happen because bins include unused
            return np.zeros_like(bins, dtype=float)
        capacities = bins[eligible]
        best_idx_in_eligible = np.argmin(capacities)
        chosen_idx = eligible[best_idx_in_eligible]
        scores = np.full_like(bins, -np.inf, dtype=float)
        scores[chosen_idx] = 1.0
        # We also need to maintain our state even for these early items.
        # We'll simulate placement later when we commit. For now just record the chosen bin?
        # We cannot because we haven't committed. Let's just not maintain state for early items and use best-fit.
        # But we need to track capacities. Since we won't use buffer logic until we have enough items,
        # we can just update current_bins by applying best-fit now.
        state.current_bins[chosen_idx] -= item
        return scores

    # Buffer is full (len == K+2 now because we just appended). We now decide the placement of the oldest item.
    # The oldest item is state.buffer_items[0].
    # We will consider all possible bins for the oldest item (must be bins from the snapshot before it was placed).
    # Then simulate the remaining K items using the resulting state, using best-fit.
    # The snapshot before the oldest item is state.buffer_bins_snapshot.
    snapshot = state.buffer_bins_snapshot.copy()
    oldest_item = state.buffer_items[0]
    other_items = list(state.buffer_items)[1:]  # includes the new item
    
    # Find all bins that can fit oldest_item (according to snapshot)
    # The bins array the harness passed is current bins, but for simulation we need snapshot before oldest.
    eligible_bins = np.where(snapshot >= oldest_item)[0]
    
    best_waste = np.inf
    best_bin = -1
    
    for bin_idx in eligible_bins:
        # simulate placing oldest_item into bin_idx
        sim_bins = snapshot.copy()
        sim_bins[bin_idx] -= oldest_item
        # Now place the rest (other_items) using best-fit
        total_waste = evaluate_placement(sim_bins, other_items)
        if total_waste < best_waste:
            best_waste = total_waste
            best_bin = bin_idx
    
    # Now we commit: the oldest item goes to best_bin.
    # Update our state: apply this placement to current_bins and to buffer.
    # state.current_bins should be updated accordingly.
    # But careful: state.current_bins currently reflects placements of items before buffer started?
    # Actually we need to sync. We'll recalc current_bins properly.
    # Simpler: after deciding the oldest item's bin, we remove it from buffer and update snapshot for the next call.
    # The new snapshot for next call will be the bins after placing oldest_item but before placing the remaining buffer items? 
    # Actually, we need to simulate the placement of the other items into the actual bins later when they become oldest.
    # But we already simulated them. We must apply them as well? No, they are still buffered, not yet committed.
    # So we advance the buffer snapshot to the state after placing the oldest item into best_bin.
    new_snapshot = snapshot.copy()
    new_snapshot[best_bin] -= oldest_item
    state.buffer_bins_snapshot = new_snapshot
    state.buffer_items.popleft()
    
    # Also update our internal current_bins to reflect reality after this placement:
    # The harness will place the current item (which is the last item in other_items) right now.
    # But wait: the harness calls priority for the current item, and expects scores for that item.
    # The current item we just added to buffer (which is other_items[-1]) must be placed NOW.
    # Our above simulation examined all possible bins for the *oldest* item, but the harness needs scores for the *current* item.
    # We are making a mistake: we are supposed to return scores for the current item, not decide the oldest.
    # The lookahead logic should be: when item arrives, we see if buffered items + new item can be reordered 
    # to decide bin for *this* item.
    
    # Correct design: 
    # - Keep buffer of last K items already placed (their bin choices already committed), and their snapshots.
    # - When new item arrives, we consider the set of K+1 items: the new item and the last K committed items (which we can conceptually reorder because they are already placed but we can reconsider their assignments?). 
    #   But reordering already placed items is not allowed; they are fixed.
    # The idea "reorder the current item and the last K items (only conceptually) to see which bin assignment now would yield the tightest packing for the buffered set, then commit the assignment that minimizes total waste on the buffer." 
    # Means we take the last K items (already placed) and the new item, and we consider all possible orders in which we could pack them (as if we had postponed decisions), but then we only commit the assignment for the *oldest* among them (which may be one of the already placed items? That doesn't make sense since they already have bins). 
    # Actually typical "online with lookahead buffer" works like: we allow delaying decisions for up to K items. 
    # So we maintain a buffer of items whose placement is not yet fixed. When buffer size exceeds K, we must fix the oldest.
    # Our earlier attempt was on that line, but we mixed the current item's scoring.
    
    # Let's re-implement proper delayed decision buffer.
    pass



# Because of complexity, I will now rewrite the whole priority function cleanly with correct delayed buffer logic.
