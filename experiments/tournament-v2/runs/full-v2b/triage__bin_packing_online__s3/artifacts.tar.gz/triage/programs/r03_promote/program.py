import numpy as np

_state = {
    "count": 0,
    "large_count": 0,
    "item_sizes": np.zeros(5000, dtype=np.float64),
    "idx": 0,
}

def priority(item, bins):
    st = _state
    st["count"] += 1
    n = st["count"]
    
    # Track item sizes for percentile estimation
    if st["idx"] < 5000:
        st["item_sizes"][st["idx"]] = item
        st["idx"] += 1
    if item >= 60:
        st["large_count"] += 1
    
    # Adaptive parameters based on observed statistics
    f_large = st["large_count"] / n
    
    # w: regret weight. Higher when large items are rare (protect empty bins more).
    # Lower when large items are common (we need to pack tightly).
    w = 0.6 + 2.0 * (0.15 - f_large)
    w = np.clip(w, 0.3, 2.0)
    
    # floor: threshold for "large item" treatment
    floor = 55.0 + 30.0 * (0.15 - f_large)
    floor = np.clip(floor, 45.0, 75.0)
    
    cap = bins.astype(np.float64)
    slack = cap - item
    
    # Use a robust upper quantile to estimate "full enough" threshold
    # Sort is O(n log n) but n <= 5000 and we only do it once per call
    sorted_cap = np.sort(cap)
    n_bins = len(cap)
    # 90th percentile, but at least the 10th largest bin
    q90_idx = min(int(0.90 * n_bins), n_bins - 1)
    q90 = sorted_cap[q90_idx]
    
    # Also compute a "lower full threshold" (e.g., 75th percentile) to identify
    # bins that are too empty and should be preserved
    q75 = sorted_cap[min(int(0.75 * n_bins), n_bins - 1)]
    
    regret = q90 - cap  # positive = bin is fuller than 90th percentile
    
    if item >= floor:
        # Large item: prefer bins where it fits tightly (minimize slack),
        # but also avoid using the very emptiest bins unless necessary.
        # Give bonus to bins that are already somewhat full (regret > 0)
        # but penalize bins that are extremely empty.
        empty_penalty = np.where(cap > q75, 0.0, -5.0 * (q75 - cap) / 100.0)
        score = -slack + 0.3 * regret + empty_penalty
        return score
    elif item <= 20:
        # Very small items: use best-fit aggressively, but prefer bins
        # that are already partially filled to consolidate.
        # Small positive regret is ideal.
        score = -slack + 0.8 * regret - 0.1 * np.abs(regret)
        return score
    else:
        # Medium items: balance slack and regret
        # Discourage using bins where slack is too large (waste)
        # and also discourage using bins that are very empty (save for large items)
        waste_penalty = np.where(slack > 30, -0.5 * (slack - 30) / 100.0, 0.0)
        score = -slack + w * regret + waste_penalty
        return score
