"""Two-pool bin-packing with an explicit dense/sparse partition.

We maintain a small boolean array that mirrors the actually used bins:
- "dense" bins are those whose remaining capacity is ≤ a dynamic threshold THR.
- "sparse" bins are the complement (THR < capacity ≤ 100).

Small items (size ≤ inventory-based "small threshold") are restricted to dense bins
whenever possible; this concentrates small fragments in already-dented bins.  When a
small item must open a new bin, that bin becomes dense only after its residual drops
below THR (so a fresh bin starts sparse).  Large items always pick the sparsest bin
(largest residual), which may turn it dense on the next call.

THR is adapted slowly from observed item sizes so the two pools stay balanced.
No future information is used.
"""

import numpy as np

# ---------------------------------------------------------------------------
# Persistent state – a module‑level dictionary that is reset by the harness
# at the start of each instance (the harness imports the module fresh).
# ---------------------------------------------------------------------------
_state = {
    # inventory / statistics
    "n": 0,                     # items seen so far
    "item_sizes": [],           # list of recent sizes for percentile estimate
    "small_threshold": 40.0,    # items ≤ this go to dense pool (fractional is fine)
    "threshold": 70.0,          # capacity below which a bin is "dense" (THR)

    # look‑aside arrays that mirror bins actually in use
    # These are re‑allocated lazily; length grows with the number of bins used.
    "is_dense": None,           # boolean array; True = dense pool
    "num_used": 0,              # how many entries of is_dense are valid
}


def _ensure_arrays(current_max_bins):
    """Extend the is_dense array if the number of bins has grown."""
    st = _state
    if st["is_dense"] is None or len(st["is_dense"]) < current_max_bins:
        # overallocate a bit to avoid repeated re-allocation
        new_len = max(current_max_bins + 200, 1000)
        new_dense = np.zeros(new_len, dtype=bool)
        if st["is_dense"] is not None:
            new_dense[: st["num_used"]] = st["is_dense"][: st["num_used"]]
        else:
            # first call for the instance: everything starts as sparse (all False)
            pass
        st["is_dense"] = new_dense


def priority(item, bins):
    st = _state
    n = st["n"] + 1
    st["n"] = n

    # --- online inventory update (lightweight) ---------------------------------
    # Keep a fixed-size rolling window for percentile estimation.
    WIN = 2000
    if len(st["item_sizes"]) >= WIN:
        # Overwrite circular-buffer style: oldest index = (n - WIN) % WIN
        idx = (n - 1) % WIN
        st["item_sizes"][idx] = item
    else:
        st["item_sizes"].append(item)

    # Every few items refresh the percentile threshold for "small".
    if n % 100 == 0 and len(st["item_sizes"]) >= 50:
        sizes = np.array(st["item_sizes"])
        st["small_threshold"] = float(np.percentile(sizes, 40))
        # Also nudge the dense/sparse capacity threshold so the two pools stay
        # roughly balanced in number of bins (avoid all bins becoming dense).
        dense_bins_now = st["is_dense"][: st["num_used"]].sum()
        sparse_bins_now = st["num_used"] - dense_bins_now
        # target: sparse pool should be about 15-20% of used bins (protect capacity)
        target_ratio = 0.18
        if st["num_used"] > 5:
            actual_ratio = sparse_bins_now / max(1, st["num_used"])
            # adjustment strength
            st["threshold"] += 1.0 * (target_ratio - actual_ratio)
            if st["threshold"] < 35.0:
                st["threshold"] = 35.0
            elif st["threshold"] > 95.0:
                st["threshold"] = 95.0

    # --- ensure the lookaside array is long enough ----------------------------
    num_bins = len(bins)
    _ensure_arrays(num_bins)
    is_dense = st["is_dense"]
    used = st["num_used"]

    # Determine which bins among the ones shown are "dense" according to the
    # *current* capacities (the array `bins` is a copy of the remaining capacity).
    # For bins that are still unused (capacity == 100) we keep their previous
    # mark (always False unless something unusual happened).  For bins that were
    # created but never had an item placed into them yet they are still sparse.
    cap = bins
    dense_now = (cap <= st["threshold"]) & (cap < 100)  # exclude untouched bins
    # Also preserve the mark for bins that already received items but whose cap
    # is still above threshold (those are sparse).
    # Important: bins that *just* became dense because capacity dropped below THR
    # must be updated in the persistent array so later calls know it.
    is_dense[:num_bins] = dense_now
    # For bins beyond the currently used range, capacity is 100 and they are
    # untouched (sparse).  We do not mark them dense.
    is_dense[used:] = False

    # --- scoring ---------------------------------------------------------------
    scores = np.full(num_bins, -np.inf, dtype=np.float64)

    if item <= st["small_threshold"]:
        # Small item: restrict to dense bins if any exist.
        dense_indices = np.where(is_dense[:num_bins])[0]
        if len(dense_indices) > 0:
            # Among dense bins, use tightest fit (maximise score -> smallest leftover).
            leftovers = cap[dense_indices] - item
            scores[dense_indices] = -leftovers  # higher (less negative) = tighter
        else:
            # No dense bin available -> use a fresh, still sparse bin.
            # Prefer the sparsest one (largest capacity) among those that are *not*
            # dense, which usually means an untouched bin.
            sparse_mask = ~is_dense[:num_bins]
            if np.any(sparse_mask):
                scores[sparse_mask] = cap[sparse_mask].astype(np.float64)
            else:
                # fallback: all bins are dense, use tightest fit everywhere
                scores[:] = -(cap - item)
    else:
        # Large item: always pick the sparsest bin (largest remaining capacity).
        # This includes both sparse and dense bins – giving capacity priority.
        scores[:] = cap.astype(np.float64)

    # If there are still -inf entries (should not happen, but safety), give them
    # a very low score so they are last resort.
    scores[scores == -np.inf] = -1e12

    # Update used count (the harness owns the actual bins, but we need to know how
    # many bins have ever received an item to maintain is_dense correctly).
    # We infer that from the fact that the harness keeps bins with capacity=100
    # at the end of the array until they are used.  The count of non-100 bins is
    # a lower bound on used bins; we set `num_used` to the number of bins that
    # *might* have been touched.  A reliable heuristic: the harness never skips
    # bins – it packs bin 0 first, then bin 1, etc.  Thus all bins before the first
    # untouched bin (capacity = 100) are potentially used.  We maintain num_used
    # as the index of the first fully empty bin *plus* the number of bins that
    # already contain items even if they later become dense.
    # Simple robust approximation: `num_used` = number of bins with capacity < 100,
    # because new bins start at 100.  This works perfectly because we never put
    # an item into a bin that previously had capacity 100 without it being recorded.
    first_empty = np.argmax(cap == 100) if np.any(cap == 100) else num_bins
    # corner case: a bin that received items could still have capacity exactly 100
    # by extremely low chance (item size 0 doesn't exist). Safe.
    st["num_used"] = first_empty

    return scores
