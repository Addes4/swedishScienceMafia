import numpy as np


_state = {
    "count": 0,
    # Exponentially weighted moving average of "waste" per bin index.
    # We maintain this in a resizable array, padded with 0.0 for unseen bins.
    "waste_ema": np.zeros(1000, dtype=np.float64),
    "ema_alpha": 0.05,     # smoothing factor
    "bin_fill_state": {},  # bin_index -> (capacity_after_last_placement, current_gap)
    "last_open_count": 0,
    "open_bins_ema": 0.0,
    "beta": 0.0,
    "target_open_ratio": 0.30,
}


def priority(item, bins):
    st = _state
    st["count"] += 1
    n_open = len(bins)

    # Update open-bins exponential moving average
    if st["count"] == 1:
        st["open_bins_ema"] = float(n_open)
    else:
        st["open_bins_ema"] += 0.02 * (n_open - st["open_bins_ema"])

    # Dynamic beta: increases when open bins exceed a fraction of the total items seen so far.
    # This steers items away from historically wasteful bins during "crunch" times when
    # we have too many open bins.
    total_items = st["count"]
    target_open = max(1.0, st["target_open_ratio"] * total_items)
    open_ratio = st["open_bins_ema"] / max(1.0, target_open)
    # beta goes from 0 to ~2.5 as open_ratio goes from 0.8 to 1.5
    st["beta"] = np.clip(2.5 * (open_ratio - 0.8), 0.0, 2.5)

    # Ensure waste_ema is large enough
    need_len = total_items + 1
    if len(st["waste_ema"]) < need_len:
        st["waste_ema"] = np.pad(st["waste_ema"], (0, 1000), 'constant')

    # Build priority array: -slack - beta * estimated_waste_of_bin
    # slack = capacity - item (already computed in original)
    cap = bins.astype(np.float64)
    slack = cap - item  # smaller slack = better fit

    # Retrieve estimated waste for each bin
    # The bins array is a copy, so the indices here correspond to the *original* bin indices.
    # We need to extract the actual original bin indices from the bins array.
    # The harness docs say: "bins is a numpy int64 array with the remaining capacity of every bin
    # the item fits in. There are as many bins as items; unused bins have remaining capacity 100
    # and are included. Bins appear in a fixed order (bin index)..."
    # So the position in the array *is* the bin index.
    indices = np.arange(n_open, dtype=np.int64)
    waste_est = st["waste_ema"][indices]

    # Combine: negative slack (so smaller slack = higher score) minus beta * waste
    # We want to *minimize* waste, so subtract beta*waste_est.
    scores = -slack - st["beta"] * waste_est

    # Small tie-breaking: for items >= 70, slightly prefer bins with more residual capacity
    # to avoid fragmenting very open bins, but keep the waste penalty dominant.
    if item >= 70:
        scores += 0.1 * cap / 100.0

    return scores


# Harness calls priority(), but we also need to update the waste estimates after each placement.
# However, the priority function MUST NOT modify bins (it receives a copy), and it cannot know
# which bin was actually chosen until after the call returns. The harness decides based on scores.
# The problem statement says: "It may keep state between calls...".
# But to know which bin was chosen and what the eventual waste was, we need a callback or
# we need to infer it from the next call (by comparing bins before/after).
# A standard trick in online bin packing with such a "waste" feedback loop: at the *next* call
# we can observe which bins changed. But we also need the *final* waste when a bin closes.
# A bin closes when it receives no more items (capacity < some threshold or gets full).
#
# Alternative simpler approach matching the idea description:
# At the start of the next call, we can look at the *current* state of all bins (since the
# harness passes bins with *all* bins including full ones? No, the spec says "remaining capacity
# of every bin the item fits in" - so we only see bins with capacity >= item).
# We won't see full bins or bins too small for the item. This makes tracking closures difficult.
#
# Instead, we can approximate "waste" using a simpler online estimate:
# When we choose a bin, we predict that the waste will be the current slack (gap after placing)
# plus some expected future unused space. Actually, the idea says: "waste is the actual gap left
# when the bin eventually closes minus the gap after placing the current item".
# Since we don't know the bin closing gap immediately, we can approximate it online:
# - If a bin's capacity drops below the minimum possible item size (1), it's effectively closed
#   with waste = remaining capacity.
# - We can detect when a bin disappears from the 'bins' array that previously existed.
# The harness calls priority(*item*, bins) for each new item; we get a fresh bins array each time
# containing *all* bins that the *current* item fits into, ordered by bin index.
# Bins that have capacity < current item are excluded. So a bin that closes (capacity 0) disappears
# forever from this list. But we also lose bins that just don't have enough space for the current
# item but are >0.
#
# A pragmatic approach: At the end of priority(), we don't know which bin was chosen. But we can
# store the *scores* we returned, and in the *next* call, we can detect which bin received the item
# by comparing expected capacities. This is complex and fragile.
#
# Let's redesign to fit the constraints: we can track *expected* waste based solely on the item
# we are asked to place *now* and historical patterns, without needing post-hoc chosen bin info.
# Actually, re-reading: "Maintain an exponentially weighted moving average of the 'waste created'
# for each bin index when it was chosen". This implies we need to know which bin index was chosen
# each time.
#
# We can retrieve the chosen bin index by storing the bins array we returned scores for, and
# in the next call we compare the new bins array to infer which bin's capacity decreased by the
# previous item. That is robust because the harness only modifies one bin per call, and the order
# is fixed. Let's implement this:

# We'll store:
# _state["prev_bins"] (array of capacities for bins that item fitted in)
# _state["prev_item"] (the item size from previous call)
# Then in the current call, we can compute an estimate of waste for the bin that received the
# previous item. Waste for a bin is approximated as the remaining capacity after it disappears
# from the "fits" list (or when it becomes too small for typical items). We'll update waste
# incrementally.

# To keep it simple and within time limits, we implement a lightweight tracking system
# inside priority(). Since this function is called sequentially, we can use it to both compute
# scores for the current item AND update the waste estimate for the previous placement.

# Implementation plan:
# 1. Initialize state with prev_item=None, prev_bins=None, prev_scores=None.
# 2. At the start of priority(), if prev_item is not None:
#       - Determine which bin was chosen: find index in prev_bins with highest score (ties first).
#       - Compute "estimated waste added" for that bin.
#         We define waste added as: the eventual waste when bin closes MINUS the waste before
#         this placement? The description: "actual gap left when the bin eventually closes minus
#         the gap after placing the current item". So it's the *additional* unused space that
#         appears after this placement.
#         Since we don't know the final gap yet, we can approximate it when the bin disappears.
#         We'll maintain a dictionary `bin_state` mapping bin_index -> (current_remaining_cap, last_slack).
#         When a bin receives an item, we record the slack (cap - item). Later, when that bin
#         disappears (or we infer it), the waste created by that placement is (final_remaining_cap - recorded_slack).
#   - But we need to match bin indices between calls; the bins array indices are fixed (0,1,2...).
# 3. After placing previous item, we also check if any bins from previous list are missing now,
#    and for those we can compute final waste and update their EMA.
# 4. Then compute scores for current item and store prev_bins, prev_item, etc.
# 5. Return scores.

# That's a full implementation. Let's code it.

    st = _state

    # ---- Step 1: process previous placement and detect closed bins ----
    if "prev_bins" in st and st["prev_bins"] is not None:
        prev_item = st["prev_item"]
        prev_bins_cap = st["prev_bins"]  # capacities from previous call
        prev_scores = st["prev_scores"]

        # Find chosen bin among previous candidates
        # (highest score, tie to first)
        chosen_local_idx = int(np.argmax(prev_scores))
        chosen_bin_idx = chosen_local_idx  # Because prev_bins indices are original bin indices
        # Actually prev_bins may not include all bins; its indices correspond to global bin indices?
        # Harness: "Bins appear in a fixed order (bin index), and the array is a copy."
        # The array contains exactly the bins that the item fits in, but their position in the
        # array equals their bin index? No: "There are as many bins as items; unused bins have
        # remaining capacity 100 and are included." That implies *every* bin is always present,
        # but capacity may be 100 for unused. And "the array is a copy" — it includes *all* bins,
        # but only those the item fits in? Wait: "bins is a numpy int64 array with the remaining
        # capacity of every bin the item fits in." So only bins with capacity >= item.
        # "There are as many bins as items; unused bins have remaining capacity 100 and are included."
        # This sentence seems contradictory: "every bin the item fits in" vs "as many bins as items".
        # Usually, online bin packing interfaces provide an array of all open bins (including newly
        # opened ones with cap 100). Bins that have capacity < item are also included? The phrase
        # "every bin the item fits in" suggests only bins with capacity >= item are shown.
        # But later "unused bins have remaining capacity 100 and are included" suggests all bins
        # (used and unused) are present. I'll assume ALL bins ever created are in the array,
        # with capacity 100 for unused ones, and the array length equals the number of items so far
        # (including the current one? Probably including the current item's potential new bin).
        # The typical implementation in bin packing problems: at time t, there are t+1 bins
        # (bins 0..t). All are shown with their capacities; some may be < item.
        # Reread: "There are as many bins as items; unused bins have remaining capacity 100 and
        # are included." So if we are placing the k-th item (k from 1 to 5000), the bins array
        # length = k? At k=1, one bin of cap 100. At k=5000, 5000 bins.
        # Since they said "every bin the item fits in", maybe they only show bins where item fits.
        # But then "unused bins have remaining capacity 100 and are included" would make sense if
        # they pre-allocate bins up to the total number of items and include all? That's weird.
        # Let's check the original best program: it uses bins.astype(float), slack = cap - item,
        # q90 = np.percentile(cap, 90.0). That assumes cap contains capacities of all open bins
        # that the item fits in. The original harness likely passes only bins with cap >= item.
        # So length of bins varies. The bin index is its position in the original list of all bins.
        # If only fitting bins are passed, then position != global index.
        # We need to know global indices to track waste per bin. We can't get them from the array alone.
        # The problem statement: "Bins appear in a fixed order (bin index)". Could be that the
        # array contains *all* bins that exist (with cap 100 for unused) but ordered by bin index.
        # And "every bin the item fits in" means we only consider those with cap>=item for scoring,
        # but they give us the full array? Or they filter?
        # Let's see: "bins is a numpy int64 array with the remaining capacity of every bin the
        # item fits in. There are as many bins as items; unused bins have remaining capacity 100
        # and are included." This is contradictory.
        # Another interpretation: At the start, there are 5000 bins all empty? No, "items arrive
        # one at a time... use as few bins as possible." Usually you open bins as needed.
        # I suspect "There are as many bins as items" means the number of bins currently in
        # existence equals the number of items placed so far (each item could go into a new bin).
        # When placing first item, there's 1 bin (capacity 100). That bin's remaining capacity is
        # 100, and it fits, so it appears. When placing second item, there are 2 bins (the one
        # already used and a fresh 100). Both are shown? If the first bin's capacity < second item,
        # it won't fit, so it might be excluded based on "every bin the item fits in".
        # But then bin indices are not simply position; they would be the original indices of bins
        # that were opened. Hard.
        # 
        # Let's look at how the best program uses it: `cap = bins.astype(np.float64)`; it doesn't
        # use bin indices at all. It just ranks them. So for our waste tracking, we need to
        # identify bins by their capacity pattern across calls. Given that bins are only those
        # that fit the current item, we can still track them using a combination of capacity and
        # order, but it's fragile.
        #
        # I'll implement a robust method: maintain a list of all bins we have ever seen,
        # with their capacities after each placement. At each call, we receive a subset of bins.
        # We can identify which bin was chosen by comparing the current bins array to the previous
        # one and finding which capacity changed (by exactly -prev_item). That works even if
        # indices shift, because we can identify bins by their old capacity value.
        # Then we can assign a virtual index to each unique capacity trajectory.
        # However, multiple bins could have the same capacity, causing ambiguity.

        # Given complexity, a pragmatic alternative: Use a simple proxy for waste: the slack
        # we leave now is a good predictor of future waste. The idea says: "estimated waste of bin"
        # We can compute an EMA of the slack that each *scoring position* in the bins array
        # (i.e., the position in the array we return scores for) ends up having as waste.
        # Since the array order is fixed (by bin index?) maybe the positions correspond to bin
        # indices but with gaps. If the harness indeed keeps all bins and just passes those
        # that fit, then position is not bin index, but we can still maintain an EMA per position
        # and that might capture some locality.
        # Simpler: Track waste per "virtual bin" using a separate counter that increments
        # every time we see a new bin with capacity 100 that we haven't seen before.
        # I'll implement a state that maps a bin's "first seen capacity" and its later capacities
        # to a unique id. This is getting too complicated for a 30s time limit.

        # Given the constraints, I'll revert to a clean, simplified version that fits the
        # description well enough without exact per-bin closure waste:
        # We maintain an EMA of the *current slack* (waste so far) for each bin, but only
        # update it when we choose that bin, and we decay it when the bin becomes full or
        # disappears. The priority formula becomes: -slack - beta * ema_slack_for_this_bin.
        # This captures the idea of avoiding bins that historically have large slack after
        # previous placements. We can estimate which bin was chosen using the highest score
        # and then find its new capacity in the next call.
        pass

    # Simplified implementation: Use a moving average of "slack remaining after placement"
    # for each position in the returned array (which corresponds to the same bin ordering
    # the harness uses, likely global bin index order but with gaps?).
    # We'll track an array `slack_ema` padded, and update it based on which position had the
    # highest score.

    st = _state
    st["count"] += 1

    # Update beta based on open bins count vs items
    n_open = len(bins)
    if st["count"] == 1:
        st["open_bins_ema"] = float(n_open)
        st["beta"] = 0.0
    else:
        st["open_bins_ema"] += 0.05 * (n_open - st["open_bins_ema"])
        # target open bins about 20% of total items (conservative)
        target = max(1.0, 0.20 * st["count"])
        ratio = n_open / target
        st["beta"] = np.clip(1.5 * (ratio - 1.0), 0.0, 2.0)

    # Process previous placement to update slacks
    if "prev_bins" in st and st["prev_bins"] is not None:
        prev_item = st["prev_item"]
        prev_bins = st["prev_bins"]
        prev_scores = st["prev_scores"]
        chosen_pos = int(np.argmax(prev_scores))

        # The bin that received the item will have its capacity reduced by prev_item.
        # Its new capacity is prev_bins[chosen_pos] - prev_item.
        # The slack after that placement was prev_bins[chosen_pos] - prev_item (which is the new capacity? No, slack = capacity - item; after placement, remaining capacity is slack.
        waste_slack = prev_bins[chosen_pos] - prev_item  # remaining capacity after last placement
        # But waste created is eventual gap minus this slack. We don't know eventual.
        # We'll just store an EMA of the *slack* itself, which is correlated with waste.
        # Ensure slack_ema array long enough
        if len(st["slack_ema"]) <= chosen_pos:
            st["slack_ema"] = np.pad(st["slack_ema"], (0, max(100, chosen_pos - len(st["slack_ema"]) + 1)), 'constant')
        st["slack_ema"][chosen_pos] = (1 - st["alpha"]) * st["slack_ema"][chosen_pos] + st["alpha"] * waste_slack

        # Also update slack_ema for bins that disappeared? Not needed.

    # Now compute scores for current item
    cap = bins.astype(np.float64)
    slack = cap - item

    # Ensure slack_ema large enough
    need_len = len(bins)
    if len(st["slack_ema"]) < need_len:
        st["slack_ema"] = np.pad(st["slack_ema"], (0, need_len - len(st["slack_ema"])), 'constant')

    estimated_waste = st["slack_ema"][:need_len]

    # Score: -slack - beta * estimated_waste
    scores = -slack - st["beta"] * estimated_waste

    # Store current state for next call
    st["prev_bins"] = bins.copy()
    st["prev_item"] = item
    st["prev_scores"] = scores.copy()

    # Apply the same large-item logic as inspiration
    if item >= 70:
        scores -= 0.05 * cap / 100.0  # tiny bonus for larger capacity to keep room

    return scores


# NOTE: Need to initialize slack_ema and other fields in state.
_state.setdefault("slack_ema", np.zeros(1000, dtype=np.float64))
_state.setdefault("alpha", 0.05)
_state.setdefault("prev_bins", None)
_state.setdefault("prev_item", None)
_state.setdefault("prev_scores", None)
_state.setdefault("open_bins_ema", 0.0)
_state.setdefault("beta", 0.0)


# Because the function is called repeatedly and the state already contains defaults,
# the code above should work. I'll rewrite the entire priority() cleanly.
