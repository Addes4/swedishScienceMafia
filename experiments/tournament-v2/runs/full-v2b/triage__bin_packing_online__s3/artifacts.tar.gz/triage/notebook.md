# Research notebook: bin_packing_online

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.961642.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Hybrid score mixing tightness with bin age: `-(bins - item) - epsilon * (number of times the bin was previously considered but not chosen)` to break ties by rec | 0.33 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961642 |
| 4 | Worst-fit variant with controlled fragmentation: return `bins - item` (largest remaining capacity) but only among bins whose remaining capacity is above a dynam | 0.30 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.396100 |
| 0 | Histogram of past item sizes to anticipate remaining items: keep a running estimate of the size distribution and for each candidate bin compute the expected was | 0.27 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.414201 |
| 2 | Learn a linear combination of features: for each bin compute features (remaining after placement, original capacity, count of items already in the bin, bin inde | 0.24 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | no_code |  |
| 5 | Harmonic-like classification: predefine a set of capacity intervals (e.g., (0,17], (17,34], …, (83,100]) and maintain dedicated bins for items falling into each | 0.19 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 3 | Treat the problem as a Monte Carlo tree search: for each plausible subset of bins, simulate several random completions of the remaining item stream using a fitt | 0.13 | long_shot | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | invalid | 0.000000 |

Best after round 1: **0.961642** (spent $0.01)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Run a deterministic lookahead over a small buffer of recently seen items: reorder the current item and the last K items (only conceptually) to see which bin ass | 0.09 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 3 | Cluster the sequence of residual capacities into a few representative states and apply a Q-learning update after each episode to choose the bin that minimizes e | 0.07 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 1 | Maintain a set of "reserve bins" for future large items: if item is below a threshold, prefer bins with small remaining capacity over bins with large capacity,  | 0.06 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | improved | 0.961642 |
| 5 | Treat the problem as online bipartite matching: assign a "potential" to each bin based on its remaining capacity and use a regularized matching algorithm (e.g., | 0.04 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 0 | Use a smoothed "anti-waste" score where each bin's priority is based on how well a future item of a certain estimated ideal size could combine with the current  | -0.03 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 2 | Compute bin priority as the negative of the residual after placement, but perturbed by a noise term that decays with bin usage count to explore alternative pack | -0.05 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Promotion: deepseek-ai/DeepSeek-V4.1-Flash:deepinfra found an improvement; deepseek-ai/DeepSeek-V4-Pro:deepinfra refined it -> not_better (0.396100).

Best after round 2: **0.961642** (spent $0.04)

## Round 3

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Replace the fixed threshold with an online estimate of the quantile of the arriving item in the size distribution using reservoir sampling. The score is a conve | 0.18 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.780346 |
| 2 | Maintain two virtual bin sub-sets—“dense” and “sparse”—based on a dynamic capacity threshold. For items below the 40th percentile of seen sizes, restrict candid | 0.15 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.671250 |
| 5 | Use a “precautionary savings” score: for each candidate bin compute the fraction of future items the bin could still accept if it takes the current item, based  | 0.14 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.959547 |
| 0 | Score bins by a linear combination of the residual after placement and a “regret” term: the difference between the current residual and the 90th percentile resi | 0.12 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | improved | 0.961875 |
| 4 | Cluster the residual capacities of chosen bins via a small number of centroids updated with exponential moving average after each placement. When an item arrive | 0.10 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 1 | Treat the bin choice as a reject-or-keep decision per bin using a sliding-window estimate of the probability that a future item will exactly fill the gap. For e | 0.08 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.961642 |

Promotion: deepseek-ai/DeepSeek-V4.1-Flash:deepinfra found an improvement; deepseek-ai/DeepSeek-V4-Pro:deepinfra refined it -> not_better (0.961642).

Best after round 3: **0.961875** (spent $0.06)

## Round 4

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 2 | Replace the static 90th percentile regret with a time-decayed exponentially weighted moving average of bin capacities, giving higher weight to capacities of bin | 0.10 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961875 |
| 5 | Decompose the bin-choice score into a product of two terms: a “fit” term that rewards slack close to zero, and a “scarcity” term that exponentially penalizes co | 0.09 | favourite | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra (swapped) | not_better | 0.935081 |
| 1 | Introduce a "balance preservation" score that groups bins by their residual capacity modulo a small integer M (e.g., M=11). Score each bin by how well its post- | 0.03 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.960942 |
| 0 | Exploit the known Weibull-shaped distribution by maintaining an online maximum-likelihood fit of the shape and scale parameters after each item. Use the fitted  | 0.03 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 4 | Model the item stream as a Markov chain of size regimes (e.g., “small” < 30, “medium” 30-60, “large” > 60) with online transition probability estimates. For eac | 0.03 | long_shot | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | not_better | 0.961875 |
| 3 | Maintain a parallel array of "phantom bins" where each real bin also keeps a running count of how many future items of the most common size could still fit if t | 0.01 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 4: **0.961875** (spent $0.08)

## Round 5

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Use a dual-threshold strategy based on the ratio of remaining total capacity to estimated remaining total load: when the ratio is below 1.1, switch to a strictl | 0.21 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961875 |
| 1 | Maintain an exponentially weighted moving average of the "waste created" for each bin index when it was chosen, then compute priority as `-slack - β * (estimate | 0.06 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 0 | Use a power-of-two partitioning: discretize remaining capacities into intervals [1,2), [2,4), [4,8), ..., [64,128). For each bin, compute a score as `-slack + α | 0.04 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 5 | Convert the bin-choice into a shortest-expected-path problem on a graph where nodes are capacity levels and edges represent accepting an item of a given size wi | 0.04 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.887436 |
| 3 | Define a "potential future waste" score: for each candidate bin, randomly sample 100 completions from the empirical distribution of the remaining items (using r | 0.02 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 2 | Track the empirical joint distribution of (item_size, residual_after_placement) pairs that resulted in a perfect fit (slack=0) in the past. For each candidate b | -0.08 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 5: **0.961875** (spent $0.11)

## Round 6

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 5 | Build an online approximation of the expected offloading cost: whenever a bin is chosen, record (item_size, remaining_before, remaining_after) and incrementally | 0.10 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 3 | Compute a “fragility” score for each open bin as the probability that its remaining capacity cannot be partitioned into an integer combination of frequently arr | 0.08 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961408 |
| 4 | Run a continuous no-regret online learning algorithm (e.g., a linear bandit over bin-feature vectors) where the reward after each complete packing is the negati | 0.07 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 1 | Maintain for each open bin a “waste potential” that exponentially decays toward the actual waste observed when the bin is eventually closed, but back-propagated | 0.03 | middle | Qwen/Qwen3.5-9B:together (swapped) | invalid | 0.000000 |
| 2 | Partition the incoming items into a small fixed number of size classes by clustering the empirical size distribution online, then for each class maintain a dedi | -0.02 | long_shot | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | not_better | 0.457074 |
| 0 | Use an exponential histogram of recent item sizes to estimate the current “density” of the stream, then dynamically switch the bin-selection logic between best- | -0.07 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.961642 |

Best after round 6: **0.961875** (spent $0.13)

