# Research notebook: erdos_squares

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.856172.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Precompute optimal dense packings of equal squares for square numbers, then for arbitrary n, remove some squares and locally enlarge neighbors via a physics sim | 0.62 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | improved | 0.917009 |
| 2 | Formulate as continuous optimization with barrier potentials. Initialize squares randomly, define penalty forces for overlap, and run gradient descent on sum of | 0.57 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 1 | Use a dynamic greedy placement: start with the largest possible square, then iteratively pack the largest square that fits in the remaining empty space, using r | 0.55 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | improved | 0.944074 |
| 3 | Search over partitions of n into a sum of grid-like packings: n = a^2 + b^2 + ... where each square count comes from an optimal packing of its own sub-square re | 0.50 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.772838 |
| 5 | Adapt known packings of circles in a square to squares by optimizing over an affine mapping that transforms circle centers into square positions and orientation | 0.44 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 0 | For non-square n, pack a large m-by-m grid and then fill the remaining area with a smaller (m-1)-by-(m-1) grid rotated 45 degrees in the center, solving n where | 0.36 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Promotion: deepseek-ai/DeepSeek-V4.1-Flash:deepinfra found an improvement; deepseek-ai/DeepSeek-V4-Pro:deepinfra refined it -> improved (0.944074).

Best after round 1: **0.944074** (spent $0.04)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Use a Monte Carlo tree search where each node represents a partial packing, actions are placements of the next square chosen from a pruned list of candidates (e | 0.26 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.917009 |
| 3 | Divide the unit square into a set of non-overlapping convex polygonal cells via a Voronoi-like diagram based on n seed points, then in each cell inscribe the ma | 0.25 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 2 | Perform iterative repulsion and growth: start with n random non-overlapping squares of tiny size, then alternate between growing all squares uniformly until ove | 0.24 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.625475 |
| 0 | Treat the problem as packing squares into the unit square by using a maximum-weight independent set in a disk graph: sample candidate squares (center, angle, si | 0.20 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.713475 |
| 4 | Exploit the fact that optimal packings for small n often correspond to known configurations: encode a library of topological contact graphs for n up to 20, then | 0.19 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 5 | Formulate as a mixed-integer nonlinear program where binary variables indicate relative placement (left/right, above/below) encoded via big-M constraints, then  | 0.17 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 2: **0.944074** (spent $0.07)

## Round 3

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Replace the current fixed discretization of candidate centers and angles with an adaptive grid that refines around the largest empty region found so far (using  | 0.39 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.944074 |
| 5 | Model the empty space as a polygon with holes, then use a continuous greedy strategy: repeatedly compute the largest feasible rotated square that can be inscrib | 0.23 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 3 | Adopt a simulated annealing or basin-hopping metaheuristic that perturbs an existing valid configuration (e.g., move a random square, swap two squares, or adjus | 0.17 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.942247 |
| 2 | Treat the problem as cutting stock: decompose the unit square into a set of non-overlapping rectangles (or other simple convex shapes) whose union covers the co | 0.09 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 1 | Use a convex optimization relaxation: over-parameterize the packing with n squares as variables for centers, orientations, and side lengths, then apply a log-ba | 0.07 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 4 | Precompute a database of optimal packings for all smaller n' <= 20 via exhaustive search over a discretized configuration space, then for a given n, find the be | 0.03 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 3: **0.944074** (spent $0.11)

## Round 4

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Replace greedy filling with a beam search over placements (width ~100) that maintains multiple partial packings, using a learned value function or a fast upper  | 0.19 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 1 | Formulate as a continuous optimization over positions, orientations, and log side lengths, using a smooth exact overlap penalty (e.g., via the maximum of all se | 0.16 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | api_error |  |
| 5 | Train a neural network policy using reinforcement learning: the state is the current set of placed squares (encoded on a grid), actions select a discrete locati | 0.06 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 2 | Use a bisection-guided greedy approach: repeatedly guess a target total sum S, then attempt to pack n squares with total side length S by greedily placing squar | 0.02 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.631306 |
| 4 | Decompose n into n = a² + b² + ... and pack each subset into a separate axis-aligned rectangular subregion obtained by recursive guillotine subdivision of the u | -0.02 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 3 | Apply a repulsion–growth dynamics with simulated annealing on a continuous configuration: represent each square by (cx, cy, angle, log side), apply gradient-bas | -0.12 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 4: **0.944074** (spent $0.14)

