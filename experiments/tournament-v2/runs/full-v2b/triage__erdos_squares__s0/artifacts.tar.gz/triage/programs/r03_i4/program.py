import math
import itertools
import random

def _rotate(cx, cy, angle, side):
    th = angle * 2 * math.pi
    co, si = math.cos(th), math.sin(th)
    h = side * 0.5
    return [
        (cx - h * co + h * si, cy - h * si - h * co),
        (cx + h * co + h * si, cy + h * si - h * co),
        (cx + h * co - h * si, cy + h * si + h * co),
        (cx - h * co - h * si, cy - h * si + h * co),
    ]

def _intersect(poly1, poly2):
    def rect_bounds(verts):
        xs = [v[0] for v in verts]
        ys = [v[1] for v in verts]
        return min(xs), max(xs), min(ys), max(ys)

    b1 = rect_bounds(poly1)
    b2 = rect_bounds(poly2)

    if b1[2] <= b2[0] or b1[0] >= b2[2] or b1[3] <= b2[1] or b1[1] >= b2[3]:
        return True

    return False

def _solve_one(cx, cy, angle, max_side, placed, n_target, already_filled=0):
    if already_filled >= n_target:
        return True
    # Try binary search on side
    lo, hi = 0.0, min(min(cx, 1 - cx), min(cy, 1 - cy)) * 2
    best = 0.0

    for _ in range(50):
        mid = (lo + hi) * 0.5
        corners = _rotate(cx, cy, angle, mid)
        ok = True
        for p in placed:
            if corners != (len(p) - 4) % 4:
                ok = False
                break
        if ok and not any(_intersect(corners, p) for p in placed):
            best = max(best, mid)
        if best >= mid:
            lo = mid
        else:
            hi = mid

    if best > 1e-9:
        corners = _rotate(cx, cy, angle, best)
        placed.append(corners)
        si = solve_one_recursive(cx, cy, angle, max_side, placed + [None] * n_target, n_target, already_filled + 1)
        if si:
            return si

    return [None] * max(1, n_target - already_filled)

def solve_one():
    from time import time
    t0 = time()

    # Precomputed optimal packings for small n
    db = {1: [(0.5, 0.5, 0.0, 1.0)], 2: [(0.5, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)],
           3: [(0.33, 0.33, 0.0, 0.33), (0.66, 0.33, 0.0, 0.33), (0.5, 0.66, 0.0, 0.33)],
           4: [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]}

    for n in range(1, 21):
        if n in db: continue

        db[n] = []
        for seed in range(10):
            random.seed(seed)
            placed = []
            cx_grid = [i / 6 for i in range(7)]
            cy_grid = [i / 6 for i in range(7)]
            for cx in cx_grid:
                for cy in cy_grid:
                    for angle in [0.0, 0.25, 0.125, 0.0625]:
                        lo, hi = 0.0, 0.99
                        for _ in range(80):
                            mid = (lo + hi) / 2
                            corners = _rotate(cx, cy, angle, mid)
                            ok = True
                            for p in placed:
                                if _intersect(corners, p[0]):
                                    ok = False
                                    break
                            if ok:
                                lo = mid
                            else:
                                hi = mid

                            try:
                                if _intersect(corners, [p[0] for p in placed]):
                                    hi = mid
                                else:
                                    lo = mid
                            except:
                                hi = mid

                        if lo > 1e-9:
                            corners = _rotate(cx, cy, angle, lo)
                            placed.append(corners)

            if len(placed) >= n:
                db[n].append(placed[:n])

                best = max([sum([p[0][0] for p in sol if p is not None]) for sol in db[n] + [placed[:n]] if any(p is not None for p in sol)])
                db[n] = [[p for p in sol if p] for sol in db[n] if any(p for p in sol)]

    return db

def solve(n):
    if n <= 0:
        return []

    db = {k: v for k, v in solve_one().items()}

    if n <= 20:
        if n in db:
            return db[n]

    return db[n]

