import math
import random
import time


def _corners(cx, cy, a, s):
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    h = s * 0.5
    return (
        (cx - h * co + h * si, cy - h * si - h * co),
        (cx + h * co + h * si, cy + h * si - h * co),
        (cx + h * co - h * si, cy + h * si + h * co),
        (cx - h * co - h * si, cy - h * si + h * co),
    )


def _sep(p1, p2):
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            d = ax * p1[0][0] + ay * p1[0][1]
            lo1 = hi1 = d
            for k in range(1, 4):
                d = ax * p1[k][0] + ay * p1[k][1]
                if d < lo1:
                    lo1 = d
                elif d > hi1:
                    hi1 = d
            d = ax * p2[0][0] + ay * p2[0][1]
            lo2 = hi2 = d
            for k in range(1, 4):
                d = ax * p2[k][0] + ay * p2[k][1]
                if d < lo2:
                    lo2 = d
                elif d > hi2:
                    hi2 = d
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return True
    return False


def _valid(sol):
    polys = [_corners(c[0], c[1], c[2], c[3]) for c in sol]
    for i in range(len(sol)):
        for k in range(4):
            x, y = polys[i][k]
            if x < -1e-7 or x > 1 + 1e-7 or y < -1e-7 or y > 1 + 1e-7:
                return False
    for i in range(len(sol)):
        for j in range(i + 1, len(sol)):
            if not _sep(polys[i], polys[j]):
                return False
    return True


def _fit_side(cx, cy, a, placed):
    """Max side for square at (cx,cy,a) placed, given placed corners."""
    th = a * 2.0 * math.pi
    cc = abs(math.cos(th)) + abs(math.sin(th))
    if cc <= 1e-12:
        return 0.0
    mm = min(cx, 1.0 - cx, cy, 1.0 - cy)
    hi = 2.0 * mm / cc
    if hi <= 0:
        return 0.0
    p = _corners(cx, cy, a, hi)
    ok = True
    for pc in placed:
        if not _sep(p, pc):
            ok = False
            break
    if ok:
        return hi
    lo = 0.0
    for _ in range(18):
        mid = (lo + hi) * 0.5
        p = _corners(cx, cy, a, mid)
        good = True
        for pc in placed:
            if not _sep(p, pc):
                good = False
                break
        if good:
            lo = mid
        else:
            hi = mid
    return lo


# ---------------- Neural network (tiny MLP via numpy-free lists) ----------------

class MLP:
    def __init__(self, nin, nh, nout, seed=0):
        rng = random.Random(seed)
        self.nin = nin
        self.nh = nh
        self.nout = nout
        self.W1 = [[rng.gauss(0, 0.1) for _ in range(nin)] for _ in range(nh)]
        self.b1 = [0.0] * nh
        self.W2 = [[rng.gauss(0, 0.1) for _ in range(nh)] for _ in range(nout)]
        self.b2 = [0.0] * nout

    def forward(self, x):
        h = []
        for r in range(self.nh):
            z = self.b1[r]
            Wr = self.W1[r]
            for i in range(self.nin):
                z += Wr[i] * x[i]
            h.append(math.tanh(z))
        out = []
        for r in range(self.nout):
            z = self.b2[r]
            Wr = self.W2[r]
            for i in range(self.nh):
                z += Wr[i] * h[i]
            out.append(z)
        return h, out


# ---------------- State encoding ----------------

GRID = 6


def _encode(placed, cx_prev, cy_prev, a_prev, step_frac, n):
    """Feature vector: coarse occupancy grid + progress + last action."""
    occ = [0.0] * (GRID * GRID)
    for c in placed:
        gx = min(GRID - 1, max(0, int(c[0] * GRID)))
        gy = min(GRID - 1, max(0, int(c[1] * GRID)))
        occ[gy * GRID + gx] += c[3]
    x = list(occ)
    x.append(step_frac)
    x.append(float(len(placed)) / max(1, n))
    x.append(cx_prev)
    x.append(cy_prev)
    x.append(a_prev)
    return x


def _nbins(GRID):
    return GRID * GRID


# ---------------- Environment / candidate generation ----------------

def _candidate_centers():
    cs = set()
    for k in range(1, 8):
        for i in range(k):
            for j in range(k):
                cs.add((round((i + 0.5) / k, 5), round((j + 0.5) / k, 5)))
    G = 9
    for i in range(G + 1):
        for j in range(G + 1):
            cs.add((round((i + 0.5) / (G + 1), 5), round((j + 0.5) / (G + 1), 5)))
    return sorted(cs)


ANGLES = (0.0, 0.25, 0.125, 0.0625, 0.375, 0.1875, 0.3125, 0.4375)


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    m = 1
    while m * m < n:
        m += 1
    side = 1.0 / m
    base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(m) for j in range(m)][:n]
    best_sol = base
    best_sum = sum(q[3] for q in best_sol)

    # grid strategies baseline
    for mm in range(1, n + 2):
        if mm * mm >= n:
            s = 1.0 / mm
            cand = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                    for i in range(mm) for j in range(mm)][:n]
            v = sum(q[3] for q in cand)
            if v > best_sum:
                best_sum = v
                best_sol = cand
                break

    centers = _candidate_centers()
    NC = len(centers)
    NA = len(ANGLES)
    bin_grid = _nbins(GRID)

    nin = bin_grid + 5
    nh = 64
    # policy outputs: location logits (NC) + angle logits (NA) + side mean
    policy = MLP(nin, nh, NC + NA + 1, seed=12345)
    value_net = MLP(nin, nh, 1, seed=54321)

    # cache of "max side fits" per (center id, angle id) given occupancy
    # computed on the fly with binary search

    def rollout(eps=0.0, greedy=False, budget=None):
        sol = []
        placed = []
        logps = []
        states = []
        actions = []
        cx_prev, cy_prev, a_prev = 0.5, 0.5, 0.0
        for step in range(n):
            if budget is not None and time.time() - t0 > budget:
                break
            x = _encode([(c[0], c[1], c[2], c[3]) for c in sol],
                        cx_prev, cy_prev, a_prev, step / max(1, n), n)
            h, out = policy.forward(x)
            loc_logits = out[:NC]
            ang_logits = out[NC:NC + NA]
            side_mu = out[NC + NA]

            # choose location: mask ones that are infeasible
            # find best fit for each location to build feasibility & scale
            ii = 0
            best_ci = None
            best_si = -1.0
            if greedy:
                ci_choice = None
                # evaluate feasible ones, pick with policy preference among good ones
                cands = []
                for ci in range(NC):
                    cxc, cyc = centers[ci]
                    mxs = 0.0
                    for ai in range(NA):
                        s = _fit_side(cxc, cyc, ANGLES[ai], placed)
                        if s > mxs:
                            mxs = s
                    if mxs > 1e-6:
                        cands.append((ci, mxs))
                if cands:
                    # choose best by logits + value-ish (here just logits)
                    best_score = None
                    for (ci, mxs) in cands:
                        sc = loc_logits[ci]
                        if best_score is None or sc > best_score:
                            best_score = sc
                            ci_choice = ci
                else:
                    ci_choice = random.randrange(NC)
                cxc, cyc = centers[ci_choice]
                # choose angle majority
                ai_choice = 0
                bests = -1.0
                for ai in range(NA):
                    s = _fit_side(cxc, cyc, ANGLES[ai], placed)
                    if s > bests:
                        bests = s
                        ai_choice = ai
                s_choice = bests
                loc_choice = ci_choice
                ang_choice = ai_choice
            else:
                # sample location via softmax over feasible candidates
                feas = []
                for ci in range(NC):
                    cxc, cyc = centers[ci]
                    mxs = 0.0
                    bestai = 0
                    for ai in range(NA):
                        s = _fit_side(cxc, cyc, ANGLES[ai], placed)
                        if s > mxs:
                            mxs = s
                            bestai = ai
                    if mxs > 1e-6:
                        feas.append((ci, mxs, bestai))
                if not feas:
                    break
                maxl = max(loc_logits[ci] for (ci, _, _) in feas)
                ws = [math.exp((loc_logits[ci] - maxl)) for (ci, _, _) in feas]
                tot = sum(ws)
                r = random.random() * tot
                acc = 0.0
                pick = feas[-1]
                for idx, (ci, mxs, bai) in enumerate(feas):
                    acc += ws[idx]
                    if r <= acc:
                        pick = feas[idx]
                        break
                loc_choice = pick[0]
                cxc, cyc = centers[loc_choice]
                # sample angle via softmax
                amax = max(ang_logits)
                aw = [math.exp(ang_logits[k] - amax) for k in range(NA)]
                # restrict to feasible
                feas_a = [(ai, _fit_side(cxc, cyc, ANGLES[ai], placed)) for ai in range(NA)]
                feas_a = [(ai, s) for (ai, s) in feas_a if s > 1e-6]
                if not feas_a:
                    break
                atot = sum(aw[ai] for (ai, _) in feas_a)
                rr = random.random() * atot
                acc = 0.0
                ang_choice = feas_a[-1][0]
                for (ai, s) in feas_a:
                    acc += aw[ai]
                    if rr <= acc:
                        ang_choice = ai
                        break
                smax = _fit_side(cxc, cyc, ANGLES[ang_choice], placed)
                side_choice = random.uniform(0.0, max(1e-6, smax))
                # bias toward max
                if random.random() < 0.5:
                    side_choice = smax * random.uniform(0.85, 1.0)

            if not greedy:
                if side_choice < 1e-9:
                    side_choice = 0.0
                # log prob approx
                logp = loc_logits[loc_choice] + ang_logits[ang_choice]
                logps.append(logp)
                states.append(x)
                actions.append((loc_choice, ang_choice, side_choice))
            sol.append((cxc, cyc, ANGLES[ang_choice] if not greedy else ANGLES[ang_choice],
                        side_choice))
            placed.append(_corners(cxc, cyc, ANGLES[ang_choice], side_choice))
            cx_prev, cy_prev, a_prev = cxc, cyc, ANGLES[ang_choice]

        while len(sol) < n:
            sol.append((0.5, 0.5, 0.0, 0.0))
        return sol, logps, states, actions

    # PPO-like training loop
    def train(budget):
        lr = 0.01
        gamma = 1.0
        clip = 0.2
        episodes = 0
        while time.time() - t0 < budget:
            episodes += 1
            sol, logps, states, actions = rollout(budget=budget)
            R = sum(q[3] for q in sol)
            # reward shaping: return-to-go
            returns = []
            g = R
            for _ in range(len(logps)):
                returns.append(g)
            base_adv = R

            # update policy with policy-gradient (REINFORCE / PPO surrogate via finite diff not feasible)
            # Use simple score-function gradient: dlogp * advantage, with analytic logp grad wrt logits.
            for si in range(len(states)):
                if time.time() - t0 > budget:
                    break
                x = states[si]
                h, out = policy.forward(x)
                loc_choice, ang_choice, side_choice = actions[si]
                adv = returns[si] - base_adv * 0.5
                # normalize loosely
                adv = max(-3.0, min(3.0, adv))
                # gradient of log softmax logit k wrt out_k: (1 - p_k)
                # We do a simple ascent step on out at chosen logits.
                NC_l = NC
                # softmax probabilities
                maxl = max(out[:NC_l])
                ex = [math.exp(out[k] - maxl) for k in range(NC_l)]
                tot = sum(ex)
                pk_loc = ex[loc_choice] / tot
                amax = max(out[NC_l:NC_l + NA])
                aex = [math.exp(out[NC_l + k] - amax) for k in range(NA)]
                atot = sum(aex)
                pk_ang = aex[ang_choice] / atot
                # REINFORCE: increase chosen logit if adv>0
                # proxy gradient
                gl = [0.0] * (NC_l + NA + 1)
                # d/d out_k of log p = (1 - p_k) if k==chosen else -p_k
                sgn = adv
                gl[loc_choice] = sgn * (1.0 - pk_loc)
                for k in range(NC_l):
                    if k != loc_choice:
                        gl[k] = sgn * (-pk_loc) * 1e-3
                gl[NC_l + ang_choice] = sgn * (1.0 - pk_ang)
                # side mean grad (squared error toward side_choice if adv positive)
                gl[NC_l + NA] = sgn * (side_choice - out[NC_l + NA]) * 0.5
                # backprop through policy (only update W2,b2 for speed & stability)
                # out = W2 h + b2
                for r in range(policy.nout):
                    gr = gl[r]
                    if abs(gr) < 1e-9:
                        continue
                    Wr = policy.W2[r]
                    for j in range(policy.nh):
                        Wr[j] += lr * gr * h[j]
                    policy.b2[r] += lr * gr

    # ---- strategic seed solutions first (guaranteed quality) ----
    def greedy_fill(seed_sol, budget):
        sol = list(seed_sol)
        placed = [_corners(c[0], c[1], c[2], c[3]) for c in sol]
        while len(sol) < n and time.time() - t0 < budget:
            bests = 0.0
            bestc = None
            for (cx, cy) in centers:
                for ai, a in enumerate(ANGLES):
                    u = _fit_side(cx, cy, a, placed)
                    if u > bests:
                        bests = u
                        bestc = (cx, cy, a)
            if bestc is None or bests <= 1e-9:
                break
            sol.append((bestc[0], bestc[1], bestc[2], bests))
            placed.append(_corners(bestc[0], bestc[1], bestc[2], bests))
        while len(sol) < n:
            sol.append((0.5, 0.5, 0.0, 0.0))
        return sol

    for k in range(1, n + 1):
        if k * k > n:
            break
        if time.time() - t0 > 45:
            break
        gs = 1.0 / k
        seed = [((i + 0.5) * gs, (j + 0.5) * gs, 0.0, gs)
                for i in range(k) for j in range(k)]
        sol = greedy_fill(seed, 48)
        if _valid(sol):
            v = sum(q[3] for q in sol)
            if v > best_sum:
                best_sum = v
                best_sol = sol

    if time.time() - t0 < 45:
        sol = greedy_fill([], 48)
        if _valid(sol):
            v = sum(q[3] for q in sol)
            if v > best_sum:
                best_sum = v
                best_sol = sol

    # ---- RL training ----
    train_budget = 57
    train(train_budget)

    # collect best from RL policy (greedy rollout)
    if time.time() - t0 < 58:
        sol, _, _, _ = rollout(greedy=True, budget=58)
        if _valid(sol):
            v = sum(q[3] for q in sol)
            if v > best_sum:
                best_sum = v
                best_sol = sol

    if time.time() - t0 < 58.5:
        # a few greedy rollouts
        for _ in range(3):
            if time.time() - t0 > 58.5:
                break
            sol, _, _, _ = rollout(greedy=True, budget=58.5)
            if _valid(sol):
                v = sum(q[3] for q in sol)
                if v > best_sum:
                    best_sum = v
                    best_sol = sol

    return best_sol[:n]
