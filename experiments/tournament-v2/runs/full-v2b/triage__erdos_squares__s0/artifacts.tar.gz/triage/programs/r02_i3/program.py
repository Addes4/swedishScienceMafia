import math
import time
import random
import numpy as np
from scipy.spatial import Voronoi
from shapely.geometry import Polygon, Point, box
from shapely.ops import polygonize


def _corners(cx, cy, a, s):
    """Return the four corners of a square (rotated)."""
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    h = s * 0.5
    return [
        (cx - h * co + h * si, cy - h * si - h * co),
        (cx + h * co + h * si, cy + h * si - h * co),
        (cx + h * co - h * si, cy + h * si + h * co),
        (cx - h * co - h * si, cy - h * si + h * co),
    ]


def polygon_from_region(region, vertices):
    """Convert a Voronoi region index list to a Shapely polygon."""
    if -1 in region or len(region) < 3:
        return None
    poly_pts = [tuple(vertices[i]) for i in region]
    return Polygon(poly_pts)


def clip_polygon_to_unit_square(poly):
    """Clip a Shapely polygon to [0,1]x[0,1]."""
    boundary = box(0, 0, 1, 1)
    if not poly.is_valid:
        poly = poly.buffer(0)
    return poly.intersection(boundary)


def maximum_inscribed_square(polygon):
    """
    Given a convex polygon (Shapely), find the maximum-area square that fits inside.
    Returns: (cx, cy, angle, side) where angle is in fractions of full turn.
    We search over 24 rotation angles and use binary search for side length.
    """
    if polygon.is_empty or polygon.area < 1e-12:
        return (0.5, 0.5, 0.0, 0.0)

    # Use centroid as initial guess for center
    centroid = polygon.centroid
    cx0, cy0 = centroid.x, centroid.y

    best_result = (cx0, cy0, 0.0, 0.0)

    # Test multiple angles
    for frac in np.linspace(0, 0.25, 25)[:-1]:  # rotation symmetry every 90 deg
        # binary search on side length
        lo, hi = 0.0, 1.5  # side cannot exceed 1.5 (diagonal)
        for _ in range(25):
            mid = (lo + hi) / 2.0
            corners = _corners(cx0, cy0, frac, mid)
            if all(polygon.contains(Point(c)) or polygon.touches(Point(c)) for c in corners):
                lo = mid
            else:
                hi = mid
        if lo > best_result[3]:
            best_result = (cx0, cy0, frac, lo)

    # Refine center by shifting a bit (small local optimization)
    # Try small perturbations
    for dx, dy in [(-0.02, 0), (0.02, 0), (0, -0.02), (0, 0.02), (-0.01, -0.01), (0.01, 0.01)]:
        nc = (cx0 + dx, cy0 + dy)
        for frac in np.linspace(0, 0.25, 13)[:-1]:
            lo, hi = 0.0, 1.5
            for _ in range(20):
                mid = (lo + hi) / 2.0
                corners = _corners(nc[0], nc[1], frac, mid)
                if all(polygon.contains(Point(c)) or polygon.touches(Point(c)) for c in corners):
                    lo = mid
                else:
                    hi = mid
            if lo > best_result[3]:
                best_result = (nc[0], nc[1], frac, lo)

    return best_result


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Initial seed points: use low-discrepancy-like distribution
    # Mix of grid and random to start
    # Use sqrt(n) based grid plus perturbations
    m = int(math.ceil(math.sqrt(n)))
    seeds = []
    for i in range(m):
        for j in range(m):
            if len(seeds) < n:
                x = (i + 0.5) / m
                y = (j + 0.5) / m
                # small random offset
                seeds.append((x + random.uniform(-0.02, 0.02), y + random.uniform(-0.02, 0.02)))
    # If m*m < n, add random extra
    while len(seeds) < n:
        seeds.append((random.random(), random.random()))
    seeds = seeds[:n]

    # Bounding box points for Voronoi to clip to unit square
    # add dummy far points to ensure regions are bounded
    # We'll instead clip later.
    best_sol = None
    best_sum = 0.0

    # Lloyd's iteration parameters
    max_iters = 15
    for iteration in range(max_iters):
        if time.time() - t0 > 55:
            break

        # Ensure seeds inside [0,1]
        seeds = [(min(max(p[0], 0.01), 0.99), min(max(p[1], 0.01), 0.99)) for p in seeds]

        # Build Voronoi from seeds, add far points to bound regions
        all_points = np.array(seeds + [(-99, -99), (99, -99), (99, 99), (-99, 99)])
        vor = Voronoi(all_points)

        regions = []
        for i in range(n):
            region_idx = vor.point_region[i]
            region_vertices = vor.regions[region_idx]
            poly = polygon_from_region(region_vertices, vor.vertices)
            if poly is None:
                regions.append(None)
            else:
                # Clip to [0,1]x[0,1]
                clipped = clip_polygon_to_unit_square(poly)
                if clipped.is_empty or clipped.area < 1e-12:
                    regions.append(None)
                else:
                    # ensure it's a single polygon (may be multipolygon after clip)
                    if clipped.geom_type == 'MultiPolygon':
                        # take the largest part
                        clipped = max(clipped.geoms, key=lambda p: p.area)
                    regions.append(clipped)

        # Compute maximum inscribed square in each region
        squares = []
        sum_sides = 0.0
        new_seeds = []
        for i, poly in enumerate(regions):
            if poly is None:
                cx, cy, a, s = seeds[i][0], seeds[i][1], 0.0, 0.0
            else:
                cx, cy, a, s = maximum_inscribed_square(poly)
            squares.append((cx, cy, a, s))
            sum_sides += s
            # new seed is the center of the inscribed square
            new_seeds.append((cx, cy))

        if sum_sides > best_sum:
            best_sum = sum_sides
            best_sol = squares[:]

        # Update seeds as centers of squares
        seeds = new_seeds

    # If we still have time, try a greedy improvement from empty
    if time.time() - t0 < 50:
        # simple grid+fill from original best known method as fallback
        # We'll do a quick greedy placement
        from itertools import product
        # Use a coarse candidate set
        candidates = []
        for i in range(10):
            for j in range(10):
                candidates.append(((i+0.5)/10, (j+0.5)/10))
        angles = [0.0, 0.25, 0.125]
        def _quick_sep(p1, p2):
            # simplified SAT
            poly1 = _corners(*p1)
            poly2 = _corners(*p2)
            for poly in (poly1, poly2):
                for i in range(4):
                    x1, y1 = poly[i]
                    x2, y2 = poly[(i+1)%4]
                    ax = y1 - y2
                    ay = x2 - x1
                    lo1 = hi1 = ax*poly1[0][0] + ay*poly1[0][1]
                    for k in range(1,4):
                        v = ax*poly1[k][0] + ay*poly1[k][1]
                        lo1 = min(lo1, v)
                        hi1 = max(hi1, v)
                    lo2 = hi2 = ax*poly2[0][0] + ay*poly2[0][1]
                    for k in range(1,4):
                        v = ax*poly2[k][0] + ay*poly2[k][1]
                        lo2 = min(lo2, v)
                        hi2 = max(hi2, v)
                    if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                        return True
            return False
        def _greedy(placed):
            pc = [_corners(q[0],q[1],q[2],q[3]) for q in placed]
            while len(placed)<n:
                best_s = 0.0
                best_p = None
                for cx, cy in candidates:
                    for a in angles:
                        # max side possible inside unit square from this center,angle
                        mm = min(cx, 1-cx, cy, 1-cy)
                        th = a*2*math.pi
                        cc = abs(math.cos(th))+abs(math.sin(th))
                        max_s = 2*mm/cc if cc>0 else 0
                        if max_s <= best_s: continue
                        lo, hi = best_s, max_s
                        for _ in range(15):
                            mid = (lo+hi)/2
                            p = _corners(cx,cy,a,mid)
                            ok = True
                            for op in pc:
                                if not _quick_sep((cx,cy,a,mid), None):
                                    # need to pass corners
                                    pass
                            # rewrite quick sep to take corners
                            poly1 = p
                            good = True
                            for op in pc:
                                # SAT
                                poly2 = op
                                sep = True
                                for poly in (poly1, poly2):
                                    for i in range(4):
                                        x1,y1 = poly[i]
                                        x2,y2 = poly[(i+1)%4]
                                        ax = y1-y2
                                        ay = x2-x1
                                        lo1=hi1=ax*poly1[0][0]+ay*poly1[0][1]
                                        for k in range(1,4):
                                            v=ax*poly1[k][0]+ay*poly1[k][1]
                                            lo1=min(lo1,v); hi1=max(hi1,v)
                                        lo2=hi2=ax*poly2[0][0]+ay*poly2[0][1]
                                        for k in range(1,4):
                                            v=ax*poly2[k][0]+ay*poly2[k][1]
                                            lo2=min(lo2,v); hi2=max(hi2,v)
                                        if hi1 <= lo2+1e-12 or hi2<= lo1+1e-12:
                                            break
                                    else:
                                        continue
                                    break
                                else:
                                    good = False
                                if not good:
                                    break
                            if good:
                                lo = mid
                            else:
                                hi = mid
                        if lo > best_s+1e-9:
                            best_s = lo
                            best_p = (cx,cy,a)
                if best_p is None:
                    placed.append((0.5,0.5,0.0,0.0))
                else:
                    placed.append((best_p[0],best_p[1],best_p[2],best_s))
                pc.append(_corners(placed[-1][0],placed[-1][1],placed[-1][2],placed[-1][3]))
            return placed
        gr = _greedy([])
        gr_sum = sum(q[3] for q in gr)
        if gr_sum > best_sum:
            best_sol = gr
            best_sum = gr_sum

    # Ensure exactly n squares
    while len(best_sol) < n:
        best_sol.append((0.5,0.5,0.0,0.0))
    return best_sol[:n]
