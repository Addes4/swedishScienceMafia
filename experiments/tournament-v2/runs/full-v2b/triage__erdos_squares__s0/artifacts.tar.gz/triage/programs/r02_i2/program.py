import math
import random
import time


def _corners(cx, cy, a, s):
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    h = s * 0.5
    return (
        (cx - h * co + h * si, cy - h * si - h * co),
        (cx + h * co + h * si, cy + h * si - h * co),
        (cx + h * co - h * si, cy + h * si + h * co),
        (cx - h * co - h * si, cy - h * si + h * co),
    )


def _overlap(p1, p2):
    """Return (overlap depth, mtv) if the two convex quads overlap, else None."""
    depth = 1e18
    mx = my = 0.0
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            ln = math.hypot(ax, ay)
            if ln < 1e-15:
                continue
            ax /= ln
            ay /= ln
            d = ax * p1[0][0] + ay * p1[0][1]
            lo1 = hi1 = d
            for k in range(1, 4):
                d = ax * p1[k][0] + ay * p1[k][1]
                if d < lo1:
                    lo1 = d
                elif d > hi1:
                    hi1 = d
            d = ax * p2[0][0] + ay * p2[0][1]
            lo2 = hi2 = d
            for k in range(1, 4):
                d = ax * p2[k][0] + ay * p2[k][1]
                if d < lo2:
                    lo2 = d
                elif d > hi2:
                    hi2 = d
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return None
            # overlap along this axis
            o = min(hi1, hi2) - max(lo1, lo2)
            if o < depth:
                depth = o
                mx, my = ax, ay
    if depth >= 1e18:
        return None
    return depth, mx, my


def _validate(sol):
    n = len(sol)
    cs = [_corners(q[0], q[1], q[2], q[3]) for q in sol]
    for i in range(n):
        if sol[i][3] <= 1e-12:
            continue
        for j in range(i + 1, n):
            if sol[j][3] <= 1e-12:
                continue
            if _overlap(cs[i], cs[j]) is not None:
                return False
    return True


def _clip(q):
    cx, cy, a, s = q
    a = a % 1.0
    if s <= 0:
        return (min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), a, 0.0)
    th = a * 2.0 * math.pi
    cc = abs(math.cos(th)) + abs(math.sin(th))
    h = s * 0.5
    ex = h * cc
    if ex <= 0:
        return (0.5, 0.5, a, 0.0)
    mx = 1.0 / cc
    if s > mx:
        s = mx
        h = s * 0.5
        ex = h * cc
    lo = ex
    hi = 1.0 - ex
    if lo > hi:
        cx = 0.5
    else:
        cx = min(max(cx, lo), hi)
    return (cx, cy, a, s)


def _resolve(sol, iters=60):
    """Iteratively push overlapping squares apart."""
    n = len(sol)
    for _ in range(iters):
        cs = [_corners(q[0], q[1], q[2], q[3]) for q in sol]
        moved = False
        for i in range(n):
            if sol[i][3] <= 1e-12:
                continue
            for j in range(i + 1, n):
                if sol[j][3] <= 1e-12:
                    continue
                ov = _overlap(cs[i], cs[j])
                if ov is None:
                    continue
                depth, nx, ny = ov
                # push along mtv
                push = depth * 0.5 + 1e-9
                si = sol[i][3]
                sj = sol[j][3]
                wi = sj + 1e-9
                wj = si + 1e-9
                tot = wi + wj
                fi = push * (wi / tot)
                fj = push * (wj / tot)
                ci = sol[i]
                cj = sol[j]
                sol[i] = _clip((ci[0] - nx * fi, ci[1] - ny * fi, ci[2], ci[3]))
                sol[j] = _clip((cj[0] + nx * fj, cj[1] + ny * fj, cj[2], cj[3]))
                moved = True
        if not moved:
            break
    return sol


def _greedy_fill(n, t0, budget):
    """Baseline: keep adding squares in the largest free spot."""
    sol = []
    while len(sol) < n:
        if time.time() - t0 > budget:
            break
        # sample candidate centres
        best = None
        best_s = -1.0
        for _ in range(400):
            cx = random.random()
            cy = random.random()
            a = random.choice((0.0, 0.25, 0.125, 0.375))
            th = a * 2.0 * math.pi
            cc = abs(math.cos(th)) + abs(math.sin(th))
            mm = min(cx, 1.0 - cx, cy, 1.0 - cy)
            u = 2.0 * mm / cc
            if u <= best_s:
                continue
            p1 = _corners(cx, cy, a, u)
            good = True
            for q in sol:
                pc = _corners(q[0], q[1], q[2], q[3])
                if _overlap(p1, pc) is not None:
                    good = False
                    break
            if good:
                best_s = u
                best = (cx, cy, a)
        if best is None:
            # try smaller
            found = False
            for _ in range(600):
                cx = random.random()
                cy = random.random()
                a = random.choice((0.0, 0.25, 0.125, 0.375))
                for t in range(1, 40):
                    u = 0.05 * (1.0 - t / 40.0)
                    p1 = _corners(cx, cy, a, u)
                    good = True
                    for q in sol:
                        pc = _corners(q[0], q[1], q[2], q[3])
                        if _overlap(p1, pc) is not None:
                            good = False
                            break
                    if good and u > 1e-6:
                        sol.append((cx, cy, a, u))
                        found = True
                        break
                if found:
                    break
            if not found:
                sol.append((0.5, 0.5, 0.0, 0.0))
        else:
            sol.append((best[0], best[1], best[2], best_s))
    while len(sol) < n:
        sol.append((0.5, 0.5, 0.0, 0.0))
    return sol


def _random_start(n):
    m = 1
    while m * m < n:
        m += 1
    s = 1.0 / m
    sol = []
    for i in range(m):
        for j in range(m):
            sol.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    sol = sol[:n]
    while len(sol) < n:
        sol.append((0.5, 0.5, 0.0, 0.0))
    return sol


def _grow_shrink(sol, n, t0, budget):
    """Alternate growth and overlap resolution."""
    sol = _resolve(sol, 80)
    best_sum = sum(q[3] for q in sol) if _validate(sol) else 0.0
    best_sol = [q for q in sol]
    shrink = 0.02
    fail = 0
    while time.time() - t0 < budget:
        # grow
        grown = []
        for cx, cy, a, s in sol:
            ns = s * (1.0 + 0.03)
            if ns > 1.0:
                ns = 1.0
            grown.append(_clip((cx, cy, a, ns)))
        grown = _resolve(grown, 80)
        # shrink slightly to break contact
        for _ in range(1):
            pass
        cur = sum(q[3] for q in grown)
        if _validate(grown) and cur > best_sum + 1e-9:
            best_sum = cur
            best_sol = [q for q in grown]
            sol = grown
            fail = 0
        else:
            # revert and perturb
            fail += 1
            # random perturbation
            new = []
            for q in sol:
                ex = q[0] + (random.random() - 0.5) * shrink
                ey = q[1] + (random.random() - 0.5) * shrink
                na = q[2] + (random.random() - 0.5) * 0.06
                ns = q[3] * (1.0 - random.random() * 0.02)
                new.append(_clip((ex, ey, na, ns)))
            new = _resolve(new, 80)
            if _validate(new):
                sol = new
            shrink = min(shrink * 1.1, 0.1)
    return best_sol


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345 + n)

    m = 1
    while m * m < n:
        m += 1
    side = 1.0 / m
    best_sol = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(m) for j in range(m)][:n]
    best_sum = sum(q[3] for q in best_sol)

    # baseline greedy
    g = _greedy_fill(n, t0, 5)
    v = sum(q[3] for q in g)
    if v > best_sum and _validate(g):
        best_sum = v
        best_sol = g

    # iterated growth from several starts
    tries = 0
    while time.time() - t0 < 50.0 and tries < 30:
        tries += 1
        if tries == 1:
            start = _random_start(n)
        elif tries % 2 == 0:
            start = _random_start(n)
        else:
            start = [q for q in best_sol]
        # randomize
        rnd = []
        for q in start:
            ex = q[0] + (random.random() - 0.5) * 0.05
            ey = q[1] + (random.random() - 0.5) * 0.05
            na = q[2] + (random.random() - 0.5) * 0.05
            ns = q[3] * (0.85 + random.random() * 0.15)
            rnd.append(_clip((ex, ey, na, ns)))
        rnd = _resolve(rnd, 100)
        if not _validate(rnd):
            continue
        r = _grow_shrink(rnd, n, t0, min(50.0, 8.0 + tries * 1.5))
        v = sum(q[3] for q in r)
        if v > best_sum + 1e-9 and _validate(r):
            best_sum = v
            best_sol = r

    if not _validate(best_sol):
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(m) for j in range(m)][:n]
        best_sol = best

    return best_sol[:n]
