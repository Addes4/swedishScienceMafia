import math
import random
import time
from typing import List, Tuple


def solve(n: int) -> List[Tuple[float, float, float, float]]:
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_sol = None
    best_sum = 0.0

    def rect_corners(cx: float, cy: float, angle: float, s: float):
        th = angle * 2.0 * math.pi
        co = math.cos(th)
        si = math.sin(th)
        h = s * 0.5
        return [
            (cx - h * co + h * si, cy - h * si - h * co),
            (cx + h * co + h * si, cy + h * si - h * co),
            (cx + h * co - h * si, cy + h * si + h * co),
            (cx - h * co - h * si, cy - h * si + h * co),
        ]

    def sq_overlaps(p1, p2):
        for i in range(4):
            x1, y1 = p1[i]
            x2, y2 = p1[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            d = ax * p1[0][0] + ay * p1[0][1]
            lo1 = hi1 = d
            for k in range(1, 4):
                d = ax * p1[k][0] + ay * p1[k][1]
                lo1 = min(lo1, d)
                hi1 = max(hi1, d)
            if i == 0:
                p = p2
            else:
                p = p2
            d = ax * p[0][0] + ay * p[0][1]
            lo2 = hi2 = d
            for k in range(1, 4):
                d = ax * p[k][0] + ay * p[k][1]
                lo2 = min(lo2, d)
                hi2 = max(hi2, d)
            if hi1 <= lo2 + 1e-10 or hi2 <= lo1 + 1e-10:
                return True
        return False

    def any_overlap(squares):
        for i in range(len(squares)):
            p1 = rect_corners(squares[i][0], squares[i][1], squares[i][2], squares[i][3])
            for j in range(i + 1, len(squares)):
                p2 = rect_corners(squares[j][0], squares[j][1], squares[j][2], squares[j][3])
                if sq_overlaps(p1, p2):
                    return squares[i], squares[j]
        return None, None

    def grow_axes(p1, p2, shift_factor=1.5, weight_factor=2.0):
        ax = p1[0][1] - p1[1][1]
        ay = p1[1][0] - p1[0][0]
        d = ax * p1[0][0] + ay * p1[0][1]
        lo1 = hi1 = d
        for k in range(1, 4):
            d = ax * p1[k][0] + ay * p1[k][1]
            lo1 = min(lo1, d)
            hi1 = max(hi1, d)
        d = ax * p2[0][0] + ay * p2[0][1]
        lo2 = hi2 = d
        for k in range(1, 4):
            d = ax * p2[k][0] + ay * p2[k][1]
            lo2 = min(lo2, d)
            hi2 = max(hi2, d)
        overlap = max(0, hi1 - lo2)
        if overlap < 1e-12:
            overlap = max(0, hi2 - lo1)
        if overlap < 1e-12:
            return None
        unit = math.sqrt(ax * ax + ay * ay)
        if unit < 1e-12:
            unit = 1.0
        ax /= unit
        ay /= unit
        shift = max(overlap * 2.0, 0.1) * weight_factor * shift_factor
        dir_x = -ax
        dir_y = -ay
        return dir_x * shift, dir_y * shift

    def clip(cx: float, cy: float, s: float, points: List[Tuple[float, float]], eps=1e-6):
        for x, y in points:
            if x < eps:
                cx -= (eps - x + s * 0.5) * 1.0
            if x > 1 - eps:
                cx += (1 - eps - x - s * 0.5) * 1.0
            if y < eps:
                cy -= (eps - y + s * 0.5) * 1.0
            if y > 1 - eps:
                cy += (1 - eps - y - s * 0.5) * 1.0
        return cx, cy

    def compute_total_sum(squares):
        return sum(sq[3] for sq in squares)

    def initial_config(n):
        squares = []
        if n == 1:
            squares = [(0.5, 0.5, 0.0, math.log(1.0))]
        else:
            k = int(n ** 0.4) + 1 if n > 10 else 2
            step = 1.0 / k
            for i in range(k):
                for j in range(k):
                    if len(squares) >= n:
                        break
                    cx = round((i + 0.5) * step, 6)
                    cy = round((j + 0.5) * step, 6)
                    s = min(cx, 1 - cx, cy, 1 - cy, 1.0 / n)
                    overlap_s = random.uniform(0.3, 0.7) * s
                    squares.append((cx, cy, random.uniform(0.0, 1.0), math.log(max(overlap_s, 0.01))))
        return squares[:n]

    def evaluate_energy(squares, temperature):
        energy = 0.0
        total_s = 0.0
        for sq in squares:
            total_s += sq[3]
        energy = -total_s * 1000.0  # maximize side sum -> minimize negative sum
        for i in range(len(squares)):
            p1 = rect_corners(squares[i][0], squares[i][1], squares[i][2], math.exp(squares[i][3]))
            for j in range(i + 1, len(squares)):
                p2 = rect_corners(squares[j][0], squares[j][1], squares[j][2], math.exp(squares[j][3]))
                if sq_overlaps(p1, p2):
                    penetration = 0.0
                    for k in range(4):
                        ax = p1[k][1] - p1[(k + 1) & 3][1]
                        ay = p1[(k + 1) & 3][0] - p1[k][0]
                        d = ax * p1[0][0] + ay * p1[0][1]
                        lo1 = hi1 = d
                        for m in range(1, 4):
                            d = ax * p1[m][0] + ay * p1[m][1]
                            lo1 = min(lo1, d)
                            hi1 = max(hi1, d)
                        lo2 = hi2 = d
                        for m in range(1, 4):
                            d = ax * p2[m][0] + ay * p2[m][1]
                            lo2 = min(lo2, d)
                            hi2 = max(hi2, d)
                        if hi1 <= lo2 + 1e-12:
                            penetration = max(0.0, hi2 - lo1 + 1e-12)
                        elif hi2 <= lo1 + 1e-12:
                            penetration = max(0.0, hi1 - lo2 + 1e-12)
                        else:
                            penetration = max(0.0, max(hi1, hi2) - min(lo1, lo2) + 1e-12)
                    energy += penetration * 1000.0
        for i in range(len(squares)):
            for x, y in rect_corners(squares[i][0], squares[i][1], squares[i][2], math.exp(squares[i][3])):
                if x < 0 or x > 1 or y < 0 or y > 1:
                    energy += 10000.0
        return energy, total_s

    def move_update(squares, delta_energy):
        if random.random() < math.exp(min(0.0, delta_energy / 1.0)):
            nx = squares[0][0] + random.uniform(-0.1, 0.1)
            ny = squares[0][1] + random.uniform(-0.1, 0.1)
            na = squares[0][2] + random.uniform(-0.1, 0.1)
            ns = squares[0][3] + random.uniform(-0.1, 0.1)
            next_sq = (nx, ny, na, max(ns - 2.0, -3.0))
            delta = next_sq[3] - squares[0][3]
            if delta_energy + delta * 1000.0 >= -1e6:
                return squares[:], [i for i in range(len(squares))]
        return squares, list(range(len(squares)))

    def swap_two(idx1, idx2, squares):
        return squares[:], [idx1, idx2]

    def simulate(n, iterations=2000, cooling=0.995, swap_chance=0.05):
        t0 = time.time()
        squares = initial_config(n)
        total_s = compute_total_sum(squares)
        cx, cy, angles, sides = [sq[:1], sq[:2], sq[:3], math.exp(sq[3]) for sq in squares]
        
        for it in range(iterations):
            temp = 0.1  # initial temperature
            if step := (2000 - it) / 2000:
                temp = 0.1 * math.exp(-step * 5)
            
            energy, total = evaluate_energy(squares, temp)
            
            if it % 100 == 0 or it == 0 or (time.time() - t0) > 50:
                best_sol = squares[:n]
                best_sum = total_s
                print(f"It: {it}, time={time.time() - t0}, sum={total_s:.4f}")
                if best_sol:
                    break
                    
            attempts = 0
            while attempts < 100 and (time.time() - t0) < 60:
                i = random.randint(0, n - 1)
                xi, yi, ai, si = squares[i]
                new_xi, new_yi, new_ai, new_si = xi + random.uniform(-0.05, 0.05), \
                    yi + random.uniform(-0.05, 0.05), ai + random.uniform(-0.1, 0.1), \
                    math.exp(si + random.uniform(-0.3, 0.3))
                new_squares = squares[:]
                if random.random() < swap_chance:
                    j = random.randint((i + 1) % n, i + 1) if i == n - 1 else random.randint(i + 1, n - 1)
                    new_squares[i], new_squares[j] = new_squares[i], new_squares[j]
                new_squares[i] = (new_xi, new_yi, new_ai, min(new_si, 2.0))
                energy2, total2 = evaluate_energy(new_squares, temp)
                delta = (total2 - total_s) * 1000
                if random.random() < math.exp(min(0, delta / temp)):
                    for k in range(len(squares)):
                        squares[k] = new_squares[k]
                        total_s = total2
                        attempts += 1
                        break
                else:
                    attempts += 1
            best_sol = squares[:n]
            best_sum = total_s
            if best_sol:
                break
        return best_sol[:n], compute_total_sum(best_sol)

    print(f"Starting simulation for n={n}")
    squares = []
    simulation_sum = 0.0
    for trial in range(5):
        t_trial = time.time()
        sol, s = simulate(n, iterations=2500, cooling=0.992, swap_chance=0.02)
        simulation_sum += s
        print(f"Trial {trial + 1}: sum={s:.6f} in {time.time() - t_trial:.2f}s")
        if s > simulation_sum and time.time() - t_trial < 50:
            best_sol = sol
            best_sum = s
        elif sol:
            temp_sol = sol[:]
            best_sol = temp_sol
            best_sum = s
            break
    print(f"Best sum: {best_sum:.6f}")
    print(f"Square count: {len(best_sol)}")
    print(f"Best configuration: {best_sol[:3]}")
    
    if len(best_sol) < n:
        while len(best_sol) < n:
            best_sol.append((0.5, 0.5, 0.0, 0.0))
    print(f"Final result: {best_sol[:3]}")
    return best_sol[:n]


def fill_grid(n, iterations=300):
    t0 = time.time()
    squares = []
    for i in range(int((n ** 0.4))):
        for j in range(int((n ** 0.4))):
            if len(squares) >= n:
                break
            for k in range(i, min(n - len(squares), i + 8)):
                x = ((j + 0.5)) / max(2, i + 1)
                y = ((j + 0.5)) / max(2, i + 1)
                s = min(x, 1 - x, y, 1 - y)
                squares.append((x, y, 0.0, max(math.log(s * 0.7), -2.0)))
            if len(squares) >= n:
                break
    return squares[:n]


if __name__ == '__main__':
    for n in [5, 6, 7, 8, 11, 12, 13, 14, 15, 16, 20]:
        start_time = time.time()
        result = solve(n)
        print(f"n={n}: {','.join([f'{x:.3f},{y:.3f},{z:.3f},{w:.3f}' for x, y, z, w in result])}")
        print(f"Time: {time.time() - start_time:.2f}s")
