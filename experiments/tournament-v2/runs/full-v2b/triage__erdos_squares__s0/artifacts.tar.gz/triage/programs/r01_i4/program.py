import math
import itertools
import random
import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three equal squares in a row? 1x1 can't fit 3x 0.333, but 2x2 grid + zeros works.
        # Better: two large and two small? Actually 3 squares: use a 2x2 grid (4 squares) and remove one, enlarge others symmetrically.
        # Simple starting point: 2x2 grid, side 0.5, remove one, then enlarge neighbors.
        return _optimize_from_grid(n, 2)
    
    # For general n, start from a grid of size k x k where k^2 >= n
    k = math.isqrt(n)
    if k * k < n:
        k += 1
    return _optimize_from_grid(n, k)

def _optimize_from_grid(n, k):
    # Create a k x k grid of equal squares that exactly tile the unit square.
    # Then randomly select n squares to keep (others will be discarded).
    # Then run optimization to enlarge remaining squares while maintaining non-overlap.
    
    side = 1.0 / k
    # Generate all grid positions
    all_positions = []
    for i in range(k):
        for j in range(k):
            cx = (i + 0.5) * side
            cy = (j + 0.5) * side
            all_positions.append((cx, cy))
    
    # If n == k*k, just return the grid
    if n == k * k:
        return [(cx, cy, 0.0, side) for (cx, cy) in all_positions]
    
    # We have more grid cells than needed; we need to drop some and enlarge others.
    # To decide which to drop, we can try multiple random subsets and pick best after optimization.
    # Since time is limited, we try a few random subsets and a heuristic: drop cells that are corner/edge? 
    # Actually, to maximize sum, we want to drop as few as possible and enlarge remaining as much as possible.
    # A good heuristic: drop cells that leave the largest connected region for expansion.
    # We'll try random subsets and run a quick optimization each time.
    
    best_solution = None
    best_sum = -1.0
    
    # Number of random subsets to try: balance time
    trials = min(20, max(1, 200 // n)) if n > 10 else 30
    
    # Precompute indices
    indices = list(range(len(all_positions)))
    
    for trial in range(trials):
        # Randomly select n indices to keep
        if trial == 0:
            # First trial: keep central ones (heuristic: remove corners first)
            # Sort by distance to center, keep n closest
            centers = np.array(all_positions)
            dist = np.sum((centers - 0.5)**2, axis=1)
            keep_indices = np.argsort(dist)[:n]
        else:
            keep_indices = random.sample(indices, n)
        
        keep_set = set(keep_indices)
        # Initial squares: kept ones with side = side, others discarded (side=0, but we won't include them)
        initial_squares = []
        for idx in keep_indices:
            cx, cy = all_positions[idx]
            initial_squares.append((cx, cy, 0.0, side))
        
        # Now optimize side lengths (and maybe positions) to maximize sum of sides,
        # subject to no overlap and staying inside [0,1]x[0,1].
        # We'll keep centers fixed to grid initially and just enlarge sides,
        # but also allow slight center movement to relieve constraints.
        
        opt_squares = _optimize_squares(initial_squares, k, all_positions, keep_indices)
        
        if opt_squares is not None:
            s = sum(s for (_, _, _, s) in opt_squares)
            if s > best_sum:
                best_sum = s
                best_solution = opt_squares
                
    if best_solution is None:
        # fallback
        return _fallback(n)
    return best_solution

def _optimize_squares(initial_squares, k, all_positions, keep_indices):
    # We'll optimize: for each square, variables: cx, cy, side, angle (angle fixed 0 for simplicity)
    # Actually we can allow rotation? Problem says rotated allowed, but grid packing without rotation is optimal for equal squares.
    # We'll keep angle=0 to simplify optimization, since rotation often not needed in dense packings of squares in square.
    
    m = len(initial_squares)
    # Variables: [cx1, cy1, s1, cx2, cy2, s2, ...]
    x0 = []
    for (cx, cy, _, s) in initial_squares:
        x0.extend([cx, cy, s])
    
    # Bounds: centers must stay within [s/2, 1-s/2], side in [0, 1]
    # For optimization we enforce bounds approximately and then project.
    lb = []
    ub = []
    for _ in range(m):
        lb.extend([0.0, 0.0, 0.0])
        ub.extend([1.0, 1.0, 1.0])
    
    bounds = Bounds(lb, ub)
    
    # Objective: negative sum of sides (since we minimize)
    def objective(x):
        s_sum = 0.0
        for i in range(m):
            s_sum += x[3*i + 2]
        return -s_sum
    
    # Constraints: no overlap between any pair i<j
    # For two axis-aligned squares, overlap condition: separation in x >= (s1+s2)/2 or separation in y >= (s1+s2)/2
    # We enforce: for all i<j, constraint: 
    # max( (s_i + s_j)/2 - |cx_i - cx_j|, (s_i + s_j)/2 - |cy_i - cy_j| ) <= 0
    # This is non-smooth, we can use a smooth approximation or handle via penalty.
    # Since scipy SLSQP can handle constraints, we'll define each pair constraint as:
    # We need g(x) <= 0.
    # Overlap condition: if both x and y overlap, then overlapping.
    # We can use: max over two conditions <= 0. But we can define two constraints per pair:
    # (s_i+s_j)/2 - |cx_i - cx_j| <= 0  OR  (s_i+s_j)/2 - |cy_i - cy_j| <= 0
    # Which is not an AND; it's an OR for non-overlap. So standard constraint formulation is tricky.
    # Alternative: penalty method.
    
    # We'll use a penalty approach: add heavy penalty for overlap.
    # Also add penalty for out of bounds (center must be within [s/2, 1-s/2]).
    
    def penalty_overlap_and_bounds(x):
        pen = 0.0
        # Out of bounds penalty
        for i in range(m):
            cx = x[3*i]
            cy = x[3*i+1]
            s = x[3*i+2]
            if s < 0:
                pen += (0 - s)**2 * 1000
                s = 0  # clamp for distance calc
            if cx - s/2 < 0:
                pen += ((s/2 - cx) ** 2) * 1000
            if cx + s/2 > 1:
                pen += ((cx + s/2 - 1) ** 2) * 1000
            if cy - s/2 < 0:
                pen += ((s/2 - cy) ** 2) * 1000
            if cy + s/2 > 1:
                pen += ((cy + s/2 - 1) ** 2) * 1000
        
        # Overlap penalty
        for i in range(m):
            for j in range(i+1, m):
                si = x[3*i+2]
                sj = x[3*j+2]
                if si <= 0 or sj <= 0:
                    continue
                cxi = x[3*i]
                cyi = x[3*i+1]
                cxj = x[3*j]
                cyj = x[3*j+1]
                dx = abs(cxi - cxj)
                dy = abs(cyi - cyj)
                # overlap in x direction?
                overlap_x = (si + sj)/2 - dx
                overlap_y = (si + sj)/2 - dy
                if overlap_x > 0 and overlap_y > 0:
                    # amount of overlap area: (overlap_x)*(overlap_y) is a measure, but we just penalize positive overlap
                    pen += (overlap_x * overlap_y) * 10000  # heavy penalty
        return pen
    
    def total_objective(x):
        return objective(x) + penalty_overlap_and_bounds(x)
    
    # Use SLSQP (gradient-free might be slow) but we can use L-BFGS-B with penalty.
    # However, without gradient, it's slow. We'll try SLSQP with constraints defined as smooth approximations.
    # Alternatively, we can use COBYLA which handles general constraints but we'll just use penalty with L-BFGS-B.
    # Given small dimension (< 30 vars) it might work.
    
    # For m up to maybe 15-20, dimension <= 60, fine.
    
    res = minimize(total_objective, x0, method='L-BFGS-B', bounds=bounds, 
                   options={'maxiter': 2000, 'ftol': 1e-8, 'disp': False})
    
    # Extract solution
    x_opt = res.x
    # Project to feasible (side non-negative, center within bounds given side)
    squares = []
    for i in range(m):
        cx = x_opt[3*i]
        cy = x_opt[3*i+1]
        s = x_opt[3*i+2]
        if s < 0:
            s = 0.0
        # clamp center
        cx = max(s/2, min(1 - s/2, cx))
        cy = max(s/2, min(1 - s/2, cy))
        squares.append((cx, cy, 0.0, s))
    
    return squares

def _fallback(n):
    # If optimization fails, fallback to grid with zeros
    k = math.isqrt(n)
    if k*k < n:
        k += 1
    side = 1.0/k
    squares = [((i+0.5)*side, (j+0.5)*side, 0.0, side) for i in range(k) for j in range(k)]
    squares = squares[:n] + [(0.5,0.5,0.0,0.0)] * (n - len(squares))
    return squares

if __name__ == "__main__":
    # Quick local test
    for n in [5,6,7,8,11,12,13,14,15]:
        sol = solve(n)
        s = sum(s for (_,_,_,s) in sol)
        print(f"n={n}: sum={s}")
