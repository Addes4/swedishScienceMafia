import math
import time
import itertools
import random

# ----------------------------------------------------------------------
#  Geometry helpers
# ----------------------------------------------------------------------

def _corners(cx, cy, a, s):
    """Return the four vertices of a square in counter‑clockwise order."""
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    h = s * 0.5
    return (
        (cx - h * co + h * si, cy - h * si - h * co),
        (cx + h * co + h * si, cy + h * si - h * co),
        (cx + h * co - h * si, cy + h * si + h * co),
        (cx - h * co - h * si, cy - h * si + h * co),
    )


def _sep(p1, p2):
    """True if p1 and p2 are strictly separated by a separating axis."""
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            # project p1
            d = ax * p1[0][0] + ay * p1[0][1]
            lo1 = hi1 = d
            for k in range(1, 4):
                d = ax * p1[k][0] + ay * p1[k][1]
                if d < lo1:
                    lo1 = d
                elif d > hi1:
                    hi1 = d
            # project p2
            d = ax * p2[0][0] + ay * p2[0][1]
            lo2 = hi2 = d
            for k in range(1, 4):
                d = ax * p2[k][0] + ay * p2[k][1]
                if d < lo2:
                    lo2 = d
                elif d > hi2:
                    hi2 = d
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return True
    return False


def _in_unit(cx, cy, a, s, tol=1e-12):
    """True if the square lies completely inside [0,1] x [0,1]."""
    for x, y in _corners(cx, cy, a, s):
        if x < -tol or x > 1.0 + tol or y < -tol or y > 1.0 + tol:
            return False
    return True


# ----------------------------------------------------------------------
#  Candidate placement generator
# ----------------------------------------------------------------------

def _gen_candidates(n, existing_corners, centers, angles, ub):
    """Yield feasible placement tuples (cx, cy, a, s) with s > 0."""
    # Compute maximum side for each (center, angle) given earlier squares.
    # We binary search the largest s that fits inside unit and does not overlap.
    for (cx, cy) in centers:
        for a in angles:
            max_s = ub.get((cx, cy, a), 0.0)
            if max_s <= 1e-9:
                continue
            # Tighten max_s by existing squares
            lo = 0.0
            hi = max_s
            for _ in range(20):
                mid = (lo + hi) * 0.5
                if mid <= 1e-12:
                    lo = mid
                    break
                p1 = _corners(cx, cy, a, mid)
                if not _in_unit(cx, cy, a, mid):
                    hi = mid
                    continue
                ok = True
                for pc in existing_corners:
                    if not _sep(p1, pc):
                        ok = False
                        break
                if ok:
                    lo = mid
                else:
                    hi = mid
            if lo > 1e-9:
                yield (cx, cy, a, lo)


# ----------------------------------------------------------------------
#  Upper bound on future achievable sum (fast, optimistic)
# ----------------------------------------------------------------------

def _max_future_sum(placed_sum, remaining_slots, free_area_factor=1.0):
    """Rough bound: assume the remaining area can be packed with squares of equal side
    equal to the largest square that could still fit. Not too tight, but fast."""
    # We do not use free_area_factor here; a simple additive bound.
    # The best we could do is one large square filling the rest, but that is too weak.
    # Instead we use the fact that maximum sum of k squares inside unit is at most sqrt(k).
    # This is a theoretical bound for axis-aligned, but still an optimistic ceiling.
    if remaining_slots <= 0:
        return placed_sum
    # The theoretical maximum sum of k squares inside a unit square is <= sqrt(k),
    # but we have already placed some. We simply add sqrt(remaining_slots) as optimistic.
    return placed_sum + math.sqrt(remaining_slots)


# ----------------------------------------------------------------------
#  Beam search
# ----------------------------------------------------------------------

def _beam_search(n, centers, angles, ub, beam_width, time_budget, t0):
    """Beam search over sequences of placements.
    Each state is (solutions_list, corners_list, sum_sides).
    """
    # initial empty state
    beam = [([], [], 0.0)]
    # Pre-sort centers by potential (max possible side) for early branching
    center_scores = [max(ub.get((cx, cy, a), 0.0) for a in angles) for (cx, cy) in centers]
    order = sorted(range(len(centers)), key=lambda i: center_scores[i], reverse=True)
    # Build candidates once: for each step we generate new placements.
    finished_solutions = []
    
    for step in range(n):
        if time.time() - t0 > time_budget:
            break
        next_beam = []
        # For each state in beam, generate possible next squares
        for sol, corners, cur_sum in beam:
            if len(sol) >= n:
                finished_solutions.append((sol, cur_sum))
                continue
            remaining = n - len(sol)
            # Upper bound for pruning
            optimistic = _max_future_sum(cur_sum, remaining)
            if optimistic <= max(finished_solutions, key=lambda x: x[1])[1] if finished_solutions else 0.0:
                continue
            # Generate candidates
            candidates = list(_gen_candidates(n - len(sol), corners, centers, angles, ub))
            if not candidates:
                # can't place any more with positive side
                dummy_sol = sol + [(0.5, 0.5, 0.0, 0.0)] * remaining
                finished_solutions.append((dummy_sol, cur_sum))
                continue
            
            # Score candidates: we want to maximize sum, so sort by side descending
            candidates.sort(key=lambda x: x[3], reverse=True)
            # Keep top candidates per state (limited by beam_width and total)
            taken = 0
            for cand in candidates:
                if taken >= beam_width:
                    break
                cx, cy, a, s = cand
                new_sol = sol + [(cx, cy, a, s)]
                new_corners = corners + [_corners(cx, cy, a, s)]
                new_sum = cur_sum + s
                next_beam.append((new_sol, new_corners, new_sum))
                taken += 1
        if not next_beam:
            break
        # Keep best states according to sum and diversity (by bounding box usage)
        # Sort by sum descending, then keep top beam_width
        next_beam.sort(key=lambda x: x[2], reverse=True)
        beam = next_beam[:beam_width]
    
    # collect all finished solutions
    all_solutions = finished_solutions + [(sol, s) for sol, _, s in beam if len(sol) == n]
    if not all_solutions:
        # fallback
        return [(0.5, 0.5, 0.0, 0.0)] * n, 0.0
    
    best = max(all_solutions, key=lambda x: x[1])
    return best[0], best[1]


# ----------------------------------------------------------------------
#  Local refinement via contact‑graph tightening
# ----------------------------------------------------------------------

def _push_apart(sol, max_iter=50, step_size=0.001):
    """Improve a solution by translating/rotating squares so they become larger
    while keeping non‑overlap. Uses simple gradient‑like moves."""
    n = len(sol)
    for _ in range(max_iter):
        improved = False
        for i in range(n):
            cx, cy, a, s = sol[i]
            if s <= 1e-9:
                continue
            # try small random perturbation
            best_s = s
            best_move = (cx, cy, a)
            for _ in range(6):
                ncx = cx + random.uniform(-step_size, step_size)
                ncy = cy + random.uniform(-step_size, step_size)
                na = (a + random.uniform(-0.02, 0.02)) % 1.0
                # ensure inside unit
                if ncx < 0 or ncx > 1.0 or ncy < 0 or ncy > 1.0:
                    continue
                # find max side at new position
                lo = 0.0
                hi = min(2.0 * min(ncx, 1-ncx, ncy, 1-ncy), 1.0)  # rough
                # binary search
                for _ in range(15):
                    mid = (lo + hi) * 0.5
                    p = _corners(ncx, ncy, na, mid)
                    if not _in_unit(ncx, ncy, na, mid):
                        hi = mid
                        continue
                    ok = True
                    for j, other in enumerate(sol):
                        if j == i:
                            continue
                        if not _sep(p, _corners(other[0], other[1], other[2], other[3])):
                            ok = False
                            break
                    if ok:
                        lo = mid
                    else:
                        hi = mid
                if lo > best_s + 1e-9:
                    best_s = lo
                    best_move = (ncx, ncy, na)
            if best_s > s + 1e-9:
                sol[i] = (best_move[0], best_move[1], best_move[2], best_s)
                improved = True
        if not improved:
            break
    return sol


# ----------------------------------------------------------------------
#  Main solver
# ----------------------------------------------------------------------

def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # candidate centres: regular grids of various resolutions
    centers = set()
    for k in range(1, 7):
        for i in range(k):
            for j in range(k):
                centers.add((round((i + 0.5) / k, 8), round((j + 0.5) / k, 8)))
    G = 12
    for i in range(G + 1):
        for j in range(G + 1):
            centers.add((round((i + 0.5) / (G + 1), 8), round((j + 0.5) / (G + 1), 8)))
    centers = sorted(centers, key=lambda p: min(p[0], 1-p[0], p[1], 1-p[1]), reverse=True)
    
    angles = [0.0, 0.25, 0.125, 0.0625, 0.1875]  # add more rotations
    
    # Upper bound for each (centre, angle) inside unit square
    ub = {}
    for (cx, cy) in centers:
        mm = min(cx, 1.0 - cx, cy, 1.0 - cy)
        for a in angles:
            th = a * 2.0 * math.pi
            denom = abs(math.cos(th)) + abs(math.sin(th))
            if denom > 0:
                ub[(cx, cy, a)] = 2.0 * mm / denom
            else:
                ub[(cx, cy, a)] = 0.0
    
    best_sol = None
    best_sum = -1.0
    
    # Baseline: m x m grid
    m = 1
    while m * m < n:
        m += 1
    side = 1.0 / m
    grid_sol = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(m) for j in range(m)][:n]
    grid_sum = sum(q[3] for q in grid_sol)
    if grid_sum > best_sum:
        best_sum = grid_sum
        best_sol = grid_sol
    
    # Beam search with increasing width
    beam_widths = [60, 120, 200]
    for bw in beam_widths:
        if time.time() - t0 > 50:
            break
        rem_time = 55 - (time.time() - t0)
        if rem_time <= 0:
            break
        sol, s = _beam_search(n, centers, angles, ub, bw, rem_time, t0)
        if s > best_sum + 1e-9:
            best_sum = s
            best_sol = sol
    
    # Local refinement on best found so far
    if time.time() - t0 < 55:
        refined = _push_apart(best_sol[:], max_iter=30, step_size=0.005)
        ref_sum = sum(q[3] for q in refined)
        if ref_sum > best_sum + 1e-9:
            best_sum = ref_sum
            best_sol = refined
    
    # Fallback if nothing found (shouldn't happen)
    if best_sol is None:
        best_sol = grid_sol
    
    return best_sol[:n]
