import math
import numpy as np
from scipy.optimize import minimize

def solve(n):
    if n == 0:
        return []
    
    # Initial guess: hexagonal-like grid packing
    initial_s = np.full(n, 1.0)
    initial_angles = np.array([0.25] * n)  # All rotated by 45 degrees initially
    grid_x, grid_y = [], []
    for i in range(n):
        row = i // math.isqrt(n)
        col = i % math.isqrt(n)
        if row % 2 == 0:
            grid_x.append((col + 0.5) / math.isqrt(n))
            grid_y.append((row + 0.5) / math.isqrt(n))
        else:
            grid_x.append((col + 0.5 + 0.25) / math.isqrt(n))
            grid_y.append((row + 0.25) / math.isqrt(n))
    
    initial_vars = np.array(grid_x + grid_y + initial_angles.tolist() + initial_s.tolist())
    
    def objective(vars, n):
        s = vars[4*n:]
        if n == 1:
            return -s[0]
        return -sum(s)
    
    constraints = []
    for i in range(n):
        for j in range(i + 1, n):
            idx_i = 4*i + 0  # x_i
            idx_j = 4*j + 0  # x_j
            idx_i_y = 4*i + 1  # y_i
            idx_j_y = 4*j + 1  # y_j
            idx_i_s = 4*i + 3  # s_i
            idx_j_s = 4*j + 3  # s_j
            def constraint(vars, i, j, idx_i=idx_i, idx_j=idx_j, 
                           idx_i_y=idx_i_y, idx_j_y=idx_j_y,
                           idx_i_s=idx_i_s, idx_j_s=idx_j_s):
                dx = vars[idx_i] - vars[idx_j]
                dy = vars[idx_i_y] - vars[idx_j_y]
                return max(0, (dx*dx + dy*dy - ( (vars[idx_i_s] + vars[idx_j_s])/2 )**2 ))
            constraints.append({'type': 'ineq', 'fun': constraint, 
                                'args': (vars, i, j, idx_i, idx_j, idx_i_y, idx_j_y, idx_i_s, idx_j_s)})
    
    bounds = []
    for i in range(n*4):
        bounds.append((0, 1) if i % 4 < 3 else (0, 1))  # x, y, angle, s
    
    result = minimize(objective, initial_vars, method='SLSQP', bounds=bounds, constraints=constraints, 
                     options={'maxiter': 1000, 'ftol': 1e-9})
    
    x = result.x[4*n//4:1, ::4]
    y = result.x[4*n//2:1, ::2]
    angles = result.x[4*n//3:2, 1]
    s = result.x[4*n//4:5, 5]
    result.x.reshape(-1, 4)
    return tuple(zip(result.x[::4], result.x[1::4], result.x[2::4], result.x[3::4][:n]))

