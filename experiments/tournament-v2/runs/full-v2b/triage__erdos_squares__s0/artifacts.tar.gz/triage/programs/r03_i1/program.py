import math
import numpy as np
from scipy.optimize import minimize

def _square_corners(cx, cy, angle, side):
    rad = angle * 2 * math.pi
    cos_a, sin_a = math.cos(rad), math.sin(rad)
    half = side * 0.5
    corners = np.array([
        [cx + half * (cos_a - sin_a), cy + half * (sin_a + cos_a)],
        [cx + half * (cos_a + sin_a), cy + half * (-sin_a + cos_a)],
        [cx + half * (-cos_a + sin_a), cy + half * (-sin_a - cos_a)],
        [cx + half * (-cos_a - sin_a), cy + half * (sin_a + cos_a)]
    ])
    return corners

def _min_overlap(p1, p2):
    for axis_idx in range(4):
        ax = p2[1] - p2[2] if axis_idx < 2 else p2[0] - p2[3]
        ay = p2[0] - p2[1] if axis_idx < 2 else p2[3] - p2[0]
        proj1 = np.array([np.dot(p1[i], np.array([ax, ay])) for i in range(4)])
        proj2 = np.array([np.dot(p2[i], np.array([ax, ay])) for i in range(4)])
        lo1, hi1 = proj1.min(), proj1.max()
        lo2, hi2 = proj2.min(), proj2.max()
        if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
            delta = hi1 - lo2 if hi1 > lo2 else hi2 - lo1
            if delta < 1e-10:
                return 0.0
            return delta
    return 0.0

def _penalty_term(corners, squeeze_factor=1e4):
    n = len(corners)
    if n <= 1:
        return 0.0
    penalty = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            dist = _min_overlap(corners[i], corners[j])
            if dist < 1e-6:
                penalty += squeeze_factor * (1e-6 - dist) ** 2
            else:
                penalty += 3.0 * squeeze_factor * -dist + squeeze_factor * math.log(dist + 1e-12)
    return penalty

def _total_length(vars):
    return sum(vars[3 * i + 2] for i in range(len(vars) // 3))

def _box_constraint(vars):
    sizes = vars[2::3]
    offsets = [(i + 0.5) * 1.0 / len(sizes) for i in range(len(sizes))]
    out = []
    for cx, cy, s in zip(vars[::2], vars[1::2], sizes):
        scale = max(abs(math.cos(vars[2 * (len(vars)//2 + 0)]) or 1e-9), abs(math.sin(vars[2 * (len(vars)//2 + 0)]) or 1e-9))
        margin = 1.0 - scale * s
        out.append([-margin, margin])
    return out

def _overlap_consistent(vars):
    n = len(vars) // 3
    corners_list = []
    for i in range(n):
        cx, cy, s, a = vars[3*i], vars[3*i+1], vars[3*i+2], vars[3*i+3]
        corners = _square_corners(cx, cy, a, s)
        corners_list.append(corners)
    penalty = 0.0
    for i in range(n):
        for j in range(i+1, n):
            d = _min_overlap(corners_list[i], corners_list[j])
            if d < 1e-6:
                penalty += 1e4 * (1e-6 - d) ** 2
            else:
                penalty += 3.0 * -d * 1e2
    return penalty

def _dist_from_centers(vars, targets):
    dist = 0.0
    for i in range(len(vars) // 3):
        cx, cy = vars[3*i], vars[3*i+1]
        rx, ry = targets[3*i], targets[3*i+1]
        dist += (cx - rx) ** 2 + (cy - ry) ** 2
    return 0.0

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    bounds = 1.0 / math.ceil(math.sqrt(n))
    x = np.array([0.5, 0.5, bounds, 0.0] * n)
    opt = minimize(lambda v: -_total_length(v), x, method='SLSQP', bounds=[(0, 1) for _ in range(3*n)], 
                   options={'maxiter': 300, 'ftol': 1e-12, 'disp': False})
    return opt.x.tolist()
