import math
import time
import itertools


def _corners(cx, cy, a, s):
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    h = s * 0.5
    return (
        (cx - h * co + h * si, cy - h * si - h * co),
        (cx + h * co + h * si, cy + h * si - h * co),
        (cx + h * co - h * si, cy + h * si + h * co),
        (cx - h * co - h * si, cy - h * si + h * co),
    )


def _sep(p1, p2):
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            # project p1
            d = ax * p1[0][0] + ay * p1[0][1]
            lo1 = hi1 = d
            for k in range(1, 4):
                d = ax * p1[k][0] + ay * p1[k][1]
                if d < lo1:
                    lo1 = d
                elif d > hi1:
                    hi1 = d
            # project p2
            d = ax * p2[0][0] + ay * p2[0][1]
            lo2 = hi2 = d
            for k in range(1, 4):
                d = ax * p2[k][0] + ay * p2[k][1]
                if d < lo2:
                    lo2 = d
                elif d > hi2:
                    hi2 = d
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return True
    return False


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # ----------  candidate placement grid  ----------
    # finer grid + more angles for better packing
    G = 15
    centers = set()
    for i in range(G + 1):
        for j in range(G + 1):
            centers.add((round(i / G, 8), round(j / G, 8)))
    # also include grid points from kxk partitions
    for k in range(2, 9):
        for i in range(k):
            for j in range(k):
                centers.add((round((i + 0.5) / k, 8), round((j + 0.5) / k, 8)))
    centers = sorted(centers)
    # rotation candidates (fraction of full turn)
    angles = (0.0, 0.125, 0.25, 0.0625, 0.1875, 0.3125, 0.375)
    # precompute upper bound for each (cx,cy,a)
    ub = {}
    for (cx, cy) in centers:
        mm = min(cx, 1.0 - cx, cy, 1.0 - cy)
        for a in angles:
            th = a * 2.0 * math.pi
            cc = abs(math.cos(th)) + abs(math.sin(th))
            if cc > 0:
                ub[(cx, cy, a)] = 2.0 * mm / cc
            else:
                ub[(cx, cy, a)] = 0.0

    def best_next(placed_corners, floor):
        """return (best_side, (cx,cy,a)) or (floor, None)"""
        bs = floor
        bc = None
        # iterate over all candidate placements
        for (cx, cy) in centers:
            for a in angles:
                u = ub[(cx, cy, a)]
                if u <= bs + 1e-12:
                    continue
                lo = bs
                hi = u
                # binary search for largest feasible side
                for _ in range(12):
                    mid = (lo + hi) * 0.5
                    p1 = _corners(cx, cy, a, mid)
                    good = True
                    for pc in placed_corners:
                        if not _sep(p1, pc):
                            good = False
                            break
                    if good:
                        lo = mid
                    else:
                        hi = mid
                if lo > bs + 1e-9:
                    bs = lo
                    bc = (cx, cy, a)
        return bs, bc

    def greedy_fill(sol, budget):
        """greedily complete solution until n squares or timeout"""
        pc = [_corners(q[0], q[1], q[2], q[3]) for q in sol]
        while len(sol) < n:
            if time.time() - t0 > budget:
                break
            s, c = best_next(pc, 0.0)
            if c is None or s <= 1e-9:
                q = (0.5, 0.5, 0.0, 0.0)
            else:
                q = (c[0], c[1], c[2], s)
            sol.append(q)
            pc.append(_corners(q[0], q[1], q[2], q[3]))
        while len(sol) < n:
            sol.append((0.5, 0.5, 0.0, 0.0))
        return sol

    best_sol = None
    best_sum = -1.0

    # ----------  deterministic baselines  ----------
    # 1) square grid of m x m
    for m in range(1, n + 2):
        if m * m >= n:
            s = 1.0 / m
            cand = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                    for i in range(m) for j in range(m)][:n]
            v = sum(q[3] for q in cand)
            if v > best_sum:
                best_sum = v
                best_sol = cand

    # 2) k x k grid of large squares + greedy fill rest
    for k in range(1, n + 1):
        if k * k > n:
            break
        if time.time() - t0 > 55:
            break
        gs = 1.0 / k
        sol = [((i + 0.5) * gs, (j + 0.5) * gs, 0.0, gs)
               for i in range(k) for j in range(k)]
        sol = greedy_fill(sol, 57)
        v = sum(q[3] for q in sol)
        if v > best_sum:
            best_sum = v
            best_sol = sol[:]

    # 3) greedy from scratch
    if time.time() - t0 < 55:
        sol = greedy_fill([], 58)
        v = sum(q[3] for q in sol)
        if v > best_sum:
            best_sum = v
            best_sol = sol[:]

    # ----------  local optimisation: try removing one square and re-greedy  ----------
    if n >= 5 and time.time() - t0 < 45:
        # try removing each square of the current best and re-filling
        improved = True
        while improved and time.time() - t0 < 50:
            improved = False
            for remove_idx in range(len(best_sol)):
                if time.time() - t0 > 55:
                    break
                cand = best_sol[:remove_idx] + best_sol[remove_idx+1:]
                # fill missing + remaining slots
                budget = max(5, 58 - (time.time() - t0))
                tmp = greedy_fill(cand, budget)
                tmp_sum = sum(q[3] for q in tmp)
                if tmp_sum > best_sum + 1e-9:
                    best_sum = tmp_sum
                    best_sol = tmp[:]
                    improved = True
                    # restart scanning from the beginning
                    break

    # 4) small brute-force swap: try different rotations for largest squares
    if n <= 20 and time.time() - t0 < 30:
        # For the biggest few squares, try all angle combinations from a small set
        main_angles = (0.0, 0.125, 0.25)
        # take up to 4 largest squares from best_sol (by side)
        idx_sorted = sorted(range(len(best_sol)), key=lambda i: -best_sol[i][3])
        top_cnt = min(4, len(best_sol))
        top_idx = idx_sorted[:top_cnt]
        # precompute replacement squares with different angles
        for comb in itertools.product(main_angles, repeat=top_cnt):
            if time.time() - t0 > 55:
                break
            cand = list(best_sol)
            ok = True
            for pos, a in zip(top_idx, comb):
                cx, cy, _, s = best_sol[pos]
                # keep same centre and side, change angle
                cand[pos] = (cx, cy, a, s)
            # check feasibility of this configuration
            pc = []
            feasible = True
            for q in cand:
                p = _corners(*q)
                for prev in pc:
                    if not _sep(p, prev):
                        feasible = False
                        break
                if not feasible:
                    break
                pc.append(p)
            if feasible:
                v = sum(q[3] for q in cand)
                if v > best_sum:
                    # try to fill if some squares became zero
                    # (but here sides are unchanged, so sum is same, just for safety)
                    best_sum = v
                    best_sol = cand[:]

    return best_sol[:n]
