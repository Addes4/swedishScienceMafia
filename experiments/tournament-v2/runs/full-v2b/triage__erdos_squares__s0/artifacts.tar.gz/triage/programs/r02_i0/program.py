import math
import time
import random


def _corners(cx, cy, a, s):
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    h = s * 0.5
    return (
        (cx - h * co + h * si, cy - h * si - h * co),
        (cx + h * co + h * si, cy + h * si - h * co),
        (cx + h * co - h * si, cy + h * si + h * co),
        (cx - h * co - h * si, cy - h * si + h * co),
    )


def _sep(p1, p2):
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            d = ax * p1[0][0] + ay * p1[0][1]
            lo1 = hi1 = d
            for k in range(1, 4):
                d = ax * p1[k][0] + ay * p1[k][1]
                if d < lo1:
                    lo1 = d
                elif d > hi1:
                    hi1 = d
            d = ax * p2[0][0] + ay * p2[0][1]
            lo2 = hi2 = d
            for k in range(1, 4):
                d = ax * p2[k][0] + ay * p2[k][1]
                if d < lo2:
                    lo2 = d
                elif d > hi2:
                    hi2 = d
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return True
    return False


def _inside(cx, cy, a, s):
    h = s * 0.5
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    ex = h * (abs(co) + abs(si))
    return cx - ex >= -1e-12 and cx + ex <= 1 + 1e-12 and cy - ex >= -1e-12 and cy + ex <= 1 + 1e-12


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    m = 1
    while m * m < n:
        m += 1
    side = 1.0 / m
    base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(m) for j in range(m)][:n]
    best_sol = base
    best_sum = sum(q[3] for q in best_sol)

    # candidate centres, dense
    centers = set()
    G = 12
    for i in range(G + 1):
        for j in range(G + 1):
            centers.add((round((i + 0.5) / (G + 1), 7), round((j + 0.5) / (G + 1), 7)))
    for k in range(1, 8):
        for i in range(k):
            for j in range(k):
                centers.add((round((i + 0.5) / k, 7), round((j + 0.5) / k, 7)))
    # grid-aligned boundaries (edges) so squares can touch walls
    for k in range(1, 9):
        for i in range(k + 1):
            for j in range(k + 1):
                centers.add((round(i / k, 7), round(j / k, 7)))
    centers = sorted(centers)
    angles = (0.0, 0.25, 0.125, 0.375, 0.0625)

    # Precompute for each center max side for each angle (must fit in unit square)
    cand = []
    for (cx, cy) in centers:
        for a in angles:
            th = a * 2.0 * math.pi
            cc = abs(math.cos(th)) + abs(math.sin(th))
            mm = min(cx, 1.0 - cx, cy, 1.0 - cy)
            u = 2.0 * mm / cc if cc > 0 else 0.0
            if u > 1e-6:
                cand.append((cx, cy, a, u))

    # Precompute corners for small candidate squares on demand later.
    def rect_key(q):
        return q

    # maximum-weight independent set via greedy (weight = side) with local search
    # build conflict by trying to expand each candidate to some side; instead we
    # do a greedy placement: pick largest feasible square among candidates.

    def greedy_weighted(weights, order, budget_cap, forbidden=None):
        # weights dict index -> value
        chosen = []
        chosen_polys = []
        for idx in order:
            if time.time() - t0 > budget_cap:
                break
            cx, cy, a, umax = cand[idx]
            w = weights[idx]
            if w <= 1e-9:
                continue
            # find max feasible side up to umax (binary search)
            lo = 0.0
            hi = umax
            # quick reject: if even 0-size conflicts? conflicts are size dependent
            # need side > 0; test with current chosen polys
            # first check if any tiny square fits: use bisection
            feasible_lo = 0.0
            # check max
            p_max = _corners(cx, cy, a, umax)
            ok = True
            for pc in chosen_polys:
                if not _sep(p_max, pc):
                    ok = False
                    break
            if ok:
                s = umax
            else:
                l = 0.0
                h = umax
                for _ in range(14):
                    mid = (l + h) * 0.5
                    if mid <= 1e-9:
                        l = mid
                        continue
                    p1 = _corners(cx, cy, a, mid)
                    good = True
                    for pc in chosen_polys:
                        if not _sep(p1, pc):
                            good = False
                            break
                    if good:
                        l = mid
                    else:
                        h = mid
                s = l
            if s <= 1e-7:
                continue
            q = (cx, cy, a, s)
            chosen.append(q)
            chosen_polys.append(_corners(cx, cy, a, s))
            if len(chosen) >= n:
                break
        return chosen

    # Strategy 1: pure greedy largest-first from empty
    def try_strategy(budget_cap):
        nonlocal best_sum, best_sol
        # weight candidates by umax, then order by umax desc, random tiebreak
        order = list(range(len(cand)))
        # weight by umax primarily
        order.sort(key=lambda i: -cand[i][3])
        sol = greedy_weighted({i: cand[i][3] for i in range(len(cand))}, order, budget_cap)
        # If fewer than n, add zero squares
        while len(sol) < n:
            sol.append((0.5, 0.5, 0.0, 0.0))
        v = sum(q[3] for q in sol)
        if v > best_sum:
            best_sum = v
            best_sol = sol
        return v

    # Strategy 2: grid seeds + fill
    def grid_seed(k):
        gs = 1.0 / k
        return [((i + 0.5) * gs, (j + 0.5) * gs, 0.0, gs)
                for i in range(k) for j in range(k)]

    def fill_from(seed, budget_cap, seed_polys=None):
        sol = list(seed)
        pc = [_corners(q[0], q[1], q[2], q[3]) for q in sol]
        # candidate order by umax desc
        order = list(range(len(cand)))
        order.sort(key=lambda i: -cand[i][3])
        while len(sol) < n:
            if time.time() - t0 > budget_cap:
                break
            bests = 0.0
            bestq = None
            for idx in order:
                cx, cy, a, umax = cand[idx]
                if umax <= bests:
                    break
                # find max feasible
                # first try umax
                l = 0.0
                h = umax
                s = 0.0
                # test if umax feasible
                p1 = _corners(cx, cy, a, umax)
                ok = True
                for p in pc:
                    if not _sep(p1, p):
                        ok = False
                        break
                if ok:
                    s = umax
                else:
                    for _ in range(12):
                        mid = (l + h) * 0.5
                        if mid <= 1e-9:
                            l = mid
                            continue
                        p1 = _corners(cx, cy, a, mid)
                        good = True
                        for p in pc:
                            if not _sep(p1, p):
                                good = False
                                break
                        if good:
                            l = mid
                        else:
                            h = mid
                    s = l
                if s > bests + 1e-9:
                    bests = s
                    bestq = (cx, cy, a, s)
            if bestq is None or bests <= 1e-9:
                sol.append((0.5, 0.5, 0.0, 0.0))
                pc.append(_corners(0.5, 0.5, 0.0, 0.0))
            else:
                sol.append(bestq)
                pc.append(_corners(bestq[0], bestq[1], bestq[2], bestq[3]))
        while len(sol) < n:
            sol.append((0.5, 0.5, 0.0, 0.0))
        return sol

    # baseline grids
    for mm in range(1, n + 2):
        if mm * mm >= n:
            s = 1.0 / mm
            c = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(mm) for j in range(mm)][:n]
            v = sum(q[3] for q in c)
            if v > best_sum:
                best_sum = v
                best_sol = c

    # greedy from empty
    if time.time() - t0 < 20:
        try_strategy(25)

    # seeded strategies
    for k in range(1, n + 1):
        if k * k > n:
            break
        if time.time() - t0 > 40:
            break
        sol = fill_from(grid_seed(k), 45)
        v = sum(q[3] for q in sol)
        if v > best_sum:
            best_sum = v
            best_sol = sol

    # local search / perturbation: try random restart with slight jitter in ordering
    rng = random.Random(12345)
    while time.time() - t0 < 52:
        order = list(range(len(cand)))
        order.sort(key=lambda i: (-cand[i][3] + rng.uniform(-0.05, 0.05)))
        sol = greedy_weighted({i: cand[i][3] for i in range(len(cand))}, order, 54)
        while len(sol) < n:
            sol.append((0.5, 0.5, 0.0, 0.0))
        v = sum(q[3] for q in sol)
        if v > best_sum:
            best_sum = v
            best_sol = sol
        # also seeded
        k = rng.randint(1, max(1, int(math.sqrt(n)) + 2))
        sol = fill_from(grid_seed(k), 55)
        v = sum(q[3] for q in sol)
        if v > best_sum:
            best_sum = v
            best_sol = sol

    return best_sol[:n]
