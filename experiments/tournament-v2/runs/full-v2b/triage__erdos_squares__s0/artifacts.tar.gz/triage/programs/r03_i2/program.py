import math
import time
from functools import lru_cache


def _corners(cx, cy, a, s):
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    h = s * 0.5
    return (
        (cx - h * co + h * si, cy - h * si - h * co),
        (cx + h * co + h * si, cy + h * si - h * co),
        (cx + h * co - h * si, cy + h * si + h * co),
        (cx - h * co - h * si, cy - h * si + h * co),
    )


def _sep(p1, p2):
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            d = ax * p1[0][0] + ay * p1[0][1]
            lo1 = hi1 = d
            for k in range(1, 4):
                d = ax * p1[k][0] + ay * p1[k][1]
                if d < lo1:
                    lo1 = d
                elif d > hi1:
                    hi1 = d
            d = ax * p2[0][0] + ay * p2[0][1]
            lo2 = hi2 = d
            for k in range(1, 4):
                d = ax * p2[k][0] + ay * p2[k][1]
                if d < lo2:
                    lo2 = d
                elif d > hi2:
                    hi2 = d
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return True
    return False


def _fit_rect_in_rect(rw, rh, x, y, w, h, a):
    """Return max square side placed at (x,y) rot a lying inside rect [rw,rh]
    with given sub-rect (w,h) -- unused helper placeholder."""
    pass


def _solve_rect(rw, rh, k, t0, budget, angles, eps=1e-9):
    """
    Place k squares inside rectangle [0,rw] x [0,rh] maximizing sum of sides.
    Uses a corner/edge candidate placement greedy with rotation angles.
    Returns list of (cx, cy, ang, side).
    """
    # candidate anchor points inside the rectangle (x,y of a corner of the square)
    anchors = []
    for i in range(k + 2):
        anchors.append((rw * i / (k + 1), 0.0))
        anchors.append((rw * i / (k + 1), rh))
    for j in range(k + 2):
        anchors.append((0.0, rh * j / (k + 1)))
        anchors.append((rw, rh * j / (k + 1)))
    anchors.append((0.0, 0.0))
    anchors.append((rw, 0.0))
    anchors.append((0.0, rh))
    anchors.append((rw, rh))

    placed = []  # (cx,cy,ang,side)
    pcs = []     # corner tuples

    def max_side_at(cx, cy, a):
        # approximate: distance to each wall considering rotation via half-width extents
        th = a * 2.0 * math.pi
        co = abs(math.cos(th))
        si = abs(math.sin(th))
        hw = 0.5 * (co + si)  # half-width factor for side s
        # need s*hw <= min(cx, rw-cx, cy, rh-cy) roughly for axis-aligned bounding box;
        # but rotated square corners may poke out; use corner-based exact via bisection
        ux = min(cx, rw - cx)
        uy = min(cy, rh - cy)
        # bounding-box bound
        if hw < 1e-12:
            return 0.0
        hi = min(ux / hw, uy / hw) * 2.0
        # refine: check all four corners inside rect
        lo = 0.0
        for _ in range(20):
            mid = 0.5 * (lo + hi)
            cs = _corners(cx, cy, a, mid)
            ok = True
            for (px, py) in cs:
                if px < -eps or px > rw + eps or py < -eps or py > rh + eps:
                    ok = False
                    break
            if ok:
                lo = mid
            else:
                hi = mid
        return lo

    def max_side_at_avoid(cx, cy, a):
        hi = max_side_at(cx, cy, a)
        if hi <= 0.0:
            return 0.0
        # ensure not overlapping placed
        lo = 0.0
        for _ in range(18):
            mid = 0.5 * (lo + hi)
            p1 = _corners(cx, cy, a, mid)
            good = True
            for pc in pcs:
                if not _sep(p1, pc):
                    good = False
                    break
            if good:
                lo = mid
            else:
                hi = mid
        return lo

    # greedy fill: at each step try to place one square; pick largest possible
    while len(placed) < k:
        if time.time() - t0 > budget:
            break
        bs = 0.0
        bc = None
        # scan candidates: anchors + placed square corners offsets
        cands = list(anchors)
        for (cx, cy, a, s) in placed:
            cs = _corners(cx, cy, a, s)
            for (px, py) in cs:
                cands.append((px, py))
                cands.append((px - 0.0, py - 0.0))
        for (ax, ay) in cands:
            for a in angles:
                th = a * 2.0 * math.pi
                co = math.cos(th)
                si = math.sin(th)
                # square with one corner at anchor: centre = anchor + 0.5*(co - si), ...
                # try placing with this anchor as lower-left corner-ish
                # centre offset so that corner0 is at anchor
                h = 1.0
                # we iterate side via bisection; approximate centre for given side
                # use a coarse search over side via the max_side function centred appropriately
                # Instead: consider centre positions around anchor
                for sign in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
                    cx = ax + sign[0] * 0.25 * (abs(co) + abs(si))
                    cy = ay + sign[1] * 0.25 * (abs(co) + abs(si))
                    if cx < 0 or cx > rw or cy < 0 or cy > rh:
                        continue
                    s = max_side_at_avoid(cx, cy, a)
                    if s > bs + 1e-9:
                        bs = s
                        bc = (cx, cy, a, s)
        if bc is None or bs <= 1e-9:
            break
        placed.append((bc[0], bc[1], bc[2], bc[3]))
        pcs.append(_corners(bc[0], bc[1], bc[2], bc[3]))

    while len(placed) < k:
        placed.append((rw * 0.5, rh * 0.5, 0.0, 0.0))
    return placed


def _grid_decomp(rw, rh, nx, ny):
    """Return list of rectangles (x,y,w,h) tiling [0,rw]x[0,rh] with nx*ny cells."""
    out = []
    for i in range(nx):
        for j in range(ny):
            out.append((rw * i / nx, rh * j / ny, rw / nx, rh / ny))
    return out


def _guillotine_decomps(rw, rh, n, depth, maxdepth, out, prefix, t0, budget):
    """Generate guillotine decompositions into up to n rectangles."""
    if time.time() - t0 > budget or depth > maxdepth:
        return
    if len(prefix) >= n:
        out.append(list(prefix))
        return
    # base rectangle current
    if not prefix:
        cur = (0.0, 0.0, rw, rh)
    else:
        cur = prefix[-1]
    x, y, w, h = cur
    if w <= 1e-9 or h <= 1e-9:
        out.append(list(prefix))
        return
    # cut vertically
    for frac in (0.5, 1.0 / 3, 2.0 / 3, 0.25, 0.75):
        w1 = w * frac
        w2 = w - w1
        if w1 <= 1e-9 or w2 <= 1e-9:
            continue
        newp = list(prefix)
        newp[-1] = (x, y, w1, h)
        newp.append((x + w1, y, w2, h))
        out.append(list(newp))
        _guillotine_decomps(rw, rh, n, depth + 1, maxdepth, out, newp, t0, budget)
    # cut horizontally
    for frac in (0.5, 1.0 / 3, 2.0 / 3, 0.25, 0.75):
        h1 = h * frac
        h2 = h - h1
        if h1 <= 1e-9 or h2 <= 1e-9:
            continue
        newp = list(prefix)
        newp[-1] = (x, y, w, h1)
        newp.append((x, y + h1, w, h2))
        out.append(list(newp))
        _guillotine_decomps(rw, rh, n, depth + 1, maxdepth, out, newp, t0, budget)


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # baseline grid
    m = 1
    while m * m < n:
        m += 1
    side = 1.0 / m
    best_sol = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(m) for j in range(m)][:n]
    best_sum = sum(q[3] for q in best_sol)

    angles = (0.0, 0.25, 0.125, 0.0625, 0.375, 0.1875)

    # Strategy A: uniform grid of larger squares + greedy fill in remainder
    # (kept from previous best for safety)
    def _corners_local(cx, cy, a, s):
        return _corners(cx, cy, a, s)

    centers = set()
    for k in range(1, 8):
        for i in range(k):
            for j in range(k):
                centers.add((round((i + 0.5) / k, 6), round((j + 0.5) / k, 6)))
    G = 8
    for i in range(G + 1):
        for j in range(G + 1):
            centers.add((round((i + 0.5) / (G + 1), 6), round((j + 0.5) / (G + 1), 6)))
    centers = sorted(centers)
    angs = (0.0, 0.25, 0.125)

    ub = {}
    for (cx, cy) in centers:
        mm = min(cx, 1.0 - cx, cy, 1.0 - cy)
        for a in angs:
            th = a * 2.0 * math.pi
            cc = abs(math.cos(th)) + abs(math.sin(th))
            ub[(cx, cy, a)] = 2.0 * mm / cc if cc > 0 else 0.0

    def best_next(placed_corners, floor):
        bs = floor
        bc = None
        for (cx, cy) in centers:
            for a in angs:
                u = ub[(cx, cy, a)]
                if u <= bs:
                    continue
                lo = bs
                hi = u
                for _ in range(11):
                    mid = (lo + hi) * 0.5
                    p1 = _corners(cx, cy, a, mid)
                    good = True
                    for pc in placed_corners:
                        if not _sep(p1, pc):
                            good = False
                            break
                    if good:
                        lo = mid
                    else:
                        hi = mid
                if lo > bs + 1e-9:
                    bs = lo
                    bc = (cx, cy, a)
        return bs, bc

    def fill(sol, budget):
        pc = [_corners(q[0], q[1], q[2], q[3]) for q in sol]
        while len(sol) < n:
            if time.time() - t0 > budget:
                break
            s, c = best_next(pc, 0.0)
            if c is None or s <= 1e-9:
                q = (0.5, 0.5, 0.0, 0.0)
            else:
                q = (c[0], c[1], c[2], s)
            sol.append(q)
            pc.append(_corners(q[0], q[1], q[2], q[3]))
        while len(sol) < n:
            sol.append((0.5, 0.5, 0.0, 0.0))
        return sol

    for mm in range(1, n + 2):
        if mm * mm >= n:
            s = 1.0 / mm
            cand = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                    for i in range(mm) for j in range(mm)][:n]
            v = sum(q[3] for q in cand)
            if v > best_sum:
                best_sum = v
                best_sol = cand

    for k in range(1, n + 1):
        if k * k > n:
            break
        if time.time() - t0 > 40:
            break
        gs = 1.0 / k
        sol = [((i + 0.5) * gs, (j + 0.5) * gs, 0.0, gs)
               for i in range(k) for j in range(k)]
        sol = fill(sol, 44)
        v = sum(q[3] for q in sol)
        if v > best_sum:
            best_sum = v
            best_sol = sol

    if time.time() - t0 < 44:
        sol = fill([], 48)
        v = sum(q[3] for q in sol)
        if v > best_sum:
            best_sum = v
            best_sol = sol

    # Strategy B: cutting-stock / guillotine decomposition + per-rect packing
    if n <= 30 and time.time() - t0 < 50:
        decomps = []
        # seed structured decompositions
        for nx in range(1, n + 1):
            for ny in range(1, n + 1):
                if nx * ny <= n and nx * ny >= max(1, n - 3):
                    decomps.append(_grid_decomp(1.0, 1.0, nx, ny))
        _guillotine_decomps(1.0, 1.0, n, 0, 3, decomps, [], t0, 51)

        # beam search over assignments of squares to rectangles
        seen = set()
        uniq = []
        for d in decomps:
            key = tuple(sorted((round(r[0], 4), round(r[1], 4), round(r[2], 4), round(r[3], 4))
                               for r in d))
            if key not in seen:
                seen.add(key)
                uniq.append(d)

        uniq = uniq[:400]
        for di, rects in enumerate(uniq):
            if time.time() - t0 > 51.5:
                break
            R = len(rects)
            if R == 0 or R > n:
                continue
            # distribute squares among rectangles (each >= 1 for used rects)
            # simple: assign counts proportional to area, then greedy refine
            areas = [r[2] * r[3] for r in rects]
            tot = sum(areas)
            counts = [1] * R
            rem = n - R
            if rem < 0:
                continue
            for _ in range(rem):
                # add to rect with largest area/count ratio (approx)
                idx = max(range(R), key=lambda i: areas[i] / counts[i])
                counts[idx] += 1
            # pack each rect
            sol_parts = []
            ok = True
            for i, (x, y, w, h) in enumerate(rects):
                k = counts[i]
                if k == 0:
                    continue
                sub = _solve_rect(w, h, k, t0, 51.5, angles)
                for (cx, cy, a, s) in sub:
                    sol_parts.append((x + cx, y + cy, a, s))
            if len(sol_parts) < n:
                continue
            sol_parts = sol_parts[:n]
            # verify global non-overlap
            valid = True
            pcs = [_corners(q[0], q[1], q[2], q[3]) for q in sol_parts]
            for i in range(len(pcs)):
                for j in range(i + 1, len(pcs)):
                    if not _sep(pcs[i], pcs[j]):
                        valid = False
                        break
                if not valid:
                    break
            if not valid:
                # fallback: keep but rebuild greedily inside whole square
                continue
            v = sum(q[3] for q in sol_parts)
            if v > best_sum:
                best_sum = v
                best_sol = sol_parts

    return best_sol[:n]
