import math
import random
import time


def _corners(cx, cy, a, s):
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    h = s * 0.5
    return (
        (cx - h * co + h * si, cy - h * si - h * co),
        (cx + h * co + h * si, cy + h * si - h * co),
        (cx + h * co - h * si, cy + h * si + h * co),
        (cx - h * co - h * si, cy - h * si + h * co),
    )


def _sep(p1, p2):
    """True if p1 and p2 are separated (non-overlapping interiors OK)."""
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            d = ax * p1[0][0] + ay * p1[0][1]
            lo1 = hi1 = d
            for k in range(1, 4):
                d = ax * p1[k][0] + ay * p1[k][1]
                if d < lo1:
                    lo1 = d
                elif d > hi1:
                    hi1 = d
            d = ax * p2[0][0] + ay * p2[0][1]
            lo2 = hi2 = d
            for k in range(1, 4):
                d = ax * p2[k][0] + ay * p2[k][1]
                if d < lo2:
                    lo2 = d
                elif d > hi2:
                    hi2 = d
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return True
    return False


def _overlap_area(p1, p2):
    """Estimate overlap area via SAT-based penetration. Returns a penalty >= 0."""
    # Use separating axis theorem: find min penetration along all axes
    axes = []
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            n = math.hypot(ax, ay)
            if n > 1e-15:
                axes.append((ax / n, ay / n))
    best = None
    for (ax, ay) in axes:
        d = ax * p1[0][0] + ay * p1[0][1]
        lo1 = hi1 = d
        for k in range(1, 4):
            d = ax * p1[k][0] + ay * p1[k][1]
            if d < lo1: lo1 = d
            elif d > hi1: hi1 = d
        d = ax * p2[0][0] + ay * p2[0][1]
        lo2 = hi2 = d
        for k in range(1, 4):
            d = ax * p2[k][0] + ay * p2[k][1]
            if d < lo2: lo2 = d
            elif d > hi2: hi2 = d
        # gap on this axis
        if hi1 <= lo2:
            return 0.0
        if hi2 <= lo1:
            return 0.0
        pen = min(hi1 - lo2, hi2 - lo1)
        if best is None or pen < best:
            best = pen
    return best if best is not None else 0.0


def _outside_penalty(cx, cy, a, s):
    """Penalty for square going outside unit box."""
    cs = _corners(cx, cy, a, s)
    pen = 0.0
    for (x, y) in cs:
        if x < 0.0:
            pen += -x
        if x > 1.0:
            pen += x - 1.0
        if y < 0.0:
            pen += -y
        if y > 1.0:
            pen += y - 1.0
    return pen


def _energy(sol):
    """Total penalty energy (overlap + outside). Total length is separate objective."""
    total_pen = 0.0
    corners = [_corners(q[0], q[1], q[2], q[3]) for q in sol]
    n = len(sol)
    for i in range(n):
        cx, cy, a, s = sol[i]
        if s <= 0:
            continue
        total_pen += _outside_penalty(cx, cy, a, s)
        for j in range(i + 1, n):
            if sol[j][3] <= 0:
                continue
            total_pen += _overlap_area(corners[i], corners[j])
    return total_pen


def _total_len(sol):
    return sum(q[3] for q in sol)


def _local_energy(sol, corners, i):
    """Energy contribution of square i."""
    cx, cy, a, s = sol[i]
    if s <= 0:
        return 0.0
    pen = _outside_penalty(cx, cy, a, s)
    for j in range(len(sol)):
        if j == i or sol[j][3] <= 0:
            continue
        pen += _overlap_area(corners[i], corners[j])
    return pen


def _repair(sol, t0, budget):
    """Push squares inside box and slightly shrink overlaps to get feasibility."""
    n = len(sol)
    sol = [list(q) for q in sol]
    # first clamp inside
    for i in range(n):
        cx, cy, a, s = sol[i]
        a %= 1.0
        th = a * 2.0 * math.pi
        cc = abs(math.cos(th)) + abs(math.sin(th))
        maxs = 2.0 * min(cx, 1 - cx, cy, 1 - cy) / cc if cc > 0 else 0.0
        if s > maxs:
            s = maxs
        sol[i] = [cx, cy, a, max(0.0, s)]
    # shrink overlaps
    for _ in range(60):
        if time.time() - t0 > budget:
            break
        corners = [_corners(q[0], q[1], q[2], q[3]) for q in sol]
        worst = -1
        worst_pen = 0.0
        for i in range(n):
            if sol[i][3] <= 0:
                continue
            p = _local_energy(sol, corners, i)
            if p > worst_pen:
                worst_pen = p
                worst = i
        if worst < 0:
            break
        sol[worst][3] *= 0.85
        if sol[worst][3] < 1e-6:
            sol[worst][3] = 0.0
    return [tuple(q) for q in sol]


def _anneal(sol, t0, budget, max_iter):
    """Simulated annealing maximizing length with penalty energy."""
    n = len(sol)
    sol = [list(q) for q in sol]
    corners = [_corners(q[0], q[1], q[2], q[3]) for q in sol]

    def full_pen():
        tot = 0.0
        for i in range(n):
            if sol[i][3] <= 0:
                continue
            tot += _outside_penalty(sol[i][0], sol[i][1], sol[i][2], sol[i][3])
            for j in range(i + 1, n):
                if sol[j][3] <= 0:
                    continue
                tot += _overlap_area(corners[i], corners[j])
        return tot

    pen = full_pen()
    length = sum(q[3] for q in sol)
    W_PEN = 6.0

    def score():
        return length - W_PEN * pen

    best_sol = [list(q) for q in sol]
    best_score = score()

    T = 0.02
    T_min = 1e-5
    it = 0
    no_improve = 0
    while it < max_iter and time.time() - t0 < budget:
        it += 1
        if it % 400 == 0:
            T = max(T_min, T * 0.92)
        # pick a move
        i = random.randrange(n)
        old = sol[i]
        new = list(old)
        r = random.random()
        if r < 0.35:
            # move
            step = T * 0.5 + 0.005
            new[0] = min(1.0, max(0.0, old[0] + random.gauss(0, step)))
            new[1] = min(1.0, max(0.0, old[1] + random.gauss(0, step)))
        elif r < 0.6:
            # change side
            step = T * 0.5 + 0.005
            new[3] = max(0.0, old[3] + random.gauss(0, step))
        elif r < 0.8:
            # rotate
            new[2] = (old[2] + random.gauss(0, 0.1)) % 1.0
        else:
            # combined
            step = T * 0.3 + 0.003
            new[0] = min(1.0, max(0.0, old[0] + random.gauss(0, step)))
            new[1] = min(1.0, max(0.0, old[1] + random.gauss(0, step)))
            new[3] = max(0.0, old[3] + random.gauss(0, step))

        # clamp side to fit box at this center
        th = new[2] * 2.0 * math.pi
        cc = abs(math.cos(th)) + abs(math.sin(th))
        maxs = 2.0 * min(new[0], 1 - new[0], new[1], 1 - new[1]) / cc if cc > 0 else 0.0
        if new[3] > maxs:
            new[3] = maxs
        # enforce <= 1
        if new[3] > 1.0:
            new[3] = 1.0
        if new[0] > 1.0: new[0] = 1.0
        if new[1] > 1.0: new[1] = 1.0

        # compute delta
        old_pen_i = 0.0
        if old[3] > 0:
            old_pen_i += _outside_penalty(old[0], old[1], old[2], old[3])
            for j in range(n):
                if j == i or sol[j][3] <= 0:
                    continue
                old_pen_i += _overlap_area(corners[i], corners[j])
        new_corners = _corners(new[0], new[1], new[2], new[3])
        new_pen_i = 0.0
        if new[3] > 0:
            new_pen_i += _outside_penalty(new[0], new[1], new[2], new[3])
            for j in range(n):
                if j == i or sol[j][3] <= 0:
                    continue
                new_pen_i += _overlap_area(new_corners, corners[j])

        d_pen = new_pen_i - old_pen_i
        d_len = new[3] - old[3]
        d_score = d_len - W_PEN * d_pen

        if d_score >= 0 or random.random() < math.exp(d_score / max(T * 0.3, 1e-9)):
            sol[i] = new
            corners[i] = new_corners
            pen += d_pen
            length += d_len
            sc = length - W_PEN * pen
            if sc > best_score:
                best_score = sc
                best_sol = [list(q) for q in sol]
                no_improve = 0
            else:
                no_improve += 1
        else:
            no_improve += 1

    # feasibility: repair best
    return [tuple(q) for q in best_sol]


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # baseline grid
    m = 1
    while m * m < n:
        m += 1
    side = 1.0 / m
    base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(m) for j in range(m)][:n]
    best_sol = base
    best_sum = sum(q[3] for q in best_sol)

    # candidate grid + greedy starter configs
    seeds = []

    # grid non-uniform: k large + fill
    for mm in range(1, n + 1):
        if mm * mm >= n:
            s = 1.0 / mm
            seeds.append([((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                          for i in range(mm) for j in range(mm)][:n])

    # Known good patterns for small n (rows/cols)
    # simple row layout
    if n > 1:
        s = 1.0 / math.ceil(math.sqrt(n))
    # strips
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        # squares in rows of cols and then partial
        s = min(1.0 / cols, 1.0 / rows)
        conf = []
        cnt = 0
        for ri in range(rows):
            for ci in range(cols):
                if cnt >= n:
                    break
                conf.append(((ci + 0.5) * s, (ri + 0.5) * s, 0.0, s))
                cnt += 1
            if cnt >= n:
                break
        if len(conf) == n:
            seeds.append(conf)

    # a seed with one big square + grid
    for big in range(0, 11):
        bigs = big / 10.0
        if bigs <= 0 or bigs >= 1:
            continue

    # generate multiple starts and anneal
    random.seed(12345)

    # Build initial configs list
    initial_configs = []
    # pure grid
    initial_configs.append(base)
    for sd in seeds:
        if len(sd) == n:
            initial_configs.append(sd)

    # non-uniform greedy: place largest first
    def greedy_place():
        placed = []
        corners_list = []
        # candidate centers/angles
        cands = []
        for k in range(1, 9):
            for i in range(k):
                for j in range(k):
                    cands.append(((i + 0.5) / k, (j + 0.5) / k))
        for i in range(17):
            for j in range(17):
                cands.append(((i + 0.5) / 17, (j + 0.5) / 17))
        # shuffle a bit
        random.shuffle(cands)
        # sub-sample
        cands = cands[:400]
        angles = [0.0, 0.25, 0.125, 0.375]
        while len(placed) < n:
            best_s = 0.0
            best_c = None
            for (cx, cy) in cands:
                for a in angles:
                    if not (0 <= cx <= 1 and 0 <= cy <= 1):
                        continue
                    th = a * 2.0 * math.pi
                    cc = abs(math.cos(th)) + abs(math.sin(th))
                    maxs = 2.0 * min(cx, 1 - cx, cy, 1 - cy) / cc if cc > 0 else 0.0
                    if maxs <= best_s:
                        continue
                    lo = 0.0
                    hi = maxs
                    for _ in range(10):
                        mid = (lo + hi) * 0.5
                        p1 = _corners(cx, cy, a, mid)
                        good = True
                        for pc in corners_list:
                            if not _sep(p1, pc):
                                good = False
                                break
                        if good:
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s:
                        best_s = lo
                        best_c = (cx, cy, a)
            if best_c is None or best_s < 1e-9:
                # fill remaining with zeros
                while len(placed) < n:
                    placed.append((0.5, 0.5, 0.0, 0.0))
                    corners_list.append(_corners(0.5, 0.5, 0.0, 0.0))
                break
            placed.append((best_c[0], best_c[1], best_c[2], best_s))
            corners_list.append(_corners(best_c[0], best_c[1], best_c[2], best_s))
        return placed[:n]

    try:
        g = greedy_place()
        if len(g) == n:
            initial_configs.append(g)
    except Exception:
        pass

    # an "all equal in optimal-ish packing" seed: try halving
    # also seed with grid then random sizes
    random.seed(999)
    for _ in range(4):
        conf = [list(q) for q in base]
        for q in conf:
            q[3] = max(0.0, q[3] * random.uniform(0.7, 1.0))
        initial_configs.append([tuple(q) for q in conf])

    best_sol = base
    best_sum = sum(q[3] for q in base)

    # evaluate seeds (repair to feasible)
    feasible_seeds = []
    for conf in initial_configs:
        if len(conf) != n:
            continue
        rep = _repair(conf, t0, min(58, t0 + 5))
        if _energy(rep) < 1e-6:
            v = _total_len(rep)
            if v > best_sum:
                best_sum = v
                best_sol = rep
            feasible_seeds.append(rep)

    if not feasible_seeds:
        feasible_seeds = [base]

    # Anneal from multiple seeds
    num_restarts = max(3, min(8, 60 // max(1, n)))
    time_per = (58.0 - (time.time() - t0)) / max(1, num_restarts)
    if time_per < 1.0:
        time_per = 1.0

    for r in range(num_restarts):
        if time.time() - t0 > 57:
            break
        seed_conf = feasible_seeds[r % len(feasible_seeds)]
        budget = min(58.0, time.time() - t0 + time_per)
        max_it = 200000 // max(1, n)
        out = _anneal(seed_conf, t0, budget, max_it)
        out = _repair(out, t0, min(58, time.time() - t0 + 1.5))
        # if repair not fully feasible (still overlapping), shrink more
        if _energy(out) > 1e-6:
            out = _repair(out, t0, 58.0)
        v = _total_len(out)
        if v > best_sum:
            best_sum = v
            best_sol = out

    # final safety: ensure feasibility
    if _energy(best_sol) > 1e-6:
        best_sol = _repair(best_sol, t0, 58.5)

    # ensure all in [0,1]
    final = []
    for q in best_sol:
        cx = min(1.0, max(0.0, q[0]))
        cy = min(1.0, max(0.0, q[1]))
        a = q[2] % 1.0
        s = min(1.0, max(0.0, q[3]))
        final.append((cx, cy, a, s))
    while len(final) < n:
        final.append((0.5, 0.5, 0.0, 0.0))
    return final[:n]
