import math
import time
import random
import numpy as np
from collections import defaultdict

SQRT2 = math.sqrt(2)

def _corners(cx, cy, a, s):
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    h = s * 0.5
    return (
        (cx - h * co + h * si, cy - h * si - h * co),
        (cx + h * co + h * si, cy + h * si - h * co),
        (cx + h * co - h * si, cy + h * si + h * co),
        (cx - h * co - h * si, cy - h * si + h * co),
    )

def _sep(p1, p2):
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            d = ax * p1[0][0] + ay * p1[0][1]
            lo1 = hi1 = d
            for k in range(1, 4):
                d = ax * p1[k][0] + ay * p1[k][1]
                if d < lo1:
                    lo1 = d
                elif d > hi1:
                    hi1 = d
            d = ax * p2[0][0] + ay * p2[0][1]
            lo2 = hi2 = d
            for k in range(1, 4):
                d = ax * p2[k][0] + ay * p2[k][1]
                if d < lo2:
                    lo2 = d
                elif d > hi2:
                    hi2 = d
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return True
    return False

def _make_candidates_list(centers, angles, unit_sq_corners):
    # For each (cx,cy,angle) precompute maximum feasible side within unit square
    ub = {}
    for (cx, cy) in centers:
        # Use simple axis-aligned bounding box type check for speed; we need a good UB
        d = min(cx, 1.0 - cx, cy, 1.0 - cy)
        for a in angles:
            th = a * 2.0 * math.pi
            # half-diagonal projection lengths
            dx = 0.5 * (abs(math.cos(th)) + abs(math.sin(th)))
            # side length s: farthest corner distance = s * dx
            if dx > 0:
                ub[(cx, cy, a)] = d / dx
            else:
                ub[(cx, cy, a)] = 2.0  # larger than unit square
    return ub

def _greedy_rollout(sol, n, ub_map, centers, angles):
    pc = [_corners(q[0], q[1], q[2], q[3]) for q in sol]
    cur = sol.copy()
    while len(cur) < n:
        best_s = 0.0
        best_c = None
        for (cx, cy) in centers:
            for a in angles:
                u = ub_map[(cx, cy, a)]
                if u <= best_s:
                    continue
                lo = best_s
                hi = u
                # binary search for max feasible size
                for _ in range(10):
                    mid = (lo + hi) * 0.5
                    p = _corners(cx, cy, a, mid)
                    ok = True
                    for pp in pc:
                        if not _sep(p, pp):
                            ok = False
                            break
                    if ok:
                        lo = mid
                    else:
                        hi = mid
                if lo > best_s + 1e-9:
                    best_s = lo
                    best_c = (cx, cy, a)
        if best_c is None or best_s <= 1e-9:
            cur.append((0.5, 0.5, 0.0, 0.0))
            pc.append(_corners(0.5, 0.5, 0.0, 0.0))
        else:
            cur.append((best_c[0], best_c[1], best_c[2], best_s))
            pc.append(_corners(best_c[0], best_c[1], best_c[2], best_s))
    return sum(q[3] for q in cur)

def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Build candidate set: lattice points and angles
    res = 10
    pts = []
    for i in range(res + 1):
        for j in range(res + 1):
            x = (i + 0.5) / (res + 1)
            y = (j + 0.5) / (res + 1)
            pts.append((round(x, 8), round(y, 8)))
    # extra coarse grid
    for k in range(1, 6):
        for i in range(k):
            for j in range(k):
                x = (i + 0.5) / k
                y = (j + 0.5) / k
                pts.append((round(x, 8), round(y, 8)))
    pts = sorted(list(set(pts)))
    angles = [0.0, 0.125, 0.25]
    ub_map = _make_candidates_list(pts, angles, None)

    base_sol = None
    base_val = 0

    # Simple grid baseline
    for m in range(1, n+2):
        if m*m >= n:
            s = 1.0 / m
            cand = [((i+0.5)*s, (j+0.5)*s, 0.0, s) for i in range(m) for j in range(m)][:n]
            val = sum(q[3] for q in cand)
            if val > base_val:
                base_val = val
                base_sol = cand

    # Greedy baseline from empty
    if time.time() - t0 < 50:
        gsol = []
        val = _greedy_rollout(gsol, n, ub_map, pts, angles)
        if val > base_val:
            base_val = val
            # reconstruct the solution used by greedy for return
            base_sol = []
            pc = []
            while len(base_sol) < n:
                best_s = 0.0
                best_c = None
                for (cx, cy) in pts:
                    for a in angles:
                        u = ub_map[(cx, cy, a)]
                        if u <= best_s:
                            continue
                        lo = best_s
                        hi = u
                        for _ in range(10):
                            mid = (lo + hi) * 0.5
                            p = _corners(cx, cy, a, mid)
                            ok = True
                            for pp in pc:
                                if not _sep(p, pp):
                                    ok = False
                                    break
                            if ok:
                                lo = mid
                            else:
                                hi = mid
                        if lo > best_s + 1e-9:
                            best_s = lo
                            best_c = (cx, cy, a)
                if best_c is None or best_s <= 1e-9:
                    base_sol.append((0.5, 0.5, 0.0, 0.0))
                    pc.append(_corners(0.5, 0.5, 0.0, 0.0))
                else:
                    base_sol.append((best_c[0], best_c[1], best_c[2], best_s))
                    pc.append(_corners(best_c[0], best_c[1], best_c[2], best_s))

    # MCTS parameters
    SIMS = min(200, max(50, n * 20))
    MAX_NODES = 3000
    Cp = 1.0 / math.sqrt(2.0)

    class Node:
        __slots__ = ('squares', 'corners', 'sum_len', 'children', 'visits', 'value', 'untried_actions', 'parent')
        def __init__(self, squares, corners, sum_len, parent=None):
            self.squares = squares
            self.corners = corners
            self.sum_len = sum_len
            self.children = {}
            self.visits = 0
            self.value = 0.0
            self.parent = parent
            # generate untried actions: (cx, cy, a, max_possible_side_before_feasibility)
            self.untried_actions = []
            if len(squares) < n:
                # precompute upper bound for each action given current placements
                for (cx, cy) in pts:
                    for a in angles:
                        u = ub_map[(cx, cy, a)]
                        if u <= 0:
                            continue
                        lo = 0.0
                        hi = u
                        # quick feasibility for max: binary search to find feasible max
                        for _ in range(8):
                            mid = (lo + hi) * 0.5
                            p = _corners(cx, cy, a, mid)
                            ok = True
                            for c in self.corners:
                                if not _sep(p, c):
                                    ok = False
                                    break
                            if ok:
                                lo = mid
                            else:
                                hi = mid
                        if lo > 1e-9:
                            self.untried_actions.append((cx, cy, a, lo))
                # Sort by side descending to prioritize larger placements
                self.untried_actions.sort(key=lambda x: x[3], reverse=True)
                # Keep only top actions to limit branching
                if len(self.untried_actions) > max(10, n*3):
                    self.untried_actions = self.untried_actions[:max(10, n*3)]

    root = Node([], [], 0.0)

    def tree_policy(node):
        while len(node.squares) < n and not node.untried_actions:
            if not node.children:
                break
            best = -float('inf')
            best_a = None
            for act, child in node.children.items():
                if child.visits == 0:
                    q = 0.0
                else:
                    q = child.value / child.visits
                u = Cp * math.sqrt(math.log(node.visits + 1) / (child.visits + 1))
                score = q + u
                if score > best:
                    best = score
                    best_a = act
            if best_a is None:
                return node  # should not happen
            node = node.children[best_a]
        return node

    def expand(node):
        if not node.untried_actions:
            return node
        # pick the first untried (largest side)
        act = node.untried_actions.pop(0)
        cx, cy, a, s = act
        squares = node.squares + [(cx, cy, a, s)]
        corners = node.corners + [_corners(cx, cy, a, s)]
        new_node = Node(squares, corners, node.sum_len + s, parent=node)
        node.children[act] = new_node
        return new_node

    def default_policy(node):
        # greedy rollout starting from node state
        cur_sq = node.squares.copy()
        cur_corners = node.corners.copy()
        while len(cur_sq) < n:
            best_s = 0.0
            best_c = None
            # Limit search to a subset of candidates for speed, maybe shuffle a bit
            sampled_pts = random.sample(pts, min(len(pts), 20))
            for (cx, cy) in sampled_pts:
                for a in angles:
                    u = ub_map[(cx, cy, a)]
                    if u <= best_s:
                        continue
                    lo = best_s
                    hi = u
                    for _ in range(8):
                        mid = (lo + hi) * 0.5
                        p = _corners(cx, cy, a, mid)
                        ok = True
                        for pc in cur_corners:
                            if not _sep(p, pc):
                                ok = False
                                break
                        if ok:
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s + 1e-9:
                        best_s = lo
                        best_c = (cx, cy, a)
            if best_c is None or best_s <= 1e-9:
                cur_sq.append((0.5, 0.5, 0.0, 0.0))
                cur_corners.append(_corners(0.5, 0.5, 0.0, 0.0))
            else:
                cur_sq.append((best_c[0], best_c[1], best_c[2], best_s))
                cur_corners.append(_corners(best_c[0], best_c[1], best_c[2], best_s))
        return sum(q[3] for q in cur_sq)

    def backpropagate(node, reward):
        while node is not None:
            node.visits += 1
            node.value += reward
            node = node.parent

    # Run MCTS
    nodes_created = 1
    for sim in range(SIMS):
        if time.time() - t0 > 55:
            break
        if nodes_created >= MAX_NODES:
            break
        leaf = tree_policy(root)
        if len(leaf.squares) < n and leaf.untried_actions:
            leaf = expand(leaf)
            nodes_created += 1
        reward = default_policy(leaf)
        backpropagate(leaf, reward)

    # Extract best child sequence from root
    best_seq = base_sol
    best_val = base_val
    def extract_best(node):
        nonlocal best_seq, best_val
        if len(node.squares) == n:
            if node.sum_len > best_val:
                best_val = node.sum_len
                best_seq = node.squares
            return
        if not node.children:
            return
        # select child with highest average value
        best_child = None
        best_avg = -1
        for act, child in node.children.items():
            if child.visits == 0:
                continue
            avg = child.value / child.visits
            if avg > best_avg:
                best_avg = avg
                best_child = child
        if best_child:
            extract_best(best_child)

    # Also consider the greedy path from root as a candidate
    if root.children:
        # greedily pick max value child
        greedy_seq = []
        cur = root
        while cur.children and len(greedy_seq) < n:
            best_act = max(cur.children.keys(), key=lambda act: cur.children[act].value / max(1, cur.children[act].visits))
            greedy_seq.append((best_act[0], best_act[1], best_act[2], best_act[3]))
            cur = cur.children[best_act]
        # complete with zeros
        while len(greedy_seq) < n:
            greedy_seq.append((0.5, 0.5, 0.0, 0.0))
        gval = sum(q[3] for q in greedy_seq)
        if gval > best_val:
            best_val = gval
            best_seq = greedy_seq

    extract_best(root)

    # fallback to baseline if nothing better
    if best_seq is None or len(best_seq) < n:
        best_seq = base_sol

    # Ensure exactly n squares returned
    res = list(best_seq[:n])
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
