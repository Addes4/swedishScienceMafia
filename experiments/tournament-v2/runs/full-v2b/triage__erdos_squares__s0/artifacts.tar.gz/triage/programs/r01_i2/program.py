import numpy as np
from scipy.optimize import minimize


def rotate_vertices(cx, cy, angle, side):
    """Return 4 vertices of a square given center, side, and rotation angle (fraction of full turn)."""
    theta = 2 * np.pi * angle
    # half-diagonal offset
    d = (side / 2) * np.sqrt(2)
    # vertices relative to center, before rotation
    base_angles = np.array([np.pi / 4, 3 * np.pi / 4, 5 * np.pi / 4, 7 * np.pi / 4])
    x_rel = d * np.cos(theta + base_angles)
    y_rel = d * np.sin(theta + base_angles)
    return (cx + x_rel, cy + y_rel)


def penalty_potential(squares_params, n, penalty_weight, max_side):
    """Compute overlap penalty and sum of side lengths from parameters.
    
    Parameters are [x1,...,xn, y1,...,yn, a1,...,an, s1,...,sn] where
    xi,yi in [0,1], ai in [0,1], si in [0, max_side].
    """
    cx = squares_params[:n]
    cy = squares_params[n:2 * n]
    angles = squares_params[2 * n:3 * n]
    sides = squares_params[3 * n:4 * n]
    
    # Keep sides non-negative using a barrier
    side_penalty = np.sum(np.maximum(-sides, 0)**2)

    # Keep squares inside unit square: encourage centers to stay within [side/2, 1 - side/2]
    lower = sides / 2
    upper = 1 - sides / 2
    container_penalty = np.sum(np.maximum(lower - cx, 0)**2) + np.sum(np.maximum(cx - upper, 0)**2)
    container_penalty += np.sum(np.maximum(lower - cy, 0)**2) + np.sum(np.maximum(cy - upper, 0)**2)
    
    overlap_penalty = 0.0
    # Compute overlap between all unordered pairs of squares using separating axis theorem
    for i in range(n):
        for j in range(i + 1, n):
            if sides[i] <= 1e-12 or sides[j] <= 1e-12:
                continue
            # Get normals: only two directions because we use axis-aligned squares? No, rotated.
            # For two squares, separating axes are the normals to sides of each square.
            # Get vertices
            vxi, vyi = rotate_vertices(cx[i], cy[i], angles[i], sides[i])
            vxj, vyj = rotate_vertices(cx[j], cy[j], angles[j], sides[j])
            # Normals: for a square there are two unique axes (perpendicular to edges)
            for k in range(2):
                theta_axis = 2 * np.pi * angles[i] + k * np.pi / 2  # normal perpendicular to edge
                axis_x = np.cos(theta_axis)
                axis_y = np.sin(theta_axis)
                proj_i = vxi * axis_x + vyi * axis_y
                proj_j = vxj * axis_x + vyj * axis_y
                min_i, max_i = np.min(proj_i), np.max(proj_i)
                min_j, max_j = np.min(proj_j), np.max(proj_j)
                gap = max(min_i, min_j) - min(max_i, max_j)
                if gap > 0:
                    break  # separating axis found
            else:
                # no separating axis found for square i, check square j axes
                for k in range(2):
                    theta_axis = 2 * np.pi * angles[j] + k * np.pi / 2
                    axis_x = np.cos(theta_axis)
                    axis_y = np.sin(theta_axis)
                    proj_i = vxi * axis_x + vyi * axis_y
                    proj_j = vxj * axis_x + vyj * axis_y
                    min_i, max_i = np.min(proj_i), np.max(proj_i)
                    min_j, max_j = np.min(proj_j), np.max(proj_j)
                    gap = max(min_i, min_j) - min(max_i, max_j)
                    if gap > 0:
                        break
                else:
                    # Overlap detected: compute penetration depth (approximate)
                    # Use simple penalty proportional to area of overlap approximated
                    # as product of side min penetration in both axes (crude but continuous)
                    # We'll penalize by a measure of overlapping region size
                    # Compute overlap in x and y by axis-aligned bounding box approach (non-rotated)
                    # but better: use the distance between centers and sum of half-diagonals
                    di = sides[i] * np.sqrt(2) / 2
                    dj = sides[j] * np.sqrt(2) / 2
                    dist = np.hypot(cx[i] - cx[j], cy[i] - cy[j])
                    penetration = di + dj - dist
                    if penetration > 0:
                        overlap_penalty += penetration**2

    total_sum = -np.sum(sides)  # maximize sum
    return total_sum + penalty_weight * (overlap_penalty + side_penalty + container_penalty)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    max_side = 1.0
    # initialization: slightly perturbed grid of side 1/ceil(sqrt(n))
    k = int(np.ceil(np.sqrt(n)))
    side_init = 1.0 / k
    # create grid positions
    xs = []
    ys = []
    angles = []
    sides = []
    for idx in range(n):
        i = idx // k
        j = idx % k
        x = (j + 0.5) * side_init
        y = (i + 0.5) * side_init
        # small random jitter
        x += np.random.uniform(-0.02, 0.02)
        y += np.random.uniform(-0.02, 0.02)
        xs.append(np.clip(x, 0.01, 0.99))
        ys.append(np.clip(y, 0.01, 0.99))
        angles.append(np.random.uniform(0, 1))
        sides.append(np.random.uniform(0.3 * side_init, side_init))
    
    # Optimize: gradually increase penalty weight
    best_sum = -np.inf
    best_params = None
    
    # Use a few restarts with different seeds
    for restart in range(3):
        np.random.seed(restart * 42 + 17)
        x0 = np.array(xs + ys + angles + sides)
        current_penalty = 10.0
        for step in range(6):
            # bounds: x,y in [0,1], angles in [0,1], sides in [0,max_side]
            bounds = [(0.0, 1.0)] * n + [(0.0, 1.0)] * n + [(0.0, 1.0)] * n + [(0.0, max_side)] * n
            res = minimize(
                penalty_potential,
                x0,
                args=(n, current_penalty, max_side),
                method='L-BFGS-B',
                bounds=bounds,
                options={'maxiter': 2000, 'ftol': 1e-12}
            )
            x0 = res.x
            current_penalty *= 5.0
        # final evaluation with high penalty (should be near feasible)
        final_penalty = 1e6
        res = minimize(
            penalty_potential,
            x0,
            args=(n, final_penalty, max_side),
            method='L-BFGS-B',
            bounds=bounds,
            options={'maxiter': 2000, 'ftol': 1e-12}
        )
        candidate = res.x
        cx = candidate[:n]
        cy = candidate[n:2 * n]
        angles_final = candidate[2 * n:3 * n]
        sides_final = candidate[3 * n:4 * n]
        # clip tiny negatives
        sides_final = np.maximum(sides_final, 0.0)
        # check feasibility roughly via overlap penalty at high weight
        overlap_pen = 0.0
        for i in range(n):
            for j in range(i + 1, n):
                if sides_final[i] <= 1e-10 or sides_final[j] <= 1e-10:
                    continue
                di = sides_final[i] * np.sqrt(2) / 2
                dj = sides_final[j] * np.sqrt(2) / 2
                dist = np.hypot(cx[i] - cx[j], cy[i] - cy[j])
                if dist < di + dj - 1e-6:
                    overlap_pen += (di + dj - dist)**2
        if overlap_pen < 1e-8:
            current_sum = np.sum(sides_final)
            if current_sum > best_sum:
                best_sum = current_sum
                best_params = candidate.copy()
    
    if best_params is None:
        # fallback to grid
        return solve_baseline(n)
    
    cx = best_params[:n]
    cy = best_params[n:2 * n]
    angles = best_params[2 * n:3 * n]
    sides = best_params[3 * n:4 * n]
    # clamp sides and ensure non-negative
    sides = np.maximum(sides, 0.0)
    angles = angles % 1.0
    # enforce boundaries roughly
    for i in range(n):
        s2 = sides[i] / np.sqrt(2)  # approx half side projection
        cx[i] = np.clip(cx[i], s2, 1 - s2)
        cy[i] = np.clip(cy[i], s2, 1 - s2)
    
    squares = [(float(cx[i]), float(cy[i]), float(angles[i]), float(sides[i])) for i in range(n)]
    return squares


def solve_baseline(n):
    """Fallback to simple grid if optimization fails."""
    k = int(np.isqrt(n))
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
