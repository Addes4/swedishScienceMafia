import math
import time
import itertools

import numpy as np
from scipy.optimize import linprog


def _corners(cx, cy, a, s):
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    h = s * 0.5
    return np.array([
        [cx - h * co + h * si, cy - h * si - h * co],
        [cx + h * co + h * si, cy + h * si - h * co],
        [cx + h * co - h * si, cy + h * si + h * co],
        [cx - h * co - h * si, cy - h * si + h * co],
    ])


def _point_in_convex_polygon(pt, poly):
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        # cross product (x2-x1, y2-y1) x (pt-x1, pt-y1)
        if (x2 - x1) * (pt[1] - y1) - (y2 - y1) * (pt[0] - x1) < -1e-12:
            return False
    return True


def _polygon_area(poly):
    area = 0.0
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def _clip_polygon_by_halfplane(poly, a, b, c):
    """Clip a convex polygon with half-plane a*x + b*y <= c.
    poly is list of points in ccw order.
    Returns new polygon (maybe empty)."""
    if not poly:
        return []
    new_poly = []
    n = len(poly)
    for i in range(n):
        cur = poly[i]
        nxt = poly[(i + 1) % n]
        cur_in = a * cur[0] + b * cur[1] <= c + 1e-12
        nxt_in = a * nxt[0] + b * nxt[1] <= c + 1e-12
        if cur_in:
            new_poly.append(cur)
        if cur_in != nxt_in:
            # compute intersection
            x1, y1 = cur
            x2, y2 = nxt
            dx = x2 - x1
            dy = y2 - y1
            denom = a * dx + b * dy
            if abs(denom) > 1e-15:
                t = (c - a * x1 - b * y1) / denom
                t = max(0.0, min(1.0, t))
                new_poly.append((x1 + t * dx, y1 + t * dy))
    return new_poly


def _subtract_square_from_region(region, sq_corners):
    """
    Subtract the square from the region (list of convex polygons).
    Square is given as 4 corner points in ccw order.
    Returns new list of convex polygons representing the free space.
    """
    # The square defines four half-planes that cut the existing polygons.
    # sq_corners order: starting from some vertex ccw.
    # For each edge of the square, we keep the part of the region that is
    # on the *outside* (the half-plane not containing the square interior).
    new_region = []
    for poly in region:
        # clip each polygon against all four half-planes
        current = [list(p) for p in poly]
        for i in range(4):
            x1, y1 = sq_corners[i]
            x2, y2 = sq_corners[(i + 1) % 4]
            # edge vector
            ex = x2 - x1
            ey = y2 - y1
            # outward normal: left-hand normal (rotate edge ccw 90 deg)
            nx = -ey
            ny = ex
            # For the square interior, points satisfy (p - x1) dot (nx, ny) <= 0
            # We want the outside: (p - x1) dot (nx, ny) >= 0  <=> -nx*x - ny*y <= -nx*x1 - ny*y1
            a = -nx
            b = -ny
            c = -nx * x1 - ny * y1
            current = _clip_polygon_by_halfplane(current, a, b, c)
            if not current:
                break
        if current:
            new_region.append(current)
    return new_region


def _region_area(region):
    return sum(_polygon_area(poly) for poly in region)


def _max_inscribed_square_in_polygon(poly, angles):
    """
    Given a convex polygon (list of points ccw), find the maximum square
    of the form (center_x, center_y, angle a, side s) that fits inside.
    Returns (cx, cy, a, s) or None if no positive side.
    Uses linear programming for a fixed angle.
    We optimize variable s directly.
    For a given angle a, we parameterize the square:
    Let u = (cos(th), sin(th)), v = (-sin(th), cos(th)) with th = a * 2pi.
    Vertices:
      c + s/2 * u + s/2 * v
      c + s/2 * u - s/2 * v
      c - s/2 * u - s/2 * v
      c - s/2 * u + s/2 * v
    The polygon edges: for each edge from p1 to p2, outward normal n = (ny, -nx) (if polygon ccw)
    Actually polygon is ccw, interior is to the left of each directed edge.
    For edge (p1 -> p2), left normal is n = (-dy, dx). Interior: n·(x - p1) >= 0.
    We need all four vertices of square to satisfy n·(vtx - p1) >= 0.
    This gives linear constraints on cx, cy, s.
    Write vtx = c + M * [s/2, s/2]^T? Better:
    We have 4 vertices: c + A_i * s/2, where A_i are the 4 directions:
    A0 = u+v, A1 = u-v, A2 = -u-v, A3 = -u+v.
    Constraint for edge j (with normal n, offset d = n·p1):
    n·c + (n·A_i) * s/2 >= d, for i=0..3
    That's linear in (cx, cy, s).
    We maximize s.
    """
    n = len(poly)
    # precompute edges: normals and offsets
    edges = []
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % n]
        dx = x2 - x1
        dy = y2 - y1
        # left normal (inside is left)
        nx = -dy
        ny = dx
        # normalize?
        norm = math.hypot(nx, ny)
        if norm < 1e-12:
            continue
        nx /= norm
        ny /= norm
        offset = nx * x1 + ny * y1  # n·p1
        edges.append((nx, ny, offset))

    best_val = -1.0
    best = None

    for a in angles:
        th = a * 2.0 * math.pi
        cos_a = math.cos(th)
        sin_a = math.sin(th)
        # directions u, v
        ux = cos_a
        uy = sin_a
        vx = -sin_a
        vy = cos_a

        # The four A vectors = combinations of +/- u and +/- v
        A = [
            (ux + vx, uy + vy),   # u+v
            (ux - vx, uy - vy),   # u-v
            (-ux - vx, -uy - vy), # -u-v
            (-ux + vx, -uy + vy), # -u+v
        ]

        # variables: cx, cy, s
        # Objective: maximize s
        c_obj = [0, 0, 1]

        # Constraints: for each edge and each vertex i,
        # nx * cx + ny * cy + (nx*Ax_i + ny*Ay_i) * 0.5 * s >= offset
        # => -nx * cx - ny * cy - coeff * s <= -offset
        A_ub = []
        b_ub = []
        for nx, ny, off in edges:
            for Ax, Ay in A:
                coeff = (nx * Ax + ny * Ay) * 0.5
                A_ub.append([-nx, -ny, -coeff])
                b_ub.append(-off)

        # Also bound variables: cx, cy in [0,1], s >= 0, s <= 2 (safe)
        bounds = [(0, 1), (0, 1), (0, 2.0)]

        # Solve LP
        try:
            res = linprog(
                c = [-x for x in c_obj],  # max s = min -s, but we use negative c for maximization? scipy minimizes c^T x. So to max s we set c = [0,0,-1]?
                # Actually scipy minimizes. We want max s, so minimize -s. Let's use c = [0,0,-1]
                A_ub = A_ub,
                b_ub = b_ub,
                bounds = bounds,
                method = 'highs',
                options = {'disp': False, 'maxiter': 2000}
            )
            if res.success and -res.fun > best_val + 1e-12:
                best_val = -res.fun
                best = (res.x[0], res.x[1], a, max(0.0, res.x[2]))
        except Exception:
            continue

    if best is not None and best[3] < 1e-9:
        best = None
    return best


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # The initial free space: the unit square as a convex polygon
    unit_sq = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0)]
    region = [unit_sq]

    # Angles to consider. Few angles often suffice; we can include more.
    angles = [0.0, 0.125, 0.25, 0.375]  # 0, 45, 90, 135 degrees
    # Also try a few more for better coverage
    for i in range(1, 8):
        angles.append(i / 8.0)
    angles = sorted(list(set(angles)))

    sol = []
    for _ in range(n):
        if time.time() - t0 > 50:
            break
        # Find the best square over all polygons of the region
        best_sq = None
        best_s = -1.0
        # Reduce polygons for speed? region can grow, but for n<=15 it's fine.
        # Filter out tiny polygons
        region_active = [poly for poly in region if _polygon_area(poly) > 1e-12]
        for poly in region_active:
            candidate = _max_inscribed_square_in_polygon(poly, angles)
            if candidate is None:
                continue
            s = candidate[3]
            if s > best_s + 1e-12:
                best_s = s
                best_sq = candidate

        if best_sq is None or best_sq[3] < 1e-9:
            # no positive square can be placed, fill remaining with zero squares
            sol.append((0.5, 0.5, 0.0, 0.0))
            continue

        cx, cy, a, s = best_sq
        # shrink slightly to avoid numerical issues when subtracting
        s_use = max(0.0, s - 1e-8)
        if s_use < 1e-9:
            sol.append((cx, cy, a, 0.0))
            continue

        sq_corners = _corners(cx, cy, a, s_use)
        # subtract this square from the region
        region = _subtract_square_from_region(region, sq_corners)
        sol.append((cx, cy, a, s_use))

    # Fill up to n if needed
    while len(sol) < n:
        sol.append((0.5, 0.5, 0.0, 0.0))

    # Post-processing: try to enlarge each square slightly while keeping no overlap
    # (simple greedy expansion)
    for _ in range(2):  # a couple of passes
        for idx in range(len(sol)):
            if sol[idx][3] <= 0:
                continue
            # temporarily remove
            others = [sol[i] for i in range(len(sol)) if i != idx]
            # try to increase side
            cx, cy, a, s_cur = sol[idx]
            lo = s_cur
            hi = min(lo * 1.5 + 0.2, 2.0)  # upper bound
            for _ in range(10):
                mid = (lo + hi) / 2
                sq_c = _corners(cx, cy, a, mid)
                # check unit square containment
                if np.any(sq_c < -1e-12) or np.any(sq_c > 1+1e-12):
                    hi = mid
                    continue
                ok = True
                for o in others:
                    if o[3] <= 0:
                        continue
                    oc = _corners(o[0], o[1], o[2], o[3])
                    # simple separation test: SAT or bounding box
                    if not _sep(sq_c, oc):
                        ok = False
                        break
                if ok:
                    lo = mid
                else:
                    hi = mid
            sol[idx] = (cx, cy, a, lo)

    # Sort by side descending for neatness
    sol.sort(key=lambda x: x[3], reverse=True)
    return sol[:n]


def _sep(p1, p2):
    # reused from baseline
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            d = ax * p1[0][0] + ay * p1[0][1]
            lo1 = hi1 = d
            for k in range(1, 4):
                d = ax * p1[k][0] + ay * p1[k][1]
                if d < lo1:
                    lo1 = d
                elif d > hi1:
                    hi1 = d
            d = ax * p2[0][0] + ay * p2[0][1]
            lo2 = hi2 = d
            for k in range(1, 4):
                d = ax * p2[k][0] + ay * p2[k][1]
                if d < lo2:
                    lo2 = d
                elif d > hi2:
                    hi2 = d
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return True
    return False
