import math
import time
import random
from itertools import product

def _corners(cx, cy, a, s):
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    h = s * 0.5
    return (
        (cx - h * co + h * si, cy - h * si - h * co),
        (cx + h * co + h * si, cy + h * si - h * co),
        (cx + h * co - h * si, cy + h * si + h * co),
        (cx - h * co - h * si, cy - h * si + h * co),
    )

def _sep(p1, p2):
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            # project p1
            d = ax * p1[0][0] + ay * p1[0][1]
            lo1 = hi1 = d
            for k in range(1, 4):
                d = ax * p1[k][0] + ay * p1[k][1]
                if d < lo1:
                    lo1 = d
                elif d > hi1:
                    hi1 = d
            # project p2
            d = ax * p2[0][0] + ay * p2[0][1]
            lo2 = hi2 = d
            for k in range(1, 4):
                d = ax * p2[k][0] + ay * p2[k][1]
                if d < lo2:
                    lo2 = d
                elif d > hi2:
                    hi2 = d
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return True
    return False

def _rect_inside_unit(cx, cy, a, s):
    """Check if the square is fully inside [0,1]^2"""
    corners = _corners(cx, cy, a, s)
    for x, y in corners:
        if not (-1e-9 <= x <= 1.0 + 1e-9 and -1e-9 <= y <= 1.0 + 1e-9):
            return False
    return True

def _max_side_at(cx, cy, a, placed_corners, bound=1.0):
    """Binary search for maximum feasible side length at given position/orientation"""
    # quick bound: distance to unit square edges
    th = a * 2.0 * math.pi
    co = abs(math.cos(th)) + abs(math.sin(th))
    max_bound = 2.0 * min(cx, 1.0 - cx, cy, 1.0 - cy) / co if co > 0 else 0.0
    lo, hi = 0.0, min(max_bound, 0.99)  # slightly less than 1 to avoid precision issues
    for _ in range(30):
        mid = (lo + hi) / 2
        p = _corners(cx, cy, a, mid)
        ok = True
        for pc in placed_corners:
            if not _sep(p, pc):
                ok = False
                break
        if ok:
            lo = mid
        else:
            hi = mid
    return lo

class Quadtree:
    """Simple region quadtree to find empty areas"""
    def __init__(self, xmin, ymin, xmax, ymax, depth=0):
        self.xmin = xmin
        self.ymin = ymin
        self.xmax = xmax
        self.ymax = ymax
        self.depth = depth
        self.children = None
        self.empty_score = (xmax - xmin) * (ymax - ymin)  # area

    def subdivide(self):
        xmid = (self.xmin + self.xmax) / 2
        ymid = (self.ymin + self.ymax) / 2
        self.children = [
            Quadtree(self.xmin, self.ymin, xmid, ymid, self.depth + 1),
            Quadtree(xmid, self.ymin, self.xmax, ymid, self.depth + 1),
            Quadtree(self.xmin, ymid, xmid, self.ymax, self.depth + 1),
            Quadtree(xmid, ymid, self.xmax, self.ymax, self.depth + 1)
        ]

    def mark_covered(self, placed_corners):
        """Recursively mark regions that are fully covered by any square"""
        if self.children is not None:
            for child in self.children:
                child.mark_covered(placed_corners)
            # if all children have empty_score = 0, set this to 0
            if all(c.empty_score == 0 for c in self.children):
                self.empty_score = 0
            else:
                self.empty_score = sum(c.empty_score for c in self.children)
            return

        # Leaf: check if completely inside some placed square
        corners_rect = [
            (self.xmin, self.ymin),
            (self.xmax, self.ymin),
            (self.xmax, self.ymax),
            (self.xmin, self.ymax)
        ]
        for sq in placed_corners:
            # Check if all 4 rectangle corners are inside the square (conservative)
            inside = True
            for p in corners_rect:
                # point-in-convex-polygon using cross product signs
                x, y = p
                sign = None
                for i in range(4):
                    x1, y1 = sq[i]
                    x2, y2 = sq[(i + 1) & 3]
                    cross = (x2 - x1) * (y - y1) - (y2 - y1) * (x - x1)
                    if cross > 1e-9:
                        sgn = 1
                    elif cross < -1e-9:
                        sgn = -1
                    else:
                        sgn = 0
                    if sign is None:
                        sign = sgn
                    elif sign != sgn and sgn != 0 and sign != 0:
                        inside = False
                        break
                if inside:
                    break
            if inside:
                self.empty_score = 0
                break
        else:
            # Check intersection with squares to see if region is free
            # A simple approximation: if rectangle overlaps any square, subdivide deeper.
            # Here we just keep score if no intersection (or minimal)
            for sq in placed_corners:
                # Quick bbox test
                xs = [p[0] for p in sq]
                ys = [p[1] for p in sq]
                if max(xs) >= self.xmin - 1e-9 and min(xs) <= self.xmax + 1e-9 and \
                   max(ys) >= self.ymin - 1e-9 and min(ys) <= self.ymax + 1e-9:
                    # potential intersection, penalize
                    self.empty_score *= 0.5
                    break

    def get_leaves(self):
        if self.children is None:
            if self.empty_score > 0:
                yield self
        else:
            for c in self.children:
                yield from c.get_leaves()

def _local_search_placement(placed_corners, max_time):
    """Adaptive search: refine quadtree to find promising regions, then local optimize"""
    t_start = time.time()
    best_cx, best_cy, best_a, best_s = 0.5, 0.5, 0.0, 0.0

    # Build quadtree
    root = Quadtree(0.0, 0.0, 1.0, 1.0)
    # Subdivide a few levels
    def subdivide_all(node, levels):
        if levels <= 0:
            return
        node.subdivide()
        for c in node.children:
            subdivide_all(c, levels - 1)
    subdivide_all(root, 5)  # 32x32 grid of leaves

    if time.time() - t_start > max_time * 0.5:
        return best_cx, best_cy, best_a, best_s

    root.mark_covered(placed_corners)

    leaves = list(root.get_leaves())
    if not leaves:
        return best_cx, best_cy, best_a, best_s

    # Sort by empty_score descending
    leaves.sort(key=lambda l: l.empty_score, reverse=True)

    # Test each candidate region: try angles, refine locally
    angles_to_try = [0.0, 0.25, 0.125, 0.375, 0.0625, 0.1875, 0.3125, 0.4375]
    tested = 0
    for leaf in leaves:
        if time.time() - t_start > max_time * 0.8:
            break
        cx_c = (leaf.xmin + leaf.xmax) / 2
        cy_c = (leaf.ymin + leaf.ymax) / 2
        # local search around center with Nelder-Mead style
        for a in angles_to_try:
            s = _max_side_at(cx_c, cy_c, a, placed_corners)
            if s > best_s + 1e-9:
                # gradient-free refinement: try small perturbations
                improved = True
                step = 0.02
                cur_cx, cur_cy, cur_a, cur_s = cx_c, cy_c, a, s
                for _ in range(10):
                    improved = False
                    for dx, dy, da in product([-step, 0, step], repeat=3):
                        if dx == 0 and dy == 0 and da == 0:
                            continue
                        nx = cur_cx + dx * (leaf.xmax - leaf.xmin)
                        ny = cur_cy + dy * (leaf.ymax - leaf.ymin)
                        na = (cur_a + da * 0.1) % 1.0
                        if not (0 <= nx <= 1 and 0 <= ny <= 1):
                            continue
                        ns = _max_side_at(nx, ny, na, placed_corners)
                        if ns > cur_s + 1e-12:
                            cur_cx, cur_cy, cur_a, cur_s = nx, ny, na, ns
                            improved = True
                    if not improved:
                        step /= 2
                    if step < 1e-4:
                        break
                if cur_s > best_s + 1e-9:
                    best_cx, best_cy, best_a, best_s = cur_cx, cur_cy, cur_a, cur_s
            tested += 1
            if tested > 100:
                break
        if tested > 100:
            break

    # Additional random local search if time permits
    while time.time() - t_start < max_time:
        cx = random.random()
        cy = random.random()
        a = random.choice(angles_to_try)
        s = _max_side_at(cx, cy, a, placed_corners)
        if s > best_s + 1e-9:
            # Refine
            improved = True
            step = 0.01
            cur_cx, cur_cy, cur_a, cur_s = cx, cy, a, s
            for _ in range(10):
                improved = False
                for dx, dy, da in product([-step, 0, step], repeat=3):
                    if dx == 0 and dy == 0 and da == 0:
                        continue
                    nx = cur_cx + dx * 0.1
                    ny = cur_cy + dy * 0.1
                    na = (cur_a + da * 0.05) % 1.0
                    if not (0 <= nx <= 1 and 0 <= ny <= 1):
                        continue
                    ns = _max_side_at(nx, ny, na, placed_corners)
                    if ns > cur_s + 1e-12:
                        cur_cx, cur_cy, cur_a, cur_s = nx, ny, na, ns
                        improved = True
                if not improved:
                    step /= 2
                if step < 1e-4:
                    break
            if cur_s > best_s + 1e-9:
                best_cx, best_cy, best_a, best_s = cur_cx, cur_cy, cur_a, cur_s

    return best_cx, best_cy, best_a, best_s


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Baseline: grid packing
    m = 1
    while m * m < n:
        m += 1
    side = 1.0 / m
    best_sol = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(m) for j in range(m)][:n]
    best_sum = sum(q[3] for q in best_sol)

    # Fill function using adaptive search
    def greedy_fill(initial_sol, time_budget):
        sol = list(initial_sol)
        placed_corners = [_corners(q[0], q[1], q[2], q[3]) for q in sol]
        while len(sol) < n:
            if time.time() - t0 > time_budget:
                break
            # Adaptive placement
            remaining_time = time_budget - (time.time() - t0)
            if remaining_time <= 0:
                break
            cx, cy, a, s = _local_search_placement(placed_corners, min(0.5, remaining_time))
            if s <= 1e-9:
                sol.append((0.5, 0.5, 0.0, 0.0))
            else:
                sol.append((cx, cy, a, s))
            placed_corners.append(_corners(cx, cy, a, s))
        while len(sol) < n:
            sol.append((0.5, 0.5, 0.0, 0.0))
        return sol

    # Try different starting grid sizes
    for k in range(1, n + 1):
        if k * k > n:
            break
        if time.time() - t0 > 55:
            break
        gs = 1.0 / k
        init = [((i + 0.5) * gs, (j + 0.5) * gs, 0.0, gs)
                for i in range(k) for j in range(k)]
        sol = greedy_fill(init, 58)
        ssum = sum(q[3] for q in sol)
        if ssum > best_sum:
            best_sum = ssum
            best_sol = sol

    # Pure greedy from empty
    if time.time() - t0 < 50:
        sol = greedy_fill([], 58)
        ssum = sum(q[3] for q in sol)
        if ssum > best_sum:
            best_sum = ssum
            best_sol = sol

    return best_sol[:n]
