import numpy as np
from scipy.optimize import minimize, dual_annealing
import math
import time

def solve(n):
    t0 = time.time()
    
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    def get_corners(cx, cy, angle, side):
        th = angle * 2.0 * math.pi
        co = math.cos(th)
        si = math.sin(th)
        h = side * 0.5
        return [
            (cx - h * co + h * si, cy - h * si - h * co),
            (cx + h * co + h * si, cy + h * si - h * co),
            (cx + h * co - h * si, cy + h * si + h * co),
            (cx - h * co - h * si, cy - h * si + h * co),
        ]

    def check_overlap(poly1, poly2, tol=1e-10):
        for i in range(4):
            x1, y1 = poly1[i]
            x2, y2 = poly1[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            d_min1 = d_max1 = ax * poly1[0][0] + ay * poly1[0][1]
            for k in range(1, 4):
                d = ax * poly1[k][0] + ay * poly1[k][1]
                d_min1 = min(d_min1, d)
                d_max1 = max(d_max1, d)
            d_min2 = d_max2 = ax * poly2[0][0] + ay * poly2[0][1]
            for k in range(1, 4):
                d = ax * poly2[k][0] + ay * poly2[k][1]
                d_min2 = min(d_min2, d)
                d_max2 = max(d_max2, d)
            if d_max1 + tol <= d_min2 or d_max2 + tol <= d_min1:
                return True
        return False

    def construct_initial_grid(m):
        side = 1.0 / m
        sol = []
        idx = 0
        for i in range(m):
            for j in range(m):
                sol.append(
                    ((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                )
            if idx >= n - 1:
                break
        return sol

    best_sol = None
    best_score = 0

    def large_m_grid(m):
        if m * m >= n:
            side_grid = 1.0 / m
            ss = np.array([side_grid] * min(n, m * m))
            rs = np.array([[0.5, 0.5]] * min(n, m * m))
            # Create more compact arrangement
            cnt = min(n, m * m)
            sol = []
            idx = 0
            for i in range(m):
                for j in range(m):
                    if idx >= n:
                        break
                    sol.append(
                        ((i + 0.5) * side_grid, (j + 0.5) * side_grid, 0.0, side_grid)
                    )
                    idx += 1
            score = sum(x[3] for x in sol)
            if score > best_score:
                best_score = score
                best_sol = sol
        return

    large_m_grid(max(1, min(n, 2 * int(np.sqrt(n)))))
    for m in range(1, 20):
        if m * m >= n:
            large_m_grid(m)

    def objective(x):
        return -np.sum(x[:n])

    def bounds(n=10):
        ret = []
        for _ in range(n):
            if fany:
                ret.extend([(-1e5, 1e5), (-1e5, 1e5), (0.0, 0.25), (0.0, 1.0)])
            else:
                ret.extend([(-1e5, 1e5), (-1e5, 1e5), (-1e5, 1e5), (0.0, 1.0)])
        return ret

    fany = True
    candidates = []
    for grid_m in range(1, 20):
        if grid_m * grid_m >= n:
            cand = construct_initial_grid(grid_m)
            s = sum(x[3] for x in cand)
            if s > best_score:
                best_score = s
                best_sol = cand
                candidates.append(tuple(cand))

    for m in range(5, 15):
        if m * m < n:
            continue
        grid_side = 1.0 / m
        for i in range(min(n, m * m)):
            if i < m * m:
                # Offsets for offset grid
                if i >= m:
                    offset_row = i // m
                    offset_col = i % m
                    s = grid_side + 0.001
                else:
                    s = grid_side
                cx = (offset_col + 0.5) * grid_side + (offset_row - 0.5) * 0.5
                cy = (m - 1 - (offset_row + 0.5)) * grid_side + 0.5
                candidates.append((
                (cx, cy, 0.0, min(s, 1.0 - 0.001))
                ))

    if time.time() - t0 > 55:
        return best_sol[:n] if best_sol else [(0.5, 0.5, 0.0, 1.0 / n)]

    def score_with_boxes(sol):
        placed = []
        w_pos = []
        for i, q in enumerate(sol):
            # approximate bounding box
            s = q[3]
            cx, cy, ang = q[0], q[1], q[2]
            h = s/2
            th = ang * 2*math.pi
            co = math.cos(th)
            si = math.sin(th)
            r = s * (abs(co) + abs(si)) / 2
            x1 = cx - r
            x2 = cx + r
            y1 = cy - s/2
            y2 = cy + s/2
            x_min = min([
                cx - h*co + h*si,
                cx + h*co + h*si,
                cx + h*co - h*si,
                cx - h*co - h*si
            ])
            x_max = max([
                cx - h*co + h*si,
                cx + h*co + h*si,
                cx + h*co - h*si,
                cx - h*co - h*si
            ])
            y_min = min([
                cy - h*si - h*co,
                cy + h*si - h*co,
                cy + h*si + h*co,
                cy - h*si + h*co
            ])
            y_max = max([
                cy - h*si - h*co,
                cy + h*si - h*co,
                cy + h*si + h*co,
                cy - h*si + h*co
            ])
            x_min = max(x_min, -0.001)
            x_max = min(x_max, 1.001)
            y_min = max(y_min, -0.001)
            y_max = min(y_max, 1.001)
            placed.append((x_min, x_max, y_min, y_max))
            w_pos.append((cx, cy, x_max - x_min + 0.001, y_max - y_min + 0.001))

        total_score = sum(q[3] for q in sol)
        valid = True
        for i in range(n):
            for j in range(i+1, n):
                if check_overlap(placed[i], placed[j], 1e-9):
                    valid = False
                    break
        return round(total_score, 8) if valid else float('nan'), sol

    def continuous_relaxation(n_sq):
        side = 0.5 ** (n_sq // 20)
        return [[((i + 0.5) * 1.0, (j + 0.5) * 1.0, 0.0, 1.0) for i in range(int(np.sqrt(n_sq)) + 1) for j in range(int(np.sqrt(n_sq)) + 1)][:n_sq]]

    final_sol = []
    candidates_copy = candidates.copy()
    
    for cand in candidates_copy[:100]:
        # Valid check and score
        placed_corners = [get_corners(q[0], q[1], q[2], c) for q, c in zip(cand, [q3 for _, _, _, q3 in cand])]
        s = 0.0
        for i, xc in enumerate(cand):
            s += xc[3]
            placed_corners[i] = get_corners(xc[0], xc[1], xc[2], xc[3])
            for j in range(i+1, len(cand)):
                if check_overlap(placed_corners[i], placed_corners[j]):
                    s = 0.0
                    break
            if s == 0:
                break
        else:
            if s > best_score:
                best_score = s
                best_sol = cand[:n]
    
    return best_sol[:n] if best_sol else [(0.5, 0.5, 0.0, 1.0 / n)]
