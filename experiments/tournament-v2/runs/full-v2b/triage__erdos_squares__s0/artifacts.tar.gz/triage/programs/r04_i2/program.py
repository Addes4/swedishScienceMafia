import math
import time


def _corners(cx, cy, a, s):
    th = a * 2.0 * math.pi
    co = math.cos(th)
    si = math.sin(th)
    h = s * 0.5
    return (
        (cx - h * co + h * si, cy - h * si - h * co),
        (cx + h * co + h * si, cy + h * si - h * co),
        (cx + h * co - h * si, cy + h * si + h * co),
        (cx - h * co - h * si, cy - h * si + h * co),
    )


def _sep(p1, p2):
    for poly in (p1, p2):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) & 3]
            ax = y1 - y2
            ay = x2 - x1
            d = ax * p1[0][0] + ay * p1[0][1]
            lo1 = hi1 = d
            for k in range(1, 4):
                d = ax * p1[k][0] + ay * p1[k][1]
                if d < lo1:
                    lo1 = d
                elif d > hi1:
                    hi1 = d
            d = ax * p2[0][0] + ay * p2[0][1]
            lo2 = hi2 = d
            for k in range(1, 4):
                d = ax * p2[k][0] + ay * p2[k][1]
                if d < lo2:
                    lo2 = d
                elif d > hi2:
                    hi2 = d
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return True
    return False


def _build_centers(G):
    centers = set()
    for k in range(1, G + 1):
        for i in range(k):
            for j in range(k):
                centers.add((round((i + 0.5) / k, 6), round((j + 0.5) / k, 6)))
    for i in range(G + 1):
        for j in range(G + 1):
            centers.add((round((i + 0.5) / (G + 1), 6), round((j + 0.5) / (G + 1), 6)))
    return sorted(centers)


def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # guaranteed valid baseline: smallest m x m grid holding all n squares
    m = 1
    while m * m < n:
        m += 1
    side = 1.0 / m
    base = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
            for i in range(m) for j in range(m)][:n]
    best_sol = base
    best_sum = sum(q[3] for q in best_sol)

    centers = _build_centers(8)
    angles = (0.0, 0.25, 0.125)

    # upper bound on side for each (center, angle): fits inside the unit square
    ub = {}
    for (cx, cy) in centers:
        mm = min(cx, 1.0 - cx, cy, 1.0 - cy)
        for a in angles:
            th = a * 2.0 * math.pi
            cc = abs(math.cos(th)) + abs(math.sin(th))
            ub[(cx, cy, a)] = 2.0 * mm / cc if cc > 0 else 0.0

    def best_next(placed_corners, floor):
        bs = floor
        bc = None
        for (cx, cy) in centers:
            for a in angles:
                u = ub[(cx, cy, a)]
                if u <= bs:
                    continue
                lo = bs
                hi = u
                for _ in range(11):
                    mid = (lo + hi) * 0.5
                    p1 = _corners(cx, cy, a, mid)
                    good = True
                    for pc in placed_corners:
                        if not _sep(p1, pc):
                            good = False
                            break
                    if good:
                        lo = mid
                    else:
                        hi = mid
                if lo > bs + 1e-9:
                    bs = lo
                    bc = (cx, cy, a)
        return bs, bc

    def place_at(pc, cx, cy, a, target):
        """Largest square at (cx,cy,a) not overlapping placed, <= target."""
        u = ub[(cx, cy, a)]
        hi = min(u, target)
        if hi <= 1e-9:
            return 0.0, None
        # check feasibility at hi
        p1 = _corners(cx, cy, a, hi)
        good = True
        for pc2 in pc:
            if not _sep(p1, pc2):
                good = False
                break
        if good:
            return hi, p1
        lo = 0.0
        for _ in range(14):
            mid = (lo + hi) * 0.5
            p1 = _corners(cx, cy, a, mid)
            good = True
            for pc2 in pc:
                if not _sep(p1, pc2):
                    good = False
                    break
            if good:
                lo = mid
            else:
                hi = mid
        if lo <= 1e-9:
            return 0.0, None
        return lo, _corners(cx, cy, a, lo)

    def pack_target(S, budget, sizes_count=None):
        """Try to pack n squares with total side <= S via decreasing-size greedy.
        Returns (success_frac_reached, sol)."""
        # candidate size targets: geometric-ish decrease from 1 down
        # We distribute total budget S across n squares, decreasing.
        # Try a few distributions.
        best_local = None
        best_local_sum = -1.0
        # distribution parameter: ratio r in (0,1), sizes s_i = c * r^i, sum = S
        for r in (0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.93, 0.95):
            if time.time() - t0 > budget:
                break
            # s_i = c * r^i, i=0..n-1, c*(1-r^n)/(1-r) = S
            if r >= 1.0:
                continue
            geom = (1.0 - r ** n) / (1.0 - r)
            c = S / geom
            targets = [c * (r ** i) for i in range(n)]
            pc = []
            placed_sum = 0.0
            ok_fail = False
            sol = []
            # place in decreasing target order but each placement chooses best pos
            for i in range(n):
                tgt = targets[i]
                best_s, best_c, best_p = 0.0, None, None
                for (cx, cy) in centers:
                    for a in angles:
                        # quick reject
                        if ub[(cx, cy, a)] <= best_s + 1e-9:
                            continue
                        s, p1 = place_at(pc, cx, cy, a, tgt)
                        if s > best_s + 1e-9:
                            best_s = s
                            best_c = (cx, cy, a)
                            best_p = p1
                if best_c is None:
                    sol.append((0.5, 0.5, 0.0, 0.0))
                    pc.append(_corners(0.5, 0.5, 0.0, 0.0))
                    ok_fail = True
                else:
                    sol.append((best_c[0], best_c[1], best_c[2], best_s))
                    pc.append(best_p)
                    placed_sum += best_s
                if time.time() - t0 > budget:
                    break
            while len(sol) < n:
                sol.append((0.5, 0.5, 0.0, 0.0))
            tot = sum(q[3] for q in sol)
            if tot > best_local_sum:
                best_local_sum = tot
                best_local = sol
            if not ok_fail and abs(placed_sum - S) < 1e-6:
                # achieved full target
                return True, best_local
        if best_local is None:
            best_local = [(0.5, 0.5, 0.0, 0.0)] * n
            best_local_sum = 0.0
        return False, best_local

    # baseline grid strategies recorded first (best_sum already known)
    # Also try a few uniform grids (k x k grid of equal squares)
    for mm in range(1, n + 2):
        if mm * mm >= n:
            s = 1.0 / mm
            cand = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
                    for i in range(mm) for j in range(mm)][:n]
            v = sum(q[3] for q in cand)
            if v > best_sum:
                best_sum = v
                best_sol = cand

    # Bisection-guided greedy on target total sum S
    lo = best_sum
    hi = float(n)  # trivially loose upper bound (side<=1 each)
    # tighter upper bound: n squares in unit square, sum bounded by sqrt(n)*?
    # keep hi = n as safe upper bound
    total_budget = 52.0
    it = 0
    while time.time() - t0 < total_budget and it < 22:
        it += 1
        # remaining time shrinks
        remain = total_budget - (time.time() - t0)
        if remain <= 0.5:
            break
        mid = (lo + hi) * 0.5
        per_call = min(remain * 0.5, 4.0 + remain * 0.2)
        ok, sol = pack_target(mid, t0 + per_call)
        v = sum(q[3] for q in sol)
        if v > best_sum:
            best_sum = v
            best_sol = sol
        if ok and v >= mid - 1e-6:
            lo = v
        else:
            # even if not full target, if we exceeded current lo raise it
            if v > lo:
                lo = v
            else:
                hi = mid

    return best_sol[:n]
