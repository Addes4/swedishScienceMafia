# EVOLVE-BLOCK-START
"""Recursive guillotine packing: partition n into sums of perfect squares, place a
k x k grid of equal squares inside each resulting rectangular region."""

import math
import random


def _best_partitions(n, max_parts=None):
    """Return a list of multisets of perfect squares that sum to n (as tuples of ks)."""
    squares = [k * k for k in range(1, int(math.isqrt(n)) + 1)]
    ks = [k for k in range(1, int(math.isqrt(n)) + 1)]
    results = []

    def rec(rem, start_idx, cur):
        if rem == 0:
            results.append(tuple(sorted(cur, reverse=True)))
            return
        if max_parts is not None and len(cur) >= max_parts:
            return
        for i in range(start_idx, -1, -1):
            if squares[i] <= rem:
                cur.append(ks[i])
                rec(rem - squares[i], i, cur)
                cur.pop()

    rec(n, len(squares) - 1, [])
    # De-duplicate
    seen = set()
    out = []
    for r in results:
        if r not in seen:
            seen.add(r)
            out.append(r)
    # Prefer balanced-ish partitions and fewer parts
    out.sort(key=lambda p: (len(p), -min(p)))
    return out


def _pack_into_regions(ks, w=1.0, h=1.0, x0=0.0, y0=0.0):
    """Given a list of k values, split the (w x h) region at (x0, y0) recursively
    (guillotine) so each k gets a sub-region as square-ish as possible."""
    if not ks:
        return []
    if len(ks) == 1:
        k = ks[0]
        s = min(w, h) / k
        cx = x0 + w / 2.0
        cy = y0 + h / 2.0
        sw = w / k
        sh = h / k
        side = s
        out = []
        total_w = k * sw
        total_h = k * sh
        # centre the k x k grid inside the region (it uses s x s total)
        gx0 = x0 + (w - s) / 2.0
        gy0 = y0 + (h - s) / 2.0
        for i in range(k):
            for j in range(k):
                out.append((gx0 + (i + 0.5) * s, gy0 + (j + 0.5) * s, 0.0, s))
        return out

    # split ks into two groups whose total "area need" is close
    areas = [k * k for k in ks]
    tot = sum(areas)
    # Greedy split
    order = sorted(range(len(ks)), key=lambda i: -areas[i])
    g1, g2 = [], []
    s1 = 0
    for idx in order:
        if s1 * 2 <= tot:
            g1.append(ks[idx])
            s1 += areas[idx]
        else:
            g2.append(ks[idx])
    if not g1:
        g1, g2 = [ks[0]], ks[1:]
    if not g2:
        g1, g2 = ks[:-1], [ks[-1]]

    a1 = sum(k * k for k in g1)
    a2 = sum(k * k for k in g2)
    frac = a1 / (a1 + a2) if (a1 + a2) > 0 else 0.5

    # Try both split directions and pick the one giving larger resulting sides.
    # Estimate: sum of sides within region.
    out = []
    # vertical split
    w1 = w * frac
    w2 = w - w1
    v_out = (_pack_into_regions(g1, w1, h, x0, y0) +
             _pack_into_regions(g2, w2, h, x0 + w1, y0))
    # horizontal split
    h1 = h * frac
    h2 = h - h1
    h_out = (_pack_into_regions(g1, w, h1, x0, y0) +
             _pack_into_regions(g2, w, y0 + h1, h2))
    return v_out if v_out else h_out


def _score(squares):
    return sum(s[3] for s in squares)


def _partition_values(n):
    """Candidate partitions of n into sums of squares, ordered by promise."""
    best = _best_partitions(n)
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    candidates = _partition_values(n)
    # Limit for performance
    if len(candidates) > 400:
        candidates = candidates[:400]

    best_squares = None
    best_val = -1.0

    for ks in candidates:
        squares = _pack_into_regions(list(ks))
        if len(squares) < n:
            squares = squares + [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        squares = squares[:n]
        val = _score(squares)
        if val > best_val:
            best_val = val
            best_squares = squares

    if best_squares is None:
        best_squares = [(0.5, 0.5, 0.0, 0.0)] * n

    # Fallback plain grid if better
    k = math.isqrt(n)
    if k >= 1:
        s = 1.0 / k
        grid = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
        grid += [(0.5, 0.5, 0.0, 0.0)] * (n - len(grid))
        grid = grid[:n]
        gv = _score(grid)
        if gv > best_val:
            best_val = gv
            best_squares = grid

    return best_squares
# EVOLVE-BLOCK-END
