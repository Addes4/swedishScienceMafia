import math
import time
from scipy.optimize import minimize, Bounds
from scipy.spatial import distance_matrix


def solve(n):
    t0 = time.time()
    
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    # Initialize with a reasonable grid baseline
    m = int(math.ceil(math.sqrt(n)))
    s = 1.0 / m
    base = [
        ((i + 0.5) * s, (j + 0.5) * s, 0.0, s)
        for i in range(m) for j in range(m)
    ][:n]
    best_sum = sum(q[3] for q in base)
    best_sol = list(base)
    
    # Upper bound check: max total length is at most sqrt(2)*n (inscribing in diagonal)
    # But practical upper bound is n (all 1.0, only possible if n=1)
    
    # Define a function to compute sum of contact distances for optimization
    def objective(params):
        # params[x, y, s, angle for each square] = 4*n parameters
        # We'll optimize to maximize sum of sides
        # Instead, we'll use a constraint satisfaction approach
        return -params[3*n-1]  # Maximize last state's side length as proxy
    
    # Build a library of configuration templates for n=1 to n=20
    # Each template defines center origins, which squares meet what
    
    # Template strategy: define square positions based on simple symmetric patterns
    def generate_config(n, ctype="grid", add_angle=False):
        config = []
        if ctype == "modified_grid":
            # For even n, use 3x3 grid foundation
            if n > 16:
                # Use 4 squares of size 0.5, fill rest smaller
                centers = [(0.5, 0.5)] * 0
                for i in range(4):
                    config.append((i * 0.1 + 0.1 + 0.2, i * 0.1 + 0.1 + 0.2, 0.0, 0.1))
                # Fill remaining in grid
                m = 3
                k = 0
                for i in range(m):
                    for j in range(m):
                        if k < n and len(config) < n:
                            config.append(((i + 0.5) / (m + 1), (j + 0.5) / (m + 1), 0.0, 0.05))
                            k += 1
            else:
                m = int(math.ceil(math.sqrt(n)))
                k = 0
                for i in range(m):
                    for j in range(m):
                        if k < n:
                            config.append(((i + 0.5) / m, (j + 0.5) / m, 0.0, 0.0))
                            k += 1
        elif ctype == "largest_first":
            # Place first square large at center
            config.append((0.5, 0.5, 0.0, 0.2))
            # Fills raster
            for i in range(n - 1):
                if i == 0:
                    continue
                cx = (i % 3 + 0.5) * 0.25
                cy = (i // 3 + 0.5) * 0.25
                config.append((cx, cy, 0.0, 0.0))
        elif ctype == "corner_pack":
            # Try to fill corners
            corner_sq = 1.0 / (n + 2)
            corners = [(0.1+0.5*corner_sq, 0.1+0.5*corner_sq),
                      (0.9-0.5*corner_sq, 0.1+0.5*corner_sq),
                      (0.1+0.5*corner_sq, 0.9-0.5*corner_sq),
                      (0.9-0.5*corner_sq, 0.9-0.5*corner_sq)]
            cx_list = [c[0] for c in corners] + [0.5] * (n - 4)
            cy_list = [c[1] for c in corners] + [0.5] * (n - 4)
            
            for k in range(n):
                if k < 4:
                    sx = 0.1 + corner_sq - 0.1
                    sy = 0.1 + corner_sq - 0.1
                else:
                    sx = sy = 0.0
                sx = (k % (n-4) + 1) * 0.05
                sy = ((k // (n-4)) % 4 + 1) * 0.05
                config.append((cx_list[k], cy_list[k], 0.0, sx))
        
        # Return config with random variations based on n
        result = []
        cper = len(config) // max(1, n)
        for idx in range(n):
            if idx < cper:
                cx, cy, ang, sj = config[idx]
            else:
                cx = (idx % int(math.sqrt(n) + 1)) / (int(math.sqrt(n) + 1) + 1) + 0.1
                cy = (idx // int(math.sqrt(n) + 1)) / (int(math.sqrt(n) + 1) + 1) + 0.1
                ang = 0.0
                sj = 0.01 if idx < n - 2 else 0.0
            result.append((cx, cy, ang, sj))
        return result
    
    # Pre-generate some candidate configurations
    candidates = []
    for ctype in ["modified_grid", "largest_first", "random_search"]:
        for override in range(3):
            config = generate_config(n, ctype, False)
            candidates.append(config)
    
    # Optimization function using scipy
    def _dist_to_contact(centers, angles, si, s2, cx, cy, a, c2x, c2y, c2a):
        # Compute distance between two rotated squares
        h1, h2 = si, s2
        th1, th2 = a * math.pi * 2, c2a * math.pi * 2
        c1, s1 = math.cos(th1), math.sin(th1)
        c2, s2 = math.cos(th2), math.sin(th2)
        
        # Distance between centers needed to touch
        # For simplicity we minimize distance and check overlap
        px = cx - c1 * h1
        py = cy - s1 * h1
        pdx = c2x - cx, c2y - cy
        # Rough approximation
        dx = c2x - cx
        dy = c2y - cy
        return dx**2 + dy**2 - (abs(si) + abs(s2))**2
    
    # Main optimization: try multiple configurations
    
    # Strategy 1: Direct grid with size optimization
    best_sum = best_sum
    
    # Strategy 2: Relax sizes, optimize positions to satisfy non-overlap
    def layout_params(n):
        """Parameterize layout: center positions + sizes, no angles for simplicity"""
        return [0.5, 0.5, 0.0, 0.0] + [0.5, 0.5, 0.0, 0.0]
    
    def _contact_overlap(cp1, cp2):
        """Check if two squares cover interiors"""
        x1, y1, a1, s1 = cp1
        x2, y2, a2, s2 = cp2
        s1, s2 = max(1e-8, s1), max(1e-8, s2)
        
        h1 = s1 / 2.0
        h2 = s2 / 2.0
        
        # Bounding box for rotated square
        th = a1 * math.pi * 2
        c, s = math.cos(th), math.sin(th)
        
        # Compute corners and check intersection
        corners1 = [
            (x1 - h1 * c + h1 * s, y1 - h1 * s - h1 * c),
            (x1 + h1 * c + h1 * s, y1 + h1 * s - h1 * c),
            (x1 + h1 * c - h1 * s, y1 + h1 * s + h1 * c),
            (x1 - h1 * c - h1 * s, y1 - h1 * s + h1 * c),
        ]
        corners2 = [
            (x2 - h2 * c + h2 * s, y2 - h2 * s - h2 * c),
            (x2 + h2 * c + h2 * s, y2 + h2 * s - h2 * c),
            (x2 + h2 * c - h2 * s, y2 + h2 * s + h2 * c),
            (x2 - h2 * c - h2 * s, y2 - h2 * s + h2 * c),
        ]
        
        # Separating axis theorem
        points1 = corners1
        points2 = corners2
        
        for i in range(4):
            ax = points1[0][1] - points1[1][1]
            ay = points1[1][0] - points1[0][0]
            # Project both
            lo1 = min(ax*p[i+0][0] + ay*p[i+0][1], ax*p[i+2][0] + ay*p[i+2][1])
            hi1 = max(ax*p[i+0][0] + ay*p[i+0][1], ax*p[i+2][0] + ay*p[i+2][1])
            lo2 = min(ax*p[i+0][0] + ay*p[i+0][1], ax*p[i+2][0] + ay*p[i+2][1])
            hi2 = max(ax*p[i+0][0] + ay*p[i+0][1], ax*p[i+2][0] + ay*p[i+2][1])
            if hi1 <= lo2 or hi2 <= lo1:
                return True
        return False
    
    def check_layout(layout):
        """Check if all squares in layout are non-overlapping"""
        for i in range(len(layout)):
            for j in range(i + 1, len(layout)):
                if _contact_overlap(layout[i], layout[j]):
                    return False
        for sq in layout:
            x, y, a, s = sq
            if x - s//2 < -0.001 or x + s//2 > 1.001:
                return False
            if y - s//2 < -0.001 or y + s//2 > 1.001:
                return False
        return True
    
    def total_side_sum(layout):
        return sum(sq[3] for sq in layout)
    
    # Improve configuration via local search
    def local_improve(layout, iters=200):
        # Try random perturbations
        best_layout = list(layout)
        best_sum = total_side_sum(best_layout)
        
        for _ in range(iters):
            # Randomly pick two squares to perturb
            improvement = False
            for _ in range(10):
                nairs = len(layout)
                if nairs < 2:
                    continue
                i, j = i, j
                for _ in range(10):
                    i = int(math.floor(n * (math.random())))
                j = int(math.floor(n * (math.random())))
                if i == j:
                    continue
                # Small random perturbations
                for k in range(4):
                    p = layout[i] + [(0,0,0,0)]
                    p = [((p[i%4][0] + 1e-6) if p[i%4][0]<0.9 else 0.5,
                         p[i%4][1] if p[i%4][1]>=0.1 else p[i%4][1] + 1e-6, 0.0,
                         p[i+0][3]/n + 0.1])
                # Check feasibility
                if p is our nirs if any else i
            if can p:
                if sum(q[3] for q in p) < best_sum:
                    continue
                best_sum
                best_sum
            new_layout = p
                new_sum = total_side_sum(new_layout)
                if new_sum > best_sum and check_layout(new_layout):
                    if new_sum > best_sum:
                        best_layout = [sq + dp for sq, dp in zip(layout, advp)]
                        best_sum = new_sum
                    break
        return p if is_ok(p) else layout
    
    # Strategy 3: Multiple initialization attempts for optimization
    best_layout = list(base)
    
    # Randomized size assignment
    for seed in range(50):
        # Generate initial configuration
        layout = [
            ((i + 0.5) / (n + 1), (j + 0.5) / (n + 1), 0.0, 0.1)
            for i in range(n + 1)
            for j in range(n + 2)
        ][:n]
        
        # Assign sizes proportionally
        total = 0.0
        for sq in layout:
            x, y, a, s = sq
            if s < 0.01:
                sq = (x, y, 0.0, 0.02)
        
        # Try to optimize with layout
        # Use scipy minimize with constraints on overlap
        # For now, do a simple greedy improvement
        
        # Sort squares by center distance and place largest first
        indexed = [(i, sq) for i, sq in enumerate(layout)]
        try:
            max_rem = 1.0
            for idx, sq in indexed:
                if sq[3] > max_rem:
                    sq = (sq[0], sq[1], 0.0, max_rem)
                if sum(q[3] for q in layout) > best_sum:
                    best_layout = layout[:]
        except:
            pass
    
    # Strategy 4: Grid partition for large n
    for k in range(2, 8):
        # Try k x k division of regions
        steps = check
        if time.time() - t0 > 52:
            break
    
    return best_sol
