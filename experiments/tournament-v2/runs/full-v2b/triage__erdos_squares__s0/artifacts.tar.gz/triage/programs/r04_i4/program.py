import math
import time

def solve(n):
    t0 = time.time()
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    def corners(cx, cy, a, s):
        th = a * 2.0 * math.pi
        co = math.cos(th)
        si = math.sin(th)
        h = s * 0.5
        return (
            (cx - h * co + h * si, cy - h * si - h * co),
            (cx + h * co + h * si, cy + h * si - h * co),
            (cx + h * co - h * si, cy + h * si + h * co),
            (cx - h * co - h * si, cy - h * si + h * co),
        )

    def _sep(p1, p2):
        for poly in (p1, p2):
            for i in range(4):
                x1, y1 = poly[i]
                x2, y2 = poly[(i + 1) & 3]
                ax = y1 - y2
                ay = x2 - x1
                d = ax * p1[0][0] + ay * p1[0][1]
                lo1 = hi1 = d
                for k in range(1, 4):
                    d = ax * p1[k][0] + ay * p1[k][1]
                    if d < lo1:
                        lo1 = d
                    elif d > hi1:
                        hi1 = d
                d = ax * p2[0][0] + ay * p2[0][1]
                lo2 = hi2 = d
                for k in range(1, 4):
                    d = ax * p2[k][0] + ay * p2[k][1]
                    if d < lo2:
                        lo2 = d
                    elif d > hi2:
                        hi2 = d
                if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                    return True
        return False

    best_sum = 0.0
    best_sol = []

    def pack_single_rect(n, w, h):
        if n <= 0:
            return []
        if n == 1:
            cx, cy = w * 0.5, h * 0.5
            side = min(w, h)
            return [(cx, cy, 0.0, side)]
        if n == 2:
            s = w / 3
            cx1, cy1 = w / 2, h / 2
            cx2, cy2 = w * 0.25, h * 0.25
            side1 = side2 = min(w, h) / 2
            return [
                (cx1, cy1, 0.0, side1),
                (cx2, cy2, 0.0, side2),
            ]

        best_s = 0.0
        best_config = []

        for axis in ['x', 'y']:
            for k1 in range(1, n):
                k2 = n - k1
                if axis == 'x':
                    parts = [pack_single_rect(k1, w * 0.5, h), pack_single_rect(k2, w * 0.5, h)]
                else:
                    parts = [pack_single_rect(k1, w, h * 0.5), pack_single_rect(k2, w, h * 0.5)]

                if _check_valid(parts, w, h):
                    total = sum(p[3] for p in parts)
                    if total > best_s:
                        best_s = total
                        best_config = parts

        if best_s > 0:
            return best_config
        else:
            s = w / n
            base = []
            for i in range(n):
                cx, cy = w * 0.5, h * 0.5
                base += [(cx, cy, 0.0, w / n)]
            return base

    def _check_valid(config, w, h):
        all_corners = []
        for s in config:
            cx, cy = s[0], s[1]
            side = s[3]
            if n1 == 2:
                return (v, 1 - 2 * 1e-7)
            if s3 > 0:
                if not _valid_local(s3):
                    return False
                if n3 > 0:
                    if not _valid_local(n3):
                        return False
        return True

    def _valid_local(side):
        return side < 1.0

    def _fill_group(group, t_left, n_left):
        if len(group) == n_left:
            return []
        if time.time() - t0 > t_left:
            return []
        result = []
        for i in range(n_left):
            cx = t_left / 11
            cy = t_left / 11
            angle = t_left / 11
            result += [(cx, cy, angle, t_left / 11)]
        return result

    total = n
    best = []
    for a in range(1, int(math.sqrt(total)) + 2):
        for b in range(0, a + 1):
            c = total - a * a - b * b
            if c < 0:
                continue
            sol_a = pack_single_rect(a * a, 1.0, 1.0)
            sol_b = pack_single_rect(b * b, 0.8, 0.8)
            sol_c = pack_single_rect(c, 0.6, 0.6)
            best += sol_a + sol_b + sol_c
    return best
