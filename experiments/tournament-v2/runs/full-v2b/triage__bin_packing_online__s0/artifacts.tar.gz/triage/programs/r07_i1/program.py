import numpy as np

class State:
    def __init__(self):
        self.num_bins = 0
        self.loads = []  # current loads of active bins (non-negative)
        # Sum of squared remaining capacities = sum_{b in active bins} (100 - load_b)^2
        self.sum_sq_rem = 0.0

def priority(item, bins):
    global state
    if 'state' not in globals() or state is None:
        state = State()
    
    # `bins` contains remaining capacities of bins the item fits in.
    # But we also need to consider unused bins (remaining capacity 100) separately.
    # The harness shows unused bins as capacity 100, but they are not yet "created" in our model.
    # When we place an item into an existing bin, we update its load.
    # When we place into a new bin, we add a new bin with load=item.
    # For scoring, we need the sum of squared remaining capacities across all current active bins.
    # We have the current global state: list of loads.
    # For each candidate bin (index in bins), we compute the new sum_sq_rem if item went there.
    
    # Edge case: if no bins provided (should never happen, because unused bins always present)
    # but just in case, fallback to simple score.
    if len(bins) == 0:
        return np.array([], dtype=np.float64)
    
    # We need to map bins (indices in the presented array) to actual loads.
    # The bins array order matches the order of active bins plus unused bins.
    # Active bins are state.loads indices 0..state.num_bins-1.
    # Unused bins are state.num_bins .. len(bins)-1.
    
    remaining_capacity = bins
    num_candidates = len(bins)
    
    # For speed, precompute some things
    current_sum_sq = state.sum_sq_rem
    
    # For each candidate, we'll compute new_sum_sq.
    scores = np.empty(num_candidates, dtype=np.float64)
    
    # Active bins (indices < state.num_bins)
    # For these, the new load = 100 - bins[i] + item, so new rem = (100 - (old_load + item))
    # Old load is known: state.loads[i]
    # Alternatively: new_rem = bins[i] - item  (since bins[i] is current remaining capacity)
    # But we need the new remaining capacity. Yes, after placing item, remaining capacity = bins[i] - item.
    # For unused bins (capacity 100), new remaining capacity = 100 - item.
    
    for i in range(num_candidates):
        rem_i = remaining_capacity[i]
        # Determine if bin i is an existing active bin or a new one.
        if i < state.num_bins:
            old_load = state.loads[i]
            # Old remaining capacity = 100 - old_load
            # Verify that this matches rem_i? It should, but we don't need to check.
            # New remaining capacity after placement = rem_i - item
            new_rem = rem_i - item
            # The change in sum of squares:
            # old contribution: (100 - old_load)^2 = rem_i^2
            # new contribution: (new_rem)^2
            delta_sq = new_rem**2 - rem_i**2
        else:
            # New bin: currently unused, its contribution to sum_sq_rem is 100^2 = 10000
            # But wait: unused bins are not yet in state.sum_sq_rem because we only track active bins.
            # Our state.sum_sq_rem currently does *not* include unused bins (since they are not active).
            # But we are considering placing into a new bin, which makes it active.
            # So we need to add its contribution from 0 (not in sum) to (100 - item)^2
            # Actually, if we never counted unused bins, then the base sum_sq_rem doesn't include them.
            # Adding a new bin changes sum by adding (100 - item)^2.
            # Also, we must be careful: there might be many unused bins, but we only care about the one we use.
            # So delta_sq = (100 - item)**2   (since previously 0)
            new_rem = 100 - item
            delta_sq = new_rem**2  # because 0^2 before
        
        # Score is negative of new sum_sq
        # But wait: since we're comparing candidates, we can just use - (current_sum_sq + delta_sq)
        # Equivalent to use -delta_sq as score? Actually, higher score is better.
        # Scores = - (new_sum_sq) = -(current_sum_sq + delta_sq)
        # Since current_sum_sq constant, ranking by -delta_sq is same. But careful: ties with same delta_sq should keep first bin.
        # Using -delta_sq is fine.
        scores[i] = -delta_sq
    
    return scores

def priority_with_state_update(item, bins):
    # This is the actual function called by harness.
    # It returns scores, but we also need to update state after the harness chooses bin.
    # Problem: The harness calls priority, then immediately places item into highest score bin (first on tie).
    # We don't get a callback after placement. So we must update state assuming the item will go into the bin we recommend.
    # However, we don't know if our recommended bin is exactly the one chosen? The highest score bin is chosen.
    # We must update state accordingly *within this call*.
    global state
    if 'state' not in globals() or state is None:
        state = State()
    
    remaining_capacity = bins
    num_candidates = len(bins)
    current_sum_sq = state.sum_sq_rem
    loads = state.loads
    
    # Compute delta_sq for all candidates simultaneously?
    # We can compute new_rem for all.
    new_rem = np.empty(num_candidates, dtype=np.int64)
    is_new_bin = np.zeros(num_candidates, dtype=bool)
    
    for i in range(num_candidates):
        if i < state.num_bins:
            new_rem[i] = remaining_capacity[i] - item
        else:
            new_rem[i] = 100 - item
            is_new_bin[i] = True
    
    # Delta sum of squares:
    # For active bins: old contribution = (100 - loads[i])**2, new = new_rem[i]**2.
    # But we can compute delta from remaining capacities directly.
    rem_i = remaining_capacity.astype(np.float64)
    delta_sq = new_rem.astype(np.float64)**2 - rem_i**2
    # For new bins, rem_i = 100, but we don't subtract 10000 because current sum doesn't include it.
    # So override delta_sq for new bins to just new_rem**2.
    delta_sq[is_new_bin] = new_rem[is_new_bin].astype(np.float64)**2
    
    # Scores
    scores = -delta_sq
    
    # Now determine which bin will be chosen (highest score, first on tie)
    best_idx = np.argmax(scores)  # returns first occurrence of max score
    
    # Update state accordingly
    if best_idx < state.num_bins:
        # place into existing bin
        state.loads[best_idx] += item
        # update sum_sq_rem
        state.sum_sq_rem += delta_sq[best_idx]
    else:
        # new bin
        state.loads.append(item)
        state.num_bins += 1
        state.sum_sq_rem += delta_sq[best_idx]
    
    return scores


# Keep the required function name
def priority(item, bins):
    return priority_with_state_update(item, bins)
