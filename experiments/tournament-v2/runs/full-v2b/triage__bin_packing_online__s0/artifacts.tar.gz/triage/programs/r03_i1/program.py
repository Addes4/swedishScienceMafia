import numpy as np

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.

    Item should be placed into the bin which maintains consistent post-insertion load
    across the system using exponential moving average of target "fill level".
    """
    # Initialize EMA if first request is made
    # Starting at 40.0 approximates mean item size and converges quickly
    if not hasattr(priority, "_ema"):
        priority._ema = 40.0

    # Compute post-insertion load for each bin
    # load = 100 - remaining_capacity + item
    post_load = 100 - bins + item

    # Update EMA after each placement using weight=0.2 for ~5 iteration response time
    priority._ema = 0.8 * priority._ema + 0.2 * post_load

    # Score bins: higher score means post-insertion load closer to target EMA
    # Positive deviation preferred (aligns with convergence to mean item size)
    return post_load - priority._ema
