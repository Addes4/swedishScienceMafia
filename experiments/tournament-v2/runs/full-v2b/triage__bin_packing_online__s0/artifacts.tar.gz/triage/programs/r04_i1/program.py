# EVOLVE-BLOCK-START
"""Online bin packing with harmonic-like size-class grouping.

Maintains K size classes with centers computed from recent items.
Each item is assigned to its nearest class, and bins are scored based
on fit quality and classification balance.
"""
import numpy as np

# Global state (can persist between calls)
_last_batch = np.zeros(2000, dtype=np.float64)
_last_idx = 0
_centers = None
_COUNT = 20
_BINS_PER_CLASS = 0
_bin_counts = np.zeros(_COUNT, dtype=np.int64)
_last_size_stats = np.zeros(_COUNT, dtype=np.float64)
_last_size_stats_idx = 0

def _update_state(item):
    global _last_idx, _last_size_stats_idx, _bin_counts
    
    # Track item
    _last_batch[_last_idx] = item
    _last_size_stats[_last_size_stats_idx] = item
    _last_idx = (_last_idx + 1) % len(_last_batch)
    _last_size_stats_idx = (_last_size_stats_idx + 1) % len(_last_size_stats)
    
    # Update class metadata
    if _centers is None or _last_idx > 0:
        _centers = np.percentile(_last_batch, [i * 100 / _COUNT for i in range(1, _COUNT)])
        _centers = np.unique(_centers)
        _centers = np.insert(_centers, 0, 1.0)
        _centers = np.append(_centers, 101.0)
    
    return len(_centers)

def priority(item, bins):
    global _centers, _bin_counts, _last_size_stats_idx
    
    if _centers is None or _last_idx == 0:
        _centers = np.array([1, 5, 10, 20, 40, 60, 80, 100], dtype=np.float64)
        _COUNT = len(_centers)
        _bin_counts = np.zeros(_COUNT, dtype=np.float64)
    
    # Classify item by size
    if len(_centers) == 0:
        return np.full_like(bins, np.nan, dtype=np.float64)
    
    class_idx = np.argmin(np.abs(_centers - item))
    
    # Compute fit score (tighter is better)
    fit = bins - item
    fit[fit < 0] = 0  # Assign zero if doesn't fit (shouldn't happen based on problem)
    
    # Count bins by utilization class
    utilization_low = bins < 30
    utilization_med = (bins >= 30) & (bins < 70)
    utilization_high = bins >= 70
    
    # Score: fit + class balance
    base_score = fit
    
    # Add harmonic bonus for tighter clusters and balanced usage
    bonus = 0.0
    # Prefer tighter residuals within same utilization ballpark
    if utilization_high:
        bonus += fit / 10.0
    elif utilization_med:
        bonus += fit / 25.0
    else:
        bonus += fit / 100.0
        
    # Encourage balanced usage across classes via classification
    class_bonus = np.ones(len(bins), dtype=np.float64)
    
    return (base_score + class_bonus * bonus)

# EVOLVE-BLOCK-END
