# EVOLVE-BLOCK-START
"""Online primal-dual bin packing: superlinear marginal cost per bin.

Idea: for each bin with remaining capacity r, its current load is L = 100 - r.
Define a convex (superlinear) cost function of the load,
    f(L) = (L / 100)^p   with p > 1,
scaled by a globally maintained price level. The score of placing an item into a bin
is the *decrease* in marginal cost when moving the load from L to L + item, i.e.
    score = f(L + item) - f(L)
(equivalently the negative marginal cost increase). A bin that is nearly full has a
large convex term, so it strongly attracts items, while nearly empty bins have a tiny
term and stay available for future large items. This is the standard online
primal-dual / exponential-weight style rule in its polynomial form.

The exponent is kept modest (p ~ 1.6) so that mid-density bins are still preferred
over empties, which empirically balances "pack tightly" (best fit) against
"spread load" (worst fit). A small tie-breaking term in favour of tighter fits
is added to match the baseline on near-degenerate ties.
"""

import numpy as np

_EXP = 1.6
_SCALE = 100.0


def priority(item, bins):
    """Score bins by superlinear marginal cost increase of accepting `item`."""
    load = _SCALE - bins.astype(np.float64)
    # f(L) = (L/100)^p, convex and superlinear.
    base = (load / _SCALE) ** _EXP
    after = ((load + item) / _SCALE) ** _EXP
    # marginal increase of cost; lower marginal cost -> higher priority
    marginal = after - base
    # prefer tight fits as a gentle tie-break (equivalent to best fit at the margin)
    return -(marginal) - 1e-6 * (bins - item)
# EVOLVE-BLOCK-END
