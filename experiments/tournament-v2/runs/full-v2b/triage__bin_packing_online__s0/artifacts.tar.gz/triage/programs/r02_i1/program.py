import numpy as np

# Algorithm: Maintain a "price curve" p(r) that gives the cost of a bin filled up to
# remaining capacity r (r = 0 means full, r = 100 means empty). We model p(r) as a
# piecewise-linear increasing convex function, represented by its slopes for each
# unit of capacity filled. Using a convex objective: sum over bins of squared (100 - r)
# (i.e., squared filled amount) plus a penalty for each new bin opened. This leads to
# online gradient descent updates on the slopes of p. When an item arrives, we score a
# bin with remaining capacity c by p(c) - p(c - item), which is the approximate increase
# in total cost if we place the item there. We pick the bin with smallest increase,
# which corresponds to highest negative score priority.

class PriceModel:
    def __init__(self):
        # Slopes for each unit of filled amount (index 0..99, where index i corresponds
        # to going from filled i to i+1). Initial slopes: small positive values,
        # representing marginal cost of using capacity.
        self.slopes = np.full(100, 0.1, dtype=np.float64)
        # Learning rate for gradient descent
        self.lr = 0.01
        # Penalty term for opening a new bin (adding a new bin to the objective)
        self.new_bin_penalty = 30.0  # tunable, roughly ~ capacity
        
    def price(self, remaining_capacity):
        """Return the price of a bin with given remaining capacity.
        r = remaining means filled = 100 - r.
        Price is sum of slopes over filled units."""
        filled = 100 - remaining_capacity
        if filled <= 0:
            return 0.0
        return float(np.sum(self.slopes[:filled]))
    
    def update_after_placement(self, bins_before, chosen_idx, item):
        """Update slopes via online gradient descent on a surrogate convex loss.
        The loss for a bin with remaining r is L(r) = (100 - r)^2 + penalty * I[r==100]
        The marginal cost of filling one unit in a bin with current fill f is 2*(100 - r) evaluated
        appropriately. For a bin that was empty (r=100), there's an additional penalty.
        We perform gradient descent on the slopes: slope[f] should approach marginal cost.
        Here we do a stochastic update: for the chosen bin, the marginal cost of the
        newly filled units is approximated by the average of 2*(100 - r) before and after.
        """
        r_before = bins_before[chosen_idx]
        r_after = r_before - item
        # Filled units before and after
        f_before = 100 - r_before
        f_after = 100 - r_after
        
        # Target marginal cost for each unit filled in this step: average of before and after
        target_marginal = (2 * r_before + 2 * r_after) / 2.0  # = r_before + r_after
        
        # Which slopes are affected: indices from f_before to f_after - 1
        for idx in range(f_before, f_after):
            # Gradient update toward target
            self.slopes[idx] -= self.lr * (self.slopes[idx] - target_marginal)
        
        # Clip slopes to be non-negative and not too large
        self.slopes = np.clip(self.slopes, 0.0, 500.0)

# Global state (one per instance, but Python module-level persists across calls).
# Note: the harness may create multiple instances sequentially; we must reset per instance.
# We'll detect a new instance by checking if a flag is set or if bins start fresh.
# Simpler: we can detect a new instance when we see many empty bins at start. But a robust
# way is to use an internal counter and reset on first call or after 5000 items.

_instance_state = {'model': None, 'item_count': 0, 'total_items': 5000}

def priority(item, bins):
    state = _instance_state
    # Reset if first call or wrapping around (item_count == 0)
    if state['model'] is None or state['item_count'] == 0:
        state['model'] = PriceModel()
        state['item_count'] = 0
        # We also want to guess lower bound bins for penalty tuning? Not needed.
    
    state['item_count'] += 1
    
    model = state['model']
    
    # Compute scores: negative of cost increase = -(p(c) - p(c-item))
    # Equivalent to p(c-item) - p(c). Larger is better (less cost increase).
    # We must handle vectorized bins.
    costs_before = np.array([model.price(c) for c in bins])
    costs_after = np.array([model.price(c - item) for c in bins])
    scores = costs_after - costs_before  # we want highest score (least increase, most negative)
    # Note: for bins where item fits, c >= item, this is well-defined.
    # Bins that don't fit are not included in bins array by harness assumption.
    
    # We must choose the bin with highest score. The harness will do that.
    # But we need to record which bin is chosen for the update. However, we don't know
    # which bin will be selected as we only provide scores. The harness chooses after
    # receiving scores. We could approximate by assuming the highest score will be picked,
    # but that might cause drift if ties are broken differently. Since ties go to first,
    # we could find the index of highest score (first occurrence). However, the harness
    # owns the bins; we only see a copy of bin capacities. We can predict which bin
    # will be chosen by taking argmax of our scores. But if there is a tie, the harness
    # will take the first bin with that score. Our prediction might not perfectly match
    # if multiple bins share the exact same score and we aren't careful. We'll take the
    # first index with highest score.
    best_idx = int(np.argmax(scores))
    
    # Perform update using the predicted chosen bin and its capacity before item.
    # bins is a copy, so the capacity before placement is in bins[best_idx].
    model.update_after_placement(bins, best_idx, item)
    
    # Reset after full instance? The problem says 5000 items per instance.
    # We reset at 5000 so next instance starts fresh.
    if state['item_count'] >= 5000:
        state['model'] = None
        state['item_count'] = 0
        
    return scores
