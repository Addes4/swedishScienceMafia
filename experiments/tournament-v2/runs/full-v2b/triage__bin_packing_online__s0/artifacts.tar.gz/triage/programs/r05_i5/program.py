"""Online Primal-Dual Bin Packing with Smoothed Penalty Learning.

Maintains a global Lagrange multiplier that penalizes opening new bins,
updated via subgradient-like dynamics to balance bin creation against
reuse of existing bins. Laureator is shared across all calls in an instance.
"""
import numpy as np

# Global state: multiplier persists across calls within an instance
_multiplier = 100.0  # Initial penalty for creating a new bin
_lr_step = 0.1  # Subgradient-like learning rate


def priority(item, bins):
    """
    Assign priority scores for this item across all bins it can fit into.
    
    item: integer size of the item (1-100)
    bins: numpy int64 array of remaining capacities (100 = unused/new bins)
    return: numpy array of scores (higher = preferred, ties go to first)
    """
    global _multiplier, _lr_step
    
    # Base score favors tight fits: smaller remaining = better
    slack = bins - item
    base_score = -slack
    
    # Penalty for new bins (unused capacity == 100)
    is_new = bins == 100
    score = base_score.copy()
    score[is_new] -= _multiplier
    
    # After harness selects a bin, multiplier is adjusted externally:
    # new_bin: _multiplier += _lr_step
    # old_bin: _multiplier -= _lr_step
    # This favors reusing existing bins unless creating one is necessary
    
    return score
