import numpy as np


class AdaptiveBinPacker:
    def __init__(self):
        self.item_remaining_pairs = []
        self._fit_model()

    def _fit_model(self):
        if not self.item_remaining_pairs:
            self.intercept = 50.0
            self.slope = 0.0
            return

        X = np.array([[p[0], 1] for p in self.item_remaining_pairs[-20:]])
        y = np.array([p[1] for p in self.item_remaining_pairs[-20:]])

        try:
            coeffs, *_ = np.linalg.lstsq(X, y, rcond=None)
            self.intercept = float(coeffs[1])
            self.slope = float(coeffs[0])
        except np.linalg.LinAlgError:
            pass

    def priority(self, item, bins):
        if self.item_remaining_pairs:
            self.item_remaining_pairs.append((self.last_item_size, self.last_bins_before))

        self._fit_model()
        predicted = float(self.intercept + self.slope * item)

        # Mask of fit bins
        mask = bins >= item
        candidate_bins = mask.nonzero()[0]
        if candidate_bins.size == 0:
            scores = np.full(len(bins), -np.inf)
            scores[0] = 0.0
            return scores

        predicted = np.full_like(bins, predicted, dtype=np.float64)
        scores = -np.abs(bins - predicted)
        for i in range(len(bins)):
            if not mask[i]:
                scores[i] = -np.inf

        scores = scores.astype(np.float64)
        chosen_idx = int(np.argmax(scores))
        self.last_item_size = item
        self.last_bins_before = bins[chosen_idx]
        return scores
