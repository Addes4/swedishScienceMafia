# EVOLVE-BLOCK-START
"""
Apply online FFD logic by scoring bins using a convex combination of best-fit criteria
and a tail-rank bonus for bins that are more loaded (closer to the top in a descent load ranking).
"""
import numpy as np


# Store current load for each bin to speed up rank computations
_bin_loads = []

def priority(item, bins):
    """
    Score each available bin. Choose bin with highest score; tie-break to lowest index.
    We maintain a running array of current bin loads.
    """
    global _bin_loads
    
    # Filter bins that fit the item
    mask = bins >= item
    fits = bins[mask]
    candidate_indices = np.where(mask)[0]
    
    # Current bin loads (we update them incrementally each call based on history)
    # We need to maintain them, but since capacity is 100 and unused = 100, 
    # current loads = 100 - bins (but only for bins that have been touched)
    # To handle incremental updates, we track actual current loads externally
    # Since bins was a COPY and represents remaining capacity, bin_index = load_index
    
    # Estimate loads as (100 - remaining) for bins used before
    # But this is tricky - we may see stray bins with remaining=100 from never used or from
    # the initial set. The harness gives us copies each time, showing ALL bins.
    
    # We need to cache actual loads we've seen in this instance
    # Since bins array is copied and passed each time, we need to reconstruct or track loads
    
    # To make this work, we will track the current 'load' of each bin index: bin_ids
    # Store in _bin_loads[np] for each index
    # But we might see unused bins (index) that are new in this list?
    # Given usual instances have bins length = items - we saw before, indices are same
    # Let's maintain loads by observing bins array over time
    
    # Better approach: Calculate load = 100 - bins[remaining capacity]
    # For unused bins remaining=100, load=0.
    
    # But wait - the harness enforces capacity, meaning if we learned in previous call
    # that item of size 30 went to bin 5, remaining cap of bin 5 should be 70
    # next time bins array shows bin 5 with remaining 70, unless bins is reset
    # Based on problem: "bins is a numpy int64 array with the remaining capacity
    # of every bin the item fits in. There are as many bins as items;
    # unused bins have remaining capacity 100"
    # So initial: all bins have 100, and as items assigned, it goes down
    # So we对您 calculate: load = 100 - remaining
    
    current_loads = 100 - bins  # This is true per current bins array
    
    if not np.any(mask):
        # Shouldn't happen if bins uses capacity logic correctly
        return np.zeros_like(bins)
    
    # Candidate score combinations
    # Tightness measure: remaining capacity after placement (100 - item - load_before)
    # = 100 - item - (100 - remaining) = remaining - item
    # We want to minimize (remaining - item), i.e., fit tightly
    tightness = fits - item
    
    # For rank-based scoring: bins with more load (higher load) get bonus
    # rank_bonus = position_in_sorted_load_descending (0-indexed, lower is better for load
    # We want high load, so we want lower rank count in descending order
    # rank_i = number of bins with load >= current_load, roughly 0..len-1
    
    # Compute loads for all bins that fit
    loads = current_loads[mask]
    
    # Sort indices by load descending to get rank order (most loaded = rank 0)
    # But we need to maintain stable sorting for consistency
    sorted_order = np.argsort(-loads)  # descending by load
    
    # For each fitting bin, compute its rank
    rank = np.zeros_like(tightness, dtype=np.int32)
    for bin_idx_in_fits, local_rank in enumerate(sorted_order):
        rank[bin_idx_in_fits] = local_rank
        # Actually need to map: sort_order[j] gives the original index of bin_j_with_highest_load
        # local_rank from 0..len1-1 corresponding to best to worst for load
    
    # Correct computation:
    # sorted_indices = indices of fits sorted by load descending
    # rank[i] = position in sorted order (0 = most loaded)
    sort_positions = np.argsort(-loads)  # gives indices for fits sorted by load desc
    for i in range(len(mask))[0]:
        pass
    
    # Easier:
    # Load rank = number of other fitting bins with load >= this load
    ranks = np.zeros_like(tightness, dtype=np.int32)
    for i in range(len(mask)):
        if mask[i]:
            # Count how many fitting bins have load >= this
            # Could be inefficient: O(N^2), but with 5000 calls, don't want per-call overhead
            break
    
    # Efficient version:
    # ranks = searchsorted of loads array
    # But loads changes each call. For N=5000, need better
    # O(N log N) per call is ok: 5000 * 5000 * 60 calls = 2.5 * 10^8 - too much
    
    # Analytic solution: sort loads once, compute ranks in O(N log N)
    # With 5000 bins, 5000 calls, so total 2.5 * 10^7, which is fine
    
    # Compute loads for all bins, not just those fitting
    all_loads = current_loads.astype(np.float64)
    n_all = len(all_loads)
    
    # For tie-breaking: prefer bins with higher load
    # And among high load with tight fit, prefer lower index (stable sort wins)
    
    # We construct a score: tightness_alpha + rank_beta
    # Minimize (remaining - item), but add reward for high load
    # Score should be NEGATIVE of what we minimize
    # So: score = -[(tightness - high_load)]
    # But we need scalar per fitting bin and return full-length array of scores
    
    # Let's simplify:
    # For bins that fit:
    #   score = item - bins + alpha * (current_load)
    # Higher load -> higher score (bonus)
    # Tight fit (small remainder) -> item - bins is small (better if <0?)
    # Wait, bins=remaining, so item - bins = item - remaining = deficit
    # We want small item - bins = tight
    # But item - bins can be negative if item > remaining (can't happen with mask)
    # item <= bins, so item - bins <= 0
    # More negative item means tighter fit. So negative is better.
    
    # We want highest score, so score = -item + bins + w * (current_load) ?
    # Hmm, more negative is tighter (better fit), so we want more negative to be higher
    # So invert: score = -[(bins - item) - w * (current_load)] = -bins + item + w * current_load
    # Higher score is better, so:
    #   -bins + item + w * current_load
    # Higher current_load makes score higher (more loaded bins preferred)
    # Smaller bins means more negative -bins, but we want smaller bin to be higher score
    # Actually if bins=50, item=40, bins-item=10; if bins=50, item=60 can't happen
    # So bins - item is the gap after placement, 0 best, positive means unused
    # Tighter means smaller bins-item
    # Score to maximize: -bins + item - w * bins = item - (bins + w * bins)?
    # Simpler: use ranked index bonus for load
    
    # Let's simplify strategy: -tightness - penalty_for_rank
    # Tightness = bins - item (after placement, but we only see before placement: bins - item)
    # Wait, bin capacity is remaining space. After placing item, new_remaining = bins - item
    # We want new_remaining close to 0, so minimize (bins - item)
    # Score should be negative of this: score = -(bins - item) = item - bins
    # High load gets a bonus
    
    # MORE OVER DELETE alt strategy:
    # Use current loads for tie-break and index stability
    
    alpha = 0.7  # weight for fit tightness
    beta = 0.3   # weight for load bonus
    
    # Precompute all loads
    loads = np.array(100 - bins, dtype=np.float32)
    
    # Compute score for each fitting bin
    # For all bins we need score array even if item doesn't fit -> set to -inf or -large
    scores = np.full(len(item).dtype, -np.inf)
    # Actually, bins may have different length in different calls? No, bins has same length.
    scores = np.full(len(bins), -np.inf)
    
    if len(fits) > 0:
        # Fit bins: tightness = remaining after placement = bins_remaining - item
        # Score = -tightness + beta * rank = -(fits - item) + beta * rank
        # rank = descent load rank: 0 = most loaded
        
        # Compute global load ranks (descending)
        # To sort loads, use argsort(- loads)
        n = len(sizes)
        sorted_ids = np.argsort(-loads)
        
        # For fitting bins, get their rank in sorted load array
        fit_indices = np.where(mask)[0]
        fitted_loads = loads[mask]
        
        # Find position of each fit's load in the global sorted length capture
        # In numpy we can use searchsorted for efficiency
        # Load inverses: for each fitted load, its rank = how many loads >= it
        # But we need stable ranking, so we use argsort twice:
        
        # Method: compute ranks via dense integers
        # rank[i] = number of j s.t. loads[j] > loads[i], with tie-breaking by index (original order)
        # But since we want most loaded first (rank 0), we want descending sort
        
        # Let's do a fast linear rank with stable sort
        sort_positions = np.argsort(-loads)  # indices for loads sorted desc
        rank_map = np.empty(n, dtype=np.int32)
        for i, pos in enumerate(sort_positions):
            rank_map[pos] = i  # load at pos has rank i (0 = most loaded)
        
        # For fitting bins:
        fit_ranks = rank_map[fit_indices]  # rank (0=most loaded)
        
        # Compute fit scores
        fit_scores = item - fits + 0.001 * np.exp(-10 * fit_ranks / (n/2))
        # Higher load (lower rank) gives bonus; exponential decay to keep reasonable scale
        
        # Fill scores for fitting bins
        scores[fit_indices] = fit_scores
        
        # But among similar fits, we want more loaded to prefer
        # So the above works for overall, but we may need to tie-break by index for stability
    
    # Ensure all entries are finite
    scores = np.asarray(scores, dtype=np.float32)
    # Replace -inf with 0 for bins that don't fit? Problem says no NaN, and return array of same length
    # Bins that don't fit should get lowest score (not chosen)
    
    # Simple optimization: -large number for non-fitting
(scores = scores.copy())
    science = np.nan  # replace
    pass
# EVOLVE-BLOCK-END
