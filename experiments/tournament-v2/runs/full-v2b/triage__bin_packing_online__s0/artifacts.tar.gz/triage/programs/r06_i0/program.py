# EVOLVE-BLOCK-START
"""
Gap-aware harmonic approach: dynamically maintain ideal residual gap classes
based on observed item sizes, then score bins by how close resulting residual
is to these ideal gaps. This encourages "packable" gaps that match future items.
"""
import numpy as np

# Dynamically-maintained ideal gap classes based on observed data
_gap_classes = np.array([5, 10, 15, 20, 25, 35, 50, 65, 75, 85])
_item_sum = 0.0
_item_count = 0
_mean_item = 40.0  # Default for Weibull mean ~40

def _update_statistics(item):
    global _item_sum, _item_count, _mean_item
    _item_sum += item
    _item_count += 1
    if _item_count >= 100:
        _mean_item = _item_sum / _item_count

def _recompute_gap_classes(item):
    global _gap_classes, _mean_item
    
    _update_statistics(item)
    
    if _mean_item < 1:
        _gap_classes = np.array([5, 10, 15, 20, 25, 35, 50, 65, 75, 85])
        return
    
    # Dynamic ideal gaps based on observed mean item size
    gaps = np.array([
        int(np.maximum(3, _mean_item * 0.3)),
        int(np.maximum(5, _mean_item * 0.5)),
        int(_mean_item),
        int(np.maximum(15, _mean_item * 1.5)),
        int(np.maximum(25, _mean_item * 2)),
        int(np.maximum(50, _mean_item * 2.5)),
        int(np.maximum(75, _mean_item * 3)),
        95
    ])
    
    # Keep 0-100 and unique, sort
    gaps = np.unique(np.maximum(1, np.minimum(100, np.round(gaps).astype(int))))
    
    # Ensure diverse coverage
    if len(gaps) < 8:
        gaps = np.sort(np.unique(np.concatenate([gaps, _gap_classes])))
    gaps = np.unique(gaps)[:10]
    
    _gap_classes = np.array(gaps)

def priority(item, bins):
    """
    Score bins by how close resulting residual capacity is to ideal gap classes.
    
    Args:
        item: integer size of the arriving item
        bins: numpy int64 array with remaining capacity of every bin that fits the item
    
    Returns:
        numpy array of scores for each bin (one per bin fitting, in bin order)
    """
    _recompute_gap_classes(item)
    gaps = _gap_classes
    
    # Calculate resulting residual if placed in each bin
    residuals = bins - item
    
    # If no bins fit (shouldn't happen for valid input), return zeros
    if len(residuals) == 0:
        return np.zeros(len(bins), dtype=np.int64) if len(bins) > 0 else np.array([])
    
    # Vectorized distance to nearest ideal gap class
    # For each residual, find minimum distance to any gap class
    distances = np.abs(residuals[:, None] - gaps[None, :])
    distances = distances.min(axis=1)
    
    # Score inversely proportional to distance
    # Higher score = closer to ideal gap
    # Avoid numerical issues with small distances
    scores = (10000.0 - distances).astype(np.float64)
    
    # Prefer larger residuals for ties (efficiency) - apply as tiebreaker
    # (implemented in harness by giving higher scores first via values, 
    # but we keep simple max for now)
    
    return scores.astype(np.int64)
# EVOLVE-BLOCK-END
