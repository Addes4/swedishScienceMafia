# EVOLVE-BLOCK-START
"""Best-fit with a pressure term discouraging over-used remaining-capacity bands.

The idea: partition remaining-capacity values into k equal-width bands and keep a
running count of how many items have been placed into bins whose (post-placement)
or current remaining capacity fell in each band. Bins whose band has been used often
get a penalty (via a bonus inversely proportional to the count), nudging the packer
toward less-crowded configurations while still preferring tight fits.
"""
import numpy as np

# Band configuration
_K = 10
_BAND_WIDTH = 100.0 / _K

# State: counts per capacity band of the remaining capacity of chosen bins.
_counts = np.zeros(_K, dtype=np.float64)
_calls = 0


def _reset():
    global _counts, _calls
    _counts = np.zeros(_K, dtype=np.float64)
    _calls = 0


def priority(item, bins):
    """Return a priority for every bin; highest wins (first on ties)."""
    global _calls

    # Detect the start of a fresh instance (treat each call sequence independently
    # by decaying toward uniformity rather than tracking identity).
    _calls += 1
    if _calls % 5000 == 1:
        _reset()

    b = np.asarray(bins, dtype=np.float64)

    # Best-fit gap: how much unused room is left after placing the item.
    gap = b - item

    # Band index of each bin's *post-placement* remaining capacity.
    idx = np.floor(gap / _BAND_WIDTH).astype(np.int64)
    idx = np.clip(idx, 0, _K - 1)

    # Historical usage counts for those bands.
    counts = _counts[idx]

    # Bonus inversely proportional to how crowded a band is (smoothed).
    bonus = 1.0 / (1.0 + counts)

    # Weighted combination: strong preference for tight fits, gentle load-balancing.
    score = -gap + 1.5 * bonus

    # Record the chosen bin's post-placement band.
    best = int(np.argmax(score))
    chosen_band = idx[best]
    _counts[chosen_band] += 1.0

    return score
# EVOLVE-BLOCK-END
