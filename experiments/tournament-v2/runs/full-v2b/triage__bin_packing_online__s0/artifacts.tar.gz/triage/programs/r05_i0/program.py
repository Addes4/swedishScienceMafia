# EVOLVE-BLOCK-START
"""Pareto-style tie-break: best fit first, then deviation from estimated item-size mode.

The primary key is the usual best-fit rule -- the smallest residual gap `bins - item`.
Ties (or near-ties) are broken by how far the bin's used space is from the most
frequent item size seen so far.  The idea is that packing bins so their used space
sits near a frequent item size leaves residuals that are likely to be matched
again later, reducing fragmentation.

Since the harness only uses a single score per bin (with the first bin winning
ties), we encode the lexicographic rule into one scalar by scaling: the gap term
dominates and the tie-break term only matters among equal gaps.  This is achieved
by using a large multiplier on the gap term (gaps are integers 0..99) and adding
a bounded secondary term in (-0.5, 0.5).
"""
import numpy as np

# Module-level online state: running estimate of the modal item size.
_state = {"counts": np.zeros(101, dtype=np.int64), "n": 0, "mode": 50}


def priority(item, bins):
    """Rank bins: tightest fit wins; residuals near the frequent item size preferred."""
    # --- update the online histogram of item sizes ---
    it = int(item)
    if 0 <= it <= 100:
        _state["counts"][it] += 1
        _state["n"] += 1
    # Recompute the mode lazily every so often (cheap, 101 entries).
    if _state["n"] % 16 == 0 or _state["n"] <= 1:
        counts = _state["counts"]
        # Smooth a bit so small samples don't lock a bad mode; weight by count.
        if _state["n"] > 0:
            _state["mode"] = int(np.argmax(counts))

    mode = _state["mode"]

    # --- primary: best fit ---
    gap = bins - it                      # residual capacity after placing item
    # Bin's used space after placing the item:
    used = 100 - gap

    # --- secondary: prefer used-space close to the modal item size ---
    dev = np.abs(used - mode).astype(np.float64)   # 0..100
    # Bound secondary term strictly inside (-0.5, 0.5) so it never overrides gap.
    sec = -dev / (2.0 * 101.0)

    # Gap term dominates: multiply by a factor larger than the range of `sec`.
    return -(gap.astype(np.float64)) + sec
# EVOLVE-BLOCK-END
