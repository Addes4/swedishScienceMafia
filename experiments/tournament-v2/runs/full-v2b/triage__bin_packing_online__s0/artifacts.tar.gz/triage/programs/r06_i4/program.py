import numpy as np
from collections import defaultdict

class TileCoder:
    def __init__(self, n_tilings=8, n_tiles_per_tiling=8):
        self.n_tilings = n_tilings
        self.n_tiles_per_tiling = n_tiles_per_tiling
        # Discretize continuous state (0-100 capacity) into tiles
        # State is the set of bins with their capacities.
        # We need a fixed-size state representation. We'll use the top-k bin capacities.
        self.k_bins = 5  # number of bins to include in state
        
    def get_tiles(self, state, action_bin_capacity):
        """Convert state and action to tile indices.
        state: tuple of (item_size, sorted_bin_capacities_truncated)
        action_bin_capacity: capacity of the bin being considered
        """
        tiles = []
        item_size = state[0]
        bin_capacities = state[1]
        
        # Discretize item size and action bin capacity
        item_range = 100
        cap_range = 100
        
        for t in range(self.n_tilings):
            offset = t * (100 // self.n_tilings)
            # Tile features: item discretized, action capacity discretized
            item_tile = min((item_size + offset) * self.n_tiles_per_tiling // item_range, 
                           self.n_tiles_per_tiling - 1)
            action_tile = min((action_bin_capacity + offset) * self.n_tiles_per_tiling // cap_range,
                             self.n_tiles_per_tiling - 1)
            # Include some bin capacity context
            tiles.append((t, item_tile, action_tile))
            # Add features for each of the k bins
            for i, cap in enumerate(bin_capacities):
                cap_tile = min((cap + offset) * self.n_tiles_per_tiling // cap_range,
                              self.n_tiles_per_tiling - 1)
                tiles.append((t + self.n_tilings, item_tile, action_tile, i, cap_tile))
        return tiles

class QFunction:
    def __init__(self, learning_rate=0.1, lambda_=0.9, gamma=0.99):
        self.weights = defaultdict(float)
        self.lr = learning_rate
        self.lambda_ = lambda_
        self.gamma = gamma
        self.tile_coder = TileCoder()
        self.eligibility = defaultdict(float)
        
    def get_q(self, state, action_capacity):
        tiles = self.tile_coder.get_tiles(state, action_capacity)
        return sum(self.weights[t] for t in tiles)
    
    def update(self, state, action_capacity, reward, next_state, next_action_capacity):
        # SARSA update with eligibility traces
        current_q = self.get_q(state, action_capacity)
        
        if next_state is not None and next_action_capacity is not None:
            next_q = self.get_q(next_state, next_action_capacity)
            td_error = reward + self.gamma * next_q - current_q
        else:
            td_error = reward - current_q
            
        # Update eligibility traces
        tiles = self.tile_coder.get_tiles(state, action_capacity)
        for t in self.eligibility:
            self.eligibility[t] *= self.gamma * self.lambda_
        for t in tiles:
            self.eligibility[t] += 1
            
        # Update weights
        for t in list(self.eligibility.keys()):
            self.weights[t] += self.lr * td_error * self.eligibility[t]
            if abs(self.eligibility[t]) < 1e-5:
                del self.eligibility[t]

# Initialize stateful Q-function
q_function = QFunction()
last_state = None
last_action = None
bins_opened = 0
prev_bins_count = 0

def priority(item, bins):
    global q_function, last_state, last_action, bins_opened, prev_bins_count
    
    # Get current state
    # State: item size and sorted top-k remaining capacities of non-empty bins
    non_empty_caps = sorted([c for c in bins if c < 100], reverse=True)
    # Pad with 100s if needed
    non_empty_caps = non_empty_caps[:q_function.tile_coder.k_bins]
    while len(non_empty_caps) < q_function.tile_coder.k_bins:
        non_empty_caps.append(100)
    current_state = (item, tuple(non_empty_caps))
    
    # Compute Q-values for all valid bins
    q_values = np.zeros(len(bins))
    for i, cap in enumerate(bins):
        q_values[i] = q_function.get_q(current_state, cap)
    
    # Choose action (bin with highest Q-value)
    best_idx = np.argmax(q_values)
    action_capacity = bins[best_idx]
    
    # Compute reward based on previous action's outcome
    # Reward is -1 if new bin opened, 0 otherwise
    reward = 0
    if prev_bins_count > 0:
        # Check if previous action opened a new bin
        # We can detect this by checking if the item went to a bin with capacity 100
        if last_action is not None and last_action == 100:
            reward = -1
    
    # Update Q-function if we have a previous state-action pair
    if last_state is not None and last_action is not None:
        q_function.update(last_state, last_action, reward, current_state, action_capacity)
    
    # Save current state and action for next step
    last_state = current_state
    last_action = action_capacity
    prev_bins_count = len(bins)
    
    return q_values
