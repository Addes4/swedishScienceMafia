# EVOLVE-BLOCK-START
"""Event-triggered protective bin packing using smoothed item size history."""
import numpy as np

# Global state for statistics tracking (kept across calls)
last_size = np.int64(0)
wins = np.array([0, 0, 0, 0, 0], dtype=np.int64)  # :10 | 10-20 | 20-40 | 40-60 | 60-80 | >80
size_counts = np.zeros(101, dtype=np.float64)
count = np.int64(0)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    global last_size
    
    # Update statistics (number of items seen mod 1000 to limit growth)
    idx = item % 101
    size_counts[idx] += 1.0
    last_size = item
    
    # Compute empirical probability of large item from history
    if count >= 100:
        total = size_counts.sum()
        p_large = size_counts[80:].sum() / total
        p_medium = size_counts[40:80].sum() / total
    else:
        p_large = 0.5
        p_medium = 0.5
    
    # Use exponential moving average for smoother adaptation
    alpha = 0.1
    p_large = alpha * (p_large if item > 80 else 0) + (1 - alpha) * p_large
    p_medium = alpha * (p_medium if item > 40 else 0) + (1 - alpha) * p_medium
    
    count += 1
    
    # Kalicki kernel density estimate approximation: weight by Gaussian-smoothed past
    wk = np.exp(-((last_size - item) ** 2) / 50.0)
    
    # Determine if next M=10 items likely contain a large item
    M = 10
    # Prob of at least one large in next M items given iid history
    prob_large_in_next_M = 1.0 - (1.0 - p_large) ** M
    
    # Threshold for triggering protective rule
    protect_threshold = 0.5  # 50% chance of large item triggers protection
    
    # Convert bins to priorities
    # "protective" means we prefer bins that can accommodate large items better
    if prob_large_in_next_M > protect_threshold:
        # Protective mode: score bins based on ability to handle large items
        # Bin with more capacity benefits more from a large item
        # Use inverse: bins with less head-room get higher priority (more risk of overflow)
        # Actually, for protective: reserve high-cap bins => give them LOWER scores
        # Large items need at least (100 - item) capacity available
        capacity_needed_for_large = 80
        bin_protection_score = bins.copy()
        # Penalize bins that can't handle item if large
        bin_protection_score[:100] -= bin_protection_score < (capacity_needed_for_large - item) * 10.0
    else:
        # Normal best-fit: prefer bins closest to tight fit
        bin_protection_score = bins - item
    
    # Add small smoothing to avoid NaNs or ties due to floating point
    bin_protection_score = bin_protection_score.astype(np.float64) + 1e-9
    return bin_protection_score
# EVOLVE-BLOCK-END
