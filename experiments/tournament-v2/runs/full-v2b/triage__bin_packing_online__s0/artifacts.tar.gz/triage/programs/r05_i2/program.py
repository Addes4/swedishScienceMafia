# EVOLVE-BLOCK-START
"""Time-decayed best fit bin packing strategy."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Static global state for tracking bin usage history
    if 'bin_ages' not in globals():
        globals()['bin_ages'] = np.zeros(10000, dtype=np.int64)
    if 'call_count' not in globals():
        globals()['call_count'] = 0
    if 'bin_counts' not in globals():
        globals()['bin_counts'] = np.zeros(10000, dtype=np.int64)
    if 'bin_max_index' not in globals():
        globals()['bin_max_index'] = 0
    
    # Update call count and filter bins that fit the item
    call_count = globals()['call_count']
    bins = np.array(bins)
    
    # Update aging for bins shown to us (those that can fit the item)
    valid_indices = (bins >= item)
    bin_counts = globals()['bin_counts']
    bin_ages = globals()['bin_ages']
    
    # Increment item count and age for valid bins
    bin_ages[valid_indices] += 1
    bin_counts[valid_indices] += 1
    
    # Update bin_max_index to track maximum bin count observed
    bin_max_index = globals()['bin_max_index']
    new_max = np.max(bin_counts)
    if new_max > bin_max_index:
        bin_max_index = new_max
    
    # Compute decay factor: bonus decreases with age
    # Use logarithmic decay to encourage spreading but still allow reuse
    age_norm = bin_ages[valid_indices]
    decay = age_norm.astype(np.float64) / (bin_max_index + 1)
    
    # Score = tight fit benefit + time-decayed usage bonus
    # Tight fit: -(bins - item) gives higher score for tighter fit
    # Usage bonus: decreases with age, encouraging spreading to fresher bins
    tight_fit = -(bins[valid_indices] - item)
    usage_bonus = (1.0 - decay) * -0.5  # Older bins get less bonus (less negative)
    
    score = tight_fit + usage_bonus
    
    # Return score array with NaN for invalid bins, handle ties by first occurrence
    # Build result array where only valid bins have scores, invalid get a very low score
    result = np.full_like(score, np.nan, dtype=np.float64)
    result[valid_indices] = score
    
    return result
# EVOLVE-BLOCK-END
