# EVOLVE-BLOCK-START
"""Dual-buffer bin choice: tight-fill zone (best-fit) vs normal zone (worst-fit),
with a PID-like controller that adapts the zone boundary to recent item means."""
import numpy as np


class _State:
    def __init__(self):
        # adaptive target for "large" items: fraction of capacity
        self.tight_min = 0.90          # items >= tight_min*100 prefer tight-fill zone
        self.recent = []               # recent item sizes
        self.total = 0                 # total item size seen
        self.count = 0                 # items seen
        self.bins_used_est = 0         # rough count of active bins
        self.err_int = 0.0             # PID integral
        self.prev_err = 0.0            # PID previous error
        self.kp = 0.25
        self.ki = 0.0008
        self.kd = 0.02
        self.boundary = 70.0           # capacity value separating tight vs normal zones

    def update_stats(self, item):
        self.recent.append(item)
        if len(self.recent) > 200:
            self.recent.pop(0)
        self.total += item
        self.count += 1
        m = float(np.mean(self.recent))
        # ideal number of bins if average fill were ~85%
        ideal = self.total / 85.0
        # observed density: items per bin so far
        dens = self.count / max(1.0, ideal)
        err = 1.0 - dens               # want dens near 1
        self.err_int += err
        if self.err_int > 50.0:
            self.err_int = 50.0
        if self.err_int < -50.0:
            self.err_int = -50.0
        derr = err - self.prev_err
        self.prev_err = err
        adj = self.kp * err + self.ki * self.err_int + self.kd * derr
        # boundary moves with mean item size and controller correction
        self.boundary = 0.55 * m + 25.0 + 20.0 * adj
        if self.boundary < 35.0:
            self.boundary = 35.0
        if self.boundary > 85.0:
            self.boundary = 85.0

    def tight_threshold(self):
        return self.tight_min * 100.0


_state = _State()


def priority(item, bins):
    """Rank bins: large items -> tight-fill (best fit); smaller -> normal (worst fit)."""
    global _state
    st = _state
    st.update_stats(item)

    bins = np.asarray(bins)
    boundary = st.boundary

    # Items are "large" when they are close to the tight threshold or above boundary
    is_large = item >= st.tight_threshold() or item >= boundary

    if is_large:
        # Best fit: smallest remaining capacity that still fits -> maximize -remaining
        return -(bins.astype(np.float64))
    else:
        # Worst fit: prefer larger gaps, but still discourage half-empty huge bins
        # score higher for larger remaining capacity
        return bins.astype(np.float64)
# EVOLVE-BLOCK-END
