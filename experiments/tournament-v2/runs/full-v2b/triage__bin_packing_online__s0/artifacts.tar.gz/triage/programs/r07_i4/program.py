# EVOLVE-BLOCK-START
"""Online-matching / cover-ratio rule with predicted remaining volume.

Idea: keep a running estimate of the average item size (a simple exponential /
moving average over the items seen so far).  Knowing the instance has a fixed
length N = 5000 items, we can predict the total volume that will still arrive.
Spreading that predicted volume uniformly over the currently open bins gives an
expected "final load" per bin.  For each candidate bin we compute the ratio

    cover = (current_load_in_bin + item) / expected_final_load_per_bin

and prefer bins whose cover ratio is closest to 1.0 (neither too empty nor too
full), which steers the packing toward a uniform final load and mimics a good
online matching / balancing decision.

We combine a small tie-breaking preference (best fit) so that among bins with a
similar cover ratio we still prefer the tighter fit.  All computations are
vectorised with numpy.
"""

import numpy as np

CAP = 100.0
N_ITEMS = 5000.0


def priority(item, bins):
    """Return a priority score per bin; highest score wins (first on ties)."""
    # `bins` holds remaining capacities of every bin the item fits in.
    bins = np.asarray(bins, dtype=np.float64)

    # ---------------------------------------------------------------
    # Bookkeeping between calls (state kept on the function object).
    # ---------------------------------------------------------------
    st = priority.__dict__
    total_seen = st.get("total_seen", 0.0)      # items seen so far (this instance)
    volume_seen = st.get("volume_seen", 0.0)    # total size of those items
    # Track the last item size to help reset state across instances.
    last_seen_marker = st.get("last_marker", None)

    # Detect a fresh instance: item counts grow monotonically within an
    # instance and reset to a small value on a new one.  We can't observe the
    # counter directly, so we rely on a soft heuristic: if the recorded number
    # of seen items already reached the known instance length, reset.
    if total_seen >= N_ITEMS:
        total_seen = 0.0
        volume_seen = 0.0

    # ---------------------------------------------------------------
    # Predict remaining volume.
    # ---------------------------------------------------------------
    # Mean item size so far (with a sensible prior near the distribution mean).
    if total_seen >= 5:
        mean_item = volume_seen / total_seen
    else:
        mean_item = 40.0  # prior: distribution mean ~ 40

    remaining_items = max(N_ITEMS - total_seen, 0.0)
    predicted_remaining_volume = remaining_items * mean_item

    # Number of bins currently available for this item.
    n_bins = bins.size
    if n_bins == 0:
        return bins  # nothing to rank

    # Expected final added load per open bin if the predicted volume were spread
    # uniformly.  Add a small floor so the ratio never divides by ~0.
    target_per_bin = predicted_remaining_volume / n_bins
    target_per_bin = max(target_per_bin, 1e-3)

    # ---------------------------------------------------------------
    # Cover ratio per bin.
    # ---------------------------------------------------------------
    # Load currently in the bin = capacity used = CAP - remaining.
    current_load = CAP - bins
    # Load after placing the item.
    new_load = current_load + item

    cover = new_load / target_per_bin  # ~1.0 is the "ideal" final load

    # Prefer cover ratios close to 1.0: a smooth, symmetric penalty.
    score = -np.abs(cover - 1.0)

    # ---------------------------------------------------------------
    # Tie-breaking: among near-equal cover ratios, prefer tighter fit
    # (smaller resulting remaining capacity), i.e. best-fit flavour.
    # Scale small enough not to override the cover-ratio ordering.
    # ---------------------------------------------------------------
    score += 1e-3 * (-(bins - item))

    # ---------------------------------------------------------------
    # Update state with the arriving item (it will be placed after we
    # return; we just accumulate statistics of observed items).
    # ---------------------------------------------------------------
    st["total_seen"] = total_seen + 1.0
    st["volume_seen"] = volume_seen + float(item)
    st["last_marker"] = float(item)

    return score
# EVOLVE-BLOCK-END
