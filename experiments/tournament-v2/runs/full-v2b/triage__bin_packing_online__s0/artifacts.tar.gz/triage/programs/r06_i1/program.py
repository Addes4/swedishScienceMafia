# EVOLVE-BLOCK-START
"""Sliding-window first-fit retrospective: maintain a window of recent items and
their actual placements, and score candidate bins by how many of those past items
would have been placed into each bin under a first-fit rule."""
import numpy as np

WINDOW_SIZE = 200

# Module-level state: lists of past items and bin indices.
_item_queue = []
_bin_queue  = []


def priority(item, bins):
    """Score bins by retrospective first-fit success count in a sliding window."""
    global _item_queue, _bin_queue

    # Number of candidate bins
    n_bins = len(bins)

    # Initialize scores to zero
    scores = np.zeros(n_bins, dtype=np.int64)

    # Evaluate each past item in the window against the current set of candidate bins
    for past_item, past_bin in zip(_item_queue, _bin_queue):
        # Find the first bin among candidates that can hold the past item
        # Use numpy's argmax on a boolean mask: first True is found by argmax.
        # We add a final True slot so that if no bin fits, it points to that slot.
        # (Past items always fit somewhere, but the current candidate set may not
        #  include the actual bin.  However, we only score among candidates.)
        feasible = bins >= past_item
        if np.any(feasible):
            first_fit = np.argmax(feasible)  # first True index
            scores[first_fit] += 1

    # Break ties by preferring bins with less remaining capacity (classic best-fit tilt)
    # This helps stability and is cheap.
    # We convert scores to float and subtract a small capacity-based term.
    float_scores = scores.astype(np.float64) - (bins / 100.0) * 0.001

    # Record the current item placement *after* scoring, because the harness
    # will place the item based on our returned scores.
    # To know the bin the item is about to go into, we need to select it the
    # same way the harness does: highest score, first on ties.
    # We replicate that logic here locally to predict the bin index.
    best_idx = int(np.argmax(float_scores))
    chosen_bin = best_idx  # bin index local to the passed bins array

    # Update the sliding window queues
    _item_queue.append(item)
    _bin_queue.append(chosen_bin)
    if len(_item_queue) > WINDOW_SIZE:
        _item_queue.pop(0)
        _bin_queue.pop(0)

    return float_scores
# EVOLVE-BLOCK-END
