# EVOLVE-BLOCK-START
"""Lookahead: simulate random futures drawn from the empirical item distribution,
run a fast best-fit oracle, and score bins by how often the oracle would pick them
for the current item. Falls back to plain best-fit when the candidate set is tiny."""
import numpy as np

# ---- module-level state (persists across calls within an instance) ----
_HIST = np.zeros(101, dtype=np.float64)   # empirical counts of item sizes seen so far
_NSEEN = 0
_CAP = 100
_HORIZON = 40          # number of synthetic future items
_NSAMPLES = 6          # number of random futures
_POOL = 14             # max number of candidate bins to consider in the oracle
_rng = np.random.default_rng(12345)


def _oracle_choice(bin_caps, seq):
    """Greedy best-fit offline placement of `seq` onto `bin_caps` (a list).

    Returns the index (into the original list) of the bin chosen for the first item,
    or -1 if a new bin was opened. Mutates a local copy of capacities.
    """
    caps = list(bin_caps)
    # place first item -> record its choice
    first = seq[0]
    best = -1
    best_rem = None
    for i in range(len(caps)):
        r = caps[i] - first
        if r >= 0:
            if best_rem is None or r < best_rem:
                best_rem = r
                best = i
    if best == -1:
        return -1  # open new bin
    caps[best] -= first
    # place remaining items
    for it in seq[1:]:
        b = -1
        br = None
        for i in range(len(caps)):
            r = caps[i] - it
            if r >= 0:
                if br is None or r < br:
                    br = r
                    b = i
        if b == -1:
            caps.append(_CAP - it)
        else:
            caps[b] -= it
    return best


def priority(item, bins):
    global _NSEEN
    _NSEEN += 1
    _HIST[item] += 1.0

    n = len(bins)

    # ---- fallback: best fit (tightest residual), keeps the baseline behaviour ----
    # This is also our answer whenever lookahead is not worthwhile.
    best_fit = -(bins - item)

    # number of bins the item actually fits in
    fit_mask = bins >= item
    nfit = int(fit_mask.sum())

    # If very few fitting bins, lookahead can't help; just best fit.
    if nfit <= 2:
        return best_fit

    # ---- build candidate pool: the `_POOL` tightest-fitting bins ----
    # indices of fitting bins, sorted by residual ascending (tightest first)
    fit_idx = np.nonzero(fit_mask)[0]
    resid = bins[fit_idx] - item
    order = np.argsort(resid, kind="stable")
    cand_idx = fit_idx[order[:_POOL]].tolist()

    # capacities of candidate bins BEFORE this item is placed
    cand_caps = [int(bins[i]) for i in cand_idx]

    # ---- empirical distribution for sampling futures ----
    total = _HIST.sum()
    if total < 50:
        # not enough history yet: plain best fit
        return best_fit
    probs = _HIST / total
    sizes = np.arange(101)

    # ---- run the oracle over several random futures ----
    votes = np.zeros(len(cand_idx), dtype=np.float64)
    H = _HORIZON
    for _ in range(_NSAMPLES):
        fut = _rng.choice(sizes, size=H, p=probs).tolist()
        seq = [item] + fut
        choice = _oracle_choice(cand_caps, seq)
        if choice >= 0:
            votes[choice] += 1.0
        # choice == -1 means oracle would open a NEW bin for the current item,
        # i.e. none of the candidate bins were attractive -> penalise all of them
        else:
            votes -= 0.05

    # ---- translate votes into scores ----
    # Annotate best-fit bins that were never voted for with a small residual term
    # so ties are broken sanely and unused (large) bins stay low.
    scores = np.empty(n, dtype=np.float64)
    # default: strongly discourage non-candidates (they had big residual anyway)
    rel = bins - item
    scores[:] = best_fit * 0.001 - rel * 1e-6  # tiny tie-breaker; main signal below
    # best-fit ordering nudge so untouched candidates rank by tightness
    for k, idx in enumerate(cand_idx):
        v = votes[k]
        # combine vote (primary) with a small best-fit tie-break (tighter better)
        scores[idx] = v * 1000.0 + (100 - int(rel[idx])) * 0.01

    # If no candidate got any vote (oracle always opened new), fall back to best fit.
    if votes.max() <= 0:
        return best_fit

    # NaN safety
    scores = np.nan_to_num(scores, nan=-1e18, posinf=1e18, neginf=-1e18)
    return scores
# EVOLVE-BLOCK-END
