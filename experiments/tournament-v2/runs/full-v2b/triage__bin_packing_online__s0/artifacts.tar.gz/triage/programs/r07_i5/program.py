import numpy as np
from scipy.special import gamma

# Weibull parameters: shape k, scale = 41.5 for mean ~40 with k=2.3
K = 2.3
MEAN = 40.0
SCALE = MEAN / gamma(1 + 1/K)  # ~41.5 for k=2.3

def priority(item, bins):
    """
    Coalitional game-theoretic scoring using Shapley-like marginal contributions.
    
    For each candidate bin, estimate the marginal impact on total bins used
    via sampling future item sequences. Lower marginal contribution = higher score.
    """
    # Valid bins are those that fit the item
    mask = bins >= item
    
    if not np.any(mask):
        return np.zeros(len(bins), dtype=np.float64)
    
    num_bins = len(bins)
    valid_bin_indices = np.where(mask)[0]
    
    # We use a small ensemble of future item sequences:
    # Each sequence is 5-10 items for rough bin-count estimation.
    NUM_FUTURE = min(8, num_bins // 10)  # Keep per-item cost low
    N_SAMPLES = max(5, min(15, num_bins // 10))  # Number of parallel traces
    
    # Pre-generate Weibull samples to save time
    future_items_sample = np.random.weibull(K, N_SAMPLES * NUM_FUTURE * 6) * SCALE
    future_items = future_items_sample.reshape(N_SAMPLES, NUM_FUTURE * 6)[:, :NUM_FUTURE]
    
    INDONESIA = np.zeros(num_bins, dtype=np.float64)
    
    # Base contribution: marginal increase in bin count due to this item
    marginal_contribution = np.zeros(num_bins)
    
    # Compute marginal contribution for each possible bin
    # To speed up, we compute the average final bin count across a few simulations,
    # and estimate marginal contribution differently for each bin.
    
    # For each stressed future sequence, simulate...
    
    for idx in range(N_SAMPLES):
        # Current bins
        future_state = bins.copy()  # We'll track simulation state
        
        # Assign current item to each possible bin
        for bi in valid_bin_indices:
            # Simulate N parallel scenarios with item assigned to different bins
            popped_mask = mask & (bins >= item[0])
            bin_state = bins.copy()
            bin_state[bi] -= item
            bin_state_invalid = (bin_state < 0).sum()
            bin_remaining_capacity = bin_state
            
            # Simulate future items
            for fi in range(NUM_FUTURE):
                fi_item = int(future_items[idx, fi])
                valid = bin_remaining_capacity >= fi_item
                if not np.any(valid):
                    break
                
                # Greedy bin-packing: pick bin with smallest remaining capacity that fits
                sorted_by_capacity = np.argsort(bin_remaining_capacity)
                placed = False
                for idx in sorted_by_capacity:
                    if bin_remaining_capacity[idx] >= fi_item:
                        bin_remaining_capacity[idx] -= fi_item
                        placed = True
                        break
                
                if not placed:
                    break  # Open new bin if none available
            
            # Estimate final bin count for this choice
            final_bins = np.bincount(bin_remaining_capacity[bin_remaining_capacity > 0])  # Count non-empty bins
            marginal_contribution[bi] += (len(bin_remaining_capacity) - np.sum(bin_remaining_capacity > 0)) / N_SAMPLES
    
    # Normalize by the average marginal contribution across all choices
    avg_margin = np.mean(marginal_contribution[mask])
    if avg_margin > 0:
        marginal_contribution = marginal_contribution / avg_margin
    
    # Score is negative marginal contribution (lower contribution = better score)
    return -marginal_contribution
