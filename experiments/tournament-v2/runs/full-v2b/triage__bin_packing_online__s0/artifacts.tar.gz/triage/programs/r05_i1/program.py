# EVOLVE-BLOCK-START
"""
Online bin packing with learned item size distribution.
Maintains a kernel density estimate of item size frequencies to score bins
by expected future waste.
"""
import numpy as np
from scipy.stats import gaussian_kde


def priority(item, bins):
    """
    Rank bins by expected waste to minimize long-term unused capacity.
    
    Returns an array of scores, one per bin that this item fits in (bins is passed ordinally).
    The item is placed in the bin with the highest score. Ties go to the first bin.
    """
    global _dist, _seen_counts, _count, _cdist
    
    if _count == 0:
        # First item, ALL bins have score 0
        return np.zeros_like(bins, dtype=np.float64)
    
    n_bins = len(bins)
    scores = np.full(n_bins, -np.inf, dtype=np.float64)
    
    # Bin that is too small won't be in bins array
    r = bins  # remaining capacity of each bin
    # Valid item sizes that fit in a bin: 1 to r[e]
    # But we know items are integer 1..100, so all future items are in [1, 100]
    
    # Precompute scores for each bin independently
    # For bin i with remaining capacity r_i:
    # Expected waste = E[(r_i - future_item) * 1_{future_item <= r_i}]
    #                = sum_{x=1}^{min(r_i, 100)} (r_i - x) * p(x)
    # where p(x) = P(future item has size x) from KDE
    
    max_item = min(item, 100)  # Earth your item size isn't too large
    
    # Use cumulative sum for efficiency
    # p_cum = [sum_{j=1}^k p(j) for k in 1..100]
    # sum_{x=1}^{r} (r - x)*p(x) = r*sum_{x=1}^{r} p(x) - sum_{x=1}^{r} x*p(x)
    #                            = r * P(X <= r) - E[X * 1_{X <= r}]
    
    pmf = _dist.pdf(np.arange(1, 101, dtype=np.float64))
    pmf = pmf / _cumsum_pm_sum  # Normalize just in case
    cumsum_p = np.cumsum(pmf)  # P(X <= x)
    cumsum_xp = np.cumsum(np.arange(1, 101, dtype=np.float64) * pmf)  # E[X * 1_{X <= x}]
    
    for i in range(n_bins):
        r_i = r[i]
        end = min(r_i, 100)
        if end < 1:
            scores[i] = r_i  # No item fits, huge waste (shouldn't happen with current bins)
        else:
            # P(X <= end)
            p_le_end = cumsum_p[end]
            # E[X * 1_{X <= end}]
            e_x_le_end = cumsum_xp[end]
            expected_waste = r_i * p_le_end - e_x_le_end
            scores[i] = -expected_waste
    
    return scores
