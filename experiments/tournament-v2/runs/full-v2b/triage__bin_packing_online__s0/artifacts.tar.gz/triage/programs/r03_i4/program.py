# EVOLVE-BLOCK-START
"""Score each bin by the expected number of future items that will exactly fill it.

We keep an online histogram of observed item sizes. For a bin with remaining capacity r,
the probability that the next item exactly fills it is p(r) = count(r)/total. But we also
care about items that "fit perfectly"; use the empirical frequency of size r. Bins whose
remaining capacity matches frequent item sizes are preferred, since leaving such a gap would
waste a future perfect fit.

To keep it robust early on (before the histogram is populated), blend with best-fit.
"""
import numpy as np

# Module-level state: histogram of item sizes 1..100.
_counts = np.zeros(101, dtype=np.float64)
_total = 0.0


def priority(item, bins):
    global _total
    # Update histogram with the current item.
    _counts[item] += 1.0
    _total += 1.0

    # Empirical frequency of each size, with Laplace-ish smoothing so early
    # predictions aren't wildly confident.
    freq = (_counts + 1.0) / (_total + 101.0)

    # Expected number of future items that fit perfectly into a bin of remaining
    # capacity r is proportional to freq[r]. Prefer bins with high freq[remaining].
    scores = freq[bins].astype(np.float64)

    # Best-fit tie-breaker / blend: tighter fits (smaller remaining capacity) are
    # generally good too. Combine with a small weight so the main signal dominates.
    best_fit = -bins.astype(np.float64)

    # Weight best-fit modestly; it stabilizes the very first items.
    return scores * 1.0 + best_fit * 1e-3
# EVOLVE-BLOCK-END
