# EVOLVE-BLOCK-START
"""Improved best-fit with small random jitter to break tight clusters
and reduce pathological cascades across instances."""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Core best-fit score: items fit more tightly scored higher (negative of leftover space)
    scores = -(bins - item)
    
    # Add tiny random jitter to perturb tie-breaking slightly
    jitter = np.random.uniform(-1e-6, 1e-6, bins.shape)
    scores = scores + jitter
    
    return scores
# EVOLVE-BLOCK-END
