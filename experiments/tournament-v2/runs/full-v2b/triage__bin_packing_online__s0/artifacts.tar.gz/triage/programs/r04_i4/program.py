import numpy as np

class EnsemblePacker:
    """
    Maintains an ensemble of simple bin-choice rules and tracks their recent performance
    using an exponential moving average.  Bins are scored by a weighted vote of the
    ensemble members.
    """
    def __init__(self):
        # List of (name, function) pairs for the ensemble rules.
        # Each rule takes (item, bins, state) and returns a numpy array of scores (higher = better).
        self.rules = [
            ("best_fit",     self._rule_best_fit),
            ("worst_fit",    self._rule_worst_fit),
            ("first_fit",    self._rule_first_fit),
            ("last_fit",     self._rule_last_fit),
            ("mid_fit",      self._rule_mid_fit),
            ("almost_full",  self._rule_almost_full),
            ("ignore_full",  self._rule_ignore_full),
            ("random_fit",   self._rule_random_fit),
        ]
        self.num_rules = len(self.rules)

        # Exponential moving average weights for each rule (initialized to uniform).
        self.ema_weights = np.ones(self.num_rules, dtype=np.float64) / self.num_rules
        self.ema_alpha = 0.1   # smoothing factor for weight updates

        # Recent window: keep track of a small history to compute per-rule rewards.
        self.window_size = 50
        # For each rule, a deque of recent binary rewards (1 = good, 0 = bad).
        from collections import deque
        self.reward_history = [deque(maxlen=self.window_size) for _ in range(self.num_rules)]

        # State that some rules may need (e.g., number of bins seen so far, placement counts).
        self.total_items = 0
        self.last_placed_bin_idx = -1   # which bin was chosen last (for reward calculation)

        # Track bin usage count to estimate when a new bin was actually opened.
        # We record after each placement the number of bins currently in use.
        self.bin_usage_history = deque(maxlen=self.window_size)

        # Random state for the random rule (seeded deterministically per instance).
        self.rng = np.random.RandomState(42)

    # --------------------------------------------------------------------------
    # Rule definitions: each returns a score array of same length as bins.
    # Rule scores are standardised to zero mean and unit variance across bins
    # before voting, so different scales do not dominate.
    # --------------------------------------------------------------------------
    @staticmethod
    def _rule_best_fit(item, bins):
        """Prefer bins where remaining capacity is closest to item."""
        return -(bins - item)

    @staticmethod
    def _rule_worst_fit(item, bins):
        """Prefer bins with the most remaining capacity."""
        return bins

    @staticmethod
    def _rule_first_fit(item, bins):
        """Prefer earlier bins (lower index)."""
        return -np.arange(len(bins), dtype=np.float64)

    @staticmethod
    def _rule_last_fit(item, bins):
        """Prefer later bins (higher index)."""
        return np.arange(len(bins), dtype=np.float64)

    @staticmethod
    def _rule_mid_fit(item, bins):
        """Prefer bins with capacity near the middle of the fit range."""
        mid = 100 - item
        return -np.abs(bins - mid)

    @staticmethod
    def _rule_almost_full(item, bins):
        """Prefer bins that are almost full; i.e., remaining capacity close to item size."""
        closeness = item - bins
        return closeness  # higher closeness = better

    @staticmethod
    def _rule_ignore_full(item, bins):
        """Prefer bins that are completely empty (capacity 100)."""
        return (bins == 100).astype(np.float64)

    def _rule_random_fit(self, item, bins):
        """Random score, ignoring item and bins. Deterministic from item index and rng."""
        # Add a small random vector based on bin count.
        return self.rng.rand(len(bins))

    # --------------------------------------------------------------------------
    # Normalize scores to zero mean, unit variance (or zeros if constant).
    # --------------------------------------------------------------------------
    @staticmethod
    def _normalize_scores(scores):
        std = np.std(scores)
        if std == 0 or np.isnan(std):
            return np.zeros_like(scores)
        return (scores - np.mean(scores)) / std

    # --------------------------------------------------------------------------
    # Compute reward for each rule after we know the consequences.
    # reward = 1 if the bin chosen by the rule did not cause a new bin to open
    # within the next self.window_size items, else 0.
    # We can only compute this retrospectively, so we store the chosen bin by each rule
    # in a history, and later evaluate rewards.
    # --------------------------------------------------------------------------
    def _update_rewards(self, item, chosen_bins_by_rule):
        """
        After placing the item, record whether each rule's chosen bin was "good".
        We approximate "good" as: the bin was not the one that just became the newest bin
        (if a new bin was opened). If no new bin was opened, all rules get reward 1.
        If a new bin was opened, the rule that caused it (i.e., its chosen bin == the new bin)
        gets reward 0; others get reward 1.
        We use the fact that bins are indexed in order of creation.
        """
        # Determine if a new bin was opened on this placement.
        # A new bin is opened if the item was placed in a previously empty bin (capacity 100).
        # Since the harness provides bins *before* placement, we cannot directly know the outcome.
        # However, we can infer it from the chosen bin's remaining capacity before placement.
        # If the bin had capacity 100, it was a new bin.
        # We use a heuristic: if the chosen bin had remaining capacity == 100, it is a new bin.
        # This works because unused bins are always shown as capacity 100.

        # But we need to know which bin was chosen by the ensemble, which is the final choice.
        # We do not have that info here unless we pass it. We'll handle rewards in the main priority function.
        pass

    # --------------------------------------------------------------------------
    # Main priority function called by harness.
    # --------------------------------------------------------------------------
    def priority(self, item, bins):
        bins = np.asarray(bins, dtype=np.int64)
        n_bins = len(bins)

        # If no bins given (should not happen, but just in case), return empty array.
        if n_bins == 0:
            return np.array([], dtype=np.float64)

        # Compute raw scores from each rule.
        rule_scores = []
        rule_chosen_bins = []
        for i, (name, rule_func) in enumerate(self.rules):
            raw = rule_func(item, bins)
            normed = self._normalize_scores(raw.astype(np.float64))
            rule_scores.append(normed)
            # Determine which bin this rule would choose:
            chosen_idx = int(np.argmax(normed))
            rule_chosen_bins.append(chosen_idx)

        # Weighted sum of normalized scores.
        ensemble_score = np.zeros(n_bins, dtype=np.float64)
        for i in range(self.num_rules):
            ensemble_score += self.ema_weights[i] * rule_scores[i]

        # Choose bin with highest ensemble score (ties go to first).
        # We don't return ensemble_score directly because tie-breaking must be deterministic.
        # Instead we return ensemble_score plus a tiny negative index bias to preserve order.
        # But the problem says: "ties go to the first such bin". Since we only rank bins,
        # we must return scores such that the highest score is unique if possible, or
        # for ties the earlier bin should have a slightly higher score.
        # So we add a tiny decreasing component based on bin index.
        tie_breaker = np.arange(n_bins, dtype=np.float64) * -1e-9
        final_scores = ensemble_score + tie_breaker

        # Before returning, update rewards and weights.
        # We need to know which bin was actually chosen (the one with highest final_score).
        actual_chosen_bin = int(np.argmax(final_scores))
        # Determine if a new bin was opened: if the chosen bin had remaining capacity == 100.
        new_bin_opened = (bins[actual_chosen_bin] == 100)

        # For each rule, compute reward.
        # If no new bin opened, all get reward 1.
        # If a new bin opened, the rule that chose the new bin gets 0, others get 1.
        for i in range(self.num_rules):
            if not new_bin_opened:
                reward = 1.0
            else:
                if rule_chosen_bins[i] == actual_chosen_bin:
                    reward = 0.0
                else:
                    reward = 1.0
            self.reward_history[i].append(reward)

        # Update EMA weights based on recent average rewards.
        # Only update if we have enough history.
        if len(self.reward_history[0]) >= self.window_size:
            avg_rewards = np.array([np.mean(hist) for hist in self.reward_history])
            # Exponential moving average:
            self.ema_weights = (1 - self.ema_alpha) * self.ema_weights + self.ema_alpha * avg_rewards
            # Normalize to sum to 1 (in case of drift due to numerical issues).
            self.ema_weights /= np.sum(self.ema_weights)

        self.total_items += 1
        return final_scores


# --------------------------------------------------------------------------
# Global state (kept between calls as requested by problem statement).
# --------------------------------------------------------------------------
_ensemble = None

def priority(item, bins):
    global _ensemble
    if _ensemble is None:
        _ensemble = EnsemblePacker()
    return _ensemble.priority(item, bins)
