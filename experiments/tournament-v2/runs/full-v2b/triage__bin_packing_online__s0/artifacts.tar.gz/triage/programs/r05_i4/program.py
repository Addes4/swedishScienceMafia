import numpy as np

# Global state to track bin ages
bin_start_times = {}
next_bin_id = 0  # internal bin id counter (sequential as bins are created)


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    global next_bin_id, bin_start_times

    n = len(bins)
    scores = np.empty(n, dtype=np.float64)

    # Gap is the main score component: negative gap (so tighter fit higher)
    gaps = bins - item
    # Primary score: tighter fit = higher (less negative gap is better, but -gap makes it positive number)
    primary = -gaps.astype(np.float64)

    # Age component: we want younger bins to be slightly favored over older ones
    # when primary scores are identical.
    # We assign each bin an "age score" based on when it received its first item.
    # For unused bins (capacity 100 and not yet seen), we assign a neutral age score.
    # For bins already seen, younger bins get a higher age score.
    
    # We need a consistent bin identity across calls. Since `bins` is a copy and bins
    # appear in fixed order, we can identify bins by their index in the array.
    # However, bins are filled in order: the harness pre-creates many bins and `bins` 
    # includes all of them. A bin's "first item time" corresponds to the first call where
    # it was eligible and was the chosen bin. But since we need to assign age *before*
    # the bin is chosen, we can track when a bin *appears* in the bins array as unused.
    # Actually, simpler: we can assign an age based on the call count when the bin first 
    # appeared with capacity < 100, indicating it was used. For unused bins (cap=100), 
    # we don't know if they'll be used. But the `bins` array length equals number of items 
    # so far? The problem says "There are as many bins as items". That simplifies things:
    # at item `t`, there are `t+1` bins. Bin indices are fixed. We can just record when 
    # each bin index first received an item (i.e., was the selected bin). For bins not 
    # yet selected, they have never been used. To break ties among unused bins, we could 
    # use a "first seen" time, but that's less critical. The idea is: when primary gaps 
    # are equal, favor the bin that started most recently among used bins. For unused bins, 
    # they haven't "started", so we can treat them as younger than used bins or older? 
    # Let's treat unused bins as having age = current_time, meaning they are "born" now.
    # Actually, better: assign each bin index a "first_used_time" when it gained its first 
    # item. For bins never used, we assign current_time as their age, making them youngest,
    # which means if gaps equal, we would prefer an unused bin over an older used bin? 
    # That might spread items. The idea: "prioritize the bin that started filling most 
    # recently to consolidate items into fewer actively-growing bins while leaving older 
    # bins with more remaining space" — so we want to favor recently started bins over 
    # older started bins, and presumably not favor unused bins over recently started ones 
    # unless we want to start new bins frequently. Let's interpret: we have several bins 
    # with same gap. We prefer the youngest used bin among them, so that items go into 
    # actively growing bins, and older bins stabilize with larger remaining capacity, 
    # making them available for future large items. Unused bins (capacity 100) are 
    # effectively "infinitely young"? If we give them high age score, we might start new 
    # bins prematurely. Better: assign age = time_of_first_item for used bins, and for 
    # unused bins assign a very low age score (like -inf) so they are only chosen when 
    # no used bin has the same gap? That would discourage opening new bins. But if no 
    # used bin fits (not in `bins` since `bins` only includes bins the item fits in), 
    # then we have to open a new bin — but `bins` always includes unused bins with 
    # capacity 100, so the item will fit. If we give unused bins low age score, we might 
    # instead put the item into an older used bin that has the exact same gap? That 
    # would consolidate. However, the problem says "prioritize the bin that started 
    # filling most recently". So we want to break ties in favor of recently started bins. 
    # For identical gaps, prefer younger used bin over older used bin. For an unused bin 
    # vs. a used bin with same gap, which to prefer? If we prefer unused, we'd open a 
    # new bin; if we prefer used, we'd consolidate into existing bin. Consolidation seems 
    # better to reduce bin count, but the statement "consolidate items into fewer 
    # actively-growing bins" suggests that we want recently started bins to get more items, 
    # making them grow quickly, rather than spreading across many bins. That implies we 
    # should prefer recently started bins even over unused bins? Actually, if a recently 
    # started bin has same gap as an unused bin (capacity 100 minus item), that means the 
    # recently started bin has some remaining capacity exactly equal to the gap we'd get 
    # from an empty bin. That's unlikely unless the new bin has capacity 100 and the item 
    # is small. In that case, the unused bin is identical. Let's just assign age as: 
    # for bins that have received at least one item, age = time of first item; for bins 
    # never used, age = a large future time? To favor used recently started bins over 
    # unused, we want younger age (higher score) for recently started used bins. Unused 
    # bins could be considered born at the current call, making them even younger, which 
    # would favor opening new bins over using an older used bin with same gap. That might 
    # lead to more bins. To avoid that, we can give unused bins an age of -1 (very old). 
    # Then a recently started used bin (age high) will be preferred over unused bin. 
    # That matches "consolidate into fewer actively-growing bins": we prefer sending 
    # items to bins that have already started, as long as they have the same tight fit, 
    # rather than opening new bins. And among used bins, we prefer the most recently 
    # started one, so that one bin grows quickly.

    # Implementation: maintain a dictionary bin_first_use_time[bin_index] = call_index.
    # call_index increments each time priority() is called.
    
    if not hasattr(priority, "call_counter"):
        priority.call_counter = 0
    priority.call_counter += 1
    current_time = priority.call_counter

    # Initialize bin_start_times as global? We'll use a closure or function attribute.
    if not hasattr(priority, "bin_start_times"):
        priority.bin_start_times = {}

    # For each bin, determine age score
    age_scores = np.zeros(n, dtype=np.float64)
    for i in range(n):
        # We don't have the actual bin index from the harness's perspective,
        # but we have the array index. Is the array index stable across calls?
        # The harness says "bins appear in a fixed order (bin index)" so bin index 
        # corresponds to position in array? Yes, probably. However, new bins are appended?
        # The problem: "There are as many bins as items; unused bins have remaining capacity 100 
        # and are included." That means after processing t items, there are t+1 bins? Or t bins?
        # It says "as many bins as items" — likely at start there are 0 bins? When first item 
        # arrives, there is at least 1 bin (unused, capacity 100). So number of bins equals 
        # number of items seen so far? Actually, if items arrive one by one, and we start with 
        # some bins? The harness pre-allocates bins? The problem statement: "There are as many 
        # bins as items; unused bins have remaining capacity 100 and are included." It likely 
        # means that at any point, the harness provides an array of bins whose length equals 
        # the number of items seen so far? Or maybe it's a fixed large number? "as many bins 
        # as items" suggests that when the first item arrives, len(bins) == 1? But then that 
        # bin has capacity 100, and after placing, it has capacity <100. For second item, 
        # len(bins) == 2? That would mean bin indices correspond to arrival order. 
        # That is plausible: the harness creates a new bin for each item (so bins.length 
        # = item_index + 1?). But then it says "including unused bins (remaining capacity 100)". 
        # If a new bin is created for each item, then the array length grows by 1 each call.
        # In that case, the bin index in the array is exactly the bin's identity and the 
        # "first used time" can be set when we first put an item into that bin. Since we only 
        # see bins that the item fits in, we might not see all bins? Actually, the item fits 
        # into bins with capacity >= item. If we have many bins, some might be too full, 
        # and those are not included. So the `bins` array is filtered to only those where 
        # item fits. But the order is preserved based on bin index. So we need to know 
        # which original bin index each entry corresponds to. The problem says "Bins appear 
        # in a fixed order (bin index), and the array is a copy." So if they give a subset, 
        # we may not know the original indices unless we track. Wait, it says "bins is a 
        # numpy int64 array with the remaining capacity of every bin the item fits in." 
        # "every bin the item fits in" — so it's not all bins, only those with enough capacity. 
        # "unused bins have remaining capacity 100 and are included" — so all unused bins 
        # (capacity 100) are included, since item size <=100, they always fit. So the array 
        # contains: all bins where remaining capacity >= item size, which includes all unused 
        # bins (capacity 100) and any partially filled bins with enough space. The order is 
        # by bin index. We need to map each entry back to its persistent bin index to assign 
        # age. How to do that? The harness doesn't provide bin indices. We'll have to infer 
        # based on capacity changes. But we can also keep a state of all bins' remaining 
        # capacities by index and track which index corresponds to which position. However, 
        # we don't know the current capacities of bins not shown. The only safe way is to 
        # use the fact that the harness fills bins according to our returned priorities, 
        # and we can maintain a model of the bin state. Since we only see bins that the item 
        # fits in, we can't directly track all bins without maintaining our own simulation 
        # of the bin fill levels. But that adds complexity and might drift if we mis-predict 
        # the harness's actual placement (which is exactly our choice). We can simulate exactly 
        # because we know which bin gets chosen (the highest score, first ties). So we can 
        # maintain a parallel array of bin remaining capacities, initialized to 100 for the 
        # first item. For each call, we get a list of bins with capacities. We must map these 
        # capacities to our simulated bins to find indices. But the harness may not include 
        # bins that don't fit; we only see those that fit. In our simulation, we know all bins. 
        # At each step, we can compute the true bins array (all bins where capacity >= item) 
        # and assign priorities. The harness will give us `bins` which should match our 
        # simulation's array if we maintain it correctly. So we can keep a global list 
        # `bin_capacities` of all bins created (starting empty). We'll simulate exactly 
        # the bin state and at each call, verify that the harness-provided `bins` matches 
        # our simulated bins for the fitting ones.

    # Let's design:
    # - We maintain a list `capacities` representing all bins in order.
    # - Initially empty.
    # - On first call, we create one bin? Or harness creates one bin? Let's infer from problem: 
    #   "There are as many bins as items" — maybe for item 1, bins = [100]. For item 2, bins
    #   might be [remaining1, 100] if first bin still fits, or just [100] if first bin too full.
    #   But they said "unused bins have remaining capacity 100 and are included". So even if 
    #   item 2 doesn't fit in first bin, there is still an unused bin (capacity 100). So the array
    #   will include at least one 100. The harness likely maintains a list of bins and when an item
    #   doesn't fit in any existing bin, it adds a new bin. That is standard online bin packing.
    #   The "as many bins as items" might mean they pre-allocate N bins for N items (5000 bins from 
    #   the start). Then `bins` is the whole array of length 5000, with capacities 100 for unused 
    #   bins. That would make bin indices constant and we can just use the array index directly.
    #   Let's read carefully: "There are as many bins as items; unused bins have remaining capacity 
    #   100 and are included. Bins appear in a fixed order (bin index), and the array is a copy."
    #   This strongly suggests that at any time, the `bins` array has length equal to the current 
    #   number of items (or total number of items that have ever arrived? "as many bins as items" 
    #   probably means total items over the whole instance, i.e., 5000 bins are pre-allocated, all 
    #   starting at capacity 100, and after each placement, one bin's capacity is reduced. 
    #   For each call, we get the capacities of all bins that the current item fits into. That 
    #   would be a subset of the 5000 bins (those with capacity >= item). Unused bins (capacity 100)
    #   are included. So bin indices are fixed 0..4999. We can use the index in the provided array
    #   to identify the bin? No, because the provided array is only the subset that fits, but 
    #   "Bins appear in a fixed order (bin index)" — so the order in the sub-array is ascending 
    #   bin index. We don't know the absolute index just from position because we don't know how 
    #   many bins were omitted before each included bin. However, we can know that the first element 
    #   is the lowest bin index that fits. To map back to absolute index, we need to know which 
    #   bins fit. Since we can simulate the bin capacities from the start using exactly the same 
    #   placement decisions, we can maintain a full array `all_capacities` of length 5000 (or 
    #   however many item count). Initially all 100. For each call, we can generate the list of 
    #   bin indices that fit: [i for i, cap in enumerate(all_capacities) if cap >= item]. 
    #   Then we know that the harness-provided `bins` array is the capacities of exactly those 
    #   bins, in order. So we can map: the k-th element corresponds to our known fitting bin index.
    #   Then we can assign ages based on our tracked first_use_time for those absolute indices.
    #   This simulation should stay in sync because we use the same tie-breaking rule as the harness
    #   (highest score, first tie). We just need to ensure our simulated placement matches.

    # Implementation steps:
    # - Use function attributes to persist state:
    #   priority.all_caps = numpy array of length N (unknown N). We can grow it dynamically because
    #     number of items not known in advance? The problem says each instance has 5000 items.
    #     We can assume N = 5000 and allocate once on first call.
    #   priority.first_use_time = list length N, initialized to None.
    #   priority.call_count = 0.
    # - On each call:
    #   call_count += 1
    #   if first call:
    #       N = len(bins) because at first call, item=?, bins includes all bins? Actually first item,
    #       all bins are capacity 100, so all bins fit, so bins array length equals total bins.
    #       That length is the number of items? But "as many bins as items" suggests length == number
    #       of items to be processed overall? For first item, we don't know total items. Could be 5000.
    #       But we can just see the length of the first bins array; presumably it's 5000 (pre-allocated).
    #       We'll initialize all_caps = np.full(len(bins), 100, dtype=np.int64)
    #       first_use_time = [None]*len(bins)
    #   else:
    #       The bins array length may be smaller as some bins become too full to fit the current item.
    #       We need to compute the indices of bins that fit based on our all_caps.
    #   Compute fitting_indices = np.where(all_caps >= item)[0]
    #   Verify len(fitting_indices) == len(bins) (should match, else error in simulation).
    #   Extract fitted_caps = all_caps[fitting_indices] and check if close to bins? Not strictly necessary but for sanity.
    #   Now we have absolute bin indices for each position.
    #   Compute primary score: - (fitted_caps - item)  [which is gaps negative]
    #   Age score: for each idx, if first_use_time[idx] is None, age_score = -np.inf? We'll use a large negative value.
    #       else age_score = first_use_time[idx] (higher = younger).
    #   Combine: total_score = primary + epsilon * age_score, where epsilon is very small so that age
    #       only breaks ties when primary scores are exactly equal (since scores are integers? primary scores
    #       are integers because gaps are ints. But we need tie-breaking only when primary equal. We can add
    #       a small epsilon * age_score. Ensure age_score range is such that it cannot override primary.
    #       Max age_score = call_count (up to 5000). We can scale age_score to < 1.0. For example:
    #       epsilon = 1e-6, age_norm = age_score / 10000. Then primary + age_norm will not affect integer
    #       boundaries as long as age_norm < 1.0. Since max age is 5000, age_norm max = 0.5, fine.
    #   For unused bins, we want them to be less preferred over recently used bins. So set their age_score
    #       to -1 (or very low). Then primary + epsilon*age_score will be lower than any used bin with 
    #       same primary (since used age >= 0). That ensures we prefer used recently started bins over 
    #       opening new bins when gaps are equal. But what if there are multiple unused bins? They'll all
    #       have same low age_score, ties broken by order (first). That's fine.
    #   Return the scores array of length len(bins).
    #   After returning, we must simulate the placement to update all_caps and first_use_time for the chosen bin.
    #   We need to know which bin was chosen. The harness will pick the bin with highest score, first on ties.
    #   We replicate that choice: find max score index in our scores array. That position corresponds to
    #   fitting_indices[best_pos]. Bin absolute index = fitting_indices[best_pos].
    #   all_caps[bin_idx] -= item
    #   if first_use_time[bin_idx] is None:
    #       first_use_time[bin_idx] = call_count
    #   Then we're done for this call.

    # This approach perfectly mirrors the harness and provides accurate age tracking.

    # We'll store state in function attributes to avoid global variables (cleaner).
    if not hasattr(priority, "initialized"):
        # First call: initialize
        # Total bins = len(bins) because at first call, all bins fit (capacity 100)
        total_bins = len(bins)
        priority.all_caps = np.full(total_bins, 100, dtype=np.int64)
        priority.first_use = np.full(total_bins, -1, dtype=np.int32)  # -1 means never used
        priority.call_count = 0
        priority.initialized = True

    priority.call_count += 1
    current_time = priority.call_count

    # Get fitting indices from our simulated capacities
    fitting_mask = priority.all_caps >= item
    fitting_indices = np.where(fitting_mask)[0]
    # The bins array provided by harness must correspond exactly
    if len(fitting_indices) != len(bins):
        # If mismatch, fallback to baseline without age (shouldn't happen if simulation correct)
        scores = -(bins.astype(np.float64) - item)
        return scores

    # Primary scores (gaps negative, so higher is tighter)
    gaps = bins - item  # bins is array of capacities from harness, but we can use our own all_caps[fitting_indices]
    primary = -gaps.astype(np.float64)

    # Age scores
    ages = priority.first_use[fitting_indices]
    # For bins never used (-1), treat as very old
    # For used bins, age = current_time - first_use_time? Actually younger bins have larger first_use_time.
    # We want higher score for younger bins. So age_score = first_use_time (higher is younger).
    # For unused, we can set age_score = -1 so they are older than any used bin.
    age_score = np.where(ages != -1, ages.astype(np.float64), -1.0)

    # Combine: epsilon small enough not to override primary integer differences.
    epsilon = 1e-6 / (current_time + 1)  # ensure age contribution < 0.5
    scores = primary + epsilon * age_score

    # Determine the chosen bin by replicating harness decision (max, first tie)
    best_pos = np.argmax(scores)
    chosen_abs_idx = fitting_indices[best_pos]

    # Update simulation
    priority.all_caps[chosen_abs_idx] -= item
    if priority.first_use[chosen_abs_idx] == -1:
        priority.first_use[chosen_abs_idx] = current_time

    return scores
