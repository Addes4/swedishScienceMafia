# EVOLVE-BLOCK-START
"""Best-of-three best-fit: among the three tightest-fitting bins, pick the fullest.

Idea: best fit (tightest remaining capacity after placement) is the standard strong
online rule for this item distribution.  Ties or near-ties in tightness can be broken
to improve consolidation: prefer the bin that already has the most absolute content
(100 - remaining capacity), which tends to fill bins up rather than leave many
half-full bins, and avoids wasting small items in fresh bins when a tighter but
emptier bin exists.  Here we take the three tightest-fitting bins (smallest residual
after placing the item) and among them select the one with the largest current fill.
"""
import numpy as np


def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100), in bin order.
    """
    # Tightness = remaining capacity after placement (best fit wants this minimal).
    residual = bins - item
    # Current fill of each bin.
    fill = 100 - bins

    n = bins.shape[0]
    k = 3 if n > 3 else n

    # Indices of the k tightest-fitting bins.  Use argpartition for efficiency,
    # then order those k by residual so the array itself defines the tie order.
    if k < n:
        cand = np.argpartition(residual, k - 1)[:k]
    else:
        cand = np.arange(n)

    # Among candidates, choose the fullest bin; ties resolved by smallest residual
    # first, then by bin index (stable through ordering of `cand`).
    # Build a single sort key: (-fill, residual) so the best is first.
    sub_fill = fill[cand]
    sub_res = residual[cand]
    # lexsort sorts by last key primary; primary = -fill, secondary = residual
    order = np.lexsort((sub_res, -sub_fill))
    best = cand[order[0]]

    # Score array: give a small positive score only to the chosen bin, everything
    # else strictly lower.  Since ties go to the first bin, ensure uniqueness by
    # putting the winner above all others.
    scores = np.zeros(n, dtype=np.float64)
    scores[best] = 1.0
    return scores
# EVOLVE-BLOCK-END
