import numpy as np

# Keep running statistics across calls:
# We need a mutable state visible across invocations of priority().
# Since only this function is called, we store state in priority's attributes.
# The idea: track the running mean of item sizes seen so far.
# For items larger than the mean, use classical best-fit (tightest).
# For smaller items, prefer bins where the resulting occupancy (100 - (remaining - item))
# is as close to 100 as possible, i.e., minimize remaining capacity after placement,
# but with a preference for exact fits (remaining == item). This semi-harmonic idea
# can be implemented by scoring bins higher when (remaining - item) is small,
# but we want to favor bins where (remaining capacity + item) is close to 100?
# Actually the description says: "score bins by remaining capacity + item to favor bins
# where the sum is close to 100 (semi-harmonic)". That suggests scoring based on
# abs( (remaining_capacity + item) - 100 )? Wait: remaining capacity is what's left in bin.
# Placing item of size s into bin with remaining r gives new remaining = r - s.
# The sum of items in bin after placement is (100 - (r - s)) = 100 - r + s.
# So remaining capacity + item = r + s? Not directly related to 100.
# Rethinking: they might mean score bins based on (remaining_capacity + item) being close to 100?
# Let's interpret: for smaller items, we want to pack bins more tightly, aiming for bins that become
# nearly full. When placing, the new occupancy = (100 - remaining) + item = 100 - (remaining - item).
# So the empty space after placement is remaining - item. We want that to be small.
# The "remaining capacity + item" is r + s. If we want r + s close to 100? That would mean
# the bin after placement has occupancy = 100 - (r - s) = 100 - r + s. To make that close to 100,
# we need -r + s close to 0 => r close to s. That's exactly best-fit. Hmm.

# Maybe the idea is: when item <= mean, we use a scoring that is a mix: we want bins where the
# resulting empty space is small, but we also give some preference to bins that are already
# partially filled? The phrase "semi-harmonic" might refer to using something like
# score = 1/(remaining - item + 1) or similar. But the exact line: "score bins by remaining capacity + item
# to favor bins where the sum is close to 100". Possibly they meant: score = -abs((remaining_capacity + item) - 100).
# Let's try that: for small items, priority = -abs(bins + item - 100). But that essentially always
# prefers bins where r + s closest to 100. For s small, r must be large (~100 - s). That is opposite of best-fit.
# Could be a "harmonic" blend: for large items use best-fit, for small items use worst-fit? Not sure.

# To stay safe, implement the literal instruction:
# For items > mean: return -(bins - item) (best-fit).
# For items <= mean: return -abs(bins + item - 100) (favor sum close to 100).
# That's simple and matches the description.

# We'll keep a running mean using an online update (Welford's or simple cumulative average).
# Since numpy is available, we can store count and mean.

def priority(item, bins):
    # Initialize state if not present
    if not hasattr(priority, "count"):
        priority.count = 0
        priority.mean = 0.0

    # Update running mean with current item (before deciding placement, we know item size)
    priority.count += 1
    # Numerically stable online mean update
    priority.mean += (item - priority.mean) / priority.count

    # Decision based on current mean
    if item > priority.mean:
        # Best-fit: prefer bins where the remaining capacity after placement is minimal,
        # i.e., bins where (remaining - item) is non-negative and smallest.
        # Using negative of (bins - item) gives highest score to smallest (bins - item).
        return -(bins - item).astype(float)
    else:
        # For smaller items, favor bins where the resulting sum of remaining capacity and item
        # is close to 100. (bins + item - 100) absolute value, negated for higher score.
        # Ties go to first bin as required (we return same score for ties, harness picks first).
        return -np.abs(bins + item - 100).astype(float)
