# EVOLVE-BLOCK-START
"""Online bin packing: relative regret rule based on smoothed item-size histogram.

This rule implements the "relative regret" idea:
1. Maintain a running histogram of all item sizes observed so far across calls.
2. Build a cumulative distribution function (CDF) of item sizes once we have enough data.
3. For each bin, score based on the probability that a future item will fit in that
   bin with a strictly smaller gap than the current leftover capacity.
4. Use (1 - that probability) as the score, so lower regret = higher priority.
5. Ties go to the first bin shown; numpy operations ensure in-place indexing.
"""
import numpy as np


# Persistent module-level state for bin packing logic
_item_histogram = None
_item_count = 0
_item_cdf = None


def priority(item, bins):
    """
    Score bins by relative regret:
    For each bin, compute the probability that a future item (from observed distribution)
    will fit with a gap strictly smaller than `bins[i] - item`. Use that as a regret
    indicator. Return 1 minus that probability as the score (higher = less regret).

    Parameters
    ----------
    item : int
        Size of the arriving item (1 <= item <= 100).
    bins : np.ndarray
        int64 array of remaining capacity for each fit-able bin (bins >= item).

    Returns
    -------
    np.ndarray
        Scores matching length of `bins`; item placed in the highest value.
    """
    global _item_histogram, _item_count, _item_cdf
    
    # Record this item into the persistent histogram
    _item_histogram = np.zeros(101) if _item_histogram is None else _item_histogram.copy()
    _item_histogram[item] += 1
    _item_count += 1
    
    # Not enough data yet
    if _item_count < 10:
        return np.ones_like(bins, dtype=np.float64)
    
    # Build CDF once per distribution
    if _item_cdf is None or _item_histogram.sum() != _item_count:
        _item_cdf = np.cumsum(_item_histogram) / _item_histogram.sum()
    
    # Current gap after placing this item
    current_gap = bins - item
    
    # For each bin, score by regret: probability a future item would fit
    # with smaller gap (less than current_gap)
    regret_idx = np.maximum(current_gap - 1, 0, out=np.zeros_like(current_gap, dtype=np.int64), where=True)
    regret_prob = _item_cdf[regret_idx]
    
    # Each bin's score as (1 - P(future item fits tighter))
    return np.asarray(1.0 - regret_prob, dtype=np.float64)


# EVOLVE-BLOCK-END
