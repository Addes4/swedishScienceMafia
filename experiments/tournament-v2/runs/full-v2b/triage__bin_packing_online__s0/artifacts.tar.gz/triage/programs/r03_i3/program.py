# EVOLVE-BLOCK-START
"""Active/empty partition with tight-space preservation.

- Active bins: remaining capacity < 100 (partially filled).
- Empty bins: remaining capacity == 100 (completely unused).

If the item would fill an active bin to at least 95% of its remaining capacity
(i.e. slack < 5% of remaining capacity), we prefer to save that bin for an even
better match and instead place the item in the most-filled empty bin available.

Otherwise, use standard best-fit among active bins, falling back to first empty bin
if no active bin can take the item.
"""

import numpy as np


def priority(item: int, bins: np.ndarray) -> np.ndarray:
    n = len(bins)
    scores = np.full(n, -np.inf)

    # Identify active bins: those with remaining capacity < 100.
    active_mask = bins < 100
    empty_mask = ~active_mask  # bins == 100

    # Among active bins, find the slack if item is placed
    slack = bins[active_mask] - item

    # Tight fit condition: slack >= 0 and slack / remaining_capacity < 0.05
    # Equivalently: slack < 0.05 * bins[active_mask]
    tight_mask = (slack >= 0) & (slack < 0.05 * bins[active_mask])

    # Best-fit normally: residual capacity = bins - item, lower is better => higher score
    # We'll use -residual so that smaller residual => higher score.
    active_scores = -bins  # Base: larger bins get lower priority initially. Let's refine.

    # We want two tiers:
    # 1) Normal active bins: best-fit (smallest slack gets highest priority).
    # 2) Tight-fit active bins: deliberately lower priority than any empty bin, but
    #    among themselves still use best-fit.
    # 3) Empty bins: base priority between tight-active and normal-active.
    #    For the tight-fit case we prefer the MOST-LOADED empty bin: i.e., smallest
    #    slack when placed into empty bin (which has capacity 100).
    #    Since all empty bins have capacity 100, placing item in empty bin gives
    #    residual 100 - item. So all empty bins tie. The harness picks the first on tie.
    #    To prefer "most-loaded" empty bin we need to differentiate them. But they are identical:
    #    we cannot see their index order to break tie except that the harness does first.
    #    So within empty bins, we cannot prefer a particular one based on loading.
    #    So we just use constant priority for all empty bins.

    # We assign numerical scores:
    #  - normal active: 100000 - slack   (so smaller slack => larger score)
    #  - empty bins:    50000             (below normal active but above tight active)
    #  - tight active:   -bins            (highest priority among them to smallest slack)
    # Actually we need tight active to be LOWER than empty.
    # So: normal active > empty > tight active.
    # Let's set normal active base = 1000, empty base = 500, tight active base = 0

    # Normal active: score = 1000 + (capacity - item) inverted
    # smaller residual => higher score.
    slack_normal = bins[active_mask] - item
    # Among active, tight_mask identifies those with tight fit
    normal_active_idx = np.where(active_mask)[0][~tight_mask]
    tight_active_idx = np.where(active_mask)[0][tight_mask]

    if len(normal_active_idx) > 0:
        # Score: 1000 - slack (so slack 0 gives 1000; slack 50 gives 950)
        scores[normal_active_idx] = 1000.0 - slack[~tight_mask].astype(float)

    if len(tight_active_idx) > 0:
        # Score: 0 - slack (slack 0 gives 0; larger slack gives negative)
        scores[tight_active_idx] = 0.0 - slack[tight_mask].astype(float)

    # Empty bins: score 500
    if np.any(empty_mask):
        scores[empty_mask] = 500.0

    return scores
# EVOLVE-BLOCK-END
