import numpy as np

# State for reserve tracking
_reserve_state = {
    'ema_frac': 0.0,                # exponential moving average of fraction of items > threshold
    'alpha': 0.01,                  # smoothing factor for EMA
    'threshold': 80,                # large item threshold
    'reserve_target': 0,            # target number of bins to keep with capacity >= threshold
    'total_bins_so_far': 0,         # total bins used so far (including unused ones shown)
    'reserve_bins_count': 0,        # current number of bins with capacity >= threshold
    'initialized': False
}

def priority(item, bins):
    """
    Best-fit with dynamic reserve for large items.
    Tracks fraction of large items via EMA, sets a target number of bins
    to keep with capacity >= threshold. Strong penalty for breaking reserve.
    """
    global _reserve_state
    state = _reserve_state
    
    # Initialize on first call
    if not state['initialized']:
        state['initialized'] = True
        # The number of bins shown equals number of items so far (current call index + 1)
        # We'll initialize counts based on the bins array length
        state['total_bins_so_far'] = len(bins)
        state['reserve_bins_count'] = np.sum(bins >= state['threshold'])
        # Set initial target based on current state and expected fraction
        expected_large = state['ema_frac']
        state['reserve_target'] = max(1, int(expected_large * len(bins) * 1.2))  # 20% buffer
    else:
        state['total_bins_so_far'] += 1
    
    # Update EMA of large item fraction
    is_large = 1.0 if item > state['threshold'] else 0.0
    state['ema_frac'] = state['alpha'] * is_large + (1 - state['alpha']) * state['ema_frac']
    
    # Current reserve count
    current_reserve = np.sum(bins >= state['threshold'])
    state['reserve_bins_count'] = current_reserve
    
    # Dynamic reserve target: keep at least expected_large * total_bins bins with capacity >= threshold
    # Add a small buffer (e.g., 2 extra bins or 10% more)
    target = max(1, int(state['ema_frac'] * state['total_bins_so_far'] * 1.15))
    # Also ensure at least a minimum fraction of all bins (e.g., 5%)
    target = max(target, int(0.05 * state['total_bins_so_far']))
    state['reserve_target'] = target
    
    # Compute base scores: best-fit (negative waste)
    waste = bins - item
    base_score = -waste.astype(float)  # best fit: higher (less negative) is better
    
    # Determine which bins would drop below threshold if we place the item
    would_drop = (bins >= state['threshold']) & (bins - item < state['threshold'])
    
    # Check if we are below target reserve and this bin would reduce reserve
    if current_reserve <= target:
        # Apply a large penalty to bins that would drop below threshold
        # The penalty should be strong enough to override best-fit unless no alternative
        penalty = -1000.0  # Very negative score
        base_score[would_drop] += penalty
    else:
        # We have enough reserve, but still slightly discourage breaking reserve
        # to maintain good distribution
        if current_reserve > target * 1.2:  # 20% above target, no penalty
            pass
        else:  # close to target, mild penalty
            penalty = -10.0
            base_score[would_drop] += penalty
    
    return base_score
