import numpy as np

SMALL_THRESHOLD = 20  # items <= this size use worst-fit

def priority(item, bins):
    """
    Return scores for each bin.
    For small items: favor the bin with the *most* remaining capacity (worst-fit)
    so that large bins remain available for future big items.
    For larger items: use best-fit (prefer tightest fit).
    """
    if item <= SMALL_THRESHOLD:
        # worst-fit: higher remaining capacity gets higher score
        return bins.astype(np.float64)
    else:
        # best-fit: tighter fit gets higher score (less waste -> higher score)
        return -(bins - item).astype(np.float64)
