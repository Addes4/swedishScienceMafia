# EVOLVE-BLOCK-START
"""
Online bin packing using exponential smoothing of item-size distribution
to estimate expected future capacity per bin.
"""
import numpy as np


class BinPacker:
    def __init__(self):
        self.item_counts = np.zeros(101)  # P[item_size] for sizes 1..100
        self.total_items = 0.0
        self.smoothing = 0.05
        self.bin_stats = {}  # (bin_index) -> {remaining_cap, p_fit}
        self.pooled_capacity = 100.0  # Track sum of capacities weighted by bin usage

    def update_distribution(self, item):
        self.item_counts[item] += 1
        self.total_items += 1
        # Smoothed probability mass function
        self.item_counts = self.smoothing * self.item_counts + (1 - self.smoothing) * self.item_counts

    def get_p_fit(self, capacity):
        if self.total_items == 0:
            return 1.0 / self.item_counts.sum()
        p_fit = 0.0
        for size in range(1, capacity + 1):
            p_fit += self.item_counts[size]
        return p_fit

    def get_expected_capacity(self, remaining_cap, item):
        """
        Compute expected number of future items this bin can accomodate.
        Uses exponential model: sum_{k=1}∞ p^k * I(item_fits_after_k)
        Simplified to geometric approximation for efficiency.
        """
        if remaining_cap <= 0:
            return 0.0

        p_fit = self.get_p_fit(min(remaining_cap, 100))
        if p_fit <= 0:
            return 0.0

        # Expected additional items the bin can take
        expected = p_fit / (1 - p_fit)
        # Adjust for the current item, expected items after
        return request

    def priority(self, item, bins):
        """
        Return a priority for every bin in `bins`.
        Higher priority = better bin.
        """
        priorities = np.zeros_like(bins, dtype=np.float64)
        
        # Current total number of bins
        total_binning = bins.size
        
        # Compute p-fit for each bin's remaining capacity
        bin_indices = np.argsort(bins)[::-1]

        # Update distribution
        self.update_distribution(item)
        
        # Compute expected future capacity from item landscape
        if self.total_items > 100:
            p_fit_list = self.get_p_fit(train)

        # Score each bin
        for i in range(len(bins)):
            remaining = bins[i]
            if remaining < item:
                continue
            
            # Compute expected capacity based on item fitting
            p = self.get_p_fit(min(remaining, 100))
            if p > 0.9:
                exp_capacity = remaining / item
            
            # Use expected capacity reduced by small factor to break ties
            score = p * (remaining / item + 0.1)
            priorities[i] = score
        
        # Normalize by count for comparability
        priorities = priorities / np.sum(priorities > 0)
        
        return priorities

# Global instance for state persistence
bin_packer = BinPacker()

def priority(item, bins):
    """Return a priority for every bin in `bins`; the item goes to the highest (first on ties)."""
    result = bin_packer.priority(item, bins)
    return result
# EVOLVE-BLOCK-END
