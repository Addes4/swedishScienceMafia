import numpy as np
import bisect

# Empirical distribution of past items (shared across calls).
_COUNTS = np.zeros(101, dtype=np.float64)
_RNG = np.random.default_rng(20240517)


def _draw_items(m):
    """Sample m synthetic future item sizes from the running empirical distribution."""
    tot = _COUNTS.sum()
    if tot < 8.0:
        return [int(v) for v in _RNG.integers(1, 101, size=m)]
    p = _COUNTS / tot
    return [int(v) for v in _RNG.choice(np.arange(1, 101), size=m, p=p)]


def priority(item, bins):
    """Rank bins by best-fit residual, adjusted by a short best-fit rollout signal.

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with remaining capacity of every bin the item fits in.
    """
    _COUNTS[item] += 1.0
    bins = np.asarray(bins)
    n = bins.size
    if n == 0:
        return np.zeros(0, dtype=np.float64)

    residual = (bins - item).astype(np.float64)
    bestfit = -residual  # higher (closer to 0) = tighter fit = preferred

    # --- Bounded environment sample (shared across all candidates for fairness) ---
    M = 48
    if n <= M:
        env = [int(v) for v in bins]
    else:
        idx = _RNG.integers(0, n, size=M)
        env = [int(v) for v in bins[idx]]
    env.sort()

    # --- Synthetic future items (identical across candidates) ---
    L = 3
    seq = _draw_items(L)

    # --- Candidate set: tightest fits + loosest (likely empty) bins ---
    Kt, Kl = 6, 4
    if n <= Kt + Kl:
        cand = list(range(n))
    else:
        tight = np.argpartition(residual, Kt - 1)[:Kt].tolist()
        loose = np.argpartition(-bins, Kl - 1)[:Kl].tolist()
        cand = list(dict.fromkeys(tight + loose))

    score = bestfit - 1.0e6  # non-candidates sit far below every candidate

    for c in cand:
        cap = int(bins[c]) - item
        w = env.copy()
        bisect.insort(w, cap)  # insert this candidate's resulting capacity
        newbins = 0
        for x in seq:
            i = bisect.bisect_left(w, x)  # best fit: smallest capacity >= x
            if i < len(w):
                v = w.pop(i)
                bisect.insort(w, v - x)
            else:
                newbins += 1  # nothing fits -> a fresh bin would be needed
                bisect.insort(w, 100 - x)
        # Best-fit primary; rollout fragmentation as a secondary, mild signal.
        score[c] = bestfit[c] - 8.0 * newbins

    return score
