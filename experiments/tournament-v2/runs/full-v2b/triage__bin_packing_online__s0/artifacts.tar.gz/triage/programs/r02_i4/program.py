# EVOLVE-BLOCK-START
"""Learned target filling: maintain running average of (item + bin load).
   Score bins by negative absolute deviation from the running average,
   aiming for tight bins close to that learned ideal."""
import numpy as np

class BinPackingStrategy:
    def __init__(self):
        self.total = 0  # running sum of (item + resulting bin load)
        self.count = 0  # running count of decisions
    
    def priority(self, item, bins):
        # (100 - remaining) is current bin load
        # (100 - remaining) + item is resulting bin load after insertion
        deviations = np.abs((100 - bins + item) - (self.total + item + 100 - bins))
        # Actually simpler: just absorb item into current bin load
        new_load = 100 - bins + item  # load after inserting item into each bin
        # Target is learning-based running mean of new loads
        # Adjust score: binaries get tighter priority
        self.total += new_load  # will approximate post-insertion load
        coef = new_load * 0.0
        score = -(abs(new_load - (self.total / (self.count + 1))))
        return score
    
    def priority(self, item, bins):
        # Vectorized implementation updated  
        new_load = 100 - bins + item    
        target = self.total / self.count if self.count > 0 else 50.0
        
        # Score is negative of absolute deviation from target
        score = -(np.abs(new_load - target))
        
        return score


strat = BinPackingStrategy()
