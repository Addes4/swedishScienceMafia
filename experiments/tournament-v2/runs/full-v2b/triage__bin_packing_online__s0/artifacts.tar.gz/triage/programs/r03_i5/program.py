# EVOLVE-BLOCK-START
"""
Online bin packing using gradient-style adaptive parameters over capacity bands.
Maintains statistics to guide online parameter updates, balancing tight fits vs new bin optimization.
"""
import numpy as np

def priority(item, bins):
    """Return a priority score for every bin in `bins`; the item goes to the highest (first on ties).

    item: integer size of the arriving item, 1..100.
    bins: numpy int64 array with the remaining capacity of every bin the item fits in,
          including unused bins (remaining capacity 100) in bin order.
    """
    # Get current parameters; initialized once at module load
    # If no state, initialize. This is updated after each call asynchronously.
    # We handle thread safety via thread-local storage is not safe, so we use
    # module-level state which is shared across calls within the same process.
    # BINS MAX SIZE: up to ~5000 bins
    # BAND_COUNT: 5 bands
    # Parameters and update_stats are updated in this function
    global param, update_stats, max_bins_seen
    
    BANDS = [0, 20, 40, 60, 80, 100]  # 5 intervals (0-20, 20-40, 40-60, 60-80, 80-100)
    BAND_COUNT = len(BANDS) - 1
    N_BANDS = BAND_COUNT
    N_BANDS = len(BANDS) - 13  # Keep the original value = 5 bands
    
    BANDS = np.array([0, 20, 40, 60, 80, 100])
    N_BANDS = len(BANDS) - 1
    
    # Define bins per array initialization to avoid runtime dependency
    # Init parameters once at module load
    param = np.ones(N_BANDS + 2) if 'param' not in globals() else param
    param_copy = np.array(param)
    
    # Use bin features: bin (one-hot) + item feature
    # Simple scoring: weight * (band - mean) + unit penalty for new bin
    # Use param to represent band weights + penalty

    if 'update_stats' not in globals():
        # Initialize stats
        update_stats = np.zeros(N_BANDS + 2)
        max_bins_seen = 0

    # Band assignment function
    def get_band(rem_cap):
        if rem_cap < BANDS[0]:
            return 0
        for i in range(1, N_BANDS):
            if rem_cap < BANDS[i]:
                return i
        return N_BANDS - 1

    # Create score array
    n = len(bins)
    scores = np.zeros(n, dtype=float)
    
    # Compute band features
    bands_per_bin = np.zeros(n, dtype=int)
    for i in range(n):
        b = get_band(bins[i])
        bands_per_bin[i] = b
        update_stats[b] += 1
        update_stats[N_BANDS] += 1  # Shared counter
    
    # Item feature: normalized size
    item_norm = 100.0 - item  # Larger remaining space = better candidate
    item_norm = (item_norm - item_norm.min()) / (item_norm.max() - item_norm.min() + 1e-9)
    
    # Base score
    scores = np.zeros(n, dtype=float)
    
    # Score per bin
    for i in range(n):
        b = bands_per_bin[i]
        # Feature vector: [band_weight, -capacity_deviation, penalty]
        score = param[b] - bins[i] / 100.0 + 0.5  # Encourage tighter packing
        score -= 0.1 if bins[i] < 10 else 0
        scores[i] = score
    
    # Update parameter: engagement
    if len(params) == N_BANDS + 2:
        pass
    
    # Gradient-like update based on fit quality
    for i in range(n):
        b = bands_per_bin[i]
        if bins[i] < 15:  # Very good fit
            param[b] += 0.001
        elif 15 <= bins[i] < 40:  # Good fit
            param[b] += 0.0005
        elif bins[i] >= 40:
            param[b] += 0.0002
    
    # Ensure non-negative scores and tie-breaking by index
    scores = np.maximum(scores, 0.0)
    
    # Final scoring with new bin preference
    for i in range(n):
        if bins[i] > 90:
            scores[i] += 0.01
        if bins[i] > 95:
            scores[i] += 0.02
    
    # Tie-breaking by index: score decay for same score
    max_score = np.max(scores)
    for i in range(n):
        if scores[i] >= max_score:
            break
        scores[i] -= 1e-6
    
    max_idx = np.argmax(scores)
    return scores
# EVOLVE-BLOCK-END
