import numpy as np
from scipy.stats import qmc

# -------- tile coding for 2D continuous state --------
# Map (rem, item) to a sparse binary feature vector.
class TileCoder:
    def __init__(self, n_tilings=8, n_tiles_per_dim=8):
        self.n_tilings = n_tilings
        self.n_tiles_per_dim = n_tiles_per_dim
        # rem in [0,100], item in [1,100]
        self.lims = np.array([[0.0, 1.0], [100.0, 100.0]])
        # tile size
        self.tile_size = (self.lims[1] - self.lims[0]) / n_tiles_per_dim
        # offsets using scrambled Sobol'
        sobol = qmc.Sobol(d=2, scramble=True, seed=12345)
        self.offsets = sobol.random(n_tilings)
        self.total_tiles = n_tilings * (n_tiles_per_dim + 1) ** 2  # with out-of-bound sentinel

    def get_features(self, rem, item):
        indices = []
        x = np.array([rem, item])
        for t in range(self.n_tilings):
            offset = self.offsets[t] * self.tile_size
            shifted = x - offset
            tiles = np.floor(shifted / self.tile_size).astype(int)
            # clip to [0, n_tiles_per_dim]
            tiles = np.clip(tiles, 0, self.n_tiles_per_dim)
            idx = t * (self.n_tiles_per_dim + 1) ** 2 + tiles[0] * (self.n_tiles_per_dim + 1) + tiles[1]
            indices.append(idx)
        active = np.zeros(self.total_tiles, dtype=np.float64)
        active[indices] = 1.0
        return active


# -------- state and agent --------
class Agent:
    def __init__(self):
        self.tc = TileCoder(n_tilings=8, n_tiles_per_dim=8)
        self.weights = np.zeros(self.tc.total_tiles)
        self.alpha = 0.05 / self.tc.n_tilings  # step size
        self.gamma = 1.0  # episodic but continue after terminals? We use TD(0) per step.

    def value(self, rem, item):
        phi = self.tc.get_features(rem, item)
        return np.dot(self.weights, phi)

    # TD update with reward = - (change in number of bins used so far)
    def update(self, rem_before, item, rem_after, delta_bins):
        # delta_bins: 1 if new bin opened, 0 else
        reward = -delta_bins
        phi = self.tc.get_features(rem_before, item)
        v_next = self.value(rem_after, 0.0) if rem_after >= 0 else 0.0  # terminal state after placement
        v_current = np.dot(self.weights, phi)
        td_error = reward + self.gamma * v_next - v_current
        self.weights += self.alpha * td_error * phi


# -------- global agent instantiated once --------
agent = Agent()
prev_num_bins = 0  # track number of bins used so far


def priority(item, bins):
    global prev_num_bins
    n_bins = len(bins)
    # current total bins used is number of bins with capacity < 100
    current_bins_used = np.sum(bins < 100)

    # if first call, initialize prev_num_bins
    if not hasattr(priority, "first_call"):
        priority.first_call = False
        prev_num_bins = current_bins_used

    # Compute scores: we want to maximize value, so we return value of state after placement.
    # The state after placement has remaining = bins[i] - item.
    scores = np.empty(n_bins)
    for i in range(n_bins):
        rem_after = bins[i] - item
        # if bin is currently unused (capacity 100) it's a "new" bin if we place there.
        # But the rule is: we open new bin if we place into a bin that was previously unused.
        # In our state tracking, bins[i]==100 means unused.
        # However, we compute value of the resulting bin state.
        # We add a small penalty for opening new bins to influence choice.
        v = agent.value(rem_after, 0.0)  # next "item" doesn't matter, set 0
        # extra penalty for opening a new bin (bins[i] == 100) to discourage new bin usage
        penalty = 0.0
        if bins[i] == 100:
            penalty = -0.05  # small negative
        scores[i] = v + penalty

    # Tie-breaking: highest score, first occurrence.
    # We'll simulate the decision: find best index
    best_idx = int(np.argmax(scores))

    # After decision, we need to update value function with the actual reward.
    # But we only know the exact outcome after the harness places the item.
    # However, the harness decides based on our returned scores.
    # We can compute the reward from our perspective:
    # delta_bins = 1 if we placed in an unused bin, else 0.
    # Immediately apply TD update to learn from this step.
    rem_before = bins[best_idx]
    rem_after = rem_before - item
    delta_bins = 1 if rem_before == 100 else 0
    agent.update(rem_before, item, rem_after, delta_bins)

    # Update prev_num_bins (not strictly needed further)
    prev_num_bins = current_bins_used + delta_bins

    return scores
