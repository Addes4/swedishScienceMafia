import numpy as np
from scipy.stats import gamma

class BayesianArrivalModel:
    def __init__(self, prior_alpha=1.0, prior_beta=1.0):
        # Prior is Gamma(alpha, beta) where mean = alpha/beta
        # This models the rate of large items (size > 50, say) per timestep
        self.alpha = prior_alpha
        self.beta = prior_beta
        self.total_steps = 0
        self.large_count = 0
        self.large_threshold = 60  # items above this size are "large"
        
    def update(self, item):
        self.total_steps += 1
        if item > self.large_threshold:
            self.large_count += 1
        # Update posterior hyperparameters
        # For Gamma-Poisson conjugate pair: posterior is Gamma(alpha + count, beta + time)
        self.alpha = 1.0 + self.large_count
        self.beta = 1.0 + self.total_steps
        
    def prob_large_soon(self, remaining_capacity, horizon=50):
        """Probability that at least one large item (size > remaining_capacity) arrives in `horizon` steps."""
        if remaining_capacity >= 100:
            return 0.0
        
        # Mean rate of large items per step = alpha/beta
        lambda_rate = self.alpha / self.beta
        
        # Probability that an item is both large AND has size > remaining_capacity
        # If remaining_capacity <= large_threshold, then ANY large item will be > remaining_capacity
        # If remaining_capacity > large_threshold, then we need a very large item
        if remaining_capacity <= self.large_threshold:
            # All large items (size > large_threshold) will exceed remaining capacity
            prob_exceed = lambda_rate
        else:
            # Only items with size > remaining_capacity matter
            # We estimate this fraction from the Gamma distribution of sizes
            # Approximate: size distribution is Weibull-shaped, mean ~40
            # We estimate P(size > remaining_capacity) using a simple exponential-like tail approximation
            # Based on typical Weibull with shape ~1.5-2, the tail decays roughly like exp(-x/scale)
            scale_estimate = 40.0 / 0.887  # Approximate Gamma(1.5) mean adjustment
            prob_exceed = lambda_rate * np.exp(-(remaining_capacity - self.large_threshold) / scale_estimate)
        
        # Poisson probability of at least 1 arrival in `horizon` steps
        expected_count = prob_exceed * horizon
        prob_one_or_more = 1.0 - np.exp(-expected_count)
        return min(prob_one_or_more, 1.0)

# Global instance of the model
_model = BayesianArrivalModel()

def priority(item, bins):
    global _model
    
    # Update the Bayesian model with the current item
    _model.update(item)
    
    # Compute priorities
    scores = np.zeros_like(bins, dtype=np.float64)
    
    for i, capacity in enumerate(bins):
        if capacity < item:
            # Shouldn't happen as bins only includes fits, but be safe
            scores[i] = -1e9
            continue
        
        gap = capacity - item
        # Risk penalty: probability that we'll need this space for a large item soon
        risk_score = _model.prob_large_soon(capacity, horizon=30)
        
        # We want to minimize gap (best fit) but also penalize leaving space that could be "risky"
        # Higher score is better, so negative gap minus penalty
        scores[i] = -gap - 20.0 * risk_score
    
    return scores
