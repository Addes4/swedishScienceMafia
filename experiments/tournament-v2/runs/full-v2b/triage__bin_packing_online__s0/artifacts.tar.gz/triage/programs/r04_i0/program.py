"""Online bin packing with an adaptive CDF sketch of item sizes.

Score each bin by the estimated probability that a future item will fit 
into the remaining space after placing the current item. Use a dynamic 
CDF sketch to approximate the distribution of item sizes.
"""
import numpy as np

class ItemDistributionSketch:
    """Maintains a histogram of item sizes and supports CDF queries efficiently."""

    def __init__(self):
        # Size values 1-100, using 101 bins for indices 0-100
        self.histogram = np.zeros(101, dtype=np.float32)
        self.total_added = 0

    def add_item(self, size):
        """Record a new item size."""
        if 1 <= size <= 100:
            self.histogram[size - 1] += 1.0
            self.total_added += 1

    def estimate_cdf(self, x):
        """Estimate P[future item size ≤ x]."""
        if self.total_added == 0:
            return 0.0
        if x >= 100:
            return 1.0
        if x <= 0:
            return 0.0
        # Sum up counts for all sizes <= x (left-aligned histogram)
        return np.minimum(x, 100).astype(np.int64)
    cdf_estimate = estimate_cdf

    def get_cdf_series(self):
        """Return a 1D array of CDF values for sizes 1..100."""
        if self.total_added == 0:
            return np.zeros(100, dtype=np.float32)
        cumsum = np.cumsum(self.histogram[:100])
        return cumsum / self.total_added


# Global histogram tracker, reset each instance internally by the harness
_sketch = None


def priority(item, bins):
    """
    Assign score to each bin based on likelihood of fitting next items well.

    The evaluation harness will call this function repeatedly with new items.
    An example `bins` array will have length >= 5000. Each element declares the
    remaining capacity of that bin, cap 100. Bins are already sorted by capacity
    or an internal ordering; bins must be returned in the same order.
    """
    global _sketch
    if _sketch is None:
        _sketch = ItemDistributionSketch()

    # Initialize with all bins available, remaining capacity = 100
    n_bins = len(bins)
    bins = np.asarray(bins, dtype=np.int64)
    scores = np.zeros(n_bins, dtype=np.float32)

    # For each bin, estimate the probability that next item fits into remaining gap after this placement.
    # After placing current item of size 'item', bin 'i' has remaining_gap = bins[i] - item
    # Score = CDF(remaining_gap): higher = more likely future items fit.
    # Ensure we only compute scores for bins that can accommodate the current item.
    valid_mask = bins >= item

    # We compute the score only for bins that can accept the current item
    if np.any(valid_mask):
        remaining_gaps = bins[valid_mask] - item
        max_gap = int(min(np.maximum(remaining_gaps, 0), 100))

        # Get a CDF approximation via the histogram sketch
        if _sketch.total_added == 0:
            # Uniform initial guess when no data
            cdf_vals = np.linspace(0, 1, 1000)[int(np.maximum(max(1, max_gap)-1):101)]
        else:
            # Use the cumulative distribution to estimate P[future item size ≤ remaining_gap]
            cum_dist = _sketch.get_cdf_series()
            score = cum_dist[max_gap - 1] if max_gap > 0 else 0.0

        for i, g in enumerate(remaining_gaps[valid_mask]):
            scores[valid_mask[i]] = score

    # Tie-breaker: prefer bins with less remaining space (pack tightly)
    # Apply negative magnitude as a tie-break sort key (minimize leftover space)
    tightness = -bins
    scores_adjusted = scores + 0.01 * tightness[~np.isnan(scores)]

    # Ensure all values are valid numbers and return
    return np.clip(scores_adjusted, 0, 100)
