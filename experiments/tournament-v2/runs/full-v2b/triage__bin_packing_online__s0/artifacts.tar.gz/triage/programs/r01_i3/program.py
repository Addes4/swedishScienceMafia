# EVOLVE-BLOCK-START
"""Online bin packing via capacity-grouped multiplicative weights.

Bins are bucketed by remaining capacity.  Each bucket gets a weight that is
updated online: after each placement we look at how much capacity was wasted
in the chosen bin and reward/penalise the bucket accordingly.  A bin's score
combines this learned bucket weight with the classic best-fit tightness term,
so the policy starts near best-fit and gradually adapts.
"""
import numpy as np

# Number of capacity buckets (0-9, 10-19, ..., 90-100).
N_BUCKETS = 11
# Learning rate for the multiplicative-weights update.
ETA = 0.02
# Blend between learned bucket weight and best-fit tightness.
ALPHA = 0.7


def _bucket(bins):
    """Map remaining capacities to bucket indices 0..N_BUCKETS-1."""
    idx = bins // 10
    # capacity 100 -> bucket 10; capacities 90..99 -> bucket 9, etc.
    return np.clip(idx, 0, N_BUCKETS - 1)


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    state = priority.state

    bk = _bucket(bins)

    # Best-fit component: prefer the bin that will be left tightest.
    tightness = -(bins - item)

    # Learned bucket weights (start uniform at 1.0).
    weights = state["weights"]
    learned = weights[bk]

    score = ALPHA * learned + (1.0 - ALPHA) * tightness

    # Record the decision so the next call can update the chosen bucket.
    # The harness picks the argmax; we approximate by picking it ourselves,
    # which matches the harness rule (highest score, first on ties).
    chosen = int(np.argmax(score))
    state["last_bucket"] = int(bk[chosen])
    state["last_item"] = int(item)
    state["last_remain"] = int(bins[chosen])

    return score


def _init_state():
    return {
        "weights": np.ones(N_BUCKETS, dtype=np.float64),
        "last_bucket": -1,
        "last_item": 0,
        "last_remain": 100,
    }


priority.state = _init_state()


# We need a hook that runs after each placement to update the weights.
# The harness only calls `priority`, so the update for the previous placement
# is performed lazily at the start of the next `priority` call.
_orig_priority = priority


def priority(item, bins):  # noqa: F811
    state = priority.state

    # --- lazy update from the previous placement -------------------------
    lb = state["last_bucket"]
    if lb >= 0:
        # waste = leftover capacity in the chosen bin after the previous item,
        # relative to the bin's full capacity.  Smaller waste = better.
        prev_item = state["last_item"]
        prev_remain = state["last_remain"]
        waste = (prev_remain - prev_item) / 100.0
        # Reward ranges roughly in [-1, 0]: 0 waste -> best reward.
        reward = -waste
        # Multiplicative-weights update.
        state["weights"][lb] *= np.exp(ETA * reward)
        # Renormalise to avoid drift.
        w = state["weights"]
        w /= w.sum()
        state["weights"] = w * N_BUCKETS

    # --- score the current candidate bins --------------------------------
    bk = _bucket(bins)
    tightness = -(bins - item)
    learned = state["weights"][bk]
    score = ALPHA * learned + (1.0 - ALPHA) * tightness

    chosen = int(np.argmax(score))
    state["last_bucket"] = int(bk[chosen])
    state["last_item"] = int(item)
    state["last_remain"] = int(bins[chosen])

    return score


priority.state = _init_state()


# Reset helper so the harness can start a fresh instance if it wants.
def reset():
    priority.state = _init_state()


# EVOLVE-BLOCK-END
