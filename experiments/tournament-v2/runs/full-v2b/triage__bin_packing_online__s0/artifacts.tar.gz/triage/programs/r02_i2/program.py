# EVOLVE-BLOCK-START
"""Harmonic-inspired bin packing with dynamic repurposing of bins.

Rounds items to the nearest harmonic class from a fixed set {100/k for k=2,3,...,N}.
Maintains separate bins for each class. If a class has no open bin, takes an empty bin.
Periodically repurposes the most-accumulated class's empty bins to under-utilized classes.
"""
import numpy as np

# Fixed set of size classes (ceil to these values)
N = 7  # classes for k=2..N
HARMONIC_SIZES = np.array([100 / k for k in range(2, N + 1)], dtype=np.float64)
HARMONIC_SIZES.sort()  # smallest first
K_VALUES = [k for k in range(2, N + 1)]
K_VALUES.sort(key=lambda k: 100 / k)  # sorted by size ascending, same order as HARMONIC_SIZES

# Remaining capacities for each class (per bin that is designated for that class)
# We'll store them as lists of remaining capacities, one per class.
class_bins = {k: [] for k in K_VALUES}

# Count total items, for periodic repurposing
item_count = 0
REPURPOSE_INTERVAL = 100  # check repurposing every N items

def find_class(item):
    """Return the class k (2..N) whose size ceil is >= item, smallest such class."""
    for i, sz in enumerate(HARMONIC_SIZES):
        if item <= sz:
            return K_VALUES[i]
    return None  # item > 100/k for all k? actually 100/2=50, but items up to 100 possible.

# Actually, items can be up to 100, so we need classes that cover up to 100.
# 100/2 = 50, so items >50 won't fit any. We'll add a class k=1 (size=100) if needed.
if 100 not in HARMONIC_SIZES:
    HARMONIC_SIZES = np.append(HARMONIC_SIZES, 100.0)
    K_VALUES.append(1)
    class_bins[1] = []

def _repurpose():
    """Move empty bins from the class with the most empty bins to classes with none."""
    # Find class with most empty bins (capacity remaining == 100) that isn't the smallest?
    empties = {}
    for k in K_VALUES:
        empties[k] = sum(1 for cap in class_bins[k] if cap >= 100)
    if not empties:
        return
    # Find a class with zero empty bins and currently non-empty demand (i.e., has some bins)
    candidates_to_fill = []
    for k in K_VALUES:
        if empties[k] == 0 and len(class_bins[k]) > 0:
            candidates_to_fill.append(k)
    if not candidates_to_fill:
        return
    # Get the class with maximal empties (argmax empties)
    donor_class = max(empties, key=empties.get)
    if empties[donor_class] <= 1:  # keep at least one empty per class if possible
        return
    # Move one empty bin from donor_class to each receiver_class that has no empties
    for receiver in candidates_to_fill:
        if empties[donor_class] <= 1:
            break
        # Find an empty bin in donor_class
        for i, cap in enumerate(class_bins[donor_class]):
            if cap >= 100:
                # remove from donor
                del class_bins[donor_class][i]
                # add to receiver (as empty, still capacity 100)
                class_bins[receiver].append(100)
                empties[donor_class] -= 1
                break
    # Sort each class's bins? Not needed but maintain descending order for best-fit within class.
    for k in K_VALUES:
        class_bins[k].sort(reverse=True)


def priority(item, bins):
    """Return score array for each bin; highest score gets the item."""
    global item_count
    item_count += 1
    if item_count % REPURPOSE_INTERVAL == 0:
        _repurpose()

    # Determine target class
    target_k = None
    for i, sz in enumerate(HARMONIC_SIZES):
        if item <= sz:
            target_k = K_VALUES[i]
            break

    # If no harmonic class (should not happen), fallback to best fit
    if target_k is None:
        return -(bins - item)

    # Known bins for this class
    my_bins = class_bins[target_k]

    # If we have no bins for this class or none can fit the item, we need a new bin.
    # But we can also use an empty bin from a different class as a new bin.
    # We'll check: is there any bin with capacity >= item?
    my_bins_feasible = [cap for cap in my_bins if cap >= item]

    if not my_bins_feasible:
        # need to open a new bin. Search for an empty bin (capacity 100) in any class.
        # We'll prioritize using an empty bin from the same class if exists (but it doesn't because
        # none fit the item, meaning no empty bin?). Actually empty bins always have capacity 100.
        # So we need to find any empty bin across all classes, or use the global bins array.
        # The bins array has remaining capacity for *all* bins (including ones already assigned to classes).
        # But our internal class_bins may not track every bin.
        # Since we must assign the item to one of the bins in the `bins` array, we'll look for
        # the first bin in `bins` that is empty (cap==100) and fits.
        # But we should also try to find an empty bin from another class and "move" it to our class.
        # The repurposing logic can handle later, but we can just assign to the bin index.
        # We'll return a score that prefers empty bins (cap==100) that are currently in my class if any,
        # else any empty bin. But we don't know which bins are in which class from `bins` alone.
        # We'll rely on the repurposing to keep balance; for now, just use best-fit among bins with cap==100.
        # Actually, we can assign high score to the first bin that is empty (cap==100) to mimic opening new.
        # But we must return a score array.
        scores = np.zeros_like(bins, dtype=np.float64)
        # If there is any bin with cap >= item, pick the one that fits tightest (best fit) among all.
        # but we want to open a new bin, meaning use an empty one. However, if no bin fits, item is rejected.
        fitting = bins >= item
        if not np.any(fitting):
            # cannot place item, shouldn't happen
            return scores  # all zeros, item not placed (harness will error but ok)
        # prefer empty bins (cap==100) then tightest fit
        # Score: +100 for empty, then -(capacity - item) as usual.
        # Among fitting bins:
        scores[fitting] = - (bins[fitting] - item)
        # but we want to prioritize empty bins. So give bonus to bins with cap==100.
        scores[bins == 100] += 100.0  # large constant to ensure empty bins win
        return scores

    # We have feasible bins in my_bins_feasible.
    # Among them, pick the one with tightest fit (minimum remaining capacity after placement).
    # In case of a tie, use the first such bin.
    remaining_after = np.array(my_bins_feasible) - item
    # find index of minimum positive remaining (tightest)
    best_local = np.argmin(remaining_after)
    best_cap = my_bins_feasible[best_local]

    # Now we need to map this chosen capacity to an index in the global `bins` array.
    # Since multiple bins can have same capacity, we must identify which bin it is.
    # We'll return a score vector such that the chosen bin gets the highest score.
    # Strategy: For bins that have capacity equal to best_cap and fit the item,
    # score them with a value that picks the first such bin.
    # We'll assign score = -1 for bins that are not chosen, and score = 0 for the chosen bin (or tie with first).
    # But we don't know which bin index corresponds to our chosen best_cap.
    # Instead, we'll produce a score based on capacity ranking, and ties will be broken by bin order.
    # So we can just use the same score formula: -(bins - item) for all bins that can fit,
    # but for bins of class target_k we give higher priority than non-class bins? Not needed.
    # Simpler: return score where all bins with capacity == best_cap get score = 0, others get -1.
    # But that might pick an empty bin with same capacity from different class, which is fine.
    # However, we need to make sure we only use bins that are in my class if possible.
    # The problem: we cannot distinguish bins by class in the global `bins` array.
    # So any bin with the same capacity could be chosen. That might steal a bin from another class.
    # To mitigate, we should prefer bins that we know belong to target_k. We can't know directly,
    # but we can assume that bins with capacities that appear in class_bins[target_k] are likely ours.
    # Better approach: We'll maintain a dictionary mapping capacity to a list of bin indices?
    # The harness calls priority with a *copy* of the bins array, indices correspond to fixed bin order.
    # We cannot control which bin index corresponds to which capacity, except by tracking assignments
    # ourselves. But we can track bin indices if we simulate the assignment.
    # Since we don't know which bin index the item actually goes to until after priority returns,
    # we cannot perfectly map. However, we can infer: the harness will assign the item to the bin
    # with highest score. If we return scores that rank bins in the order of our preferred class bins,
    # we can capture that.
    # 
    # New idea: produce a score array that ranks bins by a combination:
    # - bins that are empty get priority only if no non-empty class bin fits? We already handle opening.
    # For existing class bins, we want the tightest fit among them.
    # We'll create an array of scores where each bin gets score = -capacity (or similar) plus class-specific bonus.
    # To guarantee that a bin from our target class is chosen if it fits, we give a huge bonus to bins
    # whose remaining capacity exists in my_bins_feasible. But multiple bins may have same capacity.
    # We'll give bonuses in decreasing order of tightness: bins with capacity exactly equal to our best_cap
    # get the highest bonus, then next best, etc. This way, the harness will pick the first bin (by index)
    # that has that capacity, which is exactly what we want because the first such bin in order will
    # likely be from our class if we maintain class_bins in order? Not guaranteed.
    # 
    # We assume that bins get added sequentially, and we can keep track of which class each bin index
    # belongs to by storing assignments. Let's do that:
    # Maintain a global dict: bin_index -> target class. Start with empty.
    # We'll update it after each placement based on which class we intended.
    # But we don't know which bin index was chosen until after harness places it, but we can deduce it
    # from the bins array before and after? We can't see after. However, we can compute the bin index
    # that the harness will choose given our scores: it's the first index with max score.
    # During priority, we know the bins array and our scores. We can determine the winner index.
    # Then we can update our mapping: assign that index to target_k.
    # This requires that we compute the winner ourselves, and then adjust class_bins accordingly.
    # But we must be careful: the capacity of that bin before placement is known, and we will update it.
    # So we can simulate the harness's choice and update our class_bins lists.

    scores = np.full_like(bins, -1e9, dtype=np.float64)  # default very low
    # Determine which bins are in our target class that fit
    # We'll first mark all bins that can fit the item and belong to target_k (or could be assigned)
    # Actually, we don't yet know which bin index is ours. We'll compute bonuses based on capacity.
    # For bins that fit the item:
    fit_mask = bins >= item
    if not np.any(fit_mask):
        return scores

    # Among fitting bins, we want to prefer bins that have capacity in my_bins_feasible,
    # with tightness order.
    # Create a ordering among fitting bins: score = -(capacity - item) + bonus if capacity in my_bins_feasible?
    # But that may cause a bin from another class with same capacity to be chosen incorrectly.
    # However, if capacities are unique within my_bins_feasible (likely not), we could match exactly.
    # Since many bins may share capacities, we'll use the following strategy:
    # We'll compute the desired remaining capacity after placement for each bin if chosen.
    # We want to pick the bin with the largest (i.e., least negative) value of -(bins - item).
    # But for bins that are in our target class, we add a huge constant (like 1000) so they always
    # outrank non-class bins that fit. This ensures we only place into class bins if any fits.
    # However, we don't know which bins are in our class. So we need to identify them.
    # Solution: maintain a set of bin indices for each class.
    
    # We'll introduce global state:
    # - bin_to_class: dict from int bin_index to target_k
    # - class_to_bins: dict from k to list of bin indices (or just remain capacities)
    # We'll update these after prediction of winner.
    
    # This may be complex with multiple instances: we need to reset state per instance.
    # The harness creates a new instance each call? It says "Each instance has 5,000 items".
    # So between instances, we must reset state. We can detect new instance by seeing if `bins`
    # has all capacities 100 and length 5000? Not reliable. Instead, we'll reset when item_count==1.
    # So detect start of instance: if item_count is reset to 0? We'll keep module-level state and
    # reset when we see bins length > 0 and we have no prior bins? Better: use a flag.
    pass

    # Let's implement a fresh approach combining static harmonic with repurposing but without
    # per-index tracking, accepting some cross-class placing.
    # For the final response, provide a clean harmonic with repurposing but simpler scoring.
