# EVOLVE-BLOCK-START
"""Online bin choice: best fit plus a reservation term.

For every candidate bin we compute a "future value" from a running histogram of
item sizes seen so far:

    future_value(R) = -R * P(next item > R)

where R is the bin's remaining capacity.  A bin with a large remaining capacity
can hold many future items, and the term penalises consuming bins that the
empirical distribution says are still useful, so roomy bins are reserved for
upcoming large items.  This term is added on top of the classic best-fit score
so that tight fits are still strongly preferred.  The histogram is updated once
per arriving item, so the rule adapts to the (fixed) size distribution online.
"""
import numpy as np

# Running histogram of item sizes, index = size (1..100), plus a counter.
_HIST = np.zeros(101, dtype=np.float64)
_N = 0.0


def priority(item, bins):
    """Return a priority for every bin in `bins`; highest score wins (first on ties)."""
    global _HIST, _N

    b = np.asarray(bins, dtype=np.int64)
    leftover = (b - item).astype(np.float64)     # space left if we use this bin

    # Best fit base: prefer the bin left tightest.
    score = -leftover

    # Reservation term, using the empirical distribution of past items.
    if _N >= 50.0:
        total = _N
        hist = _HIST
        # rev[i] = number of past items with size >= i
        rev = np.cumsum(hist[::-1])[::-1]
        sf = np.empty(101, dtype=np.float64)
        sf[0:100] = rev[1:101] / total           # sf[x] = P(size > x)
        sf[100] = 0.0

        R = np.clip(b, 0, 100)
        pgt = sf[R]                              # P(future item > remaining capacity)
        # Penalise using bins that are likely still needed.  The term is
        # non-monotonic in the remaining capacity, so it can override pure
        # best fit when the distribution says a bin is valuable.
        score = score - (b.astype(np.float64) * pgt)

    # Record the current item for future estimates (one-step delay is harmless).
    _HIST[item] += 1.0
    _N += 1.0

    return score
# EVOLVE-BLOCK-END
