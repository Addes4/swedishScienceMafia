import numpy as np

# Global state: call counter to decay mixing weight over time
call_counter = 0

def priority(item, bins):
    global call_counter
    call_counter += 1
    total_items = 5000  # known horizon per instance

    # Mixing weight: start with alpha = 0.5 (equal blend) and decay towards best-fit (alpha=0)
    # alpha decays linearly with call count: early calls favor consolidation, later calls favor best-fit
    alpha = 0.5 * (1 - call_counter / total_items)

    # Best-fit component: prefer bins where item fits tightest (highest score = smallest gap)
    # gap = bins - item; score_best_fit = -gap, so smaller gap -> higher score
    best_fit = -(bins - item)

    # Consolidation bonus: prefer bins that are already heavily loaded (high total load)
    # total load = 100 - bins; higher is better.
    # Normalize to similar scale as best_fit (which ranges approx -99..0)
    consolidation = (100 - bins) / 100.0  # scale to 0..1 range, then amplify to match best fit magnitude
    consolidation = consolidation * 99  # approximate range 0..99

    # Combine: convex combination; higher score means more preferred
    score = alpha * consolidation + (1 - alpha) * best_fit

    return score
