# Research notebook: bin_packing_online

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.961642.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | When the item is small (e.g., ≤20), use a worst-fit rule to leave room for future large items; otherwise use best-fit as before. This switch protects against wa | 0.38 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.933758 |
| 1 | Keep a running estimate of the mean item size from past arrivals, and for items larger than this mean use the current best-fit rule, but for smaller items score | 0.33 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.852195 |
| 4 | Use a best-of-three approach: pick the three tightest-fitting bins according to best-fit, then choose the one with the largest current total filled (100 – remai | 0.32 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 3 | Maintain bin groups by remaining capacity percentiles (e.g., 0–9, 10–19, …, 90–100) and track success counts. For the current item, score bins by a learned weig | 0.26 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 5 | Treat the algorithm as a regression problem: record (item, chosen remaining capacity) pairs, and continuously fit a linear model that predicts ideal remaining c | 0.17 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 2 | Add a small random tie-break jitter (e.g., ±1e-6) to the best-fit scores to break tight clusters differently across instances, reducing pathological cascades wi | 0.17 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.961642 |

Best after round 1: **0.961642** (spent $0.01)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Treat the problem as online bipartite matching with predicted "dual prices." Maintain a shadow price for each unit of remaining capacity, updated online via gra | 0.12 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 2 | Adapt the HARMONIC algorithm for online bin packing: round the arriving item size up to the nearest value in a fixed set {100/k for k=2,3,...,N} and assign the  | 0.12 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.396100 |
| 5 | Use a small lookahead buffer: instead of immediately committing the item, first sample a synthetic "future sequence" by shuffling the empirical distribution of  | 0.08 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 0 | Partition the remaining-capacity range into k equal-width bins (e.g., k=10) and maintain a running count of items placed into each capacity band. Score each bin | -0.06 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 4 | Simulate the bin packing as a one-dimensional "jigsaw": maintain a running average of the sum of an arriving item and its chosen bin's existing load, aiming for | -0.07 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 3 | Track a smoothed histogram of past item sizes (e.g., via Kernel Density Estimation using a few Gaussian kernels). When an item arrives, compute the probability  | -0.10 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 2: **0.961642** (spent $0.03)

## Round 3

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Partition bins into "active" (partially filled) and "empty" sets; within active bins use best-fit, but when an item would fit an active bin with less than 5% sl | 0.03 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.941975 |
| 0 | Score bins by a convex combination of best-fit and a "consolidation bonus" that increases with the current total load (100 – remaining) of the bin, with the mix | -0.02 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961642 |
| 4 | Track the cumulative distribution of item sizes and, for the current item, compute the expected number of future items that will fit perfectly (gap 0) into each | -0.06 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.948288 |
| 2 | For each bin, compute a "future value" score as the negative remaining capacity times the empirical probability (from a running histogram of item sizes) that an | -0.07 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 5 | Treat the problem as online gradient descent on a smoothed cost function: maintain a parameter vector over capacity bands, and score bins by a dot product of bi | -0.07 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 1 | Maintain an exponential moving average of the target "fill level" after placing each item; score each bin by the negative difference between (100 – remaining +  | -0.09 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 3: **0.961642** (spent $0.05)

## Round 4

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Learn a value function V(remaining_capacity, item_size) via temporal-difference learning with linear function approximation over tile-coded features of the stat | 0.06 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 4 | Maintain an ensemble of several simple rules (best-fit, worst-fit, first-fit, etc.) and track their recent performance using an exponential moving average of a  | 0.03 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.854033 |
| 2 | Treat the remaining-capacity bins as a continuous resource and apply the "online primal-dual" framework for the minimization version: maintain a monotonically i | 0.02 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.396100 |
| 5 | Model the problem as a branching process: maintain a running estimate of the "item size generating distribution" as a mixture of a few beta distributions (repar | -0.03 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | no_code |  |
| 0 | Maintain an online estimate of the cumulative distribution function (CDF) of item sizes via quantile sketches (e.g., t-digest). For each bin, score it by the pr | -0.21 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 1 | Use a "harmonic-like" dynamic classification: maintain K (e.g., K=20) active size classes whose boundaries adapt online via k-means clustering of recent items.  | -0.26 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 4: **0.961642** (spent $0.07)

## Round 5

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Implement a bin-age-aware scoring: record the sequential index when each bin received its first item. For bins with identical best-fit gaps, prioritize the bin  | 0.05 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 1 | Maintain an online estimate of the probability density function of item sizes using a kernel density estimator with bounded support. For each bin, compute the e | -0.02 | favourite | Qwen/Qwen3.5-9B:together (swapped) | invalid | 0.000000 |
| 0 | Instead of a single score, output a Pareto-style tuple ranking: primary key is the negative gap (best-fit), secondary key is the absolute deviation of the bin’s | -0.07 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.961642 |
| 3 | Simulate a limited-depth Monte Carlo tree search: upon item arrival, for each candidate bin, roll out a few placements of synthetic future items drawn from the  | -0.11 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 2 | Treat the problem as a resource allocation task with discounting: score each bin by the negative remaining capacity plus a “time-decayed” bonus proportional to  | -0.12 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 5 | Employ a smoothed version of the “online primal-dual” approach: maintain a single global parameter (lagrange multiplier) updated via mirror descent after each p | -0.13 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 5: **0.961642** (spent $0.10)

## Round 6

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 4 | Treat the remaining capacity as a state and learn a Q-value function via online SARSA(lambda) with tile coding: each placement yields a reward of -1 if a new bi | 0.14 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 1 | Maintain a small sliding window of the last W placed items and their chosen bins. For the current item, compute how often each candidate bin would have been the | 0.04 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.909323 |
| 5 | Model the arrival stream as a Poisson process with an unknown rate of large items, and maintain a Bayesian posterior over that rate. Score bins by a risk-adjust | -0.03 | middle | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | invalid | 0.000000 |
| 2 | Score bins by the expected number of future items they can still accommodate, estimated by a running exponential model: for each bin, compute sum_{k=1}^∞ p^k *  | -0.03 | middle | Qwen/Qwen3.5-9B:together (swapped) | invalid | 0.000000 |
| 0 | Use a "gap-aware harmonic" approach: round the item up to the nearest value in a dynamically-maintained set of K ideal capacities that are the most common resid | -0.05 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.876521 |
| 3 | Apply the "First Fit Decreasing" logic online by maintaining bins sorted by their current total load (descending) in a secondary index, and score bins by a conv | -0.11 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 6: **0.961642** (spent $0.12)

## Round 7

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Introduce a reserve budget for large items: track the fraction of items above a threshold (e.g., 80) using an exponential moving average, and dynamically set a  | 0.20 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.961642 |
| 1 | Frame scoring as a combinatorial-cost minimization: maintain a set of active bins with their current loads. For each candidate bin, compute the sum of squared r | 0.13 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.959312 |
| 3 | Simulate a dual-buffer strategy: internally split bins into two virtual zones—a “tight-fill” zone using threshold 90% and a “normal” zone below—reassigning bins | 0.04 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.752334 |
| 4 | Adopt an online-matching perspective with predicted item totals: estimate the total volume of remaining items from a moving average and the known instance lengt | 0.04 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.415202 |
| 5 | Implement a coalitional game-theoretic scoring: for each candidate bin, consider the subset of existing bins (including empty ones) and compute the Shapley-valu | -0.00 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 2 | Use a “relative regret” rule: maintain a smoothed histogram of item sizes, and for each bin compute the probability that a future item drawn from that histogram | -0.01 | long_shot | Qwen/Qwen3.5-9B:together | not_better | 0.958384 |

Best after round 7: **0.961642** (spent $0.14)

