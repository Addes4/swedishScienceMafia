# EVOLVE-BLOCK-START
"""Construction: mixed-radix digit sets + shift/append refinement.
A = { sum_i d_i * B^i : d_i in D_i } for small digit sets D_i and base B.
This collapses A+A (carries / overlapping digit sums) while A-A stays large.
After the digit/base hill-climb we run a shift-append phase: union with a
shifted copy A+t and single-element insertions, accepted by exact scoring."""
import math
import time
import random
import numpy as np


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n == 0:
        return 0, 0
    diffs = (a[:, None] - a[None, :]).ravel()
    sums = (a[:, None] + a[None, :]).ravel()
    nd = np.unique(diffs).size
    ns = np.unique(sums).size
    return nd, ns


def _score_from_counts(nd, ns, n):
    if n < 2 or ns <= 1:
        return -1e9
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _build(digits, base, depth):
    vals = [0]
    for i in range(depth):
        p = base ** i
        newvals = []
        for v in vals:
            for d in digits[i]:
                newvals.append(v + d * p)
        vals = newvals
    return sorted(set(vals))


def solve():
    rng = random.Random(20240607)
    deadline = time.time() + 108

    depth = 3
    base = 8
    digits = [
        [-1, 0, 1],
        [-1, 0, 1],
        [-1, 0, 1],
    ]

    def full_digits(digits, depth):
        d = [list(x) for x in digits[:depth]]
        while len(d) < depth:
            d.append([0])
        return d

    cur_digits = full_digits(digits, depth)
    cur_base = base
    cur_depth = depth

    A = _build(cur_digits, cur_base, cur_depth)
    nd, ns = _counts(A)
    best_A = A
    best_score = _score_from_counts(nd, ns, len(A))
    cur_score = best_score

    cand_digits = [-8, -4, -3, -2, -1, 0, 1, 2, 3, 4, 8]

    while time.time() < deadline - 25:
        nd_ = [list(x) for x in cur_digits]
        nb = cur_base
        ndp = cur_depth
        r = rng.random()

        if r < 0.55 and nd_:
            i = rng.randrange(len(nd_))
            d = nd_[i]
            if d and rng.random() < 0.4:
                d.pop(rng.randrange(len(d)))
            else:
                v = rng.choice(cand_digits)
                if v not in d:
                    d.append(v)
            nd_[i] = sorted(set(d))
        elif r < 0.80:
            nb = max(2, min(40, cur_base + rng.choice([-2, -1, 1, 2])))
        elif r < 0.92:
            ndp = max(1, min(5, cur_depth + rng.choice([-1, 1])))
            while len(nd_) < ndp:
                nd_.append([0])
        else:
            i = rng.randrange(len(nd_))
            if len(nd_[i]) > 1:
                nd_[i] = nd_[i][: max(1, len(nd_[i]) - 1)]

        if not any(nd_):
            continue
        try:
            newA = _build(nd_, nb, ndp)
        except Exception:
            continue
        if len(newA) < 2:
            continue
        nd2, ns2 = _counts(newA)
        s = _score_from_counts(nd2, ns2, len(newA))
        if s >= cur_score:
            cur_digits = nd_
            cur_base = nb
            cur_depth = ndp
            cur_score = s
            if s > best_score:
                best_score = s
                best_A = newA

    res = sorted(set(best_A))

    # Phase 1: shift-append refinement. Try A -> A ∪ (A + t) for small t.
    cur_nd, cur_ns = _counts(res)
    cur_s = _score_from_counts(cur_nd, cur_ns, len(res))
    smax = max(abs(x) for x in res) if res else 1
    shifts = set()
    for t in (-8, -7, -6, -5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 6, 7, 8):
        shifts.add(t)
    # also shifts equal to half the span and to some element gaps
    if res:
        span = res[-1] - res[0]
        for k in (2, 3, 4, 5):
            if span > 0:
                shifts.add(max(1, span // k))
                shifts.add(-max(1, span // k))

    improved = True
    while improved and time.time() < deadline - 6:
        improved = False
        for t in sorted(shifts):
            cand = sorted(set(res + [x + t for x in res]))
            if len(cand) > 4000 or len(cand) <= len(res):
                continue
            if max(abs(x) for x in cand) > 10**15:
                continue
            nd2, ns2 = _counts(cand)
            s = _score_from_counts(nd2, ns2, len(cand))
            if s > cur_s:
                res = cand
                cur_s = s
                cur_nd, cur_ns = nd2, ns2
                improved = True
                break

    # Phase 2: greedy element insertion from difference/sum set candidates.
    best_res = res
    best_res_s = cur_s
    improved = True
    while improved and time.time() < deadline - 2:
        improved = False
        a = np.asarray(res, dtype=np.int64)
        cand = set()
        # candidates: sums/differences of a few random pairs, plus midpoints
        for _ in range(30):
            i = rng.randrange(len(res))
            j = rng.randrange(len(res))
            cand.add(int(a[i] + a[j]))
            cand.add(int(a[i] - a[j]))
            cand.add(int((a[i] + a[j]) // 2))
        for x in list(cand):
            if x in res:
                continue
            c = sorted(set(res + [x]))
            if len(c) > 4000 or max(abs(v) for v in c) > 10**15:
                continue
            nd2, ns2 = _counts(c)
            s = _score_from_counts(nd2, ns2, len(c))
            if s > cur_s:
                res = c
                cur_s = s
                improved = True
                break
        if cur_s > best_res_s:
            best_res = res
            best_res_s = cur_s

    res = best_res

    # Phase 3: deletion polish.
    improved = True
    cur_nd, cur_ns = _counts(res)
    cur_s = _score_from_counts(cur_nd, cur_ns, len(res))
    while improved and time.time() < deadline:
        improved = False
        order = list(range(len(res)))
        rng.shuffle(order)
        for i in order:
            cand = res[:i] + res[i + 1:]
            if len(cand) < 2:
                continue
            nd2, ns2 = _counts(cand)
            s = _score_from_counts(nd2, ns2, len(cand))
            if s >= cur_s:
                res = cand
                cur_s = s
                improved = True
                break

    return res
# EVOLVE-BLOCK-END
