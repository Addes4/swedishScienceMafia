# EVOLVE-BLOCK-START
"""Mixed-radix digit construction with direct scored search."""
import math
import time
import itertools
import random
import numpy as np

RNG = random.Random(12345)


def _counts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    return diffs, sums


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return -1.0
    diffs, sums = _counts(a)
    if sums < 2 or diffs < 2:
        return -1.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _counts_from_levels(levels, B):
    """Difference/sum counts of mixed-radix set without building it (log only).

    For a set built as sum d_i * B^i, the difference set is the sumset over
    levels of scaled difference sets, and similarly for sums (with the
    level-0 sign convention). We count exactly using the factor structure:
    |D-D| of the whole = product over levels because of the large base B
    (no carrying collisions). But we verify with real counting anyway.
    """
    pass


def _digit_stats(D):
    D = list(D)
    dd = set()
    ss = set()
    for x in D:
        for y in D:
            dd.add(x - y)
            ss.add(x + y)
    return len(dd), len(ss)


def _search_digit_sets(deadline):
    cands = []
    seen = set()

    def consider(D, target):
        key = tuple(sorted(D))
        if key in seen:
            return
        seen.add(key)
        ndd, nss = _digit_stats(D)
        if nss < 2 or ndd < 2:
            return
        ldd = math.log(ndd)
        lss = math.log(nss)
        cands.append((ldd / lss, ldd, lss, len(key), list(key)))

    universe = list(range(13))
    for sz in range(2, 6):
        if time.time() > deadline:
            break
        for comb in itertools.combinations(universe, sz):
            consider(comb, cands)
    cands.sort(reverse=True, key=lambda t: t[0])
    beam = [t[4] for t in cands[:300]]
    for sz in range(6, 10):
        if time.time() > deadline:
            break
        for D in beam:
            mx = max(D)
            for v in range(0, mx + 5):
                if v in D:
                    continue
                consider(D + [v], cands)
        cands.sort(reverse=True, key=lambda t: t[0])
        beam = [t[4] for t in cands[:300]]
        if not beam:
            break

    best_ldd = []

    def raw_consider(D):
        key = tuple(sorted(D))
        ndd, nss = _digit_stats(D)
        if nss < 2 or ndd < 2:
            return
        ldd = math.log(ndd)
        lss = math.log(nss)
        best_ldd.append((ldd - 0.45 * lss, ldd, lss, len(key), list(key)))

    uni2 = list(range(16))
    for sz in range(2, 6):
        if time.time() > deadline:
            break
        for comb in itertools.combinations(uni2, sz):
            raw_consider(comb)
    best_ldd.sort(reverse=True, key=lambda t: t[0])
    beam2 = [t[4] for t in best_ldd[:200]]
    for sz in range(6, 11):
        if time.time() > deadline:
            break
        for D in beam2:
            mx = max(D)
            for v in range(0, mx + 4):
                if v in D:
                    continue
                raw_consider(D + [v])
        best_ldd.sort(reverse=True, key=lambda t: t[0])
        nb = []
        seenk = set()
        for t in best_ldd:
            k = tuple(t[4])
            if k in seenk:
                continue
            seenk.add(k)
            nb.append(t)
            if len(nb) >= 200:
                break
        beam2 = [t[4] for t in nb]
        if not beam2:
            break
    for (_, ldd, lss, sz, D) in best_ldd[:400]:
        cands.append((ldd / lss, ldd, lss, sz, D))

    dd = {}
    for c in cands:
        k = tuple(c[4])
        if k not in dd or c[1] / max(c[2], 1e-9) > dd[k][1] / max(dd[k][2], 1e-9):
            dd[k] = c
    out = list(dd.values())
    out.sort(reverse=True, key=lambda t: t[0])
    return out


def _build_mixed(levels, B):
    A = [0]
    pw = 1
    for D in levels:
        newA = []
        for a in A:
            for d in D:
                newA.append(a + d * pw)
        A = newA
        pw *= B
    return np.array(sorted(set(A)), dtype=np.int64)


def _span(D):
    return max(D) - min(D)


def solve():
    deadline = time.time() + 108
    best = None
    best_score = -1.0

    dig = _search_digit_sets(min(deadline, time.time() + 40))
    if not dig:
        return [0, 1]

    sets = [(ldd / lss, ldd, lss, len(D), D) for (r, ldd, lss, sz, D) in dig]
    pool = list(sets[:400])
    for s in sorted(sets, key=lambda t: t[1], reverse=True)[:150]:
        pool.append(s)
    for s in sorted(sets, key=lambda t: t[1] - 0.45 * t[2], reverse=True)[:150]:
        pool.append(s)
    pd = {}
    for s in pool:
        k = tuple(s[4])
        pd[k] = s
    pool = list(pd.values())
    pool_by_ratio = sorted(pool, key=lambda t: t[0], reverse=True)

    def eval_levels(levels):
        if not levels:
            return None, -1.0
        span = max(_span(D) for D in levels)
        B = max(2 * span + 1, 2)
        lv = list(levels)
        while lv:
            A = _build_mixed(lv, B)
            if A.size < 2:
                lv.pop()
                continue
            if A.size <= 4000 and np.max(np.abs(A)) <= 10**15:
                return A, _score(A)
            lv.pop()
            if lv:
                span = max(_span(D) for D in lv)
                B = max(2 * span + 1, 2)
        return None, -1.0

    # Beam search over level sequences using analytic cumulative ratio.
    beam_states = []
    for (r, ldd, lss, sz, D) in sets[:40]:
        beam_states.append((ldd, lss, sz, [D]))
    beam_states.sort(key=lambda s: s[0] / s[1], reverse=True)

    def cum_ratio(st):
        return st[0] / st[1]

    B_cand = pool_by_ratio
    for step in range(30):
        if time.time() > deadline:
            break
        newstates = []
        for (cldd, clss, size, levels) in beam_states:
            added = 0
            for (r, ldd, lss, sz, D) in B_cand:
                if size * sz > 4000:
                    continue
                newstates.append((cldd + ldd, clss + lss, size * sz, levels + [D]))
                added += 1
                if added >= 60:
                    break
        if not newstates:
            break
        newstates.sort(key=cum_ratio, reverse=True)
        beam_states = newstates[:200]

    cand_level_seqs = [st[3] for st in beam_states[:300]]

    # Direct scored search: random perturbations of the best level sequences,
    # scored exactly with numpy. This finds real interactions between levels.
    base_seq = cand_level_seqs[0] if cand_level_seqs else [list(sets[0][4])]

    # Evaluate the analytic top sequences first.
    for levels in cand_level_seqs[:250]:
        if time.time() > deadline:
            break
        A, sc = eval_levels(levels)
        if A is not None and sc > best_score:
            best_score = sc
            best = A.tolist()

    # Randomized local search over digit sets per level, scored directly.
    def score_seq(levels):
        A, sc = eval_levels(levels)
        return sc, A

    cur_levels = [list(D) for D in base_seq]
    cur_score, _ = score_seq(cur_levels)
    if cur_score > best_score:
        A, _ = eval_levels(cur_levels)
        if A is not None:
            best_score = cur_score
            best = A.tolist()

    it = 0
    while time.time() < deadline:
        it += 1
        if it % 50 == 0 and time.time() > deadline:
            break
        cand = [list(D) for D in cur_levels]
        # mutate one level
        li = RNG.randrange(len(cand))
        D = cand[li]
        op = RNG.randrange(3)
        if op == 0 and len(D) > 2:
            D.pop(RNG.randrange(len(D)))
        elif op == 1:
            mx = max(D) if D else 1
            v = RNG.randrange(0, mx + 4)
            if v not in D:
                D.append(v)
        else:
            idx = RNG.randrange(len(D))
            mx = max(D) if D else 1
            D[idx] = RNG.randrange(0, mx + 4)
            D = sorted(set(D))
            cand[li] = D
        # also occasionally add a new level
        if RNG.random() < 0.1 and len(cand) < 8:
            cand.append(list(RNG.choice(pool)[4]))
        if RNG.random() < 0.1 and len(cand) > 1:
            cand.pop(RNG.randrange(len(cand)))
        cand = [sorted(set(D)) for D in cand if len(set(D)) >= 2]
        if not cand:
            continue
        sc, A = score_seq(cand)
        if sc > cur_score:
            cur_score = sc
            cur_levels = [list(D) for D in cand]
            if sc > best_score:
                best_score = sc
                best = A.tolist()
        # restart occasionally
        if it % 4000 == 0:
            cur_levels = [list(RNG.choice(pool)[4]) for _ in range(RNG.randint(1, 4))]
            cur_score, _ = score_seq(cur_levels)

    if best is None:
        A, sc = eval_levels([list(sets[0][4])])
        if A is not None:
            best = A.tolist()
        else:
            best = [0, 1]

    # Final boundary refinement.
    a = sorted(set(int(x) for x in best))
    improved = True
    rounds = 0
    while improved and rounds < 30 and time.time() < deadline:
        improved = False
        rounds += 1
        base_arr = np.array(a, dtype=np.int64)
        cand_adds = []
        lo, hi = a[0], a[-1]
        cand_adds.append(hi + 1)
        cand_adds.append(lo - 1)
        diffs = np.diff(base_arr)
        if diffs.size:
            gi = int(np.argmax(diffs))
            cand_adds.append(int(a[gi]) + int(diffs[gi]) // 2)
        for c in cand_adds:
            if len(a) >= 4000:
                break
            trial = np.array(sorted(set(a + [c])), dtype=np.int64)
            sc = _score(trial)
            if sc > best_score:
                best_score = sc
                a = trial.tolist()
                improved = True
                break
        if improved:
            continue
        for idx in (0, len(a) - 1):
            if len(a) <= 2:
                break
            trial_list = a[:idx] + a[idx + 1:]
            sc = _score(np.array(trial_list, dtype=np.int64))
            if sc > best_score:
                best_score = sc
                a = trial_list
                improved = True
                break

    return sorted(set(int(x) for x in a))
# EVOLVE-BLOCK-END
