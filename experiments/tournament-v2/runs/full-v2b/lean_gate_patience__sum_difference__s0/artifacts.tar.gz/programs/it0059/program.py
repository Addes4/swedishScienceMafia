# EVOLVE-BLOCK-START
"""Union-of-translates construction A = C + T.

C is a compact integer interval (rich within-cluster differences), T is a small
integer "translate" set chosen by local search so that the sum-set stays small
(cross-sums C+C+T+T collapse) while the difference-set stays rich (cross-
differences avoid collisions).  All counts are computed exactly with numpy
bitset-free set operations; a time budget guards the 120s limit and a final
greedy single-element polish squeezes the ratio further.
"""
import math
import time
import random


def _counts(A):
    """Exact |A+A| and |A-A| using Python sets (robust, moderate n)."""
    sa = set()
    pa = set()
    L = A
    n = len(L)
    for i in range(n):
        xi = L[i]
        sa.add(xi + xi)
        for j in range(i + 1, n):
            sa.add(xi + L[j])
    for i in range(n):
        xi = L[i]
        for j in range(n):
            pa.add(xi - L[j])
    return len(sa), len(pa)


def _score_counts(s, d, n):
    if n < 2 or s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _score(A):
    A = sorted(set(int(x) for x in A))
    if len(A) < 2:
        return 0.0
    s, d = _counts(A)
    return _score_counts(s, d, len(A))


def _build(C, T):
    """A = C + T (sumset), sorted distinct."""
    S = set()
    for c in C:
        for t in T:
            S.add(c + t)
    return sorted(S)


def _greedy_polish(A, deadline, max_steps=40):
    """Add one element at a time maximising the exact score."""
    A = sorted(set(A))
    sc = _score(A)

    def try_add(x):
        cand = sorted(set(A + [x]))
        return _score(cand), cand

    steps = 0
    while time.time() < deadline and steps < max_steps:
        steps += 1
        lo, hi = A[0], A[-1]
        span = hi - lo
        cand = set()
        for a in A:
            for dlt in (1, -1, 2, -2, span + 1, -(span + 1)):
                cand.add(a + dlt)
        cand.add(hi + 1)
        cand.add(hi + 2)
        cand.add(lo - 1)
        cand.add(lo - 2)
        cand = [x for x in cand if x not in A]
        best = None
        bestsc = sc
        for x in cand:
            s2, c2 = try_add(x)
            if s2 > bestsc:
                bestsc = s2
                best = c2
        if best is None:
            break
        A = best
        sc = bestsc
    return A, sc


def solve():
    random.seed(12345)
    deadline = time.time() + 108.0

    best_A = None
    best_sc = -1.0

    # cluster sizes to try
    cluster_sizes = [4, 5, 6, 8, 10, 12, 16]

    # candidate seeds for T (translate offsets), hand-picked + random
    t_seeds = [
        [0, 1],
        [0, 2],
        [0, 3],
        [0, 1, 3],
        [0, 1, 4],
        [0, 2, 5],
        [0, 1, 3, 7],
        [0, 1, 4, 9],
        [0, 2, 6, 12],
        [0, 3, 7, 15],
    ]

    for csize in cluster_sizes:
        if time.time() > deadline:
            break
        C = list(range(csize))  # contiguous cluster

        # try structured T seeds, then random restarts
        trials = list(t_seeds)
        for _ in range(60):
            k = random.randint(2, 5)
            t = sorted(random.sample(range(0, 40), k))
            trials.append(t)

        for Tseed in trials:
            if time.time() > deadline:
                break
            T = sorted(set(int(t) for t in Tseed))
            A = _build(C, T)
            sc = _score(A)

            # hill-climb T offsets
            improved = True
            rounds = 0
            while improved and time.time() < deadline and rounds < 60:
                improved = False
                rounds += 1
                for i in range(len(T)):
                    for delta in (1, -1, 2, -2, 3, -3, 5, -5, 8, -8):
                        T2 = T[:]
                        T2[i] += delta
                        T2 = sorted(set(T2))
                        A2 = _build(C, T2)
                        s2 = _score(A2)
                        if s2 > sc + 1e-12:
                            sc = s2
                            T = T2
                            A = A2
                            improved = True
                            break
                    if improved:
                        break

            # also allow growth of T (add a translate)
            grow_rounds = 0
            while time.time() < deadline and grow_rounds < 6:
                grow_rounds += 1
                lo, hi = T[0], T[-1]
                cands = set()
                for t in T:
                    cands.add(t + 1)
                    cands.add(t - 1)
                cands.add(hi + 1)
                cands.add(hi + 2)
                cands.add(lo - 1)
                cands.add(lo - 2)
                cands = [c for c in cands if c not in T]
                bestg = None
                bestgsc = sc
                for c in cands:
                    T2 = sorted(set(T + [c]))
                    A2 = _build(C, T2)
                    s2 = _score(A2)
                    if s2 > bestgsc:
                        bestgsc = s2
                        bestg = (T2, A2)
                if bestg is None:
                    break
                T, A = bestg
                sc = bestgsc

            if sc > best_sc:
                best_sc = sc
                best_A = A[:]

    if best_A is None:
        best_A = [0, 1, 3, 9, 27, 81]
        best_sc = _score(best_A)

    # final greedy polish
    best_A, best_sc = _greedy_polish(best_A, deadline)

    return sorted(set(int(x) for x in best_A))
# EVOLVE-BLOCK-END
