# EVOLVE-BLOCK-START
"""Deterministic structured construction: A is a union of arithmetic-progression clusters.

Each cluster is an arithmetic progression of length L with internal gap g. Clusters are
placed at offsets o_i. We tune (offsets, internal gaps, cluster lengths) deterministically
with a hill-climbing loop driven by a fast numpy-based exact counter for |A-A| and |A+A|.
Then we refine individual elements by local substitution moves.
The goal: differences within clusters stay distinct (many differences), while sums
collide heavily across clusters (few sums).
"""
import math
import time
import numpy as np


def _diffs_sums_np(a):
    """Exact |A-A| and |A+A| using numpy on integer array a (1D, distinct ints)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.shape[0]
    if n < 2:
        return 0, 0
    d = (a[:, None] - a[None, :]).ravel()
    nd = np.unique(d).size
    s = (a[:, None] + a[None, :]).ravel()
    ns = np.unique(s).size
    return int(nd), int(ns)


def _score_counts(nd, ns, n):
    if n < 2 or ns < 1 or nd < 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _score_np(a):
    nd, ns = _diffs_sums_np(a)
    return _score_counts(nd, ns, len(a))


def _build(clusters):
    """clusters: list of (offset, gap, length). Returns sorted distinct int list."""
    vals = []
    for (o, g, L) in clusters:
        for k in range(L):
            vals.append(o + k * g)
    vals = sorted(set(vals))
    return vals


def _try_cluster_config(clusters, best):
    a = _build(clusters)
    if len(a) < 2:
        return best
    s = _score_np(a)
    if s > best[0]:
        return (s, a, clusters)
    return best


def solve():
    """Return list A making |A-A| large, |A+A| small."""
    deadline = time.time() + 110.0
    best = (0.0, None, None)

    base_configs = []
    for ncl in (3, 4, 5, 6):
        for L in (18, 24, 30, 36, 48):
            gaps = [1 + 2 * i for i in range(ncl)]
            offs = []
            base = 0
            for i in range(ncl):
                offs.append(base)
                base += gaps[i] * L + 1
            clusters = [(offs[i], gaps[i], L) for i in range(ncl)]
            base_configs.append(clusters)

    for ncl in (4, 5, 6, 7, 8):
        for L in (10, 15, 20, 25):
            g = 1
            step = L * g + 1
            clusters = [(i * step, g, L) for i in range(ncl)]
            base_configs.append(clusters)

    # Cluster configs centered around zero to spread differences but overlap sums
    for ncl in (4, 6, 8):
        for L in (12, 16, 20):
            g = 1
            step = L * g + 1
            clusters = [((i - ncl // 2) * step, g, L) for i in range(ncl)]
            base_configs.append(clusters)

    for clusters in base_configs:
        if time.time() > deadline:
            break
        best = _try_cluster_config(clusters, best)

    if best[1] is None:
        return [0, 1, 2, 3]

    # Deterministic hill-climbing on the best cluster list.
    cur = best[2]
    cur_score = best[0]
    improved = True
    deltas = [1, 2, 3, 5, 7, 11, -1, -2, -3, -5, -7, -11]
    while improved and time.time() < deadline:
        improved = False
        for ci in range(len(cur)):
            if time.time() > deadline:
                break
            o, g, L = cur[ci]
            for dg in deltas:
                if time.time() > deadline:
                    break
                ng = g + dg
                if ng < 1:
                    continue
                trial = list(cur)
                trial[ci] = (o, ng, L)
                a = _build(trial)
                if len(a) < 2:
                    continue
                s = _score_np(a)
                if s > cur_score + 1e-12:
                    cur_score = s
                    cur = trial
                    improved = True
                    break
            for do in deltas:
                if time.time() > deadline:
                    break
                no = o + do
                trial = list(cur)
                trial[ci] = (no, g, L)
                a = _build(trial)
                if len(a) < 2:
                    continue
                s = _score_np(a)
                if s > cur_score + 1e-12:
                    cur_score = s
                    cur = trial
                    improved = True
                    break
            for dl in (1, -1, 2, -2, 3, -3, 5, -5):
                if time.time() > deadline:
                    break
                nL = L + dl
                if nL < 2 or nL > 400:
                    continue
                trial = list(cur)
                trial[ci] = (o, g, nL)
                a = _build(trial)
                if len(a) < 2:
                    continue
                s = _score_np(a)
                if s > cur_score + 1e-12:
                    cur_score = s
                    cur = trial
                    improved = True
                    break
        if cur_score > best[0]:
            best = (cur_score, _build(cur), list(cur))

    # Element-level substitution refinement on the best set.
    a = best[1]
    cur_arr = list(a)
    cur_score = best[0]
    if len(cur_arr) >= 2:
        for _pass in range(6):
            if time.time() > deadline:
                break
            improved = False
            n = len(cur_arr)
            order = list(range(n))
            for i in order:
                if time.time() > deadline:
                    break
                old = cur_arr[i]
                for delta in (1, -1, 2, -2, 3, -3, 5, -5, 7, -7, 11, -11, 13, -13):
                    nv = old + delta
                    if nv in cur_arr:
                        continue
                    trial = cur_arr[:]
                    trial[i] = nv
                    s = _score_np(trial)
                    if s > cur_score + 1e-12:
                        cur_score = s
                        cur_arr = trial
                        improved = True
                        break
            if not improved:
                break
        if cur_score > best[0]:
            best = (cur_score, sorted(cur_arr), None)

    return best[1]
# EVOLVE-BLOCK-END
