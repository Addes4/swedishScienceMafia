# EVOLVE-BLOCK-START
"""Deterministic structured construction: A is a union of arithmetic-progression clusters.

Each cluster is an arithmetic progression of length L with internal gap g. Clusters are
placed at offsets o_i. We tune (offsets, internal gaps, cluster lengths) with a
hill-climbing loop driven by a fast numpy-based exact counter for |A-A| and |A+A|, then
refine at the element level (single-element substitutions). The goal: differences stay
large (many distinct differences) while sums collide heavily across clusters (few sums).
"""
import math
import time
import numpy as np


def _diffs_sums_np(a):
    """Exact |A-A| and |A+A| using numpy on integer array a (1D, distinct ints)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.shape[0]
    if n < 2:
        return 0, 0
    d = np.unique((a[:, None] - a[None, :]).ravel()).size
    s = np.unique((a[:, None] + a[None, :]).ravel()).size
    return int(d), int(s)


def _score_counts(nd, ns, n):
    if n < 2 or ns < 1 or nd < 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _score_np(a):
    nd, ns = _diffs_sums_np(a)
    return _score_counts(nd, ns, len(a))


def _build(clusters):
    vals = []
    for (o, g, L) in clusters:
        for k in range(L):
            vals.append(o + k * g)
    return sorted(set(vals))


def _try_cluster_config(clusters, best):
    a = _build(clusters)
    if len(a) < 2:
        return best
    s = _score_np(a)
    if s > best[0]:
        return (s, a, list(clusters))
    return best


def _gen_base_configs():
    cfgs = []
    # distinct gaps per cluster (classic)
    for ncl in (3, 4, 5, 6):
        for L in (18, 24, 30, 36, 48):
            gaps = [1 + 2 * i for i in range(ncl)]
            offs = []
            base = 0
            for i in range(ncl):
                offs.append(base)
                base += gaps[i] * L + 1
            cfgs.append([(offs[i], gaps[i], L) for i in range(ncl)])
    # same gap -> heavy sum collisions across clusters
    for ncl in (4, 5, 6, 7, 8):
        for L in (10, 15, 20, 25, 30):
            for g in (1, 2, 3):
                step = L * g + 1
                cfgs.append([(i * step, g, L) for i in range(ncl)])
    # two distinct gaps alternating
    for ncl in (4, 6, 8):
        for L in (12, 18, 24):
            for (g1, g2) in ((1, 2), (1, 3), (2, 3)):
                offs = []
                base = 0
                for i in range(ncl):
                    g = g1 if i % 2 == 0 else g2
                    offs.append(base)
                    base += g * L + 1
                cfgs.append([(offs[i], (g1 if i % 2 == 0 else g2), L)
                             for i in range(ncl)])
    return cfgs


def solve():
    deadline = time.time() + 108.0
    best = (0.0, None, None)

    for clusters in _gen_base_configs():
        if time.time() > deadline:
            break
        best = _try_cluster_config(clusters, best)

    if best[1] is None:
        return [0, 1, 2, 3]

    # Hill-climbing on the best cluster list.
    cur = list(best[2])
    cur_score = best[0]
    deltas = [1, 2, 3, 5, 7, 11, -1, -2, -3, -5, -7, -11]
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for ci in range(len(cur)):
            if time.time() > deadline:
                break
            o, g, L = cur[ci]
            for dg in deltas:
                if time.time() > deadline:
                    break
                ng = g + dg
                if ng < 1:
                    continue
                trial = list(cur)
                trial[ci] = (o, ng, L)
                a = _build(trial)
                if len(a) < 2:
                    continue
                s = _score_np(a)
                if s > cur_score + 1e-12:
                    cur_score, cur, improved = s, trial, True
                    break
            o, g, L = cur[ci]
            for do in deltas:
                if time.time() > deadline:
                    break
                trial = list(cur)
                trial[ci] = (o + do, g, L)
                a = _build(trial)
                if len(a) < 2:
                    continue
                s = _score_np(a)
                if s > cur_score + 1e-12:
                    cur_score, cur, improved = s, trial, True
                    break
            o, g, L = cur[ci]
            for dl in (1, -1, 2, -2, 3, -3, 5, -5):
                if time.time() > deadline:
                    break
                nL = L + dl
                if nL < 2 or nL > 400:
                    continue
                trial = list(cur)
                trial[ci] = (o, g, nL)
                a = _build(trial)
                if len(a) < 2:
                    continue
                s = _score_np(a)
                if s > cur_score + 1e-12:
                    cur_score, cur, improved = s, trial, True
                    break
        if cur_score > best[0]:
            best = (cur_score, _build(cur), list(cur))

    # Element-level refinement: single-element substitutions.
    a = list(best[1]) if best[1] is not None else None
    if a is not None and time.time() < deadline:
        arr = np.array(a, dtype=np.int64)
        s_cur = best[0]
        offs = [1, -1, 2, -2, 3, -3, 5, -5, 7, -7]
        moved = True
        while moved and time.time() < deadline:
            moved = False
            for i in range(len(arr)):
                if time.time() > deadline:
                    break
                base = arr[i]
                for d in offs:
                    trial = arr.copy()
                    trial[i] = base + d
                    if np.unique(trial).size != trial.size:
                        continue
                    s = _score_np(trial)
                    if s > s_cur + 1e-12:
                        arr, s_cur, moved = trial, s, True
                        break

    if arr is not None and s_cur > best[0]:
        best = (s_cur, arr.tolist(), best[2])

    return best[1]
# EVOLVE-BLOCK-END

