# EVOLVE-BLOCK-START
"""Deterministic multi-cluster construction with a targeted shift-union polish."""
import math
import time
import numpy as np


def _counts(A):
    a = np.array(sorted(set(A)), dtype=np.int64)
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    return len(diffs), len(sums)


def _score_counts(nd, ns, n):
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _score(A):
    nd, ns = _counts(A)
    return _score_counts(nd, ns, len(set(A)))


def _build(clusters, offset):
    A = []
    for (s, step, ln) in clusters:
        for k in range(ln):
            A.append(offset + s + k * step)
    return sorted(set(A))


def _shift_polish(best_A, best_score, deadline):
    """Repeatedly try A union (A+t) for small t and keep improving merges."""
    improved = True
    while improved and time.time() < deadline:
        improved = False
        base = np.array(sorted(set(best_A)), dtype=np.int64)
        n0 = len(base)
        # candidate offsets derived from existing gaps and small magnitudes
        cand = set()
        for v in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 15, 16, 20, 24, 30,
                  -1, -2, -3, -4, -5, -6, -8, -10, -12, -15, -20):
            cand.add(v)
        d = np.diff(base)
        for v in np.unique(d[:50]):
            cand.add(int(v))
        for t in sorted(cand):
            if time.time() > deadline:
                break
            merged = np.union1d(base, base + t)
            if len(merged) > 4000:
                continue
            nd, ns = _counts(merged)
            s = _score_counts(nd, ns, len(merged))
            if s > best_score + 1e-12:
                best_A = merged.tolist()
                best_score = s
                improved = True
                break
    return best_A, best_score


def solve():
    deadline = time.time() + 110.0

    seeds = []

    for ncl in (2, 3, 4, 5, 6, 8):
        for L in (8, 12, 16, 20, 25, 30):
            if ncl * L > 3500:
                continue
            clusters = []
            base = 0
            gap = 1
            for c in range(ncl):
                clusters.append((base, 1 << (c + 1), L))
                base += gap
                gap += 1
            seeds.append(clusters)

    for ncl in (2, 3, 4, 5, 6, 8, 10):
        for L in (10, 16, 20, 30, 40, 60):
            if ncl * L > 3500 or ncl * L < 4:
                continue
            clusters = []
            s = 0
            for c in range(ncl):
                clusters.append((s, L + 1, L))
                s += L
            seeds.append(clusters)

    for ncl in (3, 4, 5, 6):
        for L in (15, 20, 25, 30):
            if ncl * L > 3500:
                continue
            clusters = [((c - ncl // 2) * L, L + 1, L) for c in range(ncl)]
            seeds.append(clusters)

    best_A = [0, 1]
    best_score = _score(best_A)

    for seed in seeds:
        if time.time() > deadline:
            break
        clusters = [list(t) for t in seed]
        current = _build(clusters, 0)
        cur_score = _score(current)
        if cur_score > best_score:
            best_A, best_score = current[:], cur_score

        improved = True
        while improved and time.time() < deadline:
            improved = False
            for ci in range(len(clusters)):
                for param in (0, 1):
                    base_val = clusters[ci][param]
                    for delta in (1, -1, 2, -2, 3, -3, 5, -5, 8, -8,
                                  13, -13, 21, -21, 34, -34):
                        trial = [list(t) for t in clusters]
                        nv = base_val + delta
                        if param == 1 and nv <= clusters[ci][2]:
                            continue
                        if param == 1 and nv < 2:
                            continue
                        trial[ci][param] = nv
                        A = _build(trial, 0)
                        n = len(set(A))
                        if n < 3 or n > 4000:
                            continue
                        nd, ns = _counts(A)
                        s = _score_counts(nd, ns, n)
                        if s > cur_score + 1e-12:
                            clusters = trial
                            cur_score = s
                            improved = True
                            current = A
                            if s > best_score:
                                best_A, best_score = A[:], s
                    if time.time() > deadline:
                        break
                if time.time() > deadline:
                    break

    # Targeted shift-union polish on the best found configuration.
    best_A, best_score = _shift_polish(best_A, best_score, deadline)

    best_A = sorted(set(best_A))
    if len(best_A) < 2:
        best_A = [0, 1]
    return best_A
# EVOLVE-BLOCK-END
