# EVOLVE-BLOCK-START
"""Digit-set construction.

A = { sum_i d_i * B^i : d_i in D }  (m positions).
With B large enough that digit arithmetic never carries, differences of A
correspond to digit-wise differences in D and sums to digit-wise sums in D, so
    |A-A| = |D-D|^m   and   |A+A| = |D+D|^m
giving ratio  log|D-D| / log|D+D|  independent of m, times the size bonus.
So we need a good small digit set D, and then use as many positions as fit.
"""
import math
import time
import random
import numpy as np

TIME_LIMIT = 108.0


def _counts(d):
    arr = np.asarray(sorted(set(int(x) for x in d)), dtype=np.int64)
    if arr.size == 0:
        return 0, 0
    diffs = (arr[:, None] - arr[None, :]).ravel()
    sums = (arr[:, None] + arr[None, :]).ravel()
    return int(np.unique(diffs).size), int(np.unique(sums).size)


def _ratio(d):
    nd, ns = _counts(d)
    if ns <= 1 or nd <= 1:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns), nd, ns


def _obj(D, n_total):
    """True objective: ratio + bonus for the largest achievable A."""
    nd, ns = _counts(D)
    if ns <= 1 or nd <= 1:
        return -1.0
    r = math.log(nd) / math.log(ns)
    bonus = (1.0 - 1.0 / n_total) / 100.0
    return r + bonus


def _expand(D, m, B):
    vals = [0]
    for _ in range(m):
        newvals = set()
        for v in vals:
            for d in D:
                newvals.add(v * B + d)
        vals = sorted(newvals)
    return vals


def _max_m(n, dmax):
    """Largest m with n^m <= 4000 and B^m fits in 1e15."""
    B = 2 * dmax + 10
    m = 1
    while n ** (m + 1) <= 4000:
        m += 1
    while m > 1 and (B ** m - 1) > 10 ** 15:
        m -= 1
    return m, B


def solve():
    start = time.time()
    random.seed(20240517)
    np.random.seed(20240517)

    best_D = [0, 1, 3]
    best_r = -1.0

    # ---- deterministic candidate digit sets ----
    candidates = []
    for k in range(2, 13):
        candidates.append(list(range(k)))
    for k in range(2, 9):
        for step in (2, 3):
            candidates.append([i * step for i in range(k)])
    for k in range(3, 11):
        candidates.append([i * i for i in range(k)])
    for k in range(3, 11):
        candidates.append([(1 << i) for i in range(k)])
    for a in range(1, 8):
        for b in range(1, 8):
            candidates.append(list(range(a)) + [a + b + i for i in range(b)])
    # near-AP with a few enlarged gaps (superlinear difference count)
    for k in range(4, 12):
        for extra in (2, 3, 4, 5, 7):
            D = list(range(k))
            D.append(k - 1 + extra)
            candidates.append(D)
    # AP plus symmetric perturbations
    for k in range(4, 12):
        D = [2 * i for i in range(k)]
        D += [1, 3]
        candidates.append(sorted(set(D)))

    def score_D(D):
        return _ratio(D)[0]

    for D in candidates:
        D = sorted(set(int(x) for x in D))
        r = score_D(D)
        if r > best_r:
            best_r, best_D = r, D[:]

    # ---- randomized search (annealing-ish hill climb) ----
    def climb(D, iters, deadline):
        D = sorted(set(int(x) for x in D))
        cur = score_D(D)
        for _ in range(iters):
            if time.time() > deadline:
                break
            cand = D[:]
            mv = random.randrange(5)
            if mv == 0 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.choice([-3, -2, -1, 1, 2, 3])
            elif mv == 1:
                cand.append(random.randrange(0, (max(cand) + 6) if cand else 6))
            elif mv == 2 and len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            elif mv == 3 and cand:
                cand.append(cand[-1] + random.choice([1, 2, 3, 4]))
            else:
                if len(cand) >= 2:
                    i = random.randrange(len(cand))
                    cand[i] += random.choice([-1, 1])
            cand = sorted(set(int(x) for x in cand))
            if len(cand) < 2 or len(cand) > 70:
                continue
            lo = min(cand)
            cand = [x - lo for x in cand]
            r = score_D(cand)
            if r > cur or (random.random() < 1e-3 and r > cur - 0.02):
                cur, D = r, cand
        return D, cur

    seeds = list(candidates)
    seeds += [[0, 1, 3, 7, 12, 20],
              [0, 2, 5, 9, 14, 20, 27],
              [0, 1, 2, 4, 8, 16, 24],
              [0, 1, 2, 3, 5, 8, 13, 21]]

    deadline = start + TIME_LIMIT * 0.45
    for s in seeds:
        if time.time() > deadline:
            break
        D, r = climb(s, iters=800, deadline=deadline)
        if r > best_r:
            best_r, best_D = r, D[:]

    # longer refine on the current best
    deadline2 = start + TIME_LIMIT * 0.80
    for _ in range(8):
        if time.time() > deadline2:
            break
        D, r = climb(best_D[:], iters=4000, deadline=deadline2)
        if r > best_r:
            best_r, best_D = r, D[:]

    best_D = sorted(set(int(x) for x in best_D))
    if len(best_D) < 2:
        best_D = [0, 1]

    n = len(best_D)
    dmax = max(abs(x) for x in best_D)

    # try a few bases near the tight one to possibly improve ratio via carries
    best_A = None
    best_obj = -1.0
    for B in [2 * dmax + 10, 2 * dmax + 1, dmax + 2, dmax + 1]:
        if B < dmax + 1:
            continue
        m = 1
        while n ** (m + 1) <= 4000 and (B ** (m + 1) - 1) <= 10 ** 15:
            m += 1
        if (B ** m - 1) > 10 ** 15:
            continue
        A = _expand(best_D, m, B)
        A = [int(x) for x in A if abs(x) <= 10 ** 15]
        A = sorted(set(A))
        if len(A) < 2:
            continue
        nd, ns = _counts(A)
        if ns > 1:
            r = math.log(nd) / math.log(ns) + (1.0 - 1.0 / len(A)) / 100.0
            if r > best_obj:
                best_obj = r
                best_A = A

    if best_A is None:
        # fallback: guaranteed valid set
        best_A = [0, 1] + [10 ** 6 * i for i in range(1, 20)]
        best_A = sorted(set(best_A))

    if len(best_A) > 4000:
        best_A = best_A[:4000]
    return best_A
# EVOLVE-BLOCK-END
