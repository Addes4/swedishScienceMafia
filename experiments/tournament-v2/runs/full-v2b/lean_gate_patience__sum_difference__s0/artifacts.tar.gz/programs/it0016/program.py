# EVOLVE-BLOCK-START
"""Mixed-radix digit construction: A = {sum d_i B^{i} with d_i in D_i}.
If the D_i are non-interacting (base B large enough), then
|A+A| = prod|D_i+D_i| and |A-A| = prod|D_i-D_i|, so
log|A-A|/log|A+A| = sum log|D_i-D_i| / sum log|D_i+D_i|.
We search small digit sets, then greedily stack the best levels to
maximize the cumulative log-ratio while keeping |A|<=4000."""
import math
import time
import itertools
import numpy as np


def _counts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    return diffs, sums


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return -1.0
    diffs, sums = _counts(a)
    if sums < 2 or diffs < 2:
        return -1.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _digit_stats(D):
    D = list(D)
    dd = set()
    ss = set()
    for x in D:
        for y in D:
            dd.add(x - y)
            ss.add(x + y)
    return len(dd), len(ss)


def _search_digit_sets(deadline):
    """Search many small digit sets and return unique ones with
    (log_ratio, log_dd, log_ss, size, D)."""
    cands = []
    seen = set()

    def consider(D):
        key = tuple(sorted(D))
        if key in seen:
            return
        seen.add(key)
        ndd, nss = _digit_stats(D)
        if nss < 2 or ndd < 2:
            return
        ldd = math.log(ndd)
        lss = math.log(nss)
        cands.append((ldd / lss, ldd, lss, len(key), list(key)))

    # Exhaustive small sizes over a moderate universe.
    universe = list(range(13))
    for sz in range(2, 6):
        if time.time() > deadline:
            break
        for comb in itertools.combinations(universe, sz):
            consider(comb)

    # Beam expansion to larger sizes.
    cands.sort(reverse=True, key=lambda t: t[0])
    beam = [t[4] for t in cands[:300]]
    for sz in range(6, 10):
        if time.time() > deadline:
            break
        for D in beam:
            mx = max(D)
            for v in range(0, mx + 5):
                if v in D:
                    continue
                consider(D + [v])
        cands.sort(reverse=True, key=lambda t: t[0])
        beam = [t[4] for t in cands[:300]]
        if not beam:
            break
    cands.sort(reverse=True, key=lambda t: t[0])
    return cands


def _build_mixed(levels, B):
    """levels: list of digit sets, level 0 least significant.
    Returns sorted array of all sums sum d_i B^i."""
    A = [0]
    pw = 1
    for D in levels:
        newA = []
        for a in A:
            for d in D:
                newA.append(a + d * pw)
        A = newA
        pw *= B
    return np.array(sorted(set(A)), dtype=np.int64)


def _span(D):
    return max(D) - min(D)


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    dig = _search_digit_sets(deadline)
    if not dig:
        return [0, 1]

    # Greedy stacking: pick levels one at a time to maximize the cumulative
    # sum(ldd)/sum(lss), subject to total size <= 4000.
    # Precompute per-set values.
    sets = [(ldd / lss, ldd, lss, len(D), D) for (r, ldd, lss, sz, D) in dig]
    # keep a diverse pool: top by ratio, and top by raw ldd (size)
    pool = sets[:400]
    # add some larger-size high-ldd sets too
    for s in sorted(sets, key=lambda t: t[1], reverse=True)[:200]:
        if s not in pool:
            pool.append(s)

    # Greedy cumulative construction
    for (seed_r, seed_ldd, seed_lss, seed_sz, seed_D) in sets[:60]:
        cum_ldd = seed_ldd
        cum_lss = seed_lss
        size = seed_sz
        span = _span(seed_D)
        levels = [seed_D]
        # repeatedly append the level that best improves the cumulative ratio
        while size <= 4000:
            best_gain = None
            for (r, ldd, lss, sz, D) in pool:
                if size * sz > 4000:
                    continue
                new_r = (cum_ldd + ldd) / (cum_lss + lss)
                if new_r > cum_ldd / cum_lss + 1e-12:
                    if best_gain is None or new_r > best_gain[0]:
                        best_gain = (new_r, ldd, lss, sz, D)
            if best_gain is None:
                break
            _, ldd, lss, sz, D = best_gain
            cum_ldd += ldd
            cum_lss += lss
            size *= sz
            span = max(span, _span(D))
            levels.append(D)
            if time.time() > deadline:
                break
        # build and score
        B = max(2 * span + 1, 2)
        A = _build_mixed(levels, B)
        if A.size < 2:
            continue
        if np.max(np.abs(A)) > 10**15:
            # too big; try shorter
            while levels and np.max(np.abs(_build_mixed(levels, B))) > 10**15:
                levels.pop()
            if not levels:
                continue
            span2 = max(_span(D) for D in levels)
            B = max(2 * span2 + 1, 2)
            A = _build_mixed(levels, B)
        sc = _score(A)
        if sc > best_score:
            best_score = sc
            best = A.tolist()
        if time.time() > deadline:
            break

    if best is None:
        best = [0, 1]

    # Final boundary refinement on the best construction.
    a = sorted(set(int(x) for x in best))
    improved = True
    rounds = 0
    while improved and rounds < 40 and time.time() < deadline:
        improved = False
        rounds += 1
        base_arr = np.array(a, dtype=np.int64)
        cand_adds = []
        lo, hi = a[0], a[-1]
        cand_adds.append(hi + 1)
        cand_adds.append(lo - 1)
        diffs = np.diff(base_arr)
        if diffs.size:
            gi = int(np.argmax(diffs))
            cand_adds.append(int(a[gi]) + int(diffs[gi]) // 2)
        for c in cand_adds:
            if len(a) >= 4000:
                break
            trial = np.array(sorted(set(a + [c])), dtype=np.int64)
            sc = _score(trial)
            if sc > best_score:
                best_score = sc
                a = trial.tolist()
                improved = True
                break
        if improved:
            continue
        for idx in (0, len(a) - 1):
            if len(a) <= 2:
                break
            trial_list = a[:idx] + a[idx + 1:]
            trial = np.array(trial_list, dtype=np.int64)
            sc = _score(trial)
            if sc > best_score:
                best_score = sc
                a = trial_list
                improved = True
                break

    return sorted(set(int(x) for x in a))
# EVOLVE-BLOCK-END
