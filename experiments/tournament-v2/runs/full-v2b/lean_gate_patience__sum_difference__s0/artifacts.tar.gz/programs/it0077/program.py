# EVOLVE-BLOCK-START
"""Digit-set construction with carry-free base expansion.

If A = { sum_i d_i B^i : d_i in D } for a base B larger than the spread of
D - D, then differences and sums decompose without carries:
    |A - A| = |D - D|^m , |A + A| = |D + D|^m .
So maximizing log|D-D|/log|D+D| for a small digit set, then expanding to m
positions (|A| = |D|^m <= 4000), gives a good ratio and the best size bonus.
"""
import time
import numpy as np


def _ndiff_nsum(vals):
    """Exact |X-X| and |X+X| for a set of int64 values."""
    v = np.unique(np.asarray(vals, dtype=np.int64))
    s = (v[:, None] + v[None, :]).ravel()
    nsum = int(np.unique(s).size)
    d = (v[:, None] - v[None, :]).ravel()
    ndif = int(np.unique(d).size)
    return ndif, nsum


def _ratio_score(vals):
    nd, ns = _ndiff_nsum(vals)
    if ns <= 1 or nd <= 1:
        return -1.0
    return np.log(nd) / np.log(ns)


def _build_A(D, B, m):
    """Return A = digit set expanded to m positions, as unique int64 array."""
    D = np.unique(np.asarray(D, dtype=np.int64))
    idx = np.zeros(1, dtype=np.int64)
    powers = np.array([B ** i for i in range(m)], dtype=np.int64)
    cur = np.zeros(1, dtype=np.int64)
    for i in range(m):
        cur = (cur[:, None] + D[None, :] * powers[i]).ravel()
    return np.unique(cur)


def _search_D(time_deadline, rng):
    """Search for a good digit set D."""
    best_D = None
    best_r = -1.0

    def consider(vals):
        nonlocal best_D, best_r
        vals = sorted(set(int(x) for x in vals))
        if len(vals) < 2:
            return
        # normalize by min (translation invariance of the ratio)
        mn = min(vals)
        vals = [x - mn for x in vals]
        if vals[-1] > 100000:
            return
        r = _ratio_score(vals)
        if r > best_r:
            best_r = r
            best_D = vals

    # Deterministic exhaustive search over small digit sets in [0, R).
    # Larger D -> larger m available, but small D can have better ratio.
    for R in (8, 9, 10, 12):
        # seed with hand-picked near-Sidon-like sets plus random restarts
        for _ in range(400 if R <= 10 else 200):
            k = rng.integers(3, max(4, R))
            vals = sorted(rng.choice(R, size=int(min(k, R)), replace=False).tolist())
            consider(vals)
        if time.time() > time_deadline:
            break

    # Greedy / local improvement on D with best ratio so far.
    improved = True
    while improved and time.time() < time_deadline:
        improved = False
        cur_D = best_D
        for i in range(len(cur_D)):
            for delta in (-3, -2, -1, 1, 2, 3, 4, 5):
                trial = cur_D[:]
                trial[i] += delta
                if min(trial) < 0:
                    continue
                if max(trial) > 100000:
                    continue
                r = _ratio_score(trial)
                if r > best_r + 1e-12:
                    best_r = r
                    best_D = sorted(set(trial))
                    improved = True
        # try a few random additions/removals
        for _ in range(30):
            if time.time() > time_deadline:
                break
            trial = list(best_D)
            if rng.random() < 0.5:
                trial.append(int(rng.integers(0, 60)))
            else:
                if len(trial) > 3:
                    trial.pop(int(rng.integers(0, len(trial))))
            r = _ratio_score(trial)
            if r > best_r + 1e-12:
                best_r = r
                best_D = sorted(set(trial))
                improved = True
    return best_D, best_r


def solve():
    deadline = time.time() + 112.0
    rng = np.random.default_rng(98765)

    search_deadline = time.time() + 60.0
    D, dr = _search_D(search_deadline, rng)
    if D is None:
        D = [0, 1, 4, 9]

    D = np.unique(np.asarray(D, dtype=np.int64))
    dsize = D.size
    spread = int(D.max() - D.min())

    # Choose base B > spread of (D - D) to avoid carries, with a safety margin.
    B_min = spread + 1
    # Base ~ prime-ish, not too small.
    B = B_min + 1
    while True:
        # make sure B is comfortably larger than 2*spread
        if B > 2 * spread:
            break
        B += 1

    # Choose m maximizing objective with |A| = |D|^m <= 4000.
    max_elems = 4000
    best = None
    best_val = -1.0

    m = 1
    while dsize ** (m + 1) <= max_elems and time.time() < deadline:
        m += 1
    # also clamp so values <= 1e15
    while m > 1 and (B ** (m - 1)) * (int(D.max()) + spread) > 10**15:
        m -= 1

    for mm in range(1, m + 1):
        A = _build_A(D, B, mm)
        n = A.size
        if n < 2:
            continue
        nd, ns = _ndiff_nsum(A)
        if ns <= 1:
            continue
        val = np.log(nd) / np.log(ns) + (1.0 - 1.0 / n) / 100.0
        if val > best_val:
            best_val = val
            best = A
        if time.time() > deadline:
            break

    # Try a couple of alternative bases in case carries/overlaps help.
    for Bd in (B, B + 2, 2 * spread + 3, int(D.max()) * 2 + 3):
        if Bd <= spread:
            continue
        mm = 1
        while dsize ** (mm + 1) <= max_elems:
            mm += 1
        while mm > 1 and (Bd ** (mm - 1)) * (int(D.max()) + spread) > 10**15:
            mm -= 1
        for k in range(1, mm + 1):
            if time.time() > deadline:
                break
            A = _build_A(D, Bd, k)
            n = A.size
            if n < 2:
                continue
            nd, ns = _ndiff_nsum(A)
            if ns <= 1:
                continue
            val = np.log(nd) / np.log(ns) + (1.0 - 1.0 / n) / 100.0
            if val > best_val:
                best_val = val
                best = A

    if best is None:
        best = np.array([0, 1, 4, 9, 24, 36], dtype=np.int64)

    best = np.unique(best)
    return [int(x) for x in best]
# EVOLVE-BLOCK-END

