# EVOLVE-BLOCK-START
"""Constructive Cantor-set style set with concentrated sums, refined by local search."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _seed():
    # Cantor-set style: numbers whose base-3 digits are in {0,1}, scaled.
    vals = [0]
    for _ in range(5):
        vals = [3 * v for v in vals] + [3 * v + 1 for v in vals]
    return vals


def solve():
    best = _seed()
    best_score = _score(best)
    cur = best[:]
    deadline = time.time() + 100
    step = 1
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.choice([-step, step])
        if len(set(cand)) < len(cand):
            continue
        if random.random() < 0.04 and len(cand) < 4000:
            cand.append(random.choice(best) + random.randint(-2, 2))
        if random.random() < 0.02 and len(cand) > 4:
            del cand[random.randrange(len(cand))]
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.05:
            cur = best[:]
        if random.random() < 0.01:
            step = random.choice([1, 1, 2, 3])
    return sorted(set(best))
# EVOLVE-BLOCK-END
