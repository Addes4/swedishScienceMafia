"""Maximize log|A-A|/log|A+A| via a two-digit-set digit construction.

For A = { sum_i d_i B^i : d_i in D1 (even i), d_i in D2 (odd i) }, with B larger
than 2*max(|D1|,|D2|) so no carries occur, the difference and sum sets have
product structure:
    |A-A| = (|D1-D1| * |D2-D2|)^(m/2)   (m = number of digits)
    |A+A| = (|D1+D1| * |D2+D2|)^(m/2)
so the ratio equals  log(|D1-D1||D2-D2|) / log(|D1+D1||D2+D2|).
We hill-climb D1 and D2 jointly (and also the single-set case) to maximize this,
then realize it with as many digits as fit limit constraints.
"""
import math
import time
import random
from itertools import product


def _stats(D):
    s = set()
    d = set()
    n = len(D)
    for i in range(n):
        xi = D[i]
        s.add(xi + xi)
        for j in range(n):
            d.add(xi - D[j])
        for j in range(i + 1, n):
            s.add(xi + D[j])
    return len(d), len(s)


def _ratio(D):
    d, s = _stats(D)
    if s <= 1 or d <= 1:
        return 0.0
    return math.log(d) / math.log(s)


def _two_ratio(D1, D2):
    d1, s1 = _stats(D1)
    d2, s2 = _stats(D2)
    if d1 <= 1 or d2 <= 1 or s1 <= 1 or s2 <= 1:
        return 0.0
    return math.log(d1 * d2) / math.log(s1 * s2)


def solve():
    deadline = time.time() + 95.0
    rng = random.Random(123456789)

    # ---- seed known-good small sets and hill-climb single-set case ----
    bestD = [1, 2, 4]
    bestR = _ratio(bestD)
    bestD2 = None

    def climb_single(D, iters, R):
        r = _ratio(D)
        n = len(D)
        D = list(D)
        for _ in range(iters):
            if time.time() > deadline:
                break
            D2 = list(D)
            idx = rng.randrange(len(D2))
            mode = rng.random()
            if mode < 0.6:
                D2[idx] = rng.randrange(R)
            elif mode < 0.85:
                D2[idx] += rng.randint(-3, 3)
            else:
                D2[idx] = rng.choice(D) + rng.randint(-2, 2)
            D2 = sorted(set(x for x in D2 if x >= 0))
            if len(D2) < 2:
                continue
            r2 = _ratio(D2)
            if r2 > r:
                r = r2
                D = D2
        return D, r

    for k in range(2, 26):
        if time.time() > deadline:
            break
        for restart in range(8):
            if time.time() > deadline:
                break
            R = max(8, 5 * k)
            if restart < 4:
                D = sorted(rng.sample(range(R), k))
            else:
                D = sorted(set(int(round(2 ** (i + 1))) - 1 for i in range(k)))
            D, r = climb_single(D, 100, R)
            if r > bestR:
                bestR = r
                bestD = D[:]

    # ---- joint two-set hill-climb (uses remaining time) ----
    def climb_two(D1, D2, iters, R):
        r = _two_ratio(D1, D2)
        for _ in range(iters):
            if time.time() > deadline:
                break
            which = rng.random() < 0.5
            D = list(D1 if which else D2)
            if len(D) < 2:
                D = [0, 1]
            idx = rng.randrange(len(D))
            mode = rng.random()
            if mode < 0.6:
                D[idx] = rng.randrange(R)
            elif mode < 0.85:
                D[idx] += rng.randint(-3, 3)
            else:
                D[idx] = rng.choice(D) + rng.randint(-2, 2)
            D = sorted(set(x for x in D if x >= 0))
            if len(D) < 2:
                continue
            n1, n2 = (D, D2) if which else (D1, D)
            r2 = _two_ratio(n1, n2)
            if r2 > r:
                r = r2
                D1, D2 = n1, n2
        return D1, D2, r

    # start two-set search from the best single set (duplicated and varied)
    tD1 = bestD[:]
    tD2 = bestD[:] if bestD else [1, 2, 4]
    tD1, tD2, tR = climb_two(tD1, tD2, 4000, max(16, 5 * max(len(tD1), len(tD2))))
    if tR > bestR:
        bestR = tR
        bestD, bestD2 = tD1, tD2

    for k in range(3, 20):
        if time.time() > deadline:
            break
        for restart in range(4):
            if time.time() > deadline:
                break
            R = max(10, 5 * k)
            D1 = sorted(rng.sample(range(R), k))
            D2 = sorted(rng.sample(range(R), k))
            D1, D2, r = climb_two(D1, D2, 600, R)
            if r > bestR:
                bestR = r
                bestD, bestD2 = D1[:], D2[:]

    # ---- realize best construction as A ----
    LIMIT = 4000
    CAP = 10 ** 15

    if bestD2 is None:
        # single digit set
        D = bestD
        k = len(D)
        maxD = max(abs(x) for x in D) or 1
        B = max(2, 2 * maxD + 1)
        m = 1
        while k ** (m + 1) <= LIMIT:
            top = maxD * ((B ** (m + 1) - 1) // (B - 1))
            if top > CAP:
                break
            m += 1
        A = []
        for combo in product(D, repeat=m):
            val = 0
            p = 1
            for dgt in combo:
                val += dgt * p
                p *= B
            A.append(val)
    else:
        # interleaved: even positions D1, odd positions D2
        D1, D2 = bestD, bestD2
        mx = max((max(D1) if D1 else 0), (max(D2) if D2 else 0)) or 1
        B = max(2, 2 * mx + 1)
        a, b = len(D1), len(D2)
        # total count = a^ceil(m/2) * b^floor(m/2)
        m = 1
        while True:
            e1 = (m + 1) // 2
            e2 = m // 2
            cnt = (a ** e1) * (b ** e2)
            if cnt > LIMIT:
                break
            top = mx * ((B ** m - 1) // (B - 1)) if B > 1 else mx
            if top > CAP:
                break
            m += 1
            if m > 40:
                break
        e1 = (m + 1) // 2
        e2 = m // 2
        A = []
        for c1 in product(D1, repeat=e1):
            v1 = 0
            p = 1
            for x in c1:
                v1 += x * p
                p *= B * B
            for c2 in product(D2, repeat=e2):
                v2 = 0
                p = B
                for x in c2:
                    v2 += x * p
                    p *= B * B
                A.append(v1 + v2)

    A = sorted(set(A))
    if len(A) < 2:
        A = [0, 1, 2, 4]
    return [int(x) for x in A]

