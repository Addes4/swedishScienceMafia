# EVOLVE-BLOCK-START
"""Simulated annealing on a compact integer set, directly optimizing the ratio
log|A-A|/log|A+A|. Moves are designed to create sum collisions (small sums)
while keeping differences distinct."""
import math
import random
import time

import numpy as np


def _counts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0, n
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    return diffs.size, sums.size, n


def _score(a):
    d, s, n = _counts(a)
    if s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 110
    rng = random.Random(987654321)

    best = None
    best_score = -1.0

    # Seed pool: several structured starts.
    seeds = []
    # AP seeds of various lengths: an AP of length n has |A+A| ~ 2n-1 (tiny!)
    # and |A-A| ~ 2n-1 too. Ratio ~ 1 but bonus grows with n. Not ideal.
    # Sidon-ish seeds give ratio > 1.
    base = [0, 1, 3, 7, 12, 20, 30, 44, 65, 80]
    seeds.append(base)
    seeds.append([i * i for i in range(12)])
    seeds.append([2 ** i - 1 for i in range(10)])
    seeds.append([i * (i + 1) // 2 for i in range(14)])
    for _ in range(20):
        k = rng.randint(8, 16)
        seeds.append(sorted(rng.sample(range(0, 4 * k), k)))

    for sd in seeds:
        arr = np.array(sorted(set(sd)), dtype=np.int64)
        s = _score(arr)
        if s > best_score:
            best_score = s
            best = arr.copy()

    cur = best.copy()
    cur_score = best_score

    # Precompute nothing; use numpy exact counts each eval.
    T0 = 0.05
    steps = 0
    while time.time() < deadline:
        steps += 1
        T = T0 * max(1e-6, 1.0 - (time.time() - (deadline - 110)) / 110.0)

        n = cur.size
        cand = cur.copy()
        mv = rng.random()

        if mv < 0.45:
            # shift a block: preserve internal gaps, changes sums/diffs a lot
            i = rng.randrange(n)
            j = rng.randint(i + 1, n)
            delta = rng.randint(-6, 6)
            if delta == 0:
                continue
            cand[i:j] = cand[i:j] + delta
        elif mv < 0.70:
            # single-element move
            i = rng.randrange(n)
            cand[i] += rng.choice([-1, 1, -2, 2, -3, 3, -5, 5])
        elif mv < 0.85:
            # reflect around a pivot: creates additive symmetry -> many sums collide
            pivot = cur[rng.randrange(n)]
            cand = 2 * pivot - cur
        else:
            # swap: remove one, add a new value (keep size)
            i = rng.randrange(n)
            cand = np.delete(cand, i)
            newv = rng.randint(-20, 80)
            cand = np.append(cand, newv)

        cand = np.unique(cand)
        if cand.size < 6 or cand.size > 4000:
            continue
        s = _score(cand)
        if s >= cur_score or (T > 1e-9 and rng.random() < math.exp(min(50.0, (s - cur_score) / T))):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand.copy()

        # periodic restart from best
        if steps % 4000 == 0:
            cur = best.copy()
            cur_score = best_score

    res = np.unique(best)
    return [int(x) for x in res]


# EVOLVE-BLOCK-END
