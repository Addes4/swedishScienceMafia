# EVOLVE-BLOCK-START
"""Base-digit (mixed-carry) construction: A = { sum d_i B^i : d_i in D }.

Carries in A+A collapse sums onto few values while A-A keeps many distinct
differences, giving a high log|A-A|/log|A+A|.  We search over the digit set D,
the base B and the number of levels m with randomized restarts plus a
hill-climb, scored exactly with Python sets.
"""
import math
import random
import time


def _counts(A):
    """Exact |A-A| and |A+A| using Python sets."""
    d = set()
    s = set()
    for x in A:
        for y in A:
            d.add(x - y)
            s.add(x + y)
    return len(d), len(s)


def _score(A):
    n = len(A)
    if n < 2:
        return -1.0
    nd, ns = _counts(A)
    if ns < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _build(D, B, m):
    A = {0}
    p = 1
    for _ in range(m):
        nxt = set()
        for a in A:
            for d in D:
                nxt.add(a + d * p)
        A = nxt
        p *= B
        if len(A) > 3600:
            return None
    return A


def solve():
    deadline = time.time() + 105.0
    random.seed(987654321)

    best_A = [0, 1]
    best_score = 0.0

    # (levels m, digit-set size t) so that t^m stays tractable.
    configs = [(2, 36), (2, 30), (3, 11), (3, 10), (4, 6), (5, 5)]

    def consider(A):
        nonlocal best_A, best_score
        if A is None:
            return
        A = sorted(A)
        if len(A) < 3 or len(A) > 4000:
            return
        s = _score(A)
        if s > best_score:
            best_score = s
            best_A = A

    def random_D(t):
        # a random digit set within [0, B) whose elements are spread out
        D = set([0])
        while len(D) < t:
            D.add(random.randint(0, max(t, 8)))
        return sorted(D)

    for (m, t) in configs:
        if time.time() > deadline:
            break
        for _ in range(60):
            if time.time() > deadline:
                break
            D = random_D(t)
            hi = max(D)
            # force carries: base comparable to the digit range
            B = random.randint(hi + 1, 2 * hi + 4)
            consider(_build(D, B, m))

        # Hill-climb the best structure of this shape.
        for _ in range(40):
            if time.time() > deadline:
                break
            D = random_D(t)
            hi = max(D)
            B = random.randint(hi + 1, 2 * hi + 4)
            cur = _build(D, B, m)
            if cur is None:
                continue
            cur_s = _score(cur)
            improved = True
            while improved and time.time() < deadline:
                improved = False
                # perturb digit set
                for idx in range(len(D)):
                    if time.time() > deadline:
                        break
                    for delta in (1, -1, 2, -2, 3, -3, 5, -5):
                        nd = D[:]
                        nd[idx] += delta
                        if nd[idx] < 0 or len(set(nd)) < len(nd):
                            continue
                        A = _build(nd, B, m)
                        if A is None:
                            continue
                        s = _score(A)
                        if s > cur_s + 1e-12:
                            D = nd
                            cur = A
                            cur_s = s
                            improved = True
                            break
                    if improved:
                        break
                if improved:
                    continue
                # perturb base
                for dB in (1, -1, 2, -2, 3, -3):
                    nB = B + dB
                    if nB <= max(D):
                        continue
                    A = _build(D, nB, m)
                    if A is None:
                        continue
                    s = _score(A)
                    if s > cur_s + 1e-12:
                        B = nB
                        cur = A
                        cur_s = s
                        improved = True
                        break
                if improved:
                    continue
                # try add / remove a digit
                if len(D) < t + 2 and random.random() < 0.5:
                    cand = random.randint(0, max(D) + 2)
                    if cand not in D:
                        nd = sorted(set(D) | {cand})
                        A = _build(nd, B, m)
                        if A is not None:
                            s = _score(A)
                            if s > cur_s + 1e-12:
                                D = nd
                                cur = A
                                cur_s = s
                                improved = True
            if cur_s > best_score:
                best_score = cur_s
                best_A = sorted(cur)

    # Final single-element polish on the best set (cheap, small sets).
    if best_A and time.time() < deadline:
        A = set(best_A)
        cur_s = _score(sorted(A))
        improved = True
        while improved and time.time() < deadline:
            improved = False
            L = sorted(A)
            for x in L:
                if time.time() > deadline:
                    break
                trial = set(A)
                trial.discard(x)
                if len(trial) < 3:
                    continue
                s = _score(sorted(trial))
                if s > cur_s + 1e-12:
                    A = trial
                    cur_s = s
                    improved = True
                    break
            if improved:
                continue
            cand = set()
            for x in L:
                for d in (1, -1, 2, -2):
                    cand.add(x + d)
            for x in cand:
                if time.time() > deadline:
                    break
                if x in A:
                    continue
                trial = set(A)
                trial.add(x)
                if len(trial) > 4000:
                    continue
                s = _score(sorted(trial))
                if s > cur_s + 1e-12:
                    A = trial
                    cur_s = s
                    improved = True
                    break
        if cur_s > best_score:
            best_score = cur_s
            best_A = sorted(A)

    best_A = sorted(set(best_A))
    if len(best_A) < 2:
        best_A = [0, 1]
    return best_A
# EVOLVE-BLOCK-END
