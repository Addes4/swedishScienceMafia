# EVOLVE-BLOCK-START
"""Deterministic multi-cluster construction with numpy exact scoring.

Idea: A = union over clusters C_i of (base_i + {0, d_i, 2 d_i, ..., (k_i-1) d_i}).
We choose offsets base_i and gaps d_i so that:
  * within/across-cluster differences mostly collide little  -> |A-A| large,
  * sums from many cluster pairs coincide additively        -> |A+A| small.
Scoring uses numpy boolean convolution-style counting of exact |A-A|, |A+A|.
A deterministic hill climber then refines the cluster parameters.
"""
import math
import time
import numpy as np

TIME_LIMIT = 110.0


def _exact_counts(a):
    """Exact |A-A| and |A+A| for small integer set (numpy)."""
    arr = np.asarray(a, dtype=np.int64)
    n = arr.size
    # differences
    diffs = (arr[:, None] - arr[None, :]).ravel()
    sums = (arr[:, None] + arr[None, :]).ravel()
    return int(np.unique(diffs).size), int(np.unique(sums).size)


def _score_from_counts(nd, ns, n):
    if ns <= 1 or nd <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _params_to_set(bases, gaps, sizes):
    a = []
    for b, g, k in zip(bases, gaps, sizes):
        for t in range(k):
            a.append(int(b) + t * int(g))
    return sorted(set(a))


def _build_initial():
    """Deterministic starting configuration.

    Use clusters whose offsets are chosen to force many additive collisions:
    base_i in a small arithmetic-progression so bases i+j collide, and the
    gaps are large distinct primes so cross-cluster differences stay unique.
    """
    nc = 8          # number of clusters
    k = 8           # points per cluster
    bases = [i * 100003 for i in range(nc)]
    # small additive structure among bases for sums
    # shift some bases to create more additive collisions
    offsets = [0, 1, 2, 3, 4, 5, 6, 7]
    scale = 1000000
    bases = [offsets[i] + i * scale for i in range(nc)]
    primes = [1000003, 1000033, 1000037, 1000039, 1000081, 1000099, 1000117, 1000121]
    gaps = [primes[i % len(primes)] for i in range(nc)]
    sizes = [k] * nc
    return bases, gaps, sizes


def solve():
    start = time.time()
    bases, gaps, sizes = _build_initial()

    cur_set = _params_to_set(bases, gaps, sizes)
    nd, ns = _exact_counts(cur_set)
    cur_score = _score_from_counts(nd, ns, len(cur_set))
    best_set, best_score = cur_set[:], cur_score

    nc = len(bases)

    # Deterministic hill climbing over gaps, bases offsets, and cluster sizes.
    improved = True
    while improved and time.time() - start < TIME_LIMIT:
        improved = False

        # 1) tweak gaps (large primes scaled)
        for ci in range(nc):
            for mult in (2, 3, 5, 7, 11, 13, 17, 19, 23):
                cand_gaps = gaps[:]
                cand_gaps[ci] = gaps[ci] * mult
                s = _params_to_set(bases, cand_gaps, sizes)
                nd2, ns2 = _exact_counts(s)
                sc = _score_from_counts(nd2, ns2, len(s))
                if sc > cur_score:
                    gaps, cur_set, cur_score = cand_gaps, s, sc
                    improved = True
                    if sc > best_score:
                        best_set, best_score = s[:], sc

        # 2) tweak base offsets by small steps to induce additive collisions
        for ci in range(nc):
            for delta in (-7, -5, -3, -2, -1, 1, 2, 3, 5, 7):
                cand_bases = bases[:]
                cand_bases[ci] = bases[ci] + delta
                s = _params_to_set(cand_bases, gaps, sizes)
                nd2, ns2 = _exact_counts(s)
                sc = _score_from_counts(nd2, ns2, len(s))
                if sc > cur_score:
                    bases, cur_set, cur_score = cand_bases, s, sc
                    improved = True
                    if sc > best_score:
                        best_set, best_score = s[:], sc

        # 3) try adjusting cluster sizes up (adds points; bonus favours larger)
        for ci in range(nc):
            for dk in (1, -1, 2, -2):
                nk = sizes[ci] + dk
                if nk < 2 or nk > 40:
                    continue
                cand_sizes = sizes[:]
                cand_sizes[ci] = nk
                s = _params_to_set(bases, gaps, cand_sizes)
                if len(s) > 4000:
                    continue
                nd2, ns2 = _exact_counts(s)
                sc = _score_from_counts(nd2, ns2, len(s))
                if sc > cur_score:
                    sizes, cur_set, cur_score = cand_sizes, s, sc
                    improved = True
                    if sc > best_score:
                        best_set, best_score = s[:], sc

    # Normalize so values fit range and are shifted to small magnitudes is not
    # needed; just ensure distinctness and range constraints.
    best_set = sorted(set(int(x) for x in best_set))
    lim = 10**15
    if best_set and (max(abs(x) for x in best_set) > lim or len(best_set) > 4000):
        # fall back to a safe scaled version
        best_set = sorted(set(int(x) for x in _build_safe_fallback()))
    distinct = sorted(set(best_set))
    return distinct


def _build_safe_fallback():
    bases, gaps, sizes = _build_initial()
    return _params_to_set(bases, gaps, sizes)
# EVOLVE-BLOCK-END
