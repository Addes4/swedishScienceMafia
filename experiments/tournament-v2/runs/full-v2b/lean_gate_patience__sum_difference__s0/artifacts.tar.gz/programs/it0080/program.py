# EVOLVE-BLOCK-START
"""Carry-free digit-set construction.

A = { sum_i d_i B^i : d_i in D }, B > spread(D-D) => no carries, so
    |A-A| = |D-D|^m, |A+A| = |D+D|^m, |A| = |D|^m.
Objective ~ m*log|D-D| / (m*log|D+D|) = log|D-D|/log|D+D| (ratio-only),
plus size bonus favouring the largest achievable |A| <= 4000.
Best digit sets are near-Sidon sets where |D+D| is kept small.
"""
import time
import numpy as np


def _ndiff_nsum(v):
    v = np.unique(np.asarray(v, dtype=np.int64))
    s = (v[:, None] + v[None, :]).ravel()
    nsum = int(np.unique(s).size)
    d = (v[:, None] - v[None, :]).ravel()
    ndif = int(np.unique(d).size)
    return ndif, nsum


def _ratio_score(v):
    nd, ns = _ndiff_nsum(v)
    if ns <= 1 or nd <= 1:
        return -1.0
    return np.log(nd) / np.log(ns)


def _build_A(D, B, m):
    D = np.unique(np.asarray(D, dtype=np.int64))
    cur = np.zeros(1, dtype=np.int64)
    p = 1
    for i in range(m):
        cur = (cur[:, None] + D[None, :] * p).ravel()
        p *= B
    return np.unique(cur)


def _score_A(A, max_elems=4000):
    A = np.unique(np.asarray(A, dtype=np.int64))
    n = A.size
    if n < 2 or n > max_elems:
        return -1.0, None
    nd, ns = _ndiff_nsum(A)
    if ns <= 1:
        return -1.0, None
    val = np.log(nd) / np.log(ns) + (1.0 - 1.0 / n) / 100.0
    return val, A


def _candidate_digit_sets():
    """Deterministic pool of good small digit sets (near-Sidon-ish)."""
    pool = []
    # classic near-Sidon / B_2-like sets with good difference/sum ratio
    pool.append([0, 1, 4, 9, 15, 22, 26, 31])          # near-Sidon size 8
    pool.append([0, 1, 3, 7, 12, 20, 30, 44])           # Sidon-like
    pool.append([0, 1, 4, 10, 18, 23, 25])              # Golomb-ish
    pool.append([0, 1, 4, 9, 15])
    pool.append([0, 1, 4, 10, 18])
    pool.append([0, 1, 4, 9])
    pool.append([0, 1, 3, 7, 12])
    pool.append([0, 1, 2, 5, 10, 17, 27])               # dense-ish
    pool.append([0, 1, 5, 11, 19, 29])                  # convex
    pool.append([0, 1, 6, 13, 22, 33])
    # small APs and near-APs (small |D+D|)
    pool.append([0, 1, 2])
    pool.append([0, 1, 2, 3])
    pool.append([0, 1, 2, 4])
    pool.append([0, 1, 3, 4])
    pool.append([0, 1, 2, 3, 4])
    pool.append([0, 1, 2, 3, 5])
    pool.append([0, 1, 2, 4, 5])
    return pool


def solve():
    deadline = time.time() + 110.0
    rng = np.random.default_rng(12345)
    max_elems = 4000
    LIMIT = 10 ** 15

    # 1) Build and evaluate digit sets from the deterministic pool, then
    #    locally search each with simulated annealing / hill climbing.
    D_pool = _candidate_digit_sets()

    # Add random near-Sidon candidates
    for _ in range(300):
        k = int(rng.integers(4, 9))
        vals = [0]
        while len(vals) < k:
            vals.append(int(vals[-1] + rng.integers(1, 8)))
        D_pool.append(vals)

    best_A = None
    best_val = -1.0
    scored_D = []

    for D0 in D_pool:
        if time.time() > deadline - 20:
            break
        D0 = sorted(set(int(x) for x in D0))
        if len(D0) < 2:
            continue
        mn = D0[0]
        D0 = [x - mn for x in D0]

        # local search on D to improve ratio
        cur = D0[:]
        cur_r = _ratio_score(cur)
        improved = True
        steps = 0
        while improved and time.time() < deadline - 20 and steps < 200:
            improved = False
            steps += 1
            for i in range(len(cur)):
                for delta in (-2, -1, 1, 2):
                    trial = cur[:]
                    trial[i] += delta
                    if min(trial) < 0 or max(trial) > 200:
                        continue
                    r = _ratio_score(trial)
                    if r > cur_r + 1e-12:
                        cur_r = r
                        cur = sorted(set(trial))
                        improved = True
        scored_D.append((cur_r, cur))

    # deterministic pool of extra near-Sidon sets via greedy Sidon construction
    for M in (20, 30, 40, 60, 80, 100, 130, 160, 200):
        vals = [0, 1]
        cand = 2
        while len(vals) < 8 and cand < M:
            ok = True
            for a in vals:
                for b in vals:
                    if a + b == cand or abs(a - b) == cand:
                        ok = False
                        break
                if not ok:
                    break
            if ok:
                vals.append(cand)
            cand += 1
        if len(vals) >= 3:
            r = _ratio_score(vals)
            scored_D.append((r, sorted(vals)))

    scored_D.sort(key=lambda t: -t[0])

    # 2) For the best digit sets, expand with the best base/m and score the
    #    actual set A (with size bonus).
    for ratio_r, D in scored_D[:12]:
        if time.time() > deadline - 5:
            break
        if len(D) < 2:
            continue
        spread = int(max(D) - min(D))
        dsize = len(D)

        B_candidates = set()
        for b in range(spread + 1, spread + 8):
            B_candidates.add(b)
        B_candidates.add(spread + 1)
        B_candidates.add(2 * spread + 3)
        B_candidates.add(int(max(D)) * 2 + 3)
        B_candidates.add(int(max(D)) * 3 + 1)
        # pick base B so that |D|^m is close to 4000 for some m; prefer large B
        for m in range(1, 12):
            if dsize ** m > max_elems:
                break
            # choose B to maximize dsize**m without exceeding value limit
            for B in B_candidates:
                if B < spread + 1:
                    continue
                top = int(max(D))
                if (B ** (m - 1)) * (top + spread) > LIMIT:
                    continue
                A = _build_A(D, B, m)
                val, Au = _score_A(A, max_elems)
                if val > best_val:
                    best_val = val
                    best_A = Au

        # also sweep m to hit near-4000 sizes using several bases
        for B in sorted(B_candidates):
            if B < spread + 1:
                continue
            for m in range(1, 12):
                if dsize ** m > max_elems:
                    break
                top = int(max(D))
                if (B ** (m - 1)) * (top + spread) > LIMIT:
                    continue
                A = _build_A(D, B, m)
                val, Au = _score_A(A, max_elems)
                if val > best_val:
                    best_val = val
                    best_A = Au
            if time.time() > deadline - 5:
                break

    if best_A is None:
        best_A = np.array([0, 1, 4, 9, 24, 36, 48, 60], dtype=np.int64)
        # fallback: try to score a simple near-Sidon digit set
        D = [0, 1, 4, 9, 15, 22]
        B = 40
        m = 3
        best_A = _build_A(D, B, m)

    best_A = np.unique(best_A)
    return [int(x) for x in best_A]
# EVOLVE-BLOCK-END
