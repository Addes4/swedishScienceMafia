"""Maximize log|A-A|/log|A+A| via the digit-set construction.

For A = { sum_i d_i B^i : d_i in D } with base B larger than 2*max|D| (carry-free),
    |A-A| = |D-D|^m ,  |A+A| = |D+D|^m
so the ratio equals log|D-D| / log|D+D| for the *small* digit set D.
Increasing the number of digits m only raises |A| (size bonus).
Thus we search small D directly, allowing shifts/negatives which affect |D+D|.
"""
import math
import time
import random
from itertools import product


def _stats(D):
    """Exact |D-D| and |D+D|."""
    s = set()
    d = set()
    n = len(D)
    for i in range(n):
        xi = D[i]
        s.add(xi + xi)
        for j in range(n):
            d.add(xi - D[j])
        for j in range(i + 1, n):
            s.add(xi + D[j])
    return len(d), len(s)


def _ratio(D):
    d, s = _stats(D)
    if s <= 1 or d <= 1:
        return 0.0
    return math.log(d) / math.log(s)


def solve():
    deadline = time.time() + 95.0
    rng = random.Random(20240917)

    bestD = [1, 2, 4]
    bestR = _ratio(bestD)

    def try_improve(D, r, iters, R, allow_neg):
        for _ in range(iters):
            if time.time() > deadline:
                break
            k = len(D)
            D2 = list(D)
            idx = rng.randrange(k)
            mode = rng.random()
            if mode < 0.5:
                if allow_neg:
                    D2[idx] = rng.randrange(-R, R + 1)
                else:
                    D2[idx] = rng.randrange(R)
            elif mode < 0.8:
                D2[idx] = D2[idx] + rng.randint(-3, 3)
            else:
                other = rng.choice(D)
                D2[idx] = other + rng.randint(-2, 2)
            D2 = sorted(set(D2))
            if len(D2) < 2:
                continue
            r2 = _ratio(D2)
            if r2 > r:
                r = r2
                D = D2
        return D, r

    # broad size + range sweep with both nonnegative and signed digits
    for k in range(2, 26):
        if time.time() > deadline:
            break
        for restart in range(16):
            if time.time() > deadline:
                break
            R = max(8, 5 * k)
            allow_neg = (restart % 2 == 1)
            if restart % 4 == 0:
                D = sorted(rng.sample(range(R), k))
            elif restart % 4 == 1:
                D = sorted(rng.sample(range(-R // 2, R // 2 + 1), k))
            elif restart % 4 == 2:
                D = sorted(set(int(round(2 ** (i + 1))) - 1 for i in range(k)))
            else:
                # random subset around a shifted interval
                shift = rng.randint(-R, R)
                D = sorted(set(shift + i for i in range(k)))
            D, r = try_improve(D, _ratio(D), 150, R, allow_neg)
            if time.time() < deadline:
                D, r = try_improve(D, r, 80, R * 2, allow_neg)
            if r > bestR:
                bestR = r
                bestD = D[:]

    # ---------------------------------------------------------------
    # blow the best digit set up into many base-B digits
    # ---------------------------------------------------------------
    D = bestD
    k = len(D)
    maxD = max(abs(x) for x in D)
    B = max(2, 2 * maxD + 3)          # carry-free base

    m = 1
    while True:
        if k ** (m + 1) > 4000:
            break
        top = maxD * ((B ** (m + 1) - 1) // (B - 1)) if B > 1 else maxD
        if top > 10 ** 15:
            break
        m += 1

    A = []
    for combo in product(D, repeat=m):
        val = 0
        p = 1
        for dgt in combo:
            val += dgt * p
            p *= B
        A.append(val)

    A = sorted(set(A))
    if len(A) < 2:
        A = [0, 1, 2, 4]

    return [int(x) for x in A]
