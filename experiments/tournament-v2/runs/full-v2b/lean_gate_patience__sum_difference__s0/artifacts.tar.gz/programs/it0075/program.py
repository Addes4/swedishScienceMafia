# EVOLVE-BLOCK-START
"""Digit-set construction with exact search over D and optimal expansion.

A = { sum_i d_i * B^i : d_i in D }  with m positions and base B large enough
that digit arithmetic never carries.  Then
    |A-A| = |D-D|^m,   |A+A| = |D+D|^m
so the ratio is  log|D-D|/log|D+D|  independent of m, and we maximize the
bonus by taking m as large as possible (|A|=|D|^m <= 4000).
"""
import math
import time
import random
import numpy as np

TIME_LIMIT = 105.0


def _counts(d):
    arr = np.asarray(sorted(set(int(x) for x in d)), dtype=np.int64)
    if arr.size == 0:
        return 0, 0
    diffs = arr[:, None] - arr[None, :]
    sums = arr[:, None] + arr[None, :]
    return int(np.unique(diffs).size), int(np.unique(sums).size)


def _ratio(d):
    nd, ns = _counts(d)
    if ns <= 1 or nd <= 1:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns), nd, ns


def _expand(D, m, B):
    vals = [0]
    for _ in range(m):
        newvals = []
        seen = set()
        for v in vals:
            for d in D:
                w = v * B + d
                if w not in seen:
                    seen.add(w)
                    newvals.append(w)
        vals = newvals
    return vals


def solve():
    start = time.time()

    best_D = None
    best_r = -1.0

    # ---------- deterministic candidate digit sets ----------
    candidates = []
    for k in range(2, 13):
        candidates.append(list(range(k)))
    for k in range(2, 10):
        for step in (2, 3):
            candidates.append([i * step for i in range(k)])
    for k in range(3, 11):
        candidates.append([i * i for i in range(k)])
    for k in range(3, 11):
        candidates.append([(1 << i) for i in range(k)])
    for a in range(1, 9):
        for b in range(1, 9):
            candidates.append(list(range(a)) + [a + b + i for i in range(b)])
    # AP plus a few isolated far points (bigger difference set, modest sum set)
    for k in range(3, 9):
        for t in (3, 5, 8, 13):
            candidates.append(list(range(k)) + [k + t])

    for D in candidates:
        D = sorted(set(int(x) for x in D))
        r, _, _ = _ratio(D)
        if r > best_r:
            best_r, best_D = r, D[:]

    def climb(D, iters, deadline):
        D = sorted(set(int(x) for x in D))
        cur, _, _ = _ratio(D)
        for _ in range(iters):
            if time.time() > deadline:
                break
            cand = D[:]
            mv = random.randrange(5)
            if mv == 0 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.choice([-3, -2, -1, 1, 2, 3])
            elif mv == 1:
                cand.append(random.randrange(0, max(cand) + 6 if cand else 6))
            elif mv == 2 and len(cand) > 2:
                cand.pop(random.randrange(len(cand)))
            elif mv == 3 and cand:
                cand.append(cand[-1] + random.choice([1, 2, 3, 5]))
            else:
                if len(cand) >= 2:
                    i = random.randrange(len(cand))
                    cand[i] += random.choice([-5, -4, 4, 5, 8])
            cand = sorted(set(int(x) for x in cand))
            if len(cand) < 2 or len(cand) > 80:
                continue
            lo = min(cand)
            cand = [x - lo for x in cand]
            r, _, _ = _ratio(cand)
            if r > cur:
                cur, D = r, cand
        return D, cur

    random.seed(987654321)
    np.random.seed(987654321)

    seeds = [list(d) for d in candidates] + [
        [0, 1, 3, 7, 12, 20],
        [0, 2, 5, 9, 14, 20, 27],
        [0, 1, 2, 4, 8, 16],
    ]
    deadline = start + TIME_LIMIT * 0.55
    for s in seeds:
        if time.time() > deadline:
            break
        D, r = climb(s, 4000, deadline)
        if r > best_r:
            best_r, best_D = r, D[:]

    best_D = sorted(set(int(x) for x in best_D))
    if len(best_D) < 2:
        best_D = [0, 1]

    # ---------- expand into base-B numbers, maximize |A| ----------
    n = len(best_D)
    dmax = max(abs(x) for x in best_D)
    B = 2 * dmax + 1  # strictly no carries for differences; safe for sums too

    # choose m so that n^m <= 4000 and B^m - 1 <= 1e15
    best_m = 1
    m = 1
    while n ** (m + 1) <= 4000:
        m += 1
    best_m = m
    while best_m >= 1 and (B ** best_m) > 10**15:
        best_m -= 1
    if best_m < 1:
        best_m = 1

    # If B^m too large, try a slightly smaller base still > dmax range
    # (B must make sum-digits collide exactly as in D; choose exactly dmax+1
    #  scaled so both diffs and sums are carry-free).
    B = dmax + 1
    while best_m >= 1 and (B ** best_m) > 10**15:
        best_m -= 1
    if best_m < 1:
        best_m = 1

    A = _expand(best_D, best_m, B)
    A = sorted(set(int(x) for x in A))

    lim = 10**15
    A = [x for x in A if abs(x) <= lim]
    if len(A) > 4000:
        A = A[:4000]
    if not A:
        A = [0, 1]
    return A
# EVOLVE-BLOCK-END
