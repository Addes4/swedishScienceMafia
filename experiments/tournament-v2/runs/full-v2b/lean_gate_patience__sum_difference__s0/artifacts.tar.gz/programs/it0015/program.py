# EVOLVE-BLOCK-START
"""Mixed-level digit-set construction: A = {sum d_i B^i} where each level uses a
digit set D_i.  With B large enough, |A+A| = prod |D_i+D_i| and
|A-A| = prod |D_i-D_i|, so we can pick per-level sets to optimize the product
ratio.  We search small digit sets, then assemble multi-level towers."""
import math
import time
import itertools
import numpy as np


def _counts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    return diffs, sums


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return -1.0
    diffs, sums = _counts(a)
    if sums < 2 or diffs < 2:
        return -1.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _digit_stats(D):
    D = list(D)
    dd = set()
    ss = set()
    for x in D:
        for y in D:
            dd.add(x - y)
            ss.add(x + y)
    return len(dd), len(ss)


def _search_digit_sets(deadline):
    """Collect good digit sets with their (ndd, nss)."""
    cands = []
    seen = set()

    def consider(D):
        key = tuple(sorted(D))
        if key in seen:
            return
        seen.add(key)
        ndd, nss = _digit_stats(D)
        if nss < 2 or ndd < 2:
            return
        ratio = math.log(ndd) / math.log(nss)
        cands.append((ratio, list(key), ndd, nss))

    universe = list(range(11))
    for sz in range(2, 6):
        if time.time() > deadline:
            break
        for comb in itertools.combinations(universe, sz):
            consider(comb)

    # Beam expansion to larger sizes
    cands.sort(reverse=True, key=lambda t: t[0])
    beam = [t[1] for t in cands[:150]]
    for sz in range(6, 9):
        if time.time() > deadline:
            break
        for D in beam:
            mx = max(D)
            for v in range(0, mx + 4):
                if v in D:
                    continue
                consider(D + [v])
        cands.sort(reverse=True, key=lambda t: t[0])
        beam = [t[1] for t in cands[:150]]
        if not beam:
            break
    cands.sort(reverse=True, key=lambda t: t[0])
    return cands


def _build_multilevel(levels, B):
    """levels: list of digit sets (each a list). Build A by iterated digit
    expansion in base B.  Returns numpy array."""
    A = [0]
    pw = 1
    for D in levels:
        newA = []
        for a in A:
            for d in D:
                newA.append(a + d * pw)
        A = newA
        pw *= B
    return np.array(sorted(set(A)), dtype=np.int64)


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    candidates = _search_digit_sets(deadline)

    # Filter to strong candidates.  Keep a diverse pool that includes
    # high-ratio sets of various sizes (some have better |D-D| absolute).
    top = candidates[:600]

    # --- Single-digit-set towers ---
    for (ratio, D, ndd, nss) in top:
        if time.time() > deadline:
            break
        m = len(D)
        if m < 2:
            continue
        maxn = 1
        while m ** (maxn + 1) <= 4000:
            maxn += 1
        if maxn < 1:
            continue
        span = max(D) - min(D)
        B = max(2 * span + 1, 2)
        for n in range(1, maxn + 1):
            if time.time() > deadline:
                break
            A = _build_multilevel([D] * n, B)
            if np.max(np.abs(A)) > 10**15:
                break
            sc = _score(A)
            if sc > best_score:
                best_score = sc
                best = A.tolist()

    # --- Mixed-level towers: pick the best digit set at each level to
    # maximize log(prod ndd)/log(prod nss) with a bonus term.  Because sums
    # and diffs multiply, we want a set with small |D+D| and large |D-D|.
    # Greedily combine: sort by ratio, and try towers mixing the very best
    # small-sum sets with larger high-diff sets.
    if time.time() < deadline:
        # Candidate sets for each level: best ratio sets of small sizes plus
        # a few with minimal sums.
        pool = [c for c in top if 2 <= len(c[1]) <= 8]
        # unique by (ndd, nss) preferring smallest representative
        pool.sort(key=lambda t: (-t[0], len(t[1])))
        pool = pool[:120]

        best_towers = []
        # Beam over sequences of levels.
        # state: (log-prod-ndd, log-prod-nss, size_prod, levels, B)
        beam = [(0.0, 0.0, 1, [], 2)]
        for depth in range(1, 12):
            if time.time() > deadline:
                break
            new_beam = []
            for (lndd, lnss, sprod, levels, B) in beam:
                for (ratio, D, ndd, nss) in pool:
                    nsp = sprod * len(D)
                    if nsp > 4000:
                        continue
                    nlndd = lndd + math.log(ndd)
                    nlnss = lnss + math.log(nss)
                    new_beam.append((nlndd, nlnss, nsp, levels + [D], B))
            if not new_beam:
                break
            # score towers by ratio + bonus (bonus based on size sprod)
            def tower_key(st):
                lndd, lnss, sprod, levels, B = st
                if lnss <= 0:
                    return -1e9
                r = lndd / lnss
                bonus = (1 - 1 / max(sprod, 1)) / 100
                return r + bonus
            new_beam.sort(key=tower_key, reverse=True)
            beam = new_beam[:60]
            # evaluate a few of the top towers exactly
            for st in beam[:15]:
                if time.time() > deadline:
                    break
                lndd, lnss, sprod, levels, B = st
                span = max(max(D) - min(D) for D in levels)
                Bv = max(2 * span + 1, 2)
                try:
                    A = _build_multilevel(levels, Bv)
                except Exception:
                    continue
                if A.size == 0 or np.max(np.abs(A)) > 10**15:
                    continue
                sc = _score(A)
                if sc > best_score:
                    best_score = sc
                    best = A.tolist()

    # Boundary refinement on the best construction.
    if best is not None:
        a = sorted(set(int(x) for x in best))
        improved = True
        rounds = 0
        while improved and rounds < 40 and time.time() < deadline:
            improved = False
            rounds += 1
            base_arr = np.array(a, dtype=np.int64)
            cand_adds = []
            lo, hi = a[0], a[-1]
            cand_adds.append(hi + 1)
            cand_adds.append(lo - 1)
            diffs = np.diff(base_arr)
            if diffs.size:
                gi = int(np.argmax(diffs))
                cand_adds.append(int(a[gi]) + int(diffs[gi]) // 2)
            for c in cand_adds:
                if len(a) >= 4000:
                    break
                trial = np.array(sorted(set(a + [c])), dtype=np.int64)
                sc = _score(trial)
                if sc > best_score:
                    best_score = sc
                    a = trial.tolist()
                    improved = True
                    break
            if improved:
                continue
            for idx in (0, len(a) - 1):
                if len(a) <= 2:
                    break
                trial_list = a[:idx] + a[idx + 1:]
                trial = np.array(trial_list, dtype=np.int64)
                sc = _score(trial)
                if sc > best_score:
                    best_score = sc
                    a = trial_list
                    improved = True
                    break
        best = a

    if best is None:
        best = [0, 1]
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
