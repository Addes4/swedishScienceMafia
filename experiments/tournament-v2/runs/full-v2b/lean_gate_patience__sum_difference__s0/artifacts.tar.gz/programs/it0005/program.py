# EVOLVE-BLOCK-START
"""Structured construction + fast local search for many differences / few sums."""
import math
import random
import time


def _setsize(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return None
    sums = len({a[i] + a[j] for i in range(n) for j in range(i, n)})
    diffs = len({a[i] - a[j] for i in range(n) for j in range(n)})
    return diffs, sums, n


def _score(a):
    r = _setsize(a)
    if r is None:
        return 0.0
    diffs, sums, n = r
    if sums <= 1:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _fast_score(a):
    """Score using sorted arrays; a is a list of distinct ints."""
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    # sums: use set of i<=j
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    if len(sums) <= 1:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _seed():
    """Cantor-like digit set in base 3, scaled up. Produces many diffs, few sums."""
    # Digit set in base B chosen so that few-sum / many-diff holds.
    # Use {0,1} in base 3 -> Cantor-like; scale by large M to spread.
    digits = [0, 1]
    base = 3
    A = [0]
    for _ in range(6):
        A = [x * base + d for x in A for d in digits]
    M = 10 ** 11
    return [M * x for x in A]


def solve():
    best = _seed()
    best = list(set(best))
    bs = _fast_score(best)
    cur = best[:]
    deadline = time.time() + 100
    step = 1
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.55:
            # perturb an element by a multiple of a scale
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.choice([1, 3, 9, 27, 81]) * 10 ** random.randint(0, 10)
        elif op < 0.8 and len(cand) < 400:
            cand.append(cand[random.randrange(len(cand))] + random.choice([-1, 1]) * random.choice([1, 3, 9, 27]) * 10 ** random.randint(0, 9))
        elif len(cand) > 4:
            i = random.randrange(len(cand))
            cand.pop(i)
        cand = list(set(cand))
        if len(cand) < 3:
            continue
        s = _fast_score(cand)
        if s >= bs:
            best, bs, cur = cand[:], s, cand
        elif random.random() < 0.15:
            cur = best[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END
