# EVOLVE-BLOCK-START
"""Deterministic multi-cluster (union of arithmetic progressions) construction with hill-climbing."""
import math
import time
import numpy as np


def _counts(A):
    """Exact |A-A| and |A+A| via numpy."""
    a = np.array(sorted(set(A)), dtype=np.int64)
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    return len(diffs), len(sums)


def _score_counts(nd, ns, n):
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _score(A):
    nd, ns = _counts(A)
    return _score_counts(nd, ns, len(set(A)))


def _build(clusters, offset):
    """clusters: list of (start, step, length). offset: global shift."""
    A = []
    for (s, step, ln) in clusters:
        for k in range(ln):
            A.append(offset + s + k * step)
    return sorted(set(A))


def solve():
    """A = union of arithmetic progressions; refine offsets/gaps by hill-climbing."""
    deadline = time.time() + 110.0

    # Candidate cluster structures: each is a list of (start, step, length).
    # Idea: within a cluster, differences are distinct (step large enough);
    # across clusters, sums collide by aligning cluster starts around a common midpoint.
    seeds = []

    # Seed family: ncl clusters, each of length L, steps chosen so intra-cluster
    # differences are dense-ish but structure gives sum collisions.
    for ncl in (2, 3, 4, 5, 6, 8):
        for L in (8, 12, 16, 20, 25, 30):
            if ncl * L > 3500:
                continue
            # gaps grow so that cross sums overlap
            clusters = []
            base = 0
            gap = 1
            for c in range(ncl):
                clusters.append((base, 1 << (c + 1), L))
                base += gap
                gap += 1
            seeds.append(clusters)

    # Simpler seeds: arithmetic-progression clusters with step = L+1 (so intra diffs
    # are multiples of step) and consecutive starts -> sums nearly collide.
    for ncl in (2, 3, 4, 5, 6, 8, 10):
        for L in (10, 16, 20, 30, 40, 60):
            if ncl * L > 3500 or ncl * L < 4:
                continue
            clusters = []
            s = 0
            for c in range(ncl):
                clusters.append((s, L + 1, L))
                s += L  # starts packed together
            seeds.append(clusters)

    # A "symmetric-ish" seed: clusters near 0 with varied starts.
    for ncl in (3, 4, 5, 6):
        for L in (15, 20, 25, 30):
            if ncl * L > 3500:
                continue
            clusters = [((c - ncl // 2) * L, L + 1, L) for c in range(ncl)]
            seeds.append(clusters)

    best_A = [0, 1]
    best_score = _score(best_A)

    for seed in seeds:
        if time.time() > deadline:
            break
        clusters = [list(t) for t in seed]
        current = _build(clusters, 0)
        cur_score = _score(current)
        if cur_score > best_score:
            best_A, best_score = current[:], cur_score

        # Hill-climb on offsets and steps of each cluster.
        improved = True
        while improved and time.time() < deadline:
            improved = False
            for ci in range(len(clusters)):
                for param in (0, 1):  # 0: start, 1: step
                    base_val = clusters[ci][param]
                    for delta in (1, -1, 2, -2, 3, -3, 5, -5, 8, -8,
                                  13, -13, 21, -21, 34, -34):
                        trial = [list(t) for t in clusters]
                        nv = base_val + delta
                        if param == 1 and nv <= clusters[ci][2]:
                            continue  # step must exceed length to keep diffs distinct-ish
                        if param == 1 and nv < 2:
                            continue
                        trial[ci][param] = nv
                        A = _build(trial, 0)
                        n = len(set(A))
                        if n < 3 or n > 4000:
                            continue
                        nd, ns = _counts(A)
                        s = _score_counts(nd, ns, n)
                        if s > cur_score + 1e-12:
                            clusters = trial
                            cur_score = s
                            improved = True
                            current = A
                            if s > best_score:
                                best_A, best_score = A[:], s
                    if time.time() > deadline:
                        break
                if time.time() > deadline:
                    break

    # Global shift does not change scores; normalize.
    best_A = sorted(set(best_A))
    if len(best_A) < 2:
        best_A = [0, 1]
    return best_A
# EVOLVE-BLOCK-END
