# EVOLVE-BLOCK-START
"""Construction: union of a dense arithmetic progression (heavy sum collisions)
with shifted/scaled copies whose offsets are chosen to keep |A-A| large.
Refined by hill-climbing with an exact numpy scorer."""
import math
import time
import random
import numpy as np


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n == 0:
        return 0, 0
    diffs = (a[:, None] - a[None, :]).ravel()
    sums = (a[:, None] + a[None, :]).ravel()
    nd = np.unique(diffs).size
    ns = np.unique(sums).size
    return nd, ns


def _score_from_counts(nd, ns, n):
    if n < 2 or ns <= 1:
        return -1e9
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return -1e9
    nd, ns = _counts(a)
    return _score_from_counts(nd, ns, n)


def _make_A(gap, offsets, lengths):
    A = set()
    for off, L in zip(offsets, lengths):
        for t in range(L):
            A.add(off + t * gap)
    return sorted(A)


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 110

    # Base: one long arithmetic progression creates a small-sum "floor" since
    # A+A of an AP with step g is itself mostly an AP with step g.
    # Add shifted copies placed far apart so differences stay distinct.
    n_copies = 14
    base_len = 40
    gap = 1

    lengths = np.array([base_len] + [rng.randint(3, 12) for _ in range(n_copies - 1)],
                       dtype=np.int64)
    offsets = np.zeros(n_copies, dtype=np.int64)
    spread = 0
    for i in range(1, n_copies):
        spread += rng.randint(30, 160)
        offsets[i] = spread

    def build(lengths, offsets, gap):
        return _make_A(gap, offsets.tolist(), lengths.tolist())

    cur_len = lengths.copy()
    cur_off = offsets.copy()
    cur_gap = gap
    A = build(cur_len, cur_off, cur_gap)
    nd, ns = _counts(A)
    best_A = A
    best_score = _score_from_counts(nd, ns, len(A))
    cur_score = best_score

    step_sizes = [1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144]

    while time.time() < deadline:
        nl = cur_len.copy()
        no = cur_off.copy()
        ng = cur_gap
        r = rng.random()

        if r < 0.50:
            i = rng.randrange(n_copies)
            no[i] += rng.choice([-1, 1]) * rng.choice(step_sizes)
        elif r < 0.75:
            i = rng.randrange(n_copies)
            no[i] += rng.choice([-1, 1]) * rng.randint(100, 600)
        elif r < 0.90:
            i = rng.randrange(n_copies)
            nl[i] = int(max(2, min(90, nl[i] + rng.choice([-3, -2, -1, 1, 2, 3]))))
        else:
            ng = int(max(1, min(6, cur_gap + rng.choice([-1, 1]))))

        newA = build(nl, no, ng)
        nd2, ns2 = _counts(newA)
        s = _score_from_counts(nd2, ns2, len(newA))
        if s >= cur_score:
            cur_len, cur_off, cur_gap = nl, no, ng
            cur_score = s
            if s > best_score:
                best_score = s
                best_A = newA

    res = sorted(set(best_A))

    # Polish: try to drop elements that do not hurt (or help) the ratio.
    improved = True
    cur_nd, cur_ns = _counts(res)
    cur_s = _score_from_counts(cur_nd, cur_ns, len(res))
    while improved and time.time() < deadline:
        improved = False
        order = list(range(len(res)))
        rng.shuffle(order)
        for i in order:
            cand = res[:i] + res[i + 1:]
            if len(cand) < 2:
                continue
            nd2, ns2 = _counts(cand)
            s = _score_from_counts(nd2, ns2, len(cand))
            if s >= cur_s:
                res = cand
                cur_s = s
                improved = True
                break

    return res
# EVOLVE-BLOCK-END
