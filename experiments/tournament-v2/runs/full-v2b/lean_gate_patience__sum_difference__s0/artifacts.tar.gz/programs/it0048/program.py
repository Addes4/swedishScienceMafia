# EVOLVE-BLOCK-START
"""Union-of-translates construction: A = C + T with fast set-based scoring."""
import math
import time


def _score_counts(nd, ns, n):
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _counts(A):
    """Exact |A-A|, |A+A| using Python sets (fast for moderate n)."""
    s = set(A)
    diffs = set()
    sums = set()
    L = list(s)
    for i in range(len(L)):
        ai = L[i]
        for j in range(len(L)):
            bj = L[j]
            diffs.add(ai - bj)
            sums.add(ai + bj)
    return len(diffs), len(sums)


def _build(C, T):
    A = set()
    for t in T:
        for c in C:
            A.add(c + t)
    return A


def _eval(A):
    n = len(A)
    if n < 3:
        return 0.0, 0, 0
    nd, ns = _counts(A)
    return _score_counts(nd, ns, n), nd, ns


def solve():
    deadline = time.time() + 100.0

    best_A = [0, 1]
    best_score = 0.0

    # Cluster C: dense arithmetic progression / Sidon-like base.
    # T: small translate set. Goal: small |A+A|, large |A-A|.
    cluster_seeds = []
    for L in (6, 8, 10, 12, 15, 20, 25, 30, 40, 50):
        cluster_seeds.append(list(range(L)))                 # dense interval
        cluster_seeds.append([2 * k for k in range(L)])      # even spacing
        cluster_seeds.append([k * k for k in range(L)])      # squared cluster

    # Translate-set seeds (offsets spread widely so cross differences stay distinct,
    # but cross sums overlap heavily).
    T_seeds = []
    for m in (2, 3, 4, 5, 6, 8):
        # spread translates far apart relative to cluster diameter
        T_seeds.append([k * 1000 for k in range(m)])
        T_seeds.append([k * 100000 for k in range(m)])
        T_seeds.append([(2 ** k) for k in range(m)])

    def try_set(A):
        nonlocal best_A, best_score
        A = set(A)
        if len(A) < 3 or len(A) > 4000:
            return
        s, nd, ns = _eval(A)
        if s > best_score:
            best_score = s
            best_A = sorted(A)

    # Phase 1: evaluate seeds.
    for C in cluster_seeds:
        for T in T_seeds:
            if time.time() > deadline:
                break
            try_set(_build(C, T))
        if time.time() > deadline:
            break

    # Phase 2: local search on T offsets (shift / scale) given best C.
    if best_A:
        # Reconstruct approx C, T from best via simple heuristic: try to improve by
        # hill-climbing translate offsets on the winning structure.
        pass

    # Phase 3: direct hill-climb on the translate set with a fixed good cluster.
    for C in ([list(range(12)), list(range(20)), [2 * k for k in range(20)]]):
        if time.time() > deadline:
            break
        for m in (3, 4, 5, 6):
            if time.time() > deadline:
                break
            T = [k * 100000 for k in range(m)]
            cur = _build(C, T)
            cur_score, _, _ = _eval(cur)
            improved = True
            while improved and time.time() < deadline:
                improved = False
                for ti in range(m):
                    for delta in (1000, -1000, 10000, -10000, 100000, -100000,
                                  500000, -500000, 1, -1, 7, -7):
                        trial = T[:]
                        trial[ti] += delta
                        A = _build(C, trial)
                        if len(A) < 3 or len(A) > 4000:
                            continue
                        s, _, _ = _eval(A)
                        if s > cur_score + 1e-12:
                            T = trial
                            cur_score = s
                            cur = A
                            improved = True
                            if s > best_score:
                                best_score = s
                                best_A = sorted(A)
                    if time.time() > deadline:
                        break
                if time.time() > deadline:
                    break

    # Phase 4: cheap single-element polish (add/remove) on best set.
    if best_A and time.time() < deadline:
        A = set(best_A)
        cur_score, _, _ = _eval(A)
        improved = True
        while improved and time.time() < deadline:
            improved = False
            L = sorted(A)
            # try removals
            for x in L:
                if time.time() > deadline:
                    break
                trial = set(A)
                trial.discard(x)
                if len(trial) < 3 or len(trial) > 4000:
                    continue
                s, _, _ = _eval(trial)
                if s > cur_score + 1e-12:
                    A = trial
                    cur_score = s
                    improved = True
                    break
            if improved:
                continue
            # try additions near existing elements
            span = max(A) - min(A) if A else 0
            cand = set()
            lo, hi = min(A), max(A)
            for x in L:
                for d in (1, -1, 2, -2, 3, -3):
                    cand.add(x + d)
            cand.add(lo - 1)
            cand.add(hi + 1)
            for x in cand:
                if time.time() > deadline:
                    break
                if x in A:
                    continue
                trial = set(A)
                trial.add(x)
                if len(trial) > 4000:
                    continue
                s, _, _ = _eval(trial)
                if s > cur_score + 1e-12:
                    A = trial
                    cur_score = s
                    improved = True
                    break
        if cur_score > best_score:
            best_score = cur_score
            best_A = sorted(A)

    best_A = sorted(set(best_A))
    if len(best_A) < 2:
        best_A = [0, 1]
    return best_A
# EVOLVE-BLOCK-END
