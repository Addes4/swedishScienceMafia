# EVOLVE-BLOCK-START
"""Digit-set power construction: A = sums of d_i * B^i with small digit set D."""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    nd, ns = len(diffs), len(sums)
    if ns < 2:
        return 0.0, nd, ns
    sc = math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100
    return sc, nd, ns


def _pow_construct(D, n, B):
    """A = { sum_{i=0}^{n-1} d_i B^i : d_i in D } (all n-digit combos)."""
    A = [0]
    for i in range(n):
        p = B ** i
        A = [x + d * p for x in A for d in D]
    return A


def _score(a):
    sc, _, _ = _stats(a)
    return sc


def _score_fast(a):
    """Fast score exploiting structure: compute via difference/sum set sizes."""
    # general correct path but with sorted sets to reduce overhead
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    nd, ns = len(diffs), len(sums)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 90

    # Candidate digit sets D with good |D-D| vs |D+D|.
    digit_sets = [
        (0, 1, 3),
        (0, 1, 4),
        (0, 1, 3, 4),
        (0, 1, 3, 7),
        (0, 1, 4, 6),
        (0, 1, 3, 4, 9),
        (0, 1, 4, 9),
        (0, 1, 3, 7, 12),
        (0, 1, 2, 4, 8),
        (0, 1, 3, 9),
        (0, 1, 4, 5, 9),
    ]

    candidates = []
    for D in digit_sets:
        m = len(D)
        # theoretical: |A+A| = |D+D|^n, |A-A| = |D-D|^n for large base B
        DD = len({a - b for a in D for b in D})
        DS = len({a + b for a in D for b in D})
        if DS < 2 or DD < 2:
            continue
        ratio = math.log(DD) / math.log(DS)
        # choose n so that m^n <= 4000 and B large enough
        maxn = int(math.floor(math.log(4000) / math.log(m)))
        if maxn < 1:
            maxn = 1
        candidates.append((ratio, D, maxn, DD, DS))

    candidates.sort(reverse=True)

    for ratio, D, maxn, DD, DS in candidates:
        if time.time() > deadline:
            break
        for n in range(maxn, 0, -1):
            if time.time() > deadline:
                break
            B = 1000  # large base so digit expansions don't overlap
            A = _pow_construct(D, n, B)
            if len(A) > 4000:
                continue
            sc = _score_fast(A)
            # estimate score from theory (perfect separation): log(DD^n)/log(DS^n)
            theo = ratio + (1 - 1.0 / len(A)) / 100
            if sc > best_score:
                best_score = sc
                best = A[:]
            # try local tweaks: adjust the largest base cluster
            cur, cur_sc = A, sc
            local_end = min(deadline, time.time() + 8)
            while time.time() < local_end:
                r = random.random()
                x = cur[:]
                if r < 0.5 and len(x) < 4000:
                    # add a nearby element
                    base_el = random.choice(x)
                    x.append(base_el + random.randint(-5, 5))
                elif r < 0.8 and len(x) > 2:
                    # remove a random element
                    i = random.randrange(len(x))
                    x.pop(i)
                else:
                    # perturb one element slightly
                    i = random.randrange(len(x))
                    x[i] += random.randint(-3, 3)
                x = list(set(x))
                if len(x) > 4000 or len(x) < 2:
                    continue
                ns = _score_fast(x)
                if ns > cur_sc:
                    cur, cur_sc = x, ns
                    if ns > best_score:
                        best_score = ns
                        best = x[:]

    if best is None:
        best = [0, 1, 3, 9, 27, 81]

    A = sorted(set(best))
    A = [x for x in A if abs(x) <= 10**15][:4000]
    return A
# EVOLVE-BLOCK-END
