# EVOLVE-BLOCK-START
"""Mixed-radix digit construction."""
import math
import time
import itertools
import numpy as np


def _counts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    return diffs, sums


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return -1.0
    diffs, sums = _counts(a)
    if sums < 2 or diffs < 2:
        return -1.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _digit_stats(D):
    D = list(D)
    dd = set()
    ss = set()
    for x in D:
        for y in D:
            dd.add(x - y)
            ss.add(x + y)
    return len(dd), len(ss)


def _search_digit_sets(deadline):
    cands = []
    seen = set()

    def consider(D):
        key = tuple(sorted(D))
        if key in seen:
            return
        seen.add(key)
        ndd, nss = _digit_stats(D)
        if nss < 2 or ndd < 2:
            return
        ldd = math.log(ndd)
        lss = math.log(nss)
        cands.append((ldd / lss, ldd, lss, len(key), list(key)))

    universe = list(range(13))
    for sz in range(2, 6):
        if time.time() > deadline:
            break
        for comb in itertools.combinations(universe, sz):
            consider(comb)

    cands.sort(reverse=True, key=lambda t: t[0])
    beam = [t[4] for t in cands[:300]]
    for sz in range(6, 10):
        if time.time() > deadline:
            break
        for D in beam:
            mx = max(D)
            for v in range(0, mx + 5):
                if v in D:
                    continue
                consider(D + [v])
        cands.sort(reverse=True, key=lambda t: t[0])
        beam = [t[4] for t in cands[:300]]
        if not beam:
            break

    # Additional beam that maximizes raw ldd - a*lss (Bohr-style/sum-poor sets).
    best_ldd = []
    def raw_consider(D):
        key = tuple(sorted(D))
        ndd, nss = _digit_stats(D)
        if nss < 2 or ndd < 2:
            return
        ldd = math.log(ndd); lss = math.log(nss)
        # score rewarding difference growth more aggressively
        raw_consider.val = ldd - 0.45 * lss
        best_ldd.append((raw_consider.val, ldd, lss, len(key), list(key)))
    raw_consider.val = 0.0

    uni2 = list(range(16))
    for sz in range(2, 6):
        if time.time() > deadline:
            break
        for comb in itertools.combinations(uni2, sz):
            raw_consider(comb)
    best_ldd.sort(reverse=True, key=lambda t: t[0])
    beam2 = [t[4] for t in best_ldd[:200]]
    for sz in range(6, 11):
        if time.time() > deadline:
            break
        cur = []
        for D in beam2:
            mx = max(D)
            for v in range(0, mx + 4):
                if v in D:
                    continue
                raw_consider(D + [v])
        best_ldd.sort(reverse=True, key=lambda t: t[0])
        # dedup
        nb = []
        seenk = set()
        for t in best_ldd:
            k = tuple(t[4])
            if k in seenk:
                continue
            seenk.add(k)
            nb.append(t)
            if len(nb) >= 200:
                break
        beam2 = [t[4] for t in nb]
        if not beam2:
            break
    for (_, ldd, lss, sz, D) in best_ldd[:400]:
        cands.append((ldd / lss, ldd, lss, sz, D))

    # dedup cands
    dd = {}
    for c in cands:
        k = tuple(c[4])
        if k not in dd or c[1] / max(c[2], 1e-9) > dd[k][1] / max(dd[k][2], 1e-9):
            dd[k] = c
    out = list(dd.values())
    out.sort(reverse=True, key=lambda t: t[0])
    return out


def _build_mixed(levels, B):
    A = [0]
    pw = 1
    for D in levels:
        newA = []
        for a in A:
            for d in D:
                newA.append(a + d * pw)
        A = newA
        pw *= B
    return np.array(sorted(set(A)), dtype=np.int64)


def _span(D):
    return max(D) - min(D)


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    dig = _search_digit_sets(deadline)
    if not dig:
        return [0, 1]

    sets = [(ldd / lss, ldd, lss, len(D), D) for (r, ldd, lss, sz, D) in dig]
    # pool: best ratio, plus good raw ldd, plus good raw (ldd - .45 lss)
    pool = list(sets[:400])
    for s in sorted(sets, key=lambda t: t[1], reverse=True)[:150]:
        pool.append(s)
    for s in sorted(sets, key=lambda t: t[1] - 0.45 * t[2], reverse=True)[:150]:
        pool.append(s)
    # dedup pool
    pd = {}
    for s in pool:
        k = tuple(s[4])
        pd[k] = s
    pool = list(pd.values())
    # sort pool by ratio for greedy
    pool_by_ratio = sorted(pool, key=lambda t: t[0], reverse=True)

    def build_and_score(levels):
        if not levels:
            return None, -1.0
        span = max(_span(D) for D in levels)
        B = max(2 * span + 1, 2)
        # shrink levels if too big
        lv = list(levels)
        while lv:
            A = _build_mixed(lv, B)
            if A.size < 2:
                lv.pop()
                continue
            if np.max(np.abs(A)) <= 10**15 and A.size <= 4000:
                return A, _score(A)
            lv.pop()
            if lv:
                span = max(_span(D) for D in lv)
                B = max(2 * span + 1, 2)
        return None, -1.0

    # Beam search over level sequences maximizing cumulative sum(ldd)/sum(lss)
    # each state: (cum_ldd, cum_lss, size, levels)
    seeds = [s for s in sets[:40]]
    beam_states = []
    for (r, ldd, lss, sz, D) in seeds:
        beam_states.append((ldd, lss, sz, [D]))

    def cum_ratio(st):
        return st[0] / st[1]

    beam_states.sort(key=cum_ratio, reverse=True)
    best_levels = None
    best_ratio = -1.0

    B_cand = pool_by_ratio  # candidates to append
    max_states = 200
    for step in range(30):
        if time.time() > deadline:
            break
        newstates = []
        for (cldd, clss, size, levels) in beam_states:
            # candidate append levels
            added = 0
            for (r, ldd, lss, sz, D) in B_cand:
                if size * sz > 4000:
                    continue
                nl = cldd + ldd
                ns = clss + lss
                newstates.append((nl, ns, size * sz, levels + [D]))
                added += 1
                if added >= 60:
                    break
            # also try stopping (record this state)
        if not newstates:
            break
        newstates.sort(key=cum_ratio, reverse=True)
        # dedup by ratio+size
        beam_states = newstates[:max_states]
        # evaluate each state by actual score occasionally
        for st in beam_states[:20]:
            r = cum_ratio(st)
            if r > best_ratio:
                best_ratio = r
                best_levels = st[3]

    # Evaluate candidate level sequences with actual scoring.
    cand_level_seqs = []
    if best_levels:
        cand_level_seqs.append(best_levels)
    for st in beam_states[:300]:
        cand_level_seqs.append(st[3])

    # also greedy cumulative per seed
    for (seed_r, seed_ldd, seed_lss, seed_sz, seed_D) in sets[:60]:
        cum_ldd = seed_ldd
        cum_lss = seed_lss
        size = seed_sz
        levels = [seed_D]
        while size <= 4000:
            best_gain = None
            for (r, ldd, lss, sz, D) in pool_by_ratio:
                if size * sz > 4000:
                    continue
                new_r = (cum_ldd + ldd) / (cum_lss + lss)
                if new_r > cum_ldd / cum_lss + 1e-12:
                    if best_gain is None or new_r > best_gain[0]:
                        best_gain = (new_r, ldd, lss, sz, D)
            if best_gain is None:
                break
            _, ldd, lss, sz, D = best_gain
            cum_ldd += ldd
            cum_lss += lss
            size *= sz
            levels.append(D)
            if time.time() > deadline:
                break
        cand_level_seqs.append(levels)

    for levels in cand_level_seqs:
        A, sc = build_and_score(levels)
        if A is not None and sc > best_score:
            best_score = sc
            best = A.tolist()
        if time.time() > deadline:
            break

    if best is None:
        best = [0, 1]

    # Final boundary refinement on the best construction.
    a = sorted(set(int(x) for x in best))
    improved = True
    rounds = 0
    while improved and rounds < 40 and time.time() < deadline:
        improved = False
        rounds += 1
        base_arr = np.array(a, dtype=np.int64)
        cand_adds = []
        lo, hi = a[0], a[-1]
        cand_adds.append(hi + 1)
        cand_adds.append(lo - 1)
        diffs = np.diff(base_arr)
        if diffs.size:
            gi = int(np.argmax(diffs))
            cand_adds.append(int(a[gi]) + int(diffs[gi]) // 2)
        for c in cand_adds:
            if len(a) >= 4000:
                break
            trial = np.array(sorted(set(a + [c])), dtype=np.int64)
            sc = _score(trial)
            if sc > best_score:
                best_score = sc
                a = trial.tolist()
                improved = True
                break
        if improved:
            continue
        for idx in (0, len(a) - 1):
            if len(a) <= 2:
                break
            trial_list = a[:idx] + a[idx + 1:]
            trial = np.array(trial_list, dtype=np.int64)
            sc = _score(trial)
            if sc > best_score:
                best_score = sc
                a = trial_list
                improved = True
                break

    return sorted(set(int(x) for x in a))
# EVOLVE-BLOCK-END
