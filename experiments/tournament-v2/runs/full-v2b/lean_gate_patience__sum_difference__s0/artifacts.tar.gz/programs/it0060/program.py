# EVOLVE-BLOCK-START
import math, time
import numpy as np

def _exact_counts(a):
    a = np.array(sorted(set(int(x) for x in a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0, 1
    sums = (a[:, None] + a[None, :]).ravel()
    difs = (a[:, None] - a[None, :]).ravel()
    return int(np.unique(difs).size), int(np.unique(sums).size)

def _score_counts(d, s, n):
    if n < 2 or s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0

def solve():
    t0 = time.time()
    deadline = t0 + 110.0
    best_A = [0, 1, 3, 9, 27]
    best_sc = _score_counts(*_exact_counts(best_A), len(best_A))

    def consider(A):
        nonlocal best_A, best_sc
        A = sorted(set(int(x) for x in A))
        if len(A) < 2:
            return
        d, s = _exact_counts(A)
        sc = _score_counts(d, s, len(A))
        if sc > best_sc:
            best_sc = sc
            best_A = A

    # Product construction A = B*P + Q  (P coords grand, Q fine) => A ~ P x Q-ish
    # Try many structured (P,Q) product sets and pick the best.
    def build(P, Q, B):
        return sorted(set(p * B + q for p in P for q in Q))

    Ps = []
    for m in (3, 4, 5, 6, 7):
        Ps.append(list(range(m)))
    Ps.append([0, 1, 3, 7, 12, 20])
    Ps.append([0, 1, 4, 10, 18, 27])
    Ps.append([0, 1, 3, 6, 10, 15])
    Ps.append([0, 1, 2, 4, 8, 16])

    Qs = []
    for m in (3, 4, 5, 7, 9, 11, 13):
        Qs.append(list(range(m)))
    Qs.append([0, 1, 3, 7, 12])
    Qs.append([0, 1, 3, 9, 11])
    Qs.append([0, 1, 2, 5, 9])

    for P in Ps:
        for Q in Qs:
            pspan = max(P) * len(Q)
            qspan = max(Q)
            if qspan >= pspan:
                continue
            B = pspan + 1
            consider(build(P, Q, B))
            if time.time() > deadline:
                return best_A

    # Shifted-cluster construction: A = union of translated tight clusters
    # clusters spaced so cross-sums collide.
    def clusters(offsets, clen, step):
        A = []
        for o in offsets:
            A.extend(o + step * k for k in range(clen))
        return A

    offset_sets = [
        [0, 1, 3, 7, 15],
        [0, 1, 4, 10, 20],
        [0, 2, 5, 11, 20],
        [0, 1, 3, 9, 27, 40],
        [0, 1, 5, 8, 15, 27],
        [0, 3, 7, 12, 24, 36],
    ]
    for offs in offset_sets:
        for clen in (2, 3, 4, 5):
            for step in (1, 2):
                consider(clusters(offs, clen, step))
            if time.time() > deadline:
                return best_A

    # Local search on best_A (single move + pair move)
    A = sorted(best_A)
    d, s = _exact_counts(A)
    cur = _score_counts(d, s, len(A))
    improved = True
    while improved and time.time() < deadline:
        improved = False
        rng = max(2, max(A) - min(A))
        for i in range(len(A)):
            for delta in (1, -1, 2, -2, 3, -3, 5, -5, rng // 2, -rng // 2):
                cand = A[:]
                cand[i] += delta
                cand = sorted(set(cand))
                if len(cand) < 2:
                    continue
                dd, ss = _exact_counts(cand)
                sc = _score_counts(dd, ss, len(cand))
                if sc > cur + 1e-12:
                    cur = sc
                    A = cand
                    d, s = dd, ss
                    improved = True
                    break
            if improved or time.time() > deadline:
                break
    if cur > best_sc:
        best_A = A

    return sorted(set(int(x) for x in best_A))
# EVOLVE-BLOCK-END
