# EVOLVE-BLOCK-START
"""Construction search: A = union of arithmetic progressions with shared gaps
(so A+A collapses via overlaps) while A-A stays large. Exact numpy scoring,
plus element-level polish."""
import math
import random
import time

import numpy as np


def _counts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0, n
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    return diffs.size, sums.size, n


def _score(a):
    d, s, n = _counts(a)
    if s < 2 or n < 2:
        return -1.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _build(clusters, rng):
    """clusters: list of (start, length, gap). Union them, dedupe."""
    allv = []
    for (st, ln, gp) in clusters:
        if ln <= 0:
            continue
        allv.append(np.arange(ln, dtype=np.int64) * gp + st)
    if not allv:
        return np.array([0, 1], dtype=np.int64)
    arr = np.unique(np.concatenate(allv))
    return arr


def _rand_clusters(rng, k):
    g = 1
    clusters = []
    cursor = 0
    for _ in range(k):
        gp = rng.choice([1, 1, 1, 2, 3, 4, g, g, 2 * g])
        ln = rng.randint(2, 9)
        st = cursor + rng.choice([0, 0, 0, gp, -gp])
        clusters.append((st, ln, gp))
        cursor = st + ln * gp + rng.choice([0, 1, gp, 2 * gp])
    return clusters


def solve():
    deadline = time.time() + 110
    rng = random.Random(1357911)

    best = None
    best_score = -1.0

    # Seed with simple structured starts.
    seeds = []
    seeds.append([(0, 16, 1)])
    seeds.append([(0, 8, 1), (40, 8, 4)])
    seeds.append([(0, 6, 1), (20, 6, 2), (60, 6, 3)])
    seeds.append([i * i for i in range(13)])
    seeds.append([i * (i + 1) // 2 for i in range(15)])

    for cl in seeds:
        arr = _build(cl, rng)
        s = _score(arr)
        if s > best_score:
            best_score = s
            best = arr.copy()

    # Random cluster population.
    pop = []
    for _ in range(60):
        k = rng.randint(2, 6)
        cl = _rand_clusters(rng, k)
        arr = _build(cl, rng)
        s = _score(arr)
        pop.append((s, cl))
        if s > best_score:
            best_score = s
            best = arr.copy()

    pop.sort(key=lambda t: -t[0])
    pop = pop[:20]
    cur_cl = pop[0][1]
    cur_score = pop[0][0]

    T0 = 0.03
    steps = 0
    t_start = time.time()
    while time.time() < deadline:
        steps += 1
        frac = (time.time() - t_start) / 110.0
        T = T0 * max(1e-6, 1.0 - frac)

        cl = [list(c) for c in cur_cl]
        mv = rng.random()
        if mv < 0.30 and len(cl) > 1:
            i = rng.randrange(len(cl))
            cl[i][0] += rng.randint(-8, 8)
        elif mv < 0.50 and len(cl) > 1:
            i = rng.randrange(len(cl))
            cl[i][1] = max(1, cl[i][1] + rng.choice([-2, -1, 1, 2]))
        elif mv < 0.70:
            i = rng.randrange(len(cl))
            cl[i][2] = max(1, cl[i][2] + rng.choice([-1, 1, -2, 2]))
        elif mv < 0.82 and len(cl) < 8:
            pos = rng.randrange(len(cl) + 1)
            g = cl[rng.randrange(len(cl))][2]
            cl.insert(pos, [rng.randint(-20, 80), rng.randint(2, 7), max(1, g)])
        elif mv < 0.92 and len(cl) > 2:
            del cl[rng.randrange(len(cl))]
        else:
            # crossover from population
            _, other = pop[rng.randrange(len(pop))]
            cl = [list(c) for c in other]
            i = rng.randrange(len(cl))
            cl[i][0] += rng.randint(-4, 4)

        cand = _build([tuple(c) for c in cl], rng)
        if cand.size < 6 or cand.size > 4000:
            continue
        s = _score(cand)
        if s >= cur_score or (T > 1e-9 and rng.random() < math.exp(min(50.0, (s - cur_score) / T))):
            cur_cl = [tuple(c) for c in cl]
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand.copy()
                pop.append((s, cur_cl))
                pop.sort(key=lambda t: -t[0])
                pop = pop[:20]

        # occasional polish: element-level single tweaks from best
        if steps % 1500 == 0 and best is not None:
            cur_cl = [tuple(c) for c in pop[rng.randrange(len(pop))][1]]
            cur_score = _score(_build(cur_cl, rng))

    # Element-level polish around best.
    cur = best.copy()
    cur_score = _score(cur)
    while time.time() < deadline:
        i = rng.randrange(cur.size)
        cand = cur.copy()
        cand[i] += rng.choice([-3, -2, -1, 1, 2, 3])
        cand = np.unique(cand)
        if cand.size < 6:
            continue
        s = _score(cand)
        if s > cur_score:
            cur = cand
            cur_score = s
        if s > best_score:
            best = cand.copy()
            best_score = s

    res = np.unique(best)
    return [int(x) for x in res]


# EVOLVE-BLOCK-END

