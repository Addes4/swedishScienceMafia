# EVOLVE-BLOCK-START
"""Deterministic multi-cluster construction with numpy-based hill-climbing.

Idea: build A as a union of arithmetic-progression clusters.
  - Within a cluster, differences are highly structured (small count relative to size),
    but clusters are shifted so that cross-cluster differences stay distinct -> large |A-A|.
  - Offsets are chosen to make sums collide a lot across clusters -> small |A+A|.

Then hill-climb over (offsets, gaps) using an exact numpy set-count scorer,
plus element-level substitution moves for a richer neighbourhood.
"""
import math
import random
import time

import numpy as np


def _score_np(a):
    """Exact score from array a (ints)."""
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0.0
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    if sums.size < 2:
        return 0.0
    return math.log(diffs.size) / math.log(sums.size) + (1 - 1 / n) / 100


class Builder:
    def __init__(self, n_clusters, sizes, gaps, offsets):
        self.n_clusters = n_clusters
        self.sizes = sizes
        self.gaps = list(gaps)
        self.offsets = list(offsets)

    def array(self):
        parts = []
        for k in range(self.n_clusters):
            off = self.offsets[k]
            g = self.gaps[k]
            sz = self.sizes[k]
            parts.append(off + g * np.arange(sz, dtype=np.int64))
        return np.concatenate(parts)


def solve():
    deadline = time.time() + 110

    # --- seed construction -------------------------------------------------
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score_np(best)

    rng = random.Random(12345)

    for trial in range(80):
        nc = rng.randint(3, 6)
        sizes = [rng.randint(4, 12) for _ in range(nc)]
        gaps = sorted(rng.sample(range(1, 40), nc))
        base = 0
        offsets = []
        for k in range(nc):
            offsets.append(base + rng.randint(-20, 20))
            base += gaps[k] * sizes[k]
        b = Builder(nc, sizes, gaps, offsets)
        A = b.array()
        s = _score_np(A)
        if s > best_score:
            best_score = s
            best = A.tolist()

    cur = np.array(sorted(set(best)), dtype=np.int64)
    cur_score = _score_np(cur)

    it = 0
    while time.time() < deadline and it < 400000:
        it += 1
        n = cur.size
        move = rng.random()
        cand = cur.copy()

        if move < 0.45:
            # shift a contiguous block (preserves gaps within block)
            i = rng.randrange(n)
            j = rng.randint(i + 1, n)
            delta = rng.randint(-4, 4)
            if delta == 0:
                continue
            cand[i:j] = cand[i:j] + delta
        elif move < 0.70:
            # perturb a single element
            i = rng.randrange(n)
            cand[i] += rng.randint(-3, 3)
        elif move < 0.85:
            # adjust one gap: move all elements after i
            i = rng.randrange(n)
            delta = rng.randint(-2, 2)
            cand[i:] = cand[i:] + delta
        elif move < 0.93 and n > 4:
            # remove one element (set can shrink)
            i = rng.randrange(n)
            cand = np.delete(cand, i)
        else:
            # add a new element near an existing one or at a fresh position
            i = rng.randrange(n)
            newv = int(cand[i]) + rng.randint(-6, 6)
            if np.any(cand == newv):
                continue
            cand = np.append(cand, newv)

        cand = np.unique(cand)
        if cand.size < 4 or cand.size > 4000:
            continue
        s = _score_np(cand)
        if s >= cur_score:
            cur = cand
            cur_score = s
        if it % 5000 == 0 and rng.random() < 0.3:
            cur = np.array(sorted(set(best)), dtype=np.int64)
            cur_score = _score_np(cur)

    result = np.unique(cur)
    if _score_np(result) >= best_score:
        return [int(x) for x in result]
    return [int(x) for x in np.unique(np.array(sorted(set(best)), dtype=np.int64))]


# EVOLVE-BLOCK-END
