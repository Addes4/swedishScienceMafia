# EVOLVE-BLOCK-START
"""Construction: mixed-radix digit sets.
A = { sum_i d_i * B^i : d_i in D } for a small digit set D and base B.
This collapses A+A heavily (carries / overlapping digit sums) while A-A
stays large, giving a high log|A-A|/log|A+A| ratio. Digit set and base are
refined by hill-climbing with an exact numpy scorer."""
import math
import time
import random
import numpy as np


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n == 0:
        return 0, 0
    diffs = (a[:, None] - a[None, :]).ravel()
    sums = (a[:, None] + a[None, :]).ravel()
    nd = np.unique(diffs).size
    ns = np.unique(sums).size
    return nd, ns


def _score_from_counts(nd, ns, n):
    if n < 2 or ns <= 1:
        return -1e9
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _build(digits, base, depth):
    """A = all sums of digits[i] * base^i for i in range(depth)."""
    vals = [0]
    for i in range(depth):
        p = base ** i
        newvals = []
        for v in vals:
            for d in digits[i]:
                newvals.append(v + d * p)
        vals = newvals
    return sorted(set(vals))


def solve():
    rng = random.Random(20240607)
    deadline = time.time() + 108

    # Start: symmetric digit sets around 0 in a moderate base.
    depth = 3
    base = 8
    digits = [
        [-1, 0, 1],
        [-1, 0, 1],
        [-1, 0, 1],
    ]

    def full_digits(digits, depth):
        d = [list(x) for x in digits[:depth]]
        while len(d) < depth:
            d.append([0])
        return d

    cur_digits = full_digits(digits, depth)
    cur_base = base
    cur_depth = depth

    A = _build(cur_digits, cur_base, cur_depth)
    nd, ns = _counts(A)
    best_A = A
    best_gene = (cur_digits, cur_base, cur_depth)
    best_score = _score_from_counts(nd, ns, len(A))
    cur_score = best_score

    cand_digits = [-8, -4, -3, -2, -1, 0, 1, 2, 3, 4, 8]

    while time.time() < deadline:
        nd_ = [list(x) for x in cur_digits]
        nb = cur_base
        ndp = cur_depth
        r = rng.random()

        if r < 0.55 and nd_:
            i = rng.randrange(len(nd_))
            d = nd_[i]
            if d and rng.random() < 0.4:
                d.pop(rng.randrange(len(d)))
            else:
                v = rng.choice(cand_digits)
                if v not in d:
                    d.append(v)
            nd_[i] = sorted(set(d))
        elif r < 0.80:
            nb = max(2, min(40, cur_base + rng.choice([-2, -1, 1, 2])))
        elif r < 0.92:
            ndp = max(1, min(5, cur_depth + rng.choice([-1, 1])))
            while len(nd_) < ndp:
                nd_.append([0])
        else:
            # rebalance: shrink a digit set
            i = rng.randrange(len(nd_))
            if len(nd_[i]) > 1:
                nd_[i] = nd_[i][: max(1, len(nd_[i]) - 1)]

        if not any(nd_):
            continue
        try:
            newA = _build(nd_, nb, ndp)
        except Exception:
            continue
        if len(newA) < 2:
            continue
        nd2, ns2 = _counts(newA)
        s = _score_from_counts(nd2, ns2, len(newA))
        if s >= cur_score:
            cur_digits = nd_
            cur_base = nb
            cur_depth = ndp
            cur_score = s
            if s > best_score:
                best_score = s
                best_A = newA
                best_gene = ([list(x) for x in nd_], nb, ndp)

    # ---- Phase 2: structured refinement around the best gene using
    # base-aligned candidate digits. ----
    bdig, bbase, bdepth = best_gene

    def try_gene(g, cache=[None, -1e9]):
        try:
            cand = _build(g[0], g[1], g[2])
        except Exception:
            return None, -1e9
        if len(cand) < 2:
            return None, -1e9
        nd2, ns2 = _counts(cand)
        s = _score_from_counts(nd2, ns2, len(cand))
        return cand, s

    # candidate alphabet: base-aligned and general
    C = bbase
    base_aligned = sorted(set([-C - 1, -C, -C + 1, -1, 0, 1, C - 1, C, C + 1, 2 * C, -2 * C]))

    improved = True
    while improved and time.time() < deadline:
        improved = False
        # 1) try expanding each digit set with base-aligned values
        for i in range(bdepth):
            for v in base_aligned:
                if v in bdig[i]:
                    continue
                ng = [list(x) for x in bdig] + []
                # pad to depth
                while len(ng) < bdepth:
                    ng.append([0])
                ng[i] = sorted(set(ng[i] + [v]))
                _, s = try_gene((ng, bbase, bdepth))
                if s >= best_score:
                    best_score = s
                    bdig = ng
                    best_gene = (ng, bbase, bdepth)
                    improved = True
                    break
            if improved:
                break
        if improved:
            continue
        # 2) try removing a digit
        for i in range(bdepth):
            if len(bdig[i]) <= 1:
                continue
            for v in list(bdig[i]):
                ng = [list(x) for x in bdig]
                ng[i] = [x for x in ng[i] if x != v]
                _, s = try_gene((ng, bbase, bdepth))
                if s >= best_score:
                    best_score = s
                    bdig = ng
                    best_gene = (ng, bbase, bdepth)
                    improved = True
                    break
            if improved:
                break
        if improved:
            continue
        # 3) try joint depth/base changes
        for db in (1, -1, 2, -2, 3, -3):
            nb2 = bbase + db
            if nb2 < 2 or nb2 > 60:
                continue
            ng = [list(x) for x in bdig]
            _, s = try_gene((ng, nb2, bdepth))
            if s >= best_score:
                best_score = s
                bbase = nb2
                best_gene = (ng, nb2, bdepth)
                improved = True
                break
        if improved:
            continue
        for dd in (1, -1):
            nd2_ = bdepth + dd
            if nd2_ < 1 or nd2_ > 6:
                continue
            ng = [list(x) for x in bdig]
            while len(ng) < nd2_:
                ng.append([0])
            _, s = try_gene((ng, bbase, nd2_))
            if s >= best_score:
                best_score = s
                bdepth = nd2_
                bdig = ng
                best_gene = (ng, bbase, nd2_)
                improved = True
                break

    res = sorted(set(_build(bdig, bbase, bdepth)))

    # Polish: drop elements that don't hurt the ratio.
    improved = True
    cur_nd, cur_ns = _counts(res)
    cur_s = _score_from_counts(cur_nd, cur_ns, len(res))
    while improved and time.time() < deadline:
        improved = False
        order = list(range(len(res)))
        rng.shuffle(order)
        for i in order:
            cand = res[:i] + res[i + 1:]
            if len(cand) < 2:
                continue
            nd2, ns2 = _counts(cand)
            s = _score_from_counts(nd2, ns2, len(cand))
            if s >= cur_s:
                res = cand
                cur_s = s
                improved = True
                break

    return res
# EVOLVE-BLOCK-END
