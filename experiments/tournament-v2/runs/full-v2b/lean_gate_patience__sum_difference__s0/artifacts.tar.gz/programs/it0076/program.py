# EVOLVE-BLOCK-START
"""Deterministic multi-cluster construction.

A is a union of arithmetic-progression clusters. Offsets are chosen from a
small additive structure so that sums of offsets from different clusters
collide (keeping |A+A| small), while the clusters themselves are spread with
large gaps so that cross-cluster differences stay distinct (keeping |A-A|
large). Offsets and gaps are refined by deterministic hill-climbing, scored
with a fast numpy bincount-based exact counter for |A-A| and |A+A|.
"""
import time
import numpy as np


def _counts(a, maxv):
    """Exact |A+A| and |A-A| for a numpy int64 array using bincount."""
    n = a.size
    # sums
    s = (a[:, None] + a[None, :]).ravel()
    sums = np.bincount(s - s.min(), minlength=(s.max() - s.min()) + 1)
    nsum = int(np.count_nonzero(sums))
    # differences
    d = (a[:, None] - a[None, :]).ravel()
    diffs = np.bincount(d - d.min(), minlength=(d.max() - d.min()) + 1)
    ndif = int(np.count_nonzero(diffs))
    return ndif, nsum


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return -1.0, 0, 0
    ndif, nsum = _counts(a, 0)
    val = np.log(ndif) / np.log(nsum) if nsum > 1 else 0.0
    val += (1.0 - 1.0 / n) / 100.0
    return val, ndif, nsum


def _build(offsets, gaps, sizes):
    """Union of APs: cluster i = offsets[i] + j*gaps[i], j=0..sizes[i]-1."""
    pts = []
    for o, g, s in zip(offsets, gaps, sizes):
        pts.append(o + g * np.arange(s, dtype=np.int64))
    return np.unique(np.concatenate(pts))


def solve():
    deadline = time.time() + 115.0
    rng = np.random.default_rng(12345)

    best_a = None
    best_score = -1.0

    # Try several deterministic multi-cluster seeds.
    # Cluster count, gaps large and coprime-ish so cross differences distinct.
    configs = []
    for k in (3, 4, 5):
        gaps = [int(g) for g in rng.choice(
            [101, 127, 149, 173, 199, 223, 251, 277, 307, 331], size=k,
            replace=False)]
        # additively-structured offsets: small values -> many sum collisions
        base = [0, 1, 2, 4, 8, 16, 3, 5, 6, 9][:k]
        sizes = [7] * k
        configs.append((base[:k], gaps, sizes))

    for base, gaps, sizes in configs:
        offsets = list(base)
        gaps = list(gaps)
        sizes = list(sizes)
        a = _build(offsets, gaps, sizes)
        cur_score, _, _ = _score(a)

        # deterministic hill climbing on offsets, gaps and sizes
        improved = True
        while improved and time.time() < deadline:
            improved = False
            # tune offsets
            for i in range(len(offsets)):
                for delta in (-1, 1, -2, 2, -3, 3):
                    trial = offsets[:]
                    trial[i] += delta
                    if min(trial) < 0:
                        continue
                    a2 = _build(trial, gaps, sizes)
                    s2, _, _ = _score(a2)
                    if s2 > cur_score:
                        offsets, cur_score, improved = trial, s2, True
                        a = a2
            # tune gaps
            for i in range(len(gaps)):
                for delta in (-13, -7, -3, 3, 7, 13, 29, 41):
                    trial = gaps[:]
                    trial[i] += delta
                    if trial[i] <= max(sizes) or len(set(trial)) < 2:
                        continue
                    a2 = _build(offsets, trial, sizes)
                    s2, _, _ = _score(a2)
                    if s2 > cur_score:
                        gaps, cur_score, improved = trial, s2, True
                        a = a2
            # tune sizes
            for i in range(len(sizes)):
                for delta in (-1, 1):
                    trial = sizes[:]
                    trial[i] += delta
                    if trial[i] < 2:
                        continue
                    if sum(trial) > 4000:
                        continue
                    a2 = _build(offsets, gaps, trial)
                    s2, _, _ = _score(a2)
                    if s2 > cur_score:
                        sizes, cur_score, improved = trial, s2, True
                        a = a2

        if cur_score > best_score:
            best_score = cur_score
            best_a = a

    if best_a is None:
        best_a = np.array([7, 15, 18, 22, -3, -2], dtype=np.int64)

    # final sanity cleanup
    best_a = np.unique(best_a)
    return [int(x) for x in best_a]
# EVOLVE-BLOCK-END
