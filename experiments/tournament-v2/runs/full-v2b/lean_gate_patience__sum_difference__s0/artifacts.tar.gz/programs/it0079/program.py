# EVOLVE-BLOCK-START
"""Direct optimization over structured families with a fast exact scorer.

We build A as a union of k arithmetic-progression clusters and hill-climb
the offsets/spacings to maximize log|A-A|/log|A+A| + size bonus.  The scorer
uses numpy bincount on shifted arrays so it is exact and fast, letting us do
many more evaluations within the time budget.
"""
import time
import numpy as np


def _exact(nd_vals):
    """Given int64 array of pairwise diffs, return |X-X|."""
    return None


def _score(vals):
    v = np.unique(np.asarray(vals, dtype=np.int64))
    n = v.size
    if n < 2:
        return -1.0, 1, 1
    s = (v[:, None] + v[None, :]).ravel()
    ns = int(np.unique(s).size)
    d = (v[:, None] - v[None, :]).ravel()
    nd = int(np.unique(d).size)
    if ns <= 1 or nd <= 1:
        return -1.0, nd, ns
    val = np.log(nd) / np.log(ns) + (1.0 - 1.0 / n) / 100.0
    return val, nd, ns


def _fast_counts(v):
    """Return |X+X| and |X-X| using bincount on shifted indices."""
    v = np.unique(np.asarray(v, dtype=np.int64))
    n = v.size
    lo = 2 * v.min()
    hi = 2 * v.max()
    s = (v[:, None] + v[None, :]).ravel() - lo
    ns = int(np.count_nonzero(np.bincount(s)))
    dlo = v.min() - v.max()
    d = (v[:, None] - v[None, :]).ravel() - dlo
    nd = int(np.count_nonzero(np.bincount(d)))
    return nd, ns


def _fast_score(vals):
    v = np.unique(np.asarray(vals, dtype=np.int64))
    n = v.size
    if n < 2:
        return -1.0
    nd, ns = _fast_counts(v)
    if ns <= 1 or nd <= 1:
        return -1.0
    return np.log(nd) / np.log(ns) + (1.0 - 1.0 / n) / 100.0


def _clusters(offsets, spacing, lengths):
    """A = union over i of {offsets[i] + j*spacing[i] for 0<=j<lengths[i]}."""
    parts = []
    for o, sp, L in zip(offsets, spacing, lengths):
        if L <= 0:
            continue
        parts.append(o + sp * np.arange(L, dtype=np.int64))
    if not parts:
        return np.zeros(1, dtype=np.int64)
    return np.unique(np.concatenate(parts))


def solve():
    deadline = time.time() + 110.0
    rng = np.random.default_rng(424242)

    best_A = None
    best_val = -1.0

    def consider(vals):
        nonlocal best_A, best_val
        v = np.unique(np.asarray(vals, dtype=np.int64))
        if v.size < 2 or v.size > 4000:
            return
        if np.max(np.abs(v)) > 10**15:
            return
        sval = _fast_score(v)
        if sval > best_val + 1e-12:
            best_val = sval
            best_A = v

    # --- Family 1: two APs with equal spacing, offset tuned so sums collide ---
    for L in range(20, 2000, 7):
        for gap in range(1, 200):
            a = np.arange(L, dtype=np.int64)
            b = L + gap + np.arange(L, dtype=np.int64)
            consider(np.concatenate([a, b]))
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # --- Family 2: k APs sharing a common spacing, varied offsets/lengths ---
    for _ in range(4000):
        if time.time() > deadline:
            break
        k = int(rng.integers(2, 6))
        sp = int(rng.integers(1, 60))
        lengths = rng.integers(5, 400, size=k)
        offsets = np.cumsum(rng.integers(1, 40 * sp + 1, size=k))
        vals = _clusters(offsets.tolist(), [sp] * k, lengths.tolist())
        consider(vals)

    # --- Local improvement on best_A: perturb elements ---
    if best_A is not None:
        it = 0
        while time.time() < deadline and it < 100000:
            it += 1
            v = best_A.copy()
            n = v.size
            # perturb one element
            i = int(rng.integers(0, n))
            delta = int(rng.integers(-3, 4))
            if delta == 0:
                delta = 1
            v[i] = v[i] + delta
            v = np.unique(v)
            if v.size < 2 or v.size > 4000:
                continue
            sval = _fast_score(v)
            if sval > best_val + 1e-12:
                best_val = sval
                best_A = v
            # occasionally try adding an element
            if it % 5 == 0 and best_A.size < 4000:
                addpos = int(best_A[-1]) + int(rng.integers(1, 5))
                v2 = np.unique(np.append(best_A, addpos))
                sval = _fast_score(v2)
                if sval > best_val + 1e-12:
                    best_val = sval
                    best_A = v2

    if best_A is None:
        best_A = np.array([0, 1, 4, 9, 24, 36], dtype=np.int64)

    return [int(x) for x in np.unique(best_A)]
# EVOLVE-BLOCK-END
