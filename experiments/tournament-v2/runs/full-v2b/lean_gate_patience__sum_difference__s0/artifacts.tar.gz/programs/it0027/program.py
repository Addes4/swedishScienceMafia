# EVOLVE-BLOCK-START
"""Mixed-radix digit construction.

A = { sum_i c_i * d_i : d_i in D_i } where c_i are growing coefficients and D_i small
digit sets. Then A-A is the sumset of the level difference sets (large, product-like),
while A+A has heavy carry collisions (small), so log|A-A|/log|A+A| is large.
We build the actual set, score it exactly with numpy, and keep the best.
"""
import math
import time
import numpy as np
import random


def _diffs_sums_np(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.shape[0]
    if n < 2:
        return 0, 0
    d = (a[:, None] - a[None, :]).ravel()
    nd = np.unique(d).size
    s = (a[:, None] + a[None, :]).ravel()
    ns = np.unique(s).size
    return int(nd), int(ns)


def _score_counts(nd, ns, n):
    if n < 2 or ns < 1 or nd < 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _score_np(a):
    nd, ns = _diffs_sums_np(a)
    return _score_counts(nd, ns, len(a))


def _build_mixed(coeffs, digit_sets):
    """Build set as all combinations of digits with given coefficients."""
    vals = np.zeros(1, dtype=np.int64)
    for c, D in zip(coeffs, digit_sets):
        D = np.asarray(D, dtype=np.int64)
        vals = (vals[:, None] + c * D[None, :]).ravel()
        if vals.size > 4000:
            # prune: keep unique to bound growth
            vals = np.unique(vals)
            if vals.size > 4000:
                vals = vals[:4000]
    vals = np.unique(vals)
    return vals


def _candidate_digit_sets():
    """Small digit sets that favor large differences / small sums."""
    sets = []
    # canonical: {0,1,...} like bases; use {0,...,k-1} giving many auto-sums
    for k in (2, 3, 4, 5, 6):
        sets.append(tuple(range(k)))
    # shifted / symmetric sets add collisions in sums
    sets.append((-1, 0, 1))
    sets.append((-2, -1, 0, 1, 2))
    sets.append((-1, 0, 1, 2))
    sets.append((0, 1, 3))
    sets.append((0, 2, 5))
    sets.append((0, 1, 2, 4))
    sets.append((0, 1, 3, 7))
    return sets


def _evaluate(coeffs, dss, deadline):
    if time.time() > deadline:
        return None
    try:
        vals = _build_mixed(coeffs, dss)
    except Exception:
        return None
    if vals.size < 2:
        return None
    # ensure distinctness & bounds
    if vals.size > 4000:
        return None
    if np.max(np.abs(vals)) > 10**15:
        return None
    s = _score_np(vals)
    return s, vals


def solve():
    deadline = time.time() + 110.0
    best = (0.0, None)
    rng = random.Random(12345)
    pool = _candidate_digit_sets()

    def consider(coeffs, dss):
        nonlocal best
        r = _evaluate(coeffs, dss, deadline)
        if r is None:
            return False
        s, vals = r
        if s > best[0]:
            best = (s, [int(x) for x in vals])
            return True
        return False

    # Base coefficients: growing geometric-ish so carries collide in A+A.
    base_attempts = []
    for radix in (3, 4, 5, 6, 7):
        for nlev in (2, 3, 4, 5):
            coeffs = [radix ** i for i in range(nlev)]
            base_attempts.append((coeffs, radix, nlev))

    for coeffs, radix, nlev in base_attempts:
        if time.time() > deadline:
            break
        # try uniform digit sets
        for ds in pool:
            if time.time() > deadline:
                break
            if ds and len(ds) > 1:
                consider(coeffs, [ds] * nlev)

    # Random search over digit-set assignments per level.
    it = 0
    while time.time() < deadline - 1.0:
        it += 1
        radix = rng.choice([3, 4, 5, 6, 7, 8])
        nlev = rng.choice([2, 3, 4, 5])
        coeffs = [radix ** i for i in range(nlev)]
        # slightly perturb coefficients sometimes to help differences
        if rng.random() < 0.3:
            coeffs = [c + rng.randint(0, radix) for c in coeffs]
        dss = [rng.choice(pool) for _ in range(nlev)]
        consider(coeffs, dss)
        # hill-climb from random starts
        if it % 5 == 0:
            cur_c = coeffs
            cur_d = list(dss)
            cur_r = _evaluate(cur_c, cur_d, deadline)
            if cur_r is None:
                continue
            cur_s = cur_r[0]
            improved = True
            while improved and time.time() < deadline - 1.0:
                improved = False
                # mutate one digit set
                li = rng.randrange(len(cur_d))
                old = cur_d[li]
                for cand in pool:
                    if time.time() > deadline - 1.0:
                        break
                    trial_d = list(cur_d)
                    trial_d[li] = cand
                    r = _evaluate(cur_c, trial_d, deadline)
                    if r is not None and r[0] > cur_s + 1e-12:
                        cur_d = trial_d
                        cur_s = r[0]
                        improved = True
                        if cur_s > best[0]:
                            best = (cur_s, [int(x) for x in r[1]])
                        break
                # mutate one coefficient
                if not improved and rng.random() < 0.5:
                    ci = rng.randrange(len(cur_c))
                    for do in (1, -1, 2, -2, radix, -radix):
                        if time.time() > deadline - 1.0:
                            break
                        trial_c = list(cur_c)
                        trial_c[ci] = trial_c[ci] + do
                        # keep strictly increasing
                        if trial_c[ci] <= (trial_c[ci - 1] if ci > 0 else 0):
                            continue
                        r = _evaluate(trial_c, cur_d, deadline)
                        if r is not None and r[0] > cur_s + 1e-12:
                            cur_c = trial_c
                            cur_s = r[0]
                            improved = True
                            if cur_s > best[0]:
                                best = (cur_s, [int(x) for x in r[1]])
                            break

    if best[1] is None:
        return [0, 1, 2, 3]
    return sorted(set(best[1]))
# EVOLVE-BLOCK-END
