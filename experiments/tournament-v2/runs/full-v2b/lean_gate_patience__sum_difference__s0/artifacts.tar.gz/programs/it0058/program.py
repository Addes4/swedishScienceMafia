# EVOLVE-BLOCK-START
"""Greedy set growth maximizing log|A-A|/log|A+A| (plus size bonus).

Main ideas:
  * A single exact scorer using sorted arrays + incremental updates keeps each
    candidate evaluation cheap enough to grow to a few hundred elements.
  * Multiple randomized restarts over structured seeds and candidate pools.
  * A final local search that shifts single elements to nearby values.
A time budget guards the 120s limit.
"""
import math
import time
import random


def _sets(a):
    sa = set()
    pa = set()
    L = list(a)
    n = len(L)
    for i in range(n):
        xi = L[i]
        sa.add(xi + xi)
        for j in range(i + 1, n):
            sa.add(xi + L[j])
    for i in range(n):
        xi = L[i]
        for j in range(n):
            pa.add(xi - L[j])
    return sa, pa


def _score_from_counts(d, s, n):
    if n < 2 or s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _score(a):
    a = sorted(set(int(x) for x in a))
    sa, pa = _sets(a)
    return _score_from_counts(len(pa), len(sa), len(a))


def solve():
    deadline = time.time() + 100.0
    rng = random.Random(12345)

    best_A = None
    best_score = -1.0

    def eval_add(A, sumset, diffset, x):
        ns = set(sumset)
        nd = set(diffset)
        for y in A:
            ns.add(x + y)
            nd.add(x - y)
            nd.add(y - x)
        ns.add(x + x)
        return ns, nd

    # structured seeds
    seeds = [
        [0, 1],
        [0, 1, 3],
        [0, 1, 3, 9],
        [0, 1, 4, 6],
        [0, 1, 3, 7, 12],
        [0, 1, 4, 6, 13],
        [0, 2, 5, 9, 14],
        [0, 1, 2, 4, 8, 16],
    ]

    def grow(seed, target_n, max_candidates=260):
        A = sorted(set(seed))
        sumset, diffset = _sets(A)
        while len(A) < target_n:
            if time.time() > deadline:
                break
            n = len(A)
            cur = _score_from_counts(len(diffset), len(sumset), n)
            lo, hi = A[0], A[-1]
            span = hi - lo
            cand = set()
            # window around each element
            for x in A:
                for d in (1, 2, 3, 4, 5, span + 1, span + 2, 2 * span + 1):
                    cand.add(x + d)
                    cand.add(x - d)
            cand.add(hi + 1)
            cand.add(hi + 2)
            cand.add(lo - 1)
            cand.add(lo - 2)
            # random perturbations of random members for diversity
            for _ in range(40):
                x = A[rng.randrange(n)]
                cand.add(x + rng.randint(-span - 2, span + 2))
            cand = [c for c in cand if c not in A]
            rng.shuffle(cand)
            cand = cand[:max_candidates]
            best_c = None
            best_cs = cur
            for x in cand:
                ns, nd = eval_add(A, sumset, diffset, x)
                sc = _score_from_counts(len(nd), len(ns), n + 1)
                if sc > best_cs:
                    best_cs = sc
                    best_c = (x, ns, nd)
            if best_c is None:
                break
            x, ns, nd = best_c
            A = sorted(A + [x])
            sumset, diffset = ns, nd
        return A, sumset, diffset

    target = 120
    for seed in seeds:
        if time.time() > deadline:
            break
        A, sumset, diffset = grow(seed, target)
        sc = _score_from_counts(len(diffset), len(sumset), len(A))
        if sc > best_score:
            best_score = sc
            best_A = A[:]

    if best_A is None:
        best_A = [0, 1, 3, 9, 27]
        best_score = _score(best_A)

    # local search: single-element moves
    A = sorted(set(best_A))
    cur_score = _score(A)
    improved = True
    rounds = 0
    while improved and time.time() < deadline and rounds < 400:
        improved = False
        rounds += 1
        order = list(range(len(A)))
        rng.shuffle(order)
        for i in order:
            for delta in (1, -1, 2, -2, 3, -3, 5, -5, 7, -7):
                cand = A[:]
                cand[i] += delta
                cand = sorted(set(cand))
                if len(cand) < 2:
                    continue
                sc = _score(cand)
                if sc > cur_score + 1e-12:
                    cur_score = sc
                    A = cand
                    improved = True
                    break
            if improved:
                break

    return sorted(set(int(x) for x in A))
# EVOLVE-BLOCK-END
