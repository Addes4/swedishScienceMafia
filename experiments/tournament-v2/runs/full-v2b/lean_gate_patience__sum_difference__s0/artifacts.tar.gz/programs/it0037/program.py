# EVOLVE-BLOCK-START
"""Deterministic multi-cluster construction: union of arithmetic progressions,
refined by hill-climbing with a fast numpy-based exact scorer."""
import math
import time
import random
import numpy as np


def _count_distinct_diff_and_sum(a):
    """Exact distinct counts of A-A and A+A using numpy."""
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    diffs = (a[:, None] - a[None, :]).ravel()
    sums = (a[:, None] + a[None, :]).ravel()
    nd = np.unique(diffs).size
    ns = np.unique(sums).size
    return nd, ns


def _score(a):
    a = list(dict.fromkeys(a))
    if len(a) < 2:
        return 0.0
    nd, ns = _count_distinct_diff_and_sum(a)
    return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100


def _build_from_clusters(clusters, gap, offset):
    """clusters: list of (start, length). Each cluster is an arithmetic progression
    with common difference gap."""
    A = []
    for i, (s, L) in enumerate(clusters):
        base = offset[i]
        for t in range(L):
            A.append(base + t * gap)
    return A


def _initial_clusters():
    # A union of several AP clusters with the same gap, offsets spread wide.
    gap = 1
    clusters = []
    # main dense block to create heavy sum collisions
    clusters.append((0, 60))
    # many short clusters placed far apart so differences remain distinct
    rng = random.Random(12345)
    for i in range(1, 20):
        L = rng.randint(5, 20)
        clusters.append((0, L))
    return clusters, gap


def solve():
    rng = random.Random(20240607)
    deadline = time.time() + 100

    # Deterministic structured start: k clusters, each an AP with same gap.
    # Offsets chosen so clusters are widely separated (large differences,
    # controlled sums) with one big dense cluster for sum collisions.
    n_clusters = 22
    gap = 1

    # lengths
    lengths = [70]
    for i in range(n_clusters - 1):
        lengths.append(rng.randint(4, 18))
    lengths = np.array(lengths, dtype=np.int64)

    # offsets: spread clusters across a wide range with irregular spacing
    offsets = [0]
    spread = 0
    for i in range(1, n_clusters):
        # deterministic irregular increasing offsets
        step = rng.randint(40, 200)
        spread += step
        offsets.append(spread)
    offsets = np.array(offsets, dtype=np.int64)

    def make_A(lengths, offsets, gap):
        A = []
        for L, off in zip(lengths.tolist(), offsets.tolist()):
            A.extend(off + t * gap for t in range(L))
        return A

    cur_len = lengths.copy()
    cur_off = offsets.copy()
    cur_gap = gap

    A = make_A(cur_len, cur_off, cur_gap)
    best_A = A
    best_score = _score(A)

    # Hill climbing: perturb offsets and lengths, keep if score improves.
    step_sizes = [1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
    it = 0
    while time.time() < deadline:
        it += 1
        # occasionally restart from best
        if rng.random() < 0.10:
            cur_len = np.array(best_A and _lengths_from_A(best_A) or lengths, dtype=np.int64)

        nl = cur_len.copy()
        no = cur_off.copy()
        mode = rng.random()

        if mode < 0.55:
            # perturb a single offset
            i = rng.randrange(n_clusters)
            s = rng.choice(step_sizes)
            no[i] += rng.choice([-1, 1]) * s
        elif mode < 0.80:
            # perturb a single length
            i = rng.randrange(n_clusters)
            d = rng.choice([-2, -1, 1, 2, 3])
            nl[i] = max(2, min(120, nl[i] + d))
        elif mode < 0.92:
            # shift all offsets (translation invariant -> no effect, vary instead)
            i = rng.randrange(n_clusters)
            no[i] += rng.choice([-1, 1]) * rng.randint(100, 500)
        else:
            # perturb gap
            ng = cur_gap
            ng += rng.choice([-1, 1])
            ng = max(1, min(4, ng))
            newA = make_A(nl, no, ng)
            s = _score(newA)
            if s >= best_score:
                cur_len, cur_off, cur_gap = nl, no, ng
                if s > best_score:
                    best_score = s
                    best_A = newA
            continue

        newA = make_A(nl, no, cur_gap)
        s = _score(newA)
        if s >= best_score:
            cur_len, cur_off = nl, no
            if s > best_score:
                best_score = s
                best_A = newA
        elif rng.random() < 0.05:
            cur_len, cur_off = nl, no

    # combine: union of best-cluster structure plus a refined dense core
    res = sorted(set(best_A))

    # final cheap cleanup: try to drop elements without hurting score
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for i in range(len(res)):
            cand = res[:i] + res[i + 1:]
            s = _score(cand)
            if s >= _score(res):
                res = cand
                improved = True
                break

    return res


def _lengths_from_A(A):
    # recover approximate cluster lengths heuristically (not critical)
    return [70] + [10] * 21
# EVOLVE-BLOCK-END
