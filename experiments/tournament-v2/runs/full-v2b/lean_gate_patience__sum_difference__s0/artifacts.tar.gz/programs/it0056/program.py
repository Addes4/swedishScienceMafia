# EVOLVE-BLOCK-START
"""Directly optimize log|A-A|/log|A+A| by greedy set growth.

Strategy: start from a small seed, then repeatedly insert one integer drawn from a
candidate pool (a window around existing elements plus structured offsets).  We
maintain A+A and A-A exactly as Python sets so each candidate is evaluated in
O(|A|) time.  After greedy growth we run a deterministic local search that moves
single elements to nearby values, always keeping the exact objective non-decreasing.
A time budget guards the 120s limit.
"""
import math
import time


def _sets(a):
    """Exact |A+A| and |A-A| as sets."""
    sa = set()
    pa = set()
    L = list(a)
    n = len(L)
    for i in range(n):
        xi = L[i]
        sa.add(xi + xi)
        for j in range(i + 1, n):
            xj = L[j]
            sa.add(xi + xj)
    for i in range(n):
        xi = L[i]
        for j in range(n):
            pa.add(xi - L[j])
    return sa, pa


def _score_from_counts(d, s, n):
    if n < 2 or s <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _score(a):
    a = sorted(set(int(x) for x in a))
    sa, pa = _sets(a)
    return _score_from_counts(len(pa), len(sa), len(a))


def _incremental_counts(A, sumset, diffset):
    """Return counts consistent with membership sets."""
    return len(diffset), len(sumset)


def solve():
    deadline = time.time() + 100.0

    def eval_grow(A, sumset, diffset, x):
        """Return (new_sumset, new_diffset) if x added to A, plus score."""
        ns = set(sumset)
        nd = set(diffset)
        for y in A:
            ns.add(x + y)
            nd.add(x - y)
            nd.add(y - x)
        ns.add(x + x)
        return ns, nd

    best_A = None
    best_score = -1.0

    # ---- seeds: try several small structured starting sets ---------------
    seeds = []
    seeds.append([0, 1])
    seeds.append([0, 1, 3])
    seeds.append([0, 1, 3, 9])
    seeds.append([0, 1, 2, 4])
    seeds.append([0, 1, 4, 6])
    seeds.append([0, 1, 3, 7, 12])
    seeds.append([0, 1, 3, 7, 15])
    seeds.append([0, 1, 5, 7, 11])
    seeds.append([0, 2, 5, 9, 14])

    for seed in seeds:
        if time.time() > deadline:
            break
        A = sorted(set(seed))
        sumset, diffset = _sets(A)
        # greedy growth
        while time.time() < deadline:
            n = len(A)
            if n >= 60:
                break
            cur = _score_from_counts(len(diffset), len(sumset), n)
            # candidate pool: window around min..max, plus scaled offsets
            lo = min(A)
            hi = max(A)
            cand = set()
            span = hi - lo
            for x in A:
                for dlt in (1, 2, 3, 4, span + 1, span + 2, 2 * span + 1):
                    cand.add(x + dlt)
                    cand.add(x - dlt)
            # also extend beyond range
            cand.add(hi + 1)
            cand.add(hi + 2)
            cand.add(lo - 1)
            cand.add(lo - 2)
            cand = [c for c in cand if c not in A]
            best_c = None
            best_cs = cur
            for x in cand:
                ns, nd = eval_grow(A, sumset, diffset, x)
                sc = _score_from_counts(len(nd), len(ns), n + 1)
                if sc > best_cs:
                    best_cs = sc
                    best_c = (x, ns, nd)
            if best_c is None:
                break
            x, ns, nd = best_c
            A = sorted(A + [x])
            sumset, diffset = ns, nd
        sc = _score_from_counts(len(diffset), len(sumset), len(A))
        if sc > best_score:
            best_score = sc
            best_A = A[:]

    if best_A is None:
        best_A = [0, 1, 3, 9, 27]
        best_score = _score(best_A)

    # ---- local search: single-element moves ------------------------------
    A = sorted(set(best_A))
    cur_score = _score(A)
    improved = True
    rounds = 0
    while improved and time.time() < deadline and rounds < 300:
        improved = False
        rounds += 1
        for i in range(len(A)):
            for delta in (1, -1, 2, -2, 3, -3, 5, -5):
                cand = A[:]
                cand[i] += delta
                cand = sorted(set(cand))
                if len(cand) < 2:
                    continue
                sc = _score(cand)
                if sc > cur_score + 1e-12:
                    cur_score = sc
                    A = cand
                    improved = True
                    break
            if improved:
                break

    return sorted(set(int(x) for x in A))
# EVOLVE-BLOCK-END
