# EVOLVE-BLOCK-START
"""Greedy / hill-climb construction directly on A.

Objective: r(A) = log|A-A| / log|A+A|  (plus size bonus).
We grow A one element at a time; each candidate element is scanned over a grid,
scored exactly with numpy, and kept only if it improves r(A). We start from a
good seed (an arithmetic progression, which minimizes the sum set) and then add
elements that enlarge the difference set faster than the sum set.
"""
import math
import time
import numpy as np

TIME_LIMIT = 100.0


def _dd_ss(A):
    a = np.asarray(sorted(set(int(x) for x in A)), dtype=np.int64)
    if a.size == 0:
        return 0, 0
    d = (a[:, None] - a[None, :]).ravel()
    s = (a[:, None] + a[None, :]).ravel()
    return int(np.unique(d).size), int(np.unique(s).size)


def _score(nd, ns, n):
    if ns <= 1 or nd <= 1:
        return -1.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def solve():
    start = time.time()
    rng = np.random.RandomState(20240517)

    # ---- seed: arithmetic progression maximizes collisions in A+A ----
    best_A = list(range(0, 40))
    best_nd, best_ns = _dd_ss(best_A)
    best_sc = _score(best_nd, best_ns, len(best_A))

    # current working set
    A = best_A[:]
    nd, ns = best_nd, best_ns

    max_size = 4000
    vals_lo, vals_hi = -10**6, 10**6

    # ---- greedy grow: try to add elements that help ----
    while len(A) < max_size and time.time() - start < TIME_LIMIT * 0.9:
        base = np.asarray(sorted(A), dtype=np.int64)
        step = 1
        improved = False
        # try a bunch of random candidates plus a sweep near the gap
        cands = set()
        # sweep multiples/spread positions
        span = int(base.max() - base.min()) if base.size > 1 else 1
        for _ in range(60):
            cands.add(int(rng.randint(-span - 5, span + 6)))
        for frac in range(1, 20):
            cands.add(int(base.min() + span * frac // 20))
        for c in list(cands)[:80]:
            if c in A:
                continue
            trial = A + [int(c)]
            tnd, tns = _dd_ss(trial)
            tsc = _score(tnd, tns, len(trial))
            if tsc > best_sc:
                best_sc = tsc
                best_A = trial[:]
                best_nd, best_ns = tnd, tns
                improved = True
                break
        if improved:
            A = best_A[:]
            nd, ns = best_nd, best_ns
            continue
        # try widening: scale positions
        if base.size >= 2:
            A2 = [2 * (x - base.min()) for x in A]
        else:
            break
        # add random distinct element at a scaled location
        for _ in range(40):
            c = int(rng.randint(-5 * span - 10, 5 * span + 11))
            if c in A2:
                continue
            trial = A2 + [c]
            tnd, tns = _dd_ss(trial)
            tsc = _score(tnd, tns, len(trial))
            if tsc > best_sc:
                best_sc = tsc
                best_A = trial[:]
                best_nd, best_ns = tnd, tns
                improved = True
                break
        if improved:
            A = best_A[:]
            nd, ns = best_nd, best_ns
        else:
            break

    # ---- try a few structured seeds and keep the best ----
    def try_seed(seed):
        nonlocal best_A, best_nd, best_ns, best_sc
        a = sorted(set(int(x) for x in seed))
        nd, ns = _dd_ss(a)
        sc = _score(nd, ns, len(a))
        # quick local growth
        for _ in range(200):
            if time.time() - start > TIME_LIMIT * 0.97:
                break
            b = np.asarray(a, dtype=np.int64)
            span = int(b.max() - b.min()) if b.size > 1 else 1
            c = int(rng.randint(-span - 3, span + 4))
            if c in a:
                continue
            trial = a + [c]
            tnd, tns = _dd_ss(trial)
            tsc = _score(tnd, tns, len(trial))
            if tsc > sc:
                a = trial
                nd, ns, sc = tnd, tns, tsc
        if sc > best_sc:
            best_sc, best_A, best_nd, best_ns = sc, a[:], nd, ns

    if time.time() - start < TIME_LIMIT * 0.95:
        try_seed(list(range(0, 60, 1)))
    if time.time() - start < TIME_LIMIT * 0.95:
        # geometric-ish (Sidon-like differences, small sums)
        g = []
        x = 1
        for _ in range(20):
            g.append(x)
            x = x * 2 + rng.randint(0, 2)
        try_seed(g)

    # ---- normalize ----
    A = sorted(set(int(x) for x in best_A))
    lim = 10**15
    A = [x for x in A if abs(x) <= lim]
    if len(A) > 4000:
        A = A[:4000]
    if len(A) < 2:
        A = [0, 1]
    return A
# EVOLVE-BLOCK-END

