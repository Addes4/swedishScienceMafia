"""Maximize log|A-A|/log|A+A| via the digit-set construction.

For A = { sum_i d_i B^i : d_i in D } with base B > 2*max|D| (carry-free),
    |A-A| = |D-D|^m ,  |A+A| = |D+D|^m
so the ratio equals log|D-D| / log|D+D| for the small digit set D.
Increasing m only raises |A| and thus the size bonus.
So the problem reduces to finding a small D with large ratio.
"""
import math
import time
import random
from itertools import product


def _stats(D):
    s = set()
    d = set()
    n = len(D)
    for i in range(n):
        xi = D[i]
        s.add(xi + xi)
        for j in range(n):
            d.add(xi - D[j])
        for j in range(i + 1, n):
            s.add(xi + D[j])
    return len(d), len(s)


def _ratio(D):
    d, s = _stats(D)
    if s <= 1 or d <= 1:
        return 0.0
    return math.log(d) / math.log(s)


def _norm(D):
    D = sorted(set(x for x in D if x >= 0))
    return D


def _steepest(D, r, deadline, rng, max_radius):
    """Best-of-neighborhood local search: try changing one element at a time."""
    improved = True
    while improved and time.time() < deadline:
        improved = False
        best_local = r
        best_D = D
        k = len(D)
        for i in range(k):
            base = D[:i] + D[i + 1:]
            for v in range(max_radius):
                for cand in (base + [v],):
                    C = _norm(cand)
                    if len(C) < 2:
                        continue
                    rc = _ratio(C)
                    if rc > best_local:
                        best_local = rc
                        best_D = C
        # also try removing one element and adding two
        k = len(D)
        for i in range(k):
            rem = D[:i] + D[i + 1:]
            for a in range(max_radius):
                for b in range(max_radius):
                    C = _norm(rem + [a, b])
                    if len(C) < 2:
                        continue
                    rc = _ratio(C)
                    if rc > best_local:
                        best_local = rc
                        best_D = C
        if best_local > r:
            r = best_local
            D = best_D
            improved = True
    return D, r


def solve():
    deadline = time.time() + 95.0
    rng = random.Random(1234567)

    bestD = [0, 1, 3, 7, 15]
    bestR = _ratio(bestD)

    # ---- seed with several structured families ----
    seeds = []
    for k in range(2, 12):
        seeds.append(sorted(range(k)))
    for k in range(2, 12):
        seeds.append([0] + [2 ** i - 1 for i in range(1, k)])
    seeds.append([0, 1, 2, 4, 8, 16])
    seeds.append([0, 1, 3, 7, 15, 31])
    for s in seeds:
        s = _norm(s)
        if len(s) >= 2:
            r = _ratio(s)
            if r > bestR:
                bestR = r
                bestD = s

    # ---- randomized multi-restart improvement ----
    for attempt in range(400):
        if time.time() > deadline:
            break
        k = rng.randint(3, 12)
        R = rng.choice([8, 16, 32, 64, 128])
        if rng.random() < 0.5:
            D = _norm(rng.sample(range(R), min(k, R)))
        else:
            D = _norm([0] + [2 ** i - 1 for i in range(1, k)])
        if len(D) < 2:
            continue
        r = _ratio(D)
        for _ in range(120):
            if time.time() > deadline:
                break
            D2 = list(D)
            idx = rng.randrange(len(D2))
            mode = rng.random()
            if mode < 0.5:
                D2[idx] = rng.randrange(R)
            elif mode < 0.8:
                D2[idx] = D2[idx] + rng.randint(-4, 4)
            else:
                other = rng.choice(D2)
                D2[idx] = other + rng.randint(-3, 3)
            D2 = _norm(D2)
            if len(D2) < 2:
                continue
            r2 = _ratio(D2)
            if r2 > r:
                r = r2
                D = D2
        if r > bestR:
            bestR = r
            bestD = D[:]

    # ---- steepest ascent polish on the best ----
    D = bestD
    for _ in range(3):
        if time.time() > deadline:
            break
        r = _ratio(D)
        D, r = _steepest(D, r, deadline, rng, max(64, max(D) + 8))
        if r > bestR:
            bestR = r
            bestD = D[:]
        else:
            break

    # ---- build the big set ----
    D = bestD
    k = len(D)
    maxD = max(abs(x) for x in D)
    B = max(2, 2 * maxD + 1)

    m = 1
    while True:
        if k ** (m + 1) > 4000:
            break
        top = maxD * ((B ** (m + 1) - 1) // (B - 1)) if B > 1 else maxD
        if top > 10 ** 15:
            break
        m += 1

    A = []
    for combo in product(D, repeat=m):
        val = 0
        p = 1
        for dgt in combo:
            val += dgt * p
            p *= B
        A.append(val)

    A = sorted(set(A))
    if len(A) < 2:
        A = [0, 1, 2, 4]

    return [int(x) for x in A]
