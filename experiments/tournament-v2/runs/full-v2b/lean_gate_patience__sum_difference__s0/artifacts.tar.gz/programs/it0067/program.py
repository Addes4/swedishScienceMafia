# EVOLVE-BLOCK-START
"""Deterministic multi-cluster AP construction with hill-climbing refinement.

Idea: A = union of k clusters, each cluster being an arithmetic progression
a_i + j*g_i for j in [0, L_i).  Differences within a cluster give a dense range,
and differences between clusters give many distinct values (large |A-A|).
Sums, on the other hand, can be made to collide because sums of APs are also
AP-ish and chosen offsets can be tuned additively.

We score exactly with numpy convolutions and refine with deterministic
hill-climbing.
"""
import math
import time

import numpy as np


def _exact_counts(A):
    """Return (|A-A|, |A+A|) exactly using integer counting arrays."""
    if len(A) < 2:
        return 1, 1
    A = [int(x) for x in A]
    lo = min(A)
    hi = max(A)
    span = hi - lo
    if span == 0:
        return 1, 1

    # Difference counts via correlation of indicator vector
    size = 2 * span + 1
    if size > 4_000_000:
        # fall back to direct set computation
        diffs = set()
        sums = set()
        for x in A:
            for y in A:
                diffs.add(x - y)
                sums.add(x + y)
        return len(diffs), len(sums)

    ind = np.zeros(size, dtype=np.int64)
    for x in A:
        ind[x - lo] += 1

    # number of (a,b) pairs with a-b = d is correlation
    corr = np.convolve(ind, ind[::-1])
    # corr index i corresponds to difference d = i - span
    dcount = np.count_nonzero(corr)  # includes 0 automatically since |A|>=2

    # sums: convolution of ind with itself, index i corresponds to sum s = i + 2*lo
    conv = np.convolve(ind, ind)
    scount = np.count_nonzero(conv)

    return int(dcount), int(scount)


def _score(A):
    if len(A) < 2:
        return 0.0
    d, s = _exact_counts(A)
    if s < 2 or d < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(A)) / 100


def _build(k, lengths, gaps, offsets):
    A = []
    for i in range(k):
        L = lengths[i]
        g = gaps[i]
        o = offsets[i]
        for j in range(L):
            A.append(o + j * g)
    return sorted(set(A))


def _initial_params():
    # Hand-tuned starting point: nested structures where sums collide.
    # We use clusters along a geometric-ish scale so differences between
    # clusters are all distinct, but cluster sums overlap.
    k = 6
    lengths = [4, 4, 4, 4, 4, 4]
    gaps = [1, 3, 9, 27, 81, 243]
    offsets = [0, 0, 0, 0, 0, 0]
    return k, lengths, gaps, offsets


def _hill_climb(k, lengths, gaps, offsets, deadline):
    best_A = _build(k, lengths, gaps, offsets)
    best_s = _score(best_A)

    cur_l = lengths[:]
    cur_g = gaps[:]
    cur_o = offsets[:]

    # Deterministic sweep with progressively refined step sizes
    steps_g = [1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
    steps_o = [1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233]

    while time.time() < deadline:
        improved = False
        # tune gaps
        for i in range(k):
            for st in steps_g:
                for sign in (1, -1):
                    cand_g = cur_g[:]
                    cand_g[i] = cand_g[i] + sign * st
                    if cand_g[i] < 1:
                        continue
                    cand_o = cur_o[:]
                    # offsets must stay small and distinct-ish; rescale keeping structure
                    A = _build(k, cur_l, cand_g, cand_o)
                    s = _score(A)
                    if s > best_s:
                        best_s = s
                        best_A = A
                        cur_g = cand_g
                        improved = True
                        break
                if improved and st == steps_g[0]:
                    pass
        # tune offsets
        for i in range(k):
            for st in steps_o:
                for sign in (1, -1):
                    cand_o = cur_o[:]
                    cand_o[i] = cand_o[i] + sign * st
                    A = _build(k, cur_l, cur_g, cand_o)
                    s = _score(A)
                    if s > best_s:
                        best_s = s
                        best_A = A
                        cur_o = cand_o
                        improved = True
                        break
        # tune lengths (small changes)
        for i in range(k):
            for dl in (1, -1, 2, -2):
                nl = cur_l[i] + dl
                if nl < 2 or nl > 8:
                    continue
                cand_l = cur_l[:]
                cand_l[i] = nl
                A = _build(k, cand_l, cur_g, cur_o)
                s = _score(A)
                if s > best_s:
                    best_s = s
                    best_A = A
                    cur_l = cand_l
                    improved = True
                    break
        if not improved:
            # try a different k-shape by shrinking gaps to collide more
            changed = False
            for i in range(k):
                if cur_g[i] > 1:
                    cand_g = cur_g[:]
                    cand_g[i] = max(1, cur_g[i] // 2)
                    A = _build(k, cur_l, cand_g, cur_o)
                    s = _score(A)
                    if s > best_s:
                        best_s = s
                        best_A = A
                        cur_g = cand_g
                        changed = True
                        break
            if not changed:
                break

    return best_A, best_s


def solve():
    deadline = time.time() + 100  # leave margin

    best_A = None
    best_s = -1.0

    # Try several deterministic starting configurations.
    starts = []
    # nested geometric gaps, zero offsets
    for base in (2, 3, 4):
        for k in (4, 5, 6, 7):
            lengths = [4] * k
            gaps = [base ** i for i in range(k)]
            offsets = [0] * k
            starts.append((k, lengths, gaps, offsets))
    # power-of-two with staggered offsets
    for k in (5, 6, 7):
        lengths = [4] * k
        gaps = [2 ** i for i in range(k)]
        offsets = [i * 3 for i in range(k)]
        starts.append((k, lengths, gaps, offsets))
    # same-gap clusters (heavy sum collisions)
    for k in (6, 7, 8):
        lengths = [5] * k
        gaps = [1] * k
        offsets = [2 * i for i in range(k)]
        starts.append((k, lengths, gaps, offsets))

    per_start = max(2.0, (deadline - time.time()) / max(1, len(starts)))
    for (k, l, g, o) in starts:
        if time.time() > deadline:
            break
        sub_deadline = min(deadline, time.time() + per_start)
        A, s = _hill_climb(k, l, g, o, sub_deadline)
        if s > best_s:
            best_s = s
            best_A = A

    if best_A is None:
        best_A = [0, 1, 2, 3, 4]

    # Final safety: dedupe and clamp
    best_A = sorted(set(int(x) for x in best_A))
    best_A = [x for x in best_A if abs(x) <= 10 ** 15][:4000]
    if len(best_A) < 2:
        best_A = [0, 1]
    return best_A
# EVOLVE-BLOCK-END
