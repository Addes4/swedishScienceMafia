# EVOLVE-BLOCK-START
"""Mixed-radix digit construction with fast scoring and digit-set hill-climb."""
import math
import time
import itertools
import numpy as np


def _counts_fast(a):
    """Exact |A-A| and |A+A| for int64 array, chunked to bound memory."""
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0
    diffs = set()
    sums = set()
    # chunk rows to keep memory bounded
    chunk = max(1, min(n, 2000000 // max(n, 1)))
    for i in range(0, n, chunk):
        blk = a[i:i + chunk]
        d = (blk[:, None] - a[None, :]).ravel()
        s = (blk[:, None] + a[None, :]).ravel()
        diffs.update(np.unique(d).tolist())
        sums.update(np.unique(s).tolist())
        if len(diffs) > 10**7 or len(sums) > 10**7:
            break
    return len(diffs), len(sums)


def _counts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0
    if n <= 1500:
        d = (a[:, None] - a[None, :]).ravel()
        s = (a[:, None] + a[None, :]).ravel()
        return np.unique(d).size, np.unique(s).size
    return _counts_fast(a)


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return -1.0
    diffs, sums = _counts(a)
    if sums < 2 or diffs < 2:
        return -1.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _digit_stats(D):
    D = list(D)
    dd = set()
    ss = set()
    for x in D:
        for y in D:
            dd.add(x - y)
            ss.add(x + y)
    return len(dd), len(ss)


def _search_digit_sets(deadline):
    """Find small digit sets with high log|D-D|/log|D+D| ratio."""
    cands = []
    seen = {}

    def consider(D):
        key = tuple(sorted(set(D)))
        if key in seen:
            return
        ndd, nss = _digit_stats(key)
        if nss < 2 or ndd < 2:
            return
        ldd = math.log(ndd)
        lss = math.log(nss)
        seen[key] = (ldd / lss, ldd, lss, len(key), list(key))
        cands.append(seen[key])

    universe = list(range(14))
    for sz in range(2, 6):
        if time.time() > deadline:
            break
        for comb in itertools.combinations(universe, sz):
            consider(comb)

    cands.sort(reverse=True, key=lambda t: t[0])
    beam = [t[4] for t in cands[:250]]
    for sz in range(6, 10):
        if time.time() > deadline:
            break
        for D in beam:
            mx = max(D)
            for v in range(0, mx + 5):
                if v in D:
                    continue
                consider(D + [v])
        cands.sort(reverse=True, key=lambda t: t[0])
        beam = [t[4] for t in cands[:250]]
        if not beam:
            break

    # Raw ldd-favouring beam (sum-poor / Bohr-style).
    raw = []

    def raw_consider(D):
        key = tuple(sorted(set(D)))
        ndd, nss = _digit_stats(key)
        if nss < 2 or ndd < 2:
            return
        ldd = math.log(ndd)
        lss = math.log(nss)
        raw.append((ldd - 0.45 * lss, ldd, lss, len(key), list(key)))

    uni2 = list(range(16))
    seen2 = set()
    for sz in range(2, 6):
        if time.time() > deadline:
            break
        for comb in itertools.combinations(uni2, sz):
            k = tuple(comb)
            if k not in seen2:
                seen2.add(k)
                raw_consider(comb)
    raw.sort(reverse=True, key=lambda t: t[0])
    beam2 = [t[4] for t in raw[:200]]
    for sz in range(6, 11):
        if time.time() > deadline:
            break
        for D in beam2:
            mx = max(D)
            for v in range(0, mx + 4):
                if v in D:
                    continue
                raw_consider(D + [v])
        raw.sort(reverse=True, key=lambda t: t[0])
        nb = []
        seenk = set()
        for t in raw:
            k = tuple(t[4])
            if k in seenk:
                continue
            seenk.add(k)
            nb.append(t)
            if len(nb) >= 200:
                break
        beam2 = [t[4] for t in nb]
        if not beam2:
            break
    for (_, ldd, lss, sz, D) in raw[:400]:
        cands.append((ldd / lss, ldd, lss, sz, D))

    dd = {}
    for c in cands:
        k = tuple(c[4])
        if k not in dd or c[0] > dd[k][0]:
            dd[k] = c
    out = list(dd.values())
    out.sort(reverse=True, key=lambda t: t[0])
    return out


def _build_mixed(levels, B):
    A = np.array([0], dtype=np.int64)
    pw = 1
    for D in levels:
        Darr = np.asarray(sorted(set(D)), dtype=np.int64)
        # outer sum: A + d*pw for all a in A, d in D
        A = (A[:, None] + (Darr[None, :] * pw)).ravel()
        pw *= B
    return np.unique(A)


def _span(D):
    return max(D) - min(D)


def solve():
    deadline = time.time() + 105
    best = None
    best_score = -1.0

    dig = _search_digit_sets(deadline)
    if not dig:
        return [0, 1]

    sets = dig  # (ratio, ldd, lss, size, D)
    pool = list(sets[:400])
    for s in sorted(sets, key=lambda t: t[1], reverse=True)[:150]:
        pool.append(s)
    for s in sorted(sets, key=lambda t: t[1] - 0.45 * t[2], reverse=True)[:150]:
        pool.append(s)
    pd = {}
    for s in pool:
        pd[tuple(s[4])] = s
    pool = list(pd.values())
    pool_by_ratio = sorted(pool, key=lambda t: t[0], reverse=True)

    def build_and_score(levels):
        if not levels:
            return None, -1.0
        span = max(_span(D) for D in levels)
        B = max(2 * span + 1, 2)
        lv = list(levels)
        while lv:
            A = _build_mixed(lv, B)
            if A.size < 2:
                lv.pop()
                continue
            if np.max(np.abs(A)) <= 10**15 and A.size <= 4000:
                return A, _score(A)
            lv.pop()
            if lv:
                span = max(_span(D) for D in lv)
                B = max(2 * span + 1, 2)
        return None, -1.0

    # Beam over level sequences.
    beam_states = []
    for (r, ldd, lss, sz, D) in sets[:40]:
        beam_states.append((ldd, lss, sz, [D]))

    def cum_ratio(st):
        return st[0] / st[1]

    beam_states.sort(key=cum_ratio, reverse=True)
    best_levels = None
    best_ratio = -1.0
    max_states = 200
    B_cand = pool_by_ratio
    for step in range(30):
        if time.time() > deadline:
            break
        newstates = []
        for (cldd, clss, size, levels) in beam_states:
            added = 0
            for (r, ldd, lss, sz, D) in B_cand:
                if size * sz > 4000:
                    continue
                newstates.append((cldd + ldd, clss + lss, size * sz, levels + [D]))
                added += 1
                if added >= 60:
                    break
        if not newstates:
            break
        newstates.sort(key=cum_ratio, reverse=True)
        beam_states = newstates[:max_states]
        for st in beam_states[:20]:
            r = cum_ratio(st)
            if r > best_ratio:
                best_ratio = r
                best_levels = st[3]

    cand_level_seqs = []
    if best_levels:
        cand_level_seqs.append(best_levels)
    for st in beam_states[:300]:
        cand_level_seqs.append(st[3])

    for (seed_r, seed_ldd, seed_lss, seed_sz, seed_D) in sets[:60]:
        cum_ldd = seed_ldd
        cum_lss = seed_lss
        size = seed_sz
        levels = [seed_D]
        while size <= 4000:
            best_gain = None
            for (r, ldd, lss, sz, D) in pool_by_ratio:
                if size * sz > 4000:
                    continue
                new_r = (cum_ldd + ldd) / (cum_lss + lss)
                if new_r > cum_ldd / cum_lss + 1e-12:
                    if best_gain is None or new_r > best_gain[0]:
                        best_gain = (new_r, ldd, lss, sz, D)
            if best_gain is None:
                break
            _, ldd, lss, sz, D = best_gain
            cum_ldd += ldd
            cum_lss += lss
            size *= sz
            levels.append(D)
            if time.time() > deadline:
                break
        cand_level_seqs.append(levels)

    for levels in cand_level_seqs:
        A, sc = build_and_score(levels)
        if A is not None and sc > best_score:
            best_score = sc
            best = A.tolist()
        if time.time() > deadline:
            break

    if best is None:
        best = [0, 1]

    # Time-bounded boundary refinement.
    a = sorted(set(int(x) for x in best))
    improved = True
    rounds = 0
    while improved and rounds < 25 and time.time() < deadline:
        improved = False
        rounds += 1
        base_arr = np.array(a, dtype=np.int64)
        cand_adds = []
        lo, hi = a[0], a[-1]
        cand_adds.append(hi + 1)
        cand_adds.append(lo - 1)
        diffs = np.diff(base_arr)
        if diffs.size:
            gi = int(np.argmax(diffs))
            cand_adds.append(int(a[gi]) + int(diffs[gi]) // 2)
        for c in cand_adds:
            if len(a) >= 4000:
                break
            trial = np.array(sorted(set(a + [c])), dtype=np.int64)
            sc = _score(trial)
            if sc > best_score:
                best_score = sc
                a = trial.tolist()
                improved = True
                break
        if improved:
            continue
        for idx in (0, len(a) - 1):
            if len(a) <= 2:
                break
            trial_list = a[:idx] + a[idx + 1:]
            trial = np.array(trial_list, dtype=np.int64)
            sc = _score(trial)
            if sc > best_score:
                best_score = sc
                a = trial_list
                improved = True
                break

    return sorted(set(int(x) for x in a))
# EVOLVE-BLOCK-END
