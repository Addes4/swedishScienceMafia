# EVOLVE-BLOCK-START
"""Sets with many differences and few sums.

Strategy: the carry-free digit-set construction gives ratio = ratio(D).  To beat
it we deliberately introduce *carries*: sums of digit combinations are allowed to
collide more than differences.  We build A as a base-B expansion of a digit set D
where B is chosen small enough that D+D has overlaps, then run a fast exact
hill-climb (numpy bincount scorer) on the full set A, seeded from the digit-set
construction.  We keep the best scoring set found.
"""
import time
import numpy as np


def _score_arrays(arr):
    """Exact |X-X|, |X+X| using bincount on shifted arrays."""
    v = np.unique(np.asarray(arr, dtype=np.int64))
    if v.size < 2:
        return -1.0, 0, 0
    lo = int(v.min())
    hi = int(v.max())
    s = (v[:, None] + v[None, :]).ravel()
    d = (v[:, None] - v[None, :]).ravel()
    ns = int(np.unique(s).size)
    nd = int(np.unique(d).size)
    if ns <= 1 or nd <= 1:
        return -1.0, nd, ns
    n = v.size
    val = np.log(nd) / np.log(ns) + (1.0 - 1.0 / n) / 100.0
    return val, nd, ns


def _ratio(D):
    D = np.unique(np.asarray(D, dtype=np.int64))
    if D.size < 2:
        return -1.0
    s = (D[:, None] + D[None, :]).ravel()
    d = (D[:, None] - D[None, :]).ravel()
    ns = int(np.unique(s).size)
    nd = int(np.unique(d).size)
    if ns <= 1 or nd <= 1:
        return -1.0
    return np.log(nd) / np.log(ns)


def _build_A(D, B, m):
    D = np.unique(np.asarray(D, dtype=np.int64))
    cur = np.zeros(1, dtype=np.int64)
    pw = 1
    for i in range(m):
        cur = (cur[:, None] + D[None, :] * pw).ravel()
        pw *= B
    return np.unique(cur)


def solve():
    deadline = time.time() + 112.0
    rng = np.random.default_rng(424242)

    # ---- Small digit-set search (carry-free ideal) ----
    best_D = [0, 1, 4, 9]
    best_dr = _ratio(best_D)
    for R in (7, 8, 9, 10, 12, 14, 16):
        for _ in range(300):
            k = int(rng.integers(3, min(R, 7) + 1))
            vals = sorted(rng.choice(R, size=k, replace=False).tolist())
            r = _ratio(vals)
            if r > best_dr:
                best_dr = r
                best_D = vals
    # local search on D
    improved = True
    while improved and time.time() < deadline - 60:
        improved = False
        for i in range(len(best_D)):
            for delta in (-2, -1, 1, 2, 3, 4):
                t = best_D[:]
                t[i] += delta
                if min(t) < 0 or max(t) > 60:
                    continue
                r = _ratio(t)
                if r > best_dr + 1e-12:
                    best_dr = r
                    best_D = sorted(set(t))
                    improved = True

    D = np.unique(np.asarray(best_D, dtype=np.int64))
    dsize = D.size
    spread = int(D.max() - D.min())

    # ---- Collect candidate full sets A and score exactly ----
    best_val = -1.0
    best_A = None

    candidates = []

    # Carry-free expansions with base > spread and with smaller (carry) bases
    base_choices = set()
    for B in range(max(spread + 1, 2), spread + 1 + 6):
        base_choices.add(B)
    for B in range(2, max(3, spread + 1)):
        base_choices.add(B)
    for B in (spread * 2 + 1, spread * 2 + 3, 10, 11, 12):
        if B >= 2:
            base_choices.add(B)

    max_elems = 4000
    for B in sorted(base_choices):
        # max m with |D|^m <= 4000 and values <= 1e15
        m = 1
        while dsize ** (m + 1) <= max_elems:
            m += 1
        # value bound
        while m > 1 and (B ** (m - 1)) * (int(D.max()) + spread) > 10**15:
            m -= 1
        for mm in range(1, m + 1):
            if time.time() > deadline - 40:
                break
            A = _build_A(D, B, mm)
            candidates.append(A)

    # direct short sets to seed hill climb
    for A in candidates:
        v, nd, ns = _score_arrays(A)
        if v > best_val:
            best_val = v
            best_A = A

    # ---- Hill-climb on full set A (structured moves) ----
    if best_A is None:
        best_A = np.array([0, 1, 4, 9, 24, 36], dtype=np.int64)

    # Try adding/removing points to increase the score
    def climb(A, iters):
        nonlocal best_val, best_A
        A = np.unique(A)
        cur_v = _score_arrays(A)[0]
        for _ in range(iters):
            if time.time() > deadline:
                break
            trial = A.copy()
            r = rng.random()
            if r < 0.5 and trial.size > 3:
                # remove a random element
                idx = int(rng.integers(0, trial.size))
                trial = np.delete(trial, idx)
            else:
                # add a nearby element
                base = int(trial[rng.integers(0, trial.size)])
                span = max(1, int(trial.max() - trial.min()))
                cand = base + int(rng.integers(-span // max(1, trial.size), span // max(1, trial.size) + 1))
                if abs(cand) <= 10**15:
                    trial = np.append(trial, cand)
            trial = np.unique(trial)
            if trial.size > 4000:
                continue
            v = _score_arrays(trial)[0]
            if v > cur_v:
                cur_v = v
                A = trial
        return A, cur_v

    # hill-climb from the best found construction (limited iterations)
    A_climb, v_climb = climb(best_A, 4000)
    if v_climb > best_val:
        best_val = v_climb
        best_A = A_climb

    best_A = np.unique(best_A)
    return [int(x) for x in best_A]
# EVOLVE-BLOCK-END
