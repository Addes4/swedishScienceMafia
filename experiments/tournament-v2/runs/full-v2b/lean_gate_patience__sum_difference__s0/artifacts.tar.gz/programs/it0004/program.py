# EVOLVE-BLOCK-START
"""Search for sets with many differences and few sums via greedy + annealing refinement."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _counts(a):
    a = list(set(a))
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums)


def _score_fast(d, s, n):
    if n < 2 or s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _greedy_seed(rng, base, bits, size):
    # Build set from base-`base` digits over a limited digit set to control sum collisions.
    digits = [0, 1]
    if base >= 3:
        digits = [0, 1, base]
    A = set()
    # generate many candidates of form sum d_i * base^i
    cand = [0]
    pow_b = 1
    for _ in range(bits):
        new = set()
        for c in cand:
            for d in digits:
                new.add(c + d * pow_b)
        cand = list(new)
        pow_b *= base
    rng.shuffle(cand)
    return cand[:size]


def solve():
    deadline = time.time() + 110
    rng = random.Random(12345)

    best = None
    best_score = -1.0

    # Try several structured seeds and refine each.
    configs = [(3, 8, 30), (4, 7, 40), (5, 6, 50), (7, 5, 60), (10, 4, 80)]
    while time.time() < deadline:
        for base, bits, size in configs:
            if time.time() >= deadline:
                break
            cand = _greedy_seed(rng, base, bits, size)
            n = len(cand)
            if n < 2:
                continue
            d, s = _counts(cand)
            cs = _score_fast(d, s, n)
            cur = list(cand)
            cur_d, cur_s = d, s
            cur_score = cs
            local_deadline = min(deadline, time.time() + 18)
            T = 1.0
            while time.time() < local_deadline:
                T *= 0.9995
                move = rng.random()
                new = cur[:]
                if move < 0.6:
                    # perturb an element
                    i = rng.randrange(len(new))
                    new[i] += rng.randint(-3, 3)
                elif move < 0.85:
                    # add a new element near existing ones
                    base_el = rng.choice(new)
                    new.append(base_el + rng.randint(-5, 5))
                else:
                    if len(new) > 3:
                        new.pop(rng.randrange(len(new)))
                new = list(set(new))
                if len(new) < 2:
                    continue
                nd, ns = _counts(new)
                ns2 = _score_fast(nd, ns, len(new))
                if ns2 >= cur_score or rng.random() < math.exp((ns2 - cur_score) / max(T, 1e-6)):
                    cur, cur_d, cur_s, cur_score = new, nd, ns, ns2
            if cur_score > best_score:
                best_score = cur_score
                best = 1.0 * 0 + cur[:]
                best = list(cur)
        if best is not None and time.time() >= deadline:
            break
        if best is not None:
            # after one full sweep, keep refining the best with remaining time
            break

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    # Final refinement on best
    cur = list(best)
    d, s = _counts(cur)
    cur_score = _score_fast(d, s, len(cur))
    while time.time() < deadline:
        new = cur[:]
        i = rng.randrange(len(new))
        new[i] += rng.randint(-2, 2)
        if rng.random() < 0.05:
            new.append(rng.choice(new) + rng.randint(-4, 4))
        if rng.random() < 0.05 and len(new) > 4:
            new.pop(rng.randrange(len(new)))
        new = list(set(new))
        if len(new) < 2:
            continue
        nd, ns = _counts(new)
        ns2 = _score_fast(nd, ns, len(new))
        if ns2 >= cur_score:
            cur, cur_score = new, ns2
        if cur_score > best_score:
            best_score = cur_score
            best = cur[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
