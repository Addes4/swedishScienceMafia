# EVOLVE-BLOCK-START
"""Structured construction (small sum set, large difference set) + local search."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build(base, digits, k):
    """Numbers whose base-`base` digits are drawn from `digits`."""
    A = [0]
    for _ in range(k):
        A = [x + d * (base ** _) for x in A for d in digits]
    return A


def solve():
    """Return distinct integers A making |A-A| large and |A+A| small."""
    best = None
    best_score = -1.0

    # Try several digit constructions: D small but D+D very small vs D-D large.
    candidates = [
        (5, [0, 1, 2], 6),
        (7, [0, 1, 2], 5),
        (11, [0, 1, 2], 4),
        (8, [0, 1, 3], 4),
        (13, [0, 1, 3], 4),
        (16, [0, 1, 2, 4], 3),
        (100, [0, 1, 3], 3),
        (1000, [0, 1, 2], 3),
        (10000, [0, 1, 3], 2),
    ]
    for base, digits, k in candidates:
        A = _build(base, digits, k)
        A = list(set(A))
        if len(A) < 2 or len(A) > 4000:
            continue
        s = _score(A)
        if s > best_score:
            best, best_score = A, s

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    cur = best[:]
    deadline = time.time() + 100
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.6 or len(cand) < 3:
            # perturb a coordinate
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1]) * random.randint(1, 5)
        elif r < 0.85 and len(cand) < 3800:
            # add a new element near the current range
            span = max(cand) - min(cand)
            cand.append(random.randint(min(cand), max(cand)))
        else:
            if len(cand) > 3:
                idx = random.randrange(len(cand))
                cand.pop(idx)
        cand = list(set(cand))
        if len(cand) > 4000 or len(cand) < 2:
            continue
        if max(abs(x) for x in cand) > 10 ** 15:
            continue
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.15:
            cur = best[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END

