# EVOLVE-BLOCK-START
"""Greedy incremental construction maximizing log|A-A|/log|A+A|."""
import math
import time


def _score_counts(nd, ns, n):
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _counts(A):
    s = set(A)
    diffs = set()
    sums = set()
    L = list(s)
    for i in range(len(L)):
        ai = L[i]
        for j in range(len(L)):
            bj = L[j]
            diffs.add(ai - bj)
            sums.add(ai + bj)
    return len(diffs), len(sums)


def _eval(A):
    n = len(A)
    if n < 3:
        return 0.0, 0, 0
    nd, ns = _counts(A)
    return _score_counts(nd, ns, n), nd, ns


def solve():
    deadline = time.time() + 105.0

    best_A = [0, 1]
    best_score = 0.0

    def consider(A):
        nonlocal best_A, best_score
        A = set(A)
        n = len(A)
        if n < 3 or n > 4000:
            return
        s, _, _ = _eval(A)
        if s > best_score:
            best_score = s
            best_A = sorted(A)

    # Greedy construction: grow a set by adding the candidate that best improves score.
    # Candidates are chosen from several structured families so sums collide.
    def greedy(seed, candidates):
        A = set(seed)
        cur = _eval(A)[0]
        cand = list(dict.fromkeys(candidates))
        improved = True
        while improved and time.time() < deadline and len(A) < 4000:
            improved = False
            best_c = None
            best_s = cur
            for c in cand:
                if c in A:
                    continue
                trial = A | {c}
                s, _, _ = _eval(trial)
                if s > best_s + 1e-12:
                    best_s = s
                    best_c = c
            if best_c is not None:
                A.add(best_c)
                cur = best_s
                improved = True
            if time.time() > deadline:
                break
            # Refresh candidate pool: add translates/sums of current A.
            new_c = set()
            L = list(A)
            for x in L:
                for d in (1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6, 7, -7, 8, -8,
                          10, -10, 12, -12, 16, -16):
                    new_c.add(x + d)
            for i in range(min(len(L), 30)):
                for j in range(i + 1, min(len(L), 30)):
                    new_c.add(L[i] + L[j])
            cand = list(new_c)
        return A, cur

    # Seed families
    seeds = []
    for L in (6, 8, 10, 12, 16):
        seeds.append(list(range(L)))
        seeds.append([2 * k for k in range(L)])

    for seed in seeds:
        if time.time() > deadline:
            break
        A, s = greedy(seed, [x for x in range(-40, 60)])
        consider(A)
        if time.time() > deadline:
            break

    # Union-of-translates construction: A = C + T with compact C, wide T.
    for Lc in (10, 14, 20, 30):
        C = list(range(Lc))
        for spreads in ([1000, 100000, 10 ** 7], [5000, 300000]):
            for m in (3, 4, 5, 6):
                if time.time() > deadline:
                    break
                base = spreads[0] if len(spreads) > 0 else 1000
                T = []
                v = 0
                for k in range(m):
                    step = (spreads[k % len(spreads)])
                    T.append(v)
                    v += step
                A = set()
                for t in T:
                    for c in C:
                        A.add(c + t)
                consider(A)
        if time.time() > deadline:
            break

    # Targeted polish: element add/remove on the best set.
    if best_A and time.time() < deadline:
        A = set(best_A)
        cur = _eval(A)[0]
        improved = True
        while improved and time.time() < deadline:
            improved = False
            # removals
            for x in list(A):
                if time.time() > deadline:
                    break
                trial = A - {x}
                if len(trial) < 3:
                    continue
                s, _, _ = _eval(trial)
                if s > cur + 1e-12:
                    A = trial
                    cur = s
                    improved = True
                    break
            if improved:
                continue
            # additions
            L = list(A)
            cand = set()
            for x in L:
                for d in (1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6, 7, -7, 8, -8,
                          10, -10, 12, -12):
                    cand.add(x + d)
            for x in cand:
                if time.time() > deadline:
                    break
                if x in A:
                    continue
                s, _, _ = _eval(A | {x})
                if s > cur + 1e-12:
                    A.add(x)
                    cur = s
                    improved = True
                    break
        if cur > best_score:
            best_score = cur
            best_A = sorted(A)

    best_A = sorted(set(best_A))
    if len(best_A) < 2:
        best_A = [0, 1]
    return best_A
# EVOLVE-BLOCK-END
