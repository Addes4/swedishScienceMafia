# EVOLVE-BLOCK-START
"""Digit-set construction with flexible base, scored on the true objective.

The set A is built as a base-B expansion of a digit set D:
    A = { sum_i d_i B^i : d_i in D },   |A| <= 4000.
Choosing B just above the spread of D-D makes the decomposition carry-free,
giving |A-A| = |D-D|^m and |A+A| = |D+D|^m.  But finite bases can also
produce useful collisions, so we search over several bases and lengths and
score the *actual* objective of the resulting A.
"""
import time
import itertools
import numpy as np


def _ndiff_nsum(vals):
    """Exact |X-X| and |X+X| for a set of int64 values."""
    v = np.unique(np.asarray(vals, dtype=np.int64))
    if v.size == 0:
        return 0, 0
    # differences
    d = (v[:, None] - v[None, :]).ravel()
    nd = int(np.unique(d).size)
    # sums: shift to avoid overflow is unnecessary for our magnitudes
    s = (v[:, None] + v[None, :]).ravel()
    ns = int(np.unique(s).size)
    return nd, ns


def _ratio_score(vals):
    nd, ns = _ndiff_nsum(vals)
    if ns <= 1 or nd <= 1:
        return -1.0
    n = len(np.unique(vals))
    return np.log(nd) / np.log(ns) + (1.0 - 1.0 / n) / 100.0


def _build_A(D, B, m):
    """Return sorted unique A = digit set expanded to m positions."""
    D = np.unique(np.asarray(D, dtype=np.int64))
    cur = np.zeros(1, dtype=np.int64)
    p = np.int64(1)
    for i in range(m):
        cur = (cur[:, None] + D[None, :] * p).ravel()
        cur = np.unique(cur)
        p *= B
    return cur


def _search_D(time_deadline, rng):
    """Search for a digit set D maximizing log|D-D|/log|D+D|."""
    best_D = None
    best_r = -1.0

    def consider(vals):
        nonlocal best_D, best_r
        vals = sorted(set(int(x) for x in vals))
        if len(vals) < 2:
            return
        mn = min(vals)
        vals = [x - mn for x in vals]
        if vals[-1] > 4000:
            return
        r = _ratio_score(vals)
        if r > best_r:
            best_r = r
            best_D = vals

    # Deterministic exhaustive over small digit sets.
    for R in (6, 8, 10, 12, 14, 16):
        for k in (3, 4, 5):
            if k > R:
                continue
            for combo in itertools.combinations(range(R), k):
                consider(list(combo))
        if time.time() > time_deadline:
            break

    # Random restarts.
    for _ in range(2000):
        if time.time() > time_deadline:
            break
        R = int(rng.integers(8, 30))
        k = int(rng.integers(3, min(R, 8)))
        vals = sorted(rng.choice(R, size=k, replace=False).tolist())
        consider(vals)

    # Greedy local improvement.
    improved = True
    guard = 0
    while improved and time.time() < time_deadline and guard < 200:
        improved = False
        guard += 1
        cur_D = best_D
        if cur_D is None:
            break
        for i in range(len(cur_D)):
            for delta in (-4, -3, -2, -1, 1, 2, 3, 4, 5, 6):
                trial = cur_D[:]
                trial[i] += delta
                if min(trial) < 0 or max(trial) > 4000:
                    continue
                r = _ratio_score(trial)
                if r > best_r + 1e-12:
                    best_r = r
                    best_D = sorted(set(trial))
                    improved = True
        for _ in range(40):
            if time.time() > time_deadline:
                break
            trial = list(best_D)
            if rng.random() < 0.5:
                trial.append(int(rng.integers(0, 60)))
            else:
                if len(trial) > 3:
                    trial.pop(int(rng.integers(0, len(trial))))
            r = _ratio_score(trial)
            if r > best_r + 1e-12:
                best_r = r
                best_D = sorted(set(trial))
                improved = True
    return best_D, best_r


def solve():
    deadline = time.time() + 112.0
    rng = np.random.default_rng(12345)

    search_deadline = time.time() + 55.0
    D, dr = _search_D(search_deadline, rng)
    if D is None:
        D = [0, 1, 4, 9]

    D = np.unique(np.asarray(D, dtype=np.int64))
    dsize = int(D.size)
    spread = int(D.max() - D.min())
    dmax = int(D.max())

    max_elems = 4000
    limit_val = 10**15

    # Candidate bases: carry-free (spread+1) and a range around it.
    base_candidates = set()
    for b in (spread + 1, spread + 2, 2 * spread + 1, 2 * spread + 3,
              3 * spread + 5, dmax + 1, 2 * dmax + 3):
        if b >= 2:
            base_candidates.add(int(b))
    for _ in range(6):
        base_candidates.add(int(rng.integers(max(2, spread + 1), 4 * spread + 20)))

    best_A = None
    best_val = -1.0

    def evaluate(A):
        nonlocal best_A, best_val
        A = np.unique(np.asarray(A, dtype=np.int64))
        n = int(A.size)
        if n < 2:
            return
        nd, ns = _ndiff_nsum(A)
        if ns <= 1:
            return
        val = np.log(nd) / np.log(ns) + (1.0 - 1.0 / n) / 100.0
        if val > best_val:
            best_val = val
            best_A = A

    for B in sorted(base_candidates):
        if time.time() > deadline:
            break
        # Largest m with dsize^m <= 4000 and values <= limit_val.
        m = 1
        while dsize ** (m + 1) <= max_elems:
            m += 1
        # clamp by value limit
        while m > 1:
            top = (B ** (m - 1)) * dmax
            if top <= limit_val:
                break
            m -= 1
        for mm in range(1, m + 1):
            if time.time() > deadline:
                break
            A = _build_A(D, B, mm)
            if A.size > max_elems:
                # too many: subsample not allowed; skip
                continue
            evaluate(A)

    if best_A is None:
        best_A = np.array([0, 1, 4, 9, 24, 36], dtype=np.int64)

    best_A = np.unique(best_A)
    return [int(x) for x in best_A]
# EVOLVE-BLOCK-END
