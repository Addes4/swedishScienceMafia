# EVOLVE-BLOCK-START
"""Digit-set construction: A = { sum d_i B^i : d_i in D }, B large (no carries).

If B > 2*max|D|*(number of positions) ensures no carry interactions, then
  |A - A| = |D - D|^m   and   |A + A| = |D + D|^m   (m = number of positions),
so log|A-A|/log|A+A| = log|D-D|/log|D+D|, and larger m only improves the bonus.
We search for a digit set D minimizing |D+D| while keeping |D-D| large.
"""
import math
import time
import random
import numpy as np

TIME_LIMIT = 100.0


def _counts(d):
    arr = np.asarray(d, dtype=np.int64)
    nd = int(np.unique(arr[:, None] - arr[None, :]).size)
    ns = int(np.unique(arr[:, None] + arr[None, :]).size)
    return nd, ns


def _ratio(nd, ns):
    if ns <= 1 or nd <= 1:
        return -1.0
    return math.log(nd) / math.log(ns)


def _full_score(nd, ns, n):
    if ns <= 1 or nd <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _anneal_D(seed, budget_iters, rng, lo=-40, hi=40):
    """Simulated annealing on digit set D (as a set)."""
    cur = sorted(set(seed))
    nd, ns = _counts(cur)
    cur_r = _ratio(nd, ns)
    best = cur[:]
    best_r = cur_r
    T = 0.05
    for it in range(budget_iters):
        T = 0.05 * (1.0 - it / max(1, budget_iters)) + 0.001
        cand = cur[:]
        op = rng.random()
        if op < 0.4 and len(cand) > 2:
            # remove a random element
            del cand[rng.randrange(len(cand))]
        elif op < 0.85:
            # add a new element
            v = rng.randint(lo, hi)
            if v not in cand:
                cand.append(v)
        else:
            # perturb an element
            i = rng.randrange(len(cand))
            cand[i] = cand[i] + rng.choice([-2, -1, 1, 2])
        cand = sorted(set(cand))
        if len(cand) < 2 or len(cand) > 60:
            continue
        if max(abs(x) for x in cand) > hi:
            continue
        nd2, ns2 = _counts(cand)
        r2 = _ratio(nd2, ns2)
        if r2 >= cur_r or rng.random() < math.exp((r2 - cur_r) / T):
            cur, cur_r = cand, r2
            if r2 > best_r:
                best, best_r = cand[:], r2
    return best, best_r


def _expand(D, max_positions=5):
    """Represent A as base-B digit set; return A (list of ints)."""
    D = sorted(set(D))
    if len(D) < 2:
        return D
    span = max(D) - min(D)
    dmax = max(abs(x) for x in D)
    # choose positions m as large as possible within element count and range
    m = 1
    while len(D) ** (m + 1) <= 4000:
        m += 1
    # bound value: need B large enough to avoid carries; B > 2*dmax*m
    B = 2 * dmax * m + 3
    # ensure value bound
    while abs(B) ** m * (dmax + 1) > 10**15 and m > 1:
        m -= 1
        B = 2 * dmax * m + 3
    if m < 1:
        m = 1
        B = 2 * dmax + 3
    A = [0]
    for _ in range(m):
        newA = []
        for a in A:
            for x in D:
                newA.append(a * B + x)
        A = newA
        if len(A) > 4000:
            break
    return sorted(set(int(v) for v in A))


def solve():
    start = time.time()
    rng = random.Random(12345)

    seeds = [
        [0, 1, 2, 3, 4, 5, 6, 7],
        [0, 1, 2, 4, 8, 16, 32],
        [0, 1, 3, 9, 27],
        [0, 1, 2, 4, 5, 8, 9, 10],
        [0, 1, 2, 3, 5, 8, 13],
        [0, 1, 2, 3, 4, 6, 7, 8],
        [0, 2, 4, 6, 8],
        [0, 1, 2, 3, 5, 7, 11, 13],
    ]

    best_D = None
    best_r = -1.0

    # Deterministic small exhaustive-ish: try all subsets is too many; instead
    # hill-climb + anneal from many seeds.
    for s in seeds:
        # quick local improvement
        cur = sorted(set(s))
        nd, ns = _counts(cur)
        cur_r = _ratio(nd, ns)
        improved = True
        while improved:
            improved = False
            for op in range(3):
                pass
            for v in range(-30, 31):
                if v in cur:
                    continue
                cand = sorted(cur + [v])
                if len(cand) > 40:
                    continue
                nd2, ns2 = _counts(cand)
                r2 = _ratio(nd2, ns2)
                if r2 > cur_r:
                    cur, cur_r, improved = cand, r2, True
            for i in range(len(cur)):
                for delta in (-2, -1, 1, 2):
                    cand = cur[:]
                    cand[i] += delta
                    cand = sorted(set(cand))
                    if len(cand) < 2:
                        continue
                    nd2, ns2 = _counts(cand)
                    r2 = _ratio(nd2, ns2)
                    if r2 > cur_r:
                        cur, cur_r, improved = cand, r2, True
        if cur_r > best_r:
            best_D, best_r = cur[:], cur_r

    # Anneal from the current best with a budget.
    while time.time() - start < TIME_LIMIT * 0.7:
        D, r = _anneal_D(best_D if best_D else seeds[0], 4000, rng)
        if r > best_r:
            best_D, best_r = D[:], r
        else:
            D2, r2 = _anneal_D([0, 1, 2, 3, 4, 5, 6, 7], 2000, rng)
            if r2 > best_r:
                best_D, best_r = D2[:], r2

    if best_D is None:
        best_D = [0, 1, 2, 3, 4, 5, 6, 7]

    # Expand the best D at several digit-count levels; pick the best full score.
    A = _expand(best_D, max_positions=5)
    A = sorted(set(int(x) for x in A))
    nd, ns = _counts(A)
    best_set, best_score = A, _full_score(nd, ns, len(A))

    # Fallback base-2-ish large set if something is off.
    lim = 10**15
    if (not best_set) or len(best_set) > 4000 or max(abs(x) for x in best_set) > lim:
        D = best_D
        B = 2 * max(abs(x) for x in D) + 3
        m = 1
        while len(D) ** (m + 1) <= 3000 and abs(B) ** (m + 1) * (max(abs(x) for x in D) + 1) <= lim:
            m += 1
        A = [0]
        for _ in range(m):
            A = [a * B + x for a in A for x in D]
        best_set = sorted(set(int(v) for v in A))

    return sorted(set(int(x) for x in best_set))
# EVOLVE-BLOCK-END

