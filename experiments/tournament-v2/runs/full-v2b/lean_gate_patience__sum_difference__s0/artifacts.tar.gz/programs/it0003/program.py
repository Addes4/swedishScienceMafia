# EVOLVE-BLOCK-START
"""Seeded construction + simulated annealing local search for many differences, few sums."""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    nd = len(diffs)
    ns = len(sums)
    if ns < 2 or nd < 2:
        return nd, ns, 0.0
    score = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
    return nd, ns, score


def _score(a):
    return _stats(a)[2]


def _seed():
    # Base-3 digit set D={0,1} yields a Sidon-like / MSTD-flavored set.
    # Use digits {0,1} scaled by powers to get many difference collisions with few sums.
    base = 3
    k = 9
    a = []
    for mask in range(1 << k):
        x = 0
        for i in range(k):
            if mask >> i & 1:
                x += base ** i
        a.append(x)
    return a


def solve():
    best = _seed()
    best_score = _score(best)
    cur = best[:]
    cur_score = best_score
    deadline = time.time() + 110
    T0 = 0.02
    step = 0
    while time.time() < deadline:
        step += 1
        T = T0 * (1 - min(1.0, step / 200000.0)) + 1e-4
        cand = cur[:]
        op = random.random()
        if op < 0.7:
            i = random.randrange(len(cand))
            delta = random.randint(-3, 3)
            if delta == 0:
                delta = 1
            cand[i] += delta
        elif op < 0.9:
            i = random.randrange(len(cand))
            cand[i] = random.randint(-200, 200)
        else:
            cand.append(random.randint(-500, 500))
        cand = list(set(cand))
        if len(cand) > 200:
            cand = random.sample(cand, 200)
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score or random.random() < math.exp((s - cur_score) / max(T, 1e-9)):
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return sorted(set(best))
# EVOLVE-BLOCK-END

