# EVOLVE-BLOCK-START
"""Deterministic multi-cluster AP construction with numpy-based exact scoring.

Idea: A = union over clusters of arithmetic progressions.  Within a cluster the
difference set is a long AP (large |A-A|); across clusters we try to make the
offsets *balanced* (like a Sidon-ish additive structure for sums) so that many
pair sums coincide, keeping |A+A| small.  We build clusters with a greedy
deterministic procedure and then deterministically refine offsets by local
search, scoring candidate sets exactly using bitset convolutions computed with
numpy (no randomness).
"""
import math
import time
import numpy as np


def _bitset_sets(a):
    """Exact |A-A| and |A+A| via integer bitset convolution over a byte array.

    We build an indicator byte array over the coordinate range, pad to a power
    of two, and use FFT-based convolution to compute the autocorrelation
    (differences) and the convolution with the reversed indicator (sums).
    Returns exact counts by thresholding the (integer-valued) convolution.
    """
    a = np.asarray(sorted(set(int(x) for x in a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 1, 1
    lo = int(a[0])
    hi = int(a[-1])
    # shift so min is 0 for difference; for sums use shifted coords too.
    span = hi - lo + 1
    # sums fit in [2*lo, 2*hi]
    sum_span = 2 * (hi - lo) + 1
    size = span + sum_span + 2
    m = 1
    while m < size:
        m <<= 1
    # indicator for differences over [0, span)
    idx = np.zeros(m, dtype=np.float64)
    idx[a - lo] = 1.0
    # difference counts = autocorrelation : conv(idx, idx_reversed)
    f = np.fft.rfft(idx)
    ac = np.fft.irfft(f * f, m)
    ac_int = np.rint(ac).astype(np.int64)
    # differences a-b : lag ranges -(span-1)..(span-1)
    #   lag k>=0 appears at index k ; negative lags mirror -> use indices 1..span-1
    diff_pos = ac_int[0:span]              # k = 0..span-1  (k>=0)
    diff_count = int(np.count_nonzero(diff_pos)) + \
                 int(np.count_nonzero(ac_int[1:span]))  # negative lags
    # sums: conv(idx, idx_reversed_shifted) over [0, 2*span-2]
    rev = np.zeros(m, dtype=np.float64)
    rev[0:span] = idx[span - 1::-1][0:span]
    g = np.fft.rfft(rev)
    cc = np.fft.irfft(f * g, m)
    cc_int = np.rint(cc).astype(np.int64)
    sum_count = int(np.count_nonzero(cc_int[0:sum_span]))
    return diff_count, sum_count


def _score(a):
    a = sorted(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0
    d, s = _bitset_sets(a)
    if s <= 1:
        s = 2
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def solve():
    """Deterministic multi-cluster AP construction with refinement."""
    deadline = time.time() + 100.0

    # ---- deterministic cluster generator -------------------------------
    def build(k_clusters, L, gap, offsets):
        """Union of k AP clusters each of length L with given offsets and gap."""
        A = []
        for off in offsets:
            base = off
            for j in range(L):
                A.append(base + j * gap)
        return A

    best = None
    best_score = -1.0

    # A Sidon-like set of offsets makes sums collide.  Deterministic search:
    # try small base sets of offsets from a base-3 / powers pattern that
    # maximises sum-collisions (like {0,1,3,9,...} scaled).
    # We test a family of structured offset choices.
    candidates_offsets = []

    # 1) greedy "sum-minimal" Sidon-ish offsets: build greedily so that the
    #    offset sum-set is as small as possible (few distinct pair sums).
    def greedy_offsets(k, scale):
        offs = [0]
        for _ in range(k - 1):
            # choose next offset so that |offsets+offsets| grows minimally
            best_o = None
            best_g = None
            cand = set()
            for o in offs:
                cand.add(o + scale)
                cand.add(o + 1)
            cand = sorted(c for c in cand if c > 0)
            cur_sums = {x + y for x in offs for y in offs}
            for o in cand[:40]:
                ns = cur_sums | {o + x for x in offs} | {o + o}
                # also o + o added
                g = len(ns)
                if best_g is None or g < best_g:
                    best_g, best_o = g, o
            offs.append(best_o if best_o is not None else offs[-1] + 1)
        return offs

    for scale in (1, 2, 3, 4, 5, 6):
        for k in (2, 3, 4, 5, 6):
            candidates_offsets.append(greedy_offsets(k, scale))

    # 2) powers-of-two style (strong sum collisions): {0,1,2,4,8,...}
    for k in (3, 4, 5, 6, 7):
        candidates_offsets.append([(1 << i) - 1 for i in range(k)])
    for k in (3, 4, 5, 6):
        candidates_offsets.append([i * i for i in range(k)])
    for k in (3, 4, 5, 6):
        candidates_offsets.append([i * (i + 1) // 2 for i in range(k)])

    # main structured scan: choose L, gap, offsets to maximize score
    for offs in candidates_offsets:
        k = len(offs)
        offs = list(offs)
        for gap in (1, 2, 3):
            for L in (2, 3, 4, 5, 6, 8):
                if k * L > 600:
                    continue
                A = build(k, L, gap, offs)
                s = _score(A)
                if s > best_score:
                    best_score, best = s, A[:]
        if time.time() > deadline:
            break

    if best is None:
        best = [0, 1, 2, 3, 5, 8, 13, 21, 34]
        best_score = _score(best)

    # ---- deterministic local refinement on scaled offsets & gap ---------
    A = sorted(set(best))
    cur_score = _score(A)
    improved = True
    steps = 0
    while improved and time.time() < deadline:
        improved = False
        steps += 1
        A_set = sorted(set(A))
        # try small deterministic perturbations of each element
        for delta in (1, -1, 2, -2, 3, -3):
            for i in range(len(A_set)):
                cand = A_set[:]
                cand[i] = cand[i] + delta
                cand = sorted(set(cand))
                if len(cand) < 2:
                    continue
                s = _score(cand)
                if s > cur_score:
                    cur_score = s
                    A_set = cand
                    improved = True
                    break
            if improved:
                break
        A = A_set
        if steps > 400:
            break

    # final safety: within time, also try whole-set scaling/dilating offsets
    A = sorted(set(int(x) for x in A))
    return A
# EVOLVE-BLOCK-END
