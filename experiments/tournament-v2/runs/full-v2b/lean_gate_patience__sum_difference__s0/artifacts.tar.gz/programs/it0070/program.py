# EVOLVE-BLOCK-START
"""Digit-set construction.

A = { sum_i d_i * B^i : d_i in D }  (m positions).
With B large enough that digit arithmetic never carries, differences of A
correspond to digit-wise differences in D and sums to digit-wise sums in D, so
    |A-A| = |D-D|^m   and   |A+A| = |D+D|^m
giving ratio  log|D-D| / log|D+D|  independent of m. We therefore just need a
good small digit set D, then expand to as many positions as fit.
"""
import math
import time
import numpy as np

TIME_LIMIT = 110.0


def _counts(d):
    arr = np.asarray(sorted(set(int(x) for x in d)), dtype=np.int64)
    if arr.size == 0:
        return 0, 0
    diffs = (arr[:, None] - arr[None, :]).ravel()
    sums = (arr[:, None] + arr[None, :]).ravel()
    return int(np.unique(diffs).size), int(np.unique(sums).size)


def _ratio(d):
    nd, ns = _counts(d)
    if ns <= 1 or nd <= 1:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns), nd, ns


def _expand(D, m, B):
    A = set()
    for d in D:
        pass
    # build all m-position numbers via iterative convolution of value lists
    vals = [0]
    for _ in range(m):
        newvals = set()
        for v in vals:
            for d in D:
                newvals.add(v * B + d)
        vals = sorted(newvals)
    return vals


def solve():
    start = time.time()

    best_D = None
    best_r = -1.0

    # ---- deterministic candidate digit sets ----
    candidates = []
    # intervals
    for k in range(2, 12):
        candidates.append(list(range(k)))
    # interval with a multiplier
    for k in range(2, 9):
        for step in (2, 3):
            candidates.append([i * step for i in range(k)])
    # Sidon-ish / distinct difference sets: {0,1,2,...} shuffled shapes
    for k in range(3, 10):
        candidates.append([i * i for i in range(k)])
    for k in range(3, 10):
        candidates.append([(1 << i) for i in range(k)])
    # two-block
    for a in range(1, 8):
        for b in range(1, 8):
            candidates.append(list(range(a)) + [a + b + i for i in range(b)])

    for D in candidates:
        D = sorted(set(D))
        r, _, _ = _ratio(D)
        if r > best_r:
            best_r, best_D = r, D[:]

    # ---- hill climbing on digit set (WLOG min = 0, sorted) ----
    def climb(D, iters=20000):
        D = sorted(set(int(x) for x in D))
        cur, _, _ = _ratio(D)
        for _ in range(iters):
            if time.time() - start > TIME_LIMIT * 0.5:
                break
            cand = D[:]
            move = np.random.randint(4) if False else 0
            import random
            m = random.randrange(4)
            if m == 0 and cand:                      # shift a point
                i = random.randrange(len(cand))
                cand[i] += random.choice([-3, -2, -1, 1, 2, 3])
            elif m == 1:                              # add a point
                cand.append(random.randrange(0, max(cand) + 5 if cand else 5))
            elif m == 2 and len(cand) > 2:            # remove a point
                cand.pop(random.randrange(len(cand)))
            else:                                     # tweak endpoint
                if cand:
                    cand.append(cand[-1] + random.choice([1, 2, 3]))
            cand = sorted(set(int(x) for x in cand))
            if len(cand) < 2 or len(cand) > 60:
                continue
            lo = min(cand)
            cand = [x - lo for x in cand]
            r, _, _ = _ratio(cand)
            if r > cur:
                cur, D = r, cand
        return D, cur

    import random
    random.seed(12345)
    np.random.seed(12345)

    seeds = [d for d in candidates] + [[0, 1, 3, 7, 12, 20],
                                       [0, 2, 5, 9, 14, 20, 27]]
    t0 = time.time()
    for s in seeds:
        if time.time() - start > TIME_LIMIT * 0.55:
            break
        D, r = climb(s, iters=1500)
        if r > best_r:
            best_r, best_D = r, D[:]

    best_D = sorted(set(int(x) for x in best_D))
    if not best_D:
        best_D = [0, 1]

    # ---- expand best D into base-B number with m positions ----
    n = len(best_D)
    # choose m so that n^m <= 4000 and value <= 1e15
    m = 1
    while n ** (m + 1) <= 4000:
        m += 1
    # base must exceed digit range to avoid carries
    dmax = max(abs(x) for x in best_D)
    B = 2 * dmax + 10
    # ensure numbers fit in 1e15
    while (B ** m - 1) > 10**15 and m > 1:
        m -= 1

    A = _expand(best_D, m, B)
    A = [int(x) for x in A]
    A = sorted(set(A))

    # trim / safety
    lim = 10**15
    A = [x for x in A if abs(x) <= lim]
    if len(A) > 4000:
        A = A[:4000]
    if not A:
        A = [0, 1]
    return A
# EVOLVE-BLOCK-END
