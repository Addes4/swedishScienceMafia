# EVOLVE-BLOCK-START
"""Construction: mixed-radix digit sets with carry collapse.

A = { sum_i d_i * B^i : d_i in D_i } for small digit sets D_i and base B.
A+A collapses via digit-sum carries while A-A stays large, giving a high
log|A-A|/log|A+A| ratio. We sweep several (base, digit-set) configurations
deterministically, score each exactly with numpy, and refine the winner
by an element-deletion polish that recomputes counts lazily."""
import math
import time
import numpy as np


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n == 0:
        return 0, 0
    diffs = (a[:, None] - a[None, :]).ravel()
    sums = (a[:, None] + a[None, :]).ravel()
    nd = np.unique(diffs).size
    ns = np.unique(sums).size
    return nd, ns


def _score_from_counts(nd, ns, n):
    if n < 2 or ns <= 1:
        return -1e9
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _build(digits, base, depth):
    vals = [0]
    for i in range(depth):
        p = base ** i
        newvals = []
        for v in vals:
            for d in digits[i]:
                newvals.append(v + d * p)
        vals = newvals
    return sorted(set(vals))


def _candidate_configs():
    cfgs = []
    # Symmetric ternary-style digits over various bases
    for base in (3, 4, 5, 6, 7, 8):
        for depth in (3, 4, 5):
            for sym in (1, 2, 3):
                D = list(range(-sym, sym + 1))
                cfgs.append((D, base, depth))
    # Nonnegative digit sets
    for base in (3, 4, 5, 6):
        for depth in (3, 4, 5):
            for m in (2, 3, 4):
                D = list(range(0, m + 1))
                cfgs.append((D, base, depth))
    return cfgs


def solve():
    deadline = time.time() + 108

    best_A = None
    best_score = -1e9

    for D, base, depth in _candidate_configs():
        if time.time() > deadline * 0.55:
            break
        digits = [list(D) for _ in range(depth)]
        A = _build(digits, base, depth)
        if len(A) < 2 or len(A) > 4000:
            continue
        nd, ns = _counts(A)
        s = _score_from_counts(nd, ns, len(A))
        if s > best_score:
            best_score = s
            best_A = A

    if best_A is None:
        best_A = [0, 1]

    res = sorted(set(best_A))

    # Element-deletion polish: recompute counts each time (fast enough
    # since we only revisit when sizes shrink).
    cur_nd, cur_ns = _counts(res)
    cur_s = _score_from_counts(cur_nd, cur_ns, len(res))
    improved = True
    import random
    rng = random.Random(1)
    while improved and time.time() < deadline:
        improved = False
        order = list(range(len(res)))
        rng.shuffle(order)
        for i in order:
            if time.time() > deadline:
                break
            cand = res[:i] + res[i + 1:]
            if len(cand) < 2:
                continue
            nd2, ns2 = _counts(cand)
            s = _score_from_counts(nd2, ns2, len(cand))
            if s >= cur_s:
                res = cand
                cur_s = s
                improved = True
                break

    return res
# EVOLVE-BLOCK-END
