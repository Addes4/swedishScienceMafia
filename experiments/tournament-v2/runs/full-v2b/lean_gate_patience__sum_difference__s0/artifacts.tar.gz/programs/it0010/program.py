# EVOLVE-BLOCK-START
"""Direct hill-climbing on the set A to maximize log|A-A|/log|A+A|."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(sorted(set(a)), dtype=np.int64)
    n = len(arr)
    if n < 2:
        return 1, 1
    nd = int(np.unique(arr[:, None] - arr[None, :]).size)
    ns = int(np.unique(arr[:, None] + arr[None, :]).size)
    return nd, ns


def _score_from_counts(nd, ns, n):
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100


def _score(a):
    a = sorted(set(a))
    nd, ns = _counts(a)
    return _score_from_counts(nd, ns, len(a))


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 108
    random.seed(987654321)

    # seed: digit-set constructions with small D, which have good ratios.
    # Try many D and bases; also try pure random small sets.
    candidates = []

    # digit sets D of small size, expanded in base B
    for dv in ([0, 1, 3], [0, 1, 4], [0, 1, 3, 9], [0, 1, 2, 5],
               [0, 1, 3, 7], [0, 1, 4, 11], [0, 1, 3, 8, 21]):
        for B in (50, 100, 200, 500, 1000, 5000, 20000):
            for n in range(2, 7):
                A = []
                # build n-fold digit expansion
                def gen(idx, val, out):
                    if idx == n:
                        out.append(val)
                        return
                    for d in dv:
                        gen(idx + 1, val + d * (B ** idx), out)
                gen(0, 0, A)
                if len(A) <= 4000:
                    candidates.append(A)

    for A in candidates:
        sc = _score(A)
        if sc > best_score:
            best_score = sc
            best = A[:]
        if time.time() > deadline:
            break

    # Direct hill climbing: maintain A and try moves (add element, remove, swap).
    # We re-score fully each time (set size limited ~ few hundred for speed).
    def climb(A0, t_end):
        nonlocal best, best_score
        A = sorted(set(A0))
        cur = _score(A)
        if cur > best_score:
            best_score = cur
            best = A[:]
        limit = 4000
        span = 10 ** 15
        while time.time() < t_end:
            r = random.random()
            n = len(A)
            if r < 0.5 and n < limit:
                # add an element near existing ones or random
                if random.random() < 0.7 and n > 0:
                    e = A[random.randrange(n)] + random.randint(-100, 100)
                else:
                    e = random.randint(-span, span)
                if e in A or abs(e) > span:
                    continue
                cand = sorted(set(A + [e]))
                sc = _score(cand)
                if sc > cur or random.random() < 0.02:
                    A, cur = cand, sc
                    if sc > best_score:
                        best_score = sc
                        best = A[:]
            elif r < 0.85 and n > 2:
                # remove an element
                i = random.randrange(n)
                cand = A[:i] + A[i + 1:]
                sc = _score(cand)
                if sc > cur or random.random() < 0.02:
                    A, cur = cand, sc
                    if sc > best_score:
                        best_score = sc
                        best = A[:]
            else:
                # perturb an element
                if n == 0:
                    continue
                i = random.randrange(n)
                e = A[i] + random.randint(-50, 50)
                cand = sorted(set(A[:i] + A[i + 1:] + [e]))
                if len(cand) == n:
                    sc = _score(cand)
                    if sc > cur or random.random() < 0.02:
                        A, cur = cand, sc
                        if sc > best_score:
                            best_score = sc
                            best = A[:]
        return A, cur

    # Seed hill climbs from several promising starts
    seed_sets = []
    if best is not None:
        seed_sets.append(best[:])
    # also some small random/digit sets
    for dv in ([0, 1, 3], [0, 1, 4], [0, 1, 3, 9]):
        for B in (100, 1000, 10000):
            for n in (2, 3, 4):
                A = []
                def gen(idx, val, out):
                    if idx == n:
                        out.append(val)
                        return
                    for d in dv:
                        gen(idx + 1, val + d * (B ** idx), out)
                gen(0, 0, A)
                if len(A) <= 200:
                    seed_sets.append(A)

    per = max(3.0, 100.0 / max(1, len(seed_sets)))
    for seedA in seed_sets:
        if time.time() > deadline:
            break
        climb(seedA, min(deadline, time.time() + per))

    if best is None:
        best = [0, 1, 3]

    A = sorted(set(best))
    A = [x for x in A if abs(x) <= 10 ** 15][:4000]
    return A
# EVOLVE-BLOCK-END
