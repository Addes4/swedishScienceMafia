# EVOLVE-BLOCK-START
"""Construction: mixed-radix digit sets (Erdos-Turan style).

A = { sum_i d_i * B^i : d_i in D_i } for small digit sets D_i and base B.
Carries make A+A collapse while A-A stays large, maximizing
log|A-A|/log|A+A|. Digit sets, base and depth are refined by hill-climbing
with an exact numpy scorer.
"""
import math
import time
import random
import numpy as np


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n == 0:
        return 0, 0
    diffs = (a[:, None] - a[None, :]).ravel()
    sums = (a[:, None] + a[None, :]).ravel()
    nd = np.unique(diffs).size
    ns = np.unique(sums).size
    return nd, ns


def _score_from_counts(nd, ns, n):
    if n < 2 or ns <= 1:
        return -1e9
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _build(digits, base, depth):
    vals = [0]
    for i in range(depth):
        p = base ** i
        newvals = []
        for v in vals:
            for d in digits[i]:
                newvals.append(v + d * p)
        vals = newvals
    return sorted(set(vals))


def solve():
    rng = random.Random(987654321)
    deadline = time.time() + 108

    cand_digits = list(range(-12, 13))

    def make_random_state():
        depth = rng.randint(2, 4)
        base = rng.randint(5, 24)
        digs = []
        for i in range(depth):
            k = rng.randint(2, 5)
            d = rng.sample(cand_digits, k)
            digs.append(sorted(set(d)))
        return digs, base, depth

    def evaluate(digs, base, depth):
        try:
            A = _build(digs, base, depth)
        except Exception:
            return None
        if len(A) < 2 or len(A) > 4000:
            return None
        nd, ns = _counts(A)
        return _score_from_counts(nd, ns, len(A)), A

    best_score = -1e9
    best_A = None

    # Seed configurations: symmetric small digit sets in various bases.
    seeds = []
    for base in (6, 7, 8, 9, 10, 12, 16):
        for depth in (2, 3):
            seeds.append(([[-2, -1, 0, 1, 2]] * depth, base, depth))
            seeds.append(([[-3, -1, 0, 1, 3]] * depth, base, depth))
            seeds.append(([[-1, 0, 1]] * depth, base, depth))

    for digs, base, depth in seeds:
        r = evaluate(digs, base, depth)
        if r and r[0] > best_score:
            best_score = r[0]
            best_A = r[1]

    # Hill-climb from best seed, plus random restarts.
    def local_search(cur_digs, cur_base, cur_depth, budget):
        nonlocal best_score, best_A
        cur_digs = [list(x) for x in cur_digs]
        r = evaluate(cur_digs, cur_base, cur_depth)
        if r is None:
            return
        cur_score = r[0]
        if cur_score > best_score:
            best_score = cur_score
            best_A = r[1]
        steps = 0
        while steps < budget and time.time() < deadline:
            steps += 1
            nd_ = [list(x) for x in cur_digs]
            nb = cur_base
            ndp = cur_depth
            rr = rng.random()

            if rr < 0.60 and nd_:
                i = rng.randrange(len(nd_))
                d = nd_[i]
                action = rng.random()
                if d and action < 0.35:
                    d.pop(rng.randrange(len(d)))
                elif d and action < 0.55:
                    # perturb a digit
                    j = rng.randrange(len(d))
                    d[j] = d[j] + rng.choice([-2, -1, 1, 2])
                    d = sorted(set(d))
                else:
                    v = rng.choice(cand_digits)
                    if v not in d:
                        d.append(v)
                nd_[i] = sorted(set(d))
            elif rr < 0.82:
                nb = max(2, min(60, cur_base + rng.choice([-3, -2, -1, 1, 2, 3])))
            elif rr < 0.94:
                ndp = max(1, min(5, cur_depth + rng.choice([-1, 1])))
                while len(nd_) < ndp:
                    nd_.append([0])
                nd_ = nd_[:ndp]
            else:
                i = rng.randrange(len(nd_))
                if len(nd_[i]) > 1:
                    nd_[i] = nd_[i][: max(1, len(nd_[i]) - 1)]

            if not any(nd_):
                continue
            r2 = evaluate(nd_, nb, ndp)
            if r2 is None:
                continue
            s2 = r2[0]
            if s2 >= cur_score:
                cur_digs = [list(x) for x in nd_]
                cur_base = nb
                cur_depth = ndp
                cur_score = s2
                if s2 > best_score:
                    best_score = s2
                    best_A = r2[1]

    # First: dedicated local search from the best seed.
    if best_A is not None:
        # recover a decent starting digit structure from the known strong seed
        bd, bb, bdp = [[-1, 0, 1]] * 3, 8, 3
        # find best-seed structure
        bs = -1e9
        for digs, base, depth in seeds:
            r = evaluate(digs, base, depth)
            if r and r[0] > bs:
                bs = r[0]
                bd, bb, bdp = digs, base, depth
        local_search(bd, bb, bdp, 4000)

    # Random restarts with remaining time.
    while time.time() < deadline - 2:
        digs, base, depth = make_random_state()
        local_search(digs, base, depth, 1200)

    res = sorted(set(best_A)) if best_A else [0, 1]

    # Polish: greedy element deletion + small perturbations.
    cur_nd, cur_ns = _counts(res)
    cur_s = _score_from_counts(cur_nd, cur_ns, len(res))
    improved = True
    while improved and time.time() < deadline:
        improved = False
        order = list(range(len(res)))
        rng.shuffle(order)
        for i in order:
            cand = res[:i] + res[i + 1:]
            if len(cand) < 2:
                continue
            nd2, ns2 = _counts(cand)
            s = _score_from_counts(nd2, ns2, len(cand))
            if s >= cur_s:
                res = cand
                cur_s = s
                improved = True
                break

    return res
# EVOLVE-BLOCK-END
