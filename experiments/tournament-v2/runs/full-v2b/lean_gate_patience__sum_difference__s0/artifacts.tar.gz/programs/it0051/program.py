# EVOLVE-BLOCK-START
"""A = C + T construction with geometric translates and fast incremental scoring."""
import math
import time


def _score(nd, ns, n):
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _counts(A):
    L = sorted(set(A))
    s = set(L)
    diffs = set()
    sums = set()
    for i in range(len(L)):
        ai = L[i]
        for j in range(len(L)):
            bj = L[j]
            diffs.add(ai - bj)
            sums.add(ai + bj)
    return len(diffs), len(sums)


def _build(C, T):
    A = set()
    for t in T:
        for c in C:
            A.add(c + t)
    return A


def _eval(A):
    A = set(A)
    n = len(A)
    if n < 3:
        return 0.0, 0, 0
    nd, ns = _counts(A)
    return _score(nd, ns, n), nd, ns


def solve():
    deadline = time.time() + 100.0

    best_A = [0, 1]
    best_score = 0.0

    def try_set(A):
        nonlocal best_A, best_score
        A = set(A)
        if len(A) < 3 or len(A) > 4000:
            return 0.0
        s, nd, ns = _eval(A)
        if s > best_score:
            best_score = s
            best_A = sorted(A)
        return s

    # Compact clusters (keep |C+C| and |C-C| modest).
    clusters = [list(range(L)) for L in (4, 6, 8, 10, 12, 16, 20, 24, 30)]
    clusters += [[2 * k for k in range(L)] for L in (8, 12, 16, 20, 30)]

    # Geometric translate sets: powers of a large base B, so that
    # differences t_i - t_j are all distinct but sums t_i + t_j collide.
    def geom_T(m, B):
        T = []
        v = 1
        for _ in range(m):
            T.append(v)
            v *= B
        return T

    # Phase 1: seed over clusters, translate counts and bases.
    for C in clusters:
        if time.time() > deadline:
            break
        for m in (3, 4, 5, 6, 7, 8):
            if time.time() > deadline:
                break
            for B in (16, 32, 64, 128, 256, 512, 1024, 4096):
                if time.time() > deadline:
                    break
                T = geom_T(m, B)
                try_set(_build(C, T))

    # Phase 2: hill-climb the base B and cluster size jointly on the best pattern.
    if time.time() < deadline:
        # Find the best (C, m, B) and refine B locally.
        best_params = None
        for C in clusters:
            if time.time() > deadline:
                break
            for m in (4, 5, 6, 7):
                if time.time() > deadline:
                    break
                for B in (64, 128, 256, 512, 1024, 2048, 4096):
                    if time.time() > deadline:
                        break
                    A = _build(C, geom_T(m, B))
                    s, _, _ = _eval(A)
                    if best_params is None or s > best_params[0]:
                        best_params = (s, list(C), m, B)
                    if time.time() > deadline:
                        break
        if best_params is not None:
            _, C, m, B = best_params
            cur = geom_T(m, B)
            cur_score = _eval(_build(C, cur))[0]
            improved = True
            while improved and time.time() < deadline:
                improved = False
                for i in range(1, m):
                    for scale in (2, 3, 5, 7, 11, 13):
                        for direction in (1, -1):
                            trial = cur[:]
                            if direction == 1:
                                trial[i] = trial[i] * scale
                            else:
                                if trial[i] % scale == 0:
                                    trial[i] = trial[i] // scale
                                else:
                                    continue
                            if len(set(trial)) != len(trial):
                                continue
                            s = try_set(_build(C, trial))
                            if s > cur_score + 1e-12:
                                cur = trial
                                cur_score = s
                                improved = True
                if time.time() > deadline:
                    break

    # Phase 3: shift-expand the best set: repeatedly add A+t for improving t.
    if best_A and time.time() < deadline:
        A = set(best_A)
        cur_score = _eval(A)[0]
        span = max(A) - min(A)
        step = max(1, span)
        improved = True
        while improved and time.time() < deadline:
            improved = False
            cand_ts = []
            for mult in (1, 2, 4, 8, 16):
                d = step * mult
                cand_ts += [d, -d, d + 1, -d - 1]
            for t in cand_ts:
                if time.time() > deadline:
                    break
                trial = set(A)
                for x in A:
                    trial.add(x + t)
                if len(trial) > 4000:
                    continue
                s, _, _ = _eval(trial)
                if s > cur_score + 1e-12:
                    A = trial
                    cur_score = s
                    improved = True
                    if s > best_score:
                        best_score = s
                        best_A = sorted(A)
                    break
            if not improved and step > 1:
                step = max(1, step // 2)
                improved = True  # keep looking with finer steps

    # Phase 4: single-element polish (add/remove) on best set.
    if best_A and time.time() < deadline:
        A = set(best_A)
        cur_score, _, _ = _eval(A)
        improved = True
        while improved and time.time() < deadline:
            improved = False
            L = sorted(A)
            lo, hi = min(A), max(A)
            for x in L:
                if time.time() > deadline:
                    break
                trial = set(A)
                trial.discard(x)
                if len(trial) < 3:
                    continue
                s, _, _ = _eval(trial)
                if s > cur_score + 1e-12:
                    A = trial
                    cur_score = s
                    improved = True
                    break
            if improved:
                continue
            cand = set()
            for x in L:
                for d in (1, -1, 2, -2, 3, -3):
                    cand.add(x + d)
            cand.add(lo - 1)
            cand.add(hi + 1)
            for x in cand:
                if time.time() > deadline:
                    break
                if x in A:
                    continue
                trial = set(A)
                trial.add(x)
                if len(trial) > 4000:
                    continue
                s, _, _ = _eval(trial)
                if s > cur_score + 1e-12:
                    A = trial
                    cur_score = s
                    improved = True
                    break
        if cur_score > best_score:
            best_score = cur_score
            best_A = sorted(A)

    best_A = sorted(set(best_A))
    if len(best_A) < 2:
        best_A = [0, 1]
    return best_A
# EVOLVE-BLOCK-END
