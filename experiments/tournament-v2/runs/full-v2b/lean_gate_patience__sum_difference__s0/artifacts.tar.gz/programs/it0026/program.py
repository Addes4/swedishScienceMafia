# EVOLVE-BLOCK-START
"""Structured construction via digit-sum (mixed-radix) sets.

A = { sum_i d_i  :  d_i in S_i }, where each S_i is a small set of nonnegative integer
"digits" and the S_i are scaled by large distinct multipliers m_i so digits from different
levels never interfere additively... but we instead want interference in the SUM: choose
multipliers that are IDENTICAL so sums collide, while keeping the difference set large via
the level sets being distinct. Concretely we use blocks: level i contributes m_i * S_i with
modest m_i, and we keep the distinct digit sets Sidon-like so A-A is nearly |prod|. We then
directly count |A-A| and |A+A| exactly with numpy for many candidate level sequences and keep
the best real set (plus a per-element hill-climb refinement).
"""
import math
import time
import numpy as np


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.shape[0]
    if n < 2:
        return 0, 0
    d = (a[:, None] - a[None, :]).ravel()
    nd = np.unique(d).size
    s = (a[:, None] + a[None, :]).ravel()
    ns = np.unique(s).size
    return int(nd), int(ns)


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if nd < 1 or ns < 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _build(levels):
    """levels: list of (multiplier, digit_set list). Returns sorted distinct int list."""
    vals = [0]
    for (m, ds) in levels:
        new = []
        add = [m * d for d in ds]
        for v in vals:
            for ad in add:
                new.append(v + ad)
        vals = new
    return sorted(set(vals))


def solve():
    deadline = time.time() + 108.0
    best = (0.0, None, None)

    # Candidate digit sets (nonnegative, containing 0).
    digit_sets = [
        [0, 1],
        [0, 1, 2],
        [0, 1, 3],
        [0, 1, 2, 3],
        [0, 1, 3, 4],
        [0, 1, 2, 4],
        [0, 1, 4, 5],
        [0, 1, 2, 5],
        [0, 1, 3, 7],
        [0, 1, 4, 6],
        [0, 1, 2, 3, 4],
        [0, 1, 2, 4, 5],
        [0, 1, 3, 4, 6],
        [0, 1, 2, 3, 5],
        [0, 1, 2, 3, 4, 5],
    ]

    # Multiplier schemes: identical multipliers cause sum collisions; modest scaling keeps
    # difference set product-like. Try constant multipliers and slowly growing ones.
    def make_levels(nlev, ds_choices, mult_scheme):
        levels = []
        for i in range(nlev):
            ds = ds_choices[i % len(ds_choices)]
            m = mult_scheme(i)
            levels.append((m, ds))
        return levels

    schemes = []
    # constant multiplier 1 (max sum collision)
    schemes.append(lambda i: 1)
    # small growth
    schemes.append(lambda i: 2 ** i)
    schemes.append(lambda i: 3 ** i)
    schemes.append(lambda i: 4 ** i)
    schemes.append(lambda i: (i + 1))
    schemes.append(lambda i: 2 * i + 1)

    # Enumerate candidate level sequences and evaluate exactly.
    import itertools
    tried = 0
    # Systematic: choose number of levels and multipliers from a fixed increasing scheme,
    # digit sets from the pool cyclically or chosen to balance.
    base_pool = digit_sets

    for nlev in range(2, 8):
        for sch in schemes:
            for combo in itertools.product(range(min(len(base_pool), 6)), repeat=min(nlev, 3)):
                if time.time() > deadline:
                    break
                # build ds sequence extending combo cyclically
                seq = [base_pool[combo[j % len(combo)]] for j in range(nlev)]
                levels = make_levels(nlev, seq, sch)
                a = _build(levels)
                if len(a) < 2 or len(a) > 4000:
                    continue
                s = _score(a)
                tried += 1
                if s > best[0]:
                    best = (s, a, levels)
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    if best[1] is None:
        return [0, 1, 2, 3]

    # Per-element hill-climb: try shifting individual elements to reduce |A+A| or grow |A-A|.
    cur = list(best[1])
    cur_score = best[0]
    n = len(cur)
    improved = True
    shift_amts = [1, -1, 2, -2, 3, -3, 4, -4, 5, -5, 6, -6, 7, -7, 8, -8]
    while improved and time.time() < deadline:
        improved = False
        for i in range(n):
            if time.time() > deadline:
                break
            base = cur[i]
            for st in shift_amts:
                trial = list(cur)
                trial[i] = base + st
                if len(set(trial)) < n:
                    continue
                s = _score(trial)
                if s > cur_score + 1e-12:
                    cur = trial
                    cur_score = s
                    improved = True
                    best = (s, sorted(set(cur)), best[2])
                    break
        if cur_score > best[0]:
            best = (cur_score, list(cur), best[2])

    return best[1]
# EVOLVE-BLOCK-END
