# EVOLVE-BLOCK-START
"""Digit-set construction: A = { sum d_i B^i : d_i in D }.

For a digit set D and base B, sums A+A create carries (collapsing), while
differences A-A tend to stay distinct (base-B representation is spread out).
We search over (D, B, m) with randomized restarts and hill-climb.
"""
import math
import time
import random


def _score_counts(nd, ns, n):
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _counts(A):
    s = set(A)
    diffs = set()
    sums = set()
    L = list(s)
    for i in range(len(L)):
        ai = L[i]
        for j in range(len(L)):
            bj = L[j]
            diffs.add(ai - bj)
            sums.add(ai + bj)
    return len(diffs), len(sums)


def _build_digits(D, B, m):
    A = {0}
    for _ in range(m):
        newA = set()
        p = 1
        for _k in range(_):
            p *= B
        for a in A:
            for d in D:
                newA.add(a + d * p)
        A = newA
    return A


def _eval(A):
    n = len(A)
    if n < 3:
        return 0.0, 0, 0
    nd, ns = _counts(A)
    return _score_counts(nd, ns, n), nd, ns


def solve():
    deadline = time.time() + 105.0
    random.seed(12345)

    best_A = [0, 1]
    best_score = 0.0

    def try_set(A):
        nonlocal best_A, best_score
        A = set(A)
        if len(A) < 3 or len(A) > 4000:
            return 0.0
        s, nd, ns = _eval(A)
        if s > best_score:
            best_score = s
            best_A = sorted(A)
        return s

    # Fixed-m size so |A| = |D|^m stays <= 4000.
    # For |D|=2 -> m up to 11 (2048); |D|=3 -> m up to 7 (2187); |D|=4 -> m up to 5.
    configs = []
    for D in ([0, 1], [0, 1, 2], [0, 2], [0, 1, 3], [0, 2, 4], [0, 1, 2, 3],
              [0, 3], [0, 1, 4], [0, 2, 3], [0, 1, 2, 4], [0, 1, 2, 3, 4]):
        k = len(D)
        if k < 2:
            continue
        m = 1
        while k ** (m + 1) <= 4000:
            m += 1
        configs.append((tuple(D), m))
        # also try one level smaller
        if m - 1 >= 2:
            configs.append((tuple(D), m - 1))

    # Phase 1: seeds with various bases.
    bases_by_k = {2: [2, 3, 4, 5, 6, 8, 10, 16, 100, 1000],
                  3: [2, 3, 4, 5, 8, 10, 100, 1000],
                  4: [2, 3, 4, 5, 10, 100],
                  5: [2, 3, 4, 10, 100]}

    for D, m in configs:
        if time.time() > deadline:
            break
        k = len(D)
        for B in bases_by_k.get(k, [2, 3, 4, 10]):
            if time.time() > deadline:
                break
            # slight offsets so digits can be negative-shifted to break symmetry
            try_set(_build_digits(list(D), B, m))

    # Phase 2: perturbed digit sets (add small variations to D) to break linearity.
    attempts = 0
    while time.time() < deadline and attempts < 4000:
        attempts += 1
        D, m = random.choice(configs)
        k = len(D)
        # jitter each nonzero digit a bit
        Dj = []
        for d in D:
            if d == 0:
                Dj.append(0)
            else:
                Dj.append(d + random.randint(-1, 1))
        # ensure distinct, nonneg, includes 0
        Dj = sorted(set(x for x in Dj if x >= 0))
        if 0 not in Dj or len(Dj) < 2:
            continue
        B = random.choice(bases_by_k.get(k, [2, 3, 4, 10, 100]))
        s = try_set(_build_digits(Dj, B, m))
        if s > best_score:
            best_A = sorted(_build_digits(Dj, B, m))

    # Phase 3: hill-climb digit values on the best configuration found.
    if best_A:
        # try to detect structure quickly: just do a generic local search on a
        # digit-set family around the best base and size.
        D0, m0 = random.choice(configs)
        k0 = len(D0)
        for B in bases_by_k.get(k0, [2, 3]):
            if time.time() > deadline:
                break
            Dcur = list(D0)
            cur = _build_digits(Dcur, B, m0)
            cur_score, _, _ = _eval(cur)
            improved = True
            while improved and time.time() < deadline:
                improved = False
                for i in range(len(Dcur)):
                    if i == 0 or Dcur[i] == 0:
                        continue
                    for delta in (1, -1, 2, -2):
                        nd_ = Dcur[i] + delta
                        if nd_ <= 0 or nd_ in Dcur:
                            continue
                        trial = Dcur[:]
                        trial[i] = nd_
                        A = _build_digits(trial, B, m0)
                        if len(A) > 4000 or len(A) < 3:
                            continue
                        s, _, _ = _eval(A)
                        if s > cur_score + 1e-12:
                            Dcur = trial
                            cur_score = s
                            cur = A
                            improved = True
                            if s > best_score:
                                best_score = s
                                best_A = sorted(A)
                            break
                    if time.time() > deadline:
                        break

    # Phase 4: cheap single-element polish to squeeze a bit more.
    if best_A and time.time() < deadline:
        A = set(best_A)
        cur_score, _, _ = _eval(A)
        improved = True
        while improved and time.time() < deadline:
            improved = False
            L = sorted(A)
            for x in L:
                if time.time() > deadline:
                    break
                trial = set(A)
                trial.discard(x)
                if len(trial) < 3:
                    continue
                s, _, _ = _eval(trial)
                if s > cur_score + 1e-12:
                    A = trial
                    cur_score = s
                    improved = True
                    break
            if improved:
                continue
            cand = set()
            lo, hi = min(A), max(A)
            for x in L:
                for d in (1, -1, 2, -2):
                    cand.add(x + d)
            cand.add(lo - 1)
            cand.add(hi + 1)
            for x in cand:
                if time.time() > deadline:
                    break
                if x in A:
                    continue
                trial = set(A)
                trial.add(x)
                if len(trial) > 4000:
                    continue
                s, _, _ = _eval(trial)
                if s > cur_score + 1e-12:
                    A = trial
                    cur_score = s
                    improved = True
                    break
        if cur_score > best_score:
            best_score = cur_score
            best_A = sorted(A)

    best_A = sorted(set(best_A))
    if len(best_A) < 2:
        best_A = [0, 1]
    return best_A
# EVOLVE-BLOCK-END
