# EVOLVE-BLOCK-START
"""Deterministic structured construction: union of AP clusters, then deterministic refinement."""
import math
import time
import numpy as np


def _score_np(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0.0
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    if sums < 2:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _build(clusters):
    """clusters: list of (start, step, size). Returns sorted unique list."""
    vals = []
    for (st, step, sz) in clusters:
        for i in range(sz):
            vals.append(st + i * step)
    vals = sorted(set(vals))
    return vals


def solve():
    best = None
    best_score = -1.0

    deadline = time.time() + 110

    # Deterministic structured search over cluster configurations.
    # Idea: many clusters sharing the same step so sums of corresponding
    # elements collide across clusters (small sum set), while distinct
    # cluster offsets keep differences rich.
    configs = []
    # Vary number of clusters, cluster size, shared step, and spread of offsets.
    for ncl in (3, 4, 5, 6, 7, 8, 10, 12, 16):
        for csz in (2, 3, 4, 5, 6, 8):
            for step in (1, 2, 3, 4, 5):
                for gap in (1, 2, 3, 5, 8, 13, 21):
                    configs.append((ncl, csz, step, gap))

    # Deduplicate
    seen = set()
    uniq = []
    for c in configs:
        if c not in seen:
            seen.add(c)
            uniq.append(c)
    configs = uniq

    # Explore configurations deterministically.
    for (ncl, csz, step, gap) in configs:
        if time.time() > deadline:
            break
        clusters = []
        for k in range(ncl):
            st = k * gap
            clusters.append((st, step, csz))
        a = _build(clusters)
        if len(a) < 2:
            continue
        s = _score_np(a)
        if s > best_score:
            best_score = s
            best = a

    # Deterministic refinement: try shifting each cluster's offset and
    # perturbing gaps/steps in a structured sweep.
    if best is not None:
        ncl = len(configs[0])  # unused, placeholder
    # Recover a good base config from best-found by re-running the best few.
    # Instead, do direct refinement on the best configuration found.
    # We track candidate configs and refine the top ones.

    # Re-scan to find top configs, then refine them.
    scored = []
    for (ncl, csz, step, gap) in configs:
        if time.time() > deadline:
            break
        clusters = [(k * gap, step, csz) for k in range(ncl)]
        a = _build(clusters)
        if len(a) < 2:
            continue
        s = _score_np(a)
        scored.append((s, ncl, csz, step, gap))

    scored.sort(reverse=True)

    for (s0, ncl, csz, step, gap) in scored[:20]:
        if time.time() > deadline:
            break
        # Refine offsets: each cluster gets its own offset delta.
        offsets = [k * gap for k in range(ncl)]
        cur_score = s0

        # Coordinate descent on offsets and step.
        improved = True
        rounds = 0
        while improved and rounds < 40 and time.time() < deadline:
            improved = False
            rounds += 1
            # Refine each offset
            for k in range(ncl):
                base = offsets[k]
                best_local = cur_score
                best_delta = 0
                for d in (-3, -2, -1, 1, 2, 3, -5, 5, -8, 8):
                    trial = offsets[:]
                    trial[k] = base + d
                    clusters = [(trial[j], step, csz) for j in range(ncl)]
                    a = _build(clusters)
                    if len(a) < 2:
                        continue
                    sc = _score_np(a)
                    if sc > best_local:
                        best_local = sc
                        best_delta = d
                if best_delta != 0:
                    offsets[k] = base + best_delta
                    cur_score = best_local
                    improved = True
            # Refine step
            best_step = step
            for ds in (-1, 1, -2, 2, -3, 3):
                if step + ds < 1:
                    continue
                clusters = [(offsets[j], step + ds, csz) for j in range(ncl)]
                a = _build(clusters)
                if len(a) < 2:
                    continue
                sc = _score_np(a)
                if sc > cur_score:
                    cur_score = sc
                    best_step = step + ds
            if best_step != step:
                step = best_step
                improved = True

        clusters = [(offsets[j], step, csz) for j in range(ncl)]
        a = _build(clusters)
        if len(a) >= 2:
            sc = _score_np(a)
            if sc > best_score:
                best_score = sc
                best = a

    if best is None:
        best = [0, 1]
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
