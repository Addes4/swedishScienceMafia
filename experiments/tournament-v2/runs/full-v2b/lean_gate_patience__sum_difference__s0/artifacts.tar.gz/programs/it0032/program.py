# EVOLVE-BLOCK-START
"""Search over highly structured sets: take a dense arithmetic progression (small
sumset) and perturb/embed it so differences stay large. Exact numpy scoring."""
import math
import random
import time

import numpy as np


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0.0
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    if sums < 2:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 110
    rng = random.Random(20240517)

    best = None
    best_score = -1.0

    def consider(arr):
        nonlocal best, best_score
        arr = np.unique(np.asarray(arr, dtype=np.int64))
        if arr.size < 2:
            return
        s = _score(arr)
        if s > best_score:
            best_score = s
            best = arr.copy()

    # Seed with known good structured sets.
    consider([i * i for i in range(30)])
    consider([i * (i + 1) // 2 for i in range(30)])
    consider([2 ** i - 1 for i in range(12)])

    # Main strategy: A = { c * t : t in T } union dense block, or AP with
    # Sidon-like offsets. Try many "gap" patterns on an AP.

    # Build a dense AP and then perturb positions in a way that spreads diffs.
    n_list = [16, 20, 24, 28, 32, 36, 40, 48, 56]

    for n in n_list:
        for _ in range(400):
            if time.time() > deadline:
                break
            # Base AP
            base = np.arange(n, dtype=np.int64)
            # Apply a monotone perturbation that keeps values increasing
            pert = np.zeros(n, dtype=np.int64)
            acc = 0
            for i in range(n):
                acc += rng.randint(0, 2)
                pert[i] = acc
            cand = base + pert
            consider(cand)

    # Sidon-style: start from squares of a small AP plus a dense AP block.
    for _ in range(20000):
        if time.time() > deadline:
            break
        n1 = rng.randint(4, 9)
        n2 = rng.randint(6, 20)
        sc = rng.randint(1, 5)
        sidon = np.array([i * i * sc for i in range(n1)], dtype=np.int64)
        base = sidon.max() + 1 if n1 else 0
        gap = rng.randint(1, 4)
        block = base + gap * np.arange(n2, dtype=np.int64)
        consider(np.concatenate([sidon, block]))

    # Union of two APs with different gaps to enrich differences.
    for _ in range(20000):
        if time.time() > deadline:
            break
        n1 = rng.randint(6, 16)
        n2 = rng.randint(6, 16)
        g1 = rng.randint(1, 4)
        g2 = rng.randint(1, 4)
        off = rng.randint(0, 8)
        a1 = g1 * np.arange(n1, dtype=np.int64)
        a2 = off + g2 * np.arange(n2, dtype=np.int64)
        consider(np.concatenate([a1, a2]))

    return [int(x) for x in np.unique(best)]


# EVOLVE-BLOCK-END
