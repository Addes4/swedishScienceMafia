# EVOLVE-BLOCK-START
"""Deterministic multi-cluster construction.

Idea: A is a union of arithmetic-progression clusters with common gaps. Differences
within a cluster are many distinct values (large |A-A|), while sums cross clusters
collide because clusters come in additively-matched offset groups. We refine offsets
and gaps by hill-climbing, scoring exactly with numpy bincount.
"""
import math
import time
import numpy as np


def _exact_counts(a):
    """Return (n_diff, n_sum) exactly using bincount, assuming a is a numpy int64 array."""
    if a.size < 2:
        return 0, 0
    # differences
    d = a[:, None] - a[None, :]
    d = d.ravel()
    dmin = d.min()
    nd = int(np.bincount(d - dmin).size)
    # sums
    s = a[:, None] + a[None, :]
    s = s.ravel()
    smin = s.min()
    ns = int(np.bincount(s - smin).size)
    return nd, ns


def _score_from_size(a):
    """Score a numpy array of distinct ints."""
    n = a.size
    if n < 2:
        return 0.0
    nd, ns = _exact_counts(a)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100.0


def _build(offsets, gap, n_terms):
    """Build set = union over off of {off, off+gap, ..., off+(n_terms-1)*gap}.

    offsets: iterable of ints. Returns numpy int64 array of distinct values.
    """
    off = np.array(list(offsets), dtype=np.int64)
    steps = np.arange(n_terms, dtype=np.int64) * gap
    pts = (off[:, None] + steps[None, :]).ravel()
    return np.unique(pts)


def _score_config(offsets, gap, n_terms):
    a = _build(offsets, gap, n_terms)
    return _score_from_size(a), a


def solve():
    deadline = time.time() + 110

    # Deterministic seed configuration: clusters with additively-colliding offsets.
    # Base offsets form several arithmetic progressions; pairs from different
    # progressions produce repeated sums.
    base_offsets = [
        0, 3, 6, 9, 12,          # progression A (gap 3)
        6, 15, 24, 33,           # progression B (gap 9) -- overlaps sums with A
        4, 10, 16, 22,           # progression C (gap 6)
        -4, -10, -16,            # progression D (gap -6), symmetric-ish
    ]
    # Deduplicate and ensure deterministic ordering.
    seen = set()
    offsets = []
    for o in base_offsets:
        if o not in seen:
            seen.add(o)
            offsets.append(o)

    gap = 3
    n_terms = 8

    best_score, best_a = _score_config(offsets, gap, n_terms)

    # Deterministic hill-climb: try small perturbations of each offset and the gap.
    rng = np.random.default_rng(12345)

    improved = True
    iters = 0
    while improved and time.time() < deadline:
        improved = False
        iters += 1
        # Perturb offsets
        for i in range(len(offsets)):
            if time.time() > deadline:
                break
            for delta in (-3, -2, -1, 1, 2, 3):
                cand = offsets[:]
                cand[i] += delta
                if len(set(cand)) != len(cand):
                    continue
                s, a = _score_config(cand, gap, n_terms)
                if s > best_score + 1e-15:
                    best_score, best_a = s, a
                    offsets = cand
                    improved = True
                    break
            if time.time() > deadline:
                break
        # Perturb gap
        if time.time() < deadline:
            for dg in (-3, -2, -1, 1, 2, 3):
                if gap + dg <= 0:
                    continue
                s, a = _score_config(offsets, gap + dg, n_terms)
                if s > best_score + 1e-15:
                    best_score, best_a = s, a
                    gap = gap + dg
                    improved = True
                    break
        # Occasionally add/remove offsets deterministically
        if time.time() < deadline:
            if len(offsets) < 40 and (iters % 3 == 0):
                base = offsets[-1]
                for delta in (1, 2, 3, 4, 5, 6):
                    cand = offsets + [base + delta]
                    if len(set(cand)) != len(cand):
                        continue
                    s, a = _score_config(cand, gap, n_terms)
                    if s > best_score + 1e-15:
                        best_score, best_a = s, a
                        offsets = cand
                        improved = True
                        break
            if len(offsets) > 6 and (iters % 4 == 0):
                for i in range(len(offsets)):
                    cand = offsets[:i] + offsets[i + 1:]
                    s, a = _score_config(cand, gap, n_terms)
                    if s > best_score + 1e-15:
                        best_score, best_a = s, a
                        offsets = cand
                        improved = True
                        break

        # If stuck, try a random multi-offset kick (still deterministic via rng).
        if not improved and time.time() < deadline:
            for _ in range(20):
                cand = offsets[:]
                # perturb a few offsets
                k = max(1, len(cand) // 4)
                idxs = rng.choice(len(cand), size=min(k, len(cand)), replace=False)
                for j in idxs:
                    cand[j] += int(rng.integers(-6, 7))
                if len(set(cand)) != len(cand):
                    continue
                s, a = _score_config(cand, gap, n_terms)
                if s > best_score + 1e-15:
                    best_score, best_a = s, a
                    offsets = cand
                    improved = True
                    break

    result = [int(x) for x in best_a]
    return result
# EVOLVE-BLOCK-END
