"""Maximize log|A-A|/log|A+A| via the digit-set construction.

For A = { sum_i d_i B^i : d_i in D } with base B chosen larger than 2*max|D|
(digits never carry), the digit maps are bijective, hence
    |A-A| = |D-D|^m ,  |A+A| = |D+D|^m
and the ratio equals log|D-D| / log|D+D| for the small digit set D.
Increasing the number of digits m only raises |A| (size bonus), so we first
find a small D with a large ratio (exhaustive search for tiny D + hill-climb
for larger D), then blow it up into as many digits as fit in the limits.
"""
import math
import time
import random
from itertools import product, combinations


def _stats(D):
    """Exact |D-D| and |D+D|."""
    ds = set()
    ss = set()
    n = len(D)
    for i in range(n):
        xi = D[i]
        ss.add(xi + xi)
        for j in range(n):
            ds.add(xi - D[j])
        for j in range(n):
            ss.add(xi + D[j])
    return len(ds), len(ss)


def _ratio(D):
    d, s = _stats(D)
    if s <= 1 or d <= 1:
        return 0.0
    return math.log(d) / math.log(s)


def solve():
    deadline = time.time() + 95.0
    rng = random.Random(987654321)

    bestD = [1, 2, 4]
    bestR = _ratio(bestD)

    # -----------------------------------------------------------------
    # 1a. EXHAUSTIVE search over small digit sets (sizes 2..5) in range 0..R
    #     This reliably finds the optimal tiny digit set.
    # -----------------------------------------------------------------
    for k in range(2, 6):
        if time.time() > deadline:
            break
        R = {2: 25, 3: 22, 4: 18, 5: 15}.get(k, 14)
        # limit combinations; k=5 over 15 is C(15,5)=3003, cheap
        for combo in combinations(range(R + 1), k):
            if time.time() > deadline:
                break
            # normalize so min element is 0 or keep absolute; also try shift
            D = list(combo)
            r = _ratio(D)
            if r > bestR:
                bestR = r
                bestD = D[:]

    # -----------------------------------------------------------------
    # 1b. hill-climb for larger digit sets, seeded from the best found so far
    # -----------------------------------------------------------------
    def try_improve(D, r, iters, R):
        for _ in range(iters):
            if time.time() > deadline:
                break
            k = len(D)
            D2 = list(D)
            idx = rng.randrange(k)
            mode = rng.random()
            if mode < 0.6:
                D2[idx] = rng.randrange(R)
            elif mode < 0.85:
                D2[idx] = D2[idx] + rng.randint(-3, 3)
            else:
                other = rng.choice(D)
                D2[idx] = other + rng.randint(-2, 2)
            D2 = sorted(set(x for x in D2 if x >= 0))
            if len(D2) < 2:
                continue
            r2 = _ratio(D2)
            if r2 > r:
                r = r2
                D = D2
        return D, r

    for k in range(5, 30):
        if time.time() > deadline:
            break
        for restart in range(10):
            if time.time() > deadline:
                break
            R = max(8, 5 * k)
            if restart < 5:
                D = sorted(rng.sample(range(R), k))
            else:
                D = sorted(set(int(round(2 ** (i + 1))) - 1 for i in range(k)))
            if len(D) < 2:
                continue
            D, r = try_improve(D, _ratio(D), 100, R)
            if time.time() < deadline:
                D, r = try_improve(D, r, 50, R * 2)
            if r > bestR:
                bestR = r
                bestD = D[:]

    # -----------------------------------------------------------------
    # 2. blow the best digit set up into many base-B digits
    # -----------------------------------------------------------------
    D = bestD
    k = len(D)
    maxD = max(abs(x) for x in D)
    B = max(2, 2 * maxD + 1)          # carry-free base

    m = 1
    while True:
        if k ** (m + 1) > 4000:
            break
        top = maxD * ((B ** (m + 1) - 1) // (B - 1)) if B > 1 else maxD
        if top > 10 ** 15:
            break
        m += 1

    A = []
    for combo in product(D, repeat=m):
        val = 0
        p = 1
        for dgt in combo:
            val += dgt * p
            p *= B
        A.append(val)

    A = sorted(set(A))
    if len(A) < 2:
        A = [0, 1, 2, 4]

    return [int(x) for x in A]
