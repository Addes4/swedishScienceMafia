# EVOLVE-BLOCK-START
"""Union of translates of a base cluster, with exact numpy scoring and hill-climbing."""
import math
import time
import numpy as np


def _counts(A):
    a = np.array(sorted(set(A)), dtype=np.int64)
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    return len(diffs), len(sums)


def _score_counts(nd, ns, n):
    if n < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _cnt_fast(A):
    a = np.array(sorted(set(A)), dtype=np.int64)
    n = len(a)
    d = np.subtract.outer(a, a).ravel()
    s = np.add.outer(a, a).ravel()
    return len(np.unique(d)), len(np.unique(s))


def solve():
    deadline = time.time() + 100.0
    best_A = [0, 1]
    best_score = _score_counts(*_counts(best_A), len(set(best_A)))

    def try_set(A):
        nonlocal best_A, best_score
        A = sorted(set(A))
        n = len(A)
        if n < 2 or n > 4000:
            return None
        nd, ns = _cnt_fast(A)
        s = _score_counts(nd, ns, n)
        if s > best_score:
            best_A, best_score = A[:], s
        return s

    # Base cluster C: an arithmetic-ish block with many differences but few sums.
    # Take C as {0,1,...,L-1} (its sum set 2L-1, diff set 2L-1). Union of translates
    # T+C: |A+A| ~ |T+T| + 2L, |A-A| ~ |T-T| + 2L track multiplicatively.
    bestT = None
    for L in (5, 7, 8, 11, 13, 16, 20, 25, 32, 40, 50, 64):
        C = list(range(L))
        for K in (2, 3, 4, 5, 6, 8, 10, 13, 16, 20, 25, 32, 40, 50):
            if L * K > 3800:
                continue
            # T with distinct differences: {0,1,3,7,...,2^j-1} type
            T = [0]
            while len(T) < K:
                T.append(T[-1] + len(T) + 1 if False else (2 ** len(T) - 1) if len(T) < 12 else T[-1] + 3)
            T = sorted(set(T))[:K]
            # build A = T + C
            A = []
            for t in T:
                for c in C:
                    A.append(t * L + c)  # keep clusters disjoint blocks
            s = try_set(A)
            if s is not None:
                bestT = (L, T[:])
        if time.time() > deadline:
            break

    # Hill-climb offsets of the translates T (positions of blocks), using block-spacing.
    if bestT is not None:
        L, T = bestT
        C = list(range(L))
        # interpret T as block indices; move each block index by small deltas
        power = 1
        while power < L * 2:
            power *= 2
        while time.time() < deadline:
            improved = False
            for i in range(len(T)):
                for delta in (1, -1, 2, -2, 3, -3, 5, -5, 8, -8, 13, -13):
                    T2 = T[:]
                    T2[i] += delta
                    if len(set(T2)) != len(T2):
                        continue
                    if any(x < 0 for x in T2):
                        continue
                    A = []
                    for t in T2:
                        for c in C:
                            A.append(t * (L + 1) + c)
                    n = len(set(A))
                    if n > 4000:
                        continue
                    nd, ns = _cnt_fast(A)
                    s = _score_counts(nd, ns, n)
                    if s > best_score + 1e-12:
                        T = T2
                        best_A, best_score = sorted(A), s
                        improved = True
            if not improved:
                break

    best_A = sorted(set(best_A))
    if len(best_A) < 2:
        best_A = [0, 1]
    return best_A
# EVOLVE-BLOCK-END
