# EVOLVE-BLOCK-START
"""Simulated annealing on a compact integer set, directly optimizing the ratio
log|A-A|/log|A+A|. Neighborhood biased to collapse sums via symmetry/AP structure."""
import math
import random
import time

import numpy as np


def _counts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0, n
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    return diffs.size, sums.size, n


def _score(a):
    d, s, n = _counts(a)
    if s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 110
    rng = random.Random(20240817)

    best = None
    best_score = -1.0

    seeds = []
    # AP union constructions: dense AP gives tiny |A+A|, add shifted copies
    # to blow up |A-A|.
    for m in (6, 8, 10, 12):
        for k in (2, 3, 4):
            base = list(range(m))
            A = set(base)
            step = m + rng.randint(1, 3)
            for j in range(1, k):
                for x in base:
                    A.add(x + j * step)
            seeds.append(sorted(A))
    # quadratic-ish
    seeds.append([i * i for i in range(14)])
    seeds.append([i * (i + 1) // 2 for i in range(16)])
    seeds.append([2 ** i - 1 for i in range(11)])
    for _ in range(30):
        k = rng.randint(10, 20)
        seeds.append(sorted(rng.sample(range(0, 4 * k), k)))

    for sd in seeds:
        arr = np.array(sorted(set(sd)), dtype=np.int64)
        s = _score(arr)
        if s > best_score:
            best_score = s
            best = arr.copy()

    cur = best.copy()
    cur_score = best_score

    t_start = time.time()
    T0 = 0.08
    steps = 0
    while time.time() < deadline:
        steps += 1
        frac = (time.time() - t_start) / 110.0
        T = T0 * max(1e-6, 1.0 - frac)

        n = cur.size
        cand = cur.copy()
        mv = rng.random()

        if mv < 0.30:
            # shift a block
            i = rng.randrange(n)
            j = rng.randint(i + 1, n)
            delta = rng.randint(-4, 4)
            if delta == 0:
                continue
            cand[i:j] = cand[i:j] + delta
        elif mv < 0.50:
            # single-element move
            i = rng.randrange(n)
            cand[i] += rng.choice([-1, 1, -2, 2, -3, 3])
        elif mv < 0.65:
            # reflect around a pivot -> additive symmetry, collapses sums
            pivot = cur[rng.randrange(n)]
            cand = 2 * pivot - cur
        elif mv < 0.80:
            # swap: remove one, add a new value (keep size)
            i = rng.randrange(n)
            cand = np.delete(cand, i)
            newv = rng.randint(int(cur.min()) - 5, int(cur.max()) + 5)
            cand = np.append(cand, newv)
        else:
            # dilate a subset around center to push differences apart
            center = cur.mean()
            i = rng.randrange(n)
            cand[i] = int(round(center + 1.5 * (cur[i] - center)))

        cand = np.unique(cand)
        if cand.size < 6 or cand.size > 4000:
            continue
        s = _score(cand)
        if s >= cur_score or (T > 1e-9 and rng.random() < math.exp(min(50.0, (s - cur_score) / T))):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand.copy()

        if steps % 3000 == 0:
            cur = best.copy()
            cur_score = best_score

    res = np.unique(best)
    return [int(x) for x in res]


# EVOLVE-BLOCK-END
