# EVOLVE-BLOCK-START
"""Digit-set power construction: search small D maximizing |D-D|/|D+D| ratio,
then form A as an n-fold base-B digit expansion."""
import math
import time
from itertools import combinations


def _stats_small(D):
    dd = set(x - y for x in D for y in D)
    ss = set(x + y for x in D for y in D)
    return len(dd), len(ss)


def _best_digit_set(maxsz=6, maxval=30):
    """Search small integer sets D (containing 0) maximizing log|D-D|/log|D+D|."""
    best = None
    best_ratio = -1.0
    for sz in range(2, maxsz + 1):
        # D must contain 0 (can shift any set to include 0)
        for rest in combinations(range(1, maxval + 1), sz - 1):
            D = (0,) + rest
            nd, ns = _stats_small(D)
            if ns < 2:
                continue
            ratio = math.log(nd) / math.log(ns)
            # tie-break: prefer larger ratio; if close prefer smaller sum set
            if ratio > best_ratio + 1e-12:
                best_ratio = ratio
                best = D
    return best, best_ratio


def _digit_power(D, B, n, max_size=4000):
    """A = {sum d_i B^i, d_i in D}. Requires B > span to avoid overlap."""
    A = [0]
    p = 1
    for _ in range(n):
        if len(A) * len(D) > max_size:
            break
        newA = []
        for a in A:
            for d in D:
                newA.append(a + d * p)
        A = newA
        p *= B
    return A


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    nd, ns = len(diffs), len(sums)
    if ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100, nd, ns


def solve():
    deadline = time.time() + 95

    D, ratio = _best_digit_set(maxsz=6, maxval=28)
    if D is None:
        D = (0, 1, 3, 7)

    span = max(D)
    B = span + 1  # ensures no carry overlap between digits

    best = None
    best_score = -1.0

    # Try various n (number of digits). Larger n gives more digits but each
    # step multiplies |A| by |D|; cap at 4000 elements.
    best_n_family = []
    for n in range(2, 12):
        A = _digit_power(D, B, n, max_size=4000)
        if len(A) < 2 or len(A) > 4000:
            continue
        sc, nd, ns = _score(A)
        if sc > best_score:
            best_score = sc
            best = A[:]
        best_n_family.append((n, len(A), sc))

    # Short local refinement: try toggling boundary elements to nudge score up.
    if best is not None:
        cur = sorted(set(best))
        cur_score = _score(cur)[0]
        improved = True
        it = 0
        while improved and time.time() < deadline and it < 200:
            improved = False
            it += 1
            # try adding nearby element (often touches sums only)
            for delta in (1, -1, max(D) + 1, -(max(D) + 1)):
                if len(cur) >= 4000:
                    break
                cand = sorted(set(cur + [cur[-1] + delta]))
                sc = _score(cand)[0]
                if sc > cur_score:
                    cur, cur_score = cand, sc
                    improved = True
                    if sc > best_score:
                        best_score = sc
                        best = cand[:]
                    break
            # try removing an element
            for i in (0, -1):
                if len(cur) <= 2:
                    break
                cand = cur[:i] + cur[i + 1:]
                sc = _score(cand)[0]
                if sc > cur_score:
                    cur, cur_score = cand, sc
                    improved = True
                    if sc > best_score:
                        best_score = sc
                        best = cand[:]
                    break

    if best is None:
        best = [0, 1, 3, 7]

    A = sorted(set(best))
    A = [x for x in A if abs(x) <= 10**15][:4000]
    return A
# EVOLVE-BLOCK-END
