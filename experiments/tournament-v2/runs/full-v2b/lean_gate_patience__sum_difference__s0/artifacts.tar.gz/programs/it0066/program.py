"""Maximize log|A-A|/log|A+A| via a digit-set construction.

For A = { sum_i d_i B^i : d_i in D } with base B > 2*max|D| (so no carries),
the digit maps are bijective and
    |A-A| = |D-D|^m ,  |A+A| = |D+D|^m
so the ratio equals log|D-D| / log|D+D| of the small digit set D, while the
number of digits m only controls |A| (hence the size bonus).  Note shifting D by
a constant leaves |D-D| and |D+D| unchanged, so we may take min(D) = 0.

The whole problem therefore reduces to finding a small D with a large ratio.
We run a simulated-annealing search over D (variable size) with an exact numpy
scorer, seeded from many shapes, then blow the best D up into as many base-B
digits as fit inside the 4000-element / 1e15 limits.
"""
import math
import time
import random
from itertools import product

import numpy as np


def _dif_sum(D):
    a = np.asarray(D, dtype=np.int64)
    dif = np.unique(a[:, None] - a[None, :]).size
    sm = np.unique(a[:, None] + a[None, :]).size
    return int(dif), int(sm)


def _ratio(D):
    if len(D) < 2:
        return 0.0
    dif, sm = _dif_sum(D)
    if dif <= 1 or sm <= 1:
        return 0.0
    return math.log(dif) / math.log(sm)


def _anneal(D0, rng, deadline, iters):
    """Simulated annealing on a digit set (min 0, nonneg coordinates)."""
    D = sorted(set(D0))
    if len(D) < 2:
        D = [0, 1]
    r = _ratio(D)
    best, bestr = D[:], r
    if r == 0.0:
        r = 1e-9
    temp = 0.02
    for it in range(iters):
        if (it & 1023) == 0 and time.time() > deadline:
            break
        D2 = D[:]
        k = len(D2)
        mode = rng.random()
        R = max(6, 3 * k)
        if mode < 0.5:
            i = rng.randrange(k)
            D2[i] = rng.randrange(R)
        elif mode < 0.75:
            i = rng.randrange(k)
            D2[i] = D2[i] + rng.randint(-2, 2)
            if D2[i] < 0:
                D2[i] = rng.randrange(R)
        elif mode < 0.9:
            # add an element
            D2.append(rng.randrange(R))
        else:
            # remove an element (keep >= 2)
            if k > 2:
                del D2[rng.randrange(k)]
        D2 = sorted(set(x for x in D2 if x >= 0))
        if len(D2) < 2:
            continue
        r2 = _ratio(D2)
        if r2 > r or rng.random() < math.exp((r2 - r) / temp):
            D = D2
            r = r2
            if r2 > bestr:
                best, bestr = D2[:], r2
        temp *= 0.9997
        if temp < 1e-4:
            temp = 1e-4
    return best, bestr


def solve():
    deadline = time.time() + 105.0
    rng = random.Random(246813579)

    # ---- diverse seeds -------------------------------------------------
    seeds = [[0, 1, 3, 7], [0, 1, 4], [0, 1, 3, 9], [0, 1, 2, 4, 8],
             [0, 1, 3, 4, 9, 10, 12, 13]]
    for k in range(3, 26):
        seeds.append(sorted(set(int(round(1.5 ** i)) for i in range(k))))
        seeds.append(sorted(set(i * i for i in range(k))))
        seeds.append(sorted(rng.sample(range(max(6, 3 * k)), k)))
        # two-block
        p = max(2, k // 2)
        seeds.append(sorted(set(list(range(p)) + [30 + i for i in range(k - p)])))

    bestD, bestR = [0, 1, 3, 7], _ratio([0, 1, 3, 7])

    # ---- annealing sweeps ---------------------------------------------
    rounds = 0
    while time.time() < deadline:
        for s in seeds:
            if time.time() > deadline:
                break
            D, r = _anneal(s, rng, deadline, 4000)
            if r > bestR:
                bestR, bestD = r, D[:]
        rounds += 1
        if rounds > 40:
            break

    # ---- blow best D up into many base-B digits -----------------------
    D = sorted(set(int(x) for x in bestD))
    if len(D) < 2:
        D = [0, 1, 3, 7]
    k = len(D)
    mx = max(D)
    B = max(2, 2 * mx + 1)          # carry-free base

    # largest m with |D|^m <= 4000 and magnitudes within 1e15
    m = 1
    while True:
        if k ** (m + 1) > 4000:
            break
        tot = mx * ((B ** (m + 1) - 1) // (B - 1)) if B > 1 else mx
        if tot > 10 ** 15:
            break
        m += 1

    A = []
    if k ** m <= 4000:
        for combo in product(D, repeat=m):
            v = 0
            p = 1
            for d in combo:
                v += d * p
                p *= B
            A.append(v)
    else:
        A = D[:]

    A = sorted(set(A))
    if len(A) < 2:
        A = [0, 1, 2, 4]
    if len(A) > 4000:
        A = A[:4000]

    return [int(x) for x in A]
