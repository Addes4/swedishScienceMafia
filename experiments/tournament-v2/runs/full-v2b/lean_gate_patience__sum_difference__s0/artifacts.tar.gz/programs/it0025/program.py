# EVOLVE-BLOCK-START
"""Randomized search over sets built from a suit of arithmetic progressions.

A is a union of arithmetic progressions (clusters). We randomize the cluster
parameters (count, lengths, gaps, offsets), then hill-climb on the best
configuration using fast numpy counting of exact |A-A| and |A+A|.
"""
import math
import time
import random
import numpy as np


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.shape[0]
    if n < 2:
        return 0, 0
    d = (a[:, None] - a[None, :]).ravel()
    nd = np.unique(d).size
    s = (a[:, None] + a[None, :]).ravel()
    ns = np.unique(s).size
    return int(nd), int(ns)


def _score(a):
    if len(a) < 2:
        return 0.0
    nd, ns = _counts(a)
    if nd < 1 or ns < 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / len(a)) / 100.0


def _build(clusters):
    vals = set()
    for (o, g, L) in clusters:
        for k in range(L):
            vals.add(o + k * g)
    return sorted(vals)


def _score_clusters(clusters):
    a = _build(clusters)
    if len(a) < 2:
        return -1.0, a
    return _score(a), a


def _random_config(rng):
    ncl = rng.randint(3, 9)
    clusters = []
    base = 0
    gset = set()
    for i in range(ncl):
        while True:
            g = rng.choice([1, 1, 2, 2, 3, 4, 5, 6, 7, 8, 9, 11, 13])
            if g not in gset:
                gset.add(g)
                break
        L = rng.randint(8, 40)
        clusters.append((base, g, L))
        base += g * L + rng.randint(1, max(2, g * L // 2))
    return clusters


def _hillclimb(clusters, best_score, best_a, deadline):
    cur = clusters
    cur_score = best_score
    deltas = [1, 2, 3, 5, 7, -1, -2, -3, -5, -7]
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for ci in range(len(cur)):
            if time.time() > deadline:
                break
            o, g, L = cur[ci]
            for (field, vals) in (('g', deltas), ('o', deltas),
                                  ('L', [1, -1, 2, -2, 3, -3, 4, -4])):
                for d in vals:
                    if time.time() > deadline:
                        break
                    trial = list(cur)
                    if field == 'g':
                        ng = g + d
                        if ng < 1:
                            continue
                        trial[ci] = (o, ng, L)
                    elif field == 'o':
                        trial[ci] = (o + d, g, L)
                    else:
                        nL = L + d
                        if nL < 3 or nL > 400:
                            continue
                        trial[ci] = (o, g, nL)
                    s, a = _score_clusters(trial)
                    if s > cur_score + 1e-12:
                        cur_score = s
                        cur = trial
                        if s > best_score:
                            best_score = s
                            best_a = a
                        improved = True
                        break
                if improved:
                    break
    return best_score, best_a, cur


def solve():
    deadline = time.time() + 110.0
    rng = random.Random(12345)

    best_score = 0.0
    best_a = None

    # Deterministic seeds
    seeds = []
    for ncl in (3, 4, 5, 6, 7):
        for L in (10, 16, 24, 32):
            g = 1
            step = L + 1
            seeds.append([(i * step, g, L) for i in range(ncl)])
    # mixed gap seeds
    for ncl in (3, 4, 5):
        gaps = [1, 2, 3, 5, 8][:ncl]
        for L in (12, 20, 28):
            offs = []
            b = 0
            for i in range(ncl):
                offs.append(b)
                b += gaps[i] * L + 1
            seeds.append([(offs[i], gaps[i], L) for i in range(ncl)])

    for cfg in seeds:
        if time.time() > deadline:
            break
        s, a = _score_clusters(cfg)
        if s > best_score:
            best_score = s
            best_a = a

    # Randomized restarts + hill-climb
    while time.time() < deadline:
        cfg = _random_config(rng)
        s, a = _score_clusters(cfg)
        if a is None or len(a) < 2:
            continue
        bs, ba, _ = _hillclimb(cfg, s, a, deadline)
        if bs > best_score:
            best_score = bs
            best_a = ba

    if best_a is None:
        return [0, 1, 2, 3]
    return best_a
# EVOLVE-BLOCK-END
