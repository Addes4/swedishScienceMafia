# EVOLVE-BLOCK-START
"""Digit-set construction over several bases with a fast numpy scorer."""
import math
import time
import numpy as np


def _score_counts(nd, ns, n):
    if n < 2 or ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _counts_np(arr):
    """Exact |A-A|, |A+A| for a numpy int64 array."""
    n = arr.size
    if n < 2:
        return 0, 0, n
    # differences
    d = (arr[:, None] - arr[None, :]).ravel()
    nd = np.unique(d).size
    s = (arr[:, None] + arr[None, :]).ravel()
    ns = np.unique(s).size
    return nd, ns, n


def _counts_set(A):
    s = set(A)
    diffs = set()
    sums = set()
    L = list(s)
    for i in range(len(L)):
        ai = L[i]
        for j in range(len(L)):
            bj = L[j]
            diffs.add(ai - bj)
            sums.add(ai + bj)
    return len(diffs), len(sums)


def _counts(A):
    n = len(A)
    arr = np.array(sorted(set(A)), dtype=np.int64)
    n = arr.size
    if n < 2:
        return 0, 0, n
    if n <= 700:
        # numpy path (memory-safe)
        d = (arr[:, None] - arr[None, :]).ravel()
        nd = np.unique(d).size
        s = (arr[:, None] + arr[None, :]).ravel()
        ns = np.unique(s).size
        return nd, ns, n
    nd, ns = _counts_set(A)
    return nd, ns, n


def _score(A):
    nd, ns, n = _counts(A)
    if n < 2:
        return 0.0
    return _score_counts(nd, ns, n)


def _digit_set(digits, base, depth):
    A = [0]
    for _ in range(depth):
        new = []
        p = base
        for x in A:
            for d in digits:
                new.append(x * p + d)
        A = new
    return A


def _eval_digits(digits, base, depth):
    A = _digit_set(digits, base, depth)
    if len(A) > 4000:
        return -1.0, A
    A = sorted(set(A))
    if len(A) < 3:
        return -1.0, A
    return _score(A), A


def solve():
    deadline = time.time() + 105.0

    best_A = [0, 1]
    best_score = 0.0

    # Sweep bases and digit sets.  The "canonical" high-ratio set uses a
    # digit set {0} u {large-spread digits} with many digits so differences are
    # plentiful while sums collapse (many pairs share sums).
    digit_choices = [
        [0, 1],
        [0, 1, 2],
        [0, 1, 2, 3],
        [0, 1, 3],
        [0, 1, 4],
        [0, 1, 2, 5],
        [0, 1, 2, 3, 4],
        [0, 1, 2, 3, 4, 5],
        [0, 1, 2, 4, 8],
        [0, 1, 3, 9],
        [0, 1, 2, 3, 6, 10],
        [0, 1, 2, 4, 7, 11],
    ]
    bases = [2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20, 25]

    for digits in digit_choices:
        if time.time() > deadline:
            break
        for base in bases:
            if time.time() > deadline:
                break
            # find max depth keeping size <= 4000
            for depth in range(1, 12):
                sz = len(digits) ** depth
                if sz > 4000:
                    break
                if sz < 3:
                    continue
                s, A = _eval_digits(digits, base, depth)
                if s > best_score:
                    best_score = s
                    best_A = A

    # Greedy add polish: try inserting elements that come from small linear
    # combinations at the top scale (extends the digit construction).
    if time.time() < deadline and best_A:
        A = set(best_A)
        cur = _score(A)
        HF = 1_000_000_000_000
        span = max(A) - min(A) if len(A) > 1 else 1
        cands = []
        for x in sorted(A)[:80]:
            for d in (1, -1, 2, -2, 3, -3, span // 2, -span // 2):
                cands.append(x + d)
        cands = sorted(set(cands))
        for x in cands:
            if time.time() > deadline:
                break
            if x in A:
                continue
            if abs(x) > 10 ** 15:
                continue
            trial = set(A)
            trial.add(x)
            if len(trial) > 4000:
                continue
            s = _score(trial)
            if s > cur + 1e-12:
                A = trial
                cur = s
        if cur > best_score:
            best_score = cur
            best_A = sorted(A)

    best_A = sorted(set(best_A))
    if len(best_A) < 2:
        best_A = [0, 1]
    return best_A
# EVOLVE-BLOCK-END
