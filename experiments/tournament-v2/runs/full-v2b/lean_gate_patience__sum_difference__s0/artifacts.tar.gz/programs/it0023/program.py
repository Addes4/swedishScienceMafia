# EVOLVE-BLOCK-START
"""Deterministic structured construction: A is a union of arithmetic-progression clusters.

Each cluster is an arithmetic progression of length L with internal gap g. Clusters are
placed at offsets o_i. We tune (offsets, internal gaps, cluster lengths) deterministically
with a hill-climbing loop driven by a fast numpy-based exact counter for |A-A| and |A+A|.
The goal: differences within clusters stay distinct (many differences), while sums
collide heavily across clusters (few sums).
"""
import math
import time
import numpy as np


def _diffs_sums_np(a):
    """Exact |A-A| and |A+A| using numpy on integer array a (1D, distinct ints)."""
    a = np.asarray(a, dtype=np.int64)
    n = a.shape[0]
    if n < 2:
        return 0, 0
    # Differences: a[:,None]-a[None,:]
    d = (a[:, None] - a[None, :]).ravel()
    nd = np.unique(d).size
    s = (a[:, None] + a[None, :]).ravel()
    ns = np.unique(s).size
    return int(nd), int(ns)


def _score_counts(nd, ns, n):
    if n < 2 or ns < 1 or nd < 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _score_np(a):
    nd, ns = _diffs_sums_np(a)
    return _score_counts(nd, ns, len(a))


def _build(clusters):
    """clusters: list of (offset, gap, length). Returns sorted distinct int list."""
    vals = []
    for (o, g, L) in clusters:
        for k in range(L):
            vals.append(o + k * g)
    vals = sorted(set(vals))
    return vals


def _try_cluster_config(clusters, time_left, best):
    a = _build(clusters)
    if len(a) < 2:
        return best
    s = _score_np(a)
    if s > best[0]:
        return (s, a, clusters)
    return best


def solve():
    """Return list A making |A-A| large, |A+A| small."""
    deadline = time.time() + 110.0
    best = (0.0, None, None)

    # Deterministic base configurations: several clusters, distinct gaps, moderate offsets.
    base_configs = []
    # Config1: 4 APs of length ~30 with gaps that are pairwise distinct and dominate offsets
    for ncl in (3, 4, 5, 6):
        for L in (18, 24, 30, 36, 48):
            gaps = [1 + 2 * i for i in range(ncl)]  # 1,3,5,...
            # place offsets spaced by a large prime-ish value so inter-cluster sums overlap
            offs = []
            base = 0
            for i in range(ncl):
                offs.append(base)
                base += gaps[i] * L + 1
            clusters = [(offs[i], gaps[i], L) for i in range(ncl)]
            base_configs.append(clusters)

    # Config with all clusters same gap -> many sum collisions, differences from cluster offsets
    for ncl in (4, 5, 6, 7, 8):
        for L in (10, 15, 20, 25):
            g = 1
            step = L * g + 1
            clusters = [(i * step, g, L) for i in range(ncl)]
            base_configs.append(clusters)

    # Evaluate base configs quickly, keep best.
    for clusters in base_configs:
        if time.time() > deadline:
            break
        best = _try_cluster_config(clusters, deadline, best)

    if best[1] is None:
        return [0, 1, 2, 3]

    # Deterministic hill-climbing on the best cluster list.
    cur = best[2]
    cur_score = best[0]
    improved = True
    # candidate perturbation amounts
    deltas = [1, 2, 3, 5, 7, 11, -1, -2, -3, -5, -7, -11]
    while improved and time.time() < deadline:
        improved = False
        # try perturb each cluster's offset and gap, and cluster lengths
        for ci in range(len(cur)):
            if time.time() > deadline:
                break
            o, g, L = cur[ci]
            # perturb gap
            for dg in deltas:
                if time.time() > deadline:
                    break
                ng = g + dg
                if ng < 1:
                    continue
                trial = list(cur)
                trial[ci] = (o, ng, L)
                a = _build(trial)
                if len(a) < 2:
                    continue
                s = _score_np(a)
                if s > cur_score + 1e-12:
                    cur_score = s
                    cur = trial
                    improved = True
                    break
            # perturb offset
            for do in deltas:
                if time.time() > deadline:
                    break
                no = o + do
                trial = list(cur)
                trial[ci] = (no, g, L)
                a = _build(trial)
                if len(a) < 2:
                    continue
                s = _score_np(a)
                if s > cur_score + 1e-12:
                    cur_score = s
                    cur = trial
                    improved = True
                    break
            # perturb length
            for dl in (1, -1, 2, -2, 3, -3, 5, -5):
                if time.time() > deadline:
                    break
                nL = L + dl
                if nL < 2 or nL > 400:
                    continue
                trial = list(cur)
                trial[ci] = (o, g, nL)
                a = _build(trial)
                if len(a) < 2:
                    continue
                s = _score_np(a)
                if s > cur_score + 1e-12:
                    cur_score = s
                    cur = trial
                    improved = True
                    break
        if cur_score > best[0]:
            best = (cur_score, _build(cur), list(cur))

    return best[1]
# EVOLVE-BLOCK-END
