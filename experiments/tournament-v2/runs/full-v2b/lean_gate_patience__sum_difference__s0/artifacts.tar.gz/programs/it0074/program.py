# EVOLVE-BLOCK-START
"""Digit-set construction with carry-free base.

A = { sum_i d_i * B^i : d_i in D }.
If B > 2*max(D) + 1 there are no carries, so |A-A| = |D-D|^m and |A+A| = |D+D|^m.
Maximizing log|A-A|/log|A+A| reduces to maximizing log|D-D|/log|D+D|.
We search D by exhaustive enumeration over small ranges plus a strong
randomized local search scored exactly with numpy, then expand to a full size
base-B digit set.
"""
import math
import time
import random
import numpy as np

TIME_LIMIT = 105.0


def _counts(d):
    arr = np.asarray(sorted(set(int(x) for x in d)), dtype=np.int64)
    if arr.size <= 1:
        return 0, arr.size
    diffs = (arr[:, None] - arr[None, :]).ravel()
    sums = (arr[:, None] + arr[None, :]).ravel()
    return int(np.unique(diffs).size), int(np.unique(sums).size)


def _ratio(d):
    nd, ns = _counts(d)
    if ns <= 1 or nd <= 1:
        return 0.0
    return math.log(nd) / math.log(ns)


def _obj(d):
    # true objective for the final set: ratio plus size bonus
    nd, ns = _counts(d)
    if ns <= 1 or nd <= 1:
        return -1.0
    n = len(set(int(x) for x in d))
    return math.log(nd) / math.log(ns)


def solve():
    start = time.time()
    random.seed(987654321)
    np.random.seed(987654321)

    def norm(d):
        d = sorted(set(int(x) for x in d))
        if not d:
            return []
        lo = d[0]
        return [x - lo for x in d]

    # ---- exhaustive enumeration of small sets inside [0, R] ----
    best_D = [0, 1]
    best_r = _ratio([0, 1])

    # exhaustive over subsets of [0, R] of size up to 5
    def exhaustive(R, maxsz):
        nonlocal best_D, best_r
        from itertools import combinations
        base = list(range(R + 1))
        for sz in range(2, maxsz + 1):
            for comb in combinations(base, sz):
                if time.time() - start > TIME_LIMIT * 0.35:
                    return
                r = _ratio(list(comb))
                if r > best_r + 1e-12:
                    best_r = r
                    best_D = list(comb)

    exhaustive(20, 4)
    exhaustive(14, 5)

    # ---- randomized local search / annealing on larger sets ----
    def climb(D, iters):
        D = norm(D)
        cur = _ratio(D)
        for _ in range(iters):
            if time.time() - start > TIME_LIMIT * 0.8:
                break
            cand = D[:]
            mv = random.randrange(6)
            if mv == 0 and cand:                       # shift a point
                i = random.randrange(len(cand))
                cand[i] += random.choice([-3, -2, -1, 1, 2, 3])
            elif mv == 1:                               # add a point
                hi = max(cand) if cand else 5
                cand.append(random.randrange(0, hi + 4))
            elif mv == 2 and len(cand) > 2:             # remove a point
                cand.pop(random.randrange(len(cand)))
            elif mv == 3 and cand:                      # extend top
                cand.append(cand[-1] + random.choice([1, 2, 3, 4, 5]))
            elif mv == 4 and cand:                      # insert random
                hi = max(cand) if cand else 5
                cand.append(random.randrange(0, hi + 6))
            else:                                       # scale/perturb
                cand = [x + random.choice([-1, 0, 1]) for x in cand]
            cand = norm(cand)
            if len(cand) < 2 or len(cand) > 80:
                continue
            r = _ratio(cand)
            if r > cur:
                cur, D = r, cand
        return D, cur

    seeds = [
        [0, 1, 2, 3, 4, 5],
        [0, 1, 2, 4, 7, 11],
        [0, 1, 3, 7, 12, 20],
        [0, 2, 5, 9, 14, 20, 27],
        [0, 1, 4, 9, 16, 25],
        [0, 1, 2, 4, 8, 16, 32],
        [0, 3, 5, 11, 19, 27, 38],
        [0, 1, 5, 11, 19, 29, 40, 52],
        [0, 1, 2, 3, 4, 5, 6, 7],
        [0, 1, 3, 4, 9, 10, 12, 13],
    ]
    for s in seeds:
        if time.time() - start > TIME_LIMIT * 0.78:
            break
        D, r = climb(s, iters=4000)
        if r > best_r + 1e-12:
            best_r, best_D = r, D[:]

    # a few random restarts
    for _ in range(40):
        if time.time() - start > TIME_LIMIT * 0.82:
            break
        k = random.randrange(4, 20)
        s = norm([random.randrange(0, 40) for _ in range(k)])
        D, r = climb(s, iters=1500)
        if r > best_r + 1e-12:
            best_r, best_D = r, D[:]

    D = norm(best_D)
    if len(D) < 2:
        D = [0, 1]

    n = len(D)
    dmax = max(abs(x) for x in D)
    # carry-free base
    B = max(2 * dmax + 1, 2)

    # choose m: |D|^m <= 4000 and max value <= 1e15
    best_m = 1
    best_Adom = -1
    m = 1
    while n ** m <= 4000:
        if (B ** m) - 1 > 10**15:
            break
        # domain size n^m
        if n ** m > best_Adom:
            best_Adom = n ** m
            best_m = m
        m += 1
    m = best_m

    # build A
    A = [0]
    for _ in range(m):
        A = [v * B + d for v in A for d in D]
    A = sorted(set(int(x) for x in A))

    lim = 10**15
    A = [x for x in A if abs(x) <= lim]
    if len(A) > 4000:
        A = A[:4000]
    if not A:
        A = [0, 1]
    return A
# EVOLVE-BLOCK-END
