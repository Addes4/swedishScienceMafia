# EVOLVE-BLOCK-START
"""Mixed-radix digit construction with direct (real) evaluation of candidate level sequences."""
import math
import time
import itertools
import random
import numpy as np


def _counts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    return diffs, sums


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return -1.0
    diffs, sums = _counts(a)
    if sums < 2 or diffs < 2:
        return -1.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _digit_stats(D):
    D = list(D)
    dd = set()
    ss = set()
    for x in D:
        for y in D:
            dd.add(x - y)
            ss.add(x + y)
    return len(dd), len(ss)


def _search_digit_sets(deadline):
    cands = []
    seen = set()

    def consider(D):
        key = tuple(sorted(D))
        if key in seen:
            return
        seen.add(key)
        ndd, nss = _digit_stats(D)
        if nss < 2 or ndd < 2:
            return
        ldd = math.log(ndd)
        lss = math.log(nss)
        cands.append((ldd / lss, ldd, lss, len(key), list(key)))

    universe = list(range(13))
    for sz in range(2, 6):
        if time.time() > deadline:
            break
        for comb in itertools.combinations(universe, sz):
            consider(comb)

    cands.sort(reverse=True, key=lambda t: t[0])
    beam = [t[4] for t in cands[:300]]
    for sz in range(6, 10):
        if time.time() > deadline:
            break
        for D in beam:
            mx = max(D)
            for v in range(0, mx + 5):
                if v in D:
                    continue
                consider(D + [v])
        cands.sort(reverse=True, key=lambda t: t[0])
        beam = [t[4] for t in cands[:300]]
        if not beam:
            break

    # Additional beam that maximizes raw ldd - a*lss (Bohr-style/sum-poor sets).
    best_ldd = []
    def raw_consider(D):
        key = tuple(sorted(D))
        ndd, nss = _digit_stats(D)
        if nss < 2 or ndd < 2:
            return
        ldd = math.log(ndd); lss = math.log(nss)
        best_ldd.append((ldd - 0.45 * lss, ldd, lss, len(key), list(key)))

    uni2 = list(range(16))
    for sz in range(2, 6):
        if time.time() > deadline:
            break
        for comb in itertools.combinations(uni2, sz):
            raw_consider(comb)
    best_ldd.sort(reverse=True, key=lambda t: t[0])
    beam2 = [t[4] for t in best_ldd[:200]]
    for sz in range(6, 11):
        if time.time() > deadline:
            break
        for D in beam2:
            mx = max(D)
            for v in range(0, mx + 4):
                if v in D:
                    continue
                raw_consider(D + [v])
        best_ldd.sort(reverse=True, key=lambda t: t[0])
        nb = []
        seenk = set()
        for t in best_ldd:
            k = tuple(t[4])
            if k in seenk:
                continue
            seenk.add(k)
            nb.append(t)
            if len(nb) >= 200:
                break
        beam2 = [t[4] for t in nb]
        if not beam2:
            break
    for (_, ldd, lss, sz, D) in best_ldd[:400]:
        cands.append((ldd / lss, ldd, lss, sz, D))

    dd = {}
    for c in cands:
        k = tuple(c[4])
        if k not in dd or c[1] / max(c[2], 1e-9) > dd[k][1] / max(dd[k][2], 1e-9):
            dd[k] = c
    out = list(dd.values())
    out.sort(reverse=True, key=lambda t: t[0])
    return out


def _build_mixed(levels, B):
    A = [0]
    pw = 1
    for D in levels:
        newA = []
        for a in A:
            for d in D:
                newA.append(a + d * pw)
        A = newA
        pw *= B
    return np.array(sorted(set(A)), dtype=np.int64)


def _span(D):
    return max(D) - min(D)


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    dig = _search_digit_sets(min(deadline, time.time() + 25))
    if not dig:
        return [0, 1]

    sets = [(ldd / lss, ldd, lss, len(D), D) for (r, ldd, lss, sz, D) in dig]
    pool = list(sets[:400])
    for s in sorted(sets, key=lambda t: t[1], reverse=True)[:150]:
        pool.append(s)
    for s in sorted(sets, key=lambda t: t[1] - 0.45 * t[2], reverse=True)[:150]:
        pool.append(s)
    pd = {}
    for s in pool:
        k = tuple(s[4])
        pd[k] = s
    pool = list(pd.values())

    def build_and_score(levels):
        if not levels:
            return None, -1.0
        span = max(_span(D) for D in levels)
        B = max(2 * span + 1, 2)
        lv = list(levels)
        while lv:
            A = _build_mixed(lv, B)
            if A.size < 2:
                lv.pop()
                continue
            if np.max(np.abs(A)) <= 10**15 and A.size <= 4000:
                return A, _score(A)
            lv.pop()
            if lv:
                span = max(_span(D) for D in lv)
                B = max(2 * span + 1, 2)
        return None, -1.0

    # ---- Generate many candidate level sequences and evaluate them for real ----
    cand_level_seqs = []
    seen_seq = set()

    def add_seq(levels):
        if not levels:
            return
        key = tuple(tuple(sorted(D)) for D in levels)
        if key in seen_seq:
            return
        seen_seq.add(key)
        cand_level_seqs.append(list(levels))

    # pool sorted by ratio and by raw ldd
    pool_by_ratio = sorted(pool, key=lambda t: t[0], reverse=True)
    pool_by_ldd = sorted(pool, key=lambda t: t[1], reverse=True)
    pool_by_tilt = sorted(pool, key=lambda t: t[1] - 0.45 * t[2], reverse=True)

    # 1) greedy cumulative ratio chains from many seeds, for several candidate orderings
    for cand_pool in (pool_by_ratio, pool_by_ldd, pool_by_tilt):
        for (seed_r, seed_ldd, seed_lss, seed_sz, seed_D) in cand_pool[:40]:
            cum_ldd = seed_ldd
            cum_lss = seed_lss
            size = seed_sz
            levels = [seed_D]
            add_seq(levels)
            while size <= 4000:
                best_gain = None
                for (r, ldd, lss, sz, D) in cand_pool:
                    if size * sz > 4000:
                        continue
                    new_r = (cum_ldd + ldd) / (cum_lss + lss)
                    if new_r > cum_ldd / cum_lss + 1e-12:
                        if best_gain is None or new_r > best_gain[0]:
                            best_gain = (new_r, ldd, lss, sz, D)
                if best_gain is None:
                    break
                _, ldd, lss, sz, D = best_gain
                cum_ldd += ldd
                cum_lss += lss
                size *= sz
                levels.append(D)
                add_seq(levels)
                if len(levels) > 60:
                    break
                if time.time() > deadline:
                    break

    # 2) beam search over level sequences using analytic ratio, recording each state
    seeds = [s for s in sets[:60]]
    beam_states = []
    for (r, ldd, lss, sz, D) in seeds:
        beam_states.append((ldd, lss, sz, [D]))

    def cum_ratio(st):
        return st[0] / st[1]

    beam_states.sort(key=cum_ratio, reverse=True)
    max_states = 250
    for step in range(40):
        if time.time() > deadline:
            break
        newstates = []
        for (cldd, clss, size, levels) in beam_states:
            added = 0
            for (r, ldd, lss, sz, D) in pool_by_ratio:
                if size * sz > 4000:
                    continue
                nl = cldd + ldd
                ns = clss + lss
                newstates.append((nl, ns, size * sz, levels + [D]))
                added += 1
                if added >= 60:
                    break
        if not newstates:
            break
        newstates.sort(key=cum_ratio, reverse=True)
        beam_states = newstates[:max_states]
        for st in beam_states[:60]:
            add_seq(st[3])

    for st in beam_states[:300]:
        add_seq(st[3])

    # 3) randomized perturbations / recombinations of good sequences
    base_seqs = [s for s in cand_level_seqs if len(s) >= 1][:400]
    rng = random.Random(12345)
    tries = 0
    while time.time() < deadline and tries < 4000:
        tries += 1
        if not base_seqs:
            break
        s = list(rng.choice(base_seqs))
        op = rng.random()
        if op < 0.4 and len(s) >= 1:
            # swap one level
            i = rng.randrange(len(s))
            s[i] = rng.choice(pool)[4]
        elif op < 0.8:
            # replace a random prefix by a fresh greedy continuation
            k = rng.randrange(len(s) + 1)
            s = s[:k]
            cur = 1
            for D in s:
                cur *= len(D)
            while cur <= 4000:
                D = rng.choice(pool)[4]
                if cur * len(D) > 4000:
                    break
                s.append(D)
                cur *= len(D)
        else:
            # drop a level
            if len(s) > 1:
                s.pop(rng.randrange(len(s)))
        add_seq(s)

    # ---- Evaluate all candidate level sequences for real, keep best ----
    # First dedup and prioritize by analytic ratio to evaluate the most promising first,
    # but evaluate *all* if time permits.
    def seq_ratio(levels):
        cl = 0.0
        cs = 0.0
        for D in levels:
            ldd, lss = _digit_stats(D)
            cl += math.log(max(ldd, 2))
            cs += math.log(max(lss, 2))
        return cl / cs

    cand_level_seqs.sort(key=seq_ratio, reverse=True)
    evaluated = 0
    for levels in cand_level_seqs:
        if time.time() > deadline:
            break
        A, sc = build_and_score(levels)
        evaluated += 1
        if A is not None and sc > best_score:
            best_score = sc
            best = A.tolist()

    if best is None:
        best = [0, 1]

    # ---- Final local refinement: insert / remove / shift elements ----
    a = sorted(set(int(x) for x in best))
    improved = True
    rounds = 0
    while improved and rounds < 60 and time.time() < deadline:
        improved = False
        rounds += 1
        base_arr = np.array(a, dtype=np.int64)
        cand_adds = []
        lo, hi = a[0], a[-1]
        cand_adds.append(hi + 1)
        cand_adds.append(lo - 1)
        diffs = np.diff(base_arr)
        if diffs.size:
            order = np.argsort(diffs)[::-1]
            for j in order[:5]:
                gi = int(j)
                cand_adds.append(int(a[gi]) + int(diffs[gi]) // 2)
        for c in cand_adds:
            if len(a) >= 4000:
                break
            trial = np.array(sorted(set(a + [c])), dtype=np.int64)
            sc = _score(trial)
            if sc > best_score:
                best_score = sc
                a = trial.tolist()
                improved = True
                break
        if improved:
            continue
        for idx in (0, len(a) - 1):
            if len(a) <= 2:
                break
            trial_list = a[:idx] + a[idx + 1:]
            trial = np.array(trial_list, dtype=np.int64)
            sc = _score(trial)
            if sc > best_score:
                best_score = sc
                a = trial_list
                improved = True
                break

    return sorted(set(int(x) for x in a))
# EVOLVE-BLOCK-END
