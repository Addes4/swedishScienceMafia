# EVOLVE-BLOCK-START
"""Mixed-radix digit-set construction with exact scoring.

A = { sum_i b^i * d_i : d_i in D_i }  (all combinations)

Sums add digit-by-digit with carries -> many collisions -> small |A+A|.
Differences produce a rich sumset of digit-differences -> large |A-A|.

We hill-climb over the base b and the digit sets D_i with exact numpy counts.
"""
import math
import random
import time

import numpy as np


def _counts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0, n
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    return diffs.size, sums.size, n


def _score(a):
    d, s, n = _counts(a)
    if s < 2 or n < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _build(base, digits):
    """digits: list of sorted lists of ints (digit sets). Returns np.array."""
    vals = np.zeros(1, dtype=np.int64)
    coeff = 1
    for ds in digits:
        ds_arr = np.array(sorted(set(ds)), dtype=np.int64)
        vals = (vals[:, None] + coeff * ds_arr[None, :]).reshape(-1)
        coeff *= base
    return np.unique(vals)


def solve():
    deadline = time.time() + 110
    rng = random.Random(20240517)

    best = None
    best_score = -1.0

    # initial candidate digit sets, in "balanced" range so carries happen
    # We let each level have digits around a window.
    def random_digits(level, base, width, offset):
        return sorted(rng.sample(range(offset, offset + width), min(base, width)))

    bases = [4, 5, 6, 7, 8, 10, 12, 16]
    candidates = []
    for base in bases:
        for levels in range(2, 9):
            for width in (2, 3, 4, 5):
                if width > base:
                    continue
                digits = [sorted(rng.sample(range(base), width)) for _ in range(levels)]
                candidates.append((base, digits))

    for base, digits in candidates:
        arr = _build(base, digits)
        if arr.size < 4 or arr.size > 4000:
            continue
        s = _score(arr)
        if s > best_score:
            best_score = s
            best = arr.copy()
            best_params = (base, [list(map(int, ds)) for ds in digits])

    if best is None:
        best = np.array([0, 1, 3, 7, 12], dtype=np.int64)
        best_score = _score(best)
        best_params = (4, [[0, 1], [0, 1]])

    base, digits = best_params
    cur_score = best_score

    # hill-climb over base and digit sets
    steps = 0
    while time.time() < deadline:
        steps += 1
        new_base = base
        new_digits = [list(ds) for ds in digits]

        mv = rng.random()
        if mv < 0.30 and new_digits:
            # add a digit to a random level
            lvl = rng.randrange(len(new_digits))
            cand_d = rng.randrange(0, new_base)
            if cand_d not in new_digits[lvl]:
                new_digits[lvl] = sorted(new_digits[lvl] + [cand_d])
        elif mv < 0.55 and new_digits:
            # remove a digit from a level (keep >=2)
            lvl = rng.randrange(len(new_digits))
            if len(new_digits[lvl]) > 2:
                k = rng.randrange(len(new_digits[lvl]))
                new_digits[lvl] = new_digits[lvl][:k] + new_digits[lvl][k+1:]
        elif mv < 0.75:
            # add a new level
            if len(new_digits) < 12:
                width = rng.randint(2, min(new_base, 5))
                new_digits.append(sorted(rng.sample(range(new_base), width)))
        elif mv < 0.88:
            # remove a level (keep >=1)
            if len(new_digits) > 1:
                k = rng.randrange(len(new_digits))
                new_digits = new_digits[:k] + new_digits[k+1:]
        else:
            # change base
            new_base = rng.choice(bases)
            # clip digits to new base
            clipped = []
            for ds in new_digits:
                c = sorted(set(d for d in ds if d < new_base))
                if len(c) < 2:
                    c = sorted(set(list(c) + rng.sample(range(new_base), 2)))
                clipped.append(c)
            new_digits = clipped

        if not new_digits:
            continue
        arr = _build(new_base, new_digits)
        if arr.size < 4 or arr.size > 4000:
            continue
        s = _score(arr)
        if s > cur_score:
            base, digits = new_base, new_digits
            cur_score = s
            if s > best_score:
                best_score = s
                best = arr.copy()
        elif rng.random() < 0.02:
            # occasional sideways move
            base, digits = new_base, new_digits
            cur_score = s

        # restarts from best
        if steps % 3000 == 0:
            base, digits = best_params if False else (base, digits)

    res = np.unique(best)
    return [int(x) for x in res]


# EVOLVE-BLOCK-END
