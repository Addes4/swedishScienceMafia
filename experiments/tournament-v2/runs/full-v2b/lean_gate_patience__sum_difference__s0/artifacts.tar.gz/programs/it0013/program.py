# EVOLVE-BLOCK-START
"""Digit-set power construction: A = {sum d_i B^i}, with D maximizing
log|D-D|/log|D+D|. Then |A+A|=|D+D|^n and |A-A|=|D-D|^n."""
import math
import time
import itertools
import numpy as np


def _counts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    return diffs, sums


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return -1.0
    diffs, sums = _counts(a)
    if sums < 2 or diffs < 2:
        return -1.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _best_digit_sets(max_size=5, rng=6):
    """Search small digit sets D and rank by log|D-D|/log|D+D|."""
    cands = []
    universe = list(range(rng))
    for sz in range(2, max_size + 1):
        for comb in itertools.combinations(universe, sz):
            D = list(comb)
            dd = set()
            ss = set()
            for x in D:
                for y in D:
                    dd.add(x - y)
                    ss.add(x + y)
            if len(ss) < 2 or len(dd) < 2:
                continue
            ratio = math.log(len(dd)) / math.log(len(ss))
            cands.append((ratio, list(D), len(dd), len(ss)))
    cands.sort(reverse=True, key=lambda t: t[0])
    return cands


def _build_power(D, n, B):
    A = [0]
    pw = 1
    for _ in range(n):
        newA = []
        for a in A:
            for d in D:
                newA.append(a + d * pw)
        A = newA
        pw *= B
    return np.array(sorted(set(A)), dtype=np.int64)


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    candidates = _best_digit_sets(max_size=5, rng=6)

    # Try the top digit sets, building power constructions.
    for (ratio, D, ndd, nss) in candidates[:60]:
        if time.time() > deadline:
            break
        # Determine base B large enough to avoid carries/overlaps, and
        # choose n so |A| = |D|^n <= 4000.
        m = len(D)
        maxn = 1
        while m ** (maxn + 1) <= 4000:
            maxn += 1
        if maxn < 1:
            continue
        # Base must be > max digit value / range to separate digits.
        B = 2 * (max(D) - min(D)) + 1
        B = max(B, 2)
        for n in range(1, maxn + 1):
            if time.time() > deadline:
                break
            A = _build_power(D, n, B)
            # scale to fit |a| <= 1e15 by ensuring max exponent small
            if np.max(np.abs(A)) > 10**15:
                break
            sc = _score(A)
            if sc > best_score:
                best_score = sc
                best = A.tolist()

    # Boundary refinement: try small perturbations (add a nearby element
    # or shift a boundary element) on the best construction.
    if best is not None:
        a = sorted(set(int(x) for x in best))
        improved = True
        rounds = 0
        while improved and rounds < 30 and time.time() < deadline:
            improved = False
            rounds += 1
            base_arr = np.array(a, dtype=np.int64)
            # try adding the max+1, min-1, or other gap-filling elements
            cand_adds = []
            lo, hi = a[0], a[-1]
            cand_adds.append(hi + 1)
            cand_adds.append(lo - 1)
            # try adding an element halfway in a big gap
            diffs = np.diff(base_arr)
            if diffs.size:
                gi = int(np.argmax(diffs))
                cand_adds.append(int(a[gi]) + int(diffs[gi]) // 2)
            for c in cand_adds:
                if len(a) >= 4000:
                    break
                trial = np.array(sorted(set(a + [c])), dtype=np.int64)
                sc = _score(trial)
                if sc > best_score:
                    best_score = sc
                    a = trial.tolist()
                    improved = True
                    break
            if improved:
                continue
            # try removing boundary elements to improve ratio
            for idx in (0, len(a) - 1):
                if len(a) <= 2:
                    break
                trial_list = a[:idx] + a[idx + 1:]
                trial = np.array(trial_list, dtype=np.int64)
                sc = _score(trial)
                if sc > best_score:
                    best_score = sc
                    a = trial_list
                    improved = True
                    break
        best = a

    if best is None:
        best = [0, 1]
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
