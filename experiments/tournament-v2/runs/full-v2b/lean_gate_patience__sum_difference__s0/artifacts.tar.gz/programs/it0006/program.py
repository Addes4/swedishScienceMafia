# EVOLVE-BLOCK-START
"""Structured construction: union of AP clusters tuned for many differences, few sums."""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    nd, ns = len(diffs), len(sums)
    if ns < 2:
        return 0.0, nd, ns
    sc = math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100
    return sc, nd, ns


def _build(offsets, gaps, sizes):
    """offsets[i]: start of cluster i, gaps[i]: step, sizes[i]: count."""
    A = []
    for off, g, s in zip(offsets, gaps, sizes):
        for k in range(s):
            A.append(off + g * k)
    return A


def _score(a):
    sc, _, _ = _stats(a)
    return sc


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # --- seed families: a handful of AP clusters, spread far apart so that
    # differences are numerous, with steps chosen to force sum collisions.
    families = []
    for ncl in (2, 3, 4, 5, 6):
        for per in (4, 6, 8, 10, 14, 20, 30, 45):
            sizes = [per] * ncl
            # make cross-cluster sums collide: pick offsets in a small grid
            base = [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377]
            offsets = [base[i % len(base)] * 1000 + (i // len(base)) * 10 for i in range(ncl)]
            gaps = [1] * ncl
            families.append((offsets, gaps, sizes))

    random.seed(12345)

    for offsets, gaps, sizes in families:
        offsets = offsets[:]
        gaps = gaps[:]
        sizes = sizes[:]
        cur = _build(offsets, gaps, sizes)
        cur_score = _score(cur)
        if cur_score > best_score:
            best_score = cur_score
            best = cur[:]
        # local search on offsets / gaps / sizes
        local_deadline = min(deadline, time.time() + 4)
        while time.time() < local_deadline:
            o2, g2, s2 = offsets[:], gaps[:], sizes[:]
            r = random.random()
            if r < 0.5:
                i = random.randrange(len(o2))
                o2[i] += random.randint(-60, 60)
            elif r < 0.75:
                i = random.randrange(len(g2))
                g2[i] = max(1, g2[i] + random.choice([-2, -1, 1, 2]))
            else:
                i = random.randrange(len(s2))
                s2[i] = max(1, s2[i] + random.choice([-1, 1]))
            cand = _build(o2, g2, s2)
            if len(cand) > 4000:
                continue
            sc = _score(cand)
            if sc > cur_score:
                offsets, gaps, sizes = o2, g2, s2
                cur, cur_score = cand, sc
                if sc > best_score:
                    best_score = sc
                    best = cand[:]
        if time.time() > deadline:
            break

    if best is None:
        best = [0, 1, 2, 3, 5]

    # final cleanup: remove duplicates, keep within bounds
    A = sorted(set(best))
    A = [x for x in A if abs(x) <= 10**15][:4000]
    return A
# EVOLVE-BLOCK-END
