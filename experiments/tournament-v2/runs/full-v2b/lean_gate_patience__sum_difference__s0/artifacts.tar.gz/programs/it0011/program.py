# EVOLVE-BLOCK-START
"""Digit-set power construction: A = {sum d_i B^i} for d_i in D, large base B.

Then |A-A| = |D-D|^n and |A+A| = |D+D|^n (for B large enough), so the ratio
is n*log|D-D| / (n*log|D+D|) = log|D-D|/log|D+D|, independent of n, while the
bonus grows with n.  We brute-force search good D and pick the best n.
"""
import math
import itertools


def _counts(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return len(diffs), len(sums)


def _score_counts(n, nd, ns):
    if ns < 2 or n < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100


def _build(D, B, n):
    A = [0]
    for i in range(n):
        bi = B ** i
        A = [a + d * bi for a in A for d in D]
    return A


def solve():
    B = 10 ** 6  # large base: no carry overlap between digit positions
    best_A = None
    best_sc = -1.0

    # score a candidate digit set D exactly by its own set sizes
    def digit_quality(D):
        nd, ns = _counts(D)
        if ns < 2 or nd < 2:
            return -1.0, nd, ns
        return math.log(nd) / math.log(ns), nd, ns

    # brute force D over small integer ranges, sizes 2..6
    candidates = []
    rng = range(0, 12)
    for k in range(2, 7):
        for D in itertools.combinations(rng, k):
            q, nd, ns = digit_quality(list(D))
            if q > 0:
                candidates.append((q, nd, ns, list(D)))

    candidates.sort(reverse=True)
    candidates = candidates[:400]

    for q, nd, ns, D in candidates:
        # max n such that |D|^n <= 4000
        k = len(D)
        max_n = int(math.log(4000) / math.log(k)) if k > 1 else 1
        for n in range(max(1, max_n - 2), max_n + 1):
            size = k ** n
            if size > 4000 or size < 2:
                continue
            # predicted counts from digit convolution
            pred_nd = nd ** n
            pred_ns = ns ** n
            sc = _score_counts(size, pred_nd, pred_ns)
            if sc > best_sc:
                best_sc = sc
                best_A = _build(D, B, n)

    if best_A is None:
        best_A = [0, 1, 3]

    # final safety: distinct, within bounds, size limit
    A = sorted(set(best_A))
    A = [x for x in A if abs(x) <= 10 ** 15][:4000]
    if len(A) < 2:
        A = [0, 1, 3]
    return A
# EVOLVE-BLOCK-END
