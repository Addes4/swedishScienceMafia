# EVOLVE-BLOCK-START
"""Digit-set power construction: A = {sum d_i B^i}, with D maximizing
log|D-D|/log|D+D|. Then |A+A|=|D+D|^n and |A-A|=|D-D|^n.
Search a broad family of digit sets to maximize the per-level ratio."""
import math
import time
import itertools
import numpy as np


def _counts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0, 0
    diffs = np.unique(a[:, None] - a[None, :]).size
    sums = np.unique(a[:, None] + a[None, :]).size
    return diffs, sums


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return -1.0
    diffs, sums = _counts(a)
    if sums < 2 or diffs < 2:
        return -1.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _digit_stats(D):
    D = list(D)
    dd = set()
    ss = set()
    for x in D:
        for y in D:
            dd.add(x - y)
            ss.add(x + y)
    return len(dd), len(ss)


def _search_digit_sets(deadline):
    """Search small digit sets D and rank by log|D-D|/log|D+D|.
    Uses a beam-like expansion over small ranges."""
    cands = []
    seen = set()

    def consider(D):
        key = tuple(sorted(D))
        if key in seen:
            return
        seen.add(key)
        ndd, nss = _digit_stats(D)
        if nss < 2 or ndd < 2:
            return
        ratio = math.log(ndd) / math.log(nss)
        cands.append((ratio, list(key), ndd, nss))

    # Exhaustive small sizes
    universe = list(range(9))
    for sz in range(2, 6):
        if time.time() > deadline:
            break
        for comb in itertools.combinations(universe, sz):
            consider(comb)

    # Beam expansion to larger sizes
    cands.sort(reverse=True, key=lambda t: t[0])
    beam = [t[1] for t in cands[:200]]
    for sz in range(6, 9):
        if time.time() > deadline:
            break
        newbeam = []
        for D in beam:
            mx = max(D)
            for v in range(0, mx + 4):
                if v in D:
                    continue
                consider(D + [v])
        cands.sort(reverse=True, key=lambda t: t[0])
        beam = [t[1] for t in cands[:200]]
        if not beam:
            break
    cands.sort(reverse=True, key=lambda t: t[0])
    return cands


def _build_power(D, n, B):
    A = [0]
    pw = 1
    for _ in range(n):
        newA = []
        for a in A:
            for d in D:
                newA.append(a + d * pw)
        A = newA
        pw *= B
    return np.array(sorted(set(A)), dtype=np.int64)


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    candidates = _search_digit_sets(deadline)

    # Try the top digit sets, building power constructions.
    for (ratio, D, ndd, nss) in candidates[:400]:
        if time.time() > deadline:
            break
        m = len(D)
        if m < 2:
            continue
        maxn = 1
        while m ** (maxn + 1) <= 4000:
            maxn += 1
        if maxn < 1:
            continue
        span = max(D) - min(D)
        B = max(2 * span + 1, 2)
        for n in range(1, maxn + 1):
            if time.time() > deadline:
                break
            A = _build_power(D, n, B)
            if np.max(np.abs(A)) > 10**15:
                break
            sc = _score(A)
            if sc > best_score:
                best_score = sc
                best = A.tolist()

    # Boundary refinement on the best construction.
    if best is not None:
        a = sorted(set(int(x) for x in best))
        improved = True
        rounds = 0
        while improved and rounds < 30 and time.time() < deadline:
            improved = False
            rounds += 1
            base_arr = np.array(a, dtype=np.int64)
            cand_adds = []
            lo, hi = a[0], a[-1]
            cand_adds.append(hi + 1)
            cand_adds.append(lo - 1)
            diffs = np.diff(base_arr)
            if diffs.size:
                gi = int(np.argmax(diffs))
                cand_adds.append(int(a[gi]) + int(diffs[gi]) // 2)
            for c in cand_adds:
                if len(a) >= 4000:
                    break
                trial = np.array(sorted(set(a + [c])), dtype=np.int64)
                sc = _score(trial)
                if sc > best_score:
                    best_score = sc
                    a = trial.tolist()
                    improved = True
                    break
            if improved:
                continue
            for idx in (0, len(a) - 1):
                if len(a) <= 2:
                    break
                trial_list = a[:idx] + a[idx + 1:]
                trial = np.array(trial_list, dtype=np.int64)
                sc = _score(trial)
                if sc > best_score:
                    best_score = sc
                    a = trial_list
                    improved = True
                    break
        best = a

    if best is None:
        best = [0, 1]
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
