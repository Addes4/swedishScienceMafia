# EVOLVE-BLOCK-START
"""A = C + T : compact interval cluster C plus sparse translate set T.

|C-C| ~ 2|C|-1 (large, ~2|c| per element), |C+C| ~ 2|C|-1 too, but the
*translate* set T is chosen so that |T+T| is small (carries / additive
collisions), so overall |A+A| ~ |T+T| * stuff stays small while |A-A| grows
like |T-T| * |C-C|.  We search (cluster size, base, translate pattern) with a
fast exact set-based scorer inside a tight time budget.
"""
import time
import math
import random


def _sets(a):
    a = list(dict.fromkeys(a))
    n = len(a)
    if n < 2:
        return 1, 1
    s = set(a)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    return len(diffs), len(sums)


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    d, s = _sets(a)
    if s < 2:
        s = 2
    return math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0


def _carry_translates(base, depth):
    """T = { sum d_i * base^i : d_i in {0,1} }. Produces carry-rich sums."""
    T = {0}
    p = 1
    for _ in range(depth):
        T = {t + d * p for t in T for d in (0, 1)}
        p *= base
    return sorted(T)


def _cluster(size, gap=1):
    return [i * gap for i in range(size)]


def _assemble(C, T):
    return [c + t for t in T for c in C]


def solve():
    deadline = time.time() + 90.0
    rng = random.Random(20240517)

    best = None
    best_score = -1.0

    # ---- structured scan over carry-translate constructions -------------
    for base in (2, 3, 4, 5, 6, 8, 10):
        for depth in (2, 3, 4, 5, 6):
            T = _carry_translates(base, depth)
            if len(T) > 60:
                continue
            for csize in (2, 3, 4, 5, 6, 8, 10, 12):
                if len(T) * csize > 900:
                    continue
                for gap in (1, 2, 3):
                    A = _assemble(_cluster(csize, gap), T)
                    s = _score(A)
                    if s > best_score:
                        best_score, best = s, A[:]
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    if best is None:
        best = _assemble(_cluster(4), [0, 1, 2, 4])
        best_score = _score(best)

    # ---- local polish: perturb translate offsets ------------------------
    T0 = sorted(set(best))
    Cbest = _cluster(4)
    cur = best[:]
    cur_score = best_score
    improved = True
    while improved and time.time() < deadline:
        improved = False
        # mutate a few translate offsets by +-1, +-base to reduce sum-set
        for _ in range(6):
            cand = cur[:]
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([1, -1, 2, -2, 3, -3])
            cand = sorted(set(cand))
            s = _score(cand)
            if s > cur_score:
                cur_score = s
                cur = cand
                improved = True
                break
        if best is None:
            break

    return sorted(set(int(x) for x in cur))
# EVOLVE-BLOCK-END
