# EVOLVE-BLOCK-START
"""Search for the best small digit set D (exhaustive + hill-climb), then realize
it at large size via the digit expansion A = { sum d_i B^i : d_i in D }.

Rationale: for carry-free base B, |A-A| = |D-D|^m and |A+A| = |D+D|^m, so the
log-ratio of A equals that of D exactly.  Hence we only need to find the small
set D with the best log|D-D|/log|D+D|, and then use the largest feasible m
(|D|^m <= 4000) and the best base B (small B may induce carries that collapse
sums further) to gain the (1 - 1/|A|)/100 size bonus.
"""
import math
import time
import itertools
import random

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None


def _counts_small(A):
    """Exact |A-A| and |A+A| for small lists."""
    L = list(A)
    n = len(L)
    s = set()
    for i in range(n):
        xi = L[i]
        s.add(xi + xi)
        for j in range(i + 1, n):
            s.add(xi + L[j])
    d = set()
    for i in range(n):
        xi = L[i]
        for j in range(n):
            d.add(xi - L[j])
    return len(d), len(s)


def _ratio(d, s):
    if s <= 1:
        return 0.0
    return math.log(d) / math.log(s)


def _counts_np(A):
    if np is not None:
        arr = np.asarray(A, dtype=np.int64)
        sums = np.unique(np.add.outer(arr, arr))
        difs = np.unique(np.subtract.outer(arr, arr))
        return len(difs), len(sums)
    return _counts_small(A)


def solve():
    deadline = time.time() + 110.0

    # ---- 1. Search small digit sets D (min element fixed to 0) -----------
    R = 16
    best_D = (0, 1, 3)      # guaranteed non-trivial seed with ratio > 1
    best_r = _ratio(*_counts_small(best_D))
    for k in (2, 3, 4, 5, 6):
        for comb in itertools.combinations(range(1, R), k - 1):
            D = (0,) + comb
            r = _ratio(*_counts_small(D))
            if r > best_r:
                best_r = r
                best_D = D

    # ---- 2. Randomized hill-climb over D (variable size) -----------------
    random.seed(20240517)
    cur = list(best_D)
    cur_r = best_r
    while time.time() < deadline - 45.0:
        new = cur[:]
        i = random.randrange(len(new))
        if random.random() < 0.25 and len(new) > 2:
            del new[i]
        elif random.random() < 0.25 and len(new) < 9:
            new.append(random.randrange(0, R))
        else:
            new[i] = random.randrange(0, R)
        new = sorted(set(new))
        if len(new) < 2:
            continue
        mn = new[0]
        new = [x - mn for x in new]
        r = _ratio(*_counts_small(new))
        if r > cur_r + 1e-12:
            cur = new
            cur_r = r
    if cur_r > best_r:
        best_D = cur
        best_r = cur_r

    # ---- 3. Realize the best D at maximum feasible size ------------------
    D = sorted(best_D)
    k = len(D)
    mx = D[-1]

    # feasible level counts: k^m <= 4000
    ms = []
    m = 1
    while k ** m <= 4000:
        ms.append(m)
        m += 1
        if m > 12:
            break
    if not ms:
        ms = [1]

    bestA = None
    best_sc = -1.0
    for m in ms:
        # keep values within 1e15
        powers = [1] * m
        ok = True
        for i in range(1, m):
            powers[i] = powers[i - 1] * (mx + 1)
            if powers[i] > 10 ** 15:
                ok = False
                break
        if not ok:
            continue
        lo_B = mx          # allow carries
        hi_B = 2 * mx + 4
        for B in range(max(2, lo_B), hi_B + 1):
            if time.time() > deadline - 8.0:
                break
            pw = [1] * m
            for i in range(1, m):
                pw[i] = pw[i - 1] * B
            if pw[m - 1] * mx > 10 ** 15:
                break
            A = set()
            for tup in itertools.product(D, repeat=m):
                v = 0
                for i in range(m):
                    di = tup[i]
                    if di:
                        v += di * pw[i]
                A.add(v)
            A = list(A)
            n = len(A)
            if n < 2:
                continue
            d, s = _counts_np(A)
            if s <= 1:
                continue
            sc = math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0
            if sc > best_sc:
                best_sc = sc
                bestA = A
        # carry-free option for this m (large base) as a fallback
        if time.time() < deadline - 8.0:
            B = 2 * mx + 5
            pw = [1] * m
            valid = True
            for i in range(1, m):
                pw[i] = pw[i - 1] * B
                if pw[i] > 10 ** 15:
                    valid = False
                    break
            if valid and pw[m - 1] * mx <= 10 ** 15:
                A = set()
                for tup in itertools.product(D, repeat=m):
                    v = 0
                    for i in range(m):
                        di = tup[i]
                        if di:
                            v += di * pw[i]
                    A.add(v)
                A = list(A)
                n = len(A)
                d, s = _counts_np(A)
                if s > 1:
                    sc = math.log(d) / math.log(s) + (1.0 - 1.0 / n) / 100.0
                    if sc > best_sc:
                        best_sc = sc
                        bestA = A

    if bestA is None:
        bestA = [0, 1, 3]
    return sorted(set(int(x) for x in bestA))
# EVOLVE-BLOCK-END

