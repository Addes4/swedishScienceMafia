# EVOLVE-BLOCK-START
"""Structured construction: digit-set A in a large base, few sums / many differences."""
import math
import random
import time


def _counts(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        xi = a[i]
        for j in range(n):
            diffs.add(xi - a[j])
            sums.add(xi + a[j])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    nd, ns = _counts(a)
    if ns < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100


def _build_digits(D, B, k):
    """All numbers sum d_i B^i for digits d_i in D, i<k."""
    A = [0]
    p = 1
    for _ in range(k):
        nxt = []
        for val in A:
            for d in D:
                nxt.append(val + d * p)
        A = nxt
        p *= B
    return A


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    # Candidate digit sets with small |D+D| relative to |D-D|.
    digit_sets = [
        [0, 1, 3],
        [0, 1, 4],
        [0, 1, 3, 9],
        [0, 1, 2, 4],
        [0, 1, 3, 4],
        [0, 1, 3, 5],
        [0, 1, 4, 5],
        [0, 1, 2, 5],
        [0, 1, 3, 9, 10],
        [0, 1, 3, 4, 9],
        [0, 1, 4, 9, 10],
        [0, 1, 3, 9, 27],
    ]

    for D in digit_sets:
        maxD = max(D)
        # base must be large enough that digit sums don't carry-collide
        B = maxD * 2 + 3
        # choose k so that |D|^k ~ up to ~3000
        k = 0
        size = 1
        while size * len(D) <= 3500:
            size *= len(D)
            k += 1
        if k < 1:
            continue
        A = _build_digits(D, B, k)
        # ensure within bounds
        if A[-1] > 10**15:
            continue
        sc = _score(A)
        if sc > best_score:
            best_score = sc
            best = A[:]

    # Local search: perturb base B and swap one digit value, using fast delta-free
    # recompute but with pruning by time budget per candidate.
    random.seed(999)
    # Start from best digit construction; try small variations of D and B.
    trials = 0
    while time.time() < deadline and best is not None:
        trials += 1
        D = random.choice(digit_sets)
        B = random.randint(max(D) * 2 + 1 if max(D) > 0 else 3, max(D) * 4 + 6)
        if B < 3:
            B = 3
        size = 1
        k = 0
        while size * len(D) <= 3500:
            size *= len(D)
            k += 1
        if k < 1:
            continue
        if (max(D) * (B ** (k - 1) if k >= 1 else 0)) > 10**15:
            continue
        A = _build_digits(D, B, k)
        if not A or A[-1] > 10**15:
            continue
        sc = _score(A)
        if sc > best_score:
            best_score = sc
            best = A[:]
        # brief random digit injection: replace some digits values
        if trials % 10 == 0 and time.time() < deadline:
            D2 = D[:]
            i = random.randrange(len(D2))
            D2[i] = random.randint(0, max(D) + 3)
            D2 = sorted(set(D2))
            if len(D2) >= 2:
                B2 = max(D2) * 2 + 3
                size = 1
                k2 = 0
                while size * len(D2) <= 3500:
                    size *= len(D2)
                    k2 += 1
                if k2 >= 1:
                    A2 = _build_digits(D2, B2, k2)
                    if A2 and A2[-1] <= 10**15:
                        sc2 = _score(A2)
                        if sc2 > best_score:
                            best_score = sc2
                            best = A2[:]

    if best is None:
        best = [0, 1, 3]

    A = sorted(set(best))
    A = [x for x in A if abs(x) <= 10**15][:4000]
    return A
# EVOLVE-BLOCK-END
