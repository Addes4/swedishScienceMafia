# EVOLVE-BLOCK-START
"""Mixed-radix digit construction with annealing refinement.

Build A = { sum_i b^i * d_i : d_i in D_i } where each D_i is a small digit set
and b is a base. Sums collapse because digit-sum sets are small per level and
carries merge many combinations; differences stay rich because digit-difference
sets are larger. Refine digit sets by set-based annealing.
"""
import math
import random
import time


def _diff_sum_sets(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return set(), set(), n
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    return diffs, sums, n


def _score_sets(d, s, n):
    if len(s) < 2:
        return 0.0
    return math.log(len(d)) / math.log(len(s)) + (1 - 1 / n) / 100


def _build(digits, base, cap):
    """A = all numbers sum b^i * d_i, d_i in digits[i]. Return sorted list."""
    vals = [0]
    p = 1
    for D in digits:
        newv = []
        seen = set()
        for v in vals:
            for d in D:
                x = v + p * d
                if x not in seen:
                    seen.add(x)
                    newv.append(x)
        vals = newv
        p *= base
    vals = sorted(set(vals))
    if len(vals) > cap:
        # keep a spread subset preserving structure
        step = len(vals) / cap
        vals = sorted(set(vals[int(i * step)] for i in range(cap)))
    return vals


def _score_vals(vals):
    d, s, n = _diff_sum_sets(vals)
    return _score_sets(d, s, n)


def solve():
    deadline = time.time() + 108
    rng = random.Random(20240607)

    best = None
    best_score = -1.0

    # Try a range of digit-set configurations.
    # Level 0 is unshifted digit set (differences large, sums collapse via carries).
    seed_configs = []
    for base in (3, 4, 5, 6, 7, 8, 10):
        for lvls in (2, 3, 4):
            for spread in (1, 2, 3):
                digits = []
                for i in range(lvls):
                    m = max(2, spread + 1)
                    digits.append(list(range(0, m * (i + 1), max(1, spread))))
                seed_configs.append((digits, base))

    for digits, base in seed_configs:
        try:
            vals = _build(digits, base, 4000)
        except Exception:
            continue
        if len(vals) < 6:
            continue
        sc = _score_vals(vals)
        if sc > best_score:
            best_score = sc
            best = vals

    # Anneal the digit sets of the best config.
    # Represent as (digits, base) and mutate digits.
    cur_digits = None
    cur_base = None
    cur_vals = None
    cur_score = -1.0

    # Recover best config heuristically by rebuilding around it.
    # Start from a decent config and refine.
    start = ([list(range(0, 3)), list(range(0, 4)), list(range(0, 5))], 5)
    cur_digits = [list(D) for D in start[0]]
    cur_base = start[1]
    cur_vals = _build(cur_digits, cur_base, 4000)
    cur_score = _score_vals(cur_vals) if len(cur_vals) >= 6 else -1.0

    start_time = time.time()
    it = 0
    while time.time() < deadline:
        it += 1
        T = 0.05 * max(1e-6, 1.0 - (time.time() - start_time) / 108.0)

        nd = [list(D) for D in cur_digits]
        nb = cur_base
        mv = rng.random()

        li = rng.randrange(len(nd))
        if mv < 0.35:
            # add a digit to a level
            m = (max(nd[li]) + rng.randint(1, 4)) if nd[li] else rng.randint(0, 3)
            if m not in nd[li]:
                nd[li].append(m)
                nd[li].sort()
        elif mv < 0.65 and len(nd[li]) > 2:
            # remove a digit
            nd[li].pop(rng.randrange(len(nd[li])))
        elif mv < 0.85:
            # shift a digit
            k = rng.randrange(len(nd[li]))
            nd[li][k] += rng.choice([-1, 1, -2, 2])
            nd[li] = sorted(set(x for x in nd[li] if x >= 0))
        else:
            # change base
            nb = max(2, nb + rng.choice([-1, 1]))
            if nb == 1:
                nb = 2
            nb = min(nb, 20)

        # keep level count bounded
        if mv < 0.10 and len(nd) < 6:
            nd.append(list(range(0, 3)))
        if mv > 0.95 and len(nd) > 1:
            nd.pop()

        if not nd or any(len(D) < 2 for D in nd):
            continue

        try:
            vals = _build(nd, nb, 4000)
        except Exception:
            continue
        if len(vals) < 6 or len(vals) > 4000:
            continue
        sc = _score_vals(vals)
        if sc >= cur_score or (T > 1e-12 and rng.random() < math.exp(min(50.0, (sc - cur_score) / T))):
            cur_digits = nd
            cur_base = nb
            cur_vals = vals
            cur_score = sc
            if sc > best_score:
                best_score = sc
                best = vals

    return [int(x) for x in sorted(set(best))]


# EVOLVE-BLOCK-END
