# EVOLVE-BLOCK-START
"""Construction: mixed-radix digit sets, deterministic sweep + deletion polish.

A = { sum_i d_i * B^i : d_i in D } for a small digit set D and base B.
This collapses A+A heavily (carries / overlapping digit sums) while A-A
stays large, giving a high log|A-A|/log|A+A| ratio.
We sweep a handful of (base, depth, digit-set) candidates deterministically
and keep the best, then run an incremental deletion polish.
"""
import math
import time
import random
import numpy as np


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n == 0:
        return 0, 0
    diffs = (a[:, None] - a[None, :]).ravel()
    sums = (a[:, None] + a[None, :]).ravel()
    nd = np.unique(diffs).size
    ns = np.unique(sums).size
    return nd, ns


def _score_from_counts(nd, ns, n):
    if n < 2 or ns <= 1:
        return -1e9
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _build(digits, base, depth):
    """A = all sums of digits[i] * base^i for i in range(depth)."""
    vals = [0]
    for i in range(depth):
        p = base ** i
        newvals = []
        for v in vals:
            for d in digits[i]:
                newvals.append(v + d * p)
        vals = newvals
    return sorted(set(vals))


def _sweep_candidates():
    """Yield deterministic (digits, base, depth) candidates."""
    cands = []
    # Symmetric centered digit sets over various bases.
    for base in range(2, 17):
        for half in (1, 2, 3, 4, 5, 6):
            D = list(range(-half, half + 1))
            for depth in (2, 3, 4, 5, 6):
                cands.append((D, base, depth))
    # Asymmetric / positive digit sets.
    for base in range(3, 13):
        for ma in (1, 2, 3, 4, 5, 6, 7):
            for mn in (0, -1, -2, -3):
                D = list(range(mn, ma + 1))
                for depth in (2, 3, 4, 5):
                    cands.append((D, base, depth))
    return cands


def solve():
    rng = random.Random(20240607)
    deadline = time.time() + 110.0

    best_A = None
    best_score = -1e9

    # Deterministic sweep over structured digit constructions.
    for D, base, depth in _sweep_candidates():
        if time.time() > deadline - 40:
            break
        # Build A with the same digit set at every position.
        try:
            digits = [D] * depth
            A = _build(digits, base, depth)
        except Exception:
            continue
        if len(A) < 2 or len(A) > 4000:
            continue
        nd, ns = _counts(A)
        s = _score_from_counts(nd, ns, len(A))
        if s > best_score:
            best_score = s
            best_A = A

    if best_A is None:
        best_A = [-1, 0, 1]
        best_score = _score_from_counts(*_counts(best_A), len(best_A))

    res = sorted(set(best_A))

    # Greedy deletion polish: remove elements that don't hurt the ratio.
    cur_nd, cur_ns = _counts(res)
    cur_s = _score_from_counts(cur_nd, cur_ns, len(res))
    improved = True
    while improved and time.time() < deadline:
        improved = False
        order = list(range(len(res)))
        rng.shuffle(order)
        for i in order:
            cand = res[:i] + res[i + 1:]
            if len(cand) < 2:
                continue
            nd2, ns2 = _counts(cand)
            s = _score_from_counts(nd2, ns2, len(cand))
            if s >= cur_s:
                res = cand
                cur_s = s
                improved = True
                break

    # Optional: try slightly perturbed digit constructions around the best
    # base/depth if time remains (random restart of digit set sizes).
    while time.time() < deadline - 5:
        base = rng.randrange(2, 20)
        depth = rng.randrange(2, 6)
        half = rng.randrange(1, 8)
        D = list(range(-half, half + 1))
        digits = [D] * depth
        try:
            A = _build(digits, base, depth)
        except Exception:
            continue
        if not (2 <= len(A) <= 4000):
            continue
        nd, ns = _counts(A)
        s = _score_from_counts(nd, ns, len(A))
        if s > cur_s:
            res2 = sorted(set(A))
            # quick polish
            nd2, ns2 = _counts(res2)
            s2 = _score_from_counts(nd2, ns2, len(res2))
            if s2 > cur_s:
                res = res2
                cur_s = s2

    return sorted(set(res))
# EVOLVE-BLOCK-END
