# EVOLVE-BLOCK-START
"""Digit-set construction with carry-free base expansion.

If A = { sum_i d_i B^i : d_i in D } for a base B larger than the spread of
D - D, then differences and sums decompose without carries:
    |A - A| = |D - D|^m , |A + A| = |D + D|^m .
So maximizing log|D-D|/log|D+D| for a small digit set, then expanding to m
positions (|A| = |D|^m <= 4000), gives a good ratio and the best size bonus.
"""
import time
import numpy as np


def _ndiff_nsum(vals):
    """Exact |X-X| and |X+X| for a set of int64 values."""
    v = np.unique(np.asarray(vals, dtype=np.int64))
    s = (v[:, None] + v[None, :]).ravel()
    nsum = int(np.unique(s).size)
    d = (v[:, None] - v[None, :]).ravel()
    ndif = int(np.unique(d).size)
    return ndif, nsum


def _ratio_score(vals):
    nd, ns = _ndiff_nsum(vals)
    if ns <= 1 or nd <= 1:
        return -1.0
    return np.log(nd) / np.log(ns)


def _build_A(D, B, m):
    """Return A = digit set expanded to m positions, as unique int64 array."""
    D = np.unique(np.asarray(D, dtype=np.int64))
    cur = np.zeros(1, dtype=np.int64)
    for i in range(m):
        cur = (cur[:, None] + D[None, :] * np.int64(B ** i)).ravel()
    return np.unique(cur)


def _sidon_like(k, seed):
    """Build a Sidon-like set of size k with good difference/sum structure."""
    rng = np.random.default_rng(seed)
    # Greedy Sidon construction: add smallest number keeping all pairwise sums distinct
    S = [0]
    sums = {0}
    cand = 1
    while len(S) < k and cand < 100000:
        ok = True
        newsums = set()
        for x in S:
            s = x + cand
            if s in sums or s in newsums:
                ok = False
                break
            newsums.add(s)
        if ok:
            newsums.add(2 * cand)
            if 2 * cand in sums:
                ok = False
        if ok:
            S.append(cand)
            sums |= newsums
        cand += 1
    return S


def _search_D(time_deadline, rng):
    """Search for a good digit set D maximizing |D-D|/|D+D| ratio."""
    best_D = None
    best_r = -1.0

    def consider(vals):
        nonlocal best_D, best_r
        vals = sorted(set(int(x) for x in vals))
        if len(vals) < 2:
            return
        mn = min(vals)
        vals = [x - mn for x in vals]
        if vals[-1] > 200000:
            return
        r = _ratio_score(vals)
        if r > best_r:
            best_r = r
            best_D = vals

    # 1) Known-good seeds: Golomb rulers and Sidon sets give large D-D, small D+D.
    seeds = [
        [0, 1, 4, 9, 15],           # near-Golomb ruler
        [0, 1, 4, 10, 18],
        [0, 1, 4, 10, 12, 17],
        [0, 1, 4, 9, 15, 22, 32],
        [0, 1, 3, 7, 12, 20],
        [0, 1, 3, 7, 12, 20, 30],
        [0, 1, 4, 9, 15, 22, 32, 34, 40],
        [0, 1, 3, 8, 12, 18, 26, 34, 46],
        [0, 1, 5, 11, 20, 28, 40, 55, 66],
    ]
    for s in seeds:
        consider(s)

    # 2) Sidon-like constructions of various sizes.
    for k in (5, 6, 7, 8, 9, 10, 11, 12):
        for seed in range(40):
            consider(_sidon_like(k, seed + 1000 * k))
        if time.time() > time_deadline:
            break

    # 3) Random subsets in moderate ranges.
    for _ in range(3000):
        if time.time() > time_deadline:
            break
        R = int(rng.integers(10, 80))
        k = int(rng.integers(4, min(R, 14)))
        vals = sorted(rng.choice(R, size=k, replace=False).tolist())
        consider(vals)

    # 4) Hill-climb on D.
    improved = True
    while improved and time.time() < time_deadline:
        improved = False
        cur_D = best_D
        for i in range(len(cur_D)):
            for delta in (-5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 6, 8):
                trial = cur_D[:]
                trial[i] += delta
                if min(trial) < 0 or max(trial) > 200000:
                    continue
                r = _ratio_score(trial)
                if r > best_r + 1e-12:
                    best_r = r
                    best_D = sorted(set(trial))
                    improved = True
        for _ in range(60):
            if time.time() > time_deadline:
                break
            trial = list(best_D)
            op = rng.random()
            if op < 0.45:
                trial.append(int(rng.integers(0, max(20, max(trial) + 15))))
            elif op < 0.85 and len(trial) > 3:
                trial.pop(int(rng.integers(0, len(trial))))
            else:
                if len(trial) > 3:
                    i = int(rng.integers(0, len(trial)))
                    trial[i] += int(rng.integers(-6, 7))
            r = _ratio_score(trial)
            if r > best_r + 1e-12:
                best_r = r
                best_D = sorted(set(int(x) for x in trial))
                improved = True
    return best_D, best_r


def _eval_A(A, best_val, best, deadline):
    n = A.size
    if n < 2:
        return best_val, best
    nd, ns = _ndiff_nsum(A)
    if ns <= 1:
        return best_val, best
    val = np.log(nd) / np.log(ns) + (1.0 - 1.0 / n) / 100.0
    if val > best_val:
        return val, A
    return best_val, best


def solve():
    deadline = time.time() + 112.0
    rng = np.random.default_rng(20240607)

    search_deadline = time.time() + 70.0
    D, dr = _search_D(search_deadline, rng)
    if D is None:
        D = [0, 1, 4, 9]

    D = np.unique(np.asarray(D, dtype=np.int64))
    dsize = D.size
    spread = int(D.max() - D.min())

    B_min = spread + 1
    bases = set()
    for extra in range(0, 6):
        bases.add(B_min + extra)
    bases.add(2 * spread + 1)
    bases.add(2 * spread + 3)
    bases.add(int(D.max()) * 2 + 3)
    bases = sorted(b for b in bases if b > spread and b > 1)

    max_elems = 4000
    best = None
    best_val = -1.0

    for B in bases:
        if time.time() > deadline:
            break
        # max m with dsize^m <= max_elems and values <= 1e15
        m = 1
        while dsize ** (m + 1) <= max_elems:
            m += 1
        while m > 1 and (B ** (m - 1)) * (int(D.max()) + spread) > 10**15:
            m -= 1
        for mm in range(1, m + 1):
            if time.time() > deadline:
                break
            A = _build_A(D, B, mm)
            best_val, best = _eval_A(A, best_val, best, deadline)

    if best is None:
        best = np.array([0, 1, 4, 9, 24, 36], dtype=np.int64)

    best = np.unique(best)
    return [int(x) for x in best]
# EVOLVE-BLOCK-END
