# EVOLVE-BLOCK-START
"""Digit-set construction.

A = { sum_i d_i * B^i : d_i in D }  (m positions).
With B large enough that digit arithmetic never carries, differences of A
correspond to digit-wise differences in D and sums to digit-wise sums in D, so
    |A-A| = |D-D|^m   and   |A+A| = |D+D|^m
giving ratio  log|D-D| / log|D+D|  independent of m. We therefore just need a
good small digit set D, then expand to as many positions as fit.
"""
import math
import time
import random
import numpy as np

TIME_LIMIT = 105.0


def _counts(d):
    arr = np.asarray(sorted(set(int(x) for x in d)), dtype=np.int64)
    if arr.size == 0:
        return 0, 0
    diffs = (arr[:, None] - arr[None, :]).ravel()
    sums = (arr[:, None] + arr[None, :]).ravel()
    return int(np.unique(diffs).size), int(np.unique(sums).size)


def _ratio(d):
    nd, ns = _counts(d)
    if ns <= 1 or nd <= 1:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns), nd, ns


def _expand(D, B):
    n = len(D)
    # max m with n^m <= 4000
    m = 1
    while n ** (m + 1) <= 4000:
        m += 1
    # shrink m if values exceed 1e15
    dmax = max(abs(x) for x in D)
    while m > 1 and (dmax * (B ** m) // max(1, B - 1)) > 10**15:
        m -= 1
    vals = [0]
    for _ in range(m):
        newvals = set()
        for v in vals:
            for d in D:
                newvals.add(v * B + d)
        vals = newvals
    return vals, m


def solve():
    start = time.time()
    random.seed(12345)
    np.random.seed(12345)

    best_D = None
    best_r = -1.0

    def consider(D):
        nonlocal best_D, best_r
        D = sorted(set(int(x) for x in D))
        if len(D) < 2:
            return
        lo = min(D)
        D = [x - lo for x in D]
        r, _, _ = _ratio(D)
        if r > best_r:
            best_r, best_D = r, D[:]

    # ---- deterministic candidate digit sets ----
    candidates = []
    for k in range(2, 13):
        candidates.append(list(range(k)))
    for k in range(2, 10):
        for step in (2, 3):
            candidates.append([i * step for i in range(k)])
    for k in range(3, 11):
        candidates.append([i * i for i in range(k)])
    for k in range(3, 11):
        candidates.append([(1 << i) - 1 for i in range(k)])
    for a in range(1, 9):
        for b in range(1, 9):
            candidates.append(list(range(a)) + [a + b + i for i in range(b)])
    # perfect difference sets (Singer-like / greedy)
    for k in range(3, 13):
        candidates.append([0] + [1 + i * (i + 1) // 2 for i in range(k - 1)])

    for D in candidates:
        consider(D)

    # ---- exhaustive small sets ----
    def exhaustive(maxsize, rng):
        # brute force subsets of {0..rng-1} containing 0, up to maxsize
        from itertools import combinations
        elems = list(range(1, rng))
        for size in range(1, maxsize + 1):
            if time.time() - start > TIME_LIMIT * 0.30:
                return
            for combo in combinations(elems, size):
                consider([0] + list(combo))

    exhaustive(4, 18)

    # ---- simulated annealing / hill climbing ----
    def climb(D, iters):
        D = sorted(set(int(x) for x in D))
        if len(D) < 2:
            return D
        cur, _, _ = _ratio(D)
        best_local, best_local_r = D[:], cur
        for it in range(iters):
            if time.time() - start > TIME_LIMIT * 0.85:
                break
            cand = D[:]
            move = random.randrange(5)
            if move == 0 and cand:                      # shift a point
                i = random.randrange(len(cand))
                cand[i] += random.choice([-3, -2, -1, 1, 2, 3])
            elif move == 1:                              # add a point
                cand.append(random.randrange(0, max(cand) + 6 if cand else 6))
            elif move == 2 and len(cand) > 2:            # remove a point
                cand.pop(random.randrange(len(cand)))
            elif move == 3:                              # extend endpoint
                if cand:
                    cand.append(cand[-1] + random.choice([1, 2, 3, 4]))
            else:                                        # duplicate a gap
                if len(cand) >= 2:
                    i = random.randrange(len(cand) - 1)
                    cand.append((cand[i] + cand[i + 1]) // 2)
            cand = sorted(set(int(x) for x in cand))
            if len(cand) < 2 or len(cand) > 40:
                continue
            lo = min(cand)
            cand = [x - lo for x in cand]
            r, _, _ = _ratio(cand)
            if r > cur or random.random() < math.exp((r - cur) * 50) * 0.05:
                cur, D = r, cand
            if cur > best_local_r:
                best_local, best_local_r = D[:], cur
        return best_local

    seeds = [d for d in candidates if len(d) <= 30]
    seeds += [[0, 1, 3, 7, 12, 20],
              [0, 2, 5, 9, 14, 20, 27],
              [0, 1, 4, 9, 16, 25]]
    for s in seeds:
        if time.time() - start > TIME_LIMIT * 0.92:
            break
        D = climb(s, iters=800)
        consider(D)

    best_D = sorted(set(int(x) for x in (best_D or [0, 1])))
    if len(best_D) < 2:
        best_D = [0, 1]

    dmax = max(best_D)
    B = 2 * dmax + 1
    if B < 2:
        B = 2
    vals, m = _expand(best_D, B)

    A = sorted(int(x) for x in vals)
    lim = 10**15
    A = [x for x in A if abs(x) <= lim]
    if len(A) > 4000:
        A = A[:4000]
    if not A:
        A = [0, 1]
    return A
# EVOLVE-BLOCK-END
