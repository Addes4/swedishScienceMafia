# EVOLVE-BLOCK-START
"""Carry-free digit-set construction.

Choose a small digit set D (size k) maximizing log|D-D|/log|D+D|.
Expand D into base B = 2*max(D)+1 with m digits (k^m <= 4000) so that
no carries occur: |A-A| = |D-D|^m and |A+A| = |D+D|^m.
Hence score = log|D-D|/log|D+D| + size bonus.  We sweep k broadly
(including large k with m=2, which allows n = k^2 up to ~3969 and a
bigger size bonus) and evaluate the *true* full-set score exactly.
"""
import math
import time
import numpy as np


def _exact_counts(a):
    a = np.asarray(a, dtype=np.int64)
    if a.size < 2:
        return 0, 0
    d = (a[:, None] - a[None, :]).ravel()
    nd = int(np.bincount(d - d.min()).size)
    s = (a[:, None] + a[None, :]).ravel()
    ns = int(np.bincount(s - s.min()).size)
    return nd, ns


def _score_from_size(a):
    n = a.size
    if n < 2:
        return 0.0
    nd, ns = _exact_counts(a)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100.0


def _small_ratio(D):
    D = np.array(sorted(set(int(x) for x in D)), dtype=np.int64)
    if D.size < 2:
        return 0.0
    dif = (D[:, None] - D[None, :]).ravel()
    nd = int(np.bincount(dif - dif.min()).size)
    s = (D[:, None] + D[None, :]).ravel()
    ns = int(np.bincount(s - s.min()).size)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns)


def _greedy_golomb(k):
    D = [0]
    diffs = set()
    v = 1
    while len(D) < k:
        newd = set()
        ok = True
        for d in D:
            ad = abs(v - d)
            if ad in diffs or ad in newd:
                ok = False
                break
            newd.add(ad)
        if ok:
            diffs |= newd
            D.append(v)
        v += 1
    return D


def _find_best_D(k, rng, deadline):
    best = None
    bestr = -1.0

    seeds = []
    try:
        seeds.append(_greedy_golomb(k))
    except Exception:
        pass
    seeds.append([i * i for i in range(k)])
    seeds.append([2 * i for i in range(k)])
    seeds.append(list(range(k)))

    attempts = 0
    max_attempts = 200 if k <= 12 else 60
    while time.time() < deadline and attempts < max_attempts:
        attempts += 1
        if seeds:
            D = sorted(set(int(x) for x in seeds.pop(0)))
            if len(D) < k:
                D = sorted(rng.choice(np.arange(0, 8 * k * k + 20), size=k, replace=False).tolist())
        else:
            D = sorted(rng.choice(np.arange(0, 8 * k * k + 20), size=k, replace=False).tolist())
        r = _small_ratio(D)

        improved = True
        while improved and time.time() < deadline:
            improved = False
            for i in range(len(D)):
                for delta in (-3, -2, -1, 1, 2, 3):
                    v = D[i] + delta
                    if v < 0 or v in D:
                        continue
                    cand = D[:]
                    cand[i] = v
                    cand = sorted(set(cand))
                    if len(cand) != k:
                        continue
                    rr = _small_ratio(cand)
                    if rr > r + 1e-13:
                        D = cand
                        r = rr
                        improved = True
                        break
                if improved:
                    break
        if r > bestr:
            bestr = r
            best = D
    if best is None:
        best = _greedy_golomb(k)
        bestr = _small_ratio(best)
    return best, bestr


def _max_m(k, cap=4000):
    m = 0
    p = 1
    while p * k <= cap:
        p *= k
        m += 1
    return m


def _build_digits(D, m):
    D = np.array(sorted(set(int(x) for x in D)), dtype=np.int64)
    B = int(2 * int(D.max()) + 1)
    A = np.zeros(1, dtype=np.int64)
    pw = 1
    for _ in range(m):
        A = (A[:, None] + D[None, :] * pw).ravel()
        pw *= B
    return np.unique(A)


def solve():
    deadline = time.time() + 100.0
    rng = np.random.default_rng(20240607)

    ks = list(range(3, 26)) + [32, 36, 40, 45, 50, 56, 63]
    candidates = []  # (predicted, k, D, m)

    for k in ks:
        if time.time() > deadline:
            break
        m = _max_m(k)
        if m < 1:
            continue
        n = k ** m
        # per-k time budget: smaller share for many k values
        slice_end = min(deadline, time.time() + (1.2 if k <= 12 else 0.6))
        D, r = _find_best_D(k, rng, slice_end)
        pred = r + (1 - 1.0 / n) / 100.0
        candidates.append((pred, k, D, m, n))

    if not candidates:
        return list(range(4000))

    # Sort by predicted score; evaluate true score for as many as time allows.
    candidates.sort(key=lambda t: -t[0])

    best_score = -1.0
    best_a = None

    for pred, k, D, m, n in candidates:
        if time.time() > deadline + 15:
            break
        a = _build_digits(D, m)
        s = _score_from_size(a)
        if s > best_score:
            best_score = s
            best_a = a

    if best_a is None:
        pred, k, D, m, n = candidates[0]
        best_a = _build_digits(D, m)

    return [int(x) for x in best_a]
# EVOLVE-BLOCK-END
