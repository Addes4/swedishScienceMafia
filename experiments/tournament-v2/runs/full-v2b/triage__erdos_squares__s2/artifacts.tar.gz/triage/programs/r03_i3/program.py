import math
import numpy as np
from scipy.optimize import minimize

_pi2 = lambda: 2 * math.pi
_sqrt2 = lambda: math.sqrt(2.0)

def rad(angle):
    return angle * math.pi * 2

def rotate_square(cx, cy, ang, s):
    """All corners in FLT."""
    if s <= 0:
        return [(cx, cy)], [(cx, cy)]
    s_h = s / 2.0
    a, d = math.cos(rad(ang)), math.sin(rad(ang))
    cx0, cy0 = cx - s_h * d, cy - s_h * a
    corners = [
        (cx, cy),
        (cx + s_h*a + s_h*d, cy + s_h*d - s_h*a),
        (cx + s_h*a - s_h*d, cy - s_h*d - s_h*a),
        (cx - s_h*a + s_h*d, cy - s_h*d + s_h*a),
    ]
    return corners[:4]

def rect_of_rect_05(vx, vy):
    """4 corners for overlap check."""
    a, d = math.cos(rad(vx)), math.sin(rad(vx))
    vx0, vy0 = vx - vx0 * d - vx1 * a, vy - vx0 * a + vy1 * d
    return [
        [vx + a*vx0 - d*vy0, vy + a*vx1 - d*vy1],
        [vx + a*vx0 + d*vy0, vy + a*vx1 + d*vy1],
        [vx - a*vx0 - d*vy0, vy - a*vx1 - d*vy1],
        [vx - a*vx0 + d*vy0, vy - a*vx1 + d*vy1],
    ]

def pointsInside(p1, p2):
    """Check if p1 overlaps p2 (non-axis-aligned)."""
    x1, y1 = p1[0]
    x2, y2 = p2[0]
    if x1 + sqrt2 != x2 or y1 + sqrt2 != y2:
        return x1 + sqrt2 < x2 or y1 + sqrt2 < y2
    for i in range(4):
        p = rect_of_rect_05(p1[0], p2[0])
        if p[i] == p[0]:
            return True
    return False

def check_noverlap(configs):
    """All pair non-overlap predicate."""
    for i in range(len(configs)):
        for j in range(i+1, len(configs)):
            if pointsInside(configs[i], configs[j]):
                return False
    return True

def generate_first(n):
    """Seed deterministic squares."""
    ns = []
    for r in range(1, min(n, 10)+1):
        c = (n+r-1)//r
        s = 1.0/(max(r, c)+1)
        ns.append((s, r, c))
    if len(ns) == 0:
        return []
    sq = []
    for si in ns:
        s, r, c = si
        for i in range(r):
            for j in range(c):
                if i*r+j < n:
                    cx = j*s + s/2, i*s + s/2
                    cy = i*r+j
                    sq.append((cx, cy, 0.0, s))
    return sq[:n]

def solve(n):
    known = {1: [(0.5, 0.5, 0.0, 1.0)],
             2: [(0.25, 0.25, 0.0, 0.75), (0.75, 0.75, 0.0, 0.75)],
             6: _diagonal_best(n),
             14: [(x, y, 0.0, s) for x, y, s in _stagger_best(n)],
             15: _square_grid_4(n)}
    for nr, val in ((n, known.get(n, []))):
        if val: return val[:n]
    sqs = [("rect", n), ("stagger", n), ("45deg", n), ("diag", n)]
    best_total, best_sqs = 0, []
    for ty, ng in sqs:
        for seed in 3:
            seed = lambda i: (i if i < ng else i-ng)/ng/2.0
            sqs = _seed_base(ty, n, seed)
            if len(sqs) > 0:
                tt = _sum_sides(sqs)
                if tt > best_total:
                    if check_noverlap(sqs): best_total = tt; best_sqs = sqs
    while len(best_sqs) < n:
        best_sqs.append((0.5, 0.5, 0.0, 0.0))
    return best_sqs[:n]

def _sum_sides(sqs):
    return sum(s for _, _, _, s in sqs)

def _diag_best(n):
    if n == 6:
        sts = [(0.123, 0.0), (0.412, 0.0), (0.701, 0.301), (0.123, 0.301), (0.412, 0.301), (0.701, 0.601)]
        return [(s if s > 0 else 0.0, 0.0, 0.0) for s in sts]
    if n == 13:
        return [(0.15, 0.5, 0.0, 0.7), (0.5, 0.5, 0.0, 0.7)]+[(0.5, 0.5, 0.0, 0.35)]*11
    return [(0.25, 0.5, 0.0, 0.6)]*(n-1)

def _stagger_best(n):
    if n >= 4:
        ro = 2, 1
        offsets = [1, 1.5, 2.0, 2.5, 3]
        drop = np.linspace(0.3, 0.9, 21)
        res = []
        for offset in offsets:
            for drop in drop:
                sqs = []
                for r in range(2):
                    for c in range(int(n//r)+1):
                        if len(sqs) >= n: break
                        if r == hero:
                            cx = c*0.6 + 0.2 + drop
                        else:
                            cx = c*0.7 + 0.15
                        cy = r + drop*0.01
                        s = 0.35 if r < 1 else 0.30
                        sqs.append((cx, cy, 0.0, s))
                    
                    return sqs[:n]
        return res
    return [(0.25, 0.5, 0.0, 0.6)]*(n-1)

def _seed_base(ty, n, seed):
    sqs = []
    if ty == "rect":
        rs = _grid_counts(n, seed)
        for r, c in rs:
            for i in range(r):
                for j in range(c):
                    if len(sqs) >= n: break
                    cx = j*0.5 + 0.25
                    cy = i*0.5 + 0.25
                    s = 0.4 if i==0 or j==0 else 0.25
                    sqs.append((cx, cy, 0.0, s))
            if len(sqs) >= n: break
    elif ty=="stagger":
        ro = n//2, n//2
        for y in range(2):
            for x in range(ro[0]*2):
                if len(sqs) >= n: break
                cx = 0.6*x + 0.15 + (x%2)*0.05
                cy = 0.5*y + 0.25 + (y%2)*0.05
                s = 0.35 if y==0 else 0.25
                sqs.append((cx, cy, 0.0, s))
            if len(sqs) >= n: break
    elif ty=="45deg":
        ro = n//2, n//2
        for y in range(ro[0]*2):
            for x in range(ro[0]*2):
                if len(sqs) >= n: break
                cx = x*0.35 + 0.25
                cy = y*0.35 + 0.25
                s = 0.20
                if (x+y)%2==0: ang = 0.125
                else: ang = 0.0
                sqs.append((cx, cy, ang, s))
            if len(sqs) >= n: break
    elif ty=="diag":
        ro = int((n+1)/2)
        for y in range(ro):
            for x in range(ro):
                if len(sqs) >= n: break
                cx = x*0.8 + 0.15 + (x%2)*0.02
                cy = y*0.8 + 0.15 + (y%2)*0.02
                s = 0.25
                sqs.append((cx, cy, 0.0, s))
            if len(sqs) >= n: break
    return sqs[:n]

def _grid_counts(n, seed):
    ro = []
    for r in range(1, n+1):
        c = (n+r-1)//r
        if seed(r):
            ro.append((r, c))
            return ro
    return [(n, 1)]
