import math
import random
import itertools

import numpy as np
from scipy.spatial import KDTree
from scipy.optimize import minimize, Bounds, NonlinearConstraint

# ------------------------------
#  Geometry helpers
# ------------------------------

def _square_corners(cx, cy, angle, s):
    """Return 4 corners of square (counter‑clockwise) as (N,2) array."""
    # angle in full turns, 0.25 = 90 degrees
    theta = 2.0 * math.pi * angle
    cos_t = math.cos(theta)
    sin_t = math.sin(theta)
    # half‑side vectors
    hs = 0.5 * s
    dx = hs * cos_t
    dy = hs * sin_t
    # perpendicular vector
    px = -hs * sin_t
    py =  hs * cos_t
    corners = np.array([
        [cx + dx + px, cy + dy + py],
        [cx - dx + px, cy - dy + py],
        [cx - dx - px, cy - dy - py],
        [cx + dx - px, cy + dy - py]
    ])
    return corners


def _separating_axis_overlap(poly1, poly2):
    """
    Test two convex polygons (list of vertices as (N,2) arrays) for overlap.
    Returns True if they overlap (or touch) in interior points.
    Uses separating axis theorem (only need edge normals).
    """
    # For each edge of each polygon, project both polygons onto the normal;
    # if there is a gap, they don't overlap.
    for poly in (poly1, poly2):
        nv = len(poly)
        for i in range(nv):
            edge = poly[(i + 1) % nv] - poly[i]
            # normal perpendicular to edge (2D)
            normal = np.array([-edge[1], edge[0]])
            # normalize
            norm_len = np.linalg.norm(normal)
            if norm_len < 1e-14:
                continue
            normal /= norm_len
            # projections
            proj1 = poly1 @ normal
            proj2 = poly2 @ normal
            min1, max1 = proj1.min(), proj1.max()
            min2, max2 = proj2.min(), proj2.max()
            if max1 < min2 + 1e-12 or max2 < min1 + 1e-12:
                return False  # separating axis found
    return True  # overlap


def _squares_overlap(sq1, sq2):
    """Return True if squares overlap (including interior)."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 == 0.0 or s2 == 0.0:
        return False
    # Quick bounding box check
    # Loose check to avoid costly polygon test when far apart
    hs1 = s1 * 0.71  # half diagonal approx
    hs2 = s2 * 0.71
    if abs(cx1 - cx2) > hs1 + hs2 or abs(cy1 - cy2) > hs1 + hs2:
        return False
    poly1 = _square_corners(cx1, cy1, a1, s1)
    poly2 = _square_corners(cx2, cy2, a2, s2)
    return _separating_axis_overlap(poly1, poly2)


def _inside_unit_square(sq):
    """Check that square is completely inside [0,1]x[0,1] (with tolerance)."""
    cx, cy, a, s = sq
    if s == 0.0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    poly = _square_corners(cx, cy, a, s)
    return np.all((poly >= -1e-9) & (poly <= 1.0 + 1e-9))


# ------------------------------
#  Candidate generation
# ------------------------------

def _generate_candidates(n, num_candidates=2000):
    """
    Generate a large set of candidate square placements (cx, cy, angle, side).
    Includes random positions, angles, sizes; also uses known good configurations
    (grid, rotated grid) as seeds.
    """
    candidates = []
    
    # Use a fast heuristic to get a baseline configuration: 
    # we place n squares with maximum equal side as seed.
    # This gives a lower bound of what side we should consider.
    _, baseline = _pack_squares_in_rectangle(1.0, 1.0, n)
    if baseline:
        max_side_est = max(sq[3] for sq in baseline) * 1.2
    else:
        max_side_est = 1.0 / math.sqrt(n)
    
    # Include the baseline configuration explicitly
    for sq in baseline:
        candidates.append(sq)
    
    # Random sampling
    random.seed(42 + n)  # deterministic per n
    for _ in range(num_candidates):
        # random position
        cx = random.random()
        cy = random.random()
        # random angle: 0, 0.125 (45°), 0.25 (90°) or continuous
        if random.random() < 0.7:
            angle = random.choice([0.0, 0.125, 0.25])
        else:
            angle = random.random() * 0.25
        # side length: from small up to max feasible given position
        # bound by distance to edges
        max_s_by_pos = min(cx, 1.0 - cx, cy, 1.0 - cy) * 2.0 / math.sqrt(2.0)
        # also bound by max_side_est
        max_s = min(max_side_est, max_s_by_pos * random.uniform(0.3, 1.0))
        if max_s < 1e-8:
            continue
        # sample size: often near max possible but sometimes small
        if random.random() < 0.5:
            s = random.uniform(0.1 * max_s, max_s)
        else:
            s = random.uniform(0.01 * max_s, max_s)
        # adjust side to ensure inside unit square
        # We'll check later, but disregard if outside.
        sq = (cx, cy, angle, s)
        if _inside_unit_square(sq):
            candidates.append(sq)
    
    # Also generate candidates on a dense grid of positions and angles
    # to cover the space better.
    grid_res = max(4, int(math.sqrt(num_candidates / 10)))
    for i in range(grid_res):
        for j in range(grid_res):
            cx = (i + 0.5) / grid_res
            cy = (j + 0.5) / grid_res
            for angle in [0.0, 0.125, 0.25]:
                max_s = min(cx, 1.0 - cx, cy, 1.0 - cy) * 2.0 / math.sqrt(2.0)
                if max_s < 1e-8:
                    continue
                sizes = [max_s * 0.7, max_s * 0.9, max_s * 0.5]
                for s in sizes:
                    if _inside_unit_square((cx, cy, angle, s)):
                        candidates.append((cx, cy, angle, s))
    
    # Remove duplicates (or nearly identical) to speed up
    # We'll keep unique by rounding
    uniq = {}
    for sq in candidates:
        key = (round(sq[0], 5), round(sq[1], 5), round(sq[2], 5), round(sq[3], 5))
        if key not in uniq:
            uniq[key] = sq
    candidates = list(uniq.values())
    return candidates


# ------------------------------
#  Overlap graph construction (partial)
# ------------------------------

def _build_conflict_graph(candidates):
    """
    Build a sparse conflict graph: returns list of lists of neighbors.
    Since candidate set might be large, we use a spatial hash or KDTree
    to only test pairs that are close.
    """
    n_cand = len(candidates)
    if n_cand == 0:
        return []
    # Extract centers and radii (approx half diagonal)
    centers = np.array([[sq[0], sq[1]] for sq in candidates])
    radii = np.array([sq[3] * 0.71 for sq in candidates])  # half-diagonal
    tree = KDTree(centers)
    # For each candidate, query neighbors within sum of radii
    conflict_graph = [[] for _ in range(n_cand)]
    for i in range(n_cand):
        sq_i = candidates[i]
        r_i = radii[i]
        # find all candidates within (r_i + max_possible_radius) to be safe
        # but we don't know max radius; use large threshold: 0.75 is half diag of 1x1 square
        neighbors = tree.query_ball_point(centers[i], r_i + 0.75)
        for j in neighbors:
            if j <= i:
                continue
            sq_j = candidates[j]
            # quick bounding box
            if abs(sq_i[0] - sq_j[0]) > r_i + radii[j] or abs(sq_i[1] - sq_j[1]) > r_i + radii[j]:
                continue
            if _squares_overlap(sq_i, sq_j):
                conflict_graph[i].append(j)
                conflict_graph[j].append(i)
    return conflict_graph


# ------------------------------
#  Independent set via greedy + local search
# ------------------------------

def _greedy_independent_set(candidates, conflict_graph, weights=None):
    """
    Greedy independent set based on weight / (degree+1).
    Returns list of indices selected.
    """
    n_cand = len(candidates)
    if weights is None:
        weights = [sq[3] for sq in candidates]  # side length as weight
    # Compute degree
    degree = np.array([len(adj) for adj in conflict_graph], dtype=float)
    # Avoid division by zero
    degree = degree + 1
    # ratio = weight / degree
    ratio = np.array(weights) / degree
    # order indices by ratio descending
    order = np.argsort(-ratio)
    selected_mask = np.zeros(n_cand, dtype=bool)
    conflict_mask = np.zeros(n_cand, dtype=bool)
    for idx in order:
        if conflict_mask[idx]:
            continue
        # select
        selected_mask[idx] = True
        conflict_mask[idx] = True
        for nb in conflict_graph[idx]:
            conflict_mask[nb] = True
    selected = list(np.where(selected_mask)[0])
    return selected


def _local_search_independent_set(candidates, conflict_graph, initial_selected, max_iters=300):
    """
    Improve independent set by trying swaps: remove one, add multiple others.
    Uses simple (1, k)-swap.
    """
    n_cand = len(candidates)
    selected = set(initial_selected)
    # precompute side lengths for fast weight sum
    sides = np.array([sq[3] for sq in candidates])
    
    def weight_sum(sel):
        return sum(sides[i] for i in sel)
    
    # Build adjacency dict (quick for neighbor checks)
    # but conflict_graph already there; we'll use it.
    changed = True
    it = 0
    while changed and it < max_iters:
        changed = False
        it += 1
        # try removing one vertex and adding some of its non-conflicting neighbors
        # to possibly increase total weight.
        selected_list = list(selected)
        random.shuffle(selected_list)
        for v in selected_list:
            # neighbors that are not selected and not conflicting with other selected except v
            # For speed, we'll consider adding at most a couple of neighbors
            best_gain = 0.0
            best_to_add = []
            # neighbors of v not in selected
            candidates_to_add = [u for u in conflict_graph[v] if u not in selected]
            # check which can be added if we remove v
            # they must not conflict with selected \ {v}
            sel_minus_v = selected - {v}
            for u in candidates_to_add:
                # check conflicts with sel_minus_v
                conflict = any(nb in sel_minus_v for nb in conflict_graph[u])
                if not conflict:
                    # adding u
                    gain = sides[u] - sides[v]
                    if gain > best_gain:
                        best_gain = gain
                        best_to_add = [u]
            # Also try adding two non-conflicting neighbors
            for i, u in enumerate(candidates_to_add):
                conflict_u = any(nb in sel_minus_v for nb in conflict_graph[u])
                if conflict_u:
                    continue
                for j in range(i+1, len(candidates_to_add)):
                    w = candidates_to_add[j]
                    conflict_w = any(nb in sel_minus_v for nb in conflict_graph[w])
                    if conflict_w:
                        continue
                    # also check u and w don't conflict
                    if w in conflict_graph[u]:
                        continue
                    gain = sides[u] + sides[w] - sides[v]
                    if gain > best_gain:
                        best_gain = gain
                        best_to_add = [u, w]
            if best_gain > 1e-12:
                # execute swap
                selected.remove(v)
                for u in best_to_add:
                    selected.add(u)
                changed = True
                break  # restart after change
    
    return list(selected)


# ------------------------------
#  Main packing via independent set
# ------------------------------

def _pack_independent_set(n, extra_candidates_factor=2):
    """
    Use maximal independent set on a candidate set to select n non-overlapping squares.
    Returns list of n squares.
    """
    # Heuristic initial solution from rectangle packing as fallback and to bound side sizes.
    _, base_squares = _best_split_into_regions(n)
    base_side_sum = sum(sq[3] for sq in base_squares)
    
    # Generate many candidates
    # Number of candidates roughly proportional to n but capped
    num_candidates = min(2000, 200 + n * 30)
    candidates = _generate_candidates(n, num_candidates=num_candidates)
    
    # Add base squares as candidates if not present (they usually are)
    for sq in base_squares:
        candidates.append(sq)
    
    # Remove duplicates again
    uniq = {}
    for sq in candidates:
        key = (round(sq[0], 6), round(sq[1], 6), round(sq[2], 6), round(sq[3], 6))
        uniq[key] = sq
    candidates = list(uniq.values())
    
    # Build conflict graph
    conflict_graph = _build_conflict_graph(candidates)
    
    # We need exactly n squares, but independent set might give us more or fewer.
    # Strategy: find a large independent set, then if more than n, we can drop lowest-weight ones,
    # and possibly enlarge remaining ones (local adjustment). If fewer than n, we need to add more
    # by splitting or generating more candidates.
    
    # First try to find an independent set of size >= n (if possible) with maximum sum of sides.
    # Use iterative greedy + local search.
    
    best_selected = []
    best_sum = 0.0
    
    # Multiple attempts with randomness in greedy order (via tie-breaking)
    for attempt in range(10):
        # Perturb weights slightly to get different greedy orders
        weights = np.array([sq[3] for sq in candidates])
        noise = np.random.rand(len(candidates)) * 1e-4
        weights_noisy = weights + noise
        sel_idx = _greedy_independent_set(candidates, conflict_graph, weights=weights_noisy)
        # Local search
        sel_idx = _local_search_independent_set(candidates, conflict_graph, sel_idx, max_iters=50)
        sel_sum = sum(candidates[i][3] for i in sel_idx)
        if sel_sum > best_sum and len(sel_idx) >= n:
            best_sum = sel_sum
            best_selected = sel_idx
            # if we have exactly n and sum very high, break early maybe
        
    # If we found a set of size >= n, take the top n by side length
    if len(best_selected) >= n:
        # sort by side descending
        sorted_sel = sorted(best_selected, key=lambda i: candidates[i][3], reverse=True)
        chosen_idx = sorted_sel[:n]
        squares = [candidates[i] for i in chosen_idx]
        # Attempt to enlarge the smallest squares while keeping non-overlap?
        # Simple: try to increase side of each square a bit via local optimization
        squares = _refine_squares(squares, n)
        return squares
    
    # If we got fewer than n, fallback to base heuristic, then try to improve by swaps.
    # Use the base solution and try to replace some squares with larger ones from candidates
    # via local search on the set of size n.
    squares = base_squares[:]
    # Try to improve using candidate swaps
    squares = _hybrid_improve(squares, candidates, conflict_graph, n)
    return squares


def _refine_squares(squares, n):
    """
    Given n non-overlapping squares, try to enlarge them individually while staying inside unit square
    and non-overlapping with others (keeping others fixed). Uses simple binary search for each.
    Returns possibly improved squares.
    """
    # Order by side length ascending so smaller squares get enlarged first (larger potential)
    order = np.argsort([sq[3] for sq in squares])
    for idx in order:
        sq = squares[idx]
        others = [squares[i] for i in range(n) if i != idx]
        # Binary search max side
        lo = sq[3]
        hi = 1.0  # upper bound, but we will cap at feasible
        # maximal possible given distance to edges
        cx, cy, angle = sq[0], sq[1], sq[2]
        # rough max by bounding box of rotated square inside unit
        # We'll just test up to 1.0 and use overlaps.
        # More efficient: bound by distance to boundaries using geometry
        def feasible(s):
            test_sq = (cx, cy, angle, s)
            if not _inside_unit_square(test_sq):
                return False
            for other in others:
                if _squares_overlap(test_sq, other):
                    return False
            return True
        if not feasible(lo):
            continue
        # increase up to some max (1.0 is safe)
        for _ in range(15):
            mid = (lo + hi) / 2.0
            if feasible(mid):
                lo = mid
            else:
                hi = mid
        # update
        squares[idx] = (cx, cy, angle, lo)
    return squares


def _hybrid_improve(squares, candidates, conflict_graph, n):
    """
    Attempt to improve an existing packing by swapping squares with candidate ones
    that have larger side and don't cause overlap.
    """
    # Build a small candidate set from the given squares plus some random replacements
    current = squares[:]
    # Try to replace each square with a larger candidate from the pool
    # For each current square, find candidates that can replace it (non-overlap with others)
    # and have larger side.
    improved = True
    while improved:
        improved = False
        for i in range(n):
            sq_i = current[i]
            others = [current[j] for j in range(n) if j != i]
            # Find best replacement among candidates (or even among current squares themselves with larger side)
            best_side = sq_i[3]
            best_cand = sq_i
            for cand in candidates:
                if cand[3] <= best_side + 1e-9:
                    continue
                if not _inside_unit_square(cand):
                    continue
                # quick check bounding box with others
                overlap = False
                for other in others:
                    if _squares_overlap(cand, other):
                        overlap = True
                        break
                if not overlap:
                    best_side = cand[3]
                    best_cand = cand
                    # if big improvement, break early
                    if best_side > sq_i[3] * 1.2:
                        break
            if best_cand is not sq_i:
                current[i] = best_cand
                improved = True
        # optionally refine again
    return current


def _pack_squares_in_rectangle(w, h, m):
    """(Copy from provided code, kept for fallback)"""
    if m == 0:
        return 0.0, []
    if m == 1:
        s = min(w, h)
        return s, [(w/2, h/2, 0.0, s)]
    best_s = 0.0
    best_config = []
    # axis-aligned grid
    for rows in range(1, m+1):
        cols = max(1, math.ceil(m/rows))
        s1 = w / cols
        s2 = h / rows
        s = min(s1, s2)
        if s > best_s:
            best_s = s
            config = []
            placed = 0
            for r in range(rows):
                if placed >= m: break
                for c in range(cols):
                    if placed >= m: break
                    cx = (c + 0.5) * s
                    cy = (r + 0.5) * s
                    config.append((cx, cy, 0.0, s))
                    placed += 1
            best_config = config
    # 45-degree rotated
    diag = math.sqrt(2.0)
    for rows in range(1, m+1):
        cols = max(1, math.ceil(m/rows))
        s_h = w / (cols * diag)
        s_v = h / (rows * diag)
        s = min(s_h, s_v)
        if cols > 1 and rows > 1:
            s_h_stag = w / ((cols - 0.5) * diag)
            s = max(s, min(s_h_stag, s_v))
        if s > best_s:
            config = []
            placed = 0
            for r in range(rows):
                if placed >= m: break
                y = (r + 0.5) * s * diag
                shift = (r % 2) * s * diag / 2
                for c in range(cols):
                    if placed >= m: break
                    x = shift + (c + 0.5) * s * diag
                    if x - s*diag/2 >= -1e-9 and x + s*diag/2 <= w+1e-9 and \
                       y - s*diag/2 >= -1e-9 and y + s*diag/2 <= h+1e-9:
                        config.append((x, y, 0.125, s))
                        placed += 1
            if placed == m:
                best_s = s
                best_config = config
    return best_s, best_config


def _best_split_into_regions(n):
    """(Copy from provided code, kept for fallback)"""
    unit = 1.0
    if n <= 4:
        s, config = _pack_squares_in_rectangle(unit, unit, n)
        return s*n, config
    s, config = _pack_squares_in_rectangle(unit, unit, n)
    best_total = s*n
    best_squares = config
    for cut in np.linspace(0.1, 0.9, 9):
        w = unit
        h1, h2 = cut, unit-cut
        for m1 in range(1, n):
            m2 = n - m1
            s1, c1 = _pack_squares_in_rectangle(w, h1, m1)
            s2, c2 = _pack_squares_in_rectangle(w, h2, m2)
            total = m1*s1 + m2*s2
            if total > best_total:
                best_total = total
                c2_shifted = [(x, y+h1, a, s) for x,y,a,s in c2]
                best_squares = c1 + c2_shifted
        w1, w2 = cut, unit-cut
        for m1 in range(1, n):
            m2 = n - m1
            s1, c1 = _pack_squares_in_rectangle(w1, unit, m1)
            s2, c2 = _pack_squares_in_rectangle(w2, unit, m2)
            total = m1*s1 + m2*s2
            if total > best_total:
                best_total = total
                c2_shifted = [(x+w1, y, a, s) for x,y,a,s in c2]
                best_squares = c1 + c2_shifted
    for hcut in np.linspace(0.2, 0.8, 5):
        for vcut in np.linspace(0.2, 0.8, 5):
            ws = [vcut, unit-vcut, vcut, unit-vcut]
            hs = [hcut, hcut, unit-hcut, unit-hcut]
            offsets_x = [0, vcut, 0, vcut]
            offsets_y = [0, 0, hcut, hcut]
            areas = [ws[i]*hs[i] for i in range(4)]
            total_area = sum(areas)
            base_counts = [max(1, int(round(n * a / total_area))) for a in areas]
            diff = n - sum(base_counts)
            for i in range(diff):
                base_counts[i%4] += 1
            for i in range(-diff):
                idx = 3 - (i%4)
                if base_counts[idx] > 1:
                    base_counts[idx] -= 1
            counts_variants = [base_counts]
            for counts in counts_variants:
                if any(c<0 for c in counts): continue
                total = 0.0
                valid = True
                region_squares = []
                for i in range(4):
                    w, h = ws[i], hs[i]
                    m = counts[i]
                    s, config = _pack_squares_in_rectangle(w, h, m)
                    if len(config) != m:
                        valid = False
                        break
                    total += m*s
                    ox, oy = offsets_x[i], offsets_y[i]
                    shifted = [(x+ox, y+oy, a, s) for x,y,a,s in config]
                    region_squares.extend(shifted)
                if valid and total > best_total:
                    best_total = total
                    best_squares = region_squares
    return best_total, best_squares


# ------------------------------
#  Main solve function
# ------------------------------

def solve(n):
    """
    Return n squares inside unit square maximizing sum of side lengths.
    Uses independent set approach on candidate placements.
    """
    if n <= 0:
        return []
    # First try the independent set method
    try:
        squares = _pack_independent_set(n)
    except Exception:
        # Fallback
        _, squares = _best_split_into_regions(n)
    # Ensure correct count
    if len(squares) < n:
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    # Final check: ensure all inside unit square (clamp if slightly out)
    result = []
    for sq in squares:
        cx, cy, a, s = sq
        # clamp center to [0,1] with side not protruding
        # This shouldn't happen if inside checks work, but as safety
        hs = s * 0.71
        cx = max(hs, min(1.0 - hs, cx))
        cy = max(hs, min(1.0 - hs, cy))
        result.append((cx, cy, a, s))
    return result[:n]

