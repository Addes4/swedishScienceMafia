import numpy as np
from scipy.optimize import differential_evolution, NonlinearConstraint
import math

def solve(n):
    """
    Square packing via circle-packing transformation.
    Pack n circles inside unit square, then inscribe squares.
    Squares inscribed in circles have side s_i = r_i * sqrt(2) (diagonal = 2r).
    to avoid overlap, emulate circle packing geometry for squares.
    
    Returns n squares as (centre_x, centre_y, angle, side) tuples.
    """
    if n <= 0:
        return []
    
    # Use deterministic random seed for reproducibility and good initial trials
    np.random.seed(42)
    
    # Parameterize by circle radii r_i and center positions (cx_i, cy_i)
    # side = r * sqrt(2), so s_i = sqrt(2) * r_i
    # Constraint: centers and radii such that circles (and thus square bounding boxes) don't overlap
    
    x = np.ones(3 * n)  # [cx_1, cx_2, ..., cx_n, cy_1, cy_2, ..., cy_n, r_1, r_2, ..., r_n]
    
    # Bounds for each: 0 <= cx <= 0.99, 0 <= cy <= 0.99, 0 <= r <= 0.49   (initial safe ranges)
    bounds = [(0, 1) for _ in range(3 * n)]
    
    def sq_as一世_total_side(params):
        cx = params[:n]
        cy = params[n:2 * n]
        r = params[2 * n:]
        
        # side = r * sqrt(2), so sum of sides = sqrt(2) * sum(r)
        return np.sqrt(2) * np.sum(r)[:-1]  # Then adjust later
    
    # Define the combined objective
    def objective(x):
        cx = x[:n]
        cy = x[n:2 * n]
        r = x[2 * n:]
        
        s = r * math.sqrt(2)  # Side length from circle radius
        
        # Penalise for violating constraints
        penalty = 0.0
        
        # Squares must be within unit square at corners (assuming 0-degree for now)
        # For simplicity, enforce center bounds: 
        for i in range(n):
            if cx[i] - r[i] < 0 or cx[i] + r[i] > 1:
                penalty += (max(0, -(cx[i] - r[i])) + max(0, cx[i] + r[i] - 1)) * 10
            if cy[i] - r[i] < 0 or cy[i] + r[i] > 1:
                penalty += (max(0, -(cy[i] - r[i])) + max(0, cy[i] + r[i] - 1)) * 10
                
            # Center must be in [0,1]
            if cx[i] < 0 or cx[i] > 1 or cy[i] < 0 or cy[i] > 1:
                penalty += abs(cx[i] - 0.5) + abs(cy[i] - 0.5)
            
            if s[i] < 0:
                penalty += abs(s[i]) * 10
        
        # Scatter penalties for overlaps between circles
        for i in range(n):
            for j in range(i + 1, n):
                dist = math.hypot(cx[i] - cx[j], cy[i] - cy[j])
                sum_r = r[i] + r[j]
                
                if dist < sum_r - 1e-6:
                    penalty += max(0, sum_r - dist) * 100
                
        return -math.sqrt(2) * np.sum(r) + penalty  # Negative to make maximization into minimization
    
    def load_squares(x):
        cx = x[:n]
        cy = x[n:2 * n]
        r = x[2 * n:]
        s = r * math.sqrt(2)
        
        # Return squares (assuming angle=0)
        return [(cx[i], cy[i], 0.0, s[i]) for i in range(n)]
    
    # Global optimization via differential evolution
    bounds = [(0, 1) for _ in range(3 * n)]
    
    # First easy pass: fill with initial config
    best_x = None
    best_obj = -float('inf')
    
    # Try 30 iterations of diff evolutionary
    for _ in range(30):
        res = differential_evolution(
            objective,
            bounds,
            seed=_ + 10,
            maxiter=100,
            popsize=50,
            tol=1e-3,
            mutation=(0.5, 0.2),
            recombination=(0.75, 0.85)
        )
        if res.fun < best_obj:
            best_x = res.x
            best_obj = res.fun
    
    if best_x is None:
        best_x = np.array([0.5] * 3 * n)
    else:
        best_x = np.clip(best_x, 0, 1)
    
    cx = best_x[:n]
    cy = best_x[n:2 * n]
    r = best_x[2 * n:]
    
    s = r * math.sqrt(2)
    
    # If any squared is negative, force to zero
    s[s < 1e-9] = 0
    
    squares = []
    for i in range(n):
        c = cx[i]
        cc = cy[i]
        sch = s[i]
        if sch < 0:
            sch = 0
        if sch == 0:
            squares.append((0.5, 0.5, 0.0, 0.0))
            continue
        
        # Clamp coordinates to keep square inside unit square
        margin = sch / 2
        cx_clamped = min(max(c - margin, margin), 1 - margin)
        cy_clamped = min(max(cc - margin, margin), 1 - margin)
        
        squares.append((cx_clamped, cy_clamped, 0.0, sch))
    
    # Pad remaining squares with zeros if needed
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    
    return squares[:n]
