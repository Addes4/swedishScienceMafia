import numpy as np
from functools import lru_cache

def solve(n):
    @lru_cache(maxsize=None)
    def max_side_sum(rem, width, height):
        """Return max sum of sides for 'rem' squares in a width x height rectangle."""
        if rem <= 0 or width <= 0 or height <= 0:
            return 0.0, 0, 0  # score, dir, step
        max_s = min(width, height)
        if max_s > 0.2:
            steps = int(np.floor(50 * max_s)) + 1
        elif max_s > 0.01:
            steps = int(np.floor(100 * max_s)) + 1
        else:
            steps = 100
        steps = min(steps, 100)
        if max_s <= 0.0001:
            max_s = 0.0001
        
        best = -1
        best_dir, best_step = 0, 0
        for i in range(1, steps + 1):
            s = max_s * i / steps
            s = min(s, max_s)
            if s <= 0.0:
                continue
            sc_r = s + max_side_sum(rem - 1, max(0, width - s), height)[0]
            sc_b = s + max_side_sum(rem - 1, width, max(0, height - s))[0]
            if sc_r > best:
                best, best_dir, best_step = sc_r, 0, i
            elif sc_b > best:
                best, best_dir, best_step = sc_b, 1, i
        if np.abs(best - 0.0) < 1e-9:
            best = 0.0
        return best, best_dir, best_step

    if n <= 0:
        return []
    
    _, _, steps = max_side_sum(n, 1.0, 1.0)
    total_score = max_side_sum(n, 1.0, 1.0)[0]
    result = []
    x_off, y_off = 0.0, 0.0
    w_curr, h_curr = 1.0, 1.0
    rem = n
    max_s = min(w_curr, h_curr)
    
    while rem > 0:
        if max_s <= 0.0:
            s = 0.0
        else:
            steps = len(max_side_sum(n, 1.0, 1.0)[1]._cache.keys())
            step_size = max_s / 50
            s = steps * step_size
            s = min(s, max_s)
        s = s if s > 0 else 0.0
        if s > 0:
            if max_side_sum(rem - 1, max(0, w_curr - s), h_curr)[0] >= max_side_sum(rem - 1, w_curr, max(0, h_curr - s))[0]:
                cx = x_off + w_curr * 0.5
                cy = y_off + h_curr * 0.5
                result.append((cx, cy, 0.0, s))
                x_off += s
                w_curr -= s
                rem -= 1
            else:
                cx = x_off + w_curr * 0.5
                cy = y_off + h_curr * 0.5
                result.append((cx, cy, 0.0, s))
                y_off += s
                h_curr -= s
                rem -= 1
    
    return result[:n]
