import itertools
import math

import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint

# ------------------------------------------------------------
#  Known optimal (or best known) packings for small m, scaled
#  to a rectangle [0, w] x [0, h] with uniform side s.
#  Each returns (s, [(cx, cy, angle, side), ...])
# ------------------------------------------------------------

def _pack_2_in_rect(w, h):
    """Two squares: side by side or stacked."""
    # axis-aligned best: side = min(w/2, h) or min(w, h/2)
    best_s = 0.0
    best_config = []
    # horizontally
    s = min(w / 2, h)
    if s > best_s:
        best_s = s
        best_config = [(w/4, h/2, 0.0, s), (3*w/4, h/2, 0.0, s)]
    # vertically
    s = min(w, h / 2)
    if s > best_s:
        best_s = s
        best_config = [(w/2, h/4, 0.0, s), (w/2, 3*h/4, 0.0, s)]
    return best_s, best_config

def _pack_3_in_rect(w, h):
    """Three squares: optimal known is often two in a row + one above/below, or 45° rotated."""
    best_s = 0.0
    best_config = []
    # arrangement 1: two small on bottom, one large top? but equal squares.
    # For equal squares, they can be packed axis-aligned:
    # 3 in a row: side = min(w/3, h)
    s = min(w/3, h)
    if s > best_s:
        best_s = s
        best_config = [(w/6, h/2, 0.0, s), (w/2, h/2, 0.0, s), (5*w/6, h/2, 0.0, s)]
    # 2 in first row, 1 in second row center
    s1 = min(w/2, h/2)  # could have height split
    # need two squares side by side in bottom half, one top half centered
    s_row = min(w/2, h/2)
    s2 = min(w, h/2)  # top half height h/2, width w
    # both must have same side s => s = min(s_row, s2) but actually s must fit both regions
    # bottom row: 2 squares of side s, top: 1 square of side s
    # height split: h = h_bot + h_top, both >= s. So s <= h/2? actually if h_top = s, h_bot = s, then total h=2s => s = h/2.
    # But we can have unequal heights: let bottom row height = s, top row height = s => total h = 2s => s = h/2.
    # That's ok if bottom width >= 2s and top width >= s.
    s = min(h/2, w/2)
    if s > best_s:
        best_s = s
        # bottom: y centered in height s (so cy = s/2), top: y = s + s/2 = 1.5*s
        # but total height = 2s
        best_config = [(w/4, s/2, 0.0, s), (3*w/4, s/2, 0.0, s), (w/2, 1.5*s, 0.0, s)]
    # rotated 45° packing in a triangle? Known optimal small packing sometimes uses 45° rotations.
    # For 3 squares in a square, known optimum is side = ?. But we'll try a 45° rotated arrangement:
    # pack two at bottom corners rotated, one on top rotated? Difficult.
    # We can also just try the general grid heuristic.
    # Use general _pack_squares_in_rectangle for m=3 which includes 45°.
    # But we already have specialized for known optimals. Let's add the general one as fallback.
    s_general, config_general = _pack_squares_in_rectangle(w, h, 3)
    if s_general > best_s:
        best_s = s_general
        best_config = config_general
    return best_s, best_config

def _pack_4_in_rect(w, h):
    """Four squares: 2x2 grid or row of 4 etc."""
    # 2x2 grid: s = min(w/2, h/2)
    s = min(w/2, h/2)
    config = [(w/4, h/4, 0.0, s), (3*w/4, h/4, 0.0, s),
              (w/4, 3*h/4, 0.0, s), (3*w/4, 3*h/4, 0.0, s)]
    best_s = s
    best_config = config
    # also 4 in a row/col
    s2 = min(w/4, h)
    if s2 > best_s:
        best_s = s2
        best_config = [(w/8, h/2, 0.0, s2), (3*w/8, h/2, 0.0, s2),
                       (5*w/8, h/2, 0.0, s2), (7*w/8, h/2, 0.0, s2)]
    s3 = min(w, h/4)
    if s3 > best_s:
        best_s = s3
        best_config = [(w/2, h/8, 0.0, s3), (w/2, 3*h/8, 0.0, s3),
                       (w/2, 5*h/8, 0.0, s3), (w/2, 7*h/8, 0.0, s3)]
    return best_s, best_config

def _pack_5_in_rect(w, h):
    """Five squares: known optimal in unit square is side=1/3? Actually 5 squares max sum is 2?
    Wait known reference: n=5 score 2 -> sum of sides = 2.0, meaning each side 0.4? Actually sum of side lengths = 2.0 => each = 0.4? But side of unit square 1, packing 5 equal squares? 0.4*5=2.0, yes.
    But optimal packing might be a cross: one central and four at corners rotated? However known best is 2.0 for unit square with equal squares? Actually optimal configuration for 5 squares might use different sizes?
    Problem asks maximize sum of side lengths, squares can be different sizes. But for small n, equal squares often optimal.
    We'll provide specialized known best packings from literature if possible.
    For 5 squares in a square, known maximal side length sum is 2, achieved by five equal squares in a 'pinwheel' arrangement? But we can just use general rotation packer.
    """
    best_s, best_config = _pack_squares_in_rectangle(w, h, 5, rotated=True)
    return best_s, best_config

def _pack_6_in_rect(w, h):
    """Six squares"""
    best_s, best_config = _pack_squares_in_rectangle(w, h, 6, rotated=True)
    return best_s, best_config

def _pack_7_in_rect(w, h):
    best_s, best_config = _pack_squares_in_rectangle(w, h, 7, rotated=True)
    return best_s, best_config

def _pack_8_in_rect(w, h):
    best_s, best_config = _pack_squares_in_rectangle(w, h, 8, rotated=True)
    return best_s, best_config

# general cube-based heuristic with rotation
def _pack_squares_in_rectangle(w, h, m, rotated=True, max_iter=3):
    if m == 0:
        return 0.0, []
    if m == 1:
        s = min(w, h)
        return s, [(w/2, h/2, 0.0, s)]
    best_s = 0.0
    best_config = []
    # axis-aligned grid
    for rows in range(1, m+1):
        cols = max(1, math.ceil(m / rows))
        s1 = w / cols
        s2 = h / rows
        s = min(s1, s2)
        if s > best_s:
            best_s = s
            config = []
            placed = 0
            for r in range(rows):
                if placed >= m: break
                for c in range(cols):
                    if placed >= m: break
                    cx = (c + 0.5) * s
                    cy = (r + 0.5) * s
                    config.append((cx, cy, 0.0, s))
                    placed += 1
            best_config = config
    # 45-deg rotated grid
    if rotated and m >= 2:
        diag = math.sqrt(2)
        for rows in range(1, m+1):
            cols = max(1, math.ceil(m / rows))
            s_h = w / (cols * diag)
            s_v = h / (rows * diag)
            s = min(s_h, s_v)
            # staggered
            if cols > 1 and rows > 1:
                s_h_stag = w / ((cols - 0.5) * diag)
                s = max(s, min(s_h_stag, s_v))
            if s > best_s:
                # try placement
                for use_stagger in [False, True]:
                    if use_stagger and (cols <=1 or rows <=1): continue
                    placed = 0
                    config = []
                    for r in range(rows):
                        if placed >= m: break
                        y = (r + 0.5) * s * diag
                        shift = (r % 2) * s * diag / 2 if use_stagger else 0.0
                        for c in range(cols):
                            if placed >= m: break
                            x = shift + (c + 0.5) * s * diag
                            if x - s*diag/2 >= -1e-9 and x + s*diag/2 <= w+1e-9 and \
                               y - s*diag/2 >= -1e-9 and y + s*diag/2 <= h+1e-9:
                                config.append((x, y, 0.125, s))
                                placed += 1
                    if placed == m:
                        best_s = s
                        best_config = config
                        break # found a good one
    return best_s, best_config

# Known specific packings for small m that can be used as building blocks.
# Map m to function returning best packing for rectangle [0,w]x[0,h]
_small_packers = {
    2: _pack_2_in_rect,
    3: _pack_3_in_rect,
    4: _pack_4_in_rect,
    5: _pack_5_in_rect,
    6: _pack_6_in_rect,
    7: _pack_7_in_rect,
    8: _pack_8_in_rect,
}

def _pack_m_in_rect(w, h, m):
    if m in _small_packers:
        return _small_packers[m](w, h)
    else:
        return _pack_squares_in_rectangle(w, h, m)

# ------------------------------------------------------------
#  Tiling the unit square with several rectangular regions,
#  each filled with a known optimal packing for small counts.
#  We search over partitions of n and partitions of the square.
# ------------------------------------------------------------

def _tile_with_blocks(n):
    """Try splitting unit square into rectangles, fill each with optimal small packing."""
    best_total = 0.0
    best_squares = None
    
    # fallback: whole square with general packer
    s, config = _pack_m_in_rect(1.0, 1.0, n)
    best_total = s * n
    best_squares = config

    # If n is small, just return
    if n <= 8:
        return best_total, best_squares

    # For n up to ~40, we can try horizontal/vertical cuts allocating squares to subregions.
    # We'll try splits into 2,3,4 rectangular regions with various cut points and integer allocations.
    # To limit search, we only use building blocks that are known to be good: m <= 8 or generic.
    # We'll explore partitions of n into k parts, k in {2,3,4}, each part >=1.
    # For each partition, we try splitting the square so that each subrectangle has area proportional to part count? Not exactly, but we try a set of cut positions.
    # Since time is limited, we perform a restricted search.
    
    # Precompute good cut fractions
    cuts = np.linspace(0.2, 0.8, 6)
    # Try 2 regions via horizontal or vertical cut
    for cut in cuts:
        # horizontal
        h1, h2 = cut, 1.0 - cut
        for m1 in range(1, n):
            m2 = n - m1
            s1, c1 = _pack_m_in_rect(1.0, h1, m1)
            s2, c2 = _pack_m_in_rect(1.0, h2, m2)
            total = m1*s1 + m2*s2
            if total > best_total:
                best_total = total
                c2_shifted = [(x, y + h1, a, s) for (x,y,a,s) in c2]
                best_squares = c1 + c2_shifted
        # vertical
        w1, w2 = cut, 1.0 - cut
        for m1 in range(1, n):
            m2 = n - m1
            s1, c1 = _pack_m_in_rect(w1, 1.0, m1)
            s2, c2 = _pack_m_in_rect(w2, 1.0, m2)
            total = m1*s1 + m2*s2
            if total > best_total:
                best_total = total
                c2_shifted = [(x + w1, y, a, s) for (x,y,a,s) in c2]
                best_squares = c1 + c2_shifted

    # Try 3 regions: two cuts horizontal (stacking three rows) or L-shaped? Just horizontal stacks.
    for cut1, cut2 in itertools.combinations(cuts, 2):
        cuts_sorted = sorted([cut1, cut2])
        hs = [cuts_sorted[0], cuts_sorted[1] - cuts_sorted[0], 1.0 - cuts_sorted[1]]
        # partition n into three positive parts
        for m1 in range(1, n-1):
            for m2 in range(1, n - m1):
                m3 = n - m1 - m2
                c1_s, c1 = _pack_m_in_rect(1.0, hs[0], m1)
                c2_s, c2 = _pack_m_in_rect(1.0, hs[1], m2)
                c3_s, c3 = _pack_m_in_rect(1.0, hs[2], m3)
                total = m1*c1_s + m2*c2_s + m3*c3_s
                if total > best_total:
                    best_total = total
                    c2_sft = [(x, y + hs[0], a, s) for (x,y,a,s) in c2]
                    c3_sft = [(x, y + hs[0]+hs[1], a, s) for (x,y,a,s) in c3]
                    best_squares = c1 + c2_sft + c3_sft
    # vertical 3 columns symmetric
    for cut1, cut2 in itertools.combinations(cuts, 2):
        cuts_sorted = sorted([cut1, cut2])
        ws = [cuts_sorted[0], cuts_sorted[1] - cuts_sorted[0], 1.0 - cuts_sorted[1]]
        for m1 in range(1, n-1):
            for m2 in range(1, n - m1):
                m3 = n - m1 - m2
                c1_s, c1 = _pack_m_in_rect(ws[0], 1.0, m1)
                c2_s, c2 = _pack_m_in_rect(ws[1], 1.0, m2)
                c3_s, c3 = _pack_m_in_rect(ws[2], 1.0, m3)
                total = m1*c1_s + m2*c2_s + m3*c3_s
                if total > best_total:
                    best_total = total
                    c2_sft = [(x + ws[0], y, a, s) for (x,y,a,s) in c2]
                    c3_sft = [(x + ws[0]+ws[1], y, a, s) for (x,y,a,s) in c3]
                    best_squares = c1 + c2_sft + c3_sft

    # Try 4 regions: grid, partition n into 4 positive parts
    # We limit partitions by trying area-proportional initial guess + small adjustments.
    for hcut in cuts:
        for vcut in cuts:
            ws = [vcut, 1.0 - vcut, vcut, 1.0 - vcut]
            hs = [hcut, hcut, 1.0 - hcut, 1.0 - hcut]
            ox = [0, vcut, 0, vcut]
            oy = [0, 0, hcut, hcut]
            areas = [ws[i]*hs[i] for i in range(4)]
            total_area = sum(areas)
            base = [max(1, int(round(n * a / total_area))) for a in areas]
            # adjust to sum n
            diff = n - sum(base)
            for i in range(abs(diff)):
                if diff > 0:
                    base[i%4] += 1
                else:
                    idx = 3 - (i%4)
                    if base[idx] > 1:
                        base[idx] -= 1
            if sum(base) != n or min(base) < 1: continue
            # try a few variations moving up to 1 square between regions
            variants = [base[:]]
            # shift one from max to min
            idx_max = max(range(4), key=lambda i: base[i])
            idx_min = min(range(4), key=lambda i: base[i])
            if idx_max != idx_min and base[idx_max] > 1:
                v2 = base[:]
                v2[idx_max] -= 1
                v2[idx_min] += 1
                variants.append(v2)
            for counts in variants:
                configs = []
                total_side = 0.0
                ok = True
                for i in range(4):
                    s, c = _pack_m_in_rect(ws[i], hs[i], counts[i])
                    if len(c) != counts[i]:
                        ok = False
                        break
                    total_side += counts[i] * s
                    c_shift = [(x+ox[i], y+oy[i], a, s) for (x,y,a,s) in c]
                    configs.extend(c_shift)
                if ok and total_side > best_total:
                    best_total = total_side
                    best_squares = configs

    # Also try a 2x2 equal grid with equal counts in each (if n divisible by 4)
    if n % 4 == 0 and n >= 4:
        m_part = n // 4
        s, c = _pack_m_in_rect(0.5, 0.5, m_part)
        if len(c) == m_part:
            total = 4 * m_part * s
            if total > best_total:
                best_total = total
                best_squares = []
                for i, j in [(0,0),(1,0),(0,1),(1,1)]:
                    shiftx = i * 0.5
                    shifty = j * 0.5
                    best_squares.extend([(x+shiftx, y+shifty, a, s) for (x,y,a,s) in c])

    return best_total, best_squares


def solve(n):
    _, squares = _tile_with_blocks(n)
    if len(squares) < n:
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]
