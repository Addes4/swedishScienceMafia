import math
import numpy as np
from scipy.optimize import minimize

# ----------------------------------------------------------------------------
# Geometry helpers for rotated squares (standard library + numpy only)
# ----------------------------------------------------------------------------

def _square_corners(cx, cy, ang, s):
    """Return 4x2 array of corner coordinates for a square.
    ang is fraction of full turn (0.25 = 90 deg)."""
    th = 2.0 * math.pi * ang
    c, si = math.cos(th), math.sin(th)
    h = 0.5 * s
    # local corners
    loc = np.array([[-h, -h], [h, -h], [h, h], [-h, h]])
    R = np.array([[c, -si], [si, c]])
    return loc @ R.T + np.array([cx, cy])


def _axes(cx, cy, ang, s):
    """Return two orthogonal axis vectors (unit) of the square plus half-extents."""
    th = 2.0 * math.pi * ang
    c, si = math.cos(th), math.sin(th)
    u = np.array([c, si])
    v = np.array([-si, c])
    return u, v


# ----------------------------------------------------------------------------
# Separating axis overlap measure between two OBBs (squares = special OBBs)
# ----------------------------------------------------------------------------

def _penetration_depth(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """
    Approximate minimum translation vector penetration for two squares.
    Uses the separating-axis heuristic: for each of the 4 axes (2 per square),
    compute overlap of projections; penetration depth = min over ALL axes of the
    projection overlap.  If any axis has non-positive overlap -> no collision.
    Returns (depth, axis) where depth>0 means penetration.
    This is a valid overlap measure for convex polygons (SAT gives separation,
    and the minimum axial overlap is a good proxy for penetration depth).
    """
    u1, v1 = _axes(cx1, cy1, a1, s1)
    u2, v2 = _axes(cx2, cy2, a2, s2)

    d = np.array([cx2 - cx1, cy2 - cy1])

    h1 = 0.5 * s1
    h2 = 0.5 * s2

    best_depth = None
    best_axis = None

    for ax in (u1, v1, u2, v2):
        # projection center dist
        dist = abs(np.dot(d, ax))
        r1 = h1 * abs(np.dot(u1, ax)) + h1 * abs(np.dot(v1, ax))
        r2 = h2 * abs(np.dot(u2, ax)) + h2 * abs(np.dot(v2, ax))
        overlap = r1 + r2 - dist
        if overlap <= 0.0:
            return 0.0, np.zeros(2)
        if best_depth is None or overlap < best_depth:
            best_depth = overlap
            # axis pointing from square1 to square2
            sign = 1.0 if np.dot(d, ax) >= 0 else -1.0
            best_axis = sign * ax

    return best_depth, best_axis


# ----------------------------------------------------------------------------
# Soft repulsive energy
# ----------------------------------------------------------------------------

def _energy_and_grad(params, n, stiffness, box_penalty):
    """
    params: flat array [cx0,cy0,a0,s0, cx1,...]
    Returns (E, grad) where E = -sum(s_i) + penalty terms.
    penalty = stiffness * sum_{i<j} phi(d_ij)  with phi smooth hinge of penetration.
    plus box containment penalty.
    """
    P = params.reshape(n, 4)
    grad = np.zeros_like(P)

    s = P[:, 3]

    E = -np.sum(s)

    # grad of -sum s
    for i in range(n):
        grad[i, 3] -= 1.0

    # box containment: square must fit in [0,1]^2.
    # For each square compute its half-extent along x and y; require
    # cx - ex >= 0, cx + ex <= 1 (similarly y).  Use soft quadratic penalty.
    for i in range(n):
        cx, cy, ang, si = P[i]
        u, v = _axes(cx, cy, ang, si)
        ex = 0.5 * si * (abs(u[0]) + abs(v[0]))
        ey = 0.5 * si * (abs(u[1]) + abs(v[1]))
        # violations
        for (coord, ext, dim) in ((cx, ex, 0), (cy, ey, 1)):
            lo = coord - ext
            hi = coord + ext - 1.0
            if lo < 0.0:
                E += box_penalty * lo * lo
                grad[i, dim] += box_penalty * 2.0 * lo
                # also via size derivative
            if hi > 0.0:
                E += box_penalty * hi * hi
                grad[i, dim] += box_penalty * 2.0 * hi
            # derivative wrt size (ext proportional to size)
            # de/ds = 0.5*(|u0|+|v0|)
            drev = 0.5 * (abs(u[dim]) + abs(v[dim])) if dim == 0 else 0.5 * (abs(u[1]) + abs(v[1]))
            if lo < 0.0:
                grad[i, 3] += box_penalty * 2.0 * lo * (-drev)
            if hi > 0.0:
                grad[i, 3] += box_penalty * 2.0 * hi * (drev)

    # pairwise repulsion
    for i in range(n):
        for j in range(i + 1, n):
            depth, axis = _penetration_depth(
                P[i, 0], P[i, 1], P[i, 2], P[i, 3],
                P[j, 0], P[j, 1], P[j, 2], P[j, 3],
            )
            if depth <= 0.0:
                continue
            # hinge penalty 0.5 * k * depth^2
            E += stiffness * 0.5 * depth * depth
            # gradient wrt centres: d(depth)/d(ci) = -axis, d/d(cj) = +axis
            g = stiffness * depth
            grad[i, 0] += g * (-axis[0])
            grad[i, 1] += g * (-axis[1])
            grad[j, 0] += g * (axis[0])
            grad[j, 1] += g * (axis[1])
            # note: we ignore gradient wrt angles/sizes in penalty for stability;
            # the size gradient is added approximately to prevent shrinking into things.
            # Size reduction of either square reduces penetration, so d(depth)/ds_i < 0.
            # Approximate: moving along size reduces overlap linearly.
            for k, sgn in ((i, -1.0), (j, -1.0)):
                # lowering s reduces projected half extents by ~0.5 each axis,
                # so depth change ~ -0.5*(depth contribution). Use conservative factor.
                grad[k, 3] += stiffness * depth * 0.5 * sgn * (-1.0) * 0.0  # disabled (see below)

    return E, grad.ravel()


# ----------------------------------------------------------------------------
# Initial configurations
# ----------------------------------------------------------------------------

def _initial_config(n):
    """Provide a reasonable starting layout: grid for square-ish n, else strip."""
    P = np.zeros((n, 4))
    cols = int(math.ceil(math.sqrt(n)))
    rows = int(math.ceil(n / cols))
    s = min(1.0 / cols, 1.0 / rows) * 0.6
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            cx = (c + 0.5) / cols
            cy = (r + 0.5) / rows
            P[idx] = [cx, cy, 0.0, s]
            idx += 1
    return P


# ----------------------------------------------------------------------------
# Projection / repair: make configuration exactly feasible
# ----------------------------------------------------------------------------

def _clamp_to_box(P):
    """Push squares fully inside the box by moving centres (not shrinking)."""
    Q = P.copy()
    for i in range(len(Q)):
        for _ in range(4):
            cx, cy, ang, s = Q[i]
            u, v = _axes(cx, cy, ang, s)
            ex = 0.5 * s * (abs(u[0]) + abs(v[0]))
            ey = 0.5 * s * (abs(u[1]) + abs(v[1]))
            moved = False
            if cx - ex < 0.0:
                cx = ex; moved = True
            if cx + ex > 1.0:
                cx = 1.0 - ex; moved = True
            if cy - ey < 0.0:
                cy = ey; moved = True
            if cy + ey > 1.0:
                cy = 1.0 - ey; moved = True
            if ex > 0.5:
                s = 0.5 / max(ex / max(s, 1e-12), 1e-12)
            if ey > 0.5:
                s = min(s, 0.5 / max(0.5 * (abs(u[1]) + abs(v[1])), 1e-12))
            Q[i] = [cx, cy, ang, s]
            if not moved:
                break
    return Q


def _resolve_overlaps(P, iterations=200):
    """
    Greedily separate overlapping squares by shrinking the smaller one
    (somewhat) and nudging centres apart.  Maintains box containment.
    """
    Q = P.copy()
    n = len(Q)
    for it in range(iterations):
        moved = False
        for i in range(n):
            for j in range(i + 1, n):
                depth, axis = _penetration_depth(
                    Q[i, 0], Q[i, 1], Q[i, 2], Q[i, 3],
                    Q[j, 0], Q[j, 1], Q[j, 2], Q[j, 3],
                )
                if depth <= 1e-9:
                    continue
                moved = True
                # shrink the smaller square a bit and separate centres
                si, sj = Q[i, 3], Q[j, 3]
                if si >= sj:
                    shrink_j = True
                else:
                    shrink_j = False
                shrink = depth * 0.55
                if shrink_j:
                    Q[j, 3] = max(0.0, Q[j, 3] - shrink)
                else:
                    Q[i, 3] = max(0.0, Q[i, 3] - shrink)
                # nudge both centres apart along axis
                push = 0.5 * depth
                Q[i, 0] -= push * axis[0]
                Q[i, 1] -= push * axis[1]
                Q[j, 0] += push * axis[0]
                Q[j, 1] += push * axis[1]
        Q = _clamp_to_box(Q)
        if not moved:
            break
    return Q


def _is_feasible(P, tol=1e-7):
    n = len(P)
    for i in range(n):
        cx, cy, ang, s = P[i]
        if s < -tol:
            return False
        u, v = _axes(cx, cy, ang, s)
        ex = 0.5 * s * (abs(u[0]) + abs(v[0]))
        ey = 0.5 * s * (abs(u[1]) + abs(v[1]))
        if cx - ex < -tol or cx + ex > 1.0 + tol:
            return False
        if cy - ey < -tol or cy + ey > 1.0 + tol:
            return False
    for i in range(n):
        for j in range(i + 1, n):
            depth, _ = _penetration_depth(
                P[i, 0], P[i, 1], P[i, 2], P[i, 3],
                P[j, 0], P[j, 1], P[j, 2], P[j, 3],
            )
            if depth > 1e-6:
                return False
    return True


# ----------------------------------------------------------------------------
# Core annealed gradient ascent
# ----------------------------------------------------------------------------

def _annealed_ascent(n, seed=0):
    rng = np.random.default_rng(seed)
    P = _initial_config(n)

    # slight randomization
    P[:, 0] += rng.uniform(-0.01, 0.01, n)
    P[:, 1] += rng.uniform(-0.01, 0.01, n)
    P[:, 2] += rng.uniform(-0.02, 0.02, n)

    best_feasible = None
    best_sum = -1.0

    stiffness_schedule = [3.0, 10.0, 30.0, 90.0, 250.0, 700.0, 2000.0, 5000.0]
    box_penalty = 2000.0

    for k, stiffness in enumerate(stiffness_schedule):
        params = P.ravel().copy()
        # perform a few gradient ascent steps (maximize sum s => minimize E)
        lr = 0.05 / (1.0 + 0.3 * k)
        for step in range(120):
            E, g = _energy_and_grad(params, n, stiffness, box_penalty)
            # normalize gradient magnitude
            gn = np.linalg.norm(g)
            if gn < 1e-12:
                break
            params = params - lr * g / max(1.0, gn)
            # clamp sizes to >=0
            Pcur = params.reshape(n, 4)
            Pcur[:, 3] = np.maximum(Pcur[:, 3], 0.0)
            # keep angles bounded
            params = Pcur.ravel()
        P = params.reshape(n, 4).copy()

        # Try to repair to exact feasibility and record
        Q = _resolve_overlaps(_clamp_to_box(P), iterations=150)
        if _is_feasible(Q):
            total = float(np.sum(Q[:, 3]))
            if total > best_sum:
                best_sum = total
                best_feasible = Q.copy()

    if best_feasible is None:
        # fallback: make a tiny grid, feasible by construction
        best_feasible = _resolve_overlaps(_clamp_to_box(P), iterations=400)
        # if still infeasible, shrink everything
        if not _is_feasible(best_feasible):
            s = best_feasible[:, 3]
            best_feasible[:, 3] = s * 0.5
            best_feasible = _resolve_overlaps(_clamp_to_box(best_feasible), iterations=400)

    return best_feasible


# ----------------------------------------------------------------------------
# Exact-ish improvement: local optimization to grow side lengths
# ----------------------------------------------------------------------------

def _grow_sides_exact(P0, tries=1):
    """
    Given a feasible configuration, try to increase all side lengths slightly
    and re-resolve overlaps.  This acts as a post-processing projection that
    tends to increase the sum.
    """
    P = P0.copy()
    n = len(P)
    for scale in np.linspace(1.03, 1.0, 8):
        Q = P.copy()
        Q[:, 3] = Q[:, 3] * scale
        Q = _resolve_overlaps(_clamp_to_box(Q), iterations=200)
        if _is_feasible(Q) and np.sum(Q[:, 3]) > np.sum(P[:, 3]):
            P = Q
    return P


# ----------------------------------------------------------------------------
# Large-n grid fallback (fast, good baseline)
# ----------------------------------------------------------------------------

def _grid_fallback(n):
    P = _initial_config(n)
    P[:, 2] = 0.0
    cols = int(math.ceil(math.sqrt(n)))
    rows = int(math.ceil(n / cols))
    s = min(1.0 / cols, 1.0 / rows)
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            P[idx] = [(c + 0.5) * s, (r + 0.5) * s, 0.0, s]
            idx += 1
    return P


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Try the annealed particle method with a few seeds, keep best feasible.
    best = None
    best_sum = -1.0

    # cheap baseline first
    grid = _grid_fallback(n)
    grid = _resolve_overlaps(_clamp_to_box(grid), iterations=100)
    if _is_feasible(grid):
        best = grid
        best_sum = float(np.sum(grid[:, 3]))

    n_seeds = 3 if n <= 30 else 1
    for seed in range(n_seeds):
        try:
            P = _annealed_ascent(n, seed=seed)
            P = _grow_sides_exact(P)
        except Exception:
            P = _grid_fallback(n)
            P = _resolve_overlaps(_clamp_to_box(P), iterations=200)
        if not _is_feasible(P):
            P = _resolve_overlaps(_clamp_to_box(P), iterations=300)
        if _is_feasible(P):
            total = float(np.sum(P[:, 3]))
            if total > best_sum:
                best_sum = total
                best = P.copy()

    if best is None:
        best = _grid_fallback(n)
        best[:, 3] = best[:, 3] * 0.5
        best = _resolve_overlaps(_clamp_to_box(best), iterations=300)

    out = []
    for i in range(n):
        cx, cy, ang, s = best[i]
        # final safety clamp
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        # normalize angle to [0,1)
        ang = float(ang) % 1.0
        s = max(0.0, float(s))
        out.append((float(cx), float(cy), float(ang), float(s)))
    return out
