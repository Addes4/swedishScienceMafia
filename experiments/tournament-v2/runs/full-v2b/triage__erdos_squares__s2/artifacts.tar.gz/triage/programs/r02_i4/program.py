import itertools
import math
import random

import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint
from scipy.spatial import cKDTree

def _pack_squares_in_rectangle(w, h, m, rotated=True, max_iter=3):
    """
    Pack m squares of equal side s into rectangle [0,w]x[0,h].
    Return maximal s and a configuration: list of (cx, cy, angle, s), possibly with rotation.
    angle=0 means axis-aligned, angle=0.25 means rotated 90 degrees (same as 0 effectively for square).
    """
    if m == 0:
        return 0.0, []
    if m == 1:
        s = min(w, h)
        return s, [(w / 2, h / 2, 0.0, s)]

    best_s = 0.0
    best_config = []

    # 1. Axis-aligned grid packing
    for rows in range(1, m + 1):
        cols = max(1, math.ceil(m / rows))
        s1 = w / cols
        s2 = h / rows
        s = min(s1, s2)
        if s > best_s:
            best_s = s
            config = []
            placed = 0
            for r in range(rows):
                if placed >= m:
                    break
                for c in range(cols):
                    if placed >= m:
                        break
                    cx = (c + 0.5) * s
                    cy = (r + 0.5) * s
                    config.append((cx, cy, 0.0, s))
                    placed += 1
            best_config = config

    # 2. 45-degree rotated packing (diamond) - works well for some m
    if rotated and m >= 2:
        diag = math.sqrt(2.0)
        for rows in range(1, m + 1):
            cols = max(1, math.ceil(m / rows))
            s_h = w / (cols * diag)
            s_v = h / (rows * diag)
            s = min(s_h, s_v)
            if cols > 1 and rows > 1:
                s_h_stag = w / ((cols - 0.5) * diag)
                s = max(s, min(s_h_stag, s_v))
            if s > best_s:
                best_s = s
                config = []
                placed = 0
                for r in range(rows):
                    if placed >= m:
                        break
                    y = (r + 0.5) * s * diag
                    shift = (r % 2) * s * diag / 2
                    for c in range(cols):
                        if placed >= m:
                            break
                        x = shift + (c + 0.5) * s * diag
                        if x - s * diag / 2 >= -1e-9 and x + s * diag / 2 <= w + 1e-9 and \
                           y - s * diag / 2 >= -1e-9 and y + s * diag / 2 <= h + 1e-9:
                            config.append((x, y, 0.125, s))
                            placed += 1
                if placed == m:
                    best_config = config

    return best_s, best_config


def _best_split_into_regions(n):
    """
    Try splitting the unit square into up to 4 rectangular regions using axis-aligned cuts.
    Assign a number of squares to each region, and pack each region independently.
    Return best configuration.
    """
    unit = 1.0
    best_total_side = 0.0
    best_squares = None

    if n <= 4:
        s, config = _pack_squares_in_rectangle(unit, unit, n)
        return s * n, config

    s, config = _pack_squares_in_rectangle(unit, unit, n)
    best_total_side = s * n
    best_squares = config

    for cut in np.linspace(0.1, 0.9, 9):
        w = unit
        h1 = cut
        h2 = unit - cut
        for m1 in range(1, n):
            m2 = n - m1
            s1, c1 = _pack_squares_in_rectangle(w, h1, m1)
            s2, c2 = _pack_squares_in_rectangle(w, h2, m2)
            total = m1 * s1 + m2 * s2
            if total > best_total_side:
                best_total_side = total
                c2_shifted = [(x, y + h1, a, s) for (x, y, a, s) in c2]
                best_squares = c1 + c2_shifted
        w1 = cut
        w2 = unit - cut
        h = unit
        for m1 in range(1, n):
            m2 = n - m1
            s1, c1 = _pack_squares_in_rectangle(w1, h, m1)
            s2, c2 = _pack_squares_in_rectangle(w2, h, m2)
            total = m1 * s1 + m2 * s2
            if total > best_total_side:
                best_total_side = total
                c2_shifted = [(x + w1, y, a, s) for (x, y, a, s) in c2]
                best_squares = c1 + c2_shifted

    for hcut in np.linspace(0.2, 0.8, 5):
        for vcut in np.linspace(0.2, 0.8, 5):
            ws = [vcut, unit - vcut, vcut, unit - vcut]
            hs = [hcut, hcut, unit - hcut, unit - hcut]
            offsets_x = [0, vcut, 0, vcut]
            offsets_y = [0, 0, hcut, hcut]
            areas = [ws[i]*hs[i] for i in range(4)]
            total_area = sum(areas)
            base_counts = [max(1, int(round(n * a / total_area))) for a in areas]
            diff = n - sum(base_counts)
            for i in range(diff):
                base_counts[i % 4] += 1
            for i in range(-diff):
                idx = 3 - (i % 4)
                if base_counts[idx] > 1:
                    base_counts[idx] -= 1
            counts_variants = [base_counts]
            for counts in counts_variants:
                if any(c < 0 for c in counts):
                    continue
                region_squares = []
                total = 0.0
                valid = True
                for i in range(4):
                    w, h = ws[i], hs[i]
                    m = counts[i]
                    s, config = _pack_squares_in_rectangle(w, h, m)
                    if len(config) != m:
                        valid = False
                        break
                    total += m * s
                    ox, oy = offsets_x[i], offsets_y[i]
                    shifted = [(x + ox, y + oy, a, s) for (x, y, a, s) in config]
                    region_squares.extend(shifted)
                if valid and total > best_total_side:
                    best_total_side = total
                    best_squares = region_squares

    return best_total_side, best_squares


def _phyllotaxis_spiral(n):
    """Generate n points in [0,1]x[0,1] using phyllotaxis sunflower spiral."""
    points = []
    for i in range(n):
        # Use golden angle to create nice spacing
        theta = i * math.pi * (3.0 - math.sqrt(5.0))  # golden angle in radians
        r = math.sqrt(i / n)  # radius from 0 to 1
        x = 0.5 + r * math.cos(theta) * 0.5
        y = 0.5 + r * math.sin(theta) * 0.5
        # Clamp to [0,1] (should usually be fine)
        x = max(0.0, min(1.0, x))
        y = max(0.0, min(1.0, y))
        points.append((x, y))
    return points


def _square_corners(cx, cy, angle, side):
    """Return 4 corners of a square given center, angle (full turns), and side length."""
    # angle in radians
    theta = angle * 2.0 * math.pi
    half = side / 2.0
    cos_t = math.cos(theta)
    sin_t = math.sin(theta)
    # corners relative to center: (+- half, +- half) rotated
    corners = []
    for dx, dy in [(-half, -half), (half, -half), (half, half), (-half, half)]:
        x = cx + dx * cos_t - dy * sin_t
        y = cy + dx * sin_t + dy * cos_t
        corners.append((x, y))
    return corners


def _intersect_polygons(poly1, poly2):
    """Check if two convex polygons intersect (including touching).
    Use separating axis theorem for convex polygons."""
    # poly is list of (x,y) points
    def edges(poly):
        n = len(poly)
        for i in range(n):
            p1 = poly[i]
            p2 = poly[(i+1)%n]
            edge = (p2[0]-p1[0], p2[1]-p1[1])
            normal = (-edge[1], edge[0])  # perpendicular
            yield normal
    
    # Check separation along all normals of both polygons
    for poly in [poly1, poly2]:
        for normal in edges(poly):
            # project both polygons onto normal
            min1 = float('inf')
            max1 = -float('inf')
            for p in poly1:
                proj = p[0]*normal[0] + p[1]*normal[1]
                min1 = min(min1, proj)
                max1 = max(max1, proj)
            min2 = float('inf')
            max2 = -float('inf')
            for p in poly2:
                proj = p[0]*normal[0] + p[1]*normal[1]
                min2 = min(min2, proj)
                max2 = max(max2, proj)
            if max1 < min2 - 1e-9 or max2 < min1 - 1e-9:
                return False  # separated
    return True  # no separating axis found -> intersect


def _point_inside_unit_square(x, y, margin=0.0):
    return margin <= x <= 1.0 - margin and margin <= y <= 1.0 - margin


def _square_inside_unit_square(cx, cy, angle, side):
    """Check if the entire square is within [0,1]x[0,1]."""
    corners = _square_corners(cx, cy, angle, side)
    for x, y in corners:
        if not (0.0 <= x <= 1.0 and 0.0 <= y <= 1.0):
            return False
    return True


def _collision_driven_shrink(centers, angles, initial_sides=None):
    """Given centers and angles (list of n tuples each), iteratively shrink squares
    until no overlaps. Returns list of side lengths."""
    n = len(centers)
    if n == 0:
        return []
    
    # Start with large sides (max possible half diagonal to boundary)
    if initial_sides is None:
        sides = []
        for cx, cy in centers:
            # Max distance to boundary along any axis
            max_half = min(cx, 1.0-cx, cy, 1.0-cy)
            # For rotated squares, corner could stick out further: but we start with this and shrink
            sides.append(2.0 * max_half)  # side length
    else:
        sides = list(initial_sides)
    
    # We'll iteratively resolve overlaps by scaling down colliding pairs.
    # Until no overlaps or sides very small.
    changed = True
    max_iter = 100
    iteration = 0
    while changed and iteration < max_iter:
        changed = False
        iteration += 1
        # compute all square polygons
        polys = []
        for i in range(n):
            polys.append(_square_corners(centers[i][0], centers[i][1], angles[i], sides[i]))
        
        # For each pair, if overlap, compute required shrink factor for both to just touch
        for i in range(n):
            for j in range(i+1, n):
                if sides[i] <= 1e-12 or sides[j] <= 1e-12:
                    continue
                # Check bounding circle first for quick rejection
                dx = centers[i][0] - centers[j][0]
                dy = centers[i][1] - centers[j][1]
                dist = math.hypot(dx, dy)
                # max possible radius = side * sqrt(2)/2 = side * 0.707
                max_dist = (sides[i] + sides[j]) * 0.7072
                if dist > max_dist:
                    continue
                # precise collision check
                if _intersect_polygons(polys[i], polys[j]):
                    changed = True
                    # We need to shrink one or both. Simple approach: shrink both proportionally
                    # to their current size until they just touch.
                    # Find factor alpha such that alpha*sides[i], alpha*sides[j] just touch.
                    # We do binary search for alpha, but efficient: compute exact separation distance.
                    # Hard for rotated squares. Use iterative bisection on combined scale.
                    lo = 0.0
                    hi = 1.0
                    for _ in range(15):
                        mid = (lo + hi) / 2.0
                        si = sides[i] * mid
                        sj = sides[j] * mid
                        poly_i = _square_corners(centers[i][0], centers[i][1], angles[i], si)
                        poly_j = _square_corners(centers[j][0], centers[j][1], angles[j], sj)
                        if _intersect_polygons(poly_i, poly_j):
                            hi = mid
                        else:
                            lo = mid
                    # lo is safe (no overlap)
                    scale = lo * 0.999  # slightly less to be safe
                    sides[i] *= scale
                    sides[j] *= scale
                    # after shrinking, recompute polys if needed later; we continue loop
                    # Note: this can cause new overlaps with other squares, hence while loop.
                    
        # Also ensure squares stay inside unit square: shrink those that stick out
        for i in range(n):
            if sides[i] <= 1e-12:
                continue
            # Find max scale such that square is fully inside
            lo = 0.0
            hi = 1.0
            if _square_inside_unit_square(centers[i][0], centers[i][1], angles[i], sides[i]):
                continue
            for _ in range(15):
                mid = (lo + hi) / 2.0
                si = sides[i] * mid
                if _square_inside_unit_square(centers[i][0], centers[i][1], angles[i], si):
                    lo = mid
                else:
                    hi = mid
            sides[i] *= lo * 0.999
    
    return sides


def _local_coordinate_descent(centers, angles, sides, max_iter=200, step_initial=0.05):
    """Improve configuration by small perturbations of centers and angles, accepting if sum increases."""
    n = len(centers)
    best_sum = sum(sides)
    best_centers = [list(c) for c in centers]
    best_angles = list(angles)
    best_sides = list(sides)
    
    # Fixed schedule for perturbations
    for step_factor in [1.0, 0.5, 0.25, 0.1]:
        step = step_initial * step_factor
        improved = True
        iteration = 0
        while improved and iteration < max_iter:
            improved = False
            iteration += 1
            # Try each square one by one
            for i in range(n):
                if best_sides[i] < 1e-9:
                    continue
                # Try small moves: center x,y, angle
                for dx, dy in [(step, 0), (-step, 0), (0, step), (0, -step), (step, step), (-step, step), (step, -step), (-step, -step)]:
                    new_cx = best_centers[i][0] + dx
                    new_cy = best_centers[i][1] + dy
                    if not (0.0 <= new_cx <= 1.0 and 0.0 <= new_cy <= 1.0):
                        continue
                    # Check quickly if square would cross boundary (rough)
                    # Then recompute sides via shrink starting from best_sides
                    test_centers = best_centers[:]
                    test_centers[i] = (new_cx, new_cy)
                    test_angles = best_angles[:]
                    test_sides = _collision_driven_shrink(test_centers, test_angles, initial_sides=best_sides)
                    new_sum = sum(test_sides)
                    if new_sum > best_sum + 1e-12:
                        best_sum = new_sum
                        best_centers = test_centers[:]
                        best_angles = test_angles[:]
                        best_sides = test_sides
                        improved = True
                        # break dx,dy loop and re-evaluate from scratch
                        break
                # angle perturbation
                for da in [-step, step]:
                    new_angle = best_angles[i] + da
                    # keep angle in [0,1)
                    new_angle = new_angle % 1.0
                    test_angles = best_angles[:]
                    test_angles[i] = new_angle
                    test_centers = best_centers[:]
                    test_sides = _collision_driven_shrink(test_centers, test_angles, initial_sides=best_sides)
                    new_sum = sum(test_sides)
                    if new_sum > best_sum + 1e-12:
                        best_sum = new_sum
                        best_centers = test_centers[:]
                        best_angles = test_angles[:]
                        best_sides = test_sides
                        improved = True
                        break
                if improved:
                    break  # restart outer loop because configuration changed
        # continue with smaller step
    
    return best_centers, best_angles, best_sides


def solve(n):
    """
    Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    maximizing sum of side lengths.
    """
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    best_overall_sum = -1.0
    best_squares = None
    
    # 1. Use region splitting method as candidate (fast, often good)
    sum_reg, squares_reg = _best_split_into_regions(n)
    if squares_reg:
        best_overall_sum = sum_reg
        best_squares = squares_reg
    
    # 2. Phyllotaxis spiral + collision shrink + local descent, with random restarts.
    # For small n, we can try several seeds. For larger n, time is limited.
    restarts = max(3, min(15, 30 - n // 2))
    if n > 30:
        restarts = 3
    if n > 45:
        restarts = 1
    
    # Use fixed seed for reproducibility? Random is fine.
    for attempt in range(restarts):
        if attempt == 0:
            centers = _phyllotaxis_spiral(n)
        else:
            # random points with repulsion? Better: random uniform then relax? For speed, just random.
            centers = [(random.random(), random.random()) for _ in range(n)]
        # Initial angles: alternate 0 and 0.125 (45 deg) as heuristic, or random.
        angles = []
        for i in range(n):
            if i % 2 == 0:
                angles.append(0.0)
            else:
                angles.append(0.125)
        # If random restart, maybe random angles
        if attempt > 0:
            angles = [random.random() for _ in range(n)]
        
        # Ensure centers are inside (0,1) with small margin
        centers = [(max(1e-6, min(1.0-1e-6, x)), max(1e-6, min(1.0-1e-6, y))) for x,y in centers]
        
        # Collision-driven shrink
        sides = _collision_driven_shrink(centers, angles)
        
        # Local descent
        centers_opt, angles_opt, sides_opt = _local_coordinate_descent(centers, angles, sides, max_iter=100, step_initial=0.03)
        
        total = sum(sides_opt)
        if total > best_overall_sum + 1e-9:
            best_overall_sum = total
            best_squares = [(cx, cy, a, s) for (cx,cy), a, s in zip(centers_opt, angles_opt, sides_opt)]
    
    # If still no squares, fallback
    if not best_squares:
        s, cfg = _pack_squares_in_rectangle(1.0, 1.0, n)
        best_squares = cfg
    
    # Pad to exactly n
    if len(best_squares) < n:
        best_squares.extend([(0.5, 0.5, 0.0, 0.0)] * (n - len(best_squares)))
    return best_squares[:n]

