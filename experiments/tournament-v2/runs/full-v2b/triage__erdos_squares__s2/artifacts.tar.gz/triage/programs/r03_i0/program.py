import math
import numpy as np
from scipy.optimize import minimize

# Known optimal configurations for small n as atomic tiles
KNOWNS = {
    1: [(0.5, 0.5, 0.0, 1.0)],
    2: [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)],
    3: [(0.33333, 0.5, 0.0, 1/3), (1/3, 0.5, 0.0, 1/3), (2/3, 0.5, 0.0, 1/3)],
    4: [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)],
    5: [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5),
        (0.5, 0.25, 0.0, 0.25)],
    6: [(1/3, 1/3, 0.0, 1/3), (2/3, 1/3, 0.0, 1/3), (0, 2/3, 0.0, 1/3),
        (1/3, 0.0, 0.0, 1/3), (2/3, 1/3, 0.0, 1/3), (0.5, 0.5, 0.0, 1/3)],
}

def pack_grid(n_rows, n_cols, side_by_row=None, region_name=None):
    """
    Build a configuration for n = n_rows * n_cols squares in a grid with equal-side,
    placing each square inside the unit square by dividing rows/cols and tiling.
    """
    squares = []
    h = 1.0 / n_rows
    w = 1.0 / n_cols
    for r in range(n_rows):
        for c in range(n_cols):
            cx = c + w * (1 + 1e-9) / 2
            cy = r + h * (1 + 1e-9) / 2
            if side_by_row is not None and region_name is not None:
                if cx > 1.0 + 1e-6: cx = 1.0 - 1e-9
                if cy > 1.0 + 1e-6: cy = 1.0 - 1e-9
                squares.append((cx, cy, 0.0, min(h, w)))
    return squares

def best_fixed_grid(n):
    """Try all small row/col grids that sum to n squares and return best sum of sides."""
    best_total = 0.0
    best_config = []
    for rows in range(1, int(math.sqrt(n)) + 2):
        for cols in range(1, int(n / rows) + 2):
            if rows * cols == n:
                s = 1.0 / max(rows, cols)
                total = n * s
                if total > best_total:
                    best_total = total
                    side = 1.0 / max(rows, cols)
                    h = 1.0 / rows
                    w = 1.0 / cols
                    config = []
                    for r in range(rows):
                        for c in range(cols):
                            cx = c + w * (1 + 1e-9) / 2
                            cy = r + h * (1 + 1e-9) / 2
                            config.append((cx, cy, 0.0, side))
                    best_config = config
    return best_total, best_config

def atomic_pack(configs_to_try):
    """
    Given a list of (n_target, config) pairs, try to tile the unit square with partitions of n.
    For small n, just return direct known configs.
    For medium n, do cuts and allocate.
    For large n, just use grid.
    """
    total = 0.0
    final = []
    for n_remain in configs_to_try:
        if n_remain in KNOWNS:
            total += sum(s[3] for s in KNOWNS[n_remain])
            final.extend(KNOWNS[n_remain])
        elif n_remain <= 12:
            # Use best fixed grid for these small-medium n
            _, cfg = best_fixed_grid(n_remain)
            total += sum(s[3] for s in cfg)
            final.extend(cfg)
        else:
            # Large n: pack as a dense grid
            rows = int(n_remain ** 0.5) + 1
            cols = max(1, n_remain // rows)
            s = 1.0 / max(rows, cols)
            h = 1.0 / rows
            w = 1.0 / cols
            for r in range(rows):
                for c in range(cols):
                    if len(final) >= n_remain:
                        break
                    if len(final) >= n_remain:
                        break
                    cx = c + w * (1 + 1e-9) / 2
                    cy = r + h * (1 + 1e-9) / 2
                    final.append((cx, cy, 0.0, s))
            total += len(final) * s
    return final, total

def solve(n):
    """
    Return n squares (centre_x, centre_y, angle, side) inside the unit square.
    """
    # If n is in known, return it directly.
    if n in KNOWNS:
        config = KNOWNS[n]
        return config[:n]
    
    # Find best way to partition n into two or three atomic tiles
    # that maximize total side length.
    best_total = 0.0
    best_config = []
    
    # Hardcoded partitions that have been known to perform the best for n in known range
    for part in [(n, n), (math.ceil(n/2), math.floor(n/2))]:
        # Second step: partial partitions, try simple splits into 2 parts that tile the square
        for split in [part[0], part[1]]:  # n_a and n_b
            if split <= n:
                rem = n - split
                if rem <= n and ren >= 0:
                    # Use part1 = best_fixed_grid(split), part2 = grid
                    _, cfg1 = best_fixed_grid(split)
                    s_rest = 1.0 / max(math.ceil(rem), 1)
                    total = rem * s_rest + sum(side for side in cfg1)
                    if total > best_total:
                        best_total = total
                        best_config = list(cfg1)
    
    # Default: grid packing based on sqrt(n)
    rows = int(math.sqrt(n))
    cols = max(1, n // rows)
    s = 1.0 / max(rows, cols)
    for r in range(rows):
        for c in range(cols):
            if len(best_config) >= n:
                break
            if len(best_config) >= n:
                break
            cx = c + (1.0 / cols) * (1 + 1e-9) / 2
            cy = r + (1.0 / rows) * (1 + 1e-9) / 2
            best_config.append((cx, cy, 0.0, s))
    
    return best_config[:n]
