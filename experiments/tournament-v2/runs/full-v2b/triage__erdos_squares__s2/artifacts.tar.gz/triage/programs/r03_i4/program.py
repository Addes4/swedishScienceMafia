import math
import itertools
import random

import numpy as np
from scipy.optimize import minimize

# ----------------------------------------------------------------------------
# Geometry helpers: a square is (cx, cy, angle, side). angle in fraction of
# full turn. Overlap test uses SAT (separating axis theorem) for convex polys.
# ----------------------------------------------------------------------------

def _corners(cx, cy, angle, side):
    a = angle * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * ca - dy * sa
        y = cy + dx * sa + dy * ca
        pts.append((x, y))
    return pts


def _overlap(sq1, sq2):
    """Return True if two squares share interior."""
    s1 = sq1[3]
    s2 = sq2[3]
    if s1 <= 1e-12 or s2 <= 1e-12:
        return False
    p1 = _corners(*sq1)
    p2 = _corners(*sq2)
    # quick bounding circle test
    r1 = s1 * 0.7071067811865476
    r2 = s2 * 0.7071067811865476
    dx = sq1[0] - sq2[0]
    dy = sq1[1] - sq2[1]
    if dx * dx + dy * dy > (r1 + r2) ** 2:
        return False
    # SAT
    for poly in (p1, p2):
        for i in range(4):
            ax = poly[i]
            bx = poly[(i + 1) % 4]
            ex = bx[0] - ax[0]
            ey = bx[1] - ax[1]
            # normal
            nx, ny = -ey, ex
            # project both
            min1 = min(p[0] * nx + p[1] * ny for p in p1)
            max1 = max(p[0] * nx + p[1] * ny for p in p1)
            min2 = min(p[0] * nx + p[1] * ny for p in p2)
            max2 = max(p[0] * nx + p[1] * ny for p in p2)
            if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                return False
    return True


def _inside(cx, cy, angle, side, tol=1e-9):
    for x, y in _corners(cx, cy, angle, side):
        if x < -tol or x > 1 + tol or y < -tol or y > 1 + tol:
            return False
    return True


def _valid_square(sq, others):
    if not _inside(*sq):
        return False
    for o in others:
        if _overlap(sq, o):
            return False
    return True


# ----------------------------------------------------------------------------
# Maximal side given center and angle, respecting existing squares (binary).
# ----------------------------------------------------------------------------

def _max_side_at(cx, cy, angle, others, hi=1.0):
    lo = 0.0
    # first ensure hi is infeasible enough
    if _max_side_at_feasible(cx, cy, angle, hi, others):
        return hi
    for _ in range(40):
        mid = 0.5 * (lo + hi)
        if _max_side_at_feasible(cx, cy, angle, mid, others):
            lo = mid
        else:
            hi = mid
    return lo


def _max_side_at_feasible(cx, cy, angle, s, others):
    if not _inside(cx, cy, angle, s):
        return False
    sq = (cx, cy, angle, s)
    for o in others:
        if _overlap(sq, o):
            return False
    return True


# ----------------------------------------------------------------------------
# Greedy / policy-based placement.
# A "policy" chooses (cx, cy, angle) for the next square; side is then the
# maximal feasible value there.
# We parametrize candidate positions by a set of seeds and pick the best.
# ----------------------------------------------------------------------------

def _candidate_centers(step):
    pts = []
    g = step
    i = 0
    while i * g <= 1.0 + 1e-9:
        j = 0
        while j * g <= 1.0 + 1e-9:
            x = i * g
            y = j * g
            if 0.0 <= x <= 1.0 and 0.0 <= y <= 1.0:
                pts.append((x, y))
            j += 1
        i += 1
    # include some random/perturbed ones for diversity
    rng = random.Random(12345)
    for _ in range(60):
        pts.append((rng.random(), rng.random()))
    return pts


def _place_one_greedy(placed, centers, angles, weight_new):
    """Pick the (c, angle) maximizing weight_new*side + tie-break."""
    best = None
    best_val = -1.0
    for (cx, cy) in centers:
        for ang in angles:
            s = _max_side_at(cx, cy, ang, placed)
            if s <= 0:
                continue
            val = weight_new * s
            if val > best_val:
                best_val = val
                best = (cx, cy, ang, s)
    return best


# ----------------------------------------------------------------------------
# Beam search over sequential placements.
# State: list of placed squares (each with side). Score = sum of sides.
# We expand by trying several candidate next placements, keep top-K beams.
# To keep it tractable, we discretize candidates per step.
# ----------------------------------------------------------------------------

def _coarse_candidates(placed, rng, n_extra=0):
    """Return a list of candidate (cx,cy,angle)."""
    cands = []
    # grid plus corners/edges
    steps = (0.25, 0.2, 0.16666667, 0.125, 0.1)
    seen = set()
    for g in steps:
        k = int(round(1.0 / g))
        for i in range(k + 1):
            for j in range(k + 1):
                key = (round(i * g, 6), round(j * g, 6))
                if key not in seen:
                    seen.add(key)
                    cands.append((i * g, j * g))
    # midpoints of edges and center
    cands += [(0.5, 0.5), (0.0, 0.5), (1.0, 0.5), (0.5, 0.0), (0.5, 1.0),
              (0.5, 0.25), (0.5, 0.75), (0.25, 0.5), (0.75, 0.5)]
    # random perturbations guided by existing squares
    for _ in range(80):
        if placed and rng.random() < 0.5:
            p = rng.choice(placed)
            cx = p[0] + rng.uniform(-0.3, 0.3)
            cy = p[1] + rng.uniform(-0.3, 0.3)
        else:
            cx = rng.random()
            cy = rng.random()
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        cands.append((cx, cy))
    angles = (0.0, 0.125, 0.0625, 0.25, 0.1875, 0.3125, 0.375, 0.4375)
    out = []
    for (cx, cy) in cands:
        for ang in angles:
            out.append((cx, cy, ang))
    if n_extra:
        out = out[:n_extra]
    return out


def _beam_search(n, beam_width=6, seed=0):
    rng = random.Random(seed)
    # beams: list of (placed_list, score)
    beams = [([], 0.0)]
    for step in range(n):
        new_beams = []
        for placed, score in beams:
            # decide how many candidates to try based on step
            cands = _coarse_candidates(placed, rng)
            # evaluate each candidate: maximal side there
            local = []
            for (cx, cy, ang) in cands:
                s = _max_side_at(cx, cy, ang, placed)
                if s > 1e-9:
                    local.append((s, cx, cy, ang))
            if not local:
                # no square can be placed; put a zero square at center
                new_beams.append((placed + [(0.5, 0.5, 0.0, 0.0)], score))
                continue
            # take best few distinct candidates
            local.sort(key=lambda t: -t[0])
            # keep some top by side and some diversity
            selected = local[:beam_width]
            # also try a couple of small ones occasionally to allow future gains
            if len(local) > beam_width:
                selected.append(local[-1])
            for (s, cx, cy, ang) in selected:
                new_beams.append((placed + [(cx, cy, ang, s)], score + s))
        # rank and prune
        new_beams.sort(key=lambda t: -t[1])
        # deduplicate roughly by score
        pruned = []
        for b in new_beams:
            pruned.append(b)
            if len(pruned) >= beam_width * 3:
                break
        beams = pruned[:beam_width]
    best_placed, best_score = max(beams, key=lambda t: t[1])
    return best_placed, best_score


# ----------------------------------------------------------------------------
# Global fine-tune: adjust (cx,cy,angle,side) of all squares jointly with
# gradient-free optimization while keeping feasibility via soft penalty.
# ----------------------------------------------------------------------------

def _feasibility_penalty(squares):
    pen = 0.0
    n = len(squares)
    for i in range(n):
        cx, cy, ang, s = squares[i]
        if s <= 0:
            continue
        # containment
        for (x, y) in _corners(cx, cy, ang, s):
            if x < 0:
                pen += (0 - x) ** 2 * 100
            if x > 1:
                pen += (x - 1) ** 2 * 100
            if y < 0:
                pen += (0 - y) ** 2 * 100
            if y > 1:
                pen += (y - 1) ** 2 * 100
        # overlaps
        for j in range(i + 1, n):
            if _overlap(squares[i], squares[j]):
                pen += 50.0
    return pen


def _refine(squares, iters=80):
    """Gradient-free random perturbation improvement on objective + penalty."""
    n = len(squares)
    if n == 0:
        return squares
    # parameters: cx, cy, angle, side for each square
    best = [list(sq) for sq in squares]
    best_score = sum(best[i][3] for i in range(n)) - _feasibility_penalty([tuple(b) for b in best])

    rng = random.Random(7)
    for it in range(iters):
        cand = [list(b) for b in best]
        # perturb a subset
        k = rng.randint(1, max(1, n))
        for _ in range(k):
            i = rng.randrange(n)
            if rng.random() < 0.5:
                cand[i][0] += rng.gauss(0, 0.02)
            if rng.random() < 0.5:
                cand[i][1] += rng.gauss(0, 0.02)
            if rng.random() < 0.3:
                cand[i][2] += rng.gauss(0, 0.02)
            if rng.random() < 0.7:
                cand[i][3] += rng.gauss(0, 0.02)
            # clamp
            cand[i][0] = min(1.0, max(0.0, cand[i][0]))
            cand[i][1] = min(1.0, max(0.0, cand[i][1]))
            cand[i][2] = cand[i][2] % 1.0
            if cand[i][3] < 0:
                cand[i][3] = 0.0
            if cand[i][3] > 1.0:
                cand[i][3] = 1.0
        cscore = sum(cand[i][3] for i in range(n)) - _feasibility_penalty([tuple(c) for c in cand])
        if cscore > best_score:
            best_score = cscore
            best = cand
    return [tuple(b) for b in best]


def _repair_and_grow(squares, target_n):
    """Ensure exactly target_n squares and good sum; grow sides where possible."""
    squares = list(squares)
    # remove invalid (should not happen)
    valid = []
    for sq in squares:
        if _valid_square(sq, valid):
            valid.append(sq)
    squares = valid
    # fill remaining with maximal squares greedily
    while len(squares) < target_n:
        best = None
        best_s = -1.0
        rng = random.Random(len(squares) * 13 + 1)
        cands = []
        steps = (0.2, 0.16666667, 0.14285714, 0.125, 0.1, 0.08333333)
        for g in steps:
            k = int(round(1.0 / g))
            for i in range(k + 1):
                for j in range(k + 1):
                    cands.append((i * g, j * g))
        for _ in range(200):
            cands.append((rng.random(), rng.random()))
        angles = (0.0, 0.125, 0.0625, 0.25, 0.1875, 0.3125, 0.375)
        for (cx, cy) in cands:
            for ang in angles:
                s = _max_side_at(cx, cy, ang, squares)
                if s > best_s:
                    best_s = s
                    best = (cx, cy, ang, s)
        if best is None:
            squares.append((0.5, 0.5, 0.0, 0.0))
        else:
            squares.append(best)
    # try to enlarge each square
    improved = True
    rounds = 0
    while improved and rounds < 3:
        improved = False
        rounds += 1
        for i in range(len(squares)):
            cx, cy, ang, s = squares[i]
            others = squares[:i] + squares[i + 1:]
            ns = _max_side_at(cx, cy, ang, others, hi=min(1.0, s * 2 + 0.1))
            if ns > s + 1e-6:
                squares[i] = (cx, cy, ang, ns)
                improved = True
    return squares[:target_n]


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_squares = None
    best_score = -1.0

    # Run several beam searches with different seeds and small widths.
    widths = [4, 6, 8]
    if n <= 8:
        widths = [10, 14, 18]
    for w in widths:
        for seed in (0, 1, 2):
            try:
                placed, score = _beam_search(n, beam_width=w, seed=seed * 31 + w)
            except Exception:
                continue
            placed = _repair_and_grow(placed, n)
            placed = _refine(placed, iters=40 if n <= 20 else 25)
            placed = _repair_and_grow(placed, n)
            sc = sum(sq[3] for sq in placed)
            if sc > best_score and len(placed) == n:
                best_score = sc
                best_squares = placed

    if best_squares is None:
        best_squares = _repair_and_grow([], n)

    # Final polishing
    best_squares = _refine(best_squares, iters=100 if n <= 16 else 50)
    best_squares = _repair_and_grow(best_squares, n)

    # Clip / sanitize outputs
    out = []
    for (cx, cy, ang, s) in best_squares:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = float(ang) % 1.0
        s = max(0.0, min(1.0, float(s)))
        out.append((cpp if False else cx, cy, ang, s))
    # Ensure no accidental overlap slips through final tuple conversion.
    return [(float(a), float(b), float(c), float(d)) for (a, b, c, d) in out[:n]]
