import itertools
import math
import numpy as np
from scipy.optimize import minimize, Bounds, NonlinearConstraint
from shapely.geometry import Polygon, Point
from shapely import affinity

# We'll try a sequential placement algorithm:
# 1. Place the first square large, e.g., side=1 in a corner or center.
# 2. For each subsequent square, find the largest empty circle in the available space
#    (using a distance transform approximation on a grid). Place the square inside that
#    circle, oriented to maximize its side length while avoiding overlaps.
# 3. To do this robustly, we'll maintain a "free region" polygon, or use a point-by-point
#    feasibility check via shapely.
#
# Since this is inherently continuous, we discretize search for candidate positions
# using a dense grid, test candidate squares efficiently, and pick the one with maximum side.
# Then we refine the position and angle via local optimization (scipy) for the new square only,
# keeping previous squares fixed.
#
# This approach should adapt to any n and gradually fill the space, often outperforming
# region-partitioning heuristics because it can utilize irregular gaps and rotations.

def _is_feasible(new_square, existing_squares):
    """Check if new_square (cx, cy, angle, side) does not overlap existing_squares.
    Both are lists of tuples (cx, cy, angle, side), angle in full turns.
    Returns True if no overlap (interiors disjoint)."""
    poly_new = _square_to_polygon(*new_square)
    for sq in existing_squares:
        poly_ex = _square_to_polygon(*sq)
        if poly_new.intersects(poly_ex) and not poly_new.touches(poly_ex):
            # Allow touching but not overlapping interiors
            return False
    # Also must be inside unit square [0,1]x[0,1]
    if not _polygon_inside_unit_square(poly_new):
        return False
    return True

def _square_to_polygon(cx, cy, angle, side):
    """Return a shapely Polygon for the square, angle in full turns (0.25 = 90 deg)."""
    half = side / 2.0
    # corners of axis-aligned square centered at origin
    coords = [(-half, -half), (half, -half), (half, half), (-half, half)]
    poly = Polygon(coords)
    # rotate
    angle_deg = angle * 360.0
    poly = affinity.rotate(poly, angle_deg, origin=(0, 0))
    # translate
    poly = affinity.translate(poly, cx, cy)
    return poly

def _polygon_inside_unit_square(poly):
    """Check if polygon is entirely inside [0,1]x[0,1] with a tolerance."""
    unit_square = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
    return unit_square.contains(poly)

def _find_max_side_at_position(cx, cy, angle, existing_squares):
    """Find maximum side length for a square at (cx, cy, angle) without overlapping.
    Uses binary search; returns max side, or 0 if not possible."""
    lo, hi = 0.0, 1.0
    best = 0.0
    for _ in range(30):
        mid = (lo + hi) / 2.0
        if _is_feasible((cx, cy, angle, mid), existing_squares):
            best = mid
            lo = mid
        else:
            hi = mid
    return best

def _local_optimize_square(initial, existing_squares):
    """
    Given an initial feasible square (cx, cy, angle, side),
    locally optimize its size and position/angle to maximize side
    while respecting non-overlap constraints.
    Uses scipy minimize with constraints.
    """
    # Variables: cx, cy, angle, side
    x0 = np.array([initial[0], initial[1], initial[2], initial[3]])
    bounds = Bounds([0, 0, 0, 0], [1, 1, 0.5, 1])  # angle up to 0.5 (180 deg, but square symmetry makes 0.5 identical)

    # We'll use a constraint that ensures non-overlap for each existing square.
    # The overlap is measured by the signed distance between polygons; we want that distance >= 0
    # for all pairs. Could use a signed distance function approximated by sampling points.
    # Simpler: use shapely distance. For non-intersecting polygons, distance >= 0.
    # For intersecting, distance is negative. We'll enforce distance >= 0 for all pairs,
    # but shapely distance is minimum distance, so if distance > -1e-9, accept.
    # It's not smooth but we can try.
    def constraints_factory(sq):
        def constr(x):
            new_poly = _square_to_polygon(x[0], x[1], x[2], x[3])
            other_poly = _square_to_polygon(sq[0], sq[1], sq[2], sq[3])
            return new_poly.distance(other_poly)
        return constr

    cons = []
    for sq in existing_squares:
        cons.append({'type': 'ineq', 'fun': constraints_factory(sq)})

    # Also constraint to keep inside unit square
    def inside_unit(x):
        poly = _square_to_polygon(x[0], x[1], x[2], x[3])
        unit = Polygon([(0,0),(1,0),(1,1),(0,1)])
        return poly.distance(unit.exterior)  # if inside, distance >0? Actually distance to boundary if inside is positive.
        # Shapely distance between polygon and boundary line gives minimal distance to boundary.
        # If interior, it's positive. We'll just use this.
    cons.append({'type': 'ineq', 'fun': inside_unit})

    # Objective: maximize side
    def objective(x):
        return -x[3]

    # Run local optimization
    try:
        res = minimize(objective, x0, bounds=bounds, constraints=cons, method='SLSQP', options={'maxiter': 100, 'ftol': 1e-8})
    except Exception:
        return initial  # fallback

    if res.success:
        side = res.x[3]
        if side > 0:
            return (res.x[0], res.x[1], res.x[2], side)
    return initial

def _search_next_square(existing_squares, grid_size=40, num_angles=8):
    """
    Search over a grid of candidate positions (cx, cy) and angles to find
    the square with the maximum side that can be placed without overlap.
    Then locally refine it. Returns a tuple (cx, cy, angle, side) or None.
    """
    best_square = None
    best_side = 0.0

    xs = np.linspace(0, 1, grid_size)
    ys = np.linspace(0, 1, grid_size)
    angles = np.linspace(0, 0.5, num_angles, endpoint=False)

    for cx in xs:
        for cy in ys:
            for ang in angles:
                # quick feasibility: can we place a tiny square?
                if not _is_feasible((cx, cy, ang, 1e-6), existing_squares):
                    continue
                side = _find_max_side_at_position(cx, cy, ang, existing_squares)
                if side > best_side:
                    best_side = side
                    best_square = (cx, cy, ang, side)

    if best_square is not None and best_side > 0:
        # Refine locally
        refined = _local_optimize_square(best_square, existing_squares)
        # Check if refined is better (should be)
        return refined
    else:
        return None

def solve(n):
    if n <= 0:
        return []
    
    squares = []
    # Place first square optimally: we can put a side=1 square in the unit square
    # but that leaves no room for others. Better: place a square that fills one corner
    # but not entire square to leave gaps? Actually, to maximize sum of sides, we
    # might want many large squares. A sequential greedy may start with side ~0.8 etc.
    # Let's place the first square with side = 0.9 in the center or a corner.
    # We'll search a bit for the best initial square among a few choices.
    best_start = None
    best_sum_so_far = 0.0
    for side0 in [0.9, 0.8, 0.7]:
        # try corners
        for cx0, cy0 in [(0.5, 0.5), (0.0, 0.0), (1.0, 1.0), (0.0, 1.0), (1.0, 0.0)]:
            sq0 = (cx0, cy0, 0.0, side0)
            if _is_feasible(sq0, []):
                squares = [sq0]
                # continue adding
                for _ in range(n-1):
                    new_sq = _search_next_square(squares, grid_size=25, num_angles=6)
                    if new_sq is None:
                        # cannot place more; pad with zero squares
                        break
                    squares.append(new_sq)
                total_side = sum(s[3] for s in squares)
                if total_side > best_sum_so_far:
                    best_sum_so_far = total_side
                    best_start = squares.copy()

    if best_start is not None:
        squares = best_start
    else:
        # fallback: grid packing
        from scipy.optimize import minimize
        # use previous heuristic as fallback
        from math import ceil
        best_s = 0.0
        best_conf = []
        for rows in range(1, n+1):
            cols = int(ceil(n/rows))
            s = min(1.0/cols, 1.0/rows)
            if s > best_s:
                best_s = s
                best_conf = []
                for r in range(rows):
                    for c in range(cols):
                        if len(best_conf) >= n:
                            break
                        cx = (c+0.5)*s
                        cy = (r+0.5)*s
                        best_conf.append((cx, cy, 0.0, s))
                if len(best_conf) >= n:
                    break
        squares = best_conf[:n]

    # Padding to n squares
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
