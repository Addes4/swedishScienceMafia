import numpy as np
from scipy.spatial import ConvexHull
from scipy.optimize import nonlin_lsq
import random

def rectangles_overlap(rects1, rects2):
    """Check if two sets of rotated rectangles overlap."""
    for r1 in rects1:
        for r2 in rects2:
            if do_rectangles_overlap(r1, r2):
                return True
    return False

def do_rectangles_overlap(alloc1, alloc2):
    """Check if two square allocations overlap."""
    s1, s2 = alloc1[3], alloc2[3]
    dx = abs(alloc1[0] - alloc2[0])
    dy = abs(alloc1[1] - alloc2[1])
    if dx < 0.1 and dy < 0.1:
        # centers extremely close, rotate-aware check
        angle1 = alloc1[2]
        angle2 = alloc2[2]
        dangle = min(abs(angle1 - angle2), 1 - abs(angle1 - angle2))
        if dangle > 0:
            return True
        else:
            # axis-aligned case
            half_diag = max(s1, s2) * np.sqrt(2) / 2 + 1e-6
            if abs(dx) < half_diag and abs(dy) < half_diag:
                return True
        return True
    return False

def get_square_boundary(centre_x, centre_y, angle, side):
    """Get 4 corners of square given centre, angle, side."""
    _r, _c = np.pi, np.pi
    if abs(side) < 1e-12:
        return [(centre_x, centre_y), (centre_x, centre_y)]
    
    corners = []
    for i in range(4):
        angle_rad = np.pi / 2 * 2 * i + angle * 2 * np.pi
        x = centre_x + (side / 2) * np.cos(angle_rad)
        y = centre_y + (side / 2) * np.sin(angle_rad)
        corners.append((x, y))
    return corners

def check_overlap_with_line(cx1, cy1, cx2, cy2, sq1, sq2):
    """Find if two squares can be separated by a line. Returns True if separable."""
    # Separation test using support functions
    eps = 1e-9
    for s in sq1:
        for e in sq2:
            w = s[1] - s[0]
            l = w / 2 + eps
            if abs(s[0] - e[0]) < l and abs(s[1] - e[1]) < l:
                return True
    return False

def separate_overlapping_squares(squares, max_iter=50):
    """Apply separation line search to resolve overlaps. Returns modified square list."""
    if len(squares) <= 1:
        return squares
    
    n = len(squares)
    best_valid = True
    
    for iteration in range(max_iter):
        overlapping = True
        for i in range(n):
            for j in range(i + 1, n):
                sq1 = squares[i]
                sq2 = squares[j]
                if do_rectangles_overlap(sq1, sq2):
                    overlapping = True
                    # Push squares apart
                    s1, s2 = sq1[3], sq2[3]
                    max_side = max(s1, s2)
                    cx1, cy1, cx2, cy2 = sq1[0], sq1[1], sq2[0], sq2[1]
                    
                    if abs(cx1 - cx2) > abs(cy1 - cy2):
                        delta = (s1 + s2) / 2
                        factor = 2 * (cx2 - cx1)
                        if factor != 0:
                            sq1[1] -= delta * 0.5 * np.sign(cy1 - cy2)
                            sq2[1] += delta * 0.5 * np.sign(cy1 - cy2)
                    else:
                        delta = (s1 + s2) / 2
                        factor = 2 * (cx2 - cx1)
                        if factor != 0:
                            sq1[0] -= delta * 0.5 * np.sign(cx2 - cx1)
                            sq2[0] += delta * 0.5 * np.sign(cx2 - cx1)
                    
                    # Clamp to unit square
                    sq1[0] = max(0, min(1, sq1[0]))
                    sq1[1] = max(0, min(1, sq1[1]))
                    sq2[0] = max(0, min(1, sq2[0]))
                    sq2[1] = max(0, min(1, sq2[1]))
                    sq1[2], sq2[2] = 0, 0
                    
                    if not do_rectangles_overlap(sq1, sq2):
                        break
                sq2 = sq1[:3] + list(sq2)
                    # optional: better integration
                    else:
                        continue
                        break
        if not overlapping:
            break
    
    return np.array(squares)

def calculate_overlap_area(sq1, sq2, angle1, angle2):
    """Calculate overlap between rotated rectangles."""
    side1, side2 = sq1[3], sq2[3]
    eps = 1e-6
    if side1 < eps or side2 < eps:
        return 0.0
    # Quick bounding box overlap test
    bb1 = np.array([[sq1[0] - side1/2, sq1[1] - side1/2],
                    [sq1[0] + side1/2, sq1[1] + side1/2]])
    bb2 = np.array([[sq2[0] - side2/2, sq2[1] - side2/2],
                    [sq2[0] + side2/2, sq2[1] + side2/2]])
    if np.any(bb1[:,0] > bb2[:,0]) or np.any(bb1[:,1] > bb2[:,1]) \
       or np.any(bb2[:,0] > bb1[:,0]) or np.any(bb2[:,1] > bb1[:,1]):
        return 0.0
    return side1 * side2

def fitness_function(config, n_squares):
    """Calculate fitness: sum of sides minus overlap penalty."""
    if len(config) != n_squares:
        return -1e9
    
    total_side = sum(s[3] for s in config)
    if total_side <= 0:
        return -1e9
    
    weight = 5.0  # penalty weight for overlaps
    
    # Immediate feasibility check
    overlaps = 0
    for i in range(len(config)):
        for j in range(i+1, len(config)):
            overlap = calculate_overlap_area(config[i], config[j], config[i][2], config[j][2])
            if overlap > 1e-4:
                overlaps += 1
    
    if overlaps > 0:
        return total_side - weight * overlaps
    return total_side

def geometric_crossover(parent1, parent2):
    """Create offspring from two parent configurations using geometric insights."""
    n = len(parent1)
    children = []
    
    # Strategy 1: arithmetic mean with angle averaging
    child1 = parent1.copy().astype(float).reshape(-1, 4).copy()
    for i in range(n):
        angle = (parent1[i, 2] + parent2[i, 2]) % 1
        if abs(angle - 0.25) < 1e-6:
            angle = 0.25
        p1 = parent1[i]
        p2 = parent2[i]
        child1[i] = [p1[0] + 0.5*(p2[0]-p1[0]), 
                     p1[1] + 0.5*(p2[1]-p1[1]), 
                     angle,
                     0.5*(p1[3] + p2[3])]
    
    children.append(child1)
    
    # Strategy 2: 25% randomised swap with original angles
    child2 = np.column_stack([parent1[:].copy().reshape(n, 4).copy()])
    for i in range(n):
        angle = parent2[i, 2]
        if abs(angle - 0.125) < 1e-6:  # 45 degrees = 0.125 quarter-turn
            angle = 0.125
        child2[i, 3] = 0.75 * parent1[i, 3] + 0.25 * parent2[i, 3]
    
    children.append(child2)
    
    # Strategy 3: Size inheritance with position blend
    child3 = np.column_stack([parent2[:].copy().reshape(n, 4).copy()])
    for i in range(n):
        angle = (parent1[i, 2] + parent2[i, 2]) % 1
        if abs(angle - 0.125) < 1e-6:
            angle = 0.125
        child3[i, 3] = min(parent1[i, 3], parent2[i, 3])
    
    return children

def mutation_individual(individual, mutation_rate=0.1, seed=42):
    """Apply mutation to individual configuration."""
    if random.random() < mutation_rate:
        angle_mut = random.sample([0.125, 0.25], 1)[0]
        individual[:, 2] = angle_mut
        individual[:, 3] *= random.uniform(0.8, 1.2) + np.random.normal(0, 0.05, individual.shape[0])
    
    random.seed(seed + individual.shape[0])
    return individual

def initialize_population(n_squares, pop_size=100):
    """Initialize population of random valid square configurations."""
    population = []
    for _ in range(pop_size):
        ind = np.zeros((n_squares, 4))
        base_side = 2 / (n_squares + 2)
        ind[:, 3] = np.random.uniform(base_side * 0.5, base_side * 1.5)
        ind[:, 2] = np.random.choice([0.0, 0.125, 0.25], n_squares)
        ind[:, 0] = np.random.uniform(0.1, 0.9, n_squares)
        ind[:, 1] = np.random.uniform(0.1, 0.9, n_squares)
        population.append(ind)
    return np.array(population, dtype=float)

def population_based_learning(population, fitness_func):
    """Adapt rotation pattern based on population fitness."""
    best_score = fitness_func(population)
    rotation_weights = np.zeros(4)  # 0.0, 0.125, 0.25, 0.375
    
    for ind in population:
        angle_counts = np.bincount(np.round(ind[:, 2] * 4))[:, 3*2]
        for a_idx, angle in enumerate([0, 0.125, 0.25]):
            count = np.sum(np.abs(ind[:, 2] - angle) < 0.01)
            rotation_weights[min(a_idx, 3)] += count * (fitness_func(ind) / n_squares)
    
    rotation_weights /= rotation_weights.sum() + 1e-6
    
    return rotation_weights

def main_evolution(n_squares):
    if n_squares == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    pop_size = 80
    max_generations = 200
    
    population_np = initialize_population(n_squares, pop_size)
    
    rotation_weights = population_based_learning(population_np, fitness_function)
    best_individual = None
    best_fitness = -np.inf
    
    for generation in range(max_generations):
        new_pop = []
        for _ in range(pop_size // 5):
            p1 = population_np[np.random.randint(pop_size)]
            p2 = population_np[np.random.randint(pop_size)]
            
            child = np.array(geometric_crossover(p1, p2)[random.randint(0, 2)])
            if random.random() < 0.3:
                child = mutation_individual(child)
            new_pop.append(child)
        
        for i in range(pop_size - len(new_pop) // 10):
            child = population_np[np.random.randint(pop_size)].copy()
            if random.random() < 0.2:
                child = mutation_individual(child)
            new_pop.append(child)
        
        population_np = np.array(new_pop, dtype=float)
        population_np = population_based_learning(population_np, fitness_function)
        
        for ind in population_np:
            ind = separate_overlapping_squares(ind)
            ind = np.clip(ind[:, :2], 0, 1)
            
            if fitness_function(ind, n_squares) > best_fitness:
                best_fitness = fitness_function(ind, n_squares)
                best_individual = ind.copy()
    
    if best_individual is None:
        best_individual = population_np[0].copy()
    
    return best_individual

def solve(n):
    config = main_evolution(n)
    
    result = []
    for i in range(n):
        sx, sy, angle, side = config[i, :4]
        side = max(0, side)
        result.append([[sy], [sy], [angle], [side]])
    
    return result
