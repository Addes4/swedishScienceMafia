import math
import time

import numpy as np
from scipy.optimize import minimize

# ---------- smooth energy ----------

def _energy_vec(x, n, wbox, wpair, beta=50.0, gamma=50.0):
    """Smooth penalty energy; lower = better (negative sum of sides + violations)."""
    P = x.reshape(n, 4)
    cx = P[:, 0]; cy = P[:, 1]; th = P[:, 2]
    s = np.maximum(P[:, 3], 1e-6)
    E = -np.sum(s)

    ang = 2.0 * math.pi * th
    cang = np.cos(ang); sang = np.sin(ang)
    hx = 0.5 * s * (np.abs(cang) + np.abs(sang))

    bx = np.maximum(0.0, hx - cx) ** 2 + np.maximum(0.0, cx + hx - 1.0) ** 2
    by = np.maximum(0.0, hx - cy) ** 2 + np.maximum(0.0, cy + hx - 1.0) ** 2
    E += wbox * (np.sum(bx) + np.sum(by))

    if n > 1:
        dx = cx[:, None] - cx[None, :]
        dy = cy[:, None] - cy[None, :]
        s_i = s[:, None]; s_j = s[None, :]
        th_i = th[:, None]; th_j = th[None, :]

        gaps = np.empty((4, n, n))
        for k, A in enumerate((th_i, th_i + 0.25, th_j, th_j + 0.25)):
            ca = np.cos(2.0 * math.pi * A)
            sa = np.sin(2.0 * math.pi * A)
            D = np.abs(dx * ca + dy * sa)
            Ri = 0.5 * s_i * (np.abs(np.cos(2.0 * math.pi * (th_i - A))) +
                              np.abs(np.sin(2.0 * math.pi * (th_i - A))))
            Rj = 0.5 * s_j * (np.abs(np.cos(2.0 * math.pi * (th_j - A))) +
                              np.abs(np.sin(2.0 * math.pi * (th_j - A))))
            gaps[k] = D - (Ri + Rj)

        M = gaps.max(axis=0)
        # soft max over the 4 separating axes
        SM = M + np.log(np.sum(np.exp(beta * (gaps - M[None, :, :])), axis=0)) / beta
        # softplus(-SM): penalty when separated gap is negative
        sp = np.logaddexp(0.0, -gamma * SM) / gamma
        iu = np.triu_indices(n, 1)
        E += wpair * np.sum(sp[iu] ** 2)
    return E


# ---------- exact feasibility measure ----------

def _measure(P, n):
    """Return (sum_of_sides, max_violation). violation 0 means feasible."""
    cx = P[:, 0]; cy = P[:, 1]; th = P[:, 2]
    s = np.maximum(P[:, 3], 0.0)
    viol = 0.0
    ang = 2.0 * math.pi * th
    hx = 0.5 * s * (np.abs(np.cos(ang)) + np.abs(np.sin(ang)))
    viol = max(viol,
               max(0.0, float(np.max(hx - cx))),
               max(0.0, float(np.max(cx + hx - 1.0))),
               max(0.0, float(np.max(hx - cy))),
               max(0.0, float(np.max(cy + hx - 1.0))))
    if n > 1:
        dx = cx[:, None] - cx[None, :]
        dy = cy[:, None] - cy[None, :]
        s_i = s[:, None]; s_j = s[None, :]
        th_i = th[:, None]; th_j = th[None, :]
        best = np.full((n, n), -1e18)
        for A in (th_i, th_i + 0.25, th_j, th_j + 0.25):
            ca = np.cos(2.0 * math.pi * A)
            sa = np.sin(2.0 * math.pi * A)
            D = np.abs(dx * ca + dy * sa)
            Ri = 0.5 * s_i * (np.abs(np.cos(2.0 * math.pi * (th_i - A))) +
                              np.abs(np.sin(2.0 * math.pi * (th_i - A))))
            Rj = 0.5 * s_j * (np.abs(np.cos(2.0 * math.pi * (th_j - A))) +
                              np.abs(np.sin(2.0 * math.pi * (th_j - A))))
            best = np.maximum(best, D - (Ri + Rj))
        iu = np.triu_indices(n, 1)
        v = best[iu]
        neg = v[v < 0.0]
        if neg.size > 0:
            viol = max(viol, float(-neg.min()))
    return float(np.sum(s)), viol


def _repair(P, n):
    """Shrink/adjust until strictly feasible."""
    P = P.copy()
    for _ in range(80):
        _, viol = _measure(P, n)
        if viol < 1e-10:
            break
        P[:, 3] *= max(0.5, 1.0 - 2.0 * viol)
        ang = 2.0 * math.pi * P[:, 2]
        hx = 0.5 * P[:, 3] * (np.abs(np.cos(ang)) + np.abs(np.sin(ang)))
        hx = np.minimum(hx, 0.5)
        P[:, 0] = np.clip(P[:, 0], hx, 1.0 - hx)
        P[:, 1] = np.clip(P[:, 1], hx, 1.0 - hx)
    return P


def _quality(P, n):
    sm, viol = _measure(P, n)
    return sm - 1e7 * viol


# ---------- main ----------

def solve(n):
    t0 = time.time()
    TBUDGET = 55.0

    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    inits = []

    # axis-aligned grid initialisations
    for rows in range(1, n + 1):
        cols = math.ceil(n / rows)
        s = min(1.0 / cols, 1.0 / rows)
        P = []
        cnt = 0
        for r in range(rows):
            for c in range(cols):
                if cnt >= n:
                    break
                P.append([(c + 0.5) * s, (r + 0.5) * s, 0.0, s])
                cnt += 1
        if cnt == n:
            inits.append(np.array(P, dtype=float))

    # random initialisations
    rng = np.random.default_rng(20240607)
    base = 1.0 / math.sqrt(n)
    if n <= 10:
        nrand = 90
    elif n <= 16:
        nrand = 50
    elif n <= 25:
        nrand = 26
    else:
        nrand = 12
    for _ in range(nrand):
        P = np.zeros((n, 4))
        P[:, 0] = rng.random(n)
        P[:, 1] = rng.random(n)
        P[:, 2] = rng.random(n) * 0.5
        P[:, 3] = base * (0.3 + 0.7 * rng.random(n))
        inits.append(P)

    bestP = None
    bestq = -1e18

    # always keep a guaranteed-feasible grid fallback
    rows = 1
    cols = n
    sfb = min(1.0 / cols, 1.0 / rows)
    Pfb = []
    for i in range(n):
        r = i // cols
        c = i % cols
        Pfb.append([(c + 0.5) * sfb, (r + 0.5) * sfb, 0.0, sfb])
    Pfb = np.array(Pfb, dtype=float)
    bestP = _repair(Pfb, n)
    bestq = _quality(bestP, n)

    idx = 0
    while idx < len(inits) and time.time() - t0 < TBUDGET:
        P0 = inits[idx].copy()
        idx += 1
        x = P0.ravel()

        # graduated penalty stages
        for (wb, wp) in ((1000.0, 1000.0),
                         (20000.0, 20000.0),
                         (200000.0, 200000.0)):
            if time.time() - t0 > TBUDGET:
                break

            def fun(z, wb=wb, wp=wp):
                return _energy_vec(z, n, wb, wp, 50.0, 50.0)

            try:
                res = minimize(fun, x, method="L-BFGS-B",
                               options={"maxiter": 700, "ftol": 1e-12,
                                        "gtol": 1e-9, "maxfun": 50000})
                x = res.x
            except Exception:
                break

        P = _repair(x.reshape(n, 4), n)
        q = _quality(P, n)
        if q > bestq:
            bestq = q
            bestP = P.copy()

    # local polish on the current best
    if bestP is not None and time.time() - t0 < TBUDGET - 3.0:
        x = bestP.ravel()
        for (wb, wp) in ((50000.0, 50000.0), (500000.0, 500000.0)):
            if time.time() - t0 > TBUDGET - 1.0:
                break

            def fun2(z, wb=wb, wp=wp):
                return _energy_vec(z, n, wb, wp, 60.0, 60.0)

            try:
                res = minimize(fun2, x, method="L-BFGS-B",
                               options={"maxiter": 1500, "ftol": 1e-14,
                                        "gtol": 1e-10, "maxfun": 80000})
                x = res.x
            except Exception:
                break
        P = _repair(x.reshape(n, 4), n)
        if _quality(P, n) > bestq:
            bestP = P

    if bestP is None:
        bestP = _repair(Pfb, n)

    # normalise outputs
    bestP[:, 2] = np.mod(bestP[:, 2], 0.5)
    bestP[:, 3] = np.maximum(bestP[:, 3], 0.0)
    bestP = _repair(bestP, n)

    out = []
    for i in range(n):
        cx = float(min(1.0, max(0.0, bestP[i, 0])))
        cy = float(min(1.0, max(0.0, bestP[i, 1])))
        an = float(min(1.0, max(0.0, bestP[i, 2])))
        sd = float(min(1.0, max(0.0, bestP[i, 3])))
        out.append((cx, cy, an, sd))
    return out
