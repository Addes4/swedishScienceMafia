# EVOLVE-BLOCK-START
"""Nonlinear optimisation of all squares with penalty terms.

For each n we (a) generate a good initial guess and (b) refine it with a
penalty-based nonlinear optimiser (scipy).  The objective is the sum of side
lengths; overlaps and out-of-bound placements are penalised.

Method for the initial guess (works for every n):
  * Use the largest k x k grid (k = floor(sqrt(n))) for the bulk.
  * Put the remaining r = n - k^2 squares into the free strip that remains.
    Several patterns are tried and the best (largest total side) is used.
"""

import math
import numpy as np
from scipy.optimize import minimize


def _grid(k):
    """k x k grid filling the unit square."""
    s = 1.0 / k
    out = []
    for i in range(k):
        for j in range(k):
            out.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    return out


def _initial_layouts(n):
    """Yield candidate initial layouts (lists of (cx, cy, angle, side))."""
    k = math.isqrt(n)
    r = n - k * k

    # 1) pure grid, extras as points
    base = _grid(k)
    yield base + [(0.5, 0.5, 0.0, 0.0)] * r

    if k == 0:
        return

    s = 1.0 / k

    # 2) split one grid cell into (r+1) equal squares
    if r > 0:
        cells = [(i, j) for i in range(k) for j in range(k)]
        for (ci, cj) in cells:
            x0, y0 = ci * s, cj * s
            # number of squares per row in the split cell
            # choose a 2-column arrangement when r+1 is not a perfect square
            m = r + 1
            # try to tile the cell with m equal squares as a rectangle
            for cols in range(1, m + 1):
                if m % cols == 0:
                    rows = m // cols
                    cf = 2.0 * cols - 1.0
                    rf = 2.0 * rows - 1.0
                    ss = s / max(cols, rows)
                    lay = []
                    for a in range(cols):
                        for b in range(rows):
                            cx = x0 + (a + 0.5) * ss
                            cy = y0 + (b + 0.5) * ss
                            lay.append((cx, cy, 0.0, ss))
                    rest = [c for c in base if not (abs(c[0] - (x0 + s / 2)) < 1e-12 and
                                                    abs(c[1] - (y0 + s / 2)) < 1e-12)]
                    yield rest + lay
                    break

    # 3) shrink grid slightly, put extra squares in a bottom strip
    if r > 0:
        # Place r squares in a row of height h along one side.
        # Grid occupies [0, 1-h] x [0, 1-h] scaled.
        # Try different h values.
        for h in [s * f for f in (0.5, 0.75, 1.0)]:
            g = 1.0 - h
            if g <= 0:
                continue
            sg = g / k
            lay = []
            for i in range(k):
                for j in range(k):
                    lay.append(((i + 0.5) * sg, (j + 0.5) * sg, 0.0, sg))
            # r squares across the top strip of height h
            w = 1.0 / r
            ss = min(w, h)
            for i in range(r):
                cx = (i + 0.5) * w
                cy = g + h / 2.0
                lay.append((cx, cy, 0.0, ss))
            yield lay

    # 4) equal squares everywhere, side chosen so total area <= 1
    ss = math.sqrt(1.0 / n)
    cols = math.ceil(math.sqrt(n))
    rows = math.ceil(n / cols)
    lay = []
    idx = 0
    for i in range(cols):
        for j in range(rows):
            if idx < n:
                lay.append(((i + 0.5) / cols, (j + 0.5) / rows, 0.0, ss))
                idx += 1
    yield lay


def _objective(x, n, penalty):
    """x is flat length 4n.  Returns -sum(side) + penalty * violations."""
    x = x.reshape(n, 4)
    cx = x[:, 0]
    cy = x[:, 1]
    ang = x[:, 2]
    side = np.abs(x[:, 3])
    half = side / 2.0
    ca = np.cos(2 * np.pi * ang)
    sa = np.sin(2 * np.pi * ang)

    total_side = side.sum()

    # boundary violation: each square must fit in [0,1]^2.
    # extents along x and y
    ex = half * (np.abs(ca) + np.abs(sa))
    ey = half * (np.abs(sa) + np.abs(ca))
    viol = 0.0
    viol += np.sum(np.maximum(0.0, cx - ex - 0.0) ** 2)
    viol += np.sum(np.maximum(0.0, 1.0 - (cx + ex)) ** 2)
    viol += np.sum(np.maximum(0.0, cy - ey - 0.0) ** 2)
    viol += np.sum(np.maximum(0.0, 1.0 - (cy + ey)) ** 2)

    # overlap violation via separating axis theorem (O(n^2))
    # axis-aligned bounding boxes first as a cheap filter
    for i in range(n):
        if side[i] <= 1e-12:
            continue
        for j in range(i + 1, n):
            if side[j] <= 1e-12:
                continue
            # quick reject by bounding circles
            dx = cx[i] - cx[j]
            dy = cy[i] - cy[j]
            rr = half[i] * 1.4143 + half[j] * 1.4143
            if dx * dx + dy * dy > rr * rr:
                continue
            # SAT for two squares
            sep = False
            ax = [ca[i], ca[j], -sa[i], -sa[j]]
            ay = [sa[i], sa[j], ca[i], ca[j]]
            # project both squares onto each axis; if separated -> no overlap
            for k in range(4):
                px = ax[k]
                py = ay[k]
                # projection radius of square i
                ri = half[i] * (abs(px * ca[i] + py * sa[i]) +
                                abs(px * (-sa[i]) + py * ca[i]))
                rj = half[j] * (abs(px * ca[j] + py * sa[j]) +
                                abs(px * (-sa[j]) + py * ca[j]))
                dist = abs(dx * px + dy * py)
                if dist >= ri + rj - 1e-12:
                    sep = True
                    break
            if not sep:
                # overlapping: penalty ~ area of intersection (approx)
                ov = (half[i] + half[j]) * (half[i] + half[j])
                # better: use overlap along axes
                pen = 0.0
                for k in range(4):
                    px = ax[k]
                    py = ay[k]
                    ri = half[i] * (abs(px * ca[i] + py * sa[i]) +
                                    abs(px * (-sa[i]) + py * ca[i]))
                    rj = half[j] * (abs(px * ca[j] + py * sa[j]) +
                                    abs(px * (-sa[j]) + py * ca[j]))
                    dist = abs(dx * px + dy * py)
                    pen += max(0.0, ri + rj - dist)
                viol += pen * pen

    return -total_side + penalty * viol


def _refine(layout, n, penalty=1e3):
    """Run Nelder-Mead / Powell refinement on a layout."""
    x0 = np.array(layout, dtype=float).reshape(-1)
    if x0.size != 4 * n:
        return layout, -sum(s[3] for s in layout)

    def fun(x):
        return _objective(x, n, penalty)

    best = x0.copy()
    best_val = fun(best)

    # several optimisation passes with decreasing penalty
    for p in (penalty, penalty * 0.1, penalty * 0.01):
        def f(x, p=p):
            return _objective(x, n, p)
        try:
            res = minimize(f, best, method='Powell',
                           options={'maxiter': 2000 * n, 'xtol': 1e-6, 'ftol': 1e-8})
            if res.fun < best_val:
                best = res.x
                best_val = res.fun
        except Exception:
            pass

    res_lay = best.reshape(n, 4).tolist()
    # clamp and clean
    out = []
    for (cx, cy, ang, side) in res_lay:
        side = abs(side)
        if side < 1e-9:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        # keep inside bounds conservatively
        ang = ang % 1.0
        c = math.cos(2 * math.pi * ang)
        s = math.sin(2 * math.pi * ang)
        ex = side / 2.0 * (abs(c) + abs(s))
        ey = side / 2.0 * (abs(s) + abs(c))
        cx = min(max(cx, ex), 1.0 - ex)
        cy = min(max(cy, ey), 1.0 - ey)
        # shrink a tiny bit to guarantee no boundary rounding issue
        if ex > 0:
            cx = min(max(cx, ex), 1.0 - ex)
        if ey > 0:
            cy = min(max(cy, ey), 1.0 - ey)
        out.append((cx, cy, ang, side))
    return out, sum(o[3] for o in out)


def solve(n):
    if n <= 0:
        return []
    best = None
    best_score = -1.0

    for layout in _initial_layouts(n):
        # make sure length is n
        if len(layout) != n:
            continue
        refined, sc = _refine(layout, n)
        if sc > best_score:
            best_score = sc
            best = refined

    if best is None:
        k = math.isqrt(n)
        s = 1.0 / k if k > 0 else 0.0
        best = []
        for i in range(k):
            for j in range(k):
                best.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))

    # final safety check: guarantee no overlaps by shrinking if needed
    best = _enforce(best)
    return best[:n]


def _enforce(sqs):
    """Greedily shrink squares to remove any remaining overlaps / boundary issues."""
    sqs = [list(s) for s in sqs]
    for it in range(200):
        changed = False
        # boundary
        for s in sqs:
            cx, cy, ang, side = s
            c = math.cos(2 * math.pi * ang)
            si = math.sin(2 * math.pi * ang)
            ex = side / 2.0 * (abs(c) + abs(si))
            ey = side / 2.0 * (abs(si) + abs(c))
            if cx - ex < -1e-12 or cx + ex > 1 + 1e-12 or cy - ey < -1e-12 or cy + ey > 1 + 1e-12 or ex > 0.5 or ey > 0.5:
                # shrink and recenter
                side = min(side, 1.0)
                s[3] = side * 0.999
                s[0] = min(max(cx, ex), 1.0 - ex) if ex <= 0.5 else 0.5
                s[1] = min(max(cy, ey), 1.0 - ey) if ey <= 0.5 else 0.5
                changed = True
        # overlaps
        m = len(sqs)
        for i in range(m):
            for j in range(i + 1, m):
                if _overlap(sqs[i], sqs[j]):
                    # shrink both slightly
                    sqs[i][3] *= 0.999
                    sqs[j][3] *= 0.999
                    changed = True
        if not changed:
            break
    return [tuple(s) for s in sqs]


def _overlap(a, b):
    """True if two squares share interior (within tolerance)."""
    if a[3] <= 1e-12 or b[3] <= 1e-12:
        return False
    ca = math.cos(2 * math.pi * a[2]); sa = math.sin(2 * math.pi * a[2])
    cb = math.cos(2 * math.pi * b[2]); sb = math.sin(2 * math.pi * b[2])
    dx = a[0] - b[0]; dy = a[1] - b[1]
    ha = a[3] / 2.0; hb = b[3] / 2.0
    for (px, py) in ((ca, sa), (-sa, ca), (cb, sb), (-sb, cb)):
        ra = ha * (abs(px * ca + py * sa) + abs(px * (-sa) + py * ca))
        rb = hb * (abs(px * cb + py * sb) + abs(px * (-sb) + py * cb))
        d = abs(dx * px + dy * py)
        if d >= ra + rb - 1e-9:
            return False
    return True


# EVOLVE-BLOCK-END
