import math
import random
import numpy as np

def solve(n):
    """
    Place n squares inside the unit square, with disjoint interiors, 
    maximizing the sum of side lengths.
    
    Uses a physics-inspired packing algorithm:
    1. Start with random positions and small side lengths.
    2. Apply repulsion forces between squares and from walls.
    3. Gradually grow squares until packing becomes tight.
    4. Fine-tune with simulated annealing.
    """
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    # Parameters
    max_iterations = 5000
    growth_rate = 1.001  # Slow growth
    damping = 0.95
    force_magnitude = 0.01
    min_side = 0.001
    
    # Initialize squares
    # Start with small squares at random positions
    squares = []
    for _ in range(n):
        # Random position, avoiding edges initially
        cx = random.uniform(0.1, 0.9)
        cy = random.uniform(0.1, 0.9)
        angle = random.uniform(0, 1)  # Rotation as fraction of full turn
        side = 0.05  # Start small
        squares.append([cx, cy, angle, side])
    
    # Convert to numpy array for faster computation
    squares = np.array(squares)
    
    def get_corners(cx, cy, angle, side):
        """Get the 4 corners of a square given center, angle (fraction of full turn), side length."""
        theta = angle * 2 * math.pi
        half = side / 2
        # Corners relative to center (unrotated)
        corners_rel = np.array([
            [-half, -half],
            [half, -half],
            [half, half],
            [-half, half]
        ])
        # Rotation matrix
        cos_t = math.cos(theta)
        sin_t = math.sin(theta)
        rot = np.array([[cos_t, -sin_t], [sin_t, cos_t]])
        # Rotate and translate
        corners = np.dot(corners_rel, rot.T) + np.array([cx, cy])
        return corners
    
    def overlap_sat(corners1, corners2):
        """Check if two convex polygons (squares) overlap using Separating Axis Theorem."""
        # For squares, we need to check all edges of both squares as potential separating axes
        polygons = [corners1, corners2]
        
        for poly_idx in range(2):
            poly = polygons[poly_idx]
            for i in range(4):
                # Edge from corner i to i+1
                edge = poly[(i+1)%4] - poly[i]
                # Perpendicular axis
                axis = np.array([-edge[1], edge[0]])
                axis_norm = np.linalg.norm(axis)
                if axis_norm < 1e-12:
                    continue
                axis = axis / axis_norm
                
                # Project both polygons onto axis
                proj1 = np.dot(polygons[0], axis)
                proj2 = np.dot(polygons[1], axis)
                
                min1, max1 = np.min(proj1), np.max(proj1)
                min2, max2 = np.min(proj2), np.max(proj2)
                
                # If projections don't overlap, polygons don't overlap
                if max1 < min2 - 1e-10 or max2 < min1 - 1e-10:
                    return False
        
        return True
    
    def check_boundaries(corners):
        """Check if square is entirely within [0,1]x[0,1]. Returns True if inside."""
        return np.all(corners >= 0) and np.all(corners <= 1)
    
    def compute_overlap_penetration(corners1, corners2):
        """Compute minimum penetration depth between two overlapping squares."""
        if not overlap_sat(corners1, corners2):
            return 0.0, np.array([0.0, 0.0])
        
        polygons = [corners1, corners2]
        min_penetration = float('inf')
        min_axis = np.array([0.0, 0.0])
        
        for poly_idx in range(2):
            poly = polygons[poly_idx]
            for i in range(4):
                edge = poly[(i+1)%4] - poly[i]
                axis = np.array([-edge[1], edge[0]])
                axis_norm = np.linalg.norm(axis)
                if axis_norm < 1e-12:
                    continue
                axis = axis / axis_norm
                
                proj1 = np.dot(polygons[0], axis)
                proj2 = np.dot(polygons[1], axis)
                
                min1, max1 = np.min(proj1), np.max(proj1)
                min2, max2 = np.min(proj2), np.max(proj2)
                
                # Overlap amount
                overlap = min(max1, max2) - max(min1, min2)
                if overlap < min_penetration:
                    min_penetration = overlap
                    # Direction from poly1 to poly2 (center diff)
                    direction = np.mean(polygons[1], axis=0) - np.mean(polygons[0], axis=0)
                    if np.dot(direction, axis) < 0:
                        min_axis = -axis
                    else:
                        min_axis = axis
        
        return min_penetration, min_axis
    
    # Main simulation loop
    for iteration in range(max_iterations):
        # Compute forces on each square
        forces = np.zeros((n, 2))
        
        # Repulsion between squares
        max_force = 0.0
        for i in range(n):
            corners_i = get_corners(squares[i, 0], squares[i, 1], 
                                   squares[i, 2], squares[i, 3])
            
            # Wall forces
            # Simple spring from walls based on penetration
            for corner in corners_i:
                # Right wall
                if corner[0] > 1.0:
                    forces[i, 0] -= force_magnitude * (corner[0] - 1.0) * 10
                # Left wall
                if corner[0] < 0.0:
                    forces[i, 0] += force_magnitude * (-corner[0]) * 10
                # Top wall
                if corner[1] > 1.0:
                    forces[i, 1] -= force_magnitude * (corner[1] - 1.0) * 10
                # Bottom wall
                if corner[1] < 0.0:
                    forces[i, 1] += force_magnitude * (-corner[1]) * 10
            
            for j in range(i+1, n):
                corners_j = get_corners(squares[j, 0], squares[j, 1],
                                       squares[j, 2], squares[j, 3])
                
                if overlap_sat(corners_i, corners_j):
                    penetration, axis = compute_overlap_penetration(corners_i, corners_j)
                    if penetration > 0:
                        # Repulsive force proportional to penetration
                        force = force_magnitude * penetration * 20
                        forces[i] -= axis * force
                        forces[j] += axis * force
                        max_force = max(max_force, force)
        
        # Apply forces (update positions)
        squares[:, :2] += forces * damping
        
        # Clamp to rough bounds first (will be fixed by wall forces)
        # squares[:, 0] = np.clip(squares[:, 0], 0.0, 1.0)
        # squares[:, 1] = np.clip(squares[:, 1], 0.0, 1.0)
        
        # Gently grow squares if forces are small (system is relaxed)
        if iteration % 10 == 0 and max_force < force_magnitude * 5:
            # Try to grow
            for i in range(n):
                old_side = squares[i, 3]
                new_side = old_side * growth_rate
                
                # Check if growing would cause issues
                corners_new = get_corners(squares[i, 0], squares[i, 1],
                                         squares[i, 2], new_side)
                
                # Check boundaries
                if not check_boundaries(corners_new):
                    continue
                
                # Check overlap with others
                valid = True
                for j in range(n):
                    if i != j:
                        corners_j = get_corners(squares[j, 0], squares[j, 1],
                                              squares[j, 2], squares[j, 3])
                        if overlap_sat(corners_new, corners_j):
                            valid = False
                            break
                
                if valid:
                    squares[i, 3] = new_side
        
        # Occasionally add small random perturbations to escape local minima
        if iteration % 100 == 0:
            for i in range(n):
                squares[i, 0] += random.uniform(-0.001, 0.001)
                squares[i, 1] += random.uniform(-0.001, 0.001)
                squares[i, 2] += random.uniform(-0.005, 0.005)
        
        # Project back into unit square
        for i in range(n):
            corners = get_corners(squares[i, 0], squares[i, 1],
                                 squares[i, 2], squares[i, 3])
            # Find shift needed to bring back inside
            shift_x = 0.0
            shift_y = 0.0
            
            min_x = np.min(corners[:, 0])
            max_x = np.max(corners[:, 0])
            min_y = np.min(corners[:, 1])
            max_y = np.max(corners[:, 1])
            
            if min_x < 0:
                shift_x = -min_x
            elif max_x > 1:
                shift_x = 1 - max_x
            
            if min_y < 0:
                shift_y = -min_y
            elif max_y > 1:
                shift_y = 1 - max_y
            
            squares[i, 0] += shift_x
            squares[i, 1] += shift_y
    
    # Final validation and cleanup
    result = []
    for i in range(n):
        cx, cy, angle, side = squares[i]
        angle = angle % 1.0
        
        # Ensure side is not too small
        if side < 0:
            side = 0.0
        
        # Clamp to [0,1]
        cx = np.clip(cx, 0.0, 1.0)
        cy = np.clip(cy, 0.0, 1.0)
        
        result.append((float(cx), float(cy), float(angle), float(side)))
    
    return result

# Test if called directly
if __name__ == "__main__":
    for test_n in [5, 6, 7, 8, 11, 12, 13, 14, 15]:
        sol = solve(test_n)
        total = sum(s[3] for s in sol)
        print(f"n={test_n}: sum={total:.6f}")
