# Research notebook: erdos_squares

Ranker `jev`, tiers ['deepseek-ai/DeepSeek-V4-Pro:deepinfra', 'deepseek-ai/DeepSeek-V4.1-Flash:deepinfra', 'Qwen/Qwen3.5-9B:together'], swap rate 0.15, initial score 0.856172.

## Round 1

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 0 | Instead of using a grid of equal squares, try packing squares of different sizes using a greedy or optimal rectangle packing algorithm adapted for squares, such | 0.57 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.378571 |
| 3 | Given n, try splitting the unit square into a few rectangular subregions, optimally pack squares (possibly rotated) into each region, and combine—this structura | 0.52 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | improved | 0.939260 |
| 1 | Use a physics-inspired simulation (e.g., force-directed or rigid body dynamics) that pushes squares apart and gradually shrinks or grows them to maximize total  | 0.50 | middle | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | not_better | 0.254267 |
| 2 | Formulate the problem as a nonlinear optimization: represent each square by its center, rotation, and side length; use a black-box optimizer (like differential  | 0.48 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.193955 |
| 5 | Use a recursive or dynamic programming approach that partitions the unit square by placing one large square optimally, then recurses on the remaining L-shaped o | 0.43 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 4 | Employ a “square-packing via circle-packing” transformation: first pack n circles of varying radii to maximize sum of diameters (or side equivalents) inside the | 0.33 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 1: **0.939260** (spent $0.03)

## Round 2

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 3 | Exploit symmetry and known optimal small-n configurations as building blocks: for larger n, compose the unit square by tiling it with known optimal packings for | 0.28 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.934611 |
| 4 | Apply a "growing disks" phyllotaxis spiral to place n seed points, then compute the largest non-overlapping square centered at each point via a collision-driven | 0.23 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | not_better | 0.939260 |
| 0 | Formulate as a mixed-integer quadratically constrained program (MIQCP) with binary variables for relative square orderings and continuous variables for centers, | 0.16 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.779087 |
| 1 | Use a maximal independent set approach on a continuous packing graph: generate a large set of candidate square placements (positions, rotations, sizes) via rand | 0.11 | middle | deepseek-ai/DeepSeek-V4-Pro:deepinfra (swapped) | not_better | 0.054569 |
| 2 | Adapt the Kepler conjecture/Tóth packings to the unit square by tiling the square with polygonal cells and assigning one square per cell, optimizing cell shapes | 0.10 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 5 | Use an evolutionary algorithm that directly mutates sequences of (x,y,angle,side) with custom geometric crossover operators, applying a fast overlap removal rou | 0.09 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 2: **0.939260** (spent $0.11)

## Round 3

| # | idea | rank key | planned | ran on | outcome | score |
|---|---|---|---|---|---|---|
| 1 | Use a sequential addition approach: start with one large square optimally placed in a corner, then iteratively insert the next square by solving a small local N | 0.15 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | invalid | 0.000000 |
| 2 | Apply a "shrink-and-shake" iterative refinement: begin with n identical axis-aligned squares forming a tight grid, then repeatedly apply random perturbations to | 0.13 | favourite | deepseek-ai/DeepSeek-V4-Pro:deepinfra | no_code |  |
| 4 | Employ a machine-learned policy: train a neural network (via reinforcement learning on many random n) to output placement actions (center, angle, side) sequenti | 0.04 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | invalid | 0.000000 |
| 5 | Construct a continuous relaxation where squares are modeled as soft particles with a repulsive potential that approximates the non-overlap constraint; perform c | 0.03 | middle | deepseek-ai/DeepSeek-V4.1-Flash:deepinfra | not_better | 0.917009 |
| 0 | Perfectly match the best known configs up to n=8 by enumerating known optimal small-n layouts (from literature) and using them as atomic tiles, then for larger  | -0.00 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |
| 3 | Leverage the fact that the sum of side lengths is the L1 norm of the side-length vector; reformulate the packing as a convex maximization over the space of non- | -0.01 | long_shot | Qwen/Qwen3.5-9B:together | invalid | 0.000000 |

Best after round 3: **0.939260** (spent $0.15)

