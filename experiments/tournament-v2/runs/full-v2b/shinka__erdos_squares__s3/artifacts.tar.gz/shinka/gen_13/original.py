# EVOLVE-BLOCK-START
"""Adaptive grid-subdivision packing: start from a k x k grid and recursively
split cells to host the extra squares, maximizing the sum of side lengths."""
import math


def _best_split(cell_side, m):
    """Return (gain, layout) for hosting m squares inside a cell of given side.

    layout is a list of (dx, dy, side) relative to the cell's lower-left corner.
    We try splitting the cell into an a x b grid (a*b >= m) and recursively
    refine leftover cells.  To keep it tractable we only consider a,b in {1,2,3}
    and recurse shallowly.
    """
    if m <= 0:
        return 0.0, []
    # Try all small grids a x b with a*b >= m
    best_gain = -1.0
    best_layout = None
    for a in range(1, 4):
        for b in range(1, 4):
            if a * b < m:
                continue
            s = cell_side / max(a, b)
            # fill first m cells of the a x b grid
            layout = []
            count = 0
            for i in range(a):
                for j in range(b):
                    if count >= m:
                        break
                    dx = (i + 0.5) * (cell_side / a)
                    dy = (j + 0.5) * (cell_side / b)
                    # actual square side limited by both dimensions
                    ss = min(cell_side / a, cell_side / b)
                    layout.append((dx, dy, ss))
                    count += 1
                if count >= m:
                    break
            gain = sum(l[2] for l in layout)
            if gain > best_gain:
                best_gain = gain
                best_layout = layout
    return best_gain, best_layout


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    # Choose base grid size k = floor(sqrt(n))
    k = math.isqrt(n)
    base_side = 1.0 / k

    # We have k*k cells.  n - k*k extra squares must be hosted by subdividing cells.
    extras = n - k * k

    # Distribute extras among cells greedily: each cell can be split into a 2x2
    # grid to host up to 3 extra squares (replacing 1 with 4), gaining
    # 4*(base_side/2) - base_side = base_side per split.  We split cells until
    # we can host all extras, preferring splits that give the most gain.
    # For larger extras we allow 3x3 splits too.
    cells = [(0.0, 0.0, base_side, 1)]  # (x0, y0, side, multiplicity)
    # Start with the full k x k grid as individual cells
    cells = []
    for i in range(k):
        for j in range(k):
            cells.append([i * base_side, j * base_side, base_side])

    # Greedily refine cells to absorb extras.  A cell of side s split into an
    # a x a grid yields a^2 squares of side s/a; net gain in side sum is
    # a^2*(s/a) - s = (a-1)*s, and it adds a^2 - 1 squares.
    remaining = extras
    while remaining > 0:
        # pick the cell with the largest side to split (max gain per square)
        cells.sort(key=lambda c: -c[2])
        c = cells[0]
        x0, y0, s = c
        # decide split factor a: maximize gain while adding >= remaining?  Use
        # smallest a such that a*a - 1 >= remaining, else a=3.
        a = 2
        while a * a - 1 < remaining and a < 4:
            a += 1
        if a * a - 1 < remaining:
            a = 3
        cells.pop(0)
        sub = s / a
        for i in range(a):
            for j in range(a):
                cells.append([x0 + i * sub, y0 + j * sub, sub])
        remaining -= (a * a - 1)

    # Build result: place all cells, then pad with zero-size squares if needed.
    result = []
    for x0, y0, s in cells:
        result.append((x0 + s / 2.0, y0 + s / 2.0, 0.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END
