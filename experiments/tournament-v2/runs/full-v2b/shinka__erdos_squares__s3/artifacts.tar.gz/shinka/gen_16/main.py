# EVOLVE-BLOCK-START
"""Recursive guillotine partition optimizer for packing squares in the unit square.

Approach:
- Build a guillotine partition of [0,1]^2 into exactly n rectangles.
- At each step, split one rectangle into an a x b grid of sub-rectangles,
  choosing the split that maximizes the marginal sum of inscribed square sides
  per added rectangle.
- Inscribe the largest axis-aligned square in each leaf rectangle.
- Run a local improvement phase that tries alternative splits and small
  ratio perturbations, keeping any improvement.

This is a fundamentally different search from fixed-grid constructions:
it explores arbitrary integer splits and uses a gain-per-square criterion,
with a local optimizer on top.
"""
import math
import random


def _square_sum(rects):
    """Sum of min(w, h) over rectangles."""
    return sum(min(r[2], r[3]) for r in rects)


def _split_rect(rect, a, b):
    """Split rect (x, y, w, h) into an a x b grid of sub-rectangles."""
    x, y, w, h = rect
    sw = w / a
    sh = h / b
    out = []
    for i in range(a):
        for j in range(b):
            out.append((x + i * sw, y + j * sh, sw, sh))
    return out


def _greedy_partition(n):
    """Greedily build a guillotine partition of the unit square into n rects."""
    rects = [(0.0, 0.0, 1.0, 1.0)]
    # Number of extra rects we still need
    need = n - 1
    while need > 0:
        best = None
        best_gain_per = -1.0
        best_idx = -1
        for idx, r in enumerate(rects):
            w, h = r[2], r[3]
            base = min(w, h)
            # Try splits a x b with a*b - 1 <= need (can't overshoot need)
            # and a*b >= 2
            for a in range(1, 5):
                for b in range(1, 5):
                    if a * b < 2:
                        continue
                    added = a * b - 1
                    if added > need:
                        continue
                    sub = _split_rect(r, a, b)
                    new_sum = _square_sum(sub)
                    gain = new_sum - base
                    if gain <= 0:
                        continue
                    gp = gain / added
                    if gp > best_gain_per + 1e-12:
                        best_gain_per = gp
                        best = (idx, a, b)
                        best_idx = idx
        if best is None:
            # Fallback: split the largest rectangle into 2x2
            idx = max(range(len(rects)), key=lambda i: rects[i][2] * rects[i][3])
            best = (idx, 2, 2)
        idx, a, b = best
        r = rects.pop(idx)
        rects.extend(_split_rect(r, a, b))
        need -= (a * b - 1)
    return rects


def _find_adjacent(cand, i):
    """Return list of indices j whose rect shares a full edge with cand[i]."""
    x, y, w, h = cand[i]
    out = []
    for k in range(len(cand)):
        if k == i:
            continue
        x2, y2, w2, h2 = cand[k]
        # Vertical adjacency (same x span, touching in y)
        if abs(x2 - x) < 1e-9 and abs(w2 - w) < 1e-9:
            if abs(y2 - (y + h)) < 1e-9 or abs(y - (y2 + h2)) < 1e-9:
                out.append(k)
                continue
        # Horizontal adjacency (same y span, touching in x)
        if abs(y2 - y) < 1e-9 and abs(h2 - h) < 1e-9:
            if abs(x2 - (x + w)) < 1e-9 or abs(x - (x2 + w2)) < 1e-9:
                out.append(k)
    return out


def _try_structural_move(cand, n, rng):
    """Try a topology-level mutation: pick a rectangular group of leaves
    (two or three adjacent leaves forming a rectangle) and re-split their
    union into a different grid of the same leaf count.

    Returns (new_cand, new_score) or (None, None) if no improvement found.
    """
    if len(cand) < 2:
        return None, None
    # Choose a seed leaf and try to grow a rectangle from it.
    i = rng.randrange(len(cand))
    x0, y0, w0, h0 = cand[i]
    # Try group sizes 2, 3, 4 (2x2) which are common topologies.
    for (ga, gb) in [(1, 2), (2, 1), (1, 3), (3, 1), (2, 2), (3, 3)]:
        k_target = ga * gb
        if k_target > len(cand):
            continue
        # Guess a union rectangle: use w0 * ga, h0 * gb (or vice versa)
        for (uw, uh) in [(w0 * ga, h0 * gb), (w0 * gb, h0 * ga)]:
            ux, uy = x0, y0
            # Candidate union rectangle
            # Collect all leaves fully contained in [ux, ux+uw] x [uy, uy+uh]
            group = []
            ok = True
            for k, (xx, yy, ww, hh) in enumerate(cand):
                if ux - 1e-9 <= xx and xx + ww <= ux + uw + 1e-9 and \
                   uy - 1e-9 <= yy and yy + hh <= uy + uh + 1e-9:
                    group.append(k)
                elif not (xx + ww <= ux + 1e-9 or xx >= ux + uw - 1e-9 or
                          yy + hh <= uy + 1e-9 or yy >= uy + uh - 1e-9):
                    ok = False
                    break
            if not ok or len(group) != k_target:
                continue
            # Try alternative splits of the union with same leaf count.
            alternatives = []
            for (aa, bb) in [(1, 2), (2, 1), (1, 3), (3, 1), (2, 2), (3, 3), (1, 4), (4, 1)]:
                if aa * bb == k_target:
                    alternatives.append((aa, bb))
            for (aa, bb) in alternatives:
                sub = _split_rect((ux, uy, uw, uh), aa, bb)
                new_cand = [c for k, c in enumerate(cand) if k not in group]
                new_cand.extend(sub)
                if len(new_cand) != n:
                    continue
                ns = _square_sum(new_cand)
                return new_cand, ns
    return None, None


def _try_ratio_refine(cand, n, rng):
    """Perturb a split ratio between two adjacent rects sharing a common edge,
    keeping the union rectangle fixed.  This refines continuous parameters."""
    if len(cand) < 2:
        return None, None
    i = rng.randrange(len(cand))
    adj = _find_adjacent(cand, i)
    if not adj:
        return None, None
    j = adj[rng.randrange(len(adj))]
    x, y, w, h = cand[i]
    x2, y2, w2, h2 = cand[j]
    # Determine union and split axis
    ux = min(x, x2); uy = min(y, y2)
    uw = max(x + w, x2 + w2) - ux
    uh = max(y + h, y2 + h2) - uy
    # Vertical split (same x span, split in y) or horizontal split (same y span)
    if abs(x2 - x) < 1e-9 and abs(w2 - w) < 1e-9:
        # split along y: fraction t of union height for rect i
        t = h / uh if uh > 0 else 0.5
        delta = rng.uniform(-0.15, 0.15)
        t = min(0.95, max(0.05, t + delta))
        new_i = (x, y, w, uh * t)
        new_j = (x, y + uh * t, w, uh * (1.0 - t))
    elif abs(y2 - y) < 1e-9 and abs(h2 - h) < 1e-9:
        t = w / uw if uw > 0 else 0.5
        delta = rng.uniform(-0.15, 0.15)
        t = min(0.95, max(0.05, t + delta))
        new_i = (x, y, uw * t, h)
        new_j = (x + uw * t, y, uw * (1.0 - t), h)
    else:
        return None, None
    new_cand = list(cand)
    new_cand[i] = new_i
    new_cand[j] = new_j
    ns = _square_sum(new_cand)
    return new_cand, ns


def _local_improve(rects, n, iters=400, seed=12345):
    """Improve the partition using topology-level moves and ratio refinement.

    Mutation schedule depends on n: for small n we favour structural moves
    (which explore topology), for larger n we favour ratio refinement.
    """
    rng = random.Random(seed)
    best = list(rects)
    best_score = _square_sum(best)
    # n-dependent schedule
    if n <= 10:
        p_struct = 0.60
    elif n <= 12:
        p_struct = 0.40
    else:
        p_struct = 0.25
    for _ in range(iters):
        cand = list(best)
        if rng.random() < p_struct:
            new_cand, ns = _try_structural_move(cand, n, rng)
        else:
            new_cand, ns = _try_ratio_refine(cand, n, rng)
        if new_cand is not None and ns is not None and ns > best_score + 1e-12:
            best = new_cand
            best_score = ns
        # Occasionally accept equal-score moves to escape plateaus
        elif new_cand is not None and ns is not None and rng.random() < 0.05:
            best = new_cand
            best_score = ns
    return best, best_score


def _direct_grid_candidates(n):
    """Try direct k x k grids for k around sqrt(n)."""
    results = []
    for k in range(1, int(math.isqrt(n)) + 4):
        if k * k < n:
            continue
        side = 1.0 / k
        rects = []
        count = 0
        for i in range(k):
            for j in range(k):
                if count >= n:
                    break
                rects.append((i * side, j * side, side, side))
                count += 1
            if count >= n:
                break
        if len(rects) == n:
            results.append(rects)
    return results


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_rects = None
    best_score = -1.0

    # Candidate 1: direct grids
    for rects in _direct_grid_candidates(n):
        sc = _square_sum(rects)
        if sc > best_score:
            best_score = sc
            best_rects = rects

    # Candidate 2: greedy guillotine partition
    rects = _greedy_partition(n)
    sc = _square_sum(rects)
    if sc > best_score:
        best_score = sc
        best_rects = rects

    # Candidate 3: local improvement on the greedy partition
    improved, isc = _local_improve(rects, n, iters=600, seed=999)
    if isc > best_score:
        best_score = isc
        best_rects = improved

    # Candidate 4: local improvement on the direct grid
    if best_rects is not None and len(best_rects) == n:
        improved2, isc2 = _local_improve(best_rects, n, iters=300, seed=42)
        if isc2 > best_score:
            best_score = isc2
            best_rects = improved2

    # Convert rectangles to squares (inscribe largest square in each rect)
    result = []
    for x, y, w, h in best_rects:
        s = min(w, h)
        cx = x + w / 2.0
        cy = y + h / 2.0
        result.append((cx, cy, 0.0, s))

    # Pad if needed (shouldn't happen)
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END