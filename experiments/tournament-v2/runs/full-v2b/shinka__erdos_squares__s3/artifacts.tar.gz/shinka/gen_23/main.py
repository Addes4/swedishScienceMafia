# EVOLVE-BLOCK-START
"""Hybrid guillotine + structured-candidate optimizer for packing squares.

Combines:
- Direct k x k grids, subdivided grids, and strip partitions as seeds.
- A greedy guillotine partition based on marginal gain per added rectangle.
- A structural/ratio local search that re-splits adjacent rectangular groups
  and refines split ratios, with plateau escape.

This explores both structured topologies (grids, strips, subdivisions) and
arbitrary guillotine topologies, then polishes the best with local search.
"""
import math
import random


def _square_sum(rects):
    """Sum of min(w, h) over rectangles."""
    return sum(min(r[2], r[3]) for r in rects)


def _split_rect(rect, a, b):
    """Split rect (x, y, w, h) into an a x b grid of sub-rectangles."""
    x, y, w, h = rect
    sw = w / a
    sh = h / b
    out = []
    for i in range(a):
        for j in range(b):
            out.append((x + i * sw, y + j * sh, sw, sh))
    return out


def _greedy_partition(n):
    """Greedily build a guillotine partition of the unit square into n rects."""
    rects = [(0.0, 0.0, 1.0, 1.0)]
    need = n - 1
    while need > 0:
        best = None
        best_gain_per = -1.0
        for idx, r in enumerate(rects):
            w, h = r[2], r[3]
            base = min(w, h)
            for a in range(1, 5):
                for b in range(1, 5):
                    if a * b < 2:
                        continue
                    added = a * b - 1
                    if added > need:
                        continue
                    sub = _split_rect(r, a, b)
                    new_sum = _square_sum(sub)
                    gain = new_sum - base
                    if gain <= 0:
                        continue
                    gp = gain / added
                    if gp > best_gain_per + 1e-12:
                        best_gain_per = gp
                        best = (idx, a, b)
        if best is None:
            idx = max(range(len(rects)), key=lambda i: rects[i][2] * rects[i][3])
            best = (idx, 2, 2)
        idx, a, b = best
        r = rects.pop(idx)
        rects.extend(_split_rect(r, a, b))
        need -= (a * b - 1)
    return rects


def _find_adjacent(cand, i):
    """Return list of indices j whose rect shares a full edge with cand[i]."""
    x, y, w, h = cand[i]
    out = []
    for k in range(len(cand)):
        if k == i:
            continue
        x2, y2, w2, h2 = cand[k]
        if abs(x2 - x) < 1e-9 and abs(w2 - w) < 1e-9:
            if abs(y2 - (y + h)) < 1e-9 or abs(y - (y2 + h2)) < 1e-9:
                out.append(k)
                continue
        if abs(y2 - y) < 1e-9 and abs(h2 - h) < 1e-9:
            if abs(x2 - (x + w)) < 1e-9 or abs(x - (x2 + w2)) < 1e-9:
                out.append(k)
    return out


def _try_structural_move(cand, n, rng):
    """Try a topology-level mutation on a rectangular group of leaves."""
    if len(cand) < 2:
        return None, None
    i = rng.randrange(len(cand))
    x0, y0, w0, h0 = cand[i]
    for (ga, gb) in [(1, 2), (2, 1), (1, 3), (3, 1), (2, 2), (3, 3)]:
        k_target = ga * gb
        if k_target > len(cand):
            continue
        for (uw, uh) in [(w0 * ga, h0 * gb), (w0 * gb, h0 * ga)]:
            ux, uy = x0, y0
            group = []
            ok = True
            for k, (xx, yy, ww, hh) in enumerate(cand):
                if ux - 1e-9 <= xx and xx + ww <= ux + uw + 1e-9 and \
                   uy - 1e-9 <= yy and yy + hh <= uy + uh + 1e-9:
                    group.append(k)
                elif not (xx + ww <= ux + 1e-9 or xx >= ux + uw - 1e-9 or
                          yy + hh <= uy + 1e-9 or yy >= uy + uh - 1e-9):
                    ok = False
                    break
            if not ok or len(group) != k_target:
                continue
            alternatives = []
            for (aa, bb) in [(1, 2), (2, 1), (1, 3), (3, 1), (2, 2),
                             (3, 3), (1, 4), (4, 1)]:
                if aa * bb == k_target:
                    alternatives.append((aa, bb))
            for (aa, bb) in alternatives:
                sub = _split_rect((ux, uy, uw, uh), aa, bb)
                new_cand = [c for k, c in enumerate(cand) if k not in group]
                new_cand.extend(sub)
                if len(new_cand) != n:
                    continue
                ns = _square_sum(new_cand)
                return new_cand, ns
    return None, None


def _try_ratio_refine(cand, n, rng):
    """Perturb a split ratio between two adjacent rects sharing a common edge."""
    if len(cand) < 2:
        return None, None
    i = rng.randrange(len(cand))
    adj = _find_adjacent(cand, i)
    if not adj:
        return None, None
    j = adj[rng.randrange(len(adj))]
    x, y, w, h = cand[i]
    x2, y2, w2, h2 = cand[j]
    ux = min(x, x2); uy = min(y, y2)
    uw = max(x + w, x2 + w2) - ux
    uh = max(y + h, y2 + h2) - uy
    if abs(x2 - x) < 1e-9 and abs(w2 - w) < 1e-9:
        t = h / uh if uh > 0 else 0.5
        delta = rng.uniform(-0.15, 0.15)
        t = min(0.95, max(0.05, t + delta))
        new_i = (x, y, w, uh * t)
        new_j = (x, y + uh * t, w, uh * (1.0 - t))
    elif abs(y2 - y) < 1e-9 and abs(h2 - h) < 1e-9:
        t = w / uw if uw > 0 else 0.5
        delta = rng.uniform(-0.15, 0.15)
        t = min(0.95, max(0.05, t + delta))
        new_i = (x, y, uw * t, h)
        new_j = (x + uw * t, y, uw * (1.0 - t), h)
    else:
        return None, None
    new_cand = list(cand)
    new_cand[i] = new_i
    new_cand[j] = new_j
    ns = _square_sum(new_cand)
    return new_cand, ns


def _local_improve(rects, n, iters=400, seed=12345):
    """Improve the partition using topology moves and ratio refinement."""
    rng = random.Random(seed)
    best = list(rects)
    best_score = _square_sum(best)
    if n <= 10:
        p_struct = 0.60
    elif n <= 12:
        p_struct = 0.40
    else:
        p_struct = 0.25
    for _ in range(iters):
        cand = list(best)
        if rng.random() < p_struct:
            new_cand, ns = _try_structural_move(cand, n, rng)
        else:
            new_cand, ns = _try_ratio_refine(cand, n, rng)
        if new_cand is not None and ns is not None:
            if ns > best_score + 1e-12:
                best = new_cand
                best_score = ns
            elif rng.random() < 0.05:
                best = new_cand
                best_score = ns
    return best, best_score


def _direct_grid_candidates(n):
    """Try direct k x k grids for k around sqrt(n)."""
    results = []
    for k in range(1, int(math.isqrt(n)) + 4):
        if k * k < n:
            continue
        side = 1.0 / k
        rects = []
        count = 0
        for i in range(k):
            for j in range(k):
                if count >= n:
                    break
                rects.append((i * side, j * side, side, side))
                count += 1
            if count >= n:
                break
        if len(rects) == n:
            results.append(rects)
    return results


def _subdivide_candidates(n):
    """k x k grids with one cell subdivided into an a x b grid, then drop
    the smallest cells until exactly n remain."""
    results = []
    for k in range(1, int(math.isqrt(n)) + 3):
        if k * k > n:
            continue
        base = 1.0 / k
        cells = [(i * base, j * base, base, base) for i in range(k) for j in range(k)]
        for a in (2, 3, 4):
            x0, y0, w0, h0 = cells[0]
            sub_w = w0 / a
            sub_h = h0 / a
            new_cells = list(cells[1:])
            for i in range(a):
                for j in range(a):
                    new_cells.append((x0 + i * sub_w, y0 + j * sub_h, sub_w, sub_h))
            while len(new_cells) > n:
                idx = min(range(len(new_cells)),
                          key=lambda t: min(new_cells[t][2], new_cells[t][3]))
                new_cells.pop(idx)
            if len(new_cells) == n:
                results.append(new_cells)
        for a in (2, 3):
            for b in (2, 3):
                if a == b:
                    continue
                x0, y0, w0, h0 = cells[0]
                sub_w = w0 / a
                sub_h = h0 / b
                new_cells = list(cells[1:])
                for i in range(a):
                    for j in range(b):
                        new_cells.append((x0 + i * sub_w, y0 + j * sub_h, sub_w, sub_h))
                while len(new_cells) > n:
                    idx = min(range(len(new_cells)),
                              key=lambda t: min(new_cells[t][2], new_cells[t][3]))
                    new_cells.pop(idx)
                if len(new_cells) == n:
                    results.append(new_cells)
    return results


def _strip_candidates(n):
    """Partition into m horizontal (or vertical) strips with balanced counts."""
    results = []
    for m in range(1, n + 1):
        base = n // m
        rem = n % m
        counts = [base + (1 if i < rem else 0) for i in range(m)]
        if any(c == 0 for c in counts):
            continue
        h = 1.0 / m
        rects = []
        y = 0.0
        for i, c in enumerate(counts):
            w = 1.0 / c
            for j in range(c):
                rects.append((j * w, y, w, h))
            y += h
        if len(rects) == n:
            results.append(rects)
    for m in range(1, n + 1):
        base = n // m
        rem = n % m
        counts = [base + (1 if i < rem else 0) for i in range(m)]
        if any(c == 0 for c in counts):
            continue
        w = 1.0 / m
        rects = []
        x = 0.0
        for i, c in enumerate(counts):
            h = 1.0 / c
            for j in range(c):
                rects.append((x, j * h, w, h))
            x += w
        if len(rects) == n:
            results.append(rects)
    return results


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_rects = None
    best_score = -1.0

    # Structured seeds: direct grids, subdivided grids, strip partitions.
    for rects in _direct_grid_candidates(n):
        sc = _square_sum(rects)
        if sc > best_score:
            best_score = sc
            best_rects = rects

    for rects in _subdivide_candidates(n):
        sc = _square_sum(rects)
        if sc > best_score:
            best_score = sc
            best_rects = rects

    for rects in _strip_candidates(n):
        sc = _square_sum(rects)
        if sc > best_score:
            best_score = sc
            best_rects = rects

    # Greedy guillotine seed.
    greedy_rects = _greedy_partition(n)
    sc = _square_sum(greedy_rects)
    if sc > best_score:
        best_score = sc
        best_rects = greedy_rects

    # Polish the greedy partition.
    improved, isc = _local_improve(greedy_rects, n, iters=600, seed=999)
    if isc > best_score:
        best_score = isc
        best_rects = improved

    # Polish the best-so-far with several seeds.
    if best_rects is not None and len(best_rects) == n:
        for iters, seed in [(500, 42), (400, 7), (400, 12345), (300, 2024),
                            (300, 555), (200, 31337)]:
            improved2, isc2 = _local_improve(best_rects, n, iters=iters, seed=seed)
            if isc2 > best_score:
                best_score = isc2
                best_rects = improved2

    # Convert rectangles to squares (inscribe largest square in each rect).
    result = []
    for x, y, w, h in best_rects:
        s = min(w, h)
        cx = x + w / 2.0
        cy = y + h / 2.0
        result.append((cx, cy, 0.0, s))

    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END
