# EVOLVE-BLOCK-START
"""Guillotine-based packing: recursively split rectangles to maximize sum of square sides."""
import math
from functools import lru_cache

def _guillotine_pack(n, w, h, depth=0):
    """
    Return (best_sum, list_of_squares) for packing n squares into a w x h rectangle.
    Each square is (cx, cy, side) relative to the rectangle's lower-left corner.
    Uses guillotine splits: split rectangle into two sub-rectangles.
    """
    if n <= 0:
        return 0.0, []
    if n == 1:
        s = min(w, h)
        return s, [(w/2, h/2, s)]
    
    # Base case: grid packing when depth is too large or n is small
    if depth > 4 or n <= 4:
        # Try grid: find a,b with a*b >= n maximizing sum
        best_sum = -1.0
        best_layout = None
        for a in range(1, n+1):
            for b in range(1, n+1):
                if a*b < n:
                    continue
                # Use a x b grid, but only fill n cells
                sx = w / a
                sy = h / b
                s = min(sx, sy)
                # Fill first n cells
                layout = []
                count = 0
                for i in range(a):
                    for j in range(b):
                        if count >= n:
                            break
                        cx = (i + 0.5) * sx
                        cy = (j + 0.5) * sy
                        layout.append((cx, cy, s))
                        count += 1
                    if count >= n:
                        break
                total = sum(l[2] for l in layout)
                if total > best_sum:
                    best_sum = total
                    best_layout = layout
        return best_sum, best_layout
    
    best_sum = -1.0
    best_layout = None
    
    # Try all possible horizontal splits: split into two rectangles
    # Left gets i squares, right gets n-i squares
    for i in range(1, n):
        # Try several split positions
        for frac in [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8]:
            w1 = w * frac
            w2 = w * (1 - frac)
            sum1, layout1 = _guillotine_pack(i, w1, h, depth+1)
            sum2, layout2 = _guillotine_pack(n-i, w2, h, depth+1)
            total = sum1 + sum2
            if total > best_sum:
                best_sum = total
                # Adjust layout2 x-coordinates
                layout2_adj = [(cx + w1, cy, s) for cx, cy, s in layout2]
                best_layout = layout1 + layout2_adj
    
    # Try all possible vertical splits
    for i in range(1, n):
        for frac in [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8]:
            h1 = h * frac
            h2 = h * (1 - frac)
            sum1, layout1 = _guillotine_pack(i, w, h1, depth+1)
            sum2, layout2 = _guillotine_pack(n-i, w, h2, depth+1)
            total = sum1 + sum2
            if total > best_sum:
                best_sum = total
                # Adjust layout2 y-coordinates
                layout2_adj = [(cx, cy + h1, s) for cx, cy, s in layout2]
                best_layout = layout1 + layout2_adj
    
    return best_sum, best_layout

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    
    # For small n, use guillotine packing on unit square
    if n <= 20:
        best_sum, layout = _guillotine_pack(n, 1.0, 1.0, depth=0)
        # Convert to required format: (centre_x, centre_y, angle, side)
        result = []
        for cx, cy, s in layout:
            # Ensure within [0,1]
            cx = max(0.0, min(1.0, cx))
            cy = max(0.0, min(1.0, cy))
            result.append((cx, cy, 0.0, s))
        # Pad with zero-size squares if needed
        while len(result) < n:
            result.append((0.5, 0.5, 0.0, 0.0))
        return result[:n]
    
    # For larger n, use optimized grid with local refinement
    k = math.isqrt(n)
    base_side = 1.0 / k
    cells = []
    for i in range(k):
        for j in range(k):
            cells.append([i * base_side, j * base_side, base_side])
    
    extras = n - k * k
    remaining = extras
    
    # Greedy refinement: split largest cells
    while remaining > 0:
        cells.sort(key=lambda c: -c[2])
        x0, y0, s = cells[0]
        # Try split factors 2, 3, 4
        best_a = 2
        best_gain = -1
        for a in range(2, 5):
            if a*a - 1 <= remaining or a == 4:
                gain = (a*a - 1) * (s / a)  # approximate gain
                if gain > best_gain:
                    best_gain = gain
                    best_a = a
        a = best_a
        cells.pop(0)
        sub = s / a
        for i in range(a):
            for j in range(a):
                cells.append([x0 + i * sub, y0 + j * sub, sub])
        remaining -= (a*a - 1)
    
    result = []
    for x0, y0, s in cells:
        result.append((x0 + s/2, y0 + s/2, 0.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END
