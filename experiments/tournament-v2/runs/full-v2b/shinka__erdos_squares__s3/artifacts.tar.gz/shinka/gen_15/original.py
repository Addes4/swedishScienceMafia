# EVOLVE-BLOCK-START
"""Recursive guillotine partition optimizer for packing squares in the unit square.

Approach:
- Build a guillotine partition of [0,1]^2 into exactly n rectangles.
- At each step, split one rectangle into an a x b grid of sub-rectangles,
  choosing the split that maximizes the marginal sum of inscribed square sides
  per added rectangle.
- Inscribe the largest axis-aligned square in each leaf rectangle.
- Run a local improvement phase that tries alternative splits and small
  ratio perturbations, keeping any improvement.

This is a fundamentally different search from fixed-grid constructions:
it explores arbitrary integer splits and uses a gain-per-square criterion,
with a local optimizer on top.
"""
import math
import random


def _square_sum(rects):
    """Sum of min(w, h) over rectangles."""
    return sum(min(r[2], r[3]) for r in rects)


def _split_rect(rect, a, b):
    """Split rect (x, y, w, h) into an a x b grid of sub-rectangles."""
    x, y, w, h = rect
    sw = w / a
    sh = h / b
    out = []
    for i in range(a):
        for j in range(b):
            out.append((x + i * sw, y + j * sh, sw, sh))
    return out


def _greedy_partition(n):
    """Greedily build a guillotine partition of the unit square into n rects."""
    rects = [(0.0, 0.0, 1.0, 1.0)]
    # Number of extra rects we still need
    need = n - 1
    while need > 0:
        best = None
        best_gain_per = -1.0
        best_idx = -1
        for idx, r in enumerate(rects):
            w, h = r[2], r[3]
            base = min(w, h)
            # Try splits a x b with a*b - 1 <= need (can't overshoot need)
            # and a*b >= 2
            for a in range(1, 5):
                for b in range(1, 5):
                    if a * b < 2:
                        continue
                    added = a * b - 1
                    if added > need:
                        continue
                    sub = _split_rect(r, a, b)
                    new_sum = _square_sum(sub)
                    gain = new_sum - base
                    if gain <= 0:
                        continue
                    gp = gain / added
                    if gp > best_gain_per + 1e-12:
                        best_gain_per = gp
                        best = (idx, a, b)
                        best_idx = idx
        if best is None:
            # Fallback: split the largest rectangle into 2x2
            idx = max(range(len(rects)), key=lambda i: rects[i][2] * rects[i][3])
            best = (idx, 2, 2)
        idx, a, b = best
        r = rects.pop(idx)
        rects.extend(_split_rect(r, a, b))
        need -= (a * b - 1)
    return rects


def _local_improve(rects, n, iters=400, seed=12345):
    """Try to improve the partition by re-splitting rectangles or tweaking ratios."""
    rng = random.Random(seed)
    best = list(rects)
    best_score = _square_sum(best)
    for _ in range(iters):
        cand = list(best)
        # Pick a random rectangle
        i = rng.randrange(len(cand))
        x, y, w, h = cand[i]
        # Try replacing it with an a x b grid, but we must keep n rectangles.
        # We need to remove some other rectangles to compensate, or merge.
        # Simpler: try a small perturbation of the rectangle's dimensions by
        # adjusting its neighbors.  Instead, try a 2-step: split this rect into
        # a x b and merge a*b-1 other rects (pick smallest).
        a = rng.choice([2, 3])
        b = rng.choice([2, 3])
        added = a * b - 1
        if added >= len(cand):
            continue
        # Pick `added` smallest rectangles to merge into one that covers them.
        # To keep it simple and valid, we instead try a different strategy:
        # pick two adjacent rectangles and re-split their union.
        # Find a rectangle that shares an edge with cand[i].
        j = -1
        for k in range(len(cand)):
            if k == i:
                continue
            x2, y2, w2, h2 = cand[k]
            # Check vertical adjacency (same x range, touching in y)
            if abs(x2 - x) < 1e-9 and abs(w2 - w) < 1e-9:
                if abs(y2 - (y + h)) < 1e-9 or abs(y - (y2 + h2)) < 1e-9:
                    j = k
                    break
            # Horizontal adjacency
            if abs(y2 - y) < 1e-9 and abs(h2 - h) < 1e-9:
                if abs(x2 - (x + w)) < 1e-9 or abs(x - (x2 + w2)) < 1e-9:
                    j = k
                    break
        if j < 0:
            continue
        # Union rectangle
        x2, y2, w2, h2 = cand[j]
        ux = min(x, x2)
        uy = min(y, y2)
        uw = max(x + w, x2 + w2) - ux
        uh = max(y + h, y2 + h2) - uy
        # Re-split union into (a, b) grid, replacing the two rects
        # But this changes count by a*b - 2.  We need net change 0, so a*b = 2.
        # So only 1x2 or 2x1 splits, which just re-divides the union differently.
        # Try both orientations.
        for aa, bb in [(1, 2), (2, 1)]:
            sub = _split_rect((ux, uy, uw, uh), aa, bb)
            new_cand = [c for k, c in enumerate(cand) if k != i and k != j]
            new_cand.extend(sub)
            if len(new_cand) == n:
                ns = _square_sum(new_cand)
                if ns > best_score + 1e-12:
                    best = new_cand
                    best_score = ns
                    break
        # Also try a global "rebalance": pick two sibling rects and swap sizes
        if rng.random() < 0.3 and len(cand) >= 2:
            i2 = rng.randrange(len(cand))
            if i2 != i:
                x2, y2, w2, h2 = cand[i2]
                # Try re-splitting both as a combined 1x2 or 2x1
                # (only if they form a rectangle)
                ux = min(x, x2); uy = min(y, y2)
                uw = max(x + w, x2 + w2) - ux
                uh = max(y + h, y2 + h2) - uy
                if abs(uw * uh - (w * h + w2 * h2)) < 1e-9:
                    for aa, bb in [(1, 2), (2, 1)]:
                        sub = _split_rect((ux, uy, uw, uh), aa, bb)
                        new_cand = [c for k, c in enumerate(cand) if k != i and k != i2]
                        new_cand.extend(sub)
                        if len(new_cand) == n:
                            ns = _square_sum(new_cand)
                            if ns > best_score + 1e-12:
                                best = new_cand
                                best_score = ns
                                break
    return best, best_score


def _direct_grid_candidates(n):
    """Try direct k x k grids for k around sqrt(n)."""
    results = []
    for k in range(1, int(math.isqrt(n)) + 4):
        if k * k < n:
            continue
        side = 1.0 / k
        rects = []
        count = 0
        for i in range(k):
            for j in range(k):
                if count >= n:
                    break
                rects.append((i * side, j * side, side, side))
                count += 1
            if count >= n:
                break
        if len(rects) == n:
            results.append(rects)
    return results


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_rects = None
    best_score = -1.0

    # Candidate 1: direct grids
    for rects in _direct_grid_candidates(n):
        sc = _square_sum(rects)
        if sc > best_score:
            best_score = sc
            best_rects = rects

    # Candidate 2: greedy guillotine partition
    rects = _greedy_partition(n)
    sc = _square_sum(rects)
    if sc > best_score:
        best_score = sc
        best_rects = rects

    # Candidate 3: local improvement on the greedy partition
    improved, isc = _local_improve(rects, n, iters=600, seed=999)
    if isc > best_score:
        best_score = isc
        best_rects = improved

    # Candidate 4: local improvement on the direct grid
    if best_rects is not None and len(best_rects) == n:
        improved2, isc2 = _local_improve(best_rects, n, iters=300, seed=42)
        if isc2 > best_score:
            best_score = isc2
            best_rects = improved2

    # Convert rectangles to squares (inscribe largest square in each rect)
    result = []
    for x, y, w, h in best_rects:
        s = min(w, h)
        cx = x + w / 2.0
        cy = y + h / 2.0
        result.append((cx, cy, 0.0, s))

    # Pad if needed (shouldn't happen)
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END