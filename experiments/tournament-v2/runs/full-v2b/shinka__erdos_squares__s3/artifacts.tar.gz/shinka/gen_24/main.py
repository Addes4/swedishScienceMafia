# EVOLVE-BLOCK-START
"""Guillotine-cut packing optimizer with rotation-aware leaves.

Structural changes vs. the previous version:
  * Leaves carry a rotation flag; a rotated leaf in a w x h rectangle gets
    side = min(w, h) / sqrt(2), allowing 45-degree placements.
  * The tree is stored as a flat list of nodes so mutations are O(1) index
    edits rather than recursive tuple rebuilds. This lets the annealer run
    many more iterations inside the time budget.
  * Two-phase search: randomized restarts to explore topologies, then
    simulated annealing on the best candidate to refine ratios, orientations
    and rotation flags.
  * The axis-aligned grid is always evaluated first and acts as a floor.
  * NEW: a deterministic (k x k)-grid-with-2x2-merges constructor is added
    as a Phase-0 candidate.  For n = k^2 - m, we merge m cells into 2x2
    blocks (each block counts as one square of side 2/k), which reproduces
    the structured optima for residue classes like n = 12, 14, 15.
"""
import math
import random


SQRT2 = math.sqrt(2.0)


def _leaf_side(w, h, rotated):
    m = w if w < h else h
    if rotated:
        return m / SQRT2
    return m


def _eval_tree(nodes, x, y, w, h, out):
    """Evaluate the flat-tree. nodes[i] is either:
        ('leaf', rotated)
        ('split', orient, ratio, left_idx, right_idx)
    Returns total side sum."""
    stack = [(0, x, y, w, h)]
    total = 0.0
    while stack:
        idx, cx0, cy0, cw, ch = stack.pop()
        node = nodes[idx]
        if node[0] == 0:  # leaf
            rotated = node[1]
            s = _leaf_side(cw, ch, rotated)
            out.append((cx0 + cw * 0.5, cy0 + ch * 0.5,
                        0.25 if rotated else 0.0, s))
            total += s
        else:
            _, orient, ratio, li, ri = node
            if orient == 0:  # vertical cut
                wl = cw * ratio
                stack.append((li, cx0, cy0, wl, ch))
                stack.append((ri, cx0 + wl, cy0, cw - wl, ch))
            else:  # horizontal cut
                hl = ch * ratio
                stack.append((li, cx0, cy0, cw, hl))
                stack.append((ri, cx0, cy0 + hl, cw, ch - hl))
    return total


def _make_flat_tree(n_leaves, rng):
    """Build a flat guillotine tree with exactly n_leaves leaves."""
    nodes = []

    def rec(k):
        if k == 1:
            nodes.append((0, rng.random() < 0.5))
            return len(nodes) - 1
        k_left = rng.randint(1, k - 1)
        orient = rng.randint(0, 1)
        ratio = rng.uniform(0.2, 0.8)
        my_idx = len(nodes)
        nodes.append(None)
        li = rec(k_left)
        ri = rec(k - k_left)
        nodes[my_idx] = (1, orient, ratio, li, ri)
        return my_idx
    rec(n_leaves)
    return nodes


def _internal_indices(nodes):
    return [i for i, nd in enumerate(nodes) if nd is not None and nd[0] == 1]


def _leaf_indices(nodes):
    return [i for i, nd in enumerate(nodes) if nd is not None and nd[0] == 0]


def _mutate(nodes, rng):
    r = rng.random()
    if r < 0.60:
        internals = _internal_indices(nodes)
        if not internals:
            return False
        i = rng.choice(internals)
        _, orient, ratio, li, ri = nodes[i]
        if rng.random() < 0.75:
            ratio = ratio + rng.gauss(0, 0.10)
            if ratio < 0.06:
                ratio = 0.06
            elif ratio > 0.94:
                ratio = 0.94
            nodes[i] = (1, orient, ratio, li, ri)
        else:
            nodes[i] = (1, 1 - orient, ratio, li, ri)
        return True
    else:
        leaves = _leaf_indices(nodes)
        if not leaves:
            return False
        i = rng.choice(leaves)
        _, rotated = nodes[i]
        nodes[i] = (0, not rotated)
        return True


def _score(nodes):
    out = []
    return _eval_tree(nodes, 0.0, 0.0, 1.0, 1.0, out)


def _anneal(nodes, rng, iters):
    cur_score = _score(nodes)
    best_nodes = [nd for nd in nodes]
    best_score = cur_score
    T0, T1 = 0.08, 0.0005
    last_improve = 0
    reheat_period = max(1, iters // 4)
    for it in range(iters):
        T = T0 * (T1 / T0) ** (it / float(iters))
        if it - last_improve > reheat_period:
            T = max(T, 0.5 * T0)
            last_improve = it
        cand = list(nodes)
        if not _mutate(cand, rng):
            continue
        cs = _score(cand)
        if cs >= cur_score or rng.random() < math.exp((cs - cur_score) / max(T, 1e-9)):
            nodes = cand
            cur_score = cs
            if cs > best_score:
                best_score = cs
                best_nodes = list(cand)
                last_improve = it
    return best_nodes, best_score


def _grid_fallback(n):
    """Redistributing grid: try several (rows, cols) layouts."""
    if n <= 0:
        return [], 0.0
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)], 1.0

    best = None
    best_score = -1.0
    for c in range(1, n + 1):
        r = n // c
        p = n - r * c
        if r < 1:
            continue
        if p == 0:
            cell_w = 1.0 / c
            cell_h = 1.0 / r
            side = min(cell_w, cell_h)
            squares = [((i + 0.5) * cell_w, (j + 0.5) * cell_h, 0.0, side)
                       for j in range(r) for i in range(c)]
            score = side * n
        else:
            H = 1.0 / (r + 1)
            side_full = min(1.0 / c, H)
            side_part = min(1.0 / p, H)
            score = side_full * (r * c) + side_part * p
            squares = []
            for j in range(r):
                for i in range(c):
                    squares.append(((i + 0.5) / c, (j + 0.5) * H, 0.0, side_full))
            for i in range(p):
                squares.append(((i + 0.5) / p, (r + 0.5) * H, 0.0, side_part))
        if score > best_score:
            best_score = score
            best = squares

    squares = best if best is not None else [(0.5, 0.5, 0.0, 0.0)] * n
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n], float(best_score)


def _merge_candidates(k, m, max_patterns=400):
    """Enumerate up to `max_patterns` valid patterns of m disjoint 2x2
    merges inside a k x k cell grid.  A pattern is a set of top-left
    cell coordinates (r, c) with r, c in [0, k-2]; merges must be
    disjoint (no shared cell).  Returns list of lists of (r, c)."""
    if m <= 0:
        return [[]]
    if k < 2:
        return []
    # Candidate top-left positions.
    positions = [(r, c) for r in range(k - 1) for c in range(k - 1)]
    # We'll do a randomized/ordered DFS with a cap on the number of
    # complete patterns returned.
    results = []
    cells_used = [[False] * k for _ in range(k)]

    def can_place(r, c):
        return not (cells_used[r][c] or cells_used[r + 1][c]
                    or cells_used[r][c + 1] or cells_used[r + 1][c + 1])

    def place(r, c, val):
        cells_used[r][c] = val
        cells_used[r + 1][c] = val
        cells_used[r][c + 1] = val
        cells_used[r + 1][c + 1] = val

    def dfs(start, placed, chosen):
        if len(results) >= max_patterns:
            return
        if placed == m:
            results.append(list(chosen))
            return
        remaining = m - placed
        # Need at least 4*remaining free cells.
        for idx in range(start, len(positions)):
            r, c = positions[idx]
            if can_place(r, c):
                place(r, c, True)
                chosen.append((r, c))
                dfs(idx + 1, placed + 1, chosen)
                chosen.pop()
                place(r, c, False)
                if len(results) >= max_patterns:
                    return

    dfs(0, 0, [])
    return results


def _merge_grid_candidate(n):
    """Deterministic constructor: for n = k^2 - m, build a k x k grid and
    merge m disjoint 2x2 blocks.  Each merged block becomes one square of
    side 2/k.  Returns (squares, score) or (None, -inf) if not applicable."""
    if n <= 1:
        return None, -1.0
    k = math.isqrt(n) + 1
    # We want k^2 >= n and m = k^2 - n merges; each merge removes 3 squares
    # (4 cells -> 1 square), so k^2 - 3*m = n.  If not, try smaller k.
    best_sq = None
    best_score = -1.0
    for k_try in range(2, k + 2):
        total = k_try * k_try
        diff = total - n
        if diff < 0:
            continue
        if diff % 3 != 0:
            continue
        m = diff // 3
        if m > (k_try - 1) * (k_try - 1):
            continue
        patterns = _merge_candidates(k_try, m, max_patterns=200)
        if not patterns:
            continue
        cell = 1.0 / k_try
        block_side = 2.0 * cell
        for pat in patterns:
            used = [[False] * k_try for _ in range(k_try)]
            ok = True
            for (r, c) in pat:
                if used[r][c] or used[r + 1][c] or used[r][c + 1] or used[r + 1][c + 1]:
                    ok = False
                    break
                used[r][c] = used[r + 1][c] = used[r][c + 1] = used[r + 1][c + 1] = True
            if not ok:
                continue
            squares = []
            # Emit merged blocks.
            for (r, c) in pat:
                cx = (c + 1) * cell
                cy = (r + 1) * cell
                squares.append((cx, cy, 0.0, block_side))
            # Emit single cells.
            for r in range(k_try):
                for c in range(k_try):
                    if used[r][c]:
                        continue
                    cx = (c + 0.5) * cell
                    cy = (r + 0.5) * cell
                    squares.append((cx, cy, 0.0, cell))
            if len(squares) != n:
                continue
            sc = block_side * len(pat) + cell * (n - len(pat))
            if sc > best_score:
                best_score = sc
                best_sq = squares
    return best_sq, best_score


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_sq, best_score = _grid_fallback(n)

    # Phase 0: deterministic (k x k)-grid-with-2x2-merges constructor.
    merge_sq, merge_sc = _merge_grid_candidate(n)
    if merge_sq is not None and merge_sc > best_score + 1e-9:
        best_sq = merge_sq
        best_score = merge_sc

    rng = random.Random(987654 + n)

    # Phase 1: randomized restarts to explore topologies.
    restarts = 10 if n <= 16 else 6
    short_iters = 900 if n <= 16 else 500
    best_nodes = None
    for _ in range(restarts):
        nodes = _make_flat_tree(n, rng)
        nodes, sc = _anneal(nodes, rng, short_iters)
        if sc > best_score + 1e-9:
            out = []
            _eval_tree(nodes, 0.0, 0.0, 1.0, 1.0, out)
            if len(out) == n:
                best_sq = out
                best_score = sc
                best_nodes = list(nodes)

    # Phase 2: warm-started long annealing from the best topology found.
    if best_nodes is not None:
        long_iters = 9000 if n <= 16 else 5000
        nodes, sc = _anneal(list(best_nodes), rng, long_iters)
        if sc > best_score + 1e-9:
            out = []
            _eval_tree(nodes, 0.0, 0.0, 1.0, 1.0, out)
            if len(out) == n:
                best_sq = out
                best_score = sc
                best_nodes = list(nodes)

    # Phase 3: rotation sweep.
    if best_nodes is not None:
        leaves = _leaf_indices(best_nodes)
        improved = True
        sweeps = 0
        while improved and sweeps < 6:
            improved = False
            sweeps += 1
            for i in leaves:
                if best_nodes[i] is None or best_nodes[i][0] != 0:
                    continue
                cand = list(best_nodes)
                cand[i] = (0, not best_nodes[i][1])
                cs = _score(cand)
                if cs > best_score + 1e-12:
                    best_nodes = cand
                    best_score = cs
                    improved = True
        out = []
        _eval_tree(best_nodes, 0.0, 0.0, 1.0, 1.0, out)
        if len(out) == n:
            best_sq = out

        # Phase 3b: pairwise rotation sweep.
        if len(leaves) <= 20:
            pair_improved = True
            pair_sweeps = 0
            while pair_improved and pair_sweeps < 3:
                pair_improved = False
                pair_sweeps += 1
                for ai in range(len(leaves)):
                    i = leaves[ai]
                    if best_nodes[i] is None or best_nodes[i][0] != 0:
                        continue
                    for bi in range(ai + 1, len(leaves)):
                        j = leaves[bi]
                        if best_nodes[j] is None or best_nodes[j][0] != 0:
                            continue
                        cand = list(best_nodes)
                        cand[i] = (0, not best_nodes[i][1])
                        cand[j] = (0, not best_nodes[j][1])
                        cs = _score(cand)
                        if cs > best_score + 1e-12:
                            best_nodes = cand
                            best_score = cs
                            pair_improved = True
            out = []
            _eval_tree(best_nodes, 0.0, 0.0, 1.0, 1.0, out)
            if len(out) == n:
                best_sq = out

        # Phase 4: low-temperature polish.
        polish_iters = 800 if n <= 16 else 500
        nodes, sc = _anneal(list(best_nodes), rng, polish_iters)
        if sc > best_score + 1e-9:
            out = []
            _eval_tree(nodes, 0.0, 0.0, 1.0, 1.0, out)
            if len(out) == n:
                best_sq = out
                best_score = sc
                best_nodes = list(nodes)

        # Phase 5: second long anneal with a fresh RNG stream.
        rng2 = random.Random(13579 + n)
        nodes, sc = _anneal(list(best_nodes), rng2, 4000 if n <= 16 else 2500)
        if sc > best_score + 1e-9:
            out = []
            _eval_tree(nodes, 0.0, 0.0, 1.0, 1.0, out)
            if len(out) == n:
                best_sq = out
                best_score = sc
                best_nodes = list(nodes)

    # Sanitize.
    result = []
    for (cx, cy, ang, s) in best_sq:
        s = max(0.0, min(s, 1.0))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = ang % 1.0
        result.append((cx, cy, ang, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END