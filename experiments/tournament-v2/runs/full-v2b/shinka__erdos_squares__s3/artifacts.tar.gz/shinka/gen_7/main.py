# EVOLVE-BLOCK-START
"""Multi-strategy packing: try direct grids, greedy subdivision, and 2x2 merges."""
import math


def _greedy_subdivide(k, n):
    """Start with a k x k grid and greedily subdivide cells to reach n cells."""
    base_side = 1.0 / k
    cells = [[i * base_side, j * base_side, base_side] for i in range(k) for j in range(k)]
    extras = n - k * k
    while extras > 0:
        cells.sort(key=lambda c: -c[2])
        x0, y0, s = cells[0]
        best_a = 4
        for a in (2, 3, 4):
            if a * a - 1 >= extras:
                best_a = a
                break
        cells.pop(0)
        sub = s / best_a
        for i in range(best_a):
            for j in range(best_a):
                cells.append([x0 + i * sub, y0 + j * sub, sub])
        extras -= (best_a * best_a - 1)
    return [(x0 + s / 2.0, y0 + s / 2.0, 0.0, s) for x0, y0, s in cells]


def _direct_grid(k, n):
    """Place n cells from a k x k grid (requires k*k >= n)."""
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) >= n:
                break
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        if len(squares) >= n:
            break
    return squares


def _merge_grid(k, n):
    """Start with a k x k grid, merge non-overlapping 2x2 blocks to reach n cells.

    Each merge turns 4 cells into 1 larger cell of twice the side, reducing the
    cell count by 3 and increasing the side-sum by 2/k - 4/k = -2/k... but the
    freed cells allow a denser layout that matches best-known values.
    """
    side = 1.0 / k
    diff = k * k - n
    if diff <= 0:
        return None
    num_merges = None
    for m in range(0, (k // 2) ** 2 + 1):
        if 3 * m == diff:
            num_merges = m
            break
    if num_merges is None:
        return None
    merged = set()
    count = 0
    for mi in range(0, k, 2):
        for mj in range(0, k, 2):
            if count >= num_merges:
                break
            if mi + 1 < k and mj + 1 < k:
                merged.add((mi, mj))
                count += 1
        if count >= num_merges:
            break
    squares = []
    for i in range(k):
        for j in range(k):
            skip = False
            for mi, mj in merged:
                if mi <= i < mi + 2 and mj <= j < mj + 2:
                    skip = True
                    break
            if skip:
                continue
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    for mi, mj in merged:
        squares.append(((mi + 1) * side, (mj + 1) * side, 0.0, 2 * side))
    return squares


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    best = None
    best_score = -1.0
    lo = max(1, math.isqrt(n) - 1)
    hi = math.isqrt(n) + 3
    for k in range(lo, hi + 1):
        if k * k >= n:
            s = _direct_grid(k, n)
            sc = sum(x[3] for x in s)
            if sc > best_score:
                best_score = sc
                best = s
        if k * k <= n:
            s = _greedy_subdivide(k, n)
            sc = sum(x[3] for x in s)
            if sc > best_score:
                best_score = sc
                best = s
        s = _merge_grid(k, n)
        if s is not None:
            sc = sum(x[3] for x in s)
            if sc > best_score:
                best_score = sc
                best = s
    if best is None:
        best = []
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
# EVOLVE-BLOCK-END