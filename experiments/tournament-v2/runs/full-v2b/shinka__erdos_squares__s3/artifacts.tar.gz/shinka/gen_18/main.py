# EVOLVE-BLOCK-START
"""Free-form simulated-annealing packer for n rotated squares in the unit square.

Approach (fundamentally different from guillotine-tree slicers):
  * Each square is parameterized by (cx, cy, angle, side) in continuous space.
  * Feasibility is checked with the Separating Axis Theorem (SAT) on rotated
    squares, so non-guillotine / non-slicing layouts are reachable.
  * A soft penalty (total overlap area + out-of-bounds violation) is added to
    the objective, so the annealer can pass through infeasible states.
  * Multiple restarts, geometric cooling, and a targeted repair move that
    perturbs the square involved in the largest overlap.
  * A deterministic seed (grid or known-good pattern) guarantees a floor.
"""
import math
import random


TWO_PI = 2.0 * math.pi


def _corners(cx, cy, ang, s):
    """Return 4 corners of a square (center, angle fraction of turn, side)."""
    a = ang * TWO_PI
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for (x, y) in pts:
        out.append((cx + ca * x - sa * y, cy + sa * x + ca * y))
    return out


def _overlap_area_sat(c1, c2):
    """Overlap area of two convex polygons via Sutherland-Hodgman clipping."""
    # Use SAT for a quick reject, then clip for the area.
    def axes(c):
        ax = []
        for i in range(4):
            x1, y1 = c[i]
            x2, y2 = c[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            ax.append((-ey, ex))
        return ax

    def project(c, ax):
        axx, axy = ax
        mn = mx = c[0][0] * axx + c[0][1] * axy
        for (x, y) in c[1:]:
            v = x * axx + y * axy
            if v < mn:
                mn = v
            elif v > mx:
                mx = v
        return mn, mx

    for ax in axes(c1) + axes(c2):
        a1, b1 = project(c1, ax)
        a2, b2 = project(c2, ax)
        if b1 <= a2 or b2 <= a1:
            return 0.0

    # Clip c2 against c1 (Sutherland-Hodgman)
    def clip(subject, clipper):
        def inside(p, a, b):
            return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= 0.0

        def intersect(p1, p2, a, b):
            x1, y1 = p1
            x2, y2 = p2
            x3, y3 = a
            x4, y4 = b
            den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
            if abs(den) < 1e-15:
                return p2
            t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den
            return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))

        out = list(subject)
        for i in range(len(clipper)):
            a = clipper[i]
            b = clipper[(i + 1) % len(clipper)]
            inp = out
            out = []
            if not inp:
                break
            s = inp[-1]
            for e in inp:
                if inside(e, a, b):
                    if not inside(s, a, b):
                        out.append(intersect(s, e, a, b))
                    out.append(e)
                elif inside(s, a, b):
                    out.append(intersect(s, e, a, b))
                s = e
        return out

    poly = clip(c2, c1)
    if len(poly) < 3:
        return 0.0
    area = 0.0
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        area += x1 * y2 - x2 * y1
    return 0.5 * abs(area)


def _evaluate(sqs):
    """Return (total_side, penalty).  sqs is list of (cx,cy,ang,s)."""
    total = 0.0
    pen = 0.0
    corners = []
    for (cx, cy, ang, s) in sqs:
        if s <= 0.0:
            corners.append(None)
            continue
        total += s
        c = _corners(cx, cy, ang, s)
        corners.append(c)
        # bounds penalty: any corner outside [0,1]^2
        for (x, y) in c:
            if x < 0.0:
                pen += (-x) * s
            elif x > 1.0:
                pen += (x - 1.0) * s
            if y < 0.0:
                pen += (-y) * s
            elif y > 1.0:
                pen += (y - 1.0) * s
    # overlap penalty
    for i in range(len(sqs)):
        ci = corners[i]
        if ci is None:
            continue
        for j in range(i + 1, len(sqs)):
            cj = corners[j]
            if cj is None:
                continue
            a = _overlap_area_sat(ci, cj)
            if a > 0.0:
                pen += a * 5.0
    return total, pen


def _objective(sqs, w_pen=40.0):
    t, p = _evaluate(sqs)
    return t - w_pen * p


def _grid_seed(n):
    """Deterministic grid seed as a floor."""
    k = int(math.isqrt(n))
    if k < 1:
        k = 1
    side = 1.0 / k
    sqs = []
    for i in range(k):
        for j in range(k):
            if len(sqs) >= n:
                break
            sqs.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        if len(sqs) >= n:
            break
    while len(sqs) < n:
        sqs.append((0.5, 0.5, 0.0, 0.0))
    return sqs[:n]


def _known_pattern(n):
    """Hand-crafted seeds for small n where a non-slicing layout is known to
    beat the guillotine optimum.  Returns None if no pattern is available."""
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        # 4 small in corners + 1 big in the middle
        s = 0.5
        big = 1.0 - s
        return [(s / 2, s / 2, 0.0, s), (1 - s / 2, s / 2, 0.0, s),
                (s / 2, 1 - s / 2, 0.0, s), (1 - s / 2, 1 - s / 2, 0.0, s),
                (0.5, 0.5, 0.0, big)]
    if n == 6:
        # 2x3 grid
        return [((i + 0.5) / 3, (j + 0.5) / 2, 0.0, 1.0 / 3)
                for j in range(2) for i in range(3)]
    if n == 7:
        # 2x2 big + 3 small: use 2 rows
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5),
                (0.25, 0.05, 0.0, 0.1), (0.5, 0.05, 0.0, 0.1),
                (0.75, 0.05, 0.0, 0.1),
                (0.25, 0.95, 0.0, 0.1), (0.75, 0.95, 0.0, 0.1)]
    if n == 8:
        # Known optimal pattern: 4 squares in corners + 4 smaller in middle
        # (classic "pinwheel" style).  Use a good approximation.
        a = 0.4
        b = (1.0 - a) / 2.0
        return [
            (a / 2, a / 2, 0.0, a),
            (1 - a / 2, a / 2, 0.0, a),
            (a / 2, 1 - a / 2, 0.0, a),
            (1 - a / 2, 1 - a / 2, 0.0, a),
            (0.5, b / 2, 0.0, b),
            (0.5, 1 - b / 2, 0.0, b),
            (b / 2, 0.5, 0.0, b),
            (1 - b / 2, 0.5, 0.0, b),
        ]
    return None


def _perturb(sqs, rng, strength):
    """Return a mutated copy of sqs."""
    new = list(sqs)
    n = len(new)
    if n == 0:
        return new
    # pick a square
    i = rng.randrange(n)
    cx, cy, ang, s = new[i]
    r = rng.random()
    if r < 0.35:
        # move center
        cx += rng.gauss(0, 0.06 * strength)
        cy += rng.gauss(0, 0.06 * strength)
    elif r < 0.55:
        # resize
        s += rng.gauss(0, 0.04 * strength)
    elif r < 0.75:
        # rotate
        ang += rng.gauss(0, 0.05 * strength)
    elif r < 0.9:
        # combine
        cx += rng.gauss(0, 0.04 * strength)
        cy += rng.gauss(0, 0.04 * strength)
        s += rng.gauss(0, 0.03 * strength)
    else:
        # swap angle with 0.25
        ang = 0.25 if abs(ang) < 0.01 else 0.0
    # clamp
    if cx < 0.0:
        cx = 0.0
    elif cx > 1.0:
        cx = 1.0
    if cy < 0.0:
        cy = 0.0
    elif cy > 1.0:
        cy = 1.0
    if s < 0.0:
        s = 0.0
    elif s > 1.0:
        s = 1.0
    ang = ang % 1.0
    new[i] = (cx, cy, ang, s)
    return new


def _anneal(sqs, rng, iters, T0=0.05, T1=0.0005):
    cur = list(sqs)
    cur_obj = _objective(cur)
    best = list(cur)
    best_obj = cur_obj
    for it in range(iters):
        T = T0 * (T1 / T0) ** (it / float(iters))
        cand = _perturb(cur, rng, 1.0)
        cobj = _objective(cand)
        if cobj >= cur_obj or rng.random() < math.exp((cobj - cur_obj) / max(T, 1e-9)):
            cur = cand
            cur_obj = cobj
            if cobj > best_obj:
                best = list(cand)
                best_obj = cobj
    return best, best_obj


def _repair(sqs, rng, rounds=200):
    """Greedy repair: repeatedly find the worst-overlapping pair and shrink
    or move one of them."""
    cur = list(sqs)
    for _ in range(rounds):
        t, p = _evaluate(cur)
        if p < 1e-9:
            break
        # find worst pair
        worst = None
        worst_a = 0.0
        corners = [_corners(cx, cy, ang, s) if s > 0 else None
                   for (cx, cy, ang, s) in cur]
        for i in range(len(cur)):
            if corners[i] is None:
                continue
            for j in range(i + 1, len(cur)):
                if corners[j] is None:
                    continue
                a = _overlap_area_sat(corners[i], corners[j])
                if a > worst_a:
                    worst_a = a
                    worst = (i, j)
        if worst is None:
            break
        i, j = worst
        # shrink the smaller one
        si = cur[i][3]
        sj = cur[j][3]
        k = i if si <= sj else j
        cx, cy, ang, s = cur[k]
        s *= 0.95
        cur[k] = (cx, cy, ang, s)
    return cur


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(20240607 + n * 7919)

    # Seed candidates
    seeds = []
    seeds.append(_grid_seed(n))
    kp = _known_pattern(n)
    if kp is not None:
        seeds.append(kp)
    # A few random seeds
    for _ in range(3):
        sqs = []
        for _ in range(n):
            sqs.append((rng.random(), rng.random(),
                        rng.choice([0.0, 0.0, 0.25]), rng.uniform(0.05, 0.4)))
        seeds.append(sqs)

    best_sqs = None
    best_score = -1e18

    for seed in seeds:
        # repair first
        cur = _repair(seed, rng, rounds=150)
        # anneal
        iters = 6000 if n <= 16 else 3000
        cur, obj = _anneal(cur, rng, iters)
        # repair again
        cur = _repair(cur, rng, rounds=150)
        cur, obj = _anneal(cur, rng, iters // 2, T0=0.02, T1=0.0002)
        cur = _repair(cur, rng, rounds=150)
        t, p = _evaluate(cur)
        score = t - 1000.0 * p  # hard feasibility emphasis
        if score > best_score:
            best_score = score
            best_sqs = list(cur)

    # Final polish on the best
    if best_sqs is not None:
        for _ in range(3):
            cand, _ = _anneal(best_sqs, rng, 4000, T0=0.015, T1=0.0001)
            cand = _repair(cand, rng, rounds=200)
            t, p = _evaluate(cand)
            score = t - 1000.0 * p
            if score > best_score:
                best_score = score
                best_sqs = list(cand)

    if best_sqs is None:
        best_sqs = _grid_seed(n)

    # Sanitize
    result = []
    for (cx, cy, ang, s) in best_sqs:
        s = max(0.0, min(s, 1.0))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = ang % 1.0
        result.append((cx, cy, ang, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END