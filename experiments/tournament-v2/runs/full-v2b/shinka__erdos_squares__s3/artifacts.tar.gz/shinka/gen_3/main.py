# EVOLVE-BLOCK-START
"""Guillotine-cut packing optimizer with simulated annealing.

Idea: any packing can be approximated by recursively splitting the unit square
with axis-aligned guillotine cuts. Each leaf rectangle holds one square whose
side is min(width, height). We search over the binary tree of cuts and the
split ratios using simulated annealing, maximizing the total side length.
"""
import math
import random


def _eval_tree(tree, x, y, w, h, out):
    """Evaluate a guillotine tree; append (cx, cy, 0, side) squares to out."""
    if tree is None:
        s = min(w, h)
        out.append((x + w * 0.5, y + h * 0.5, 0.0, s))
        return s
    orient, ratio, left, right = tree
    if orient == 0:  # vertical cut
        wl = w * ratio
        sl = _eval_tree(left, x, y, wl, h, out)
        sr = _eval_tree(right, x + wl, y, w - wl, h, out)
    else:  # horizontal cut
        hl = h * ratio
        sl = _eval_tree(left, x, y, w, hl, out)
        sr = _eval_tree(right, x, y + hl, w, h - hl, out)
    return sl + sr


def _score(tree):
    out = []
    return _eval_tree(tree, 0.0, 0.0, 1.0, 1.0, out)


def _count_leaves(tree):
    if tree is None:
        return 1
    return _count_leaves(tree[2]) + _count_leaves(tree[3])


def _random_tree(n_leaves, rng):
    """Build a random guillotine tree with exactly n_leaves leaves."""
    if n_leaves <= 1:
        return None
    # split leaves between left and right
    k = rng.randint(1, n_leaves - 1)
    orient = rng.randint(0, 1)
    ratio = rng.uniform(0.2, 0.8)
    left = _random_tree(k, rng)
    right = _random_tree(n_leaves - k, rng)
    return (orient, ratio, left, right)


def _collect_paths(tree, path=()):
    """Return list of (path, node) for internal nodes."""
    if tree is None:
        return []
    res = [(path, tree)]
    res += _collect_paths(tree[2], path + (2,))
    res += _collect_paths(tree[3], path + (3,))
    return res


def _get_node(tree, path):
    node = tree
    for p in path:
        node = node[p]
    return node


def _set_node(tree, path, new_node):
    if not path:
        return new_node
    node = list(tree)
    child = _set_node(node[path[0]], path[1:], new_node)
    node[path[0]] = child
    return tuple(node)


def _mutate(tree, rng):
    """Random mutation: tweak a ratio or orientation."""
    paths = _collect_paths(tree)
    if not paths:
        return tree
    path, node = rng.choice(paths)
    orient, ratio, left, right = node
    if rng.random() < 0.5:
        ratio = min(0.9, max(0.1, ratio + rng.gauss(0, 0.1)))
    else:
        orient = 1 - orient
    new_node = (orient, ratio, left, right)
    return _set_node(tree, path, new_node)


def _anneal(n, rng, iters=20000):
    best_tree = _random_tree(n, rng)
    best_score = _score(best_tree)
    cur_tree = best_tree
    cur_score = best_score
    T0, T1 = 0.05, 0.0005
    for it in range(iters):
        T = T0 * (T1 / T0) ** (it / iters)
        cand = _mutate(cur_tree, rng)
        cs = _score(cand)
        if cs >= cur_score or rng.random() < math.exp((cs - cur_score) / max(T, 1e-9)):
            cur_tree, cur_score = cand, cs
            if cs > best_score:
                best_score, best_tree = cs, cand
    return best_tree, best_score


def _grid_fallback(n):
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n], k  # score = k * 1.0


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # baseline grid
    grid_sq, grid_score = _grid_fallback(n)
    best_sq = grid_sq
    best_score = float(grid_score)

    rng = random.Random(12345 + n)
    restarts = 4 if n <= 20 else 2
    iters = 8000 if n <= 20 else 4000
    for r in range(restarts):
        tree, sc = _anneal(n, rng, iters=iters)
        if sc > best_score + 1e-9:
            out = []
            _eval_tree(tree, 0.0, 0.0, 1.0, 1.0, out)
            if len(out) == n:
                best_sq = out
                best_score = sc

    # final sanitize: clip to [0,1], ensure exactly n entries
    result = []
    for (cx, cy, ang, s) in best_sq:
        s = max(0.0, min(s, 1.0))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        result.append((cx, cy, ang, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END
