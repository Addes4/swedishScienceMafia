# EVOLVE-BLOCK-START
"""Guillotine-cut packing optimizer with rotation-aware leaves and a
targeted rotation-refinement pass.

Key changes vs. the previous version:
  * After annealing, a dedicated "rotated-leaf refinement" pass iterates
    only over leaves whose rotation flag is set. For each such leaf it
    tries (a) flipping the leaf to axis-aligned, and (b) perturbing the
    parent split ratio, accepting any candidate that improves the score.
    This addresses the specific case where a rotated leaf's
    min(w,h)/sqrt(2) side is smaller than the axis-aligned alternative.
  * A small coordinate-descent on split ratios of parents of rotated
    leaves is performed, again only touching high-value nodes.
  * The annealer uses slightly higher T0 and a few more restarts for
    small n, since the flat-tree representation is cheap.
  * The axis-aligned grid is always evaluated first as a floor.
"""
import math
import random


SQRT2 = math.sqrt(2.0)


def _leaf_side(w, h, rotated):
    m = w if w < h else h
    if rotated:
        return m / SQRT2
    return m


def _eval_tree(nodes, x, y, w, h, out):
    """Evaluate the flat-tree. nodes[i] is either:
        (0, rotated)                     -- leaf
        (1, orient, ratio, li, ri)       -- split
    Returns total side sum."""
    stack = [(0, x, y, w, h)]
    total = 0.0
    while stack:
        idx, cx0, cy0, cw, ch = stack.pop()
        node = nodes[idx]
        if node[0] == 0:  # leaf
            rotated = node[1]
            s = _leaf_side(cw, ch, rotated)
            out.append((cx0 + cw * 0.5, cy0 + ch * 0.5,
                        0.25 if rotated else 0.0, s))
            total += s
        else:
            _, orient, ratio, li, ri = node
            if orient == 0:  # vertical cut
                wl = cw * ratio
                stack.append((li, cx0, cy0, wl, ch))
                stack.append((ri, cx0 + wl, cy0, cw - wl, ch))
            else:  # horizontal cut
                hl = ch * ratio
                stack.append((li, cx0, cy0, cw, hl))
                stack.append((ri, cx0, cy0 + hl, cw, ch - hl))
    return total


def _make_flat_tree(n_leaves, rng):
    """Build a flat guillotine tree with exactly n_leaves leaves."""
    nodes = []

    def rec(k):
        if k == 1:
            nodes.append((0, rng.random() < 0.5))
            return len(nodes) - 1
        k_left = rng.randint(1, k - 1)
        orient = rng.randint(0, 1)
        ratio = rng.uniform(0.2, 0.8)
        my_idx = len(nodes)
        nodes.append(None)
        li = rec(k_left)
        ri = rec(k - k_left)
        nodes[my_idx] = (1, orient, ratio, li, ri)
        return my_idx

    rec(n_leaves)
    return nodes


def _internal_indices(nodes):
    return [i for i, nd in enumerate(nodes) if nd is not None and nd[0] == 1]


def _leaf_indices(nodes):
    return [i for i, nd in enumerate(nodes) if nd is not None and nd[0] == 0]


def _mutate(nodes, rng):
    r = rng.random()
    if r < 0.55:
        internals = _internal_indices(nodes)
        if not internals:
            return False
        i = rng.choice(internals)
        _, orient, ratio, li, ri = nodes[i]
        if rng.random() < 0.7:
            ratio = ratio + rng.gauss(0, 0.08)
            if ratio < 0.08:
                ratio = 0.08
            elif ratio > 0.92:
                ratio = 0.92
            nodes[i] = (1, orient, ratio, li, ri)
        else:
            nodes[i] = (1, 1 - orient, ratio, li, ri)
        return True
    else:
        leaves = _leaf_indices(nodes)
        if not leaves:
            return False
        i = rng.choice(leaves)
        _, rotated = nodes[i]
        nodes[i] = (0, not rotated)
        return True


def _score(nodes):
    out = []
    return _eval_tree(nodes, 0.0, 0.0, 1.0, 1.0, out)


def _anneal(nodes, rng, iters):
    cur_score = _score(nodes)
    best_nodes = list(nodes)
    best_score = cur_score
    T0, T1 = 0.08, 0.0005
    for it in range(iters):
        T = T0 * (T1 / T0) ** (it / float(iters))
        cand = list(nodes)
        if not _mutate(cand, rng):
            continue
        cs = _score(cand)
        if cs >= cur_score or rng.random() < math.exp((cs - cur_score) / max(T, 1e-9)):
            nodes = cand
            cur_score = cs
            if cs > best_score:
                best_score = cs
                best_nodes = list(cand)
    return best_nodes, best_score


def _parent_map(nodes):
    """Return dict child_idx -> (parent_idx, side) where side is 0 for left
    child and 1 for right child."""
    pm = {}
    for i, nd in enumerate(nodes):
        if nd is not None and nd[0] == 1:
            _, _, _, li, ri = nd
            pm[li] = (i, 0)
            pm[ri] = (i, 1)
    return pm


def _refine_rotated(nodes, best_score, rng, max_rounds=3):
    """Targeted refinement: for each rotated leaf, try to flip it to
    axis-aligned and/or perturb the parent ratio.  Accept improvements."""
    parent = _parent_map(nodes)
    leaves = _leaf_indices(nodes)
    rounds = 0
    improved = True
    while improved and rounds < max_rounds:
        improved = False
        rounds += 1
        for li in leaves:
            nd = nodes[li]
            if nd is None or nd[0] != 0:
                continue
            rotated = nd[1]
            # Candidate A: flip rotation flag only.
            cand = list(nodes)
            cand[li] = (0, not rotated)
            cs = _score(cand)
            if cs > best_score + 1e-12:
                nodes = cand
                best_score = cs
                improved = True
                continue

            # Candidate B: if the leaf is rotated, try axis-aligned while
            # perturbing the parent split ratio.  This is the case the
            # recommendation highlights.
            if rotated and li in parent:
                pi, side = parent[li]
                pnode = nodes[pi]
                if pnode is None or pnode[0] != 1:
                    continue
                _, orient, ratio, pli, pri = pnode
                for delta in (-0.06, -0.03, 0.03, 0.06):
                    nr = ratio + delta
                    if nr < 0.08 or nr > 0.92:
                        continue
                    cand = list(nodes)
                    cand[pi] = (1, orient, nr, pli, pri)
                    cand[li] = (0, False)
                    cs = _score(cand)
                    if cs > best_score + 1e-12:
                        nodes = cand
                        best_score = cs
                        improved = True
                        break
        # Refresh parent map in case topology changed (it does not here,
        # but leaves list is stable).
    return nodes, best_score


def _grid_fallback(n):
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n], float(k)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_sq, best_score = _grid_fallback(n)

    rng = random.Random(987654 + n)

    # Phase 1: randomized restarts to explore topologies.
    restarts = 8 if n <= 16 else 4
    short_iters = 700 if n <= 16 else 400
    best_nodes = None
    for _ in range(restarts):
        nodes = _make_flat_tree(n, rng)
        nodes, sc = _anneal(nodes, rng, short_iters)
        if sc > best_score + 1e-9:
            out = []
            _eval_tree(nodes, 0.0, 0.0, 1.0, 1.0, out)
            if len(out) == n:
                best_sq = out
                best_score = sc
                best_nodes = list(nodes)

    # Phase 2: warm-started long annealing from the best topology found.
    if best_nodes is not None:
        long_iters = 10000 if n <= 16 else 6000
        nodes, sc = _anneal(list(best_nodes), rng, long_iters)
        if sc > best_score + 1e-9:
            out = []
            _eval_tree(nodes, 0.0, 0.0, 1.0, 1.0, out)
            if len(out) == n:
                best_sq = out
                best_score = sc
                best_nodes = list(nodes)

    # Phase 3: targeted rotated-leaf refinement.
    if best_nodes is not None:
        nodes, sc = _refine_rotated(best_nodes, best_score, rng, max_rounds=3)
        if sc > best_score + 1e-12:
            out = []
            _eval_tree(nodes, 0.0, 0.0, 1.0, 1.0, out)
            if len(out) == n:
                best_sq = out
                best_score = sc
                best_nodes = list(nodes)

    # Sanitize.
    result = []
    for (cx, cy, ang, s) in best_sq:
        s = max(0.0, min(s, 1.0))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = ang % 1.0
        result.append((cx, cy, ang, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END