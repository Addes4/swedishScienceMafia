# EVOLVE-BLOCK-START
"""Adaptive guillotine slicing-tree packer.

We recursively subdivide the unit square into rectangles (a slicing tree).
Each leaf rectangle hosts one square. For an axis-aligned square, its side is
min(w, h). For a 45-degree rotated square, the largest rotated square inscribed
in a w x h rectangle has side = min(w, h) / (cos45 + sin45) = min(w,h)/sqrt(2)
when the rectangle is a square; more generally the rotated square diagonal must
fit: side * (|cos|+|sin|) <= min(w, h) for the tighter axis, so for 45 deg
side = min(w, h) / sqrt(2).  We use a slicing tree with per-leaf rotation flags
and randomized ratios, optimized by multi-start hill climbing.
"""
import math
import random


def _largest_square(w, h, rotated):
    """Largest square side that fits in a w x h rectangle."""
    m = min(w, h)
    if rotated:
        return m / math.sqrt(2.0)
    return m


def _place(rect, rotated):
    """Return (cx, cy, angle, side) for a square in rect=(x,y,w,h)."""
    x, y, w, h = rect
    s = _largest_square(w, h, rotated)
    cx = x + w * 0.5
    cy = y + h * 0.5
    ang = 0.25 if rotated else 0.0
    return (cx, cy, ang, s)


def _evaluate(tree, rect, out):
    """Recursively fill rect according to tree; append squares to out.
    tree is either ('leaf', rotated) or ('split', axis, ratio, left, right).
    Returns total side sum for this subtree."""
    if tree[0] == 'leaf':
        sq = _place(rect, tree[1])
        out.append(sq)
        return sq[3]
    _, axis, ratio, left, right = tree
    x, y, w, h = rect
    if axis == 0:  # vertical split
        wl = w * ratio
        r1 = (x, y, wl, h)
        r2 = (x + wl, y, w - wl, h)
    else:          # horizontal split
        hl = h * ratio
        r1 = (x, y, w, hl)
        r2 = (x, y + hl, w, h - hl)
    return _evaluate(left, r1, out) + _evaluate(right, r2, out)


def _random_tree(n_leaves, rng):
    """Build a random slicing tree with exactly n_leaves leaves."""
    if n_leaves == 1:
        return ('leaf', rng.random() < 0.5)
    # split off a random number of leaves for the left subtree
    k = rng.randint(1, n_leaves - 1)
    axis = rng.randint(0, 1)
    ratio = rng.uniform(0.25, 0.75)
    left = _random_tree(k, rng)
    right = _random_tree(n_leaves - k, rng)
    return ('split', axis, ratio, left, right)


def _collect_leaves(tree, acc):
    if tree[0] == 'leaf':
        acc.append(tree)
    else:
        _collect_leaves(tree[3], acc)
        _collect_leaves(tree[4], acc)


def _mutate(tree, rng):
    """Return a mutated copy of the tree."""
    if tree[0] == 'leaf':
        if rng.random() < 0.3:
            return ('leaf', not tree[1])
        return tree
    _, axis, ratio, left, right = tree
    r = rng.random()
    if r < 0.5:
        # perturb ratio
        new_ratio = ratio + rng.gauss(0, 0.08)
        new_ratio = min(0.9, max(0.1, new_ratio))
        return ('split', axis, new_ratio, _mutate(left, rng), _mutate(right, rng))
    elif r < 0.7:
        # flip axis
        return ('split', 1 - axis, ratio, _mutate(left, rng), _mutate(right, rng))
    else:
        return ('split', axis, ratio, _mutate(left, rng), _mutate(right, rng))


def _tree_leaves(tree):
    acc = []
    _collect_leaves(tree, acc)
    return acc


def _replace_leaf(tree, target_id, new_leaf):
    """Replace the leaf with a given index (DFS order) by new_leaf."""
    counter = [0]
    def rec(t):
        if t[0] == 'leaf':
            idx = counter[0]
            counter[0] += 1
            if idx == target_id:
                return new_leaf
            return t
        _, axis, ratio, left, right = t
        return ('split', axis, ratio, rec(left), rec(right))
    return rec(tree)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    # Number of leaves in the tree. Use exactly n leaves when feasible; for
    # larger n we use a tree with n leaves directly (recursion depth fine).
    # To keep depth manageable for big n, cap leaves but not needed here.
    n_leaves = n

    best_tree = None
    best_score = -1.0

    # Multi-start: random trees + hill climbing on ratios/rotations.
    starts = 60
    iters = 120
    for _ in range(starts):
        tree = _random_tree(n_leaves, rng)
        out = []
        score = _evaluate(tree, (0.0, 0.0, 1.0, 1.0), out)
        for _ in range(iters):
            cand = _mutate(tree, rng)
            out2 = []
            s2 = _evaluate(cand, (0.0, 0.0, 1.0, 1.0), out2)
            if s2 >= score - 1e-12:
                if s2 > score:
                    score = s2
                    tree = cand
                elif rng.random() < 0.5:
                    tree = cand
        if score > best_score:
            best_score = score
            best_tree = tree

    out = []
    _evaluate(best_tree, (0.0, 0.0, 1.0, 1.0), out)

    # Pad or trim to exactly n squares with zero-size squares.
    if len(out) < n:
        out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    elif len(out) > n:
        # merge extra leaves into zero-size squares
        out = out[:n - 1] + [(0.5, 0.5, 0.0, 0.0)] if n >= 1 else []
        out = out[:n]

    # Clamp everything into [0,1] for safety.
    result = []
    for (cx, cy, ang, s) in out:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = min(1.0, max(0.0, s))
        result.append((cx, cy, ang, s))
    return result[:n]
# EVOLVE-BLOCK-END
