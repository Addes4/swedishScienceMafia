# EVOLVE-BLOCK-START
"""Multi-seed Singer/Bose-Chowla Sidon construction + parallel polishing
for maximizing log|A-A|/log|A+A| with a bonus for larger sets.

Strategy:
  1. Sweep a wide range of primes, build Singer-style B_2 sets.
  2. Score each exactly, keep the top-K seeds.
  3. Also add greedy Mian-Chowla Sidon sets and a compact baseline.
  4. Polish each of the top-K seeds with a bounded SA budget, return best.
"""

import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    ld = len(diffs)
    ls = len(sums)
    if ls < 2 or ld < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _score_parts(a):
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


def _score_from_parts(ld, ls, n):
    if ls < 2 or ld < 2 or n < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def singer_sidon(p):
    """Erdos-Turan / Singer style Sidon set:
    A = { 2*p*i + (i*i mod p) : i = 0..p-1 }.
    For prime p this is a B_2 set: all pairwise differences are distinct,
    giving |A - A| = n*(n-1) + 1 (near-maximal)."""
    A = []
    for i in range(p):
        A.append(2 * p * i + (i * i) % p)
    return sorted(set(A))


def greedy_sidon(target_size, max_val):
    """Greedy Mian-Chowla style Sidon set: unique positive differences."""
    A = [0]
    used = {0}
    c = 1
    while len(A) < target_size and c <= max_val:
        ok = True
        new = set()
        for x in A:
            d = abs(c - x)
            if d in used or d in new:
                ok = False
                break
            new.add(d)
        if ok:
            A.append(c)
            used |= new
        c += 1
    return sorted(A)


def _polish(A, deadline, rng):
    """SA local search: shift, compress toward median, add, remove.
    Only strictly improving moves are accepted near the end (T -> 0)."""
    A = sorted(set(A))
    if len(A) < 2:
        return A
    ld, ls, n = _score_parts(A)
    cur_s = _score_from_parts(ld, ls, n)
    best = A[:]
    best_s = cur_s
    start = time.time()
    total = max(0.001, deadline - start)
    T0 = 0.05
    while time.time() < deadline:
        t = (time.time() - start) / total
        T = T0 * (0.001 / T0) ** min(1.0, max(0.0, t))
        cand = A[:]
        r = rng.random()
        if r < 0.55:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-3, -2, -1, 1, 2, 3, -5, 5, -10, 10])
        elif r < 0.70:
            # Compress: pull random element toward the median
            srt = sorted(cand)
            med = srt[len(srt) // 2]
            i = rng.randrange(len(cand))
            if cand[i] != med:
                diff = med - cand[i]
                if abs(diff) > 1:
                    cand[i] += diff // 2
                else:
                    cand[i] += 1 if diff > 0 else -1
        elif r < 0.85 and len(cand) < 4000:
            lo, hi = min(cand), max(cand)
            cand.append(rng.randint(lo - 5, hi + 5))
        elif len(cand) > 3:
            i = rng.randrange(len(cand))
            cand.pop(i)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        cld, cls, cn = _score_parts(cand)
        s = _score_from_parts(cld, cls, cn)
        if s > cur_s or rng.random() < math.exp((s - cur_s) / max(T, 1e-9)):
            A = cand
            ld, ls, n = cld, cls, cn
            cur_s = s
            if s > best_s:
                best = cand[:]
                best_s = s
    return best


def _build_seeds():
    """Return a list of (score, A) candidate seeds."""
    seeds = []

    # 1) Singer/Bose-Chowla sweep over many primes
    primes = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59,
              61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127,
              131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191,
              193, 197, 199, 211, 223, 227, 229, 233, 239, 251, 257, 263,
              269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337,
              347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409,
              419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479,
              487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569,
              571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641,
              643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719,
              727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809,
              811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881,
              883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971,
              977, 983, 991, 997]
    for p in primes:
        A = singer_sidon(p)
        if len(A) < 2:
            continue
        s = _score(A)
        seeds.append((s, A))

    # 2) Greedy Mian-Chowla Sidon sets
    for size in [8, 12, 16, 20, 25, 30, 40]:
        for mv in [size * size, size * size * 2, size * size * 4]:
            A = greedy_sidon(size, mv)
            if len(A) < 2:
                continue
            s = _score(A)
            seeds.append((s, A))

    # 3) Compact baseline
    compact = [7, 15, 18, 22, -3, -2]
    seeds.append((_score(compact), compact))

    return seeds


def solve():
    """Return a list of distinct integers A maximizing
    log|A-A|/log|A+A| + (1 - 1/|A|)/100."""
    deadline = time.time() + 25.0
    rng = random.Random(20240607)

    seeds = _build_seeds()
    # Sort by score descending, keep top-K
    seeds.sort(key=lambda t: -t[0])
    K = 10
    top = seeds[:K]

    best = top[0][1][:]
    best_s = top[0][0]

    # Polish each of the top-K seeds with a bounded budget.
    remaining = deadline - time.time()
    if remaining <= 0.5:
        return sorted(set(best))

    per_seed = max(0.5, min(2.0, remaining / max(1, len(top))))

    for idx, (s0, A0) in enumerate(top):
        if time.time() >= deadline - 0.2:
            break
        slice_end = min(deadline - 0.1, time.time() + per_seed)
        cand = _polish(A0, slice_end, rng)
        s = _score(cand)
        if s > best_s:
            best = cand[:]
            best_s = s

    # If time remains, do one more longer polish from the current best.
    if time.time() < deadline - 0.5:
        cand = _polish(best, deadline - 0.1, rng)
        s = _score(cand)
        if s > best_s:
            best = cand
            best_s = s

    return sorted(set(best))
# EVOLVE-BLOCK-END