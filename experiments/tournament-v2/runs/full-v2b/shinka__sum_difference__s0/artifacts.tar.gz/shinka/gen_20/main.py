# EVOLVE-BLOCK-START
"""Hybrid Golomb-ruler + simulated annealing approach for maximizing
log|A-A|/log|A+A| with bonus for larger sets."""

import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls < 2 or ld < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _fast_score_parts(a):
    """Return (len_diff, len_sum, n)."""
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


def _score_from_parts(ld, ls, n):
    if ls < 2 or ld < 2 or n < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def greedy_sidon(target_size, max_val):
    """Greedy Mian-Chowla style: build a set where all positive differences are unique.
    This maximizes |A-A| (gives ~n^2 distinct differences)."""
    A = [0]
    used_diffs = {0}
    candidates = list(range(1, max_val + 1))
    while len(A) < target_size:
        found = False
        for c in candidates:
            if c in A:
                continue
            new_diffs = set()
            ok = True
            for x in A:
                d = abs(c - x)
                if d in used_diffs or d in new_diffs:
                    ok = False
                    break
                new_diffs.add(d)
            if ok:
                A.append(c)
                used_diffs |= new_diffs
                found = True
                break
        if not found:
            break
    return sorted(A)


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def singer_sidon(p):
    """Singer's construction: for a prime p, gives a Sidon set of size p
    modulo v = p^2 + p + 1 (using the classical Singer difference set).
    Actually we use the simpler Bose-Chowla construction: for prime power q,
    a Sidon set of size q in Z_{q^2-1}, via the map x -> x + (x^2 mod v)
    where v = q^2 - 1. We use q = p (prime).
    Returns a list of distinct integers (lifted to Z)."""
    q = p
    v = q * q - 1
    # Bose-Chowla: A = { (x, x^2 mod v) mapped to x * v + (x^2 mod v) }
    # This gives a Sidon set in Z_{v^2}? That's too large.
    # Better: use the classical Sidon set in Z_{q^2-1}:
    # For q prime, the set { 2*q*i + (i^2 mod q) : i = 0..q-1 } is Sidon in Z_{q^2}
    # (Erdos-Turan style). Let's use a known explicit construction.
    # Simpler practical approach: Bose-Chowla set in Z_{q^2-1}:
    # A = { a in Z_{q^2-1} : a ≡ x^2 (mod ...) } -- complicated.
    # Instead use the Ruzsa construction: for prime p, A = { 2*p*i + (i^2 mod p) : i=0..p-1 }
    # has all differences distinct (B_2 set) in the integers.
    A = []
    for i in range(q):
        A.append(2 * q * i + (i * i) % q)
    return sorted(set(A))


def golomb_best_known(n):
    """Return a good Golomb ruler of order n (subset of a known optimal ruler).
    For small n we use known optimal rulers; for larger n we use a heuristic."""
    KNOWN = {
        1: [0], 2: [0, 1], 3: [0, 1, 3], 4: [0, 1, 4, 6],
        5: [0, 1, 4, 9, 11], 6: [0, 1, 4, 10, 12, 17],
        7: [0, 1, 4, 10, 18, 23, 25], 8: [0, 1, 4, 9, 15, 22, 32, 34],
        9: [0, 1, 5, 12, 25, 27, 35, 41, 44],
        10: [0, 1, 6, 10, 23, 26, 34, 41, 53, 55],
        11: [0, 1, 4, 13, 28, 33, 47, 54, 64, 70, 72],
        12: [0, 2, 6, 24, 29, 40, 43, 55, 68, 75, 76, 85],
        13: [0, 2, 5, 25, 37, 43, 59, 70, 85, 89, 98, 99, 106],
        14: [0, 4, 5, 17, 19, 39, 52, 65, 75, 90, 95, 100, 105, 112],
        15: [0, 4, 20, 30, 57, 59, 62, 76, 100, 111, 123, 136, 144, 145, 151],
    }
    if n in KNOWN:
        return list(KNOWN[n])
    return None


def build_initial():
    """Build several candidate initial sets and pick the best."""
    best = None
    best_s = -1.0
    # Try known optimal Golomb rulers (best |A-A| for small n)
    for n in range(3, 16):
        A = golomb_best_known(n)
        if A is None:
            continue
        s = _score(A)
        if s > best_s:
            best_s = s
            best = A[:]
    # Try Singer/Bose-Chowla Sidon sets for primes (large |A-A| ~ n^2)
    for p in [5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61,
              67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113]:
        A = singer_sidon(p)
        if len(A) < 2:
            continue
        s = _score(A)
        if s > best_s:
            best_s = s
            best = A[:]
    # Try various greedy Sidon sets as fallback
    for size in [8, 12, 16, 20, 25, 30]:
        for mv in [size * size, size * size * 2, size * size * 4]:
            A = greedy_sidon(size, mv)
            if len(A) < 2:
                continue
            s = _score(A)
            if s > best_s:
                best_s = s
                best = A
    # Also try a compact set
    compact = list(range(0, 12))
    s = _score(compact)
    if s > best_s:
        best_s = s
        best = compact
    return best, best_s


def local_search(A, deadline, rng):
    """Simulated annealing with multiple move types."""
    A = sorted(set(A))
    ld, ls, n = _fast_score_parts(A)
    cur_score = _score_from_parts(ld, ls, n)
    best = A[:]
    best_score = cur_score

    # Temperature schedule
    T0 = 0.5
    T_min = 0.001
    start = time.time()
    total = max(0.001, deadline - start)

    iter_count = 0
    while time.time() < deadline:
        iter_count += 1
        t = (time.time() - start) / total
        T = T0 * (T_min / T0) ** min(1.0, t)

        move = rng.random()
        cand = A[:]
        if move < 0.5 and len(cand) > 2:
            # Shift a random element
            i = rng.randrange(len(cand))
            delta = rng.choice([-3, -2, -1, 1, 2, 3, -5, 5, -10, 10])
            cand[i] += delta
        elif move < 0.75:
            # Add an element
            if len(cand) < 4000:
                lo = min(cand) - rng.randint(1, 30)
                hi = max(cand) + rng.randint(1, 30)
                cand.append(rng.randint(lo, hi))
        elif move < 0.9 and len(cand) > 3:
            # Remove an element
            i = rng.randrange(len(cand))
            cand.pop(i)
        else:
            # Shift a whole block (translation doesn't change score, so shift by small amount)
            i = rng.randrange(len(cand))
            delta = rng.choice([-1, 1]) * rng.randint(1, 5)
            cand[i] += delta

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        cld, cls, cn = _fast_score_parts(cand)
        cscore = _score_from_parts(cld, cls, cn)

        if cscore > cur_score or rng.random() < math.exp((cscore - cur_score) / max(T, 1e-9)):
            A = cand
            ld, ls, n = cld, cls, cn
            cur_score = cscore
            if cscore > best_score:
                best = cand[:]
                best_score = cscore
        elif rng.random() < 0.02:
            # Occasionally restart from best
            A = best[:]
            ld, ls, n = _fast_score_parts(A)
            cur_score = _score_from_parts(ld, ls, n)

    return best, best_score


def refine_shift(A, deadline):
    """Try translating the set to reduce |A+A| by making it more compact around 0.
    Actually translation doesn't change |A+A| or |A-A|, so skip."""
    return A


def _is_sidon_after_replace(A_sorted, removed_val, new_val):
    """Check if replacing removed_val with new_val in A_sorted keeps the set Sidon
    (all pairwise positive differences distinct)."""
    if new_val == removed_val:
        return True
    if new_val in A_sorted and new_val != removed_val:
        return False
    diffs = set()
    m = len(A_sorted)
    for i in range(m):
        ai = A_sorted[i]
        for j in range(i + 1, m):
            d = ai - A_sorted[j]
            if d < 0:
                d = -d
            if d in diffs:
                # Check if this collision involves the removed element
                # (we'll re-check below); for now mark as potential collision
                return False
            diffs.add(d)
    # Now try adding new_val and verify no repeated differences
    new_diffs = []
    for x in A_sorted:
        if x == removed_val:
            continue
        d = new_val - x
        if d < 0:
            d = -d
        if d == 0 or d in diffs:
            return False
        new_diffs.append(d)
    # Also check new_diffs are pairwise distinct
    if len(set(new_diffs)) != len(new_diffs):
        return False
    return True


def remove_and_replace(A, deadline):
    """Refinement: delete a boundary element and re-insert it at a smaller position
    that preserves the Sidon property. This shrinks the diameter without losing n,
    reducing |A+A| and improving the ratio."""
    A = sorted(set(A))
    if len(A) < 3:
        return A
    best = A[:]
    best_ld, best_ls, best_n = _fast_score_parts(best)
    best_s = _score_from_parts(best_ld, best_ls, best_n)
    rng = random.Random(777)
    while time.time() < deadline:
        cur = best[:]
        n = len(cur)
        # Pick a boundary element: prefer the largest (top of range)
        if rng.random() < 0.7:
            idx = n - 1
        else:
            idx = 0
        removed = cur[idx]
        rest = cur[:idx] + cur[idx + 1:]
        if not rest:
            continue
        lo, hi = min(rest), max(rest)
        # Search for smallest valid integer in [lo, hi] (replace top with smaller)
        if idx == n - 1:
            search_range = range(lo, removed)
        else:
            # Replace smallest with something larger, but not larger than hi
            search_range = range(hi, removed, -1)
        found_val = None
        for x in search_range:
            if _is_sidon_after_replace(rest, removed, x):
                found_val = x
                break
        if found_val is None:
            continue
        cand = sorted(rest + [found_val])
        cld, cls, cn = _fast_score_parts(cand)
        cs = _score_from_parts(cld, cls, cn)
        if cs > best_s or (cs == best_s and cls < best_ls):
            best = cand
            best_s = cs
            best_ld, best_ls, best_n = cld, cls, cn
    return best


def compactify(A, deadline):
=======
    """Try to reduce |A+A| by compressing the set while keeping |A-A| large.
    Strategy: try to shift individual elements to reduce overlap in sums.

    NOTE: We only accept improving moves (with a tiny SA acceptance for
    exploration). The previous version accepted every candidate, effectively
    performing a random walk that discarded the good solution found by the
    main search. This version preserves the best solution."""
    A = sorted(set(A))
    if len(A) < 2:
        return A
    best = A[:]
    best_s = _score(best)
    cur = A[:]
    cur_s = best_s
    rng = random.Random(12345)
    T0 = 0.002
    start = time.time()
    total = max(0.001, deadline - start)
    while time.time() < deadline:
        t = (time.time() - start) / total
        T = T0 * (0.01) ** min(1.0, max(0.0, t))
        i = rng.randrange(len(cur))
        cand = cur[:]
        # Try moving element i to reduce overlap in sums.
        # Mix of random target and median-directed move.
        if rng.random() < 0.5:
            lo, hi = min(cur), max(cur)
            target = rng.randint(lo, hi)
        else:
            med = cur[len(cur) // 2]
            target = med + rng.randint(-3, 3)
        cand[i] = target
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_s or rng.random() < math.exp((s - cur_s) / max(T, 1e-9)):
            cur = cand
            cur_s = s
            if s > best_s:
                best = cand[:]
                best_s = s
    return best


def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A| + bonus."""
    deadline = time.time() + 110  # leave some margin
    rng = random.Random(987654321)

    # Build initial candidates
    initial, initial_score = build_initial()

    best = initial[:]
    best_score = initial_score

    # Run multiple SA restarts
    n_restarts = 0
    prime_list = [5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59,
                  61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113,
                  127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179,
                  181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239]
    while time.time() < deadline - 5:
        n_restarts += 1
        if n_restarts == 1:
            start_A = initial[:]
        else:
            # Perturb best or build new
            if rng.random() < 0.5:
                start_A = best[:]
                # Random perturbation
                for _ in range(rng.randint(1, 3)):
                    if start_A and rng.random() < 0.7:
                        i = rng.randrange(len(start_A))
                        start_A[i] += rng.randint(-5, 5)
                    elif len(start_A) < 4000:
                        start_A.append(rng.randint(-50, 50))
                start_A = sorted(set(start_A))
            else:
                # Use a random Singer/Bose-Chowla Sidon set for a fresh start
                p = rng.choice(prime_list)
                start_A = singer_sidon(p)
                # Add a small perturbation to try to reduce |A+A|
                if rng.random() < 0.3:
                    for _ in range(rng.randint(1, 2)):
                        if start_A:
                            i = rng.randrange(len(start_A))
                            start_A[i] += rng.randint(-2, 2)
                    start_A = sorted(set(start_A))

        # Allocate time slice
        slice_end = min(deadline - 2, time.time() + max(3, (deadline - time.time()) / 4))
        cand, cscore = local_search(start_A, slice_end, rng)
        if cscore > best_score:
            best = cand[:]
            best_score = cscore

    # Remove-and-replace refinement: shrink diameter while preserving Sidon property
    if time.time() < deadline - 1:
        rr_budget = min(deadline - time.time(), 30)
        cand = remove_and_replace(best, time.time() + rr_budget)
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s

    # Final compaction attempt
    if time.time() < deadline:
        cand = compactify(best, deadline)
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s

    return sorted(set(best))
# EVOLVE-BLOCK-END