# EVOLVE-BLOCK-START
"""Head-to-head Bose-Chowla vs Erdos-Turan Sidon seeds + local search polishing
for maximizing log|A-A|/log|A+A| with a bonus for larger sets."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2 or len(diffs) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def erdos_turan_sidon(p):
    """Erdos-Turan Sidon set on the integers:
    A = { 2*p*i + (i*i mod p) : i = 0..p-1 }.
    B_2 set: |A - A| = n*(n-1) + 1. Diameter ~ 2*p^2."""
    A = []
    for i in range(p):
        A.append(2 * p * i + (i * i) % p)
    return sorted(set(A))


def _primitive_root(v):
    """Return a primitive root modulo v (v = p^2 - 1), or None if not found."""
    if v <= 1:
        return None
    # Factor v
    n = v
    factors = set()
    d = 2
    while d * d <= n:
        if n % d == 0:
            factors.add(d)
            while n % d == 0:
                n //= d
        d += 1
    if n > 1:
        factors.add(n)
    # Euler phi
    phi = v
    for f in factors:
        phi -= phi // f
    # Try small candidates
    for g in range(2, min(v, 5000)):
        if math.gcd(g, v) != 1:
            continue
        ok = True
        for f in factors:
            if pow(g, phi // f, v) == 1:
                ok = False
                break
        if ok:
            return g
    return None


def bose_chowla_sidon(p):
    """Bose-Chowla Sidon set: for prime p, v = p^2 - 1, g primitive root mod v.
    A = { i in [0, v-1] : g^i ≡ 1 + i (mod v) }.
    This is a Sidon set of size exactly p, contained in [0, v-1] = [0, p^2-2].
    Diameter ~ p^2 (about half of Erdos-Turan's 2*p^2)."""
    v = p * p - 1
    if v < 3:
        return []
    g = _primitive_root(v)
    if g is None:
        return []
    # Build discrete log table: dlog[g^k mod v] = k
    dlog = [-1] * v
    cur = 1 % v
    for k in range(v):
        if dlog[cur] == -1:
            dlog[cur] = k
        cur = (cur * g) % v
    A = []
    for i in range(v):
        target = (1 + i) % v
        if dlog[target] == i:
            A.append(i)
    # BC should yield exactly p elements; if not, bail out so we don't
    # waste time polishing a degenerate construction.
    if len(A) < p:
        return []
    return sorted(A)


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _lex_key(ld, ls, n):
    """Lexicographic key (ratio, -|A+A|, n) used to break ties in favour of
    smaller sum sets and larger n when the ratio is unchanged."""
    if ls < 2 or ld < 2 or n < 2:
        return (-1.0, 0, 0)
    return (math.log(ld) / math.log(ls), -ls, n)


def _polish(A, deadline, rng):
    """Greedy improving-moves local search with lexicographic acceptance
    (ratio, -|A+A|, n). Accepts moves that keep the ratio fixed but shrink
    |A+A| or grow n, so the Sidon-level difference count is preserved while
    the sum set is nudged down."""
    A = sorted(set(A))
    if len(A) < 2:
        return A
    ld, ls, n = _score_parts(A)
    cur_key = _lex_key(ld, ls, n)
    best = A[:]
    best_key = cur_key
    cur = A[:]
    start = time.time()
    total = max(0.001, deadline - start)
    T0 = 0.05
    while time.time() < deadline:
        t = (time.time() - start) / total
        T = T0 * (0.001 / T0) ** min(1.0, max(0.0, t))
        cand = cur[:]
        r = rng.random()
        if r < 0.7:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-3, -2, -1, 1, 2, 3, -5, 5])
        elif r < 0.85 and len(cand) < 4000:
            lo, hi = min(cand), max(cand)
            cand.append(rng.randint(lo - 5, hi + 5))
        elif len(cand) > 3:
            i = rng.randrange(len(cand))
            cand.pop(i)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        cld, cls, cn = _score_parts(cand)
        ckey = _lex_key(cld, cls, cn)
        # Accept if lexicographically better, or with small SA probability
        # on the ratio component (so we can escape a plateau).
        d_ratio = ckey[0] - cur_key[0]
        if ckey > cur_key or (d_ratio >= 0 and rng.random() < 0.5) or \
           rng.random() < math.exp(d_ratio / max(T, 1e-9)):
            cur = cand
            cur_key = ckey
            if ckey > best_key:
                best = cand[:]
                best_key = ckey
    return best


def _score_parts(a):
    """Return (|A-A|, |A+A|, |A|) for a list of distinct integers."""
    a = list(set(a))
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


def _repair(A, deadline, rng):
    """Exhaustive interior scan with lexicographic acceptance:
    for each index i, try every shift in a window [-W, W] (W ~ span/8) and
    accept the lexicographically-best candidate. This is the untried
    combination of an exhaustive interior scan with lexicographic acceptance
    keyed on (ratio, -|A+A|, n), which can lock in small |A+A| reductions
    that pure random sampling misses."""
    A = sorted(set(A))
    if len(A) < 2:
        return A
    ld, ls, n = _score_parts(A)
    best = A[:]
    best_key = _lex_key(ld, ls, n)
    cur = A[:]
    cur_ld, cur_ls = ld, ls
    cur_key = best_key
    while time.time() < deadline:
        lo, hi = min(cur), max(cur)
        span = hi - lo
        W = max(2, span // 8)
        # Cycle through indices in random order for fairness.
        order = list(range(len(cur)))
        rng.shuffle(order)
        improved_any = False
        for i in order:
            if time.time() >= deadline:
                break
            orig = cur[i]
            best_local = None
            best_local_key = cur_key
            # Scan a window of shifts; step 1 for exhaustive coverage.
            for d in range(-W, W + 1):
                if d == 0:
                    continue
                newv = orig + d
                if newv in cur and newv != orig:
                    continue
                cand = cur[:]
                cand[i] = newv
                cand = sorted(set(cand))
                if len(cand) != len(cur):
                    continue
                cld, cls, cn = _score_parts(cand)
                ckey = _lex_key(cld, cls, cn)
                if ckey > best_local_key:
                    best_local_key = ckey
                    best_local = cand
                    best_local_ld, best_local_ls = cld, cls
            if best_local is not None:
                cur = best_local
                cur_ld, cur_ls = best_local_ld, best_local_ls
                cur_key = best_local_key
                if cur_key > best_key:
                    best = cur[:]
                    best_key = cur_key
                improved_any = True
        if not improved_any:
            # No lexicographic improvement possible in this pass; stop.
            break
    return best


def _sum_compress(A, deadline, rng):
    """Try to shrink |A+A| by moving individual elements while keeping |A-A|
    intact. Strictly improving moves only."""
    A = sorted(set(A))
    if len(A) < 2:
        return A
    best = A[:]
    best_s = _score(best)
    diffs = {x - y for x in A for y in A}
    ld = len(diffs)
    sums = {x + y for x in A for y in A}
    ls = len(sums)
    n = len(A)
    while time.time() < deadline:
        i = rng.randrange(len(A))
        cand = A[:]
        # Try a nearby target within the current span
        lo, hi = min(A), max(A)
        span = hi - lo
        step = rng.randint(1, max(2, span // 20))
        cand[i] += rng.choice([-step, step, -1, 1, -2, 2])
        cand = sorted(set(cand))
        if len(cand) != n:
            continue
        cd = {x - y for x in cand for y in cand}
        if len(cd) < ld:
            continue
        cs = {x + y for x in cand for y in cand}
        if len(cs) <= ls:
            # Accept if strictly reduces sums (or same sums with same diffs)
            if len(cs) < ls or len(cd) > ld:
                A = cand
                if len(cd) > ld:
                    ld = len(cd)
                if len(cs) < ls:
                    ls = len(cs)
                s = math.log(ld) / math.log(ls) + (1 - 1 / n) / 100
                if s > best_s:
                    best = cand[:]
                    best_s = s
    return best


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 110
    rng = random.Random(20240607)

    primes = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59,
              61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127,
              131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191,
              193, 197, 199, 211, 223, 227, 229, 233, 239, 251, 257, 263,
              269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337,
              347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409,
              419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479,
              487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569,
              571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641,
              643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719,
              727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809,
              811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881,
              883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971,
              977, 983, 991, 997]

    best = None
    best_score = -1.0
    best_kind = None

    # Head-to-head sweep: Erdos-Turan vs Bose-Chowla for each prime.
    for p in primes:
        A_et = erdos_turan_sidon(p)
        if len(A_et) >= 2:
            s = _score(A_et)
            if s > best_score:
                best_score = s
                best = A_et[:]
                best_kind = "ET"
        A_bc = bose_chowla_sidon(p)
        if len(A_bc) >= 2:
            s = _score(A_bc)
            if s > best_score:
                best_score = s
                best = A_bc[:]
                best_kind = "BC"

    # Fallback compact baseline.
    compact = [7, 15, 18, 22, -3, -2]
    s = _score(compact)
    if s > best_score:
        best_score = s
        best = compact[:]
        best_kind = "compact"

    # Polish the best construction, then lexicographic repair, then
    # sum-compression as a final pass.
    if best is not None and time.time() < deadline - 5:
        polish_deadline = min(deadline - 5, time.time() + (deadline - time.time()) * 0.5)
        cand = _polish(best, polish_deadline, rng)
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s

    if best is not None and time.time() < deadline - 1:
        repair_deadline = min(deadline - 1, time.time() + (deadline - time.time()) * 0.7)
        cand = _repair(best, repair_deadline, rng)
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s

    if best is not None and time.time() < deadline:
        cand = _sum_compress(best, deadline, rng)
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s

    return sorted(set(best))
# EVOLVE-BLOCK-END