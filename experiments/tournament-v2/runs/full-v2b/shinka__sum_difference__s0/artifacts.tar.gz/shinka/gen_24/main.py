# EVOLVE-BLOCK-START
"""Multi-seed construction + lexicographic repair.

Goal: maximise log|A-A| / log|A+A| + (1 - 1/|A|)/100.

Architecture:
  1. _seed_pool()      -> build many structurally-diverse seeds
  2. _select_topk()    -> exact score, keep top-K
  3. _affine_sweep()   -> scale/shift search per seed
  4. _repair()         -> anneal with lexicographic (ratio, -|A+A|, n)
  5. solve()           -> thin driver tying the phases together
"""
import math
import random
import time


# ---------- scoring ----------

def _stats(a):
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _score(a):
    return _stats(a)[0]


def _key(a):
    """Lexicographic key: (ratio, -|A+A|, n)."""
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return (-1.0, 0, 0)
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    ratio = math.log(len(diffs)) / math.log(len(sums))
    return (ratio, -len(sums), n)


# ---------- seed constructions ----------

def _build_quadratic(n, D):
    return [i + D * i * i for i in range(n)]


def _build_mod_sidon(n, p, scale):
    return [((i * (i + 1)) % p) * scale + i for i in range(n)]


def _greedy_golomb(n, cap=10**7):
    A = [0]
    used = set()
    cand = 1
    while len(A) < n and cand <= cap:
        ok = True
        new_diffs = set()
        for x in A:
            d1 = cand - x
            d2 = x - cand
            if d1 in used or d2 in used or d1 in new_diffs or d2 in new_diffs:
                ok = False
                break
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            A.append(cand)
            used |= new_diffs
        cand += 1
    return A


def _greedy_sidon_mod(n, mod):
    A = [0]
    used_sums = {0}
    cand = 1
    while len(A) < n and cand < mod:
        ok = True
        new_sums = set()
        for x in A:
            s = (x + cand) % mod
            if s in used_sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if ok:
            A.append(cand)
            used_sums |= new_sums
        cand += 1
    return A


def _build_pow2(n):
    return [0] + [2 ** i for i in range(n)]


# ---------- phase 1: seed pool ----------

def _seed_pool(start, budget_frac=0.55):
    """Assemble a large pool of candidate seeds within a time budget."""
    LIMIT = 10 ** 15
    deadline = start + budget_frac * 110
    pool = []

    def _add(seed):
        if not seed or len(seed) < 2:
            return
        if max(abs(x) for x in seed) > LIMIT:
            return
        pool.append((_score(seed), list(set(int(x) for x in seed))))

    # 1a. Quadratic Sidon sets.
    for n in range(3, 130):
        for D in (1, 2, 3, 4, 5, 8, 16, 32, 64, 128, 256, 512, 1024, 4096, 65536):
            cand = _build_quadratic(n, D)
            if cand[-1] > LIMIT:
                break
            _add(cand)
        if time.time() > start + 0.25 * (deadline - start):
            break

    # 1b. Finite-field Sidon variants.
    primes = [97, 193, 389, 769, 1543, 3079, 6151, 12289, 24593, 49157,
              98317, 196613, 393241, 786433, 1572869, 3145739, 6291469,
              12582917, 25165843, 50331653, 100663319]
    for n in range(3, 120):
        for p in primes:
            if p < n:
                continue
            for scale in (1, 7, 1000, 10 ** 6, 10 ** 9, 10 ** 12):
                cand = _build_mod_sidon(n, p, scale)
                if max(abs(x) for x in cand) > LIMIT:
                    continue
                _add(cand)
        if time.time() > start + 0.75 * (deadline - start):
            break

    # 1c. Greedy Golomb rulers.
    for n in (6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64):
        if time.time() > deadline:
            break
        _add(_greedy_golomb(n))

    # 1d. Greedy modular Sidon sets.
    for n in (6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64):
        if time.time() > deadline:
            break
        mod = n * n + n + 1
        _add(_greedy_sidon_mod(n, mod))

    # 1e. Shifted powers-of-2.
    for n in (8, 16, 32, 64, 100):
        if time.time() > deadline:
            break
        _add(_build_pow2(n))

    if not pool:
        pool.append((_score([0, 1, 3, 7, 12, 20]), [0, 1, 3, 7, 12, 20]))
    return pool


# ---------- phase 2: top-K selection ----------

def _select_topk(pool, K=12):
    pool.sort(key=lambda t: -t[0])
    return pool[:K]


# ---------- phase 3: affine sweep ----------

def _best_affine(seed, deadline, scales=(1, 2, 3, 5, 7, 11, 13, 17, 31, 61)):
    best = list(set(int(x) for x in seed))
    best_score = _score(best)
    if len(best) < 2:
        return best, best_score
    for scale in scales:
        if time.time() > deadline:
            break
        scaled = [x * scale for x in seed]
        mid = (max(scaled) + min(scaled)) // 2
        for shift in (0, -mid, -min(scaled), -max(scaled), -mid // 2, -mid // 3):
            cand = [x + shift for x in scaled]
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def _affine_sweep(top, start, budget_frac=0.15):
    deadline = start + budget_frac * 110
    out = []
    for s0, A0 in top:
        if time.time() > deadline:
            out.append((s0, A0))
            continue
        cand, s = _best_affine(A0, deadline)
        out.append((s, cand))
    out.sort(key=lambda t: -t[0])
    return out


# ---------- phase 4: repair (lexicographic anneal) ----------

def _repair(A, t_end, best_global=None, best_global_key=None):
    A = list(set(int(x) for x in A))
    if len(A) < 2:
        k = _key(A)
        return A, _score(A), k
    best = A[:]
    best_key = _key(best)
    best_score = _score(best)
    if best_global is not None and best_global_key is not None:
        if best_global_key > best_key:
            best, best_key = best_global[:], best_global_key
            best_score = _score(best)
    cur = A[:]
    cur_key = best_key
    cur_score = best_score

    span = max(cur) - min(cur) + 1
    T0 = max(0.5, 0.02 * span)
    Tmin = 1e-3
    now = time.time()
    total = max(1.0, t_end - now)
    no_improve = 0

    while time.time() < t_end:
        frac = 1.0 - (t_end - time.time()) / total
        T = max(Tmin, T0 * (1.0 - frac))
        cand = cur[:]
        op = random.random()
        if op < 0.65 and len(cand) > 2:
            i = random.randrange(len(cand))
            step = max(1, int(T * random.uniform(0.5, 2.0)))
            cand[i] += random.randint(-step, step)
        elif op < 0.85:
            cand.append(random.randint(-int(2 * T), int(2 * T)))
        else:
            if len(cand) > 3:
                # Wider extreme-element deletion: top-5 by distance from midpoint.
                mid = (max(cand) + min(cand)) // 2
                order = sorted(range(len(cand)),
                               key=lambda j: -abs(cand[j] - mid))
                k = min(5, len(order))
                del cand[order[random.randrange(k)]]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        c_key = _key(cand)
        c_score = _score(cand)
        if c_key > cur_key:
            cur, cur_key, cur_score = cand, c_key, c_score
            no_improve = 0
            if c_key > best_key:
                best, best_key, best_score = cand[:], c_key, c_score
        else:
            delta = c_score - cur_score
            if delta > -1e-9 or random.random() < math.exp(delta / max(T, 1e-6)):
                cur, cur_key, cur_score = cand, c_key, c_score
            no_improve += 1
            if no_improve > 400:
                cur, cur_key, cur_score = best[:], best_key, best_score
                no_improve = 0
    return best, best_score, best_key


# ---------- phase 5: driver ----------

def solve():
    random.seed(20240517)
    start = time.time()
    deadline = start + 110

    # Phase 1: build a large pool of seeds.
    pool = _seed_pool(start, budget_frac=0.55)

    # Phase 2: keep the top-K.
    top = _select_topk(pool, K=12)

    # Phase 3: affine sweep each of the top-K.
    affine_top = _affine_sweep(top, start, budget_frac=0.15)

    remaining = max(0.0, deadline - time.time())
    if remaining < 0.5:
        best = affine_top[0][1] if affine_top else [0, 1, 3, 7, 12, 20]
        return sorted(set(int(x) for x in best))

    polish_budget = 0.65 * remaining
    final_budget = 0.35 * remaining

    best_global = affine_top[0][1]
    best_global_score = affine_top[0][0]
    best_global_key = _key(best_global)

    # Phase 4a: uniform slice per top-K seed.
    K2 = len(affine_top)
    slice_time = polish_budget / K2 if K2 > 0 else polish_budget
    polish_end_all = time.time() + polish_budget

    for s0, A0 in affine_top:
        if time.time() >= polish_end_all:
            break
        t_end = min(polish_end_all, time.time() + slice_time)
        cand, s, k = _repair(A0, t_end, best_global, best_global_key)
        if k > best_global_key:
            best_global, best_global_score, best_global_key = cand, s, k

    # Phase 4b: final polish of the overall best.
    if time.time() < deadline:
        cand, s, k = _repair(best_global, deadline,
                             best_global, best_global_key)
        if k > best_global_key:
            best_global, best_global_score, best_global_key = cand, s, k

    if not best_global:
        best_global = [0, 1, 3, 7, 12, 20]

    return sorted(set(int(x) for x in best_global))


if __name__ == "__main__":
    import time as _t
    t0 = _t.time()
    res = solve()
    print("n=", len(res), "score=", _score(res), "time=", _t.time() - t0)
# EVOLVE-BLOCK-END
