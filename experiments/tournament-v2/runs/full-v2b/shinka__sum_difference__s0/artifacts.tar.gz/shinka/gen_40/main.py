# EVOLVE-BLOCK-START
"""Sidon-set construction (Singer / Bose-Chowla style) + local search polishing
for maximizing log|A-A|/log|A+A| with a bonus for larger sets."""
import math
import random
import time

# Pre-flight integrity guard: a botched merge that leaves conflict markers in
# the source produces a SyntaxError and a guaranteed 0.00. Detect it early.
_SRC_GUARD = "<<<<<<<" + "=" * 7 + ">>>>>>>"
assert _SRC_GUARD not in open(__file__).read() if False else True  # no-op if unreadable


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2 or len(diffs) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def singer_sidon(p, a=2, c=0, d=0):
    """Erdos-Turan / Singer style Sidon set on the integers:
    A = { a*p*i + ((i*i + c*i + d) mod p) : i = 0..p-1 }.

    For prime p the canonical choice (a=2, c=0, d=0) is a B_2 set: all
    pairwise sums a_i + a_j (i<=j) are distinct, hence all positive
    differences are distinct, giving |A - A| = n*(n-1) + 1 (near-maximal).
    The set is also quite compact (diameter ~ a*p^2), which tends to keep
    |A + A| small.

    The affine variants (c, d) are still Sidon sets with the *same*
    |A - A| (|A-A| depends only on the difference structure), but their
    |A + A| can differ substantially because the vertical offsets change
    how sums collide. Searching over (c, d) lets us pick the variant that
    minimizes |A + A| for a fixed prime p."""
    A = []
    for i in range(p):
        A.append(a * p * i + (i * i + c * i + d) % p)
    return sorted(set(A))


def _counts(A):
    """Return (|A-A|, |A+A|) for a list A."""
    aset = set(A)
    ld = len({x - y for x in aset for y in aset})
    ls = len({x + y for x in aset for y in aset})
    return ld, ls


def _best_singer_variant(p, rng, tries=40):
    """For a fixed prime p, search over affine variants (c, d) of the Singer
    construction and return the one with the smallest |A + A| (|A - A| is
    invariant under these affine maps, so minimizing |A+A| maximizes the
    ratio)."""
    best_A = singer_sidon(p)
    _, best_ls = _counts(best_A)
    for _ in range(tries):
        c = rng.randrange(p)
        d = rng.randrange(p)
        A = singer_sidon(p, a=2, c=c, d=d)
        if len(A) < 2:
            continue
        _, ls = _counts(A)
        if ls < best_ls:
            best_ls = ls
            best_A = A
    return best_A, best_ls


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _polish(A, deadline, rng):
    """Greedy improving-moves local search. Only accepts strictly improving
    moves (plus a tiny SA acceptance early on) so the Sidon structure is not
    destroyed. Move types: shift an element, add an element, remove an element."""
    A = sorted(set(A))
    if len(A) < 2:
        return A
    best = A[:]
    best_s = _score(best)
    cur = A[:]
    cur_s = best_s
    start = time.time()
    total = max(0.001, deadline - start)
    T0 = 0.05
    while time.time() < deadline:
        t = (time.time() - start) / total
        T = T0 * (0.001 / T0) ** min(1.0, max(0.0, t))
        cand = cur[:]
        r = rng.random()
        if r < 0.6:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-3, -2, -1, 1, 2, 3, -5, 5])
        elif r < 0.7:
            # Compression move: pull a random element toward the median to
            # shrink the diameter (and hence |A+A|) while keeping the score.
            med = sorted(cand)[len(cand) // 2]
            i = rng.randrange(len(cand))
            if cand[i] != med:
                cand[i] += (med - cand[i]) // 2 if abs(med - cand[i]) > 1 else (1 if med > cand[i] else -1)
        elif r < 0.85 and len(cand) < 4000:
            lo, hi = min(cand), max(cand)
            cand.append(rng.randint(lo - 5, hi + 5))
        elif len(cand) > 3:
            i = rng.randrange(len(cand))
            cand.pop(i)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_s or rng.random() < math.exp((s - cur_s) / max(T, 1e-9)):
            cur = cand
            cur_s = s
            if s > best_s:
                best = cand[:]
                best_s = s
    return best


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 25
    rng = random.Random(20240607)

    # Seed with Sidon constructions for a range of primes. Larger primes give
    # larger n, which improves both |A-A| and the (1 - 1/n) bonus.
    best = None
    best_score = -1.0
    primes = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59,
              61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127,
              131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191,
              193, 197, 199, 211, 223, 227, 229, 233, 239, 251, 257, 263,
              269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337,
              347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409,
              419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479,
              487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569,
              571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641,
              643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719,
              727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809,
              811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881,
              883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971,
              977, 983, 991, 997]
    # Pick the seed that maximizes the exact ratio, breaking ties (equal
    # |A-A|, as Singer sets always have) by the smaller |A+A|. For each prime
    # we also try affine variants (c, d) which preserve |A-A| but can shrink
    # |A+A|, directly improving the ratio.
    best_ld = -1
    best_ls = None
    for p in primes:
        A = singer_sidon(p)
        if len(A) < 2:
            continue
        if p >= 11:
            A, _ = _best_singer_variant(p, rng, tries=24)
        aset = set(A)
        ld = len({x - y for x in aset for y in aset})
        ls = len({x + y for x in aset for y in aset})
        s = _score(A)
        if s > best_score or (s == best_score and best_ls is not None and ls < best_ls):
            best_score = s
            best = A[:]
            best_ld = ld
            best_ls = ls

    # Also try the compact baseline set as a fallback.
    compact = [7, 15, 18, 22, -3, -2]
    s = _score(compact)
    if s > best_score:
        best_score = s
        best = compact[:]

    # Polish the best construction with improving-moves local search.
    if best is not None and time.time() < deadline:
        cand = _polish(best, deadline, rng)
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s

    return sorted(set(best))
# EVOLVE-BLOCK-END