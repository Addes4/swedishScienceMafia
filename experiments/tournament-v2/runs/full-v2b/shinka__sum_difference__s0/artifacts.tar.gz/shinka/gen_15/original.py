# EVOLVE-BLOCK-START
"""Golomb-ruler + Singer-difference-set hybrid with simulated annealing.

Goal: maximise log|A-A| / log|A+A| + (1 - 1/|A|)/100.

Strategy:
  1. Build seeds from greedy Golomb rulers (maximise |A-A|) and Singer
     perfect difference sets over prime powers (also maximal |A-A|).
  2. Search over affine transforms (scale, shift) that leave |A-A| unchanged
     but can drastically change |A+A|.
  3. Refine with simulated annealing using exact ratio as objective.
"""
import math
import random
import time


# ---------- scoring ----------

def _stats(a):
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _score(a):
    return _stats(a)[0]


# ---------- seed constructions ----------

def _greedy_golomb(n):
    """Greedy Golomb ruler: pick smallest integer keeping all differences distinct."""
    A = [0]
    used = set()
    cand = 1
    while len(A) < n:
        ok = True
        new_diffs = set()
        for x in A:
            d1 = cand - x
            d2 = x - cand
            if d1 in used or d2 in used or d1 in new_diffs or d2 in new_diffs:
                ok = False
                break
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            A.append(cand)
            used |= new_diffs
        cand += 1
        if cand > 10**7:
            break
    return A


def _singer_difference_set(n):
    """Try to build a Singer perfect difference set of order n over Z_{n^2+n+1}
    when n^2+n+1 is a prime power. Fall back to a random-ish construction."""
    q = n * n + n + 1
    # find a prime power p^k == q
    for p in range(2, 200):
        pk = p
        k = 1
        while pk < q:
            pk *= p
            k += 1
        if pk == q:
            # multiplicative generator of GF(p^k)* is hard; use a known
            # heuristic: choose a primitive root when k == 1
            if k == 1 and _is_prime(q):
                g = _primitive_root(q)
                if g is None:
                    continue
                # Singer construction: A = { i : trace(g^i)=0 } -- simplified
                # We use the standard "quadratic residues" style set instead:
                # A = { x : x^2 + x + 1 has a specific form } is complex;
                # fall back to a pseudorandom Sidon set of size n in Z_q.
                break
    # Fallback: greedy Sidon in Z_q
    return _greedy_sidon_mod(n, q)


def _is_prime(x):
    if x < 2:
        return False
    if x % 2 == 0:
        return x == 2
    i = 3
    while i * i <= x:
        if x % i == 0:
            return False
        i += 2
    return True


def _primitive_root(p):
    if p == 2:
        return 1
    factors = set()
    phi = p - 1
    x = phi
    d = 2
    while d * d <= x:
        while x % d == 0:
            factors.add(d)
            x //= d
        d += 1
    if x > 1:
        factors.add(x)
    for g in range(2, p):
        if all(pow(g, phi // f, p) != 1 for f in factors):
            return g
    return None


def _greedy_sidon_mod(n, mod):
    """Greedy Sidon set in Z_mod: all pairwise sums distinct (mod-friendly)."""
    A = [0]
    used_sums = {0}
    cand = 1
    while len(A) < n and cand < mod:
        ok = True
        new_sums = set()
        for x in A:
            s = (x + cand) % mod
            if s in used_sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if ok:
            A.append(cand)
            used_sums |= new_sums
        cand += 1
    return A


# ---------- affine search over seeds ----------

def _best_affine(seed, deadline):
    """Try scales and shifts to minimise |A+A| while keeping |A-A|."""
    best = seed[:]
    best_score = _score(best)
    n = len(seed)
    if n < 2:
        return best, best_score
    span = max(seed) - min(seed) + 1
    for scale in (1, 2, 3, 5, 7, 11):
        scaled = [x * scale for x in seed]
        # try shifts: 0, and shifts that centre around 0
        mid = (max(scaled) + min(scaled)) // 2
        for shift in (0, -mid, -min(scaled), -max(scaled), -mid // 2):
            cand = [x + shift for x in scaled]
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s
        if time.time() > deadline:
            break
    return best, best_score


# ---------- simulated annealing refinement ----------

def _anneal(A, deadline, budget_frac=0.6):
    A = list(set(int(x) for x in A))
    if len(A) < 2:
        return A, _score(A)
    best = A[:]
    best_score = _score(best)
    cur = A[:]
    cur_score = best_score
    t_end = time.time() + max(0.0, (deadline - time.time()) * budget_frac)

    span = max(cur) - min(cur) + 1
    T0 = max(0.5, 0.02 * span)
    Tmin = 1e-3
    total = max(1.0, t_end - time.time())
    no_improve = 0

    while time.time() < t_end:
        frac = 1.0 - (t_end - time.time()) / total
        T = max(Tmin, T0 * (1.0 - frac))
        cand = cur[:]
        op = random.random()
        if op < 0.65 and len(cand) > 2:
            i = random.randrange(len(cand))
            step = max(1, int(T * random.uniform(0.5, 2.0)))
            cand[i] += random.randint(-step, step)
        elif op < 0.85:
            cand.append(random.randint(-int(2 * T), int(2 * T)))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            no_improve = 0
            if s > best_score:
                best, best_score = cand[:], s
        else:
            delta = s - cur_score
            if delta > -1e-9 or random.random() < math.exp(delta / max(T, 1e-6)):
                cur, cur_score = cand, s
            no_improve += 1
            if no_improve > 400:
                cur, cur_score = best[:], best_score
                no_improve = 0
    return best, best_score


# ---------- driver ----------

def solve():
    random.seed(20240517)
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Phase 1: build seeds (40% of budget).
    seed_deadline = time.time() + 0.4 * (deadline - time.time())

    sizes = [6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96, 128]

    # Golomb-ruler seeds (maximise |A-A|).
    for n in sizes:
        if time.time() > seed_deadline:
            break
        seed = _greedy_golomb(n)
        if len(seed) < 2:
            continue
        cand, s = _best_affine(seed, seed_deadline)
        if s > best_score:
            best, best_score = cand[:], s

    # Singer / modular Sidon seeds.
    for n in sizes:
        if time.time() > seed_deadline:
            break
        mod = n * n + n + 1
        seed = _greedy_sidon_mod(n, mod)
        if len(seed) < 2:
            continue
        # wrap-around: map to a symmetric interval to help sums
        cand, s = _best_affine(seed, seed_deadline)
        if s > best_score:
            best, best_score = cand[:], s

    # Also try classic powers-of-2 with a shift (small sum set via symmetry).
    for n in (8, 16, 32, 64):
        if time.time() > seed_deadline:
            break
        seed = [0] + [2 ** i for i in range(n)]
        cand, s = _best_affine(seed, seed_deadline)
        if s > best_score:
            best, best_score = cand[:], s

    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    # Phase 2: simulated annealing refinement.
    if time.time() < deadline:
        best, best_score = _anneal(best, deadline, budget_frac=0.95)

    return sorted(set(int(x) for x in best))


if __name__ == "__main__":
    import time as _t
    t0 = _t.time()
    res = solve()
    print("n=", len(res), "score=", _score(res), "time=", _t.time() - t0)
# EVOLVE-BLOCK-END
