# EVOLVE-BLOCK-START
"""Multi-seed construction + short polishing per top-K seed.

Goal: maximise log|A-A| / log|A+A| + (1 - 1/|A|)/100.

Strategy:
  1. Build many seeds from several families:
       - quadratic Sidon sets {i + D*i^2}
       - finite-field Sidon sets ((i*(i+1)) mod p)*scale + i
       - greedy Golomb rulers
       - greedy modular Sidon sets
       - shifted powers-of-2
  2. Score each seed exactly and keep the top-K.
  3. Run a short polish (anneal / hill-climb) on each top-K seed
     within a shared budget, then return the best.
"""
import math
import random
import time


# ---------- scoring ----------

def _stats(a):
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _score(a):
    return _stats(a)[0]


# ---------- seed constructions ----------

def _build_quadratic(n, D):
    """A = {i + D*i*i : i=0..n-1}."""
    return [i + D * i * i for i in range(n)]


def _build_mod_sidon(n, p, scale):
    """Finite-field Sidon: map (i*(i+1)) mod p into a wide integer range."""
    return [((i * (i + 1)) % p) * scale + i for i in range(n)]


def _greedy_golomb(n, cap=10**7):
    A = [0]
    used = set()
    cand = 1
    while len(A) < n and cand <= cap:
        ok = True
        new_diffs = set()
        for x in A:
            d1 = cand - x
            d2 = x - cand
            if d1 in used or d2 in used or d1 in new_diffs or d2 in new_diffs:
                ok = False
                break
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            A.append(cand)
            used |= new_diffs
        cand += 1
    return A


def _greedy_sidon_mod(n, mod):
    A = [0]
    used_sums = {0}
    cand = 1
    while len(A) < n and cand < mod:
        ok = True
        new_sums = set()
        for x in A:
            s = (x + cand) % mod
            if s in used_sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if ok:
            A.append(cand)
            used_sums |= new_sums
        cand += 1
    return A


def _build_pow2(n):
    return [0] + [2 ** i for i in range(n)]


# ---------- affine sweep ----------

def _best_affine(seed, deadline, scales=(1, 2, 3, 5, 7, 11, 13, 17, 31, 61)):
    best = list(set(int(x) for x in seed))
    best_score = _score(best)
    if len(best) < 2:
        return best, best_score
    for scale in scales:
        if time.time() > deadline:
            break
        scaled = [x * scale for x in seed]
        mid = (max(scaled) + min(scaled)) // 2
        for shift in (0, -mid, -min(scaled), -max(scaled), -mid // 2, -mid // 3):
            cand = [x + shift for x in scaled]
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


# ---------- polishing (anneal / hill-climb) ----------

def _polish(A, t_end, best_global=None, best_global_score=-1.0):
    A = list(set(int(x) for x in A))
    if len(A) < 2:
        return A, _score(A)
    best = A[:]
    best_score = _score(best)
    if best_global is not None and best_global_score > best_score:
        best, best_score = best_global[:], best_global_score
    cur = A[:]
    cur_score = _score(cur)

    span = max(cur) - min(cur) + 1
    T0 = max(0.5, 0.02 * span)
    Tmin = 1e-3
    now = time.time()
    total = max(1.0, t_end - now)
    no_improve = 0

    while time.time() < t_end:
        frac = 1.0 - (t_end - time.time()) / total
        T = max(Tmin, T0 * (1.0 - frac))
        cand = cur[:]
        op = random.random()
        if op < 0.65 and len(cand) > 2:
            i = random.randrange(len(cand))
            step = max(1, int(T * random.uniform(0.5, 2.0)))
            cand[i] += random.randint(-step, step)
        elif op < 0.85:
            cand.append(random.randint(-int(2 * T), int(2 * T)))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            no_improve = 0
            if s > best_score:
                best, best_score = cand[:], s
        else:
            delta = s - cur_score
            if delta > -1e-9 or random.random() < math.exp(delta / max(T, 1e-6)):
                cur, cur_score = cand, s
            no_improve += 1
            if no_improve > 400:
                cur, cur_score = best[:], best_score
                no_improve = 0
    return best, best_score


# ---------- driver ----------

def solve():
    random.seed(20240517)
    start = time.time()
    deadline = start + 110
    LIMIT = 10 ** 15

    # ----- Phase 1: build a large pool of candidate seeds -----
    pool = []  # list of (score, A)

    def _add(seed):
        if not seed or len(seed) < 2:
            return
        if max(abs(x) for x in seed) > LIMIT:
            return
        s = _score(seed)
        pool.append((s, list(set(int(x) for x in seed))))

    # 1a. Quadratic Sidon sets.
    for n in range(3, 130):
        for D in (1, 2, 3, 4, 5, 8, 16, 32, 64, 128, 256, 512, 1024, 4096, 65536):
            cand = _build_quadratic(n, D)
            if cand[-1] > LIMIT:
                break
            _add(cand)
        if time.time() > start + 25:
            break

    # 1b. Finite-field Sidon variants.
    primes = [97, 193, 389, 769, 1543, 3079, 6151, 12289, 24593, 49157, 98317]
    for n in range(3, 90):
        for p in primes:
            if p < n:
                continue
            for scale in (1, 7, 1000, 10 ** 6, 10 ** 9):
                cand = _build_mod_sidon(n, p, scale)
                if max(abs(x) for x in cand) > LIMIT:
                    continue
                _add(cand)
        if time.time() > start + 45:
            break

    # 1c. Greedy Golomb rulers (maximise |A-A|).
    for n in (6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64):
        if time.time() > start + 55:
            break
        seed = _greedy_golomb(n)
        _add(seed)

    # 1d. Greedy modular Sidon sets.
    for n in (6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64):
        if time.time() > start + 65:
            break
        mod = n * n + n + 1
        seed = _greedy_sidon_mod(n, mod)
        _add(seed)

    # 1e. Shifted powers-of-2 (small sum set via symmetry).
    for n in (8, 16, 32, 64, 100):
        if time.time() > start + 70:
            break
        seed = _build_pow2(n)
        _add(seed)

    if not pool:
        pool.append((_score([0, 1, 3, 7, 12, 20]), [0, 1, 3, 7, 12, 20]))

    # ----- Phase 2: keep top-K seeds, affine sweep each -----
    pool.sort(key=lambda t: -t[0])
    K = 12
    top = pool[:K]

    affine_deadline = time.time() + max(0.0, (deadline - time.time()) * 0.15)
    affine_top = []
    for s0, A0 in top:
        if time.time() > affine_deadline:
            affine_top.append((s0, A0))
            continue
        cand, s = _best_affine(A0, affine_deadline)
        affine_top.append((s, cand))
    affine_top.sort(key=lambda t: -t[0])

    # ----- Phase 3: short polish on each of the top-K (round-robin) -----
    # Give each seed a slice of the remaining budget, but ensure the
    # best seed gets a slightly larger slice.
    remaining = max(0.0, deadline - time.time())
    if remaining < 0.5:
        best = affine_top[0][1]
        return sorted(set(int(x) for x in best))

    # Reserve 60% of remaining time for polishing, 40% for a final polish
    # of the overall best.
    polish_budget = 0.6 * remaining
    final_budget = 0.4 * remaining

    # Weight slices: better seeds get more time (linearly).
    K2 = len(affine_top)
    weights = [K2 - i for i in range(K2)]
    total_w = sum(weights)

    best_global = affine_top[0][1]
    best_global_score = affine_top[0][0]

    polish_end_all = time.time() + polish_budget
    for i, (s0, A0) in enumerate(affine_top):
        if time.time() >= polish_end_all:
            break
        slice_time = polish_budget * weights[i] / total_w
        t_end = min(polish_end_all, time.time() + slice_time)
        cand, s = _polish(A0, t_end, best_global, best_global_score)
        if s > best_global_score:
            best_global, best_global_score = cand, s

    # ----- Phase 4: final polish of the best overall -----
    if time.time() < deadline:
        cand, s = _polish(best_global, deadline, best_global, best_global_score)
        if s > best_global_score:
            best_global, best_global_score = cand, s

    if not best_global:
        best_global = [0, 1, 3, 7, 12, 20]

    return sorted(set(int(x) for x in best_global))


if __name__ == "__main__":
    import time as _t
    t0 = _t.time()
    res = solve()
    print("n=", len(res), "score=", _score(res), "time=", _t.time() - t0)
# EVOLVE-BLOCK-END
