# EVOLVE-BLOCK-START
"""Sidon-set seed (Singer / Bose-Chowla style) + exhaustive interior repair
for maximizing log|A-A|/log|A+A| with a bonus for larger sets."""
import math
import random
import time


def _parts(a):
    """Return (|A-A|, |A+A|, n) for a set a."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0, 0, n
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums), n


def _score(a):
    ld, ls, n = _parts(a)
    if n < 2 or ld < 2 or ls < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _score_parts(ld, ls, n):
    if n < 2 or ld < 2 or ls < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def singer_sidon(p):
    """Erdos-Turan / Singer style Sidon set on the integers:
    A = { 2*p*i + (i*i mod p) : i = 0..p-1 }.
    For prime p this is a B_2 set: all pairwise sums a_i + a_j (i<=j) are
    distinct, giving |A - A| = n*(n-1) + 1 (near-maximal) while the set
    stays compact (diameter ~ 2*p^2), keeping |A + A| small."""
    return sorted({2 * p * i + (i * i) % p for i in range(p)})


def _repair(A, deadline):
    """Exhaustive interior insertion search over the gap structure of A.

    For each candidate x in [min(A), max(A)] not already in A, compute the
    exact new |A+A| and |A-A| (O(n^2) each) and accept the insertion that
    most improves the score. Stop when no insertion improves or time runs out.
    """
    A = sorted(set(A))
    if len(A) < 2:
        return A
    ld, ls, n = _parts(A)
    cur_score = _score_parts(ld, ls, n)
    aset = set(A)
    while time.time() < deadline:
        lo, hi = A[0], A[-1]
        best_gain = 0.0
        best_x = None
        # Enumerate every interior integer not already present.
        for x in range(lo, hi + 1):
            if x in aset:
                continue
            cand = A + [x]
            cld, cls, cn = _parts(cand)
            cs = _score_parts(cld, cls, cn)
            g = cs - cur_score
            if g > best_gain:
                best_gain = g
                best_x = x
                best_ld, best_ls = cld, cls
            if time.time() >= deadline:
                break
        if best_x is None:
            break
        A.append(best_x)
        A.sort()
        aset.add(best_x)
        ld, ls = best_ld, best_ls
        n = len(A)
        cur_score = _score_parts(ld, ls, n)
    return A


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 110

    # Seed with Sidon constructions for a range of primes. Larger primes give
    # larger n, which improves both |A-A| and the (1 - 1/n) bonus.
    primes = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59,
              61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127,
              131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191,
              193, 197, 199, 211, 223, 227, 229, 233, 239, 251, 257, 263,
              269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337,
              347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409,
              419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479,
              487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569,
              571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641,
              643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719,
              727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809,
              811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881,
              883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971,
              977, 983, 991, 997]

    best = None
    best_score = -1.0
    best_ls = None
    for p in primes:
        A = singer_sidon(p)
        if len(A) < 2:
            continue
        ld, ls, n = _parts(A)
        s = _score_parts(ld, ls, n)
        if s > best_score or (s == best_score and best_ls is not None and ls < best_ls):
            best = A[:]
            best_score = s
            best_ls = ls

    # Fallback compact baseline.
    compact = [7, 15, 18, 22, -3, -2]
    s = _score(compact)
    if best is None or s > best_score:
        best = compact[:]
        best_score = s

    # Exhaustive interior repair on the best seed.
    if best is not None and time.time() < deadline:
        cand = _repair(best, deadline)
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s

    return sorted(set(best))
# EVOLVE-BLOCK-END