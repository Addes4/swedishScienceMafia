# EVOLVE-BLOCK-START
"""Sidon-set construction (Singer / Bose-Chowla style) + local search polishing
for maximizing log|A-A|/log|A+A| with a bonus for larger sets."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2 or len(diffs) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def singer_sidon(p):
    """Erdos-Turan / Singer style Sidon set on the integers:
    A = { 2*p*i + (i*i mod p) : i = 0..p-1 }.
    For prime p this is a B_2 set: all pairwise sums a_i + a_j (i<=j) are
    distinct, hence all positive differences are distinct, giving
    |A - A| = n*(n-1) + 1 (near-maximal). The set is also quite compact
    (diameter ~ 2*p^2), which tends to keep |A + A| small."""
    A = []
    for i in range(p):
        A.append(2 * p * i + (i * i) % p)
    return sorted(set(A))


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _polish(A, deadline, rng):
    """Greedy improving-moves local search. Only accepts strictly improving
    moves (plus a tiny SA acceptance early on) so the Sidon structure is not
    destroyed. Move types: shift an element, add an element, remove an element."""
    A = sorted(set(A))
    if len(A) < 2:
        return A
    best = A[:]
    best_s = _score(best)
    cur = A[:]
    cur_s = best_s
    start = time.time()
    total = max(0.001, deadline - start)
    T0 = 0.05
    while time.time() < deadline:
        t = (time.time() - start) / total
        T = T0 * (0.001 / T0) ** min(1.0, max(0.0, t))
        cand = cur[:]
        r = rng.random()
        if r < 0.7:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-3, -2, -1, 1, 2, 3, -5, 5])
        elif r < 0.85 and len(cand) < 4000:
            lo, hi = min(cand), max(cand)
            cand.append(rng.randint(lo - 5, hi + 5))
        elif len(cand) > 3:
            i = rng.randrange(len(cand))
            cand.pop(i)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_s or rng.random() < math.exp((s - cur_s) / max(T, 1e-9)):
            cur = cand
            cur_s = s
            if s > best_s:
                best = cand[:]
                best_s = s
    return best


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 25
    rng = random.Random(20240607)

    # Seed with Sidon constructions for a range of primes. Larger primes give
    # larger n, which improves both |A-A| and the (1 - 1/n) bonus.
    best = None
    best_score = -1.0
    primes = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59,
              61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127,
              131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191,
              193, 197, 199, 211, 223, 227, 229, 233, 239, 251, 257, 263,
              269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337,
              347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409,
              419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479,
              487, 491, 499]
    for p in primes:
        A = singer_sidon(p)
        if len(A) < 2:
            continue
        s = _score(A)
        if s > best_score:
            best_score = s
            best = A[:]

    # Also try the compact baseline set as a fallback.
    compact = [7, 15, 18, 22, -3, -2]
    s = _score(compact)
    if s > best_score:
        best_score = s
        best = compact[:]

    # Polish the best construction with improving-moves local search.
    if best is not None and time.time() < deadline:
        cand = _polish(best, deadline, rng)
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s

    return sorted(set(best))
# EVOLVE-BLOCK-END