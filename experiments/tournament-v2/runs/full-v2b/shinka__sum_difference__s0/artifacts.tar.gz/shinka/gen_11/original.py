# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _construct_powers(base, n):
    """Geometric progression: {0} + {base^i : i=0..n-1}."""
    return [0] + [base ** i for i in range(n)]


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 100

    # Try several geometric-progression constructions.
    best = None
    best_score = -1.0
    for base in (2, 3, 4, 5, 6, 7, 8, 10, 12, 16):
        for n in range(2, 60):
            cand = _construct_powers(base, n)
            if max(abs(x) for x in cand) > 10**15:
                break
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s

    # Also try symmetric-ish sets around zero using powers.
    for base in (2, 3, 4, 5):
        for n in range(2, 55):
            cand = [-(base ** i) for i in range(n)] + [base ** i for i in range(n)]
            if max(abs(x) for x in cand) > 10**15:
                break
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s

    cur = best[:]
    # Local search refinement.
    while time.time() < deadline:
        cand = cur[:]
        if random.random() < 0.6 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-1, 1])
        elif random.random() < 0.8:
            cand.append(random.randint(-50, 50))
        elif len(cand) > 3:
            cand = cand[1:]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= best_score:
            best, best_score, cur = cand[:], s, cand
        elif random.random() < 0.02:
            cur = best[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END