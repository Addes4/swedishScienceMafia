# EVOLVE-BLOCK-START
"""Sidon (B_2) construction: quadratic sets minimize |A+A| while keeping |A-A| large."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _build_sidon(n, D):
    """A = {i + D*i*i : i=0..n-1}. Quadratic term makes sums nearly unique."""
    return [i + D * i * i for i in range(n)]


def _build_mod_sidon(n, p, scale):
    """Finite-field Sidon: map (i + i*i) mod p into a wide integer range."""
    return [((i * (i + 1)) % p) * scale + i for i in range(n)]


def _local_refine(A, deadline, budget_frac=0.6):
    """Hill climb that only accepts non-worsening moves; occasional restarts."""
    A = list(set(A))
    best = A[:]
    best_score = _score(best)
    cur = A[:]
    cur_score = best_score
    step = 1
    no_improve = 0
    t_end = time.time() + (deadline - time.time()) * budget_frac
    while time.time() < t_end:
        cand = cur[:]
        r = random.random()
        if r < 0.7 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif r < 0.9:
            cand.append(random.randint(-step * 10, step * 10))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            no_improve = 0
            if s > best_score:
                best, best_score = cand[:], s
        else:
            no_improve += 1
            if no_improve > 300:
                step = max(1, min(step * 2, 64))
                no_improve = 0
            if random.random() < 0.05:
                cur, cur_score = best[:], best_score
    return best, best_score


def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A|."""
    random.seed(20240607)
    deadline = time.time() + 100

    best = None
    best_score = -1.0
    LIMIT = 10 ** 15

    # Quadratic Sidon sets A = {i + D*i^2}.
    for n in range(3, 120):
        for D in (1, 2, 3, 4, 8, 16, 32, 64, 128, 256, 1024, 4096, 65536):
            cand = _build_sidon(n, D)
            if cand[-1] > LIMIT:
                break
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s
        if time.time() > deadline * 0.4:
            break

    # Finite-field Sidon variants mapped into a wide range.
    primes = [97, 193, 389, 769, 1543, 3079, 6151, 12289, 24593, 49157]
    for n in range(3, 80):
        for p in primes:
            if p < n:
                continue
            for scale in (1, 7, 1000, 10 ** 6):
                cand = _build_mod_sidon(n, p, scale)
                if max(abs(x) for x in cand) > LIMIT:
                    continue
                s = _score(cand)
                if s > best_score:
                    best, best_score = cand[:], s
        if time.time() > deadline * 0.7:
            break

    # Refine the best construction.
    if best is not None and time.time() < deadline:
        best, best_score = _local_refine(best, deadline, budget_frac=0.9)

    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END