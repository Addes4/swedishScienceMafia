# EVOLVE-BLOCK-START
"""Hybrid: Sidon/B2 seeds + affine sweep + lexicographic anneal + boundary repair.

Combines:
  - Strong Sidon/B2 seed constructions (quadratic, modular, greedy).
  - Affine sweep (scale/shift) to improve seeds.
  - Lexicographic annealing with key (ratio, -|A+A|, n).
  - Boundary remove-and-replace refinement for local search.
"""
import math
import random
import time


# ---------- scoring ----------

def _stats(a):
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0, 0, 0
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _score(a):
    return _stats(a)[0]


def _key(a):
    """Lexicographic key: (ratio, -|A+A|, n)."""
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return (-1.0, 0, 0)
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return (-1.0, 0, 0)
    ratio = math.log(len(diffs)) / math.log(len(sums))
    return (ratio, -len(sums), n)


# ---------- B2 helpers ----------

def _is_b2(A):
    s = set()
    n = len(A)
    for i in range(n):
        ai = A[i]
        for j in range(i, n):
            v = ai + A[j]
            if v in s:
                return False
            s.add(v)
    return True


# ---------- seed constructions ----------

def _quad(n, M):
    return [i * (1 + M * i) for i in range(n)]


def _mod_sidon(n, p, scale):
    return [((i * (i + 1)) % p) * scale + i for i in range(n)]


def _greedy_b2(n, cap=10**7):
    A = [0]
    used = {0}
    cand = 1
    while len(A) < n and cand <= cap:
        new = []
        ok = True
        for x in A:
            s = x + cand
            if s in used or s in new:
                ok = False
                break
            new.append(s)
        if ok:
            A.append(cand)
            used.update(new)
            used.add(2 * cand)
        cand += 1
    return A


def _build_pow2(n):
    return [0] + [2 ** i for i in range(n)]


def _primitive_root(m):
    """Find a primitive root modulo m (m assumed to be of small size)."""
    if m <= 1:
        return None
    # factor m
    factors = []
    x = m
    d = 2
    while d * d <= x:
        if x % d == 0:
            factors.append(d)
            while x % d == 0:
                x //= d
        d += 1
    if x > 1:
        factors.append(x)
    for g in range(2, m):
        ok = True
        for f in factors:
            if pow(g, m // f, m) == 1:
                ok = False
                break
        if ok:
            return g
    return None


def _bose_chowla(p):
    """Bose-Chowla Sidon set modulo p^2 - 1 for prime p.

    A = { i : g^i ≡ i + 1 (mod p^2 - 1), 0 <= i < p^2 - 1 }
    where g is a primitive root modulo p^2 - 1.
    Typically yields exactly p elements, forming a Sidon (B2) set.
    """
    m = p * p - 1
    if m < 3 or m > 30000:
        return []
    g = _primitive_root(m)
    if g is None:
        return []
    A = []
    for i in range(m):
        if pow(g, i, m) == (i + 1) % m:
            A.append(i)
    if len(A) < p:
        return []
    return A
=======


# ---------- phase 1: seed pool ----------

def _seed_pool(start, budget_frac=0.45):
    LIMIT = 10 ** 15
    deadline = start + budget_frac * 110
    pool = []

    def _add(seed):
        if not seed or len(seed) < 2:
            return
        if max(abs(x) for x in seed) > LIMIT:
            return
        pool.append((_score(seed), list(set(int(x) for x in seed))))

    # 1a. quadratic Sidon family
    for n in range(4, 160):
        for M in (1, 2, 3, 4, 5, 7, 8, 11, 13, 16, 17, 23, 31, 32, 41, 61, 64,
                  128, 256, 512, 1024, 4096, 65536):
            cand = _quad(n, M)
            if cand[-1] > LIMIT:
                break
            _add(cand)
        if time.time() > start + 0.25 * (deadline - start):
            break

    # 1b. finite-field Sidon variants
    primes = [97, 193, 389, 769, 1543, 3079, 6151, 12289, 24593, 49157,
              98317, 196613, 393241, 786433]
    for n in range(4, 120):
        for p in primes:
            if p < n:
                continue
            for scale in (1, 7, 1000, 10 ** 6, 10 ** 9, 10 ** 12):
                cand = _mod_sidon(n, p, scale)
                if max(abs(x) for x in cand) > LIMIT:
                    continue
                _add(cand)
        if time.time() > start + 0.65 * (deadline - start):
            break

    # 1b2. Bose-Chowla Sidon seeds (tight diameter, B2-optimal)
    bc_primes = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53,
                 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109,
                 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173]
    for p in bc_primes:
        if time.time() > start + 0.75 * (deadline - start):
            break
        cand = _bose_chowla(p)
        if cand:
            _add(cand)
            # also add scaled versions to push into a large range
            for scale in (10 ** 6, 10 ** 9, 10 ** 12):
                scaled = [x * scale for x in cand]
                if max(abs(x) for x in scaled) <= LIMIT:
                    _add(scaled)

    # 1c. greedy B2 seeds
    for n in (6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64, 80):
        if time.time() > deadline:
            break
        _add(_greedy_b2(n))

    # 1d. shifted powers-of-2
    for n in (8, 16, 32, 64, 100):
        if time.time() > deadline:
            break
        _add(_build_pow2(n))

    if not pool:
        pool.append((_score([0, 1, 3, 7, 12, 20]), [0, 1, 3, 7, 12, 20]))
    return pool


# ---------- phase 2: top-K selection ----------

def _select_topk(pool, K=12):
    pool.sort(key=lambda t: -t[0])
    return pool[:K]


# ---------- phase 3: affine sweep ----------

def _best_affine(seed, deadline, scales=(1, 2, 3, 5, 7, 11, 13, 17, 31, 61)):
    best = list(set(int(x) for x in seed))
    best_score = _score(best)
    if len(best) < 2:
        return best, best_score
    for scale in scales:
        if time.time() > deadline:
            break
        scaled = [x * scale for x in seed]
        mid = (max(scaled) + min(scaled)) // 2
        for shift in (0, -mid, -min(scaled), -max(scaled), -mid // 2, -mid // 3):
            cand = [x + shift for x in scaled]
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s
    return best, best_score


def _affine_sweep(top, start, budget_frac=0.12):
    deadline = start + budget_frac * 110
    out = []
    for s0, A0 in top:
        if time.time() > deadline:
            out.append((s0, A0))
            continue
        cand, s = _best_affine(A0, deadline)
        out.append((s, cand))
    out.sort(key=lambda t: -t[0])
    return out


# ---------- boundary remove-and-replace refinement ----------

def _boundary_repair(A, deadline, best_global=None, best_global_key=None):
    """Delete a boundary element and re-insert at a position that improves the key."""
    A = sorted(set(int(x) for x in A))
    if len(A) < 4:
        k = _key(A)
        return A, _score(A), k
    best = A[:]
    best_key = _key(best)
    best_score = _score(best)
    if best_global is not None and best_global_key is not None:
        if best_global_key > best_key:
            best, best_key = best_global[:], best_global_key
            best_score = _score(best)
    n = len(A)

    while time.time() < deadline:
        improved = False
        order = sorted(range(n), key=lambda i: -abs(A[i] - (A[0] + A[-1]) / 2))
        for idx in order[:4]:
            if time.time() > deadline:
                break
            base = A[:idx] + A[idx + 1:]
            lo = min(base)
            hi = max(base)
            span = hi - lo
            cands = set()
            step = max(1, span // (4 * n))
            x = lo
            while x <= hi:
                cands.add(x)
                x += step
            for frac in (0.5, 0.25, 0.75):
                cands.add(lo + int(frac * span))
            cands.add(hi + 1)
            cands.add(lo - 1)
            cands.add((lo + hi) // 2)

            for c in cands:
                if c in base:
                    continue
                cand = base + [c]
                ck = _key(cand)
                if ck > best_key:
                    best, best_key = cand[:], ck
                    best_score = _score(cand)
                    A = sorted(set(cand))
                    n = len(A)
                    improved = True
                    break
            if improved:
                break
        if not improved:
            if time.time() > deadline:
                break
            cand = A[:]
            i = random.randrange(len(cand))
            lo, hi = min(cand), max(cand)
            span = hi - lo
            cand[i] += random.randint(-max(1, span // (4 * n)), max(1, span // (4 * n)))
            cand = list(set(cand))
            if len(cand) < 4:
                continue
            ck = _key(cand)
            if ck > best_key:
                best, best_key = cand[:], ck
                best_score = _score(cand)
                A = sorted(set(cand))
                n = len(A)
            elif random.random() < 0.05:
                A = sorted(set(cand))
                n = len(A)
    return best, best_score, best_key


# ---------- lexicographic annealing repair ----------

def _repair(A, t_end, best_global=None, best_global_key=None):
    A = list(set(int(x) for x in A))
    if len(A) < 2:
        k = _key(A)
        return A, _score(A), k
    best = A[:]
    best_key = _key(best)
    best_score = _score(best)
    if best_global is not None and best_global_key is not None:
        if best_global_key > best_key:
            best, best_key = best_global[:], best_global_key
            best_score = _score(best)
    cur = A[:]
    cur_key = best_key
    cur_score = best_score

    span = max(cur) - min(cur) + 1
    T0 = max(0.5, 0.02 * span)
    Tmin = 1e-3
    now = time.time()
    total = max(1.0, t_end - now)
    no_improve = 0

    while time.time() < t_end:
        frac = 1.0 - (t_end - time.time()) / total
        T = max(Tmin, T0 * (1.0 - frac))
        cand = cur[:]
        op = random.random()
        if op < 0.60 and len(cand) > 2:
            i = random.randrange(len(cand))
            step = max(1, int(T * random.uniform(0.5, 2.0)))
            cand[i] += random.randint(-step, step)
        elif op < 0.80:
            cand.append(random.randint(-int(2 * T), int(2 * T)))
        elif op < 0.90:
            if len(cand) > 3:
                mid = (max(cand) + min(cand)) // 2
                order = sorted(range(len(cand)),
                               key=lambda j: -abs(cand[j] - mid))
                k = min(5, len(order))
                del cand[order[random.randrange(k)]]
        else:
            # boundary replace
            if len(cand) > 3:
                mid = (max(cand) + min(cand)) // 2
                order = sorted(range(len(cand)),
                               key=lambda j: -abs(cand[j] - mid))
                idx = order[random.randrange(min(4, len(order)))]
                cand.pop(idx)
                lo, hi = min(cand), max(cand)
                cand.append(lo + random.randint(0, max(1, hi - lo)))
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        c_key = _key(cand)
        c_score = _score(cand)
        if c_key > cur_key:
            cur, cur_key, cur_score = cand, c_key, c_score
            no_improve = 0
            if c_key > best_key:
                best, best_key, best_score = cand[:], c_key, c_score
        else:
            delta = c_score - cur_score
            if delta > -1e-9 or random.random() < math.exp(delta / max(T, 1e-6)):
                cur, cur_key, cur_score = cand, c_key, c_score
            no_improve += 1
            if no_improve > 400:
                cur, cur_key, cur_score = best[:], best_key, best_score
                no_improve = 0
    return best, best_score, best_key


# ---------- driver ----------

def solve():
    random.seed(20240517)
    start = time.time()
    deadline = start + 110

    # Phase 1: build a large pool of seeds.
    pool = _seed_pool(start, budget_frac=0.40)

    # Phase 2: keep the top-K.
    top = _select_topk(pool, K=12)

    # Phase 3: affine sweep each of the top-K.
    affine_top = _affine_sweep(top, start, budget_frac=0.12)

    remaining = max(0.0, deadline - time.time())
    if remaining < 0.5:
        best = affine_top[0][1] if affine_top else [0, 1, 3, 7, 12, 20]
        return sorted(set(int(x) for x in best))

    # Phase 4: split remaining time between lexicographic anneal and boundary repair.
    anneal_budget = 0.55 * remaining
    boundary_budget = 0.25 * remaining
    final_budget = 0.20 * remaining

    best_global = affine_top[0][1]
    best_global_score = affine_top[0][0]
    best_global_key = _key(best_global)

    # Phase 4a: uniform slice per top-K seed with lexicographic anneal.
    K2 = len(affine_top)
    slice_time = anneal_budget / K2 if K2 > 0 else anneal_budget
    anneal_end_all = time.time() + anneal_budget

    for s0, A0 in affine_top:
        if time.time() >= anneal_end_all:
            break
        t_end = min(anneal_end_all, time.time() + slice_time)
        cand, s, k = _repair(A0, t_end, best_global, best_global_key)
        if k > best_global_key:
            best_global, best_global_score, best_global_key = cand, s, k

    # Phase 4b: boundary repair on the current best.
    if time.time() < deadline and boundary_budget > 0.5:
        b_end = min(deadline, time.time() + boundary_budget)
        cand, s, k = _boundary_repair(best_global, b_end,
                                      best_global, best_global_key)
        if k > best_global_key:
            best_global, best_global_score, best_global_key = cand, s, k

    # Phase 4c: final lexicographic anneal polish.
    if time.time() < deadline:
        cand, s, k = _repair(best_global, deadline,
                             best_global, best_global_key)
        if k > best_global_key:
            best_global, best_global_score, best_global_key = cand, s, k

    if not best_global:
        best_global = [0, 1, 3, 7, 12, 20]

    return sorted(set(int(x) for x in best_global))


if __name__ == "__main__":
    import time as _t
    t0 = _t.time()
    res = solve()
    print("n=", len(res), "score=", _score(res), "time=", _t.time() - t0)
# EVOLVE-BLOCK-END