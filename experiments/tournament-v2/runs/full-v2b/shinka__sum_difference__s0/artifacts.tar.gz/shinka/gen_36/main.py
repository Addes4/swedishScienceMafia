# EVOLVE-BLOCK-START
"""Crossover: algebraic Sidon seeds + Sidon-preserving repair + SA refinement.

Combines:
  * quadratic Sidon seeds and geometric-progression seeds (script A),
  * modulus-based quadratic Sidon seeds (script B),
  * lexicographic key (ratio, -|A+A|, n) (script A),
  * Sidon-preserving repair (script A),
  * simulated annealing with reheats (script A),
  * adaptive geometric hill climbing (script B) as a cheap polish stage.
"""
import math
import random
import time


# ---------------------------------------------------------------- scoring

def _stats(a):
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) < 2:
        return 0.0, len(diffs), len(sums)
    ratio = math.log(len(diffs)) / math.log(len(sums))
    score = ratio + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _score(a):
    return _stats(a)[0]


def _key(a):
    """Lexicographic key: (ratio, -|A+A|, n)."""
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return (-1.0, 0, 0)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return (-1.0, 0, 0)
    ratio = math.log(len(diffs)) / math.log(len(sums))
    return (ratio, -len(sums), n)


# ---------------------------------------------------------------- Sidon seeds

def _sidon_quadratic(n, M):
    """A = { i * (1 + M*i) : i=0..n-1 } -- quadratic Sidon-like set."""
    return [i * (1 + M * i) for i in range(n)]


def _powers_set(base, n):
    """{0, 1, base, base^2, ..., base^(n-1)}."""
    A = [0, 1]
    v = 1
    for _ in range(n - 2):
        v *= base
        A.append(v)
    return A


def _build_sidon(n, mult=1, shift=0, mod=None):
    """Quadratic-modulus Sidon-like construction (script B)."""
    if mod is None:
        mod = max(3, n * n + 1)
    A = []
    for i in range(n):
        v = (i * mult + i * i + shift) % mod
        A.append(v)
    return A


def _is_sidon(A):
    n = len(A)
    seen = set()
    for i in range(n):
        ai = A[i]
        for j in range(i + 1, n):
            d = ai - A[j]
            if d in seen:
                return False
            seen.add(d)
    return True


# ---------------------------------------------------------------- repair

def _repair(A, deadline, rounds=400):
    """Sidon-preserving lexicographic repair (script A)."""
    A = sorted(set(int(x) for x in A))
    if len(A) < 3:
        return A
    best = A[:]
    best_key = _key(best)

    for _ in range(rounds):
        if time.time() > deadline:
            break
        cur = best[:]
        n_cur = len(cur)
        mid = (cur[0] + cur[-1]) // 2
        order = sorted(range(n_cur), key=lambda i: -abs(cur[i] - mid))
        victim_idx = order[random.randrange(min(5, n_cur))]
        victim = cur[victim_idx]
        cur = cur[:victim_idx] + cur[victim_idx + 1:]
        if len(cur) < 2:
            continue
        lo = cur[0]
        hi = cur[-1]

        cands = set()
        cands.add(lo)
        cands.add(lo + 1)
        cands.add(lo + 2)
        cands.add(hi + 1)
        cands.add(hi + 2)
        cands.add(victim - 1)
        cands.add(victim - 2)
        cands.add(victim + 1)
        cands.add(victim + 2)
        cands.add(mid)
        cands.add(mid - 1)
        cands.add(mid + 1)
        for k in range(1, 8):
            cands.add(lo + (hi - lo) * k // 8)
        for _t in range(8):
            cands.add(victim + random.randint(-4, 4))

        improved = False
        for x in cands:
            if x in cur:
                continue
            trial = sorted(cur + [x])
            if not _is_sidon(trial):
                continue
            k = _key(trial)
            if k > best_key:
                best = trial
                best_key = k
                improved = True
                break
        if not improved:
            hi_lo_span = max(1, hi - lo)
            for _try in range(60):
                if time.time() > deadline:
                    break
                x = random.randint(lo, hi + 1)
                if x in cur:
                    continue
                trial = sorted(cur + [x])
                if not _is_sidon(trial):
                    continue
                k = _key(trial)
                if k > best_key:
                    best = trial
                    best_key = k
                    improved = True
                    break
            if not improved:
                break
    return best


# ---------------------------------------------------------------- hill climb (script B)

def _local_refine(A, deadline, budget_frac=0.35):
    """Adaptive geometric hill climbing (script B), lexicographic key."""
    A = list(set(int(x) for x in A))
    if len(A) < 2:
        return A
    best = A[:]
    best_key = _key(best)
    cur = A[:]
    cur_key = best_key
    step = max(1, int(0.05 * (max(cur) - min(cur) + 1)) if len(cur) > 1 else 3)
    no_improve = 0
    t_end = time.time() + max(0.0, (deadline - time.time()) * budget_frac)
    while time.time() < t_end:
        cand = cur[:]
        op = random.random()
        if op < 0.70 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif op < 0.90:
            cand.append(random.randint(-step * 4, step * 4))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        k = _key(cand)
        if k > cur_key:
            cur, cur_key = cand, k
            no_improve = 0
            if k > best_key:
                best, best_key = cand[:], k
        else:
            no_improve += 1
            if no_improve > 150:
                step = max(1, step // 2)
                no_improve = 0
            if random.random() < 0.05:
                cur, cur_key = best[:], best_key
    return best


# ---------------------------------------------------------------- annealing (script A)

def _anneal(A, deadline, budget_frac=0.85):
    A = list(set(int(x) for x in A))
    if len(A) < 2:
        return A
    best = A[:]
    best_key = _key(best)
    cur = A[:]
    cur_key = best_key
    t_end = time.time() + max(0.0, (deadline - time.time()) * budget_frac)

    span = max(cur) - min(cur) + 1
    T0 = max(0.5, 0.015 * span)
    Tmin = 1e-3
    total = max(1e-6, t_end - time.time())
    no_improve = 0

    while time.time() < t_end:
        frac = 1.0 - (t_end - time.time()) / total
        T = max(Tmin, T0 * (1.0 - frac))
        cand = cur[:]
        op = random.random()
        if op < 0.60 and len(cand) > 2:
            i = random.randrange(len(cand))
            step = max(1, int(T * random.uniform(0.5, 2.0)))
            cand[i] += random.randint(-step, step)
        elif op < 0.80:
            cand.append(random.randint(-int(3 * T), int(3 * T)))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        k = _key(cand)
        s = _score(cand)
        cur_s = _score(cur)
        if k > cur_key:
            cur, cur_key = cand, k
            no_improve = 0
            if k > best_key:
                best, best_key = cand[:], k
        else:
            delta = s - cur_s
            if delta > -1e-9 or random.random() < math.exp(delta / max(T, 1e-6)):
                cur, cur_key = cand, k
            no_improve += 1
            if no_improve > 500:
                cur, cur_key = best[:], best_key
                T0 *= 1.5
                no_improve = 0
    return best


# ---------------------------------------------------------------- driver

def solve():
    random.seed(20240517)
    start = time.time()
    deadline = start + 110

    best = [7, 15, 18, 22, -3, -2]
    best_key = _key(best)

    # ----- Phase 1: build a pool of distinct algebraic seeds -----
    pool = []
    seen = set()

    def _add(A):
        if not A or len(A) < 2:
            return
        A = tuple(sorted(set(int(x) for x in A)))
        if A in seen:
            return
        seen.add(A)
        k = _key(list(A))
        pool.append((k, list(A)))

    # 1a. quadratic Sidon seeds
    sizes = [8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512]
    for n in sizes:
        for M in [1, 2, 3, 5, 7, 11, 13, 17, 23, 31, 41, 61]:
            A = _sidon_quadratic(n, M)
            if max(A) > 10**14:
                break
            _add(A)
        if time.time() > start + 15:
            break

    # 1b. geometric-progression candidates
    for base in (2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 32):
        for n in range(2, 55):
            A = _powers_set(base, n)
            if max(A) > 10**14:
                break
            _add(A)

    # 1c. modulus-based Sidon seeds (script B)
    for n in (16, 32, 64, 96, 128, 192, 256, 384, 512):
        for mult in (1, 2, 3, 5, 7):
            for shift in (0, 1, 3):
                mod = max(3, n * n + 1)
                A = _build_sidon(n, mult=mult, shift=shift, mod=mod)
                _add(A)
        if time.time() > start + 25:
            break

    if not pool:
        pool.append((best_key, best[:]))

    # ----- Phase 2: keep top-K seeds, short repair slice each -----
    pool.sort(key=lambda t: t[0], reverse=True)
    K = 10
    top = pool[:K]

    remaining = max(0.0, deadline - time.time())
    repair_budget = 0.22 * remaining
    short_anneal_budget = 0.30 * remaining
    final_budget = 0.48 * remaining

    repair_end = time.time() + repair_budget
    repaired_top = []
    K2 = max(1, len(top))
    slice_repair = repair_budget / K2
    for k0, A0 in top:
        if time.time() >= repair_end:
            repaired_top.append((k0, A0))
            continue
        t_end = min(repair_end, time.time() + slice_repair)
        cand = _repair(A0, t_end)
        k = _key(cand)
        if k > k0:
            repaired_top.append((k, cand))
        else:
            repaired_top.append((k0, A0))
    repaired_top.sort(key=lambda t: t[0], reverse=True)

    # ----- Phase 3: quick hill climb + short anneal slices -----
    short_anneal_end = time.time() + short_anneal_budget
    annealed_top = []
    slice_anneal = short_anneal_budget / K2
    for k0, A0 in repaired_top:
        if time.time() >= short_anneal_end:
            annealed_top.append((k0, A0))
            continue
        t_end = min(short_anneal_end, time.time() + slice_anneal)
        half = time.time() + 0.5 * max(0.0, t_end - time.time())
        cand = _local_refine(A0, half, budget_frac=1.0)
        cand = _anneal(cand, t_end, budget_frac=1.0)
        k = _key(cand)
        if k > k0:
            annealed_top.append((k, cand))
        else:
            annealed_top.append((k0, A0))
    annealed_top.sort(key=lambda t: t[0], reverse=True)

    if annealed_top:
        best, best_key = annealed_top[0][1], annealed_top[0][0]

    # ----- Phase 4: final hill climb + anneal on the overall best -----
    if time.time() < deadline:
        half = time.time() + 0.25 * max(0.0, deadline - time.time())
        polished = _local_refine(best, half, budget_frac=1.0)
        kp = _key(polished)
        if kp > best_key:
            best, best_key = polished, kp
        annealed = _anneal(best, deadline, budget_frac=1.0)
        k = _key(annealed)
        if k > best_key:
            best, best_key = annealed, k

    return sorted(set(int(x) for x in best))


if __name__ == "__main__":
    import time as _t
    t0 = _t.time()
    res = solve()
    print("n=", len(res), "score=", _score(res), "time=", _t.time() - t0)
# EVOLVE-BLOCK-END
