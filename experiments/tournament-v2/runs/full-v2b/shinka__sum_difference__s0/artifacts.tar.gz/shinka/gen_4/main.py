# EVOLVE-BLOCK-START
"""Baseline: random local search over small integer sets (the official starting program, shortened)."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _fast_score(a):
    """Compute the log-ratio score for a set a (list of distinct ints)."""
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1 or ld <= 1:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _build_initial(n, step=1000, spread=3):
    """Build an AP-like set with a large common step and small perturbations.
    This gives small |A+A| (few sum collisions) while spreading differences."""
    base = []
    for i in range(n):
        base.append(i * step + random.randint(-spread, spread))
    # ensure distinctness
    base = sorted(set(base))
    return base


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    random.seed(12345)
    deadline = time.time() + 110

    # Try several initial sizes and step scales, keep the best.
    best = None
    best_score = -1.0

    # Candidate initial configurations: (n, step, spread)
    configs = []
    # Pure arithmetic progression with large step gives |A+A| = 2n-1 small.
    # Larger n -> better ratio (log(n^2)/log(2n) -> 2), but need perturbation
    # to keep differences large.
    for n in (50, 100, 200, 400, 800, 1600, 3000):
        for step in (1, 10, 1000, 100000, 10**7, 10**10):
            configs.append((n, step, 1))
    random.shuffle(configs)

    for (n, step, spread) in configs:
        if time.time() > deadline:
            break
        cand = _build_initial(n, step, spread)
        s = _fast_score(cand)
        if s > best_score:
            best, best_score = cand[:], s

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _fast_score(best)

    cur = best[:]
    cur_score = best_score

    # Targeted local search: try to modify elements to improve the score.
    # Moves: perturb an element, swap an element far away, or shift the whole
    # set's perturbation pattern.
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        op = random.random()
        if op < 0.5:
            # perturb one element
            i = random.randrange(len(cand))
            cand[i] += random.randint(-10, 10)
        elif op < 0.85:
            # replace an element with a far-away value to expand differences
            i = random.randrange(len(cand))
            cand[i] = random.randint(-10**12, 10**12)
        else:
            # shift a contiguous block
            i = random.randrange(len(cand))
            j = min(len(cand), i + random.randint(1, 20))
            delta = random.randint(-100, 100)
            for k in range(i, j):
                cand[k] += delta
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _fast_score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.05:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END