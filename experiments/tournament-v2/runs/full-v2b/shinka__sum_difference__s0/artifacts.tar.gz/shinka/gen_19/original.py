# EVOLVE-BLOCK-START
"""Hybrid Golomb-ruler + simulated annealing approach for maximizing
log|A-A|/log|A+A| with bonus for larger sets."""

import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    ld = len(diffs)
    ls = len(sums)
    if ls < 2 or ld < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def _fast_score_parts(a):
    """Return (len_diff, len_sum, n)."""
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


def _score_from_parts(ld, ls, n):
    if ls < 2 or ld < 2 or n < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def greedy_sidon(target_size, max_val):
    """Greedy Mian-Chowla style: build a set where all positive differences are unique.
    This maximizes |A-A| (gives ~n^2 distinct differences)."""
    A = [0]
    used_diffs = {0}
    candidates = list(range(1, max_val + 1))
    while len(A) < target_size:
        found = False
        for c in candidates:
            if c in A:
                continue
            new_diffs = set()
            ok = True
            for x in A:
                d = abs(c - x)
                if d in used_diffs or d in new_diffs:
                    ok = False
                    break
                new_diffs.add(d)
            if ok:
                A.append(c)
                used_diffs |= new_diffs
                found = True
                break
        if not found:
            break
    return sorted(A)


def build_initial():
    """Build several candidate initial sets and pick the best."""
    best = None
    best_s = -1.0
    # Try various greedy Sidon sets
    for size in [8, 12, 16, 20, 25, 30]:
        for mv in [size * size, size * size * 2, size * size * 4]:
            A = greedy_sidon(size, mv)
            if len(A) < 2:
                continue
            s = _score(A)
            if s > best_s:
                best_s = s
                best = A
    # Also try a compact set
    compact = list(range(0, 12))
    s = _score(compact)
    if s > best_s:
        best_s = s
        best = compact
    # Try a set with additive structure: A = {0,1,2,...} shifted
    # Try powers-like but with collisions
    return best, best_s


def local_search(A, deadline, rng):
    """Simulated annealing with multiple move types."""
    A = sorted(set(A))
    ld, ls, n = _fast_score_parts(A)
    cur_score = _score_from_parts(ld, ls, n)
    best = A[:]
    best_score = cur_score

    # Temperature schedule
    T0 = 0.5
    T_min = 0.001
    start = time.time()
    total = max(0.001, deadline - start)

    iter_count = 0
    while time.time() < deadline:
        iter_count += 1
        t = (time.time() - start) / total
        T = T0 * (T_min / T0) ** min(1.0, t)

        move = rng.random()
        cand = A[:]
        if move < 0.5 and len(cand) > 2:
            # Shift a random element
            i = rng.randrange(len(cand))
            delta = rng.choice([-3, -2, -1, 1, 2, 3, -5, 5, -10, 10])
            cand[i] += delta
        elif move < 0.75:
            # Add an element
            if len(cand) < 4000:
                lo = min(cand) - rng.randint(1, 30)
                hi = max(cand) + rng.randint(1, 30)
                cand.append(rng.randint(lo, hi))
        elif move < 0.9 and len(cand) > 3:
            # Remove an element
            i = rng.randrange(len(cand))
            cand.pop(i)
        else:
            # Shift a whole block (translation doesn't change score, so shift by small amount)
            i = rng.randrange(len(cand))
            delta = rng.choice([-1, 1]) * rng.randint(1, 5)
            cand[i] += delta

        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        cld, cls, cn = _fast_score_parts(cand)
        cscore = _score_from_parts(cld, cls, cn)

        if cscore > cur_score or rng.random() < math.exp((cscore - cur_score) / max(T, 1e-9)):
            A = cand
            ld, ls, n = cld, cls, cn
            cur_score = cscore
            if cscore > best_score:
                best = cand[:]
                best_score = cscore
        elif rng.random() < 0.02:
            # Occasionally restart from best
            A = best[:]
            ld, ls, n = _fast_score_parts(A)
            cur_score = _score_from_parts(ld, ls, n)

    return best, best_score


def refine_shift(A, deadline):
    """Try translating the set to reduce |A+A| by making it more compact around 0.
    Actually translation doesn't change |A+A| or |A-A|, so skip."""
    return A


def compactify(A, deadline):
    """Try to reduce |A+A| by compressing the set while keeping |A-A| large.
    Strategy: try to shift individual elements to reduce the span."""
    A = sorted(set(A))
    if len(A) < 2:
        return A
    best = A[:]
    best_s = _score(best)
    rng = random.Random(12345)
    while time.time() < deadline:
        i = rng.randrange(len(A))
        cand = A[:]
        # Try moving element i to reduce overlap in sums
        span = max(A) - min(A)
        target = rng.randint(min(A), max(A))
        cand[i] = target
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > best_s:
            best = cand[:]
            best_s = s
        A = cand[:]
    return best


def solve():
    """Return a list of distinct integers A maximizing log|A-A|/log|A+A| + bonus."""
    deadline = time.time() + 110  # leave some margin
    rng = random.Random(987654321)

    # Build initial candidates
    initial, initial_score = build_initial()

    best = initial[:]
    best_score = initial_score

    # Run multiple SA restarts
    n_restarts = 0
    while time.time() < deadline - 5:
        n_restarts += 1
        if n_restarts == 1:
            start_A = initial[:]
        else:
            # Perturb best or build new
            if rng.random() < 0.5:
                start_A = best[:]
                # Random perturbation
                for _ in range(rng.randint(1, 3)):
                    if start_A and rng.random() < 0.7:
                        i = rng.randrange(len(start_A))
                        start_A[i] += rng.randint(-5, 5)
                    elif len(start_A) < 4000:
                        start_A.append(rng.randint(-50, 50))
                start_A = sorted(set(start_A))
            else:
                size = rng.randint(8, 40)
                start_A = greedy_sidon(size, size * size * rng.choice([1, 2, 4]))

        # Allocate time slice
        slice_end = min(deadline - 2, time.time() + max(3, (deadline - time.time()) / 4))
        cand, cscore = local_search(start_A, slice_end, rng)
        if cscore > best_score:
            best = cand[:]
            best_score = cscore

    # Final compaction attempt
    if time.time() < deadline:
        cand = compactify(best, deadline)
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s

    return sorted(set(best))
# EVOLVE-BLOCK-END
