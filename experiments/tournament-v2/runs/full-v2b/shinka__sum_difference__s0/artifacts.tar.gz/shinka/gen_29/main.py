# EVOLVE-BLOCK-START
"""Incremental difference/sum-map annealing for maximizing
log|A-A|/log|A+A| + (1 - 1/|A|)/100.

Key idea: maintain running multiplicity maps of differences and sums so that
each add/remove/swap move updates the objective in O(n) rather than O(n^2).
This allows far more exploration than the seed+polish approach, and directly
optimizes the tradeoff between a large difference set and a small sum set.
"""

import math
import random
import time


def _score_from_counts(nd, ns, n):
    if n < 2 or nd < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


class State:
    """Maintains A as a set plus difference/sum multiplicities.

    diff_count[d] = number of ordered pairs (a,b) in A x A with a-b == d.
    sum_count[s]  = number of ordered pairs (a,b) in A x A with a+b == s.
    |A-A| = number of keys in diff_count;  |A+A| = number of keys in sum_count.
    """

    __slots__ = ("vals", "diff_count", "sum_count", "nd", "ns")

    def __init__(self, vals):
        self.vals = list(dict.fromkeys(vals))  # distinct
        self.diff_count = {}
        self.sum_count = {}
        for a in self.vals:
            for b in self.vals:
                d = a - b
                s = a + b
                self.diff_count[d] = self.diff_count.get(d, 0) + 1
                self.sum_count[s] = self.sum_count.get(s, 0) + 1
        self.nd = len(self.diff_count)
        self.ns = len(self.sum_count)

    def score(self):
        return _score_from_counts(self.nd, self.ns, len(self.vals))

    def _apply(self, x, sign):
        """Add (sign=+1) or remove (sign=-1) element x, updating maps.
        Returns nothing; caller must ensure x not already in vals when adding
        (and present when removing)."""
        dc = self.diff_count
        sc = self.sum_count
        nd, ns = self.nd, self.ns
        for y in self.vals:
            d = x - y
            c = dc.get(d, 0) + sign
            if c == 0:
                del dc[d]
                nd -= 1
            else:
                if d not in dc:
                    nd += 1
                dc[d] = c
            d2 = y - x
            c2 = dc.get(d2, 0) + sign
            if c2 == 0:
                del dc[d2]
                nd -= 1
            else:
                if d2 not in dc:
                    nd += 1
                dc[d2] = c2
            s = x + y
            c3 = sc.get(s, 0) + sign
            if c3 == 0:
                del sc[s]
                ns -= 1
            else:
                if s not in sc:
                    ns += 1
                sc[s] = c3
            s2 = y + x
            c4 = sc.get(s2, 0) + sign
            if c4 == 0:
                del sc[s2]
                ns -= 1
            else:
                if s2 not in sc:
                    ns += 1
                sc[s2] = c4
        # self-self pairs (x,x)
        d = 0
        c = dc.get(d, 0) + sign
        if c == 0:
            del dc[d]
            nd -= 1
        else:
            if d not in dc:
                nd += 1
            dc[d] = c
        s = 2 * x
        c3 = sc.get(s, 0) + sign
        if c3 == 0:
            del sc[s]
            ns -= 1
        else:
            if s not in sc:
                ns += 1
            sc[s] = c3
        self.nd, self.ns = nd, ns

    def add(self, x):
        self._apply(x, +1)
        self.vals.append(x)

    def remove(self, x):
        self._apply(x, -1)
        self.vals.remove(x)

    def copy(self):
        st = State.__new__(State)
        st.vals = self.vals[:]
        st.diff_count = dict(self.diff_count)
        st.sum_count = dict(self.sum_count)
        st.nd = self.nd
        st.ns = self.ns
        return st


def _greedy_build(target_n, rng, max_val):
    """Build a set incrementally, each step adding the candidate that maximizes
    the running score. Candidates are drawn from a geometric-ish spread."""
    st = State([0])
    while len(st.vals) < target_n:
        best_x = None
        best_s = -1.0
        # sample candidates
        cur_min = min(st.vals)
        cur_max = max(st.vals)
        span = max(1, cur_max - cur_min)
        cands = set()
        for _ in range(40):
            mode = rng.random()
            if mode < 0.4:
                # near an existing element
                base = rng.choice(st.vals)
                cands.add(base + rng.randint(-span // 4 - 1, span // 4 + 1))
            elif mode < 0.75:
                # just outside the current range
                cands.add(cur_max + rng.randint(1, max(2, span // 2 + 1)))
                cands.add(cur_min - rng.randint(1, max(2, span // 2 + 1)))
            else:
                # wide spread
                cands.add(rng.randint(-max_val, max_val))
        for x in cands:
            if x in st.vals:
                continue
            # simulate add cost cheaply
            st.add(x)
            s = st.score()
            st.remove(x)
            if s > best_s:
                best_s = s
                best_x = x
        if best_x is None:
            # fallback: pick a far-out value
            best_x = max(st.vals) + 1
        st.add(best_x)
    return st.vals


def _anneal(st, deadline, rng, T0=0.08, compress_phase=False):
    """Incremental annealing. If compress_phase, only accept moves that keep
    the difference-set size (B_2-like) while shrinking diameter."""
    best = st.vals[:]
    best_s = st.score()
    cur_s = best_s
    start = time.time()
    total = max(0.001, deadline - start)
    while time.time() < deadline:
        t = (time.time() - start) / total
        if t > 1.0:
            t = 1.0
        T = T0 * (0.0005 / T0) ** t
        r = rng.random()
        n = len(st.vals)
        if n < 2:
            break
        if compress_phase:
            # Try to pull an element toward the median (shrink diameter).
            srt = sorted(st.vals)
            med = srt[n // 2]
            i = rng.randrange(n)
            x = st.vals[i]
            if x == med:
                continue
            diff = med - x
            step = diff // 2 if abs(diff) > 1 else (1 if diff > 0 else -1)
            newx = x + step
            if newx in st.vals:
                continue
            st.remove(x)
            st.add(newx)
            s = st.score()
            if s >= cur_s or rng.random() < math.exp((s - cur_s) / max(T, 1e-9)):
                cur_s = s
                if s > best_s:
                    best_s = s
                    best = st.vals[:]
            else:
                st.remove(newx)
                st.add(x)
        else:
            if r < 0.55:
                # perturb one element
                i = rng.randrange(n)
                x = st.vals[i]
                delta = rng.choice([-10, -5, -3, -2, -1, 1, 2, 3, 5, 10])
                newx = x + delta
                if newx in st.vals:
                    continue
                st.remove(x)
                st.add(newx)
                s = st.score()
                if s >= cur_s or rng.random() < math.exp((s - cur_s) / max(T, 1e-9)):
                    cur_s = s
                    if s > best_s:
                        best_s = s
                        best = st.vals[:]
                else:
                    st.remove(newx)
                    st.add(x)
            elif r < 0.70 and n < 4000:
                # add a new element just outside the current range
                lo = min(st.vals)
                hi = max(st.vals)
                span = max(1, hi - lo)
                newx = hi + rng.randint(1, max(2, span // 3 + 1))
                if newx in st.vals:
                    newx = lo - rng.randint(1, max(2, span // 3 + 1))
                if newx in st.vals:
                    continue
                st.add(newx)
                s = st.score()
                if s >= cur_s or rng.random() < math.exp((s - cur_s) / max(T, 1e-9)):
                    cur_s = s
                    if s > best_s:
                        best_s = s
                        best = st.vals[:]
                else:
                    st.remove(newx)
            elif r < 0.85 and n > 3:
                # remove one element
                i = rng.randrange(n)
                x = st.vals[i]
                st.remove(x)
                s = st.score()
                if s >= cur_s or rng.random() < math.exp((s - cur_s) / max(T, 1e-9)):
                    cur_s = s
                    if s > best_s:
                        best_s = s
                        best = st.vals[:]
                else:
                    st.add(x)
            else:
                # swap: remove one, add a far one
                i = rng.randrange(n)
                x = st.vals[i]
                lo = min(st.vals)
                hi = max(st.vals)
                span = max(1, hi - lo)
                newx = hi + rng.randint(1, max(2, span))
                if newx in st.vals:
                    continue
                st.remove(x)
                st.add(newx)
                s = st.score()
                if s >= cur_s or rng.random() < math.exp((s - cur_s) / max(T, 1e-9)):
                    cur_s = s
                    if s > best_s:
                        best_s = s
                        best = st.vals[:]
                else:
                    st.remove(newx)
                    st.add(x)
    # Rebuild a fresh State from best (maps may be stale after rollbacks)
    return best, best_s


def solve():
    """Return a list of distinct integers A maximizing
    log|A-A|/log|A+A| + (1 - 1/|A|)/100."""
    rng = random.Random(987654321)
    deadline = time.time() + 110.0

    best = None
    best_s = -1.0

    # Multi-restart: sweep target sizes and build greedily, then anneal.
    target_sizes = [60, 120, 200, 300, 500, 800, 1200, 1800, 2500, 3200]
    max_vals = [10**6, 10**9, 10**12, 10**14]

    seeds = []
    # Build a handful of greedy seeds quickly.
    for ts in target_sizes:
        for mv in max_vals:
            if time.time() > deadline - 5:
                break
            vals = _greedy_build(ts, rng, mv)
            st = State(vals)
            s = st.score()
            seeds.append((s, vals))
        if time.time() > deadline - 5:
            break

    # Also include a compact arithmetic-progression-ish seed.
    seeds.append((0.0, [7, 15, 18, 22, -3, -2]))

    seeds.sort(key=lambda t: -t[0])
    K = 12
    top = seeds[:K]

    # Phase 1: exploratory annealing on each top seed.
    remaining = deadline - time.time()
    if remaining <= 1.0:
        return sorted(set(top[0][1]))
    per_seed = max(1.0, min(4.0, (remaining * 0.7) / max(1, len(top))))

    polished = []
    for s0, vals in top:
        if time.time() >= deadline - 2.0:
            break
        slice_end = min(deadline - 1.0, time.time() + per_seed)
        st = State(vals)
        bv, bs = _anneal(st, slice_end, rng, T0=0.08, compress_phase=False)
        polished.append((bs, bv))

    polished.sort(key=lambda t: -t[0])
    if polished:
        best_s, best = polished[0]
        best = best[:]

    # Phase 2: compress-only polishing of the best few.
    top2 = polished[:4] if polished else [(best_s, best)]
    remaining = deadline - time.time()
    per_seed2 = max(0.5, remaining / max(1, len(top2)))
    for s0, vals in top2:
        if time.time() >= deadline - 0.5:
            break
        slice_end = min(deadline - 0.3, time.time() + per_seed2)
        st = State(vals)
        bv, bs = _anneal(st, slice_end, rng, T0=0.02, compress_phase=True)
        if bs > best_s:
            best_s = bs
            best = bv[:]

    # Final: if time remains, do one more exploratory pass on the best.
    if time.time() < deadline - 1.0:
        st = State(best)
        bv, bs = _anneal(st, deadline - 0.3, rng, T0=0.05, compress_phase=False)
        if bs > best_s:
            best_s = bs
            best = bv[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END