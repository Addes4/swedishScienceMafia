# EVOLVE-BLOCK-START
"""Golomb-ruler + Singer-difference-set hybrid with annealing and
sum-set-shrinking refinement.

Goal: maximise log|A-A| / log|A+A| + (1 - 1/|A|)/100.

Improvements over the prior version:
  * Seeds are ranked lexicographically: primary = ratio, secondary = -|A+A|.
  * Affine sweep uses negative scales and a dense shift grid.
  * Annealing uses the pure ratio (no n-bonus contamination).
  * A dedicated shrink phase reduces |A+A| while preserving |A-A|.
"""
import math
import random
import time


# ---------- scoring ----------

def _stats(a):
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) < 2:
        return 0.0, len(diffs), len(sums)
    ratio = math.log(len(diffs)) / math.log(len(sums))
    score = ratio + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _ratio(a):
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return -1.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) < 2:
        return -1.0, len(diffs), len(sums)
    return math.log(len(diffs)) / math.log(len(sums)), len(diffs), len(sums)


def _score(a):
    return _stats(a)[0]


def _better(a, b):
    """True if a is lexicographically better than b: (ratio, -|A+A|, n)."""
    if b is None:
        return True
    ra, da, sa = _ratio(a)
    rb, db, sb = _ratio(b)
    if ra > rb + 1e-12:
        return True
    if ra < rb - 1e-12:
        return False
    if sa < sb:
        return True
    if sa > sb:
        return False
    return len(set(a)) > len(set(b))


# ---------- seed constructions ----------

def _greedy_golomb(n, cap=10**7):
    """Greedy Golomb ruler: pick smallest integer keeping all differences distinct."""
    A = [0]
    used = set()
    cand = 1
    while len(A) < n:
        ok = True
        new_diffs = set()
        for x in A:
            d1 = cand - x
            d2 = x - cand
            if d1 in used or d2 in used or d1 in new_diffs or d2 in new_diffs:
                ok = False
                break
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            A.append(cand)
            used |= new_diffs
        cand += 1
        if cand > cap:
            break
    return A


def _greedy_sidon_mod(n, mod):
    """Greedy Sidon set in Z_mod: all pairwise sums distinct mod mod."""
    A = [0]
    used_sums = {0}
    cand = 1
    while len(A) < n and cand < mod:
        ok = True
        new_sums = set()
        for x in A:
            s = (x + cand) % mod
            if s in used_sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if ok:
            A.append(cand)
            used_sums |= new_sums
        cand += 1
    return A


def _powers_set(base, n):
    A = [0, 1]
    v = 1
    for _ in range(n - 2):
        v *= base
        A.append(v)
    return A


# ---------- affine search over seeds ----------

def _best_affine(seed, deadline):
    """Try scales (including negative) and shifts to minimise |A+A| while
    keeping |A-A| invariant under x -> s*x + t (s != 0)."""
    best = list(seed)
    best_r, best_d, best_s = _ratio(best)
    n = len(seed)
    if n < 2:
        return best
    lo = min(seed)
    hi = max(seed)
    span = hi - lo + 1

    scales = [1, 2, 3, 5, 7, 11, 13, 17, 23, -1, -2, -3, -5, -7, -11]
    shifts_frac = [0.0, 0.5, 1.0, -0.5, -1.0, 0.25, 0.75, -0.25, -0.75]

    for s in scales:
        scaled = [x * s for x in seed]
        slo = min(scaled)
        shi = max(scaled)
        sspan = shi - slo
        cand_shifts = set()
        for f in shifts_frac:
            cand_shifts.add(int(-slo + f * sspan))
        # also add a few random shifts
        for _ in range(4):
            cand_shifts.add(random.randint(-sspan, sspan))
        for t in cand_shifts:
            cand = [x + t for x in scaled]
            r, d, sm = _ratio(cand)
            if r > best_r + 1e-12 or (abs(r - best_r) <= 1e-12 and sm < best_s):
                best = cand
                best_r, best_d, best_s = r, d, sm
        if time.time() > deadline:
            break
    return best


# ---------- annealing (pure ratio objective) ----------

def _anneal(A, deadline, budget_frac=0.55):
    A = list(set(int(x) for x in A))
    if len(A) < 2:
        return A
    best = A[:]
    best_r, best_d, best_s = _ratio(best)
    cur = A[:]
    cur_r, cur_d, cur_s = best_r, best_d, best_s
    t_end = time.time() + max(0.0, (deadline - time.time()) * budget_frac)

    span = max(cur) - min(cur) + 1
    T0 = max(0.5, 0.03 * span)
    Tmin = 1e-3
    total = max(1.0, t_end - time.time())
    no_improve = 0

    while time.time() < t_end:
        frac = 1.0 - (t_end - time.time()) / total
        T = max(Tmin, T0 * (1.0 - frac) ** 1.5)
        cand = cur[:]
        op = random.random()
        if op < 0.7 and len(cand) > 2:
            i = random.randrange(len(cand))
            step = max(1, int(T * random.uniform(0.5, 2.0)))
            cand[i] += random.randint(-step, step)
        elif op < 0.88:
            cand.append(random.randint(-int(2 * T), int(2 * T)))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        r, d, sm = _ratio(cand)
        # accept if ratio improves, or ratio equal and sum-set smaller
        improved = (r > cur_r + 1e-12) or (
            abs(r - cur_r) <= 1e-12 and sm < cur_s
        )
        if improved:
            cur, cur_r, cur_d, cur_s = cand, r, d, sm
            no_improve = 0
            if r > best_r + 1e-12 or (
                abs(r - best_r) <= 1e-12 and sm < best_s
            ):
                best, best_r, best_d, best_s = cand[:], r, d, sm
        else:
            delta = r - cur_r
            if delta > -1e-9 or random.random() < math.exp(
                delta / max(T, 1e-6)
            ):
                cur, cur_r, cur_d, cur_s = cand, r, d, sm
            no_improve += 1
            if no_improve > 500:
                cur, cur_r, cur_d, cur_s = best[:], best_r, best_d, best_s
                no_improve = 0
    return best


# ---------- sum-set shrinking phase ----------

def _shrink_sums(A, deadline):
    """Hill-climb that strictly reduces |A+A| while keeping |A-A| >= current."""
    A = list(set(int(x) for x in A))
    if len(A) < 2:
        return A
    cur = A[:]
    cur_r, cur_d, cur_s = _ratio(cur)
    no_improve = 0
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.6 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-3, -2, -1, 1, 2, 3])
        elif op < 0.8:
            cand.append(random.randint(min(cur) - 5, max(cur) + 5))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        r, d, sm = _ratio(cand)
        # accept if same ratio and smaller sums (or better ratio)
        if (r > cur_r + 1e-12) or (
            abs(r - cur_r) <= 1e-12 and sm < cur_s
        ):
            cur, cur_r, cur_d, cur_s = cand, r, d, sm
            no_improve = 0
        else:
            no_improve += 1
            if no_improve > 800:
                break
    return cur


# ---------- driver ----------

def solve():
    random.seed(20240517)
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Phase 1: build seeds (~30% of budget).
    seed_deadline = time.time() + 0.30 * (deadline - time.time())

    sizes = [6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 56, 64]

    # Golomb-ruler seeds.
    for n in sizes:
        if time.time() > seed_deadline:
            break
        seed = _greedy_golomb(n)
        if len(seed) < 2:
            continue
        cand = _best_affine(seed, seed_deadline)
        if _better(cand, best):
            best = cand

    # Modular Sidon seeds.
    for n in sizes:
        if time.time() > seed_deadline:
            break
        mod = n * n + n + 1
        seed = _greedy_sidon_mod(n, mod)
        if len(seed) < 2:
            continue
        cand = _best_affine(seed, seed_deadline)
        if _better(cand, best):
            best = cand

    # Powers-of-base seeds.
    for base in (2, 3, 4, 5):
        for n in (8, 16, 24, 32, 48, 64):
            if time.time() > seed_deadline:
                break
            seed = _powers_set(base, n)
            if max(seed) > 10**14:
                continue
            cand = _best_affine(seed, seed_deadline)
            if _better(cand, best):
                best = cand

    # Quadratic Sidon family.
    for n in sizes:
        if time.time() > seed_deadline:
            break
        for M in (1, 2, 3, 5, 7, 11, 13, 17, 23, 31):
            A = [i * (1 + M * i) for i in range(n)]
            if max(A) > 10**14:
                break
            cand = _best_affine(A, seed_deadline)
            if _better(cand, best):
                best = cand

    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    # Phase 2: annealing (~55% of budget).
    if time.time() < deadline:
        best = _anneal(best, deadline, budget_frac=0.55)

    # Phase 3: sum-set shrinking (~15% of budget).
    if time.time() < deadline:
        shrunk = _shrink_sums(best, deadline)
        if _better(shrunk, best):
            best = shrunk

    return sorted(set(int(x) for x in best))


if __name__ == "__main__":
    import time as _t
    t0 = _t.time()
    res = solve()
    print("n=", len(res), "score=", _score(res), "time=", _t.time() - t0)
# EVOLVE-BLOCK-END
