# EVOLVE-BLOCK-START
"""B2 (Sidon) algebraic seeds + boundary remove-and-replace refinement.

For a Sidon set A, |A+A| = n(n+1)/2 (minimal).  The ratio
    log|A-A| / log|A+A|
is then maximised by making the difference set as large as possible.
Classical quadratic sets A = {i(1+M i)} are Sidon, but their extreme
elements sit far above the rest, so |A-A| is already near the max possible
for that span.  The real gain comes from *repairing* the boundary: delete
the largest element (which contributes the most to the span) and re-insert
a new integer chosen to keep the sum set small while enlarging the
difference set.  We do this with a fast incremental B2/difference test.
"""
import math
import random
import time


# ---------- scoring ----------

def _stats(a):
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0, 0, 0
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _score(a):
    return _stats(a)[0]


# ---------- fast B2 / difference helpers ----------

def _is_b2(A):
    """True if all pairwise sums a_i + a_j (i<=j) are distinct."""
    s = set()
    n = len(A)
    for i in range(n):
        ai = A[i]
        for j in range(i, n):
            v = ai + A[j]
            if v in s:
                return False
            s.add(v)
    return True


def _diff_count(A):
    return len({x - y for x in A for y in A})


# ---------- seed constructions ----------

def _quad(n, M):
    return [i * (1 + M * i) for i in range(n)]


def _mod_sidon(n, p, scale):
    return [((i * (i + 1)) % p) * scale + i for i in range(n)]


def _greedy_b2(n, cap=10**7):
    A = [0]
    used = {0}
    cand = 1
    while len(A) < n and cand <= cap:
        new = []
        ok = True
        for x in A:
            s = x + cand
            if s in used or s in new:
                ok = False
                break
            new.append(s)
        if ok:
            A.append(cand)
            used.update(new)
            used.add(2 * cand)
        cand += 1
    return A


# ---------- boundary remove-and-replace refinement ----------

def _repair(A, deadline, tol_collisions=0):
    """Repeatedly delete a boundary element and re-insert at a position
    that improves the score (small |A+A|, large |A-A|)."""
    A = sorted(set(int(x) for x in A))
    if len(A) < 4:
        return A, _score(A)
    best = A[:]
    best_score = _score(best)
    n = len(A)

    while time.time() < deadline:
        improved = False
        # try deleting each of the few extreme elements
        order = sorted(range(n), key=lambda i: -abs(A[i] - (A[0] + A[-1]) / 2))
        for idx in order[:3]:
            if time.time() > deadline:
                break
            base = A[:idx] + A[idx + 1:]
            lo = min(base)
            hi = max(base)
            span = hi - lo
            # candidate insertion positions: interior grid + just outside
            cands = set()
            step = max(1, span // (4 * n))
            x = lo
            while x <= hi:
                cands.add(x)
                x += step
            # a few strategic values
            for frac in (0.5, 0.25, 0.75):
                cands.add(lo + int(frac * span))
            cands.add(hi + 1)
            cands.add(lo - 1)
            cands.add((lo + hi) // 2)

            for c in cands:
                if c in base:
                    continue
                cand = base + [c]
                s, nd, ns = _stats(cand)
                if s > best_score:
                    best, best_score = cand[:], s
                    A = sorted(set(cand))
                    n = len(A)
                    improved = True
                    break
            if improved:
                break
        if not improved:
            # try a small random perturbation instead
            if time.time() > deadline:
                break
            cand = A[:]
            i = random.randrange(len(cand))
            lo, hi = min(cand), max(cand)
            span = hi - lo
            cand[i] += random.randint(-max(1, span // (4 * n)), max(1, span // (4 * n)))
            cand = list(set(cand))
            if len(cand) < 4:
                continue
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s
                A = sorted(set(cand))
                n = len(A)
            else:
                # small anneal acceptance
                if random.random() < 0.05:
                    A = sorted(set(cand))
                    n = len(A)
    return best, best_score


# ---------- driver ----------

def solve():
    random.seed(20240517)
    start = time.time()
    deadline = start + 110
    LIMIT = 10 ** 15

    pool = []

    def _add(seed):
        if not seed or len(seed) < 2:
            return
        if max(abs(x) for x in seed) > LIMIT:
            return
        pool.append((_score(seed), list(set(int(x) for x in seed))))

    # 1a. quadratic Sidon family
    for n in range(4, 160):
        for M in (1, 2, 3, 4, 5, 7, 8, 11, 13, 16, 17, 23, 31, 32, 41, 61, 64,
                  128, 256, 512, 1024, 4096, 65536):
            cand = _quad(n, M)
            if cand[-1] > LIMIT:
                break
            _add(cand)
        if time.time() > start + 20:
            break

    # 1b. finite-field Sidon variants
    primes = [97, 193, 389, 769, 1543, 3079, 6151, 12289, 24593, 49157, 98317]
    for n in range(4, 100):
        for p in primes:
            if p < n:
                continue
            for scale in (1, 7, 1000, 10 ** 6, 10 ** 9):
                cand = _mod_sidon(n, p, scale)
                if max(abs(x) for x in cand) > LIMIT:
                    continue
                _add(cand)
        if time.time() > start + 35:
            break

    # 1c. greedy B2 seeds
    for n in (6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64, 80):
        if time.time() > start + 45:
            break
        _add(_greedy_b2(n))

    if not pool:
        pool.append((_score([0, 1, 3, 7, 12, 20]), [0, 1, 3, 7, 12, 20]))

    pool.sort(key=lambda t: -t[0])

    # ----- Phase 2: repair the top few seeds -----
    remaining = max(0.0, deadline - time.time())
    if remaining < 0.5:
        return sorted(set(int(x) for x in pool[0][1]))

    K = 6
    top = pool[:K]
    best_global = top[0][1]
    best_global_score = top[0][0]

    repair_budget = 0.75 * remaining
    repair_end = time.time() + repair_budget

    # weight better seeds more
    weights = [K - i for i in range(len(top))]
    total_w = sum(weights)

    for i, (s0, A0) in enumerate(top):
        if time.time() >= repair_end:
            break
        slice_time = repair_budget * weights[i] / total_w
        t_end = min(repair_end, time.time() + slice_time)
        cand, s = _repair(A0, t_end)
        if s > best_global_score:
            best_global, best_global_score = cand, s

    # ----- Phase 3: final repair of the overall best -----
    if time.time() < deadline:
        cand, s = _repair(best_global, deadline)
        if s > best_global_score:
            best_global, best_global_score = cand, s

    if not best_global:
        best_global = [0, 1, 3, 7, 12, 20]

    return sorted(set(int(x) for x in best_global))


if __name__ == "__main__":
    import time as _t
    t0 = _t.time()
    res = solve()
    print("n=", len(res), "score=", _score(res), "time=", _t.time() - t0)
# EVOLVE-BLOCK-END