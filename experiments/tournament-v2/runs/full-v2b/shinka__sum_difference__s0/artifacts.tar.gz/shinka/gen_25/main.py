# EVOLVE-BLOCK-START
"""Algebraic Sidon / Golomb constructions + lexicographic repair + simulated annealing.

Key idea: for a Sidon (B_2) set A, all pairwise sums a_i + a_j are distinct,
so |A+A| = n(n+1)/2 is minimal, while |A-A| is typically large -- this
maximises log|A-A| / log|A+A|.

Improvements over the previous version:
  * lexicographic acceptance rule (ratio, -|A+A|, n) instead of strict ratio
    improvement, so ties on the ratio are broken by shrinking |A+A| and by
    growing n (which also collects the (1 - 1/n)/100 bonus);
  * wider extreme-element deletion: remove any of the top-5 elements by
    distance from the midpoint, not just the maximum;
  * finer candidate insertion set (anchors + perturbations around removed);
  * simulated-annealing refinement with reheats, also using the lexicographic
    rule, with add / remove / perturb moves.
"""
import math
import random
import time


# ---------------------------------------------------------------- scoring

def _stats(a):
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) < 2:
        return 0.0, len(diffs), len(sums)
    ratio = math.log(len(diffs)) / math.log(len(sums))
    score = ratio + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _score(a):
    return _stats(a)[0]


def _key(a):
    """Lexicographic key: (ratio, -|A+A|, n)."""
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return (-1.0, 0, 0)
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return (-1.0, 0, 0)
    ratio = math.log(len(diffs)) / math.log(len(sums))
    return (ratio, -len(sums), n)


# ---------------------------------------------------------------- Sidon seeds

def _sidon_quadratic(n, M):
    """A = { i * (1 + M*i) : i=0..n-1 } -- quadratic Sidon-like set."""
    return [i * (1 + M * i) for i in range(n)]


def _powers_set(base, n):
    """{0, 1, base, base^2, ..., base^(n-1)}."""
    A = [0, 1]
    v = 1
    for _ in range(n - 2):
        v *= base
        A.append(v)
    return A


def _is_sidon(A):
    n = len(A)
    seen = set()
    for i in range(n):
        ai = A[i]
        for j in range(i + 1, n):
            d = ai - A[j]
            if d in seen:
                return False
            seen.add(d)
    return True


# ---------------------------------------------------------------- repair

def _repair(A, deadline, rounds=400):
    """Lexicographic repair: remove a far-from-midpoint element, reinsert a
    smaller one while preserving the B_2 property."""
    A = sorted(set(int(x) for x in A))
    if len(A) < 3:
        return A
    best = A[:]
    best_key = _key(best)

    for _ in range(rounds):
        if time.time() > deadline:
            break
        cur = best[:]
        n_cur = len(cur)
        mid = (cur[0] + cur[-1]) // 2
        # pick one of the top-5 elements by distance from the midpoint
        order = sorted(range(n_cur), key=lambda i: -abs(cur[i] - mid))
        victim_idx = order[random.randrange(min(5, n_cur))]
        victim = cur[victim_idx]
        cur = cur[:victim_idx] + cur[victim_idx + 1:]
        if len(cur) < 2:
            continue
        lo = cur[0]
        hi = cur[-1]

        # candidate insertion values
        cands = set()
        cands.add(lo)
        cands.add(lo + 1)
        cands.add(lo + 2)
        cands.add(hi + 1)
        cands.add(hi + 2)
        cands.add(victim - 1)
        cands.add(victim - 2)
        cands.add(victim + 1)
        cands.add(victim + 2)
        cands.add(mid)
        cands.add(mid - 1)
        cands.add(mid + 1)
        for k in range(1, 8):
            cands.add(lo + (hi - lo) * k // 8)
        # random perturbations around the victim
        for _t in range(8):
            cands.add(victim + random.randint(-4, 4))

        improved = False
        for x in cands:
            if x in cur:
                continue
            trial = sorted(cur + [x])
            if not _is_sidon(trial):
                continue
            k = _key(trial)
            if k > best_key:
                best = trial
                best_key = k
                improved = True
                break
        if not improved:
            # broader random scan
            span = max(1, hi - lo)
            for _try in range(60):
                if time.time() > deadline:
                    break
                x = random.randint(lo, hi + 1)
                if x in cur:
                    continue
                trial = sorted(cur + [x])
                if not _is_sidon(trial):
                    continue
                k = _key(trial)
                if k > best_key:
                    best = trial
                    best_key = k
                    improved = True
                    break
            if not improved:
                # try re-inserting the victim (no-op) or break out
                break
    return best


# ---------------------------------------------------------------- annealing

def _anneal(A, deadline, budget_frac=0.85):
    A = list(set(int(x) for x in A))
    if len(A) < 2:
        return A
    best = A[:]
    best_key = _key(best)
    cur = A[:]
    cur_key = best_key
    t_end = time.time() + max(0.0, (deadline - time.time()) * budget_frac)

    span = max(cur) - min(cur) + 1
    T0 = max(0.5, 0.015 * span)
    Tmin = 1e-3
    total = max(1e-6, t_end - time.time())
    no_improve = 0

    while time.time() < t_end:
        frac = 1.0 - (t_end - time.time()) / total
        T = max(Tmin, T0 * (1.0 - frac))
        cand = cur[:]
        op = random.random()
        if op < 0.60 and len(cand) > 2:
            i = random.randrange(len(cand))
            step = max(1, int(T * random.uniform(0.5, 2.0)))
            cand[i] += random.randint(-step, step)
        elif op < 0.80:
            cand.append(random.randint(-int(3 * T), int(3 * T)))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        k = _key(cand)
        s = _score(cand)
        cur_s = _score(cur)
        if k > cur_key:
            cur, cur_key = cand, k
            no_improve = 0
            if k > best_key:
                best, best_key = cand[:], k
        else:
            delta = s - cur_s
            if delta > -1e-9 or random.random() < math.exp(delta / max(T, 1e-6)):
                cur, cur_key = cand, k
            no_improve += 1
            if no_improve > 500:
                cur, cur_key = best[:], best_key
                T0 *= 1.5
                no_improve = 0
    return best


# ---------------------------------------------------------------- driver

def solve():
    random.seed(20240517)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_key = _key(best)

    # Phase 1: algebraic quadratic Sidon seeds.
    sizes = [8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512]
    for n in sizes:
        for M in [1, 2, 3, 5, 7, 11, 13, 17, 23, 31, 41, 61]:
            A = _sidon_quadratic(n, M)
            if max(A) > 10**14:
                break
            k = _key(A)
            if k > best_key:
                best, best_key = A[:], k
        if time.time() > deadline * 0.5:
            break

    # Phase 2: geometric-progression candidates.
    for base in (2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 32):
        for n in range(2, 55):
            A = _powers_set(base, n)
            if max(A) > 10**14:
                break
            k = _key(A)
            if k > best_key:
                best, best_key = A[:], k

    # Phase 3: lexicographic B_2-preserving repair.
    if time.time() < deadline:
        repaired = _repair(best, min(deadline, time.time() + 30))
        k = _key(repaired)
        if k > best_key:
            best, best_key = repaired, k

    # Phase 4: simulated annealing refinement.
    if time.time() < deadline:
        annealed = _anneal(best, deadline, budget_frac=0.9)
        k = _key(annealed)
        if k > best_key:
            best, best_key = annealed, k

    return sorted(set(int(x) for x in best))


if __name__ == "__main__":
    import time as _t
    t0 = _t.time()
    res = solve()
    print("n=", len(res), "score=", _score(res), "time=", _t.time() - t0)
# EVOLVE-BLOCK-END