# EVOLVE-BLOCK-START
"""Algebraic Sidon / Golomb constructions + targeted local refinement.

The key observation: for a Sidon (B_2) set A, all pairwise sums a_i + a_j
are distinct, so |A+A| = n(n+1)/2 is minimal, while the difference set
A - A is typically much larger. This maximises log|A-A| / log|A+A|.

Classical construction: A = { i*(1 + M*i) : i = 0..n-1 } for suitable M.
For M chosen so that i -> (i, i^2) is injective (no collisions in sums),
this yields a true Sidon set of integers. We try several M values and
sizes, then locally refine the best candidate with small integer steps.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _sidon_quadratic(n, M):
    """A = { i * (1 + M*i) : i=0..n-1 } -- quadratic Sidon-like set."""
    return [i * (1 + M * i) for i in range(n)]


def _powers_set(base, n):
    """{0, 1, base, base^2, ..., base^(n-1)} -- sums are nearly distinct."""
    A = [0, 1]
    v = 1
    for _ in range(n - 2):
        v *= base
        A.append(v)
    return A


def _local_refine(A, deadline):
    A = list(set(A))
    best = A[:]
    best_score = _score(best)
    cur = A[:]
    cur_score = best_score
    no_improve = 0
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.choice([-1, 1, -2, 2])
        if random.random() < 0.02:
            cand.append(random.randint(0, max(cand) + 1))
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            no_improve = 0
            if s > best_score:
                best, best_score = cand[:], s
        else:
            no_improve += 1
            if no_improve > 300:
                cur, cur_score = best[:], best_score
                no_improve = 0
    return best, best_score


def solve():
    random.seed(20240517)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # Quadratic Sidon family: A = { i*(1 + M*i) }.
    sizes = [8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512]
    for n in sizes:
        for M in [1, 2, 3, 5, 7, 11, 13, 17, 23, 31, 41, 61]:
            A = _sidon_quadratic(n, M)
            if max(A) > 10**14:
                break
            s = _score(A)
            if s > best_score:
                best, best_score = A[:], s
        if time.time() > deadline * 0.6:
            break

    # Geometric-progression candidates (sums are highly structured).
    for base in (2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 32):
        for n in range(2, 55):
            A = _powers_set(base, n)
            if max(A) > 10**14:
                break
            s = _score(A)
            if s > best_score:
                best, best_score = A[:], s

    # Refinement on the best algebraic candidate.
    if time.time() < deadline:
        best, best_score = _local_refine(best, deadline)

    return sorted(set(int(x) for x in best))


if __name__ == "__main__":
    import time as _t
    t0 = _t.time()
    res = solve()
    print("n=", len(res), "score=", _score(res), "time=", _t.time() - t0)
# EVOLVE-BLOCK-END