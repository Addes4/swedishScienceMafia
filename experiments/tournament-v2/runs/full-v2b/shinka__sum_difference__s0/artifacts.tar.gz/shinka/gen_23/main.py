# EVOLVE-BLOCK-START
"""Hybrid: algebraic Sidon seeds + Golomb/Sidon seeds + affine search + simulated annealing.

Combines:
  * algebraic quadratic Sidon construction (cheap, many candidates)
  * greedy Golomb ruler and modular Sidon seeds (max |A-A|)
  * powers-of-two with shifts (small |A+A| via symmetry)
  * affine (scale, shift) search over seeds
  * simulated annealing refinement (stronger than plain hill-climb)
"""
import math
import random
import time


# ---------------------------------------------------------------- scoring

def _stats(a):
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _score(a):
    return _stats(a)[0]


# ---------------------------------------------------------------- seeds

def _algebraic_sidon(n, mult=1, shift=0, mod=None):
    """a_i = (i*mult + i*i + shift) mod mod -- Sidon-like over Z_mod."""
    if mod is None:
        mod = max(3, n * n + 1)
    A = []
    for i in range(n):
        v = (i * mult + i * i + shift) % mod
        # fold into a symmetric interval to help sums
        if v > mod // 2:
            v -= mod
        A.append(v)
    return A


def _greedy_golomb(n, cap=10**7):
    """Greedy Golomb ruler: smallest integers with all differences distinct."""
    A = [0]
    used = set()
    cand = 1
    while len(A) < n and cand <= cap:
        ok = True
        new_diffs = set()
        for x in A:
            d1 = cand - x
            d2 = x - cand
            if d1 in used or d2 in used or d1 in new_diffs or d2 in new_diffs:
                ok = False
                break
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            A.append(cand)
            used |= new_diffs
        cand += 1
    return A


def _greedy_sidon_mod(n, mod):
    """Greedy Sidon set in Z_mod (all pairwise sums distinct)."""
    A = [0]
    used_sums = {0}
    cand = 1
    while len(A) < n and cand < mod:
        ok = True
        new_sums = set()
        for x in A:
            s = (x + cand) % mod
            if s in used_sums or s in new_sums:
                ok = False
                break
            new_sums.add(s)
        if ok:
            A.append(cand)
            used_sums |= new_sums
        cand += 1
    return A


def _powers_of_two(n):
    return [0] + [2 ** i for i in range(n)]


# ---------------------------------------------------------------- affine search

def _best_affine(seed, deadline):
    """Try scales and shifts to reduce |A+A| while preserving |A-A|."""
    seed = list(set(int(x) for x in seed))
    if len(seed) < 2:
        return seed, _score(seed)
    best = seed[:]
    best_score = _score(best)
    for scale in (1, 2, 3, 5, 7, 11):
        scaled = [x * scale for x in seed]
        mid = (max(scaled) + min(scaled)) // 2
        for shift in (0, -mid, -min(scaled), -max(scaled), -mid // 2):
            cand = [x + shift for x in scaled]
            s = _score(cand)
            if s > best_score:
                best, best_score = cand[:], s
        if time.time() > deadline:
            break
    return best, best_score


# ---------------------------------------------------------------- annealing

def _anneal(A, deadline, budget_frac=0.9):
    """Simulated annealing with reheats on stagnation."""
    A = list(set(int(x) for x in A))
    if len(A) < 2:
        return A, _score(A)
    best = A[:]
    best_score = _score(best)
    cur = A[:]
    cur_score = best_score
    t_end = time.time() + max(0.0, (deadline - time.time()) * budget_frac)

    span = max(cur) - min(cur) + 1
    T0 = max(0.5, 0.02 * span)
    Tmin = 1e-3
    total = max(1e-6, t_end - time.time())
    no_improve = 0

    while time.time() < t_end:
        frac = 1.0 - (t_end - time.time()) / total
        T = max(Tmin, T0 * (1.0 - frac))
        cand = cur[:]
        op = random.random()
        if op < 0.65 and len(cand) > 2:
            i = random.randrange(len(cand))
            step = max(1, int(T * random.uniform(0.5, 2.0)))
            cand[i] += random.randint(-step, step)
        elif op < 0.85:
            cand.append(random.randint(-int(2 * T), int(2 * T)))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            no_improve = 0
            if s > best_score:
                best, best_score = cand[:], s
        else:
            delta = s - cur_score
            if delta > -1e-9 or random.random() < math.exp(delta / max(T, 1e-6)):
                cur, cur_score = cand, s
            no_improve += 1
            if no_improve > 400:
                # reheat: jump back to best and boost temperature
                cur, cur_score = best[:], best_score
                T0 *= 1.5
                no_improve = 0
    return best, best_score


# ---------------------------------------------------------------- driver

def solve():
    random.seed(20240517)
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Phase 1 (35%): seed generation.
    seed_deadline = time.time() + 0.35 * (deadline - time.time())

    sizes = [6, 8, 10, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96, 128, 192, 256]

    # Algebraic Sidon seeds (many cheap candidates).
    for n in sizes:
        if time.time() > seed_deadline:
            break
        for mult in (1, 2, 3, 5, 7):
            for shift in (0, 1, 3):
                mod = max(3, n * n + 1)
                A = _algebraic_sidon(n, mult=mult, shift=shift, mod=mod)
                A = list(set(A))
                if len(A) < 2:
                    continue
                cand, s = _best_affine(A, seed_deadline)
                if s > best_score:
                    best, best_score = cand[:], s
            if time.time() > seed_deadline:
                break

    # Golomb rulers (maximise |A-A|).
    for n in sizes:
        if time.time() > seed_deadline:
            break
        seed = _greedy_golomb(n)
        if len(seed) < 2:
            continue
        cand, s = _best_affine(seed, seed_deadline)
        if s > best_score:
            best, best_score = cand[:], s

    # Modular Sidon seeds.
    for n in sizes:
        if time.time() > seed_deadline:
            break
        mod = n * n + n + 1
        seed = _greedy_sidon_mod(n, mod)
        if len(seed) < 2:
            continue
        cand, s = _best_affine(seed, seed_deadline)
        if s > best_score:
            best, best_score = cand[:], s

    # Powers-of-two (small |A+A| via structure).
    for n in (8, 16, 32, 64, 128):
        if time.time() > seed_deadline:
            break
        seed = _powers_of_two(n)
        cand, s = _best_affine(seed, seed_deadline)
        if s > best_score:
            best, best_score = cand[:], s

    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    # Phase 2 (remaining ~65%): simulated annealing refinement.
    if time.time() < deadline:
        best, best_score = _anneal(best, deadline, budget_frac=0.95)

    return sorted(set(int(x) for x in best))


if __name__ == "__main__":
    import time as _t
    t0 = _t.time()
    res = solve()
    print("n=", len(res), "score=", _score(res), "time=", _t.time() - t0)
# EVOLVE-BLOCK-END
