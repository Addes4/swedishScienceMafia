# EVOLVE-BLOCK-START
"""Multi-seed near-arithmetic-progression search with focused polish.

Idea: an AP {i*step} has |A+A| = 2n-1 (tiny).  Perturbing a few elements
by small deltas keeps most sum collisions (step dominates) while breaking
the AP symmetry that caps |A-A|.  We sweep many (n, step) seeds, keep the
top-K by score, and run a cheap strict-improvement polish on each.
"""

import math
import random
import time


# ---------- scoring ----------

def _parts(a):
    """Return (len_diff, len_sum, n) for a list of distinct ints."""
    n = len(a)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums), n


def _score_parts(ld, ls, n):
    if ls < 2 or ld < 2 or n < 2:
        return 0.0
    return math.log(ld) / math.log(ls) + (1.0 - 1.0 / n) / 100.0


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    ld, ls, n = _parts(a)
    return _score_parts(ld, ls, n)


# ---------- seed generators ----------

def build_near_ap(n, step, rng, delta_pool=(-2, -1, 0, 0, 0, 1, 2)):
    """AP with large step, plus tiny per-element deltas from a small pool.
    Step dominates so many sums collide; deltas break AP symmetry in diffs."""
    A = []
    seen = set()
    for i in range(n):
        d = rng.choice(delta_pool)
        v = i * step + d
        if v not in seen:
            seen.add(v)
            A.append(v)
    return sorted(A)


def build_scaled_ap(n, step, rng, scale=2):
    """AP where each element is i*step plus a multiple of a smaller base,
    giving extra structure to break diff symmetry cheaply."""
    A = []
    seen = set()
    for i in range(n):
        v = i * step + (i * i) % scale
        if v not in seen:
            seen.add(v)
            A.append(v)
    return sorted(A)


# ---------- polish: strict-improvement micro-moves ----------

def polish(A, deadline, rng):
    """Cheap local polish: perturb single elements by tiny deltas, accept only
    strict improvements.  Bounded by deadline."""
    A = sorted(set(A))
    if len(A) < 2:
        return A
    ld, ls, n = _parts(A)
    cur = _score_parts(ld, ls, n)
    best = A[:]
    best_s = cur

    # small delta pool, biased toward tiny moves
    deltas = (-3, -2, -1, 1, 2, 3, -5, 5)

    while time.time() < deadline:
        i = rng.randrange(len(best))
        d = rng.choice(deltas)
        cand = best[:]
        cand[i] += d
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        cld, cls, cn = _parts(cand)
        s = _score_parts(cld, cls, cn)
        if s > best_s:
            best = cand
            best_s = s
    return best


# ---------- main ----------

def solve():
    deadline = time.time() + 108.0
    rng = random.Random(20240617)

    # ---- Phase 1: sweep (n, step) seeds, keep top-K ----
    seeds = []  # list of (score, A)

    # candidate sizes: prefer moderate n (score bonus is tiny; ratio dominates)
    n_list = [40, 60, 80, 100, 130, 160, 200, 250, 300, 400, 550, 700]
    # steps: powers of 10 and some primes-ish for variety
    step_list = [1, 2, 3, 7, 10, 31, 100, 1000, 10**4, 10**6, 10**8, 10**10]

    sweep_deadline = time.time() + 40.0
    for n in n_list:
        if time.time() > sweep_deadline:
            break
        for step in step_list:
            if time.time() > sweep_deadline:
                break
            for _ in range(2):
                A = build_near_ap(n, step, rng)
                if len(A) < 2:
                    continue
                ld, ls, nn = _parts(A)
                s = _score_parts(ld, ls, nn)
                seeds.append((s, A))
            # one structured variant
            A = build_scaled_ap(n, step, rng, scale=3)
            if len(A) >= 2:
                ld, ls, nn = _parts(A)
                s = _score_parts(ld, ls, nn)
                seeds.append((s, A))

    # Also a few compact baselines for robustness
    for n in (6, 8, 10, 12, 14):
        A = list(range(n))
        ld, ls, nn = _parts(A)
        seeds.append((_score_parts(ld, ls, nn), A))

    if not seeds:
        return [7, 15, 18, 22, -3, -2]

    seeds.sort(key=lambda t: -t[0])

    # Keep top-K unique seeds (dedupe by tuple)
    TOPK = 12
    top = []
    seen_keys = set()
    for s, A in seeds:
        key = tuple(A)
        if key in seen_keys:
            continue
        seen_keys.add(key)
        top.append((s, A))
        if len(top) >= TOPK:
            break

    # ---- Phase 2: polish top-K seeds with bounded budget each ----
    best_A = top[0][1][:]
    best_s = top[0][0]

    remaining = deadline - time.time()
    if remaining > 0:
        per_seed = max(0.5, remaining / float(len(top)))
        for s0, A0 in top:
            if time.time() >= deadline - 1.0:
                break
            slice_end = min(deadline - 1.0, time.time() + per_seed)
            cand = polish(A0, slice_end, rng)
            ld, ls, nn = _parts(cand)
            cs = _score_parts(ld, ls, nn)
            if cs > best_s:
                best_s = cs
                best_A = cand

    return sorted(set(best_A))
# EVOLVE-BLOCK-END