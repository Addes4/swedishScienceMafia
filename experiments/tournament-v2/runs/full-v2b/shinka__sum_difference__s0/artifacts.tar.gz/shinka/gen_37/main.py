# EVOLVE-BLOCK-START
"""Sidon-set affine maximization with spectral seeds and gap compression.

Insight: For a Sidon (B_2) set A, |A+A| = n(n+1)/2 is the theoretical minimum.
So log|A-A|/log|A+A| is maximized by keeping A Sidon (minimal sum-set) while
maximizing the *number* of distinct differences |A-A|.

Affine maps x -> s*x + t (s != 0) preserve Sidon-ness and hence |A+A| exactly,
while changing the actual spread and integer structure of the difference set.
We therefore:
  1. Build large Sidon-like seeds (quadratic, powers-of-2, greedy Golomb).
  2. Sweep affine transforms ranked lexicographically (ratio, -|A+A|, n).
  3. Greedily extend by appending the smallest integer that keeps Sidon-ness
     (this grows n, which both boosts |A-A| and the n-bonus).
  4. Apply a "gap-compress" operator: shift elements above the largest interior
     gap down by 1 to shrink diameter (=|A+A| proxy) without breaking Sidon.
"""
import math
import random
import time


# ---------------------------------------------------------------- scoring

def _stats(a):
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) < 2:
        return 0.0, len(diffs), len(sums)
    ratio = math.log(len(diffs)) / math.log(len(sums))
    score = ratio + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _key(a):
    a = list(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return (-1.0, 0, 0)
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    if len(sums) < 2:
        return (-1.0, 0, 0)
    ratio = math.log(len(diffs)) / math.log(len(sums))
    return (ratio, -len(sums), n)


def _score(a):
    return _stats(a)[0]


# ---------------------------------------------------------------- Sidon tools

def _is_sidon_fast(A):
    """Check Sidon (all pairwise differences i<j distinct) in O(n^2)."""
    n = len(A)
    seen = set()
    for i in range(n):
        ai = A[i]
        for j in range(i + 1, n):
            d = ai - A[j]
            if d in seen:
                return False
            seen.add(d)
    return True


def _sidon_quadratic(n, M):
    """A = { i*(1 + M*i) : i=0..n-1 } -- a quadratic Sidon-like family."""
    return [i * (1 + M * i) for i in range(n)]


def _powers_set(base, n):
    """{0, 1, base, base^2, ..., base^(n-1)}."""
    A = [0, 1]
    v = 1
    for _ in range(n - 2):
        v *= base
        A.append(v)
    return A


def _greedy_golomb(n, cap=10**8):
    """Greedy Golomb ruler: pick smallest integer keeping differences distinct."""
    A = [0]
    used = set()
    cand = 1
    while len(A) < n and cand <= cap:
        ok = True
        new_diffs = set()
        for x in A:
            d1 = cand - x
            d2 = x - cand
            if d1 in used or d2 in used or d1 in new_diffs or d2 in new_diffs:
                ok = False
                break
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            A.append(cand)
            used |= new_diffs
        cand += 1
    return A


def _extend_sidon(A, deadline, max_add=200):
    """Greedily append smallest integers keeping Sidon-ness. Grows n."""
    A = sorted(set(int(x) for x in A))
    if len(A) < 2:
        return A
    cur = A[:]
    # Build used-difference set once.
    used = set()
    for i in range(len(cur)):
        for j in range(i + 1, len(cur)):
            used.add(cur[i] - cur[j])
    lo, hi = cur[0], cur[-1]
    cand = hi + 1
    added = 0
    while added < max_add and time.time() < deadline:
        # try candidates above hi (smallest first), then below lo
        ok = True
        new_diffs = set()
        for x in cur:
            d1 = cand - x
            d2 = x - cand
            if d1 in used or d2 in used or d1 in new_diffs or d2 in new_diffs:
                ok = False
                break
            new_diffs.add(d1)
            new_diffs.add(d2)
        if ok:
            cur.append(cand)
            used |= new_diffs
            added += 1
            cand += 1
        else:
            cand += 1
            # avoid runaway
            if cand - hi > 5000:
                break
    return sorted(cur)


# ---------------------------------------------------------------- affine sweep

def _best_affine(seed, deadline, n_tries=400):
    """Try scales (incl. negative) and shifts to lexicographically maximise
    (ratio, -|A+A|, n). Affine maps preserve Sidon-ness and |A+A|."""
    seed = sorted(set(int(x) for x in seed))
    if len(seed) < 2:
        return seed
    best = seed[:]
    best_key = _key(best)
    lo = min(seed)
    hi = max(seed)
    span = max(1, hi - lo)

    scales = [1, 2, 3, 5, 7, 11, 13, 17, 23, 31, 41, 61,
              -1, -2, -3, -5, -7, -11, -13]
    shifts_frac = [0.0, 0.5, 1.0, -0.5, -1.0, 0.25, 0.75, -0.25, -0.75,
                   0.1, 0.9, -0.1, -0.9]

    for s in scales:
        scaled = [x * s for x in seed]
        slo = min(scaled)
        shi = max(scaled)
        sspan = max(1, shi - slo)
        cand_shifts = set()
        for f in shifts_frac:
            cand_shifts.add(int(-slo + f * sspan))
        for _ in range(6):
            cand_shifts.add(random.randint(-sspan, sspan))
        for t in cand_shifts:
            cand = [x + t for x in scaled]
            k = _key(cand)
            if k > best_key:
                best = cand
                best_key = k
        if time.time() > deadline:
            break
    return best


# ---------------------------------------------------------------- gap compress

def _gap_compress(A, deadline, rounds=200):
    """Remove the largest interior gap by shifting the suffix down by 1.
    Reduces diameter (and often |A+A|) without losing elements."""
    A = sorted(set(int(x) for x in A))
    if len(A) < 3:
        return A
    best = A[:]
    best_key = _key(best)
    for _ in range(rounds):
        if time.time() > deadline:
            break
        cur = best[:]
        # find largest interior gap
        gaps = [(cur[i + 1] - cur[i], i) for i in range(len(cur) - 1)]
        gaps.sort(reverse=True)
        moved = False
        for _, gi in gaps[:5]:
            cand = cur[:gi + 1] + [x - 1 for x in cur[gi + 1:]]
            cand = sorted(set(cand))
            if len(cand) < len(cur):
                continue
            if not _is_sidon_fast(cand):
                continue
            k = _key(cand)
            if k > best_key:
                best = cand
                best_key = k
                moved = True
                break
        if not moved:
            break
    return best


# ---------------------------------------------------------------- driver

def solve():
    random.seed(20240517)
    start = time.time()
    deadline = start + 110

    best = [7, 15, 18, 22, -3, -2]
    best_key = _key(best)

    pool = []
    seen = set()

    def _add(A):
        if not A or len(A) < 2:
            return
        A = tuple(sorted(set(int(x) for x in A)))
        if A in seen:
            return
        seen.add(A)
        pool.append((_key(list(A)), list(A)))

    seed_deadline = time.time() + 0.30 * (deadline - time.time())

    # 1a. Quadratic Sidon family.
    for n in [8, 12, 16, 20, 24, 32, 40, 48, 64, 96, 128]:
        if time.time() > seed_deadline:
            break
        for M in [1, 2, 3, 5, 7, 11, 13, 17, 23, 31, 41, 61, 101]:
            A = _sidon_quadratic(n, M)
            if max(A) > 10**14:
                break
            _add(A)

    # 1b. Powers-of-base.
    for base in (2, 3, 4, 5, 6, 7, 8, 10, 12, 16):
        for n in range(2, 60):
            A = _powers_set(base, n)
            if max(A) > 10**14:
                break
            _add(A)

    # 1c. Greedy Golomb rulers.
    for n in [8, 12, 16, 20, 24, 32, 40, 48, 56, 64]:
        if time.time() > seed_deadline:
            break
        A = _greedy_golomb(n)
        _add(A)

    if not pool:
        pool.append((best_key, best[:]))

    # Phase 2: affine sweep on top seeds.
    pool.sort(key=lambda t: t[0], reverse=True)
    top = pool[:16]
    affine_deadline = time.time() + 0.25 * (deadline - time.time())
    K = len(top)
    slice_t = max(0.1, (affine_deadline - time.time()) / max(1, K))
    swept = []
    for k0, A0 in top:
        if time.time() >= affine_deadline:
            swept.append((k0, A0))
            continue
        t_end = min(affine_deadline, time.time() + slice_t)
        cand = _best_affine(A0, t_end)
        k = _key(cand)
        if k > k0:
            swept.append((k, cand))
        else:
            swept.append((k0, A0))
    swept.sort(key=lambda t: t[0], reverse=True)

    # Phase 3: greedy Sidon extension on the best few.
    ext_deadline = time.time() + 0.20 * (deadline - time.time())
    extended = []
    K2 = max(1, len(swept[:6]))
    slice_e = max(0.1, (ext_deadline - time.time()) / K2)
    for k0, A0 in swept[:6]:
        if time.time() >= ext_deadline:
            extended.append((k0, A0))
            continue
        t_end = min(ext_deadline, time.time() + slice_e)
        cand = _extend_sidon(A0, t_end, max_add=60)
        k = _key(cand)
        if k > k0:
            extended.append((k, cand))
        else:
            extended.append((k0, A0))
    for k0, A0 in swept[6:]:
        extended.append((k0, A0))
    extended.sort(key=lambda t: t[0], reverse=True)

    if extended:
        best, best_key = extended[0][1], extended[0][0]

    # Phase 4: gap compression on best.
    if time.time() < deadline:
        comp = _gap_compress(best, deadline)
        k = _key(comp)
        if k > best_key:
            best, best_key = comp, k

    # Phase 5: final affine sweep on best (fine grid).
    if time.time() < deadline:
        fine = _best_affine(best, deadline)
        k = _key(fine)
        if k > best_key:
            best, best_key = fine, k

    return sorted(set(int(x) for x in best))


if __name__ == "__main__":
    import time as _t
    t0 = _t.time()
    res = solve()
    print("n=", len(res), "score=", _score(res), "time=", _t.time() - t0)
# EVOLVE-BLOCK-END
