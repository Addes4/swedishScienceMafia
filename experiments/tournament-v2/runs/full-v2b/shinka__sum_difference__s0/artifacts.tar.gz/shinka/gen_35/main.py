# EVOLVE-BLOCK-START
"""Head-to-head Bose-Chowla vs Erdos-Turan Sidon seeds + local search polishing
for maximizing log|A-A|/log|A+A| with a bonus for larger sets."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2 or len(diffs) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def erdos_turan_sidon(p):
    """Erdos-Turan Sidon set on the integers:
    A = { 2*p*i + (i*i mod p) : i = 0..p-1 }.
    B_2 set: |A - A| = n*(n-1) + 1. Diameter ~ 2*p^2."""
    A = []
    for i in range(p):
        A.append(2 * p * i + (i * i) % p)
    return sorted(set(A))


def _primitive_root(v):
    """Return a primitive root modulo v (v = p^2 - 1), or None if not found."""
    if v <= 1:
        return None
    # Factor v
    n = v
    factors = set()
    d = 2
    while d * d <= n:
        if n % d == 0:
            factors.add(d)
            while n % d == 0:
                n //= d
        d += 1
    if n > 1:
        factors.add(n)
    # Euler phi
    phi = v
    for f in factors:
        phi -= phi // f
    # Try small candidates
    for g in range(2, min(v, 5000)):
        if math.gcd(g, v) != 1:
            continue
        ok = True
        for f in factors:
            if pow(g, phi // f, v) == 1:
                ok = False
                break
        if ok:
            return g
    return None


def bose_chowla_sidon(p):
    """Bose-Chowla Sidon set: for prime p, v = p^2 - 1, g primitive root mod v.
    A = { i in [0, v-1] : g^i ≡ 1 + i (mod v) }.
    This is a Sidon set of size exactly p, contained in [0, v-1] = [0, p^2-2].
    Diameter ~ p^2 (about half of Erdos-Turan's 2*p^2)."""
    v = p * p - 1
    if v < 3:
        return []
    g = _primitive_root(v)
    if g is None:
        return []
    # Build discrete log table: dlog[g^k mod v] = k
    dlog = [-1] * v
    cur = 1 % v
    for k in range(v):
        if dlog[cur] == -1:
            dlog[cur] = k
        cur = (cur * g) % v
    A = []
    for i in range(v):
        target = (1 + i) % v
        if dlog[target] == i:
            A.append(i)
    return sorted(set(A))


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _polish(A, deadline, rng):
    """Greedy improving-moves local search. Only accepts strictly improving
    moves (plus a tiny SA acceptance early on) so the Sidon structure is not
    destroyed. Move types: shift an element, add an element, remove an element."""
    A = sorted(set(A))
    if len(A) < 2:
        return A
    best = A[:]
    best_s = _score(best)
    cur = A[:]
    cur_s = best_s
    start = time.time()
    total = max(0.001, deadline - start)
    T0 = 0.05
    while time.time() < deadline:
        t = (time.time() - start) / total
        T = T0 * (0.001 / T0) ** min(1.0, max(0.0, t))
        cand = cur[:]
        r = rng.random()
        if r < 0.7:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-3, -2, -1, 1, 2, 3, -5, 5])
        elif r < 0.85 and len(cand) < 4000:
            lo, hi = min(cand), max(cand)
            cand.append(rng.randint(lo - 5, hi + 5))
        elif len(cand) > 3:
            i = rng.randrange(len(cand))
            cand.pop(i)
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_s or rng.random() < math.exp((s - cur_s) / max(T, 1e-9)):
            cur = cand
            cur_s = s
            if s > best_s:
                best = cand[:]
                best_s = s
    return best


def _sum_compress(A, deadline, rng):
    """Try to shrink |A+A| by moving individual elements while keeping |A-A|
    intact. Strictly improving moves only."""
    A = sorted(set(A))
    if len(A) < 2:
        return A
    best = A[:]
    best_s = _score(best)
    diffs = {x - y for x in A for y in A}
    ld = len(diffs)
    sums = {x + y for x in A for y in A}
    ls = len(sums)
    n = len(A)
    while time.time() < deadline:
        i = rng.randrange(len(A))
        cand = A[:]
        # Try a nearby target within the current span
        lo, hi = min(A), max(A)
        span = hi - lo
        step = rng.randint(1, max(2, span // 20))
        cand[i] += rng.choice([-step, step, -1, 1, -2, 2])
        cand = sorted(set(cand))
        if len(cand) != n:
            continue
        cd = {x - y for x in cand for y in cand}
        if len(cd) < ld:
            continue
        cs = {x + y for x in cand for y in cand}
        if len(cs) <= ls:
            # Accept if strictly reduces sums (or same sums with same diffs)
            if len(cs) < ls or len(cd) > ld:
                A = cand
                if len(cd) > ld:
                    ld = len(cd)
                if len(cs) < ls:
                    ls = len(cs)
                s = math.log(ld) / math.log(ls) + (1 - 1 / n) / 100
                if s > best_s:
                    best = cand[:]
                    best_s = s
    return best


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small:
    maximise log|A - A| / log|A + A|."""
    deadline = time.time() + 110
    rng = random.Random(20240607)

    primes = [3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59,
              61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127,
              131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191,
              193, 197, 199, 211, 223, 227, 229, 233, 239, 251, 257, 263,
              269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337,
              347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409,
              419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479,
              487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569,
              571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641,
              643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719,
              727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809,
              811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881,
              883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971,
              977, 983, 991, 997]

    best = None
    best_score = -1.0
    best_kind = None

    # Head-to-head sweep: Erdos-Turan vs Bose-Chowla for each prime.
    for p in primes:
        A_et = erdos_turan_sidon(p)
        if len(A_et) >= 2:
            s = _score(A_et)
            if s > best_score:
                best_score = s
                best = A_et[:]
                best_kind = "ET"
        A_bc = bose_chowla_sidon(p)
        if len(A_bc) >= 2:
            s = _score(A_bc)
            if s > best_score:
                best_score = s
                best = A_bc[:]
                best_kind = "BC"

    # Fallback compact baseline.
    compact = [7, 15, 18, 22, -3, -2]
    s = _score(compact)
    if s > best_score:
        best_score = s
        best = compact[:]
        best_kind = "compact"

    # Polish the best construction, then do sum-compression.
    if best is not None and time.time() < deadline - 5:
        polish_deadline = min(deadline - 5, time.time() + (deadline - time.time()) * 0.7)
        cand = _polish(best, polish_deadline, rng)
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s

    if best is not None and time.time() < deadline:
        cand = _sum_compress(best, deadline, rng)
        s = _score(cand)
        if s > best_score:
            best = cand
            best_score = s

    return sorted(set(best))
# EVOLVE-BLOCK-END