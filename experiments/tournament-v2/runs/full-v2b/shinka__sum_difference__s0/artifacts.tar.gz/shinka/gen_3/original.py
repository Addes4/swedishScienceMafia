# EVOLVE-BLOCK-START
"""Improved: algebraic Sidon/Golomb construction + adaptive local refinement.

We build A from a quadratic map over a finite field / modulus, which gives a
Sidon (B_2) set: all pairwise sums are (almost) distinct while differences
cover a large range. This maximizes |A-A| / |A+A| in log-scale.
"""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return score, len(diffs), len(sums)


def _score(a):
    return _stats(a)[0]


def _build_sidon(n, mult=1, shift=0, mod=None):
    """Construct a Sidon-like set via a quadratic sequence.

    Using a_i = i*mult + i*i (mod mod) mapped into a range, we get a B_2 set:
    sums i+j and i^2+j^2 determine the pair, so sums are highly distinct
    (small sum set collisions) while differences are numerous.
    """
    if mod is None:
        mod = max(3, n * n + 1)
    A = []
    for i in range(n):
        v = (i * mult + i * i + shift) % mod
        A.append(v)
    return A


def _local_refine(A, deadline, budget_frac=0.55):
    """Adaptive hill climbing with geometrically shrinking step sizes."""
    A = list(set(A))
    best = A[:]
    best_score = _score(best)
    cur = A[:]
    cur_score = best_score
    step = max(1, int(0.05 * (max(cur) - min(cur) + 1)) if len(cur) > 1 else 3)
    no_improve = 0
    t_end = time.time() + (deadline - time.time()) * budget_frac
    while time.time() < t_end:
        cand = cur[:]
        op = random.random()
        if op < 0.70 and len(cand) > 2:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-step, step)
        elif op < 0.90:
            cand.append(random.randint(-step * 4, step * 4))
        else:
            if len(cand) > 3:
                del cand[random.randrange(len(cand))]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            no_improve = 0
            if s > best_score:
                best, best_score = cand[:], s
        else:
            no_improve += 1
            if no_improve > 200:
                step = max(1, step // 2)
                no_improve = 0
            if random.random() < 0.08:
                cur, cur_score = best[:], best_score
    return best, best_score


def solve():
    random.seed(12345)
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Try a family of algebraic constructions with different sizes / moduli.
    sizes = [8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256, 384, 512, 768, 1024]
    mults = [1, 2, 3, 5, 7]
    for n in sizes:
        for mult in mults:
            for shift in (0, 1, 3):
                mod = max(3, n * n + 1)
                A = _build_sidon(n, mult=mult, shift=shift, mod=mod)
                A = list(set(A))
                if len(A) < 2:
                    continue
                s = _score(A)
                if s > best_score:
                    best_score = s
                    best = A[:]
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # Refine the best algebraic candidate.
    if best is not None and time.time() < deadline:
        best, best_score = _local_refine(best, deadline, budget_frac=0.7)

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    return sorted(set(int(x) for x in best))


if __name__ == "__main__":
    import time as _t
    t0 = _t.time()
    res = solve()
    print("n=", len(res), "score=", _score(res), "time=", _t.time() - t0)
# EVOLVE-BLOCK-END