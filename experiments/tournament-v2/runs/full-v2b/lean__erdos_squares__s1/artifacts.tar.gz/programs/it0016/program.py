# EVOLVE-BLOCK-START
"""Greedy packing plus local refinement with structured 'big square + strip' layouts."""
import math
import random


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-9 and x + h <= 1 + 1e-9 and y - h >= -1e-9 and y + h <= 1 + 1e-9


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
        cands.append((o[0] + o[3] / 2.0, o[1] + o[3] / 2.0))
        cands.append((o[0] - o[3] / 2.0, o[1] + o[3] / 2.0))
        cands.append((o[0] + o[3] / 2.0, o[1] - o[3] / 2.0))
        cands.append((o[0] - o[3] / 2.0, o[1] - o[3] / 2.0))
    for gx in range(1, 22):
        for gy in range(1, 22):
            cands.append((gx / 22.0, gy / 22.0))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=80):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _random_greedy(n, rng):
    layout = []
    for _ in range(n):
        base = _largest_fit(layout)
        # jitter the center a little to explore different configurations
        entries = []
        entries.append((base[3], base))
        for _ in range(6):
            nx = min(max(base[0] + (rng.random() - 0.5) * 0.2, 0.05), 0.95)
            ny = min(max(base[1] + (rng.random() - 0.5) * 0.2, 0.05), 0.95)
            sq = _largest_fit(layout + [(nx, ny, 0.0, 0.0)])
            entries.append((sq[3], sq))
        entries.sort(key=lambda e: -e[0])
        layout.append(list(entries[0][1]))
    return [tuple(s) for s in layout]


def _pack_density(layout):
    return sum(s[3] for s in layout)


def _compact(layout, iters=120, seed=0):
    """Relaxation/compaction: try to grow each square while pushing others away."""
    rng = random.Random(seed)
    lay = [list(s) for s in layout]
    n = len(lay)
    best = [tuple(s) for s in lay]
    best_tot = sum(s[3] for s in lay)

    def violates(ls):
        for i in range(n):
            s = ls[i]
            if s[3] < -1e-9:
                return True
            if not _inside(s):
                return True
        for i in range(n):
            for j in range(i + 1, n):
                if _overlap(ls[i], ls[j]):
                    return True
        return False

    for it in range(iters):
        i = rng.randrange(n)
        grow = 1.0 + rng.uniform(0.005, 0.05)
        cand = [list(s) for s in lay]
        cx, cy, a, sz = cand[i]
        cand[i][3] = sz * grow
        if violates(cand):
            # attempt to resolve by pushing conflicting squares
            resolved = False
            for _ in range(30):
                if not violates(cand):
                    resolved = True
                    break
                # push the largest offender slightly away from i
                cx_i, cy_i, _, sz_i = cand[i]
                moved = False
                for j in range(n):
                    if j == i:
                        continue
                    if _overlap(cand[i], cand[j]):
                        dx = cand[j][0] - cx_i
                        dy = cand[j][1] - cy_i
                        d = math.hypot(dx, dy)
                        if d < 1e-6:
                            dx, dy, d = 1.0, 0.0, 1.0
                        step = 0.01
                        cand[j][0] = min(max(cand[j][0] + step * dx / d, 0.0), 1.0)
                        cand[j][1] = min(max(cand[j][1] + step * dy / d, 0.0), 1.0)
                        moved = True
                if not moved:
                    break
            if not violates(cand):
                resolved = True
            if not resolved:
                continue
        lay = cand
        tot = sum(s[3] for s in lay)
        if tot > best_tot + 1e-12 and not violates(lay):
            best_tot = tot
            best = [tuple(s) for s in lay]
    return best


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    rng = random.Random(12345)
    for _ in range(6):
        candidates.append(_random_greedy(n, rng))

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    # compaction polish on the best structured candidate
    polished = _compact(best[1])
    ref2 = _refine(polished, rounds=40)
    if _valid(ref2):
        t2 = sum(s[3] for s in ref2)
        if t2 > best[0]:
            best = (t2, ref2)

    return best[1]
# EVOLVE-BLOCK-END
