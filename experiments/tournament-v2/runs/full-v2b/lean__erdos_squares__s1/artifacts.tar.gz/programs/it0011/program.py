# EVOLVE-BLOCK-START
"""Greedy packing plus local refinement with structured 'big square + L-strip' layouts."""
import math


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-9 and x + h <= 1 + 1e-9 and y - h >= -1e-9 and y + h <= 1 + 1e-9


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
    for gx in range(1, 14):
        for gy in range(1, 14):
            cands.append((gx / 14.0, gy / 14.0))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=60):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _big_plus_strip(n):
    """One large square in a corner, remaining n-1 squares tiled in the L-shaped region.

    The L region for a big square of side b in the bottom-left corner is:
      right strip: [b,1] x [0,1]      (width 1-b, height 1)
      top strip:   [0,b] x [b,1]      (width b, height 1-b)
    We tile with a single square size s, using some columns in the right strip and
    some in the top strip, sized to actually fit each region.
    """
    results = []
    if n < 1:
        return results
    k = n - 1  # squares outside the big one

    # Try big-square sizes; use finer resolution near interesting values.
    bs = set()
    for i in range(1, 400):
        bs.add(i / 400.0)
    # also candidate sizes derived from small grids
    for cols in range(1, n + 1):
        bs.add(1.0 / cols)
        bs.add(1.0 - 1.0 / cols)

    for b in sorted(bs):
        avail_w = 1.0 - b   # width of right strip
        avail_h = 1.0 - b   # height of top strip above big square
        if avail_w <= 1e-9:
            continue

        # right strip width avail_w, full height 1 ; top strip height avail_h, width b
        # We choose a target size s, then compute how many squares fit in each strip.
        # Try a range of s values and counts split.
        for cr in range(0, k + 1):
            ct = k - cr
            # s must allow cr squares in right strip [0,avail_w]x[0,1]
            # and ct squares in top strip [0,b]x[b,1]
            # right strip: ncols_r cols, nrows_r rows with cols*rows>=cr
            # Simplify: pick ncols_r in 1..cr for right, etc.
            for ncols_r in range(1, cr + 1) if cr > 0 else [0]:
                if cr == 0:
                    s_r = 1e9
                else:
                    nrows_r = (cr + ncols_r - 1) // ncols_r
                    s_r = min(avail_w / ncols_r, 1.0 / nrows_r)
                if ct == 0:
                    s_t = 1e9
                else:
                    if b <= 1e-9:
                        continue
                    for nrows_t in range(1, ct + 1):
                        ncols_t = (ct + nrows_t - 1) // nrows_t
                        s_t = min(b / ncols_t, avail_h / nrows_t)
                        s = min(s_r, s_t)
                        if s <= 1e-9:
                            continue
                        nmax_r = int(min(avail_w // s + 1e-9, 1.0 // s + 1e-9))
                        # build layout and validate; break on first cr/ct that fails badly?
                        layout = [(b / 2.0, b / 2.0, 0.0, b)]
                        idx = 0
                        # right strip
                        if cr > 0:
                            ncols_rr = max(1, int(avail_w / s + 1e-9))
                            nrows_rr = (cr + ncols_rr - 1) // ncols_rr
                            if ncols_rr * nrows_rr < cr:
                                continue
                            cnt = 0
                            for r in range(nrows_rr):
                                for c in range(ncols_rr):
                                    if cnt >= cr:
                                        break
                                    cx = b + (c + 0.5) * s
                                    cy = (r + 0.5) * s
                                    layout.append((cx, cy, 0.0, s))
                                    cnt += 1
                                if cnt >= cr:
                                    break
                            if cnt < cr:
                                continue
                        # top strip
                        if ct > 0:
                            nrows_tt = max(1, int(avail_h / s + 1e-9))
                            ncols_tt = (ct + nrows_tt - 1) // nrows_tt
                            if ncols_tt * nrows_tt < ct or ncols_tt * s > b + 1e-9:
                                continue
                            cnt = 0
                            for r in range(nrows_tt):
                                for c in range(ncols_tt):
                                    if cnt >= ct:
                                        break
                                    cx = (c + 0.5) * s
                                    cy = b + (r + 0.5) * s
                                    layout.append((cx, cy, 0.0, s))
                                    cnt += 1
                                if cnt >= ct:
                                    break
                            if cnt < ct:
                                continue
                        if len(layout) != n:
                            continue
                        if _valid(layout):
                            results.append(layout)
        # limit combinatorial blow-up
        if len(results) > 4000:
            break
    return results


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    for lay in _big_plus_strip(n):
        candidates.append(lay)

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    return best[1]
# EVOLVE-BLOCK-END
