# EVOLVE-BLOCK-START
"""Grid packing plus a simple axis-aligned local-search redistribution pass."""
import math


def _grid_candidates(n):
    """Yield candidate layouts (total, squares) for various rows x cols grids."""
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        if rows * cols < n:
            continue
        side = min(1.0 / cols, 1.0 / rows)
        if side <= 0:
            continue
        squares = []
        idx = 0
        for r in range(rows):
            for c in range(cols):
                if idx >= n:
                    break
                cx = (c + 0.5) * side
                cy = (r + 0.5) * side
                squares.append([cx, cy, 0.0, side])
                idx += 1
            if idx >= n:
                break
        while len(squares) < n:
            squares.append([0.5, 0.5, 0.0, 0.0])
        yield squares


def _total(squares):
    return sum(s[3] for s in squares)


def _fits(sq, others, eps=1e-12):
    """Axis-aligned overlap check (angles are 0 here)."""
    x, y, a, s = sq
    h = s / 2.0
    x0, x1 = x - h, x + h
    y0, y1 = y - h, y + h
    if x0 < -eps or x1 > 1 + eps or y0 < -eps or y1 > 1 + eps:
        return False
    for o in others:
        ox, oy, oa, os_ = o
        oh = os_ / 2.0
        ox0, ox1 = ox - oh, ox + oh
        oy0, oy1 = oy - oh, oy + oh
        if x0 < ox1 - eps and ox0 < x1 - eps and y0 < oy1 - eps and oy0 < y1 - eps:
            return False
    return True


def _local_search(squares, rounds=2000):
    """Grow each square into local space; shrink when necessary to relocate."""
    squares = [list(s) for s in squares]
    n = len(squares)
    if n == 0:
        return squares
    # Try uniform scaling up if it all fits, then per-square growth.
    lo, hi = 1.0, 2.0
    for _ in range(40):
        mid = (lo + hi) / 2.0
        ok = True
        for i in range(n):
            x, y, a, s = squares[i]
            ns = s * mid
            h = ns / 2.0
            if x - h < -1e-12 or x + h > 1 + 1e-12 or y - h < -1e-12 or y + h > 1 + 1e-12:
                ok = False
                break
            for j in range(n):
                if i == j:
                    continue
                ox, oy, _, os_ = squares[j]
                oh = os_ / 2.0
                if (x - h < ox + oh - 1e-12 and ox - oh < x + h - 1e-12 and
                        y - h < oy + oh - 1e-12 and oy - oh < y + h - 1e-12):
                    ok = False
                    break
            if not ok:
                break
        if ok:
            lo = mid
        else:
            hi = mid
    scale = lo
    if scale > 1.0:
        for i in range(n):
            squares[i][3] *= scale

    # Per-square greedy growth: for each, try to increase its side.
    order = sorted(range(n), key=lambda i: squares[i][3], reverse=True)
    for _ in range(3):
        for i in order:
            x, y, a, s = squares[i]
            others = [squares[j] for j in range(n) if j != i]
            best_s = s
            # binary search max side keeping center fixed
            lo2, hi2 = s, min(1.0, 2.0 * s + 1.0)
            for _ in range(30):
                mid = (lo2 + hi2) / 2.0
                if _fits([x, y, 0.0, mid], others):
                    lo2 = mid
                else:
                    hi2 = mid
            best_s = lo2
            squares[i][3] = best_s
    return squares


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    best_total = -1.0
    best_squares = None
    for cand in _grid_candidates(n):
        layout = _local_search(cand)
        t = _total(layout)
        if t > best_total:
            best_total = t
            best_squares = layout

    # Clean up: clamp to [0,1] and ensure float output.
    out = []
    for x, y, a, s in best_squares:
        if s < 0:
            s = 0.0
        if s > 1.0:
            s = 1.0
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        out.append((float(x), float(y), float(a), float(s)))
    return out
# EVOLVE-BLOCK-END

