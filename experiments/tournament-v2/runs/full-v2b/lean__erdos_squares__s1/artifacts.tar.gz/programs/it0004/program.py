# EVOLVE-BLOCK-START
"""Greedy packing: grid base plus largest-free-rectangle greedy to reclaim leftover space."""
import math


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _grid_score(n, cols):
    return sum(s[3] for s in _grid_layout(n, cols))


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _recursive_pack(n, w, h, x0, y0, out):
    """Recursively split a w x h rectangle into n pieces, packing squares."""
    if n <= 0:
        return
    if n == 1:
        s = min(w, h)
        out.append((x0 + s / 2.0, y0 + s / 2.0, 0.0, s))
        return
    # Try to split into two groups separated by a vertical or horizontal cut.
    best = None
    for k in range(1, n):
        # vertical split
        # group1 with k squares in width a, group2 with n-k in width w-a
        # choose a to balance
        a = w * k / n
        # estimate: each group packs into a x h and (w-a) x h
        # use uniform grid estimates
        def est(cnt, ww, hh):
            if cnt <= 0:
                return 0.0
            cols = max(1, int(math.ceil(math.sqrt(cnt * ww / hh)))) if hh > 0 else 1
            rows = (cnt + cols - 1) // cols
            return cnt * min(ww / cols, hh / rows)
        e1 = est(k, a, h) + est(n - k, w - a, h)
        # horizontal split
        b = h * k / n
        e2 = est(k, w, b) + est(n - k, w, h - b)
        if best is None or e1 > best[0]:
            best = (e1, 'v', a)
        if e2 > best[0]:
            best = (e2, 'h', b)
    if best is None:
        s = min(w, h)
        for _ in range(n):
            out.append((x0 + s / 2.0, y0 + s / 2.0, 0.0, s))
        return
    _, kind, cut = best
    # Place greedily: choose cut so each side uses a grid, then fill.
    if kind == 'v':
        a = cut
        # allocate counts proportional to areas
        ka = max(1, min(n - 1, int(round(n * a / w))))
        # place ka in left, rest in right using grids
        _place_grid(ka, a, h, x0, y0, out)
        _place_grid(n - ka, w - a, h, x0 + a, y0, out)
    else:
        b = cut
        ka = max(1, min(n - 1, int(round(n * b / h))))
        _place_grid(ka, w, b, x0, y0, out)
        _place_grid(n - ka, w, h - b, x0, y0 + b, out)


def _place_grid(cnt, w, h, x0, y0, out):
    if cnt <= 0:
        return
    best = None
    for cols in range(1, cnt + 1):
        rows = (cnt + cols - 1) // cols
        side = min(w / cols, h / rows)
        if best is None or cols * rows < best[0] and False:
            pass
        # score by how many fit and total
        # count squares actually placeable
        idx = 0
        tot = 0.0
        for r in range(rows):
            for c in range(cols):
                if idx >= cnt:
                    break
                tot += side
                idx += 1
            if idx >= cnt:
                break
        if best is None or tot > best[0]:
            best = (tot, cols, rows, side)
    _, cols, rows, side = best
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= cnt:
                break
            out.append((x0 + (c + 0.5) * side, y0 + (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= cnt:
            break
    while idx < cnt:
        out.append((x0 + w / 2.0, y0 + h / 2.0, 0.0, 0.0))
        idx += 1


def solve(n):
    if n <= 0:
        return []

    best = _best_grid(n)

    # Candidate: recursive guillotine partition
    for w_split in [1.0]:
        out = []
        _recursive_pack(n, 1.0, 1.0, 0.0, 0.0, out)
        if len(out) == n:
            tot = sum(s[3] for s in out)
            if tot > best[0]:
                best = (tot, out)

    return best[1]
# EVOLVE-BLOCK-END

