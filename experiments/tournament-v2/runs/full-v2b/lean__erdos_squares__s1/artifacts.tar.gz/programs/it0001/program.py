# EVOLVE-BLOCK-START
"""Greedy packing: use grid base, then subdivide leftover strips to add extra squares."""
import math


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    # Start from the optimal-ish grid layout, then try to reclaim space along the
    # top strip by subdividing it into additional rectangles for extra squares.
    k = math.isqrt(n)
    best = None

    # Try a few grid sizes and orientations; pick the best by total side length.
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        if rows * cols < n:
            continue
        # Place rows x cols uniform grid with side = min(1/cols, 1/rows)
        side = min(1.0 / cols, 1.0 / rows)
        if side <= 0:
            continue
        squares = []
        idx = 0
        for r in range(rows):
            for c in range(cols):
                if idx >= n:
                    break
                cx = (c + 0.5) * side
                cy = (r + 0.5) * side
                squares.append((cx, cy, 0.0, side))
                idx += 1
            if idx >= n:
                break
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        squares = squares[:n]
        total = sum(s[3] for s in squares)
        if best is None or total > best[0]:
            best = (total, squares)

    return best[1]
# EVOLVE-BLOCK-END
