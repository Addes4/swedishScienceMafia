# EVOLVE-BLOCK-START
"""Greedy packing plus structured slicing layouts and local refinement."""
import math


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-9 and x + h <= 1 + 1e-9 and y - h >= -1e-9 and y + h <= 1 + 1e-9


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
    for gx in range(1, 14):
        for gy in range(1, 14):
            cands.append((gx / 14.0, gy / 14.0))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=40):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _rect_grid_best_squares(rw, rh, k):
    best = None
    for cols in range(1, k + 1):
        rows = (k + cols - 1) // cols
        if cols * rows < k:
            continue
        s = min(rw / cols, rh / rows)
        tot = k * s
        if best is None or tot > best[0]:
            placements = []
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = (c + 0.5) * (rw / cols)
                    cy = (r + 0.5) * (rh / rows)
                    placements.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k:
                    break
            best = (tot, placements)
    return best


def _tile_rect(rw, rh, k, ox, oy):
    r = _rect_grid_best_squares(rw, rh, k)
    if r is None:
        return None
    tot, placements = r
    out = [(px + ox, py + oy, a, s) for (px, py, a, s) in placements]
    return tot, out


def _slicing_layouts(n, max_splits=3):
    results = []

    for k1 in range(1, n):
        k2 = n - k1
        best_for = None
        for fi in range(1, 1000):
            f = fi / 1000.0
            r1 = _tile_rect(f, 1.0, k1, 0.0, 0.0)
            if r1 is None:
                continue
            r2 = _tile_rect(1.0 - f, 1.0, k2, f, 0.0)
            if r2 is None:
                continue
            tot = r1[0] + r2[0]
            if best_for is None or tot > best_for[0]:
                best_for = (tot, r1[1] + r2[1])
        if best_for is not None:
            results.append(best_for[1])

    for k1 in range(1, n):
        k2 = n - k1
        best_for = None
        for fi in range(1, 1000):
            f = fi / 1000.0
            r1 = _tile_rect(1.0, f, k1, 0.0, 0.0)
            if r1 is None:
                continue
            r2 = _tile_rect(1.0, 1.0 - f, k2, 0.0, f)
            if r2 is None:
                continue
            tot = r1[0] + r2[0]
            if best_for is None or tot > best_for[0]:
                best_for = (tot, r1[1] + r2[1])
        if best_for is not None:
            results.append(best_for[1])

    return results


def _corner_big_l(n):
    """Big square (size b) in bottom-left corner; remaining k=n-1 squares tile the
    L-region = right strip [b,1]x[0,1-b?] ... Actually L-region is unit square minus
    the big square.  We tile the L-region by two rectangles: right strip [b,1]x[0,1]
    with k1 squares, top-left strip [0,b]x[b,1] with k2 squares, using a common tile
    size s shared by both strips (so squares in both strips have equal size)."""
    results = []
    k = n - 1
    if k <= 0:
        return results
    # scan b
    steps = 200
    for bi in range(1, steps):
        b = bi / steps
        rw = 1.0 - b      # right strip width
        rh = 1.0 - b      # top strip height
        # right strip: rw x 1.0 ; top strip: b x rh
        for k1 in range(0, k + 1):
            k2 = k - k1
            # choose cols/rows for each strip
            best_pair = None
            for c1 in range(1, k1 + 1):
                rows1 = (k1 + c1 - 1) // c1
                for c2 in range(1, k2 + 1):
                    rows2 = (k2 + c2 - 1) // c2
                    if k1 > 0:
                        s1 = min(rw / c1, 1.0 / rows1)
                    else:
                        s1 = float('inf')
                    if k2 > 0:
                        s2 = min(b / c2, rh / rows2)
                    else:
                        s2 = float('inf')
                    s = min(s1, s2)
                    if s <= 0 or s == float('inf'):
                        continue
                    if best_pair is None or s > best_pair[0]:
                        best_pair = (s, c1, rows1, c2, rows2)
            if best_pair is None:
                continue
            s, c1, rows1, c2, rows2 = best_pair
            # place big square
            layout = [(b / 2.0, b / 2.0, 0.0, b)]
            # right strip occupies x in [b,1], y in [0,1]
            idx = 0
            ok = True
            for r in range(rows1):
                for c in range(c1):
                    if idx >= k1:
                        break
                    # center cell within rw x 1.0 grid
                    cellw = rw / c1
                    cellh = 1.0 / rows1
                    cx = b + (c + 0.5) * cellw
                    cy = (r + 0.5) * cellh
                    layout.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k1:
                    break
            idx = 0
            for r in range(rows2):
                for c in range(c2):
                    if idx >= k2:
                        break
                    cellw = b / c2
                    cellh = rh / rows2
                    cx = (c + 0.5) * cellw
                    cy = b + (r + 0.5) * cellh
                    layout.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k2:
                    break
            if len(layout) != n:
                continue
            if _valid(layout):
                results.append(layout)
    return results


def _big_plus_strip(n):
    """One large square in a corner, remaining n-1 squares in a grid strip."""
    results = []
    if n < 1:
        return results
    k = n - 1
    for b in [i / 200.0 for i in range(1, 200)]:
        avail_w = 1.0 - b
        if avail_w <= 0:
            continue
        for cols in range(1, k + 1):
            rows = (k + cols - 1) // cols
            s = min(avail_w / cols, 1.0 / rows)
            if s <= 0:
                continue
            if cols * rows < k:
                continue
            layout = [(b / 2.0, b / 2.0, 0.0, b)]
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = b + (c + 0.5) * s
                    cy = (r + 0.5) * (1.0 / rows)
                    layout.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k:
                    break
            if len(layout) != n:
                continue
            if _valid(layout):
                results.append(layout)
    return results


def _rotated_pair_for_5():
    """Classic n=5 optimum: one square of side 1/2 plus four of side 1/4? no.
    Known best for 5 is 2.0. Provide structured candidate anyway."""
    return None


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    for lay in _big_plus_strip(n):
        candidates.append(lay)
    for lay in _corner_big_l(n):
        candidates.append(lay)
    for lay in _slicing_layouts(n):
        candidates.append(lay)

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    return best[1]
# EVOLVE-BLOCK-END
