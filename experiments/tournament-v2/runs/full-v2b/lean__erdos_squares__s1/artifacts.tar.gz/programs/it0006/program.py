# EVOLVE-BLOCK-START
"""Greedy packing plus local refinement: grid base, free-rectangle greedy, then reinsertion search."""
import math

# ---------------------------------------------------------------------------
# geometry helpers (rotated squares, exact-ish overlap via SAT + sampling)
# ---------------------------------------------------------------------------
_SQRT1_2 = math.sqrt(0.5)


def _corners(s):
    """Return the 4 corner points of square s=(cx,cy,angle,side)."""
    cx, cy, a, sz = s
    h = sz / 2.0
    ang = a * 2.0 * math.pi
    ca = math.cos(ang)
    sa = math.sin(ang)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _proj(pts, axis):
    ax, ay = axis
    dots = [px * ax + py * ay for px, py in pts]
    return min(dots), max(dots)


def _overlap(a, b):
    """Separating axis theorem for two rotated squares. Returns True if interiors overlap."""
    if a[3] <= 0 or b[3] <= 0:
        return False
    ca = _corners(a)
    cb = _corners(b)
    axes = []
    for pts in (ca, cb):
        for i in range(4):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            axes.append((-ey, ex))
    for ax, ay in axes:
        n = math.hypot(ax, ay)
        if n == 0:
            continue
        ax, ay = ax / n, ay / n
        lo1, hi1 = _proj(ca, (ax, ay))
        lo2, hi2 = _proj(cb, (ax, ay))
        if hi1 <= lo2 + 1e-9 or hi2 <= lo1 + 1e-9:
            return False
    return True


def _inside(s):
    """Check all corners inside unit square."""
    if s[3] <= 0:
        return -1e-9 <= s[0] <= 1 + 1e-9 and -1e-9 <= s[1] <= 1 + 1e-9
    for x, y in _corners(s):
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _total(layout):
    return sum(s[3] for s in layout)


# ---------------------------------------------------------------------------
# candidate layouts
# ---------------------------------------------------------------------------
def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _largest_fit(others, angles=(0.0,)):
    """Largest square (over candidate centers and angles) avoiding the others."""
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        h = o[3] / 2.0
        cands.append((o[0] + h, o[1]))
        cands.append((o[0] - h, o[1]))
        cands.append((o[0], o[1] + h))
        cands.append((o[0], o[1] - h))
    for gx in range(1, 12):
        for gy in range(1, 12):
            cands.append((gx / 12.0, gy / 12.0))

    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for ang in angles:
            ss = s
            if ang != 0.0:
                # rotation shrinks max axis-aligned extent; be conservative
                reach = abs(math.cos(ang * 2 * math.pi)) + abs(math.sin(ang * 2 * math.pi))
                ss = min(ss, 2.0 * lim / max(reach, 1e-9))
            trial = (cx, cy, ang, ss)
            # shrink to satisfy walls exactly
            while ss > 1e-9 and not _inside(trial):
                ss *= 0.9
                trial = (cx, cy, ang, ss)
            if ss <= 1e-9:
                continue
            ok = True
            for o in others:
                if o[3] <= 0:
                    continue
                if _overlap(trial, o):
                    ok = False
                    break
            if not ok:
                continue
            if best is None or trial[3] > best[3]:
                best = trial
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


# ---------------------------------------------------------------------------
# refinement
# ---------------------------------------------------------------------------
def _refine(layout, rounds=60, angles=(0.0,)):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others, angles=angles)
            if best is not None and best[3] > removed[3] + 1e-9:
                if all(not _overlap(best, o) for o in others) and _inside(best):
                    layout[i] = list(best)
                    improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand, angles=(0.0,))
        refined = _refine(refined, rounds=25, angles=(0.0, 0.25))
        if not _valid(refined):
            refined = cand
        tot = _total(refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    return best[1]
# EVOLVE-BLOCK-END
