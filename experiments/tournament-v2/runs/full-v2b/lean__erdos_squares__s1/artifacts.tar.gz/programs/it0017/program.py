# EVOLVE-BLOCK-START
"""Greedy packing plus local refinement with structured 'big square + strip' layouts."""
import math
import random


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-9 and x + h <= 1 + 1e-9 and y - h >= -1e-9 and y + h <= 1 + 1e-9


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
    for gx in range(1, 14):
        for gy in range(1, 14):
            cands.append((gx / 14.0, gy / 14.0))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=60):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _repack_polish(layout, iters=400, seed=0):
    """Remove the smallest squares and greedily re-insert fresh largest-fit squares."""
    rnd = random.Random(seed)
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(iters):
        k = rnd.randint(1, min(3, n))
        order = sorted(range(n), key=lambda i: layout[i][3])
        remove = set(order[:k])
        kept = [layout[i] for i in range(n) if i not in remove]
        # rebuild: reinsert k new squares greedily
        new = list(kept)
        for _ in range(k):
            sq = _largest_fit(new)
            new.append(list(sq))
        if len(new) != n:
            continue
        new_sum = sum(s[3] for s in new)
        old_sum = sum(s[3] for s in layout)
        if new_sum > old_sum + 1e-9:
            layout = new
    return [tuple(s) for s in layout]


def _jitter_sa(layout, seconds_budget=3.0, seed=1):
    """Randomized search: randomly perturb sides/centers and accept improvements."""
    import time
    rnd = random.Random(seed)
    layout = [list(s) for s in layout]
    n = len(layout)
    best = [list(s) for s in layout]
    best_sum = sum(s[3] for s in layout)
    t0 = time.time()
    it = 0
    while time.time() - t0 < seconds_budget:
        it += 1
        i = rnd.randrange(n)
        cand = [list(s) for s in layout]
        s = cand[i]
        s[3] = max(0.0, s[3] * (1.0 + rnd.uniform(-0.05, 0.05)))
        s[0] += rnd.uniform(-0.02, 0.02)
        s[1] += rnd.uniform(-0.02, 0.02)
        if _valid(cand):
            tot = sum(x[3] for x in cand)
            if tot >= sum(x[3] for x in layout) - 1e-9:
                layout = cand
                if tot > best_sum:
                    best_sum = tot
                    best = [list(x) for x in cand]
    return [tuple(x) for x in best]


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        repacked = _repack_polish(refined, iters=200, seed=n)
        if _valid(repacked):
            refined = repacked
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    # SA polish on the best candidate
    if best is not None:
        polished = _jitter_sa(best[1], seconds_budget=4.0, seed=n * 7 + 1)
        if _valid(polished):
            tot = sum(s[3] for s in polished)
            if tot > best[0]:
                best = (tot, polished)

    return best[1]
# EVOLVE-BLOCK-END
