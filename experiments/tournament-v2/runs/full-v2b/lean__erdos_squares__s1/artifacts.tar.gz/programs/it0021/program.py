# EVOLVE-BLOCK-START
"""Greedy packing plus structured slicing layouts and continuous relaxation."""
import math
import random


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-9 and dy < ha + hb - 1e-9


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-7 and x + h <= 1 + 1e-7 and y - h >= -1e-7 and y + h <= 1 + 1e-7


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
    for gx in range(1, 14):
        for gy in range(1, 14):
            cands.append((gx / 14.0, gy / 14.0))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=40):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


# -------- Slicing (guillotine) layouts --------

def _rect_grid_best_squares(rw, rh, k):
    best = None
    for cols in range(1, k + 1):
        rows = (k + cols - 1) // cols
        if cols * rows < k:
            continue
        s = min(rw / cols, rh / rows)
        tot = k * s
        if best is None or tot > best[0]:
            placements = []
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = (c + 0.5) * (rw / cols)
                    cy = (r + 0.5) * (rh / rows)
                    placements.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k:
                    break
            best = (tot, placements)
    return best


def _slicing_layouts(n, max_splits=3):
    results = []

    def tile_rect(rw, rh, k, ox, oy):
        r = _rect_grid_best_squares(rw, rh, k)
        if r is None:
            return None
        tot, placements = r
        out = [(px + ox, py + oy, a, s) for (px, py, a, s) in placements]
        return tot, out

    for k1 in range(1, n):
        k2 = n - k1
        best_for = None
        for fi in range(1, 1000):
            f = fi / 1000.0
            r1 = tile_rect(f, 1.0, k1, 0.0, 0.0)
            if r1 is None:
                continue
            r2 = tile_rect(1.0 - f, 1.0, k2, f, 0.0)
            if r2 is None:
                continue
            tot = r1[0] + r2[0]
            if best_for is None or tot > best_for[0]:
                best_for = (tot, r1[1] + r2[1])
        if best_for is not None:
            results.append(best_for[1])

    for k1 in range(1, n):
        k2 = n - k1
        best_for = None
        for fi in range(1, 1000):
            f = fi / 1000.0
            r1 = tile_rect(1.0, f, k1, 0.0, 0.0)
            if r1 is None:
                continue
            r2 = tile_rect(1.0, 1.0 - f, k2, 0.0, f)
            if r2 is None:
                continue
            tot = r1[0] + r2[0]
            if best_for is None or tot > best_for[0]:
                best_for = (tot, r1[1] + r2[1])
        if best_for is not None:
            results.append(best_for[1])

    return results


def _big_plus_strip(n):
    results = []
    if n < 1:
        return results
    k = n - 1
    for b in [i / 200.0 for i in range(1, 200)]:
        avail_w = 1.0 - b
        if avail_w <= 0:
            continue
        for cols in range(1, k + 1):
            rows = (k + cols - 1) // cols
            s = min(avail_w / cols, 1.0 / rows)
            if s <= 0:
                continue
            if cols * rows < k:
                continue
            layout = [(b / 2.0, b / 2.0, 0.0, b)]
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = b + (c + 0.5) * s
                    cy = (r + 0.5) * (1.0 / rows)
                    layout.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k:
                    break
            if len(layout) != n:
                continue
            if _valid(layout):
                results.append(layout)
    return results


# -------- Continuous relaxation: grow one square, push neighbors --------

def _grow_relax(layout, i, iters=120, step=0.02):
    """Try to enlarge square i by pushing overlapping neighbors apart (axis aligned)."""
    lay = [list(s) for s in layout]
    n = len(lay)
    if lay[i][3] <= 0:
        return layout
    target = lay[i][3] + step
    for _ in range(iters):
        # keep square i fixed, enlarge
        lay[i][3] = min(target, lay[i][3] + step)
        moved = False
        for j in range(n):
            if j == i:
                continue
            if lay[j][3] <= 0:
                continue
            # compute overlap region
            dx = lay[i][0] - lay[j][0]
            dy = lay[i][1] - lay[j][1]
            hi = lay[i][3] / 2.0
            hj = lay[j][3] / 2.0
            ox = hi + hj - abs(dx)
            oy = hi + hj - abs(dy)
            if ox > 1e-9 and oy > 1e-9:
                # push j along the axis of least overlap
                push = min(ox, oy)
                if ox < oy:
                    sgn = 1.0 if dx > 0 else -1.0
                    lay[j][0] -= sgn * push
                else:
                    sgn = 1.0 if dy > 0 else -1.0
                    lay[j][1] -= sgn * push
                moved = True
            # clamp j inside
            hl = lay[j][3] / 2.0
            lay[j][0] = max(hl, min(1.0 - hl, lay[j][0]))
            lay[j][1] = max(hl, min(1.0 - hl, lay[j][1]))
        # check if square i overlaps still
        ok = True
        for j in range(n):
            if j == i or lay[j][3] <= 0:
                continue
            dx = abs(lay[i][0] - lay[j][0])
            dy = abs(lay[i][1] - lay[j][1])
            hi = lay[i][3] / 2.0
            hj = lay[j][3] / 2.0
            if dx < hi + hj - 1e-7 and dy < hi + hj - 1e-7:
                ok = False
                break
        if ok and _inside(lay[i]):
            # success: keep grown size; also try to re-enlarge neighbors later
            continue
        else:
            # shrink square i back a bit and stop
            lay[i][3] -= step
            break
    # snap: ensure inside and no overlap by tiny shrink of all
    for _ in range(50):
        bad = False
        for j in range(n):
            if lay[j][3] <= 0:
                continue
            hl = lay[j][3] / 2.0
            if lay[j][0] - hl < -1e-9 or lay[j][0] + hl > 1 + 1e-9 or \
               lay[j][1] - hl < -1e-9 or lay[j][1] + hl > 1 + 1e-9:
                bad = True
        for a in range(n):
            if lay[a][3] <= 0:
                continue
            for b in range(a + 1, n):
                if lay[b][3] <= 0:
                    continue
                dx = abs(lay[a][0] - lay[b][0])
                dy = abs(lay[a][1] - lay[b][1])
                ha = lay[a][3] / 2.0
                hb = lay[b][3] / 2.0
                if dx < ha + hb - 1e-9 and dy < ha + hb - 1e-9:
                    bad = True
        if not bad:
            break
        # shrink all slightly
        for j in range(n):
            lay[j][3] *= 0.999
            hl = lay[j][3] / 2.0
            lay[j][0] = max(hl, min(1.0 - hl, lay[j][0]))
            lay[j][1] = max(hl, min(1.0 - hl, lay[j][1]))
    out = [tuple(s) for s in lay]
    if _valid(out) and sum(s[3] for s in out) > sum(s[3] for s in layout) + 1e-9:
        return out
    return layout


def _grow_pass(layout, rounds=6):
    layout = [tuple(s) for s in layout]
    n = len(layout)
    order = sorted(range(n), key=lambda k: layout[k][3])
    for _ in range(rounds):
        improved = False
        for i in order:
            new = _grow_relax(layout, i, iters=60, step=0.015)
            if new is not layout and sum(s[3] for s in new) > sum(s[3] for s in layout) + 1e-9:
                layout = new
                improved = True
        if not improved:
            break
    return layout


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    for lay in _big_plus_strip(n):
        candidates.append(lay)
    for lay in _slicing_layouts(n):
        candidates.append(lay)

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = [tuple(s) for s in cand]
        grown = _grow_pass(refined)
        if _valid(grown) and sum(s[3] for s in grown) > sum(s[3] for s in refined) + 1e-9:
            refined = grown
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    return best[1]
# EVOLVE-BLOCK-END
