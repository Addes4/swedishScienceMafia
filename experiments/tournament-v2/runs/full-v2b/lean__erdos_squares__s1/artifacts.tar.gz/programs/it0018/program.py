# EVOLVE-BLOCK-START
"""Structured exact packing (big square + L strips) plus greedy refinement."""
import math


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-9 and x + h <= 1 + 1e-9 and y - h >= -1e-9 and y + h <= 1 + 1e-9


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
    for gx in range(1, 14):
        for gy in range(1, 14):
            cands.append((gx / 14.0, gy / 14.0))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=60):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _corner_L(n):
    """Big square in bottom-left corner of size b; remaining n-1 squares packed
    into the right strip [b,1]x[0,1] minus top region and the top strip
    [0,b]x[b,1].  We tile as: right strip uses cr columns, tr rows; top strip
    uses ct columns (of width b) and tt rows. Total cells >= n-1 with a common
    cell size s.  Also symmetric single-strip-only and mixed variants."""
    results = []
    k = n - 1
    if k == 0:
        return [[(0.25, 0.25, 0.0, 0.5)]]
    # Enumerate big-square size b over a fine grid; for each, find best s.
    N = 400
    for bi in range(1, N):
        b = bi / float(N)
        aw = 1.0 - b  # width of right strip and height of top strip
        if aw <= 1e-9:
            continue
        # Option A: put all k in right strip: cols x rows grid.
        bestA = None
        for cols in range(1, k + 1):
            rows = (k + cols - 1) // cols
            s = min(aw / cols, 1.0 / rows)
            if s <= 0:
                continue
            if cols * rows >= k and (bestA is None or s > bestA[0]):
                bestA = (s, cols, rows)
        if bestA:
            s, cols, rows = bestA
            layout = [(b / 2.0, b / 2.0, 0.0, b)]
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = b + (c + 0.5) * s
                    cy = (r + 0.5) * (1.0 / rows) if False else (r + 0.5) * s
                    # Ensure fits in height 1: rows*s <= 1
                    layout.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k:
                    break
            if len(layout) == n and _valid(layout):
                results.append(layout)
        # Option B: split between right strip and top strip.
        for cr in range(0, k + 1):
            for tr in range(0, k + 1):
                if cr * tr > k:
                    continue
                for ct in range(0, k + 1):
                    for tt in range(0, k + 1):
                        cells_r = cr * tr
                        cells_t = ct * tt
                        if cells_r + cells_t < k:
                            continue
                        if cells_r + cells_t > k + max(cr, tr) + max(ct, tt) + 4:
                            continue
                        # constraints:
                        # right strip: cr*s <= aw ; (tr + tt)*s <= 1
                        # top strip:   ct*s <= b  ;  tt*s <= aw
                        lim = []
                        if cr > 0:
                            lim.append(aw / cr)
                        if ct > 0:
                            lim.append(b / ct)
                        if tr + tt > 0:
                            lim.append(1.0 / (tr + tt))
                        if tt > 0:
                            lim.append(aw / tt)
                        lim.append(1.0)
                        s = min(lim)
                        if s <= 1e-9:
                            continue
                        layout = [(b / 2.0, b / 2.0, 0.0, b)]
                        idx = 0
                        # right strip cells: cr columns x tr rows, at x >= b
                        for r in range(tr):
                            for c in range(cr):
                                if idx >= k:
                                    break
                                cx = b + (c + 0.5) * s
                                cy = (r + 0.5) * s + 0.0
                                layout.append((cx, cy, 0.0, s))
                                idx += 1
                            if idx >= k:
                                break
                        # top strip cells: ct columns x tt rows, y >= b
                        for r in range(tt):
                            for c in range(ct):
                                if idx >= k:
                                    break
                                cx = (c + 0.5) * s
                                cy = b + (r + 0.5) * s
                                layout.append((cx, cy, 0.0, s))
                                idx += 1
                            if idx >= k:
                                break
                        if len(layout) != n:
                            continue
                        if _valid(layout):
                            results.append(layout)
    return results


def _corner_L_compact(n):
    """Cheaper but wider search: big square of a few sizes + two-strip packing."""
    results = []
    k = n - 1
    if k <= 0:
        return []
    for bi in range(1, 200):
        b = bi / 200.0
        aw = 1.0 - b
        if aw <= 1e-9:
            continue
        for cols in range(1, k + 1):
            rows = (k + cols - 1) // cols
            s = min(aw / cols, 1.0 / rows)
            if s <= 0:
                continue
            layout = [(b / 2.0, b / 2.0, 0.0, b)]
            idx = 0
            ok = True
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = b + (c + 0.5) * s
                    cy = (r + 0.5) * s
                    if cy + s / 2.0 > 1.0 + 1e-9:
                        ok = False
                        break
                    layout.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k or not ok:
                    break
            if not ok or len(layout) != n:
                continue
            if _valid(layout):
                results.append(layout)
    return results


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    for lay in _corner_L_compact(n):
        candidates.append(lay)
    if n <= 12:
        for lay in _corner_L(n):
            candidates.append(lay)

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        tot = sum(s[3] for s in cand)
        if best is None or tot > best[0]:
            best = (tot, list(cand))

    # Refine the top candidates to save time.
    scored = []
    for cand in candidates:
        if len(cand) != n:
            continue
        scored.append((sum(s[3] for s in cand), cand))
    scored.sort(key=lambda t: -t[0])
    top = scored[:6]

    for _, cand in top:
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    return best[1]
# EVOLVE-BLOCK-END
