# EVOLVE-BLOCK-START
"""Greedy packing plus structured layouts and a randomized repacking local search."""
import math
import random


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-9 and x + h <= 1 + 1e-9 and y - h >= -1e-9 and y + h <= 1 + 1e-9


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others, extra_cands=()):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
        cands.append((min(1 - o[3] / 2.0, max(o[3] / 2.0, o[0])), o[1]))
        cands.append((o[0], min(1 - o[3] / 2.0, max(o[3] / 2.0, o[1]))))
    for gx in range(1, 21):
        for gy in range(1, 21):
            cands.append((gx / 21.0, gy / 21.0))
    for c in extra_cands:
        cands.append(c)
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=80):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _corner_plus_strip(n):
    """Big square in one corner; remaining squares fill right strip + top strip."""
    results = []
    if n < 2:
        return results
    k = n - 1
    orientations = [
        # (big corner, right strip x-range, top strip y-range)  generic via mirror
        (0, 1, 1),   # big bottom-left -> right strip full, top strip above b on left
        (1, 1, 1),
    ]
    for flip_x in (0, 1):
        for flip_y in (0, 1):
            for bstep in range(1, 400):
                b = bstep / 400.0
                aw = 1.0 - b
                if aw <= 1e-9:
                    continue
                for cols in range(1, k + 1):
                    for rows in range(1, k + 1):
                        if cols * rows < k:
                            continue
                        # cells in right strip: cols wide (width aw), rows tall (height 1)
                        sr = min(aw / cols, 1.0 / rows)
                        # cells in top strip: some left over region [0,b] x [b,1]
                        if sr <= 0:
                            continue
                        layout = []
                        bx, by = (b / 2.0, b / 2.0)
                        if flip_x:
                            bx = 1 - b / 2.0
                        if flip_y:
                            by = 1 - b / 2.0
                        layout.append((bx, by, 0.0, b))
                        idx = 0
                        # fill right strip with a grid of size sr
                        nx = int(math.floor(aw / sr + 1e-9)) if sr > 0 else 0
                        ny = int(math.floor(1.0 / sr + 1e-9)) if sr > 0 else 0
                        rx0 = b if not flip_x else 0.0
                        for r in range(ny):
                            for c in range(nx):
                                if idx >= k:
                                    break
                                cx = rx0 + (c + 0.5) * sr
                                cy = (r + 0.5) * sr
                                if flip_y:
                                    cy = 1 - cy
                                if flip_x:
                                    cx = 1 - cx + (1 - 2 * rx0) if False else cx
                                layout.append((cx, cy, 0.0, sr))
                                idx += 1
                            if idx >= k:
                                break
                        # fill top strip left region
                        tx = b if not flip_x else 0.0
                        if idx < k:
                            nx2 = int(math.floor(tx / sr + 1e-9)) if sr > 0 else 0
                            ny2 = int(math.floor(aw / sr + 1e-9)) if sr > 0 else 0
                            ty0 = b if not flip_y else 0.0
                            for r in range(ny2):
                                for c in range(nx2):
                                    if idx >= k:
                                        break
                                    cx = (c + 0.5) * sr
                                    cy = ty0 + (r + 0.5) * sr
                                    if flip_y:
                                        cy = 1 - cy
                                    layout.append((cx, cy, 0.0, sr))
                                    idx += 1
                                if idx >= k:
                                    break
                        if len(layout) != n:
                            continue
                        if _valid(layout):
                            results.append(layout)
    return results


def _try_uniform_strip(n, cols_right, rows_right, cols_top, rows_top, b):
    aw = 1.0 - b
    if aw <= 0:
        return None
    sr = aw / cols_right
    st = aw / cols_top if cols_top > 0 else 0
    s = min(sr, st) if st > 0 else sr
    if s <= 0:
        return None
    layout = [(b / 2.0, b / 2.0, 0.0, b)]
    idx = 0
    k = n - 1
    for r in range(rows_right):
        for c in range(cols_right):
            if idx >= k:
                break
            layout.append((b + (c + 0.5) * s, (r + 0.5) * (1.0 / rows_right), 0.0, s))
            idx += 1
        if idx >= k:
            break
    for r in range(rows_top):
        for c in range(cols_top):
            if idx >= k:
                break
            layout.append(((c + 0.5) * (b / cols_top) if cols_top else 0.0,
                           b + (r + 0.5) * (aw / rows_top), 0.0,
                           min(s, b / cols_top if cols_top else s)))
            idx += 1
        if idx >= k:
            break
    if len(layout) != n:
        return None
    if _valid(layout):
        return layout
    return None


def _randomized_repack(layout, n, iters, rng):
    best = [list(s) for s in layout]
    best_tot = sum(s[3] for s in best)
    cur = [list(s) for s in best]
    for _ in range(iters):
        # remove one or two random squares, reinsert greedily
        cnt = 1 if rng.random() < 0.7 else 2
        idxs = rng.sample(range(n), min(cnt, n))
        others = [cur[j] for j in range(n) if j not in idxs]
        new_sqs = []
        for _k in range(len(idxs)):
            sq = _largest_fit(others + new_sqs)
            new_sqs.append(list(sq))
        cand = others + new_sqs
        tot = sum(s[3] for s in cand)
        if _valid([tuple(s) for s in cand]) and tot > best_tot - 1e-12:
            if tot > best_tot + 1e-12:
                best = [list(s) for s in cand]
                best_tot = tot
            cur = [list(s) for s in cand]
        else:
            # occasionally accept sideways
            if rng.random() < 0.15:
                cur = [list(s) for s in cand]
    return [tuple(s) for s in best]


def solve(n):
    if n <= 0:
        return []

    rng = random.Random(12345 + n)

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    for lay in _corner_plus_strip(n):
        candidates.append(lay)
    for bstep in range(1, 200):
        b = bstep / 200.0
        for cols in range(1, n):
            for rows in range(1, n):
                if cols * rows < n - 1:
                    continue
                lay = _try_uniform_strip(n, cols, rows, 0, 0, b)
                if lay:
                    candidates.append(lay)

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    base = best[1] if best else _best_grid(n)[1]
    rep = _randomized_repack(base, n, iters=4000, rng=rng)
    refined = _refine(rep)
    if not _valid(refined):
        refined = rep
    tot = sum(s[3] for s in refined)
    if best is None or tot > best[0]:
        best = (tot, refined)

    return best[1]
# EVOLVE-BLOCK-END
