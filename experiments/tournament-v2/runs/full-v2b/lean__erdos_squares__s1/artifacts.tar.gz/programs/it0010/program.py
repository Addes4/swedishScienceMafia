# EVOLVE-BLOCK-START
"""Greedy packing + structured layouts + rotation-aware simulated annealing polish."""
import math
import random


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


# ---- SAT-based geometry (rotated squares) ----
def _corners(s):
    x, y, a, sz = s
    if sz <= 0:
        return [(x, y)] * 4
    ang = a * 2.0 * math.pi
    ca, sa = math.cos(ang), math.sin(ang)
    h = sz / 2.0
    base = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for bx, by in base:
        out.append((x + bx * ca - by * sa, y + bx * sa + by * ca))
    return out


def _axes(corners):
    ax = []
    for i in range(2):
        x1, y1 = corners[i]
        x2, y2 = corners[i + 1]
        ex, ey = x2 - x1, y2 - y1
        n = math.hypot(ex, ey)
        if n < 1e-12:
            ax.append((1.0, 0.0))
        else:
            ax.append((-ey / n, ex / n))
    return ax


def _project(corners, axis):
    dots = [c[0] * axis[0] + c[1] * axis[1] for c in corners]
    return min(dots), max(dots)


def _sat_overlap(a, b):
    if a[3] <= 0 or b[3] <= 0:
        return False
    ca = _corners(a)
    cb = _corners(b)
    for axis in _axes(ca) + _axes(cb):
        amin, amax = _project(ca, axis)
        bmin, bmax = _project(cb, axis)
        if amax <= bmin + 1e-12 or bmax <= amin + 1e-12:
            return False
    return True


def _inside_rot(s, tol=1e-7):
    x, y, a, sz = s
    if sz <= 0:
        return 0 <= x <= 1 and 0 <= y <= 1
    for cx, cy in _corners(s):
        if cx < -tol or cx > 1 + tol or cy < -tol or cy > 1 + tol:
            return False
    return True


def _valid_rot(layout, tol=1e-7):
    for s in layout:
        if s[3] < -tol:
            return False
        if not _inside_rot(s, tol):
            return False
    m = len(layout)
    for i in range(m):
        for j in range(i + 1, m):
            if _sat_overlap(layout[i], layout[j]):
                return False
    return True


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-9 and x + h <= 1 + 1e-9 and y - h >= -1e-9 and y + h <= 1 + 1e-9


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
    for gx in range(1, 14):
        for gy in range(1, 14):
            cands.append((gx / 14.0, gy / 14.0))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=60):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [tuple(layout[j]) for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _big_plus_strip(n):
    results = []
    if n < 1:
        return results
    k = n - 1
    for b in [i / 200.0 for i in range(1, 200)]:
        avail_w = 1.0 - b
        if avail_w <= 0:
            continue
        for cols in range(1, k + 1):
            rows = (k + cols - 1) // cols
            s = min(avail_w / cols, 1.0 / rows)
            if s <= 0:
                continue
            if cols * rows < k:
                continue
            layout = [(b / 2.0, b / 2.0, 0.0, b)]
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = b + (c + 0.5) * s
                    cy = (r + 0.5) * (1.0 / rows)
                    layout.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k:
                    break
            if len(layout) != n:
                continue
            if _valid(layout):
                results.append(layout)
    return results


def _sa_polish(layout, budget_iter=4000, seed=12345):
    """Rotation-aware simulated annealing on centers/sides/angles."""
    rng = random.Random(seed)
    n = len(layout)
    if n == 0:
        return layout
    cur = [list(s) for s in layout]
    # normalize to valid
    if not _valid_rot([tuple(s) for s in cur]):
        return layout
    cur_total = sum(s[3] for s in cur)

    best = [list(s) for s in cur]
    best_total = cur_total

    T0 = 0.12 * (cur_total / max(1, n)) if cur_total > 0 else 0.05
    T = T0
    cooling = (1e-3) ** (1.0 / max(1, budget_iter))

    for it in range(budget_iter):
        i = rng.randrange(n)
        s = cur[i]
        move = rng.random()
        cand = list(s)
        if move < 0.3:
            # jitter center
            d = (rng.random() - 0.5) * 0.06
            cand[0] = min(1.0, max(0.0, cand[0] + d))
            d = (rng.random() - 0.5) * 0.06
            cand[1] = min(1.0, max(0.0, cand[1] + d))
        elif move < 0.6:
            # grow/shrink side
            cand[3] = max(0.0, min(1.0, cand[3] + (rng.random() - 0.35) * 0.05))
        else:
            # rotate
            cand[2] = (cand[2] + (rng.random() - 0.5) * 0.25) % 1.0

        # Ensure inside
        if not _inside_rot(cand):
            T *= cooling
            continue

        ok = True
        for j in range(n):
            if j == i:
                continue
            if _sat_overlap(cand, cur[j]):
                ok = False
                break
        if not ok:
            # try to shrink back into validity
            shrunk = list(cand)
            for _ in range(6):
                shrunk[3] *= 0.75
                if not _inside_rot(shrunk):
                    continue
                good = True
                for j in range(n):
                    if j == i:
                        continue
                    if _sat_overlap(shrunk, cur[j]):
                        good = False
                        break
                if good:
                    cand = shrunk
                    ok = True
                    break
            if not ok:
                T *= cooling
                continue

        new_total = cur_total - cur[i][3] + cand[3]
        delta = new_total - cur_total
        if delta >= 0 or rng.random() < math.exp(delta / max(T, 1e-9)):
            cur[i] = cand
            cur_total = new_total
            if cur_total > best_total:
                best_total = cur_total
                best = [list(s) for s in cur]
        T *= cooling

    return [tuple(s) for s in best]


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    for lay in _big_plus_strip(n):
        candidates.append(lay)

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    if best is None:
        best = (0.0, _best_grid(n)[1])

    # Rotation-aware SA polish around the best layout.
    polished = _sa_polish(best[1], budget_iter=3500, seed=987654)
    if _valid_rot(polished):
        tot_p = sum(s[3] for s in polished)
        if tot_p > best[0] + 1e-9:
            best = (tot_p, polished)

    # final axis-aligned refine attempt on the polished (could still help)
    final = _refine(best[1])
    if _valid_rot(final):
        tf = sum(s[3] for s in final)
        if tf > best[0] + 1e-9:
            best = (tf, final)

    return list(best[1])
# EVOLVE-BLOCK-END
