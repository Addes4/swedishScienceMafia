# EVOLVE-BLOCK-START
"""Greedy packing plus structured slicing layouts and SAT-based local refinement."""
import math


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


# ---------- exact rotated-square geometry (SAT) ----------

def _corners(cx, cy, ang, sz):
    h = sz / 2.0
    th = ang * 2.0 * math.pi
    ca, sa = math.cos(th), math.sin(th)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _sat_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    if s1 <= 0 or s2 <= 0:
        return False
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)
    for poly in (p1, p2):
        for k in range(4):
            x1, y1 = poly[k]
            x2, y2 = poly[(k + 1) % 4]
            nx, ny = -(y2 - y1), (x2 - x1)
            # project both polygons
            min1 = min(px * nx + py * ny for px, py in p1)
            max1 = max(px * nx + py * ny for px, py in p1)
            min2 = min(px * nx + py * ny for px, py in p2)
            max2 = max(px * nx + py * ny for px, py in p2)
            if min1 > min2 + 1e-12 or min2 > min1 + 1e-12:
                # check actual separation: max overlap <= 0 means separated
                ov = min(max1, max2) - max(min1, min2)
                if ov <= 1e-12:
                    return False
    return True


def _inside_sat(cx, cy, ang, sz):
    if sz <= 0:
        return True
    for px, py in _corners(cx, cy, ang, sz):
        if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
            return False
    return True


def _overlap(a, b):
    return _sat_overlap(a[0], a[1], a[2], a[3], b[0], b[1], b[2], b[3])


def _inside(s):
    return _inside_sat(s[0], s[1], s[2], s[3])


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


# ---------- grow-in-place refinement ----------

def _max_grow(layout, i):
    """Maximum side for square i keeping its center and angle fixed."""
    cx, cy, ang, sz = layout[i]
    # boundary limit
    corners = _corners(cx, cy, ang, 1.0)  # unit-size corners
    scale_lim = 1e9
    for px, py in corners:
        dx = px - cx
        dy = py - cy
        # find max s so cx+dx*s in [0,1], cy+dy*s in [0,1]
        for coord, c, d in ((px, cx, dx), (py, cy, dy)):
            pass
    # boundary: solve linearly.  Use corner distances.
    lim = 1e9
    for px, py in corners:
        dx = px - cx
        dy = py - cy
        for (base, d) in ((cx, dx), (cy, dy)):
            if d > 1e-12:
                lim = min(lim, (1.0 - base) / d)
            elif d < -1e-12:
                lim = min(lim, (0.0 - base) / d)
    # neighbor limit: binary search on side
    lo = max(sz, 0.0)
    hi = max(lim, lo) + 1e-6
    # ensure hi infeasible or bounded
    def feasible(s):
        if s > lim + 1e-12:
            return False
        for j in range(len(layout)):
            if j == i:
                continue
            o = layout[j]
            if _sat_overlap(cx, cy, ang, s, o[0], o[1], o[2], o[3]):
                return False
        return True

    # find feasible upper via binary search
    if not feasible(lo):
        return sz
    a, b = lo, hi
    for _ in range(40):
        m = (a + b) / 2.0
        if feasible(m):
            a = m
        else:
            b = m
    return min(a, lim)


def _grow_refine(layout, rounds=6):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            ns = _max_grow(layout, i)
            if ns > layout[i][3] + 1e-9:
                layout[i][3] = ns
                improved = True
        if not improved:
            break
    if not _valid(layout):
        return None
    return [tuple(s) for s in layout]


# ---------- candidate generation ----------

def _largest_fit(others, gridres=14):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
        cands.append((o[0] + o[3] / 2.0, o[1] + o[3] / 2.0))
        cands.append((o[0] - o[3] / 2.0, o[1] - o[3] / 2.0))
        cands.append((o[0] + o[3] / 2.0, o[1] - o[3] / 2.0))
        cands.append((o[0] - o[3] / 2.0, o[1] + o[3] / 2.0))
    for gx in range(1, gridres):
        for gy in range(1, gridres):
            cands.append((gx / float(gridres), gy / float(gridres)))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=25):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


# -------- Slicing (guillotine) layouts --------

def _rect_grid_best_squares(rw, rh, k):
    best = None
    for cols in range(1, k + 1):
        rows = (k + cols - 1) // cols
        if cols * rows < k:
            continue
        s = min(rw / cols, rh / rows)
        tot = k * s
        if best is None or tot > best[0]:
            placements = []
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = (c + 0.5) * (rw / cols)
                    cy = (r + 0.5) * (rh / rows)
                    placements.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k:
                    break
            best = (tot, placements)
    return best


def _tile_rect(rw, rh, k, ox, oy):
    r = _rect_grid_best_squares(rw, rh, k)
    if r is None:
        return None
    tot, placements = r
    out = [(px + ox, py + oy, a, s) for (px, py, a, s) in placements]
    return tot, out


def _slicing_layouts(n, fs_steps=200):
    results = []
    fs = [i / float(fs_steps) for i in range(1, fs_steps)]

    for k1 in range(1, n):
        k2 = n - k1
        best_for = None
        for f in fs:
            r1 = _tile_rect(f, 1.0, k1, 0.0, 0.0)
            if r1 is None:
                continue
            r2 = _tile_rect(1.0 - f, 1.0, k2, f, 0.0)
            if r2 is None:
                continue
            tot = r1[0] + r2[0]
            if best_for is None or tot > best_for[0]:
                best_for = (tot, r1[1] + r2[1])
        if best_for is not None:
            results.append(best_for[1])

    for k1 in range(1, n):
        k2 = n - k1
        best_for = None
        for f in fs:
            r1 = _tile_rect(1.0, f, k1, 0.0, 0.0)
            if r1 is None:
                continue
            r2 = _tile_rect(1.0, 1.0 - f, k2, 0.0, f)
            if r2 is None:
                continue
            tot = r1[0] + r2[0]
            if best_for is None or tot > best_for[0]:
                best_for = (tot, r1[1] + r2[1])
        if best_for is not None:
            results.append(best_for[1])
    return results


def _big_plus_strip(n):
    results = []
    if n < 2:
        return results
    k = n - 1
    for bi in range(1, 200):
        b = bi / 200.0
        if b >= 1.0:
            break
        layout = [(b / 2.0, b / 2.0, 0.0, b)]
        others = list(layout)
        ok = True
        for _ in range(k):
            sq = _largest_fit(others)
            if sq[3] <= 0:
                ok = False
                break
            others.append(list(sq))
        if ok and len(others) == n and _valid(others):
            results.append([tuple(s) for s in others])
    return results


def _corner_two_strips(n):
    results = []
    if n < 2:
        return results
    k = n - 1
    bs = [i / 300.0 for i in range(1, 300)]
    for ka in range(0, k + 1):
        kb = k - ka
        if ka == 0 or kb == 0:
            continue
        best_for = None
        for b in bs:
            rw = 1.0 - b
            rh = 1.0
            tw = b
            th = 1.0 - b
            ra = _rect_grid_best_squares(rw, rh, ka)
            if ra is None:
                continue
            rb = _rect_grid_best_squares(tw, th, kb)
            if rb is None:
                continue
            tot = b + ra[0] + rb[0]
            if best_for is None or tot > best_for[0]:
                pls = [(b / 2.0, b / 2.0, 0.0, b)]
                for (px, py, a, s) in ra[1]:
                    pls.append((b + px, py, a, s))
                for (px, py, a, s) in rb[1]:
                    pls.append((px, b + py, a, s))
                best_for = (tot, pls)
        if best_for is not None:
            results.append(best_for[1])
    out = []
    for lay in results:
        out.append(lay)
        out.append([(1.0 - x, y, a, s) for (x, y, a, s) in lay])
        out.append([(x, 1.0 - y, a, s) for (x, y, a, s) in lay])
        out.append([(1.0 - x, 1.0 - y, a, s) for (x, y, a, s) in lay])
    return out


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    for lay in _big_plus_strip(n):
        candidates.append(lay)
    for lay in _slicing_layouts(n):
        candidates.append(lay)
    for lay in _corner_two_strips(n):
        candidates.append(lay)

    scored = []
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        scored.append((tot, refined))

    scored.sort(key=lambda t: -t[0])

    best = None
    # Apply SAT grow-refine to the best few candidates.
    for tot, refined in scored[:6]:
        grown = _grow_refine(refined)
        if grown is None:
            grown = refined
        gtot = sum(s[3] for s in grown)
        if best is None or gtot > best[0]:
            best = (gtot, grown)

    if best is None:
        # fallback
        fallback = _greedy_largest(n)
        return _refine(fallback)

    return best[1]
# EVOLVE-BLOCK-END
