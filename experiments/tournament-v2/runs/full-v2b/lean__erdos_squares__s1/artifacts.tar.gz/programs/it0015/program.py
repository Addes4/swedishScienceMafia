# EVOLVE-BLOCK-START
"""Greedy packing plus local refinement with structured 'big square + strip' layouts."""
import math
import random


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-9 and x + h <= 1 + 1e-9 and y - h >= -1e-9 and y + h <= 1 + 1e-9


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _candidate_points(others):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
    for gx in range(1, 14):
        for gy in range(1, 14):
            cands.append((gx / 14.0, gy / 14.0))
    return cands


def _fit_at(cx, cy, others):
    lim = min(cx, 1 - cx, cy, 1 - cy)
    if lim <= 0:
        return 0.0
    s = lim * 2.0
    for o in others:
        if o[3] <= 0:
            continue
        dx = abs(cx - o[0])
        dy = abs(cy - o[1])
        ho = o[3] / 2.0
        mx = dx - ho
        my = dy - ho
        if mx < 0 and my < 0:
            return 0.0
        allowed = max(mx, my)
        if allowed < s / 2.0:
            s = 2.0 * allowed
            if s <= 0:
                return 0.0
    return s


def _largest_fit(others):
    best_s = -1.0
    best = None
    for cx, cy in _candidate_points(others):
        s = _fit_at(cx, cy, others)
        if s > 0 and s > best_s:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                best_s = s
                best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _largest_fit_random(others, rng):
    """Pick among near-best fits randomly to diversify greedy construction."""
    scored = []
    for cx, cy in _candidate_points(others):
        s = _fit_at(cx, cy, others)
        if s > 1e-9 and _inside((cx, cy, 0.0, s)):
            scored.append((s, cx, cy))
    if not scored:
        return (0.5, 0.5, 0.0, 0.0)
    scored.sort(reverse=True)
    top = scored[:max(1, min(6, len(scored)))]
    s, cx, cy = rng.choice(top)
    return (cx, cy, 0.0, s)


def _refine(layout, rounds=60):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _greedy_random(n, rng):
    layout = []
    for _ in range(n):
        sq = _largest_fit_random(layout, rng)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _big_plus_strip(n):
    """One large square in a corner, remaining n-1 squares in a grid strip."""
    results = []
    if n < 1:
        return results
    k = n - 1
    for b in [i / 200.0 for i in range(1, 200)]:
        avail_w = 1.0 - b
        if avail_w <= 0:
            continue
        for cols in range(1, k + 1):
            rows = (k + cols - 1) // cols
            s = min(avail_w / cols, 1.0 / rows)
            if s <= 0:
                continue
            if cols * rows < k:
                continue
            layout = [(b / 2.0, b / 2.0, 0.0, b)]
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = b + (c + 0.5) * s
                    cy = (r + 0.5) * (1.0 / rows)
                    layout.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k:
                    break
            if len(layout) != n:
                continue
            if _valid(layout):
                results.append(layout)
    return results


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    for lay in _big_plus_strip(n):
        candidates.append(lay)

    rng = random.Random(12345 + n)
    restarts = 40 if n <= 40 else 15
    for _ in range(restarts):
        candidates.append(_greedy_random(n, rng))

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    return best[1]
# EVOLVE-BLOCK-END
