# EVOLVE-BLOCK-START
"""Guillotine-partition DP plus greedy packing and local refinement."""
import math
from functools import lru_cache


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-9 and x + h <= 1 + 1e-9 and y - h >= -1e-9 and y + h <= 1 + 1e-9


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
    for gx in range(1, 20):
        for gy in range(1, 20):
            cands.append((gx / 20.0, gy / 20.0))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=60):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


# -------- Guillotine partition DP --------
# tile a w x h rectangle with exactly k equal axis-aligned squares in a grid.

def _rect_grid_best_squares(rw, rh, k):
    best = None
    for cols in range(1, k + 1):
        rows = (k + cols - 1) // cols
        if cols * rows < k:
            continue
        s = min(rw / cols, rh / rows)
        if s <= 0:
            continue
        tot = k * s
        if best is None or tot > best[0]:
            placements = []
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = (c + 0.5) * (rw / cols)
                    cy = (r + 0.5) * (rh / rows)
                    placements.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k:
                    break
            best = (tot, placements)
    return best


# DP cache: for rectangle (w,h) with k squares, best (total, placements relative to origin)
_dp_cache = {}


def _dp_rect(rw, rh, k):
    """Best total side length placing exactly k squares in rw x rh, guillotine splits."""
    key = (round(rw, 6), round(rh, 6), k)
    if key in _dp_cache:
        return _dp_cache[key]
    if k == 1:
        s = min(rw, rh)
        res = (s, [(rw / 2.0, rh / 2.0, 0.0, s)]) if s > 0 else (0.0, [(rw / 2.0, rh / 2.0, 0.0, 0.0)])
        _dp_cache[key] = res
        return res
    best = _rect_grid_best_squares(rw, rh, k)
    # try vertical and horizontal splits
    for k1 in range(1, k):
        k2 = k - k1
        # vertical split at fraction f: width f*rw ; other (1-f)*rw
        def vert_total(f):
            a = _dp_rect(f * rw, rh, k1)
            b = _dp_rect((1 - f) * rw, rh, k2)
            return a[0] + b[0], a, b
        # ternary search on f in (eps,1-eps)
        lo, hi = 1e-4, 1 - 1e-4
        for _ in range(60):
            m1 = lo + (hi - lo) / 3.0
            m2 = hi - (hi - lo) / 3.0
            t1 = vert_total(m1)[0]
            t2 = vert_total(m2)[0]
            if t1 < t2:
                lo = m1
            else:
                hi = m2
        f = (lo + hi) / 2.0
        tot, a, b = vert_total(f)
        if tot > best[0]:
            pls = [(x, y, aa, ss) for (x, y, aa, ss) in a[1]]
            pls += [(x + f * rw, y, aa, ss) for (x, y, aa, ss) in b[1]]
            best = (tot, pls)
        # horizontal
        def horiz_total(f):
            a = _dp_rect(rw, f * rh, k1)
            b = _dp_rect(rw, (1 - f) * rh, k2)
            return a[0] + b[0], a, b
        lo, hi = 1e-4, 1 - 1e-4
        for _ in range(60):
            m1 = lo + (hi - lo) / 3.0
            m2 = hi - (hi - lo) / 3.0
            t1 = horiz_total(m1)[0]
            t2 = horiz_total(m2)[0]
            if t1 < t2:
                lo = m1
            else:
                hi = m2
        f = (lo + hi) / 2.0
        tot, a, b = horiz_total(f)
        if tot > best[0]:
            pls = [(x, y, aa, ss) for (x, y, aa, ss) in a[1]]
            pls += [(x, y + f * rh, aa, ss) for (x, y, aa, ss) in b[1]]
            best = (tot, pls)
    _dp_cache[key] = best
    return best


def _dp_layout(n):
    _dp_cache.clear()
    tot, pls = _dp_rect(1.0, 1.0, n)
    return [(x, y, a, s) for (x, y, a, s) in pls]


def _big_plus_strip(n):
    results = []
    if n < 1:
        return results
    k = n - 1
    for b in [i / 200.0 for i in range(1, 200)]:
        avail_w = 1.0 - b
        if avail_w <= 0:
            continue
        for cols in range(1, k + 1):
            rows = (k + cols - 1) // cols
            s = min(avail_w / cols, 1.0 / rows)
            if s <= 0:
                continue
            if cols * rows < k:
                continue
            layout = [(b / 2.0, b / 2.0, 0.0, b)]
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = b + (c + 0.5) * s
                    cy = (r + 0.5) * (1.0 / rows)
                    layout.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k:
                    break
            if len(layout) != n:
                continue
            if _valid(layout):
                results.append(layout)
    return results


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    try:
        candidates.append(_dp_layout(n))
    except Exception:
        pass
    for lay in _big_plus_strip(n):
        candidates.append(lay)

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    return best[1]
# EVOLVE-BLOCK-END
