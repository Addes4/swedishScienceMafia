# EVOLVE-BLOCK-START
"""Structured packing: grids, corner big-square + strip tiling, greedy largest-fit,
plus a fast local refinement that repeatedly reinserts each square as a largest fit."""
import math


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-9 and x + h <= 1 + 1e-9 and y - h >= -1e-9 and y + h <= 1 + 1e-9


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
        cands.append((o[0] + o[3] / 2.0, o[1] + o[3] / 2.0))
        cands.append((o[0] - o[3] / 2.0, o[1] - o[3] / 2.0))
        cands.append((o[0] + o[3] / 2.0, o[1] - o[3] / 2.0))
        cands.append((o[0] - o[3] / 2.0, o[1] + o[3] / 2.0))
    for gx in range(1, 20):
        for gy in range(1, 20):
            cands.append((gx / 20.0, gy / 20.0))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=40):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _corner_strip(n):
    """Big square in a corner plus a grid filling the remaining L-region."""
    results = []
    if n < 1:
        return results
    k = n - 1
    # corner orientation: 0 = bottom-left, 1 = bottom-right, 2 = top-left, 3 = top-right
    for b in [i / 150.0 for i in range(1, 150)]:
        avail = 1.0 - b
        if avail <= 0:
            continue
        for cols in range(1, k + 1):
            rows = (k + cols - 1) // cols
            s = min(avail / cols, 1.0 / rows)
            if s <= 0:
                continue
            if cols * rows < k:
                continue
            layout = [(b / 2.0, b / 2.0, 0.0, b)]
            idx = 0
            ok = True
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = b + (c + 0.5) * s
                    cy = (r + 0.5) * (1.0 / rows)
                    if cx + s / 2.0 > 1 + 1e-9:
                        ok = False
                        break
                    layout.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k or not ok:
                    break
            if not ok or len(layout) != n:
                continue
            if _valid(layout):
                results.append(layout)
        for cols in range(1, k + 1):
            rows = (k + cols - 1) // cols
            s = min(1.0 / cols, avail / rows)
            if s <= 0:
                continue
            layout = [(b / 2.0, b / 2.0, 0.0, b)]
            idx = 0
            ok = True
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = (c + 0.5) * (1.0 / cols)
                    cy = b + (r + 0.5) * s
                    if cy + s / 2.0 > 1 + 1e-9 or cx + 0.5 / cols > 1 + 1e-9:
                        ok = False
                        break
                    layout.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k or not ok:
                    break
            if not ok or len(layout) != n:
                continue
            if _valid(layout):
                results.append(layout)
    return results


def _two_rect_strip(n):
    """Big square of size b, remaining squares split between right strip and top strip."""
    results = []
    if n < 2:
        return results
    k = n - 1
    for b in [i / 100.0 for i in range(1, 100)]:
        avail = 1.0 - b
        if avail <= 0:
            continue
        for k1 in range(0, k + 1):
            k2 = k - k1
            for c1 in range(1, k1 + 1):
                r1 = (k1 + c1 - 1) // c1
                s1 = min(avail / c1, 1.0 / r1) if (c1 > 0 and r1 > 0) else 0
                if k1 > 0 and (c1 * r1 < k1 or s1 <= 0):
                    continue
                if k2 > 0:
                    for c2 in range(1, k2 + 1):
                        r2 = (k2 + c2 - 1) // c2
                        s2 = min(1.0 / c2, avail / r2) if (c2 > 0 and r2 > 0) else 0
                        if c2 * r2 < k2 or s2 <= 0:
                            continue
                        layout = [(b / 2.0, b / 2.0, 0.0, b)]
                        idx = 0
                        ok = True
                        for r in range(r1):
                            for c in range(c1):
                                if idx >= k1:
                                    break
                                cx = b + (c + 0.5) * s1
                                cy = (r + 0.5) * (1.0 / r1)
                                if cx + s1 / 2.0 > 1 + 1e-9:
                                    ok = False
                                    break
                                layout.append((cx, cy, 0.0, s1))
                                idx += 1
                            if not ok:
                                break
                        idx2 = 0
                        for r in range(r2):
                            for c in range(c2):
                                if idx2 >= k2:
                                    break
                                cx = (c + 0.5) * (1.0 / c2)
                                cy = b + (r + 0.5) * s2
                                if cy + s2 / 2.0 > 1 + 1e-9:
                                    ok = False
                                    break
                                layout.append((cx, cy, 0.0, s2))
                                idx2 += 1
                            if not ok:
                                break
                        if ok and len(layout) == n and _valid(layout):
                            results.append(layout)
                else:
                    layout = [(b / 2.0, b / 2.0, 0.0, b)]
                    idx = 0
                    ok = True
                    for r in range(r1):
                        for c in range(c1):
                            if idx >= k1:
                                break
                            cx = b + (c + 0.5) * s1
                            cy = (r + 0.5) * (1.0 / r1)
                            if cx + s1 / 2.0 > 1 + 1e-9:
                                ok = False
                                break
                            layout.append((cx, cy, 0.0, s1))
                            idx += 1
                        if not ok:
                            break
                    if ok and len(layout) == n and _valid(layout):
                        results.append(layout)
    return results


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    for lay in _corner_strip(n):
        candidates.append(lay)
    for lay in _two_rect_strip(n):
        candidates.append(lay)

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    if best is None:
        best = (0.0, _best_grid(n)[1])
    return best[1]
# EVOLVE-BLOCK-END
