# EVOLVE-BLOCK-START
"""Greedy packing plus structured slicing layouts and local refinement."""
import math


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _corners(x, y, a, sz):
    """Return the 4 corner points of a rotated square."""
    h = sz / 2.0
    ang = a * 2.0 * math.pi
    ca = math.cos(ang)
    sa = math.sin(ang)
    pts = []
    for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        dx = sx * h
        dy = sy * h
        pts.append((x + dx * ca - dy * sa, y + dx * sa + dy * ca))
    return pts


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    if aa == 0.0 and ba == 0.0:
        dx = abs(ax - bx)
        dy = abs(ay - by)
        ha = asz / 2.0
        hb = bsz / 2.0
        return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12
    # SAT for convex polygons
    pa = _corners(ax, ay, aa, asz)
    pb = _corners(bx, by, ba, bsz)
    for poly in (pa, pb):
        for k in range(4):
            x1, y1 = poly[k]
            x2, y2 = poly[(k + 1) % 4]
            nx = -(y2 - y1)
            ny = (x2 - x1)
            p0 = pa[0]
            d0 = nx * (p0[0] - x1) + ny * (p0[1] - y1)
            mina = maxa = d0
            for p in pa[1:]:
                d = nx * (p[0] - x1) + ny * (p[1] - y1)
                if d < mina:
                    mina = d
                if d > maxa:
                    maxa = d
            q0 = pb[0]
            e0 = nx * (q0[0] - x1) + ny * (q0[1] - y1)
            minb = maxb = e0
            for p in pb[1:]:
                d = nx * (p[0] - x1) + ny * (p[1] - y1)
                if d < minb:
                    minb = d
                if d > maxb:
                    maxb = d
            if maxa < minb + 1e-12 or maxb < mina + 1e-12:
                return False
    return True


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    ang = abs(a * 2.0 * math.pi)
    ca = abs(math.cos(ang))
    sa = abs(math.sin(ang))
    ext_x = h * (ca + sa)
    ext_y = h * (ca + sa)
    return (x - ext_x >= -1e-9 and x + ext_x <= 1 + 1e-9 and
            y - ext_y >= -1e-9 and y + ext_y <= 1 + 1e-9)


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others, gridres=14):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
        cands.append((o[0] + o[3] / 2.0, o[1] + o[3] / 2.0))
        cands.append((o[0] - o[3] / 2.0, o[1] - o[3] / 2.0))
        cands.append((o[0] + o[3] / 2.0, o[1] - o[3] / 2.0))
        cands.append((o[0] - o[3] / 2.0, o[1] + o[3] / 2.0))
    for gx in range(1, gridres):
        for gy in range(1, gridres):
            cands.append((gx / float(gridres), gy / float(gridres)))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=25):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _grow_free(layout, iters=60):
    """Continuous grow-and-push local optimizer allowing rotations."""
    lay = [list(s) for s in layout]
    n = len(lay)
    cur = sum(s[3] for s in lay)

    def total():
        return sum(s[3] for s in lay)

    def ok(i):
        if lay[i][3] < -1e-9:
            return False
        if not _inside(tuple(lay[i])):
            return False
        for j in range(n):
            if j != i and _overlap(tuple(lay[i]), tuple(lay[j])):
                return False
        return True

    # precompute which pairs need checking (all)
    for _ in range(iters):
        improved = False
        order = list(range(n))
        order.sort(key=lambda i: -lay[i][3])
        for i in order:
            best_gain = 0.0
            best_state = None
            # try growing this square in place
            base = lay[i][:]
            for da in (0.0, 0.02, -0.02, 0.05, -0.05):
                a2 = base[2] + da
                for ds in (0.01, 0.03, 0.06, 0.1):
                    t = [base[0], base[1], a2, base[3] + ds]
                    if t[3] > 1.0 + 1e-9:
                        continue
                    if _inside(tuple(t)) and not any(
                            j != i and _overlap(tuple(t), tuple(lay[j])) for j in range(n)):
                        if ds > best_gain:
                            best_gain = ds
                            best_state = t
            if best_state is not None:
                lay[i] = best_state
                improved = True
        if not improved:
            break
    return [tuple(s) for s in lay]


# -------- Slicing (guillotine) layouts --------

def _rect_grid_best_squares(rw, rh, k):
    best = None
    for cols in range(1, k + 1):
        rows = (k + cols - 1) // cols
        if cols * rows < k:
            continue
        s = min(rw / cols, rh / rows)
        tot = k * s
        if best is None or tot > best[0]:
            placements = []
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = (c + 0.5) * (rw / cols)
                    cy = (r + 0.5) * (rh / rows)
                    placements.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k:
                    break
            best = (tot, placements)
    return best


def _tile_rect(rw, rh, k, ox, oy):
    r = _rect_grid_best_squares(rw, rh, k)
    if r is None:
        return None
    tot, placements = r
    out = [(px + ox, py + oy, a, s) for (px, py, a, s) in placements]
    return tot, out


def _slicing_layouts(n, fs_steps=200):
    results = []
    fs = [i / float(fs_steps) for i in range(1, fs_steps)]

    # Vertical splits
    for k1 in range(1, n):
        k2 = n - k1
        best_for = None
        for f in fs:
            r1 = _tile_rect(f, 1.0, k1, 0.0, 0.0)
            if r1 is None:
                continue
            r2 = _tile_rect(1.0 - f, 1.0, k2, f, 0.0)
            if r2 is None:
                continue
            tot = r1[0] + r2[0]
            if best_for is None or tot > best_for[0]:
                best_for = (tot, r1[1] + r2[1])
        if best_for is not None:
            results.append(best_for[1])

    # Horizontal splits
    for k1 in range(1, n):
        k2 = n - k1
        best_for = None
        for f in fs:
            r1 = _tile_rect(1.0, f, k1, 0.0, 0.0)
            if r1 is None:
                continue
            r2 = _tile_rect(1.0, 1.0 - f, k2, 0.0, f)
            if r2 is None:
                continue
            tot = r1[0] + r2[0]
            if best_for is None or tot > best_for[0]:
                best_for = (tot, r1[1] + r2[1])
        if best_for is not None:
            results.append(best_for[1])

    # Three-rectangle
    for ka in range(1, n - 1):
        for kb in range(1, n - ka):
            kc = n - ka - kb
            if kc < 1:
                continue
            best_for = None
            for f in fs[::4]:
                for g in fs[::4]:
                    r1 = _tile_rect(f, g, ka, 0.0, 0.0)
                    r2 = _tile_rect(f, 1.0 - g, kb, 0.0, g)
                    r3 = _tile_rect(1.0 - f, 1.0, kc, f, 0.0)
                    if None in (r1, r2, r3):
                        continue
                    tot = r1[0] + r2[0] + r3[0]
                    if best_for is None or tot > best_for[0]:
                        best_for = (tot, r1[1] + r2[1] + r3[1])
            if best_for is not None:
                results.append(best_for[1])
    return results


def _big_plus_strip(n):
    """One big square in a corner, remaining n-1 packed by greedy largest-fit."""
    results = []
    if n < 2:
        return results
    k = n - 1
    for bi in range(1, 400):
        b = bi / 400.0
        if b >= 1.0:
            break
        layout = [(b / 2.0, b / 2.0, 0.0, b)]
        others = list(layout)
        ok = True
        for _ in range(k):
            sq = _largest_fit(others)
            if sq[3] <= 0:
                ok = False
                break
            others.append(list(sq))
        if ok and len(others) == n and _valid(others):
            results.append([tuple(s) for s in others])
    return results


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    for lay in _big_plus_strip(n):
        candidates.append(lay)
    for lay in _slicing_layouts(n):
        candidates.append(lay)

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    # Apply continuous grow-and-push to the best few candidates
    ranked = []
    for cand in candidates:
        if len(cand) != n:
            continue
        ranked.append((sum(s[3] for s in cand), cand))
    ranked.sort(key=lambda t: -t[0])
    for _, cand in ranked[:6]:
        grown = _grow_free(cand)
        if not _valid(grown):
            continue
        grown2 = _refine(grown)
        if _valid(grown2) and sum(s[3] for s in grown2) >= sum(s[3] for s in grown):
            grown = grown2
        tot = sum(s[3] for s in grown)
        if best is None or tot > best[0]:
            best = (tot, grown)

    return best[1]
# EVOLVE-BLOCK-END

