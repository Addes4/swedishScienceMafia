# EVOLVE-BLOCK-START
"""Recursive guillotine partition packing for squares in a unit square.

Idea: partition [0,1]^2 into rectangles by recursive straight cuts, then within
each rectangle place either one square (side = min(w,h)) or further subdivide it.
By exploring many partition trees and counting the total side length achievable,
we find layouts that beat a fixed uniform grid for arbitrary n, especially when
n is not a perfect square.
"""
import math


def _rect_squares(w, h, count):
    """Place `count` axis-aligned squares in a w x h rectangle, returning list of
    (local_x, local_y, side) with corners measured from the rectangle's lower-left.
    Uses a simple heuristic: split the rectangle into a grid that best matches
    count, choosing split directions to keep squares as large as possible."""
    if count <= 0:
        return []
    if count == 1:
        s = min(w, h)
        return [(0.0, 0.0, s)]

    # Try all ways to factor count into (a, b) grid and pick best total side.
    best = None
    for a in range(1, count + 1):
        if count % a != 0:
            continue
        b = count // a
        # Option: a columns by b rows
        sw = w / a
        sh = h / b
        s = min(sw, sh)
        total = s * count
        if best is None or total > best[0]:
            best = (total, a, b, s, sw, sh)

    # Also try a guillotine split: one square along an edge, rest in remainder.
    for frac in (0.5, 0.3333, 0.6666):
        for horiz in (True, False):
            if horiz:
                cut = h * frac
                s = min(w, cut)
                if s <= 0:
                    continue
                rem_h = h - s
                if rem_h <= 0:
                    continue
                rest = _rect_squares(w, rem_h, count - 1)
                tot = s + sum(r[2] for r in rest)
                cand = ('split', s, rest, True, rem_h)
            else:
                cut = w * frac
                s = min(cut, h)
                if s <= 0:
                    continue
                rem_w = w - s
                if rem_w <= 0:
                    continue
                rest = _rect_squares(rem_w, h, count - 1)
                tot = s + sum(r[2] for r in rest)
                cand = ('split', s, rest, False, rem_w)

            if best is None or tot > best[0]:
                best = (tot, cand)

    _, a, b, s, sw, sh = best if isinstance(best[1], int) else (best[0], 1, count, 0, w, h)

    # Grid placement as fallback / chosen
    res = []
    for r in range(b):
        for c in range(a):
            res.append((c * sw, r * sh, s))
    return res


def _pack(w, h, count):
    """Return list of (x, y, side) placing `count` squares in w x h rectangle.
    Returns local coords in the rectangle."""
    if count <= 0:
        return []
    if count == 1:
        s = min(w, h)
        return [(0.0, 0.0, s)]

    best = None
    # Grid factor options
    for a in range(1, count + 1):
        if count % a != 0:
            continue
        b = count // a
        sw = w / a
        sh = h / b
        s = min(sw, sh)
        total = s * count
        if best is None or total > best[0]:
            best = (total, 'grid', a, b, s, sw, sh)

    # Guillotine: place one square, recurse on the remaining strip
    for frac in (0.25, 0.3333, 0.5, 0.6666, 0.75):
        for horiz in (True, False):
            if horiz:
                s = min(w, h * frac)
                if s <= 1e-12:
                    continue
                rem_h = h - s
                if rem_h <= 1e-12:
                    continue
                rest = _pack(w, rem_h, count - 1)
                tot = s + sum(r[2] for r in rest)
                cand = ('split', s, rest, True)
            else:
                s = min(w * frac, h)
                if s <= 1e-12:
                    continue
                rem_w = w - s
                if rem_w <= 1e-12:
                    continue
                rest = _pack(rem_w, h, count - 1)
                tot = s + sum(r[2] for r in rest)
                cand = ('split', s, rest, False)

            if best is None or tot > best[0]:
                best = (tot, cand)

    if best is None:
        return [(0.0, 0.0, min(w, h))]

    if best[1] == 'grid':
        _, a, b, s, sw, sh = best[1], best[2], best[3], best[4], best[5], best[6]
        res = []
        for r in range(b):
            for c in range(a):
                res.append((c * sw, r * sh, s))
        return res
    else:
        _, s, rest, horiz = best[1], best[2], best[3], best[4]
        res = [(0.0, 0.0, s)]
        if horiz:
            offset_y = s
            for (x, y, ss) in rest:
                res.append((x, y + offset_y, ss))
        else:
            offset_x = s
            for (x, y, ss) in rest:
                res.append((x + offset_x, y, ss))
        return res


def solve(n):
    if n <= 0:
        return []

    best = None
    for t in range(0, 2):
        # try packing all n into whole unit square
        layout = _pack(1.0, 1.0, n)
        total = sum(s[2] for s in layout)
        if best is None or total > best[0]:
            best = (total, layout)

    layout = best[1]
    result = []
    for (x, y, s) in layout:
        cx = x + s / 2.0
        cy = y + s / 2.0
        # clamp
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        result.append((cx, cy, 0.0, s))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
# EVOLVE-BLOCK-END
