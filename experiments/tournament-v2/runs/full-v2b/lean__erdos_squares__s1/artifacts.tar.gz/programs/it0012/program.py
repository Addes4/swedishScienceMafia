# EVOLVE-BLOCK-START
"""Greedy packing plus local refinement with structured 'big square + strip' layouts."""
import math


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-9 and x + h <= 1 + 1e-9 and y - h >= -1e-9 and y + h <= 1 + 1e-9


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others):
    cands = [(0.5, 0.5)]
    for o in others:
        ox, oy, oa, osz = o
        ho = osz / 2.0
        cands.append((ox, oy))
        cands.append((ox + ho, oy))
        cands.append((ox - ho, oy))
        cands.append((ox, oy + ho))
        cands.append((ox, oy - ho))
        cands.append((ox + ho, oy + ho))
        cands.append((ox + ho, oy - ho))
        cands.append((ox - ho, oy + ho))
        cands.append((ox - ho, oy - ho))
    for gx in range(1, 20):
        for gy in range(1, 20):
            cands.append((gx / 20.0, gy / 20.0))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine(layout, rounds=80):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        # sort indices by descending size to try growing big ones first
        order = sorted(range(n), key=lambda i: -layout[i][3])
        for i in order:
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _big_plus_strip(n):
    """Big square in a corner plus the remaining squares tiling the L-shaped region
    with a single cell size, split between the right strip and top strip."""
    results = []
    if n < 1:
        return results
    k = n - 1  # squares outside the big square
    for corner in range(4):
        for bi in range(1, 250):
            b = bi / 250.0
            W = 1.0 - b  # strip width / height
            if W <= 1e-9:
                continue
            for cols in range(1, k + 1):
                rows = (k + cols - 1) // cols
                # single cell size fits in the wider strip (width W, height 1) and
                # top strip (height W, width b or W depending on corner)
                s = min(W / cols, 1.0 / rows)
                if s <= 1e-9:
                    continue
                if cols * rows < k:
                    continue
                # build layout in a canonical orientation then transform by corner
                if corner == 0:
                    big = (b / 2.0, b / 2.0, 0.0, b)
                    right_x0, right_y0 = b, 0.0
                    right_w, right_h = W, 1.0
                elif corner == 1:
                    big = (1 - b / 2.0, b / 2.0, 0.0, b)
                    right_x0, right_y0 = 0.0, 0.0
                    right_w, right_h = W, 1.0
                elif corner == 2:
                    big = (b / 2.0, 1 - b / 2.0, 0.0, b)
                    right_x0, right_y0 = b, 0.0
                    right_w, right_h = W, 1.0
                else:
                    big = (1 - b / 2.0, 1 - b / 2.0, 0.0, b)
                    right_x0, right_y0 = 0.0, 0.0
                    right_w, right_h = W, 1.0
                # place k squares in a grid within the right strip (cols x rows)
                layout = [big]
                idx = 0
                for r in range(rows):
                    for c in range(cols):
                        if idx >= k:
                            break
                        cx = right_x0 + (c + 0.5) * s
                        cy = right_y0 + (r + 0.5) * s
                        layout.append((cx, cy, 0.0, s))
                        idx += 1
                    if idx >= k:
                        break
                if len(layout) != n:
                    continue
                if _valid(layout):
                    results.append(layout)
    return results


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    for lay in _big_plus_strip(n):
        candidates.append(lay)

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    return best[1]
# EVOLVE-BLOCK-END
