# EVOLVE-BLOCK-START
"""Free-rectangle greedy packing with randomized restarts plus axis-aligned refinement."""
import math
import random


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _inside(s):
    x, y, a, sz = s
    h = sz / 2.0
    return x - h >= -1e-9 and x + h <= 1 + 1e-9 and y - h >= -1e-9 and y + h <= 1 + 1e-9


def _overlap(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _largest_fit(others):
    """Largest axis-aligned square avoiding the others (approx via candidate centers)."""
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
    for gx in range(1, 12):
        for gy in range(1, 12):
            cands.append((gx / 12.0, gy / 12.0))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        ok = True
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                ok = False
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    ok = False
                    break
        if ok and s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        layout.append(list(_largest_fit(layout)))
    return [tuple(s) for s in layout]


def _random_greedy(n, rng, jitter=0.0):
    """Place n squares greedily with randomized center jitter; then fill smallest first."""
    layout = []
    for _ in range(n):
        sq = _largest_fit(layout)
        if jitter > 0 and sq[3] > 0:
            cx = min(1 - sq[3] / 2.0, max(sq[3] / 2.0, sq[0] + rng.uniform(-jitter, jitter)))
            cy = min(1 - sq[3] / 2.0, max(sq[3] / 2.0, sq[1] + rng.uniform(-jitter, jitter)))
            cand = (cx, cy, 0.0, sq[3])
            if _valid(layout + [cand]):
                sq = cand
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _refine(layout, rounds=80):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def solve(n):
    if n <= 0:
        return []

    import time
    t0 = time.time()
    deadline = t0 + 55.0

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    rng = random.Random(12345 + n)
    jitters = [0.0, 0.02, 0.05, 0.1]
    # Randomized multi-start search until time runs out.
    while time.time() < deadline:
        j = jitters[rng.randrange(len(jitters))]
        cand = _random_greedy(n, rng, jitter=j)
        if not _valid(cand):
            continue
        refined = _refine(cand)
        if not _valid(refined):
            continue
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    return best[1]
# EVOLVE-BLOCK-END
