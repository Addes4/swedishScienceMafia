# EVOLVE-BLOCK-START
"""Greedy packing plus structured slicing layouts and local refinement (SAT-based)."""
import math


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


# ---------------- geometry: exact rotated-square overlap (SAT) ----------------

def _corners(x, y, a, s):
    """Corners of a rotated square centered (x,y), angle a (fraction of turn)."""
    ang = a * 2.0 * math.pi
    ca, sa = math.cos(ang), math.sin(ang)
    h = s / 2.0
    pts = []
    for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        px, py = sx * h, sy * h
        pts.append((x + px * ca - py * sa, y + px * sa + py * ca))
    return pts


def _sat_overlap(A, B):
    """Exact check: do two rotated squares share interior area?"""
    if A[3] <= 0 or B[3] <= 0:
        return False
    pa = _corners(*A)
    pb = _corners(*B)
    # axes: edge normals of both squares
    for poly in (pa, pb):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            ax, ay = -(y2 - y1), (x2 - x1)
            # project both polygons
            def proj(pts):
                lo = hi = pts[0][0] * ax + pts[0][1] * ay
                for (px, py) in pts[1:]:
                    v = px * ax + py * ay
                    if v < lo:
                        lo = v
                    if v > hi:
                        hi = v
                return lo, hi
            lo1, hi1 = proj(pa)
            lo2, hi2 = proj(pb)
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return False
    return True


def _inside_sat(s):
    x, y, a, sz = s
    if sz <= 0:
        return 0 <= x <= 1 and 0 <= y <= 1
    for (px, py) in _corners(x, y, a, sz):
        if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
            return False
    return True


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside_sat(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _sat_overlap(layout[i], layout[j]):
                return False
    return True


# ---------------- greedy largest-fit (axis aligned, fast) ----------------

def _overlap_aa(a, b):
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    if asz <= 0 or bsz <= 0:
        return False
    dx = abs(ax - bx)
    dy = abs(ay - by)
    ha = asz / 2.0
    hb = bsz / 2.0
    return dx < ha + hb - 1e-12 and dy < ha + hb - 1e-12


def _largest_fit(others, gridres=14):
    cands = [(0.5, 0.5)]
    for o in others:
        cands.append((o[0], o[1]))
        cands.append((o[0] + o[3] / 2.0, o[1]))
        cands.append((o[0] - o[3] / 2.0, o[1]))
        cands.append((o[0], o[1] + o[3] / 2.0))
        cands.append((o[0], o[1] - o[3] / 2.0))
        cands.append((o[0] + o[3] / 2.0, o[1] + o[3] / 2.0))
        cands.append((o[0] - o[3] / 2.0, o[1] - o[3] / 2.0))
        cands.append((o[0] + o[3] / 2.0, o[1] - o[3] / 2.0))
        cands.append((o[0] - o[3] / 2.0, o[1] + o[3] / 2.0))
    for gx in range(1, gridres):
        for gy in range(1, gridres):
            cands.append((gx / float(gridres), gy / float(gridres)))
    best = None
    for cx, cy in cands:
        lim = min(cx, 1 - cx, cy, 1 - cy)
        if lim <= 0:
            continue
        s = lim * 2.0
        for o in others:
            if o[3] <= 0:
                continue
            dx = abs(cx - o[0])
            dy = abs(cy - o[1])
            ho = o[3] / 2.0
            mx = dx - ho
            my = dy - ho
            if mx < 0 and my < 0:
                s = 0.0
                break
            allowed = max(mx, my)
            if allowed < s / 2.0:
                s = 2.0 * allowed
                if s <= 0:
                    s = 0.0
                    break
        if s > 0:
            sq = (cx, cy, 0.0, s)
            if _inside_sat(sq):
                if best is None or s > best[3]:
                    best = sq
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _refine_axis(layout, rounds=25):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = _largest_fit(others)
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _grow_in_place(layout, iters=6):
    """Try to enlarge each square in place (keep center, small angle drift) using SAT."""
    layout = [list(s) for s in layout]
    n = len(layout)
    angles = [0.0, 0.05, -0.05, 0.1, -0.1, 0.25, -0.25]
    for _ in range(iters):
        changed = False
        for i in range(n):
            x, y, a, sz = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = (sz, a, x, y)
            for da in angles:
                na = a + da
                test = (x, y, na, sz)
                if not _inside_sat(test):
                    continue
                # max size this square can take before hitting any neighbor
                ok = True
                for o in others:
                    if _sat_overlap((x, y, na, sz), o):
                        ok = False
                        break
                if not ok:
                    continue
                # binary grow
                lo, hi = sz, 2.0
                if _fit_size(x, y, na, others, hi) >= hi - 1e-9:
                    ns = hi
                else:
                    for _b in range(20):
                        mid = 0.5 * (lo + hi)
                        if _fit_size(x, y, na, others, mid) >= mid - 1e-9:
                            lo = mid
                        else:
                            hi = mid
                    ns = lo
                if ns > best[0] + 1e-9:
                    best = (ns, na, x, y)
            if best[0] > sz + 1e-9:
                layout[i] = [best[2], best[3], best[1], best[0]]
                changed = True
        if not changed:
            break
    return [tuple(s) for s in layout]


def _fit_size(x, y, a, others, sz):
    """Return sz if (x,y,a,sz) is valid against others and boundary, else 0."""
    if not _inside_sat((x, y, a, sz)):
        return 0.0
    for o in others:
        if _sat_overlap((x, y, a, sz), o):
            return 0.0
    return sz


def _slide_drop(layout, rounds=4):
    """Slide each square toward the center to free up boundary space, then grow."""
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        changed = False
        for i in range(n):
            x, y, a, sz = layout[i]
            others = [layout[j] for j in range(n) if j != i]
            best = (sz, x, y)
            steps = 0.02
            for dxm in (-1, 0, 1):
                for dym in (-1, 0, 1):
                    for k in range(1, 6):
                        nx = x + dxm * steps * k
                        ny = y + dym * steps * k
                        if not _inside_sat((nx, ny, a, sz)):
                            continue
                        ok = True
                        for o in others:
                            if _sat_overlap((nx, ny, a, sz), o):
                                ok = False
                                break
                        if not ok:
                            continue
                        # grow at new position
                        lo, hi = sz, 2.0
                        if _fit_size(nx, ny, a, others, hi) >= hi - 1e-9:
                            ns = hi
                        else:
                            for _b in range(16):
                                mid = 0.5 * (lo + hi)
                                if _fit_size(nx, ny, a, others, mid) >= mid - 1e-9:
                                    lo = mid
                                else:
                                    hi = mid
                            ns = lo
                        if ns > best[0] + 1e-9:
                            best = (ns, nx, ny)
            if best[0] > sz + 1e-9:
                layout[i] = [best[1], best[2], a, best[0]]
                changed = True
        if not changed:
            break
    return [tuple(s) for s in layout]


# ---------------- structured layout families ----------------

def _rect_grid_best_squares(rw, rh, k):
    best = None
    for cols in range(1, k + 1):
        rows = (k + cols - 1) // cols
        if cols * rows < k:
            continue
        s = min(rw / cols, rh / rows)
        tot = k * s
        if best is None or tot > best[0]:
            placements = []
            idx = 0
            for r in range(rows):
                for c in range(cols):
                    if idx >= k:
                        break
                    cx = (c + 0.5) * (rw / cols)
                    cy = (r + 0.5) * (rh / rows)
                    placements.append((cx, cy, 0.0, s))
                    idx += 1
                if idx >= k:
                    break
            best = (tot, placements)
    return best


def _tile_rect(rw, rh, k, ox, oy):
    r = _rect_grid_best_squares(rw, rh, k)
    if r is None:
        return None
    tot, placements = r
    out = [(px + ox, py + oy, a, s) for (px, py, a, s) in placements]
    return tot, out


def _slicing_layouts(n, fs_steps=240):
    results = []
    fs = [i / float(fs_steps) for i in range(1, fs_steps)]

    for k1 in range(1, n):
        k2 = n - k1
        best_for = None
        for f in fs:
            r1 = _tile_rect(f, 1.0, k1, 0.0, 0.0)
            if r1 is None:
                continue
            r2 = _tile_rect(1.0 - f, 1.0, k2, f, 0.0)
            if r2 is None:
                continue
            tot = r1[0] + r2[0]
            if best_for is None or tot > best_for[0]:
                best_for = (tot, r1[1] + r2[1])
        if best_for is not None:
            results.append(best_for[1])

    for k1 in range(1, n):
        k2 = n - k1
        best_for = None
        for f in fs:
            r1 = _tile_rect(1.0, f, k1, 0.0, 0.0)
            if r1 is None:
                continue
            r2 = _tile_rect(1.0, 1.0 - f, k2, 0.0, f)
            if r2 is None:
                continue
            tot = r1[0] + r2[0]
            if best_for is None or tot > best_for[0]:
                best_for = (tot, r1[1] + r2[1])
        if best_for is not None:
            results.append(best_for[1])

    fs3 = fs[::3]
    for ka in range(1, n - 1):
        for kb in range(1, n - ka):
            kc = n - ka - kb
            if kc < 1:
                continue
            best_for = None
            for f in fs3:
                for g in fs3:
                    r1 = _tile_rect(f, g, ka, 0.0, 0.0)
                    r2 = _tile_rect(f, 1.0 - g, kb, 0.0, g)
                    r3 = _tile_rect(1.0 - f, 1.0, kc, f, 0.0)
                    if None in (r1, r2, r3):
                        continue
                    tot = r1[0] + r2[0] + r3[0]
                    if best_for is None or tot > best_for[0]:
                        best_for = (tot, r1[1] + r2[1] + r3[1])
            if best_for is not None:
                results.append(best_for[1])
    return results


def _big_plus_strip(n):
    results = []
    if n < 2:
        return results
    k = n - 1
    for bi in range(1, 400):
        b = bi / 400.0
        if b >= 1.0:
            break
        layout = [(b / 2.0, b / 2.0, 0.0, b)]
        others = list(layout)
        ok = True
        for _ in range(k):
            sq = _largest_fit(others)
            if sq[3] <= 0:
                ok = False
                break
            others.append(list(sq))
        if ok and len(others) == n and _valid(others):
            results.append([tuple(s) for s in others])
    return results


def _corner_two_strips(n):
    results = []
    if n < 2:
        return results
    k = n - 1
    bs = [i / 600.0 for i in range(1, 600)]
    for ka in range(0, k + 1):
        kb = k - ka
        if ka == 0 or kb == 0:
            continue
        best_for = None
        for b in bs:
            rw = 1.0 - b
            rh = 1.0
            tw = b
            th = 1.0 - b
            ra = _rect_grid_best_squares(rw, rh, ka) if ka > 0 else (0.0, [])
            if ra is None:
                continue
            rb = _rect_grid_best_squares(tw, th, kb) if kb > 0 else (0.0, [])
            if rb is None:
                continue
            tot = b + ra[0] + rb[0]
            if best_for is None or tot > best_for[0]:
                pls = [(b / 2.0, b / 2.0, 0.0, b)]
                for (px, py, a, s) in ra[1]:
                    pls.append((b + px, py, a, s))
                for (px, py, a, s) in rb[1]:
                    pls.append((px, b + py, a, s))
                best_for = (tot, pls)
        if best_for is not None:
            results.append(best_for[1])
    out = []
    for lay in results:
        out.append(lay)
        out.append([(1.0 - x, y, a, s) for (x, y, a, s) in lay])
        out.append([(x, 1.0 - y, a, s) for (x, y, a, s) in lay])
        out.append([(1.0 - x, 1.0 - y, a, s) for (x, y, a, s) in lay])
    return out


def _total(layout):
    return sum(s[3] for s in layout)


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))
    for lay in _big_plus_strip(n):
        candidates.append(lay)
    for lay in _slicing_layouts(n):
        candidates.append(lay)
    for lay in _corner_two_strips(n):
        candidates.append(lay)

    # axis-aligned refinement of all candidates (fast)
    scored = []
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine_axis(cand)
        if not _valid(refined):
            refined = cand
        scored.append((_total(refined), refined))

    scored.sort(key=lambda t: -t[0])
    best_tot, best = (scored[0][0], scored[0][1]) if scored else (0.0, _best_grid(n)[1])

    # SAT-based growth only on top few candidates, budget-limited
    top = scored[:3]
    for tot, lay in top:
        cand = _grow_in_place(lay)
        cand = _slide_drop(cand)
        cand = _grow_in_place(cand)
        if _valid(cand):
            t = _total(cand)
            if t > best_tot + 1e-9:
                best_tot, best = t, cand

    return best
# EVOLVE-BLOCK-END

