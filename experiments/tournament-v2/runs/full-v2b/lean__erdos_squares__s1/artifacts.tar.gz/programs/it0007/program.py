# EVOLVE-BLOCK-START
"""Greedy packing + multi-start randomized refinement with rotation-aware SAT overlap test."""
import math
import random


def _corners(s):
    x, y, a, sz = s
    if sz <= 0:
        return [(x, y)] * 4
    h = sz / 2.0
    ang = a * 2.0 * math.pi
    c = math.cos(ang)
    si = math.sin(ang)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((x + dx * c - dy * si, y + dx * si + dy * c))
    return pts


def _proj(pts, ax):
    dots = [p[0] * ax[0] + p[1] * ax[1] for p in pts]
    return min(dots), max(dots)


def _overlap(a, b):
    sa, sb = a[3], b[3]
    if sa <= 0 or sb <= 0:
        return False
    pa = _corners(a)
    pb = _corners(b)
    # axes: two edges of each square
    axes = []
    for pts in (pa, pb):
        for k in range(2):
            ex = pts[k + 1][0] - pts[k][0]
            ey = pts[k + 1][1] - pts[k][1]
            n = math.hypot(ex, ey)
            if n > 1e-15:
                axes.append((-ey / n, ex / n))
    for ax in axes:
        loa, hia = _proj(pa, ax)
        lob, hib = _proj(pb, ax)
        if hia <= lob + 1e-12 or hib <= loa + 1e-12:
            return False
    return True


def _inside(s):
    for px, py in _corners(s):
        if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
            return False
    return True


def _valid(layout):
    for s in layout:
        if s[3] < -1e-9:
            return False
        if not _inside(s):
            return False
    for i in range(len(layout)):
        for j in range(i + 1, len(layout)):
            if _overlap(layout[i], layout[j]):
                return False
    return True


def _grid_layout(n, cols):
    rows = (n + cols - 1) // cols
    side = min(1.0 / cols, 1.0 / rows)
    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            squares.append(((c + 0.5) * side, (r + 0.5) * side, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares


def _best_grid(n):
    best = None
    for cols in range(1, n + 1):
        sq = _grid_layout(n, cols)
        tot = sum(s[3] for s in sq)
        if best is None or tot > best[0]:
            best = (tot, sq)
    return best


def _largest_fit(others, angles=(0.0,)):
    """Largest square that fits avoiding others; tries candidate centers and angles."""
    cands = [(0.5, 0.5)]
    for o in others:
        if o[3] <= 0:
            continue
        r = o[3] / 2.0
        cands.append((o[0], o[1]))
        cands.append((o[0] + r, o[1]))
        cands.append((o[0] - r, o[1]))
        cands.append((o[0], o[1] + r))
        cands.append((o[0], o[1] - r))
        cands.append((o[0] + r, o[1] + r))
        cands.append((o[0] - r, o[1] - r))
        cands.append((o[0] + r, o[1] - r))
        cands.append((o[0] - r, o[1] + r))
    for gx in range(1, 10):
        for gy in range(1, 10):
            cands.append((gx / 10.0, gy / 10.0))
    best = None
    for cx, cy in cands:
        if cx < 0 or cx > 1 or cy < 0 or cy > 1:
            continue
        for ang in angles:
            # start from wall-bound size
            s = _wall_max(cx, cy, ang)
            if s <= 0:
                continue
            # shrink against each obstacle
            for o in others:
                if o[3] <= 0:
                    continue
                if s <= 0:
                    break
                if not _circle_overlap(cx, cy, s / 2.0, o):
                    continue
                # binary search largest s so squares don't overlap
                lo, hi = 0.0, s
                for _ in range(30):
                    mid = (lo + hi) / 2.0
                    if _overlap((cx, cy, ang, mid), o):
                        hi = mid
                    else:
                        lo = mid
                s = lo
            if s > 0 and _inside((cx, cy, ang, s)):
                if best is None or s > best[3]:
                    best = (cx, cy, ang, s)
    if best is None:
        best = (0.5, 0.5, 0.0, 0.0)
    return best


def _wall_max(cx, cy, ang):
    """Max side so a square centered at (cx,cy) with angle ang stays in unit square."""
    h = 1.0
    ang2 = ang * 2.0 * math.pi
    c = abs(math.cos(ang2))
    si = abs(math.sin(ang2))
    # half-extent in x is h*(c+si), in y also h*(c+si) for square
    span = c + si
    if span <= 1e-15:
        return 2.0
    limx = min(cx, 1 - cx)
    limy = min(cy, 1 - cy)
    lim = min(limx, limy)
    return 2.0 * lim / span


def _circle_overlap(cx, cy, r, o):
    """Cheap conservative check: bounding circle overlap guess."""
    d = math.hypot(cx - o[0], cy - o[1])
    return d < r + o[3] * 0.75 + 1e-9


def _refine(layout, rounds=80):
    layout = [list(s) for s in layout]
    n = len(layout)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            removed = layout[i]
            others = [tuple(layout[j]) for j in range(n) if j != i]
            if removed[3] > 0:
                others.append((removed[0], removed[1], removed[2], removed[3] * 0.5))
            best = _largest_fit(others, angles=(0.0, 0.25, removed[2]))
            if best is not None and best[3] > removed[3] + 1e-9:
                layout[i] = list(best)
                improved = True
        if not improved:
            break
    return [tuple(s) for s in layout]


def _greedy_largest(n):
    layout = []
    for _ in range(n):
        sq = _largest_fit([tuple(s) for s in layout], angles=(0.0, 0.25))
        layout.append(list(sq))
    return [tuple(s) for s in layout]


def _random_layout(n, rng):
    """Random sequential greedy: perturb selection order/size slightly."""
    layout = []
    for _ in range(n):
        base = _largest_fit([tuple(s) for s in layout], angles=(0.0, 0.25))
        # random perturbation
        x = min(max(base[0] + rng.uniform(-0.1, 0.1), 0.0), 1.0)
        y = min(max(base[1] + rng.uniform(-0.1, 0.1), 0.0), 1.0)
        ang = base[2]
        cand = (x, y, ang, base[3])
        # shrink so valid
        s = base[3]
        for o in layout:
            if _overlap((x, y, ang, s), o):
                lo, hi = 0.0, s
                for _ in range(25):
                    mid = (lo + hi) / 2.0
                    if _overlap((x, y, ang, mid), o):
                        hi = mid
                    else:
                        lo = mid
                s = lo
        s = min(s, _wall_max(x, y, ang))
        if not _inside((x, y, ang, s)):
            s = 0.0
            x, y, ang = 0.5, 0.5, 0.0
        layout.append((x, y, ang, s))
    return layout


def solve(n):
    if n <= 0:
        return []

    candidates = []
    candidates.append(_best_grid(n)[1])
    candidates.append(_greedy_largest(n))

    rng = random.Random(12345)
    extra = max(0, min(25, 30 - n))
    for _ in range(extra):
        candidates.append(_random_layout(n, rng))

    best = None
    for cand in candidates:
        if len(cand) != n:
            continue
        refined = _refine(cand)
        if not _valid(refined):
            refined = cand
            if not _valid(refined):
                continue
        tot = sum(s[3] for s in refined)
        if best is None or tot > best[0]:
            best = (tot, refined)

    if best is None:
        return _best_grid(n)[1]
    return best[1]
# EVOLVE-BLOCK-END
