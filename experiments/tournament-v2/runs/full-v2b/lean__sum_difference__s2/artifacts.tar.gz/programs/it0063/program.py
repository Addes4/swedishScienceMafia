# EVOLVE-BLOCK-START
"""Block-product over Sidon set, spacing tuned to the sum-collision threshold,
   with a short deterministic polish."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(12345)

    def consider(a):
        nonlocal best, best_score
        if not a or len(a) < 3 or len(a) > 4000:
            return
        a = sorted(set(a))
        if len(a) > 4000:
            return
        sc = _score(a)
        if sc > best_score:
            best_score, best = sc, a[:]

    # --- generate Sidon cores ---
    cores = []
    for p in [23, 29, 41, 53, 71, 101, 149, 211, 307, 401, 557, 809]:
        B = _bose_chowla(p)
        cores.append(B)

    # --- sweep block constructions near the sum-collision threshold ---
    for B in cores:
        nb = len(B)
        lo, hi = min(B), max(B)
        rngb = hi - lo
        # base spacing candidates around the range / nearby values
        base_spacings = set()
        for base in [hi, hi + 1, rngb, rngb + 1, rngb + lo, nb, 2 * nb]:
            if base < 2:
                continue
            for mult in [0.6, 0.75, 0.85, 0.95, 1.0, 1.05, 1.1, 1.2, 1.35, 1.5]:
                base_spacings.add(max(2, int(base * mult)))
        for k in [2, 3, 4, 5, 6, 7, 8, 10, 12]:
            if k * nb > 4000 or k * nb < 12:
                continue
            for M in base_spacings:
                consider(_build(B, k, M))

    # --- short deterministic polish on the best block construction ---
    def polish(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        curset = set(cur)
        improved = True
        while improved and time.time() < tlimit:
            improved = False
            n = len(cur)
            # try single-element perturbations / removals
            for i in range(n):
                orig = cur[i]
                for delta in (-2, -1, 1, 2, -5, 5, -10, 10):
                    cand = cur[:]
                    cand[i] = orig + delta
                    cand = sorted(set(cand))
                    if len(cand) != n:
                        continue
                    s = _score(cand)
                    if s > cs:
                        cur, cs = cand, s
                        improved = True
                        break
                if improved:
                    break
            if improved:
                continue
            # try removing one element
            for i in range(n):
                cand = cur[:i] + cur[i + 1:]
                s = _score(cand)
                if s > cs:
                    cur, cs = cand, s
                    improved = True
                    break
        return cur, cs

    if best is not None:
        b, bs = polish(best, min(deadline, time.time() + 25))
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END

