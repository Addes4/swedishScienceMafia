# EVOLVE-BLOCK-START
"""Sidon-union construction with fine shift/dilation sweep and ratio-focused local search."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(20240117)

    # Build candidate seeds: Bose-Chowla Sidon sets, unioned with shifted/dilated copies.
    seeds = []
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        spread = max(B) - min(B)
        # single block directly
        seeds.append(B[:])
        # union of shifted copies: B + t*d
        for ncopy in [2, 3, 4]:
            if ncopy * nb > 4000:
                continue
            baseM = spread + 1
            for mult in [0.05, 0.15, 0.3, 0.5, 0.75, 1.0, 1.5, 2.0]:
                d = max(1, int(baseM * mult))
                A = []
                for t in range(ncopy):
                    off = t * d
                    A.extend(x + off for x in B)
                seeds.append(A)
        # dilated copies: scale B by s then shift
        for s in [2, 3, 5]:
            Bs = [s * x for x in B]
            if len(Bs) <= 4000:
                seeds.append(Bs)
            for ncopy in [2, 3]:
                if ncopy * nb > 4000:
                    continue
                baseM = spread * s + 1
                for mult in [0.3, 0.75, 1.0, 1.5]:
                    d = max(1, int(baseM * mult))
                    A = []
                    for t in range(ncopy):
                        A.extend(x + t * d for x in Bs)
                    seeds.append(A)

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, sorted(set(s))[:]

    def local_opt(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        best_local, best_local_s = cur[:], cs
        step = 0
        stall = 0
        while time.time() < tlimit and step < 60000:
            step += 1
            cand = cur[:]
            op = rng.random()
            if op < 0.25 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-10, 10)
            elif op < 0.45 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-2, 2)
            elif op < 0.60 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-1, 1]) * rng.randint(20, 1500)
            elif op < 0.72 and len(cand) > 5:
                i = rng.randrange(len(cand))
                del cand[i]
            elif op < 0.86:
                if cand:
                    b = rng.choice(cand)
                    cand.append(b + rng.randint(-30, 30))
            else:
                if len(cand) >= 2:
                    a1 = rng.choice(cand)
                    a2 = rng.choice(cand)
                    cand.append(a1 + a2 - rng.choice(cand))
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_local_s:
                    best_local, best_local_s = cand[:], s
                    stall = 0
                else:
                    stall += 1
            else:
                stall += 1
            if stall > 4000:
                break
        return best_local, best_local_s

    idx = 0
    nseeds = len(seeds)
    while time.time() < deadline:
        if idx < nseeds:
            base = seeds[idx]
            idx += 1
        else:
            if rng.random() < 0.75 and seeds:
                base = [x + rng.randint(-15, 15) for x in rng.choice(seeds)]
            elif rng.random() < 0.5 and seeds:
                n = rng.randint(40, 300)
                base = [rng.choice(rng.choice(seeds)) + rng.randint(-100, 100) for _ in range(n)]
            else:
                n = rng.randint(30, 250)
                base = [rng.randint(-10 ** 6, 10 ** 6) for _ in range(n)]
            base = sorted(set(base))
        tlimit = min(deadline, time.time() + 8)
        b, bs = local_opt(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
