# EVOLVE-BLOCK-START
"""Block-product over Sidon set with a fixed small additive core, exact scoring."""
import math
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, M, C):
    A = []
    for b in B:
        base = M * b
        for c in C:
            A.append(base + c)
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0

    primes = [29, 53, 101, 211, 401, 809, 1601]

    # fixed small additive cores; larger T means more sum collisions but more elements
    cores = [
        [0, 1],
        [0, 1, 2],
        [0, 2],
        [0, 1, 2, 3],
        [0, 1, 3],
        [0, 1, 2, 3, 4],
    ]

    for p in primes:
        if p - 1 > 4000:
            continue
        B = _bose_chowla(p)
        nb = len(B)
        spread = max(B) - min(B)
        baseM = spread + 1
        for C in cores:
            T = len(C)
            if nb * T > 4000 or nb * T < 8:
                continue
            # M controls scaling; sum-collision wants small M, diff-preservation wants large
            for mult in [1.0, 0.5, 0.25, 0.125, 0.0625, 3.0, 0.75, 1.5]:
                M = max(2, int(baseM * mult))
                A = _build(B, M, C)
                if len(set(A)) != len(A):
                    continue
                sc = _score(A)
                if sc > best_score:
                    best_score, best = sc, A

    if best is None:
        # fallback small construction
        best = list(range(20))

    return sorted(set(best))
# EVOLVE-BLOCK-END

