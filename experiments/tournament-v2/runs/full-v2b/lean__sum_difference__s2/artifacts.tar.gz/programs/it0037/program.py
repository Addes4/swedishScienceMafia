# EVOLVE-BLOCK-START
"""Product construction: interval (tiny sumset) x Sidon base (large diffset)."""
import math
import time

import numpy as np


def _score_parts(arr):
    n = arr.size
    if n < 2:
        return 0.0, 0, 0
    d = np.unique(arr[:, None] - arr[None, :])
    s = np.unique(arr[:, None] + arr[None, :])
    nd, ns = d.size, s.size
    if nd < 2 or ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0

    bases = []
    for p in [29, 53, 101, 211, 401]:
        B = [b - min(_bose_chowla(p)) for b in _bose_chowla(p)]
        bases.append(B)

    # Build candidate sets: interval {0..T-1} shifted by M*b for b in B.
    # Sums of interval part collapse (only 2T-1 distinct), diffs of interval
    # part are small range; the Sidon base pushes differences far out.
    def build(B, T, M):
        A = []
        for b in B:
            off = M * b
            for t in range(T):
                A.append(off + t)
        return A

    candidates = []
    for B in bases:
        nb = len(B)
        spread = max(B) - min(B)
        for T in range(2, 33):
            for k in range(1, nb + 1):
                Bk = B[:k]
                n = k * T
                if n > 4000 or n < 4:
                    continue
                sp = max(Bk) - min(Bk) if k > 1 else 0
                # spacing sweep: from tiny to wide
                for M in {1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144,
                          T, T + 1, 2 * T, 3 * T, sp + 1, 2 * (sp + 1),
                          max(1, sp // 2), max(1, sp // 3)}:
                    if M < 1:
                        continue
                    A = build(Bk, T, M)
                    if len(A) > 4000:
                        continue
                    candidates.append(A)

    # fast evaluation
    seen = set()
    scored = []
    for A in candidates:
        key = tuple(sorted(set(A)))
        if key in seen:
            continue
        seen.add(key)
        arr = np.array(key, dtype=np.int64)
        sc, nd, ns = _score_parts(arr)
        scored.append((sc, key))

    scored.sort(key=lambda z: -z[0])
    if scored:
        best_score, key = scored[0]
        best = list(key)

    # Refinement: take top candidates, try local tweaks around the interval
    # boundaries and spacing using fast numpy scoring.
    import random
    rng = random.Random(12345)
    top = [list(k) for _, k in scored[:30]]

    def fast_score(a):
        arr = np.array(sorted(set(a)), dtype=np.int64)
        if arr.size < 2:
            return 0.0, arr
        return _score_parts(arr)[0], arr

    for base in top:
        if time.time() > deadline - 5:
            break
        cur = base[:]
        cs, _ = fast_score(cur)
        curset = set(cur)
        for _ in range(3000):
            if time.time() > deadline - 2:
                break
            cand = cur[:]
            op = rng.random()
            if op < 0.4 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-3, 3)
            elif op < 0.6 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-1, 1]) * rng.randint(1, 40)
            elif op < 0.75 and len(cand) > 4:
                i = rng.randrange(len(cand))
                del cand[i]
            else:
                if cand:
                    cand.append(rng.choice(cand) + rng.randint(-10, 10))
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s, _ = fast_score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_score:
                    best_score, best = s, cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
