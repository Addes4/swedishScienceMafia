# EVOLVE-BLOCK-START
"""Block clusters over a Sidon base: A = {M*b + t}. Tune M,T for small sumset, big diffset."""
import math
import random
import time

import numpy as np


def _score_np(arr):
    n = arr.shape[0]
    if n < 2:
        return 0.0
    d = np.unique(arr[:, None] - arr[None, :])
    s = np.unique(arr[:, None] + arr[None, :])
    nd = d.shape[0]
    ns = s.shape[0]
    if nd < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _counts_np(arr):
    d = np.unique(arr[:, None] - arr[None, :])
    s = np.unique(arr[:, None] + arr[None, :])
    return d.shape[0], s.shape[0]


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    dd = 2
    while dd * dd <= m:
        while m % dd == 0:
            facs.add(dd)
            m //= dd
        dd += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def solve():
    deadline = time.time() + 108
    best = None
    best_score = -1.0
    best_arr = None

    # Base Sidon sets
    bases = []
    for p in [29, 53, 101, 211, 401]:
        B = _bose_chowla(p)
        bases.append(B)

    # Construction: A = { M*b + t : b in B, t in range(T) }
    # Sweep M (spacing between clusters) and T (cluster width).
    # Tight M makes cross-cluster sums collide; small T keeps intra-cluster sums few.
    for B in bases:
        nb = len(B)
        blo = min(B)
        Bs = [b - blo for b in B]  # normalize to start at 0
        bmax = max(Bs)
        # candidate T values
        for T in [1, 2, 3, 4, 5, 6, 8, 12, 16]:
            n = nb * T
            if n > 4000 or n < 20:
                continue
            # M around the "sum-collision" region: M ~ T (so that t ranges overlap)
            # and also around bmax (cluster separation). Sweep broadly.
            for M in [T, T + 1, 2 * T + 1, bmax + 1, bmax // 2 + 1,
                      tval for tval in []]:
                pass
            Mlist = set()
            for base in [T, T + 1, 2 * T + 1]:
                for f in [0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0]:
                    Mlist.add(max(1, int(base * f)))
            for base in [bmax, bmax + 1]:
                for f in [0.1, 0.25, 0.5, 0.75, 1.0]:
                    Mlist.add(max(1, int(base * f)))
            for M in Mlist:
                if M < 1:
                    continue
                arr = []
                for i in range(nb):
                    off = M * Bs[i]
                    for t in range(T):
                        arr.append(off + t)
                arr = np.array(sorted(set(arr)), dtype=np.int64)
                if arr.shape[0] < 3:
                    continue
                sc = _score_np(arr)
                if sc > best_score:
                    best_score = sc
                    best_arr = arr.copy()

    if best_arr is None:
        best_arr = np.array([0, 1], dtype=np.int64)

    # Greedy refinement: try removing elements, moving elements, adding elements
    # that reduce the sumset without reducing the diffset ratio.
    rng = random.Random(12345)
    cur = best_arr.copy()
    cur_score = best_score

    def try_candidate(cand_arr, cur_arr, cur_sc, best_arr, best_sc):
        cand_arr = np.unique(cand_arr)
        n = cand_arr.shape[0]
        if n < 3 or n > 4000:
            return best_arr, best_sc, cur_arr, cur_sc
        nd, ns = _counts_np(cand_arr)
        if nd < 2 or ns < 2:
            return best_arr, best_sc, cur_arr, cur_sc
        sc = math.log(nd) / math.log(ns) + (1 - 1 / n) / 100
        if sc > best_sc:
            best_sc = sc
            best_arr = cand_arr.copy()
        if sc >= cur_sc:
            cur_sc = sc
            cur_arr = cand_arr.copy()
        return best_arr, best_sc, cur_arr, cur_sc

    steps = 0
    stall = 0
    while time.time() < deadline and steps < 4000:
        steps += 1
        cand = cur.copy()
        op = rng.random()
        n = cur.shape[0]
        if op < 0.4 and n > 3:
            # remove a random element
            i = rng.randrange(n)
            cand = np.delete(cand, i)
        elif op < 0.7:
            # move an element
            i = rng.randrange(n)
            spread = max(1, int(cand.max() - cand.min()))
            cand[i] += rng.randint(-spread // 10 - 5, spread // 10 + 5)
        elif op < 0.9:
            # add an element near the middle (fill sums)
            lo = int(cand.min())
            hi = int(cand.max())
            cand = np.append(cand, rng.randint(lo, hi))
        else:
            # add a sum of two elements (sumset-filling region)
            i = rng.randrange(n)
            j = rng.randrange(n)
            cand = np.append(cand, int(cand[i]) + int(cand[j]) - int(cand[rng.randrange(n)]))
        cand = cand.astype(np.int64)
        before = best_score
        best_arr, best_score, cur, cur_score = try_candidate(
            cand, cur, cur_score, best_arr, best_score
        )
        if best_score > before:
            stall = 0
        else:
            stall += 1
        if stall > 800:
            # restart from a fresh block construction with random params
            B = rng.choice(bases)
            T = rng.choice([2, 3, 4, 5, 6, 8])
            nb = len(B)
            blo = min(B)
            Bs = [b - blo for b in B]
            bmax = max(Bs)
            M = rng.randint(1, max(2, bmax))
            arr = []
            for i in range(nb):
                off = M * Bs[i]
                for t in range(T):
                    arr.append(off + t)
            arr = np.unique(np.array(arr, dtype=np.int64))
            if arr.shape[0] >= 3:
                sc = _score_np(arr)
                cur = arr
                cur_score = sc
                if sc > best_score:
                    best_score = sc
                    best_arr = arr.copy()
            stall = 0

    return sorted(set(int(x) for x in best_arr))
# EVOLVE-BLOCK-END
