# EVOLVE-BLOCK-START
"""Improved: Bose-Chowla Sidon seeds + numpy-accelerated hill climbing on the true ratio."""
import math
import random
import time

import numpy as np


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    ns = len(sums)
    if ns < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    sizes = [p for p in [101, 211, 401, 809, 1601, 3203] if p <= 4000]
    seeds = []
    for p in sizes:
        if p >= 101:
            seeds.append(_bose_chowla(p))

    rng = random.Random(12345)

    while time.time() < deadline:
        if seeds:
            base = list(seeds.pop(0))
        else:
            n = rng.randint(20, 200)
            base = [rng.randint(1, 10 ** 6) for _ in range(n)]
        cur = base[:]
        cur_score = _score(cur)
        if cur_score > best_score:
            best_score, best = cur_score, cur[:]
        step = 0
        while time.time() < deadline and step < 20000:
            step += 1
            cand = cur[:]
            op = rng.random()
            if op < 0.5 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-50, 50)
            elif op < 0.75:
                cand.append(rng.randint(-1000, 1000))
            elif len(cand) > 3:
                i = rng.randrange(len(cand))
                del cand[i]
            s = _score(cand)
            if s >= cur_score:
                cur, cur_score = cand, s
                if s > best_score:
                    best_score, best = s, cand[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END
