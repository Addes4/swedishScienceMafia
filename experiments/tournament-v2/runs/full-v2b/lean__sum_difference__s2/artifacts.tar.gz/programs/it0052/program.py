# EVOLVE-BLOCK-START
"""Union of shifted Sidon sets: few sum-shifts, many difference-shifts."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _score_fast(a):
    """Vectorized score, tolerates duplicates."""
    arr = np.unique(np.array(a, dtype=np.int64))
    n = len(arr)
    if n < 2:
        return 0.0
    d = np.unique(arr[:, None] - arr[None, :])
    s = np.unique(arr[:, None] + arr[None, :])
    nd, ns = len(d), len(s)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(987654321)

    prims = [29, 53, 101, 211, 401, 809, 1601]

    seeds = []
    # Union construction: A = {b*k + shift : b in B, shift in shifts}
    # where shifts are an arithmetic progression {0, d, 2d, ..., (m-1)d}
    # B a Bose-Chowla Sidon set. k scales B to spread it out.
    for p in prims:
        B = _bose_chowla(p)
        nb = len(B)
        for m in [2, 3, 4, 5, 6]:
            if nb * m > 4000 or nb * m < 20:
                continue
            for k in [1, 2]:
                spread = (max(B) - min(B)) * k
                # d must be chosen around spread so the shifted copies are
                # just separated; sweep tightly around spread/m .. spread.
                for dfrac in [0.05, 0.1, 0.2, 0.3, 0.5, 0.75, 1.0, 1.5, 2.0]:
                    d = max(2, int(spread * dfrac / max(1, m - 1) if m > 1 else spread))
                    A = []
                    for s in range(m):
                        shift = s * d
                        for b in B:
                            A.append(k * b + shift)
                    seeds.append(A)

    # Also: positive-only small union examples, scaling slowly.
    for p in [53, 101, 211, 401]:
        B = _bose_chowla(p)
        nb = len(B)
        for m in [2, 3, 4]:
            if nb * m > 4000 or nb * m < 20:
                continue
            lo = min(B)
            hi = max(B)
            rngb = hi - lo
            for d in [rngb // 4, rngb // 2, rngb, rngb + 1, rngb + 2,
                      2 * rngb, 3 * rngb]:
                if d < 2:
                    continue
                A = []
                for s in range(m):
                    for b in B:
                        A.append(b + s * d)
                seeds.append(A)

    for s0 in seeds:
        sc = _score_fast(s0)
        if sc > best_score:
            best_score, best = sc, sorted(set(s0))

    def local_opt(base, tlimit):
        cur = sorted(set(base))
        cs = _score_fast(cur)
        best_local, best_local_s = cur[:], cs
        step = 0
        stall = 0
        while time.time() < tlimit and step < 80000:
            step += 1
            cand = cur[:]
            op = rng.random()
            if op < 0.20 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-20, 20)
            elif op < 0.35 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-3, 3)
            elif op < 0.48:
                if cand:
                    i = rng.randrange(len(cand))
                    cand[i] += rng.choice([-1, 1]) * rng.randint(50, 3000)
            elif op < 0.60:
                if cand:
                    i = rng.randrange(len(cand))
                    cand[i] += rng.randint(-300, 300)
            elif op < 0.70 and len(cand) > 5:
                i = rng.randrange(len(cand))
                del cand[i]
            elif op < 0.82:
                if cand:
                    base_el = rng.choice(cand)
                    cand.append(base_el + rng.randint(-50, 50))
            elif op < 0.92:
                if len(cand) >= 2:
                    a1 = rng.choice(cand)
                    a2 = rng.choice(cand)
                    cand.append(a1 + a2 - rng.choice(cand))
            else:
                cand.append(rng.randint(-5000, 5000))
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s = _score_fast(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_local_s:
                    best_local, best_local_s = cand[:], s
                    stall = 0
                else:
                    stall += 1
            else:
                stall += 1
            if stall > 5000:
                break
        return best_local, best_local_s

    idx = 0
    nseeds = len(seeds)
    while time.time() < deadline:
        if idx < nseeds:
            base = seeds[idx]
            idx += 1
        else:
            if rng.random() < 0.7 and seeds:
                base = [x + rng.randint(-20, 20) for x in rng.choice(seeds)]
            else:
                n = rng.randint(30, 300)
                base = [rng.randint(-10 ** 6, 10 ** 6) for _ in range(n)]
            base = sorted(set(base))
        tlimit = min(deadline, time.time() + 10)
        b, bs = local_opt(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
