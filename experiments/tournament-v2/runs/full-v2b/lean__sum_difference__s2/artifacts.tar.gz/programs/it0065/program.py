# EVOLVE-BLOCK-START
"""Block construction over a short sparse core + greedy sum-preserving inserts."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(1357911)

    # ---- Phase 1: block seeds sweeping M near the sum-collision threshold.
    seeds = []
    for p in [29, 53, 101, 211, 401]:
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        spread = hi - lo
        for k in [3, 4, 5, 6, 7, 8, 10, 12]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for mult in [0.10, 0.20, 0.33, 0.5, 0.75, 1.0, 1.5, 2.0]:
                M = max(2, int(spread * mult))
                seeds.append(_build(B, k, M))
            # M values directly tied to the "gap" scale of B
            for M in [2, 3, 4, 5, 7, 11, 13]:
                seeds.append(_build(B, k, M))

    for s in seeds:
        s = sorted(set(s))
        if len(s) > 4000:
            continue
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    # ---- Phase 2: greedy sum-preserving / difference-growing insets.
    def polish(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        curset = set(cur)
        bc, bcs = cur[:], cs
        tries = 0
        while time.time() < tlimit and tries < 40000:
            tries += 1
            cand = cur[:]
            op = rng.random()
            if op < 0.55 and len(cand) >= 2:
                # insert an element inside an existing sum-difference (keeps new sums low)
                a1 = cand[rng.randrange(len(cand))]
                a2 = cand[rng.randrange(len(cand))]
                v = a1 + a2 - cand[rng.randrange(len(cand))]
                if v not in curset:
                    cand.append(v)
            elif op < 0.75 and len(cand) >= 2:
                # insert element == existing sum (collides in sumset)
                a1 = cand[rng.randrange(len(cand))]
                a2 = cand[rng.randrange(len(cand))]
                v = a1 + a2
                if v not in curset and abs(v) < 10**15:
                    cand.append(v)
            elif op < 0.90 and cand:
                # small nudge to close a near-duplicate difference
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-6, 6)
            else:
                if cand:
                    i = rng.randrange(len(cand))
                    cand[i] += rng.choice([-1, 1]) * rng.randint(1, 400)
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs, curset = cand, s, set(cand)
                if s > bcs:
                    bc, bcs = cand[:], s
        return bc, bcs

    # seed phase 2 from the best few block constructions
    ranked = sorted((( _score(sorted(set(s))), sorted(set(s)) ) for s in seeds
                     if len(set(s)) <= 4000), key=lambda x: -x[0])[:8]
    ranked = [r for r in ranked if r[1]]
    idx = 0
    while time.time() < deadline:
        if idx < len(ranked):
            base = ranked[idx][1]
            idx += 1
        else:
            if ranked and rng.random() < 0.6:
                base = [x + rng.randint(-3, 3) for x in rng.choice(ranked)[1]]
                base = sorted(set(base))
            else:
                n = rng.randint(40, 400)
                base = sorted(set(rng.randint(-10**6, 10**6) for _ in range(n)))
        tlimit = min(deadline, time.time() + 12)
        b, bs = polish(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    if best is None:
        best = [0, 1]
    return sorted(set(best))
# EVOLVE-BLOCK-END
