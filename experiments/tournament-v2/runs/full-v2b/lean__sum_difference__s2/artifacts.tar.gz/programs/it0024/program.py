# EVOLVE-BLOCK-START
"""Block-product over Sidon set + numpy hill climb on true log-ratio."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0

    # Build block-product seeds: A = {i*M + b}
    # B is Sidon (Bose-Chowla). Blocks separated by large M.
    seeds = []
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        nbf = max(B)
        # number of blocks k so total size <= 4000
        for k in [2, 3, 4, 5, 6, 8, 10, 14, 20]:
            if k * nb > 4000 or k * nb < 20:
                continue
            M = nbf * (k + 2) + 10  # keep blocks separated
            # offset blocks by multiples of M so sums between blocks overlap where possible
            A = []
            for i in range(k):
                off = i * M
                for b in B:
                    A.append(off + b)
            seeds.append(A)

    rng = random.Random(987654321)

    # score all seeds first
    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    def local_opt(base, tlimit):
        cur = base[:]
        cs = _score(cur)
        best_local, best_local_s = cur[:], cs
        step = 0
        while time.time() < tlimit and step < 30000:
            step += 1
            cand = cur[:]
            op = rng.random()
            if op < 0.35 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-30, 30)
            elif op < 0.55:
                # add an element from a shifted copy to induce collisions
                if cand:
                    cand.append(rng.choice(cand) + rng.randint(-200, 200))
            elif op < 0.7 and len(cand) > 5:
                i = rng.randrange(len(cand))
                del cand[i]
            elif op < 0.85 and len(cand) >= 4:
                # translate a whole block
                cand = sorted(set(cand))
                i = rng.randrange(len(cand))
                cand[i] -= rng.randint(-500, 500)
            else:
                cand.append(rng.randint(-3000, 3000))
            cand = sorted(set(cand))
            if len(cand) > 4000:
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_local_s:
                    best_local, best_local_s = cand[:], s
        return best_local, best_local_s

    idx = 0
    while time.time() < deadline:
        if idx < len(seeds):
            base = seeds[idx]
            idx += 1
        else:
            n = rng.randint(50, 800)
            base = [rng.randint(-10 ** 6, 10 ** 6) for _ in range(n)]
            base = sorted(set(base))
        tlimit = min(deadline, time.time() + 15)
        b, bs = local_opt(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
