# EVOLVE-BLOCK-START
"""Strong Sidon-product seeds with a refinement pass over block offsets."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(13579)

    seeds = []

    # Block product over Sidon sets: A = {i*M + b}.
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        spread = max(B) - min(B)
        baseM = spread + 1
        for k in [2, 3, 4, 5, 6, 7, 8, 9]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for mult in [0.1, 0.25, 0.5, 0.75, 1.0, 1.5, 2.0]:
                M = max(2, int(baseM * mult))
                A = []
                for i in range(k):
                    off = i * M
                    for b in B:
                        A.append(off + b)
                seeds.append(A)

    # Tight spacings relative to B-range for sum-collapse.
    for p in [53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        rngb = hi - lo
        for k in [2, 3, 4, 5, 6, 7]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for M in [rngb // 4, rngb // 3, rngb // 2, rngb, rngb + 1, 2 * rngb]:
                if M < 2:
                    continue
                A = []
                for i in range(k):
                    off = i * M
                    for b in B:
                        A.append(off + b)
                seeds.append(A)

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    def refine(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        bl, bls = cur[:], cs
        stall = 0
        step = 0
        while time.time() < tlimit and step < 40000:
            step += 1
            cand = cur[:]
            r = rng.random()
            if r < 0.35 and cand:
                # shift a whole block-ish cluster
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-40, 40)
            elif r < 0.6 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-1, 1]) * rng.randint(100, 5000)
            elif r < 0.75 and len(cand) > 4:
                i = rng.randrange(len(cand))
                del cand[i]
            elif r < 0.9:
                if cand:
                    e = rng.choice(cand)
                    cand.append(e + rng.randint(-100, 100))
            else:
                if len(cand) >= 2:
                    a1 = rng.choice(cand)
                    a2 = rng.choice(cand)
                    cand.append(a1 + a2 - rng.choice(cand))
            cand = sorted(set(cand))
            if not (3 <= len(cand) <= 4000):
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > bls:
                    bl, bls = cand[:], s
                    stall = 0
                else:
                    stall += 1
            else:
                stall += 1
            if stall > 3000:
                break
        return bl, bls

    idx = 0
    nseeds = len(seeds)
    while time.time() < deadline:
        if idx < nseeds:
            base = seeds[idx]
            idx += 1
        else:
            if seeds and rng.random() < 0.8:
                base = [x + rng.randint(-30, 30) for x in rng.choice(seeds)]
            else:
                base = sorted(set(rng.randint(-10 ** 6, 10 ** 6)
                                  for _ in range(rng.randint(30, 250))))
        tlimit = min(deadline, time.time() + 6)
        b, bs = refine(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
