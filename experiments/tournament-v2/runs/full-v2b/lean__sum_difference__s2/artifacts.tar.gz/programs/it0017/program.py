# EVOLVE-BLOCK-START
"""Search over structured integer sets to maximize log|A-A|/log|A+A|."""
import math
import itertools


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = len({x - y for x in a for y in a})
    sums = len({x + y for x in a for y in a})
    if sums < 2 or diffs < 2:
        return 0.0
    return math.log(diffs) / math.log(sums) + (1 - 1 / n) / 100


def _try(a):
    a = sorted(set(a))
    return a, _score(a)


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # 1) Geometric progressions A = {1,2,4,...} lead to highly distinct differences
    #    (differences of distinct powers are unique-ish) and many sum collisions.
    for n in range(2, 30):
        a = [2 ** i for i in range(n)]
        a, s = _try(a)
        if s > best_score:
            best, best_score = a, s

    # 2) Geometric with general ratio r and offset, small searches.
    for r in range(2, 12):
        for n in range(2, 25):
            a = [r ** i for i in range(n)]
            if max(a) > 10 ** 15:
                break
            a, s = _try(a)
            if s > best_score:
                best, best_score = a, s

    # 3) Powers of a base times offset shift (tune so |A+A| collapses).
    for r in range(2, 16):
        for n in range(4, 30):
            a = [r ** i + i for i in range(n)]
            if max(a) > 10 ** 15:
                break
            a, s = _try(a)
            if s > best_score:
                best, best_score = a, s

    # 4) Take a geometric base and trim / densify to push sum collisions.
    for r in range(2, 8):
        base = [r ** i for i in range(26)]
        base = [x for x in base if x <= 10 ** 15]
        # try removing later elements that inflate the sum set
        for cut in range(4, len(base) + 1):
            a = base[:cut]
            a, s = _try(a)
            if s > best_score:
                best, best_score = a, s

    # 5) Sidon-like: B = {i^2} has few distinct sums relative to differences.
    for n in range(3, 60):
        a = [i * i for i in range(n)]
        a, s = _try(a)
        if s > best_score:
            best, best_score = a, s

    # 6) Union of two geometric blocks (differences large, sums collide across blocks).
    for r in range(2, 6):
        for n in range(4, 22):
            for k in range(1, 6):
                block1 = [r ** i for i in range(n)]
                if max(block1) > 10 ** 15:
                    break
                shift = r ** n * k
                if shift > 10 ** 15:
                    continue
                a = block1 + [x + shift for x in block1]
                a, s = _try(a)
                if s > best_score:
                    best, best_score = a, s

    # 7) Powers of two but with small perturbations trying to collapse more sums.
    base = [1 << i for i in range(28)]
    base = [x for x in base if x <= 10 ** 15]
    for n in range(4, len(base) + 1):
        a = base[:n]
        a, s = _try(a)
        if s > best_score:
            best, best_score = a, s
        # colliding variant: replace top element with a small sum
        a2 = base[:n - 1] + [base[n - 2]]
        a2, s2 = _try(a2)
        if s2 > best_score:
            best, best_score = a2, s2

    return sorted(set(best))
# EVOLVE-BLOCK-END

