# EVOLVE-BLOCK-START
"""Simulated annealing on the true log-ratio, seeded by block-product Sidon sets."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _seed_blocks():
    seeds = []
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        nbf = max(B)
        for k in [2, 3, 4, 5, 6, 8, 10, 14, 20]:
            tot = k * nb
            if tot > 4000 or tot < 20:
                continue
            M = nbf * (k + 2) + 10
            A = []
            for i in range(k):
                off = i * M
                for b in B:
                    A.append(off + b)
            seeds.append(sorted(set(A)))
    return seeds


def solve():
    deadline = time.time() + 112
    rng = random.Random(20240109)

    seeds = _seed_blocks()
    best = None
    best_score = -1.0
    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]
    if best is None:
        best = list(range(1, 300))
        best_score = _score(best)

    def anneal(base, t_end, temp0=0.02):
        cur = sorted(set(base))
        cs = _score(cur)
        bl, bls = cur[:], cs
        lo = min(cur) - 5000
        hi = max(cur) + 5000
        start = time.time()
        total = max(t_end - start, 1e-6)
        t = 0
        while time.time() < t_end:
            t += 1
            frac = min((time.time() - start) / total, 1.0)
            T = temp0 * (0.001 ** frac)
            cand = cur[:]
            r = rng.random()
            if r < 0.30 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-40, 40)
            elif r < 0.50 and cand:
                i = rng.randrange(len(cand))
                cand.append(cand[i] + rng.choice([-1, 1]) * rng.randint(1, 200))
            elif r < 0.65 and len(cand) > 5:
                del cand[rng.randrange(len(cand))]
            elif r < 0.80 and cand:
                i = rng.randrange(len(cand))
                cand[i] -= rng.randint(-400, 400)
            elif r < 0.92 and cand:
                # shift a whole contiguous block
                cur_sorted = sorted(cand)
                j = rng.randrange(len(cur_sorted))
                w = rng.randint(1, max(1, len(cur_sorted) // 10))
                shift = rng.randint(-300, 300)
                for k in range(j, min(j + w, len(cur_sorted))):
                    cur_sorted[k] += shift
                cand = cur_sorted
            else:
                cand.append(rng.randint(lo, hi))
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 2:
                continue
            s = _score(cand)
            if s >= cs or rng.random() < math.exp((s - cs) / max(T, 1e-9)):
                cur, cs = cand, s
                if s > bls:
                    bl, bls = cand[:], s
        return bl, bls

    idx = 0
    while time.time() < deadline:
        if idx < len(seeds):
            base = seeds[idx]
            idx += 1
        else:
            n = rng.choice([100, 200, 400, 800, 1600])
            base = sorted(set(rng.randint(-10 ** 6, 10 ** 6) for _ in range(n)))
        t_end = min(deadline, time.time() + 12)
        b, bs = anneal(base, t_end)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END

