# EVOLVE-BLOCK-START
"""Deterministic sweep of block-product spacings maximizing the true log-ratio."""
import math
import time

import numpy as np


def _fast_score(a):
    arr = np.array(sorted(set(a)), dtype=np.int64)
    n = len(arr)
    if n < 2:
        return 0.0
    nd = len(np.unique(arr[:, None] - arr[None, :]))
    ns = len(np.unique(arr[:, None] + arr[None, :]))
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0

    bases = []
    for p in [29, 53, 101, 211, 401, 809, 1601]:
        B = _bose_chowla(p)
        bases.append(B)

    def consider(a):
        nonlocal best, best_score
        a = sorted(set(a))
        if len(a) < 3 or len(a) > 4000:
            return
        sc = _fast_score(a)
        if sc > best_score:
            best_score, best = sc, a[:]

    # Sweep block-product construction: B (Sidon) tiled k times with spacing M.
    for B in bases:
        nb = len(B)
        lo, hi = min(B), max(B)
        spread = hi - lo
        baseM = spread + 1
        for k in range(2, 9):
            n = k * nb
            if n > 4000 or n < 10:
                continue
            # sweep M from very tight to wide, fine near sum-collision regime
            Ms = set()
            for mult in [0.02, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8,
                         0.9, 1.0, 1.1, 1.25, 1.5, 2.0, 3.0]:
                Ms.add(max(1, int(baseM * mult)))
            # also tight spacings near the intra-block width itself
            for m in [spread, spread // 2, spread // 3, spread // 4,
                      spread // 5, spread // 6, spread // 8, spread // 10]:
                if m >= 1:
                    Ms.add(m)
            for M in Ms:
                consider(_build(B, k, M))

    # Greedy refinement: try shifting the whole set / small offsets won't help
    # ratio much, but try adding one element to fill differences cheaply.
    if best is not None:
        cur = best[:]
        cs = best_score
        improved = True
        while improved and time.time() < deadline:
            improved = False
            arr = np.array(cur, dtype=np.int64)
            # candidate new elements: pairwise sums/differences of a sample
            sample = cur if len(cur) <= 60 else [
                cur[i] for i in np.random.default_rng(0).choice(
                    len(cur), 60, replace=False)]
            cands = set()
            for i in range(len(sample)):
                for j in range(i + 1, len(sample)):
                    cands.add(sample[i] + sample[j])
                    cands.add(sample[i] - sample[j])
            for c in cands:
                if c in cur or len(cur) >= 4000:
                    continue
                trial = sorted(set(cur + [c]))
                sc = _fast_score(trial)
                if sc > cs:
                    cs, cur = sc, trial
                    improved = True
                    if cs > best_score:
                        best_score, best = cs, cur[:]
                    break
        if cs > best_score:
            best_score, best = cs, cur[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
