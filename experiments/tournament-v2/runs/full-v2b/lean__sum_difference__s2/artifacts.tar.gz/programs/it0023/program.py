# EVOLVE-BLOCK-START
"""Seeded search: Bose-Chowla Sidon seeds + hill climbing on true log-ratio."""
import math
import random
import time

import numpy as np


def _score_components(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0, n
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return math.log(len(diffs)) / math.log(len(sums)), len(diffs), len(sums), n


def _score(a):
    s, _, _, _ = _score_components(a)
    n = len(set(a))
    if n < 2:
        return 0.0
    return s + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _fast_counts(a):
    arr = np.array(a, dtype=np.int64)
    if arr.size < 2:
        return 0, 0
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0
    rng = random.Random(987654321)

    # Candidate seed sizes
    primes = [p for p in [101, 211, 401, 809, 1601, 3203] if p <= 4000]

    def consider(a):
        nonlocal best, best_score
        a = sorted(set(a))
        if len(a) < 2:
            return
        s = _score(a)
        if s > best_score:
            best_score, best = s, a[:]

    # Phase 1: evaluate Bose-Chowla seeds directly
    for p in primes:
        try:
            consider(_bose_chowla(p))
        except Exception:
            pass

    # Phase 2: greedy augmentation on top of best seeds
    def augment(base, budget_end):
        cur = sorted(set(base))
        cd, cs = _fast_counts(cur)
        if cs < 2:
            return cur
        cur_score = math.log(cd) / math.log(cs)
        improved = True
        while improved and time.time() < budget_end:
            improved = False
            # try adding elements near existing ones
            arr = np.array(cur, dtype=np.int64)
            span = int(arr.max() - arr.min()) if arr.size else 1
            for _ in range(30):
                if time.time() >= budget_end:
                    break
                base_pt = rng.choice(cur)
                delta = rng.randint(-max(1, span // 4), max(1, span // 4))
                cand = sorted(set(cur + [base_pt + delta]))
                if len(cand) > 4000 or len(cand) == len(cur):
                    continue
                nd, ns = _fast_counts(cand)
                if ns < 2:
                    continue
                sc = math.log(nd) / math.log(ns)
                if sc > cur_score + 1e-12:
                    cur = cand
                    cd, cs, cur_score = nd, ns, sc
                    improved = True
                    break
        return cur

    # Build a strong seed: Bose-Chowla unioned with a scaled/negated copy
    seeds = []
    for p in primes:
        if p >= 101:
            try:
                B = _bose_chowla(p)
                seeds.append(B)
                M = max(B) * 2 + 10
                seeds.append([x for x in B] + [M - x for x in B])
            except Exception:
                pass

    for s in seeds:
        if time.time() >= deadline - 15:
            break
        res = augment(s, min(deadline - 10, time.time() + 15))
        consider(res)

    # Phase 3: local search / hill climb on the true ratio with insert/delete
    cur = best[:] if best else [rng.randint(0, 10 ** 6) for _ in range(50)]
    arrive = time.time() + 5
    while time.time() < arrive and len(cur) < 4000:
        cand = sorted(set(cur + [rng.randint(-10 ** 6, 10 ** 6)]))
        nd, ns = _fast_counts(cand)
        if ns >= 2 and math.log(nd) / math.log(ns) >= (math.log(_fast_counts(cur)[0]) / math.log(max(2, _fast_counts(cur)[1]))):
            cur = cand
    consider(cur)

    cd, cs = _fast_counts(cur)
    cur_score = math.log(cd) / math.log(cs) if cs >= 2 else 0.0
    step = 0
    while time.time() < deadline and step < 200000:
        step += 1
        cand = cur[:]
        op = rng.random()
        if op < 0.55 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-100, 100)
        elif op < 0.80 and len(cand) < 4000:
            cand.append(rng.randint(-5000, 5000))
        elif len(cand) > 4:
            i = rng.randrange(len(cand))
            del cand[i]
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        nd, ns = _fast_counts(cand)
        if ns < 2:
            continue
        sc = math.log(nd) / math.log(ns)
        if sc >= cur_score:
            cur, cd, cs, cur_score = cand, nd, ns, sc
            ns_n = len(cur)
            sc_bonus = sc + (1 - 1 / ns_n) / 100
            if sc_bonus > best_score:
                best_score, best = sc_bonus, cur[:]

    return sorted(set(best)) if best else []
# EVOLVE-BLOCK-END
