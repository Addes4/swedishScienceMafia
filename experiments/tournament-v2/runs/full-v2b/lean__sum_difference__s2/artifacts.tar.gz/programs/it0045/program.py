# EVOLVE-BLOCK-START
"""Block-cluster over Bose-Chowla Sidon set with T-multiple spacing.

A = { k*M*b + t : b in B, t in [0,T) }

B Sidon (Bose-Chowla) => |B-B| ~ |B|^2 (large differences).
Choosing M = multiple of T makes block-offsets align so that
A+A collapses onto ~ (|B+B|)*(2T-1) values while A-A keeps
~ (|B-B|)*(2T-1) values, maximizing log|A-A|/log|A+A|.
"""
import math
import time

import numpy as np

MAXN = 4000
LIMIT = 10 ** 15


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _score_arr(arr):
    n = len(arr)
    if n < 2:
        return 0.0, 0, 0
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    nd, ns = len(diffs), len(sums)
    if nd < 2 or ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    best_info = (0, 0)

    primes = [17, 29, 37, 53, 67, 101, 127, 211, 257, 401, 509, 809, 1021, 2039]
    ts = [1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32, 40, 50, 64, 80, 100]

    tried = 0
    for p in primes:
        if time.time() > deadline:
            break
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        rngb = hi - lo
        for T in ts:
            if nb * T > MAXN:
                continue
            if nb * T < 20:
                continue
            k = nb * T  # scale factor for B so coordinates spread nicely
            for mult_num, mult_den in [(1, 1), (1, 2), (3, 4), (5, 4), (3, 2), (2, 1),
                                       (5, 1), (9, 1), (17, 1)]:
                if time.time() > deadline:
                    break
                # M is a multiple of T; make offsets per block be exactly [0,T)
                Mbase = rngb + 1
                M = Mbase * mult_num // mult_den
                if M < T:
                    M = T
                # snap M up to a multiple of T so sums align in residue classes
                M = ((M + T - 1) // T) * T
                if M < 1:
                    M = T
                off = M * k
                A = []
                for b in B:
                    base = b * off
                    for t in range(T):
                        A.append(base + t)
                arr = np.array(A, dtype=np.int64)
                if np.max(np.abs(arr)) > LIMIT:
                    continue
                tried += 1
                sc, nd, ns = _score_arr(arr)
                if sc > best_score:
                    best_score = sc
                    best = A[:]
                    best_info = (nd, ns)

    if best is None:
        return [0, 1]

    # Light greedy tail: try removing elements that don't change sums much
    # but keep differences large (cheap, bounded).
    cur = best[:]
    cs = best_score
    end = min(deadline, time.time() + 8)
    improved = True
    while improved and time.time() < end:
        improved = False
        curset = set(cur)
        # try removing each element; keep removal if score improves
        for i in range(len(cur) - 1, -1, -1):
            if time.time() > end:
                break
            cand = cur[:i] + cur[i + 1:]
            if len(cand) < 3:
                continue
            carr = np.array(cand, dtype=np.int64)
            if np.max(np.abs(carr)) > LIMIT:
                continue
            sc, nd, ns = _score_arr(carr)
            if sc > cs:
                cur, cs = cand, sc
                improved = True

    return sorted(set(cur))
# EVOLVE-BLOCK-END

