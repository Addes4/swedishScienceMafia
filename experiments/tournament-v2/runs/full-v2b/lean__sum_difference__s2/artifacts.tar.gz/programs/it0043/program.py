# EVOLVE-BLOCK-START
"""Thickened Sidon set: A = B + [0,k) gives many distinct differences and few sums."""
import math
import time
import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _thicken(B, k):
    """A = union_{b in B} [b, b+k). Small k -> few sums, many diffs."""
    A = set()
    for b in B:
        for j in range(k):
            A.add(b + j)
    return sorted(A)


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0

    # candidate Sidon bases
    primelist = [13, 17, 29, 37, 53, 101, 149, 211, 307, 401]

    seeds = []
    for p in primelist:
        B = _bose_chowla(p)
        nb = len(B)
        for k in range(1, 16):
            n = nb * k
            if n < 20 or n > 4000:
                continue
            # rescale B by a large factor so thickened copies don't overlap
            spread = max(B) - min(B)
            M = spread + k + 1
            Bs = [b * M for b in B]
            A = _thicken(Bs, k)
            if len(A) <= 4000:
                seeds.append(A)

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    # deterministic greedy refinement: try removing elements that reduce |A+A|
    def refine(base, tlimit):
        cur = base[:]
        cs = _score(cur)
        improved = True
        while improved and time.time() < tlimit:
            improved = False
            arr = np.array(cur, dtype=np.int64)
            # try removing one element
            for i in range(len(cur)):
                cand = cur[:i] + cur[i + 1:]
                s = _score(cand)
                if s > cs:
                    cur, cs = cand, s
                    improved = True
                    break
            if not improved and time.time() < tlimit and len(cur) < 4000:
                # try adding an element near a random existing one
                for _ in range(30):
                    base_el = cur[np.random.randint(len(cur))]
                    for delta in [1, -1, 2, -2, 3, -3]:
                        v = base_el + delta
                        if v in cur:
                            continue
                        cand = sorted(set(cur + [v]))
                        if len(cand) > 4000:
                            continue
                        s = _score(cand)
                        if s > cs:
                            cur, cs = cand, s
                            improved = True
                            break
                    if improved:
                        break
        return cur, cs

    for s in seeds:
        if time.time() > deadline:
            break
        r, rs = refine(s, min(deadline, time.time() + 5))
        if rs > best_score:
            best_score, best = rs, r[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
