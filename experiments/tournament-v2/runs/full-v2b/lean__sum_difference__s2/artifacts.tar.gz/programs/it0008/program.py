# EVOLVE-BLOCK-START
"""Structured product-set construction: A = {i*M + 2*j} maximises |A-A|/|A+A| ratio."""
import math


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(n, k):
    """A = {i*M + 2*j : 0<=i<n, 0<=j<k}, M = 2*(2k-1)."""
    M = 2 * (2 * k - 1)
    A = []
    for i in range(n):
        base = i * M
        for j in range(k):
            A.append(base + 2 * j)
    return A


def solve():
    best = None
    best_score = -1.0
    # Try many (n,k) splits so that n*k <= 4000 and ratio is maximised.
    max_size = 4000
    candidates = []
    for k in range(2, 60):
        for n in range(2, max_size // k + 1):
            size = n * k
            if size < 4:
                continue
            candidates.append((n, k, size))
    # Score approximately (analytically) then pick best few exactly.
    approx = []
    for n, k, size in candidates:
        # |A+A| ~ (2n-1)*(2k-1), |A-A| ~ (2n-1)*(2k-1) but differences larger range
        sums = (2 * n - 1) * (2 * k - 1)
        # distinct differences: values (i1-i2)*M + 2*(j1-j2)
        # M=2(2k-1); j-difference range 2(k-1); so spacing 2 plus j-range covers [0, M)
        # distinct = (2n-1)*(2k-1) approximately as well but let's be safe
        diffs = (2 * n - 1) * (2 * k - 1)
        if sums <= 1 or diffs <= 1:
            continue
        s = math.log(diffs) / math.log(sums) + (1 - 1 / size) / 100
        approx.append((s, n, k, size))
    approx.sort(reverse=True)
    for _, n, k, size in approx[:25]:
        A = _build(n, k)
        sc = _score(A)
        if sc > best_score:
            best_score = sc
            best = A
    if best is None:
        best = [0, 1, 2, 3]
    return sorted(set(best))
# EVOLVE-BLOCK-END
