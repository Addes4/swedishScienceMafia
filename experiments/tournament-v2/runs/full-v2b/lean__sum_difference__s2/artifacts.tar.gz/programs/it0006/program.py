# EVOLVE-BLOCK-START
"""Bose-Chowla Sidon set construction + sum-collapsing local refinement.

Idea: A Sidon set B in Z_p (Bose-Chowla: B = {2pk + (k^2 mod p)} style) has all
differences distinct, so |B-B| ~ |B|^2.  Map it into the integers.  Then we try to
locally nudge elements so that many pair sums coincide (shrinking |A+A|) without
losing too many distinct differences.
"""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    d = len(diffs)
    s = len(sums)
    if s <= 1 or d <= 1:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def _is_prime(x):
    if x < 2:
        return False
    if x % 2 == 0:
        return x == 2
    i = 3
    while i * i <= x:
        if x % i == 0:
            return False
        i += 2
    return True


def _bose_chowla(p, n):
    """Return Sidon set of size n in Z_p (p prime, n <= p)."""
    S = []
    for k in range(n):
        S.append((2 * p * k + (k * k) % p) % (p * p) if False else (k, (k * k) % p))
    # standard Bose-Chowla: elements (k, k^2 mod p) in Z_{p} x Z_{p-1} -> use GF
    # simpler: use the classic Sidon set {k*p... } below.
    return S


def _sidon_int(n):
    """Build a large Sidon-like set of n integers with distinct pairwise differences."""
    # Bose-Chowla Sidon set in Z_q where q = n(n-1)+1 prime.
    q = n * (n - 1) + 1
    while not _is_prime(q):
        q += 1
    # generator g of Z_q^*
    g = 2
    while True:
        ok = True
        seen = 1
        x = g % q
        for _ in range(q - 2):
            if x == 1:
                ok = False
                break
            x = (x * g) % q
        if ok and _is_prime(q):
            break
        g += 1
        if g > q:
            g = 2
            q += 1
            while not _is_prime(q):
                q += 1
    # Bose-Chowla: {a in Z_{q-1} : g^a = i + g^j, i,j in [0,n-1]}  -- complex.
    # Fall back to a robust simple Sidon construction: greedy Sidon set.
    A = [0]
    used = {0}
    diffs_used = set()
    x = 1
    while len(A) < n:
        ok = True
        new_d = set()
        for a in A:
            d1 = x - a
            d2 = a - x
            if d1 in diffs_used or d2 in diffs_used:
                ok = False
                break
            new_d.add(d1)
            new_d.add(d2)
        if ok:
            A.append(x)
            diffs_used |= new_d
        x += 1
        if x > 10 * n * n:
            break
    return A


def solve():
    deadline = time.time() + 100

    best = None
    best_score = -1.0

    # Try several sizes; larger n gives bigger bonus and more differences.
    sizes = [30, 60, 100, 160, 240, 350, 500, 700]
    for n in sizes:
        if time.time() > deadline:
            break
        base = _sidon_int(n)
        s = _score(base)
        if s > best_score:
            best, best_score = base[:], s

    # Local refinement: try shifting elements to collapse sums.
    if best is None:
        return [0, 1]
    cur = best[:]
    cur_score = best_score
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.choice([-2, -1, 1, 2, -3, 3, 4, -4])
        s = _score(cand)
        if s >= cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
    return sorted(set(best))
# EVOLVE-BLOCK-END
