# EVOLVE-BLOCK-START
"""Geometric dilations of a Sidon set: many differences, few sums."""
import math
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    primes = [17, 29, 53, 101, 211, 401, 809]

    for p in primes:
        B = _bose_chowla(p)
        nb = len(B)
        # dilations: geometric with factor c
        for k in range(2, 9):
            if k * nb > 4000:
                continue
            if k * nb < 20:
                continue
            for c in [2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20, 32]:
                A = []
                scale = 1
                for i in range(k):
                    for b in B:
                        A.append(scale * b)
                    scale *= c
                if max(abs(x) for x in A) > 10 ** 15:
                    continue
                sc = _score(A)
                if sc > best_score:
                    best_score, best = sc, sorted(set(A))

    if best is None:
        best = [0, 1]
        best_score = 0.0

    # greedy polish: try to collapse sums by appending / shifting elements
    improve = True
    while improve and time.time() < deadline:
        improve = False
        cur = best[:]
        cs = best_score
        curset = set(cur)
        base_scale = max(abs(x) for x in cur) if cur else 1
        # trial moves
        moves = []
        for i in range(len(cur)):
            for delta in (1, -1, 2, -2):
                cand = cur[:]
                cand[i] += delta
                moves.append(cand)
        # random additions
        for _ in range(200):
            if len(cur) < 4000:
                cand = cur + [int(np.random.randint(-base_scale, base_scale))]
                moves.append(cand)
        for cand in moves:
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s = _score(cand)
            if s > cs:
                best, best_score = cand, s
                cur, cs = cand, s
                improve = True

    return sorted(set(best))
# EVOLVE-BLOCK-END

