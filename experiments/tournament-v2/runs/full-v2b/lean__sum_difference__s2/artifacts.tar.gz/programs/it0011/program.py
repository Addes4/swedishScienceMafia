# EVOLVE-BLOCK-START
"""Strong local search on integer sets: large |A-A|, small |A+A|, maximizing
log|A-A|/log|A+A| with a size bonus."""
import math
import random
import time
import numpy as np


def _costs(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    if a.size < 2:
        return 0, 0
    n = a.size
    # differences
    d = a[:, None] - a[None, :]
    nd = np.unique(d).size
    s = a[:, None] + a[None, :]
    ns = np.unique(s).size
    return int(nd), int(ns)


def _score_from_counts(nd, ns, n):
    if ns <= 1 or nd <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1.0 / n) / 100.0


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    nd, ns = _costs(a)
    return _score_from_counts(nd, ns, a.size)


def solve():
    random.seed(1234567)
    np.random.seed(1234567)

    best = None
    best_score = -1.0
    deadline = time.time() + 115

    # multiple restarts with varying size and spread
    restarts = 0
    while time.time() < deadline:
        restarts += 1
        n = random.randint(12, 40)
        spread = random.choice([n, 2 * n, 3 * n, 5 * n, 10 * n])
        cur = sorted(random.sample(range(0, spread + 1), min(n, spread + 1)))
        cur = sorted(set(cur))
        cur_nd, cur_ns = _costs(cur)
        cur_score = _score_from_counts(cur_nd, cur_ns, len(cur))

        T = 0.05
        inner_deadline = time.time() + min(20.0, deadline - time.time())
        step = 0
        while time.time() < inner_deadline:
            step += 1
            cand = cur[:]
            op = random.random()
            if op < 0.5 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.choice([-3, -2, -1, 1, 2, 3])
                cand = sorted(set(cand))
            elif op < 0.75:
                # add
                if cand:
                    base = random.choice(cand)
                    cand.append(base + random.randint(1, max(2, spread)))
                    cand = sorted(set(cand))
            else:
                # remove
                if len(cand) > 3:
                    cand.pop(random.randrange(len(cand)))
            if not cand:
                continue
            cand = sorted(set(cand))
            if len(cand) > 80:
                continue
            cnd, cns = _costs(cand)
            cs = _score_from_counts(cnd, cns, len(cand))
            if cs >= cur_score or random.random() < T:
                cur, cur_nd, cur_ns, cur_score = cand, cnd, cns, cs
            if cur_score > best_score:
                best_score = cur_score
                best = cur[:]
        # cool
        T *= 0.9

    return [int(x) for x in (best if best else [7, 15, 18, 22, -3, -2])]
# EVOLVE-BLOCK-END

