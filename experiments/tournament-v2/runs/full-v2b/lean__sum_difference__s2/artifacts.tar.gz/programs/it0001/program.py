# EVOLVE-BLOCK-START
"""Construct a set with large difference set and small sum set using a multi-scale
"block" construction, then refine by local search."""
import math
import random
import time


def _stats(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100, nd, ns


def _ratio(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns)


def _build_block(base, scales):
    """A = sum_i scale_i * B : differences rich, sums structured."""
    A = []
    for s in scales:
        for b in base:
            A.append(s * b)
    return A


def _greedy_grow(A, tries=400):
    """Grow A by adding elements that maximise the ratio."""
    A = list(set(A))
    cur = _ratio(A)
    pool = set(A)
    for _ in range(tries):
        best_add = None
        best_r = cur
        m = max(abs(x) for x in A) if A else 1
        for _ in range(30):
            cand = random.randint(-3 * m, 3 * m)
            if cand in pool:
                continue
            test = A + [cand]
            r = _ratio(test)
            if r > best_r:
                best_r = r
                best_add = cand
        if best_add is None:
            break
        A.append(best_add)
        pool.add(best_add)
        cur = best_r
    return A


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    best = None
    best_score = -1.0
    best_ratio = -1.0

    # Base blocks: small dense sets whose difference set saturates (|D| near |A|^2)
    # but whose sum set is comparatively small, placed at widely separated scales.
    base_candidates = [
        [0, 1, 2, 4, 8, 16],
        [0, 1, 3, 4, 9, 10, 12, 13],
        [0, 1, 2, 3, 7, 8, 16, 24],
        [0, 1, 2, 4, 8, 13, 21],
    ]
    scale_patterns = [
        [1, 32, 1024, 32768],
        [1, 64, 4096, 262144],
        [1, 100, 10000, 1000000],
        [1, 128, 16384],
        [1, 200, 40000, 8000000],
    ]

    random.seed(12345)
    deadline = time.time() + 60

    for base in base_candidates:
        for scales in scale_patterns:
            A = _build_block(base, scales)
            A = list(set(A))
            if len(A) < 2:
                continue
            if len(A) > 4000:
                continue
            # cap magnitudes
            if max(abs(x) for x in A) > 10 ** 15:
                continue
            s, _, _ = _stats(A)
            if s > best_score:
                best_score = s
                best = A[:]
                best_ratio = _ratio(A)

    # Greedy growth from the best structural seed.
    if best is not None and time.time() < deadline:
        grown = _greedy_grow(best, tries=200)
        s, _, _ = _stats(grown)
        if s > best_score and max(abs(x) for x in grown) <= 10 ** 15:
            best_score = s
            best = grown

    # Local search refinement.
    if best is not None:
        cur = best[:]
        deadline2 = time.time() + 40
        while time.time() < deadline2:
            cand = cur[:]
            i = random.randrange(len(cand))
            cand[i] += random.randint(-5, 5)
            cand = list(set(cand))
            if len(cand) < 2:
                continue
            if max(abs(x) for x in cand) > 10 ** 15:
                continue
            s, _, _ = _stats(cand)
            if s >= best_score:
                best_score = s
                best = cand[:]
                cur = cand
            elif random.random() < 0.2:
                cur = best[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
