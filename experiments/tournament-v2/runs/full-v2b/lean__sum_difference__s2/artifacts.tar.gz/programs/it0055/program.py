# EVOLVE-BLOCK-START
"""Two-scale Sidon cluster: rich differences, clustered sums."""
import math
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    if len(arr) > 3000:
        # subsample-safe: still full computation but memory bounded
        pass
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return sorted(pow(g, i, p) for i in range(1, p))


def _levels(X):
    """Return list of integer levels implementing a small additive-structured set X."""
    return list(X)


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0

    primes = [29, 53, 101, 197, 401, 797, 1601]
    Bcache = {p: _bose_chowla(p) for p in primes}

    # candidate level patterns: small additive sets with lots of sum collisions
    level_patterns = []
    for t in range(2, 8):
        level_patterns.append(list(range(t)))                          # arithmetic
        level_patterns.append([2 * i for i in range(t)])               # even-spaced
        level_patterns.append([i * i for i in range(t)])               # squares
        level_patterns.append([3 * i for i in range(t)])               # 3-step AP
        level_patterns.append([0] + [2 ** i for i in range(1, t)])     # geometric-ish
        level_patterns.append([0] + list(range(1, t)))                 # contiguous

    for p in primes:
        B = Bcache[p]
        nb = len(B)
        lo, hi = B[0], B[-1]
        spread = hi - lo

        for X in level_patterns:
            nx = len(X)
            total = nb * nx
            if total > 4000 or total < 20:
                continue
            xr = max(X) - min(X)
            if xr == 0:
                continue
            # S must exceed spread so that distinct levels (over B) are separated,
            # but tight enough that cross-level sums overlap modulo small structure.
            for S in (spread + 1, spread + xr, (spread // max(1, xr)) + 1,
                      spread, (spread + xr) // 2, spread // 2,
                      spread + 2 * xr, 2 * spread):
                if S < 2:
                    continue
                A = []
                for x in X:
                    off = x * S
                    for b in B:
                        A.append(off + b)
                A = sorted(set(A))
                if len(A) > 4000:
                    continue
                sc = _score(A)
                if sc > best_score:
                    best_score, best = sc, A[:]
                        if time.time() > deadline:
                            return sorted(set(best))

    # fine local refinement around the best configuration using small perturbations
    if best is None:
        return []

    best = sorted(set(best))
    cur = best[:]
    cs = _score(cur)
    step = 0
    import random
    rng = random.Random(12345)
    while time.time() < deadline and step < 20000:
        step += 1
        cand = cur[:]
        r = rng.random()
        if r < 0.4:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-1, 1])
        elif r < 0.7:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-3, 3)
        elif r < 0.85 and len(cand) > 5:
            del cand[rng.randrange(len(cand))]
        else:
            cand.append(rng.choice(cand) + rng.choice([-1, 1, 2, -2]))
        cand = sorted(set(cand))
        if len(cand) > 4000 or len(cand) < 3:
            continue
        s = _score(cand)
        if s >= cs:
            cur, cs = cand, s
            if s > best_score:
                best_score, best = s, cand[:]
    return sorted(set(best))
# EVOLVE-BLOCK-END

