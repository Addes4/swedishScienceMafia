# EVOLVE-BLOCK-START
"""Union of shifted Bose-Chowla Sidon sets: rich differences, clustered sums."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    n = len(arr)
    if n * n > 4000 * 4000:
        # fall back to chunked unique to bound memory
        diffs = set()
        sums = set()
        for i in range(0, n, 256):
            blk = arr[i:i + 256]
            diffs.update(np.unique(blk[:, None] - arr[None, :]).tolist())
            sums.update(np.unique(blk[:, None] + arr[None, :]).tolist())
        return len(diffs), len(sums)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _union(B, T, d):
    S = set()
    for t in range(T):
        off = t * d
        for b in B:
            S.add(off + b)
    return sorted(S)


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(2024)

    # Cache Bose-Chowla sets
    bc = {}
    for p in [53, 101, 211, 401, 809, 1601]:
        bc[p] = _bose_chowla(p)

    seeds = []
    for p in [53, 101, 211, 401]:
        B = bc[p]
        lo, hi = min(B), max(B)
        rngB = hi - lo
        nb = len(B)
        for T in [2, 3, 4, 5, 6, 8, 10, 12]:
            if T * nb > 4000:
                continue
            for frac in [0.25, 0.4, 0.5, 0.6, 0.75, 1.0, 1.5, 2.0]:
                d = max(2, int(rngB * frac))
                seeds.append(_union(B, T, d))
        # also small absolute steps
        for T in [3, 5, 8]:
            if T * nb > 4000:
                continue
            for d in [p, p + 1, 2 * p, 3 * p, 5 * p]:
                seeds.append(_union(B, T, d))

    # score seeds
    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    # reference sets for a few p also collapsed to a compact base range
    for p in [101, 211, 401]:
        B = bc[p]
        lo = min(B)
        B2 = [b - lo for b in B]
        rngB = max(B2)
        nb = len(B2)
        for T in [3, 4, 5, 6, 8]:
            if T * nb > 4000:
                continue
            for frac in [0.5, 0.75, 1.0, 1.25]:
                d = max(2, int(rngB * frac))
                seeds.append(_union(B2, T, d))

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    def local_opt(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        best_local, best_local_s = cur[:], cs
        stall = 0
        step = 0
        while time.time() < tlimit and step < 40000:
            step += 1
            cand = cur[:]
            op = rng.random()
            if op < 0.3 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-2, 2)
            elif op < 0.5 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-20, 20)
            elif op < 0.65 and len(cand) > 4:
                i = rng.randrange(len(cand))
                del cand[i]
            elif op < 0.8:
                # add a sum-colliding element: a + a' - a''
                if len(cand) >= 3:
                    a1 = rng.choice(cand)
                    a2 = rng.choice(cand)
                    a3 = rng.choice(cand)
                    cand.append(a1 + a2 - a3)
            else:
                if cand:
                    v = rng.choice(cand) + rng.choice([-1, 1]) * rng.randint(1, 50)
                    cand.append(v)
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_local_s:
                    best_local, best_local_s = cand[:], s
                    stall = 0
                else:
                    stall += 1
            else:
                stall += 1
            if stall > 4000:
                break
        return best_local, best_local_s

    # sort seeds by score, refine the best ones
    scored = []
    for s in seeds:
        scored.append((_score(s), s))
    scored.sort(key=lambda x: -x[0])

    idx = 0
    nseeds = len(scored)
    while time.time() < deadline:
        if idx < nseeds:
            base = scored[idx][1]
            idx += 1
        else:
            if rng.random() < 0.6 and scored:
                base = [x + rng.randint(-2, 2) for x in rng.choice(scored[:20])[1]]
            else:
                n = rng.randint(50, 400)
                base = [rng.randint(-10 ** 6, 10 ** 6) for _ in range(n)]
            base = sorted(set(base))
        tlimit = min(deadline, time.time() + 8)
        b, bs = local_opt(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
