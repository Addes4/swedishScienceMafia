# EVOLVE-BLOCK-START
"""Strong simulated-annealing over the true log-ratio, seeded by block-product Sidon sets."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _seed_sets():
    seeds = []
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        nbf = max(B)
        for k in [2, 3, 4, 5, 6, 8, 10, 14, 20]:
            if k * nb > 4000 or k * nb < 20:
                continue
            M = nbf * (k + 2) + 10
            A = []
            for i in range(k):
                off = i * M
                for b in B:
                    A.append(off + b)
            seeds.append(sorted(set(A)))
    return seeds


def _sa(base, deadline, rng, n_target):
    cur = sorted(set(base))
    # pad/trim to a reasonable working size
    while len(cur) > n_target:
        del cur[rng.randrange(len(cur))]
    while len(cur) < n_target:
        cur.append(rng.randint(-50000, 50000))
    cur = sorted(set(cur))
    cs = _score(cur)
    best, bs = cur[:], cs
    temp = 0.05
    it = 0
    span = max(50, (max(cur) - min(cur)) if len(cur) > 1 else 50)
    while time.time() < deadline:
        it += 1
        if it % 200 == 0:
            temp *= 0.995
        cand = cur[:]
        op = rng.random()
        if op < 0.55 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-span // 4 - 1, span // 4 + 1)
        elif op < 0.75 and cand:
            # duplicate a shifted element to force sum collisions
            cand.append(rng.choice(cand) + rng.randint(-span // 8 - 1, span // 8 + 1))
        elif op < 0.9 and len(cand) > 4:
            del cand[rng.randrange(len(cand))]
        else:
            cand.append(rng.randint(-span, span))
        cand = sorted(set(cand))
        if len(cand) < 4 or len(cand) > 4000:
            continue
        s = _score(cand)
        if s >= cs or rng.random() < math.exp((s - cs) / max(temp, 1e-9)):
            cur, cs = cand, s
            if s > bs:
                best, bs = cand[:], s
    return best, bs


def solve():
    deadline = time.time() + 112
    rng = random.Random(20240607)

    best = None
    best_score = -1.0

    for s in _seed_sets():
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    # also try plain Bose-Chowla sets and small random starts
    for p in [53, 101, 211, 401]:
        B = sorted(_bose_chowla(p))
        sc = _score(B)
        if sc > best_score:
            best_score, best = sc, B[:]

    sizes = [40, 80, 120, 160, 220, 300, 400]
    round_idx = 0
    while time.time() < deadline:
        if round_idx < len(sizes):
            n_target = sizes[round_idx]
            round_idx += 1
        else:
            n_target = rng.choice(sizes)
        if best is not None and rng.random() < 0.7:
            base = best[:]
        else:
            base = sorted(set(rng.randint(-100000, 100000) for _ in range(n_target)))
        tlimit = min(deadline, time.time() + 14)
        b, bs = _sa(base, tlimit, rng, n_target)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END

