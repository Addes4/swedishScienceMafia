# EVOLVE-BLOCK-START
"""Dilated-Sidon union seeds + vectorized counting + local search."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(sorted(set(a)), dtype=np.int64)
    n = len(arr)
    if n == 0:
        return 0, 0
    # batch to bound memory
    ds = np.empty(n * n, dtype=np.int64)
    ss = np.empty(n * n, dtype=np.int64)
    if n <= 2000:
        d = arr[:, None] - arr[None, :]
        s = arr[:, None] + arr[None, :]
        return len(np.unique(d)), len(np.unique(s))
    # chunked
    diffs = []
    sums = []
    step = max(1, 4000000 // n)
    for i in range(0, n, step):
        blk = arr[i:i + step]
        diffs.append(np.unique(blk[:, None] - arr[None, :]))
        sums.append(np.unique(blk[:, None] + arr[None, :]))
    nd = len(np.unique(np.concatenate(diffs)))
    ns = len(np.unique(np.concatenate(sums)))
    return nd, ns


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(123456789)

    seeds = []

    # Dilated-Sidon union construction: A = B ∪ (s*B + t)
    # scaling makes some sum collisions while differences remain rich
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        spread = max(B) - min(B)
        for s in [2, 3, 4, 5]:
            for t in [0, 1, s, spread + 1, -spread]:
                A = list(B) + [s * b + t for b in B]
                if 3 <= len(A) <= 4000:
                    seeds.append(A)

    # Block construction (kept from before)
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        spread = max(B) - min(B)
        baseM = spread + 1
        for k in [2, 3, 4, 5, 6, 7, 8]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for mult in [0.05, 0.15, 0.3, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0]:
                M = max(2, int(baseM * mult))
                A = []
                for i in range(k):
                    off = i * M
                    for b in B:
                        A.append(off + b)
                seeds.append(A)

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    def local_opt(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        best_local, best_local_s = cur[:], cs
        step = 0
        stall = 0
        while time.time() < tlimit and step < 80000:
            step += 1
            cand = cur[:]
            op = rng.random()
            if op < 0.20 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-20, 20)
            elif op < 0.35 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-3, 3)
            elif op < 0.48 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-1, 1]) * rng.randint(50, 3000)
            elif op < 0.60 and cand:
                cand = sorted(set(cand))
                if cand:
                    i = rng.randrange(len(cand))
                    cand[i] += rng.randint(-300, 300)
            elif op < 0.70 and len(cand) > 5:
                i = rng.randrange(len(cand))
                del cand[i]
            elif op < 0.82 and cand:
                base_el = rng.choice(cand)
                cand.append(base_el + rng.randint(-50, 50))
            elif op < 0.92 and len(cand) >= 2:
                a1 = rng.choice(cand)
                a2 = rng.choice(cand)
                cand.append(a1 + a2 - rng.choice(cand))
            else:
                cand.append(rng.randint(-5000, 5000))
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_local_s:
                    best_local, best_local_s = cand[:], s
                    stall = 0
                else:
                    stall += 1
            else:
                stall += 1
            if stall > 4000:
                break
        return best_local, best_local_s

    idx = 0
    nseeds = len(seeds)
    while time.time() < deadline:
        if idx < nseeds:
            base = seeds[idx]
            idx += 1
        else:
            if seeds and rng.random() < 0.7:
                base = [x + rng.randint(-20, 20) for x in rng.choice(seeds)]
            else:
                n = rng.randint(30, 300)
                base = [rng.randint(-10 ** 6, 10 ** 6) for _ in range(n)]
            base = sorted(set(base))
        tlimit = min(deadline, time.time() + 8)
        b, bs = local_opt(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
