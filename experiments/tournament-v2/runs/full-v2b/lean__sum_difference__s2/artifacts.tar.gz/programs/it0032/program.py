# EVOLVE-BLOCK-START
"""Block-product over Sidon set plus AP/sumset-small hybrid seeds with tuned sum-collision search."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def _hybrid_seed(B, k, M, dense_len, dense_gap, dense_start):
    """x-coord from Sidon B (sparse, big diffs), y-coord a near-AP dense set (small sumset)."""
    Y = [dense_start + j * dense_gap for j in range(dense_len)]
    A = []
    for i, b in enumerate(B[:k]):
        base = b * M
        for y in Y:
            A.append(base + y)
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(987654321)

    seeds = []
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        spread = max(B) - min(B)
        baseM = spread + 1
        for k in [2, 3, 4, 5, 6, 7, 8]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for mult in [0.05, 0.15, 0.3, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0]:
                M = max(2, int(baseM * mult))
                seeds.append(_build(B, k, M))

    for p in [53, 101, 211, 401]:
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        rngb = hi - lo
        for k in [2, 3, 4, 5, 6]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for M in [rngb, rngb + 1, rngb // 2, rngb // 3, rngb // 4]:
                if M < 2:
                    continue
                seeds.append(_build(B, k, M))

    # Hybrid seeds: Sidon x-coordinate + near-AP y-coordinate (small sumset).
    for p in [53, 101, 211, 401]:
        B = _bose_chowla(p)
        for k in [3, 4, 5, 6, 8, 10, 12, 16]:
            for dense_len in [4, 6, 8, 10, 12, 16, 20]:
                if k * dense_len > 4000:
                    continue
                # spacing so blocks are separated by a large multiplier
                for M in [p, 2 * p, 4 * p, 8 * p, 16 * p]:
                    for dense_gap in [1, 2, 3, 5, 8]:
                        # ensure y-range fits within M
                        if dense_len * dense_gap >= M:
                            continue
                        seeds.append(_hybrid_seed(B, k, M, dense_len, dense_gap, 0))

    # trim to keep seed list manageable
    if len(seeds) > 400:
        rng.shuffle(seeds)
        seeds = seeds[:400]

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    def local_opt(base, tlimit):
        cur = base[:]
        cs = _score(cur)
        best_local, best_local_s = cur[:], cs
        step = 0
        stall = 0
        while time.time() < tlimit and step < 80000:
            step += 1
            cand = cur[:]
            op = rng.random()
            if op < 0.15 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-20, 20)
            elif op < 0.25 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-3, 3)
            elif op < 0.35:
                if cand:
                    i = rng.randrange(len(cand))
                    cand[i] += rng.choice([-1, 1]) * rng.randint(50, 3000)
            elif op < 0.45:
                cand = sorted(set(cand))
                if cand:
                    i = rng.randrange(len(cand))
                    cand[i] += rng.randint(-300, 300)
            elif op < 0.53 and len(cand) > 5:
                i = rng.randrange(len(cand))
                del cand[i]
            elif op < 0.65:
                if cand:
                    base_el = rng.choice(cand)
                    cand.append(base_el + rng.randint(-50, 50))
            elif op < 0.75:
                if len(cand) >= 2:
                    a1 = rng.choice(cand)
                    a2 = rng.choice(cand)
                    cand.append(a1 + a2 - rng.choice(cand))
            elif op < 0.85:
                # shift a whole contiguous block uniformly (perturbs block offset)
                if len(cand) >= 4:
                    cand.sort()
                    i = rng.randrange(len(cand))
                    j = min(len(cand), i + rng.randint(2, 12))
                    shift = rng.choice([-1, 1]) * rng.randint(1, 20)
                    for t in range(i, j):
                        cand[t] += shift
            else:
                cand.append(rng.randint(-5000, 5000))
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_local_s:
                    best_local, best_local_s = cand[:], s
                    stall = 0
                else:
                    stall += 1
            else:
                stall += 1
            if stall > 5000:
                break
        return best_local, best_local_s

    idx = 0
    nseeds = len(seeds)
    while time.time() < deadline:
        if idx < nseeds:
            base = seeds[idx]
            idx += 1
        else:
            if rng.random() < 0.7 and seeds:
                base = [x + rng.randint(-20, 20) for x in rng.choice(seeds)]
            else:
                n = rng.randint(30, 300)
                base = [rng.randint(-10 ** 6, 10 ** 6) for _ in range(n)]
            base = sorted(set(base))
        tlimit = min(deadline, time.time() + 10)
        b, bs = local_opt(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
