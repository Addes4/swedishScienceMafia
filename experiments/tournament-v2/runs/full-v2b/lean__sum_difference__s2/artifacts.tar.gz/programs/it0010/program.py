# EVOLVE-BLOCK-START
"""Long multi-restart stochastic search for sets with many differences and few sums."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    d = len(diffs)
    s = len(sums)
    if s < 2:
        return -1.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def solve():
    random.seed(12345)
    deadline = time.time() + 115.0

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    seeds = [
        [7, 15, 18, 22, -3, -2],
        [0, 1, 3, 7, 12, 20, 30],
        [-1, 0, 2, 5, 9, 14],
        [1, 2, 4, 8, 16, 32, 64],
    ]

    restart = 0
    while time.time() < deadline:
        restart += 1
        # choose a restart configuration
        if random.random() < 0.5 and seeds:
            cur = random.choice(seeds)[:]
        else:
            n0 = random.randint(4, 14)
            rng = random.choice([8, 12, 20, 30, 50])
            cur = [random.randint(-rng, rng) for _ in range(n0)]
        cur = list(set(cur))
        cur_score = _score(cur)
        if cur_score > best_score:
            best, best_score = cur[:], cur_score

        T = 0.5
        stall = 0
        for _ in range(200000):
            if time.time() > deadline:
                break
            cand = cur[:]
            r = random.random()
            if r < 0.65 and cand:
                i = random.randrange(len(cand))
                mag = random.choice([1, 1, 1, 2, 3, 5, 8, 13])
                cand[i] += random.choice([-1, 1]) * mag
            elif r < 0.85:
                cand.append(random.randint(-40, 40))
            elif len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
            cand = list(set(cand))
            if len(cand) < 3 or len(cand) > 60:
                continue
            cs = _score(cand)
            if cs > cur_score or random.random() < math.exp((cs - cur_score) / max(T, 1e-6)):
                cur, cur_score = cand, cs
                if cs > best_score:
                    best, best_score = cand[:], cs
                    stall = 0
            stall += 1
            if stall > 4000:
                break
            T *= 0.99995
            if T < 0.01:
                T = 0.01

    return sorted(set(best))
# EVOLVE-BLOCK-END
