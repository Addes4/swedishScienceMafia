# EVOLVE-BLOCK-START
"""Union of shifted small Sidon cores tuned so sums collide heavily while diffs stay rich."""
import math
import random
import time

import numpy as np


def _nd_ns(a):
    arr = np.array(a, dtype=np.int64)
    d = np.unique(arr[:, None] - arr[None, :])
    s = np.unique(arr[:, None] + arr[None, :])
    return len(d), len(s)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _nd_ns(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build_block(S, k, M):
    A = []
    for i in range(k):
        off = i * M
        for s in S:
            A.append(off + s)
    return A


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0
    rng = random.Random(1234567)

    cores = []
    for p in [13, 29, 53, 101, 211, 401]:
        cores.append(_bose_chowla(p))

    # Sweep block constructions across cores, block counts k, and spacings M.
    # Key: allow M close to the core spread (small integer offsets) so distinct sums
    # are suppressed (offsets + core-sums collapse), while diffs stay Sidon-rich.
    for S in cores:
        nb = len(S)
        spread = max(S) - min(S)
        for k in range(2, 20):
            if k * nb > 4000:
                break
            if k * nb < 20:
                continue
            for M in set([
                spread, spread + 1,
                nb, nb * 2, nb * 3,
                (spread // k) if k else 1,
                spread // 2, spread // 3, spread // 4,
                k, 2 * k, 3 * k,
                int(spread ** 0.5), int(spread ** 0.5) + 1,
            ]):
                if M < 2:
                    continue
                A = _build_block(S, k, M)
                if len(A) > 4000:
                    continue
                sc = _score(A)
                if sc > best_score:
                    best_score, best = sc, A[:]

    # Local polish with vectorized objective, favoring moves that reduce |A+A|.
    def local(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        bl, bls = cur[:], cs
        stall = 0
        while time.time() < tlimit:
            cand = cur[:]
            op = rng.random()
            if op < 0.35 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-5, 5)
            elif op < 0.60 and len(cand) > 4:
                i = rng.randrange(len(cand))
                del cand[i]
            elif op < 0.85:
                e = rng.choice(cand) if cand else 0
                cand.append(e + rng.randint(-8, 8))
            else:
                # align two elements to force a sum collision
                if len(cand) >= 2:
                    a1 = rng.choice(cand)
                    a2 = rng.choice(cand)
                    cand.append(a1 + a2 - rng.choice(cand))
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > bls:
                    bl, bls = cand[:], s
                    stall = 0
                else:
                    stall += 1
            else:
                stall += 1
            if stall > 6000:
                break
        return bl, bls

    while time.time() < deadline:
        if best is not None and rng.random() < 0.6:
            base = [x + rng.randint(-3, 3) for x in best]
            base = sorted(set(base))
        else:
            S = rng.choice(cores)
            nb = len(S)
            k = rng.randint(2, max(2, 4000 // max(1, nb)))
            M = rng.randint(2, max(3, (max(S) - min(S)) + 10))
            base = _build_block(S, k, M)
        t = min(deadline, time.time() + 8)
        b, bs = local(base, t)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END

