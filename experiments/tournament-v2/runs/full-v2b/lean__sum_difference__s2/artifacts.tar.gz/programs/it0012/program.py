# EVOLVE-BLOCK-START
"""Search for integer sets A with large |A-A| and small |A+A| by heavy simulated annealing."""
import math
import random
import time


def _stats(a):
    diffs = set()
    sums = set()
    n = len(a)
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            sums.add(ai + a[j])
    return len(diffs), len(sums)


def _score(a):
    nd, ns = _stats(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100


def solve():
    random.seed(12345)
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Try several sizes; the ratio log|A-A|/log|A+A| tends to be best for
    # medium sets where differences are near n^2 and sums are much fewer.
    while time.time() < deadline:
        n = random.randint(6, 24)
        R = random.choice([n * n, 3 * n * n, 100, 500, 2000])
        cur = sorted(random.sample(range(-R, R + 1), n))
        cur_score = _score(cur)
        T = 1.0
        stall = 0
        while time.time() < deadline and stall < 20000:
            cand = cur[:]
            op = random.random()
            if op < 0.6:
                i = random.randrange(len(cand))
                step = random.choice([1, 1, 2, 3, -1, -1, -2, -3])
                cand[i] += step
            elif op < 0.85:
                i = random.randrange(len(cand))
                cand[i] += random.randint(-R, R)
            elif op < 0.95 and len(cand) > 3:
                cand.pop(random.randrange(len(cand)))
            else:
                cand.append(random.randint(-R, R))
            cand = sorted(set(cand))
            if len(cand) < 3:
                continue
            s = _score(cand)
            if s > cur_score or random.random() < math.exp((s - cur_score) / max(T, 1e-6)):
                cur, cur_score = cand, s
                stall = 0
            else:
                stall += 1
            if cur_score > best_score:
                best, best_score = cur[:], cur_score
            T *= 0.9995
            if T < 1e-4:
                T = 1.0
        # keep the global best, restart from a fresh set
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return best
# EVOLVE-BLOCK-END
