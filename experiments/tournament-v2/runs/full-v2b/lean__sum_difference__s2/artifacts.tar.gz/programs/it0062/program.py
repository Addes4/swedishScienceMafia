# EVOLVE-BLOCK-START
"""Block-product over Sidon set with fine spacing sweep near sum-collision threshold."""
import math
import random
import time

import numpy as np


def _counts(arr):
    arr = np.asarray(sorted(set(arr)), dtype=np.int64)
    n = arr.size
    if n < 2:
        return 0, 0
    d = np.unique(arr[:, None] - arr[None, :])
    s = np.unique(arr[:, None] + arr[None, :])
    return int(d.size), int(s.size)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return -1.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0
    rng = random.Random(20240517)

    # Small primes => small core => dense blocks => strong cross-block sum collisions.
    primes = [13, 17, 23, 29, 37, 53, 67, 101, 149, 211]

    seeds = []
    for p in primes:
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        rngb = hi - lo
        baseM = rngb + 1
        # k chosen so total ~ up to 4000, and k at least 2
        kmax = max(2, 4000 // nb)
        for k in range(2, min(kmax, 24) + 1):
            if k * nb < 12 or k * nb > 4000:
                continue
            # Fine sweep of spacing multipliers, focusing on SMALL M (collisions).
            for mult in [0.02, 0.04, 0.06, 0.08, 0.10, 0.13, 0.16, 0.20,
                         0.25, 0.30, 0.36, 0.43, 0.50, 0.60, 0.70, 0.80,
                         0.90, 1.0, 1.15, 1.35, 1.6, 2.0]:
                M = max(2, int(round(baseM * mult)))
                seeds.append(_build(B, k, M))

    # Deduplicate seeds cheaply.
    seen = set()
    uniq = []
    for s in seeds:
        key = tuple(s)
        if key not in seen:
            seen.add(key)
            uniq.append(s)
    seeds = uniq

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]
        if time.time() > deadline:
            break

    def local_opt(base, tlimit, max_step=60000):
        cur = sorted(set(base))
        cs = _score(cur)
        best_local, best_local_s = cur[:], cs
        stall = 0
        step = 0
        while time.time() < tlimit and step < max_step:
            step += 1
            cand = cur[:]
            r = rng.random()
            if r < 0.25 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-8, 8)
            elif r < 0.45 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-2, 2)
            elif r < 0.60 and len(cand) > 4:
                i = rng.randrange(len(cand))
                del cand[i]
            elif r < 0.78 and cand:
                base_el = rng.choice(cand)
                cand.append(base_el + rng.choice([-1, 1]) * rng.randint(1, 30))
            elif r < 0.90 and len(cand) >= 2:
                a1 = rng.choice(cand)
                a2 = rng.choice(cand)
                cand.append(a1 + a2 - rng.choice(cand))
            else:
                cand.append(rng.randint(-2000, 2000))
            cand = sorted(set(cand))
            if not (3 <= len(cand) <= 4000):
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_local_s:
                    best_local, best_local_s = cand[:], s
                    stall = 0
                else:
                    stall += 1
            else:
                stall += 1
            if stall > 4000:
                break
        return best_local, best_local_s

    idx = 0
    nseeds = len(seeds)
    while time.time() < deadline:
        if idx < nseeds:
            base = seeds[idx]
            idx += 1
        else:
            if rng.random() < 0.6 and seeds:
                base = list(rng.choice(seeds))
                for _ in range(rng.randint(1, 3)):
                    if base:
                        i = rng.randrange(len(base))
                        base[i] += rng.randint(-5, 5)
            else:
                base = [rng.randint(-3000, 3000) for _ in range(rng.randint(20, 200))]
            base = sorted(set(base))
        tlimit = min(deadline, time.time() + 8)
        b, bs = local_opt(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
