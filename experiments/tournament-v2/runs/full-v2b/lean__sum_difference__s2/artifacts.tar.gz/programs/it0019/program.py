# EVOLVE-BLOCK-START
"""Direct optimization of log|A-A|/log|A+A| via simulated annealing with numpy."""
import math
import random
import time
import numpy as np


def _counts(a):
    a = np.asarray(a, dtype=np.int64)
    d = a[:, None] - a[None, :]
    s = a[:, None] + a[None, :]
    nd = np.unique(d).size
    ns = np.unique(s).size
    return nd, ns


def _score_counts(nd, ns, n):
    if ns <= 1 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    return _score_counts(*_counts(a), len(set(a)))


def solve():
    random.seed(12345)
    best_a = None
    best_score = -1.0
    deadline = time.time() + 115

    # try several sizes
    sizes = [8, 10, 12, 14, 16, 18, 20, 22, 26, 30, 36, 44, 55, 70]

    for n in sizes:
        if time.time() > deadline:
            break
        # init: distinct random ints in moderate range
        cur = random.sample(range(1, 4 * n + 40), n)
        cur = sorted(cur)
        nd, ns = _counts(cur)
        cur_score = _score_counts(nd, ns, n)
        if cur_score > best_score:
            best_score, best_a = cur_score, cur[:]

        local_deadline = min(deadline, time.time() + 115.0 / len(sizes))
        T = 0.05
        step = max(n // 2, 3)
        it = 0
        while time.time() < local_deadline:
            it += 1
            cand = cur[:]
            r = random.random()
            if r < 0.7:
                i = random.randrange(n)
                cand[i] += random.randint(-step, step)
                cand = list(set(cand))
                if len(cand) < 2:
                    continue
            elif r < 0.9:
                cand.append(random.randint(1, 4 * n + 60))
                cand = list(set(cand))
            else:
                if len(cand) > 4:
                    del cand[random.randrange(len(cand))]
                cand = list(set(cand))
                if len(cand) < 2:
                    continue
            cn = len(cand)
            nd, ns = _counts(cand)
            sc = _score_counts(nd, ns, cn)
            if sc >= cur_score or random.random() < math.exp((sc - cur_score) / max(T, 1e-9)):
                cur, cur_score = cand, sc
                if sc > best_score:
                    best_score, best_a = sc, cand[:]
            # anneal
            if it % 200 == 0:
                T *= 0.997
                if T < 1e-4:
                    T = 1e-4
            # occasional restart from best
            if it % 5000 == 0 and random.random() < 0.3:
                cur = best_a[:] if best_a else cur
                cur_score = best_score

    if best_a is None:
        best_a = [7, 15, 18, 22, -3, -2]
    return sorted(set(int(x) for x in best_a))
# EVOLVE-BLOCK-END
