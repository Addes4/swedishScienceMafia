# EVOLVE-BLOCK-START
"""Construction: integer geometric progression A = {b^i} picks up many sum-collisions
(consecutive triples satisfy b^i + b^{i+2} = (b+1) b^{i+1}), shrinking |A+A| while keeping
|A-A| close to n^2, giving a large difference/sum ratio."""
import math
import time


def _stats(a):
    a = list(set(a))
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums), len(a)


def _score(a):
    d, s, n = _stats(a)
    if n < 2 or s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / n) / 100


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # Try a family of geometric-ish constructions and small perturbations.
    for base in range(2, 40):
        for n in range(5, 22):
            # keep values within range: base^(n-1) <= 1e15
            if (n - 1) * math.log(base) > math.log(1e15):
                break
            a = [base ** i for i in range(n)]
            if max(a) > 10**15:
                break
            sc = _score(a)
            if sc > best_score:
                best_score = sc
                best = a[:]

        if time.time() > deadline:
            break

    # allow slightly larger bases with fewer terms
    if best is None:
        best = [1, 2, 4, 8, 16, 32, 64]

    # Local refinement: try replacing/perturbing a few terms to improve ratio.
    import random
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] = max(1, cand[i] + random.randint(-2, 2))
        if len(set(cand)) < len(cand):
            continue
        if max(cand) > 10**15:
            continue
        sc = _score(cand)
        if sc > cur_score:
            cur, cur_score = cand, sc
        if sc > best_score:
            best_score = sc
            best = cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END

