# EVOLVE-BLOCK-START
"""Block-product over Sidon set with tight spacing and fast numpy-guided refinement."""
import math
import random
import time

import numpy as np


def _n_ns(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _n_ns(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(123456789)

    seeds = []
    for p in [13, 17, 23, 29, 37, 53, 71, 101, 151, 211, 307, 401]:
        B = _bose_chowla(p)
        nb = len(B)
        spread = max(B) - min(B)
        baseM = spread + 1
        for k in [2, 3, 4, 5, 6, 8, 10, 12, 16]:
            n = k * nb
            if n > 4000 or n < 16:
                continue
            for mult in [0.06, 0.12, 0.2, 0.3, 0.45, 0.6, 0.8, 1.0, 1.3, 1.7, 2.2]:
                M = max(2, int(baseM * mult))
                seeds.append(_build(B, k, M))
            # exact-ish spacings around the block width
            for M in [spread, spread + 1, spread - 1, spread + 2, spread - 2]:
                if M < 2:
                    continue
                seeds.append(_build(B, k, M))

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    arr_full = np.array(best, dtype=np.int64)

    def fast_score(a):
        if len(a) < 3:
            return 0.0
        arr = np.array(a, dtype=np.int64)
        diffs = np.unique(arr[:, None] - arr[None, :])
        sums = np.unique(arr[:, None] + arr[None, :])
        nd = len(diffs)
        ns = len(sums)
        if ns < 2 or nd < 2:
            return 0.0
        return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100

    def refine(base, budget):
        cur = sorted(set(base))
        cs = fast_score(cur)
        curset = set(cur)
        t_end = min(deadline, time.time() + budget)
        span = max(cur) - min(cur) if cur else 1
        step_scale = max(1, span // 4)
        stall = 0
        while time.time() < t_end and stall < 400:
            cand = cur[:]
            r = rng.random()
            if r < 0.35 and len(cand) > 4:
                # move one element by a smallish delta
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-step_scale, step_scale)
            elif r < 0.6:
                # insert near an existing element (tight sums)
                base_el = rng.choice(cand)
                cand.append(base_el + rng.choice([-1, 0, 1]) * rng.randint(0, max(1, step_scale // 4)))
            elif r < 0.8:
                # insert a sum of two elements (collide with a sum)
                a1 = rng.choice(cand)
                a2 = rng.choice(cand)
                cand.append(a1 + a2 - rng.choice(cand))
            elif r < 0.9 and len(cand) > 4:
                i = rng.randrange(len(cand))
                del cand[i]
            else:
                cand.append(rng.randint(-step_scale, step_scale))
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 4:
                stall += 1
                continue
            s = fast_score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_score:
                    pass
                stall = 0
            else:
                stall += 1
        return cur, cs

    # greedy single-element cleanup around the best
    def greedy_clean(base, budget):
        cur = sorted(set(base))
        cs = fast_score(cur)
        t_end = min(deadline, time.time() + budget)
        improved = True
        while improved and time.time() < t_end:
            improved = False
            # try removing redundant elements
            for i in range(len(cur)):
                if time.time() > t_end:
                    break
                cand = cur[:i] + cur[i + 1:]
                if len(cand) < 4:
                    continue
                s = fast_score(cand)
                if s > cs:
                    cur, cs = cand, s
                    improved = True
                    break
        return cur, cs

    cur, cs = best[:], best_score

    # main refinement loop with restarts
    while time.time() < deadline:
        budget = min(8, deadline - time.time())
        if budget <= 0.2:
            break
        b, bs = refine(cur, budget)
        if bs > cs:
            cur, cs = b, bs
        gc, gs = greedy_clean(cur, min(3, deadline - time.time()))
        if gs > cs:
            cur, cs = gc, gs
        if cs > best_score:
            best_score, best = cs, cur[:]
        # occasional restart from a fresh seed variant
        if rng.random() < 0.4 and seeds:
            cur = rng.choice(seeds)[:]
            cur = sorted(set(x + rng.randint(-2, 2) for x in cur))
            cs = fast_score(cur)
            if cs < best_score * 0.9:
                cur, cs = best[:], best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
