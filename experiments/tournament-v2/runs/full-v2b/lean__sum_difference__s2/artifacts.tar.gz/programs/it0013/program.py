# EVOLVE-BLOCK-START
"""Hill-climb the true ratio objective over moderate-size integer sets, starting from
a Bose-Chowla Sidon set (near-maximal differences) and pushing sums to collide."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def _bose_chowla(p, n):
    # Sidon set mod p^2-1 lifted to ints: use generator g of F_{p^2} style; simple
    # practical version: take a known Sidon set via the standard construction
    # a_i = 2*p*i + (i*i mod p)
    m = p
    out = []
    for i in range(n):
        out.append(2 * m * i + (i * i) % m)
    return out


def solve():
    random.seed(int(time.time()) & 0xffff)
    deadline = time.time() + 110

    best = None
    best_s = -1.0

    # candidate sizes to try
    sizes = [30, 40, 50, 60, 80]

    # initialize from Sidon-like constructions of several sizes
    starts = []
    for n in sizes:
        p = max(5, n)
        starts.append(_bose_chowla(p, n))
    # also a compact arithmetic seed
    starts.append([2 * i for i in range(40)])

    for seed_set in starts:
        if time.time() > deadline:
            break
        cur = seed_set[:]
        s, _, _ = _score(cur)
        if s > best_s:
            best_s, best = s, cur[:]
        # normalize: shift to reduce span
        cur = sorted(set(cur))

        # local search with restarts
        local_end = time.time() + 18
        while time.time() < local_end and time.time() < deadline:
            cand = cur[:]
            op = random.random()
            if op < 0.55 and cand:
                i = random.randrange(len(cand))
                cand[i] += random.choice([-2, -1, 1, 2, -3, 3, -5, 5])
            elif op < 0.8:
                # move whole set by a constant (doesn't change ratio but changes sums overlap w/ diffs) - skip
                i = random.randrange(len(cand))
                cand[i] += random.randint(-10, 10)
            else:
                # try compressing towards median to collide sums
                if len(cand) > 3:
                    i = random.randrange(len(cand))
                    med = sorted(cand)[len(cand) // 2]
                    cand[i] = med + random.randint(-2, 2)
            if len(set(cand)) < len(set(cur)):
                continue
            s2, _, _ = _score(cand)
            if s2 >= s:
                s, cur = s2, cand
                if s2 > best_s:
                    best_s, best = s2, cur[:]

    if best is None:
        best = [2 * i for i in range(40)]
    return sorted(set(best))
# EVOLVE-BLOCK-END
