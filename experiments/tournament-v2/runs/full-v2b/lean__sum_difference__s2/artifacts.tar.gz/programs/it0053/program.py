# EVOLVE-BLOCK-START
"""Block-cluster over Bose-Chowla Sidon set with fine M sweep + targeted refinement."""
import math
import random
import time

import numpy as np


def _counts(arr):
    a = np.asarray(arr, dtype=np.int64)
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(np.array(a, dtype=np.int64))
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build_block(B, k, M, T):
    """A = { M*b + t : b in B, t in [0,T) }, k = number of distinct t values used."""
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(123456789)

    # Fast seed sweep over block constructions
    primes = [17, 29, 53, 101, 211, 401, 809]
    for p in primes:
        B = _bose_chowla(p)
        nb = len(B)
        if nb < 2:
            continue
        spread = max(B) - min(B)
        baseM = spread + 1
        # fine sweep of M near baseM * mult and multiples for sum collision
        mults = [0.02, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5,
                 0.6, 0.75, 0.9, 1.0, 1.1, 1.25, 1.5, 1.75, 2.0, 2.5, 3.0]
        for k in [2, 3, 4, 5, 6, 7, 8, 10, 12]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for mult in mults:
                M = max(2, int(baseM * mult))
                A = _build_block(B, k, M, 1)
                sc = _score(A)
                if sc > best_score:
                    best_score, best = sc, sorted(set(A))

    # also sweep with M as a small multiple of the number of blocks
    for p in [29, 53, 101, 211, 401]:
        B = _bose_chowla(p)
        nb = len(B)
        spread = max(B) - min(B)
        for k in [3, 4, 5, 6, 8, 10]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for M in [k, k + 1, 2 * k, 3 * k, max(2, spread // k), max(2, spread)]:
                if M < 2:
                    continue
                A = _build_block(B, k, M, 1)
                sc = _score(A)
                if sc > best_score:
                    best_score, best = sc, sorted(set(A))

    if best is None:
        best = list(range(40, 80))
        best_score = _score(best)

    def local_opt(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        best_local, best_local_s = cur[:], cs
        step = 0
        stall = 0
        while time.time() < tlimit and step < 200000:
            step += 1
            cand = cur[:]
            op = rng.random()
            if op < 0.30:
                # small shift
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-8, 8)
            elif op < 0.50:
                # medium shift
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-1, 1]) * rng.randint(10, 200)
            elif op < 0.62:
                # large jump
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-1, 1]) * rng.randint(200, 5000)
            elif op < 0.72 and len(cand) > 5:
                del cand[rng.randrange(len(cand))]
            elif op < 0.85:
                # insert near existing element (fill)
                cand.append(rng.choice(cand) + rng.randint(-40, 40))
            elif op < 0.95:
                # insert sum of two existing to collide sums
                if len(cand) >= 2:
                    a1 = rng.choice(cand)
                    a2 = rng.choice(cand)
                    cand.append(a1 + a2 - rng.choice(cand))
            else:
                cand.append(rng.randint(-8000, 8000))
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_local_s:
                    best_local, best_local_s = cand[:], s
                    stall = 0
                else:
                    stall += 1
            else:
                stall += 1
            if stall > 6000:
                break
        return best_local, best_local_s

    # refine from best seed plus extra seeds
    seed_list = [best[:]]
    for _ in range(6):
        seed_list.append([x + rng.randint(-30, 30) for x in best])

    idx = 0
    while time.time() < deadline:
        if idx < len(seed_list):
            base = seed_list[idx]
            idx += 1
        else:
            # restart from perturbed best
            base = [x + rng.randint(-100, 100) for x in best]
            base = sorted(set(base))
        tlimit = min(deadline, time.time() + 12)
        b, bs = local_opt(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
