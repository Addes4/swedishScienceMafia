# EVOLVE-BLOCK-START
"""Bose-Chowla Sidon seed + numpy hill-climb on the actual ratio objective."""
import math
import random
import time

try:
    import numpy as np
    HAVE_NP = True
except Exception:
    HAVE_NP = False


def _bose_chowla(p, q):
    """Sidon set in [0, p*q) using Bose-Chowla with prime power q and base p."""
    # Standard Bose-Chowla: elements 2*p*i + (i^2 mod q) etc. Here use the
    # simple known construction: for prime p, {2*p*k + (k*k mod p) : k} is Sidon.
    return sorted({2 * p * k + (k * k) % p for k in range(p)})


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    if HAVE_NP:
        arr = np.array(a, dtype=np.int64)
        diffs = np.unique(arr[:, None] - arr[None, :])
        sums = np.unique(arr[:, None] + arr[None, :])
        return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 115

    # Build Sidon seeds of several sizes, then hill-climb the real ratio.
    best = None
    best_score = -1.0

    prime_sizes = [13, 17, 19, 23, 29, 31, 37, 41]
    seeds = []
    for p in prime_sizes:
        s = _bose_chowla(p, p)
        seeds.append(s)
        # also a shifted-copy seed: B union (B + t) for various t
        for t in (1, 2, 3, 5, 8, 13):
            seeds.append(sorted(set(s) | {x + t for x in s}))

    for seed in seeds:
        a = list(set(seed))
        sc = _score(a)
        if sc > best_score:
            best, best_score = a[:], sc

    # Combine: keep the best seed as working set and refine it.
    cur = best[:]
    cur_score = best_score
    it = 0
    while time.time() < deadline:
        it += 1
        cand = cur[:]
        move = rng.random()
        vals = set(cand)
        if move < 0.55:
            # perturbation
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-2, 2)
        elif move < 0.80 and len(cand) < 200:
            # insertion tied to an existing element (keeps structure)
            base = rng.choice(cand)
            cand.append(base + rng.choice([1, 2, 3, -1, -2, -3, 5, -5]))
        elif move < 0.92 and len(cand) > 4:
            cand.pop(rng.randrange(len(cand)))
        else:
            # shift whole set
            d = rng.randint(-3, 3)
            cand = [x + d for x in cand]
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        sc = _score(cand)
        if sc >= cur_score:
            cur, cur_score = cand[:], sc
            if sc > best_score:
                best, best_score = cand[:], sc
        elif rng.random() < 0.02:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
