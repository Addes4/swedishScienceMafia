# EVOLVE-BLOCK-START
"""Block-product over Sidon set with tight spacing and vectorized biased local search."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return int(len(diffs)), int(len(sums))


def _score(a):
    if len(a) < 2:
        return 0.0
    arr = np.array(a, dtype=np.int64)
    nd = len(np.unique(arr[:, None] - arr[None, :]))
    ns = len(np.unique(arr[:, None] + arr[None, :]))
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0
    rng = random.Random(987654321)

    seeds = []
    # Fine sweep around the sum-collision threshold for block constructions.
    for p in [29, 53, 101, 211, 401]:
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        rngb = hi - lo
        for k in [2, 3, 4, 5, 6, 7, 8]:
            n = k * nb
            if n > 4000 or n < 20:
                continue
            # M near the range of B (collisions when M <= rngb); sweep finely
            for frac in [0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2]:
                M = max(2, int(rngb * frac))
                seeds.append(_build(B, k, M))
            # also small integer M for aggressive collision
            for M in [2, 3, 5, 8, 13, 21, 34]:
                seeds.append(_build(B, k, M))

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    def local_opt(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        best_local, best_local_s = cur[:], cs
        step = 0
        stall = 0
        while time.time() < tlimit and step < 40000:
            step += 1
            cand = cur[:]
            op = rng.random()
            if op < 0.18 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-20, 20)
            elif op < 0.32 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-3, 3)
            elif op < 0.44:
                if cand:
                    i = rng.randrange(len(cand))
                    cand[i] += rng.choice([-1, 1]) * rng.randint(50, 3000)
            elif op < 0.56:
                if cand:
                    i = rng.randrange(len(cand))
                    cand[i] += rng.randint(-300, 300)
            elif op < 0.66 and len(cand) > 5:
                i = rng.randrange(len(cand))
                del cand[i]
            elif op < 0.80:
                if cand:
                    base_el = rng.choice(cand)
                    cand.append(base_el + rng.randint(-50, 50))
            elif op < 0.92:
                if len(cand) >= 2:
                    a1 = rng.choice(cand)
                    a2 = rng.choice(cand)
                    cand.append(a1 + a2 - rng.choice(cand))
            else:
                cand.append(rng.randint(-5000, 5000))
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_local_s:
                    best_local, best_local_s = cand[:], s
                    stall = 0
                else:
                    stall += 1
            else:
                stall += 1
            if stall > 4000:
                break
        return best_local, best_local_s

    # sort seeds by initial score, use best ones for local search
    order = sorted(range(len(seeds)), key=lambda i: -_score(seeds[i]))
    idx = 0
    nseeds = len(seeds)
    while time.time() < deadline:
        if idx < nseeds:
            base = seeds[order[idx]]
            idx += 1
        else:
            if rng.random() < 0.7 and seeds:
                base = [x + rng.randint(-20, 20) for x in rng.choice(seeds)]
            else:
                n = rng.randint(30, 300)
                base = [rng.randint(-10 ** 6, 10 ** 6) for _ in range(n)]
            base = sorted(set(base))
        tlimit = min(deadline, time.time() + 8)
        b, bs = local_opt(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
