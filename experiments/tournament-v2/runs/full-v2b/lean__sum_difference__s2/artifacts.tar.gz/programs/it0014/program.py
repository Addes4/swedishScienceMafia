# EVOLVE-BLOCK-START
"""Simulated-annealing search for sets with many differences and few sums."""
import math
import time
import random

import numpy as np


def _score(arr):
    """arr: 1-D int64 numpy array of distinct integers."""
    n = arr.size
    if n < 2:
        return 0.0
    d = arr[:, None] - arr[None, :]
    s = arr[:, None] + arr[None, :]
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    random.seed(1234567)
    np.random.seed(1234567)

    deadline = time.time() + 115.0

    # ---- initial dealers ----
    def ap(n, start, step):
        return [start + i * step for i in range(n)]

    seeds = []

    # arithmetic progression (ratio ~ 1, good baseline structure)
    seeds.append(ap(60, -30, 7))
    # geometric-ish base pattern
    seeds.append([0, 1, 2, 4, 8, 16, 32, 64, 128, 256])
    # a decent small found pattern
    seeds.append([7, 15, 18, 22, -3, -2])

    best_global = None
    best_global_score = -1.0

    # Try a range of set sizes across restarts
    restart = 0
    while time.time() < deadline:
        restart += 1
        # size schedule
        n = random.choice([20, 30, 40, 50, 60, 80, 100, 140])
        spread = random.choice([n, 2 * n, 5 * n, 20 * n, 100 * n, 1000 * n])

        r = random.random()
        if r < 0.35 and seeds:
            base = list(random.choice(seeds))
            if len(base) >= n:
                random.shuffle(base)
                cur = base[:n]
            else:
                cur = base + [random.randint(-int(spread), int(spread))
                              for _ in range(n - len(base))]
        else:
            cur = [random.randint(-int(spread), int(spread)) for _ in range(n)]

        # dedupe
        cur = list(set(cur))
        if len(cur) < 2:
            continue

        arr = np.array(sorted(cur), dtype=np.int64)
        cur_score = _score(arr)

        if cur_score > best_global_score:
            best_global_score = cur_score
            best_global = arr.copy()

        T0 = 0.05
        steps = 0
        # per-restart time slice
        restart_deadline = min(deadline, time.time() + random.uniform(3.0, 8.0))

        while time.time() < restart_deadline and time.time() < deadline:
            steps += 1
            T = T0 * max(0.001, 1.0 - steps / 20000.0)

            cand = arr.copy()
            move = random.random()
            if move < 0.55 and cand.size > 0:
                # perturb one element
                i = random.randrange(cand.size)
                cand[i] += int(np.random.normal(0, max(1, spread / 50)))
            elif move < 0.70:
                # large reassignment
                i = random.randrange(cand.size)
                cand[i] = random.randint(-int(spread), int(spread))
            elif move < 0.85 and cand.size < 4000:
                # insert
                cand = np.append(cand, random.randint(-int(spread), int(spread)))
            elif cand.size > 3:
                # delete
                i = random.randrange(cand.size)
                cand = np.delete(cand, i)

            cand = np.unique(cand)  # keeps distinct
            if cand.size < 2:
                continue
            cs = _score(cand)
            delta = cs - cur_score
            if delta >= 0 or random.random() < math.exp(delta / max(T, 1e-6)):
                arr = cand
                cur_score = cs
                if cur_score > best_global_score:
                    best_global_score = cur_score
                    best_global = arr.copy()

    if best_global is None:
        best_global = np.array([7, 15, 18, 22, -3, -2], dtype=np.int64)

    return [int(x) for x in best_global.tolist()]
# EVOLVE-BLOCK-END

