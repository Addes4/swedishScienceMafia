# EVOLVE-BLOCK-START
"""Block-product over Sidon set with fast scorer and targeted refinement."""
import math
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0

    seeds = []
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        spread = max(B) - min(B)
        baseM = spread + 1
        for k in [2, 3, 4, 5, 6, 7, 8]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for mult in [0.05, 0.1, 0.15, 0.2, 0.3, 0.4, 0.5, 0.65, 0.8,
                         1.0, 1.25, 1.5, 2.0, 3.0]:
                M = max(2, int(baseM * mult))
                seeds.append(_build(B, k, M))

    # tight relative to B-range (so blocks overlap heavily -> more sum collisions)
    for p in [53, 101, 211, 401]:
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        rngb = hi - lo
        for k in [2, 3, 4, 5, 6, 7]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for M in [rngb, rngb + 1, rngb // 2, rngb // 3, rngb // 4,
                      rngb // 6, rngb // 10]:
                if M < 2:
                    continue
                seeds.append(_build(B, k, M))

    # fast score all seeds
    seed_scores = []
    for s in seeds:
        sc = _score(s)
        seed_scores.append((sc, s))
        if sc > best_score:
            best_score, best = sc, s[:]

    seed_scores.sort(key=lambda t: -t[0])
    top = [s for _, s in seed_scores[:40]]

    # target = spacing of global best; do fine sweep around it
    def fast_score(arr):
        a = np.unique(np.array(arr, dtype=np.int64))
        n = a.size
        if n < 2:
            return 0.0
        diffs = np.unique(a[:, None] - a[None, :])
        sums = np.unique(a[:, None] + a[None, :])
        nd, ns = diffs.size, sums.size
        if nd < 2 or ns < 2:
            return 0.0
        return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100

    # Refinement: try shifting a single element to reduce sumset without
    # losing diffs. Randomized but time-bounded, starting from top seeds.
    import random
    rng = random.Random(20240607)

    def refine(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        bc, bs = cur[:], cs
        while time.time() < tlimit:
            improved = False
            for _ in range(60):
                cand = cur[:]
                i = rng.randrange(len(cand))
                delta = rng.randint(-30, 30)
                cand[i] += delta
                cand = sorted(set(cand))
                s = _score(cand)
                if s > cs:
                    cur, cs = cand, s
                    bc, bs = cand[:], s
                    improved = True
                    break
            if not improved:
                # try a wider jump on a random element
                for _ in range(30):
                    cand = cur[:]
                    i = rng.randrange(len(cand))
                    cand[i] += rng.choice([-1, 1]) * rng.randint(100, 5000)
                    cand = sorted(set(cand))
                    if len(cand) < 3:
                        continue
                    s = _score(cand)
                    if s > cs:
                        cur, cs = cand, s
                        bc, bs = cand[:], s
                        improved = True
                        break
            if not improved:
                break
        return bc, bs

    idx = 0
    while time.time() < deadline:
        if idx < len(top):
            base = top[idx]
            idx += 1
        else:
            base = [x + rng.randint(-10, 10) for x in rng.choice(top)]
            base = sorted(set(base))
        tlimit = min(deadline, time.time() + 8)
        b, bs = refine(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
