# EVOLVE-BLOCK-START
"""Block-cluster over a Bose-Chowla Sidon set with compact sums."""
import math
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


PRIMES = [29, 53, 101, 211, 401, 809, 1601, 3203]


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    for p in PRIMES:
        if time.time() > deadline:
            break
        B = _bose_chowla(p)
        nb = len(B)
        blo, bhi = min(B), max(B)
        rngb = bhi - blo + 1
        # shift B so min is 0
        B0 = [b - blo for b in B]

        # cluster sizes T
        for T in [1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 30]:
            if nb * T > 4000:
                continue
            if nb * T < 10:
                continue
            # M must be large enough that blocks don't overlap.
            # Want cross-block sums to collide: (M*b1 + t1) + (M*b2 + t2)
            # For distinct b sums to map into compact range, choose M ~ T
            # but not smaller than rngb; sweep a fine grid around rngb and multiples.
            base = max(rngb, T)
            cands_M = []
            for mult in [1.0, 1.02, 1.05, 1.1, 1.2, 1.5, 2.0, 3.0]:
                cands_M.append(int(base * mult))
            # also tight: M slightly above T
            for m in [T, T + 1, T * 2, T * 3]:
                if m >= T:
                    cands_M.append(max(rngb, m))
            # smooth grid around rngb
            for dm in [-2, -1, 0, 1, 2]:
                if rngb + dm >= 2:
                    cands_M.append(rngb + dm)
            for M in sorted(set(cands_M)):
                if M < 2:
                    continue
                A = []
                for b in B0:
                    off = M * b
                    for t in range(T):
                        A.append(off + t)
                if len(A) > 4000 or len(A) < 10:
                    continue
                sc = _score(A)
                if sc > best_score:
                    best_score = sc
                    best = A[:]

    return sorted(set(best)) if best else [0, 1]
# EVOLVE-BLOCK-END

