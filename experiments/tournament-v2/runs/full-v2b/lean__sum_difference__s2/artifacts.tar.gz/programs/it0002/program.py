# EVOLVE-BLOCK-START
"""Structured construction: product-like set with large difference set and collapsing sums."""
import math
import random
import time


def _stats(a):
    a = sorted(set(a))
    m = len(a)
    if m < 2:
        return 1, 1, 0.0
    diffs = set()
    sums = set()
    for i, x in enumerate(a):
        for y in a[i:]:
            diffs.add(x - y)
            diffs.add(y - x)
            sums.add(x + y)
    ratio = math.log(len(diffs)) / math.log(len(sums))
    return len(diffs), len(sums), ratio + (1 - 1 / m) / 100


def _build(n, base):
    # A = union over i in [0,n-1] of {i*M + d}. Choose M so that block sums
    # overlap heavily (M ~ 2*range(base)) while block offsets stay distinct.
    span = max(base) - min(base) + 1
    M = 2 * span
    a = []
    for i in range(n):
        off = i * M
        for d in base:
            a.append(off + d)
    return a


def solve():
    """Return A with large |A-A| and small |A+A|."""
    base = [0, 1, 4, 10, 20, 35]
    best = None
    best_sc = -1.0
    # sweep n to balance log|A-A| / log|A+A|
    for n in range(2, 42):
        cand = _build(n, base)
        _, _, sc = _stats(cand)
        if sc > best_sc:
            best_sc, best = sc, cand[:]
    if best is None:
        best = [0, 1, 4, 10, 20, 35]

    # local refinement
    cur = best[:]
    deadline = time.time() + 90
    cur_sc = _stats(cur)[2]
    best_sc = cur_sc
    span = max(cur) - min(cur)
    step = max(1, span // 200)
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        cand[i] += random.randint(-step, step)
        if len(set(cand)) < len(cand):
            continue
        s = _stats(cand)[2]
        if s >= cur_sc:
            cur, cur_sc = cand, s
            if s > best_sc:
                best, best_sc = cand[:], s
        elif random.random() < 0.05:
            cur, cur_sc = best[:], best_sc
        if step > 1 and random.random() < 0.01:
            step = max(1, step - 1)
    return sorted(set(best))
# EVOLVE-BLOCK-END

