# EVOLVE-BLOCK-START
"""Block-product over Sidon set with vectorized counting and sum-collision moves."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.asarray(a, dtype=np.int64)
    n = arr.size
    if n < 2:
        return 1, 1
    # differences
    d = arr[:, None] - arr[None, :]
    nd = np.unique(d).size
    s = arr[:, None] + arr[None, :]
    ns = np.unique(s).size
    return nd, ns


def _score(a):
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(20240607)

    primes = [29, 53, 101, 211, 401, 809, 1601]

    seeds = []
    for p in primes:
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        spread = hi - lo
        baseM = spread + 1
        for k in [2, 3, 4, 5, 6, 7, 8, 10, 12, 16]:
            if k * nb > 4000 or k * nb < 20:
                continue
            # finer sweep of spacings, including tight fractional ones
            for num, den in [(1, 20), (1, 10), (1, 6), (1, 4), (1, 3), (1, 2),
                             (2, 3), (1, 1), (4, 3), (3, 2), (2, 1), (3, 1), (5, 1)]:
                M = max(2, (baseM * num) // den)
                seeds.append(_build(B, k, M))
                # shift blocks a bit: A = {i*M + b + i*delta} to force sum overlap
                for delta in (1, -1):
                    seeds.append([i * M + b + i * delta for i in range(k) for b in B])

    # score seeds
    for s in seeds:
        s = sorted(set(s))
        if len(s) < 3:
            continue
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    def local_opt(base, tlimit):
        cur = sorted(set(base))
        if len(cur) < 3:
            return cur, _score(cur)
        cs = _score(cur)
        best_local, best_local_s = cur[:], cs
        n = len(cur)
        lo_val = min(cur)
        hi_val = max(cur)
        stall = 0
        while time.time() < tlimit and stall < 6000:
            cand = cur[:]
            op = rng.random()
            if op < 0.30:
                # small perturbation of one element
                i = rng.randrange(n)
                cand[i] += rng.randint(-max(1, (hi_val - lo_val) // 50 or 1),
                                       max(1, (hi_val - lo_val) // 50 or 1))
            elif op < 0.50:
                # larger jump
                i = rng.randrange(n)
                cand[i] += rng.choice([-1, 1]) * rng.randint(1, max(2, hi_val - lo_val))
            elif op < 0.68:
                # sum-collision move: move an element onto a+b of two others
                if n >= 3:
                    i = rng.randrange(n)
                    a1 = rng.randrange(n)
                    a2 = rng.randrange(n)
                    cand[i] = cur[a1] + cur[a2]
            elif op < 0.80 and n > 5:
                # difference-collision-free insert
                a1 = rng.randrange(n)
                a2 = rng.randrange(n)
                cand.append(cur[a1] - cur[a2])
            elif op < 0.90:
                cand.append(rng.choice(cur) + rng.randint(-3, 3))
            else:
                cand.append(rng.randint(lo_val, hi_val))
            cand = sorted(set(cand))
            nc = len(cand)
            if nc > 4000 or nc < 3:
                continue
            s = _score(cand)
            if s >= cs or rng.random() < 0.02:
                cur, cs = cand, s
                n = nc
                if s > best_local_s:
                    best_local, best_local_s = cand[:], s
                    stall = 0
                else:
                    stall += 1
            else:
                stall += 1
        return best_local, best_local_s

    idx = 0
    nseeds = len(seeds)
    while time.time() < deadline:
        if idx < nseeds:
            base = sorted(set(seeds[idx]))
            idx += 1
        else:
            if seeds and rng.random() < 0.8:
                base = [x + rng.randint(-30, 30) for x in rng.choice(seeds)]
                base = sorted(set(base))
            else:
                nb = rng.randint(30, 300)
                base = sorted(set(rng.randint(-10 ** 6, 10 ** 6) for _ in range(nb)))
        tlimit = min(deadline, time.time() + 8)
        b, bs = local_opt(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
