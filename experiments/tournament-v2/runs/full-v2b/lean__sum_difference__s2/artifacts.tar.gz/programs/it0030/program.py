# EVOLVE-BLOCK-START
"""Block-product over Sidon set with sum-collision SA and reflection moves."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    n = len(arr)
    # chunk to avoid memory blowup at n=4000
    if n <= 1500:
        diffs = np.unique(arr[:, None] - arr[None, :])
        sums = np.unique(arr[:, None] + arr[None, :])
    else:
        ds = []
        ss = []
        chunk = 700
        for i in range(0, n, chunk):
            sub = arr[i:i + chunk]
            ds.append(np.unique(sub[:, None] - arr[None, :]).ravel())
            ss.append(np.unique(sub[:, None] + arr[None, :]).ravel())
        diffs = np.unique(np.concatenate(ds))
        sums = np.unique(np.concatenate(ss))
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(246813579)

    seeds = []
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        spread = max(B) - min(B)
        baseM = spread + 1
        for k in [2, 3, 4, 5, 6, 7, 8]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for mult in [0.02, 0.05, 0.15, 0.3, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0]:
                M = max(2, int(baseM * mult))
                seeds.append(_build(B, k, M))

    for p in [53, 101, 211, 401]:
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        rngb = hi - lo
        for k in [2, 3, 4, 5, 6]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for M in [rngb, rngb + 1, rngb // 2, rngb // 3, rngb // 4, 2]:
                if M < 2:
                    continue
                seeds.append(_build(B, k, M))

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    def sa(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        best_local, best_local_s = cur[:], cs
        curset = set(cur)
        step = 0
        T0 = 0.02
        while time.time() < tlimit and step < 200000:
            step += 1
            T = T0 * (0.5 ** (step / 8000.0)) + 0.0002
            cand = cur[:]
            op = rng.random()
            n = len(cand)
            if op < 0.18 and n:
                i = rng.randrange(n)
                cand[i] += rng.randint(-300, 300)
            elif op < 0.32 and n:
                i = rng.randrange(n)
                cand[i] += rng.randint(-5, 5)
            elif op < 0.44 and n:
                # reflection around a pivot -> create sum collisions
                piv = rng.choice(cand)
                i = rng.randrange(n)
                cand[i] = 2 * piv - cand[i]
            elif op < 0.54 and n:
                # rescale-ish: move an element to land on an existing sum
                if n >= 2:
                    a1 = rng.choice(cand); a2 = rng.choice(cand)
                    cand[rng.randrange(n)] = a1 + a2 - rng.choice(cand)
            elif op < 0.62 and len(cand) > 5:
                del cand[rng.randrange(len(cand))]
            elif op < 0.72:
                # insert near existing element
                if cand:
                    cand.append(rng.choice(cand) + rng.randint(-40, 40))
            elif op < 0.82:
                # insert a sum to fill sums (collision cheap)
                if len(cand) >= 2:
                    a1 = rng.choice(cand); a2 = rng.choice(cand)
                    cand.append(a1 + a2 - rng.choice(cand))
            elif op < 0.90 and n:
                # shift a whole small cluster (block offset)
                i = rng.randrange(n)
                d = rng.randint(-100, 100)
                for j in range(i, min(n, i + 5)):
                    cand[j] += d
            else:
                cand.append(rng.randint(-8000, 8000))
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s = _score(cand)
            if s >= cs or rng.random() < math.exp(min(50, (s - cs) / T)):
                cur, cs = cand, s
                if s > best_local_s:
                    best_local, best_local_s = cand[:], s
        return best_local, best_local_s

    idx = 0
    nseeds = len(seeds)
    while time.time() < deadline:
        tlimit = min(deadline, time.time() + 8)
        if idx < nseeds:
            base = seeds[idx]
            idx += 1
        else:
            if rng.random() < 0.75 and seeds:
                base = [x + rng.randint(-30, 30) for x in rng.choice(seeds)]
            else:
                n = rng.randint(30, 250)
                base = [rng.randint(-10 ** 6, 10 ** 6) for _ in range(n)]
            base = sorted(set(base))
        b, bs = sa(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
