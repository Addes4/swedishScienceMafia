# EVOLVE-BLOCK-START
"""Greedy + local search construction maximizing log|A-A|/log|A+A|."""
import math
import random
import time
import numpy as np


def _score(a):
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    if a.size < 2:
        return 0.0
    diffs = np.unique(a[:, None] - a[None, :])
    sums = np.unique(a[:, None] + a[None, :])
    return math.log(diffs.size) / math.log(sums.size) + (1 - 1 / a.size) / 100


def _fast_stats(a):
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    if a.size < 2:
        return 0, 0, 1
    d = a[:, None] - a[None, :]
    s = a[:, None] + a[None, :]
    nd = np.unique(d).size
    ns = np.unique(s).size
    return nd, ns, a.size


def _try_construct(M, n, base):
    """A = {i*M + b : i in [0,n-1], b in base} adjusted to reduce sums."""
    A = []
    for i in range(n):
        for b in base:
            A.append(i * M + b)
    return A


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)
    deadline = time.time() + 100

    # Structured candidates: union of shifted copies with collapsing sums
    base_options = [
        [0, 1, 3, 7, 12],
        [0, 1, 4, 10, 18],
        [0, 2, 5, 11, 19, 30],
        [0, 1, 3, 8, 17, 29],
        [0, 1, 4, 9, 15],
        [0, 3, 7, 12, 20],
    ]
    for base in base_options:
        if time.time() > deadline:
            break
        for n in (10, 14, 18, 24, 30, 40):
            if time.time() > deadline:
                break
            # choose M large enough that sums across blocks collapse little,
            # but not so large differences explode pairwise unevenly
            for M in (base[-1] + 2, base[-1] * 2 + 1, base[-1] * 3 + 2):
                A = _try_construct(M, n, base)
                if len(A) > 4000 or max(abs(x) for x in A) > 10**15:
                    continue
                sc = _score(A)
                if sc > best_score:
                    best_score = sc
                    best = A

    # Generic greedy local search over a moderate ground range
    rng = random.Random(12345)
    for _ in range(200):
        if time.time() > deadline:
            break
        # random structured seed
        k = rng.randint(8, 20)
        M = rng.randint(5, 30)
        seed = sorted({rng.randint(-M * 3, M * 3) for _ in range(k)} |
                      {i * M + rng.randint(0, max(1, M // 2)) for i in range(k)})
        cur = seed[:]
        cur_score = _score(cur)
        improved = True
        while improved and time.time() < deadline:
            improved = False
            cands = []
            # try mutations
            for _ in range(30):
                c = cur[:]
                op = rng.random()
                if op < 0.4:
                    i = rng.randrange(len(c))
                    c[i] += rng.randint(-M, M)
                elif op < 0.7:
                    c.append(rng.randint(-M * 4, M * 4))
                elif len(c) > 3:
                    del c[rng.randrange(len(c))]
                if len(c) < 2 or len(c) > 500:
                    continue
                cands.append(c)
            for c in cands:
                if max(abs(x) for x in c) > 10**15:
                    continue
                s = _score(c)
                if s > cur_score:
                    cur, cur_score = c, s
                    improved = True
                    break
        if cur_score > best_score:
            best, best_score = cur[:], cur_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
