# EVOLVE-BLOCK-START
"""Block-cluster over Bose-Chowla Sidon set with fine spacing sweep + hill-climb."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _fast_counts(a):
    """Vectorized count of distinct differences and sums."""
    arr = np.asarray(a, dtype=np.int64)
    n = arr.size
    if n == 0:
        return 0, 0
    diffs = (arr[:, None] - arr[None, :]).ravel()
    sums = (arr[:, None] + arr[None, :]).ravel()
    return np.unique(diffs).size, np.unique(sums).size


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _fast_counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _cluster_score(A):
    if len(A) < 3:
        return -1.0, 0, 0
    a = sorted(set(A))
    if len(a) < 3:
        return -1.0, 0, 0
    nd, ns = _fast_counts(a)
    if ns < 2 or nd < 2:
        return -1.0, nd, ns
    sc = math.log(nd) / math.log(ns) + (1 - 1 / len(a)) / 100
    return sc, nd, ns


def _block_cluster_sweep():
    """A = {M*b + t : b in B, t in [0,T)}. Sweep M and T finely."""
    best = None
    best_score = -1.0
    primes = [29, 53, 101, 211, 401, 809]
    for p in primes:
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        rngb = hi - lo
        for T in [1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20, 28, 40]:
            for k in [1, 2, 3, 4, 5, 6, 7, 8, 10, 12]:
                n = nb * k
                if n > 4000 or n < 20:
                    continue
                # M controls block separation. Key: cross-block sums collide
                # when M is comparable to the cluster width k*T.
                # Sweep M across a broad multiplicative band around rngb.
                cluster_w = k * T
                for mult in [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0]:
                    M = max(1, int(rngb * mult))
                    A = []
                    for i in range(k):
                        off = i * M
                        for b in B:
                            b0 = b - lo
                            for t in range(T):
                                A.append(off + b0 * 1 + t)
                    if len(A) > 4000:
                        continue
                    sc, nd, ns = _cluster_score(A)
                    if sc > best_score:
                        best_score, best = sc, sorted(set(A))
                # Also vary M relative to cluster width to force sum reuse
                for mult in [0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0, 8.0]:
                    M = max(1, int(cluster_w * mult))
                    A = []
                    for i in range(k):
                        off = i * M
                        for b in B:
                            b0 = b - lo
                            for t in range(T):
                                A.append(off + b0 + t)
                    if len(A) > 4000:
                        continue
                    sc, nd, ns = _cluster_score(A)
                    if sc > best_score:
                        best_score, best = sc, sorted(set(A))
    return best, best_score


def solve():
    deadline = time.time() + 118
    best = None
    best_score = -1.0
    rng = random.Random(20240517)

    # ---- Deterministic block-cluster sweep ----
    b, bs = _block_cluster_sweep()
    if b is not None:
        best, best_score = b[:], bs

    # ---- Seed classic block-product (uniform spacing, no cluster) ----
    seeds = []
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        spread = max(B) - min(B)
        baseM = spread + 1
        for k in [2, 3, 4, 5, 6, 7, 8]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for mult in [0.05, 0.15, 0.3, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0]:
                M = max(2, int(baseM * mult))
                A = []
                for i in range(k):
                    off = i * M
                    for bb in B:
                        A.append(off + bb)
                seeds.append(A)

    for s in seeds:
        sc, nd, ns = _cluster_score(s)
        if sc > best_score:
            best_score, best = sc, sorted(set(s))

    if best is None:
        best = list(range(50))
        best_score = 0.0

    def local_opt(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        best_local, best_local_s = cur[:], cs
        step = 0
        stall = 0
        while time.time() < tlimit and step < 60000:
            step += 1
            cand = cur[:]
            op = rng.random()
            if op < 0.20 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-20, 20)
            elif op < 0.35 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-3, 3)
            elif op < 0.48 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-1, 1]) * rng.randint(50, 3000)
            elif op < 0.60 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-300, 300)
            elif op < 0.70 and len(cand) > 5:
                i = rng.randrange(len(cand))
                del cand[i]
            elif op < 0.82 and cand:
                base_el = rng.choice(cand)
                cand.append(base_el + rng.randint(-50, 50))
            elif op < 0.92 and len(cand) >= 2:
                a1 = rng.choice(cand)
                a2 = rng.choice(cand)
                cand.append(a1 + a2 - rng.choice(cand))
            else:
                cand.append(rng.randint(-5000, 5000))
            cand = sorted(set(cand))
            if len(cand) > 4000 or len(cand) < 3:
                continue
            s = _score(cand)
            if s >= cs:
                cur, cs = cand, s
                if s > best_local_s:
                    best_local, best_local_s = cand[:], s
                    stall = 0
                else:
                    stall += 1
            else:
                stall += 1
            if stall > 4000:
                break
        return best_local, best_local_s

    # refine the deterministic best first
    tlimit = min(deadline, time.time() + 20)
    bb, bbs = local_opt(best, tlimit)
    if bbs > best_score:
        best_score, best = bbs, bb[:]

    while time.time() < deadline:
        if rng.random() < 0.6:
            base = [x + rng.randint(-10, 10) for x in best]
        else:
            base = [x + rng.randint(-3, 3) for x in rng.choice(seeds)] if seeds else best[:]
        base = sorted(set(base))
        tlimit = min(deadline, time.time() + 12)
        b, bs2 = local_opt(base, tlimit)
        if bs2 > best_score:
            best_score, best = bs2, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
