# EVOLVE-BLOCK-START
"""Block-product over Sidon set with precise spacing sweep and fast greedy refinement."""
import math
import random
import time

import numpy as np


def _counts_fast(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts_fast(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(1234567)

    # Build candidate seed family: block product over Bose-Chowla Sidon sets.
    seeds = []
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        spread = max(B) - min(B)
        baseM = spread + 1
        for k in [2, 3, 4, 5, 6, 7, 8, 10]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for mult in [0.02, 0.05, 0.1, 0.15, 0.2, 0.3, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0]:
                M = max(2, int(baseM * mult))
                seeds.append(_build(B, k, M))

    # Tight spacings relative to B-range.
    for p in [29, 53, 101, 211, 401]:
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        rngb = hi - lo
        for k in [2, 3, 4, 5, 6, 8]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for M in [max(2, rngb // j) for j in [1, 2, 3, 4, 6]] + [rngb, rngb + 1]:
                if M < 2:
                    continue
                seeds.append(_build(B, k, M))

    # Deterministic evaluation of seeds with fast scorer.
    for s in seeds:
        if time.time() > deadline - 80:
            break
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    # Greedy refinement: try single-element perturbations around current best.
    def refine(base, budget):
        cur = sorted(set(base))
        arr = np.array(cur, dtype=np.int64)
        nd, ns = _counts_fast(cur)
        cs = math.log(nd) / math.log(ns) + (1 - 1 / len(cur)) / 100

        def sc_of(ls):
            a = sorted(set(ls))
            if len(a) < 3:
                return -1.0
            d, s = _counts_fast(a)
            if s < 2 or d < 2:
                return -1.0
            return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100

        lo = min(cur)
        hi = max(cur)
        span = max(1, hi - lo)
        t0 = time.time()
        improved = True
        while improved and time.time() - t0 < budget:
            improved = False
            # Try adjusting each element to a nearby value or a symmetric point.
            for i in range(len(cur)):
                base_val = cur[i]
                trials = set()
                # local jitter
                for dj in [-3, -2, -1, 1, 2, 3]:
                    trials.add(base_val + dj)
                # symmetry reflections around center / other elements (sum-collapsing)
                c = (lo + hi) // 2
                trials.add(2 * c - base_val)
                for j in rng.sample(range(len(cur)), min(4, len(cur))):
                    if j != i:
                        trials.add(2 * cur[j] - base_val)
                # scale-based
                trials.add(int(base_val * 0.99))
                trials.add(int(base_val * 1.01))
                for tv in trials:
                    if tv == base_val:
                        continue
                    cand = cur[:]
                    cand[i] = tv
                    ns_ = sc_of(cand)
                    if ns_ > cs:
                        cur = sorted(set(cand))
                        cs = ns_
                        improved = True
                        break
                if improved:
                    break
            # Try adding an element (fills sums collinearly / boosts diffs).
            if len(cur) < 4000:
                adds = set()
                c = (lo + hi) // 2
                adds.add(c)
                for _ in range(6):
                    j = rng.randrange(len(cur))
                    kk = rng.randrange(len(cur))
                    adds.add(cur[j] + cur[kk] - rng.choice(cur))
                for _ in range(4):
                    adds.add(rng.randint(lo, hi))
                for av in adds:
                    if av in cur:
                        continue
                    cand = cur + [av]
                    ns_ = sc_of(cand)
                    if ns_ > cs:
                        cur = sorted(set(cand))
                        cs = ns_
                        improved = True
                        break
            # Try removing an element.
            if len(cur) > 10:
                for i in rng.sample(range(len(cur)), min(8, len(cur))):
                    cand = cur[:i] + cur[i + 1:]
                    ns_ = sc_of(cand)
                    if ns_ > cs:
                        cur = cand
                        cs = ns_
                        improved = True
                        break
        return cur, cs

    # Refine the best few seeds, then run multiple randomized restarts.
    order = sorted(seeds, key=lambda s: -_score(s))[:5] if seeds else []
    per = max(1, (deadline - time.time()) / max(1, len(order) + 3))
    for s in order:
        if time.time() > deadline - 5:
            break
        b, bs = refine(s, min(per, deadline - time.time()))
        if bs > best_score:
            best_score, best = bs, b[:]

    # Randomized restarts around best.
    while time.time() < deadline - 2:
        if best is None:
            break
        base = [x + rng.randint(-2, 2) for x in best]
        b, bs = refine(base, min(10, deadline - time.time()))
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best)) if best else [0, 1]
# EVOLVE-BLOCK-END
