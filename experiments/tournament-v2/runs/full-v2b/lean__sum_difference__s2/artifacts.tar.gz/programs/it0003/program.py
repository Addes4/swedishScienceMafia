# EVOLVE-BLOCK-START
"""Randomized hill-climb / simulated annealing over small integer sets.

We maximise log|A-A| / log|A+A| (+ tiny size bonus).  Rather than a rigid
algebraic construction, we search directly for sets of integers whose
difference set is large and sum set is small, using many restarts with
simulated annealing.
"""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1:
        return 0.0, ld, ls
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100, ld, ls


def _scount(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    ld = len(diffs)
    ls = len(sums)
    if ls <= 1:
        return 0.0
    return math.log(ld) / math.log(ls) + (1 - 1 / n) / 100


def solve():
    best = [7, 15, 18, 22, -3, -2]
    best_score = _scount(best)

    rng = random.Random(12345)
    deadline = time.time() + 110.0

    # Ground range and target sizes to explore.
    configs = []
    for n in (6, 7, 8, 9, 10, 11, 12):
        configs.append((n, 3 * n))
        configs.append((n, 4 * n))
        configs.append((n, 6 * n))

    while time.time() < deadline:
        n, span = rng.choice(configs)
        # Seed a random set with distinct integers in [0, span].
        vals = rng.sample(range(0, span + 1), min(n, span + 1))
        cur = vals
        cur_score = _scount(cur)
        T = 0.05
        for step in range(4000):
            if time.time() > deadline:
                break
            cand = cur[:]
            op = rng.random()
            if op < 0.7:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-3, -2, -1, 1, 2, 3])
                if cand[i] in cand[:i] + cand[i + 1:]:
                    continue
            elif op < 0.9 and len(cand) < 14:
                v = rng.randint(0, span)
                if v in cand:
                    continue
                cand.append(v)
            elif len(cand) > 5:
                i = rng.randrange(len(cand))
                cand.pop(i)
            else:
                continue
            s = _scount(cand)
            if s >= cur_score or rng.random() < math.exp((s - cur_score) / max(T, 1e-9)):
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s
            T *= 0.9995
            if T < 1e-4:
                T = 1e-4
    return sorted(set(best))
# EVOLVE-BLOCK-END
