# EVOLVE-BLOCK-START
"""Sidon-seeded full-budget simulated annealing on the true objective."""
import math
import random
import time
import numpy as np


def _counts(a):
    a = np.asarray(sorted(set(a)), dtype=np.int64)
    n = a.shape[0]
    if n < 2:
        return 0, 0
    d = a[:, None] - a[None, :]
    s = a[:, None] + a[None, :]
    nd = np.unique(d).shape[0]
    ns = np.unique(s).shape[0]
    return nd, ns


def _score_from_counts(nd, ns, n):
    if ns <= 1 or nd <= 1:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(a):
    nd, ns = _counts(a)
    return _score_from_counts(nd, ns, len(set(a)))


def _bose_chowla(p, n):
    """Sidon set mod p via Bose-Chowla: {theta^i - i mod p} lifted to ints."""
    if p < 3:
        return list(range(n))
    # find primitive root g mod p
    factors = []
    m = p - 1
    d = 2
    while d * d <= m:
        if m % d == 0:
            factors.append(d)
            while m % d == 0:
                m //= d
        d += 1
    if m > 1:
        factors.append(m)
    g = 2
    while True:
        if all(pow(g, (p - 1) // f, p) != 1 for f in factors):
            break
        g += 1
    theta = g % p
    res = []
    pw = 1
    for i in range(n):
        res.append((pw - i) % p)
        pw = (pw * theta) % p
    return res


def solve():
    deadline = time.time() + 115
    rng = random.Random(12345)
    np_rng = np.random.default_rng(12345)

    # --- seed: Bose-Chowla Sidon lifted with a large multiplier to spread ints ---
    best = None
    best_score = -1.0

    for p in (43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151):
        for k in (15, 20, 25, 30, 35, 40):
            if k >= p:
                continue
            bc = _bose_chowla(p, k)
            for scale in (1, 3, 10):
                a = sorted(set(int(x) * scale for x in bc))
                s = _score(a)
                if s > best_score:
                    best_score = s
                    best = a[:]
        if time.time() > deadline:
            break

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    cur = best[:]
    cur_score = best_score

    # --- full-budget simulated annealing ---
    while time.time() < deadline:
        T = max(1e-4, 0.05 * (1.0 - (time.time() - (deadline - 115)) / 115.0))
        cand = cur[:]
        r = rng.random()
        if r < 0.45 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-3, 3)
        elif r < 0.65:
            cand.append(rng.randint(-50, 50))
        elif r < 0.80 and len(cand) > 3:
            del cand[rng.randrange(len(cand))]
        elif r < 0.92 and cand:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-10, -7, -5, 5, 7, 10, -20, 20])
        else:
            if cand:
                i = rng.randrange(len(cand))
                cand[i] = rng.randint(-100, 100)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        if len(cand) > 300:
            continue
        nd, ns = _counts(cand)
        s = _score_from_counts(nd, ns, len(cand))
        if s >= cur_score or rng.random() < math.exp((s - cur_score) / max(T, 1e-6)):
            cur = cand
            cur_score = s
            if s > best_score:
                best_score = s
                best = cand[:]
        if rng.random() < 0.01:
            cur = best[:]
            cur_score = best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
