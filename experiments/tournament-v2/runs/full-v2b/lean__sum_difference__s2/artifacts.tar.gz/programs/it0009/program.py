import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _bose_chowla(p):
    # Sidon set mod p: {2pk + k^2 mod p : k in Z_p} shifted into 0..p-1
    s = set()
    for k in range(p):
        s.add((2 * p * k + k * k) % p)
    return sorted(s)


def gross(a):
    a = set(a)
    d = len({x - y for x in a for y in a})
    s = len({x + y for x in a for y in a})
    return d, s


def solve():
    t0 = time.time()
    deadline = t0 + 100

    # Find a prime p giving a Sidon set of size ~ sqrt(p) near a good target.
    def is_prime(n):
        if n < 2:
            return False
        i = 2
        while i * i <= n:
            if n % i == 0:
                return False
            i += 1
        return True

    target = 1600  # size of Sidon set ~ p^0.5
    p = target * target
    while not is_prime(p):
        p += 1

    base = _bose_chowla(p)  # size p, but only first ~sqrt needed; take subset

    # Take a subset of the Sidon set (full set is size p ~ 2.5M, too big).
    # Actually Sidon set mod p has size ~sqrt(p) when built differently.
    # Build B_2 set of size ~sqrt(p) properly.
    def sidon_sqrt(q):
        # {2qk + k^2 : k=0..m-1} with m ~ sqrt(q) is Sidon in integers, use directly.
        m = int(math.isqrt(q))
        return [2 * q * k + k * k for k in range(m)]

    # Use a large modulus so the lifted values are spread widely.
    q = 50000
    n = 300
    S = [2 * q * k + k * k for k in range(n)]  # Sidon in integers, spread by q

    # Scale so differences stay distinct while sums collide a little.
    A = S[:]

    best = A[:]
    bs = _score(best)

    # Light local search: only tweak to reduce sums without hurting differences.
    cur = A[:]
    while time.time() < deadline:
        i = random.randrange(len(cur))
        old = cur[i]
        delta = random.randint(-3, 3)
        if delta == 0:
            continue
        cur[i] = old + delta
        s = _score(cur)
        if s >= bs:
            bs = s
            best = cur[:]
        else:
            cur[i] = old

    return sorted(set(best))
