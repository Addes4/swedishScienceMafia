# EVOLVE-BLOCK-START
"""Sidon core plus explicit sum-collapsing polish to maximize log|A-A|/log|A+A|."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    nd = len(np.unique(arr[:, None] - arr[None, :]))
    ns = len(np.unique(arr[:, None] + arr[None, :]))
    return nd, ns


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _sum_polish(A, tlimit, rng, max_steps=20000):
    """Greedy: try to reduce |A+A| while keeping |A-A| from dropping much."""
    cur = sorted(set(A))
    nd, ns = _counts(cur)
    best = cur[:]
    best_nd, best_ns = nd, ns
    step = 0
    while time.time() < tlimit and step < max_steps:
        step += 1
        cand = cur[:]
        op = rng.random()
        if op < 0.5:
            # shift an element toward the centroid to force sum collisions
            i = rng.randrange(len(cand))
            c = int(np.mean(cand))
            cand[i] = c + rng.randint(-3, 3) if rng.random() < 0.5 else c
        elif op < 0.75:
            # reflect an element about an existing one (keeps split diffs)
            i = rng.randrange(len(cand))
            j = rng.randrange(len(cand))
            cand[i] = 2 * cand[j] - cand[i]
        else:
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-1, 1]) * rng.randint(1, 5)
        cand = sorted(set(cand))
        if len(cand) < 3 or len(cand) > 4000:
            continue
        nd2, ns2 = _counts(cand)
        if ns2 == 0:
            continue
        s_old = math.log(nd) / math.log(ns) if ns > 1 else 0.0
        s_new = math.log(nd2) / math.log(ns2) if ns2 > 1 else 0.0
        if s_new >= s_old or (ns2 <= ns and nd2 >= nd - 2):
            cur, nd, ns = cand, nd2, ns2
            if s_new > (math.log(best_nd) / math.log(best_ns) if best_ns > 1 else 0.0):
                best, best_nd, best_ns = cand[:], nd2, ns2
    return best


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(20240817)

    seeds = []
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        spread = hi - lo
        for k in [1, 2, 3, 4, 5, 6, 7, 8]:
            if k * nb > 4000 or k * nb < 12:
                continue
            for mult in [0.2, 0.5, 0.8, 1.0, 1.2, 1.6, 2.0, 3.0]:
                M = max(2, int((spread + 1) * mult))
                A = []
                for i in range(k):
                    off = i * M
                    for b in B:
                        A.append(off + b)
                seeds.append(A)

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    # polish the best few seeds with the sum-collapsing local search
    seeds.sort(key=lambda s: _score(s), reverse=True)
    idx = 0
    while time.time() < deadline:
        if idx < min(6, len(seeds)):
            base = seeds[idx]
            idx += 1
        else:
            if best is None:
                break
            base = [x + rng.randint(-3, 3) for x in best]
        tlimit = min(deadline, time.time() + 12)
        cand = _sum_polish(base, tlimit, rng)
        sc = _score(cand)
        if sc > best_score:
            best_score, best = sc, cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
