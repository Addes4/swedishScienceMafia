# EVOLVE-BLOCK-START
"""Block-product over Bose-Chowla Sidon sets, fine spacing sweep + fast greedy."""
import math
import random
import time


def _counts(a):
    s = set(a)
    diffs = set()
    sums = set()
    la = list(s)
    n = len(la)
    for i in range(n):
        ai = la[i]
        for j in range(i, n):
            aj = la[j]
            s2 = ai + aj
            sums.add(s2)
            d = ai - aj
            diffs.add(d)
            diffs.add(-d)
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0
    rng = random.Random(20240517)

    seeds = []
    # Fine sweep of spacing near/below the B+B collision threshold.
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        nb = len(B)
        lo, hi = min(B), max(B)
        rngb = hi - lo
        baseM = rngb + 1
        for k in [2, 3, 4, 5, 6, 7, 8]:
            if k * nb > 4000 or k * nb < 30:
                continue
            # sweep spacing from very tight to wide on a fine grid
            for mult in [0.02, 0.05, 0.08, 0.12, 0.18, 0.25, 0.35, 0.5, 0.65,
                         0.8, 0.95, 1.0, 1.05, 1.1, 1.2, 1.35, 1.5, 1.8, 2.2, 3.0]:
                M = max(2, int(baseM * mult))
                seeds.append(_build(B, k, M))
            # also absolute tight spacing values
            for M in [2, 3, 4, 5, 7, 10, 15, 20, 30, 50]:
                if k * nb <= 4000 and k * nb >= 30:
                    seeds.append(_build(B, k, M))

    # dedup seeds
    seen = set()
    uniq_seeds = []
    for s in seeds:
        key = tuple(sorted(set(s)))
        if key not in seen:
            seen.add(key)
            uniq_seeds.append(list(key))
    seeds = uniq_seeds

    tc = time.time()
    for s in seeds:
        if time.time() > tc + 40:
            break
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    def greedy(base, tlimit):
        cur = sorted(set(base))
        cs = _score(cur)
        best_local, best_local_s = cur[:], cs
        stall = 0
        while time.time() < tlimit and stall < 1500:
            improved = False
            n = len(cur)
            if n < 2:
                break
            # try removing elements that most reduce |A+A| relative to |A-A|
            for trial in range(min(n, 25)):
                i = rng.randrange(len(cur))
                cand = cur[:i] + cur[i + 1:]
                if len(cand) < 3:
                    continue
                s = _score(cand)
                if s > cs:
                    cur, cs = sorted(cand), s
                    improved = True
                    if s > best_local_s:
                        best_local, best_local_s = cur[:], s
                    break
            if improved:
                stall = 0
                continue
            # try small shifts of individual elements
            for trial in range(min(n, 30)):
                i = rng.randrange(len(cur))
                for delta in (rng.randint(-40, 40), rng.randint(-4, 4)):
                    cand = cur[:]
                    cand[i] += delta
                    cand = sorted(set(cand))
                    if len(cand) < 3:
                        continue
                    s = _score(cand)
                    if s > cs:
                        cur, cs = cand, s
                        improved = True
                        if s > best_local_s:
                            best_local, best_local_s = cand[:], s
                        break
                if improved:
                    break
            if not improved:
                stall += 1
        return best_local, best_local_s

    # greedy polish on top seeds
    top = sorted(seeds, key=lambda s: _score(s) if len(s) <= 500 else -1, reverse=True)[:12]
    for base in top:
        if time.time() > deadline - 10:
            break
        tlimit = min(deadline - 5, time.time() + 12)
        b, bs = greedy(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    # random restarts on the very best structure (perturbation)
    while time.time() < deadline - 2:
        if best is None:
            break
        base = [x + rng.randint(-6, 6) for x in best]
        base = sorted(set(base))
        tlimit = min(deadline - 1, time.time() + 8)
        b, bs = greedy(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
