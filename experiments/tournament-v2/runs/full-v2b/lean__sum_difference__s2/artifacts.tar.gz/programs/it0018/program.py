# EVOLVE-BLOCK-START
"""Construction: A = { i*M + j : i in S, j in T } (product of a Sidon-ish outer set S
and an inner interval-ish set T), maximizing log|A-A|/log|A+A| via block structure."""
import math


def _score(a):
    a = list(set(a))
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _sidon(n):
    """Build a Sidon set of size ~n using greedy over small integers (B_2 set)."""
    S = []
    used_diff = set()
    x = 0
    while len(S) < n:
        ok = True
        for s in S:
            d = abs(x - s)
            if d in used_diff:
                ok = False
                break
        if ok:
            for s in S:
                used_diff.add(abs(x - s))
            S.append(x)
        x += 1
    return S


def solve():
    """Return A with large difference set and small sum set."""
    best = None
    best_score = -1.0

    # Try product construction over several sizes.
    for n_s in (2, 3, 4, 5, 6, 7, 8, 10, 12, 16, 20, 25, 30, 40):
        S = _sidon(n_s)
        for n_t in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20):
            if n_s * n_t > 4000:
                continue
            # Separation M: large enough that blocks S don't overlap sums weirdly,
            # but small enough that cross-block sums collide.
            span_S = max(S) - min(S) if len(S) > 1 else 0
            for M in (span_S + 1, 2 * (span_S + 1), 4 * (span_S + 1)):
                if M < 1:
                    M = 1
                T = list(range(n_t))
                A = [i * M + j for i in S for j in T]
                if len(set(A)) != len(A):
                    continue
                sc = _score(A)
                if sc > best_score:
                    best_score = sc
                    best = A

    # Fallback baseline if nothing found.
    if best is None:
        best = [7, 15, 18, 22, -3, -2]
    return sorted(set(best))
# EVOLVE-BLOCK-END
