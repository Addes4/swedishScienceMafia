# EVOLVE-BLOCK-START
"""Find A with large |A-A| and small |A+A| via greedy seeds + simulated annealing."""
import math
import random
import time
import numpy as np


def _counts(a):
    x = np.asarray(a, dtype=np.int64)
    d = np.unique(np.subtract.outer(x, x))
    s = np.unique(np.add.outer(x, x))
    return int(d.size), int(s.size)


def _obj(a):
    n = len(a)
    if n < 2:
        return -1e9
    nd, ns = _counts(a)
    if nd < 2 or ns < 2:
        return -1e9
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _greedy(n, C, deadline):
    """Build a set element-by-element, each time adding the element (sampled from a
    pool) that most improves the exact objective."""
    A = [0]
    used = {0}
    while len(A) < n and time.time() < deadline:
        bestx = None
        bestv = -1e9
        for _ in range(150):
            x = random.randint(-C, C)
            if x in used:
                continue
            v = _obj(A + [x])
            if v > bestv:
                bestv = v
                bestx = x
        if bestx is None:
            break
        A.append(bestx)
        used.add(bestx)
    return A


def solve():
    random.seed(987654321)
    np.random.seed(987654321)
    deadline = time.time() + 110.0

    best = [7, 15, 18, 22, -3, -2]
    best_obj = _obj(best)
    pool = {}

    while time.time() < deadline:
        n = random.randint(6, 22)
        C = max(12, 4 * n * n)

        r = random.random()
        if r < 0.35:
            cur = _greedy(n, C, deadline)
        elif n in pool and r < 0.7:
            cur = pool[n][:]
        else:
            cur = random.sample(range(-C, C + 1), n)

        if len(cur) < 6:
            continue
        cur_obj = _obj(cur)

        iters = 2500
        for it in range(iters):
            if time.time() > deadline:
                break
            T = 0.03 * (1.0 - it / iters) + 1e-4
            cand = cur[:]
            i = random.randrange(len(cand))
            m = random.random()
            if m < 0.4:
                cand[i] += random.choice((-2, -1, 1, 2))
            elif m < 0.8:
                cand[i] = random.randint(-C, C)
            else:
                # larger structural jumps
                cand[i] = random.choice((-C, C)) + random.randint(-5, 5)
            if len(set(cand)) < len(cand):
                continue
            co = _obj(cand)
            if co > cur_obj or random.random() < math.exp((co - cur_obj) / T):
                cur = cand
                cur_obj = co
                if co > best_obj:
                    best_obj = co
                    best = cand[:]

        pool[n] = cur[:]
        if cur_obj > best_obj:
            best_obj = cur_obj
            best = cur[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
