# EVOLVE-BLOCK-START
"""Block-product over Bose-Chowla Sidon sets: fine sweep at the sum-collision
threshold with a fast numpy scorer and a bounded greedy polish."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _build(B, k, M):
    A = []
    for i in range(k):
        off = i * M
        for b in B:
            A.append(off + b)
    return A


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0
    rng = random.Random(1234567)

    # Collect Sidon bases (keep sizes modest so scoring stays cheap).
    bases = []
    for p in [29, 53, 101, 211, 401, 809]:
        B = _bose_chowla(p)
        # normalize so min element is 0 for tighter packing
        B = [b - min(B) for b in B]
        bases.append(B)

    seeds = []
    for B in bases:
        nb = len(B)
        spread = max(B) - min(B)
        baseM = spread + 1
        # fine sweep around the sum-collision threshold
        for k in [2, 3, 4, 5, 6, 7]:
            if k * nb > 2200 or k * nb < 16:
                continue
            for frac in [0.02, 0.05, 0.1, 0.2, 0.3, 0.45, 0.6, 0.8, 1.0, 1.3, 1.7, 2.2]:
                M = max(2, int(baseM * frac))
                seeds.append(_build(B, k, M))

    # Score all seeds quickly, keep the top ones.
    scored = []
    for s in seeds:
        scored.append((_score(s), s))
    scored.sort(key=lambda x: -x[0])

    if scored:
        best_score, best = scored[0][0], scored[0][1][:]

    # Greedy polish on the most promising seeds.
    top = [s for _, s in scored[:80]]

    def polish(base, tlimit):
        cur = base[:]
        cs = _score(cur)
        bl, bs = cur[:], cs
        steps = 0
        while time.time() < tlimit and steps < 6000:
            steps += 1
            cand = cur[:]
            r = rng.random()
            if r < 0.5 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.randint(-8, 8)
            elif r < 0.8 and cand:
                i = rng.randrange(len(cand))
                cand[i] += rng.choice([-1, 1]) * rng.randint(10, 400)
            else:
                if cand:
                    cand.append(rng.choice(cand) + rng.randint(-40, 40))
            cand = sorted(set(cand))
            if not (3 <= len(cand) <= 4000):
                continue
            s = _score(cand)
            if s > cs:
                cur, cs = cand, s
                if s > bs:
                    bl, bs = cand[:], s
        return bl, bs

    idx = 0
    while time.time() < deadline:
        if idx < len(top):
            base = top[idx]
            idx += 1
        else:
            if top and rng.random() < 0.8:
                base = [x + rng.randint(-6, 6) for x in rng.choice(top)]
            else:
                base = [rng.randint(-5000, 5000) for _ in range(rng.randint(20, 120))]
            base = sorted(set(base))
        tlimit = min(deadline, time.time() + 8)
        b, bs = polish(base, tlimit)
        if bs > best_score:
            best_score, best = bs, b[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
