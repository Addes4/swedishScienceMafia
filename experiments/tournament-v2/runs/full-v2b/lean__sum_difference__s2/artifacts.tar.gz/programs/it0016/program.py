# EVOLVE-BLOCK-START
"""Geometric-block Sidon construction with direct ratio cleanup.

Idea
----
A Sidon set S (all pairwise sums distinct) already gives |S-S| ~ |S|^2 and
|S+S| ~ |S|^2, so the ratio is ~1.  To push the ratio above 1 we want
  * |A-A| large     -> many distinct differences,
  * |A+A| small     -> heavy collapsing of sums.

The construction below takes several *translated copies* of a Sidon set,
A = union_{i=0}^{m-1} ( S + i*G ).
Choosing G very large keeps all differences of different blocks distinct,
which makes |A-A| almost m^2 * |S-S| (near the maximum possible).
But sums a+b with a in block i and b in block j land in block i+j, so the
number of distinct sums is only O(m * |S+S|) instead of O(m^2 * |S+S|).
That is exactly the desired asymmetry.

A short, strictly time-bounded local search then polishes the set directly
against the true objective.
"""
import math
import random
import time

try:
    import numpy as np
    _HAVE_NP = True
except Exception:                                    # pragma: no cover
    _HAVE_NP = False


# ----------------------------------------------------------------------
# fast exact evaluation
# ----------------------------------------------------------------------
def _counts(a):
    """Return (|A-A|, |A+A|, |A|) for a list of distinct ints."""
    if _HAVE_NP:
        v = np.asarray(sorted(set(int(x) for x in a)), dtype=np.int64)
        n = v.size
        if n < 2:
            return 0, 0, n
        d = v[:, None] - v[None, :]
        s = v[:, None] + v[None, :]
        return int(np.unique(d).size), int(np.unique(s).size), n
    v = sorted(set(a))
    n = len(v)
    diffs = {x - y for x in v for y in v}
    sums = {x + y for x in v for y in v}
    return len(diffs), len(sums), n


def _score(a):
    nd, ns, n = _counts(a)
    if n < 2 or ns < 2:
        return -1e18
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


# ----------------------------------------------------------------------
# Sidon base set: a prime-field Sidon set lifted to integers
# ----------------------------------------------------------------------
def _is_prime(x):
    if x < 2:
        return False
    if x % 2 == 0:
        return x == 2
    i = 3
    while i * i <= x:
        if x % i == 0:
            return False
        i += 2
    return True


def _sidon_mod(q):
    """Bose-Chowla Sidon set modulo prime q: {2*i*q + (i^2 % q)}."""
    s = set()
    for i in range(q):
        s.add((2 * i * q + (i * i) % q) % (q * q + q - 1) if False else 2 * i * q + (i * i) % q)
    return sorted(s)


def _base_sidon(q):
    """Bose-Chowla Sidon set of size ~ q, values < 2*q^2."""
    return [2 * i * q + (i * i) % q for i in range(q)]


# ----------------------------------------------------------------------
# geometric-block construction
# ----------------------------------------------------------------------
def _construct(n_elements, seed=12345):
    """Build A as m translated copies of a Sidon set S, sizes ~ matched."""
    base = [3, -1, 7, 0, 11, -5, 15, 2, 19, -9, 23, 5, 27, -13, 31, 8]
    base = sorted(set(base))
    # choose q so that m * q ~ n_elements
    best = None
    best_score = -1e18
    rng = random.Random(seed)
    for q in (5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59,
              61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113):
        S = _base_sidon(q)
        S = sorted(set(S))
        for m in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32):
            if m * len(S) > 3500:
                continue
            spread = max(S) - min(S)
            # G must separate the different copies so differences stay distinct
            G = spread + 1
            A = []
            for i in range(m):
                A.extend(x + i * G for x in S)
            A = sorted(set(A))
            sc = _score(A)
            if sc > best_score:
                best_score, best = sc, A
    return best, best_score


# ----------------------------------------------------------------------
# direct local cleanup, time bounded
# ----------------------------------------------------------------------
def _hill_climb(A, deadline, seed=999):
    rng = random.Random(seed)
    A = sorted(set(int(x) for x in A))
    cur = A[:]
    cur_score = _score(cur)
    best = cur[:]
    best_score = cur_score
    step = 1
    while time.time() < deadline:
        cand = cur[:]
        r = rng.random()
        if r < 0.55 and len(cand) >= 2:
            # perturb one element
            i = rng.randrange(len(cand))
            cand[i] += rng.choice([-step, step, -1, 1, -2, 2])
        elif r < 0.75:
            # add an element
            cand.append(rng.randint(-5, max(cand) + 5))
        elif r < 0.90 and len(cand) > 4:
            # remove an element
            del cand[rng.randrange(len(cand))]
        else:
            # shift a whole block / large jump
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-step * 10, step * 10)
        cand = sorted(set(cand))
        if len(cand) < 4 or len(cand) > 3999:
            continue
        sc = _score(cand)
        if sc > best_score:
            best_score, best, cur, cur_score = sc, cand[:], cand, sc
            step = 1
        elif sc >= cur_score:
            cur, cur_score = cand, sc
            step = 1
        else:
            step = min(step + 1, 64)
            if rng.random() < 0.15:
                cur, cur_score = best[:], best_score
    return best


def solve():
    deadline = time.time() + 110.0
    A, _ = _construct(600)
    if A is None:
        A = sorted(set([7, 15, 18, 22, -3, -2]))

    # a couple of cheap refinements around the construction
    best = _hill_climb(A, min(time.time() + 45.0, deadline))

    # second phase: shrink the sum set by aligning a small perturbation
    remaining = deadline - time.time()
    if remaining > 5:
        best = _hill_climb(best, deadline)

    best = sorted(set(int(x) for x in best))
    if len(best) < 2:
        best = [1, 2]
    return best
# EVOLVE-BLOCK-END
