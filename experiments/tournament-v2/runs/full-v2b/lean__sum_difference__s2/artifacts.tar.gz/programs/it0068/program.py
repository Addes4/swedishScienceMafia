# EVOLVE-BLOCK-START
"""Dilated Bose-Chowla Sidon sets: distinct differences, clustered sums."""
import math
import random
import time

import numpy as np


def _counts(a):
    arr = np.array(a, dtype=np.int64)
    diffs = np.unique(arr[:, None] - arr[None, :])
    sums = np.unique(arr[:, None] + arr[None, :])
    return len(diffs), len(sums)


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    nd, ns = _counts(a)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _is_prim_root(g, p):
    n = p - 1
    facs = set()
    m = n
    d = 2
    while d * d <= m:
        while m % d == 0:
            facs.add(d)
            m //= d
        d += 1
    if m > 1:
        facs.add(m)
    for q in facs:
        if pow(g, n // q, p) == 1:
            return False
    return True


def _bose_chowla(p):
    g = 2
    while not _is_prim_root(g, p):
        g += 1
    return [pow(g, i, p) for i in range(1, p)]


def _dilate(B, k, c):
    B = sorted(B)
    lo = B[0]
    core = [b - lo for b in B]
    A = []
    f = 1
    for _ in range(k):
        for x in core:
            A.append(f * x)
        f *= c
    return A


def solve():
    deadline = time.time() + 112
    best = None
    best_score = -1.0

    seeds = []
    for p in [29, 53, 101, 211]:
        B = _bose_chowla(p)
        nb = len(B)
        for k in [2, 3, 4, 5, 6, 8, 10, 12, 16, 20]:
            if k * nb > 4000 or k * nb < 20:
                continue
            for c in [2, 3, 4, 5, 7, 11, 17, 31, 61, 127]:
                seeds.append(_dilate(B, k, c))

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best_score, best = sc, s[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
