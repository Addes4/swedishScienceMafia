# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid layouts + greedy inflate + SLSQP polish."""
import math
import random


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _feasible(s):
    m = len(s)
    for (cx, cy, a, si) in s:
        if si < -1e-12 or cx - si / 2 < -1e-9 or cx + si / 2 > 1 + 1e-9 \
           or cy - si / 2 < -1e-9 or cy + si / 2 > 1 + 1e-9:
            return False
    for i in range(m):
        x1, y1, _, s1 = s[i]
        for j in range(i + 1, m):
            x2, y2, _, s2 = s[j]
            if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
               abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _refine(sq, n, rounds=80, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                               (0.003, 0.003), (-0.003, -0.003),
                               (0.003, -0.003), (-0.003, 0.003)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 400:
            step = len(comps) // 400 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
    return cands


def _sep_axes(cx, cy, a, s):
    """Return the two edge normals (separating axes) of a rotated square."""
    t = a * 2.0 * math.pi
    c, sn = math.cos(t), math.sin(t)
    # axis 1: (c, sn); axis 2: (-sn, c)
    return (c, sn), (-sn, c)


def _slsqp_polish(sq, n, maxiter=200):
    """Jointly optimize centres, sides, angles to maximise sum sides."""
    try:
        import numpy as np
        from scipy.optimize import minimize
    except Exception:
        return sq

    sq = [list(q) for q in sq]
    x0 = np.array([v for q in sq for v in q], dtype=float)

    def blocks(x):
        X = x.reshape(n, 4)
        return X

    def neg_obj(x):
        return -np.sum(x.reshape(n, 4)[:, 3])

    # constraints: for each pair, separation along at least one axis
    # and box constraints on centres to keep squares in unit square.
    # Use a smooth formulation: for each pair i<j, we require
    #   max over 4 axes of (proj_i + proj_j) <= dist along that axis.
    # Instead model: along both squares' edge normals we need
    #   |proj_ij| >= r_i + r_j, where proj uses axis direction and
    #   r = s/2 * (|cos| + |sin|) support function.
    def support(q, ax, ay):
        t = q[2] * 2.0 * math.pi
        c, sn = math.cos(t), math.sin(t)
        # support radius of square side s along unit dir (ax, ay)
        u = abs(c * ax + sn * ay)
        v = abs(-sn * ax + c * ay)
        return q[3] * 0.5 * (u + v)

    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]

    def con_pair(x, i, j):
        X = x.reshape(n, 4)
        qi, qj = X[i], X[j]
        dx = qi[0] - qj[0]
        dy = qi[1] - qj[1]
        # try axes: edge normals of i and of j
        axes = list(_sep_axes(qi[0], qi[1], qi[2], qi[3])) + \
               list(_sep_axes(qj[0], qj[1], qj[2], qj[3]))
        slack = -1e9
        for ax, ay in axes:
            proj = dx * ax + dy * ay
            r = support(qi, ax, ay) + support(qj, ax, ay)
            slack = max(slack, abs(proj) - r)
        return slack

    constraints = []
    for (i, j) in pairs:
        constraints.append(
            {'type': 'ineq', 'fun': (lambda x, i=i, j=j: con_pair(x, i, j))}
        )

    # box bounds: centres within [s/2, 1-s/2], side in [0, 1], angle free
    # We rely on the greedy start being feasible; add centre bounds loosely.
    class Bounds:
        pass

    # We wrap bounds via constraints on centres + sides to be safe.
    def center_lb(x, idx):
        X = x.reshape(n, 4)
        return X[idx, 0] - X[idx, 3] * 0.5

    def center_ub(x, idx):
        X = x.reshape(n, 4)
        return 1.0 - X[idx, 0] - X[idx, 3] * 0.5

    def cylb(x, idx):
        X = x.reshape(n, 4)
        return X[idx, 1] - X[idx, 3] * 0.5

    def cyub(x, idx):
        X = x.reshape(n, 4)
        return 1.0 - X[idx, 1] - X[idx, 3] * 0.5

    for idx in range(n):
        constraints.append({'type': 'ineq',
                            'fun': (lambda x, idx=idx: center_lb(x, idx))})
        constraints.append({'type': 'ineq',
                            'fun': (lambda x, idx=idx: center_ub(x, idx))})
        constraints.append({'type': 'ineq',
                            'fun': (lambda x, idx=idx: cylb(x, idx))})
        constraints.append({'type': 'ineq',
                            'fun': (lambda x, idx=idx: cyub(x, idx))})

    try:
        res = minimize(neg_obj, x0, method='SLSQP', constraints=constraints,
                       options={'maxiter': maxiter, 'ftol': 1e-10})
        if res.success or res.fun < neg_obj(x0) - 1e-9:
            X = res.x.reshape(n, 4)
            out = [tuple(float(v) for v in row) for row in X]
            # validate
            ok = True
            for (cx, cy, a, si) in out:
                if si < -1e-9 or si > 1 + 1e-6:
                    ok = False
                    break
                if cx - si / 2 < -1e-6 or cx + si / 2 > 1 + 1e-6:
                    ok = False
                    break
                if cy - si / 2 < -1e-6 or cy + si / 2 > 1 + 1e-6:
                    ok = False
                    break
            if ok:
                for (i, j) in pairs:
                    if con_pair(res.x, i, j) < -1e-4:
                        ok = False
                        break
            if ok:
                return out
    except Exception:
        pass
    return sq


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 12)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=40, seed=999)

    # SLSQP continuous polish (best-effort; ignored on failure)
    polished = _slsqp_polish(best, n, maxiter=250)
    if polished is not None and _total(polished) > _total(best) + 1e-9:
        # re-run greedy refiner from polished layout to clean up
        cleaned = _refine(polished, n, rounds=30, seed=321)
        if _total(cleaned) > _total(best):
            best = cleaned
        else:
            best = polished

    return best[:n]
# EVOLVE-BLOCK-END
