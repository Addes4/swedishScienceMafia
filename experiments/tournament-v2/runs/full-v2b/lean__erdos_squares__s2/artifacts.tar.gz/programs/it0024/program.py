# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid/diagonal layouts + strong inflate
refiner (axis-aligned) plus a rotation-aware polish stage using a correct
separating-axis (SAT) collision test for possibly-rotated squares."""
import math
import random


def _make_layout(n, counts):
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _diagonal_layout(n, counts):
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    total_h = sum(heights)
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        shift = (y / max(total_h, 1e-9)) * (1.0 - c * s)
        xoff = shift
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            if cx - s / 2 < -1e-9 or cx + s / 2 > 1 + 1e-9:
                cx = min(max(cx, s / 2), 1 - s / 2)
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _corners(cx, cy, a, s):
    """Return the 4 corners of a square (centre, angle fraction of turn, side)."""
    th = a * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s / 2.0
    pts = []
    for ux, uy in ((1, 1), (1, -1), (-1, -1), (-1, 1)):
        px = h * (ux * c - uy * sn) + cx
        py = h * (ux * sn + uy * c) + cy
        pts.append((px, py))
    return pts


def _inside_unit(pts, s):
    for x, y in pts:
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _axes(pts):
    """Edge normals (2 per square for a rotated square are enough: use both
    edge directions)."""
    ax = []
    for i in range(2):
        x1, y1 = pts[i]
        x2, y2 = pts[i + 1]
        ex, ey = x2 - x1, y2 - y1
        n = math.hypot(ex, ey)
        if n > 1e-12:
            ax.append((-ey / n, ex / n))
    return ax


def _overlap(p1, p2):
    """Separating axis test: return True if the two convex quads overlap."""
    axes = _axes(p1) + _axes(p2)
    for ax, ay in axes:
        min1 = min(x * ax + y * ay for x, y in p1)
        max1 = max(x * ax + y * ay for x, y in p1)
        min2 = min(x * ax + y * ay for x, y in p2)
        max2 = max(x * ax + y * ay for x, y in p2)
        if max1 < min2 + 1e-9 or max2 < min1 + 1e-9:
            return False
    return True


def _feasible(s):
    m = len(s)
    corners = []
    for (cx, cy, a, si) in s:
        if si < -1e-12 or cx < -1e-9 or cx > 1 + 1e-9 \
           or cy < -1e-9 or cy > 1 + 1e-9:
            return False
        pts = _corners(cx, cy, a, si)
        if not _inside_unit(pts, si):
            return False
        corners.append(pts)
    for i in range(m):
        for j in range(i + 1, m):
            if _overlap(corners[i], corners[j]):
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _refine(sq, n, rounds=80, seed=12345):
    """Axis-aligned greedy inflate refiner."""
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                               (0.003, 0.003), (-0.003, -0.003),
                               (0.003, -0.003), (-0.003, 0.003)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _refine_rot(sq, n, rounds=40, seed=4242):
    """Rotation-aware greedy refiner: tries small angle changes along with
    growth and position tweaks, to find tilted interlocking layouts."""
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    angles = (0.0, 0.125, 0.0625, -0.0625, 0.25, -0.25, 0.03125, -0.03125,
              0.1875, -0.1875, 0.375, -0.375)
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.04, 0.02, 0.01, 0.005, 0.002, 0.001, 0.0005):
                ns = si + grow
                # try a few angle shifts together with the smallest position fix
                tried = False
                for da in angles:
                    na = a + da
                    pts = _corners(cx, cy, na, ns)
                    if not _inside_unit(pts, si):
                        continue
                    cand = cur[:i] + [[cx, cy, na, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        tried = True
                        break
                if tried:
                    break
                # also try repositioning
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for da in angles:
                    na = a + da
                    for dx, dy in cands:
                        pts = _corners(cx + dx, cy + dy, na, ns)
                        if not _inside_unit(pts, si):
                            continue
                        cand = cur[:i] + [[cx + dx, cy + dy, na, ns]] + cur[i + 1:]
                        if _feasible(cand):
                            cur = cand
                            grew = True
                            improved = True
                            break
                    if grew:
                        break
                if grew:
                    break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 500:
            step = len(comps) // 500 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
            dq = _diagonal_layout(n, counts)
            if len(dq) == n and _feasible(dq):
                cands.append(dq)
    return cands


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 18)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    # basin-hopping: perturb centres of the best packing and re-refine
    rnd = random.Random(777)
    for restart in range(30):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.03 * (0.3 + rnd.random())
            ncx = min(max(cx + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            cur[i] = [ncx, ncy, a, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
        if not _feasible(cur):
            cur = [list(q) for q in best]
            continue
        r = _refine([tuple(q) for q in cur], n, rounds=50, seed=restart * 13 + 1)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=40, seed=999)

    # rotation-aware polish: try to find tilted interlocking improvements
    for seed in (11, 101, 202, 303, 404, 505):
        rrot = _refine_rot(best, n, rounds=30, seed=seed)
        if _feasible(rrot) and _total(rrot) > best_s:
            best_s = _total(rrot)
            best = rrot
            # re-inflate axis-aligned after tilting helps sometimes
            r2 = _refine(best, n, rounds=30, seed=seed + 1)
            if _total(r2) > best_s:
                best_s = _total(r2)
                best = r2

    if not _feasible(best):
        return _make_layout(n, [n])[:n]
    return best[:n]
# EVOLVE-BLOCK-END
