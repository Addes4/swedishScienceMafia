# EVOLVE-BLOCK-START
"""Grid-seeded smooth-penalty optimizer for packing axis-aligned squares.

We always begin from the largest k x k grid (feasible), let scipy push the
sides up subject to a soft non-overlap/out-of-bounds penalty, then repair any
tiny residual violation by a global shrink so the returned layout is strictly
valid.  We return whichever of {repaired layout, plain grid} has the larger
sum of side lengths, so the result never scores below the baseline.
"""
import math
import numpy as np
from scipy.optimize import minimize


def _grid(n):
    k = math.isqrt(n)
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
          for i in range(k) for j in range(k)]
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n]


def _total(sq):
    return sum(s for *_, s in sq)


def _overlap_area(a, b):
    ax, ay, _, as_ = a
    bx, by, _, bs = b
    ox = min(ax + as_ / 2, bx + bs / 2) - max(ax - as_ / 2, bx - bs / 2)
    oy = min(ay + as_ / 2, by + bs / 2) - max(ay - as_ / 2, by - bs / 2)
    return max(0.0, ox) * max(0.0, oy)


def _valid(sq, tol=1e-9):
    for x, y, _, s in sq:
        if s < -tol:
            return False
        if x - s / 2 < -tol or x + s / 2 > 1 + tol:
            return False
        if y - s / 2 < -tol or y + s / 2 > 1 + tol:
            return False
    n = len(sq)
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap_area(sq[i], sq[j]) > tol * tol:
                return False
    return True


def _scaled(sq, r):
    return [(x, y, a, s * r) for x, y, a, s in sq]


def _repair(sq):
    """Return the largest globally-shrunk copy of sq that is strictly valid."""
    if _valid(sq):
        return sq
    lo, hi = 0.0, 1.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        if _valid(_scaled(sq, mid)):
            lo = mid
        else:
            hi = mid
    return _scaled(sq, lo)


def _optimize(grid):
    n = len(grid)
    if n <= 1:
        return grid
    x0 = np.empty(3 * n)
    for i, (x, y, _, s) in enumerate(grid):
        x0[3 * i] = x
        x0[3 * i + 1] = y
        x0[3 * i + 2] = s

    bounds = []
    for _ in range(n):
        bounds += [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0)]

    def unpack(z):
        pts = [(z[3 * i], z[3 * i + 1], 0.0, max(0.0, z[3 * i + 2]))
               for i in range(n)]
        return pts

    lam = 8.0

    def obj(z):
        pts = unpack(z)
        val = -sum(p[3] for p in pts)
        pen = 0.0
        for i in range(n):
            x, y, _, s = pts[i]
            hx = x - s / 2
            hX = x + s / 2
            hy = y - s / 2
            hY = y + s / 2
            pen += max(0.0, -hx) ** 2 + max(0.0, hX - 1.0) ** 2
            pen += max(0.0, -hy) ** 2 + max(0.0, hY - 1.0) ** 2
        for i in range(n):
            for j in range(i + 1, n):
                ox = min(pts[i][0] + pts[i][3] / 2, pts[j][0] + pts[j][3] / 2) \
                    - max(pts[i][0] - pts[i][3] / 2, pts[j][0] - pts[j][3] / 2)
                oy = min(pts[i][1] + pts[i][3] / 2, pts[j][1] + pts[j][3] / 2) \
                    - max(pts[i][1] - pts[i][3] / 2, pts[j][1] - pts[j][3] / 2)
                if ox > 0 and oy > 0:
                    pen += (ox * oy)
        return val + lam * pen

    best = list(grid)
    best_val = -_total(grid)
    for lam_try in (4.0, 8.0, 16.0, 32.0):
        lam = lam_try
        try:
            res = minimize(obj, x0, method="L-BFGS-B", bounds=bounds,
                           options={"maxiter": 400, "maxfun": 100000})
        except Exception:
            continue
        cand = _repair(unpack(res.x))
        cval = -_total(cand)
        if _valid(cand) and cval < best_val:
            best_val = cval
            best = cand
    return best


def solve(n):
    grid = _grid(n)
    if n <= 1:
        return grid
    try:
        cand = _optimize(grid)
    except Exception:
        cand = grid
    cand = _repair(cand)
    if _valid(cand) and _total(cand) > _total(grid) + 1e-12:
        out = cand
    else:
        out = grid
    # final safety: clamp everything inside the unit square
    res = []
    for x, y, a, s in out:
        s = min(max(s, 0.0), 1.0)
        x = min(max(x, s / 2), 1 - s / 2)
        y = min(max(y, s / 2), 1 - s / 2)
        res.append((x, y, 0.0, s))
    return res[:n]
# EVOLVE-BLOCK-END

