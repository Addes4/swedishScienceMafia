# EVOLVE-BLOCK-START
"""Squares in a square: optimized unequal-row packing with local refinement."""
import math


def _best_height_layout(counts):
    """Given row counts (list of positive ints), choose row heights h_i >= 0
    with sum h_i = 1 maximising sum_i min(h_i, 1/c_i).
    Returns (heights, sum_sides) or None if infeasible."""
    m = len(counts)
    caps = [1.0 / c for c in counts]  # max side per row (width limit)
    # Each row's contribution is min(h_i, cap_i). Optimal: rows either fully
    # at cap (h_i = cap_i) or share remaining height equally among "limited" rows.
    # Sort by cap ascending; try: the t rows with smallest caps are at their cap,
    # remaining m-t rows split leftover height s = 1 - sum(caps of those t).
    order = sorted(range(m), key=lambda i: caps[i])
    best = None
    for t in range(m + 1):
        capped = order[:t]
        rest = order[t:]
        used = sum(caps[i] for i in capped)
        rem = 1.0 - used
        if rem < -1e-12:
            continue
        # If rest nonempty, remaining rows get height rem/len(rest).
        # Need rem/len(rest) <= min cap among rest for it to be valid optimum.
        heights = [0.0] * m
        for i in capped:
            heights[i] = caps[i]
        if rest:
            h = rem / len(rest)
            feasible = True
            for i in rest:
                heights[i] = h
                if h > caps[i] + 1e-9:
                    feasible = False
            if not feasible:
                continue
        # sum of sides = capped sides + rest
        total = sum(caps[i] for i in capped)
        if rest:
            total += rem
        if best is None or total > best[1] + 1e-15:
            best = (heights, total)
    return best


def _compositions(n, k):
    """Yield all compositions of n into k positive parts (non-increasing)."""
    if k == 1:
        yield (n,)
        return
    if k > n:
        return
    # generate non-increasing to reduce duplicates
    def gen(remaining, parts, maxv):
        if parts == 1:
            if remaining <= maxv:
                yield (remaining,)
            return
        for v in range(min(remaining - (parts - 1), maxv), 0, -1):
            for tail in gen(remaining - v, parts - 1, v):
                yield (v,) + tail
    yield from gen(n, k, n)


def _layout(counts, heights):
    squares = []
    y = 0.0
    for c, h in zip(counts, heights):
        if c == 0 or h <= 0:
            y += h
            continue
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append([cx, cy, 0.0, s])
        y += h
    return squares


def _best_layout(n):
    best_sq = None
    best_sc = -1.0
    for k in range(1, n + 1):
        for counts in _compositions(n, k):
            res = _best_height_layout(list(counts))
            if res is None:
                continue
            heights, tot = res
            if tot <= best_sc:
                continue
            sq = _layout(list(counts), heights)
            if len(sq) == n:
                best_sc = tot
                best_sq = sq
    return best_sq


def _overlap(a, b):
    # axis-aligned boxes
    return (abs(a[0] - b[0]) < (a[3] + b[3]) / 2 - 1e-12 and
            abs(a[1] - b[1]) < (a[3] + b[3]) / 2 - 1e-12)


def _feasible(sq, n):
    for (cx, cy, a, s) in sq:
        if s < -1e-12 or cx - s / 2 < -1e-12 or cx + s / 2 > 1 + 1e-12 \
           or cy - s / 2 < -1e-12 or cy + s / 2 > 1 + 1e-12:
            return False
    for i in range(n):
        ai = sq[i]
        if ai[3] <= 0:
            continue
        for j in range(i + 1, n):
            if sq[j][3] <= 0:
                continue
            if _overlap(ai, sq[j]):
                return False
    return True


def _refine(sq, n):
    cur = [list(q) for q in sq]

    def sc(s):
        return sum(q[3] for q in s)

    # Stage 1: grow each square in place
    steps = (0.05, 0.02, 0.01, 0.005, 0.002, 0.001)
    for _ in range(60):
        improved = False
        for i in range(n):
            cx, cy, a, si = cur[i]
            for g in steps:
                cand = [list(q) for q in cur]
                cand[i][3] = si + g
                if _feasible(cand, n):
                    cur = cand
                    si += g
                    improved = True
                    break
        if not improved:
            break

    # Stage 2: slightly move centres to pack tighter then grow again
    moves = (0.01, 0.005, 0.002, 0.001)
    for _ in range(40):
        improved = False
        for i in range(n):
            for dx, dy in ((0.0, 0.0),) + tuple(
                    (mv * sx, mv * sy)
                    for mv in moves
                    for sx in (-1, 1) for sy in (-1, 1)):
                if dx == 0.0 and dy == 0.0:
                    continue
                cand = [list(q) for q in cur]
                cand[i][0] = cur[i][0] + dx
                cand[i][1] = cur[i][1] + dy
                if _feasible(cand, n):
                    if sc(cand) >= sc(cur) - 1e-15:
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return cur


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    sq = _best_layout(n)
    if sq is None:
        # fallback uniform grid
        k = max(1, int(math.isqrt(n)))
        side = 1.0 / k
        sq = [[(i + 0.5) * side, (j + 0.5) * side, 0.0, side]
              for i in range(k) for j in range(k)][:n]
        while len(sq) < n:
            sq.append([0.5, 0.5, 0.0, 0.0])

    # prune tiny/safe only if valid
    if not _feasible(sq, n):
        k = max(1, int(math.isqrt(n)))
        side = 1.0 / k
        sq = [[(i + 0.5) * side, (j + 0.5) * side, 0.0, side]
              for i in range(k) for j in range(k)][:n]
        while len(sq) < n:
            sq.append([0.5, 0.5, 0.0, 0.0])

    sq = _refine(sq, n)

    if not _feasible(sq, n):
        k = max(1, int(math.isqrt(n)))
        side = 1.0 / k
        sq = [[(i + 0.5) * side, (j + 0.5) * side, 0.0, side]
              for i in range(k) for j in range(k)][:n]
        while len(sq) < n:
            sq.append([0.5, 0.5, 0.0, 0.0])

    return [(float(a), float(b), 0.0, float(s)) for (a, b, _, s) in sq[:n]]
# EVOLVE-BLOCK-END
