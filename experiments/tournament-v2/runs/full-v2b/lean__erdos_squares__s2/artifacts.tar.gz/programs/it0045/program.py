# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid/diagonal layouts + a bitmap
corner-occupancy constructor + strong inflate refiner, plus a rotation-aware
separator and tilt neighbourhood to exploit non-axis-aligned optima."""
import math
import random
import time


def _sq_corners(cx, cy, a, s):
    th = 2.0 * math.pi * a
    c, sn = math.cos(th), math.sin(th)
    h = s / 2.0
    pts = []
    for (ux, uy) in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + c * ux - sn * uy, cy + sn * ux + c * uy))
    return pts


def _overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Separating-axis test for two convex (rotated) squares."""
    p1 = _sq_corners(cx1, cy1, a1, s1)
    p2 = _sq_corners(cx2, cy2, a2, s2)
    th1 = 2.0 * math.pi * a1
    th2 = 2.0 * math.pi * a2
    axes = []
    for th in (th1, th2):
        c, sn = math.cos(th), math.sin(th)
        axes.append((c, sn))
        axes.append((-sn, c))
    for (ax, ay) in axes:
        min1 = min(p[0] * ax + p[1] * ay for p in p1)
        max1 = max(p[0] * ax + p[1] * ay for p in p1)
        min2 = min(p[0] * ax + p[1] * ay for p in p2)
        max2 = max(p[0] * ax + p[1] * ay for p in p2)
        if max1 < min2 + 1e-12 or max2 < min1 + 1e-12:
            return False
    return True


def _dist2(c1, c2):
    dx = c1[0] - c2[0]
    dy = c1[1] - c2[1]
    return dx * dx + dy * dy


def _feasible(s):
    m = len(s)
    for iq in range(m):
        cx, cy, a, si = s[iq]
        h = si / 2.0
        ca = abs(math.cos(2.0 * math.pi * a))
        sa = abs(math.sin(2.0 * math.pi * a))
        ex = h * (ca + sa)
        ey = ex
        if si < -1e-12 or cx - ex < -1e-7 or cx + ex > 1 + 1e-7 \
           or cy - ey < -1e-7 or cy + ey > 1 + 1e-7:
            return False
        for jq in range(iq + 1, m):
            cx2, cy2, a2, s2 = s[jq]
            cx1, cy1 = cx, cy
            if a == 0.0 and a2 == 0.0:
                if abs(cx1 - cx2) < (si + s2) / 2 - 1e-9 and \
                   abs(cy1 - cy2) < (si + s2) / 2 - 1e-9:
                    return False
                continue
            if abs(a - a2) < 1e-9 and abs(a) < 1e-12:
                if abs(cx1 - cx2) < (si + s2) / 2 - 1e-9 and \
                   abs(cy1 - cy2) < (si + s2) / 2 - 1e-9:
                    return False
                continue
            if _overlap(cx1, cy1, a, si, cx2, cy2, a2, s2):
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _refine(sq, n, rounds=80, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(2):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = cx + dx
                    ncy = cy + dy
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                               (0.003, 0.003), (-0.003, -0.003),
                               (0.003, -0.003), (-0.003, 0.003)):
                    cand = cur[:i] + [[cx + dx, cy + dy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _relax_axis_aligned(sq, n, iters=12):
    """Push each square toward the boundary/neighbours until exact contact,
    reusing the fast axis-aligned structure where possible."""
    a = [list(q) for q in sq]
    for _ in range(iters):
        changed = False
        for i in range(n):
            si = a[i][3]
            best_dx, best_dy = 0.0, 0.0
            # gravity toward origin in x and y, then clamp
            for (dx, dy) in ((0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01)):
                nc = a[:i] + [[a[i][0] + dx, a[i][1] + dy, a[i][2], si]] + a[i+1:]
                if _feasible(nc):
                    a = nc
                    changed = True
        if not changed:
            break
    return [tuple(q) for q in a]


def _tilt_polish(sq, n, deadline, seed=4242):
    """Try small angle changes per square, then re-inflate. Uses the general
    separating-axis test so rotated configurations remain valid."""
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    base = _total(cur)
    best = cur
    angles = (0.02, -0.02, 0.04, -0.04, 0.06, -0.06, 0.12, -0.12, -0.25, 0.25)
    while time.time() < deadline:
        cur = [list(q) for q in best]
        improved = False
        order = list(range(n))
        rnd.shuffle(order)
        for i in order:
            if time.time() >= deadline:
                break
            cx, cy, a, si = cur[i]
            moved = False
            for da in angles:
                na = (a + da) % 1.0
                cand = cur[:i] + [[cx, cy, na, si]] + cur[i + 1:]
                if _feasible(cand):
                    cur = cand
                    a = na
                    moved = True
                    improved = True
                    break
            if not moved:
                continue
        # try to grow after tilts using the general refiner, then slide along
        cur = _refine([tuple(q) for q in cur], n, rounds=25,
                      seed=rnd.randint(0, 10**9))
        sc = _total(cur)
        if sc > base + 1e-9:
            base = sc
            best = cur
    return [tuple(q) for q in best]


def _slide_polish(sq, n, rounds=40, deadline=None):
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        if deadline is not None and time.time() >= deadline:
            break
        improved = False
        order = sorted(range(n), key=lambda i: cur[i][3])
        for i in order:
            if deadline is not None and time.time() >= deadline:
                break
            cx, cy, a, si = cur[i]
            maxhalf = min(1.0 - cx, cx, 1.0 - cy, cy)
            for j in range(n):
                if j == i:
                    continue
                ox, oy, _, os = cur[j]
                need = (si + os) / 2.0
                dx = abs(ox - cx)
                dy = abs(oy - cy)
                if dx < need and dy < need:
                    maxhalf = si / 2.0
                    break
                lim = max(dx, dy) - os / 2.0
                if lim < maxhalf:
                    maxhalf = lim
            if maxhalf > si / 2.0 + 1e-12:
                ns = 2.0 * maxhalf - 1e-9
                cand = cur[:i] + [[cx, cy, a, ns]] + cur[i + 1:]
                if _feasible(cand):
                    cur = cand
                    si = ns
                    improved = True
                    continue
            for (dxs, dys) in ((1, 0), (-1, 0), (0, 1), (0, -1),
                               (0.7071, 0.7071), (-0.7071, -0.7071),
                               (0.7071, -0.7071), (-0.7071, 0.7071)):
                lo, hi = 0.0, 0.2
                for _ in range(16):
                    mid = 0.5 * (lo + hi)
                    ncx = cx + dxs * mid
                    ncy = cy + dys * mid
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        lo = mid
                    else:
                        hi = mid
                if lo > 1e-7:
                    ncx = cx + dxs * lo
                    ncy = cy + dys * lo
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        cx, cy = ncx, ncy
                        improved = True
        if not improved:
            break
    return [tuple(q) for q in cur]


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _diagonal_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    total_h = sum(heights)
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        shift = (y / max(total_h, 1e-9)) * (1.0 - c * s)
        cy = y + h / 2.0
        for j in range(c):
            cx = shift + (j + 0.5) * s
            if cx - s / 2 < -1e-9 or cx + s / 2 > 1 + 1e-9:
                cx = min(max(cx, s / 2), 1 - s / 2)
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _shelf_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        x = 0.0
        cy = y + h / 2.0
        for j in range(c):
            cx = min(x + s / 2.0, 1 - s / 2.0)
            squares.append((cx, cy, 0.0, s))
            x += s
        y += h
    return squares


def _corner_layout(n, seed=0):
    squares = []
    big = 0.5
    squares.append((big / 2.0, big / 2.0, 0.0, big))
    x = big
    y = 0.0
    row_h = 0.0
    for i in range(n - 1):
        s = 0.5 / (i + 2.0)
        if x + s > 1.0 + 1e-9:
            x = 0.0
            y += row_h if row_h > 0 else s
            row_h = 0.0
        cy = min(y + s / 2.0, 1 - s / 2.0)
        cx = min(x + s / 2.0, 1 - s / 2.0)
        squares.append((cx, cy, 0.0, s))
        x += s
        row_h = max(row_h, s)
    return squares


def _bitmap_layout(n, seed=0, grid=120):
    rnd = random.Random(seed)
    G = grid
    occ = [bytearray(G) for _ in range(G)]
    squares = []

    req = [1.0 / (i + 1.7) for i in range(n)]
    mx = max(req)
    req = [r / mx for r in req]

    def free(cx, cy, s):
        half = s / 2.0
        x0 = int(math.floor((cx - half) * G))
        x1 = int(math.ceil((cx + half) * G))
        y0 = int(math.floor((cy - half) * G))
        y1 = int(math.ceil((cy + half) * G))
        if x0 < 0 or y0 < 0 or x1 > G or y1 > G:
            return False
        for yy in range(y0, y1):
            row = occ[yy]
            for xx in range(x0, x1):
                if row[xx]:
                    return False
        return True

    def mark(cx, cy, s):
        half = s / 2.0
        x0 = max(0, int(math.floor((cx - half) * G)))
        x1 = min(G, int(math.ceil((cx + half) * G)))
        y0 = max(0, int(math.floor((cy - half) * G)))
        y1 = min(G, int(math.ceil((cy + half) * G)))
        for yy in range(y0, y1):
            row = occ[yy]
            for xx in range(x0, x1):
                row[xx] = 1

    anchors = []
    step = 0.1
    kk = 0
    while kk <= 10 + 1e-9:
        ll = 0
        while ll <= 10 + 1e-9:
            anchors.append((kk * step, ll * step))
            ll += 1
        kk += 1

    for i in range(n):
        target = req[i]
        best = None
        order = anchors[:]
        rnd.shuffle(order)
        for (ax, ay) in order:
            s = target
            tries = 0
            while s > 1e-3 and tries < 6:
                cx = min(max(ax + s / 2.0, s / 2.0), 1 - s / 2.0)
                cy = min(max(ay + s / 2.0, s / 2.0), 1 - s / 2.0)
                if free(cx, cy, s):
                    score = s + 0.01 * rnd.random()
                    if best is None or score > best[0]:
                        best = (score, cx, cy, s)
                    break
                s *= 0.8
                tries += 1
        if best is None:
            placed = False
            for yy in range(G):
                if placed:
                    break
                for xx in range(G):
                    if not occ[yy][xx]:
                        mark((xx + 0.5) / G, (yy + 0.5) / G, 1.0 / G)
                        squares.append(((xx + 0.5) / G, (yy + 0.5) / G, 0.0,
                                        1.0 / G))
                        placed = True
                        break
            if not placed:
                squares.append((0.5, 0.5, 0.0, 0.0))
            continue
        _, cx, cy, s = best
        mark(cx, cy, s)
        squares.append((cx, cy, 0.0, s))
        half = s / 2.0
        for (px, py) in ((cx + half, cy + half), (cx - half, cy + half),
                         (cx + half, cy - half), (cx - half, cy - half),
                         (cx + half, cy), (cx - half, cy),
                         (cx, cy + half), (cx, cy - half)):
            if -1e-9 <= px <= 1 + 1e-9 and -1e-9 <= py <= 1 + 1e-9:
                anchors.append((px, py))
    return squares


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 200:
            step = len(comps) // 200 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            for fn in (_make_layout, _column_layout, _diagonal_layout,
                       _shelf_layout):
                sq = fn(n, counts)
                if len(sq) == n and _feasible(sq):
                    cands.append(sq)
    return cands


def solve(n):
    t0 = time.time()
    deadline = t0 + 55.0

    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    for sd in range(3):
        cq = _corner_layout(n, seed=sd)
        if len(cq) == n and _feasible(cq):
            cands.append(cq)

    for sd in range(4):
        try:
            bq = _bitmap_layout(n, seed=sd, grid=110)
        except Exception:
            bq = []
        if len(bq) == n and _feasible(bq):
            cands.append(bq)

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 20)]

    best = None
    best_s = -1.0
    for sq in pool:
        if time.time() >= deadline:
            break
        r = _refine(sq, n, rounds=50)
        r = _slide_polish(r, n, rounds=25, deadline=deadline)
        r = _refine(r, n, rounds=25)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    if best is None:
        best = [tuple(q) for q in cands[0]]
        best_s = _total(best)

    rnd = random.Random(777)
    restart = 0
    while time.time() < deadline - 5.0:
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.03 * (0.3 + rnd.random())
            ncx = min(max(cx + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            cur[i] = [ncx, ncy, a, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
        if not _feasible(cur):
            restart += 1
            continue
        r = _refine([tuple(q) for q in cur], n, rounds=40,
                    seed=restart * 13 + 1)
        r = _slide_polish(r, n, rounds=15, deadline=deadline)
        r = _refine(r, n, rounds=20, seed=restart * 13 + 1)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r
        restart += 1

    best = _refine(best, n, rounds=30, seed=999)
    if time.time() < deadline - 8.0:
        tilt_budget = min(deadline - 2.0, time.time() + 12.0)
        tilted = _tilt_polish(best, n, tilt_budget, seed=31337)
        if _total(tilted) > best_s:
            best_s = _total(tilted)
            best = tilted
    best = _refine(best, n, rounds=25, seed=998)
    best = _slide_polish(best, n, rounds=25, deadline=deadline)

    out = []
    for (cx, cy, a, s) in best[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = a % 1.0
        s = max(0.0, s)
        out.append((cx, cy, a, s))
    return out
# EVOLVE-BLOCK-END
