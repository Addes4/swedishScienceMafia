# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid/diagonal layouts + strong inflate
refiner with basin-hopping restarts, plus a rotation-aware (SAT) polish stage
so tilted interlocking packings can be discovered."""
import math
import random


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _diagonal_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    total_h = sum(heights)
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        shift = (y / max(total_h, 1e-9)) * (1.0 - c * s)
        xoff = shift
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            if cx - s / 2 < -1e-9 or cx + s / 2 > 1 + 1e-9:
                cx = min(max(cx, s / 2), 1 - s / 2)
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _corners(cx, cy, a, s):
    """Return the 4 corner points of a square given centre, angle (fraction of
    a full turn) and side length."""
    th = a * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s / 2.0
    pts = []
    for sx, sy in ((1, 1), (-1, 1), (-1, -1), (1, -1)):
        px = sx * h
        py = sy * h
        pts.append((cx + px * c - py * sn, cy + px * sn + py * c))
    return pts


def _axes(a):
    th = a * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    return (c, sn), (-sn, c)


def _sep_axis(pts1, pts2, ax):
    axx, axy = ax
    p1 = [p[0] * axx + p[1] * axy for p in pts1]
    p2 = [p[0] * axx + p[1] * axy for p in pts2]
    return max(p1) < min(p2) - 1e-12 or max(p2) < min(p1) - 1e-12


def _pair_ok(x1, y1, a1, s1, x2, y2, a2, s2):
    p1 = _corners(x1, y1, a1, s1)
    p2 = _corners(x2, y2, a2, s2)
    for ax in _axes(a1) + _axes(a2):
        if _sep_axis(p1, p2, ax):
            return True
    return False


def _in_unit(s):
    for (cx, cy, a, si) in s:
        if si < -1e-12:
            return False
        pts = _corners(cx, cy, a, si)
        for px, py in pts:
            if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                return False
    return True


def _feasible(s, use_sat=False):
    m = len(s)
    if not _in_unit(s):
        return False
    if not use_sat:
        # fast path: if all angles are ~0, use the axis-aligned test
        aligned = all(abs((q[2] % 0.5)) < 1e-9 for q in s)
        if aligned:
            for i in range(m):
                x1, y1, _, s1 = s[i]
                for j in range(i + 1, m):
                    x2, y2, _, s2 = s[j]
                    if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
                       abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                        return False
            return True
    for i in range(m):
        x1, y1, a1, s1 = s[i]
        for j in range(i + 1, m):
            x2, y2, a2, s2 = s[j]
            if not _pair_ok(x1, y1, a1, s1, x2, y2, a2, s2):
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _refine(sq, n, rounds=80, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                               (0.003, 0.003), (-0.003, -0.003),
                               (0.003, -0.003), (-0.003, 0.003)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _refine_sat(sq, n, rounds=60, seed=555):
    """Rotation-aware refiner: tries rotating each square (with growth) using
    a correct SAT collision test."""
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    angle_steps = (0.02, 0.01, 0.005, 0.0025, 0.00125, 0.0006)
    grow_steps = (0.01, 0.005, 0.002, 0.001, 0.0005)
    for _ in range(rounds):
        improved = False
        for i in range(n):
            cx, cy, a, si = cur[i]
            moved = False
            for da in angle_steps:
                for sign in (1, -1):
                    for grow in grow_steps:
                        na = (a + sign * da) % 1.0
                        ns = si + grow
                        ncx = min(max(cx, ns / 2), 1 - ns / 2)
                        ncy = min(max(cy, ns / 2), 1 - ns / 2)
                        cand = cur[:i] + [[ncx, ncy, na, ns]] + cur[i + 1:]
                        if _feasible(cand, use_sat=True):
                            cur = cand
                            moved = True
                            improved = True
                            break
                    if moved:
                        break
                if moved:
                    break
            if not moved:
                # try just rotating without growing
                for da in angle_steps:
                    for sign in (1, -1):
                        na = (a + sign * da) % 1.0
                        cand = cur[:i] + [[cx, cy, na, si]] + cur[i + 1:]
                        if _feasible(cand, use_sat=True):
                            cur = cand
                            improved = True
                            moved = True
                            break
                    if moved:
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 500:
            step = len(comps) // 500 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
            dq = _diagonal_layout(n, counts)
            if len(dq) == n and _feasible(dq):
                cands.append(dq)
    return cands


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 18)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    # basin-hopping: perturb centres of the best packing and re-refine
    rnd = random.Random(777)
    for restart in range(40):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.03 * (0.3 + rnd.random())
            ncx = min(max(cx + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            cur[i] = [ncx, ncy, a, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
        if not _feasible(cur):
            cur = [list(q) for q in best]
            continue
        r = _refine([tuple(q) for q in cur], n, rounds=50, seed=restart * 13 + 1)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=40, seed=999)

    # rotation-aware polish: try tilted interlocking packings
    tilted = _refine_sat(best, n, rounds=40, seed=321)
    if _feasible(tilted, use_sat=True):
        ts = _total(tilted)
        if ts > best_s:
            best_s = ts
            best = tilted
            # re-grow axis-aligned to clean up
            regrown = _refine(best, n, rounds=30, seed=1001)
            if _feasible(regrown, use_sat=True) and _total(regrown) > best_s:
                best = regrown

    # verify final packaging; fall back to axis refiner if tilted broke bounds
    if not _feasible(best, use_sat=True):
        best = _refine(best, n, rounds=40, seed=4242)

        tilted = _refine_sat(best, n, rounds=40, seed=321)
        if _feasible(tilted, use_sat=True) and _total(tilted) > best_s:
            best = tilted

    return best[:n]
# EVOLVE-BLOCK-END

