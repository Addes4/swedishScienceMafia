# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid/diagonal layouts + strong inflate
refiner with basin-hopping restarts (including small rotations) to escape local
optima and find tilted interlocking packings."""
import math
import random


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _diagonal_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    total_h = sum(heights)
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        shift = (y / max(total_h, 1e-9)) * (1.0 - c * s)
        xoff = shift
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            if cx - s / 2 < -1e-9 or cx + s / 2 > 1 + 1e-9:
                cx = min(max(cx, s / 2), 1 - s / 2)
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _rot_corners(cx, cy, a, s):
    """Return the 4 corners (x,y) of a square rotated by angle a (fraction of turn)."""
    th = a * 2.0 * math.pi
    co, si = math.cos(th), math.sin(th)
    h = s / 2.0
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for (px, py) in pts:
        out.append((cx + px * co - py * si, cy + px * si + py * co))
    return out


def _axis_proj(pts, ax, ay):
    return [p[0] * ax + p[1] * ay for p in pts]


def _overlap(sq1, sq2):
    c1 = _rot_corners(*sq1)
    c2 = _rot_corners(*sq2)
    axes = []
    for corners in (c1, c2):
        for i in range(4):
            x1, y1 = corners[i]
            x2, y2 = corners[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            n = math.hypot(ex, ey)
            if n > 1e-15:
                axes.append((-ey / n, ex / n))
    for (ax, ay) in axes:
        p1 = _axis_proj(c1, ax, ay)
        p2 = _axis_proj(c2, ax, ay)
        if min(p1) > max(p2) - 1e-9 or min(p2) > max(p1) - 1e-9:
            return False
    return True


def _feasible(s):
    m = len(s)
    corners = [_rot_corners(cx, cy, a, si) for (cx, cy, a, si) in s]
    for (cx, cy, a, si) in s:
        if si < -1e-12:
            return False
    for cs in corners:
        for (x, y) in cs:
            if x < -1e-7 or x > 1 + 1e-7 or y < -1e-7 or y > 1 + 1e-7:
                return False
    for i in range(m):
        for j in range(i + 1, m):
            if _overlap(s[i], s[j]):
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _refine(sq, n, rounds=80, seed=12345, allow_rot=False):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                ang_opts = [a]
                if allow_rot:
                    for da in (0.01, -0.01, 0.02, -0.02):
                        ang_opts.append((a + da) % 1.0)
                for (dx, dy) in cands:
                    for na in ang_opts:
                        ncx = cx + dx
                        ncy = cy + dy
                        cand = cur[:i] + [[ncx, ncy, na, ns]] + cur[i + 1:]
                        if _feasible(cand):
                            cur = cand
                            grew = True
                            improved = True
                            break
                    if grew:
                        break
                if grew:
                    break
            if not grew:
                # try nudging position (and angle) to open space
                for (dx, dy) in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                                 (0.003, 0.003), (-0.003, -0.003),
                                 (0.003, -0.003), (-0.003, 0.003)):
                    ang_opts = [a]
                    if allow_rot:
                        ang_opts = [a, (a + 0.01) % 1.0, (a - 0.01) % 1.0]
                    done = False
                    for na in ang_opts:
                        cand = cur[:i] + [[cx + dx, cy + dy, na, si]] + cur[i + 1:]
                        if _feasible(cand):
                            cur = cand
                            improved = True
                            done = True
                            break
                    if done:
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 500:
            step = len(comps) // 500 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
            dq = _diagonal_layout(n, counts)
            if len(dq) == n and _feasible(dq):
                cands.append(dq)
    return cands


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 18)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r
        # tilt-aware polish on top candidates
        r2 = _refine(r, n, rounds=40, seed=42, allow_rot=True)
        sc2 = _total(r2)
        if sc2 > best_s:
            best_s = sc2
            best = r2

    # basin-hopping: perturb centres (and small angles) of the best packing
    rnd = random.Random(777)
    for restart in range(60):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.03 * (0.3 + rnd.random())
            ncx = cx + rnd.uniform(-amp, amp)
            ncy = cy + rnd.uniform(-amp, amp)
            na = (a + rnd.uniform(-0.03, 0.03)) % 1.0
            cur[i] = [ncx, ncy, na, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
        if not _feasible(cur):
            cur = [list(q) for q in best]
            continue
        allow = (restart % 2 == 0)
        r = _refine([tuple(q) for q in cur], n, rounds=50,
                    seed=restart * 13 + 1, allow_rot=allow)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=40, seed=999, allow_rot=True)
    if not _feasible(best):
        # fall back to axis-aligned clean refine
        best = _refine(best, n, rounds=40, seed=1001, allow_rot=False)
    # clamp for safety
    out = []
    for (cx, cy, a, si) in best:
        si = max(0.0, min(si, 1.0))
        if si > 1.0:
            si = 1.0
        cx = max(0.0, min(cx, 1.0))
        cy = max(0.0, min(cy, 1.0))
        out.append((cx, cy, a % 1.0, si))
    return out[:n]
# EVOLVE-BLOCK-END

