# EVOLVE-BLOCK-START
"""Squares in a square: maximise the sum of side lengths.

Strategy:
  * Generate many structured candidate layouts (rows, columns, diagonals,
    shelves, bitmap corner-occupancy, and a recursive "largest square in a
    corner then tile the rest" family).
  * Pick the best few, then run a strong refiner that inflates squares one at
    a time, slides them to contact, and periodically performs
    "shrink-the-biggest / re-grow-the-rest" perturbations to escape the
    single-square inflation plateau.
"""
import math
import random


# ----------------------------------------------------------------------------
# Feasibility / objective
# ----------------------------------------------------------------------------
def _sep_ok(cx1, cy1, s1, cx2, cy2, s2, eps=1e-9):
    return (abs(cx1 - cx2) >= (s1 + s2) / 2 - eps or
            abs(cy1 - cy2) >= (s1 + s2) / 2 - eps)


def _feasible(sq, eps=1e-9):
    m = len(sq)
    for (cx, cy, a, si) in sq:
        if si < -eps:
            return False
        h = si / 2.0
        if cx - h < -eps or cx + h > 1 + eps or cy - h < -eps or cy + h > 1 + eps:
            return False
    for i in range(m):
        x1, y1, _, s1 = sq[i]
        for j in range(i + 1, m):
            x2, y2, _, s2 = sq[j]
            if not _sep_ok(x1, y1, s1, x2, y2, s2, eps):
                return False
    return True


def _total(sq):
    return sum(q[3] for q in sq)


# ----------------------------------------------------------------------------
# Structured constructors (all axis-aligned)
# ----------------------------------------------------------------------------
def _distribute(counts):
    """Return row heights that fit in the unit square for the given counts."""
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        return caps[:]
    lo, hi = 0.0, max(caps)
    for _ in range(70):
        t = 0.5 * (lo + hi)
        if sum(min(c, t) for c in caps) < 1.0:
            lo = t
        else:
            hi = t
    t = 0.5 * (lo + hi)
    heights = [min(c, t) for c in caps]
    s = sum(heights)
    if s > 0:
        heights = [h / s for h in heights]
    return heights


def _row_layout(counts):
    heights = _distribute(counts)
    squares = []
    y = 0.0
    for c, h in zip(counts, heights):
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            squares.append((xoff + (j + 0.5) * s, cy, 0.0, s))
        y += h
    return squares


def _col_layout(counts):
    return [(cy, cx, 0.0, s) for (cx, cy, a, s) in _row_layout(counts)]


def _diag_layout(counts):
    heights = _distribute(counts)
    squares = []
    y = 0.0
    th = sum(heights)
    for c, h in zip(counts, heights):
        s = min(h, 1.0 / c)
        shift = (y / max(th, 1e-9)) * (1.0 - c * s)
        cy = y + h / 2.0
        for j in range(c):
            cx = shift + (j + 0.5) * s
            cx = min(max(cx, s / 2), 1 - s / 2)
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _shelf_layout(counts):
    heights = _distribute(counts)
    squares = []
    y = 0.0
    for c, h in zip(counts, heights):
        s = min(h, 1.0 / c)
        x = 0.0
        cy = y + h / 2.0
        for j in range(c):
            cx = min(x + s / 2.0, 1 - s / 2.0)
            squares.append((cx, cy, 0.0, s))
            x += s
        y += h
    return squares


def _corner_recursive(n, big_frac=0.5, seed=0):
    """Place a big square in a corner, then recursively tile the remaining
    L-shaped region using vertical/horizontal shelves.  This yields the
    'k equal squares in a block + leftover' families that hit several optima."""
    rnd = random.Random(seed)
    squares = []
    if n <= 0:
        return squares
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    b = big_frac
    corners = [(0, 0), (1, 1), (0, 1), (1, 0)]
    # pick a few corner variants
    for (ux, uy) in corners:
        # big square in the chosen corner
        bx = b / 2.0 if ux == 0 else 1.0 - b / 2.0
        by = b / 2.0 if uy == 0 else 1.0 - b / 2.0
        sq = [(bx, by, 0.0, b)]
        # remaining region is two strips; fill them with rows
        rem = n - 1
        if rem <= 0:
            squares.append(sq)
            continue
        # split rem into a strip along x and strip along y
        best = None
        for cx in range(1, rem + 1):
            cy = rem - cx
            cand = []
            # strip 1: along the x side, height b, spanning full width
            if cx > 0:
                s1 = min(b, 1.0 / cx)
                # horizontal row at y from by+b/2 (or by-b/2)
                if uy == 0:
                    yy = b + s1 / 2.0
                else:
                    yy = 1.0 - b - s1 / 2.0
                xoff = 0.0
                for j in range(cx):
                    xx = xoff + (j + 0.5) * s1
                    cand.append((xx, yy, 0.0, s1))
            # strip 2: along the y side, width b, spanning full height
            if cy > 0:
                s2 = min(b, 1.0 / cy)
                if ux == 0:
                    xx = b + s2 / 2.0
                else:
                    xx = 1.0 - b - s2 / 2.0
                yoff = 0.0
                for j in range(cy):
                    yy = yoff + (j + 0.5) * s2
                    cand.append((xx, yy, 0.0, s2))
            test = sq + cand
            if len(test) == n and _feasible(test):
                sc = _total(test)
                if best is None or sc > best[0]:
                    best = (sc, test)
        if best is not None:
            squares.append(best[1])
        else:
            # fallback: just place the big square and pack the rest in a row
            s = (1.0 - b) / max(1, n - 1)
            sq2 = sq[:]
            for j in range(n - 1):
                sq2.append((s / 2.0 + j * s, b + s / 2.0 if uy == 0 else 1 - b - s / 2.0, 0.0, s))
            if len(sq2) == n and _feasible(sq2):
                squares.append(sq2)
    return squares


def _bitmap_layout(n, seed=0, grid=120):
    rnd = random.Random(seed)
    G = grid
    occ = [bytearray(G) for _ in range(G)]
    squares = []

    req = [1.0 / (i + 1.7) for i in range(n)]
    mx = max(req)
    req = [r / mx for r in req]

    def free(cx, cy, s):
        half = s / 2.0
        x0 = int(math.floor((cx - half) * G))
        x1 = int(math.ceil((cx + half) * G))
        y0 = int(math.floor((cy - half) * G))
        y1 = int(math.ceil((cy + half) * G))
        if x0 < 0 or y0 < 0 or x1 > G or y1 > G:
            return False
        for yy in range(y0, y1):
            row = occ[yy]
            for xx in range(x0, x1):
                if row[xx]:
                    return False
        return True

    def mark(cx, cy, s):
        half = s / 2.0
        x0 = max(0, int(math.floor((cx - half) * G)))
        x1 = min(G, int(math.ceil((cx + half) * G)))
        y0 = max(0, int(math.floor((cy - half) * G)))
        y1 = min(G, int(math.ceil((cy + half) * G)))
        for yy in range(y0, y1):
            row = occ[yy]
            for xx in range(x0, x1):
                row[xx] = 1

    anchors = [(i * 0.1, j * 0.1) for i in range(11) for j in range(11)]

    for i in range(n):
        target = req[i]
        best = None
        order = anchors[:]
        rnd.shuffle(order)
        for (ax, ay) in order:
            s = target
            tries = 0
            while s > 1e-3 and tries < 6:
                cx = min(max(ax + s / 2.0, s / 2.0), 1 - s / 2.0)
                cy = min(max(ay + s / 2.0, s / 2.0), 1 - s / 2.0)
                if free(cx, cy, s):
                    sc = s + 0.01 * rnd.random()
                    if best is None or sc > best[0]:
                        best = (sc, cx, cy, s)
                    break
                s *= 0.8
                tries += 1
        if best is None:
            for yy in range(G):
                done = False
                for xx in range(G):
                    if not occ[yy][xx]:
                        mark((xx + 0.5) / G, (yy + 0.5) / G, 1.0 / G)
                        squares.append(((xx + 0.5) / G, (yy + 0.5) / G, 0.0, 1.0 / G))
                        done = True
                        break
                if done:
                    break
            else:
                squares.append((0.5, 0.5, 0.0, 0.0))
            continue
        _, cx, cy, s = best
        mark(cx, cy, s)
        squares.append((cx, cy, 0.0, s))
        half = s / 2.0
        for (px, py) in ((cx + half, cy + half), (cx - half, cy + half),
                         (cx + half, cy - half), (cx - half, cy - half),
                         (cx + half, cy), (cx - half, cy),
                         (cx, cy + half), (cx, cy - half)):
            if 0 <= px <= 1 and 0 <= py <= 1:
                anchors.append((px, py))
    return squares


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return

    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        hi = min(maxv, remaining - (k - 1 - len(parts)))
        for v in range(hi, 0, -1):
            yield from rec(remaining - v, parts + [v], v)

    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 260:
            step = len(comps) // 260 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            for maker, flip in ((_row_layout, False), (_col_layout, False),
                                (_diag_layout, False), (_shelf_layout, False)):
                sq = maker(counts)
                if len(sq) == n and _feasible(sq):
                    cands.append(sq)
    return cands


# ----------------------------------------------------------------------------
# Refiner: inflate one at a time + slide to contact
# ----------------------------------------------------------------------------
def _refine(sq, n, rounds=60, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    grows = (0.06, 0.03, 0.015, 0.008, 0.004, 0.002, 0.001, 0.0005)
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for g in grows:
                ns = si + g
                if ns > 1.0 + 1e-9:
                    continue
                moves = [(0, 0), (g / 2, 0), (-g / 2, 0), (0, g / 2), (0, -g / 2),
                         (g / 2, g / 2), (-g / 2, -g / 2),
                         (g / 2, -g / 2), (-g / 2, g / 2)]
                ang = rnd.uniform(0, 2 * math.pi)
                moves.append((g * math.cos(ang), g * math.sin(ang)))
                for dx, dy in moves:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                               (0.003, 0.003), (-0.003, -0.003),
                               (0.003, -0.003), (-0.003, 0.003)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _slide_polish(sq, n, rounds=30):
    cur = [list(q) for q in sq]
    dirs = ((1, 0), (-1, 0), (0, 1), (0, -1),
            (0.7071, 0.7071), (-0.7071, -0.7071),
            (0.7071, -0.7071), (-0.7071, 0.7071))
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            # grow in place if possible
            maxhalf = min(1.0 - cx, cx, 1.0 - cy, cy)
            ok = True
            for j in range(n):
                if j == i:
                    continue
                ox, oy, _, os = cur[j]
                dx = abs(ox - cx)
                dy = abs(oy - cy)
                if dx < (si + os) / 2 - 1e-9 and dy < (si + os) / 2 - 1e-9:
                    ok = False
                    break
                lim = max(dx, dy) - os / 2.0
                if lim < maxhalf:
                    maxhalf = lim
            if ok and maxhalf > si / 2 + 1e-12:
                ns = 2.0 * maxhalf - 1e-9
                cand = cur[:i] + [[cx, cy, a, ns]] + cur[i + 1:]
                if _feasible(cand):
                    cur = cand
                    si = ns
                    improved = True
                    continue
            # slide to contact
            for (dxs, dys) in dirs:
                lo, hi = 0.0, 0.25
                for _ in range(18):
                    mid = 0.5 * (lo + hi)
                    ncx = cx + dxs * mid
                    ncy = cy + dys * mid
                    if (ncx - si / 2 >= -1e-9 and ncx + si / 2 <= 1 + 1e-9 and
                        ncy - si / 2 >= -1e-9 and ncy + si / 2 <= 1 + 1e-9):
                        clash = False
                        for j in range(n):
                            if j == i:
                                continue
                            ox, oy, _, os = cur[j]
                            if abs(ox - ncx) < (si + os) / 2 - 1e-9 and \
                               abs(oy - ncy) < (si + os) / 2 - 1e-9:
                                clash = True
                                break
                        if not clash:
                            lo = mid
                            continue
                    hi = mid
                if lo > 1e-7:
                    ncx = cx + dxs * lo
                    ncy = cy + dys * lo
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        cx, cy = ncx, ncy
                        improved = True
        if not improved:
            break
    return [tuple(q) for q in cur]


def _reinsert_polish(sq, n, rounds=20, seed=0):
    """Remove one square, then greedily reinsert the largest feasible square
    anywhere; keeps the total non-decreasing in expectation and escapes the
    inflation plateau."""
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        best_gain = 0.0
        best_state = None
        order = list(range(n))
        rnd.shuffle(order)
        for i in order:
            si = cur[i][3]
            rest = cur[:i] + cur[i + 1:]
            # find best location for a square of ~si (or slightly larger)
            for grow in (1.06, 1.03, 1.0, 0.97):
                ns = si * grow
                if ns > 1.0:
                    continue
                found = None
                for _t in range(200):
                    cx = rnd.uniform(ns / 2, 1 - ns / 2)
                    cy = rnd.uniform(ns / 2, 1 - ns / 2)
                    cand = rest + [[cx, cy, 0.0, ns]]
                    if _feasible(cand):
                        found = (cx, cy, ns)
                        break
                if found is not None:
                    gain = found[2] - si
                    if gain > best_gain:
                        best_gain = gain
                        best_state = rest + [[found[0], found[1], 0.0, found[2]]]
                    break
        if best_state is None:
            break
        cur = best_state
    return [tuple(q) for q in cur]


# ----------------------------------------------------------------------------
# solve
# ----------------------------------------------------------------------------
def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_row_layout([n])]

    for sd in range(4):
        for bf in (0.5, 0.45, 0.55, 0.6):
            for cq in _corner_recursive(n, big_frac=bf, seed=sd):
                if len(cq) == n and _feasible(cq):
                    cands.append(cq)

    for sd in range(6):
        try:
            bq = _bitmap_layout(n, seed=sd, grid=120)
        except Exception:
            bq = []
        if len(bq) == n and _feasible(bq):
            cands.append(bq)

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 24)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=50)
        r = _slide_polish(r, n, rounds=30)
        r = _refine(r, n, rounds=30)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    rnd = random.Random(4242)
    for restart in range(80):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.04 * (0.3 + rnd.random())
            ncx = min(max(cx + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            cur[i] = [ncx, ncy, a, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
        if not _feasible(cur):
            cur = [list(q) for q in best]
        r = _refine([tuple(q) for q in cur], n, rounds=45, seed=restart * 13 + 1)
        r = _slide_polish(r, n, rounds=20)
        r = _reinsert_polish(r, n, rounds=8, seed=restart)
        r = _refine(r, n, rounds=25, seed=restart * 13 + 1)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=40, seed=999)
    best = _slide_polish(best, n, rounds=40)
    best = _reinsert_polish(best, n, rounds=12, seed=11)
    best = _refine(best, n, rounds=40, seed=998)
    return [tuple(q) for q in best[:n]]
# EVOLVE-BLOCK-END
