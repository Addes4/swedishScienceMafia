# EVOLVE-BLOCK-START
"""Squares in a square: row packing with optimized row sizes + refinement."""
import math


def _layout_from_counts(counts):
    """counts[i] squares in row i, all axis-aligned, filling width 1.
    For a row with c squares, side s = 1/c and height h = s (squares sit in row).
    We can also let a row be taller than its squares; but to maximize sum we set
    height = side and stack rows. We normalize total height to 1 if it exceeds,
    otherwise we're free. Actually we scale all sides by sc = min(1, 1/sum_h).
    Returns squares or None if infeasible.
    """
    counts = [c for c in counts if c > 0]
    if not counts:
        return None
    raw = [1.0 / c for c in counts]
    total = sum(raw)
    if total <= 0:
        return None
    sc = 1.0 / total if total > 1.0 else 1.0
    squares = []
    y = 0.0
    for c in counts:
        s = (1.0 / c) * sc
        h = s
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    if y > 1.0 + 1e-9:
        return None
    return squares


def _gen_counts(n, k):
    """Generate candidate count distributions of n into k rows."""
    base = n // k
    rem = n % k
    # candidate 1: as even as possible
    yield [base + (1 if i < rem else 0) for i in range(k)]
    # candidate 2: big/small mix (geometric-ish), all useful
    if k >= 2:
        # one big row, rest as small as possible gaining height efficiency
        for big in range(1, n - k + 2):
            rest = n - big
            rows = k - 1
            if rows <= 0:
                continue
            b = rest // rows
            r = rest % rows
            if b == 0:
                continue
            c = [big] + [b + (1 if i < r else 0) for i in range(rows)]
            yield c
    # candidate 3: sorted descending distributions
    if k >= 2 and n % k != 0:
        c = [base + 1] * rem + [base] * (k - rem)
        yield c


def _feasible_aa(s):
    n = len(s)
    for (cx, cy, a, si) in s:
        if si < 0 or cx - si / 2 < -1e-9 or cx + si / 2 > 1 + 1e-9 \
           or cy - si / 2 < -1e-9 or cy + si / 2 > 1 + 1e-9:
            return False
    for i in range(n):
        x1, y1, _, s1 = s[i]
        for j in range(i + 1, n):
            x2, y2, _, s2 = s[j]
            if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
               abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                return False
    return True


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_s = -1.0
    for k in range(1, n + 1):
        for counts in _gen_counts(n, k):
            if sum(counts) != n or len(counts) != k:
                continue
            sq = _layout_from_counts(counts)
            if sq is None or len(sq) != n:
                continue
            if _feasible_aa(sq):
                sc = sum(q[3] for q in sq)
                if sc > best_s:
                    best_s = sc
                    best = sq

    if best is None:
        k = math.isqrt(n)
        side = 1.0 / k
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    best = _refine(best, n)
    return best[:n]


def _overlap(p, q):
    """Separating axis test for two possibly rotated squares.
    p,q = (cx,cy,angle,side). Returns True if interiors overlap."""
    import math as _m
    (x1, y1, a1, s1) = p
    (x2, y2, a2, s2) = q
    if s1 <= 0 or s2 <= 0:
        return False
    t1 = a1 * 2 * _m.pi
    t2 = a2 * 2 * _m.pi
    for half1, half2, (c1x, c1y), (c2x, c2y) in ((None, None, None, None),):
        pass
    # half-extent vectors for each square (two axes)
    def axes(t):
        c, s = _m.cos(t), _m.sin(t)
        return [(c, s), (-s, c)]
    u1 = axes(t1)
    u2 = axes(t2)
    axes_list = u1 + u2
    d = (x2 - x1, y2 - y1)
    for (ax, ay) in axes_list:
        # projection radius of square 1 = s1/2*(|u1[0].ax|+|u1[1].ax|)
        r1 = s1 / 2 * (abs(u1[0][0] * ax + u1[0][1] * ay) +
                       abs(u1[1][0] * ax + u1[1][1] * ay))
        r2 = s2 / 2 * (abs(u2[0][0] * ax + u2[0][1] * ay) +
                       abs(u2[1][0] * ax + u2[1][1] * ay))
        dist = abs(d[0] * ax + d[1] * ay)
        if dist >= r1 + r2 - 1e-9:
            return False
    return True


def _inside(p, tol=1e-9):
    import math as _m
    (cx, cy, a, s) = p
    if s < 0:
        return False
    r = s / 2 * (abs(_m.cos(a * 2 * _m.pi)) + abs(_m.sin(a * 2 * _m.pi)))
    return (cx - r >= -tol and cx + r <= 1 + tol and
            cy - r >= -tol and cy + r <= 1 + tol)


def _feasible(s):
    n = len(s)
    for p in s:
        if not _inside(p):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap(s[i], s[j]):
                return False
    return True


def _refine(sq, n):
    cur = [tuple(q) for q in sq]

    for _ in range(40):
        improved = False
        for i in range(n):
            cx, cy, a, si = cur[i]
            # try growing
            for grow in (0.02, 0.01, 0.005, 0.002, 0.001, 0.0005):
                ns = si + grow
                cand = cur[:i] + [(cx, cy, a, ns)] + cur[i + 1:]
                if _feasible(cand):
                    cur = cand
                    improved = True
                    break
            if improved:
                break
            # try small rotations to open space then grow
            for da in (0.02, -0.02, 0.05, -0.05, 0.1, -0.1, 0.125, -0.125):
                na = (a + da) % 1.0
                cand = cur[:i] + [(cx, cy, na, si)] + cur[i + 1:]
                if _feasible(cand):
                    cur = cand
                    improved = True
                    break
            if improved:
                break
            # try translating to open space then grow
            for (dx, dy) in ((0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01),
                             (0.005, 0.005), (-0.005, 0.005),
                             (0.005, -0.005), (-0.005, -0.005)):
                cand = cur[:i] + [(cx + dx, cy + dy, a, si)] + cur[i + 1:]
                if _feasible(cand):
                    cur = cand
                    improved = True
                    break
            if improved:
                break
        if not improved:
            break
    return cur
# EVOLVE-BLOCK-END
