# EVOLVE-BLOCK-START
"""Squares in a square: row/column band layouts + separating-axis (rotation-aware)
feasibility + greedy inflate refiner + basin-hopping restarts."""
import math
import random


def _corners(cx, cy, a, s):
    ang = a * 2.0 * math.pi
    ca, sa = math.cos(ang), math.sin(ang)
    h = s / 2.0
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for (px, py) in pts:
        out.append((cx + px * ca - py * sa, cy + px * sa + py * ca))
    return out


def _overlap(s1, s2, eps=1e-9):
    """Separating axis test for two squares. Returns True if interiors overlap."""
    x1, y1, a1, s1_ = s1
    x2, y2, a2, s2_ = s2
    if abs(x1 - x2) >= (s1_ + s2_) / 2 * 1.4143 and abs(y1 - y2) >= (s1_ + s2_) / 2 * 1.4143:
        # bounding circle quick reject only when both axis-aligned-ish
        pass
    pa = _corners(x1, y1, a1, s1_)
    pb = _corners(x2, y2, a2, s2_)
    ang1 = a1 * 2.0 * math.pi
    ang2 = a2 * 2.0 * math.pi
    axes = [(math.cos(ang1), math.sin(ang1)), (-math.sin(ang1), math.cos(ang1)),
            (math.cos(ang2), math.sin(ang2)), (-math.sin(ang2), math.cos(ang2))]
    for (ax, ay) in axes:
        m1 = min(ax * p[0] + ay * p[1] for p in pa)
        M1 = max(ax * p[0] + ay * p[1] for p in pa)
        m2 = min(ax * p[0] + ay * p[1] for p in pb)
        M2 = max(ax * p[0] + ay * p[1] for p in pb)
        if M1 <= m2 + eps or M2 <= m1 + eps:
            return False
    return True


def _feasible(s):
    m = len(s)
    for (cx, cy, a, si) in s:
        if si < -1e-12 or cx - si / 2 < -1e-7 or cx + si / 2 > 1 + 1e-7 \
           or cy - si / 2 < -1e-7 or cy + si / 2 > 1 + 1e-7:
            return False
    for i in range(m):
        for j in range(i + 1, m):
            if _overlap(s[i], s[j]):
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _refine(sq, n, rounds=80, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007, 0.0003):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                # try a tiny rotation as well
                for da in (0.02, -0.02, 0.05, -0.05):
                    for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004)):
                        ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                        ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                        cand = cur[:i] + [[ncx, ncy, (a + da) % 1.0, si]] + cur[i + 1:]
                        if _feasible(cand):
                            cur = cand
                            improved = True
                            break
                    else:
                        continue
                    break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 400:
            step = len(comps) // 400 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
    return cands


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 16)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    rnd = random.Random(777)
    for restart in range(40):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.03 * (0.3 + rnd.random())
            ncx = min(max(cx + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            na = (a + rnd.uniform(-0.05, 0.05)) % 1.0
            cur[i] = [ncx, ncy, na, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
        if not _feasible(cur):
            cur = [list(q) for q in best]
            continue
        r = _refine([tuple(q) for q in cur], n, rounds=50, seed=restart * 13 + 1)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=40, seed=999)
    return best[:n]
# EVOLVE-BLOCK-END
