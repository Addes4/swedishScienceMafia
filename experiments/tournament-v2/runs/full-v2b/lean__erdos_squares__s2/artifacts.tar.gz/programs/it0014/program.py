# EVOLVE-BLOCK-START
"""Squares in a square: row/column layouts + rotated-square inflate refiner."""
import math
import random


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _corners(cx, cy, a, s):
    """Return the 4 corners of a rotated square."""
    t = a * 2 * math.pi
    ca, sa = math.cos(t), math.sin(t)
    h = s / 2.0
    pts = []
    for (dx, dy) in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _proj(pts, axis):
    d = [p[0] * axis[0] + p[1] * axis[1] for p in pts]
    return min(d), max(d)


def _overlap(b1, b2):
    """True if two convex polygons' interiors overlap (SAT)."""
    for poly in (b1, b2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ax, ay = -(y2 - y1), (x2 - x1)
            nrm = math.hypot(ax, ay)
            if nrm < 1e-15:
                continue
            ax /= nrm
            ay /= nrm
            lo1, hi1 = _proj(b1, (ax, ay))
            lo2, hi2 = _proj(b2, (ax, ay))
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return False
    return True


def _feasible(s):
    m = len(s)
    polys = [None] * m
    for i in range(m):
        cx, cy, a, si = s[i]
        if si < -1e-12:
            return False
        pts = _corners(cx, cy, a, si)
        for (px, py) in pts:
            if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                return False
        polys[i] = pts
    for i in range(m):
        for j in range(i + 1, m):
            if _overlap(polys[i], polys[j]):
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _refine(sq, n, rounds=80, seed=12345, allow_rotate=True):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                # try small rotations (helps interlocking) plus translations
                angles = [0.0]
                if allow_rotate:
                    angles = [0.02, -0.02, 0.05, -0.05, 0.1, -0.1,
                              0.15, -0.15, 0.25, -0.25, 0.35, -0.35]
                moved = False
                for da in angles:
                    for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                                   (0.003, 0.003), (-0.003, -0.003),
                                   (0.003, -0.003), (-0.003, 0.003)):
                        ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                        ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                        cand = cur[:i] + [[ncx, ncy, a + da, si]] + cur[i + 1:]
                        if _feasible(cand):
                            cur = cand
                            improved = True
                            moved = True
                            break
                    if moved:
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 400:
            step = len(comps) // 400 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
    return cands


def _strip_layout(n):
    """A diagonal / tilted strip pattern that can help mid-size n."""
    res = []
    i = 0
    y = 0.0
    while i < n:
        c = 1 if (i % 3 == 0) else 2
        c = min(c, n - i)
        h = 1.0 / (c + 1)
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        for j in range(c):
            res.append((xoff + (j + 0.5) * s, 0.0, 0.0, s))
        i += c
    # normalize vertical positions
    m = len(res)
    res2 = []
    yy = 0.0
    row = 0
    for i in range(n):
        res2.append([res[i][0], 0.0, 0.0, res[i][3]])
    return [tuple(r) for r in res2]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 14)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=50, seed=999)
    best = _refine(best, n, rounds=60, seed=7, allow_rotate=True)
    return best[:n]
# EVOLVE-BLOCK-END
