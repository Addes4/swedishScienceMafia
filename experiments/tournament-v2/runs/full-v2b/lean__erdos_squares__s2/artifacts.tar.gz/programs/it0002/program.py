# EVOLVE-BLOCK-START
"""Factor-pair grid initialisation plus local size inflation."""
import math
import numpy as np
from scipy.optimize import minimize


def _factor_pair(n):
    """Return (a, b) with a*b >= n, a <= b, minimising max(a,b)/min(a,b) imbalance."""
    best = None
    for a in range(1, int(math.isqrt(n)) + 2):
        b = (n + a - 1) // a
        if a * b < n:
            continue
        key = (b / a, b)
        if best is None or key < best[0]:
            best = (key, a, b)
    return best[1], best[2]


def _initial(n):
    """Build an initial configuration: a x b grid, extras as size-zero squares."""
    a, b = _factor_pair(n)
    # a rows, b columns; cell is 1/a by 1/b
    h = 1.0 / a
    w = 1.0 / b
    squares = []
    for i in range(a):
        for j in range(b):
            cx = (j + 0.5) * w
            cy = (i + 0.5) * h
            squares.append((cx, cy, 0.0, min(w, h)))
    # pad/trim
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _overlap_penalty(cx, cy, s, k, min_gap=0.0):
    """Return total pairwise squared violation of axis-aligned separation."""
    # half-extents
    hx = s * 0.5
    hy = s * 0.5
    total = 0.0
    for i in range(k):
        for j in range(i + 1, k):
            dx = abs(cx[i] - cx[j])
            dy = abs(cy[i] - cy[j])
            gx = (hx[i] + hx[j]) + min_gap - dx
            gy = (hy[i] + hy[j]) + min_gap - dy
            ox = max(0.0, gx)
            oy = max(0.0, gy)
            total += (ox * ox + oy * oy)
    return total


def solve(n):
    base = _initial(n)
    # work with arrays
    cx = np.array([s[0] for s in base], dtype=float)
    cy = np.array([s[1] for s in base], dtype=float)
    sz = np.array([s[3] for s in base], dtype=float)

    scale = 1e-6
    # leave a small margin so squares stay strictly inside [0,1]
    eps = 1e-4

    def unpack(v):
        return v[:n], v[n:2 * n], v[2 * n:3 * n]

    def objective(v):
        X, Y, S = unpack(v)
        # maximise sum of sides => minimise negative
        pen = _overlap_penalty(X, Y, S, n)
        return -np.sum(S) + 200.0 * pen

    # build constraints: centre bounds depend on size, but sizes vary,
    # so use simple bound constraints plus penalty already in objective
    bounds = [(eps, 1.0 - eps)] * (2 * n) + [(0.0, 1.0)] * n

    v0 = np.concatenate([cx, cy, sz])
    try:
        res = minimize(objective, v0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': 500, 'ftol': 1e-12})
        X, Y, S = unpack(res.x)
    except Exception:
        X, Y, S = cx, cy, sz

    # Safety: enforce centres strictly inside using actual half extent
    out = []
    for i in range(n):
        s = float(max(0.0, S[i]))
        h = s * 0.5
        x = float(min(max(X[i], h + eps), 1.0 - h - eps))
        y = float(min(max(Y[i], h + eps), 1.0 - h - eps))
        out.append((x, y, 0.0, s))
    return out
# EVOLVE-BLOCK-END
