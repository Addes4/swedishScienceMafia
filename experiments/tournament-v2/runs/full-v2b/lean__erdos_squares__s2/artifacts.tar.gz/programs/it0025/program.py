# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid/diagonal layouts + strong inflate
refiner with compaction and basin-hopping restarts to escape local optima."""
import math
import random


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _diagonal_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    total_h = sum(heights)
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        shift = (y / max(total_h, 1e-9)) * (1.0 - c * s)
        xoff = shift
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            if cx - s / 2 < -1e-9 or cx + s / 2 > 1 + 1e-9:
                cx = min(max(cx, s / 2), 1 - s / 2)
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _corners(cx, cy, a, s):
    ca = math.cos(2 * math.pi * a)
    sa = math.sin(2 * math.pi * a)
    hs = s / 2.0
    pts = []
    for dx, dy in ((hs, hs), (-hs, hs), (-hs, -hs), (hs, -hs)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _sat_overlap(c1, c2):
    """True if the two convex quads c1, c2 overlap in interior."""
    for quad in (c1, c2):
        for i in range(4):
            x1, y1 = quad[i]
            x2, y2 = quad[(i + 1) % 4]
            ax, ay = -(y2 - y1), (x2 - x1)
            nrm = math.hypot(ax, ay)
            if nrm < 1e-15:
                continue
            ax /= nrm
            ay /= nrm
            mn1 = mx1 = ax * c1[0][0] + ay * c1[0][1]
            for (px, py) in c1[1:]:
                v = ax * px + ay * py
                if v < mn1:
                    mn1 = v
                if v > mx1:
                    mx1 = v
            mn2 = mx2 = ax * c2[0][0] + ay * c2[0][1]
            for (px, py) in c2[1:]:
                v = ax * px + ay * py
                if v < mn2:
                    mn2 = v
                if v > mx2:
                    mx2 = v
            if mx1 <= mn2 + 1e-9 or mx2 <= mn1 + 1e-9:
                return False
    return True


def _feasible(s):
    m = len(s)
    quads = []
    for (cx, cy, a, si) in s:
        if si < -1e-12:
            return False
        cs = _corners(cx, cy, a, si)
        for (px, py) in cs:
            if px < -1e-8 or px > 1 + 1e-8 or py < -1e-8 or py > 1 + 1e-8:
                return False
        quads.append(cs)
    for i in range(m):
        for j in range(i + 1, m):
            if _sat_overlap(quads[i], quads[j]):
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _fits_others(cur, i, skip=()):
    """check square i against all others except those in skip"""
    ci = _corners(*cur[i][:1], cur[i][2], cur[i][3]) if False else _corners(cur[i][0], cur[i][1], cur[i][2], cur[i][3])
    for (px, py) in ci:
        if px < -1e-8 or px > 1 + 1e-8 or py < -1e-8 or py > 1 + 1e-8:
            return False
    for j in range(len(cur)):
        if j == i or j in cur[0].__class__ if False else False:
            pass
    for j in range(len(cur)):
        if j == i:
            continue
        if _sat_overlap(ci, _corners(cur[j][0], cur[j][1], cur[j][2], cur[j][3])):
            return False
    return True


def _refine(sq, n, rounds=80, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                               (0.003, 0.003), (-0.003, -0.003),
                               (0.003, -0.003), (-0.003, 0.003)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compact(sq, n, rounds=12, seed=31337):
    """Shrink overlapping neighbours then grow target: escapes local optima."""
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: cur[i][3])
        for i in order:
            cur_i = cur[i]
            for grow in (0.02, 0.01, 0.005, 0.002):
                ns = cur_i[3] + grow
                ci = _corners(cur_i[0], cur_i[1], cur_i[2], ns)
                if any(px < -1e-8 or px > 1 + 1e-8 or py < -1e-8 or py > 1 + 1e-8
                       for (px, py) in ci):
                    continue
                neigh = []
                ok_place = True
                for j in range(n):
                    if j == i:
                        continue
                    cj = _corners(cur[j][0], cur[j][1], cur[j][2], cur[j][3])
                    if _sat_overlap(ci, cj):
                        neigh.append(j)
                if len(neigh) > 2:
                    continue
                # try shrinking neighbours slightly
                trial = [list(q) for q in cur]
                ok = True
                for j in neigh:
                    sj = trial[j][3]
                    snew = sj * (1.0 - max(0.02, grow / max(sj, 1e-9)))
                    trial[j][3] = max(snew, 1e-6)
                trial[i][3] = ns
                if _feasible(trial):
                    # accept if total not decreased
                    if _total(trial) >= _total(cur) - 1e-6:
                        cur = trial
                        improved = True
                        break
            # local nudge to open space
            if not improved:
                for j in range(n):
                    if j == i:
                        continue
                    cj = _corners(cur[j][0], cur[j][1], cur[j][2], cur[j][3])
                    ci = _corners(cur[i][0], cur[i][1], cur[i][2], cur[i][3])
                    if not _sat_overlap(ci, cj):
                        continue
                    dx = cur[j][0] - cur[i][0]
                    dy = cur[j][1] - cur[i][1]
                    d = math.hypot(dx, dy) + 1e-9
                    step = 0.004
                    trial = [list(q) for q in cur]
                    trial[j][0] = min(max(trial[j][0] + step * dx / d, 0.0), 1.0)
                    trial[j][1] = min(max(trial[j][1] + step * dy / d, 0.0), 1.0)
                    if _feasible(trial):
                        cur = trial
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 400:
            step = len(comps) // 400 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
            dq = _diagonal_layout(n, counts)
            if len(dq) == n and _feasible(dq):
                cands.append(dq)
    return cands


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 16)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        r = _compact(r, n, rounds=10, seed=1)
        r = _refine(r, n, rounds=40, seed=2)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    rnd = random.Random(777)
    for restart in range(30):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.03 * (0.3 + rnd.random())
            ncx = min(max(cx + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            cur[i] = [ncx, ncy, a, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
        if not _feasible(cur):
            continue
        r = _refine([tuple(q) for q in cur], n, rounds=50, seed=restart * 13 + 1)
        r = _compact(r, n, rounds=10, seed=restart * 7 + 3)
        r = _refine(r, n, rounds=30, seed=restart * 11 + 5)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _compact(best, n, rounds=15, seed=4242)
    best = _refine(best, n, rounds=40, seed=999)
    return best[:n]
# EVOLVE-BLOCK-END

