# EVOLVE-BLOCK-START
"""Squares in a square: maximize sum of side lengths.

Strategy:
  - Build a feasible initial packing: an a x b grid of squares.
  - Refine with SLSQP, treating squares as (cx,cy,angle,side), maximizing sum
    of sides subject to:
        * each square inside the unit box (via its 4 rotated corners),
        * pairwise non-overlap via separating-axis theorem on the 4 corner
          projections (linear-ish constraints handled by penalty).
  A smooth penalty on overlap is used in the objective so SLSQP handles it.
"""
import math
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, ang, s):
    """4 corners of a square (angle is fraction of full turn)."""
    t = 2.0 * math.pi * ang
    ct, st = math.cos(t), math.sin(t)
    h = 0.5 * s
    # local corners
    lx = np.array([-h, h, h, -h])
    ly = np.array([-h, -h, h, h])
    x = cx + ct * lx - st * ly
    y = cy + st * lx + ct * ly
    return x, y


def _overlap_depth(r1, r2):
    """Approx penetration depth between two rotated squares using SAT.
    Returns >0 if separated (distance-like), <=0 if overlapping."""
    cx1, cy1, a1, s1 = r1
    cx2, cy2, a2, s2 = r2
    x1, y1 = _corners(cx1, cy1, a1, s1)
    x2, y2 = _corners(cx2, cy2, a2, s2)
    # axes: normals of both squares edges
    axes = []
    for (xs, ys) in ((x1, y1), (x2, y2)):
        for k in range(4):
            ex = xs[(k + 1) % 4] - xs[k]
            ey = ys[(k + 1) % 4] - ys[k]
            n = math.hypot(ex, ey)
            if n > 1e-12:
                axes.append((-ey / n, ex / n))
    # minimum gap across axes; positive gap = separated
    best_gap = -1e18
    for (ax, ay) in axes:
        p1 = x1 * ax + y1 * ay
        p2 = x2 * ax + y2 * ay
        gap = max(min(p2) - max(p1), min(p1) - max(p2))
        if gap > best_gap:
            best_gap = gap
        if best_gap >= 0:
            return best_gap
    return best_gap


def _feasible(r1, r2):
    return _overlap_depth(r1, r2) > 1e-9


def _build_grid(n):
    """Largest a*b >= n grid that fills as much as possible."""
    best = None
    best_side = -1
    for a in range(1, n + 1):
        b = (n + a - 1) // a
        if a * b < n:
            continue
        # place n squares on an a x b grid, cell size = 1/max(a,b)
        # Use cell = 1/max(a,b); arrange rows of a or b.
        m = max(a, b)
        side = 1.0 / m
        if side > best_side:
            best_side = side
            best = (a, b)
    return best


def _initial(n):
    """Feasible initial packing, axis aligned grid."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    a, b = _build_grid(n)
    # arrange as a columns x b rows (or b x a)
    m = max(a, b)
    side = 1.0 / m - 1e-6
    sq = []
    cols = a
    rows = b
    if rows * cols < n:
        cols, rows = rows, cols
    # fit within box
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            cx = (c + 0.5) * side
            cy = (r + 0.5) * side
            sq.append((cx, cy, 0.0, side))
            idx += 1
        if idx >= n:
            break
    while len(sq) < n:
        sq.append((0.5, 0.5, 0.0, 0.0))
    return sq[:n]


def _refine(n, init):
    """SLSQP refinement maximizing sum of sides with penalties."""
    x0 = []
    for (cx, cy, a, s) in init:
        x0.extend([cx, cy, a, s])
    x0 = np.array(x0, dtype=float)

    def unpack(x):
        return [(x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3])
                for i in range(n)]

    def objective(x):
        sq = unpack(x)
        total = 0.0
        pen = 0.0
        # want large sides
        for (_, _, _, s) in sq:
            if s < 0:
                pen += 1e3 * s * s
            total += s if s > 0 else 0.0
        # inside box: penalties for corners out of [0,1]
        for (cx, cy, a, s) in sq:
            if s <= 0:
                continue
            xs, ys = _corners(cx, cy, a, s)
            for v in xs:
                if v < 0:
                    pen += 1e3 * v * v
                elif v > 1:
                    pen += 1e3 * (v - 1) ** 2
            for v in ys:
                if v < 0:
                    pen += 1e3 * v * v
                elif v > 1:
                    pen += 1e3 * (v - 1) ** 2
        # overlap penalties
        for i in range(n):
            for j in range(i + 1, n):
                if sq[i][3] <= 1e-9 or sq[j][3] <= 1e-9:
                    continue
                g = _overlap_depth(sq[i], sq[j])
                if g < 0:
                    pen += 1e3 * g * g
        return -total + pen

    res = minimize(objective, x0, method='Nelder-Mead',
                   options={'maxiter': 4000, 'xatol': 1e-6, 'fatol': 1e-8})
    x = res.x
    # project to feasible
    sq = unpack(x)
    # scale down any square still violating after refine
    return sq


def _final_cleanup(n, sq):
    """Ensure strict feasibility; shrink violators."""
    sq = [list(q) for q in sq]
    for _ in range(200):
        changed = False
        for i in range(n):
            cx, cy, a, s = sq[i]
            if s < 0:
                sq[i][3] = 0.0
                changed = True
                continue
            # inside box
            xs, ys = _corners(cx, cy, a, s)
            mx = max(max(xs), 1 - min(xs)) if s > 0 else 0
            # compute max overflow
            over = 0.0
            for v in xs:
                if v < 0:
                    over = max(over, -v)
                elif v > 1:
                    over = max(over, v - 1)
            for v in ys:
                if v < 0:
                    over = max(over, -v)
                elif v > 1:
                    over = max(over, v - 1)
            if over > 1e-12:
                sq[i][3] = max(0.0, s - 2 * over - 1e-9)
                changed = True
        for i in range(n):
            for j in range(i + 1, n):
                if sq[i][3] <= 0 or sq[j][3] <= 0:
                    continue
                g = _overlap_depth(tuple(sq[i]), tuple(sq[j]))
                if g <= 1e-9:
                    # shrink both a bit
                    sq[i][3] = max(0.0, sq[i][3] * 0.98)
                    sq[j][3] = max(0.0, sq[j][3] * 0.98)
                    changed = True
        if not changed:
            break
    return [tuple(q) for q in sq]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    init = _initial(n)
    try:
        sq = _refine(n, init)
    except Exception:
        sq = init
    sq = _final_cleanup(n, sq)
    # make sure length exactly n, clamp
    out = []
    for (cx, cy, a, s) in sq:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        a = a % 1.0
        s = min(1.0, max(0.0, s))
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
# EVOLVE-BLOCK-END
