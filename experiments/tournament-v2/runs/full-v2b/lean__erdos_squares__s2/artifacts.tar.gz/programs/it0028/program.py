# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid/diagonal layouts + strong inflate
refiner with compaction/regrow and basin-hopping restarts."""
import math
import random


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _diagonal_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    total_h = sum(heights)
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        shift = (y / max(total_h, 1e-9)) * (1.0 - c * s)
        xoff = shift
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            if cx - s / 2 < -1e-9 or cx + s / 2 > 1 + 1e-9:
                cx = min(max(cx, s / 2), 1 - s / 2)
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _feasible(s):
    m = len(s)
    for (cx, cy, a, si) in s:
        if si < -1e-12 or cx - si / 2 < -1e-9 or cx + si / 2 > 1 + 1e-9 \
           or cy - si / 2 < -1e-9 or cy + si / 2 > 1 + 1e-9:
            return False
    for i in range(m):
        x1, y1, _, s1 = s[i]
        for j in range(i + 1, m):
            x2, y2, _, s2 = s[j]
            if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
               abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _try_grow(cur, i, grow_targets, rnd, cand_dirs):
    """Try to grow square i to current side + grow, testing small moves."""
    cx, cy, a, si = cur[i]
    for grow in grow_targets:
        ns = si + grow
        if ns > 1.0 + 1e-12:
            continue
        for dx, dy in cand_dirs(grow):
            ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
            ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
            cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
            if _feasible(cand):
                return cand
    return None


def _refine(sq, n, rounds=80, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]

    def cand_dirs(grow):
        ds = [(0, 0), (grow/2, 0), (-grow/2, 0),
              (0, grow/2), (0, -grow/2),
              (grow/2, grow/2), (-grow/2, -grow/2),
              (grow/2, -grow/2), (-grow/2, grow/2)]
        for _r in range(4):
            ang = rnd.uniform(0, 2 * math.pi)
            ds.append((grow * math.cos(ang), grow * math.sin(ang)))
        return ds

    grow_targets = (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007)
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            if _try_grow(cur, i, grow_targets, rnd, cand_dirs) is not None:
                cur = _try_grow(cur, i, grow_targets, rnd, cand_dirs)
                improved = True
                continue
            # fallback: slide (no growth)
            cx, cy, a, si = cur[i]
            moved = False
            for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                           (0.003, 0.003), (-0.003, -0.003),
                           (0.003, -0.003), (-0.003, 0.003)):
                ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                if _feasible(cand):
                    cur = cand
                    improved = True
                    moved = True
                    break
            if not moved:
                # compaction/regrow: shrink blockers, grow i, then re-grow them
                cur2 = _compact_grow(cur, i, n, grow_targets, cand_dirs, rnd)
                if cur2 is not None:
                    cur = cur2
                    improved = True
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compact_grow(cur, i, n, grow_targets, cand_dirs, rnd):
    """Shrink squares that block i, grow i, then re-grow others."""
    x1, y1, a1, s1 = cur[i]
    target = s1 * 1.06
    # find blockers: squares whose bounding box overlaps i's expansion
    shrunk = []
    work = [list(q) for q in cur]
    for j in range(n):
        if j == i:
            continue
        x2, y2, a2, s2 = work[j]
        # distance in max-norm
        need = (target + s2) / 2.0
        if abs(x1 - x2) < need and abs(y1 - y2) < need:
            new_s = s2 * 0.85
            if new_s < 1e-6:
                return None
            work[j][3] = new_s
            # keep center within bounds
            work[j][0] = min(max(work[j][0], new_s / 2), 1 - new_s / 2)
            work[j][1] = min(max(work[j][1], new_s / 2), 1 - new_s / 2)
            shrunk.append(j)
    if not shrunk:
        return None
    # grow square i
    cx, cy = x1, y1
    ns = target
    ncx = min(max(cx, ns / 2), 1 - ns / 2)
    ncy = min(max(cy, ns / 2), 1 - ns / 2)
    work[i] = [ncx, ncy, a1, ns]
    if not _feasible(work):
        return None
    # re-grow the shrunk squares
    for j in shrunk:
        cg = _try_grow(work, j, grow_targets, rnd, cand_dirs)
        if cg is not None:
            work = cg
    if not _feasible(work):
        return None
    return work


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _shelf_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        x = 0.0
        cy = y + h / 2.0
        for j in range(c):
            cx = min(x + s / 2.0, 1 - s / 2.0)
            squares.append((cx, cy, 0.0, s))
            x += s
        y += h
    return squares


def _corner_layout(n, seed=0):
    rnd = random.Random(seed)
    squares = []
    big = 0.5
    squares.append((big / 2.0, big / 2.0, 0.0, big))
    x = big
    y = 0.0
    row_h = 0.0
    for i in range(n - 1):
        s = 0.5 / (i + 2.0)
        if x + s > 1.0 + 1e-9:
            x = 0.0
            y += row_h if row_h > 0 else s
            row_h = 0.0
        cy = min(y + s / 2.0, 1 - s / 2.0)
        cx = min(x + s / 2.0, 1 - s / 2.0)
        squares.append((cx, cy, 0.0, s))
        x += s
        row_h = max(row_h, s)
    return squares


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 500:
            step = len(comps) // 500 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
            dq = _diagonal_layout(n, counts)
            if len(dq) == n and _feasible(dq):
                cands.append(dq)
            shq = _shelf_layout(n, counts)
            if len(shq) == n and _feasible(shq):
                cands.append(shq)
    return cands


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    for sd in range(4):
        cq = _corner_layout(n, seed=sd)
        if len(cq) == n and _feasible(cq):
            cands.append(cq)

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 22)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    rnd = random.Random(777)
    for restart in range(50):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.03 * (0.3 + rnd.random())
            ncx = min(max(cx + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            cur[i] = [ncx, ncy, a, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
            cur[i][0] = min(max(cur[i][0], cur[i][3] / 2), 1 - cur[i][3] / 2)
            cur[i][1] = min(max(cur[i][1], cur[i][3] / 2), 1 - cur[i][3] / 2)
        if not _feasible(cur):
            cur = [list(q) for q in best]
            continue
        r = _refine([tuple(q) for q in cur], n, rounds=50, seed=restart * 13 + 1)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=40, seed=999)
    return best[:n]
# EVOLVE-BLOCK-END
