# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid/diagonal layouts plus a
fast inflate refiner with a targeted "reinsert the smallest" escape step.

Design goals:
  * keep the candidate generators cheap and deterministic
  * spend nearly the whole 60 s budget on refinement, not on construction
  * break the one-square-at-a-time inflation plateau by repeatedly removing
    the smallest square and re-growing the leftover free space.
"""
import math
import random


# --------------------------------------------------------------------------
# cheap deterministic constructors
# --------------------------------------------------------------------------
def _make_layout(n, counts):
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _shelf_layout(n, counts):
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        x = 0.0
        cy = y + h / 2.0
        for j in range(c):
            cx = min(x + s / 2.0, 1 - s / 2.0)
            squares.append((cx, cy, 0.0, s))
            x += s
        y += h
    return squares


def _diagonal_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    total_h = sum(heights)
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        shift = (y / max(total_h, 1e-9)) * (1.0 - c * s)
        xoff = shift
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            if cx - s / 2 < -1e-9 or cx + s / 2 > 1 + 1e-9:
                cx = min(max(cx, s / 2), 1 - s / 2)
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


# --------------------------------------------------------------------------
# geometry helpers (axis aligned)
# --------------------------------------------------------------------------
def _feasible(s):
    m = len(s)
    for q in s:
        cx, cy, _a, si = q
        if si < -1e-12 or cx - si / 2 < -1e-9 or cx + si / 2 > 1 + 1e-9 \
           or cy - si / 2 < -1e-9 or cy + si / 2 > 1 + 1e-9:
            return False
    for i in range(m):
        x1, y1, _, s1 = s[i]
        for j in range(i + 1, m):
            x2, y2, _, s2 = s[j]
            if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
               abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                return False
    return True


def _total(s):
    t = 0.0
    for q in s:
        t += q[3]
    return t


def _ok_square(cur, i, cx, cy, si):
    """check square i against walls and all others"""
    if si < -1e-12:
        return False
    if cx - si / 2 < -1e-9 or cx + si / 2 > 1 + 1e-9:
        return False
    if cy - si / 2 < -1e-9 or cy + si / 2 > 1 + 1e-9:
        return False
    for j, q in enumerate(cur):
        if j == i:
            continue
        ox, oy, _a, os_ = q
        if abs(ox - cx) < (si + os_) / 2 - 1e-9 and \
           abs(oy - cy) < (si + os_) / 2 - 1e-9:
            return False
    return True


# --------------------------------------------------------------------------
# refiner: inflate each square greedily (with random kicks)
# --------------------------------------------------------------------------
def _refine(sq, n, rounds=80, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    grows = (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007)
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in grows:
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(2):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                               (0.003, 0.003), (-0.003, -0.003),
                               (0.003, -0.003), (-0.003, 0.003)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _slide_polish(sq, n, rounds=40):
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            maxhalf = min(1.0 - cx, cx, 1.0 - cy, cy)
            for j in range(n):
                if j == i:
                    continue
                ox, oy, _, os_ = cur[j]
                need = (si + os_) / 2.0
                if abs(ox - cx) < need and abs(oy - cy) < need:
                    maxhalf = si / 2.0
                    break
                dx = abs(ox - cx)
                dy = abs(oy - cy)
                lim = max(dx, dy) - os_ / 2.0
                if lim < maxhalf:
                    maxhalf = lim
            if maxhalf > si / 2.0 + 1e-12:
                ns = 2.0 * maxhalf - 1e-9
                if _ok_square(cur, i, cx, cy, ns):
                    cur[i] = [cx, cy, a, ns]
                    si = ns
                    improved = True
                    continue
            for (dxs, dys) in ((1, 0), (-1, 0), (0, 1), (0, -1),
                               (0.7071, 0.7071), (-0.7071, -0.7071),
                               (0.7071, -0.7071), (-0.7071, 0.7071)):
                lo, hi = 0.0, 0.2
                for _ in range(18):
                    mid = 0.5 * (lo + hi)
                    ncx = cx + dxs * mid
                    ncy = cy + dys * mid
                    if _ok_square(cur, i, ncx, ncy, si):
                        lo = mid
                    else:
                        hi = mid
                if lo > 1e-7:
                    ncx = cx + dxs * lo
                    ncy = cy + dys * lo
                    cur[i] = [ncx, ncy, a, si]
                    cx, cy = ncx, ncy
                    improved = True
        if not improved:
            break
    return [tuple(q) for q in cur]


# --------------------------------------------------------------------------
# escape step: drop the smallest square, grow the rest, put it back
# --------------------------------------------------------------------------
def _largest_free_square(cur, i_ignore, steps=45):
    """Greedily find the largest axis-aligned square fitting in free space
    (keeping square index i_ignore as itself, treating others as obstacles)."""
    best = (0.0, 0.5, 0.5)
    # candidate centres: grid + corners of neighbours + edges of neighbours
    cands = []
    for fx in (0.0, 0.25, 0.5, 0.75, 1.0):
        for fy in (0.0, 0.25, 0.5, 0.75, 1.0):
            cands.append((fx, fy))
    for j, q in enumerate(cur):
        if j == i_ignore:
            continue
        ox, oy, _a, os_ = q
        h = os_ / 2.0
        for (px, py) in ((ox + h, oy), (ox - h, oy), (ox, oy + h), (ox, oy - h),
                         (ox + h, oy + h), (ox - h, oy - h),
                         (ox + h, oy - h), (ox - h, oy + h)):
            if -1e-9 <= px <= 1 + 1e-9 and -1e-9 <= py <= 1 + 1e-9:
                cands.append((px, py))
    for (cx0, cy0) in cands:
        # simple expanding search around this anchor
        s = 0.001
        for _ in range(steps):
            ns = s * 1.15 + 0.001
            cx = min(max(cx0, ns / 2), 1 - ns / 2)
            cy = min(max(cy0, ns / 2), 1 - ns / 2)
            if _ok_square(cur, i_ignore, cx, cy, ns):
                s = ns
            else:
                break
        if s > best[0]:
            cx = min(max(cx0, s / 2), 1 - s / 2)
            cy = min(max(cy0, s / 2), 1 - s / 2)
            if _ok_square(cur, i_ignore, cx, cy, s):
                best = (s, cx, cy)
    return best


def _reinsert_polish(sq, n, rounds=6, seed=1):
    """Remove the smallest square, grow the remaining layout first, then place
    the removed one (or a bigger/smaller one) into the leftover free space."""
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        # drop smallest
        order = sorted(range(n), key=lambda i: cur[i][3])
        i = order[0]
        removed = cur[i]
        cur[i] = [removed[0], removed[1], removed[2], 0.0]
        # temporarily null out removed square (side 0) and re-inflate the rest
        cur2 = _refine([tuple(q) for q in cur], n, rounds=25,
                       seed=rnd.randrange(10**6))
        cur = [list(q) for q in cur2]
        # find largest free square for the empty slot
        s, cx, cy = _largest_free_square(cur, i)
        if s > cur[i][3] + 1e-9:
            cur[i] = [cx, cy, 0.0, max(s - 1e-9, 0.0)]
        else:
            cur[i] = [removed[0], removed[1], 0.0, 0.0]
        cur = [list(q) for q in _refine([tuple(q) for q in cur], n,
                                        rounds=25, seed=rnd.randrange(10**6))]
    return [tuple(q) for q in cur]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return

    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n, cap_per_k=60):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = []
        cnt = 0
        for c in _compositions(n, k):
            comps.append(c)
            cnt += 1
            if cnt >= cap_per_k:
                break
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            for maker in (_make_layout, _column_layout, _diagonal_layout,
                          _shelf_layout):
                sq = maker(n, counts)
                if len(sq) == n and _feasible(sq):
                    cands.append(sq)
    return cands


def _candidate_layouts_cheap(n, cap_per_k=30):
    """smaller pool used for large n so we do not blow the budget"""
    cands = []
    seen = set()
    for k in range(1, min(n, 6) + 1):
        comps = []
        cnt = 0
        for c in _compositions(n, k):
            comps.append(c)
            cnt += 1
            if cnt >= cap_per_k:
                break
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            for maker in (_make_layout, _shelf_layout):
                sq = maker(n, counts)
                if len(sq) == n and _feasible(sq):
                    cands.append(sq)
    for k in range(7, min(n, 12) + 1):
        for c in _compositions(n, k):
            for maker in (_shelf_layout,):
                sq = maker(n, c)
                if len(sq) == n and _feasible(sq):
                    cands.append(sq)
            break
    return cands


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------
def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    if n <= 40:
        cands = _candidate_layouts(n, cap_per_k=50)
    else:
        cands = _candidate_layouts_cheap(n)

    if not cands:
        cands = [_make_layout(n, [n])]

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 14)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=50)
        r = _slide_polish(r, n, rounds=25)
        r = _refine(r, n, rounds=25)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    # random restarts (cheap, bounded)
    rnd = random.Random(777)
    nrestart = 20 if n <= 40 else 8
    for restart in range(nrestart):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.03 * (0.3 + rnd.random())
            ncx = min(max(cx + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            cur[i] = [ncx, ncy, a, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
            cur[i][0] = min(max(cur[i][0], cur[i][3] / 2), 1 - cur[i][3] / 2)
            cur[i][1] = min(max(cur[i][1], cur[i][3] / 2), 1 - cur[i][3] / 2)
        if not _feasible(cur):
            continue
        r = _refine([tuple(q) for q in cur], n, rounds=35, seed=restart * 13 + 1)
        r = _slide_polish(r, n, rounds=15)
        r = _refine(r, n, rounds=20, seed=restart * 13 + 1)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    # escape the plateau: reinsert polish
    n_ri = 5 if n <= 40 else 2
    for t in range(n_ri):
        r = _reinsert_polish(best, n, rounds=4, seed=1000 + t)
        r = _slide_polish(r, n, rounds=20)
        r = _refine(r, n, rounds=30, seed=2000 + t)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=35, seed=999)
    best = _slide_polish(best, n, rounds=35)
    best = _refine(best, n, rounds=35, seed=998)
    return best[:n]
# EVOLVE-BLOCK-END
