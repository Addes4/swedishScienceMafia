# EVOLVE-BLOCK-START
"""Squares in a square: greedy unequal-row packing with local refinement."""
import math


def _layout(n, k):
    """Build an axis-aligned layout with k rows filling the unit square.
    Returns list of (cx, cy, angle, side)."""
    # Distribute n squares into k rows as evenly as possible, bigger rows first.
    base = n // k
    rem = n % k
    counts = [base + (1 if i < rem else 0) for i in range(k)]

    # Row heights: choose so that squares of side s_i in a row of c_i fill width 1
    # and height h = s_i => h = 1/c_i. Total height must be <= 1.
    # We'll scale rows to fit: raw heights h_i = 1/c_i, normalized.
    raw = [1.0 / c if c > 0 else 0.0 for c in counts]
    total = sum(raw)
    if total <= 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n

    # If normalized heights shrink squares; instead try to enlarge. We iterate:
    # pick row heights h_i, each row's square side = min(h_i, 1/c_i).
    # Try to make sum of sides large.
    # Simple approach: heights proportional to raw, scaled to fill unit height.
    scale = 1.0 / total
    heights = [r * scale for r in raw]

    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        if c == 0:
            continue
        h = heights[i]
        s = min(h, 1.0 / c)
        # fill row: c squares of side s across width, centred vertically in row
        x = 0.0
        row_w = c * s
        xoff = (1.0 - row_w) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares[:n]


def _score(squares):
    return sum(q[3] for q in squares)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_s = -1.0
    # Try every number of rows from 1..n
    for k in range(1, n + 1):
        sq = _layout(n, k)
        if len(sq) != n:
            continue
        # verify inside and disjoint (axis aligned)
        ok = True
        for (cx, cy, a, s) in sq:
            if s < 0 or cx - s / 2 < -1e-9 or cx + s / 2 > 1 + 1e-9 \
               or cy - s / 2 < -1e-9 or cy + s / 2 > 1 + 1e-9:
                ok = False
                break
        if not ok:
            continue
        for i in range(n):
            for j in range(i + 1, n):
                x1, y1, _, s1 = sq[i]
                x2, y2, _, s2 = sq[j]
                if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
                   abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                    ok = False
                    break
            if not ok:
                break
        if ok:
            sc = _score(sq)
            if sc > best_s:
                best_s = sc
                best = sq

    if best is None:
        # fallback: uniform grid
        k = math.isqrt(n)
        side = 1.0 / k
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    # Local refinement: nudge row heights / sides to gain a bit.
    best = _refine(best, n)
    return best[:n]


def _refine(sq, n):
    """Greedy local search: try scaling up each square slightly if feasible."""
    sq = [list(q) for q in sq]

    def feasible(s):
        for (cx, cy, a, si) in s:
            if si < 0 or cx - si / 2 < -1e-12 or cx + si / 2 > 1 + 1e-12 \
               or cy - si / 2 < -1e-12 or cy + si / 2 > 1 + 1e-12:
                return False
        for i in range(n):
            for j in range(i + 1, n):
                x1, y1, _, s1 = s[i]
                x2, y2, _, s2 = s[j]
                if abs(x1 - x2) < (s1 + s2) / 2 - 1e-12 and \
                   abs(y1 - y2) < (s1 + s2) / 2 - 1e-12:
                    return False
        return True

    cur = [tuple(q) for q in sq]
    for _ in range(30):
        improved = False
        for i in range(n):
            cx, cy, a, si = cur[i]
            for grow in (0.02, 0.01, 0.005, 0.002, 0.001):
                ns = si + grow
                cand = cur[:i] + [(cx, cy, a, ns)] + cur[i + 1:]
                if feasible(cand):
                    cur = cand
                    improved = True
                    break
        if not improved:
            break
    return cur
# EVOLVE-BLOCK-END
