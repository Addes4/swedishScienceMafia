# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid/diagonal layouts + a bitmap
corner-occupancy constructor + strong inflate refiner with basin-hopping."""
import math
import random


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _diagonal_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    total_h = sum(heights)
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        shift = (y / max(total_h, 1e-9)) * (1.0 - c * s)
        xoff = shift
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            if cx - s / 2 < -1e-9 or cx + s / 2 > 1 + 1e-9:
                cx = min(max(cx, s / 2), 1 - s / 2)
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _feasible(s):
    m = len(s)
    for (cx, cy, a, si) in s:
        if si < -1e-12 or cx - si / 2 < -1e-9 or cx + si / 2 > 1 + 1e-9 \
           or cy - si / 2 < -1e-9 or cy + si / 2 > 1 + 1e-9:
            return False
    for i in range(m):
        x1, y1, _, s1 = s[i]
        for j in range(i + 1, m):
            x2, y2, _, s2 = s[j]
            if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
               abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _refine(sq, n, rounds=80, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                               (0.003, 0.003), (-0.003, -0.003),
                               (0.003, -0.003), (-0.003, 0.003)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _shelf_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        x = 0.0
        cy = y + h / 2.0
        for j in range(c):
            cx = min(x + s / 2.0, 1 - s / 2.0)
            squares.append((cx, cy, 0.0, s))
            x += s
        y += h
    return squares


def _corner_layout(n, seed=0):
    rnd = random.Random(seed)
    first = 1.0
    squares = [(0.5, 0.5, 0.0, first)]
    remaining = n - 1
    if remaining <= 0:
        return squares
    squares = []
    big = 0.5
    squares.append((big / 2.0, big / 2.0, 0.0, big))
    x = big
    y = 0.0
    row_h = 0.0
    for i in range(n - 1):
        s = 0.5 / (i + 2.0)
        if x + s > 1.0 + 1e-9:
            x = 0.0
            y += row_h if row_h > 0 else s
            row_h = 0.0
        cy = min(y + s / 2.0, 1 - s / 2.0)
        cx = min(x + s / 2.0, 1 - s / 2.0)
        squares.append((cx, cy, 0.0, s))
        x += s
        row_h = max(row_h, s)
    return squares


def _bitmap_layout(n, seed=0, grid=140, req=None):
    """Greedy bitmap constructor. If req is given it supplies the requested
    sizes (largest first, decreasing); otherwise a harmonic-ish sequence is used.
    Squares shrink gracefully when no gap fits the requested size."""
    rnd = random.Random(seed)
    G = grid
    occ = [bytearray(G) for _ in range(G)]
    squares = []

    if req is None:
        req = []
        for i in range(n):
            req.append(1.0 / (i + 1.7))
    req = list(req)
    # normalise so the largest ~ fits inside the unit square
    mx = max(req) if req else 1.0
    req = [r / max(mx, 1e-9) for r in req]
    # pad/truncate to n
    while len(req) < n:
        req.append(req[-1] * 0.9 if req else 0.1)
    req = req[:n]

    def free(cx, cy, s):
        half = s / 2.0
        x0 = int(math.floor((cx - half) * G))
        x1 = int(math.ceil((cx + half) * G))
        y0 = int(math.floor((cy - half) * G))
        y1 = int(math.ceil((cy + half) * G))
        if x0 < 0 or y0 < 0 or x1 > G or y1 > G:
            return False
        for yy in range(y0, y1):
            row = occ[yy]
            for xx in range(x0, x1):
                if row[xx]:
                    return False
        return True

    def mark(cx, cy, s):
        half = s / 2.0
        x0 = max(0, int(math.floor((cx - half) * G)))
        x1 = min(G, int(math.ceil((cx + half) * G)))
        y0 = max(0, int(math.floor((cy - half) * G)))
        y1 = min(G, int(math.ceil((cy + half) * G)))
        for yy in range(y0, y1):
            row = occ[yy]
            for xx in range(x0, x1):
                row[xx] = 1

    # candidate anchor points: coarse lattice for the first placement
    anchors = []
    step = 0.1
    kk = 0
    while kk <= 10 + 1e-9:
        ll = 0
        while ll <= 10 + 1e-9:
            anchors.append((kk * step, ll * step))
            ll += 1
        kk += 1

    for i in range(n):
        target = req[i]
        best = None
        order = anchors[:]
        rnd.shuffle(order)
        for (ax, ay) in order:
            s = target
            tries = 0
            while s > 1e-3 and tries < 6:
                cx = min(max(ax + s / 2.0, s / 2.0), 1 - s / 2.0)
                cy = min(max(ay + s / 2.0, s / 2.0), 1 - s / 2.0)
                if free(cx, cy, s):
                    score = s + 0.01 * rnd.random()
                    if best is None or score > best[0]:
                        best = (score, cx, cy, s)
                    break
                s *= 0.8
                tries += 1
        if best is None:
            placed = False
            for yy in range(G):
                if placed:
                    break
                for xx in range(G):
                    if not occ[yy][xx]:
                        mark((xx + 0.5) / G, (yy + 0.5) / G, 1.0 / G)
                        squares.append(((xx + 0.5) / G, (yy + 0.5) / G, 0.0,
                                        1.0 / G))
                        placed = True
                        break
            if not placed:
                squares.append((0.5, 0.5, 0.0, 0.0))
            continue
        _, cx, cy, s = best
        mark(cx, cy, s)
        squares.append((cx, cy, 0.0, s))
        half = s / 2.0
        for (px, py) in ((cx + half, cy + half), (cx - half, cy + half),
                         (cx + half, cy - half), (cx - half, cy - half),
                         (cx + half, cy), (cx - half, cy),
                         (cx, cy + half), (cx, cy - half)):
            if -1e-9 <= px <= 1 + 1e-9 and -1e-9 <= py <= 1 + 1e-9:
                anchors.append((px, py))
    return squares


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 300:
            step = len(comps) // 300 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
            dq = _diagonal_layout(n, counts)
            if len(dq) == n and _feasible(dq):
                cands.append(dq)
            shq = _shelf_layout(n, counts)
            if len(shq) == n and _feasible(shq):
                cands.append(shq)
    return cands


def _random_req(rnd, n, kind):
    """Generate a decreasing sequence of requested sizes."""
    if kind == 0:
        base = 1.0 / (rnd.uniform(1.3, 2.2))
        return [base / (i + 1) for i in range(n)]
    if kind == 1:
        a = rnd.uniform(0.8, 1.6)
        b = rnd.uniform(1.2, 2.6)
        return [a / (i + b) for i in range(n)]
    if kind == 2:
        return [(1.0 - rnd.uniform(0.0, 0.05) * i) / rnd.uniform(1.0, 2.0)
                for i in range(n)]
    # exponential-ish decay
    r = rnd.uniform(0.5, 0.85)
    seq = []
    v = 1.0
    for i in range(n):
        seq.append(v)
        v *= r
    return seq


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    for sd in range(4):
        cq = _corner_layout(n, seed=sd)
        if len(cq) == n and _feasible(cq):
            cands.append(cq)

    # bitmap corner-occupancy constructs
    for sd in range(6):
        try:
            bq = _bitmap_layout(n, seed=sd, grid=140)
        except Exception:
            bq = []
        if len(bq) == n and _feasible(bq):
            cands.append(bq)

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 26)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    rnd = random.Random(777)
    for restart in range(60):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.03 * (0.3 + rnd.random())
            ncx = min(max(cx + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            cur[i] = [ncx, ncy, a, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
        if not _feasible(cur):
            cur = [list(q) for q in best]
            continue
        r = _refine([tuple(q) for q in cur], n, rounds=50, seed=restart * 13 + 1)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=40, seed=999)

    # Extensive randomized bitmap search to escape the fixed harmonic layout.
    rnd2 = random.Random(20240517)
    for it in range(120):
        kind = rnd2.randrange(4)
        req = _random_req(rnd2, n, kind)
        grid = rnd2.choice((100, 120, 140, 160, 180))
        try:
            bq = _bitmap_layout(n, seed=rnd2.randrange(10**6), grid=grid, req=req)
        except Exception:
            continue
        if len(bq) != n or not _feasible(bq):
            continue
        r = _refine(bq, n, rounds=50, seed=it * 7 + 3)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r
            # tight extra polish on the new best
            r2 = _refine(best, n, rounds=30, seed=it * 7 + 500)
            sc2 = _total(r2)
            if sc2 > best_s:
                best_s = sc2
                best = r2

    return best[:n]
# EVOLVE-BLOCK-END
