# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid/diagonal layouts + strong inflate
refiner with basin-hopping restarts and a rotation-aware polish using a
correct separating-axis overlap test."""
import math
import random


def _corners(cx, cy, a, s):
    ang = a * 2.0 * math.pi
    c, sn = math.cos(ang), math.sin(ang)
    h = s / 2.0
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _overlap_sat(q1, q2):
    """True if two squares (cx,cy,a,s) overlap with positive area."""
    p1 = _corners(*q1)
    p2 = _corners(*q2)
    for pts in (p1, p2):
        axes = []
        for k in range(4):
            x1, y1 = pts[k]
            x2, y2 = pts[(k + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            axes.append((-ey, ex))
        for ax, ay in axes:
            L = math.hypot(ax, ay)
            if L < 1e-15:
                continue
            ax /= L
            ay /= L
            min1 = min(px * ax + py * ay for px, py in p1)
            max1 = max(px * ax + py * ay for px, py in p1)
            min2 = min(px * ax + py * ay for px, py in p2)
            max2 = max(px * ax + py * ay for px, py in p2)
            if max1 < min2 + 1e-9 or max2 < min1 + 1e-9:
                return False
    return True


def _feasible(s):
    m = len(s)
    for (cx, cy, a, si) in s:
        if si < -1e-12 or cx - si / 2 < -1e-9 or cx + si / 2 > 1 + 1e-9 \
           or cy - si / 2 < -1e-9 or cy + si / 2 > 1 + 1e-9:
            return False
    for i in range(m):
        for j in range(i + 1, m):
            if _overlap_sat(s[i], s[j]):
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _diagonal_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    total_h = sum(heights)
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        shift = (y / max(total_h, 1e-9)) * (1.0 - c * s)
        xoff = shift
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            if cx - s / 2 < -1e-9 or cx + s / 2 > 1 + 1e-9:
                cx = min(max(cx, s / 2), 1 - s / 2)
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _refine(sq, n, rounds=80, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                               (0.003, 0.003), (-0.003, -0.003),
                               (0.003, -0.003), (-0.003, 0.003)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _refine_rot(sq, n, rounds=60, seed=24680):
    """Rotation-aware refiner: try angle tweaks together with growth, using SAT."""
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.04, 0.02, 0.01, 0.005, 0.0025, 0.0012, 0.0006, 0.0003):
                for dth in (0.0, 0.01, -0.01, 0.02, -0.02, 0.04, -0.04, 0.08, -0.08):
                    na = (a + dth) % 0.5  # keep orientation (mod 180 deg)
                    ns = si + grow
                    cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                             (0, grow/2), (0, -grow/2)]
                    for _r in range(2):
                        ang = rnd.uniform(0, 2 * math.pi)
                        cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                    for dx, dy in cands:
                        ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                        ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                        cand = cur[:i] + [[ncx, ncy, na, ns]] + cur[i + 1:]
                        if _feasible(cand):
                            cur = cand
                            grew = True
                            improved = True
                            break
                    if grew:
                        break
                if grew:
                    break
            if not grew:
                # try rotation-only move to enable later growth
                for dth in (0.02, -0.02, 0.05, -0.05):
                    na = (a + dth) % 0.5
                    cand = cur[:i] + [[cx, cy, na, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 500:
            step = len(comps) // 500 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
            dq = _diagonal_layout(n, counts)
            if len(dq) == n and _feasible(dq):
                cands.append(dq)
    return cands


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 18)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    # basin-hopping: perturb centres of the best packing and re-refine
    rnd = random.Random(777)
    for restart in range(40):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.03 * (0.3 + rnd.random())
            ncx = min(max(cx + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            cur[i] = [ncx, ncy, a, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
        if not _feasible(cur):
            cur = [list(q) for q in best]
            continue
        r = _refine([tuple(q) for q in cur], n, rounds=50, seed=restart * 13 + 1)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=40, seed=999)

    # rotation-aware polish from the best packing and several jittered variants
    best_rot = best
    best_rot_s = _total(best)
    starts = [best]
    rnd2 = random.Random(31337)
    for _ in range(6):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.02
            ncx = min(max(cx + rnd2.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd2.uniform(-amp, amp), si / 2), 1 - si / 2)
            cur[i] = [ncx, ncy, a, si]
        if _feasible(cur):
            starts.append([tuple(q) for q in cur])

    for idx, st in enumerate(starts):
        r = _refine_rot(st, n, rounds=40, seed=idx * 101 + 5)
        sc = _total(r)
        if sc > best_rot_s:
            best_rot_s = sc
            best_rot = r

    if best_rot_s >= _total(best):
        return best_rot[:n]
    return best[:n]
# EVOLVE-BLOCK-END
