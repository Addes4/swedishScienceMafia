# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid layouts + strong inflate refiner."""
import math
import random


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _feasible(s):
    m = len(s)
    for (cx, cy, a, si) in s:
        if si < -1e-12 or cx - si / 2 < -1e-9 or cx + si / 2 > 1 + 1e-9 \
           or cy - si / 2 < -1e-9 or cy + si / 2 > 1 + 1e-9:
            return False
    for i in range(m):
        x1, y1, _, s1 = s[i]
        for j in range(i + 1, m):
            x2, y2, _, s2 = s[j]
            if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
               abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _refine(sq, n, rounds=80, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                # random small jitter candidates
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                               (0.003, 0.003), (-0.003, -0.003),
                               (0.003, -0.003), (-0.003, 0.003)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 400:
            step = len(comps) // 400 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
    return cands


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    # pick top candidates by raw score, refine the best few
    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 12)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    # one more polish pass on the best
    best = _refine(best, n, rounds=40, seed=999)
    return best[:n]
# EVOLVE-BLOCK-END
