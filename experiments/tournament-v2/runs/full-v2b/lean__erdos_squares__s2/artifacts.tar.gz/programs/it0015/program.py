# EVOLVE-BLOCK-START
"""Squares in a square: row layouts + SAT-based rotate-and-grow refiner."""
import math
import random


def _corners(cx, cy, a, s):
    h = s / 2.0
    ca = math.cos(2 * math.pi * a)
    sa = math.sin(2 * math.pi * a)
    pts = []
    for (ux, uy) in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + ux * ca - uy * sa, cy + ux * sa + uy * ca))
    return pts


def _overlap(p1, p2):
    # separating axis test for two convex polygons
    for poly in (p1, p2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            nx = -(y2 - y1)
            ny = (x2 - x1)
            mn1 = mx1 = None
            for (px, py) in p1:
                d = px * nx + py * ny
                if mn1 is None or d < mn1:
                    mn1 = d
                if mx1 is None or d > mx1:
                    mx1 = d
            mn2 = mx2 = None
            for (px, py) in p2:
                d = px * nx + py * ny
                if mn2 is None or d < mn2:
                    mn2 = d
                if mx2 is None or d > mx2:
                    mx2 = d
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return False
    return True


def _feasible(s):
    m = len(s)
    polys = []
    for (cx, cy, a, si) in s:
        if si < -1e-12:
            return False
        if si > 0:
            for (px, py) in _corners(cx, cy, a, si):
                if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                    return False
        polys.append(_corners(cx, cy, a, si))
    for i in range(m):
        for j in range(i + 1, m):
            s1 = s[i][3]
            s2 = s[j][3]
            if s1 <= 0 or s2 <= 0:
                continue
            if _overlap(polys[i], polys[j]):
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        ssum = sum(heights)
        if ssum > 0:
            heights = [h / ssum for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        side = min(h, 1.0 / c)
        xoff = (1.0 - c * side) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * side
            squares.append((cx, cy, 0.0, side))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return

    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 400:
            step = len(comps) // 400 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            for maker in (_make_layout, _column_layout):
                sq = maker(n, counts)
                if len(sq) == n and _feasible(sq):
                    cands.append(sq)
    return cands


def _refine(sq, n, rounds=80, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]

    def try_set(i, val):
        cand = cur[:i] + [val] + cur[i + 1:]
        if _feasible(cand):
            cur[:] = cand
            return True
        return False

    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            # grow in place (centres and angle fixed)
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007):
                ns = si + grow
                if ns > 0:
                    # keep must be inside; nudge centre inward if needed
                    ncx = min(max(cx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy, ns / 2), 1 - ns / 2)
                    if try_set(i, [ncx, ncy, a, ns]):
                        cx, cy, si = ncx, ncy, ns
                        grew = True
                        improved = True
                        break
                cands = [(0, 0), (grow / 2, 0), (-grow / 2, 0),
                         (0, grow / 2), (0, -grow / 2)]
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    if try_set(i, [ncx, ncy, a, ns]):
                        cx, cy, si = ncx, ncy, ns
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                # try rotation+jitter to open space
                for da in (0.02, -0.02, 0.05, -0.05, 0.125, -0.125, 0.25, -0.25):
                    na = (a + da) % 1.0
                    if try_set(i, [cx, cy, na, si]):
                        a = na
                        improved = True
                        break
            if not grew:
                for dx, dy in ((0.005, 0), (-0.005, 0), (0, 0.005), (0, -0.005),
                               (0.004, 0.004), (-0.004, -0.004),
                               (0.004, -0.004), (-0.004, 0.004)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    if try_set(i, [ncx, ncy, a, si]):
                        cx, cy = ncx, ncy
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 12)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=50, seed=999)
    # clamp everything into [0,1] as a safety net
    out = []
    for (cx, cy, a, si) in best[:n]:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = min(max(a, 0.0), 1.0)
        si = min(max(si, 0.0), 1.0)
        out.append((cx, cy, a, si))
    return out
# EVOLVE-BLOCK-END
