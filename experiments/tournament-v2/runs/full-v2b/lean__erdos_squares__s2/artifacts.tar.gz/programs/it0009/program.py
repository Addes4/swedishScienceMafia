# EVOLVE-BLOCK-START
"""Squares in a square: row-band packing with greedy expansion refinement."""
import math


def _make_layout(n, counts):
    """Given row counts (list of ints summing to n), build a layout.

    Row i has c_i squares of equal side s_i = min(h_i, 1/c_i) packed across width.
    Heights h_i chosen so that sum(h_i)=1 while maximizing sum(c_i*s_i).
    The optimal allocation: with excess width unused when 1/c_i < h_i.
    We solve: maximize sum min(h_i, w_i) with w_i=1/c_i, sum h_i = 1, h_i>=0.
    Optimal: set h_i = w_i for rows we fully fill; the slack goes to the row
    with largest w_i (to raise its side). But if all fully filled sum w_i < 1,
    extra height goes to the row with the largest c_i? Actually extra height only
    increases side of a row up to its cap min(h_i, w_i): once h_i>=w_i, side=w_i
    and adding more height is wasted. So best: allocate excess to shrink? No.
    We instead reduce squares? Simpler: distribute proportional to w_i, then trim.
    """
    k = len(counts)
    caps = [1.0 / c for c in counts]  # max useful height
    total_cap = sum(caps)
    if total_cap <= 1.0:
        # All rows can be fully filled; leftover height is useless for side sum.
        heights = caps[:]
    else:
        # Need to compress; the marginal value of height in a saturated row is 0,
        # unsaturated row value 1. So water-fill: find level t such that
        # sum(min(cap_i, t)) = 1.  Then h_i = min(cap_i, t).
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        # normalize exactly
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]

    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _feasible(s):
    m = len(s)
    for (cx, cy, a, si) in s:
        if si < -1e-12 or cx - si / 2 < -1e-9 or cx + si / 2 > 1 + 1e-9 \
           or cy - si / 2 < -1e-9 or cy + si / 2 > 1 + 1e-9:
            return False
    for i in range(m):
        x1, y1, _, s1 = s[i]
        for j in range(i + 1, m):
            x2, y2, _, s2 = s[j]
            if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
               abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                return False
    return True


def _refine(sq, n, rounds=40):
    """Greedy coordinate search: try to grow each square and move it to gain."""
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            # try growing side, possibly repositioning to make room
            for grow in (0.05, 0.02, 0.01, 0.005, 0.002, 0.001):
                ns = si + grow
                # try several centre positions around current
                for dx, dy in ((0, 0), (grow/2, 0), (-grow/2, 0),
                               (0, grow/2), (0, -grow/2),
                               (grow/2, grow/2), (-grow/2, -grow/2),
                               (grow/2, -grow/2), (-grow/2, grow/2)):
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                # small shift without growth to free space (no gain directly)
                for dx, dy in ((0.005, 0), (-0.005, 0), (0, 0.005), (0, -0.005)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compositions(n, k):
    """Yield non-increasing compositions of n into k positive parts (as row counts)."""
    if k == 1:
        yield (n,)
        return
    # parts in non-increasing order to reduce symmetry
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_s = -1.0
    # try many row counts; sample compositions to stay within time
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        # limit number of compositions examined for large k
        if len(comps) > 300:
            step = len(comps) // 300 + 1
            comps = comps[::step]
        for counts in comps:
            sq = _make_layout(n, counts)
            if len(sq) != n:
                continue
            if not _feasible(sq):
                continue
            sc = sum(q[3] for q in sq)
            if sc > best_s:
                best_s = sc
                best = sq

    if best is None:
        best = _make_layout(n, [n])

    best = _refine(best, n)
    return best[:n]
# EVOLVE-BLOCK-END
