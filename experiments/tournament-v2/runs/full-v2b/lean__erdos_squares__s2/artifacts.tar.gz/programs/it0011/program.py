# EVOLVE-BLOCK-START
"""Squares in a square: row-band packing with greedy + continuous refinement."""
import math

try:
    import numpy as np
    from scipy.optimize import minimize
    _HAVE_SCIPY = True
except Exception:
    _HAVE_SCIPY = False


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]

    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _feasible(s):
    m = len(s)
    for (cx, cy, a, si) in s:
        if si < -1e-12 or cx - si / 2 < -1e-9 or cx + si / 2 > 1 + 1e-9 \
           or cy - si / 2 < -1e-9 or cy + si / 2 > 1 + 1e-9:
            return False
    for i in range(m):
        x1, y1, _, s1 = s[i]
        for j in range(i + 1, m):
            x2, y2, _, s2 = s[j]
            if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
               abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                return False
    return True


def _greedy_refine(sq, n, rounds=60):
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.02, 0.01, 0.005, 0.002, 0.001, 0.0005):
                ns = si + grow
                for dx, dy in ((0, 0), (grow/2, 0), (-grow/2, 0),
                               (0, grow/2), (0, -grow/2),
                               (grow/2, grow/2), (-grow/2, -grow/2),
                               (grow/2, -grow/2), (-grow/2, grow/2)):
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.005, 0), (-0.005, 0), (0, 0.005), (0, -0.005),
                               (0.003, 0.003), (-0.003, -0.003)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _continuous_refine(sq, n, iters=300):
    """Soft-penalty continuous optimization: variables (cx, cy, s) per square.

    Maximize sum(s) subject to boxes inside [0,1]^2 and non-overlap.
    We use a repulsion penalty on overlap and hard clamp via parameterization
    cx in [s/2, 1-s/2] handled by projection during line search (we simply
    penalize boundary violations too, then project at the end).
    """
    if not _HAVE_SCIPY:
        return [tuple(q) for q in sq]
    x0 = np.zeros(3 * n)
    for i, (cx, cy, a, si) in enumerate(sq):
        x0[3*i] = cx
        x0[3*i+1] = cy
        x0[3*i+2] = si

    def unpack(x):
        return x.reshape(n, 3)

    def objective(x):
        v = unpack(x)
        cx = v[:, 0]; cy = v[:, 1]; s = v[:, 2]
        val = -np.sum(s)  # maximize sum s
        # boundary penalty
        pen = 0.0
        pen += np.sum(np.maximum(0, s/2 - cx) ** 2)
        pen += np.sum(np.maximum(0, cx + s/2 - 1) ** 2)
        pen += np.sum(np.maximum(0, s/2 - cy) ** 2)
        pen += np.sum(np.maximum(0, cy + s/2 - 1) ** 2)
        # overlap penalty
        dx = np.abs(cx[:, None] - cx[None, :])
        dy = np.abs(cy[:, None] - cy[None, :])
        th = (s[:, None] + s[None, :]) / 2.0
        ox = np.maximum(0, th - dx)
        oy = np.maximum(0, th - dy)
        ov = np.minimum(ox, oy)
        iu = np.triu_indices(n, 1)
        pen += 50.0 * np.sum(ov[iu] ** 2)
        pen += 5.0 * np.sum(ov[iu])
        return val + pen

    try:
        res = minimize(objective, x0, method='L-BFGS-B',
                       options={'maxiter': iters, 'ftol': 1e-12, 'gtol': 1e-9})
        v = unpack(res.x)
    except Exception:
        return [tuple(q) for q in sq]

    out = []
    for i in range(n):
        cx, cy, s = v[i, 0], v[i, 1], v[i, 2]
        a = sq[i][2]
        s = max(s, 0.0)
        cx = min(max(cx, s/2), 1 - s/2)
        cy = min(max(cy, s/2), 1 - s/2)
        out.append([cx, cy, a, s])
    # repair any remaining overlap by shrinking
    for _ in range(20):
        bad = False
        for i in range(n):
            for j in range(i+1, n):
                x1, y1, _, s1 = out[i]
                x2, y2, _, s2 = out[j]
                ex = (s1 + s2)/2 - abs(x1 - x2)
                ey = (s1 + s2)/2 - abs(y1 - y2)
                if ex > 1e-9 and ey > 1e-9:
                    bad = True
                    shrink = min(ex, ey) / 2 + 1e-6
                    out[i][3] = max(0.0, out[i][3] - shrink)
                    out[j][3] = max(0.0, out[j][3] - shrink)
        if not bad:
            break
    for q in out:
        q[3] = max(q[3], 0.0)
        q[0] = min(max(q[0], q[3]/2), 1 - q[3]/2)
        q[1] = min(max(q[1], q[3]/2), 1 - q[3]/2)
    return [tuple(q) for q in out]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_s = -1.0
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 200:
            step = len(comps) // 200 + 1
            comps = comps[::step]
        for counts in comps:
            sq = _make_layout(n, counts)
            if len(sq) != n:
                continue
            if not _feasible(sq):
                continue
            sc = sum(q[3] for q in sq)
            if sc > best_s:
                best_s = sc
                best = sq

    if best is None:
        best = _make_layout(n, [n])

    best = _greedy_refine(best, n)
    # Try continuous refinement from a few top candidates
    cand = _continuous_refine(best, n)
    if _feasible(cand) and sum(q[3] for q in cand) > sum(q[3] for q in best):
        best = cand
    # final greedy polish
    best = _greedy_refine(best, n, rounds=20)
    return best[:n]
# EVOLVE-BLOCK-END
