# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid layouts + strong inflate refiner
with basin-hopping restarts (jitter + drop-and-regrow) to escape local optima."""
import math
import random


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _feasible(s):
    m = len(s)
    for (cx, cy, a, si) in s:
        if si < -1e-12 or cx - si / 2 < -1e-9 or cx + si / 2 > 1 + 1e-9 \
           or cy - si / 2 < -1e-9 or cy + si / 2 > 1 + 1e-9:
            return False
    for i in range(m):
        x1, y1, _, s1 = s[i]
        for j in range(i + 1, m):
            x2, y2, _, s2 = s[j]
            if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
               abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _refine(sq, n, rounds=80, seed=12345):
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.05, 0.025, 0.012, 0.006, 0.003, 0.0015, 0.0007):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.004, 0), (-0.004, 0), (0, 0.004), (0, -0.004),
                               (0.003, 0.003), (-0.003, -0.003),
                               (0.003, -0.003), (-0.003, 0.003)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _try_insert(sq, cand_sq, n):
    """Try to insert a new square into sq; return expanded list or None."""
    for (cx, cy, a, si) in cand_sq:
        placed = False
        # search a coarse grid of centres for the new square
        g = 12
        step = 1.0 / g
        best_pos = None
        best_size = -1.0
        for gi in range(g + 1):
            for gj in range(g + 1):
                px = gi * step
                py = gj * step
                # find max feasible size at this centre vs existing squares
                maxs = 2 * min(px, 1 - px, py, 1 - py)
                if maxs <= 0:
                    continue
                for (x2, y2, _, s2) in sq:
                    dx = abs(px - x2) - s2 / 2
                    dy = abs(py - y2) - s2 / 2
                    # room for half-side along each axis
                    room = min(dx, dy) * 2 if (dx > 0 or dy > 0) else min(dx, dy) * 2
                    # conservative: need both axes clear
                    if dx <= 0 and dy <= 0:
                        maxs = -1
                        break
                    # axis-aligned overlap requires both |dx|<(s+s2)/2 and |dy|<(s+s2)/2
                    # max side s such that NOT (|dx| < (s+s2)/2 and |dy| < (s+s2)/2)
                    lim1 = 2 * dx - s2
                    lim2 = 2 * dy - s2
                    lim = max(lim1, lim2)
                    if lim < maxs:
                        maxs = lim
                if maxs > best_size:
                    best_size = maxs
                    best_pos = (px, py)
        if best_size <= 1e-6 or best_pos is None:
            continue
        sq = sq + [(best_pos[0], best_pos[1], 0.0, best_size)]
        placed = True
    return sq


def _inflate_simul(sq, n, seed=0, iters=40):
    """Simultaneously try to grow all squares a tiny bit; accept if feasible."""
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(iters):
        delta = max(1e-4, 0.02 / (1 + _total(cur)))
        cand = []
        for (cx, cy, a, si) in cur:
            ns = si + 0.002
            cand.append([cx, cy, a, ns])
        if _feasible(cand):
            cur = cand
            continue
        break
    return _refine([tuple(q) for q in cur], n, rounds=40, seed=seed)


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 500:
            step = len(comps) // 500 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
    return cands


def _drop_and_regrow(best, n, rnd):
    """Remove the smallest squares, expand the rest, then reinsert the removed
    ones via grid search.  Returns a candidate packing."""
    m = len(best)
    if m < 3:
        return None
    keep_cnt = max(1, int(round(m * 0.7)))
    order = sorted(range(m), key=lambda i: best[i][3])
    dropped = [best[i] for i in order[:m - keep_cnt]]
    kept = [best[i] for i in order[m - keep_cnt:]]
    kept = [list(q) for q in kept]
    # small jitter to keep dirs separated
    for q in kept:
        s = q[3]
        q[0] = min(max(q[0] + rnd.uniform(-0.01, 0.01), s / 2), 1 - s / 2)
        q[1] = min(max(q[1] + rnd.uniform(-0.01, 0.01), s / 2), 1 - s / 2)
    kept = _refine([tuple(q) for q in kept], len(kept), rounds=40,
                   seed=rnd.randint(1, 10**6))
    total = _total(kept)
    # greedily reinsert dropped squares, biggest first
    dropped_sorted = sorted(dropped, key=lambda q: -q[3])
    packed = list(kept)
    for d in dropped_sorted:
        ins = _try_insert(packed, [d], n)
        if ins is not None and len(ins) > len(packed):
            packed = ins
    if len(packed) != n:
        return None
    # clip feasibility
    for q in packed:
        if q[3] > 0:
            if q[0] - q[3] / 2 < -1e-9 or q[0] + q[3] / 2 > 1 + 1e-9 \
               or q[1] - q[3] / 2 < -1e-9 or q[1] + q[3] / 2 > 1 + 1e-9:
                return None
    if not _feasible(packed):
        return None
    return _refine(packed, n, rounds=50, seed=rnd.randint(1, 10**6))


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 14)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    # basin-hopping: perturb centres of the best packing and re-refine
    rnd = random.Random(777)
    for restart in range(30):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.03 * (0.3 + rnd.random())
            ncx = min(max(cx + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            cur[i] = [ncx, ncy, a, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
        if not _feasible(cur):
            continue
        r = _refine([tuple(q) for q in cur], n, rounds=50, seed=restart * 13 + 1)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    # drop-and-regrow restarts to escape row-structure local optima
    for restart in range(25):
        cand = _drop_and_regrow(best, n, rnd)
        if cand is None:
            continue
        r = _refine(cand, n, rounds=50, seed=restart * 31 + 7)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=40, seed=999)
    return best[:n]
# EVOLVE-BLOCK-END

