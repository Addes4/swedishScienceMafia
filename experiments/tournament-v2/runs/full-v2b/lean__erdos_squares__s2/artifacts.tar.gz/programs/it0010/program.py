# EVOLVE-BLOCK-START
"""Squares in a square: row-band packing + smooth SLSQP inflation refinement."""
import math
import numpy as np
from scipy.optimize import minimize


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]

    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _corners(cx, cy, a, s):
    """Return 4 corners of a square given centre, angle (fraction of turn), side."""
    th = 2.0 * math.pi * a
    c, sn = math.cos(th), math.sin(th)
    hs = s / 2.0
    pts = []
    for dx, dy in ((hs, hs), (-hs, hs), (-hs, -hs), (hs, -hs)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _overlap_nonaxis(q1, q2, eps=1e-10):
    """SAT for two rotated squares. Returns True if they overlap in interior."""
    p1 = _corners(*q1)
    p2 = _corners(*q2)
    for poly, other in ((p1, p2), (p2, p1)):
        for i in range(4):
            ax = poly[i]
            bx = poly[(i + 1) % 4]
            nx = -(bx[1] - ax[1])
            ny = (bx[0] - ax[0])
            L = math.hypot(nx, ny)
            if L < 1e-15:
                continue
            nx /= L
            ny /= L
            d1 = [nx * p[0] + ny * p[1] for p in p1]
            d2 = [nx * p[0] + ny * p[1] for p in p2]
            if min(d1) > max(d2) - eps or min(d2) > max(d1) - eps:
                return False
    return True


def _feasible(s):
    m = len(s)
    for (cx, cy, a, si) in s:
        if si < -1e-9:
            return False
        pts = _corners(cx, cy, a, si)
        for (px, py) in pts:
            if px < -1e-7 or px > 1 + 1e-7 or py < -1e-7 or py > 1 + 1e-7:
                return False
    if m <= 200:
        for i in range(m):
            for j in range(i + 1, m):
                if _overlap_nonaxis(s[i], s[j]):
                    return False
    else:
        for i in range(m):
            for j in range(i + 1, m):
                x1, y1, _, s1 = s[i]
                x2, y2, _, s2 = s[j]
                if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
                   abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                    if _overlap_nonaxis(s[i], s[j]):
                        return False
    return True


def _penalty_and_grad_ok(s):
    return _feasible(s)


def _refine_slsqp(sq, n):
    """Smooth SLSQP inflation: variables = cx,cy,a,s per square.

    Objective: minimize negative sum of sides (plus a tiny regularizer for
    the boundary). Constraints: box for centres/sides and pairwise separation
    via axis-aligned bounds. We use a soft penalty on pairwise overlaps."""
    if n == 0:
        return sq
    # Variables: for each square: cx, cy, s, angle (frac of turn in [-0.25,0.25])
    x0 = np.zeros(4 * n)
    for i, (cx, cy, a, s) in enumerate(sq):
        aa = a
        while aa > 0.25:
            aa -= 0.5
        x0[4 * i] = cx
        x0[4 * i + 1] = cy
        x0[4 * i + 2] = s
        x0[4 * i + 3] = aa

    def unpack(x):
        return [(x[4*i], x[4*i+1], x[4*i+3], x[4*i+2]) for i in range(n)]

    def obj(x):
        s = x[2::4]
        # maximize sum s; small push away from edges to keep interior strength
        return -float(np.sum(s))

    def obj_jac(x):
        g = np.zeros_like(x)
        g[2::4] = -1.0
        return g

    # Smooth overlap penalty over all pairs.
    def penalty(x):
        pen = 0.0
        for i in range(n):
            cxi, cyi, ai, si = x[4*i], x[4*i+1], x[4*i+3], x[4*i+2]
            hi = si / 2.0
            for j in range(i + 1, n):
                cxj, cyj, aj, sj = x[4*j], x[4*j+1], x[4*j+3], x[4*j+2]
                hj = sj / 2.0
                # axis-aligned necessary separation: sum of half-extents along each axis
                # rotated square half-extent along axis = (|cos|+|sin|)*s/2
                ti = (abs(math.cos(2*math.pi*ai)) + abs(math.sin(2*math.pi*ai))) * hi
                tj = (abs(math.cos(2*math.pi*aj)) + abs(math.sin(2*math.pi*aj))) * hj
                ox = ti + tj - abs(cxi - cxj)
                oy = ti + tj - abs(cyi - cyj)
                # only penalize when squares likely overlap (both axes overlapping);
                # but rotated squares overlap iff both axes projections overlap
                # Use smooth penalty = min? Approximate with soft blending.
                if ox > 0 and oy > 0:
                    pen += 100.0 * ox * oy
        return pen

    # Box bounds
    bnds = []
    for i in range(n):
        bnds.append((0.0, 1.0))   # cx
        bnds.append((0.0, 1.0))   # cy
        bnds.append((1e-6, 1.0))  # s
        bnds.append((-0.25, 0.25))  # angle

    def f(x):
        return obj(x) + penalty(x)

    best = list(sq)
    best_score = sum(q[3] for q in sq)
    cur_x = x0
    methods = [("SLSQP", 400)]
    for meth, it in methods:
        try:
            res = minimize(f, cur_x, method=meth, bounds=bnds,
                           options={"maxiter": it, "ftol": 1e-9} if meth == "SLSQP"
                           else {"maxiter": it})
            xs = res.x
            cand = unpack(xs)
            # clamp and snap into feasible region
            cand = [(min(max(cx, s/2), 1 - s/2),
                     min(max(cy, s/2), 1 - s/2), a, s) for (cx, cy, a, s) in cand]
            if _feasible(cand):
                sc = sum(q[3] for q in cand)
                if sc > best_score:
                    best_score = sc
                    best = cand
                    cur_x = xs
        except Exception:
            pass
    return best


def _refine_greedy(sq, n, rounds=40):
    """Greedy coordinate search falling back on axis-align feasibility."""
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.03, 0.015, 0.008, 0.004, 0.002, 0.001):
                ns = si + grow
                for dx, dy in ((0, 0), (grow/2, 0), (-grow/2, 0),
                               (0, grow/2), (0, -grow/2),
                               (grow/2, grow/2), (-grow/2, -grow/2),
                               (grow/2, -grow/2), (-grow/2, grow/2)):
                    ncx = min(max(cx + dx, ns / 2), 1 - ns / 2)
                    ncy = min(max(cy + dy, ns / 2), 1 - ns / 2)
                    cand = cur[:i] + [[ncx, ncy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
            if not grew:
                for dx, dy in ((0.005, 0), (-0.005, 0), (0, 0.005), (0, -0.005)):
                    ncx = min(max(cx + dx, si / 2), 1 - si / 2)
                    ncy = min(max(cy + dy, si / 2), 1 - si / 2)
                    cand = cur[:i] + [[ncx, ncy, a, si]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        improved = True
                        break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return

    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_s = -1.0
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 300:
            step = len(comps) // 300 + 1
            comps = comps[::step]
        for counts in comps:
            sq = _make_layout(n, counts)
            if len(sq) != n:
                continue
            sc = sum(q[3] for q in sq)
            if sc > best_s:
                best_s = sc
                best = sq

    if best is None:
        best = _make_layout(n, [n])

    best = _refine_greedy(best, n)
    best = _refine_slsqp(best, n)
    best = _refine_greedy(best, n)
    return best[:n]
# EVOLVE-BLOCK-END
