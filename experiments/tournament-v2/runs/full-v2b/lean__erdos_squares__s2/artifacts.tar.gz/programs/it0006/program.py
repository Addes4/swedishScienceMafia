# EVOLVE-BLOCK-START
"""Squares in a square: analytic row-composition search + safe refinement."""
import math


def _layout(counts):
    """Given row counts (list of positive ints), place squares filling width.
    Each row i has c_i squares of side s_i = min(h_i, 1/c_i).
    We choose heights h_i >= 0 with sum h_i = 1 to maximise sum c_i*min(h_i,1/c_i).
    Optimal: give rows with c_i <= k full height 1/c_i (side = 1/c_i),
    leftover height to the row with smallest c_i (largest 1/c) -> best marginal.
    Actually use scipy-free greedy: sort rows by 1/c_i desc; assign h_i = min needed.
    Simpler exact: each row's contribution f_i(h)=c_i*min(h,1/c_i).
    Allocate height water-filling to rows in increasing c_i (largest side benefit).
    """
    k = len([c for c in counts if c > 0])
    if k == 0:
        return []
    rows = [c for c in counts if c > 0]
    # water-filling: rows sorted by c ascending get saturated first
    order = sorted(range(len(rows)), key=lambda i: rows[i])
    h = [0.0] * len(rows)
    remaining = 1.0
    # saturate greedily by smallest c (each needs 1/c)
    for idx in order:
        need = 1.0 / rows[idx]
        give = min(need, remaining)
        h[idx] = give
        remaining -= give
        if remaining <= 1e-15:
            break
    # if leftover after all saturated (total 1/c sum < 1), scale all up so sum h=1
    tot = sum(h)
    if tot < 1.0 and tot > 0:
        # distribute leftover to the row giving most side gain: smallest c
        extra = 1.0 - tot
        best_i = min(range(len(rows)), key=lambda i: rows[i])
        h[best_i] += extra

    squares = []
    y = 0.0
    for i, c in enumerate(rows):
        hi = h[i]
        s = min(hi, 1.0 / c)
        if s <= 0:
            y += hi
            continue
        row_w = c * s
        xoff = (1.0 - row_w) / 2.0
        cy = y + hi / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += hi
    return squares


def _compositions(n, maxparts):
    """Generate compositions of n into at most maxparts positive parts."""
    # yields tuples summing to n, nonincreasing, length<=maxparts
    def rec(rem, mx, cur):
        if rem == 0:
            yield tuple(cur)
            return
        if len(cur) >= maxparts:
            return
        top = min(rem, mx)
        for v in range(top, 0, -1):
            cur.append(v)
            yield from rec(rem - v, v, cur)
            cur.pop()
    yield from rec(n, n, [])


def _score(squares):
    return sum(q[3] for q in squares)


def _feasible(s, n):
    for (cx, cy, a, si) in s:
        if si < -1e-12 or cx - si / 2 < -1e-9 or cx + si / 2 > 1 + 1e-9 \
           or cy - si / 2 < -1e-9 or cy + si / 2 > 1 + 1e-9:
            return False
    for i in range(n):
        x1, y1, _, s1 = s[i]
        for j in range(i + 1, n):
            x2, y2, _, s2 = s[j]
            if abs(x1 - x2) < (s1 + s2) / 2 - 1e-9 and \
               abs(y1 - y2) < (s1 + s2) / 2 - 1e-9:
                return False
    return True


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_s = -1.0
    for counts in _compositions(n, n):
        sq = _layout(list(counts))
        if len(sq) != n:
            continue
        if _feasible(sq, n):
            sc = _score(sq)
            if sc > best_s:
                best_s = sc
                best = sq

    if best is None:
        k = math.isqrt(n)
        side = 1.0 / k if k > 0 else 0.0
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    # Safe axis-aligned coordinate-ascent refinement.
    cur = [tuple(q) for q in best]
    for _ in range(50):
        improved = False
        for i in range(n):
            cx, cy, a, si = cur[i]
            for grow in (0.01, 0.005, 0.002, 0.001, 0.0005):
                cand = cur[:i] + [(cx, cy, 0.0, si + grow)] + cur[i + 1:]
                if _feasible(cand, n):
                    cur = cand
                    improved = True
                    break
        if not improved:
            break
    return cur[:n]
# EVOLVE-BLOCK-END
