# EVOLVE-BLOCK-START
"""Grid construction plus local optimization of square sizes/positions."""

import math
import numpy as np
from scipy.optimize import minimize


def _grid(n):
    best = None
    for a in range(1, n + 1):
        b = (n + a - 1) // a
        if a * b < n:
            continue
        # candidate dimensions a x b
        s = 1.0 / max(a, b)
        score = n * s
        if best is None or score > best[0]:
            best = (score, a, b)
    _, a, b = best
    s = 1.0 / max(a, b)
    squares = []
    for i in range(a):
        for j in range(b):
            if len(squares) >= n:
                break
            squares.append([(i + 0.5) * s, (j + 0.5) * s, 0.0, s])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return squares[:n]


def _overlap_penalty(sq):
    # sq: (N,4) arrays; compute max overlap depth between every pair
    N = len(sq)
    pen = 0.0
    for i in range(N):
        for j in range(i + 1, N):
            if sq[i][3] <= 0 or sq[j][3] <= 0:
                continue
            # conservative overlap using sum of half-diagonals in each axis
            dx = abs(sq[i][0] - sq[j][0])
            dy = abs(sq[i][1] - sq[j][1])
            ri = sq[i][3] * 0.5
            rj = sq[j][3] * 0.5
            # rotated squares: use bounding radius along axes
            # conservative circle-based separation
            d2 = dx * dx + dy * dy
            rr = (ri + rj) * 1.4142
            if d2 < rr * rr:
                pen += (rr - math.sqrt(d2)) ** 2
    return pen


def solve(n):
    squares = _grid(n)
    if n <= 3:
        return [tuple(x) for x in squares]

    x0 = np.array(squares, dtype=float).ravel()

    def obj(x):
        sq = x.reshape(-1, 4)
        sides = sq[:, 3]
        # keep inside unit square
        pen = 0.0
        for i in range(len(sq)):
            cx, cy, ang, s = sq[i]
            if s <= 0:
                pen += (s) ** 2 * 1e-3
                continue
            h = s * 0.5
            # rotated half extents
            c = abs(math.cos(ang * 2 * math.pi))
            sn = abs(math.sin(ang * 2 * math.pi))
            ex = h * (c + sn)
            ey = h * (c + sn)
            if cx - ex < 0:
                pen += (ex - cx) ** 2
            if cx + ex > 1:
                pen += (cx + ex - 1) ** 2
            if cy - ey < 0:
                pen += (ey - cy) ** 2
            if cy + ey > 1:
                pen += (cy + ey - 1) ** 2
        pen += _overlap_penalty(sq) * 5.0
        return -np.sum(sides) + pen * 10.0

    res = minimize(obj, x0, method='Nelder-Mead',
                   options={'maxiter': 2000, 'xatol': 1e-4, 'fatol': 1e-6})
    sq = res.x.reshape(-1, 4)
    # clip into unit square
    out = []
    for cx, cy, ang, s in sq:
        s = max(0.0, min(1.0, s))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = ang % 1.0
        out.append((cx, cy, ang, s))
    return out
# EVOLVE-BLOCK-END
