# EVOLVE-BLOCK-START
"""Squares in a square: multi-start row/grid/diagonal layouts + strong inflate
refiner with basin-hopping restarts to escape local optima, plus an optional
rotation-aware polish (SAT collision test) that only accepts strict gains."""
import math
import random


def _make_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        xoff = (1.0 - c * s) / 2.0
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _column_layout(n, counts):
    sq = _make_layout(n, counts)
    return [(cy, cx, 0.25, s) for (cx, cy, a, s) in sq]


def _diagonal_layout(n, counts):
    k = len(counts)
    caps = [1.0 / c for c in counts]
    total_cap = sum(caps)
    if total_cap <= 1.0:
        heights = caps[:]
    else:
        lo, hi = 0.0, max(caps)
        for _ in range(60):
            t = 0.5 * (lo + hi)
            if sum(min(c, t) for c in caps) < 1.0:
                lo = t
            else:
                hi = t
        t = 0.5 * (lo + hi)
        heights = [min(c, t) for c in caps]
        s = sum(heights)
        if s > 0:
            heights = [h / s for h in heights]
    squares = []
    y = 0.0
    total_h = sum(heights)
    for i, c in enumerate(counts):
        h = heights[i]
        s = min(h, 1.0 / c)
        shift = (y / max(total_h, 1e-9)) * (1.0 - c * s)
        xoff = shift
        cy = y + h / 2.0
        for j in range(c):
            cx = xoff + (j + 0.5) * s
            if cx - s / 2 < -1e-9 or cx + s / 2 > 1 + 1e-9:
                cx = min(max(cx, s / 2), 1 - s / 2)
            squares.append((cx, cy, 0.0, s))
        y += h
    return squares


def _corners(cx, cy, a, s):
    """Return the 4 corners of a square given centre, angle (fraction of full
    turn), and side. angle*a*2*pi is the rotation applied."""
    th = a * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s / 2.0
    pts = []
    for dx, dy in ((h, h), (-h, h), (-h, -h), (h, -h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts


def _overlap_sat(sq1, sq2):
    """Separating axis test between two squares. Returns True if their
    interiors overlap."""
    c1 = _corners(*sq1)
    c2 = _corners(*sq2)
    axes = []
    for pts in (c1, c2):
        for i in range(4):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 1e-12:
                axes.append((-ey / ln, ex / ln))
    for ax, ay in axes:
        p1 = [x * ax + y * ay for x, y in c1]
        p2 = [x * ax + y * ay for x, y in c2]
        if max(p1) < min(p2) + 1e-9 or max(p2) < min(p1) + 1e-9:
            return False
    return True


def _feasible(s):
    m = len(s)
    for (cx, cy, a, si) in s:
        if si < -1e-12:
            return False
        pts = _corners(cx, cy, a, si)
        for x, y in pts:
            if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                return False
    for i in range(m):
        for j in range(i + 1, m):
            if _overlap_sat(s[i], s[j]):
                return False
    return True


def _total(s):
    return sum(q[3] for q in s)


def _refine(sq, n, rounds=80, seed=12345):
    """Greedy grow-only refiner using SAT feasibility (handles axis-aligned,
    where angles stay 0)."""
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    for _ in range(rounds):
        improved = False
        order = sorted(range(n), key=lambda i: -cur[i][3])
        for i in order:
            cx, cy, a, si = cur[i]
            grew = False
            for grow in (0.02, 0.01, 0.005, 0.0025, 0.0012, 0.0006, 0.0003):
                ns = si + grow
                cands = [(0, 0), (grow/2, 0), (-grow/2, 0),
                         (0, grow/2), (0, -grow/2),
                         (grow/2, grow/2), (-grow/2, -grow/2),
                         (grow/2, -grow/2), (-grow/2, grow/2)]
                for _r in range(3):
                    ang = rnd.uniform(0, 2 * math.pi)
                    cands.append((grow * math.cos(ang), grow * math.sin(ang)))
                for dx, dy in cands:
                    cand = cur[:i] + [[cx + dx, cy + dy, a, ns]] + cur[i + 1:]
                    if _feasible(cand):
                        cur = cand
                        grew = True
                        improved = True
                        break
                if grew:
                    break
        if not improved:
            break
    return [tuple(q) for q in cur]


def _rotate_polish(sq, n, seed=4242):
    """Try per-square angle tweaks combined with small position adjustments;
    accept only strict total improvements."""
    rnd = random.Random(seed)
    cur = [list(q) for q in sq]
    best_tot = _total(cur)
    for _ in range(60):
        improved = False
        for i in range(n):
            cx, cy, a, si = cur[i]
            best_local = None
            tested = 0
            for _t in range(14):
                da = rnd.uniform(-0.08, 0.08)
                na = (a + da) % 1.0
                dx = rnd.uniform(-0.01, 0.01)
                dy = rnd.uniform(-0.01, 0.01)
                cand = cur[:i] + [[cx + dx, cy + dy, na, si]] + cur[i + 1:]
                if _feasible(cand):
                    # try to grow slightly after rotating
                    grown = _grow_one(cand, i, rnd)
                    if grown is not None:
                        tot = _total(grown)
                        if tot > best_tot + 1e-9:
                            best_local = grown
                            best_tot = tot
                tested += 1
            if best_local is not None:
                cur = best_local
                improved = True
        if not improved:
            break
    return [tuple(q) for q in cur]


def _grow_one(cur, i, rnd):
    cx, cy, a, si = cur[i]
    for grow in (0.01, 0.005, 0.002, 0.001, 0.0005):
        ns = si + grow
        for _ in range(6):
            ang = rnd.uniform(0, 2 * math.pi)
            dx = grow * math.cos(ang)
            dy = grow * math.sin(ang)
            cand = cur[:i] + [[cx + dx, cy + dy, a, ns]] + cur[i + 1:]
            if _feasible(cand):
                return cand
    return None


def _compositions(n, k):
    if k == 1:
        yield (n,)
        return
    def rec(remaining, parts, maxv):
        if len(parts) == k - 1:
            if 1 <= remaining <= maxv:
                yield tuple(parts + [remaining])
            return
        for v in range(min(maxv, remaining - (k - 1 - len(parts))), 0, -1):
            yield from rec(remaining - v, parts + [v], v)
    yield from rec(n, [], n)


def _candidate_layouts(n):
    cands = []
    seen = set()
    for k in range(1, n + 1):
        comps = list(_compositions(n, k))
        if len(comps) > 500:
            step = len(comps) // 500 + 1
            comps = comps[::step]
        for counts in comps:
            if counts in seen:
                continue
            seen.add(counts)
            sq = _make_layout(n, counts)
            if len(sq) == n and _feasible(sq):
                cands.append(sq)
            cq = _column_layout(n, counts)
            if len(cq) == n and _feasible(cq):
                cands.append(cq)
            dq = _diagonal_layout(n, counts)
            if len(dq) == n and _feasible(dq):
                cands.append(dq)
    return cands


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    cands = _candidate_layouts(n)
    if not cands:
        cands = [_make_layout(n, [n])]

    cands.sort(key=_total, reverse=True)
    pool = cands[:min(len(cands), 18)]

    best = None
    best_s = -1.0
    for sq in pool:
        r = _refine(sq, n, rounds=60)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    rnd = random.Random(777)
    for restart in range(40):
        cur = [list(q) for q in best]
        for i in range(n):
            cx, cy, a, si = cur[i]
            amp = 0.03 * (0.3 + rnd.random())
            ncx = min(max(cx + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            ncy = min(max(cy + rnd.uniform(-amp, amp), si / 2), 1 - si / 2)
            cur[i] = [ncx, ncy, a, si]
        for i in rnd.sample(range(n), max(1, n // 3)):
            cur[i][3] *= rnd.uniform(0.75, 0.96)
        if not _feasible(cur):
            cur = [list(q) for q in best]
            continue
        r = _refine([tuple(q) for q in cur], n, rounds=50, seed=restart * 13 + 1)
        sc = _total(r)
        if sc > best_s:
            best_s = sc
            best = r

    best = _refine(best, n, rounds=40, seed=999)

    # rotation-aware polish (only accepts strict gains, handles tilts)
    try:
        rp = _rotate_polish(best, n, seed=31337)
        if _total(rp) > best_s + 1e-9 and _feasible(rp):
            best = rp
            best_s = _total(rp)
    except Exception:
        pass

    return best[:n]
# EVOLVE-BLOCK-END
