import math
import random
import numpy as np


def _overlap_area(s1, s2):
    # Quick separating-axis test for two squares (returns overlap area approximation)
    # s = (cx, cy, angle, side)
    cx1, cy1, a1, w1 = s1
    cx2, cy2, a2, w2 = s2
    if w1 <= 0 or w2 <= 0:
        return 0.0
    h1 = w1 * 0.5
    h2 = w2 * 0.5
    ca1, sa1 = math.cos(a1 * 2 * math.pi), math.sin(a1 * 2 * math.pi)
    ca2, sa2 = math.cos(a2 * 2 * math.pi), math.sin(a2 * 2 * math.pi)
    # axes: two from each square
    axes = [(ca1, sa1), (-sa1, ca1), (ca2, sa2), (-sa2, ca2)]
    # corners
    def corners(cx, cy, ca, sa, h):
        return [
            (cx + (-h * ca - (-h) * sa), cy + (-h * sa + (-h) * ca)),
            (cx + (h * ca - (-h) * sa), cy + (h * sa + (-h) * ca)),
            (cx + (h * ca - h * sa), cy + (h * sa + h * ca)),
            (cx + (-h * ca - h * sa), cy + (-h * sa + h * ca)),
        ]
    c1 = corners(cx1, cy1, ca1, sa1, h1)
    c2 = corners(cx2, cy2, ca2, sa2, h2)
    # SAT for overlap: compute minimal penetration along each axis
    # For disjointness, we want to minimize max penetration.
    # Compute projection intervals
    best_pen = 1e18
    for (ax, ay) in axes:
        p1 = [x * ax + y * ay for x, y in c1]
        p2 = [x * ax + y * ay for x, y in c2]
        min1, max1 = min(p1), max(p1)
        min2, max2 = min(p2), max(p2)
        pen = min(max1 - min2, max2 - min1)
        if pen <= 0:
            return 0.0
        if pen < best_pen:
            best_pen = pen
    return best_pen


def _total_penalty(squares):
    p = 0.0
    n = len(squares)
    for i in range(n):
        for j in range(i + 1, n):
            p += _overlap_area(squares[i], squares[j]) ** 2
    return p


def _boundary_penalty(s):
    cx, cy, a, w = s
    if w <= 0:
        return 0.0
    h = w * 0.5
    ang = a * 2 * math.pi
    ca, sa = math.cos(ang), math.sin(ang)
    proj = h * (abs(ca) + abs(sa))
    pen = 0.0
    if cx - proj < -1e-9:
        pen += (proj - cx) ** 2
    if cx + proj > 1 + 1e-9:
        pen += (cx + proj - 1) ** 2
    if cy - proj < -1e-9:
        pen += (proj - cy) ** 2
    if cy + proj > 1 + 1e-9:
        pen += (cy + proj - 1) ** 2
    return pen


def _score(squares):
    return sum(s[3] for s in squares)


def _greedy_place(n, rng):
    # Try to place squares greedily: largest squares first.
    # Use a candidate set of positions/angles and pick the best one with no overlap.
    squares = []
    # Start with a few large squares using a coarse grid search.
    for _ in range(n):
        best = None
        best_side = -1.0
        # candidate positions
        for _try in range(400):
            cx = 0.05 + 0.9 * rng.random()
            cy = 0.05 + 0.9 * rng.random()
            ang = rng.choice([0.0, 0.25, 0.5, 0.75, rng.random()])
            # binary search max side
            lo, hi = 0.0, 1.0
            for _ in range(22):
                mid = (lo + hi) * 0.5
                cand = (cx, cy, ang, mid)
                ok = True
                for s in squares:
                    if _overlap_area(cand, s) > 1e-12:
                        ok = False
                        break
                # boundary check
                h = mid * 0.5
                a2 = ang * 2 * math.pi
                ca, sa = math.cos(a2), math.sin(a2)
                proj = h * (abs(ca) + abs(sa))
                if cx - proj < -1e-9 or cx + proj > 1 + 1e-9 or cy - proj < -1e-9 or cy + proj > 1 + 1e-9:
                    ok = False
                if ok:
                    lo = mid
                else:
                    hi = mid
            if lo > best_side:
                best_side = lo
                best = (cx, cy, ang, lo)
        if best is None:
            best = (0.5, 0.5, 0.0, 0.0)
        squares.append(best)
    return squares


def _optimize(squares, rng, time_limit=8.0):
    import time
    t0 = time.time()
    n = len(squares)
    squares = [list(s) for s in squares]
    # initial penalties
    def total_pen():
        p = 0.0
        for s in squares:
            p += _boundary_penalty(s)
        for i in range(n):
            for j in range(i + 1, n):
                p += _overlap_area(squares[i], squares[j]) ** 2
        return p

    cur_pen = total_pen()
    step = 0.05
    it = 0
    while time.time() - t0 < time_limit:
        it += 1
        i = rng.randrange(n)
        old = squares[i][:]
        # random perturbation
        dx = rng.uniform(-step, step)
        dy = rng.uniform(-step, step)
        da = rng.uniform(-step, step) * 0.5
        ds = rng.uniform(-step, step) * 0.3
        squares[i][0] += dx
        squares[i][1] += dy
        squares[i][2] += da
        squares[i][3] = max(0.0, squares[i][3] + ds)
        new_pen = total_pen()
        # accept if penalty decrease or small increase (simulated annealing style)
        if new_pen < cur_pen or rng.random() < 0.02:
            cur_pen = new_pen
        else:
            squares[i] = old
        if it % 200 == 0:
            step *= 0.995
    # final cleanup: shrink overlapping squares slightly
    for _ in range(5):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                ov = _overlap_area(squares[i], squares[j])
                if ov > 1e-9:
                    s_i = max(0.0, squares[i][3] - ov * 0.6)
                    s_j = max(0.0, squares[j][3] - ov * 0.6)
                    squares[i][3] = s_i
                    squares[j][3] = s_j
                    changed = True
        if not changed:
            break
    # clamp into bounds
    for i in range(n):
        cx, cy, a, w = squares[i]
        w = max(0.0, w)
        h = w * 0.5
        ang = a * 2 * math.pi
        ca, sa = math.cos(ang), math.sin(ang)
        proj = h * (abs(ca) + abs(sa))
        cx = min(max(cx, proj), 1.0 - proj)
        cy = min(max(cy, proj), 1.0 - proj)
        squares[i] = [cx, cy, a, w]
    return [tuple(s) for s in squares]


def solve(n):
    if n <= 0:
        return []
    rng = random.Random(12345 + n)
    # Try several greedy starts, pick best then optimize
    best = None
    best_score = -1
    for trial in range(3):
        sq = _greedy_place(n, rng)
        score = _score(sq)
        if score > best_score:
            best_score = score
            best = sq
    best = _optimize(best, rng, time_limit=10.0)
    # final score check: remove any residual overlaps by shrinking
    n2 = len(best)
    best = [list(s) for s in best]
    for _ in range(10):
        for i in range(n2):
            for j in range(i + 1, n2):
                ov = _overlap_area(best[i], best[j])
                if ov > 1e-10:
                    best[i][3] = max(0.0, best[i][3] - ov * 0.55)
                    best[j][3] = max(0.0, best[j][3] - ov * 0.55)
    # ensure boundary constraints by clamping and shrinking if needed
    for i in range(n2):
        cx, cy, a, w = best[i]
        if w <= 0:
            best[i] = [0.5, 0.5, 0.0, 0.0]
            continue
        h = w * 0.5
        ang = a * 2 * math.pi
        ca, sa = math.cos(ang), math.sin(ang)
        proj = h * (abs(ca) + abs(sa))
        if cx - proj < 0 or cx + proj > 1 or cy - proj < 0 or cy + proj > 1:
            # shrink until fits
            lo, hi = 0.0, w
            for _ in range(30):
                mid = (lo + hi) * 0.5
                h2 = mid * 0.5
                proj2 = h2 * (abs(ca) + abs(sa))
                if cx - proj2 >= -1e-12 and cx + proj2 <= 1 + 1e-12 and cy - proj2 >= -1e-12 and cy + proj2 <= 1 + 1e-12:
                    lo = mid
                else:
                    hi = mid
            w = lo
        best[i] = [min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), a % 1.0, max(0.0, w)]
    return [tuple(s) for s in best[:n]]
