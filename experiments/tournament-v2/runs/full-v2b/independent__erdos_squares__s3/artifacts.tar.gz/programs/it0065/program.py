import math
import random
from scipy.optimize import minimize

def _pack_rects(n):
    # simple recursive guillotine packing with axis-aligned squares maximizing sum
    # Represent free rectangles as (x, y, w, h). Always place square of side min(w,h) in largest.
    rects = [(0.0, 0.0, 1.0, 1.0)]
    squares = []
    for _ in range(n):
        # choose rect with largest min(w,h)
        idx = max(range(len(rects)), key=lambda i: min(rects[i][2], rects[i][3]))
        x, y, w, h = rects.pop(idx)
        s = min(w, h)
        # place at corner
        squares.append((x + s/2.0, y + s/2.0, 0.0, s))
        # split remaining area into two rects
        if w - s > 1e-12:
            rects.append((x + s, y, w - s, h))
        if h - s > 1e-12:
            rects.append((x, y + s, w, h - s))
    return squares

def _refine(squares, n, iters=50):
    # coordinate descent with random perturbations
    best = [list(s) for s in squares]
    best_val = sum(s[3] for s in best)
    for _ in range(iters):
        i = random.randrange(n)
        for _ in range(5):
            old = best[i][:]
            # perturb center or size
            r = random.random()
            if r < 0.4:
                best[i][0] += random.uniform(-0.05, 0.05)
            elif r < 0.8:
                best[i][1] += random.uniform(-0.05, 0.05)
            else:
                best[i][3] += random.uniform(-0.02, 0.02)
            # clamp
            s = max(0.0, min(1.0, best[i][3]))
            cx = max(s/2.0, min(1.0 - s/2.0, best[i][0]))
            cy = max(s/2.0, min(1.0 - s/2.0, best[i][1]))
            best[i] = [cx, cy, best[i][2], s]
            # check overlap with all others
            ok = True
            for j in range(n):
                if i == j: continue
                dx = abs(best[i][0] - best[j][0])
                dy = abs(best[i][1] - best[j][1])
                # axis aligned bounding box overlap check (conservative)
                if dx < (best[i][3] + best[j][3])/2.0 - 1e-9 and dy < (best[i][3] + best[j][3])/2.0 - 1e-9:
                    ok = False
                    break
            if not ok:
                best[i] = old
            else:
                val = sum(s[3] for s in best)
                if val > best_val:
                    best_val = val
                else:
                    best[i] = old
    return [tuple(s) for s in best]

def solve(n):
    if n == 0:
        return []
    # start with guillotine packing
    squares = _pack_rects(n)
    # refine
    squares = _refine(squares, n, iters=100)
    # ensure n squares
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    # ensure all in [0,1] and disjoint (repair)
    result = []
    for cx, cy, ang, s in squares[:n]:
        s = max(0.0, min(1.0, s))
        cx = max(s/2.0, min(1.0 - s/2.0, cx))
        cy = max(s/2.0, min(1.0 - s/2.0, cy))
        result.append((cx, cy, 0.0, s))
    # simple overlap removal: shrink if overlapping
    for _ in range(20):
        changed = False
        for i in range(n):
            for j in range(i+1, n):
                xi, yi, _, si = result[i]
                xj, yj, _, sj = result[j]
                dx = abs(xi - xj)
                dy = abs(yi - yj)
                if dx < (si+sj)/2.0 - 1e-9 and dy < (si+sj)/2.0 - 1e-9:
                    # shrink smaller
                    if si < sj:
                        ns = max(0.0, 2.0*dx - sj) if dx > 0 else 0.0
                        ns = min(ns, 2.0*dy - sj) if dy > 0 else 0.0
                        ns = max(0.0, min(si, ns))
                        result[i] = (xi, yi, 0.0, ns)
                    else:
                        ns = max(0.0, 2.0*dx - si) if dx > 0 else 0.0
                        ns = min(ns, 2.0*dy - si) if dy > 0 else 0.0
                        ns = max(0.0, min(sj, ns))
                        result[j] = (xj, yj, 0.0, ns)
                    changed = True
        if not changed:
            break
    return result
