import math
import numpy as np
from scipy.optimize import minimize


def _grid(n):
    k = math.isqrt(n)
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
          for i in range(k) for j in range(k)]
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n]


def _eval_layout(x, n):
    """x = [h, w, s, r, t, ang]  ->  list of squares (centre_x, centre_y, angle, side)"""
    # Not used directly; scoring done by objective
    return x


def _make_squares(params, n):
    """params: [h, w, s, r, t, ang]
    h: height of bottom band (fraction of 1)
    w: side of bottom squares
    s: side of top squares
    r: number of bottom squares per row (integer, rounded)
    t: number of rows in top region
    ang: rotation angle of top squares (fraction of turn)
    Returns list of (cx, cy, angle, side).
    """
    h, w, s, r, t, ang = params
    r = max(1, int(round(r)))
    t = max(0, int(round(t)))
    rows_bottom = max(1, int(round(1.0 / h))) if h > 1e-9 else 1
    # Actually derive rows from h: bottom band packed with rows of height w
    rows_bottom = max(1, int(round(h / max(w, 1e-9))))
    if rows_bottom < 1:
        rows_bottom = 1
    # We'll reconstruct bottom grid: r columns x rows_bottom rows, square side w
    cols = r
    # Clamp to fit
    if cols * w > 1.0 + 1e-9:
        w = 1.0 / cols
    if rows_bottom * w > h + 1e-9:
        w = h / rows_bottom

    squares = []
    # BOTTOM: grid of r x rows_bottom squares of size w
    for j in range(rows_bottom):
        for i in range(cols):
            cx = (i + 0.5) * (1.0 / cols)
            cy = (j + 0.5) * w
            if cy + w / 2 > h + 1e-9:
                continue
            squares.append((cx, cy, 0.0, w))

    # TOP: t rows of rotated squares of side s, arranged in a grid
    if t > 0 and s > 1e-9:
        # Bounding box of rotated square
        c = abs(math.cos(2 * math.pi * ang))
        si = abs(math.sin(2 * math.pi * ang))
        bw = s * (c + si)  # horizontal extent
        bh = s * (c + si)  # vertical extent (same for square rotation)
        # available region above h
        top_h = 1.0 - h
        if t * bh > top_h + 1e-9:
            # shrink s
            s = top_h / (t * (c + si)) if (c + si) > 1e-9 else top_h / t
            bw = s * (c + si)
            bh = s * (c + si)
        # Number of columns that fit
        ncol = max(1, int(1.0 / bw + 1e-9))
        # if fewer than needed, reduce s further? keep simple
        for j in range(t):
            cy = h + (j + 0.5) * bh
            # check fit
            if cy + bh / 2 > 1.0 + 1e-9:
                break
            # spread ncol squares across width
            for i in range(ncol):
                cx = (i + 0.5) * (1.0 / ncol)
                squares.append((cx, cy, ang, s))

    # Pad or truncate to n
    if len(squares) >= n:
        squares = squares[:n]
    else:
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares


def _total_side(params, n):
    sq = _make_squares(params, n)
    return -sum(s[3] for s in sq)  # minimize negative


def _refine(squares, n, iters=200):
    """Light local refinement: adjust sizes and positions slightly to improve sum,
    keeping validity by checking overlaps."""
    # We'll do a simple coordinate descent on all squares respecting non-overlap.
    # Since checking overlap is expensive, we do a conservative approach:
    # Try increasing each square's size slightly if no overlap, and adjust positions.
    def bb(sq):
        cx, cy, a, s = sq
        c = abs(math.cos(2 * math.pi * a))
        si = abs(math.sin(2 * math.pi * a))
        hw = s * (c + si) / 2
        return cx - hw, cx + hw, cy - hw, cy + hw

    def overlap(s1, s2):
        # SAT for convex polygons (squares)
        def corners(cx, cy, a, s):
            ca = math.cos(2 * math.pi * a)
            sa = math.sin(2 * math.pi * a)
            h = s / 2
            pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
            return [(cx + px * ca - py * sa, cy + px * sa + py * ca) for px, py in pts]

        def sat(poly1, poly2):
            for poly in (poly1, poly2):
                for i in range(len(poly)):
                    p1 = poly[i]
                    p2 = poly[(i + 1) % len(poly)]
                    edge = (p2[0] - p1[0], p2[1] - p1[1])
                    axis = (-edge[1], edge[0])
                    length = math.hypot(*axis)
                    if length < 1e-12:
                        continue
                    axis = (axis[0] / length, axis[1] / length)
                    min1, max1 = float('inf'), float('-inf')
                    for p in poly1:
                        d = p[0] * axis[0] + p[1] * axis[1]
                        min1 = min(min1, d); max1 = max(max1, d)
                    min2, max2 = float('inf'), float('-inf')
                    for p in poly2:
                        d = p[0] * axis[0] + p[1] * axis[1]
                        min2 = min(min2, d); max2 = max(max2, d)
                    if max1 < min2 - 1e-9 or max2 < min1 - 1e-9:
                        return False
            return True

        c1 = corners(*s1)
        c2 = corners(*s2)
        return sat(c1, c2)

    sq = [list(s) for s in squares]
    for _ in range(20):
        improved = False
        for i in range(n):
            if sq[i][3] < 1e-9:
                continue
            # try increase size
            best = sq[i][3]
            best_params = tuple(sq[i])
            for ds in [0.005, 0.002, 0.001, -0.005, -0.002]:
                cand = list(sq[i])
                cand[3] = max(0.0, cand[3] + ds)
                ok = True
                for j in range(n):
                    if i == j:
                        continue
                    if overlap(cand, sq[j]):
                        ok = False
                        break
                if ok and (ds > 0 and cand[3] > best or ds < 0 and False):
                    if cand[3] > best:
                        best = cand[3]
                        best_params = tuple(cand)
            if best_params[3] != sq[i][3]:
                sq[i] = list(best_params)
                improved = True
        if not improved:
            break
    # Convert back
    return [(s[0], s[1], s[2], s[3]) for s in sq]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # For general n, use optimization with multiple restarts
    best_sq = _grid(n)
    best_val = sum(s[3] for s in best_sq)

    # Try a few parameterized layouts
    seeds = [
        # h, w, s, r, t, ang
        (0.4, 0.4, 0.3, 2, 2, 0.0),
        (0.5, 0.3, 0.3, 3, 1, 0.0),
        (0.3, 0.3, 0.3, 3, 2, 0.0),
        (0.5, 0.5, 0.25, 2, 1, 0.25),
        (0.4, 0.4, 0.25, 2, 1, 0.25),
        (0.6, 0.33, 0.2, 3, 1, 0.125),
        (0.4, 0.25, 0.25, 4, 1, 0.25),
        (0.3, 0.33, 0.2, 3, 2, 0.125),
    ]

    def obj(x):
        # Ensure valid params
        h, w, s, r, t, ang = x
        if not (0.05 < h < 0.95):
            return 1e6
        if not (0.01 < w < 0.99):
            return 1e6
        if not (0.0 <= s < 0.99):
            return 1e6
        if not (1 <= r <= 20):
            return 1e6
        if not (0 <= t <= 10):
            return 1e6
        if not (-0.25 <= ang <= 0.75):
            return 1e6
        sq = _make_squares(x, n)
        total = sum(s[3] for s in sq)
        # penalty if less than n non-degenerate squares? (padding allowed, but punish zeros)
        num_nonzero = sum(1 for s in sq if s[3] > 1e-6)
        penalty = (n - num_nonzero) * 0.5
        return -total + penalty

    bounds = [(0.05, 0.95), (0.01, 0.99), (0.0, 0.99), (1, 20), (0, 10), (-0.25, 0.75)]

    for seed in seeds:
        try:
            res = minimize(obj, seed, method='Nelder-Mead',
                           options={'maxiter': 300, 'xatol': 1e-4, 'fatol': 1e-4})
            if res.fun < -best_val:
                sq = _make_squares(res.x, n)
                val = sum(s[3] for s in sq)
                if val > best_val:
                    best_val = val
                    best_sq = sq
        except Exception:
            pass

    # Try random restarts around best
    for _ in range(5):
        seed = [
            np.random.uniform(0.1, 0.8),
            np.random.uniform(0.1, 0.8),
            np.random.uniform(0.05, 0.8),
            np.random.randint(1, 6),
            np.random.randint(0, 4),
            np.random.choice([0.0, 0.125, 0.25]),
        ]
        try:
            res = minimize(obj, seed, method='Nelder-Mead',
                           options={'maxiter': 200, 'xatol': 1e-4, 'fatol': 1e-4})
            if res.fun < -best_val:
                sq = _make_squares(res.x, n)
                val = sum(s[3] for s in sq)
                if val > best_val:
                    best_val = val
                    best_sq = sq
        except Exception:
            pass

    # Ensure exactly n squares
    if len(best_sq) > n:
        best_sq = best_sq[:n]
    while len(best_sq) < n:
        best_sq.append((0.5, 0.5, 0.0, 0.0))

    # Final safety: remove overlaps by shrinking (conservative)
    # (We trust construction, but clip to unit square)
    result = []
    for sx, sy, a, s in best_sq:
        s = max(0.0, min(1.0, s))
        # Keep center within [0,1]
        sx = max(0.0, min(1.0, sx))
        sy = max(0.0, min(1.0, sy))
        # If square would stick out, shrink
        c = abs(math.cos(2 * math.pi * a))
        si = abs(math.sin(2 * math.pi * a))
        half_extent = s * (c + si) / 2
        # move inside
        sx = max(half_extent, min(1.0 - half_extent, sx))
        sy = max(half_extent, min(1.0 - half_extent, sy))
        # shrink if needed
        if half_extent > 0.5:
            s = 1.0 / (c + si) if (c + si) > 1e-9 else 1.0
            half_extent = s * (c + si) / 2
        result.append((sx, sy, a % 1.0, s))

    return result


if __name__ == "__main__":
    for n in range(1, 16):
        sq = solve(n)
        total = sum(s[3] for s in sq)
        print(n, total)
