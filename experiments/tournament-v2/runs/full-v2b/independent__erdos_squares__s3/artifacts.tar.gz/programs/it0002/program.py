import math
import random
import time

# ----------------------------------------------------------------------
# geometric helpers (single precision is enough)
# ----------------------------------------------------------------------

def _corners(cx, cy, ang, s):
    """Return the 4 corners of a square."""
    h = 0.5 * s
    c = math.cos(ang * 2.0 * math.pi)
    sn = math.sin(ang * 2.0 * math.pi)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * sn, cy + dx * sn + dy * c))
    return pts

def _poly(cx, cy, ang, s):
    """Return the convex polygon (list of vertices) of a square."""
    return _corners(cx, cy, ang, s)

def _sep_axis(pts, ax, ay):
    mn = 1e18
    mx = -1e18
    for x, y in pts:
        v = x * ax + y * ay
        if v < mn: mn = v
        if v > mx: mx = v
    return mn, mx

def _overlap_two(p1, p2):
    """SAT overlap test for two convex polygons (squares)."""
    for poly in (p1, p2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ax = -(y2 - y1)
            ay = x2 - x1
            l = math.hypot(ax, ay)
            if l < 1e-15:
                continue
            ax /= l
            ay /= l
            a1, b1 = _sep_axis(p1, ax, ay)
            a2, b2 = _sep_axis(p2, ax, ay)
            if b1 <= a2 + 1e-12 or b2 <= a1 + 1e-12:
                return False
    return True

def _inside_unit(p):
    """Check all vertices lie inside the unit square (with tiny tolerance)."""
    for x, y in p:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True

def _valid(sqs):
    """Check all squares are inside the unit square and pairwise non-overlapping."""
    polys = []
    for cx, cy, ang, s in sqs:
        if s < -1e-12:
            return False
        if s <= 1e-14:
            polys.append(None)
            continue
        p = _poly(cx, cy, ang, s)
        if not _inside_unit(p):
            return False
        polys.append(p)
    for i in range(len(polys)):
        pi = polys[i]
        if pi is None:
            continue
        for j in range(i + 1, len(polys)):
            pj = polys[j]
            if pj is None:
                continue
            if _overlap_two(pi, pj):
                return False
    return True

# ----------------------------------------------------------------------
# constructive layouts
# ----------------------------------------------------------------------

def _grid_layout(n):
    """Largest integer grid k x k that fits, plus zeros."""
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    sqs = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
           for i in range(k) for j in range(k)]
    sqs += [(0.5, 0.5, 0.0, 0.0)] * (n - k * k)
    return sqs

def _extra_grid_layout(n):
    """(k+1) x k grid, filling only n cells."""
    best = None
    best_sum = -1.0
    for rows in range(1, int(math.sqrt(n)) + 3):
        cols = (n + rows - 1) // rows
        if cols < 1:
            continue
        s = min(1.0 / rows, 1.0 / cols)
        # try to fit n squares of side s in a rows x cols array
        cells = []
        for r in range(rows):
            for c in range(cols):
                cells.append((r, c))
        # take n cells: prefer a compact block
        cells.sort(key=lambda rc: (rc[0] + rc[1], rc[0], rc[1]))
        cells = cells[:n]
        if len(cells) < n:
            continue
        tot = n * s
        # try all orientations by swapping rows/cols
        for (R, C) in ((rows, cols), (cols, rows)):
            ss = min(1.0 / R, 1.0 / C)
            sqs = []
            for r, c in cells:
                if r >= R or c >= C:
                    continue
                sqs.append(((c + 0.5) * ss, (r + 0.5) * ss, 0.0, ss))
            if len(sqs) == n and _valid(sqs):
                if n * ss > best_sum:
                    best_sum = n * ss
                    best = sqs
    return best

def _big_plus_rest(n):
    """One big square plus recursive fill of the remaining L-shaped region."""
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0)] if n == 1 else []
    best = None
    best_sum = -1.0
    # try big square size in a few fractions; remaining squares in the L
    for frac in [0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9]:
        s = frac
        # place big square in a corner
        place = [
            (s * 0.5, s * 0.5, 0.0, s),          # bottom-left
            (1.0 - s * 0.5, s * 0.5, 0.0, s),    # bottom-right
            (s * 0.5, 1.0 - s * 0.5, 0.0, s),    # top-left
            (1.0 - s * 0.5, 1.0 - s * 0.5, 0.0, s),  # top-right
        ]
        rem = n - 1
        if rem <= 0:
            continue
        # fill remaining L with grid-ish pattern of side t
        # L region: unit square minus the big square
        # approximate with a grid of side t in the complement
        # try t values such that some fit
        for t in [s * 0.5, s * 0.4, s * 0.3333, s * 0.25, 1.0 / (math.isqrt(rem) + 1)]:
            if t <= 1e-9:
                continue
            # candidate centres in the L
            cand = []
            k = int(1.0 / t) + 2
            for i in range(k):
                for j in range(k):
                    cx = (i + 0.5) * t
                    cy = (j + 0.5) * t
                    if cx - t * 0.5 < 1e-9 and cy - t * 0.5 < 1e-9 and \
                       cx + t * 0.5 < 1.0 + 1e-9 and cy + t * 0.5 < 1.0 + 1e-9:
                        # check not overlapping big square
                        ok = True
                        for bx, by, ba, bs in place:
                            # quick AABB overlap check
                            if abs(cx - bx) < (t + bs) * 0.5 - 1e-9 and abs(cy - by) < (t + bs) * 0.5 - 1e-9:
                                ok = False
                                break
                        if ok:
                            cand.append((cx, cy))
            if len(cand) < rem:
                continue
            # pick rem candidates: prefer those far from big square
            cand.sort(key=lambda c: -(abs(c[0] - place[0][0]) + abs(c[1] - place[0][1])))
            for combo_idx in range(min(len(cand), 200)):
                # choose a subset: take first rem after rotation
                subset = cand[combo_idx:combo_idx + rem]
                if len(subset) < rem:
                    break
                sqs = list(place) + [(cx, cy, 0.0, t) for cx, cy in subset]
                if _valid(sqs):
                    tot = s + rem * t
                    if tot > best_sum:
                        best_sum = tot
                        best = sqs
    return best

def _rotated_variants(n):
    """Grid with all squares slightly rotated (no overlap) - can't improve area,
       but try rotated big plus rest."""
    best = None
    best_sum = -1.0
    for base in (_big_plus_rest(n), _extra_grid_layout(n), _grid_layout(n)):
        if base is None:
            continue
        # try global small rotation
        for ang in [0.0, 0.125, 0.25, 0.375, 0.0625, 0.1875, 0.3125]:
            if ang == 0.0:
                cand = list(base)
            else:
                # rotate each square about its own centre: may overlap
                cand = [(cx, cy, a + ang, s) for (cx, cy, a, s) in base]
            if _valid(cand):
                tot = sum(s for _, _, _, s in cand)
                if tot > best_sum:
                    best_sum = tot
                    best = cand
    return best

# ----------------------------------------------------------------------
# local optimisation
# ----------------------------------------------------------------------

def _local_opt(sqs, seconds=5.0):
    """Perturb centres and sides, keep improvements, never create overlaps."""
    t0 = time.time()
    best = list(sqs)
    best_sum = sum(s for _, _, _, s in best)
    n = len(best)
    it = 0
    T = 0.02
    while time.time() - t0 < seconds:
        it += 1
        # pick a random square
        i = random.randrange(n)
        cx, cy, ang, s = best[i]
        # propose a new position/size
        dcx = random.gauss(0, T)
        dcy = random.gauss(0, T)
        ds = random.gauss(0, T)
        ncx = min(1.0, max(0.0, cx + dcx))
        ncy = min(1.0, max(0.0, cy + dcy))
        ns = min(1.0, max(0.0, s + ds))
        # keep inside unit roughly
        if ncx - ns * 0.5 < -1e-9 or ncx + ns * 0.5 > 1.0 + 1e-9:
            # clamp
            m = min(ncx, 1.0 - ncx) * 2.0
            ns = min(ns, m)
            if ns < 0.0:
                ns = 0.0
        if ncy - ns * 0.5 < -1e-9 or ncy + ns * 0.5 > 1.0 + 1e-9:
            m = min(ncy, 1.0 - ncy) * 2.0
            ns = min(ns, m)
            if ns < 0.0:
                ns = 0.0
        cand = list(best)
        cand[i] = (ncx, ncy, ang, ns)
        if _valid(cand):
            new_sum = sum(s for _, _, _, s in cand)
            if new_sum >= best_sum - 1e-12:
                best = cand
                best_sum = new_sum
        # occasional global shuffle for zero squares to give them size
        if it % 50 == 0:
            for i in range(n):
                cx, cy, ang, s = best[i]
                if s < 1e-9:
                    # try to give it a tiny size in a random place
                    for _ in range(5):
                        ncx = random.random()
                        ncy = random.random()
                        ns = random.uniform(0.0, 0.02)
                        cand = list(best)
                        cand[i] = (ncx, ncy, ang, ns)
                        if _valid(cand):
                            if sum(sq[3] for sq in cand) >= best_sum - 1e-12:
                                best = cand
                                best_sum = sum(sq[3] for sq in cand)
                            break
        # cool down
        if it % 200 == 0:
            T = max(0.001, T * 0.9)
    return best

def _trim_zeros(sqs):
    return [t for t in sqs if t[3] > 1e-12]

def _pad(sqs, n):
    sqs = list(sqs)
    while len(sqs) < n:
        sqs.append((0.5, 0.5, 0.0, 0.0))
    return sqs[:n]

# ----------------------------------------------------------------------
# main solver
# ----------------------------------------------------------------------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # small n: exact-ish constructions
    best = None
    best_sum = -1.0

    # candidate generators
    candidates = []
    candidates.append(_grid_layout(n))
    eg = _extra_grid_layout(n)
    if eg: candidates.append(eg)
    bp = _big_plus_rest(n)
    if bp: candidates.append(bp)
    rv = _rotated_variants(n)
    if rv: candidates.append(rv)

    for cand in candidates:
        if cand is None:
            continue
        cand = _pad(list(cand), n)
        if _valid(cand):
            tot = sum(s for _, _, _, s in cand)
            if tot > best_sum:
                best_sum = tot
                best = cand

    if best is None:
        best = _grid_layout(n)
        best_sum = sum(s for _, _, _, s in best)

    # refine with local optimisation, time limited
    # allocate about 4 seconds to local search, scaled by n
    budget = 5.0 if n <= 20 else 4.0
    refined = _local_opt(best, seconds=budget)
    if refined and _valid(refined):
        tot = sum(s for _, _, _, s in refined)
        if tot > best_sum:
            best = refined
            best_sum = tot

    # final safety: ensure valid, pad zeros
    best = _pad(best, n)
    # check validity; if fails, fall back to grid
    if not _valid(best):
        best = _grid_layout(n)
        best = _pad(best, n)

    # ensure all numbers in [0,1]
    out = []
    for cx, cy, ang, s in best:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = min(1.0, max(0.0, s))
        out.append((cx, cy, ang, s))
    return out[:n]
