import math
import random

def _interiors_overlap(c1, a1, s1, c2, a2, s2):
    """Check if two squares with centres c, angle a (fraction of turn), side s overlap interiors."""
    if s1 <= 0 or s2 <= 0:
        return False
    # Relative vector from c1 to c2
    dx = c2[0] - c1[0]
    dy = c2[1] - c1[1]
    # Rotate c2 into c1's frame
    a = a1 * 2 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    # rotate by -a: (dx*ca + dy*sa, -dx*sa + dy*ca)
    rx = dx * ca + dy * sa
    ry = -dx * sa + dy * ca
    # half extents
    h1 = s1 * 0.5
    h2 = s2 * 0.5
    # In c1 frame, square1 axis-aligned. Square2 axes are rotated by (a2-a1)
    b = (a2 - a1) * 2 * math.pi
    cb, sb = math.cos(b), math.sin(b)
    # SAT for two rectangles: axes of square1 (x,y) and axes of square2 (u,v)
    # Project both onto x-axis
    # half-width of square2 in x: h2*(|cb| + |sb|)
    p2x = h2 * (abs(cb) + abs(sb))
    if abs(rx) >= h1 + p2x:
        return False
    p2y = h2 * (abs(sb) + abs(cb))
    if abs(ry) >= h1 + p2y:
        return False
    # Project onto square2 axes: need square1 extent in those directions
    # square1 extent along u: h1*(|cb| + |sb|)
    ux = h1 * (abs(cb) + abs(sb))
    if abs(rx * cb + ry * sb) >= ux + h2:
        return False
    vx = h1 * (abs(cb) + abs(sb))
    if abs(-rx * sb + ry * cb) >= vx + h2:
        return False
    return True

def _inside(c, s):
    """Check square entirely inside [0,1]^2 (allowing boundary touch)."""
    if s <= 0:
        return True
    # For rotated square, max |x| extent is s/2*(|cos|+|sin|)
    # but angle isn't stored here; assume worst case to be safe: half diagonal
    r = s * 0.5 * math.sqrt(2)
    return c[0] - r >= -1e-12 and c[0] + r <= 1 + 1e-12 and c[1] - r >= -1e-12 and c[1] + r <= 1 + 1e-12

def _inside_rot(c, a, s):
    if s <= 0:
        return True
    r = s * 0.5 * (abs(math.cos(a * 2 * math.pi)) + abs(math.sin(a * 2 * math.pi)))
    return c[0] - r >= -1e-12 and c[0] + r <= 1 + 1e-12 and c[1] - r >= -1e-12 and c[1] + r <= 1 + 1e-12

def _score(squares):
    total = 0.0
    for c, a, s in squares:
        if s > 0:
            total += s
    penalty = 0.0
    m = len(squares)
    for i in range(m):
        ci, ai, si = squares[i]
        if si <= 0:
            continue
        if not _inside_rot(ci, ai, si):
            penalty += 100.0 * si
        for j in range(i+1, m):
            cj, aj, sj = squares[j]
            if sj <= 0:
                continue
            if _interiors_overlap(ci, ai, si, cj, aj, sj):
                penalty += 50.0 * min(si, sj) + 1.0
    return total - penalty

def _grid_initial(n):
    k = int(math.sqrt(n))
    if k < 1:
        k = 1
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) >= n:
                break
            squares.append(((i+0.5)*side, (j+0.5)*side, 0.0, side))
        if len(squares) >= n:
            break
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares

def _nested_initial(n):
    # Use a grid, but try to give larger squares to edge positions
    return _grid_initial(n)

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # For small n do optimisation
    if n <= 12:
        squares = _grid_initial(n)
    else:
        squares = _nested_initial(n)
    # Convert to mutable list of [cx, cy, angle, side]
    state = [[c[0], c[1], c[2], c[3]] for c in squares]
    # Ensure sizes positive where possible
    # Initial sizes: set them equal to grid side
    k = int(math.sqrt(n))
    if k < 1: k = 1
    base_side = 1.0 / k
    for i in range(n):
        if state[i][3] <= 0:
            state[i][3] = base_side * 0.5

    # Optimisation via random local search
    # We'll do a simple hill climbing with decreasing step sizes
    def eval_state(st):
        lst = [((s[0], s[1]), s[2], s[3]) for s in st]
        return _score(lst)

    current_score = eval_state(state)
    best_state = [row[:] for row in state]
    best_score = current_score

    # Determine scale-based step
    # For small n, we can try larger perturbations
    iter_count = 0
    max_iters = 20000 if n <= 12 else (5000 if n <= 30 else 2000)
    temp = 0.1
    # For large n, we might not have time; reduce iterations
    import time
    start_time = time.time()
    TL = 55.0

    while iter_count < max_iters:
        iter_count += 1
        if iter_count % 500 == 0 and time.time() - start_time > TL:
            break
        # Pick a random square
        idx = random.randrange(n)
        old = state[idx][:]
        # Perturb: choose type of move
        move = random.random()
        if move < 0.35:
            # Change size
            delta = random.gauss(0, 0.05) * (1.0 / math.sqrt(n))
            state[idx][3] = max(0.0, min(1.0, state[idx][3] + delta))
        elif move < 0.65:
            # Change position
            delta = random.gauss(0, 0.05) * (1.0 / math.sqrt(n))
            state[idx][0] = max(0.0, min(1.0, state[idx][0] + delta))
            delta = random.gauss(0, 0.05) * (1.0 / math.sqrt(n))
            state[idx][1] = max(0.0, min(1.0, state[idx][1] + delta))
        elif move < 0.8:
            # Change angle (small)
            delta = random.gauss(0, 0.05)
            state[idx][2] = (state[idx][2] + delta) % 1.0
        elif move < 0.95:
            # Try to increase size
            state[idx][3] = min(1.0, state[idx][3] + 0.01 * (1.0 / math.sqrt(n)))
        else:
            # Random full move
            state[idx][0] = random.random()
            state[idx][1] = random.random()
            state[idx][2] = random.random()
            state[idx][3] = random.random() * 0.5

        new_score = eval_state(state)
        if new_score >= current_score:
            current_score = new_score
            if new_score > best_score:
                best_score = new_score
                best_state = [row[:] for row in state]
        else:
            # Accept worse with small probability (simulated annealing)
            if temp > 0 and random.random() < math.exp((new_score - current_score) / temp):
                current_score = new_score
            else:
                state[idx] = old[:]
        # Decrease temperature slowly
        if iter_count % 100 == 0:
            temp *= 0.95
            if temp < 1e-6:
                temp = 1e-6

    # Final: try to repair overlaps and maximize sizes greedily
    # Use best_state
    result = []
    # Convert to list of (centre, angle, side)
    for s in best_state:
        result.append((s[0], s[1], s[2], s[3]))

    # Post-process: for each square, try to grow it if possible
    # Build list of tuples (cx, cy, angle, side)
    sq = result[:]
    # Ensure all inside and non-overlapping; if not, reduce sizes
    # Simple repair: set any square that violates boundary to size 0? No, reduce
    # Check and fix
    changed = True
    rounds = 0
    while changed and rounds < 50:
        changed = False
        rounds += 1
        # Check each square against others and boundaries
        for i in range(n):
            c_i, a_i, s_i = sq[i]
            if s_i <= 0:
                continue
            # boundary check
            if not _inside_rot((c_i, c_i), a_i, s_i):
                # reduce size
                sq[i] = (c_i, c_i, a_i, s_i * 0.9)
                changed = True
                continue
            for j in range(i+1, n):
                c_j, a_j, s_j = sq[j]
                if s_j <= 0:
                    continue
                if _interiors_overlap((c_i, c_i), a_i, s_i, (c_j, c_j), a_j, s_j):
                    # reduce smaller one
                    if s_i <= s_j:
                        sq[i] = (c_i, c_i, a_i, s_i * 0.95)
                    else:
                        sq[j] = (c_j, c_j, a_j, s_j * 0.95)
                    changed = True
    # Try to grow sizes greedily
    for _ in range(3):
        for i in range(n):
            c_i, a_i, s_i = sq[i]
            if s_i <= 0:
                continue
            # try increase
            new_s = min(1.0, s_i * 1.02 + 0.001)
            new_sq = (c_i, c_i, a_i, new_s)
            ok = _inside_rot((c_i, c_i), a_i, new_s)
            if ok:
                for j in range(n):
                    if j == i:
                        continue
                    c_j, a_j, s_j = sq[j]
                    if s_j <= 0:
                        continue
                    if _interiors_overlap((c_i, c_i), a_i, new_s, (c_j, c_j), a_j, s_j):
                        ok = False
                        break
            if ok:
                sq[i] = new_sq
    # Final cleanup: ensure all sides are >= 0
    final = []
    for (cx, cy, a, s) in sq:
        final.append((cx, cy, a, max(0.0, s)))
    return final
