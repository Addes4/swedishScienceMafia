import math
import random


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345 + n)

    def mk(cx, cy, ang, s):
        return [cx, cy, ang, s]

    def clamp_square(q):
        cx, cy, ang, s = q
        s = max(0.0, min(1.0, s))
        if s == 0.0:
            return [0.5, 0.5, 0.0, 0.0]
        r = s * (abs(math.cos(2 * math.pi * ang)) + abs(math.sin(2 * math.pi * ang))) * 0.5
        cx = max(r, min(1.0 - r, cx))
        cy = max(r, min(1.0 - r, cy))
        return [cx, cy, ang % 1.0, s]

    def corners(cx, cy, ang, s):
        a = 2 * math.pi * ang
        c, si = math.cos(a), math.sin(a)
        h = s * 0.5
        return [
            (cx + (-h) * c - (-h) * si, cy + (-h) * si + (-h) * c),
            (cx + (h) * c - (-h) * si, cy + (h) * si + (-h) * c),
            (cx + (h) * c - (h) * si, cy + (h) * si + (h) * c),
            (cx + (-h) * c - (h) * si, cy + (-h) * si + (h) * c),
        ]

    def proj_axes(ang):
        a = 2 * math.pi * ang
        c, si = math.cos(a), math.sin(a)
        return [(c, si), (-si, c)]

    def separated(p, q):
        if p[3] <= 1e-14 or q[3] <= 1e-14:
            return True
        ax = proj_axes(p[2])
        bx = proj_axes(q[2])
        axes = ax + bx
        pc = corners(*p)
        qc = corners(*q)
        for ux, uy in axes:
            pmin = min(px * ux + py * uy for px, py in pc)
            pmax = max(px * ux + py * uy for px, py in pc)
            qmin = min(px * ux + py * py for px, py in qc) if False else min(px * ux + py * uy for px, py in qc)
            qmax = max(px * ux + py * uy for px, py in qc)
            if pmax <= qmin + 1e-12 or qmax <= pmin + 1e-12:
                return True
        return False

    def total(sol):
        return sum(max(0.0, x[3]) for x in sol)

    def feasible(sol):
        m = len(sol)
        for i in range(m):
            q = sol[i]
            if q[3] <= 1e-14:
                continue
            r = q[3] * (abs(math.cos(2 * math.pi * q[2])) + abs(math.sin(2 * math.pi * q[2]))) * 0.5
            if q[0] < r - 1e-11 or q[0] > 1.0 - r + 1e-11 or q[1] < r - 1e-11 or q[1] > 1.0 - r + 1e-11:
                return False
            for j in range(i + 1, m):
                if not separated(q, sol[j]):
                    return False
        return True

    def repair(sol):
        sol = [clamp_square(list(x)) for x in sol]
        for _ in range(120):
            bad = None
            m = len(sol)
            for i in range(m):
                if sol[i][3] <= 1e-14:
                    continue
                for j in range(i + 1, m):
                    if sol[j][3] <= 1e-14:
                        continue
                    if not separated(sol[i], sol[j]):
                        bad = (i, j)
                        break
                if bad:
                    break
            if bad is None:
                return sol
            i, j = bad
            si, sj = sol[i][3], sol[j][3]
            if si >= sj:
                sol[i][3] *= 0.97
                sol[i] = clamp_square(sol[i])
            else:
                sol[j][3] *= 0.97
                sol[j] = clamp_square(sol[j])
        for i in range(len(sol)):
            sol[i][3] = 0.0
            sol[i][:3] = [0.5, 0.5, 0.0]
        return sol

    def local_search(sol, rounds=70):
        sol = repair(sol)
        if not feasible(sol):
            return sol
        best = [list(x) for x in sol]
        bs = total(best)
        m = len(best)
        scale = 0.09
        for rd in range(rounds):
            improved = False
            order = list(range(m))
            random.shuffle(order)
            for idx in order:
                cur = list(best[idx])
                cs = cur[3]
                if cs <= 0:
                    continue
                cands = []

                for d in (scale, scale * 0.5, scale * 0.2):
                    cands.append(list(cur))
                    cands[-1][3] = min(1.0, cs + d)
                    for dx, dy in ((d, 0), (-d, 0), (0, d), (0, -d), (d, d), (-d, -d), (d, -d), (-d, d)):
                        q = list(cur)
                        q[0] += dx
                        q[1] += dy
                        cands.append(q)
                    for da in (d, -d):
                        q = list(cur)
                        q[2] = (q[2] + da) % 1.0
                        cands.append(q)
                for q in cands:
                    q = clamp_square(q)
                    if q[3] <= 1e-14:
                        continue
                    old = best[idx]
                    best[idx] = q
                    ok = True
                    for k in range(m):
                        if k == idx or best[k][3] <= 1e-14:
                            continue
                        if not separated(best[k], q):
                            ok = False
                            break
                    if ok:
                        ts = total(best)
                        if ts > bs + 1e-12:
                            bs = ts
                            improved = True
                            cur = list(q)
                            break
                    best[idx] = old
            if not improved:
                scale *= 0.55
                if scale < 1e-4:
                    break
        return best

    # --- constructors ---
    def grid(k, sx=1.0, sy=1.0, ox=0.0, oy=0.0):
        s = min(sx / k, sy / k)
        out = []
        for i in range(k):
            for j in range(k):
                out.append(mk(ox + (i + 0.5) * s, oy + (j + 0.5) * s, 0.0, s))
        return out

    def grid_rect(r, c):
        s = min(1.0 / r, 1.0 / c)
        out = []
        for i in range(r):
            for j in range(c):
                out.append(mk((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        return out

    def rowpack(nn):
        out = []
        y = 0.0
        rem = nn
        while rem > 0:
            r = 1
            while r * r <= rem:
                r += 1
            r -= 1
            if r <= 0:
                r = 1
            r = min(r, rem)
            s = 1.0 / r
            h = s
            if y + h > 1.0 + 1e-15:
                h = 1.0 - y
                if h <= 1e-12:
                    break
                s = min(s, h)
            for i in range(r):
                out.append(mk((i + 0.5) * s, y + 0.5 * s, 0.0, s))
            y += s
            rem -= r
            if len(out) >= nn:
                break
        return out

    def dyadic(nn, depth=0, x0=0.0, y0=0.0, w=1.0, h=1.0):
        if nn <= 0:
            return []
        if nn == 1:
            s = min(w, h)
            return [mk(x0 + w / 2.0, y0 + h / 2.0, 0.0, s)]
        if w >= h:
            w1 = w * 0.5
            k1 = nn // 2
            left = dyadic(k1, depth + 1, x0, y0, w1, h)
            right = dyadic(nn - k1, depth + 1, x0 + w1, y0, w - w1, h)
        else:
            h1 = h * 0.5
            k1 = nn // 2
            left = dyadic(k1, depth + 1, x0, y0, w, h1)
            right = dyadic(nn - k1, depth + 1, x0, y0 + h1, w, h - h1)
        return left + right

    candidates = []
    k = int(math.isqrt(n))
    while k * k < n:
        k += 1
    for kk in range(max(1, k - 2), min(n, k + 3) + 1):
        if kk <= 0:
            continue
        candidates.append(grid(kk))
    for r in range(1, min(n, 12) + 1):
        for c in range(1, min(n, 12) + 1):
            if 1 <= r * c <= n + 5:
                candidates.append(grid_rect(r, c))
    candidates.append(rowpack(n))
    candidates.append(dyadic(n))
    for _ in range(6):
        base = [mk(random.random(), random.random(), 0.0, 0.0) for _ in range(n)]
        candidates.append(base)

    best_sol = None
    best_val = -1.0
    for cand in candidates:
        cand = [clamp_square(list(x)) for x in cand]
        if len(cand) < n:
            cand += [mk(0.5, 0.5, 0.0, 0.0)] * (n - len(cand))
        cand = cand[:n]
        cand = local_search(cand, rounds=80)
        v = total(cand)
        if v > best_val:
            best_val = v
            best_sol = cand

    # Final polish with more iterations on best
    for _ in range(3):
        best_sol = local_search(best_sol, rounds=120)
        if total(best_sol) > best_val:
            best_val = total(best_sol)

    res = []
    for q in best_sol[:n]:
        q = clamp_square(q)
        res.append((q[0], q[1], q[2], q[3]))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res
