import math
import random
import time
from typing import List, Tuple

Vec = Tuple[float, float]


def _sq_corners(cx: float, cy: float, ang: float, s: float) -> List[Vec]:
    """Return the 4 corners of a square."""
    if s <= 0.0:
        return [(cx, cy)] * 4
    a = ang * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + x * c - y * sn, cy + x * sn + y * c))
    return out


def _axes(corners: List[Vec]) -> List[Vec]:
    axes = []
    for i in range(4):
        x1, y1 = corners[i]
        x2, y2 = corners[(i + 1) % 4]
        ex, ey = x2 - x1, y2 - y1
        ln = math.hypot(ex, ey)
        if ln > 1e-15:
            axes.append((-ey / ln, ex / ln))
    return axes


def _project(corners: List[Vec], ax: Vec) -> Tuple[float, float]:
    axx, axy = ax
    mn = mx = corners[0][0] * axx + corners[0][1] * axy
    for x, y in corners[1:]:
        v = x * axx + y * axy
        if v < mn:
            mn = v
        elif v > mx:
            mx = v
    return mn, mx


def _overlap_area(e1, e2) -> float:
    """Approximate overlap penalty via separating-axis. 0 if disjoint."""
    c1 = e1[0]
    c2 = e2[0]
    s1 = e1[1]
    s2 = e2[1]
    if s1 <= 0.0 or s2 <= 0.0:
        return 0.0
    # quick bounding-circle reject
    r1 = s1 * 0.7071067811865476
    r2 = s2 * 0.7071067811865476
    dx = c1[0] - c2[0]
    dy = c1[1] - c2[1]
    if dx * dx + dy * dy > (r1 + r2) ** 2:
        return 0.0
    corners1 = _sq_corners(c1[0], c1[1], e1[2], s1)
    corners2 = _sq_corners(c2[0], c2[1], e2[2], s2)
    axes = _axes(corners1) + _axes(corners2)
    min_overlap = 1e18
    for ax in axes:
        a1, b1 = _project(corners1, ax)
        a2, b2 = _project(corners2, ax)
        ov = min(b1, b2) - max(a1, a2)
        if ov <= 0.0:
            return 0.0
        if ov < min_overlap:
            min_overlap = ov
    return min_overlap * min_overlap


def _penalty(entries, target_pen=1000.0):
    pen = 0.0
    n = len(entries)
    for i in range(n):
        ci, si = entries[i][0], entries[i][1]
        # boundary
        r = si * 0.7071067811865476
        if ci[0] - r < 0.0:
            pen += (r - ci[0]) ** 2 * target_pen
        if ci[0] + r > 1.0:
            pen += (ci[0] + r - 1.0) ** 2 * target_pen
        if ci[1] - r < 0.0:
            pen += (r - ci[1]) ** 2 * target_pen
        if ci[1] + r > 1.0:
            pen += (ci[1] + r - 1.0) ** 2 * target_pen
    for i in range(n):
        for j in range(i + 1, n):
            o = _overlap_area((entries[i][0], entries[i][1]), (entries[j][0], entries[j][1]))
            if o > 0.0:
                pen += o * target_pen
    return pen


def _clamp_entry(cx, cy, ang, s):
    """Clamp center into [0,1], angle mod 1, side >=0."""
    cx = min(1.0, max(0.0, cx))
    cy = min(1.0, max(0.0, cy))
    ang = ang - math.floor(ang)
    if s < 0.0:
        s = 0.0
    # ensure bounding circle fits approximately (soft)
    s = min(s, 1.0)
    return (cx, cy, ang, s)


def _random_layout(n, rng):
    """Generates layouts from several strategies and returns best."""
    cands = []

    # strategy 0: grid
    k = max(1, int(round(math.sqrt(n))))
    if k * k < n:
        k += 1
    side = 1.0 / k
    arr = []
    cnt = 0
    for i in range(k):
        for j in range(k):
            if cnt >= n:
                break
            arr.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
            cnt += 1
        if cnt >= n:
            break
    while len(arr) < n:
        arr.append((0.5, 0.5, 0.0, 0.0))
    cands.append(arr)

    # strategy 1: guillotine recursive
    def guillotine(depth, x0, y0, x1, y1, count):
        if count <= 0:
            return []
        if count == 1:
            w = (x1 - x0)
            h = (y1 - y0)
            s = min(w, h)
            return [((x0 + x1) * 0.5, (y0 + y1) * 0.5, 0.0, s)]
        if depth > 12:
            w = (x1 - x0)
            h = (y1 - y0)
            s = min(w, h) / math.sqrt(count)
            r = max(0.0, s * 0.5)
            if (x1 - x0) > (y1 - y0):
                return [((x0 + x1) * 0.5, (y0 + y1) * 0.5, 0.0, min(s, w, h) * 0.5)] * count
            else:
                return [((x0 + x1) * 0.5, (y0 + y1) * 0.5, 0.0, min(s, w, h) * 0.5)] * count
        # split in the longer dimension, sometimes with rotations
        w = x1 - x0
        h = y1 - y0
        if w >= h:
            cut = w * rng.uniform(0.35, 0.65)
            n1 = max(1, int(round(count * (cut / w))))
            n1 = min(count - 1, max(1, n1))
            n2 = count - n1
            return guillotine(depth + 1, x0, y0, x0 + cut, y1, n1) + \
                   guillotine(depth + 1, x0 + cut, y0, x1, y1, n2)
        else:
            cut = h * rng.uniform(0.35, 0.65)
            n1 = max(1, int(round(count * (cut / h))))
            n1 = min(count - 1, max(1, n1))
            n2 = count - n1
            return guillotine(depth + 1, x0, y0, x1, y0 + cut, n1) + \
                   guillotine(depth + 1, x0, y0 + cut, x1, y1, n2)

    for _ in range(3):
        try:
            g = guillotine(0, 0.0, 0.0, 1.0, 1.0, n)
            while len(g) < n:
                g.append((0.5, 0.5, 0.0, 0.0))
            cands.append(g[:n])
        except RecursionError:
            pass

    # strategy 2: random points with small sizes
    arr = []
    for _ in range(n):
        arr.append((rng.uniform(0.05, 0.95), rng.uniform(0.05, 0.95),
                    rng.uniform(0.0, 1.0), rng.uniform(0.01, 0.2)))
    cands.append(arr)

    # pick best by score minus penalty
    def score_of(arr):
        return sum(t[3] for t in arr) - _penalty([(t[:2], t[3]) for t in arr], target_pen=500.0)

    best = None
    bestv = -1e9
    for arr in cands:
        arr = [_clamp_entry(*t) for t in arr]
        v = score_of(arr)
        if v > bestv:
            bestv = v
            best = arr
    return best


def _local_optimize(init, time_budget, seed):
    rng = random.Random(seed)
    n = len(init)
    cur = [_clamp_entry(*t) for t in init]
    cur_score = sum(t[3] for t in cur) - _penalty([(t[:2], t[3]) for t in cur], target_pen=5000.0)

    start = time.time()
    best = cur[:]
    best_score = sum(t[3] for t in best) - _penalty([(t[:2], t[3]) for t in best], target_pen=5000.0)
    best_feasible = best_score

    # scale of moves
    step = 0.05
    temp = 0.05
    it = 0
    while time.time() - start < time_budget:
        it += 1
        if it % 200 == 0:
            step = max(0.003, step * 0.995)
            temp = max(0.0005, temp * 0.995)
        cand = [list(t) for t in cur]
        k = rng.randrange(n)
        # choose a move type
        typ = rng.random()
        if typ < 0.45:
            # move
            cand[k][0] += rng.gauss(0.0, step)
            cand[k][1] += rng.gauss(0.0, step)
        elif typ < 0.7:
            # size
            cand[k][3] += rng.gauss(0.0, step * 0.8)
            if cand[k][3] < 0.0:
                cand[k][3] = 0.0
        elif typ < 0.9:
            # angle
            cand[k][2] += rng.gauss(0.0, step * 0.5)
            cand[k][2] = cand[k][2] % 1.0
        else:
            # move+size
            cand[k][0] += rng.gauss(0.0, step * 0.7)
            cand[k][1] += rng.gauss(0.0, step * 0.7)
            cand[k][3] += rng.gauss(0.0, step * 0.6)
            if cand[k][3] < 0.0:
                cand[k][3] = 0.0

        cand = [_clamp_entry(*t) for t in cand]
        entries = [(t[:2], t[3]) for t in cand]
        pen = _penalty(entries, target_pen=5000.0)
        sc = sum(t[3] for t in cand) - pen
        d = sc - cur_score
        if d >= 0.0 or rng.random() < math.exp(d / max(temp, 1e-12)):
            cur = cand
            cur_score = sc
            if pen < 1e-6 * max(1.0, sum(t[3] for t in cur)):
                s = sum(t[3] for t in cur)
                if s > best_feasible:
                    best_feasible = s
                    best = cur[:]
                    best_score = sc

    # final verify and repair: remove tiny overlaps by shrinking
    entries = [(t[:2], t[3]) for t in best]
    return best_feasible, best


def _repair(entries):
    """Given list of (cx,cy,ang,s), do a final shrink pass to remove overlaps."""
    n = len(entries)
    arr = [[t[0], t[1], t[2], t[3]] for t in entries]
    # Also ensure bounds
    for _ in range(20):
        changed = False
        # boundary shrink
        for i in range(n):
            cx, cy, ang, s = arr[i]
            if s <= 0.0:
                continue
            r = s * 0.7071067811865476
            new_s = s
            if cx - r < 0.0:
                new_s = min(new_s, cx / 0.7071067811865476)
            if cx + r > 1.0:
                new_s = min(new_s, (1.0 - cx) / 0.7071067811865476)
            if cy - r < 0.0:
                new_s = min(new_s, cy / 0.7071067811865476)
            if cy + r > 1.0:
                new_s = min(new_s, (1.0 - cy) / 0.7071067811865476)
            if new_s < s:
                arr[i][3] = max(0.0, new_s)
                changed = True
        # overlap shrink: if two overlap, shrink larger by amount related to overlap
        for i in range(n):
            for j in range(i + 1, n):
                e1 = ((arr[i][0], arr[i][1]), arr[i][3])
                e2 = ((arr[j][0], arr[j][1]), arr[j][3])
                ov = _overlap_area(e1, e2)
                if ov > 1e-12:
                    # shrink both a bit
                    si = arr[i][3]
                    sj = arr[j][3]
                    if si > 0 and sj > 0:
                        f = 0.98
                        arr[i][3] = si * f
                        arr[j][3] = sj * f
                        changed = True
        if not changed:
            break
    return [(arr[i][0], arr[i][1], arr[i][2], arr[i][3]) for i in range(n)]


def solve(n):
    if n <= 0:
        return []
    rng = random.Random(12345)
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares likely side 0.5 each side by side; but maybe rotated diagonal can be better?
        # two congruent axis-aligned squares: max sum = 1.0 (each 0.5)
        # can rotated do better? A 45-degree square of side sqrt(2)/2? no, must fit in unit.
        # Try: two squares side 0.5.
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # known: 2 big squares side 0.5 plus one small as large as possible in remaining? 
        # 3 equal squares side? 1/2+... Actually three in a row: side 1/3 each -> sum 1.
        # Better: two 0.5 squares on left, remaining half split: one square side? 
        # left column two squares 0.5 each. right column (width 0.5): place one square side 0.5? 
        # 3 squares: 0.5,0.5,0.5? Can't (would be 2x2 grid missing one). Actually 0.5 squares 
        # take pairs; the remaining is an L-shape of two 0.25 squares. Put one 0.5? no.
        # Two 0.5 and one maximized in L: L is unit minus two 0.5 squares in top and bottom 
        # of left column. Right column is empty full 0.5x1.0, can fit 0.5. But then left column 
        # has 0.5 and 0.5 and right column 0.5 => three 0.5 squares in an L. Yes! 
        return [(0.25, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    
    # For general n, use multi-start local optimization
    init = _random_layout(n, rng)
    # seed multiple starts
    best_val = -1e9
    best_arr = None
    
    # number of restarts scaled by n and time
    time_limit = 45.0
    per_start = max(0.5, min(5.0, time_limit / 6.0))
    starts = []
    starts.append(init)
    for _ in range(4):
        s = _random_layout(n, rng)
        starts.append(s)
    # also perturbed
    for base in [init]:
        for _ in range(3):
            p = []
            for t in base:
                p.append(_clamp_entry(
                    t[0] + rng.gauss(0, 0.05),
                    t[1] + rng.gauss(0, 0.05),
                    t[2] + rng.gauss(0, 0.2),
                    max(0.0, t[3] + rng.gauss(0, 0.03))))
            starts.append(p)
    
    t0 = time.time()
    total_budget = 55.0
    for idx, s in enumerate(starts):
        if time.time() - t0 > total_budget:
            break
        remain = total_budget - (time.time() - t0)
        this_budget = min(per_start, remain)
        if this_budget <= 0:
            break
        val, arr = _local_optimize(s, this_budget, seed=idx * 1000 + n)
        if val > best_val:
            best_val = val
            best_arr = arr
    
    if best_arr is None:
        best_arr = init
    # final repair
    repaired = _repair([(t[0], t[1], t[2], t[3]) for t in best_arr])
    # ensure feasibility and score
    # verify and zero out any tiny overlaps by shrinking to zero if needed
    arr = repaired
    # check overlaps and boundary robustly
    for _ in range(50):
        bad = False
        # boundary
        for i in range(len(arr)):
            cx, cy, ang, s = arr[i]
            if s <= 0:
                continue
            r = s * 0.7071067811865476
            if cx - r < -1e-9 or cx + r > 1.0 + 1e-9 or cy - r < -1e-9 or cy + r > 1.0 + 1e-9:
                bad = True
                s2 = s * 0.999
                arr[i] = (cx, cy, ang, max(0.0, s2))
        # overlap
        for i in range(len(arr)):
            for j in range(i + 1, len(arr)):
                e1 = ((arr[i][0], arr[i][1]), arr[i][3])
                e2 = ((arr[j][0], arr[j][1]), arr[j][3])
                if _overlap_area(e1, e2) > 1e-12:
                    bad = True
                    si, sj = arr[i][3], arr[j][3]
                    arr[i] = (arr[i][0], arr[i][1], arr[i][2], si * 0.995)
                    arr[j] = (arr[j][0], arr[j][1], arr[j][2], sj * 0.995)
        if not bad:
            break
    
    # clamp to valid
    result = []
    for cx, cy, ang, s in arr:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        if s < 0:
            s = 0.0
        result.append((cx, cy, ang, s))
    
    # if n == 0 handled; ensure exactly n
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
