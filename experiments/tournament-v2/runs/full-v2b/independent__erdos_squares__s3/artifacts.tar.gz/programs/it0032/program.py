import math
import random
import numpy as np

def solve(n):
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # initial grid
    k = math.isqrt(n)
    base = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) < n:
                squares.append([ (i+0.5)*base, (j+0.5)*base, 0.0, base ])
    # fill remaining with small squares in leftover space (row/col not full)
    # We'll just add them stacked in a tiny cluster at the top area to be fixed later
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    squares = squares[:n]
    squares = np.array(squares, dtype=float)  # shape (n,4): cx, cy, angle_frac, side

    # We'll optimize by iterative local search: try random square, grow it slightly,
    # if overlap, try to adjust positions of overlapping squares minimally.
    # More robust: use repulsion dynamics

    def corners(cx, cy, angle, side):
        a = angle * 2 * math.pi
        ca, sa = math.cos(a), math.sin(a)
        h = side / 2.0
        # corners in local frame: (+-h, +-h)
        pts = [(-h,-h), (h,-h), (h,h), (-h,h)]
        out = []
        for x, y in pts:
            out.append((cx + x*ca - y*sa, cy + x*sa + y*ca))
        return out

    def poly_overlap(p1, p2):
        # SAT for convex polygons
        polys = [p1, p2]
        for poly in polys:
            for i in range(4):
                x1, y1 = poly[i]
                x2, y2 = poly[(i+1)%4]
                edge = (x2-x1, y2-y1)
                axis = (-edge[1], edge[0])
                # project both
                min1 = min(p[0]*axis[0] + p[1]*axis[1] for p in p1)
                max1 = max(p[0]*axis[0] + p[1]*axis[1] for p in p1)
                min2 = min(p[0]*axis[0] + p[1]*axis[1] for p in p2)
                max2 = max(p[0]*axis[0] + p[1]*axis[1] for p in p2)
                if max1 < min2 - 1e-12 or max2 < min1 - 1e-12:
                    return False
        return True

    # try to increase sizes and resolve overlaps by moving centres
    best = squares.copy()
    best_score = sum(squares[:,3])

    # Use a simple iterative approach: repeatedly attempt to increase each square
    # and keep if no overlap.

    # Precompute current corners
    def total_score(sq):
        return sum(sq[:,3])

    def has_overlap(sq):
        n_ = len(sq)
        corners_list = [corners(sq[i,0], sq[i,1], sq[i,2], sq[i,3]) for i in range(n_)]
        for i in range(n_):
            for j in range(i+1, n_):
                if sq[i,3] < 1e-9 or sq[j,3] < 1e-9:
                    continue
                if poly_overlap(corners_list[i], corners_list[j]):
                    return True
        return False

    # Simple growth strategy:
    # Cycle through squares, try to increase side, and if overlap, try to nudge apart.
    # Use many random restarts / trials.

    random.seed(12345)
    np.random.seed(12345)

    # We'll start with a good heuristic: try to fill the square with equal squares where possible.
    # Then optimize for remaining space.

    # Better initialization: strip packing for remainder
    # Actually let's just do many random perturbations and keep best.

    max_iter = 20000
    squares = best.copy()
    best = squares.copy()
    best_score = total_score(best)

    def clamp_all(sq):
        # keep centres inside [0,1] and sizes non-negative
        sq[:,0] = np.clip(sq[:,0], 0.0, 1.0)
        sq[:,1] = np.clip(sq[:,1], 0.0, 1.0)
        sq[:,3] = np.maximum(sq[:,3], 0.0)

    for it in range(max_iter):
        # pick random square
        i = random.randrange(n)
        # try to increase size
        old = squares[i].copy()
        # increase
        factor = 1.0 + random.uniform(0.001, 0.05)
        new_side = min(1.0, squares[i,3] * factor + 0.0001)
        # try random position/angle perturbation
        squares[i,3] = new_side
        squares[i,0] += random.uniform(-0.05, 0.05)
        squares[i,1] += random.uniform(-0.05, 0.05)
        squares[i,2] += random.uniform(-0.1, 0.1)
        clamp_all(squares)

        if has_overlap(squares):
            # revert
            squares[i] = old
        else:
            sc = total_score(squares)
            if sc > best_score:
                best_score = sc
                best = squares.copy()

    # Refinement: try small adjustments
    for it in range(10000):
        i = random.randrange(n)
        old = squares[i].copy()
        # try to grow
        squares[i,3] *= (1 + random.uniform(0.0001, 0.01))
        squares[i,0] += random.uniform(-0.01, 0.01)
        squares[i,1] += random.uniform(-0.01, 0.01)
        squares[i,2] += random.uniform(-0.02, 0.02)
        clamp_all(squares)
        if has_overlap(squares):
            squares[i] = old
        else:
            sc = total_score(squares)
            if sc > best_score:
                best_score = sc
                best = squares.copy()

    # Final cleanup: zero out tiny squares that don't help (optional) or just return
    result = []
    for i in range(n):
        cx, cy, ang, side = best[i]
        # ensure angle is fraction of turn, normalize to [0,1)
        ang = ang % 1.0
        side = max(0.0, min(1.0, side))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        result.append((cx, cy, ang, side))
    return result
