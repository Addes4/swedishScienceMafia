import math
import random
import numpy as np

def _overlap_area(sq1, sq2):
    """Return whether two squares' interiors overlap, using separating axis theorem."""
    cx1, cy1, a1, s1 = sq1
    cx2, cy2, a2, s2 = sq2
    if s1 <= 0 or s2 <= 0:
        return False
    # corner vectors for axis-aligned squares rotated by angle (fraction of turn)
    t1 = a1 * 2 * math.pi
    t2 = a2 * 2 * math.pi
    c1, s_1 = math.cos(t1), math.sin(t1)
    c2, s_2 = math.cos(t2), math.sin(t2)
    h1 = s1 / 2
    h2 = s2 / 2
    # four axes: normals of each square
    axes = [(c1, s_1), (-s_1, c1), (c2, s_2), (-s_2, c2)]
    dx = cx2 - cx1
    dy = cy2 - cy1
    for ax, ay in axes:
        # project both squares onto axis
        r1 = h1 * (abs(ax * c1 + ay * s_1) + abs(-ax * s_1 + ay * c1))
        r2 = h2 * (abs(ax * c2 + ay * s_2) + abs(-ax * s_2 + ay * c2))
        dist = abs(ax * dx + ay * dy)
        if dist >= r1 + r2 - 1e-12:
            return False
    return True

def _projection_radius(cx, cy, angle, side, axis):
    t = angle * 2 * math.pi
    c, s = math.cos(t), math.sin(t)
    ux, uy = axis
    # extent along axis
    return side / 2 * (abs(ux * c + uy * s) + abs(-ux * s + uy * c))

def solve(n):
    if n == 0:
        return []
    random.seed(42 + n)
    # Initialize with a grid-like structure but random sizes
    squares = []
    # Use approximate sqrt for initial grid
    k = max(1, int(math.sqrt(n)))
    # Create initial arrangement: grid with jitter
    for idx in range(n):
        grid_size = k
        row = idx // grid_size
        col = idx % grid_size
        if row >= grid_size:
            row = grid_size - 1
            col = min(col, grid_size - 1)
        cell = 1.0 / grid_size
        cx = (col + 0.5) * cell
        cy = (row + 0.5) * cell
        # small random angle
        ang = random.uniform(-0.05, 0.05) + random.choice([0, 0.25, 0.5, 0.75]) * random.uniform(0.9, 1.1)
        ang = ang % 1.0
        side = cell * random.uniform(0.7, 0.98)
        squares.append([cx, cy, ang, side])
    # Clamp to [0,1]
    for s in squares:
        s[0] = max(s[3]/2, min(1 - s[3]/2, s[0]))
        s[1] = max(s[3]/2, min(1 - s[3]/2, s[1]))

    # Optimization: iterative scaling and separation
    best_squares = [list(s) for s in squares]
    best_total = sum(s[3] for s in squares)
    current = [list(s) for s in squares]
    current_total = best_total
    
    temperature = 0.01
    for iteration in range(3000):
        # Try to increase all sizes
        scale = 1.0 + 0.005 * (1.0 - iteration / 3000.0)
        for i in range(n):
            current[i][3] *= scale
            # keep inside
            current[i][0] = max(current[i][3]/2, min(1 - current[i][3]/2, current[i][0]))
            current[i][1] = max(current[i][3]/2, min(1 - current[i][3]/2, current[i][1]))
        
        # Resolve overlaps by pushing apart or shrinking
        for _ in range(30):
            any_overlap = False
            for i in range(n):
                for j in range(i+1, n):
                    if _overlap_area(current[i], current[j]):
                        any_overlap = True
                        # push apart
                        cx1, cy1, a1, s1 = current[i]
                        cx2, cy2, a2, s2 = current[j]
                        dx = cx2 - cx1
                        dy = cy2 - cy1
                        d = math.hypot(dx, dy) + 1e-10
                        # estimate combined radius
                        r1 = s1 * 0.7
                        r2 = s2 * 0.7
                        overlap = (r1 + r2) - d
                        if overlap > 0:
                            push = overlap * 0.5
                            nx = dx / d
                            ny = dy / d
                            current[i][0] -= nx * push
                            current[i][1] -= ny * push
                            current[j][0] += nx * push
                            current[j][1] += ny * push
                            # clamp
                            for sq in (current[i], current[j]):
                                sq[0] = max(sq[3]/2, min(1 - sq[3]/2, sq[0]))
                                sq[1] = max(sq[3]/2, min(1 - sq[3]/2, sq[1]))
                        else:
                            # shrink both slightly
                            current[i][3] *= 0.995
                            current[j][3] *= 0.995
                            for sq in (current[i], current[j]):
                                sq[0] = max(sq[3]/2, min(1 - sq[3]/2, sq[0]))
                                sq[1] = max(sq[3]/2, min(1 - sq[3]/2, sq[1]))
            if not any_overlap:
                break
        
        # Random perturbation: move and rotate
        for i in range(n):
            if random.random() < 0.1:
                current[i][0] += random.gauss(0, 0.005)
                current[i][1] += random.gauss(0, 0.005)
                current[i][2] += random.gauss(0, 0.005)
                current[i][2] %= 1.0
                # clamp
                s = current[i][3]
                current[i][0] = max(s/2, min(1 - s/2, current[i][0]))
                current[i][1] = max(s/2, min(1 - s/2, current[i][1]))
        
        # Check validity and total
        total = sum(s[3] for s in current)
        valid = True
        for i in range(n):
            if current[i][3] < 0:
                valid = False
                break
            if current[i][0] < current[i][3]/2 - 1e-9 or current[i][0] > 1 - current[i][3]/2 + 1e-9:
                valid = False
                break
            if current[i][1] < current[i][3]/2 - 1e-9 or current[i][1] > 1 - current[i][3]/2 + 1e-9:
                valid = False
                break
        if valid:
            for i in range(n):
                for j in range(i+1, n):
                    if _overlap_area(current[i], current[j]):
                        valid = False
                        break
                if not valid:
                    break
        if valid and total > best_total:
            best_total = total
            best_squares = [list(s) for s in current]
            temperature *= 0.99
        else:
            if random.random() < 0.3:
                # revert some
                for i in range(n):
                    if random.random() < 0.2:
                        current[i] = list(best_squares[i])
    
    # Final cleanup: ensure validity
    result = []
    for i in range(n):
        cx, cy, ang, side = best_squares[i]
        side = max(0, min(side, 1.0))
        if side > 0:
            cx = max(side/2, min(1 - side/2, cx))
            cy = max(side/2, min(1 - side/2, cy))
        else:
            cx = max(0, min(1, cx))
            cy = max(0, min(1, cy))
        ang = ang % 1.0
        result.append((cx, cy, ang, side))
    
    # Final overlap resolution: shrink any overlapping squares
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i+1, n):
                if _overlap_area(result[i], result[j]):
                    changed = True
                    cx1, cy1, a1, s1 = result[i]
                    cx2, cy2, a2, s2 = result[j]
                    # shrink smaller one
                    if s1 <= s2:
                        new_side = max(0, s1 * 0.98)
                        result[i] = (max(new_side/2, min(1-new_side/2, cx1)),
                                     max(new_side/2, min(1-new_side/2, cy1)),
                                     a1, new_side)
                    else:
                        new_side = max(0, s2 * 0.98)
                        result[j] = (max(new_side/2, min(1-new_side/2, cx2)),
                                     max(new_side/2, min(1-new_side/2, cy2)),
                                     a2, new_side)
        if not changed:
            break
    
    return result
