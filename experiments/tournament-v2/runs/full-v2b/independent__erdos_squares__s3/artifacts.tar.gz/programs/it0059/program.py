import math
import random
from itertools import product

import numpy as np


def _corners(cx, cy, ang, s):
    h = s * 0.5
    c = math.cos(2.0 * math.pi * ang)
    sn = math.sin(2.0 * math.pi * ang)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * c - dy * sn
        y = cy + dx * sn + dy * c
        pts.append((x, y))
    return pts


def _axes(ang):
    a = 2.0 * math.pi * ang
    return (math.cos(a), math.sin(a)), (-math.sin(a), math.cos(a))


def _overlap_area(sq1, sq2, eps=1e-12):
    """Approximate overlap area of two squares via separating axis theorem sampling."""
    (c1x, c1y, a1, s1) = sq1
    (c2x, c2y, a2, s2) = sq2
    if s1 <= eps or s2 <= eps:
        return 0.0
    dx = c2x - c1x
    dy = c2y - c1y
    ax1, ay1 = _axes(a1)
    ax2, ay2 = _axes(a2)
    axes = [ax1, ay1, ax2, ay2]
    sep_min = 1e9
    for ax, ay in axes:
        proj1 = abs(ax * ax1[0] + ay * ax1[1]) * s1 * 0.5 + abs(ax * ax2[0] + ay * ax2[1]) * s2 * 0.5
        proj2 = abs(ax * ax2[0] + ay * ax2[1]) * s2 * 0.5 + abs(ax * ax1[0] + ay * ax1[1]) * s1 * 0.5
        dist = abs(dx * ax + dy * ay)
        r = proj1 + proj2
        if dist >= r:
            return 0.0
        sep_min = min(sep_min, dist)
    return 0.0


def _inside_penalty(pts, eps=1e-9):
    p = 0.0
    for x, y in pts:
        if x < -eps:
            p += (-eps - x) ** 2
        if x > 1.0 + eps:
            p += (x - 1.0 - eps) ** 2
        if y < -eps:
            p += (-eps - y) ** 2
        if y > 1.0 + eps:
            p += (y - 1.0 - eps) ** 2
    return p


def _sat_overlap(sq1, sq2):
    """Return True if interiors overlap using SAT."""
    (c1x, c1y, a1, s1) = sq1
    (c2x, c2y, a2, s2) = sq2
    if s1 <= 1e-12 or s2 <= 1e-12:
        return False
    ax1, ay1 = _axes(a1)
    ax2, ay2 = _axes(a2)
    dx = c2x - c1x
    dy = c2y - c1y
    for ax, ay in (ax1, ay1, ax2, ay2):
        p1 = (abs(ax * ax1[0] + ay * ax1[1]) + abs(ax * ay1[0] + ay * ay1[1])) * s1 * 0.5
        p2 = (abs(ax * ax2[0] + ay * ax2[1]) + abs(ax * ay2[0] + ay * ay2[1])) * s2 * 0.5
        dist = abs(dx * ax + dy * ay)
        if dist >= p1 + p2 - 1e-11:
            return False
    return True


def _penalty(squares):
    pen = 0.0
    n = len(squares)
    for i in range(n):
        cx, cy, ang, s = squares[i]
        if s < 0:
            pen += s * s * 1000.0
        pts = _corners(cx, cy, ang, s)
        pen += _inside_penalty(pts) * 50.0
    for i in range(n):
        for j in range(i + 1, n):
            if _sat_overlap(squares[i], squares[j]):
                dx = squares[j][0] - squares[i][0]
                dy = squares[j][1] - squares[i][1]
                pen += (1e-3 + abs(dx) + abs(dy)) * 100.0
    return pen


def _objective(squares):
    return sum(sq[3] for sq in squares)


def _total(squares):
    return _objective(squares) - _penalty(squares)


def _local_improve(squares, iterations=2000, step=0.02, rng=None):
    rng = rng or random.Random(0)
    n = len(squares)
    best = [list(sq) for sq in squares]
    best_val = _total(best)
    cur = [list(sq) for sq in best]
    cur_val = best_val
    temp = step
    for it in range(iterations):
        idx = rng.randrange(n)
        old = list(cur[idx])
        cur[idx][0] += rng.uniform(-temp, temp)
        cur[idx][1] += rng.uniform(-temp, temp)
        cur[idx][2] += rng.uniform(-temp, temp)
        cur[idx][3] += rng.uniform(-temp, temp)
        cur[idx][0] = min(1.0, max(0.0, cur[idx][0]))
        cur[idx][1] = min(1.0, max(0.0, cur[idx][1]))
        cur[idx][2] = cur[idx][2] % 1.0
        cur[idx][3] = min(1.0, max(0.0, cur[idx][3]))
        new_val = _total(cur)
        if new_val >= cur_val or rng.random() < math.exp((new_val - cur_val) / max(temp, 1e-9)):
            cur_val = new_val
            if cur_val > best_val:
                best_val = cur_val
                best = [list(sq) for sq in cur]
        else:
            cur[idx] = old
        temp *= 0.9995
    return best, best_val


def _grid_packing(n):
    if n == 0:
        return []
    k = math.isqrt(n)
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    rest = n - len(squares)
    if rest == 0:
        return squares
    # Try to shrink some row/col to insert rest squares.
    best = None
    best_score = -1
    # Try different grid arrangements with variable column widths.
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if cols > n:
            continue
        # Equal grid with some zero squares.
        if rows * cols <= n:
            s = min(1.0 / rows, 1.0 / cols)
            sq = []
            for i in range(rows):
                for j in range(cols):
                    if len(sq) < n:
                        sq.append(((j + 0.5) / cols, (i + 0.5) / rows, 0.0, s))
            if len(sq) == n:
                val = sum(x[3] for x in sq)
                if val > best_score:
                    best_score = val
                    best = sq
    # Add leftover squares optimally: shrink grid slightly and put remaining in a strip.
    for k in range(1, n + 1):
        if k * k > n:
            break
        m = n - k * k
        # keep k x k grid, and use remaining space around.
        if m == 0:
            continue
        # Put m squares in a row at bottom on top of scaled k x k grid.
        # Try to fit m squares in a strip of height h, and kxk grid of size g in remaining 1-h.
        for frac in (0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.99):
            g = min(frac, (1.0 - frac * m / (1.0 + m)) if m > 0 else frac)
            g = min(g, 1.0 / k)
            if g <= 0:
                continue
            remaining_h = 1.0 - g * k
            if remaining_h <= 0:
                continue
            strip_side = min(remaining_h, 1.0 / max(m, 1))
            sq = []
            for i in range(k):
                for j in range(k):
                    sq.append(((j + 0.5) * g, (i + 0.5) * g + remaining_h, 0.0, g))
            for i in range(m):
                sq.append(((i + 0.5) / m, strip_side * 0.5, 0.0, strip_side))
            if len(sq) == n:
                val = sum(x[3] for x in sq)
                if val > best_score:
                    best_score = val
                    best = sq
    if best is None:
        best = _grid_packing(max(1, n - 1)) + [(0.5, 0.5, 0.0, 0.0)]
    return best


def _candidate_packings(n, rng):
    cands = []
    # Grid with zero squares.
    k = math.isqrt(n)
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    cands.append(sq[:n])

    # Single row of n equal squares.
    s = 1.0 / n
    cands.append([((i + 0.5) * s, 0.5, 0.0, s) for i in range(n)])

    # Single column.
    cands.append([(0.5, (i + 0.5) * s, 0.0, s) for i in range(n)])

    # Grid with extra strip.
    cands.append(_grid_packing(n))

    # Hex-like / rotated arrangements.
    for ang in (0.0, 0.1, 0.2, 0.25):
        s = 1.0 / math.sqrt(n)
        sq = []
        cols = int(math.ceil(math.sqrt(n)))
        rows = int(math.ceil(n / cols))
        xs = np.linspace(s / 2, 1.0 - s / 2, cols)
        ys = np.linspace(s / 2, 1.0 - s / 2, rows)
        for x in xs:
            for y in ys:
                if len(sq) < n:
                    sq.append((x, y, ang, s))
        cands.append(sq)

    return cands


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    best = None
    best_val = -1e18

    cands = _candidate_packings(n, rng)
    # Also generate random perturbations.
    for _ in range(20):
        base = list(cands[rng.randrange(len(cands))])
        for i in range(len(base)):
            c = list(base[i])
            c[0] = min(1.0, max(0.0, c[0] + rng.uniform(-0.05, 0.05)))
            c[1] = min(1.0, max(0.0, c[1] + rng.uniform(-0.05, 0.05)))
            c[2] = (c[2] + rng.uniform(-0.1, 0.1)) % 1.0
            c[3] = min(1.0, max(0.0, c[3] + rng.uniform(-0.03, 0.03)))
            base[i] = tuple(c)
        cands.append(base)

    evals = 0
    max_evals = 300 if n <= 20 else (150 if n <= 100 else 60)
    for base in cands:
        if evals >= max_evals:
            break
        evals += 1
        sq = [list(x) for x in base]
        # quick penalty repair: shrink overlapping squares.
        for _ in range(30):
            changed = False
            for i in range(n):
                for j in range(i + 1, n):
                    if _sat_overlap(sq[i], sq[j]):
                        # shrink both slightly.
                        sq[i][3] *= 0.98
                        sq[j][3] *= 0.98
                        changed = True
                pts = _corners(*sq[i])
                if _inside_penalty(pts) > 0:
                    sq[i][3] *= 0.98
                    changed = True
            if not changed:
                break
        iters = 3000 if n <= 20 else (1500 if n <= 60 else 600)
        improved, val = _local_improve(sq, iterations=iters, step=0.03, rng=rng)
        if val > best_val:
            best_val = val
            best = improved
    # Final cleanup: ensure inside and non-overlapping (shrink as needed).
    out = []
    for i, s in enumerate(best):
        cx = min(1.0, max(0.0, s[0]))
        cy = min(1.0, max(0.0, s[1]))
        ang = s[2] % 1.0
        side = min(1.0, max(0.0, s[3]))
        out.append((cx, cy, ang, side))

    # Iterative repair: shrink conflicting squares until valid.
    for _ in range(200):
        valid = True
        for i in range(n):
            pts = _corners(*out[i])
            if _inside_penalty(pts) > 1e-8:
                valid = False
                cx, cy, ang, side = out[i]
                out[i] = (cx, cy, ang, side * 0.95)
        for i in range(n):
            for j in range(i + 1, n):
                if _sat_overlap(out[i], out[j]):
                    valid = False
                    cx1, cy1, a1, s1 = out[i]
                    cx2, cy2, a2, s2 = out[j]
                    out[i] = (cx1, cy1, a1, s1 * 0.95)
                    out[j] = (cx2, cy2, a2, s2 * 0.95)
        if valid:
            break
    return out
