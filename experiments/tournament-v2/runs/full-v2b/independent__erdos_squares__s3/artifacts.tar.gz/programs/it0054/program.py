import math
import random
import numpy as np
from scipy.optimize import minimize

# ---------- geometry utilities ----------

def corners(cx, cy, a, s):
    """Return the 4 corners of a square: centre (cx,cy), angle fraction of turn, side s."""
    t = 2.0 * math.pi * a
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    # local corners (x,y)
    pts = [(h, h), (-h, h), (-h, -h), (h, -h)]
    res = []
    for (x, y) in pts:
        res.append((cx + x * c - y * sn, cy + x * sn + y * c))
    return res

def sat_overlap(c1, c2):
    """Separating axis test for two convex polygons given as corner lists."""
    for poly in (c1, c2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            # normal
            nx, ny = -ey, ex
            min1 = min2 = 1e18
            max1 = max2 = -1e18
            for (px, py) in c1:
                d = px * nx + py * ny
                if d < min1: min1 = d
                if d > max1: max1 = d
            for (px, py) in c2:
                d = px * nx + py * ny
                if d < min2: min2 = d
                if d > max2: max2 = d
            if max1 < min2 - 1e-12 or max2 < min1 - 1e-12:
                return False
    return True

def overlap_any(squares, i):
    """Check if square i overlaps any other square in list."""
    ci = corners(*squares[i])
    for j in range(len(squares)):
        if i == j:
            continue
        cj = corners(*squares[j])
        if sat_overlap(ci, cj):
            return True
    return False

def inside_unit(cx, cy, a, s):
    """Check whether square is fully inside [0,1]^2."""
    cs = corners(cx, cy, a, s)
    for (x, y) in cs:
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True

def valid_square(cx, cy, a, s, squares, idx):
    """Full validity check."""
    if s < 0:
        return False
    if not inside_unit(cx, cy, a, s):
        return False
    if s == 0:
        return True
    ci = corners(cx, cy, a, s)
    for j in range(len(squares)):
        if j == idx:
            continue
        if squares[j][3] == 0:
            continue
        cj = corners(*squares[j])
        if sat_overlap(ci, cj):
            return False
    return True

# ---------- constructive packings ----------

def greedy_guillotine(n):
    """Split unit square recursively into rectangles, place squares greedily."""
    # generate candidate rectangles via binary splitting, then place squares
    rects = [(0.0, 0.0, 1.0, 1.0)]  # x, y, w, h
    squares = []
    # first, fill a grid as fallback
    k = int(math.isqrt(n))
    if k > 0:
        side = 1.0 / k
        for i in range(k):
            for j in range(k):
                squares.append((side * (i + 0.5), side * (j + 0.5), 0.0, side))
    # if fewer than n, add zero-size
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    # now try to improve by greedy splitting if n is small
    if n <= 30:
        # attempt recursive partition: use a list of (x,y,w,h) rectangles
        best_squares = squares[:n]
        best_score = sum(s[3] for s in best_squares)
        for _ in range(200):
            rects = [(0.0, 0.0, 1.0, 1.0)]
            placed = []
            attempts = 0
            while len(placed) < n and attempts < 1000:
                attempts += 1
                if not rects:
                    break
                # pick largest area rectangle
                rects.sort(key=lambda r: r[2] * r[3], reverse=True)
                rx, ry, rw, rh = rects.pop(0)
                side = min(rw, rh)
                if side < 1e-9:
                    break
                # place square in corner
                cx = rx + side * 0.5
                cy = ry + side * 0.5
                placed.append((cx, cy, 0.0, side))
                # leftover rectangles
                if rw > side + 1e-12:
                    rects.append((rx + side, ry, rw - side, rh))
                if rh > side + 1e-12:
                    rects.append((rx, ry + side, rw, rh - side))
            if len(placed) < n:
                # fill with zero
                while len(placed) < n:
                    placed.append((0.5, 0.5, 0.0, 0.0))
            score = sum(s[3] for s in placed)
            if score > best_score:
                best_score = score
                best_squares = placed[:n]
        squares = best_squares[:n]
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
    return squares

# ---------- local improvement ----------

def try_perturb(squares, n, iters=5000, T0=0.05):
    """Randomly perturb squares, keep valid improvements."""
    cur = [list(s) for s in squares]
    cur_score = sum(s[3] for s in cur)
    best = [list(s) for s in cur]
    best_score = cur_score
    T = T0
    for it in range(iters):
        i = random.randrange(n)
        if random.random() < 0.3:
            # try to grow this square
            cx, cy, a, s = cur[i]
            new_s = s + random.uniform(0.001, 0.05)
            # try slight rotation if growing fails
            new_a = a
            if random.random() < 0.5:
                new_a = (a + random.uniform(-0.05, 0.05)) % 1.0
            # try to adjust centre
            new_cx = cx + random.uniform(-0.02, 0.02)
            new_cy = cy + random.uniform(-0.02, 0.02)
            new_cx = min(1.0, max(0.0, new_cx))
            new_cy = min(1.0, max(0.0, new_cy))
            if valid_square(new_cx, new_cy, new_a, new_s, cur, i):
                old_score = sum(s[3] for s in cur)
                cur[i] = [new_cx, new_cy, new_a, new_s]
                new_score = sum(s[3] for s in cur)
                if new_score > best_score or random.random() < math.exp((new_score - old_score) / max(T, 1e-9)):
                    if new_score > best_score:
                        best_score = new_score
                        best = [list(s) for s in cur]
                else:
                    cur[i] = [cx, cy, a, s]
            else:
                # try just moving/rotating without growing
                if valid_square(new_cx, new_cy, new_a, s, cur, i):
                    cur[i] = [new_cx, new_cy, new_a, s]
        else:
            # try to move/rotate
            cx, cy, a, s = cur[i]
            new_cx = cx + random.uniform(-0.03, 0.03)
            new_cy = cy + random.uniform(-0.03, 0.03)
            new_cx = min(1.0, max(0.0, new_cx))
            new_cy = min(1.0, max(0.0, new_cy))
            new_a = (a + random.uniform(-0.1, 0.1)) % 1.0
            if valid_square(new_cx, new_cy, new_a, s, cur, i):
                cur[i] = [new_cx, new_cy, new_a, s]
        T *= 0.9995
        if T < 1e-6:
            T = 1e-6
    return best

# ---------- main solver ----------

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        # one square can be as large as possible: axis-aligned side 1
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares: each can be 0.5 side, side by side
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three squares: one large (0.5) and two smaller? or three equal?
        # three equal squares of side 1/3 fit in a row? no, they fit as 1x3 strip
        # Actually best known: three squares can be 0.5, 0.5, and small? 
        # Let's use 0.5, 0.5, and a small one? But sum=1.0+? 
        # Try three squares in an L-shape: one 0.5, two 0.25 -> sum=1.0
        # Better: three squares in a row of side 1/3 -> sum=1.0
        # Can we do better? Known optimal for 3 is 1.0? Actually maybe 1.0 is max.
        # We'll start with grid and let local search improve.
        pass
    # start with greedy guillotine for small n, grid for large
    if n <= 30:
        squares = greedy_guillotine(n)
    else:
        # for large n, use grid + random fine-tuning
        k = int(math.isqrt(n))
        side = 1.0 / k
        squares = []
        for i in range(k):
            for j in range(k):
                squares.append((side * (i + 0.5), side * (j + 0.5), 0.0, side))
        # if we have more slots, try to add small squares in gaps? 
        # For now, just add zero-size
        while len(squares) < n:
            squares.append((0.5, 0.5, 0.0, 0.0))
        squares = squares[:n]
        # maybe adjust sizes slightly for better packing? 
        # For large n, skip local search, too slow.
        return squares
    
    # local search for n <= 30
    best = squares
    best_score = sum(s[3] for s in best)
    # try multiple random restarts
    for restart in range(3):
        improved = try_perturb(squares, n, iters=2000, T0=0.02)
        score = sum(s[3] for s in improved)
        if score > best_score:
            best_score = score
            best = improved
    # ensure all valid; if any invalid, fall back to grid
    for i in range(n):
        if not valid_square(best[i][0], best[i][1], best[i][2], best[i][3], best, i):
            # fallback to grid
            k = int(math.isqrt(n))
            side = 1.0 / k
            best = []
            for i in range(k):
                for j in range(k):
                    best.append((side * (i + 0.5), side * (j + 0.5), 0.0, side))
            while len(best) < n:
                best.append((0.5, 0.5, 0.0, 0.0))
            best = best[:n]
            break
    # final check: ensure all in [0,1]
    for i in range(n):
        cx, cy, a, s = best[i]
        best[i] = (min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)), a % 1.0, max(0.0, s))
    return best
