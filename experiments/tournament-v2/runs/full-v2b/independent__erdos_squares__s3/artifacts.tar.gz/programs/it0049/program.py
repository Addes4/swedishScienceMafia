import math
import random
import numpy as np
from scipy.optimize import minimize

_EPS = 1e-12

def _corners(cx, cy, ang, s):
    a = ang * 2.0 * math.pi
    c = math.cos(a)
    si = math.sin(a)
    h = 0.5 * s
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * c - dy * si, cy + dx * si + dy * c))
    return pts

def _overlap_area(sq1, sq2):
    # approximate overlap via convex polygons (Sutherland-Hodgman clip)
    p1 = _corners(*sq1)
    p2 = _corners(*sq2)
    out = p1
    for i in range(4):
        a = p2[i]
        b = p2[(i + 1) % 4]
        inp = out
        if not inp:
            return 0.0
        ex = b[0] - a[0]
        ey = b[1] - a[1]
        out = []
        for j in range(len(inp)):
            p = inp[j]
            q = inp[(j + 1) % len(inp)]
            sp = ex * (p[1] - a[1]) - ey * (p[0] - a[0])
            sq = ex * (q[1] - a[1]) - ey * (q[0] - a[0])
            if sp >= -_EPS:
                out.append(p)
            if (sp >= -_EPS) != (sq >= -_EPS):
                t = sp / (sp - sq) if abs(sp - sq) > _EPS else 0.0
                out.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])))
        if not out:
            return 0.0
    area = 0.0
    for i in range(len(out)):
        x1, y1 = out[i]
        x2, y2 = out[(i + 1) % len(out)]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5

def _penalty(params, n):
    # params: cx,cy,ang,s for each
    p = params.reshape((n, 4))
    pen = 0.0
    total = 0.0
    for i in range(n):
        cx, cy, ang, s = p[i]
        ang = ang % 1.0
        if s < 0:
            pen += s * s * 1e4
            s = 0.0
        # boundary
        pts = _corners(cx, cy, ang, s)
        for x, y in pts:
            if x < -1e-9:
                pen += (x * x) * 1e4
            if x > 1 + 1e-9:
                pen += ((x - 1) * (x - 1)) * 1e4
            if y < -1e-9:
                pen += (y * y) * 1e4
            if y > 1 + 1e-9:
                pen += ((y - 1) * (y - 1)) * 1e4
        total += s
    # pair conflicts
    for i in range(n):
        for j in range(i + 1, n):
            o = _overlap_area(p[i], p[j])
            if o > 0:
                pen += o * o * 1e5
    return -total + pen

def _feasible(params, n):
    p = params.reshape((n, 4))
    for i in range(n):
        cx, cy, ang, s = p[i]
        if s < -1e-9:
            return False
        pts = _corners(cx, cy, ang % 1.0, max(0.0, s))
        for x, y in pts:
            if x < -1e-7 or x > 1 + 1e-7 or y < -1e-7 or y > 1 + 1e-7:
                return False
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap_area(p[i], p[j]) > 1e-7:
                return False
    return True

def _repair(params, n, iterations=200):
    p = params.reshape((n, 4)).copy()
    # clamp sizes
    for i in range(n):
        p[i, 3] = max(0.0, p[i, 3])
    # iterative overlap separation and clipping
    for _ in range(iterations):
        changed = False
        # clip into box by shrinking/moving
        for i in range(n):
            cx, cy, ang, s = p[i]
            pts = _corners(cx, cy, ang % 1.0, s)
            minx = min(q[0] for q in pts)
            maxx = max(q[0] for q in pts)
            miny = min(q[1] for q in pts)
            maxy = max(q[1] for q in pts)
            dx = 0.0
            dy = 0.0
            if minx < 0:
                dx = -minx
            if maxx > 1:
                dx = min(dx, 0) if dx != 0 else (1 - maxx)
            if dx != 0:
                p[i, 0] += dx
                changed = True
            if miny < 0:
                dy = -miny
            if maxy > 1:
                dy = min(dy, 0) if dy != 0 else (1 - maxy)
            if dy != 0:
                p[i, 1] += dy
                changed = True
        # resolve overlaps by pushing apart along center difference and shrinking
        for i in range(n):
            for j in range(i + 1, n):
                o = _overlap_area(p[i], p[j])
                if o > 1e-9:
                    x1, y1 = p[i, 0], p[i, 1]
                    x2, y2 = p[j, 0], p[j, 1]
                    dx = x1 - x2
                    dy = y1 - y2
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        ang = random.random() * 2 * math.pi
                        dx = math.cos(ang)
                        dy = math.sin(ang)
                        d = 1.0
                    push = math.sqrt(o) * 0.5
                    p[i, 0] += dx / d * push
                    p[i, 1] += dy / d * push
                    p[j, 0] -= dx / d * push
                    p[j, 1] -= dy / d * push
                    # shrink slightly
                    shrink = 0.995
                    p[i, 3] *= shrink
                    p[j, 3] *= shrink
                    changed = True
        if not changed:
            break
    # final clip
    for i in range(n):
        s = max(0.0, p[i, 3])
        cx, cy, ang = p[i, 0], p[i, 1], p[i, 2]
        # shrink until inside
        for _ in range(60):
            pts = _corners(cx, cy, ang % 1.0, s)
            minx = min(q[0] for q in pts)
            maxx = max(q[0] for q in pts)
            miny = min(q[1] for q in pts)
            maxy = max(q[1] for q in pts)
            if minx >= -1e-9 and maxx <= 1 + 1e-9 and miny >= -1e-9 and maxy <= 1 + 1e-9:
                break
            if s < 1e-9:
                s = 0.0
                break
            s *= 0.95
        p[i, 3] = max(0.0, s)
    # remove remaining overlaps by shrinking smaller square
    for _ in range(300):
        found = False
        for i in range(n):
            for j in range(i + 1, n):
                o = _overlap_area(p[i], p[j])
                if o > 1e-9:
                    found = True
                    if p[i, 3] <= p[j, 3]:
                        p[i, 3] *= 0.9
                    else:
                        p[j, 3] *= 0.9
                    if p[i, 3] < 1e-10 and p[j, 3] < 1e-10:
                        p[i, 3] = 0.0
                        p[j, 3] = 0.0
        if not found:
            break
    # ensure non-overlap strictly
    for i in range(n):
        p[i, 3] = max(0.0, p[i, 3])
    return p

def _initial_layout(n, seed):
    rnd = random.Random(seed)
    p = np.zeros((n, 4))
    # try grid for small sizes
    if n <= 64:
        k = math.isqrt(n)
        if k * k == n:
            side = 1.0 / k
            idx = 0
            for i in range(k):
                for j in range(k):
                    p[idx] = ((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                    idx += 1
            return p
    # random or hierarchical
    # use quadtree splitting
    cells = [(0.0, 0.0, 1.0, 1.0)]
    while len(cells) < n:
        # split largest cell
        cells.sort(key=lambda c: c[2] * c[3], reverse=True)
        x, y, w, h = cells.pop(0)
        if w >= h:
            cells.append((x, y, w / 2, h))
            cells.append((x + w / 2, y, w / 2, h))
        else:
            cells.append((x, y, w, h / 2))
            cells.append((x, y + h / 2, w, h / 2))
    rnd.shuffle(cells)
    for i in range(n):
        x, y, w, h = cells[i % len(cells)]
        cx = x + w / 2
        cy = y + h / 2
        s = min(w, h) * 0.98
        p[i] = (cx, cy, 0.0, s)
    return p

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    best_sum = -1.0
    best_p = None
    starts = 8
    for si in range(starts):
        rnd = random.Random(12345 + si * 97)
        p0 = _initial_layout(n, 12345 + si * 97)
        # add randomness
        for i in range(n):
            if si > 0:
                p0[i, 0] += (rnd.random() - 0.5) * 0.05
                p0[i, 1] += (rnd.random() - 0.5) * 0.05
                p0[i, 0] = min(1.0, max(0.0, p0[i, 0]))
                p0[i, 1] = min(1.0, max(0.0, p0[i, 1]))
                if rnd.random() < 0.5:
                    p0[i, 2] = rnd.random()
                p0[i, 3] *= (0.9 + 0.2 * rnd.random())
        x0 = p0.flatten()
        # bounds: cx,cy in [0,1], ang in [0,1], s in [0,1]
        bounds = [(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)] * n
        try:
            res = minimize(_penalty, x0, args=(n,), method='L-BFGS-B', bounds=bounds,
                           options={'maxiter': 200, 'ftol': 1e-12, 'gtol': 1e-8})
            x = res.x if res.x is not None else x0
        except Exception:
            x = x0
        p = _repair(x, n)
        # evaluate sum
        total = sum(p[i, 3] for i in range(n))
        if _feasible(p.flatten(), n) and total > best_sum:
            best_sum = total
            best_p = p.copy()
    if best_p is None:
        # fallback grid
        k = math.isqrt(n)
        side = 1.0 / k if k > 0 else 1.0
        p = np.zeros((n, 4))
        idx = 0
        for i in range(k):
            for j in range(k):
                if idx < n:
                    p[idx] = ((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                    idx += 1
        while idx < n:
            p[idx] = (0.5, 0.5, 0.0, 0.0)
            idx += 1
        best_p = p
        best_sum = sum(p[i, 3] for i in range(n))
    # one more refinement pass: shrink-free local adjustment
    p = best_p.copy()
    # maximize sum by slightly growing while maintaining feasibility
    improved = True
    it = 0
    while improved and it < 50:
        improved = False
        it += 1
        for i in range(n):
            old_s = p[i, 3]
            if old_s <= 0:
                continue
            # try grow
            scale = 1.02
            p[i, 3] = old_s * scale
            if _feasible(p.flatten(), n):
                improved = True
            else:
                p[i, 3] = old_s
        # random rotations for zero-size or small squares
        for i in range(n):
            if p[i, 3] < 1e-6:
                # place in a gap
                for _ in range(20):
                    cx = random.random()
                    cy = random.random()
                    s = 0.05 * random.random()
                    ang = random.random()
                    q = p.copy()
                    q[i] = (cx, cy, ang, s)
                    if _feasible(q.flatten(), n):
                        p = q
                        improved = True
                        break
    result = []
    for i in range(n):
        cx, cy, ang, s = p[i]
        cx = min(1.0, max(0.0, float(cx)))
        cy = min(1.0, max(0.0, float(cy)))
        ang = float(ang) % 1.0
        s = min(1.0, max(0.0, float(s)))
        result.append((cx, cy, ang, s))
    return result
