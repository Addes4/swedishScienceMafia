import math
import random
import numpy as np

# ----------------------------------------------------------------------
# Geometry helpers
# ----------------------------------------------------------------------
def corners(cx, cy, angle, side):
    """Return the 4 corners of a square (fraction of full turn for angle)."""
    a = angle * 2 * math.pi
    c, s = math.cos(a), math.sin(a)
    h = side * 0.5
    # local corners
    loc = ((-h, -h), (h, -h), (h, h), (-h, h))
    return [(cx + c * x - s * y, cy + s * x + c * y) for x, y in loc]


def projection_interval(corners, axis):
    """Project polygon onto axis, return (min, max)."""
    dots = [x * axis[0] + y * axis[1] for x, y in corners]
    return min(dots), max(dots)


def overlap(c1, c2):
    """True if interiors of two convex quads overlap (SAT)."""
    for poly in (c1, c2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            axis = (-(y2 - y1), x2 - x1)
            if axis == (0, 0):
                continue
            # normalise not needed for comparison
            mn1, mx1 = projection_interval(c1, axis)
            mn2, mx2 = projection_interval(c2, axis)
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return False
    return True


def inside_unit_square(corners, tol=0.0):
    for x, y in corners:
        if x < -tol or x > 1 + tol or y < -tol or y > 1 + tol:
            return False
    return True


# ----------------------------------------------------------------------
# Initial packing heuristics
# ----------------------------------------------------------------------
def grid_packing(n):
    """Place largest k x k grid and add small squares in remaining gaps."""
    best = None
    for k in range(1, int(math.sqrt(n)) + 2):
        if k * k > n:
            continue
        side = 1.0 / k
        # grid with k rows and k columns
        squares = []
        for i in range(k):
            for j in range(k):
                squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
        remaining = n - k * k
        # place extra squares as tiny things near corners / edges, but better: shrink grid slightly
        if remaining > 0:
            # shrink grid to make room: use factor
            f = 0.92
            s2 = side * f
            # recenter each grid square so grid occupies central f fraction
            offset = (1 - f) * 0.5
            for idx in range(len(squares)):
                squares[idx][0] = offset + squares[idx][0] * f
                squares[idx][1] = offset + squares[idx][1] * f
                squares[idx][3] = s2
            # now add remaining as small squares in the border strip
            # border width
            bw = offset
            # distribute remaining along perimeter
            if bw > 1e-9:
                t = remaining
                for r in range(t):
                    # alternate edges
                    pos = (r + 1) / (t + 1)
                    choice = r % 4
                    if choice == 0:  # bottom
                        cx, cy = pos, bw * 0.5
                    elif choice == 1:  # right
                        cx, cy = 1 - bw * 0.5, pos
                    elif choice == 2:  # top
                        cx, cy = pos, 1 - bw * 0.5
                    else:  # left
                        cx, cy = bw * 0.5, pos
                    # small side: at most bw * 0.9, and also limited by spacing
                    spacing = 1.0 / (t + 1)
                    ss = min(bw * 0.9, spacing * 0.8)
                    squares.append([cx, cy, 0.0, ss])
        # ensure exactly n
        while len(squares) < n:
            squares.append([0.5, 0.5, 0.0, 0.0])
        squares = squares[:n]
        val = sum(s[3] for s in squares)
        if best is None or val > best[0]:
            best = (val, squares)
    return best[1]


def greedy_packing(n):
    """Greedy: repeatedly add largest axis-aligned square in free space (coarse grid search)."""
    # Start with a fine grid of candidate positions and sizes
    squares = []
    # try a few random starts
    best_squares = None
    best_val = -1
    for trial in range(5):
        squares = []
        # candidate sizes from 1.0 down to small
        for _ in range(n):
            best_cand = (0.0, 0.5, 0.5, 0.0)
            # try many candidates
            for cx in np.linspace(0.05, 0.95, 25):
                for cy in np.linspace(0.05, 0.95, 25):
                    # max side that fits
                    # start with 0.6 and shrink
                    for ang in [0.0, 0.125, 0.25, 0.375]:  # some rotations
                        # binary search max side
                        lo, hi = 0.0, 0.7
                        for _ in range(20):
                            mid = (lo + hi) / 2
                            c = corners(cx, cy, ang, mid)
                            if not inside_unit_square(c):
                                hi = mid
                                continue
                            ok = True
                            for s in squares:
                                c2 = corners(s[0], s[1], s[2], s[3])
                                if overlap(c, c2):
                                    ok = False
                                    break
                            if ok:
                                lo = mid
                            else:
                                hi = mid
                        if lo > best_cand[3]:
                            best_cand = (lo, cx, cy, ang)
            # add best
            squares.append([best_cand[1], best_cand[2], best_cand[3], best_cand[0]])
        val = sum(s[3] for s in squares)
        if val > best_val:
            best_val = val
            best_squares = [s[:] for s in squares]
    return best_squares


# ----------------------------------------------------------------------
# Local improvement
# ----------------------------------------------------------------------
def total_side(squares):
    return sum(s[3] for s in squares)


def repair_overlaps(squares, tol=1e-9):
    """Scale down all squares uniformly until no overlaps. Returns (squares, penalty)."""
    # Check overlaps and boundary
    # Use a shrink factor: find max shrink needed
    # Simple iterative scaling
    shr = 1.0
    for _ in range(50):
        ok = True
        # check boundary
        for s in squares:
            c = corners(s[0], s[1], s[2], s[3] * shr)
            if not inside_unit_square(c):
                ok = False
                break
        if ok:
            # check pairwise overlaps
            n = len(squares)
            # build corner lists
            corns = [corners(s[0], s[1], s[2], s[3] * shr) for s in squares]
            for i in range(n):
                for j in range(i + 1, n):
                    if overlap(corns[i], corns[j]):
                        ok = False
                        break
                if not ok:
                    break
        if ok:
            break
        shr *= 0.98
    # apply shrink
    newsq = []
    for s in squares:
        newsq.append([s[0], s[1], s[2], s[3] * shr])
    penalty = (1 - shr) * total_side(squares)
    return newsq, penalty


def local_search(squares, n, iterations=3000, seed=0):
    """Perturb squares and accept if total side sum improves."""
    rng = random.Random(seed)
    squares = [s[:] for s in squares]
    best = [s[:] for s in squares]
    best_val = total_side(squares)

    for it in range(iterations):
        # choose random square to modify
        i = rng.randrange(n)
        s = squares[i]
        # perturb
        cx, cy, ang, side = s
        # size change
        ds = rng.gauss(0, 0.02)
        new_side = max(0.0, side + ds)
        # position change
        dx = rng.gauss(0, 0.015)
        dy = rng.gauss(0, 0.015)
        # angle change
        da = rng.gauss(0, 0.01)
        new_ang = (ang + da) % 0.5  # symmetry: 180 deg = 0.5 turn
        new_cx = cx + dx
        new_cy = cy + dy

        # boundary clamp
        new_cx = min(max(new_cx, 0.0), 1.0)
        new_cy = min(max(new_cy, 0.0), 1.0)

        # try update
        old = squares[i]
        squares[i] = [new_cx, new_cy, new_ang, new_side]

        # repair boundaries: if outside, pull back
        c = corners(new_cx, new_cy, new_ang, new_side)
        if not inside_unit_square(c):
            # clamp centre
            xs = [p[0] for p in c]
            ys = [p[1] for p in c]
            mnx, mxx = min(xs), max(xs)
            mny, mxy = min(ys), max(ys)
            if mnx < 0:
                new_cx += -mnx
            if mxx > 1:
                new_cx -= mxx - 1
            if mny < 0:
                new_cy += -mny
            if mxy > 1:
                new_cy -= mxy - 1
            squares[i] = [min(max(new_cx, 0), 1), min(max(new_cy, 0), 1), new_ang, new_side]

        # check overlaps with others
        conflict = False
        c_new = corners(squares[i][0], squares[i][1], squares[i][2], squares[i][3])
        for j in range(n):
            if j == i:
                continue
            c_j = corners(squares[j][0], squares[j][1], squares[j][2], squares[j][3])
            if overlap(c_new, c_j):
                conflict = True
                break
        if conflict:
            # revert
            squares[i] = old
        else:
            val = total_side(squares)
            if val >= best_val:
                best_val = val
                best = [s[:] for s in squares]
            else:
                # accept worse with small probability (simulated annealing-ish)
                if rng.random() < 0.01:
                    pass
                else:
                    squares[i] = old

    return best, best_val


# ----------------------------------------------------------------------
# Main solver
# ----------------------------------------------------------------------
def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside unit square."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # get initial packing
    sq = grid_packing(n)
    # possibly refine with greedy for small n
    if n <= 25:
        g = greedy_packing(n)
        if total_side(g) > total_side(sq):
            sq = g
    # local search
    best_sq = sq
    best_val = total_side(sq)
    # run multiple restarts
    for seed in range(3):
        s2, v2 = local_search(sq, n, iterations=1500, seed=seed)
        if v2 > best_val:
            best_val = v2
            best_sq = s2
    # final check: scales to avoid any tiny overlaps
    repaired, _ = repair_overlaps(best_sq, tol=1e-12)
    # ensure exact n
    res = []
    for s in repaired[:n]:
        cx, cy, ang, side = s
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        ang = ang % 0.5
        side = max(0.0, min(side, 1.0))
        # final boundary fix: if square extends outside, shrink side
        for _ in range(20):
            c = corners(cx, cy, ang, side)
            if inside_unit_square(c):
                break
            side *= 0.98
        res.append((cx, cy, ang, side))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]
