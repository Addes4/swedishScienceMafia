import math
import numpy as np
from scipy.optimize import minimize

def solve(n):
    if n == 0:
        return []
    if n <= 7:
        return _solve_small(n)
    return _solve_large(n)

def _solve_small(n):
    # Known good layouts for small n (derived from literature / simple constructions)
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.5, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 3:
        # Three squares: two half-height, one full-height but narrower
        s = 0.5
        return [(0.25, 0.5, 0.0, s), (0.75, 0.25, 0.0, s), (0.75, 0.75, 0.0, s)]
    if n == 4:
        # 2x2 grid, optimal
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s),
                (0.25, 0.75, 0.0, s), (0.75, 0.75, 0.0, s)]
    if n == 5:
        # 2x2 grid plus one small in center? Actually better: one large + four smaller
        # Try: one square side ~0.5 at corner, four squares side ~0.25
        # But known better: five squares with total side ~1.5? Let's use a simple layout
        # Use: one square side a at bottom-left, four squares side b in remaining L-shape
        # Optimize quickly: a^2? We'll use numeric optimization here.
        return _optimize_layout(n, _init_grid(n))
    if n == 6:
        return _optimize_layout(n, _init_grid(n))
    if n == 7:
        return _optimize_layout(n, _init_grid(n))

def _init_grid(n):
    # Initial guess: grid-based packing with some rotation
    k = int(math.ceil(math.sqrt(n)))
    s = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) < n:
                squares.append([(i+0.5)*s, (j+0.5)*s, 0.0, s*0.9])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return np.array(squares)

def _solve_large(n):
    # For larger n, use strip-based packing + local search
    best = None
    best_score = -1
    # Try several initial configurations
    for seed in range(3):
        np.random.seed(seed)
        init = _init_strips(n)
        result = _optimize_layout(n, init, max_iter=100)
        score = sum(s[3] for s in result)
        if score > best_score:
            best_score = score
            best = result
    return [tuple(s) for s in best]

def _init_strips(n):
    # Divide unit square into vertical strips, pack squares in each strip
    # Each strip gets approximately equal number of squares
    strips = max(1, int(math.sqrt(n)))
    squares = []
    remaining = n
    for strip_idx in range(strips):
        if remaining <= 0:
            break
        count = remaining // (strips - strip_idx)
        remaining -= count
        # In each strip, place count squares stacked vertically
        # Strip width = 1.0 / strips
        strip_w = 1.0 / strips
        # Each square gets height = 1.0 / count, but limited by width
        for j in range(count):
            side = min(strip_w, 1.0 / count)
            cx = (strip_idx + 0.5) * strip_w
            cy = (j + 0.5) * (1.0 / count)
            squares.append([cx, cy, 0.0, side * 0.95])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return np.array(squares[:n])

def _optimize_layout(n, init, max_iter=200):
    # Variables: for each square: cx, cy, angle, side
    # Constraints: within [0,1], non-overlap
    x0 = init.flatten()
    bounds = []
    for _ in range(n):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 0.25), (0.0, 1.0)])
    
    def objective(x):
        total = 0.0
        for i in range(n):
            total -= x[i*4+3]  # minimize negative sum of sides
        # Penalty for overlaps and boundary violations
        penalty = 0.0
        for i in range(n):
            cx, cy, ang, side = x[i*4:i*4+4]
            # Boundary check: square center must be inside [0,1], and corner extent
            half = side * (abs(math.cos(2*math.pi*ang)) + abs(math.sin(2*math.pi*ang))) / 2.0
            # Actually for a rotated square, the bounding box half-extent is (side/2)*(|cos|+|sin|)
            half = side * (abs(math.cos(2*math.pi*ang)) + abs(math.sin(2*math.pi*ang))) / 2.0
            if cx - half < -1e-9: penalty += (half - cx)**2 * 1000
            if cx + half > 1+1e-9: penalty += (cx + half - 1)**2 * 1000
            if cy - half < -1e-9: penalty += (half - cy)**2 * 1000
            if cy + half > 1+1e-9: penalty += (cy + half - 1)**2 * 1000
        
        # Overlap penalty: for each pair, check if they overlap
        for i in range(n):
            cx1, cy1, ang1, side1 = x[i*4:i*4+4]
            for j in range(i+1, n):
                cx2, cy2, ang2, side2 = x[j*4:j*4+4]
                # Check overlap using separating axis theorem for rotated squares
                overlap = _squares_overlap(cx1, cy1, ang1, side1, cx2, cy2, ang2, side2)
                if overlap > 0:
                    penalty += overlap * 1e5
        return total + penalty
    
    try:
        res = minimize(objective, x0, method='L-BFGS-B', bounds=bounds,
                      options={'maxiter': max_iter, 'ftol': 1e-12})
        x = res.x
    except Exception:
        x = x0
    
    # Extract result
    result = []
    for i in range(n):
        cx, cy, ang, side = x[i*4:i*4+4]
        # Ensure valid
        cx = np.clip(cx, 0.0, 1.0)
        cy = np.clip(cy, 0.0, 1.0)
        ang = np.clip(ang, 0.0, 0.25)
        side = max(0.0, min(side, 1.0))
        result.append([cx, cy, ang, side])
    
    # Post-process: resolve overlaps by shrinking
    result = _resolve_overlaps(result)
    return result

def _squares_overlap(cx1, cy1, ang1, s1, cx2, cy2, ang2, s2):
    if s1 <= 0 or s2 <= 0:
        return 0.0
    # Get vertices of both squares
    v1 = _square_vertices(cx1, cy1, ang1, s1)
    v2 = _square_vertices(cx2, cy2, ang2, s2)
    # SAT: check all axes (4 edges from each square)
    axes = []
    for i in range(4):
        edge = v1[(i+1)%4] - v1[i]
        axes.append(np.array([-edge[1], edge[0]]))
    for i in range(4):
        edge = v2[(i+1)%4] - v2[i]
        axes.append(np.array([-edge[1], edge[0]]))
    
    min_overlap = float('inf')
    for axis in axes:
        # Project both squares onto axis
        proj1 = [np.dot(v, axis) for v in v1]
        proj2 = [np.dot(v, axis) for v in v2]
        min1, max1 = min(proj1), max(proj1)
        min2, max2 = min(proj2), max(proj2)
        overlap = min(max1, max2) - max(min1, min2)
        if overlap <= 0:
            return 0.0  # separating axis found
        min_overlap = min(min_overlap, overlap)
    return min_overlap if min_overlap != float('inf') else 0.0

def _square_vertices(cx, cy, ang, side):
    # angle as fraction of full turn
    theta = 2 * math.pi * ang
    c, s = math.cos(theta), math.sin(theta)
    half = side / 2.0
    # Corners relative to center
    corners = [(-half, -half), (half, -half), (half, half), (-half, half)]
    vertices = []
    for x, y in corners:
        rx = x*c - y*s + cx
        ry = x*s + y*c + cy
        vertices.append(np.array([rx, ry]))
    return vertices

def _resolve_overlaps(squares):
    # Simple iterative shrinking to remove overlaps
    squares = [list(s) for s in squares]
    n = len(squares)
    for _ in range(100):
        any_overlap = False
        for i in range(n):
            for j in range(i+1, n):
                cx1, cy1, ang1, s1 = squares[i]
                cx2, cy2, ang2, s2 = squares[j]
                if s1 <= 0 or s2 <= 0:
                    continue
                overlap = _squares_overlap(cx1, cy1, ang1, s1, cx2, cy2, ang2, s2)
                if overlap > 1e-6:
                    any_overlap = True
                    # Shrink both by small factor
                    squares[i][3] *= 0.995
                    squares[j][3] *= 0.995
        if not any_overlap:
            break
    return squares

# Run a quick test if executed directly
if __name__ == "__main__":
    for n in range(1, 10):
        sol = solve(n)
        total = sum(s[3] for s in sol)
        print(f"n={n}, sum={total:.4f}, squares={len(sol)}")
