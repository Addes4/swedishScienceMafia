import math
import random
from typing import List, Tuple

# -------------------------------------------------------------------
# Geometry utilities
# -------------------------------------------------------------------

def _corners(cx: float, cy: float, ang: float, s: float) -> List[Tuple[float, float]]:
    """Return the four corners of a square, rotated by ``ang`` turns."""
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        xr = cx + x * ca - y * sa
        yr = cy + x * sa + y * ca
        out.append((xr, yr))
    return out


def _proj_interval(pts, ax, ay):
    vals = [x * ax + y * ay for x, y in pts]
    return min(vals), max(vals)


def _overlap_area(c1, c2, s1, s2) -> bool:
    """Return True if the two convex polygons overlap (interiors intersect)."""
    # Quick bounding circle test
    r1 = s1 * math.sqrt(2.0) * 0.5
    r2 = s2 * math.sqrt(2.0) * 0.5
    dx = c1[0] - c2[0]
    dy = c1[1] - c2[1]
    if dx * dx + dy * dy >= (r1 + r2) ** 2:
        return False

    # Separating axis theorem for convex polygons
    for pts in (c1, c2):
        n = len(pts)
        for i in range(n):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            # normal
            ax, ay = -ey, ex
            # Normalize (not strictly needed but helps numerical stability)
            ln = math.hypot(ax, ay)
            if ln < 1e-15:
                continue
            ax /= ln
            ay /= ln
            min1, max1 = _proj_interval(c1, ax, ay)
            min2, max2 = _proj_interval(c2, ax, ay)
            if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                return False  # gap -> no overlap
    return True


def _inside_unit(cx, cy, ang, s) -> bool:
    """Check whether the square is fully inside the unit square."""
    if s <= 0.0:
        return True
    pts = _corners(cx, cy, ang, s)
    for x, y in pts:
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


def _clamp_to_unit(cx, cy, ang, s):
    """Shift the square so that it lies inside the unit square (if possible)."""
    if s <= 0.0:
        return 0.5, 0.5, ang, s
    pts = _corners(cx, cy, ang, s)
    minx = min(p[0] for p in pts)
    maxx = max(p[0] for p in pts)
    miny = min(p[1] for p in pts)
    maxy = max(p[1] for p in pts)
    dx = 0.0
    if minx < 0.0:
        dx = -minx
    elif maxx > 1.0:
        dx = 1.0 - maxx
    dy = 0.0
    if miny < 0.0:
        dy = -miny
    elif maxy > 1.0:
        dy = 1.0 - maxy
    return cx + dx, cy + dy, ang, s


# -------------------------------------------------------------------
# Initial layout
# -------------------------------------------------------------------

def _initial_layout(n: int):
    """Return a list of (cx, cy, ang, s) squares with non-overlapping interiors."""
    # Start from a grid: rows x cols
    cols = max(1, int(math.sqrt(n)))
    rows = (n + cols - 1) // cols

    # Try to fit a grid with reasonable margins
    margin = 0.02
    max_s = min((1.0 - 2.0 * margin) / cols, (1.0 - 2.0 * margin) / rows)

    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            sx = margin + (c + 0.5) * (1.0 - 2.0 * margin) / cols
            sy = margin + (r + 0.5) * (1.0 - 2.0 * margin) / rows
            squares.append([sx, sy, 0.0, max_s])
            idx += 1
        if idx >= n:
            break

    # Random slight perturbation to break symmetry
    for sq in squares[:n]:
        sq[0] = min(1.0, max(0.0, sq[0] + random.uniform(-0.01, 0.01)))
        sq[1] = min(1.0, max(0.0, sq[1] + random.uniform(-0.01, 0.01)))
        sq[2] = random.uniform(0.0, 1.0)

    # Ensure all are inside and non-overlapping (shrink if needed)
    _resolve_overlaps(squares, max_iter=200)

    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])

    return squares[:n]


# -------------------------------------------------------------------
# Overlap resolution
# -------------------------------------------------------------------

def _resolve_overlaps(squares, max_iter=100):
    """Iteratively shrink/move squares to remove overlaps."""
    n = len(squares)
    for _ in range(max_iter):
        changed = False
        # Check all pairs
        for i in range(n):
            ci = squares[i]
            if ci[3] <= 0:
                continue
            ci_corners = _corners(ci[0], ci[1], ci[2], ci[3])
            for j in range(i + 1, n):
                cj = squares[j]
                if cj[3] <= 0:
                    continue
                cj_corners = _corners(cj[0], cj[1], cj[2], cj[3])
                if _overlap_area(ci_corners, cj_corners, ci[3], cj[3]):
                    # Push apart along centre line
                    dx = ci[0] - cj[0]
                    dy = ci[1] - cj[1]
                    dist = math.hypot(dx, dy)
                    if dist < 1e-9:
                        ang = random.uniform(0, 2 * math.pi)
                        dx = math.cos(ang)
                        dy = math.sin(ang)
                        dist = 1.0
                    # Move both
                    push = 0.001 + 0.5 * min(ci[3], cj[3])
                    ci[0] += (dx / dist) * push
                    ci[1] += (dy / dist) * push
                    cj[0] -= (dx / dist) * push
                    cj[1] -= (dy / dist) * push
                    # Shrink slightly
                    shrink = 0.999
                    if ci[3] > 0:
                        ci[3] *= shrink
                    if cj[3] > 0:
                        cj[3] *= shrink
                    changed = True

            # Clamp inside
            ci[0], ci[1], ci[2], ci[3] = _clamp_to_unit(ci[0], ci[1], ci[2], ci[3])

        if not changed:
            break


# -------------------------------------------------------------------
# Main solver
# -------------------------------------------------------------------

def solve(n: int):
    """Return n squares maximising the sum of side lengths."""
    if n <= 0:
        return []

    # For very small n, direct known optimal or near-optimal
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # Two squares side by side, each 0.5
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    # Use a physics-inspired optimization
    squares = _initial_layout(n)

    # Number of optimization iterations
    iterations = min(800, 200 + n * 8)

    # Temperature for simulated-annealing style perturbations
    temp = 0.02
    best_squares = [sq[:] for sq in squares]
    best_score = sum(sq[3] for sq in squares)

    # Precompute pair indices for efficiency
    import itertools
    pairs = list(itertools.combinations(range(n), 2))

    for it in range(iterations):
        # Grow all squares slightly
        grow = 0.002 + 0.005 * (1.0 - it / iterations)
        for sq in squares:
            if sq[3] > 0:
                sq[3] = min(sq[3] * (1.0 + grow), 1.0)

        # Move each square slightly (attraction to centre)
        for sq in squares:
            if sq[3] > 0:
                sq[0] += (0.5 - sq[0]) * random.uniform(0.0005, 0.002)
                sq[1] += (0.5 - sq[1]) * random.uniform(0.0005, 0.002)
                sq[2] = (sq[2] + random.uniform(-0.01, 0.01)) % 1.0

        # Resolve overlaps
        _resolve_overlaps(squares, max_iter=50)

        # Clamp to unit
        for sq in squares:
            sq[0], sq[1], sq[2], sq[3] = _clamp_to_unit(sq[0], sq[1], sq[2], sq[3])

        # Evaluate
        current_score = sum(sq[3] for sq in squares)

        # Accept if better, or occasionally if worse (simulated annealing)
        if current_score > best_score:
            best_score = current_score
            best_squares = [sq[:] for sq in squares]
        else:
            # Sometimes revert to best
            if random.random() < 0.3:
                squares = [sq[:] for sq in best_squares]

        # Adaptive temperature
        temp *= 0.999

    # Final polish: try to expand each square individually
    _final_polish(best_squares)

    # Ensure all squares are inside unit and non-overlapping
    _resolve_overlaps(best_squares, max_iter=500)
    for sq in best_squares:
        sq[0], sq[1], sq[2], sq[3] = _clamp_to_unit(sq[0], sq[1], sq[2], sq[3])

    # Convert to required format
    result = []
    for cx, cy, ang, s in best_squares:
        # Clamp values to [0,1] as required
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = min(1.0, max(0.0, s))
        result.append((cx, cy, ang, s))

    return result[:n]


def _final_polish(squares):
    """Greedily try to increase each square's size while avoiding overlaps."""
    n = len(squares)
    order = list(range(n))
    # Sort by current size (smaller first for more improvement potential)
    order.sort(key=lambda i: squares[i][3])

    for _ in range(3):
        for i in order:
            if squares[i][3] <= 0:
                continue
            # Try growing this square
            original = squares[i][:]

            # Test growth
            growth_factor = 1.0
            test_size = squares[i][3] * 1.05
            if test_size > 1.0:
                test_size = 1.0

            # Temporarily set larger
            squares[i][3] = test_size
            # Check overlaps with others
            valid = True
            ci_corners = _corners(squares[i][0], squares[i][1], squares[i][2], squares[i][3])
            for j in range(n):
                if j == i or squares[j][3] <= 0:
                    continue
                cj_corners = _corners(squares[j][0], squares[j][1], squares[j][2], squares[j][3])
                if _overlap_area(ci_corners, cj_corners, squares[i][3], squares[j][3]):
                    valid = False
                    break
                # Also check inside unit
            if valid and _inside_unit(squares[i][0], squares[i][1], squares[i][2], squares[i][3]):
                # Accept growth
                pass
            else:
                # Revert
                squares[i] = original

    # Try shifting to increase sizes
    for i in range(n):
        if squares[i][3] <= 0:
            continue
        best_pos = squares[i][:]
        best_s = squares[i][3]
        # Try small shifts
        for _ in range(20):
            dx = random.uniform(-0.02, 0.02)
            dy = random.uniform(-0.02, 0.02)
            new_cx = squares[i][0] + dx
            new_cy = squares[i][1] + dy
            if new_cx < 0 or new_cx > 1 or new_cy < 0 or new_cy > 1:
                continue
            # Check inside and overlap
            if not _inside_unit(new_cx, new_cy, squares[i][2], best_s):
                continue
            ci_corners = _corners(new_cx, new_cy, squares[i][2], best_s)
            valid = True
            for j in range(n):
                if j == i or squares[j][3] <= 0:
                    continue
                cj_corners = _corners(squares[j][0], squares[j][1], squares[j][2], squares[j][3])
                if _overlap_area(ci_corners, cj_corners, best_s, squares[j][3]):
                    valid = False
                    break
            if valid:
                squares[i][0] = new_cx
                squares[i][1] = new_cy
                break
