# EVOLVE-BLOCK-START
"""Squares in a square: heuristic packing + local optimization.

We build a good initial packing, then repeatedly try to increase total side length
by perturbing individual squares and verifying all non-overlap constraints exactly
enough for the required scoring.  The implementation uses only the standard
library and numpy (scipy is allowed but not needed).
"""

from __future__ import annotations

import math
import random
from typing import List, Tuple

try:
    import numpy as np
except Exception:  # pragma: no cover
    np = None

Square = Tuple[float, float, float, float]  # cx, cy, angle, side


# ---------------------------------------------------------------------------
# Geometry: convex polygon overlap test for two rectangles (rotated squares)
# ---------------------------------------------------------------------------

def _corners(cx: float, cy: float, ang: float, s: float) -> List[Tuple[float, float]]:
    """Corners of a square with centre (cx,cy), angle fraction of a turn."""
    if s <= 0.0:
        return []
    h = 0.5 * s
    th = ang * 2.0 * math.pi
    ca = math.cos(th)
    sa = math.sin(th)
    # local corner offsets (+-h, +-h), rotated
    loc = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in loc:
        out.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
    return out


def _project(poly: List[Tuple[float, float]], nx: float, ny: float) -> Tuple[float, float]:
    d = nx * poly[0][0] + ny * poly[0][1]
    lo = hi = d
    for x, y in poly[1:]:
        d = nx * x + ny * y
        if d < lo:
            lo = d
        elif d > hi:
            hi = d
    return lo, hi


def _overlap_poly(a: List[Tuple[float, float]], b: List[Tuple[float, float]]) -> bool:
    """Exact SAT for convex polygons."""
    if not a or not b:
        return False
    # axes from both polygons
    for poly in (a, b):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex = x2 - x1
            ey = y2 - y1
            nx, ny = -ey, ex
            if nx == 0.0 and ny == 0.0:
                continue
            lo1, hi1 = _project(a, nx, ny)
            lo2, hi2 = _project(b, nx, ny)
            if hi1 < lo2 or hi2 < lo1:
                return False
    return True


def _inside_square(cx: float, cy: float, ang: float, s: float, eps: float = 1e-12) -> bool:
    if s <= 0.0:
        return True
    for x, y in _corners(cx, cy, ang, s):
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


# ---------------------------------------------------------------------------
# Basic feasibility at the level of full list
# ---------------------------------------------------------------------------

def _valid(squares: List[Square]) -> bool:
    polys = []
    for q in squares:
        cx, cy, ang, s = q
        if not _inside_square(cx, cy, ang, s):
            return False
        p = _corners(cx, cy, ang, s)
        for r in polys:
            if _overlap_poly(p, r):
                return False
        polys.append(p)
    return True


# ---------------------------------------------------------------------------
# Initial constructions
# ---------------------------------------------------------------------------

def _grid(k: int) -> List[Square]:
    if k <= 0:
        return []
    side = 1.0 / k
    return [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]


def _nice_initial(n: int) -> List[Square]:
    """Start from a grid that leaves a bit of room for extra squares."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # choose grid size so we have n - k^2 leftovers for a strip
    best = None
    for k in range(1, int(math.isqrt(n)) + 1):
        m = k * k
        if m > n:
            continue
        rem = n - m
        # capacity of a strip if we steal fraction t from grid cell size
        # crude estimate: worth trying several k
        for t in (0.0, 0.08, 0.14, 0.20, 0.26, 0.32):
            if t >= 1.0:
                continue
            gs = (1.0 - t) / k
            strip_w = 1.0 - gs * k  # unused width/height in the strip
            if strip_w <= 1e-12:
                continue
            # if rem squares are put in a vertical strip of width strip_w and height 1
            # each could have side ~ strip_w (rotated 45 deg gives at most strip_w*? )
            # rough capacity estimate:
            cap = int(math.floor(strip_w / (strip_w + 1e-9) * (1.0 / strip_w))) if strip_w > 0 else 0
            if rem <= cap + 4:
                cand = k
                if best is None or cand > best[0]:
                    best = (k, t)
    if best is None:
        k = int(math.isqrt(n))
        return _grid(k) + [(0.5, 0.5, 0.0, 0.0)] * (n - k * k)

    k, t = best
    gs = (1.0 - t) / k
    squares = _grid(k)
    # shrink grid squares
    squares = [((x - 0.5) * (gs / (1.0 / k)) + 0.5, (y - 0.5) * (gs / (1.0 / k)) + 0.5, 0.0, gs)
               for (x, y, a, s) in squares]
    # place leftovers greedily in the right-most strip [k*gs, 1] x [0,1]
    left = n - len(squares)
    if left > 0:
        x0 = k * gs
        w = 1.0 - x0
        # fill a column of squares of side w, rotated 0, stacked
        m = int(math.floor(1.0 / w)) if w > 0 else 0
        for i in range(min(left, m)):
            cy = (i + 0.5) * w
            squares.append((x0 + 0.5 * w, cy, 0.0, w))
            left -= 1
        if left > 0:
            # remaining in bottom strip
            y0 = 0.0
            h = x0  # available height under grid if we use bottom strip
            m2 = int(math.floor(x0 / w)) if w > 0 else 0
            for i in range(min(left, m2)):
                cx = (i + 0.5) * w
                squares.append((cx, 0.5 * w, 0.0, w))
                left -= 1
    while left > 0:
        squares.append((0.5, 0.5, 0.0, 0.0))
        left -= 1
    return squares[:n]


# ---------------------------------------------------------------------------
# Objective and local search
# ---------------------------------------------------------------------------

def _total(squares: List[Square]) -> float:
    return sum(max(0.0, q[3]) for q in squares)


def _clamp_square(q: Square) -> Square:
    cx, cy, ang, s = q
    if s < 0.0:
        s = 0.0
    ang = ang % 1.0
    # clamp centre so corners may fit: use conservative bounds by scaling square
    # find max centre displacement allowed: just clamp centre to [0,1] and let check reject
    cx = min(1.0, max(0.0, cx))
    cy = min(1.0, max(0.0, cy))
    return (cx, cy, ang, s)


def _try_set(squares: List[Square], idx: int, cand: Square, others: List[List[Tuple[float, float]]]) -> bool:
    """Check candidate at idx against all others by polygon SAT."""
    cx, cy, ang, s = cand
    if not _inside_square(cx, cy, ang, s):
        return False
    p = _corners(cx, cy, ang, s)
    for j, op in enumerate(others):
        if j == idx:
            continue
        # others includes old idx too; skip
        if _overlap_poly(p, op):
            return False
    return True


def _optimize(squares: List[Square], time_budget: float = 4.0, seed: int = 12345, rng: random.Random | None = None) -> List[Square]:
    import time
    if rng is None:
        rng = random.Random(seed)
    start = time.time()
    n = len(squares)
    if n == 0:
        return squares

    squares = [(_clamp_square(q)) for q in squares]
    # ensure validity; if invalid, nudge not attempted
    if not _valid(squares):
        # fall back: shrink invalid squares
        for _ in range(50):
            ok = True
            for i in range(n):
                if not _valid(squares):
                    cx, cy, ang, s = squares[i]
                    squares[i] = (cx, cy, ang, max(0.0, s * 0.95))
                    ok = False
                    break
            if ok:
                break
        if not _valid(squares):
            squares = [(0.5, 0.5, 0.0, 0.0)] * n

    best = list(squares)
    best_val = _total(best)

    # cache polygons
    polys = [_corners(*q) for q in best]

    steps = 0
    while time.time() - start < time_budget:
        steps += 1
        i = rng.randrange(n)
        cx, cy, ang, s = best[i]

        # choose a move type
        r = rng.random()
        if r < 0.55:
            # try increase size
            grow = 1.0 + rng.uniform(0.002, 0.08)
            ns = s * grow
            if ns <= 0.0:
                ns = 0.0
            # also shift to help
            ncx = cx + rng.uniform(-0.01, 0.01)
            ncy = cy + rng.uniform(-0.01, 0.01)
            nang = ang + rng.uniform(-0.03, 0.03)
            cand = _clamp_square((ncx, ncy, nang, ns))
        elif r < 0.8:
            # rotate
            nang = ang + rng.uniform(-0.06, 0.06)
            ns = s * (1.0 + rng.uniform(0.0, 0.03))
            cand = _clamp_square((cx, cy, nang, ns))
        else:
            # shift
            ncx = cx + rng.uniform(-0.04, 0.04)
            ncy = cy + rng.uniform(-0.04, 0.04)
            ns = s * (1.0 + rng.uniform(0.0, 0.04))
            cand = _clamp_square((ncx, ncy, ang, ns))

        # quick reject: candidate total not worse
        if cand[3] <= s - 1e-15 and abs(cand[0] - cx) + abs(cand[1] - cy) + abs(cand[2] - ang) < 1e-12:
            continue

        if _try_set(best, i, cand, polys):
            best[i] = cand
            polys[i] = _corners(*cand)
            nv = best_val - s + cand[3]
            best_val = nv

    # final cleanup: if any tiny violation remains, shrink to be safe
    if not _valid(best):
        for _ in range(200):
            changed = False
            for i in range(n):
                if not _valid(best):
                    cx, cy, ang, s = best[i]
                    best[i] = (cx, cy, ang, s * 0.999)
                    changed = True
            if not changed or _valid(best):
                break
        if not _valid(best):
            best = [(_clamp_square((0.5, 0.5, 0.0, 0.0))) for _ in range(n)]
    return best


# ---------------------------------------------------------------------------
# Multi-start driver
# ---------------------------------------------------------------------------

def solve(n: int) -> List[Square]:
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    # Trivial exact cases
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two equal squares side 0.5
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three squares: 2x2 grid minus one cell, then enlarge one? Use one big + two small.
        # Big square side 0.5 at top-left. Remaining L-shape: place two squares side 0.5
        # stacked in the right column and one in bottom-left.  This gives 3 * 0.5 = 1.5.
        return [(0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5), (0.25, 0.25, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    import time
    deadline = time.time() + 52.0  # keep under 60 s

    # Initial attempts
    inits = []
    inits.append(_nice_initial(n))
    # also try pure square grids with size 0 squares for remainder
    k = int(math.isqrt(n))
    inits.append(_grid(k) + [(0.5, 0.5, 0.0, 0.0)] * (n - k * k))
    # try slightly different k
    for kk in range(max(1, k - 3), min(n, k + 4) + 1):
        if kk * kk <= n:
            inits.append(_grid(kk) + [(0.5, 0.5, 0.0, 0.0)] * (n - kk * kk))

    best = None
    best_val = -1.0

    # multi-start with different seeds and increasing time slices
    trials = 0
    while time.time() < deadline:
        trials += 1
        init = inits[(trials - 1) % len(inits)]
        # randomise slightly
        rng = random.Random(trials * 99991 + n)
        if trials > 1:
            # perturb sizes/positions of some squares while keeping validity
            cand = list(init)
            for _ in range(min(n * 2, 200)):
                i = rng.randrange(n)
                cx, cy, ang, s = cand[i]
                cx = min(1.0, max(0.0, cx + rng.uniform(-0.03, 0.03)))
                cy = min(1.0, max(0.0, cy + rng.uniform(-0.03, 0.03)))
                ang = (ang + rng.uniform(-0.05, 0.05)) % 1.0
                ns = max(0.0, s * (1.0 + rng.uniform(-0.03, 0.06)))
                q = (cx, cy, ang, ns)
                trial = list(cand)
                trial[i] = q
                if _valid(trial):
                    cand = trial
            init = cand

        remaining = deadline - time.time()
        if remaining <= 0:
            break
        # use a chunk of time per start
        budget = min(3.0, max(0.5, remaining / 5.0))
        res = _optimize(init, time_budget=budget, seed=trials, rng=rng)
        val = _total(res)
        if val > best_val + 1e-12:
            best_val = val
            best = res

        if time.time() >= deadline:
            break

    if best is None:
        best = _nice_initial(n)

    # Final validity guarantee
    if not _valid(best):
        # attempt repair by shrinking offending squares
        for _ in range(500):
            if _valid(best):
                break
            for i in range(n):
                cx, cy, ang, s = best[i]
                best[i] = (cx, cy, ang, s * 0.99)
        if not _valid(best):
            best = [(_clamp_square(q)) for q in best]
            # brute fallback to grid
            k = int(math.isqrt(n))
            best = _grid(k) + [(0.5, 0.5, 0.0, 0.0)] * (n - k * k)

    # ensure list length n and format
    out: List[Square] = []
    for q in best[:n]:
        cx, cy, ang, s = q
        if s < 0.0:
            s = 0.0
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        out.append((cx, cy, ang, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out


# ---------------------------------------------------------------------------
# Optional local testing hook (not used by judge)
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    for nn in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 16, 20, 25, 30]:
        sq = solve(nn)
        print(nn, _total(sq), _valid(sq))
# EVOLVE-BLOCK-END
