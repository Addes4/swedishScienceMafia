import math
import random
import time


def _overlap(a, b):
    # separating axis theorem for two rotated squares
    ax, ay, aa, asz = a
    bx, by, ba, bsz = b
    ca, sa = math.cos(aa * 2 * math.pi), math.sin(aa * 2 * math.pi)
    cb, sb = math.cos(ba * 2 * math.pi), math.sin(ba * 2 * math.pi)

    # axis-aligned local corners relative to center
    ha = asz * 0.5
    hb = bsz * 0.5

    # corners of a
    ac = []
    for dx, dy in ((-ha, -ha), (ha, -ha), (ha, ha), (-ha, ha)):
        ac.append((ax + dx * ca - dy * sa, ay + dx * sa + dy * ca))

    axes = []
    # normals for a's edges
    for i in range(4):
        x1, y1 = ac[i]
        x2, y2 = ac[(i + 1) % 4]
        ex, ey = x2 - x1, y2 - y1
        axes.append((-ey, ex))
    # normals for b's edges
    for dx, dy in ((-1, 0), (0, -1), (1, 0), (0, 1)):
        nx = dx * cb - dy * sb
        ny = dx * sb + dy * cb
        axes.append((nx, ny))

    for nx, ny in axes:
        nlen = math.hypot(nx, ny)
        if nlen == 0:
            continue
        nx /= nlen
        ny /= nlen

        mina = min(x * nx + y * ny for x, y in ac)
        maxa = max(x * nx + y * ny for x, y in ac)

        bc = []
        for dx, dy in ((-hb, -hb), (hb, -hb), (hb, hb), (-hb, hb)):
            bc.append((bx + dx * cb - dy * sb, by + dx * sb + dy * cb))

        minb = min(x * nx + y * ny for x, y in bc)
        maxb = max(x * nx + y * ny for x, y in bc)

        if maxa <= minb or maxb <= mina:
            return False
    return True


def _inside(ax, ay, aa, asz):
    ca, sa = math.cos(aa * 2 * math.pi), math.sin(aa * 2 * math.pi)
    h = asz * 0.5
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = ax + dx * ca - dy * sa
        y = ay + dx * sa + dy * ca
        if x < -1e-12 or x > 1 + 1e-12 or y < -1e-12 or y > 1 + 1e-12:
            return False
    return True


def solve(n):
    if n <= 0:
        return []

    # Start with a reasonably good grid-based layout: largest integer grid.
    k = max(1, math.isqrt(n))
    grid_side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) < n:
                squares.append([(i + 0.5) * grid_side, (j + 0.5) * grid_side, 0.0, grid_side])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])

    # Try several random restarts and keep the best.
    best = [tuple(s) for s in squares]
    best_score = sum(s[3] for s in squares)

    rng = random.Random(12345)
    deadline = time.time() + 55.0

    attempts = 0
    while time.time() < deadline:
        attempts += 1

        # Build a new candidate by greedy growth from random order insertions.
        # Permute ordering, then for each square start small and grow.
        order = list(range(n))
        rng.shuffle(order)

        cand = [None] * n
        placed = []

        for idx in order:
            # Try a few random positions/angles and pick the largest that fits.
            best_local = -1.0
            best_state = (0.5, 0.5, 0.0, 0.0)

            trials = 12
            for _ in range(trials):
                x = rng.random()
                y = rng.random()
                angle = rng.choice([0.0, 0.25, 0.125, 0.0625, rng.random()])
                # Binary search for max size at this pose.
                lo, hi = 0.0, 1.0
                for _ in range(24):
                    mid = (lo + hi) * 0.5
                    if _inside(x, y, angle, mid) and all(
                        not _overlap((x, y, angle, mid), p) for p in placed
                    ):
                        lo = mid
                    else:
                        hi = mid
                if lo > best_local:
                    best_local = lo
                    best_state = (x, y, angle, lo)

            # Additionally, try to grow from the center pose.
            x, y, angle = 0.5, 0.5, 0.0
            lo, hi = 0.0, 1.0
            for _ in range(24):
                mid = (lo + hi) * 0.5
                if _inside(x, y, angle, mid) and all(
                    not _overlap((x, y, angle, mid), p) for p in placed
                ):
                    lo = mid
                else:
                    hi = mid
            if lo > best_local:
                best_local = lo
                best_state = (x, y, angle, lo)

            cand[idx] = best_state
            placed.append(best_state)

        score = sum(s[3] for s in cand)
        if score > best_score:
            best_score = score
            best = [tuple(s) for s in cand]

        if time.time() >= deadline:
            break

    # Light local refinement: try shrinking none, just jiggle positions and sizes.
    improved = True
    while improved and time.time() < deadline:
        improved = False
        for i in range(n):
            xi, yi, ai, si = best[i]
            for _ in range(6):
                dx = (rng.random() - 0.5) * 0.03
                dy = (rng.random() - 0.5) * 0.03
                da = (rng.random() - 0.5) * 0.05
                nx = min(1.0, max(0.0, xi + dx))
                ny = min(1.0, max(0.0, yi + dy))
                na = (ai + da) % 1.0
                if not _inside(nx, ny, na, si):
                    continue
                ok = True
                for j in range(n):
                    if i == j:
                        continue
                    if _overlap((nx, ny, na, si), best[j]):
                        ok = False
                        break
                if ok:
                    best[i] = (nx, ny, na, si)
                    xi, yi, ai = nx, ny, na
                    improved = True

    return [tuple(s) for s in best]
