import math
import random
import numpy as np

# ---------- geometry helpers ----------
def corners(cx, cy, a, s):
    """Return the 4 corners of a square rotated by a (fraction of full turn)."""
    t = 2.0 * math.pi * a
    c, sn = math.cos(t), math.sin(t)
    h = s * 0.5
    # local corners before rotation
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + x * c - y * sn, cy + x * sn + y * c))
    return out

def proj(cx, cy, a, s):
    """Axis-aligned bounding box of a rotated square: (xmin, xmax, ymin, ymax)."""
    t = 2.0 * math.pi * a
    c, sn = abs(math.cos(t)), abs(math.sin(t))
    h = s * 0.5
    ex = h * (c + sn)
    ey = h * (c + sn)
    return cx - ex, cx + ex, cy - ey, cy + ey

def inside(cx, cy, a, s, eps=1e-12):
    xmin, xmax, ymin, ymax = proj(cx, cy, a, s)
    return xmin >= -eps and xmax <= 1.0 + eps and ymin >= -eps and ymax <= 1.0 + eps

def overlap(sq1, sq2, eps=1e-10):
    """True if interiors of two squares overlap (SAT)."""
    _, _, _, s1 = sq1
    _, _, _, s2 = sq2
    if s1 <= eps or s2 <= eps:
        return False
    p1 = corners(*sq1)
    p2 = corners(*sq2)
    # edges normals
    polys = [p1, p2]
    for poly in polys:
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            nx, ny = -(y2 - y1), (x2 - x1)
            # project both
            def pr(pp):
                vals = [px * nx + py * ny for px, py in pp]
                return min(vals), max(vals)
            a1, b1 = pr(p1)
            a2, b2 = pr(p2)
            if b1 <= a2 + eps or b2 <= a1 + eps:
                return False  # separating axis found
    return True

# ---------- constructions ----------
def grid(k, n):
    """k x k grid of equal squares, rest size zero."""
    s = 1.0 / k
    out = [((i + 0.5) * s, (j + 0.5) * s, 0.0, s) for i in range(k) for j in range(k)]
    out += [(0.5, 0.5, 0.0, 0.0)] * (n - len(out))
    return out[:n]

def rows_and_cols(n):
    """Try all splits n = a*b + c where c rows/cols adapt."""
    best = None
    best_val = -1.0
    for a in range(1, n + 1):
        b = n // a
        rem = n - a * b
        # a columns, b rows in main block, plus rem extra in a partial row/column
        # Build a tight packing: a columns of width 1/a, b+1 rows, last row only 'rem' cells
        if b == 0:
            continue
        total_rows = b + (1 if rem > 0 else 0)
        cell_h = 1.0 / total_rows
        cell_w = 1.0 / a
        side = min(cell_w, cell_h)
        cnt = 0
        out = []
        for r in range(b):
            for c in range(a):
                if cnt >= n:
                    break
                out.append(((c + 0.5) * cell_w, (r + 0.5) * cell_h, 0.0, side))
                cnt += 1
        if rem > 0:
            r = b
            for c in range(rem):
                if cnt >= n:
                    break
                out.append(((c + 0.5) * cell_w, (r + 0.5) * cell_h, 0.0, side))
                cnt += 1
        while len(out) < n:
            out.append((0.5, 0.5, 0.0, 0.0))
        val = sum(x[3] for x in out)
        if val > best_val:
            best_val = val
            best = out
    return best

def guillotine(n, depth=0):
    """Recursive guillotine cut packing."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    best = None
    best_val = -1.0
    # split into two parts with the cut along either axis
    for k in range(1, n):
        left = guillotine(k, depth + 1)
        right = guillotine(n - k, depth + 1)
        # try horizontal cut (stack vertically)
        # left gets height h, right gets 1-h, widths full
        for h in (0.5,):
            for orient in (0, 1):
                if orient == 0:
                    # vertical cut: left column width w, right column width 1-w
                    # scale left to fit w x 1, right to (1-w) x 1
                    for wcand in (0.5,):
                        w = wcand
                        L = [(cx * w, cy, a, s * min(w, 1.0)) for (cx, cy, a, s) in left]
                        R = [(w + cx * (1 - w), cy, a, s * min(1 - w, 1.0)) for (cx, cy, a, s) in right]
                        out = L + R
                        # fix: scaling by min(w,1) and min(1-w,1) may not guarantee fit; just use construction quality
                        val = sum(x[3] for x in out)
                        if val > best_val:
                            best_val = val
                            best = out
                else:
                    # horizontal cut
                    h = 0.5
                    B = [(cx, cy * h, a, s * min(h, 1.0)) for (cx, cy, a, s) in left]
                    T = [(cx, h + cy * (1 - h), a, s * min(1 - h, 1.0)) for (cx, cy, a, s) in right]
                    out = B + T
                    val = sum(x[3] for x in out)
                    if val > best_val:
                        best_val = val
                        best = out
    return best

def recursive_best(n):
    """Combine several constructions."""
    cands = []
    k = math.isqrt(n)
    for kk in range(max(1, k - 2), k + 3):
        if kk * kk <= n or kk * kk >= n:
            cands.append(grid(kk, n))
    cands.append(rows_and_cols(n))
    # try guillotine split into known good pieces
    for k in range(1, n):
        c1 = rows_and_cols(k)
        c2 = rows_and_cols(n - k)
        if c1 is None or c2 is None:
            continue
        # place side by side vertically
        for cut in (0.5,):
            L = [(cx * cut, cy, a, s * cut) for (cx, cy, a, s) in c1]
            R = [(cut + cx * (1 - cut), cy, a, s * (1 - cut)) for (cx, cy, a, s) in c2]
            cands.append(L + R)
            B = [(cx, cy * cut, a, s * cut) for (cx, cy, a, s) in c1]
            T = [(cx, cut + cy * (1 - cut), a, s * (1 - cut)) for (cx, cy, a, s) in c2]
            cands.append(B + T)
    best = None
    best_val = -1.0
    for c in cands:
        if c is None or len(c) != n:
            continue
        val = sum(x[3] for x in c)
        if val > best_val:
            best_val = val
            best = c
    return best

# ---------- local search ----------
def repair(squares, n):
    """Project into unit square and remove overlaps by shrinking."""
    sq = [list(s) for s in squares]
    # clamp inside
    for i in range(n):
        cx, cy, a, s = sq[i]
        xmin, xmax, ymin, ymax = proj(cx, cy, a, s)
        if xmin < 0:
            cx -= xmin
        if xmax > 1:
            cx -= (xmax - 1)
        if ymin < 0:
            cy -= ymin
        if ymax > 1:
            cy -= (ymax - 1)
        sq[i] = [cx, cy, a, s]
    # resolve overlaps by shrinking the smaller / later ones
    changed = True
    it = 0
    while changed and it < 50:
        changed = False
        it += 1
        for i in range(n):
            for j in range(i + 1, n):
                if overlap(tuple(sq[i]), tuple(sq[j])):
                    # shrink both slightly
                    sq[i][3] *= 0.98
                    sq[j][3] *= 0.98
                    changed = True
                    # clamp
                    for idx in (i, j):
                        cx, cy, a, s = sq[idx]
                        xmin, xmax, ymin, ymax = proj(cx, cy, a, s)
                        if xmin < 0:
                            sq[idx][0] -= xmin
                        if xmax > 1:
                            sq[idx][0] -= (xmax - 1)
                        if ymin < 0:
                            sq[idx][1] -= ymin
                        if ymax > 1:
                            sq[idx][1] -= (ymax - 1)
    return [tuple(x) for x in sq]

def local_search(init, n, time_budget=15.0):
    import time
    t0 = time.time()
    cur = [list(x) for x in init]
    cur_val = sum(x[3] for x in cur)
    best = [list(x) for x in cur]
    best_val = cur_val
    T0 = 0.2
    it = 0
    # anneal
    while time.time() - t0 < time_budget:
        it += 1
        T = T0 * (1.0 - (time.time() - t0) / time_budget) + 0.001
        # copy
        cand = [list(x) for x in cur]
        # choose one or two squares to perturb
        k = random.randint(1, min(4, n))
        for _ in range(k):
            i = random.randrange(n)
            cx, cy, a, s = cand[i]
            mode = random.random()
            if mode < 0.25:
                # jiggle position
                cx += random.gauss(0, 0.05)
                cy += random.gauss(0, 0.05)
                cx = min(max(cx, 0.0), 1.0)
                cy = min(max(cy, 0.0), 1.0)
            elif mode < 0.5:
                # jiggle angle
                a = random.random()
            else:
                # jiggle size
                s *= math.exp(random.gauss(0, 0.2))
                s = min(s, 1.0)
            cand[i] = [cx, cy, a, s]
        cand = repair(cand, n)
        val = sum(x[3] for x in cand)
        if val > cur_val or random.random() < math.exp((val - cur_val) / max(T, 1e-9)):
            cur = cand
            cur_val = val
            if val > best_val:
                best_val = val
                best = [list(x) for x in cand]
    return best

# ---------- main ----------
def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s), (0.25, 0.75, 0.0, s), (0.75, 0.75, 0.0, s)]

    best = recursive_best(n)
    if best is None:
        best = grid(math.isqrt(n), n)
    # refine with local search
    try:
        best = local_search(best, n, time_budget=20.0)
    except Exception:
        pass
    # ensure length n and values in bounds
    out = []
    for x in best:
        cx, cy, a, s = x
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        a = min(max(a, 0.0), 1.0)
        s = min(max(s, 0.0), 1.0)
        out.append((cx, cy, a, s))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]

if __name__ == "__main__":
    for n in range(1, 11):
        res = solve(n)
        print(n, sum(r[3] for r in res), len(res))
