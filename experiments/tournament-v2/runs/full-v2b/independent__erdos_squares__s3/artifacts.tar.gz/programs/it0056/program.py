import math
import random
from scipy.optimize import minimize


def _overlap(s1, s2):
    """Return True if two squares overlap in interior."""
    x1, y1, a1, L1 = s1
    x2, y2, a2, L2 = s2
    # Quick bounding circle test
    r1 = L1 * math.sqrt(2) / 2
    r2 = L2 * math.sqrt(2) / 2
    if (x1 - x2)**2 + (y1 - y2)**2 >= (r1 + r2)**2:
        return False
    # Use SAT with axes of both squares
    axes = []
    for a in (a1, a2):
        t = a * 2 * math.pi
        c = math.cos(t)
        s = math.sin(t)
        axes.append((c, s))
        axes.append((-s, c))
    for ax, ay in axes:
        # project square 1
        p1 = []
        for sx, sy in ((0.5, 0.5), (0.5, -0.5), (-0.5, 0.5), (-0.5, -0.5)):
            t = a1 * 2 * math.pi
            c = math.cos(t)
            s = math.sin(t)
            rx = sx * c - sy * s
            ry = sx * s + sy * c
            px = x1 + rx * L1
            py = y1 + ry * L1
            p1.append(px * ax + py * ay)
        p2 = []
        for sx, sy in ((0.5, 0.5), (0.5, -0.5), (-0.5, 0.5), (-0.5, -0.5)):
            t = a2 * 2 * math.pi
            c = math.cos(t)
            s = math.sin(t)
            rx = sx * c - sy * s
            ry = sx * s + sy * c
            px = x2 + rx * L2
            py = y2 + ry * L2
            p2.append(px * ax + py * ay)
        if min(p1) >= max(p2) - 1e-12 or min(p2) >= max(p1) - 1e-12:
            return False
    return True


def _total_side(squares):
    return sum(s[3] for s in squares)


def _feasible(squares, tol=1e-9):
    for i in range(len(squares)):
        x, y, a, L = squares[i]
        if L < tol:
            continue
        # inside unit square check (bounding box)
        t = a * 2 * math.pi
        c = abs(math.cos(t))
        s = abs(math.sin(t))
        half = (c + s) * L / 2
        if x - half < -tol or x + half > 1 + tol:
            return False
        if y - half < -tol or y + half > 1 + tol:
            return False
    for i in range(len(squares)):
        if squares[i][3] < tol:
            continue
        for j in range(i + 1, len(squares)):
            if squares[j][3] < tol:
                continue
            if _overlap(squares[i], squares[j]):
                return False
    return True


def _clamp_square(s):
    x, y, a, L = s
    a = a % 1.0
    t = a * 2 * math.pi
    c = abs(math.cos(t))
    s_ = abs(math.sin(t))
    half = (c + s_) * L / 2
    x = max(half, min(1 - half, x))
    y = max(half, min(1 - half, y))
    if half >= 0.5:
        L = 1.0 / (c + s_)
        half = (c + s_) * L / 2
        x = max(half, min(1 - half, x))
        y = max(half, min(1 - half, y))
    return (x, y, a, L)


def _penalty(squares):
    """Sum of overlaps + outside violations, to guide local search."""
    pen = 0.0
    for i in range(len(squares)):
        x, y, a, L = squares[i]
        if L < 1e-12:
            continue
        t = a * 2 * math.pi
        c = abs(math.cos(t))
        s = abs(math.sin(t))
        half = (c + s) * L / 2
        if x - half < 0:
            pen += (half - x) * 10
        if x + half > 1:
            pen += (x + half - 1) * 10
        if y - half < 0:
            pen += (half - y) * 10
        if y + half > 1:
            pen += (y + half - 1) * 10
    for i in range(len(squares)):
        if squares[i][3] < 1e-12:
            continue
        for j in range(i + 1, len(squares)):
            if squares[j][3] < 1e-12:
                continue
            s1 = squares[i]
            s2 = squares[j]
            # approximate overlap via centers and bounding circles
            r1 = s1[3] * math.sqrt(2) / 2
            r2 = s2[3] * math.sqrt(2) / 2
            d2 = (s1[0] - s2[0])**2 + (s1[1] - s2[1])**2
            if d2 < (r1 + r2)**2:
                # check actual overlap
                if _overlap(s1, s2):
                    # approximate overlap area
                    ov = max(0.0, (r1 + r2) - math.sqrt(d2))
                    pen += ov * 20
    return pen


def _objective(params, n):
    """params: flat list of 3*n values (x,y,angle) for non-zero squares, plus side lengths handled separately."""
    squares = []
    for i in range(n):
        x = params[4 * i]
        y = params[4 * i + 1]
        a = params[4 * i + 2]
        L = params[4 * i + 3]
        squares.append((x, y, a, max(0.0, L)))
    return -_total_side(squares) + _penalty(squares)


def _initial_grid(n):
    """Generate a reasonable initial packing."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    k = math.isqrt(n)
    best = None
    best_score = -1
    # Try various grid dimensions
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if rows * cols < n:
            continue
        # Fit rows x cols grid of equal squares
        side = min(1.0 / rows, 1.0 / cols)
        sq = []
        for i in range(rows):
            for j in range(cols):
                if len(sq) >= n:
                    break
                sq.append(((j + 0.5) * side, (i + 0.5) * side, 0.0, side))
            if len(sq) >= n:
                break
        score = sum(s[3] for s in sq)
        if score > best_score:
            best_score = score
            best = sq
    # Add zero-size fillers
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    # Center the grid if smaller
    if best[0][3] > 0:
        side = best[0][3]
        max_x = max(s[0] for s in best if s[3] > 0)
        min_x = min(s[0] for s in best if s[3] > 0)
        max_y = max(s[1] for s in best if s[3] > 0)
        min_y = min(s[1] for s in best if s[3] > 0)
        dx = 0.5 - (max_x + min_x) / 2
        dy = 0.5 - (max_y + min_y) / 2
        best = [(s[0] + dx, s[1] + dy, s[2], s[3]) for s in best]
        # re-clamp and shrink if needed
        for i, s in enumerate(best):
            best[i] = _clamp_square(s)
    return best


def _refine(squares, n, maxiter=500):
    """Local optimization of positions, angles, sizes."""
    # Only optimize non-zero squares
    idx = [i for i in range(n) if squares[i][3] > 1e-9]
    if not idx:
        return squares

    def unpack(params):
        sq = [list(s) for s in squares]
        for k, i in enumerate(idx):
            sq[i][0] = params[4 * k]
            sq[i][1] = params[4 * k + 1]
            sq[i][2] = params[4 * k + 2]
            sq[i][3] = max(0.0, params[4 * k + 3])
        return [tuple(s) for s in sq]

    def obj(params):
        sq = unpack(params)
        return -_total_side(sq) + _penalty(sq)

    x0 = []
    for i in idx:
        x0.extend([squares[i][0], squares[i][1], squares[i][2] % 1.0, squares[i][3]])

    # bounds
    bnds = []
    for i in idx:
        bnds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])

    try:
        res = minimize(obj, x0, method='L-BFGS-B', bounds=bnds,
                       options={'maxiter': maxiter, 'ftol': 1e-14, 'gtol': 1e-14})
        sq = unpack(res.x)
        # clamp and fix infeasibilities
        sq = _repair(sq)
        return sq
    except Exception:
        return squares


def _repair(squares):
    """Greedily shrink/separate overlapping squares and clamp to bounds."""
    n = len(squares)
    sq = [list(s) for s in squares]
    # clamp inside
    for i in range(n):
        sq[i] = list(_clamp_square(sq[i]))
    # try to resolve overlaps by shrinking smaller square / moving
    for _ in range(500):
        changed = False
        for i in range(n):
            if sq[i][3] < 1e-12:
                continue
            for j in range(i + 1, n):
                if sq[j][3] < 1e-12:
                    continue
                if _overlap(tuple(sq[i]), tuple(sq[j])):
                    # shrink the smaller one
                    if sq[i][3] <= sq[j][3]:
                        sq[i][3] *= 0.98
                    else:
                        sq[j][3] *= 0.98
                    changed = True
        for i in range(n):
            sq[i] = list(_clamp_square(tuple(sq[i])))
        if not changed:
            break
    return [tuple(s) for s in sq]


def _greedy_add(n, base_squares, attempts=20):
    """Try to add new squares in gaps using random placement + local refinement."""
    current = [list(s) for s in base_squares]
    score = sum(s[3] for s in current)
    for _ in range(attempts):
        best_new = None
        best_val = score
        for _ in range(300):
            # find a gap: random center
            cx = random.random()
            cy = random.random()
            a = random.random()
            # binary search largest side that fits
            lo, hi = 0.0, 0.7
            for _ in range(25):
                mid = (lo + hi) / 2
                ns = (cx, cy, a, mid)
                ns = _clamp_square(ns)
                ok = True
                if ns[3] > 1e-12:
                    for s in current:
                        if s[3] > 1e-12 and _overlap(tuple(s), ns):
                            ok = False
                            break
                if ok:
                    lo = mid
                else:
                    hi = mid
            if lo > 1e-9:
                candidate = _clamp_square((cx, cy, a, lo))
                val = score + candidate[3]
                if val > best_val:
                    # refine candidate and neighbors
                    trial = [list(s) for s in current]
                    # replace smallest zero or add
                    zero_idx = -1
                    for z in range(len(trial)):
                        if trial[z][3] < 1e-12:
                            zero_idx = z
                            break
                    if zero_idx >= 0:
                        trial[zero_idx] = list(candidate)
                    else:
                        # replace smallest
                        mi = min(range(len(trial)), key=lambda z: trial[z][3])
                        trial[mi] = list(candidate)
                    trial = _refine(trial, n, maxiter=200)
                    trial = _repair(trial)
                    v = sum(s[3] for s in trial)
                    if v > best_val:
                        best_val = v
                        best_new = trial
        if best_new is not None and best_val > score + 1e-8:
            current = best_new
            score = best_val
        else:
            break
    return [tuple(s) for s in current]


def _perturb(squares, n, strength=0.02):
    """Randomly perturb a packing."""
    new = []
    for s in squares:
        x, y, a, L = s
        if L > 1e-9 and random.random() < 0.7:
            x += random.gauss(0, strength)
            y += random.gauss(0, strength)
            a += random.gauss(0, strength)
            L *= max(0.5, 1.0 + random.gauss(0, strength * 0.5))
        new.append((x, y, a % 1.0, max(0.0, L)))
    return _repair(new)


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_score = -1.0

    # multiple restarts with different initial layouts
    for restart in range(5):
        if restart == 0:
            squares = _initial_grid(n)
        elif restart == 1:
            # slightly random grid
            squares = _initial_grid(n)
            squares = [_repair(_perturb(squares, n, 0.05)) for _ in range(1)][0]
        else:
            squares = _initial_grid(n)
            # randomize angles
            squares = [(s[0], s[1], random.random(), s[3]) for s in squares]
            squares = _repair(squares)

        # refine
        squares = _refine(squares, n, maxiter=300)
        squares = _repair(squares)

        # greedy add for zero squares
        if sum(1 for s in squares if s[3] > 1e-9) < n:
            squares = _greedy_add(n, squares, attempts=8)

        # local search with perturbation (simulated annealing style)
        for it in range(30):
            temp = 0.5 * (0.95 ** it)
            trial = _perturb(squares, n, 0.01 + temp * 0.05)
            trial = _refine(trial, n, maxiter=150)
            trial = _repair(trial)
            if sum(1 for s in trial if s[3] > 1e-9) < n:
                trial = _greedy_add(n, trial, attempts=3)
            ts = sum(s[3] for s in trial)
            cs = sum(s[3] for s in squares)
            if ts > cs or random.random() < math.exp((ts - cs) / max(temp, 1e-6)):
                squares = trial

        sc = sum(s[3] for s in squares)
        if sc > best_score:
            best_score = sc
            best = squares

    # final polish
    if best is not None:
        best = _refine(best, n, maxiter=500)
        best = _repair(best)
        if sum(1 for s in best if s[3] > 1e-9) < n:
            best = _greedy_add(n, best, attempts=10)
            best = _refine(best, n, maxiter=300)
            best = _repair(best)

    if best is None:
        best = _initial_grid(n)

    # ensure exactly n squares
    result = []
    for s in best[:n]:
        x, y, a, L = s
        L = max(0.0, L)
        # final clamp
        a = a % 1.0
        t = a * 2 * math.pi
        c = abs(math.cos(t))
        si = abs(math.sin(t))
        half = (c + si) * L / 2
        if half >= 0.5:
            L = 1.0 / (c + si)
            half = (c + si) * L / 2
        x = max(half, min(1 - half, x))
        y = max(half, min(1 - half, y))
        result.append((x, y, a, L))
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    return result[:n]
