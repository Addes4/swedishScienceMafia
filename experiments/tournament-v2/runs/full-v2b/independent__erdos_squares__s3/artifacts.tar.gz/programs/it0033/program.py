import math
import random
import time

try:
    import numpy as np
except Exception:
    np = None


def _rotated_square_corners(cx, cy, ang, s):
    """Return the 4 corners of a square with center (cx,cy), angle fraction, side s."""
    a = 2.0 * math.pi * ang
    ca = math.cos(a)
    sa = math.sin(a)
    h = 0.5 * s
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
    return out


def _project_polygon(corners, axis):
    """Project polygon corners onto axis (unit vector). Return (min,max)."""
    ax, ay = axis
    vals = [x * ax + y * ay for x, y in corners]
    return min(vals), max(vals)


def _sat_overlap(c1, c2):
    """Return True if two convex polygons overlap (positive area) using SAT."""
    polys = [c1, c2]
    for p in polys:
        n = len(p)
        for i in range(n):
            x1, y1 = p[i]
            x2, y2 = p[(i + 1) % n]
            ex = x2 - x1
            ey = y2 - y1
            # normal
            nx, ny = -ey, ex
            ln = math.hypot(nx, ny)
            if ln < 1e-15:
                continue
            nx /= ln
            ny /= ln
            mn1, mx1 = _project_polygon(c1, (nx, ny))
            mn2, mx2 = _project_polygon(c2, (nx, ny))
            if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
                return False
    return True


def _inside_unit(corners, eps=1e-9):
    for x, y in corners:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def _make_grid(n):
    """Initial packing: grid for the largest square, plus zero-size squares."""
    k = max(1, int(math.sqrt(n)))
    while k * k > n:
        k -= 1
    while (k + 1) * (k + 1) <= n:
        k += 1
    side = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    while len(res) < n:
        res.append([0.5, 0.5, 0.0, 0.0])
    return res[:n]


def _make_varied(n, rng):
    """A varied initial guess: some rows/cols with gaps for larger squares."""
    res = []
    # try several grid-like patterns
    best = None
    best_sum = -1.0
    for k in range(1, int(math.sqrt(n)) + 3):
        pattern = []
        # fill k x k grid, then distribute remaining in leftover strips
        side = 1.0 / k
        for i in range(k):
            for j in range(k):
                pattern.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
        rem = n - len(pattern)
        if rem < 0:
            continue
        # Put rem tiny squares in a row at bottom (zero size initially)
        for t in range(rem):
            u = (t + 0.5) / max(1, rem)
            pattern.append([u, 1e-6, 0.0, 0.0])
        if len(pattern) != n:
            continue
        s = _evaluate(pattern)
        if s > best_sum:
            best_sum = s
            best = pattern
    if best is None:
        best = _make_grid(n)
    # perturb slightly
    for p in best:
        p[0] += rng.uniform(-0.01, 0.01)
        p[1] += rng.uniform(-0.01, 0.01)
        p[0] = min(1.0, max(0.0, p[0]))
        p[1] = min(1.0, max(0.0, p[1]))
    return best


def _evaluate(state):
    return sum(p[3] for p in state)


def _clamp_state(state):
    for p in state:
        p[0] = min(1.0, max(0.0, p[0]))
        p[1] = min(1.0, max(0.0, p[1]))
        p[2] = p[2] % 1.0
        p[3] = max(0.0, min(1.0, p[3]))


def _is_feasible(state, eps=1e-10):
    corners = []
    for cx, cy, ang, s in state:
        if s <= eps:
            corners.append(None)
            continue
        c = _rotated_square_corners(cx, cy, ang, s)
        if not _inside_unit(c, 1e-8):
            return False
        corners.append(c)
    m = len(corners)
    for i in range(m):
        if corners[i] is None:
            continue
        for j in range(i + 1, m):
            if corners[j] is None:
                continue
            if _sat_overlap(corners[i], corners[j]):
                return False
    return True


def _max_side_at(state, idx, lo=0.0, hi=1.0, iters=22):
    """Maximum feasible side for square idx given others fixed, by bisection."""
    base = state[idx]
    cx, cy, ang, _ = base
    # quick upper bound by unit square constraints (rough)
    best = 0.0
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        trial = [cx, cy, ang, mid]
        # check inside
        c = _rotated_square_corners(cx, cy, ang, mid)
        if not _inside_unit(c, 1e-9):
            hi = mid
            continue
        ok = True
        for j, p in enumerate(state):
            if j == idx:
                continue
            if p[3] <= 1e-12:
                continue
            c2 = _rotated_square_corners(p[0], p[1], p[2], p[3])
            if _sat_overlap(c, c2):
                ok = False
                break
        if ok:
            best = mid
            lo = mid
        else:
            hi = mid
    return best


def _grow_greedy(state, rng, time_limit):
    """Iteratively try to grow each square as large as possible."""
    n = len(state)
    improved = True
    while improved and time.time() < time_limit:
        improved = False
        order = list(range(n))
        rng.shuffle(order)
        for idx in order:
            if time.time() > time_limit:
                break
            old = state[idx][3]
            ns = _max_side_at(state, idx, old, 1.0, 24)
            if ns > old + 1e-6:
                state[idx][3] = ns
                improved = True
    return state


def _local_relax(state, rng, time_limit):
    """Small random moves: try to improve total by perturbing positions/angles."""
    n = len(state)
    best = [list(p) for p in state]
    best_sum = _evaluate(best)

    # Try moving centers slightly to allow growth
    for _ in range(4000):
        if time.time() > time_limit:
            break
        i = rng.randrange(n)
        old = [state[i][0], state[i][1], state[i][2], state[i][3]]
        # small random displacement
        state[i][0] += rng.gauss(0, 0.01)
        state[i][1] += rng.gauss(0, 0.01)
        state[i][2] += rng.gauss(0, 0.02)
        _clamp_state([state[i]])
        # try shrink others slightly to fit
        if not _is_feasible(state):
            # undo
            state[i] = old
        else:
            # try grow
            ns = _max_side_at(state, i, state[i][3], 1.0, 20)
            if ns > state[i][3] + 1e-7:
                state[i][3] = ns
            s = _evaluate(state)
            if s > best_sum + 1e-9:
                best_sum = s
                best = [list(p) for p in state]
            else:
                # keep if not worse much (simulated-annealing-lite)
                if rng.random() < 0.02:
                    pass
                else:
                    state[i] = old
    return best


def _multi_start(n, time_limit):
    rng = random.Random(12345 + n)
    best = None
    best_sum = -1.0
    start = time.time()

    # deterministic start
    candidates = [_make_grid(n)]
    # a few random starts
    for _ in range(6):
        candidates.append(_make_varied(n, rng))

    for cand in candidates:
        if time.time() > time_limit:
            break
        state = [list(p) for p in cand]
        _clamp_state(state)
        # ensure feasible-ish
        state = _grow_greedy(state, rng, time.time() + 1.5)
        state = _local_relax(state, rng, time.time() + 2.0)
        s = _evaluate(state)
        if s > best_sum and _is_feasible(state):
            best_sum = s
            best = [list(p) for p in state]

    # if still no feasible, fall back to grid
    if best is None:
        best = _make_grid(n)
        best_sum = _evaluate(best)

    # final intensification
    state = [list(p) for p in best]
    while time.time() < time_limit:
        improved = _grow_greedy(state, rng, min(time.time() + 2.0, time_limit))
        state = _local_relax(state, rng, min(time.time() + 2.0, time_limit))
        s = _evaluate(state)
        if s > best_sum + 1e-8 and _is_feasible(state):
            best_sum = s
            best = [list(p) for p in state]
        else:
            # restart from best with perturbation
            state = [list(p) for p in best]
            for p in state:
                p[0] += rng.gauss(0, 0.005)
                p[1] += rng.gauss(0, 0.005)
                p[2] += rng.gauss(0, 0.01)
            _clamp_state(state)
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # time budget
    t_end = time.time() + 52.0

    # special exact-ish solutions for tiny n
    if n == 2:
        # two squares: each can be side 1/sqrt(2) rotated 45deg? No.
        # Two axis-aligned squares of side 0.5 fit side by side -> sum 1.
        # Better: two squares each side s rotated 45deg diagonally can overlap, but
        # two squares side 0.5 gives 1.0. Try s=0.5.
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    if n == 3:
        # 3 squares: one large plus two small. Try side 0.5 for two, and one 0.5? 
        # Actually 3 equal squares side 1/2? doesn't fit. Use 2x2 grid minus one.
        # side 1/2 for two, remaining strip.
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]

    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # For general n, run the optimizer.
    best = _multi_start(n, t_end)

    # verify / repair: if not feasible, fall back
    if not _is_feasible(best):
        best = _make_grid(n)

    # final safety clamp
    out = []
    for cx, cy, ang, s in best:
        cx = min(1.0, max(0.0, float(cx)))
        cy = min(1.0, max(0.0, float(cy)))
        ang = float(ang) % 1.0
        s = min(1.0, max(0.0, float(s)))
        out.append((cx, cy, ang, s))
    if not _is_feasible(out):
        return _make_grid(n)
    return out
