import math
import random
import time

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side by side, each 0.5
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # one row of three squares? Actually 3 in a row: 3 squares of side 1/3
        # but we can do better: two squares of side 1/2 and one small? no, 1/2+1/2=1 sum=1.0
        # three in a row: sum=1.0
        # Better: one large square and two small? Let's try 0.5, 0.5,? no room
        return [(1/6, 0.5, 0.0, 1/3), (0.5, 0.5, 0.0, 1/3), (5/6, 0.5, 0.0, 1/3)]
    if n == 4:
        # 2x2 grid side 0.5, sum = 2.0
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        # 2x2 grid + one small in remaining? no, better: 2 large + 3 small? 
        # Known: 5 squares: 0.5,0.5,0.5,? maybe 3 in row + 2 in row
        # Actually use grid 2x3 with 6 cells, drop one -> sum of 5 sides = 5*(1/3)=5/3~1.667
        # Alternative: 2x2 grid + 1 tiny? sum ~2.0 still if tiny=0
        # But can we fit 0.5,0.5,0.5,0.5 + something? no
        # Try: two columns: left column two squares of 0.5, right column three squares of 1/3
        # left: 0.5+0.5=1.0, right: 3*(1/3)=1.0, total=2.0, plus one more? n=5
        # Let's do: 0.5,0.5 in left, 0.333,0.333,0.333 in right -> 5 squares sum=2.0
        return [(0.25, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5),
                (0.833333, 0.166667, 0.0, 1/3), (0.833333, 0.5, 0.0, 1/3), (0.833333, 0.833333, 0.0, 1/3)]
    if n == 6:
        # 2x3 grid side 1/3, sum=2.0
        return [((i+0.5)/3, (j+0.5)/2, 0.0, 1/3) for i in range(3) for j in range(2)]
    if n == 7:
        # 7 squares: 3x3 grid minus 2 -> side 1/3, sum=7/3~2.333
        return [((i+0.5)/3, (j+0.5)/3, 0.0, 1/3) for i in range(3) for j in range(3)][:7]
    if n == 8:
        # 3x3 grid minus 1: side 1/3, sum=8/3~2.667
        return [((i+0.5)/3, (j+0.5)/3, 0.0, 1/3) for i in range(3) for j in range(3)][:8]
    if n == 9:
        # 3x3 grid side 1/3, sum=3.0
        return [((i+0.5)/3, (j+0.5)/3, 0.0, 1/3) for i in range(3) for j in range(3)]

    # general case: try a few strategies and pick best
    best_sum = -1.0
    best_sqs = None

    # Strategy 1: regular grid k x k where k = floor(sqrt(n))
    k = int(math.isqrt(n))
    s = 1.0 / k
    sqs = [((i+0.5)*s, (j+0.5)*s, 0.0, s) for i in range(k) for j in range(k)]
    # fill remaining with tiny squares in gaps? just zeros
    sqs += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sqs))
    sum1 = k * 1.0  # k*k squares each side s => k^2 * (1/k) = k
    if sum1 > best_sum:
        best_sum = sum1
        best_sqs = sqs[:n]

    # Strategy 2: use leftover row/column
    # e.g., k x k grid plus extra squares in a new row with smaller size
    if k*k < n:
        rem = n - k*k
        # try to fit rem squares in a strip of height h, width 1
        # if we add a row of rem squares each side (1/rem) but height must be <= remaining height
        # remaining height = 1 - k*s = 1 - k/k = 0 for k=floor sqrt, if n not square
        # Actually k=floor(sqrt(n)), then k*s = 1, so no space. So we need k smaller
        k2 = k
        if k2 > 0:
            # try k2 x k2 grid with side 1/k2, then leftover
            # but k2=k gives full coverage. Better: use k x k grid with side 1/(k+1)? 
            pass

    # Strategy 3: split into two rectangles recursively (simple)
    # for now just return grid
    if best_sqs is None:
        best_sqs = sqs[:n]
    return best_sqs
