import math
import random
import numpy as np

# ---------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------

def corners(cx, cy, ang, s):
    """Return the 4 corners of the square."""
    a = 2.0 * math.pi * ang
    c = math.cos(a)
    sn = math.sin(a)
    h = 0.5 * s
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + c * x - sn * y, cy + sn * x + c * y) for (x, y) in pts]


def separating_axis_overlap(c1, c2, ang1, ang2, s1, s2):
    """True if the two squares' interiors overlap."""
    # quick bounding circle test
    r1 = s1 * 0.5 * math.sqrt(2.0)
    r2 = s2 * 0.5 * math.sqrt(2.0)
    dx = c1[0] - c2[0]
    dy = c1[1] - c2[1]
    if dx * dx + dy * dy > (r1 + r2) ** 2:
        return False
    if s1 < 1e-12 or s2 < 1e-12:
        return False
    p1 = corners(c1[0], c1[1], ang1, s1)
    p2 = corners(c2[0], c2[1], ang2, s2)
    # SAT
    axes = []
    for i in range(4):
        j = (i + 1) % 4
        ex = p1[j][0] - p1[i][0]
        ey = p1[j][1] - p1[i][1]
        L = math.hypot(ex, ey)
        if L > 1e-15:
            axes.append((-ey / L, ex / L))
    for i in range(4):
        j = (i + 1) % 4
        ex = p2[j][0] - p2[i][0]
        ey = p2[j][1] - p2[i][1]
        L = math.hypot(ex, ey)
        if L > 1e-15:
            axes.append((-ey / L, ex / L))
    for ax, ay in axes:
        min1 = min(px * ax + py * ay for px, py in p1)
        max1 = max(px * ax + py * ay for px, py in p1)
        min2 = min(px * ax + py * ay for px, py in p2)
        max2 = max(px * ax + py * ay for px, py in p2)
        if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
            return False
    return True


def inside_unit(cx, cy, ang, s):
    if s < 1e-12:
        return True
    pts = corners(cx, cy, ang, s)
    for x, y in pts:
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def total_side(squares):
    return sum(s[3] for s in squares)


# ---------------------------------------------------------------
# Constructive packings
# ---------------------------------------------------------------

def grid_packing(n):
    """Best k x k grid, with k = isqrt(n)."""
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0) for _ in range(n)]
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
          for i in range(k) for j in range(k)]
    # fill remaining with zero squares
    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
    return sq[:n]


def recursive_guillotine(n, x0, y0, w, h, angle, out):
    """Fill a rectangle with n squares; puts results in out."""
    if n <= 0:
        return
    if n == 1:
        s = min(w, h)
        cx = x0 + w * 0.5
        cy = y0 + h * 0.5
        out.append((cx, cy, angle, s))
        return

    # Decide a split: favour near-square sub-rectangles
    # Try vertical split first (more columns)
    # Choose number of columns c and rows r with c*r >= n, minimising waste
    best = None
    for c in range(1, n + 1):
        r = (n + c - 1) // c
        # sub-rectangle dimensions if vertical split into c columns
        cw = w / c
        ch = h
        # but we'll recursively split into columns then rows inside
        # effective fill ratio
        waste = (c * r - n) + abs(cw - ch) * 0.0
        if best is None or waste < best[0]:
            best = (waste, c, r)

    # Simpler: use a binary guillotine, split into two parts
    # Choose split direction and ratio
    if n == 2:
        if w >= h:
            # split vertically
            s = min(w * 0.5, h)
            out.append((x0 + s * 0.5, y0 + h * 0.5, angle, s))
            out.append((x0 + w - s * 0.5, y0 + h * 0.5, angle, s))
        else:
            s = min(w, h * 0.5)
            out.append((x0 + w * 0.5, y0 + s * 0.5, angle, s))
            out.append((x0 + w * 0.5, y0 + h - s * 0.5, angle, s))
        return

    # split into two groups
    n1 = n // 2
    n2 = n - n1
    # prefer splitting the longer dimension
    if w >= h:
        # vertical split, proportional
        frac = n1 / n
        w1 = w * frac
        # squares in left region should have area ~ w1*h/n1
        recursive_guillotine(n1, x0, y0, w1, h, angle, out)
        recursive_guillotine(n2, x0 + w1, y0, w - w1, h, angle, out)
    else:
        frac = n1 / n
        h1 = h * frac
        recursive_guillotine(n1, x0, y0, w, h1, angle, out)
        recursive_guillotine(n2, x0, y0 + h1, w, h - h1, angle, out)


def guillotine_packing(n):
    out = []
    recursive_guillotine(n, 0.0, 0.0, 1.0, 1.0, 0.0, out)
    return out


def mixed_packing(n):
    """Try different strategies and keep best."""
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    candidates = []
    candidates.append(grid_packing(n))
    candidates.append(guillotine_packing(n))
    # Try grid with extra squares in unused columns
    best = max(candidates, key=total_side)
    return best


# ---------------------------------------------------------------
# Local optimisation
# ---------------------------------------------------------------

def repair(squares, n, iterations=30):
    """Greedily shrink/move squares to remove overlap / out-of-bounds."""
    sq = [list(s) for s in squares]

    for _ in range(iterations):
        changed = False
        # fix bounds
        for i in range(n):
            cx, cy, ang, s = sq[i]
            if s <= 1e-12:
                continue
            # clamp centre so square fits (approximately)
            # compute bounding box
            pts = corners(cx, cy, ang, s)
            minx = min(p[0] for p in pts)
            maxx = max(p[0] for p in pts)
            miny = min(p[1] for p in pts)
            maxy = max(p[1] for p in pts)
            if minx < 0:
                sq[i][0] -= minx
            if maxx > 1:
                sq[i][0] -= (maxx - 1)
            if miny < 0:
                sq[i][1] -= miny
            if maxy > 1:
                sq[i][1] -= (maxy - 1)

        # resolve overlaps
        for i in range(n):
            if sq[i][3] <= 1e-12:
                continue
            for j in range(i + 1, n):
                if sq[j][3] <= 1e-12:
                    continue
                c1 = (sq[i][0], sq[i][1])
                c2 = (sq[j][0], sq[j][1])
                a1, a2 = sq[i][2], sq[j][2]
                s1, s2 = sq[i][3], sq[j][3]
                if separating_axis_overlap(c1, c2, a1, a2, s1, s2):
                    # shrink both by a bit
                    scale = 0.94
                    sq[i][3] *= scale
                    sq[j][3] *= scale
                    changed = True
        if not changed:
            break
    return [tuple(s) for s in sq]


def try_move(sq, i, dcx, dcy, dang, ds, n, check_iters=2):
    """Attempt to move square i; returns new list if valid else None."""
    old = sq[i][:]
    cx = old[0] + dcx
    cy = old[1] + dcy
    ang = old[2] + dang
    s = old[3] + ds
    if s < 0:
        s = 0.0
    if s > 1.0:
        s = 1.0
    # must be inside
    if not inside_unit(cx, cy, ang, s):
        return None
    # must not overlap others
    for j in range(n):
        if j == i:
            continue
        if sq[j][3] <= 1e-12:
            continue
        if separating_axis_overlap((cx, cy), (sq[j][0], sq[j][1]), ang, sq[j][2], s, sq[j][3]):
            return None
    new = sq[:]
    new[i] = (cx, cy, ang, s)
    return new


def local_optimise(squares, n, rng, time_budget_iters=4000):
    """Coordinate ascent: try random moves, accept if total side increases."""
    sq = [tuple(s) for s in squares]
    cur = total_side(sq)

    # collect indices to try
    idxs = [i for i in range(n)]

    for it in range(time_budget_iters):
        i = rng.choice(idxs)
        s0 = sq[i][3]
        if s0 <= 1e-12:
            # try to grow this zero square
            cx = rng.uniform(0.1, 0.9)
            cy = rng.uniform(0.1, 0.9)
            ang = rng.choice([0.0, 0.25, 0.125, 0.375, rng.random()])
            s = rng.uniform(0.0, 0.2)
            if inside_unit(cx, cy, ang, s):
                ok = True
                for j in range(n):
                    if j == i or sq[j][3] <= 1e-12:
                        continue
                    if separating_axis_overlap((cx, cy), (sq[j][0], sq[j][1]),
                                               ang, sq[j][2], s, sq[j][3]):
                        ok = False
                        break
                if ok:
                    new = sq[:]
                    new[i] = (cx, cy, ang, s)
                    ns = total_side(new)
                    if ns > cur:
                        sq = new
                        cur = ns
            continue

        # random perturbation
        scale = max(0.001, 0.08 * s0)
        dcx = rng.gauss(0, scale * 0.5)
        dcy = rng.gauss(0, scale * 0.5)
        dang = rng.gauss(0, 0.05)
        ds = rng.gauss(0, scale * 0.5)
        res = try_move(sq, i, dcx, dcy, dang, ds, n)
        if res is not None:
            ns = total_side(res)
            if ns > cur:
                sq = res
                cur = ns
            elif ns > cur - 1e-12 and rng.random() < 0.1:
                sq = res
                cur = ns

        # occasionally try to grow a square
        if it % 5 == 0:
            i = rng.choice(idxs)
            s0 = sq[i][3]
            if s0 > 1e-12:
                ds = rng.uniform(0.0, 0.03) * (1.0 - s0)
                res = try_move(sq, i, 0.0, 0.0, 0.0, ds, n)
                if res is not None:
                    ns = total_side(res)
                    if ns > cur:
                        sq = res
                        cur = ns

    return sq


# ---------------------------------------------------------------
# Main solver
# ---------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n * 7919)

    best = None

    # try several initial constructions
    initials = []
    initials.append(grid_packing(n))
    initials.append(guillotine_packing(n))
    # a few random guillotine variants
    for _ in range(3):
        initials.append(guillotine_packing(n))

    for init in initials:
        sq = repair(init, n, iterations=20)
        # ensure all squares valid
        sq = [tuple(s) for s in sq]
        # local search
        improved = local_optimise(sq, n, rng, time_budget_iters=2500)
        val = total_side(improved)
        if best is None or val > total_side(best):
            best = improved

    # final repair pass
    best = repair(best, n, iterations=30)
    # clip all to [0,1]
    result = []
    for cx, cy, ang, s in best:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        s = min(1.0, max(0.0, s))
        result.append((cx, cy, ang, s))
    return result
