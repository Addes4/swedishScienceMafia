import math
import random
import numpy as np
from scipy.optimize import minimize

def _overlap_penalty(squares):
    """Penalty for overlapping squares and those going outside the unit square."""
    penalty = 0.0
    n = len(squares)
    for i in range(n):
        cx, cy, ang, s = squares[i]
        if s <= 0:
            continue
        # Square corners
        c, sn = math.cos(2*math.pi*ang), math.sin(2*math.pi*ang)
        h = s / 2.0
        corners = [(cx + c*h - sn*h, cy + sn*h + c*h),
                   (cx - c*h - sn*h, cy - sn*h + c*h),
                   (cx - c*h + sn*h, cy - sn*h - c*h),
                   (cx + c*h + sn*h, cy + sn*h - c*h)]
        # Boundary violations
        for (x, y) in corners:
            if x < 0: penalty += 1000 * x*x
            if x > 1: penalty += 1000 * (x-1)*(x-1)
            if y < 0: penalty += 1000 * y*y
            if y > 1: penalty += 1000 * (y-1)*(y-1)
        # Overlap with other squares (approximate via point-in-square checks of corners)
        for j in range(i+1, n):
            cx2, cy2, ang2, s2 = squares[j]
            if s2 <= 0:
                continue
            # Separating Axis Theorem for two squares
            if _sat_overlap(cx, cy, ang, s, cx2, cy2, ang2, s2):
                penalty += 1000
    return penalty

def _sat_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Separating Axis Theorem for two rotated squares."""
    def corners(cx, cy, ang, s):
        c, sn = math.cos(2*math.pi*ang), math.sin(2*math.pi*ang)
        h = s / 2.0
        return [(cx + c*h - sn*h, cy + sn*h + c*h),
                (cx - c*h - sn*h, cy - sn*h + c*h),
                (cx - c*h + sn*h, cy - sn*h - c*h),
                (cx + c*h + sn*h, cy + sn*h - c*h)]
    p1 = corners(cx1, cy1, a1, s1)
    p2 = corners(cx2, cy2, a2, s2)
    axes = []
    for poly in [p1, p2]:
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i+1)%4]
            edge = (x2 - x1, y2 - y1)
            normal = (-edge[1], edge[0])
            ln = math.hypot(*normal)
            if ln > 1e-12:
                axes.append((normal[0]/ln, normal[1]/ln))
    for ax, ay in axes:
        mn1 = min(x*ax + y*ay for x, y in p1)
        mx1 = max(x*ax + y*ay for x, y in p1)
        mn2 = min(x*ax + y*ay for x, y in p2)
        mx2 = max(x*ax + y*ay for x, y in p2)
        if mx1 < mn2 - 1e-9 or mx2 < mn1 - 1e-9:
            return False
    return True

def _score(squares):
    return sum(s for (_, _, _, s) in squares)

def _refine(squares, iterations=3000):
    """Simulated annealing to improve the packing."""
    n = len(squares)
    cur = [list(sq) for sq in squares]
    cur_score = _score(cur) - _overlap_penalty(cur)
    best = [list(sq) for sq in cur]
    best_score = cur_score
    temp = 0.05
    for it in range(iterations):
        temp = 0.05 * (1 - it / iterations) + 0.001
        i = random.randrange(n)
        new = [list(sq) for sq in cur]
        r = random.random()
        if r < 0.4:
            # Perturb size
            new[i][3] = max(0.0, min(1.0, new[i][3] + random.gauss(0, temp)))
        elif r < 0.7:
            # Perturb position
            new[i][0] = max(0.0, min(1.0, new[i][0] + random.gauss(0, temp*5)))
            new[i][1] = max(0.0, min(1.0, new[i][1] + random.gauss(0, temp*5)))
        else:
            # Perturb angle
            new[i][2] = (new[i][2] + random.gauss(0, temp)) % 1.0
        # Clamp
        new[i][3] = min(new[i][3], 1.0)
        new_score = _score(new) - _overlap_penalty(new)
        if new_score > cur_score or random.random() < math.exp((new_score - cur_score) / max(temp, 1e-9)):
            cur = new
            cur_score = new_score
            if cur_score > best_score:
                best_score = cur_score
                best = [list(sq) for sq in cur]
    return best, best_score

def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    
    # Start with a grid
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    # Add remaining as zero-size
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    
    # Multiple restarts with refinement
    best = squares
    best_score = _score(squares) - _overlap_penalty(squares)
    
    for restart in range(3):
        # Randomize slightly
        cand = [list(sq) for sq in squares]
        for i in range(len(cand)):
            if i < k*k:
                cand[i][0] += random.uniform(-0.05, 0.05)
                cand[i][1] += random.uniform(-0.05, 0.05)
                cand[i][2] += random.uniform(-0.05, 0.05)
                cand[i][3] *= random.uniform(0.9, 1.1)
                cand[i][3] = min(cand[i][3], 1.0)
            else:
                cand[i][0] = random.random()
                cand[i][1] = random.random()
                cand[i][2] = random.random()
                cand[i][3] = random.uniform(0.0, 0.2)
        refined, sc = _refine(cand, iterations=2000)
        if sc > best_score:
            best_score = sc
            best = refined
    
    # Convert to tuples, ensure zero-size squares are valid
    result = []
    for sq in best:
        cx, cy, ang, s = sq
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = ang % 1.0
        s = max(0.0, min(1.0, s))
        result.append((cx, cy, ang, s))
    
    return result[:n]
