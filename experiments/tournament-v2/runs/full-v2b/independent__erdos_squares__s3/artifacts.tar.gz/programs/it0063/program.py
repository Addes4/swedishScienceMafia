import math
import random
import numpy as np
from scipy.optimize import minimize

# Global cache for random seed reproducibility
random.seed(12345)
np.random.seed(12345)

def solve(n):
    """Return n squares inside unit square maximising sum of side lengths."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 0.5)]
    # Start with a good constructive heuristic: largest k x k grid, then pack remainder.
    best = None
    best_score = -1.0
    
    # Try several k values
    for k in range(1, min(11, n) + 1):
        # k x k grid with side = 1/k
        if k*k > n:
            continue
        rem = n - k*k
        # Try different strategies for placing leftover squares
        for strategy in range(4):
            squares = _grid_packing(k, rem, strategy)
            if squares is None:
                continue
            score = sum(s[3] for s in squares)
            if score > best_score:
                best_score = score
                best = squares
                
    # Try random guillotine packings
    for trial in range(20):
        squares = _random_guillotine(n)
        score = sum(s[3] for s in squares)
        if score > best_score:
            best_score = score
            best = squares
            
    # Try spiral packing
    for trial in range(10):
        squares = _spiral_packing(n)
        score = sum(s[3] for s in squares)
        if score > best_score:
            best_score = score
            best = squares

    # Refine with local search
    if best is not None:
        best = _local_search(best, n, time_limit=50.0)
    
    # Ensure correct length
    if best is None:
        k = math.isqrt(n)
        side = 1.0 / k
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    
    return best[:n]


def _grid_packing(k, rem, strategy):
    """Place k x k grid, then leftover squares in gaps."""
    squares = []
    side = 1.0 / k
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    if rem > 0:
        # Try to insert leftover squares into grid lines or borders
        if strategy == 0:
            # Shrink some squares and fill gaps
            pass
        elif strategy == 1:
            # Add small squares along edges
            gap = (1.0 - k * side) / 2.0 if k > 0 else 0.0
            positions = []
            for i in range(k):
                positions.append((i * side, 0.0))
            for i in range(rem):
                if i < len(positions):
                    x, y = positions[i]
                    squares.append((x + side * 0.1, y - gap * 0.5, 0.0, gap * 0.4))
                else:
                    squares.append((0.5, 0.5, 0.0, 0.0))
        elif strategy == 2:
            # Place tiny squares in grid intersections
            for i in range(rem):
                squares.append((random.random(), random.random(), random.random(), 0.001))
        else:
            # Zero-size for leftovers
            for i in range(rem):
                squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:len(squares)]


def _random_guillotine(n):
    """Random guillotine partition into n rectangles approximated by squares."""
    # Start with full square, split recursively
    rects = [(0.0, 0.0, 1.0, 1.0)]
    while len(rects) < n:
        # Pick largest rectangle to split
        rects.sort(key=lambda r: -min(r[2] - r[0], r[3] - r[1]))
        idx = 0
        r = rects.pop(idx)
        x0, y0, x1, y1 = r
        w, h = x1 - x0, y1 - y0
        if w <= 0 or h <= 0:
            rects.append(r)
            break
        # Split along longer dimension with random ratio
        if w > h:
            ratio = random.uniform(0.3, 0.7)
            xm = x0 + w * ratio
            rects.append((x0, y0, xm, y1))
            rects.append((xm, y0, x1, y1))
        else:
            ratio = random.uniform(0.3, 0.7)
            ym = y0 + h * ratio
            rects.append((x0, y0, x1, ym))
            rects.append((x0, ym, x1, y1))
    # Convert to squares: use min(w,h) as side, centre in rectangle
    squares = []
    for x0, y0, x1, y1 in rects[:n]:
        w, h = x1 - x0, y1 - y0
        side = min(w, h)
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        squares.append((cx, cy, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _spiral_packing(n):
    """Spiral packing: place squares in decreasing size along a spiral."""
    squares = []
    # Place diminishing squares
    total = 0.0
    sides = []
    if n > 0:
        # Use a geometric sequence
        r = 0.85
        s = 0.5
        for i in range(n):
            sides.append(s)
            s *= r
    # Place them along a spiral path
    angle = 0.0
    radius = 0.0
    for i, side in enumerate(sides):
        if side < 1e-6:
            squares.append((0.5, 0.5, 0.0, 0.0))
            continue
        # Try to place without overlap (simplified)
        placed = False
        for attempt in range(200):
            cx = 0.5 + radius * math.cos(angle)
            cy = 0.5 + radius * math.sin(angle)
            if _fits(cx, cy, 0.0, side, squares):
                squares.append((cx, cy, 0.0, side))
                placed = True
                break
            angle += 0.3
            radius += 0.01
            radius = min(radius, 0.5)
        if not placed:
            squares.append((0.5, 0.5, 0.0, 0.0))
        angle += 0.5
        radius += side * 0.5
        radius = min(radius, 0.49)
    return squares[:n]


def _fits(cx, cy, angle, side, squares):
    """Check if a square fits inside unit square and doesn't overlap others."""
    if not _inside_unit(cx, cy, angle, side):
        return False
    for s in squares:
        if s[3] < 1e-9:
            continue
        if _overlap(cx, cy, angle, side, s[0], s[1], s[2], s[3]):
            return False
    return True


def _corners(cx, cy, angle, side):
    """Return four corners of square (in unit coords)."""
    a = angle * 2 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = side / 2.0
    # Base corners relative to centre
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    result = []
    for px, py in pts:
        rx = px * ca - py * sa
        ry = px * sa + py * ca
        result.append((cx + rx, cy + ry))
    return result


def _inside_unit(cx, cy, angle, side):
    """Check if square is inside [0,1]^2."""
    for x, y in _corners(cx, cy, angle, side):
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Check if two squares overlap interior using SAT."""
    if s1 < 1e-9 or s2 < 1e-9:
        return False
    c1 = _corners(cx1, cy1, a1, s1)
    c2 = _corners(cx2, cy2, a2, s2)
    # Separating axis theorem
    axes = []
    for i in range(4):
        p1 = c1[i]
        p2 = c1[(i + 1) % 4]
        edge = (p2[0] - p1[0], p2[1] - p1[1])
        axes.append((-edge[1], edge[0]))
    for i in range(4):
        p1 = c2[i]
        p2 = c2[(i + 1) % 4]
        edge = (p2[0] - p1[0], p2[1] - p1[1])
        axes.append((-edge[1], edge[0]))
    for ax, ay in axes:
        nlen = math.hypot(ax, ay)
        if nlen < 1e-12:
            continue
        ax /= nlen
        ay /= nlen
        min1, max1 = float('inf'), float('-inf')
        for x, y in c1:
            proj = x * ax + y * ay
            min1 = min(min1, proj)
            max1 = max(max1, proj)
        min2, max2 = float('inf'), float('-inf')
        for x, y in c2:
            proj = x * ax + y * ay
            min2 = min(min2, proj)
            max2 = max(max2, proj)
        if max1 < min2 - 1e-9 or max2 < min1 - 1e-9:
            return False
    return True


def _local_search(squares, n, time_limit=50.0):
    """Local search to improve sum of side lengths."""
    import time
    start_time = time.time()
    current = [list(s) for s in squares]
    # Remove zero-size squares (treat as points)
    active = [s for s in current if s[3] > 1e-9]
    zero_squares = [s for s in current if s[3] <= 1e-9]
    
    # Ensure exactly n squares
    while len(active) + len(zero_squares) < n:
        zero_squares.append([0.5, 0.5, 0.0, 0.0])
    active = active[:n]
    zero_squares = zero_squares[:max(0, n - len(active))]
    
    best_active = [s[:] for s in active]
    best_score = sum(s[3] for s in active)
    
    # Coordinate descent optimization
    improved = True
    iteration = 0
    while improved and time.time() - start_time < time_limit:
        improved = False
        iteration += 1
        for idx in range(min(len(active), n)):
            if time.time() - start_time > time_limit:
                break
            best_local = active[idx][:]
            local_score = sum(s[3] for s in active)
            base_score = local_score - active[idx][3]
            # Try to increase size or adjust position
            cx, cy, ag, sz = active[idx]
            # Try incrementally larger sizes and slight movements
            for factor in [1.02, 1.05, 1.1, 1.2]:
                new_sz = min(sz * factor, 0.5)
                if new_sz > 0.5:
                    continue
                # Try small position adjustments
                for dx in [-0.01, 0.0, 0.01]:
                    for dy in [-0.01, 0.0, 0.01]:
                        for da in [-0.05, 0.0, 0.05]:
                            ncx = min(max(cx + dx, new_sz/2), 1.0 - new_sz/2)
                            ncy = min(max(cy + dy, new_sz/2), 1.0 - new_sz/2)
                            nag = (ag + da) % 1.0
                            if _fits(ncx, ncy, nag, new_sz, [s for i, s in enumerate(active) if i != idx]):
                                # Check overlap with all other active
                                ok = True
                                for j, s in enumerate(active):
                                    if j == idx:
                                        continue
                                    if _overlap(ncx, ncy, nag, new_sz, s[0], s[1], s[2], s[3]):
                                        ok = False
                                        break
                                if ok:
                                    if new_sz > active[idx][3]:
                                        active[idx] = [ncx, ncy, nag, new_sz]
                                        improved = True
                                        break
                    if improved:
                        break
                if improved:
                    break
            # Also try to just move without resizing to allow future growth
            if not improved:
                for dx in [-0.02, 0.0, 0.02]:
                    for dy in [-0.02, 0.0, 0.02]:
                        ncx = min(max(cx + dx, sz/2), 1.0 - sz/2)
                        ncy = min(max(cy + dy, sz/2), 1.0 - sz/2)
                        if _inside_unit(ncx, ncy, ag, sz) and sz > 0:
                            ok = True
                            for j, s in enumerate(active):
                                if j == idx:
                                    continue
                                if _overlap(ncx, ncy, ag, sz, s[0], s[1], s[2], s[3]):
                                    ok = False
                                    break
                            if ok:
                                active[idx] = [ncx, ncy, ag, sz]
                                break
            # Try rotating without changing size to reduce overlap
            if not improved:
                for da in [-0.1, 0.1, -0.05, 0.05]:
                    nag = (ag + da) % 1.0
                    if _inside_unit(cx, cy, nag, sz):
                        ok = True
                        for j, s in enumerate(active):
                            if j == idx:
                                continue
                            if _overlap(cx, cy, nag, sz, s[0], s[1], s[2], s[3]):
                                ok = False
                                break
                        if ok:
                            active[idx] = [cx, cy, nag, sz]
                            break
        # Try to grow all squares slightly if possible
        if time.time() - start_time < time_limit * 0.8:
            for idx in range(len(active)):
                cx, cy, ag, sz = active[idx]
                new_sz = min(sz * 1.01, 0.5)
                # Try to find a position where it fits at larger size
                found = False
                for dx in [-0.01, 0.0, 0.01]:
                    for dy in [-0.01, 0.0, 0.01]:
                        ncx = min(max(cx + dx, new_sz/2), 1.0 - new_sz/2)
                        ncy = min(max(cy + dy, new_sz/2), 1.0 - new_sz/2)
                        if _fits(ncx, ncy, ag, new_sz, [s for i, s in enumerate(active) if i != idx]):
                            active[idx] = [ncx, ncy, ag, new_sz]
                            found = True
                            break
                    if found:
                        break
        
        # Update best
        score = sum(s[3] for s in active)
        if score > best_score:
            best_score = score
            best_active = [s[:] for s in active]
            improved = True
    
    # Combine with zero squares
    result = best_active + [list(s) for s in zero_squares]
    # Sort or maintain order
    result = result[:n]
    # Fill with zeros if needed
    while len(result) < n:
        result.append([0.5, 0.5, 0.0, 0.0])
    return [tuple(s) for s in result[:n]]


# Additional specialized packings for specific n values
def _try_specific(n):
    """Try specialized packings for known good configurations."""
    pass


if __name__ == "__main__":
    # Test
    for n in [1, 2, 4, 5, 9, 10, 16, 20, 25]:
        result = solve(n)
        score = sum(s[3] for s in result)
        print(f"n={n}, score={score:.4f}")
