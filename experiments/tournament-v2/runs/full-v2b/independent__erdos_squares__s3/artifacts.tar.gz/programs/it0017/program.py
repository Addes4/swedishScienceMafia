import math
import random
import time
from itertools import product

try:
    import numpy as np
    from scipy.optimize import minimize
    HAS_SCIPY = True
except Exception:
    HAS_SCIPY = False

_TIME_LIMIT = 55.0
_EPS = 1e-12


def _clip01(x):
    return min(1.0, max(0.0, x))


def _rotated_square_vertices(cx, cy, ang, s):
    """Return 4 vertices of square centered at (cx, cy), angle in turns, side s."""
    t = 2.0 * math.pi * ang
    c = math.cos(t)
    sn = math.sin(t)
    h = 0.5 * s
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + c * dx - sn * dy
        y = cy + sn * dx + c * dy
        pts.append((x, y))
    return pts


def _sat_overlap(a, b):
    """Check overlap of two convex polygons using SAT. Polygons as vertex lists.
    Returns True if interiors overlap (positive area overlap)."""
    for poly in (a, b):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            # normal axis
            ax, ay = -ey, ex
            # project both polygons
            amin, amax = float('inf'), float('-inf')
            bmin, bmax = float('inf'), float('-inf')
            for (px, py) in a:
                d = px * ax + py * ay
                if d < amin:
                    amin = d
                if d > amax:
                    amax = d
            for (px, py) in b:
                d = px * ax + py * ay
                if d < bmin:
                    bmin = d
                if d > bmax:
                    bmax = d
            if amax <= bmin + _EPS or bmax <= amin + _EPS:
                return False
    return True


def _inside_unit(vertices):
    for (x, y) in vertices:
        if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
            return False
    return True


def _penalty(squares):
    """Penalty for overlap + outside. Negative for reward? We'll just count violations."""
    n = len(squares)
    polys = []
    for (cx, cy, ang, s) in squares:
        if s <= 0:
            polys.append(None)
        else:
            polys.append(_rotated_square_vertices(cx, cy, ang, s))
    pen = 0.0
    # outside penalty
    for p in polys:
        if p is None:
            continue
        for (x, y) in p:
            if x < 0:
                pen += -x * 10.0
            elif x > 1:
                pen += (x - 1.0) * 10.0
            if y < 0:
                pen += -y * 10.0
            elif y > 1:
                pen += (y - 1.0) * 10.0
    # overlap penalty
    for i in range(n):
        if polys[i] is None:
            continue
        ai = polys[i]
        for j in range(i + 1, n):
            if polys[j] is None:
                continue
            if _sat_overlap(ai, polys[j]):
                # approximate overlap area by bounding boxes
                ax = [v[0] for v in ai]
                ay = [v[1] for v in ai]
                bx = [v[0] for v in polys[j]]
                by = [v[1] for v in polys[j]]
                w = min(max(ax), max(bx)) - max(min(ax), min(bx))
                h = min(max(ay), max(by)) - max(min(ay), min(by))
                if w > 0 and h > 0:
                    pen += w * h * 100.0
                else:
                    pen += 1e-3
    return pen


def _greedy_grid(n):
    """Start with a grid of squares. Largest k x k grid that fits, plus extras shrunk to 0."""
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # remaining get placed at center with tiny size or better: try to subdivide
    rem = n - k * k
    # place remaining in empty space? For simplicity, place them as points
    for _ in range(rem):
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _initial_config(n):
    """Create an initial configuration. Use grid + small extras placed to not overlap too much."""
    if n <= 0:
        return []
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    # place remaining as small squares in corners or between gaps, initially zero
    rem = n - k * k
    # Distribute remaining into the gaps along edges? For simplicity, place them at random
    # non-overlapping-ish positions with size 0
    positions = []
    # candidate positions: corners and centers of cells
    cand = []
    for i in range(k + 1):
        for j in range(k + 1):
            x = i * side
            y = j * side
            if 0.0 <= x <= 1.0 and 0.0 <= y <= 1.0:
                cand.append((_clip01(x), _clip01(y)))
    # also center of cells
    for i in range(k):
        for j in range(k):
            cand.append(((i + 0.5) * side, (j + 0.5) * side))
    random.shuffle(cand)
    for r in range(rem):
        if r < len(cand):
            x, y = cand[r]
        else:
            x, y = random.random(), random.random()
        squares.append([x, y, 0.0, 0.0])
    return squares[:n]


def _objective(squares):
    return sum(s[3] for s in squares)


def _repair(squares, max_iter=2000):
    """Greedily shrink overlapping squares and move them inside, to reduce penalty."""
    n = len(squares)
    for _ in range(max_iter):
        pen = _penalty(squares)
        if pen < 1e-9:
            break
        # Find worst violation and fix
        # Simple: shrink all squares slightly until penalty is low
        # But better: shrink the ones causing overlap
        # First, clamp positions inside
        for i in range(n):
            cx, cy, ang, s = squares[i]
            if s <= 0:
                cx = _clip01(cx)
                cy = _clip01(cy)
                squares[i] = [cx, cy, ang, 0.0]
                continue
            # move center so that square stays inside
            # compute needed shift
            polys = _rotated_square_vertices(cx, cy, ang, s)
            minx = min(p[0] for p in polys)
            maxx = max(p[0] for p in polys)
            miny = min(p[1] for p in polys)
            maxy = max(p[1] for p in polys)
            dx = 0.0
            if minx < 0:
                dx += -minx
            if maxx > 1:
                dx -= (maxx - 1.0)
            dy = 0.0
            if miny < 0:
                dy += -miny
            if maxy > 1:
                dy -= (maxy - 1.0)
            # If still can't fit, shrink
            if minx + dx < -1e-9 or maxx + dx > 1 + 1e-9 or miny + dy < -1e-9 or maxy + dy > 1 + 1e-9:
                # shrink
                needed_w = maxx - minx
                needed_h = maxy - miny
                if needed_w > 1.0 or needed_h > 1.0:
                    s *= min(1.0 / needed_w, 1.0 / needed_h) * 0.999
                    polys = _rotated_square_vertices(cx, cy, ang, s)
                    minx = min(p[0] for p in polys)
                    maxx = max(p[0] for p in polys)
                    miny = min(p[1] for p in polys)
                    maxy = max(p[1] for p in polys)
                    dx = 0.0
                    if minx < 0:
                        dx += -minx
                    if maxx > 1:
                        dx -= (maxx - 1.0)
                    dy = 0.0
                    if miny < 0:
                        dy += -miny
                    if maxy > 1:
                        dy -= (maxy - 1.0)
            squares[i][0] = _clip01(cx + dx)
            squares[i][1] = _clip01(cy + dy)
            squares[i][3] = s

        # Now handle overlaps: reduce the smaller squares?
        # compute overlaps and shrink both proportionally
        polys = []
        for (cx, cy, ang, s) in squares:
            if s > 0:
                polys.append(_rotated_square_vertices(cx, cy, ang, s))
            else:
                polys.append(None)
        shrink_factor = {}
        for i in range(n):
            if polys[i] is None:
                continue
            for j in range(i + 1, n):
                if polys[j] is None:
                    continue
                if _sat_overlap(polys[i], polys[j]):
                    # shrink both
                    shrink_factor[i] = shrink_factor.get(i, 1.0) * 0.95
                    shrink_factor[j] = shrink_factor.get(j, 1.0) * 0.95
        if not shrink_factor:
            # no overlap found but penalty remains? maybe numerical
            # do a tiny global shrink
            for i in range(n):
                squares[i][3] *= 0.999
            continue
        for i, f in shrink_factor.items():
            squares[i][3] *= f

    # final clamp
    for i in range(n):
        cx, cy, ang, s = squares[i]
        squares[i] = [_clip01(cx), _clip01(cy), ang % 1.0, max(0.0, s)]
    return squares


def _local_search(squares, n, time_deadline, rng):
    """Try to increase side lengths by moving/rotating and growing."""
    best = [list(s) for s in squares]
    best_score = _objective(best)
    cur = [list(s) for s in squares]
    cur_score = best_score

    # iterative improvement: pick a square, try to increase size
    it = 0
    while time.time() < time_deadline:
        it += 1
        # random perturbation
        i = rng.randrange(n)
        cx, cy, ang, s = cur[i]
        # propose new state
        new_s = s
        new_x, new_y, new_a = cx, cy, ang
        mode = rng.random()
        if mode < 0.4:
            # try to grow
            new_s = min(1.0, s + rng.uniform(0.001, 0.05))
        elif mode < 0.6:
            # try to shrink to allow move
            new_s = max(0.0, s - rng.uniform(0.001, 0.05))
        elif mode < 0.8:
            # move
            new_x = _clip01(cx + rng.uniform(-0.05, 0.05))
            new_y = _clip01(cy + rng.uniform(-0.05, 0.05))
        else:
            # rotate
            new_a = (ang + rng.uniform(-0.1, 0.1)) % 1.0

        old = cur[i]
        cur[i] = [new_x, new_y, new_a, new_s]
        # repair just this square (and maybe others if overlap)
        pen = _penalty(cur)
        if pen < 1e-7:
            new_score = _objective(cur)
            if new_score > cur_score:
                cur_score = new_score
                if new_score > best_score:
                    best_score = new_score
                    best = [list(x) for x in cur]
            else:
                # accept if not much worse (simulated annealing-ish)
                if new_score > cur_score - 0.01 and rng.random() < 0.1:
                    pass  # keep it
                else:
                    cur[i] = old
        else:
            # try to repair by shrinking this square
            tmp_s = new_s
            for _ in range(20):
                if pen < 1e-7:
                    break
                tmp_s *= 0.9
                cur[i] = [new_x, new_y, new_a, tmp_s]
                pen = _penalty(cur)
            if pen < 1e-7:
                new_score = _objective(cur)
                if new_score > cur_score:
                    cur_score = new_score
                    if new_score > best_score:
                        best_score = new_score
                        best = [list(x) for x in cur]
                else:
                    if new_score > cur_score - 0.01 and rng.random() < 0.1:
                        pass
                    else:
                        cur[i] = old
            else:
                cur[i] = old

        # occasionally do a full repair
        if it % 500 == 0:
            cur = _repair(cur, max_iter=200)
            cur_score = _objective(cur)
            if cur_score > best_score + 1e-9:
                best_score = cur_score
                best = [list(x) for x in cur]

    return best


def _scipy_optimize(squares, n, time_deadline):
    """Use scipy minimize with penalty to fine-tune."""
    if not HAS_SCIPY:
        return squares
    # parameters: all cx, cy, ang, s
    x0 = []
    for (cx, cy, ang, s) in squares:
        x0.extend([cx, cy, ang, s])
    x0 = np.array(x0)

    def obj(x):
        sqs = []
        for i in range(n):
            cx, cy, ang, s = x[4 * i:4 * i + 4]
            sqs.append([cx, cy, ang, max(0.0, s)])
        return -sum(s[3] for s in sqs) + _penalty(sqs) * 10.0

    bounds = []
    for i in range(n):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])
    # time check
    if time.time() > time_deadline:
        return squares
    try:
        res = minimize(obj, x0, method='L-BFGS-B', bounds=bounds,
                       options={'maxiter': 200, 'ftol': 1e-8, 'gtol': 1e-6})
        x = res.x
        new_sqs = []
        for i in range(n):
            cx, cy, ang, s = x[4 * i:4 * i + 4]
            new_sqs.append([_clip01(cx), _clip01(cy), ang % 1.0, max(0.0, min(1.0, s))])
        # repair
        new_sqs = _repair(new_sqs, max_iter=500)
        if _objective(new_sqs) > _objective(squares) and _penalty(new_sqs) < 1e-6:
            return new_sqs
    except Exception:
        pass
    return squares


def solve(n):
    if n <= 0:
        return []
    rng = random.Random(12345 + n)
    start_time = time.time()
    time_deadline = start_time + _TIME_LIMIT

    # Multiple restarts with different initial configurations
    best = None
    best_score = -1.0

    restarts = 0
    max_restarts = 5
    if n <= 4:
        max_restarts = 10
    elif n <= 20:
        max_restarts = 8

    while restarts < max_restarts and time.time() < time_deadline:
        restarts += 1
        if restarts == 1:
            sqs = _initial_config(n)
        else:
            # perturb initial config
            sqs = _initial_config(n)
            for i in range(n):
                sqs[i][0] = _clip01(sqs[i][0] + rng.uniform(-0.1, 0.1))
                sqs[i][1] = _clip01(sqs[i][1] + rng.uniform(-0.1, 0.1))
                sqs[i][2] = rng.random()
                sqs[i][3] *= rng.uniform(0.5, 1.0)

        # repair to feasible
        sqs = _repair(sqs, max_iter=1000)

        # local search
        sqs = _local_search(sqs, n, min(time_deadline, time.time() + 10), rng)

        # scipy polish
        if time.time() < time_deadline - 2:
            sqs = _scipy_optimize(sqs, n, min(time_deadline, time.time() + 5))

        # final repair
        sqs = _repair(sqs, max_iter=2000)

        score = _objective(sqs)
        pen = _penalty(sqs)
        if pen > 1e-6:
            # infeasible, shrink slightly
            sqs = _repair(sqs, max_iter=5000)
            score = _objective(sqs)
            pen = _penalty(sqs)
            if pen > 1e-6:
                # last resort: shrink all
                for i in range(n):
                    sqs[i][3] *= 0.99
                sqs = _repair(sqs, max_iter=5000)
                score = _objective(sqs)

        if score > best_score:
            best_score = score
            best = sqs

    if best is None:
        best = _initial_config(n)
        best = _repair(best, max_iter=5000)

    # ensure all inside and valid
    result = []
    for (cx, cy, ang, s) in best:
        cx = _clip01(cx)
        cy = _clip01(cy)
        ang = ang % 1.0
        s = max(0.0, min(1.0, s))
        result.append((cx, cy, ang, s))

    # final validation: check overlaps and shrink if necessary (very conservative)
    # Do a final repair pass
    result = _repair([list(r) for r in result], max_iter=3000)
    result = [(r[0], r[1], r[2], r[3]) for r in result]

    return result[:n]
