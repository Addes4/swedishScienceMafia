import math
import random
import numpy as np

def solve(n):
    if n == 0:
        return []
    
    # Use a randomized greedy + optimization approach
    best_result = None
    best_sum = -1
    
    # Number of random restarts based on n
    restarts = max(5, min(30, 200 // max(1, n)))
    
    for attempt in range(restarts):
        # Initialize with a grid + extras
        k = int(math.sqrt(n))
        while (k+1)*(k+1) <= n:
            k += 1
        while k*k > n:
            k -= 1
        
        squares = []
        base_side = 1.0 / k if k > 0 else 0.0
        count = 0
        for i in range(k):
            for j in range(k):
                if count >= n:
                    break
                # Add small random jitter to positions
                jx = random.uniform(-0.02, 0.02) * base_side if attempt > 0 else 0
                jy = random.uniform(-0.02, 0.02) * base_side if attempt > 0 else 0
                squares.append([(i+0.5)*base_side + jx, (j+0.5)*base_side + jy, 0.0, base_side])
                count += 1
            if count >= n:
                break
        
        # For remaining squares, try to fit them in gaps
        remaining = n - len(squares)
        if remaining > 0:
            # Try random placements in remaining space
            for _ in range(remaining):
                # Try to find a good spot
                best_spot = None
                best_side = 0
                for _try in range(100):
                    cx = random.uniform(0.02, 0.98)
                    cy = random.uniform(0.02, 0.98)
                    # Estimate max side that fits
                    max_s = min(cx, 1-cx, cy, 1-cy) * 2
                    # Check against existing squares roughly
                    for s in squares:
                        if s[3] <= 0:
                            continue
                        dist = math.sqrt((cx-s[0])**2 + (cy-s[1])**2)
                        max_s = min(max_s, max(0, dist - s[3]*0.71 - 0.001) * 2)
                    if max_s > best_side:
                        best_side = max_s
                        best_spot = (cx, cy, 0.0, max_s)
                if best_spot:
                    squares.append(list(best_spot))
                else:
                    squares.append([0.5, 0.5, 0.0, 0.0])
        
        # Ensure we have exactly n
        squares = squares[:n]
        while len(squares) < n:
            squares.append([0.5, 0.5, 0.0, 0.0])
        
        # Optimization: iteratively adjust squares
        squares = optimize(squares, n, iterations=2000)
        
        total = sum(s[3] for s in squares)
        if total > best_sum:
            best_sum = total
            best_result = [tuple(s) for s in squares]
    
    # Final polish
    if best_result:
        final = [list(s) for s in best_result]
        final = optimize(final, n, iterations=3000)
        # Clamp all values
        result = []
        for s in final:
            cx = max(0.0, min(1.0, s[0]))
            cy = max(0.0, min(1.0, s[1]))
            angle = max(0.0, min(1.0, s[2] % 1.0))
            side = max(0.0, min(1.0, s[3]))
            result.append((cx, cy, angle, side))
        return result
    
    return [(0.5, 0.5, 0.0, 0.0)] * n


def square_corners(cx, cy, angle, side):
    """Get the 4 corners of a rotated square."""
    half = side / 2
    a = angle * 2 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    # corners in local coords
    local = [(-half, -half), (half, -half), (half, half), (-half, half)]
    corners = []
    for lx, ly in local:
        x = cx + lx * ca - ly * sa
        y = cy + lx * sa + ly * ca
        corners.append((x, y))
    return corners


def overlap_amount(s1, s2):
    """Approximate overlap/penetration between two squares."""
    cx1, cy1, a1, side1 = s1
    cx2, cy2, a2, side2 = s2
    if side1 <= 1e-9 or side2 <= 1e-9:
        return 0.0
    
    corners1 = square_corners(cx1, cy1, a1, side1)
    corners2 = square_corners(cx2, cy2, a2, side2)
    
    # Check if any corner of one is inside the other (SAT-lite)
    # Use separating axis theorem approximation
    # Quick bounding circle test
    r1 = side1 * 0.7071
    r2 = side2 * 0.7071
    dist = math.hypot(cx1 - cx2, cy1 - cy2)
    if dist > r1 + r2:
        return 0.0
    
    # Check all edges as separating axes (SAT)
    axes = []
    for corners in (corners1, corners2):
        for i in range(4):
            x1, y1 = corners[i]
            x2, y2 = corners[(i+1) % 4]
            ex, ey = x2 - x1, y2 - y1
            # normal
            nx, ny = -ey, ex
            length = math.hypot(nx, ny)
            if length > 1e-12:
                axes.append((nx/length, ny/length))
    
    min_overlap = float('inf')
    for ax, ay in axes:
        # Project corners1
        p1 = [x*ax + y*ay for x, y in corners1]
        p2 = [x*ax + y*ay for x, y in corners2]
        min1, max1 = min(p1), max(p1)
        min2, max2 = min(p2), max(p2)
        overlap = min(max1, max2) - max(min1, min2)
        if overlap <= 0:
            return 0.0
        min_overlap = min(min_overlap, overlap)
    
    return min_overlap if min_overlap != float('inf') else 0.0


def out_of_bounds(cx, cy, angle, side):
    """Total amount by which square goes outside [0,1]^2."""
    if side <= 1e-9:
        return 0.0
    corners = square_corners(cx, cy, angle, side)
    total = 0.0
    for x, y in corners:
        if x < 0:
            total += -x
        if x > 1:
            total += x - 1
        if y < 0:
            total += -y
        if y > 1:
            total += y - 1
    return total


def objective(squares):
    """Total side length minus penalties."""
    total_side = sum(s[3] for s in squares)
    penalty = 0.0
    for s in squares:
        penalty += 100.0 * out_of_bounds(s[0], s[1], s[2], s[3])
    # Overlap penalties
    m = len(squares)
    for i in range(m):
        for j in range(i+1, m):
            ov = overlap_amount(squares[i], squares[j])
            if ov > 1e-6:
                penalty += 50.0 * ov
    return total_side - penalty


def optimize(squares, n, iterations=2000):
    """Improve the arrangement using local search."""
    squares = [list(s) for s in squares]
    current_obj = objective(squares)
    
    temp = 0.1
    for it in range(iterations):
        # Pick a random square
        idx = random.randint(0, n-1) if n > 0 else 0
        if n == 0:
            break
        
        s = squares[idx]
        # Decide what to change
        choice = random.random()
        
        if choice < 0.3:
            # Move center
            step = 0.05 * (1 - it / (2*iterations))
            new_s = [s[0] + random.uniform(-step, step),
                     s[1] + random.uniform(-step, step),
                     s[2], s[3]]
        elif choice < 0.5:
            # Rotate
            step = 0.15 * (1 - it / (2*iterations))
            new_s = [s[0], s[1], (s[2] + random.uniform(-step, step)) % 1.0, s[3]]
        elif choice < 0.8:
            # Change size
            step = 0.05 * (1 - it / (2*iterations))
            new_s = [s[0], s[1], s[2], max(0, min(1, s[3] + random.uniform(-step, step)))]
        else:
            # Combined small adjustment
            step = 0.03 * (1 - it / (2*iterations))
            new_s = [s[0] + random.uniform(-step, step),
                     s[1] + random.uniform(-step, step),
                     s[2] + random.uniform(-step, step),
                     s[3] + random.uniform(-step, step)]
            new_s[3] = max(0, min(1, new_s[3]))
        
        # Clamp
        new_s[0] = max(0.0, min(1.0, new_s[0]))
        new_s[1] = max(0.0, min(1.0, new_s[1]))
        new_s[3] = max(0.0, min(1.0, new_s[3]))
        
        old_s = squares[idx]
        squares[idx] = new_s
        new_obj = objective(squares)
        
        delta = new_obj - current_obj
        if delta > 0 or random.random() < math.exp(delta / max(0.001, temp)):
            current_obj = new_obj
        else:
            squares[idx] = old_s
        
        temp *= 0.999
    
    return squares
