import math
import random
import time
import numpy as np
from scipy.optimize import minimize

EVOLVE_BLOCK_START = True


def _rot(angle):
    c = math.cos(2 * math.pi * angle)
    s = math.sin(2 * math.pi * angle)
    return c, s


def _corners(cx, cy, a, side):
    c, s = _rot(a)
    h = side * 0.5
    pts = []
    for sx, sy in ((1, 1), (1, -1), (-1, -1), (-1, 1)):
        dx = sx * h
        dy = sy * h
        pts.append((cx + c * dx - s * dy, cy + s * dx + c * dy))
    return pts


def _axes(a):
    c, s = _rot(a)
    return ((c, s), (-s, c))


def _sat_gap(s1, s2):
    # negative if overlapping; positive separation along best axis
    cx1, cy1, a1, side1 = s1
    cx2, cy2, a2, side2 = s2
    best = -1e9
    # separating axes for both rectangles
    for ax in _axes(a1) + _axes(a2):
        p1 = _corners(cx1, cy1, a1, side1)
        p2 = _corners(cx2, cy2, a2, side2)
        d1 = [px * ax[0] + py * ax[1] for px, py in p1]
        d2 = [px * ax[0] + py * ax[1] for px, py in p2]
        gap = max(min(d2) - max(d1), min(d1) - max(d2))
        if gap > best:
            best = gap
    return best


def _extract(x, n):
    out = []
    for i in range(n):
        cx = x[4 * i]
        cy = x[4 * i + 1]
        a = x[4 * i + 2]
        side = x[4 * i + 3]
        out.append((cx, cy, a, side))
    return out


def _objective(x, n, barrier):
    squares = _extract(x, n)
    total = 0.0
    # maximize sum of sides -> minimize negative
    s = 0.0
    for cx, cy, a, side in squares:
        if side < 0:
            s += 1e6 * side * side
        s -= side

    # boundary penalties: all corners inside [0,1]^2
    for cx, cy, a, side in squares:
        pts = _corners(cx, cy, a, side)
        for px, py in pts:
            if px < 0:
                s += barrier * px * px
            elif px > 1:
                s += barrier * (px - 1) * (px - 1)
            if py < 0:
                s += barrier * py * py
            elif py > 1:
                s += barrier * (py - 1) * (py - 1)

    # pairwise non-overlap: penalize overlap gaps
    for i in range(n):
        for j in range(i + 1, n):
            g = _sat_gap(squares[i], squares[j])
            if g < 0:
                s += barrier * g * g

    return s


def _initial_grid(n):
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]


def _to_x(squares):
    x = []
    for cx, cy, a, side in squares:
        x.extend([cx, cy, a, side])
    return np.array(x, dtype=float)


def solve(n):
    if n <= 0:
        return []
    start = time.time()
    limit = 55.0

    best = _initial_grid(n)
    best_score = sum(s[3] for s in best)

    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # number of random restarts depends on n
    seed = _initial_grid(n)

    def pack_score(sqs):
        for cx, cy, a, side in sqs:
            if side < 0:
                return -1e18
        for i in range(n):
            for j in range(i + 1, n):
                if _sat_gap(sqs[i], sqs[j]) < -1e-9:
                    return -1e18
        for cx, cy, a, side in sqs:
            for px, py in _corners(cx, cy, a, side):
                if px < -1e-9 or px > 1 + 1e-9 or py < -1e-9 or py > 1 + 1e-9:
                    return -1e18
        return sum(s[3] for s in sqs)

    # try a few structured starts
    starts = []
    starts.append(_to_x(seed))

    # random perturbations of the grid
    rng = random.Random(12345)
    for _ in range(8):
        sq = []
        for i in range(n):
            if i < len(seed):
                cx, cy, a, side = seed[i]
            else:
                cx, cy, a, side = 0.5, 0.5, 0.0, 0.0
            if side > 0:
                sq.append((min(1, max(0, cx + rng.uniform(-0.05, 0.05))),
                           min(1, max(0, cy + rng.uniform(-0.05, 0.05))),
                           a + rng.uniform(-0.02, 0.02),
                           max(1e-6, side * rng.uniform(0.85, 1.05))))
            else:
                sq.append((0.5, 0.5, 0.0, 0.0))
        starts.append(_to_x(sq[:n]))

    # run L-BFGS-B for each start with increasing barrier
    for x0 in starts:
        if time.time() - start > limit:
            break
        x = x0.copy()
        for barrier in (10.0, 100.0, 1000.0, 10000.0):
            if time.time() - start > limit:
                break
            try:
                res = minimize(_objective, x, args=(n, barrier),
                               method='L-BFGS-B',
                               options={'maxiter': 300, 'ftol': 1e-12, 'gtol': 1e-8})
                x = res.x
            except Exception:
                pass
        sq = _extract(x, n)
        sc = pack_score(sq)
        if sc > best_score:
            best_score = sc
            best = sq

    # final local polish with a large barrier
    if time.time() - start < limit:
        x = _to_x(best)
        try:
            res = minimize(_objective, x, args=(n, 1e5),
                           method='L-BFGS-B',
                           options={'maxiter': 500, 'ftol': 1e-14, 'gtol': 1e-10})
            sq = _extract(res.x, n)
            sc = pack_score(sq)
            if sc > best_score:
                best_score = sc
                best = sq
        except Exception:
            pass

    # clamp all to [0,1] and clean tiny violations
    cleaned = []
    for cx, cy, a, side in best:
        side = max(0.0, float(side))
        if side < 1e-12:
            cleaned.append((0.5, 0.5, 0.0, 0.0))
            continue
        # ensure corners inside; if not, shrink slightly
        lo, hi = 0.0, side
        for _ in range(30):
            mid = (lo + hi) / 2
            pts = _corners(cx, cy, a, mid)
            ok = all(0 <= px <= 1 and 0 <= py <= 1 for px, py in pts)
            if ok:
                lo = mid
            else:
                hi = mid
        s2 = lo
        cleaned.append((min(1, max(0, cx)), min(1, max(0, cy)),
                        a % 1.0, s2))

    # final overlap resolution: if any overlap, shrink smaller one
    changed = True
    while changed:
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                if cleaned[i][3] <= 0 or cleaned[j][3] <= 0:
                    continue
                if _sat_gap(cleaned[i], cleaned[j]) < -1e-9:
                    if cleaned[i][3] >= cleaned[j][3]:
                        c = cleaned[i]
                        cleaned[i] = (c[0], c[1], c[2], c[3] * 0.995)
                    else:
                        c = cleaned[j]
                        cleaned[j] = (c[0], c[1], c[2], c[3] * 0.995)
                    changed = True

    return [tuple(map(float, s)) for s in cleaned[:n]]
