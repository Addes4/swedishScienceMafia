import math
import random
import numpy as np
from scipy.optimize import minimize


def _overlap_penalty(params, n):
    """Penalty for interiors overlapping and going outside [0,1]^2.
    params: length 3n (cx, cy, side). angle fixed to 0 for this penalty."""
    total = 0.0
    for i in range(n):
        cx = params[3*i]
        cy = params[3*i+1]
        s = params[3*i+2]
        if s <= 0:
            continue
        h = s / 2.0
        # boundary violation
        lo_x = 0.0 - (cx - h)
        lo_y = 0.0 - (cy - h)
        hi_x = (cx + h) - 1.0
        hi_y = (cy + h) - 1.0
        for v in (lo_x, lo_y, hi_x, hi_y):
            if v > 0:
                total += v * v
    for i in range(n):
        cxi = params[3*i]
        cyi = params[3*i+1]
        si = params[3*i+2]
        if si <= 0:
            continue
        for j in range(i+1, n):
            cxj = params[3*j]
            cyj = params[3*j+1]
            sj = params[3*j+2]
            if sj <= 0:
                continue
            # axis-aligned overlap
            ox = (si + sj) / 2.0 - abs(cxi - cxj)
            oy = (si + sj) / 2.0 - abs(cyi - cyj)
            if ox > 0 and oy > 0:
                total += ox * oy
    return total


def _feasible(squares):
    n = len(squares)
    for i in range(n):
        cx, cy, ang, s = squares[i]
        if s <= 0:
            continue
        if ang == 0.0:
            h = s / 2.0
            if cx - h < -1e-9 or cx + h > 1.0 + 1e-9 or cy - h < -1e-9 or cy + h > 1.0 + 1e-9:
                return False
    for i in range(n):
        cxi, cyi, angi, si = squares[i]
        if si <= 0:
            continue
        for j in range(i+1, n):
            cxj, cyj, angj, sj = squares[j]
            if sj <= 0:
                continue
            if angi == 0.0 and angj == 0.0:
                if abs(cxi - cxj) < (si+sj)/2.0 - 1e-9 and abs(cyi - cyj) < (si+sj)/2.0 - 1e-9:
                    return False
            else:
                # use SAT for general case
                if _sat_overlap(cxi, cyi, angi, si, cxj, cyj, angj, sj):
                    return False
    return True


def _sat_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    t1 = a1 * 2 * math.pi
    t2 = a2 * 2 * math.pi
    h1 = s1 / 2.0
    h2 = s2 / 2.0
    def corners(cx, cy, t, h):
        c, si = math.cos(t), math.sin(t)
        return [(cx + c*h - si*h, cy + si*h + c*h),
                (cx + c*h + si*h, cy + si*h - c*h),
                (cx - c*h + si*h, cy - si*h - c*h),
                (cx - c*h - si*h, cy - si*h + c*h)]
    p1 = corners(cx1, cy1, t1, h1)
    p2 = corners(cx2, cy2, t2, h2)
    axes = []
    for p in (p1, p2):
        for k in range(4):
            x1, y1 = p[k]
            x2, y2 = p[(k+1) % 4]
            ex, ey = x2 - x1, y2 - y1
            axes.append((-ey, ex))
    for ax, ay in axes:
        nrm = math.hypot(ax, ay)
        if nrm < 1e-12:
            continue
        ax /= nrm
        ay /= nrm
        min1 = min(px*ax + py*ay for px, py in p1)
        max1 = max(px*ax + py*ay for px, py in p1)
        min2 = min(px*ax + py*ay for px, py in p2)
        max2 = max(px*ax + py*ay for px, py in p2)
        if max1 <= min2 + 1e-9 or max2 <= min1 + 1e-9:
            return False
    return True


def _separate_positions(cx, cy, s):
    return cx, cy


def _pack_axis_aligned(n, iterations=200, seed=42):
    """Greedy: try random feasible configurations of axis-aligned squares,
    keep best by total side length."""
    rng = random.Random(seed)
    best = None
    best_score = -1.0

    for trial in range(iterations):
        # random sizes
        sizes = [rng.uniform(0.02, 0.4) for _ in range(n)]
        sizes.sort(reverse=True)
        squares = []
        # place greedily with random order / rejection
        for s in sizes:
            placed = False
            for _ in range(200):
                cx = rng.uniform(s/2, 1 - s/2)
                cy = rng.uniform(s/2, 1 - s/2)
                ok = True
                for (px, py, pa, ps) in squares:
                    if pa == 0.0 and ps > 0:
                        if abs(cx - px) < (s + ps)/2 and abs(cy - py) < (s + ps)/2:
                            ok = False
                            break
                if ok:
                    squares.append((cx, cy, 0.0, s))
                    placed = True
                    break
            # if not placed, add as zero
            if not placed:
                squares.append((0.5, 0.5, 0.0, 0.0))
        squares = squares[:n]
        score = sum(q[3] for q in squares)
        if score > best_score:
            best_score = score
            best = [list(q) for q in squares]

    return best, best_score


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_squares = None
    best_score = -1.0

    # candidate seeds
    k = int(math.isqrt(n))
    # grid candidate
    if k >= 1:
        side = 1.0 / k
        grid = []
        cnt = 0
        for i in range(k):
            for j in range(k):
                if cnt < n:
                    grid.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
                    cnt += 1
        while len(grid) < n:
            grid.append([0.5, 0.5, 0.0, 0.0])
        grid = grid[:n]
        sc = sum(g[3] for g in grid)
        best_squares = grid
        best_score = sc

    # try random packing
    tries = 40 if n <= 30 else 15
    pack, sc = _pack_axis_aligned(n, iterations=tries, seed=n*13+7)
    if sc > best_score:
        best_score = sc
        best_squares = pack

    # Now do local optimization: try to grow each square.
    squares = [list(q) for q in best_squares]
    # repeatedly attempt to increase each square
    improved = True
    rounds = 0
    max_rounds = 60
    rng = random.Random(n * 31 + 17)

    while improved and rounds < max_rounds:
        improved = False
        rounds += 1
        # sort indices by current size ascending
        order = sorted(range(n), key=lambda i: squares[i][3])
        for idx in order:
            cx, cy, ang, s = squares[idx]
            # try to grow
            grow = min(1.0 - s, 0.05)
            if grow <= 1e-9:
                continue
            # binary search max feasible growth with random position jitter
            for attempt in range(8):
                delta = grow * (0.5 + 0.5 * rng.random())
                new_s = min(s + delta, 1.0)
                new_cx = cx + rng.uniform(-0.02, 0.02)
                new_cy = cy + rng.uniform(-0.02, 0.02)
                new_cx = min(max(new_cx, new_s/2), 1 - new_s/2)
                new_cy = min(max(new_cy, new_s/2), 1 - new_s/2)
                # check feasibility
                temp = [list(q) for q in squares]
                temp[idx] = [new_cx, new_cy, 0.0, new_s]
                feasible = True
                # boundary
                h = new_s / 2.0
                if new_cx - h < -1e-9 or new_cx + h > 1 + 1e-9 or new_cy - h < -1e-9 or new_cy + h > 1 + 1e-9:
                    feasible = False
                else:
                    for j in range(n):
                        if j == idx:
                            continue
                        ox, oy, oa, os_ = temp[j]
                        if os_ <= 0:
                            continue
                        if abs(new_cx - ox) < (new_s + os_)/2 - 1e-9 and abs(new_cy - oy) < (new_s + os_)/2 - 1e-9:
                            feasible = False
                            break
                if feasible:
                    squares[idx] = [new_cx, new_cy, 0.0, new_s]
                    improved = True
                    break

    final_score = sum(q[3] for q in squares)
    if final_score > best_score:
        best_score = final_score
        best_squares = squares

    # ensure final feasibility (clip tiny overlaps by shrinking)
    result = [list(q) for q in best_squares]
    for _ in range(10):
        if _feasible(result):
            break
        # shrink all positive squares slightly
        for q in result:
            if q[3] > 0:
                q[3] *= 0.995
        # re-check
    # final safety: convert zero sizes properly
    out = []
    for q in result:
        cx, cy, ang, s = q
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        s = max(0.0, min(s, 1.0))
        out.append((cx, cy, 0.0, s))
    return out[:n]
