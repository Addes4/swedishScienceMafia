import math
import random
import itertools
from typing import List, Tuple

# Optional scipy/numpy are allowed, but this pure-python implementation is robust.
try:
    import numpy as np
except Exception:
    np = None


def _overlap_area(c1, s1, a1, c2, s2, a2) -> float:
    """Return area of intersection of two squares (centre, side, angle-in-turns)."""
    if s1 <= 0.0 or s2 <= 0.0:
        return 0.0
    # Conservative bounding-circle overlap test (rotated rectangle can be inside
    # circumscribed circle of radius s*sqrt(2)/2; if circles don't overlap, no overlap).
    r1 = s1 * 0.7071067811865476
    r2 = s2 * 0.7071067811865476
    dx = c1[0] - c2[0]
    dy = c1[1] - c2[1]
    if dx * dx + dy * dy >= (r1 + r2) * (r1 + r2):
        return 0.0

    # Separating Axis Theorem for two rotated rectangles.
    def corners(cx, cy, s, a):
        t = a * 2.0 * math.pi
        co, si = math.cos(t), math.sin(t)
        h = s * 0.5
        pts = []
        for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            pts.append((cx + co * sx - si * sy, cy + si * sx + co * sy))
        return pts

    A = corners(c1[0], c1[1], s1, a1)
    B = corners(c2[0], c2[1], s2, a2)

    def axes(P):
        out = []
        for i in range(4):
            x1, y1 = P[i]
            x2, y2 = P[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            n = math.hypot(ex, ey)
            if n > 0:
                out.append((-ey / n, ex / n))
        return out

    for ax in axes(A) + axes(B):
        pa = [p[0] * ax[0] + p[1] * ax[1] for p in A]
        pb = [p[0] * ax[0] + p[1] * ax[1] for p in B]
        if max(pa) <= min(pb) + 1e-12 or max(pb) <= min(pa) + 1e-12:
            return 0.0

    # They intersect in positive area (or touch).  Compute area by clipping.
    # Clip polygon A by each edge of B.
    def clip(poly, a, b):
        # keep points on left side of directed line a->b
        ex, ey = b[0] - a[0], b[1] - a[1]
        nx, ny = -ey, ex
        res = []
        if not poly:
            return res
        def side(p):
            return (p[0] - a[0]) * nx + (p[1] - a[1]) * ny

        for i in range(len(poly)):
            p = poly[i]
            q = poly[(i + 1) % len(poly)]
            sp = side(p)
            sq = side(q)
            if sp >= -1e-15:
                res.append(p)
            if (sp > 1e-15 and sq < -1e-15) or (sp < -1e-15 and sq > 1e-15):
                t = sp / (sp - sq)
                res.append((p[0] + t * (q[0] - p[0]), p[1] + t * (q[1] - p[1])))
        return res

    poly = A
    for i in range(4):
        poly = clip(poly, B[i], B[(i + 1) % 4])
        if len(poly) < 3:
            return 0.0

    area = 0.0
    for i in range(len(poly)):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % len(poly)]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def _inside(c, s, a) -> bool:
    """Does square lie completely inside [0,1]^2?"""
    if s <= 0.0:
        return True
    t = a * 2.0 * math.pi
    co, si = math.cos(t), math.sin(t)
    h = s * 0.5
    for sx, sy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = c[0] + co * sx - si * sy
        y = c[1] + si * sx + co * sy
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


def _valid(sqs) -> bool:
    n = len(sqs)
    for i in range(n):
        c, a, s = sqs[i]
        if s < 0 or s > 1.0 + 1e-12:
            return False
        if not _inside(c, s, a):
            return False
    for i in range(n):
        for j in range(i + 1, n):
            c1, a1, s1 = sqs[i]
            c2, a2, s2 = sqs[j]
            if _overlap_area(c1, s1, a1, c2, s2, a2) > 1e-10:
                return False
    return True


def _total(sqs) -> float:
    return sum(s for _, _, s in sqs)


def _grid_solution(n, k=None):
    if k is None:
        k = math.isqrt(n)
    if k <= 0:
        return [((0.5, 0.5, 0.0, 0.0)) for _ in range(n)]
    side = 1.0 / k
    sqs = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    sqs += [((0.5, 0.5, 0.0, 0.0))] * (n - len(sqs))
    return sqs[:n]


def _try_insert(sqs, cand, iters=1):
    """Try to insert candidate square (x,y,a,s) replacing zeros / improving weak ones."""
    cand_x, cand_y, cand_a, cand_s = cand
    if cand_s <= 0:
        return sqs, False
    best_gain = -1
    best_idx = -1
    for i, (c, a, s) in enumerate(sqs):
        if s <= 1e-12:
            # Free slot: test directly.
            news = sqs[:]
            news[i] = ((cand_x, cand_y, 0), cand_a, cand_s)
            if _valid([(q[0], q[1], q[2]) for q in news]):
                return news, True
        else:
            # Can we replace this square by the candidate with gain?
            if cand_s > s:
                news = sqs[:]
                news[i] = ((cand_x, cand_y, 0), cand_a, cand_s)
                if _valid([(q[0], q[1], q[2]) for q in news]):
                    gain = cand_s - s
                    if gain > best_gain:
                        best_gain = gain
                        best_idx = i
    if best_idx >= 0:
        news = sqs[:]
        news[best_idx] = ((cand_x, cand_y, 0), cand_a, cand_s)
        return news, True
    return sqs, False


def _local_opt(sqs, time_budget=1.0):
    """Greedily shrink/move/rotate to improve while keeping validity."""
    import time
    start = time.time()
    n = len(sqs)
    improved = True
    cur = [((c[0], c[1]), a, s) for c, a, s in sqs]

    def build(curs):
        return [((c[0], c[1], a, s)) for c, a, s in curs]

    def valid_curs(curs):
        return _valid([(c, a, s) for c, a, s in curs])

    while improved and time.time() - start < time_budget:
        improved = False
        for i in range(n):
            if time.time() - start > time_budget:
                break
            c, a, s = cur[i]
            if s <= 1e-12:
                continue
            best_s = s
            best_c = c
            best_a = a
            # try growing / shifting / rotating
            for da in (0.0, 0.25, 0.125, -0.125, 0.0625, -0.0625):
                aa = (a + da) % 1.0
                for ds in (0.0, 0.02, 0.005, -0.01):
                    ss = s + ds
                    if ss <= 1e-12:
                        continue
                    # try shifts
                    for dx, dy in ((0, 0), (0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01),
                                   (0.005, 0.005), (-0.005, 0.005), (0.005, -0.005), (-0.005, -0.005)):
                        nc = (c[0] + dx, c[1] + dy)
                        if nc[0] < 0 or nc[0] > 1 or nc[1] < 0 or nc[1] > 1:
                            continue
                        if not _inside(nc, ss, aa):
                            continue
                        tmp = cur[:]
                        tmp[i] = (nc, aa, ss)
                        if valid_curs(tmp):
                            if ss > best_s + 1e-9:
                                best_s, best_c, best_a = ss, nc, aa
            if best_s > s + 1e-9:
                cur[i] = (best_c, best_a, best_s)
                improved = True
        # also try improvement by pairwise swaps? skip for time.
    return build(cur)


def _candidate_sizes_and_positions(n):
    """Generate diverse candidate squares."""
    cands = []
    # grid-based candidates
    for k in range(1, min(n + 2, 12)):
        s = 1.0 / k
        for i in range(k):
            for j in range(k):
                cx = (i + 0.5) * s
                cy = (j + 0.5) * s
                for ang in (0.0, 0.125, 0.25):
                    cands.append((cx, cy, ang, s * 0.999))
    # random size candidates
    rnd = random.Random(12345)
    for _ in range(300):
        s = rnd.random() * 0.5 + 0.02
        cx = rnd.random()
        cy = rnd.random()
        ang = rnd.choice([0.0, 0.125, 0.25, 0.375, 0.5])
        cands.append((cx, cy, ang, s))
    # small exact-ish nice values
    for s in (1.0, 0.5, 1/3, 0.25, 1/5, 1/6, 0.2, 0.15, 0.125, 0.1,
              0.333333, 0.211324865, 0.267949192):
        for cx in (s/2, 0.5, 1 - s/2):
            for cy in (s/2, 0.5, 1 - s/2):
                cands.append((cx, cy, 0.0, s))
                cands.append((cx, cy, 0.25, s))
    return cands


def solve(n: int):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Start from several baselines and greedily improve.
    best = None
    best_total = -1.0

    # Grid starters for several k
    starters = []
    for k in range(1, min(n, 8) + 1):
        if k * k <= n:
            starters.append(_grid_solution(n, k))
    if not starters:
        starters.append(_grid_solution(n))

    cands = _candidate_sizes_and_positions(n)

    for base in starters:
        cur = [((c[0], c[1]), a, s) for (c, a, s) in base]
        # fill zeros with best candidates greedily
        changed = True
        rounds = 0
        while changed and rounds < 5:
            changed = False
            rounds += 1
            for cand in cands:
                cx, cy, ang, s = cand
                # try replace a zero or improve a square
                for i in range(n):
                    c, a, ss = cur[i]
                    if ss <= 1e-12:
                        test = cur[:]
                        test[i] = ((cx, cy), ang, s)
                        if _valid([(q[0], q[1], q[2]) for q in test]):
                            cur = test
                            changed = True
                            break
                if changed:
                    break
        # local search
        cur = _local_opt(cur, time_budget=0.8)
        total = sum(s for _, _, s in cur)
        if total > best_total + 1e-9:
            best_total = total
            best = cur

    # For small n, try exact / near-exact known configurations.
    if n <= 4:
        # n=2: two 0.5 squares side by side
        if n == 2:
            cand = [((0.25, 0.5), 0.0, 0.5), ((0.75, 0.5), 0.0, 0.5)]
            if _valid([(c, a, s) for c, a, s in cand]) and sum(s for _, _, s in cand) > best_total:
                best = cand
        # n=3: three squares, known good is two on bottom, one top left/right etc.
        if n == 3:
            for trial in [
                [((0.25, 0.25), 0.0, 0.5), ((0.75, 0.25), 0.0, 0.5), ((0.25, 0.75), 0.0, 0.5)],
                [((0.25, 0.25), 0.0, 0.5), ((0.75, 0.25), 0.0, 0.5), ((0.5, 0.75), 0.0, 0.5)],
            ]:
                if _valid([(c, a, s) for c, a, s in trial]) and sum(s for _, _, s in trial) > best_total:
                    best = trial
        # n=4: four 0.5x0.5
        if n == 4:
            trial = [((0.25, 0.25), 0.0, 0.5), ((0.75, 0.25), 0.0, 0.5),
                     ((0.25, 0.75), 0.0, 0.5), ((0.75, 0.75), 0.0, 0.5)]
            if _valid([(c, a, s) for c, a, s in trial]) and sum(s for _, _, s in trial) > best_total:
                best = trial

    if best is None:
        best = _grid_solution(n)

    # Final guarantee valid.
    out = []
    for c, a, s in best:
        out.append((float(c[0]), float(c[1]), float(a), float(s)))
    out = out[:n]
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out
