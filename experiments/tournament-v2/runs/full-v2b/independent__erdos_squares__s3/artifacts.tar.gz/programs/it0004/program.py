import math
import random

# Optional numpy/scipy are allowed; use plain lists for portability and speed.

def _overlap_sq(s1, s2):
    """Return True if two squares have positive-area overlap.
    Square: (cx, cy, angle_fraction, side)
    Use separating-axis test for rotated squares.
    """
    cx1, cy1, a1, s1v = s1
    cx2, cy2, a2, s2v = s2
    if s1v <= 0 or s2v <= 0:
        return False
    th1 = a1 * 2.0 * math.pi
    th2 = a2 * 2.0 * math.pi
    ux1, uy1 = math.cos(th1), math.sin(th1)
    vx1, vy1 = -uy1, ux1
    ux2, uy2 = math.cos(th2), math.sin(th2)
    vx2, vy2 = -uy2, ux2
    r1 = s1v * 0.5
    r2 = s2v * 0.5
    # half-extents along axes
    axes = [(ux1, uy1), (vx1, vy1), (ux2, uy2), (vx2, vy2)]
    dx = cx2 - cx1
    dy = cy2 - cy1
    for ax, ay in axes:
        # projection radius of square1 on axis
        p1 = abs(ax * ux1 + ay * uy1) * r1 + abs(ax * vx1 + ay * vy1) * r1
        p2 = abs(ax * ux2 + ay * uy2) * r2 + abs(ax * vx2 + ay * vy2) * r2
        d = abs(dx * ax + dy * ay)
        if d > p1 + p2 - 1e-12:
            return False
    return True


def _inside_unit(s):
    cx, cy, a, side = s
    if side <= 0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    r = side * 0.5
    th = a * 2.0 * math.pi
    c, si = math.cos(th), math.sin(th)
    # four corners
    for sx, sy in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
        x = cx + r * sx * c - r * sy * si
        y = cy + r * sx * si + r * sy * c
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


def _valid(squares):
    for s in squares:
        if not _inside_unit(s):
            return False
    n = len(squares)
    for i in range(n):
        si = squares[i]
        if si[3] <= 0:
            continue
        for j in range(i + 1, n):
            sj = squares[j]
            if sj[3] <= 0:
                continue
            if _overlap_sq(si, sj):
                return False
    return True


def _score(squares):
    return sum(s[3] for s in squares)


def _grid_init(n):
    """Initial packing: k x k grid plus possibly some size-zero squares.
    Also try k x (k+1) style split when better for certain n.
    """
    if n == 0:
        return []
    best = None
    best_val = -1.0
    k = max(1, int(math.sqrt(n)))
    for kk in range(max(1, k - 2), k + 3):
        # full kk^2 grid
        if kk * kk <= n:
            side = 1.0 / kk
            sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                  for i in range(kk) for j in range(kk)]
            sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
            # can sometimes add extra squares by shrinking: try add one row/col
        # mixed: a x b grid where a*b <= n
        for a in range(1, n + 1):
            b = n // a
            if a * b == 0:
                continue
            if a * b <= n:
                sa = 1.0 / a
                sb = 1.0 / b
                if a == b:
                    continue
                vals = min(sa, sb)
                # only reasonable if close to square
                if abs(a - b) <= 1:
                    sq = []
                    for i in range(a):
                        for j in range(b):
                            sq.append(((i + 0.5) * sa, (j + 0.5) * sb, 0.0, min(sa, sb)))
                    sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
                    v = _score(sq)
                    if v > best_val and _valid(sq):
                        best_val = v
                        best = sq
        side = 1.0 / kk
        sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
              for i in range(kk) for j in range(kk)]
        sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        v = _score(sq)
        if v > best_val and _valid(sq):
            best_val = v
            best = sq
    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0) for _ in range(n)]
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # three squares in a row, all same size
        return [(0.5 / 3, 0.5, 0.0, 1.0 / 3),
                (1.5 / 3, 0.5, 0.0, 1.0 / 3),
                (2.5 / 3, 0.5, 0.0, 1.0 / 3)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    squares = _grid_init(n)
    best = [list(s) for s in squares]
    best_val = _score(best)

    # Heuristic: exact row/column layout often optimal for and near perfect squares.
    # Try to improve by local optimization for a limited time.
    # Use deterministic + random search.
    random.seed(12345 + n)
    limit = 3.0  # seconds approximately; adjust by n
    if n > 50:
        limit = 1.5

    import time
    t0 = time.time()

    # Normalize order: largest first
    squares = sorted(squares, key=lambda s: -s[3])
    # Local search
    cur = [list(s) for s in squares]
    cur_val = _score(cur)

    # For large n, focus on many equal-size squares in a near grid.
    if n > 16:
        # Try progressive shrinking of all squares, then expand individual ones.
        for _ in range(50):
            if time.time() - t0 > limit:
                break
            # shrink all by tiny amount
            factor = random.uniform(0.92, 0.995)
            cand = [s[:] for s in cur]
            for s in cand:
                s[3] *= factor
            # try expand random subset
            idxs = list(range(n))
            random.shuffle(idxs)
            for i in idxs:
                if time.time() - t0 > limit:
                    break
                s = cand[i]
                old = s[3]
                s[3] = min(1.0, old + random.uniform(0.001, 0.05))
                if not _valid(cand):
                    s[3] = old
                else:
                    # move center to fit
                    pass
            val = _score(cand)
            if val > cur_val:
                cur = cand
                cur_val = val

    # General random local search
    step_sizes = [0.05, 0.02, 0.01, 0.005, 0.002, 0.001]
    for it in range(4000):
        if time.time() - t0 > limit:
            break
        cand = [s[:] for s in cur]
        # Choose a subset to perturb
        k = random.randint(1, min(n, 4))
        idxs = random.sample(range(n), k)
        for i in idxs:
            s = cand[i]
            sx, sy, aa, side = s
            # perturb center or angle or side
            choice = random.random()
            if choice < 0.4:
                sx += random.choice([-1, 1]) * random.uniform(0, 0.05)
                sy += random.choice([-1, 1]) * random.uniform(0, 0.05)
            elif choice < 0.7:
                aa = (aa + random.uniform(-0.02, 0.02)) % 1.0
            else:
                side = max(0.0, side + random.choice([-1, 1]) * random.uniform(0, 0.03))
            # clamp center inside
            sx = min(1.0, max(0.0, sx))
            sy = min(1.0, max(0.0, sy))
            # try to make it fit
            cand[i] = [sx, sy, aa, side]
            # if invalid, try shrinking
            if not _inside_unit(cand[i]):
                cand[i][3] = 0.0
        if _valid(cand):
            val = _score(cand)
            if val > cur_val - 1e-9:
                cur = cand
                cur_val = val
                if val > best_val:
                    best = [row[:] for row in cur]
                    best_val = val
        else:
            # attempt repair: shrink overlapping squares
            for _rep in range(5):
                for i in range(n):
                    if not _inside_unit(cand[i]):
                        cand[i][3] *= 0.9
                if _valid(cand):
                    break
            if _valid(cand):
                val = _score(cand)
                if val > cur_val:
                    cur = cand
                    cur_val = val
                    if val > best_val:
                        best = [row[:] for row in cur]
                        best_val = val

    # Ensure all squares are in [0,1] and valid; zero out problematic ones.
    res = []
    for s in best:
        cx = min(1.0, max(0.0, s[0]))
        cy = min(1.0, max(0.0, s[1]))
        a = s[2] % 1.0
        side = max(0.0, min(1.0, s[3]))
        res.append((cx, cy, a, side))
    # Validate and zero out any remaining overlaps quickly
    for i in range(n):
        if res[i][3] <= 0:
            res[i] = (0.5, 0.5, 0.0, 0.0)
    # simple greedy fix: if overlap, reduce later one
    for i in range(n):
        for j in range(i + 1, n):
            if res[i][3] > 0 and res[j][3] > 0 and _overlap_sq(res[i], res[j]):
                res[j] = (res[j][0], res[j][1], res[j][2], 0.0)
    return res
