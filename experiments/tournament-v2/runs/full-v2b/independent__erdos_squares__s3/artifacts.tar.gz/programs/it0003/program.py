import math
import random
import time

def solve(n):
    if n <= 0:
        return []
    best = None
    best_score = -1.0
    deadline = time.time() + 55.0
    random.seed(12345 + n)

    def rand_init():
        sq = []
        # start with grid-like coverage
        k = int(math.sqrt(n))
        if k < 1:
            k = 1
        used = 0
        for i in range(k):
            for j in range(k):
                if used >= n:
                    break
                cx = (i + 0.5) / k
                cy = (j + 0.5) / k
                s = 1.0 / k
                sq.append([cx, cy, 0.0, s])
                used += 1
            if used >= n:
                break
        while len(sq) < n:
            sq.append([random.uniform(0.2, 0.8), random.uniform(0.2, 0.8), random.choice([0.0,0.25,0.5,0.75]), random.uniform(0.01, 0.15)])
        return sq

    def score(sq):
        # total side length (maximize)
        return sum(s[3] for s in sq)

    def overlap_area(a, b):
        # approximate using corners for rotated squares via polygon clipping (Sutherland-Hodgman)
        def poly(s):
            cx, cy, ang, side = s
            ang *= 2*math.pi
            ca, sa = math.cos(ang), math.sin(ang)
            h = side/2.0
            pts = [(-h,-h),(h,-h),(h,h),(-h,h)]
            return [(cx + x*ca - y*sa, cy + x*sa + y*ca) for x,y in pts]
        def inside(p, cp):
            # convex polygon inside test
            sign = None
            for i in range(len(cp)):
                x1,y1 = cp[i]
                x2,y2 = cp[(i+1)%len(cp)]
                cross = (x2-x1)*(p[1]-y1) - (y2-y1)*(p[0]-x1)
                if sign is None:
                    sign = cross >= -1e-12
                elif (cross >= -1e-12) != sign:
                    return False
            return True
        def clip(subject, clipper):
            out = subject[:]
            for i in range(len(clipper)):
                if not out:
                    break
                x1,y1 = clipper[i]
                x2,y2 = clipper[(i+1)%len(clipper)]
                inp = out
                out = []
                if inp:
                    s = inp[-1]
                    for e in inp:
                        # inside edge?
                        def cross(p):
                            return (x2-x1)*(p[1]-y1) - (y2-y1)*(p[0]-x1)
                        s_in = cross(s) >= -1e-12
                        e_in = cross(e) >= -1e-12
                        if e_in:
                            if not s_in:
                                # intersection
                                dx1,dy1 = e[0]-s[0], e[1]-s[1]
                                dx2,dy2 = x2-x1, y2-y1
                                denom = dx1*dy2 - dy1*dx2
                                if abs(denom) > 1e-18:
                                    t = ((x1-s[0])*dy2 - (y1-s[1])*dx2)/denom
                                    out.append((s[0]+t*dx1, s[1]+t*dy1))
                            out.append(e)
                        elif s_in:
                            dx1,dy1 = e[0]-s[0], e[1]-s[1]
                            dx2,dy2 = x2-x1, y2-y1
                            denom = dx1*dy2 - dy1*dx2
                            if abs(denom) > 1e-18:
                                t = ((x1-s[0])*dy2 - (y1-s[1])*dx2)/denom
                                out.append((s[0]+t*dx1, s[1]+t*dy1))
                        s = e
            return out
        pa = poly(a)
        pb = poly(b)
        inter = clip(pa, pb)
        if len(inter) < 3:
            return 0.0
        area = 0.0
        for i in range(len(inter)):
            x1,y1 = inter[i]
            x2,y2 = inter[(i+1)%len(inter)]
            area += x1*y2 - x2*y1
        return abs(area)/2.0

    def eval_pen(sq):
        pen = 0.0
        # boundary
        for cx, cy, ang, side in sq:
            h = side/2.0
            # bounding circle for rotated square
            r = h*math.sqrt(2)
            if cx - r < -1e-9: pen += (r - cx)*10
            if cx + r > 1+1e-9: pen += (cx + r - 1)*10
            if cy - r < -1e-9: pen += (r - cy)*10
            if cy + r > 1+1e-9: pen += (cy + r - 1)*10
            if side < 0: pen += -side*10
        # overlaps
        m = len(sq)
        for i in range(m):
            for j in range(i+1, m):
                if sq[i][3] < 1e-9 or sq[j][3] < 1e-9:
                    continue
                ov = overlap_area(sq[i], sq[j])
                if ov > 1e-12:
                    pen += ov * 100.0
        return pen

    def run_local(sq):
        # simple coordinate descent / random perturbation hill climb
        cur = [list(s) for s in sq]
        cur_pen = eval_pen(cur)
        cur_sc = score(cur)
        step = 0.05
        for it in range(3000):
            if time.time() > deadline:
                break
            i = random.randrange(len(cur))
            old = list(cur[i])
            # mutate
            typ = random.random()
            if typ < 0.25:
                cur[i][0] = min(1.0, max(0.0, cur[i][0] + random.gauss(0, step)))
            elif typ < 0.5:
                cur[i][1] = min(1.0, max(0.0, cur[i][1] + random.gauss(0, step)))
            elif typ < 0.7:
                cur[i][2] = (cur[i][2] + random.gauss(0, step)) % 1.0
            else:
                cur[i][3] = min(1.0, max(0.0, cur[i][3] + random.gauss(0, step)))
            new_pen = eval_pen(cur)
            new_sc = score(cur)
            if new_pen < cur_pen - 1e-12 or (abs(new_pen - cur_pen) < 1e-9 and new_sc > cur_sc + 1e-12):
                cur_pen = new_pen
                cur_sc = new_sc
                step *= 0.999
            else:
                cur[i] = old
            if random.random() < 0.01:
                step = random.uniform(0.01, 0.08)
        return cur, cur_pen, cur_sc

    # Try multiple starts
    for trial in range(6):
        if time.time() > deadline - 2:
            break
        sq = rand_init()
        res, pen, sc = run_local(sq)
        if pen < 1e-6 and sc > best_score:
            best_score = sc
            best = res

    if best is None:
        # fallback: grid
        k = math.isqrt(n)
        if k < 1:
            k = 1
        side = 1.0/k
        best = []
        for i in range(k):
            for j in range(k):
                if len(best) < n:
                    best.append([(i+0.5)*side, (j+0.5)*side, 0.0, side])
        while len(best) < n:
            best.append([0.5,0.5,0.0,0.0])

    # final cleanup: shrink squares slightly to ensure no violation
    # and clamp
    out = []
    for cx, cy, ang, side in best:
        side = max(0.0, min(1.0, side))
        r = side*math.sqrt(2)/2
        cx = min(1.0-r if r < 0.5 else 0.5, max(r if r < 0.5 else 0.5, cx))
        cy = min(1.0-r if r < 0.5 else 0.5, max(r if r < 0.5 else 0.5, cy))
        # shrink if still out
        if r > 0:
            maxr = min(cx, cy, 1.0-cx, 1.0-cy)
            if maxr < r:
                side = maxr/math.sqrt(2)*2
        out.append((cx, cy, ang % 1.0, side))
    return out
