import math
import random
import numpy as np
from scipy.optimize import minimize

# ------------------------------------------------------------
# Geometry helpers
# ------------------------------------------------------------

def corners(cx, cy, th, s):
    """Return the 4 corners of a rotated square."""
    c, sn = math.cos(2 * math.pi * th), math.sin(2 * math.pi * th)
    h = s * 0.5
    return [
        (cx + h * (c - sn), cy + h * (sn + c)),
        (cx + h * (c + sn), cy + h * (sn - c)),
        (cx - h * (c - sn), cy - h * (sn + c)),
        (cx - h * (c + sn), cy - h * (sn - c)),
    ]


def overlap_area(p, q):
    """Approximate convex polygon intersection area via clipping."""
    # Separating axis theorem based exact check first
    ax = p
    bx = q
    if len(ax) < 3 or len(bx) < 3:
        return 0.0

    def proj(poly, axis):
        d = [x * axis[0] + y * axis[1] for x, y in poly]
        return min(d), max(d)

    def axes(poly):
        n = len(poly)
        res = []
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 1e-15:
                res.append((-ey / ln, ex / ln))
        return res

    for a in axes(ax) + axes(bx):
        lo1, hi1 = proj(ax, a)
        lo2, hi2 = proj(bx, a)
        if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
            return 0.0

    # Sutherland-Hodgman clip
    def clip(subject, clip_poly):
        def inside(p, a, b):
            return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= -1e-12

        def intersect(p1, p2, a, b):
            x1, y1 = p1
            x2, y2 = p2
            x3, y3 = a
            x4, y4 = b
            den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
            if abs(den) < 1e-15:
                return p2
            px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / den
            py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / den
            return (px, py)

        output = subject
        cp = clip_poly
        for i in range(len(cp)):
            a = cp[i]
            b = cp[(i + 1) % len(cp)]
            inp = output
            output = []
            if not inp:
                break
            s = inp[-1]
            for e in inp:
                if inside(e, a, b):
                    if not inside(s, a, b):
                        output.append(intersect(s, e, a, b))
                    output.append(e)
                elif inside(s, a, b):
                    output.append(intersect(s, e, a, b))
                s = e
        return output

    inter = clip(ax, bx)
    if len(inter) < 3:
        return 0.0
    area = 0.0
    for i in range(len(inter)):
        x1, y1 = inter[i]
        x2, y2 = inter[(i + 1) % len(inter)]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def is_valid(sol):
    """Check all constraints with tolerance."""
    n = len(sol)
    polys = []
    for cx, cy, th, s in sol:
        if s < -1e-9:
            return False
        if not (-1e-9 <= cx <= 1 + 1e-9 and -1e-9 <= cy <= 1 + 1e-9):
            return False
        polys.append(corners(cx, cy, th, max(0.0, s)))
    for i in range(n):
        for j in range(i + 1, n):
            if overlap_area(polys[i], polys[j]) > 1e-7:
                return False
    # containment: all corners inside unit square
    for p in polys:
        for x, y in p:
            if x < -1e-7 or x > 1 + 1e-7 or y < -1e-7 or y > 1 + 1e-7:
                return False
    return True


# ------------------------------------------------------------
# Initial configurations
# ------------------------------------------------------------

def grid_init(n):
    """k x k grid plus a few optimized extra squares in leftover space."""
    k = math.isqrt(n)
    side = 1.0 / k
    sq = []
    for i in range(k):
        for j in range(k):
            sq.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    extra = n - k * k
    if extra > 0:
        # try to place extra small squares in gaps
        # With k x k grid, remaining area is 1 - k*(1/k)^2 = 1 - 1/k
        # simple: put them in a row along top/bottom with tiny size
        # We'll let optimizer handle sizing
        for i in range(extra):
            sq.append([(i + 0.5) / max(1, extra), 0.5, 0.0, 0.02])
    return sq


def hex_init(n):
    """Hexagonal-like arrangement: rows offset, optimized later."""
    if n <= 4:
        return grid_init(n)
    best = None
    best_score = -1
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if cols * rows < n:
            continue
        # estimate side
        s = min(1.0 / cols, 1.0 / rows)
        sq = []
        cnt = 0
        for r in range(rows):
            for c in range(cols):
                if cnt >= n:
                    break
                x = (c + 0.5) * s
                y = (r + 0.5) * s
                if r % 2 == 1:
                    x += s * 0.5
                    if x + s * 0.5 > 1.0:
                        x = 1.0 - s * 0.5
                sq.append([x, y, 0.0, s])
                cnt += 1
        if len(sq) == n:
            sc = sum(t[3] for t in sq)
            if sc > best_score:
                best_score = sc
                best = sq
    return best if best else grid_init(n)


# ------------------------------------------------------------
# Optimization
# ------------------------------------------------------------

def make_objective(n):
    def obj(x):
        return -sum(x[i * 4 + 3] for i in range(n))
    return obj


def optimize(n, init, maxiter=200):
    """Run SLSQP from init, return best solution."""
    # Variables: cx, cy, angle(normalized), side
    x0 = []
    for cx, cy, th, s in init:
        x0.append(cx)
        x0.append(cy)
        # normalize angle into [0, 1)
        th_norm = th % 1.0
        x0.append(th_norm)
        x0.append(max(0.0, s))
    x0 = np.array(x0, dtype=float)

    # Bounds: center in [0,1], angle [0,1), side [0,1]
    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))  # cx
        bounds.append((0.0, 1.0))  # cy
        bounds.append((0.0, 1.0))  # angle
        bounds.append((0.0, 1.0))  # side

    # Inequality constraints: g(x) >= 0
    def con_fun(x):
        cons = []
        # containment constraints: for each square, all corners inside [0,1]^2
        polys = []
        for i in range(n):
            cx, cy, th, s = x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]
            p = corners(cx, cy, th, s)
            polys.append(p)
            for (px, py) in p:
                cons.append(px - 0.0)
                cons.append(1.0 - px)
                cons.append(py - 0.0)
                cons.append(1.0 - py)
        # pairwise non-overlap: use approximate area constraints
        for i in range(n):
            for j in range(i + 1, n):
                a = overlap_area(polys[i], polys[j])
                cons.append(-a)  # -area >= 0 => area <= 0
        return np.array(cons)

    cons = {'type': 'ineq', 'fun': con_fun}

    try:
        res = minimize(
            lambda x: -sum(x[i * 4 + 3] for i in range(n)),
            x0,
            method='SLSQP',
            bounds=bounds,
            constraints=cons,
            options={'maxiter': maxiter, 'ftol': 1e-9, 'disp': False},
        )
        if res.success:
            sol = []
            for i in range(n):
                sol.append((
                    float(np.clip(res.x[4*i], 0, 1)),
                    float(np.clip(res.x[4*i+1], 0, 1)),
                    float(res.x[4*i+2] % 1.0),
                    max(0.0, float(res.x[4*i+3])),
                ))
            return sol, -res.fun
    except Exception:
        pass
    return init, sum(t[3] for t in init)


def solve(n):
    """Main entry."""
    if n <= 0:
        return []

    # try multiple initial configurations
    inits = []
    inits.append(grid_init(n))
    inits.append(hex_init(n))

    # random perturbations of grid
    random.seed(12345)
    for _ in range(3):
        base = grid_init(n)
        pert = []
        for cx, cy, th, s in base:
            pert.append([
                min(1.0, max(0.0, cx + random.uniform(-0.05, 0.05))),
                min(1.0, max(0.0, cy + random.uniform(-0.05, 0.05))),
                random.uniform(0, 1),
                max(0.0, s * random.uniform(0.9, 1.1)),
            ])
        inits.append(pert)

    best_sol = None
    best_score = -1.0

    for init in inits:
        sol, score = optimize(n, init, maxiter=150)
        if score > best_score:
            # verify correctness
            sol_clean = []
            for cx, cy, th, s in sol:
                # clamp
                cx = float(np.clip(cx, 0, 1))
                cy = float(np.clip(cy, 0, 1))
                th = float(th % 1.0)
                s = max(0.0, float(s))
                sol_clean.append((cx, cy, th, s))
            if is_valid(sol_clean):
                best_score = score
                best_sol = sol_clean

    # fallback
    if best_sol is None:
        best_sol = grid_init(n)
        best_score = sum(t[3] for t in best_sol)

    # ensure exactly n
    while len(best_sol) < n:
        best_sol.append((0.5, 0.5, 0.0, 0.0))
    best_sol = best_sol[:n]

    return best_sol
