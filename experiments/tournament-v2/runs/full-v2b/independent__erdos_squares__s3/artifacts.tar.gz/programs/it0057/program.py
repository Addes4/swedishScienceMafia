import math
import random
import numpy as np
from scipy.optimize import minimize

# ----------------------------------------------------------------------
# geometry helpers
# ----------------------------------------------------------------------
def unit_vectors(angle):
    """angle is a fraction of a full turn.  returns two orthonormal vectors"""
    t = 2.0 * math.pi * angle
    c, s = math.cos(t), math.sin(t)
    return np.array([c, s]), np.array([-s, c])


def corners(x, y, a, side):
    u, v = unit_vectors(a)
    h = 0.5 * side
    return np.array([
        [x + h * u[0] + h * v[0], y + h * u[1] + h * v[1]],
        [x + h * u[0] - h * v[0], y + h * u[1] - h * v[1]],
        [x - h * u[0] - h * v[0], y - h * u[1] - h * v[1]],
        [x - h * u[0] + h * v[0], y - h * u[1] + h * v[1]],
    ])


def outside_amount(cx, cy, a, side):
    """total amount by which the square sticks out of the unit square"""
    if side <= 0.0:
        return 0.0
    pts = corners(cx, cy, a, side)
    out = 0.0
    for p in pts:
        if p[0] < 0.0:
            out += -p[0]
        if p[0] > 1.0:
            out += p[0] - 1.0
        if p[1] < 0.0:
            out += -p[1]
        if p[1] > 1.0:
            out += p[1] - 1.0
    return out


def sat_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """approximate overlap penalty via separating axis theorem.
       returns positive value if the two squares overlap"""
    if s1 <= 0.0 or s2 <= 0.0:
        return 0.0
    c1 = np.array([cx1, cy1])
    c2 = np.array([cx2, cy2])
    d = c2 - c1

    u1, v1 = unit_vectors(a1)
    u2, v2 = unit_vectors(a2)
    axes = [u1, v1, u2, v2]

    h1 = 0.5 * s1
    h2 = 0.5 * s2

    min_pen = float('inf')
    for ax in axes:
        # project half-extent of square 1 onto ax
        e1 = h1 * (abs(np.dot(u1, ax)) + abs(np.dot(v1, ax)))
        e2 = h2 * (abs(np.dot(u2, ax)) + abs(np.dot(v2, ax)))
        dist = abs(np.dot(d, ax))
        gap = dist - (e1 + e2)
        pen = max(0.0, -gap)
        if pen < min_pen:
            min_pen = pen
    if min_pen == 0.0:
        return 0.0
    return min_pen


# ----------------------------------------------------------------------
# objective with penalties
# ----------------------------------------------------------------------
def make_objective(n, target_sum=None):
    def objective(z):
        sides = z[0::4]
        cx = z[1::4]
        cy = z[2::4]
        ang = z[3::4]

        total = float(np.sum(sides))

        penalty = 0.0
        for i in range(n):
            penalty += 50.0 * outside_amount(cx[i], cy[i], ang[i], sides[i])
        for i in range(n):
            si = sides[i]
            if si <= 0.0:
                continue
            for j in range(i + 1, n):
                sj = sides[j]
                if sj <= 0.0:
                    continue
                ov = sat_overlap(cx[i], cy[i], ang[i], si,
                                 cx[j], cy[j], ang[j], sj)
                if ov > 0.0:
                    penalty += 100.0 * ov * ov
        return -total + penalty + 1e-9 * float(np.sum(np.array(cx) ** 2
                                                      + np.array(cy) ** 2))
    return objective


def make_grad_objective(n):
    """numerical gradient is easiest; scipy will do finite differences."""
    obj = make_objective(n)
    return obj


# ----------------------------------------------------------------------
# initial configurations
# ----------------------------------------------------------------------
def config_grid(n):
    k = max(1, int(round(math.sqrt(n))))
    while k * k > n:
        k -= 1
    while (k + 1) * (k + 1) <= n:
        k += 1
    s = 1.0 / k
    z = []
    for i in range(k):
        for j in range(k):
            z += [s, (i + 0.5) * s, (j + 0.5) * s, 0.0]
    while len(z) < 4 * n:
        z += [0.0, 0.5, 0.5, 0.0]
    return np.array(z[:4 * n])


def config_grid_mixed(n):
    """use rows/cols with possibly different sizes to absorb remainder"""
    # approximate: try several grid shapes (a x b)
    best = None
    best_val = -1
    for a in range(1, n + 1):
        b = (n + a - 1) // a
        if a * b < n:
            continue
        # a columns, b rows, each cell side 1/a x 1/b can't be square unless a=b
        # instead use side min(1/a,1/b) in a grid
        s = min(1.0 / a, 1.0 / b)
        if a * s <= 1.0 and b * s <= 1.0:
            z = []
            for i in range(a):
                for j in range(b):
                    z += [s, (i + 0.5) * s, (j + 0.5) * s, 0.0]
            while len(z) < 4 * n:
                z += [0.0, 0.5, 0.5, 0.0]
            z = np.array(z[:4 * n])
            val = sum(z[0::4])
            if val > best_val:
                best_val = val
                best = z
    return best if best is not None else config_grid(n)


def config_greedy(n):
    """place largest possible axis-aligned squares greedily in a grid,
       then random tiny ones"""
    # try a few candidate side sizes
    candidates = []
    for k in range(1, int(math.sqrt(n)) + 3):
        s = 1.0 / k
        cells = k * k
        if cells <= n:
            candidates.append((s * min(cells, n), k, s))
    # generate square placement by rows
    best = None
    best_score = -1
    for _, k, s in candidates:
        z = []
        cnt = 0
        for i in range(k):
            for j in range(k):
                z += [s, (i + 0.5) * s, (j + 0.5) * s, 0.0]
                cnt += 1
        # remaining small squares placed at random feasible spots
        while cnt < n:
            # try to find a spot
            placed = False
            for _try in range(200):
                x = random.random()
                y = random.random()
                s2 = random.uniform(0.0, 0.02)
                ok = True
                for t in range(cnt):
                    if sat_overlap(x, y, 0.0, s2,
                                   z[4*t+1], z[4*t+2], z[4*t+3], z[4*t]) > 0.0:
                        ok = False
                        break
                if ok:
                    z += [s2, x, y, 0.0]
                    cnt += 1
                    placed = True
                    break
            if not placed:
                z += [0.0, 0.5, 0.5, 0.0]
                cnt += 1
        val = sum(z[0::4])
        if val > best_score:
            best_score = val
            best = np.array(z[:4 * n])
    return best if best is not None else config_grid(n)


def config_recursive_split(n):
    """recursively split the square to place n squares"""
    result = []

    def rec(x0, y0, x1, y1, m):
        if m <= 0:
            return
        if m == 1:
            w = min(x1 - x0, y1 - y0)
            result.append((0.5 * (x0 + x1), 0.5 * (y0 + y1), 0.0, w))
            return
        # split into roughly two halves by area
        if (x1 - x0) >= (y1 - y0):
            mid = 0.5 * (x0 + x1)
            m1 = m // 2
            rec(x0, y0, mid, y1, m1)
            rec(mid, y0, x1, y1, m - m1)
        else:
            mid = 0.5 * (y0 + y1)
            m1 = m // 2
            rec(x0, y0, x1, mid, m1)
            rec(x0, mid, x1, y1, m - m1)

    rec(0.0, 0.0, 1.0, 1.0, n)
    z = []
    for cx, cy, a, s in result:
        z += [s, cx, cy, a]
    while len(z) < 4 * n:
        z += [0.0, 0.5, 0.5, 0.0]
    return np.array(z[:4 * n])


def config_spiral(n):
    """place squares along a spiral, decreasing sizes"""
    z = []
    total = 0.0
    # choose sides that decay geometrically, then normalise
    sizes = []
    s = 1.0
    for i in range(n):
        sizes.append(s)
        s *= 0.88
    # place along spiral
    cx, cy = 0.5, 0.5
    radius = 0.0
    angle = 0.0
    for i in range(n):
        si = sizes[i] * 0.15
        # spiral
        angle += 0.6
        radius += 0.02
        x = 0.5 + radius * math.cos(angle)
        y = 0.5 + radius * math.sin(angle)
        x = min(0.99, max(0.01, x))
        y = min(0.99, max(0.01, y))
        z += [si, x, y, 0.0]
    return np.array(z[:4 * n])


def config_random(n, seed=0):
    rng = random.Random(seed)
    z = []
    for _ in range(n):
        s = rng.uniform(0.0, 0.3)
        z += [s, rng.random(), rng.random(), rng.random()]
    return np.array(z)


# ----------------------------------------------------------------------
# bounds and optimisation
# ----------------------------------------------------------------------
def optimise_from(z0, n, maxiter=200, time_limit=50.0):
    """local optimisation with L-BFGS-B"""
    import time
    t0 = time.time()

    def bounds():
        b = []
        for _ in range(n):
            b.append((0.0, 1.0))     # side
            b.append((0.0, 1.0))     # cx
            b.append((0.0, 1.0))     # cy
            b.append((0.0, 1.0))     # angle
        return b

    obj = make_objective(n)
    res = minimize(obj, z0, method='L-BFGS-B', bounds=bounds(),
                   options={'maxiter': maxiter,
                            'ftol': 1e-12,
                            'gtol': 1e-10,
                            'maxfun': 200000})
    return res.x


def evaluate(z):
    """returns sum of side lengths if feasible, else very negative"""
    n = len(z) // 4
    sides = z[0::4]
    cx = z[1::4]
    cy = z[2::4]
    ang = z[3::4]

    # outside penalty
    for i in range(n):
        if outside_amount(cx[i], cy[i], ang[i], sides[i]) > 1e-6:
            return -1e9
    # overlap check
    for i in range(n):
        for j in range(i + 1, n):
            if sat_overlap(cx[i], cy[i], ang[i], sides[i],
                           cx[j], cy[j], ang[j], sides[j]) > 1e-7:
                return -1e9
    return float(np.sum(sides))


def clean_up(z, n):
    """clip to feasible bounds and zero out tiny sides"""
    z = np.array(z)
    z[0::4] = np.clip(z[0::4], 0.0, 1.0)
    z[1::4] = np.clip(z[1::4], 0.0, 1.0)
    z[2::4] = np.clip(z[2::4], 0.0, 1.0)
    z[3::4] = np.clip(z[3::4], 0.0, 1.0)
    return z


# ----------------------------------------------------------------------
# local repair: fix overlap by shrinking
# ----------------------------------------------------------------------
def repair_penalty(z, n, iters=50):
    """simple gradient-free repair: shrink overlapping squares"""
    z = clean_up(z, n)
    for _ in range(iters):
        changed = False
        # outside
        for i in range(n):
            out = outside_amount(z[4*i+1], z[4*i+2], z[4*i+3], z[4*i])
            if out > 1e-9:
                z[4*i] *= 0.9
                changed = True
        # overlap
        for i in range(n):
            if z[4*i] <= 0.0:
                continue
            for j in range(i + 1, n):
                if z[4*j] <= 0.0:
                    continue
                ov = sat_overlap(z[4*i+1], z[4*i+2], z[4*i+3], z[4*i],
                                 z[4*j+1], z[4*j+2], z[4*j+3], z[4*j])
                if ov > 1e-9:
                    # shrink both
                    z[4*i] *= 0.95
                    z[4*j] *= 0.95
                    changed = True
        if not changed:
            break
    return z


def make_postprocess(z, n):
    z = clean_up(z, n)
    z = repair_penalty(z, n, iters=100)
    # zero out very small pieces to avoid numerical junk
    for i in range(n):
        if z[4*i] < 1e-5:
            z[4*i] = 0.0
    return z


# ----------------------------------------------------------------------
# main solver
# ----------------------------------------------------------------------
def solve(n):
    if n <= 0:
        return []

    random.seed(12345)
    np.random.seed(12345)

    # small n: near-optimal structured answers
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # two on bottom, one on top
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # generate many starting points
    configs = []
    configs.append(config_grid(n))
    configs.append(config_grid_mixed(n))
    configs.append(config_greedy(n))
    configs.append(config_recursive_split(n))
    configs.append(config_spiral(n))
    for seed in range(5):
        configs.append(config_random(n, seed))
    # also random perturbations of grid
    g = config_grid(n)
    for _ in range(8):
        zz = g.copy()
        for i in range(n):
            zz[4*i+1] += random.uniform(-0.03, 0.03)
            zz[4*i+2] += random.uniform(-0.03, 0.03)
            zz[4*i+3] += random.uniform(-0.1, 0.1)
        configs.append(np.clip(zz, 0.0, 1.0))

    best_z = None
    best_val = -1.0

    import time
    start_time = time.time()
    time_budget = 55.0

    # Optimise from each configuration
    for ci, z0 in enumerate(configs):
        if time.time() - start_time > time_budget:
            break
        try:
            z0 = clean_up(z0, n)
            # quick repair before optimisation
            z0 = repair_penalty(z0, n, iters=30)
            z_opt = optimise_from(z0, n, maxiter=120)
            z_opt = make_postprocess(z_opt, n)
            val = evaluate(z_opt)
            if val > best_val:
                best_val = val
                best_z = z_opt.copy()
        except Exception:
            continue

    # intensive polishing of the best
    if best_z is not None:
        for round_id in range(6):
            if time.time() - start_time > time_budget:
                break
            try:
                z_opt = optimise_from(best_z, n, maxiter=200)
                z_opt = make_postprocess(z_opt, n)
                val = evaluate(z_opt)
                if val > best_val:
                    best_val = val
                    best_z = z_opt.copy()
                else:
                    # try a slight perturbation of the best
                    zz = best_z.copy()
                    for i in range(n):
                        zz[4*i+1] += random.uniform(-0.01, 0.01)
                        zz[4*i+2] += random.uniform(-0.01, 0.01)
                        zz[4*i+3] += random.uniform(-0.02, 0.02)
                    zz = np.clip(zz, 0.0, 1.0)
                    z_opt = optimise_from(zz, n, maxiter=150)
                    z_opt = make_postprocess(z_opt, n)
                    val = evaluate(z_opt)
                    if val > best_val:
                        best_val = val
                        best_z = z_opt.copy()
            except Exception:
                continue

    # final fallback
    if best_z is None:
        best_z = config_grid(n)
        best_z = make_postprocess(best_z, n)
        best_val = evaluate(best_z)

    # convert to output
    result = []
    for i in range(n):
        side = float(best_z[4*i])
        cx = float(best_z[4*i+1])
        cy = float(best_z[4*i+2])
        ang = float(best_z[4*i+3])
        # safety clamps
        side = max(0.0, min(1.0, side))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = max(0.0, min(1.0, ang))
        result.append((cx, cy, ang, side))

    return result
