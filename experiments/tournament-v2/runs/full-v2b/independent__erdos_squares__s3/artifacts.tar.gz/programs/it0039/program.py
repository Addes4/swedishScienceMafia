import math
import random


def _overlap_check_all(squares, eps=1e-12):
    m = len(squares)
    for i in range(m):
        xi, yi, ai, si = squares[i]
        if si <= 0:
            continue
        ci, si_ang = math.cos(2 * math.pi * ai), math.sin(2 * math.pi * ai)
        # corners of square i
        pts_i = _corners(xi, yi, ci, si_ang, si)
        for j in range(i + 1, m):
            xj, yj, aj, sj = squares[j]
            if sj <= 0:
                continue
            cj, sj_ang = math.cos(2 * math.pi * aj), math.sin(2 * math.pi * aj)
            if _rect_overlap(pts_i, _corners(xj, yj, cj, sj_ang, sj), eps):
                return True
    return False


def _corners(x, y, c, s, side):
    h = side * 0.5
    return [
        (x + c * h - s * h, y + s * h + c * h),
        (x + c * h + s * h, y + s * h - c * h),
        (x - c * h + s * h, y - s * h - c * h),
        (x - c * h - s * h, y - s * h + c * h),
    ]


def _rect_overlap(A, B, eps):
    # separating axis theorem for convex polygons
    for poly in (A, B):
        for k in range(4):
            p1 = poly[k]
            p2 = poly[(k + 1) % 4]
            axis = (-(p2[1] - p1[1]), p2[0] - p1[0])
            ax, ay = axis
            minA = min(p[0] * ax + p[1] * ay for p in A)
            maxA = max(p[0] * ax + p[1] * ay for p in A)
            minB = min(p[0] * ax + p[1] * ay for p in B)
            maxB = max(p[0] * ax + p[1] * ay for p in B)
            if maxA <= minB + eps or maxB <= minA + eps:
                return False
    return True


def _inside_unit(sq, eps=1e-9):
    x, y, a, s = sq
    if s <= 0:
        return True
    ang = 2 * math.pi * a
    c, sn = math.cos(ang), math.sin(ang)
    h = s * 0.5
    for px, py in (
        (x + c * h - sn * h, y + sn * h + c * h),
        (x + c * h + sn * h, y + sn * h - c * h),
        (x - c * h + sn * h, y - sn * h - c * h),
        (x - c * h - sn * h, y - sn * h + c * h),
    ):
        if px < -eps or px > 1 + eps or py < -eps or py > 1 + eps:
            return False
    return True


def _valid_all(squares):
    m = len(squares)
    for i in range(m):
        if not _inside_unit(squares[i]):
            return False
    return not _overlap_check_all(squares)


# ----------------------------- layout builders -----------------------------

def _grid_layout(n, k, angle=0.0):
    """k x k grid in unit square, using exactly k*k slots if n >= k*k else fewer."""
    side = 1.0 / k
    out = []
    cnt = 0
    for i in range(k):
        for j in range(k):
            if cnt >= n:
                break
            out.append(((i + 0.5) * side, (j + 0.5) * side, angle, side))
            cnt += 1
        if cnt >= n:
            break
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out


def _beatty_layout(n):
    """Rows of equal-height squares, number of columns chosen to balance area."""
    best = None
    best_sum = -1.0
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        s = min(1.0 / rows, 1.0 / cols)
        total = 0.0
        out = []
        cnt = 0
        y0 = 0.0
        for r in range(rows):
            used_cols = min(cols, n - cnt)
            if used_cols <= 0:
                break
            step = 1.0 / used_cols
            for c in range(used_cols):
                x = (c + 0.5) * step
                y = y0 + s * 0.5
                out.append((x, y, 0.0, s))
            cnt += used_cols
            y0 += s
        while len(out) < n:
            out.append((0.5, 0.5, 0.0, 0.0))
        if cnt >= n:
            total = sum(sq[3] for sq in out)
            if total > best_sum:
                best_sum = total
                best = out
    return best


def _big_plus_grid(n):
    """One big square in a corner, grid in the remaining L-shape."""
    best = None
    best_sum = -1.0
    for k in range(1, int(math.sqrt(n)) + 1):
        # try big square occupying top-left of side b, remaining squares in two strips
        for b_num in range(1, 20):
            b = b_num / 20.0
            if b <= 0 or b >= 1:
                continue
            rem = n - 1
            if rem < 0:
                continue
            # right strip: width 1-b, height 1; bottom strip: width b, height 1-b
            # choose grid in each strip
            for rr in range(1, 30):
                for cc in range(1, 30):
                    s1 = min((1 - b) / rr, 1.0 / cc)
                    # square count in right strip
                    if rr * cc > rem:
                        continue
                    for rr2 in range(1, 30):
                        for cc2 in range(1, 30):
                            s2 = min(b / rr2, (1 - b) / cc2)
                            cnt2 = rr2 * cc2
                            if rr * cc + cnt2 != rem:
                                continue
                            total = b + rr * cc * s1 + cnt2 * s2
                            if total > best_sum:
                                out = [(b / 2, b / 2, 0.0, b)]
                                for i in range(rr):
                                    for j in range(cc):
                                        out.append((b + (j + 0.5) * s1, (i + 0.5) * s1, 0.0, s1))
                                for i in range(rr2):
                                    for j in range(cc2):
                                        out.append(((j + 0.5) * s2, b + (i + 0.5) * s2, 0.0, s2))
                                if len(out) == n and _valid_all(out):
                                    best_sum = total
                                    best = out
    return best


def _random_layout(n, rng):
    """Random rows with equal side inside each row, valid partition of height."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    remaining = n
    out = []
    y = 0.0
    rows = rng.randint(1, min(n, 8))
    while remaining > 0:
        r = min(rows, remaining)
        h = 1.0 / rows
        for _ in range(r):
            remaining -= 1
        out.append(r)
    # actually simpler: uniform rows splitting unit square
    rows = rng.randint(1, n)
    # distribute n squares into rows
    counts = [0] * rows
    for i in range(n):
        counts[i % rows] += 1
    y = 0.0
    h = 1.0 / rows
    out = []
    for r in range(rows):
        c = counts[r]
        if c == 0:
            y += h
            continue
        w = 1.0 / c
        s = min(h, w)
        for i in range(c):
            out.append(((i + 0.5) * w, y + h * 0.5, 0.0, s))
        y += h
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _local_improve(squares, rng, iterations=4000, time_budget=None):
    m = len(squares)
    sq = [list(s) for s in squares]
    cur_sum = sum(s[3] for s in sq)
    best = [s[:] for s in sq]
    best_sum = cur_sum
    for _ in range(iterations):
        i = rng.randrange(m)
        x, y, a, s = sq[i]
        op = rng.randrange(4)
        if op == 0 and s > 0:
            ns = min(1.0, max(0.0, s + rng.uniform(-0.02, 0.02)))
            sq[i] = [x, y, a, ns]
        elif op == 1:
            nx = min(1.0, max(0.0, x + rng.uniform(-0.02, 0.02)))
            sq[i] = [nx, y, a, s]
        elif op == 2:
            ny = min(1.0, max(0.0, y + rng.uniform(-0.02, 0.02)))
            sq[i] = [x, ny, a, s]
        else:
            na = rng.uniform(0.0, 1.0)
            sq[i] = [x, y, na, s]
        if _valid_all(sq):
            new_sum = sum(s[3] for s in sq)
            if new_sum > cur_sum or rng.random() < 0.01:
                cur_sum = new_sum
                if new_sum > best_sum:
                    best_sum = new_sum
                    best = [s[:] for s in sq]
        else:
            sq[i] = [x, y, a, s]
    return best


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)

    candidates = []
    # grid layouts
    for k in range(1, int(math.sqrt(n)) + 3):
        candidates.append(_grid_layout(n, k))
        candidates.append(_grid_layout(n, k, 0.0))
    # beatty rows
    b = _beatty_layout(n)
    if b:
        candidates.append(b)
    # large square + strips
    bg = _big_plus_grid(n)
    if bg:
        candidates.append(bg)
    # random
    for _ in range(5):
        candidates.append(_random_layout(n, rng))

    # keep valid ones, score sum
    valid = []
    for c in candidates:
        if len(c) < n:
            c = list(c) + [(0.5, 0.5, 0.0, 0.0)] * (n - len(c))
        c = c[:n]
        if _valid_all(c):
            valid.append(c)
    if not valid:
        # fallback grid
        valid = [_grid_layout(n, max(1, math.isqrt(n)))]

    best = max(valid, key=lambda c: sum(s[3] for s in c))

    # local search
    improved = _local_improve(best, rng, iterations=600)
    if _valid_all(improved) and sum(s[3] for s in improved) >= sum(s[3] for s in best):
        best = improved

    # final clean
    out = []
    for x, y, a, s in best[:n]:
        out.append((min(1.0, max(0.0, x)), min(1.0, max(0.0, y)), a % 1.0, max(0.0, s)))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
