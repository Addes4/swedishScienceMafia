import math
import random
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, a, s):
    """Return 4 corners of a square given centre, angle (fraction of turn), side."""
    t = 2.0 * math.pi * a
    c, sn = math.cos(t), math.sin(t)
    h = 0.5 * s
    # local corners
    dx = np.array([-h, h, h, -h])
    dy = np.array([-h, -h, h, h])
    x = cx + c * dx - sn * dy
    y = cy + sn * dx + c * dy
    return x, y


def _sat_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """Return max penetration depth (positive if overlapping interiors)."""
    if s1 <= 0.0 or s2 <= 0.0:
        return 0.0
    x1, y1 = _corners(cx1, cy1, a1, s1)
    x2, y2 = _corners(cx2, cy2, a2, s2)
    # test axes from both squares
    min_pen = 1e18
    for corners, cx in ((x1, cx1), (x2, cx2)):
        for i in range(4):
            j = (i + 1) % 4
            ax = corners[j] - corners[i]
            ay = np.array([0.0])  # placeholder
        # do proper axes below
    # Use edge normals
    axes = []
    for xs, ys in ((x1, y1), (x2, y2)):
        for i in range(4):
            j = (i + 1) % 4
            ex = xs[j] - xs[i]
            ey = ys[j] - ys[i]
            L = math.hypot(ex, ey)
            if L < 1e-15:
                continue
            axes.append((-ey / L, ex / L))
    # For each axis, project and check overlap
    pen = 1e18
    for ax, ay in axes:
        p1 = x1 * ax + y1 * ay
        p2 = x2 * ax + y2 * ay
        ov = min(p1.max(), p2.max()) - max(p1.min(), p2.min())
        if ov <= 0.0:
            return 0.0
        pen = min(pen, ov)
    return pen if pen < 1e17 else 0.0


def _boundary_violation(cx, cy, a, s):
    if s <= 0.0:
        return 0.0
    x, y = _corners(cx, cy, a, s)
    v = 0.0
    v = max(v, -x.min())
    v = max(v, x.max() - 1.0)
    v = max(v, -y.min())
    v = max(v, y.max() - 1.0)
    return v


def _initial_grid(n):
    """Place n squares heuristically."""
    k = max(1, int(round(math.sqrt(n))))
    # try to use a grid of r rows, c cols with n cells, some cells may be subdivided
    best = None
    for r in range(1, n + 1):
        c = (n + r - 1) // r
        if r * c < n:
            continue
        # side limited by cell
        s = min(1.0 / r, 1.0 / c)
        total = n * s
        if best is None or total > best[0]:
            # construct
            cells = [(i, j) for i in range(r) for j in range(c)]
            squares = []
            for idx in range(n):
                i, j = cells[idx % len(cells)]
                cx = (j + 0.5) / c
                cy = (i + 0.5) / r
                # If n < r*c, some cells can be bigger by merging, but keep simple
                squares.append((cx, cy, 0.0, s))
            best = (total, squares)
    return best[1]


def _initial_rows(n):
    """Rows with equal number of squares per row; last row maybe fewer/bigger."""
    best = None
    for rows in range(1, n + 1):
        base = n // rows
        extra = n % rows
        widths = []
        for r in range(rows):
            cnt = base + (1 if r < extra else 0)
            widths.append(cnt)
        # each row uses full width; side limited by row height
        h = 1.0 / rows
        total = 0.0
        sq = []
        for r in range(rows):
            cnt = widths[r]
            if cnt == 0:
                continue
            w = 1.0 / cnt
            s = min(h, w)
            y = (r + 0.5) * h
            for j in range(cnt):
                x = (j + 0.5) * w
                sq.append((x, y, 0.0, s))
            total += cnt * s
        if best is None or total > best[0]:
            best = (total, sq)
    return best[1]


def _initial_guillotine(n):
    """Recursive guillotine split: try splitting into two parts."""
    # Dynamic programming: best total side for a rectangle w x h containing k squares
    # Memoize on (k, ) with symmetric use.
    from functools import lru_cache

    @lru_cache(maxsize=None)
    def best_fill(k):
        # returns (total_side_sum, layout) for k squares in unit square with no rotation
        # layout as list of (x0,y0,x1,y1) in local unit coords? too complex.
        return None

    # simpler: try a few recursive splits greedily
    def rec(w, h, k, ox, oy):
        if k == 0:
            return []
        if k == 1:
            s = min(w, h)
            # center it
            return [(ox + w / 2.0, oy + h / 2.0, 0.0, s)]
        # try split along x or y
        best = None
        for split_ratio in [i / k for i in range(1, k)]:
            # split along x
            w1 = w * split_ratio
            w2 = w - w1
            r1 = rec(w1, h, int(round(split_ratio * k)), ox, oy)
            r2 = rec(w2, h, k - int(round(split_ratio * k)), ox + w1, oy)
            if r1 is not None and r2 is not None:
                tot = sum(t[3] for t in r1) + sum(t[3] for t in r2)
                if best is None or tot > best[0]:
                    best = (tot, r1 + r2)
            # split along y
            h1 = h * split_ratio
            h2 = h - h1
            r1 = rec(w, h1, int(round(split_ratio * k)), ox, oy)
            r2 = rec(w, h2, k - int(round(split_ratio * k)), ox, oy + h1)
            if r1 is not None and r2 is not None:
                tot = sum(t[3] for t in r1) + sum(t[3] for t in r2)
                if best is None or tot > best[0]:
                    best = (tot, r1 + r2)
        return best[1] if best is not None else None

    res = rec(1.0, 1.0, n, 0.0, 0.0)
    if res is None:
        return _initial_grid(n)
    return res


def _objective(x, n):
    # x = [cx, cy, angle, side] * n
    return -sum(x[4 * i + 3] for i in range(n))


def _constraints(x, n, penalty_scale=1.0):
    """Return list of constraint values >= 0 for feasible."""
    cons = []
    # boundary: corners inside [0,1]
    for i in range(n):
        cx, cy, a, s = x[4 * i:4 * i + 4]
        if s <= 0:
            cons.extend([1.0, 1.0, 1.0, 1.0])
            continue
        xs, ys = _corners(cx, cy, a, s)
        cons.append(xs.min())          # >=0
        cons.append(1.0 - xs.max())    # >=0
        cons.append(ys.min())
        cons.append(1.0 - ys.max())
    # pairwise non-overlap: penetration == 0
    for i in range(n):
        for j in range(i + 1, n):
            cxi, cyi, ai, si = x[4 * i:4 * i + 4]
            cxj, cyj, aj, sj = x[4 * j:4 * j + 4]
            pen = _sat_overlap(cxi, cyi, ai, si, cxj, cyj, aj, sj)
            cons.append(pen)
    return np.array(cons)


def _unpack(x, n):
    return [(x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3]) for i in range(n)]


def _pack(x, squares):
    x = list(x)
    for i, (cx, cy, a, s) in enumerate(squares):
        x[4 * i:4 * i + 4] = [cx, cy, a, s]
    return x


def _try_optimize(init_squares, n, maxiter=200, tol=1e-10):
    x0 = []
    for cx, cy, a, s in init_squares:
        x0.extend([cx, cy, a, math.fabs(s)])
    x0 = np.array(x0)

    bounds = []
    for i in range(n):
        bounds.extend([(0.0, 1.0), (0.0, 1.0), (0.0, 1.0), (0.0, 1.0)])

    def obj(x):
        return -np.sum(x[3::4])

    def cons_fun(x):
        # SLSQP wants constraints >= 0
        c = _constraints(x, n)
        return c

    # use numerical jacobian for constraints (may be slow); n small enough
    res = minimize(obj, x0, method='SLSQP', bounds=bounds,
                   constraints=[{'type': 'ineq', 'fun': cons_fun}],
                   options={'maxiter': maxiter, 'ftol': tol, 'disp': False})
    if res.success or res.fun < -0.0:
        return _unpack(res.x, n)
    return init_squares


def _repair(squares, n):
    """Scale down overlapping squares iteratively."""
    sq = [list(s) for s in squares]
    for _ in range(100):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                ci, cj = sq[i], sq[j]
                pen = _sat_overlap(ci[0], ci[1], ci[2], ci[3],
                                   cj[0], cj[1], cj[2], cj[3])
                if pen > 1e-12:
                    # shrink both slightly
                    ci[3] *= 0.995
                    cj[3] *= 0.995
                    changed = True
        # boundary repair
        for i in range(n):
            cx, cy, a, s = sq[i]
            v = _boundary_violation(cx, cy, a, s)
            if v > 1e-12:
                sq[i][3] *= 0.99
                changed = True
        if not changed:
            break
    return [tuple(s) for s in sq]


def solve(n):
    if n <= 0:
        return []
    random.seed(1234567)
    np.random.seed(1234567)

    # Try multiple initial layouts
    inits = []
    inits.append(_initial_grid(n))
    inits.append(_initial_rows(n))
    # try guillotine
    try:
        g = _initial_guillotine(n)
        if g is not None:
            inits.append(g)
    except Exception:
        pass

    best = None
    best_score = -1e18

    for base in inits:
        if base is None or len(base) != n:
            continue
        # repair
        base = _repair(base, n)
        # multi-start local optimization
        for trial in range(3):
            if trial == 0:
                start = [list(s) for s in base]
            else:
                start = [list(s) for s in base]
                for i in range(n):
                    start[i][0] += random.uniform(-0.02, 0.02)
                    start[i][1] += random.uniform(-0.02, 0.02)
                    start[i][2] += random.uniform(-0.05, 0.05)
                    start[i][3] = min(1.0, max(0.0, start[i][3] * random.uniform(0.9, 1.1)))
            start = _repair([tuple(s) for s in start], n)
            try:
                improved = _try_optimize(start, n, maxiter=150)
            except Exception:
                improved = start
            improved = _repair(improved, n)
            score = sum(s[3] for s in improved)
            if score > best_score:
                best_score = score
                best = improved

    if best is None:
        best = _initial_grid(n)

    # final repair
    best = _repair(best, n)
    # ensure all numbers in [0,1]
    result = []
    for cx, cy, a, s in best:
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        a = a % 1.0
        s = min(1.0, max(0.0, s))
        result.append((cx, cy, a, s))
    return result[:n]
