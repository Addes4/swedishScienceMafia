import math
import random
import numpy as np
from scipy.optimize import minimize


def _overlap_amount(a, b):
    cx1, cy1, t1, s1 = a
    cx2, cy2, t2, s2 = b
    if s1 <= 0 or s2 <= 0:
        return 0.0
    a1 = t1 * 2.0 * math.pi
    a2 = t2 * 2.0 * math.pi
    c1, sn1 = math.cos(a1), math.sin(a1)
    c2, sn2 = math.cos(a2), math.sin(a2)

    # separating axis theorem for convex polygons
    # get corners of square 1
    h1 = s1 * 0.5
    h2 = s2 * 0.5

    axes = [
        (c1, sn1), (-sn1, c1),
        (c2, sn2), (-sn2, c2),
    ]

    dx = cx2 - cx1
    dy = cy2 - cy1

    overlap = float('inf')
    for ax, ay in axes:
        r1 = h1 * (abs(ax * c1 + ay * sn1) + abs(ax * (-sn1) + ay * c1))
        r2 = h2 * (abs(ax * c2 + ay * sn2) + abs(ax * (-sn2) + ay * c2))
        d = abs(ax * dx + ay * dy)
        ov = r1 + r2 - d
        if ov <= 0:
            return 0.0
        if ov < overlap:
            overlap = ov
    return overlap


def _boundary_violation(x, y, t, s):
    if s <= 0:
        return 0.0
    a = t * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    ext_x = h * (abs(c) + abs(sn))
    ext_y = h * (abs(sn) + abs(c))
    v = 0.0
    if x - ext_x < 0:
        v += ext_x - x
    if x + ext_x > 1:
        v += x + ext_x - 1
    if y - ext_y < 0:
        v += ext_y - y
    if y + ext_y > 1:
        v += y + ext_y - 1
    return v


def _penalty(squares):
    pen = 0.0
    nsq = len(squares)
    for i in range(nsq):
        x, y, t, s = squares[i]
        if s < 0:
            pen += (-s) ** 2 * 1000.0
        if x < 0 or x > 1 or y < 0 or y > 1:
            pen += 1000.0 * ((max(0.0, -x) + max(0.0, x - 1.0)) ** 2 +
                             (max(0.0, -y) + max(0.0, y - 1.0)) ** 2)
        pen += _boundary_violation(x, y, t, s) ** 2 * 1000.0
    for i in range(nsq):
        for j in range(i + 1, nsq):
            ov = _overlap_amount(squares[i], squares[j])
            if ov > 0:
                pen += ov ** 2 * 1000.0
    return pen


def _objective(params, n):
    squares = []
    for i in range(n):
        x = params[4 * i]
        y = params[4 * i + 1]
        t = params[4 * i + 2]
        s = params[4 * i + 3]
        squares.append((x, y, t, s))
    total = sum(s for _, _, _, s in squares)
    return -total


def _total_obj(params, n):
    return _objective(params, n) + _penalty_from_params(params, n)


def _penalty_from_params(params, n):
    squares = []
    for i in range(n):
        x = params[4 * i]
        y = params[4 * i + 1]
        t = params[4 * i + 2]
        s = params[4 * i + 3]
        squares.append((x, y, t, s))
    return _penalty(squares)


def _initial_grid(n):
    squares = []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    k = math.isqrt(n)
    # try different arrangements
    best = None
    best_sum = -1
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        if cols * rows >= n:
            # place rows x cols grid, some empty
            sz = min(1.0 / rows, 1.0 / cols)
            if sz * min(n, rows * cols) > best_sum:
                best_sum = sz * min(n, rows * cols)
                best = (rows, cols, sz)
    rows, cols, sz = best
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            x = (c + 0.5) / cols
            y = (r + 0.5) / rows
            squares.append((x, y, 0.0, sz))
            idx += 1
    return squares


def _local_optimize(squares, n, maxiter=200):
    params = np.zeros(4 * n)
    for i, (x, y, t, s) in enumerate(squares):
        params[4 * i] = x
        params[4 * i + 1] = y
        params[4 * i + 2] = t
        params[4 * i + 3] = s

    def fun(p):
        return _total_obj(p, n)

    res = minimize(fun, params, method='L-BFGS-B',
                   options={'maxiter': maxiter, 'ftol': 1e-12, 'gtol': 1e-10})
    best_params = res.x

    squares_out = []
    for i in range(n):
        x = best_params[4 * i]
        y = best_params[4 * i + 1]
        t = best_params[4 * i + 2]
        s = best_params[4 * i + 3]
        squares_out.append((x, y, t, s))
    return squares_out


def _repair(squares, n):
    out = []
    for x, y, t, s in squares:
        if s < 0:
            s = 0.0
        # clamp position approximately
        x = max(0.0, min(1.0, x))
        y = max(0.0, min(1.0, y))
        t = t % 1.0
        # shrink if boundary violated
        a = t * 2.0 * math.pi
        c, sn = math.cos(a), math.sin(a)
        h = s * 0.5
        ext_x = h * (abs(c) + abs(sn))
        ext_y = h * (abs(sn) + abs(c))
        # move inward
        if x - ext_x < 0:
            x = ext_x
        if x + ext_x > 1:
            x = 1.0 - ext_x
        if y - ext_y < 0:
            y = ext_y
        if y + ext_y > 1:
            y = 1.0 - ext_y
        out.append((x, y, t, s))
    # resolve overlaps by shrinking
    changed = True
    for _ in range(50):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                ov = _overlap_amount(out[i], out[j])
                if ov > 1e-9:
                    xi, yi, ti, si = out[i]
                    xj, yj, tj, sj = out[j]
                    # shrink both
                    si2 = max(0.0, si - ov * 0.5)
                    sj2 = max(0.0, sj - ov * 0.5)
                    out[i] = (xi, yi, ti, si2)
                    out[j] = (xj, yj, tj, sj2)
                    changed = True
        if not changed:
            break
    return out


def solve(n):
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    random.seed(12345)

    best_squares = None
    best_val = -1.0

    # try several initial configurations
    inits = []

    # grid
    inits.append(_initial_grid(n))

    # grid with perturb
    for _ in range(3):
        g = _initial_grid(n)
        pert = []
        for x, y, t, s in g:
            pert.append((
                x + random.uniform(-0.02, 0.02),
                y + random.uniform(-0.02, 0.02),
                t + random.uniform(-0.01, 0.01),
                s
            ))
        inits.append(pert)

    # single column-ish for some n
    if n <= 5:
        inits.append([(0.5, (i + 0.5) / n, 0.0, 1.0 / n) for i in range(n)])
        inits.append([((i + 0.5) / n, 0.5, 0.0, 1.0 / n) for i in range(n)])

    for init in inits:
        sq = _repair(init, n)
        sq = _local_optimize(sq, n, maxiter=150)
        sq = _repair(sq, n)

        val = sum(s for _, _, _, s in sq)
        if val > best_val:
            best_val = val
            best_squares = sq

    # additional random restarts within time
    import time
    start = time.time()
    it = 0
    while time.time() - start < 50.0 and it < 40:
        it += 1
        base = best_squares if best_squares else _initial_grid(n)
        pert = []
        for x, y, t, s in base:
            pert.append((
                x + random.uniform(-0.05, 0.05),
                y + random.uniform(-0.05, 0.05),
                t + random.uniform(-0.1, 0.1),
                s * random.uniform(0.95, 1.02)
            ))
        sq = _repair(pert, n)
        sq = _local_optimize(sq, n, maxiter=100)
        sq = _repair(sq, n)
        val = sum(s for _, _, _, s in sq)
        if val > best_val:
            best_val = val
            best_squares = sq

    # final careful repair and local optimize
    if best_squares is None:
        best_squares = _initial_grid(n)

    best_squares = _repair(best_squares, n)
    best_squares = _local_optimize(best_squares, n, maxiter=300)
    best_squares = _repair(best_squares, n)

    # final validation, if something wrong, fall back to grid
    try:
        for i in range(n):
            x, y, t, s = best_squares[i]
            assert -1e-9 <= x <= 1 + 1e-9
            assert -1e-9 <= y <= 1 + 1e-9
            assert s >= -1e-12
        for i in range(n):
            for j in range(i + 1, n):
                ov = _overlap_amount(best_squares[i], best_squares[j])
                assert ov <= 1e-6
    except Exception:
        k = math.isqrt(n)
        side = 1.0 / k
        best_squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                        for i in range(k) for j in range(k)]
        best_squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_squares))
        best_squares = best_squares[:n]

    # normalize t to [0,1)
    result = []
    for x, y, t, s in best_squares:
        t = t % 1.0
        s = max(0.0, s)
        x = max(0.0, min(1.0, x))
        y = max(0.0, min(1.0, y))
        result.append((x, y, t, s))
    return result[:n]
