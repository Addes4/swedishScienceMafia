import math
import random
from scipy.optimize import minimize

EPS = 1e-10


def _poly(cx, cy, a, s):
    """Return the 4 vertices of a square centred at (cx,cy), angle a (turns), side s."""
    t = 2.0 * math.pi * a
    ca, sa = math.cos(t), math.sin(t)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def _inside_unit(pts):
    for x, y in pts:
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _seg_intersect(p1, p2, q1, q2):
    """Proper or improper segment intersection (excluding touching), robust enough."""
    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    d1 = cross(q1, q2, p1)
    d2 = cross(q1, q2, p2)
    d3 = cross(p1, p2, q1)
    d4 = cross(p1, p2, q2)
    if ((d1 > 1e-12 and d2 < -1e-12) or (d1 < -1e-12 and d2 > 1e-12)) and \
       ((d3 > 1e-12 and d4 < -1e-12) or (d3 < -1e-12 and d4 > 1e-12)):
        return True
    return False


def _overlap(sq1, sq2):
    """Check whether two squares (lists of 4 vertices) overlap with positive area.
    Uses polygon clipping via Sutherland-Hodgman."""
    def clip(subject, clip_poly):
        def inside(p, a, b):
            return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= -1e-12

        def inter(p, a, b):
            # intersection of line p->? Actually compute line-line intersection
            # of segment a-b and the segment p1-p2 where p is previous point
            return None

        output = list(subject)
        cp = clip_poly
        for i in range(len(cp)):
            a = cp[i]
            b = cp[(i + 1) % len(cp)]
            inp = output
            output = []
            if not inp:
                break
            s = inp[-1]
            for e in inp:
                if inside(e, a, b):
                    if not inside(s, a, b):
                        output.append(_line_inter(s, e, a, b))
                    output.append(e)
                elif inside(s, a, b):
                    output.append(_line_inter(s, e, a, b))
                s = e
        return output

    poly = list(sq1)
    for i in range(4):
        a = sq2[i]
        b = sq2[(i + 1) % 4]
        poly = _clip_poly(poly, a, b)
        if not poly:
            return False
    # area of poly
    area = 0.0
    m = len(poly)
    for i in range(m):
        x1, y1 = poly[i]
        x2, y2 = poly[(i + 1) % m]
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5 > 1e-9


def _line_inter(p1, p2, a, b):
    x1, y1 = p1
    x2, y2 = p2
    x3, y3 = a
    x4, y4 = b
    den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
    if abs(den) < 1e-18:
        return p2
    t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den
    return (x1 + t * (x2 - x1), y1 + t * (y2 - y1))


def _inside_half(p, a, b):
    return (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]) >= -1e-12


def _clip_poly(poly, a, b):
    if not poly:
        return poly
    out = []
    s = poly[-1]
    for e in poly:
        if _inside_half(e, a, b):
            if not _inside_half(s, a, b):
                out.append(_line_inter(s, e, a, b))
            out.append(e)
        elif _inside_half(s, a, b):
            out.append(_line_inter(s, e, a, b))
        s = e
    return out


def _feasible(squares):
    """squares: list of (cx, cy, a, s). Return True if no overlaps and all inside."""
    polys = [_poly(*sq) for sq in squares]
    for p in polys:
        if not _inside_unit(p):
            return False
    m = len(polys)
    for i in range(m):
        for j in range(i + 1, m):
            if _overlap(polys[i], polys[j]):
                return False
    return True


def _grid(n, k):
    side = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]


def _try_tilt(squares, idx, max_delta=0.02):
    """Try small random tilts/moves for square idx, keep if legal and sum improves."""
    best = squares[idx]
    cx, cy, a, s = best
    best_s = s
    for _ in range(10):
        na = a + random.uniform(-0.05, 0.05)
        ncx = cx + random.uniform(-max_delta, max_delta)
        ncy = cy + random.uniform(-max_delta, max_delta)
        ns = s * random.uniform(0.98, 1.02)
        cand = list(squares)
        cand[idx] = (ncx, ncy, na, ns)
        if _feasible(cand):
            if ns > best_s:
                return cand, True
    return squares, False


def _optimize_local(squares, iterations=200):
    """Simple coordinate descent on side lengths with feasibility checks."""
    n = len(squares)
    squares = [list(sq) for sq in squares]
    improved = True
    it = 0
    while improved and it < iterations:
        improved = False
        it += 1
        for i in range(n):
            cx, cy, a, s = squares[i]
            if s < 1e-9:
                # try to insert a small square at a random free location
                for _ in range(20):
                    ncx = random.uniform(0.05, 0.95)
                    ncy = random.uniform(0.05, 0.95)
                    ns = random.uniform(0.001, 0.02)
                    cand = [list(sq) for sq in squares]
                    cand[i] = [ncx, ncy, 0.0, ns]
                    if _feasible([tuple(x) for x in cand]):
                        squares = cand
                        improved = True
                        break
                continue
            # increase size slightly
            delta = 0.002
            cand = [list(sq) for sq in squares]
            cand[i][3] = s + delta
            if _feasible([tuple(x) for x in cand]):
                squares = cand
                improved = True
                continue
            # try shrink then move
            for _ in range(5):
                cand = [list(sq) for sq in squares]
                cand[i][0] = cx + random.uniform(-0.01, 0.01)
                cand[i][1] = cy + random.uniform(-0.01, 0.01)
                cand[i][2] = a + random.uniform(-0.03, 0.03)
                if _feasible([tuple(x) for x in cand]):
                    if cand[i][3] > s - 1e-6:
                        squares = cand
                        improved = True
                        break
    return [tuple(x) for x in squares]


def _sum_sides(squares):
    return sum(sq[3] for sq in squares)


def _special_small(n):
    """Some good arrangements for small n found by hand / improvement search."""
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.75, 0.0, s)]
    if n == 3:
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s), (0.5, 0.75, 0.0, s)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        # grid 2x2 plus a central small square
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s),
                (0.25, 0.75, 0.0, s), (0.75, 0.75, 0.0, s),
                (0.5, 0.5, 0.25, 0.0)]
    if n == 6:
        # 2x3 grid
        sx = 1.0 / 2
        sy = 1.0 / 3
        ss = min(sx, sy)
        res = []
        for i in range(2):
            for j in range(3):
                res.append(((i + 0.5) * sx, (j + 0.5) * sy, 0.0, ss))
        return res
    if n == 7:
        # 3x3 grid minus two squares, shift to fit 7 equal-ish
        k = 3
        s = 1.0 / k
        res = []
        for i in range(k):
            for j in range(k):
                if len(res) < n:
                    res.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        while len(res) < n:
            res.append((0.5, 0.5, 0.0, 0.0))
        return res[:n]
    return None


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    sp = _special_small(n)
    if sp is not None:
        # Validate special; if invalid, fall back
        if _feasible(sp):
            return sp
    # Baseline grid
    best = None
    best_sum = -1.0
    # Try square grids and rectangular grids
    for k in range(1, int(math.isqrt(n)) + 2):
        for ell in range(1, n // k + 2):
            if k * ell < n:
                continue
            if k * ell > n:
                # only use exactly n unless we can zero-fill
                pass
            # Fit k x ell grid in unit square. Square size = min(1/k, 1/ell)
            sx = 1.0 / k
            sy = 1.0 / ell
            side = min(sx, sy)
            if k * ell < n:
                continue
            res = []
            cnt = 0
            for i in range(k):
                for j in range(ell):
                    if cnt < n:
                        res.append(((i + 0.5) * sx if side == sx else (i + 0.5) * side + (1 - k * side) / 2,
                                    (j + 0.5) * sy if side == sy else (j + 0.5) * side + (1 - ell * side) / 2,
                                    0.0, side))
                        cnt += 1
            while len(res) < n:
                res.append((0.5, 0.5, 0.0, 0.0))
            res = res[:n]
            if _feasible(res):
                tot = _sum_sides(res)
                if tot > best_sum:
                    best_sum = tot
                    best = res
    # Fallback simple grid
    k = math.isqrt(n)
    base = _grid(n, k)
    if best is None or _sum_sides(base) > best_sum:
        best = base
        best_sum = _sum_sides(best)
    # Local optimisation
    random.seed(12345 + n)
    try:
        improved = _optimize_local(best, iterations=30)
        if _feasible(improved) and _sum_sides(improved) >= best_sum - 1e-9:
            best = improved
    except Exception:
        pass
    return best
