import math
import random
import numpy as np
from scipy.optimize import minimize


def _axes(angle):
    # angle fraction of full turn
    a = 2.0 * math.pi * angle
    c, s = math.cos(a), math.sin(a)
    return (c, s), (-s, c)


def _corners(cx, cy, angle, side):
    u, v = _axes(angle)
    h = 0.5 * side
    return [
        (cx + h * (u[0] + v[0]), cy + h * (u[1] + v[1])),
        (cx + h * (u[0] - v[0]), cy + h * (u[1] - v[1])),
        (cx + h * (-u[0] - v[0]), cy + h * (-u[1] - v[1])),
        (cx + h * (-u[0] + v[0]), cy + h * (-u[1] + v[1])),
    ]


def _project_poly(poly, axis):
    vals = [p[0] * axis[0] + p[1] * axis[1] for p in poly]
    return min(vals), max(vals)


def _overlap_area_sq(a, b):
    # SAT sufficient for two convex polygons: if no separating axis, they overlap.
    pa, pb = a
    axes = []
    for poly in (pa, pb):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            ex, ey = x2 - x1, y2 - y1
            ln = math.hypot(ex, ey)
            if ln > 1e-15:
                axes.append((-ey / ln, ex / ln))
    for ax in axes:
        lo1, hi1 = _project_poly(pa, ax)
        lo2, hi2 = _project_poly(pb, ax)
        if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
            return 0.0
    # approximate overlap area penalty via intersection of bounding boxes in local axes
    # use a small positive value: enough to push apart
    return 1e-4


def _objective(x, n):
    # x length 4n; we maximize sum side, so minimize -sum side, plus small centering penalty
    sides = x[3::4]
    return -float(np.sum(sides))


def _constraints_vec(x, n):
    vals = []
    # boundary containment: all corners in [0,1]
    for i in range(n):
        cx, cy, ang, side = x[4 * i:4 * i + 4]
        if side < 0:
            vals.append(side)  # require >=0 -> <=0
        for px, py in _corners(cx, cy, ang, side):
            vals.append(px)
            vals.append(1.0 - px)
            vals.append(py)
            vals.append(1.0 - py)
    return np.array(vals)


def _constraints_nonoverlap(x, n, pairs):
    vals = []
    polys = []
    for i in range(n):
        cx, cy, ang, side = x[4 * i:4 * i + 4]
        if side <= 0:
            polys.append(None)
        else:
            polys.append(_corners(cx, cy, ang, side))
    for i, j in pairs:
        if polys[i] is None or polys[j] is None:
            continue
        a, b = polys[i], polys[j]
        pa, pb = a, b
        axes = []
        for poly in (pa, pb):
            m = len(poly)
            for k in range(m):
                x1, y1 = poly[k]
                x2, y2 = poly[(k + 1) % m]
                ex, ey = x2 - x1, y2 - y1
                ln = math.hypot(ex, ey)
                if ln > 1e-15:
                    axes.append((-ey / ln, ex / ln))
        sep = -1e9
        for ax in axes:
            lo1, hi1 = _project_poly(pa, ax)
            lo2, hi2 = _project_poly(pb, ax)
            sep = max(sep, max(lo2 - hi1, lo1 - hi2))
        # sep >0 means separated; require sep >= 0
        vals.append(sep)
    return np.array(vals) if vals else np.array([0.0])


def _penalty(x, n, pairs):
    c = _constraints_vec(x, n)
    pen = 0.0
    viol = np.minimum(c, 0.0)
    pen += 1000.0 * float(np.sum(viol * viol))
    o = _constraints_nonoverlap(x, n, pairs)
    if len(o):
        viol2 = np.minimum(o, 0.0)
        pen += 10000.0 * float(np.sum(viol2 * viol2))
    return pen


def _pack_greedy(n, rng):
    # Schedule of side lengths: roughly decreasing, trying to cover unit square.
    # Use area-based estimate: sum side_i^2 <= 1 (necessary, not sufficient).
    sides = []
    if n <= 0:
        return []
    # initial roughly equal small squares
    base = 1.0 / math.sqrt(float(n))
    if n >= 4:
        # try to include one large square
        base = 0.85 / math.sqrt(float(n))
    for i in range(n):
        f = (0.85 ** i) * (1.0 + rng.uniform(-0.02, 0.02))
        sides.append(base * f)
    # normalize area to <= 0.98
    area = sum(s * s for s in sides)
    if area > 0:
        scale = math.sqrt(0.98 / area)
        sides = [min(0.999, s * scale) for s in sides]
    return sides


def _optimize_once(n, sides, rng, maxiter=300):
    if n == 0:
        return []
    x = np.zeros(4 * n)
    # place greedily by random locations and try to avoid overlap
    polys = []
    for i in range(n):
        s = sides[i]
        best = None
        best_pen = 1e18
        for _ in range(30):
            cx = rng.uniform(0.5 * s, 1.0 - 0.5 * s)
            cy = rng.uniform(0.5 * s, 1.0 - 0.5 * s)
            ang = rng.choice([0.0, 0.25, 0.5, 0.75]) if s > 0 else 0.0
            x[4 * i:4 * i + 4] = [cx, cy, ang, s]
            if s <= 0:
                break
            # penalty against already placed
            xv = x.copy()
            pairs = [(k, i) for k in range(i)]
            p = _penalty(xv, n, pairs)
            if p < best_pen:
                best_pen = p
                best = x[4 * i:4 * i + 4].copy()
        if best is not None:
            x[4 * i:4 * i + 4] = best
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
    # Use SLSQP with smooth penalty. To keep size feasible, work with transformed sizes via softmax? Simpler: clamp.
    def f(z):
        return _objective(z, n) + _penalty(z, n, pairs)

    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))
        bounds.append((0.0, 1.0))
        bounds.append((-10.0, 10.0))
        bounds.append((0.0, 1.0))

    bestx = x.copy()
    bestval = f(bestx)
    # coordinate perturbation then SLSQP
    for it in range(4):
        z = bestx.copy()
        for i in range(n):
            z[4 * i] = min(1.0, max(0.0, z[4 * i] + rng.uniform(-0.02, 0.02)))
            z[4 * i + 1] = min(1.0, max(0.0, z[4 * i + 1] + rng.uniform(-0.02, 0.02)))
            z[4 * i + 2] = z[4 * i + 2] + rng.uniform(-0.03, 0.03)
            z[4 * i + 3] = min(1.0, max(0.0, z[4 * i + 3] * (1.0 + rng.uniform(-0.03, 0.03))))
        try:
            res = minimize(f, z, method='L-BFGS-B', bounds=bounds,
                           options={'maxiter': maxiter, 'ftol': 1e-12, 'gtol': 1e-8})
            if res.fun < bestval:
                bestval = res.fun
                bestx = res.x.copy()
        except Exception:
            pass

    # final cleanup: shrink any overlapping or out-of-bounds squares
    def repair(z):
        z = z.copy()
        for i in range(n):
            cx, cy, ang, side = z[4 * i:4 * i + 4]
            side = max(0.0, min(1.0, side))
            # shrink to fit boundary
            u, v = _axes(ang)
            half = 0.5 * side
            dx = half * (abs(u[0]) + abs(v[0]))
            dy = half * (abs(u[1]) + abs(v[1]))
            if dx > cx:
                side = min(side, cx / (abs(u[0]) + abs(v[0]) + 1e-15))
            if dx > 1.0 - cx:
                side = min(side, (1.0 - cx) / (abs(u[0]) + abs(v[0]) + 1e-15))
            if dy > cy:
                side = min(side, cy / (abs(u[1]) + abs(v[1]) + 1e-15))
            if dy > 1.0 - cy:
                side = min(side, (1.0 - cy) / (abs(u[1]) + abs(v[1]) + 1e-15))
            z[4 * i:4 * i + 4] = [cx, cy, ang, max(0.0, side)]
        # remove overlaps by shrinking later ones
        for _ in range(10):
            changed = False
            for i in range(n):
                for j in range(i + 1, n):
                    ci = z[4 * i:4 * i + 4]
                    cj = z[4 * j:4 * j + 4]
                    if ci[3] <= 0 or cj[3] <= 0:
                        continue
                    pa = _corners(ci[0], ci[1], ci[2], ci[3])
                    pb = _corners(cj[0], cj[1], cj[2], cj[3])
                    # separation check
                    axes = []
                    for poly in (pa, pb):
                        m = len(poly)
                        for k in range(m):
                            x1, y1 = poly[k]
                            x2, y2 = poly[(k + 1) % m]
                            ex, ey = x2 - x1, y2 - y1
                            ln = math.hypot(ex, ey)
                            if ln > 1e-15:
                                axes.append((-ey / ln, ex / ln))
                    sep = -1e18
                    for ax in axes:
                        lo1, hi1 = _project_poly(pa, ax)
                        lo2, hi2 = _project_poly(pb, ax)
                        sep = max(sep, max(lo2 - hi1, lo1 - hi2))
                    if sep < -1e-9:
                        # overlap; shrink the larger one slightly
                        if ci[3] >= cj[3]:
                            z[4 * i + 3] *= 0.98
                        else:
                            z[4 * j + 3] *= 0.98
                        changed = True
            if not changed:
                break
        return z

    bestx = repair(bestx)
    return [(float(bestx[4 * i]), float(bestx[4 * i + 1]),
             float(bestx[4 * i + 2]), float(bestx[4 * i + 3])) for i in range(n)]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    rng = random.Random(12345)
    best = None
    best_sum = -1.0
    base_sides = _pack_greedy(n, rng)
    # several restarts with different schedules
    schedules = [base_sides]
    for _ in range(3):
        schedules.append(_pack_greedy(n, rng))
    for ks in schedules:
        for trial in range(2):
            r = random.Random(1000 + n * 17 + trial)
            cand = _optimize_once(n, ks, r)
            total = sum(max(0.0, s) for _, _, _, s in cand)
            if total > best_sum:
                best_sum = total
                best = cand
    # final safety
    out = []
    for cx, cy, ang, side in best:
        out.append((min(1.0, max(0.0, cx)), min(1.0, max(0.0, cy)),
                    float(ang), max(0.0, min(1.0, side))))
    return out
