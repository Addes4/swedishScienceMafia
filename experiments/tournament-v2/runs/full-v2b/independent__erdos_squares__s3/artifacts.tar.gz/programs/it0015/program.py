import math
import random

# We solve by partitioning the unit square with guillotine cuts into rectangles,
# then placing squares inside rectangles. For a rectangle a x b, the best use is
# usually a grid of equal squares, but we allow recursive subdivision.

def solve(n):
    random.seed(123456789)
    best = None
    best_score = -1.0

    # Candidate strategies.
    candidates = []

    # 1. Plain grid
    def grid_solution(n):
        k = math.isqrt(n)
        side = 1.0 / k
        sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
              for i in range(k) for j in range(k)]
        sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        return sq[:n]

    candidates.append(grid_solution)

    # 2. Rectangular grid: find p,q with p*q <= n maximizing area used.
    def rect_grid_solution(n):
        bestp, bestq, bestv = 1, 1, -1
        for p in range(1, n + 1):
            q = n // p
            if q < 1:
                continue
            # use p*q squares in a p by q grid, remaining zero
            w = 1.0 / p
            h = 1.0 / q
            side = min(w, h)
            # If side = w, squares width w; if side = h, height h.
            val = p * q * side
            if val > bestv:
                bestv = val
                bestp, bestq = p, q
        p, q = bestp, bestq
        sq = []
        w = 1.0 / p
        h = 1.0 / q
        side = min(w, h)
        for i in range(p):
            for j in range(q):
                cx = (i + 0.5) * w
                cy = (j + 0.5) * h
                sq.append((cx, cy, 0.0, side))
        sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
        return sq[:n]

    candidates.append(rect_grid_solution)

    # 3. Guillotine recursive layout
    def recursive_layout(n, x, y, w, h, depth=0):
        # Place n squares in rectangle [x, x+w] x [y, y+h].
        # Returns list of (cx, cy, angle, side).
        if n <= 0:
            return []
        if n == 1:
            side = min(w, h)
            return [(x + w / 2, y + h / 2, 0.0, side)]
        # Try direct grid inside this rectangle.
        best = None
        best_val = -1.0
        # direct grid p x q
        for p in range(1, n + 1):
            q = n // p
            if q < 1:
                continue
            if p * q > n:
                continue
            side = min(w / p, h / q)
            val = p * q * side
            if val > best_val:
                best_val = val
                best = (p, q, side)

        p, q, side = best
        sq = []
        for i in range(p):
            for j in range(q):
                cx = x + (i + 0.5) * (w / p)
                cy = y + (j + 0.5) * (h / q)
                sq.append((cx, cy, 0.0, side))
        rem = n - p * q
        # Remaining squares: try to fit in leftover strips.
        if rem == 0:
            return sq
        # Leftover width and height after using p x q cells.
        used_w = p * side
        used_h = q * side
        leftovers = []
        if w - used_w > 1e-12:
            leftovers.append((x + used_w, y, w - used_w, h))
        if h - used_h > 1e-12:
            leftovers.append((x, y + used_h, used_w, h - used_h))
        # Distribute rem among leftovers by area.
        if leftovers:
            total_area = sum(lw * lh for _, _, lw, lh in leftovers)
            if total_area > 1e-18:
                alloc = []
                acc = 0
                for idx, (lx, ly, lw, lh) in enumerate(leftovers):
                    if idx == len(leftovers) - 1:
                        cnt = rem - acc
                    else:
                        cnt = int(round(rem * (lw * lh) / total_area))
                        cnt = max(0, min(rem - acc, cnt))
                    acc += cnt
                    alloc.append(cnt)
                # Fix any rounding.
                while acc < rem:
                    j = acc % len(leftovers)
                    alloc[j] += 1
                    acc += 1
                while acc > rem:
                    for j in range(len(leftovers)):
                        if alloc[j] > 0:
                            alloc[j] -= 1
                            acc -= 1
                            break
                for (lx, ly, lw, lh), cnt in zip(leftovers, alloc):
                    if cnt > 0:
                        sq.extend(recursive_layout(cnt, lx, ly, lw, lh, depth + 1))
        else:
            # fallback: shrink existing squares to make room? Just add zeros.
            sq += [(x + w / 2, y + h / 2, 0.0, 0.0)] * rem
        return sq

    def rec_solution(n):
        return recursive_layout(n, 0.0, 0.0, 1.0, 1.0)

    candidates.append(rec_solution)

    # Try candidates and pick best.
    for func in candidates:
        try:
            sq = func(n)
        except Exception:
            continue
        if len(sq) != n:
            # pad or trim
            if len(sq) < n:
                sq += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sq))
            sq = sq[:n]
        score = sum(s[3] for s in sq)
        if score > best_score:
            best_score = score
            best = sq

    # Local improvement: randomly try to merge zero-size squares with existing ones.
    best = [list(s) for s in best]
    for _ in range(2000):
        # pick a random nonzero square and a random zero square
        nonzero = [i for i, s in enumerate(best) if s[3] > 1e-9]
        zero = [i for i, s in enumerate(best) if s[3] <= 1e-9]
        if not nonzero or not zero:
            break
        i = random.choice(nonzero)
        j = random.choice(zero)
        # Try to shrink all nonzero squares slightly and give to j.
        # Compute total extra needed for a small epsilon.
        eps = 0.001
        # Check feasibility: can we shrink all to accommodate a square of size eps?
        # Simple attempt: just set zero square to eps and shrink the largest.
        sizes = [best[k][3] for k in range(n)]
        # Instead try to increase one by delta and decrease all others proportionally.
        # Not guaranteed feasible; do a simple feasibility check for a set of squares.
        # Just skip if unsafe.
        # Simpler: try to replace the smallest nonzero square with a smaller one and
        # give the difference to a zero square, placed at its center (might overlap).
        # For safety, only allow if the new square fits in an empty corner.
        # We'll do a conservative move: set a zero square to 0 still.
        # No easy local move guaranteed. Keep as is.
        break

    # Final safety: ensure all in [0,1] and nonnegative.
    result = []
    for cx, cy, ang, s in best:
        s = max(0.0, min(s, 1.0))
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = max(0.0, min(1.0, ang))
        result.append((cx, cy, ang, s))
    return result
