import math
import numpy as np
from scipy.optimize import minimize


def _sat_overlap_constraint(a, b):
    """
    Given two squares a=(cx,cy,ang,side), b likewise, return a value >=0 iff
    they do NOT share an interior (i.e. they are separated or touching).
    We use the separating axis theorem: project both squares onto the 4 candidate
    axes (2 edge normals of each square) and require that on at least one axis
    the projections do not overlap in their interior.
    Returns the max over axes of (gap on that axis). gap >= 0 means separated
    (or touching) along that axis. Also handles side==0 (degenerate point).
    """
    def corners(cx, cy, ang, side):
        if side <= 0.0:
            return np.array([[cx, cy]])
        th = ang * 2.0 * math.pi
        c, s = math.cos(th), math.sin(th)
        h = side * 0.5
        pts = np.array([[-h, -h], [h, -h], [h, h], [-h, h]])
        R = np.array([[c, -s], [s, c]])
        return pts @ R.T + np.array([cx, cy])

    pa = corners(*a)
    pb = corners(*b)
    if len(pa) == 1 and len(pb) == 1:
        return 0.0  # two points never share interior
    # candidate axes: edge normals of each square
    axes = []
    for pts in (pa, pb):
        if len(pts) >= 2:
            for i in range(len(pts)):
                e = pts[(i + 1) % len(pts)] - pts[i]
                nrm = math.hypot(e[0], e[1])
                if nrm > 1e-12:
                    axes.append(np.array([-e[1] / nrm, e[0] / nrm]))
    if not axes:
        return 0.0
    best = -1e18
    for ax in axes:
        pa_d = pa @ ax
        pb_d = pb @ ax
        gap = max(pa_d.min() - pb_d.max(), pb_d.min() - pa_d.max())
        if gap > best:
            best = gap
    return best


def _make_initial_grid(n):
    """Initial guess: grid of squares (largest k x k) plus tiny extra squares."""
    k = max(1, math.isqrt(n))
    # fit k x k grid with a small margin
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            if len(squares) < n:
                squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return squares


def _make_initial_strip(n):
    """Alternative: a single row of n equal squares (worst case 1/n each) - not good"""
    return _make_initial_grid(n)


def _objective(params, n):
    # params: [cx1,...,cxn, cy1,...,cyn, a1,...,an, s1,...,sn]
    s = params[3 * n:4 * n]
    return -np.sum(s)


def _solve_opt(n, x0, maxiter=200):
    n = int(n)
    if n == 0:
        return []

    # pack parameters
    x0 = np.array([c for sq in x0 for c in sq], dtype=float)
    # x0 has length 4n in order cx1,cy1,a1,s1,...

    def pack():
        return x0

    # if a side is 0, we can still optimize but gradients via SAT may be flat.
    # Give all sides a small positive value initially.
    for i in range(n):
        if x0[4 * i + 3] <= 1e-9:
            x0[4 * i + 3] = 0.01

    bounds = []
    for i in range(n):
        cx = x0[4 * i + 0]
        cy = x0[4 * i + 1]
        a = x0[4 * i + 2]
        s = x0[4 * i + 3]
        # center bounds depend on side and angle but to be safe, use broad bounds,
        # later constraint enforces containment.
        bounds.append((0.0, 1.0))     # cx
        bounds.append((0.0, 1.0))     # cy
        bounds.append((0.0, 1.0))     # angle (fraction of turn)
        bounds.append((0.0, 1.0))     # side

    cons = []
    # containment constraints: each square corner inside [0,1]^2
    def corner_coords(cx, cy, ang, side):
        th = ang * 2.0 * math.pi
        c, s = math.cos(th), math.sin(th)
        h = side * 0.5
        pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
        R = [(c * px - s * py + cx, s * px + c * py + cy) for px, py in pts]
        return R

    def containment(params):
        # returns array of values >= 0
        vals = []
        for i in range(n):
            cx = params[4 * i + 0]
            cy = params[4 * i + 1]
            a = params[4 * i + 2]
            s = params[4 * i + 3]
            for px, py in corner_coords(cx, cy, a, s):
                vals.append(px)
                vals.append(1.0 - px)
                vals.append(py)
                vals.append(1.0 - py)
        return np.array(vals)

    cons.append({'type': 'ineq', 'fun': containment})

    # non-overlap constraints via SAT
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]

    def nonoverlap(params):
        vals = []
        for i, j in pairs:
            a = (params[4 * i + 0], params[4 * i + 1], params[4 * i + 2], params[4 * i + 3])
            b = (params[4 * j + 0], params[4 * j + 1], params[4 * j + 2], params[4 * j + 3])
            # scale: to make multiple {-1,0,1} axes smoother, but SAT returns gap.
            # To avoid discontinuity in max(), use a soft formulation? For now,
            # return the max gap. Since we require >= 0, feasibility is exact.
            vals.append(_sat_overlap_constraint(a, b))
        return np.array(vals)

    cons.append({'type': 'ineq', 'fun': nonoverlap})

    # Use SLSQP
    def obj(p):
        return -np.sum(p[3::4]) if False else _objective(p, n)

    # We'll use numerical gradients because of the max() in SAT.
    res = minimize(_objective, x0, args=(n,),
                   method='SLSQP', bounds=bounds, constraints=cons,
                   options={'maxiter': maxiter, 'ftol': 1e-12, 'disp': False})

    params = res.x
    result = []
    for i in range(n):
        cx = float(np.clip(params[4 * i + 0], 0.0, 1.0))
        cy = float(np.clip(params[4 * i + 1], 0.0, 1.0))
        a = float(params[4 * i + 2] % 1.0)
        s = float(np.clip(params[4 * i + 3], 0.0, 1.0))
        # final safety: ensure containment by shrinking if needed
        # compute max extent
        th = a * 2.0 * math.pi
        c, sn = math.cos(th), math.sin(th)
        h = s * 0.5
        xs = []
        ys = []
        for px, py in [(-h, -h), (h, -h), (h, h), (-h, h)]:
            xs.append(c * px - sn * py + cx)
            ys.append(sn * px + c * py + cy)
        # clip to be safe
        minx, maxx = min(xs), max(xs)
        miny, maxy = min(ys), max(ys)
        # if out of bounds, shrink slightly
        if minx < 0 or maxx > 1 or miny < 0 or maxy > 1:
            # shift center back in
            dx = max(0.0 - minx, maxx - 1.0)
            dy = max(0.0 - miny, maxy - 1.0)
            # reduce side by needed amount
            factor = 1.0
            if s > 0:
                w = maxx - minx
                hgt = maxy - miny
                if w > 1.0:
                    factor = min(factor, 1.0 / w) if w > 1e-9 else 0.0
                if hgt > 1.0:
                    factor = min(factor, 1.0 / hgt) if hgt > 1e-9 else 0.0
                s *= factor
            cx = np.clip(cx, 0.0, 1.0)
            cy = np.clip(cy, 0.0, 1.0)
        result.append((cx, cy, a, s))
    return result


def solve(n):
    n = int(n)
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Try a few initial guesses and pick the best.
    best = None
    best_score = -1.0

    # Candidate initializations
    candidates = []

    # 1. Standard grid with tiny extras
    candidates.append(_make_initial_grid(n))

    # 2. Grid with fractional sizes to use leftover space:
    #    place k*k squares of size 1/k, then place remaining ones in a row
    k = max(1, int(math.isqrt(n)))
    g = _make_initial_grid(n)
    # improve extras: make them slightly bigger if possible; but optimizer handles.
    candidates.append([row[:] for row in g])

    # 3. Random perturbations of the grid
    rng = np.random.RandomState(12345)
    for _ in range(3):
        cand = [row[:] for row in g]
        for sq in cand:
            sq[0] += rng.uniform(-0.02, 0.02)
            sq[1] += rng.uniform(-0.02, 0.02)
            sq[0] = min(max(sq[0], 0.0), 1.0)
            sq[1] = min(max(sq[1], 0.0), 1.0)
        candidates.append(cand)

    # 4. For prime-ish n, a single row of squares might be better than grid? No,
    #    but try a formula: all squares in one row of size 1/n each -> sum=1, worse.
    #    Same for single column. Not useful.

    for x0 in candidates:
        try:
            sol = _solve_opt(n, x0, maxiter=250)
        except Exception:
            continue
        score = sum(sq[3] for sq in sol)
        if score > best_score:
            best_score = score
            best = sol

    if best is None:
        best = _make_initial_grid(n)

    # Final validation and score check: if optimizer failed to reach a
    # feasible solution, compare with simple grid.
    def is_feasible(sol):
        # check containment
        for cx, cy, a, s in sol:
            if s <= 1e-12:
                continue
            th = a * 2 * math.pi
            c, sn = math.cos(th), math.sin(th)
            h = s * 0.5
            for px, py in [(-h, -h), (h, -h), (h, h), (-h, h)]:
                x = c * px - sn * py + cx
                y = sn * px + c * py + cy
                if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
                    return False
        # check overlaps
        for i in range(len(sol)):
            for j in range(i + 1, len(sol)):
                if _sat_overlap_constraint(sol[i], sol[j]) < -1e-9:
                    return False
        return True

    score_best = sum(sq[3] for sq in best)
    if not is_feasible(best):
        # fall back to grid
        g = _make_initial_grid(n)
        score_g = sum(sq[3] for sq in g)
        if score_g >= score_best:
            best = g

    # Final sanity: ensure we return exactly n tuples with numbers in [0,1]
    out = []
    for cx, cy, a, s in best[:n]:
        out.append((float(np.clip(cx, 0.0, 1.0)),
                    float(np.clip(cy, 0.0, 1.0)),
                    float(a % 1.0),
                    float(np.clip(s, 0.0, 1.0))))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]
