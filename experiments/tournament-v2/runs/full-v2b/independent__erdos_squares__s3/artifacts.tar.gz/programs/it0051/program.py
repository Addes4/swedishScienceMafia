import math
import random
from scipy.optimize import minimize

# ---------- geometric non-overlap helpers ----------
def _sq_vertices(cx, cy, ang, s):
    """Return the four corners of a square as a list of (x, y)."""
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = 0.5 * s
    # local corners (relative to centre)
    loc = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + x * ca - y * sa, cy + x * sa + y * ca) for x, y in loc]

def _overlap_area_sq2(c1, c2):
    """Approximate penetration/overlap measure for two squares.
    Returns 0 if disjoint, otherwise a positive value (SAT based).
    c = (cx, cy, ang, s)."""
    v1 = _sq_vertices(*c1)
    v2 = _sq_vertices(*c2)
    # axes to test: x/y of each square
    def axes(v, ang):
        a = 2.0 * math.pi * ang
        ca, sa = math.cos(a), math.sin(a)
        return [(ca, sa), (-sa, ca)]  # edge directions
    ax = axes(None, c1[2]) + axes(None, c2[2])
    # Also include edge normals? For squares edge dirs are enough (normals parallel).
    # Compute projections
    pts1 = v1
    pts2 = v2
    min_overlap = 1e9
    for (axx, axy) in ax:
        p1 = [x * axx + y * axy for (x, y) in pts1]
        p2 = [x * axx + y * axy for (x, y) in pts2]
        o = min(max(p1) - min(p2), max(p2) - min(p1))
        if o <= 0:
            return 0.0
        if o < min_overlap:
            min_overlap = o
    return min_overlap  # positive => overlapping along all axes

def _inside(c):
    """Return penalty if square is outside unit square (sum of violations)."""
    cx, cy, ang, s = c
    v = _sq_vertices(cx, cy, ang, s)
    pen = 0.0
    for x, y in v:
        if x < 0: pen += -x
        if x > 1: pen += x - 1
        if y < 0: pen += -y
        if y > 1: pen += y - 1
    return pen

# ---------- heuristic construction ----------
def _grid_fill(n):
    """Best k x k grid (k=floor(sqrt(n))) + leftover zero squares."""
    k = int(math.isqrt(n))
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]

def _grid_rectangular(n):
    """Try all factor pairs (a*b <= n) and choose best grid layout."""
    best, best_sum = None, -1.0
    for a in range(1, n + 1):
        if n % a != 0:
            continue
        b = n // a
        w, h = 1.0 / a, 1.0 / b
        s = min(w, h)
        sq = [((i + 0.5) * w, (j + 0.5) * h, 0.0, s)
              for i in range(a) for j in range(b)]
        total = s * len(sq)
        if total > best_sum:
            best_sum = total
            best = sq
    if best is None:
        return _grid_fill(n)
    # fill with zero-size squares if needed
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]

def _strips(n, angle_deg=0.0):
    """Place squares in horizontal or rotated strips."""
    ang = angle_deg / 360.0
    a = 2 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    # We build a big square of side 1, filled with strips.
    # For simplicity: place n squares in a single row, rotated.
    # Actually do a rotated grid: partition unit square into k x k cells,
    # rotate the entire pattern slightly if it helps? Hard.
    # Here just return rotated grid variant: identical to grid but with angle.
    k = int(math.isqrt(n))
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, ang, side)
               for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]

def _hex_packing(n):
    """Try a hexagonal-like staggered grid with small rotation."""
    # Place squares in rows; offset alternate rows.
    # Use grid spacing slightly larger.
    best = None
    best_sum = -1.0
    for rows in range(1, n + 1):
        cols = (n + rows - 1) // rows
        for rot_deg in (0.0, 2.0, 5.0, 10.0, 15.0, 20.0, 30.0, 45.0):
            ang = rot_deg / 360.0
            # bounding box for a rotated square of side s is s*(|cos|+|sin|)
            a = 2 * math.pi * ang
            ca, sa = math.cos(a), math.sin(a)
            # find max side that fits rows x cols with offset
            # approximate: use grid cell width = 1/cols, height = 1/rows
            s_guess = min(1.0 / cols, 1.0 / rows)
            # try to adjust for rotation
            bbox_factor = abs(ca) + abs(sa)
            s_fit = s_guess / bbox_factor
            if s_fit <= 0:
                continue
            sq = []
            for r in range(rows):
                for c in range(cols):
                    if len(sq) >= n:
                        break
                    # stagger even rows
                    x_off = 0.0
                    if r % 2 == 1:
                        x_off = 0.5 / cols
                    cx = (c + 0.5 + x_off) / cols
                    cy = (r + 0.5) / rows
                    # clamp center so square inside
                    # compute extent
                    hw = s_fit * bbox_factor / 2.0
                    cx = max(hw, min(1.0 - hw, cx))
                    cy = max(hw, min(1.0 - hw, cy))
                    sq.append((cx, cy, ang, s_fit))
            if len(sq) > n:
                sq = sq[:n]
            while len(sq) < n:
                sq.append((0.5, 0.5, 0.0, 0.0))
            total = sum(c[3] for c in sq)
            if total > best_sum:
                best_sum = total
                best = sq
    return best

# ---------- local optimizer ----------
def _refine(squares, n, maxiter=200):
    """Maximise sum of sides with SLSQP, subject to non-overlap and containment."""
    # variables: for each square: cx, cy, ang, s
    x0 = []
    for (cx, cy, ang, s) in squares:
        x0.extend([cx, cy, ang, s])
    x0 = [max(0.0, min(1.0, v)) for v in x0]

    # If too many variables, subsample refine? For many n we may limit.
    # We'll refine only the largest few? Actually refine all, but time constrained.
    # Use penalty method with SLSQP on inequality constraints.
    # Constraints:
    # 1) each square inside unit square (vertices in [0,1]) -> 8 inequalities per square
    #    Actually we need all vertices >=0 and <=1. Equivalent: for square with centre c and angle a,
    #    max x = cx + s/2*(|cos|+|sin|) <= 1, min x = cx - ... >=0, same y.
    #    So 4 inequalities per square: cx ± hx within [0,1], cy ± hy within [0,1].
    #    where hx = s/2*(|cos|+|sin|), hy = s/2*(|cos|+|sin|) (same).
    # 2) non-overlap between all pairs. Use SAT: for each axis of each square,
    #    the projected intervals must not overlap. We'll enforce strict non-overlap.
    #    For squares, the separating axis can be one of the 4 edge normals (2 per square).
    #    We'll use 4 inequalities per pair (one per axis) requiring interval gap >= 0.

    def unpack(x):
        out = []
        for i in range(n):
            out.append((x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]))
        return out

    def objective(x):
        return -sum(x[4*i+3] for i in range(n))  # maximise sum

    cons = []
    # bounds
    bnds = []
    for i in range(n):
        bnds.append((0.0, 1.0))  # cx
        bnds.append((0.0, 1.0))  # cy
        bnds.append((0.0, 1.0))  # ang (fraction of turn, mod 1? allow [0,1))
        bnds.append((0.0, 1.0))  # s

    def ineq_inside(x, i):
        cx, cy, ang, s = x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]
        a = 2 * math.pi * ang
        ca, sa = math.cos(a), math.sin(a)
        hx = 0.5 * s * (abs(ca) + abs(sa))
        hy = hx
        # cx - hx >= 0, cx + hx <= 1
        return [cx - hx, 1.0 - (cx + hx), cy - hy, 1.0 - (cy + hy)]
    for i in range(n):
        cons.append({'type': 'ineq', 'fun': lambda x, i=i: -ineq_inside(x, i)[0]})  # cx - hx >=0 => hx - cx <=0
        # better to phrase directly:
    # Redo constraints properly:
    cons = []
    for i in range(n):
        def f(x, i=i):
            cx, cy, ang, s = x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]
            a = 2 * math.pi * ang
            ca, sa = math.cos(a), math.sin(a)
            hx = 0.5 * s * (abs(ca) + abs(sa))
            hy = hx
            return [cx - hx, 1.0 - (cx + hx), cy - hy, 1.0 - (cy + hy)]
        for j in range(4):
            cons.append({'type': 'ineq', 'fun': lambda x, i=i, j=j: f(x, i)[j]})

    # non-overlap constraints: SAT
    # For each pair (i,j), for each axis (2 from i, 2 from j), require gap >= 0.
    # To reduce number, we can use a smooth approximation: overlapping area penalty.
    # For SLSQP, we use inequality constraints: the projections must be separated.
    # Actually SAT: disjoint if there exists an axis where projections separated.
    # Hard to encode as inequalities. Instead use a penalty: the minimum overlap
    # over all axes must be <= 0. We can enforce by requiring one axis separated.
    # Use: for each axis, require max(min1)-min(max2) <= 0 OR max(min2)-min(max1) <= 0.
    # That's combinatorial. Use a smooth penalty: push apart.
    # Let's use a different approach: use penalty in objective, or SLSQP with all
    # pairwise constraints that max overlap <= 0, but that's non-smooth.
    # We'll approximate using four inequalities: for each axis, either interval
    # separation. Instead, we can enforce that for each axis, the sum of overlaps is zero.
    # We'll use a penalty method: add large penalty for overlap.
    # But SLSQP needs constraints. Let's use penalty in objective and SLSQP without
    # non-overlap constraints, but with penalty increasing.
    # Actually simpler: use scipy.optimize.minimize with method='SLSQP' and objective
    # = -sum(s) + penalty(overlaps) + penalty(outside). No constraints (except bounds).
    # This is often effective.

    # Use penalty method: objective includes large penalties.
    def total_obj(x):
        t = -sum(x[4*i+3] for i in range(n))
        pen = 0.0
        # boundary
        for i in range(n):
            cx, cy, ang, s = x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]
            a = 2 * math.pi * ang
            ca, sa = math.cos(a), math.sin(a)
            hx = 0.5 * s * (abs(ca) + abs(sa))
            hy = hx
            for val in (cx - hx, 1.0 - (cx + hx), cy - hy, 1.0 - (cy + hy)):
                if val < 0:
                    pen += 1000.0 * val * val
        # overlaps
        # precompute vertices
        V = []
        for i in range(n):
            cx, cy, ang, s = x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]
            V.append(_sq_vertices(cx, cy, ang, s))
        for i in range(n):
            for j in range(i + 1, n):
                # quick bounding circle check
                # SAT
                # axes from both squares
                # Instead of full SAT, compute approximate overlap area via clipping?
                # Use SAT min overlap.
                v1 = V[i]
                v2 = V[j]
                # axes: edge directions of each square
                a1 = 2 * math.pi * x[4*i+2]
                a2 = 2 * math.pi * x[4*j+2]
                axes = [(math.cos(a1), math.sin(a1)), (-math.sin(a1), math.cos(a1)),
                        (math.cos(a2), math.sin(a2)), (-math.sin(a2), math.cos(a2))]
                min_ov = 1e9
                for (axx, axy) in axes:
                    p1 = [px * axx + py * axy for (px, py) in v1]
                    p2 = [px * axx + py * axy for (px, py) in v2]
                    o1 = min(max(p1) - min(p2), max(p2) - min(p1))
                    if o1 <= 1e-9:
                        min_ov = 0.0
                        break
                    if o1 < min_ov:
                        min_ov = o1
                if min_ov > 1e-9:
                    pen += 1000.0 * min_ov * min_ov
        return t + pen

    # We'll do a few SLSQP iterations with increasing penalty.
    # But penalty is already hardcoded. Use minimize with SLSQP or L-BFGS-B.
    # Since penalty is non-smooth, use Nelder-Mead? Better: use SLSQP with
    # constraints (non-overlap as inequalities? too many). We'll just use
    # L-BFGS-B with penalty. Might get stuck.
    # Alternative: do a simple projected gradient / random jitter improvement.
    # Given time, we do a few random local searches.

    # Simpler: use scipy.optimize.minimize with method='Powell' or 'Nelder-Mead'
    # for small n; for large n, just return heuristic.
    if n <= 8:
        # use SLSQP with proper constraints for small n
        cons = []
        # boundary constraints
        for i in range(n):
            def f(x, i=i):
                cx, cy, ang, s = x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]
                a = 2 * math.pi * ang
                ca, sa = math.cos(a), math.sin(a)
                hx = 0.5 * s * (abs(ca) + abs(sa))
                hy = hx
                return [cx - hx, 1.0 - (cx + hx), cy - hy, 1.0 - (cy + hy)]
            for j in range(4):
                cons.append({'type': 'ineq', 'fun': lambda x, i=i, j=j: f(x, i)[j]})
        # non-overlap: use SAT formulated as: for each pair, for each axis,
        # either they are separated. We can't do 'or'. Instead we use a single
        # smooth constraint: the minimum overlap over axes must be <= 0.
        # That's non-smooth. Use penalty in objective instead and no constraints.
        def obj(x):
            return total_obj(x)
        # Use Nelder-Mead for small n
        res = minimize(obj, x0, method='Nelder-Mead',
                       options={'maxiter': 2000, 'xatol': 1e-6, 'fatol': 1e-6})
        x = res.x
    else:
        # For larger n, do random local search: perturb one square at a time?
        # Use coordinate descent with small random steps.
        x = x0[:]
        best_val = total_obj(x)
        for _ in range(300):
            i = random.randrange(n)
            # perturb square i
            xi = x[4*i:4*i+4]
            old = xi[:]
            # random step
            for k in range(4):
                xi[k] += random.uniform(-0.02, 0.02)
            xi[0] = max(0.0, min(1.0, xi[0]))
            xi[1] = max(0.0, min(1.0, xi[1]))
            xi[2] = xi[2] % 1.0
            xi[3] = max(0.0, min(1.0, xi[3]))
            x[4*i:4*i+4] = xi
            new_val = total_obj(x)
            if new_val < best_val - 1e-9:
                best_val = new_val
            else:
                x[4*i:4*i+4] = old

    # unpack
    out = []
    for i in range(n):
        cx, cy, ang, s = x[4*i], x[4*i+1], x[4*i+2], x[4*i+3]
        # sanitize
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = ang % 1.0
        s = max(0.0, min(1.0, s))
        out.append((cx, cy, ang, s))
    return out

# ---------- main ----------
def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n == 0:
        return []
    # candidates
    candidates = []
    candidates.append(_grid_fill(n))
    candidates.append(_grid_rectangular(n))
    for deg in (0, 5, 10, 15, 20, 30, 45):
        candidates.append(_strips(n, deg))
    candidates.append(_hex_packing(n))

    # pick best by simple sum (minus tiny penalty for zero-size)
    best = None
    best_sum = -1.0
    for cand in candidates:
        if len(cand) < n:
            continue
        s = sum(c[3] for c in cand)
        if s > best_sum:
            best_sum = s
            best = cand

    if best is None:
        best = _grid_fill(n)

    # refine
    try:
        refined = _refine(best, n)
        # check if refined has larger sum and is valid
        rs = sum(c[3] for c in refined)
        if rs > best_sum - 1e-9:
            # quick validity check: no overlaps (allow tiny)
            valid = True
            for i in range(n):
                if _inside(refined[i]) > 1e-5:
                    valid = False
                    break
            if valid:
                for i in range(n):
                    for j in range(i + 1, n):
                        if _overlap_area_sq2(refined[i], refined[j]) > 1e-5:
                            valid = False
                            break
                    if not valid:
                        break
            if valid:
                best = refined
                best_sum = rs
    except Exception:
        pass

    # fill to n if needed
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]
