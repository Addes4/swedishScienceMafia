import math
import random
import numpy as np
from scipy.optimize import minimize


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    np.random.seed(12345 + n)

    # ---------- geometry helpers ----------
    def corners(cx, cy, ang, s):
        a = ang * 2.0 * math.pi
        c, sn = math.cos(a), math.sin(a)
        h = s * 0.5
        pts = []
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x = cx + dx * c - dy * sn
            y = cy + dx * sn + dy * c
            pts.append((x, y))
        return pts

    def axes_of(ang):
        a = ang * 2.0 * math.pi
        c, sn = math.cos(a), math.sin(a)
        return [(c, sn), (-sn, c)]

    def overlap(sq1, sq2):
        c1, y1, a1, s1 = sq1
        c2, y2, a2, s2 = sq2
        if s1 <= 1e-15 or s2 <= 1e-15:
            return False
        p1 = corners(c1, y1, a1, s1)
        p2 = corners(c2, y2, a2, s2)
        for ax in axes_of(a1) + axes_of(a2):
            proj1 = [px * ax[0] + py * ax[1] for px, py in p1]
            proj2 = [px * ax[0] + py * ax[1] for px, py in p2]
            if max(proj1) <= min(proj2) + 1e-12 or max(proj2) <= min(proj1) + 1e-12:
                return False
        return True

    def inside(cx, cy, ang, s):
        if s <= 1e-15:
            return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
        h = s * 0.5
        a = ang * 2.0 * math.pi
        c, sn = math.cos(a), math.sin(a)
        for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
            x = cx + dx * c - dy * sn
            y = cy + dx * sn + dy * c
            if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
                return False
        return True

    def total(sqs):
        return sum(s for _, _, _, s in sqs)

    def valid_all(sqs):
        m = len(sqs)
        for i in range(m):
            if not inside(*sqs[i]):
                return False
        for i in range(m):
            for j in range(i + 1, m):
                if overlap(sqs[i], sqs[j]):
                    return False
        return True

    # ---------- initial greedy packing ----------
    # Try several strategies and pick the best valid one.
    def greedy_grid(n, k):
        # k x k grid plus leftover as very small squares
        s = 1.0 / k
        out = []
        for i in range(k):
            for j in range(k):
                if len(out) < n:
                    out.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        while len(out) < n:
            out.append((0.5, 0.5, 0.0, 0.0))
        return out

    def greedy_guillotine(n):
        # Recursively split the largest square, then fill gaps
        sqs = [(0.5, 0.5, 0.0, 1.0)]
        while len(sqs) < n:
            # split largest square into 4 quarters
            idx = max(range(len(sqs)), key=lambda i: sqs[i][3])
            cx, cy, ang, s = sqs[idx]
            ns = s * 0.5
            if ns <= 1e-9:
                break
            del sqs[idx]
            for dx in (-ns, ns):
                for dy in (-ns, ns):
                    if len(sqs) < n:
                        sqs.append((cx + dx, cy + dy, 0.0, ns))
                    else:
                        sqs.append((cx + dx, cy + dy, 0.0, 0.0))
        while len(sqs) < n:
            sqs.append((0.5, 0.5, 0.0, 0.0))
        return sqs[:n]

    best = None

    for k in range(max(1, int(math.sqrt(n)) - 2), int(math.sqrt(n)) + 3):
        if k <= 0:
            continue
        cand = greedy_grid(n, k)
        if valid_all(cand):
            if best is None or total(cand) > total(best):
                best = cand

    cand = greedy_guillotine(n)
    if valid_all(cand):
        if best is None or total(cand) > total(best):
            best = cand

    if best is None:
        # fallback: all zeros
        best = [(0.5, 0.5, 0.0, 0.0)] * n

    # ---------- local improvement via random search ----------
    # Simulated annealing style: perturb centres, angles, sizes.
    def improve(sqs, steps=4000):
        cur = [list(x) for x in sqs]
        cur_tot = total(cur)

        def repair(sq_list):
            # Push overlapping squares apart a bit; clamp inside.
            m = len(sq_list)
            for _ in range(30):
                moved = False
                for i in range(m):
                    cx, cy, ang, s = sq_list[i]
                    # clamp inside
                    if s > 1e-15:
                        h = s * 0.5
                        a = ang * 2.0 * math.pi
                        c, sn = math.cos(a), math.sin(a)
                        minx = min(cx + dx * c - dy * sn for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)))
                        maxx = max(cx + dx * c - dy * sn for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)))
                        miny = min(cy + dx * sn + dy * c for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)))
                        maxy = max(cy + dx * sn + dy * c for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)))
                        if minx < 0:
                            cx += -minx
                            moved = True
                        if maxx > 1:
                            cx -= maxx - 1
                            moved = True
                        if miny < 0:
                            cy += -miny
                            moved = True
                        if maxy > 1:
                            cy -= maxy - 1
                            moved = True
                        sq_list[i] = [cx, cy, ang, s]
                for i in range(m):
                    for j in range(i + 1, m):
                        if overlap(sq_list[i], sq_list[j]):
                            cx1, cy1, a1, s1 = sq_list[i]
                            cx2, cy2, a2, s2 = sq_list[j]
                            dx = cx2 - cx1
                            dy = cy2 - cy1
                            d = math.hypot(dx, dy)
                            if d < 1e-12:
                                dx, dy = rng.uniform(-1, 1), rng.uniform(-1, 1)
                                d = math.hypot(dx, dy) + 1e-12
                            push = 0.01 * (s1 + s2)
                            move = (dx / d * push, dy / d * push)
                            sq_list[i][0] -= move[0]
                            sq_list[i][1] -= move[1]
                            sq_list[j][0] += move[0]
                            sq_list[j][1] += move[1]
                            moved = True
                if not moved:
                    break
            # shrink slightly if still overlapping
            for _ in range(10):
                bad = False
                for i in range(m):
                    for j in range(i + 1, m):
                        if overlap(sq_list[i], sq_list[j]):
                            bad = True
                            sq_list[i][3] *= 0.98
                            sq_list[j][3] *= 0.98
                if not bad:
                    break
            return sq_list

        temp = 0.02
        for step in range(steps):
            i = rng.randrange(len(cur))
            old = cur[i][:]
            # random move
            cx, cy, ang, s = old
            r = rng.random()
            if r < 0.4:
                cx += rng.gauss(0, 0.01)
                cy += rng.gauss(0, 0.01)
            elif r < 0.7:
                ang = (ang + rng.gauss(0, 0.02)) % 1.0
            else:
                s = max(0.0, min(1.0, s + rng.gauss(0, 0.005)))
            cx = min(1.0, max(0.0, cx))
            cy = min(1.0, max(0.0, cy))
            if s > 0 and not inside(cx, cy, ang, s):
                # try to clamp
                cur[i] = [cx, cy, ang, s]
                cur = repair(cur)
                cx, cy, ang, s = cur[i]

            cur[i] = [cx, cy, ang, s]
            # check validity
            ok = True
            for j in range(len(cur)):
                if j != i and overlap(cur[i], cur[j]):
                    ok = False
                    break
            if ok and inside(cur[i]):
                new_tot = total(cur)
                if new_tot >= cur_tot or rng.random() < math.exp((new_tot - cur_tot) / max(temp, 1e-12)):
                    cur_tot = new_tot
                else:
                    cur[i] = old
            else:
                cur[i] = old
            temp *= 0.9995
        return [tuple(x) for x in cur]

    best = improve(best, steps=3000 + n * 20)

    # final repair
    best = repair([list(x) for x in best])
    best_tot = total(best)

    # One more pass from guillotine if better
    if n > 4:
        cand2 = improve(greedy_guillotine(n), steps=1500 + n * 10)
        cand2 = repair([list(x) for x in cand2])
        if total(cand2) > best_tot and valid_all(cand2):
            best = cand2
            best_tot = total(best)

    # ensure correctness
    if not valid_all(best):
        best = greedy_grid(n, max(1, math.isqrt(n)))

    # convert to tuples
    return [(float(x), float(y), float(a) % 1.0, max(0.0, float(s))) for x, y, a, s in best]
