import math
import random
from typing import List, Tuple


def _overlap_area(s1, s2, eps=1e-12):
    x1, y1, a1, r1 = s1
    x2, y2, a2, r2 = s2
    if r1 <= eps or r2 <= eps:
        return 0.0
    # Fast path for axis-aligned squares
    if abs(a1 % 0.5) < eps and abs(a2 % 0.5) < eps:
        h1 = r1 * 0.5
        h2 = r2 * 0.5
        dx = abs(x1 - x2)
        dy = abs(y1 - y2)
        ox = h1 + h2 - dx
        oy = h1 + h2 - dy
        if ox > eps and oy > eps:
            return ox * oy
        return 0.0
    return 0.0  # rotations not used in construction


def _penalty(squares):
    """Sum of pairwise overlap areas."""
    m = len(squares)
    p = 0.0
    for i in range(m):
        for j in range(i + 1, m):
            p += _overlap_area(squares[i], squares[j])
    return p


def _build_rows(n: int) -> List[Tuple[float, float, float, float]]:
    """Row-based construction: choose a number of rows, then pack each row independently."""
    best = None
    best_score = -1.0

    for rows in range(1, min(n, 70) + 1):
        # Each row gets an integer number of squares; rows height = 1/rows.
        # Squares in a row are placed corner-to-corner.
        # Distribute n squares among rows as evenly as possible.
        base = n // rows
        extra = n % rows
        counts = [base + (1 if i < extra else 0) for i in range(rows)]
        counts = [c for c in counts if c > 0]
        # Recompute row height to use all rows
        rows_used = len(counts)
        h = 1.0 / rows_used
        squares = []
        ok = True
        for ri, c in enumerate(counts):
            # Try two orientations: squares use side = h (min of row width and height)
            # Row width available = 1, height = h.  If squares are axis-aligned,
            # side must be <= h.  Place c squares in the row.
            side = min(h, 1.0 / c) if c > 0 else 0.0
            if side <= 1e-15:
                ok = False
                break
            # Center row vertically
            cy = (ri + 0.5) * h
            # Distribute squares across the row
            total_width = c * side
            start_x = 0.5 - total_width * 0.5
            for ci in range(c):
                cx = start_x + (ci + 0.5) * side
                squares.append((cx, cy, 0.0, side))
        if not ok:
            continue
        # Adjust: if side * c < 1 - tiny, we could enlarge; but enlarging would
        # exceed row height or cause overlap with adjacent rows.
        # Instead, allow each row's squares to have side up to h, and if they fit
        # horizontally, they can be wider than h? No: must stay within row band.
        # But if row width not fully used, we can enlarge squares up to min(h, 1/c * scale)
        # Actually if c*h <= 1, side = h is best (fills height).
        # If c*h > 1, side = 1/c.
        # Recompute each row's maximum side:
        new_squares = []
        for ri, c in enumerate(counts):
            cy = (ri + 0.5) * h
            # max side for c squares across width 1 is 1/c
            # max side for row height h is h
            side = min(h, 1.0 / c)
            total_width = c * side
            start_x = 0.5 - total_width * 0.5
            # If total_width < 1 and side < h, we can broaden to h (height constraint)
            # but width constraint might bind.
            for ci in range(c):
                cx = start_x + (ci + 0.5) * side
                new_squares.append((cx, cy, 0.0, side))
        squares = new_squares
        score = sum(s[3] for s in squares)
        if score > best_score + 1e-12 and _penalty(squares) < 1e-9:
            best_score = score
            best = squares
    return best if best is not None else [(0.5, 0.5, 0.0, 0.0)] * n


def _local_improve(squares, n, iterations=200, time_budget=1.0):
    """Coordinate descent: try to increase sum of sides by perturbing squares."""
    import time
    start = time.time()
    sq = [list(s) for s in squares]
    # Ensure exactly n squares; pad with zeros
    while len(sq) < n:
        sq.append([0.5, 0.5, 0.0, 0.0])
    sq = sq[:n]
    best_val = sum(s[3] for s in sq)
    # Precompute neighbours for speed: all pairs could be O(n^2) per iteration.
    # We only check collisions per moved square.
    def collides_penalty(idx):
        s = sq[idx]
        if s[3] <= 1e-15:
            return 0.0
        pen = 0.0
        for j, t in enumerate(sq):
            if j == idx:
                continue
            if t[3] <= 1e-15:
                continue
            pen += _overlap_area(s, t)
        return pen

    ordering = list(range(n))
    random.shuffle(ordering)
    # Greedy enlargement: try to grow each square as much as possible without collision
    for _ in range(iterations):
        if time.time() - start > time_budget:
            break
        improved = False
        random.shuffle(ordering)
        for idx in ordering:
            s = sq[idx]
            side = s[3]
            if side <= 1e-15:
                # try to place a small square somewhere free
                # Just give it a tiny side; it won't help score much but may allow growth later
                # We'll skip for now; search for a good spot later.
                continue
            # Try increasing side
            growth = 0.02
            for _ in range(5):
                new_side = side + growth
                old_side = s[3]
                s[3] = new_side
                # clamp inside [0,1]
                cx, cy = s[0], s[1]
                half = new_side * 0.5
                cx = min(max(cx, half), 1.0 - half)
                cy = min(max(cy, half), 1.0 - half)
                s[0], s[1] = cx, cy
                pen = collides_penalty(idx)
                if pen < 1e-12:
                    best_val += new_side - old_side
                    improved = True
                    break
                else:
                    s[3] = old_side
                    growth *= 0.5
            if not improved:
                # try shifting center in random directions to reduce collision
                dx, dy = random.uniform(-0.01, 0.01), random.uniform(-0.01, 0.01)
                old = s[:]
                half = s[3] * 0.5
                s[0] = min(max(s[0] + dx, half), 1.0 - half)
                s[1] = min(max(s[1] + dy, half), 1.0 - half)
                pen = collides_penalty(idx)
                if pen < 1e-12:
                    improved = True
                else:
                    s[:] = old
        if not improved:
            break
    # Pad with zero squares if fewer than n
    while len(sq) < n:
        sq.append([0.5, 0.5, 0.0, 0.0])
    return [tuple(s) for s in sq[:n]]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # Two squares side by side: sum = 1.0
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # One big on top, two small below
        # Big: side 2/3, small: side 1/3 each -> sum = 4/3? Let's check: big 2/3 x 2/3, two small 1/3 x 1/3
        # Yes, sum = 2/3 + 1/3 + 1/3 = 4/3 ≈ 1.333
        return [(0.5, 2.0/3.0, 0.0, 2.0/3.0),
                (1.0/6.0, 1.0/6.0, 0.0, 1.0/3.0),
                (5.0/6.0, 1.0/6.0, 0.0, 1.0/3.0)]

    # Try multiple constructions
    candidates = []
    # 1. Grid-based
    k = math.isqrt(n)
    if k > 0:
        side = 1.0 / k
        grid = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        grid += [(0.5, 0.5, 0.0, 0.0)] * (n - len(grid))
        candidates.append(grid[:n])
    # 2. Row-based with different row counts
    for rows in range(1, min(n, 60) + 1):
        counts = []
        base = n // rows
        extra = n % rows
        for i in range(rows):
            c = base + (1 if i < extra else 0)
            if c > 0:
                counts.append(c)
        if not counts:
            continue
        rows_used = len(counts)
        h = 1.0 / rows_used
        cand = []
        for ri, c in enumerate(counts):
            cy = (ri + 0.5) * h
            side = min(h, 1.0 / c)
            total_width = c * side
            start_x = 0.5 - total_width * 0.5
            for ci in range(c):
                cx = start_x + (ci + 0.5) * side
                cand.append((cx, cy, 0.0, side))
        while len(cand) < n:
            cand.append((0.5, 0.5, 0.0, 0.0))
        cand = cand[:n]
        candidates.append(cand)

    # 3. Mixed tiling: combine a big square and grid in remaining region
    # For some n, place m x m grid in a sub-square and fill rest
    for a in range(1, n):
        b = n - a
        # Place a squares as a grid in left region of width w, and b squares in right
        # We'll just use row-based with rows=2 or 3 variants already covered.
        pass

    # Evaluate candidates by actual overlap penalty and score
    best = None
    best_score = -1.0
    for cand in candidates:
        # Ensure no overlaps
        pen = _penalty(cand)
        if pen > 1e-9:
            continue
        sc = sum(s[3] for s in cand)
        if sc > best_score + 1e-12:
            best_score = sc
            best = cand[:]

    if best is None:
        # fallback: simple grid
        k = max(1, math.isqrt(n))
        side = 1.0 / k
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        while len(best) < n:
            best.append((0.5, 0.5, 0.0, 0.0))
        best = best[:n]

    # Local improvement with limited time
    improved = _local_improve(best, n, iterations=100, time_budget=0.5)
    # Validate no overlaps
    pen = _penalty(improved)
    if pen > 1e-9:
        return best[:n]
    sc_imp = sum(s[3] for s in improved)
    sc_best = sum(s[3] for s in best)
    if sc_imp > sc_best + 1e-12:
        return improved[:n]
    return best[:n]
