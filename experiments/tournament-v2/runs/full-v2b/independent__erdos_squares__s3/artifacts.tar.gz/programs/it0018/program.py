import math
import random
import numpy as np

# ---------- geometry ----------
def corners(cx, cy, ang, s):
    """Return 4 corners of square (cx,cy,ang,s), ang in turns."""
    th = 2.0 * math.pi * ang
    c, si = math.cos(th), math.sin(th)
    h = s * 0.5
    # local corners (-h,-h),(h,-h),(h,h),(-h,h)
    return [
        (cx + c * (-h) - si * (-h), cy + si * (-h) + c * (-h)),
        (cx + c * ( h) - si * (-h), cy + si * ( h) + c * (-h)),
        (cx + c * ( h) - si * ( h), cy + si * ( h) + c * ( h)),
        (cx + c * (-h) - si * ( h), cy + si * (-h) + c * ( h)),
    ]

def poly_axes(pts):
    return [(pts[1][0]-pts[0][0], pts[1][1]-pts[0][1]),
            (pts[3][0]-pts[0][0], pts[3][1]-pts[0][1])]

def overlap_poly(pts1, pts2):
    """SAT overlap test for convex polygons; touching is allowed."""
    for pts in (pts1, pts2):
        for ax, ay in poly_axes(pts):
            n = math.hypot(ax, ay)
            if n < 1e-15:
                continue
            ax, ay = ax / n, ay / n
            p1 = [ax*x + ay*y for x, y in pts1]
            p2 = [ax*x + ay*y for x, y in pts2]
            if min(p1) > max(p2) + 1e-12 or min(p2) > max(p1) + 1e-12:
                return False
    return True

def inside_unit(pts):
    e = 1e-11
    for x, y in pts:
        if x < -e or x > 1.0 + e or y < -e or y > 1.0 + e:
            return False
    return True

def valid_square(cx, cy, ang, s):
    if s < 0:
        return False
    pts = corners(cx, cy, ang, s)
    return inside_unit(pts)

# precompute corner cache for speed
def all_corners(sqs):
    return [corners(*q) for q in sqs]

def total_side(sqs):
    return sum(q[3] for q in sqs)

def is_valid_all(sqs):
    ol = all_corners(sqs)
    n = len(sqs)
    for i in range(n):
        if not inside_unit(ol[i]):
            return False
        for j in range(i+1, n):
            if overlap_poly(ol[i], ol[j]):
                return False
    return True

def valid_with_new(sqs, newq, ol=None):
    if ol is None:
        ol = all_corners(sqs)
    npts = corners(*newq)
    if not inside_unit(npts):
        return False
    for pts in ol:
        if overlap_poly(pts, npts):
            return False
    return True

# ---------- initialization ----------
def grid_init(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0) for _ in range(n)]
    side = 1.0 / k
    sqs = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    sqs += [(0.5, 0.5, 0.0, 0.0)] * (n - len(sqs))
    return sqs[:n]

def random_init(n):
    sqs = []
    for _ in range(n):
        sqs.append((random.random(), random.random(), random.random(), 0.0))
    # grow greedily
    return repair_grow(sqs)

def repair_grow(sqs):
    """Given squares (maybe zero-size), try to enlarge each and place allowed."""
    # first, remove overlap by shrinking
    result = []
    for q in sqs:
        cx, cy, ang, s = q
        s = max(0.0, min(1.0, s))
        # shrink until no overlap with already placed
        lo, hi = 0.0, s
        best = 0.0
        for _ in range(40):
            mid = (lo + hi) / 2
            if valid_with_new(result, (cx, cy, ang, mid)):
                best = mid
                lo = mid
            else:
                hi = mid
        result.append((cx, cy, ang, best))
    return result

# ---------- local search ----------
def perturb(sqs, strength=0.05):
    n = len(sqs)
    new = list(sqs)
    # pick a few random squares and move/resize/rotate
    idxs = list(range(n))
    random.shuffle(idxs)
    k = max(1, int(math.sqrt(n)))
    for i in idxs[:k]:
        cx, cy, ang, s = new[i]
        if random.random() < 0.5:
            cx = min(1.0, max(0.0, cx + random.gauss(0, strength)))
            cy = min(1.0, max(0.0, cy + random.gauss(0, strength)))
        if random.random() < 0.3:
            ang = (ang + random.gauss(0, strength * 2)) % 1.0
        if random.random() < 0.6:
            s = max(0.0, s * (1.0 + random.gauss(0, strength * 2)))
        new[i] = (cx, cy, ang, s)
    return new

def repair(sqs, max_iter=30):
    """Make valid by shrinking overlapping squares, then try to grow."""
    # shrink all to fit inside
    res = []
    for q in sqs:
        cx, cy, ang, s = q
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        # shrink to be inside unit square
        lo, hi = 0.0, s
        for _ in range(30):
            mid = (lo + hi) / 2
            if valid_square(cx, cy, ang, mid):
                lo = mid
            else:
                hi = mid
        res.append((cx, cy, ang, lo))
    # resolve overlaps by shrinking one of each pair
    changed = True
    it = 0
    while changed and it < 60:
        changed = False
        it += 1
        ol = all_corners(res)
        for i in range(len(res)):
            for j in range(i+1, len(res)):
                if overlap_poly(ol[i], ol[j]):
                    # shrink the larger one (or both slightly)
                    si, sj = res[i][3], res[j][3]
                    if si >= sj:
                        t = i
                    else:
                        t = j
                    cx, cy, ang, s = res[t]
                    lo, hi = 0.0, s
                    for _ in range(30):
                        mid = (lo + hi) / 2
                        tmp = list(res)
                        tmp[t] = (cx, cy, ang, mid)
                        if is_valid_all(tmp):
                            lo = mid
                        else:
                            hi = mid
                    res[t] = (cx, cy, ang, lo)
                    changed = True
                    ol = all_corners(res)
    # grow greedily
    res = grow_all(res)
    return res

def grow_all(sqs):
    """Try to enlarge each square as much as possible while keeping validity."""
    res = list(sqs)
    for i in range(len(res)):
        cx, cy, ang, s = res[i]
        # binary search max side
        lo, hi = s, 3.0
        # first check if can just set to 3.0 (unlikely)
        best = s
        for _ in range(50):
            mid = (lo + hi) / 2
            tmp = list(res)
            tmp[i] = (cx, cy, ang, mid)
            if is_valid_all(tmp):
                best = mid
                lo = mid
            else:
                hi = mid
        res[i] = (cx, cy, ang, best)
    return res

def local_search(n, init_sqs, time_budget=50.0):
    import time
    start = time.time()
    best = repair(init_sqs)
    best_score = total_side(best)
    cur = best
    cur_score = best_score
    T = 0.05
    iteration = 0
    while time.time() - start < time_budget:
        iteration += 1
        # adaptive strength
        strength = 0.02 + 0.1 * (0.5 + 0.5 * math.sin(iteration * 0.01))
        cand = perturb(cur, strength)
        cand = repair(cand)
        cand_score = total_side(cand)
        if cand_score > cur_score or random.random() < math.exp((cand_score - cur_score) / max(T, 1e-6)):
            cur = cand
            cur_score = cand_score
            if cur_score > best_score:
                best = cur
                best_score = cur_score
        # lower temperature
        T *= 0.9997
        if T < 1e-4:
            T = 0.02
        # occasionally restart from best
        if iteration % 200 == 0:
            cur = best
            cur_score = best_score
    return best

def refine_continuous(sqs, iterations=5):
    """Coordinate-wise line search on positions and sizes."""
    res = list(sqs)
    n = len(res)
    for _ in range(iterations):
        improved = False
        for i in range(n):
            cx, cy, ang, s = res[i]
            # try small moves
            for dcx, dcy, dang, ds in [
                (0.01, 0, 0, 0), (-0.01, 0, 0, 0),
                (0, 0.01, 0, 0), (0, -0.01, 0, 0),
                (0, 0, 0.02, 0), (0, 0, -0.02, 0),
                (0, 0, 0, 0.01), (0, 0, 0, -0.01)
            ]:
                tmp = list(res)
                ncx = min(1.0, max(0.0, cx + dcx))
                ncy = min(1.0, max(0.0, cy + dcy))
                nang = (ang + dang) % 1.0
                ns = max(0.0, s + ds)
                tmp[i] = (ncx, ncy, nang, ns)
                if is_valid_all(tmp):
                    if total_side(tmp) > total_side(res) + 1e-12:
                        res = tmp
                        cx, cy, ang, s = ncx, ncy, nang, ns
                        improved = True
        if not improved:
            break
    return res

# ---------- special known packings ----------
def special_cases(n):
    """Return better initial guess for specific small n."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side 0.5 each
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # two at bottom, one on top? Actually 3 squares of 1/2 side not fit.
        # use side 0.5, 0.5, 0.5 in L shape? Actually best is 2 large + 1 small.
        # place two 0.5 side, one rotated 45 deg in remaining corner
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.5, 0.75, 0.0, 0.5)]  # this overlaps, will be repaired
    if n == 4:
        side = 0.5
        return [(0.25, 0.25, 0.0, side), (0.75, 0.25, 0.0, side),
                (0.25, 0.75, 0.0, side), (0.75, 0.75, 0.0, side)]
    if n == 5:
        # 4 grid + 1 in center? Not enough space. Use 4 corners + center rotated.
        side = 0.4
        return [(0.2, 0.2, 0.0, side), (0.8, 0.2, 0.0, side),
                (0.2, 0.8, 0.0, side), (0.8, 0.8, 0.0, side),
                (0.5, 0.5, 0.25, 0.2)]
    return None

# ---------- main solve ----------
def solve(n):
    random.seed(12345 + n)
    np.random.seed(12345 + n)

    if n == 0:
        return []

    sp = special_cases(n)
    if sp is not None:
        sp = repair(sp)
        return sp

    # start from grid
    init = grid_init(n)
    init = repair(init)

    # run local search
    best = local_search(n, init, time_budget=50.0)
    best = refine_continuous(best, iterations=3)
    best = grow_all(best)
    best = refine_continuous(best, iterations=2)
    best = grow_all(best)

    # ensure exactly n
    best = best[:n]
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best
