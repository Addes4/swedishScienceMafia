import math
import random
import time

SQRT2 = math.sqrt(2.0)

def solve(n):
    if n <= 0:
        return []

    best = None
    best_score = -1.0
    rng = random.Random(1234567 + n)

    # Time budget is generous; keep several attempts.
    deadline = time.time() + 55.0

    attempts = 0
    while time.time() < deadline:
        attempts += 1
        cur = initial_layout(n, rng, attempts)
        cur, score = optimize(cur, n, deadline, rng)
        if score > best_score:
            best_score = score
            best = cur
            if attempts >= 3 and time.time() > deadline - 10.0:
                break

    if best is None:
        best = initial_layout(n, rng, 0)

    best = final_repair(best, n)
    return [(float(x), float(y), float(a), float(s)) for (x, y, a, s) in best]


def initial_layout(n, rng, attempt):
    """Produce a starting list of squares."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # row / column counts near sqrt(n), often slightly unbalanced helps.
    k = int(math.isqrt(n))
    while k > 1 and k * k > n:
        k -= 1
    if k < 1:
        k = 1

    # Try a few grid shapes.
    choices = []
    for rows in range(max(1, k - 2), k + 3):
        cols = (n + rows - 1) // rows
        if cols < 1:
            continue
        if rows * cols >= n:
            choices.append((rows, cols))
    if not choices:
        rows = max(1, int(round(math.sqrt(n))))
        cols = (n + rows - 1) // rows
        choices = [(rows, cols)]

    rows, cols = choices[(attempt - 1) % len(choices)] if attempt > 0 else choices[0]

    # Base square size with a little random shrink.
    side = min(1.0 / cols, 1.0 / rows)
    if attempt > 0:
        side *= rng.uniform(0.95, 1.0)

    squares = []
    idx = 0
    for r in range(rows):
        for c in range(cols):
            if idx >= n:
                break
            x = (c + 0.5) / cols
            y = (r + 0.5) / rows
            ang = 0.0
            if attempt > 1 and rng.random() < 0.08:
                ang = rng.uniform(0.0, 0.25)
            squares.append([x, y, ang, side])
            idx += 1
        if idx >= n:
            break

    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return squares[:n]


def half_extent(side, ang):
    """Axis-aligned half-extent of a rotated square."""
    c = abs(math.cos(2.0 * math.pi * ang))
    s = abs(math.sin(2.0 * math.pi * ang))
    h = 0.5 * side * (c + s)
    return h, h


def overlap(sq1, sq2):
    """Return True if interiors of two squares overlap."""
    x1, y1, a1, s1 = sq1
    x2, y2, a2, s2 = sq2
    if s1 <= 0.0 or s2 <= 0.0:
        return False

    # Cheap AABB rejection.
    h1 = half_extent(s1, a1)[0]
    h2 = half_extent(s2, a2)[0]
    dx = x1 - x2
    if dx < 0:
        dx = -dx
    if dx >= h1 + h2:
        return False
    dy = y1 - y2
    if dy < 0:
        dy = -dy
    if dy >= h1 + h2:
        return False

    # Separating axis theorem for two squares.
    t1 = 2.0 * math.pi * a1
    t2 = 2.0 * math.pi * a2
    c1 = math.cos(t1); s1v = math.sin(t1)
    c2 = math.cos(t2); s2v = math.sin(t2)

    axes = [
        (c1, s1v), (-s1v, c1),
        (c2, s2v), (-s2v, c2),
    ]

    half1 = 0.5 * s1
    half2 = 0.5 * s2

    for ax, ay in axes:
        # projection radius of square 1
        r1 = half1 * (abs(c1 * ax + s1v * ay) + abs(-s1v * ax + c1 * ay))
        r2 = half2 * (abs(c2 * ax + s2v * ay) + abs(-s2v * ax + c2 * ay))
        d = abs(dx * ax + dy * ay)
        if d >= r1 + r2:
            return False
    return True


def valid_layout(sqs, n):
    for i in range(n):
        if sqs[i][3] <= 0.0:
            continue
        x, y, a, s = sqs[i]
        # inside unit square? (for safety)
        h = half_extent(s, a)[0]
        if x - h < -1e-9 or x + h > 1.0 + 1e-9 or y - h < -1e-9 or y + h > 1.0 + 1e-9:
            return False
        for j in range(i + 1, n):
            if sqs[j][3] <= 0.0:
                continue
            if overlap(sqs[i], sqs[j]):
                return False
    return True


def score_of(sqs, n):
    return sum(sqs[i][3] for i in range(n))


def clamp_center(sq):
    x, y, a, s = sq
    h = half_extent(s, a)[0]
    if h < 1e-12:
        sq[0] = min(1.0, max(0.0, x))
        sq[1] = min(1.0, max(0.0, y))
        return
    lo = h
    hi = 1.0 - h
    if lo > hi:
        sq[0] = 0.5
    else:
        sq[0] = min(hi, max(lo, x))
    if lo > hi:
        sq[1] = 0.5
    else:
        sq[1] = min(hi, max(lo, y))
    if sq[3] < 0.0:
        sq[3] = 0.0


def optimize(sqs, n, deadline, rng):
    """Simulated-annealing-style local search on square parameters."""
    sqs = [list(s) for s in sqs]
    for s in sqs:
        s[3] = max(0.0, min(1.0, s[3]))
        s[2] %= 1.0
        clamp_center(s)

    # Drop initial overlaps by shrinking offending squares.
    for _ in range(6 * max(1, n)):
        bad = False
        for i in range(n):
            if sqs[i][3] <= 0.0:
                continue
            for j in range(i + 1, n):
                if sqs[j][3] <= 0.0:
                    continue
                if overlap(sqs[i], sqs[j]):
                    # shrink smaller one
                    if sqs[i][3] <= sqs[j][3]:
                        sqs[i][3] *= 0.9
                    else:
                        sqs[j][3] *= 0.9
                    bad = True
            if bad and time.time() > deadline:
                return sqs, score_of(sqs, n)
        if not bad:
            break

    best = [s[:] for s in sqs]
    best_score = score_of(best, n)
    cur = [s[:] for s in sqs]
    cur_score = best_score

    temp0 = 0.08
    it = 0
    while time.time() < deadline:
        it += 1
        frac = (it % 4000) / 4000.0
        temp = temp0 * (1.0 - 0.8 * frac)

        # choose one square to perturb
        i = rng.randrange(n)
        old = cur[i][:]
        sq = cur[i]

        choice = rng.random()
        if choice < 0.40:
            # change size
            sq[3] *= rng.uniform(0.97, 1.03)
            if sq[3] > 1.0:
                sq[3] = 1.0
        elif choice < 0.75:
            # move centre
            step = 0.03 * (1.0 - 0.5 * frac)
            sq[0] += rng.gauss(0.0, step)
            sq[1] += rng.gauss(0.0, step)
        else:
            # rotate
            sq[2] += rng.gauss(0.0, 0.05)
            sq[2] %= 1.0

        clamp_center(sq)

        # ensure no overlap with others, else reject/shrink
        ok = True
        for j in range(n):
            if j == i or cur[j][3] <= 0.0:
                continue
            if overlap(cur[i], cur[j]):
                ok = False
                break

        if ok:
            new_score = cur_score - old[3] + sq[3]
            delta = new_score - cur_score
            if delta >= 0.0 or rng.random() < math.exp(delta / max(temp, 1e-9)):
                cur_score = new_score
                if cur_score > best_score:
                    best_score = cur_score
                    best = [s[:] for s in cur]
            else:
                cur[i] = old
                clamp_center(cur[i])
        else:
            # Try shrinking to become valid.
            trial = sq[:]
            for _ in range(25):
                trial[3] *= 0.92
                clamp_center(trial)
                badj = False
                for j in range(n):
                    if j == i or cur[j][3] <= 0.0:
                        continue
                    if overlap(trial, cur[j]):
                        badj = True
                        break
                if not badj:
                    break
            if not badj:
                cur[i] = trial
                cur_score = score_of(cur, n)
                if cur_score > best_score:
                    best_score = cur_score
                    best = [s[:] for s in cur]
            else:
                cur[i] = old
                clamp_center(cur[i])

        # Occasionally try growing all squares a tiny bit.
        if it % 500 == 0:
            grow_all(cur, n, rng)
            sc = score_of(cur, n)
            if sc > best_score:
                best_score = sc
                best = [s[:] for s in cur]
            cur_score = sc

    return best, best_score


def grow_all(sqs, n, rng):
    """Attempt to scale up all squares around their centres slightly."""
    factor = 1.004
    for i in range(n):
        if sqs[i][3] <= 0.0:
            continue
        old = sqs[i][:]
        sqs[i][3] *= factor
        clamp_center(sqs[i])
        bad = False
        for j in range(n):
            if i == j or sqs[j][3] <= 0.0:
                continue
            if overlap(sqs[i], sqs[j]):
                bad = True
                break
        if bad:
            sqs[i] = old


def final_repair(sqs, n):
    """Guarantee validity and return safely inside bounds."""
    res = [list(s) for s in sqs[:n]]
    while len(res) < n:
        res.append([0.5, 0.5, 0.0, 0.0])

    for s in res:
        s[2] %= 1.0
        s[3] = max(0.0, min(1.0, s[3]))
        clamp_center(s)

    # Repeatedly remove overlaps by shrinking the smaller square.
    for _ in range(2000):
        changed = False
        for i in range(n):
            if res[i][3] <= 0.0:
                continue
            for j in range(i + 1, n):
                if res[j][3] <= 0.0:
                    continue
                if overlap(res[i], res[j]):
                    if res[i][3] <= res[j][3]:
                        res[i][3] *= 0.95
                    else:
                        res[j][3] *= 0.95
                    clamp_center(res[i])
                    clamp_center(res[j])
                    changed = True
        if not changed:
            break

    # Final clipping safeguard.
    for s in res:
        s[2] %= 1.0
        s[3] = max(0.0, min(1.0, s[3]))
        clamp_center(s)
        if s[3] <= 1e-12:
            s[3] = 0.0
            s[0] = 0.5
            s[1] = 0.5
            s[2] = 0.0

    return res
