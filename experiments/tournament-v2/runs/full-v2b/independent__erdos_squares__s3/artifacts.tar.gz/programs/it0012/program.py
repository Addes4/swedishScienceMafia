import math
import random
import time

# We only need math, random, time. No numpy/scipy needed.

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        # One square can fill the whole unit square
        return [(0.5, 0.5, 0.0, 1.0)]

    # Time budget (seconds). Keep well under 60s total.
    start_time = time.time()
    TIME_LIMIT = 55.0

    # Helper: check non-overlap of two squares given centers, angles, sides.
    # Squares may be rotated. Use separating axis theorem (SAT).
    # A square with center c, angle a (fraction of turn), side s:
    # local axes: u=(cos(2*pi*a), sin(2*pi*a)), v=(-sin, cos)
    # vertices: c +/- (s/2)u +/- (s/2)v
    # For SAT between two convex polygons, test axes = edge normals of both.
    # Since both are squares, test 4 axes: u1, v1, u2, v2.
    # Project each square onto each axis and check interval overlap.
    # If any axis has no overlap -> separated -> no interior intersection.

    def square_axes(cx, cy, ang):
        t = 2.0 * math.pi * ang
        ca, sa = math.cos(t), math.sin(t)
        # edge directions (normalized)
        ux, uy = ca, sa
        vx, vy = -sa, ca
        return (ux, uy), (vx, vy)

    def project_square(cx, cy, ang, side, ax, ay):
        # project square onto axis (ax, ay). Returns (min, max)
        (ux, uy), (vx, vy) = square_axes(cx, cy, ang)
        hs = side * 0.5
        # vertices offsets from center: +/- hs*u +/- hs*v
        # projection of u onto axis = ux*ax + uy*ay, etc.
        pu = ux * ax + uy * ay
        pv = vx * ax + vy * ay
        # extreme projections: +/- hs*|pu| +/- hs*|pv|
        ext = hs * (abs(pu) + abs(pv))
        c = cx * ax + cy * ay
        return (c - ext, c + ext)

    def overlap_interior(s1, s2):
        # returns True if interiors overlap (positive area intersection)
        cx1, cy1, a1, s1_ = s1
        cx2, cy2, a2, s2_ = s2
        if s1_ <= 0.0 or s2_ <= 0.0:
            return False
        # Quick bounding circle check
        r1 = s1_ * 0.5 * math.sqrt(2.0)
        r2 = s2_ * 0.5 * math.sqrt(2.0)
        dx = cx1 - cx2
        dy = cy1 - cy2
        if dx*dx + dy*dy >= (r1 + r2)**2:
            return False
        # SAT: test 4 axes
        axes = []
        (ux1, uy1), (vx1, vy1) = square_axes(cx1, cy1, a1)
        (ux2, uy2), (vx2, vy2) = square_axes(cx2, cy2, a2)
        axes.append((ux1, uy1))
        axes.append((vx1, vy1))
        axes.append((ux2, uy2))
        axes.append((vx2, vy2))
        for ax, ay in axes:
            lo1, hi1 = project_square(cx1, cy1, a1, s1_, ax, ay)
            lo2, hi2 = project_square(cx2, cy2, a2, s2_, ax, ay)
            # Check for separation with a tiny epsilon
            if hi1 <= lo2 + 1e-12 or hi2 <= lo1 + 1e-12:
                return False
        return True

    def feasible(squares):
        # Check all pairs for interior overlap and bounds (centers inside [0,1]? Actually squares must be inside unit square)
        # Squares must be entirely inside [0,1]x[0,1]. So we need to check that all vertices are in bounds.
        m = len(squares)
        # bounds check per square
        for i in range(m):
            cx, cy, ang, side = squares[i]
            if side <= 0.0:
                # A point is allowed if center inside [0,1] (but we can place at boundary). Let's ensure center in [0,1].
                if not (0.0 - 1e-12 <= cx <= 1.0 + 1e-12 and 0.0 - 1e-12 <= cy <= 1.0 + 1e-12):
                    return False
                continue
            (ux, uy), (vx, vy) = square_axes(cx, cy, ang)
            hs = side * 0.5
            # vertices
            for sx in (-1.0, 1.0):
                for sy in (-1.0, 1.0):
                    x = cx + sx * hs * ux + sy * hs * vx
                    y = cy + sx * hs * uy + sy * hs * vy
                    if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
                        return False
        # overlap check
        for i in range(m):
            for j in range(i+1, m):
                if overlap_interior(squares[i], squares[j]):
                    return False
        return True

    def score(squares):
        return sum(s[3] for s in squares)

    # --- Initial construction ---
    # Try several structured packings and pick the best feasible.

    def grid_packing(n):
        # largest k x k grid, remaining as tiny squares in leftover row/col
        k = int(math.floor(math.sqrt(n)))
        # If k^2 < n, we can try to put extra squares in the remaining strip.
        # Simple approach: k x k full grid, then place remaining in a row or column.
        # But better: use a grid of k columns and rows, and leftover space.
        # We'll use a more flexible approach: place squares in a grid with k columns,
        # each column has some rows, all equal size? Actually we can vary.
        # Let's just do k x k grid and put rest as zero-size? No, let's try to make
        # a better packing with k columns and distribute n squares.
        # We'll try all ways to factor n into rows and columns.
        best = None
        best_val = -1
        for cols in range(1, n+1):
            rows = (n + cols - 1) // cols
            if rows * cols < n:
                continue
            # If we use cols columns and rows rows, each cell size = min(1/cols, 1/rows) if we want squares.
            # Actually we can fit squares of side s if cols*s <= 1 and rows*s <= 1 => s = min(1/cols, 1/rows).
            # But we may not need all rows full.
            # Use cols columns, each column may have different number of squares.
            # Let's just do full grid with cols x rows and remove extra? No, we need exactly n.
            # Simple: choose s = min(1/cols, 1/rows), place n squares in first n cells.
            # Number of cells = cols*rows >= n.
            s = min(1.0 / cols, 1.0 / rows)
            # place n squares in row-major order
            squares = []
            for idx in range(n):
                r = idx // cols
                c = idx % cols
                cx = (c + 0.5) * s
                cy = (r + 0.5) * s
                # Only if inside
                if cx + s*0.5 <= 1.0 + 1e-12 and cy + s*0.5 <= 1.0 + 1e-12:
                    squares.append((cx, cy, 0.0, s))
                else:
                    # fallback: place at center with zero size
                    squares.append((0.5, 0.5, 0.0, 0.0))
            if len(squares) < n:
                squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
            squares = squares[:n]
            if feasible(squares):
                val = score(squares)
                if val > best_val:
                    best_val = val
                    best = squares[:]
        return best

    # Also try packing with rotated squares in a strip? 
    # We'll rely on local search to improve.

    best_solution = grid_packing(n)
    if best_solution is None:
        # fallback: all zero
        best_solution = [(0.5, 0.5, 0.0, 0.0) for _ in range(n)]

    # Additional heuristic: try to fill leftover space with a rotated square in corners?
    # We'll let local search handle it.

    # --- Local search ---
    # We'll use a simple stochastic hill climbing with restarts.
    # Operations: change angle, size, position of one square (or multiple).
    # We must maintain feasibility.

    # To speed up, we can use a penalty-based approach: allow slight overlaps and penalize,
    # then project back. But simple feasibility check is okay for small n.

    # For larger n, feasibility check O(n^2) per step could be slow. We'll do incremental checks.

    def try_move(squares, idx, new_cx, new_cy, new_ang, new_side):
        # returns new squares if feasible, else None
        old = squares[idx]
        squares[idx] = (new_cx, new_cy, new_ang, new_side)
        # check bounds for this square
        cx, cy, ang, side = squares[idx]
        ok = True
        if side > 0:
            (ux, uy), (vx, vy) = square_axes(cx, cy, ang)
            hs = side * 0.5
            for sx in (-1.0, 1.0):
                for sy in (-1.0, 1.0):
                    x = cx + sx * hs * ux + sy * hs * vx
                    y = cy + sx * hs * uy + sy * hs * vy
                    if x < -1e-9 or x > 1.0 + 1e-9 or y < -1e-9 or y > 1.0 + 1e-9:
                        ok = False
                        break
                if not ok:
                    break
        else:
            if not (0.0 - 1e-12 <= cx <= 1.0 + 1e-12 and 0.0 - 1e-12 <= cy <= 1.0 + 1e-12):
                ok = False
        if ok:
            # check overlap with all others
            for j in range(len(squares)):
                if j == idx:
                    continue
                if overlap_interior(squares[idx], squares[j]):
                    ok = False
                    break
        if ok:
            return squares
        else:
            squares[idx] = old
            return None

    # Local search loop
    current = [list(s) for s in best_solution]
    current_score = score(current)
    best = [list(s) for s in current]
    best_score = current_score

    random.seed(12345)

    iteration = 0
    while time.time() - start_time < TIME_LIMIT - 2.0:  # leave margin
        iteration += 1
        # choose a random square index (maybe biased towards larger sides)
        if n == 0:
            break
        # pick index with probability proportional to (side + 0.1)^2? Let's just pick random.
        idx = random.randrange(n)
        cx, cy, ang, side = current[idx]

        # Propose a move
        move_type = random.random()
        # Sometimes try to increase size (greedy)
        if move_type < 0.4:
            # increase size
            new_side = side + random.uniform(0.0, 0.05) * (1.0 - side)
            if new_side > 1.0:
                new_side = 1.0
            # try same center
            res = try_move(current, idx, cx, cy, ang, new_side)
            if res is not None:
                current = res
                current_score = score(current)
                if current_score > best_score + 1e-12:
                    best_score = current_score
                    best = [list(s) for s in current]
                continue
        elif move_type < 0.7:
            # change angle
            new_ang = (ang + random.uniform(-0.25, 0.25)) % 1.0
            res = try_move(current, idx, cx, cy, new_ang, side)
            if res is not None:
                current = res
                current_score = score(current)
                if current_score > best_score + 1e-12:
                    best_score = current_score
                    best = [list(s) for s in current]
                continue
        elif move_type < 0.9:
            # move center
            dx = random.uniform(-0.05, 0.05)
            dy = random.uniform(-0.05, 0.05)
            new_cx = cx + dx
            new_cy = cy + dy
            if new_cx < 0.0: new_cx = 0.0
            if new_cx > 1.0: new_cx = 1.0
            if new_cy < 0.0: new_cy = 0.0
            if new_cy > 1.0: new_cy = 1.0
            res = try_move(current, idx, new_cx, new_cy, ang, side)
            if res is not None:
                current = res
                current_score = score(current)
                if current_score > best_score + 1e-12:
                    best_score = current_score
                    best = [list(s) for s in current]
                continue
        else:
            # random perturbation: change all parameters slightly
            new_cx = cx + random.uniform(-0.02, 0.02)
            new_cy = cy + random.uniform(-0.02, 0.02)
            new_ang = (ang + random.uniform(-0.1, 0.1)) % 1.0
            new_side = side * random.uniform(0.9, 1.1)
            if new_side > 1.0:
                new_side = 1.0
            new_cx = max(0.0, min(1.0, new_cx))
            new_cy = max(0.0, min(1.0, new_cy))
            res = try_move(current, idx, new_cx, new_cy, new_ang, new_side)
            if res is not None:
                current = res
                current_score = score(current)
                if current_score > best_score + 1e-12:
                    best_score = current_score
                    best = [list(s) for s in current]
                continue

        # If we failed to improve, sometimes restart from best
        if random.random() < 0.01:
            current = [list(s) for s in best]
            current_score = best_score

        # Occasionally do a global "shake": move all squares slightly? Too expensive.

        # Also try to increase size of all squares proportionally? 
        # Maybe periodically try to scale up all squares by a factor and check feasibility.
        if iteration % 500 == 0:
            factor = 1.02
            test = []
            for (x, y, a, s) in current:
                # scale about the center of the unit square (0.5, 0.5)
                nx = 0.5 + (x - 0.5) * factor
                ny = 0.5 + (y - 0.5) * factor
                ns = s * factor
                test.append((nx, ny, a, ns))
            if feasible(test):
                current = test
                current_score = score(current)
                if current_score > best_score + 1e-12:
                    best_score = current_score
                    best = [list(s) for s in current]

    # Return best as list of tuples
    return [tuple(s) for s in best]
