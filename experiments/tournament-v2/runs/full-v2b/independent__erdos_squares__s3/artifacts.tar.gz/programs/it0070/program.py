import math
import random
from typing import List, Tuple

try:
    import numpy as np
except Exception:
    np = None


Square = Tuple[float, float, float, float]


def _grid(n: int, k: int, side: float) -> List[Square]:
    out = []
    for i in range(k):
        for j in range(k):
            out.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    return out[:n]


def _row_pack(n: int) -> List[Square]:
    """Pack n equal squares in rows filling the unit square from the bottom."""
    best = None
    best_sum = -1.0
    # Try a few candidate row counts / column counts.
    candidates = set()
    for rows in range(1, min(n, 40) + 1):
        cols = (n + rows - 1) // rows
        candidates.add((rows, cols))
    for rows, cols in candidates:
        # Place cols per row, rows rows. Last row may be partial.
        s = min(1.0 / cols, 1.0 / rows)
        # If partial last row, can we enlarge the squares in full rows?
        used = 0
        full_rows = n // cols
        partial = n % cols
        total_rows = full_rows + (1 if partial else 0)
        if total_rows == 0:
            continue
        s = min(1.0 / cols, 1.0 / total_rows)
        # But full rows have `cols` squares, partial row has `partial`.
        # Height needed: full_rows * s + (s if partial else 0) = total_rows*s <= 1.
        # Width: cols*s <= 1, partial*s <= 1.
        if cols * s > 1.0 + 1e-12 or total_rows * s > 1.0 + 1e-12:
            continue
        out = []
        y = 0.0
        cnt = 0
        for r in range(total_rows):
            in_row = cols if r < full_rows else partial
            if in_row == 0:
                continue
            # Center the row horizontally
            x0 = (1.0 - in_row * s) / 2.0
            for c in range(in_row):
                out.append((x0 + (c + 0.5) * s, y + 0.5 * s, 0.0, s))
                cnt += 1
            y += s
        while len(out) < n:
            out.append((0.5, 0.5, 0.0, 0.0))
        val = sum(q[3] for q in out)
        if val > best_sum:
            best_sum = val
            best = out[:n]
    return best if best is not None else _grid(n, max(1, math.isqrt(n)), 1.0 / max(1, math.isqrt(n)))


def _two_block_pack(n: int) -> List[Square]:
    """Split n into two groups: larger squares in a bottom block, smaller in a top strip."""
    best = None
    best_sum = -1.0
    for k in range(1, n):
        m = n - k
        # Bottom block: k squares in a grid of k1 x k2
        for a in range(1, k + 1):
            b = (k + a - 1) // a
            if a * b < k:
                continue
            # Place k squares in a rows x b cols grid (last row partial)
            full_rows = k // b
            partial = k % b
            total_rows = full_rows + (1 if partial else 0)
            h = min(1.0 / total_rows, 1.0)
            w = min(1.0 / b, 1.0)
            s1 = min(h, w)
            # Top strip height
            top_h = 1.0 - total_rows * s1
            if top_h < -1e-12:
                continue
            # Top: m squares in a grid
            if m == 0:
                s2 = 0.0
                top_rows = 0
            else:
                for a2 in range(1, m + 1):
                    b2 = (m + a2 - 1) // a2
                    if a2 * b2 < m:
                        continue
                    full2 = m // b2
                    part2 = m % b2
                    trows = full2 + (1 if part2 else 0)
                    if trows == 0:
                        continue
                    s2 = min(1.0 / b2, top_h / trows) if trows > 0 else 0.0
                    if s2 <= 0:
                        continue
                    out = []
                    y = 0.0
                    cnt = 0
                    for r in range(total_rows):
                        in_row = b if r < full_rows else partial
                        if in_row == 0:
                            continue
                        x0 = (1.0 - in_row * s1) / 2.0
                        for c in range(in_row):
                            if cnt < k:
                                out.append((x0 + (c + 0.5) * s1, y + 0.5 * s1, 0.0, s1))
                                cnt += 1
                        y += s1
                    y_top = total_rows * s1
                    y = y_top
                    cnt = 0
                    for r in range(trows):
                        in_row = b2 if r < full2 else part2
                        if in_row == 0:
                            continue
                        x0 = (1.0 - in_row * s2) / 2.0
                        for c in range(in_row):
                            if cnt < m:
                                out.append((x0 + (c + 0.5) * s2, y + 0.5 * s2, 0.0, s2))
                                cnt += 1
                        y += s2
                    while len(out) < n:
                        out.append((0.5, 0.5, 0.0, 0.0))
                    val = sum(q[3] for q in out)
                    if val > best_sum:
                        best_sum = val
                        best = out[:n]
                    break  # take best b2 for this a2 is enough, but loop more later
    return best


def _three_block_pack(n: int) -> List[Square]:
    """Try splitting into 1, 2, or 3 horizontal strips of equal squares."""
    best = None
    best_sum = -1.0
    # Try k1 + k2 + k3 = n, each strip packed with equal squares.
    # Strip i has k_i squares; choose grid dimensions to maximize size under its height.
    for parts in range(1, 4):
        if parts == 1:
            split_list = [(n,)]
        elif parts == 2:
            split_list = [(a, n - a) for a in range(1, n)]
        else:
            split_list = []
            for a in range(1, n - 1):
                for b in range(1, n - a):
                    c = n - a - b
                    if c >= 1:
                        split_list.append((a, b, c))
            if len(split_list) > 5000:
                # sample
                random.seed(12345)
                split_list = random.sample(split_list, 5000)
        for split in split_list:
            # For each strip, find its best square side given its height budget.
            # We distribute height among strips. Strip i needs h_i >= rows_i * s_i,
            # and s_i <= 1/cols_i. We choose rows_i/cols_i for each strip.
            # Simplify: choose cols_i = ceil(sqrt(k_i)), rows_i = ceil(k_i/cols_i).
            strips = []
            ok = True
            for k in split:
                cols = max(1, int(math.ceil(math.sqrt(k))))
                rows = (k + cols - 1) // cols
                strips.append((k, rows, cols))
            # We need sum over strips of rows_i * s_i <= 1, with s_i <= 1/cols_i.
            # Max sum of s_i = sum min(1/cols_i, h_i/rows_i) subject to sum h_i <= 1.
            # Water-filling: give each strip height so s_i equalizes up to cap.
            caps = [1.0 / c for (_, _, c) in strips]
            # Binary search on target t: h_i = rows_i * min(t, cap_i), sum h_i <= 1
            lo, hi = 0.0, 1.0
            for _ in range(50):
                mid = (lo + hi) / 2
                total_h = 0.0
                for (k, rows, cols), cap in zip(strips, caps):
                    total_h += rows * min(mid, cap)
                if total_h <= 1.0:
                    lo = mid
                else:
                    hi = mid
            t = lo
            total_h = 0.0
            sides = []
            for (k, rows, cols), cap in zip(strips, caps):
                s = min(t, cap)
                sides.append(s)
                total_h += rows * s
            if total_h > 1.0 + 1e-9:
                continue
            # build
            out = []
            y = 0.0
            for (k, rows, cols), s in zip(strips, sides):
                if s <= 0:
                    # all zero squares
                    continue
                full_rows = k // cols
                partial = k % cols
                total_rows = full_rows + (1 if partial else 0)
                cnt = 0
                for r in range(total_rows):
                    in_row = cols if r < full_rows else partial
                    if in_row == 0:
                        continue
                    x0 = (1.0 - in_row * s) / 2.0
                    for c in range(in_row):
                        if cnt < k:
                            out.append((x0 + (c + 0.5) * s, y + 0.5 * s, 0.0, s))
                            cnt += 1
                    y += s
            while len(out) < n:
                out.append((0.5, 0.5, 0.0, 0.0))
            val = sum(q[3] for q in out)
            if val > best_sum:
                best_sum = val
                best = out[:n]
    return best


def _overlap_free(sq: List[Square]) -> bool:
    """Check that no two squares with positive side overlap in interior.
    For rotated squares, use separating axis theorem on OBBs."""
    for i in range(len(sq)):
        xi, yi, ai, si = sq[i]
        if si <= 0:
            continue
        # represent as OBB
        ca, sa = math.cos(2 * math.pi * ai), math.sin(2 * math.pi * ai)
        # half extents along local axes
        for j in range(i + 1, len(sq)):
            xj, yj, aj, sj = sq[j]
            if sj <= 0:
                continue
            # SAT for two OBBs
            if _obb_sep(xi, yi, ai, si, xj, yj, aj, sj):
                continue
            return False
    return True


def _obb_sep(x1, y1, a1, s1, x2, y2, a2, s2) -> bool:
    """Return True if the two oriented squares are separated (no interior overlap)."""
    # corners
    def corners(x, y, a, s):
        c = math.cos(2 * math.pi * a)
        sn = math.sin(2 * math.pi * a)
        h = s / 2.0
        pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
        return [(x + px * c - py * sn, y + px * sn + py * c) for px, py in pts]

    A = corners(x1, y1, a1, s1)
    B = corners(x2, y2, a2, s2)
    # axes from A and B edges
    axes = []
    for k in range(2):
        ax = A[(k + 1) % 4][0] - A[k][0]
        ay = A[(k + 1) % 4][1] - A[k][1]
        axes.append((ax, ay))
        bx = B[(k + 1) % 4][0] - B[k][0]
        by = B[(k + 1) % 4][1] - B[k][1]
        axes.append((bx, by))
    for ax, ay in axes:
        # project both onto axis
        minA = min(px * ax + py * ay for px, py in A)
        maxA = max(px * ax + py * ay for px, py in A)
        minB = min(px * ax + py * ay for px, py in B)
        maxB = max(px * ax + py * ay for px, py in B)
        if maxA <= minB + 1e-12 or maxB <= minA + 1e-12:
            return True
    return False


def _fix_inside(sq: List[Square]) -> List[Square]:
    out = []
    for x, y, a, s in sq:
        if s <= 0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        x = min(max(x, 0.0), 1.0)
        y = min(max(y, 0.0), 1.0)
        # For axis-aligned, clamp properly; for rotated, clamp conservatively
        c = abs(math.cos(2 * math.pi * a)) + abs(math.sin(2 * math.pi * a))
        half = s / 2.0 * c
        if half >= 0.5:
            s = min(s, 1.0 / c)
            half = s / 2.0 * c
        x = min(max(x, half), 1.0 - half)
        y = min(max(y, half), 1.0 - half)
        out.append((x, y, a, s))
    return out


def _sum(sq): return sum(q[3] for q in sq)


def _local_improve(sq: List[Square], time_budget=1.5) -> List[Square]:
    """Small coordinate descent: randomly perturb centers and sizes, accept if valid and improves."""
    import time
    t0 = time.time()
    best = [q[:] for q in sq]
    best_sum = _sum(best)
    rng = random.Random(999)
    n = len(best)
    steps = 0
    while time.time() - t0 < time_budget:
        steps += 1
        cand = [q[:] for q in best]
        i = rng.randrange(n)
        x, y, a, s = cand[i]
        mode = rng.random()
        if mode < 0.5:
            # try increasing size
            ds = rng.uniform(0.0, 0.03)
            s2 = s + ds
            c = abs(math.cos(2 * math.pi * a)) + abs(math.sin(2 * math.pi * a))
            half = s2 / 2.0 * c
            if half > 0.5:
                s2 = 1.0 / c
            cand[i] = (x, y, a, max(0.0, s2))
        elif mode < 0.75:
            # move
            dx, dy = rng.uniform(-0.02, 0.02), rng.uniform(-0.02, 0.02)
            cand[i] = (x + dx, y + dy, a, s)
        else:
            # rotate slightly (only if axis-aligned, otherwise skip)
            if abs(a) < 1e-9 or abs(a - 0.5) < 1e-9 or abs(a - 0.25) < 1e-9:
                cand[i] = (x, y, a + rng.choice([0.25, 0.5]) * rng.choice([-1, 1]) * 0 + a, s)
            else:
                cand[i] = (x, y, a, s)
        cand = _fix_inside(cand)
        if _sum(cand) <= best_sum + 1e-12:
            continue
        if _overlap_free(cand):
            best = cand
            best_sum = _sum(cand)
    return best


def solve(n: int) -> List[Square]:
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side by side or rotated 45 deg (both size sqrt(2)/2? no, side 0.5 each)
        # best known: two squares side 1/2 rotated? Actually 1/2 each axis aligned, sum=1.
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]

    candidates = []

    # 1) Grid
    k = math.isqrt(n)
    candidates.append(_grid(n, k, 1.0 / k))

    # 2) Row pack
    rp = _row_pack(n)
    if rp is not None:
        candidates.append(rp)

    # 3) Multi-strip pack
    tp = _three_block_pack(n)
    if tp is not None:
        candidates.append(tp)

    # 4) Two block
    try:
        bp = _two_block_pack(n)
        if bp is not None:
            candidates.append(bp)
    except Exception:
        pass

    # 5) Rotated large square + smaller ones in corners? Try a 45-degree large square
    #    with four corner squares. Only for small n where it helps.
    if n <= 8:
        for big_side in [0.7, 0.8, 0.9, 1.0 / math.sqrt(2)]:
            c = math.cos(math.pi / 4) + math.sin(math.pi / 4)
            if big_side * c > 1.0 + 1e-9:
                continue
            out = [(0.5, 0.5, 0.125, big_side)]
            rem = n - 1
            # place in four corners and then bottom
            corner_slots = [(0.05, 0.05), (0.95, 0.05), (0.05, 0.95), (0.95, 0.95)]
            si = 0
            for cx, cy in corner_slots:
                if rem <= 0:
                    break
                out.append((cx, cy, 0.0, 0.0))
                si += 1
                rem -= 1
            while len(out) < n:
                out.append((0.5, 0.5, 0.0, 0.0))
            candidates.append(out)

    # Choose best valid candidate
    best = None
    best_sum = -1.0
    for cand in candidates:
        if cand is None or len(cand) != n:
            continue
        cand = _fix_inside(cand)
        if not _overlap_free(cand):
            # try to repair by zeroing overlapping squares
            cand = _repair(cand)
            if not _overlap_free(cand):
                continue
        val = _sum(cand)
        if val > best_sum:
            best_sum = val
            best = [q[:] for q in cand]

    if best is None:
        best = _grid(n, max(1, math.isqrt(n)), 1.0 / max(1, math.isqrt(n)))

    # Local improvement, but keep within time limits (60s total).
    # Use adaptive budget based on n.
    budget = 0.5 if n > 200 else 1.5
    try:
        improved = _local_improve(best, time_budget=budget)
        if _sum(improved) >= _sum(best) and _overlap_free(improved):
            best = improved
    except Exception:
        pass

    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    return best[:n]


def _repair(sq: List[Square]) -> List[Square]:
    """Zero out squares that overlap with earlier ones, keep others."""
    out = []
    for i, q in enumerate(sq):
        x, y, a, s = q
        if s <= 0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ok = True
        for j in range(len(out)):
            xj, yj, aj, sj = out[j]
            if sj <= 0:
                continue
            if not _obb_sep(x, y, a, s, xj, yj, aj, sj):
                ok = False
                break
        if ok:
            out.append((x, y, a, s))
        else:
            out.append((0.5, 0.5, 0.0, 0.0))
    return out
