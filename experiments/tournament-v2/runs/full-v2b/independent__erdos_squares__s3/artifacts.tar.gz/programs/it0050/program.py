import math
import random

# ---------------------------------------------------------------
# geometry helpers
# ---------------------------------------------------------------

def corners(cx, cy, ang, s):
    """corners of square (centre, angle fraction of turn, side)"""
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        pts.append((cx + dx * ca - dy * sa, cy + dx * sa + dy * ca))
    return pts


def sat_gap(A, B):
    """return separating distance (<=0 means overlap) between convex polygons A,B"""
    best = -1e18
    for poly in (A, B):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            # normal
            nx, ny = -ey, ex
            L = math.hypot(nx, ny)
            if L == 0:
                continue
            nx /= L
            ny /= L
            # projection of A
            amin = amax = A[0][0] * nx + A[0][1] * ny
            for p in A[1:]:
                v = p[0] * nx + p[1] * ny
                if v < amin: amin = v
                if v > amax: amax = v
            bmin = bmax = B[0][0] * nx + B[0][1] * ny
            for p in B[1:]:
                v = p[0] * nx + p[1] * ny
                if v < bmin: bmin = v
                if v > bmax: bmax = v
            gap = max(amin - bmax, bmin - amax)
            if gap > best:
                best = gap
            if best > 0:
                return best
    return best


def overlap(A, B):
    g = sat_gap(A, B)
    return g  # >0 separated, <=0 overlap amount

# ---------------------------------------------------------------
# initial constructions
# ---------------------------------------------------------------

def grid_pack(n, k, rows=None):
    """k columns grid with n squares"""
    if rows is None:
        rows = n // k
    cols = k
    s = 1.0 / cols
    sy = 1.0 / rows
    side = min(s, sy)
    res = []
    for i in range(cols):
        for j in range(rows):
            res.append(((i + 0.5) * s, (j + 0.5) * sy, 0.0, side))
    return res[:n]


def initial(n):
    """produce n non-overlapping squares"""
    # special cases
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        # two squares side by side
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s), (0.25, 0.75, 0.0, s)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    if n == 5:
        s = 0.5
        res = [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s),
               (0.25, 0.75, 0.0, s), (0.75, 0.75, 0.0, s)]
        res.append((0.0, 0.0, 0.0, 0.0))
        return res
    # general: best grid layout over divisors
    best = None
    bestv = -1
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        s = min(1.0 / cols, 1.0 / rows)
        tot = s * n
        if tot > bestv:
            bestv = tot
            best = (cols, rows, s)
    cols, rows, s = best
    res = []
    idx = 0
    for i in range(cols):
        for j in range(rows):
            if idx >= n:
                break
            res.append(((i + 0.5) / cols, (j + 0.5) / rows, 0.0, s))
            idx += 1
        if idx >= n:
            break
    return res

# ---------------------------------------------------------------
# objective
# ---------------------------------------------------------------

def total_score(sqs):
    return sum(q[3] for q in sqs)


def violation(sqs):
    """total overlap plus out of bounds, only among positive-size squares"""
    pen = 0.0
    P = [q for q in sqs if q[3] > 1e-12]
    C = [corners(*q) for q in P]
    for i in range(len(P)):
        for j in range(i + 1, len(P)):
            g = sat_gap(C[i], C[j])
            if g < 0:
                pen += -g
        # bounds
        for (x, y) in C[i]:
            if x < 0:
                pen += -x
            elif x > 1:
                pen += x - 1
            if y < 0:
                pen += -y
            elif y > 1:
                pen += y - 1
    return pen

# ---------------------------------------------------------------
# local optimiser
# ---------------------------------------------------------------

def local_search(sqs, iters=1500, seed=0):
    random.seed(seed)
    best = [list(q) for q in sqs]
    bestv = total_score(sqs)
    bestpen = violation(sqs)
    cur = [list(q) for q in sqs]
    curv = bestv
    curpen = bestpen

    def clamp_square(q):
        cx, cy, ang, s = q
        s = min(s, 1.0)
        if s < 0:
            s = 0.0
        if s > 0:
            h = s * 0.5
            a = ang * 2.0 * math.pi
            ca, sa = math.cos(a), math.sin(a)
            dx = abs(ca) + abs(sa)
            m = dx * h
            cx = min(max(cx, m), 1 - m)
            cy = min(max(cy, m), 1 - m)
        else:
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
        q[:] = [cx, cy, ang, s]

    for it in range(iters):
        T = 0.02 * (1 - it / iters) + 0.001
        idx = random.randrange(len(cur))
        q = cur[idx]
        old = q[:]
        mode = random.random()
        if mode < 0.35:
            # resize
            q[3] *= random.uniform(0.9, 1.1)
        elif mode < 0.6:
            # move
            q[0] += random.gauss(0, 0.01)
            q[1] += random.gauss(0, 0.01)
        elif mode < 0.8:
            # rotate
            q[2] += random.gauss(0, 0.05)
        else:
            # small resize up intent
            q[3] += random.gauss(0, 0.01)
        clamp_square(q)

        npen = violation(cur)
        nv = total_score(cur)

        # accept
        old_obj = curv - 100 * curpen
        new_obj = nv - 100 * npen
        accept = False
        if npen < 1e-9 and curpen < 1e-9:
            if nv > curv:
                accept = True
        else:
            if new_obj > old_obj:
                accept = True
        if not accept:
            d = new_obj - old_obj
            if random.random() < math.exp(min(0, d) / T):
                accept = True
        if accept:
            curv = nv
            curpen = npen
            if curpen < 1e-9 and curv > bestv:
                bestv = curv
                best = [x[:] for x in cur]
        else:
            q[:] = old
    return [tuple(x) for x in best]

# ---------------------------------------------------------------
# strength packing: recursively subdivide good shapes
# ---------------------------------------------------------------

def guillotine(n):
    """recursively split a rectangle horizontally/vertically"""
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # choose split
    if n % 2 == 0:
        a, b = n // 2, n // 2
    else:
        a = n // 2
        b = n - a
    # place a left, b right
    left = guillotine(a)
    right = guillotine(b)
    # left occupies x in [0, 0.5], right [0.5, 1]
    res = []
    for (cx, cy, ang, s) in left:
        res.append((cx * 0.5, cy, ang, s * 0.5))
    for (cx, cy, ang, s) in right:
        res.append((cx * 0.5 + 0.5, cy, ang, s * 0.5))
    return res


def initial2(n):
    cands = []
    cands.append(initial(n))
    cands.append(guillotine(n))
    best = cands[0]
    bv = total_score(best) - 100 * violation(best)
    for c in cands[1:]:
        v = total_score(c) - 100 * violation(c)
        if v > bv:
            bv = v
            best = c
    return best

# ---------------------------------------------------------------
# main
# ---------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    sqs = initial2(n)
    # local optimise
    iters = min(4000, 400 + n * 30)
    best = local_search(sqs, iters=int(iters), seed=12345)
    # a second restart
    iters2 = min(3000, 300 + n * 20)
    best2 = local_search(sqs, iters=int(iters2), seed=999)
    if total_score(best2) - 100 * violation(best2) > total_score(best) - 100 * violation(best):
        best = best2
    # final clamp, kill negatives
    out = []
    for (cx, cy, ang, s) in best:
        if s < 0:
            s = 0.0
        if s == 0.0:
            out.append((0.5, 0.5, 0.0, 0.0))
        else:
            a = ang * 2.0 * math.pi
            h = s * 0.5
            dx = (abs(math.cos(a)) + abs(math.sin(a))) * h
            cx = min(max(cx, dx), 1 - dx)
            cy = min(max(cy, dx), 1 - dx)
            out.append((cx, cy, ang, s))
    return out


if __name__ == "__main__":
    for nn in range(1, 20):
        r = solve(nn)
        print(nn, sum(q[3] for q in r), len(r))
