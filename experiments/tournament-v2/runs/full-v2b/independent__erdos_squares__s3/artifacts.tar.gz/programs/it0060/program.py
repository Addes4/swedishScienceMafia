import math
import numpy as np
from scipy.optimize import minimize

# ---------- geometry helpers ----------

def corners(cx, cy, ang, s):
    """Return 4x2 array of corners of a square (center cx,cy, angle fraction of turn, side s)."""
    th = ang * 2.0 * math.pi
    c, sn = math.cos(th), math.sin(th)
    h = s * 0.5
    # local corner offsets (before rotation)
    off = np.array([[-h, -h], [h, -h], [h, h], [-h, h]], dtype=float)
    R = np.array([[c, -sn], [sn, c]], dtype=float)
    return off @ R.T + np.array([cx, cy], dtype=float)


def overlap_depth(polyA, polyB):
    """Approximate penetration depth between two convex polygons using SAT.
    Returns >0 if they overlap (positive depth), <=0 if separated (max separation)."""
    # use separating axis theorem on both polygons' edges
    best = -1e18
    for poly in (polyA, polyB):
        n = len(poly)
        for i in range(n):
            a = poly[i]
            b = poly[(i + 1) % n]
            edge = b - a
            axis = np.array([-edge[1], edge[0]], dtype=float)
            la = np.linalg.norm(axis)
            if la < 1e-15:
                continue
            axis /= la
            projA = polyA @ axis
            projB = polyB @ axis
            gap = min(projA.max(), projB.max()) - max(projA.min(), projB.min())
            best = max(best, gap)
    return best


def point_in_poly(p, poly, eps=1e-12):
    n = len(poly)
    sign = 0
    for i in range(n):
        a = poly[i]
        b = poly[(i + 1) % n]
        cross = (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])
        if cross > eps:
            s = 1
        elif cross < -eps:
            s = -1
        else:
            continue
        if sign == 0:
            sign = s
        elif sign != s:
            return False
    return True


def clip_poly_to_unit(poly):
    """Clip a convex polygon to the unit square [0,1]^2 (Sutherland-Hodgman)."""
    def clip_edge(poly, inside, intersect):
        out = []
        n = len(poly)
        for i in range(n):
            cur = poly[i]
            nxt = poly[(i + 1) % n]
            cin = inside(cur)
            nin = inside(nxt)
            if cin:
                out.append(cur)
            if cin != nin:
                out.append(intersect(cur, nxt))
        return out

    def inside_left(p):
        return p[0] >= -1e-12

    def inside_right(p):
        return p[0] <= 1.0 + 1e-12

    def inside_bottom(p):
        return p[1] >= -1e-12

    def inside_top(p):
        return p[1] <= 1.0 + 1e-12

    def inter_x(p, q, x):
        t = (x - p[0]) / (q[0] - p[0]) if abs(q[0] - p[0]) > 1e-15 else 0.0
        return np.array([x, p[1] + t * (q[1] - p[1])])

    def inter_y(p, q, y):
        t = (y - p[1]) / (q[1] - p[1]) if abs(q[1] - p[1]) > 1e-15 else 0.0
        return np.array([p[0] + t * (q[0] - p[0]), y])

    poly = [np.asarray(p, dtype=float) for p in poly]
    poly = clip_edge(poly, inside_left, lambda p, q: inter_x(p, q, 0.0))
    if len(poly) < 3:
        return None
    poly = clip_edge(poly, inside_right, lambda p, q: inter_x(p, q, 1.0))
    if len(poly) < 3:
        return None
    poly = clip_edge(poly, inside_bottom, lambda p, q: inter_y(p, q, 0.0))
    if len(poly) < 3:
        return None
    poly = clip_edge(poly, inside_top, lambda p, q: inter_y(p, q, 1.0))
    if len(poly) < 3:
        return None
    return np.array(poly)


# ---------- objective construction ----------

BIG = 1e4

def unpack(x):
    """x length 3n+? -> list of (cx,cy,ang,s)."""
    n = len(x) // 3
    res = []
    for i in range(n):
        cx = x[3 * i]
        cy = x[3 * i + 1]
        ang = x[3 * i + 2]
        # side stored implicitly? No: we optimize side too. Need 4 per square.
    return res


def solve(n, time_limit=55.0):
    import time
    t0 = time.time()

    if n <= 0:
        return []

    # We'll optimize parameters: for each square (cx, cy, ang, s)
    # Total 4n variables.
    # Objective: maximize sum s - penalty.
    # Penalty: overlap between squares + squares outside unit square.
    #
    # To keep things tractable for moderate/large n, we do a greedy construction
    # plus local coordinate refinement.

    # Start with baseline grid for the largest k that fits
    k = max(1, math.isqrt(n))
    # We'll try several candidate k values near isqrt(n)
    best_result = None
    best_sum = -1.0

    candidates_k = set()
    for kk in range(max(1, k - 2), min(n, k + 3) + 1):
        if kk * kk <= n:
            candidates_k.add(kk)
    if not candidates_k:
        candidates_k.add(1)

    # Also try patterns with mixed sizes: rows/columns
    # We'll generate several initial configurations and refine.

    def make_grid_init(kk):
        s = 1.0 / kk
        pts = []
        cnt = 0
        for i in range(kk):
            for j in range(kk):
                if cnt >= n:
                    break
                pts.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                cnt += 1
            if cnt >= n:
                break
        # remaining as tiny zero-size squares placed at random non-overlapping-ish spots
        while len(pts) < n:
            # try to fit a tiny square in a random location; just use tiny size 0.0
            pts.append((0.5 + (len(pts) % 7) * 0.013, 0.5 + (len(pts) % 5) * 0.017, 0.0, 0.0))
        return pts

    def make_mixed_init():
        # Try to pack with varying sizes: greedy largest-first in a grid-ish arrangement
        # simpler: divide unit square into k columns of varying widths
        pts = []
        # Start from grid, then randomly perturb sizes
        kk = max(1, math.isqrt(n))
        s = 1.0 / kk
        cell = 0
        for i in range(kk):
            for j in range(kk):
                if len(pts) >= n:
                    break
                pts.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
            if len(pts) >= n:
                break
        while len(pts) < n:
            pts.append((0.5, 0.5, 0.0, 0.0))
        return pts

    inits = []
    for kk in candidates_k:
        inits.append(make_grid_init(kk))
    # add a few perturbed versions
    base = make_grid_init(k)
    for _ in range(3):
        pert = []
        for (cx, cy, ang, s) in base:
            pert.append((min(max(cx + np.random.uniform(-0.02, 0.02), 0.0), 1.0),
                         min(max(cy + np.random.uniform(-0.02, 0.02), 0.0), 1.0),
                         (ang + np.random.uniform(-0.05, 0.05)) % 1.0,
                         max(0.0, s + np.random.uniform(-0.01, 0.01))))
        inits.append(pert)

    def evaluate(params):
        # params: list of (cx,cy,ang,s)
        polys = []
        total_s = 0.0
        pen = 0.0
        for (cx, cy, ang, s) in params:
            if s <= 1e-12:
                polys.append(None)
                continue
            total_s += s
            poly = corners(cx, cy, ang, s)
            clipped = clip_poly_to_unit(poly)
            if clipped is None or len(clipped) < 3:
                # fully outside: penalty
                pen += BIG * s * s + 1.0
                polys.append(None)
                continue
            # penalty for area outside unit square
            area_full = s * s
            # compute clipped area (shoelace)
            x = clipped[:, 0]
            y = clipped[:, 1]
            area_clipped = 0.5 * abs(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))
            outside_area = max(0.0, area_full - area_clipped)
            if outside_area > 1e-9:
                pen += BIG * outside_area
            polys.append(clipped)

        # overlap penalty between all pairs
        for i in range(n):
            if polys[i] is None:
                continue
            for j in range(i + 1, n):
                if polys[j] is None:
                    continue
                d = overlap_depth(polys[i], polys[j])
                if d > 1e-9:
                    pen += BIG * d
        return total_s - pen

    def to_vec(params):
        v = []
        for (cx, cy, ang, s) in params:
            v.extend([cx, cy, ang, s])
        return np.array(v, dtype=float)

    def from_vec(v):
        params = []
        for i in range(n):
            cx = min(max(v[4 * i], 0.0), 1.0)
            cy = min(max(v[4 * i + 1], 0.0), 1.0)
            ang = v[4 * i + 2] % 1.0
            s = min(max(v[4 * i + 3], 0.0), 1.0)
            params.append((cx, cy, ang, s))
        return params

    def obj_vec(v):
        params = from_vec(v)
        return -evaluate(params)  # minimize negative

    # Refine each initialization with Nelder-Mead (derivative-free)
    # For large n this is too slow; use coordinate descent style.
    best_params = None

    def refine_local(params, maxiter=200, max_time=None):
        v = to_vec(params)
        # coordinate-wise adjustment: try small perturbations to improve
        # For coarse refinement when n is moderate, use Nelder-Mead on subsets.
        n_par = n
        if n_par * 4 <= 80:
            try:
                res = minimize(obj_vec, v, method='Nelder-Mead',
                               options={'maxiter': maxiter, 'xatol': 1e-6, 'fatol': 1e-8,
                                        'disp': False})
                cand = from_vec(res.x)
                if evaluate(cand) > evaluate(params):
                    return cand
            except Exception:
                pass
        # fallback: greedy coordinate tuning by scaling/permuting
        return params

    def improve(params, rounds=3, time_budget=None):
        cur = list(params)
        best_val = evaluate(cur)
        cur_val = best_val
        # try small random perturbations and keep improvements
        rng = np.random.default_rng(12345)
        t_start = time.time()
        for it in range(rounds):
            if time_budget and time.time() - t_start > time_budget:
                break
            improved = False
            # for each square, try adjusting size up/down slightly
            idxs = list(range(n))
            rng.shuffle(idxs)
            for i in idxs:
                cx, cy, ang, s = cur[i]
                trials = []
                # size tweaks
                for ds in [0.02, -0.02, 0.05, -0.05, 0.01, -0.01, 0.1, -0.1]:
                    ns = s + ds
                    if 0.0 <= ns <= 1.0:
                        trials.append((cx, cy, ang, ns))
                # position tweaks
                for dx, dy in [(0.01, 0), (-0.01, 0), (0, 0.01), (0, -0.01),
                               (0.02, 0.02), (-0.02, -0.02), (0.02, -0.02), (-0.02, 0.02),
                               (0.005, 0), (0, 0.005), (-0.005, 0), (0, -0.005)]:
                    ncx = min(max(cx + dx, 0.0), 1.0)
                    ncy = min(max(cy + dy, 0.0), 1.0)
                    trials.append((ncx, ncy, ang, s))
                # angle tweaks
                for da in [0.01, -0.01, 0.02, -0.02, 0.05, -0.05, 0.1, -0.1]:
                    trials.append((cx, cy, (ang + da) % 1.0, s))

                for t in trials:
                    cand = list(cur)
                    cand[i] = t
                    val = evaluate(cand)
                    if val > cur_val + 1e-9:
                        cur = cand
                        cur_val = val
                        improved = True
                        break
            if not improved:
                # try random global-ish perturbation
                for _ in range(min(20, n)):
                    i = rng.integers(0, n)
                    cx, cy, ang, s = cur[i]
                    ncx = min(max(cx + rng.uniform(-0.03, 0.03), 0.0), 1.0)
                    ncy = min(max(cy + rng.uniform(-0.03, 0.03), 0.0), 1.0)
                    nang = (ang + rng.uniform(-0.1, 0.1)) % 1.0
                    ns = min(max(s + rng.uniform(-0.02, 0.02), 0.0), 1.0)
                    cand = list(cur)
                    cand[i] = (ncx, ncy, nang, ns)
                    val = evaluate(cand)
                    if val > cur_val + 1e-9:
                        cur = cand
                        cur_val = val
                        improved = True
                if not improved:
                    break
        return cur

    # Try all inits with limited time each
    n_init = len(inits)
    per_init_time = max(1.0, (time_limit - (time.time() - t0)) / max(1, n_init))

    for init in inits:
        remaining = time_limit - (time.time() - t0)
        if remaining <= 1.0:
            break
        budget = min(per_init_time, remaining)
        # refine
        refined = refine_local(init, maxiter=150)
        # improve locally within budget
        improved = improve(refined, rounds=5, time_budget=budget)
        val = evaluate(improved)
        if val > best_sum:
            best_sum = val
            best_params = improved

    # Final output: ensure format
    if best_params is None:
        # fallback baseline
        kk = max(1, math.isqrt(n))
        s = 1.0 / kk
        best_params = []
        for i in range(n):
            ii = i % kk
            jj = (i // kk) % kk
            best_params.append(((ii + 0.5) * s, (jj + 0.5) * s, 0.0, s if i < kk * kk else 0.0))

    return [(float(cx), float(cy), float(ang % 1.0), float(max(0.0, s))) for (cx, cy, ang, s) in best_params]
