import math
import random
import numpy as np


def _corners(cx, cy, ang, s):
    h = s * 0.5
    c = math.cos(2.0 * math.pi * ang)
    sn = math.sin(2.0 * math.pi * ang)
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * c - dy * sn
        y = cy + dx * sn + dy * c
        pts.append((x, y))
    return pts


def _axes(ang):
    t = 2.0 * math.pi * ang
    c = math.cos(t)
    s = math.sin(t)
    return (c, s), (-s, c)


def _project(pts, ax):
    return min(p[0] * ax[0] + p[1] * ax[1] for p in pts), max(p[0] * ax[0] + p[1] * ax[1] for p in pts)


def _overlap(a, b):
    ca = _corners(a[0], a[1], a[2], a[3])
    cb = _corners(b[0], b[1], b[2], b[3])
    axes = list(_axes(a[2])) + list(_axes(b[2]))
    for ax in axes:
        a0, a1 = _project(ca, ax)
        b0, b1 = _project(cb, ax)
        if a1 <= b0 + 1e-15 or b1 <= a0 + 1e-15:
            return False
    return True


def _valid(sq):
    n = len(sq)
    for i in range(n):
        if sq[i][3] <= 0:
            continue
        for j in range(i + 1, n):
            if sq[j][3] <= 0:
                continue
            if _overlap(sq[i], sq[j]):
                return False
    return True


def _clamp_sq(sq):
    out = []
    for cx, cy, ang, s in sq:
        if s <= 0:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        ang = ang % 1.0
        # center must keep all corners in [0,1]
        c = abs(math.cos(2.0 * math.pi * ang)) * 0.5 * s
        sn = abs(math.sin(2.0 * math.pi * ang)) * 0.5 * s
        h = c + sn
        if h > 0.5:
            s = 0.5 / (abs(math.cos(2.0 * math.pi * ang)) * 0.5 + abs(math.sin(2.0 * math.pi * ang)) * 0.5)
            c = abs(math.cos(2.0 * math.pi * ang)) * 0.5 * s
            sn = abs(math.sin(2.0 * math.pi * ang)) * 0.5 * s
            h = c + sn
        cx = min(max(cx, h), 1.0 - h)
        cy = min(max(cy, h), 1.0 - h)
        out.append((cx, cy, ang, s))
    return out


def _sum(sq):
    return sum(max(0.0, x[3]) for x in sq)


def _grid_init(n):
    k = math.isqrt(n)
    if k < 1:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    rest = n - len(sq)
    if rest:
        sq += _fill_rest(rest, 0.0, 0.0, 1.0, 1.0)
    return sq[:n]


def _fill_rest(m, x0, y0, w, h):
    """Pack m squares (possibly rotated) into an axis-aligned rectangle, small ones."""
    res = []
    if m <= 0:
        return res
    if w <= 1e-12 or h <= 1e-12:
        return [(x0 + w * 0.5, y0 + h * 0.5, 0.0, 0.0)] * m
    # strip packing: split rectangle into m horizontal strips of equal height
    if w >= h:
        strip_h = h / m
        s = min(w, strip_h)
        for i in range(m):
            cy = y0 + strip_h * (i + 0.5)
            cx = x0 + w * 0.5
            res.append((cx, cy, 0.0, s))
    else:
        strip_w = w / m
        s = min(h, strip_w)
        for i in range(m):
            cx = x0 + strip_w * (i + 0.5)
            cy = y0 + h * 0.5
            res.append((cx, cy, 0.0, s))
    return res


def _init_construct(n):
    # grid of kxk plus extra packed into one leftover strip (simple, decent)
    k = math.isqrt(n)
    side = 1.0 / k
    sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    rest = n - len(sq)
    if rest:
        # leftover region: shrink grid to leave a strip? Instead add tiny squares in unused margin is zero.
        # Better: use k-1 grid with larger side plus a strip for rest.
        pass
    return sq


def _construct_best(n):
    """Try several k x k grid sizes and distribute leftover squares."""
    best = None
    bs = -1.0
    for k in range(1, max(2, n + 1)):
        if k * k > n:
            # k*k bigger than n: use k-1? skip
            pass
        cnt = min(n, k * k)
        if cnt < 1:
            continue
        # use k x k grid only if n >= k*k, else use k x k would exceed
        if k * k > n:
            continue
        side = 1.0 / k
        sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        rest = n - len(sq)
        if rest:
            # Put leftover squares into a thin border by reducing grid to k-1 is bad.
            # Instead subdivide some cells.
            sq = _subdivide_grid(n, k, side)
        s = _sum(sq)
        if s > bs and _valid(sq):
            bs = s
            best = sq
    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n
    return best


def _subdivide_grid(n, k, side):
    """k x k grid then split cells to accommodate extra squares (axis aligned)."""
    cells = [(i * side, j * side, side, side) for i in range(k) for j in range(k)]
    need = n
    # recursive split of largest cells
    import heapq
    heap = []
    for idx, (x, y, w, h) in enumerate(cells):
        heapq.heappush(heap, (-w * h, idx, x, y, w, h))
    out = []
    count = 0
    # We need exactly n squares. Start with k*k, split until we have n, each split +1.
    # Only split if beneficial enough; if not enough room, allow zero squares.
    splits = n - k * k
    cur = cells[:]
    for _ in range(splits):
        if not cur:
            break
        # find largest area cell
        bi = max(range(len(cur)), key=lambda i: cur[i][2] * cur[i][3])
        x, y, w, h = cur.pop(bi)
        if w >= h:
            w1 = w * 0.5
            cur.append((x, y, w1, h))
            cur.append((x + w1, y, w - w1, h))
        else:
            h1 = h * 0.5
            cur.append((x, y, w, h1))
            cur.append((x, y + h1, w, h - h1))
    res = []
    for x, y, w, h in cur:
        s = min(w, h)
        res.append((x + w * 0.5, y + h * 0.5, 0.0, s))
    while len(res) < n:
        res.append((0.5, 0.5, 0.0, 0.0))
    return res[:n]


def _local_opt(n, sq, iters=4000, rng=None):
    if rng is None:
        rng = random.Random(12345)
    sq = [list(x) for x in sq]
    best = [x[:] for x in sq]
    bs = _sum(best)
    T0 = 0.05
    for it in range(iters):
        T = T0 * (1.0 - it / iters) + 1e-4
        i = rng.randrange(n)
        if sq[i][3] <= 0:
            # try to give it small size
            cand = [sq[i][0], sq[i][1], sq[i][2], 0.0]
            cand[3] = rng.uniform(0.0, 0.02)
            cand = _clamp_sq([tuple(cand)])[0]
        else:
            cand = sq[i][:]
            what = rng.randrange(4)
            step = T * (rng.random() + 0.1)
            if what == 0:
                cand[0] += rng.gauss(0, step)
            elif what == 1:
                cand[1] += rng.gauss(0, step)
            elif what == 2:
                cand[2] += rng.gauss(0, step)
            else:
                cand[3] += rng.gauss(0, step)
            cand = _clamp_sq([tuple(cand)])[0]
        old = sq[i][:]
        sq[i] = list(cand)
        # check collisions with i
        ok = sq[i][3] <= 0 or sq[i][3] > 0
        if ok:
            for j in range(n):
                if j == i:
                    continue
                if sq[j][3] <= 0 or sq[i][3] <= 0:
                    continue
                if _overlap(tuple(sq[j]), tuple(sq[i])):
                    ok = False
                    break
        if ok:
            ns = _sum(sq)
            if ns >= bs - 1e-12 or rng.random() < math.exp((ns - bs) / max(T, 1e-9)):
                if ns > bs:
                    bs = ns
                    best = [x[:] for x in sq]
        else:
            sq[i] = old
    return [tuple(x) for x in best]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # construct candidates
    cands = []
    # simple grid
    k = math.isqrt(n)
    side = 1.0 / k
    g = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
    if len(g) < n:
        g += [(0.5, 0.5, 0.0, 0.0)] * (n - len(g))
    cands.append(g[:n])

    cands.append(_subdivide_grid(n, k, side))

    # try a slightly bigger grid with leftover small squares in a corner? skip
    best = None
    bs = -1
    for c in cands:
        c = _clamp_sq(c)
        s = _sum(c)
        if _valid(c) and s > bs:
            bs = s
            best = c

    if best is None:
        best = [(0.5, 0.5, 0.0, 0.0)] * n

    rng = random.Random(987654321 + n)
    # local optimize
    trials = 3 if n <= 30 else 1
    for t in range(trials):
        start = [list(x) for x in best]
        # random perturb for restart
        if t > 0:
            for i in range(n):
                if start[i][3] > 0:
                    start[i][2] += rng.uniform(-0.1, 0.1)
                    start[i][0] += rng.uniform(-0.02, 0.02)
                    start[i][1] += rng.uniform(-0.02, 0.02)
            start = [list(x) for x in _clamp_sq([tuple(y) for y in start])]
            if not _valid([tuple(y) for y in start]):
                start = [list(x) for x in best]
        res = _local_opt(n, start, iters=2500 if n <= 40 else 1200, rng=rng)
        s = _sum(res)
        if _valid(res) and s > bs:
            bs = s
            best = res

    return best
