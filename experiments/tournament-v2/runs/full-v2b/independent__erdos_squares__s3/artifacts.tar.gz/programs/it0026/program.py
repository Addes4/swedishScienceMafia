import math
import random
import numpy as np

def corners(cx, cy, ang, side):
    """Return 4 corners of a square."""
    h = side / 2.0
    ca, sa = math.cos(2*math.pi*ang), math.sin(2*math.pi*ang)
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        rx = ca*x - sa*y + cx
        ry = sa*x + ca*y + cy
        out.append((rx, ry))
    return out

def overlap(c1, c2):
    """Check if two convex polygons have overlapping interiors using SAT."""
    for poly1, poly2 in ((c1, c2), (c2, c1)):
        for i in range(4):
            x1, y1 = poly1[i]
            x2, y2 = poly1[(i+1) % 4]
            # edge normal
            nx, ny = -(y2 - y1), (x2 - x1)
            # project both
            min1 = max1 = None
            for px, py in poly1:
                d = px*nx + py*ny
                if min1 is None or d < min1: min1 = d
                if max1 is None or d > max1: max1 = d
            min2 = max2 = None
            for px, py in poly2:
                d = px*nx + py*ny
                if min2 is None or d < min2: min2 = d
                if max2 is None or d > max2: max2 = d
            # check overlap with small epsilon
            if max1 <= min2 + 1e-12 or max2 <= min1 + 1e-12:
                return False
    return True

def inside(cx, cy, ang, side, eps=1e-9):
    """Check if square is inside unit square."""
    if side == 0.0:
        return 0.0 - eps <= cx <= 1.0 + eps and 0.0 - eps <= cy <= 1.0 + eps
    for x, y in corners(cx, cy, ang, side):
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True

def is_valid(squares):
    """Check all pairs for overlap and all squares inside."""
    n = len(squares)
    polys = []
    for sq in squares:
        cx, cy, ang, side = sq
        if not inside(cx, cy, ang, side):
            return False
        if side > 0:
            polys.append((corners(cx, cy, ang, side),))
    # for zero side, just check center
    for i in range(n):
        cx, cy, ang, side = squares[i]
        if side == 0:
            # check point not inside any other square interior
            for j in range(n):
                if i == j: continue
                cx2, cy2, ang2, side2 = squares[j]
                if side2 == 0: continue
                # check point inside polygon j
                poly = corners(cx2, cy2, ang2, side2)
                # point in convex polygon test
                inside_flag = True
                for k in range(4):
                    x1, y1 = poly[k]
                    x2, y2 = poly[(k+1) % 4]
                    # cross product sign
                    cross = (x2 - x1) * (cy - y1) - (y2 - y1) * (cx - x1)
                    if cross < -1e-12:
                        inside_flag = False
                        break
                if inside_flag:
                    return False
    # check all pairs with side > 0
    for i in range(n):
        if squares[i][3] == 0: continue
        c1 = corners(*squares[i])
        for j in range(i+1, n):
            if squares[j][3] == 0: continue
            c2 = corners(*squares[j])
            if overlap(c1, c2):
                return False
    return True

def initial_grid(n):
    """Create a grid packing for n squares."""
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    # fill remaining with small squares in empty spots or zero
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return squares[:n]

def score(squares):
    return sum(sq[3] for sq in squares)

def optimize(n, time_limit=55):
    """Optimize using simulated annealing with adaptive perturbations."""
    import time
    start_time = time.time()
    
    # get initial
    if n <= 4:
        # special cases: all in a row-ish for small n
        if n == 1:
            return [(0.5, 0.5, 0.0, 1.0)]
        elif n == 2:
            # two rectangles? actually two squares side 0.5
            return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
        elif n == 3:
            # L-shape: 2x2 grid missing one, each side 0.5
            return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.25, 0.75, 0.0, 0.5)]
        elif n == 4:
            return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                    (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    
    # general case: start with grid
    best = initial_grid(n)
    best_score = score(best)
    
    current = [list(sq) for sq in best]
    current_score = best_score
    
    # adaptive parameters
    T = 0.1 * best_score / n
    cooling = 0.99995
    min_T = 1e-7
    
    step = 0
    while time.time() - start_time < time_limit:
        step += 1
        
        # pick random square
        idx = random.randrange(n)
        old = current[idx][:]
        
        # decide what to perturb
        r = random.random()
        if r < 0.4:
            # move
            dx = random.gauss(0, 0.01)
            dy = random.gauss(0, 0.01)
            current[idx][0] = max(0.0, min(1.0, old[0] + dx))
            current[idx][1] = max(0.0, min(1.0, old[1] + dy))
        elif r < 0.6:
            # rotate
            da = random.gauss(0, 0.01)
            current[idx][2] = (old[2] + da) % 1.0
        elif r < 0.9:
            # resize
            ds = random.gauss(0, 0.01)
            current[idx][3] = max(0.0, min(1.0, old[3] + ds))
        else:
            # combined
            current[idx][0] = max(0.0, min(1.0, old[0] + random.gauss(0, 0.005)))
            current[idx][1] = max(0.0, min(1.0, old[1] + random.gauss(0, 0.005)))
            current[idx][2] = (old[2] + random.gauss(0, 0.005)) % 1.0
            current[idx][3] = max(0.0, min(1.0, old[3] + random.gauss(0, 0.005)))
        
        if is_valid(current):
            new_score = score(current)
            delta = new_score - current_score
            if delta >= 0 or random.random() < math.exp(delta / T):
                current_score = new_score
                if new_score > best_score:
                    best_score = new_score
                    best = [list(sq) for sq in current]
        else:
            current[idx] = old  # revert
        
        T *= cooling
        if T < min_T:
            T = min_T
            cooling = 0.99999  # very slow cooling at low temp
    
    return best

def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n == 0:
        return []
    
    result = optimize(n, time_limit=55)
    
    # final validation
    cleaned = []
    for sq in result:
        cx, cy, ang, side = sq
        # clamp
        cx = max(0.0, min(1.0, cx))
        cy = max(0.0, min(1.0, cy))
        ang = ang % 1.0
        side = max(0.0, min(1.0, side))
        cleaned.append((cx, cy, ang, side))
    
    # ensure validity by shrinking if needed (shouldn't happen)
    if not is_valid([list(sq) for sq in cleaned]):
        # fallback to grid
        cleaned = initial_grid(n)
        cleaned = [(sq[0], sq[1], sq[2], sq[3]) for sq in cleaned]
    
    return cleaned[:n]
