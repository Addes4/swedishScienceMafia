import math
import random

def solve(n):
    if n <= 0:
        return []
    # Start with the largest k x k grid that fits
    k = math.isqrt(n)
    if k == 0:
        # n = 1, best is a single square of side 1
        return [(0.5, 0.5, 0.0, 1.0)]

    base_side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * base_side, (j + 0.5) * base_side, 0.0, base_side])

    # If we have exactly k^2 no extra work
    if len(squares) == n:
        return [(x, y, a, s) for (x, y, a, s) in squares]

    # We have some leftover squares: try to improve by using a slightly different arrangement.
    # Strategy: keep the grid but shrink all squares slightly to create a border, 
    # then place the remaining squares in that border with optimized rotation/size.
    # However, a simpler robust improvement: use a grid with fewer full squares 
    # and pack the rest in the leftover space using a greedy heuristic.

    # Approach: use k-1 full grid of side 1/(k) but shift to leave a strip? 
    # Better: use a grid of k x k squares with side s slightly less than 1/k,
    # so that a strip of width w = 1 - k*s is free on the right and top.
    # Place leftover squares in the free strips, axis-aligned or rotated 45 degrees for max size.

    # Let's try a simple improvement: for leftover m = n - k*k, we can try to
    # fit a few larger squares by reducing the number of grid squares.
    # For small leftover, just add tiny squares in the corner - but that gives little.
    # Instead, we can use a (k+1) grid partially filled? That gives smaller squares.

    # Alternative: use k x (k+1) grid? The number of squares would be k*(k+1) = k^2 + k.
    # If n is between k^2 and k^2 + k, we can use a k x (k+1) grid with side = 1/(k+1) 
    # but height would be k/(k+1) < 1, so we can stretch squares vertically? 
    # Actually we can use rectangles? No, must be squares.

    # Let's consider packing a k x k grid of side a and then a row/column of smaller squares.
    # Suppose we use a k x k grid of side s, and then one additional row of k squares of side t.
    # Total height: k*s + t <= 1, width: k*s <= 1.
    # We want to maximize k*k*s + k*t. 
    # If we set s = t = 1/(k+1), then height = (k+1)/(k+1)=1, width = k/(k+1).
    # We can also add one more column of k+1 squares? 
    # Actually k x (k+1) grid of side 1/(k+1) gives k*(k+1) squares, sum = k*(k+1)/(k+1)=k.
    # Compare to k^2 grid: sum = k. Same sum! Interesting.
    # For n = k^2 + m, with 0 < m < k+1, we can use k x (k+1) grid and then m extra squares.

    # Let's try a general heuristic: try all grid dimensions a x b where a*b >= n?
    # No, we need exactly n squares. 
    # We can always use size-zero for the rest.

    # For leftover m, we can take the k x k grid with side s = 1/(k+1) and then 
    # fill remaining with a (k+1) x (k+1) grid? But that gives too many squares.

    # Simpler: Use a grid of size k x k with side s slightly less than 1/k, 
    # then fit leftover squares in the free space at the right or top edge.
    # Max side for leftover when using a strip of width w = 1 - k*s along the right:
    # We can place squares of side up to w in that strip. If we place m squares in a column,
    # each can have side <= w and height m*w <= 1 => w <= 1/m. Also w <= 1/k (to not exceed).
    # To maximize total sum: k^2*s + m*w, with k*s + w <= 1? Actually if we use a strip of width w on the right,
    # then k*s + w <= 1. Also s <= 1/k (to fit in height). 
    # Total sum = k^2*s + m*w = k^2*s + m*(1 - k*s) = m + (k^2 - m*k)*s.
    # If k^2 - m*k > 0 i.e. m < k, we want s as large as possible = 1/k. Then w = 0, sum = k.
    # That's the baseline. No improvement.
    # If m > k, we want s as small as possible? But s >= w? Not necessarily.
    # Actually we need m squares in the strip. The strip height is 1, width w. 
    # To fit m squares in a column, need m*w <= 1 => w <= 1/m.
    # Also need k*s <= 1 => s <= 1/k. And k*s + w <= 1.
    # Sum = k^2*s + m*w. We want to maximize.
    # With w <= 1/m and w <= 1 - k*s, and s <= 1/k.
    # If m < k, set s=1/k, w=0, sum=k.
    # If m >= k, we can set w = 1/m, then k*s <= 1 - 1/m => s <= (1 - 1/m)/k.
    # Sum = k^2 * (1 - 1/m)/k + m * (1/m) = k*(1 - 1/m) + 1 = k - k/m + 1.
    # For m=k, sum = k - 1 + 1 = k. Same.
    # For m=k+1, sum = k - k/(k+1) + 1 = k+1 - k/(k+1) = (k+1)^2/(k+1) - k/(k+1) = (k^2+2k+1-k)/(k+1) = (k^2+k+1)/(k+1) = k + 1/(k+1)? 
    # Actually k - k/(k+1) + 1 = (k(k+1) - k + k+1)/(k+1) = (k^2+k - k + k+1)/(k+1) = (k^2+k+1)/(k+1) = k + 1/(k+1). 
    # This is > k! So improvement!

    # Let's check: k=3, n=10 (m=1): m<k, no improvement, sum=3.
    # k=3, n=12 (m=3): m=k, sum=3.
    # k=3, n=13 (m=4): m>k, sum = 3 + 1/4? Wait formula: k - k/m + 1 = 3 - 3/4 + 1 = 3.25. 
    # But can we actually fit 13 squares with sum 3.25? Let's see: k x k grid with side s, plus strip.
    # s = (1 - 1/4)/3 = 0.75/3 = 0.25. Then grid squares side 0.25, 9 of them sum 2.25.
    # Strip width w = 1/m = 0.25. Place 4 squares of side 0.25 in a column: 4*0.25 = 1.0 height. Sum = 4*0.25 = 1.0.
    # Total = 2.25 + 1.0 = 3.25. 
    # But wait, the grid squares are 3x3 of side 0.25, so they occupy 0.75 x 0.75. 
    # The strip is 0.25 wide, 1 tall. We can fit 4 squares of side 0.25 in a column. 
    # But these 4 squares in the strip have side 0.25, and the grid squares have side 0.25.
    # Are they disjoint? The grid occupies x in [0,0.75], y in [0,0.75]. 
    # The strip is x in [0.75,1.0], y in [0,1.0]. They touch at x=0.75 but don't overlap.
    # So total 13 squares, sum = 9*0.25 + 4*0.25 = 13*0.25 = 3.25. 
    # But wait, we could also use 3x3 grid of side 0.25 and then 4 squares of side 0.25 in strip. 
    # But actually we could just use a 3x4 grid? No, 3x4=12, not 13. 
    # But we can use a 4x4 grid minus 3 squares? No, must be exactly n.
    # This gives 3.25 > 3.0 baseline (which would be 3x3 grid of side 1/3=0.333, sum=3).
    # So improvement!

    # So general strategy: for given n, find k = floor(sqrt(n)), m = n - k*k.
    # If m < k: use k x k grid of side 1/k, plus m zero squares. Sum = k.
    # If m >= k: use k x k grid of side s = (1 - 1/m)/k, plus m squares of side w = 1/m in a strip.
    # But wait, we need m squares in the strip. They can be stacked vertically. 
    # Actually we can also place them in a grid pattern in the strip? 
    # If m is large, maybe better to use a different k. 
    # What if n is such that k^2 + m with m > k? We could also try k' = k-1? 
    # For example n=13: k=3, m=4. Using above: sum=3.25.
    # What if we use k=2 (4 squares) and rest 9 squares? 
    # 2x2 grid of side s, plus 9 squares in strip? 
    # 2x2 grid side s, strip width w = 1 - 2s. Need 9 squares of side <= w in strip, stacked: 9w <= 1 => w <= 1/9.
    # Sum = 4s + 9w = 4*(1 - w)/2 + 9w = 2 - 2w + 9w = 2 + 7w. With w=1/9, sum=2+7/9=2.777. Less than 3.25.
    # What if we use more general: a x b grid plus strip? 
    # For n=13, maybe 3x4 grid (12 squares) of side s, plus 1 square in strip. 
    # 3x4 grid: width 3s, height 4s. Plus strip on right? 3s + w <= 1. 
    # Sum = 12s + w = 12s + 1 - 3s = 1 + 9s. Maximize s: s <= 1/4 (height). Also 3s <= 1 => s <= 1/3. 
    # s=1/4: sum = 1 + 9/4 = 3.25. Same.
    # Actually 3x4 grid of side 1/4 gives 12 squares sum 3.0. Plus one square of side 1/4 in remaining width 1/4? 
    # Remaining width = 1 - 3/4 = 1/4, height = 1. One square of side 1/4. Sum = 3.0 + 0.25 = 3.25.

    # So for m >= k, using k x k grid + strip of m squares works.
    # But what if m is very large, close to 2k? 
    # For example n = k^2 + 2k = (k+1)^2 - 1. Then m = 2k. 
    # Our formula: s = (1 - 1/(2k))/k, w = 1/(2k). Sum = k^2*s + 2k*w = k^2*(1 - 1/(2k))/k + 1 = k - 1/2 + 1 = k + 1/2.
    # But (k+1)^2 - 1 squares: can we do better? 
    # Use (k+1) x (k+1) grid minus one? No, must be exactly n. 
    # But we could use (k+1) x (k+1) grid with one zero square? That would give sum = (k+1)^2 * (1/(k+1)) = k+1, minus 0 for the zero. 
    # Wait, if we use (k+1) x (k+1) grid, that's (k+1)^2 squares. We have n = (k+1)^2 - 1. 
    # We can set one of them to size 0. Then sum = (k+1)^2 * (1/(k+1)) - 1/(k+1) = (k+1) - 1/(k+1) = k + 1 - 1/(k+1).
    # For k=3, n=15: (4x4 grid minus 1) sum = 4 - 1/4 = 3.75. Our strip method: 3 + 1/2 = 3.5. So 4x4 minus 1 is better!
    # So we should also consider using (k+1) x (k+1) grid with some zero squares if n is close to (k+1)^2.

    # So general: compare options:
    # Option A: k x k grid (k = floor(sqrt(n))), plus leftover m = n - k^2.
    #   If m < k: sum = k (plus zeros).
    #   If m >= k: sum = k - k/m + 1 (from strip formula).
    # Option B: (k+1) x (k+1) grid, with (k+1)^2 - n zero squares.
    #   Sum = n * (1/(k+1)) if we set all non-zero to side 1/(k+1)? 
    #   Wait, we can set all (k+1)^2 squares to side 1/(k+1) but then (k+1)^2 - n of them have side 0. 
    #   Actually we can just use n squares of side 1/(k+1)? No, we need to place them. 
    #   We can use a (k+1) x (k+1) grid of side 1/(k+1) and set some to zero. 
    #   Sum = n * (1/(k+1)).
    # Option C: Maybe more general grids like a x b with a*b >= n.

    # Let's test n=15: k=3, m=6. Option A: m>=k, sum = 3 - 3/6 + 1 = 3.5. Option B: 4x4 grid, sum = 15/4 = 3.75. Better.
    # n=14: k=3, m=5. Option A: 3 - 3/5 + 1 = 3.4. Option B: 14/4 = 3.5. Better.
    # n=13: Option A: 3 - 3/4 + 1 = 3.25. Option B: 13/4 = 3.25. Same.
    # n=12: k=3, m=3. Option A: m=k, sum=3. Option B: 12/4 = 3. Same.
    # n=11: k=3, m=2. Option A: 3. Option B: 11/4 = 2.75. A better.
    # So Option B is better when n is close to (k+1)^2.

    # But we can also consider a x b grids more generally.
    # For given n, we can try all a, b such that a*b >= n, and use a grid of a x b with side 1/max(a,b)? 
    # Actually if we use a grid of a columns and b rows, we can set side s = min(1/a, 1/b) to fit. 
    # Then we have a*b squares, but we only need n. We can set a*b - n to zero. 
    # Sum = n * s. To maximize s, we want to minimize max(a,b) subject to a*b >= n.
    # The minimum possible max(a,b) is ceil(sqrt(n)). 
    # So the best grid-based approach is to take a = b = ceil(sqrt(n))? 
    # Wait, if n=15, ceil(sqrt(15))=4, a=b=4, s=1/4, sum = 15/4 = 3.75. 
    # If n=13, ceil(sqrt(13))=4, a=b=4, s=1/4, sum = 13/4 = 3.25. Same as Option A.
    # If n=10, ceil(sqrt(10))=4, a=b=4, s=1/4, sum = 10/4 = 2.5. But Option A for k=3: m=1<k, sum=3. So A better.
    # So the best grid-based is: use a = b = ceil(sqrt(n)) if n is large relative to k^2? 
    # Actually we should just compare: use floor(sqrt(n)) grid with strip, or ceil(sqrt(n)) grid with zeros.
    # Also maybe other a,b like a=4,b=5 for n=20? ceil(sqrt(20))=5, so 5x5 grid sum=20/5=4. 
    # But 4x5 grid: max=5, s=1/5, sum=20/5=4. Same.
    # For n=17: floor sqrt=4, ceil=5. Option A: k=4, m=1<k, sum=4. Option B: 5x5, sum=17/5=3.4. A better.
    # For n=21: floor=4, m=5>=k. Option A: 4 - 4/5 + 1 = 4.2. Option B: 5x5, sum=21/5=4.2. Same.
    # For n=22: A: 4 - 4/6 + 1 = 4.333. B: 22/5=4.4. B slightly better.
    # For n=23: A: 4 - 4/7 + 1 = 4.428. B: 23/5=4.6. B better.
    # For n=24: A: 4 - 4/8 + 1 = 4.5. B: 24/5=4.8. B better.
    # For n=25: A: 5x5, sum=5. B: same.
    # So generally, for n between k^2 and (k+1)^2, we should compare:
    # - Option A: k x k grid + strip (if m >= k) or just k (if m < k)
    # - Option B: (k+1) x (k+1) grid with zeros, sum = n/(k+1)
    # - Also consider k x (k+1) grid? That has k*(k+1) squares. If n <= k*(k+1), we can use side 1/(k+1) and set some to zero. Sum = n/(k+1). Same as B.
    # - Also consider (k+1) x k grid, same.
    # - Maybe even better: use a k x k grid with side s and a strip of width w on both sides? But we only have one strip in our formula.

    # Actually we can also consider using a (k+1) x (k+1) grid but with different sizes for some squares? 
    # But for simplicity, let's just implement the two options and pick the best.

    # Wait, we can also consider other configurations: e.g., for n=15, maybe 3x5 grid? 
    # 3x5 = 15 squares. Side s = min(1/3, 1/5) = 1/5 = 0.2. Sum = 15*0.2 = 3.0. Less than 3.75.
    # 4x4 grid with zeros gives 3.75.
    # What about a 4x4 grid but with some squares larger? Not trivial.

    # Given time constraints, let's implement:
    # 1. Compute k = isqrt(n).
    # 2. Option A: if n == k*k, use k x k grid side 1/k, sum = k.
    #    else m = n - k*k:
    #      if m < k: use k x k grid side 1/k, plus m zero squares. sum = k.
    #      else: use k x k grid side s = (1 - 1/m)/k, plus m squares of side w = 1/m in a strip on the right.
    #      Sum_A = k*k*s + m*w.
    # 3. Option B: use a = b = k+1 (if k+1 >= 1), grid of side 1/(k+1), set (k+1)^2 - n to zero.
    #    Sum_B = n / (k+1).
    # 4. Also try Option C: use a x b grid with a,b close to sqrt(n) but allowing a*b >= n, 
    #    side = 1/max(a,b), sum = n/max(a,b). Best when max(a,b) is minimized. 
    #    The minimum max(a,b) for a*b >= n is ceil(sqrt(n)) (achieved by a=b=ceil(sqrt(n)) or a=ceil(sqrt(n)), b=ceil(n/a)). 
    #    So Option C is same as B with k+1 = ceil(sqrt(n)). 
    #    Wait, ceil(sqrt(n)) could be k+1 or larger. For n=10, ceil(sqrt(10))=4=k+1. For n=17, ceil(sqrt(17))=5=k+1. 
    #    In general ceil(sqrt(n)) = k+1 if n > k^2, else k. So Option B is exactly the best grid with a*b >= n.
    # 5. Compare Sum_A and Sum_B, pick the better.
    # 6. Construct the squares accordingly.

    # But we can also improve Option A by using a strip on top or right, or even multiple strips.
    # For simplicity, let's just use the right strip.

    # Also, we can try to improve by allowing the strip squares to be rotated? 
    # Rotated squares in a strip of width w can have side up to w*sqrt(2)? 
    # Actually a square rotated 45 degrees has bounding box side s*sqrt(2). 
    # In a strip of width w, the maximum side of a rotated square (angle 45) is w/ (cos45+sin45)? 
    # The bounding box width of a square of side s rotated by angle theta is s*(|cos theta|+|sin theta|). 
    # For theta=45, width = s*sqrt(2). So s <= w/sqrt(2). That's smaller than w. 
    # So rotation doesn't help for fitting in a strip. 
    # But rotation might help for packing in 2D more generally, but for our simple strip it doesn't.

    # However, we can also place the leftover squares in the strip arranged in a grid pattern? 
    # If we have m squares in a strip of width w, height 1, we can place them in a column (m squares stacked) 
    # requiring m*w <= 1 => w <= 1/m. Or we can place them in multiple columns? 
    # If we place them in c columns, each column has ceil(m/c) squares. 
    # Then width needed = c*w <= ? But the strip is only width w. 
    # Actually the strip is of width w, so we can only have one column if w is small. 
    # If we want multiple columns, we need wider strip, which means smaller s for the main grid.
    # Let's not overcomplicate.

    # Let's also consider using a grid of k x (k+1) with side 1/(k+1) and then filling the remaining space? 
    # For n = k*(k+1) + m, with m < k+1, we could use k x (k+1) grid side 1/(k+1) (sum = k) and then m squares in the remaining strip of height 1 - k/(k+1) = 1/(k+1). 
    # Wait, k x (k+1) grid: if we use k columns and k+1 rows, height = (k+1)*s, width = k*s. 
    # To fit in unit square, need (k+1)*s <= 1 => s <= 1/(k+1) and k*s <= 1 => s <= 1/k. 
    # So s = 1/(k+1). Then width = k/(k+1), height = 1. So there is a strip of width 1 - k/(k+1) = 1/(k+1) on the right. 
    # We can place m squares in that strip, each of side up to 1/(k+1)? 
    # But the strip width is 1/(k+1), so we can place squares of side 1/(k+1) stacked? 
    # If m <= k+1, we can stack m squares of side 1/(k+1) in the strip (height m/(k+1) <= 1). 
    # Sum = k*(k+1)*s + m*s = (k*(k+1) + m)*s = n/(k+1). 
    # This is exactly Option B! Because we can just use a (k+1) x (k+1) grid and set some to zero.
    # Actually if n = k*(k+1) + m, with m <= k+1, then n/(k+1) = k + m/(k+1). 
    # For n=15, k=3: 3*4 = 12, m=3. n/4 = 3.75. Yes.

    # So Option B covers this.

    # Now, what about using k x k grid + strip where m > k? We got Sum_A = k - k/m + 1.
    # Is there a better arrangement for m > k? 
    # Maybe use k x k grid with side s and two strips (right and top)? 
    # But that would require reducing s more. 
    # For example n=15, k=3, m=6. Sum_A = 3 - 3/6 + 1 = 3.5. Option B = 3.75. 
    # So B is better.

    # For n=22, k=4, m=6. Sum_A = 4 - 4/6 + 1 = 4.333. Option B = 22/5 = 4.4. B better.
    # For n=26, k=5, m=1. Sum_A = 5. Option B = 26/6 ≈ 4.333. A better.
    # For n=30, k=5, m=5. Sum_A = 5 - 5/5 + 1 = 5. Option B = 30/6 = 5. Same.
    # For n=31, k=5, m=6. Sum_A = 5 - 5/6 + 1 = 5.1667. Option B = 31/6 ≈ 5.1667. Same.
    # For n=32, k=5, m=7. Sum_A = 5 - 5/7 + 1 = 5.2857. Option B = 32/6 ≈ 5.3333. B better.
    # It seems Option B is better when n > k^2 + k? 
    # Let's check: Sum_A = k + 1 - k/m. Sum_B = n/(k+1) = (k^2 + m)/(k+1).
    # Compare: k + 1 - k/m vs (k^2 + m)/(k+1).
    # Multiply by m(k+1): 
    # (k+1)m(k+1-k/m) = (k+1)(m(k+1) - k) = (k+1)(m(k+1) - k)
    # vs m(k^2 + m)
    # Difference: 
    # LHS = (k+1)^2 m - k(k+1)
    # RHS = m k^2 + m^2
    # LHS - RHS = m[(k+1)^2 - k^2] - k(k+1) - m^2 = m(2k+1) - k(k+1) - m^2.
    # This is a quadratic in m: -m^2 + (2k+1)m - k(k+1).
    # Roots: m = [(2k+1) ± sqrt((2k+1)^2 - 4k(k+1))]/2 = [(2k+1) ± sqrt(4k^2+4k+1 - 4k^2-4k)]/2 = [(2k+1) ± 1]/2.
    # Roots: m = k or m = k+1.
    # So LHS - RHS > 0 when m is between k and k+1? Actually since it's a downward parabola, it's positive between roots.
    # But m is integer, so only m=k+1 gives positive? Let's test m=k+1: 
    # LHS = (k+1)^2(k+1) - k(k+1) = (k+1)[(k+1)^2 - k] = (k+1)(k^2+2k+1-k) = (k+1)(k^2+k+1).
    # RHS = (k+1)k^2 + (k+1)^2 = k^3 + k^2 + k^2 + 2k + 1 = k^3 + 2k^2 + 2k + 1.
    # LHS = k^3 + k^2 + k + k^2 + k + 1 = k^3 + 2k^2 + 2k + 1. Same! So equality at m=k+1?
    # Wait, our formula gave root at m=k+1, so LHS-RHS=0 at m=k+1. So Sum_A = Sum_B at m=k+1.
    # For m > k+1, LHS-RHS < 0, so Sum_A < Sum_B. 
    # For m < k, we already had Sum_A = k (since w=0). Sum_B = (k^2+m)/(k+1) = k + (m-k)/(k+1). Since m<k, this is less than k. So A better.
    # For m = k, Sum_A = k - k/k + 1 = k. Sum_B = (k^2+k)/(k+1) = k. Same.
    # So the comparison is:
    # - If m <= k: Sum_A >= Sum_B (A better or equal).
    # - If m = k+1: Sum_A = Sum_B.
    # - If m > k+1: Sum_B > Sum_A.
    # Actually we need to check m between k+1 and 2k+1? Since n < (k+1)^2, m < 2k+1. 
    # So for m >= k+2, B is better. For m <= k, A is better. For m = k+1, tie.

    # So optimal grid-based strategy:
    # - If m <= k: use k x k grid side 1/k, sum = k.
    # - If m >= k+1: use (k+1) x (k+1) grid side 1/(k+1) with zeros, sum = n/(k+1).
    # (For m = k+1, either is fine; we'll use B for simplicity.)

    # Wait, but we can also consider using k x k grid with side s < 1/k and then place m squares in a strip of width w, 
    # where m squares are placed in a column. But what if we place them in multiple columns? 
    # For m > k+1, we could use a strip of width w and place m squares in a grid of c columns and r rows. 
    # But the strip width is w, so we can only have one column if we want squares of side w. 
    # If we want multiple columns, each column has width w, so total width c*w. 
    # But the strip width is w, so c=1. So only one column. 
    # So for m > k+1, it's better to just use (k+1) x (k+1) grid with zeros.

    # However, we can also consider using k x k grid with side s and placing m squares in a strip on the right AND top? 
    # But that would require reducing s more. Let's not.

    # Let's also consider if we can use a grid of a x b with a,b not both k or k+1. 
    # For example n=15, we could use 4x4 grid (sum=3.75) or 3x5 grid (sum=3.0) or 5x3 grid (sum=3.0). 
    # 4x4 is best. 
    # In general, for n, the best grid is with a=b=ceil(sqrt(n)) if n is large enough, or a=b=floor(sqrt(n)) with strip if n is small.
    # Our comparison covers this.

    # So let's implement this simple strategy:
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 1.0)]
    m = n - k*k
    if m <= k:
        # Use k x k grid of side 1/k, plus m zero squares
        s = 1.0 / k
        squares = []
        for i in range(k):
            for j in range(k):
                squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        # add m zero squares
        squares += [(0.5, 0.5, 0.0, 0.0)] * m
        return squares[:n]
    else:
        # Use (k+1) x (k+1) grid of side 1/(k+1), with (k+1)^2 - n zero squares
        kk = k + 1
        s = 1.0 / kk
        squares = []
        count = 0
        for i in range(kk):
            for j in range(kk):
                if count < n:
                    squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                    count += 1
                else:
                    squares.append((0.5, 0.5, 0.0, 0.0))
        return squares[:n]

# But wait, we can do better: for m between k+1 and 2k, maybe use k x k grid + strip with m squares in strip 
# but we can also use (k+1) x (k+1) grid with zeros. We already compared and B is better for m > k+1.
# However, we can also consider using a k x (k+1) grid with side 1/(k+1) and then m' = n - k*(k+1) squares in the remaining strip.
# For n = k*(k+1) + m', with m' <= k+1, this gives sum = n/(k+1). Same as B.
# So no improvement.

# Let's test n=13: k=3, m=4. m > k (4>3), m >= k+1? 4 = k+1. So we use B: kk=4, s=1/4, sum = 13/4 = 3.25.
# But Option A gave 3.25. Same.
# n=15: k=3, m=6 > k+1=4. Use B: kk=4, sum=15/4=3.75.
# n=10: k=3, m=1 <= k. Use A: sum=3.
# n=11: k=3, m=2 <= k. Use A: sum=3.
# n=12: k=3, m=3 <= k. Use A: sum=3.
# n=17: k=4, m=1 <= k. Use A: sum=4.
# n=18: k=4, m=2 <= k. Use A: sum=4.
# n=19: k=4, m=3 <= k. Use A: sum=4.
# n=20: k=4, m=4 <= k. Use A: sum=4.
# n=21: k=4, m=5 > k+1? 5 > 5? No, k+1=5, m=5. Our rule: if m <= k use A, else if m >= k+1 use B. So m=5 >= 5, use B: kk=5, sum=21/5=4.2. 
# But Option A for m=5: s = (1 - 1/5)/4 = 0.8/4 = 0.2, sum = 16*0.2 + 5*0.2 = 21*0.2 = 4.2. Same.
# n=22: k=4, m=6 >= 5. Use B: sum=22/5=4.4. Option A: s=(1-1/6)/4=5/24≈0.2083, sum=16*5/24 + 6*1/6 = 80/24 + 1 = 3.333+1=4.333. B better.
# n=24: k=4, m=8 >= 5. B: 24/5=4.8. A: s=(1-1/8)/4=7/32=0.21875, sum=16*7/32+8*1/8=112/32+1=3.5+1=4.5. B better.
# n=25: k=5, m=0. A: sum=5. B: kk=6? But n=25, k=5, m=0. Our rule: m <= k, use A. sum=5. 
# What if we used B for n=25? kk=6, sum=25/6≈4.167. A better.

# So our simple strategy seems good for grid-based.

# But wait, we can also consider improving by using non-grid arrangements, e.g., for n=5, the optimal is known to be about 2.414 (5 squares: one large and 4 small in corners?). 
# Actually for n=5, the best known sum is ~2.414? Let's think: a square of side 1/2 in one corner, and 4 squares of side 1/4 in the remaining space? 
# Sum = 0.5 + 4*0.25 = 1.5. But we can do better: maybe a central square rotated 45 degrees? 
# The baseline for n=5: k=2, m=1. A: 2x2 grid side 1/2, sum=2. B: 3x3 grid, sum=5/3≈1.667. So A gives 2.0.
# But can we do better? Known packing of 5 squares: the max sum is about 2.207? Actually I recall that for n=5, the optimal sum is 1 + sqrt(2)/2 ≈ 1.707? No.
# Let's not worry about exact optimal; our grid-based method is simple and probably gives decent scores.

# However, the problem says "maximise the sum of side lengths" and we are scored against a reference value. 
# The reference might be the best known, so we should try to improve beyond simple grids.

# Given time, let's implement a local search improvement: 
# After constructing the grid-based solution, we can try to adjust sizes and positions slightly to increase sum.
# But that's complex and might violate disjointness.

# Alternative: for small n, we can use known better packings by trying random configurations and local optimization.
# But the problem says runs are limited to 60 seconds per n, so we can afford some computation for small n.

# Let's implement a simple randomized local search for n <= 20 or so, and grid-based for larger n.
# For larger n, the grid is near optimal.

# Actually, let's just use the grid-based strategy and maybe a small improvement for n where m is between 1 and k: 
# we could try to use a k x (k+1) grid with side 1/(k+1) and then fill the rest? 
# For n=5, k=2, m=1. A: 2x2 grid side 1/2, sum=2. 
# Could we do better? Let's try 3x3 grid side 1/3, sum=5/3≈1.667. No.
# What about a 2x2 grid with side s and one square in the corner? 
# If we reduce s to 0.45, we have a strip of width 0.1 on right and top. 
# Place one square of side 0.1 in the corner. Sum = 4*0.45 + 0.1 = 1.9. Less than 2.
# So 2 is good.

# For n=6, k=2, m=2. A: sum=2. Could we do better? 
# Maybe 3x3 grid with side 1/3, sum=6/3=2. Same.
# For n=7, k=2, m=3. A: sum=2. B: 3x3, sum=7/3≈2.333. B better.
# For n=8, k=2, m=4. B: 8/3≈2.667. A: s=(1-1/4)/2=0.375, sum=4*0.375+4*0.25=1.5+1=2.5. B better.
# For n=9, k=3, m=0. A: sum=3.
# For n=10, k=3, m=1. A: sum=3.
# So our strategy is fine.

# Let's just go with the simple grid-based strategy. It's fast and likely near-optimal for large n.

# But wait, we can also consider using a grid with different number of rows and columns to better fit n.
# For n=7, k=2, m=3. Our rule: m > k (3>2), m >= k+1 (3>=3), so use B: kk=3, sum=7/3≈2.333.
# But what about a 2x3 grid? That's 6 squares, plus one in strip? 
# 2x3 grid side 1/3: width 2/3, height 1. Remaining width 1/3. Place one square of side 1/3. 
# Total 7 squares, sum = 6*(1/3) + 1/3 = 7/3≈2.333. Same.
# So B is good.

# For n=11, k=3, m=2. A: sum=3. B: 11/4=2.75. A better.
# For n=12, k=3, m=3. A: sum=3. B: 12/4=3. Same.
# For n=13, k=3, m=4. A: 3.25. B: 13/4=3.25. Same.
# For n=14, k=3, m=5. A: 3.4. B: 14/4=3.5. B better.
# So our rule: if m <= k use A, else use B. 
# For m=k+1, both give same? For n=13, m=4=k+1, A gives 3.25, B gives 3.25. 
# Our rule says m <= k use A, else use B. So for m=k+1 we use B. That's fine.

# Let's implement this.

# But wait, we can do even better for m=k+1 by using A? Same. So no issue.

# Let's write the function.

def solve(n):
    if n <= 0:
        return []
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 1.0)]
    m = n - k*k
    if m <= k:
        # Option A: k x k grid of side 1/k
        s = 1.0 / k
        squares = []
        for i in range(k):
            for j in range(k):
                squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
        # add m zero squares
        for _ in range(m):
            squares.append((0.5, 0.5, 0.0, 0.0))
        return squares[:n]
    else:
        # Option B: (k+1) x (k+1) grid of side 1/(k+1), with (kk^2 - n) zeros
        kk = k + 1
        s = 1.0 / kk
        squares = []
        count = 0
        for i in range(kk):
            for j in range(kk):
                if count < n:
                    squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
                    count += 1
                else:
                    squares.append((0.5, 0.5, 0.0, 0.0))
        return squares[:n]
