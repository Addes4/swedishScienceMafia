import math, random, time
from typing import List, Tuple

# ------------------------------------------------------------
# Basic geometry: an axis-aligned bounding square for a rotated
# square, and a separating-axis overlap test for two squares.
# ------------------------------------------------------------

def _corners(cx: float, cy: float, ang: float, s: float):
    """Return the four corners of a square (centre cx,cy, angle fraction of turn, side s)."""
    a = ang * 2.0 * math.pi
    c, sn = math.cos(a), math.sin(a)
    h = s * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + x * c - y * sn, cy + x * sn + y * c))
    return out


def _bbox(cx, cy, ang, s):
    a = ang * 2.0 * math.pi
    c, sn = abs(math.cos(a)), abs(math.sin(a))
    half = s * 0.5 * (c + sn)
    return (cx - half, cy - half, cx + half, cy + half)


def _overlap(c1, c2):
    """SAT for two convex polygons (lists of points). True if interiors overlap."""
    # quick bbox reject
    xs1 = [p[0] for p in c1]; ys1 = [p[1] for p in c1]
    xs2 = [p[0] for p in c2]; ys2 = [p[1] for p in c2]
    if max(xs1) <= min(xs2) or max(xs2) <= min(xs1):
        return False
    if max(ys1) <= min(ys2) or max(ys2) <= min(ys1):
        return False
    for poly in (c1, c2):
        n = len(poly)
        for i in range(n):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % n]
            ex, ey = x2 - x1, y2 - y1
            # normal
            nx, ny = -ey, ex
            p1 = [ (p[0]-x1)*nx + (p[1]-y1)*ny for p in c1 ]
            p2 = [ (p[0]-x1)*nx + (p[1]-y1)*ny for p in c2 ]
            if max(p1) <= min(p2) or max(p2) <= min(p1):
                return False
    return True


def _inside_unit(cx, cy, ang, s):
    """Check all four corners inside [0,1]^2."""
    if s == 0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    for x, y in _corners(cx, cy, ang, s):
        if x < -1e-12 or x > 1.0 + 1e-12 or y < -1e-12 or y > 1.0 + 1e-12:
            return False
    return True


# ------------------------------------------------------------
# Exact / heuristic constructive packings
# ------------------------------------------------------------

def _grid_pack(n):
    """k x k grid, then leftover as tiny squares in the last cell if any.
    Returns list of (cx,cy,ang,side)."""
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    s = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * s, (j + 0.5) * s, 0.0, s))
    extra = n - k * k
    if extra > 0:
        # put extras as small squares in top-left cell, shrinking them
        # find cell (0, k-1)
        base_cx = 0.5 * s
        base_cy = (k - 0.5) * s
        # remove the last grid square to make room
        squares.pop()
        # tile the last cell with 1 + extra squares: one large + small
        # simple: split cell into vertical strips
        m = extra + 1
        w = s
        h = s
        # arrange m squares in a row inside cell with side = h/m if h/m <= w
        ss = min(w, h / m)
        # if ss too small, put them in a k+1-th row? keep simple: just use ss
        for idx in range(m):
            cx = base_cx + w * 0.5  # centre x of cell
            cy = base_cy - h * 0.5 + (idx + 0.5) * (h / m)
            squares.append((cx, cy, 0.0, ss))
        # total count k*k -1 + m = k*k + extra = n
    return squares[:n]


def _row_pack(n):
    """Try packings: split n into a rows and b columns with rectangles."""
    best = None
    best_val = -1.0
    # try all a,b with a*b >= n
    for a in range(1, n + 1):
        b = (n + a - 1) // a
        if a * b > n * 2:
            continue
        # rows of height 1/a; each row can hold b squares of side min(1/a, 1/b)
        # more precisely: each row independently, the max sum per row
        # If we place m squares in a row of height h, max sum = min(1, m*h) if
        # axis aligned, because widths add up and all same side min(h,1/m)
        # Better: place m squares side = min(h, 1/m) -> sum = m*min(h,1/m)
        def rowsum(m, h):
            if m <= 0:
                return 0.0
            s = min(h, 1.0 / m)
            return m * s
        # distribute n among a rows
        base = n // a
        rem = n % a
        total = 0.0
        h = 1.0 / a
        for r in range(a):
            m = base + (1 if r < rem else 0)
            total += rowsum(m, h)
        if total > best_val:
            best_val = total
            best = (a, b)
    if best is None:
        best = (n, 1)
    a = best[0]
    h = 1.0 / a
    base = n // a
    rem = n % a
    squares = []
    y = h * 0.5
    for r in range(a):
        m = base + (1 if r < rem else 0)
        if m == 0:
            y += h
            continue
        s = min(h, 1.0 / m)
        # centre horizontally
        total_w = m * s
        start = (1.0 - total_w) * 0.5
        for j in range(m):
            cx = start + (j + 0.5) * s
            squares.append((cx, y, 0.0, s))
        y += h
    return squares


def _simple_constructions(n):
    """Return a few candidate packings."""
    cands = []
    cands.append(_grid_pack(n))
    cands.append(_row_pack(n))
    # k x k grid plus one extra on the side? simple variant
    return cands


# ------------------------------------------------------------
# Greedy random restart + refinement
# ------------------------------------------------------------

def _score(sq):
    return sum(s[3] for s in sq)


def _check_all(sq, tol=1e-9):
    """Return True if all valid and inside."""
    n = len(sq)
    polys = []
    for (cx, cy, ang, s) in sq:
        if s < 0:
            return False
        if not _inside_unit(cx, cy, ang, s):
            return False
        polys.append(_corners(cx, cy, ang, s))
    for i in range(n):
        if sq[i][3] == 0:
            continue
        for j in range(i + 1, n):
            if sq[j][3] == 0:
                continue
            if _overlap(polys[i], polys[j]):
                # slight tolerance: allow touching
                # re-check with shrunk squares
                si = sq[i]; sj = sq[j]
                pi = _corners(si[0], si[1], si[2], si[3] * 0.999)
                pj = _corners(sj[0], sj[1], sj[2], sj[3] * 0.999)
                if _overlap(pi, pj):
                    return False
    return True


def _refine(sq, time_limit=1.0):
    """Local search: try small perturbations of cx,cy,angle,side."""
    n = len(sq)
    t0 = time.time()
    cur = [list(s) for s in sq]
    cur_score = _score(cur)
    steps = [0.02, 0.01, 0.005, 0.002, 0.001, 0.0005, 0.0002, 0.0001]
    improved = True
    while improved and time.time() - t0 < time_limit:
        improved = False
        for i in range(n):
            if time.time() - t0 >= time_limit:
                break
            old = cur[i][:]
            for step in steps:
                if time.time() - t0 >= time_limit:
                    break
                # try increasing side
                for (dcx, dcy, dang, dside) in [
                    (0, 0, 0, step),
                    (step, 0, 0, 0),
                    (-step, 0, 0, 0),
                    (0, step, 0, 0),
                    (0, -step, 0, 0),
                ]:
                    cand = [old[0] + dcx, old[1] + dcy, old[2] + dang, old[3] + dside]
                    if not (0 <= cand[0] <= 1 and 0 <= cand[1] <= 1 and cand[3] >= 0):
                        continue
                    cand[2] = cand[2] % 1.0
                    if not _inside_unit(cand[0], cand[1], cand[2], cand[3]):
                        continue
                    # check against all others
                    ok = True
                    for j in range(n):
                        if j == i or cur[j][3] == 0:
                            continue
                        if cand[3] == 0:
                            continue
                        c1 = _corners(cand[0], cand[1], cand[2], cand[3])
                        c2 = _corners(cur[j][0], cur[j][1], cur[j][2], cur[j][3])
                        if _overlap(c1, c2):
                            ok = False
                            break
                    if ok:
                        old = cand
                        improved = True
            cur[i] = old
        cur_score = _score(cur)
    return [tuple(x) for x in cur]


# ------------------------------------------------------------
# Special known good patterns
# ------------------------------------------------------------

def _known_pattern(n):
    """Some particular n have nice patterns."""
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # two small on top, one big below? better: 3 squares in a row
        s = 1.0 / 3
        return [(s * (i + 0.5), 0.5, 0.0, s) for i in range(3)]
    if n == 4:
        s = 0.5
        return [(0.25, 0.25, 0.0, s), (0.75, 0.25, 0.0, s),
                (0.25, 0.75, 0.0, s), (0.75, 0.75, 0.0, s)]
    if n == 5:
        # 4 large + 1 small in corner
        # known: 1 square of 0.5 at bottom, 4 of ~0.5? Actually pack 5:
        # one 0.5 at bottom centre, four 0.25? Let's use:
        # 0.5, 0.5, 0.5, 0.5, 0. 25 -> sum 2.25
        # Better: 5 squares all side 0.5? not possible. Use grid 2x3 minus one:
        # sum = 4*0.5 + 1*0.333 = 2.333
        sq = [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
              (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
        # fifth in remaining? no remaining. So use 3x2 grid: 6 cells, put 5 with side 0.5?
        # not fit. Use row of 5? side 0.2 sum=1.0
        # best known for 5: 0.5,0.5,0.5,0.5,0.25? Let's just do 3 rows:
        # bottom two 0.5, top three 0.25? sum = 1 + 0.75 = 1.75. no.
        # Try: one 0.5, four 0.25? sum=1.5
        # Actually known optimal for 5 is 2.207? Let's use greedy/refine.
        return None
    return None


# ------------------------------------------------------------
# Main solver
# ------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    kp = _known_pattern(n)
    if kp is not None:
        return kp

    best = None
    best_score = -1.0

    # gather constructive candidates
    cands = _simple_constructions(n)
    for c in cands:
        if _check_all(c):
            sc = _score(c)
            if sc > best_score:
                best_score = sc
                best = c

    # also try an axis-aligned greedy: sort descending, place one by one
    def greedy_aa(n):
        sq = []
        for idx in range(n):
            # choose size that fits
            # start with large sizes and shrink
            placed = False
            for s in [0.9, 0.8, 0.7, 0.6, 0.5, 0.45, 0.4, 0.35, 0.3,
                      0.25, 0.2, 0.15, 0.12, 0.1, 0.08, 0.06, 0.05,
                      0.04, 0.03, 0.025, 0.02, 0.015, 0.01, 0.005, 0.001]:
                # try grid positions
                grid = max(1, int(1.0 / s))
                for gi in range(grid):
                    for gj in range(grid):
                        cx = (gi + 0.5) * (1.0 / grid)
                        cy = (gj + 0.5) * (1.0 / grid)
                        cand = (cx, cy, 0.0, s)
                        ok = True
                        for (ox, oy, oa, os) in sq:
                            c1 = _corners(cx, cy, 0.0, s)
                            c2 = _corners(ox, oy, oa, os)
                            if _overlap(c1, c2):
                                ok = False
                                break
                        if ok:
                            sq.append(cand)
                            placed = True
                            break
                    if placed:
                        break
                if placed:
                    break
            if not placed:
                sq.append((0.5, 0.5, 0.0, 0.0))
        return sq

    g = greedy_aa(n)
    if _check_all(g):
        sc = _score(g)
        if sc > best_score:
            best_score = sc
            best = g

    # refine the best
    if best is not None:
        refined = _refine(best, time_limit=min(2.0, 60.0 / max(1, n)))
        if _check_all(refined) and _score(refined) >= best_score - 1e-9:
            best = refined
            best_score = _score(best)

    # random restarts with greedy heuristic
    t0 = time.time()
    while time.time() - t0 < min(5.0, 60.0 / max(1, n) * 0.5):
        # random axis aligned sizes
        sq = []
        for idx in range(n):
            s = random.choice([0.1, 0.2, 0.3, 0.4, 0.5, 0.25, 0.15, 0.05, 0.02])
            # random position
            found = False
            for _ in range(200):
                cx = random.random()
                cy = random.random()
                if _inside_unit(cx, cy, 0.0, s):
                    ok = True
                    for (ox, oy, oa, os) in sq:
                        if _overlap(_corners(cx, cy, 0.0, s), _corners(ox, oy, oa, os)):
                            ok = False
                            break
                    if ok:
                        sq.append((cx, cy, 0.0, s))
                        found = True
                        break
            if not found:
                sq.append((0.5, 0.5, 0.0, 0.0))
        if _check_all(sq):
            sq = _refine(sq, time_limit=min(1.0, 60.0 / max(1, n)))
            sc = _score(sq)
            if sc > best_score:
                best_score = sc
                best = sq

    if best is None:
        # fallback
        best = _grid_pack(n)

    # ensure exactly n
    best = best[:n]
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))

    # final sanity
    if not _check_all(best):
        # fallback to grid
        best = _grid_pack(n)

    return best
