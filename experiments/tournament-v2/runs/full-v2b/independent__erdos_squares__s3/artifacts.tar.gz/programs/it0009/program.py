import math
import random
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, ang, s):
    a = 2.0 * math.pi * ang
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + p[0] * ca - p[1] * sa, cy + p[0] * sa + p[1] * ca) for p in pts]


def _overlap(c1, c2):
    # SAT for convex polygons (squares)
    for poly in (c1, c2):
        for i in range(4):
            ax, ay = poly[(i + 1) % 4][0] - poly[i][0], poly[(i + 1) % 4][1] - poly[i][1]
            n = (-ay, ax)
            mn1 = min(p[0] * n[0] + p[1] * n[1] for p in c1)
            mx1 = max(p[0] * n[0] + p[1] * n[1] for p in c1)
            mn2 = min(p[0] * n[0] + p[1] * n[1] for p in c2)
            mx2 = max(p[0] * n[0] + p[1] * n[1] for p in c2)
            if mx1 < mn2 + 1e-12 or mx2 < mn1 + 1e-12:
                return False
    return True


def _penalty(vec, n):
    v = vec.reshape(n, 4)
    sq = []
    pen = 0.0
    for i in range(n):
        cx, cy, ang, s = v[i]
        if s <= 0:
            if s < 0:
                pen += -s * 10.0
            sq.append(None)
            continue
        cs = _corners(cx, cy, ang, s)
        for p in cs:
            if p[0] < 0:
                pen += -p[0] * 10.0
            if p[0] > 1:
                pen += (p[0] - 1) * 10.0
            if p[1] < 0:
                pen += -p[1] * 10.0
            if p[1] > 1:
                pen += (p[1] - 1) * 10.0
        sq.append(cs)
    for i in range(n):
        if sq[i] is None:
            continue
        for j in range(i + 1, n):
            if sq[j] is None:
                continue
            if _overlap(sq[i], sq[j]):
                # depth estimate: min gap in SAT
                d = _overlap_depth(sq[i], sq[j])
                pen += d * 100.0
    return pen


def _overlap_depth(c1, c2):
    best = 1e9
    for poly in (c1, c2):
        for i in range(4):
            ax, ay = poly[(i + 1) % 4][0] - poly[i][0], poly[(i + 1) % 4][1] - poly[i][1]
            n = (-ay, ax)
            l = math.hypot(n[0], n[1])
            if l == 0:
                continue
            n = (n[0] / l, n[1] / l)
            mn1 = min(p[0] * n[0] + p[1] * n[1] for p in c1)
            mx1 = max(p[0] * n[0] + p[1] * n[1] for p in c1)
            mn2 = min(p[0] * n[0] + p[1] * n[1] for p in c2)
            mx2 = max(p[0] * n[0] + p[1] * n[1] for p in c2)
            ov = min(mx1, mx2) - max(mn1, mn2)
            if ov < best:
                best = ov
    return max(best, 0.0)


def _obj(vec, n, target):
    pen = _penalty(vec, n)
    v = vec.reshape(n, 4)
    s = np.maximum(v[:, 3], 0.0)
    if target is not None:
        return -(s.sum()) + 1e6 * pen + 1e3 * ((s - target) @ (s - target))
    return -(s.sum()) + 1e6 * pen


def _project(vec, n):
    v = vec.reshape(n, 4)
    v[:, 3] = np.maximum(v[:, 3], 0.0)
    v[:, 0] = np.clip(v[:, 0], 0.0, 1.0)
    v[:, 1] = np.clip(v[:, 1], 0.0, 1.0)
    v[:, 2] = np.mod(v[:, 2], 1.0)
    return v.reshape(-1)


def _feasible(v, n):
    if _penalty(v, n) > 1e-9:
        return False
    return True


def _greedy_grow(v, n, iters=4000, rng=None):
    if rng is None:
        rng = random.Random(12345)
    v = v.copy()
    best = v.copy()

    def val(x):
        p = _penalty(x, n)
        if p > 1e-9:
            return 1e9 + p * 1000
        return -np.sum(np.maximum(x.reshape(n, 4)[:, 3], 0))

    for it in range(iters):
        i = rng.randrange(n)
        cur = v.reshape(n, 4)[i].copy()
        done = False
        # try increasing side
        if cur[3] > 0:
            trial = v.copy()
            t = trial.reshape(n, 4)
            t[i, 3] = cur[3] + rng.uniform(0.0001, 0.01) * (1 + cur[3])
            t[i, 0] = np.clip(cur[0] + rng.uniform(-0.002, 0.002), 0, 1)
            t[i, 1] = np.clip(cur[1] + rng.uniform(-0.002, 0.002), 0, 1)
            t[i, 2] = (cur[2] + rng.uniform(-0.02, 0.02)) % 1.0
            if _penalty(trial, n) < 1e-9:
                if -np.sum(t[:, 3]) < val(v):
                    v = trial
                    done = True
        if not done:
            # random restart of this square small
            trial = v.copy()
            t = trial.reshape(n, 4)
            t[i, 0] = rng.random()
            t[i, 1] = rng.random()
            t[i, 2] = rng.random()
            t[i, 3] = rng.random() * 0.45
            if _penalty(trial, n) < 1e-9 and -np.sum(t[:, 3]) < val(v):
                v = trial
    return v


def _layout(n):
    # initial: grid if square, else random small
    v = np.zeros((n, 4))
    k = int(math.isqrt(n))
    if n >= 1:
        idx = 0
        for i in range(k):
            for j in range(k):
                if idx < n:
                    v[idx, 0] = (i + 0.5) / max(k, 1)
                    v[idx, 1] = (j + 0.5) / max(k, 1)
                    v[idx, 3] = 1.0 / max(k, 1) * 0.99
                    idx += 1
        while idx < n:
            v[idx, 0] = 0.5 + random.uniform(-0.3, 0.3)
            v[idx, 1] = 0.5 + random.uniform(-0.3, 0.3)
            v[idx, 2] = random.random()
            v[idx, 3] = 0.02
            idx += 1
    return v.reshape(-1)


def solve(n):
    rng = random.Random(987654321)

    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        # two small up, one large below? simple: 3 rect column? use known-ish
        s = 0.5
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    best_v = None
    best_score = -1

    # try several starts
    starts = []
    k = int(math.isqrt(n))
    base = _layout(n)
    starts.append(base)
    for _ in range(3):
        v = np.zeros((n, 4))
        for i in range(n):
            v[i, 0] = rng.random()
            v[i, 1] = rng.random()
            v[i, 2] = rng.random()
            v[i, 3] = rng.random() * 0.4
        starts.append(v.reshape(-1))

    for st in starts:
        v = st.copy()
        # ensure feasible (penalty only if overlaps)
        v = _repair(v, n)
        if v is None:
            continue
        for _ in range(6):
            v = _greedy_grow(v, n, iters=800, rng=rng)
        # polish: coordinate ascent resizing each one greedily many passes
        v = _polish(v, n)
        score = -np.sum(v.reshape(n, 4)[:, 3]) * -1  # sum
        if score > best_score:
            best_score = score
            best_v = v.copy()

    out = []
    vv = best_v.reshape(n, 4)
    for i in range(n):
        cx, cy, ang, s = vv[i]
        out.append((float(np.clip(cx, 0, 1)), float(np.clip(cy, 0, 1)), float(ang % 1.0), float(max(s, 0.0))))
    return out


def _repair(v, n, tries=200):
    v = v.copy()
    t = v.reshape(n, 4)
    t[:, 0] = np.clip(t[:, 0], 0, 1)
    t[:, 1] = np.clip(t[:, 1], 0, 1)
    t[:, 2] = np.mod(t[:, 2], 1.0)
    t[:, 3] = np.maximum(t[:, 3], 0.0)
    for _ in range(tries):
        p = _penalty(v, n)
        if p < 1e-10:
            return v
        # shrink all slightly, move apart slightly
        t = v.reshape(n, 4)
        t[:, 3] *= 0.98
        for i in range(n):
            t[i, 0] = np.clip(t[i, 0] + random.uniform(-0.01, 0.01), 0, 1)
            t[i, 1] = np.clip(t[i, 1] + random.uniform(-0.01, 0.01), 0, 1)
    if _penalty(v, n) < 1e-6:
        return v
    return None


def _polish(v, n):
    v = v.copy()
    improved = True
    rounds = 0
    while improved and rounds < 20:
        improved = False
        rounds += 1
        for i in range(n):
            cur = v.reshape(n, 4)[i].copy()
            # try to grow
            for scale in [1.5, 1.2, 1.1, 1.05, 1.02, 1.01]:
                trial = v.copy()
                t = trial.reshape(n, 4)
                ns = cur[3] * scale
                t[i, 3] = ns
                if _penalty(trial, n) < 1e-9:
                    v = trial
                    improved = True
                    break
            # try shift/rotate to make room
            cur = v.reshape(n, 4)[i].copy()
            if cur[3] > 0:
                for _ in range(30):
                    trial = v.copy()
                    t = trial.reshape(n, 4)
                    t[i, 0] = np.clip(cur[0] + random.uniform(-0.02, 0.02), 0, 1)
                    t[i, 1] = np.clip(cur[1] + random.uniform(-0.02, 0.02), 0, 1)
                    t[i, 2] = (cur[2] + random.uniform(-0.05, 0.05)) % 1.0
                    t[i, 3] = cur[3] * 1.001
                    if _penalty(trial, n) < 1e-9:
                        v = trial
                        improved = True
                        break
    return v
