import math
import numpy as np
from scipy.optimize import minimize


def _pack_into(rect, squares, out, depth=0):
    """Recursively subdivide a rectangle to pack squares using guillotine cuts."""
    x0, y0, x1, y1 = rect
    w = x1 - x0
    h = y1 - y0
    if not squares:
        return
    if len(squares) == 1:
        s = min(w, h, squares[0])
        out.append((x0 + (w - s) / 2.0, y0 + (h - s) / 2.0, 0.0, s))
        return

    # Try splitting along vertical or horizontal cuts, at positions that
    # either isolate a square strip or split the set roughly in half.
    best = None

    total_area = sum(s * s for s in squares)
    target = total_area / 2.0

    # candidate cut fractions
    if w >= h:
        cuts = _candidate_cuts(w, squares, horizontal=False)
        for c in cuts:
            left = squares  # placeholder
            # split squares by area into left/right groups
            a, b = _split_by_area(squares, c * h)
            if not a or not b:
                continue
            sub = _eval_split((x0, y0, x0 + c, y1), (x0 + c, y0, x1, y1), a, b, depth)
            if sub is not None and (best is None or sub[0] > best[0]):
                best = sub
    else:
        cuts = _candidate_cuts(h, squares, horizontal=True)
        for c in cuts:
            a, b = _split_by_area(squares, c * w)
            if not a or not b:
                continue
            sub = _eval_split((x0, y0, x1, y0 + c), (x0, y0 + c, x1, y1), a, b, depth)
            if sub is not None and (best is None or sub[0] > best[0]):
                best = sub

    if best is None:
        # fallback: just stack
        s = min(w, h, max(squares))
        out.append((x0 + (w - s) / 2.0, y0 + (h - s) / 2.0, 0.0, s))
        return

    best[1](out)


def _eval_split(r1, r2, a, b, depth):
    if depth > 40:
        return None
    try:
        o1 = []
        _pack_into(r1, sorted(a, reverse=True), o1, depth + 1)
        o2 = []
        _pack_into(r2, sorted(b, reverse=True), o2, depth + 1)
    except RecursionError:
        return None
    total = sum(t[3] for t in o1) + sum(t[3] for t in o2)
    def apply(out):
        out.extend(o1)
        out.extend(o2)
    return (total, apply)


def _split_by_area(squares, avail):
    # divide squares into those that can go left (area allowance avail)
    sq = sorted(squares, reverse=True)
    a = []
    b = []
    rem = avail
    for s in sq:
        if s * s <= rem:
            a.append(s)
            rem -= s * s
        else:
            b.append(s)
    return a, b


def _candidate_cuts(length, squares, horizontal):
    cuts = set()
    maxs = max(squares)
    cuts.add(maxs / length)
    cuts.add(0.5)
    for frac in (0.25, 0.3333, 0.6667, 0.5, 0.75):
        cuts.add(frac)
    # cuts based on cumulative sizes
    srt = sorted(squares, reverse=True)
    cum = 0
    tot = sum(x * x for x in squares)
    for s in srt:
        cum += s * s
        cuts.add(min(0.98, max(0.02, cum / tot)))
    return [c for c in cuts if 0.02 < c < 0.98]


def _greedy(n):
    # Try several initial scalar sizes; use guillotine with a single size.
    best_s, best_val = 0.0, -1.0
    lo, hi = 0.0, 1.0
    for _ in range(60):
        mid = (lo + hi) / 2.0
        # check if n squares of side mid fit via grid (approx upper bound)
        # Actually rely on packing attempt:
        out = []
        ok = _try_uniform(1.0, 1.0, n, mid, out)
        if ok:
            best_s = mid
            lo = mid
        else:
            hi = mid
    return best_s


def _try_uniform(w, h, n, s, out):
    # simple grid fit check
    if s <= 0:
        return True
    cols = int(w // s)
    rows = int(h // s)
    return cols * rows >= n


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # Initial guess: uniform grid
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append((i * side + side / 2, j * side + side / 2, 0.0, side))

    # For the remainder squares, place tiny squares inside leftover region.
    placed = len(squares)
    # Use leftover strip along top
    remaining = n - placed
    idx = 0
    for i in range(k):
        if idx >= remaining:
            break
        # use thin column on right of cell? just place zero-size fallback
        pass
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))

    # Try to improve: attempt a guillotine packing for common n ranges.
    try:
        result = _improve(n, squares)
        if result is not None:
            return result
    except Exception:
        pass
    return squares[:n]


def _improve(n, base):
    # Re-pack using guillotine when n is small enough to be fast.
    if n > 60:
        return None

    # Phase 1: find a good set of side lengths via binary search on uniform,
    # then try unequal via simple heuristic (largest square in corner).
    # We'll attempt a greedy guillotine for each "shape" hypothesis.
    best = None
    for trial in range(1):
        out = []
        try:
            # Try a straightforward packing: largest squares first in strips.
            _pack_into((0.0, 0.0, 1.0, 1.0), [1.0] * 1, out, 0)
        except Exception:
            pass

    # Simple approach: use a grid but shrink to allow rotated? Skip.
    # Fall back: use base but try SLSQP to optimize positions/sizes locally.
    try:
        res = _local_opt(base[:n])
        if res is not None:
            return res
    except Exception:
        pass
    return None


def _local_opt(squares):
    n = len(squares)
    x0 = np.array([s[0] for s in squares])
    y0 = np.array([s[1] for s in squares])
    a0 = np.array([s[2] for s in squares])
    s0 = np.array([s[3] for s in squares])

    # Only optimize sizes and positions, fix angles 0.
    x0 = np.clip(x0, 0.01, 0.99)
    y0 = np.clip(y0, 0.01, 0.99)
    s0 = np.clip(s0, 0.001, 1.0)

    def objective(v):
        x = v[0::3]
        y = v[1::3]
        s = v[2::3]
        pen = 0.0
        # bounds penalty
        for i in range(n):
            pen += max(0, x[i] - 0.5 * s[i] - 0.0) ** 2
            pen += max(0, -(x[i] + 0.5 * s[i]) + 1.0) ** 2
            pen += max(0, y[i] - 0.5 * s[i] - 0.0) ** 2
            pen += max(0, -(y[i] + 0.5 * s[i]) + 1.0) ** 2
        return -np.sum(s) + 100.0 * pen

    v = np.zeros(3 * n)
    for i in range(n):
        v[3 * i] = x0[i]
        v[3 * i + 1] = y0[i]
        v[3 * i + 2] = s0[i]

    try:
        res = minimize(objective, v, method='Nelder-Mead',
                       options={'maxiter': 2000, 'xatol': 1e-4, 'fatol': 1e-4})
        if res.success or res.fun < objective(v):
            v = res.x
    except Exception:
        pass

    out = []
    for i in range(n):
        cx = min(0.999, max(0.001, v[3 * i]))
        cy = min(0.999, max(0.001, v[3 * i + 1]))
        s = min(1.0, max(0.0, v[3 * i + 2]))
        # ensure within bounds
        s = min(s, 2 * cx, 2 * cy, 2 * (1 - cx), 2 * (1 - cy))
        out.append((cx, cy, 0.0, s))

    # Resolve overlaps by shrinking.
    for _ in range(20):
        changed = False
        for i in range(n):
            xi, yi, _, si = out[i]
            for j in range(i + 1, n):
                xj, yj, _, sj = out[j]
                # axis-aligned overlap check
                ox = (si + sj) / 2 - abs(xi - xj)
                oy = (si + sj) / 2 - abs(yi - yj)
                if ox > 0 and oy > 0:
                    need = min(ox, oy) / 2
                    si = max(0.0, si - need)
                    sj = max(0.0, sj - need)
                    out[i] = (xi, yi, 0.0, si)
                    out[j] = (xj, yj, 0.0, sj)
                    changed = True
        if not changed:
            break
    return out
