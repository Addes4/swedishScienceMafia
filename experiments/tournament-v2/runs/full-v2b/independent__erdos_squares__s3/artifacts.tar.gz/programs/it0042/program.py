# EVOLVE-BLOCK-START
import math
from typing import List, Tuple

import numpy as np
from scipy.optimize import minimize


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def corners(cx: float, cy: float, ang: float, s: float):
    """Return the 4 corners of a square with centre (cx,cy), angle in turns, side s."""
    if s <= 0.0:
        return [(cx, cy)] * 4

    t = 2.0 * math.pi * ang
    c, sn = math.cos(t), math.sin(t)
    h = 0.5 * s
    # local axes
    ux, uy = c, sn
    vx, vy = -sn, c
    return [
        (cx + h * ux + h * vx, cy + h * uy + h * vy),
        (cx + h * ux - h * vx, cy + h * uy - h * vy),
        (cx - h * ux - h * vx, cy - h * uy - h * vy),
        (cx - h * ux + h * vx, cy - h * uy + h * vy),
    ]


def inside_unit(cx: float, cy: float, ang: float, s: float, eps: float = 1e-12) -> bool:
    for x, y in corners(cx, cy, ang, s):
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def project_inside(cx: float, cy: float, ang: float, s: float):
    """Translate (and shrink slightly if needed) so the square is inside [0,1]^2."""
    if s <= 0.0:
        return min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), 0.0, 0.0

    t = 2.0 * math.pi * ang
    c, sn = math.cos(t), math.sin(t)
    h = 0.5 * s
    ux, uy = c, sn
    vx, vy = -sn, c
    xs = []
    ys = []
    for ax, ay in ((ux + vx, uy + vy), (ux - vx, uy - vy),
                   (-ux - vx, -uy - vy), (-ux + vx, -uy + vy)):
        xs.append(h * ax)
        ys.append(h * ay)
    minx, maxx = min(xs), max(xs)
    miny, maxy = min(ys), max(ys)

    # required s so that width/height fit
    width = maxx - minx
    height = maxy - miny
    s_lim = s
    if width > 1e-15:
        s_lim = min(s_lim, 1.0 / width)
    if height > 1e-15:
        s_lim = min(s_lim, 1.0 / height)
    s_lim = max(s_lim, 0.0)
    if s_lim < s:
        s = s_lim
        h = 0.5 * s
        xs = [val * (s / max(1e-30, s_lim)) for val in xs]  # not used
        # recompute
        minx, maxx = min(h * ax for ax, _ in ((ux + vx, 0), (ux - vx, 0),
                                               (-ux - vx, 0), (-ux + vx, 0))), \
                     max(h * ax for ax, _ in ((ux + vx, 0), (ux - vx, 0),
                                               (-ux - vx, 0), (-ux + vx, 0)))
        miny, maxy = min(h * ay for _, ay in ((0, uy + vy), (0, uy - vy),
                                               (0, -uy - vy), (0, -uy + vy))), \
                     max(h * ay for _, ay in ((0, uy + vy), (0, uy - vy),
                                               (0, -uy - vy), (0, -uy + vy)))

    # shift centre so bounding box fits
    tx = 0.0
    if minx + cx < 0.0:
        tx = -(minx + cx)
    elif maxx + cx > 1.0:
        tx = 1.0 - (maxx + cx)
    ty = 0.0
    if miny + cy < 0.0:
        ty = -(miny + cy)
    elif maxy + cy > 1.0:
        ty = 1.0 - (maxy + cy)
    return cx + tx, cy + ty, ang, s


def overlap_area(x1, y1, a1, s1, x2, y2, a2, s2) -> float:
    """Approximate overlap area of two centred squares via sampling / OBB SAT.

    We use a quick separating-axis test to decide non-overlap; for optimisation
    the penalty only needs a smooth-ish measure.  Here we return 0 if separated
    and a positive value otherwise.
    """
    if s1 <= 0.0 or s2 <= 0.0:
        return 0.0

    # quick SAT for OBBs
    t1 = 2.0 * math.pi * a1
    c1, sn1 = math.cos(t1), math.sin(t1)
    t2 = 2.0 * math.pi * a2
    c2, sn2 = math.cos(t2), math.sin(t2)
    axes = [(c1, sn1), (-sn1, c1), (c2, sn2), (-sn2, c2)]
    dx, dy = x2 - x1, y2 - y1

    for ax, ay in axes:
        r1 = 0.5 * s1 * (abs(ax * c1 + ay * sn1) + abs(ax * (-sn1) + ay * c1))
        r2 = 0.5 * s2 * (abs(ax * c2 + ay * sn2) + abs(ax * (-sn2) + ay * c2))
        if abs(dx * ax + dy * ay) > r1 + r2 + 1e-14:
            return 0.0
    # If no separating axis, estimate overlap by sampling a few points in sq1
    h1 = 0.5 * s1
    h2 = 0.5 * s2
    cnt = 0
    tot = 0
    for u in (-h1 * 0.8, 0.0, h1 * 0.8):
        for v in (-h1 * 0.8, 0.0, h1 * 0.8):
            px = x1 + u * c1 + v * (-sn1)
            py = y1 + u * sn1 + v * c1
            # transform to square2 local
            dxp, dyp = px - x2, py - y2
            lu = dxp * c2 + dyp * sn2
            lv = -dxp * sn2 + dyp * c2
            tot += 1
            if abs(lu) <= h2 and abs(lv) <= h2:
                cnt += 1
    if cnt == 0:
        return 0.0
    # area of intersection is positive; use small positive proxy
    return min(s1 * s1, s2 * s2) * 0.5


# ---------------------------------------------------------------------------
# Analytical initial packings
# ---------------------------------------------------------------------------

def grid_packing(n: int):
    """Largest k x k grid plus leftover as tiny squares in the remaining strip."""
    k = max(1, int(math.floor(math.sqrt(n))))
    side = 1.0 / k
    squares: List[Tuple[float, float, float, float]] = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    rem = n - k * k
    if rem > 0:
        # use a row of smaller squares in the strip at top (height = 1 - k*side)
        # or if k*k==n then just extend elsewhere
        strip_h = 1.0 - k * side
        if strip_h <= 1e-12:
            # no strip: make some squares slightly smaller to create one
            side2 = 1.0 / (k + 1)
            # replace last row with k+1 squares of side2
            squares = squares[:-(k)] if k > 1 else []
            for i in range(k + 1):
                for j in range(k - 1 if k > 1 else 0):
                    squares.append(((i + 0.5) * side2, (j + 0.5) * side2, 0.0, side2))
            for i in range(k + 1):
                if len(squares) >= n:
                    break
                squares.append(((i + 0.5) * side2, (k - 0.5) * side2, 0.0, side2))
        else:
            # rem small squares in top strip
            each = rem
            if each <= k:
                w = 1.0 / each
                h = min(strip_h, w)
                # stack as one row
                height = min(strip_h, 1.0 / each)
                width = 1.0 / each
                s = min(height, width)
                for i in range(each):
                    squares.append(((i + 0.5) * width, k * side + 0.5 * s, 0.0, s))
            else:
                # fill recursively
                sub = grid_packing(rem)
                # place in top strip, scaled
                strip_h2 = strip_h
                # scale centres into strip
                for cx, cy, a, s in sub:
                    squares.append((cx, k * side + cy * strip_h2, a, s * strip_h2))
    return squares[:n]


def strip_packing(n: int):
    """Better packing: choose number of rows r, then place n squares as evenly
    as possible with row heights chosen to maximise total side.

    For axis-aligned squares, if we use rows with counts c_i, the optimal side is
    determined by width 1/c_i and height constraints.  We use dynamic programming
    over rows.
    """
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best = None
    best_val = -1.0

    # try rows from 1 to n
    for rows in range(1, n + 1):
        # distribute n squares into rows as evenly as possible: c_i = ceil/floor
        base = n // rows
        extra = n % rows
        counts = [base + (1 if i < extra else 0) for i in range(rows)]
        if min(counts) <= 0:
            continue

        # each row i has c_i squares, natural side h_i = 1/c_i
        # vertical scale to fit total height 1: factor lam
        # The squares in a row can have side <= 1/c_i and <= available row height
        # Optimally all squares in a row have equal side s_i, and rows stack.
        # Maximise sum(c_i * s_i) s.t. sum(s_i) <= 1, s_i <= 1/c_i.
        # This is a fractional assignment: give height first to rows with largest c_i?
        # Actually objective coefficient c_i, so allocate height to rows with largest c_i.
        idx = sorted(range(rows), key=lambda i: -counts[i])
        remaining = 1.0
        s = [0.0] * rows
        for i in idx:
            cap = 1.0 / counts[i]
            take = min(cap, remaining)
            s[i] = take
            remaining -= take
            if remaining <= 1e-15:
                break
        val = sum(counts[i] * s[i] for i in range(rows))
        if val > best_val + 1e-12:
            best_val = val
            best = (counts, s)

    if best is None:
        return [(0.5, 0.5, 0.0, 0.0)] * n

    counts, sizes = best
    squares = []
    y = 0.0
    for i, c in enumerate(counts):
        s = sizes[i]
        if s <= 1e-15:
            # put zero-size squares
            for j in range(c):
                if len(squares) >= n:
                    break
                squares.append((0.5, 0.5, 0.0, 0.0))
        else:
            w = 1.0 / c
            # centre the row horizontally if w*c < 1 (should be exact)
            for j in range(c):
                if len(squares) >= n:
                    break
                cx = (j + 0.5) * w
                cy = y + 0.5 * s
                squares.append((cx, cy, 0.0, s))
        y += s

    return squares[:n]


def mixed_packing(n: int):
    """Try several heuristics and pick best by total side."""
    candidates = []
    candidates.append(grid_packing(n))
    candidates.append(strip_packing(n))
    # A rotated variant: rotate some squares 45 degrees? For now just axis aligned.
    best = max(candidates, key=lambda sq: sum(s for _, _, _, s in sq))
    return best


# ---------------------------------------------------------------------------
# Numerical refinement
# ---------------------------------------------------------------------------

def vector_to_squares(v: np.ndarray, n: int):
    arr = v.reshape((n, 4))
    return [(float(arr[i, 0]), float(arr[i, 1]), float(arr[i, 2] % 1.0), float(arr[i, 3]))
            for i in range(n)]


def objective_and_grad(v: np.ndarray, n: int):
    """Negative total side, with penalty for out-of-bounds and overlaps.

    We use a finite-difference-free approach by returning scalar only; scipy's
    L-BFGS-B can handle vector objective without gradient, but here we return
    scalar for Nelder-Mead or Powell.  We'll use a custom penalty.
    """
    arr = v.reshape((n, 4))
    total = 0.0
    penalty = 0.0

    # bounds penalty
    for i in range(n):
        cx, cy, ang, s = arr[i]
        if s < 0:
            penalty += 1e3 * (-s) ** 2 + 1e3 * (-s)
            s = 0.0
        # inside check (approximate via bounding box)
        t = 2.0 * math.pi * ang
        c, sn = math.cos(t), math.sin(t)
        h = 0.5 * s
        corners_x = [h * (c + (-sn)), h * (c - (-sn)), h * (-c - (-sn)), h * (-c + (-sn))]
        corners_y = [h * (sn + c), h * (sn - c), h * (-sn - c), h * (-sn + c)]
        minx = min(corners_x) + cx
        maxx = max(corners_x) + cx
        miny = min(corners_y) + cy
        maxy = max(corners_y) + cy
        if minx < 0:
            penalty += 1e4 * (minx) ** 2
        if maxx > 1:
            penalty += 1e4 * (maxx - 1.0) ** 2
        if miny < 0:
            penalty += 1e4 * (miny) ** 2
        if maxy > 1:
            penalty += 1e4 * (maxy - 1.0) ** 2
        total += s

    # overlap penalty
    for i in range(n):
        xi, yi, ai, si = arr[i]
        if si <= 0:
            continue
        for j in range(i + 1, n):
            xj, yj, aj, sj = arr[j]
            if sj <= 0:
                continue
            ov = overlap_area(xi, yi, ai, si, xj, yj, aj, sj)
            if ov > 0:
                penalty += 1e5 * ov

    return -(total) + penalty


def refine(squares, n, maxiter=200):
    if n == 0:
        return squares
    v0 = np.array([c for sq in squares for c in sq], dtype=float)
    # ensure inside and non-negative side
    arr = v0.reshape((n, 4))
    for i in range(n):
        cx, cy, ang, s = arr[i]
        cx, cy, ang, s = project_inside(cx, cy, ang, max(0.0, s))
        arr[i] = (cx, cy, ang, s)
    v0 = arr.ravel()

    try:
        res = minimize(objective_and_grad, v0, args=(n,),
                       method='Powell',
                       options={'maxiter': maxiter, 'xtol': 1e-8, 'ftol': 1e-8})
        v = res.x
    except Exception:
        v = v0

    # post-process: project all inside, clip side >= 0
    arr = v.reshape((n, 4))
    out = []
    for i in range(n):
        cx, cy, ang, s = arr[i]
        ang = float(ang % 1.0)
        s = max(0.0, float(s))
        cx, cy, ang, s = project_inside(cx, cy, ang, s)
        out.append((min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), ang, s))
    return out


def solve(n):
    """Return n tuples representing squares inside the unit square."""
    if n <= 0:
        return []

    base = mixed_packing(n)
    if n >= 2:
        # refine once
        try:
            refined = refine(base, n, maxiter=100)
            if sum(s for _, _, _, s in refined) > sum(s for _, _, _, s in base):
                base = refined
        except Exception:
            pass

    # final safety: ensure every square is inside and non-overlapping.
    # If overlaps remain, shrink smaller squares until feasible (conservative).
    squares = list(base)
    squares = [
        (min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), float(ang % 1.0), max(0.0, float(s)))
        for cx, cy, ang, s in squares
    ]

    # simple iterative shrink for overlaps
    for _ in range(50):
        changed = False
        for i in range(n):
            xi, yi, ai, si = squares[i]
            if si <= 0:
                continue
            for j in range(i + 1, n):
                xj, yj, aj, sj = squares[j]
                if sj <= 0:
                    continue
                if overlap_area(xi, yi, ai, si, xj, yj, aj, sj) > 0:
                    # shrink both a bit
                    si2 = si * 0.98
                    sj2 = sj * 0.98
                    ci = project_inside(xi, yi, ai, si2)
                    cj = project_inside(xj, yj, aj, sj2)
                    squares[i] = ci
                    squares[j] = cj
                    changed = True
        if not changed:
            break

    # Normalise centres to [0,1]
    squares = [
        (min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0), float(ang % 1.0), max(0.0, float(s)))
        for cx, cy, ang, s in squares
    ]

    # pad with zeros
    while len(squares) < n:
        squares.append((0.5, 0.5, 0.0, 0.0))
    return squares[:n]
# EVOLVE-BLOCK-END

