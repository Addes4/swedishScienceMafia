import math
import numpy as np
from scipy.optimize import minimize


def _rect_corners(cx, cy, ang, side):
    """Return 4 corners of a square with centre, angle (turns) and side."""
    c = math.cos(2.0 * math.pi * ang)
    s = math.sin(2.0 * math.pi * ang)
    h = side * 0.5
    ux, uy = c * h, s * h
    vx, vy = -s * h, c * h
    return (
        (cx - ux - vx, cy - uy - vy),
        (cx + ux - vx, cy + uy - vy),
        (cx + ux + vx, cy + uy + vy),
        (cx - ux + vx, cy - uy + vy),
    )


def _axes(cx, cy, ang, side):
    """Return the two edge directions and half-extents."""
    c = math.cos(2.0 * math.pi * ang)
    s = math.sin(2.0 * math.pi * ang)
    h = side * 0.5
    return (c, s), (-s, c), h


def _boxes_overlap(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """SAT test for two squares. Returns penetration depth (>0 if overlap)."""
    axes = []
    for cx, cy, ang, side in ((cx1, cy1, a1, s1), (cx2, cy2, a2, s2)):
        (ux, uy), (vx, vy), h = _axes(cx, cy, ang, side)
        axes.append((ux, uy))
        axes.append((vx, vy))
    dx = cx2 - cx1
    dy = cy2 - cy1
    best = float('inf')
    for ax, ay in axes:
        # project both squares onto axis
        # square 1
        s1proj = None
        for cxx, cyy, ang, side in ((cx1, cy1, a1, s1), (cx2, cy2, a2, s2)):
            (ux, uy), (vx, vy), h = _axes(cxx, cyy, ang, side)
            # corners relative to centre
            pts = [
                (-ux - vx, -uy - vy),
                (ux - vx, uy - vy),
                (ux + vx, uy + vy),
                (-ux + vx, -uy + vy),
            ]
            ps = [p[0] * ax + p[1] * ay for p in pts]
            mn = min(ps)
            mx = max(ps)
            if cxx == cx1:
                m1, x1 = mn, mx
            else:
                m2, x2 = mn, mx
        # separation along axis
        gap = max(m1 - x2, m2 - x1)
        if gap < best:
            best = gap
        if best <= 0:
            return 0.0
    return -best if best > 0 else -best


def _overlap_penalty(cx1, cy1, a1, s1, cx2, cy2, a2, s2):
    """0 if separated, else positive overlap measure."""
    if s1 <= 0 or s2 <= 0:
        return 0.0
    # If centres are far apart, skip SAT.
    # Use bounding radius first.
    r1 = s1 * 0.7071067811865476
    r2 = s2 * 0.7071067811865476
    dx = cx2 - cx1
    dy = cy2 - cy1
    if dx * dx + dy * dy > (r1 + r2) ** 2:
        return 0.0

    # SAT overlap as min separation across 4 axes
    axes = []
    for cx, cy, ang, side in ((cx1, cy1, a1, s1), (cx2, cy2, a2, s2)):
        (ux, uy), (vx, vy), h = _axes(cx, cy, ang, side)
        axes.append((ux, uy))
        axes.append((vx, vy))
    best = float('inf')
    for ax, ay in axes:
        m1 = x1 = None
        m2 = x2 = None
        for cxx, cyy, ang, side in ((cx1, cy1, a1, s1), (cx2, cy2, a2, s2)):
            (ux, uy), (vx, vy), h = _axes(cxx, cyy, ang, side)
            pts = [
                (-ux - vx, -uy - vy),
                (ux - vx, uy - vy),
                (ux + vx, uy + vy),
                (-ux + vx, -uy + vy),
            ]
            ps = [p[0] * ax + p[1] * ay for p in pts]
            mn = min(ps)
            mx = max(ps)
            if cxx == cx1:
                m1, x1 = mn, mx
            else:
                m2, x2 = mn, mx
        gap = max(m1 - x2, m2 - x1)
        if gap < best:
            best = gap
        if best <= 0:
            return 0.0
    return -best


def _boundary_penalty(cx, cy, ang, side):
    """Positive if square goes outside [0,1]^2, else 0."""
    if side <= 0:
        return 0.0
    c = math.cos(2.0 * math.pi * ang)
    s = math.sin(2.0 * math.pi * ang)
    h = side * 0.5
    # extent along x and y
    ex = h * (abs(c) + abs(s))
    ey = h * (abs(s) + abs(c))
    p = 0.0
    if cx - ex < 0.0:
        p += (0.0 - (cx - ex)) ** 2
    if cx + ex > 1.0:
        p += ((cx + ex) - 1.0) ** 2
    if cy - ey < 0.0:
        p += (0.0 - (cy - ey)) ** 2
    if cy + ey > 1.0:
        p += ((cy + ey) - 1.0) ** 2
    return p


def _objective_and_grad(x, n, penalty_weight):
    """x contains [cx, cy, ang, side] for each square."""
    vals = x.reshape(n, 4)
    total_side = 0.0
    pen = 0.0
    for i in range(n):
        cx, cy, ang, side = vals[i]
        side = max(0.0, min(1.0, side))
        total_side += side
        pen += _boundary_penalty(cx, cy, ang, side)
    for i in range(n):
        for j in range(i + 1, n):
            cx1, cy1, a1, s1 = vals[i]
            cx2, cy2, a2, s2 = vals[j]
            s1 = max(0.0, min(1.0, s1))
            s2 = max(0.0, min(1.0, s2))
            pen += _overlap_penalty(cx1, cy1, a1, s1, cx2, cy2, a2, s2)
    return -total_side + penalty_weight * pen


def _packing_for_n(n, seed=0, maxiter=200):
    rng = np.random.default_rng(seed)

    # --- initial layout by greedy placement / grid ---
    if n <= 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    # try square grid first
    k = int(math.isqrt(n))
    if k * k == n:
        side = 1.0 / k
        init = []
        for i in range(k):
            for j in range(k):
                init.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
        init = np.array(init, dtype=float).reshape(-1)
    else:
        # approximate equal-area packing: side ~ 1/sqrt(n)
        side = 1.0 / math.sqrt(n)
        # random start with grid-like centres
        centres = []
        m = int(math.ceil(math.sqrt(n)))
        for i in range(m):
            for j in range(m):
                if len(centres) < n:
                    centres.append(((i + 0.5) / m, (j + 0.5) / m))
        while len(centres) < n:
            centres.append((0.5, 0.5))
        init_list = []
        for i in range(n):
            cx, cy = centres[i]
            ang = 0.0
            s = side
            init_list.append((cx, cy, ang, s))
        init = np.array(init_list, dtype=float).reshape(-1)

    # bounds: cx,cy in [0,1], angle in [0,0.5), side in [0,1]
    lo = []
    hi = []
    for _ in range(n):
        lo.extend([0.0, 0.0, 0.0, 0.0])
        hi.extend([1.0, 1.0, 0.5, 1.0])

    best_x = init.copy()
    best_val = _objective_and_grad(init, n, 1e3)

    # multi-restart local optimisation
    for restart in range(6):
        x0 = init.copy()
        if restart > 0:
            # perturb
            noise = rng.normal(0.0, 0.03, size=x0.shape)
            x0 = x0 + noise
            for i in range(n):
                base = i * 4
                x0[base] = np.clip(x0[base], 0.0, 1.0)
                x0[base + 1] = np.clip(x0[base + 1], 0.0, 1.0)
                x0[base + 2] = np.clip(x0[base + 2], 0.0, 0.5)
                x0[base + 3] = np.clip(x0[base + 3], 0.0, 1.0)

        # adaptive penalty: increase when infeasible
        pw = 1e2
        x_cur = x0.copy()
        for outer in range(5):
            res = minimize(
                _objective_and_grad,
                x_cur,
                args=(n, pw),
                method='L-BFGS-B',
                bounds=list(zip(lo, hi)),
                options={'maxiter': maxiter, 'ftol': 1e-12, 'gtol': 1e-8},
            )
            x_cur = res.x
            val = _objective_and_grad(x_cur, n, 1e9)  # evaluate feasibility with huge penalty
            if val < best_val:
                best_val = val
                best_x = x_cur.copy()
            pw *= 10.0

    vals = best_x.reshape(n, 4)
    out = []
    for i in range(n):
        cx, cy, ang, side = vals[i]
        # final clipping to guarantee inside bounds
        cx = float(np.clip(cx, 0.0, 1.0))
        cy = float(np.clip(cy, 0.0, 1.0))
        ang = float(np.clip(ang, 0.0, 1.0))
        side = float(np.clip(side, 0.0, 1.0))
        out.append((cx, cy, ang, side))
    return out


def solve(n):
    """Return n squares (cx, cy, angle, side) inside unit square, disjoint interiors."""
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    # use optimisation
    best = None
    best_score = -1.0
    for seed in range(4):
        try:
            cand = _packing_for_n(n, seed=seed)
        except Exception:
            continue
        # score = sum of sides, but penalise infeasible heavily
        score = 0.0
        feasible = True
        for cx, cy, ang, side in cand:
            score += max(0.0, min(1.0, side))
            if _boundary_penalty(cx, cy, ang, max(0.0, min(1.0, side))) > 1e-8:
                feasible = False
        for i in range(n):
            for j in range(i + 1, n):
                cx1, cy1, a1, s1 = cand[i]
                cx2, cy2, a2, s2 = cand[j]
                if _overlap_penalty(cx1, cy1, a1, max(0.0, min(1.0, s1)),
                                    cx2, cy2, a2, max(0.0, min(1.0, s2))) > 1e-8:
                    feasible = False
        if not feasible:
            score *= 0.5
        if score > best_score:
            best_score = score
            best = cand

    if best is None:
        # fallback grid
        k = int(math.isqrt(n))
        side = 1.0 / k
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
        best = best[:n]

    # ensure exactly n
    if len(best) < n:
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return best[:n]
