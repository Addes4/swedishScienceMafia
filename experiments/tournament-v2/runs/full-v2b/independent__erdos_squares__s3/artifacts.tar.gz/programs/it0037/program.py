import math
import random
import numpy as np

try:
    from scipy.optimize import minimize
    HAVE_SCIPY = True
except Exception:
    HAVE_SCIPY = False


def _corners(cx, cy, ang, s):
    a = ang * 2.0 * math.pi
    ca, sa = math.cos(a), math.sin(a)
    h = s * 0.5
    pts = []
    for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
        x = sx * h
        y = sy * h
        pts.append((cx + x * ca - y * sa, cy + x * sa + y * ca))
    return pts


def _inside_unit(cx, cy, ang, s):
    if s <= 1e-15:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    h = s * 0.5
    a = ang * 2.0 * math.pi
    ca, sa = abs(math.cos(a)), abs(math.sin(a))
    ex = h * (ca + sa)
    ey = h * (sa + ca)
    return (ex <= cx <= 1.0 - ex) and (ey <= cy <= 1.0 - ey)


def _overlap(i, j, X):
    cx1, cy1, a1, s1 = X[4 * i:4 * i + 4]
    cx2, cy2, a2, s2 = X[4 * j:4 * j + 4]
    if s1 <= 1e-14 or s2 <= 1e-14:
        return False
    p1 = _corners(cx1, cy1, a1, s1)
    p2 = _corners(cx2, cy2, a2, s2)
    # separating axis: try edges of both squares
    for poly in (p1, p2):
        for k in range(4):
            x1, y1 = poly[k]
            x2, y2 = poly[(k + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            ax, ay = -ey, ex
            d1 = [ax * (px - x1) + ay * (py - y1) for px, py in p1]
            d2 = [ax * (px - x1) + ay * (py - y1) for px, py in p2]
            if max(d1) <= 1e-12 or min(d1) >= -1e-12:
                # project
                pass
            if max(d1) < min(d2) - 1e-12 or max(d2) < min(d1) - 1e-12:
                return False
    # no separating axis => overlap in interior (allow touching)
    return True


def _fitness(X, n):
    total = sum(X[4 * i + 3] for i in range(n))
    # penalty for out of bounds / overlap
    pen = 0.0
    scale = 100.0
    for i in range(n):
        cx, cy, a, s = X[4 * i:4 * i + 4]
        if not _inside_unit(cx, cy, a, s):
            pen += scale * (s + 1.0)
    for i in range(n):
        for j in range(i + 1, n):
            if _overlap(i, j, X):
                pen += scale * (min(X[4 * i + 3], X[4 * j + 3]) + 1.0)
    return total - pen


def _baseline_grid(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
               for i in range(k) for j in range(k)]
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def _init_random(n, rng):
    X = np.zeros(4 * n)
    for i in range(n):
        s = rng.uniform(0.02, 0.25)
        cx = rng.uniform(s / 2, 1 - s / 2)
        cy = rng.uniform(s / 2, 1 - s / 2)
        a = rng.uniform(0, 1)
        X[4 * i:4 * i + 4] = cx, cy, a, s
    return X


def _to_x(squares):
    X = np.zeros(4 * len(squares))
    for i, (cx, cy, a, s) in enumerate(squares):
        X[4 * i:4 * i + 4] = cx, cy, a, s
    return X


def _from_x(X, n):
    return [(float(X[4 * i]), float(X[4 * i + 1]), float(X[4 * i + 2] % 1.0), float(max(0.0, X[4 * i + 3]))) for i in range(n)]


def _local_opt(n, X, rng):
    best = X.copy()
    bestf = _fitness(best, n)
    # random hill climbing with small moves, keep only valid improvements
    for _ in range(2000):
        Y = best.copy()
        i = rng.randrange(n)
        what = rng.random()
        if what < 0.3:
            Y[4 * i] += rng.gauss(0, 0.01)
            Y[4 * i] = min(max(Y[4 * i], 0.0), 1.0)
        elif what < 0.6:
            Y[4 * i + 1] += rng.gauss(0, 0.01)
            Y[4 * i + 1] = min(max(Y[4 * i + 1], 0.0), 1.0)
        elif what < 0.8:
            Y[4 * i + 3] *= math.exp(rng.gauss(0, 0.05))
            Y[4 * i + 3] = min(max(Y[4 * i + 3], 0.0), 0.99)
        else:
            Y[4 * i + 2] += rng.gauss(0, 0.02)
        f = _fitness(Y, n)
        if f > bestf + 1e-12:
            best, bestf = Y, f
    return best


def _greedy_place(n, rng):
    """Randomized greedy insertion: try positions in decreasing size order."""
    X = np.zeros(4 * n)
    order = list(range(n))
    # initial guess sizes
    sizes = [0.0] * n
    for i in range(n):
        # target roughly 1/(sqrt(n)+1) but perturb
        sizes[i] = rng.uniform(0.05, 0.3)
    for idx in order:
        # try several candidate placements
        best_s = 0.0
        best_cx = best_cy = 0.5
        best_a = 0.0
        for _ in range(30):
            s = rng.uniform(0.02, 0.4)
            a = rng.uniform(0, 1)
            ca, sa = abs(math.cos(a * 2 * math.pi)), abs(math.sin(a * 2 * math.pi))
            h = s * 0.5
            ex = h * (ca + sa)
            ey = h * (sa + ca)
            if ex >= 0.5 or ey >= 0.5:
                continue
            cx = rng.uniform(ex, 1 - ex)
            cy = rng.uniform(ey, 1 - ey)
            ok = True
            for j in range(n):
                if j == idx:
                    continue
                if X[4 * j + 3] <= 1e-14:
                    continue
                Y = X.copy()
                Y[4 * idx:4 * idx + 4] = cx, cy, a, s
                if _overlap(idx, j, Y):
                    ok = False
                    break
            if ok and s > best_s:
                best_s = s
                best_cx, best_cy, best_a = cx, cy, a
        X[4 * idx:4 * idx + 4] = best_cx, best_cy, best_a, best_s
    return X


def solve(n):
    """
    Place n squares in unit square, maximise sum of side lengths.
    """
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    rng = random.Random(12345 + n)
    candidates = []

    # 1) grid baseline
    grid = _baseline_grid(n)
    candidates.append(_to_x(grid))

    # 2) random greedy
    for _ in range(6):
        candidates.append(_greedy_place(n, rng))

    # 3) random small init
    for _ in range(4):
        X = _init_random(n, rng)
        # enforce inside and zero overlaps roughly by shrinking
        for i in range(n):
            if not _inside_unit(X[4*i], X[4*i+1], X[4*i+2], X[4*i+3]):
                s = X[4*i+3]
                cx = min(max(X[4*i], s/2), 1 - s/2)
                cy = min(max(X[4*i+1], s/2), 1 - s/2)
                X[4*i] = cx
                X[4*i+1] = cy
        candidates.append(X)

    # local search on each
    bestX = None
    bestf = -1e18
    for X in candidates:
        Y = X.copy()
        for _ in range(3):
            Y = _local_opt(n, Y, rng)
        f = _fitness(Y, n)
        if f > bestf:
            bestf = f
            bestX = Y

    result = _from_x(bestX, n)
    # clamp and validate
    out = []
    for cx, cy, a, s in result:
        s = max(0.0, min(s, 1.0))
        a = a % 1.0
        if s <= 1e-14:
            out.append((min(max(cx,0.0),1.0), min(max(cy,0.0),1.0), a, 0.0))
        else:
            ca, sa = abs(math.cos(a * 2 * math.pi)), abs(math.sin(a * 2 * math.pi))
            h = s * 0.5
            ex = h * (ca + sa)
            ey = h * (sa + ca)
            if ex >= 0.5 or ey >= 0.5:
                s = 0.0
                out.append((0.5, 0.5, 0.0, 0.0))
                continue
            cx = min(max(cx, ex), 1 - ex)
            cy = min(max(cy, ey), 1 - ey)
            out.append((cx, cy, a, s))
    return out
