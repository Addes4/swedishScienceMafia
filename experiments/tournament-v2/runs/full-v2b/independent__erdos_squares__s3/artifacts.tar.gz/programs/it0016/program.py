import sys
import functools

sys.setrecursionlimit(100000)


def _quad(n):
    """Best split factor a for n squares in a rectangle: n = 1 -> 1; else a*b,
    with a,b as equal as possible but favouring more rows/cols for elongated cuts."""
    if n <= 1:
        return 1.0
    best = None
    bestv = -1.0
    # try all factorisations a*b = n (a = cols, b = rows)
    a = 1
    while a * a <= n:
        if n % a == 0:
            b = n // a
            # value of normalized split: max(1/a, 1/b), we minimize the larger
            v = -max(1.0 / a, 1.0 / b)
            if v > bestv:
                bestv = v
                best = (a, b)
        a += 1
    return best


def _quad_split(n):
    """Return (cols, rows) roughly balanced factorisation of n."""
    if n <= 1:
        return (1, 1)
    best = (1, n)
    bestmax = max(1.0 / 1, 1.0 / n)
    a = 1
    while a * a <= n:
        if n % a == 0:
            b = n // a
            m = max(1.0 / a, 1.0 / b)
            if m < bestmax - 1e-12 or (abs(m - bestmax) < 1e-12 and a > best[0]):
                bestmax = m
                best = (a, b)
        a += 1
    return best


def _rect_value(w, h, n):
    """Upper bound estimate of sum for n equal squares packed in w x h rectangle."""
    if n <= 0 or w <= 0 or h <= 0:
        return 0.0
    c, r = _quad_split(n)
    return n * min(w / c, h / r)


def _pack_rect(w, h, n, cx, cy, pieces, angle0=0.0):
    """Pack n squares in rectangle [cx-w/2, cx+w/2] x [cy-h/2, cy+h/2]."""
    if n <= 0:
        return
    if n == 1:
        s = min(w, h)
        pieces.append((cx, cy, angle0, s))
        return
    # choose the split direction favouring placing many squares in a grid
    c, r = _quad_split(n)
    # binary split if near-square factors almost match grid-perfect value
    # evaluate grid value
    gv = n * min(w / c, h / r)
    # try all binary cuts along x: i squares left, n-i right
    best_gain = -1e18
    best_action = None
    # candidate counts to split: use factorisation-friendly splits
    cands = set()
    for i in range(1, n):
        a = i
        b = n - i
        cands.add(i)
        if len(cands) > 60 and i > n // 2:
            break
    # we prefer balanced splits to keep good factorisation
    cands = sorted(cands, key=lambda i: abs(i - n / 2))[:24]
    for i in cands:
        j = n - i
        if i <= 0 or j <= 0:
            continue
        # split along x: widths proportional to value densities
        # estimate values
        best_a = None
        bestA = -1
        # search split x ratio t
        # value of left: i squares in (t*w) x h ; right: j in (1-t)*w x h
        # use approx: assume each subrect packs with _rect_value
        lo, hi = 0.001, 0.999
        # analytic: we want to find t maximizing
        # f(t) = _rect_value(t*w,h,i) + _rect_value((1-t)*w,h,j)
        # do a coarse-to-fine scan since _rect_value is piecewise simple
        ts = [k / 100.0 for k in range(1, 100)]
        # add adaptive candidates
        for _ in range(40):
            ts += [(lo + hi) / 2]
            mid = (lo + hi) / 2
            # biased directions: try where factors align
            if _rect_value((mid) * w, h, i) + _rect_value((1 - mid) * w, h, j) >= \
               _rect_value((mid - 0.01) * w, h, i) + _rect_value((1 - (mid - 0.01)) * w, h, j):
                lo = mid - (mid - lo) * 0.5
                hi = mid + (hi - mid) * 0.5
            else:
                lo, hi = mid - (mid - lo) * 0.5, mid + (hi - mid) * 0.5
            ts = list(set(round(t, 6) for t in ts))
        bestt = None
        bestv = -1
        for t in ts:
            if t <= 0 or t >= 1:
                continue
            v = _rect_value(t * w, h, i) + _rect_value((1 - t) * w, h, j)
            if v > bestv:
                bestv = v
                bestt = t
        if bestv > best_gain:
            best_gain = bestv
            best_action = ('x', i, j, bestt)
        # split along y
        bestt = None
        bestv = -1
        ts = [k / 100.0 for k in range(1, 100)]
        for t in ts:
            if t <= 0 or t >= 1:
                continue
            v = _rect_value(w, t * h, i) + _rect_value(w, (1 - t) * h, j)
            if v > bestv:
                bestv = v
                bestt = t
        if bestv > best_gain:
            best_gain = bestv
            best_action = ('y', i, j, bestt)
    # also consider ternary: place one square in corner (largest side) and split rest by a
    # diagonal cut; simpler: place m squares in a row/col, then rest.
    # ternary in a corner: square of side s at one corner, remaining L-shaped region
    # decomposed into two rectangles.  Evaluate a few s values.
    for i in cands[:6]:
        j = n - 1 - i
        if j < 0:
            continue
        # put 1 square in corner; remaining n-1 squares split into i and j along other dim
        for t in [0.25, 0.33, 0.4, 0.5, 0.6, 0.67, 0.75]:
            s = min(w, h) * math.sqrt(1.0 / max(n, 1))
            s = min(s, min(w, h))
            # corner square
            # remaining: right strip (w-s) x h and top-left s x (h-s)
            # assign i squares to right strip, j to top-left
            if s >= w or s >= h:
                continue
            v1 = _rect_value(w - s, h, i) + _rect_value(s, h - s, j)
            v2 = _rect_value(w - s, h, j) + _rect_value(s, h - s, i)
            v = s + max(v1, v2)
            if v > best_gain:
                best_gain = v
                if v1 >= v2:
                    best_action = ('corner', s, i, j, True)
                else:
                    best_action = ('corner', s, j, i, False)
    if best_action is None:
        # fallback: grid
        c, r = _quad_split(n)
        sw = w / c
        sh = h / r
        s = min(sw, sh)
        for a in range(c):
            for b in range(r):
                if len(pieces) < 0:
                    continue
                px = cx - w / 2 + (a + 0.5) * sw
                py = cy - h / 2 + (b + 0.5) * sh
                pieces.append((px, py, angle0, s))
        return
    if best_action[0] == 'x':
        _, i, j, t = best_action
        _pack_rect(w * t, h, i, cx - w / 2 + w * t / 2, cy, pieces, angle0)
        _pack_rect(w * (1 - t), h, j, cx - w / 2 + w * t + w * (1 - t) / 2, cy, pieces, angle0)
    elif best_action[0] == 'y':
        _, i, j, t = best_action
        _pack_rect(w, h * t, i, cx, cy - h / 2 + h * t / 2, pieces, angle0)
        _pack_rect(w, h * (1 - t), j, cx, cy - h / 2 + h * t + h * (1 - t) / 2, pieces, angle0)
    else:
        _, s, i, j, left_first = best_action
        # corner at bottom-left
        pieces.append((cx - w / 2 + s / 2, cy - h / 2 + s / 2, angle0, s))
        if left_first:
            # right strip: (w-s) x h with i squares
            _pack_rect(w - s, h, i, cx - w / 2 + s + (w - s) / 2, cy, pieces, angle0)
            _pack_rect(s, h - s, j, cx - w / 2 + s / 2, cy - h / 2 + s + (h - s) / 2, pieces, angle0)
        else:
            _pack_rect(w - s, h, j, cx - w / 2 + s + (w - s) / 2, cy, pieces, angle0)
            _pack_rect(s, h - s, i, cx - w / 2 + s / 2, cy - h / 2 + s + (h - s) / 2, pieces, angle0)


import math


def solve(n):
    pieces = []
    _pack_rect(1.0, 1.0, n, 0.5, 0.5, pieces)
    # safety fix: clip to unit square, remove overlaps roughly
    out = []
    for (x, y, a, s) in pieces:
        if s <= 1e-12:
            out.append((0.5, 0.5, 0.0, 0.0))
            continue
        # check inside
        half = s / 2.0
        # axis-aligned: keep center inside
        x = min(max(x, half), 1.0 - half)
        y = min(max(y, half), 1.0 - half)
        out.append((x, y, a, s))
    # ensure exactly n
    while len(out) < n:
        out.append((0.5, 0.5, 0.0, 0.0))
    out = out[:n]
    # fix overlaps greedily by shrinking
    for _ in range(3):
        for i in range(len(out)):
            xi, yi, ai, si = out[i]
            if si <= 0:
                continue
            shrink = 1.0
            for j in range(len(out)):
                if i == j:
                    continue
                xj, yj, aj, sj = out[j]
                if sj <= 0:
                    continue
                if ai == aj == 0.0:
                    dx = abs(xi - xj)
                    dy = abs(yi - yj)
                    # overlap if both dims overlap
                    ovx = (si + sj) / 2.0 - dx
                    ovy = (si + sj) / 2.0 - dy
                    if ovx > 1e-9 and ovy > 1e-9:
                        # shrink si so that at least one dim separates
                        # want max(si, sj) small
                        # target si such that dx >= (si+sj)/2 or dy >= (si+sj)/2
                        need1 = 2 * dx - sj
                        need2 = 2 * dy - sj
                        target = min(max(need1, -1), max(need2, -1))
                        if target < si:
                            si = max(0.0, target)
                            out[i] = (xi, yi, ai, si)
            # re-center
    return out
