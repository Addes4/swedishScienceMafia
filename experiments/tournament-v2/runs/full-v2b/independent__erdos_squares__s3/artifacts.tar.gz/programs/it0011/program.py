import math
import random
import time


def _rotate(cx, cy, ang, side):
    c = math.cos(2 * math.pi * ang)
    s = math.sin(2 * math.pi * ang)
    h = side * 0.5
    pts = []
    for dx, dy in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + dx * c - dy * s
        y = cy + dx * s + dy * c
        pts.append((x, y))
    return pts


def _poly_inside(poly):
    for x, y in poly:
        if x < -1e-9 or x > 1 + 1e-9 or y < -1e-9 or y > 1 + 1e-9:
            return False
    return True


def _cross(ax, ay, bx, by):
    return ax * by - ay * bx


def _seg_hit(a, b, c, d):
    def on(px, py, qx, qy, rx, ry):
        return min(px, qx) - 1e-12 <= rx <= max(px, qx) + 1e-12 and \
               min(py, qy) - 1e-12 <= ry <= max(py, qy) + 1e-12

    d1 = _cross(b[0] - a[0], b[1] - a[1], c[0] - a[0], c[1] - a[1])
    d2 = _cross(b[0] - a[0], b[1] - a[1], d[0] - a[0], d[1] - a[1])
    d3 = _cross(d[0] - c[0], d[1] - c[1], a[0] - c[0], a[1] - c[1])
    d4 = _cross(d[0] - c[0], d[1] - c[1], b[0] - c[0], b[1] - c[1])
    if ((d1 > 1e-12) != (d2 > 1e-12)) or ((d1 < -1e-12) != (d2 < -1e-12)):
        if ((d3 > 1e-12) != (d4 > 1e-12)) or ((d3 < -1e-12) != (d4 < -1e-12)):
            return True
    if abs(d1) < 1e-12 and on(a[0], a[1], b[0], b[1], c[0], c[1]):
        return True
    if abs(d2) < 1e-12 and on(a[0], a[1], b[0], b[1], d[0], d[1]):
        return True
    if abs(d3) < 1e-12 and on(c[0], c[1], d[0], d[1], a[0], a[1]):
        return True
    if abs(d4) < 1e-12 and on(c[0], c[1], d[0], d[1], b[0], b[1]):
        return True
    return False


def _overlap(p, q):
    for i in range(4):
        a = p[i]
        b = p[(i + 1) % 4]
        for j in range(4):
            c = q[j]
            d = q[(j + 1) % 4]
            if _seg_hit(a, b, c, d):
                return True
    # one inside the other
    def inside(pt, poly):
        sgn = 0
        for i in range(4):
            ax, ay = poly[i]
            bx, by = poly[(i + 1) % 4]
            v = _cross(bx - ax, by - ay, pt[0] - ax, pt[1] - ay)
            if abs(v) < 1e-12:
                continue
            s = 1 if v > 0 else -1
            if sgn == 0:
                sgn = s
            elif sgn != s:
                return False
        return True

    return inside(p[0], q) or inside(q[0], p)


class Packer:
    def __init__(self, n):
        self.n = n
        self.squares = []

    def polys(self):
        return [_rotate(cx, cy, a, s) for cx, cy, a, s in self.squares]

    def can_place(self, cx, cy, a, s):
        p = _rotate(cx, cy, a, s)
        if not _poly_inside(p):
            return False
        for q in self.polys():
            if _overlap(p, q):
                return False
        return True

    def add(self, cx, cy, a, s):
        self.squares.append((cx, cy, a, s))

    def total(self):
        return sum(s for _, _, _, s in self.squares)


def _initial_grid(n):
    best = []
    best_score = -1
    for k in range(max(1, math.isqrt(n)), 0, -1):
        side = 1.0 / k
        sq = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side)
              for i in range(k) for j in range(k)]
        if len(sq) <= n:
            sc = len(sq) * side
            if sc > best_score:
                best_score = sc
                best = sq[:]
            break
    return best


def _try_fill(rand, packer, remaining, deadline, trials=60):
    """Try to add squares to packer greedily/randomly."""
    added = 0
    target = remaining
    while added < target and time.time() < deadline:
        best = None
        best_sz = 0.0
        for _ in range(trials):
            # sample a candidate
            if rand.random() < 0.5:
                cx = rand.uniform(0.0, 1.0)
                cy = rand.uniform(0.0, 1.0)
            else:
                base = rand.choice(packer.squares) if packer.squares else (0.5, 0.5, 0.0, 1.0)
                cx = base[0] + rand.uniform(-0.3, 0.3)
                cy = base[1] + rand.uniform(-0.3, 0.3)
            ang = rand.choice([0.0, 0.25, 0.125, 0.375, rand.uniform(0, 1)])
            lo, hi = 0.0, 1.0
            # binary search largest side
            for _ in range(24):
                mid = (lo + hi) * 0.5
                if packer.can_place(cx, cy, ang, mid):
                    lo = mid
                else:
                    hi = mid
            if lo > best_sz:
                best_sz = lo
                best = (cx, cy, ang, lo)
        if best is None or best_sz < 1e-4:
            break
        packer.add(*best)
        added += 1
    return added


def _improve(packer, deadline):
    """Local search: try to enlarge existing squares and nudge positions."""
    rand = random.Random(12345)
    it = 0
    while time.time() < deadline:
        it += 1
        idx = rand.randrange(len(packer.squares))
        old = packer.squares[idx]
        best = old
        best_s = old[3]
        # random perturbations
        for _ in range(12):
            if rand.random() < 0.3:
                cx = rand.uniform(0, 1)
                cy = rand.uniform(0, 1)
            else:
                cx = old[0] + rand.gauss(0, 0.05)
                cy = old[1] + rand.gauss(0, 0.05)
            if not (0 <= cx <= 1 and 0 <= cy <= 1):
                continue
            if rand.random() < 0.5:
                ang = old[2]
            else:
                ang = rand.uniform(0, 1)
            # grow to max feasible
            lo, hi = 0.0, 1.0
            for _ in range(20):
                mid = (lo + hi) * 0.5
                if packer.can_place_excluding(idx, cx, cy, ang, mid):
                    lo = mid
                else:
                    hi = mid
            if lo > best_s + 1e-6:
                best_s = lo
                best = (cx, cy, ang, lo)
        if best_s > old[3]:
            packer.squares[idx] = best


def _can_place_excluding(self, skip, cx, cy, a, s):
    p = _rotate(cx, cy, a, s)
    if not _poly_inside(p):
        return False
    for i, (x, y, ang, sz) in enumerate(self.squares):
        if i == skip:
            continue
        q = _rotate(x, y, ang, sz)
        if _overlap(p, q):
            return False
    return True


Packer.can_place_excluding = _can_place_excluding


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    t_start = time.time()
    deadline = t_start + 55.0

    best_squares = None
    best_score = -1.0

    seeds = [0, 1, 2, 3, 4]
    for seed in seeds:
        if time.time() > deadline - 2:
            break
        rand = random.Random(seed)
        packer = Packer(n)
        init = _initial_grid(n)
        for sq in init:
            packer.add(*sq)
        # fill remaining
        remaining = n - len(packer.squares)
        # try several angle sets
        _try_fill(rand, packer, remaining, deadline, trials=40)
        # local improve with remaining time slice
        slice_end = min(deadline, time.time() + 8.0)
        _improve(packer, slice_end)
        # pad zeros
        while len(packer.squares) < n:
            packer.squares.append((0.5, 0.5, 0.0, 0.0))
        sc = packer.total()
        if sc > best_score:
            best_score = sc
            best_squares = packer.squares[:n]

    return best_squares
