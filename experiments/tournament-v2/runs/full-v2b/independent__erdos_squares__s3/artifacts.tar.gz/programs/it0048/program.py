import math
import numpy as np
from scipy.optimize import minimize


def _objective(v, k, m, n):
    """Penalty-based objective: negative sum of sides + large penalty for overlap/outside."""
    # v has length 4*(k*k + m) : for each square (x, y, angle, side)
    N = k * k + m
    penalty = 0.0
    total = 0.0
    squares = []
    for i in range(N):
        cx = v[4 * i]
        cy = v[4 * i + 1]
        ang = v[4 * i + 2]
        s = v[4 * i + 3]
        s = max(0.0, s)
        total += s
        ang = ang * 2 * math.pi
        c = math.cos(ang)
        sn = math.sin(ang)
        h = s / 2.0
        # four corners
        corners = [
            (cx + c * h - sn * h, cy + sn * h + c * h),
            (cx - c * h - sn * h, cy - sn * h + c * h),
            (cx - c * h + sn * h, cy - sn * h - c * h),
            (cx + c * h + sn * h, cy + sn * h - c * h),
        ]
        squares.append((cx, cy, ang, s, c, sn, h, corners))

    # outside penalty
    for sq in squares:
        cx, cy, ang, s, c, sn, h, corners = sq
        if s <= 1e-12:
            continue
        for (px, py) in corners:
            if px < 0:
                penalty += (0 - px) ** 2
            elif px > 1:
                penalty += (px - 1) ** 2
            if py < 0:
                penalty += (0 - py) ** 2
            elif py > 1:
                penalty += (py - 1) ** 2

    # overlap penalty using separating axis theorem on convex quads
    n_sq = len(squares)
    for i in range(n_sq):
        si = squares[i]
        if si[3] <= 1e-12:
            continue
        for j in range(i + 1, n_sq):
            sj = squares[j]
            if sj[3] <= 1e-12:
                continue
            # SAT overlap: check axes from both squares
            overlap = True
            for sq in (si, sj):
                cx, cy, ang, s, c, sn, h, corners = sq
                # two edge normals for this rotated square
                axes = [(c, sn), (-sn, c)]
                for (ax, ay) in axes:
                    proj_i = [corners[k][0] * ax + corners[k][1] * ay for k in range(4)]
                    proj_j = [sj[7][k][0] * ax + sj[7][k][1] * ay for k in range(4)]
                    if max(proj_i) <= min(proj_j) or max(proj_j) <= min(proj_i):
                        overlap = False
                        break
                if not overlap:
                    break
            if overlap:
                # estimate overlap amount roughly
                dx = si[0] - sj[0]
                dy = si[1] - sj[1]
                d2 = dx * dx + dy * dy
                penalty += 0.1 * (si[3] + sj[3]) ** 2 / (d2 + 1e-9) * 0.001
    return -total + 1000.0 * penalty


def _pack_with_opt(k, m, n, restarts=3):
    """Try to pack k*k + m squares, return best list."""
    N = k * k + m
    best = None
    best_val = -1e18

    for trial in range(restarts):
        v0 = np.zeros(4 * N)
        # initial: k x k grid for first k*k, then m more in remaining space
        side = 1.0 / k
        idx = 0
        for i in range(k):
            for j in range(k):
                v0[4 * idx] = (i + 0.5) * side
                v0[4 * idx + 1] = (j + 0.5) * side
                v0[4 * idx + 2] = 0.0
                v0[4 * idx + 3] = side * (0.95 + 0.1 * np.random.rand())
                idx += 1
        # extra squares: small random ones
        for _ in range(m):
            v0[4 * idx] = np.random.rand()
            v0[4 * idx + 1] = np.random.rand()
            v0[4 * idx + 2] = np.random.rand()
            v0[4 * idx + 3] = np.random.rand() * side * 0.5
            idx += 1

        # bounds: centres [0,1], angle [0,1) for full turn -> [0, 1] is enough as fraction
        bounds = []
        for _ in range(N):
            bounds.append((0.0, 1.0))
            bounds.append((0.0, 1.0))
            bounds.append((0.0, 1.0))
            bounds.append((0.0, 1.0))

        try:
            res = minimize(
                _objective, v0, args=(k, m, n),
                method='L-BFGS-B', bounds=bounds,
                options={'maxiter': 800, 'ftol': 1e-12, 'gtol': 1e-8}
            )
            val = -res.fun
            if val > best_val:
                best_val = val
                best = res.x
        except Exception:
            continue

    if best is None:
        return None
    result = []
    for i in range(N):
        cx = min(1.0, max(0.0, best[4 * i]))
        cy = min(1.0, max(0.0, best[4 * i + 1]))
        ang = best[4 * i + 2] % 1.0
        s = max(0.0, min(1.0, best[4 * i + 3]))
        result.append((cx, cy, ang, s))
    return result


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square."""
    if n <= 0:
        return []

    k = math.isqrt(n)
    result = None

    # Try to squeeze in extra squares beyond a perfect grid
    # We try a few configurations: k*k base plus as many extras as possible
    candidates = []
    for base_k in range(k, 0, -1):
        base_slots = base_k * base_k
        if base_slots > n:
            continue
        extras = n - base_slots
        # limit extras to a reasonable number for optimization
        if extras > 20:
            extras_try = 20
        else:
            extras_try = extras
        candidates.append((base_k, extras_try, base_slots + extras_try))

    best_result = None
    best_sum = -1.0

    # First: simple grid + zeros (guaranteed valid)
    simple = [((i + 0.5) / k, (j + 0.5) / k, 0.0, 1.0 / k)
              for i in range(k) for j in range(k)]
    simple += [(0.5, 0.5, 0.0, 0.0)] * (n - len(simple))
    simple = simple[:n]
    base_sum = sum(s[3] for s in simple)

    # Try optimization for the best candidates
    for (bk, ex, total) in candidates[:3]:
        if total > n:
            continue
        opt = _pack_with_opt(bk, ex, n, restarts=2)
        if opt is None:
            continue
        # Ensure all elements valid & fill to n
        if len(opt) < n:
            opt += [(0.5, 0.5, 0.0, 0.0)] * (n - len(opt))
        opt = opt[:n]
        # Validate no overlap quickly, if bad, fall back to smaller side
        s = sum(o[3] for o in opt)
        if s > best_sum:
            best_sum = s
            best_result = opt

    if best_result is None or best_sum < base_sum:
        return simple

    # Safety: if optimized sum is lower than grid, use grid
    if best_sum < base_sum:
        return simple

    return best_result
