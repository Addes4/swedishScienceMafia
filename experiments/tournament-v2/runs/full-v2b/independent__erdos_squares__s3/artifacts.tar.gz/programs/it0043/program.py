import math
import random
import numpy as np
from scipy.optimize import minimize


def _overlap_penalty(sq):
    """Return total area of pairwise interior overlaps (approx by sampling corners)."""
    pen = 0.0
    n = len(sq)
    for i in range(n):
        cx1, cy1, a1, s1 = sq[i]
        if s1 <= 1e-12:
            continue
        h1 = s1 / 2.0
        c1, si1 = math.cos(a1 * 2 * math.pi), math.sin(a1 * 2 * math.pi)
        # axis-aligned bounding box in rotated frame
        pts1 = []
        for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            x = cx1 + c1 * sx * h1 - si1 * sy * h1
            y = cy1 + si1 * sx * h1 + c1 * sy * h1
            pts1.append((x, y))
        for j in range(i + 1, n):
            cx2, cy2, a2, s2 = sq[j]
            if s2 <= 1e-12:
                continue
            h2 = s2 / 2.0
            c2, si2 = math.cos(a2 * 2 * math.pi), math.sin(a2 * 2 * math.pi)
            pts2 = []
            for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                x = cx2 + c2 * sx * h2 - si2 * sy * h2
                y = cy2 + si2 * sx * h2 + c2 * sy * h2
                pts2.append((x, y))
            # SAT: check separating axis
            sep = False
            for pts in (pts1, pts2):
                pass
            # simple SAT using edge normals of both squares
            axes = []
            for k in range(4):
                dx = pts1[(k + 1) % 4][0] - pts1[k][0]
                dy = pts1[(k + 1) % 4][1] - pts1[k][1]
                L = math.hypot(dx, dy)
                if L > 1e-15:
                    axes.append((-dy / L, dx / L))
            for k in range(4):
                dx = pts2[(k + 1) % 4][0] - pts2[k][0]
                dy = pts2[(k + 1) % 4][1] - pts2[k][1]
                L = math.hypot(dx, dy)
                if L > 1e-15:
                    axes.append((-dy / L, dx / L))
            minov = float('inf')
            for ax, ay in axes:
                p1 = [ax * p[0] + ay * p[1] for p in pts1]
                p2 = [ax * p[0] + ay * p[1] for p in pts2]
                ov = min(max(p1), max(p2)) - max(min(p1), min(p2))
                if ov <= 0:
                    minov = 0
                    break
                if ov < minov:
                    minov = ov
            if minov > 0:
                pen += minov * minov
    return pen


def _constraints(sq):
    """Return list of violation amounts (0 if valid)."""
    v = []
    for cx, cy, a, s in sq:
        if s <= 1e-12:
            continue
        h = s / 2.0
        c, si = math.cos(a * 2 * math.pi), math.sin(a * 2 * math.pi)
        for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            x = cx + c * sx * h - si * sy * h
            y = cy + si * sx * h + c * sy * h
            if x < -1e-9:
                v.append(-x)
            if x > 1 + 1e-9:
                v.append(x - 1)
            if y < -1e-9:
                v.append(-y)
            if y > 1 + 1e-9:
                v.append(y - 1)
    v.append(_overlap_penalty(sq))
    return v


def _obj(params):
    """params: for each square (cx, cy, a, s). Maximize sum(s) - penalty."""
    n = len(_obj.n_sq)
    sq = []
    idx = 0
    for i in range(n):
        cx, cy, a, s = params[idx], params[idx + 1], params[idx + 2], params[idx + 3]
        idx += 4
        sq.append((cx, cy, a, s))
    tot = sum(s for _, _, _, s in sq)
    pen = 0.0
    for cx, cy, a, s in sq:
        if s <= 1e-12:
            continue
        h = s / 2.0
        c, si = math.cos(a * 2 * math.pi), math.sin(a * 2 * math.pi)
        for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
            x = cx + c * sx * h - si * sy * h
            y = cy + si * sx * h + c * sy * h
            if x < 0:
                pen += (0 - x) ** 2 * 10
            if x > 1:
                pen += (x - 1) ** 2 * 10
            if y < 0:
                pen += (0 - y) ** 2 * 10
            if y > 1:
                pen += (y - 1) ** 2 * 10
    pen += _overlap_penalty(sq) * 10
    return -(tot) + pen


_obj.n_sq = []


def _greedy_grid(n, seed=0):
    """Place n axis-aligned squares using a greedy largest-first approach."""
    rng = random.Random(seed)
    # candidate sizes: binary subdivision of unit square
    # build list of empty regions as (x0, y0, x1, y1, maxsize)
    # simpler: start with a quadtree-like recursive splitting
    # We'll use a grid approach: try many random splits
    # Alternative: use a known good heuristic -- divide into strips.

    # Try: divide unit square into n rectangles of different aspect, fit a square
    # in each rectangle. Optimize the division.
    # For now: axis-aligned packing via guillotine cuts (recursive).

    best_sqs = None
    best_sum = -1

    for trial in range(200 if n <= 20 else 50):
        # random guillotine partition into n pieces
        boxes = [(0.0, 0.0, 1.0, 1.0)]
        while len(boxes) < n:
            # pick largest area box
            boxes.sort(key=lambda b: (b[2] - b[0]) * (b[3] - b[1]), reverse=True)
            # pick random among top few
            k = rng.randint(0, min(2, len(boxes) - 1))
            x0, y0, x1, y1 = boxes.pop(k)
            w, h = x1 - x0, y1 - y0
            if w < 1e-9 or h < 1e-9:
                boxes.append((x0, y0, x1, y1))
                continue
            # split
            if rng.random() < 0.5:
                # vertical split
                frac = rng.uniform(0.25, 0.75)
                xm = x0 + w * frac
                if xm <= x0 or xm >= x1:
                    boxes.append((x0, y0, x1, y1))
                    continue
                boxes.append((x0, y0, xm, y1))
                boxes.append((xm, y0, x1, y1))
            else:
                frac = rng.uniform(0.25, 0.75)
                ym = y0 + h * frac
                if ym <= y0 or ym >= y1:
                    boxes.append((x0, y0, x1, y1))
                    continue
                boxes.append((x0, y0, x1, ym))
                boxes.append((x0, ym, x1, y1))
        # in each box place a square centered, side = min(w,h)
        sqs = []
        for x0, y0, x1, y1 in boxes:
            s = min(x1 - x0, y1 - y0)
            cx = (x0 + x1) / 2
            cy = (y0 + y1) / 2
            sqs.append((cx, cy, 0.0, s))
        tot = sum(s for _, _, _, s in sqs)
        if tot > best_sum:
            best_sum = tot
            best_sqs = sqs

    return best_sqs, best_sum


def _optimize(sq, n_restarts=5, maxiter=300):
    """Refine positions/sizes using scipy."""
    best = list(sq)
    best_val = -1

    def make_params(sqs):
        p = []
        for cx, cy, a, s in sqs:
            p += [cx, cy, a, s]
        return np.array(p, dtype=float)

    _obj.n_sq = best  # dummy

    for restart in range(n_restarts):
        if restart == 0:
            p0 = make_params(sq)
        else:
            p0 = make_params(sq)
            # perturb
            noise = np.random.randn(len(p0)) * 0.05
            p0 = p0 + noise
            # clip centers and sizes
            for i in range(0, len(p0), 4):
                p0[i] = np.clip(p0[i], 0.001, 0.999)
                p0[i + 1] = np.clip(p0[i + 1], 0.001, 0.999)
                p0[i + 2] = np.clip(p0[i + 2], 0, 0.5)
                p0[i + 3] = np.clip(p0[i + 3], 0, 1)

        _obj.n_sq = [None] * len(sq)

        def f(p):
            nn = len(sq)
            sqs = []
            for i in range(nn):
                cx, cy, a, s = p[4 * i], p[4 * i + 1], p[4 * i + 2], p[4 * i + 3]
                sqs.append((cx, cy, a, s))
            tot = sum(s for _, _, _, s in sqs)
            pen = 0.0
            for cx, cy, a, s in sqs:
                if s <= 1e-12:
                    continue
                h = s / 2.0
                c = math.cos(a * 2 * math.pi)
                si = math.sin(a * 2 * math.pi)
                for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1)):
                    x = cx + c * sx * h - si * sy * h
                    y = cy + si * sx * h + c * sy * h
                    if x < 0:
                        pen += (0 - x) ** 2 * 100
                    if x > 1:
                        pen += (x - 1) ** 2 * 100
                    if y < 0:
                        pen += (0 - y) ** 2 * 100
                    if y > 1:
                        pen += (y - 1) ** 2 * 100
            pen += _overlap_penalty(sqs) * 100
            return -(tot) + pen

        try:
            res = minimize(f, p0, method='Nelder-Mead',
                           options={'maxiter': maxiter, 'xatol': 1e-6, 'fatol': 1e-6})
            p = res.x
        except Exception:
            continue

        # build result
        sqs = []
        for i in range(len(sq)):
            cx, cy, a, s = p[4 * i], p[4 * i + 1], p[4 * i + 2], p[4 * i + 3]
            cx = min(max(cx, 0), 1)
            cy = min(max(cy, 0), 1)
            s = max(s, 0)
            sqs.append((cx, cy, a, s))

        # check validity & compute sum
        tot = sum(s for _, _, _, s in sqs)
        if _overlap_penalty(sqs) < 1e-6:
            v = _constraints(sqs)
            valid = all(x < 1e-4 for x in v)
            if valid and tot > best_val:
                best_val = tot
                best = sqs

    if best_val < 0:
        return sq, sum(s for _, _, _, s in sq)
    return best, best_val


def _improve_grid(sq):
    """Optimize axis-aligned square sizes/positions on a grid using a simple local search."""
    n = len(sq)
    sq = [list(x) for x in sq]
    best_sum = sum(s[3] for s in sq)

    # local search: try to increase each square's size slightly,
    # adjusting positions to avoid overlap
    improved = True
    iters = 0
    while improved and iters < 50:
        improved = False
        iters += 1
        for i in range(n):
            # try to grow square i
            old = sq[i][:]
            delta = 0.001
            for _ in range(20):
                sq[i][3] += delta
                # re-center to fit
                cx, cy, a, s = sq[i]
                h = s / 2
                cx = min(max(cx, h), 1 - h)
                cy = min(max(cy, h), 1 - h)
                sq[i] = [cx, cy, a, s]
                # check overlap with others
                ok = True
                for j in range(n):
                    if i == j:
                        continue
                    if _overlap_penalty([sq[i], sq[j]]) > 1e-9:
                        ok = False
                        break
                if ok:
                    improved = True
                else:
                    sq[i] = old
                    break
    return [tuple(s) for s in sq], sum(s[3] for s in sq)


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside unit square."""
    if n == 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    best_sqs = None
    best_val = -1

    # Phase 1: greedy guillotine packing
    sqs, val = _greedy_grid(n, seed=42)
    if sqs is not None and val > best_val:
        best_sqs = sqs
        best_val = val

    # Phase 2: try a few different seeds
    for seed in range(5):
        sqs2, val2 = _greedy_grid(n, seed=seed * 7 + 1)
        if sqs2 is not None and val2 > best_val:
            best_sqs = sqs2
            best_val = val2

    if best_sqs is None:
        # fallback: axis-aligned grid
        k = math.isqrt(n)
        side = 1.0 / k
        best_sqs = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) for i in range(k) for j in range(k)]
        best_sqs += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best_sqs))
        best_sqs = best_sqs[:n]
        best_val = sum(s for _, _, _, s in best_sqs)

    # Phase 3: optimize with scipy for small n
    if n <= 15:
        try:
            sqs_opt, val_opt = _optimize(best_sqs, n_restarts=3, maxiter=500)
            if val_opt > best_val:
                best_sqs = sqs_opt
                best_val = val_opt
        except Exception:
            pass

    # Phase 4: local search to grow sizes
    try:
        sqs_imp, val_imp = _improve_grid(best_sqs)
        if val_imp > best_val:
            best_sqs = sqs_imp
            best_val = val_imp
    except Exception:
        pass

    # Ensure valid: check and fix any overlaps by shrinking
    result = []
    for cx, cy, a, s in best_sqs:
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        s = max(s, 0.0)
        # clip so square fits inside unit square
        if s > 0:
            h = s / 2.0
            c = math.cos(a * 2 * math.pi)
            si = math.sin(a * 2 * math.pi)
            mx = abs(c) * h + abs(si) * h
            my = abs(si) * h + abs(c) * h
            if cx < mx:
                cx = mx
            if cx > 1 - mx:
                cx = 1 - mx
            if cy < my:
                cy = my
            if cy > 1 - my:
                cy = 1 - my
            # if still doesn't fit, shrink
            if mx > 0.5 or my > 0.5:
                s = min(1.0 / (2 * max(abs(c) + abs(si), 1e-9)), s)
                h = s / 2.0
                mx = abs(c) * h + abs(si) * h
                my = abs(si) * h + abs(c) * h
                cx = min(max(cx, mx), 1 - mx)
                cy = min(max(cy, my), 1 - my)
        result.append((float(cx), float(cy), float(a), float(s)))

    # final overlap fix: iteratively shrink overlapping squares
    for _ in range(100):
        pen = _overlap_penalty(result)
        if pen < 1e-10:
            break
        # shrink all slightly
        result = [(cx, cy, a, s * 0.99) for cx, cy, a, s in result]

    # ensure exactly n squares
    while len(result) < n:
        result.append((0.5, 0.5, 0.0, 0.0))
    result = result[:n]

    # all values must be in [0,1]
    result = [(min(max(cx, 0.0), 1.0), min(max(cy, 0.0), 1.0),
               min(max(a, 0.0), 1.0), min(max(s, 0.0), 1.0))
              for cx, cy, a, s in result]

    return result
