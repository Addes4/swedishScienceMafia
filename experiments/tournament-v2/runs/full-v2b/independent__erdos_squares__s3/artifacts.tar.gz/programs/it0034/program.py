import math
import random
import numpy as np
from scipy.optimize import minimize


def _overlap_ok(squares, eps=1e-12):
    # conservative SAT overlap test for possibly rotated squares
    def corners(cx, cy, a, s):
        t = 2.0 * math.pi * a
        c, sn = math.cos(t), math.sin(t)
        d = 0.5 * s
        pts = []
        for dx, dy in ((-d, -d), (d, -d), (d, d), (-d, d)):
            pts.append((cx + c * dx - sn * dy, cy + sn * dx + c * dy))
        return pts

    def proj(poly, ax, ay):
        return [x * ax + y * ay for x, y in poly]

    def sat(poly1, poly2):
        for poly in (poly1, poly2):
            for i in range(4):
                x1, y1 = poly[i]
                x2, y2 = poly[(i + 1) % 4]
                ax, ay = -(y2 - y1), (x2 - x1)
                n = math.hypot(ax, ay)
                if n < 1e-15:
                    continue
                ax /= n
                ay /= n
                p1 = proj(poly1, ax, ay)
                p2 = proj(poly2, ax, ay)
                if max(p1) <= min(p2) + eps or max(p2) <= min(p1) + eps:
                    return False
        return True

    polys = [corners(*sq) for sq in squares if sq[3] > 1e-14]
    for i in range(len(polys)):
        for j in range(i + 1, len(polys)):
            if not sat(polys[i], polys[j]):
                return False
    return True


def _inside(sq, eps=1e-12):
    cx, cy, a, s = sq
    if s <= 0:
        return True
    t = 2.0 * math.pi * a
    c, sn = math.cos(t), math.sin(t)
    d = 0.5 * s
    for dx, dy in ((-d, -d), (d, -d), (d, d), (-d, d)):
        x = cx + c * dx - sn * dy
        y = cy + sn * dx + c * dy
        if x < -eps or x > 1 + eps or y < -eps or y > 1 + eps:
            return False
    return True


def _valid(squares):
    return all(_inside(sq) for sq in squares) and _overlap_ok(squares)


def _score(squares):
    return sum(sq[3] for sq in squares)


def _initial(n):
    best = None
    best_s = -1.0

    # Try several grid shapes, including non-square-ish partitions.
    for k in range(1, n + 1):
        if k * k > n:
            break
        cols = k
        rows = k
        while cols * rows < n and rows <= n:
            rows += 1
        if cols * rows < n:
            continue
        # use a k by ceil(n/k) grid, favoring squares
        for c in range(max(1, k - 1), k + 2):
            for r in range(max(1, k - 1), k + 2):
                if c * r >= n and c <= n and r <= n:
                    used = c * r
                    w = 1.0 / c
                    h = 1.0 / r
                    s = min(w, h)
                    if s <= 0:
                        continue
                    sqs = []
                    for i in range(c):
                        for j in range(r):
                            if len(sqs) < n:
                                sqs.append(((i + 0.5) * w, (j + 0.5) * h, 0.0, s))
                    # fill missing with zero-size in unused cells
                    while len(sqs) < n:
                        sqs.append((0.5, 0.5, 0.0, 0.0))
                    if _valid(sqs):
                        sc = _score(sqs)
                        if sc > best_s:
                            best_s = sc
                            best = sqs

    if best is not None:
        return best

    # fallback: single row or column
    for c in range(1, n + 1):
        r = (n + c - 1) // c
        if c * r < n:
            continue
        w = 1.0 / c
        h = 1.0 / r
        s = min(w, h)
        sqs = []
        for i in range(c):
            for j in range(r):
                if len(sqs) < n:
                    sqs.append(((i + 0.5) * w, (j + 0.5) * h, 0.0, s))
        while len(sqs) < n:
            sqs.append((0.5, 0.5, 0.0, 0.0))
        if _valid(sqs):
            return sqs

    return [(0.5, 0.5, 0.0, 0.0)] * n


def _local_search(squares, n, time_budget=1.0):
    rng = random.Random(12345)
    cur = [list(sq) for sq in squares]
    cur_score = _score(cur)
    best = [list(sq) for sq in cur]
    best_score = cur_score

    steps = 0
    max_steps = 200
    while steps < max_steps:
        steps += 1
        temp = max(0.0, 0.2 * (1.0 - steps / max_steps))
        i = rng.randrange(n)
        trial = [list(sq) for sq in cur]
        cx, cy, a, s = trial[i]
        # perturb center, angle, side
        scale = 0.02 * (1.0 + 4.0 * temp)
        cx += rng.uniform(-scale, scale)
        cy += rng.uniform(-scale, scale)
        a += rng.uniform(-0.1, 0.1)
        a %= 1.0
        s = max(0.0, s + rng.uniform(-scale, scale))
        # clamp into unit square roughly
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        # if side too big, shrink
        max_side = 1.0 / math.sqrt(n)
        s = min(s, max_side)
        trial[i] = [cx, cy, a, s]

        if _valid(trial):
            sc = _score(trial)
            if sc >= cur_score - 1e-12 or rng.random() < math.exp((sc - cur_score) / max(1e-9, temp)):
                cur = trial
                cur_score = sc
                if sc > best_score:
                    best_score = sc
                    best = [list(sq) for sq in trial]

    return [tuple(sq) for sq in best]


def solve(n):
    """Return n squares (centre_x, centre_y, angle, side) inside the unit square,
    with disjoint interiors, maximising the sum of the sides."""
    if n <= 0:
        return []

    # Special cases where known good configurations exist.
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5), (0.5, 0.75, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]

    best = _initial(n)
    # local search for small and medium n
    if n <= 200:
        improved = _local_search(best, n, time_budget=0.5)
        if _valid(improved) and _score(improved) >= _score(best) - 1e-12:
            best = improved

    # ensure exact n
    if len(best) < n:
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    return [tuple(sq) for sq in best[:n]]
