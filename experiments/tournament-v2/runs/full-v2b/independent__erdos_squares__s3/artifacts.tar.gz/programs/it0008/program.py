import math
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, angle, side):
    a = angle * 2.0 * math.pi
    c = math.cos(a)
    s = math.sin(a)
    h = side * 0.5
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [(cx + px * c - py * s, cy + px * s + py * c) for px, py in pts]


def _poly_area(pts):
    n = len(pts)
    s = 0.0
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        s += x1 * y2 - x2 * y1
    return 0.5 * s


def _inside_unit(pts, eps=1e-9):
    for x, y in pts:
        if x < -eps or x > 1.0 + eps or y < -eps or y > 1.0 + eps:
            return False
    return True


def _axes(pts):
    axes = []
    n = len(pts)
    for i in range(n):
        x1, y1 = pts[i]
        x2, y2 = pts[(i + 1) % n]
        dx, dy = x2 - x1, y2 - y1
        L = math.hypot(dx, dy)
        if L > 1e-15:
            axes.append((-dy / L, dx / L))
    return axes


def _project(pts, ax):
    vals = [x * ax[0] + y * ax[1] for x, y in pts]
    return min(vals), max(vals)


def _overlap(ptsA, ptsB):
    for ax in _axes(ptsA) + _axes(ptsB):
        a1, a2 = _project(ptsA, ax)
        b1, b2 = _project(ptsB, ax)
        if a2 <= b1 + 1e-12 or b2 <= a1 + 1e-12:
            return False
    return True


def _initial_grid(n):
    k = math.isqrt(n)
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append([(i + 0.5) * side, (j + 0.5) * side, 0.0, side])
    while len(squares) < n:
        squares.append([0.5, 0.5, 0.0, 0.0])
    return squares[:n]


def _initial_random(n, rng):
    squares = []
    # Start with sizes decreasing: first few big, then many small
    # Use a shelf-style packing in unit square with random splits
    target = []
    if n == 0:
        return []
    # generate sizes: pick largest arrangement heuristically
    # start from grid
    k = max(1, math.isqrt(n))
    base = 1.0 / k
    sizes = [base] * (k * k)
    while len(sizes) < n:
        sizes.append(0.0)
    sizes = sizes[:n]
    # try random small perturb
    rng.shuffle(sizes)
    # shelf packing: attempt to place with rotations
    # We'll just use random positions, letting optimizer fix.
    for s in sizes:
        cx = rng.uniform(s * 0.5, 1.0 - s * 0.5) if s > 0 else 0.5
        cy = rng.uniform(s * 0.5, 1.0 - s * 0.5) if s > 0 else 0.5
        ang = rng.uniform(0.0, 1.0)
        squares.append([cx, cy, ang, s])
    return squares


def _pack_vector(x, n):
    return x.reshape(n, 4)


def _unpack(x, n):
    arr = x.reshape(n, 4)
    return arr


def _objective(x, n):
    arr = _unpack(x, n)
    s = np.clip(arr[:, 3], 0.0, None)
    return -np.sum(s)


def _constraints(x, n, use_penalty=True):
    arr = _unpack(x, n)
    cons = []
    # boundary constraints via corner checks: instead use center bounds approximation plus rotations
    # For robustness, we check corners exactly for boundary in a penalty-free form
    # Here we enforce: for each square, rotated half-diagonal within unit square
    # Actually we must check corners; use inequalities on center
    for i in range(n):
        cx, cy, ang, s = arr[i]
        if s <= 0:
            cons.append(cx - 0.5)
            cons.append(0.5 - cx)
            cons.append(cy - 0.5)
            cons.append(0.5 - cy)
            continue
        a = ang * 2 * math.pi
        c = math.cos(a)
        si = math.sin(a)
        h = s * 0.5
        # corners offsets
        for px, py in [(-h, -h), (h, -h), (h, h), (-h, h)]:
            X = cx + px * c - py * si
            Y = cy + px * si + py * c
            cons.append(X)
            cons.append(1.0 - X)
            cons.append(Y)
            cons.append(1.0 - Y)
    return np.array(cons)


def _nonoverlap_penalty(x, n):
    arr = _unpack(x, n)
    pen = 0.0
    pts_list = []
    for i in range(n):
        cx, cy, ang, s = arr[i]
        if s <= 1e-12:
            pts_list.append(None)
            continue
        pts_list.append(_corners(cx, cy, ang, s))
    for i in range(n):
        if pts_list[i] is None:
            continue
        for j in range(i + 1, n):
            if pts_list[j] is None:
                continue
            if _overlap(pts_list[i], pts_list[j]):
                # approximate penetration depth via centroid distance
                ci = (arr[i, 0], arr[i, 1])
                cj = (arr[j, 0], arr[j, 1])
                d = math.hypot(ci[0] - cj[0], ci[1] - cj[1])
                ri = 0.5 * arr[i, 3] * math.sqrt(2)
                rj = 0.5 * arr[j, 3] * math.sqrt(2)
                pen += max(0.0, ri + rj - d) ** 2
    return pen


def _total_objective(x, n, penalty_weight=200.0):
    val = 0.0
    arr = _unpack(x, n)
    val -= np.sum(np.clip(arr[:, 3], 0.0, None))
    # boundary penalty
    for i in range(n):
        cx, cy, ang, s = arr[i]
        if s <= 0:
            cx = min(max(cx, 0.0), 1.0)
            cy = min(max(cy, 0.0), 1.0)
            continue
        a = ang * 2 * math.pi
        c = math.cos(a)
        si = math.sin(a)
        h = s * 0.5
        for px, py in [(-h, -h), (h, -h), (h, h), (-h, h)]:
            X = cx + px * c - py * si
            Y = cy + px * si + py * c
            if X < 0:
                val += penalty_weight * X * X
            if X > 1:
                val += penalty_weight * (X - 1) ** 2
            if Y < 0:
                val += penalty_weight * Y * Y
            if Y > 1:
                val += penalty_weight * (Y - 1) ** 2
    pen = _nonoverlap_penalty(x, n)
    val += penalty_weight * pen
    return val


def _greedy_pack(n, rng, trials=8):
    # Try a lattice/greedy shelf approach with decreasing squares
    # Use squares in a spiral/shelf pattern to maximize area -> side sum
    best = None
    best_score = -1.0

    for t in range(trials):
        sizes = _generate_sizes(n, rng)
        placed = []
        ok = True
        # sort decreasing
        order = sorted(range(n), key=lambda i: -sizes[i])
        positions = [None] * n
        for idx in order:
            s = sizes[idx]
            if s <= 1e-12:
                positions[idx] = (0.5, 0.5, 0.0, 0.0)
                continue
            found = False
            # try random positions
            for _ in range(200):
                ang = rng.uniform(0.0, 1.0)
                if rng.random() < 0.5:
                    ang = 0.0
                # bounding box placement: place center near a corner/middle
                cx = rng.uniform(s * 0.5, 1.0 - s * 0.5)
                cy = rng.uniform(s * 0.5, 1.0 - s * 0.5)
                newc = _corners(cx, cy, ang, s)
                if not _inside_unit(newc):
                    continue
                collide = False
                for p in placed:
                    if _overlap(newc, p):
                        collide = True
                        break
                if not collide:
                    placed.append(newc)
                    positions[idx] = (cx, cy, ang, s)
                    found = True
                    break
            if not found:
                positions[idx] = (0.5, 0.5, 0.0, 0.0)
        score = sum(p[3] for p in positions if p is not None)
        if score > best_score:
            best_score = score
            best = positions
    return best


def _generate_sizes(n, rng):
    # Heuristic: equal-ish sizes arranged in grid give ~sqrt(n) * 1/sqrt(n) = 1
    # Actually k x k grid gives k * (1/k) = 1. Better: mix sizes.
    # Use a few large + many small; large squares contribute more.
    # Try partition-based sizes
    sizes = []
    # base plan: largest square as big as possible, remainder in strips
    # For simplicity use equal sizes with random perturbations
    k = max(1, int(round(math.isqrt(n))))
    base = 1.0 / k
    for i in range(n):
        s = base * rng.uniform(0.7, 1.3)
        sizes.append(s)
    return sizes


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    rng = np.random.default_rng(12345)
    best_x = None
    best_val = -1e9
    # multi-start
    starts = []
    # grid start
    starts.append(_initial_grid(n))
    for _ in range(6):
        starts.append(_initial_random(n, rng))

    for init in starts:
        x0 = np.array(init, dtype=float).reshape(-1)
        # clip sizes to [0,1], angles [0,1], centers [0,1]
        for i in range(n):
            x0[4 * i] = min(max(x0[4 * i], 0.0), 1.0)
            x0[4 * i + 1] = min(max(x0[4 * i + 1], 0.0), 1.0)
            x0[4 * i + 2] = min(max(x0[4 * i + 2], 0.0), 1.0)
            x0[4 * i + 3] = min(max(x0[4 * i + 3], 0.0), 1.0)
        try:
            res = minimize(
                _total_objective,
                x0,
                args=(n,),
                method='Nelder-Mead',
                options={'maxiter': 4000, 'xatol': 1e-6, 'fatol': 1e-6},
            )
            cand = res.x
        except Exception:
            continue
        val = -_total_objective(cand, n)
        if val > best_val:
            best_val = val
            best_x = cand

    if best_x is None:
        return _initial_grid(n)

    arr = _unpack(best_x, n)
    result = []
    for i in range(n):
        cx, cy, ang, s = arr[i]
        s = max(0.0, min(s, 1.0))
        ang = ang % 1.0
        cx = min(max(cx, 0.0), 1.0)
        cy = min(max(cy, 0.0), 1.0)
        result.append((float(cx), float(cy), float(ang), float(s)))

    # sanity check: resolve any overlaps by shrinking
    result = _repair(result)
    return result


def _repair(squares):
    n = len(squares)
    sq = [list(s) for s in squares]
    for _ in range(30):
        changed = False
        for i in range(n):
            for j in range(i + 1, n):
                si = sq[i][3]
                sj = sq[j][3]
                if si <= 1e-12 or sj <= 1e-12:
                    continue
                ci = _corners(*sq[i])
                cj = _corners(*sq[j])
                if _overlap(ci, cj):
                    # shrink the smaller one
                    if si <= sj:
                        sq[i][3] *= 0.9
                    else:
                        sq[j][3] *= 0.9
                    changed = True
        if not changed:
            break
    return [tuple(s) for s in sq]
