import math
import numpy as np
from scipy.optimize import minimize


def _corners(cx, cy, ang, s):
    c = math.cos(ang * 2 * math.pi)
    sn = math.sin(ang * 2 * math.pi)
    h = s * 0.5
    # local corners
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    out = []
    for x, y in pts:
        out.append((cx + x * c - y * sn, cy + x * sn + y * c))
    return out


def _sat_overlap(a, b):
    # returns positive penetration depth-like value if overlapping, else <=0
    pa = _corners(*a)
    pb = _corners(*b)
    best = -1e9
    for poly, other in ((pa, pb), (pb, pa)):
        for i in range(4):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            # normal
            nx, ny = -ey, ex
            L = math.hypot(nx, ny)
            if L < 1e-15:
                continue
            nx /= L
            ny /= L
            amin = amax = None
            for px, py in poly:
                d = px * nx + py * ny
                if amin is None or d < amin:
                    amin = d
                if amax is None or d > amax:
                    amax = d
            bmin = bmax = None
            for px, py in other:
                d = px * nx + py * ny
                if bmin is None or d < bmin:
                    bmin = d
                if bmax is None or d > bmax:
                    bmax = d
            overlap = min(amax, bmax) - max(amin, bmin)
            if overlap > best:
                best = overlap
    return best


def _penalty(squares):
    total = 0.0
    m = len(squares)
    for i in range(m):
        for j in range(i + 1, m):
            p = _sat_overlap(squares[i], squares[j])
            if p > 1e-12:
                total += p * p
    return total


def _containment_penalty(squares):
    total = 0.0
    for cx, cy, ang, s in squares:
        pts = _corners(cx, cy, ang, s)
        for x, y in pts:
            dx = 0.0
            if x < 0:
                dx = -x
            elif x > 1:
                dx = x - 1
            dy = 0.0
            if y < 0:
                dy = -y
            elif y > 1:
                dy = y - 1
            total += dx * dx + dy * dy
    return total


def _objective(x, n):
    squares = []
    for i in range(n):
        squares.append((x[4 * i], x[4 * i + 1], x[4 * i + 2], x[4 * i + 3]))
    s = sum(sq[3] for sq in squares)
    pen = _penalty(squares) * 50.0
    pen += _containment_penalty(squares) * 50.0
    return -s + pen


def _grid_init(n):
    k = int(math.ceil(math.sqrt(n)))
    # try grids
    best = None
    for rows in range(1, n + 1):
        cols = int(math.ceil(n / rows))
        if cols * rows < n:
            continue
        # side lengths
        s = min(1.0 / cols, 1.0 / rows)
        sq = []
        idx = 0
        for j in range(rows):
            for i in range(cols):
                if idx >= n:
                    break
                cx = (i + 0.5) / cols
                cy = (j + 0.5) / rows
                sq.append((cx, cy, 0.0, s))
                idx += 1
        val = sum(q[3] for q in sq)
        if best is None or val > best[0]:
            best = (val, sq)
    return best[1]


def _row_init(n):
    # some squares can be larger in a less regular layout
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5)]
    if n == 4:
        return [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
    return _grid_init(n)


def _strip_init(n):
    # divide into horizontal strips, each containing 1 row of equal squares
    # optimized allocation later; simple version
    best = None
    for rows in range(1, n + 1):
        # distribute n squares among rows
        base = n // rows
        rem = n % rows
        if base == 0:
            continue
        counts = [base + (1 if i < rem else 0) for i in range(rows)]
        heights = []
        side = 1e9
        for c in counts:
            s = 1.0 / c
            heights.append(s)
            side = min(side, s)
        total = sum(heights)
        if total > 1 + 1e-9:
            scale = 1.0 / total
            heights = [h * scale for h in heights]
        y = 0.0
        sq = []
        idx = 0
        for r, c in enumerate(counts):
            s = 1.0 / c
            s = min(s, heights[r])
            # actually use height as side
            s = heights[r]
            x = 0.0
            for i in range(c):
                sq.append((x + s * 0.5, y + s * 0.5, 0.0, s))
                x += s
                idx += 1
            y += s
        val = sum(q[3] for q in sq)
        if best is None or val > best[0]:
            best = (val, sq)
    return best[1]


def _agnostic_init(n):
    candidates = [_grid_init(n), _row_init(n), _strip_init(n)]
    best = max(candidates, key=lambda sq: sum(q[3] for q in sq))
    return best


def _refine(squares, n, maxiter=200):
    x0 = []
    for sq in squares:
        x0.extend(sq)
    x0 = np.array(x0, dtype=float)
    # clip to valid range
    for i in range(n):
        x0[4 * i] = min(max(x0[4 * i], 0.0), 1.0)
        x0[4 * i + 1] = min(max(x0[4 * i + 1], 0.0), 1.0)
        x0[4 * i + 2] = min(max(x0[4 * i + 2], 0.0), 1.0)
        x0[4 * i + 3] = min(max(x0[4 * i + 3], 0.0), 1.0)

    bounds = []
    for i in range(n):
        bounds.append((0.0, 1.0))  # cx
        bounds.append((0.0, 1.0))  # cy
        bounds.append((0.0, 1.0))  # angle
        bounds.append((0.0, 1.0))  # side

    try:
        res = minimize(_objective, x0, args=(n,), method='SLSQP',
                       bounds=bounds,
                       options={'maxiter': maxiter, 'ftol': 1e-12})
        if res.success or res.fun is not None:
            xx = res.x
        else:
            xx = x0
    except Exception:
        xx = x0

    out = []
    for i in range(n):
        cx = min(max(xx[4 * i], 0.0), 1.0)
        cy = min(max(xx[4 * i + 1], 0.0), 1.0)
        ang = min(max(xx[4 * i + 2], 0.0), 1.0)
        s = max(xx[4 * i + 3], 0.0)
        out.append((cx, cy, ang, s))
    return out


def _project(squares):
    # shrink sides / push centers to eliminate overlaps and keep in bounds
    # simple iterative repair
    n = len(squares)
    sq = [list(s) for s in squares]
    for _ in range(200):
        moved = False
        # containment
        for i in range(n):
            pts = _corners(sq[i][0], sq[i][1], sq[i][2], sq[i][3])
            minx = min(p[0] for p in pts)
            maxx = max(p[0] for p in pts)
            miny = min(p[1] for p in pts)
            maxy = max(p[1] for p in pts)
            if minx < -1e-12:
                sq[i][0] += -minx
                moved = True
            if maxx > 1 + 1e-12:
                sq[i][0] -= maxx - 1
                moved = True
            if miny < -1e-12:
                sq[i][1] += -miny
                moved = True
            if maxy > 1 + 1e-12:
                sq[i][1] -= maxy - 1
                moved = True
            if sq[i][3] < 0:
                sq[i][3] = 0.0
        # overlap
        for i in range(n):
            for j in range(i + 1, n):
                p = _sat_overlap(sq[i], sq[j])
                if p > 1e-12:
                    moved = True
                    # push apart along center line, and shrink
                    dx = sq[j][0] - sq[i][0]
                    dy = sq[j][1] - sq[i][1]
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        dx, dy = 1.0, 0.0
                        d = 1.0
                    push = p * 0.5 + 1e-4
                    ux, uy = dx / d, dy / d
                    sq[i][0] -= ux * push * 0.5
                    sq[i][1] -= uy * push * 0.5
                    sq[j][0] += ux * push * 0.5
                    sq[j][1] += uy * push * 0.5
                    # also shrink a little
                    sq[i][3] *= 0.999
                    sq[j][3] *= 0.999
        if not moved:
            break
    # final containment enforce by shrinking if needed
    for i in range(n):
        if sq[i][3] <= 0:
            sq[i][3] = 0.0
            continue
        pts = _corners(sq[i][0], sq[i][1], sq[i][2], sq[i][3])
        minx = min(p[0] for p in pts)
        maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts)
        maxy = max(p[1] for p in pts)
        # shift then shrink
        sx = 1.0 / max(1e-12, maxx - minx + 1.0)
        sy = 1.0 / max(1e-12, maxy - miny + 1.0)
        # just shift
        if minx < 0:
            sq[i][0] -= minx
        if maxx > 1:
            sq[i][0] -= (maxx - 1)
        if miny < 0:
            sq[i][1] -= miny
        if maxy > 1:
            sq[i][1] -= (maxy - 1)
    return [tuple(s) for s in sq]


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]

    init = _agnostic_init(n)
    init = _project(init)

    # try a few refinements
    best = init
    best_val = sum(sq[3] for sq in best)

    trials = [init]
    # multi-start: slightly perturbed versions
    rng = np.random.RandomState(12345)
    for t in range(3):
        x0 = []
        for sq in init:
            x0.append(sq[0] + rng.randn() * 0.01)
            x0.append(sq[1] + rng.randn() * 0.01)
            x0.append(sq[2] + rng.randn() * 0.02)
            x0.append(sq[3] * (1.0 + rng.randn() * 0.05))
        x0 = np.clip(np.array(x0), 0.0, 1.0)
        perturbed = []
        for i in range(n):
            perturbed.append((x0[4 * i], x0[4 * i + 1], x0[4 * i + 2], x0[4 * i + 3]))
        perturbed = _project(perturbed)
        trials.append(perturbed)

    for tr in trials:
        refined = _refine(tr, n, maxiter=300)
        refined = _project(refined)
        val = sum(sq[3] for sq in refined)
        if val > best_val:
            best_val = val
            best = refined

    # final projection and return
    best = _project(best)
    return best


if __name__ == "__main__":
    for n in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 16, 25]:
        res = solve(n)
        print(n, sum(s[3] for s in res))
