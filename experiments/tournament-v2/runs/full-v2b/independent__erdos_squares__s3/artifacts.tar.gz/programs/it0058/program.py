import math
import random
import time

try:
    import numpy as np
except Exception:
    np = None

# ---------- geometry helpers ----------

SQRT2 = math.sqrt(2.0)

def square_vertices(cx, cy, ang, side):
    """Return 4 corner vertices of a square (fractional turn angle)."""
    a = ang * 2.0 * math.pi
    c, s = math.cos(a), math.sin(a)
    h = side * 0.5
    # local corners in (-h,-h)..(h,h)
    pts = []
    for lx, ly in ((-h, -h), (h, -h), (h, h), (-h, h)):
        x = cx + c * lx - s * ly
        y = cy + s * lx + c * ly
        pts.append((x, y))
    return pts

def sat_overlap(s1, s2):
    """Return penetration depth if two squares overlap (positive), else 0.
    Uses Separating Axis Theorem with axes of both squares."""
    cx1, cy1, a1, w1 = s1
    cx2, cy2, a2, w2 = s2
    if w1 <= 0.0 or w2 <= 0.0:
        return 0.0
    a1r = a1 * 2.0 * math.pi
    a2r = a2 * 2.0 * math.pi
    axes1 = [(math.cos(a1r), math.sin(a1r)), (-math.sin(a1r), math.cos(a1r))]
    axes2 = [(math.cos(a2r), math.sin(a2r)), (-math.sin(a2r), math.cos(a2r))]
    best_pen = float('inf')
    h1 = w1 * 0.5
    h2 = w2 * 0.5
    for ax, ay in axes1 + axes2:
        # project both squares onto axis
        p1 = cx1 * ax + cy1 * ay
        p2 = cx2 * ax + cy2 * ay
        r1 = abs(ax * (math.cos(a1r))) * h1 + abs(ay * (math.cos(a1r))) * h1  # not correct
        # proper radius: sum over the two local axes of square
        def proj_radius(ca, sa, h):
            # axes of the square: (ca,sa) and (-sa,ca)
            return h * (abs(ax * ca + ay * sa) + abs(ax * (-sa) + ay * ca))
        r1 = proj_radius(math.cos(a1r), math.sin(a1r), h1)
        r2 = proj_radius(math.cos(a2r), math.sin(a2r), h2)
        dist = abs(p1 - p2)
        pen = r1 + r2 - dist
        if pen <= 0.0:
            return 0.0
        if pen < best_pen:
            best_pen = pen
    return best_pen

# ---------- initial configurations ----------

def grid_layout(n, k):
    side = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    return res[:n]

def diagonal_layout(n):
    """Place squares along diagonals, all same size, trying to maximise total side."""
    # approximate: choose size s such that along a diagonal line we can fit some count
    # simple heuristic: use k = ceil(sqrt(n)) grid then randomize
    k = int(math.ceil(math.sqrt(n)))
    side = 1.0 / k
    res = []
    for i in range(k):
        for j in range(k):
            res.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    return res[:n]

def random_layout(n, rng):
    res = []
    for _ in range(n):
        s = rng.uniform(0.02, 0.15)
        res.append((rng.uniform(s*0.5, 1-s*0.5),
                    rng.uniform(s*0.5, 1-s*0.5),
                    rng.uniform(0.0, 1.0),
                    s))
    return res

# ---------- relaxation ----------

def clamp_square(sq):
    cx, cy, ang, side = sq
    if side <= 0.0:
        return (0.5, 0.5, 0.0, 0.0)
    h = side * 0.5
    # half-extent of rotated square bounding box
    a = ang * 2.0 * math.pi
    ca, sa = abs(math.cos(a)), abs(math.sin(a))
    ex = (ca + sa) * h
    ey = (ca + sa) * h
    if ex > 0.5:
        # scale down side to fit
        max_side = 1.0 / (ca + sa)
        side = max_side
        h = side * 0.5
        ex = ey = (ca + sa) * h
    if cx - ex < -1e-9:
        cx = ex
    if cx + ex > 1.0 + 1e-9:
        cx = 1.0 - ex
    if cy - ey < -1e-9:
        cy = ey
    if cy + ey > 1.0 + 1e-9:
        cy = 1.0 - ey
    return (cx, cy, ang, side)

def relax(squares, iters=300, dt=0.02, grow=True, grow_rate=0.002, rng=None):
    """Physics relaxation: repulsion on overlap, grow sides."""
    s = [list(x) for x in squares]
    n = len(s)
    if rng is None:
        rng = random.Random(12345)
    for it in range(iters):
        forces = [[0.0, 0.0] for _ in range(n)]
        # pairwise repulsion
        for i in range(n):
            xi, yi, ai, wi = s[i]
            if wi <= 0:
                continue
            for j in range(i + 1, n):
                xj, yj, aj, wj = s[j]
                if wj <= 0:
                    continue
                pen = sat_overlap((xi, yi, ai, wi), (xj, yj, aj, wj))
                if pen > 0:
                    dx = xi - xj
                    dy = yi - yj
                    d = math.hypot(dx, dy)
                    if d < 1e-9:
                        dx = rng.uniform(-1, 1)
                        dy = rng.uniform(-1, 1)
                        d = math.hypot(dx, dy)
                    ux, uy = dx / d, dy / d
                    f = pen * 50.0
                    forces[i][0] += ux * f
                    forces[i][1] += uy * f
                    forces[j][0] -= ux * f
                    forces[j][1] -= uy * f
        # integrate
        for i in range(n):
            if s[i][3] <= 0:
                continue
            s[i][0] += forces[i][0] * dt
            s[i][1] += forces[i][1] * dt
            # slight angle jitter
            s[i][2] += rng.uniform(-0.01, 0.01) * dt * 10
            s[i][2] = s[i][2] % 1.0
            # grow side
            if grow:
                s[i][3] *= (1.0 + grow_rate)
            # clamp
            cx, cy, ang, side = clamp_square(s[i])
            s[i] = [cx, cy, ang, side]
    return [tuple(x) for x in s]

# ---------- main solver ----------

def solve(n):
    if n <= 0:
        return []
    rng = random.Random(987654321)
    deadline = time.time() + 55.0

    best = None
    best_score = -1.0

    # Candidate initial layouts
    candidates = []

    # 1. grid layouts for various k
    for k in range(1, int(math.ceil(math.sqrt(n))) + 2):
        if k * k >= n:
            candidates.append(grid_layout(n, k))

    # 2. random layouts
    for _ in range(4):
        candidates.append(random_layout(n, rng))

    # 3. diagonal / staggered: place in rows with alternating offsets
    def staggered(n):
        rows = int(math.ceil(math.sqrt(n)))
        res = []
        side = 1.0 / rows
        idx = 0
        for i in range(rows):
            offset = 0.0 if i % 2 == 0 else side * 0.5
            j = 0
            while idx < n:
                x = offset + j * side + side * 0.5
                if x + side * 0.5 > 1.0:
                    break
                y = (i + 0.5) * side
                res.append((x, y, 0.0, side))
                idx += 1
                j += 1
                break  # one per row for simplicity
        # fill remainder
        while len(res) < n:
            res.append((0.5, 0.5, 0.0, 0.0))
        return res[:n]
    candidates.append(staggered(n))

    # evaluate and relax each candidate
    for cand in candidates:
        if time.time() > deadline:
            break
        # quick initial relax with growth
        cur = relax(cand, iters=200, dt=0.015, grow=True, grow_rate=0.004, rng=rng)
        cur = relax(cur, iters=200, dt=0.01, grow=False, rng=rng)
        score = sum(x[3] for x in cur)
        if score > best_score:
            best_score = score
            best = cur

    # additional random restarts
    restart = 0
    while time.time() < deadline and restart < 30:
        restart += 1
        cand = random_layout(n, rng)
        cur = relax(cand, iters=200, dt=0.015, grow=True, grow_rate=0.004, rng=rng)
        cur = relax(cur, iters=200, dt=0.01, grow=False, rng=rng)
        score = sum(x[3] for x in cur)
        if score > best_score:
            best_score = score
            best = cur

    # final polish: shrink zero-side squares to points if any, ensure n
    if best is None:
        best = grid_layout(n, max(1, int(math.ceil(math.sqrt(n)))))
    best = list(best)[:n]
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    # ensure all valid
    out = []
    for sq in best:
        cx, cy, ang, side = sq
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = ang % 1.0
        side = min(1.0, max(0.0, side))
        out.append((cx, cy, ang, side))
    return out
