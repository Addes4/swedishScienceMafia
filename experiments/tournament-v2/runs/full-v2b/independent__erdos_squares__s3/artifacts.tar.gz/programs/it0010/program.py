import math
import random
import time

# ------------------------------------------------------------
# Geometry helpers
# ------------------------------------------------------------

def _rot_axes(angle):
    c = math.cos(angle * 2.0 * math.pi)
    s = math.sin(angle * 2.0 * math.pi)
    return c, s


def _corners(x, y, a, r):
    """Return the 4 corners of a square with centre (x,y), angle a (turns), half-side r."""
    c = math.cos(a * 2.0 * math.pi)
    s = math.sin(a * 2.0 * math.pi)
    # local axes: (c,s) and (-s,c)
    ex = (c * r, s * r)
    ey = (-s * r, c * r)
    return [
        (x - ex[0] - ey[0], y - ex[1] - ey[1]),
        (x + ex[0] - ey[0], y + ex[1] - ey[1]),
        (x + ex[0] + ey[0], y + ex[1] + ey[1]),
        (x - ex[0] + ey[0], y - ex[1] + ey[1]),
    ]


def _inside_square(pts):
    for px, py in pts:
        if px < -1e-12 or px > 1.0 + 1e-12 or py < -1e-12 or py > 1.0 + 1e-12:
            return False
    return True


def _project(poly, ax):
    return min(p[0] * ax[0] + p[1] * ax[1] for p in poly), max(
        p[0] * ax[0] + p[1] * ax[1] for p in poly
    )


def _sat_overlap(poly1, poly2):
    """True if interiors overlap using separating axis theorem."""
    axes = []
    for poly in (poly1, poly2):
        m = len(poly)
        for i in range(m):
            x1, y1 = poly[i]
            x2, y2 = poly[(i + 1) % m]
            dx, dy = x2 - x1, y2 - y1
            length = math.hypot(dx, dy)
            if length > 1e-15:
                axes.append((-dy / length, dx / length))
    for a in axes:
        mn1, mx1 = _project(poly1, a)
        mn2, mx2 = _project(poly2, a)
        if mx1 <= mn2 + 1e-12 or mx2 <= mn1 + 1e-12:
            return False
    return True


class SquareSet:
    """Maintains a set of squares (cx, cy, angle, side) and provides feasibility checks."""

    def __init__(self, squares):
        self.squares = list(squares)
        self.n = len(squares)
        self.corners = []
        self._rebuild()

    def _rebuild(self):
        self.corners = []
        for x, y, a, side in self.squares:
            self.corners.append(_corners(x, y, a, side * 0.5))

    def set_square(self, i, x, y, a, side):
        self.squares[i] = (x, y, a, side)
        self.corners[i] = _corners(x, y, a, side * 0.5)

    def feasible(self):
        # boundaries
        for i in range(self.n):
            if not _inside_square(self.corners[i]):
                return False
        # pairwise
        for i in range(self.n):
            ci = self.corners[i]
            for j in range(i + 1, self.n):
                if _sat_overlap(ci, self.corners[j]):
                    return False
        return True

    def conflicts(self, i):
        """Return list of indices j that overlap with i or wet i boundary violation, plus -1 for boundary."""
        res = []
        ci = self.corners[i]
        if not _inside_square(ci):
            res.append(-1)
        for j in range(self.n):
            if i == j:
                continue
            if _sat_overlap(ci, self.corners[j]):
                res.append(j)
        return res


# ------------------------------------------------------------
# Constructors
# ------------------------------------------------------------

def grid_solution(n):
    k = math.isqrt(n)
    if k == 0:
        return [(0.5, 0.5, 0.0, 0.0)] * n
    side = 1.0 / k
    squares = []
    for i in range(k):
        for j in range(k):
            squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def strip_solution(n):
    """One row of squares."""
    if n == 0:
        return []
    s = 1.0
    squares = []
    for i in range(n):
        squares.append(((i + 0.5) / n, 0.5, 0.0, 1.0 / n))
    return squares


def mixed_solution(n):
    """Try a combination of rows with different counts, starting from best grid."""
    best = grid_solution(n)
    best_score = sum(s[3] for s in best)

    # Try row configurations: distribute n into r rows.
    for r in range(1, min(n, 12) + 1):
        counts = [n // r] * r
        for i in range(n % r):
            counts[i] += 1
        # widths determined by the minimum of row heights and column widths
        row_h = 1.0 / r
        squares = []
        for ri, cnt in enumerate(counts):
            if cnt == 0:
                continue
            col_w = 1.0 / cnt
            side = min(row_h, col_w)
            # centre row horizontally
            total_w = cnt * side
            x0 = (1.0 - total_w) * 0.5
            for ci in range(cnt):
                squares.append((x0 + (ci + 0.5) * side, (ri + 0.5) * row_h, 0.0, side))
        # pad with zeros
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        squares = squares[:n]
        sc = sum(s[3] for s in squares)
        if sc > best_score:
            best_score = sc
            best = squares
    return best


def diagonal_solution(n):
    """Place n squares along a line with rotation to pack tighter."""
    # Simpler: just use mixed.
    return mixed_solution(n)


# ------------------------------------------------------------
# Local search / simulated annealing
# ------------------------------------------------------------

def _random_perturbation(squares, idx, temperature, rng):
    x, y, a, s = squares[idx]
    # scale moves according to s and temperature
    mag = max(0.01, s * 0.5 * temperature)
    dx = rng.uniform(-mag, mag)
    dy = rng.uniform(-mag, mag)
    da = rng.uniform(-0.1, 0.1) * temperature
    ds = rng.uniform(-mag, mag)
    nx = min(1.0, max(0.0, x + dx))
    ny = min(1.0, max(0.0, y + dy))
    na = (a + da) % 0.25
    ns = max(0.0, min(1.0, s + ds))
    return nx, ny, na, ns


def optimize(n, time_limit=55.0):
    rng = random.Random(1234567 + n)
    start_time = time.time()

    # initial solutions
    candidates = [grid_solution(n), mixed_solution(n), strip_solution(n)]
    best = max(candidates, key=lambda sq: sum(s[3] for s in sq))
    best_score = sum(s[3] for s in best)

    sqs = SquareSet([tuple(s) for s in best])

    # Try to repair if infeasible
    def repair(sqs, max_iter=1000):
        it = 0
        while not sqs.feasible() and it < max_iter:
            it += 1
            # find a random conflicting square and shrink it
            moved = False
            for i in range(sqs.n):
                conf = sqs.conflicts(i)
                if conf:
                    x, y, a, s = sqs.squares[i]
                    # shrink or move inward
                    if -1 in conf:
                        # move toward centre
                        nx = x + (0.5 - x) * rng.uniform(0.1, 0.5)
                        ny = y + (0.5 - y) * rng.uniform(0.1, 0.5)
                        ns = s * rng.uniform(0.9, 0.999)
                        sqs.set_square(i, min(1.0, max(0.0, nx)), min(1.0, max(0.0, ny)), a, ns)
                    else:
                        # shrink
                        ns = s * rng.uniform(0.8, 0.99)
                        sqs.set_square(i, x, y, a, ns)
                    moved = True
                    break
            if not moved:
                # randomly shrink largest
                idx = max(range(sqs.n), key=lambda k: sqs.squares[k][3])
                x, y, a, s = sqs.squares[idx]
                sqs.set_square(idx, x, y, a, s * 0.95)
        return sqs

    if not sqs.feasible():
        repair(sqs)

    # Simulated annealing
    T0 = 0.05
    T_end = 1e-4
    alpha = 0.9995

    T = T0
    step = 0
    while time.time() - start_time < time_limit:
        step += 1
        T = max(T_end, T * alpha)
        if step % 100 == 0 and T < T_end:
            break

        # pick a random square and perturb
        idx = rng.randrange(sqs.n)
        old = sqs.squares[idx]
        new = _random_perturbation(sqs.squares, idx, T, rng)

        # tentative set
        sqs.set_square(idx, *new)

        if sqs.feasible():
            new_score = sum(s[3] for s in sqs.squares)
            delta = new_score - best_score
            if delta >= 0 or rng.random() < math.exp(delta / (T + 1e-12)):
                if new_score > best_score:
                    best_score = new_score
                    best = list(sqs.squares)
            else:
                sqs.set_square(idx, *old)
        else:
            # try to shrink a tiny bit to make feasible
            x, y, a, s = new
            new_small = (x, y, a, s * 0.99)
            sqs.set_square(idx, *new_small)
            if sqs.feasible():
                new_score = sum(s[3] for s in sqs.squares)
                if new_score > best_score:
                    best_score = new_score
                    best = list(sqs.squares)
            else:
                sqs.set_square(idx, *old)

    # Final greedy pass: try increasing sizes one by one
    improved = True
    while improved and time.time() - start_time < time_limit:
        improved = False
        for i in range(sqs.n):
            x, y, a, s = sqs.squares[i]
            old = (x, y, a, s)
            # try increasing size
            lo, hi = s, min(1.0, s + 0.2)
            best_inc = s
            for _ in range(8):
                mid = (lo + hi) * 0.5
                sqs.set_square(i, x, y, a, mid)
                if sqs.feasible():
                    best_inc = mid
                    lo = mid
                else:
                    hi = mid
            if best_inc > s + 1e-9:
                sqs.set_square(i, x, y, a, best_inc)
                improved = True
            else:
                sqs.set_square(i, *old)

    final = list(sqs.squares)
    if sum(s[3] for s in final) > best_score:
        best = final

    # Ensure all outputs in [0,1]
    out = []
    for x, y, a, s in best:
        out.append((
            min(1.0, max(0.0, x)),
            min(1.0, max(0.0, y)),
            a % 1.0,
            max(0.0, min(1.0, s)),
        ))
    return out


# ------------------------------------------------------------
# Main solve
# ------------------------------------------------------------

_cache = {}


def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n in _cache:
        return _cache[n]

    # quick constructive attempt
    if n <= 4:
        # optimal or near-optimal simple cases
        if n == 2:
            res = [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
            _cache[n] = res
            return res
        if n == 3:
            # two small on one side, one large
            res = [
                (0.25, 0.25, 0.0, 0.5),
                (0.75, 0.25, 0.0, 0.5),
                (0.5, 0.75, 0.0, 0.5),
            ]
            _cache[n] = res
            return res
        if n == 4:
            res = [(0.25, 0.25, 0.0, 0.5), (0.75, 0.25, 0.0, 0.5),
                   (0.25, 0.75, 0.0, 0.5), (0.75, 0.75, 0.0, 0.5)]
            _cache[n] = res
            return res

    tlim = 50.0 if n < 40 else (40.0 if n < 100 else 30.0)
    res = optimize(n, time_limit=tlim)
    _cache[n] = res
    return res
