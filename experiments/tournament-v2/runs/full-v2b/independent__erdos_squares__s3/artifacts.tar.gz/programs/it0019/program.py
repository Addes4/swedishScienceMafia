import math
import random
import numpy as np
from scipy.optimize import minimize

# ----------------------------------------------------------------------------
# Geometry helpers
# ----------------------------------------------------------------------------

def _rotated_square_corners(cx, cy, angle, side):
    """Return the four corners of a square centred at (cx, cy)."""
    h = side / 2.0
    ca = math.cos(2.0 * math.pi * angle)
    sa = math.sin(2.0 * math.pi * angle)
    # local corners in CCW order
    pts = [(-h, -h), (h, -h), (h, h), (-h, h)]
    return [
        (cx + ca * x - sa * y, cy + sa * x + ca * y) for x, y in pts
    ]

def _projection_interval(points, axis):
    vals = [px * axis[0] + py * axis[1] for px, py in points]
    return min(vals), max(vals)

def _overlap_1d(a1, a2, b1, b2):
    return max(0.0, min(a2, b2) - max(a1, b1))

def _squares_overlap(s1, s2, eps=1e-9):
    """Separating axis test for two rotated squares."""
    cx1, cy1, a1, s1_side = s1
    cx2, cy2, a2, s2_side = s2
    if s1_side <= 0 or s2_side <= 0:
        return False
    p1 = _rotated_square_corners(cx1, cy1, a1, s1_side)
    p2 = _rotated_square_corners(cx2, cy2, a2, s2_side)
    # axes: normals to the four edges (two per square)
    axes = []
    for pts in (p1, p2):
        for i in range(4):
            x1, y1 = pts[i]
            x2, y2 = pts[(i + 1) % 4]
            ex, ey = x2 - x1, y2 - y1
            n = (-ey, ex)
            ln = math.hypot(*n)
            if ln > 1e-15:
                axes.append((n[0] / ln, n[1] / ln))
    for ax in axes:
        i1 = _projection_interval(p1, ax)
        i2 = _projection_interval(p2, ax)
        if _overlap_1d(i1[0], i1[1], i2[0], i2[1]) <= eps:
            return False
    return True

def _inside_unit(cx, cy, angle, side):
    if side <= 0:
        return 0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0
    pts = _rotated_square_corners(cx, cy, angle, side)
    for px, py in pts:
        if px < -1e-9 or px > 1.0 + 1e-9 or py < -1e-9 or py > 1.0 + 1e-9:
            return False
    return True

# ----------------------------------------------------------------------------
# Constructive tiling routines
# ----------------------------------------------------------------------------

def _grid_tile(n, x0, y0, w, h):
    """Tile rectangle [x0,x0+w] x [y0,y0+h] with n equal squares in a grid."""
    if n <= 0:
        return []
    # choose cols/rows to fit n squares with side as large as possible
    best = None
    for cols in range(1, n + 1):
        rows = (n + cols - 1) // cols
        if cols * rows < n:
            continue
        side = min(w / cols, h / rows)
        if side <= 0:
            continue
        # count that actually fit with this side in given rectangle
        # we can use exactly n cells if cols*rows >= n
        if best is None or side > best[0]:
            best = (side, cols, rows)
    if best is None:
        return []
    side, cols, rows = best
    squares = []
    for r in range(rows):
        for c in range(cols):
            if len(squares) >= n:
                break
            cx = x0 + (c + 0.5) * w / cols
            cy = y0 + (r + 0.5) * h / rows
            squares.append((cx, cy, 0.0, side))
        if len(squares) >= n:
            break
    return squares

def _strip_tile(n, x0, y0, w, h):
    """Tile a rectangle with n squares by equal columns or rows."""
    if n <= 0:
        return []
    side_a = min(w / n, h)
    side_b = min(w, h / n)
    if side_a >= side_b:
        side = side_a
        squares = []
        for i in range(n):
            cx = x0 + (i + 0.5) * w / n
            cy = y0 + h / 2.0
            squares.append((cx, cy, 0.0, side))
        return squares
    else:
        side = side_b
        squares = []
        for i in range(n):
            cx = x0 + w / 2.0
            cy = y0 + (i + 0.5) * h / n
            squares.append((cx, cy, 0.0, side))
        return squares

def _fill_rect_with_grid(n, x0, y0, w, h):
    """Fill rectangle by grid or strips, whichever gives larger side per square."""
    g = _grid_tile(n, x0, y0, w, h)
    s = _strip_tile(n, x0, y0, w, h)
    def sum_side(lst):
        return sum(sq[3] for sq in lst) if lst else -1
    if sum_side(g) >= sum_side(s):
        return g
    return s

# ----------------------------------------------------------------------------
# Main constructive heuristic
# ----------------------------------------------------------------------------

def _construct(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    # large single square is good for small n
    if n <= 3:
        # one big square occupying most space, plus small squares in a corner strip
        big = 1.0
        # leave a thin strip? Actually for n=2, two squares can both be large:
        # split unit square into two equal halves.
        if n == 2:
            return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
        # n == 3: one 0.5 square plus two smaller in remaining strip? Or three strips of width 1/3.
        side = 1.0 / 3.0
        return [(side*(i+0.5), 0.5, 0.0, side) for i in range(3)]
    # General: recursively split into rectangles and fill
    # Strategy: partition into k columns/rows and fill each with best tilings
    best_result = None
    best_score = -1.0
    
    # Try several partition strategies
    strategies = []
    
    # Strategy A: split into vertical strips of varying widths
    # Use number of strips from 1 to min(n, 20)
    for num_strips in range(1, min(n, 25) + 1):
        strategies.append(('vertical_strips', num_strips))
        strategies.append(('horizontal_strips', num_strips))
    
    # Strategy B: main rectangle + leftover in a strip
    # Try placing a big rectangle with a grid of m squares, and fill remaining L-shape
    for m in range(1, min(n, 50) + 1):
        strategies.append(('main_plus_rest', m))
    
    for strat in strategies:
        result = _try_strategy(n, strat)
        if result is None:
            continue
        # validate
        if not _valid_solution(result, n):
            continue
        score = sum(sq[3] for sq in result)
        if score > best_score:
            best_score = score
            best_result = result
    
    if best_result is None:
        # fallback: uniform grid
        k = math.isqrt(n)
        side = 1.0 / k
        best_result = [((i+0.5)*side, (j+0.5)*side, 0.0, side)
                       for i in range(k) for j in range(k)]
        while len(best_result) < n:
            best_result.append((0.5, 0.5, 0.0, 0.0))
    return best_result[:n]

def _try_strategy(n, strat):
    kind = strat[0]
    if kind == 'vertical_strips':
        num_strips = strat[1]
        return _fill_strips(n, num_strips, vertical=True)
    if kind == 'horizontal_strips':
        num_strips = strat[1]
        return _fill_strips(n, num_strips, vertical=False)
    if kind == 'main_plus_rest':
        m = strat[1]
        if m >= n:
            return None
        return _main_plus_rest(n, m)
    return None

def _fill_strips(n, num_strips, vertical=True):
    """Split unit square into num_strips strips, distribute n squares among them."""
    if num_strips <= 0:
        return None
    # We need at least 1 square per strip and at least n squares total
    if num_strips > n:
        return None
    # Allocate squares proportional to strip area (equal strips => equal area)
    counts = [n // num_strips] * num_strips
    rem = n - sum(counts)
    for i in range(rem):
        counts[i] += 1
    # Better: try to allocate more squares to some strips to allow bigger side
    # Simple proportional allocation is fine
    squares = []
    for i in range(num_strips):
        ci = counts[i]
        if ci == 0:
            continue
        if vertical:
            w = 1.0 / num_strips
            x0 = i * w
            y0 = 0.0
            h = 1.0
        else:
            h = 1.0 / num_strips
            y0 = i * h
            x0 = 0.0
            w = 1.0
        part = _fill_rect_with_grid(ci, x0, y0, w, h)
        squares.extend(part)
    return squares

def _main_plus_rest(n, m):
    """Place m squares in a grid in a sub-rectangle, fill rest with remaining squares."""
    if m >= n:
        return None
    rest = n - m
    best = None
    best_score = -1
    # Try grid shapes for main block
    for cols in range(1, m + 1):
        rows = (m + cols - 1) // cols
        if cols * rows < m:
            continue
        # rectangle dimensions: choose to maximize side
        # main block occupies cols x rows grid with side s, plus rest in a strip
        # Try main block at left/bottom with width W, height H such that W/H = cols/rows
        # Simple: try several fractions of unit square for main block
        for frac in [0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 1.0]:
            W = frac
            H = frac
            side_main = min(W / cols, H / rows)
            # rest in remaining L-shaped or strip area
            # choose rest area: right strip or top strip
            for rest_frac in [0.2, 0.25, 0.3, 0.33, 0.4, 0.5]:
                rw = 1.0 - W if W < 1.0 else rest_frac
                rh = 1.0 - H if H < 1.0 else rest_frac
                if rw > 1e-9 and rh > 1e-9:
                    pass
                # strip on right
                if W < 1.0 - 1e-9:
                    rw = 1.0 - W
                    rest_squares = _fill_rect_with_grid(rest, W, 0.0, rw, 1.0)
                    # main squares
                    main_squares = []
                    for r in range(rows):
                        for c in range(cols):
                            if len(main_squares) >= m:
                                break
                            cx = (c + 0.5) * W / cols
                            cy = (r + 0.5) * H / rows
                            main_squares.append((cx, cy, 0.0, side_main))
                        if len(main_squares) >= m:
                            break
                    allsq = main_squares + rest_squares
                    if len(allsq) == n and _valid_solution(allsq, n):
                        sc = sum(sq[3] for sq in allsq)
                        if sc > best_score:
                            best_score = sc
                            best = allsq
                # strip on top
                if H < 1.0 - 1e-9:
                    rh = 1.0 - H
                    rest_squares = _fill_rect_with_grid(rest, 0.0, H, 1.0, rh)
                    main_squares = []
                    for r in range(rows):
                        for c in range(cols):
                            if len(main_squares) >= m:
                                break
                            cx = (c + 0.5) * W / cols
                            cy = (r + 0.5) * H / rows
                            main_squares.append((cx, cy, 0.0, side_main))
                        if len(main_squares) >= m:
                            break
                    allsq = main_squares + rest_squares
                    if len(allsq) == n and _valid_solution(allsq, n):
                        sc = sum(sq[3] for sq in allsq)
                        if sc > best_score:
                            best_score = sc
                            best = allsq
    return best

# ----------------------------------------------------------------------------
# Validation
# ----------------------------------------------------------------------------

def _valid_solution(squares, n):
    if len(squares) != n:
        return False
    for sq in squares:
        if len(sq) != 4:
            return False
        cx, cy, ang, side = sq
        if not (0.0 <= cx <= 1.0 and 0.0 <= cy <= 1.0):
            return False
        if not (0.0 <= ang <= 1.0):
            return False
        if side < 0:
            return False
        if not _inside_unit(cx, cy, ang, side):
            return False
    # check overlaps
    for i in range(n):
        for j in range(i + 1, n):
            if _squares_overlap(squares[i], squares[j]):
                return False
    return True

# ----------------------------------------------------------------------------
# Local optimisation
# ----------------------------------------------------------------------------

def _score(params):
    """params: array of 4*n values, each (cx, cy, angle, side)."""
    n = len(params) // 4
    total = 0.0
    squares = []
    for i in range(n):
        cx = params[4*i]
        cy = params[4*i+1]
        ang = params[4*i+2]
        side = params[4*i+3]
        total += side
        squares.append((cx, cy, ang, side))
    return total, squares

def _objective(params):
    """Negative total side length (minimize) with penalties."""
    n = len(params) // 4
    total = 0.0
    squares = []
    for i in range(n):
        cx = params[4*i]
        cy = params[4*i+1]
        ang = params[4*i+2]
        side = params[4*i+3]
        total += side
        squares.append((cx, cy, ang, side))
    penalty = 0.0
    # boundedness
    for sq in squares:
        cx, cy, ang, side = sq
        if side <= 0:
            continue
        pts = _rotated_square_corners(cx, cy, ang, side)
        for px, py in pts:
            if px < 0:
                penalty += 1e3 * (0 - px) ** 2
            if px > 1:
                penalty += 1e3 * (px - 1) ** 2
            if py < 0:
                penalty += 1e3 * (0 - py) ** 2
            if py > 1:
                penalty += 1e3 * (py - 1) ** 2
    # overlap
    for i in range(n):
        for j in range(i + 1, n):
            if squares[i][3] <= 0 or squares[j][3] <= 0:
                continue
            if _squares_overlap(squares[i], squares[j]):
                # compute overlap area approximately
                penalty += 1e3
    return -total + penalty

def _local_optimize(squares, n, maxiter=40):
    """Optimize positions/sizes/angles with bounded scipy or simple random search."""
    # Use scipy minimize with bounds if n is small, else random local search
    # Build initial params
    x0 = np.array([val for sq in squares for val in sq], dtype=float)
    # clip
    x0 = np.clip(x0, 0.0, 1.0)
    
    if n <= 60:
        bounds = []
        for i in range(n):
            bounds.append((0.0, 1.0))  # cx
            bounds.append((0.0, 1.0))  # cy
            bounds.append((0.0, 1.0))  # ang
            bounds.append((0.0, 1.0))  # side
        try:
            res = minimize(_objective, x0, method='L-BFGS-B', bounds=bounds,
                           options={'maxiter': maxiter, 'ftol': 1e-10})
            xnew = res.x
            _, newsq = _score(xnew)
            if _valid_solution(newsq, n):
                sc = sum(sq[3] for sq in newsq)
                oldsc = sum(sq[3] for sq in squares)
                if sc > oldsc:
                    return newsq
        except Exception:
            pass
    
    # Simple local random search (always runs)
    current = list(squares)
    current_score = sum(sq[3] for sq in current)
    best = current
    best_score = current_score
    scale = 0.02
    for it in range(200):
        trial = []
        for sq in current:
            cx, cy, ang, side = sq
            # perturb each parameter
            if random.random() < 0.3:
                cx += random.gauss(0, scale)
            if random.random() < 0.3:
                cy += random.gauss(0, scale)
            if random.random() < 0.2:
                ang += random.gauss(0, scale * 0.5)
            if random.random() < 0.5:
                side += random.gauss(0, scale * 0.5)
            # clip
            cx = min(1.0, max(0.0, cx))
            cy = min(1.0, max(0.0, cy))
            ang = min(1.0, max(0.0, ang))
            side = min(1.0, max(0.0, side))
            trial.append((cx, cy, ang, side))
        # quick validation
        if not _valid_solution(trial, n):
            # try to repair by shrinking sides
            repaired = []
            for sq in trial:
                cx, cy, ang, side = sq
                # shrink until fits
                for _ in range(20):
                    if _inside_unit(cx, cy, ang, side) and not any(
                        _squares_overlap((cx,cy,ang,side), r) for r in repaired
                    ):
                        break
                    side *= 0.9
                repaired.append((cx, cy, ang, side))
            trial = repaired
        if _valid_solution(trial, n):
            sc = sum(sq[3] for sq in trial)
            if sc > current_score:
                current = trial
                current_score = sc
                if sc > best_score:
                    best = trial
                    best_score = sc
        # adaptive scale
        if it % 50 == 49:
            scale *= 0.8
    return best

# ----------------------------------------------------------------------------
# Random restarts
# ----------------------------------------------------------------------------

def _random_grid_solution(n):
    """Generate a random partition into rectangles and fill."""
    best = None
    best_score = -1
    for _ in range(30):
        # random number of strips
        num = random.randint(1, min(n, 12))
        # random directions
        squares = []
        remaining = n
        # split unit square recursively
        rects = [(0.0, 0.0, 1.0, 1.0, n)]
        while rects:
            idx = random.randrange(len(rects))
            x0, y0, w, h, cnt = rects.pop(idx)
            if cnt <= 1:
                part = _fill_rect_with_grid(cnt, x0, y0, w, h)
                squares.extend(part)
            else:
                # random split
                if random.random() < 0.5 or h < 1e-6:
                    # vertical split
                    frac = random.uniform(0.3, 0.7)
                    c1 = random.randint(1, cnt-1)
                    c2 = cnt - c1
                    rects.append((x0, y0, w*frac, h, c1))
                    rects.append((x0 + w*frac, y0, w*(1-frac), h, c2))
                else:
                    frac = random.uniform(0.3, 0.7)
                    c1 = random.randint(1, cnt-1)
                    c2 = cnt - c1
                    rects.append((x0, y0, w, h*frac, c1))
                    rects.append((x0, y0 + h*frac, w, h*(1-frac), c2))
        if len(squares) != n:
            continue
        if _valid_solution(squares, n):
            sc = sum(sq[3] for sq in squares)
            if sc > best_score:
                best_score = sc
                best = squares
    return best

# ----------------------------------------------------------------------------
# Public solve
# ----------------------------------------------------------------------------

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    if n == 2:
        return [(0.25, 0.5, 0.0, 0.5), (0.75, 0.5, 0.0, 0.5)]
    if n == 3:
        side = 1.0 / 3.0
        return [(side*(i+0.5), 0.5, 0.0, side) for i in range(3)]
    
    candidates = []
    
    # Heuristic construction
    c = _construct(n)
    if c is not None and _valid_solution(c, n):
        candidates.append(c)
    
    # Random grid restarts
    for _ in range(20):
        r = _random_grid_solution(n)
        if r is not None:
            candidates.append(r)
    
    # Grid + strips for various numbers of strips
    for ns in range(1, min(n, 20) + 1):
        for vert in (True, False):
            s = _fill_strips(n, ns, vertical=vert)
            if s is not None and len(s) == n and _valid_solution(s, n):
                candidates.append(s)
    
    # main + rest
    for m in range(1, min(n, 40) + 1):
        s = _main_plus_rest(n, m)
        if s is not None:
            candidates.append(s)
    
    if not candidates:
        k = math.isqrt(n)
        side = 1.0 / k
        candidates.append([((i+0.5)*side, (j+0.5)*side, 0.0, side)
                           for i in range(k) for j in range(k)])
        while len(candidates[0]) < n:
            candidates[0].append((0.5, 0.5, 0.0, 0.0))
    
    # pick best
    best = max(candidates, key=lambda s: sum(sq[3] for sq in s))
    
    # try local optimization (limited time)
    import time
    t0 = time.time()
    try:
        opt = _local_optimize(best, n, maxiter=30)
        if opt is not None and _valid_solution(opt, n):
            sc_opt = sum(sq[3] for sq in opt)
            sc_best = sum(sq[3] for sq in best)
            if sc_opt > sc_best:
                best = opt
    except Exception:
        pass
    
    # ensure exactly n
    best = list(best)
    while len(best) < n:
        best.append((0.5, 0.5, 0.0, 0.0))
    best = best[:n]
    
    # final safety clamp and validation
    safe = []
    for sq in best:
        cx, cy, ang, side = sq
        cx = min(1.0, max(0.0, cx))
        cy = min(1.0, max(0.0, cy))
        ang = min(1.0, max(0.0, ang))
        side = min(1.0, max(0.0, side))
        safe.append((cx, cy, ang, side))
    if not _valid_solution(safe, n):
        # fallback
        k = math.isqrt(n)
        side = 1.0 / k
        safe = [((i+0.5)*side, (j+0.5)*side, 0.0, side)
                for i in range(k) for j in range(k)]
        while len(safe) < n:
            safe.append((0.5, 0.5, 0.0, 0.0))
        safe = safe[:n]
    return safe
