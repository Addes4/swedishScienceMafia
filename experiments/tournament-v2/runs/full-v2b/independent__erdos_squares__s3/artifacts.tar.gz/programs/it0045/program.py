import math
import random
import numpy as np
from scipy.optimize import minimize

def solve(n):
    if n <= 0:
        return []
    if n == 1:
        return [(0.5, 0.5, 0.0, 1.0)]
    
    best = None
    best_sum = -1
    
    # Try multiple strategies
    strategies = [
        try_grid,
        try_greedy,
        try_random_packing,
        try_spiral,
    ]
    
    for attempt in range(3):
        for strat in strategies:
            try:
                squares = strat(n)
                if squares and valid_packing(squares):
                    squares = optimize_packing(squares, n)
                    s = sum(sq[3] for sq in squares[:n])
                    if s > best_sum:
                        best_sum = s
                        best = squares[:n]
            except Exception:
                continue
    
    if best is None:
        # fallback
        k = math.isqrt(n)
        side = 1.0 / max(k, 1)
        best = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) 
                for i in range(k) for j in range(k)]
        best += [(0.5, 0.5, 0.0, 0.0)] * (n - len(best))
    
    return best[:n]


def valid_packing(squares):
    """Check if squares are inside unit square and disjoint."""
    for cx, cy, a, s in squares:
        if s < 0:
            return False
        if s == 0:
            continue
        # check corners inside
        ang = a * 2 * math.pi
        c, si = math.cos(ang), math.sin(ang)
        h = s / 2
        corners = [(cx + h*(c- si), cy + h*(si + c)),
                   (cx + h*(-c - si), cy + h*(-si + c)),
                   (cx + h*(-c + si), cy + h*(-si - c)),
                   (cx + h*(c + si), cy + h*(si - c))]
        for x, y in corners:
            if x < -1e-8 or x > 1+1e-8 or y < -1e-8 or y > 1+1e-8:
                return False
    
    # check pairwise disjoint (using separating axis theorem for squares)
    for i in range(len(squares)):
        for j in range(i+1, len(squares)):
            if overlap(squares[i], squares[j]):
                return False
    return True


def overlap(s1, s2):
    cx1, cy1, a1, s1v = s1
    cx2, cy2, a2, s2v = s2
    if s1v == 0 or s2v == 0:
        return False
    
    def get_corners(cx, cy, a, s):
        ang = a * 2 * math.pi
        c, si = math.cos(ang), math.sin(ang)
        h = s / 2
        return [(cx + h*(c - si), cy + h*(si + c)),
                (cx + h*(-c - si), cy + h*(-si + c)),
                (cx + h*(-c + si), cy + h*(-si - c)),
                (cx + h*(c + si), cy + h*(si - c))]
    
    c1 = get_corners(cx1, cy1, a1, s1v)
    c2 = get_corners(cx2, cy2, a2, s2v)
    
    # SAT for convex polygons
    def get_axes(corners):
        axes = []
        for k in range(len(corners)):
            p1 = corners[k]
            p2 = corners[(k+1) % len(corners)]
            edge = (p2[0]-p1[0], p2[1]-p1[1])
            axes.append((-edge[1], edge[0]))
        return axes
    
    for axis in get_axes(c1) + get_axes(c2):
        ax, ay = axis
        nrm = math.hypot(ax, ay)
        if nrm < 1e-12:
            continue
        ax /= nrm
        ay /= nrm
        p1 = [ax*x + ay*y for x, y in c1]
        p2 = [ax*x + ay*y for x, y in c2]
        if max(p1) < min(p2) - 1e-9 or max(p2) < min(p1) - 1e-9:
            return False
    return True


def try_grid(n):
    """Grid-based packing."""
    k = math.isqrt(n)
    squares = []
    if k > 0:
        side = 1.0 / k
        for i in range(k):
            for j in range(k):
                if len(squares) < n:
                    squares.append(((i + 0.5) * side, (j + 0.5) * side, 0.0, side))
    # remaining in a strip
    rem = n - len(squares)
    if rem > 0 and k > 0:
        # try to put them in remaining space
        # use smaller squares in one row
        row_h = 1.0 - k * side
        if row_h > 0:
            w = 1.0 / rem
            h = min(row_h, w)
            for i in range(rem):
                squares.append(((i + 0.5) * w, k * side + h/2, 0.0, h))
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def try_greedy(n):
    """Greedy: build packing by placing squares in best empty spots."""
    squares = []
    # start with a grid
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    
    # instead: place squares one at a time in largest empty square
    placed = []
    for _ in range(n):
        best_pos = None
        best_size = -1
        
        if not placed:
            best_pos = (0.5, 0.5, 0.0)
            best_size = 1.0
        else:
            # sample random positions
            for _ in range(200):
                cx = random.uniform(0.1, 0.9)
                cy = random.uniform(0.1, 0.9)
                ang = random.choice([0, 0.25, 0.125, 0.375, 0.0625, 0.1875, 0.3125, 0.4375])
                # binary search largest size
                lo, hi = 0, 0.5
                for _ in range(20):
                    mid = (lo + hi) / 2
                    test = placed + [(cx, cy, ang, mid)]
                    if valid_packing(test):
                        lo = mid
                    else:
                        hi = mid
                if lo > best_size:
                    best_size = lo
                    best_pos = (cx, cy, ang)
        
        if best_pos and best_size > 0:
            placed.append((best_pos[0], best_pos[1], best_pos[2], best_size))
        else:
            placed.append((0.5, 0.5, 0.0, 0.0))
    
    # try to improve by increasing sizes
    return placed


def try_random_packing(n):
    """Random guillotine-like packing."""
    rects = [(0.0, 0.0, 1.0, 1.0)]
    squares = []
    
    for _ in range(n):
        if not rects:
            squares.append((0.5, 0.5, 0.0, 0.0))
            continue
        # pick largest rect
        idx = max(range(len(rects)), key=lambda i: rects[i][2]*rects[i][3])
        x, y, w, h = rects.pop(idx)
        s = min(w, h)
        if s < 1e-9:
            squares.append((x + w/2, y + h/2, 0.0, 0.0))
            continue
        squares.append((x + s/2, y + s/2, 0.0, s))
        # split remaining
        if w - s > h - s:
            if w - s > 1e-9:
                rects.append((x + s, y, w - s, h))
            if h - s > 1e-9:
                rects.append((x, y + s, s, h - s))
        else:
            if h - s > 1e-9:
                rects.append((x, y + s, w, h - s))
            if w - s > 1e-9:
                rects.append((x + s, y, w - s, s))
    
    return squares[:n]


def try_spiral(n):
    """Spiral arrangement."""
    squares = []
    if n == 0:
        return squares
    
    # place sqrt(n) in a grid
    k = max(1, math.isqrt(n))
    side = 1.0 / k
    count = 0
    for i in range(k):
        for j in range(k):
            if count < n:
                squares.append(((i+0.5)*side, (j+0.5)*side, 0.0, side))
                count += 1
    
    squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
    return squares[:n]


def optimize_packing(squares, n):
    """Improve packing via local search - increase sizes where possible."""
    squares = [list(s) for s in squares[:n]]
    squares += [[0.5, 0.5, 0.0, 0.0]] * (n - len(squares))
    
    # Multiple passes of improvement
    for _ in range(6):
        # try to increase each square's size
        for i in range(n):
            cx, cy, a, s = squares[i]
            if s == 0:
                # try to give it some size
                best_s = 0
                best_pos = (cx, cy, a)
                for _ in range(50):
                    ncx = random.uniform(0.05, 0.95)
                    ncy = random.uniform(0.05, 0.95)
                    na = random.choice([0, 0.25, 0.125, 0.375, 0.5, 0.0625, 0.1875, 0.3125, 0.4375])
                    lo, hi = 0, 0.3
                    for _ in range(15):
                        mid = (lo + hi) / 2
                        test = [list(sq) for sq in squares]
                        test[i] = [ncx, ncy, na, mid]
                        if valid_packing(test):
                            lo = mid
                        else:
                            hi = mid
                    if lo > best_s:
                        best_s = lo
                        best_pos = (ncx, ncy, na)
                squares[i] = [best_pos[0], best_pos[1], best_pos[2], best_s]
            
            # try to shift and rotate to allow bigger size
            cx, cy, a, s = squares[i]
            if s > 0:
                for _ in range(10):
                    ncx = cx + random.uniform(-0.05, 0.05)
                    ncy = cy + random.uniform(-0.05, 0.05)
                    ncx = max(0.01, min(0.99, ncx))
                    ncy = max(0.01, min(0.99, ncy))
                    na = a + random.uniform(-0.1, 0.1)
                    
                    # binary search for max size at new position
                    lo, hi = s, 0.5
                    test = [list(sq) for sq in squares]
                    test[i] = [ncx, ncy, na, lo]
                    if not valid_packing(test):
                        continue
                    for _ in range(20):
                        mid = (lo + hi) / 2
                        test = [list(sq) for sq in squares]
                        test[i] = [ncx, ncy, na, mid]
                        if valid_packing(test):
                            lo = mid
                        else:
                            hi = mid
                    if lo > s:
                        s = lo
                        cx = ncx
                        cy = ncy
                        a = na
                squares[i] = [cx, cy, a, s]
        
        # Try pairwise size rebalancing
        for i in range(n):
            for j in range(n):
                if i != j:
                    si = squares[i][3]
                    sj = squares[j][3]
                    if si > sj and sj >= 0:
                        # try to shrink i and grow j
                        total0 = si + sj
                        delta = 0.01
                        # shrink i
                        test = [list(sq) for sq in squares]
                        test[i][3] = max(0, si - delta)
                        if valid_packing(test):
                            # grow j
                            lo, hi = sj, sj + delta
                            for _ in range(10):
                                mid = (lo + hi) / 2
                                test2 = [list(sq) for sq in test]
                                test2[j][3] = mid
                                if valid_packing(test2):
                                    lo = mid
                                else:
                                    hi = mid
                            if lo > sj:
                                test[j][3] = lo
                                squares = test
    
    # Normalize: ensure all valid
    for i in range(n):
        cx, cy, a, s = squares[i]
        if s < 0:
            squares[i][3] = 0
        if s > 0:
            # clamp position
            squares[i][0] = max(0.0, min(1.0, cx))
            squares[i][1] = max(0.0, min(1.0, cy))
    
    # final validity check & repair
    if not valid_packing(squares):
        # fallback to grid
        k = math.isqrt(n)
        side = 1.0 / max(k, 1)
        squares = [((i + 0.5) * side, (j + 0.5) * side, 0.0, side) 
                   for i in range(k) for j in range(k)]
        squares += [(0.5, 0.5, 0.0, 0.0)] * (n - len(squares))
        squares = [list(s) for s in squares[:n]]
    
    # Random restarts within time budget
    random.seed(42)
    
    return [tuple(s) for s in squares[:n]]
