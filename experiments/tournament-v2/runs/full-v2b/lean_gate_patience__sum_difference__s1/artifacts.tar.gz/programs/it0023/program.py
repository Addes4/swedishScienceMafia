# EVOLVE-BLOCK-START
"""Block construction A = union_i (i*M + D) with fast numpy scorer and block-move search."""
import math
import random
import time
import numpy as np


def _score_np(arr):
    n = arr.size
    if n < 2:
        return 0.0
    d = np.subtract.outer(arr, arr).ravel()
    s = np.add.outer(arr, arr).ravel()
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _golomb(n, span):
    marks = [0]
    used = {0}
    cand = 1
    while len(marks) < n and cand <= span:
        ok = True
        for m in marks:
            if abs(cand - m) in used:
                ok = False
                break
        if ok:
            for m in marks:
                used.add(abs(cand - m))
            marks.append(cand)
        cand += 1
    return marks


def _sidon(n, span):
    """Greedy Sidon set (all pairwise sums distinct) with n elements within span."""
    s = [0]
    sums = {0}
    cand = 1
    while len(s) < n and cand <= span:
        a = cand
        ok = True
        for x in s:
            if a + x in sums:
                ok = False
                break
        if ok:
            for x in s:
                sums.add(a + x)
            sums.add(2 * a)
            s.append(a)
        cand += 1
    return s


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    cache = {}

    def gol(n, span):
        key = (n, span)
        if key not in cache:
            cache[key] = _golomb(n, span)
        return cache[key]

    def sid(n, span):
        key = ('s', n, span)
        if key not in cache:
            cache[key] = _sidon(n, span)
        return cache[key]

    # Block construction: A = union_{i=0..k-1} (i*M + D)
    # D a difference-rich small set (Golomb ruler or Sidon or short AP), M large.
    D_candidates = []
    for m in range(3, 13):
        D_candidates.append(list(range(m)))          # AP: small |D+D|
        D_candidates.append(gol(m, 30 * m))          # Golomb: rich differences
        D_candidates.append(sid(m, 30 * m))          # Sidon: rich sums too

    M_candidates = [37, 60, 120, 300, 700, 1500, 4000, 10000, 30000, 100000]

    for D in D_candidates:
        if len(D) < 3:
            continue
        D = sorted(set(D))
        dmin = min(D)
        D = [x - dmin for x in D]
        dspan = max(D) - min(D)
        for k in range(2, 30):
            if time.time() > deadline:
                break
            for M in M_candidates:
                if M <= dspan + 2:
                    continue
                arr = np.array([i * M + x for i in range(k) for x in D],
                               dtype=np.int64)
                arr = np.unique(arr)
                if arr.size < 2:
                    continue
                sc = _score_np(arr)
                if sc > best_score:
                    best_score = sc
                    best = arr.copy()
            if time.time() > deadline:
                break

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)
        best_score = _score_np(best)

    # Local search: block moves + single-element tweaks.
    cur = best.copy()
    cur_score = best_score
    random.seed(12345)
    it = 0
    maxmag = int(np.max(np.abs(cur))) + 50
    while time.time() < deadline and it < 4000:
        it += 1
        cand = cur.copy()
        r = random.random()
        if r < 0.6:
            k = random.randint(1, max(1, len(cand) // 10))
            idx = np.random.randint(0, len(cand), size=k)
            cand[idx] += np.random.randint(-3, 4, size=k).astype(np.int64)
        elif r < 0.85:
            # shift a whole contiguous block
            cand = np.sort(cand)
            n = len(cand)
            a = random.randint(0, n - 1)
            b = min(n, a + random.randint(1, max(1, n // 5)))
            delta = random.choice([-1, 1]) * random.randint(1, 5)
            cand[a:b] += delta
        else:
            cand = (cur * random.choice((2, 3))).astype(np.int64)
        cand = np.unique(cand)
        if cand.size < 2:
            continue
        sc = _score_np(cand)
        if sc >= cur_score - 1e-12:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand.copy(), sc

    return sorted(int(v) for v in np.unique(best))
# EVOLVE-BLOCK-END
