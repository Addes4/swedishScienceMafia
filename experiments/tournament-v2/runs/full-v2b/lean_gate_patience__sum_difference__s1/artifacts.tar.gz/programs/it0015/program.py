# EVOLVE-BLOCK-START
"""Constructive: union of translated APs sharing step so sums collapse,
with offsets forming a near-Sidon set so differences are plentiful."""
import math
import time

import numpy as np


def _score_np(arr):
    if len(arr) < 2:
        return 0.0
    a = np.unique(np.asarray(arr, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0.0
    d = a[:, None] - a[None, :]
    diffs = np.unique(d)
    s = a[:, None] + a[None, :]
    sums = np.unique(s)
    if sums.size < 2:
        return 0.0
    return math.log(diffs.size) / math.log(sums.size) + (1 - 1 / n) / 100.0


def _golomb_offsets(k, span):
    marks = [0]
    used = {0}
    cand = 1
    while len(marks) < k and cand <= span:
        ok = True
        for m in marks:
            if (cand - m) in used:
                ok = False
                break
        if ok:
            for m in marks:
                used.add(cand - m)
            marks.append(cand)
        cand += 1
    return marks


def solve():
    deadline = time.time() + 105
    best = None
    best_score = -1.0

    # Build candidate sets as union of k APs, each length L, step d,
    # separated by Golomb-like offsets scaled by S.
    configs = []
    for k in (2, 3, 4, 5, 6, 7, 8, 10, 12):
        for L in (2, 3, 4, 5, 6, 8, 10):
            for d in (1, 2, 3):
                for S_mult in (L, L + 1, 2 * L, 2 * L + 1, 3 * L):
                    configs.append((k, L, d, S_mult))

    for (k, L, d, S_mult) in configs:
        if time.time() > deadline:
            break
        span = 120 * k
        offs = _golomb_offsets(k, span)
        if len(offs) < k:
            continue
        offs = offs[:k]
        Sp = S_mult * d
        A = []
        for o in offs:
            base = o * Sp
            for j in range(L):
                A.append(base + j * d)
        sc = _score_np(A)
        if sc > best_score:
            best_score = sc
            best = A[:]

    if best is None:
        best = [0, 1, 2, 3]

    # Small exact refinement: try tweaking a few elements to squeeze ratio.
    cur = np.unique(np.asarray(best, dtype=np.int64)).tolist()
    cur_score = _score_np(cur)
    rng = np.random.default_rng(12345)

    it = 0
    while time.time() < deadline and it < 4000:
        it += 1
        cand = list(cur)
        r = rng.random()
        if r < 0.5:
            # randomly perturb one element
            i = int(rng.integers(0, len(cand)))
            cand[i] += int(rng.integers(-3, 4))
        elif r < 0.8:
            # add an element near existing cluster
            j = int(rng.integers(0, len(cand)))
            cand.append(cand[j] + int(rng.integers(-5, 6)))
        else:
            if len(cand) > 4:
                i = int(rng.integers(0, len(cand)))
                cand.pop(i)
        cand = np.unique(np.asarray(cand, dtype=np.int64)).tolist()
        if len(cand) < 2:
            continue
        sc = _score_np(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
