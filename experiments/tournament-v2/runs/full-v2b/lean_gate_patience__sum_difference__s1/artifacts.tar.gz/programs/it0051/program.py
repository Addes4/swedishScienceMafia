# EVOLVE-BLOCK-START
"""
Constructive multi-cluster builder.

Idea: A = union_{i=1..g} ( b_i + {0,1,...,L-1} )

If the L elements inside each cluster are consecutive integers, then:
  - A + A = union_{i,j} (b_i + b_j + {0..2L-2})
  So sums are limited to (about) g^2 intervals, each of length 2L-1.
  - A - A = union_{i,j} (b_i - b_j + {-(L-1)..L-1})
  Differences also lie in g^2 intervals.

The ratio is set by the relative density of distinct differences vs distinct sums.
By choosing the offsets b_i Golomb-ruler-like (well separated, all pairwise
differences distinct), the difference set is nearly g*(g-1) + 2g-1 distinct
blocks, mostly disjoint => |A-A| ~ g^2 * (2L-1). The sum set is similar size
(if offsets collide we still get fewer distinct sums than a truly random set of
the same size would produce, because they are concentrated in blocks), but
crucially we then Greedily polish: try adding elements outside clusters (which
add new differences in fresh places) and removing elements from clusters (which
loses fewer differences than sums since differences are more redundant). We
short locally via small random-like perturbations.

The whole thing runs on purely constructive building + local polish.
"""

import math
import random
import time


def _score(a):
    a = list(a)
    n = len(a)
    if n < 2:
        return 0.0
    s = set(a)
    n = len(s)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in s:
        for y in s:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score_fast(a):
    """Cheap version used during search where duplicates are not expected."""
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if nd < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _make_set(g, L, spacing):
    """Build g clusters each being {0..L-1} shifted by Golomb-like offsets."""
    # Golomb ruler via simple greedy: pick each new offset so that all pairwise
    # differences (offsets and their extensions) are distinct as much as possible.
    offsets = [0]
    used_diff = {0}
    # We'll pick offsets spaced far apart, roughly "Sidon-like" at scale spacing.
    # A raw Golomb ruler of order g has marks up to ~ g^2 * spacing, giving
    # good spread of cross-cluster differences.
    cur = 0
    step = spacing
    # simple greedy: each candidate offset chosen to introduce as few duplicate
    # pairwise differences with prior offsets as possible.
    for i in range(1, g):
        best_off = cur + step
        best_cost = None
        # try a few step lengths and pick the one whose new pairwise differences
        # are most distinct from the existing set
        for mult in (1, 2, 3, 4, 5, 7, 9, 12, 16):
            cand = cur + step * mult
            cost = 0
            for o in offsets:
                d = cand - o
                if d in used_diff:
                    cost += 1
                if -d in used_diff:
                    cost += 1
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best_off = cand
            if cost == 0:
                break
        offsets.append(best_off)
        for o in offsets:
            used_diff.add(best_off - o)
            used_diff.add(o - best_off)
        cur = best_off
    a = []
    for b in offsets:
        for k in range(L):
            a.append(b + k)
    a = sorted(set(a))
    return a, offsets


def _greedy_polish(a, deadline, verbose=False):
    """Add/remove/adjust to try to improve score."""
    a = list(dict.fromkeys(a))  # preserve order, drop dups
    cur = sorted(set(a))
    if not cur:
        return cur
    best_score = _score_fast(cur)
    cont = True
    # Repeated single-element moves: removals, small shifts, additions.
    while time.time() < deadline and cont:
        cont = False
        improved = False
        # try removals
        i = 0
        while i < len(cur):
            if time.time() > deadline:
                break
            cand = cur[:i] + cur[i + 1:]
            if len(cand) < 2:
                i += 1
                continue
            sc = _score_fast(cand)
            # importance: difference dimension loss vs sum dimension loss
            if sc > best_score + 1e-12:
                cur = cand
                best_score = sc
                improved = True
                cont = True
            else:
                i += 1
        # try small shifts
        for i in range(len(cur)):
            if time.time() > deadline:
                break
            orig = cur[i]
            for delta in (-2, -1, 1, 2, -3, 3, -5, 5):
                cand = cur[:]
                cand[i] = orig + delta
                cand = sorted(set(cand))
                if len(cand) < 2:
                    continue
                sc = _score_fast(cand)
                if sc > best_score + 1e-12:
                    cur = cand
                    best_score = sc
                    improved = True
                    cont = True
                    break
        # try additions in fresh locations
        lo = min(cur)
        hi = max(cur)
        span = hi - lo if hi > lo else 1
        for _ in range(4):
            if time.time() > deadline:
                break
            # candidate positions: near the boundaries plus random interior
            pos = random.randrange(lo - span, hi + span + 1) if random.random() < 0.5 \
                else random.choice([lo - 1, lo - 2, lo - 3, hi + 1, hi + 2, hi + 3])
            if pos in cur:
                continue
            cand = sorted(cur + [pos])
            sc = _score_fast(cand)
            if sc > best_score + 1e-12:
                cur = cand
                best_score = sc
                improved = True
                cont = True
        if improved and verbose:
            pass
    return cur


def solve():
    random.seed(12345)
    deadline = time.time() + 110

    best = None
    best_score = -1.0

    # Try a range of (g, L, spacing) configurations.
    configs = []
    for g in (3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 30, 40, 50):
        for L in (2, 3, 4, 5, 6, 8, 10):
            for spacing in (1, 2, 3, 5, 8, 13, 21):
                configs.append((g, L, spacing))
    # randomize order a bit, but keep deterministic seed
    random.shuffle(configs)

    for (g, L, spacing) in configs:
        if time.time() > deadline - 5:
            break
        try:
            a, _ = _make_set(g, L, spacing)
        except Exception:
            continue
        if len(a) < 2 or len(a) > 4000:
            continue
        sc = _score_fast(a)
        if sc > best_score:
            best_score = sc
            best = a[:]

    # If a reasonable candidate found, polish it harder.
    if best is None:
        best = [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377]

    # Polish the best candidate as far as time allows.
    polished = _greedy_polish(best, deadline)
    pscore = _score_fast(polished)
    if pscore > best_score:
        best = polished
        best_score = pscore

    # A few more rounds of polish from perturbed copies.
    for _ in range(3):
        if time.time() > deadline - 2:
            break
        base = list(best)
        # random perturb: shift a few elements
        for _ in range(random.randint(1, 3)):
            if not base:
                break
            i = random.randrange(len(base))
            base[i] += random.randint(-2, 2)
        base = sorted(set(base))
        cand = _greedy_polish(base, deadline)
        sc = _score_fast(cand)
        if sc > best_score:
            best = cand
            best_score = sc

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
