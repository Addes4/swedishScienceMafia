# EVOLVE-BLOCK-START
"""Constructive multi-cluster AP builder + greedy polish for many differences / few sums."""
import math
import time
import random
import itertools


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            sums.add(ai + a[j])
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _build(offsets, length, step):
    a = []
    for o in offsets:
        for k in range(length):
            a.append(o + k * step)
    return a


def _golomb(r, seed=0):
    """Greedy Golomb ruler of r marks starting at 0."""
    marks = [0]
    used = {0}
    while len(marks) < r:
        best = None
        for cand in range(marks[-1] + 1, marks[-1] + 400):
            ok = True
            for m in marks:
                d = cand - m
                if d in used:
                    ok = False
                    break
            if ok:
                for m in marks:
                    used.add(cand - m)
                best = cand
                break
        if best is None:
            best = marks[-1] + 1
            for m in marks:
                used.add(best - m)
        marks.append(best)
    return marks


def _polish(a, deadline, base_score):
    """Greedy add/remove/adjust local search."""
    a = list(set(a))
    best = a[:]
    bs = _score(best)
    tries = 0

    def ev(lst):
        return _score(lst)

    while time.time() < deadline:
        tries += 1
        improved = False

        # try removing each element
        if len(a) > 8:
            for i in range(len(a)):
                cand = a[:i] + a[i + 1:]
                s = ev(cand)
                if s > bs:
                    bs = s
                    a = cand
                    best = cand[:]
                    improved = True
                    break
        if improved:
            continue

        # try adjusting each element a bit
        span = max(a) - min(a) if a else 1
        step = max(1, span // 200)
        for i in range(len(a)):
            for delta in (step, -step, 1, -1):
                cand = a[:]
                cand[i] = cand[i] + delta
                if len(set(cand)) != len(cand):
                    continue
                s = ev(cand)
                if s > bs:
                    bs = s
                    a = cand
                    best = cand[:]
                    improved = True
                    break
            if improved:
                break
        if improved:
            continue

        # try adding an element
        lo, hi = min(a) - 3 * step, max(a) + 3 * step
        for _ in range(30):
            v = random.randint(lo, hi)
            if v in a:
                continue
            cand = a + [v]
            s = ev(cand)
            if s > bs:
                bs = s
                a = cand
                best = cand[:]
                improved = True
                break
        if not improved:
            break

    return best


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Phase 1: try a variety of multi-cluster configurations.
    configs = []
    for g in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20):
        for L in (2, 3, 4, 5, 6, 8, 10):
            for step in (1, 2, 3, 5):
                configs.append((g, L, step))
    random.shuffle(configs)

    tested = 0
    for (g, L, step) in configs:
        if time.time() > deadline - 20:
            break
        offsets = _golomb(g)
        offsets = [o * step for o in offsets]
        a = _build(offsets, L, step)
        a = list(set(a))
        if len(a) < 2:
            continue
        s = _score(a)
        tested += 1
        # quick polish on promising candidates
        if s > best_score - 0.15 or tested % 40 == 0:
            pb = min(deadline - 5, time.time() + 2.0)
            a2 = _polish(a, pb, s)
            s2 = _score(a2)
            if s2 > best_score:
                best_score = s2
                best = a2
        if s > best_score:
            best_score = s
            best = a

    # Phase 2: polish the best found with the full remaining time.
    if best is None:
        best = _build(_golomb(8), 4, 1)
        best_score = _score(best)

    best = _polish(best, deadline, best_score)

    # Phase 3: light randomized perturbation escape.
    cur = best[:]
    cur_s = _score(cur)
    while time.time() < deadline:
        cand = cur[:]
        op = random.random()
        if op < 0.4 and len(cand) > 2:
            cand.pop(random.randrange(len(cand)))
        elif op < 0.8:
            cand.append(random.randint(min(cand) - 5, max(cand) + 5))
        else:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-2, 2)
        cand = list(set(cand))
        if len(cand) < 2:
            continue
        s = _score(cand)
        if s > cur_s:
            cur, cur_s = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif random.random() < 0.05:
            cur = best[:]
            cur_s = _score(cur)

    return sorted(set(best))


if __name__ == "__main__":
    a = solve()
    a = list(set(a))
    if len(a) > 4000:
        a = a[:4000]
    print(len(a), _score(a))
# EVOLVE-BLOCK-END
