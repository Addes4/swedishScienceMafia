# EVOLVE-BLOCK-START
"""Constructive multi-cluster arithmetic-progression builder with greedy polish.

Idea: A = union over i of (base_i + {0, d, 2d, ..., (L-1)d}).
Within one cluster, sums are 2*base_i + k*d for k in [0, 2L-2], so |A+A|_intra = 2L-1.
Across g clusters we get ~g^2*(2L-1) sums and ~g^2*(2L-1) differences, but differences
from distinct clusters are spread over a wider range, and we can push clusters apart so
cross differences fill a long interval (good for |A-A|) while cross sums also concentrate.
Offsets chosen like a Golomb ruler to keep cross-differences distinct-ish and sum range tight.
"""
import math
import random
import time


def _stats(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 1, 1, 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    score = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return len(diffs), len(sums), score


def _build(g, L, d, span):
    """g clusters, each an AP of length L step d. Offsets spread over [-span, span]
    using a Golomb-ruler-ish greedy greedy: pick offsets maximizing pairwise
    distinctness of cross differences modulo a range."""
    rng = random.Random(12345)
    offsets = [0]
    # greedy Golomb-like: each new offset maximizes min pairwise difference so far
    used = {0}
    for _ in range(g - 1):
        best_off = None
        best_val = -1
        for _try in range(60):
            cand = rng.randint(-span, span)
            if cand in used:
                continue
            # min distance to existing offsets (prefer spread => large diff range)
            md = min(abs(cand - o) for o in offsets)
            # and prefer moderate offset to keep sums from spreading too much:
            tight = -abs(cand) * 0.001
            v = md + tight
            if v > best_val:
                best_val = v
                best_off = cand
        if best_off is None:
            best_off = rng.randint(-span, span)
        offsets.append(best_off)
        used.add(best_off)
    A = []
    for o in offsets:
        for k in range(L):
            A.append(o + k * d)
    return sorted(set(A))


def _polish(A, deadline, start_score):
    """Greedy add/remove/adjust polish on top of the construction."""
    A = sorted(set(A))
    best = A[:]
    _, _, best_score = _stats(best)
    cur = best[:]
    n = len(cur)
    # range for adjustments
    lo = min(cur) - 3
    hi = max(cur) + 3
    step = max(1, (hi - lo) // 200)

    while time.time() < deadline:
        improved = False
        # try remove an element
        if len(cur) > 6:
            for i in range(len(cur)):
                cand = cur[:i] + cur[i + 1:]
                _, _, s = _stats(cand)
                if s > best_score:
                    best_score = s
                    best = cand[:]
                    cur = cand[:]
                    improved = True
                    break
        if improved:
            continue
        # try add an element from a candidate pool
        pool = set()
        for x in cur:
            for delta in (-2, -1, 1, 2, -3, 3, -5, 5):
                pool.add(x + delta)
        for x in list(cur):
            pool.add(x)
        pool.discard(0)
        cand_pool = [v for v in pool if v not in set(cur)]
        rng = random.Random(int(time.time() * 1000) % 100000)
        rng.shuffle(cand_pool)
        for v in cand_pool[:80]:
            cand = cur + [v]
            _, _, s = _stats(cand)
            if s > best_score:
                best_score = s
                best = cand[:]
                cur = cand[:]
                improved = True
                break
        if improved:
            continue
        # try adjust one element by +-1..3 (bounded span)
        for i in range(len(cur)):
            for delta in (-1, 1, -2, 2, -3, 3):
                cand = cur[:]
                cand[i] += delta
                if len(set(cand)) < len(cand):
                    continue
                _, _, s = _stats(cand)
                if s > best_score:
                    best_score = s
                    best = cand[:]
                    cur = cand[:]
                    improved = True
                    break
            if improved:
                break
        if not improved:
            break
    return best


def solve():
    """Return a list of distinct integers A with large A-A and small A+A."""
    best = [0, 1, 2, 3, 4, 5]
    _, _, best_score = _stats(best)
    deadline = time.time() + 110

    # try a family of parametric constructions, keep the best
    configs = []
    for g in (2, 3, 4, 5, 6, 7, 8):
        for L in (3, 4, 5, 6, 7, 8, 9, 10):
            for d in (1, 2, 3, 4, 5, 6, 8, 10, 12):
                for span in (5, 10, 20, 40, 80, 160, 320):
                    configs.append((g, L, d, span))

    random.Random(999).shuffle(configs)
    time_per = max(0.5, min(8.0, 100.0 / max(1, len(configs) // 40)))

    for (g, L, d, span) in configs:
        if time.time() > deadline - 2:
            break
        A = _build(g, L, d, span)
        if len(A) < 2:
            continue
        _, _, s = _stats(A)
        if s > best_score:
            best_score = s
            best = A[:]
        # quick local improvement with a small budget
        t_end = min(deadline, time.time() + time_per)
        A2 = _polish(A, t_end, s)
        _, _, s2 = _stats(A2)
        if s2 > best_score:
            best_score = s2
            best = A2[:]

    # final polish on the overall best
    if time.time() < deadline - 1:
        best = _polish(best, deadline - 0.5, best_score)

    best = sorted(set(int(x) for x in best))
    return best
# EVOLVE-BLOCK-END
