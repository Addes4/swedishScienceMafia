# EVOLVE-BLOCK-START
"""Constructive approach: union of translated arithmetic progressions at Golomb-like offsets."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _golomb(n, span):
    """Greedy Golomb-ruler-like set of n offsets with distinct pairwise differences."""
    marks = [0]
    used = {0}
    cand = 1
    while len(marks) < n and cand <= span:
        ok = True
        for m in marks:
            if abs(cand - m) in used:
                ok = False
                break
        if ok:
            for m in marks:
                used.add(abs(cand - m))
            marks.append(cand)
        cand += 1
    return marks


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Try many configurations: k clusters, each an AP of length L with step d,
    # cluster offsets from a Golomb ruler.
    configs = []
    for k in range(2, 9):
        for L in range(2, 8):
            for d in (1, 2, 3, 4, 5):
                configs.append((k, L, d))
    random.shuffle(configs)

    for (k, L, d) in configs:
        if time.time() > deadline:
            break
        span = 60 * k
        offs = _golomb(k, span)
        if len(offs) < k:
            continue
        # scale spacing large enough that intra-cluster sums collide but
        # cross-cluster differences stay distinct-ish
        spacing = d * (L + 1)
        A = []
        for o in offs:
            base = o * spacing
            for j in range(L):
                A.append(base + j * d)
        sc = _score(A)
        if sc > best_score:
            best_score = sc
            best = A[:]

    # Local refinement: shift clusters / tweak step.
    if best is None:
        best = [0, 1, 2, 3]
    cur = sorted(set(best))
    cur_score = _score(cur)

    it = 0
    while time.time() < deadline and it < 100000:
        it += 1
        cand = cur[:]
        op = random.random()
        if op < 0.4 and cand:
            i = random.randrange(len(cand))
            cand[i] += random.randint(-2, 2)
        elif op < 0.7 and cand:
            i = random.randrange(len(cand))
            if len(cand) > 3:
                cand.pop(i)
        elif len(cand) < 2000:
            cand.append(random.randint(-2000, 2000))
        cand = sorted(set(cand))
        sc = _score(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc

    return sorted(set(best))
# EVOLVE-BLOCK-END
