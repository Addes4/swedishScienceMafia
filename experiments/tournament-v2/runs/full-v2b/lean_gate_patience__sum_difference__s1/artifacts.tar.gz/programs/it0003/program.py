# EVOLVE-BLOCK-START
"""Greedy Sidon (Golomb ruler) construction with random restarts + local polish.

A Golomb ruler has all pairwise differences distinct, so |A - A| = n^2 - n + 1
(theoretical max for a set of size n).  We grow such a set greedily, trying many
random orders/shifts, and keep whichever set gives the best ratio
log|A-A| / log|A+A|.  A short sign-flip local search tries to shrink |A+A|.
"""
import math
import random
import time


def _score_parts(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100, len(diffs), len(sums)


def _score(a):
    return _score_parts(a)[0]


def _greedy_sidon(n, maxval, rng):
    """Build a set of size ~n with as many distinct differences as possible."""
    # start from a random small seed pair
    a = [0, rng.randint(1, 3)]
    diffs = {a[0] - a[1], a[1] - a[0], 0}
    while len(a) < n:
        # collect candidate values not creating duplicate differences
        best_c = None
        # gather candidates; shuffle and take first valid ones
        cands = list(range(maxval + 1))
        rng.shuffle(cands)
        # try to add a value that keeps as many differences distinct as possible
        for c in cands:
            if c in a:
                continue
            new_diffs = set()
            ok = True
            for x in a:
                d1 = c - x
                d2 = x - c
                if d1 in diffs or d2 in diffs:
                    ok = False
                    break
                new_diffs.add(d1)
                new_diffs.add(d2)
            if ok:
                best_c = c
                break
        if best_c is None:
            return a
        a.append(best_c)
        for x in a[:-1]:
            diffs.add(best_c - x)
            diffs.add(x - best_c)
    return a


def solve():
    rng = random.Random(12345)
    deadline = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # many random greedy Sidon attempts with increasing sizes
    trial = 0
    while time.time() < deadline:
        trial += 1
        n = rng.randint(8, 30)
        maxval = n * n  # dense range keeps sums small-ish
        a = _greedy_sidon(n, maxval, rng)
        s = _score(a)
        if s > best_score:
            best, best_score = a[:], s
        # also try small translations
        for _ in range(3):
            t = rng.randint(-3, 3)
            b = [x + t for x in a]
            sb = _score(b)
            if sb > best_score:
                best, best_score = b, sb
        if trial % 200 == 0 and time.time() > deadline - 5:
            break

    # short local search: sign flips and small perturbations
    cur = best[:]
    cur_score = best_score
    while time.time() < deadline:
        cand = cur[:]
        i = rng.randrange(len(cand))
        move = rng.choice([1, -1]) * rng.randint(1, 4)
        cand[i] += move
        if len(set(cand)) != len(cand):
            continue
        s = _score(cand)
        if s > cur_score:
            cur, cur_score = cand, s
            if s > best_score:
                best, best_score = cand[:], s
        elif rng.random() < 0.05:
            cur, cur_score = best[:], best_score

    return sorted(set(best))
# EVOLVE-BLOCK-END
