# EVOLVE-BLOCK-START
"""Two-interval construction A = {0..L-1} U (Q + {0..L-1}) optimized directly
by the true objective log|A-A| / log|A+A| (plus size bonus).

Key structure: within-block sums collide onto a short interval; the union of
the two block-sum intervals is short -> few sums. Differences between the two
blocks spread over a long interval -> many differences.  We sweep (L, Q).
"""
import math
import time

import numpy as np


def _true_score(a):
    a = sorted(set(int(x) for x in a))
    n = len(a)
    if n < 2:
        return 0.0
    arr = np.array(a, dtype=np.int64)
    sums = np.unique(arr[:, None] + arr[None, :])
    diffs = np.unique(arr[:, None] - arr[None, :])
    ns = len(sums)
    nd = len(diffs)
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _build(L, Q):
    a = list(range(0, L))
    a += [Q + k for k in range(L)]
    return a


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Coarse sweep over (L, Q).  Larger L and Q give more differences.
    # We cap |A| at 4000, so 2L <= 4000 -> L <= 2000.
    Ls = [10, 20, 30, 40, 60, 80, 100, 140, 180, 250, 350, 500, 700, 1000,
          1300, 1600, 1900]
    # Q relative scale: Q roughly >= 2L so the two intervals are disjoint.
    Qs_rel = [1.5, 2.0, 2.5, 3.0, 4.0, 6.0, 9.0, 14.0, 20.0, 30.0, 50.0,
              80.0, 130.0]

    coarse = []
    for L in Ls:
        for r in Qs_rel:
            Q = int(round(L * r))
            if Q < L + 1:
                Q = L + 1
            coarse.append((L, Q))

    for (L, Q) in coarse:
        if time.time() > deadline - 25:
            break
        cand = _build(L, Q)
        s = _true_score(cand)
        if s > best_score:
            best_score = s
            best = cand
    if best is None:
        best = _build(100, 300)
        best_score = _true_score(best)

    # Local refinement around the best (L, Q), plus a few of the top configs.
    # Sort coarse results quickly by rescoring the best few is expensive, so we
    # just refine around the current best and a handful of promising sizes.
    seeds = [(len(best) // 2, (max(best) - min(best)) // 2)]
    seeds.append((len(best) // 2, max(best) - min(best) - (len(best) // 2 - 1)))

    refined = set()
    for (L0, Q0) in seeds:
        refined.add((L0, Q0))

    # broad local grid: vary L and Q around best with several step sizes.
    for stepL, stepQ in ((1, 1), (2, 3), (5, 7), (10, 15), (25, 40), (60, 100)):
        newr = []
        for (L0, Q0) in list(refined):
            for dL in (-stepL, 0, stepL):
                for dQ in (-stepQ, 0, stepQ):
                    L = L0 + dL
                    Q = Q0 + dQ
                    if 2 <= L <= 2000 and Q >= L + 1:
                        newr.append((L, Q))
        refined.update(newr)

    # Evaluate refined candidates; keep the best.
    for (L, Q) in refined:
        if time.time() > deadline - 2:
            break
        cand = _build(L, Q)
        s = _true_score(cand)
        if s > best_score:
            best_score = s
            best = cand

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END
