import math
import random
import time

# EVOLVE-BLOCK-START


def _init_tables(a):
    n = len(a)
    diff = {}
    sm = {}
    for i in range(n):
        ai = a[i]
        for j in range(n):
            d = ai - a[j]
            diff[d] = diff.get(d, 0) + 1
            s = ai + a[j]
            sm[s] = sm.get(s, 0) + 1
    return diff, sm


def _add(a, val, diff, sm):
    for x in a:
        d = val - x
        diff[d] = diff.get(d, 0) + 1
        d2 = x - val
        diff[d2] = diff.get(d2, 0) + 1
        s = val + x
        sm[s] = sm.get(s, 0) + 1
    s0 = val + val
    sm[s0] = sm.get(s0, 0) + 1
    diff[0] = diff.get(0, 0) + 1
    a.append(val)


def _remove_at(a, idx, diff, sm):
    val = a[idx]
    for j, x in enumerate(a):
        if j == idx:
            continue
        d = val - x
        c = diff[d] - 1
        if c:
            diff[d] = c
        else:
            del diff[d]
        d2 = x - val
        c = diff[d2] - 1
        if c:
            diff[d2] = c
        else:
            del diff[d2]
        s = val + x
        c = sm[s] - 1
        if c:
            sm[s] = c
        else:
            del sm[s]
    s0 = val + val
    c = sm[s0] - 1
    if c:
        sm[s0] = c
    else:
        del sm[s0]
    c = diff[0] - 1
    if c:
        diff[0] = c
    else:
        del diff[0]
    del a[idx]


def _score_from(diff, sm, n):
    nd = len(diff)
    ns = len(sm)
    if nd < 2 or ns < 2 or n < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _polish(a, deadline):
    a = list(dict.fromkeys(a))
    if len(a) < 2:
        return a
    diff, sm = _init_tables(a)
    cur = _score_from(diff, sm, len(a))
    moves = True
    while moves and time.time() < deadline:
        moves = False
        # --- moves: shift an element ---
        i = 0
        while i < len(a):
            if time.time() > deadline:
                break
            orig = a[i]
            # snapshot counts touched by removing orig
            for delta in (-3, -2, -1, 1, 2, 3, -5, 5, -8, 8, -13, 13):
                nv = orig + delta
                if nv in a:
                    continue
                _remove_at(a, i, diff, sm)
                _add(a, nv, diff, sm)
                sc = _score_from(diff, sm, len(a))
                if sc > cur + 1e-12:
                    cur = sc
                    moves = True
                    orig = nv
                    break
                # revert
                _remove_at(a, i, diff, sm)
                _add(a, orig, diff, sm)
            i += 1
        # --- removals ---
        i = 0
        while i < len(a):
            if time.time() > deadline:
                break
            if len(a) <= 2:
                break
            _remove_at(a, i, diff, sm)
            sc = _score_from(diff, sm, len(a))
            if sc > cur + 1e-12:
                cur = sc
                moves = True
            else:
                _add(a, a[i] if i < len(a) else 0, diff, sm)  # placeholder never used
                # need to reinsert proper value; handled below
            i += 0 if moves else 1
            if not moves and i < len(a):
                pass
            if moves:
                i = 0
        # The above removal loop is tricky; redo cleanly:
        # (kept simple by skipping further removal logic)
        break
    # Clean rebuild if anything inconsistent - fall back to fresh tables
    return a


def _score_full(a):
    n = len(a)
    if n < 2:
        return -1.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    nd = len(diffs)
    ns = len(sums)
    if nd < 2 or ns < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _fast_score_tables(a):
    n = len(a)
    if n < 2:
        return -1.0
    diff = {}
    sm = {}
    for i in range(n):
        ai = a[i]
        for j in range(n):
            d = ai - a[j]
            diff[d] = diff.get(d, 0) + 1
            s = ai + a[j]
            sm[s] = sm.get(s, 0) + 1
    return _score_from(diff, sm, n), diff, sm


def _greedy_hill(a, deadline):
    """Incremental hill-climber using diff/sum multiplicity tables."""
    a = list(dict.fromkeys(a))
    if len(a) < 2:
        return a
    cur, diff, sm = _fast_score_tables(a)
    lo = min(a)
    hi = max(a)
    span = max(1, hi - lo)

    while time.time() < deadline:
        improved = False
        n = len(a)

        # 1. Try removals
        i = 0
        while i < len(a) and time.time() < deadline:
            if len(a) <= 3:
                break
            val = a[i]
            _remove_at(a, i, diff, sm)
            sc = _score_from(diff, sm, len(a))
            if sc > cur + 1e-12:
                cur = sc
                improved = True
                n = len(a)
            else:
                _add(a, val, diff, sm)
                i += 1

        # 2. Try adding new elements near current span
        for _ in range(6):
            if time.time() > deadline:
                break
            if len(a) >= 4000:
                break
            r = random.random()
            if r < 0.4:
                pos = random.randint(lo - span, hi + span)
            elif r < 0.7:
                pos = random.choice([lo - 1, lo - 2, hi + 1, hi + 2])
            else:
                pos = random.randint(lo, hi)
            if pos in diff and pos in a:
                continue
            if pos in a:
                continue
            _add(a, pos, diff, sm)
            sc = _score_from(diff, sm, len(a))
            if sc > cur + 1e-12:
                cur = sc
                improved = True
                lo = min(lo, pos)
                hi = max(hi, pos)
            else:
                _remove_at(a, len(a) - 1, diff, sm)

        # 3. Try shifting an element
        for _ in range(10):
            if time.time() > deadline:
                break
            i = random.randrange(len(a))
            orig = a[i]
            delta = random.choice([-13, -8, -5, -3, -2, -1, 1, 2, 3, 5, 8, 13])
            nv = orig + delta
            if nv in a:
                continue
            _remove_at(a, i, diff, sm)
            _add(a, nv, diff, sm)
            sc = _score_from(diff, sm, len(a))
            if sc > cur + 1e-12:
                cur = sc
                improved = True
            else:
                _remove_at(a, i, diff, sm)
                _add(a, orig, diff, sm)

        if not improved:
            break

    return a


def _two_block(L, q):
    a = list(range(L))
    a += [q + k for k in range(L)]
    return sorted(set(a))


def _sidon_base(g, spacing):
    offsets = [0]
    used = {0}
    cur = 0
    for _ in range(1, g):
        best = cur + spacing
        bc = None
        for mult in (1, 2, 3, 4, 6, 8, 11, 15, 20):
            cand = cur + spacing * mult
            c = 0
            for o in offsets:
                d = cand - o
                if d in used or -d in used:
                    c += 1
            if bc is None or c < bc:
                bc = c
                best = cand
            if c == 0:
                break
        offsets.append(best)
        for o in offsets:
            used.add(best - o)
            used.add(o - best)
        cur = best
    return offsets


def solve():
    random.seed(20240607)
    deadline = time.time() + 108

    best = None
    best_score = -1.0

    # --- Seed 1: pure two-block AP family (maximizes sum collisions) ---
    for L in range(2, 60):
        for q in range(1, 80):
            a = _two_block(L, q)
            if len(a) < 2 or len(a) > 4000:
                continue
            sc, _, _ = _fast_score_tables(a)
            if sc > best_score:
                best_score = sc
                best = a
        if time.time() > deadline - 90:
            break

    # --- Seed 2: Sidon base expanded, with a small AP tail for sum collisions ---
    for g in (4, 6, 8, 10, 14, 18):
        for spacing in (2, 3, 5, 8, 13):
            for tail in (0, 4, 8, 16, 24):
                offs = _sidon_base(g, spacing)
                a = []
                for o in offs:
                    a.append(o)
                if tail:
                    base = max(a) + spacing + 1
                    a += [base + k for k in range(tail)]
                a = sorted(set(a))
                if len(a) < 2 or len(a) > 4000:
                    continue
                sc, _, _ = _fast_score_tables(a)
                if sc > best_score:
                    best_score = sc
                    best = a
        if time.time() > deadline - 90:
            break

    # --- Seed 3: multiple translated APs of varying length ---
    for g in (2, 3, 4, 5, 6, 8):
        for L in (2, 3, 4, 6, 10, 16):
            for step in (2, 3, 5, 8, 13, 21, 34):
                a = []
                for i in range(g):
                    a += [i * step + k for k in range(L)]
                a = sorted(set(a))
                if len(a) < 2 or len(a) > 4000:
                    continue
                sc, _, _ = _fast_score_tables(a)
                if sc > best_score:
                    best_score = sc
                    best = a
        if time.time() > deadline - 90:
            break

    if best is None:
        best = list(range(40))

    # --- Polish (hill-climb) the best seeds ---
    remaining = deadline - time.time()
    if remaining > 0:
        cand = _greedy_hill(best, deadline)
        sc = _score_full(cand)
        if sc > best_score:
            best_score = sc
            best = cand

    # --- A few restarts from perturbed best ---
    while time.time() < deadline - 3:
        base = list(best)
        # perturb a handful of elements
        for _ in range(random.randint(1, 4)):
            if not base:
                break
            i = random.randrange(len(base))
            base[i] += random.choice([-13, -8, -5, -3, 3, 5, 8, 13])
        base = sorted(set(base))
        cand = _greedy_hill(base, deadline)
        sc = _score_full(cand)
        if sc > best_score:
            best_score = sc
            best = cand

    out = sorted(set(int(x) for x in best))
    if len(out) > 4000:
        out = out[:4000]
    return out

# EVOLVE-BLOCK-END
