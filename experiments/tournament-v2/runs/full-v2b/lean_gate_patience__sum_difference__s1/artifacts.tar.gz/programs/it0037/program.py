# EVOLVE-BLOCK-START
"""Multi-cluster arithmetic-progression builder plus a fast incremental local search.

Seed: A = union of g translated copies of a short AP placed at Golomb-ruler offsets,
so within-cluster sums collide while cross-cluster differences fill a wide range.
Polish: incremental diff/sum multiplicity dictionaries give O(n) exact scoring of
add / remove / shift moves, so we can run vastly more iterations and grow |A|.
"""
import math
import random
import time


def _score_from(nd, ns, n):
    if ns < 2 or nd < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _stats(a):
    a = list(dict.fromkeys(a))
    n = len(a)
    if n < 2:
        return 1, 1, 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
        for j in range(i, n):
            sums.add(ai + a[j])
    nd = len(diffs)
    ns = len(sums)
    return nd, ns, _score_from(nd, ns, n)


class State:
    """Incremental diff/sum multiplicity tracker."""
    __slots__ = ("a", "dcnt", "scnt", "nd", "ns")

    def __init__(self, a):
        self.a = list(dict.fromkeys(int(x) for x in a))
        self.dcnt = {}
        self.scnt = {}
        for x in self.a:
            for y in self.a:
                d = x - y
                self.dcnt[d] = self.dcnt.get(d, 0) + 1
        for i, x in enumerate(self.a):
            for j in range(i, len(self.a)):
                s = x + self.a[j]
                self.scnt[s] = self.scnt.get(s, 0) + 1
        self.nd = len(self.dcnt)
        self.ns = len(self.scnt)

    def score(self):
        return _score_from(self.nd, self.ns, len(self.a))

    def _add_counts(self, v):
        for x in self.a:
            d = v - x
            self.dcnt[d] = self.dcnt.get(d, 0) + 1
            d = x - v
            self.dcnt[d] = self.dcnt.get(d, 0) + 1
            s = v + x
            self.scnt[s] = self.scnt.get(s, 0) + 1
        s = v + v
        self.scnt[s] = self.scnt.get(s, 0) + 1
        self.dcnt[0] = self.dcnt.get(0, 0) + 1

    def _remove_counts(self, v):
        for x in self.a:
            d = v - x
            self.dcnt[d] -= 1
            d = x - v
            self.dcnt[d] -= 1
            s = v + x
            self.scnt[s] -= 1
        s = v + v
        self.scnt[s] -= 1
        self.dcnt[0] -= 1

    def add(self, v):
        if v in self.a:
            return False
        self._add_counts(v)
        self.a.append(v)
        self.nd = len(self.dcnt)
        self.ns = len(self.scnt)
        return True

    def remove(self, v):
        if v not in self.a or len(self.a) <= 2:
            return False
        self.a.remove(v)
        self._remove_counts(v)
        # prune zeros
        self.dcnt = {k: c for k, c in self.dcnt.items() if c > 0}
        self.scnt = {k: c for k, c in self.scnt.items() if c > 0}
        self.nd = len(self.dcnt)
        self.ns = len(self.scnt)
        return True

    def move(self, idx, newv):
        old = self.a[idx]
        if newv == old:
            return False
        self.remove(old)
        ok = self.add(newv)
        if not ok:
            self.add(old)
            return False
        return True


def _golomb_offsets(count, spacing=1):
    offs = [0]
    used = {0}
    step = 1
    for _ in range(count - 1):
        cand = offs[-1] + step * spacing
        tries = 0
        while tries < 400:
            ok = True
            for o in offs:
                d = cand - o
                if d in used or -d in used:
                    ok = False
                    break
            if ok:
                break
            cand += 1
            tries += 1
        offs.append(cand)
        for o in offs[:-1]:
            used.add(offs[-1] - o)
            used.add(o - offs[-1])
        step += 1
    return offs


def _build(clusters, plen, spacing=1):
    offs = _golomb_offsets(clusters, spacing)
    base = max(offs) + plen * spacing + 1
    A = []
    for o in offs:
        start = base + o
        for t in range(plen):
            A.append(start + t)
    return A


def _search(seed, deadline, rng):
    st = State(seed)
    best = list(st.a)
    best_sc = st.score()
    n = len(st.a)
    span = max(st.a) - min(st.a) if st.a else 1
    steps = 0
    while time.time() < deadline:
        steps += 1
        r = rng.random()
        if r < 0.5:
            # shift a random element
            idx = rng.randrange(len(st.a))
            delta = rng.randint(-3, 3)
            if delta == 0:
                delta = 1
            newv = st.a[idx] + delta
            if newv in st.a:
                continue
            old = st.a[idx]
            st.remove(old)
            if not st.add(newv):
                st.add(old)
                continue
        elif r < 0.8:
            # add near an anchor
            if len(st.a) >= 3990:
                continue
            anchor = rng.choice(st.a)
            newv = anchor + rng.randint(1, 12)
            if newv in st.a:
                continue
            if not st.add(newv):
                continue
        else:
            if len(st.a) <= 4:
                continue
            v = rng.choice(st.a)
            st.remove(v)
        sc = st.score()
        if sc > best_sc or (sc > best_sc - 1e-9):
            if sc > best_sc:
                best_sc = sc
                best = list(st.a)
        else:
            # occasional restart from best to stay near good region
            if rng.random() < 0.02:
                st = State(best)
    return best, best_sc


def solve():
    start = time.time()
    deadline = start + 112.0
    rng = random.Random(987654321)

    best = None
    best_sc = -1.0

    # Seed pool: multi-cluster family.
    seeds = []
    for clusters in (3, 4, 6, 8, 12, 16, 20, 24, 32, 40, 50):
        for plen in (2, 3, 4, 5, 6, 8, 10, 12):
            if clusters * plen <= 3000:
                seeds.append((clusters, plen))

    seeds.sort(key=lambda cp: abs(cp[0] * cp[1] - 80) + abs(cp[0] - cp[1] * 4))

    for clusters, plen in seeds[:12]:
        A = _build(clusters, plen)
        _, _, sc = _stats(A)
        if sc > best_sc:
            best_sc = sc
            best = list(A)

    if best is None:
        best = [0, 1, 2, 4, 8]

    # Build the best seed found, then run heavy incremental search.
    budget = deadline - time.time()
    n_seed = max(1, min(4, int(budget // 25)))
    cur_best = best
    cur_best_sc = best_sc
    per = (deadline - time.time() - 2.0) / n_seed
    for k in range(n_seed):
        sub_deadline = time.time() + per
        # vary seed size for diversity
        A = None
        if k == 0:
            A = cur_best
        else:
            cl = rng.randint(3, 50)
            pl = rng.randint(2, 12)
            A = _build(cl, pl)
        res, sc = _search(list(A), sub_deadline, rng)
        if sc > cur_best_sc:
            cur_best_sc = sc
            cur_best = res

    _, _, final_sc = _stats(cur_best)
    if final_sc >= cur_best_sc or final_sc > best_sc:
        best = cur_best

    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    return best
# EVOLVE-BLOCK-END
