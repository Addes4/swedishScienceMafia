# EVOLVE-BLOCK-START
"""Grid construction A = X + M*Y with memory-safe scorer and finer M-sweep."""
import math
import random
import time
import numpy as np


def _score_np(arr):
    n = arr.size
    if n < 2:
        return 0.0
    a = np.sort(arr.astype(np.int64))
    d = np.subtract.outer(a, a).ravel()
    s = np.add.outer(a, a).ravel()
    d.sort()
    s.sort()
    nd = 1 + int(np.count_nonzero(d[1:] != d[:-1]))
    ns = 1 + int(np.count_nonzero(s[1:] != s[:-1]))
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _golomb(n, span):
    """Greedy Golomb ruler with n marks within span (may return fewer)."""
    marks = [0]
    used = {0}
    cand = 1
    while len(marks) < n and cand <= span:
        ok = True
        for m in marks:
            if abs(cand - m) in used:
                ok = False
                break
        if ok:
            for m in marks:
                used.add(abs(cand - m))
            marks.append(cand)
        cand += 1
    return marks


def _make_grid(X, Y, M):
    a = np.array([x + M * y for y in Y for x in X], dtype=np.int64)
    return np.unique(a)


def solve():
    deadline = time.time() + 105
    best = None
    best_score = -1.0

    gol_cache = {}

    def gol(n, span):
        key = (n, span)
        if key not in gol_cache:
            gol_cache[key] = _golomb(n, span)
        return gol_cache[key]

    # Precompute a set of Golomb rulers we may reuse.
    rulers = {}
    for n in range(2, 90):
        span = 220 * n
        r = gol(n, span)
        if len(r) >= 2:
            rulers[len(r)] = r
        if time.time() > deadline:
            break

    Xs = []
    for n in (5, 8, 11, 14, 18, 22, 27, 33, 40, 48, 57, 67, 78):
        r = gol(n, 260 * n)
        if len(r) >= 3:
            Xs.append(r)

    Ms = []
    v = 60
    while v <= 200000:
        Ms.append(v)
        v = int(v * 1.7) + 7

    # Family 1: A = X + M*Y, X golomb, Y golomb or interval.
    for X in Xs:
        if time.time() > deadline:
            break
        nX = len(X)
        for nY in range(2, 22):
            Yint = list(range(nY))
            Ygol = gol(nY, 40 * nY)
            if len(Ygol) < 2:
                Ygol = Yint
            for Y in (Yint, Ygol):
                for M in Ms:
                    arr = _make_grid(X, Y, M)
                    if arr.size < 2:
                        continue
                    sc = _score_np(arr)
                    if sc > best_score:
                        best_score = sc
                        best = arr.copy()
                if time.time() > deadline:
                    break
            if time.time() > deadline:
                break

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)
        best_score = _score_np(best)

    # Local search: mutate a few elements, keep improvements.
    cur = best.copy()
    cur_score = best_score
    it = 0
    while time.time() < deadline and it < 4000:
        it += 1
        cand = cur.copy()
        k = random.randint(1, max(1, len(cand) // 20))
        idx = np.random.randint(0, len(cand), size=k)
        cand[idx] += np.random.randint(-3, 4, size=k).astype(np.int64)
        cand = np.unique(cand)
        if cand.size < 2:
            continue
        sc = _score_np(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand.copy(), sc
        if it % 300 == 0:
            cand = np.unique((cur * random.choice((2, 3))).astype(np.int64))
            if cand.size >= 2:
                sc = _score_np(cand)
                if sc > best_score:
                    best, best_score = cand.copy(), sc

    return sorted(int(v) for v in np.unique(best))
# EVOLVE-BLOCK-END
