# EVOLVE-BLOCK-START
"""Product family: A = X + M*Y with X a Golomb ruler (difference-dominant) and
Y a short interval (so sums stay small). Sweep M, sizes; light greedy polish."""
import math
import time


def _golomb(k):
    """Greedy Golomb ruler: marks with all pairwise differences distinct."""
    marks = [0]
    used = {0}
    while len(marks) < k:
        c = marks[-1] + 1
        while True:
            ok = True
            for m in marks:
                d = abs(c - m)
                if d in used:
                    ok = False
                    break
            if ok:
                newd = {abs(c - m) for m in marks}
                used |= newd
                marks.append(c)
                break
            c += 1
    return marks


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for i in range(n):
        xi = a[i]
        for j in range(i, n):
            sums.add(xi + a[j])
            if i != j:
                diffs.add(xi - a[j])
                diffs.add(a[j] - xi)
    nd, ns = len(diffs), len(sums)
    if ns == 0 or nd == 0:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def build_grid(X, Y, M):
    """A = { x + M*y }."""
    a = set()
    for y in Y:
        for x in X:
            a.add(x + M * y)
    return sorted(a)


def solve():
    deadline = time.time() + 110

    best = None
    best_score = -1.0
    best_key = None

    # Candidate Golomb rulers
    rulers = [_golomb(k) for k in (6, 8, 10, 12, 16, 20, 26, 32)]

    # Candidate offsets: the ruler itself, symmetric, and shifted variants
    t_sizes = [2, 3, 4, 5, 6, 7, 8]

    # M sweep ranges
    def m_candidates(span, t):
        base = set()
        for f in (1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 30, 40, 50, 64, 80, 100, 128, 160, 200, 256):
            base.add(f)
        # also M just larger than max diff so Y-blocks barely overlap
        for v in range(1, 12):
            base.add(max(1, span // max(1, t) * v // 2 + 1))
        return sorted(x for x in base if x >= 1)

    for X in rulers:
        span = X[-1] if X else 1
        for t in t_sizes:
            Y = list(range(t))
            for M in m_candidates(span, t):
                if time.time() > deadline:
                    break
                a = build_grid(X, Y, M)
                if len(a) < 2:
                    continue
                s, nd, ns = _score(a)
                if s > best_score:
                    best_score = s
                    best = a
                    best_key = (len(X), t, M)
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    # Light greedy polish: try shifting individual elements and small swaps
    if best is not None:
        cur = list(best)
        cur_score = best_score
        rnd_seed = 12345
        import random
        rnd = random.Random(rnd_seed)
        it = 0
        while time.time() < deadline and it < 4000:
            it += 1
            improved = False
            # try shifting a few elements by multiples of small deltas
            idxs = list(range(len(cur)))
            rnd.shuffle(idxs)
            for i in idxs[:max(1, len(cur) // 4)]:
                for delta in (-M_delta if False else -1, 1):
                    pass
            # simple single-element shift
            for i in idxs:
                for delta in (-2, -1, 1, 2):
                    cand = cur[:]
                    cand[i] += delta
                    cs = set(cand)
                    if len(cs) != len(cand):
                        continue
                    s, _, _ = _score(cand)
                    if s > cur_score:
                        cur = cand
                        cur_score = s
                        improved = True
                        break
                if improved:
                    break
            if not improved:
                break

        if cur_score > best_score:
            best_score = cur_score
            best = cur

    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    best = [x for x in best if abs(x) <= 10 ** 15]
    return best
# EVOLVE-BLOCK-END


if __name__ == "__main__":
    res = solve()
    print(len(res), _score(res))
