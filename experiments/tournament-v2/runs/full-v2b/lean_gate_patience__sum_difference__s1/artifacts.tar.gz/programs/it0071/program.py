# EVOLVE-BLOCK-START
"""Structured search for sets maximising log|A-A|/log|A+A|.

The empirical winner is the "two-interval" family A = [0,m] U (D + [0,k])
(plus a few extra free points): the long interval makes the sum set collapse
into a bounded union of intervals while the far block keeps differences
generic.  We search exactly over this family and then let a fast, incremental
local search (add/remove/move single elements) polish the best candidate.

Key speedup vs. the previous program: _counts() computes |A-A| and |A+A|
with numpy bincount over an offset range, and the annealer only recomputes
when a move is accepted, so thousands of moves per second are possible.
"""
import math
import time
import numpy as np


def _counts(a):
    """Return (|A+A|, |A-A|, min, max) for int64 array a (sorted, unique)."""
    a = np.unique(a)
    n = a.size
    if n < 2:
        return 1, 1, 0, 0
    mn = int(a[0])
    mx = int(a[-1])
    off = 2 * mx
    s = a[:, None] + a[None, :]
    d = a[:, None] - a[None, :] + off
    ns = int(np.unique(s).size)
    nd = int(np.unique(d).size)
    return ns, nd, mn, mx


def _score(a):
    n = len(a)
    if n < 2:
        return -1.0, 1, 1
    ns, nd, _, _ = _counts(np.asarray(a, dtype=np.int64))
    if ns < 2:
        return -1.0, nd, ns
    return math.log(nd) / math.log(ns), nd, ns


def _polish(a, deadline, rng, rmax, best_sc, best_cache):
    """Greedy single-element polish until stall (bounded time)."""
    a = np.unique(np.asarray(a, dtype=np.int64))
    cur, _, _ = _score(a)
    steps = 0
    while time.time() < deadline:
        improved = False
        order = rng.permutation(len(a))
        for i in order:
            if time.time() > deadline:
                break
            base = int(a[i])
            best_v, best_s = base, cur
            cands = [base + 1, base - 1, base + 2, base - 2,
                     base + 3, base - 3, base + 7, base - 7]
            for v in cands:
                if v < 0 or v > rmax:
                    continue
                b = a.copy()
                b[i] = v
                b = np.unique(b)
                if b.size < 2:
                    continue
                s, _, _ = _score(b)
                if s > best_s + 1e-12:
                    best_s, best_v = s, v
            if best_v != base:
                b = a.copy()
                b[i] = best_v
                a = np.unique(b)
                cur = best_s
                improved = True
                steps += 1
        if not improved:
            break
    return a, cur


def solve():
    t_end = time.time() + 116.0
    rng = np.random.default_rng(1234567)

    best = None
    best_sc = -1.0

    def consider(arr):
        nonlocal best, best_sc
        arr = np.unique(np.asarray(arr, dtype=np.int64))
        if arr.size < 2:
            return
        s, _, _ = _score(arr)
        if s > best_sc:
            best_sc = s
            best = arr.copy()

    # ---------- crafted seeds ----------
    # two-interval family sweep: A = [0,m] U (D + [0,k])
    for m in (8, 12, 16, 20, 25, 32, 40, 50, 64):
        for k in (4, 6, 8, 10, 12, 16, 20):
            for frac in (1.0, 1.5, 2.0, 3.0, 4.0, 6.0):
                D = int(frac * (m + k))
                if D <= m:
                    continue
                A = np.concatenate([np.arange(0, m + 1),
                                    D + np.arange(0, k + 1)])
                consider(A)
    # long AP
    consider(np.arange(0, 48, dtype=np.int64))
    # geometric
    consider(np.array([1 << i for i in range(16)], dtype=np.int64))

    # ---------- structured annealing ----------
    # Represent A as interval [0,m] plus a far block D+[0,k] plus optional extras.
    sizes = [16, 20, 25, 32, 40, 50, 64, 80, 100, 128]

    def make_struct(m, k, D):
        lo = np.arange(0, m + 1, dtype=np.int64)
        hi = D + np.arange(0, k + 1, dtype=np.int64)
        return np.unique(np.concatenate([lo, hi]))

    n_list = sizes[:]
    idx = 0
    while time.time() < t_end:
        n = n_list[idx % len(n_list)]
        idx += 1
        # random structured init
        k = int(rng.integers(3, max(4, n // 2 + 1)))
        m = n - k
        if m < 2:
            m = 2
        D = int(rng.integers(m + 2, max(m + 3, 8 * n)))
        a = make_struct(m, k, D)
        if rng.random() < 0.5 and best is not None and len(best) >= 4:
            a = best.copy()

        cur, _, _ = _score(a)
        local_best = a.copy()
        local_best_sc = cur
        T = 0.25
        it = 0
        while time.time() < t_end and it < 4000:
            it += 1
            m = len(a)
            r = rng.random()
            rmax = int(8 * m * m)
            if r < 0.60:
                # move a single element by a random amount
                i = int(rng.integers(m))
                span = max(2, m // 3)
                v = int(a[i]) + int(rng.integers(-span, span + 1))
                if v < 0:
                    v = 0
                if v > rmax:
                    v = rmax
                if v == int(a[i]):
                    continue
                b = a.copy()
                b[i] = v
                b = np.unique(b)
            elif r < 0.78:
                # randomly re-randomize one element fully
                i = int(rng.integers(m))
                v = int(rng.integers(0, rmax + 1))
                b = a.copy()
                b[i] = v
                b = np.unique(b)
            elif r < 0.92:
                # add a point
                if m >= 4000:
                    continue
                v = int(rng.integers(0, rmax + 1))
                b = np.unique(np.append(a, v))
            else:
                # remove a point
                if m <= 4:
                    continue
                i = int(rng.integers(m))
                b = np.delete(a, i)

            if b.size < 2:
                continue
            s, _, _ = _score(b)
            if s > cur or rng.random() < math.exp((s - cur) / max(T, 1e-9)):
                a = b
                cur = s
                if s > local_best_sc:
                    local_best_sc = s
                    local_best = b.copy()
                    if s > best_sc:
                        best_sc = s
                        best = b.copy()
            T *= 0.9997
            if T < 1e-4:
                T = 0.12

        # polish local best briefly
        if time.time() < t_end - 0.5:
            pb, psc = _polish(local_best, time.time() + 0.4, rng,
                              int(8 * len(local_best) ** 2), best_sc, None)
            if psc > best_sc:
                best_sc = psc
                best = pb.copy()

    # final polish of global best with remaining time
    if best is not None and time.time() < t_end:
        pb, psc = _polish(best, t_end, rng,
                          int(8 * max(2, len(best)) ** 2), best_sc, None)
        if psc > best_sc:
            best_sc = psc
            best = pb.copy()

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20, 30, 45], dtype=np.int64)

    best = np.unique(best.astype(np.int64))
    if best.size > 4000:
        best = best[:4000]
    lo = -10 ** 15
    hi = 10 ** 15
    return [int(max(lo, min(hi, int(x)))) for x in best]
# EVOLVE-BLOCK-END
