# EVOLVE-BLOCK-START
"""Structured search for sets maximising log|A-A|/log|A+A|.

Key idea: a long arithmetic interval I={0..m-1} makes most of I+I collide
(|I+I| = 2m-1 ~ 2|I|), which keeps |A+A| small.  Adding a well-separated
Sidon-like block B far away from I adds many new differences (|I-B| types)
while contributing only O(|B|^2)-ish new sums.  We sweep (m, offset, block)
and hill-climb.
"""
import math
import time
import numpy as np


def _score(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return -1.0, 1, 1
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    ns = int(sums.size)
    nd = int(diffs.size)
    if ns < 2:
        return -1.0, nd, ns
    bonus = (1.0 - 1.0 / n) / 100.0
    return math.log(nd) / math.log(ns) + bonus, nd, ns


def _polish(a, deadline, rng, rmax):
    a = np.unique(np.asarray(a, dtype=np.int64))
    cur, _, _ = _score(a)
    while time.time() < deadline:
        improved = False
        for i in rng.permutation(a.size):
            if time.time() > deadline:
                break
            base = int(a[i])
            best_v, best_s = base, cur
            step = max(1, rmax // 64)
            for v in (base + 1, base - 1, base + step, base - step,
                      base + 2, base - 2):
                if v < 0 or v > rmax:
                    continue
                b = a.copy()
                b[i] = v
                b = np.unique(b)
                if b.size < 2:
                    continue
                s, _, _ = _score(b)
                if s > best_s + 1e-12:
                    best_s, best_v = s, v
            if best_v != base:
                b = a.copy()
                b[i] = best_v
                a = np.unique(b)
                cur = best_s
                improved = True
        if not improved:
            break
    return a, cur


def solve():
    t_end = time.time() + 117.0
    rng = np.random.default_rng(12345)

    best = None
    best_sc = -1.0

    def consider(arr):
        nonlocal best, best_sc
        arr = np.unique(np.asarray(arr, dtype=np.int64))
        if arr.size < 2:
            return
        s, _, _ = _score(arr)
        if s > best_sc:
            best_sc = s
            best = arr.copy()

    # ---- structured seeds: interval I plus separated Sidon block B ----
    # B is a Sidon set (all pairwise sums distinct -> few sum collisions
    # among B, but B-B is large).  We use a greedy Sidon set.
    def sidon(k, start=1):
        marks = [0]
        used = set([0])
        c = start
        while len(marks) < k:
            ok = True
            newd = set()
            for mm in marks:
                d = c - mm
                if d in used or d in newd:
                    ok = False
                    break
                newd.add(d)
            if ok:
                # also require sums distinctness handled by Sidon on both signs
                used |= newd
                marks.append(c)
                c += 1
            else:
                c += 1
            if c > 10 * k * k + 100:
                break
        return np.array(marks, dtype=np.int64)

    # sweep interval length m and far offset D, block = sidon block scaled
    # A = {0..m-1} U {D + t : t in B}
    for m in (20, 30, 40, 60, 80, 120, 160, 240):
        if time.time() > t_end:
            break
        for kb in (3, 4, 6, 8):
            B = sidon(kb)
            for Dmult in (1, 2, 4, 8):
                D = m * Dmult + int(rng.integers(0, max(1, m)))
                room = int(4 * (m + kb * kb) ** 2)
                arr = np.concatenate([np.arange(m, dtype=np.int64),
                                      D + B.astype(np.int64)])
                if arr.max() <= room:
                    consider(arr)

    # randomized structured start + annealing over the family
    sizes = [20, 30, 40, 60, 80, 120, 160, 240]

    # generic anna ling sweep for a portion of the time
    t_ann = time.time() + 60.0
    idx = 0
    n_list = sizes
    while time.time() < t_ann:
        n = n_list[idx % len(n_list)]
        idx += 1
        rmax = int(6 * n * n)
        if best is not None and len(best) == n and rng.random() < 0.5:
            a = best.copy()
        else:
            a = np.sort(rng.choice(rmax, size=n, replace=False)).astype(np.int64)
        cur, _, _ = _score(a)
        T = 0.25
        b_step = max(1, n // 3)
        it = 0
        while time.time() < t_ann:
            it += 1
            if (it & 127) == 0 and time.time() > t_ann:
                break
            m = a.size
            r = rng.random()
            if r < 0.90:
                i = int(rng.integers(m))
                v = int(a[i]) + int(rng.integers(-b_step, b_step + 1))
                v = max(0, min(rmax, v))
                if v == int(a[i]):
                    continue
                b = a.copy()
                b[i] = v
                b = np.unique(b)
            elif r < 0.96:
                if m >= 4000:
                    continue
                v = int(rng.integers(0, rmax + 1))
                b = np.unique(np.append(a, v))
            else:
                if m <= 4:
                    continue
                i = int(rng.integers(m))
                b = np.delete(a, i)
            if b.size < 2:
                continue
            s, _, _ = _score(b)
            if s > cur or rng.random() < math.exp((s - cur) / max(T, 1e-9)):
                a, cur = b, s
                if s > best_sc:
                    best_sc = s
                    best = b.copy()
            T *= 0.9999
            if T < 1e-4:
                T = 0.12

    # ---- final polish of the best --------------------------------
    if best is not None and time.time() < t_end - 2.0:
        R = int(max(best) + 2 * len(best) ** 2 + 10)
        pb, psc = _polish(best, t_end - 0.5, rng, R)
        if psc > best_sc:
            best_sc = psc
            best = pb.copy()

    if best is None:
        best = np.array([0, 1, 2, 3, 4, 5, 7, 11, 16, 40, 41, 42],
                        dtype=np.int64)

    best = np.unique(best.astype(np.int64))
    if best.size > 4000:
        best = best[:4000]
    lo, hi = -10 ** 15, 10 ** 15
    return [int(max(lo, min(hi, int(x)))) for x in best]
# EVOLVE-BLOCK-END
