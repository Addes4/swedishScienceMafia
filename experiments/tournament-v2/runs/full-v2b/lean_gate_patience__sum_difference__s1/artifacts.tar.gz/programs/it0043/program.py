# EVOLVE-BLOCK-START
"""Fast incremental local search for max log|A-A|/log|A+A| (+ size bonus).

We maintain dicts diffcnt[x] = #{ordered pairs (a,b) with a-b = x} and
sumcnt[x] = #{ordered pairs (a,b) with a+b = x}. |A-A| = #keys(diffcnt) and
|A+A| = #keys(sumcnt). Adding/removing/shifting an element updates these in O(n).

Seeds: structured sets of the form A = X + M*[0,k), where X is a small base set
chosen so that its differences are numerous (good for |A-A|) and the interval
M*[0,k) keeps sums concentrated. We also try multi-cluster AP seeds. Then we run
a large budget of local moves accepting improvements to the full score.
"""
import math
import random
import time


def _score(nd, ns, n):
    if n < 2 or ns < 2 or nd < 2:
        return 1e-9, nd, ns
    s = math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0
    return s, nd, ns


def _build_cnt(A):
    n = len(A)
    diff = {}
    summ = {}
    for i in range(n):
        ai = A[i]
        for j in range(n):
            aj = A[j]
            d = ai - aj
            diff[d] = diff.get(d, 0) + 1
            s = ai + aj
            summ[s] = summ.get(s, 0) + 1
    return diff, summ, len(diff), len(summ)


def _add(A, diff, summ, nd, ns, v):
    """Add v to A, updating counts. Returns new (nd, ns)."""
    for a in A:
        d = v - a
        c = diff.get(d, 0)
        diff[d] = c + 1
        if c == 0:
            nd += 1
        d2 = a - v
        c2 = diff.get(d2, 0)
        diff[d2] = c2 + 1
        if c2 == 0:
            nd += 1
        s = v + a
        cs = summ.get(s, 0)
        summ[s] = cs + 1
        if cs == 0:
            ns += 1
        s2 = a + v
        cs2 = summ.get(s2, 0)
        summ[s2] = cs2 + 1
        if cs2 == 0:
            ns += 1
    # self terms
    c = diff.get(0, 0)
    diff[0] = c + 1
    if c == 0:
        nd += 1
    cs = summ.get(2 * v, 0)
    summ[2 * v] = cs + 1
    if cs == 0:
        ns += 1
    A.append(v)
    return nd, ns


def _remove(A, diff, summ, nd, ns, v):
    """Remove v from A (assumes present once)."""
    for a in A:
        if a == v:
            continue
        d = v - a
        c = diff.get(d, 0) - 1
        if c <= 0:
            diff.pop(d, None)
            nd -= 1
        else:
            diff[d] = c
        d2 = a - v
        c2 = diff.get(d2, 0) - 1
        if c2 <= 0:
            diff.pop(d2, None)
            nd -= 1
        else:
            diff[d2] = c2
        s = v + a
        cs = summ.get(s, 0) - 1
        if cs <= 0:
            summ.pop(s, None)
            ns -= 1
        else:
            summ[s] = cs
        s2 = a + v
        cs2 = summ.get(s2, 0) - 1
        if cs2 <= 0:
            summ.pop(s2, None)
            ns -= 1
        else:
            summ[s2] = cs2
    c = diff.get(0, 0) - 1
    if c <= 0:
        diff.pop(0, None)
        nd -= 1
    else:
        diff[0] = c
    cs = summ.get(2 * v, 0) - 1
    if cs <= 0:
        summ.pop(2 * v, None)
        ns -= 1
    else:
        summ[2 * v] = cs
    A.remove(v)
    return nd, ns


def _local_search(A0, deadline, rng):
    A = sorted(set(int(x) for x in A0))
    n = len(A)
    if n < 2:
        return A
    diff, summ, nd, ns = _build_cnt(A)
    best_s, nd, ns = _score(nd, ns, n)
    best = A[:]

    # candidate neighborhood for additions/shifts
    lo = min(A)
    hi = max(A)
    rng_span = max(2, hi - lo)

    it = 0
    while time.time() < deadline:
        it += 1
        improved = False
        n = len(A)

        # ---- try add ----
        pool = set()
        for x in A[:min(n, 40)]:
            for dl in (-2, -1, 1, 2, -4, 4, -7, 7):
                pool.add(x + dl)
        for x in A[-min(n, 40):]:
            for dl in (-2, -1, 1, 2, -4, 4, -7, 7):
                pool.add(x + dl)
        # also midpoints
        for _ in range(10):
            i = rng.randrange(n)
            j = rng.randrange(n)
            pool.add((A[i] + A[j]) // 2)
        cand = [v for v in pool if v not in set(A)]
        rng.shuffle(cand)
        for v in cand[:120]:
            nd2, ns2 = _add(A, diff, summ, nd, ns, v)
            s2, _, _ = _score(nd2, ns2, n + 1)
            if s2 > best_s:
                best_s = s2
                best = A[:]
                nd, ns = nd2, ns2
                improved = True
                break
            else:
                nd, ns = _remove(A, diff, summ, nd2, ns2, v)
        if improved:
            continue

        # ---- try shift one element ----
        order = list(range(n))
        rng.shuffle(order)
        for i in order:
            v = A[i]
            d0 = v - A[i - 1] if i > 0 else 1
            d1 = A[i + 1] - v if i + 1 < n else 1
            for dl in (-1, 1, -2, 2, -3, 3, -5, 5):
                nv = v + dl
                if nv in set(A):
                    continue
                if (i > 0 and nv <= A[i - 1]) or (i + 1 < n and nv >= A[i + 1]):
                    # allow but keep distinctness
                    if nv in set(A):
                        continue
                nd2, ns2 = _remove(A, diff, summ, nd, ns, v)
                nd2, ns2 = _add(A, diff, summ, nd2, ns2, nv)
                A.sort()
                s2, _, _ = _score(nd2, ns2, n)
                if s2 > best_s:
                    best_s = s2
                    best = A[:]
                    nd, ns = nd2, ns2
                    improved = True
                    break
                else:
                    A.remove(nv)
                    nd2, ns2 = _add(A, diff, summ, nd2, ns2, v)
                    A.sort()
                    nd, ns = nd2, ns2
            if improved:
                break
        if improved:
            continue

        # ---- try remove weak element ----
        if n > 4:
            order = list(range(n))
            rng.shuffle(order)
            for i in order:
                v = A[i]
                nd2, ns2 = _remove(A, diff, summ, nd, ns, v)
                s2, _, _ = _score(nd2, ns2, n - 1)
                if s2 > best_s:
                    best_s = s2
                    best = A[:]
                    nd, ns = nd2, ns2
                    improved = True
                    break
                else:
                    nd2, ns2 = _add(A, diff, summ, nd2, ns2, v)
                    A.sort()
                    nd, ns = nd2, ns2
        if improved:
            continue

        # no improvement: perturb by adding a random far element occasionally
        if it % 3 == 0:
            v = rng.randint(lo - rng_span, hi + rng_span)
            if v not in set(A):
                _add(A, diff, summ, nd, ns, v)
                A.sort()
                diff, summ, nd, ns = _build_cnt(A)
        else:
            break

    return best


def _seed_shapes(rng):
    seeds = []
    # structured: A = X + M*[0,k)
    bases = [
        [0, 1, 3], [0, 1, 4], [0, 2, 5], [0, 1, 3, 7],
        [0, 1, 4, 6], [0, 1, 3, 8], [0, 1, 5, 9],
        [0, 1, 3, 7, 12], [0, 1, 4, 10, 15], [0, 1, 3, 8, 14],
        [0, 1, 2, 5, 9], [0, 1, 3, 6, 11, 17],
    ]
    for X in bases:
        for M in (1, 2, 3, 5, 8, 13, 21, 34, 55):
            for k in (2, 3, 4, 5, 7, 10, 15, 25):
                A = []
                for x in X:
                    for t in range(k):
                        A.append(x + M * t)
                A = sorted(set(A))
                if 2 <= len(A) <= 4000:
                    seeds.append(A)
    # multi-cluster AP seeds
    for g in (2, 3, 4, 5, 6, 8):
        for L in (3, 4, 5, 6, 8, 10, 15):
            for d in (1, 2, 3, 5, 8, 13):
                for span in (5, 13, 34, 89, 233):
                    offsets = [0]
                    used = {0}
                    for _ in range(g - 1):
                        cand = rng.randint(-span, span)
                        for _t in range(30):
                            c2 = rng.randint(-span, span)
                            if c2 not in used:
                                cand = c2
                                break
                        offsets.append(cand)
                        used.add(cand)
                    A = []
                    for o in offsets:
                        for kk in range(L):
                            A.append(o + kk * d)
                    A = sorted(set(A))
                    if 2 <= len(A) <= 4000:
                        seeds.append(A)
    return seeds


def solve():
    rng = random.Random(20240117)
    deadline = time.time() + 112.0
    seeds = _seed_shapes(rng)
    rng.shuffle(seeds)

    best = [0, 1, 2, 3, 4, 5]
    _, _, bs = _score(*_build_cnt(best)[2:], len(best))
    best_score = _score(_build_cnt(best)[2], _build_cnt(best)[3], len(best))[0]

    # Evaluate seeds quickly, keep the top ones for deeper search
    scored = []
    for A in seeds:
        if time.time() > deadline - 1:
            break
        diff, summ, nd, ns = _build_cnt(A)
        s = _score(nd, ns, len(A))[0]
        scored.append((s, A))
    scored.sort(key=lambda t: -t[0])

    # Deepen the most promising seeds with local search, round-robin
    t_end_budget = deadline
    idx = 0
    while time.time() < t_end_budget and idx < len(scored):
        s0, A0 = scored[idx]
        idx += 1
        # allocate a share; small for many seeds, more for the best
        share = max(0.05, min(6.0, (t_end_budget - time.time()) / max(1, len(scored) - idx + 1)))
        A2 = _local_search(A0, min(time.time() + share, t_end_budget - 0.5), rng)
        diff, summ, nd, ns = _build_cnt(A2)
        s = _score(nd, ns, len(A2))[0]
        if s > best_score:
            best_score = s
            best = A2[:]

    # final long polish on the best
    if time.time() < deadline - 0.5:
        A3 = _local_search(best, deadline - 0.2, rng)
        diff, summ, nd, ns = _build_cnt(A3)
        s = _score(nd, ns, len(A3))[0]
        if s > best_score:
            best = A3[:]

    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    return best
# EVOLVE-BLOCK-END
