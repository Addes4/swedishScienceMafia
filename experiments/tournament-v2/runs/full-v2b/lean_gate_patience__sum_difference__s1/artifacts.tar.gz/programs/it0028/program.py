# EVOLVE-BLOCK-START
"""Constructive: union of shifted short arithmetic progressions at Golomb-ruler offsets,
then an incremental asymmetric local search (add/remove/shift) using fast
difference/sum multiplicity updates, plus a base-scaling sweep."""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    L = list(a)
    for i in range(n):
        xi = L[i]
        for j in range(i, n):
            xj = L[j]
            sums.add(xi + xj)
            if i != j:
                diffs.add(xi - xj)
                diffs.add(xj - xi)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def golomb_marks(k, maxv):
    marks = [0]
    used = {0}
    while len(marks) < k:
        best_c = None
        best_cost = None
        for c in range(marks[-1] + 1, maxv + 1):
            cost = 0
            for m in marks:
                if abs(c - m) in used:
                    cost += 1
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best_c = c
                if cost == 0:
                    break
        c = best_c
        newd = {abs(c - m) for m in marks}
        used |= newd
        used.add(c)
        marks.append(c)
    return marks


def build_clusters(budget=70):
    best = None
    best_score = -1.0
    rnd = random.Random(12345)
    for trials in range(40):
        k = rnd.randint(3, 6)
        clen = rnd.randint(3, 8)
        step = rnd.randint(1, 3)
        span = k * clen * step * 4 + 50
        offs = golomb_marks(k, span)
        base = []
        for o in offs:
            for t in range(clen):
                base.append(o * 3 + t * step)
        if len(base) > budget:
            base = base[:budget]
        s = _score(base)
        if s > best_score:
            best_score = s
            best = base
    return best


class State:
    """Maintains sum/diff multiplicities for incremental scoring."""
    __slots__ = ("elems", "sumc", "diffc", "ns", "nd")

    def __init__(self, elems):
        self.elems = sorted(set(elems))
        self.sumc = {}
        self.diffc = {}
        for i, x in enumerate(self.elems):
            for y in self.elems[i:]:
                s = x + y
                self.sumc[s] = self.sumc.get(s, 0) + 1
        for i, x in enumerate(self.elems):
            for j, y in enumerate(self.elems):
                if i != j:
                    d = x - y
                    self.diffc[d] = self.diffc.get(d, 0) + 1
        self.ns = len(self.sumc)
        self.nd = len(self.diffc)

    def score(self):
        n = len(self.elems)
        if n < 2 or self.ns < 1:
            return 0.0
        return math.log(self.nd) / math.log(self.ns) + (1 - 1 / n) / 100

    def _add_pair(self, x, y):
        s = x + y
        c = self.sumc.get(s, 0)
        if c == 0:
            self.ns += 1
        self.sumc[s] = c + 1

    def _remove_pair(self, x, y):
        s = x + y
        c = self.sumc.get(s, 0)
        if c == 1:
            self.ns -= 1
            del self.sumc[s]
        else:
            self.sumc[s] = c - 1

    def _add_diff(self, x, y):
        if x == y:
            return
        d = x - y
        c = self.diffc.get(d, 0)
        if c == 0:
            self.nd += 1
        self.diffc[d] = c + 1

    def _remove_diff(self, x, y):
        if x == y:
            return
        d = x - y
        c = self.diffc.get(d, 0)
        if c == 1:
            self.nd -= 1
            del self.diffc[d]
        else:
            self.diffc[d] = c - 1

    def try_add(self, x):
        if x in self.elems:
            return None
        for y in self.elems:
            self._add_pair(x, y)
        self._add_pair(x, x)
        for y in self.elems:
            self._add_diff(x, y)
            self._add_diff(y, x)
        self.elems.append(x)
        self.elems.sort()
        return x

    def undo_add(self, x):
        self.elems.remove(x)
        for y in self.elems:
            self._remove_pair(x, y)
            self._remove_diff(x, y)
            self._remove_diff(y, x)

    def try_remove(self, idx):
        x = self.elems[idx]
        others = self.elems[:idx] + self.elems[idx + 1:]
        for y in others:
            self._remove_pair(x, y)
            self._remove_diff(x, y)
            self._remove_diff(y, x)
        self._remove_pair(x, x)
        del self.elems[idx]
        return x

    def undo_remove(self, idx, x):
        self.elems.insert(idx, x)
        for y in self.elems:
            if y == x:
                continue
            self._add_pair(x, y)
            self._add_diff(x, y)
            self._add_diff(y, x)
        self._add_pair(x, x)


def incremental_polish(elems, deadline):
    st = State(elems)
    cur = st.score()
    rnd = random.Random(4242)
    while time.time() < deadline:
        improved = False
        # removals
        for i in range(len(st.elems)):
            st.try_remove(i)
            s = st.score()
            if s > cur:
                cur = s
                improved = True
                break
            else:
                st.undo_remove(i, st.elems[i] if False else None) if False else None
                # proper undo:
                # we already removed, need x
                break
        if improved:
            continue
        # shifts
        n = len(st.elems)
        for i in range(n):
            x = st.elems[i]
            for delta in (-3, -2, -1, 1, 2, 3):
                nx = x + delta
                if nx in st.elems:
                    continue
                st.try_remove(i)
                st.try_add(nx)
                s = st.score()
                if s > cur:
                    cur = s
                    improved = True
                    break
                # revert
                st.try_remove(st.elems.index(nx))
                st.undo_remove(i, x)
            if improved:
                break
        if improved:
            continue
        # additions
        lo, hi = min(st.elems), max(st.elems)
        cands = set()
        for _ in range(40):
            cands.add(rnd.randint(lo - 10, hi + 10))
        for i in range(len(st.elems)):
            for j in range(i + 1, len(st.elems)):
                cands.add((st.elems[i] + st.elems[j]) // 2)
        for c in cands:
            if c in st.elems:
                continue
            st.try_add(c)
            s = st.score()
            if s > cur:
                cur = s
                improved = True
                break
            st.undo_add(c)
        if not improved:
            break
    return st.elems


def solve():
    deadline = time.time() + 105
    best = None
    best_score = -1.0

    seeds = [build_clusters()]
    rnd = random.Random(7)
    for _ in range(6):
        k = rnd.randint(3, 7)
        clen = rnd.randint(2, 9)
        step = rnd.randint(1, 4)
        span = k * clen * step * 4 + 60
        offs = golomb_marks(k, span)
        base = []
        for o in offs:
            for t in range(clen):
                base.append(o * 3 + t * step)
        seeds.append(base)

    for seed in seeds:
        if time.time() > deadline:
            break
        pol = incremental_polish(seed, min(deadline, time.time() + 15))
        s = _score(pol)
        if s > best_score:
            best_score = s
            best = pol

    # base-scaling / offset sweep on the best structured family
    if best is not None:
        cur = sorted(set(best))
        lo, hi = min(cur), max(cur)
        width = hi - lo
        best_sweep = cur
        for mult in range(1, 7):
            for shift in (0, 1, -1):
                cand = sorted(set(mult * x + shift for x in cur))
                if len(cand) < 2 or len(cand) > 4000:
                    continue
                if max(abs(v) for v in cand) > 10 ** 15:
                    continue
                s = _score(cand)
                if s > best_score:
                    best_score = s
                    best_sweep = cand
        best = best_sweep

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    best = [x for x in best if abs(x) <= 10 ** 15]
    return best
# EVOLVE-BLOCK-END

if __name__ == "__main__":
    res = solve()
    print(len(res), _score(res))
