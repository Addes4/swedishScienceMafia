# EVOLVE-BLOCK-START
"""Two-interval + Sidon-gap seed with fast incremental hill-climbing."""
import math
import time
import random


def _stats(a):
    n = len(a)
    sums = {}
    for i in range(n):
        ai = a[i]
        for j in range(i, n):
            v = ai + a[j]
            sums[v] = sums.get(v, 0) + 1
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            if i != j:
                diffs.add(ai - a[j])
    return len(diffs), len(sums), sums


def _score_from(dcount, scount, n):
    if scount < 2 or dcount < 2:
        return -1e18
    return math.log(dcount) / math.log(scount) + (1 - 1 / n) / 100


def _full(a):
    d, s, _ = _stats(a)
    return _score_from(d, s, len(a))


def _golomb(r):
    marks = [0]
    used = {0}
    while len(marks) < r:
        cand = marks[-1] + 1
        while True:
            ok = True
            for m in marks:
                if cand - m in used:
                    ok = False
                    break
            if ok:
                break
            cand += 1
        for m in marks:
            used.add(cand - m)
        marks.append(cand)
    return marks


def solve():
    deadline = time.time() + 110

    best = None
    best_score = -1e18

    # Phase 1: seed with two-interval family + sidon gap block, sweep params.
    sidon = _golomb(7)
    seeds = []
    for L in (40, 60, 80, 100, 140, 180, 240):
        for Q in (2 * L, 3 * L, 4 * L, 6 * L, 9 * L, 14 * L, 22 * L):
            base = list(range(L)) + [Q + k for k in range(L)]
            seeds.append(base)
            # add scaled sidon gap block near the middle gap
            g = [Q + 2 * L + 3 * s for s in sidon]
            seeds.append(base + g)

    for a in seeds:
        if time.time() > deadline - 60:
            break
        a = sorted(set(a))
        if len(a) < 2:
            continue
        s = _full(a)
        if s > best_score:
            best_score = s
            best = a

    # Phase 2: incremental hill climb seeded by best.
    if best is None:
        best = list(range(80)) + [200 + k for k in range(80)]
        best_score = _full(best)

    a = sorted(set(best))

    def recompute(lst):
        lst = sorted(set(lst))
        d, s, sums = _stats(lst)
        return lst, d, s, sums

    a, dcount, scount, sums = recompute(a)
    cur_score = _score_from(dcount, scount, len(a))

    def try_state(lst):
        lst = sorted(set(lst))
        if len(lst) < 4:
            return None
        d, s, sums = _stats(lst)
        sc = _score_from(d, s, len(lst))
        return lst, d, s, sums, sc

    # local search: remove / add / move operations
    while time.time() < deadline - 2:
        improved = False
        n = len(a)
        span = max(a) - min(a)
        step = max(1, span // 60)

        # remove
        if n > 12:
            idxs = list(range(n))
            random.shuffle(idxs)
            for i in idxs:
                cand = a[:i] + a[i + 1:]
                r = try_state(cand)
                if r and r[4] > cur_score:
                    a, dcount, scount, sums, cur_score = r
                    improved = True
                    break
        if improved:
            continue

        # move
        idxs = list(range(n))
        random.shuffle(idxs)
        for i in idxs:
            for delta in (step, -step, 1, -1, 2, -2):
                cand = a[:]
                cand[i] += delta
                if len(set(cand)) != len(cand):
                    continue
                r = try_state(cand)
                if r and r[4] > cur_score:
                    a, dcount, scount, sums, cur_score = r
                    improved = True
                    break
            if improved:
                break
        if improved:
            continue

        # add random elements near ends (extend AP -> more sum collisions)
        added = False
        for _ in range(40):
            lo = min(a) - 3 * step
            hi = max(a) + 3 * step
            v = random.randint(lo, hi)
            if v in a:
                continue
            cand = a + [v]
            r = try_state(cand)
            if r and r[4] > cur_score:
                a, dcount, scount, sums, cur_score = r
                improved = True
                added = True
                break
        if not improved and not added:
            break

    if cur_score > best_score:
        best = a
        best_score = cur_score

    return sorted(set(best))


if __name__ == "__main__":
    res = solve()
    res = list(set(res))
    if len(res) > 4000:
        res = res[:4000]
    print(len(res), _full(res))
# EVOLVE-BLOCK-END
