# EVOLVE-BLOCK-START
"""Grid construction with a faster scorer and a focused local search."""
import math
import random
import time
import numpy as np


def _score_np(arr):
    n = arr.size
    if n < 2:
        return 0.0
    d = np.subtract.outer(arr, arr).ravel()
    s = np.add.outer(arr, arr).ravel()
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _golomb(n, span):
    marks = [0]
    used = {0}
    cand = 1
    while len(marks) < n and cand <= span:
        ok = True
        for m in marks:
            if abs(cand - m) in used:
                ok = False
                break
        if ok:
            for m in marks:
                used.add(abs(cand - m))
            marks.append(cand)
        cand += 1
    return marks


def _build_grid(nX, nY, M):
    X = _golomb(nX, 40 * nX)
    if len(X) < nX:
        return None
    Y = list(range(nY))
    arr = np.array([x + M * y for y in Y for x in X], dtype=np.int64)
    return arr


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    # Coarse scan over grid parameters, keeping the best structure.
    cands = []
    for nX in range(3, 32):
        if time.time() > deadline:
            break
        for nY in range(2, 26):
            for M in (100, 300, 1000, 3000, 8000):
                arr = _build_grid(nX, nY, M)
                if arr is None:
                    continue
                cands.append(arr)
            if time.time() > deadline:
                break

    random.shuffle(cands)
    for arr in cands:
        if time.time() > deadline:
            break
        sc = _score_np(arr)
        if sc > best_score:
            best_score = sc
            best = arr.copy()

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)
        best_score = _score_np(best)

    # Refinement: try local perturbations including removing "sum-redundant" elements
    # and adding far-away elements to grow the difference set.
    cur = best.copy()
    cur_score = best_score
    rng = random.Random(12345)
    while time.time() < deadline:
        cand = cur.copy()
        op = rng.random()
        if op < 0.5 and cand.size > 3:
            # move a random element to a far position
            idx = rng.randrange(cand.size)
            shift = rng.choice([-1, 1]) * rng.randint(1, 2000)
            cand[idx] += shift
        elif op < 0.85:
            # small jitter
            k = rng.randint(1, max(1, cand.size // 15))
            for _ in range(k):
                idx = rng.randrange(cand.size)
                cand[idx] += rng.randint(-4, 4)
        else:
            # add a new far element
            far = int(cand.max()) + rng.randint(1, 5000)
            cand = np.append(cand, far)
        cand = np.unique(cand)
        if cand.size < 2 or cand.size > 4000:
            continue
        sc = _score_np(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand.copy(), sc

    return sorted(int(v) for v in np.unique(best))
# EVOLVE-BLOCK-END
