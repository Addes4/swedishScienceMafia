# EVOLVE-BLOCK-START
"""Constructive multi-cluster arithmetic-progression builder with greedy polish.

Idea: A = union of g translated copies of a short arithmetic progression of length L,
placed at offsets that behave like a Golomb ruler (so cross-cluster differences are
mostly distinct and fill a wide range), while within each cluster all sums collapse
to a single arithmetic progression of length 2L-1.  Sum set size grows only mildly
with the number of clusters because the cluster-sum sets overlap heavily, whereas the
difference set grows like ~g^2 * L + span.  A greedy asymmetric polish then trims
and shifts elements to improve the ratio.
"""
import math
import random
import time


def _stats(a):
    a = list(dict.fromkeys(a))
    n = len(a)
    if n < 2:
        return 1, 1, 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            if j >= i:
                s = ai + a[j]
                sums.add(s)
    nd = len(diffs)
    ns = len(sums)
    if ns < 2 or nd < 2:
        return nd, ns, 0.0
    score = math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0
    return nd, ns, score


def _golomb_offsets(count, spacing=1, jitter=0):
    """Generate `count` offsets that form a near-Golomb ruler (all pairwise diffs distinct)."""
    offs = [0]
    used = {0}
    step = 1
    for _ in range(count - 1):
        cand = offs[-1] + step * spacing
        tries = 0
        while tries < 200:
            if jitter:
                cand += random.randint(-jitter, jitter)
            ok = True
            for o in offs:
                d = cand - o
                if d == 0:
                    ok = False
                    break
                if d in used or -d in used:
                    ok = False
                    break
            if ok:
                break
            cand += 1
            tries += 1
        offs.append(cand)
        for o in offs[:-1]:
            used.add(offs[-1] - o)
            used.add(o - offs[-1])
        step += 1
    return offs


def _build(clusters, plen, spacing, jitter=0, base=None):
    offs = _golomb_offsets(clusters, spacing, jitter)
    if base is None:
        base = max(offs) + plen * spacing + 1
    A = []
    for k, o in enumerate(offs):
        start = base + o
        for t in range(plen):
            A.append(start + t)
    return A


def _polish(A, deadline, rng):
    nd, ns, sc = _stats(A)
    best = list(A)
    best_sc = sc
    best_nd = nd
    best_ns = ns
    cur = list(A)
    n_cur = len(cur)

    while time.time() < deadline:
        mode = rng.random()
        cand = list(cur)
        if mode < 0.55:
            # perturb an element
            if not cand:
                continue
            i = rng.randrange(len(cand))
            delta = rng.choice([-2, -1, 1, 2, -spacing_guess(cand), spacing_guess(cand)])
            if delta == 0:
                delta = 1
            cand[i] += delta
        elif mode < 0.75:
            # add a new element near an existing one
            if not cand:
                continue
            anchor = rng.choice(cand)
            cand.append(anchor + rng.randint(1, 5))
        elif mode < 0.9:
            # remove an element
            if len(cand) <= 3:
                continue
            i = rng.randrange(len(cand))
            cand.pop(i)
        else:
            if not cand:
                continue
            i = rng.randrange(len(cand))
            cand[i] = -cand[i]

        cand = list(dict.fromkeys(cand))
        if len(cand) < 3:
            continue
        nd_c, ns_c, sc_c = _stats(cand)
        if sc_c > best_sc or (sc_c == best_sc and len(cand) > len(best)):
            best = list(cand)
            best_sc = sc_c
            best_nd = nd_c
            best_ns = ns_c
            cur = list(cand)
        elif sc_c >= best_sc - 0.002 and rng.random() < 0.25:
            cur = list(cand)
    return best


def spacing_guess(a):
    if len(a) < 2:
        return 1
    ds = sorted(abs(a[i] - a[j]) for i in range(len(a)) for j in range(i + 1, len(a)))
    # smallest common gap
    if not ds:
        return 1
    for k in range(1, 6):
        if ds[0] == k:
            return k
    return ds[0] if ds[0] > 0 else 1


def solve():
    """Return a list of distinct integers A minimising the ratio above."""
    start = time.time()
    deadline = start + 110.0
    rng = random.Random(1234567)

    best = None
    best_sc = -1.0

    # Try a family of cluster/progression configurations.
    configs = []
    for clusters in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 28, 32):
        for plen in (2, 3, 4, 5, 6, 8, 10, 12, 14):
            if clusters * plen <= 4000:
                configs.append((clusters, plen))

    # Sort roughly by expected quality: moderate clusters, moderate plen.
    configs.sort(key=lambda cp: abs(cp[0] * cp[1] - 60) + abs(cp[0] - cp[1] * 3))

    checked = 0
    for clusters, plen in configs:
        if time.time() > deadline - 60:
            break
        for spacing in (1, 2, 3):
            A = _build(clusters, plen, spacing, jitter=0)
            _, _, sc = _stats(A)
            if sc > best_sc:
                best_sc = sc
                best = list(A)
            checked += 1
            if checked > 40:
                break
        if checked > 40:
            break

    # Second wave: randomly jittered Golomb offsets.
    while time.time() < deadline - 45:
        clusters = rng.randint(4, 40)
        plen = rng.randint(3, 16)
        if clusters * plen > 4000:
            continue
        spacing = rng.choice([1, 1, 1, 2, 3])
        jitter = rng.choice([0, 1, 2, 3])
        A = _build(clusters, plen, spacing, jitter=jitter)
        _, _, sc = _stats(A)
        if sc > best_sc:
            best_sc = sc
            best = list(A)

    if best is None:
        best = [0, 1, 2, 4, 8]
        best_sc = _stats(best)[2]

    # Greedy polish.
    polished = _polish(best, deadline, rng)
    _, _, psc = _stats(polished)
    if psc > best_sc:
        best = polished

    # Final dedup / sort.
    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    return best
# EVOLVE-BLOCK-END
