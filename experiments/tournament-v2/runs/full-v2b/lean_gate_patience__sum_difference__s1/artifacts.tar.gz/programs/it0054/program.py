# EVOLVE-BLOCK-START
import math
import random
import time
from collections import Counter


def _score_from_counts(nd, ns, n):
    if nd < 2 or ns < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _exact_score(a):
    a = list(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return _score_from_counts(len(diffs), len(sums), n), len(diffs), len(sums)


class Tracker:
    """Maintain difference and sum multiplicity counts incrementally."""
    __slots__ = ("elems", "dcnt", "scnt", "nd", "ns")

    def __init__(self, a):
        self.elems = list(a)
        self.dcnt = Counter()
        self.scnt = Counter()
        for x in self.elems:
            for y in self.elems:
                self.dcnt[x - y] += 1
                self.scnt[x + y] += 1
        self.nd = len(self.dcnt)
        self.ns = len(self.scnt)

    def _add_to_counts(self, x, sign):
        # sign=+1 add x, sign=-1 remove x (remove last)
        for y in self.elems:
            d = x - y
            c = self.dcnt[d] + sign
            if c <= 0:
                del self.dcnt[d]
            else:
                self.dcnt[d] = c
            s = x + y
            c = self.scnt[s] + sign
            if c <= 0:
                del self.scnt[s]
            else:
                self.scnt[s] = c

    def add(self, x):
        # interactions between x and itself
        self._add_to_counts(x, +1)
        # x-x, x+x already counted once via loop (x present? no, x not yet in elems)
        # loop above iterated over existing elems, so we must add x-x and x+x
        d = x - x
        c = self.dcnt[d] + 1
        self.dcnt[d] = c
        s = x + x
        c = self.scnt[s] + 1
        self.scnt[s] = c
        self.elems.append(x)
        self.nd = len(self.dcnt)
        self.ns = len(self.scnt)

    def remove_idx(self, i):
        x = self.elems[i]
        # remove self interactions first
        d = x - x
        c = self.dcnt[d] - 1
        if c <= 0:
            del self.dcnt[d]
        else:
            self.dcnt[d] = c
        s = x + x
        c = self.scnt[s] - 1
        if c <= 0:
            del self.scnt[s]
        else:
            self.scnt[s] = c
        # remove interactions with others (x is still in elems list)
        for j, y in enumerate(self.elems):
            if j == i:
                continue
            d = x - y
            c = self.dcnt[d] - 1
            if c <= 0:
                del self.dcnt[d]
            else:
                self.dcnt[d] = c
            d2 = y - x
            c = self.dcnt[d2] - 1
            if c <= 0:
                del self.dcnt[d2]
            else:
                self.dcnt[d2] = c
            ss = x + y
            c = self.scnt[ss] - 1
            if c <= 0:
                del self.scnt[ss]
            else:
                self.scnt[ss] = c
        del self.elems[i]
        self.nd = len(self.dcnt)
        self.ns = len(self.scnt)

    def score(self):
        return _score_from_counts(self.nd, self.ns, len(self.elems))


def _build_base_sidon(g, maxv):
    """Greedy Sidon-like set: all pairwise sums distinct (and thus differences
    highly spread). Small set, size g."""
    base = [0]
    used_sum = {0}
    cand = 1
    while len(base) < g and cand <= maxv:
        ok = True
        new_sums = []
        for b in base:
            s = cand + b
            if s in used_sum:
                ok = False
                break
            new_sums.append(s)
        if ok:
            base.append(cand)
            for s in new_sums:
                used_sum.add(s)
        cand += 1
    return base


def _two_block(M, q, base):
    a = sorted(set(list(base) + [q + k for k in range(M)]))
    return [x for x in a if -10**15 <= x <= 10**15]


def _search(seed, deadline, rng, max_iter):
    tr = Tracker(seed)
    best = list(tr.elems)
    best_sc = tr.score()
    lo = min(tr.elems)
    hi = max(tr.elems)
    it = 0
    while time.time() < deadline and it < max_iter:
        it += 1
        # occasionally try adding
        improved = False
        # ADD move
        span = hi - lo if hi > lo else 1
        for _ in range(3):
            if time.time() > deadline:
                break
            pos = rng.randrange(lo - span, hi + span + 1)
            if pos in tr.dcnt and False:
                continue
            tr.add(pos)
            sc = tr.score()
            if sc > best_sc + 1e-12:
                best_sc = sc
                best = list(tr.elems)
                lo = min(lo, pos)
                hi = max(hi, pos)
                best_sc = sc
                improved = True
                break
            else:
                tr.remove_idx(len(tr.elems) - 1)
        # REMOVE move
        if len(tr.elems) > 3:
            for _ in range(3):
                if time.time() > deadline:
                    break
                i = rng.randrange(len(tr.elems))
                saved = tr.elems[i]
                tr.remove_idx(i)
                sc = tr.score()
                if sc > best_sc + 1e-12:
                    best_sc = sc
                    best = list(tr.elems)
                    improved = True
                    break
                else:
                    tr.add(saved)
        if not improved and it % 7 == 0:
            # small shift
            i = rng.randrange(len(tr.elems))
            saved = tr.elems[i]
            delta = rng.choice([-2, -1, 1, 2])
            tr.remove_idx(i)
            tr.add(saved + delta)
            sc = tr.score()
            if sc > best_sc + 1e-12:
                best_sc = sc
                best = list(tr.elems)
            else:
                done = False
                # revert: remove new, add old
                try:
                    j = tr.elems.index(saved + delta)
                except ValueError:
                    j = None
                if j is not None:
                    tr.remove_idx(j)
                    tr.add(saved)
    return best, best_sc


def solve():
    rng = random.Random(20240607)
    deadline = time.time() + 110

    best = None
    best_sc = -1.0

    # Candidate sweep over two-block family: small Sidon base + long AP.
    for g in (1, 2, 3, 4, 5, 6, 8):
        base = _build_base_sidon(g, 10**6) if g > 1 else [0]
        for M in (4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 192, 256):
            for q in (M, 2 * M, 3 * M, 4 * M, 5 * M, 7 * M, 9 * M,
                      (M - 1) + base[-1] + 1 if base else M,
                      base[-1] + 1 if base else M,
                      base[-1] + M if base else M):
                if time.time() > deadline - 40:
                    break
                a = _two_block(M, q, base)
                if len(a) < 3 or len(a) > 4000:
                    continue
                if not (-10**15 <= min(a) and max(a) <= 10**15):
                    continue
                sc, nd, ns = _exact_score(a)
                if sc > best_sc:
                    best_sc = sc
                    best = a[:]

    if best is None:
        best = [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377]
        best_sc = _exact_score(best)[0]

    # Local search from the best seed and a couple of perturbations.
    seeds = [best]
    for _ in range(4):
        base = list(best)
        for _ in range(rng.randint(1, 3)):
            if not base:
                break
            i = rng.randrange(len(base))
            base[i] += rng.randint(-3, 3)
        base = sorted(set(base))
        if 3 <= len(base) <= 4000:
            seeds.append(base)

    for sd in seeds:
        if time.time() > deadline - 5:
            break
        res, sc = _search(sd, deadline - 2, rng, max_iter=200000)
        if sc > best_sc:
            best_sc = sc
            best = res

    best = [int(x) for x in best]
    best = sorted(set(best))
    # clamp
    best = [x for x in best if -10**15 <= x <= 10**15]
    if len(best) > 4000:
        best = best[:4000]
    return best
# EVOLVE-BLOCK-END
