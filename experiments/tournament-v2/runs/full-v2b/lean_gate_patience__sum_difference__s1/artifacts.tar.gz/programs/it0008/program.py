# EVOLVE-BLOCK-START
"""Union of translated copies of an AP with a common step, placed at
Golomb-like offsets so that the difference set is large but the sum set
stays inside a narrow arithmetic progression."""
import math
import random
import time


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    if not sums:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / len(a)) / 100


def _golomb(n):
    """Fast approximate Golomb ruler with n marks: marks spaced by an
    increasing sequence of distinct differences (greedy)."""
    marks = [0]
    used = {0}
    while len(marks) < n:
        cand = marks[-1] + 1
        while True:
            ok = True
            for m in marks:
                d = cand - m
                if d in used or d == 0:
                    ok = False
                    break
            if ok:
                break
            cand += 1
        for m in marks:
            used.add(cand - m)
        marks.append(cand)
    return marks


def _build(clusters, width, step, offset_scale):
    """Union of `clusters` translated copies of the AP {k*step} for
    k=0..width-1, placed at Golomb offsets scaled by offset_scale."""
    offs = _golomb(clusters)
    offs = [o * offset_scale for o in offs]
    A = []
    for o in offs:
        for k in range(width):
            A.append(o + k * step)
    return A


def solve():
    """Return A making |A-A| large and |A+A| small."""
    best = None
    best_score = -1.0
    deadline = time.time() + 90

    # structured candidates: unions of translated APs with common step
    for width in range(2, 60):
        for clusters in range(2, 60):
            n = clusters * width
            if n < 2 or n > 4000:
                continue
            # scale so that inter-cluster offsets dominate intra-cluster span
            step = 1
            scale = width * (width + clusters) + 1
            A = _build(clusters, width, step, scale)
            s = _score(A)
            if s > best_score:
                best_score, best = s, A[:]
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    if best is None:
        best = [0, 1, 2, 4, 8]
        best_score = _score(best)

    # local refinement: perturb / add / remove elements near existing ones
    cur = best[:]
    cur_score = best_score
    improve_deadline = time.time() + 20
    while time.time() < improve_deadline:
        mode = random.random()
        if mode < 0.5:
            cand = cur[:]
            base = random.choice(cand)
            cand.append(base + random.randint(-300, 300))
            cand = list(set(cand))
        elif mode < 0.8 and len(cur) > 3:
            cand = cur[:]
            cand.pop(random.randrange(len(cand)))
        else:
            cand = cur[:]
            idx = random.randrange(len(cand))
            cand[idx] += random.randint(-50, 50)
            cand = list(set(cand))
        if len(cand) > 4000 or len(cand) < 2:
            continue
        s = _score(cand)
        if s >= cur_score:
            cur_score, cur = s, cand
            if s > best_score:
                best_score, best = s, cand[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
