# EVOLVE-BLOCK-START
"""Constructive multi-cluster AP builder + greedy polish.

Idea: A = union_{j=1..g} (o_j + {0..L-1}*d)  -- g translated copies of a length-L AP.
Within a cluster, sums collapse to ~2L values; across g clusters we get O(g^2 * L) sums,
so |A+A| ~ g^2 L. Differences between two clusters form a contiguous range of length
about (offset gap + L*d), so the union of all cross-cluster difference ranges (offsets
chosen ``Golomb-ruler-like'' so gaps are large and varied) gives |A-A| ~ sum of ranges,
roughly the spread of the offsets squared. This yields a large ratio.

We then do a cheap greedy polish: try small random perturbations that must not
increase |A+A| much while keeping |A-A| large.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


def _eval(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return -1.0, 0, 0
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    s = math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0
    return s, len(diffs), len(sums)


def _build(g, L, d, seed=0):
    """g clusters, each an AP of length L and stride d, offsets Golomb-like."""
    rnd = random.Random(seed)
    # Golomb-like offsets: spread out, roughly quadratic gaps.
    offsets = [0]
    cur = 0
    for j in range(1, g):
        # gap grows with j (quadratic-ish) but with slight randomness
        gap = L * d + rnd.randint(L * d // 2, max(L * d // 2 + 1, L * d * 3 // 2))
        cur += gap
        offsets.append(cur)
    A = []
    for o in offsets:
        for i in range(L):
            A.append(o + i * d)
    return A


def _polish(best, deadline):
    """Greedy random add/remove/adjust polish under the exact score."""
    best = sorted(set(best))
    try:
        bscore, bd, bs = _eval(best)
    except Exception:
        return best
    if bscore < 0:
        return best
    cur = best[:]
    cscore, cd, cs = bscore, bd, bs
    tries = 0
    while time.time() < deadline:
        tries += 1
        cand = cur[:]
        r = random.random()
        if r < 0.45:
            # adjust a random element by a small delta
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2, 3, -3])
        elif r < 0.75:
            # add a new element near an existing one
            base = random.choice(cand)
            cand.append(base + random.randint(-5, 5))
        else:
            # remove an element (if not too small)
            if len(cand) > 8:
                del cand[random.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(cand) < 2:
            continue
        s, nd, nsu = _eval(cand)
        if s >= cscore:
            cur, cscore, cd, cs = cand, s, nd, nsu
            if s > bscore:
                best, bscore, bd, bs = cand[:], s, nd, nsu
    return best


def solve():
    """Construct multi-cluster AP sets and polish to maximise
    log|A-A|/log|A+A| (plus small large-set bonus)."""
    t_end = time.time() + 110
    best = [7, 15, 18, 22, -3, -2]
    bscore, _, _ = _eval(best)

    # construct several candidate parameter sets and keep the best
    configs = []
    # (g clusters, L per cluster, stride d)
    configs += [(8, 8, 3), (7, 12, 2), (6, 16, 2), (9, 7, 3), (10, 6, 4)]
    configs += [(5, 20, 2), (6, 18, 3), (8, 10, 2), (7, 14, 1),
                (12, 5, 5), (11, 6, 4), (9, 8, 3)]
    configs += [(6, 22, 2), (7, 18, 3), (8, 14, 3), (10, 9, 3),
                (5, 30, 2), (6, 25, 2), (13, 5, 4), (14, 4, 6)]

    for seed in range(6):
        for (g, L, d) in configs:
            if len(best) < L * g:
                pass
            A = _build(g, L, d, seed=seed * 7919 + g * 131 + L)
            s, _, _ = _eval(A)
            if s > bscore:
                best, bscore = A[:], s

    # greedy polish on the best construction
    best = _polish(best, t_end - 40)

    # final polish round with remaining time
    if time.time() < t_end:
        best = _polish(best, t_end)

    return sorted(set(best))
# EVOLVE-BLOCK-END
