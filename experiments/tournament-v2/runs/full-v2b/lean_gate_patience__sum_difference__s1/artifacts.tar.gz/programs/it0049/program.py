# EVOLVE-BLOCK-START
"""Two-block AP seed + fast incremental-multiplicity local search.

Construction: A = {0..L-1} U (q + {0..L-1}).
- Within a block, sums take only 2L-1 values, so |A+A| is O(L) per block.
- Across the two blocks, differences form long intervals; |A-A| is large.
This gives a strong ratio. We then run a local search using dictionaries of
difference/sum multiplicities so each add/remove/move costs O(n) not O(n^2).
"""
import math
import random
import time


def _score_from(diffs, sums, n):
    if n < 2 or not diffs or not sums:
        return -1.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1.0 - 1.0 / n) / 100.0


# ---- incremental multiplicity structures ----

class Multi:
    """Track multiset multiplicities of pairwise diffs and sums for a set."""
    def __init__(self, elems):
        self.a = list(elems)
        self.dmult = {}
        self.smult = {}
        for x in self.a:
            for y in self.a:
                self.dmult[x - y] = self.dmult.get(x - y, 0) + 1
                self.smult[x + y] = self.smult.get(x + y, 0) + 1

    def add(self, v):
        a = self.a
        dm = self.dmult
        sm = self.smult
        for x in a:
            dm[x - v] = dm.get(x - v, 0) + 1
            dm[v - x] = dm.get(v - x, 0) + 1
            sm[x + v] = sm.get(x + v, 0) + 1
            sm[v + x] = sm.get(v + x, 0) + 1
        # x==x counted twice in loop above; self diff already there
        dm[0] = dm.get(0, 0) + 1  # v-v
        sm[2 * v] = sm.get(2 * v, 0) + 1
        a.append(v)

    def remove(self, v):
        a = self.a
        dm = self.dmult
        sm = self.smult
        for x in a:
            if x == v:
                continue
            k = x - v
            dm[k] -= 1
            if dm[k] == 0:
                del dm[k]
            k = v - x
            dm[k] -= 1
            if dm[k] == 0:
                del dm[k]
            k = x + v
            sm[k] -= 1
            if sm[k] == 0:
                del sm[k]
        dm[0] -= 1
        if dm[0] == 0:
            del dm[0]
        k = 2 * v
        sm[k] -= 1
        if sm[k] == 0:
            del sm[k]
        a.remove(v)

    def score(self):
        return _score_from(self.dmult, self.smult, len(self.a))


def _build_two_block(L, q, d=1):
    A = []
    for i in range(L):
        A.append(i * d)
    for i in range(L):
        A.append(q + i * d)
    return sorted(set(A))


def solve():
    t_end = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_s = None

    # sweep two-block family
    candidates = []
    for L in [10, 15, 20, 25, 30, 40, 50, 60]:
        for q in [2 * L, 3 * L, 4 * L, 5 * L, 6 * L, 8 * L,
                  L * L, 2 * L * L + 1, L * L + L // 2]:
            A = _build_two_block(L, q, 1)
            if len(A) > 4000:
                continue
            cands = (L, q, A)
            candidates.append(cands)

    for (L, q, A) in candidates:
        if time.time() > t_end - 90:
            break
        m = Multi(A)
        s = m.score()
        if best_s is None or s > best_s:
            best_s, best = s, list(m.a)

    # local search from the best
    if best_s is None:
        m = Multi(best)
        best_s = m.score()
    else:
        m = Multi(best)
        best_s = m.score()

    cur = m
    cur_s = best_s
    attempts = 0
    while time.time() < t_end:
        attempts += 1
        r = random.random()
        a = cur.a
        if r < 0.40:
            # move a random element by small delta
            i = random.randrange(len(a))
            old = a[i]
            delta = random.choice([-2, -1, 1, 2, 3, -3, 5, -5])
            nv = old + delta
            if nv in a:
                continue
            cur.remove(old)
            cur.add(nv)
            s = cur.score()
            if s >= cur_s:
                cur_s = s
                if s > best_s:
                    best_s = s
                    best = list(cur.a)
            else:
                cur.remove(nv)
                cur.add(old)
        elif r < 0.75:
            # add a new element near an existing one
            base = random.choice(a)
            nv = base + random.choice([-1, 1, 2, -2, 3, -3, 7, -7])
            if nv in a:
                continue
            cur.add(nv)
            s = cur.score()
            if s >= cur_s:
                cur_s = s
                if s > best_s:
                    best_s = s
                    best = list(cur.a)
            else:
                cur.remove(nv)
        else:
            # remove an element
            if len(a) > 6:
                v = random.choice(a)
                cur.remove(v)
                s = cur.score()
                if s >= cur_s:
                    cur_s = s
                    if s > best_s:
                        best_s = s
                        best = list(cur.a)
                else:
                    cur.add(v)

    return sorted(set(best))
# EVOLVE-BLOCK-END

