# EVOLVE-BLOCK-START
"""Focused parametric search for sets with large differences and small sums."""
import math
import time
import random
import numpy as np


def _score_arr(a):
    a = np.asarray(a, dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    nsum = sums.size
    if nsum < 2:
        nsum = 2
    return math.log(diffs.size) / math.log(nsum) + (1 - 1.0 / n) / 100.0


def _two_interval(L, Q):
    A = list(range(0, L)) + list(range(Q, Q + L))
    return sorted(set(A))


def _score_py(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    sums = set()
    diffs = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            sums.add(ai + a[j])
            diffs.add(ai - a[j])
    nsum = len(sums)
    if nsum < 2:
        nsum = 2
    return math.log(len(diffs)) / math.log(nsum) + (1 - 1.0 / n) / 100.0


def _golomb(r):
    marks = [0]
    used = {0}
    while len(marks) < r:
        cand = marks[-1] + 1
        while True:
            ok = True
            for m in marks:
                if cand - m in used:
                    ok = False
                    break
            if ok:
                for m in marks:
                    used.add(cand - m)
                marks.append(cand)
                break
            cand += 1
    return marks


def _multi_cluster(offsets, length, step):
    a = []
    for o in offsets:
        for k in range(length):
            a.append(o + k * step)
    return sorted(set(a))


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    # Phase 1: deterministic sweep over two-interval family (the key family).
    # We want Q large relative to L so difference structure spreads,
    # while each interval creates sum collisions internally.
    N_target = 1200  # total elements ~ 2L, keep <=4000
    for L in range(2, 40):
        for Q in range(L, L + 6 * L + 40):
            A = _two_interval(L, Q)
            if len(A) > 4000:
                continue
            s = _score_py(A)
            if s > best_score:
                best_score = s
                best = A
        if time.time() > deadline - 60:
            break

    # Phase 2: multi-cluster with Golomb offsets (spread differences).
    for g in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20):
        for Lc in (2, 3, 4, 5, 6, 8, 10, 12):
            offsets = _golomb(g)
            for step in (1, 2, 3, 5, 7, 11):
                A = _multi_cluster([o * step for o in offsets], Lc, step)
                if not A or len(A) > 4000:
                    continue
                s = _score_py(A)
                if s > best_score:
                    best_score = s
                    best = A
            if time.time() > deadline - 40:
                break
        if time.time() > deadline - 40:
            break

    if best is None:
        best = _two_interval(4, 20)
        best_score = _score_py(best)

    # Phase 3: local search on best via targeted moves using fast scorer.
    a = list(set(best))
    cur_score = _score_py(a)
    span = max(a) - min(a)
    step = max(1, span // 400)

    while time.time() < deadline - 5:
        improved = False
        # try adding an element that could increase differences without
        # adding many sums: place far from the set
        for v in (min(a) - step, max(a) + step):
            if v in a:
                continue
            cand = a + [v]
            if len(cand) > 4000:
                continue
            s = _score_py(cand)
            if s > cur_score:
                a, cur_score = cand, s
                improved = True
                break
        if improved:
            continue
        # try shifting a "cluster" by a small amount
        found = False
        for i in range(len(a)):
            for delta in (step, -step, 1, -1):
                v = a[i] + delta
                if v in a:
                    continue
                cand = a[:]
                cand[i] = v
                s = _score_py(cand)
                if s > cur_score:
                    a, cur_score = cand, s
                    found = True
                    break
            if found:
                break
        if not found:
            break

    return sorted(set(a))


if __name__ == "__main__":
    a = solve()
    a = list(set(a))
    if len(a) > 4000:
        a = a[:4000]
    print(len(a), _score_py(a))
# EVOLVE-BLOCK-END
