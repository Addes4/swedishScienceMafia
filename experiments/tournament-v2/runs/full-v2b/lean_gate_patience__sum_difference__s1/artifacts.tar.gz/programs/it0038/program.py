# EVOLVE-BLOCK-START
"""Constructive multi-cluster builder + fast incremental local search.

Key speed idea: maintain Counters of difference and sum multiplicities so that
add/remove/shift moves can be evaluated exactly in O(n) time. This lets us do
hundreds of thousands of moves and grow |A| while keeping the ratio high.
"""
import math
import random
import time
from collections import Counter


def _stats(a):
    a = list(dict.fromkeys(a))
    n = len(a)
    if n < 2:
        return 1, 1, 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            if j >= i:
                sums.add(ai + a[j])
    nd = len(diffs)
    ns = len(sums)
    if ns < 2 or nd < 2:
        return nd, ns, 0.0
    score = math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0
    return nd, ns, score


def _score(nd, ns, n):
    if ns < 2 or nd < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


class State:
    """Incremental multiplicity tracker for A - A and A + A."""

    __slots__ = ("a", "dcnt", "scnt", "nd", "ns")

    def __init__(self, elems):
        self.a = list(elems)
        self.dcnt = Counter()
        self.scnt = Counter()
        n = len(self.a)
        for i in range(n):
            ai = self.a[i]
            for j in range(n):
                self.dcnt[ai - self.a[j]] += 1
        for i in range(n):
            ai = self.a[i]
            for j in range(i, n):
                self.scnt[ai + self.a[j]] += 1
        self.nd = len(self.dcnt)
        self.ns = len(self.scnt)

    def add(self, x):
        """Add element x; assumes not present."""
        inc_d = Counter()
        inc_s = Counter()
        for y in self.a:
            inc_d[x - y] += 1
            inc_d[y - x] += 1
            inc_s[x + y] += 1
        inc_d[0] = 0  # self-self diff already; handle below
        # self pair diff = 0
        inc_d[0] += 1
        inc_s[2 * x] += 1
        for k, v in inc_d.items():
            if v == 0:
                continue
            if k not in self.dcnt:
                self.nd += 1
            self.dcnt[k] += v
        for k, v in inc_s.items():
            if k not in self.scnt:
                self.ns += 1
            self.scnt[k] += v
        self.a.append(x)

    def remove(self, idx):
        x = self.a[idx]
        # update counts by walking pairs involving x
        for j, y in enumerate(self.a):
            if j == idx:
                continue
            d1 = x - y
            d2 = y - x
            self.dcnt[d1] -= 1
            if self.dcnt[d1] == 0:
                del self.dcnt[d1]
                self.nd -= 1
            self.dcnt[d2] -= 1
            if self.dcnt[d2] == 0:
                del self.dcnt[d2]
                self.nd -= 1
            s = x + y
            self.scnt[s] -= 1
            if self.scnt[s] == 0:
                del self.scnt[s]
                self.ns -= 1
        self.dcnt[0] -= 1
        if self.dcnt[0] == 0:
            del self.dcnt[0]
            self.nd -= 1
        s = 2 * x
        self.scnt[s] -= 1
        if self.scnt[s] == 0:
            del self.scnt[s]
            self.ns -= 1
        self.a.pop(idx)

    def shift(self, idx, newval):
        x = self.a[idx]
        if newval == x:
            return
        self.remove(idx)
        self.add(newval)


def _golomb_offsets(count, spacing=1):
    offs = [0]
    used = {0}
    cur = 0
    step = 1
    for _ in range(count - 1):
        cand = cur + step * spacing
        tries = 0
        while tries < 500:
            ok = True
            for o in offs:
                d = cand - o
                if d == 0 or d in used or -d in used:
                    ok = False
                    break
            if ok:
                break
            cand += 1
            tries += 1
        offs.append(cand)
        for o in offs[:-1]:
            used.add(cand - o)
            used.add(o - cand)
        cur = cand
        step += 1
    return offs


def _build(clusters, plen, spacing):
    offs = _golomb_offsets(clusters, spacing)
    base = max(offs) + plen * spacing + 1
    A = []
    for o in offs:
        start = base + o
        for t in range(plen):
            A.append(start + t)
    return A


def _local_search(st, deadline, rng, span):
    best_a = list(st.a)
    best_nd = st.nd
    best_ns = st.ns
    best_n = len(st.a)
    best_sc = _score(st.nd, st.ns, best_n)

    it = 0
    while True:
        it += 1
        if (it & 63) == 0 and time.time() > deadline:
            break
        n = len(st.a)
        if n < 3:
            break
        mode = rng.random()
        if mode < 0.45:
            # shift an element
            i = rng.randrange(n)
            old = st.a[i]
            delta = rng.choice([-3, -2, -1, 1, 2, 3, -span, span])
            st.shift(i, old + delta)
        elif mode < 0.80:
            # add new element near an anchor
            anchor = st.a[rng.randrange(n)]
            x = anchor + rng.randint(1, max(2, span))
            if x in st.dcnt or x in st.a:
                continue
            st.add(x)
        else:
            # remove an element
            if n <= 4:
                continue
            st.remove(rng.randrange(n))

        n2 = len(st.a)
        sc = _score(st.nd, st.ns, n2)
        if sc > best_sc or (sc == best_sc and n2 > best_n):
            best_sc = sc
            best_nd = st.nd
            best_ns = st.ns
            best_n = n2
            best_a = list(st.a)
    return best_a, best_nd, best_ns, best_sc


def solve():
    start = time.time()
    deadline = start + 112.0
    rng = random.Random(987654321)

    best_a = None
    best_sc = -1.0

    # Seed sweeping: multi-cluster construction over configs.
    seeds = []
    for clusters in (4, 6, 8, 10, 12, 16, 20, 24, 30):
        for plen in (4, 5, 6, 8, 10, 12):
            if clusters * plen <= 900:
                seeds.append((clusters, plen))
    seeds.sort(key=lambda cp: abs(cp[0] - 12) + abs(cp[1] - 6))

    for clusters, plen in seeds[:8]:
        if time.time() > deadline * 0 + start + 8:
            break
        A = _build(clusters, plen, 1)
        nd, ns, sc = _stats(A)
        if sc > best_sc:
            best_sc = sc
            best_a = A

    if best_a is None:
        best_a = _build(10, 6, 1)
        best_sc = _stats(best_a)[2]

    # Iterated local search with restarts.
    while time.time() < deadline:
        base = list(best_a) if best_a and rng.random() < 0.6 else _build(
            rng.randint(6, 20), rng.randint(4, 10), 1)
        # small random perturbation
        for _ in range(rng.randint(0, 3)):
            if base:
                i = rng.randrange(len(base))
                base[i] += rng.choice([-2, -1, 1, 2])
        base = list(dict.fromkeys(base))
        if len(base) < 3:
            continue
        span = 5
        st = State(base)
        a, nd, ns, sc = _local_search(st, min(deadline, time.time() + 12.0), rng, span)
        if sc > best_sc:
            best_sc = sc
            best_a = a

    best_a = sorted(set(int(x) for x in best_a))
    if len(best_a) > 4000:
        best_a = best_a[:4000]
    return best_a
# EVOLVE-BLOCK-END
