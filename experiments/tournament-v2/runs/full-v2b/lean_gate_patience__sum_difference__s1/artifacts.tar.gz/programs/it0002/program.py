# EVOLVE-BLOCK-START
"""Greedy Sidon-set construction: maximise |A-A| (nearly n^2) while keeping |A+A| small."""
import math
import random
import time


def _score(a):
    a = list(set(a))
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
            sums.add(x + y)
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _greedy_sidon(max_val, max_n):
    """Build the lexicographically-greedy Sidon set (all pairwise sums distinct, equivalently
    all positive differences distinct) staying within [0, max_val]."""
    A = []
    used_sums = set()
    i = 0
    while len(A) < max_n and i <= max_val:
        ok = True
        for a in A:
            s = a + i
            if s in used_sums or (2 * i) in used_sums:
                ok = False
                break
        if ok:
            for a in A:
                used_sums.add(a + i)
            used_sums.add(2 * i)
            A.append(i)
        i += 1
    return A


def solve():
    best = None
    best_score = -1.0
    deadline = time.time() + 100

    # Try greedy Sidon sets on a range of size limits; record the best-scoring ones.
    candidates = []
    for max_val in list(range(30, 400, 10)) + list(range(400, 3000, 100)):
        A = _greedy_sidon(max_val, 4000)
        if len(A) >= 2:
            candidates.append((A, max_val))

    for A, base in candidates:
        s = _score(A)
        if s > best_score:
            best, best_score = A[:], s

    # Local search refinement: try shifting individual elements to reduce sum-set size
    # without collapsing the difference set.
    if best is not None:
        cur = best[:]
        cur_score = best_score
        rng = random.Random(12345)
        while time.time() < deadline:
            cand = cur[:]
            i = rng.randrange(len(cand))
            cand[i] += rng.randint(-5, 5)
            cand = sorted(set(cand))
            if len(cand) < 2:
                continue
            s = _score(cand)
            if s >= cur_score:
                cur, cur_score = cand, s
                if s > best_score:
                    best, best_score = cand[:], s

    if best is None:
        best = [7, 15, 18, 22, -3, -2]

    # Centre-ish normalization doesn't change score; return sorted distinct.
    return sorted(set(best))
# EVOLVE-BLOCK-END
