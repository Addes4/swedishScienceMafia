# EVOLVE-BLOCK-START
"""Sets with large difference sets and small sum sets.

Idea: use the classic Sidon-set construction based on a quadratic map modulo m.
For a prime m, the set B = {2*m*i + (i*i mod m) : i = 0..m-1} is a Sidon set, i.e.
all pairwise sums (hence all nonzero differences) are distinct.  By taking only
the first k elements we get |A-A| as large as possible for that size, and by
choosing k appropriately we control |A+A|.  A short local search then tweaks
individual elements to try to reduce |A+A| further (or grow |A-A|).

The score is log|A-A| / log|A+A| plus a small bonus favouring larger sets.
"""
import math
import random
import time


def _score(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = set()
    sums = set()
    la = list(a)
    for x in la:
        for y in la:
            diffs.add(x - y)
            sums.add(x + y)
    if len(sums) < 2:
        return 0.0
    return math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100


def _is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def _sidon_prefix(m, k):
    """First k elements of the Sidon set {2*m*i + (i*i mod m)}."""
    return [2 * m * i + (i * i) % m for i in range(k)]


def solve():
    """Return a list of distinct integers A making |A - A| large and |A + A| small."""
    random.seed(12345)
    deadline = time.time() + 110

    best = [7, 15, 18, 22, -3, -2]
    best_score = _score(best)

    # try several Sidon prefixes and keep the best scoring one
    seeds = []
    for m in (1009, 2011, 4013, 8009, 16061, 32009, 64007, 128021):
        # roughly optimise k: larger k grows both sets, but the ratio tends to
        # improve with larger k for Sidon-type sets, so try a spread of sizes
        for k in (m // 8, m // 4, m // 2, int(m * 0.7), m):
            k = max(5, min(k, 4000, m))
            seeds.append(_sidon_prefix(m, k))

    for s in seeds:
        sc = _score(s)
        if sc > best_score:
            best, best_score = s[:], sc

    # greedy element-wise perturbation of the current best to reduce sums
    cur = best[:]
    used = set(cur)
    while time.time() < deadline:
        cand = cur[:]
        i = random.randrange(len(cand))
        if random.random() < 0.5:
            cand[i] += random.randint(-5, 5)
        else:
            cand[i] += random.choice([-1, 1]) * random.randint(1, 1000)
        if len(set(cand)) != len(cand):
            continue
        sc = _score(cand)
        if sc > best_score:
            best, best_score, cur = cand[:], sc, cand
        elif sc > _score(cur) and random.random() < 0.3:
            cur = cand

    return sorted(set(best))
# EVOLVE-BLOCK-END
