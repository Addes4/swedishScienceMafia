# EVOLVE-BLOCK-START
"""Structured search for sets maximising log|A-A|/log|A+A|.

The best known finite constructions for a large difference set / small sum set
come from the "two-interval" family  A = {0..L-1} U (Q + {0..L-1}).
Inside one interval sums collide onto a short AP (2L-1 sums), while the gap Q
spreads the differences.  We exhaustively score this family over a grid of
(L, Q), then locally refine the offsets (the far block may be shifted by a
small perturbation) and finally polish by adding/removing single elements.
"""
import math
import time
import numpy as np


def _score(a):
    n = len(a)
    if n < 2:
        return -1.0, 1, 1
    a = np.asarray(a, dtype=np.int64)
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    ns = int(sums.size)
    nd = int(diffs.size)
    if ns < 2:
        return -1.0, nd, ns
    return math.log(nd) / math.log(ns), nd, ns


def _bonus_score(a):
    """Full objective: ratio + tiny bonus favouring larger sets."""
    s, nd, ns = _score(a)
    n = len(a)
    if n < 2:
        return -1.0
    return s + (1.0 - 1.0 / n) / 100.0


def solve():
    t_end = time.time() + 117.0
    rng = np.random.default_rng(12345)

    best = None
    best_full = -1.0
    best_ratio = -1.0

    def consider(arr):
        nonlocal best, best_full, best_ratio
        arr = np.unique(np.asarray(arr, dtype=np.int64))
        if arr.size < 2 or arr.size > 4000:
            return
        f = _bonus_score(arr)
        r, _, _ = _score(arr)
        if f > best_full:
            best_full = f
            best_ratio = r
            best = arr.copy()

    # ---- exhaustive grid over the two-interval family -------------------
    # A = {0..L-1} U (Q + {0..L-1});  n = 2L.
    grid_best = None
    grid_best_full = -1.0
    for L in range(2, 61):
        lo = L  # Q at least L keeps the blocks disjoint
        hi = max(lo + 1, int(6 * L * L))
        # coarse then fine scan of Q
        step = max(1, (hi - lo) // 400)
        Qs = list(range(lo, hi + 1, step))
        for Q in Qs:
            if time.time() > t_end * 0.5:
                break
            A = np.concatenate([np.arange(L, dtype=np.int64),
                                Q + np.arange(L, dtype=np.int64)])
            f = _bonus_score(A)
            if f > grid_best_full:
                grid_best_full = f
                grid_best = A.copy()
                consider(A)
        if time.time() > t_end * 0.5:
            break

    # ---- refine the best grid point over fine Q neighborhood ------------
    if grid_best is not None:
        # recover (L, Q0) from the rounded structure
        A = np.unique(grid_best)
        L = A.size // 2
        Q0 = int(A[L] - 0)  # first far element is Q0 (since near block is 0..L-1)
        for Q in range(max(L, Q0 - 30), Q0 + 31):
            if time.time() > t_end * 0.6:
                break
            B = np.concatenate([np.arange(L, dtype=np.int64),
                                Q + np.arange(L, dtype=np.int64)])
            consider(B)

    # ---- local polish: shift far block by small delta, add/remove points -
    if best is not None:
        cur = best.copy()
        cur_f = _bonus_score(cur)
        while time.time() < t_end:
            improved = False
            # try shifting a contiguous half of elements (far block) by delta
            for delta in (-3, -2, -1, 1, 2, 3):
                if time.time() > t_end:
                    break
                B = cur.copy()
                mid = len(B) // 2
                B[mid:] = B[mid:] + delta
                B = np.unique(B)
                if B.size < 2:
                    continue
                f = _bonus_score(B)
                if f > cur_f + 1e-12:
                    cur = B
                    cur_f = f
                    improved = True
                    consider(B)
                    break
            if improved:
                continue
            # try add / remove a point to nudge the ratio
            m = len(cur)
            best_local = None
            best_local_f = cur_f
            # removal of each element (cheap-ish for small sets)
            if m > 3 and time.time() < t_end - 1.0:
                for i in range(m):
                    if time.time() > t_end:
                        break
                    B = np.delete(cur, i)
                    f = _bonus_score(B)
                    if f > best_local_f + 1e-12:
                        best_local_f = f
                        best_local = B.copy()
            # try a few random additions
            if m < 4000 and time.time() < t_end - 1.0:
                span = int(cur.max() - cur.min()) + 1
                for _ in range(20):
                    if time.time() > t_end:
                        break
                    v = int(cur.min()) + int(rng.integers(0, max(2, span)))
                    B = np.unique(np.append(cur, v))
                    f = _bonus_score(B)
                    if f > best_local_f + 1e-12:
                        best_local_f = f
                        best_local = B.copy()
            if best_local is not None:
                cur = best_local
                cur_f = best_local_f
                consider(cur)
            else:
                break

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)

    best = np.unique(best.astype(np.int64))
    if best.size > 4000:
        best = best[:4000]
    lo = -10 ** 15
    hi = 10 ** 15
    out = [int(max(lo, min(hi, int(x)))) for x in best]
    return out
# EVOLVE-BLOCK-END
