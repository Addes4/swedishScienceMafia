# EVOLVE-BLOCK-START
"""Multi-cluster AP seed + fast incremental hill climbing.

Seed: A = union_{j=1..g} (o_j + {0..L-1}*d) with Golomb-like offsets:
intra-cluster sums collapse (few sums) while cross-cluster differences fill
long intervals (many differences).

We then run a hill climber that maintains, incrementally, the dictionaries of
difference/sum multiplicities. Adding/removing/shifting one element is O(n),
so we can perform a huge number of moves within the time budget and push the
ratio well above the raw construction.
"""
import math
import random
import time


def solve():
    t_end = time.time() + 110
    rnd = random.Random(20240607)

    def score(nd, ns, n):
        if n < 2 or nd < 1 or ns < 1:
            return -1.0
        return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0

    def build(g, L, d, seed):
        r = random.Random(seed)
        offs = [0]
        cur = 0
        for j in range(1, g):
            lo = max(1, (L * d) // 2)
            hi = max(lo + 1, (L * d * 3) // 2)
            cur += L * d + r.randint(lo, hi)
            offs.append(cur)
        A = []
        for o in offs:
            for i in range(L):
                A.append(o + i * d)
        return A

    def full_eval(A):
        S = set(A)
        n = len(S)
        if n < 2:
            return -1.0
        md = {}
        for x in S:
            for y in S:
                md[x - y] = md.get(x - y, 0) + 1
        ms = {}
        for x in S:
            for y in S:
                ms[x + y] = ms.get(x + y, 0) + 1
        return score(len(md), len(ms), n)

    configs = [
        (8, 8, 3), (7, 12, 2), (6, 16, 2), (9, 7, 3), (10, 6, 4),
        (5, 20, 2), (6, 18, 3), (8, 10, 2), (7, 14, 1), (12, 5, 5),
        (11, 6, 4), (9, 8, 3), (6, 22, 2), (7, 18, 3), (8, 14, 3),
        (10, 9, 3), (5, 30, 2), (6, 25, 2), (13, 5, 4), (14, 4, 6),
        (4, 24, 2), (6, 20, 4), (15, 5, 3), (16, 4, 5),
    ]

    best = [0, 1, 3, 7, 15]
    bsc = full_eval(best)
    for (g, L, d) in configs:
        for s in range(2):
            A = build(g, L, d, s * 131 + g * 7 + L * 3 + d)
            sc = full_eval(A)
            if sc > bsc:
                bsc = sc
                best = A[:]

    # ---- incremental state ----
    S = set(best)
    md = {}
    ms = {}
    for x in S:
        for y in S:
            md[x - y] = md.get(x - y, 0) + 1
            ms[x + y] = ms.get(x + y, 0) + 1
    nd = len(md)
    ns = len(ms)
    cur = score(nd, ns, len(S))
    bestS = set(S)
    best_sc = cur

    def add(x):
        nonlocal nd, ns
        for y in S:
            dd = x - y
            c = md.get(dd, 0)
            if c == 0:
                nd += 1
            md[dd] = c + 1
            dd = y - x
            c = md.get(dd, 0)
            if c == 0:
                nd += 1
            md[dd] = c + 1
            ss = x + y
            c = ms.get(ss, 0)
            if c == 0:
                ns += 1
            ms[ss] = c + 1
        c = md.get(0, 0)
        if c == 0:
            nd += 1
        md[0] = c + 1
        S.add(x)

    def rem(x):
        nonlocal nd, ns
        S.discard(x)
        for y in S:
            dd = x - y
            c = md[dd]
            md[dd] = c - 1
            if c - 1 == 0:
                nd -= 1
            dd = y - x
            c = md[dd]
            md[dd] = c - 1
            if c - 1 == 0:
                nd -= 1
            ss = x + y
            c = ms[ss]
            ms[ss] = c - 1
            if c - 1 == 0:
                ns -= 1
        c = md[0]
        md[0] = c - 1
        if c - 1 == 0:
            nd -= 1

    eps = 1e-12
    shifts = [-1, 1, -2, 2, -3, 3, -4, 4, -6, 6, -9, 9, -14, 14, -20, 20]

    while time.time() < t_end:
        for _ in range(3000):
            if time.time() >= t_end:
                break
            r = rnd.random()
            if r < 0.62:
                x = rnd.choice(tuple(S))
                delta = rnd.choice(shifts)
                y = x + delta
                if y == x or y in S:
                    continue
                rem(x)
                add(y)
                sc = score(nd, ns, len(S))
                if sc >= cur - eps:
                    cur = sc
                    if sc > best_sc:
                        best_sc = sc
                        bestS = set(S)
                else:
                    rem(y)
                    add(x)
            elif r < 0.86:
                if len(S) < 400:
                    base = rnd.choice(tuple(S))
                    x = base + rnd.randint(-30, 30)
                    if x in S:
                        continue
                    add(x)
                    sc = score(nd, ns, len(S))
                    if sc >= cur - eps:
                        cur = sc
                        if sc > best_sc:
                            best_sc = sc
                            bestS = set(S)
                    else:
                        rem(x)
            else:
                if len(S) > 4:
                    x = rnd.choice(tuple(S))
                    rem(x)
                    sc = score(nd, ns, len(S))
                    if sc >= cur - eps:
                        cur = sc
                        if sc > best_sc:
                            best_sc = sc
                            bestS = set(S)
                    else:
                        add(x)

        # re-seed current state from best with a small perturbation to escape
        if time.time() < t_end:
            S = set(bestS)
            md = {}
            ms = {}
            for x in S:
                for y in S:
                    md[x - y] = md.get(x - y, 0) + 1
                    ms[x + y] = ms.get(x + y, 0) + 1
            nd = len(md)
            ns = len(ms)
            cur = score(nd, ns, len(S))
            # random perturbation
            for _ in range(rnd.randint(1, 3)):
                if rnd.random() < 0.5 and len(S) < 400:
                    base = rnd.choice(tuple(S))
                    x = base + rnd.randint(-25, 25)
                    if x not in S:
                        add(x)
                elif len(S) > 4:
                    x = rnd.choice(tuple(S))
                    rem(x)
            cur = score(nd, ns, len(S))

    return sorted(bestS)


# EVOLVE-BLOCK-END
