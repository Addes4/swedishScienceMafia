# EVOLVE-BLOCK-START
"""Behrend-style set on a sphere in dimension d, flattened with a base B.
Sums stay in a bounded range so |A+A| is compressed, while differences spread
out across a large integer range, maximizing log|A-A|/log|A+A|.
Then refine with fast numpy incremental scoring.
"""
import math
import random
import time
import numpy as np


def _score_from_arrays(arr):
    n = arr.size
    if n < 2:
        return 0.0
    d = np.subtract.outer(arr, arr).ravel()
    s = np.add.outer(arr, arr).ravel()
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _behrend(d, base, radius):
    """Points on sphere of radius^2 = sum x_i^2 within [0, base)^d.
    Returns list of flattened integers sum x_i * base^i."""
    # Enumerate all tuples in [0,base)^d with sum of squares == radius^2
    pts = []
    # recursive search with pruning
    target = radius * radius

    def rec(coord, idx, rem_sq):
        if idx == d:
            if rem_sq == 0:
                v = 0
                p = 1
                for c in coord:
                    v += c * p
                    p *= base
                pts.append(v)
            return
        # remaining max contributions
        remaining = d - idx
        lo = 0
        hi = base - 1
        # prune: need rem_sq between 0 and remaining*(base-1)^2
        if rem_sq < 0 or rem_sq > remaining * (base - 1) * (base - 1):
            return
        for c in range(lo, hi + 1):
            rec(coord + [c], idx + 1, rem_sq - c * c)

    rec([], 0, target)
    return pts


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    # Behrend-style: search small dimensions/base/radius for many sphere points
    # Choose base large enough that flattening is injective, radius chosen so
    # many points lie on the sphere.
    configs = []
    for d in (2, 3, 4, 5, 6):
        for base in (10, 16, 20, 24, 32, 40):
            max_r = int(math.sqrt(d) * (base - 1)) + 1
            for r in range(2, max_r + 1, 1):
                configs.append((d, base, r))

    # Evaluate a subset (full enumeration may be slow); prioritize promising
    random.shuffle(configs)
    for (d, base, r) in configs:
        if time.time() > deadline * 0.5:
            break
        pts = _behrend(d, base, r)
        if len(pts) < 6 or len(pts) > 3000:
            continue
        arr = np.array(sorted(set(pts)), dtype=np.int64)
        if arr.size < 2:
            continue
        sc = _score_from_arrays(arr)
        if sc > best_score:
            best_score = sc
            best = arr.copy()

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)
        best_score = _score_from_arrays(best)

    # Local refinement: random single/multiple element perturbations
    cur = best.copy()
    cur_score = best_score
    rng = np.random.default_rng(12345)
    span = int(cur.max() - cur.min()) + 100
    it = 0
    while time.time() < deadline and it < 60000:
        it += 1
        cand = cur.copy()
        k = 1 if rng.random() < 0.7 else rng.integers(1, max(2, len(cand) // 30) + 1)
        idx = rng.integers(0, len(cand), size=int(k))
        # mutate chosen elements by small amounts
        delta = rng.integers(-5, 6, size=int(k)).astype(np.int64)
        cand[idx] = cand[idx] + delta
        cand = np.unique(cand)
        if cand.size < 2:
            continue
        sc = _score_from_arrays(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand.copy(), sc

    return sorted(int(v) for v in np.unique(best))
# EVOLVE-BLOCK-END
