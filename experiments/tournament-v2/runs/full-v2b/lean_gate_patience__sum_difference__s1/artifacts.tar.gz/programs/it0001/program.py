# EVOLVE-BLOCK-START
"""Greedy Sidon-like / Golomb-ruler construction plus local search to balance difference vs sum sets."""
import math
import random
import time


def _counts(a):
    diffs = {x - y for x in a for y in a}
    sums = {x + y for x in a for y in a}
    return len(diffs), len(sums)


def _score(a):
    a = set(a)
    if len(a) < 2:
        return 0.0
    d, s = _counts(list(a))
    if s < 2:
        return 0.0
    return math.log(d) / math.log(s) + (1 - 1 / len(a)) / 100


def _greedy_sidon(n, scale=1):
    """Build a set with all pairwise differences distinct (Golomb ruler style),
    scaled/offset to try to keep the sum set small relative to the difference set."""
    used_diffs = {0}
    A = [0]
    while len(A) < n:
        # pick next element: smallest value that keeps all diffs new
        cand = A[-1] + 1
        while True:
            new_diffs = []
            ok = True
            for x in A:
                d = cand - x
                if d in used_diffs or -d in used_diffs:
                    ok = False
                    break
                new_diffs.append(d)
            if ok:
                for d in new_diffs:
                    used_diffs.add(d)
                    used_diffs.add(-d)
                A.append(cand)
                break
            cand += 1
        if cand > 10 ** 6 * scale:
            break
    return A


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    # Multi-start over Sidon constructions of various sizes, then local search
    for n in (30, 50, 80, 120, 160, 200, 256):
        if time.time() > deadline:
            break
        A = _greedy_sidon(n)
        if len(A) < 4:
            continue
        # Center around 0 to make sums cluster (sum set overlaps more)
        mid = (A[0] + A[-1]) // 2
        A = [x - mid for x in A]
        d, s = _counts(A)
        sc = math.log(d) / math.log(s) + (1 - 1 / len(A)) / 100
        if sc > best_score:
            best_score, best = sc, A[:]

    if best is None:
        best = [7, 15, 18, 22, -3, -2]
        best_score = _score(best)

    # Local search: small perturbations, occasionally scale by 2 to change sum collisions
    cur = best[:]
    while time.time() < deadline:
        cand = cur[:]
        r = random.random()
        if r < 0.5:
            i = random.randrange(len(cand))
            cand[i] += random.choice([-2, -1, 1, 2])
        elif r < 0.8:
            cand.append(random.randint(-5, 5) + random.choice(cand))
        elif len(cand) > 6:
            del cand[random.randrange(len(cand))]
        cand = sorted(set(cand))
        if len(set(cand)) < 2:
            continue
        d, s = _counts(cand)
        if s < 2:
            continue
        sc = math.log(d) / math.log(s) + (1 - 1 / len(cand)) / 100
        if sc >= best_score:
            best_score, cur, best = sc, cand, cand[:]
        elif random.random() < 0.05:
            cur = best[:]

    return sorted(set(best))
# EVOLVE-BLOCK-END
