# EVOLVE-BLOCK-START
"""Build A = X + M*[0,k) where X is a Sidon-like base with many distinct differences.

Within-cluster (same X element, different t): copies of an AP => few sums, many diffs.
Cross X elements: differences of form (x_i - x_j) + M*(t_i - t_j). If X is a Sidon set
(all pairwise differences distinct) then cross differences are spread widely over a long
interval, giving |A-A| close to the maximum, while |A+A| stays modest.

We sweep X over Golomb-ruler constructions and greedy-Sidon grids, M and k, scoring
exactly with a fast bit-free O(n^2) difference/sum counter, and keep the best ratio.
Also try pure Sidon/Golomb sets of maximal size for a given span (many distinct diffs).
"""
import math
import random
import time


def _score(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 1, 1, 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            aj = a[j]
            diffs.add(ai - aj)
            sums.add(ai + aj)
    s = math.log(len(diffs)) / math.log(len(sums)) + (1 - 1 / n) / 100
    return len(diffs), len(sums), s


def _bc_block(M, k):
    """[0, M, 2M, ..., (k-1)M]"""
    return [i * M for i in range(k)]


def _greedy_sidon(n, span, seed):
    """Greedy Sidon set (all pairwise sums distinct) of size n within [0,span]."""
    rng = random.Random(seed)
    chosen = []
    sums = set()
    candidates = list(range(span + 1))
    rng.shuffle(candidates)
    def feasible(x, chosen, sums):
        for c in chosen:
            s = c + x
            if s in sums:
                return False
        for i in range(len(chosen)):
            for j in range(i + 1, len(chosen)):
                pass
        return True
    for x in candidates:
        ok = True
        for c in chosen:
            if (c + x) in sums:
                ok = False
                break
        if ok:
            for c in chosen:
                sums.add(c + x)
            sums.add(2 * x)
            chosen.append(x)
            if len(chosen) >= n:
                break
    return sorted(chosen)


def _golomb(n, span):
    """Simple greedy Golomb ruler (distinct differences), n marks within [0,span]."""
    marks = [0]
    used = set()
    cur = 0
    while len(marks) < n and cur < span:
        step = 1
        placed = False
        while cur + step <= span:
            cand = cur + step
            newd = [cand - m for m in marks]
            ok = all(d not in used for d in newd) and \
                 all((cand - m) not in used for m in marks)
            # also require cand - m distinct and positive
            if len(set(newd)) == len(newd) and all(d > 0 for d in newd) and \
               all(d not in used for d in newd):
                for d in newd:
                    used.add(d)
                marks.append(cand)
                cur = cand
                placed = True
                break
            step += 1
        if not placed:
            break
        cur = marks[-1]
    return marks


def _assemble(X, M, k):
    A = []
    for x in X:
        for t in range(k):
            A.append(x + M * t)
    return sorted(set(A))


def solve():
    best = [0, 1, 2, 3, 4, 5]
    _, _, best_score = _score(best)
    deadline = time.time() + 110

    # cache X constructions
    Xs = []
    rng = random.Random(7)
    for n in range(3, 26):
        for span in (n - 1, 2 * n, 4 * n, 8 * n, 16 * n, 32 * n):
            Xs.append(_golomb(n, span))
    for seed in range(40):
        for n in (4, 6, 8, 10, 12, 16):
            for span in (2 * n, 4 * n, 8 * n):
                Xs.append(_greedy_sidon(n, span, seed * 97 + n))
    Xs.append([0])

    configs = []
    for X in Xs:
        if len(X) < 2:
            continue
        maxx = max(X)
        for M in (maxx + 1, 2 * maxx + 1, 4 * maxx + 1, 8 * maxx + 1,
                  int(1.5 * maxx) + 2, 3 * maxx + 2):
            if M <= 0:
                continue
            for k in (1, 2, 3, 4, 5, 6, 8, 10, 12):
                configs.append((X, M, k))
    rng.shuffle(configs)

    for (X, M, k) in configs:
        if time.time() > deadline - 1:
            break
        A = _assemble(X, M, k)
        if len(A) < 2:
            continue
        if len(A) > 4000:
            continue
        _, _, s = _score(A)
        if s > best_score:
            best_score = s
            best = A[:]

    best = sorted(set(int(x) for x in best))
    return best
# EVOLVE-BLOCK-END
