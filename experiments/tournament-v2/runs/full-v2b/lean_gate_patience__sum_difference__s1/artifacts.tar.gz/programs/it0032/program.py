# EVOLVE-BLOCK-START
"""Grid construction A = { x + M*y } with X a Golomb ruler and Y a short interval,
then a fast incremental local search (add/remove/shift) using multiplicity dicts."""
import math
import random
import time


def _stats(L):
    n = len(L)
    dmul = {}
    smul = {}
    for i in range(n):
        xi = L[i]
        for j in range(i, n):
            xj = L[j]
            s = xi + xj
            smul[s] = smul.get(s, 0) + 1
            if i != j:
                d = xi - xj
                dmul[d] = dmul.get(d, 0) + 1
                d = -d
                dmul[d] = dmul.get(d, 0) + 1
    return dmul, smul


def _score_from_counts(nd, ns, n):
    if ns <= 1 or nd <= 1:
        return -1.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score(L):
    L = sorted(set(L))
    dm, sm = _stats(L)
    return _score_from_counts(len(dm), len(sm), len(L))


# ---------- incremental move machinery ----------

class State:
    __slots__ = ("S", "dmul", "smul", "nd", "ns")

    def __init__(self, elems):
        self.S = sorted(set(elems))
        self.dmul, self.smul = _stats(self.S)
        self.nd = len(self.dmul)
        self.ns = len(self.smul)

    def score(self):
        return _score_from_counts(self.nd, self.ns, len(self.S))

    def _add_sum(self, s):
        c = self.smul.get(s, 0)
        self.smul[s] = c + 1
        if c == 0:
            self.ns += 1

    def _del_sum(self, s):
        c = self.smul.get(s, 0)
        if c == 1:
            del self.smul[s]
            self.ns -= 1
        elif c > 1:
            self.smul[s] = c - 1

    def _add_diff(self, d):
        c = self.dmul.get(d, 0)
        self.dmul[d] = c + 1
        if c == 0:
            self.nd += 1

    def _del_diff(self, d):
        c = self.dmul.get(d, 0)
        if c == 1:
            del self.dmul[d]
            self.nd -= 1
        elif c > 1:
            self.dmul[d] = c - 1

    def remove(self, x):
        S = self.S
        # remove x contributions
        for y in S:
            self._del_sum(x + y)
            if y != x:
                self._del_diff(x - y)
                self._del_diff(y - x)
        S.remove(x)

    def add(self, x):
        S = self.S
        for y in S:
            self._add_sum(x + y)
            self._add_diff(x - y)
            self._add_diff(y - x)
        self._add_sum(x + x)
        S.append(x)
        S.sort()

    def shift(self, x, delta):
        self.remove(x)
        self.add(x + delta)


def golomb_marks(k, maxv):
    marks = [0]
    used = {0}
    while len(marks) < k:
        best_c = None
        best_cost = None
        last = marks[-1]
        for c in range(last + 1, maxv + 1):
            cost = 0
            for m in marks:
                if abs(c - m) in used:
                    cost += 1
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best_c = c
                if cost == 0:
                    break
        c = best_c
        used |= {abs(c - m) for m in marks}
        used.add(c)
        marks.append(c)
    return marks


def make_grid(X, M, t):
    Y = list(range(t))
    return [x + M * y for x in X for y in Y]


def search_state(st, deadline, rnd):
    S = st.S
    cur = st.score()
    while time.time() < deadline:
        improved = False

        # shift pass: try moving each element by small deltas
        for i in range(len(S)):
            x = S[i]
            for delta in (1, -1, 2, -2, 3, -3, Mguess[0], -Mguess[0]):
                if x + delta in set(S):
                    continue
                st.shift(x, delta)
                s = st.score()
                if s > cur:
                    cur = s
                    improved = True
                    break
                else:
                    st.shift(x + delta, -delta)
            if improved:
                break
        if improved:
            continue

        # removal pass
        for i in range(len(S)):
            x = S[i]
            if len(S) <= 2:
                break
            st.remove(x)
            s = st.score()
            if s > cur:
                cur = s
                improved = True
                break
            else:
                st.add(x)
        if improved:
            continue

        # add pass: try candidates near existing structure
        lo, hi = S[0], S[-1]
        cands = set()
        for _ in range(40):
            cands.add(rnd.randint(lo - 5, hi + 5))
        for i in range(len(S)):
            for j in range(i + 1, len(S)):
                cands.add((S[i] + S[j]) // 2)
        for c in cands:
            if c in set(S):
                continue
            st.add(c)
            s = st.score()
            if s > cur:
                cur = s
                improved = True
                break
            else:
                st.remove(c)
        if not improved:
            break
    return cur


Mguess = [1]


def solve():
    deadline = time.time() + 108
    rnd = random.Random(2024)
    best = None
    best_score = -1.0

    # build several grid seeds
    seeds = []
    for _ in range(8):
        k = rnd.randint(4, 12)
        t = rnd.randint(2, 5)
        span = 2000
        X = golomb_marks(k, span)
        for M in range(1, 60):
            A = make_grid(X, M, t)
            if len(A) > 200:
                break
            seeds.append(A)

    # score quick, keep the good ones
    scored = []
    for A in seeds:
        A = sorted(set(A))
        if len(A) < 2:
            continue
        s = _score(A)
        scored.append((s, A))
    scored.sort(key=lambda z: -z[0])
    scored = scored[:12]

    for s0, A in scored:
        if time.time() > deadline:
            break
        # infer M guess
        diffs = sorted(set(A))
        Mguess[0] = 1
        st = State(A)
        idx = scored.index((s0, A)) if False else 0
        # choose an M guess from element spacing
        gaps = sorted(set(b - a for a, b in zip(sorted(A), sorted(A)[1:]) if b > a))
        if gaps:
            Mguess[0] = gaps[0]
        t_end = min(deadline, time.time() + 25)
        sc = search_state(st, t_end, rnd)
        S = sorted(set(st.S))
        if sc > best_score:
            best_score = sc
            best = S

    if best is None:
        best = make_grid(golomb_marks(8, 400), 20, 3)

    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    best = [x for x in best if abs(x) <= 10 ** 15]
    return best
# EVOLVE-BLOCK-END


if __name__ == "__main__":
    res = solve()
    print(len(res), _score(res))
