# EVOLVE-BLOCK-START
"""Systematic scan over unions of translated short APs (small sum set, rich differences)."""
import math
import numpy as np
import time


def _score_np(a):
    a = np.asarray(sorted(set(int(x) for x in a)), dtype=np.int64)
    n = a.size
    if n < 2:
        return 0.0, 0, 0
    d = (a[:, None] - a[None, :]).ravel()
    s = (a[:, None] + a[None, :]).ravel()
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def solve():
    deadline = time.time() + 108
    best = None
    best_score = -1.0

    # Family: A = union_{i=0..k-1} { base_i + j*d : j=0..L-1 }
    # base_i ourselves are an AP with step P (small sum set of bases),
    # but we vary P and also allow a second-level jitter.
    configs = []
    for k in range(2, 40):
        for L in range(1, 8):
            for P in range(1, 6):
                for d in (1, 2, 3, 4, 5):
                    if k * L <= 4000:
                        configs.append((k, L, P, d))

    for (k, L, P, d) in configs:
        if time.time() > deadline:
            break
        A = []
        for i in range(k):
            base = i * P * (L * d + 1)
            for j in range(L):
                A.append(base + j * d)
        sc, _, _ = _score_np(A)
        if sc > best_score:
            best_score = sc
            best = A[:]

    best = sorted(set(best))

    # Light local polish: perturb single elements, keep improvements.
    if best is None:
        best = [0, 1, 2, 3]
    cur = best[:]
    cur_score, _, _ = _score_np(cur)

    radii = [1, 2, 3, 5]
    it = 0
    while time.time() < deadline and it < 200000:
        it += 1
        cand = cur[:]
        r = radii[it % len(radii)]
        op = (it // len(radii)) % 3
        if op == 0 and cand:
            i = int(np.random.randint(len(cand)))
            cand[i] += int(np.random.randint(-r, r + 1))
        elif op == 1 and cand:
            i = int(np.random.randint(len(cand)))
            if len(cand) > 4:
                cand.pop(i)
        elif len(cand) < 4000:
            cand.append(int(np.random.randint(-3000, 3001)))
        cand = sorted(set(int(x) for x in cand))
        sc, _, _ = _score_np(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand[:], sc

    return sorted(set(int(x) for x in best))
# EVOLVE-BLOCK-END

