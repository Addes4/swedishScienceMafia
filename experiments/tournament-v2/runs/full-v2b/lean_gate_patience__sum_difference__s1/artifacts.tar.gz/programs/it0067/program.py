# EVOLVE-BLOCK-START
"""Direct simulated-annealing search for sets maximising log|A-A|/log|A+A|.

Analysis: for a set A of size n, |A-A| can approach n^2 while the ratio is
capped near 2 - log n / log|A+A| (Ruzsa).  This favours sets of moderate size
whose sumset has ~n^1.5 distinct values while the difference set stays close
to n^2.  Such sets are hard to build explicitly, so we run a numpy-vectorised
simulated annealer that moves single elements and occasionally adds/removes
points, keeping a global best, sweeping over several sizes and spread values.
"""
import math
import time
import numpy as np


def _score(a):
    n = len(a)
    if n < 2:
        return -1.0, 1, 1
    a = np.asarray(a, dtype=np.int64)
    sums = np.unique((a[:, None] + a[None, :]).ravel())
    diffs = np.unique((a[:, None] - a[None, :]).ravel())
    ns = int(sums.size)
    nd = int(diffs.size)
    if ns < 2:
        return -1.0, nd, ns
    return math.log(nd) / math.log(ns), nd, ns


def _polish(a, deadline, rng, rmax):
    """Greedy single-element polish until no improving move (bounded time)."""
    a = np.unique(np.asarray(a, dtype=np.int64))
    cur, _, _ = _score(a)
    while True:
        if time.time() > deadline:
            break
        improved = False
        order = rng.permutation(len(a))
        for i in order:
            if time.time() > deadline:
                break
            base = int(a[i])
            best_v, best_s = base, cur
            for v in (base + 1, base - 1, base + 2, base - 2):
                if v < 0 or v > rmax:
                    continue
                b = a.copy()
                b[i] = v
                b = np.unique(b)
                if b.size < 2:
                    continue
                s, _, _ = _score(b)
                if s > best_s + 1e-12:
                    best_s, best_v = s, v
            if best_v != base:
                b = a.copy()
                b[i] = best_v
                a = np.unique(b)
                cur = best_s
                improved = True
        if not improved:
            break
    return a, cur


def solve():
    t_end = time.time() + 117.0
    rng = np.random.default_rng(0xC0FFEE)

    best = None
    best_sc = -1.0

    def consider(arr):
        nonlocal best, best_sc
        arr = np.unique(np.asarray(arr, dtype=np.int64))
        if arr.size < 2:
            return
        s, _, _ = _score(arr)
        if s > best_sc:
            best_sc = s
            best = arr.copy()

    # ---- crafted seeds -------------------------------------------------
    # long AP
    consider(np.arange(0, 40, dtype=np.int64))
    # two-interval family
    for L, Q in ((3, 9), (4, 16), (5, 30), (6, 60), (8, 120)):
        consider(np.concatenate([np.arange(L), Q + np.arange(L)]))
    # Golomb-ish ruler (greedy) -- large difference set
    def golomb(k):
        marks = [0]
        used = set([0])
        for _ in range(k - 1):
            c = marks[-1] + 1
            while True:
                ok = True
                newd = set()
                for m in marks:
                    d = c - m
                    if d in used or d in newd:
                        ok = False
                        break
                    newd.add(d)
                if ok:
                    used |= newd
                    marks.append(c)
                    break
                c += 1
        return np.array(marks, dtype=np.int64)
    consider(golomb(18))
    # geometric
    consider(np.array([1 << i for i in range(14)], dtype=np.int64))

    sizes = [16, 20, 25, 32, 40, 50, 64, 80, 100, 128, 160]

    # ---- seed sweep ----------------------------------------------------
    for n in sizes:
        if time.time() > t_end:
            break
        rmax = int(4 * n * n)
        for _ in range(2):
            R = max(n + 1, int(n ** 1.5))
            R = min(R, rmax)
            a = np.sort(rng.choice(R, size=n, replace=False)).astype(np.int64)
            consider(a)

    # ---- simulated annealing restarts ---------------------------------
    n_list = sizes[:]
    idx = 0
    while time.time() < t_end:
        n = n_list[idx % len(n_list)]
        idx += 1
        rmax = int(4 * n * n)

        if best is not None and len(best) == n and rng.random() < 0.5:
            a = best.copy()
        else:
            R = max(n + 1, min(int(n ** 1.5), rmax))
            a = np.sort(rng.choice(R, size=n, replace=False)).astype(np.int64)

        cur, _, _ = _score(a)
        local_best = a.copy()
        local_best_sc = cur
        T = 0.30
        b_step = max(1, n // 4)
        it = 0
        while time.time() < t_end:
            it += 1
            if (it & 255) == 0 and time.time() > t_end:
                break
            m = len(a)
            r = rng.random()
            if r < 0.90:
                # move a single element
                i = int(rng.integers(m))
                if rng.random() < 0.5:
                    v = int(a[i]) + int(rng.integers(-b_step, b_step + 1))
                else:
                    v = int(rng.integers(0, rmax + 1))
                if v < 0:
                    v = 0
                if v > rmax:
                    v = rmax
                if v == int(a[i]):
                    continue
                b = a.copy()
                b[i] = v
                b = np.unique(b)
            elif r < 0.96:
                # add a point
                if m >= 4000:
                    continue
                v = int(rng.integers(0, rmax + 1))
                b = np.unique(np.append(a, v))
            else:
                # remove a point
                if m <= 4:
                    continue
                i = int(rng.integers(m))
                b = np.delete(a, i)

            if b.size < 2:
                continue
            s, _, _ = _score(b)
            if s > cur or rng.random() < math.exp((s - cur) / max(T, 1e-9)):
                a = b
                cur = s
                if s > local_best_sc:
                    local_best_sc = s
                    local_best = b.copy()
                    if s > best_sc:
                        best_sc = s
                        best = b.copy()

            T *= 0.99985
            if T < 1e-4:
                T = 0.15  # reheat

        # polish the local best a little
        if time.time() < t_end - 1.0:
            pb, psc = _polish(local_best, time.time() + 1.0, rng, rmax)
            if psc > best_sc:
                best_sc = psc
                best = pb.copy()

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)

    best = np.unique(best.astype(np.int64))
    if best.size > 4000:
        best = best[:4000]
    lo = -10 ** 15
    hi = 10 ** 15
    out = [int(max(lo, min(hi, int(x)))) for x in best]
    return out
# EVOLVE-BLOCK-END
