# EVOLVE-BLOCK-START
"""Constructive multi-cluster AP builder + greedy/banded polish.

Idea: build A as the union of g translated copies of a short arithmetic
progression {0, d, 2d, ..., (L-1)d} where the cluster offsets t_i are chosen
so their pairwise differences are distinct-ish (Golomb-ruler like).  Then:

  * intra-cluster sums are all of the form 2*t_i + k*d, heavily overlapping,
    so |A+A| grows roughly like (number of distinct 2*t_i+... values);
  * cross-cluster differences t_i - t_j (i != j) plus the AP span d*(L-1) fill
    a wide range, so |A-A| is large.

We then polish with a fast greedy move set that adds / removes / shifts a
single element and keeps changes that improve log|A-A|/log|A+A|, plus the
size bonus.  The final answer is the best found over several configurations.
"""
import math
import time


def _score_parts(a):
    a = set(a)
    n = len(a)
    if n < 2:
        return 0.0, 0, 0
    diffs = set()
    for x in a:
        for y in a:
            diffs.add(x - y)
    sums = set()
    for x in a:
        for y in a:
            sums.add(x + y)
    nd, ns = len(diffs), len(sums)
    if ns < 2:
        return 0.0, nd, ns
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100, nd, ns


def _score(a):
    return _score_parts(a)[0]


def _golomb_offsets(g, spacing):
    """Cheap greedy Golomb-ruler-ish offsets: as many distinct pairwise
    differences as we can get while the offsets stay small."""
    offs = [0]
    used = set()
    while len(offs) < g:
        # try candidates in increasing size, pick first whose new differences
        # are all fresh
        c = offs[-1] + spacing
        while True:
            ds = {c - o for o in offs}
            ds |= {o - c for o in offs}
            if not (ds & used):
                break
            c += 1
        for o in offs:
            used.add(c - o)
            used.add(o - c)
        offs.append(c)
    return offs


def _build(L, d, offsets):
    """Union of translated APs {t + k*d : k=0..L-1}."""
    a = set()
    for t in offsets:
        for k in range(L):
            a.add(t + k * d)
    return sorted(a)


def _polish(a, deadline, max_shift):
    """Greedy add/remove/shift polish with occasional restart from best."""
    a = set(a)
    best = set(a)
    sc, _, _ = _score_parts(best)
    cur = set(a)
    csc = sc
    step = 0
    while True:
        if (step & 15) == 0 and time.time() > deadline:
            break
        step += 1
        improved = False
        elems = list(cur)

        # try shifting one element to nearby empty spots
        for x in elems[:]:
            for dx in range(-max_shift, max_shift + 1):
                if dx == 0:
                    continue
                nx = x + dx
                if nx in cur:
                    continue
                cand = set(cur)
                cand.discard(x)
                cand.add(nx)
                s, _, _ = _score_parts(cand)
                if s >= csc:
                    cur = cand
                    csc = s
                    improved = True
                    if s > sc:
                        best, sc = set(cand), s
                    break
            if improved:
                break

        if not improved:
            # try adding a new element
            for dx in range(1, max_shift + 1):
                for base in elems[:12]:
                    for nx in (base - dx, base + dx):
                        if nx in cur:
                            continue
                        cand = set(cur)
                        cand.add(nx)
                        s, _, _ = _score_parts(cand)
                        if s > csc:
                            cur = cand
                            csc = s
                            improved = True
                            if s > sc:
                                best, sc = set(cand), s
                            break
                    if improved:
                        break
                if improved:
                    break

        if not improved and len(cur) > 2:
            # try removing an element
            for x in elems[:]:
                cand = set(cur)
                cand.discard(x)
                s, _, _ = _score_parts(cand)
                if s > csc:
                    cur = cand
                    csc = s
                    improved = True
                    if s > sc:
                        best, sc = set(cand), s
                    break

        if not improved:
            # restart from best with a small perturbation
            cur = set(best)
            csc = sc
            if len(cur) > 1:
                x = max(cur) if (step % 2 == 0) else min(cur)
                cur.discard(x)
                cur.add(x + (1 if step % 2 == 0 else -1))
                csc = _score(cur)

    return sorted(best), sc


def solve():
    """Return A as a list of distinct integers maximising
    log|A-A| / log|A+A| (plus a small size bonus)."""
    t_end = time.time() + 115.0
    best = None
    best_sc = -1.0

    configs = []
    # sweep AP length / step / number of clusters / offset spacing
    for L in (5, 6, 8, 10, 12, 16):
        for d in (1, 2, 3, 5, 8):
            for g in (4, 6, 8, 10, 12, 16, 20):
                for spacing in (2 * L * d + d, 4 * L * d, 8 * L * d):
                    configs.append((L, d, g, spacing))

    # order configs roughly by expected promise (fewer sums per size)
    configs.sort(key=lambda c: (c[2], c[0]))

    idx = 0
    while time.time() < t_end and idx < len(configs):
        L, d, g, spacing = configs[idx]
        idx += 1
        offs = _golomb_offsets(g, spacing)
        a = _build(L, d, offs)
        # normalize so min is 0
        m = min(a)
        a = [x - m for x in a]
        if len(a) < 2:
            continue
        s0, nd, ns = _score_parts(a)
        # quick polish budget per config, scaled by remaining time
        rem = t_end - time.time()
        this_deadline = time.time() + max(0.4, rem * 0.12)
        cand, sc = _polish(a, this_deadline, max(4, d * L))
        if sc > best_sc:
            best_sc = sc
            best = cand

        # also try a Golomb offset run with tighter/looser spacing
        if time.time() > t_end:
            break

    if best is None:
        best = [0, 1, 3, 7, 12, 20]

    # final safety normalisation and validity
    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    best = [max(-10**15, min(10**15, x)) for x in best]
    return best
# EVOLVE-BLOCK-END
