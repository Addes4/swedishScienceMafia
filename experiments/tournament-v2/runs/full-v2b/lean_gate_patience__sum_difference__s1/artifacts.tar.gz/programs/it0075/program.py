# EVOLVE-BLOCK-START
"""Two-interval family A = {0..L-1} ∪ (Q + {0..L-1}), exact numpy scoring.

For this family the sum set is essentially an arithmetic progression with a few
extra gaps, while the difference set spreads over a wide range, giving a large
log|A-A|/log|A+A|. We sweep (L, Q) on a grid, then refine locally.
"""
import math
import time
import numpy as np


def _score_np(A):
    a = np.array(sorted(set(A)), dtype=np.int64)
    n = len(a)
    if n < 2:
        return 0.0
    diffs = a[:, None] - a[None, :]
    sums = a[:, None] + a[None, :]
    nd = len(np.unique(diffs))
    ns = len(np.unique(sums))
    if ns < 2 or nd < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _two_interval(L, Q):
    a = list(range(0, L))
    a += [Q + k for k in range(L)]
    return sorted(set(a))


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Coarse grid over L and Q. Q is the gap; interesting when Q ~ L^2 or so.
    Ls = list(range(2, 60))
    for L in Ls:
        if time.time() > deadline - 30:
            break
        # Q ranges roughly from L to L*L (to spread cross differences)
        maxQ = max(L * L + L, 200)
        for Q in range(L, maxQ + 1, max(1, L // 2)):
            cand = _two_interval(L, Q)
            s = _score_np(cand)
            if s > best_score:
                best_score = s
                best = cand[:]

    # Also try a few larger L values coarsely.
    for L in (64, 80, 100, 128, 160, 200, 256):
        if time.time() > deadline - 30:
            break
        maxQ = max(L * L // 2 + L, 1000)
        for Q in range(L, maxQ + 1, max(1, L)):
            cand = _two_interval(L, Q)
            s = _score_np(cand)
            if s > best_score:
                best_score = s
                best = cand[:]

    if best is None:
        best = _two_interval(3, 10)

    # Local refinement on (L, Q).
    def refine(L, Q, deadline):
        nonlocal best, best_score
        cur_s = best_score
        improved = True
        while improved and time.time() < deadline:
            improved = False
            # try perturbing L and Q
            for dL in (-2, -1, 1, 2):
                cand = _two_interval(L + dL, Q)
                s = _score_np(cand)
                if s > cur_s:
                    cur_s = s
                    L = L + dL
                    best = cand
                    best_score = s
                    improved = True
            for dQ in (-2, -1, 1, 2):
                cand = _two_interval(L, Q + dQ)
                s = _score_np(cand)
                if s > cur_s:
                    cur_s = s
                    Q = Q + dQ
                    best = cand
                    best_score = s
                    improved = True
        return L, Q

    # recover L, Q of best (best is 2L elements, L known from construction)
    L0 = len(best) // 2
    Q0 = max(best) - (L0 - 1)
    if len(best) % 2 != 0:
        L0 = len(best)
        Q0 = 0
    refine(L0, Q0, deadline - 0.5)

    # Final: try removing the far-block far elements and a few odd offsets.
    A = sorted(set(best))
    cur_score = _score_np(A)
    changed = True
    while changed and time.time() < deadline - 0.2:
        changed = False
        for i in range(len(A)):
            if len(A) <= 3:
                break
            cand = A[:i] + A[i + 1:]
            s = _score_np(cand)
            if s >= cur_score:
                A = cand
                cur_score = s
                changed = True
                break

    return sorted(set(A))
# EVOLVE-BLOCK-END
