# EVOLVE-BLOCK-START
"""Grid construction A = X + M*Y with fast set-based scorer and local search."""
import math
import random
import time
import numpy as np


def _score_from_sets(diffs, sums, n):
    nd = diffs.size
    ns = sums.size
    if ns < 2 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _score_np(arr):
    n = arr.size
    if n < 2:
        return 0.0
    d = np.subtract.outer(arr, arr).ravel()
    s = np.add.outer(arr, arr).ravel()
    nd = np.unique(d).size
    ns = np.unique(s).size
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _golomb(n, span):
    """Greedy Golomb ruler with n marks within span (may return fewer)."""
    marks = [0]
    used = {0}
    cand = 1
    while len(marks) < n and cand <= span:
        ok = True
        for m in marks:
            if abs(cand - m) in used:
                ok = False
                break
        if ok:
            for m in marks:
                used.add(abs(cand - m))
            marks.append(cand)
        cand += 1
    return marks


def _make_grid(X, Y, M):
    a = np.array([x + M * y for y in Y for x in X], dtype=np.int64)
    return np.unique(a)


def solve():
    deadline = time.time() + 100
    best = None
    best_score = -1.0

    # Cache Golomb rulers.
    gol_cache = {}

    def gol(n, span):
        key = (n, span)
        if key not in gol_cache:
            gol_cache[key] = _golomb(n, span)
        return gol_cache[key]

    # Family 1: A = X + M*Y, X golomb, Y golomb or interval.
    for nX in range(2, 45):
        if time.time() > deadline:
            break
        X = gol(nX, 60 * nX)
        if len(X) < nX:
            continue
        for nY in range(2, 26):
            Yint = list(range(nY))
            Ygol = gol(nY, 40 * nY)
            for Y in (Ygol, Yint):
                if len(Y) < 2:
                    continue
                for M in (60, 120, 300, 700, 1500, 4000, 10000):
                    arr = _make_grid(X, Y, M)
                    sc = _score_np(arr)
                    if sc > best_score:
                        best_score = sc
                        best = arr.copy()
            if time.time() > deadline:
                break

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)
        best_score = _score_np(best)

    # Local search: mutate a few elements, keep improvements.
    cur = best.copy()
    cur_score = best_score
    it = 0
    maxmag = int(np.max(np.abs(cur))) + 50
    while time.time() < deadline and it < 6000:
        it += 1
        cand = cur.copy()
        k = random.randint(1, max(1, len(cand) // 15))
        idx = np.random.randint(0, len(cand), size=k)
        cand[idx] += np.random.randint(-5, 6, size=k).astype(np.int64)
        cand = np.unique(cand)
        if cand.size < 2:
            continue
        sc = _score_np(cand)
        if sc >= cur_score:
            cur, cur_score = cand, sc
            if sc > best_score:
                best, best_score = cand.copy(), sc
        # also attempt scaling moves occasionally
        if it % 200 == 0:
            cand = (cur * random.choice((-1, 2, 3))).astype(np.int64)
            cand = np.unique(np.abs(cand))
            if cand.size >= 2:
                sc = _score_np(cand)
                if sc > best_score:
                    best, best_score = cand.copy(), sc

    return sorted(int(v) for v in np.unique(best))
# EVOLVE-BLOCK-END
