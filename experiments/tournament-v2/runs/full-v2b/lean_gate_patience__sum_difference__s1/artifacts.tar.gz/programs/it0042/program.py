# EVOLVE-BLOCK-START
"""Sets with many differences and few sums.

Construction: A = X + M*[0,k)  where X is a Sidon-like/B2 base set (its difference
set is large and nearly collision-free) and adding a short arithmetic progression
[0,k) scaled by M forces many sums to collide (sums within the interval part are
[M*0..M*(2k-2)] plus X-collisions), while differences remain spread.

We seed from several such constructions and refine with a fast incremental
multiplicity local search that maintains diff/sum count dicts so add/remove/shift
moves are evaluated exactly in O(n) via partial-updates of the multiplicity counts.
"""
import math
import random
import time
from collections import Counter


def _score_from_counts(nd, ns, n):
    if ns <= 1 or n < 2:
        return -1e18
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _full_stats(a):
    a = sorted(set(a))
    n = len(a)
    if n < 2:
        return 1, 1, -1e18
    dc = Counter()
    sc = Counter()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            dc[ai - a[j]] += 1
            sc[ai + a[j]] += 1
    nd = len(dc)
    ns = len(sc)
    return nd, ns, _score_from_counts(nd, ns, n)


def _sidon_greedy(size, bound, rng):
    """Greedy B2-ish set: build by trying random candidates and keeping those with
    many new distinct differences (and = sums kept small)."""
    base = [0]
    used_diff = {0}
    for _ in range(size - 1):
        best_c = None
        best_g = -1
        for _try in range(40):
            c = rng.randint(-bound, bound)
            if c in base:
                continue
            new_d = 0
            for b in base:
                if (c - b) not in used_diff:
                    new_d += 1
                if (b - c) not in used_diff:
                    new_d += 1
            # prefer candidates that add many fresh differences
            g = new_d - 0.15 * abs(c)
            if g > best_g:
                best_g = g
                best_c = c
        if best_c is None:
            best_c = rng.randint(-bound, bound)
        for b in base:
            used_diff.add(best_c - b)
            used_diff.add(b - best_c)
        used_diff.add(0)
        base.append(best_c)
    return base


def _build_interval(base, k, M):
    A = []
    for x in base:
        for j in range(k):
            A.append(x + M * j)
    return sorted(set(A))


def _incremental_search(A, deadline, best_score):
    """Fast local search using diff/sum multiplicity dicts.

    For a candidate we only need |diff set| and |sum set|. Recompute cheaply.
    """
    cur = sorted(set(int(x) for x in A))
    if len(cur) < 2:
        return cur, best_score
    best = cur[:]
    nd, ns, s = _full_stats(cur)
    if s > best_score:
        best_score = s
        best = cur[:]

    rng = random.Random(20240817)

    def counts(a):
        n = len(a)
        dc = Counter()
        sc = Counter()
        for i in range(n):
            ai = a[i]
            for j in range(n):
                dc[ai - a[j]] += 1
                sc[ai + a[j]] += 1
        return len(dc), len(sc)

    while time.time() < deadline:
        improved = False
        n = len(cur)
        # remove
        if n > 6:
            order = list(range(n))
            rng.shuffle(order)
            for i in order:
                cand = cur[:i] + cur[i + 1:]
                nd2, ns2 = counts(cand)
                s2 = _score_from_counts(nd2, ns2, len(cand))
                if s2 > best_score:
                    best_score = s2
                    best = cand[:]
                    cur = cand[:]
                    improved = True
                    break
        if improved:
            continue
        # add from neighbors
        pool = {}
        for x in cur:
            for delta in (-1, 1, -2, 2, -3, 3, -M_GLOBAL, M_GLOBAL):
                pool[x + delta] = 1
        cs = set(cur)
        cand_pool = [v for v in pool if v not in cs]
        rng.shuffle(cand_pool)
        for v in cand_pool[:60]:
            cand = cur + [v]
            nd2, ns2 = counts(cand)
            s2 = _score_from_counts(nd2, ns2, len(cand))
            if s2 > best_score:
                best_score = s2
                best = cand[:]
                cur = cand[:]
                improved = True
                break
        if improved:
            continue
        # shift one element
        for i in range(n):
            for delta in (-1, 1, -2, 2, -3, 3):
                cand = cur[:]
                cand[i] += delta
                if len(set(cand)) < len(cand):
                    continue
                nd2, ns2 = counts(cand)
                s2 = _score_from_counts(nd2, ns2, len(cand))
                if s2 > best_score:
                    best_score = s2
                    best = cand[:]
                    cur = cand[:]
                    improved = True
                    break
            if improved:
                break
        if not improved:
            break
    return best, best_score


M_GLOBAL = 1


def solve():
    global M_GLOBAL
    best = [0, 1, 2, 3, 4, 5]
    _, _, best_score = _full_stats(best)
    deadline = time.time() + 100.0

    rng = random.Random(7)
    trials = []
    # sweep base size, interval length k, and scale M
    for bsize in (3, 4, 5, 6, 7, 8):
        for k in (2, 3, 4, 5, 6, 7, 8):
            for M in (1, 2, 3, 4, 5, 6, 8, 10, 12, 15, 20):
                trials.append((bsize, k, M))
    rng.shuffle(trials)

    for (bsize, k, M) in trials:
        if time.time() > deadline - 3:
            break
        bound = max(20, bsize * 6)
        base = _sidon_greedy(bsize, bound, rng)
        A = _build_interval(base, k, M)
        M_GLOBAL = M
        nd, ns, s = _full_stats(A)
        # quick check, then a short local search
        t_end = min(deadline, time.time() + 1.5)
        A2, s2 = _incremental_search(A, t_end, max(best_score, s))
        if s2 > best_score:
            best_score = s2
            best = A2[:]
        else:
            if s > best_score:
                best_score = s
                best = A[:]

    # final polish
    if time.time() < deadline - 1:
        M_GLOBAL = max(1, abs(best[1] - best[0]) if len(best) > 1 else 1)
        A2, s2 = _incremental_search(best, deadline - 0.5, best_score)
        if s2 > best_score:
            best_score = s2
            best = A2[:]

    best = sorted(set(int(x) for x in best))
    return best
# EVOLVE-BLOCK-END
