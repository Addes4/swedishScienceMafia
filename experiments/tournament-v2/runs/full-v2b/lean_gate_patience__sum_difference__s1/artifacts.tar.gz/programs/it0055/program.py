# EVOLVE-BLOCK-START
"""
Two-block / base+interval constructive builder with exact scoring.

Families explored:
  F1: A = {0,1,...,L-1} ∪ (q + {0,1,...,L-1})   -- two translates of an AP.
      Sums of two intervals: {0..2L-2} ∪ (q+{0..2L-2}) ∪ (2q+{0..2L-2})
      => concentrated. Differences spread over many distinct values.
  F2: A = X ∪ (q + {0,...,M-1}) where X is a small Sidon-like base.
  F3: A = X + {0,...,M-1} for a small base X (interval factor forcing sum
      collisions).

We evaluate each with an exact O(n^2) set-based counter and keep the best.
A short greedy polish with a cached diff/sum set follows if time remains.
"""

import math
import time


def _score_sets(diffs, sums, n):
    nd = len(diffs)
    ns = len(sums)
    if nd < 2 or ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def _exact_score(a):
    s = list(dict.fromkeys(a))
    n = len(s)
    if n < 2:
        return 0.0, set(), set()
    diffs = set()
    sums = set()
    for x in s:
        for y in s:
            diffs.add(x - y)
            sums.add(x + y)
    return _score_sets(diffs, sums, n), diffs, sums


def _two_interval(L, q):
    a = list(range(0, L)) + [q + k for k in range(L)]
    return sorted(set(a))


def _base_plus_interval(base, q, M):
    a = list(base) + [q + k for k in range(M)]
    return sorted(set(a))


def _interval_of_base(base, M):
    a = []
    for x in base:
        for k in range(M):
            a.append(x + k)
    return sorted(set(a))


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # --- Family F1: two intervals ----------------------------------------
    for L in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 32, 40, 50, 64):
        for q in (1, 2, 3, 4, 5, 7, 10, 13, 17, 21, 26, 32, 40, 50):
            if time.time() > deadline * 0.25:
                break
            a = _two_interval(L, q)
            if len(a) < 2 or len(a) > 4000:
                continue
            sc, _, _ = _exact_score(a)
            if sc > best_score:
                best_score = sc
                best = a

    # --- Family F2: Sidon-like base ∪ interval ---------------------------
    # small base with all distinct differences (a Sidon-ish set)
    bases = [
        [0, 1],
        [0, 1, 3],
        [0, 1, 3, 7],
        [0, 1, 4, 9, 15],
        [0, 1, 3, 7, 12, 20],
        [0, 1, 4, 10, 18, 23, 31],
        [0, 1, 3, 8, 12, 22, 28, 36],
        [0, 1, 5, 11, 19, 24, 33, 41, 52],
    ]
    for base in bases:
        bspan = base[-1] + 1
        for q in (bspan, bspan + 1, bspan + 2, 2 * bspan, 3 * bspan):
            for M in (4, 6, 8, 12, 16, 24, 32, 48, 64, 96):
                if time.time() > deadline * 0.6:
                    break
                a = _base_plus_interval(base, q, M)
                if len(a) < 2 or len(a) > 4000:
                    continue
                sc, _, _ = _exact_score(a)
                if sc > best_score:
                    best_score = sc
                    best = a

    # --- Family F3: interval-of-base -------------------------------------
    for base in bases:
        bspan = base[-1] + 1
        for M in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20):
            if time.time() > deadline * 0.8:
                break
            a = _interval_of_base(base, M)
            if len(a) < 2 or len(a) > 4000:
                continue
            sc, _, _ = _exact_score(a)
            if sc > best_score:
                best_score = sc
                best = a

    if best is None:
        best = [0, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377]

    # --- Short greedy polish: try removals and small shifts --------------
    cur = sorted(set(best))
    sc, diffs, sums = _exact_score(cur)
    best_score = sc
    improved = True
    while improved and time.time() < deadline:
        improved = False
        # removals
        i = 0
        while i < len(cur) and time.time() < deadline:
            if len(cur) <= 2:
                break
            cand = cur[:i] + cur[i + 1:]
            csc, _, _ = _exact_score(cand)
            if csc > best_score + 1e-12:
                cur = cand
                best_score = csc
                improved = True
            else:
                i += 1
        # small shifts
        for i in range(len(cur)):
            if time.time() > deadline:
                break
            orig = cur[i]
            done = False
            for delta in (-2, -1, 1, 2, -3, 3):
                cand = cur[:]
                cand[i] = orig + delta
                cand = sorted(set(cand))
                csc, _, _ = _exact_score(cand)
                if csc > best_score + 1e-12:
                    cur = cand
                    best_score = csc
                    improved = True
                    done = True
                    break
            if done:
                break

    return sorted(set(int(x) for x in cur))
# EVOLVE-BLOCK-END
