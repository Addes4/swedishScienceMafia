# EVOLVE-BLOCK-START
"""Greedy growth maximizing log|A-A|/log|A+A| with numpy exact scoring."""
import math
import random
import time
import numpy as np


def _stats(arr):
    n = arr.size
    if n < 2:
        return 0, 0
    d = np.subtract.outer(arr, arr).ravel()
    s = np.add.outer(arr, arr).ravel()
    return np.unique(d).size, np.unique(s).size


def _score(arr):
    n = arr.size
    if n < 2:
        return 0.0
    nd, ns = _stats(arr)
    if ns < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def solve():
    deadline = time.time() + 110
    rng = random.Random(12345)
    best = None
    best_score = -1.0

    def try_seed(seedvals):
        nonlocal best, best_score
        arr = np.array(sorted(set(seedvals)), dtype=np.int64)
        cur = arr
        cur_score = _score(cur)
        # greedy growth
        while cur.size < 400 and time.time() < deadline:
            base_max = int(np.abs(cur).max())
            span = base_max + 1
            cands = []
            # candidate pool: many random offsets
            for _ in range(200):
                cands.append(rng.randint(-span, 2 * span + 10))
            cands = np.array(sorted(set(cands)), dtype=np.int64)
            bestc = None
            bestc_score = cur_score
            for c in cands:
                if c in cur:
                    continue
                trial = np.union1d(cur, np.array([c], dtype=np.int64))
                sc = _score(trial)
                if sc > bestc_score:
                    bestc_score = sc
                    bestc = trial
            if bestc is None:
                break
            cur = bestc
            cur_score = bestc_score
        if cur_score > best_score:
            best_score = cur_score
            best = cur.copy()
        return cur_score

    # seeds: small APs and random
    for L in range(2, 12):
        for step in (1, 2, 3, 5, 8, 13):
            try_seed(list(range(0, step * L, step)) if step > 1 else list(range(L)))
            if time.time() > deadline:
                break
        if time.time() > deadline:
            break

    for _ in range(30):
        if time.time() > deadline:
            break
        k = rng.randint(4, 12)
        seedvals = sorted({rng.randint(-50, 50) for _ in range(k)})
        try_seed(seedvals)

    if best is None:
        best = np.array([0, 1, 3, 7, 12, 20], dtype=np.int64)
        best_score = _score(best)

    # Local refinement: single-element moves
    cur = best.copy()
    cur_score = best_score
    while time.time() < deadline:
        improved = False
        arr_list = cur.tolist()
        vals_set = set(arr_list)
        span = max(abs(v) for v in arr_list) + 1
        for i in range(len(arr_list)):
            for _ in range(6):
                newv = rng.randint(-2 * span, 3 * span)
                if newv in vals_set and newv != arr_list[i]:
                    continue
                trial_list = arr_list[:i] + [newv] + arr_list[i + 1:]
                trial = np.array(sorted(set(trial_list)), dtype=np.int64)
                if trial.size < 3:
                    continue
                sc = _score(trial)
                if sc > cur_score:
                    cur = trial
                    cur_score = sc
                    arr_list = cur.tolist()
                    vals_set = set(arr_list)
                    improved = True
                    if sc > best_score:
                        best = cur.copy()
                        best_score = sc
                    break
            if improved:
                break
        if not improved:
            break

    return sorted(int(v) for v in np.unique(best))
# EVOLVE-BLOCK-END
