# EVOLVE-BLOCK-START
"""Multi-cluster arithmetic-progression builder + fast incremental local search.

Seed: A = union of g translated arithmetic progressions of length L placed at
Golomb-ruler offsets.  Within a cluster sums/sym-differences collapse to 2L-1
values; cross-cluster terms spread out.  A fast incremental multiplicity scorer
(diff & sum count dictionaries) drives a local search of add/remove/shift moves
that directly maximises log|A-A|/log|A+A| (including the size bonus).
"""
import math
import random
import time


def _stats(a):
    a = list(dict.fromkeys(a))
    n = len(a)
    if n < 2:
        return 1, 1, 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            if j >= i:
                sums.add(ai + a[j])
    nd = len(diffs)
    ns = len(sums)
    if ns < 2 or nd < 2:
        return nd, ns, 0.0
    score = math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0
    return nd, ns, score


def _score_from(nd, ns, n):
    if ns < 2 or nd < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


class Fast:
    """Incremental multiplicity tracker for a set A (list of distinct ints)."""
    __slots__ = ("d", "s", "a", "S")

    def __init__(self, a):
        self.a = list(a)
        self.d = {}
        self.s = {}
        for x in self.a:
            for y in self.a:
                self.d[x - y] = self.d.get(x - y, 0) + 1
        # sums (symmetric; count ordered pairs to make updates uniform)
        for x in self.a:
            for y in self.a:
                self.s[x + y] = self.s.get(x + y, 0) + 1

    def nd(self):
        return len(self.d)

    def ns(self):
        return len(self.s)

    def score(self):
        return _score_from(len(self.d), len(self.s), len(self.a))

    def _add_pair_d(self, x, y):
        k = x - y
        v = self.d.get(k, 0)
        self.d[k] = v + 1
        return v  # was new if v==0

    def _sub_pair_d(self, x, y):
        k = x - y
        self.d[k] -= 1
        if self.d[k] == 0:
            del self.d[k]

    def _add_pair_s(self, x, y):
        k = x + y
        v = self.s.get(k, 0)
        self.s[k] = v + 1

    def _sub_pair_s(self, x, y):
        k = x + y
        self.s[k] -= 1
        if self.s[k] == 0:
            del self.s[k]

    def add(self, x):
        # add element x to A
        for y in self.a:
            self._add_pair_d(x, y)
            self._add_pair_d(y, x)
            self._add_pair_s(x, y)
            self._add_pair_s(y, x)
        self._add_pair_d(x, x)
        self._add_pair_s(x, x)
        self.a.append(x)

    def remove(self, x):
        # remove element x (must be present)
        self.a.remove(x)
        for y in self.a:
            self._sub_pair_d(x, y)
            self._sub_pair_d(y, x)
            self._sub_pair_s(x, y)
            self._sub_pair_s(y, x)
        self._sub_pair_d(x, x)
        self._sub_pair_s(x, x)

    def shift(self, i, dx):
        x = self.a[i]
        nx = x + dx
        if nx in self.a:
            return
        self.remove(x)
        self.add(nx)


def _golomb_offsets(count):
    offs = [0]
    used = {0}
    step = 1
    for _ in range(count - 1):
        cand = offs[-1] + step
        tries = 0
        while tries < 500:
            ok = True
            for o in offs:
                d = cand - o
                if d == 0 or d in used or -d in used:
                    ok = False
                    break
            if ok:
                break
            cand += 1
            tries += 1
        offs.append(cand)
        for o in offs[:-1]:
            used.add(cand - o)
            used.add(o - cand)
        step += 1
    return offs


def _build(clusters, plen):
    offs = _golomb_offsets(clusters)
    A = []
    for o in offs:
        for t in range(plen):
            A.append(o * plen + t)
    return A


def solve():
    start = time.time()
    deadline = start + 110.0
    rng = random.Random(987654321)

    best = None
    best_sc = -1.0

    # Seed with a range of cluster/progression constructions.
    seeds = []
    for clusters in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32, 40, 50, 64, 80):
        for plen in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24):
            if clusters * plen <= 4000:
                seeds.append((clusters, plen))
    seeds.sort(key=lambda cp: abs(cp[0] * cp[1] - 80) + abs(cp[0] - cp[1] * 4))

    for clusters, plen in seeds[:60]:
        A = _build(clusters, plen)
        _, _, sc = _stats(A)
        if sc > best_sc:
            best_sc = sc
            best = list(A)
        if time.time() > deadline - 90:
            break

    if best is None:
        best = [0, 1, 2, 4, 8]
        best_sc = _stats(best)[2]

    # Fast incremental local search.
    cur = Fast(best)
    bestA = list(cur.a)
    bestSc = cur.score()

    while time.time() < deadline:
        nd0, ns0 = cur.nd(), cur.ns()
        sc0 = cur.score()
        n0 = len(cur.a)
        mode = rng.random()
        if mode < 0.5 and n0 < 4000:
            # add an element near an existing one
            anchor = rng.choice(cur.a)
            x = anchor + rng.choice([-3, -2, -1, 1, 2, 3, 4, 8])
            if x in cur.a:
                continue
            cur.add(x)
            sc = cur.score()
            if sc > sc0 + 1e-12 or (abs(sc - sc0) < 1e-12):
                if sc > bestSc:
                    bestSc = sc
                    bestA = list(cur.a)
            else:
                cur.remove(x)
        elif mode < 0.85:
            # shift an element
            i = rng.randrange(n0)
            dx = rng.choice([-3, -2, -1, 1, 2, 3, 5, 8, -5, -8])
            x = cur.a[i]
            nx = x + dx
            if nx in cur.a:
                continue
            cur.remove(x)
            cur.add(nx)
            sc = cur.score()
            if sc > sc0 + 1e-12 or (abs(sc - sc0) < 1e-12):
                if sc > bestSc:
                    bestSc = sc
                    bestA = list(cur.a)
            else:
                cur.remove(nx)
                cur.add(x)
        else:
            # remove an element
            if n0 <= 6:
                continue
            i = rng.randrange(n0)
            x = cur.a[i]
            cur.remove(x)
            sc = cur.score()
            if sc > sc0 + 1e-12:
                if sc > bestSc:
                    bestSc = sc
                    bestA = list(cur.a)
            else:
                cur.add(x)

        # occasional restart from best
        if rng.random() < 0.0008:
            cur = Fast(bestA)

    A = sorted(set(int(x) for x in bestA))
    if len(A) > 4000:
        A = A[:4000]
    return A
# EVOLVE-BLOCK-END

