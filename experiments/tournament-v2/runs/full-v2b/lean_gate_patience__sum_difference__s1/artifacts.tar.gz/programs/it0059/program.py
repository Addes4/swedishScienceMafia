# EVOLVE-BLOCK-START
"""Sweep two-cluster AP family + numpy exact scoring + hill climb."""
import math
import time
import numpy as np


def _score(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0.0
    sums = np.add.outer(a, a).ravel()
    sums = np.unique(sums)
    diffs = np.subtract.outer(a, a).ravel()
    diffs = np.unique(diffs)
    if sums.size == 0 or diffs.size == 0:
        return 0.0
    return math.log(diffs.size) / math.log(sums.size) + (1 - 1 / n) / 100


def _score_parts(a):
    a = np.unique(np.asarray(a, dtype=np.int64))
    n = a.size
    if n < 2:
        return 0.0
    sums = np.unique(np.add.outer(a, a).ravel())
    diffs = np.unique(np.subtract.outer(a, a).ravel())
    if sums.size == 0 or diffs.size == 0:
        return 0.0
    return math.log(diffs.size) / math.log(sums.size) + (1 - 1 / n) / 100


def _two_cluster(L, Q):
    left = np.arange(L, dtype=np.int64)
    right = Q + np.arange(L, dtype=np.int64)
    return np.concatenate([left, right])


def solve():
    deadline = time.time() + 110
    best = None
    best_score = -1.0

    # Fine sweep over two-cluster AP family A = {0..L-1} U (Q+{0..L-1}).
    # Try to make sums collide while differences spread.
    Ls = list(range(2, 60)) + list(range(60, 320, 4)) + list(range(320, 1500, 40))
    for L in Ls:
        if time.time() > deadline - 60:
            break
        # For fixed L, larger Q spreads differences (good) but too large Q
        # increases distinct sums. Sweep Q around a few multiples of L.
        Qs = []
        for mult in (1, 2, 3, 4, 6, 8, 12, 16, 24, 32):
            Qs.append(mult * L)
        for extra in (L // 2, L - 1):
            for mult in (1, 2, 3, 4, 6, 8, 12, 16):
                Qs.append(mult * L + extra)
        Qs = sorted(set(q for q in Qs if q >= 1))
        for Q in Qs:
            a = _two_cluster(L, Q)
            s = _score_parts(a)
            if s > best_score:
                best_score = s
                best = a

    if best is None:
        best = _two_cluster(20, 60)
        best_score = _score_parts(best)

    # Hill climb: relocate / add / remove elements with numpy scoring.
    best = list(int(x) for x in best)
    best_score = _score(best)
    span = max(best) - min(best)
    step = max(1, span // max(1, len(best)))

    improved = True
    while improved and time.time() < deadline:
        improved = False
        n = len(best)
        # try relocating single elements
        for i in range(n):
            orig = best[i]
            base = orig
            for delta in (step, -step, 2 * step, -2 * step, 1, -1):
                cand = best[:]
                cand[i] = base + delta
                if len(set(cand)) != len(cand):
                    continue
                s = _score(cand)
                if s > best_score:
                    best_score = s
                    best = cand
                    improved = True
                    break
            if improved:
                break
        if improved:
            continue
        # try removing
        if n > 12:
            for i in range(n):
                cand = best[:i] + best[i + 1:]
                s = _score(cand)
                if s > best_score:
                    best_score = s
                    best = cand
                    improved = True
                    break
        if improved:
            continue
        # try adding near existing points
        lo, hi = min(best), max(best)
        for _ in range(40):
            v = lo + int(np.random.randint(0, hi - lo + 1))
            if v in best:
                continue
            cand = best + [v]
            s = _score(cand)
            if s > best_score:
                best_score = s
                best = cand
                improved = True
                break

    return sorted(set(int(x) for x in best))


if __name__ == "__main__":
    a = solve()
    a = list(set(a))
    if len(a) > 4000:
        a = a[:4000]
    print(len(a), _score(a))
# EVOLVE-BLOCK-END
