# EVOLVE-BLOCK-START
"""Parametric grid family: A = { x + M*y : x in X (Golomb, diff-rich), y in Y (interval) }.
Sweep M (coprime base) and shapes (|X|, |Y|), keep the family maximizing the ratio."""
import math
import time


def _diffs_sums_count(L):
    n = len(L)
    diffs = set()
    sums = set()
    for i in range(n):
        xi = L[i]
        for j in range(i, n):
            sums.add(xi + L[j])
            if i != j:
                diffs.add(xi - L[j])
                diffs.add(L[j] - xi)
    return len(diffs), len(sums)


def _score_counts(nd, ns, n):
    if ns < 1 or n < 2:
        return 0.0
    return math.log(nd) / math.log(ns) + (1 - 1 / n) / 100


def golomb_marks(k, maxv):
    marks = [0]
    used = {0}
    while len(marks) < k:
        best_c = None
        best_cost = None
        for c in range(marks[-1] + 1, maxv + 1):
            cost = 0
            for m in marks:
                if abs(c - m) in used:
                    cost += 1
            if best_cost is None or cost < best_cost:
                best_cost = cost
                best_c = c
                if cost == 0:
                    break
        c = best_c
        newd = {abs(c - m) for m in marks}
        used |= newd
        used.add(c)
        marks.append(c)
        if len(marks) > 2 and marks[-1] > maxv:
            break
    return marks


def _eval_grid(X, M, Y):
    A = [x + M * y for x in X for y in Y]
    A = sorted(set(A))
    nd, ns = _diffs_sums_count(A)
    return _score_counts(nd, ns, len(A)), A


def solve():
    deadline = time.time() + 110
    best_score, best_A = -1.0, None

    # Sweep grid shapes (|X|, |Y|) x coprime bases M.
    # X is a Golomb ruler; Y is a full interval 0..|Y|-1.
    shapes = []
    for nx in (6, 8, 10, 14, 18, 24, 30, 40, 55, 70):
        for ny in (2, 3, 4, 5, 6, 8):
            if nx * ny <= 4000:
                shapes.append((nx, ny))

    Ms = [1]
    for M in range(2, 60):
        Ms.append(M)
    for M in (100, 137, 199, 256, 331, 512, 700, 1000, 1500, 2000, 3000):
        Ms.append(M)

    # Precompute Golomb rulers for the needed sizes.
    marks_cache = {}
    for nx in set(s[0] for s in shapes):
        marks_cache[nx] = golomb_marks(nx, nx * nx * 2 + 200)

    for (nx, ny) in shapes:
        if time.time() > deadline:
            break
        X = marks_cache[nx]
        Y = list(range(ny))
        # scale X so it fits comfortably, then sweep M
        base_span = max(X)
        for M in Ms:
            if time.time() > deadline:
                break
            # ensure X and M*Y ranges don't overlap too badly: X small, M large enough
            scale = max(1, (M * ny) // (base_span + 1) if base_span > 0 else 1)
            s, A = _eval_grid([x * scale for x in X], M, Y)
            if s > best_score:
                best_score = s
                best_A = A

    if best_A is None:
        best_A = [7, 15, 18, 22, -3, -2]

    best_A = sorted(set(int(x) for x in best_A))
    if len(best_A) > 4000:
        best_A = best_A[:4000]
    best_A = [x for x in best_A if abs(x) <= 10 ** 15]
    return best_A
# EVOLVE-BLOCK-END

if __name__ == "__main__":
    res = solve()
    print(len(res), _diffs_sums_count(res))
