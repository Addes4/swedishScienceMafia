# EVOLVE-BLOCK-START
"""Constructive multi-cluster builder + fast incremental local search.

A = union of g translated copies of an arithmetic progression of length L put at
Golomb-ruler-style offsets.  Within-cluster sums collide (few sums) while
cross-cluster differences fill a wide range (many differences).  Then a fast
incremental local search maintains exact difference/sum multiplicities and
accepts add/remove/shift moves that improve log|A-A|/log|A+A|.
"""
import math
import random
import time
from collections import defaultdict


def _stats(a):
    a = list(dict.fromkeys(a))
    n = len(a)
    if n < 2:
        return 1, 1, 0.0
    diffs = set()
    sums = set()
    for i in range(n):
        ai = a[i]
        for j in range(n):
            diffs.add(ai - a[j])
            if j >= i:
                sums.add(ai + a[j])
    nd = len(diffs)
    ns = len(sums)
    if ns < 2 or nd < 2:
        return nd, ns, 0.0
    score = math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0
    return nd, ns, score


def _golomb_offsets(count, spacing=1):
    offs = [0]
    used = {0}
    step = 1
    for _ in range(count - 1):
        cand = offs[-1] + step * spacing
        while True:
            ok = True
            for o in offs:
                d = cand - o
                if d == 0 or d in used or -d in used:
                    ok = False
                    break
            if ok:
                break
            cand += 1
        offs.append(cand)
        for o in offs[:-1]:
            used.add(offs[-1] - o)
            used.add(o - offs[-1])
        step += 1
    return offs


def _build(clusters, plen, spacing, base=None):
    offs = _golomb_offsets(clusters, spacing)
    if base is None:
        base = max(offs) + plen * spacing + 1
    A = []
    for o in offs:
        start = base + o
        for t in range(plen):
            A.append(start + t)
    return A


def _score_from(a, nd, ns):
    n = len(a)
    if ns < 2 or nd < 2 or n < 2:
        return -1.0
    return math.log(nd) / math.log(ns) + (1.0 - 1.0 / n) / 100.0


def _make_state(a):
    a = sorted(set(a))
    nd = defaultdict(int)
    ns = defaultdict(int)
    n = len(a)
    for i in range(n):
        for j in range(n):
            if i != j:
                nd[a[i] - a[j]] += 1
        for j in range(i, n):
            ns[a[i] + a[j]] += 1
    return a, nd, ns


def _add_elem(a, nd, ns, x):
    # x not in a
    new_d = 0
    new_s = 0
    for y in a:
        for d in (x - y, y - x):
            if nd[d] == 0:
                new_d += 1
            nd[d] += 1
        s = x + y
        if ns[s] == 0:
            new_s += 1
        ns[s] += 1
    s = x + x
    if ns[s] == 0:
        new_s += 1
    ns[s] += 1
    a.append(x)
    return new_d, new_s


def _remove_elem(a, nd, ns, i):
    x = a.pop(i)
    for y in a:
        for d in (x - y, y - x):
            nd[d] -= 1
        s = x + y
        ns[s] -= 1
    ns[x + x] -= 1
    return x


def _delta_add(a, nd, ns, x):
    """(new diffs, new sums) without mutating."""
    new_d = 0
    new_s = 0
    for y in a:
        for d in (x - y, y - x):
            if nd[d] == 0:
                new_d += 1
        if ns[x + y] == 0:
            new_s += 1
    if ns[x + x] == 0:
        new_s += 1
    return new_d, new_s


def _delta_remove(a, nd, ns, i):
    """Count of diffs/sums that would drop to 0 if element i removed."""
    x = a[i]
    lost_d = 0
    lost_s = 0
    seen_d = set()
    seen_s = set()
    for k, y in enumerate(a):
        if k == i:
            continue
        for d in (x - y, y - x):
            if d not in seen_d:
                seen_d.add(d)
                if nd[d] == 1:
                    lost_d += 1
        s = x + y
        if s not in seen_s:
            seen_s.add(s)
            if ns[s] == 1:
                lost_s += 1
    if (x + x) not in seen_s and ns[x + x] == 1:
        lost_s += 1
    return lost_d, lost_s


def _incremental_search(seed, deadline, rng):
    a, nd, ns = _make_state(seed)
    ND = len(nd)
    NS = len(ns)
    best_a = list(a)
    best_sc = _score_from(a, ND, NS)

    while time.time() < deadline:
        r = rng.random()
        if not a:
            break
        if r < 0.45:
            # shift an element
            i = rng.randrange(len(a))
            x = a[i]
            step = rng.choice([1, 1, 2, -1, -2, 3, -3, 5, -5])
            nx = x + step
            if nx in nd or any(v == nx for v in a):
                continue
            ld, ls = _delta_remove(a, nd, ns, i)
            _remove_elem(a, nd, ns, i)
            if nx in a:
                a.insert(i, x)
                for y in a:
                    if y != x:
                        nd[x - y] += 1
                        nd[y - x] += 1
                        ns[x + y] += 1
                ns[x + x] += 1
                continue
            ad, as_ = _delta_add(a, nd, ns, nx)
            _add_elem(a, nd, ns, nx)
            nND = ND - ld + ad
            nNS = NS - ls + as_
            nsc = _score_from(a, nND, nNS) if nNS >= 2 and nND >= 2 else -1.0
            if nsc > best_sc:
                best_sc = nsc
                best_a = list(a)
                ND, NS = nND, nNS
            elif nsc < best_sc - rng.random() * 0.001:
                # revert
                i_new = a.index(nx)
                _remove_elem(a, nd, ns, i_new)
                _add_elem(a, nd, ns, x)
                a.sort()
        elif r < 0.80 and len(a) < 4000:
            # add element near anchor
            anchor = a[rng.randrange(len(a))]
            nx = anchor + rng.choice([1, 1, 2, -1, 2, 3, -2])
            if nx in a:
                continue
            ad, as_ = _delta_add(a, nd, ns, nx)
            _add_elem(a, nd, ns, nx)
            a.sort()
            nND = ND + ad
            nNS = NS + as_
            nsc = _score_from(a, nND, nNS)
            if nsc > best_sc:
                best_sc = nsc
                best_a = list(a)
                ND, NS = nND, nNS
            elif nsc < best_sc - rng.random() * 0.002:
                _remove_elem(a, nd, ns, a.index(nx))
        elif r < 0.95 and len(a) > 4:
            # remove element
            i = rng.randrange(len(a))
            ld, ls = _delta_remove(a, nd, ns, i)
            x = a[i]
            _remove_elem(a, nd, ns, i)
            nND = ND - ld
            nNS = NS - ls
            nsc = _score_from(a, nND, nNS) if nNS >= 2 and nND >= 2 else -1.0
            if nsc > best_sc:
                best_sc = nsc
                best_a = list(a)
                ND, NS = nND, nNS
            elif nsc < best_sc - rng.random() * 0.002:
                _add_elem(a, nd, ns, x)
                a.sort()
        else:
            # global restart from best
            a, nd, ns = _make_state(best_a)
            ND = len(nd)
            NS = len(ns)

    return best_a


def solve():
    start = time.time()
    deadline = start + 115.0
    rng = random.Random(20240517)

    best = None
    best_sc = -1.0

    # Constructive seeds.
    configs = []
    for clusters in (2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 28, 32, 40):
        for plen in (2, 3, 4, 5, 6, 8, 10, 12, 14, 16):
            if clusters * plen <= 4000:
                configs.append((clusters, plen))
    configs.sort(key=lambda cp: abs(cp[0] * cp[1] - 80))

    for clusters, plen in configs:
        if time.time() > start + 5:
            break
        for spacing in (1, 2, 3):
            A = _build(clusters, plen, spacing)
            _, _, sc = _stats(A)
            if sc > best_sc:
                best_sc = sc
                best = list(A)

    if best is None:
        best = [0, 1, 2, 4, 8]

    # Incremental local search with restarts across the time budget.
    round_no = 0
    while time.time() < deadline - 3:
        round_no += 1
        slice_end = min(deadline - 1, time.time() + 25)
        cand = _incremental_search(best, slice_end, rng)
        _, _, csc = _stats(cand)
        if csc > best_sc:
            best_sc = csc
            best = list(cand)
        elif round_no > 1:
            # diversify: perturb best
            b = list(best)
            if b:
                i = rng.randrange(len(b))
                b[i] += rng.choice([-3, -2, -1, 1, 2, 3])
            cand2 = _incremental_search(b, min(deadline - 1, time.time() + 20), rng)
            _, _, csc2 = _stats(cand2)
            if csc2 > best_sc:
                best_sc = csc2
                best = list(cand2)

    best = sorted(set(int(x) for x in best))
    if len(best) > 4000:
        best = best[:4000]
    return best
# EVOLVE-BLOCK-END

